# `_import/` — постоянная transfer boundary EFHC Frontend

Статус: **OWNER-PROTECTED / PERSISTENT / DO NOT DELETE**.

`_import/` — постоянная входная папка для синхронизации полного physical release с GitHub repository. Папка входит в каждый physical release и должна существовать в repository всегда.

## Основной workflow

1. Рабочее состояние развивается локально в одном persistent workspace ChatGPT.
2. После material checkpoint создаётся полный immutable `FRONTEND_vNNN.zip`.
3. OWNER вручную загружает этот полный ZIP в repository по пути `_import/FRONTEND_vNNN.zip`.
4. `repository-import-sync` проверяет ZIP и зеркально синхронизирует repository tree с содержимым полного архива.
5. После успешной синхронизации transport ZIP удаляется из repository commit, но `_import/README.md` и сама папка `_import/` сохраняются.
6. GitHub repository-native CI проверяет уже синхронизированный exact HEAD.

## Правила

- `_import/` **никогда не удаляется автоматически**.
- Удаление `_import/` разрешено только по новой прямой команде OWNER, явно отменяющей этот канон.
- `_import/` — transfer/staging boundary, а не runtime/source authority.
- Canonical runtime/source после применения ZIP находится в обычных project paths (`frontend/`, `backend/`, `api/`, `docs/`, `ops/`, `reports/` и т. д.).
- Основной transport payload — **полный physical release `FRONTEND_vNNN.zip`**, а не patch-only архив.
- Загруженный ZIP должен быть полной копией physical release, а не набором только изменённых файлов.
- Одновременно в `_import/` допускается только один ожидающий применения `FRONTEND_vNNN.zip`.
- Nested ZIP допускается только внутри `_import/`; вне `_import/` nested ZIP запрещён.
- После успешного импорта transport ZIP удаляется, чтобы repository не хранил дубликат полного проекта внутри самого себя.
- Cache/build/temp/bytecode, `node_modules`, `.next` и scratch/debug payloads в `_import/` запрещены.
- Workflow обязан fail-closed при CRC failure, unsafe path, duplicate ZIP entries, symlink, version/companion mismatch или отсутствии этого README в импортируемом release.
- Workflow не имеет права удалять этот README или оставлять repository без `_import/`.

## Authority

`OWNER / SSOT / CANON / NORM` > physical release contract > GitHub repository history/CI > `_import/` transport payload.

`_import/` переносит authority; сама папка authority не создаёт.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

