"""Minimal stub of the `freezegun` API used by EFHC tests.

This repository's tests require `freeze_time` to deterministically
control time-based logic. The upstream `freezegun` package is not a
strict runtime
dependency of the bot, so we ship a tiny, test-only compatible subset.

Supported:
  - from freezegun import freeze_time
  - freeze_time("2026-01-01T00:00:00Z") as a context manager

Notes:
  - This implementation patches `datetime.datetime` and `time.time`.
  - It is intentionally minimal and should only be used by tests.
"""

from __future__ import annotations

import contextlib
import datetime as _dt
import time as _time
from typing import Iterator, Optional, Union
from unittest.mock import patch


def _parse_time(value: Union[str, _dt.datetime]) -> _dt.datetime:
    if isinstance(value, _dt.datetime):
        dt = value
    else:
        s = str(value).strip()
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = _dt.datetime.fromisoformat(s)

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc)
    return dt


@contextlib.contextmanager
def freeze_time(
    value: Union[str, _dt.datetime],
) -> Iterator[_dt.datetime]:
    """Freeze time for the duration of the context.

    Returns the frozen datetime.
    """
    frozen = _parse_time(value)
    frozen_ts = frozen.timestamp()

    class FrozenDateTime(_dt.datetime):
        @classmethod
        def now(
            cls,
            tz: Optional[_dt.tzinfo] = None,
        ) -> "FrozenDateTime":
            if tz is None:
                return cls.fromtimestamp(frozen_ts, tz=_dt.timezone.utc)
            return cls.fromtimestamp(frozen_ts, tz=tz)

        @classmethod
        def utcnow(cls) -> "FrozenDateTime":
            dt = cls.fromtimestamp(frozen_ts, tz=_dt.timezone.utc)
            return dt.replace(tzinfo=None)

    with patch("datetime.datetime", FrozenDateTime), patch(
        "time.time",
        lambda: frozen_ts,
    ):
        yield frozen

__all__ = ["freeze_time"]
