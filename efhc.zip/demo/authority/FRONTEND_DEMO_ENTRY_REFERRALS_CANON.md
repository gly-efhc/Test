# FRONTEND DEMO ENTRY + REFERRALS CANON — CURRENT

Статус: **ACTIVE / CURRENT / UNVERSIONED CANON**.

## DEMO startup

- Standalone review-role по умолчанию = `admin`, чтобы Admin entrypoints были доступны OWNER для ручного review.
- Это не backend authorization и не выдаёт реальные server-admin права.
- Первый обычный product route = `/` (`Energy`). Review-role и текущая product page независимы.
- Ручное USER/ADMIN переключение сохраняется и меняет только состояние simulation/review contour.
- Owner-visible Admin UI должен следовать текущему simulated `/admin/access` → frontend access-state contract, а не отдельной обходной preview-role ветке.

## Referrals entrypoint

- `/referrals` содержит одну широкую кнопку `Мои Рефералы` → `/referrals/my`.
- Дублирующая кнопка не создаётся.
- `/referrals/my` roster, Active/Inactive, cursor pagination, newest-first и backend/economy contracts не меняются этим CANON.
