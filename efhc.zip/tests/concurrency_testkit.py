from __future__ import annotations

import importlib
import os

import pytest

pytest.importorskip("sqlalchemy")


def get_async_database_url() -> str:
    """Return DATABASE_URL normalized for SQLAlchemy AsyncEngine."""
    db_url = os.getenv("ASYNC_DATABASE_URL") or os.getenv(
        "DATABASE_URL", ""
    )
    if not db_url:
        pytest.skip("ASYNC_DATABASE_URL/DATABASE_URL is not set")
    if db_url.startswith("sqlite://"):
        pytest.fail("SQLite is forbidden by CANON")
    if db_url.startswith("postgresql+asyncpg://"):
        return db_url
    if db_url.startswith("postgresql+psycopg://"):
        return (
            "postgresql+asyncpg://"
            + db_url[len("postgresql+psycopg://") :]
        )
    if db_url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + db_url[len("postgresql://") :]
    if db_url.startswith("postgres://"):
        return "postgresql+asyncpg://" + db_url[len("postgres://") :]
    return db_url


def reload_transactions_service() -> object:
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.transactions_service as ts

    return importlib.reload(ts)


def reload_withdraw_service() -> object:
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.withdraw_service as ws

    return importlib.reload(ws)


def reload_tx_and_withdraw_services_for_postgres() -> tuple[
    object, object
]:
    db_url = os.getenv("DATABASE_URL", "")
    if not db_url:
        pytest.skip("DATABASE_URL is not set")
    if db_url.startswith("sqlite://"):
        pytest.fail("SQLite is forbidden by CANON")

    from app.core import config_core

    config_core.get_settings.cache_clear()

    import app.services.transactions_service as ts
    import app.services.withdraw_service as ws

    return importlib.reload(ts), importlib.reload(ws)


async def ensure_core_user(
    db,
    *,
    global_id: int,
    tg_id: int | None = None,
    username: str = "user",
    ton_wallet: str | None = None,
    main_balance: str = "0.00000000",
) -> None:
    from sqlalchemy import text

    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  global_id, tg_id, username, is_vip, is_active,",
                    "  ton_wallet,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, exchanged_kwh_total,",
                    "  created_at, updated_at",
                    ") VALUES (",
                    "  :global_id, :tg_id, :u, false, true,",
                    "  NULLIF(:tw, ''),",
                    "  :mb, '0.00000000',",
                    "  '0.00000000', '0.00000000',",
                    "  NOW(), NOW()",
                    ")",
                    "ON CONFLICT (global_id) DO NOTHING",
                ]
            )
        ),
        {
            "global_id": global_id,
            "tg_id": tg_id,
            "u": username,
            "tw": ton_wallet,
            "mb": main_balance,
        },
    )
    await db.commit()


async def ensure_admin_whitelist(
    db,
    *,
    global_id: int,
    tg_id: int | None = None,
) -> None:
    from sqlalchemy import text

    await ensure_core_user(
        db,
        global_id=int(global_id),
        tg_id=(int(tg_id) if tg_id is not None else None),
        username="admin",
    )
    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_admin.admin_whitelist (",
                    "  global_id, tg_id, is_active",
                    ") VALUES (",
                    "  :global_id, :tg_id, true",
                    ")",
                    "ON CONFLICT (global_id) DO UPDATE SET",
                    "  tg_id = EXCLUDED.tg_id,",
                    "  is_active = true",
                ]
            )
        ),
        {
            "global_id": int(global_id),
            "tg_id": int(tg_id) if tg_id is not None else None,
        },
    )
    await db.commit()


async def reset_core_tables(engine, schema: str) -> None:
    from sqlalchemy import text

    async with engine.begin() as conn:
        await conn.execute(
            text(
                f"TRUNCATE TABLE {schema}.withdraw_requests, "
                f"{schema}.efhc_transfers_log, {schema}.users "
                "RESTART IDENTITY CASCADE"
            )
        )
        await conn.execute(
            text(
                """
                INSERT INTO efhc_core.identity_migration_control (
                    singleton_id, dual_write_enabled, shadow_read_enabled,
                    legacy_authoritative,
                    nonfinancial_read_global_id_enabled,
                    nonfinancial_read_rollback_ready,
                    financial_read_global_id_enabled,
                    financial_read_rollback_ready, updated_at
                ) VALUES (
                    1, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, now()
                )
                ON CONFLICT (singleton_id) DO UPDATE SET
                    dual_write_enabled = TRUE,
                    shadow_read_enabled = TRUE,
                    legacy_authoritative = TRUE,
                    nonfinancial_read_global_id_enabled = TRUE,
                    nonfinancial_read_rollback_ready = TRUE,
                    financial_read_global_id_enabled = TRUE,
                    financial_read_rollback_ready = TRUE,
                    updated_at = now()
                """
            )
        )


__all__ = [
    "ensure_admin_whitelist",
    "get_async_database_url",
    "ensure_core_user",
    "reload_transactions_service",
    "reload_tx_and_withdraw_services_for_postgres",
    "reload_withdraw_service",
    "reset_core_tables",
]
