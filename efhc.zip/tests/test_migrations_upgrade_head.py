# SPDX-License-Identifier: MIT
"""Alembic smoke: clean DB -> upgrade head.

Goal: prove that a fresh install (empty DB) can run
`alembic upgrade head` and that key tables exist.

CI canon: Postgres-only. SQLite is forbidden.
"""

from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest


def _import_or_skip(name: str):
    """Import helper for minimal vs full CI.

    In minimal environments the migration smoke may be skipped.
    In full CI (`EFHC_CI_FULL=1`) missing deps is an env error.
    """
    try:
        return __import__(name, fromlist=["*"])
    except Exception as exc:
        if os.getenv("EFHC_CI_FULL") == "1":
            pytest.fail(f"Missing dependency: {name}: {exc}")
        pytest.skip(
            f"Missing dependency: {name}",
            allow_module_level=True,
        )


sa = _import_or_skip("sqlalchemy")
command = _import_or_skip("alembic.command")
Config = _import_or_skip("alembic.config").Config
psycopg = _import_or_skip("psycopg")


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _alembic_config(repo_root: Path, db_url: str) -> Config:
    """Build Alembic Config using backend/alembic.ini.

    The project relies on ini defaults (section, logging, etc.).
    A bare Config() can miss these and lead to env.py running
    without a valid engine_from_config setup.
    """
    ini = repo_root / "backend" / "alembic.ini"
    cfg = Config(str(ini))
    cfg.set_main_option("sqlalchemy.url", db_url)
    mig = repo_root / "backend" / "migrations"
    cfg.set_main_option("script_location", str(mig))
    return cfg


def _set_urls_for_alembic(db_url: str) -> dict[str, str | None]:
    keys = [
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    ]
    prev: dict[str, str | None] = {k: os.getenv(k) for k in keys}
    os.environ["DATABASE_URL"] = db_url
    os.environ["SYNC_DATABASE_URL"] = db_url
    os.environ["ASYNC_DATABASE_URL"] = db_url
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(db_url)
    return prev


def _restore_env(prev: dict[str, str | None]) -> None:
    for k, v in prev.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


def test_alembic_upgrade_head_postgres() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    base_url = os.getenv("DATABASE_URL")
    if not base_url:
        pytest.skip("DATABASE_URL is required")
    if str(base_url).startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon")

    dbname = f"alembic_smoke_{uuid.uuid4().hex[:12]}"
    admin_url = str(base_url).rstrip("/")
    if "/" in admin_url.rsplit("@", 1)[-1]:
        admin_url = admin_url.rsplit("/", 1)[0] + "/postgres"

    with psycopg.connect(_to_psycopg_url(admin_url)) as conn:
        conn.autocommit = True
        conn.execute(f'CREATE DATABASE "{dbname}"')

    db_url = str(base_url).rsplit("/", 1)[0] + f"/{dbname}"
    cfg = _alembic_config(repo_root, db_url)
    prev = _set_urls_for_alembic(db_url)
    try:
        command.upgrade(cfg, "head")
    finally:
        _restore_env(prev)

    engine = sa.create_engine(db_url)
    core = os.getenv("DB_SCHEMA_CORE", "efhc_core")
    with engine.begin() as conn:
        for name in ("users", "panels", "efhc_transfers_log"):
            q = f'SELECT 1 FROM "{core}"."{name}" LIMIT 1'
            conn.execute(sa.text(q))

    with psycopg.connect(_to_psycopg_url(admin_url)) as conn:
        conn.autocommit = True
        conn.execute(
            "SELECT pg_terminate_backend(pid) "
            "FROM pg_stat_activity "
            "WHERE datname = %s AND pid <> pg_backend_pid()",
            (dbname,),
        )
        conn.execute(f'DROP DATABASE IF EXISTS "{dbname}"')