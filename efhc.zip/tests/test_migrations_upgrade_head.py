# SPDX-License-Identifier: MIT
"""Alembic smoke: clean DB -> upgrade head.

Goal: prove that a fresh install (empty DB) can run
`alembic upgrade head` and that key tables exist.

CI canon: Postgres-only. SQLite is forbidden.
"""

from __future__ import annotations

from pathlib import Path

import os

import pytest


def _import_or_skip(name: str):
    """Import helper for minimal vs full CI.

    In minimal environments the migration smoke may be skipped.
    In full CI (`EFHC_CI_FULL=1`) missing deps is an env error.
    """
    try:
        return __import__(name, fromlist=["*"])
    except Exception as exc:
        if os.getenv("EFHC_CI_FULL") == "1":
            pytest.fail(f"Missing dependency: {name}: {exc}")
        pytest.skip(
            f"Missing dependency: {name}",
            allow_module_level=True,
        )


sa = _import_or_skip("sqlalchemy")
command = _import_or_skip("alembic.command")
Config = _import_or_skip("alembic.config").Config


def _alembic_config(repo_root: Path, db_url: str) -> Config:
    cfg = Config()
    cfg.set_main_option(
        "script_location",
        str(repo_root / "backend" / "migrations"),
    )
    cfg.set_main_option("sqlalchemy.url", db_url)
    return cfg


def test_alembic_upgrade_head_postgres(tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    base_url = os.getenv("DATABASE_URL")
    if not base_url:
        pytest.skip("DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    if base_url.startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # create a temporary database for migration smoke
    import uuid
    import psycopg
    dbname = f"alembic_smoke_{uuid.uuid4().hex[:12]}"
    # connect to default 'postgres' database to create/drop temp db
    admin_url = base_url
    if admin_url.endswith("/"):
        admin_url = admin_url[:-1]
    # swap db name to postgres
    if "/" in admin_url.rsplit("@",1)[-1]:
        admin_url = admin_url.rsplit("/",1)[0] + "/postgres"
    with psycopg.connect(_to_psycopg_url(admin_url)) as conn:
        conn.autocommit = True
        conn.execute(f'CREATE DATABASE "{dbname}"')
    db_url = base_url.rsplit("/",1)[0] + f"/{dbname}"

    cfg = _alembic_config(repo_root, db_url)
    command.upgrade(cfg, "head")

    engine = sa.create_engine(db_url)
    with engine.begin() as conn:
        for name in (
            "users",
            "panels",
            "efhc_transfers_log",
        ):
            conn.execute(sa.text(f"SELECT 1 FROM {name} LIMIT 1"))


    # cleanup temp database
    with psycopg.connect(_to_psycopg_url(admin_url)) as conn:
        conn.autocommit = True
        # terminate connections if any
        conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = %s AND pid <> pg_backend_pid()",
            (dbname,),
        )
        conn.execute(f'DROP DATABASE IF EXISTS "{dbname}"')
