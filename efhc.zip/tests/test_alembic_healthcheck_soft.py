import os
import subprocess
import warnings
from pathlib import Path


def _run(cmd: str, cwd: str | None = None) -> tuple[int, str]:
    p = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return p.returncode, p.stdout


def test_alembic_healthcheck_soft() -> None:
    """
    SOFT healthcheck:
    - НЕ валит тесты/CI
    - подсвечивает проблемы Alembic/миграций/структуры репо
    """
    problems: list[str] = []

    repo = Path(".").resolve()
    backend = repo / "backend"
    alembic_ini = backend / "alembic.ini"

    if not backend.exists():
        problems.append("backend/ отсутствует")
    if not alembic_ini.exists():
        problems.append("backend/alembic.ini отсутствует")
    if not (backend / "migrations").exists():
        problems.append("backend/migrations/ отсутствует")
    if not (backend / "migrations" / "env.py").exists():
        problems.append("backend/migrations/env.py отсутствует")
    if not (backend / "migrations" / "versions").exists():
        problems.append("backend/migrations/versions/ отсутствует")

    # 1) compileall (самый ранний стоп-кран)
    rc, out = _run("python -m compileall backend -q")
    if rc != 0:
        problems.append("compileall упал (синтаксис/отступы)")
        problems.append(out.strip())

    # 2) alembic history (проверка что миграции видны)
    if alembic_ini.exists():
        cmd = "python -m alembic -c alembic.ini history"
        rc, out = _run(cmd, cwd=str(backend))
        if rc != 0:
            problems.append("alembic history упал")
            problems.append(out.strip())
        else:
            # небольшой sanity: должен быть head
            if "head" not in out.lower():
                problems.append(
                    "alembic history: не вижу head "
                    "(подозрение на конфиг)"
                )

    # 3) Offline --sql (полезно как сигнал)
    fake_url = "postgresql://user:pass@localhost:5432/db"
    env = os.environ.copy()
    env.setdefault("DATABASE_URL", fake_url)
    if alembic_ini.exists():
        cmd = "python -m alembic -c alembic.ini upgrade head --sql"
        p = subprocess.run(
            cmd,
            shell=True,
            cwd=str(backend),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if p.returncode != 0:
            problems.append(
                "alembic --sql (offline) падает (ок, но важно знать)"
            )
            problems.append(p.stdout.strip())

    # Итог: НИКОГДА не падаем, только подсвечиваем
    if problems:
        msg = "\n".join(f"ERROR: {x}" for x in problems if x)
        warnings.warn(
            "SOFT Alembic healthcheck нашёл проблемы:\n" + msg,
            category=RuntimeWarning,
            stacklevel=2,
        )
        print("\n" + msg + "\n")
    else:
        print("\nOK: Alembic healthcheck (soft)\n")

    assert True
