"""Frontend SSOT guard.

CI MUST fail if SSOT UI zones reintroduce float/Number patterns.

Scope is intentionally fixed and minimal.
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_frontend_has_package_lock_for_ci_determinism() -> None:
    """Frontend CI MUST be deterministic.

    The CI uses `npm ci`, which requires a lockfile.
    """

    lockfile = ROOT / "frontend" / "package-lock.json"
    assert lockfile.exists(), "Missing frontend/package-lock.json"


SSOT_UI_PATHS = [
    Path("frontend/src/pages/exchange.tsx"),
    Path("frontend/src/pages/index.tsx"),
    Path("frontend/src/pages/panels.tsx"),
    Path("frontend/src/components/GlobalHeader.tsx"),
    Path("frontend/src/components/Layout.tsx"),
    Path("frontend/src/components/EnergyGauge.tsx"),
    Path("frontend/src/pages/admin/withdrawals.tsx"),
    Path("frontend/src/pages/admin/bank.tsx"),
    Path("frontend/src/pages/admin/shop.tsx"),
    Path("frontend/src/lib/format.ts"),
]


VISUAL_SSOT_UI_PATHS = [
    Path("frontend/src/pages/exchange.tsx"),
    Path("frontend/src/pages/index.tsx"),
    Path("frontend/src/pages/panels.tsx"),
    Path("frontend/src/pages/tasks.tsx"),
    Path("frontend/src/pages/referrals.tsx"),
    Path("frontend/src/pages/ranks.tsx"),
    Path("frontend/src/components/GlobalHeader.tsx"),
    Path("frontend/src/components/Layout.tsx"),
    Path("frontend/src/components/ui/Button.tsx"),
    Path("frontend/src/components/ui/Card.tsx"),
    Path("frontend/src/components/ui/Badge.tsx"),
    Path("frontend/src/components/ui/EmptyState.tsx"),
    Path("frontend/src/components/ui/Skeleton.tsx"),
    Path("frontend/src/pages/shop.tsx"),
    Path("frontend/src/pages/lotteries.tsx"),
    Path("frontend/src/components/ui/Modal.tsx"),
    Path("frontend/src/components/ProfileModal.tsx"),
    Path("frontend/src/components/ui/EfhcStatus.tsx"),
    Path("frontend/src/components/ui/LevelSkinBadge.tsx"),
    Path("frontend/src/pages/admin/withdrawals.tsx"),
    Path("frontend/src/pages/admin/bank.tsx"),
    Path("frontend/src/pages/admin/shop.tsx"),
    Path("frontend/src/pages/_app.tsx"),
]


FORBIDDEN_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("Number(", re.compile(r"\bNumber\s*\(")),
    ("parseFloat(", re.compile(r"\bparseFloat\s*\(")),
    ("toFixed(", re.compile(r"\btoFixed\s*\(")),
    ("toExponential(", re.compile(r"\btoExponential\s*\(")),
]


def _read_text(rel: Path) -> str:
    abs_path = ROOT / rel
    assert abs_path.exists(), f"Missing file: {rel.as_posix()}"
    return abs_path.read_text(encoding="utf-8")


def test_ui_ssot_no_float_number_patterns() -> None:
    bad: list[str] = []

    for rel in SSOT_UI_PATHS:
        text = _read_text(rel)
        for label, rx in FORBIDDEN_PATTERNS:
            if rx.search(text):
                bad.append(f"{rel.as_posix()}: {label}")

    assert not bad, (
        "Forbidden UI float/Number patterns found:\n"
        + "\n".join(bad)
    )


def test_frontend_fixed_tsx_files_start_with_import() -> None:
    """Minimal TSX compile-sanity guard.

    Pytest does not typecheck/compile TSX. This guard prevents
    releasing a syntactically torn file (e.g. missing first 'import').

    Scope is intentionally fixed and minimal.
    """

    files = [Path("frontend/src/pages/index.tsx")]
    bad: list[str] = []

    rx_broken = re.compile(r"^\s*mport\b")

    for rel in files:
        text = _read_text(rel)
        lines = text.splitlines()

        # Skip empty lines and line comments.
        first = ""
        for ln in lines:
            s = ln.strip()
            if not s:
                continue
            if s.startswith("//"):
                continue
            first = s
            break

        if not first.startswith("import "):
            bad.append(f"{rel.as_posix()}: first token not import")
        if rx_broken.search(text):
            bad.append(f"{rel.as_posix()}: broken 'mport' detected")

    assert not bad, (
        "Frontend TSX sanity guard failed:\n" + "\n".join(bad)
    )


def test_exchange_d8_rejects_scientific_notation() -> None:
    exchange = _read_text(Path("frontend/src/pages/exchange.tsx"))
    format_ts = _read_text(Path("frontend/src/lib/format.ts"))

    has_exchange_guard = any(
        pat in exchange
        for pat in [
            "includes(\"e\")",
            "includes(\"E\")",
            "includes('e')",
            "includes('E')",
            "[eE]",
        ]
    )

    has_formatter_guard = "Scientific notation forbidden" in format_ts

    assert has_exchange_guard, (
        "Exchange must reject e/E in D8 string inputs"
    )
    assert has_formatter_guard, (
        "Formatter must reject scientific notation"
    )


def test_ui_visual_ssot_no_hardcoded_colors() -> None:
    """SSOT UI zone must rely on Telegram theme tokens.

    No hardcoded colors allowed in the fixed SSOT UI list.
    """

    bad: list[str] = []

    rx_hex = re.compile(r"#[0-9a-fA-F]{3,8}")
    rx_fn = re.compile(r"\b(?:rgb|rgba|hsl|hsla)\s*\(")
    rx_tw = re.compile(
        r"\b(?:bg|text|border)-(?:white|black|gray|zinc|"
        r"slate|neutral|stone|red|amber|emerald|yellow|blue)"
        r"(?:-[0-9]{2,3})?(?:/[0-9]{1,3})?\b"
    )

    for rel in VISUAL_SSOT_UI_PATHS:
        text = _read_text(rel)
        if rx_hex.search(text):
            bad.append(f"{rel.as_posix()}: hex")
        if rx_fn.search(text):
            bad.append(f"{rel.as_posix()}: rgb/hsl")
        if rx_tw.search(text):
            bad.append(f"{rel.as_posix()}: tailwind")

    assert not bad, (
        "Forbidden UI float/Number patterns found:\n"
        + "\n".join(bad)
    )


def test_ui_level_badge_no_hex_or_inline_palette() -> None:
    """Level badge MUST NOT inject hex/palette into user UI."""

    rel = Path("frontend/src/components/ui/LevelSkinBadge.tsx")
    text = _read_text(rel)

    assert "#" not in text, "LevelSkinBadge must not contain '#'"
    assert "accent_" not in text, "LevelSkinBadge must not use skin accents"


def test_ui_telegram_theme_tokens_exist_and_sync() -> None:
    globals_css = _read_text(Path("frontend/src/styles/globals.css"))
    telegram_ts = _read_text(Path("frontend/src/lib/telegram.ts"))

    for token in [
        "--tg-bg",
        "--tg-text",
        "--tg-hint",
        "--tg-link",
        "--tg-button",
        "--tg-button-text",
    ]:
        assert token in globals_css, (
            f"Missing token in globals.css: {token}"
        )
        assert token in telegram_ts, (
            f"Missing token sync in telegram.ts: {token}"
        )


def test_walletgate_autoconnect_wiring_exists() -> None:
    """Guard: all gated CTAs must open TonConnect modal immediately."""

    header = _read_text(Path("frontend/src/components/GlobalHeader.tsx"))
    layout = _read_text(Path("frontend/src/components/Layout.tsx"))
    profile = _read_text(Path("frontend/src/components/ProfileModal.tsx"))
    exchange = _read_text(Path("frontend/src/pages/exchange.tsx"))
    shop = _read_text(Path("frontend/src/pages/shop.tsx"))
    lotteries = _read_text(Path("frontend/src/pages/lotteries.tsx"))

    assert "Пополнить" in header, "Header must include 'Пополнить'"
    assert "openWalletConnect" in layout, (
        "Layout must expose openWalletConnect()"
    )
    assert "onOpenWalletConnect" in profile, (
        "Profile wallet CTA must call onOpenWalletConnect()"
    )
    assert "openWalletConnect" in exchange, (
        "Withdraw gate must use openWalletConnect()"
    )
    assert "openWalletConnect" in shop, (
        "Shop external/deposit gates must use openWalletConnect()"
    )
    assert "openWalletConnect" in lotteries, (
        "Lotteries gate must use openWalletConnect()"
    )


FORBIDDEN_CLOUD_KEYS = [
    "balance",
    "main_balance",
    "available",
    "withdraw",
    "exchange",
]


def test_ui_cloudstorage_no_financial_keys() -> None:
    """CloudStorage MUST NOT persist any financial/state keys."""

    front = ROOT / "frontend" / "src"
    assert front.exists(), "Missing frontend/src"

    bad: list[str] = []

    rx_wrapped = re.compile(
        r"telegramCloudStorage(?:Get|Set)\(\s*[\"\']([^\"\']+)[\"\']"
    )
    rx_direct = re.compile(
        r"\.CloudStorage\.(?:getItem|setItem)\("
        r"\s*[\"\']([^\"\']+)[\"\']"
    )

    for abs_path in front.rglob("*.ts*"):
        rel = abs_path.relative_to(ROOT)
        text = abs_path.read_text(encoding="utf-8")

        for rx in (rx_wrapped, rx_direct):
            for m in rx.finditer(text):
                key = m.group(1).lower()
                if any(k in key for k in FORBIDDEN_CLOUD_KEYS):
                    bad.append(f"{rel.as_posix()}: {key}")

    assert not bad, (
        "Forbidden UI float/Number patterns found:\n"
        + "\n".join(bad)
    )


def test_docs_telegram_theme_tokens_are_fixed() -> None:
    """Docs MUST закреплять список --tg-* tokens."""

    doc = _read_text(Path("docs/TELEGRAM_WEBAPP_INTEGRATION.md"))

    for token in [
        "--tg-bg",
        "--tg-text",
        "--tg-hint",
        "--tg-link",
        "--tg-button",
        "--tg-button-text",
        "--tg-secondary-bg",
    ]:
        assert token in doc, f"Missing token in docs: {token}"
