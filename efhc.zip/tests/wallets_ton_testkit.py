from __future__ import annotations

import contextlib
import importlib
import os
from datetime import UTC, datetime

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")


def get_async_db_url() -> str:
    url = (
        os.getenv("ASYNC_DATABASE_URL")
        or os.getenv("DATABASE_URL")
        or os.getenv("SYNC_DATABASE_URL")
    )
    if not url:
        pytest.skip(
            "DATABASE_URL/ASYNC_DATABASE_URL is required "
            "for Postgres-only CI",
            allow_module_level=True,
        )
    if url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://") :]
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://") :]
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgresql+psycopg://"):
        return (
            "postgresql+asyncpg://"
            + url[len("postgresql+psycopg://") :]
        )
    return url


async def init_sqlite_wallets_schema(db_url: str) -> None:
    from sqlalchemy import event, text
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(db_url, future=True)
    if not db_url.lower().startswith("sqlite"):
        async with engine.begin() as conn:
            await conn.execute(
                text(
                    "TRUNCATE TABLE "
                    "efhc_core.wallet_connect_idempotency, "
                    "efhc_core.wallet_proof_token_uses, "
                    "efhc_core.wallet_bindings "
                    "RESTART IDENTITY CASCADE"
                )
            )
        await engine.dispose()
        return

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        with contextlib.suppress(Exception):
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(UTC).isoformat(),
            )

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))
        await conn.execute(
            text("""
                CREATE TABLE IF NOT EXISTS efhc_core.wallet_bindings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    wallet_address TEXT NOT NULL UNIQUE,
                    wallet_app TEXT,
                    is_primary INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    proof_verified INTEGER NOT NULL DEFAULT 0,
                    proof_verified_at TEXT,
                    proof_payload_hash TEXT,
                    proof_source TEXT,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP)
                )
                """)
        )
        await conn.execute(
            text("""
                CREATE TABLE IF NOT EXISTS
                    efhc_core.wallet_connect_idempotency (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    wallet_id INTEGER NOT NULL,
                    wallet_address TEXT NOT NULL,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
                    UNIQUE (tg_id, idempotency_key)
                )
                """)
        )
        await conn.execute(
            text("""
                CREATE TABLE IF NOT EXISTS
                    efhc_core.wallet_proof_token_uses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    wallet_address TEXT NOT NULL,
                    proof_payload_hash TEXT NOT NULL UNIQUE,
                    idempotency_key TEXT NOT NULL,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP)
                )
                """)
        )

    await engine.dispose()


def reload_wallets_service_for_sqlite() -> object:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.wallets_service as ws

    return importlib.reload(ws)


__all__ = [
    "get_async_db_url",
    "init_sqlite_wallets_schema",
    "reload_wallets_service_for_sqlite",
]
