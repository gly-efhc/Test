from __future__ import annotations

import importlib
import os
from datetime import datetime, timedelta, timezone

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_panels_service_for_postgres():
    os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    from backend.app.services import panels_service
    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_active_archive_classification_by_server_now() -> None:
    panels_service = _reload_panels_service_for_postgres()

    fixed_now = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
    # legacy hook inside service used by tests
    if hasattr(panels_service, "utcnow"):
        panels_service.utcnow = lambda: fixed_now  # type: ignore

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(panels_service, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    tg_id = 4001

    async with Session() as db:
        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.users (tg_id, main_balance, bonus_balance)
                VALUES (:tg, '0.00000000', '0.00000000')
                """
            ),
            {"tg": tg_id},
        )

        # panel 1: active (expires after server_now)
        act = fixed_now - timedelta(days=1)
        exp_active = fixed_now + timedelta(days=1)
        # panel 2: archive (expires at/before server_now)
        exp_arch = fixed_now

        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.panels (
                    tg_id,
                    public_id,
                    activated_at,
                    created_at,
                    expires_at,
                    last_generated_at,
                    base_gen_per_sec,
                    generated_kwh,
                    is_active,
                    archived_at
                )
                VALUES
                  (:tg, 'ID00000001', :act, :act, :exp1, :act, '0.00000692',
                   '0.00000000', 1, NULL),
                  (:tg, 'ID00000002', :act, :act, :exp2, :act, '0.00000692',
                   '0.00000000', 1, :arch)
                """
            ),
            {
                "tg": tg_id,
                "act": act,
                "exp1": exp_active,
                "exp2": exp_arch,
                "arch": fixed_now,
            },
        )
        await db.commit()

    async with Session() as db:
        active = await panels_service.list_user_panels(
            db,
            tg_id=tg_id,
            kind="active",
            limit=10,
            cursor=None,
        )
        archive = await panels_service.list_user_panels(
            db,
            tg_id=tg_id,
            kind="archive",
            limit=10,
            cursor=None,
        )

        assert len(active.items) == 1
        assert active.items[0]["public_id"] == "ID00000001"
        assert bool(active.items[0]["is_active"]) is True

        assert len(archive.items) == 1
        assert archive.items[0]["public_id"] == "ID00000002"
        assert bool(archive.items[0]["is_active"]) is False

    await engine.dispose()
