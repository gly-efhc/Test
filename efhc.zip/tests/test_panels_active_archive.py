from __future__ import annotations

import pytest
from sqlalchemy import text

from tests.panels_testkit import (
    reload_panels_service,
    seed_user_with_balances,
)

pytestmark = pytest.mark.asyncio


async def test_panels_active_then_archive_flow(
    db_session,
    db_clean,
) -> None:
    ps = reload_panels_service()
    tg_id = 3002

    await seed_user_with_balances(
        db_session,
        tg_id=tg_id,
        main_balance="200.0",
    )

    out = await ps.create_panel_for_user(
        db_session, tg_id=tg_id, idempotency_key="p1"
    )
    await db_session.commit()

    # Panel should exist and be active initially
    r = await db_session.execute(
        text(
            "SELECT id, is_archived FROM efhc_core.panels WHERE "
            "id=:pid"
        ),
        {"pid": int(out["id"])},
    )
    row = r.fetchone()
    assert row is not None
    assert bool(row[1]) is False

    # Archive via service if available; otherwise simulate archive
    # field update
    if hasattr(ps, "archive_panel_for_user"):
        await ps.archive_panel_for_user(
            db_session, tg_id=tg_id, panel_id=int(out["id"])
        )
    else:
        await db_session.execute(
            text(
                "UPDATE efhc_core.panels SET is_archived=TRUE WHERE "
                "id=:pid"
            ),
            {"pid": int(out["id"])},
        )
    await db_session.commit()

    r2 = await db_session.execute(
        text("SELECT is_archived FROM efhc_core.panels WHERE id=:pid"),
        {"pid": int(out["id"])},
    )
    row2 = r2.fetchone()
    assert row2 is not None
    assert bool(row2[0]) is True
