from __future__ import annotations

import importlib

import pytest
from sqlalchemy import text


def _reload_panels_service():
    # Reload panels service to pick up canon env
    # (efhc_core/efhc_admin) from conftest
    from app.core import config_core
    config_core.get_settings.cache_clear()
    import app.services.panels_service as ps
    ps = importlib.reload(ps)
    return ps


@pytest.mark.asyncio
async def test_panels_active_then_archive_flow(
    db_session,
    db_clean,
) -> None:
    ps = _reload_panels_service()
    tg_id = 3002

    await db_session.execute(
        text(
            'INSERT INTO efhc_core.users (tg_id, main_balance, '
            'bonus_balance) VALUES (:tg, 200.0, 0.0)'
        ),
        {"tg": tg_id},
    )
    await db_session.commit()

    out = await ps.create_panel_for_user(db_session, tg_id=tg_id, idempotency_key="p1")
    await db_session.commit()

    # Panel should exist and be active initially
    r = await db_session.execute(
        text(
            'SELECT id, is_archived FROM efhc_core.panels WHERE '
            'id=:pid'
        ),
        {"pid": int(out["id"])},
    )
    row = r.fetchone()
    assert row is not None
    assert bool(row[1]) is False

    # Archive via service if available; otherwise simulate archive
    # field update
    if hasattr(ps, "archive_panel_for_user"):
        await ps.archive_panel_for_user(db_session, tg_id=tg_id, panel_id=int(out["id"]))
    else:
        await db_session.execute(
            text(
                'UPDATE efhc_core.panels SET is_archived=TRUE WHERE '
                'id=:pid'
            ),
            {"pid": int(out["id"])},
        )
    await db_session.commit()

    r2 = await db_session.execute(
        text("SELECT is_archived FROM efhc_core.panels WHERE id=:pid"),
        {"pid": int(out["id"])},
    )
    row2 = r2.fetchone()
    assert row2 is not None
    assert bool(row2[0]) is True
