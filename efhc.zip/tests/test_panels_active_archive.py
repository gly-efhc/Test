from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timedelta, timezone

import pytest

def _get_async_db_url() -> str:
    db_url = os.getenv("DATABASE_URL") or os.getenv("ASYNC_DATABASE_URL")
    if not db_url:
        pytest.skip("DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    # forbid sqlite in canon
    if db_url.startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to async psycopg driver for SQLAlchemy
    if db_url.startswith("postgresql://"):
        return "postgresql+psycopg://" + db_url[len("postgresql://"):]
    if db_url.startswith("postgres://"):
        return "postgresql+psycopg://" + db_url[len("postgres://"):]
    if db_url.startswith("postgresql+psycopg://"):
        return db_url
    return db_url


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    # SQLite is forbidden in Postgres-only CI canon
    pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return


def _reload_panels_service_for_sqlite():
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core

    importlib.reload(config_core)
    from backend.app.services import panels_service

    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_active_archive_classification_by_server_now() -> None:
    panels_service = _reload_panels_service_for_sqlite()

    fd, path = tempfile.mkstemp(prefix="efhc_panels_kind_", suffix=".db")
    os.close(fd)
    db_url = _get_async_db_url()

    fixed_now = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
    panels_service.utcnow = lambda: fixed_now  # type: ignore

    try:
        await _init_sqlite_schema(db_url)
        engine = create_async_engine(
            db_url,
            future=True,

        )
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        tg_id = 4001

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO efhc_core.users (tg_id, main_balance, bonus_balance)
                    VALUES (:tg, 0.0, 0.0)
                    """
                ),
                {"tg": tg_id},
            )

            # panel 1: active (expires after server_now)
            act = fixed_now - timedelta(days=1)
            exp_active = fixed_now + timedelta(days=1)
            # panel 2: archive (expires at/before server_now)
            exp_arch = fixed_now

            await db.execute(
                text(
                    """
                    INSERT INTO efhc_core.panels (
                        tg_id,
                        public_id,
                        activated_at,
                        created_at,
                        expires_at,
                        last_generated_at,
                        base_gen_per_sec,
                        generated_kwh,
                        is_active,
                        archived_at
                    )
                    VALUES
                      (:tg, 'ID00000001', :act, :act, :exp1, :act, 0.00000692,
                       0, 1, NULL),
                      (:tg, 'ID00000002', :act, :act, :exp2, :act, 0.00000692,
                       0, 1, :arch)
                    """
                ),
                {
                    "tg": tg_id,
                    "act": act.isoformat(),
                    "exp1": exp_active.isoformat(),
                    "exp2": exp_arch.isoformat(),
                    "arch": fixed_now.isoformat(),
                },
            )
            await db.commit()

        async with Session() as db:
            active = await panels_service.list_user_panels(
                db,
                tg_id=tg_id,
                kind="active",
                limit=10,
                cursor=None,
            )
            archive = await panels_service.list_user_panels(
                db,
                tg_id=tg_id,
                kind="archive",
                limit=10,
                cursor=None,
            )

            assert len(active.items) == 1
            assert active.items[0]["public_id"] == "ID00000001"
            assert bool(active.items[0]["is_active"]) is True

            assert len(archive.items) == 1
            assert archive.items[0]["public_id"] == "ID00000002"
            assert bool(archive.items[0]["is_active"]) is False

        await engine.dispose()
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
