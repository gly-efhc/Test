# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path


def test_no_new_per_sec_literals_outside_ssot_sources() -> None:
    repo = Path(__file__).resolve().parents[1]
    needles = {"0.00000692", "0.00000741"}

    allowed_suffixes = {
        str(Path("backend/app/core/config_core.py")),
        str(Path("backend/app/core/system_locks.py")),
    }

    hits: list[str] = []
    for p in repo.rglob("*.py"):
        rel = str(p.relative_to(repo))
        if rel.startswith("tests/"):
            continue
        if rel.startswith("reports/"):
            continue
        txt = p.read_text(encoding="utf-8")
        if any(n in txt for n in needles):
            if rel not in allowed_suffixes:
                hits.append(rel)

    assert hits == [], f"Unexpected literals in: {hits}"