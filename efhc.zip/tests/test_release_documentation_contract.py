"""Контракты release-документации и schema freeze policy."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_install_uses_persistent_env_template() -> None:
    install = (ROOT / "release_docs/INSTALL.md").read_text(encoding="utf-8")
    assert ".env.example" in install
    assert "/opt/efhc/shared/.env" in install
    assert "chmod 600" in install


def test_update_document_is_generic() -> None:
    update = (ROOT / "release_docs/UPDATE_AND_ROLLBACK.md").read_text(
        encoding="utf-8"
    )
    assert "TARGET_RELEASE.zip" in update
    assert "TARGET_RELEASE.zip.sha256" in update


def test_update_policy_declares_cutover_preparation_lineage() -> None:
    policy = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )
    assert policy["schema"] == "EFHC_RELEASE_UPDATE_POLICY_V4"
    assert policy["update_policy"] == "pre_release_schema_freeze"
    assert policy["supported_database_revisions"] == ["0001", "0002"]
    assert policy["target_database_revision"] == "0002"
    assert policy["database_migration_policy"] == (
        "cumulative_release_migrations"
    )
    assert policy["rollback_database_policy"] == (
        "alembic_downgrade_or_snapshot"
    )
    rollback = policy["rollback_compatibility"]
    assert rollback["application_rollback_supported"] is False
    assert rollback["database_restore_required"] is False
