from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAGE = ROOT / "frontend/src/features/browser-shop/BrowserShopPage.tsx"
ADMIN = ROOT / "frontend/src/pages/admin/diagnostics.tsx"
LOCALE_DIR = ROOT / "frontend/public/locale"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_browser_shop_public_page_has_no_operator_blocks() -> None:
    src = _read(PAGE)
    forbidden = [
        "SurfaceFactsStrip",
        "TelegramSearchBar",
        "TelegramCategoryPills",
        "TelegramSectionRow",
        "paymentChainFacts",
        "customAmount",
        "activeCategory",
        "activePackage",
        "copyText",
        "maskWallet",
    ]
    for marker in forbidden:
        assert marker not in src


def test_storefront_cards_hide_admin_and_payment_fields() -> None:
    src = _read(PAGE)
    forbidden = [
        "Copy wallet",
        "Copy memo",
        "Payment chain facts",
        'title="SKU"',
        'title="Type"',
        'title="USDT jetton"',
        "selectedItem.sku",
        "item.item_type",
        "create_ton_intent",
    ]
    for marker in forbidden:
        assert marker not in src

    assert "portal.browser_shop.pay_button" in src
    assert "wallet.transaction_failed" in src
    assert "wallet.transaction_rejected" in src
    assert "useBrowserShopIntentStatus" in src
    assert "useBrowserShopAccessKey" in src
    assert 'data-browser-shop-linking="telegram-web-return"' in src
    assert "efhc-browser-shop-trust-rail" not in src


def test_browser_shop_diagnostics_are_admin_only() -> None:
    admin = _read(ADMIN)
    assert "Browser-Shop payment diagnostics" in admin
    assert "/shopfront/create-intent" in admin
    assert "/shopfront/intent-status" in admin
    assert "wallet and memo · hidden from public UI" in admin


def test_clean_storefront_locale_keys_exist() -> None:
    keys = {
        "portal.browser_shop.clean_subtitle",
        "portal.browser_shop.pay_button",
        "portal.browser_shop.payment_pending_title",
        "portal.browser_shop.payment_pending_detail",
        "portal.browser_shop.payment_pending_badge",
        "portal.browser_shop.payment_checking_title",
        "portal.browser_shop.payment_checking_detail",
        "portal.browser_shop.payment_checking_badge",
        "portal.browser_shop.payment_error_title",
        "portal.browser_shop.payment_error_badge",
        "portal.browser_shop.wallet_open_failed",
    }
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in keys:
            assert data.get(key), path.name
