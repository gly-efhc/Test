from pathlib import Path


def test_admin_panel_limit_counts_only_active() -> None:
    path = Path("backend/app/services/admin/admin_panels_service.py")
    text = path.read_text(encoding="utf-8")
    assert "_count_user_active_panels" in text
    assert "_count_user_panels(db, req.tg_id)" not in text
