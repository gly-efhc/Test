from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_runtime_port_docs_and_report_exist() -> None:
    required = [
        "docs/NORM/PANELS_PORTFOLIO_RUNTIME_PORT.md",
        "docs/NORM/PANELS_PORTFOLIO_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1472_PANELS_PORTFOLIO_RUNTIME_PORT.md",
        "reports/generated/panels_portfolio_runtime_port_v170_48.json",
        "reports/change_cycle_2026-06-07_v170_48_cycle_1472_panels_portfolio_runtime_port.md",
        "tests/architecture/test_panels_portfolio_runtime_port.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_declares_safe_boundaries() -> None:
    data = json.loads(
        read("reports/generated/panels_portfolio_runtime_port_v170_48.json")
    )
    assert data["cycle"] == 1472
    assert data["archive_version"] == "v170.48"
    assert data["truth_model"] == "raw + derived snapshot"
    assert data["synthetic_runtime_data"] is False
    assert data["real_timeseries_claimed"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["panel_lifetime_days"] == 180


def test_runtime_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx")
    required = [
        "data-panels-portfolio-runtime-port=\"1472\"",
        "data-panels-portfolio-data-kind=\"raw-derived\"",
        "data-panels-portfolio-source=\"panels-summary-and-panel-list\"",
        "data-panels-portfolio-write-flow=\"false\"",
        "data-panel-lifetime-days=\"180\"",
        "data-grafana-reference-only=\"true\"",
        "data-sandbox-reference-only=\"true\"",
        "PANEL_LIFETIME_SECONDS = 180 * 86400",
        "panelsPortfolioRuntimeVersion",
    ]
    for marker in required:
        assert marker in src


def test_runtime_component_is_display_only() -> None:
    src = read("frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "newIdempotencyKey",
        "POST",
        "/panels/activate",
        "telegramMainButtonSet",
        "confirm(",
        "toast(",
    ]
    for marker in forbidden:
        assert marker not in src


def test_runtime_component_uses_raw_and_derived_not_synthetic() -> None:
    src = read("frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx")
    assert "dataKind=\"raw\"" in src
    assert "dataKind=\"derived\"" in src
    assert "synthetic" not in src.lower()
    assert "real_timeseries" not in src
    assert "TimeSeries" not in src


def test_live_panels_route_uses_cycle_1556_replacement() -> None:
    src = read("frontend/src/pages/panels.tsx")
    mapping = read(
        "docs/frontend/"
        "FRONTEND_PANELS_EXCHANGE_MVP_REPLACEMENT_MAPPING.md"
    )
    assert "PanelsPortfolioRuntime" not in src
    assert "PublicPanelsActivationPreview" not in src
    assert "usePanelsList" in src
    assert "usePanelsSummary" in src
    assert "usePanelActivation" in src
    assert 'data-panels-mvp-activation="cycle-1556"' in src
    assert 'data-panel-activation-cta="100-efhc"' in src
    assert "INACTIVE_LEGACY_REFERENCE" in mapping


def test_runtime_port_does_not_remove_sandbox_component() -> None:
    assert (ROOT / "frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx").exists()
    sandbox = read("frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx")
    assert "data-panels-portfolio-sandbox-prototype=\"1471\"" in sandbox
    assert "data-panels-portfolio-preview-only=\"true\"" in sandbox


def test_locales_have_runtime_labels() -> None:
    keys = [
        "panels.portfolio_runtime_title",
        "panels.portfolio_runtime_subtitle",
        "panels.portfolio_state_filter",
        "panels.portfolio_no_write_actions",
        "panels.portfolio_snapshot_only",
    ]
    for lang in ("ru", "en", "uk", "de", "fr", "es", "it", "tr", "pl", "da", "hi", "id", "sw"):
        data = json.loads(read(f"frontend/public/locale/{lang}.json"))
        for key in keys:
            assert key in data
            assert data[key]


def test_navigation_and_kernel_are_updated() -> None:
    kernel = read("KERNEL.md")
    nav = read("map_element.md")
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "Operator Kernel" in kernel
    for text in (nav, routes):
        assert "Panels Portfolio Runtime Port" in text
        assert "1472" in text
        assert "PanelsPortfolioRuntime" in text
    assert "1473 — Panel Cards Deep Polish" in nav
    assert "1473 — Panel Cards Deep Polish" in nav


def test_grafana_and_sandbox_boundaries_are_documented() -> None:
    docs = (
        read("docs/NORM/PANELS_PORTFOLIO_RUNTIME_PORT.md")
        + read("docs/NORM/PANELS_PORTFOLIO_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница" in docs
    assert "No Grafana source code is copied" in docs
