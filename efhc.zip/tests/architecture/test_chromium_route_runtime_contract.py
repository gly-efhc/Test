"""Контракт исправления real Chromium route-backed qualification."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_telegram_sdk_разрешён_точным_csp_origin() -> None:
    config = _read("frontend/next.config.js")
    document = _read("frontend/src/pages/_document.tsx")
    assert 'src="https://telegram.org/js/telegram-web-app.js"' in document
    assert '"https://telegram.org"' in config
    assert "script-src 'self' 'unsafe-inline' 'unsafe-eval'" in config


def test_system_routes_имеют_явные_expected_status() -> None:
    manifest = json.loads(
        _read("ops/frontend/all_pages_visual_manifest_v171_88.json")
    )
    statuses = {
        item["route"]: item.get("expected_status")
        for item in manifest["system_routes"]
    }
    assert statuses == {"/404": 404, "/500": 500}
    assert "expected_http_status" in manifest["checks"]
    assert "http_status_below_500" not in manifest["checks"]


def test_route_audit_не_скрывает_неожиданный_status() -> None:
    audit = _read(
        "ops/frontend/all_pages_route_backed_visual_audit.py"
    )
    assert 'item.get("expected_status", 200)' in audit
    assert "status_code == expected_status" in audit
    assert '"expected_http_status": expected_status' in audit
    assert "expected_status in {404, 500}" in audit


def test_ci_build_создаёт_реальный_admin_allowlist_context() -> None:
    workflow = _read("ci.yml")
    assert 'NEXT_PUBLIC_ADMIN_TG_IDS: "1"' in workflow
    assert "Chromium visual audit" in workflow
    assert "all_pages_route_backed_visual_audit.py" in workflow


def test_admin_guard_ждёт_server_side_access_resolution() -> None:
    app = _read("frontend/src/pages/_app.tsx")
    admin_client = _read("frontend/src/lib/admin.ts")
    assert "fetchAdminAccess" in app
    assert '"checking" | "allowed" | "denied"' in app
    assert 'const adminGuardCanDecide = adminAccessState !== "checking";' in app
    assert "ADMIN_ACCESS_PATH" in admin_client
    assert "providerIdentityResolved" not in app



def test_route_audit_использует_только_локальный_browser_proof() -> None:
    app = _read("frontend/src/pages/_app.tsx")
    harness = _read("ops/frontend/admin_visual_button_click_proof.py")
    assert "__EFHC_ADMIN_PROOF_PATH__" in harness
    assert "window.location.pathname.startsWith('/admin')" in harness
    assert "window.navigator.webdriver" in app
    assert '["127.0.0.1", "localhost", "::1"]' in app
    assert "configuredProof || localAutomationProof" in app
