from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVICE = (
    ROOT / "backend/app/services/admin/admin_withdrawals_service.py"
)
LIVE_FUNCS = [
    "list_withdrawals",
    "approve_withdrawal",
    "reject_withdrawal",
]
LEGACY_FUNCS = [
    "list_bonus_awards",
    "process_bonus_award",
    "reject_bonus_award",
]


def _source() -> str:
    return SERVICE.read_text(encoding="utf-8")


def _functions() -> dict[str, ast.AsyncFunctionDef | ast.FunctionDef]:
    tree = ast.parse(_source())
    out: dict[str, ast.AsyncFunctionDef | ast.FunctionDef] = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)):
            out[node.name] = node
    return out


def _function_source(name: str) -> str:
    func = _functions()[name]
    lines = _source().splitlines()
    assert func.end_lineno is not None
    return "\n".join(lines[func.lineno - 1: func.end_lineno])


def test_cycle1519_live_withdraw_paths_have_no_bonus_guard() -> None:
    forbidden = [
        "_legacy_bonus_awards_table_exists",
        "_ensure_legacy_bonus_awards_table",
        "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE",
    ]
    for name in LIVE_FUNCS:
        body = _function_source(name)
        for marker in forbidden:
            assert marker not in body, name


def test_cycle1519_bonus_guard_only_exists_in_legacy_paths() -> None:
    legacy_chunks = [_function_source(name) for name in LEGACY_FUNCS]
    legacy_text = "\n".join(legacy_chunks)
    assert "_legacy_bonus_awards_table_exists" in legacy_text
    assert "_ensure_legacy_bonus_awards_table" in legacy_text
    assert "bonus_awards" in legacy_text


def test_cycle1519_list_withdrawals_returns_withdraw_requests() -> None:
    body = _function_source("list_withdrawals")
    assert "AdminCommonCrud.fetch_all" in body
    assert ".withdraw_requests" in body
    assert "return out" in body
    assert "return []" not in body
