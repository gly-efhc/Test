from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_energy_headline_and_chips_preserve_exact_numbers() -> None:
    page = read("frontend/src/pages/index.tsx")
    css = read("frontend/src/styles/globals.css")
    assert 'data-energy-value-safe="true"' in page
    assert "const base = 38;" in page
    assert "return clamp(base - cut, 21, 38);" in page
    assert "{shownRate}" in page
    assert "{shownAvailable}" in page
    assert "overflow:visible;" in css
    assert "text-overflow:clip;" in css
    assert "letter-spacing:-0.035em;" in css
