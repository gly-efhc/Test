from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_shop_payment_truth_guard_1191() -> None:
    script = ROOT / "ops/routes/check_shop_payment_truth.py"
    result = subprocess.run(
        [sys.executable, str(script)],
        cwd=ROOT,
        check=False,
        text=True,
        capture_output=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(
        (ROOT / "reports/generated/shop_payment_truth.json").read_text(
            encoding="utf-8"
        )
    )
    assert data["all_required_present"] is True
