from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TX_SERVICE = ROOT / "backend/app/services/transactions_service.py"
EXCHANGE_SERVICE = ROOT / "backend/app/services/exchange_service.py"
WITHDRAW_SERVICE = ROOT / "backend/app/services/withdraw_service.py"
REPAIR_DOC = ROOT / "docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_REPAIR.md"
BOUNDARY_MAP = ROOT / "docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_MAP.md"
CYCLE_LOG = ROOT / "docs/cycles/WORK_CYCLES.md"


def _function_slice(content: str, marker: str, next_marker: str) -> str:
    start = content.index(marker)
    end = content.index(next_marker, start)
    return content[start:end]


def test_core_money_tx_context_is_service_owned_not_hidden_savepoint() -> None:
    content = TX_SERVICE.read_text(encoding="utf-8")
    helper = _function_slice(
        content,
        "async def _tx_context(db: AsyncSession):",
        "settings = get_settings()",
    )

    assert "@contextlib.asynccontextmanager" in content
    assert "yield" in helper
    assert "await db.commit()" in helper
    assert "await db.rollback()" in helper
    assert "db.begin_nested" not in helper
    assert "return db.begin_nested" not in helper


def test_exchange_preflight_closes_read_only_autobegin_before_money_service(
) -> None:
    content = EXCHANGE_SERVICE.read_text(encoding="utf-8")
    marker = "before_state = await _read_user_exchange_state"
    service_call = "exchange_partial_available_kwh_to_main("
    slice_ = content[content.index(marker):content.index(service_call)]

    assert "HEAL-0018" in slice_
    assert "db.in_transaction()" in slice_
    assert "await db.rollback()" in slice_


def test_heal0018_repair_is_documented_after_1409_map() -> None:
    repair = REPAIR_DOC.read_text(encoding="utf-8")
    boundary_map = BOUNDARY_MAP.read_text(encoding="utf-8")
    cycles = CYCLE_LOG.read_text(encoding="utf-8")

    assert "1410" in cycles
    assert "HEAL-0018 transaction-boundary repair" in cycles
    assert "begin_nested()" in repair
    assert "service-owned" in repair
    assert "transactions_service.py" in repair
    assert "exchange_service.py" in repair
    assert "NO_RUNTIME_BOUNDARY_REWRITE_IN_1409" in boundary_map


def test_withdraw_request_hold_is_single_atomic_boundary() -> None:
    content = WITHDRAW_SERVICE.read_text(encoding="utf-8")
    request_slice = _function_slice(
        content,
        "async def request_withdraw(",
        "async def cancel_withdraw",
    )

    assert "HEAL-0024" in request_slice
    assert "async with _tx_context(db):" in request_slice
    assert "debit_user_to_bank_nocommit(" in request_slice
    assert "hold_done = TRUE" in request_slice
    assert "debit_user_to_bank(" not in request_slice
    assert "db.begin_nested" not in request_slice


def test_transactions_service_exposes_no_commit_withdraw_hold_helper() -> None:
    content = TX_SERVICE.read_text(encoding="utf-8")
    helper = _function_slice(
        content,
        "async def debit_user_to_bank_nocommit(",
        "async def debit_user_bonus_to_bank",
    )

    assert "HEAL-0024" in helper
    assert "caller owns" in helper.lower()
    assert "await db.commit()" not in helper
    assert "await db.rollback()" not in helper
    assert "_insert_log(" in helper
