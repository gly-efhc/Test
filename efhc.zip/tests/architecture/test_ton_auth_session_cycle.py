"""Архитектурные границы цикла 1618."""

from __future__ import annotations

from pathlib import Path

from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_cycle_1618_имеет_exact_operator_kernel_route() -> None:
    classified = classify_task(
        "Цикл 1618 TON auth session logout closure"
    )
    assert classified["task_type"] == "ton_auth_session_closure"
    route = resolve_route("ton_auth_session_closure", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "ton_auth_session_closure"


def test_cycle_1618_использует_единую_release_schema_0001() -> None:
    migrations = ROOT / "backend/migrations/versions"
    assert sorted(path.name for path in migrations.glob("*.py")) == [
        "0001_initial_release_schema.py",
    ]
    source = (migrations / "0001_initial_release_schema.py").read_text(
        encoding="utf-8"
    )
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source


def test_ton_proof_response_содержит_session_без_tg_id() -> None:
    schema = _read("backend/app/schemas/auth_ton_schemas.py")
    route = _read("backend/app/routes/auth_ton_routes.py")
    assert "session: AuthSessionCredentialOut" in schema
    assert "access_token" in schema
    assert "TonAuthSessionService" in route
    assert "get_ton_auth_session_service" in route
    assert "tg_id" not in route
