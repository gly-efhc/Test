"""Fail-closed tests security/audit identity цикла 1703."""

from __future__ import annotations

from ops.identity.check_security_audit_identity import build_report


def test_privileged_и_audit_owner_используют_global_id() -> None:
    report = build_report()
    assert report["status"] == "PASS", report
    assert report["checks"]["admin_bank_financial_owner_is_global_id"] is True
    assert report["checks"]["privileged_jwt_has_no_tg_id_owner_fallback"] is True
    assert report["checks"]["provider_subject_fields_are_redacted"] is True
