from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_admin_withdraw_preview_route_and_page_exist() -> None:
    route = _read("backend/app/routes/admin_withdrawals_routes.py")
    page = _read("frontend/src/pages/admin/withdrawals.tsx")
    assert "/{request_id}/outcome-preview" in route
    assert "Outcome preview" in page
    assert "ADMIN_WITHDRAW_OUTCOME_PREVIEW_PATH" in page


def test_web_profile_latest_outcome_surface_exists() -> None:
    schema = _read("backend/app/schemas/hub_schemas.py")
    route = _read("backend/app/routes/shopfront_routes.py")
    page = _read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    ) + _read(
        "frontend/src/components/profile/ProfileHistorySection.tsx"
    )
    assert "latest_withdraw_outcome" in schema
    assert "latest_withdraw_outcome" in route
    assert "data-history-data-contract" in page
