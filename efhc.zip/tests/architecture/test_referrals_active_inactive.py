from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LIST_PAGE = (
    ROOT / "frontend/src/components/referrals/ReferralListPage.tsx"
)
LIB = ROOT / "frontend/src/services/referrals.service.ts"
ROUTES = ROOT / "backend/app/routes/referrals_routes.py"
LOCALES = ROOT / "frontend/public/locale"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_referrals_active_inactive_boundary_marker_exists() -> None:
    src = read(LIST_PAGE)
    marker = 'data-referrals-active-inactive-boundary="1296"'
    assert marker in src
    assert 'data-referral-row="username-only"' in src


def test_referrals_list_does_not_render_tg_id_fallback() -> None:
    src = read(LIST_PAGE)
    banned = [
        "String(item.child_tg_id)",
        "item.tg_id",
        "{{id}}",
        "child_tg_id}</div>",
    ]
    for token in banned:
        assert token not in src
    assert "referrals.user_hidden_fallback" in src


def test_referrals_lists_use_current_user_routes() -> None:
    src = read(LIB)
    assert '"/referrals/active/me"' in src
    assert '"/referrals/inactive/me"' in src
    assert "parent_tg_id" not in src


def test_backend_has_current_user_referral_list_routes() -> None:
    src = read(ROUTES)
    assert '"/active/me"' in src
    assert '"/inactive/me"' in src
    assert "def get_my_referrals_active" in src
    assert "def get_my_referrals_inactive" in src


def test_new_referral_locale_keys_exist_everywhere() -> None:
    required = [
        "referrals.share_link",
        "referrals.user_hidden_fallback",
        "referrals.panels_count_label",
    ]
    for path in LOCALES.glob("*.json"):
        src = read(path)
        for key in required:
            assert f'"{key}"' in src, path.name


def test_cycle_1296_docs_are_registered() -> None:
    docs = read(PLAN) + "\n" + read(REPORTS)
    assert "v168_92 / work pass" in docs
    assert "active/inactive referrals" in docs
    assert "test_referrals_active_inactive.py" in docs
