from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALES = ROOT / "frontend" / "public" / "locale"
EXPECTED_LOCALES = {
    "da",
    "de",
    "en",
    "es",
    "fr",
    "hi",
    "id",
    "it",
    "pl",
    "ru",
    "sw",
    "tr",
    "uk",
}
PUBLIC_DASHBOARD_PREFIXES = (
    "energy.dashboard_",
    "exchange.dashboard_",
    "panels.card_",
    "panels.duration_",
    "panels.portfolio_",
    "profile.dashboard_",
    "ranks.dashboard_",
    "ranks.leaderboard_",
    "referrals.dashboard_",
    "tasks.dashboard_",
)
FORBIDDEN_PLACEHOLDER_PREFIXES = (
    "Локализовано:",
    "Локалізовано:",
    "Lokalisiert:",
    "Localizado:",
    "Localisé:",
    "Localizzato:",
    "Lokaliseret:",
    "Yerelleştirilmiş:",
    "Zlokalizowano:",
    "स्थानीयकृत:",
    "Dilokalkan:",
    "Imetafsiriwa:",
)
PUBLIC_RUNTIME_FILES = (
    "frontend/src/components/dashboard/EnergyDashboardRuntime.tsx",
    "frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx",
    "frontend/src/components/dashboard/RanksDashboardRuntime.tsx",
    "frontend/src/components/dashboard/TasksDashboardRuntime.tsx",
    "frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx",
    "frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx",
    "frontend/src/components/dashboard/WebProfileAccountDashboard.tsx",
    "frontend/src/components/dashboard/MiniCharts.tsx",
    "frontend/src/components/dashboard/ProgressSystem.tsx",
)
INLINE_TEXT_BLOCKLIST = (
    "Нет данных",
    "Завершено",
    "срока прошло",
    "Runtime energy split from sync snapshot",
    "Runtime energy activity signals",
    "derived from runtime snapshot",
    "derived from loaded panel records",
    "derived from current panel snapshot",
    "backend ranks snapshot",
    'label: "Snapshot"',
)


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def load_locale(name: str) -> dict[str, str]:
    return json.loads((LOCALES / f"{name}.json").read_text(encoding="utf-8"))


def public_dashboard_keys(data: dict[str, str]) -> set[str]:
    return {
        key
        for key in data
        if key.startswith(PUBLIC_DASHBOARD_PREFIXES)
    }


def test_cycle_1496_docs_reports_and_navigation_exist() -> None:
    required = [
        "docs/NORM/DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md",
        "docs/NORM/DASHBOARD_DIRECTION_HANDOFF_GRAFANA_ELEMENT_ANALYSIS.md",
        (
            "docs/cycles/WORK_CYCLES_1496_DASHBOARD_DIRECTION_"
            "HANDOFF_BACKLOG_FREEZE.md"
        ),
        "reports/generated/dashboard_direction_handoff_backlog_freeze_v170_72.json",
        (
            "reports/change_cycle_2026-06-10_v170_72_cycle_1496_"
            "dashboard_direction_handoff_backlog_freeze.md"
        ),
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel

    joined = "\n".join(
        read(path)
        for path in (
            "KERNEL.md",
            "map_element.md",
            "ops/operator_kernel/config/routes.yaml",
            "reports/REPORTS_INDEX.md",
        )
    )
    assert "1496 — Dashboard Direction Handoff / Backlog Freeze" in joined
    assert "DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md" in joined


def test_public_user_dashboard_locale_parity_is_thirteen_languages() -> None:
    actual = {path.stem for path in LOCALES.glob("*.json")}
    assert actual == EXPECTED_LOCALES

    en = load_locale("en")
    en_keys = set(en)
    en_public_dashboard_keys = public_dashboard_keys(en)
    assert en_public_dashboard_keys
    assert "panels.duration_days_short" in en_public_dashboard_keys
    assert "panels.portfolio_runtime_title" in en_public_dashboard_keys
    assert "ranks.leaderboard_podium" in en_public_dashboard_keys

    for locale in EXPECTED_LOCALES:
        data = load_locale(locale)
        assert set(data) == en_keys
        assert public_dashboard_keys(data) == en_public_dashboard_keys


def test_public_dashboard_locale_values_have_no_placeholder_prefixes() -> None:
    offenders: list[str] = []
    for locale in EXPECTED_LOCALES:
        data = load_locale(locale)
        for key, value in data.items():
            if not key.startswith(PUBLIC_DASHBOARD_PREFIXES):
                continue
            if not isinstance(value, str) or not value.strip():
                offenders.append(f"{locale}:{key}:empty")
                continue
            if any(
                value.startswith(prefix)
                for prefix in FORBIDDEN_PLACEHOLDER_PREFIXES
            ):
                offenders.append(f"{locale}:{key}:{value}")
    assert offenders == []


def test_public_runtime_dashboards_do_not_expose_known_inline_fallbacks() -> None:
    offenders: list[str] = []
    cyrillic = re.compile(r"[А-Яа-яЁёІіЇїЄє]")
    for rel in PUBLIC_RUNTIME_FILES:
        text = read(rel)
        for item in INLINE_TEXT_BLOCKLIST:
            if item in text:
                offenders.append(f"{rel}:{item}")
        if rel.endswith(("Runtime.tsx", "MiniCharts.tsx", "ProgressSystem.tsx")) and cyrillic.search(text):
            offenders.append(f"{rel}:inline-cyrillic")
    assert offenders == []


def test_panel_countdown_duration_is_locale_driven() -> None:
    progress = read("frontend/src/components/dashboard/ProgressSystem.tsx")
    panels = read("frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx")
    page = read("frontend/src/pages/panels.tsx")

    assert "DashboardDurationLabels" in progress
    assert "durationLabels" in progress
    assert "elapsedLabel" in progress
    assert "props.completeLabel ?? \"100%\"" in progress
    assert "durationLabels={{" in panels
    assert "completeLabel={props.labels.durationComplete}" in panels
    assert "elapsedLabel={props.labels.durationElapsed}" in panels
    assert 't("common.day_short")' in page
    assert 't("panels.countdown_expired")' in page


def test_handoff_freezes_dashboard_direction_and_public_i18n_scope() -> None:
    doc = read("docs/NORM/DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md")
    assert "42 / 42" in doc
    assert "Every user-facing dashboard label" in doc
    assert "Admin dashboards are not declared as a 13-language public surface" in doc
    assert "VIS-03" in doc
    assert "GitHub CI green" in doc

    report = json.loads(
        read("reports/generated/dashboard_direction_handoff_backlog_freeze_v170_72.json")
    )
    assert report["dashboard_direction"]["done_after_cycle"] == 42
    assert report["dashboard_direction"]["remaining_after_cycle"] == 0
    assert report["public_dashboard_i18n"]["user_dashboard_surfaces_only"] is True
    assert report["public_dashboard_i18n"]["admin_dashboard_13_language_claimed"] is False


def test_grafana_and_sandbox_remain_reference_only_after_handoff() -> None:
    norm = read("docs/NORM/DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md")
    graf = read("docs/NORM/DASHBOARD_DIRECTION_HANDOFF_GRAFANA_ELEMENT_ANALYSIS.md")
    assert "Grafana was used only as visual-pattern/reference layer" in norm
    assert "Песочница was used only as reference/navigation/prototype layer" in norm
    assert "No Grafana runtime code" in graf
    assert "Песочница remains reference/navigation/prototype only" in graf
