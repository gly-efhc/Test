from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "reports/generated/scheduler_notify_facade_fix_v171_08.json"
NORM = ROOT / "docs/NORM/SCHEDULER_NOTIFY_FACADE_FIX_REPORT.md"
CYCLE = ROOT / "docs/cycles/WORK_CYCLES_1533_SCHEDULER_NOTIFY_FACADE_FIX.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _load(path: Path) -> dict:
    return json.loads(_read(path))


def test_cycle_1533_report_and_docs_exist() -> None:
    assert REPORT.exists()
    assert NORM.exists()
    assert CYCLE.exists()
    data = _load(REPORT)
    assert data["cycle"] == 1533
    assert data["input_head"] == "v171.07"
    assert data["output_head"] == "v171.08"
    assert data["release_ready_claimed"] is False


def test_cycle_1533_closes_audited_findings() -> None:
    data = _load(REPORT)
    closed = set(data["closed_findings"])
    required = {
        "P1-WITHDRAWALS-PROCESSOR-DOUBLE-BUG",
        "P1-REPORTS-DAILY-NOTIFY-GENERIC",
        "P2-DEAD-CODE-ADMIN-FACADE-APPROVE-WITHDRAW",
        "P2-DEAD-CODE-ADMIN-FACADE-REJECT-WITHDRAW",
        "P1-MYPY-SCOPE-STILL-REACTIVE",
    }
    assert required.issubset(closed)


def test_cycle_1533_navigation_updated() -> None:
    joined = "\n".join([_read(KERNEL), _read(MAP), _read(NORM), _read(CYCLE)])
    assert "v171_08 / v171.08" in joined
    assert "Scheduler Notify Fix" in joined
    assert "reports.daily" in joined
    assert "withdrawals.stale" in joined


def test_cycle_1533_runtime_boundaries_recorded() -> None:
    data = _load(REPORT)
    assert data["economy_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["wallet_flow_changed"] is False
    assert data["withdraw_business_logic_changed"] is False
    assert data["tonconnect_changed"] is False
    assert data["frontend_runtime_changed"] is False
