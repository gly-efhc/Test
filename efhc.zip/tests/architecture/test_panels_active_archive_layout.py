from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PANELS = ROOT / "frontend/src/pages/panels.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORT = (
    ROOT
    / "reports"
    / "change_cycle_2026-05-21_v168_77_cycle_1279_panels_layout.md"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_panels_active_archive_layout_markers_exist() -> None:
    src = read(PANELS)
    assert 'data-panels-layout="active-archive"' in src
    assert 'data-panels-list-mode="segmented"' in src
    assert 'data-panels-tabs="active-archive"' in src
    assert 'data-panels-tab-button="active"' in src
    assert 'data-panels-tab-button="archive"' in src
    assert "data-panels-list={tab}" in src
    assert "data-panel-card={tab}" in src


def test_panels_layout_does_not_use_public_tg_id_paths() -> None:
    src = read(PANELS)
    forbidden = [
        "/panels/${tg_id}",
        "/panels/{tg_id}",
        "/tasks/my/${tg_id}",
        "/tasks/claim/${tg_id}",
    ]
    for needle in forbidden:
        assert needle not in src
    assert '"/panels/active"' in src
    assert '"/panels/archive"' in src


def test_panels_tabs_are_equal_and_contained() -> None:
    css = read(CSS)
    assert ".efhc-panels-tabs > *" in css
    assert "min-height: 2.75rem;" in css
    assert "width: 100%;" in css
    assert ".efhc-panels-list-card" in css
    assert "overflow: hidden;" in css


def test_cycle_1279_is_documented() -> None:
    plan = read(PLAN)
    report = read(REPORT)
    assert "v168_77 — work pass" in plan
    assert "Panels active/archive layout" in plan
    assert "work pass" in report
    assert "active/archive segmented layout" in report
