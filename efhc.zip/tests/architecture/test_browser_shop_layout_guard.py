from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "frontend/src/pages/_app.tsx"
SHOP_LAYOUT = ROOT / "frontend/src/components/ShopLayout.tsx"
QNA = ROOT / "docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md"


def _text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_browser_shop_uses_shop_layout_exception() -> None:
    src = _text(APP)
    assert 'router.pathname === "/browser-shop"' in src
    assert "<ShopLayout" in src
    assert "<Layout" in src
    assert src.index("<ShopLayout") < src.index("<Layout")


def test_shop_layout_has_no_mini_app_shell_parts() -> None:
    src = _text(SHOP_LAYOUT)
    forbidden = [
        "GlobalHeader",
        "NavItem",
        "DepositModal",
        "efhc-nav",
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
    ]
    for marker in forbidden:
        assert marker not in src


def test_shop_layout_has_storefront_top_zone() -> None:
    src = _text(SHOP_LAYOUT)
    assert "efhc-shop-layout_topbar" in src
    assert "efhc-shop-layout_identity" in src
    assert "efhc-shop-layout_balance" in src
    assert "main_balance" in src
    assert "telegramAvatarUrl" in src
    assert "href={profileHref}" in src
    assert 'const profileHref = "/web-profile";' in src


def test_visual_qa_100_is_in__main__qna_register() -> None:
    src = _text(QNA)
    marker = "Q/A addendum — 2026-05-16 — visual UI audit 100 answers"
    assert marker in src
    assert src.count("## Visual Q/A ") == 100
    assert "Visual Q/A 001" in src
    assert "Visual Q/A 100" in src
