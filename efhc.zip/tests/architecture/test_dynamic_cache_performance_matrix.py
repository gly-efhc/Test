from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_dynamic_cache_is_versioned_and_financially_safe() -> None:
    sw = read("frontend/public/sw.js")
    build = read("frontend/scripts/generate-pwa-build.mjs")
    status = read("frontend/src/components/PwaRuntimeStatus.tsx")
    assert "pwa-build.json" in sw
    assert "build_id" in sw
    assert "max_entries" in sw
    assert "max_age_seconds" in sw
    assert "CACHE_PROGRESS" in sw
    assert "CACHE_COMPLETE" in sw
    assert "UPDATE_AVAILABLE" in sw
    assert "isProtectedPath" in sw
    for prefix in ("/api/", "/admin/", "/health", "/meta/"):
        assert prefix in sw
    assert "request.method !== \"GET\"" in sw
    assert "sha256" in build
    assert "financialRoute" in status
    assert "connectionAllowsPrefetch" in status
    assert "saveData" in status
    assert "resolveAdaptiveCachePolicy" in status
    assert "navigator.storage" in status
    assert 'type: "SET_CACHE_POLICY"' in status
    assert 'data.type === "SET_CACHE_POLICY"' in sw
    assert "runtimeCachePolicy" in sw
    assert "CACHE_POLICY_APPLIED" in sw
    assert "max_entries: 520" in status


def test_heavy_optional_features_are_outside_startup_path() -> None:
    app = read("frontend/src/pages/_app.tsx")
    ton = read(
        "frontend/src/lib/vendor/tonconnect-ui-react-compat.tsx"
    )
    layout = read("frontend/src/components/Layout.tsx")
    faq = read("frontend/src/hooks/faq/useFaqCatalog.ts")
    assert "SkinBackgroundController = dynamic" in app
    assert 'import("@tonconnect/sdk")' in ton
    assert 'import("../lib/sfx")' in layout
    assert 'fetch(`/faq/${lang}.json`' in faq
    assert "../data/faq/catalogs" not in faq


def test_performance_budget_and_vitals_contracts_exist() -> None:
    package = json.loads(read("frontend/package.json"))
    budgets = read("frontend/scripts/budgets.mjs")
    vitals = read("frontend/src/services/webVitals.service.ts")
    assert package["scripts"]["performance-budgets"]
    assert "postbuild" not in package["scripts"]
    assert package["scripts"]["release-assets:verify"]
    assert "brotliCompressSync" in budgets
    assert "gzipSync" in budgets
    for platform in (
        "telegram-android",
        "telegram-ios",
        "telegram-desktop",
        "browser-android",
        "browser-ios",
        "browser-desktop",
    ):
        assert platform in vitals
    assert "MAX_BUFFERED_METRICS" in vitals
    assert "NEXT_PUBLIC_WEB_VITALS_ENDPOINT" in vitals


def test_long_lists_use_browser_native_virtualization() -> None:
    styles = read("frontend/src/styles/globals.css")
    history = read(
        "frontend/src/components/profile/history/"
        "BalanceHistoryList.tsx"
    )
    withdrawals = read(
        "frontend/src/components/profile/history/"
        "WithdrawHistoryList.tsx"
    )
    logs = read(
        "frontend/src/components/admin/"
        "AdminLogsEventsDashboardRuntime.tsx"
    )
    assert "content-visibility: auto" in styles
    assert "contain-intrinsic-size" in styles
    assert "efhc-native-virtual-item" in history
    assert "efhc-native-virtual-item" in withdrawals
    assert "efhc-native-virtual-item" in logs


def test_responsive_image_variants_are_available() -> None:
    base = ROOT / "frontend/public/assets/efhc/responsive"
    variants = {
        (128, "webp"): "efhc_coin_128.webp",
        (128, "avif"): "efhc_coin_128.avif",
        (192, "webp"): "efhc_coin_192.webp",
        (192, "avif"): "efhc_coin_192.avif",
        (256, "webp"): "efhc_coin_256.webp",
        (256, "avif"): "efhc_coin_256.avif",
        (512, "webp"): "efhc_coin_512.webp",
        (512, "avif"): "efhc_coin_large.avif",
    }
    for filename in variants.values():
        target = base / filename
        assert target.exists()
        assert target.stat().st_size > 1_000
    offline = read("frontend/public/offline.html")
    assert 'type="image/avif"' in offline
    assert 'type="image/webp"' in offline
