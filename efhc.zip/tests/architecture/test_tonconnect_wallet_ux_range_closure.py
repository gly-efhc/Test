import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_range_closure_documents_exist_and_gate_next_cycles():
    assert (
        ROOT
        / "docs/frontend/TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/TONCONNECT_WALLET_UX_RANGE_CLOSURE_AUDIT_V169_54.md"
    ).exists()
    assert (
        ROOT
        / "reports/generated/tonconnect_wallet_ux_range_closure_v169_54.json"
    ).exists()
    work = read("docs/cycles/WORK_CYCLES.md")
    assert (
        "Current HEAD: `v169_54 / TonConnect Wallet UX range closure`"
        in work
    )
    assert (
        "Last completed: `1375` TonConnect /"
        " Wallet UX proof and range closure"
        in work
    )
    assert "1376+" in work and "new audit" in work


def test_generated_manifest_closes_range_without_runtime_claims():
    data = json.loads(
        read(
            "reports/generated/"
            "tonconnect_wallet_ux_range_closure_v169_54.json"
        )
    )
    assert data["version"] == "v169_54"
    assert data["cycle"] == "1375"
    assert data["range_status"] == "CLOSED"
    assert "1376+" in data["next_cycles"]
    assert any(
        item["area"] == "TonConnect provider"
        for item in data["proof_matrix"]
    )
    assert any(
        "no real TonConnect" in item for item in data["non_claims"]
    )


def test_tonconnect_wallet_static_sources_keep_expected_contracts():
    # The custom Next app shell lives in _app.tsx. The /app route is
    # only
    # a Telegram deep-link alias and must not duplicate the AppProps
    # shell,
    # otherwise Next prerender receives no Component prop and build
    # fails.
    app = read("frontend/src/pages/_app.tsx")
    app_shell_service = read("frontend/src/services/appShell.service.ts")
    app_alias = read("frontend/src/pages/app.tsx")
    helper = read("frontend/src/lib/tonconnect.ts")
    provider = read("frontend/src/lib/wallet-provider/WalletProvider.tsx")
    adapter = read(
        "frontend/src/lib/wallet-provider/adapters/TonConnectAdapter.ts"
    )
    deposit = read("frontend/src/components/DepositModal.tsx")
    shop = read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    wallet = read(
        "frontend/src/components/profile/ProfileWalletSection.tsx"
    )
    assert "buildTonConnectManifestUrl" in app
    assert "/api/tonconnect-manifest" in app_shell_service
    assert "<WalletProvider" in app
    assert "returnUrl={tcReturnUrl}" in app
    assert "twaReturnUrl" in provider
    assert "tonConnectLanguage(props.language)" in provider
    assert "tonConnectTheme(" in provider
    assert 'export { default } from "./index"' in app_alias
    assert "AppProps" not in app_alias
    assert "useTonConnectUI" not in app_alias
    for marker in [
        "prepareTonProof",
        "submitTonProofEnvelope",
        "bindVerifiedTonConnectWallet",
        "fetchTonConnectWallets",
        "waitTonConnectRestore",
        "disconnectTonConnect",
    ]:
        assert marker in helper
    assert "window.location.assign" not in deposit
    assert "window.open(" not in deposit
    assert "buildEfhcDirectDepositTx" in deposit
    assert "useWalletProvider" in deposit
    assert "sendTransaction(tx)" in deposit
    assert "isUserRejected" in deposit
    assert "normalizeTonConnectTx" in shop
    assert "useWalletProvider" in shop
    assert "sendTransaction(tx)" in shop
    assert "isUserRejected" in shop
    assert "sendTonConnectTransaction" in adapter
    assert "wallet.linked_wallets_count" in wallet
    assert "Ton Proof" in wallet


def test_operator_kernel_has_range_closure_route():
    routes = read("ops/operator_kernel/config/routes.yaml")
    classifier = read("ops/operator_kernel/task_classifier.py")
    resolver = read("ops/operator_kernel/route_resolver.py")
    for src in [routes, classifier, resolver]:
        assert "tonconnect_wallet_ux_range_closure" in src
    assert (
        "docs/frontend/TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md"
        in routes
    )
    assert (
        "reports/generated/"
        "tonconnect_wallet_ux_range_closure_v169_54.json"
        in resolver
    )


def test_product_filename_hygiene_is_preserved_for_new_doc():
    product_path = (
        "docs/frontend/TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md"
    )
    assert "1375" not in product_path
    assert "v169" not in product_path.lower()
