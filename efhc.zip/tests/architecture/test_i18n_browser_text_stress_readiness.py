import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = (
    ROOT
    / "ops"
    / "i18n"
    / "audit_i18n_browser_text_stress_readiness.py"
)
PLAN_DOC = (
    ROOT
    / "docs"
    / "frontend"
    / "I18N_BROWSER_TEXT_STRESS_SCREENSHOT_READINESS_PLAN.md"
)
AUDIT_DOC = (
    ROOT
    / "docs"
    / "audits"
    / "I18N_BROWSER_TEXT_STRESS_SCREENSHOT_READINESS_AUDIT_V169_64.md"
)
REPORT = (
    ROOT
    / "reports"
    / "generated"
    / "i18n_browser_text_stress_readiness_v169_64.json"
)
MAP = ROOT / "map_element.md"


def test_i18n_browser_text_stress_script_generates_planning_matrix():
    result = subprocess.run(
        [sys.executable, str(SCRIPT)],
        cwd=ROOT,
        text=True,
        capture_output=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["version"] == "v169_64"
    assert data["cycle"] == 1384
    assert (
        data["status"]
        == "SCREENSHOT_READINESS_PLAN_ONLY_NO_BROWSER_CAPTURE"
    )
    assert data["route_count"] == 14
    assert data["device_count"] == 3
    assert len(data["languages"]) == 13
    assert data["route_locale_device_combinations"] == 546
    assert data["claims"]["screenshots_captured"] is False
    assert data["claims"]["browser_visual_verdict"] is False


def test_i18n_browser_text_stress_docs_preserve_non_claims_and_sandbox_boundary():
    plan = PLAN_DOC.read_text(encoding="utf-8")
    audit = AUDIT_DOC.read_text(encoding="utf-8")
    map_text = MAP.read_text(encoding="utf-8")
    for text in [plan, audit, map_text]:
        assert (
            "no screenshots" in text.lower()
            or "no browser" in text.lower()
        )
        assert "sandbox" in text.lower()
    assert "no template English labels" in map_text
    assert (
        "no Vue/Solid/Nuxt/Vanilla runtime" in map_text
        or "No sandbox runtime" in audit
    )


def test_i18n_browser_text_stress_does_not_create_screenshot_claims():
    plan = PLAN_DOC.read_text(encoding="utf-8").lower()
    audit = AUDIT_DOC.read_text(encoding="utf-8").lower()
    forbidden_claims = [
        "screenshots captured: yes",
        "browser visual verdict: pass",
        "release-ready: pass",
    ]
    for phrase in forbidden_claims:
        assert phrase not in plan
        assert phrase not in audit
