from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVICE = (
    ROOT / "backend/app/services/admin/admin_withdrawals_service.py"
)
LEGACY_FUNCS = {
    "list_bonus_awards",
    "process_bonus_award",
    "reject_bonus_award",
}
LIVE_WITHDRAW_FUNCS = {
    "list_withdrawals",
    "approve_withdrawal",
    "reject_withdrawal",
}


def _source() -> str:
    return SERVICE.read_text(encoding="utf-8")


def _tree() -> ast.Module:
    return ast.parse(_source())


def _functions() -> dict[str, ast.AsyncFunctionDef | ast.FunctionDef]:
    funcs: dict[str, ast.AsyncFunctionDef | ast.FunctionDef] = {}
    for node in ast.walk(_tree()):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)):
            funcs[node.name] = node
    return funcs


def _calls(func: ast.AsyncFunctionDef | ast.FunctionDef) -> set[str]:
    names: set[str] = set()
    for node in ast.walk(func):
        if isinstance(node, ast.Call):
            target = node.func
            if isinstance(target, ast.Name):
                names.add(target.id)
            elif isinstance(target, ast.Attribute):
                names.add(target.attr)
    return names


def _function_source(name: str) -> str:
    funcs = _functions()
    func = funcs[name]
    lines = _source().splitlines()
    assert func.end_lineno is not None
    return "\n".join(lines[func.lineno - 1: func.end_lineno])


def test_проверка_bonus_awards_guard_forbidden_in_live_withdraw_flow() -> None:
    funcs = _functions()
    forbidden = {
        "_legacy_bonus_awards_table_exists",
        "_ensure_legacy_bonus_awards_table",
    }
    for name in LIVE_WITHDRAW_FUNCS:
        assert name in funcs
        assert _calls(funcs[name]).isdisjoint(forbidden), name
        body = _function_source(name)
        assert "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE" not in body


def test_проверка_list_withdrawals_has_no_bonus_awards_early_return() -> None:
    body = _function_source("list_withdrawals")
    assert "bonus_awards" not in body
    assert "return []" not in body
    assert "FROM " in body
    assert ".withdraw_requests" in body


def test_проверка_bonus_awards_sql_references_are_only_legacy_marked() -> None:
    funcs = _functions()
    offenders: list[str] = []
    for name in funcs:
        body = _function_source(name)
        if "bonus_awards" not in body:
            continue
        if name.startswith("_legacy_bonus_awards"):
            continue
        if name.startswith("_ensure_legacy_bonus_awards"):
            continue
        if name not in LEGACY_FUNCS:
            offenders.append(name)
    assert offenders == []


def test_проверка_legacy_bonus_awards_functions_are_guarded() -> None:
    funcs = _functions()
    assert "_legacy_bonus_awards_table_exists" in _calls(
        funcs["list_bonus_awards"]
    )
    for name in ["process_bonus_award", "reject_bonus_award"]:
        assert (
            "_ensure_legacy_bonus_awards_table"
            in _calls(funcs[name])
        )


def test_проверка_live_withdraw_flow_has_no_bonus_dependency() -> None:
    src = _source()
    assert "async def _legacy_bonus_awards_table_exists" in src
    assert "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE" in src
    for name in LIVE_WITHDRAW_FUNCS:
        body = _function_source(name)
        assert ".withdraw_requests" in body
        assert "bonus_awards" not in body
