from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TASKS = ROOT / "frontend/src/pages/tasks.tsx"
MATRIX = ROOT / "docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_tasks_page_has_earning_boundary_markers() -> None:
    src = read(TASKS)
    assert 'data-tasks-earning-boundary="1291"' in src
    assert 'data-tasks-list-card-layout="compact"' in src
    assert 'data-task-card="earning"' in src
    assert 'data-task-reward="bonus-efhc"' in src
    assert 'data-task-action-row="primary"' in src


def test_tasks_cards_keep_reward_and_primary_actions() -> None:
    src = read(TASKS)
    assert "formatD8ToHuman(item.bonus_efhc)" in src
    assert "<EfhcCoinIcon" in src
    assert "buttonLabel(" in src
    assert 'adTask ? "watch-ad" : "claim-bonus"' in src
    assert "helpText(" in src
    assert "useClaimTask" in src
    assert "useFinishBuiltinTimerAd" in src


def test_tasks_public_ui_has_no_history_log_or_debug_surface() -> None:
    src = read(TASKS)
    banned = [
        "task history",
        "completion history",
        "execution log",
        "backend logs",
        "debug",
        "idempotency_note",
        "tasks.idempotency_note",
        "desc.tasks.idempotency_note",
        "desc.tasks.no_separate_ads_page",
        "GameDetails",
        "useTD",
    ]
    for token in banned:
        assert token not in src


def test_tasks_docs_record_boundary() -> None:
    docs = read(MATRIX) + "\n" + read(PLAN) + "\n" + read(REPORTS)
    assert "v168_89 / work pass" in docs
    assert "Tasks is an earning module" in docs
    assert "no task history public block" in docs
    assert "test_tasks_earning_boundary.py" in docs
