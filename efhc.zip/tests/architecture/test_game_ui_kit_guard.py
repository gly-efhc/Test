from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_game_ui_kit_component_exists() -> None:
    kit = read("frontend/src/components/ui/GameShell.tsx")
    assert "GamePageShell" in kit
    assert "GameHero" in kit
    assert "GameStatsGrid" in kit
    assert "GameStat" in kit
    assert "GameNotice" in kit


def test_core_pages_use_game_shell() -> None:
    for page in [
        "frontend/src/pages/panels.tsx",
        "frontend/src/pages/exchange.tsx",
        "frontend/src/pages/tasks.tsx",
        "frontend/src/pages/referrals.tsx",
        "frontend/src/pages/ranks.tsx",
    ]:
        text = read(page)
        assert "GamePageShell" in text
        assert "GameHero" in text


def test_public_pages_hide_raw_error_details() -> None:
    for page in [
        "frontend/src/pages/panels.tsx",
        "frontend/src/pages/exchange.tsx",
        "frontend/src/pages/tasks.tsx",
        "frontend/src/pages/referrals.tsx",
        "frontend/src/pages/ranks.tsx",
    ]:
        text = read(page)
        assert "String(e?.message" not in text
        assert "detail={errorText}" not in text
        assert "detail={err ||" not in text
        assert "preview_route_error" not in text


def test_profile_tabs_localized_in__all__locales() -> None:
    keys = [
        "profile.section_profile_tab",
        "profile.section_wallet_tab",
        "profile.section_history_tab",
    ]
    locale_dir = ROOT / "frontend/public/locale"
    for path in locale_dir.glob("*.json"):
        text = path.read_text(encoding="utf-8")
        for key in keys:
            assert key in text, f"{key} missing in {path.name}"


def test_admin_button_and_splash_stability_guards() -> None:
    header = read("frontend/src/components/GlobalHeader.tsx")
    app = read("frontend/src/pages/_app.tsx")
    assert "props.isAdmin" in header
    assert 't("nav.admin")' in header
    assert "splashDone" in app
    assert "setSplashDone(true)" in app
