from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_reports_export_component_exists() -> None:
    path = (
        ROOT
        / "frontend/src/components/admin/AdminReportsExportDownloadPanel.tsx"
    )
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert 'data-admin-reports-export-cycle="1344"' in text
    assert "refine useExport" in text
    assert "ExportButton" in text
    assert "tma downloadFile" in text


def test_reports_page_uses_export_panel() -> None:
    text = read("frontend/src/pages/admin/reports.tsx")
    assert "AdminReportsVisualDashboardPanel" in text
    assert "AdminReportsExportDownloadPanel" in text
    assert "AdminRouteHealthStrip" not in text


def test_reports_export_is_client_side_and_sanitized() -> None:
    text = read(
        "frontend/src/components/admin/"
        "AdminReportsExportDownloadPanel.tsx"
    )
    for marker in (
        "new Blob",
        "createObjectURL",
        "downloadText",
        "rowsToCsv",
        "rowsToJson",
        "rowsToText",
    ):
        assert marker in text
    forbidden = ("raw SQL", "raw payload", "apiRequest<")
    for marker in forbidden:
        assert marker not in text


def test_reports_export_cycle_docs_exist() -> None:
    assert (
        ROOT / "docs/admin/ADMIN_REPORTS_EXPORT_DOWNLOAD_BOUNDARY.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/FRONTEND_CYCLE_1344_ADMIN_REPORTS_EXPORT_DOWNLOAD_AUDIT_V169_23.md"
    ).exists()
    assert (
        ROOT
        / "reports/change_cycle_2026-05-31_v169_23_cycle_1344_admin_reports_export_download_boundary.md"
    ).exists()


def test_cycle_plan_advances_to_diagnostics() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert (
        "1344: Admin Reports export/download boundary. DONE in v169_23."
        in text
    )
    assert "1345: Diagnostics technical-only boundary" in text
