from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOCKERFILE = ROOT / "ops" / "docker" / "Dockerfile.frontend"


def test_frontend_dockerfile_uses_stable_npm_ci_flags() -> None:
    text = DOCKERFILE.read_text(encoding="utf-8")

    assert "npm config set registry https://registry.npmjs.org/" in text
    assert "npm ci" in text
    assert "--no-audit" in text
    assert "--no-fund" in text
    assert "--progress=false" in text
    assert "--fetch-retries=5" in text


def test_frontend_dockerfile_disables_noisy_npm_defaults() -> None:
    text = DOCKERFILE.read_text(encoding="utf-8")

    assert "NPM_CONFIG_AUDIT=false" in text
    assert "NPM_CONFIG_FUND=false" in text
    assert "NPM_CONFIG_PROGRESS=false" in text
    assert "NEXT_TELEMETRY_DISABLED=1" in text
