from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_проверка_direct_and_purchase_contours_are_explicitly_separate() -> None:
    modal = read("frontend/src/components/DepositModal.tsx")
    hub = read("frontend/src/features/hub/HubPage.tsx")
    shop = read("frontend/src/features/browser-shop/BrowserShopPage.tsx")
    assert 'data-direct-deposit-label="direct"' in modal
    assert 'data-direct-deposit-kind="efhc-jetton-to-efhcm"' in modal
    assert 'data-hub-visible-action-count="2"' in hub
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in hub
    assert 'data-hub-handoff-kind="external-top-up"' in hub
    assert "portal.browser_shop.pay_ton_gram" in shop
    assert "portal.browser_shop.pay_usdt_ton_gram" in shop
    assert "tonAmountToNano" not in modal
    assert 'data-direct-deposit-amount="ton"' not in modal


def test_проверка_russian_labels_distinguish_direct_deposit_and_purchase() -> None:
    data = json.loads(
        (ROOT / "frontend/public/locale/ru.json").read_text(
            encoding="utf-8"
        )
    )
    assert data["deposit.direct_title"] == "Прямое пополнение"
    assert data["hub.action_top_up_efhc"] == "Пополнение"
    assert "EFHC jetton" in data["deposit.direct_description"]
    hub_detail = data["hub.action_top_up_efhc_description"]
    forbidden = ("TON", "GRAM", "USDT", "куп", "магаз", "цен")
    assert all(token.lower() not in hub_detail.lower() for token in forbidden)
    assert "TON / GRAM" in data["portal.browser_shop.pay_ton_gram"]
    assert "USDT" in data["portal.browser_shop.pay_usdt_ton_gram"]


def test_проверка_direct_backend_does_not_share_shop_pricing_or_native_ton() -> None:
    route = read("backend/app/routes/deposit_routes.py")
    watcher = read("backend/app/services/watcher_service.py")
    direct = route.split("async def open_direct_deposit", 1)[1].split(
        "@router.get", 1
    )[0]
    assert "EFHC_JETTON_MASTER_ADDRESS" in direct
    assert "create_intent_deposit_by_package" not in direct
    assert "wallet_open_url" not in direct
    assert "amount_ton" not in watcher.split(
        'elif kind == "simple_efhc":', 1
    )[1].split("else:", 1)[0]
