from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_single_startup_entrypoint_and_active_dispatch_kernel() -> None:
    start = read("START_HERE.md")
    kernel = read("KERNEL.md")
    assert "единственным активным порядком старта" in start
    assert "Песочница ChatGPT является временной" in start
    assert "ACTIVE OPERATOR KERNEL / FULL DETAILED DISPATCH LAYER" in kernel
    assert "It is not only navigation" in kernel
    assert "file_map.summary.json" in kernel
    assert "EFHC_Bot_v171_65.zip" in kernel
    assert "EFHC_Bot_v171_64.zip" in kernel
    assert "Current canonical development HEAD" in kernel


def test_compatibility_entrypoints_do_not_define_second_order() -> None:
    assert "does not define a second reading order" in read("AGENTS.md")
    assert "must not define an alternative order" in read("docs/AI/READING_ENTRYPOINT.md")
    assert "Use `START_HERE.md` as the only startup entrypoint" in read("CLAUDE.md")


def test_ci_and_screenshot_user_corrections_are_active() -> None:
    norm = read("docs/NORM/AI_EXECUTION_BOUNDS_AND_HANDOFF_STANDARD.md")
    assert "The user has not prohibited CI" in norm
    assert "PNG screenshots are local visual evidence" in norm
    assert "page.set_content" in norm
    assert "GitHub CI belongs to the user by default" not in norm


def test_prior_archive_lineage_and_receipt_are_preserved_as_history() -> None:
    lineage = json.loads(read("reports/generated/archive_truth_lineage_v171_60.json"))
    receipt = json.loads(read("reports/generated/startup_read_receipt_v171_60.json"))
    assert len(lineage["archives_compared"]) == 8
    assert receipt["result"] == "READ_FULL_CONFIRMED_BEFORE_EDIT"


def test_governance_guards_pass() -> None:
    for script in [
        "scripts/ci/check_governance_entrypoints.py",
        "scripts/ci/check_application_screenshot_provenance.py",
        "scripts/ci/check_ai_archive_laws_integrity.py",
    ]:
        proc = subprocess.run(
            [sys.executable, script],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        assert proc.returncode == 0, proc.stdout
