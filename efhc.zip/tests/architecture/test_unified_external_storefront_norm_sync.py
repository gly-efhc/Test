from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_unified_external_storefront_norm_matches_cycle_rebase() -> (
    None
):
    norm = (
        ROOT / "docs" / "NORM" / "UNIFIED_EXTERNAL_STOREFRONT_NORM.md"
    ).read_text(encoding="utf-8")
    audit = (
        ROOT
        / "docs"
        / "audits"
        / "CHAT_ARCHIVE_CYCLES_REBASE_2026_04_04_UNIFIED_DIRECTION.md"
    ).read_text(encoding="utf-8")
    cycles = (
        ROOT / "docs" / "cycles" / "WORK_CYCLES_301-400.md"
    ).read_text(encoding="utf-8")

    required = [
        "one frontend shell",
        "Telegram is a handoff and context layer only",
        "The storefront itself opens outside Telegram",
        "same backend/admin repo",
        "VIP verification",
    ]
    for token in required:
        assert token in norm

    assert "one external storefront" in audit
    assert "one frontend shell" in audit
    assert "Telegram is only handoff/context" in cycles
