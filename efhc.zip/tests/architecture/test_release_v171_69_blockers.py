from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _service_block(
    compose: str,
    name: str,
    next_name: str | None,
) -> str:
    start = compose.index(f"  {name}:\n")
    if next_name is None:
        end = compose.index("\nvolumes:\n", start)
    else:
        end = compose.index(f"  {next_name}:\n", start)
    return compose[start:end]


def test_production_runner_uses_canonical_scheduler_service() -> None:
    runner = (ROOT / "backend/run.py").read_text(encoding="utf-8")
    assert "SchedulerService" in runner
    assert "register_defaults(strict=True)" in runner
    assert "TaskSpec" not in runner
    assert "_resolve_entry" not in runner


def test_all_canonical_scheduler_jobs_are_registered() -> None:
    source = (
        ROOT / "backend/app/services/scheduler_service.py"
    ).read_text(encoding="utf-8")
    expected = {
        "generate_energy",
        "check_ton_inbox",
        "check_vip_nft",
        "archive_panels",
        "update_ranks",
        "tasks_autorestart",
        "ads_rotation",
        "reports_daily",
    }
    for name in expected:
        assert f'"{name}"' in source
    assert "async def stop(" in source
    assert "scheduler shutdown timed out" in source


def test_release_compose_isolates_secrets_and_bounds_logs() -> None:
    compose = (ROOT / "docker-compose.release.yml").read_text(
        encoding="utf-8"
    )
    blocks = {
        "db": _service_block(compose, "db", "backend"),
        "backend": _service_block(compose, "backend", "frontend"),
        "frontend": _service_block(compose, "frontend", "proxy"),
        "proxy": _service_block(compose, "proxy", None),
    }
    assert "env_file:" not in blocks["db"]
    assert "env_file:" not in blocks["proxy"]
    assert "env_file:" in blocks["backend"]
    assert "TELEGRAM_BOT_TOKEN" not in blocks["db"]
    assert "TELEGRAM_BOT_TOKEN" not in blocks["proxy"]
    for block in blocks.values():
        assert "logging: *json-logging" in block


def test_restore_is_fail_closed() -> None:
    restore = (
        ROOT / "scripts/release/restore_postgres.sh"
    ).read_text(encoding="utf-8")
    assert "restore_completed=false" in restore
    assert "remain stopped" in restore
    assert "trap cleanup EXIT" not in restore
    assert restore.index("pg_restore") < restore.index(
        'compose up -d --no-deps backend'
    )


def test_install_grants_non_root_docker_access() -> None:
    installer = (
        ROOT / "scripts/release/install_server.sh"
    ).read_text(encoding="utf-8")
    assert "usermod -aG docker" in installer
    assert "newgrp docker" in installer


def test_release_scripts_are_executable() -> None:
    scripts = sorted((ROOT / "scripts/release").glob("*.sh"))
    assert scripts
    for script in scripts:
        assert os.access(script, os.X_OK), script


def test_deploy_uses_safe_update_order() -> None:
    deploy = (ROOT / "scripts/release/deploy.sh").read_text(
        encoding="utf-8"
    )
    build = deploy.index("compose build --pull migrate frontend")
    backup = deploy.index('"${SCRIPT_DIR}/backup_postgres.sh"')
    migrations = deploy.index("run_migrations_once")
    backend = deploy.index("compose up -d --no-deps backend")
    frontend = deploy.index("compose up -d --no-deps frontend")
    proxy = deploy.index("compose up -d --no-deps proxy")
    schema_check = deploy.index("existing EFHC schema detected")
    assert build < schema_check < backup < migrations
    assert migrations < backend < frontend < proxy
