from __future__ import annotations

import importlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_states_py_is_compatibility_facade_only() -> None:
    content = read("backend/app/bot/states.py")

    assert len(content.encode("utf-8")) < 2_500
    assert "from app.bot.fsm import" in content
    assert "class StateManager" not in content
    assert "class MemoryStateBackend" not in content
    assert "def require_state" not in content


def test_fsm_modules_exist_with_single_responsibility_names() -> None:
    expected = [
        "__init__.py",
        "backend.py",
        "decorators.py",
        "dto.py",
        "manager.py",
    ]
    for name in expected:
        assert (ROOT / "backend/app/bot/fsm" / name).is_file()

    dto = read("backend/app/bot/fsm/dto.py")
    backend = read("backend/app/bot/fsm/backend.py")
    manager = read("backend/app/bot/fsm/manager.py")
    decorators = read("backend/app/bot/fsm/decorators.py")

    assert "class BotStates" in dto
    assert "class ConversationState" in dto
    assert "class StateBackend" in backend
    assert "class MemoryStateBackend" in backend
    assert "class StateManager" in manager
    assert "def get_state_manager" in manager
    assert "def require_state" in decorators
    assert "def advance_state" in decorators
    assert "def clear_state_after" in decorators


def test_fsm_import_api_stays_backward_compatible() -> None:
    states = importlib.import_module("app.bot.states")
    fsm = importlib.import_module("app.bot.fsm")

    names = [
        "BotStates",
        "ConversationState",
        "StateBackend",
        "MemoryStateBackend",
        "StateManager",
        "get_state_manager",
        "require_state",
        "advance_state",
        "clear_state_after",
    ]
    for name in names:
        assert getattr(states, name) is getattr(fsm, name)

    state = states.ConversationState()
    assert state.state == states.BotStates.IDLE
    assert state.as_dict()["state"] == states.BotStates.IDLE


def test_bot_package_import_is_lazy_for_fsm() -> None:
    package = read("backend/app/bot/__init__.py")

    header = package.split("def get_bot(")[0]
    assert "from app.bot.bot import" not in header
    assert "def get_bot(" in package
    assert "def get_dispatcher(" in package
    assert "async def process_update(" in package
