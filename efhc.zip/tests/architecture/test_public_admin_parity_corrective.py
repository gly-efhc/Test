"""Причинные guards корректирующего пакета цикла 1635."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_faq_рендерит_структуру_без_сырой_html_инъекции() -> None:
    renderer = read("frontend/src/components/faq/FaqAnswerText.tsx")
    tree = read("frontend/src/components/faq/FaqVerticalTree.tsx")
    item = read("frontend/src/components/faq/FaqQuestionItem.tsx")
    page = read("frontend/src/pages/faq.tsx")

    assert "text.split(/(\\*\\*[^*]+\\*\\*)/g)" in renderer
    assert "<strong" in renderer
    assert "<ul" in renderer
    assert "dangerouslySetInnerHTML" not in renderer
    assert '<FaqAnswerText text={item.answer} />' in tree
    assert '<FaqAnswerText text={props.item.answer} />' in item
    assert "FaqAnswerText" in page


def test_readonly_offline_status_не_перекрывает_route() -> None:
    component = read("frontend/src/components/PwaRuntimeStatus.tsx")
    styles = read("frontend/src/styles/globals.css")
    audit = read("ops/frontend/all_pages_route_backed_visual_audit.py")

    assert 'data-pwa-runtime-layout={' in component
    assert '"inline-readonly"' in component
    assert (
        '.efhc-pwa-runtime-status[data-pwa-runtime-layout="inline-readonly"]'
        in styles
    )
    inline_selector = (
        '.efhc-pwa-runtime-status[data-pwa-runtime-layout="inline-readonly"]{'
    )
    inline_start = styles.index(inline_selector)
    inline_rule = styles[inline_start:inline_start + 320]
    assert "position:relative;" in inline_rule
    assert "position:fixed;" not in inline_rule
    assert "[data-pwa-runtime-status]:not(" in audit
    assert "inline-readonly" in audit
    assert "obstructing_overlays == 0" in audit


def test_admin_home_содержит_релизные_но_не_технические_данные() -> None:
    page = read("frontend/src/pages/admin/index.tsx")

    forbidden = [
        "AdminOverviewDashboardRuntime",
        "AdminObservabilityTimeseriesDashboardRuntime",
        "AdminUiKitAdoptionProofPanel",
        "AdminScreenshotQaPreparationPanel",
        "AdminRouteHealthStrip",
        "AdminDiagnosticsTechnicalBoundaryPanel",
        "diagnostics",
        "route markers",
        "technical counters",
    ]
    for marker in forbidden:
        assert marker not in page

    policy = json.loads(read("release_config/UPDATE_POLICY.json"))
    release_version = policy["release_version"]
    assert f'const RELEASE_VERSION = "{release_version}"' in page
    assert "Релизный центр управления" in page
    assert "Ключевые показатели" in page
    assert "Релизные данные" in page
    assert "Операторские инструменты" in page


def test_public_ui_использует_admin_quality_state_system() -> None:
    styles = read("frontend/src/styles/globals.css")
    marker = (
        "Cycle 1635 corrective — "
        "admin-quality public design system parity"
    )
    start = styles.rfind(marker)
    assert start >= 0
    corrective = styles[start:]

    assert "--efhc-public-accent:#6ea8ff;" in corrective
    assert "--efhc-public-teal:#58c7b4;" in corrective
    assert "background:rgba(88,199,180,.10);" in corrective
    assert "background:rgba(59,130,246,.12);" in corrective
    assert (
        ".efhc-hub-page[data-hub-runtime=\"two-equal-actions\"]"
        in corrective
    )
    assert "min-height:9.5rem;" in corrective
    assert ":disabled{" in corrective
    assert ":focus-visible{" in corrective


def test_шесть_нижних_routes_сохранены() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    expected = [
        'href: "/"',
        'href: "/panels"',
        'href: "/exchange"',
        'href: "/tasks"',
        'href: "/referrals"',
        'href: "/ranks"',
    ]
    positions = [layout.index(marker) for marker in expected]
    assert positions == sorted(positions)
    assert "const bottom = [" in layout
    assert layout.count("data-nav-key={props.navKey}") == 1
