"""Статические UI-контракты мобильной навигации и Energy."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(
        encoding="utf-8",
        errors="replace",
    )


def test_шапка_профиля_сохраняет_утверждённый_baseline() -> None:
    profile = _read("frontend/src/features/profile/WebProfilePage.tsx")
    css = _read("frontend/src/styles/globals.css")
    assert "efhc-profile-topbar" in profile
    assert "efhc-profile-topbar_actions" in profile
    assert "navigateBackWithinApp(router)" in profile
    assert "actions-one-row" not in profile + css
    assert "efhc-profile-topbar_back" not in profile + css


def test_нижняя_навигация_сохраняет_шесть_маршрутов() -> None:
    layout = _read("frontend/src/components/Layout.tsx")
    css = _read("frontend/src/styles/globals.css")
    expected = {
        "Energy": "/",
        "Panels": "/panels",
        "Exchange": "/exchange",
        "Tasks": "/tasks",
        "Referrals": "/referrals",
        "Ranks": "/ranks",
    }
    for label, route in expected.items():
        assert f'visualLabel: "{label}"' in layout
        assert f'href: "{route}"' in layout
    assert 'data-nav-geometry="wide-rounded-six"' in layout
    assert 'data-nav-icon-system="rounded-outline-v2"' in layout
    assert "premium-dock-v3" not in layout + css
    assert "floating-console-six" not in layout + css
    assert "efhc-game-nav_icon-halo" not in layout + css


def test_energy_progress_использует_простой_baseline() -> None:
    page = _read("frontend/src/pages/index.tsx")
    icon = _read("frontend/src/components/icons/KwhIcon.tsx")
    css = _read("frontend/src/styles/globals.css")
    assert 'data-energy-mark="balanced-lightning-v2"' in icon
    assert "energy-core-marker-v3" not in page + css
    assert "efhc-energy-progress-marker" not in page + css
    assert "premium-energy-core-v3" not in icon + css


def test_android_и_pwa_back_остаются_внутри_приложения() -> None:
    back = _read("frontend/src/lib/appBackNavigation.ts")
    app = _read("frontend/src/pages/_app.tsx")
    layout = _read("frontend/src/components/Layout.tsx")
    assert "useAppBackNavigation(router)" in app
    assert "router.beforePopState" in back
    assert 'document.addEventListener("backbutton"' in back
    assert "__EFHC_ANDROID_BACK__" in back
    assert "sessionStorage" in back
    assert 'root_fallback: "/"' in back
    assert "navigateBackWithinApp(router)" in layout
