from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_i18n_has_embedded_first_paint_fallback() -> None:
    src = read("frontend/src/lib/i18n.ts")
    assert "../../public/locale/en.json" in src
    assert "../../public/locale/ru.json" in src
    assert "getEmbeddedDict" in src
    assert "embeddedEn[k]" in src
    assert "void ru;" in src
    assert "embeddedRu[k]" not in src


def test_app_initializes_with_non_empty_dictionaries() -> None:
    src = read("frontend/src/pages/_app.tsx")
    assert 'getEmbeddedDict("en")' in src
    assert 'getEmbeddedDict("ru")' in src
    assert "setUiDict(fallback)" in src
    assert "setDescDict(fallback)" in src
    assert 'setRuDict(getEmbeddedDict("ru"))' in src


def test_browser_preview__name__is_user_facing() -> None:
    src = read("frontend/src/lib/browserFallback.ts")
    assert "browser-player" not in src
    assert 'username: "EFHC Player"' in src


def test_live_blocker_audit_was_recorded() -> None:
    src = read("docs/audits/FRONTEND_LIVE_APP_BLOCKER_AUDIT_V168_36.md")
    assert "raw i18n keys" in src
    assert "energy.title" in src
    assert "Dragon" in src
