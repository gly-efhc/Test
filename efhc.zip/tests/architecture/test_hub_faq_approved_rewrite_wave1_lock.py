from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.json"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def test_hub_replacements_present() -> None:
    data = json.loads(RU.read_text(encoding="utf-8"))
    sec = data["sections"][12]
    qa = {item["q"]: item["a"] for item in sec["items"]}
    assert qa["Что можно делать в Hub?"]
    assert qa["Для чего нужен Hub?"]
    assert qa["Что делает кнопка «Пополнить»?"] == (
        "Она открывает внешнюю Web-страницу продолжения. "
        "До выхода из Hub товары, цены и способы оплаты "
        "не показываются."
    )
    assert qa["Сколько действий доступно в Hub?"] == (
        "Ровно два: «Пополнение» и «EFHC VIP NFT». "
        "Обе функции являются каноническими."
    )


def test_cycle_110_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert "| 110 | done | RU Hub approved rewrite wave 1." in text
