from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_cycle_1494_docs_and_navigation_are_registered() -> None:
    required = [
        "docs/NORM/ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA.md",
        "docs/NORM/ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1494_ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA.md",
        "reports/generated/accessibility_localization_overflow_qa_v170_70.json",
        (
            "reports/change_cycle_2026-06-10_v170_70_cycle_1494_"
            "accessibility_localization_overflow_qa.md"
        ),
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel

    kernel = read("KERNEL.md")
    routes = read("ops/operator_kernel/config/routes.yaml")
    map_element = read("map_element.md")
    for marker in required[:3]:
        assert marker in kernel or marker in map_element
        assert marker in routes or marker in map_element
    assert "1495 — Final Dashboard Visual Audit / Screenshot Proof" in (
        kernel + map_element
    )


def test_dashboard_progress_bars_have_accessible_progressbar_semantics() -> None:
    source = read("frontend/src/components/dashboard/ProgressSystem.tsx")
    assert 'role="progressbar"' in source
    assert "aria-valuenow={Math.round(normalized.percent)}" in source
    assert "aria-valuemin={0}" in source
    assert "aria-valuemax={100}" in source
    assert 'data-dashboard-accessibility-overflow-qa="1494"' in source


def test_admin_ui_primitives_have_status_and_kpi_accessibility_markers() -> None:
    source = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    assert "function adminNodeToText" in source
    assert 'role="status"' in source
    assert "aria-label={adminNodeToText(props.label" in source
    assert 'data-admin-accessibility-overflow-qa="1494"' in source
    assert 'adminNodeToText(props.value, "value")' in source
    assert "EFHC Admin Dashboard" in source


def test_dashboard_css_hardens_overflow_and_mobile_widths() -> None:
    css = read("frontend/src/styles/globals.css")
    assert "Cycle 1494 — Accessibility / Localization / Overflow QA hardening" in css
    assert "overflow-wrap: anywhere" in css
    assert "hyphens: auto" in css
    assert "font-variant-numeric: tabular-nums" in css
    assert "@media (max-width: 430px)" in css
    assert ".efhc-dashboard-surface" in css
    assert "min-width: 0" in css


def test_exchange_profile_snapshot_placeholder_labels_are_localized() -> None:
    forbidden = {
        "Локализовано: raw snapshot",
        "Локалізовано: raw snapshot",
        "Localizado: raw snapshot",
        "Localisé : raw snapshot",
        "Lokalisiert: raw snapshot",
        "Lokaliseret: raw snapshot",
        "Localizzato: raw snapshot",
        "Lokalnie: raw snapshot",
        "स्थानीय: raw snapshot",
        "Eneo: raw snapshot",
    }
    for path in sorted((ROOT / "frontend/public/locale").glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in ("exchange.dashboard_raw_data", "profile.dashboard_raw_data"):
            value = data.get(key)
            assert value, f"{path.name}:{key} missing"
            assert value not in forbidden, f"{path.name}:{key}={value!r}"


def test_russian_locale_does_not_keep_raw_snapshot_placeholders() -> None:
    data = json.loads(read("frontend/public/locale/ru.json"))
    assert data["exchange.dashboard_raw_data"] == "исходный снимок"
    assert data["profile.dashboard_raw_data"] == "исходный снимок"
    assert data["energy.dashboard_raw_snapshot"] == "исходный снимок"
    assert data["energy.dashboard_derived_snapshot"] == "расчётное отображение"


def test_real_timeseries_filter_labels_are_russian_on_admin_surface() -> None:
    source = read(
        "frontend/src/components/admin/"
        "AdminObservabilityTimeseriesDashboardRuntime.tsx"
    )
    assert 'label: "Метрика"' in source
    assert 'label: "Шаг"' in source
    assert 'label: "Период"' in source
    assert '{ key: "hour", label: "час" }' in source
    assert '{ key: "day", label: "день" }' in source
    assert 'label: "Metric"' not in source
    assert 'label: "Bucket"' not in source
    assert 'label: "Range"' not in source


def test_grafana_and_sandbox_remain_reference_only() -> None:
    norm = read("docs/NORM/ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA.md")
    graf = read(
        "docs/NORM/ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA_"
        "GRAFANA_ELEMENT_ANALYSIS.md"
    )
    assert "Grafana was used only as visual-pattern/reference layer" in norm
    assert "Песочница was used only as reference/navigation/prototype layer" in norm
    assert "No Grafana runtime code" in graf
    assert "No sandbox runtime code was copied" in graf
