"""Причинная приёмка разделения GlobalId и TelegramId."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest
from app.identity.types import (
    GlobalId,
    InvalidGlobalId,
    InvalidTelegramId,
    TelegramId,
    tg_id_from_provider,
    tg_id_to_provider,
)
from ops.identity.check_cross_language_identity_separation import (
    найти_frontend_смешения,
    найти_python_смешения,
    проверить,
)
from ops.identity.export_cross_language_identity_contract import (
    build_contract,
)

ROOT = Path(__file__).resolve().parents[2]
FRONTEND_TYPES = ROOT / "frontend/src/types/identity.ts"
FIXTURE = ROOT / (
    "contracts/identity/"
    "cross_language_identity_separation_v1.json"
)


def _require_tool(name: str) -> str:
    executable = shutil.which(name)
    if executable is None:
        pytest.skip(f"Инструмент {name} отсутствует в среде.")
    return executable


def _compile_identity(tmp_path: Path) -> Path:
    tsc = _require_tool("tsc")
    output = tmp_path / "compiled"
    result = subprocess.run(
        [
            tsc,
            str(FRONTEND_TYPES),
            "--target",
            "ES2020",
            "--module",
            "commonjs",
            "--strict",
            "--skipLibCheck",
            "--outDir",
            str(output),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    return output / "identity.js"


def test_backend_nominal_types_отклоняют_смешение() -> None:
    global_id = GlobalId(42)
    telegram_id = TelegramId(42)
    with pytest.raises(InvalidGlobalId):
        GlobalId.from_database(telegram_id)
    with pytest.raises(InvalidTelegramId):
        TelegramId.from_provider(global_id)
    with pytest.raises(InvalidTelegramId):
        tg_id_from_provider(9_007_199_254_740_992)
    assert tg_id_to_provider(telegram_id) == 42


def test_frontend_runtime_различает_wire_types(
    tmp_path: Path,
) -> None:
    node = _require_tool("node")
    compiled = _compile_identity(tmp_path)
    script = r'''
const assert = require("node:assert/strict");
const identity = require(process.argv[1]);
const globalId = identity.parseGlobalId("0000000042");
const telegramId = identity.parseTelegramId(42);
assert.equal(identity.globalIdToApi(globalId), "0000000042");
assert.equal(identity.telegramIdToProvider(telegramId), 42);
assert.throws(() => identity.parseGlobalId(42));
assert.throws(() => identity.parseTelegramId("0000000042"));
assert.throws(() => identity.parseTelegramId(0));
assert.throws(() => identity.parseTelegramId(Number.MAX_SAFE_INTEGER + 1));
'''
    result = subprocess.run(
        [node, "-e", script, str(compiled)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_typescript_compile_отклоняет_оба_направления(
    tmp_path: Path,
) -> None:
    tsc = _require_tool("tsc")
    identity = tmp_path / "identity.ts"
    identity.write_text(
        FRONTEND_TYPES.read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    invalid = tmp_path / "invalid.ts"
    invalid.write_text(
        'import { parseGlobalId, parseTelegramId, '
        'telegramIdToProvider } from "./identity";\n'
        'import type { GlobalId, TelegramId } from "./identity";\n'
        'const globalId = parseGlobalId("0000000042");\n'
        'const telegramId = parseTelegramId(42);\n'
        'const badGlobal: GlobalId = telegramId;\n'
        'const badTelegram: TelegramId = globalId;\n'
        'telegramIdToProvider(globalId);\n'
        'void badGlobal; void badTelegram;\n',
        encoding="utf-8",
    )
    result = subprocess.run(
        [
            tsc,
            str(identity),
            str(invalid),
            "--target",
            "ES2020",
            "--module",
            "commonjs",
            "--strict",
            "--skipLibCheck",
            "--noEmit",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    output = result.stdout + result.stderr
    assert result.returncode != 0
    assert "TelegramId" in output
    assert "GlobalId" in output


def test_guard_ловит_python_telegram_to_global(
    tmp_path: Path,
) -> None:
    path = tmp_path / "backend/app/bad.py"
    path.parent.mkdir(parents=True)
    path.write_text(
        "def bad(tg_id):\n"
        "    global_id = tg_id\n"
        "    return global_id\n",
        encoding="utf-8",
    )
    findings = найти_python_смешения(tmp_path)
    assert findings[0]["причина"] == "telegram_to_global_assignment"


def test_guard_ловит_global_id_в_telegram_api(
    tmp_path: Path,
) -> None:
    path = tmp_path / "backend/app/bad.py"
    path.parent.mkdir(parents=True)
    path.write_text(
        "def bad(bot, global_id):\n"
        "    return bot.send_message(chat_id=global_id, text='x')\n",
        encoding="utf-8",
    )
    findings = найти_python_смешения(tmp_path)
    assert findings[0]["причина"] == "global_id_to_telegram_api"


def test_guard_ловит_typescript_смешение(tmp_path: Path) -> None:
    path = tmp_path / "frontend/src/bad.ts"
    path.parent.mkdir(parents=True)
    path.write_text(
        "const telegramId = globalId;\n",
        encoding="utf-8",
    )
    findings = найти_frontend_смешения(tmp_path)
    assert findings[0]["причина"] == "typescript_identity_assignment"


def test_exact_head_проходит_cross_language_guard() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["номинальные_типы_backend"] is True
    assert result["брендированные_типы_frontend"] is True
    assert result["telegram_граница_типизирована"] is True


def test_fixture_воспроизводим_из_backend_contract() -> None:
    actual = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert actual == build_contract()
    assert actual["global_id"]["wire_type"] == "string"
    assert actual["tg_id"]["wire_type"] == "integer"


def test_цикл_1607_имеет_operator_kernel_route() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    classified = classify_task(
        "Цикл 1607 Cross-language разделение GlobalId и TelegramId"
    )
    assert classified["task_type"] == (
        "cross_language_identity_separation"
    )
    route = resolve_route(
        "cross_language_identity_separation",
        ROOT,
    )
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_ускоренный_roadmap_оставляет_25_обязательных_циклов() -> None:
    completed_cycle = 1607
    final_mandatory_cycle = 1632
    assert final_mandatory_cycle - completed_cycle == 25
