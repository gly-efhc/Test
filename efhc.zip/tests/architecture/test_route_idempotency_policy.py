from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))

classify_path = importlib.import_module(
    "app.standards.idempotency_policy"
).classify_path
ROUTES_DIR = ROOT / "backend/app/routes"
WRITE_METHODS = {"post", "put", "patch", "delete"}


def _route_prefixes(tree: ast.Module) -> dict[str, str]:
    prefixes: dict[str, str] = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        if not isinstance(node.value, ast.Call):
            continue
        call = node.value
        if (
            not isinstance(call.func, ast.Name)
            or call.func.id != "APIRouter"
        ):
            continue
        prefix = ""
        for kw in call.keywords:
            if kw.arg == "prefix" and isinstance(
                kw.value, ast.Constant
            ):
                prefix = str(kw.value.value)
        for target in node.targets:
            if isinstance(target, ast.Name):
                prefixes[target.id] = prefix
    return prefixes


def _has_idempotency_dep(fn: ast.AsyncFunctionDef) -> bool:
    defaults = list(fn.args.defaults) + [
        d for d in fn.args.kw_defaults if d is not None
    ]
    for default in defaults:
        if default is None:
            continue
        text = ast.unparse(default)
        if "require_idempotency_key" in text:
            return True
    return False


def _decorated_paths(
    fn: ast.AsyncFunctionDef,
    prefixes: dict[str, str],
) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    for dec in fn.decorator_list:
        if not isinstance(dec, ast.Call):
            continue
        if not isinstance(dec.func, ast.Attribute):
            continue
        if not isinstance(dec.func.value, ast.Name):
            continue
        router_name = dec.func.value.id
        method = dec.func.attr.lower()
        if method not in WRITE_METHODS:
            continue
        if not dec.args:
            continue
        arg0 = dec.args[0]
        if isinstance(arg0, ast.Constant) and isinstance(
            arg0.value, str
        ):
            found.append(
                (method, prefixes.get(router_name, "") + arg0.value)
            )
    return found


def test_write_routes_follow_idempotency_policy() -> None:
    missing: list[str] = []
    excessive: list[str] = []

    for path in sorted(ROUTES_DIR.rglob("*_routes.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        prefixes = _route_prefixes(tree)
        for node in tree.body:
            if not isinstance(node, ast.AsyncFunctionDef):
                continue
            has_dep = _has_idempotency_dep(node)
            for method, route_path in _decorated_paths(node, prefixes):
                cls = classify_path(route_path)
                rel = path.relative_to(ROOT).as_posix()
                marker = (
                    f"{method.upper()} {route_path} -> "
                    f"{rel}:{node.name}"
                )
                if cls == "MUST" and not has_dep:
                    missing.append(marker)
                if cls in {"NONE", "EXTERNAL"} and has_dep:
                    excessive.append(marker)

    assert not missing, (
        "MUST write-routes must depend on "
        f"require_idempotency_key: {missing}"
    )
    assert not excessive, (
        "NONE/EXTERNAL write-routes must not depend on "
        f"Idempotency-Key: {excessive}"
    )
