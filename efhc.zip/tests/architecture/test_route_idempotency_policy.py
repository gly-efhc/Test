from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))

classify_path = importlib.import_module(
    "app.standards.idempotency_policy"
).classify_path
ROUTES_DIR = ROOT / "backend/app/routes"
WRITE_METHODS = {"post", "put", "patch", "delete"}


def _has_idempotency_arg(fn: ast.AsyncFunctionDef) -> bool:
    for arg in fn.args.args + fn.args.kwonlyargs:
        if arg.arg != "idempotency_key":
            continue
        ann = ast.unparse(arg.annotation) if arg.annotation else ""
        if "Depends(require_idempotency_key)" in ann:
            return True
    return False


def _decorated_paths(
    fn: ast.AsyncFunctionDef,
) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    for dec in fn.decorator_list:
        if not isinstance(dec, ast.Call):
            continue
        if not isinstance(dec.func, ast.Attribute):
            continue
        method = dec.func.attr.lower()
        if method not in WRITE_METHODS:
            continue
        if not dec.args:
            continue
        arg0 = dec.args[0]
        if isinstance(arg0, ast.Constant) and isinstance(arg0.value, str):
            found.append((method, arg0.value))
    return found


def test_must_write_routes_require_idempotency_dependency() -> None:
    bad: list[str] = []
    for path in sorted(ROUTES_DIR.rglob("*_routes.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in tree.body:
            if not isinstance(node, ast.AsyncFunctionDef):
                continue
            for method, route_path in _decorated_paths(node):
                if classify_path(route_path) != "MUST":
                    continue
                if _has_idempotency_arg(node):
                    continue
                rel = path.relative_to(ROOT).as_posix()
                bad.append(f"{method.upper()} {route_path} -> {rel}:{node.name}")
    assert not bad, (
        "MUST write-routes must depend on "
        f"require_idempotency_key: {bad}"
    )
