from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "reports/generated/fresh_ci_log_repair_v170_95.json"


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1519_report_keeps_honest_red_log_boundary() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["schema"] == "EFHC_FRESH_CI_LOG_REPAIR_V1"
    assert data["cycle"] == 1519
    assert data["archive_version"] == "v170.95"
    assert data["input_log"] == "logs_74249190312.zip"
    assert data["input_log_verdict"] == "RED"
    assert data["status"] == "RED_LOG_REPAIRED_LOCALLY"
    assert data["github_ci_green_claimed"] is False
    assert data["release_ready_claimed"] is False
    assert data["pytest_failures_in_input_log"] == 9


def test_cycle_1519_lockfile_has_public_registry_only() -> None:
    text = _read("frontend/package-lock.json")
    assert "applied-caas-gateway" not in text
    assert "internal.api.openai" not in text
    assert "artifactory" not in text
    assert "https://registry.npmjs.org/form-data/-/form-data-4.0.6.tgz" in text


def test_active_migration_docs_use_current_table_counts() -> None:
    active_docs = [
        "docs/NORM/ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md",
        "docs/NORM/MIGRATION_INVARIANTS_HARDENING.md",
        "docs/SSOT/SSOT_DB_0001_CANON.md",
    ]
    for rel in active_docs:
        text = _read(rel)
        assert "48" in text, rel
        assert "49" in text, rel
        assert "50" in text, rel
        assert "ровно 43" not in text
        assert "Current SSOT count: 43" not in text

    historical = _read("docs/audits/MIGRATION_0001_ORM_SSOT_AUDIT.md")
    assert "44" in historical


def test_cycle_1519_kernel_has_no_numbered_cycle_text() -> None:
    text = _read("KERNEL.md")
    current = text.split("---", 1)[0]
    assert "cycle 1519" not in current.lower()
    assert "ADMIN_DASHBOARD_UI_KIT_FOUNDATION" in text


def test_cycle_1519_withdraw_approve_not_blocked_by_bonus_awards() -> None:
    text = _read("backend/app/services/admin/admin_withdrawals_service.py")
    start = text.index("async def approve_withdrawal")
    end = text.index("async def reject_withdrawal")
    approve = text[start:end]
    assert "_ensure_legacy_bonus_awards_table" not in approve
    assert "debit_user_to_bank" in approve


def test_cycle_1519_browser_proof_has_no_generation_rate_literals() -> None:
    text = _read("ops/frontend/admin_visual_button_click_proof.py")
    assert "0.00000692" not in text
    assert "0.00000741" not in text
