from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def load(path: str) -> dict:
    return json.loads(read(path))


def test_admin_logs_events_dashboard_docs_exist() -> None:
    for rel in [
        "docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD.md",
        "docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1490_ADMIN_LOGS_EVENTS_DASHBOARD.md",
        "reports/generated/admin_logs_events_dashboard_v170_66.json",
        "reports/change_cycle_2026-06-09_v170_66_cycle_1490_admin_logs_events_dashboard.md",
        "frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx",
    ]:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_logs_events_boundaries() -> None:
    data = load("reports/generated/admin_logs_events_dashboard_v170_66.json")
    assert data["cycle"] == 1490
    assert data["archive_version"] == "v170.66"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["read_only_endpoints"] == [
        "GET /admin/logs/transfers?limit=80"
    ]
    assert data["logs_repaired"] == "logs_73159210416.zip"
    for key in [
        "backend_changed",
        "openapi_changed",
        "migrations_changed",
        "economy_changed",
        "dashboard_write_actions_added",
        "dashboard_idempotency_key_created",
        "raw_payload_visible",
        "debug_json_visible",
        "secrets_visible",
        "fake_time_series_added",
        "synthetic_admin_analytics_added",
        "real_time_series_claimed",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
    ]:
        assert data[key] is False


def test_runtime_component_has_1490_markers_and_read_only_endpoint() -> None:
    src = read("frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx")
    for marker in [
        "adminLogsEventsDashboardRuntimeVersion",
        "EFHC_ADMIN_LOGS_EVENTS_DASHBOARD_RUNTIME_V1",
        'data-admin-logs-events-dashboard-runtime="1490"',
        'data-admin-logs-events-truth="read-only-transfer-log-snapshot"',
        'data-admin-logs-events-no-write-actions="true"',
        'data-admin-logs-events-no-raw-payload="true"',
        'data-admin-logs-events-no-debug-json="true"',
        'data-admin-logs-events-no-secrets="true"',
        'data-admin-logs-events-no-fake-timeseries="true"',
        'data-grafana-reference-only="true"',
        'data-sandbox-reference-only="true"',
        "adminApiRequest<TransferLogsOut>",
        "ADMIN_LOGS_TRANSFERS_PATH",
        "AdminDashboardToolbar",
        "AdminRefreshPicker",
        "AdminFilterBar",
        "AdminMiniBarChart",
        "AdminHeatStrip",
        "AdminActionTable",
    ]:
        assert marker in src


def test_runtime_component_has_no_write_flow_or_raw_debug_rendering() -> None:
    src = read("frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx")
    for marker in [
        '"POST"',
        '"PUT"',
        '"PATCH"',
        '"DELETE"',
        "makeIdempotencyKey",
        "Idempotency-Key",
        "item.meta",
        "JSON.stringify",
        "process.env",
        "initData",
        "synthetic_preview",
        "@grafana/",
        "tg_id",
    ]:
        assert marker not in src


def test_admin_logs_page_integrates_dashboard() -> None:
    page = read("frontend/src/pages/admin/logs.tsx")
    assert "AdminLogsEventsDashboardRuntime" in page
    assert "<AdminLogsEventsDashboardRuntime />" in page
    assert "docker compose logs -f backend frontend" in page
    assert "debug JSON" in page


def test_log_repair_russian_locale_matches_visual_qa_guard() -> None:
    ru = load("frontend/public/locale/ru.json")
    en = load("frontend/public/locale/en.json")
    assert ru["energy.dashboard_raw_snapshot"] == "исходный снимок"
    assert ru["energy.dashboard_derived_snapshot"] == "расчётное отображение"
    assert "Real time-series" not in ru["energy.dashboard_no_timeseries"]
    assert en["energy.dashboard_raw_snapshot"] == "source current summary"
    assert en["energy.dashboard_derived_snapshot"] == "derived display"


def test_navigation_and_manifest_reference_cycle_1490() -> None:
    assert "1490 — Admin Logs / Events Dashboard" in read(
        "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
    )
    assert "1490 — Admin Logs / Events Dashboard" in read(
        "docs/cycles/WORK_CYCLES.md"
    )
    assert "ADMIN_LOGS_EVENTS_DASHBOARD.md" in read("map_element.md")
    assert "test_admin_logs_events_dashboard.py" in read(
        "docs/testing/TEST_GUARD_MANIFEST.md"
    )
    manifest = load("docs/testing/TEST_GUARD_MANIFEST.json")
    assert "tests/architecture/test_admin_logs_events_dashboard.py" in str(manifest)


def test_grafana_and_sandbox_are_reference_only() -> None:
    grafana = read("docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md")
    sandbox = read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    assert "reference-only" in grafana
    assert "No Grafana runtime code" in grafana
    assert "no sandbox runtime code is copied" in sandbox.lower()
