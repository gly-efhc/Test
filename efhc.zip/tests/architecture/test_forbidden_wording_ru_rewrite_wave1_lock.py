from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.json"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def test_forbidden_wording_removed_from_ru_faq() -> None:
    text = RU.read_text(encoding="utf-8").lower()
    assert "купить панель" not in text
    assert "покупка панели" not in text
    assert "депозит" not in text
    assert "заработанные" not in text


def test_cycles_114_115_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert "| 114 | done | RU forbidden wording cleanup audit." in text
    assert (
        "| 115 | done | RU forbidden wording approved rewrite wave."
        in text
    )
