from pathlib import Path


def test_panels_ui_keys_switched_to_activation() -> None:
    panels = Path("frontend/src/pages/panels.tsx").read_text(
        encoding="utf-8"
    )
    assert "panels.activate_panel" in panels
    assert "panels.activate_ok" in panels
    assert "panels.buy_panel" not in panels
    assert "panels.buy_ok" not in panels


def test_ru_panel_wording_approved_wave1() -> None:
    ru = Path("frontend/public/locale/ru.json").read_text(
        encoding="utf-8"
    )
    assert '"panels.activate_panel": "Активация панели"' in ru
    assert '"panels.activate_ok": "Активация выполнена."' in ru
    assert (
        '"panels.subtitle_price_100": "Активации панели 100 EFHC"' in ru
    )
    assert '"profile.reason.panel_activation": "Активация панели"' in ru
    assert '"panels.buy_panel"' not in ru
    assert '"panels.buy_ok"' not in ru
    assert '"profile.reason.panel_purchase"' not in ru


def test_admin_index_approved_label_only() -> None:
    txt = Path("frontend/src/pages/admin/index.tsx").read_text(
        encoding="utf-8"
    )
    assert "AdminAppButtonGrid" in txt
