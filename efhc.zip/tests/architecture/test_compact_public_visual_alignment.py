from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_hub_navigation_and_shop_cards_use_compact_alignment() -> None:
    css = read("frontend/src/styles/globals.css")
    card = read("frontend/src/components/ui/GameShell.tsx")
    page = read("frontend/src/features/browser-shop/BrowserShopPage.tsx")
    assert ".efhc-game-nav_item:visited" in css
    assert '.efhc-game-nav_item:not([data-active="true"])' in css
    assert "color:#f5f5f5;" in css
    assert "place-items:start stretch;" in css
    assert 'data-product-card-has-image=' in card
    assert 'data-product-card-has-image="false"' in css
    assert "item.description.trim() !== item.title.trim()" in page
