from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = (
    ROOT
    / "reports/generated/complete_function_linkage_matrix_v171_41.json"
)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_complete_linkage_generator_is_green_and_reproducible() -> None:
    result = subprocess.run(
        [
            sys.executable,
            "ops/linkage/build_complete_function_linkage_matrix.py",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["status"] == "ok"
    assert data["strict_openapi_gate_status"] == "ok"
    assert data["summary"]["total_actions"] >= 80
    assert data["summary"]["public_actions"] >= 35
    assert data["summary"]["admin_actions"] >= 40
    assert data["summary"]["complete"] == data["summary"]["total_actions"]
    assert data["summary"]["partial"] == 0
    assert data["summary"]["direct_ui_transport_files"] == 0
    assert data["blockers"] == []
    rows = {(row["method"], row["path"]) for row in data["rows"]}
    assert ("GET", "/auth/session") in rows
    assert ("POST", "/auth/logout") in rows


def test_every_linkage_row_has_all_required_boundaries() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    for row in data["rows"]:
        assert row["status"] == "complete", row
        assert row["ui_files"], row
        assert row["query_files"], row
        assert row["service_files"], row
        assert row["dto_boundary"] != "missing", row
        assert row["openapi"] is True, row
        assert row["backend_route_file"], row
        assert row["business_boundary"], row
        assert row["db_boundary"], row
        assert row["response_contract"] != "missing", row
        assert row["invalidation_refetch"] != "missing", row


def test_admin_ui_uses_shared_query_service_boundary() -> None:
    hook = read("frontend/src/queries/useAdminLinkedTransport.ts")
    service = read("frontend/src/services/adminLinked.service.ts")
    assert "useMutation" in hook
    assert "queryClient.fetchQuery" in hook
    assert "invalidateQueries" in hook
    assert "adminLinkedRequest" in hook
    assert "apiRequest<unknown>" in service
    assert "parseAdminLinkedResponse" in service
    assert "JsonResponseSchema.parse" in service


def test_public_compatibility_transports_are_removed() -> None:
    assert not (ROOT / "frontend/src/lib/referrals.ts").exists()
    skins = read("frontend/src/lib/skins.ts")
    assert "apiRequest" not in skins
    launcher = read("frontend/src/lib/portal/shopLauncher.ts")
    assert "apiRequest" not in launcher
    ton = read("frontend/src/services/tonConnect.service.ts")
    assert "TonProofPayloadSchema" in ton
    assert "TonProofCheckSchema" in ton
