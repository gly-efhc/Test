from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/VARIABLES_FILTERS_SYSTEM.md"
TSX = ROOT / "frontend/src/components/dashboard/DashboardFilters.tsx"
ADMIN = ROOT / "frontend/src/components/admin/AdminDashboardUiKit.tsx"
SIM = ROOT / "frontend/src/components/dashboard/SimulationDashboardUiKit.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
MAP = ROOT / "map_element.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
REPORT = ROOT / "reports/generated/variables_filters_system_v170_42.json"
KERNEL = ROOT / "KERNEL.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_variables_filters_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_VARIABLES_FILTERS_SYSTEM" in text
    assert "DashboardFilterBar" in text
    assert "DashboardVariableBar" in text
    assert "DashboardFilterChip" in text
    assert "safe_display_only" in text
    assert "No Grafana source code is copied" in text


def test_shared_variables_filters_runtime_components_exist() -> None:
    text = read(TSX)
    required = [
        "export function DashboardFilterBar",
        "export function DashboardVariableBar",
        "export function DashboardFilterChip",
        "export function DashboardFilterResetButton",
        "export function DashboardFilterGroup",
        "isSafeDashboardFilterQueryKey",
        "EFHC_DASHBOARD_VARIABLES_FILTERS_V1",
        "data-dashboard-filter-bar=\"1466\"",
        "data-dashboard-filter-chip=\"1466\"",
        "data-dashboard-filter-reset=\"1466\"",
        "data-dashboard-filter-group=\"1466\"",
    ]
    for marker in required:
        assert marker in text
    forbidden = ["@grafana/", "SceneObject", "apiRequest", "fetch(", "axios"]
    for marker in forbidden:
        assert marker not in text


def test_filter_domains_and_safe_query_boundary_are_declared() -> None:
    text = read(TSX)
    for marker in [
        "status",
        "route",
        "operation_type",
        "user_segment",
        "date_range",
        "source",
        "severity",
        "panel_state",
        "period",
        "leaderboard_scope",
        "task_status",
        "referral_scope",
        "safe_display_only",
        "dashboardFilterForbiddenQueryFragments",
    ]:
        assert marker in text
    for marker in [
        "secret",
        "token",
        "payload",
        "initdata",
        "password",
        "private",
        "seed",
        "mnemonic",
        "tg_id",
    ]:
        assert marker in text


def test_admin_and_simulation_kits_expose_filter_wrappers() -> None:
    admin = read(ADMIN)
    sim = read(SIM)
    for marker in [
        "AdminVariableBar",
        "AdminFilterBar",
        "AdminStatusFilter",
        "AdminOperationTypeFilter",
        "AdminDateRangeFilter",
        "AdminRouteFilter",
        "EFHC_ADMIN_VARIABLES_FILTERS_V1",
    ]:
        assert marker in admin
    for marker in [
        "SimFilterBar",
        "SimPeriodFilter",
        "SimPanelStateFilter",
        "SimLeaderboardScopeFilter",
        "EFHC_SIM_VARIABLES_FILTERS_V1",
    ]:
        assert marker in sim


def test_filters_are_read_only_display_controls() -> None:
    combined = "\n".join([read(TSX), read(ADMIN), read(SIM)])
    forbidden_write_markers = [
        "method: \"POST\"",
        "method: \"PUT\"",
        "method: \"PATCH\"",
        "method: \"DELETE\"",
        "apiRequest(",
        "submit",
        "formAction",
    ]
    for marker in forbidden_write_markers:
        assert marker not in combined
    assert "data-dashboard-filter-readonly=\"true\"" in combined
    assert "type=\"button\"" in combined


def test_variables_filters_css_uses_dashboard_tokens() -> None:
    css = read(CSS)
    required = [
        "Dashboard Variables / Filters System Foundation",
        ".efhc-dashboard-filter-bar",
        ".efhc-dashboard-variable-bar",
        ".efhc-dashboard-filter-chip",
        ".efhc-dashboard-filter-reset",
        "var(--efhc-dash-border)",
        "var(--efhc-dash-info)",
    ]
    for marker in required:
        assert marker in css


def test_grafana_variables_map_is_reference_only() -> None:
    for path in [MAP, GRAFANA_MAP]:
        text = read(path)
        for marker in [
            "Variables",
            "DashboardControls.tsx",
            "TimeRangePicker.tsx",
            "RelativeTimeRangePicker",
            "PageToolbar.tsx",
        ]:
            assert marker in text
        assert "No Grafana source code is copied" in text


def test_variables_filters_report_and_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1466
    assert data["version"] == "v170.42"
    assert data["url_query_sync"]["allowed_mode"] == "safe_display_only"
    assert data["url_query_sync"]["business_truth_source"] is False
    assert data["url_query_sync"]["dangerous_query_keys_rejected"] is True
    assert data["boundaries"]["economy_changed"] is False
    assert data["boundaries"]["backend_contracts_changed"] is False
    assert data["boundaries"]["db_migrations_changed"] is False
    assert data["boundaries"]["new_dependencies_added"] is False
    assert data["boundaries"]["grafana_runtime_code_copied"] is False
    assert data["boundaries"]["sandbox_runtime_code_copied"] is False
    assert data["boundaries"]["write_flows_changed"] is False
    assert data["boundaries"]["money_actions_added"] is False


def test_navigation_points_to_variables_filters_foundation() -> None:
    for path in [KERNEL, MAP, ROUTES]:
        text = read(path)
        assert "VARIABLES_FILTERS_SYSTEM" in text
        assert "DashboardFilters.tsx" in text
        assert "test_variables_filters_system.py" in text


def test_grafana_archive_contains_variables_reference_files() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "PageToolbar.tsx",
        "DashboardVariablesList.tsx",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker
