from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LIST_TEST = ROOT / "tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py"
ROUTE_TEST = ROOT / "tests/efhc_backend/admin/test_admin_withdrawals_routes_runtime.py"
REPORT = ROOT / "reports/generated/fresh_ci_withdrawals_runtime_test_isolation_v171_00.json"
NORM = ROOT / "docs/NORM/FRESH_CI_WITHDRAWALS_RUNTIME_TEST_ISOLATION.md"


def test_withdrawals_runtime_helpers_insert_null_ton_wallet() -> None:
    for path in (LIST_TEST, ROUTE_TEST):
        text = path.read_text(encoding="utf-8")
        assert "ton_wallet," in text
        assert "true, NULL," in text or "false, true, NULL," in text
        assert "true, ''," not in text
        assert "false, true, ''," not in text


def test_cycle_1524_report_records_red_log_root_cause() -> None:
    text = REPORT.read_text(encoding="utf-8")
    assert "logs_74379950976.zip" in text
    assert "uq_users_ton_wallet" in text
    assert "PENDING_WITHDRAW_RUNTIME_TEST_ISOLATION" in text
    assert '"github_ci_green_claimed": false' in text
    assert '"release_ready_claimed": false' in text


def test_norm_records_null_wallet_test_rule() -> None:
    text = NORM.read_text(encoding="utf-8")
    assert "users.ton_wallet" in text
    assert "NULL" in text
    assert "empty string" in text
    assert "uq_users_ton_wallet" in text
