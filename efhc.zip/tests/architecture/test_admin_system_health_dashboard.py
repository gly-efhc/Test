from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def test_admin_system_health_dashboard_docs_exist() -> None:
    for rel in ["docs/NORM/ADMIN_SYSTEM_HEALTH_DASHBOARD.md", "docs/NORM/ADMIN_SYSTEM_HEALTH_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md", "docs/cycles/WORK_CYCLES_1489_ADMIN_SYSTEM_HEALTH_DASHBOARD.md", "reports/generated/admin_system_health_dashboard_v170_65.json", "reports/change_cycle_2026-06-08_v170_65_cycle_1489_admin_system_health_dashboard.md", "frontend/src/components/admin/AdminSystemHealthDashboardRuntime.tsx"]:
        assert (ROOT / rel).exists(), rel

def test_generated_report_records_system_health_boundaries() -> None:
    data = json.loads(read("reports/generated/admin_system_health_dashboard_v170_65.json"))
    assert data["cycle"] == 1489
    assert data["archive_version"] == "v170.65"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["read_only_endpoints"] == ["GET /health", "GET /health/db", "GET /health/runtime"]
    for key in ["dashboard_write_actions_added", "dashboard_idempotency_key_created", "raw_payload_visible", "debug_json_visible", "secrets_visible", "fake_time_series_added", "grafana_runtime_code_copied", "sandbox_runtime_code_copied"]:
        assert data[key] is False

def test_system_health_runtime_component_has_1489_markers() -> None:
    src = read("frontend/src/components/admin/AdminSystemHealthDashboardRuntime.tsx")
    for marker in ["adminSystemHealthDashboardRuntimeVersion", "EFHC_ADMIN_SYSTEM_HEALTH_DASHBOARD_RUNTIME_V1", 'data-admin-system-health-dashboard-runtime="1489"', 'data-admin-system-health-truth="read-only-runtime-health"', 'data-admin-system-health-no-write-actions="true"', 'data-admin-system-health-no-raw-payload="true"', 'data-admin-system-health-no-debug-json="true"', 'data-admin-system-health-no-secrets="true"', 'data-admin-system-health-no-fake-timeseries="true"', 'data-admin-system-health-no-synthetic="true"', 'apiRequest<BasicHealth>("/api/health", "GET")', 'apiRequest<DbHealth>("/api/health/db", "GET")', 'apiRequest<RuntimeHealth>("/api/health/runtime", "GET")', "AdminDashboardToolbar", "AdminRefreshPicker", "AdminFreshnessBadge", "AdminKpiCard", "AdminProgressBar", "AdminHeatStrip", "AdminFlowMapCard", "AdminActionTable"]:
        assert marker in src

def test_system_health_component_has_no_write_flow() -> None:
    src = read("frontend/src/components/admin/AdminSystemHealthDashboardRuntime.tsx")
    for marker in ['"POST"', '"PUT"', '"PATCH"', '"DELETE"', "newIdempotencyKey", "mutateAsync", "synthetic_preview", "raw payload dump", "debug JSON dump", "process.env"]:
        assert marker not in src
    assert "fake time-series" not in src

def test_admin_system_page_integrates_dashboard() -> None:
    page = read("frontend/src/pages/admin/system.tsx")
    assert "AdminSystemHealthDashboardRuntime" in page
    assert "<AdminSystemHealthDashboardRuntime />" in page
    assert "AdminFunctionalPageTemplate" in page

def test_dashboard_plan_and_map_reference_cycle_1489() -> None:
    assert "1489 — Admin System Health Dashboard" in read("docs/NORM/DASHBOARD_VISUAL_PLAN.md")
    assert "1489 — Admin System Health Dashboard" in read("docs/cycles/WORK_CYCLES.md")
    assert "ADMIN_SYSTEM_HEALTH_DASHBOARD.md" in read("map_element.md")
    assert "test_admin_system_health_dashboard.py" in read("docs/testing/TEST_GUARD_MANIFEST.md")
