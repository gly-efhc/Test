from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENERGY = ROOT / "frontend/src/pages/index.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
SUMMARY = ROOT / "frontend/src/components/energy/EnergyMvpSummary.tsx"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORT = (
    ROOT
    / "reports/generated"
    / "frontend_cycle_1278_mobile_proof_v168_76.json"
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_energy_has_mobile_proof_markers() -> None:
    page = _read(ENERGY)
    summary = _read(SUMMARY)
    for marker in [
        'data-energy-mobile-proof="390px"',
        'data-energy-mobile-stage="true"',
    ]:
        assert marker in page
    assert 'data-energy-mobile-actions="aligned"' in summary
    assert 'data-first-screen-action-count="1"' in summary


def test_energy_mobile_css_locks_no_horizontal_overflow() -> None:
    css = _read(CSS)
    mandatory = [
        "work pass: Energy 390px mobile proof",
        "@media (max-width: 390px)",
        "overflow-x: clip",
        "max-width: 100%",
        "min-width: 0",
        "grid-template-columns: 1fr",
    ]
    missing = [marker for marker in mandatory if marker not in css]
    assert missing == []


def test_energy_mobile_action_is_contextual_and_route_limited() -> None:
    text = _read(SUMMARY)
    assert 'href: "/panels"' in text
    assert 'href: "/exchange"' in text
    forbidden = [
        'href: "/hub"',
        'href: "/web-profile"',
        'href: "/tasks"',
        'href: "/browser-shop"',
    ]
    offenders = [marker for marker in forbidden if marker in text]
    assert offenders == []


def test_cycle_1278_is_documented() -> None:
    combined = _read(PLAN) + "\n" + _read(REPORT)
    assert "1278" in combined
    assert "Energy mobile proof pass" in combined
    assert "390px" in combined
    assert "no horizontal scroll" in combined
