from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest
from app.services import referral_service

ROOT = Path(__file__).resolve().parents[2]


def test_referral_level_money_contract_is_present() -> None:
    source = (
        ROOT / "backend/app/services/referral_service.py"
    ).read_text(encoding="utf-8")

    assert (
        'ReferralLevelConfig(level=1, required_active=10, '
        'bonus=d8("1"))'
        in source
    )
    assert (
        'ReferralLevelConfig(level=2, required_active=100, '
        'bonus=d8("10"))'
        in source
    )
    assert (
        'ReferralLevelConfig(level=3, required_active=1000, '
        'bonus=d8("100"))'
        in source
    )
    assert (
        'ReferralLevelConfig(level=4, required_active=3000, '
        'bonus=d8("300"))'
        in source
    )
    assert "required_active=10000" in source
    assert 'bonus=d8("1000")' in source
    assert "referral_level_bonus" in source
    assert "REF_LVL:" in source
    assert "_sync_inviter_level_rewards" in source


@pytest.mark.asyncio
async def test_all_reached_levels_use_atomic_idempotent_bank_credits(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db = object()
    credit_calls: list[dict[str, object]] = []

    async def _resolve_owner(
        candidate_db, *, global_id=None, tg_id=None
    ):
        assert candidate_db is db
        value = int(global_id if global_id is not None else tg_id)
        return referral_service._ReferralOwner(
            global_id=value,
            tg_id=(int(tg_id) if tg_id is not None else value),
        )

    async def _count(
        candidate_db, inviter_global_id: int, legacy_tg_id=None
    ) -> int:
        assert candidate_db is db
        assert inviter_global_id == 990001
        return 10000

    async def _choose(candidate_db, *, canonical_key, legacy_key=None):
        assert candidate_db is db
        from app.identity.idempotency_compat import (
            CompatibleIdempotencyKey,
        )
        return CompatibleIdempotencyKey(
            selected=str(legacy_key or canonical_key),
            canonical=str(canonical_key),
            legacy=legacy_key,
            matched_existing=False,
        )

    async def _credit(**kwargs) -> None:
        credit_calls.append(kwargs)

    monkeypatch.setattr(
        referral_service,
        "_resolve_referral_owner",
        _resolve_owner,
    )
    monkeypatch.setattr(
        referral_service,
        "_count_active_referrals_global",
        _count,
    )
    monkeypatch.setattr(
        referral_service,
        "choose_compatible_idempotency_key",
        _choose,
    )
    monkeypatch.setattr(
        referral_service,
        "credit_user_bonus_from_bank_nocommit",
        _credit,
    )

    await referral_service._sync_inviter_level_rewards(
        db,
        inviter_tg_id=990001,
    )

    assert [item["amount"] for item in credit_calls] == [
        Decimal("1.00000000"),
        Decimal("10.00000000"),
        Decimal("100.00000000"),
        Decimal("300.00000000"),
        Decimal("1000.00000000"),
    ]
    assert [item["reason"] for item in credit_calls] == [
        "referral_level_bonus",
    ] * 5
    assert [item["idempotency_key"] for item in credit_calls] == [
        "REF_LVL:990001:1",
        "REF_LVL:990001:2",
        "REF_LVL:990001:3",
        "REF_LVL:990001:4",
        "REF_LVL:990001:5",
    ]
    assert all(item["db"] is db for item in credit_calls)


def test_level_scale_exposes_cumulative_economic_truth() -> None:
    steps = referral_service.get_referral_level_steps()

    assert [step.level for step in steps] == [1, 2, 3, 4, 5]
    assert [step.required_active for step in steps] == [
        10,
        100,
        1000,
        3000,
        10000,
    ]
    assert steps[0].direct_bonus_total == Decimal("1.00000000")
    assert steps[0].level_bonus == Decimal("1.00000000")
    assert steps[0].cumulative_level_bonus == Decimal("1.00000000")
    assert steps[0].cumulative_total_reward == Decimal("2.00000000")

    assert referral_service.REFERRAL_BONUS_ASSET == "EFHCb"
    assert steps[-1].direct_bonus_total == Decimal("1000.00000000")
    assert steps[-1].cumulative_level_bonus == Decimal("1411.00000000")
    assert steps[-1].cumulative_total_reward == Decimal("2411.00000000")

    assert [step.cumulative_total_reward for step in steps] == [
        Decimal("2.00000000"),
        Decimal("21.00000000"),
        Decimal("211.00000000"),
        Decimal("711.00000000"),
        Decimal("2411.00000000"),
    ]
