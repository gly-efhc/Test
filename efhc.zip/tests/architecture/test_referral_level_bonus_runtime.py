from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest

sqlalchemy = pytest.importorskip("sqlalchemy")
text = sqlalchemy.text

pytestmark = pytest.mark.asyncio


async def _ensure_user(
    db_session,
    *,
    tg_id: int,
    bonus_balance: str = "0.00000000",
) -> int:
    row = await db_session.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, created_at, updated_at",
                    ") VALUES (",
                    "  :tg, NULL, FALSE, TRUE,",
                    "  0, :bb,",
                    "  0, now(), now()",
                    ")",
                    "ON CONFLICT (tg_id) DO UPDATE SET",
                    "  bonus_balance = excluded.bonus_balance,",
                    "  updated_at = now()",
                    "RETURNING id",
                ]
            )
        ),
        {"tg": int(tg_id), "bb": str(bonus_balance)},
    )
    rec = row.first()
    if rec is None:
        q = await db_session.execute(
            text(
                "SELECT id FROM efhc_core.users WHERE tg_id = :tg"
            ),
            {"tg": int(tg_id)},
        )
        rec = q.first()
    assert rec is not None
    return int(rec[0])


async def _insert_panel(db_session, *, user_id: int, n: int) -> None:
    now = datetime.now(UTC)
    await db_session.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.panels (",
                    "  tg_id, is_active, is_archived, public_id,",
                    "  created_at, activated_at, expires_at,",
                    "  base_gen_per_sec, generated_kwh, updated_at",
                    ") VALUES (",
                    "  :uid, TRUE, FALSE, :pid,",
                    "  :now, :now, :exp,",
                    "  0, 0, :now",
                    ")",
                ]
            )
        ),
        {
            "uid": int(user_id),
            "pid": f"IDREF{n:06d}",
            "now": now,
            "exp": now + timedelta(days=180),
        },
    )


async def test_referral_level_bonus_auto_to_bonus_from_bank(
    db_session,
) -> None:
    from app.services.referral_service import (
        on_user_first_panel_purchase,
    )

    inviter_tg = 305001
    buyer_tg = 305099
    await _ensure_user(db_session, tg_id=inviter_tg)

    buyer_user_id = 0
    for idx in range(1, 11):
        tg_id = buyer_tg + idx
        user_id = await _ensure_user(db_session, tg_id=tg_id)
        await db_session.execute(
            text(
                "\n".join(
                    [
                        "INSERT INTO efhc_core.referral_links (",
                        "  inviter_tg_id, invitee_tg_id,",
                        "  created_at, activated_at",
                        ") VALUES (",
                        "  :inv, :ref, :now, :act",
                        ")",
                    ]
                )
            ),
            {
                "inv": inviter_tg,
                "ref": tg_id,
                "now": datetime.now(UTC),
                "act": datetime.now(UTC) if idx < 10 else None,
            },
        )
        if idx < 10:
            await _insert_panel(db_session, user_id=user_id, n=idx)
        else:
            buyer_user_id = user_id

    await _insert_panel(db_session, user_id=buyer_user_id, n=10)
    await db_session.commit()

    await on_user_first_panel_purchase(
        db_session,
        buyer_tg_id=buyer_tg + 10,
    )
    await db_session.commit()

    row = (
        await db_session.execute(
            text(
                "SELECT bonus_balance FROM efhc_core.users "
                "WHERE tg_id = :tg"
            ),
            {"tg": inviter_tg},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("1.10000000")

    bank = (
        await db_session.execute(
            text(
                "SELECT balance FROM efhc_core.bank_balance "
                "WHERE key = 'EFHC_MAIN'"
            )
        )
    ).first()
    assert bank is not None
    assert Decimal(str(bank[0])) == Decimal("-1.10000000")

    lvl = (
        await db_session.execute(
            text(
                "SELECT COUNT(*) FROM efhc_core.efhc_transfers_log "
                "WHERE tg_id = :tg "
                "AND reason = 'referral_level_bonus' "
                "AND balance_type = 'bonus' "
                "AND direction = 'credit' "
                "AND idempotency_key = :idk"
            ),
            {
                "tg": inviter_tg,
                "idk": f"REF_LVL:{inviter_tg}:1",
            },
        )
    ).scalar()
    assert int(lvl or 0) == 1
