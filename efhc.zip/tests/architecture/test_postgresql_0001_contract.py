"""Architecture guard единственного PostgreSQL release head 0001."""

from ops.db.check_postgresql_0001_contract import audit


def test_проверка_postgresql_0001_release_contract() -> None:
    result = audit()
    assert result["passed"], result["errors"]
