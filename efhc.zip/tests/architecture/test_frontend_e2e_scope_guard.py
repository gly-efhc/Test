from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

PUBLIC_ROUTES = [
    '"/"',
    '"/panels"',
    '"/exchange"',
    '"/tasks"',
    '"/referrals"',
    '"/referrals/active"',
    '"/referrals/inactive"',
    '"/ranks"',
    '"/web-profile"',
    '"/faq"',
    '"/hub"',
    '"/browser-shop"',
    '"/withdraw"',
    '"/ads"',
]

ADMIN_ROUTES = [
    '"/admin"',
    '"/admin/bank"',
    '"/admin/users"',
    '"/admin/withdrawals"',
    '"/admin/shop"',
    '"/admin/tasks"',
    '"/admin/reports"',
    '"/admin/diagnostics"',
    '"/admin/system"',
    '"/admin/logs"',
    '"/admin/panels"',
    '"/admin/sale-packages"',
    '"/admin/efhc-deposits"',
    '"/admin/hub"',
    '"/admin/referrals"',
    '"/admin/templates"',
    '"/admin/ads"',
]


def test_frontend_e2e_smoke_public_scope_is_complete() -> None:
    text = (
        ROOT / "tests/frontend/e2e/test_smoke_public_pages.py"
    ).read_text(encoding="utf-8")
    for route in PUBLIC_ROUTES:
        assert route in text, route
    assert "PUBLIC_SMOKE_ROUTES" in text


def test_frontend_e2e_smoke_admin_scope_is_complete() -> None:
    text = (
        ROOT / "tests/frontend/e2e/test_smoke_admin_pages.py"
    ).read_text(encoding="utf-8")
    for route in ADMIN_ROUTES:
        assert route in text, route
    assert "ADMIN_SMOKE_ROUTES" in text


def test_frontend_e2e_interaction_smokes_verify_post_calls() -> None:
    exchange = (
        ROOT / "tests/frontend/e2e/test_exchange_convert_flow.py"
    ).read_text(encoding="utf-8")
    hub = (
        ROOT / "tests/frontend/e2e/test_hub_deposit_button.py"
    ).read_text(encoding="utf-8")
    withdraw = (
        ROOT / "tests/frontend/e2e/test_withdraw_request_flow.py"
    ).read_text(encoding="utf-8")
    assert 'page.route("**/api/exchange/convert", on_convert)' in exchange
    assert "POST /api/hub/efhc-handoff was not called" in hub
    assert "POST /api/withdraw/request was not called" in withdraw
    assert (
        'posted["done"]' in exchange
        and 'posted["done"]' in hub
        and 'posted["done"]' in withdraw
    )
