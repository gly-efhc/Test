from __future__ import annotations

import json
from pathlib import Path

FAQ_JSON = Path("docs/SSOT/faq_ssot/ru/faq_ru.json")
FAQ_MD = Path("docs/SSOT/faq_ssot/ru/faq_ru.md")


def _section_14_items() -> list[dict]:
    data = json.loads(FAQ_JSON.read_text(encoding="utf-8"))
    section = next(s for s in data["sections"] if s["id"] == 14)
    return section["items"]


def test_ru_section_14_wave2_refinement_present() -> None:
    items = _section_14_items()
    assert len(items) == 17
    expected_questions = {
        0: "Когда стоит открыть раздел «Навигация и правила»?",
        9: (
            "По каким признакам понять, что сейчас открыт "
            "не тот раздел?"
        ),
        10: (
            "Какой порядок проверки экранов удобен при "
            "обычном ежедневном входе в WebApp?"
        ),
        11: (
            "Какие разделы полезно проверять регулярно "
            "даже без срочной задачи?"
        ),
        13: (
            "По каким признакам понять, что действие "
            "важное и требует внимательности?"
        ),
    }
    for index, question in expected_questions.items():
        assert items[index]["q"] == question


def test_ru_section_14_wave2_refinement_synced_in_markdown() -> None:
    text = FAQ_MD.read_text(encoding="utf-8")
    required_questions = [
        "### 14-1. Когда стоит открыть раздел «Навигация и правила»?",
        (
            "### 14-10. По каким признакам понять, что сейчас "
            "открыт не тот раздел?"
        ),
        (
            "### 14-11. Какой порядок проверки экранов удобен при "
            "обычном ежедневном входе в WebApp?"
        ),
        (
            "### 14-12. Какие разделы полезно проверять регулярно "
            "даже без срочной задачи?"
        ),
        (
            "### 14-14. По каким признакам понять, что действие "
            "важное и требует внимательности?"
        ),
    ]
    for question in required_questions:
        assert question in text
