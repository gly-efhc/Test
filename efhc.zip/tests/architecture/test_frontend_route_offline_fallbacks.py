from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_route_level_product_fallback_pages_exist() -> None:
    for path in [
        "frontend/src/pages/404.tsx",
        "frontend/src/pages/500.tsx",
        "frontend/src/pages/_error.tsx",
    ]:
        assert (ROOT / path).exists(), path
    assert "common.route_not_found_title" in read("frontend/src/pages/404.tsx")
    assert "common.safe_recoverable_screen_detail" in read("frontend/src/pages/500.tsx")


def test_service_worker_precaches_offline_page() -> None:
    src = read("frontend/public/sw.js")
    assert "event.waitUntil(" in src
    assert 'cacheUrls(config.precache || [], "install")' in src
    assert 'new Response("Offline")' not in src
    assert "Content-Type" in src
