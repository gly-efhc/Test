from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TOKEN = "tg" + "_id"
INVENTORY = ROOT / "reports/generated" / f"{TOKEN}_final_inventory.json"
DISPOSITIONS = ROOT / "ops/identity" / f"{TOKEN}_review_dispositions.json"


def test_очередь_review_identity_inventory_закрыта() -> None:
    data = json.loads(INVENTORY.read_text(encoding="utf-8"))

    assert data["version"] == "v173.27"
    assert data["cycle"] == 1706
    assert data["actionable_or_review"] == 0
    for status in ("OPEN_CONFIRMED", "OPEN_REVIEW", "REVIEW_REQUIRED"):
        assert int(data["statuses"].get(status, 0)) == 0


def test_review_dispositions_точные_и_fail_closed() -> None:
    data = json.loads(DISPOSITIONS.read_text(encoding="utf-8"))

    assert data["schema"] == "EFHC_TG_ID_REVIEW_DISPOSITIONS_V1"
    assert data["version"] == "v173.27"
    assert data["cycle"] == 1706
    assert data["broad_patterns_allowed"] is False
    assert data["entry_count"] == len(data["entries"])

    seen: set[tuple[str, int, int, str, str]] = set()
    for item in data["entries"]:
        assert not any(marker in item["file"] for marker in ("*", "?", "["))
        path = ROOT / item["file"]
        assert path.is_file()
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        line_no = int(item["line_at_review"])
        assert 1 <= line_no <= len(lines)
        fragment = lines[line_no - 1].strip()[:500]
        assert fragment == item["fragment"]
        digest = hashlib.sha256(fragment.encode("utf-8")).hexdigest()
        assert digest == item["fragment_sha256"]
        column = int(item["column_at_review"])
        assert 1 <= column <= max(1, len(lines[line_no - 1]) + 1)
        key = (item["file"], line_no, column, item["token"], digest)
        assert key not in seen
        seen.add(key)


def test_реальные_identity_drifts_цикла_1701_удалены() -> None:
    admin_proof = (
        ROOT / "ops/frontend/admin_visual_button_click_proof.py"
    ).read_text(encoding="utf-8")
    kernel_routes = (
        ROOT / "ops/operator_kernel/config/routes.yaml"
    ).read_text(encoding="utf-8")

    assert '"global_id": "0000001001"' in admin_proof
    assert '"inviter_global_id": "0000001001"' in admin_proof
    assert '"tg' + '_id": 1001' not in admin_proof
    assert '"inviter_tg' + '_id": 1001' not in admin_proof
    assert "legacy Telegram ownership не является authoritative runtime path" in kernel_routes
