from __future__ import annotations

from pathlib import Path

ALLOWED_FILES = {
    "frontend/package-lock.json",
}

ALLOWED_SNIPPETS = {
    "ua-parser-js",
    "registry.npmjs.org/ua-parser-js",
    "opencollective.com/ua-parser-js",
}

SCAN_DIRS = ("backend", "frontend", "ops", "api")
SKIP_SUFFIXES = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".pdf",
    ".woff",
    ".woff2",
    ".ttf",
}


def test_uk_is_only_ukrainian_language_code_in_code() -> None:
    root = Path(__file__).resolve().parents[2]

    for dirname in SCAN_DIRS:
        for path in (root / dirname).rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(root).as_posix()
            if rel in ALLOWED_FILES:
                continue
            if path.suffix in SKIP_SUFFIXES:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if "ua" not in text:
                continue
            for snippet in ALLOWED_SNIPPETS:
                text = text.replace(snippet, "")
            assert '"ua"' not in text, rel
            assert "'ua'" not in text, rel
            assert "ua.json" not in text, rel
