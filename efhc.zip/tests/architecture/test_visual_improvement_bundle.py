"""Guard the complete approved frontend improvement bundle."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_legal_profile_and_trust_improvements_are_active() -> None:
    legal = _read(
        "frontend/src/components/profile/LegalPolicyView.tsx"
    )
    profile = _read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    )
    assert "efhc-legal-index" in legal
    assert "efhc-legal-warning" in legal
    assert "efhc-legal-changes" in legal
    assert "efhc-legal-support-fab" in legal
    assert "profile.trust_legal_title" in profile


def test_admin_security_logs_and_users_improvements_are_active() -> None:
    diagnostics = _read("frontend/src/pages/admin/diagnostics.tsx")
    launcher = _read("frontend/src/pages/admin/index.tsx")
    logs = _read(
        "frontend/src/components/admin/"
        "AdminLogsEventsDashboardRuntime.tsx"
    )
    users = _read("frontend/src/pages/admin/users.tsx")
    assert "AdminRuntimePosturePanel" in diagnostics
    assert "AdminSecurityAttentionBadge" not in launcher
    assert (ROOT / "frontend/src/components/admin/AdminSecurityAttentionBadge.tsx").exists()
    assert "redacted" in logs
    assert "visibleLimit" in logs
    assert "efhc-admin-log-detail-drawer" in logs
    assert "efhc-admin-user-risk-summary" in users


def test_public_money_wallet_and_error_improvements_are_active() -> None:
    withdraw = _read("frontend/src/pages/withdraw.tsx")
    shop = _read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    wallet = _read(
        "frontend/src/components/profile/wallet/"
        "WalletConnectBanner.tsx"
    )
    onboarding = _read("frontend/src/components/OnboardingTour.tsx")
    error = _read("frontend/src/components/ui/SafeErrorState.tsx")
    assert "WithdrawStatusTimeline" in withdraw
    assert "BrowserShopPreSignChecklist" in shop
    assert "efhc-wallet-progress-rail" in wallet
    assert "compact-deep-route" in onboarding
    assert "type ErrorClass = 401 | 403 | 413 | 429 | 500" in error
    assert "safe_error.${props.status}" in error
    for locale in (
        "ru", "en", "uk", "de", "fr", "es", "it",
        "tr", "pl", "da", "hi", "id", "sw",
    ):
        copy = _read(f"frontend/public/locale/{locale}.json")
        for status in ("401", "403", "413", "429", "500"):
            assert f'"safe_error.{status}_title"' in copy
            assert f'"safe_error.{status}_detail"' in copy
            assert f'"safe_error.{status}_action"' in copy


def test_geometry_skeleton_and_responsive_table_guards_are_active() -> None:
    styles = _read("frontend/src/styles/globals.css")
    browser_shop = _read("frontend/src/features/browser-shop/BrowserShopPage.tsx")
    users = _read("frontend/src/pages/admin/users.tsx")
    assert "RouteSkeleton" in browser_shop
    assert "data-route-skeleton" in _read(
        "frontend/src/components/ui/RouteSkeleton.tsx"
    )
    assert "grid-template-columns:repeat(" in styles
    assert "efhc-game-header_statuses" in styles
    assert "efhc-game-nav_icon svg" in styles
    assert "@media(max-width:599px)" in styles
    assert "data-label=\"Пользователь\"" in users


def test_visual_matrix_script_covers_required_states() -> None:
    script = _read(
        "ops/frontend/observability_visual_proof.py"
    )
    for viewport in ("360", "390", "430", "768"):
        assert viewport in script
    for status in ("401", "403", "413", "429"):
        assert status in script
    assert "redacted" in script
    assert "diagnostics" in script
