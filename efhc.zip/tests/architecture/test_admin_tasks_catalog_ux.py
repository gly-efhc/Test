from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_admin_tasks_catalog_component_exists() -> None:
    src = read(
        "frontend/src/components/admin/AdminTasksCatalogUxPanel.tsx"
    )
    assert 'data-admin-tasks-catalog-ux-cycle="1341"' in src
    assert "AdminSectionHeader" in src
    assert "AdminFilterBar" in src
    assert "AdminKpiCard" in src
    assert "AdminFlowMapCard" in src
    assert "AdminActionTable" in src
    assert "AdminEmptyState" in src
    assert "AdminErrorState" in src


def test_admin_tasks_page_uses_catalog_panel() -> None:
    src = read("frontend/src/pages/admin/tasks.tsx")
    assert "AdminTasksCatalogUxPanel" in src
    assert "AdminRouteHealthStrip" not in src
    assert "moderateSubmission" in src
    assert "makeIdempotencyKey" in src
    assert "ADMIN_TASKS_REFRESH_STATUSES_PATH" in src


def test_admin_tasks_styles_exist() -> None:
    css = read("frontend/src/styles/globals.css")
    assert ".efhc-admin-tasks-catalog" in css
    assert ".efhc-admin-tasks-catalog_deck" in css
    assert "@media (max-width:900px)" in css


def test_admin_tasks_docs_and_report_exist() -> None:
    assert (ROOT / "docs/admin/ADMIN_TASKS_CATALOG_UX.md").exists()
    assert (
        ROOT
        / (
            "docs/audits/"
            "FRONTEND_CYCLE_1341_ADMIN_TASKS_"
            "CATALOG_UX_AUDIT_V169_20.md"
        )
    ).exists()
    assert (
        ROOT
        / (
            "reports/"
            "change_cycle_2026-05-30_v169_20_cycle_1341_"
            "admin_tasks_catalog_ux.md"
        )
    ).exists()
    assert (
        ROOT
        / (
            "reports/generated/"
            "frontend_cycle_1341_admin_tasks_catalog_ux_v169_20.json"
        )
    ).exists()


def test_cycle_plan_shifted_to_1342() -> None:
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1341: Admin Tasks catalog UX. DONE in v169_20." in plan
    assert "1342: Admin Tasks execution trace boundary" in plan
    assert "1341 — Admin Tasks catalog UX" in plan


def test_ci_workflow_is_manual_boundary() -> None:
    doc = read("docs/admin/ADMIN_TASKS_CATALOG_UX.md")
    assert "CI/workflow files are not changed silently" in doc
