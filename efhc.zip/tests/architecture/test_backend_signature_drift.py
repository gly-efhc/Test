from __future__ import annotations

import ast
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend" / "app"

BAD_KWARGS: dict[str, set[str]] = {
    "encode_cursor": {"ts", "id"},
    "archive_expired_panels": {"batch_size"},
    "get_referral_stats": {"tg_id"},
    "get_user_rank_and_top": {"limit"},
    "wallet_has_nft_in_collection": {
        "wallet_address",
        "collection_address",
    },
    "format_decimal_str": {"places"},
    "notify_generic": {"title", "level"},
    "approve_withdrawal": {"request_id"},
    "reject_withdrawal": {"request_id"},
}

TARGET_FILES = [
    BACKEND / "services" / "panels_service.py",
    BACKEND / "scheduler" / "archive_panels.py",
    BACKEND / "bot" / "handlers" / "referrals_handlers.py",
    BACKEND / "bot" / "handlers" / "ranks_handlers.py",
    BACKEND / "routes" / "nft_routes.py",
    BACKEND / "routes" / "admin_observability_routes.py",
    BACKEND / "routes" / "admin_reports_routes.py",
    BACKEND / "scheduler" / "withdrawals_processor.py",
    BACKEND / "scheduler" / "reports_daily.py",
    BACKEND / "services" / "admin" / "admin_facade.py",
]

MYPY_REQUIRED_FILES = {
    "backend/app/services/panels_service.py",
    "backend/app/scheduler/archive_panels.py",
    "backend/app/bot/handlers/referrals_handlers.py",
    "backend/app/bot/handlers/ranks_handlers.py",
    "backend/app/routes/nft_routes.py",
    "backend/app/routes/admin_observability_routes.py",
    "backend/app/routes/admin_reports_routes.py",
    "backend/app/scheduler/withdrawals_processor.py",
    "backend/app/scheduler/reports_daily.py",
    "backend/app/services/admin/admin_facade.py",
}


def _call_name(func: ast.expr) -> str | None:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return None


def test_known_signature_drift_bad_kwargs_are_not_used():
    offenders: list[str] = []
    for path in TARGET_FILES:
        tree = ast.parse(path.read_text(), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _call_name(node.func)
            if name not in BAD_KWARGS:
                continue
            bad = BAD_KWARGS[name]
            for kw in node.keywords:
                if kw.arg in bad:
                    rel = path.relative_to(ROOT)
                    marker = f"{rel}:{node.lineno}:{name}.{kw.arg}"
                    offenders.append(marker)

    assert offenders == []


def test_pyproject_mypy_scope_includes_signature_drift_files():
    config = tomllib.loads(
        (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    )
    files = set(config["tool"]["mypy"].get("files", []))
    if "backend/app" in files:
        return
    missing = sorted(MYPY_REQUIRED_FILES - files)
    assert missing == []


def test_notify_generic_call_sites_include_db_and_event():
    offenders: list[str] = []
    for path in TARGET_FILES:
        tree = ast.parse(path.read_text(), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if _call_name(node.func) != "notify_generic":
                continue
            kwargs = {kw.arg for kw in node.keywords}
            if not node.args or "event" not in kwargs:
                rel = path.relative_to(ROOT)
                offenders.append(f"{rel}:{node.lineno}")
    assert offenders == []


def test_withdrawals_processor_uses_uppercase_pending_status():
    path = BACKEND / "scheduler" / "withdrawals_processor.py"
    tree = ast.parse(path.read_text(), filename=str(path))
    offenders: list[int] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Compare):
            continue
        for comparator in node.comparators:
            if (
                isinstance(comparator, ast.Constant)
                and comparator.value == "pending"
            ):
                offenders.append(node.lineno)
    assert offenders == []


def test_admin_facade_withdraw_calls_pass_required_objects():
    path = BACKEND / "services" / "admin" / "admin_facade.py"
    tree = ast.parse(path.read_text(), filename=str(path))
    offenders: list[str] = []
    required = {
        "approve_withdrawal": {"withdrawal_id", "req", "admin"},
        "reject_withdrawal": {
            "withdrawal_id",
            "reason",
            "idempotency_key",
            "admin",
        },
    }
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _call_name(node.func)
        if name not in required:
            continue
        kwargs = {kw.arg for kw in node.keywords}
        missing = sorted(required[name] - kwargs)
        if missing:
            rel = path.relative_to(ROOT)
            offenders.append(f"{rel}:{node.lineno}:{name}:{missing}")
    assert offenders == []
