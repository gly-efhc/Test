from __future__ import annotations

import json
from pathlib import Path

from app.core.config_core import Settings

ROOT = Path(__file__).resolve().parents[2]


def test_production_frontend_build_uses_packaged_assets() -> None:
    package = json.loads(
        (ROOT / "frontend/package.json").read_text(encoding="utf-8")
    )
    scripts = package["scripts"]
    assert "postbuild" not in scripts
    assert scripts["prebuild"] == "node scripts/prebuild.mjs"

    prebuild = (
        ROOT / "frontend/scripts/prebuild.mjs"
    ).read_text(encoding="utf-8")
    assert "verify-production-assets.mjs" in prebuild
    assert "generate_faq_catalogs_from_ssot.py" not in prebuild
    assert "python" not in prebuild.lower()

    manifest = json.loads(
        (
            ROOT / "frontend/release-assets-manifest.json"
        ).read_text(encoding="utf-8")
    )
    assert manifest["schema"] == "EFHC_FRONTEND_RELEASE_ASSETS_V1"
    policy = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )
    assert manifest["version"] == policy["version"]
    assert len(manifest["files"]) == 29


def test_pwa_generation_has_no_runtime_docs_dependency() -> None:
    source = (
        ROOT / "frontend/scripts/generate-pwa-build.mjs"
    ).read_text(encoding="utf-8")
    assert "generate_faq_catalogs_from_ssot.py" not in source
    assert "docs/SSOT" not in source
    assert "release-assets-manifest.json" in source


def test_frontend_timeout_is_vps_safe() -> None:
    source = (
        ROOT / "frontend/scripts/build-next-production.mjs"
    ).read_text(encoding="utf-8")
    assert 'process.env.EFHC_NEXT_BUILD_TIMEOUT_SECONDS || "900"' in source
    assert "Math.max(600" in source
    assert "120_000" not in source


def test_performance_budgets_are_explicit_current_gate() -> None:
    source = (
        ROOT / "frontend/scripts/budgets.mjs"
    ).read_text(encoding="utf-8")
    policy = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )
    assert f'"{policy["version"]}"' in source
    assert f'"{policy["minimum_supported_source_version"]}"' in source
    assert "mkdirSync(dirname(outputPath)" in source
    assert "v171_47" not in source
    assert "v171_46" not in source


def test_deploy_build_and_backup_detection_are_consistent() -> None:
    source = (
        ROOT / "scripts/release/deploy.sh"
    ).read_text(encoding="utf-8")
    assert "compose build --pull migrate frontend" in source
    assert "pg_catalog.pg_tables" in source
    assert "existing EFHC schema detected" in source
    assert "compose ps -q db" not in source


def test_scheduler_env_fields_are_not_ignored() -> None:
    settings = Settings(
        _env_file=None,
        CHECK_TON_INBOX_INTERVAL_SEC=701,
        CHECK_TON_INBOX_TIMEOUT_SEC=902,
        TON_WATCHER_POLL_LIMIT=203,
        TON_WATCHER_RETRY_LIMIT=504,
        TON_RECONCILE_EVERY_TICKS=7,
        TON_RECONCILE_HOURS=25,
    )
    assert settings.CHECK_TON_INBOX_INTERVAL_SEC == 701
    assert settings.CHECK_TON_INBOX_TIMEOUT_SEC == 902
    assert settings.TON_WATCHER_POLL_LIMIT == 203
    assert settings.TON_WATCHER_RETRY_LIMIT == 504
    assert settings.TON_RECONCILE_EVERY_TICKS == 7
    assert settings.TON_RECONCILE_HOURS == 25


def test_all_expected_routes_are_required_in_production() -> None:
    source = (
        ROOT / "backend/app/routes/__init__.py"
    ).read_text(encoding="utf-8")
    assert (
        "REQUIRED_PRODUCTION_ROUTES = frozenset(ROUTERS_EXPECTED)"
        in source
    )
    assert "OPTIONAL_PRODUCTION_ROUTES" in source


def test_release_version_is_final_candidate_number() -> None:
    env = (ROOT / "env.release.example").read_text(encoding="utf-8")
    policy = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )
    version = policy["version"]
    assert f"APP_VERSION={version}" in env
    assert f"EFHC_BACKEND_IMAGE=efhc-backend:{version}" in env
    assert f"EFHC_FRONTEND_IMAGE=efhc-frontend:{version}" in env
    assert "APP_VERSION=v171.70-rc" not in env
    assert "EFHC_NEXT_BUILD_TIMEOUT_SECONDS=900" in env
    compose = (
        ROOT / "docker-compose.release.yml"
    ).read_text(encoding="utf-8")
    assert f"efhc-backend:{version}" in compose
    assert f"efhc-frontend:{version}" in compose
