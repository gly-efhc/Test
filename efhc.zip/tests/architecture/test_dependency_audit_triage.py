from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="ignore")


def load_json(rel: str) -> dict:
    return json.loads(read(rel))


def test_dependency_audit_docs_and_report_exist() -> None:
    required = [
        "docs/NORM/DEPENDENCY_AUDIT_TRIAGE.md",
        "docs/NORM/DEPENDENCY_AUDIT_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1468_DEPENDENCY_AUDIT_TRIAGE.md",
        "reports/generated/dependency_audit_triage_v170_44.json",
        "reports/change_cycle_2026-06-07_v170_44_cycle_1468_dependency_audit_triage.md",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_kernel_keeps_current_and_legacy_markers() -> None:
    kernel = read("KERNEL.md")
    map_element = read("map_element.md")
    nav = kernel + map_element
    assert "v170.44 Dependency Audit Triage" in nav
    assert "Cycle 1468" in nav
    assert "v170.27 / CI log repair" in nav
    assert "1469 — Energy Dashboard Runtime Port" in nav


def test_no_frontend_tsbuildinfo_artifact_in_repo() -> None:
    assert not (ROOT / "frontend/tsconfig.tsbuildinfo").exists()


def test_dependency_versions_are_controlled_and_no_framework_downgrade() -> None:
    package = load_json("frontend/package.json")
    deps = package["dependencies"]
    dev = package["devDependencies"]
    overrides = package.get("overrides", {})

    assert deps["next"] == "16.2.6"
    assert deps["react"] == "19.2.6"
    assert deps["react-dom"] == "19.2.6"
    assert dev["tailwindcss"] == "4.3.0"

    assert deps["axios"] == "1.18.0"
    assert deps["@ton/ton"] == "16.3.0"
    assert dev["postcss"] == "^8.5.10"
    assert overrides["axios"] == "$axios"
    assert overrides["follow-redirects"] == "^1.15.12"
    assert overrides["postcss"] == "$postcss"


def test_package_lock_resolves_audit_repair_versions() -> None:
    lock = load_json("frontend/package-lock.json")
    packages = lock["packages"]

    assert packages["node_modules/@ton/ton"]["version"] == "16.3.0"
    assert packages["node_modules/axios"]["version"] >= "1.16.0"
    assert packages["node_modules/follow-redirects"]["version"] >= "1.15.12"
    assert packages["node_modules/postcss"]["version"] >= "8.5.10"
    assert "node_modules/next/node_modules/postcss" not in packages


def test_generated_report_records_zero_vulnerabilities() -> None:
    report = load_json("reports/generated/dependency_audit_triage_v170_44.json")
    assert report["npm_audit_before"] == {
        "total": 5,
        "moderate": 3,
        "high": 2,
    }
    assert report["npm_audit_after"]["total"] == 0
    assert report["npm_audit_after"]["critical"] == 0
    assert report["runtime_code_copied_from_grafana"] is False
    assert report["runtime_code_copied_from_sandbox"] is False
    assert report["economy_changed"] is False
    assert report["ci_workflow_changed"] is False


def test_dashboard_plan_shift_is_documented() -> None:
    plan = read("docs/NORM/DASHBOARD_VISUAL_PLAN.md")
    cycles = read("docs/cycles/WORK_CYCLES.md")
    assert "1455–1496" in plan
    assert "42" in plan
    assert "Цикл 1468 — Dependency Audit Triage" in plan
    assert "Цикл 1469 — Energy Dashboard Runtime Port" in plan
    assert "Direction Handoff" in plan or "backlog freeze" in plan
    assert "14 / 42" in cycles
    assert "1469 — Energy Dashboard Runtime Port" in cycles


def test_map_and_routes_register_dependency_audit_triage() -> None:
    routes = read("ops/operator_kernel/config/routes.yaml")
    map_element = read("map_element.md")
    manifest = read("docs/testing/TEST_GUARD_MANIFEST.md")

    assert "dependency_audit_triage" in routes
    assert "docs/NORM/DEPENDENCY_AUDIT_TRIAGE.md" in routes
    assert "tests/architecture/test_dependency_audit_triage.py" in routes
    assert "Cycle 1468 — v170.44 Dependency Audit Triage" in map_element
    assert "Cycle 1468 — Dependency Audit Triage guard" in manifest


def test_no_runtime_code_from_grafana_or_sandbox_is_copied() -> None:
    doc = read("docs/NORM/DEPENDENCY_AUDIT_GRAFANA_ELEMENT_ANALYSIS.md")
    report = load_json("reports/generated/dependency_audit_triage_v170_44.json")

    assert "Runtime code was not copied" in doc
    assert "framework runtime" in doc
    assert report["grafana_reference_only"] is True
    assert report["sandbox_reference_only"] is True


def test_no_force_audit_fix_or_ci_workflow_change_claim() -> None:
    doc = read("docs/NORM/DEPENDENCY_AUDIT_TRIAGE.md")
    change = read(
        "reports/change_cycle_2026-06-07_v170_44_cycle_1468_dependency_audit_triage.md"
    )
    assert "npm audit fix --force` не использовался" in doc
    assert "No backend, database, OpenAPI" in change
    assert "CI/workflow" in change
