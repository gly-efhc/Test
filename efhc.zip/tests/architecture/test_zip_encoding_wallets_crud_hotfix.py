from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC_DIR = ROOT / "docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md"

LONG_BAD_NAMES = (
    "┬½╨╢╨╕╨▓╤ï╨╡┬╗_╤é╨╛╤ç╨║╨╕_╤ü╨░╨╝╨╛"
    "╨▓╨╛╤ü╤ü╤é╨░╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤Å_╨ÿ╨ÿ_"
    "╨╖╨░╤ë╨╕╤é_╨▓_╨╜╨░╤ê╨╡╨╝_╤é╨╡╨║╤â"
    "╤ë╨╡╨╝_╤ü╤Ç╨╡╨╖╨╡ (2).md",
    "╨ö╨₧╨ƒ╨₧╨¢╨¥╨ò╨¥╨ÿ╨ò_╨Ü_╨ó╨ù_EFHC_Bot_v3_1_"
    "╨▓╨╛╤ü╤ü╤é╨░╨╜╨╛╨▓╨╗╨╡╨╜╨╕╨╡_"
    "╨┐╨╛╤é╨╡╤Ç╤Å╨╜╨╜╤ï╤à_╤ä╤â╨╜╨║╤å╨╕╨╣_.md",
)

ASCII_REPLACEMENTS = (
    "ai_self_recovery_protection_points.md",
    "efhc_bot_tz_lost_functions_recovery.md",
)


def test_original_sources_extract_to_fifteen_md_files() -> None:
    assert SRC_DIR.is_dir()
    assert len(list(SRC_DIR.glob("*.md"))) == 15


def test_problematic_original_source_names_are_ascii_now() -> None:
    for name in ASCII_REPLACEMENTS:
        path = SRC_DIR / name
        assert path.exists()
        assert path.name.isascii()
        assert len(path.name.encode("utf-8")) < 180


def test_old_problematic_zip_names_are_absent() -> None:
    existing = {path.name for path in SRC_DIR.glob("*.md")}
    for name in LONG_BAD_NAMES:
        assert name not in existing


def test_wallets_crud_uses_canonical_wallets_model() -> None:
    text = (ROOT / "backend/app/crud/wallets_crud.py").read_text(
        encoding="utf-8"
    )
    assert "from app.models.wallets_models import WalletBinding" in text
    assert (
        "from app.models.wallet_models import WalletBinding" not in text
    )


def test_cycle_1352_docs_exist() -> None:
    required = [
        "docs/GENERAL/ORIGINAL_SOURCES_ZIP_NAME_ENCODING_FIX.md",
        "docs/backend/WALLETS_CRUD_IMPORT_CANON.md",
        "docs/audits/ZIP_ENCODING_WALLETS_CRUD_HOTFIX_V169_31.md",
        "reports/change_cycle_2026-05-31_v169_31_cycle_1352_zip_"
        "encoding_wallets_crud_hotfix.md",
    ]
    for rel in required:
        assert (ROOT / rel).exists()
