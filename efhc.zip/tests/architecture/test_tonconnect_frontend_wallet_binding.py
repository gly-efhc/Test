from __future__ import annotations

from pathlib import Path


def test_tonconnect_frontend_binds_wallet_after_proof() -> None:
    text = Path("frontend/src/components/Layout.tsx").read_text(
        encoding="utf-8",
    )
    adapter = Path(
        "frontend/src/lib/wallet-provider/adapters/TonConnectAdapter.ts"
    ).read_text(encoding="utf-8")
    assert "bindVerifiedTonConnectWallet" not in text
    assert "bindWallet(proofState)" in text
    assert "bindVerifiedTonConnectWallet(" in adapter
    assert "current.raw" in adapter
    assert 'setConnectionPhase("verifying")' in text
    assert "submitTonProofEnvelope(wallet, proofState)" not in text


def test_tonconnect_helper_calls_wallets_connect() -> None:
    helper = Path("frontend/src/lib/tonconnect.ts").read_text(
        encoding="utf-8",
    )
    service = Path(
        "frontend/src/services/tonConnect.service.ts"
    ).read_text(encoding="utf-8")
    assert '"/wallets/connect"' in service
    assert "connectVerifiedTonWallet" in helper
    assert "idempotencyKey:" in helper
    assert "payload_token: proofState.payload_token" in helper
    assert "signature: String(proof.signature" in helper
    assert "public_key: wallet?.account?.publicKey" in helper
    assert "network: wallet?.account?.chain" in helper


def test_static_tonconnect_manifest_is_documented_as_fallback() -> None:
    app = Path("frontend/src/pages/_app.tsx").read_text(
        encoding="utf-8"
    )
    app_shell_service = Path(
        "frontend/src/services/appShell.service.ts"
    ).read_text(encoding="utf-8")
    manifest = Path(
        "frontend/public/tonconnect-manifest.json"
    ).read_text(encoding="utf-8")
    assert "buildTonConnectManifestUrl" in app
    assert "/api/tonconnect-manifest" in app_shell_service
    assert "FALLBACK ONLY" in manifest
