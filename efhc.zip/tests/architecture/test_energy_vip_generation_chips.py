from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENERGY = ROOT / "frontend/src/pages/index.tsx"
SUMMARY = ROOT / "frontend/src/components/energy/EnergyMvpSummary.tsx"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORT = (
    ROOT
    / "reports/generated"
    / "frontend_cycle_1277_energy_chips_v168_75.json"
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_energy_chips_are_exactly_canonical_generation_chips() -> None:
    text = _read(ENERGY)
    mandatory = [
        'data-energy-chip-count="3"',
        'data-energy-chip="active-panels"',
        'data-energy-chip="generation-rate"',
        'data-energy-chip="available-kwh"',
        "gen_per_sec_effective",
        "available_kwh",
        "active_count",
    ]
    missing = [marker for marker in mandatory if marker not in text]
    assert missing == []


def test_energy_does_not_render_vip_wallet_or_exchange_blocks() -> None:
    text = _read(ENERGY)
    for marker in [
        'data-energy-status="vip"',
        "is_vip={Boolean(s.profile.is_vip)}",
        "profile.main_balance",
        "profile.bonus_balance",
        'href="/exchange"',
        'href="/hub"',
    ]:
        assert marker not in text

def test_energy_keeps_named_level_and_no_contextual_action() -> None:
    text = _read(ENERGY)
    assert 'data-energy-level-name={levelName}' in text
    assert "USER_LEVEL_SKINS" in text
    assert "EnergyMvpSummary" not in text

def test_cycle_1277_is_documented() -> None:
    combined = _read(PLAN) + "\n" + _read(REPORT)
    assert "1277" in combined
    assert "Energy VIP status and generation chips" in combined
    assert "active panels" in combined
    assert "generation rate" in combined
    assert "available kWh" in combined
