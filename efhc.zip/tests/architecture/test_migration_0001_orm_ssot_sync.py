from __future__ import annotations

import csv
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _ssot_count(root: Path) -> int:
    p = root / "docs" / "SSOT" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
    with p.open("r", encoding="utf-8") as f:
        rows = [
            row
            for row in csv.DictReader(f)
            if (row.get("table") or "").strip()
        ]
    return len(rows)


def test_migration_docs_use_current_ssot_table_count() -> None:
    root = _repo_root()
    count = _ssot_count(root)
    docs = [
        root / "docs" / "NORM" / "ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md",
        root / "docs" / "SSOT" / "SSOT_DB_0001_CANON.md",
        root / "docs" / "audits" / "MIGRATION_0001_ORM_SSOT_AUDIT.md",
    ]
    for doc in docs:
        text = doc.read_text(encoding="utf-8")
        assert (
            str(count) in text
        ), f"missing current count in {doc.as_posix()}"
        assert (
            "31" not in text
        ), f"stale count 31 remains in {doc.as_posix()}"


def test_migration_docs_keep_two__schema__canon() -> None:
    root = _repo_root()
    docs = [
        root / "docs" / "NORM" / "ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md",
        root / "docs" / "SSOT" / "SSOT_DB_0001_CANON.md",
    ]
    for doc in docs:
        text = doc.read_text(encoding="utf-8")
        assert "efhc_core" in text
        assert "efhc_admin" in text
        assert "все таблицы в efhc_core" not in text
        assert "только в `efhc_core`" not in text
