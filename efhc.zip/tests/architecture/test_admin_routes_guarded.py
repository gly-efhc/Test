from pathlib import Path


def _is_admin_route_file(path: Path) -> bool:
    txt = path.read_text(encoding="utf-8")
    if 'prefix="/admin"' in txt or "prefix='/admin'" in txt:
        return True
    return "'/admin'" in txt or '"/admin"' in txt


def test_admin_routes_are_guarded() -> None:
    root = Path(__file__).resolve().parents[2]
    routes_dir = root / "backend" / "app" / "routes"
    assert routes_dir.exists(), str(routes_dir)

    bad: list[str] = []
    for path in sorted(routes_dir.rglob("*.py")):
        if path.name in {"init.py", "__init__.py"}:
            continue
        if not _is_admin_route_file(path):
            continue
        txt = path.read_text(encoding="utf-8")
        if "require_admin" not in txt:
            bad.append(str(path.relative_to(root)))

    assert not bad, "Admin routes without require_admin: " + ", ".join(
        bad
    )
