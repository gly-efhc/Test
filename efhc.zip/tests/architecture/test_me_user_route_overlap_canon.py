from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_user_me_is_the_only_self_profile_route() -> None:
    text = (ROOT / "backend/app/routes/user_routes.py").read_text(
        encoding="utf-8",
    )
    assert '"/me"' in text
    assert '"/{tg_id}/me"' not in text
    assert "Depends(get_nonfinancial_read_owner)" in text
    assert "global_id=owner.global_id" in text


def test_docs_do_not_reference_removed_api_user_profile() -> None:
    checked = [
        ROOT / "docs/GENERAL/specification.md",
        ROOT / "docs/GENERAL/architecture.md",
        ROOT / "docs/NORM/API_CONTRACTS.md",
    ]
    for path in checked:
        text = path.read_text(encoding="utf-8")
        assert (
            "/api/user/profile" not in text
        ), f"stale self-profile route in {path.relative_to(ROOT)}"


def test_docs_fix_me_user_surface_contract() -> None:
    text = (ROOT / "docs/NORM/API_CONTRACTS.md").read_text(
        encoding="utf-8",
    )
    assert "GET /api/v1/me" in text
    assert "GET /user/me" in text
    assert "GET /user/{tg_id}/me" not in text
