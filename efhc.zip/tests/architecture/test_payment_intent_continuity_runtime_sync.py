from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_payment_intent_runtime_truth_exposes_canonical_fields() -> (
    None
):
    text = _read("backend/app/services/payment_intents_service.py")
    for needle in [
        '"product_state":',
        '"next_action":',
        '"return_path":',
        '"canonical_center": "web_profile"',
    ]:
        assert needle in text


def test_hub_truth_and_schemas_keep_runtime_continuity_fields() -> None:
    hub_schema = _read("backend/app/schemas/hub_schemas.py")
    pay_schema = _read("backend/app/schemas/payment_intents_schemas.py")
    hub_route = _read("backend/app/routes/hub_routes.py")
    for needle in [
        "product_state: str",
        "next_action: str",
        "return_path: str",
        "canonical_center: str",
    ]:
        assert needle in hub_schema
        assert needle in pay_schema
    assert "flow_truth=flow_truth" in hub_route
    assert "product_state=product_state" in hub_route
    assert "next_action=next_action" in hub_route
    assert "return_path=return_path" in hub_route
    assert "canonical_center=canonical_center" in hub_route


def test_wallet_readiness_flags_are_runtime_canonical() -> None:
    hub_schema = _read("backend/app/schemas/hub_schemas.py")
    hub_route = _read("backend/app/routes/hub_routes.py")
    portal = _read("frontend/src/lib/portal/shopLauncher.ts")
    for needle in [
        "wallet_ready: bool",
        "wallet_blocked: bool",
        "action_allowed: bool",
        "action_denied: bool",
        "readiness_state: str",
        "primary_cta: str",
    ]:
        assert needle in hub_schema
    for needle in [
        'wallet_ready=bool(readiness["wallet_ready"])',
        'action_denied=bool(readiness["action_denied"])',
        'readiness_state=str(readiness["readiness_state"])',
        'primary_cta=str(readiness["primary_cta"])',
    ]:
        assert needle in hub_route
    assert "flow?.action_denied" in portal
    assert 'primaryCta === "sync_wallet"' in portal


def test_efhc_deposits_runtime_becomes_automation_first() -> None:
    admin_routes = _read("backend/app/routes/admin_routes.py")
    admin_page = _read("frontend/src/pages/admin/efhc-deposits.tsx")
    ssot = _read("docs/NORM/EFHC_DEPOSITS_PRODUCTION_GRADE_STATUS.md")
    assert '"/efhc-deposits/runtime-summary"' in admin_routes
    assert '"/efhc-deposits/reprocess/{tx_hash}"' in admin_routes
    assert 'release_mode: str = "release_core_eligible"' in admin_routes
    assert (
        'automation_mode: str = "automated_with_operator_fallback"'
        in admin_routes
    )
    assert "reprocess_single_tx" in admin_routes
    assert "Replay automated path" in admin_page
    assert "operator_exception_path" in admin_page
    assert "release_core_eligible" in ssot


def test_store_launcher_is_isolated_from_direct_deposit() -> None:
    portal = _read("frontend/src/lib/portal/shopLauncher.ts")
    launcher = _read("frontend/src/queries/useShopLauncher.ts")
    deposit = _read("frontend/src/components/DepositModal.tsx")
    browser_shop = _read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    assert "getShopLauncherResult" in portal
    assert 'primaryCta === "open_telegram_handoff"' in portal
    assert 'primaryCta === "unavailable"' in portal
    assert "truth.telegram_sync_url" in launcher
    assert "getShopLauncherResult" not in deposit
    assert "telegram_handoff_required" not in deposit
    assert 'data-direct-deposit-kind="efhc-jetton-to-efhcm"' in deposit
    assert (
        'flow?.action_denied || flow?.primary_cta === "sync_wallet"'
        not in portal
    )
    assert 'readinessState === "wallet_sync_required"' in browser_shop
    assert "walletSyncRequired" in browser_shop
    assert "openTelegramLink" in browser_shop
    assert "bootstrap?.telegram_sync_url" in browser_shop


def test_active_intent_resume_contract_is_backend_first() -> None:
    hub_route = _read("backend/app/routes/hub_routes.py")
    browser_shop = _read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    assert (
        "active_intent = await _get_active_intent_truth(" in hub_route
    )
    assert '"Active intent already exists; "' in hub_route
    assert "resume the current payment path" in hub_route
    assert (
        'flowTruth?.next_step === "resume_intent"'
        in browser_shop
    )
    assert "bootstrap?.active_payment" in browser_shop
    assert "useBrowserShopIntentStatus" in browser_shop
    assert "statusQ.refetch()" in browser_shop


def test_terminal_and_non_terminal_payment_wording_stays_canonical() -> (
    None
):
    service = _read("backend/app/services/payment_intents_service.py")
    continuity = _read("frontend/src/lib/portal/continuityCopy.ts")
    profile = _read("frontend/src/components/ProfileModal.tsx")
    browser_shop = _read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    for needle in [
        '"Payment confirmed. EFHC were already credited.',
        '"The intent expired. Create a new intent',
        '"The payment was detected, but it requires an',
        'return "wait_network"',
    ]:
        assert needle in service
    for needle in [
        'case "wait_network":',
        'case "pay_or_wait":',
        "pending external confirmation",
    ]:
        assert needle in continuity
    assert 'return "no active payment";' in profile
    assert "return `Active payment · ${asset}`;" in profile
    assert 'raw === "CONFIRMED"' in browser_shop
    assert '["EXPIRED", "CANCELED", "FAILED"]' in browser_shop
    assert 'return "checking";' in browser_shop


def test_return__path__and_canonical_center_stay_backend_first() -> (
    None
):
    hub_route = _read("backend/app/routes/hub_routes.py")
    continuity = _read("frontend/src/lib/portal/continuityCopy.ts")
    browser_shop = _read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    hub_page = _read("frontend/src/features/hub/HubPage.tsx")
    web_profile = _read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    )
    profile_modal = _read("frontend/src/components/ProfileModal.tsx")
    assert "data-profile-status-model" in web_profile
    assert "active_payment" in web_profile
    assert 'canonical_center = "web_profile"' in hub_route
    assert "active_intent.flow_truth.canonical_center" in hub_route
    assert "canonical_center=canonical_center" in hub_route
    assert "canonicalCenter?: string | null" in continuity
    assert "Continue the execution path in Browser-Shop." in continuity
    assert (
        "Return to Web-Profile as the canonical account and"
        in continuity
    )
    assert (
        'flowTruth?.canonical_center || "web_profile"'
        in browser_shop
    )
    assert "useHubEfhcHandoff" in hub_page
    assert "canonical_center" not in hub_page
    assert "canonical_center" in web_profile
    assert "flow.canonical_center" in profile_modal


def test_profile_modal_role_split_and_withdraw_labels_stay_canonical() -> (
    None
):
    profile = _read("frontend/src/components/ProfileModal.tsx")
    web_profile = _read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    )
    continuity = _read("frontend/src/lib/portal/continuityCopy.ts")
    for needle in [
        "Quick overlay only. Use it for shortcuts and current status.",
        (
            "Detailed account, payment, and history views stay in Web-"
            "Profile."
        ),
        'PENDING: "pending"',
        'APPROVED: "approved"',
        'PAID: "paid"',
        'REJECTED: "rejected"',
        'CANCELED: "canceled"',
    ]:
        assert needle in profile
    assert "Open Web-Profile" in profile
    assert "History shortcut" in profile
    assert (
        "Web-Profile stays the canonical account center;" in continuity
    )
    assert "data-profile-status-model" in web_profile


def test_outcome_edge_cases_keep_user_and_surface_consistency() -> None:
    service = _read("backend/app/services/payment_intents_service.py")
    profile = _read("frontend/src/components/ProfileModal.tsx")
    web_profile = _read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    )
    for needle in [
        '"product_state": "manual_review"',
        '"product_state": "expired"',
        '"product_state": "terminal_failed"',
        '"next_step": "create_new_intent"',
        '"next_step": "wait_manual_review"',
        "without crediting funds.",
    ]:
        assert needle in service
    for needle in [
        'flow.product_state === "terminal_success"',
        'flow.product_state === "terminal_failed"',
        'flow.product_state === "expired"',
        'flow.lifecycle_stage === "manual_review"',
    ]:
        assert needle in profile
    for needle in [
        "active_payment",
        "latest_withdraw_status",
        "latest_withdraw_outcome",
        "canonical_center",
        "ProfileHistorySection",
    ]:
        assert needle in web_profile


def test_efhc_deposits_operator_chain_stays_audit_first() -> None:
    admin_page = _read("frontend/src/pages/admin/efhc-deposits.tsx")
    admin_routes = _read("backend/app/routes/admin_routes.py")
    assert 'title="Предпочтительная audit chain"' in admin_page
    assert "1) runtime summary, 2) replay automated path," in admin_page
    assert (
        "3) process exception only if unresolved, 4) final result "
        "detail."
        in admin_page
    )
    assert 'label="Final result"' in admin_page
    assert (
        "Result path after replay or exception processing."
        in admin_page
    )
    assert (
        'detail="Failed to replay automated EFHC deposit path."'
        in admin_routes
    )


def test_admin_shell_isolates_helper_and_deferred_modules() -> None:
    admin_index = _read("frontend/src/pages/admin/index.tsx")
    diagnostics = _read("frontend/src/pages/admin/diagnostics.tsx")
    assert 'href: "/admin/efhc-deposits"' in admin_index
    assert 'state: "live"' in admin_index
    assert 'releaseTier: "core"' in admin_index
    assert (
        '"/admin/efhc-deposits", "/admin/sale-packages"'
        not in admin_index
    )
    assert 'title="Release-core finance actions"' in diagnostics
    assert 'href: "/admin/efhc-deposits"' in diagnostics
    assert 'title="Support and helper sections"' in diagnostics
    assert 'href: "/admin/diagnostics"' in diagnostics
    assert 'href: "/admin/ads"' in diagnostics
    assert 'href: "/admin/sale-packages"' in diagnostics


def test_admin_release_core_evidence_pack_stays_honest() -> None:
    admin_index = _read("frontend/src/pages/admin/index.tsx")
    diagnostics = _read("frontend/src/pages/admin/diagnostics.tsx")
    audit = _read(
        "docs/audits/ADMIN_RELEASE_CORE_EVIDENCE_PACK_951_2026_04_18.md"
    )
    assert "AdminAppButtonGrid" in admin_index
    assert "AdminAppButtonGrid" in admin_index
    assert "Банк" in admin_index or "admin.section_bank" in admin_index
    assert "/admin/diagnostics" not in admin_index
    assert "/admin/system" not in admin_index
    assert "Диагностика" in diagnostics or "System" in diagnostics
    assert "Отчёты" in admin_index or "Reports" in admin_index
    assert "Пополнить EFHC" not in admin_index or "EFHC" in admin_index
    assert 'title="Current release-core evidence subset"' in diagnostics
    assert "withdrawals · release-core payout/outcome" in diagnostics
    assert (
        "Sale packages"
        not in audit.split("## Включено")[1].split("##")[0]
    )


def test_release_core_runtime_walkthrough_and_white_spots_docs_exist() -> (
    None
):
    walkthrough = _read(
        "docs/audits/RELEASE_CORE_RUNTIME_WALKTHROUGH_952_2026_04_18.md"
    )
    closure = _read("docs/audits/WHITE_SPOTS_CLOSURE_953_2026_04_18.md")
    assert (
        "Telegram -> Hub -> Browser-Shop -> Web-Profile -> outcome"
        in walkthrough
    )
    assert "ProfileModal = quick overlay" in walkthrough
    assert "admin shell do this" not in walkthrough
    assert "Release-core evidence pack" in closure
    assert "Current release-core evidence subset" in closure


def test_exchange_and_panels_edge_case_guards_stay_bounded() -> None:
    exchange_page = _read("frontend/src/pages/exchange.tsx")
    exchange_panel = _read("frontend/src/components/ExchangePanel.tsx")
    panels_page = _read("frontend/src/pages/panels.tsx")
    assert "pending={exchangeMutation.isPending}" in exchange_page
    assert "disabled={disabled}" in exchange_panel
    assert 't("exchange.processing")' in exchange_panel
    assert (
        "const activating = activationMutation.isPending"
        in panels_page
    )
    assert (
        "if (!globalId || activating || !canActivatePanel) return;"
        in panels_page
    )
    assert "Panel activation needs at least 100 EFHCm." in panels_page


def test_helper_and_deferred_surfaces_keep_beta_visibility() -> None:
    diagnostics = _read("frontend/src/pages/admin/diagnostics.tsx")
    sale_packages = _read(
        "frontend/src/features/admin/AdminSalePackagesPage.tsx"
    )
    assert '{ label: "beta", tone: "warning" }' in diagnostics
    assert "Beta helper/internal route overview" in diagnostics
    assert "Deferred beta read-only snapshot" in diagnostics
    assert '{ label: "beta", tone: "warning" }' in sale_packages
    assert (
        'TelegramStatusBadge label="beta" tone="warning"'
        in sale_packages
    )
