from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_faq_search_and_admin_large_filters_use_workers() -> None:
    faq = read("frontend/src/hooks/faq/useFaqSearch.ts")
    admin = read("frontend/src/hooks/admin/useLargeAdminFilter.ts")
    assert "faqSearch.worker.ts" in faq
    assert "WORKER_THRESHOLD = 10_000" in admin
    assert "adminFilter.worker.ts" in admin


def test_locale_checksum_and_safe_public_query_persistence() -> None:
    i18n = read("frontend/src/lib/i18n.ts")
    persistence = read("frontend/src/lib/publicCatalogPersistence.ts")
    query_keys = read("frontend/src/queries/queryKeys.ts")
    assert "locale_checksums" in i18n
    assert "cached.checksum === checksum" in i18n
    assert 'SAFE_PREFIX = "public-static"' in persistence
    assert "MAX_BYTES" in persistence
    assert "publicStatic" in query_keys
    for forbidden in ("balance", "withdraw", "wallet", "payment", "admin"):
        assert f'"{forbidden}"' not in persistence.lower()


def test_cache_is_byte_bounded_adaptive_and_persistent_on_consent() -> None:
    sw = read("frontend/public/sw.js")
    status = read("frontend/src/components/PwaRuntimeStatus.tsx")
    assert "max_bytes" in sw
    assert "keptBytes" in sw
    assert "max_entries: 520" in status
    assert "navigator.storage.persist" in status
    assert "appinstalled" in status
    assert "CACHE_PROGRESS" in status


def test_prefetch_uses_recent_safe_navigation_and_save_data_guard() -> None:
    status = read("frontend/src/components/PwaRuntimeStatus.tsx")
    assert "NAV_HISTORY_KEY" in status
    assert "predictedRoutes" in status
    assert "SAFE_PREFETCH_ROUTES" in status
    assert "FINANCIAL_ROUTES" in status
    assert "saveData" in status
    assert "slow-2g" in status


def test_priority_hint_and_image_support_telemetry_are_present() -> None:
    document = read("frontend/src/pages/_document.tsx")
    image_support = read(
        "frontend/src/services/imageFormatSupport.service.ts"
    )
    assert 'fetchPriority="high"' in document
    assert "efhc_image_format_support_v1" in image_support
    assert "avif" in image_support
    assert "webp" in image_support


def test_vitals_have_percentiles_platform_and_build_id() -> None:
    vitals = read("frontend/src/services/webVitals.service.ts")
    for marker in ("p50", "p75", "p95", "buildId", "platform"):
        assert marker in vitals
    for platform in (
        "telegram-android",
        "telegram-ios",
        "telegram-desktop",
        "browser-android",
        "browser-ios",
        "browser-desktop",
    ):
        assert platform in vitals


def test_compressed_budgets_compare_previous_release() -> None:
    budgets = read("frontend/scripts/budgets.mjs")
    assert "EFHC_RELEASE_VERSION" in budgets
    assert "EFHC_BASELINE_VERSION" in budgets
    policy = json.loads(read("release_config/UPDATE_POLICY.json"))
    assert f'"{policy["version"]}"' in budgets
    assert f'"{policy["minimum_supported_source_version"]}"' in budgets
    assert "v171_47" not in budgets
    assert "v171_46" not in budgets
    assert "gzip_delta_percent" in budgets
    assert "brotli_delta_percent" in budgets
    assert "REGRESSION_REVIEW" in budgets


def test_read_only_offline_mode_is_explicit_and_financially_safe() -> None:
    status = read("frontend/src/components/PwaRuntimeStatus.tsx")
    offline = read("frontend/public/offline-readonly.html")
    sw = read("frontend/public/sw.js")
    assert 'data-pwa-offline-mode="public-read-only"' in status
    assert "offline-readonly.html" in sw
    for marker in ("FAQ", "Privacy", "Terms"):
        assert marker in offline
    assert "/api/" in sw
    assert "/admin/" in sw


def test_github_workflow_and_root_mirror_are_equal() -> None:
    assert read("ci.yml") == read(".github/workflows/canon.yml")
    workflow = read("ci.yml")
    assert "PYTHONPATH=backend pytest -q" in workflow
    assert "npm ci" in workflow
    assert "npm run build" in workflow
    assert "Chromium visual audit" in workflow
    assert "all_pages_route_backed_visual_audit.py" in workflow
