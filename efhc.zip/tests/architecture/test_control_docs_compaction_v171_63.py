from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_consolidated_kernel_standard_is_active() -> None:
    standard = read("docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md")
    assert "Status: ACTIVE NORM" in standard
    assert "Compound request" in standard
    for name in ("FIRST", "PATCH", "PERMISSION", "VALIDATION"):
        pointer = read(f"docs/NORM/EFHC_OPERATOR_KERNEL_{name}_STANDARD.md")
        assert "DEPRECATED PATH" in pointer
        assert "EFHC_OPERATOR_KERNEL_STANDARD.md" in pointer


def test_stale_startup_and_machine_map_rules_are_removed() -> None:
    start = read("START_HERE.md")
    kernel = read("KERNEL.md")
    budget = read("docs/AI/READING_BUDGET.md")
    assert "EFHC_OPERATOR_KERNEL_STANDARD.md" in start
    assert "EFHC_OPERATOR_KERNEL_STANDARD.md" in kernel
    assert "1,500,000" not in budget
    assert "500,000" not in budget
    assert "file_map.summary.json" in read("docs/AI/READING_ENTRYPOINT.md")


def test_legacy_continuation_prompts_are_history_only() -> None:
    history = read("docs/history/LEGACY_CONTINUE_PROMPTS.md")
    assert "HISTORICAL" in history
    assert not list((ROOT / "docs/AI").glob("CONTINUE_NEW_CHAT_*.md"))


def test_exact_duplicate_and_wrong_layer_files_are_removed() -> None:
    assert not (ROOT / "docs/audits/FRONTEND_CYCLE_1323_ADMIN_BANK_SANDBOX_VISUAL_AUDIT_V168_101.md").exists()
    assert not (ROOT / "docs/audits/FRONTEND_CYCLE_1322_ADMIN_USERS_READABILITY_AUDIT_V168_100.md").exists()
    assert (ROOT / "docs/audits/FRONTEND_CYCLE_1323_ADMIN_BANK_SANDBOX_VISUAL_AUDIT_V169_01.md").exists()
    assert (ROOT / "docs/audits/FRONTEND_CYCLE_1322_ADMIN_USERS_READABILITY_AUDIT_V169_00.md").exists()
    assert not (ROOT / "docs/NORM/WALLETS_TONCONNECT_SSOT.md").exists()
    assert (ROOT / "docs/SSOT/WALLETS_TONCONNECT_SSOT.md").exists()
    assert not (ROOT / "docs/GENERAL/API_SERVICE_REACT_QUERY_MIGRATION_GATE.md").exists()
    assert (ROOT / "docs/NORM/API_SERVICE_REACT_QUERY_MIGRATION_GATE.md").exists()


def test_active_control_filenames_are_bounded() -> None:
    roots = ["docs/AI", "docs/SSOT", "docs/NORM", "docs/healer", "ops/operator_kernel", "tests/architecture"]
    violations = []
    for rel in roots:
        for path in (ROOT / rel).rglob("*"):
            if path.is_file() and len(path.name.encode("utf-8")) > 120:
                violations.append(path.relative_to(ROOT).as_posix())
    assert violations == []
