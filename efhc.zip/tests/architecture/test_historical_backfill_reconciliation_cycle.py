"""После squash historical backfill не является активной migration фазой."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_release_0001_создаёт_финальную_schema_без_historical_backfill() -> None:
    source = (
        ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source
    assert "users.global_id" in source
    assert "users.user_id physical column forbidden" in source
    assert "financial_read_global_id_enabled" in source
    assert "nonfinancial_read_global_id_enabled" in source


def test_postgresql_environment_сохраняет_real_transaction_boundary() -> None:
    source = (ROOT / "backend/migrations/env.py").read_text(
        encoding="utf-8"
    )
    assert "bootstrap_connection" in source
    assert 'isolation_level="AUTOCOMMIT"' in source
    assert "with connectable.connect() as connection:" in source
    assert "with context.begin_transaction():" in source
