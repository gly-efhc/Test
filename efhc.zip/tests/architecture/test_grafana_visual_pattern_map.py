from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md"
REPORT = ROOT / "reports/generated/grafana_visual_pattern_map_v170_33.json"
PLAN = ROOT / "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_grafana_visual_pattern_map_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_GRAFANA_REFERENCE_MAP_FOR_DASHBOARD_DIRECTION" in text
    assert "Grafana is visual-pattern reference only" in text
    assert "PanelChrome" in text
    assert "DashboardGrid" in text
    assert "AdminTimeRangePicker" in text
    assert "Synthetic preview data" in text
    assert "1458 — Dashboard Design Tokens Foundation" in text


def test_grafana_visual_pattern_map_machine_report() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1457
    assert data["version"] == "v170.33"
    assert data["grafana_reference"]["testzip"] is None
    assert data["grafana_reference"]["file_count"] > 1000
    assert data["pattern_count"] >= 12
    assert data["next_cycle"]["cycle"] == 1458


def test_grafana_visual_map_keeps_reference_only_boundary() -> None:
    data = load(REPORT)
    assert data["grafana_reference"]["runtime_code_copied"] is False
    assert data["grafana_reference"]["dependencies_copied"] is False
    assert data["grafana_reference"]["lock_files_copied"] is False
    assert data["sandbox_reference"]["runtime_code_copied"] is False
    assert data["safety"]["economy_changed"] is False
    assert data["safety"]["backend_contracts_changed"] is False
    assert data["safety"]["tests_deleted_or_disabled"] is False


def test_required_patterns_have_efhc_targets() -> None:
    data = load(REPORT)
    joined = "\n".join(
        f"{p['pattern']} -> {p['efhc_component']}"
        for p in data["patterns"]
    )
    required = [
        "PanelChrome -> AdminPanelChrome / SimPanelChrome",
        "DashboardGrid -> AdminDashboardGrid / SimDashboardGrid",
        "Refresh picker -> AdminRefreshPicker",
        "Time range picker -> AdminTimeRangePicker",
        "Variables and filters -> AdminVariableBar",
        "BigValue / Stat card -> AdminStatCard",
        "Sparkline and mini charts -> AdminSparkline",
    ]
    for marker in required:
        assert marker in joined


def test_navigation_points_to_grafana_pattern_map() -> None:
    assert "v170.33 / Grafana Visual Pattern Map" in read(KERNEL)
    assert "GRAFANA_VISUAL_PATTERN_MAP.md" in read(PLAN)
    assert "GRAFANA_VISUAL_PATTERN_MAP.md" in read(MAP)
    routes = read(ROUTES)
    assert "docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md" in routes
    assert "grafana_visual_pattern_map_v170_33.json" in routes
