from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TX = ROOT / "backend/app/services/transactions_service.py"

REMOVED_ALIASES = {
    "credit_user__main__from_bank_by_tg_id",
    "credit_user_bonus_from_bank_by_tg_id",
    "debit_user__main__to_bank_by_tg_id",
    "debit_user_bonus_to_bank_by_tg_id",
}


def test_безопасные_денежные_алиасы_удалены() -> None:
    tree = ast.parse(TX.read_text(encoding="utf-8"))
    definitions = {
        node.name
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    assert not (REMOVED_ALIASES & definitions)


def test_provider_ingress_не_считается_owner_alias() -> None:
    telegram = (
        ROOT / "backend/app/identity/telegram_auth_session.py"
    ).read_text(encoding="utf-8")
    watcher = (
        ROOT / "backend/app/services/watcher_service.py"
    ).read_text(encoding="utf-8")
    assert "_lock_user_by_tg_id" in telegram
    assert "_find_user_by_tg_id" in watcher


def test_неиспользуемый_payment_status_alias_удалён() -> None:
    payment = (
        ROOT / "backend/app/services/payment_intents_service.py"
    ).read_text(encoding="utf-8")
    assert "STATUS_SENT = STATUS_PENDING" not in payment
