from ops.operator_kernel.route_resolver import resolve_route


def test_operator_kernel_default_route_avoids_heavy_paths():
    route = resolve_route("operator_kernel")
    start = "\n".join(route["start_core"])
    assert "docs/audits/*" not in start
    assert "reports/*" not in start
    assert "full backend" not in start
    assert "full frontend" not in start
    assert "docs/audits/*" in route["forbidden_default_heavy"]
    assert "full backend" in route["forbidden_default_heavy"]
