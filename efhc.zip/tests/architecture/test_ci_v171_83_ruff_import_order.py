from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_admin_facade_sqlalchemy_import_follows_app_imports() -> None:
    source = (
        ROOT / "backend/app/services/admin/admin_facade.py"
    ).read_text(encoding="utf-8")

    app_import = source.index(
        "from app.services.admin.admin_withdrawals_service"
    )
    sqlalchemy_import = source.index(
        "from sqlalchemy.ext.asyncio import AsyncSession"
    )
    assert app_import < sqlalchemy_import


def test_referral_sqlalchemy_imports_follow_app_imports() -> None:
    source = (
        ROOT / "backend/app/services/referral_service.py"
    ).read_text(encoding="utf-8")

    app_import = source.index(
        "from app.services.transactions_service import"
    )
    sqlalchemy_text = source.index(
        "from sqlalchemy import func, select, text"
    )
    sqlalchemy_async = source.index(
        "from sqlalchemy.ext.asyncio import AsyncSession"
    )
    assert app_import < sqlalchemy_text < sqlalchemy_async
