from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ROUTE_FILE = ROOT / "backend/app/routes/admin_withdrawals_routes.py"
SERVICE_FILE = (
    ROOT / "backend/app/services/admin/admin_withdrawals_service.py"
)
MODEL_FILE = ROOT / "backend/app/models/withdraw_models.py"


def _parse(path: Path) -> ast.AST:
    return ast.parse(path.read_text(encoding="utf-8"))


def _find_async_func(tree: ast.AST, name: str) -> ast.AsyncFunctionDef:
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == name:
            return node
    raise AssertionError(f"async def {name} not found")


def test_admin_reject_route_matches_service_signature() -> None:
    route_tree = _parse(ROUTE_FILE)
    service_tree = _parse(SERVICE_FILE)
    route_fn = _find_async_func(route_tree, "admin_reject")
    service_fn = _find_async_func(service_tree, "reject_withdrawal")
    service_args = {arg.arg for arg in service_fn.args.kwonlyargs}
    assert "idempotency_key" in service_args

    found = False
    for node in ast.walk(route_fn):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if not isinstance(func, ast.Attribute):
            continue
        if func.attr != "reject_withdrawal":
            continue
        kws = {kw.arg for kw in node.keywords if kw.arg is not None}
        assert "idempotency_key" in kws
        found = True
        break
    assert found, "WithdrawalsService.reject_withdrawal call not found"


def test_admin_withdrawals_joins_use_users_tg_id() -> None:
    text = SERVICE_FILE.read_text(encoding="utf-8")
    assert "u.id = w.tg_id" not in text
    assert "u.id = b.tg_id" not in text
    assert "u.tg_id = w.tg_id" in text
    assert "u.tg_id = b.tg_id" in text


def test_withdraw_request_model_matches_admin_service_columns() -> None:
    text = MODEL_FILE.read_text(encoding="utf-8")
    assert "external_address" in text
    assert "processing_idempotency_key" in text
