from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COMPONENT = ROOT / "frontend/src/components/BrowserLoginDemo.tsx"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
LOCALE_DIR = ROOT / "frontend/public/locale"


REQUIRED_KEYS = [
    "browser_login.badge",
    "browser_login.title",
    "browser_login.subtitle",
    "browser_login.telegram_cta",
]


LEGACY_PREVIEW_KEYS = [
    "browser_login.demo_note",
    "browser_login.preview_title",
]


def test_browser_login_demo_component_exists() -> None:
    text = COMPONENT.read_text(encoding="utf-8")
    assert "export function BrowserLoginDemo" in text
    assert "https://t.me/efhc_bot/app" in text
    assert "window.open" in text
    assert 'data-browser-shell-mode="preview"' in text
    assert "Energy demo" not in text


def test_layout_renders_demo_when_no_telegram_provider() -> None:
    text = LAYOUT.read_text(encoding="utf-8")
    assert "import { BrowserLoginDemo }" in text
    assert "showBrowserLoginDemo" in text
    assert "!props.telegramProviderId" in text
    assert "<BrowserLoginDemo t={t} />" in text


def test_browser_login_is_compact_banner_not_duplicate_energy_preview() -> None:
    component = COMPONENT.read_text(encoding="utf-8")
    css = CSS.read_text(encoding="utf-8")
    assert ".efhc-browser-login" in css
    assert ".efhc-browser-login_primary" in css
    assert ".efhc-browser-login_copy" in css
    assert ".efhc-browser-login_preview" not in component
    assert "KwhIcon" not in component
    for key in LEGACY_PREVIEW_KEYS:
        assert key not in component


def test_browser_login_locale_keys_exist_for_all_13_languages() -> None:
    paths = sorted(LOCALE_DIR.glob("*.json"))
    assert len(paths) == 13
    missing: list[str] = []
    for path in paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in REQUIRED_KEYS:
            if key not in data or not str(data[key]).strip():
                missing.append(f"{path.name}:{key}")
    assert missing == []
