from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HUB = ROOT / "frontend/src/features/hub/HubPage.tsx"
SHOP = ROOT / "frontend/src/features/browser-shop/BrowserShopPage.tsx"
HOOKS = ROOT / "frontend/src/queries/useBrowserShop.ts"
SERVICE = ROOT / "frontend/src/services/browserShop.service.ts"
ENERGY = ROOT / "frontend/src/pages/index.tsx"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_public_hub_has_two_canonical_actions_without_commerce_copy() -> None:
    hub = read(HUB)
    assert hub.count('data-hub-action=') == 2
    assert 'data-hub-visible-action-count="2"' in hub
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in hub
    assert 'data-hub-action="top-up"' in hub
    assert 'data-hub-action="vip-nft"' in hub
    assert "hub.action_top_up_efhc" in hub
    assert "hub.action_vip_nft" in hub
    assert "https://getgems.io/efhc-nft" in hub
    top_up = hub.split('data-hub-action="top-up"', 1)[1].split(
        'data-hub-action="vip-nft"', 1
    )[0]
    for marker in [
        "purchase",
        "checkout",
        "browser-shop",
        "ton / gram",
        "usdt",
        "price",
    ]:
        assert marker not in top_up.lower()


def test_hub_top_up_locale_copy_is_neutral_in_all_languages() -> None:
    forbidden = re.compile(
        r"(куп|покуп|магаз|витрин|shop|buy|purchase|store|checkout|"
        r"ton|gram|usdt|acheter|compr|acquist|satın|køb|beli)",
        re.IGNORECASE,
    )
    for path in sorted((ROOT / "frontend/public/locale").glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        active_values = " ".join(
            str(data[key])
            for key in (
                "hub.action_top_up_efhc",
                "hub.clean_description",
                "hub.action_top_up_efhc_description",
                "hub.efhc_modal_body",
            )
        )
        assert forbidden.search(active_values) is None, path.name
        assert data["hub.action_vip_nft"].strip(), path.name


def test_browser_shop_uses_query_linking_return_ttl_and_polling() -> None:
    page = read(SHOP)
    hooks = read(HOOKS)
    service = read(SERVICE)
    assert "useBrowserShopAccessKey" in page
    assert "useBrowserShopBootstrap" in page
    assert "useBrowserShopCatalog" in page
    assert "useBrowserShopCreateIntent" in page
    assert "useBrowserShopIntentStatus" in page
    assert "createBrowserShopAccessKey" in service
    assert "SHOPFRONT_ACCESS_KEY_PATH" in service
    assert "parseShopfrontAccessResponse" in service
    assert "sessionStorage" in page
    assert 'url.searchParams.set("sku"' in page
    assert 'url.searchParams.set("method"' in page
    assert "window.location.assign(url)" in page
    assert "expires_at" in page
    assert "formatRemaining" in page
    assert 'data-browser-shop-linking="telegram-web-return"' in page
    assert 'data-browser-shop-polling="react-query-5000ms"' in page
    assert "refetchInterval" in hooks
    assert "5_000" in hooks
    assert "TERMINAL" in hooks


def test_browser_shop_has_both_payment_methods_and_compact_surface() -> None:
    page = read(SHOP)
    css = read(CSS)
    assert "portal.browser_shop.pay_ton_gram" in page
    assert "portal.browser_shop.pay_usdt_ton_gram" in page
    assert 'data-browser-shop-checkout="ton-usdt"' in page
    assert "efhc-browser-shop-trust-rail" not in page
    assert "ready_packages_detail" not in page
    assert "stepper" not in page.lower()
    assert ".efhc-browser-shop-account-bar" in css
    assert ".efhc-browser-shop-payment-strip" in css
    assert ".efhc-browser-shop-methods" in css
    assert "grid-template-columns:repeat(2,minmax(0,1fr));" in css


def test_energy_and_navigation_are_compact_and_overflow_safe() -> None:
    energy = read(ENERGY)
    layout = read(LAYOUT)
    css = read(CSS)
    icon = read(ROOT / "frontend/src/components/icons/KwhIcon.tsx")
    assert 'data-energy-range-safe="true"' in energy
    assert 'data-energy-level-name={levelName}' in energy
    assert "USER_LEVEL_SKINS" in energy
    assert "EnergyMvpSummary" not in energy
    assert 'data-energy-chip-count="3"' in energy
    assert 'data-energy-chip="available-kwh"' in energy
    assert 'data-nav-geometry="wide-rounded-six"' in layout
    assert 'data-nav-icon-system="rounded-outline-v2"' in layout
    assert 'data-nav-slot={props.slot}' in layout
    assert "premium-dock-v3" not in layout + css
    assert "floating-console-six" not in layout + css
    assert "layered-line-v3" not in layout + css
    assert 'data-energy-mark="balanced-lightning-v2"' in icon
    assert "premium-energy-core-v3" not in icon + css


def test_current_norms_lock_two_hub_actions_and_shop_checkout() -> None:
    hub_ssot = read(ROOT / "docs/SSOT/HUB_SSOT.md")
    ai = read(ROOT / "docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md")
    norm = read(ROOT / "docs/NORM/HUB_BROWSER_SHOP_COMPACT_CHECKOUT_NORM.md")
    locks = read(ROOT / "docs/NORM/ARCHITECTURAL_LOCKS.md")
    combined = "\n".join((hub_ssot, ai, norm, locks))
    assert "exactly two visible actions" in combined
    assert "EFHC VIP NFT" in combined
    assert "GetGems" in combined
    assert "React Query polling every five seconds" in combined
    assert "return to the same checkout" in combined
    assert "request a user decision" in combined
