from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BUILD_SCRIPT = ROOT / "ops" / "build_efhc_zip.sh"
FORBIDDEN_SUFFIXES = {".pyc", ".pyo", ".tsbuildinfo", ".log"}
FORBIDDEN_DIRS = {
    "__pycache__",
    "node_modules",
    ".next",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
    ".cache",
    ".local_artifacts",
    "logs",
}
# Test runners may create these during collection. They remain excluded by
# the release build script and ZIP post-pack guard, but this repo-scan test
# must not fail only because pytest created its own cache while running.
TRANSIENT_RUNTIME_DIRS = {".pytest_cache", ".ruff_cache"}
TRANSIENT_RUNTIME_PATHS = {
    Path("tests/__pycache__"),
}


def _is_transient_bytecode(rel: Path) -> bool:
    return "__pycache__" in rel.parts or rel.suffix == ".pyc"


REQUIRED_BUILD_EXCLUDES = (
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".cache",
    ".local_artifacts",
    "logs/",
    "*.log",
    "node_modules",
    ".next",
    "*.pyc",
    "*.pyo",
    "*.tsbuildinfo",
)


def _is_transient_runtime_path(rel: Path) -> bool:
    if rel.parts and rel.parts[0] in TRANSIENT_RUNTIME_DIRS:
        return True
    if rel in TRANSIENT_RUNTIME_PATHS:
        return True
    return any(
        parent in TRANSIENT_RUNTIME_PATHS for parent in rel.parents
    )


def test_no_forbidden_frontend_artifacts_in_repo() -> None:
    bad: list[str] = []
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT)
        if _is_transient_runtime_path(rel):
            continue
        if _is_transient_bytecode(rel):
            continue
        if any(part in FORBIDDEN_DIRS for part in rel.parts):
            bad.append(str(rel))
            continue
        if path.is_file() and any(
            path.name.endswith(suf) for suf in FORBIDDEN_SUFFIXES
        ):
            bad.append(str(rel))
    assert not bad, f"forbidden artifacts found: {bad[:20]}"


def test_build_script_excludes_release_artifacts() -> None:
    text = BUILD_SCRIPT.read_text(encoding="utf-8")
    missing = [
        item for item in REQUIRED_BUILD_EXCLUDES if item not in text
    ]
    assert not missing, (
        "build script misses release excludes: " f"{missing}"
    )
