from __future__ import annotations

import json
from pathlib import Path

FAQ_DIR = Path("docs/SSOT/faq_ssot")
TARGETS = {
    "3-7": {
        "da": "Hvornår bør jeg bruge knappen “Top up” i topbjælken?",
        "de": (
            "Wann sollte ich die Schaltfläche „Aufladen“ in "
            "der oberen Leiste verwenden?"
        ),
        "en": "When should I use the Top Up button in the top bar?",
        "es": (
            "¿Cuándo conviene usar el botón «Recargar» de la "
            "barra superior?"
        ),
        "fr": (
            "Quand faut-il utiliser le bouton « Recharger » "
            "dans la barre supérieure ?"
        ),
        "hi": "ऊपरी पैनल में “Top up” बटन का उपयोग कब करना चाहिए?",
        "id": (
            "Kapan sebaiknya saya menggunakan tombol “Top Up” "
            "di panel atas?"
        ),
        "it": (
            "Quando conviene usare il pulsante “Top Up” nella "
            "barra superiore?"
        ),
        "pl": "Kiedy warto używać przycisku „Doładuj” w górnym panelu?",
        "sw": (
            "Ni wakati gani nifae kutumia kitufe cha “Top up” "
            "kwenye paneli ya juu?"
        ),
        "tr": (
            "Üst paneldeki “Yatır” düğmesini ne zaman kullanmak "
            "gerekir?"
        ),
        "uk": (
            "Коли варто використовувати кнопку «Поповнити» "
            "у верхній панелі?"
        ),
    },
    "3-8": {
        "da": "Hvorfor åbne Hub fra topbjælken?",
        "de": "Warum sollte man Hub über die obere Leiste öffnen?",
        "en": "Why open Hub from the top bar?",
        "es": "¿Por qué abrir Hub desde la barra superior?",
        "fr": "Pourquoi ouvrir Hub depuis la barre supérieure ?",
        "hi": "ऊपरी बार से Hub क्यों खोलें?",
        "id": "Mengapa membuka Hub dari bilah atas?",
        "it": "Perché aprire Hub dalla barra superiore?",
        "pl": "Po co otwierać Hub z górnego paska?",
        "sw": "Kwa nini kufungua Hub kutoka kwenye upau wa juu?",
        "tr": "Hub’ı üst çubuktan neden açmalıyım?",
        "uk": "Навіщо відкривати Hub з верхньої панелі?",
    },
    "8-6": {
        "da": (
            "Hvorfor tælles tilgængelig energi og hovedsaldo "
            "separat?"
        ),
        "de": (
            "Warum werden verfügbare Energy und Hauptsaldo "
            "getrennt gezählt?"
        ),
        "en": (
            "Why are available energy and main balance counted "
            "separately?"
        ),
        "es": (
            "¿Por qué la energía disponible y el saldo principal "
            "se cuentan por separado?"
        ),
        "fr": (
            "Pourquoi l’énergie disponible et le solde principal "
            "sont-ils comptés séparément ?"
        ),
        "hi": (
            "Available energy और main balance अलग-अलग क्यों गिने जाते " "हैं?"
        ),
        "id": (
            "Mengapa available energy dan saldo utama dihitung "
            "terpisah?"
        ),
        "it": (
            "Perché l’energia disponibile e il saldo principale "
            "vengono conteggiati separatamente?"
        ),
        "pl": (
            "Dlaczego dostępna energia i saldo główne są liczone "
            "osobno?"
        ),
        "sw": (
            "Kwa nini nishati inayopatikana na salio kuu "
            "huhesabiwa tofauti?"
        ),
        "tr": (
            "Neden kullanılabilir enerji ile ana bakiye ayrı "
            "hesaplanır?"
        ),
        "uk": (
            "Чому доступна енергія і основний баланс рахуються "
            "окремо?"
        ),
    },
    "8-7": {
        "da": (
            "Hvorfor vokser energien af sig selv, mens hovedsaldoen "
            "ikke stiger automatisk?"
        ),
        "de": (
            "Warum wächst Energy von selbst, während der "
            "Hauptsaldo nicht automatisch steigt?"
        ),
        "en": (
            "Why does energy grow by itself while the main balance "
            "does not increase automatically?"
        ),
        "es": (
            "¿Por qué la energía crece sola, pero el saldo "
            "principal no aumenta automáticamente?"
        ),
        "fr": (
            "Pourquoi l’énergie augmente-t-elle d’elle-même alors "
            "que le solde principal n’augmente pas automatiquement ?"
        ),
        "hi": (
            "Energy अपने आप बढ़ती है, लेकिन main balance अपने आप "
            "क्यों नहीं बढ़ता?"
        ),
        "id": (
            "Mengapa energy bertambah sendiri, tetapi saldo utama "
            "tidak naik otomatis?"
        ),
        "it": (
            "Perché l’energia cresce da sola mentre il saldo "
            "principale non aumenta automaticamente?"
        ),
        "pl": (
            "Dlaczego energia rośnie sama, a saldo główne nie "
            "zwiększa się automatycznie?"
        ),
        "sw": (
            "Kwa nini nishati inaongezeka yenyewe lakini salio kuu "
            "haliongezeki moja kwa moja?"
        ),
        "tr": (
            "Enerji neden kendi kendine artıyor da ana bakiye neden "
            "otomatik olarak büyümüyor?"
        ),
        "uk": (
            "Чому енергія зростає сама, а основний баланс не "
            "збільшується автоматично?"
        ),
    },
    "16-8": {
        "da": (
            "Hvorfor kan min rangering flytte sig uden nye "
            "handlinger fra mig?"
        ),
        "de": (
            "Warum kann sich mein Ranking verschieben, auch wenn ich "
            "keine neuen Aktionen ausgeführt habe?"
        ),
        "en": (
            "Why can my ranking move even without any new actions "
            "from me?"
        ),
        "es": (
            "¿Por qué mi ranking puede moverse aunque yo no haya "
            "hecho nuevas acciones?"
        ),
        "fr": (
            "Pourquoi mon classement peut-il bouger sans nouvelles "
            "actions de ma part ?"
        ),
        "hi": (
            "मेरे नए actions के बिना भी मेरी ranking क्यों बदल सकती " "है?"
        ),
        "id": (
            "Mengapa peringkat saya bisa bergeser tanpa ada "
            "tindakan baru dari saya?"
        ),
        "it": (
            "Perché il mio ranking può spostarsi anche senza nuove "
            "azioni da parte mia?"
        ),
        "pl": (
            "Dlaczego mój ranking może się przesuwać bez moich "
            "nowych działań?"
        ),
        "sw": (
            "Kwa nini rank yangu inaweza kusogea bila mimi kufanya "
            "hatua mpya?"
        ),
        "tr": (
            "Yeni bir işlem yapmasam bile sıralamam neden yer "
            "değiştirebilir?"
        ),
        "uk": ("Чому мій рейтинг може зрушуватися без моїх нових дій?"),
    },
    "16-10": {
        "da": (
            "Hvorfor kan min rangering falde, selv om jeg gør "
            "fremskridt?"
        ),
        "de": (
            "Warum kann mein Ranking sinken, obwohl ich selbst "
            "Fortschritte mache?"
        ),
        "en": (
            "Why can my ranking go down even when I am making "
            "progress?"
        ),
        "es": (
            "¿Por qué mi ranking puede bajar incluso cuando yo "
            "progreso?"
        ),
        "fr": (
            "Pourquoi mon classement peut-il baisser même quand je "
            "progresse ?"
        ),
        "hi": (
            "मेरी खुद की progress होने पर भी मेरी ranking नीचे क्यों "
            "जा सकती है?"
        ),
        "id": (
            "Mengapa peringkat saya bisa turun meskipun saya sedang "
            "berkembang?"
        ),
        "it": (
            "Perché il mio ranking può scendere anche se sto facendo "
            "progressi?"
        ),
        "pl": (
            "Dlaczego mój ranking może spadać nawet wtedy, gdy robię "
            "postępy?"
        ),
        "sw": (
            "Kwa nini rank yangu inaweza kushuka hata kama "
            "ninaendelea kupiga hatua?"
        ),
        "tr": (
            "İlerleme kaydediyor olsam bile sıralamam neden "
            "düşebilir?"
        ),
        "uk": (
            "Чому рейтинг може знижуватися навіть за мого власного "
            "прогресу?"
        ),
    },
}


def _load(lang: str) -> dict:
    path = FAQ_DIR / lang / f"faq_{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _get_question(data: dict, target: str) -> str:
    sec_id, item_pos = target.split("-")
    sec = next(s for s in data["sections"] if str(s["id"]) == sec_id)
    return sec["items"][int(item_pos) - 1]["q"]


def test_translation_wave2_wave_synced_after_ru_cleanup() -> None:
    mismatches: list[str] = []
    for target, per_lang in TARGETS.items():
        for lang, expected in per_lang.items():
            data = _load(lang)
            actual = _get_question(data, target)
            if actual != expected:
                mismatches.append(f"{target}:{lang}:{actual}")
    assert not mismatches, mismatches
