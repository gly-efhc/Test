from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_pwa_manifest_is_installable_and_has_shortcuts() -> None:
    data = json.loads(read("frontend/public/manifest.webmanifest"))
    assert data["id"] == "/"
    assert data["display"] == "standalone"
    assert "standalone" in data["display_override"]
    assert len(data["shortcuts"]) == 3
    assert all("maskable" in icon["purpose"] for icon in data["icons"])


def test_service_worker_caches_only_safe_public_resources() -> None:
    sw = read("frontend/public/sw.js")
    for marker in [
        'const BUILD_CONFIG_URL = "/pwa-build.json"',
        'const CACHE_PREFIX = "efhc-pwa-"',
        "cacheFirst",
        "staleWhileRevalidate",
        "navigationFallback",
        'pathname.startsWith("/admin/")',
        '"/api/"',
        '"/health"',
        '"/meta/"',
    ]:
        assert marker in sw
    assert "POST" not in sw


def test_http_cache_policy_supports_traffic_savings() -> None:
    config = read("frontend/next.config.js")
    assert 'source: "/sw.js"' in config
    assert "no-cache, no-store, must-revalidate" in config
    assert 'source: "/locale/:path*"' in config
    assert "stale-while-revalidate=604800" in config
    assert 'source: "/assets/:path*"' in config
    i18n = read("frontend/src/lib/i18n.ts")
    assert 'cache: "default"' in i18n
    assert 'fetch(`/locale/${lang}.json`, {' in i18n
    assert 'cache: "default"' in i18n
    assert 'fetch("/pwa-build.json", {' in i18n


def test_telegram_webview_and_safe_area_contract_stays_active() -> None:
    telegram = read("frontend/src/lib/telegram.ts")
    layout = read("frontend/src/components/Layout.tsx")
    document = read("frontend/src/pages/_document.tsx")
    assert 'data-tma-shell="telegram|browser"' not in telegram
    assert "data-tma-shell-polish" in layout
    css = read("frontend/src/styles/globals.css")
    assert "--tg-content-safe-top" in telegram
    assert "--tg-content-safe-bottom" in telegram
    assert "--efhc-safe-top" in css
    assert "--efhc-safe-bottom" in css
    assert "viewport-fit=cover" in document


def test_wcag_keyboard_focus_and_network_status_are_visible() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    css = read("frontend/src/styles/globals.css")
    network = read("frontend/src/components/NetworkStatus.tsx")
    assert 'href="#efhc-main-content"' in layout
    assert 'id="efhc-main-content"' in layout
    assert ":focus-visible" in css
    assert "min-height:44px" in css
    assert "prefers-reduced-motion" in css
    assert 'role="status"' in network
    assert 'aria-live="polite"' in network


def test_performance_splits_proof_runtime_and_keeps_query_cache_bounded() -> None:
    app = read("frontend/src/pages/_app.tsx")
    query = read("frontend/src/lib/queryClient.ts")
    assert 'dynamic(' in app
    assert 'import("../proof/AdminVisualProofRouter")' in app
    assert "gcTime: 300_000" in query
    assert "staleTime: 10_000" in query
    assert "refetchOnReconnect: true" in query
