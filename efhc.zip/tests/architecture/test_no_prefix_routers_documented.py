from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_no_prefix_routers_have_canon_comments_and_norm_doc() -> None:
    for rel in [
        "backend/app/routes/me_routes.py",
        "backend/app/routes/system_routes.py",
    ]:
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert "КАНОН" in text
        assert "намеренно не имеет prefix" in text
        assert "APIRouter(tags=" in text
    api = (ROOT / "docs/NORM/API_CONTRACTS.md").read_text(
        encoding="utf-8"
    )
    assert "no-prefix router exceptions" in api
    assert "me_routes.py" in api and "system_routes.py" in api
