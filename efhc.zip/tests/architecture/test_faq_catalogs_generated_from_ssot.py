from __future__ import annotations

import importlib.util
from pathlib import Path


def _load_generator(root: Path):
    path = root / "ops/scripts/generate_faq_catalogs_from_ssot.py"
    spec = importlib.util.spec_from_file_location(
        "generate_faq_catalogs_from_ssot",
        path,
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_faq_catalogs_ts_is_generated_from_ssot() -> None:
    root = Path(__file__).resolve().parents[2]
    module = _load_generator(root)
    expected = module.render_catalogs_ts(root)
    actual = (root / "frontend/src/data/faq/catalogs.ts").read_text(
        encoding="utf-8"
    )
    assert actual == expected
