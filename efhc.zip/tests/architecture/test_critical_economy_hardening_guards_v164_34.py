from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend/app"


def test_payment_intents_service_has_no_nextval_fstring() -> None:
    text = (BACKEND / "services/payment_intents_service.py").read_text(
        encoding="utf-8"
    )
    assert "nextval('" not in text
    assert "pg_get_serial_sequence(:pi_table, 'id')" in text


def test_no_direct_user_balance_assignment_outside_transactions_service() -> (
    None
):
    bad: list[str] = []
    sql_patt = re.compile(
        r"(?:main_balance|bonus_balance)\s*=\s*:(?:[a-z_]+)",
        re.IGNORECASE,
    )
    orm_patt = re.compile(r"\.(?:main_balance|bonus_balance)\s*=\s*")
    allowed = {ROOT / "backend/app/services/transactions_service.py"}
    for path in sorted(BACKEND.rglob("*.py")):
        if path in allowed:
            continue
        body = path.read_text(encoding="utf-8")
        for i, line in enumerate(body.splitlines(), 1):
            if sql_patt.search(line) or orm_patt.search(line):
                bad.append(
                    f"{path.relative_to(ROOT)}:{i}: {line.strip()}"
                )
    assert not bad, (
        "direct balance writes outside transactions_service: "
        + "; ".join(bad)
    )


def test_no_direct_available_kwh_write_outside_transactions_and_model() -> (
    None
):
    bad: list[str] = []
    sql_patt = re.compile(
        r"available_kwh\s*=\s*:(?:[a-z_]+)", re.IGNORECASE
    )
    orm_patt = re.compile(r"\.available_kwh\s*=\s*")
    allowed = {
        ROOT / "backend/app/services/transactions_service.py",
        ROOT / "backend/app/models/user_models.py",
    }
    for path in sorted(BACKEND.rglob("*.py")):
        if path in allowed:
            continue
        body = path.read_text(encoding="utf-8")
        for i, line in enumerate(body.splitlines(), 1):
            if sql_patt.search(line) or orm_patt.search(line):
                bad.append(
                    f"{path.relative_to(ROOT)}:{i}: {line.strip()}"
                )
    assert not bad, "available_kwh writes outside canon: " + "; ".join(
        bad
    )


def test_referral_layers_do_not_resolve_users_id_for_tg() -> None:
    for rel in [
        "backend/app/services/referral_service.py",
        "backend/app/routes/admin_referral_routes.py",
    ]:
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert "SELECT id\n            FROM efhc_core.users" not in text
        assert "Вернуть users.id" not in text
        assert "users.id нужен" not in text


def test_withdraw_layers_keep_locking_and_status_constraint() -> None:
    model = (ROOT / "backend/app/models/withdraw_models.py").read_text(
        encoding="utf-8"
    )
    svc = (ROOT / "backend/app/services/withdraw_service.py").read_text(
        encoding="utf-8"
    )
    admin = (
        ROOT / "backend/app/services/admin/admin_withdrawals_service.py"
    ).read_text(encoding="utf-8")
    assert "ck_withdraw_requests_status_enum" in model
    assert "FOR UPDATE" in svc
    assert "FOR UPDATE" in admin


def test_manual_vip_claim_is_not_compat_stub() -> None:
    text = (BACKEND / "services/nft_requests_service.py").read_text(
        encoding="utf-8"
    )
    assert '"mode": "compat_stub"' not in text
    assert '"status": "accepted"' not in text
    assert "INSERT INTO efhc_core.shop_orders" in text


def test_panel_activation_price_is_hard_frozen_to_100() -> None:
    text = (BACKEND / "services/panels_service.py").read_text(
        encoding="utf-8"
    )
    assert 'PANEL_PRICE: Decimal = d8("100")' in text
    assert 'getattr(settings, "PANEL_PRICE"' not in text
