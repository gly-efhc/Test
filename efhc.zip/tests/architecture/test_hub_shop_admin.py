import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HUB = ROOT / "frontend/src/features/hub/HubPage.tsx"
SHOP = ROOT / "frontend/src/features/browser-shop/BrowserShopPage.tsx"
SHELL = ROOT / "frontend/src/components/ui/GameShell.tsx"
ADMIN = ROOT / "frontend/src/pages/admin/index.tsx"
SYSTEM = ROOT / "frontend/src/pages/admin/system.tsx"
TEMPLATE = (
    ROOT
    / "frontend/src/components/admin/AdminFunctionalPageTemplate.tsx"
)
USDT_AUDIT = (
    ROOT / "docs/audits/BROWSER_SHOP_USDT_PAYMENT_ROAD_AUDIT.md"
)
ROUTES_MAP = ROOT / "docs/admin/ADMIN_ROUTES_MAP.md"
NEXT_PLAN = (
    ROOT
    / "docs/cycles/WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
)
ROUTES_JSON = ROOT / "reports/generated/admin_routes_map.json"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_hub_has_two_canonical_external_actions():
    text = read(HUB)
    assert 'data-hub-visible-action-count="2"' in text
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in text
    assert 'data-hub-handoff-kind="external-top-up"' in text
    assert "action_vip_nft" in text
    assert "getgems.io/efhc-nft" in text
    assert "truth-layer" not in text

def test_browser_shop_compact_cards_and_ton_usdt_payment_road():
    text = read(SHOP)
    shell = read(SHELL)
    assert 'data-browser-shop-checkout="ton-usdt"' in text
    assert 'data-browser-shop-linking="telegram-web-return"' in text
    assert 'data-browser-shop-polling="react-query-5000ms"' in text
    assert 'data-browser-shop-no-bottom-menu="true"' in text
    assert '"TON" | "USDT"' in text
    assert "portal.browser_shop.pay_ton_gram" in text
    assert "portal.browser_shop.pay_usdt_ton_gram" in text
    assert 'pay_method: "TON"' not in text
    assert 'data-game-product-card="web3-large"' in shell
    assert 'data-product-card-image-frame="large"' in shell
    assert 'data-product-card-no-raw-payment="true"' in shell
    public = text.rsplit("return (", 1)[1]
    forbidden = ["memo", "payload", "tonconnect_tx"]
    for token in forbidden:
        assert token not in public.lower()


def test_usdt_road_is_audited_and_enabled_with_tep74_builder():
    text = read(USDT_AUDIT)
    shop = read(SHOP)
    assert "USDT public payment button is enabled" in text
    assert "TEP-74" in text
    assert "portal.browser_shop.pay_usdt_ton_gram" in shop
    assert "selectedMethods" in shop
    assert 'chooseMethod(item, "USDT")' in shop
    assert "buildJettonTransferTonConnectTx" in shop
    assert "buildUsdtTransferPlanFromBrowserShopIntent" in shop


def test_admin_home_has_release_grid_and_retains_system_page():
    text = read(ADMIN)
    assert "CORE_MODULES" in text
    assert "OPERATION_MODULES" in text
    assert 'data-admin-home-app-grid="release-v172-51"' in text
    for href in [
        "/admin/users",
        "/admin/bank",
        "/admin/withdrawals",
        "/admin/shop",
        "/admin/tasks",
        "/admin/reports",
    ]:
        assert href in text
    for technical_href in ["/admin/diagnostics", "/admin/system"]:
        assert technical_href not in text
    assert SYSTEM.exists()
    assert "debug dump" not in text.lower()


def test_admin_functional_template_and_routes_map_exist():
    template = read(TEMPLATE)
    assert (
        'data-admin-functional-template="stats-actions-table-1318"'
        in template
    )
    assert "AdminCharts" in template
    assert "AdminTable" in template
    assert "Операторские действия" in template
    assert ROUTES_MAP.exists()
    routes = json.loads(ROUTES_JSON.read_text(encoding="utf-8"))
    assert "/admin/system" in "\n".join(routes["frontend_admin_pages"])
    assert routes["route_deletion"] == "none"


def test_admin_next_plan_exists_after_1320():
    text = read(NEXT_PLAN)
    assert "1321-1325" in text
    assert "1350" in text
    assert "Admin recovery checkpoint report" in text
