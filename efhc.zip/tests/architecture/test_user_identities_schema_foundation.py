"""Финальный контракт identity schema после pre-release squash."""

from __future__ import annotations

from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from app.identity.auth_provider import AuthProvider
from app.models.identity_models import UserIdentity
from ops.identity.check_user_identities_schema import build_report
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
MIGRATION = ROOT / "backend/migrations/versions/0001_initial_release_schema.py"


def test_user_identity_model_остаётся_provider_neutral() -> None:
    table = UserIdentity.__table__
    assert {column.name for column in table.columns} >= {
        "id",
        "global_id",
        "provider",
        "provider_tenant",
        "provider_subject",
    }
    foreign_keys = list(table.c.global_id.foreign_keys)
    assert len(foreign_keys) == 1
    assert foreign_keys[0].target_fullname == "efhc_core.users.global_id"
    assert foreign_keys[0].ondelete == "RESTRICT"
    assert foreign_keys[0].onupdate == "RESTRICT"
    assert len(AuthProvider) == 10


def test_alembic_имеет_один_release_head() -> None:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    assert script.get_heads() == ["0002"]
    assert script.get_revision("0001").down_revision is None
    assert sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    ) == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]


def test_release_migration_содержит_identity_tables_и_final_fk() -> None:
    source = MIGRATION.read_text(encoding="utf-8")
    for marker in (
        "efhc_core.user_identities",
        "efhc_core.auth_challenges",
        "efhc_core.auth_sessions",
        "efhc_core.user_roles",
        "Base.metadata.create_all",
        "users.user_id physical column forbidden",
    ):
        assert marker in source


def test_identity_schema_guard_проходит() -> None:
    report = build_report(ROOT)
    assert report["пройдено"], report["ошибки"]
    assert report["alembic_heads"] == ["0002"]
    assert report["migration_files"] == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]


def test_identity_postgresql_route_остаётся_config_primary() -> None:
    classified = classify_task(
        "Цикл 1611 PostgreSQL test package user_identities и constraints"
    )
    assert classified["task_type"] == "user_identities_postgresql_package"
    route = resolve_route(classified["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
