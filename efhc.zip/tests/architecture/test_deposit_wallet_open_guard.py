from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_direct_deposit_uses_tonconnect_jetton_transaction() -> None:
    modal = (
        ROOT / "frontend/src/components/DepositModal.tsx"
    ).read_text(encoding="utf-8")
    assert "window.location.assign" not in modal
    assert "window.open(clean" not in modal
    assert "buildEfhcDirectDepositTx" in modal
    assert "useWalletProvider" in modal
    assert "sendTransaction(tx)" in modal
    assert 'data-direct-deposit-action="send-efhc-jetton"' in modal
    assert 'data-direct-deposit-amount="efhc-jetton"' in modal
    assert "wallet_open_url" not in modal
