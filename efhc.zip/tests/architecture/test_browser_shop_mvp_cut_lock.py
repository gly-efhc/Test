from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_browser_shop_is_purchase_surface_for_ton_and_usdt() -> None:
    page = (
        ROOT / "frontend" / "src" / "features" /
        "browser-shop" / "BrowserShopPage.tsx"
    ).read_text(encoding="utf-8")
    assert "useWalletProvider" in page
    assert "address: walletAddress" in page
    assert "buildUsdtTransferPlanFromBrowserShopIntent" in page
    assert "resolveSenderJettonWallet" in page
    assert "buildJettonTransferTonConnectTx" in page
    assert "item.ton_enabled || item.usdt_enabled" in page
    assert "const [selectedMethods" in page
    assert "function selectedMethod" in page
    assert "portal.browser_shop.pay_ton_gram" in page
    assert "portal.browser_shop.pay_usdt_ton_gram" in page
    assert 'pay_method: "TON"' not in page
    assert "USDT_DISABLED_UNTIL_REAL_JETTON_TRANSFER" not in page


def test_storefront_catalog_hides_vip_nft_items() -> None:
    text = (
        ROOT / "backend" / "app" / "services" / "shop_service.py"
    ).read_text(encoding="utf-8")
    assert "ITEM_TYPE_NFT_VIP" in text
    assert "continue" in text


def test_hub_remains_external_shop_launcher_not_checkout() -> None:
    page = (
        ROOT / "frontend" / "src" / "features" / "hub" / "HubPage.tsx"
    ).read_text(encoding="utf-8")
    service = (
        ROOT / "frontend" / "src" / "services" / "hub.service.ts"
    ).read_text(encoding="utf-8")
    assert "useHubEfhcHandoff" in page
    assert 'data-hub-runtime="two-canonical-actions"' in page
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in page
    assert "purchase" not in page.lower()
    assert "buy" not in page.lower()
    assert "apiRequest" not in page
    assert "HUB_EFHC_HANDOFF_PATH" in service
    assert "/hub/efhc-handoff" in service
    assert "window.open" in page
    assert "TonConnect" not in page
