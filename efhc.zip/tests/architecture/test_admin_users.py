from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
USERS_TSX = ROOT / "frontend/src/pages/admin/users.tsx"
ROUTE = ROOT / "backend/app/routes/admin_users_routes.py"
PLAN = ROOT / "docs/cycles/WORK_CYCLES.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_admin_users_page_has_1321_statistics_and_actions() -> None:
    text = read(USERS_TSX)
    assert 'data-admin-users-cycle="1321"' in text
    assert "data-admin-users-statistics-audit='1321'" in text
    assert "data-admin-users-actions-audit='safe-1321'" in text
    marker = "data-admin-users-balance-correction"
    assert marker in text
    assert "walletCount" in text


def test_admin_users_initial_search_accepts_empty_query() -> None:
    route = read(ROUTE)
    assert 'q: str = Query("", max_length=64)' in route
    assert 'detail="q is empty"' not in route
    assert '"is_empty": is_empty' in route
    assert "ILIKE :username_pref" in route


def test_admin_users_actions_keep_idempotency() -> None:
    text = read(USERS_TSX)
    assert "newIdempotencyKey()" in text
    assert "ADMIN_TRANSFER_PATH" in text
    assert "data-admin-users-balance-correction" in text


def test_cycle_1321_recorded_in_work_cycles() -> None:
    text = read(PLAN)
    assert "1321" in text
    assert "Users page statistics and actions audit" in text
