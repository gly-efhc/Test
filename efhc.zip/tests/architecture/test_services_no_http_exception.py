from pathlib import Path


def test_services_no_http_exception_in_tasks() -> None:
    tasks_path = Path("backend/app/services/tasks_service.py")
    text = tasks_path.read_text(encoding="utf-8")
    assert "raise HTTPException" not in text, tasks_path.as_posix()
