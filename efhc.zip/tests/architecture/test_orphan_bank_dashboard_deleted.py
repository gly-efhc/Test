from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_orphan_admin_interactive_bank_dashboard_deleted() -> None:
    """Cycle 1502 deletes the old orphan bank dashboard file."""
    orphan = ROOT / (
        "frontend/src/components/admin/AdminInteractiveBankDashboard.tsx"
    )
    assert not orphan.exists(), (
        "AdminInteractiveBankDashboard.tsx must stay deleted. "
        "Use AdminBankDashboardRuntime.tsx instead."
    )


def test_no_admin_runtime_imports_deleted_orphan() -> None:
    offenders: list[str] = []
    for path in (ROOT / "frontend/src").rglob("*.tsx"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "AdminInteractiveBankDashboard" in text:
            offenders.append(path.relative_to(ROOT).as_posix())
    assert offenders == []


def test_no_build_series_in_admin_runtime_components() -> None:
    """Synthetic buildSeries trend generators are forbidden."""
    admin_dir = ROOT / "frontend/src/components/admin"
    violations: list[str] = []
    for path in admin_dir.glob("*.tsx"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "buildSeries" in text:
            violations.append(path.name)
    assert violations == []


def test_dash_01_audit_finding_is_marked_closed() -> None:
    report = ROOT / (
        "reports/generated/"
        "orphan_bank_dashboard_deletion_v170_78.json"
    )
    norm = ROOT / "docs/NORM/ORPHAN_BANK_DASHBOARD_DELETION.md"
    assert report.exists()
    assert "DASH-01" in norm.read_text(encoding="utf-8")
