from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_ranks_runtime_docs_exist() -> None:
    required = [
        "docs/NORM/RANKS_DASHBOARD_RUNTIME_PORT.md",
        "docs/NORM/RANKS_DASHBOARD_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1475_RANKS_DASHBOARD_RUNTIME_PORT.md",
        "reports/generated/ranks_dashboard_runtime_port_v170_51.json",
        "reports/change_cycle_2026-06-07_v170_51_cycle_1475_ranks_dashboard_runtime_port.md",
        "frontend/src/components/dashboard/RanksDashboardRuntime.tsx",
        "tests/architecture/test_ranks_dashboard_runtime_port.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_runtime_boundaries() -> None:
    data = json.loads(read("reports/generated/ranks_dashboard_runtime_port_v170_51.json"))
    assert data["cycle"] == 1475
    assert data["archive_version"] == "v170.51"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_ranks_route_changed"] is True
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["raw_tg_id_visible_in_public_ui"] is False
    assert data["fake_leaderboard_rows_added"] is False
    assert data["fake_rank_position_removed"] is True
    assert data["internal_energy_levels_catalog_exposed"] is False
    assert data["grafana_runtime_code_copied"] is False


def test_ranks_runtime_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/RanksDashboardRuntime.tsx")
    required = [
        "data-ranks-dashboard-runtime=\"1475\"",
        "data-ranks-runtime-truth=\"raw-derived\"",
        "data-ranks-runtime-no-fake-leaderboard=\"true\"",
        "data-ranks-runtime-no-energy-catalogue=\"true\"",
        "data-ranks-runtime-username-only=\"true\"",
        "SimLeaderboardScopeFilter",
        "SimMilestoneProgress",
        "SimMiniSparkline",
        "SimActivityStrip",
        "nextVisibleGoal",
        "progressToGoal",
    ]
    for marker in required:
        assert marker in src


def test_ranks_page_uses_current_runtime_without_fake_rank() -> None:
    page = read("frontend/src/pages/ranks.tsx")
    assert "RanksDashboardRuntime" not in page
    assert "useMyRankWithTop" in page
    assert "useRankTopPages" in page
    assert "item={me}" in page
    assert "rank_pos: 0" in page
    assert "rank_pos: 1" not in page
    assert 'data-ranks-runtime="react-query-kwh-1558"' in page
    assert 'data-ranks-leaderboard="top-100"' in page


def test_ranks_runtime_does_not_add_write_or_money_flow() -> None:
    src = read("frontend/src/components/dashboard/RanksDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "withdraw",
        "deposit",
        "activatePanel",
        "newIdempotencyKey",
        "telegramMainButtonSet",
    ]
    for marker in forbidden:
        assert marker not in src


def test_ranks_runtime_protects_public_identifier_boundary() -> None:
    src = read("frontend/src/components/dashboard/RanksDashboardRuntime.tsx")
    docs = read("docs/NORM/RANKS_DASHBOARD_RUNTIME_PORT.md")
    assert "data-ranks-runtime-username-only=\"true\"" in src
    assert "username" in src
    assert "TG ${" not in src
    assert "raw `tg_id` visible in public UI: no" in docs


def test_ranks_runtime_does_not_reintroduce_energy_level_catalog() -> None:
    corpus = read("frontend/src/components/dashboard/RanksDashboardRuntime.tsx")
    forbidden = [
        "current_level",
        "level x/12",
        "Earth Ally",
        "Climate Fighter",
        "Green Sentinel",
        "Planet Defender",
        "Eco Champion",
        "Planet Saver",
        "Green Commander",
        "Guardian of Earth",
    ]
    for marker in forbidden:
        assert marker not in corpus


def test_ranks_runtime_locale_keys_exist_in_all_languages() -> None:
    required = [
        "ranks.dashboard_title",
        "ranks.dashboard_subtitle",
        "ranks.dashboard_fresh",
        "ranks.dashboard_source",
        "ranks.dashboard_raw_data",
        "ranks.dashboard_derived_display",
        "ranks.dashboard_mode",
        "ranks.dashboard_visible_goal",
        "ranks.dashboard_no_rank",
        "ranks.dashboard_privacy",
        "ranks.dashboard_truth",
        "ranks.dashboard_no_fake_leaderboard",
        "ranks.dashboard_no_energy_catalogue",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in required if key not in data]
        assert not missing, f"{path.name}: {missing}"


def test_ranks_runtime_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1475 — Ranks Dashboard Runtime Port",
        ".efhc-ranks-dashboard-runtime",
        ".efhc-ranks-dashboard-runtime__leader-grid",
        ".efhc-ranks-dashboard-runtime__leader-card--me",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1475 — Ranks Dashboard Runtime Port" in corpus
    assert "RANKS_DASHBOARD_RUNTIME_PORT" in corpus
    assert "1476 — Leaderboard Visual System" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/RANKS_DASHBOARD_RUNTIME_PORT.md")
        + read("docs/NORM/RANKS_DASHBOARD_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs
