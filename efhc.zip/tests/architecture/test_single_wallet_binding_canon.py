from __future__ import annotations

from pathlib import Path

ROOT = Path(".")


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_wallet_bindings_is_single_active_wallet_table() -> None:
    doc = _read("docs/NORM/WALLET_BINDING_CANON.md")
    assert "wallet_bindings" in doc
    assert "single active wallet binding table" in doc
    matrix = _read("docs/NORM/DB_DRIFT_MATRIX.md")
    assert "`wallet_bindings` | active" in matrix
    assert "`user_wallets` | removed/deprecated/not active" in matrix
    assert "`wallet_bind_requests` | removed/deprecated/not active" in matrix


def test_tonconnect_proof_is_active_wallet_binding_mechanism() -> None:
    route = _read("backend/app/routes/wallets_routes.py")
    service = _read("backend/app/services/wallets_service.py")
    doc = _read("docs/NORM/WALLET_BINDING_CANON.md")
    assert "tonconnect_proof_service.check_proof" in route
    assert "proof_payload_hash" in service
    assert "wallet_proof_token_uses" in service
    assert "wallet_connect_idempotency" in service
    assert "TonConnect proof" in doc


def test_legacy_wallet_binding_service_not_imported_by_runtime() -> None:
    assert not Path("backend/app/services/wallet_binding_service.py").exists()
    runtime_files = list(Path("backend/app").rglob("*.py"))
    offenders: list[str] = []
    for path in runtime_files:
        if path.name == "wallet_binding_service.py":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "wallet_binding_service" in text:
            offenders.append(str(path))
    assert offenders == []


def test_no_runtime_reference_to_legacy_wallet_tables() -> None:
    offenders: list[str] = []
    legacy_markers = (
        "efhc_core.user_wallets",
        "wallet_bind_requests",
    )
    for path in Path("backend/app").rglob("*.py"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if any(marker in text for marker in legacy_markers):
            offenders.append(str(path))
    assert offenders == []


def test_wallet_binding_canon_docs_exist() -> None:
    for rel in [
        "docs/SSOT/WALLET_IDENTITY_SSOT.md",
        "docs/NORM/WALLET_CANONICAL_ADDRESS_NORM.md",
        "docs/NORM/WALLET_BINDING_CANON.md",
        "docs/NORM/DB_DRIFT_MATRIX.md",
    ]:
        assert Path(rel).exists(), rel


def test_wallet_proof_replay_protection_docs_exist() -> None:
    doc = _read("docs/NORM/WALLET_BINDING_CANON.md")
    assert "wallet_proof_token_uses" in doc
    assert "Replay protection" in doc


def test_wallet_idempotency_docs_exist() -> None:
    doc = _read("docs/NORM/WALLET_BINDING_CANON.md")
    assert "wallet_connect_idempotency" in doc
    assert "Idempotency" in doc


def test_kernel_links_wallet_binding_canon() -> None:
    kernel = _read("KERNEL.md")
    mapping = _read("map_element.md")
    nav = kernel + mapping
    assert "docs/NORM/WALLET_BINDING_CANON.md" in nav
    assert "single active wallet binding mechanism canon" in nav


def test_map_element_links_wallet_binding_canon() -> None:
    m = _read("map_element.md")
    assert "docs/SSOT/WALLET_IDENTITY_SSOT.md" in m
    assert "docs/NORM/WALLET_BINDING_CANON.md" in m
    assert "docs/NORM/WALLET_CANONICAL_ADDRESS_NORM.md" in m


def test_wallet_address_model_is_canonical_unique_key() -> None:
    model = _read("backend/app/models/wallets_models.py")
    assert "wallet_address stores EFHC canonical TON address" in model
    assert "unique=True" in model
    assert "ownership/conflict/lookup unique key" in model
