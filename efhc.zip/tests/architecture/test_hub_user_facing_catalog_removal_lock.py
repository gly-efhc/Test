from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FAQ_RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.md"


def test_ru_faq_section_13_has_hub_questions() -> None:
    text = FAQ_RU.read_text(encoding="utf-8")
    required = [
        "### 13-1. Что можно делать в Hub?",
        "### 13-2. Для чего нужен Hub?",
        "### 13-3. Сколько действий доступно в Hub?",
        "### 13-4. Что делает кнопка «Пополнить»?",
        (
            "### 13-9. В какой баланс попадает пополнение через "
            "«Пополнить» и Hub?"
        ),
        "Скины не являются карточками Hub.",
    ]
    for item in required:
        assert item in text, item


def test_ru_faq_section_13_has_no_store_wording() -> None:
    text = FAQ_RU.read_text(encoding="utf-8")
    banned = [
        "Что можно делать в Shop?",
        (
            "В Shop можно покупать пакеты пополнения EFHC, "
            "EFHC VIP NFT и другие товары проекта."
        ),
        "Можно ли покупать в Shop, если кошелёк не подключён?",
    ]
    for item in banned:
        assert item not in text, item


def test_wallet_answer_no_longer_mentions_shop_purchase() -> None:
    text = FAQ_RU.read_text(encoding="utf-8")
    assert "покупки в Shop" not in text
    assert "Ровно два: «Пополнение» и «EFHC VIP NFT»" in text
    assert "EFHCm зачисляется в основной баланс" in text
