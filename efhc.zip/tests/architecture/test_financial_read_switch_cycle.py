"""Архитектурный contract financial read switch цикла 1627."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_release_0001_содержит_final_financial_read_control() -> None:
    migration = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    assert 'revision = "0001"' in migration
    assert "down_revision = None" in migration
    assert "financial_read_global_id_enabled" in migration
    assert "financial_read_rollback_ready" in migration
    assert "identity_migration_control" in migration
    assert "users.user_id physical column forbidden" in migration

def test_financial_owner_provider_neutral_и_rollback_ready() -> None:
    source = _read("backend/app/identity/financial_read_switch.py")
    dependency = _read(
        "backend/app/identity/financial_read_dependency.py"
    )
    assert "financial_read_global_id_enabled" in source
    assert "financial_read_rollback_ready" in source
    assert "context.global_id.value" in dependency
    assert "require_auth_context" in dependency


def test_owner_reads_и_writes_используют_canonical_owner() -> None:
    payment = _read("backend/app/routes/payment_intents_routes.py")
    wallets = _read("backend/app/routes/wallets_routes.py")
    withdraw = _read("backend/app/routes/withdraw_routes.py")
    exchange = _read("backend/app/routes/exchange_routes.py")
    outcome = _read("backend/app/routes/me_routes.py")

    assert "get_financial_read_owner" in payment
    assert "get_financial_read_owner" in wallets
    assert "get_financial_read_owner" in withdraw
    assert "get_financial_read_owner" in exchange
    assert "get_financial_read_owner" in outcome

    assert "global_id=int(owner.global_id)" in withdraw
    assert "global_id=owner.global_id" in exchange

    # TON Connect proof остаётся Telegram-provider boundary.
    assert "tonconnect_check_proof" in wallets
    assert "get_current_tg_id" in wallets


def test_withdraw_owner_api_не_принимает_tg_id_query() -> None:
    source = _read("backend/app/routes/withdraw_routes.py")
    assert "Legacy self-check. Prefer auth user." not in source
    block = source.split("async def get_withdraw_list", 1)[1]
    block = block.split("async def get_withdraw_detail", 1)[0]
    assert "Depends(get_financial_read_owner)" in block
    assert "tg_id: int | None = Query" not in block
