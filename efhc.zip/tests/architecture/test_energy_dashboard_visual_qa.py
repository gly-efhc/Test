from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/ENERGY_DASHBOARD_VISUAL_QA.md"
GRAFANA_DOC = ROOT / "docs/NORM/ENERGY_DASHBOARD_VISUAL_QA_GRAFANA_ELEMENT_ANALYSIS.md"
TSX = ROOT / "frontend/src/components/dashboard/EnergyDashboardRuntime.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
RU = ROOT / "frontend/public/locale/ru.json"
EN = ROOT / "frontend/public/locale/en.json"
REPORT = ROOT / "reports/generated/energy_dashboard_visual_qa_v170_46.json"
EVIDENCE = (
    ROOT
    / "reports/evidence/screenshots/energy_dashboard_visual_qa_v170_46"
    / "browser_capture_attempt.json"
)
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
TEST_MANIFEST = ROOT / "docs/testing/TEST_GUARD_MANIFEST.md"
TEST_MANIFEST_JSON = ROOT / "docs/testing/TEST_GUARD_MANIFEST.json"
CYCLE_DOC = ROOT / "docs/cycles/WORK_CYCLES_1470_ENERGY_DASHBOARD_VISUAL_QA.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_energy_dashboard_visual_qa_docs_exist_and_record_no_false_screenshot_claim() -> None:
    text = read(DOC)
    assert "ACTIVE_ENERGY_DASHBOARD_VISUAL_QA" in text
    assert "Cycle: `1470`" in text
    assert "STATIC_VISUAL_QA_SAFE_WITH_BROWSER_CAPTURE_BLOCKED_BY_ENVIRONMENT" in text
    assert "net::ERR_BLOCKED_BY_ADMINISTRATOR" in text
    assert "does not claim browser screenshot proof" in text
    assert "No Песочница runtime code is copied" in text
    assert "Grafana remains visual-pattern/reference layer only" in text


def test_runtime_component_has_visual_qa_markers_and_safe_ctas() -> None:
    text = read(TSX)
    for marker in [
        "data-energy-dashboard-runtime-port=\"1469\"",
        "data-energy-dashboard-visual-qa=\"1470\"",
        "data-energy-dashboard-mobile-safe=\"true\"",
        "data-energy-dashboard-cta-count=\"2\"",
        "data-energy-dashboard-synthetic=\"false\"",
        "data-energy-dashboard-write-flow=\"false\"",
        "data-grafana-reference-only=\"true\"",
        "data-sandbox-reference-only=\"true\"",
        "href=\"/panels\"",
        "href=\"/exchange\"",
    ]:
        assert marker in text

    forbidden = [
        "method: \"POST\"",
        "method: \"PUT\"",
        "method: \"PATCH\"",
        "method: \"DELETE\"",
        "onSubmit",
        "formAction",
        "transfer-to-user",
        "synthetic_preview",
        "@grafana/",
    ]
    for marker in forbidden:
        assert marker not in text


def test_visual_qa_css_hardens_mobile_overflow() -> None:
    css = read(CSS)
    for marker in [
        "Cycle 1470 — Energy Dashboard Visual QA",
        ".efhc-energy-dashboard-runtime *",
        "min-width: 0",
        "overflow-wrap: anywhere",
        ".efhc-energy-dashboard-runtime__kpi-strip .efhc-sim-dashboard-stat strong",
        ".efhc-energy-dashboard-runtime__rules span",
        ".efhc-sim-dashboard-hero__value strong",
        "repeat(auto-fit, minmax(150px, 1fr))",
        "repeat(auto-fit, minmax(140px, 1fr))",
    ]:
        assert marker in css


def test_russian_locale_is_not_mixed_with_english_truth_labels() -> None:
    ru = load(RU)
    en = load(EN)
    assert ru["energy.dashboard_raw_snapshot"] == "исходный снимок"
    assert ru["energy.dashboard_derived_snapshot"] == "расчётное отображение"
    assert "Real time-series" not in ru["energy.dashboard_no_timeseries"]
    assert en["energy.dashboard_raw_snapshot"] == "source current summary"
    assert en["energy.dashboard_derived_snapshot"] == "derived display"


def test_generated_report_records_visual_qa_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1470
    assert data["version"] == "v170.46"
    assert data["visual_qa_verdict"] == (
        "STATIC_VISUAL_QA_SAFE_WITH_BROWSER_CAPTURE_BLOCKED_BY_ENVIRONMENT"
    )
    assert data["browser_proof"]["screenshots_claimed"] is False
    assert data["browser_proof"]["error"] == "net::ERR_BLOCKED_BY_ADMINISTRATOR"
    assert data["visual_matrix"]["cta_count"] == "2"
    assert data["visual_matrix"]["cta_targets"] == ["/panels", "/exchange"]
    assert data["visual_matrix"]["synthetic_runtime_data"] == "absent"
    assert data["visual_matrix"]["real_timeseries_claimed"] is False
    for key in [
        "economy_changed",
        "backend_contracts_changed",
        "db_migrations_changed",
        "openapi_changed",
        "dependencies_changed",
        "lock_files_changed",
        "ci_workflows_changed",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
        "write_flows_changed",
        "money_actions_added",
    ]:
        assert data["boundaries"][key] is False


def test_browser_capture_attempt_evidence_is_honest() -> None:
    if EVIDENCE.exists():
        evidence = load(EVIDENCE)
        assert evidence["cycle"] == 1470
        assert evidence["local_http_probe"]["status"] == "HTTP/1.1 200 OK"
        assert evidence["browser_capture"]["attempted"] is True
        assert evidence["browser_capture"]["result"] == "blocked_by_environment"
        assert evidence["browser_capture"]["screenshots_claimed"] is False
        return

    report = load(REPORT)
    assert report["browser_proof"]["screenshots_claimed"] is False
    assert report["browser_proof"]["error"] == (
        "net::ERR_BLOCKED_BY_ADMINISTRATOR"
    )
    screenshot_root = EVIDENCE.parent
    assert not list(screenshot_root.glob("*.png"))


def test_grafana_visual_qa_analysis_is_reference_only() -> None:
    text = read(GRAFANA_DOC)
    for marker in [
        "PanelChrome.tsx",
        "PanelHeader",
        "PanelStatus.tsx",
        "DashboardGrid",
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "BigValue",
        "Sparkline/Sparkline.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
        "Variables",
        "No Grafana source code is copied",
        "EFHC-owned implementation target",
    ]:
        assert marker in text
    assert "Grafana is not a code donor" in text


def test_navigation_and_manifest_register_visual_qa() -> None:
    for path in [KERNEL, MAP, ROUTES, TEST_MANIFEST, CYCLE_DOC]:
        text = read(path)
        assert "Energy Dashboard Visual QA" in text
        assert "ENERGY_DASHBOARD_VISUAL_QA" in text
        assert "test_energy_dashboard_visual_qa.py" in text
    manifest = load(TEST_MANIFEST_JSON)
    item = manifest["cycle_1470_energy_dashboard_visual_qa"]
    assert item["status"] == "active"
    assert item["browser_screenshots_claimed"] is False


def test_grafana_reference_archive_contains_visual_qa_anchors() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    for marker in [
        "PanelChrome.tsx",
        "PanelStatus.tsx",
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "Sparkline/Sparkline.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
    ]:
        assert any(marker in name for name in names), marker


def test_no_forbidden_release_artifacts_from_visual_qa() -> None:
    forbidden = [
        ROOT / "frontend/tsconfig.tsbuildinfo",
    ]
    for path in forbidden:
        assert not path.exists(), path
