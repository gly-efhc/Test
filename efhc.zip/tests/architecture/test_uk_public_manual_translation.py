from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
UK_GUARD = ROOT / "ops" / "i18n" / "audit_uk_locale_value_quality.py"

MANUAL_KEYS = {
    "energy.exchange_interactive_hint": (
        "Обмін використовує лише доступні kWh і канонічний курс 1 kWh "
        "= 1 EFHC."
    ),
    "energy.overview_interactive_hint": (
        "Компактний mobile-"
        "first огляд енергії, швидкості генерації та доступних kWh."
    ),
    "energy.panels_interactive_hint": (
        "Панелі запускають генерацію. Активація залишається окремою "
        "підтверджуваною дією."
    ),
    "portal.shop_entry.flow_title": "Як працює вхід",
    "profile.connect_wallet": "Підключити гаманець",
    "profile.wallet_title": "Гаманець",
    "public_engagement.ranks.cta": "Показати мене в рейтингу",
    "public_engagement.referrals.cta": "Скопіювати запрошення",
    "public_engagement.tasks.title": "Заробіть і поверніться до енергії",
    "public_profile_trust.note_wallet": (
        "Деталі гаманця відкриваються у звичайній вкладці Wallet. "
        "source proof data не показується."
    ),
    "wallet.state_map_title": "Карта стану гаманця",
    "wallet.state_wallet_error": "Помилка гаманця",
}

PROTECTED_EXACT_VALUES = {
    "deposit.truth__path__badge": "truth-path",
    "energy.exchange_action_note": "1 kWh = 1 EFHC",
    "portal.browser_shop.payment_state_idle": "TON",
    "ranks.filter_kwh": "kWh",
}

CYRILLIC_RU_TAILS = (
    "Профиль",
    "Детали кошелька",
    "Карта состояния",
    "Ошибка кошелька",
)


def _flatten(data: dict, prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(_flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def _load(lang: str) -> dict[str, str]:
    return _flatten(
        json.loads(
            (LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8")
        )
    )


def test_cycle_1377_uk_manual_translations_are_present() -> None:
    uk = _load("uk")
    en = _load("en")
    for key, expected in MANUAL_KEYS.items():
        assert uk[key] == expected, key
        assert uk[key] != en[key], key


def test_cycle_1377_protected_exact_values_are_not_translation_debt() -> (
    None
):
    uk = _load("uk")
    allow = json.loads(
        (
            ROOT / "ops/i18n/identical_to_english_allowlist.json"
        ).read_text(encoding="utf-8")
    )
    exact_values = set(allow["exact_values"])
    for key, expected in PROTECTED_EXACT_VALUES.items():
        assert uk[key] == expected, key
        assert expected in exact_values, (key, expected)


def test_cycle_1377_uk_locale_has_no_known_russian_tail_markers() -> (
    None
):
    uk = _load("uk")
    joined = "\n".join(uk.values())
    for marker in CYRILLIC_RU_TAILS:
        assert marker not in joined, marker


def test_cycle_1377_uk_quality_guard_uses_global_exact_allowlist() -> (
    None
):
    text = UK_GUARD.read_text(encoding="utf-8")
    assert "identical_to_english_allowlist.json" in text
    assert "value in exact_values" in text
    assert "key.startswith(prefix)" in text
    assert re.search(
        (
            r"not\s+is_allowed_identical\(key, value, exact_values, key_"
            r"prefixes\)"
        ),
        text,
    )
