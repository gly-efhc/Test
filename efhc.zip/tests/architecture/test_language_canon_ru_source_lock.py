from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_language_ssot_requires_russian_semantic_source() -> None:
    text = read("docs/SSOT/LANGUAGE_CANON_SSOT.md")
    required = [
        "Russian is the mandatory semantic source language",
        (
            "Other languages are translation layers from the verified "
            "Russian meaning"
        ),
        "never translate Russian from English",
        "SSOT can regress",
        "Runtime fallback",
    ]
    for marker in required:
        assert marker in text


def test_ai_and_norm_layers_record_ru_source_rule() -> None:
    files = [
        "docs/NORM/LOCALIZATION_WORKFLOW_NORM.md",
        "docs/AI/AI_OPERATOR_RULES_EFHC.md",
        "docs/AI/TOPIC_READING_ROUTES.md",
        "docs/AI/FAQ_READING_POLICY.md",
        "docs/AI/AI_DOCS_INDEX.md",
    ]
    for file in files:
        text = read(file).lower()
        assert "russian" in text or "русск" in text, file
        assert (
            "english" in text or "англий" in text or "en" in text
        ), file
        assert "source" in text or "источник" in text, file


def test_operator_kernel_has_language_canon_route() -> None:
    for file in [
        "ops/operator_kernel/config/routes.yaml",
        "ops/operator_kernel/route_resolver.py",
        "ops/operator_kernel/task_classifier.py",
    ]:
        assert "language_canon_ru_source_lock" in read(file), file


def test_ru_locale_no_forbidden_english_source_regressions() -> None:
    en = json.loads(
        (ROOT / "frontend/public/locale/en.json").read_text(
            encoding="utf-8"
        )
    )
    ru = json.loads(
        (ROOT / "frontend/public/locale/ru.json").read_text(
            encoding="utf-8"
        )
    )
    allow = {
        "admin.hub",
        "admin.hub_url",
        "admin.tg_id",
        "admin.vip",
        "common.id",
        "deposit.truth__path__badge",
        "energy.exchange_action_note",
        "energy.kwh_suffix_spaced",
        "faq.title",
        "hub.efhc_modal_title",
        "hub.title",
        "nav.hub",
        "portal.browser_shop.payment_state_idle",
        "profile.telegram_badge",
        "profile.vip_badge",
        "ranks.filter_kwh",
    }
    allow.update({k for k in ru if k.startswith("profile.lang.")})
    forbidden_prefixes = (
        "portal.browser_shop.",
        "portal.shop_entry.",
        "public_engagement.",
    )
    offenders = []
    for key, en_value in en.items():
        ru_value = ru.get(key)
        if key in allow:
            continue
        if (
            key.startswith(forbidden_prefixes)
            and isinstance(en_value, str)
            and en_value == ru_value
        ):
            offenders.append(key)
    assert offenders == []


def test_user_decision_recorded_in_questions_and_answers() -> None:
    text = read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")
    assert "Запрещено переводить русский язык с английского" in text
    assert "SSOT может быть регрессом" in text
