from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = (
    ROOT / "ops/frontend/all_pages_visual_manifest_v171_88.json"
)
AUDIT = ROOT / "ops/frontend/all_pages_route_backed_visual_audit.py"
SCREEN = ROOT / "docs/frontend/FRONTEND_SCREEN_REGISTRY.md"
SOURCE_MAP = ROOT / "docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md"


def _page_route(path: Path) -> str | None:
    relative = path.relative_to(ROOT / "frontend/src/pages")
    parts = list(relative.with_suffix("").parts)
    if parts[-1].startswith("_"):
        return None
    if parts[-1] == "index":
        parts.pop()
    return "/" + "/".join(parts)


def test_postgres_plan_guard_accepts_real_panel_index_choice() -> None:
    text = (
        ROOT / "tests/integration/test_referral_runtime.py"
    ).read_text(encoding="utf-8")
    assert "PANEL_QUERY_INDEXES" in text
    assert "_plan_index_names(plan)" in text
    assert "index_names & PANEL_QUERY_INDEXES" in text
    assert 'assert "ix_efhc_core_panels_tg_id" in plan_text' not in text


def test_visual_manifest_covers_every_physical_product_page() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    physical = {
        route
        for path in (ROOT / "frontend/src/pages").rglob("*.tsx")
        if (route := _page_route(path)) is not None
    }
    system = {item["route"] for item in data["system_routes"]}
    public = {item["route"] for item in data["public_routes"]}
    admin = {item["route"] for item in data["admin_routes"]}
    assert physical == public | admin | system
    assert len(public) == 15
    assert len(admin) == 17
    assert {360, 390, 430} == {
        int(item["width"]) for item in data["viewports"]
    }


def test_all_page_visual_audit_is_real_route_backed() -> None:
    text = AUDIT.read_text(encoding="utf-8")
    assert "page.goto(" in text
    assert "full_page=True" in text
    assert "horizontal_overflow" in text
    assert "pageerror" in text
    assert "set_content(" not in text
    assert '"synthetic_html": False' in text


def test_screen_docs_cover_every_manifest_route() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    screen = SCREEN.read_text(encoding="utf-8")
    source_map = SOURCE_MAP.read_text(encoding="utf-8")
    routes = {
        item["route"]
        for key in (
            "public_routes",
            "admin_routes",
            "system_routes",
        )
        for item in data[key]
    }
    for route in routes:
        marker = f"`{route}`"
        assert marker in screen
        assert marker in source_map


def test_public_smoke_includes_telegram_app_alias() -> None:
    text = (
        ROOT / "tests/frontend/e2e/test_smoke_public_pages.py"
    ).read_text(encoding="utf-8")
    assert '"/app"' in text

def test_github_visual_workflow_runs_complete_route_cycle() -> None:
    blocking = (ROOT / ".github/workflows/canon.yml").read_text(
        encoding="utf-8"
    )
    visual = (
        ROOT / ".github/workflows/frontend-visual.yml"
    ).read_text(encoding="utf-8")
    assert "Chromium visual audit" in blocking
    assert "reports/screenshots" in blocking
    assert "EXPECTED_SCREENSHOTS = 102" in visual
    assert "npm run start" in visual
    assert "page.goto(" in visual
    assert "page.screenshot(" in visual
    assert "page.set_content(" not in visual
    assert "context.route(" not in visual
    assert "ci_artifacts/screenshots" in visual
    assert "playwright install --with-deps chromium" in visual

