from __future__ import annotations

import json
from pathlib import Path

FORBIDDEN_RUNTIME_ALIASES = {
    "@ton/core",
    "@ton/ton",
    "@ton/crypto",
    "@tonconnect/sdk",
    "@tonconnect/protocol",
    "@tonconnect/isomorphic-fetch",
    "@tonconnect/isomorphic-eventsource",
}

REQUIRED_DEPS = {
    "@ton/core",
    "@ton/ton",
    "@tonconnect/sdk",
    "buffer",
}


def test_frontend_tsconfig_blocks_raw_donor_runtime_paths() -> None:
    p = Path("frontend/tsconfig.json")
    data = json.loads(p.read_text(encoding="utf-8"))
    paths = data["compilerOptions"].get("paths", {})

    for key in FORBIDDEN_RUNTIME_ALIASES:
        assert key not in paths, (
            "Forbidden raw runtime alias returned: " + key
        )

    ui_alias = paths.get("@tonconnect/ui-react")
    assert ui_alias == ["src/lib/vendor/tonconnect-ui-react-compat.tsx"]


def test_frontend_package_json_keeps_published_ton_runtime_deps() -> (
    None
):
    p = Path("frontend/package.json")
    data = json.loads(p.read_text(encoding="utf-8"))
    deps = data.get("dependencies", {})

    missing = sorted(x for x in REQUIRED_DEPS if x not in deps)
    assert not missing, "Missing published deps: " + ", ".join(missing)


def test_frontend_polyfills_imported_first_in_app() -> None:
    p = Path("frontend/src/pages/_app.tsx")
    lines = p.read_text(encoding="utf-8").splitlines()
    non_empty = [line.strip() for line in lines if line.strip()]
    assert non_empty, "_app.tsx is empty"
    assert non_empty[0] in {
        "import '../polyfills';",
        'import "../polyfills";',
    }
