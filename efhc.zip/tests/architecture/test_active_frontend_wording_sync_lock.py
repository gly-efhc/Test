from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read_locale(code: str) -> dict[str, str]:
    return json.loads(
        (ROOT / f"frontend/public/locale/{code}.json").read_text(
            encoding="utf-8"
        )
    )


def test_ru_and_uk_active_keys_match_hub_external_flow_canon() -> None:
    ru = _read_locale("ru")
    uk = _read_locale("uk")

    assert "внешн" in ru["hub.card_efhc_description"].lower()
    assert "покуп" not in ru["hub.efhc_modal_body"].lower()
    assert "ton" not in ru["hub.efhc_modal_body"].lower()
    assert "действ" in ru["profile.confirm_purchase"].lower()
    assert "efhc-переход" in ru["wallet.connection_needed"].lower()

    assert "зовніш" in uk["hub.card_efhc_description"].lower()
    assert "куп" not in uk["hub.efhc_modal_body"].lower()
    assert "ton" not in uk["hub.efhc_modal_body"].lower()
    assert "ді" in uk["profile.confirm_purchase"].lower()
    assert "efhc-перехід" in uk["wallet.connection_needed"].lower()


def test_en_active_keys_no_longer_say_buy_or_purchase() -> None:
    en = _read_locale("en")
    for key in [
        "hub.card_efhc_description",
        "hub.efhc_modal_body",
        "profile.confirm_purchase",
        "wallet.connection_needed",
        "wallet.connection_ready",
        "wallet.empty_body",
    ]:
        value = en[key].lower()
        assert "buy" not in value
        assert "purchase" not in value
