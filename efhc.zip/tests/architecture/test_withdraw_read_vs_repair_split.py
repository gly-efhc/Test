from pathlib import Path


def test_user_withdraw_list_has_no_repair_call() -> None:
    src = Path("backend/app/routes/withdraw_routes.py").read_text(
        encoding="utf-8"
    )
    assert "async def get_withdraw_list" in src
    assert "ensure_consistency(" not in src
    assert "backfill: bool = True" not in src


def test_admin_withdraw_repair_is_admin_only() -> None:
    src = Path(
        "backend/app/routes/admin_withdrawals_routes.py"
    ).read_text(encoding="utf-8")
    assert '"/repair-consistency"' in src
    assert "require_admin" in src
    assert "ensure_consistency(" in src
