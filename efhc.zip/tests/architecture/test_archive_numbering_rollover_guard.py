from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INVALID_VERSION = re.compile(r"\bv(?P<major>\d{2,4})_(?P<minor>\d{3,})\b")
HISTORICAL_INVALID_ALIASES = {
    "v165_100",
    "v165_101",
    "v168_100",
    "v168_101",
    "v170_100",
}
CURRENT_CANONICAL_HEAD = "v171_31"


def _iter_text_files():
    excluded = {
        ".git",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "node_modules",
        ".next",
    }
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in excluded for part in path.parts):
            continue
        if path.suffix.lower() not in {
            ".md",
            ".py",
            ".json",
            ".yaml",
            ".yml",
            ".txt",
            ".csv",
        }:
            continue
        yield path


def _rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _is_negative_test_context(line: str) -> bool:
    return "not in" in line or "forbidden" in line.lower()


def _invalid_versions_in(path: Path):
    rel = _rel(path)
    for match in INVALID_VERSION.finditer(rel):
        version = match.group(0)
        if version not in HISTORICAL_INVALID_ALIASES:
            yield f"{rel}:path:{version}"

    text = path.read_text(encoding="utf-8", errors="ignore")
    for lineno, line in enumerate(text.splitlines(), start=1):
        for match in INVALID_VERSION.finditer(line):
            version = match.group(0)
            if version in HISTORICAL_INVALID_ALIASES:
                continue
            if _is_negative_test_context(line):
                continue
            yield f"{_rel(path)}:{lineno}:{version}"


def test_no_current_or_future_three_digit_minor_versions():
    offenders: list[str] = []
    for path in _iter_text_files():
        offenders.extend(_invalid_versions_in(path))
    assert not offenders, (
        "Three-digit archive minor suffixes are forbidden. "
        "After vN_99 use v(N+1)_00. Offenders:\n"
        + "\n".join(offenders)
    )


def test_current_head_uses_rollover_version():
    kernel = (ROOT / "KERNEL.md").read_text(encoding="utf-8")
    map_element = (ROOT / "map_element.md").read_text(encoding="utf-8")
    assert CURRENT_CANONICAL_HEAD in kernel
    assert CURRENT_CANONICAL_HEAD in map_element


def test_rollover_formula_is_enforced_in_canon():
    canon = (
        ROOT / "docs" / "NORM" / "ARCHIVE_NUMBERING_CANON.md"
    ).read_text(encoding="utf-8")
    assert "00" in canon
    assert "99" in canon
    assert "v(N+1)_00" in canon
    assert "three-digit minor" in canon
    assert "exactly two digits" in canon


def test_invalid_minor_pattern_detection_catches_future_regression():
    simulated = "v" + "171" + "_" + "100"
    assert INVALID_VERSION.search(simulated)
    assert simulated not in HISTORICAL_INVALID_ALIASES


def test_short_archive_filename_is_current_canon():
    canon = (
        ROOT / "docs" / "NORM" / "ARCHIVE_NUMBERING_CANON.md"
    ).read_text(encoding="utf-8")
    assert "EFHC_Bot_v<major>_<minor_two_digits>.zip" in canon
    assert "cycle and title belong inside archive documents" in canon
