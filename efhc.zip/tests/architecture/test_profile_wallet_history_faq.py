import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROFILE = ROOT / "frontend/src/features/profile/WebProfilePage.tsx"
WALLET = (
    ROOT / "frontend/src/components/profile/ProfileWalletSection.tsx"
)
HISTORY = (
    ROOT / "frontend/src/components/profile/ProfileHistorySection.tsx"
)
FAQ_PAGE = ROOT / "frontend/src/pages/faq.tsx"
FAQ_TREE = ROOT / "frontend/src/components/faq/FaqVerticalTree.tsx"
LOCALES = ROOT / "frontend/public/locale"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_profile_status_badges_are_always_visible_and_not_technical():
    text = read(PROFILE)
    assert 'data-profile-status-model="always-visible-1303"' in text
    assert (
        'data-profile-vip-status={isVip ? "active" : "inactive"}'
        in text
    )
    assert "data-profile-active-status={" in text
    assert 't("profile.vip_badge")' in text
    assert 't("profile.active_badge")' in text
    assert "Browser ready" not in text
    assert "independent shell" not in text


def test_profile_faq_is_button_only_not_embedded_mini_faq():
    text = read(PROFILE)
    assert 'data-profile-faq-button-only="1304"' in text
    assert 'data-profile-faq-entry="button-1304"' in text
    assert 'href="/faq"' in text
    assert "ProfileFaqSection" not in text
    assert "getFaqCatalog" not in text


def test_wallet_is_wallet_list_only_and_has_safe_error_microcopy():
    profile_text = read(PROFILE)
    wallet_text = read(WALLET)
    assert (
        'data-wallet-list-boundary="wallet-list-only-1305"'
        in profile_text
    )
    assert 'data-wallet-list-only="1305"' in wallet_text
    assert 'data-wallet-error-microcopy="safe-1306"' in wallet_text
    assert "props.walletsError}</TelegramInfoBlock>" not in wallet_text
    wallet_section = profile_text.split(
        'data-wallet-list-boundary="wallet-list-only-1305"'
    )[1]
    wallet_section = wallet_section.split('{activeTab === "history"')[0]
    assert "profile.main_balance" not in wallet_section
    assert "profile.bonus_balance" not in wallet_section
    assert "balances.total_label" not in wallet_section
    assert "latest_withdraw" not in wallet_section


def test_history_account_timeline_filters_and_contract_markers_exist():
    text = read(HISTORY)
    assert 'data-history-account-timeline="1307"' in text
    assert (
        'data-history-data-contract="balance-history-withdraw-me-1308"'
        in text
    )
    assert (
        'data-history-filters="all-purchases-exchange-withdraw-bonuses-'
        'panels"'
        in text
    )
    for value in [
        "all",
        "purchases",
        "exchange",
        "withdraw",
        "bonuses",
        "panels",
    ]:
        assert "data-history-filter={filter}" in text
        assert f'"{value}"' in text
    profile_text = read(PROFILE)
    service = read(ROOT / "frontend/src/services/profile.service.ts")
    assert "/wallets/balance-history?" in service
    assert "/withdraw/list/me?" in service
    assert 'set("tg_id"' not in profile_text


def test_faq_is_compact_vertical_tree_without_open__all__or_pills():
    page = read(FAQ_PAGE)
    tree = read(FAQ_TREE)
    assert 'data-faq-compact-tree="1309"' in page
    assert 'data-faq-no-horizontal-pills="true"' in page
    assert 'compactTreeProof="1309"' in page
    assert "openAll" not in page
    assert (
        'data-faq-vertical-tree={props.compactTreeProof || "true"}'
        in tree
    )
    assert "FaqQuickLinks" not in page
    assert "FaqPopularQuestions" not in page


def test_profile_wallet_history_faq_locale_keys_exist():
    required = [
        "profile.faq_button_note",
        "wallet.error_body",
        "history.filter_all",
        "history.filter_purchases",
        "history.filter_exchange",
        "history.filter_withdraw",
        "history.filter_bonuses",
        "history.filter_panels",
        "history.load_error",
        "faq.counts_summary",
    ]
    for path in LOCALES.glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in required:
            assert key in data, f"{path.name} missing {key}"
