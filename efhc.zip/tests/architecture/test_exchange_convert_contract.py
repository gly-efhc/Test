from pathlib import Path


def test_exchange_convert_route_keeps_amount_contract() -> None:
    src = Path("backend/app/routes/exchange_routes.py").read_text(
        encoding="utf-8"
    )
    assert "amount_kwh" in src
    assert '"Если пропустить — обменять максимум."' in src


def test_exchange_service_no_longer_forces_exchange__all__only() -> (
    None
):
    src = Path("backend/app/services/exchange_service.py").read_text(
        encoding="utf-8"
    )
    assert "exchange_partial_available_kwh_to_main" in src
    assert "if amount_kwh is None" in src


def test_transactions_service_has_partial_exchange_audit() -> None:
    src = Path(
        "backend/app/services/transactions_service.py"
    ).read_text(encoding="utf-8")
    assert "EXCHANGE_PARTIAL" in src
    assert "requested_amount_kwh" in src
    assert "actual_amount_kwh" in src
