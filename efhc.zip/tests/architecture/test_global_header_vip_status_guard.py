from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_global_header_keeps_vip_and_activ_statuses_visible() -> None:
    src = (ROOT / "frontend/src/components/GlobalHeader.tsx").read_text()
    assert 'kind="vip"' in src
    assert 'kind="activ"' in src
    assert 'active={props.isVip}' in src
    assert 'active={props.hasActiv}' in src
    assert 'label={t("profile.vip_badge")}' in src
    assert 'label={t("profile.activ_badge")}' in src
    assert 'data-status={props.kind}' in src
    assert 'data-active={props.active ? "true" : "false"}' in src
    assert 'className="efhc-vip-crown"' not in src
    assert "👑" not in src
    assert "{props.isVip ? (" not in src
