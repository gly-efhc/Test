"""Переходная граница global owner до удаления alias-слоя.

На этапе test-repair старые provider/compatibility имена ещё существуют.
Guard запрещает рост legacy-слоя и требует canonical ``global_id`` в
ключевых бизнес-контурах. После exact-head PASS baseline уменьшается до
нуля и удаляется вместе с alias-harness.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONTRACT = ROOT / "contracts/identity/global_owner_tg_id_boundary_v1.json"
BASELINE = (
    ROOT
    / "contracts/identity/tg_id_compatibility_baseline_v172_64.json"
)
TOKEN = re.compile(r"\btg_id\b")


def _current_counts() -> dict[str, int]:
    counts: dict[str, int] = {}
    for path in (ROOT / "backend/app").rglob("*.py"):
        relative = path.relative_to(ROOT).as_posix()
        count = sum(
            len(TOKEN.findall(line))
            for line in path.read_text(
                encoding="utf-8", errors="ignore"
            ).splitlines()
        )
        if count:
            counts[relative] = count
    return counts


def test_слой_совместимости_tg_id_не_растёт() -> None:
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))["files"]
    current = _current_counts()
    new_files = sorted(set(current) - set(baseline))
    increased = sorted(
        f"{path}:{current[path]}>{baseline[path]}"
        for path in current.keys() & baseline.keys()
        if current[path] > int(baseline[path])
    )
    assert not new_files, f"new tg_id files: {new_files}"
    assert not increased, f"tg_id compatibility grew: {increased}"


def test_канонический_owner_есть_в_критических_бизнес_сервисах() -> None:
    required = {
        "backend/app/services/transactions_service.py": [
            "global_id",
            "resolve_and_lock_financial_write_owner",
        ],
        "backend/app/services/panels_service.py": ["global_id"],
        "backend/app/services/withdraw_service.py": ["global_id"],
        "backend/app/services/payment_intents_service.py": ["global_id"],
        "backend/app/services/referral_service.py": ["global_id"],
        "backend/app/services/tasks_service.py": ["global_id"],
        "backend/app/services/ranks_service.py": ["global_id"],
        "backend/app/services/wallets_service.py": ["global_id"],
    }
    missing: list[str] = []
    for relative, markers in required.items():
        text = (ROOT / relative).read_text(encoding="utf-8")
        for marker in markers:
            if marker not in text:
                missing.append(f"{relative}:{marker}")
    assert not missing, missing



def test_runtime_alias_global_owner_удалён() -> None:
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    assert contract["temporary_alias_removed"] is True
    assert not (
        ROOT / "backend/app/identity/global_owner_alias.py"
    ).exists()
