from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAGE = ROOT / "frontend/src/features/browser-shop/BrowserShopPage.tsx"
SERVICE = ROOT / "frontend/src/services/browserShop.service.ts"
PROFILE = ROOT / "frontend/src/components/ProfileModal.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_browser_shop_pay_button_uses_tx_internally() -> None:
    src = _read(PAGE)
    service_ts = _read(SERVICE)

    assert "useWalletProvider" in src
    assert "sendTransaction" in src
    assert "normalizeTonConnectTx" in src
    assert "parseBrowserShopCreateIntentResponse(raw)" in service_ts
    assert "parsed.tonconnect_tx" in src
    assert "sendTransaction(tx)" in src
    assert "WALLET_TX_MISSING" in src


def test_browser_shop_does_not_render_raw_tonconnect_payload() -> None:
    src = _read(PAGE)
    render_part = src.split("return (")[-1]

    assert "tonconnect_tx" not in render_part
    assert "to_wallet" not in render_part
    assert "memo" not in render_part
    assert "Copy" not in render_part


def test_profile_language_selector_is_dropdown() -> None:
    profile = _read(PROFILE)
    css = _read(CSS)

    assert "languageMenuOpen" in profile
    assert "efhc-language-select_current" in profile
    assert "efhc-language-select_option" in profile
    assert "selectLanguage(lang)" in profile
    assert "efhc-language-pill" not in profile

    assert ".efhc-language-select_button" in css
    assert ".efhc-language-select_option--active" in css
    assert ".efhc-language-pill" not in css


def test_language_route_has_labels_for__all__supported_locales() -> (
    None
):
    import json

    locale_dir = ROOT / "frontend/public/locale"
    langs = [
        "en",
        "ru",
        "uk",
        "de",
        "fr",
        "es",
        "it",
        "tr",
        "pl",
        "da",
        "hi",
        "id",
        "sw",
    ]
    required = {f"profile.lang.{lang}" for lang in langs}
    for path in sorted(locale_dir.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(key for key in required if not data.get(key))
        assert not missing, f"{path.name}: {missing}"
