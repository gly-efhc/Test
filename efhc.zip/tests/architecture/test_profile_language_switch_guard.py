from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_profile_language_switch_controls_runtime_ui_dict() -> None:
    app = _read("frontend/src/pages/_app.tsx")

    assert "settingsHydrated" in app
    assert "if (!settingsHydrated) return;" in app
    assert "loadDict(lang)" in app
    assert "setUiDict(dict)" in app
    assert "setDescDict(dict)" in app

    stale = re.search(
        r"loadDict\(\"en\"\).*setUiDict",
        app,
        flags=re.S,
    )
    assert stale is None


def test_profile_language_selector_is_dropdown() -> None:
    profile = _read("frontend/src/components/ProfileModal.tsx")
    css = _read("frontend/src/styles/globals.css")

    assert "efhc-language-select_button" in profile
    assert 'aria-haspopup="listbox"' in profile
    assert "aria-expanded={languageMenuOpen}" in profile
    assert "efhc-language-select_menu" in profile
    assert "selectLanguage(lang)" in profile
    assert "efhc-language-bar" not in profile
    assert "efhc-language-grid" not in profile

    assert ".efhc-language-select_button" in css
    assert ".efhc-language-select_menu" in css
    assert ".efhc-language-bar" not in css
    assert ".efhc-language-grid" not in css


def test_bottom_navigation_labels_remain_english_canon() -> None:
    layout = _read("frontend/src/components/Layout.tsx")
    m = re.search(
        r"const\s+bottom\s*=\s*\[(?P<body>.*?)\]\s*;",
        layout,
        flags=re.S,
    )
    assert m, "bottom tabs array not found"
    body = m.group("body")

    labels = re.findall(r"visualLabel:\s*\"([^\"]+)\"", body)
    assert labels == [
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
    ]
    assert 'visualLabel: t("nav.' not in body
