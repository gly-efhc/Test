from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALES = [
    "en",
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1499_docs_and_reports_exist() -> None:
    expected = [
        "docs/NORM/VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md",
        "docs/NORM/VIS_03_WITHDRAW_HISTORY_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1499_VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md",
        "reports/generated/vis_03_withdraw_history_semantic_repair_v170_75.json",
        "reports/generated/green_ci_log_proof_v170_75.json",
        "reports/change_cycle_2026-06-11_v170_75_cycle_1499_vis_03_withdraw_history_semantic_repair.md",
    ]
    for rel in expected:
        assert (ROOT / rel).exists(), rel


def test_withdraw_history_uses_semantic_balance_type_label() -> None:
    text = read("frontend/src/pages/withdraw.tsx")
    assert "const balanceLabel = balanceTypeLabel(item.balance_type, t);" in text
    assert "data-withdraw-history-balance-type-label=\"semantic\"" in text
    assert "data-withdraw-history-balance-type-raw-hidden=\"true\"" in text
    assert "data-withdraw-history-balance-type=\"localized\"" in text
    assert "{balanceLabel}" in text
    assert "{item.balance_type} ·" not in text
    assert "item.balance_type} ·" not in text


def test_withdraw_history_row_has_accessible_semantic_label() -> None:
    text = read("frontend/src/pages/withdraw.tsx")
    assert "const rowLabel = [" in text
    assert "historyReasonLabel(item.reason)" in text
    assert "directionLabel" in text
    assert "balanceLabel" in text
    assert "aria-label={rowLabel}" in text


def test_balance_type_formatter_is_not_raw_fallback() -> None:
    text = read("frontend/src/lib/humanLabels.ts")
    assert "if (value === \"main\") return t(\"withdraw.balance_main\");" in text
    assert "if (value === \"bonus\") return t(\"withdraw.balance_bonus\");" in text
    assert "return t(\"withdraw.balance_unknown\");" in text
    assert "return balanceType" not in text


def test_withdraw_balance_labels_exist_in_all_public_locales() -> None:
    keys = [
        "withdraw.balance_main",
        "withdraw.balance_bonus",
        "withdraw.balance_unknown",
        "withdraw.credit",
        "withdraw.debit",
    ]
    for locale in LOCALES:
        data = json.loads(read(f"frontend/public/locale/{locale}.json"))
        for key in keys:
            value = data.get(key)
            assert isinstance(value, str) and value.strip(), (locale, key)


def test_green_log_proof_is_fixed_without_claiming_new_ci() -> None:
    proof = json.loads(read("reports/generated/green_ci_log_proof_v170_75.json"))
    assert proof["source"] == "logs_73559592200.zip"
    assert proof["input_line_green"] is True
    assert proof["not_claimed_for_new_archive_after_cycle_1499"] is True
    facts = proof["facts"]
    assert facts["gate_summary"] == "OK: all gate steps passed."
    assert facts["pytest"] == "1694 passed, 8 skipped, 1 warning"


def test_manifest_and_counters_are_updated_for_1499() -> None:
    manifest = json.loads(read("docs/testing/TEST_GUARD_MANIFEST.json"))
    assert manifest["last_updated_cycle"] >= 1499
    assert manifest["last_updated_version"] >= "v170.75"
    assert manifest["active_architecture"] >= 321
    assert any(
        item.get("file") == "tests/architecture/test_vis_03_withdraw_history_semantic_repair.py"
        for item in manifest.get("active_guards", [])
        if isinstance(item, dict)
    )


def test_kernel_and_map_reference_1499_work_item() -> None:
    kernel = read("KERNEL.md")
    mapping = read("map_element.md")
    nav = kernel + mapping
    assert "1499 — VIS-03 Withdraw History Semantic Repair" in nav
    assert "VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md" in nav
    assert "test_vis_03_withdraw_history_semantic_repair.py" in mapping
    assert "VIS-03" in mapping
