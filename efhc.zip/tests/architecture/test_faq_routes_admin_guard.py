from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_faq_uses_vertical_tree_without_category_pills() -> None:
    faq_page = read("frontend/src/pages/faq.tsx")
    assert "FaqVerticalTree" in faq_page
    assert "TelegramCategoryPills" not in faq_page
    assert "FaqQuickLinks" not in faq_page
    assert "FaqPopularQuestions" not in faq_page


def test_profile_keeps_faq_button_and_vertical_preview() -> None:
    profile = read("frontend/src/features/profile/WebProfilePage.tsx")
    section = read(
        "frontend/src/components/profile/ProfileFaqSection.tsx"
    )
    assert 'activeTab === "faq"' in profile
    assert 'href="/faq"' in section
    assert "FaqVerticalTree" in section
    assert "TelegramActionCard" not in section


def test_admin_uses_app_button_grid_not_nested_link_rows() -> None:
    admin = read("frontend/src/pages/admin/index.tsx")
    grid = read("frontend/src/components/admin/AdminAppButtonGrid.tsx")
    assert "AdminAppButtonGrid" in admin
    assert "release-core evidence" not in admin
    assert "<Link" not in admin
    assert "efhc-admin-app-button" in grid


def test_tunnel_probe_and_route_probe_exist() -> None:
    tunnel = read("ops/local/tunnel_probe.ps1")
    routes = read("ops/local/check_frontend_routes.py")
    assert "cloudflared:2026.4.0" in tunnel
    assert "api.trycloudflare.com/tunnel" in tunnel
    assert "Missing frontend routes" in routes
