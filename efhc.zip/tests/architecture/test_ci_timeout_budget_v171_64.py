from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
WORKFLOWS = [ROOT / ".github/workflows/canon.yml", ROOT / "ci.yml"]


def _workflow(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def test_canon_ci_job_timeout_covers_full_universal_pipeline() -> None:
    for path in WORKFLOWS:
        data = _workflow(path)
        job = data["jobs"]["canon"]
        timeout = job["timeout-minutes"]
        assert timeout == 35
        assert 30 <= timeout <= 40
        source = path.read_text(encoding="utf-8")
        assert "timeout-minutes: 18" in source
        assert "--kill-after=30s 15m" in source


def test_ci_workflow_mirror_stays_identical() -> None:
    assert WORKFLOWS[0].read_bytes() == WORKFLOWS[1].read_bytes()
