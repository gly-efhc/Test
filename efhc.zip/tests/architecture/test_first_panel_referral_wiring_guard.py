from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _async_function(tree: ast.AST, name: str) -> ast.AsyncFunctionDef:
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == name:
            return node
    raise AssertionError(f"async function not found: {name}")


def _call_text(node: ast.AST) -> str:
    return ast.unparse(node)


def test_first_panel_referral_hook_is_inside_transaction() -> None:
    source = (
        ROOT / "backend/app/services/panels_service.py"
    ).read_text(encoding="utf-8")
    tree = ast.parse(source)
    activate = _async_function(tree, "activate_panel")

    tx_blocks = [
        node
        for node in ast.walk(activate)
        if isinstance(node, ast.AsyncWith)
        and "bank._tx_context(db)" in _call_text(node)
    ]
    assert len(tx_blocks) == 1

    tx_text = _call_text(tx_blocks[0])
    assert "current_active == 0" in tx_text
    assert "on_user_first_panel_activation" in tx_text
    assert tx_text.index("_create_panel_records_bulk") < tx_text.index(
        "on_user_first_panel_activation"
    )


def test_referral_rewards_use_no_commit_money_path() -> None:
    referral = (
        ROOT / "backend/app/services/referral_service.py"
    ).read_text(encoding="utf-8")
    transactions = (
        ROOT / "backend/app/services/transactions_service.py"
    ).read_text(encoding="utf-8")

    assert "credit_user_bonus_from_bank_nocommit" in referral
    assert (
        "async def credit_user_bonus_from_bank_nocommit"
        in transactions
    )

    tree = ast.parse(referral)
    hook = _async_function(tree, "on_user_first_panel_activation")
    reward_group = _async_function(
        tree,
        "_award_first_panel_referral_rewards",
    )
    unit = _async_function(tree, "_maybe_reward_active_unit_bonus")
    levels = _async_function(tree, "_sync_inviter_level_rewards")
    hook_body = ast.unparse(hook)
    reward_body = ast.unparse(reward_group)
    assert "_award_first_panel_referral_rewards" in hook_body
    assert "_maybe_reward_active_unit_bonus" in reward_body
    assert "_sync_inviter_level_rewards" in reward_body
    assert "referral_bonus_transaction_rolled_back" in reward_body
    assert any(isinstance(node, ast.Raise) for node in ast.walk(reward_group))
    for function in (unit, levels):
        body = ast.unparse(function)
        assert "credit_user_bonus_from_bank_nocommit" in body
        assert "credit_user_bonus_from_bank(" not in body
    assert "referral_level_bonus" in referral
    assert "REF_LVL:" in referral
    assert not any(
        isinstance(node, ast.Try) for node in ast.walk(hook)
    ), "first-panel hook must not swallow referral reward errors"


def test_mypy_default_scope_matches_full_backend_ci() -> None:
    config = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
    assert 'files = ["backend/app"]' in config
    assert "mypy-backend:" in makefile
    assert "mypy backend/app" in makefile
