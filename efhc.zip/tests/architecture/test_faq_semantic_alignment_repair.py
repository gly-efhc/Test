from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LANGS = (
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)


def _flat(lang: str) -> dict[int, dict[str, str]]:
    data = json.loads(
        (ROOT / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.json").read_text(
            encoding="utf-8"
        )
    )
    out: dict[int, dict[str, str]] = {}
    n = 0
    for section in data["sections"]:
        for item in section["items"]:
            n += 1
            out[n] = {
                "q": item["q"],
                "a": item["a"],
                "section": str(section["id"]),
            }
    return out


def test_semantic_alignment_docs_exist() -> None:
    required = [
        "docs/frontend/FAQ_SEMANTIC_ALIGNMENT_REPAIR.md",
        "docs/audits/FAQ_SEMANTIC_ALIGNMENT_AUDIT_V169_50.md",
        (
            "reports/change_cycle_2026-06-02_v169_50_cycle_1371_faq_"
            "semantic_alignment_repair.md"
        ),
        "reports/generated/faq_semantic_alignment_repair_v169_50.json",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_wallet_item_45_matches_account_linking_semantics() -> None:
    for lang in LANGS:
        item = _flat(lang)[45]
        text = (item["q"] + "\n" + item["a"]).lower()
        assert "what else is the wallet needed" not in text
        assert "besides withdrawals" not in text
        if lang == "en":
            assert "two accounts" in text
            assert "linked to one account" in text
        if lang == "ru":
            assert "двум аккаунтам" in text
            assert "отвязать" in text


def test_main_wallet_item_42_uses_top_up_not_deposit_semantics() -> (
    None
):
    en_item = _flat("en")[42]
    text = (en_item["q"] + "\n" + en_item["a"]).lower()
    assert "top-ups" in text
    assert "deposits" not in text
    ru_item = _flat("ru")[42]
    assert "пополн" in ru_item["a"].lower()


def test_navigation_rules_items_aligned_to_ru_detail_not_summary_en() -> (
    None
):
    en = _flat("en")
    assert "account data" in en[162]["a"].lower()
    assert "balance movements" in en[162]["a"].lower()
    assert "top bar" in en[163]["a"].lower()
    assert "balances and movements" in en[164]["a"].lower()
    assert "Wallet" in en[165]["a"] and "Hub" in en[165]["a"]
    assert "main screen and the top bar" in en[166]["a"]
    assert "screen name and button" in en[171]["a"].lower()
    assert "unnecessary steps" in en[172]["a"].lower()


def test_semantic_alignment_governance_recorded() -> None:
    qa = (
        ROOT / "docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md"
    ).read_text(encoding="utf-8")
    assert "FAQ semantic alignment rule after 1371" in qa
    assert "SSOT" in qa and "regression" in qa
    faq_ssot = (ROOT / "docs/SSOT/FAQ_SSOT.md").read_text(
        encoding="utf-8"
    )
    assert "Q/A regression check before trusting SSOT" in faq_ssot
    status = (
        ROOT / "docs/SSOT/faq_ssot/TRANSLATION_STATUS.md"
    ).read_text(encoding="utf-8")
    assert "SEMANTIC_ALIGNED_TO_RU_QA" in status


def test_approval_manifest_contains_semantic_alignment_entry() -> None:
    manifest = json.loads(
        (
            ROOT / "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json"
        ).read_text(encoding="utf-8")
    )
    entries = manifest["entries"]
    assert int(manifest["entries_total"]) == len(entries)
    entry = next(
        (e for e in entries if e["approval_id"] == "FAQ-APPROVAL-0012"),
        None,
    )
    assert entry is not None
    assert entry["status"] == "implemented"
    assert entry["rewrite_allowed"] is True
    assert entry["runtime_rebuild_allowed"] is True
    assert 45 in entry["ru_question_ids"]


def test_generated_semantic_matrix_records_corrected_items() -> None:
    report = json.loads(
        (
            ROOT
            / "reports/generated/faq_semantic_alignment_repair_v169_50.json"
        ).read_text(encoding="utf-8")
    )
    assert report["status"] == "DONE_STATIC_SEMANTIC_ALIGNMENT"
    assert 45 in report["semantic_corrected_items"]
    assert 162 in report["semantic_corrected_items"]
    assert report["translation_source_boundary"].startswith(
        "Sandbox archives are not translation sources"
    )


def test_faq_catalog_generated_from_semantic_ssot() -> None:
    catalog = (ROOT / "frontend/src/data/faq/catalogs.ts").read_text(
        encoding="utf-8"
    )
    assert (
        "Why can’t the same wallet be linked to two accounts?"
        in catalog
    )
    assert (
        "What else is the wallet needed for besides withdrawals?"
        not in catalog
    )
    assert "The main wallet is used for actions connected" in catalog
