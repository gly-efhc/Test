from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_helper_internal_boundary_guard_1194() -> None:
    script = ROOT / "ops/routes/check_helper_internal_boundary.py"
    result = subprocess.run(
        [sys.executable, "-S", str(script)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
