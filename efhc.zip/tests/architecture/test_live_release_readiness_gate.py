from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / (
    "reports/generated/live_release_readiness_gate_v170_97.json"
)
GATE = ROOT / "ops/release/release_readiness_proof_gate.py"
NORM = ROOT / "docs/NORM" / (
    "LIVE_TELEGRAM_REAL_TONCONNECT_RELEASE_PROOF_GATE.md"
)
CYCLE_DOC = (
    "docs/cycles/"
    "WORK_CYCLES_1521_LIVE_TELEGRAM_REAL_TONCONNECT_"
    "RELEASE_PROOF_GATE.md"
)
CHANGE_REPORT = (
    "reports/change_cycle_2026-06-16_v170_97_cycle_1521_"
    "live_release_readiness_gate.md"
)


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_live_release_gate_report_is_fail_closed() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["schema"] == "EFHC_LIVE_RELEASE_READINESS_GATE_V1"
    assert data["cycle"] == 1521
    assert data["input_head"] == "v170.96"
    assert data["output_target"] == "v170.97"
    assert data["release_ready"] is False
    assert data["release_readiness_status"] == "NOT_RELEASE_READY"
    blockers = data["release_blockers"]
    assert "LIVE_EXTERNAL_PROOF_NOT_EXECUTED" in blockers
    assert "FRESH_GITHUB_CI_PROOF_NOT_PROVIDED" in blockers


def test_live_and_real_external_proofs_are_not_faked() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    live = data["live_telegram_proof"]
    real = data["real_tonconnect_proof"]
    assert live["executed"] is False
    assert real["executed"] is False
    assert live["status"] == "BLOCKED_MISSING_ENV"
    assert real["status"] == "BLOCKED_MISSING_ENV"
    ci = data["fresh_github_ci_proof"]
    assert ci["executed"] is False
    assert ci["status"] == "NOT_PROVIDED_FOR_V170_96"


def test_local_visual_i18n_proofs_are_recorded_as_local_only() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    reports = data["local_reports"]
    assert reports["admin_visual_runtime"]["gate_status"] == "PASSED"
    assert reports["public_pages_visual"]["gate_status"] == "PASSED"
    i18n = reports["frontend_i18n_visual_closure"]
    assert i18n["gate_status"] == "PASSED"
    assert data["release_ready"] is False


def test_gate_does_not_record_secret_values() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    text = json.dumps(data, ensure_ascii=False)
    assert "xoxb-" not in text
    assert "Bearer " not in text
    assert "postgresql://postgres:" not in text
    assert (
        data["live_telegram_proof"]["secret_values_recorded"] is False
    )
    assert (
        data["real_tonconnect_proof"]["secret_values_recorded"] is False
    )
    assert data["secret_hygiene"]["status"] == "PASS"


def test_gate_script_is_env_checked_not_network_faked() -> None:
    text = GATE.read_text(encoding="utf-8")
    assert "LIVE_TELEGRAM_ENV" in text
    assert "REAL_TONCONNECT_ENV" in text
    assert "BLOCKED_MISSING_ENV" in text
    assert '"release_ready": False' in text
    assert "requests.get" not in text
    assert "urllib.request" not in text


def test_release_docs_do_not_claim_release_ready() -> None:
    docs = [
        NORM.read_text(encoding="utf-8"),
        _read(CYCLE_DOC),
        _read(CHANGE_REPORT),
    ]
    joined = "\n".join(docs)
    assert "not a release-ready archive" in joined
    assert "does not perform a real Telegram client pass" in joined
    assert "perform a real TonConnect wallet transaction" in joined
    assert "GITHUB_CI_GREEN" in joined
    assert "RELEASE_READY" in joined
