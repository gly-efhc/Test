from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADMIN_USERS_ROUTES = ROOT / "backend" / "app" / "routes" / "admin_users_routes.py"
WALLETS_SERVICE = ROOT / "backend" / "app" / "services" / "wallets_service.py"
WATCHER = ROOT / "backend" / "app" / "services" / "watcher_service.py"
FRONTEND_ADMIN_USERS = ROOT / "frontend" / "src" / "pages" / "admin" / "users.tsx"
WALLETS_MODEL = ROOT / "backend" / "app" / "models" / "wallets_models.py"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _reset_wallet_route_body() -> str:
    src = read(ADMIN_USERS_ROUTES)
    decorator = src.index('@router.post("/{global_id}/wallet/reset"')
    return src[decorator:]


def _admin_reset_wallet_bindings_body() -> str:
    src = read(WALLETS_SERVICE)
    start = src.index("async def admin_reset_wallet_bindings")
    end = src.index("async def deactivate_wallet", start)
    return src[start:end]


def test_проверка_admin_wallet_reset_resets_canonical_wallet_bindings() -> None:
    route = _reset_wallet_route_body()
    service = _admin_reset_wallet_bindings_body()

    assert "wallets_service.admin_reset_wallet_bindings" in route
    assert "UPDATE efhc_core.users" in route
    assert "ton_wallet = NULL" in route
    assert "UPDATE efhc_core.wallet_bindings" in service
    assert "is_active = false" in service
    assert "is_primary = false" in service
    assert "WHERE global_id = :global_id" in service
    assert "is_active = true OR is_primary = true" in service


def test_проверка_admin_wallet_reset_writes_audit_log() -> None:
    route = _reset_wallet_route_body()
    assert "AdminLogger.write" in route
    assert 'action="reset_wallet"' in route
    assert 'entity="user"' in route
    assert "wallet_bindings_deactivated" in route
    assert "idem={idem}" in route


def test_проверка_admin_wallet_reset_requires_admin_guard() -> None:
    route = _reset_wallet_route_body()
    assert '@router.post("/{global_id}/wallet/reset", status_code=204)' in route
    assert "Depends(require_admin)" in route
    assert "Idempotency-Key" in route
    assert "_require_idempotency" in route


def test_проверка_wallet_reset_reflected_in_profile_wallet_state() -> None:
    route = _reset_wallet_route_body()
    frontend = read(FRONTEND_ADMIN_USERS)
    wallets_service = read(WALLETS_SERVICE)

    assert "ton_wallet = NULL" in route
    assert "wallets_service.admin_reset_wallet_bindings" in route
    assert "await loadDetail(globalId);" in frontend
    assert "await loadList(query);" in frontend
    assert 'disabled={busyAction !== "" || !selected.ton_wallet}' not in frontend
    assert 'disabled={busyAction !== ""}' in frontend
    assert "async def has_active_wallet" in wallets_service
    assert "is_active = true" in wallets_service
    assert "proof_verified = true" in wallets_service


def test_проверка_revoked_wallet_not_used_by_deposit_watcher() -> None:
    watcher = read(WATCHER)
    start = watcher.index("async def _find_user_by_wallet")
    end = watcher.index("async def _find_user_by_tg_id", start)
    body = watcher[start:end]

    assert "efhc_core.wallet_bindings" in body
    assert "is_active = TRUE" in body
    assert "proof_verified = TRUE" in body
    assert "efhc_core.user_wallets" not in body
    assert "users.ton_wallet" not in body


def test_проверка_admin_wallet_reset_service_does_not_commit_inside_helper() -> None:
    body = _admin_reset_wallet_bindings_body()
    route = _reset_wallet_route_body()
    assert "await db.commit()" not in body
    assert route.count("await db.commit()") == 1


def test_проверка_wallet_bindings_model_remains_canonical() -> None:
    model = read(WALLETS_MODEL)
    assert 'class WalletBinding' in model
    assert '__tablename__ = "wallet_bindings"' in model
    assert "global_id: Mapped[int]" in model
    assert "tg_id: Mapped[int | None]" in model
    assert "wallet_address: Mapped[str]" in model
    assert "is_active: Mapped[bool]" in model
    assert "proof_verified: Mapped[bool]" in model
