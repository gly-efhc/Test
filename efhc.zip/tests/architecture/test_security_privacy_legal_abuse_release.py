from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_frontend_dependency_advisory_is_closed() -> None:
    package = json.loads(read("frontend/package.json"))
    lock = json.loads(read("frontend/package-lock.json"))
    assert package["dependencies"]["axios"] == "1.18.0"
    assert lock["packages"]["node_modules/axios"]["version"] == "1.18.0"
    assert "packages.applied-caas-gateway" not in read(
        "frontend/package-lock.json"
    )


def test_backend_and_frontend_security_headers_are_active() -> None:
    backend = read("backend/app/middleware/security_headers.py")
    main = read("backend/app/main.py")
    frontend = read("frontend/next.config.js")
    for marker in [
        "X-Content-Type-Options",
        "Referrer-Policy",
        "Permissions-Policy",
        "Content-Security-Policy",
    ]:
        assert marker in backend
        assert marker in frontend
    assert "SecurityHeadersMiddleware" in main
    assert "MAX_REQUEST_BODY_BYTES" in main
    assert "Strict-Transport-Security" in frontend
    assert "frame-ancestors 'self' " in frontend
    assert "https://web.telegram.org" in frontend
    assert "https://*.telegram.org" in frontend
    assert "X-Frame-Options" not in frontend


def test_health_error_does_not_expose_database_exception() -> None:
    main = read("backend/app/main.py")
    health = main.split("async def health_db", 1)[1].split(
        'if __name__ == "__main__"',
        1,
    )[0]
    assert '"detail": str(e)' not in health
    assert 'content={"status": "error"}' in health
    assert "status_code=503" in health


def test_legal_policies_cover_all_canonical_languages() -> None:
    source = read("frontend/src/data/legalPolicies.ts")
    for lang in [
        "ru", "en", "uk", "de", "fr", "es", "it",
        "tr", "pl", "da", "hi", "id", "sw",
    ]:
        assert f"  {lang}: {{" in source
    assert "...COPY[lang][kind]" in source
    assert "...getLegalPolicyMeta(lang)" in source
    assert "data-legal-no-english-fallback" in read(
        "frontend/src/components/profile/LegalPolicyView.tsx"
    )


def test_legal_routes_are_visible_and_manifest_linked() -> None:
    profile = read("frontend/src/features/profile/WebProfilePage.tsx")
    modal = read("frontend/src/components/ProfileModal.tsx")
    manifest_api = read("frontend/src/pages/api/tonconnect-manifest.ts")
    fallback = json.loads(read("frontend/public/tonconnect-manifest.json"))
    assert 'legalParam === "terms"' in profile
    assert 'legalParam === "privacy"' in profile
    assert "/web-profile?legal=terms" in modal
    assert "/web-profile?legal=privacy" in modal
    assert "termsOfUseUrl" in manifest_api
    assert "privacyPolicyUrl" in manifest_api
    assert "legal=terms" in fallback["termsOfUseUrl"]
    assert "legal=privacy" in fallback["privacyPolicyUrl"]
    assert 'openTelegramLink("https://t.me/")' not in modal


def test_monetary_guards_normalize_api_prefix() -> None:
    locks = read("backend/app/core/system_locks.py")
    assert "def _strip_api_prefix" in locks
    assert "route_local_path = _strip_api_prefix(path)" in locks
    assert "_match_monetary__path__scope(path, self.prefixes)" in locks


def test_log_redactor_covers_structured_sensitive_fields() -> None:
    logging_source = read("backend/app/core/logging_core.py")
    for marker in [
        "SENSITIVE_FIELDS",
        '"authorization"',
        '"x-telegram-init-data"',
        '"private_key"',
        '"mnemonic"',
        "def _redact_value",
    ]:
        assert marker in logging_source


def test_historical_visual_evidence_is_local_only() -> None:
    pytest_ini = read("pytest.ini")
    workflow = read(".github/workflows/canon.yml")
    makefile = read("Makefile")
    assert "visual_evidence:" in pytest_ini
    assert "Chromium visual audit" in workflow
    assert "all_pages_route_backed_visual_audit.py" in workflow
    assert "visual-evidence:" in makefile
    for rel in [
        "tests/architecture/"
        "test_browser_admin_visual_button_click_proof.py",
        "tests/architecture/"
        "test_panels_exchange_release_readiness.py",
        "tests/architecture/"
        "test_public_frontend_buttons_api_i18n_drift.py",
    ]:
        source = read(rel)
        assert "@pytest.mark.visual_evidence" in source
        assert "assert_screenshot_evidence" in source
