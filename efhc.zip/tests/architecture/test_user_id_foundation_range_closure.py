"""После schema freeze historical foundation evidence остаётся в архиве."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_current_handoff_описывает_цикл_1632() -> None:
    handoff = (ROOT / "CONTINUE_IN_NEW_CHAT.md").read_text(encoding="utf-8")
    policy = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(encoding="utf-8")
    )
    version = policy["version"]
    assert f"EFHC_Bot_{version.replace('.', '_')}.zip" in handoff
    assert f"EFHC_Bot_{version.replace('.', '_')}_RELEASE.zip" in handoff
    assert "1632" in handoff
    assert "0001_initial_release_schema.py" in handoff
    assert "GitHub CI" in handoff


def test_historical_evidence_цикла_1600_не_переписывается() -> None:
    path = ROOT / "reports/generated/foundation_range_1593_1600_closure_v171_97.json"
    report = json.loads(path.read_text(encoding="utf-8"))
    assert report["цикл"] == 1600
    assert report["локально_закрыто"] is True
    assert report["alembic_head"] == "0001"
    assert report["миграционная_фаза"] == "EXPAND"
