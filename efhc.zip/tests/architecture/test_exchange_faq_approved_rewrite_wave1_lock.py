from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.json"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def test_exchange_replacements_present() -> None:
    data = json.loads(RU.read_text(encoding="utf-8"))
    sec = data["sections"][8]
    qa = {item["q"]: item["a"] for item in sec["items"]}
    assert qa["Что происходит в Exchange?"]
    assert qa[
        (
            "В какой баланс попадает обмен сгенерированной "
            "энергии в Exchange?"
        )
    ]
    assert qa["Почему Exchange не связан с бонусным балансом напрямую?"]


def test_cycle_111_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert "| 111 | done | RU Exchange approved rewrite wave 1." in text
