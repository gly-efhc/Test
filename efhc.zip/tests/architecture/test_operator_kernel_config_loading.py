from __future__ import annotations

from pathlib import Path

from ops.operator_kernel.config_loader import (
    ROUTES_CONFIG_VERSION,
    load_config_bundle,
    load_heavy_paths,
    load_invariants,
    load_layers,
    load_tool_modes,
    load_validation_config,
)
from ops.operator_kernel.file_map import HEAVY_PREFIXES, LAYER_PREFIXES
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.tool_registry import list_tools
from ops.operator_kernel.validation_router import route_checks

ROOT = Path(__file__).resolve().parents[2]


def test__all__operator_kernel_configs_are_loaded() -> None:
    bundle = load_config_bundle(ROOT)
    expected = {
        "routes.yaml",
        "layers.yaml",
        "invariants.yaml",
        "heavy_paths.yaml",
        "tool_registry.yaml",
        "validation_routes.yaml",
    }
    assert set(bundle) == expected
    assert all(bundle[name].strip() for name in expected)
    assert "version: 1" in bundle["routes.yaml"]
    assert ROUTES_CONFIG_VERSION == "1"


def test_config_files_drive_runtime_constants() -> None:
    layers = load_layers(ROOT)
    heavy = load_heavy_paths(ROOT)
    invariants = load_invariants(ROOT)
    tools = load_tool_modes(ROOT)
    validation = load_validation_config(ROOT)
    assert layers["AI"] == "docs/AI/"
    assert "docs/audits/" in heavy
    assert any("CI files" in item for item in invariants)
    assert tools["plan_patch"] == "dry_run"
    assert "validation_routes" in validation
    assert "docs/audits/" in HEAVY_PREFIXES
    assert LAYER_PREFIXES["AI"] == "docs/AI/"


def test_operator_kernel_routes_and_tools_use_configs() -> None:
    route = resolve_route("ci_log_repair")
    checks = route_checks(["ci.yml"])
    tools = list_tools()
    assert route["config_loaded"] is True
    assert checks["config_loaded"] is True
    assert "ci.yml" in route["restricted"]
    assert "BLOCKED: manual CI patch required" in checks["checks"]
    assert tools["build_context_capsule"] == "read_only_output_cache"


def test_operator_kernel_refresh_script_exists() -> None:
    script = ROOT / "ops/operator_kernel/refresh.sh"
    text = script.read_text(encoding="utf-8")
    assert "--mode clean-cache" in text
    assert "--mode map" in text
    assert "--mode capsule" in text
