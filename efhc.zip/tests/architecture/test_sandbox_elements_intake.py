from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAP = ROOT / "map_element.md"
INTAKE = ROOT / "docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md"


def test_sandbox_element_maps_exist_and_cover_sources() -> None:
    assert MAP.exists()
    assert INTAKE.exists()
    text = (
        MAP.read_text(encoding="utf-8")
        + "\n"
        + INTAKE.read_text(encoding="utf-8")
    )
    for source in (
        "Песочница.xz",
        "vuejs-template-master.zip",
        "solidjs-template-master.zip",
        "nuxt-telegram-mini-app-main.zip",
        "typescript-template-master.zip",
        "vanillajs-template-master.zip",
    ):
        assert source in text


def test_sandbox_is_reference_only_not_runtime_migration() -> None:
    text = INTAKE.read_text(encoding="utf-8")
    assert (
        "Do not migrate EFHC to Vue, Solid, Nuxt or Vanilla runtime "
        "stacks"
        in text
    )
    assert "Next.js 16.2.6" in text
    assert "React 19.2.6" in text
    assert "Tailwind CSS 4.3.0" in text
    assert "Only patterns are accepted" in text


def test_sandbox_map_links_next_public_ui_work() -> None:
    text = MAP.read_text(encoding="utf-8")
    assert "Immediate next use" in text
    assert "Public UI" in text
    assert "Telegram-native shell patterns" in text
    assert "TonConnect" in text
