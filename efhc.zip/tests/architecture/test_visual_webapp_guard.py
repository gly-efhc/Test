from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_webapp_target_is_fixed_without_custom_install_button() -> None:
    text = read("docs/audits/WEBAPP_PWA_TARGET.md")

    assert "Telegram Mini App surface" in text
    assert "Normal browser / PWA surface" in text
    assert "system install prompt" in text
    assert "custom fake install button" in text


def test_ranks_uses_compact_cards_without_energy_ladder() -> None:
    src = read("frontend/src/pages/ranks.tsx")
    css = read("frontend/src/styles/globals.css")

    assert "efhc-rank-card" in src
    assert "efhc-rank-medal" in src
    assert "medalForRank" in src
    assert 'data-ranks-card-layout="vertical-1299"' in src
    assert "USER_LEVEL_SKINS" not in src
    assert "ranks.levels" not in src
    assert ".efhc-rank-card" in css
    assert ".efhc-rank-card--mine" in css


def test_panels_exchange_tasks_audit_notes() -> None:
    text = read("docs/audits/PANELS_EXCHANGE_TASKS_AUDIT.md")

    assert "Approval is chat-first" in text
    assert "Panels" in text
    assert "Exchange" in text
    assert "Tasks" in text
    assert "without deleting functions" in text


def test_exchange_public_hardcoded_helpers_are_localized() -> None:
    src = read("frontend/src/pages/exchange.tsx")

    forbidden = [
        "Where to check the result",
        "After exchange and withdraw",
        "Open history",
        "Open Wallet",
        "Full Withdraw screen",
    ]
    for token in forbidden:
        assert token not in src

    required = [
        't("exchange.history_hint")',
        't("exchange.open_history")',
    ]
    for token in required:
        assert token in src


def test_locale_keys_cover_ranks_and_exchange_repairs() -> None:
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in [
            "ranks.me_badge",
            "exchange.history_hint",
            "exchange.open_history",
        ]:
            assert key in data, f"{key} missing in {path.name}"
        detail = data["exchange.confirmation_ready_detail"]
        assert "truth-layer" not in detail


def test_generated_visible_audit_matches_cycle() -> None:
    data = json.loads(
        read("reports/generated/visible_functions_audit.json")
    )

    assert data["cycle"] == "1213-1214"
    assert data["webapp_target"]["telegram_surface"] is True
    assert data["webapp_target"]["browser_pwa_surface"] is True
    assert data["webapp_target"]["custom_install_button"] is False
    assert data["ranks"]["dragon_style_compact_cards"] is True
    assert data["ranks"]["energy_level_ladder_public"] is False
