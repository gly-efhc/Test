from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_old_browser_shop_norm_parts_removed_from_active_surface() -> (
    None
):
    for rel in [
        "docs/NORM/BROWSER_SHOP_CHECKOUT_STATUS_NORM.md",
        "docs/NORM/BROWSER_SHOP_INTENT_MEMO_CONTRACT_NORM.md",
        "docs/NORM/BROWSER_SHOP_WATCHER_CONFIRM_ANTIFRAUD_NORM.md",
    ]:
        assert not (ROOT / rel).exists()
    assert (
        ROOT / "docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md"
    ).exists()


def test_temp_plans_backlog_removed_from_norm() -> None:
    for rel in [
        "docs/NORM/ECONOMIC_AUDIT_20_CYCLES_PLAN_2026_04_05.md",
        "docs/NORM/CRITICAL_HARDENING_20_CYCLES_PLAN_2026_04_04.md",
        "docs/NORM/DOCS_REFRESH_BACKLOG_2026_04_05.md",
        "docs/NORM/MVP_DEMOLITION_PLAN_NORM.md",
    ]:
        assert not (ROOT / rel).exists()


def test_strong_docs_promoted_to_ssot() -> None:
    for rel in [
        "docs/SSOT/BANK_CANON.md",
        "docs/SSOT/DTO_INPUT_CANON.md",
        "docs/SSOT/ENERGY_RULES.md",
        "docs/SSOT/ROUTE_RESPONSE_ERROR_CANON.md",
        "docs/SSOT/TERMS_GLOSSARY.md",
        "docs/SSOT/TON_MEMO_SPEC.md",
        "docs/SSOT/USER_FACING_WORDING_CANON.md",
        "docs/SSOT/SYSTEM_LOCK_TG_ID.md",
        "docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md",
        "docs/SSOT/DOCUMENT_LAYER_CANON.md",
    ]:
        assert (ROOT / rel).exists()


def test_document_layer_canon_has_protection_rules() -> None:
    text = (ROOT / "docs/SSOT/DOCUMENT_LAYER_CANON.md").read_text(
        encoding="utf-8"
    )
    assert "В NORM запрещено" in text
    assert "В CANON / SSOT запрещено" in text
