from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_system_webhook_uses_canonical_process_update():
    src = read("backend/app/routes/system_routes.py")
    webhook = src.split("async def telegram_webhook", 1)[1]
    assert "process_update" in webhook
    assert "await process_update(db=db, payload=payload)" in webhook
    assert "feed_raw_update" not in webhook
    assert "dp.bot" not in webhook


def test_process_update_raises_after_logging_processing_errors():
    src = read("backend/app/bot/bot.py")
    fn = src.split("async def process_update", 1)[1]
    fn = fn.split("async def require_subscription_text", 1)[0]
    assert "await dp.feed_update(bot, update, db=db)" in fn
    assert "logger.exception" in fn
    assert "raise" in fn


def test_failed_webhook_processing_removes_dedupe_marker():
    src = read("backend/app/routes/system_routes.py")
    webhook = src.split("async def telegram_webhook", 1)[1]
    assert "DELETE FROM" in webhook
    assert "efhc_core.processed_external_events" in webhook
    assert "raise HTTPException(" in webhook
