from __future__ import annotations

import ast
from pathlib import Path

ROUTES_DIR = Path("backend/app/routes")
ADMIN_ROUTE_FILES = sorted(ROUTES_DIR.glob("admin*_routes.py"))


def _router_kwargs(path: Path) -> dict[str, str | list[str]]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name) or target.id != "router":
            continue
        call = node.value
        if not isinstance(call, ast.Call):
            continue
        if not isinstance(call.func, ast.Name):
            continue
        if call.func.id != "APIRouter":
            continue
        result: dict[str, str | list[str]] = {}
        for kw in call.keywords:
            if kw.arg == "prefix" and isinstance(
                kw.value, ast.Constant
            ):
                result["prefix"] = str(kw.value.value)
            if kw.arg == "tags" and isinstance(kw.value, ast.List):
                tags: list[str] = []
                for elt in kw.value.elts:
                    if isinstance(elt, ast.Constant):
                        tags.append(str(elt.value))
                result["tags"] = tags
        return result
    raise AssertionError(f"router APIRouter not found in {path}")


def test_admin_route_modules_use_canonical_prefixes_and_tags() -> None:
    expected = {
        "admin_ads_routes.py": ("/admin/ads", ["admin:ads"]),
        "admin_hub_routes.py": ("/admin/hub", ["admin:hub"]),
        "admin_logs_routes.py": ("/admin/logs", ["admin:logs"]),
        "admin_observability_routes.py": (
            "/admin/observability",
            ["admin:observability"],
        ),
        "admin_reports_routes.py": (
            "/admin/reports",
            ["admin-reports"],
        ),
        "admin_panels_routes.py": ("/admin/panels", ["admin:panels"]),
        "admin_referral_routes.py": (
            "/admin/referrals",
            ["admin:referrals"],
        ),
        "admin_routes.py": ("/admin", ["admin"]),
        "admin_sale_packages_routes.py": (
            "/admin/sale-packages",
            ["admin:sale-packages"],
        ),
        "admin_shop_routes.py": ("/admin/shop", ["admin:shop"]),
        "admin_tasks_routes.py": ("/admin/tasks", ["admin:tasks"]),
        "admin_templates_routes.py": (
            "/admin/templates",
            ["admin:templates"],
        ),
        "admin_users_routes.py": ("/admin/users", ["admin:users"]),
        "admin_withdrawals_routes.py": (
            "/admin/withdrawals",
            ["admin:withdrawals"],
        ),
    }
    got = {
        path.name: _router_kwargs(path) for path in ADMIN_ROUTE_FILES
    }
    assert set(got) == set(expected)
    for name, (prefix, tags) in expected.items():
        assert got[name]["prefix"] == prefix
        assert got[name]["tags"] == tags
