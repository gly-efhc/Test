from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
LANGS = [
    "en",
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]
FILLED_CRITICAL_KEYS = [
    "energy.hub_action",
    "energy.hub_action_note",
    "energy.profile_wallet_action",
    "energy.profile_wallet_note",
    "profile.independent_shell_badge",
]
PLACEHOLDER_KEYS = {
    "wallet.linked_wallets_count": {"{count}"},
    "withdraw.request_number": {"{id}"},
}


def _locale(lang: str) -> dict[str, str]:
    return json.loads(
        (LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8")
    )


def _placeholders(value: str) -> set[str]:
    return set(re.findall(r"\{[a-zA-Z0-9_]+\}", value))


def test_player_fallback_chain_is_english_not_russian() -> None:
    text = (ROOT / "frontend/src/lib/i18n.ts").read_text(
        encoding="utf-8"
    )
    fn = text.split("export function tFromDicts", 1)[1].split("\n}", 1)[
        0
    ]
    assert "embeddedEn" in fn
    assert "embeddedRu" not in fn
    assert "ru[k]" not in fn
    get_embedded = text.split("export function getEmbeddedDict", 1)[
        1
    ].split("\n}", 1)[0]
    assert "EMBEDDED_DICTS.en" in get_embedded
    assert "EMBEDDED_DICTS.ru || {}" not in get_embedded


def test_critical_empty_locale_keys_are_filled_in_all_languages() -> (
    None
):
    for lang in LANGS:
        data = _locale(lang)
        for key in FILLED_CRITICAL_KEYS:
            assert key in data, f"{lang} missing {key}"
            assert str(data[key]).strip(), f"{lang} has empty {key}"


def test_locale_placeholders_survive_hindi_repair() -> None:
    hi = _locale("hi")
    for key, expected in PLACEHOLDER_KEYS.items():
        assert key in hi
        assert expected <= _placeholders(
            str(hi[key])
        ), f"hi {key} lost placeholders"


def test_all_locale_files_keep_key_parity_after_i18n_repair() -> None:
    en_keys = set(_locale("en"))
    assert en_keys
    for lang in LANGS:
        keys = set(_locale(lang))
        assert keys == en_keys, f"{lang} locale key drift"


def test_public_shell_has_no_russian_hardcoded_fallbacks_for_player_route_guard() -> (
    None
):
    app = (ROOT / "frontend/src/pages/_app.tsx").read_text(
        encoding="utf-8"
    )
    assert "Проверяем доступ к Admin" not in app
    assert "Admin доступ закрыт" not in app
    assert "Эта операторская панель" not in app
    shop_layout = (
        ROOT / "frontend/src/components/ShopLayout.tsx"
    ).read_text(encoding="utf-8")
    assert '|| "Профиль"' not in shop_layout


def test_i18n_audit_source_and_repair_report_exist() -> None:
    assert (
        ROOT
        / "docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md"
    ).exists()
    assert (
        ROOT / "reports/generated/i18n_audit_summary_v169_45.json"
    ).exists()
    assert (
        ROOT / "docs/frontend/I18N_CRITICAL_AUDIT_REPAIR_PASS.md"
    ).exists()
    assert (
        ROOT / "reports/generated/i18n_critical_repair_v169_47.json"
    ).exists()


def test_bot_texts_parity_script_uses_valid_importlib_loader() -> None:
    text = (ROOT / "ops/i18n/audit_bot_texts_parity.py").read_text(
        encoding="utf-8"
    )
    assert "SourceFileLoader" in text
    assert "backend" in text and "bot" in text and "texts.py" in text
    assert "spec_from_file_location" not in text
    assert "importlib.import_module" not in text


def test_public_layout_description_fallback_does_not_force_russian() -> (
    None
):
    for rel in [
        "frontend/src/components/Layout.tsx",
        "frontend/src/components/ShopLayout.tsx",
    ]:
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert (
            "props.descDict[k] || props.uiDict[k] || props.ruDict[k] "
            "|| k"
            not in text
        )
        assert (
            "props.descDict[k] || tFromDicts(k, props.uiDict, "
            "props.ruDict)"
            in text
        )
