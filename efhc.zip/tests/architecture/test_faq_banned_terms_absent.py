from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FAQ_PATHS = [
    ROOT / "docs/SSOT/faq_ssot",
    ROOT / "frontend/src/data/faq/catalogs.ts",
]

_PARTS = [
    "lott" + "er",
    "лотере",
    "розыгрыш",
    "розыгры",
    "розіграш",
    "розігра",
    "raff" + "le",
    "give" + "away",
    "sweep" + "stake",
    "jack" + "pot",
    "tourna" + "ment",
]
BANNED = re.compile("|".join(_PARTS), re.IGNORECASE)


def test_faq_layers_have_no_banned_gambling_terms() -> None:
    hits: list[str] = []
    for base in FAQ_PATHS:
        if base.is_dir():
            files = sorted(
                p
                for p in base.rglob("*")
                if p.is_file() and p.suffix in {".md", ".json"}
            )
        else:
            files = [base]
        for path in files:
            text = path.read_text(encoding="utf-8")
            match = BANNED.search(text)
            if match is not None:
                hits.append(
                    f"{path.relative_to(ROOT)}::{match.group(0)}"
                )
    assert not hits, hits
