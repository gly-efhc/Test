from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1334_documents_exist() -> None:
    required = [
        "docs/audits/CI_LOGS_71033084031_REPAIR_V169_13.md",
        "docs/backend/CI_TEST_DEPENDENCY_SANITY_CANON.md",
        "reports/"
        "change_cycle_2026-05-27_v169_13_cycle_1334_"
        "ci_logs_71033084031_repair.md",
        "reports/generated/ci_logs_71033084031_repair_v169_13.json",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_ci_proves_test_requirements_before_pytest() -> None:
    ci = read("ci.yml")
    install = "pip install -r extracted/requirements-test.txt"
    assert install in ci
    runner = "PYTHONPATH=backend pytest -q"
    assert runner in ci
    assert ci.index(install) < ci.index(runner)
    assert "OK: test dependency bootstrap" in ci


def test_freezegun_remains_test_only_dependency() -> None:
    runtime = read("backend/requirements.txt")
    lock = read("backend/requirements.lock")
    test_req = read("requirements-test.txt")
    assert "freezegun" not in runtime
    assert "freezegun" not in lock
    assert "freezegun==1.5.1" in test_req


def test_cycle_plan_shifts_shop_to_1335() -> None:
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1334: CI logs 71033084031 repair" in plan
    assert "1335: Shop admin actions" in plan
    assert "1356: Admin recovery checkpoint report" in plan


def test_audit_records_confirmed_log_failure() -> None:
    audit = read("docs/audits/CI_LOGS_71033084031_REPAIR_V169_13.md")
    assert "ModuleNotFoundError: No module named 'freezegun'" in audit
    assert "pytest -q" in audit
    assert "runtime requirements" in audit
