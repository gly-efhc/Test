"""work pass guard: pytest freezegun collection repair."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_core_math_econ_no_freezegun_import() -> None:
    text = read("tests/core/test_core_math_econ.py")
    assert "from freezegun import" not in text
    assert "freeze_time" not in text
    assert "datetime.fromisoformat" in text


def test_runtime_requirements_stay_freezegun_free() -> None:
    runtime = read("backend/requirements.txt")
    lock = read("backend/requirements.lock")
    assert "freezegun" not in runtime
    assert "freezegun" not in lock


def test_cycle_1337_documents_exist() -> None:
    assert (
        ROOT / "docs/audits/CI_LOGS_71060357686_REPAIR_V169_16.md"
    ).exists()
    assert (
        ROOT / "docs/backend/CORE_ECON_TEST_DEPENDENCY_FREE_CANON.md"
    ).exists()
    assert (
        ROOT
        / (
            "reports/"
            "change_cycle_2026-05-29_v169_16_cycle_1337_"
            "ci_logs_71060357686_repair.md"
        )
    ).exists()


def test_ci_manual_boundary_is_documented() -> None:
    protocol = read("docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md")
    audit = read("docs/audits/CI_LOGS_71060357686_REPAIR_V169_16.md")
    assert "CI/workflow files are manual-control files" in protocol
    assert "does not edit `ci.yml`" in audit


def test_shop_cycle_shifted_to_1338() -> None:
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1337` becomes `CI logs 71060357686 repair" in plan
    assert "shifts to `1338`" in plan
    assert "1337: Shop admin actions" in plan
    assert "SHIFTED to 1338" in plan
