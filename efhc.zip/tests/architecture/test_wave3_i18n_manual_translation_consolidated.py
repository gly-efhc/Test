from __future__ import annotations

import importlib

import pytest

CASES = (
    "wave3_public_engagement_manual_translation",
    "wave3_portal_shop_manual_translation",
    "wave3_profile_trust_manual_translation",
    "wave3_panels_tasks_history_manual_translation",
    "wave3_hub_energy_wallet_ranks_referrals_manual_translation",
)


@pytest.mark.parametrize("case_name", CASES)
def test_wave3_i18n_manual_case(case_name: str) -> None:
    module = importlib.import_module(
        f"tests.architecture.wave3_cases.{case_name}"
    )
    checks = [
        getattr(module, name)
        for name in sorted(dir(module))
        if name.startswith("test_")
    ]
    assert checks, case_name
    for check in checks:
        check()
