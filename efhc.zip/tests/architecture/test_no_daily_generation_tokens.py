from pathlib import Path


def test_no_daily_generation_tokens_in_runtime() -> None:
    banned = [
        "PANEL_GENERATION_NORMAL",
        "PANEL_GENERATION_VIP",
        "daily_generation_base",
        "daily_generation_vip",
        "DAILY_BASE",
        "DAILY_VIP",
    ]
    files = [
        Path("backend/app/routes/sync_routes.py"),
        Path("frontend/src/hooks/useSnapshot.ts"),
    ]
    for path in files:
        text = path.read_text(encoding="utf-8")
        for token in banned:
            assert token not in text, f"{path}: banned token {token}"
