from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_npm_build_keeps_typecheck_blocking_before_next() -> None:
    package = json.loads(read("frontend/package.json"))
    assert package["scripts"]["prebuild"] == (
        "node scripts/prebuild.mjs"
    )
    prebuild = read("frontend/scripts/prebuild.mjs")
    assert "scripts/clean-next-build.mjs" in prebuild
    assert "scripts/verify-production-assets.mjs" in prebuild
    assert package["scripts"]["build"] == (
        "node scripts/build-next-production.mjs"
    )
    script = read("frontend/scripts/build-next-production.mjs")
    config = read("frontend/next.config.js")
    tsc = '"node_modules/typescript/bin/tsc"'
    next_build = '"node_modules/next/dist/bin/next"'
    assert tsc in script
    assert '"--noEmit"' in script
    assert next_build in script
    assert '"build", "--webpack"' in script
    assert script.index(tsc) < script.index(next_build)
    assert 'EFHC_NEXT_EXTERNAL_TYPECHECK: "1"' in script
    assert "ignoreBuildErrors" in config
    assert 'EFHC_NEXT_EXTERNAL_TYPECHECK === "1"' in config
