from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "reports/generated/fresh_ci_green_confirmation_v171_05.json"
NORM = ROOT / "docs/NORM/FRESH_CI_GREEN_CONFIRMATION.md"
CYCLE = ROOT / "docs/cycles/WORK_CYCLES_1530_FRESH_CI_GREEN_CONFIRMATION.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
RELEASE = ROOT / "docs/NORM/RELEASE_PROOF_STATUS.md"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _json(path: Path) -> dict:
    return json.loads(_read(path))


def test_cycle_1530_green_ci_evidence_report_exists() -> None:
    assert REPORT.exists()
    data = _json(REPORT)
    assert data["cycle"] == 1530
    assert data["version"] == "v171.05"
    assert data["log_verdict"] == "GREEN"
    assert data["ci_green_confirmed_for"] == "v171.04"
    assert data["gate_summary"] == "OK: all gate steps passed."


def test_cycle_1530_records_green_gate_summaries() -> None:
    data = _json(REPORT)
    assert data["pytest_summary"].startswith("1962 passed")
    assert data["ruff_summary"] == "All checks passed!"
    assert "283 source files" in data["mypy_summary"]
    assert "Compiled successfully" in data["frontend_build_summary"]
    for gate in [
        "exit_pytest",
        "exit_ruff_full",
        "exit_mypy_full",
        "exit_npm_build",
    ]:
        assert data["exit_codes"][gate] == 0


def test_cycle_1530_does_not_claim_output_ci_or_release_ready() -> None:
    data = _json(REPORT)
    assert data["ci_green_claimed_for_output_archive"] is False
    assert data["github_ci_green_claimed_for_output"] is False
    assert data["live_telegram_proof_claimed"] is False
    assert data["real_tonconnect_proof_claimed"] is False
    assert data["release_ready_claimed"] is False


def test_cycle_1530_docs_and_navigation_updated() -> None:
    assert NORM.exists()
    assert CYCLE.exists()
    joined = "\n".join([
        _read(KERNEL),
        _read(MAP),
        _read(NORM),
        _read(CYCLE),
        _read(RELEASE),
    ])
    assert "v171_05" in joined
    assert "logs_74465909794.zip" in joined
    assert "OK: all gate steps passed" in joined
    assert "v171.04" in joined


def test_cycle_1530_preserves_runtime_boundaries() -> None:
    data = _json(REPORT)
    for key in [
        "runtime_changed",
        "money_flow_changed",
        "wallet_flow_changed",
        "withdraw_logic_changed",
        "tonconnect_changed",
        "frontend_runtime_changed",
        "economy_changed",
    ]:
        assert data[key] is False
