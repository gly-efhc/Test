"""Архитектурные границы non-financial EXPAND цикла 1621."""

from __future__ import annotations

from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from ops.identity.check_nonfinancial_domain_expand import проверить
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_cycle_1621_имеет_exact_primary_route() -> None:
    task = classify_task(
        "Цикл 1621 — non-financial domain schema expand: "
        "panels energy referrals tasks ranks"
    )
    assert task["task_type"] == "nonfinancial_domain_schema_expand"
    route = resolve_route(task["task_type"], ROOT)
    assert route["route_name"] == "nonfinancial_domain_schema_expand"
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_nonfinancial_schema_входит_в_единую_release_revision() -> None:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    assert script.get_heads() == ["0001"]
    assert script.get_revision("0001").down_revision is None

def test_nonfinancial_expand_static_guard_проходит() -> None:
    result = проверить(ROOT)
    assert result["успех"] is True, result["нарушения"]
    assert result["таблиц_expand"] == 13
    assert result["owner_columns"] == 14
    assert result["openapi_paths"] == 131
    assert result["openapi_operations"] == 136
    assert result["backfill"] is False
    assert result["read_switch"] is False
    assert result["financial_owner_switch"] is False


def test_final_models_содержат_nonfinancial_global_owner() -> None:
    for relative in (
        "backend/app/models/panels_models.py",
        "backend/app/models/referral_models.py",
        "backend/app/models/tasks_models.py",
        "backend/app/models/ranks_models.py",
    ):
        source = _read(relative)
        assert "global_id" in source
        assert "users.global_id" in source

def test_legacy_runtime_owner_fields_сохранены() -> None:
    for relative in (
        "backend/app/models/panels_models.py",
        "backend/app/models/referral_models.py",
        "backend/app/models/tasks_models.py",
        "backend/app/models/ranks_models.py",
    ):
        assert "tg_id" in _read(relative)
    users = _read("backend/app/models/user_models.py")
    assert 'user_id = synonym("global_id")' in users
