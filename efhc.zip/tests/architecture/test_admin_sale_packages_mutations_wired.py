from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_admin_sale_packages_mutations_are_wired_with_idempotency() -> (
    None
):
    text = (
        ROOT / "frontend/src/features/admin/AdminSalePackagesPage.tsx"
    ).read_text(encoding="utf-8")
    assert '"POST"' in text and '"PUT"' in text
    assert "ADMIN_SALE_PACKAGES_PATH" in text
    assert "adminPath(ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH" in text
    assert "adminPath(ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH" in text
    assert "adminApiRequest<" in text
    assert "newIdempotencyKey()" in text
    assert "AdminPromptModal" in text
    assert "setMutationBusy(true)" in text
