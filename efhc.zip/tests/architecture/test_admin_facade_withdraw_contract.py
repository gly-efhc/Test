from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FACADE = ROOT / "backend" / "app" / "services" / "admin"
FACADE = FACADE / "admin_facade.py"


def _function_node(tree: ast.Module, name: str) -> ast.AsyncFunctionDef:
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == name:
            return node
    raise AssertionError(f"missing function {name}")


def _calls_named(node: ast.AST, name: str) -> list[ast.Call]:
    calls: list[ast.Call] = []
    for item in ast.walk(node):
        if not isinstance(item, ast.Call):
            continue
        func = item.func
        if isinstance(func, ast.Attribute) and func.attr == name:
            calls.append(item)
    return calls


def _kw_names(call: ast.Call) -> set[str | None]:
    return {kw.arg for kw in call.keywords}


def test_admin_facade_approve_withdraw_uses_current_service_contract():
    tree = ast.parse(FACADE.read_text(), filename=str(FACADE))
    node = _function_node(tree, "admin_approve_withdraw")
    calls = _calls_named(node, "approve_withdrawal")
    assert len(calls) == 1
    kwargs = _kw_names(calls[0])
    assert "request_id" not in kwargs
    assert {"withdrawal_id", "req", "admin"}.issubset(kwargs)


def test_admin_facade_reject_withdraw_uses_current_service_contract():
    tree = ast.parse(FACADE.read_text(), filename=str(FACADE))
    node = _function_node(tree, "admin_reject_withdraw")
    calls = _calls_named(node, "reject_withdrawal")
    assert len(calls) == 1
    kwargs = _kw_names(calls[0])
    assert "request_id" not in kwargs
    required = {"withdrawal_id", "reason", "idempotency_key", "admin"}
    assert required.issubset(kwargs)


def test_admin_facade_reject_requires_explicit_idempotency_key():
    tree = ast.parse(FACADE.read_text(), filename=str(FACADE))
    node = _function_node(tree, "admin_reject_withdraw")
    kwonly = {arg.arg for arg in node.args.kwonlyargs}
    assert "idempotency_key" in kwonly
