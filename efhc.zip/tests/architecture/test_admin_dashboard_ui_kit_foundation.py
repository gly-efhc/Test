from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
TSX = ROOT / "frontend/src/components/admin/AdminDashboardUiKit.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
REPORT = (
    ROOT
    / "reports/generated/admin_dashboard_ui_kit_foundation_v170_37.json"
)
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_admin_dashboard_ui_kit_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_ADMIN_DASHBOARD_UI_KIT_FOUNDATION" in text
    assert "AdminDashboardShell" in text
    assert "AdminPanelChrome" in text
    assert "AdminPanelInspectorDrawer" in text
    assert "Grafana is visual-pattern reference only" in text
    assert "Песочница is reference/prototype layer only" in text


def test_admin_dashboard_runtime_components_are_exported() -> None:
    text = read(TSX)
    required = [
        "AdminDashboardShell",
        "AdminDashboardPage",
        "AdminDashboardToolbar",
        "AdminDashboardGrid",
        "AdminPanelChrome",
        "AdminPanelHeader",
        "AdminPanelBody",
        "AdminPanelFooter",
        "AdminPanelStatus",
        "AdminStatusCard",
        "AdminTrendCard",
        "AdminPanelInspectorDrawer",
    ]
    for marker in required:
        assert f"export function {marker}" in text
    assert "DashboardComponentContract" in text
    assert "DashboardPanelStatus" in text
    assert "DashboardPanelTone" in text


def test_admin_dashboard_css_uses_dashboard_tokens() -> None:
    css = read(CSS)
    assert "Admin Dashboard UI Kit Foundation" in css
    assert ".efhc-admin-dashboard-shell" in css
    assert ".efhc-admin-dashboard-toolbar" in css
    assert ".efhc-admin-panel-chrome" in css
    assert ".efhc-admin-panel-inspector" in css
    assert "var(--efhc-dash-panel)" in css
    assert "var(--efhc-dash-border)" in css


def test_grafana_element_usage_map_is_reference_only() -> None:
    text = read(GRAFANA_MAP)
    required = [
        "PanelChrome",
        "PanelHeader",
        "DashboardGrid",
        "DashboardPageProxy",
        "DashboardControls",
        "RefreshPicker",
        "TimeRangePicker",
        "Variables",
        "PanelInspector",
        "BigValue",
        "Sparkline",
    ]
    for marker in required:
        assert marker in text
    assert "Do not copy files from `grafana-main.zip`" in text
    assert "Grafana is reference only" in text


def test_admin_dashboard_report_and_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1461
    assert data["version"] == "v170.37"
    assert data["runtime_component"] == str(TSX.relative_to(ROOT))
    assert data["boundaries"]["economy_changed"] is False
    assert data["boundaries"]["backend_contracts_changed"] is False
    assert data["boundaries"]["grafana_runtime_code_copied"] is False
    assert data["boundaries"]["sandbox_runtime_code_copied"] is False


def test_navigation_points_to_admin_dashboard_foundation() -> None:
    for path in [KERNEL, MAP, ROUTES]:
        text = read(path)
        assert "ADMIN_DASHBOARD_UI_KIT_FOUNDATION" in text
        assert "GRAFANA_EFHC_ELEMENT_USAGE_MAP" in text
        assert "AdminDashboardUiKit.tsx" in text


def test_no_grafana_runtime_code_copied_into_admin_kit() -> None:
    text = read(TSX)
    forbidden = [
        "@grafana/",
        "grafana-ui",
        "SceneObject",
        "PanelData",
    ]
    for marker in forbidden:
        assert marker not in text


def test_grafana_archive_contains_reference_anchors() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "PanelChrome",
        "RefreshPicker",
        "DashboardPageProxy",
        "PanelInspector",
        "BigValue",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker
