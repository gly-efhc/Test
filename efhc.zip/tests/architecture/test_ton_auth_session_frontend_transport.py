"""Статические границы frontend session transport цикла 1618."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_frontend_session_transport_изолирован() -> None:
    transport = _read("frontend/src/lib/auth-session.ts")
    api = _read("frontend/src/lib/api.ts")
    ton_auth = _read("frontend/src/lib/ton-auth.ts")

    assert "sessionStorage" in transport
    assert "localStorage" not in transport
    assert "efhc.auth.session.v1" in transport
    assert "getAuthAuthorizationHeader" in api
    assert "headers.Authorization" in api
    assert "clearAuthSession" in api
    assert "completeTonProofLogin" in ton_auth
    assert "logoutAuthSession" in ton_auth
    assert "global_id: string" in ton_auth
    assert "global_id: number" not in ton_auth


def test_backend_session_routes_включены_в_production_registry() -> None:
    registry = _read("backend/app/routes/__init__.py")
    route = _read("backend/app/routes/auth_session_routes.py")
    assert '"auth_session_routes"' in registry
    assert '"/session"' in route
    assert '"/logout"' in route
    assert "require_auth_context" in route
    assert "require_auth_session_token" in route
