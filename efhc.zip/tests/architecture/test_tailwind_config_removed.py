from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_tailwind_config__file__is_removed() -> None:
    assert not (ROOT / "frontend/tailwind.config.js").exists()


def test_tailwind_v4_css_first_sources_remain_active() -> None:
    postcss = read("frontend/postcss.config.js")
    css = read("frontend/src/styles/globals.css")

    assert '"@tailwindcss/postcss"' in postcss
    assert '@import "tailwindcss";' in css
    assert "@theme" in css
    assert "--color-efhc-gold" in css
    assert "@tailwind base" not in css
    assert "@tailwind components" not in css
    assert "@tailwind utilities" not in css


def test_cycle_1332_documents_exist() -> None:
    required = [
        "docs/frontend/FRONTEND_TAILWIND_CONFIG_REMOVAL.md",
        (
            "docs/audits/"
            "FRONTEND_CYCLE_1332_TAILWIND_CONFIG_REMOVAL_AUDIT_V169_11.md"
        ),
        (
            "reports/change_cycle_2026-05-27_v169_11_cycle_1332_tailwind_"
            "config_removal_docs.md"
        ),
        (
            "reports/generated/"
            "frontend_tailwind_config_removal_v169_11.json"
        ),
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_docs_state_tailwind_config_as_absent() -> None:
    standard = read(
        "docs/frontend/"
        "FRONTEND_CODE_STANDARD_NEXT16_REACT19_TAILWIND4.md"
    )
    removal = read("docs/frontend/FRONTEND_TAILWIND_CONFIG_REMOVAL.md")
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )

    assert "tailwind.config.js` explicitly removed" in standard
    assert "must not exist in HEAD" in removal
    assert "1332` becomes `Tailwind config removal" in plan
    assert "1333: Shop admin actions" in plan
    assert "1334: Shop admin actions" in plan
    assert "1355: Admin recovery checkpoint report" in plan
