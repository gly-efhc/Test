from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_проверка_wallet_connect_requires_tonconnect_proof() -> None:
    route = read("backend/app/routes/wallets_routes.py")
    schema = read("backend/app/schemas/wallet_schemas.py")
    service = read("backend/app/services/wallets_service.py")

    connect_route = route.split('"/connect"', 1)[1]
    assert "tonconnect_proof_service.check_proof" in connect_route
    assert "payload.payload_token" in connect_route
    assert "payload.proof.model_dump()" in connect_route
    assert "proof_out.cryptographically_verified" in connect_route
    assert "verified_proof_payload_token" in connect_route
    assert "verified_proof_source" in connect_route

    assert "payload_token: str" in schema
    assert "proof: WalletTonProofProofIn" in schema
    assert "public_key: str | None" in schema

    signature = service.split("async def connect_wallet(", 1)[1].split(
        ") -> dict:", 1
    )[0]
    assert "verified_proof_payload_token: str" in signature
    assert "verified_proof_source: str" in signature


def test_проверка_wallet_gate_accepts_only_verified_binding() -> None:
    service = read("backend/app/services/wallets_service.py")
    deps = read("backend/app/deps.py")

    has_wallet = service.split("async def has_active_wallet(", 1)[1]
    has_wallet = has_wallet.split("def _proof_token_hash", 1)[0]
    assert "proof_verified = true" in has_wallet
    assert "is_active = true" in has_wallet
    assert "has_active_wallet" in deps


def test_проверка_tonconnect_proof_replay_is_blocked() -> None:
    service = read("backend/app/services/wallets_service.py")
    models = read("backend/app/models/wallets_models.py")
    migration = read("backend/migrations/versions/0001_initial_release_schema.py")

    assert "class WalletProofReplay" in service
    assert "_proof_token_hash" in service
    assert "_mark_verified_proof_single_use" in service
    assert "wallet_proof_token_uses" in service
    assert "ON CONFLICT (proof_payload_hash) DO NOTHING" in service
    assert "raise WalletProofReplay" in service

    assert "class WalletProofTokenUse" in models
    assert "uq_wallet_proof_payload_hash" in models
    assert "proof_verified" in models
    assert "proof_payload_hash" in models

    assert "wallet_proof_token_uses" in migration
    assert "proof_verified" in migration


def test_проверка_cron_secret_has_no_working_default_and_fails_fast() -> None:
    config = read("backend/app/core/config_core.py")
    system = read("backend/app/routes/system_routes.py")
    prod_env = read("env.prod.example")

    old_secret = "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs"
    assert old_secret not in config
    assert 'CRON_SECRET: str = Field(\n        default=""' in config
    assert "_LEGACY_CRON_DIGEST_SHA256" in config
    assert "CRON_SECRET must be high-entropy" in config
    assert 'env in {"prod", "stage"}' in config
    assert "len(cron_secret) < 32" in config

    assert 'env in {"prod", "stage"} and not cron_secret' in system
    assert "hmac.compare_digest(token, cron_secret)" in system

    cron_line = next(
        line for line in prod_env.splitlines()
        if line.startswith("CRON_SECRET=")
    )
    assert cron_line == "CRON_SECRET=<your_cron_secret_min_32_chars>"
    assert old_secret not in cron_line


