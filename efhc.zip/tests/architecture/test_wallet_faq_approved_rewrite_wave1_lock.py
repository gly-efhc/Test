from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.json"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def test_wallet_replacements_present() -> None:
    data = json.loads(RU.read_text(encoding="utf-8"))
    sec = data["sections"][4]
    qa = {(item["q"], item["a"]) for item in sec["items"]}
    assert any(
        q
        == (
            "Почему один и тот же кошелёк нельзя привязать "
            "к двум аккаунтам?"
        )
        for q, _ in qa
    )
    assert any(
        q
        == (
            "Что делать, если я хочу использовать свой "
            "кошелёк в другом аккаунте?"
        )
        for q, _ in qa
    )
    assert any(
        q
        == (
            "Где проверить, какой кошелёк сейчас привязан "
            "к моему аккаунту?"
        )
        for q, _ in qa
    )


def test_wallet_old_questions_removed() -> None:
    text = RU.read_text(encoding="utf-8")
    assert "Для чего еще нужен кошелек, кроме вывода?" not in text
    assert "Что будет, если я сменю основной кошелёк?" not in text
    assert (
        "Можно ли играть и развиваться, если кошелёк ещё не подключён?"
        not in text
    )


def test_cycle_108_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert (
        "| 108 | done | RU Wallet FAQ approved rewrite wave 1." in text
    )
