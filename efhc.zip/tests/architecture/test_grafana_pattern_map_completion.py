from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md"
NORM = ROOT / "docs/NORM/GRAFANA_PATTERN_MAP_COMPLETION.md"
REPORT = ROOT / "reports/generated/grafana_pattern_map_completion_v170_80.json"
AUDIT = ROOT / "docs/audits/AUDIT_TZ_REPAIR_1501_1504.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_dash03_patterns_are_documented() -> None:
    text = read(DOC)
    for marker in [
        "## Grid layout",
        "## Drill-down",
        "## Empty/error states",
    ]:
        assert marker in text
    assert "react-grid-layout" in text
    assert "DashboardPanelAction" in text
    assert "AdminPanelEmpty" in text
    assert "AdminPanelError" in text


def test_dash03_keeps_reference_only_boundary() -> None:
    text = read(NORM)
    assert "Runtime code was not changed" in text
    assert "Grafana runtime code was not copied" in text
    assert "Sandbox runtime code was not copied" in text
    assert "No dependency or lock file was changed" in text
    assert "No backend or money-flow change" in text


def test_dash03_report_closes_audit_finding() -> None:
    data = json.loads(read(REPORT))
    assert data["cycle"] == 1504
    assert data["version"] == "v170.80"
    assert data["closed_findings"] == ["DASH-03"]
    assert data["runtime_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False
    assert data["patterns_completed"] == [
        "Grid layout",
        "Drill-down",
        "Empty/error states",
    ]


def test_audit_tz_marks_dash03_closed() -> None:
    text = read(AUDIT)
    assert "**DASH-03**" in text
    assert "✅ CLOSED (c.1504)" in text
    assert "Итого после цикла 1504: все 4 находки закрыты" in text


def test_navigation_points_to_dash03_completion() -> None:
    for doc in [KERNEL, MAP, ROUTES]:
        text = read(doc)
        assert "GRAFANA_PATTERN_MAP_COMPLETION.md" in text
        assert "test_grafana_pattern_map_completion.py" in text
    assert "GitHub CI Rerun Proof" in read(KERNEL)
    assert "1505 — GitHub CI Rerun Proof" in read(MAP)
