from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "reports/generated/fresh_ci_rerun_log_repair_v170_98.json"
PANELS_PAGE = ROOT / "frontend/src/pages/panels.tsx"
PANELS_SERVICE = ROOT / "frontend/src/services/panels.service.ts"
ROUTE_CASE = ROOT / (
    "tests/architecture/route_evidence_cases/"
    "case_public_energy_panels_exchange_guard_matrix.py"
)
PUBLIC_PROOF = ROOT / "ops/frontend/public_visual_runtime_proof.py"
NORM = ROOT / "docs/NORM/FRESH_CI_RERUN_LOG_REPAIR.md"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_fresh_ci_rerun_log_report_is_red_repaired_only() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["schema"] == "EFHC_FRESH_CI_RERUN_LOG_REPAIR_V1"
    assert data["cycle"] == 1522
    assert data["archive_version"] == "v170.98"
    assert data["input_log"] == "logs_74335271498.zip"
    assert data["input_log_verdict"] == "RED"
    assert data["input_log_summary"]["pytest"]["failed"] == 7
    assert data["status"] == "RED_LOG_REPAIRED_LOCALLY"
    assert data["github_ci_green_claimed"] is False
    assert data["release_ready_claimed"] is False


def test_public_visual_proof_line72_repair_is_wrapped() -> None:
    text = _read(PUBLIC_PROOF)
    assert "payload = json.dumps(" in text
    assert (
        'parser.add_argument(\n        "--screenshots"' in text
    )
    assert 'report = run(\n        args.base_url' in text
    for i, line in enumerate(text.splitlines(), start=1):
        assert len(line) <= 72, f"{PUBLIC_PROOF}:{i}:{len(line)}"


def test_panels_page_keeps_generated_seam_and_static_evidence() -> None:
    text = _read(PANELS_PAGE)
    service_ts = _read(PANELS_SERVICE)
    assert "PANELS_ACTIVATE_PATH" in service_ts
    assert "PANELS_ACTIVE_PATH" in service_ts
    seams = _read(
        ROOT / "frontend/src/lib/api/generated/economicUserSeams.ts"
    )
    assert '"/panels/activate"' in seams
    assert '"/panels/active"' in seams
    assert '"/panels/archive"' in seams
    assert 'apiRequest("/panels/activate"' not in text
    assert "data-panels-route-activate" in text


def test_route_evidence_guard_is_seam_aware_not_stale_raw() -> None:
    text = _read(ROUTE_CASE)
    raw_activate_call = 'apiRequest("' + '/panels/activate'
    assert "PANELS_ACTIVATE_PATH" in text
    assert raw_activate_call not in text
    assert 'apiRequest("/panels/activate", "POST"' not in text


def test_norm_keeps_no_false_release_claim_boundary() -> None:
    text = _read(NORM)
    assert "A fresh GitHub CI rerun" in text
    assert "RELEASE_READY" in text
    assert "does not change EFHC economics" in text
