from __future__ import annotations

from decimal import Decimal

from app.services.watcher_transport import classify_watcher_transport


def test_usdt_single_unit_maps_to_d6_exact() -> None:
    got = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=1,
        jetton_master="EQ_USDT_MASTER",
        efhc_master="EQ_EFHC_MASTER",
        usdt_master="EQ_USDT_MASTER",
        efhc_decimals=8,
        usdt_decimals=6,
    )
    assert got.confirm_asset == "USDT"
    assert str(got.amount_asset_d8) == "0.00000100"


def test_usdt_d6_large_value_has_no_extra_fraction_bleed() -> None:
    got = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=123456789,
        jetton_master="EQ_USDT_MASTER",
        efhc_master="EQ_EFHC_MASTER",
        usdt_master="EQ_USDT_MASTER",
        efhc_decimals=8,
        usdt_decimals=6,
    )
    assert got.confirm_asset == "USDT"
    assert str(got.amount_asset_d8) == "123.45678900"


def test_efhc_jetton_single_unit_maps_to_d8_exact() -> None:
    got = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=1,
        jetton_master="EQ_EFHC_MASTER",
        efhc_master="EQ_EFHC_MASTER",
        usdt_master="EQ_USDT_MASTER",
        efhc_decimals=8,
        usdt_decimals=6,
    )
    assert got.confirm_asset == "EFHCJ"
    assert Decimal(str(got.amount_asset_d8)) == Decimal("0.00000001")
