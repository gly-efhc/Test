from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FAQ_DIR = ROOT / "docs/SSOT/faq_ssot"
EXPECTED = {
    "da": "Navigation og regler",
    "de": "Navigation und Regeln",
    "en": "Navigation and Rules",
    "es": "Navegación y reglas",
    "fr": "Navigation et règles",
    "hi": "नेविगेशन और नियम",
    "id": "Navigasi dan aturan",
    "it": "Navigazione e regole",
    "pl": "Nawigacja i zasady",
    "sw": "Urambazaji na sheria",
    "tr": "Navigasyon ve kurallar",
    "uk": "Навігація і правила",
}


def _load(lang: str) -> dict:
    path = FAQ_DIR / lang / f"faq_{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def test_section14_titles_synced_after_ru_wave1() -> None:
    mismatches: list[str] = []
    for lang, title in EXPECTED.items():
        data = _load(lang)
        sec = next(s for s in data["sections"] if s["id"] == 14)
        if sec["title"] != title:
            mismatches.append(f"{lang}:{sec['title']}")
        if len(sec["items"]) != 17:
            mismatches.append(f"{lang}:count={len(sec['items'])}")
    assert not mismatches, mismatches
