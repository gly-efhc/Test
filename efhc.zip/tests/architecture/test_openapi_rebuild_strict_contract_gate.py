from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OPENAPI = ROOT / "backend/openapi/openapi.json"
MANIFEST = ROOT / "backend/openapi/openapi_manifest.json"
SSOT = ROOT / "docs/SSOT/ssot_pack/SSOT_ROUTES.csv"
REPORT = ROOT / "reports/generated/openapi_strict_contract_gate_v170_18.json"
REBUILD_SCRIPT = ROOT / "ops/routes/rebuild_openapi_contract_snapshot.py"
GATE_SCRIPT = ROOT / "ops/routes/check_openapi_strict_contract_gate.py"


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


def _openapi() -> dict:
    return json.loads(OPENAPI.read_text(encoding="utf-8"))


def test_openapi_snapshot_was_rebuilt_for_cycle_1442() -> None:
    spec = _openapi()
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))

    assert spec["info"]["version"] == "v170.18-openapi-contract-snapshot"
    assert spec["info"]["x-efhc-step"] == "1442"
    assert spec["info"]["x-efhc-openapi-mode"] == "backend-route-source-derived-snapshot"
    assert manifest["mode"] == "backend-route-source-derived-snapshot"
    assert manifest["path_count"] == len(spec["paths"])
    assert manifest["operation_count"] == sum(len(v) for v in spec["paths"].values())
    assert manifest["runtime_live_export"] == "not_claimed_in_this_environment"


def test_rebuilder_route_count_matches_checked_in_openapi() -> None:
    rebuild = _load_module(REBUILD_SCRIPT)
    rows = rebuild.collect_routes()
    spec = _openapi()
    expected_ops = {(row["method"].lower(), row["path"]) for row in rows}
    actual_ops = {
        (method.lower(), path)
        for path, methods in spec["paths"].items()
        for method in methods
        if method.lower() in {"get", "post", "put", "patch", "delete"}
    }

    assert len(rows) == 136
    assert len(rows) == len(expected_ops)
    assert expected_ops == actual_ops
    assert "/cron/tick" not in spec["paths"]
    assert "/tg/webhook" not in spec["paths"]


def test_all_backend_routes_have_openapi_entry() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    assert report["missing_openapi"] == []
    assert report["ssot_operation_count"] == report["openapi_operation_count"]


def test_openapi_has_no_dead_routes() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    assert report["dead_openapi"] == []


def test_all_frontend_api_calls_have_backend_route() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    assert report["frontend_api_call_count"] >= 80
    assert report["missing_frontend_backend"] == []


def test_route_schema_contract_frontend_backend_match() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    assert report["generated_seam_constant_count"] >= 20
    assert report["missing_frontend_openapi"] == []
    assert report["missing_seam_openapi"] == []


def test_admin_routes_are_marked_admin_or_guarded() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    assert report["admin_unmarked"] == []


def test_money_routes_do_not_expose_internal_fields() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    assert report["money_internal_leaks"] == []
    text = OPENAPI.read_text(encoding="utf-8")
    assert "internal_tx" not in text
    assert "efhc_mint_burn" not in text
    assert "efhc_admin.bank_balances" not in text


def test_openapi_strict_gate_report_is_green() -> None:
    gate = _load_module(GATE_SCRIPT)
    report = gate.build_report()
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    saved = json.loads(REPORT.read_text(encoding="utf-8"))
    assert saved["status"] == "ok"
    assert saved["missing_openapi"] == []
    assert saved["dead_openapi"] == []
