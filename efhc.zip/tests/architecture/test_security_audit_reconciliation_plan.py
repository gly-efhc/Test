from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_security_audit_is_archived_and_reconciled() -> None:
    audit = ROOT / "docs/audits/P0_SECURITY_AUDIT_V170_01.md"
    cycle = _read(
        "docs/cycles/WORK_CYCLES_1428_SECURITY_AUDIT_"
        "RECONCILIATION_PLAN.md"
    )
    canon = _read("docs/security/P0_SECURITY_REPAIR_CANON.md")

    assert audit.exists()
    assert "P0_RELEASE_BLOCKED" in audit.read_text(encoding="utf-8")
    assert "v170.02 is the factual HEAD" in cycle
    assert "target-label drift" in cycle
    assert "latest actual HEAD" in canon


def test_security_audit_questions_have_locked_answers() -> None:
    canon = _read("docs/security/P0_SECURITY_REPAIR_CANON.md")
    qna = _read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")

    assert "Production wallet binding must be TonConnect proof based" in canon
    assert "Both application entrypoints must converge" in canon
    assert "The security repair line continues from the latest" in canon

    assert "canonical wallet binding" in qna
    assert "TonConnect proof" in qna
    assert "both entrypoints" in qna
    assert "v170.02" in qna


def test_security_repair_cycles_are_planned_not_claimed_done() -> None:
    cycle = _read(
        "docs/cycles/WORK_CYCLES_1428_SECURITY_AUDIT_"
        "RECONCILIATION_PLAN.md"
    )
    manifest = _read("docs/testing/TEST_GUARD_MANIFEST.md")

    for token in ("Cycle 1429", "Cycle 1430", "Cycle 1431"):
        assert token in cycle

    assert "P0 fixed" in cycle
    assert "does not claim" in cycle
    assert "security lane" in manifest
    assert "must not be deleted" in manifest


def test_security_p0_blockers_remain_visible() -> None:
    canon = _read("docs/security/P0_SECURITY_REPAIR_CANON.md")

    assert "P0_RELEASE_BLOCKED" in canon
    assert "/wallets/connect" in canon
    assert "verified proof" in canon
    assert "/cron/tick" in canon
    assert "repository-known default secret" in canon
