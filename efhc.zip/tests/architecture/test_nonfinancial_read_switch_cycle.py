from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_release_0001_содержит_final_nonfinancial_read_control() -> None:
    source = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source
    assert "nonfinancial_read_global_id_enabled" in source
    assert "nonfinancial_read_rollback_ready" in source
    assert "legacy_authoritative" in source
    assert "identity_ownership_shadow_telemetry" in source

def test_runtime_read_owner_использует_global_id_с_mapping_boundary() -> None:
    dependency = _read(
        "backend/app/identity/nonfinancial_read_dependency.py"
    )
    owner = _read("backend/app/identity/nonfinancial_read_switch.py")
    assert "get_optional_auth_context" not in dependency
    assert "context.global_id.value" in dependency
    assert "require_auth_context" in dependency
    assert "get_current_tg_id" not in dependency
    assert "nonfinancial_read_global_id_enabled" in owner
    assert "nonfinancial_read_rollback_ready" in owner
    assert "legacy_authoritative" in owner
    assert "require_legacy_tg_id" not in owner


def test_nonfinancial_routes_используют_global_read_boundary() -> None:
    paths = (
        "backend/app/routes/panels_routes.py",
        "backend/app/routes/tasks_routes.py",
        "backend/app/routes/referrals_routes.py",
        "backend/app/routes/ranks_routes.py",
        "backend/app/routes/user_routes.py",
    )
    joined = "\n".join(_read(path) for path in paths)
    assert joined.count("get_nonfinancial_read_owner") >= 5
    assert "global_id=owner.global_id" in joined
    assert "global_read=owner.use_global_id" not in joined


def test_static_guard_1625_проходит() -> None:
    path = ROOT / "ops/identity/check_nonfinancial_read_switch.py"
    spec = importlib.util.spec_from_file_location("cycle1625_guard", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    report = module.collect()
    assert report["статус"] == "PASS", report
