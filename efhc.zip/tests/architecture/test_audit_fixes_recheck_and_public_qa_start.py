from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_audit_fixes_recheck_documents_exist() -> None:
    required = [
        "docs/audits/AUDIT_FIXES_RECHECK_AUDIT_V169_38.md",
        "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
        (
            "reports/change_cycle_2026-06-01_v169_38_cycles_1358_1361_"
            "recheck_public_ui_qa_start.md"
        ),
        (
            "reports/generated/"
            "audit_fixes_recheck_public_ui_qa_v169_38.json"
        ),
    ]
    for path in required:
        assert (ROOT / path).exists(), path


def test_sale_packages_recheck_closed_stale_read_only_badge() -> None:
    src = read("frontend/src/features/admin/AdminSalePackagesPage.tsx")
    assert "mutation-wired" in src
    assert '<TelegramStatusBadge label="read-only"' not in src
    assert "/admin/sale-packages/" in src
    assert "newIdempotencyKey()" in src
    assert "AdminPromptModal" in src


def test_efhc_deposit_force_fulfill_has_frontend_idempotency() -> None:
    src = read("frontend/src/pages/admin/efhc-deposits.tsx")
    marker = "ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH"
    assert marker in src
    start = src.index("async function forceFulfill")
    block = src[start : start + 650]
    assert "POST" in block
    assert "idempotencyKey" in block
    assert "newIdempotencyKey()" in block


def test_public_ui_screenshot_qa_preparation_covers_all_public_surfaces() -> (
    None
):
    doc = read("docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md")
    for route in [
        "`/`",
        "`/panels`",
        "`/exchange`",
        "`/tasks`",
        "`/referrals`",
        "`/referrals/active`",
        "`/referrals/inactive`",
        "`/ranks`",
        "`/web-profile`",
        "`/faq`",
        "`/hub`",
        "`/browser-shop`",
        "`/withdraw`",
        "`/ads`",
    ]:
        assert route in doc
    assert "map_element.md" in doc
    assert "does not claim that screenshots were captured" in doc


def test_cycle_and_ai_docs_point_to_public_qa_completion() -> None:
    cycles = read("docs/cycles/WORK_CYCLES.md")
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md"
    )
    ai = read("docs/AI/AI_DOCS_INDEX.md")
    routes = read("docs/AI/TOPIC_READING_ROUTES.md")
    assert "v169_39" in cycles
    assert "1361: Public UI screenshot QA preparation. DONE" in cycles
    assert "1362: Public UI regression proof pass" in plan
    assert "PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md" in ai
    assert "## Public UI screenshot QA preparation" in routes
    assert "`/withdraw`" in routes and "`/ads`" in routes


def test_operator_kernel_has_public_screenshot_qa_route() -> None:
    cfg = read("ops/operator_kernel/config/routes.yaml")
    classifier = read("ops/operator_kernel/task_classifier.py")
    resolver = read("ops/operator_kernel/route_resolver.py")
    assert "public_ui_screenshot_qa:" in cfg
    assert "PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md" in cfg
    assert "frontend/public/locale/*.json" in cfg
    assert '"public_ui_screenshot_qa"' in classifier
    assert '"public_ui_screenshot_qa"' in resolver
    assert "frontend/src/pages/withdraw.tsx" in resolver
    assert "frontend/src/pages/ads.tsx" in resolver


def test_map_element_public_qa_navigation_update_exists() -> None:
    doc = read("map_element.md")
    assert "## Public screenshot QA navigation update" in doc
    assert "## 18. Обновление v169_39" in doc
    assert "Browser Shop" in doc
    assert "This update is navigational only" in doc
