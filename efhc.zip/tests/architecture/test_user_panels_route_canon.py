from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROFILE_SCRIPT = ROOT / "ops/routes/check_profile_route_canon.py"
PANELS_SCRIPT = ROOT / "ops/routes/check_panels_summary_canon.py"


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_profile_alias_removed_after_consumer_check() -> None:
    module = _load(PROFILE_SCRIPT, "profile_canon_1185")
    data = module.build()
    assert data["status"] == "ok"
    assert data["has_legacy_route"] is False


def test_panels_summary_self_route_is_canonical() -> None:
    module = _load(PANELS_SCRIPT, "panels_canon_1186")
    data = module.build()
    assert data["status"] == "ok"
    assert data["has_canonical_route"] is True
    assert data["has_legacy_route"] is False
