from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LANGS = (
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)


def _faq(lang: str) -> dict:
    return json.loads(
        (ROOT / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.json").read_text(
            encoding="utf-8"
        )
    )


def _item(lang: str, section_index: int, item_index: int) -> dict:
    return _faq(lang)["sections"][section_index]["items"][item_index]


def test_faq_semantic_gate_docs_exist() -> None:
    required = [
        "docs/frontend/FAQ_SEMANTIC_APPROVAL_GATE.md",
        "docs/audits/FAQ_SEMANTIC_APPROVAL_GATE_AUDIT_V169_51.md",
        "reports/generated/faq_semantic_approval_gate_v169_51.json",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_faq_approval_manifest_records_gate() -> None:
    manifest = json.loads(
        (
            ROOT / "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json"
        ).read_text(encoding="utf-8")
    )
    assert manifest["entries_total"] == len(manifest["entries"])
    entry = next(
        (
            e
            for e in manifest["entries"]
            if e["approval_id"] == "FAQ-APPROVAL-0013"
        ),
        None,
    )
    assert entry is not None
    assert entry["approved_by_user"] is True
    assert entry["ru_question_ids"] == [48, 51]


def test_wallet_residual_drift_items_follow_ru_semantics() -> None:
    ru48 = _item("ru", 4, 6)
    ru51 = _item("ru", 4, 9)
    assert "другом аккаунте" in ru48["q"]
    assert "какой кошел" in ru51["q"].lower()

    en48 = _item("en", 4, 6)
    en51 = _item("en", 4, 9)
    assert (
        en48["q"]
        == "What should I do if I want to use my wallet in another account?"
    )
    assert "linked to two accounts" in en48["a"]
    assert (
        en51["q"]
        == "Where can I check which wallet is currently linked to my account?"
    )
    assert "Wallet section" in en51["a"]

    forbidden_fragments = [
        "change my primary wallet",
        "play and grow",
        "spielen und fortschritte",
        "changer de wallet principal",
        "cambio la wallet principal",
        "cambio il wallet principale",
    ]
    for lang in LANGS:
        for section_index, item_index in [(4, 6), (4, 9)]:
            txt = (
                _item(lang, section_index, item_index)["q"]
                + " "
                + _item(lang, section_index, item_index)["a"]
            ).lower()
            for fragment in forbidden_fragments:
                assert (
                    fragment not in txt
                ), f"stale semantic fragment {fragment!r} in {lang}"


def test_generated_catalog_contains_repaired_wallet_items() -> None:
    catalog = (ROOT / "frontend/src/data/faq/catalogs.ts").read_text(
        encoding="utf-8"
    )
    assert (
        "What should I do if I want to use my wallet in another "
        "account?"
        in catalog
    )
    assert (
        "Where can I check which wallet is currently linked to my "
        "account?"
        in catalog
    )
    assert "What happens if I change my primary wallet?" not in catalog
    assert (
        "Can I play and grow if the wallet is not connected yet?"
        not in catalog
    )


def test_semantic_gate_route_is_registered() -> None:
    routes = (
        ROOT / "ops/operator_kernel/config/routes.yaml"
    ).read_text(encoding="utf-8")
    classifier = (
        ROOT / "ops/operator_kernel/task_classifier.py"
    ).read_text(encoding="utf-8")
    resolver = (
        ROOT / "ops/operator_kernel/route_resolver.py"
    ).read_text(encoding="utf-8")
    assert "faq_semantic_approval_gate" in routes
    assert "faq_semantic_approval_gate" in classifier
    assert "faq_semantic_approval_gate" in resolver
