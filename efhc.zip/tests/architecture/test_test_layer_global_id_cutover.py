"""Machine guard принудительного global_id-cutover тестового слоя."""

from __future__ import annotations

import json
from pathlib import Path

from ops.identity.force_test_global_id_cutover import scan

ROOT = Path(__file__).resolve().parents[2]
ALLOWLIST = (
    ROOT
    / "reports"
    / "generated"
    / "test_tg_id_telegram_allowlist.json"
)


def test_бизнес_сервисы_в_тестах_используют_только_global_id() -> None:
    report = scan(ROOT)
    assert report["business_selector_violations"] == []
    assert report["passed"] is True


def test_оставшиеся_tg_id_зарегистрированы_построчно() -> None:
    live = scan(ROOT)
    saved = json.loads(ALLOWLIST.read_text(encoding="utf-8"))
    assert saved["schema"] == "EFHC_TEST_GLOBAL_ID_CUTOVER_V2"
    assert saved["version"] == "v173.27"
    assert saved["cycle"] == 1706
    assert saved["violation_count"] == 0
    assert saved["registered_occurrence_count"] == (
        live["registered_occurrence_count"]
    )
    assert live["registered_occurrence_count"] <= 450
