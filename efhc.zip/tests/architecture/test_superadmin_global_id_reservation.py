"""Замок зарезервированного ``global_id`` владельца Admin."""

from __future__ import annotations

from pathlib import Path

from app.identity.reserved_global_ids import (
    SUPERADMIN_GLOBAL_ID_DB,
    SUPERADMIN_GLOBAL_ID_TEXT,
    is_reserved_global_id_db,
)

ROOT = Path(__file__).resolve().parents[2]
REGISTRATION = ROOT / "backend/app/identity/account_registration.py"
SSOT = ROOT / "docs/SSOT/GLOBAL_IDENTITY_SSOT.md"
RBAC = ROOT / "docs/NORM/ADMIN_RBAC.md"
MODEL = ROOT / "backend/app/models/user_models.py"
MIGRATION = ROOT / "backend/migrations/versions/0001_initial_release_schema.py"


def test_superadmin_global_id_зарезервирован_явно() -> None:
    assert SUPERADMIN_GLOBAL_ID_TEXT == "1313131313"
    assert SUPERADMIN_GLOBAL_ID_DB == 1_313_131_313
    assert is_reserved_global_id_db(SUPERADMIN_GLOBAL_ID_DB)


def test_обычная_регистрация_пропускает_reserved_global_id() -> None:
    source = REGISTRATION.read_text(encoding="utf-8")
    assert "_allocate_regular_global_id" in source
    assert "is_reserved_global_id_db" in source
    assert "global_id=allocated_global_id" in source


def test_active_docs_фиксируют_reserved_superadmin() -> None:
    for path in (SSOT, RBAC):
        text = path.read_text(encoding="utf-8")
        assert "1313131313" in text
        assert "SuperAdmin" in text or "superadmin" in text


def test_db_contract_не_разрешает_reserved_id_обычному_user() -> None:
    model = MODEL.read_text(encoding="utf-8")
    migration = MIGRATION.read_text(encoding="utf-8")
    assert "ck_users_superadmin_global_id_reserved" in model
    assert "reserved_superadmin_global_id_conflict" in migration
    assert "reserved_identity" in migration
