from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RANKS = ROOT / "frontend/src/pages/ranks.tsx"
RANKS_SERVICE = ROOT / "frontend/src/services/ranks.service.ts"
RANKS_QUERY = ROOT / "frontend/src/queries/useRanks.ts"
RANKS_ROUTES = ROOT / "backend/app/routes/ranks_routes.py"
LOCALES = ROOT / "frontend/public/locale"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_ranks_vertical_cards_and_no_public_tg_fallback():
    text = read(RANKS)
    assert 'data-ranks-card-layout="vertical-1299"' in text
    assert 'data-ranks-card="vertical-1299"' in text
    assert 'data-ranks-username-only="true"' in text
    assert "TG ${" not in text
    assert "`TG " not in text
    assert "ranks.user_hidden_fallback" in text


def test_ranks_active_surface_is_kwh_canon_only():
    page = read(RANKS)
    service = read(RANKS_SERVICE)
    assert 'data-ranks-runtime="react-query-kwh-1558"' in page
    assert "total_generated_kwh" in page
    assert "/ranks/my-plus-top/me" in service
    assert "/ranks/top/me" in service
    assert "/ranks/referrals/" not in service
    assert "filter_referrals" not in page


def test_ranks_show_me_focus_exists():
    text = read(RANKS)
    assert 'data-ranks-show-me-boundary="1558"' in text
    assert 'data-ranks-show-me-action="scroll-to-my-card"' in text
    assert "myCardRef.current?.scrollIntoView" in text


def test_ranks_uses_service_and_react_query_not_direct_transport():
    page = read(RANKS)
    service = read(RANKS_SERVICE)
    query = read(RANKS_QUERY)
    assert "apiRequest" not in page
    assert "useMyRankWithTop" in page
    assert "useRankTopPages" in page
    assert "myPlusTopSchema.parse" in service
    assert "topPageSchema.parse" in service
    assert "useQuery" in query
    assert "useInfiniteQuery" in query


def test_ranks_backend_current_user_routes_exist():
    text = read(RANKS_ROUTES)
    assert '"/my-plus-top/me"' in text
    assert '"/top/me"' in text
    assert "get_nonfinancial_read_owner" in text
    assert "NonFinancialReadOwner" in text


def test_ranks_proof_and_locale_keys_exist_everywhere():
    text = read(RANKS)
    assert 'data-ranks-proof-pass="1558"' in text
    keys = [
        '"ranks.my_energy"',
        '"ranks.me"',
        '"ranks.top"',
        '"ranks.find_me"',
        '"ranks.user_hidden_fallback"',
    ]
    for path in LOCALES.glob("*.json"):
        locale_text = read(path)
        for key in keys:
            assert key in locale_text, f"{path.name} missing {key}"
