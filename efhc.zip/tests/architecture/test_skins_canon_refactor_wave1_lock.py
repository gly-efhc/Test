from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
SKINS_TS = ROOT / "frontend" / "src" / "lib" / "skins.ts"

SKIN_KEYS = [
    "shop_ui.buy_skin_hint",
    "shop_ui.owned_skin_hint",
    "shop_ui.skin_purchased",
    "shop_ui.skins_empty_detail",
    "shop_ui.skins_note",
]

BANNED = [
    "buy",
    "purchase",
    "shop skins",
    "купит",
    "покуп",
    "придбан",
    "satın al",
    "achetez",
    "compr",
]


def test_skin_locale_keys_no_longer_sell_skins() -> None:
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in SKIN_KEYS:
            val = str(data.get(key, "")).lower()
            assert val, f"{path.name}: missing {key}"
            for banned in BANNED:
                assert banned not in val, (
                    f"{path.name}: {key} still contains "
                    f"banned wording: {banned!r}"
                )


def test_user_level_skins_count_is_12() -> None:
    text = SKINS_TS.read_text(encoding="utf-8")
    assert "USER_LEVEL_SKINS" in text
    assert text.count("level: ") >= 12
    assert "canonical user-facing progression theme layer" in text
