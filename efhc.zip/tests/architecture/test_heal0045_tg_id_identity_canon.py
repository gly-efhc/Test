from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REFERRALS_CRUD = ROOT / "backend/app/crud/referrals_crud.py"

# LEGACY compatibility: these assertions preserve the pre-migration
# join until user_id backfill and read switch are completed.


def _admin_top_inviters_source() -> str:
    content = REFERRALS_CRUD.read_text(encoding="utf-8")
    marker = "async def admin_top_inviters"
    start = content.index(marker)
    end_marker = "# ======================================================================\n# Пояснения"
    end = content.index(end_marker, start)
    return content[start:end]


def test_legacy_admin_top_inviters_join_is_stable() -> None:
    source = _admin_top_inviters_source()
    forbidden = [
        "ReferralLink.inviter_tg_id == User.id",
        "active_subq.c.tg_id == User.id",
        "bonus_subq.c.tg_id == User.id",
    ]
    for pattern in forbidden:
        assert pattern not in source

    required = [
        "ReferralLink.inviter_tg_id == User.tg_id",
        "active_subq.c.tg_id == User.tg_id",
        "bonus_subq.c.tg_id == User.tg_id",
    ]
    for pattern in required:
        assert pattern in source


def test_legacy_admin_top_inviters_exposes_telegram_id() -> None:
    source = _admin_top_inviters_source()
    assert 'User.tg_id.label("inviter_tg_id")' in source
    assert "User.id," not in source
    assert "User.id.label" not in source
    assert "User.id," not in source[source.index("select(") :]


def test_legacy_referral_join_does_not_mix_identity_spaces() -> None:
    content = REFERRALS_CRUD.read_text(encoding="utf-8")
    forbidden_fragments = [
        "inviter_tg_id == User.id",
        "invitee_tg_id == User.id",
        "c.tg_id == User.id",
        "ReferralBonusLedger.tg_id == User.id",
    ]
    for fragment in forbidden_fragments:
        assert fragment not in content
