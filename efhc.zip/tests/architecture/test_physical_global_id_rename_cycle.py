"""Контракты schema freeze и pre-release migration squash цикла 1632."""

from __future__ import annotations

import json
from pathlib import Path

import app.models  # noqa: F401
from alembic.config import Config
from alembic.script import ScriptDirectory
from app.models.base import Base
from app.models.user_models import User
from app.release.database_contract import load_all_models
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task
from sqlalchemy import inspect

ROOT = Path(__file__).resolve().parents[2]
MIGRATION = (
    ROOT
    / "backend/migrations/versions/0001_initial_release_schema.py"
)


def test_cycle_1632_имеет_отдельный_primary_route() -> None:
    task = classify_task(
        "Цикл 1632 — schema freeze и pre-release migration squash"
    )
    assert task["task_type"] == "pre_release_migration_squash"
    route = resolve_route(task["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "pre_release_migration_squash"


def test_active_lineage_содержит_release_0001_и_baseline_0001() -> None:
    versions = sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert versions == [
        "0001_initial_release_schema.py",
    ]

    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    assert script.get_heads() == ["0001"]
    revision = script.get_revision("0001")
    assert revision is not None
    assert revision.down_revision is None


def test_release_0001_создаёт_final_global_id_schema() -> None:
    source = MIGRATION.read_text(encoding="utf-8")
    for marker in (
        'revision = "0001"',
        "down_revision = None",
        "users_global_id_seq",
        "users.global_id",
        "identity_migration_control",
        "identity_ownership_shadow_telemetry",
        "financial_read_global_id_enabled",
        "nonfinancial_read_global_id_enabled",
        "expected 39 global owner FK",
    ):
        assert marker in source
    assert "RENAME COLUMN user_id TO global_id" not in source
    assert "0002_users_user_id_expand.py" not in source


def test_orm_имеет_одну_physical_global_id_колонку() -> None:
    mapper = inspect(User)
    assert "global_id" in mapper.columns
    assert "user_id" not in User.__table__.c
    assert User.user_id.key == "user_id"
    assert User.user_id.name == "global_id"
    assert User.__table__.c.global_id.server_default is not None


def test_все_orm_fk_ссылаются_на_users_global_id() -> None:
    load_all_models()
    owner_fks = []
    for table in Base.metadata.sorted_tables:
        for constraint in table.foreign_key_constraints:
            for element in constraint.elements:
                if (
                    element.column.table.fullname == "efhc_core.users"
                    and element.target_fullname.endswith(".global_id")
                ):
                    owner_fks.append(element.target_fullname)
    assert owner_fks
    assert all(target == "efhc_core.users.global_id" for target in owner_fks)
    assert len(owner_fks) == 39


def test_release_policy_содержит_lineage_0001_0002() -> None:
    policy = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )
    assert policy["supported_database_revisions"] == ["0001"]
    assert policy["target_database_revision"] == "0001"
    assert policy["database_migration_class"] == (
        "PRE_RELEASE_MIGRATION_SQUASH"
    )
    assert policy["database_migration_phase"] == (
        "CANONICAL_BASELINE"
    )


def test_pre_release_history_не_остаётся_active_revision() -> None:
    text = "\n".join(
        path.name
        for path in (ROOT / "backend/migrations/versions").iterdir()
    )
    for revision in range(3, 14):
        assert f"{revision:04d}" not in text
