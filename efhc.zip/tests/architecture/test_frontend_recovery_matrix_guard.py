from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MATRIX = (
    ROOT / "reports/generated/frontend_page_element_matrix_v168_68.json"
)


def _matrix() -> dict:
    return json.loads(MATRIX.read_text(encoding="utf-8"))


def test_frontend_recovery_canon_sources_exist() -> None:
    required = [
        "docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md",
        "docs/frontend/FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md",
        "docs/frontend/FRONTEND_SOURCE_CANON_FREEZE.md",
        "docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md",
        "docs/frontend/FRONTEND_VISUAL_TOKEN_SHELL_LOCK.md",
    ]
    missing = [path for path in required if not (ROOT / path).exists()]
    assert missing == []


def test_original_sources_remain_md_only() -> None:
    base = ROOT / "docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START"
    assert not (base / "pdf").exists()
    assert not (base / "text").exists()
    assert (base / "md").is_dir()


def test_page_matrix_contains_core_screens() -> None:
    screens = _matrix()["screens"]
    expected = [
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
        "Profile",
        "Wallet",
        "History",
        "FAQ",
        "HUB",
        "Browser-Shop",
        "Admin",
        "BrowserLogin",
    ]
    missing = [name for name in expected if name not in screens]
    assert missing == []


def test_energy_forbidden_cards_are_locked() -> None:
    forbidden = " ".join(_matrix()["screens"]["Energy"]["forbidden"])
    for marker in ["HUB", "Wallet", "Profile", "Tasks", "Shop"]:
        assert marker in forbidden


def test_panels_countdown_is_mandatory() -> None:
    mandatory = " ".join(_matrix()["screens"]["Panels"]["mandatory"])
    forbidden = " ".join(_matrix()["screens"]["Panels"]["forbidden"])
    assert "activation date" in mandatory
    assert "deactivation date" in mandatory
    assert "runtime countdown" in mandatory
    assert "panel age" in forbidden


def test_exchange_transfer_ban_is_locked() -> None:
    screen = _matrix()["screens"]["Exchange"]
    mandatory = " ".join(screen["mandatory"])
    forbidden = " ".join(screen["forbidden"])
    assert "1 kWh = 1 EFHC" in mandatory
    assert "user to user transfer" in forbidden
    assert "recipient input" in forbidden


def test_wallet_history_boundary_is_locked() -> None:
    wallet_forbidden = " ".join(
        _matrix()["screens"]["Wallet"]["forbidden"]
    )
    history_mandatory = " ".join(
        _matrix()["screens"]["History"]["mandatory"]
    )
    assert "account History button inside Wallet" in wallet_forbidden
    assert "all account financial movements" in history_mandatory


def test_hub_and_admin_boundaries_are_locked() -> None:
    hub = _matrix()["screens"]["HUB"]
    admin = _matrix()["screens"]["Admin"]
    assert "two equal buttons" in " ".join(hub["mandatory"])
    assert "third item without chat approval" in " ".join(
        hub["forbidden"]
    )
    assert "debug dump on main admin page" in " ".join(
        admin["forbidden"]
    )


def test_visual_tokens_are_recorded() -> None:
    tokens = _matrix()["visual_tokens"]
    assert tokens["theme"] == "dark first paint"
    assert "progress bars" in tokens["progress"]
    assert "no horizontal scroll" in tokens["mobile_width"]
