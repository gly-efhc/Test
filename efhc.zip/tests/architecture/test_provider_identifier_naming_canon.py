from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ACTIVE_ROOTS = (ROOT / "backend", ROOT / "frontend", ROOT / "contracts")
FORBIDDEN = ("tg_provider_id", "telegram_provider_id")


def test_промежуточные_имена_telegram_provider_запрещены() -> None:
    hits: list[str] = []
    for root in ACTIVE_ROOTS:
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix not in {".py", ".ts", ".tsx", ".js", ".json"}:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            for token in FORBIDDEN:
                if re.search(rf"\b{re.escape(token)}\b", text):
                    hits.append(f"{path.relative_to(ROOT)}: {token}")
    assert not hits, "Запрещённые provider-имена:\n" + "\n".join(hits)
