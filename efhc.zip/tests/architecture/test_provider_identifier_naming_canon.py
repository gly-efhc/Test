from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ACTIVE_ROOTS = (ROOT / "backend", ROOT / "frontend", ROOT / "contracts")
FORBIDDEN = ("tg_provider_id", "telegram_provider_id")


def test_промежуточные_имена_telegram_provider_запрещены() -> None:
    hits: list[str] = []
    for root in ACTIVE_ROOTS:
        for path in root.rglob("*"):
            if (
                not path.is_file()
                or path.suffix
                not in {".py", ".ts", ".tsx", ".js", ".json"}
            ):
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            for token in FORBIDDEN:
                if re.search(rf"\b{re.escape(token)}\b", text):
                    hits.append(f"{path.relative_to(ROOT)}: {token}")
    assert not hits, "Запрещённые provider-имена:\n" + "\n".join(hits)


def test_auth_provider_wire_names_каноничны_и_без_alias() -> None:
    auth_provider = (ROOT / "backend/app/identity/auth_provider.py").read_text(
        encoding="utf-8"
    )
    ton_schema = (ROOT / "backend/app/schemas/auth_ton_schemas.py").read_text(
        encoding="utf-8"
    )
    ton_route = (ROOT / "backend/app/routes/auth_ton_routes.py").read_text(
        encoding="utf-8"
    )
    ton_frontend = (ROOT / "frontend/src/lib/ton-auth.ts").read_text(
        encoding="utf-8"
    )
    assert 'TON = "ton"' in auth_provider
    assert "TON_WALLET" not in auth_provider
    assert 'Literal["ton"]' in ton_schema
    assert 'Literal["ton_wallet"]' not in ton_schema
    assert 'active.get("ton")' in ton_route
    assert 'active.get("ton_wallet")' not in ton_route
    assert 'provider: "ton"' in ton_frontend
    assert 'provider: "ton_wallet"' not in ton_frontend



def test_provider_subject_names_соответствуют_утверждённому_канону() -> None:
    mapping = (
        ROOT / "docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md"
    ).read_text(encoding="utf-8")
    schema = (ROOT / "backend/app/schemas/auth_ton_schemas.py").read_text(
        encoding="utf-8"
    )
    frontend = (ROOT / "frontend/src/lib/ton-auth.ts").read_text(
        encoding="utf-8"
    )
    resolver = (
        ROOT / "backend/app/identity/ton_wallet_id_resolver.py"
    ).read_text(encoding="utf-8")
    admin_model = (ROOT / "backend/app/models/admin_models.py").read_text(
        encoding="utf-8"
    )
    migration = (
        ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    openapi = (ROOT / "backend/openapi/openapi.json").read_text(
        encoding="utf-8"
    )
    assert "| TON | `ton` | `ton_wallet_id` |" in mapping
    assert "ton_wallet_id: StrictStr" in schema
    assert "ton_wallet_id: str" in schema
    assert "provider_subject: str" not in schema
    assert "ton_wallet_id: string" in frontend
    assert "provider_subject: string" not in frontend
    assert "def ton_wallet_id(self)" in resolver
    assert "ton_wallet_id: Mapped[str | None]" in admin_model
    assert "UniqueConstraint(\"ton_wallet_id\"" in admin_model
    assert "RENAME COLUMN ton_address TO ton_wallet_id" in migration
    assert '"ton_wallet_id"' in openapi
