"""Архитектурный контракт background owner/delivery boundary."""
from __future__ import annotations

from ops.identity.check_background_identity_split import check


def test_background_owner_global_id_а_delivery_tg_id() -> None:
    result = check()
    assert result["passed"], result["violations"]
    assert result["background_business_state_tg_id"] == 0
    assert result["telegram_delivery_boundary"] == "PRESERVED"
