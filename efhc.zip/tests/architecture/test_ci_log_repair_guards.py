from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_admin_bank_import_block_keeps_ruff_order() -> None:
    text = _read("backend/app/services/admin/admin_bank_service.py")
    assert (
        "from .admin_rbac import RBAC, AdminRole, AdminUser"
        in text
    )
    assert "from .admin_rbac import AdminUser, RBAC" not in text


def test_transactions_import_block_keeps_ruff_order() -> None:
    text = _read("backend/app/services/transactions_service.py")
    future = text.index("from __future__ import annotations")
    first_import = text.index("import asyncio")
    marker = text.index(
        "IDEMPOTENCY_KEY_REUSED_FOR_DIFFERENT_BANK_OPERATION"
    )
    assert future < first_import < marker


def test_route_inventory_freeze_has_status_note() -> None:
    text = _read("docs/audits/ROUTE_INVENTORY_FREEZE.md")
    assert "Status note" in text
    assert "historical route inventory snapshot" in text
