import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PANEL = ROOT / "frontend/src/components/ExchangePanel.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
LOCALES = ROOT / "frontend/public/locale"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"
CHATS = ROOT / "docs/NORM/CHATS/21.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_exchange_amount_preview_has_canonical_markers() -> None:
    src = read(PANEL)
    assert 'data-exchange-amount-polish="1287"' in src
    assert 'data-exchange-amount-input="kwh"' in src
    assert 'data-exchange-preview="one-to-one"' in src
    assert 'data-exchange-max-action="true"' in src
    assert 'data-exchange-rate="1-kwh-1-efhc"' in src


def test_exchange_amount_input_is_sanitized_and_limited() -> None:
    src = read(PANEL)
    assert "sanitizeAmountInput" in src
    assert "decimals >= 8" in src
    assert 'replace(/,/g, ".")' in src
    assert "aria-invalid={overMax || !amountIsValid}" in src
    assert "amountScaled > maxScaled" in src


def test_exchange_preview_has_no_fast_actions_or_transfer() -> None:
    src = read(PANEL)
    banned = ["setPct", ">25%<", ">50%<", ">100%<", "transfer"]
    for token in banned:
        assert token not in src


def test_exchange_preview_locale_keys_exist() -> None:
    required = {
        "exchange.amount_label",
        "exchange.receive_label",
        "exchange.amount_hint",
        "exchange.amount_over_available",
        "exchange.amount_invalid_detail",
    }
    for path in sorted(LOCALES.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = required.difference(data)
        assert not missing, f"{path.name}: {sorted(missing)}"


def test_exchange_amount_preview_docs_and_chats_exist() -> None:
    css = read(CSS)
    docs = read(PLAN) + "\n" + read(REPORTS)
    assert "work pass" in css
    assert ".efhc-exchange-preview-row" in css
    assert "v168_85 / work pass" in docs
    assert "Exchange amount/preview polish" in docs
    assert CHATS.exists()
    assert "ветки 21" in read(CHATS)
