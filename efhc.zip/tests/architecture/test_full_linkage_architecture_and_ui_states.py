from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "reports/generated/full_linkage_report_v170_24.json"
SCRIPT = ROOT / "ops/linkage/build_full_linkage_report.py"
OPENAPI = ROOT / "backend/openapi/openapi.json"


def _load_script():
    spec = importlib.util.spec_from_file_location("full_linkage", SCRIPT)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


def _report() -> dict:
    module = _load_script()
    report = module.build_report()
    REPORT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return report


def test_full_linkage_report_is_green() -> None:
    report = _report()
    assert report["cycle"] == "1448"
    assert report["version"] == "v170.24"
    assert report["status"] == "ok"
    assert report["blockers"] == []


def test_all_frontend_api_calls_have_backend_route() -> None:
    report = _report()
    assert report["frontend_api_call_count"] >= 80
    assert report["missing_frontend_backend"] == []


def test_route_schema_contract_frontend_backend_match() -> None:
    report = _report()
    assert report["openapi_gate_status"] == "ok"
    assert report["missing_frontend_openapi"] == []


def test_admin_hub_uses_generated_seam_contract() -> None:
    report = _report()
    contract = report["admin_hub_seam_contract"]
    assert contract["missing_generated_tokens"] == []
    assert contract["raw_admin_hub_api_literals"] == []
    assert "ADMIN_HUB_LINKS_PATH" in contract["page_imported_tokens"]
    assert "ADMIN_HUB_LINK_CREATE_PATH" in contract["page_imported_tokens"]
    assert "ADMIN_HUB_LINK_UPDATE_PATH" in contract["page_imported_tokens"]
    assert "ADMIN_HUB_LINK_TOGGLE_PATH" in contract["page_imported_tokens"]
    assert "ADMIN_HUB_LINK_REORDER_PATH" in contract["page_imported_tokens"]


def test_admin_routes_are_marked_admin_or_guarded() -> None:
    report = _report()
    assert report["admin_unmarked"] == []


def test_services_do_not_use_legacy_money_table_refs() -> None:
    report = _report()
    assert report["raw_legacy_money_table_refs"] == {}


def test_no_direct_balance_write_outside_canonical_service() -> None:
    report = _report()
    assert report["direct_balance_writes_outside_canonical_service"] == []


def test_user_object_routes_have_ownership_check() -> None:
    data = json.loads(OPENAPI.read_text(encoding="utf-8"))
    public_tg_routes: list[str] = []
    for path, methods in data.get("paths", {}).items():
        if path.startswith("/admin/") or "{tg_id}" not in path:
            continue
        for method in methods:
            if method.lower() in {"post", "put", "patch", "delete"}:
                public_tg_routes.append(f"{method.upper()} {path}")

    assert public_tg_routes == ["POST /sync/user/{tg_id}"]
    text = (ROOT / "backend/app/routes/sync_routes.py").read_text(
        encoding="utf-8",
    )
    assert "current_tg_id: int = Depends(get_current_tg_id)" in text
    assert "int(tg_id) != int(current_tg_id)" in text
    assert "status_code=403" in text


def test_critical_frontend_api_calls_have_loading_error_empty_state() -> None:
    report = _report()
    assert len(report["critical_ui_surfaces"]) >= 10
    assert report["critical_ui_state_missing"] == []
