from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT_PATH = "reports/generated/fresh_ci_live_referral_proof_gate_v171_14.json"


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def report() -> dict[str, object]:
    return json.loads(read(REPORT_PATH))


def test_cycle_1539_report_records_no_new_external_evidence() -> None:
    data = report()
    assert data["cycle"] == 1539
    assert data["version"] == "v171.14"
    assert data["input_archive"] == (
        "EFHC_Bot_v171_13_cycle_1538_"
        "fresh_ci_artifact_hygiene_log_repair.zip"
    )
    assert data["new_logs_received"] is False
    assert data["new_audit_received"] is False
    assert data["new_tz_received"] is False
    assert "C1539-PROOF-GATE-NO-NEW-EVIDENCE" in data["closed_items"]


def test_cycle_1539_release_claims_remain_fail_closed() -> None:
    data = report()
    false_claims = [
        "github_ci_green_claimed",
        "full_pytest_green_claimed",
        "frontend_build_green_for_output_claimed",
        "live_telegram_proof_claimed",
        "real_webapp_start_param_proof_claimed",
        "real_tonconnect_proof_claimed",
        "release_ready_claimed",
        "production_ready_claimed",
    ]
    for key in false_claims:
        assert data[key] is False


def test_cycle_1539_does_not_mutate_runtime_or_money_boundaries() -> None:
    data = report()
    protected_flags = [
        "runtime_economy_changed",
        "money_flow_changed",
        "withdraw_logic_changed",
        "wallet_flow_changed",
        "tonconnect_changed",
        "frontend_money_mutation_changed",
        "sandbox_runtime_code_copied",
    ]
    for key in protected_flags:
        assert data[key] is False


def test_current_kernel_map_cycles_and_release_status_are_recorded() -> None:
    kernel = read("KERNEL.md")
    cycles = read("docs/cycles/WORK_CYCLES.md")
    release = read("docs/NORM/RELEASE_PROOF_STATUS.md")
    map_element = read("map_element.md")

    assert "Canonical archive lineage:" in kernel
    assert "Last cycle:" in cycles
    assert "Range `1501–1600`:" in cycles
    assert "Release proof status" in release
    assert "not claimed" in release.lower()
    assert "v171." in map_element


def test_cycle_1539_docs_reports_and_routes_are_registered() -> None:
    manifest = read("docs/testing/TEST_GUARD_MANIFEST.md")
    reports = read("reports/REPORTS_INDEX.md")
    routes = read("ops/operator_kernel/config/routes.yaml")

    assert "test_fresh_ci_live_referral_proof_gate.py" in manifest
    assert "fresh_ci_live_referral_proof_gate_v171_14.json" in reports
    assert "fresh_ci_live_referral_proof_gate:" in routes
    assert "cycle: 1539" in routes
