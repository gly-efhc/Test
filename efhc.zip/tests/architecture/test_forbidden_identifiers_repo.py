from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

# --- Log artifacts policy (SSOT) ---
# Логи и журналы ошибок фиксируются 1:1 (как есть)
# и могут содержать строки из CI/traceback.
# Поэтому они исключаются из большинства
# guard-тестов, чтобы не ломать канон проекта.
# Исключение: отдельный тест длины строки 72.
# Исключение: отдельный тест длины строки 72.
# чтобы не ломать канон проекта.
# Исключение: отдельный тест длины строки 72.
LOG_EXCLUDED_FILE_NAMES = {
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
}
LOG_EXCLUDED_DIR_PARTS = {
    ".local_artifacts",
    "logs",
}
LOG_EXCLUDED_SUFFIXES = {
    ".log",
}


def _is_log_artifact(path: Path) -> bool:
    if path.name in LOG_EXCLUDED_FILE_NAMES:
        return True
    if set(path.parts) & LOG_EXCLUDED_DIR_PARTS:
        return True
    if path.suffix.lower() in LOG_EXCLUDED_SUFFIXES:
        return True
    return bool(path.name.startswith("logs_"))


@dataclass(frozen=True)
class Finding:
    rel_path: str
    line_no: int
    line: str
    hint: str


# --- Canon: forbidden patterns (repo-wide) ---
# A) MUST NOT: telegram id (no underscore) in any casing.
FORB_TELEGRAM_KEY = "telegram" + "_" + "id"
RE_FORB_TELEGRAM_KEY = re.compile(FORB_TELEGRAM_KEY, re.IGNORECASE)

# B) Optional (enabled): user-id alias forms.
# - tg id (but NOT tg_id)
FORB_TG_KEY = "tg" + "id"
RE_FORB_TG_KEY_WORD = re.compile(
    r"\b" + FORB_TG_KEY + r"\b", re.IGNORECASE
)
# - u id as a standalone word
FORB_U_KEY = "u" + "id"
RE_FORB_U_KEY_WORD = re.compile(
    r"\b" + FORB_U_KEY + r"\b", re.IGNORECASE
)

# Explicit replacement hints (exact keys).
EXACT_HINTS = {
    "ADMIN_" + "TELEGRAM" + "_ID": "ADMIN_TG_ID",
    "ADMIN_BANK_" + "TELEGRAM" + "_ID": "BANK_EFHC",
    (
        "NEXT_PUBLIC_ADMIN_" + "TELEGRAM" + "_IDS"
    ): "NEXT_PUBLIC_ADMIN_TG_IDS",
    "BANK_" + "TELEGRAM" + "_ID": "BANK_EFHC",
    "ROOT_ADMIN_" + "TELEGRAM" + "_ID": "ROOT_ADMIN_TG_ID",
}

# Extensions we consider as text for this guard.
ALLOWED_SUFFIXES = {
    ".py",
    ".txt",
    ".md",
    ".yml",
    ".yaml",
    ".json",
    ".env",
    ".example",
    ".ts",
    ".tsx",
}

# Binary / noise exclusions by suffix (case-insensitive).
BINARY_SUFFIXES = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".svg",
    ".pdf",
    ".zip",
    ".tar",
    ".gz",
    ".7z",
    ".ico",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".pyc",
}

APPROVED_TELEGRAM_ALIAS_FILES = {
    "backend/app/identity/compatibility_registry.py",
    "backend/app/identity/legacy_alias.py",
    "backend/app/models/user_models.py",
    "ops/identity/check_identity_compatibility_registry.py",
    "ops/identity/check_global_id_canon.py",
    "ops/identity/check_cross_language_identity_separation.py",
    "ops/identity/tg_id_domain_boundary_baseline.json",
}


EXCLUDED_DIR_PARTS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    ".next",
}


def _is_excluded(path: Path) -> bool:
    if _is_log_artifact(path):
        return True

    parts = set(path.parts)
    if parts & EXCLUDED_DIR_PARTS:
        return True

    suf = path.suffix.lower()
    if suf in BINARY_SUFFIXES:
        return True

    # Allow .env.* and .env.*.example where suffix is ".example".
    return bool(
        (
            suf not in ALLOWED_SUFFIXES
            and path.name not in {".env", "editorconfig"}
        )
        and not path.name.startswith(".env")
    )


def _iter_files(repo_root: Path) -> Iterable[Path]:
    """
    Guard scans only product roots:
    backend, frontend, ops and migrations.
    This excludes docs/tests/other folders from this guard test.
    """
    allowed_roots = ["backend", "frontend", "ops", "migrations"]

    for root_name in allowed_roots:
        root = repo_root / root_name
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            if _is_excluded(p):
                continue
            yield p


def _hint_for_line(line: str) -> str:
    for k, v in EXACT_HINTS.items():
        if k in line:
            return f"Replace: {k} -> {v}"

    upper = line.upper()
    if ("TELEGRAM" + "_IDS") in upper:
        return "Rule: *_TELEGRAM" + "_IDS* -> *_TG_IDS*"
    if ("TELEGRAM" + "_ID") in upper:
        return "Rule: *_TELEGRAM" + "_ID* -> *_TG_ID*"
    if FORB_TG_KEY.upper() in upper:
        return "Use canonical tg_id (snake_case)."
    if re.search(RE_FORB_U_KEY_WORD, line):
        return "Use canonical tg_id (snake_case)."

    return "Remove forbidden identifier."


def _scan_file(repo_root: Path, path: Path) -> list[Finding]:
    findings: list[Finding] = []
    rel = str(path.relative_to(repo_root))

    try:
        data = path.read_bytes()
    except OSError:
        return findings

    text = data.decode("utf-8", errors="ignore")
    approved_alias_file = rel in APPROVED_TELEGRAM_ALIAS_FILES
    for idx, line in enumerate(text.splitlines(), start=1):
        if (
            "ops/monitoring/grafana" in rel
            and line.lstrip().startswith('"uid":')
        ):
            continue
        if RE_FORB_TELEGRAM_KEY.search(line):
            if not approved_alias_file:
                finding = Finding(rel, idx, line, _hint_for_line(line))
                findings.append(finding)
            continue
        if RE_FORB_TG_KEY_WORD.search(line):
            if not approved_alias_file:
                finding = Finding(rel, idx, line, _hint_for_line(line))
                findings.append(finding)
            continue
        if RE_FORB_U_KEY_WORD.search(line):
            finding = Finding(rel, idx, line, _hint_for_line(line))
            findings.append(finding)
            continue

    return findings


def test_forbidden_identifiers_repo() -> None:
    # tests/architecture/ -> tests/ -> repo root
    repo_root = Path(__file__).resolve().parents[2]

    all_findings: list[Finding] = []
    for p in _iter_files(repo_root):
        all_findings.extend(_scan_file(repo_root, p))

    if not all_findings:
        return

    report: list[str] = []
    report.append("Forbidden identifiers found (repo-wide):")
    for f in all_findings:
        snippet = f.line.strip("\n")
        if len(snippet) > 180:
            snippet = snippet[:177] + "..."
        report.append(
            f"- {f.rel_path}:{f.line_no}: {snippet} | {f.hint}"
        )

    raise AssertionError("\n".join(report))
