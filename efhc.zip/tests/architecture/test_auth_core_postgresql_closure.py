"""Архитектурные guards интеграционного закрытия auth-core."""

from __future__ import annotations

import ast
import json
from pathlib import Path

from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
PG_TEST = ROOT / "tests/integration/test_auth_runtime_postgresql.py"
MIGRATIONS = ROOT / "backend/migrations/versions"


def test_kernel_route_1614_является_exact_primary() -> None:
    task = classify_task(
        "Цикл 1614 — auth-core PostgreSQL integration closure, "
        "migrations concurrency logout roles и 0 critical skips"
    )
    assert task["task_type"] == "auth_core_postgresql_closure"
    assert task["confidence"] >= 0.99
    route = resolve_route(task["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_auth_core_postgresql_scope_имеет_девять_tests() -> None:
    source = PG_TEST.read_text(encoding="utf-8")
    tree = ast.parse(source)
    tests = [
        node.name
        for node in tree.body
        if isinstance(node, ast.AsyncFunctionDef)
        and node.name.startswith("test_")
    ]
    assert len(tests) == 9
    required = (
        "concurrent_challenge_consume",
        "session_revoke",
        "role_revoke",
        "concurrent_role_grant",
        "schema_head_0008",
    )
    for marker in required:
        assert any(marker in name for name in tests)


def test_auth_core_postgresql_scope_не_содержит_critical_skip() -> None:
    source = PG_TEST.read_text(encoding="utf-8")
    assert "pytest.skip" not in source
    assert "pytest.mark.skip" not in source
    assert "pytest.mark.xfail" not in source


def test_auth_core_входит_в_единую_release_revision_0001() -> None:
    migrations = {path.name for path in MIGRATIONS.glob("*.py")}
    assert migrations == {
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    }
    migration = (MIGRATIONS / "0001_initial_release_schema.py").read_text(
        encoding="utf-8"
    )
    for table in (
        "efhc_core.user_identities",
        "efhc_core.auth_challenges",
        "efhc_core.auth_sessions",
        "efhc_core.user_roles",
    ):
        assert table in migration


def test_ci_findings_1614_имеют_точный_run() -> None:
    path = (
        ROOT
        / "reports/generated/cycle_1614_ci_findings_v172_13.json"
    )
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["цикл"] == 1614
    assert payload["run_id"] == 82888503300
    assert payload["исходный_head"] == "EFHC_Bot_v172_12.zip"
