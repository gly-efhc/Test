from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TX_SERVICE = ROOT / "backend/app/services/transactions_service.py"
BOUNDARY_MAP = ROOT / "docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_MAP.md"
IDEMPOTENCY_DOC = ROOT / "docs/backend/P0_HEAL0023_IDEMPOTENCY_READTHROUGH_HARDENING.md"


def test_heal0023_detector_catches_explicit_idempotency_conflict_marker() -> None:
    content = TX_SERVICE.read_text(encoding="utf-8")
    helper_start = content.index("def _is_idempotency_conflict")
    helper_end = content.index("def _is_transient_tx_error", helper_start)
    helper = content[helper_start:helper_end]

    assert "idempotency_conflict:" in helper.lower()
    assert "unique" in helper and "idempotency_key" in helper
    assert 'startswith("idempotency_conflict:")' in helper


def test_heal0023_no_direct_case_sensitive_conflict_startswith_remains() -> None:
    content = TX_SERVICE.read_text(encoding="utf-8")
    assert 'startswith("IDEMPOTENCY_CONFLICT:")' not in content
    assert "startswith('IDEMPOTENCY_CONFLICT:')" not in content
    assert "if _is_idempotency_conflict(exc):" in content
    assert "if _is_idempotency_conflict(e):" in content


def test_heal0023_readthrough_documented_and_guarded() -> None:
    doc = IDEMPOTENCY_DOC.read_text(encoding="utf-8")
    assert "HEAL-0023" in doc
    assert "IDEMPOTENCY_CONFLICT" in doc
    assert "read-through" in doc
    assert "tests/architecture/test_heal0023_0018_idempotency_transaction_boundary.py" in doc


def test_heal0018_transaction_boundary_map_exists_before_runtime_repair() -> None:
    doc = BOUNDARY_MAP.read_text(encoding="utf-8")
    assert "HEAL-0018" in doc
    assert "service-owned" in doc
    assert "route-owned" in doc
    assert "begin_nested" in doc
    assert "1410" in doc
    assert "NO_RUNTIME_BOUNDARY_REWRITE_IN_1409" in doc


def test_heal0018_boundary_map_lists_core_money_services() -> None:
    doc = BOUNDARY_MAP.read_text(encoding="utf-8")
    for marker in (
        "transactions_service.py",
        "withdraw_service.py",
        "payment_intents_service.py",
        "efhc_deposits_service.py",
        "system_locks.py",
    ):
        assert marker in doc
