from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def _locale(lang: str) -> dict[str, str]:
    path = ROOT / "frontend" / "public" / "locale" / f"{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def test_current_head_and_release_boundary_are_recorded() -> None:
    kernel = _read("KERNEL.md")
    release = _read("docs/NORM/RELEASE_PROOF_STATUS.md")
    map_element = _read("map_element.md")
    report = json.loads(
        _read(
            "reports/generated/fresh_ci_referral_log_repair_v171_11.json"
        )
    )
    assert "Canonical archive lineage:" in kernel
    assert "v171." in map_element
    assert report["log"] == "logs_74569153381.zip"
    assert "GitHub CI green" in release
    assert "not claimed" in release.lower()
    assert "fail-closed" in release.lower()


def test_start_payload_is_preserved_for_fail_closed_validation() -> None:
    src = _read("backend/app/bot/handlers/start_handlers.py")
    assert "payload = parts[1].strip()" in src
    assert "await onboard_user_at_first_creation(" in src
    assert "attach_referral_code_for_user" not in src


def test_openapi_snapshot_has_no_manual_referral_bind_routes() -> None:
    spec = json.loads(_read("backend/openapi/openapi.json"))
    manifest = json.loads(
        _read("backend/openapi/openapi_manifest.json")
    )
    paths = spec.get("paths", {})
    assert "/referrals/bind" not in paths
    assert "/referrals/attach" not in paths
    assert manifest["operation_count"] == sum(
        len(methods) for methods in paths.values()
    )


def test_new_public_i18n_keys_are_localized_not_english_fallback() -> (
    None
):
    en = _locale("en")
    keys = [
        "exchange.exchange_failed",
        "onboarding.done",
        "onboarding.skip",
        "onboarding.next",
        "onboarding.kicker",
        "onboarding.energy_title",
        "onboarding.energy_text",
        "onboarding.panels_title",
        "onboarding.panels_text",
        "onboarding.exchange_title",
        "onboarding.exchange_text",
        "onboarding.help_title",
        "onboarding.help_text",
    ]
    for lang in ("de", "fr", "es", "it", "tr", "pl", "da", "hi"):
        data = _locale(lang)
        for key in keys:
            assert data[key]
            assert data[key] != en[key]


def test_public_locale_count_guard_matches_new_key_count() -> None:
    counts = {
        lang: len(_locale(lang))
        for lang in (
            "en",
            "ru",
            "uk",
            "de",
            "fr",
            "es",
            "it",
            "pl",
            "tr",
            "id",
            "hi",
            "sw",
            "da",
        )
    }
    assert len(set(counts.values())) == 1
    assert min(counts.values()) >= 1554


def test_cycle_report_records_failed_gates_without_false_green_claim() -> (
    None
):
    report = json.loads(
        _read(
            "reports/generated/fresh_ci_referral_log_repair_v171_11.json"
        )
    )
    assert report["log"] == "logs_74569153381.zip"
    assert report["failed_gates"] == ["ruff", "mypy", "pytest"]
    assert report["fresh_ci_green_for_output_claimed"] is False
    assert report["release_ready_claimed"] is False
