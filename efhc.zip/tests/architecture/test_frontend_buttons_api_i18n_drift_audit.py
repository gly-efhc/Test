from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/FRONTEND_BUTTONS_API_I18N_DRIFT_AUDIT.md"
ADMIN_SCOPE = [
    ROOT / "frontend/src/pages/admin",
    ROOT / "frontend/src/features/admin",
    ROOT / "frontend/src/components/admin",
]
ALLOWED_DIRECT_API_IMPORTS = {
    "frontend/src/components/admin/AdminRouteHealthStrip.tsx",
    "frontend/src/components/admin/AdminSystemHealthDashboardRuntime.tsx",
}
ALLOWED_STATIC_HREFS = {
    "/manifest.webmanifest",
    "/tonconnect-manifest.json",
    "/offline.html",
}


def _rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _source_files(*roots: Path) -> list[Path]:
    out: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        out.extend(
            path for path in sorted(root.rglob("*"))
            if path.suffix in {".ts", ".tsx"}
        )
    return out


def test_cycle_1517_audit_doc_exists() -> None:
    text = DOC.read_text(encoding="utf-8")
    assert "Cycle 1517" in text
    assert "Frontend Buttons / API / i18n Drift Audit" in text
    assert "VISUAL_NOT_VERIFIED" in text
    assert "GITHUB_CI_NOT_VERIFIED" in text


def test_admin_runtime_uses_admin_seams_outside_health_widgets() -> None:
    offenders: list[str] = []
    raw_admin_call = re.compile(
        r"apiRequest(?:<[^>]+>)?\s*\(\s*[`\'\"]\s*/admin"
    )
    direct_api_import = re.compile(
        r"from\s+[`\'\"](?:\.\./)+lib/api[`\'\"]"
    )
    for path in _source_files(*ADMIN_SCOPE):
        rel = _rel(path)
        src = path.read_text(encoding="utf-8")
        if raw_admin_call.search(src):
            offenders.append(f"{rel}: raw /admin apiRequest")
        if rel not in ALLOWED_DIRECT_API_IMPORTS and direct_api_import.search(src):
            offenders.append(f"{rel}: direct lib/api import in admin scope")
    assert not offenders, offenders


def test_admin_seam_helpers_are_used_for_admin_feature_mutations() -> None:
    required = {
        "frontend/src/features/admin/AdminHubPage.tsx": [
            "adminApiRequest<HubLink[]>",
            "adminPath(ADMIN_HUB_LINK_UPDATE_PATH",
            "adminPath(ADMIN_HUB_LINK_TOGGLE_PATH",
        ],
        "frontend/src/features/admin/AdminSalePackagesPage.tsx": [
            "adminApiRequest<SalePackagesOut>",
            "adminPath(ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH",
            "adminPath(ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH",
        ],
        "frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx": [
            "adminApiRequest<TransferLogsOut>",
            "ADMIN_LOGS_TRANSFERS_PATH",
        ],
        "frontend/src/components/admin/AdminObservabilityTimeseriesDashboardRuntime.tsx": [
            "adminApiRequest<AdminObservabilitySummaryResponse>",
            "adminApiRequest<AdminObservabilityTimeseriesResponse>",
        ],
    }
    missing: list[str] = []
    for rel, needles in required.items():
        src = (ROOT / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle not in src:
                missing.append(f"{rel}: {needle}")
    assert not missing, missing


def test_frontend_static_internal_hrefs_resolve_to_page_or_asset() -> None:
    page_routes: set[str] = set()
    for path in (ROOT / "frontend/src/pages").rglob("*.tsx"):
        if path.name.startswith("_"):
            continue
        rel = path.relative_to(ROOT / "frontend/src/pages")
        if rel.name == "index.tsx":
            route = "/" if rel.parent.as_posix() == "." else "/" + rel.parent.as_posix()
        else:
            route = "/" + rel.with_suffix("").as_posix()
        route = route.replace("/.", "").replace("//", "/")
        if route != "/" and route.endswith("/"):
            route = route[:-1]
        page_routes.add(route)

    offenders: list[str] = []
    href_re = re.compile(r"href=([\"\'])(.*?)\1|router\.push\(([\"\'])(.*?)\3\)")
    for path in _source_files(ROOT / "frontend/src"):
        src = path.read_text(encoding="utf-8")
        for match in href_re.finditer(src):
            value = match.group(2) or match.group(4) or ""
            if not value.startswith("/"):
                continue
            clean = value.split("?", 1)[0]
            if clean in page_routes or clean in ALLOWED_STATIC_HREFS:
                continue
            if clean.startswith("/api/") or clean.startswith("/assets/"):
                continue
            offenders.append(f"{_rel(path)}:{clean}")
    assert not offenders, offenders


def test_i18n_node_audit_scripts_use_valid_commonjs_dirname() -> None:
    scripts = [
        ROOT / "ops/i18n/audit_locale_placeholders.js",
        ROOT / "ops/i18n/audit_identical_to_english.js",
    ]
    for script in scripts:
        src = script.read_text(encoding="utf-8")
        assert "path.resolve(_dirname" not in src
        assert "path.join(\n  _dirname" not in src
        assert "__dirname" in src
        result = subprocess.run(
            ["node", script.as_posix()],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, result.stdout + result.stderr
