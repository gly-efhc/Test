from __future__ import annotations

import json
from pathlib import Path

from app.models.user_models import User
from scripts.release.validate_migration_path import validate_path
from sqlalchemy import BigInteger

ROOT = Path(__file__).resolve().parents[2]
MIGRATION = ROOT / "backend/migrations/versions/0001_initial_release_schema.py"


def test_release_schema_uses_only_canonical_global_id_column() -> None:
    column = User.__table__.c.global_id
    assert isinstance(column.type, BigInteger)
    assert column.server_default is not None
    assert "user_id" not in User.__table__.c
    assert User.__table__.c.id.primary_key is True
    assert User.__table__.c.tg_id.nullable is True


def test_release_schema_has_explicit_global_id_constraints() -> None:
    names = {
        constraint.name
        for constraint in User.__table__.constraints
        if constraint.name
    }
    assert "uq_users_global_id" in names
    assert "ck_users_global_id_range" in names
    assert "uq_users_telegram" in names


def test_release_migrations_form_cumulative_lineage() -> None:
    versions = sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert versions == [
        "0001_initial_release_schema.py",
    ]
    result = validate_path(
        ROOT / "backend/migrations/versions",
        "0001",
        "0001",
        ["0001"],
    )
    assert result["pending_revisions"] == []


def test_base_revision_creates_final_physical_schema() -> None:
    source = MIGRATION.read_text(encoding="utf-8")
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source
    assert "users.global_id" in source
    assert "users_global_id_seq" in source
    assert "identity_migration_control" in source
    assert "identity_ownership_shadow_telemetry" in source
    assert "users.user_id physical column forbidden" in source


def test_release_policy_is_cutover_preparation() -> None:
    data = json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )
    assert data["supported_database_revisions"] == ["0001"]
    assert data["target_database_revision"] == "0001"
    assert data["database_migration_policy"] == (
        "single_initial_release_schema"
    )
    assert data["database_migration_class"] == (
        "PRE_RELEASE_MIGRATION_SQUASH"
    )
    assert data["database_migration_phase"] == (
        "CANONICAL_BASELINE"
    )
