from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
ROUTES = ROOT / "docs/SSOT/ssot_pack/SSOT_ROUTES.csv"
FREEZE = ROOT / "docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv"
FREEZE_MD = ROOT / "docs/audits/ROUTE_INVENTORY_FREEZE.md"


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def test_route_inventory_freeze_matches_ssot_routes() -> None:
    routes = _read_csv(ROUTES)
    freeze = _read_csv(FREEZE)

    route_keys = {(r["method"], r["path"]) for r in routes}
    freeze_keys = {(r["method"], r["path"]) for r in freeze}

    assert len(freeze) == len(routes)
    assert freeze_keys == route_keys


def test_route_inventory_freeze_required_columns_present() -> None:
    freeze = _read_csv(FREEZE)
    expected = {
        "method",
        "path",
        "file",
        "router_module",
        "prefix",
        "service_refs",
        "auth_type",
    }

    assert freeze
    assert set(freeze[0]) == expected
    for row in freeze:
        for key in expected:
            assert row[key].strip()


def test_route_inventory_freeze_markdown_count_sync() -> None:
    freeze = _read_csv(FREEZE)
    text = FREEZE_MD.read_text(encoding="utf-8")
    assert f"- Active routes in freeze: {len(freeze)}" in text
