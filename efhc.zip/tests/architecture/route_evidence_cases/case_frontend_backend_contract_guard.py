from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SCRIPT = (
    ROOT / "ops" / "routes" / ("check_frontend_backend_contracts.py")
)


def _load_module():
    spec = importlib.util.spec_from_file_location(
        "contract_guard_1183",
        SCRIPT,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_sensitive_frontend_seams_have_backend_routes() -> None:
    module = _load_module()
    data = module.build()
    assert data["missing_count"] == 0
    assert data["method_drift_count"] == 0
