from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
INVENTORY = (
    ROOT / "reports/generated/frontend_visible_functions_inventory.json"
)
AUDIT = ROOT / "docs/audits/FRONTEND_VISIBLE_FUNCTIONS_AUDIT.md"
PLAN = ROOT / "docs/cycles/WORK_CYCLES_1209-1230_DETAILED_PLAN.md"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_visible_function_inventory_exists() -> None:
    data = json.loads(INVENTORY.read_text(encoding="utf-8"))

    assert data["cycle"] == 1209
    assert data["scope"] == "static visible frontend function inventory"
    assert data["public_pages"]
    assert data["button_like_entries_count"] > 50
    assert data["button_like_entries_by_segment"]["public"] > 0


def test_bottom_navigation_canon_is_unchanged() -> None:
    data = json.loads(INVENTORY.read_text(encoding="utf-8"))
    nav = data["canon_bottom_navigation"]

    assert [item["label"] for item in nav] == [
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
    ]
    assert [item["route"] for item in nav] == [
        "/",
        "/panels",
        "/exchange",
        "/tasks",
        "/referrals",
        "/ranks",
    ]

    layout = _read(LAYOUT)
    for label in ["Energy", "Panels", "Exchange"]:
        assert f'visualLabel: "{label}"' in layout
    assert 'href: "/admin"' not in layout


def test_audit_has_user_function_triage_model() -> None:
    text = _read(AUDIT)

    assert "оставить" in text
    assert "удалить" in text
    assert "перенести в админку" in text
    assert "вынести на вопрос" in text
    assert "не менять шесть нижних кнопок" in text


def test_plan_preserves_canon_pages_and_dragon_visual_only() -> None:
    text = _read(PLAN)

    assert "Energy remains canonical" in text
    assert "Dragon style is visual only" in text
    assert "Browser shell" in text
    assert "visible function audit" in text
