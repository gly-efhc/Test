import re
from pathlib import Path


def test_route_modules_do_not_embed_api_prefix() -> None:
    root = Path(__file__).resolve().parents[3]
    routes_dir = root / "backend" / "app" / "routes"
    bad: list[str] = []

    prefix_re = re.compile(r"prefix\s*=\s*[\"'](/api[^\"']*)[\"']")
    path_re = re.compile(
        r"@router\.(?:get|post|put|patch|delete)\(\s*[\"']"
        r"(/api[^\"']*)[\"']"
    )

    for path in sorted(routes_dir.rglob("*.py")):
        if path.name == "init.py":
            continue
        txt = path.read_text(encoding="utf-8")
        prefixes = prefix_re.findall(txt)
        paths = path_re.findall(txt)
        hits = prefixes + paths
        if hits:
            rel = path.relative_to(root)
            bad.append(f"{rel}: {', '.join(hits)}")

    assert not bad, (
        "Route modules must not embed API_PREFIX in local "
        "prefixes/paths: " + "; ".join(bad)
    )
