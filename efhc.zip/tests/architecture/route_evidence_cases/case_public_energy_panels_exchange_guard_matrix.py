from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DOC = ROOT / "docs/frontend/PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md"
REPORT = (
    ROOT
    / "reports/generated/"
    / "public_energy_panels_exchange_guard_matrix_v169_76.json"
)
GUARD = (
    "tests/architecture/"
    "test_public_energy_panels_exchange_guard_matrix.py"
)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1394_guard_artifacts_exist() -> None:
    assert DOC.exists()
    assert REPORT.exists()
    doc = DOC.read_text(encoding="utf-8")
    assert "ACTIVE STATIC GUARD MATRIX" in doc
    assert "Energy, Panels and Exchange" in doc
    assert "does not claim" in doc


def test_generated_matrix_covers_public_triad_without_false_claims() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["archive_target"] == "v169.76"
    assert data["cycle"] == 1394
    assert data["status"] == "ACTIVE_STATIC_GUARD_MATRIX"
    assert data["guard"] == GUARD
    assert data["no_screenshot_claim"] is True
    assert data["github_ci_green_claimed"] is False
    assert data["full_local_pytest_green_claimed"] is False
    assert data["release_ready_claimed"] is False
    assert data["sandbox_runtime_imported"] is False
    assert data["economics_changed"] is False
    routes = {item["route"] for item in data["surfaces"]}
    assert routes == {"/", "/panels", "/exchange"}


def test_energy_route_component_and_public_boundary_chain() -> None:
    page = read("frontend/src/pages/index.tsx")
    component = read(
        "frontend/src/components/energy/EnergyMvpSummary.tsx"
    )
    legacy = read(
        "frontend/src/components/public/"
        "PublicEnergyInteractiveOverview.tsx"
    )
    doc = DOC.read_text(encoding="utf-8")
    assert "EnergyMvpSummary" not in page
    assert "PublicEnergyInteractiveOverview" not in page
    assert 'data-energy-chip-count="3"' in page
    assert 'data-energy-level-name={levelName}' in page
    assert 'data-energy-mobile-proof="390px"' in page
    assert 'data-public-energy-interactive-cycle="1347"' in legacy
    assert "components/admin" not in component
    assert "AdminRouteHealthStrip" not in page
    assert "Energy | `/`" in doc


def test_panels_route_component_backend_and_money_chain() -> None:
    page = read("frontend/src/pages/panels.tsx")
    service_ts = read("frontend/src/services/panels.service.ts")
    mapping = read(
        "docs/frontend/"
        "FRONTEND_PANELS_EXCHANGE_MVP_REPLACEMENT_MAPPING.md"
    )
    route = read("backend/app/routes/panels_routes.py")
    service = read("backend/app/services/panels_service.py")
    assert "PublicPanelsActivationPreview" not in page
    assert "PanelsPortfolioRuntime" not in page
    assert 'data-panels-mvp-activation="cycle-1556"' in page
    assert 'data-panel-activation-cta="100-efhc"' in page
    assert '"/panels/active"' in page
    assert '"/panels/archive"' in page
    assert "PANELS_ACTIVATE_PATH" in service_ts
    assert "apiRequest" not in page
    assert "newIdempotencyKey" in page
    assert "idempotencyKey" in service_ts
    assert 'data-panel-activation-debit="bonus-first-main-second"' in page
    assert '"/activate"' in route
    assert "Depends(require_idempotency_key)" in route
    assert "PANEL_PRICE" in service
    assert 'd8("100")' in service
    assert "bonus" in service.lower()
    assert "main" in service.lower()
    assert "DELETE_AFTER_REPLACEMENT" in mapping


def test_exchange_route_component_backend_and_economy_chain() -> None:
    page = read("frontend/src/pages/exchange.tsx")
    service_ts = read("frontend/src/services/exchange.service.ts")
    mapping = read(
        "docs/frontend/"
        "FRONTEND_PANELS_EXCHANGE_MVP_REPLACEMENT_MAPPING.md"
    )
    seams = read("frontend/src/lib/api/generated/economicUserSeams.ts")
    route = read("backend/app/routes/exchange_routes.py")
    assert "PublicExchangeInteractivePreview" not in page
    assert "ExchangeDashboardRuntime" not in page
    assert page.count("<ExchangePanel") == 1
    assert "EXCHANGE_PREVIEW_PATH" in service_ts
    assert "EXCHANGE_CONVERT_PATH" in service_ts
    assert "WITHDRAW_REQUEST_PATH" not in page
    assert "newIdempotencyKey" in page
    assert "idempotencyKey" in service_ts
    assert "confirm(" in page
    assert 'data-exchange-runtime-proof="1556-react-query-transaction"' in page
    assert '"/exchange/preview"' in seams
    assert '"/exchange/convert"' in seams
    assert '"/preview"' in route
    assert '"/convert"' in route
    assert "Depends(require_idempotency_key)" in route
    assert "svc_exchange_kwh_to_efhc" in route
    assert "INACTIVE_LEGACY_REFERENCE" in mapping

def test_cycle_1394_guard_is_registered_in_control_documents() -> None:
    manifest = json.loads(
        read("docs/testing/TEST_GUARD_MANIFEST.json")
    )
    docs_manifest = read("docs/testing/TEST_GUARD_MANIFEST.md")
    cycles = read("docs/cycles/WORK_CYCLES.md")
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1390-1400_CI_LOG_REPAIR_AND_TEST_HEALING_PLAN.md"
    )
    index = read("docs/AI/AI_DOCS_INDEX.md")
    assert manifest["cycle_1394_public_guard_matrix"]["guard"] == GUARD
    assert "Cycle 1394 public triad guard matrix" in docs_manifest
    assert "1394 — Public Energy / Panels / Exchange guard matrix" in cycles
    assert "1394 | Public Energy, Panels, Exchange" in plan
    assert "PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md" in index
