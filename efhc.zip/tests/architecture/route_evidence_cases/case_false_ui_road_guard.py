from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def test_false_ui_road_guard_1193() -> None:
    script = ROOT / "ops/routes/check_false_ui_road.py"
    result = subprocess.run(
        [sys.executable, "-S", str(script)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
