import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DOC = ROOT / "docs/admin/ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX.md"
AUDIT = ROOT / "docs/audits/ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX_AUDIT_V169_77.md"
REPORT = ROOT / "reports/generated/admin_visible_functions_guard_matrix_v169_77.json"
ADMIN_DOCS_MAP = ROOT / "docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md"
ADMIN_ROUTES_MAP = ROOT / "docs/admin/ADMIN_ROUTES_MAP.md"

REQUIRED_SURFACES = {
    "/admin",
    "/admin/bank",
    "/admin/users",
    "/admin/withdrawals",
    "/admin/shop",
    "/admin/tasks",
    "/admin/reports",
    "/admin/diagnostics",
    "/admin/system",
    "/admin/logs",
    "/admin/panels",
    "/admin/referrals",
    "/admin/ads",
    "/admin/templates",
    "/admin/hub",
    "/admin/sale-packages",
    "/admin/efhc-deposits",
}


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_admin_visible_functions_matrix_lists_all_admin_surfaces() -> None:
    assert DOC.exists()
    assert AUDIT.exists()
    data = json.loads(read(REPORT))
    got = {item["surface"] for item in data["surfaces"]}
    assert got == REQUIRED_SURFACES
    assert data["surfaces_count"] == len(REQUIRED_SURFACES)
    text = read(DOC)
    for surface in REQUIRED_SURFACES:
        assert f"`{surface}`" in text


def test_admin_visible_functions_have_backend_roads_and_guards() -> None:
    data = json.loads(read(REPORT))
    for item in data["surfaces"]:
        assert item["visible_functions"], item["surface"]
        assert item["backend_roads"], item["surface"]
        assert item["guard_files"], item["surface"]
        for guard in item["guard_files"]:
            assert (ROOT / guard).exists(), guard


def test_admin_matrix_cross_links_existing_route_maps() -> None:
    docs_map = read(ADMIN_DOCS_MAP)
    routes_map = read(ADMIN_ROUTES_MAP)
    matrix = read(DOC)
    for surface in REQUIRED_SURFACES:
        assert surface in docs_map or surface in routes_map
        assert surface in matrix
    assert "GET /admin/reports/overview" in matrix
    assert "POST /admin/bank/mint" in matrix
    assert "GET /admin/hub/links" in matrix
    assert "POST /admin/sale-packages" in matrix


def test_admin_matrix_preserves_sandbox_reference_boundary() -> None:
    data = json.loads(read(REPORT))
    assert data["sandbox_intake"]["boundary"] == "reference_only_no_runtime_copy"
    text = read(DOC) + read(AUDIT)
    forbidden = [
        "copied into EFHC runtime",
        "donor runtime",
        "foreign lock file",
        "CI file",
        "wallet/payment logic",
    ]
    for marker in forbidden:
        assert marker in text
