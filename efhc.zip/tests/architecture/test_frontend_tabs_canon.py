from __future__ import annotations

import re
from pathlib import Path


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_frontend_tabs_are_exactly_six_in_canon_order() -> None:
    """Canon: 6 tabs, fixed order.

    We enforce this at repo-level so UI cannot drift.
    """

    layout = Path("frontend/src/components/Layout.tsx")
    assert layout.exists(), "Layout.tsx missing"
    txt = _read_text(layout)

    m = re.search(
        r"const\s+bottom\s*=\s*\[(?P<body>.*?)\]\s*;",
        txt,
        flags=re.S,
    )
    assert m, "bottom tabs array not found"
    body = m.group("body")

    hrefs = re.findall(r"href:\s*\"([^\"]+)\"", body)
    keys = re.findall(r"key:\s*\"([^\"]+)\"", body)

    assert hrefs == [
        "/",
        "/panels",
        "/exchange",
        "/tasks",
        "/referrals",
        "/ranks",
    ], hrefs
    assert keys == [
        "nav.energy",
        "nav.panels",
        "nav.exchange",
        "nav.tasks",
        "nav.referrals",
        "nav.ranks",
    ], keys


def test_settings_and_profile_never_enter_bottom_game_navigation() -> None:
    """Settings/Profile are account controls, not game-loop navigation."""

    layout = _read_text(Path("frontend/src/components/Layout.tsx"))
    match = re.search(
        r"const\s+bottom\s*=\s*\[(?P<body>.*?)\]\s*;",
        layout,
        flags=re.S,
    )
    assert match, "bottom tabs array not found"
    body = match.group("body")

    for forbidden in (
        'href: "/web-profile"',
        'href: "/settings"',
        'key: "nav.profile"',
        'key: "nav.settings"',
        'visualLabel: "Profile"',
        'visualLabel: "Settings"',
    ):
        assert forbidden not in body, forbidden


def test_settings_entry_is_strictly_inside_profile_surface() -> None:
    """The full settings modal may be opened only from WebProfile/Profile."""

    frontend = Path("frontend/src")
    importers: list[str] = []
    for path in frontend.rglob("*.tsx"):
        if path.name == "ProfileModal.tsx":
            continue
        text = _read_text(path)
        if "ProfileModal" in text:
            importers.append(path.as_posix())

    assert importers == [
        "frontend/src/features/profile/WebProfilePage.tsx"
    ], importers

    profile = _read_text(
        Path("frontend/src/features/profile/WebProfilePage.tsx")
    )
    assert 'activeTab === "profile"' in profile
    assert 'data-profile-settings-entry="profile-modal"' in profile
    assert 'className="efhc-profile-settings-button"' in profile
    assert 'aria-label={t("profile.settings_title")}' in profile
    assert "setSettingsOpen(true)" in profile
    assert '{t("profile.modal_title")}' not in profile

