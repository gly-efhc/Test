from __future__ import annotations

import re
from pathlib import Path


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_frontend_tabs_are_exactly_six_in_canon_order() -> None:
    """Canon: 6 tabs, fixed order.

    We enforce this at repo-level so UI cannot drift.
    """

    layout = Path("frontend/src/components/Layout.tsx")
    assert layout.exists(), "Layout.tsx missing"
    txt = _read_text(layout)

    m = re.search(
        r"const\s+bottom\s*=\s*\[(?P<body>.*?)\]\s*;",
        txt,
        flags=re.S,
    )
    assert m, "bottom tabs array not found"
    body = m.group("body")

    hrefs = re.findall(r"href:\s*\"([^\"]+)\"", body)
    keys = re.findall(r"key:\s*\"([^\"]+)\"", body)

    assert hrefs == [
        "/",
        "/panels",
        "/exchange",
        "/tasks",
        "/referrals",
        "/ranks",
    ], hrefs
    assert keys == [
        "nav.energy",
        "nav.panels",
        "nav.exchange",
        "nav.tasks",
        "nav.referrals",
        "nav.ranks",
    ], keys
