from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = (
    ROOT
    / "reports"
    / "generated"
    / "kernel_map_compaction_test_consolidation_v171_03.json"
)


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def test_current_head_anchors_are_compact_and_current() -> None:
    kernel = read("KERNEL.md")
    mapping = read("map_element.md")
    assert "Canonical archive lineage:" in kernel
    assert "v171_03" in mapping
    assert "compaction" in kernel
    assert "cycle 1528" in mapping
    forbidden = "v171" + "_100"
    assert forbidden not in kernel
    assert forbidden not in mapping


def test_compaction_docs_and_reports_are_linked() -> None:
    mapping = read("map_element.md")
    reports = read("reports/REPORTS_INDEX.md")
    docs = (
        "docs/NORM/KERNEL_MAP_ELEMENT_COMPACTION_PASS.md",
        "docs/NORM/TEST_GUARD_CONSOLIDATION_EXECUTION.md",
        "docs/cycles/WORK_CYCLES_1528_KERNEL_MAP_COMPACTION_TEST_CONSOLIDATION.md",
        "reports/generated/kernel_map_compaction_test_consolidation_v171_03.json",
    )
    for doc in docs:
        assert doc in mapping
        assert doc in reports or doc.endswith(".json")


def test_chat_docs_consolidation_preserves_mapping() -> None:
    doc = read("docs/NORM/TEST_GUARD_CONSOLIDATION_EXECUTION.md")
    manifest = read("docs/testing/TEST_GUARD_MANIFEST.md")
    target = "tests/architecture/test_chat_docs_intake.py"
    for old in (
        "tests/architecture/test_chat_24_archive_intake.py",
        "tests/architecture/test_chat_25_archive_intake.py",
    ):
        assert old in doc
        assert old in manifest
        assert not (ROOT / old).exists()
    assert target in doc
    assert target in manifest


def test_cycle_1528_report_is_fail_closed() -> None:
    data = json.loads(REPORT.read_text(encoding="utf-8"))
    assert data["cycle"] == 1528
    assert data["version"] == "v171.03"
    assert data["logs_zip_provided"] is False
    assert data["github_ci_green_claimed"] is False
    assert data["release_ready_claimed"] is False
    assert data["runtime_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["tests_skipped"] is False
    assert data["tests_xfailed"] is False
    assert data["high_risk_guards_merged"] is False


def test_candidate_doc_marks_only_group_one_executed() -> None:
    doc = read("docs/NORM/TEST_GUARD_CONSOLIDATION_CANDIDATES.md")
    assert "Chat docs intake guards — EXECUTED IN CYCLE 1528" in doc
    assert "Groups 2–10 remain proposal-only" in doc
    assert "high-risk" in doc or "High-risk" in doc
