from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LANGS = [
    "en",
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]


def test_reaudit_artifacts_and_manual_plan_exist() -> None:
    required = [
        "docs/audits/I18N_REAUDIT_REPORT_V169_54_2026_06_03.md",
        "docs/frontend/I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md",
        (
            "docs/cycles/"
            "WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md"
        ),
        "reports/generated/i18n_reaudit_intake_v169_55.json",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_formula_is_allowed_as_formula_not_translation_gap() -> None:
    allow = json.loads(
        (
            ROOT / "ops/i18n/identical_to_english_allowlist.json"
        ).read_text(encoding="utf-8")
    )
    assert "1 kWh = 1 EFHC" in allow["exact_values"]


def test_two_task_keys_no_longer_use_game_framing() -> None:
    for lang in LANGS:
        data = json.loads(
            (
                ROOT / "frontend/public/locale" / f"{lang}.json"
            ).read_text(encoding="utf-8")
        )
        for key in ("tasks.earning_kicker", "tasks.demo_daily_detail"):
            value = data[key]
            assert "game" not in value.lower(), (lang, key, value)
            assert "игр" not in value.lower(), (lang, key, value)
            assert "ігров" not in value.lower(), (lang, key, value)


def test_audit_precondition_reports_exist_with_required_markers() -> (
    None
):
    hardcoded = (
        ROOT / "docs/audits/FRONTEND_HARDCODED_STRINGS.md"
    ).read_text(encoding="utf-8")
    for marker in (
        "work pass",
        "admin/operator",
        "player-facing",
        "false positives",
    ):
        assert marker in hardcoded
    inventory = (
        ROOT / "docs/audits/LOCALIZATION_NOTIFICATIONS_AND_TEMPLATES.md"
    ).read_text(encoding="utf-8")
    for rel in (
        "backend/app/services/admin/admin_notifications.py",
        "backend/app/services/shop_order_notifications_service.py",
        "backend/app/models/system_templates_models.py",
        "backend/app/routes/admin_templates_routes.py",
        "backend/app/services/admin/admin_templates_service.py",
        "backend/app/services/outcome_service.py",
        "backend/app/services/tasks_service.py",
        "frontend/src/pages/admin/templates.tsx",
    ):
        assert rel in inventory


def test_generated_report_keeps_non_claims() -> None:
    report = json.loads(
        (
            ROOT / "reports/generated/i18n_reaudit_intake_v169_55.json"
        ).read_text(encoding="utf-8")
    )
    assert report["cycle"] == 1376
    assert (
        report["residuals"]["translation_completion_claimed"] is False
    )
    assert "manual" in report["manual_translation_rule"].lower()
    assert "release-ready" in report["non_claims"]
