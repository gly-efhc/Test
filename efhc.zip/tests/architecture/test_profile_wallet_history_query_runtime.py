from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_profile_service_has_typed_contracts() -> None:
    s = read("frontend/src/services/profile.service.ts")
    for token in (
        "walletsMeSchema",
        "balanceHistoryPageSchema",
        "withdrawHistoryPageSchema",
        "getProfileWallets",
        "getProfileBalanceHistoryPage",
        "getProfileWithdrawHistoryPage",
    ):
        assert token in s


def test_profile_query_layer_is_active() -> None:
    page = read("frontend/src/features/profile/WebProfilePage.tsx")
    hooks = read("frontend/src/queries/useProfile.ts")
    assert "useProfileBalanceHistory" in page
    assert "useProfileWithdrawHistory" in page
    assert "fetchNextPage" in page
    assert "setHistoryItems(" not in page
    assert "useInfiniteQuery" in hooks
