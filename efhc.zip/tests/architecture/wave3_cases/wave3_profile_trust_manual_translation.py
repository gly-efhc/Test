from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
ALLOWLIST = (
    ROOT / "ops" / "i18n" / "identical_to_english_allowlist.json"
)
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)
PREFIXES = ("profile.", "public_profile_trust.")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")

EXPECTED_SAMPLE = {
    "de": {
        "profile.connect_wallet": "Wallet verbinden",
        "profile.history_clean_title": "Verlauf",
        "public_profile_trust.note_profile": (
            "Diese Ebene dient als klare Kontoübersicht. Detaillierte "
            "Einstellungen bleiben darunter."
        ),
    },
    "fr": {
        "profile.connect_wallet": "Connecter le portefeuille",
        "profile.history_clean_title": "Historique",
        "public_profile_trust.note_profile": (
            "Utilisez cette couche comme résumé clair du compte. Les "
            "paramètres détaillés restent en dessous."
        ),
    },
    "hi": {
        "profile.connect_wallet": "वॉलेट कनेक्ट करें",
        "profile.history_clean_title": "इतिहास",
        "public_profile_trust.note_profile": (
            "इस परत को साफ़ खाता सारांश के रूप में उपयोग करें। विस्तृत "
            "सेटिंग्स नीचे रहती हैं।"
        ),
    },
    "sw": {
        "profile.connect_wallet": "Unganisha pochi",
        "profile.history_clean_title": "Historia",
        "public_profile_trust.note_profile": (
            "Tumia safu hii kama muhtasari safi wa akaunti. Mipangilio "
            "ya kina inabaki chini."
        ),
    },
    "tr": {
        "profile.connect_wallet": "Cüzdanı bağla",
        "profile.history_clean_title": "Geçmiş",
        "public_profile_trust.note_profile": (
            "Bu katmanı temiz bir hesap özeti olarak kullanın. "
            "Ayrıntılı ayarlar aşağıda kalır."
        ),
    },
    "pl": {
        "profile.connect_wallet": "Połącz portfel",
        "profile.history_clean_title": "Historia",
        "public_profile_trust.note_profile": (
            "Używaj tej warstwy jako przejrzystego podsumowania konta. "
            "Szczegółowe ustawienia pozostają niżej."
        ),
    },
    "da": {
        "profile.connect_wallet": "Tilslut wallet",
        "profile.history_clean_title": "Historik",
        "public_profile_trust.note_profile": (
            "Brug dette lag som et rent kontooverblik. Detaljerede "
            "indstillinger bliver nedenunder."
        ),
    },
    "it": {
        "profile.connect_wallet": "Collega portafoglio",
        "profile.history_clean_title": "Cronologia",
        "public_profile_trust.note_profile": (
            "Usa questo livello come riepilogo pulito dell’account. Le "
            "impostazioni dettagliate restano sotto."
        ),
    },
    "es": {
        "profile.connect_wallet": "Conectar billetera",
        "profile.history_clean_title": "Historial",
        "public_profile_trust.note_profile": (
            "Usa esta capa como un resumen limpio de la cuenta. Los "
            "ajustes detallados permanecen abajo."
        ),
    },
    "id": {
        "profile.connect_wallet": "Hubungkan dompet",
        "profile.history_clean_title": "Riwayat",
        "public_profile_trust.note_profile": (
            "Gunakan lapisan ini sebagai ringkasan akun yang bersih. "
            "Pengaturan detail tetap berada di bawah."
        ),
    },
}


def _flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(_flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def _load(lang: str) -> dict[str, str]:
    return _flatten(
        json.loads(
            (LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8")
        )
    )


def _allowlist() -> tuple[set[str], tuple[str, ...]]:
    payload = json.loads(ALLOWLIST.read_text(encoding="utf-8"))
    return set(payload.get("exact_values", [])), tuple(
        payload.get("key_prefixes", [])
    )


def _in_scope(key: str) -> bool:
    return any(key.startswith(prefix) for prefix in PREFIXES)


def _profile_keys() -> list[str]:
    en = _load("en")
    allowed_exact, allowed_prefixes = _allowlist()
    return sorted(
        key
        for key, value in en.items()
        if _in_scope(key)
        and value not in allowed_exact
        and not any(
            key.startswith(prefix) for prefix in allowed_prefixes
        )
    )


def test_cycle_1380_wave3_profile_trust_samples_are_manual() -> None:
    en = _load("en")
    for lang, expected_values in EXPECTED_SAMPLE.items():
        locale = _load(lang)
        for key, expected in expected_values.items():
            assert locale[key] == expected, (lang, key)
            assert locale[key] != en[key], (lang, key)


def test_cycle_1380_wave3_profile_trust_has_no_unexpected_english_identical_values() -> (
    None
):
    en = _load("en")
    profile_keys = _profile_keys()
    assert len(profile_keys) >= 152
    for lang in WAVE3_LANGS:
        locale = _load(lang)
        identical = [
            key for key in profile_keys if locale[key] == en[key]
        ]
        assert identical == [], (lang, identical)


def test_cycle_1380_wave3_profile_trust_has_no_cyrillic_tails() -> None:
    profile_keys = _profile_keys()
    for lang in WAVE3_LANGS:
        locale = _load(lang)
        tails = [
            key
            for key in profile_keys
            if CYRILLIC_RE.search(locale[key])
        ]
        assert tails == [], (lang, tails)


def test_cycle_1380_wave3_profile_trust_audit_script_passes() -> None:
    result = subprocess.run(
        [
            sys.executable,
            "ops/i18n/audit_wave3_profile_trust_locale_quality.py",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "Unexpected English-identical values: 0" in result.stdout
    assert "Cyrillic tails: 0" in result.stdout
