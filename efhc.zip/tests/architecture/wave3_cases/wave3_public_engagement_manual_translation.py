from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)
PREFIX = "public_engagement."
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")

EXPECTED_SAMPLE = {
    "de": {
        "public_engagement.ranks.cta": "Mich in der Rangliste anzeigen",
        "public_engagement.referrals.cta": "Einladungslink kopieren",
        "public_engagement.tasks.title": "Verdienen und zur Energie zurückkehren",
    },
    "fr": {
        "public_engagement.ranks.cta": "Me montrer dans le classement",
        "public_engagement.referrals.cta": "Copier le lien d’invitation",
        "public_engagement.tasks.title": "Gagner puis revenir à l’énergie",
    },
    "hi": {
        "public_engagement.ranks.cta": "मुझे रेटिंग में दिखाएँ",
        "public_engagement.referrals.cta": "आमंत्रण लिंक कॉपी करें",
        "public_engagement.tasks.title": "कमाएँ और ऊर्जा पर लौटें",
    },
    "sw": {
        "public_engagement.ranks.cta": "Nionyeshe kwenye viwango",
        "public_engagement.referrals.cta": "Nakili kiungo cha mwaliko",
        "public_engagement.tasks.title": "Pata mapato na urudi kwenye nishati",
    },
    "tr": {
        "public_engagement.ranks.cta": "Beni sıralamada göster",
        "public_engagement.referrals.cta": "Davet bağlantısını kopyala",
        "public_engagement.tasks.title": "Kazan ve enerjiye dön",
    },
    "pl": {
        "public_engagement.ranks.cta": "Pokaż mnie w rankingu",
        "public_engagement.referrals.cta": "Kopiuj link zaproszenia",
        "public_engagement.tasks.title": "Zarabiaj i wróć do energii",
    },
    "da": {
        "public_engagement.ranks.cta": "Vis mig i ranglisten",
        "public_engagement.referrals.cta": "Kopiér invitationslink",
        "public_engagement.tasks.title": "Tjen og vend tilbage til energi",
    },
    "it": {
        "public_engagement.ranks.cta": "Mostrami nella classifica",
        "public_engagement.referrals.cta": "Copia link di invito",
        "public_engagement.tasks.title": "Guadagna e torna all’energia",
    },
    "es": {
        "public_engagement.ranks.cta": "Mostrarme en la clasificación",
        "public_engagement.referrals.cta": "Copiar enlace de invitación",
        "public_engagement.tasks.title": "Gana y vuelve a la energía",
    },
    "id": {
        "public_engagement.ranks.cta": "Tampilkan saya di peringkat",
        "public_engagement.referrals.cta": "Salin tautan undangan",
        "public_engagement.tasks.title": "Dapatkan dan kembali ke energi",
    },
}


def _flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(_flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def _load(lang: str) -> dict[str, str]:
    return _flatten(
        json.loads(
            (LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8")
        )
    )


def test_cycle_1378_wave3_public_engagement_samples_are_manual() -> (
    None
):
    en = _load("en")
    for lang, expected_values in EXPECTED_SAMPLE.items():
        locale = _load(lang)
        for key, expected in expected_values.items():
            assert locale[key] == expected, (lang, key)
            assert locale[key] != en[key], (lang, key)


def test_cycle_1378_wave3_public_engagement_has_no_english_identical_values() -> (
    None
):
    en = _load("en")
    public_keys = sorted(key for key in en if key.startswith(PREFIX))
    assert len(public_keys) == 43
    for lang in WAVE3_LANGS:
        locale = _load(lang)
        identical = [
            key for key in public_keys if locale[key] == en[key]
        ]
        assert identical == [], (lang, identical)


def test_cycle_1378_wave3_public_engagement_has_no_cyrillic_tails() -> (
    None
):
    public_keys = sorted(
        key for key in _load("en") if key.startswith(PREFIX)
    )
    for lang in WAVE3_LANGS:
        locale = _load(lang)
        tails = [
            key
            for key in public_keys
            if CYRILLIC_RE.search(locale[key])
        ]
        assert tails == [], (lang, tails)


def test_cycle_1378_wave3_public_engagement_audit_script_passes() -> (
    None
):
    result = subprocess.run(
        [
            sys.executable,
            "ops/i18n/audit_wave3_public_engagement_locale_quality.py",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "English-identical values: 0" in result.stdout
    assert "Cyrillic tails: 0" in result.stdout
