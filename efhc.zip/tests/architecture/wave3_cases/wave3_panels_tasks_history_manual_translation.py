from __future__ import annotations

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def test_wave3_panels_tasks_history_guard_passes() -> None:
    result = subprocess.run(
        [
            "python3",
            (
                "ops/i18n/audit_wave3_panels_tasks_history_locale_"
                "quality.py"
            ),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "Unexpected English-identical values: 0" in result.stdout
    assert "Cyrillic tails: 0" in result.stdout


def test_cycle_1381_documents_are_indexed() -> None:
    expected = [
        "docs/frontend/I18N_WAVE3_PANELS_TASKS_HISTORY_MANUAL_PASS.md",
        "docs/audits/I18N_WAVE3_PANELS_TASKS_HISTORY_AUDIT_V169_61.md",
        "ops/i18n/audit_wave3_panels_tasks_history_locale_quality.py",
    ]
    for rel_path in expected:
        assert (ROOT / rel_path).exists(), rel_path

    cycles = (ROOT / "docs/cycles/WORK_CYCLES.md").read_text(
        encoding="utf-8"
    )
    assert "v169_61 / cycle 1381" in cycles
    assert "Next planned cycle: `1382" in cycles

    plan = (
        ROOT
        / "docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md"
    ).read_text(encoding="utf-8")
    assert (
        "Cycle 1381 — wave-3 panels/tasks/"
        "history manual translation pass"
        in plan
    )
    assert "Status: DONE in v169.61" in plan


def test_cycle_1381_generated_evidence_is_consistent() -> None:
    payload_path = (
        ROOT
        / "reports/generated/wave3_panels_tasks_history_manual_translation_v169_61.json"
    )
    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    assert payload["cycle"] == 1381
    assert payload["version"] == "v169.61"
    assert payload["domains"] == ["panels", "tasks", "history"]
    assert payload["wave3_languages"] == [
        "de",
        "fr",
        "hi",
        "sw",
        "tr",
        "pl",
        "da",
        "it",
        "es",
        "id",
    ]
    assert payload["guarded_domain_keys"] == 133
    assert payload["unexpected_english_identical_values"] == 0
    assert payload["cyrillic_tails"] == 0
