from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
ALLOWLIST = (
    ROOT / "ops" / "i18n" / "identical_to_english_allowlist.json"
)
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)
PREFIXES = ("portal.browser_shop.", "portal.shop_entry.")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")

EXPECTED_SAMPLE = {
    "de": {
        "portal.browser_shop.clean_subtitle": (
            "Wähle ein EFHC-"
            "Paket und drücke Bezahlen. Die Wallet öffnet sich mit "
            "einer vorbereiteten Zahlung."
        ),
        "portal.browser_shop.payment_checking_title": "Zahlung wird geprüft",
        "portal.shop_entry.flow_title": "So funktioniert der Einstieg",
    },
    "fr": {
        "portal.browser_shop.clean_subtitle": (
            "Choisissez un forfait EFHC et appuyez sur Payer. Le "
            "portefeuille s’ouvrira avec un paiement déjà préparé."
        ),
        "portal.browser_shop.payment_checking_title": "Le paiement est en cours de vérification",
        "portal.shop_entry.flow_title": "Fonctionnement de l’entrée",
    },
    "hi": {
        "portal.browser_shop.clean_subtitle": (
            "EFHC पैकेज चुनें और भुगतान दबाएँ। वॉलेट पहले से तैयार "
            "भुगतान के साथ खुलेगा।"
        ),
        "portal.browser_shop.payment_checking_title": "भुगतान जाँचा जा रहा है",
        "portal.shop_entry.flow_title": "प्रवेश कैसे काम करता है",
    },
    "sw": {
        "portal.browser_shop.clean_subtitle": (
            "Chagua kifurushi cha EFHC na ubonyeze Lipa. Wallet "
            "itafunguka ikiwa na malipo yaliyotayarishwa."
        ),
        "portal.browser_shop.payment_checking_title": "Malipo yanakaguliwa",
        "portal.shop_entry.flow_title": "Jinsi kuingia kunavyofanya kazi",
    },
    "tr": {
        "portal.browser_shop.clean_subtitle": (
            "Bir EFHC paketi seç ve Öde’ye bas. Cüzdan hazırlanmış "
            "ödeme ile açılır."
        ),
        "portal.browser_shop.payment_checking_title": "Ödeme kontrol ediliyor",
        "portal.shop_entry.flow_title": "Giriş nasıl çalışır",
    },
    "pl": {
        "portal.browser_shop.clean_subtitle": (
            "Wybierz pakiet EFHC i naciśnij Zapłać. Portfel otworzy "
            "się z przygotowaną płatnością."
        ),
        "portal.browser_shop.payment_checking_title": "Płatność jest sprawdzana",
        "portal.shop_entry.flow_title": "Jak działa wejście",
    },
    "da": {
        "portal.browser_shop.clean_subtitle": (
            "Vælg en EFHC-"
            "pakke, og tryk Betal. Walleten åbnes med en forberedt "
            "betaling."
        ),
        "portal.browser_shop.payment_checking_title": "Betalingen kontrolleres",
        "portal.shop_entry.flow_title": "Sådan fungerer indgangen",
    },
    "it": {
        "portal.browser_shop.clean_subtitle": (
            "Scegli un pacchetto EFHC e premi Paga. Il wallet si "
            "aprirà con il pagamento già preparato."
        ),
        "portal.browser_shop.payment_checking_title": "Il pagamento è in verifica",
        "portal.shop_entry.flow_title": "Come funziona l’ingresso",
    },
    "es": {
        "portal.browser_shop.clean_subtitle": (
            "Elige un paquete EFHC y pulsa Pagar. La billetera se "
            "abrirá con un pago preparado."
        ),
        "portal.browser_shop.payment_checking_title": "El pago se está verificando",
        "portal.shop_entry.flow_title": "Cómo funciona la entrada",
    },
    "id": {
        "portal.browser_shop.clean_subtitle": (
            "Pilih paket EFHC dan tekan Bayar. Wallet akan terbuka "
            "dengan pembayaran yang sudah disiapkan."
        ),
        "portal.browser_shop.payment_checking_title": "Pembayaran sedang diperiksa",
        "portal.shop_entry.flow_title": "Cara masuk bekerja",
    },
}


def _flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(_flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def _load(lang: str) -> dict[str, str]:
    return _flatten(
        json.loads(
            (LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8")
        )
    )


def _allowed_exact_values() -> set[str]:
    payload = json.loads(ALLOWLIST.read_text(encoding="utf-8"))
    return set(payload.get("exact_values", []))


def _in_scope(key: str) -> bool:
    return any(key.startswith(prefix) for prefix in PREFIXES)


def test_cycle_1379_wave3_portal_shop_samples_are_manual() -> None:
    en = _load("en")
    for lang, expected_values in EXPECTED_SAMPLE.items():
        locale = _load(lang)
        for key, expected in expected_values.items():
            assert locale[key] == expected, (lang, key)
            assert locale[key] != en[key], (lang, key)


def test_cycle_1379_wave3_portal_shop_has_no_unexpected_english_identical_values() -> (
    None
):
    en = _load("en")
    allowed = _allowed_exact_values()
    public_keys = sorted(key for key in en if _in_scope(key))
    assert len(public_keys) == 134
    for lang in WAVE3_LANGS:
        locale = _load(lang)
        identical = [
            key
            for key in public_keys
            if locale[key] == en[key] and locale[key] not in allowed
        ]
        assert identical == [], (lang, identical)


def test_cycle_1379_wave3_portal_shop_has_no_cyrillic_tails() -> None:
    public_keys = sorted(key for key in _load("en") if _in_scope(key))
    for lang in WAVE3_LANGS:
        locale = _load(lang)
        tails = [
            key
            for key in public_keys
            if CYRILLIC_RE.search(locale[key])
        ]
        assert tails == [], (lang, tails)


def test_cycle_1379_wave3_portal_shop_audit_script_passes() -> None:
    result = subprocess.run(
        [
            sys.executable,
            "ops/i18n/audit_wave3_portal_shop_locale_quality.py",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "Unexpected English-identical values: 0" in result.stdout
    assert "Cyrillic tails: 0" in result.stdout
