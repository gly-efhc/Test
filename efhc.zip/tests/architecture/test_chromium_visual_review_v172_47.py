from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_скриншоты_маршрутов_скрывают_временные_панели() -> None:
    proof = read("ops/frontend/public_visual_runtime_proof.py")
    audit = read("ops/frontend/all_pages_route_backed_visual_audit.py")

    assert (
        "window.localStorage.setItem('onboarding_v1_seen', '1')"
        in proof
    )
    assert "window.__EFHC_PUBLIC_VISUAL_PROOF__ = true" in proof
    assert "value: async () => true" in proof
    assert "obstructing_overlays" in audit
    assert (
        '"[data-onboarding-tour], "' in audit
        and "[data-pwa-runtime-status]:not(" in audit
        and "inline-readonly" in audit
    )
    assert "obstructing_overlays == 0" in audit


def test_visual_audit_browser_shop_открывает_витрину() -> None:
    manifest = json.loads(
        read("ops/frontend/all_pages_visual_manifest_v171_88.json")
    )
    browser_shop = next(
        item
        for item in manifest["public_routes"]
        if item["route"] == "/browser-shop"
    )
    assert browser_shop["marker"] == (
        "[data-browser-shop-checkout='ton-usdt']"
    )

    page = read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    )
    assert "__EFHC_PUBLIC_VISUAL_PROOF__" in page
    assert "navigator.webdriver === true" in page
    assert '"127.0.0.1"' in page
    assert '"localhost"' in page


def test_панели_первого_запуска_не_перекрываются() -> None:
    onboarding = read("frontend/src/components/OnboardingTour.tsx")
    pwa = read("frontend/src/components/PwaRuntimeStatus.tsx")
    styles = read("frontend/src/styles/globals.css")

    assert "createPortal(content, document.body)" in onboarding
    assert "efhc:onboarding-complete" in onboarding
    assert "dataset.efhcOnboarding" in onboarding
    assert "onboardingDone" in pwa
    assert "!visualProof" in pwa
    assert '!router.pathname.startsWith("/admin")' in pwa
    assert ".efhc-pwa-storage-card{" in styles
    assert 'html[data-efhc-onboarding="full"] .efhc-game-nav' in styles
    assert "max-height: calc(100dvh - 2rem)" in styles


def test_метка_browser_login_имеет_различимые_цвета() -> None:
    styles = read("frontend/src/styles/globals.css")
    corrective_start = styles.rfind(
        "Cycle 1635 corrective — admin-quality public design system parity"
    )
    assert corrective_start >= 0
    corrective = styles[corrective_start:]
    assert ".efhc-browser-login_badge{" in corrective
    assert "background:rgba(88,199,180,.10);" in corrective
    assert "color:#a9e5da;" in corrective
    assert "text-align:center;" in styles


def test_visual_report_использует_текущую_версию() -> None:
    audit = read("ops/frontend/all_pages_route_backed_visual_audit.py")
    assert "def _archive_version()" in audit
    assert '"archive_version": _archive_version()' in audit
    assert '"cycle": 1635' in audit
