from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


CONCEPT = ROOT / "docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md"
WORK = ROOT / "docs/cycles/WORK_CYCLES_0-100.md"
HUB = ROOT / "docs/SSOT/HUB_SSOT.md"


def test_skin_switcher_concept_doc_exists_and_separates_domains():
    text = CONCEPT.read_text(encoding="utf-8")
    assert "Skin switcher is not Hub." in text
    assert "Skin switcher is not a commerce screen." in text
    assert "available_skin_ids" in text
    assert "active_skin_id" in text
    assert "unlocked set is cumulative" in text
    assert "fallback to the highest unlocked skin" in text
    assert "POST /skins/buy/{skin_id}" in text
    assert "price_efhc" in text
    assert "purchased_at" in text


def test_cycle_72_and_91_are_closed_in_work_cycles():
    text = WORK.read_text(encoding="utf-8")
    assert "| 72 | done | Skin switcher concept." in text
    assert "| 91 | done | Skin switcher concept closure." in text
    assert "resolved later by cycle 91" in text


def test_hub_ssot_points_to_skin_switcher_concept_doc():
    text = HUB.read_text(encoding="utf-8")
    assert "docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md" in text
    assert "отдельный concept-layer switcher" in text
