from __future__ import annotations

import json
from pathlib import Path

from ops.ci_checks.check_public_ui_active_copy import main, scan


def test_active_public_copy_is_human_facing() -> None:
    assert scan(Path.cwd()) == []


def test_guard_rejects_referenced_technical_locale_copy(tmp_path: Path) -> None:
    policy = tmp_path / "ops/policy"
    policy.mkdir(parents=True)
    (policy / "public_ui_active_copy.json").write_text(
        json.dumps({"forbidden_phrases": ["payload"]}),
        encoding="utf-8",
    )
    page = tmp_path / "frontend/src/pages"
    page.mkdir(parents=True)
    (page / "index.tsx").write_text(
        'export default function P(){return <p>{t("x.note")}</p>}',
        encoding="utf-8",
    )
    locale = tmp_path / "frontend/public/locale"
    locale.mkdir(parents=True)
    (locale / "ru.json").write_text(
        json.dumps({"x.note": "Показан payload"}),
        encoding="utf-8",
    )
    assert main(["--root", str(tmp_path)]) == 1
