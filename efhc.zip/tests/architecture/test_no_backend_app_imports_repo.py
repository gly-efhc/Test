from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

# Canon: code must not import via backend.app.*
FORB = "backend.app."


# We scan only code-like files where imports matter.
CODE_SUFFIXES = {
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
}

# Exclusions: binary / caches.
EXCLUDED_DIR_PARTS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    ".next",
    ".local_artifacts",
}

# Some repo-wide log artifacts may contain tracebacks.
EXCLUDED_FILE_NAMES = {
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
}

BINARY_SUFFIXES = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".svg",
    ".pdf",
    ".zip",
    ".tar",
    ".gz",
    ".7z",
    ".ico",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".pyc",
}


@dataclass(frozen=True)
class Finding:
    rel_path: str
    line_no: int
    line: str


def _is_excluded(path: Path) -> bool:
    if path.name in EXCLUDED_FILE_NAMES:
        return True
    if set(path.parts) & EXCLUDED_DIR_PARTS:
        return True
    if path.suffix.lower() in BINARY_SUFFIXES:
        return True
    if path.name.startswith("logs_"):
        return True
    return path.suffix.lower() not in CODE_SUFFIXES


def _scan_tree(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if _is_excluded(path):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            continue
        if FORB not in text:
            continue
        rel = str(path.relative_to(root))
        for idx, line in enumerate(text.splitlines(), start=1):
            if FORB in line:
                findings.append(
                    Finding(
                        rel_path=rel,
                        line_no=idx,
                        line=line.strip(),
                    )
                )
    return findings


def test_no_backend_app_imports_repo() -> None:
    root = Path(__file__).resolve().parents[2]
    targets = [
        root / "backend",
        root / "frontend",
    ]
    findings: list[Finding] = []
    for t in targets:
        if t.exists() and t.is_dir():
            findings.extend(_scan_tree(t))
    if findings:
        details = "\n".join(
            f"{f.rel_path}:{f.line_no}: {f.line}" for f in findings
        )
        raise AssertionError(
            "Forbidden import prefix found: "
            f"'{FORB}'. Use 'app.' instead.\n" + details
        )
