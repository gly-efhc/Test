"""Architecture contracts для extended domain ownership пакета 1628."""

from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def _literal_assignment(rel: str, name: str) -> object:
    tree = ast.parse(_read(rel))
    for node in tree.body:
        if (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == name
        ):
            return ast.literal_eval(node.value)
    raise AssertionError(f"{rel}: assignment {name} not found")


def test_extended_owner_входит_в_single_release_schema() -> None:
    source = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source
    for table in ("shop_orders", "user_skins", "user_cosmetics"):
        assert table in source

def test_extended_owner_final_models_не_дублируют_owner_columns() -> None:
    for relative in (
        "backend/app/models/shop_models.py",
        "backend/app/models/skins_models.py",
        "backend/app/models/admin_models.py",
        "backend/app/models/ton_logs_models.py",
    ):
        source = _read(relative)
        assert "global_id" in source
    migration = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    assert "OWNER_TRIGGER_SPECS" in migration

def test_shop_и_cosmetics_reads_используют_canonical_owner() -> None:
    shop_routes = _read("backend/app/routes/shop_routes.py")
    shop_service = _read("backend/app/services/shop_service.py")
    skins_routes = _read("backend/app/routes/skins_routes.py")
    skins_service = _read("backend/app/services/skins_service.py")

    assert "get_nonfinancial_read_owner" in shop_routes
    assert "list_orders_by_owner" in shop_routes
    assert "global_id=int(owner.global_id)" in shop_routes
    assert "list_orders_for_owner" in shop_service
    assert "WHERE global_id = :global_id" in shop_service
    assert "WHERE tg_id = :tg_id" in shop_service

    assert "get_nonfinancial_read_owner" in skins_routes
    assert "owner: NonFinancialReadOwner" in skins_service
    assert "UserSkin.global_id == int(owner.global_id)" in skins_service
    assert "UserCosmetics.global_id == int(owner.global_id)" in skins_service


def test_paid_writes_используют_canonical_owner() -> None:
    shop_routes = _read("backend/app/routes/shop_routes.py")
    skins_routes = _read("backend/app/routes/skins_routes.py")
    skins_service = _read("backend/app/services/skins_service.py")

    assert shop_routes.count("Depends(get_current_tg_id)") >= 2
    assert "async def buy_skin(" in skins_service
    assert "global_id: int" in skins_service
    assert "spend_user_to_bank_bonus_then_main" in skins_service
    assert "global_id=int(owner.global_id)" in skins_routes
    assert "Depends(get_current_tg_id)" not in skins_routes


def test_memo_и_notification_identity_provider_neutral() -> None:
    memo = _read("backend/app/integrations/ton_memo.py")
    channel = _read("backend/app/identity/notification_channel.py")
    notifications = _read(
        "backend/app/services/shop_order_notifications_service.py"
    )

    assert "EFHC:GID:" in memo
    assert "|GID:" in memo
    assert "global_id must be 10 ASCII digits" in memo
    assert "|TG:" in memo

    assert "class TelegramNotificationChannel" in channel
    assert "global_id" in channel
    assert "tg_id" in channel
    assert "AuthProvider.TELEGRAM.value" in channel
    assert "resolve_telegram_notification_channel" in notifications
    assert "global_id" in notifications


def test_telegram_replay_сохраняет_resolved_global_owner() -> None:
    source = _read("backend/app/identity/telegram_auth_session.py")
    assert "async def _bind_replay_owner(" in source
    assert ".values(resolved_global_id=global_id.value)" in source
    assert "INIT_DATA_OWNER_CONFLICT" in source
    assert "global_id=account.global_id" in source
