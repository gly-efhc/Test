from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_energy_first_screen_has_only_energy_context() -> None:
    page = read("frontend/src/pages/index.tsx")
    assert "LiveEnergyHeroAndProgress" in page
    assert "EnergyMvpSummary" not in page
    assert 'data-energy-level-name={levelName}' in page
    assert 'data-energy-chip-count="3"' in page
    assert "profile.main_balance" not in page
    assert "profile.bonus_balance" not in page
    assert 'href: "/exchange"' not in page

def test_energy_first_screen_has_resource_chips() -> None:
    page = read("frontend/src/pages/index.tsx")
    assert "efhc-energy-stage_chips" in page
    assert "props.labels.panels_owned" in page
    assert "props.labels.gen_rate" in page
    assert "active_panels={activePanels}" in page


def test_layout_no_duplicate_skin_hero_before_energy() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    assert "props.shopSkinBgUrl ?" not in layout
    assert "efhc-skin-hero_image" not in layout


def test_energy_first_screen_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    assert ".efhc-energy-page" in css
    assert ".efhc-energy-stage_topbar" in css
    assert ".efhc-energy-stage_level" in css
    assert ".efhc-energy-chip" in css


def test_energy_action_locale_keys_exist() -> None:
    en = read("frontend/public/locale/en.json")
    ru = read("frontend/public/locale/ru.json")
    assert "energy.activate_panel_action" in en
    assert "energy.exchange_action" in en
    assert "energy.activate_panel_action" in ru
    assert "energy.exchange_action" in ru
