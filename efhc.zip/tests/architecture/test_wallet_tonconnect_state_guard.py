from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_wallet_state_map_has__all__public_states() -> None:
    src = read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    ) + read("frontend/src/components/profile/ProfileWalletSection.tsx")
    for state in (
        "wallet.status_not_connected",
        "wallet.status_connected",
        "wallet.error_title",
        "wallet.empty_title",
        "wallet.linked_wallets",
    ):
        assert state in src
    assert (
        "data-wallet-list-boundary" in src
        or "data-wallet-list-only" in src
    )
    assert "ctx.openWalletConnect" in src


def test_tonconnect_manifest_and_provider_remain_wired() -> None:
    app = read("frontend/src/pages/_app.tsx")
    provider = read("frontend/src/lib/wallet-provider/WalletProvider.tsx")
    app_shell_service = read("frontend/src/services/appShell.service.ts")
    manifest = read("frontend/src/pages/api/tonconnect-manifest.ts")
    assert "buildTonConnectManifestUrl" in app
    assert "/api/tonconnect-manifest" in app_shell_service
    assert "TonConnectUIProvider" in provider
    assert "Access-Control-Allow-Origin" in manifest


def test_public_wallet_state_locale_keys_exist() -> None:
    locale_dir = ROOT / "frontend/public/locale"
    for path in sorted(locale_dir.glob("*.json")):
        text = path.read_text(encoding="utf-8")
        for key in (
            "wallet.state_map_title",
            "wallet.state_not_connected",
            "wallet.state_connected",
            "wallet.state_pending_proof",
            "wallet.state_wallet_error",
            "wallet.state_backend_error",
            "wallet.state_bound",
        ):
            assert f'"{key}"' in text, path.name
