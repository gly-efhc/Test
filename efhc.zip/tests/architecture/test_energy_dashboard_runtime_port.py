from __future__ import annotations

import json
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/ENERGY_DASHBOARD_RUNTIME_PORT.md"
GRAFANA_DOC = ROOT / "docs/NORM/ENERGY_DASHBOARD_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md"
TSX = ROOT / "frontend/src/components/dashboard/EnergyDashboardRuntime.tsx"
INDEX = ROOT / "frontend/src/pages/index.tsx"
SIM_KIT = ROOT / "frontend/src/components/dashboard/SimulationDashboardUiKit.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
RU = ROOT / "frontend/public/locale/ru.json"
EN = ROOT / "frontend/public/locale/en.json"
REPORT = ROOT / "reports/generated/energy_dashboard_runtime_port_v170_45.json"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
TEST_MANIFEST = ROOT / "docs/testing/TEST_GUARD_MANIFEST.md"
TEST_MANIFEST_JSON = ROOT / "docs/testing/TEST_GUARD_MANIFEST.json"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_energy_dashboard_runtime_docs_exist_and_set_truth_model() -> None:
    text = read(DOC)
    assert "ACTIVE_ENERGY_DASHBOARD_RUNTIME_PORT" in text
    assert "Cycle: `1469`" in text
    assert "SyncSnapshot" in text
    assert "raw" in text
    assert "derived" in text
    assert "does not claim `real_timeseries`" in text
    assert "does not use `synthetic_preview`" in text
    assert "data-energy-dashboard-runtime-port=\"1469\"" in text
    assert "data-energy-dashboard-synthetic=\"false\"" in text
    assert "No Песочница runtime code is copied" in text


def test_energy_dashboard_runtime_component_is_runtime_safe() -> None:
    text = read(TSX)
    required = [
        "export function EnergyDashboardRuntime",
        "EFHC_ENERGY_DASHBOARD_RUNTIME_PORT_V1",
        "data-energy-dashboard-runtime-port=\"1469\"",
        "data-energy-dashboard-data-kind=\"raw-and-derived\"",
        "data-energy-dashboard-synthetic=\"false\"",
        "data-energy-dashboard-write-flow=\"false\"",
        "data-grafana-reference-only=\"true\"",
        "data-sandbox-reference-only=\"true\"",
        "SyncSnapshot",
        "SimHeroEnergyCard",
        "SimMiniBarChart",
        "SimActivityStrip",
        "SimSegmentedProgress",
    ]
    for marker in required:
        assert marker in text

    forbidden = [
        "energySandboxPreviewByPeriod",
        "synthetic_preview",
        "@grafana/",
        "SceneObject",
        "apiRequest",
        "fetch(",
        "axios",
        "method: \"POST\"",
        "method: \"PUT\"",
        "method: \"PATCH\"",
        "method: \"DELETE\"",
        "onSubmit",
        "formAction",
        "transfer-to-user",
        "raw tg_id",
        "initData",
    ]
    for marker in forbidden:
        assert marker not in text


def test_energy_runtime_dashboard_is_retained_as_inactive_legacy_reference() -> None:
    text = read(INDEX)
    assert "<LiveEnergyHeroAndProgress" in text
    assert "<EnergyMvpSummary" not in text
    assert "EnergyDashboardRuntime" not in text
    assert "PublicEnergyInteractiveOverview" not in text
    assert "export function EnergyDashboardRuntime" in read(TSX)
    mapping = read(
        ROOT / "docs/frontend/FRONTEND_ENERGY_MVP_REPLACEMENT_MAPPING.md"
    )
    assert "EnergyDashboardRuntime" in mapping
    assert "INACTIVE_LEGACY_REFERENCE" in mapping

def test_runtime_port_css_and_locale_keys_exist() -> None:
    css = read(CSS)
    for marker in [
        "Cycle 1469 — Energy Dashboard Runtime Port",
        ".efhc-energy-dashboard-runtime",
        ".efhc-energy-dashboard-runtime__kpi-strip",
        ".efhc-energy-dashboard-runtime__rules",
        "var(--efhc-dash-border)",
        "var(--efhc-dash-accent)",
    ]:
        assert marker in css

    for data in [load(RU), load(EN)]:
        for key in [
            "energy.dashboard_runtime_title",
            "energy.dashboard_runtime_subtitle",
            "energy.dashboard_snapshot",
            "energy.dashboard_freshness",
            "energy.dashboard_source_runtime",
            "energy.dashboard_no_timeseries",
            "energy.dashboard_raw_snapshot",
            "energy.dashboard_derived_snapshot",
        ]:
            assert key in data


def test_runtime_report_records_safe_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1469
    assert data["version"] == "v170.45"
    assert data["truth_model"]["data_kinds"] == ["raw", "derived"]
    assert data["truth_model"]["synthetic_preview_used_in_runtime"] is False
    assert data["truth_model"]["real_timeseries_claimed"] is False
    assert data["truth_model"]["snapshot_only_period"] is True
    for key in [
        "economy_changed",
        "backend_contracts_changed",
        "db_migrations_changed",
        "openapi_changed",
        "new_dependencies_added",
        "lock_files_changed",
        "ci_workflows_changed",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
        "write_flows_changed",
        "money_actions_added",
    ]:
        assert data["boundaries"][key] is False
    assert data["boundaries"]["live_energy_route_uses_runtime_snapshot"] is True
    assert data["tests"]["npm_audit_total_vulnerabilities"] == 0


def test_grafana_runtime_analysis_is_reference_only() -> None:
    text = read(GRAFANA_DOC)
    for marker in [
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "PanelChrome.tsx",
        "PanelStatus.tsx",
        "BigValue",
        "Sparkline/Sparkline.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
        "DashboardGrid",
        "Variables",
    ]:
        assert marker in text
    assert "Grafana is not a code donor" in text
    assert "No Grafana source code is copied" in text
    assert "EFHC-owned target code" in text


def test_navigation_and_guard_manifest_register_runtime_port() -> None:
    for path in [KERNEL, MAP, ROUTES, TEST_MANIFEST]:
        text = read(path)
        assert "ENERGY_DASHBOARD_RUNTIME_PORT" in text
        assert "EnergyDashboardRuntime.tsx" in text
        assert "test_energy_dashboard_runtime_port.py" in text
    manifest = load(TEST_MANIFEST_JSON)
    assert "cycle_1469_energy_dashboard_runtime_port" in manifest
    item = manifest["cycle_1469_energy_dashboard_runtime_port"]
    assert item["status"] == "active"


def test_sim_hero_energy_card_has_single_unit_span() -> None:
    text = read(SIM_KIT)
    assert text.count("{props.unit ? <span>{props.unit}</span> : null}") == 1


def test_grafana_archive_has_referenced_runtime_elements() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "PanelChrome.tsx",
        "PanelStatus.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker


def test_sandbox_archive_remains_reference_available() -> None:
    sandbox_path = ROOT.parent / "Песочница.xz"
    if not sandbox_path.exists():
        return
    with tarfile.open(sandbox_path) as archive:
        names = archive.getnames()
    for marker in [
        "MaterialM-Tailwind-Nextjs-Free-main",
        "TelegramUI-main",
        "Mark42-master",
    ]:
        assert any(marker in name for name in names), marker
