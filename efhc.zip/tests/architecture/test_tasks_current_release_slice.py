from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="ignore")


def test_tasks_page_is_one_react_query_catalog() -> None:
    page = read("frontend/src/pages/tasks.tsx")
    assert 'data-tasks-runtime="cycle-1557-react-query"' in page
    assert "useTasksCatalog" in page
    assert "useMyTasks" in page
    assert "useClaimTask" in page
    assert "useBuiltinAdSlot" in page
    assert "useFinishBuiltinTimerAd" in page
    assert "TasksDashboardRuntime" not in page
    assert "PublicEngagementPreview" not in page
    assert "useMutation" not in page
    assert "useQueryClient" not in page


def test_tasks_query_invalidates_user_state_and_snapshot() -> None:
    queries = read("frontend/src/queries/useTasks.ts")
    assert "invalidateTaskState" in queries
    assert "queryKeys.tasks.mine(globalId)" in queries
    assert "queryKeys.snapshot.current(globalId)" in queries
    assert queries.count("onSuccess") >= 2


def test_tasks_service_validates_catalog_state_and_rewards() -> None:
    service = read("frontend/src/services/tasks.service.ts")
    for marker in (
        "TaskCatalogItemSchema",
        "MyTaskItemSchema",
        "ClaimTaskResponseSchema",
        "AdSlotResponseSchema",
        "AdCallbackResponseSchema",
        ".parse(",
    ):
        assert marker in service


def test_backend_unifies_submission_and_ad_runtime_status() -> None:
    service = read("backend/app/services/tasks_service.py")
    assert "aliased(TaskSubmission)" in service
    assert "aliased(UserTaskStatus)" in service
    assert "runtime_status.next_available_at" in service
    assert 'status = "claimed"' in service
    assert 'status = "not_started"' in service


def test_double_credit_guards_remain_fail_closed() -> None:
    service = read("backend/app/services/tasks_service.py")
    assert ".with_for_update()" in service
    assert "if bool(sub.paid):" in service
    assert 'detail="already_paid"' in service
    assert "credit_user_bonus_from_bank" in service
    assert "global_id=owner.global_id" in service
    assert "task_complete_lock" in service
    assert "FOR UPDATE" in service


def test_ads_route_remains_tasks_alias() -> None:
    alias = read("frontend/src/pages/ads.tsx")
    assert 'r.replace("/tasks")' in alias or "replace('/tasks')" in alias


def test_global_typography_is_compact_and_arial_like() -> None:
    css = read("frontend/src/styles/globals.css")
    document = read("frontend/src/pages/_document.tsx")
    assert '--efhc-font-sans: Arial, "Helvetica Neue", Helvetica, sans-serif' in css
    assert "font-family: var(--efhc-font-sans)" in css
    assert "Arial,HelveticaNeue,Helvetica,sans-serif" in document.replace(" ", "")
    assert "Georgia" not in css
    assert '"Times New Roman"' not in css
    assert ".efhc-exchange-shell .efhc-game-stat_value" in css
    assert "white-space: nowrap" in css
    assert "Cycle 1557" in css
    assert ".efhc-modal-overlay" in css
    assert "z-index:60" in css
    modal = read("frontend/src/components/ui/Modal.tsx")
    assert "createPortal" in modal
    assert 'data-modal-portal="body"' in modal
