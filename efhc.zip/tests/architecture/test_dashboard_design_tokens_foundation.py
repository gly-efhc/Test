from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md"
CSS = ROOT / "frontend/src/styles/globals.css"
REPORT = ROOT / "reports/generated/dashboard_design_tokens_foundation_v170_34.json"
PLAN = ROOT / "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_dashboard_design_tokens_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_DASHBOARD_DESIGN_TOKENS_FOUNDATION" in text
    assert "frontend/src/styles/globals.css" in text
    assert "Grafana is visual-pattern reference only" in text
    assert "--efhc-dash-surface" in text
    assert "--efhc-dash-success" in text
    assert "1459 — Dashboard Component Contract" in text


def test_dashboard_css_tokens_cover_required_families() -> None:
    css = read(CSS)
    required = [
        "--efhc-dash-bg",
        "--efhc-dash-surface",
        "--efhc-dash-panel",
        "--efhc-dash-panel-strong",
        "--efhc-dash-border",
        "--efhc-dash-border-strong",
        "--efhc-dash-text",
        "--efhc-dash-muted",
        "--efhc-dash-accent",
        "--efhc-dash-success",
        "--efhc-dash-warning",
        "--efhc-dash-danger",
        "--efhc-dash-info",
        "--efhc-dash-radius-lg",
        "--efhc-dash-space-4",
        "--efhc-dash-shadow-panel",
        "--efhc-dash-font-value",
    ]
    for marker in required:
        assert marker in css


def test_dashboard_css_has_light_mode_overrides() -> None:
    css = read(CSS)
    light = css.split('html[data-theme="light"]', maxsplit=1)[1]
    assert "--efhc-dash-bg" in light
    assert "--efhc-dash-panel" in light
    assert "--efhc-dash-success" in light
    assert "--efhc-dash-danger" in light


def test_dashboard_utility_classes_use_tokens() -> None:
    css = read(CSS)
    assert ".efhc-dashboard-panel" in css
    assert "background: var(--efhc-dash-panel)" in css
    assert "border: 1px solid var(--efhc-dash-border)" in css
    assert ".efhc-dashboard-grid" in css
    assert "gap: var(--efhc-dash-space-4)" in css
    assert ".efhc-dashboard-status-success" in css
    assert "color: var(--efhc-dash-success)" in css


def test_dashboard_design_tokens_machine_report() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1458
    assert data["version"] == "v170.34"
    assert data["runtime_changes"]["css_tokens_added"] is True
    assert data["runtime_changes"]["economy_changed"] is False
    assert data["runtime_changes"]["backend_contracts_changed"] is False
    assert data["reference_boundaries"]["grafana_runtime_code_copied"] is False
    assert data["reference_boundaries"]["sandbox_runtime_code_copied"] is False
    assert data["next_cycle"]["cycle"] == 1459


def test_navigation_points_to_dashboard_design_tokens() -> None:
    assert "v170.34 / Dashboard Design Tokens Foundation" in read(KERNEL)
    assert "DASHBOARD_DESIGN_TOKENS_FOUNDATION.md" in read(PLAN)
    assert "DASHBOARD_DESIGN_TOKENS_FOUNDATION.md" in read(MAP)
    routes = read(ROUTES)
    assert "docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md" in routes
    assert "dashboard_design_tokens_foundation_v170_34.json" in routes
    assert "frontend/src/styles/globals.css" in routes
