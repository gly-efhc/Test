from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1404_user_decisions_recorded_in_qna_and_plan() -> None:
    qna = _read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")
    plan = _read(
        "docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md"
    )
    for marker in (
        "HEAL-0040",
        "package_id",
        "HEAL-0024",
        "HEAL-0018",
        "compatibility facade",
        "HEAL-0055",
        "efhc_admin.idempotency_key",
    ):
        assert marker in qna
        assert marker in plan


def test_deposit_cache_runtime_has_no_process_local_ttl_seen() -> None:
    system_locks = _read("backend/app/core/system_locks.py")
    assert "_ttl_seen" not in system_locks
    assert "self._ttl_seen" not in system_locks
    assert "_acquire_idempotency_ttl_lock" in system_locks
    assert "IdempotencyKey" in system_locks


def test_deposit_cache_uses_admin_idempotency_key_model() -> None:
    model = _read("backend/app/models/admin_models.py")
    assert "class IdempotencyKey" in model
    assert '__tablename__ = "idempotency_key"' in model
    assert "ADMIN_SCHEMA" in model
    assert "expires_at" in model


def test_healer_0055_elevated_and_planned() -> None:
    atlas = json.loads(_read("atlas.json"))
    card = next(c for c in atlas["cards"] if c["heal_id"] == "HEAL-0055")
    assert card["severity"] == "P0"
    assert card["zone"] == "red"
    assert card["action_priority"] == "immediate"
    assert "1412-1413" in card["confirmation_basis"]


def test_old_plan_is_superseded_not_deleted() -> None:
    old_plan = _read("docs/cycles/WORK_CYCLES_1403-1417_P0_BACKEND_AND_FSM_REPAIR_PLAN.md")
    assert "SUPERSEDED" in old_plan
    assert "WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md" in old_plan
