from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_panels_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_PANELS_DASHBOARD_UPGRADE.md",
        "docs/NORM/ADMIN_PANELS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1487_ADMIN_PANELS_DASHBOARD_UPGRADE.md",
        "reports/generated/admin_panels_dashboard_upgrade_v170_63.json",
        "reports/change_cycle_2026-06-08_v170_63_cycle_1487_"
        "admin_panels_dashboard_upgrade.md",
        "frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx",
        "tests/architecture/test_admin_panels_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_panel_boundaries() -> None:
    data = json.loads(
        read("reports/generated/admin_panels_dashboard_upgrade_v170_63.json")
    )
    assert data["cycle"] == 1487
    assert data["archive_version"] == "v170.63"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_panels_route_changed"] is True
    assert data["new_backend_endpoint_added"] is False
    assert data["fake_time_series_added"] is False
    assert data["fake_activation_trends_added"] is False
    assert data["fake_panel_history_added"] is False
    assert data["synthetic_admin_analytics_added"] is False
    assert data["real_time_series_claimed"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["dashboard_idempotency_key_created"] is False
    assert data["panel_lifecycle_logic_changed"] is False
    assert data["panel_generation_logic_changed"] is False
    assert data["panel_activate_logic_changed"] is False
    assert data["panel_deactivate_logic_changed"] is False
    assert data["panel_money_flow_changed"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False
    assert data["deposits_progress_coverage_debt_fixed"] is True


def test_admin_panels_runtime_component_has_1487_markers() -> None:
    src = read("frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx")
    required = [
        "adminPanelsDashboardRuntimeVersion",
        "EFHC_ADMIN_PANELS_DASHBOARD_RUNTIME_V1",
        'data-admin-panels-dashboard-runtime="1487"',
        'data-admin-panels-truth="raw-derived"',
        'data-admin-panels-no-synthetic="true"',
        'data-admin-panels-no-write-actions="true"',
        'data-admin-panels-no-raw-payload="true"',
        'data-admin-panels-no-debug-json="true"',
        'data-admin-panels-no-secrets="true"',
        'data-admin-panels-no-fake-activation-trends="true"',
        'data-admin-panels-lifecycle-safe="true"',
        'data-admin-panels-economy="read-only"',
        "AdminDashboardToolbar",
        "AdminFreshnessBadge",
        "AdminRefreshPicker",
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminPanelChrome",
        "AdminMiniBarChart",
        "AdminProgressBar",
        "AdminHeatStrip",
        "AdminFlowMapCard",
        "AdminActionTable",
        "AdminStatusBadge",
    ]
    for marker in required:
        assert marker in src


def test_admin_panels_runtime_component_is_read_only() -> None:
    src = read("frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "fetch(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "mutateAsync",
        "synthetic_preview",
        "raw payload dump",
        "debug JSON dump",
        "buildTrend",
        "setInterval",
        "toggle(",
    ]
    for marker in forbidden:
        assert marker not in src
    assert "Derived snapshot display" in src
    assert "нет backend dates" in src
    assert "fake activation trends" in src


def test_admin_panels_page_integrates_dashboard_safely() -> None:
    page = read("frontend/src/pages/admin/panels.tsx")
    assert "AdminPanelsDashboardRuntime" in page
    assert "loadDashboardSnapshots" in page
    assert "adminApiRequest<PanelsOut>" in page
    assert "ADMIN_PANELS_PATH" in page
    assert "dashboardItems" in page
    assert "dashboardUpdatedAt" in page
    assert "activeOnly={onlyActive}" in page
    assert "filterApplied={Boolean(tgFilter.trim())}" in page


def test_admin_panels_guarded_actions_remain_outside_dashboard() -> None:
    page = read("frontend/src/pages/admin/panels.tsx")
    component = read("frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx")
    for marker in [
        "toggle(panelId:number,toActive:boolean)",
        "newIdempotencyKey",
        'adminApiRequest(path,"PATCH"',
        "ADMIN_PANELS_PANEL_ID_ACTIVATE_PATH",
        "ADMIN_PANELS_PANEL_ID_DEACTIVATE_PATH",
        "Переключить",
    ]:
        assert marker in page
        assert marker not in component


def test_admin_panels_dashboard_has_real_panel_fields_only() -> None:
    component = read("frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx")
    required = [
        "is_active",
        "created_at",
        "expires_at",
        "archived_at",
        "last_generated_at",
        "base_gen_per_sec",
        "generated_kwh",
        "PANEL_LIFECYCLE_DAYS = 180",
    ]
    for marker in required:
        assert marker in component
    assert "fake panel history" not in component.lower()
    assert "synthetic" in component


def test_admin_panels_dashboard_does_not_expose_raw_public_identifiers() -> None:
    component = read("frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx")
    assert "tg_id" not in component
    assert "raw payload" not in component.lower()
    assert "debug JSON" not in component
    assert "secrets" in component


def test_admin_panels_css_exists_and_mobile_safe() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1487 — Admin Panels Dashboard Upgrade",
        'data-admin-panels-dashboard-runtime="1487"',
        ".efhc-admin-panels-dashboard-grid",
        ".efhc-admin-panels-dashboard-status-grid",
        ".efhc-admin-panels-dashboard-readiness",
        ".efhc-admin-panels-dashboard-table",
        ".efhc-admin-panels-dashboard-row",
        ".efhc-admin-panels-dashboard-boundary",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_deposits_progress_coverage_debt_is_closed() -> None:
    src = read("frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx")
    css = read("frontend/src/styles/globals.css")
    required = [
        "pendingIntentsPercent",
        "Pending intents ratio",
        "label=\"Pending intents\"",
        "Automation credited + exception backlog + pending intents cover",
        "observedTotal denominator",
    ]
    for marker in required:
        assert marker in src
    assert ".efhc-admin-deposits-dashboard-coverage-note" in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1487 — Admin Panels Dashboard Upgrade" in corpus
    assert "ADMIN_PANELS_DASHBOARD_UPGRADE" in corpus
    assert "AdminPanelsDashboardRuntime.tsx" in corpus
    assert "1488 — Admin Tasks / Referrals Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/ADMIN_PANELS_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/ADMIN_PANELS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype" in docs
    assert "No Grafana source code" in docs
