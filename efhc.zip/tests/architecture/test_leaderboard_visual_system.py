from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_leaderboard_visual_system_docs_exist() -> None:
    required = [
        "docs/NORM/LEADERBOARD_VISUAL_SYSTEM.md",
        "docs/NORM/LEADERBOARD_VISUAL_SYSTEM_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1476_LEADERBOARD_VISUAL_SYSTEM.md",
        "reports/generated/leaderboard_visual_system_v170_52.json",
        "reports/change_cycle_2026-06-07_v170_52_cycle_1476_leaderboard_visual_system.md",
        "frontend/src/components/dashboard/LeaderboardVisualSystem.tsx",
        "tests/architecture/test_leaderboard_visual_system.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(read("reports/generated/leaderboard_visual_system_v170_52.json"))
    assert data["cycle"] == 1476
    assert data["archive_version"] == "v170.52"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_ranks_route_changed"] is True
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["raw_tg_id_visible_in_public_ui"] is False
    assert data["fake_leaderboard_rows_added"] is False
    assert data["internal_energy_levels_catalog_exposed"] is False
    assert data["grafana_runtime_code_copied"] is False


def test_leaderboard_visual_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/LeaderboardVisualSystem.tsx")
    required = [
        "leaderboardVisualSystemVersion",
        "EFHC_LEADERBOARD_VISUAL_SYSTEM_V1",
        "SimLeaderboardCard",
        "SimLeaderboardPodium",
        "SimLeaderboardList",
        "buildLeaderboardVisualItem",
        "data-leaderboard-visual-system=\"1476\"",
        "data-leaderboard-username-only=\"true\"",
        "data-leaderboard-no-raw-tg-id=\"true\"",
    ]
    for marker in required:
        assert marker in src


def test_leaderboard_visual_component_is_ui_only() -> None:
    src = read("frontend/src/components/dashboard/LeaderboardVisualSystem.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "withdraw",
        "deposit",
        "activatePanel",
        "newIdempotencyKey",
        "telegramMainButtonSet",
    ]
    for marker in forbidden:
        assert marker not in src


def test_runtime_ranks_uses_visual_system_without_fake_rows() -> None:
    runtime = read("frontend/src/components/dashboard/RanksDashboardRuntime.tsx")
    assert "LeaderboardVisualSystem" in runtime
    assert "SimLeaderboardPodium" in runtime
    assert "SimLeaderboardList" in runtime
    assert "data-leaderboard-visual-system-runtime=\"1476\"" in runtime
    assert "data-ranks-runtime-username-only=\"true\"" in runtime
    assert "synthetic_preview" not in runtime
    assert "rank_pos: 1" not in runtime


def test_runtime_ranks_page_keeps_active_leaderboard_meaning() -> None:
    page = read("frontend/src/pages/ranks.tsx")
    required = [
        "RankRow",
        "ranks.leaderboard_empty",
        "ranks.user_hidden_fallback",
        'data-ranks-leaderboard="top-100"',
        'data-ranks-card-layout="vertical-1299"',
        "item={me}",
        "leaderboard.map",
    ]
    for marker in required:
        assert marker in page
    assert "RanksDashboardRuntime" not in page


def test_locale_keys_exist_in_all_languages() -> None:
    required = [
        "ranks.leaderboard_podium",
        "ranks.leaderboard_list",
        "ranks.leaderboard_empty",
        "ranks.leaderboard_username_only",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in required if key not in data]
        assert not missing, f"{path.name}: {missing}"


def test_css_for_leaderboard_visual_system_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1476 — Leaderboard Visual System",
        ".efhc-leaderboard-visual-system",
        ".efhc-leaderboard-visual-system__card--gold",
        ".efhc-leaderboard-visual-system__card--me",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1476 — Leaderboard Visual System" in corpus
    assert "LEADERBOARD_VISUAL_SYSTEM" in corpus
    assert "1477 — Tasks Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/LEADERBOARD_VISUAL_SYSTEM.md")
        + read("docs/NORM/LEADERBOARD_VISUAL_SYSTEM_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs
