from __future__ import annotations

from pathlib import Path


def test_shop_service_uses_centralized_bonus_then_main() -> None:
    src = Path("backend/app/services/shop_service.py")
    text = src.read_text(encoding="utf-8")
    assert "spend_user_to_bank_bonus_then_main(" in text
    assert "debit_user_bonus_to_bank(" not in text
    assert "debit_user_to_bank(" not in text
