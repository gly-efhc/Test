from pathlib import Path


def test_admin_withdrawals_page_has_regression_controls() -> None:
    src = Path("frontend/src/pages/admin/withdrawals.tsx").read_text()
    assert "Repair consistency" in src
    assert "/repair-consistency" in src
    assert "Refresh selected case" in src
    assert "Operator regression" in src


def test_withdraw_page_reads_latest_outcome_bundle() -> None:
    src = Path("frontend/src/pages/withdraw.tsx").read_text()
    service = Path("frontend/src/services/withdrawals.service.ts").read_text()
    assert "/api/v1/me/withdraw-outcomes/" in service
    assert "Latest withdraw outcome" in src
    assert "parseWithdrawOutcomeBundle" in service
