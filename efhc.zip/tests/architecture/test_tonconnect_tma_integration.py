from pathlib import Path


def test_tonconnect_provider_has_twa_return_url_and_theme_sync() -> (
    None
):
    app = Path("frontend/src/pages/_app.tsx").read_text(
        encoding="utf-8"
    )
    provider = Path(
        "frontend/src/lib/wallet-provider/WalletProvider.tsx"
    ).read_text(encoding="utf-8")
    assert "<WalletProvider" in app
    assert "manifestUrl={tcManifestUrl}" in app
    assert "returnUrl={tcReturnUrl}" in app
    assert "<TonConnectUIProvider" in provider
    assert "actionsConfiguration={{" in provider
    assert "twaReturnUrl:" in provider
    assert "uiPreferences={{" in provider
    assert "tonConnectTheme(" in provider
    assert "onTelegramThemeChanged" in app
    assert "setTgScheme(nextScheme)" in app


def test_tonconnect_manifest_has_cors_header() -> None:
    cfg = Path("frontend/next.config.js").read_text(encoding="utf-8")
    assert 'source: "/tonconnect-manifest.json"' in cfg
    assert 'key: "Access-Control-Allow-Origin"' in cfg
    assert 'value: "*"' in cfg


def test_tonconnect_modal_hides__main__button() -> None:
    layout = Path("frontend/src/components/Layout.tsx").read_text(
        encoding="utf-8",
    )
    provider = Path(
        "frontend/src/lib/wallet-provider/WalletProvider.tsx"
    ).read_text(encoding="utf-8")
    assert "hideTelegramMainButtonForWalletModal" in layout
    assert "restoreTelegramMainButtonAfterWalletModal" in layout
    assert "MainButton?.hide?.()" in layout
    assert "MainButton?.show?.()" in layout
    assert "onModalStateChange" in provider
    assert "openWalletConnect" in layout
