from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SEAMS = ROOT / (
    "frontend/src/lib/api/generated/economicUserSeams.ts"
)
VALIDATORS = ROOT / (
    "frontend/src/lib/api/generated/economicUserSeamValidators.ts"
)
GENERATORS = (
    ROOT / "ops/openapi/generate_frontend_user_economic_seams.py",
    ROOT / "ops/openapi/generate_frontend_user_economic_validators.py",
)


def test_panels_exchange_generated_seams_are_reproducible() -> None:
    before = {
        SEAMS: SEAMS.read_bytes(),
        VALIDATORS: VALIDATORS.read_bytes(),
    }
    for generator in GENERATORS:
        subprocess.run(
            [sys.executable, str(generator)],
            cwd=ROOT,
            check=True,
        )
    after = {
        SEAMS: SEAMS.read_bytes(),
        VALIDATORS: VALIDATORS.read_bytes(),
    }
    assert after == before


def test_panels_seams_include_runtime_contract() -> None:
    seams = SEAMS.read_text(encoding="utf-8")
    validators = VALIDATORS.read_text(encoding="utf-8")
    assert 'PANELS_SUMMARY_PATH' in seams
    assert 'PanelActivationResponse' in seams
    assert 'parsePanelsPageResponse' in validators
    assert 'parsePanelsSummaryResponse' in validators
    assert 'parsePanelActivationResponse' in validators
