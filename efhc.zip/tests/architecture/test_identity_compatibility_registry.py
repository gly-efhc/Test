"""Причинная приёмка semantic allowlist identity registry."""

from __future__ import annotations

import json
from pathlib import Path

from app.identity.compatibility_registry import (
    COMPATIBILITY_ALIASES,
    HISTORICAL_SCOPES,
    IDENTITY_GUARD_FILES,
    IDENTITY_NAME_POLICIES,
    build_identity_compatibility_registry,
    get_compatibility_alias,
    get_identity_name_policy,
)
from app.identity.legacy_alias import GLOBAL_ID_ALIAS_PLAN
from ops.identity.check_identity_compatibility_registry import (
    _ambiguous_contract_findings,
    _legacy_import_findings,
    проверить,
)

ROOT = Path(__file__).resolve().parents[2]
FIXTURE = ROOT / (
    "contracts/identity/compatibility_registry_v1.json"
)


def test_registry_различает_четыре_семантики() -> None:
    policies = {
        item.name: item for item in IDENTITY_NAME_POLICIES
    }
    assert set(policies) == {"global_id", "user_id", "id", "tg_id"}
    assert policies["global_id"].owner_allowed is True
    assert policies["user_id"].owner_allowed is False
    assert policies["id"].status == "local_only"
    assert policies["tg_id"].status == "provider_only"


def test_legacy_user_id_имеет_sunset_budget() -> None:
    policy = get_identity_name_policy("user_id")
    assert policy.semantic == "reverse_legacy_global_alias"
    assert policy.sunset_cycle == 1632
    assert "new_domain_owner" in policy.forbidden_new_uses


def test_compatibility_aliases_явно_зарегистрированы() -> None:
    aliases = {item.alias: item for item in COMPATIBILITY_ALIASES}
    assert aliases["User.user_id"].target == "User.global_id"
    assert aliases["User.legacy_pk"].target == "User.id"
    assert aliases["User.telegram_id"].target == "User.tg_id"
    assert aliases["UserId"].target == "GlobalId"
    assert all(item.sunset_cycle == 1632 for item in aliases.values())
    assert get_compatibility_alias("User.user_id") is aliases[
        "User.user_id"
    ]


def test_historical_scopes_не_управляют_runtime() -> None:
    assert HISTORICAL_SCOPES
    assert all(
        not item.may_define_current_runtime
        for item in HISTORICAL_SCOPES
    )


def test_fixture_воспроизводим_из_registry() -> None:
    actual = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert actual == build_identity_compatibility_registry()


def test_boundary_guard_читает_allowlist_из_registry() -> None:
    assert len(IDENTITY_GUARD_FILES) == 1
    item = IDENTITY_GUARD_FILES[0]
    assert item.path == (
        "backend/app/identity/compatibility_registry.py"
    )
    assert item.max_identifier_occurrences == 6
    assert item.semantic == "AUTH_IDENTITY"


def test_alias_plan_синхронизирован_с_ускоренным_roadmap() -> None:
    assert GLOBAL_ID_ALIAS_PLAN.physical_rename_cycle == 1631
    assert GLOBAL_ID_ALIAS_PLAN.compatibility_removal_cycle == 1632
    assert GLOBAL_ID_ALIAS_PLAN.runtime_read_switch is True


def test_exact_head_проходит_registry_guard() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["зарегистрировано_имён"] == 4
    assert result["зарегистрировано_aliases"] == 5
    assert result["цикл_удаления_совместимости"] == 1632


def test_guard_ловит_legacy_import_в_production(
    tmp_path: Path,
) -> None:
    path = tmp_path / "backend/app/services/bad.py"
    path.parent.mkdir(parents=True)
    path.write_text(
        "from app.identity.legacy_user_id import UserId\n",
        encoding="utf-8",
    )
    findings = _legacy_import_findings(tmp_path)
    assert findings[0]["причина"] == "legacy_import_in_production"


def test_guard_ловит_неопределённый_user_id_contract(
    tmp_path: Path,
) -> None:
    backend = tmp_path / "backend/app/identity/api_contract.py"
    frontend = tmp_path / "frontend/src/contracts/global-id.ts"
    backend.parent.mkdir(parents=True)
    frontend.parent.mkdir(parents=True)
    backend.write_text("user_id: str\n", encoding="utf-8")
    frontend.write_text(
        "type Bad = { user_id: string };\n",
        encoding="utf-8",
    )
    findings = _ambiguous_contract_findings(tmp_path)
    assert len(findings) == 2


def test_цикл_1608_имеет_operator_kernel_route() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    classified = classify_task(
        "Цикл 1608 semantic allowlist и compatibility registry"
    )
    assert classified["task_type"] == (
        "identity_semantic_compatibility_registry"
    )
    route = resolve_route(
        "identity_semantic_compatibility_registry",
        ROOT,
    )
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
