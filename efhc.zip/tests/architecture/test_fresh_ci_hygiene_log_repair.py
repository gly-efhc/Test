from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle1534_report_and_clean_norm_filename_exist() -> None:
    assert (ROOT / "docs/NORM/FRESH_CI_HYGIENE_LOG_REPAIR.md").exists()
    assert not (
        ROOT / "docs/NORM/CYCLE_1533_SCHEDULER_NOTIFY_FACADE_FIX_REPORT.md"
    ).exists()
    assert (ROOT / "docs/NORM/SCHEDULER_NOTIFY_FACADE_FIX_REPORT.md").exists()


def test_cycle1534_kernel_current_head_without_numbered_cycle_text() -> None:
    kernel = _read("KERNEL.md")
    assert "Canonical archive lineage:" in kernel
    assert "cycle 1533" not in kernel.lower()
    assert "cycle 1534" not in kernel.lower()


def test_cycle1534_map_records_log_repair_and_no_runtime_change() -> None:
    text = _read("map_element.md")
    assert "v171.09 / cycle 1534" in text
    assert "logs_74538464541.zip" in text
    assert "Runtime code was not copied" in text
    assert "Runtime, money-flow, wallet flow" in text


def test_cycle1534_release_status_no_false_claims() -> None:
    text = _read("docs/NORM/RELEASE_PROOF_STATUS.md")
    assert "GitHub CI green" in text
    assert "not claimed" in text.lower()
    assert "fail-closed" in text.lower()


def test_cycle1534_routes_and_report_index_updated() -> None:
    routes = _read("ops/operator_kernel/config/routes.yaml")
    reports = _read("reports/REPORTS_INDEX.md")
    assert "fresh_ci_hygiene_log_repair" in routes
    assert "fresh_ci_hygiene_log_repair_v171_09.json" in reports
