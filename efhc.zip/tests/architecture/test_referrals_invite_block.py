from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAGE = ROOT / "frontend/src/pages/referrals.tsx"
SERVICE = ROOT / "frontend/src/services/referrals.service.ts"
ROUTES = ROOT / "backend/app/routes/referrals_routes.py"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_referrals_invite_block_is_primary_surface() -> None:
    src = read(PAGE)
    assert 'data-referrals-invite-boundary="deep-link-share-1558"' in src
    assert 'data-referrals-invite-canon="1295"' in src
    assert 'data-referral-link-main="true"' in src
    assert 'data-referral-action="copy-link"' in src
    assert 'data-referral-action="share-link"' in src


def test_referrals_stats_uses_current_user_route() -> None:
    src = read(SERVICE)
    assert '"/referrals/stats/me"' in src
    banned = [
        "parent_tg_id=",
        "?tg_id=",
        "?user_id=",
        "`${base}?parent_tg_id",
    ]
    for token in banned:
        assert token not in src


def test_backend_has_referrals_stats_me_route() -> None:
    src = read(ROUTES)
    assert '"/stats/me"' in src
    assert "get_nonfinancial_read_owner" in src
    assert "Depends(" in src
    assert "def get_my_referrals_stats" in src


def test_cycle_1295_docs_are_registered() -> None:
    docs = read(PLAN) + "\n" + read(REPORTS)
    assert "v168_92 / work pass" in docs
    assert "Referrals invite block" in docs
    assert "test_referrals_invite_block.py" in docs
