"""Причинная проверка retention-policy development archive."""

from __future__ import annotations

import json
from pathlib import Path

from ops.release.development_archive_retention import (
    CURRENT_VERSION,
    PREVIOUS_VERSION,
    build_plan,
    classify_removal,
)

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / (
    "reports/generated/"
    "development_archive_retention_v172_20.json"
)
PREVIOUS_REPORT = ROOT / (
    "reports/generated/"
    "development_archive_retention_v172_19.json"
)
HISTORICAL_REPORT = ROOT / (
    "reports/generated/"
    "development_archive_retention_v172_06.json"
)


def test_policy_классифицирует_root_xlsx_duplicate(
    tmp_path: Path,
) -> None:
    path = tmp_path / "EFHC_v1_full_matrix.xlsx"
    path.write_bytes(b"xlsx")
    result = classify_removal(tmp_path, path)
    assert result is not None
    assert result[0] == "root_xlsx_дубликат"


def test_policy_переносит_current_identity_matrix(
    tmp_path: Path,
) -> None:
    path = tmp_path / (
        "reports/generated/identity_audit_"
        f"{CURRENT_VERSION}_ru/матрица_использований.json"
    )
    path.parent.mkdir(parents=True)
    path.write_text("[]", encoding="utf-8")
    result = classify_removal(tmp_path, path)
    assert result is not None
    assert result[0] == "raw_identity_в_матричный_архив"


def test_policy_переносит_previous_identity_matrix(
    tmp_path: Path,
) -> None:
    path = tmp_path / (
        "reports/generated/identity_audit_"
        f"{PREVIOUS_VERSION}_ru/матрица_использований.csv"
    )
    path.parent.mkdir(parents=True)
    path.write_text("x", encoding="utf-8")
    result = classify_removal(tmp_path, path)
    assert result is not None
    assert result[0] == "raw_identity_в_матричный_архив"


def test_exact_head_не_содержит_кандидатов_cleanup() -> None:
    assert build_plan(ROOT) == []


def test_current_retention_report_фиксирует_перемещения() -> None:
    report = json.loads(REPORT.read_text(encoding="utf-8"))
    assert report["применено"] is True
    assert report["цикл"] == 1620
    assert report["версия"] == CURRENT_VERSION
    assert report["архив_назначения"] == (
        "EFHC_Bot_v172_20_MATRIX_TECHNICAL.zip"
    )
    assert report["удалено_или_перенесено_файлов"] == 0
    assert report["освобождено_байт"] == 0
    assert report["перемещённые_файлы"] == []


def test_previous_retention_report_согласован() -> None:
    report = json.loads(
        PREVIOUS_REPORT.read_text(encoding="utf-8")
    )
    assert report["применено"] is True
    assert report["цикл"] == 1619
    assert report["версия"] == PREVIOUS_VERSION
    assert report["удалено_или_перенесено_файлов"] == 0


def test_historical_retention_report_сохраняет_sha256_manifest() -> None:
    report = json.loads(
        HISTORICAL_REPORT.read_text(encoding="utf-8")
    )
    assert report["применено"] is True
    assert report["цикл"] == 1609
    assert report["версия"] == "v172_06"
    assert report["удалено_или_перенесено_файлов"] == 35
    assert report["освобождено_байт"] == 913_208
    first = report["перемещённые_файлы"][0]
    assert len(first["sha256"]) == 64
    assert first["размер_байт"] > 0


def test_канонические_документы_и_код_сохранены() -> None:
    required = (
        "START_HERE.md",
        "backend/app/identity/types.py",
        "docs/NORM/USER_IDENTITY_MIGRATION_NORM.md",
        "docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md",
        "reports/REPORTS_INDEX.md",
    )
    assert all((ROOT / item).exists() for item in required)


def test_root_не_дублирует_audit_xlsx() -> None:
    duplicates = [
        path for path in ROOT.glob("*.xlsx")
        if "full_matrix" in path.name
    ]
    assert duplicates == []
