"""Причинная приёмка API-контракта ``global_id`` цикла 1606."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest
from app.identity import (
    GlobalId,
    GlobalIdRequest,
    GlobalIdResponse,
    PydanticGlobalId,
)
from ops.identity.check_global_id_api_contract import проверить
from ops.identity.export_global_id_api_contract import build_contract
from pydantic import TypeAdapter, ValidationError

ROOT = Path(__file__).resolve().parents[2]
FIXTURE = ROOT / "contracts/identity/global_id_api_contract_v1.json"
FRONTEND_IDENTITY = ROOT / "frontend/src/types/identity.ts"
FRONTEND_CONTRACT = ROOT / "frontend/src/contracts/global-id.ts"


def test_exact_head_соблюдает_global_id_api_contract() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["fixture_воспроизводим"] is True
    assert result["active_routes_переключены"] is False
    assert result["историческое_заполнение"] is False
    assert result["переключение_чтения"] is False


def test_fixture_точно_воспроизводится_из_backend_contract() -> None:
    actual = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert actual == build_contract()
    assert actual["поле"] == "global_id"
    assert actual["openapi_format"] == "efhc-global-id"
    assert actual["openapi_pattern"] == "^[0-9]{10}$"
    assert actual["активные_routes_переключены"] is False


@pytest.mark.parametrize(
    "key",
    [
        "схема_path_параметра",
        "схема_поля_ответа",
        "схема_pydantic_значения",
    ],
)
def test_backend_openapi_schema_только_строковая(key: str) -> None:
    schema = build_contract()[key]
    assert schema["type"] == "string"
    assert schema["format"] == "efhc-global-id"
    assert schema["pattern"] == "^[0-9]{10}$"
    assert schema["minLength"] == 10
    assert schema["maxLength"] == 10
    assert "integer" not in json.dumps(schema)


def test_backend_dto_сохраняет_ведущие_нули() -> None:
    request = GlobalIdRequest(global_id="0000000042")
    response = GlobalIdResponse.from_global_id(GlobalId(42))
    assert request.global_id == GlobalId(42)
    assert request.model_dump() == {"global_id": "0000000042"}
    assert response.model_dump_json() == (
        '{"global_id":"0000000042"}'
    )


@pytest.mark.parametrize(
    "value",
    [
        42,
        True,
        42.0,
        "42",
        "0000000000",
        "0000000042 ",
        "１２３４５６７８９０",
    ],
)
def test_backend_dto_отклоняет_неканонический_input(
    value: object,
) -> None:
    with pytest.raises(ValidationError):
        GlobalIdRequest(global_id=value)
    with pytest.raises(ValidationError):
        TypeAdapter(PydanticGlobalId).validate_python(value)


def _require_tool(name: str) -> str:
    executable = shutil.which(name)
    if executable is None:
        pytest.skip(f"Инструмент {name} отсутствует в среде.")
    return executable


def _compile_frontend_contract(tmp_path: Path) -> Path:
    tsc = _require_tool("tsc")
    source_root = tmp_path / "src"
    (source_root / "types").mkdir(parents=True)
    (source_root / "contracts").mkdir(parents=True)
    (source_root / "types/identity.ts").write_text(
        FRONTEND_IDENTITY.read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    (source_root / "contracts/global-id.ts").write_text(
        FRONTEND_CONTRACT.read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    output = tmp_path / "compiled"
    result = subprocess.run(
        [
            tsc,
            str(source_root / "types/identity.ts"),
            str(source_root / "contracts/global-id.ts"),
            "--target",
            "ES2020",
            "--module",
            "commonjs",
            "--strict",
            "--skipLibCheck",
            "--outDir",
            str(output),
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    return output / "contracts/global-id.js"


def test_frontend_dto_runtime_имеет_parity(tmp_path: Path) -> None:
    node = _require_tool("node")
    compiled = _compile_frontend_contract(tmp_path)
    script = r'''
const assert = require("node:assert/strict");
const contract = require(process.argv[1]);
const request = contract.decodeGlobalIdRequest({
  global_id: "0000000042",
});
assert.deepEqual(contract.encodeGlobalIdRequest(request), {
  global_id: "0000000042",
});
const response = contract.decodeGlobalIdResponse({
  global_id: "0000000042",
});
assert.deepEqual(contract.encodeGlobalIdResponse(response), {
  global_id: "0000000042",
});
for (const invalid of [
  {global_id: 42},
  {global_id: "0000000000"},
  {global_id: "42"},
  {global_id: "0000000042", extra: true},
  {user_id: "0000000042"},
  null,
  [],
]) {
  assert.throws(() => contract.decodeGlobalIdRequest(invalid));
}
'''
    result = subprocess.run(
        [node, "-e", script, str(compiled)],
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_frontend_contract_не_принимает_number_type(
    tmp_path: Path,
) -> None:
    tsc = _require_tool("tsc")
    source_root = tmp_path / "src"
    (source_root / "types").mkdir(parents=True)
    (source_root / "contracts").mkdir(parents=True)
    (source_root / "types/identity.ts").write_text(
        FRONTEND_IDENTITY.read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    (source_root / "contracts/global-id.ts").write_text(
        FRONTEND_CONTRACT.read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    invalid = source_root / "invalid.ts"
    invalid.write_text(
        'import type { GlobalIdRequestDto } from "./contracts/global-id";\n'
        "const bad: GlobalIdRequestDto = { global_id: 42 };\n"
        "void bad;\n",
        encoding="utf-8",
    )
    result = subprocess.run(
        [
            tsc,
            str(source_root / "types/identity.ts"),
            str(source_root / "contracts/global-id.ts"),
            str(invalid),
            "--target",
            "ES2020",
            "--module",
            "commonjs",
            "--strict",
            "--skipLibCheck",
            "--noEmit",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode != 0
    assert "number" in result.stdout + result.stderr


def test_действующие_routes_не_переключены() -> None:
    active = (
        "backend/app/routes",
        "backend/app/schemas",
        "backend/app/services",
        "backend/app/crud",
    )
    for relative in active:
        for path in (ROOT / relative).rglob("*.py"):
            source = path.read_text(encoding="utf-8")
            assert "GlobalIdRequest" not in source
            assert "GlobalIdResponse" not in source
            assert "PydanticGlobalId" not in source
            assert "ApiExternalGlobalId" not in source


def test_цикл_1606_имеет_operator_kernel_route() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    classified = classify_task("Цикл 1606 API-контракт global_id")
    assert classified["task_type"] == "global_id_api_contract"
    route = resolve_route("global_id_api_contract", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_ускоренный_roadmap_заменяет_старый_максимальный_план() -> None:
    roadmap = (
        ROOT
        / "docs/cycles/"
        "WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md"
    ).read_text(encoding="utf-8")
    assert "Статус: `ACTIVE_SSOT`" in roadmap
    assert "Циклы `1633–1700` не являются обязательными" in roadmap
