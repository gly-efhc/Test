"""Действующий provider-independent API-контракт ``global_id``."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from app.identity import (
    GlobalId,
    GlobalIdRequest,
    GlobalIdResponse,
    PydanticGlobalId,
)
from ops.identity.check_global_id_api_contract import проверить
from ops.identity.export_global_id_api_contract import build_contract
from pydantic import TypeAdapter, ValidationError

ROOT = Path(__file__).resolve().parents[2]
FIXTURE = ROOT / "contracts/identity/global_id_api_contract_v1.json"


def test_проверка_exact_head_uses_current_global_id_api_contract() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["версия"] == "v173.18"
    assert result["цикл"] == 1699
    assert result["active_contract_imports"] > 0
    assert result["numeric_global_id_schemas"] == []
    assert result["business_tg_id_response_fields"] == []
    assert result["generated_business_tg_id_fields"] == []
    assert result["deprecated_telegram_ingress_marked"] is True


def test_проверка_fixture_is_reproducible_from_current_backend_contract() -> None:
    actual = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert actual == build_contract()
    assert actual["поле"] == "global_id"
    assert actual["active_routes_use_global_id_contract"] is True
    assert actual["active_compatibility_aliases"] == 0


@pytest.mark.parametrize(
    "key",
    [
        "схема_path_параметра",
        "схема_поля_ответа",
        "схема_pydantic_значения",
    ],
)
def test_проверка_openapi_contract_is_ten_digit_string(key: str) -> None:
    schema = build_contract()[key]
    assert schema["type"] == "string"
    assert schema["format"] == "efhc-global-id"
    assert schema["pattern"] == "^[0-9]{10}$"
    assert schema["minLength"] == 10
    assert schema["maxLength"] == 10
    assert "integer" not in json.dumps(schema)


def test_проверка_backend_envelopes_preserve_leading_zeroes() -> None:
    request = GlobalIdRequest(global_id="0000000042")
    response = GlobalIdResponse.from_global_id(GlobalId(42))
    assert request.model_dump() == {"global_id": "0000000042"}
    assert response.model_dump_json() == '{"global_id":"0000000042"}'


@pytest.mark.parametrize(
    "value",
    [
        42,
        True,
        42.0,
        "42",
        "0000000000",
        "0000000042 ",
        "１２３４５６７８９０",
    ],
)
def test_проверка_backend_boundary_rejects_noncanonical_input(
    value: object,
) -> None:
    with pytest.raises(ValidationError):
        GlobalIdRequest(global_id=value)
    with pytest.raises(ValidationError):
        TypeAdapter(PydanticGlobalId).validate_python(value)


def test_проверка_frontend_contract_rejects_number_coercion() -> None:
    source = (
        ROOT / "frontend/src/contracts/global-id.ts"
    ).read_text(encoding="utf-8")
    identity = (
        ROOT / "frontend/src/types/identity.ts"
    ).read_text(encoding="utf-8")
    assert 'GLOBAL_ID_API_FIELD = "global_id"' in source
    assert 'GLOBAL_ID_OPENAPI_PATTERN = "^[0-9]{10}$"' in source
    assert "Number(" not in source
    assert "parseInt(" not in source
    assert "export type GlobalId = string" in identity
