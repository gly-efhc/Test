from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_tonconnect_is_server_safe() -> None:
    text = (
        ROOT / "frontend/src/lib/vendor/tonconnect-ui-react-compat.tsx"
    ).read_text(encoding="utf-8")
    assert 'const isBrowser = typeof window !== "undefined"' in text
    assert "createServerSafeConnector()" in text
    assert "const injectedE2e = e2eConnector();" in text
    assert "isBrowser" in text
    assert "createServerSafeConnector()" in text
    assert "loadTonConnectSdk" in text
    assert "Promise.resolve(false)" in text
