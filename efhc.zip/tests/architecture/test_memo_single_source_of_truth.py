from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_watcher_uses_ton_memo_parser_as_ssot() -> None:
    watcher = read("backend/app/services/watcher_service.py")

    assert "from app.integrations.ton_memo import" in watcher
    assert "parse_memo_for_watcher" in watcher
    assert "parse_memo_for_watcher(memo)" in watcher
    assert "_RE_SIMPLE_EFHC" not in watcher
    assert "_RE_SKU_EFHC" not in watcher
    assert "re.compile(r\"^EFHC" not in watcher


def test_direct_open_memo_has_static_bridge_to_watcher() -> None:
    route = read("backend/app/routes/deposit_routes.py")
    memo = read("backend/app/integrations/ton_memo.py")
    watcher_test = read(
        "tests/efhc_backend/watcher/"
        "test_direct_deposit_memo_runtime.py"
    )

    assert "memo = build_deposit_global_memo(owner.global_id)" in route
    assert "def parse_memo_for_watcher" in memo
    assert "build_deposit_memo" in watcher_test
    assert "_parse_memo(memo)" in watcher_test


def test_buy_pack_builder_is_supported_or_guarded() -> None:
    memo = read("backend/app/integrations/ton_memo.py")

    assert "def build_buy_pack_memo" in memo
    assert "MemoBuyEFHCPack" in memo
    assert "_RE_BUY_PACK" in memo
    assert "_RE_SKU_EFHC_LEGACY" in memo
