from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_game_word_is_allowed_and_not_a_forbidden_token() -> None:
    ssot = _read("docs/SSOT/FORBIDDEN_WORDS_AND_EXCEPTIONS_SSOT.md")
    boundary = _read("docs/SSOT/GAME_VS_GAMBLING_BOUNDARY_SSOT.md")
    guard = _read("ops/i18n/audit_forbidden_gambling_chance_contour.py")

    assert "Слово `игра` и обычный игровой слой не запрещены" in ssot
    assert "EFHC Bot разрешено описывать как игру" in boundary

    forbidden_decl = guard.split("FORBIDDEN_RE =", 1)[1].split(
        "SUSPICIOUS_RE =", 1
    )[0]
    forbidden_low = forbidden_decl.lower()
    assert not re.search(r"\bgame\b", forbidden_low)
    assert not re.search(r"(^|[^а-яё])игра([^а-яё]|$)", forbidden_low)
    assert "игров" not in forbidden_low

    for required in ["LOT", "GAMB", "bet"]:
        assert required in forbidden_decl


def test_1396_wording_matrix_is_bound_to_active_surfaces() -> None:
    matrix = _read(
        "docs/frontend/RANKS_HUB_BROWSER_SHOP_WORDING_GUARD_MATRIX.md"
    )
    report = json.loads(
        _read(
            "reports/generated/"
            "ranks_hub_browser_shop_wording_guard_v169_78.json"
        )
    )

    for surface in ["/ranks", "/hub", "/browser-shop"]:
        assert surface in matrix
        assert surface in report["surfaces"]

    assert "game_word_policy" in report
    assert report["game_word_policy"]["game_word_allowed"] is True
    assert report["game_word_policy"]["chance_prize_ban"] is True


def test_browser_shop_and_hub_wording_keep_public_boundary() -> None:
    hub = _read("frontend/src/features/hub/HubPage.tsx")
    shop = _read("frontend/src/features/browser-shop/BrowserShopPage.tsx")
    ranks = _read("frontend/src/pages/ranks.tsx")

    assert "hub.action_top_up_efhc" in hub
    assert "hub.action_vip_nft" in hub
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in hub
    assert "portal.browser_shop.storefront_title" in shop
    assert "wallet.transaction_failed" in shop
    assert "wallet.transaction_rejected" in shop
    assert "ranks.game_kicker" in ranks

    forbidden_public = [
        "Browser-Shop payment diagnostics",
        "Copy memo",
        "Copy wallet",
        "truth-layer",
        "execution path",
    ]
    combined = "\n".join([hub, shop, ranks])
    for needle in forbidden_public:
        assert needle not in combined


def test_old_guard_path_is_compatibility_shim_only() -> None:
    shim = _read("ops/i18n/audit_forbidden_gaming_contour.py")
    assert "Compatibility shim" in shim
    assert "It does not ban the word game" in shim
    assert "audit_forbidden_gambling_chance_contour" in shim

    canon = _read("ops/canon_rules.yaml")
    assert "audit_forbidden_gambling_chance_contour.py" in canon
