from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "docs/testing/TEST_GUARD_MANIFEST.json"
SCRIPT = ROOT / "scripts/ci/check_test_suite_integrity.py"


def test_test_guard_manifest_restores_architecture_tests() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    active = sorted((ROOT / "tests/architecture").glob("test_*.py"))

    assert data["incident"].startswith("v169_67")
    minimum = data["minimums"]["active_architecture_test_files"]
    cycle_1399 = data.get("cycle_1399_mapped_consolidation", {})
    if cycle_1399:
        assert cycle_1399["status"] == "USER_APPROVED_EXECUTED"
        assert cycle_1399["tests_deleted_without_mapping"] == 0
        assert cycle_1399["tests_archived_as_test_files"] == 0
        assert cycle_1399["skip_added"] == 0
        assert cycle_1399["xfail_added"] == 0
        assert minimum >= 245
    else:
        assert minimum >= 269
    assert len(active) >= minimum
    assert len(data["mappings"]) >= 271
    assert data.get("consolidations")

    missing = [
        item["active_replacement"]
        for item in data["mappings"]
        if not (ROOT / item["active_replacement"]).exists()
    ]
    assert missing == []


def test_no_archived_test_files_and_no_pytest_exclusion() -> None:
    archived = [
        str(path.relative_to(ROOT))
        for path in (ROOT / "tests").rglob("test_*.py")
        if any(part.startswith("_archived") for part in path.parts)
    ]
    assert archived == []

    pytest_ini = (ROOT / "pytest.ini").read_text(encoding="utf-8")
    assert "tests/_archived_architecture_1387" not in pytest_ini
    assert "_archived_architecture_1387" not in pytest_ini
    assert "norecursedirs" not in pytest_ini


def test_ci_test_suite_integrity_script_runs_structural_mode() -> None:
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), "--no-collect"],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=30,
        check=False,
    )
    assert proc.returncode == 0, proc.stdout
    assert "OK: test suite integrity guard passed" in proc.stdout


def test_ci_test_suite_integrity_reports_bootstrap_deps() -> None:
    text = SCRIPT.read_text(encoding="utf-8")
    assert "_assert_collect_bootstrap_dependencies" in text
    assert "pytest collect-only bootstrap dependencies" in text
    assert "backend/requirements.txt" in text
    assert "requirements-test.txt" in text
    assert "sqlalchemy" in text
    assert "except AssertionError as exc" in text
    assert "raise SystemExit(1) from None" in text
