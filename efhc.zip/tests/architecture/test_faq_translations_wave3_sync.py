from __future__ import annotations

import json
from pathlib import Path

FAQ_DIR = Path("docs/SSOT/faq_ssot")
TARGETS = {
    "4-6": {
        "da": "Hvor åbner jeg saldohistorikken i profilen?",
        "de": "Wo kann ich im Profil die Guthabenhistorie " "öffnen?",
        "en": "Where do I open the balance history in the " "profile?",
        "es": "¿Dónde abrir el historial de saldos en el " "perfil?",
        "fr": "Où ouvrir l’historique des soldes dans le profil " "?",
        "hi": "प्रोफ़ाइल में balance history कहाँ खोलें?",
        "id": "Di mana membuka riwayat saldo di profil?",
        "it": "Dove apro nel profilo la cronologia dei saldi?",
        "pl": "Gdzie w profilu otworzyć historię salda?",
        "sw": "Historia ya salio inafunguliwa wapi ndani ya " "wasifu?",
        "tr": "Profilden bakiye geçmişi nereden açılır?",
        "uk": "Де в профілі відкрити історію балансу?",
    },
    "4-7": {
        "da": "Hvor skifter jeg sprog i profilen?",
        "de": "Wo kann ich im Profil die Sprache wechseln?",
        "en": "Where do I change the language in the profile?",
        "es": "¿Dónde cambiar el idioma en el perfil?",
        "fr": "Où changer la langue dans le profil ?",
        "hi": "प्रोफ़ाइल में भाषा कहाँ बदलें?",
        "id": "Di mana mengganti bahasa di profil?",
        "it": "Dove cambio lingua nel profilo?",
        "pl": "Gdzie w profilu zmienić język?",
        "sw": "Lugha inabadilishwa wapi ndani ya wasifu?",
        "tr": "Profilden dil nereden değiştirilir?",
        "uk": "Де в профілі змінити мову?",
    },
    "4-8": {
        "da": "Hvor i Profil kan jeg åbne Wallet for at arbejde "
        "med walleten?",
        "de": "Wo kann ich im Profil Wallet für die Arbeit mit "
        "der Wallet öffnen?",
        "en": "Where in Profile can I open Wallet to work with "
        "the wallet?",
        "es": "¿Dónde abrir Wallet en Perfil para trabajar con "
        "la billetera?",
        "fr": "Où ouvrir Wallet dans Profil pour travailler "
        "avec le wallet ?",
        "hi": "प्रोफ़ाइल में Wallet कहाँ खोलें ताकि wallet के "
        "साथ काम किया जा सके?",
        "id": "Di mana membuka Wallet di Profil untuk bekerja "
        "dengan wallet?",
        "it": "Dove aprire Wallet nel Profilo per lavorare con "
        "il wallet?",
        "pl": "Gdzie w Profilu otworzyć Wallet do pracy z "
        "portfelem?",
        "sw": "Ni wapi katika Profile nifungue Wallet kwa ajili "
        "ya kufanya kazi na wallet?",
        "tr": "Profil içinde cüzdanla çalışmak için Wallet "
        "nereden açılır?",
        "uk": "Де в профілі відкрити Wallet для роботи з " "гаманцем?",
    },
    "4-9": {
        "da": "Hvor i Profil kan jeg hurtigt åbne FAQ, hvis jeg "
        "har brug for et svar?",
        "de": "Wo kann ich im Profil schnell FAQ öffnen, wenn "
        "ich eine Antwort brauche?",
        "en": "Where in Profile can I quickly open FAQ if I "
        "need an answer?",
        "es": "¿Dónde abrir rápidamente FAQ en Perfil si "
        "necesito una respuesta?",
        "fr": "Où ouvrir rapidement FAQ dans Profil si j’ai "
        "besoin d’une réponse ?",
        "hi": "अगर मुझे जवाब चाहिए तो प्रोफ़ाइल में FAQ जल्दी " "कहाँ खोलूँ?",
        "id": "Di mana cepat membuka FAQ di Profil jika saya "
        "membutuhkan jawaban?",
        "it": "Dove aprire rapidamente FAQ nel Profilo se mi "
        "serve una risposta?",
        "pl": "Gdzie w Profilu szybko otworzyć FAQ, jeśli "
        "potrzebuję odpowiedzi?",
        "sw": "Ni wapi katika Profile nifungue FAQ haraka "
        "nikihitaji jibu?",
        "tr": "Bir cevaba ihtiyacım olduğunda Profil içinde FAQ "
        "hızlıca nereden açılır?",
        "uk": "Де в профілі швидко відкрити FAQ, якщо потрібна "
        "відповідь?",
    },
    "16-7": {
        "da": "Hvorfor har jeg et højt niveau, men ikke "
        "førstepladsen i ranglisten?",
        "de": "Warum habe ich ein hohes Level, aber nicht den "
        "ersten Platz im Ranking?",
        "en": "Why is my level high, but my ranking position "
        "is not first?",
        "es": "¿Por qué tengo un nivel alto, pero mi puesto en "
        "el ranking no es el primero?",
        "fr": "Pourquoi ai-je un niveau élevé, mais pas la "
        "première place au classement ?",
        "hi": "मेरा level ऊँचा है, लेकिन ranking में मैं पहले "
        "स्थान पर क्यों नहीं हूँ?",
        "id": "Mengapa level saya tinggi, tetapi posisi "
        "peringkat saya bukan yang pertama?",
        "it": "Perché ho un livello alto ma il mio posto in "
        "classifica non è il primo?",
        "pl": "Dlaczego mam wysoki poziom, ale moje miejsce w "
        "rankingu nie jest pierwsze?",
        "sw": "Kwa nini nina level ya juu, lakini nafasi yangu "
        "kwenye rank si ya kwanza?",
        "tr": "Neden seviyem yüksek ama sıralamadaki yerim "
        "birinci değil?",
        "uk": "Чому в мене високий рівень, але місце в "
        "рейтингу не перше?",
    },
    "16-9": {
        "da": "Hvor kan jeg se min placering i ranglisten?",
        "de": "Wo sehe ich meinen Platz im Ranking?",
        "en": "Where can I see my ranking position?",
        "es": "¿Dónde veo mi posición en el ranking?",
        "fr": "Où puis-je voir ma place dans le classement ?",
        "hi": "मैं ranking में अपनी जगह कहाँ देख सकता हूँ?",
        "id": "Di mana saya bisa melihat posisi saya dalam "
        "peringkat?",
        "it": "Dove posso vedere la mia posizione in " "classifica?",
        "pl": "Gdzie widzę swoje miejsce w rankingu?",
        "sw": "Naona wapi nafasi yangu kwenye rank?",
        "tr": "Sıralamadaki yerimi nerede görürüm?",
        "uk": "Де я бачу своє місце в рейтингу?",
    },
    "18-3": {
        "da": "Hvilke tegn viser, at VIP allerede er taget i "
        "betragtning?",
        "de": "Woran sieht man, dass VIP bereits "
        "berücksichtigt wird?",
        "en": "By what signs can I tell that VIP is already "
        "taken into account?",
        "es": "¿Por qué señales se nota que VIP ya fue tenido "
        "en cuenta?",
        "fr": "Quels signes montrent que VIP est déjà pris en "
        "compte ?",
        "hi": "कौन-से संकेत दिखाते हैं कि VIP पहले से account "
        "में लिया जा चुका है?",
        "id": "Dari tanda apa terlihat bahwa VIP sudah "
        "diperhitungkan?",
        "it": "Da quali segnali si vede che VIP è già preso in "
        "considerazione?",
        "pl": "Po jakich oznakach widać, że VIP jest już "
        "uwzględniony?",
        "sw": "Ni kwa dalili gani inaweza kuonekana kuwa VIP "
        "tayari imezingatiwa?",
        "tr": "VIP’in zaten hesaba katıldığını hangi "
        "işaretlerden anlayabilirim?",
        "uk": "За якими ознаками видно, що VIP уже " "врахований?",
    },
    "18-9": {
        "da": "Hvordan kan jeg kontrollere, at VIP virkelig "
        "påvirker kontoen?",
        "de": "Wie kann ich prüfen, dass VIP den Account "
        "wirklich beeinflusst?",
        "en": "How can I check that VIP really affects the " "account?",
        "es": "¿Cómo comprobar que VIP realmente influye en la "
        "cuenta?",
        "fr": "Comment vérifier que VIP influence réellement "
        "le compte ?",
        "hi": "मैं कैसे जाँचूँ कि VIP सच में account को " "प्रभावित कर रहा है?",
        "id": "Bagaimana cara memeriksa bahwa VIP benar-benar "
        "memengaruhi akun?",
        "it": "Come posso verificare che VIP influenzi davvero "
        "l’account?",
        "pl": "Jak sprawdzić, że VIP naprawdę wpływa na konto?",
        "sw": "Ninawezaje kukagua kwamba VIP kweli inaathiri "
        "akaunti?",
        "tr": "VIP’in hesabı gerçekten etkilediğini nasıl "
        "kontrol edebilirim?",
        "uk": "Як перевірити, що VIP справді впливає на " "акаунт?",
    },
}


def _load(lang: str) -> dict:
    path = FAQ_DIR / lang / f"faq_{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _get_question(data: dict, target: str) -> str:
    sec_id, item_pos = target.split("-")
    sec = next(s for s in data["sections"] if str(s["id"]) == sec_id)
    return sec["items"][int(item_pos) - 1]["q"]


def test_translation_wave3_questions_synced_after_ru_cleanup() -> None:
    mismatches: list[str] = []
    for target, per_lang in TARGETS.items():
        for lang, expected in per_lang.items():
            data = _load(lang)
            actual = _get_question(data, target)
            if actual != expected:
                mismatches.append(f"{target}:{lang}:{actual}")
    assert not mismatches, mismatches
