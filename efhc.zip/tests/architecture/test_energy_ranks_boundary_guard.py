from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_ranks_page_does_not_render_energy_level_ladder() -> None:
    text = read("frontend/src/pages/ranks.tsx")
    for token in [
        "USER_LEVEL_SKINS",
        "LevelSkinBadge",
        "ranks.levels",
        "ranks.levels_min_kwh",
        "ranks.current_level",
        "L{myLevel}",
    ]:
        assert token not in text


def test_energy_page_displays_current_canonical_named_level() -> None:
    text = read("frontend/src/pages/index.tsx")
    assert "USER_LEVEL_SKINS" in text
    assert 'data-energy-level-name={levelName}' in text
    assert "Lvl {level}" in text
    assert "efhc-energy-progress-track" in text
    assert "width: `${visibleProgressPct}%`" in text


def test_level_skin_table_is_canonical_progression_source() -> None:
    text = read("frontend/src/lib/skins.ts")
    assert "USER_LEVEL_SKINS" in text
    assert "getUserLevel" in text
    assert "Eco Initiate" in text
    assert "Guardian of Earth" in text


def test_glossary_records_game_simulator_boundary() -> None:
    text = read("docs/SSOT/TERMS_GLOSSARY.md")
    assert "game simulator WebApp" in text
    assert "Energy progress layer" in text
    assert "Ranks leaderboard layer" in text
