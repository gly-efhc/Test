from pathlib import Path


def test_stage_real_funds_guard_present() -> None:
    text = Path("backend/app/main.py").read_text(encoding="utf-8")
    assert "ALLOW_REAL_FUNDS" in text
    assert "forbidden when ENV = stage" in text
