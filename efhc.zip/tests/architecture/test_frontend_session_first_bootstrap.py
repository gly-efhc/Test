"""Архитектурные границы frontend session-first foundation."""

from __future__ import annotations

from pathlib import Path

from ops.identity.check_frontend_session_first_bootstrap import (
    проверить,
)
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_frontend_session_first_имеет_exact_primary_route() -> None:
    task = classify_task(
        "Цикл 1620 — Frontend session-first bootstrap, hooks/query keys "
        "и provider context skeleton"
    )
    assert task["task_type"] == "frontend_session_first_bootstrap"
    route = resolve_route(task["task_type"], ROOT)
    assert route["route_name"] == "frontend_session_first_bootstrap"
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_session_first_static_guard_проходит() -> None:
    result = проверить(ROOT)
    assert result["успех"] is True, result["нарушения"]
    assert result["alembic_head"] == "0002"
    assert result["migration_files"] == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]
    assert result["openapi_paths"] == 131
    assert result["openapi_operations"] == 136


def test_common_auth_state_не_содержит_provider_subject_owner() -> None:
    provider = _read("frontend/src/auth/AuthSessionProvider.tsx")
    for forbidden in (
        "tg_id",
        "provider_subject",
        "wallet_address",
        "localStorage",
    ):
        assert forbidden not in provider
    assert "useAuthOwnerGlobalId" in provider
    assert "AuthSessionContext" in provider
    assert "subscribeAuthSessionInvalidation" in provider


def test_hooks_покрывают_session_provider_logout_telegram_ton() -> None:
    expected = (
        "useSessionRestore.ts",
        "useAuthState.ts",
        "useProviderState.ts",
        "useLogout.ts",
        "useTelegramLogin.ts",
        "useTonLogin.ts",
    )
    base = ROOT / "frontend/src/hooks/auth"
    assert all((base / name).is_file() for name in expected)


def test_telegram_login_не_сохраняет_raw_init_data() -> None:
    source = _read("frontend/src/lib/telegram-auth.ts")
    service = _read("frontend/src/services/authSession.service.ts")
    assert "requestTelegramSession" in source
    assert '"X-Telegram-Init-Data"' in service
    assert "acceptIssuedAuthSession" in source
    assert "legacyTelegramFallback" not in service
    assert "sessionStorage" not in source + service
    assert "localStorage" not in source + service


def test_generic_api_использует_только_bearer_session() -> None:
    source = _read("frontend/src/lib/api.ts")
    assert "getAuthAuthorizationHeader" in source
    assert "legacyTelegramFallback" not in source
    assert "recordLegacyTelegramFallback" not in source
    assert "X-Telegram-Init-Data" not in source
    assert "res.status === 401" in source
    assert "clearAuthSession" in source


def test_new_query_key_contract_использует_global_id_string() -> None:
    source = _read("frontend/src/queries/queryKeys.ts")
    assert 'import type { GlobalId }' in source
    assert 'session: ["auth", "session"]' in source
    assert "owner: (globalId: GlobalId)" in source
    assert "provider: (globalId: GlobalId)" in source
    assert "resource: (globalId: GlobalId" in source


def test_app_монтирует_provider_neutral_session_bootstrap() -> None:
    source = _read("frontend/src/pages/_app.tsx")
    assert 'from "../auth/AuthSessionProvider"' in source
    assert "<AuthSessionProvider>" in source
    assert "</AuthSessionProvider>" in source
