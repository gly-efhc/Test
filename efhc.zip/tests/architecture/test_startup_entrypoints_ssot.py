from pathlib import Path


def test_api_index_loads_env_before_app_import() -> None:
    src = Path("api/index.py").read_text(encoding="utf-8")
    assert src.index("load_env_files()") < src.index(
        "from app.main import app"
    )


def test_create_app_delegates_to__main__app() -> None:
    src = Path("backend/app/init.py").read_text(encoding="utf-8")
    assert "from .main import app as main_app" in src
    assert "return main_app" in src
