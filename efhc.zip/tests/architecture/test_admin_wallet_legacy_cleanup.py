from __future__ import annotations

from pathlib import Path

ROOT = Path(".")


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_wallets_service_removed_from_runtime() -> None:
    assert not Path(
        "backend/app/services/admin/admin_wallets_service.py"
    ).exists()


def test_admin_facade_does_not_import_legacy_wallet_service() -> None:
    text = _read("backend/app/services/admin/admin_facade.py")
    assert "admin_wallets_service" not in text
    assert "AdminWalletsService" not in text
    assert "crypto_wallets" not in text


def test_backend_runtime_does_not_use_crypto_wallets_for_wallets() -> None:
    offenders: list[str] = []
    for path in Path("backend/app").rglob("*.py"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "crypto_wallets" in text or "AdminWalletsService" in text:
            offenders.append(path.as_posix())
    assert offenders == []


def test_db_drift_matrix_marks_crypto_wallets_deprecated() -> None:
    text = _read("docs/NORM/DB_DRIFT_MATRIX.md")
    assert "`crypto_wallets` | removed/deprecated/not active" in text


def test_wallet_binding_canon_mentions_admin_legacy_cleanup() -> None:
    text = _read("docs/NORM/WALLET_BINDING_CANON.md")
    assert "Admin legacy wallet contour closure" in text
    assert "crypto_wallets" in text
    assert "not active wallet-binding canon" in text


def test_kernel_links_pack_02_tail_cleanup() -> None:
    text = _read("KERNEL.md")
    assert "PACK-02 tails cleanup" in text
    assert "crypto_wallets` is not active wallet-binding storage" in text


def test_map_element_links_legacy_wallet_cleanup_docs() -> None:
    text = _read("map_element.md")
    assert "docs/NORM/ADMIN_WALLET_LEGACY_CLEANUP.md" in text
    assert "docs/NORM/WALLET_BINDINGS_CANONICAL_BACKFILL.md" in text
