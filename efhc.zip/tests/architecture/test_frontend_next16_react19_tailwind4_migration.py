from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1331_migration_docs_exist() -> None:
    required = [
        (
            "docs/frontend/"
            "FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_COMPLETED.md"
        ),
        (
            "docs/audits/"
            "FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_AUDIT_V169_10.md"
        ),
        (
            "reports/change_cycle_2026-05-27_v169_10_cycle_1331_frontend_"
            "next16_react19_tailwind4_migration.md"
        ),
        (
            "reports/generated/"
            "frontend_next16_react19_tailwind4_migration_v169_10.json"
        ),
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_package_json_uses_target_frontend_runtime() -> None:
    package = json.loads(read("frontend/package.json"))
    deps = package["dependencies"]
    dev = package["devDependencies"]
    scripts = package["scripts"]

    assert deps["next"] == "16.2.6"
    assert deps["react"] == "19.2.6"
    assert deps["react-dom"] == "19.2.6"
    assert dev["tailwindcss"] == "4.3.0"
    assert dev["@tailwindcss/postcss"] == "4.3.0"
    assert dev["@types/react"].startswith("19.")
    assert dev["@types/react-dom"].startswith("19.")
    assert scripts["dev"] == "next dev --turbo"
    assert scripts["typecheck"] == "tsc --noEmit"
    assert scripts["lint"] == "npm run typecheck"
    assert "next lint" not in json.dumps(scripts)


def test_package_lock_installs_target_frontend_runtime() -> None:
    lock = json.loads(read("frontend/package-lock.json"))
    packages = lock["packages"]
    root = packages[""]

    assert root["dependencies"]["next"] == "16.2.6"
    assert root["dependencies"]["react"] == "19.2.6"
    assert root["dependencies"]["react-dom"] == "19.2.6"
    assert root["devDependencies"]["tailwindcss"] == "4.3.0"
    assert root["devDependencies"]["@tailwindcss/postcss"] == "4.3.0"
    assert packages["node_modules/next"]["version"] == "16.2.6"
    assert packages["node_modules/react"]["version"] == "19.2.6"
    assert packages["node_modules/react-dom"]["version"] == "19.2.6"
    assert packages["node_modules/tailwindcss"]["version"] == "4.3.0"
    assert (
        packages["node_modules/@tailwindcss/postcss"]["version"]
        == "4.3.0"
    )


def test_tailwind_v4_css_first_setup_is_active() -> None:
    postcss = read("frontend/postcss.config.js")
    css = read("frontend/src/styles/globals.css")
    assert '"@tailwindcss/postcss"' in postcss
    assert '@import "tailwindcss";' in css
    assert "@theme" in css
    assert "--color-efhc-gold" in css
    assert "@tailwind base" not in css
    assert "@tailwind components" not in css
    assert "@tailwind utilities" not in css
    assert not (ROOT / "frontend/tailwind.config.js").exists()


def test_cycle_plan_records_migration_and_later_shop_shift() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1331: Frontend dependency migration" in text
    assert "1332: Shop admin actions" in text
    assert "1333: Shop admin actions" in text
    assert "1334: Shop admin actions" in text
    assert "1355: Admin recovery checkpoint report" in text


def test_frontend_standard_doc_marks_runtime_as_implemented() -> None:
    text = read(
        "docs/frontend/"
        "FRONTEND_CODE_STANDARD_NEXT16_REACT19_TAILWIND4.md"
    )
    assert "active implemented frontend runtime standard" in text
    assert "frontend/package.json" in text
    assert "frontend/package-lock.json" in text
    assert "Tailwind CSS v4.3" in text
    assert "old Next.js 14 / React 18 / Tailwind CSS 3" in text
