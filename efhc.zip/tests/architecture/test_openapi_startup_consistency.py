from __future__ import annotations

import ast
import csv
import json
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def test_api_index_exports_app() -> None:
    text = (_repo_root() / "api/index.py").read_text(encoding="utf-8")
    tree = ast.parse(text)
    has_app_import = False
    has__all__app = False
    for node in tree.body:
        if (
            isinstance(node, ast.ImportFrom)
            and node.module == "app.main"
        ):
            has_app_import = any(
                alias.name == "app" for alias in node.names
            )
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if (
                    isinstance(target, ast.Name)
                    and target.id == "__all__"
                    and isinstance(node.value, ast.List | ast.Tuple)
                ):
                    has__all__app = any(
                        isinstance(el, ast.Constant)
                        and el.value == "app"
                        for el in node.value.elts
                    )
    assert has_app_import, "api/index.py must import app from app.main"
    assert has__all__app, 'api/index.py must export __all__ = ["app"]'


def test_exported_openapi_matches_ssot_route_surface() -> None:
    root = _repo_root()
    with (root / "docs/SSOT/ssot_pack/SSOT_ROUTES.csv").open(
        encoding="utf-8", newline=""
    ) as fh:
        rows = list(csv.DictReader(fh))
    expected_paths: dict[str, set[str]] = {}
    for row in rows:
        expected_paths.setdefault(row["path"], set()).add(
            row["method"].lower()
        )

    exported = json.loads(
        (root / "backend/openapi/openapi.json").read_text(
            encoding="utf-8"
        )
    )
    actual_paths = exported.get("paths", {})

    assert set(actual_paths) == set(expected_paths)
    for path, methods in expected_paths.items():
        assert set(actual_paths[path]) == methods
