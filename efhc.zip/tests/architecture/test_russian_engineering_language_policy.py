"""Тест русскоязычной инженерной доктрины цикла 1600."""

from __future__ import annotations

from pathlib import Path

from ops.quality.check_russian_engineering_language import check

ROOT = Path(__file__).resolve().parents[2]
BASELINE = ROOT / (
    "ops/quality/russian_engineering_language_baseline.json"
)


def test_новые_инженерные_артефакты_написаны_по_русски() -> None:
    result = check(ROOT, BASELINE)
    assert result["пройдено"], result["новые_нарушения"]
