from __future__ import annotations

import ast
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LANGS = [
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="ignore")


def test_bot_runtime_language_set_is_exactly_canonical_13() -> None:
    source = read("frontend/src/lib/i18n.ts")
    match = re.search(
        r"SUPPORTED_LANGS: Lang\[\] = \[(.*?)\];",
        source,
        re.DOTALL,
    )
    assert match is not None
    actual = ast.literal_eval("[" + match.group(1) + "]")
    assert len(actual) == 13
    assert set(actual) == set(LANGS)
    locale_names = sorted(
        path.stem
        for path in (ROOT / "frontend/public/locale").glob("*.json")
    )
    assert locale_names == sorted(LANGS)


def test_locale_key_parity_covers_all_13_languages() -> None:
    locale_dir = ROOT / "frontend/public/locale"
    dictionaries = {
        lang: json.loads((locale_dir / f"{lang}.json").read_text())
        for lang in LANGS
    }
    reference = set(dictionaries["ru"])
    assert reference
    for lang, dictionary in dictionaries.items():
        assert set(dictionary) == reference, lang


def test_three_language_sample_cannot_redefine_bot_scope() -> None:
    canon = read("docs/SSOT/LANGUAGE_CANON_SSOT.md")
    operator = read("docs/AI/AI_OPERATOR_RULES_EFHC.md")
    combined = canon + operator
    assert "RU/UK/EN" in combined or "RU / UK / EN" in combined
    assert "13" in combined
    assert "Google Sites" in combined
    assert "scope" in combined.lower()


def test_bottom_nav_english_visual_exception_keeps_localized_accessibility() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    norm = read("docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md")
    assert "bottom navigation stays English" in norm
    for label in [
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
    ]:
        assert f'visualLabel: "{label}"' in layout
    assert "localizedLabel={t(item.key)}" in layout
    assert "aria-label={props.localizedLabel}" in layout
    assert "title={props.localizedLabel}" in layout


def test_public_browser_proof_uses_real_browser_fallback_and_all_languages() -> None:
    proof = read("ops/frontend/public_visual_runtime_proof.py")
    assert "LANGUAGE_SET = [" in proof
    for lang in LANGS:
        assert f'    "{lang}",' in proof
    assert "_install_admin_fallback" not in proof
    assert "EFHC_USER_SETTINGS_V2" in proof
    assert "initDataUnsafe = {{}}" in proof
    assert "page.goto(" in proof
    assert "server-html-proxy" not in proof
    assert "page.set_content(" not in proof
    assert "_load_server_document" not in proof
    assert "context.route(" in proof
    assert "proxy_local=False" in proof
    assert '"/ads"' in proof
    assert "languages_total" in proof
    assert "locale_match" in proof


def test_energy_initial_runtime_has_no_zero_flash_or_fake_progress() -> None:
    page = read("frontend/src/pages/index.tsx")
    assert "base_scaled: e0ScaledRaw < 0n ? 0n : e0ScaledRaw" in page
    assert "const visibleProgressPct = displayPct" in page
    assert "Math.max(2" not in page
    assert 'data-has-progress={visibleProgressPct > 0 ? "true" : "false"}' in page


def test_document_root_follows_all_runtime_locales() -> None:
    app = read("frontend/src/pages/_app.tsx")
    assert "document.documentElement.lang = lang" in app
    assert "document.documentElement.dataset.efhcLocale = lang" in app
