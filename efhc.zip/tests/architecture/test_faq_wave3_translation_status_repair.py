from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FAQ_DIR = ROOT / "docs/SSOT/faq_ssot"
LANGS = [
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]
WAVE3_LANGS = [
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]
ALLOWED_IDENTICAL_QUESTION_ITEMS = set(range(221, 233))


def _load(lang: str) -> dict:
    return json.loads(
        (FAQ_DIR / lang / f"faq_{lang}.json").read_text(
            encoding="utf-8"
        )
    )


def _flat(data: dict) -> list[dict[str, str]]:
    items: list[dict[str, str]] = []
    for section in data["sections"]:
        for item in section["items"]:
            items.append({"q": item["q"], "a": item["a"]})
    return items


def test_faq_wave3_languages_have_shape_and_no_identical_answers() -> (
    None
):
    en_items = _flat(_load("en"))
    assert len(en_items) == 250
    for lang in LANGS:
        items = _flat(_load(lang))
        assert len(items) == 250, lang
        if lang == "en":
            continue
        identical_answers = [
            idx
            for idx, (en_item, item) in enumerate(
                zip(en_items, items, strict=True), start=1
            )
            if item["a"] == en_item["a"]
        ]
        assert identical_answers == [], f"{lang}: {identical_answers}"


def test_remaining_identical_faq_questions_are_canonical_level_names_only() -> (
    None
):
    en_items = _flat(_load("en"))
    for lang in LANGS:
        if lang == "en":
            continue
        items = _flat(_load(lang))
        identical_questions = {
            idx
            for idx, (en_item, item) in enumerate(
                zip(en_items, items, strict=True), start=1
            )
            if item["q"] == en_item["q"]
        }
        assert (
            identical_questions <= ALLOWED_IDENTICAL_QUESTION_ITEMS
        ), (
            lang,
            sorted(
                identical_questions - ALLOWED_IDENTICAL_QUESTION_ITEMS
            ),
        )


def test_faq_translation_status_and_generated_evidence_are_updated() -> (
    None
):
    status = (FAQ_DIR / "TRANSLATION_STATUS.md").read_text(
        encoding="utf-8"
    )
    assert "SEMANTIC_ALIGNED_TO_RU_QA" in status
    assert (
        "structural parity" in status and "semantic alignment" in status
    )
    doc = ROOT / "docs/frontend/FAQ_WAVE3_TRANSLATION_STATUS_REPAIR.md"
    audit = (
        ROOT
        / "docs/audits/FAQ_WAVE3_TRANSLATION_REPAIR_AUDIT_V169_49.md"
    )
    generated = (
        ROOT
        / "reports/generated/faq_wave3_translation_repair_v169_49.json"
    )
    assert doc.exists()
    assert audit.exists()
    assert generated.exists()
    data = json.loads(generated.read_text(encoding="utf-8"))
    assert data["cycle"] == "1371"
    assert (
        data["checks"]["no_identical_answers_in_non_en_langs"] is True
    )


def test_frontend_faq_catalog_regenerated_from_repaired_ssot() -> None:
    catalog = (ROOT / "frontend/src/data/faq/catalogs.ts").read_text(
        encoding="utf-8"
    )
    for phrase in [
        "Warum wird die Haupt-Wallet benötigt?",
        "Pourquoi le portefeuille principal est-il nécessaire ?",
        "¿Para qué se necesita la billetera principal?",
        "मुख्य वॉलेट की आवश्यकता क्यों है?",
        "Kwa nini pochi kuu inahitajika?",
    ]:
        assert phrase in catalog
