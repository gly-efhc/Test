"""Fail-closed cross-layer identity guard цикла 1705."""
from __future__ import annotations

from ops.identity.check_cross_layer_consistency import build_report


def test_cross_layer_identity_consistency_проходит() -> None:
    report = build_report()
    assert report["status"] == "PASS", report["failed"]
    assert report["checks"]["admin_backend_session_global_id"] is True
    assert report["checks"]["frontend_admin_server_checked"] is True
    assert report["checks"]["withdrawals_no_role_escalation"] is True
    assert report["checks"]["provider_subject_canon"] is True
