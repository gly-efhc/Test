"""Machine guard канона работы по пользовательским CI-логам."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CANON = ROOT / "docs/NORM/USER_PROVIDED_CI_LOGS_REPAIR_CANON.md"
HANDOFF = ROOT / "CONTINUE_IN_NEW_CHAT.md"
KERNEL = ROOT / "KERNEL.md"
AGENTS = ROOT / "AGENTS.md"
CLAUDE = ROOT / "CLAUDE.md"


def test_канон_работы_по_пользовательским_ci_логам_существует() -> None:
    text = CANON.read_text(encoding="utf-8")
    required = (
        "полный ZIP с логами GitHub CI",
        "запускать собственный полный CI",
        "запускать полный локальный pytest",
        "делить весь проект на множество test-shards",
        "следующий exact-head GitHub CI пользователя",
    )
    for marker in required:
        assert marker in text


def test_каждый_handoff_содержит_обязательный_запрет() -> None:
    text = HANDOFF.read_text(encoding="utf-8")
    assert "Обязательный канон работы" in text
    assert "глупые, бессмысленные и дублирующие" in text
    assert "короткие точечные проверки" in text
    assert "следующий exact-head GitHub CI пользователя" in text


def test_operator_entrypoints_ссылаются_на_канон() -> None:
    marker = "USER_PROVIDED_CI_LOGS_REPAIR_CANON.md"
    for path in (KERNEL, AGENTS, CLAUDE):
        assert marker in path.read_text(encoding="utf-8")
