"""Release v171.70 clean-database and one-command boot guards."""

from __future__ import annotations

import subprocess
from pathlib import Path

import yaml
from app.release.database_contract import (
    EXPECTED_TABLE_COUNT,
    expected_tables,
)

ROOT = Path(__file__).resolve().parents[2]


def test_migration_has_no_document_runtime_dependency() -> None:
    text = (
        ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    assert "SSOT_TABLES_ORM.csv" not in text
    assert "expected_tables()" in text
    assert "EXPECTED_TABLE_COUNT" in text
    assert len(expected_tables()) == EXPECTED_TABLE_COUNT == 48


def test_compose_has_migrate_and_scheduler_gates() -> None:
    data = yaml.safe_load(
        (ROOT / "docker-compose.release.yml").read_text(
            encoding="utf-8"
        )
    )
    services = data["services"]
    assert set(services) == {
        "db",
        "migrate",
        "backend",
        "scheduler",
        "frontend",
        "proxy",
    }
    assert services["backend"]["depends_on"]["migrate"][
        "condition"
    ] == "service_completed_successfully"
    assert services["scheduler"]["depends_on"]["migrate"][
        "condition"
    ] == "service_completed_successfully"
    assert "app.release.database_bootstrap" in " ".join(
        services["migrate"]["command"]
    )
    assert "healthcheck" in services["scheduler"]
    assert "ports" not in services["db"]
    assert "ports" not in services["backend"]
    migrate_env = services["migrate"]["environment"]
    for secret in (
        "TELEGRAM_BOT_TOKEN",
        "TELEGRAM_WEBHOOK_SECRET",
        "TON_API_KEY",
        "SECRET_KEY",
        "CRON_SECRET",
    ):
        assert secret not in migrate_env


def test_webhook_and_ton_env_are_canonical() -> None:
    env = (ROOT / "env.release.example").read_text(
        encoding="utf-8"
    )
    assert "TELEGRAM_WEBHOOK_PATH=/api/tg/webhook" in env
    assert "WEBHOOK_URL=https://api.example.org/api/tg/webhook" in env
    assert "TON_API_BASE_URL=https://tonapi.io" in env
    assert "TON_API_URL=" not in env
    assert "TON_WALLET=" not in env
    for name in (
        "TON_MAIN_WALLET",
        "TON_NFT_COLLECTION",
        "TON_WALLET_ADDRESS",
        "BANK_EFHC",
    ):
        assert f"{name}=" in env


def test_ranks_service_matches_cache_model() -> None:
    text = (
        ROOT / "backend/app/services/ranks_service.py"
    ).read_text(encoding="utf-8")
    assert "c.username" not in text
    assert "c.is_vip" not in text
    assert "JOIN efhc_core.users u" in text
    assert "bucket, snapshot_at, global_id, tg_id" in text
    assert "rank_position" in text
    assert "ranks.last_snapshot_at" in text


def test_admin_routes_use_exact_transfer_model() -> None:
    text = (
        ROOT / "backend/app/crud/admin/admin_crud.py"
    ).read_text(encoding="utf-8")
    assert "from app.models.transactions_models import EfhcTransferLog" in text
    assert "EfhcTransfersLog" not in text


def test_reconciliation_is_enabled_in_run_once() -> None:
    text = (
        ROOT / "backend/app/scheduler/check_ton_inbox.py"
    ).read_text(encoding="utf-8")
    assert "_next_reconcile_tick" in text
    assert "scheduler.ton_reconcile_last_success_at" in text
    assert "run_tick(db, do_reconcile=False)" not in text


def test_only_deploy_is_documented_as_first_start() -> None:
    readme = (ROOT / "release_docs/README.md").read_text(
        encoding="utf-8"
    )
    assert "./scripts/release/deploy.sh" in readme
    assert "Do not create database tables manually" in readme


def test_release_scripts_are_executable_and_parse() -> None:
    for path in (ROOT / "scripts/release").glob("*"):
        if path.suffix not in {".sh", ".py"}:
            continue
        assert path.stat().st_mode & 0o111
        command = (
            ["bash", "-n", str(path)]
            if path.suffix == ".sh"
            else ["python", "-m", "py_compile", str(path)]
        )
        result = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr


def test_clean_first_boot_task_uses_exact_kernel_route() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    query = (
        "Подготовить EFHC_Bot_v171_70_RELEASE: чистый первый "
        "production-запуск на пустом VPS, Alembic, 45 таблиц, "
        "admin routes и one-command deploy"
    )
    task = classify_task(query)
    assert task["task_type"] == "clean_first_boot_release"
    route = resolve_route(task["task_type"])
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "clean_first_boot_release_candidate"


def test_release_gate_does_not_create_python_cache() -> None:
    gate = (
        ROOT / "ops/release/provider_portability_gate.py"
    ).read_text(encoding="utf-8")
    assert '"py_compile"' not in gate
    assert 'compile(' in gate
