from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_diagnostics_boundary_component_exists() -> None:
    path = (
        ROOT
        / "frontend/src/components/admin/"
        / "AdminDiagnosticsTechnicalBoundaryPanel.tsx"
    )
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert 'data-admin-diagnostics-boundary-cycle="1345"' in text
    assert "chart-area-interactive" in text
    assert "data-table" in text
    assert "MaterialM status cards" in text
    assert "no business mutation" in text


def test_diagnostics_page_uses_boundary_panel() -> None:
    text = read("frontend/src/pages/admin/diagnostics.tsx")
    assert "AdminDiagnosticsTechnicalBoundaryPanel" in text
    assert "AdminDiagnosticsTechnicalBoundaryPanel />" in text


def test_public_interactivity_plan_exists() -> None:
    path = (
        ROOT
        / "docs/frontend/"
        / "FRONTEND_PUBLIC_INTERACTIVITY_IMPLEMENTATION_PLAN.md"
    )
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    for marker in (
        "Public Energy interactive overview",
        "Public Panels activation preview",
        "Public Exchange interactive preview",
        "no admin/debug/internal labels",
        "Песочница",
    ):
        assert marker in text


def test_diagnostics_cycle_docs_exist() -> None:
    assert (
        ROOT / "docs/admin/ADMIN_DIAGNOSTICS_TECHNICAL_BOUNDARY.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/"
        / "FRONTEND_CYCLE_1345_ADMIN_DIAGNOSTICS_BOUNDARY_AUDIT_V169_24.md"
    ).exists()
    assert (
        ROOT
        / "reports/"
        / "change_cycle_2026-05-31_v169_24_cycle_1345_admin_diagnostics_boundary.md"
    ).exists()


def test_cycle_plan_advances_after_1345() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1345: Diagnostics technical-only boundary" in text
    assert "DONE in v169_24" in text
    assert "1346 — Tasks/Reports/Diagnostics proof pass" in text


def test_ci_yml_manual_boundary_remains_documented() -> None:
    text = read("docs/AI/AI_OPERATOR_RULES_EFHC.md")
    assert "CI files are manual-control" in text
    component = read(
        "frontend/src/components/admin/"
        "AdminDiagnosticsTechnicalBoundaryPanel.tsx"
    )
    assert "Workflow files остаются manual-control" in component
