from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHATS = ROOT / "docs" / "NORM" / "CHATS"
REPORT = (
    ROOT
    / "reports"
    / "generated"
    / "ci_evidence_chat_docs_test_consolidation_v171_02.json"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_chat_34_and_35_are_canonical_docs() -> None:
    for name in ("34.md", "35.md"):
        path = CHATS / name
        assert path.exists(), name
        assert path.stat().st_size > 1000, name
        assert "EFHC Bot" in read(path), name


def test_chat_index_and_readme_link_recent_chats() -> None:
    index = read(CHATS / "CHATS_INDEX.md")
    readme = read(CHATS / "README.md")
    for name in ("34.md", "35.md"):
        rel = f"docs/NORM/CHATS/{name}"
        assert f"`{name}`" in index
        assert rel in index
        assert f"`{name}`" in readme


def test_no_branch_duplicates_for_recent_chats() -> None:
    branch_dir = ROOT / "docs" / "NORM" / "CHAT_BRANCHES"
    for name in ("34.md", "35.md"):
        assert not (branch_dir / name).exists(), name


def test_cycle_1527_proposal_status_is_preserved() -> None:
    doc = read(
        ROOT / "docs" / "NORM" / "TEST_GUARD_CONSOLIDATION_CANDIDATES.md"
    )
    assert "cycle 1527 proposal" in doc
    assert "Chat docs intake guards — EXECUTED IN CYCLE 1528" in doc
    assert "old test -> protected meaning -> new active test" in doc


def test_cycle_1527_report_is_fail_closed() -> None:
    data = json.loads(read(REPORT))
    assert data["cycle"] == 1527
    assert data["version"] == "v171.02"
    assert data["logs_zip_provided"] is False
    assert data["log_repair_claimed"] is False
    assert data["github_ci_green_claimed"] is False
    assert data["release_ready_claimed"] is False
    assert data["test_consolidation"] == "PROPOSAL_ONLY_NO_TESTS_MERGED"
