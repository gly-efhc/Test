from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (ROOT / path).read_text()


def test_cycle1531_panels_cursor_uses_payload_dict():
    text = _read("backend/app/services/panels_service.py")
    assert "encode_cursor(\n            {" in text
    assert "encode_cursor(\n            ts=" not in text


def test_cycle1531_scheduler_signature_and_return_shape_fixed():
    text = _read("backend/app/scheduler/archive_panels.py")
    assert "limit=int(S.PANELS_ARCHIVE_BATCH_SIZE)" in text
    assert "batch_size=int(S.PANELS_ARCHIVE_BATCH_SIZE)" not in text
    assert 'return {"archived": int(res)}' in text
    assert ".get(\"archived\"" not in text


def test_cycle1531_bot_signature_calls_fixed():
    referrals = _read("backend/app/bot/handlers/referrals_handlers.py")
    ranks = _read("backend/app/bot/handlers/ranks_handlers.py")
    assert "inviter_tg_id=tg_id" in referrals
    referral_call = referrals.split("stats = await get_referral_stats", 1)[1]
    referral_call = referral_call.split("inactive_count =", 1)[0]
    assert "\n        tg_id=" not in referral_call
    assert "top_limit=10" in ranks
    assert "me, top, meta = await get_user_rank_and_top" in ranks
    assert "logger.exception" in ranks


def test_cycle1531_nft_and_decimal_signature_calls_fixed():
    nft = _read("backend/app/routes/nft_routes.py")
    obs = _read("backend/app/routes/admin_observability_routes.py")
    reports = _read("backend/app/routes/admin_reports_routes.py")
    assert "wallet=wallet" in nft
    assert "collection=collection" in nft
    assert "wallet_address=wallet" not in nft
    assert "collection_address=collection" not in nft
    assert "places=8" not in obs
    assert "places=8" not in reports
    assert "decimals=8" in obs
    assert "decimals=8" in reports
