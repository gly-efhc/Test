from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_active_kernel_full_dispatch_role_restored() -> None:
    kernel = read("KERNEL.md")
    low = kernel.casefold()
    assert "active operator kernel / full detailed dispatch layer" in low
    assert "it is not only navigation" in low
    assert "navigation only" not in low.replace("demoted to navigation-only", "").replace("demoting kernel to navigation-only", "").replace("navigation-only", "")
    for token in (
        "keywords",
        "canonical anchors",
        "route-backed",
        "v171.47",
        "six bottom buttons",
        "tonconnect",
        "tonproof",
        "screenshots",
        "development archive",
        "release archive",
    ):
        assert token in low


def test_preserved_reference_and_kernel_ssot_exist() -> None:
    preserved = read("docs/AI/PRESERVED_OPERATOR_KERNEL_v171_47_FULL.md")
    assert "EFHC Bot Operator Kernel" in preserved
    assert "v171_46" in preserved
    ssot = read("docs/SSOT/EFHC_OPERATOR_KERNEL_SSOT.md")
    assert "active detailed operational dispatch layer" in ssot
    assert "must not be demoted to navigation-only" in ssot


def test_startup_uses_summary_not_full_machine_or_healer_read() -> None:
    start = read("START_HERE.md")
    assert "file_map.summary.json" in start
    assert "запрещено полностью загружать" in start
    assert "HEALER_CAPSULE.md" in start
    assert "file_map.json" in start
    assert "EFHC_OPERATOR_KERNEL_STANDARD.md" in start
