from pathlib import Path

from ops.operator_kernel.context_capsule import build_context_capsule
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
QUERY = """Задача: EFHC_Bot_v171_63_CYCLE_1573_CLOSE_ROUTE_BACKED_VISUAL_AND_LIVE_TON_PROOF. Оптимизируй kernel, SSOT, канон и AI. Прочитай документы и удали дубли, объедини одинаковые по смыслу, проверь длину названий. Дай отчёт сколько весят документы аудиты логи циклы. Это последний цикл в этом чате. Жду новый архив."""


def test_compound_request_keeps_exact_cycle_as_primary() -> None:
    result = classify_task(QUERY)
    assert result["task_type"] == "cycle_1573_close_visual_live_proof"
    assert "control_docs_optimization" in result["secondary_task_types"]
    assert result["task_type"] != "exchange_repair"


def test_compound_and_control_routes_are_yaml_primary() -> None:
    primary = resolve_route("cycle_1573_close_visual_live_proof")
    secondary = resolve_route("control_docs_optimization")
    assert primary["route_name"] == "cycle_1573_close_route_backed_visual_live_ton_proof"
    assert primary["config_primary"] is True
    assert secondary["route_name"] == "control_docs_optimization"
    assert secondary["config_primary"] is True


def test_context_capsule_combines_routes_without_full_map_preload(tmp_path: Path) -> None:
    capsule = build_context_capsule(QUERY, root=ROOT, archive_name="EFHC_Bot_v171_63")
    assert "primary route: cycle_1573_close_route_backed_visual_live_ton_proof" in capsule
    assert "control_docs_optimization" in capsule
    start_section = capsule.split("## Start core", 1)[1].split("## Canonical anchors", 1)[0]
    assert "file_map.summary.json" in start_section
    assert "file_map.json" not in start_section
