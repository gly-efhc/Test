from __future__ import annotations

import json
import re
from pathlib import Path

ADMIN_SEAMS = Path("frontend/src/lib/api/generated/adminSeams.ts")
FRONTEND_ADMIN = Path("frontend/src/pages/admin")
CLIENT = Path("frontend/src/lib/api.ts")


def _admin_paths_in_openapi() -> set[str]:
    data = json.loads(Path("backend/openapi/openapi.json").read_text())
    return {
        str(path)
        for path in data.get("paths", {})
        if str(path).startswith("/admin")
    }


def _admin_seam_paths() -> set[str]:
    seams = ADMIN_SEAMS.read_text(encoding="utf-8")
    return set(re.findall(r'"(/admin[^"]*)" as const', seams))


def test_admin_seams_exports_all_admin_openapi_paths() -> None:
    paths = _admin_paths_in_openapi()
    seams = _admin_seam_paths()
    missing = sorted(paths - seams)
    extra = sorted(seams - paths)
    assert not missing, "Missing admin seam constants: " + repr(missing)
    assert not extra, "Stale extra admin seam constants: " + repr(extra)
    assert len(paths) == 57
    assert len(seams) == 57


def test_admin_pages_have_zero_raw_api_request_calls() -> None:
    raw_hits: list[str] = []
    patterns = [
        re.compile(r"apiRequest\s*\(\s*[`'\"]\s*/admin"),
        re.compile(r"apiRequest\s*\(\s*ADMIN_"),
        re.compile(r"from\s+[`'\"]\.\./\.\./lib/api[`'\"]"),
    ]
    for path in sorted(FRONTEND_ADMIN.rglob("*.tsx")):
        src = path.read_text(encoding="utf-8")
        for pattern in patterns:
            for match in pattern.finditer(src):
                line = src[: match.start()].count(chr(10)) + 1
                raw_hits.append(f"{path}:{line}:{match.group(0)}")
    assert not raw_hits, "Admin pages must use adminSeams only: " + repr(raw_hits)


def test_admin_seams_is_only_admin_api_entrypoint_wrapper() -> None:
    seams = ADMIN_SEAMS.read_text(encoding="utf-8")
    assert "export async function adminApiRequest" in seams
    assert "export function adminPath" in seams
    assert "apiRequest<T>(path, method, opts)" in seams
    assert CLIENT.exists()
