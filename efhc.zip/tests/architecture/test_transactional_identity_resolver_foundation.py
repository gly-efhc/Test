"""Architecture guards transactional IdentityResolver цикла 1612."""

from __future__ import annotations

import ast
import inspect
import json
from pathlib import Path

import yaml
from alembic.config import Config
from alembic.script import ScriptDirectory
from app.identity import (
    IdentityResolver,
    PostgreSQLIdentityResolver,
    build_identity_resolver_contract,
)
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
RUNTIME = ROOT / "backend/app/identity/identity_resolver.py"


def _called_names(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            names.add(ast.unparse(node.func))
    return names


def test_kernel_route_1612_является_exact_primary() -> None:
    task = classify_task(
        "Цикл 1612 — transactional IdentityResolver, "
        "PostgreSQL locks и запрет auto-merge"
    )
    assert task["task_type"] == "transactional_identity_resolver"
    assert task["confidence"] >= 0.99
    route = resolve_route(task["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert RUNTIME.relative_to(ROOT).as_posix() in route["docs"]
    restricted = " ".join(route["restricted"])
    assert "account creation" in restricted
    assert "auth sessions" in restricted


def test_runtime_реализует_protocol_без_signature_drift() -> None:
    assert isinstance(PostgreSQLIdentityResolver, type)
    method = IdentityResolver.resolve_verified_identity
    runtime = PostgreSQLIdentityResolver.resolve_verified_identity
    assert tuple(inspect.signature(method).parameters) == (
        "self",
        "identity",
    )
    assert tuple(inspect.signature(runtime).parameters) == (
        "self",
        "identity",
    )


def test_runtime_использует_две_postgresql_lock_boundaries() -> None:
    text = RUNTIME.read_text(encoding="utf-8")
    calls = _called_names(RUNTIME)
    assert "pg_advisory_xact_lock" in text
    assert ".with_for_update()" in text
    assert "session.begin" in calls
    assert "session.commit" not in calls


def test_runtime_не_содержит_create_merge_session_или_finance() -> None:
    text = RUNTIME.read_text(encoding="utf-8")
    forbidden = (
        "INSERT INTO",
        "UPDATE users",
        "DELETE FROM",
        "session.add",
        "create_user",
        "create_account",
        "auto_merge=True",
        "issue_session",
        "main_balance",
        "bonus_balance",
        "total_generated_kwh",
    )
    for marker in forbidden:
        assert marker not in text


def test_machine_contract_совпадает_с_json_ssot() -> None:
    path = (
        ROOT
        / "contracts/identity/identity_resolver_contract_v1.json"
    )
    actual = json.loads(path.read_text(encoding="utf-8"))
    assert actual == build_identity_resolver_contract()
    assert actual["side_effects"]["auto_merge"] is False
    assert actual["side_effects"]["financial_update"] is False


def test_identity_resolver_входит_в_single_release_schema() -> None:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    assert script.get_heads() == ["0001"]
    assert script.get_revision("0001").down_revision is None

def test_routes_yaml_фиксирует_границы_цикла_1612() -> None:
    data = yaml.safe_load(
        (ROOT / "ops/operator_kernel/config/routes.yaml").read_text(
            encoding="utf-8"
        )
    )
    route = data["tasks"]["transactional_identity_resolver"]
    validation = " ".join(route["validation"])
    restricted = " ".join(route["restricted"])
    assert "pg_advisory_xact_lock" in validation
    assert "SELECT FOR UPDATE" in validation
    assert "conflict fail closed" in validation
    assert "auto-merge" in restricted
    assert "migration 0001" in restricted
    assert "business owner" in restricted


