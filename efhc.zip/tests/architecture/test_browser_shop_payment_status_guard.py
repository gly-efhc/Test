from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAGE = ROOT / "frontend/src/features/browser-shop/BrowserShopPage.tsx"
SERVICE = ROOT / "frontend/src/services/browserShop.service.ts"
VALIDATORS = (
    ROOT
    / "frontend/src/lib/api/generated/economicUserSeamValidators.ts"
)
GENERATOR = (
    ROOT / "ops/openapi/generate_frontend_user_economic_validators.py"
)
LOCALE_DIR = ROOT / "frontend/public/locale"
PAGES_DIR = ROOT / "frontend/src/pages"
FRONTEND_SRC = ROOT / "frontend/src"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_browser_shop_polls_payment_status_after_wallet_open() -> None:
    src = _read(PAGE)
    service_ts = _read(SERVICE)
    hooks = _read(ROOT / "frontend/src/queries/useBrowserShop.ts")

    assert "SHOPFRONT_INTENT_STATUS_PATH" in service_ts
    assert "parsePaymentIntentStatusResponse" in service_ts
    assert "activeIntentId" in src
    assert "useBrowserShopIntentStatus" in src
    assert "setActiveIntentId(parsed.intent_id)" in src
    assert "refetchInterval" in hooks
    assert "5_000" in hooks
    assert "TERMINAL" in hooks
    assert "CONFIRMED" in src
    assert "terminal_success" in src
    assert 'data-browser-shop-polling="react-query-5000ms"' in src


def test_payment_status_parser_keeps_flow_truth() -> None:
    validators = _read(VALIDATORS)
    generator = _read(GENERATOR)

    assert "flow_truth: PaymentIntentFlowTruthSchema" in validators
    assert "flow_truth: PaymentIntentFlowTruthSchema" in generator


def test_payment_status_locale_keys_exist() -> None:
    required = {
        "portal.browser_shop.payment_done_detail",
        "portal.browser_shop.payment_error_detail",
        "portal.browser_shop.payment_status_poll_error",
    }
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(key for key in required if not data.get(key))
        assert not missing, f"{path.name}: {missing}"


def test_static_frontend_route_links_have_pages() -> None:
    pages: set[str] = set()
    for path in PAGES_DIR.rglob("*.tsx"):
        rel = str(path.relative_to(PAGES_DIR))
        if rel == "app.tsx":
            continue
        route = "/" + rel[:-4].replace("/index", "")
        if route == "/index":
            route = "/"
        pages.add(route.rstrip("/") or "/")

    missing: list[tuple[str, str]] = []
    pattern = re.compile(
        r"(?:href=|router\.push\(|window\.location\.assign\()"
        r"\s*(?:\{|\()?\s*[`\"](/[^`\"?#)]+)"
    )
    for path in FRONTEND_SRC.rglob("*.tsx"):
        src = path.read_text(encoding="utf-8", errors="replace")
        for match in pattern.finditer(src):
            ref = match.group(1).rstrip("/") or "/"
            last = ref.rsplit("/", 1)[-1]
            if "." in last:
                continue
            if ref not in pages:
                missing.append((str(path.relative_to(ROOT)), ref))

    assert missing == []
