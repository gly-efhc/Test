from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/MINI_CHARTS_FOUNDATION.md"
TSX = ROOT / "frontend/src/components/dashboard/MiniCharts.tsx"
SIM = ROOT / "frontend/src/components/dashboard/SimulationDashboardUiKit.tsx"
ADMIN = ROOT / "frontend/src/components/admin/AdminDashboardUiKit.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
MAP = ROOT / "map_element.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
REPORT = ROOT / "reports/generated/mini_charts_foundation_v170_40.json"
KERNEL = ROOT / "KERNEL.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_mini_charts_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_MINI_CHARTS_FOUNDATION" in text
    assert "DashboardMiniSparkline" in text
    assert "DashboardMiniAreaChart" in text
    assert "DashboardMiniBarChart" in text
    assert "DashboardActivityStrip" in text
    assert "No Grafana source code is copied" in text


def test_mini_chart_runtime_components_exist() -> None:
    text = read(TSX)
    required = [
        "export function DashboardMiniSparkline",
        "export function DashboardMiniAreaChart",
        "export function DashboardMiniBarChart",
        "export function DashboardActivityStrip",
        "buildMiniChartPolyline",
        "normalizeMiniChartPoints",
        "EFHC_MINI_CHARTS_V1",
        "data-mini-chart-data-kind",
        "data-mini-chart-synthetic",
    ]
    for marker in required:
        assert marker in text
    forbidden = ["@grafana/", "uPlot", "recharts", "chart.js"]
    for marker in forbidden:
        assert marker not in text


def test_mini_chart_polyline_uses_safe_scaling() -> None:
    text = read(TSX)
    assert "DEFAULT_WIDTH = 120" in text
    assert "DEFAULT_HEIGHT = 38" in text
    assert "Number.isFinite(value)" in text
    assert "height - ((value - min) / range)" in text
    assert "points.length === 1" in text


def test_simulation_and_admin_kits_expose_mini_chart_wrappers() -> None:
    sim = read(SIM)
    admin = read(ADMIN)
    for marker in [
        "SimMiniSparkline",
        "SimMiniAreaChart",
        "SimMiniBarChart",
        "SimActivityStrip",
        "EFHC_SIM_MINI_CHARTS_V1",
    ]:
        assert marker in sim
    for marker in [
        "AdminSparkline",
        "AdminAreaChart",
        "AdminMiniBarChart",
        "AdminHeatStrip",
        "EFHC_ADMIN_MINI_CHARTS_V1",
    ]:
        assert marker in admin


def test_mini_chart_css_uses_dashboard_tokens() -> None:
    css = read(CSS)
    required = [
        "Dashboard Mini Charts Foundation",
        ".efhc-mini-chart",
        ".efhc-mini-chart__svg",
        ".efhc-mini-chart-bars",
        ".efhc-mini-chart-activity",
        "var(--efhc-dash-info)",
        "var(--efhc-dash-border)",
    ]
    for marker in required:
        assert marker in css


def test_grafana_mini_chart_map_is_reference_only() -> None:
    for path in [MAP, GRAFANA_MAP]:
        text = read(path)
        for marker in [
            "Sparkline/Sparkline.tsx",
            "TimeSeriesPanel.tsx",
            "TrendPanel.tsx",
            "XYChartPanel.tsx",
            "StatusHistoryPanel.tsx",
            "StateTimelinePanel.tsx",
        ]:
            assert marker in text
        assert "No Grafana source code is copied" in text


def test_mini_chart_report_and_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1464
    assert data["version"] == "v170.40"
    assert data["boundaries"]["economy_changed"] is False
    assert data["boundaries"]["backend_contracts_changed"] is False
    assert data["boundaries"]["db_migrations_changed"] is False
    assert data["boundaries"]["new_dependencies_added"] is False
    assert data["boundaries"]["grafana_runtime_code_copied"] is False
    assert data["boundaries"]["sandbox_runtime_code_copied"] is False


def test_navigation_points_to_mini_charts_foundation() -> None:
    for path in [KERNEL, MAP, ROUTES]:
        text = read(path)
        assert "MINI_CHARTS_FOUNDATION" in text
        assert "MiniCharts.tsx" in text
        assert "test_mini_charts_foundation.py" in text


def test_grafana_archive_contains_mini_chart_reference_files() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "Sparkline/Sparkline.tsx",
        "Sparkline/utils.ts",
        "Table/Cells/SparklineCell.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker
