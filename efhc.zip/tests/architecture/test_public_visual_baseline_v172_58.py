from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "frontend" / "src"


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_отклонённый_визуальный_слой_отсутствует() -> None:
    rejected = {
        "premium-dock-v3",
        "floating-console-six",
        "layered-line-v3",
        "premium-energy-core-v3",
        "energy-core-marker-v3",
        "efhc-energy-progress-marker",
        "efhc-game-nav_icon-halo",
        "actions-one-row",
        "efhc-profile-topbar_back",
        "cycle 1635 corrective: profile, premium dock and Energy core",
    }
    text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in SRC.rglob("*")
        if path.is_file() and path.suffix in {".css", ".ts", ".tsx"}
    )
    for token in rejected:
        assert token not in text, token


def test_baseline_геометрия_и_полезная_функциональность_сохранены() -> None:
    layout = _read("frontend/src/components/Layout.tsx")
    profile = _read("frontend/src/features/profile/WebProfilePage.tsx")
    energy = _read("frontend/src/components/icons/KwhIcon.tsx")
    home = _read("frontend/src/pages/index.tsx")

    assert 'data-nav-geometry="wide-rounded-six"' in layout
    assert 'data-nav-icon-system="rounded-outline-v2"' in layout
    assert "data-nav-slot={props.slot}" in layout
    assert "navigateBackWithinApp(router)" in layout
    assert "navigateBackWithinApp(router)" in profile
    assert 'data-energy-mark="balanced-lightning-v2"' in energy
    assert '<div className="efhc-energy-progress-track">' in home
