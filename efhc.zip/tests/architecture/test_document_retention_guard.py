from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

MANDATORY_DOCS = [
    "docs/NORM/CHAT_TRANSCRIPT.md",
    "docs/NORM/CHAT_TRANSCRIPT_RECOVERY_PROTOCOL.md",
    "docs/NORM/CHAT_BRANCHES/README.md",
    "docs/NORM/CHAT_BRANCHES/BRANCHES_INDEX.md",
    "docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md",
    "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
    "docs/AI/AI_DOCS_INDEX.md",
    "docs/AI/AI_OPERATOR_RULES_EFHC.md",
    "docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md",
    "docs/AI/TOPIC_READING_ROUTES.md",
    "docs/frontend/FRONTEND_VISUAL_CONTRACT.md",
    "docs/frontend/FRONTEND_SHELL_ARCHITECTURE.md",
    "docs/frontend/FRONTEND_SCREEN_REGISTRY.md",
    "docs/frontend/FRONTEND_COMPONENT_REGISTRY.md",
    "docs/frontend/FRONTEND_VISUAL_ELEMENTS_REGISTRY.md",
    "docs/frontend/FRONTEND_DO_NOT_TOUCH.md",
    "docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md",
    "docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md",
    "docs/frontend/FRONTEND_REFERENCE_INTERPRETATION.md",
    "docs/frontend/FRONTEND_CHANGE_REPORT_TEMPLATE.md",
    "docs/frontend/FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md",
    "docs/frontend/FRONTEND_RECOVERY_CLARIFICATION_QUEUE.md",
    "reports/REPORTS_INDEX.md",
    "docs/GENERAL/MASTER_DOCUMENT_INDEX.csv",
]

ACTIVE_MARKERS = (
    "active",
    "mandatory",
    "required",
    "living",
    "актив",
    "обяз",
    "жив",
)

HISTORICAL_MARKERS = (
    "истор",
    "нет в текущем обзоре",
    "не рассматривать сейчас",
    "placeholder",
    "заглуш",
)


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_mandatory_retention_documents_exist() -> None:
    missing = [p for p in MANDATORY_DOCS if not (ROOT / p).exists()]
    assert missing == []


def test_chat_transcript_is_active_living_document() -> None:
    text = _read("docs/NORM/CHAT_TRANSCRIPT.md")
    required = [
        "# Стенограмма текущего чата",
        "живой обязательный документ",
        "QUESTIONS_AND_ANSWERS_REGISTER.md",
        "Каждый следующий цикл обязан пополнять этот файл",
    ]
    for marker in required:
        assert marker in text


def test_active_index_rows_do_not_point_to_missing_files() -> None:
    index_path = ROOT / "docs/GENERAL/MASTER_DOCUMENT_INDEX.csv"
    missing: list[str] = []
    with index_path.open(encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            path = (row.get("path") or "").strip()
            if not path or path.startswith("http"):
                continue
            values: list[str] = []
            for value in row.values():
                if value is None:
                    continue
                if isinstance(value, list):
                    values.extend(str(item) for item in value)
                else:
                    values.append(str(value))
            joined = " ".join(values).lower()
            is_active = any(m in joined for m in ACTIVE_MARKERS)
            is_historical = any(m in joined for m in HISTORICAL_MARKERS)
            if (
                is_active
                and not is_historical
                and not (ROOT / path).exists()
            ):
                missing.append(path)
    assert missing == []


def test_chat_transcript_is_listed_in_master_index() -> None:
    text = _read("docs/GENERAL/MASTER_DOCUMENT_INDEX.csv")
    assert "docs/NORM/CHAT_TRANSCRIPT.md" in text


def test_chat_transcript_and_qa_are_separate_layers() -> None:
    transcript = _read("docs/NORM/CHAT_TRANSCRIPT.md")
    qa = _read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")
    policy = _read("docs/NORM/CHAT_TRANSCRIPT_RECOVERY_PROTOCOL.md")
    assert "Q/A register" in transcript
    assert "не является стенограммой" in transcript
    assert "не может заменять" in transcript
    assert "separate document" in qa
    assert "Q/A cannot substitute" in policy or "нельзя" in policy
    assert transcript != qa


def test_transcript_records_latest_user_correction() -> None:
    text = _read("docs/NORM/CHAT_TRANSCRIPT.md")
    assert "T015" in text
    assert "20 чатов" in text
    assert "Q/A register" in text


def test_chat_branches_folder_is_retained() -> None:
    branch_dir = ROOT / "docs/NORM/CHAT_BRANCHES"
    assert branch_dir.is_dir()
    assert (branch_dir / "README.md").exists()
    assert (branch_dir / "BRANCHES_INDEX.md").exists()
    index = (branch_dir / "BRANCHES_INDEX.md").read_text(
        encoding="utf-8"
    )
    assert "18.md" in index
    assert "20.md" in index
    assert "10.md" in index


def test_branch_18_source_is_recorded_in_transcript() -> None:
    branch = ROOT / "docs/NORM/CHAT_BRANCHES/18.md"
    assert branch.exists()
    transcript = _read("docs/NORM/CHAT_TRANSCRIPT.md")
    assert "Ветка 18" in transcript
    assert "v168_02" in transcript
    assert "optim" in transcript or "оптимизация" in transcript
    assert "не равно" in transcript


def test_restored_branch_sources_are_retained() -> None:
    branch_dir = ROOT / "docs/NORM/CHAT_BRANCHES"
    for name in ["10.md", "13.md", "18.md", "19.md", "20.md"]:
        assert (branch_dir / name).exists()


def test_restored_branches_are_recorded_in_transcript() -> None:
    transcript = _read("docs/NORM/CHAT_TRANSCRIPT.md")
    for marker in [
        "Ветка 20",
        "Ветка 19",
        "Ветка 18",
        "Ветка 13",
        "Ветка 10",
    ]:
        assert marker in transcript


def test_frontend_page_description_sources_are_retained() -> None:
    required = [
        "docs/audits/VISIBLE_FUNCTIONS_TRIAGE_TABLE.md",
        "docs/audits/FRONTEND_VISIBLE_FUNCTIONS_AUDIT.md",
        "docs/audits/FRONTEND_VISIBLE_ELEMENTS_CHAT_AGREEMENT.md",
        "docs/audits/CHAT_VISIBLE_FRONTEND_AGREEMENT.md",
        "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
    ]
    missing = [path for path in required if not (ROOT / path).exists()]
    assert missing == []


def test_frontend_docs_record_source_first_rule() -> None:
    contract = _read("docs/frontend/FRONTEND_VISUAL_CONTRACT.md")
    registry = _read("docs/frontend/FRONTEND_SCREEN_REGISTRY.md")
    assert "Page-description source hierarchy" in contract
    assert "VISIBLE_FUNCTIONS_TRIAGE_TABLE.md" in contract
    assert "No additional questions are required" in registry


def test_original_source_layer_is_md_only() -> None:
    base = ROOT / "docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START"
    assert base.is_dir()
    assert (base / "INDEX.md").exists()
    assert not (base / "pdf").exists()
    assert not (base / "text").exists()
    assert (base / "md").is_dir()
    assert len(list((base / "md").glob("*.md"))) == 15


def test_frontend_function_recovery_canon_exists() -> None:
    path = ROOT / "docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md"
    questions = (
        ROOT
        / "docs/frontend/FRONTEND_RECOVERY_20_FOLLOWUP_QUESTIONS.md"
    )
    assert path.exists()
    assert questions.exists()
    text = path.read_text(encoding="utf-8")
    assert "PDF-файлы удалены" in text
    assert "ответы пользователя" in text


def test_frontend_recovery_answers_are_recorded() -> None:
    canon = _read("docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md")
    answers = _read(
        "docs/frontend/FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md"
    )
    assert "время до деактивации" in canon
    assert "дата активации" in canon
    assert "дата деактивации" in canon
    assert "обратный отсчёт" in canon
    assert "Max" in answers
    assert "kWh" in answers


def test_frontend_recovery_clarification_queue_exists() -> None:
    text = _read(
        "docs/frontend/FRONTEND_RECOVERY_CLARIFICATION_QUEUE.md"
    )
    assert "USDT" in text
    assert "Wallet states" in text
    assert "debug dump" in text
    assert "login page" in text


def test_chat_first_communication_rule_is_recorded() -> None:
    ai = _read("docs/AI/AI_OPERATOR_RULES_EFHC.md")
    transcript = _read("docs/NORM/CHAT_TRANSCRIPT.md")
    qa = _read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")
    queue = _read(
        "docs/frontend/FRONTEND_RECOVERY_CLARIFICATION_QUEUE.md"
    )
    assert "архив" in ai
    assert "сначала" in ai
    assert "в чате" in ai
    assert "v168_66" in transcript
    assert "chat-first" in queue
    assert "не является" in qa
