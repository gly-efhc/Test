from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.json"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def test_topbar_and_hub_updates_present() -> None:
    data = json.loads(RU.read_text(encoding="utf-8"))
    top = data["sections"][2]
    hub = data["sections"][12]
    top_q = {item["q"] for item in top["items"]}
    hub_q = {item["q"] for item in hub["items"]}
    assert "Что отображается в верхней панели аккаунта?" in top_q
    assert "Для чего нужна кнопка «+» в верхней панели?" in top_q
    assert "Какие статусы аккаунта видны в верхней панели?" in top_q
    assert "Сколько действий доступно в Hub?" in hub_q
    assert "Что делает кнопка «Пополнить»?" in hub_q
    assert "Что делает карточка VIP в Hub?" not in hub_q
    assert (
        "В какой баланс попадает пополнение через «Пополнить» и Hub?"
        in hub_q
    )


def test_cycles_112_113_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert (
        "| 112 | done | RU Top bar FAQ audit and draft package." in text
    )
    assert "| 113 | done | RU Top bar approved rewrite wave." in text
