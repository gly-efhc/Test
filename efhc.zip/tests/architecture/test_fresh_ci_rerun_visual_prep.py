from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1515_norm_doc_exists_and_keeps_proof_honest() -> None:
    doc = read("docs/NORM/FRESH_CI_RERUN_VISUAL_PROOF_PREP.md")
    assert "Cycle 1515" in doc
    assert "GITHUB_CI_NOT_VERIFIED" in doc
    assert "GITHUB_CI_GREEN_NOT_CLAIMED" in doc
    assert "FULL_PYTEST_GREEN_NOT_CLAIMED" in doc
    assert "RELEASE_READY_NOT_CLAIMED" in doc
    assert "VISUAL_NOT_VERIFIED" in doc
    assert "PREPARED_NOT_CAPTURED" in doc


def test_cycle_1515_records_sandbox_worker_build_boundary() -> None:
    doc = read("docs/NORM/FRESH_CI_RERUN_VISUAL_PROOF_PREP.md")
    assert "CIRCLE_NODE_TOTAL=1" in doc
    assert "PASSED_WITH_SANDBOX_WORKER_LIMIT" in doc
    assert "37 workers" in doc
    assert "not GitHub CI proof" in doc


def test_cycle_1515_reference_layers_are_not_runtime_sources() -> None:
    doc = read("docs/NORM/FRESH_CI_RERUN_VISUAL_PROOF_PREP.md")
    assert "Runtime-код не переносился" in doc
    assert "Песочница использована только как reference/navigation/prototype layer" in doc
    assert "Grafana использована только как visual-pattern/reference layer" in doc


def test_cycle_1515_report_json_has_no_false_green_claims() -> None:
    data = json.loads(
        read("reports/generated/fresh_ci_rerun_visual_prep_v170_91.json")
    )
    assert data["cycle"] == 1515
    assert data["github_ci"] == "GITHUB_CI_NOT_VERIFIED"
    assert data["github_ci_green_claimed"] is False
    assert data["full_pytest_green_claimed"] is False
    assert data["visual_status"] == "VISUAL_NOT_VERIFIED"
    assert data["button_click_proof"] == "NOT_EXECUTED"
    assert data["release_status"] == "NOT_RELEASE_READY"
    assert data["local_checks"]["npm_build"] == (
        "PASSED_WITH_CIRCLE_NODE_TOTAL_1"
    )
