import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXCHANGE = ROOT / "frontend/src/pages/exchange.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
LOCALES = ROOT / "frontend/public/locale"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_exchange_history_link_is_light_and_present() -> None:
    src = read(EXCHANGE)
    assert 'data-exchange-history-boundary="light-link-only"' in src
    assert 'data-exchange-history-link="account-history"' in src
    assert 'data-exchange-history-link-light="1288"' in src
    assert 'openProfile("history")' in src
    assert 'openProfile("wallet")' not in src


def test_exchange_does_not_render_heavy_history_surface() -> None:
    src = read(EXCHANGE)
    banned = [
        "HistoryTable",
        "HistoryList",
        "historyRows",
        "historyFilters",
        "purchaseHistory",
        "withdrawHistory",
        "bonusHistory",
        "panelHistory",
    ]
    for token in banned:
        assert token not in src


def test_exchange_history_link_style_is_not_a_heavy_card() -> None:
    css = read(CSS)
    assert "work pass: Exchange History light boundary" in css
    assert ".efhc-exchange-history-boundary" in css
    assert ".efhc-exchange-history-hint" in css
    assert ".efhc-exchange-history-link" in css
    link_block = css.split(".efhc-exchange-history-link", 1)[1]
    link_block = link_block.split("}", 1)[0]
    assert "border: 0;" in link_block
    assert "background: transparent;" in link_block
    assert "width: 100%;" not in link_block


def test_exchange_history_locale_keys_exist() -> None:
    required = {
        "exchange.open_history",
        "exchange.history_hint",
    }
    for path in sorted(LOCALES.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = required.difference(data)
        assert not missing, f"{path.name}: {sorted(missing)}"
        assert data["exchange.open_history"] != "Open history" or (
            path.name == "en.json"
        )


def test_exchange_history_cycle_docs_exist() -> None:
    docs = read(PLAN) + "\n" + read(REPORTS)
    assert "v168_86 / work pass" in docs
    assert "Exchange History link light boundary" in docs
    assert "heavy history" in docs
