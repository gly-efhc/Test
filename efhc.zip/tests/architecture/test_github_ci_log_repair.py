from __future__ import annotations

from pathlib import Path


def read(path: str) -> str:
    return Path(path).read_text()


def test_cycle_1511_norm_doc_exists() -> None:
    text = read("docs/NORM/GITHUB_CI_LOG_REPAIR.md")
    assert "logs_74007805923.zip" in text
    assert "CI_GREEN" in text
    assert "NOT_RELEASE_READY" in text


def test_admin_facade_imports_are_ruff_sorted_locally() -> None:
    text = read("backend/app/services/admin/admin_facade.py")
    assert "from __future__ import annotations" in text
    assert "from sqlalchemy.ext.asyncio import AsyncSession" in text


def test_wallet_canonicalization_returns_str_for_mypy() -> None:
    watcher = read("backend/app/services/watcher_service.py")
    wallets = read("backend/app/services/wallets_service.py")
    assert "cast(str, canonicalize_ton_address(cleaned))" in watcher
    assert "cast(str, canonicalize_ton_address(addr))" in wallets


def test_ton_address_regression_matches_canonical_canon() -> None:
    text = read("tests/test_ton_address_validation_regression.py")
    assert "canonicalize_ton_address" in text
    assert "assert norm1.startswith(\"0:\")" in text
    assert "assert normalize_wallet_address(addr1) == addr1" not in text


def test_cycle_1511_change_report_exists() -> None:
    path = Path(
        "reports/change_cycle_2026-06-14_v170_87_cycle_1511_"
        "github_ci_log_repair.md"
    )
    assert path.exists()


def test_cycle_1511_generated_report_exists() -> None:
    text = read("reports/generated/github_ci_log_repair_v170_87.json")
    assert '"ci_green_claimed": false' in text
    assert '"input_log_status": "CI_FAILED"' in text
