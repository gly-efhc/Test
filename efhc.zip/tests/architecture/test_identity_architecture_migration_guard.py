from __future__ import annotations

import json
from pathlib import Path

from ops.identity.check_tg_id_domain_boundary import check
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_identity_ssot_separates_global_id_and_tg_id() -> None:
    ssot = read("docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md")
    norm = read("docs/NORM/GLOBAL_IDENTITY_MIGRATION_NORM.md")
    assert "Главным, постоянным и неизменяемым идентификатором" in ssot
    assert "`tg_id` — внешний Telegram identifier" in ssot
    assert "global_id = tg_id" in ssot
    assert "цикл `1602`" in norm
    assert "POSTGRESQL PREFLIGHT" in norm
    assert "EXPAND" in ssot
    assert "BACKFILL" in ssot
    assert "DUAL WRITE" in ssot
    assert "READ SWITCH" in ssot
    assert "CONTRACT" in ssot


def test_current_identity_boundary_guard_passes_exact_tree() -> None:
    baseline = ROOT / (
        "ops/identity/tg_id_domain_boundary_baseline.json"
    )
    result = check(ROOT, baseline)
    assert result["passed"], result["errors"]
    assert result["telegram_specific_files"] == 22
    assert result["identity_specific_files"] == 14
    assert result["legacy_runtime_files"] == 184
    assert result["get_current_tg_id_files"] == 12
    assert result["cycle"] == 1646
    assert result["semantic_mix_offenders"] == 0


def test_identity_task_has_exact_kernel_route() -> None:
    classified = classify_task(
        "Цикл 1594 tg_id → user_id UserId contract"
    )
    assert classified["task_type"] == "user_id_contract_foundation"
    route = resolve_route("user_id_contract_foundation", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "user_id_contract_foundation"
    assert (
        "docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md"
        in route["docs"]
    )


def test_cycle1593_does_not_claim_user_id_schema_exists() -> None:
    model = read("backend/app/models/user_models.py")
    assert "id: Mapped[int] = mapped_column(" in model
    assert "tg_id: Mapped[int | None] = mapped_column(" in model
    assert "global_id: Mapped[int | None] = mapped_column(" in model
    assert 'user_id = synonym("global_id")' in model
    cycle = read(
        "docs/cycles/"
        "WORK_CYCLE_1593_USER_ID_IDENTITY_AUDIT_GUARD.md"
    )
    assert "does not change the database schema" in cycle
    assert "users.user_id BIGINT" in cycle


def test_identity_audit_headline_counts_are_recorded() -> None:
    report = read(
        "docs/audits/EFHC_USER_ID_TG_ID_AUDIT_V171_90.md"
    )
    for value in (
        "2448",
        "133",
        "32",
        "29",
        "336",
        "54",
        "375",
        "712",
        "1105",
    ):
        assert value in report
    generated = json.loads(
        read("reports/generated/user_id_tg_id_audit_v171_90.json")
    )
    assert generated["orm_fields"] == 32
    assert generated["service_function_signatures"] == 336


def test_reconciliation_baseline_is_honest_without_database() -> None:
    report = json.loads(
        read(
            "reports/generated/"
            "user_identity_reconciliation_v171_90.json"
        )
    )
    assert report["read_only"] is True
    assert report["financial_tolerance"] == "0.00000000"
    assert report["status"] in {
        "CAPTURED",
        "NOT_RUN_DB_UNAVAILABLE",
    }
    if report["status"] != "CAPTURED":
        assert report["metrics"] == {}
        assert report["errors"]


def test_old_tg_id_lock_is_marked_transitional() -> None:
    legacy = read("docs/SSOT/SYSTEM_LOCK_TG_ID.md")
    assert "TRANSITIONAL" in legacy
    assert "GLOBAL_IDENTITY_AUTH_SSOT.md" in legacy
    locks = read("docs/NORM/ARCHITECTURAL_LOCKS.md")
    assert "главный system/domain owner — `GlobalId` / `global_id`" in locks
