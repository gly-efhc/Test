from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REFERRALS = ROOT / "frontend/src/pages/referrals.tsx"
RANKS = ROOT / "frontend/src/pages/ranks.tsx"
REFERRALS_SERVICE = ROOT / "frontend/src/services/referrals.service.ts"
RANKS_SERVICE = ROOT / "frontend/src/services/ranks.service.ts"
APP = ROOT / "frontend/src/pages/_app.tsx"
HEADER = ROOT / "frontend/src/components/GlobalHeader.tsx"
COIN = ROOT / "frontend/src/components/icons/EfhcCoin.tsx"
NAV = ROOT / "frontend/src/components/icons/AppNavIcon.tsx"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_referrals_use_typed_service_without_manual_binding() -> None:
    page = read(REFERRALS)
    service = read(REFERRALS_SERVICE)
    app = read(APP)
    assert "useReferralStats" in page
    assert "apiRequest" not in page
    assert "referralStatsSchema.parse" in service
    assert "referralBindSchema" not in service
    assert '"/referrals/bind"' not in service
    assert "bindReferralStartParam" not in app


def test_ranks_are_kwh_only_and_use_typed_service_query() -> None:
    page = read(RANKS)
    service = read(RANKS_SERVICE)
    assert "useMyRankWithTop" in page
    assert "useRankTopPages" in page
    assert "apiRequest" not in page
    assert "total_generated_kwh" in page
    assert 'data-ranks-leaderboard="top-100"' in page
    assert 'data-ranks-card-layout="vertical-1299"' in page
    assert "myPlusTopSchema.parse" in service
    assert "topPageSchema.parse" in service
    assert '`/ranks/my-plus-top/me?' in service


def test_header_uses_universal_energy_mark_and_only_efhc_label() -> None:
    header = read(HEADER)
    coin = read(COIN)
    assert 'data-header-balance-label="EFHC"' in header
    assert "<span>EFHC</span>" in header
    assert "Total" not in header
    assert 'data-efhc-energy-mark="universal-lightning"' in coin
    assert "efhc_coin_128.png" not in coin
    assert "<svg" in coin


def test_bottom_navigation_uses_one_consistent_six_icon_system() -> None:
    nav = read(NAV)
    layout = read(LAYOUT)
    expected = {
        '"energy"',
        '"panels"',
        '"exchange"',
        '"tasks"',
        '"referrals"',
        '"ranks"',
    }
    for marker in expected:
        assert marker in nav
    assert '"data-app-nav-icon": props.kind' in nav
    assert "<AppNavIcon kind={item.kind}" in layout
    assert "runtime" not in nav.lower()
