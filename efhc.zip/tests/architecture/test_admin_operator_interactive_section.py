from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1327_documents_exist() -> None:
    paths = [
        "docs/admin/ADMIN_INTERACTIVE_OPERATOR_SECTION.md",
        (
            "docs/audits/"
            "FRONTEND_CYCLE_1327_ADMIN_OPERATOR_INTERACTIVE_SECTION_"
            "AUDIT_V169_06.md"
        ),
        (
            "reports/"
            "change_cycle_2026-05-27_v169_06_cycle_1327_"
            "admin_operator_interactive_section.md"
        ),
        (
            "reports/generated/"
            "frontend_cycle_1327_admin_operator_interactive_section_"
            "v169_06.json"
        ),
    ]
    missing = [path for path in paths if not (ROOT / path).exists()]
    assert missing == []


def test_interactive_operator_panel_exists_and_is_not_static() -> None:
    text = read(
        "frontend/src/components/admin/"
        "AdminInteractiveOperatorPanel.tsx"
    )
    required = [
        "AdminInteractiveOperatorPanel",
        "useState",
        "setInterval",
        "AdminFilterBar",
        "AdminChartCard",
        "AdminFlowMapCard",
        "AdminActionTable",
        "onClick",
        "setWindowKey",
        "setMetricKey",
        'data-admin-operator-panel-cycle="1327"',
    ]
    missing = [marker for marker in required if marker not in text]
    assert missing == []


def test_users_and_bank_use_runtime_dashboards_without_operator_panel() -> None:
    bank = read("frontend/src/pages/admin/bank.tsx")
    users = read("frontend/src/pages/admin/users.tsx")
    assert "AdminBankDashboardRuntime" in bank
    assert "AdminInteractiveOperatorPanel" not in bank
    assert 'data-admin-bank-dashboard-runtime="1483"' in read(
        "frontend/src/components/admin/AdminBankDashboardRuntime.tsx"
    )
    assert "AdminUsersDashboardRuntime" in users
    assert "AdminInteractiveOperatorPanel" not in users
    assert 'data-admin-users-dashboard-runtime="1484"' in read(
        "frontend/src/components/admin/AdminUsersDashboardRuntime.tsx"
    )


def test_cycle_1327_component_not_rendered_and_orphan_deleted() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    orphan = ROOT / (
        "frontend/src/components/admin/"
        "AdminInteractiveBankDashboard.tsx"
    )
    kit = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in home
    assert "AdminInteractiveBankDashboard" not in home
    assert not orphan.exists()
    assert "AdminKpiCard" in kit
    assert "AdminChartCard" in kit


def test_sandbox_direct_intake_documented() -> None:
    doc = read("docs/admin/ADMIN_INTERACTIVE_OPERATOR_SECTION.md")
    required = [
        "Песочница.xz",
        "chart-area-interactive.tsx",
        "section-cards.tsx",
        "data-table.tsx",
        "MaterialM",
        "telegram-web-app-shop-main",
    ]
    missing = [marker for marker in required if marker not in doc]
    assert missing == []
