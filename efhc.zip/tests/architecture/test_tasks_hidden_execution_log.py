from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TASKS_PAGE = ROOT / "frontend/src/pages/tasks.tsx"
TASKS_ROUTES = ROOT / "backend/app/routes/tasks_routes.py"
TASKS_SERVICE = ROOT / "backend/app/services/tasks_service.py"
ADMIN_TASKS_ROUTES = ROOT / "backend/app/routes/admin_tasks_routes.py"
ADMIN_LOGS_ROUTES = ROOT / "backend/app/routes/admin_logs_routes.py"
ARCH_LOCKS = ROOT / "docs/NORM/ARCHITECTURAL_LOCKS.md"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
MATRIX = ROOT / "docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md"
SCREEN = ROOT / "docs/frontend/FRONTEND_SCREEN_REGISTRY.md"
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_tasks_page_marks_hidden_log_boundary_without_public_history() -> (
    None
):
    src = read(TASKS_PAGE)
    assert 'data-tasks-execution-log-boundary="hidden-1293"' in src
    assert 'data-tasks-public-history="forbidden"' in src
    banned = [
        "tasks.history",
        "tasks.execution_log",
        "tasks.backend_log",
        "tasks.idempotency_note",
        "/tasks/history",
        "/tasks/logs",
        "TaskHistory",
        "ExecutionLog",
        "BackendLog",
        "idempotency_note",
    ]
    for token in banned:
        assert token not in src


def test_public_tasks_routes_do_not_expose_history_or_logs() -> None:
    src = read(TASKS_ROUTES)
    banned = [
        '@router.get("/history"',
        "@router.get('/history'",
        '@router.get("/logs"',
        "@router.get('/logs'",
        "list_task_bonus_log(",
        "list_task_rewards_log(",
    ]
    for token in banned:
        assert token not in src


def test_backend_keeps_double_claim_and_bonus_log_protection() -> None:
    src = read(TASKS_SERVICE)
    required = [
        "task_complete_lock",
        "task_bonus_log",
        "_SQL_LOCK_UPSERT",
        "_SQL_LOCK_SELECT_FOR_UPDATE",
        "_SQL_LOCK_SET_CREDITED",
        "_SQL_INSERT_REWARD_LOG",
        "idempotency_key",
        "sub.paid",
    ]
    for token in required:
        assert token in src


def test_admin_can_still_see_task_traces_without_public_tasks_history() -> (
    None
):
    admin_tasks = read(ADMIN_TASKS_ROUTES)
    admin_logs = read(ADMIN_LOGS_ROUTES)
    assert "list_task_submissions_admin" in admin_tasks
    assert "/submissions/{submission_id}/moderate" in admin_tasks
    assert "/transfers" in admin_logs
    assert "reason" in admin_logs
    assert "reason.ilike" in admin_logs
    assert "reason=task_bonus" in admin_logs


def test_cycle_1293_docs_are_registered() -> None:
    docs = "\n".join(
        read(path)
        for path in [ARCH_LOCKS, PLAN, MATRIX, SCREEN, REPORTS]
    )
    assert "v168_91 / work pass" in docs
    assert "Tasks execution log boundary" in docs
    assert "test_tasks_hidden_execution_log.py" in docs
    assert "backend double-claim protection remains internal" in docs
