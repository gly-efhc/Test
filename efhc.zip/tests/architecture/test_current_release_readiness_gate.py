from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / (
    "reports/generated/live_release_readiness_gate_v171_01_cycle_1526.json"
)
SUMMARY = ROOT / (
    "reports/generated/fresh_ci_live_tonconnect_proof_v171_01.json"
)
GATE = ROOT / "ops/release/release_readiness_proof_gate.py"
CYCLE_DOC = ROOT / (
    "docs/cycles/"
    "WORK_CYCLES_1526_FRESH_CI_LIVE_TONCONNECT_PROOF.md"
)
CHANGE_REPORT = ROOT / (
    "reports/"
    "change_cycle_2026-06-16_v171_01_cycle_1526_"
    "fresh_ci_live_tonconnect_proof.md"
)


def _json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_cycle_1526_gate_is_for_current_head() -> None:
    data = _json(REPORT)
    assert data["schema"] == "EFHC_LIVE_RELEASE_READINESS_GATE_V1"
    assert data["cycle"] == 1526
    assert data["input_head"] == "v171.00"
    assert data["output_target"] == "v171.01"
    assert data["release_ready"] is False
    assert data["release_readiness_status"] == "NOT_RELEASE_READY"


def test_cycle_1526_external_proofs_are_not_faked() -> None:
    data = _json(REPORT)
    live = data["live_telegram_proof"]
    real = data["real_tonconnect_proof"]
    ci = data["fresh_github_ci_proof"]
    assert live["status"] == "BLOCKED_MISSING_ENV"
    assert real["status"] == "BLOCKED_MISSING_ENV"
    assert ci["status"] == "NOT_PROVIDED_FOR_V171_00"
    assert live["executed"] is False
    assert real["executed"] is False
    assert ci["executed"] is False


def test_cycle_1526_summary_preserves_non_claims() -> None:
    data = _json(SUMMARY)
    assert data["cycle"] == 1526
    assert data["status"] == "DONE_LOCALLY_FAIL_CLOSED"
    assert data["logs_zip_provided"] is False
    assert data["release_ready"] is False
    assert "GITHUB_CI_GREEN" in data["forbidden_claims"]
    assert "RELEASE_READY" in data["forbidden_claims"]


def test_gate_supports_current_cycle_parameters() -> None:
    text = GATE.read_text(encoding="utf-8")
    assert "--cycle" in text
    assert "--input-head" in text
    assert "--output-target" in text
    assert "--fresh-ci-status" in text
    assert "NOT_PROVIDED_FOR_V171_00" not in text


def test_docs_do_not_claim_external_release_proof() -> None:
    joined = "\n".join(
        [
            CYCLE_DOC.read_text(encoding="utf-8"),
            CHANGE_REPORT.read_text(encoding="utf-8"),
        ]
    )
    assert "GitHub CI green" in joined
    assert "not claimed" in joined
    assert "live Telegram proof" in joined
    assert "real TonConnect proof" in joined
    assert "release-ready" in joined
