"""
Canon guard: backend/requirements.txt must include freezegun.

Rationale:
- Multiple tests depend on freezegun (freeze_time).
- CI installs dependencies from backend/requirements.txt; missing entry causes collection failures.
"""
from __future__ import annotations

from pathlib import Path


def test_backend_requirements_must_include_freezegun() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    req_path = repo_root / "backend" / "requirements.txt"
    assert req_path.exists(), "backend/requirements.txt is missing"

    text = req_path.read_text(encoding="utf-8", errors="replace")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    found = any(ln.lower().startswith("freezegun") for ln in lines)

    assert found, (
        "backend/requirements.txt must include 'freezegun' (tests import freeze_time). "
        "Add e.g. 'freezegun==1.5.1' or a pinned range."
    )
