"""Причинная приёмка финального backend GlobalId contract."""

from __future__ import annotations

from pathlib import Path

import pytest
from app.identity import (
    GlobalId,
    IdentityValueError,
    InvalidGlobalId,
    InvalidTelegramId,
    TelegramId,
    format_global_id,
    format_tg_id,
    global_id_from_database,
    global_id_to_database,
    tg_id_from_provider,
    tg_id_to_provider,
)
from ops.identity.check_backend_global_id_type_finalization import (
    проверить,
)

ROOT = Path(__file__).resolve().parents[2]


def test_backend_global_id_types_завершены() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["историческое_заполнение"] is True
    assert result["переключение_чтения"] is True
    assert result["переключение_финансового_владения"] is True
    assert result["legacy_modules_active"] == 0


def test_канонический_package_не_содержит_legacy_user_id_module() -> None:
    import app.identity as identity

    assert not hasattr(identity, "UserId")
    for relative in (
        "backend/app/identity/legacy_user_id.py",
        "backend/app/identity/legacy_alias.py",
        "backend/app/identity/user_id_backfill.py",
        "backend/app/identity/user_id_expand.py",
    ):
        assert not (ROOT / relative).exists(), relative


def test_global_id_имеет_явные_database_boundaries() -> None:
    value = global_id_from_database(42)
    assert value == GlobalId(42)
    assert global_id_to_database(value) == 42
    assert format_global_id(value) == "0000000042"


@pytest.mark.parametrize(
    ("value", "code"),
    [
        (True, "global_id.type"),
        (1.0, "global_id.type"),
        (0, "global_id.range"),
        (10_000_000_000, "global_id.range"),
        (TelegramId(42), "global_id.provider_mismatch"),
    ],
)
def test_global_id_ошибки_имеют_стабильные_codes(value: object, code: str) -> None:
    with pytest.raises(InvalidGlobalId) as captured:
        global_id_from_database(value)
    assert captured.value.code == code
    assert captured.value.as_dict()["поле"] == "global_id"


def test_telegram_id_имеет_явные_provider_boundaries() -> None:
    value = tg_id_from_provider(42)
    assert value == TelegramId(42)
    assert tg_id_to_provider(value) == 42
    assert format_tg_id(value) == "42"


@pytest.mark.parametrize(
    ("value", "code"),
    [
        (True, "tg_id.type"),
        (1.0, "tg_id.type"),
        (0, "tg_id.range"),
        (GlobalId(42), "tg_id.global_mismatch"),
    ],
)
def test_telegram_id_ошибки_имеют_стабильные_codes(value: object, code: str) -> None:
    with pytest.raises(InvalidTelegramId) as captured:
        tg_id_from_provider(value)
    assert captured.value.code == code
    assert captured.value.as_dict()["поле"] == "tg_id"


def test_identity_error_payload_не_содержит_неявных_полей() -> None:
    error = IdentityValueError("ошибка", code="identity.test")
    assert error.as_dict() == {
        "поле": "identity",
        "код": "identity.test",
        "сообщение": "ошибка",
    }
