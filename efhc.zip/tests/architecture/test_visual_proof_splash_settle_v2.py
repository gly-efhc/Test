from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADMIN = ROOT / "ops/frontend/admin_visual_button_click_proof.py"
PUBLIC = ROOT / "ops/frontend/public_visual_runtime_proof.py"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_visual_proof_has_explicit_minimum_settle_timing() -> None:
    src = _read(ADMIN)

    assert "VISUAL_PROOF_MIN_SETTLE_MS = 2_500" in src
    assert "VISUAL_PROOF_READY_TIMEOUT_MS = 5_000" in src
    assert "performance.now()" in src
    assert "remaining_ms = max(" in src
    assert "page.wait_for_timeout(remaining_ms)" in src


def test_visual_proof_waits_for_splash_hidden_before_success() -> None:
    admin_src = _read(ADMIN)
    public_src = _read(PUBLIC)

    assert "def _splash_visible(page: Page) -> bool:" in admin_src
    assert "def _wait_for_shell_visual_ready(" in admin_src
    assert "assert not splash_visible" in admin_src
    assert "assert not _splash_visible(page)" in admin_src
    assert "and not splash_visible" in public_src
    assert '"splash_visible": splash_visible' in public_src
    assert '"splash_visible": splash_visible' in admin_src


def test_visual_proof_no_short_fixed_wait_as_ready_signal() -> None:
    combined = _read(ADMIN) + "\n" + _read(PUBLIC)

    forbidden = (
        "page.wait_for_timeout(700)",
        "page.wait_for_timeout(500)",
        "page.wait_for_timeout(450)",
    )
    for marker in forbidden:
        assert marker not in combined


def test_public_visual_proof_uses_shared_splash_helpers() -> None:
    src = _read(PUBLIC)

    assert "_wait_for_shell_visual_ready," in src
    assert "_splash_visible," in src
    assert "_wait_for_shell_visual_ready(page)" in src
    assert "splash_visible = _splash_visible(page)" in src
