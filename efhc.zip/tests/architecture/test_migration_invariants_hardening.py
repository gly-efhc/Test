from __future__ import annotations

import csv
import json
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _s(parts: list[str]) -> str:
    return "".join(parts)


def _tables_rows(root: Path) -> list[dict[str, str]]:
    p = root / "docs" / "SSOT" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
    with p.open("r", encoding="utf-8") as f:
        return [
            row
            for row in csv.DictReader(f)
            if (row.get("table") or "").strip()
        ]


def test_migration_plan_uses_current_invariants() -> None:
    root = _repo_root()
    p = (
        root
        / "docs"
        / "SSOT"
        / "ssot_pack"
        / "ROUTES_TABLES_MIGRATIONS_PLAN.json"
    )
    data = json.loads(p.read_text(encoding="utf-8"))
    rows = _tables_rows(root)

    assert data["canon"]["tables_canon_count"] == len(rows)
    assert data["canon"]["db_schemas"] == ["efhc_core", "efhc_admin"]
    text = p.read_text(encoding="utf-8")
    assert _s(["t", "g", "I", "d"]) not in text
    assert _s(["t", "elegram", "_", "id"]) not in text
    assert "count=31" not in text
    assert "sanity 31" not in text
    assert "efhc_core-only" not in text


def test_release_migration_0001_is_metadata_driven() -> None:
    root = _repo_root()
    path = (
        root
        / "backend"
        / "migrations"
        / "versions"
        / "0001_initial_release_schema.py"
    )
    text = path.read_text(encoding="utf-8")
    assert "Base.metadata.create_all" in text
    assert 'sa.text("CREATE TABLE' not in text
    assert 'revision = "0001"' in text
    assert "down_revision = None" in text
    assert "efhc_core" in text
    assert "efhc_admin" in text


def test_migration_invariants_doc_matches_ssot() -> None:
    root = _repo_root()
    p = root / "docs" / "NORM" / "MIGRATION_INVARIANTS_HARDENING.md"
    text = p.read_text(encoding="utf-8")
    rows = _tables_rows(root)
    assert str(len(rows)) in text
    assert "efhc_core" in text
    assert "efhc_admin" in text
    assert _s(["t", "g", "I", "d"]) not in text
    assert _s(["t", "elegram", "_", "id"]) not in text
    assert "efhc_core-only" not in text
