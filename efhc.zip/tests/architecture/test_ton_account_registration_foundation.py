"""TON account registration сохраняется в active release schema."""

from __future__ import annotations

import json
from pathlib import Path

from app.identity.ton_account_registration import (
    build_ton_account_registration_contract,
)
from app.models.user_models import User
from app.models.wallets_models import WalletBinding

ROOT = Path(__file__).resolve().parents[2]
CONTRACT = ROOT / "contracts/identity/ton_account_registration_contract_v1.json"


def test_ton_account_contract_запрещает_fake_tg_id_и_auto_merge() -> None:
    contract = build_ton_account_registration_contract()
    assert contract["alembic_head"] == "0001"
    assert contract["ton_only"]["fake_tg_id"] is False
    assert contract["fail_closed"]["auto_merge"] is False
    assert contract["атомарность"]["one_wallet_one_global_account"] is True


def test_orm_разрешает_ton_only_owner_без_telegram_id() -> None:
    assert User.__table__.c.tg_id.nullable is True
    assert WalletBinding.__table__.c.global_id.nullable is True
    assert WalletBinding.__table__.c.tg_id.nullable is True
    constraints = {
        constraint.name for constraint in WalletBinding.__table__.constraints
    }
    assert "fk_wallet_bindings_global_id_users_global_id" in constraints
    assert "ck_wallet_bindings_owner_reference" in constraints
    assert "ck_wallet_bindings_global_id_range" in constraints


def test_release_migration_содержит_финальную_ton_owner_schema() -> None:
    source = (
        ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source
    assert "wallet_bindings" in source
    assert "proof_verified" in source
    assert "users_global_id_seq" in source


def test_machine_contract_соответствует_runtime_contract() -> None:
    assert json.loads(CONTRACT.read_text(encoding="utf-8")) == (
        build_ton_account_registration_contract()
    )
