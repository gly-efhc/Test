from __future__ import annotations

from pathlib import Path


def _read(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def test_admin_payout_canon_doc_exists() -> None:
    assert Path("docs/NORM/ADMIN_PAYOUT_CANON.md").exists()


def test_admin_payout_does_not_grant_treasury_access_by_canon() -> None:
    text = _read("docs/NORM/ADMIN_PAYOUT_CANON.md")
    assert "does not receive technical access" in text
    assert "treasury/private funds" in text


def test_withdraw_payout_is_operator_wallet_action_by_canon() -> None:
    text = _read("docs/NORM/ADMIN_PAYOUT_CANON.md")
    assert "operator payout action" in text
    assert "TonConnect" in text
    assert "approved operator wallet" in text


def test_kernel_links_admin_payout_canon() -> None:
    kernel = _read("KERNEL.md")
    mapping = _read("map_element.md")
    nav = kernel + mapping
    assert "docs/NORM/ADMIN_PAYOUT_CANON.md" in nav
    assert "treasury/private funds access" in nav


def test_map_element_links_admin_payout_canon() -> None:
    m = _read("map_element.md")
    assert "docs/NORM/ADMIN_PAYOUT_CANON.md" in m
    assert "treasury/private funds" in m
