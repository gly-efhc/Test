from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_global_owner_alias_is_centralized() -> None:
    matches = sorted(
        path.relative_to(ROOT).as_posix()
        for path in (ROOT / "backend/app").rglob("*alias*.py")
        if "tg_id" in path.read_text(encoding="utf-8", errors="ignore")
    )
    assert matches == [
        "backend/app/identity/global_owner_alias.py",
        "backend/app/identity/legacy_alias.py",
    ]


def test_business_services_expose_global_id() -> None:
    for name in (
        "transactions_service.py",
        "panels_service.py",
        "withdraw_service.py",
        "payment_intents_service.py",
        "referral_service.py",
        "tasks_service.py",
        "ranks_service.py",
        "wallets_service.py",
    ):
        text = (ROOT / "backend/app/services" / name).read_text(encoding="utf-8")
        assert "global_id" in text, name
