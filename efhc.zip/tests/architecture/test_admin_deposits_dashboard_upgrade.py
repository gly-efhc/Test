from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_deposits_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md",
        "docs/NORM/ADMIN_DEPOSITS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1485_ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md",
        "reports/generated/admin_deposits_dashboard_upgrade_v170_61.json",
        "reports/change_cycle_2026-06-08_v170_61_cycle_1485_"
        "admin_deposits_dashboard_upgrade.md",
        "frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx",
        "tests/architecture/test_admin_deposits_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_deposit_boundaries() -> None:
    data = json.loads(
        read("reports/generated/admin_deposits_dashboard_upgrade_v170_61.json")
    )
    assert data["cycle"] == 1485
    assert data["archive_version"] == "v170.61"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_deposits_route_changed"] is True
    assert data["new_backend_endpoint_added"] is False
    assert data["fake_time_series_added"] is False
    assert data["synthetic_admin_analytics_added"] is False
    assert data["real_time_series_claimed"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["dashboard_idempotency_key_created"] is False
    assert data["replay_logic_changed"] is False
    assert data["exception_processing_changed"] is False
    assert data["force_fulfill_logic_changed"] is False
    assert data["deposit_credit_logic_changed"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False


def test_admin_deposits_runtime_component_has_1485_markers() -> None:
    src = read("frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx")
    required = [
        "adminDepositsDashboardRuntimeVersion",
        "EFHC_ADMIN_DEPOSITS_DASHBOARD_RUNTIME_V1",
        'data-admin-deposits-dashboard-runtime="1485"',
        'data-admin-deposits-truth="raw-derived"',
        'data-admin-deposits-no-synthetic="true"',
        'data-admin-deposits-no-write-actions="true"',
        'data-admin-deposits-no-raw-payload="true"',
        'data-admin-deposits-no-debug-json="true"',
        'data-admin-deposits-no-secrets="true"',
        'data-admin-deposits-money-path="read-only"',
        "AdminDashboardToolbar",
        "AdminFreshnessBadge",
        "AdminRefreshPicker",
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminPanelChrome",
        "AdminMiniBarChart",
        "AdminProgressBar",
        "AdminHeatStrip",
        "AdminFlowMapCard",
    ]
    for marker in required:
        assert marker in src


def test_admin_deposits_runtime_component_is_read_only() -> None:
    src = read("frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "fetch(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "mutateAsync",
        "synthetic_preview",
        "raw payload dump",
        "debug JSON dump",
        "buildTrend",
        "setInterval",
    ]
    for marker in forbidden:
        assert marker not in src
    assert "Derived snapshot display" in src


def test_admin_deposits_page_integrates_dashboard_safely() -> None:
    page = read("frontend/src/pages/admin/efhc-deposits.tsx")
    assert "AdminDepositsDashboardRuntime" in page
    assert "ADMIN_EFHC_DEPOSITS_RUNTIME_SUMMARY_PATH" in page
    assert "ADMIN_EFHC_DEPOSITS_REPROCESS_TX_HASH_PATH" in page
    assert "ADMIN_EFHC_DEPOSITS_PROCESS_PATH" in page
    assert "ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH" in page
    assert "newIdempotencyKey" in page
    assert "AdminPromptModal" in page


def test_admin_deposits_guarded_actions_remain_outside_dashboard() -> None:
    page = read("frontend/src/pages/admin/efhc-deposits.tsx")
    component = read(
        "frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx"
    )
    for marker in ["replayAutomatedPath", "submit", "forceFulfill"]:
        assert marker in page
        assert marker not in component
    assert "idempotencyKey" in page
    assert "idempotencyKey" not in component


def test_admin_deposits_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1485 — Admin Deposits Dashboard Upgrade",
        'data-admin-deposits-dashboard-runtime="1485"',
        ".efhc-admin-deposits-dashboard-grid",
        ".efhc-admin-deposits-dashboard-status-grid",
        ".efhc-admin-deposits-dashboard-readiness",
        ".efhc-admin-deposits-dashboard-boundary",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1485 — Admin Deposits Dashboard Upgrade" in corpus
    assert "ADMIN_DEPOSITS_DASHBOARD_UPGRADE" in corpus
    assert "AdminDepositsDashboardRuntime.tsx" in corpus
    assert "1486 — Admin Withdrawals Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/ADMIN_DEPOSITS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype" in docs
    assert "No Grafana source code" in docs


def test_deposit_status_fields_are_real_runtime_summary_fields() -> None:
    component = read(
        "frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx"
    )
    required = [
        "pending_manual_count",
        "error_retry_count",
        "error_user_count",
        "auto_credited_count",
        "pending_intents_count",
    ]
    for marker in required:
        assert marker in component
    assert "fake deposit history" not in component.lower()
