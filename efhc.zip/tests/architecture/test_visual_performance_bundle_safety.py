from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def load(path: str) -> dict:
    return json.loads(read(path))


def test_cycle_1493_docs_reports_and_guard_exist() -> None:
    for rel in [
        "docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY.md",
        "docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1493_VISUAL_PERFORMANCE_BUNDLE_SAFETY.md",
        "reports/generated/visual_performance_bundle_safety_v170_69.json",
        "reports/change_cycle_2026-06-10_v170_69_cycle_1493_visual_performance_bundle_safety.md",
        "tests/architecture/test_visual_performance_bundle_safety.py",
    ]:
        assert (ROOT / rel).exists(), rel


def test_admin_release_home_excludes_heavy_observability_panel() -> None:
    page = read("frontend/src/pages/admin/index.tsx")
    assert 'import dynamic from "next/dynamic"' not in page
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in page
    assert "Релизный центр управления" in page
    assert "Релизные данные" in page


def test_no_heavy_chart_or_grafana_dependencies_added() -> None:
    package = load("frontend/package.json")
    names = set(package.get("dependencies", {})) | set(package.get("devDependencies", {}))
    forbidden = {
        "@grafana/data",
        "@grafana/runtime",
        "@grafana/ui",
        "grafana",
        "recharts",
        "chart.js",
        "react-chartjs-2",
        "echarts",
        "d3",
        "@nivo/core",
        "@nivo/line",
        "victory",
        "plotly.js",
        "highcharts",
        "ag-grid-community",
    }
    assert names.isdisjoint(forbidden)


def test_frontend_runtime_has_no_grafana_imports_or_heavy_chart_imports() -> None:
    forbidden_markers = [
        "@grafana/",
        "from 'recharts'",
        'from "recharts"',
        "from 'chart.js'",
        'from "chart.js"',
        "from 'echarts'",
        'from "echarts"',
        "from 'd3'",
        'from "d3"',
        "from '@nivo/",
        'from "@nivo/',
        "from 'plotly.js'",
        'from "plotly.js"',
        "from 'highcharts'",
        'from "highcharts"',
    ]
    offenders: list[str] = []
    for path in (ROOT / "frontend/src").rglob("*.ts*"):
        rel = path.relative_to(ROOT).as_posix()
        txt = path.read_text(encoding="utf-8", errors="ignore")
        if any(marker in txt for marker in forbidden_markers):
            offenders.append(rel)
    assert offenders == []


def test_public_tma_pages_do_not_import_admin_dashboard_runtime_components() -> None:
    offenders: list[str] = []
    for path in (ROOT / "frontend/src/pages").rglob("*.tsx"):
        rel = path.relative_to(ROOT).as_posix()
        if "/admin/" in rel:
            continue
        txt = path.read_text(encoding="utf-8", errors="ignore")
        if "components/admin" in txt or "AdminDashboard" in txt:
            offenders.append(rel)
    assert offenders == []


def test_generated_report_records_bundle_safety_boundaries() -> None:
    data = load("reports/generated/visual_performance_bundle_safety_v170_69.json")
    assert data["cycle"] == 1493
    assert data["archive_version"] == "v170.69"
    assert data["status"] == "done_locally"
    assert data["lazy_boundaries"] == [
        "frontend/src/pages/admin/index.tsx -> AdminObservabilityTimeseriesDashboardRuntime"
    ]
    for key in [
        "heavy_dependencies_added",
        "package_json_changed",
        "package_lock_changed",
        "backend_changed",
        "openapi_changed",
        "migrations_changed",
        "economy_changed",
        "write_actions_added",
        "dashboard_idempotency_key_created",
        "money_changing_service_called",
        "raw_payload_visible",
        "debug_json_visible",
        "secrets_visible",
        "fake_time_series_added",
        "synthetic_runtime_series_added",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
    ]:
        assert data[key] is False


def test_navigation_and_manifests_reference_cycle_1493() -> None:
    for rel in [
        "KERNEL.md",
        "map_element.md",
        "docs/NORM/DASHBOARD_VISUAL_PLAN.md",
        "docs/NORM/DASHBOARD_VISUAL_KERNEL.md",
        "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md",
        "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md",
        "docs/cycles/WORK_CYCLES.md",
        "docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md",
        "docs/testing/TEST_GUARD_MANIFEST.md",
        "reports/REPORTS_INDEX.md",
    ]:
        text = read(rel)
        if rel == "KERNEL.md":
            assert "Visual Performance / Bundle Safety" in text
        else:
            assert "1493 — Visual Performance / Bundle Safety" in text
    manifest = load("docs/testing/TEST_GUARD_MANIFEST.json")
    assert "tests/architecture/test_visual_performance_bundle_safety.py" in str(manifest)
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "visual_performance_bundle_safety" in routes


def test_grafana_and_sandbox_reference_only_for_cycle_1493() -> None:
    norm = read("docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY.md")
    grafana = read(
        "docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY_GRAFANA_ELEMENT_ANALYSIS.md"
    )
    sandbox = read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    assert "Grafana использована только как visual-pattern/reference layer" in norm
    assert "Runtime-код не" in norm
    assert "Grafana remains a visual reference only" in grafana
    assert "no sandbox runtime code is copied" in sandbox.lower()
