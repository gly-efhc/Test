from __future__ import annotations

import json
from pathlib import Path


def test_cycle_1513_reports_exist() -> None:
    required = [
        Path("docs/NORM/TAIL_FIX_REPORT.md"),
        Path("docs/NORM/ADMIN_SEAMS_FULL_MIGRATION_REPORT.md"),
        Path("docs/NORM/ADMIN_RUNTIME_TEST_PROOF.md"),
        Path("docs/NORM/ADMIN_ORPHAN_ROUTE_STATUS.md"),
        Path("reports/generated/cycle_1513_tail_fix_proof_v170_89.json"),
    ]
    missing = [str(path) for path in required if not path.exists()]
    assert not missing


def test_cycle_1513_proof_is_honest_not_false_green() -> None:
    data = json.loads(
        Path("reports/generated/cycle_1513_tail_fix_proof_v170_89.json")
        .read_text(encoding="utf-8")
    )
    assert data["input_log_verdict"] == "CI_FAILED"
    assert data["fresh_output_ci_green"] is False
    assert data["release_ready"] is False
    assert data["visual_status"] == "VISUAL_NOT_VERIFIED"


def test_cycle_1513_admin_seams_full_migration_doc() -> None:
    text = Path("docs/NORM/ADMIN_SEAMS_FULL_MIGRATION_REPORT.md").read_text(
        encoding="utf-8"
    )
    assert "raw admin `apiRequest` call-sites | tracked debt | 0" in text
    assert "adminSeams constants | 59 | 59" in text
    assert "strict" in text


def test_cycle_1513_runtime_proof_requires_fresh_ci() -> None:
    text = Path("docs/NORM/ADMIN_RUNTIME_TEST_PROOF.md").read_text(
        encoding="utf-8"
    )
    assert "RUNTIME_P1_TESTS_READY_BUT_NOT_PROVEN_BY_FRESH_CI" in text
    assert "pytest.skip" not in text
    assert "raw `TypeError`: `NOT FOUND`" in text
