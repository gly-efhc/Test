from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_public_hub_has_exactly_two_canonical_actions() -> None:
    hub = _read("frontend/src/features/hub/HubPage.tsx")
    assert hub.count('data-hub-action=') == 2
    assert 'data-hub-visible-action-count="2"' in hub
    assert "hub.action_top_up_efhc" in hub
    assert "hub.action_vip_nft" in hub
    assert "https://getgems.io/efhc-nft" in hub
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in hub
    forbidden = [
        "readShopLauncherTruth",
        "SurfaceFactsStrip",
        "TelegramSectionRow",
        "TelegramStatusBadge",
        "productStateLabel",
        "readinessLabel",
        "canonicalCenterLabel",
        "nextActionDescription",
        "returnPathDescription",
    ]
    for needle in forbidden:
        assert needle not in hub


def test_public_hub_does_not_render_diagnostics_or_commerce_copy() -> None:
    hub = _read("frontend/src/features/hub/HubPage.tsx")
    string_literals = re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"', hub)
    rendered_text = "\n".join(
        s for s in string_literals if not s.startswith("hub.")
    )
    for term in [
        "truth-layer",
        "contour",
        "Browser-Shop",
        "endpoint",
        "execution path",
        "return path",
        "canonical center",
        "active intent",
        "watcher",
        "wallet state",
        "TON / GRAM",
        "USDT",
    ]:
        assert term not in rendered_text


def test_hub_diagnostics_are_admin_only() -> None:
    diagnostics = _read("frontend/src/pages/admin/diagnostics.tsx")
    assert "HUB / Storefront operator diagnostics" in diagnostics
    assert "/hub/shop-truth" in diagnostics
    assert "/hub/efhc-handoff" in diagnostics


def test_hub_locale_keys_exist_for_all_languages() -> None:
    locale_dir = ROOT / "frontend/public/locale"
    keys = {
        "hub.clean_description",
        "hub.action_top_up_efhc",
        "hub.action_top_up_efhc_description",
        "hub.action_vip_nft",
    }
    for path in sorted(locale_dir.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in keys:
            assert key in data, path.name
