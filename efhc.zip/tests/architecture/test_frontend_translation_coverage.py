from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALES = sorted((ROOT / "frontend/public/locale").glob("*.json"))

REQUIRED_KEYS = [
    "profile.modal_title",
    "profile.section_title",
    "profile.wallet_nav_desc",
    "profile.history_nav_desc",
    "profile.faq_nav_desc",
    "profile.interface_title",
    "profile.sound_title",
    "profile.haptic_feedback",
    "wallet.title",
    "wallet.connected_title",
    "wallet.required_title",
    "wallet.status_connected",
    "wallet.status_not_connected",
    "wallet.primary_wallet",
    "wallet.linked_wallets",
    "wallet.make_primary",
    "wallet.remove",
    "history.title",
    "history.balance_operations",
    "history.withdraw_requests",
    "history.empty_title",
    "history.loading_items",
    "withdraw.status_pending",
    "withdraw.status_paid",
    "withdraw.status_rejected",
    "withdraw.status_canceled",
    "withdraw.empty_title",
    "shop_ui.deposit_title",
    "shop_ui.deposit_note",
    "shop_ui.wallet_required",
    "shop_ui.preview_unavailable",
    "shop_ui.preview",
    "shop_ui.buy",
    "shop_ui.use",
    "shop_ui.active",
    "shop_ui.owned",
    "shop_ui.no_skins",
    "shop_ui.skin_preview_title",
]


def test_translation_keys_exist_in__all__locales() -> None:
    assert LOCALES, "locale files are missing"
    for path in LOCALES:
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in REQUIRED_KEYS if key not in data]
        assert not missing, f"{path.name} missing keys: {missing}"
