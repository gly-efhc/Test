"""Structural guard that complements, but never replaces, PostgreSQL tests."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_referral_activation_has_one_locked_runtime_owner() -> None:
    crud = read("backend/app/crud/referrals_crud.py")
    service = read("backend/app/services/referral_service.py")
    assert "class ReferralActivationResult" in crud
    assert ".with_for_update()" in crud
    assert "activated_now" in crud
    assert "activation_dt" in crud
    assert "UPDATE efhc_core.referral_links" not in service
    assert "activation = await activate_referral(" in service
    assert "if not activation.activated_now:" in service
    release_guard = read(
        "ops/release/ci_profile/test_release_archive_contract.py"
    )
    assert 'assert ".with_for_update()" in crud' in release_guard
    assert 'assert "FOR UPDATE" in service' not in release_guard


def test_integration_suite_executes_real_business_paths() -> None:
    runtime = read("tests/integration/test_referral_runtime.py")
    release_contract = read("tests/test_release_archive_contract.py")
    for required in (
        "onboard_user_at_first_creation(",
        "get_or_create_referral_code(",
        "await activate_panel(",
        "asyncio.gather(",
        "forced failure after unit bonus",
        "test_ten_end_to_end_referrals_produce_exact_lvl1_total",
        "EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)",
        "test_active_status_is_permanent_and_ignores_panel_count",
        "DELETE FROM efhc_core.panels WHERE tg_id = :tg",
    ):
        assert required in runtime
    assert "test_full_referral_cycle_is_exactly_2411_efhcb" not in runtime
    assert "activate_panel" not in release_contract
    assert "onboard_user_at_first_creation" not in release_contract


def test_ci_referral_integration_is_fail_closed_on_skips() -> None:
    workflow = read(".github/workflows/canon.yml")
    conftest = read("tests/conftest.py")
    checker = read("ops/ci_checks/assert_pytest_junit.py")
    assert "PYTHONPATH=backend pytest -q" in workflow
    assert "ASYNC_DATABASE_URL" in workflow
    assert "postgresql+asyncpg://" in workflow
    assert "if _running_in_ci():" in conftest
    assert "pytest.fail(message)" in conftest
    assert "skipped > args.max_skipped" in checker


def test_ci_log_repairs_remain_protected_in_runtime_source() -> None:
    service = read("backend/app/services/referral_service.py")
    panels = read("backend/app/services/panels_service.py")
    runtime = read("tests/integration/test_referral_runtime.py")

    sql = service.split('SQL_LIST_REFERRALS = """', 1)[1].split(
        '"""', 1
    )[0]
    for typed_bind in (
        "CAST(:cursor_ts AS TIMESTAMPTZ)",
        "CAST(:cursor_id AS BIGINT)",
        "CAST(:want_active AS BOOLEAN)",
        "LIMIT CAST(:fetch_limit AS INTEGER)",
    ):
        assert typed_bind in sql

    lock_block = panels.split("async def _lock_user_row", 1)[1].split(
        "async def _load_panel_activation", 1
    )[0]
    lock_sql = lock_block.split(
        "row = await db.execute(", 1
    )[1].split('"""', 1)[1].split('"""', 1)[0]
    assert "FOR UPDATE" in lock_sql
    assert "SKIP LOCKED" not in lock_sql
    assert 'Decimal("0.00000000")' in runtime
    assert "CAST(:created_at AS TIMESTAMPTZ)" in runtime
    assert "CAST(:start_index AS BIGINT)" in runtime
    assert "CAST(:end_index AS BIGINT)" in runtime
