from pathlib import Path


def test_admin_reports_overview_has_panel_and_energy_metrics() -> None:
    src = Path("backend/app/routes/admin_routes.py").read_text()
    required = [
        "panels_total_bought",
        "panels_total_active",
        "panels_total_archived",
        "panels_total_paid_efhc",
        "users_total_generated_kwh",
        "users_total_exchanged_kwh",
        "users_total__main__efhc",
        "users_total_bonus_efhc",
    ]
    for key in required:
        assert key in src
