from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1498_docs_and_reports_exist() -> None:
    expected = [
        "docs/NORM/CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md",
        "docs/NORM/CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1498_CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md",
        "reports/generated/ci_log_repair_public_dashboard_i18n_hardening_v170_74.json",
        "reports/change_cycle_2026-06-11_v170_74_cycle_1498_ci_log_repair_public_dashboard_i18n_hardening.md",
    ]
    for rel in expected:
        assert (ROOT / rel).exists(), rel


def test_observability_summary_row_is_mypy_safe() -> None:
    text = read("backend/app/routes/admin_observability_routes.py")
    assert "row: Mapping[str, Any] = dict(result) if result is not None else {}" in text
    assert "row: Mapping[str, Any] = result if result is not None else {}" not in text


def test_dashboard_handoff_guard_is_ruff_sim102_safe() -> None:
    text = read("tests/architecture/test_dashboard_direction_handoff_backlog_freeze.py")
    assert "and cyrillic.search(text)" in text
    assert "if rel.endswith((\"Runtime.tsx\", \"MiniCharts.tsx\", \"ProgressSystem.tsx\")):\n            if cyrillic.search(text):" not in text


def test_audit_followup_files_use_filename_hygiene_names() -> None:
    assert (ROOT / "docs/NORM/DASHBOARD_DIRECTION_AUDIT_FOLLOWUP.md").exists()
    assert (ROOT / "tests/architecture/test_dashboard_direction_audit_followup.py").exists()
    assert not (ROOT / "docs/NORM/DASHBOARD_DIRECTION_AUDIT_FOLLOWUP_1497.md").exists()
    assert not (ROOT / "tests/architecture/test_dashboard_direction_audit_followup_1497.py").exists()


def test_public_dashboard_i18n_audits_pass() -> None:
    scripts = [
        "ops/i18n/audit_i18n_manual_coverage_consolidation.py",
        "ops/i18n/audit_wave3_profile_trust_locale_quality.py",
        "ops/i18n/audit_wave3_panels_tasks_history_locale_quality.py",
        "ops/i18n/audit_wave3_hub_energy_wallet_ranks_referrals_locale_quality.py",
    ]
    for script in scripts:
        result = subprocess.run(
            [sys.executable, script],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, result.stdout + result.stderr
        assert "Unexpected English-identical values: 0" in result.stdout


def test_cycle_1498_manifest_and_counters_are_updated() -> None:
    manifest = json.loads(read("docs/testing/TEST_GUARD_MANIFEST.json"))
    assert manifest["last_updated_cycle"] >= 1498
    assert manifest["active_architecture"] >= 320
    assert "cycle_1498_ci_log_repair_public_dashboard_i18n_hardening" in manifest
    assert any(
        item.get("file") == "tests/architecture/test_ci_log_repair_public_dashboard_i18n_hardening.py"
        for item in manifest.get("active_guards", [])
        if isinstance(item, dict)
    )


def test_kernel_and_map_reference_cycle_1498_without_numbered_cycle_text() -> None:
    kernel = read("KERNEL.md")
    mapping = read("map_element.md")
    nav = kernel + mapping
    assert "1498 — CI Log Repair / Public Dashboard i18n Hardening" in nav
    assert "CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md" in nav
    assert "tests/architecture/test_ci_log_repair_public_dashboard_i18n_hardening.py" in mapping
    assert "cycle 1498" not in kernel.lower()
