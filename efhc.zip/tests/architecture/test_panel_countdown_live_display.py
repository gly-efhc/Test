from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONT = ROOT / "frontend/src/pages/panels.tsx"
STYLE = ROOT / "frontend/src/styles/globals.css"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_panel_countdown_has_live_display_marker() -> None:
    src = read(FRONT)
    assert 'data-panel-countdown-live="client-stopwatch"' in src
    assert "data-panel-countdown-tick={tick}" in src
    assert 'aria-live="polite"' in src
    assert "setInterval" in src
    assert "1_000" in src


def test_panel_countdown_uses_server_anchor_not_local_source() -> None:
    src = read(FRONT)
    assert "anchorServerMs" in src
    assert "anchorClientMs" in src
    assert "server_now_utc" in src
    assert "expiresMs - nowUtcMs" in src
    assert "local device clock is not the source of truth" in src


def test_panel_countdown_visual_style_exists() -> None:
    css = read(STYLE)
    assert "work pass" in css
    assert ".efhc-panel-countdown-live" in css
    assert "box-shadow" in css
    assert "var(--tg-button)" in css


def test_cycle_1284_documented() -> None:
    plan = read(PLAN)
    reports = read(REPORTS)
    assert "v168_82 / work pass" in plan
    assert "panel countdown live display" in plan
    assert "v168_82 work pass" in reports
