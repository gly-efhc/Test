from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_public_energy_component_exists() -> None:
    path = (
        ROOT
        / "frontend/src/components/public/PublicEnergyInteractiveOverview.tsx"
    )
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert 'data-public-energy-interactive-cycle="1347"' in text
    assert "DisplayData rows" in text
    assert "Haptic feedback wrapper" in text
    assert "hapticTap" in text
    assert "frontend/src/pages/admin" not in text


def test_energy_page_uses_cycle_1554_mvp_replacement() -> None:
    text = read("frontend/src/pages/index.tsx")
    assert "EnergyMvpSummary" not in text
    assert "LiveEnergyHeroAndProgress" in text
    assert 'data-energy-level-name={levelName}' in text
    assert "PublicEnergyInteractiveOverview" not in text
    assert 'data-energy-mobile-proof="390px"' in text
    assert "AdminRouteHealthStrip" not in text
    mapping = read(
        "docs/frontend/FRONTEND_ENERGY_MVP_REPLACEMENT_MAPPING.md"
    )
    assert "PublicEnergyInteractiveOverview" in mapping
    assert "DELETE_AFTER_REPLACEMENT" in mapping


def test_public_energy_locales_exist() -> None:
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        text = path.read_text(encoding="utf-8")
        assert "energy.interactive_title" in text
        assert "energy.public_interactivity_safe_note" in text
        assert "energy.overview_interactive_hint" in text


def test_public_energy_docs_exist() -> None:
    assert (
        ROOT
        / "docs/frontend/FRONTEND_PUBLIC_ENERGY_INTERACTIVE_OVERVIEW.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/FRONTEND_CYCLE_1347_PUBLIC_ENERGY_INTERACTIVE_OVERVIEW_AUDIT_V169_26.md"
    ).exists()
    assert (
        ROOT
        / "reports/change_cycle_2026-05-31_v169_26_cycle_1347_public_energy_interactive_overview.md"
    ).exists()


def test_cycle_plan_moves_to_public_panels() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert (
        "1347: Public Energy interactive overview. DONE in v169_26."
        in text
    )
    assert (
        "1348: Public Panels activation preview. DONE in v169_27."
        in text
    )


def test_ci_manual_boundary_unchanged() -> None:
    report = read(
        "reports/change_cycle_2026-05-31_v169_26_cycle_1347_public_"
        "energy_interactive_overview.md"
    )
    assert "`ci.yml` was not changed" in report
