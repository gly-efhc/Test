import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_cycle_1542_report_records_single_pytest_guard_repair() -> None:
    report = json.loads(read(
        "reports/generated/"
        "fresh_ci_frontend_noise_rerun_confirmation_v171_17.json"
    ))
    assert report["cycle"] == 1542
    assert report["input_log"] == "logs_74653569841.zip"
    assert report["failed_gates"] == ["pytest"]
    assert report["github_ci_green_claimed"] is False
    assert report["release_ready_claimed"] is False


def test_cycle_1542_keeps_referral_import_guard_semantic() -> None:
    guard = read(
        "tests/architecture/"
        "test_fresh_ci_artifact_hygiene_log_repair.py"
    )
    assert "src.startswith(\"from pathlib import Path\\n\")" in guard
    assert "test_late_referral_binding_surface_is_removed" in guard
    assert "attach_referral_code" in guard
    assert "bind_referral_code" in guard


def test_cycle_1542_no_release_or_live_proof_overclaim() -> None:
    kernel = read("KERNEL.md")
    release_status = read("docs/NORM/RELEASE_PROOF_STATUS.md")
    combined = kernel + "\n" + release_status
    assert "GitHub CI green" in combined
    assert "not claimed" in combined
    assert "live Telegram proof" in combined
    assert "real TonConnect proof" in combined
