from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FAQ_PAGE = ROOT / "frontend/src/pages/faq.tsx"
FAQ_LIST = ROOT / "frontend/src/components/faq/FaqAccordionList.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
LOCALE_DIR = ROOT / "frontend/public/locale"

REQUIRED_KEYS = {
    "faq.quick_sections_title",
    "faq.quick_sections_next",
    "faq.quick_sections_desc",
    "faq.quick_topic_links",
    "faq.quick_topic_links_desc",
    "faq.quick_wallet_desc",
    "faq.quick_history_desc",
    "faq.quick_panels_desc",
    "faq.quick_exchange_desc",
    "faq.quick_referrals_desc",
    "faq.quick_ranks_desc",
}

FORBIDDEN_PUBLIC_STRINGS = {
    "Quick FAQ sections",
    "Where to go next",
    "Quick topic links",
    "Wallet and linked accounts.",
    "Operations and request history.",
    "Referral links and activity.",
    "Go to kWh to EFHC exchange.",
}


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_faq_uses_selected_runtime_language() -> None:
    src = _read(FAQ_PAGE)

    assert "useFaqCatalog(ctx.lang)" in src
    assert "key={ctx.lang}" in src
    assert 'getFaqCatalog("ru")' not in src
    assert 'getFaqCatalog("en")' not in src


def test_faq_public_labels_are_not_hardcoded_english() -> None:
    combined = _read(FAQ_PAGE) + "\n" + _read(FAQ_LIST)

    for text in FORBIDDEN_PUBLIC_STRINGS:
        assert text not in combined

    assert "data-faq-compact-tree" in combined
    assert "compactTreeProof" in combined


def test_faq_locale_keys_exist_for_every_language() -> None:
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(
            key for key in REQUIRED_KEYS if not data.get(key)
        )
        assert missing == [], f"{path.name}: {missing}"


def test_faq_has_bot_width_shell() -> None:
    page = _read(FAQ_PAGE)
    css = _read(CSS)

    assert "efhc-faq-shell" in page
    assert "data-faq-compact-tree" in page
    assert ".efhc-faq-shell" in css
    assert "max-width: min(100%, 36rem);" in css
    assert "overflow-x: hidden;" in css
    assert "@media (max-width: 420px)" in css
