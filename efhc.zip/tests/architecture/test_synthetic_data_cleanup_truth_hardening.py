from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def load(path: str) -> dict:
    return json.loads(read(path))


def test_cycle_1492_docs_and_reports_exist() -> None:
    for rel in [
        "docs/NORM/SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md",
        "docs/NORM/SYNTHETIC_DATA_CLEANUP_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1492_SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md",
        "reports/generated/synthetic_data_cleanup_truth_hardening_v170_68.json",
        (
            "reports/change_cycle_2026-06-10_v170_68_cycle_1492_"
            "synthetic_data_cleanup_truth_hardening.md"
        ),
        (
            "frontend/src/components/admin/"
            "AdminObservabilityTimeseriesDashboardRuntime.tsx"
        ),
    ]:
        assert (ROOT / rel).exists(), rel


def test_observability_backend_hardens_route_and_amount_metrics() -> None:
    src = read("backend/app/routes/admin_observability_routes.py")
    assert 'if "ref" in reason_s' not in src
    assert 'reason_s.startswith("referral")' in src
    assert '"referral" in reason_s' in src
    assert '"efhc_credit_amount"' in src
    assert '"efhc_debit_amount"' in src
    assert "where direction = 'credit'" in src
    assert "where direction = 'debit'" in src
    assert 'unit="EFHC gross turnover"' in src
    assert "not net balance" not in src.lower()


def test_frontend_uses_real_timeseries_dashboard_on_admin_index() -> None:
    page = read("frontend/src/pages/admin/index.tsx")
    component = read(
        "frontend/src/components/admin/AdminObservabilityTimeseriesDashboardRuntime.tsx"
    )
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in page
    assert "AdminInteractiveBankDashboard" not in page
    assert "ADMIN_OBSERVABILITY_TIMESERIES_PATH" in component
    assert "ADMIN_OBSERVABILITY_SUMMARY_PATH" in component
    assert "data-admin-observability-truth=\"real_timeseries\"" in component
    assert "data-admin-observability-synthetic=\"false\"" in component
    assert "synthetic={false}" in component
    assert "real_timeseries" in component
    assert "POST" not in component
    assert "PUT" not in component
    assert "PATCH" not in component
    assert "DELETE" not in component
    assert "Idempotency-Key" not in component
    assert "newIdempotencyKey" not in component


def test_old_synthetic_series_builder_is_deleted_and_not_mounted() -> None:
    legacy = (
        ROOT
        / "frontend/src/components/admin/AdminInteractiveBankDashboard.tsx"
    )
    page = read("frontend/src/pages/admin/index.tsx")
    assert not legacy.exists()
    assert "AdminInteractiveBankDashboard" not in page


def test_synthetic_preview_is_confined_to_sandbox_or_marker_components() -> None:
    allowed = {
        "frontend/src/lib/dashboard/componentContract.ts",
        "frontend/src/components/dashboard/MiniCharts.tsx",
        "frontend/src/components/dashboard/PanelChrome.tsx",
        "frontend/src/components/dashboard/ProgressSystem.tsx",
        "frontend/src/components/dashboard/EnergyDashboardSandboxPrototype.tsx",
        "frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx",
        "frontend/src/components/dashboard/RanksDashboardSandboxPrototype.tsx",
    }
    offenders: list[str] = []
    for path in (ROOT / "frontend/src").rglob("*.tsx"):
        rel = path.relative_to(ROOT).as_posix()
        txt = path.read_text(encoding="utf-8", errors="ignore")
        if "synthetic_preview" in txt and rel not in allowed:
            offenders.append(rel)
        if "synthetic={true}" in txt and rel not in allowed:
            offenders.append(rel)
    for path in (ROOT / "frontend/src").rglob("*.ts"):
        rel = path.relative_to(ROOT).as_posix()
        txt = path.read_text(encoding="utf-8", errors="ignore")
        if "synthetic_preview" in txt and rel not in allowed:
            offenders.append(rel)
    assert offenders == []


def test_frontend_seams_and_docs_include_directional_amount_metrics() -> None:
    seams = read("frontend/src/lib/api/generated/adminSeams.ts")
    docs = read("docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS.md")
    for marker in [
        "efhc_transfer_amount",
        "efhc_credit_amount",
        "efhc_debit_amount",
        "EFHC gross turnover",
    ]:
        assert marker in seams or marker in docs
    assert "gross turnover, credit + debit, not net balance" in docs


def test_generated_report_records_truth_hardening_boundaries() -> None:
    data = load(
        "reports/generated/synthetic_data_cleanup_truth_hardening_v170_68.json"
    )
    assert data["cycle"] == 1492
    assert data["archive_version"] == "v170.68"
    assert data["truth_model"] == "runtime_real_timeseries_or_explicit_empty_state"
    assert data["new_metric_contracts"] == [
        "efhc_credit_amount",
        "efhc_debit_amount",
    ]
    for key in [
        "migrations_changed",
        "economy_changed",
        "dependencies_changed",
        "lock_files_changed",
        "ci_workflows_changed",
        "write_actions_added",
        "dashboard_idempotency_key_created",
        "money_changing_service_called",
        "raw_payload_visible",
        "debug_json_visible",
        "secrets_visible",
        "fake_time_series_added",
        "synthetic_runtime_series_added",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
    ]:
        assert data[key] is False


def test_navigation_and_test_manifest_reference_cycle_1492() -> None:
    for rel in [
        "KERNEL.md",
        "map_element.md",
        "docs/NORM/DASHBOARD_VISUAL_PLAN.md",
        "docs/NORM/DASHBOARD_VISUAL_KERNEL.md",
        "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md",
        "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md",
        "docs/cycles/WORK_CYCLES.md",
        "docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md",
        "docs/testing/TEST_GUARD_MANIFEST.md",
        "reports/REPORTS_INDEX.md",
    ]:
        text = read(rel)
        if rel == "KERNEL.md":
            assert "Synthetic Data Cleanup / Truth Hardening" in text
        else:
            assert "1492 — Synthetic Data Cleanup / Truth Hardening" in text
    manifest = load("docs/testing/TEST_GUARD_MANIFEST.json")
    assert "test_synthetic_data_cleanup_truth_hardening.py" in str(manifest)
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "synthetic_data_cleanup_truth_hardening" in routes


def test_grafana_and_sandbox_reference_only_for_cycle_1492() -> None:
    grafana = read("docs/NORM/SYNTHETIC_DATA_CLEANUP_GRAFANA_ELEMENT_ANALYSIS.md")
    norm = read("docs/NORM/SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md")
    assert "Grafana использована только как visual-pattern/reference layer" in norm
    assert "Runtime-код Grafana" in grafana
    assert (
        "Песочница использована только как reference/navigation/prototype layer"
        in norm
    )
    assert "No sandbox runtime code was copied" in read(
        "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md"
    )
