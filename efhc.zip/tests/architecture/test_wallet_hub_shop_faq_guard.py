from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_faq_is_contained_inside_app_frame() -> None:
    css = read("frontend/src/styles/globals.css")
    assert ".efhc-faq-shell," in css
    assert "contain:inline-size" in css
    assert "overflow-wrap:anywhere" in css
    assert "overscroll-behavior-x:contain" in css
    assert "white-space:normal !important" in css


def test_game_ui_kit_has_action_and_product_cards() -> None:
    source = read("frontend/src/components/ui/GameShell.tsx")
    assert "export function GameActionCard" in source
    assert "export function GameProductCard" in source
    assert "efhc-game-action-card" in source
    assert "efhc-game-product-card" in source


def test_hub_uses_game_shell_not_old_telegram_cards() -> None:
    source = read("frontend/src/features/hub/HubPage.tsx")
    assert "GamePageShell" in source
    assert 'className="efhc-hub-choice"' in source
    assert source.count('data-hub-action=') == 2
    assert "TelegramActionCard" not in source
    assert "TelegramInfoBlock" not in source


def test_browser_shop_uses_game_cards_and_clean_errors() -> None:
    source = read(
        "frontend/src/features/browser-shop/BrowserShopPage.tsx",
    )
    assert "GamePageShell" in source
    assert "GameProductCard" in source
    assert "TelegramProductCard" not in source
    assert "TelegramHeroSection" not in source
    assert "err instanceof Error" not in source
    assert "portal.browser_shop.open_failed_title" in source
    assert "open_failed_clean_detail" not in source


def test_wallet_page_uses_game_stats_for_wallet_history() -> None:
    source = read(
        "frontend/src/features/profile/WebProfilePage.tsx"
    ) + read("frontend/src/components/profile/ProfileWalletSection.tsx")
    assert "GameStatsGrid" in source
    assert "GameNotice" in source
    assert "data-wallet-list-boundary" in source
    assert "wallet.connect_hint" in source


def test_new_locale_keys_exist_in_ru_and_en() -> None:
    ru = read("frontend/public/locale/ru.json")
    en = read("frontend/public/locale/en.json")
    for key in (
        "hub.clean_runtime_title",
        "hub.clean_runtime_detail",
        "portal.browser_shop.open_failed_clean_detail",
    ):
        assert key in ru
        assert key in en
