"""Cycle-independent observability and rollout readiness guards."""

from __future__ import annotations

import json
from pathlib import Path

from backend.app.core.runtime_observability import (
    RuntimeObservabilityRegistry,
    normalize_route,
)
from ops.release.check_environment_parity import compare
from ops.release.rollback_preflight import inspect_archive

ROOT = Path(__file__).resolve().parents[2]


def test_runtime_metrics_normalize_identifiers_and_keep_privacy() -> None:
    route = normalize_route(
        "/api/withdraw/1234567890/"
        "abcdefabcdefabcdefabcdefabcdefab"
    )
    assert route == "/api/withdraw/:id/:id"
    registry = RuntimeObservabilityRegistry(max_samples=100)
    registry.record(
        method="POST",
        route="/api/withdraw/1234567890?token=secret",
        status_code=503,
        duration_ms=42.5,
    )
    snapshot = registry.snapshot()
    assert snapshot["sample_count"] == 1
    assert snapshot["recent_5xx"] == 1
    assert snapshot["privacy"] == {
        "request_bodies_stored": False,
        "query_strings_stored": False,
        "identifiers_normalized": True,
    }
    serialized = json.dumps(snapshot)
    assert "secret" not in serialized
    assert "1234567890" not in serialized


def test_correlation_and_observability_middleware_are_registered() -> None:
    main = (ROOT / "backend/app/main.py").read_text(
        encoding="utf-8"
    )
    correlation = (
        ROOT / "backend/app/core/logging_core.py"
    ).read_text(encoding="utf-8")
    assert "CorrelationIdMiddleware" in main
    assert "RequestObservabilityMiddleware" in main
    assert '"x-request-id"' in correlation
    assert '"idempotency-key"' in correlation
    assert '"x - request - id"' not in correlation


def test_readiness_and_metrics_contracts_exist() -> None:
    routes = (
        ROOT / "backend/app/routes/system_routes.py"
    ).read_text(encoding="utf-8")
    assert '"/health/readiness"' in routes
    assert '"/meta/metrics"' in routes
    assert '"/meta/deployment"' in routes
    assert "0002" in routes
    assert "JSONResponse(status_code=503" in routes


def test_kubernetes_manifests_are_immutable_and_probe_ready() -> None:
    backend = (
        ROOT / "ops/k8s/backend-deployment.yaml"
    ).read_text(encoding="utf-8")
    frontend = (
        ROOT / "ops/k8s/frontend-deployment.yaml"
    ).read_text(encoding="utf-8")
    ingress = (ROOT / "ops/k8s/ingress.yaml").read_text(
        encoding="utf-8"
    )
    for manifest in (backend, frontend):
        assert ":latest" not in manifest
        assert "@sha256:" in manifest
        assert "replicas: 2" in manifest
        assert "maxUnavailable: 0" in manifest
        assert "startupProbe:" in manifest
        assert "readinessProbe:" in manifest
        assert "livenessProbe:" in manifest
        assert "runAsNonRoot: true" in manifest
        assert "allowPrivilegeEscalation: false" in manifest
    assert "tls:" in ingress
    assert 'force-ssl-redirect: "true"' in ingress


def test_environment_parity_is_fail_closed() -> None:
    base = {
        "DB_SCHEMA_CORE": "efhc_core",
        "DB_SCHEMA_ADMIN": "efhc_admin",
        "SCHEDULER_ENABLED": "true",
        "REQUEST_BODY_LIMIT_BYTES": 1048576,
        "CORS_ALLOW_ORIGINS": "https://app.example",
        "TON_NETWORK": "mainnet",
    }
    assert compare(base, dict(base))["ok"] is True
    changed = dict(base)
    changed["TON_NETWORK"] = "testnet"
    result = compare(base, changed)
    assert result["ok"] is False
    assert result["mismatches"][0]["key"] == "TON_NETWORK"


def test_rollback_preflight_rejects_missing_archive(
    tmp_path: Path,
) -> None:
    path = tmp_path / "broken.zip"
    path.write_bytes(b"not a zip")
    try:
        inspect_archive(path)
    except Exception as exc:
        assert exc.__class__.__name__ in {
            "BadZipFile",
            "FileNotFoundError",
        }
    else:
        raise AssertionError("Broken rollback archive was accepted")


def test_alert_rules_and_dashboard_are_privacy_safe() -> None:
    alerts = (
        ROOT / "ops/observability/alert_rules.yaml"
    ).read_text(encoding="utf-8")
    dashboard = json.loads(
        (
            ROOT
            / "ops/monitoring/grafana/efhc-runtime-dashboard.json"
        ).read_text(encoding="utf-8")
    )
    assert "request_bodies: forbidden" in alerts
    assert "query_strings: forbidden" in alerts
    assert "WATCHER_HEARTBEAT_STALE" in alerts
    assert dashboard["uid"] == "efhc-runtime-readiness"
    assert len(dashboard["panels"]) >= 4
