from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1328_documents_exist() -> None:
    paths = [
        "docs/admin/ADMIN_WITHDRAWALS_MOBILE_DECISION_PANEL.md",
        "docs/frontend/FRONTEND_PUBLIC_INTERACTIVITY_BACKLOG.md",
        (
            "docs/audits/"
            "FRONTEND_CYCLE_1328_WITHDRAWALS_MOBILE_DECISION_AUDIT_"
            "V169_07.md"
        ),
        (
            "reports/"
            "change_cycle_2026-05-27_v169_07_cycle_1328_"
            "withdrawals_mobile_decision_panel.md"
        ),
        (
            "reports/generated/"
            "frontend_cycle_1328_withdrawals_mobile_decision_panel_"
            "v169_07.json"
        ),
    ]
    missing = [path for path in paths if not (ROOT / path).exists()]
    assert missing == []


def test_mobile_decision_panel_exists_and_uses_ui_kit() -> None:
    text = read(
        "frontend/src/components/admin/"
        "AdminWithdrawalsMobileDecisionPanel.tsx"
    )
    required = [
        "AdminWithdrawalsMobileDecisionPanel",
        'data-admin-withdraw-mobile-decision-cycle="1328"',
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminFlowMapCard",
        "AdminChartCard",
        "AdminActionTable",
        "AdminConfirmationBlock",
        "PENDING",
        "PAID",
        "REJECTED",
        "CANCELED",
        "ERROR",
        "mobile-first",
    ]
    missing = [marker for marker in required if marker not in text]
    assert missing == []


def test_withdrawals_page_uses_mobile_panel_and_no_route_strip() -> (
    None
):
    page = read("frontend/src/pages/admin/withdrawals.tsx")
    assert "AdminWithdrawalsMobileDecisionPanel" in page
    assert "AdminRouteHealthStrip" not in page
    assert "Диагностика маршрута" not in page
    assert "repairConsistency" in page
    assert "payWithWallet" in page
    assert "openApprove" in page
    assert "openReject" in page


def test_cycle_1328_documents_record_sandbox_and_public_ui_answer() -> (
    None
):
    admin_doc = read(
        "docs/admin/ADMIN_WITHDRAWALS_MOBILE_DECISION_PANEL.md"
    )
    public_doc = read(
        "docs/frontend/FRONTEND_PUBLIC_INTERACTIVITY_BACKLOG.md"
    )
    required_admin = [
        "Песочница.xz",
        "EFHC_SANDBOX_COMPACT_v002",
        "chart-area-interactive.tsx",
        "section-cards.tsx",
        "data-table.tsx",
        "mobile-admin",
    ]
    required_public = [
        "Возможно добавить интерактивности",
        "Да",
        "Public UI",
        "Energy",
        "Panels",
        "Exchange",
    ]
    assert [
        marker for marker in required_admin if marker not in admin_doc
    ] == []
    assert [
        marker for marker in required_public if marker not in public_doc
    ] == []


def test_css_contains_mobile_first_withdrawals_rules() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "work pass",
        ".efhc-admin-withdraw-mobile",
        "@media (max-width:430px)",
        "touch-action:manipulation",
    ]
    missing = [marker for marker in required if marker not in css]
    assert missing == []
