from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_error_boundary_uses_recoverable_copy_not_raw_detail() -> None:
    src = read("frontend/src/components/ErrorBoundary.tsx")
    assert "common.screen_refresh_needed" in src
    assert "common.safe_recoverable_screen_detail" in src
    assert "raw?.message" not in src
    assert "String(\n      raw" not in src
    assert "translate(\"common.unexpected_error\")" not in src


def test_error_boundary_console_is_dev_only() -> None:
    src = read("frontend/src/components/ErrorBoundary.tsx")
    assert 'process.env.NODE_ENV !== "production"' in src
    assert 'console.error("EFHC UI error", error)' in src
