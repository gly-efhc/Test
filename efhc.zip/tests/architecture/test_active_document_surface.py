from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_проверка_active_document_surface_guard() -> None:
    result = subprocess.run(
        [sys.executable, "ops/documents/check_active_document_surface.py"],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "ACTIVE_DOCUMENT_SURFACE: PASS" in result.stdout
