from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADMIN_HUB_ROUTES = ROOT / "backend" / "app" / "routes" / "admin_hub_routes.py"
ADMIN_SHOP_ROUTES = ROOT / "backend" / "app" / "routes" / "admin_shop_routes.py"
ROUTES_INIT = ROOT / "backend" / "app" / "routes" / "__init__.py"
OPENAPI = ROOT / "backend" / "openapi" / "openapi.json"
FRONTEND_HUB = ROOT / "frontend" / "src" / "features" / "admin" / "AdminHubPage.tsx"
FRONTEND_HUB_PAGE = ROOT / "frontend" / "src" / "pages" / "admin" / "hub.tsx"
FRONTEND_DIAGNOSTICS = ROOT / "frontend" / "src" / "pages" / "admin" / "diagnostics.tsx"
SERVICE = ROOT / "backend" / "app" / "services" / "admin" / "admin_hub_links_service.py"
MODEL = ROOT / "backend" / "app" / "models" / "hub_links_models.py"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_admin_hub_routes_match_frontend_and_openapi() -> None:
    routes = read(ADMIN_HUB_ROUTES)
    frontend = read(FRONTEND_HUB)
    openapi = json.loads(OPENAPI.read_text(encoding="utf-8"))
    paths = set(openapi.get("paths", {}))

    assert 'APIRouter(prefix="/admin/hub", tags=["admin:hub"])' in routes
    for path in (
        "/admin/hub/links",
        "/admin/hub/links/{link_id}",
        "/admin/hub/links/{link_id}/toggle",
        "/admin/hub/links/reorder",
    ):
        assert path in paths

    assert "ADMIN_HUB_LINKS_PATH" in frontend
    assert "ADMIN_HUB_LINK_UPDATE_PATH" in frontend
    assert "ADMIN_HUB_LINK_TOGGLE_PATH" in frontend
    assert "ADMIN_HUB_LINK_REORDER_PATH" in frontend
    assert "adminPath(ADMIN_HUB_LINK_UPDATE_PATH" in frontend
    assert "adminPath(ADMIN_HUB_LINK_TOGGLE_PATH" in frontend


def test_admin_hub_links_list_route_registered() -> None:
    routes = read(ADMIN_HUB_ROUTES)
    assert '@router.get("/links", response_model=list[HubLinkAdminOut])' in routes
    assert "async def admin_hub_links_list" in routes
    assert "admin_list_hub_links" in routes
    assert "Depends(require_admin)" in routes


def test_admin_hub_links_create_update_archive_routes_registered() -> None:
    routes = read(ADMIN_HUB_ROUTES)
    assert '@router.post("/links", response_model=HubLinkAdminOut)' in routes
    assert '@router.put("/links/{link_id}", response_model=HubLinkAdminOut)' in routes
    assert '"/links/{link_id}/toggle"' in routes
    assert "admin_create_hub_link" in routes
    assert "admin_update_hub_link" in routes
    assert "admin_toggle_hub_link" in routes
    assert routes.count("Depends(require_admin)") >= 5


def test_admin_hub_reorder_route_registered() -> None:
    routes = read(ADMIN_HUB_ROUTES)
    assert '@router.post("/links/reorder", response_model=list[HubLinkAdminOut])' in routes
    assert "async def admin_hub_links_reorder" in routes
    assert "admin_reorder_hub_links" in routes
    assert "await db.commit()" in routes
    assert "Depends(require_admin)" in routes


def test_frontend_admin_hub_calls_existing_backend_routes() -> None:
    routes = read(ADMIN_HUB_ROUTES)
    frontend = read(FRONTEND_HUB)
    page = read(FRONTEND_HUB_PAGE)
    diagnostics = read(FRONTEND_DIAGNOSTICS)

    assert 'export { default } from "../../features/admin/AdminHubPage";' in page
    assert "ADMIN_HUB_LINKS_PATH" in frontend
    assert "ADMIN_HUB_LINK_REORDER_PATH" in frontend
    assert "ADMIN_HUB_LINK_CREATE_PATH" in frontend
    assert 'path: "/admin/hub/links"' in diagnostics
    assert '@router.get("/links"' in routes
    assert '@router.post("/links"' in routes
    assert '@router.put("/links/{link_id}"' in routes
    assert '"/links/{link_id}/toggle"' in routes
    assert '@router.post("/links/reorder"' in routes


def test_admin_hub_router_is_not_nested_under_admin_shop() -> None:
    shop = read(ADMIN_SHOP_ROUTES)
    init = read(ROUTES_INIT)

    assert '"admin_hub_routes"' in init
    assert '"admin_shop_routes",\n    "admin_hub_routes"' in init
    assert "hub_router" not in shop
    assert "router.include_router" not in shop
    assert "/admin/shop/admin/hub" not in shop
    assert "/admin/hub" not in shop


def test_admin_hub_chain_uses_hub_links_model_and_service() -> None:
    routes = read(ADMIN_HUB_ROUTES)
    service = read(SERVICE)
    model = read(MODEL)

    assert "from app.services.admin.admin_hub_links_service" in routes
    assert "HubLinkAdminOut" in routes
    assert "class HubLink" in model
    assert '__tablename__ = "hub_links"' in model
    assert "admin_list_hub_links" in service
    assert "admin_create_hub_link" in service
    assert "admin_update_hub_link" in service
    assert "admin_toggle_hub_link" in service
    assert "admin_reorder_hub_links" in service
