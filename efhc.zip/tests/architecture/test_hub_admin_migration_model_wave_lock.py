from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (REPO_ROOT / path).read_text(encoding="utf-8")


def test_hub_links_model_exists() -> None:
    text = _read("backend/app/models/hub_links_models.py")
    assert "class HubLink" in text
    assert '__tablename__ = "hub_links"' in text
    assert "uq_hub_links_code" in text
    assert "ck_hub_links_target_kind" in text
    assert "ck_hub_links_open_mode" in text


def test_hub_links_structure_and_seed_have_single_owners() -> None:
    init_text = _read("backend/migrations/versions/0001_initial_release_schema.py")
    seed_text = _read("backend/app/release/initial_data.py")
    assert "Base.metadata.create_all" in init_text
    assert "INSERT INTO efhc_core.hub_links" not in init_text
    assert "SYSTEM_MANAGED_HUB_LINKS" in seed_text
    assert "ON CONFLICT (code) DO UPDATE SET" in seed_text


def test_hub_links_layer_has_no_price_fields() -> None:
    model = _read("backend/app/models/hub_links_models.py")
    crud = _read("backend/app/crud/admin/admin_hub_links_crud.py")
    service = _read(
        "backend/app/services/admin/admin_hub_links_service.py"
    )
    combined = model + "\n" + crud + "\n" + service
    assert "price_efhc" not in combined
    assert "price_ton" not in combined
    assert "price_usdt" not in combined
    assert "pay_currencies" not in combined
