from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/FRONTEND_API_I18N_CONSISTENCY.md"


def _doc() -> str:
    return DOC.read_text(encoding="utf-8")


def test_frontend_api_i18n_consistency_doc_exists() -> None:
    assert DOC.exists()
    assert "| Page/component | Button/action |" in _doc()


def test_no_user_facing_tg_id_labels_in_frontend() -> None:
    text = _doc()
    assert "must not show raw `tg_id`" in text


def test_no_debug_payload_internal_text_in_user_pages() -> None:
    text = _doc()
    assert "must not show debug/internal payload" in text


def test_faq_vertical_canon_is_documented() -> None:
    text = _doc()
    assert "FAQ is vertical" in text
    assert "FAQ" in text


def test_hub_allowed_buttons_canon_is_documented() -> None:
    text = _doc()
    assert "HUB contains only allowed buttons" in text


def test_frontend_pages_have_loading_error_empty_state_status() -> None:
    text = _doc()
    for col in ["Loading state", "Error state", "Empty state"]:
        assert col in text


def test_backend_raw_error_mapping_canon_exists() -> None:
    text = _doc()
    assert "Raw backend exceptions" in text
    assert "human-readable" in text
