from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def load(path: str) -> dict:
    return json.loads(read(path))


def test_real_time_series_contract_docs_exist() -> None:
    for rel in [
        "docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS.md",
        "docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1491_REAL_TIME_SERIES_BACKEND_CONTRACTS.md",
        "reports/generated/real_time_series_backend_contracts_v170_67.json",
        "reports/generated/green_ci_log_proof_v170_67.json",
        "reports/change_cycle_2026-06-10_v170_67_cycle_1491_real_time_series_backend_contracts.md",
        "backend/app/routes/admin_observability_routes.py",
    ]:
        assert (ROOT / rel).exists(), rel


def test_backend_route_is_admin_read_only_and_registered() -> None:
    src = read("backend/app/routes/admin_observability_routes.py")
    registry = read("backend/app/routes/__init__.py")
    assert 'prefix="/admin/observability"' in src
    assert "Depends(require_admin)" in src
    assert "admin_observability_routes" in registry
    for marker in [
        '@router.get(\n    "/summary"',
        '@router.get(\n    "/timeseries"',
        '@router.get(\n    "/events"',
        '@router.get(\n    "/health"',
        'data_kind: Literal["real_timeseries"]',
        "synthetic: bool = False",
        "no_rows_in_selected_range",
        "SET LOCAL statement_timeout",
    ]:
        assert marker in src
    for forbidden in [
        "@router.post",
        "@router.put",
        "@router.patch",
        "@router.delete",
        "Idempotency-Key",
        "require_idempotency",
        "credit_user__main__from_bank_by_tg_id",
        "debit_user__main__to_bank_by_tg_id",
        "process_efhc_deposit",
        "raw_tx",
        "initData",
        "process.env",
        "synthetic_preview",
    ]:
        assert forbidden not in src


def test_timeseries_contract_uses_allowed_runtime_tables_only() -> None:
    src = read("backend/app/routes/admin_observability_routes.py")
    for marker in [
        '"users_created"',
        '"panels_created"',
        '"withdrawals_created"',
        '"payment_intents_created"',
        '"efhc_transfer_count"',
        '"efhc_transfer_amount"',
        "date_trunc(:bucket",
        "make_interval(hours => :hours)",
        "efhc_transfers_log safe projection",
    ]:
        assert marker in src
    assert "METRICS[str(metric)]" in src
    assert "table=f\"{CORE_SCHEMA}.users\"" in src


def test_openapi_and_frontend_seams_include_observability_paths() -> None:
    openapi = load("backend/openapi/openapi.json")
    for path in [
        "/admin/observability/summary",
        "/admin/observability/timeseries",
        "/admin/observability/events",
        "/admin/observability/health",
    ]:
        assert path in openapi["paths"]
        assert "get" in openapi["paths"][path]
    seams = read("frontend/src/lib/api/generated/adminSeams.ts")
    for marker in [
        "ADMIN_OBSERVABILITY_SUMMARY_PATH",
        "ADMIN_OBSERVABILITY_TIMESERIES_PATH",
        "ADMIN_OBSERVABILITY_EVENTS_PATH",
        "ADMIN_OBSERVABILITY_HEALTH_PATH",
        "AdminObservabilityTimeseriesResponse",
        "AdminObservabilitySummaryResponse",
        "AdminObservabilityEventsResponse",
        "data_kind: 'real_timeseries'",
        "synthetic: boolean",
    ]:
        assert marker in seams


def test_generated_report_records_safety_boundaries() -> None:
    data = load(
        "reports/generated/real_time_series_backend_contracts_v170_67.json"
    )
    assert data["cycle"] == 1491
    assert data["archive_version"] == "v170.67"
    assert data["truth_model"] == "real_timeseries_backend_contracts"
    assert data["new_read_only_endpoints"] == [
        "GET /admin/observability/summary",
        "GET /admin/observability/timeseries",
        "GET /admin/observability/events",
        "GET /admin/observability/health",
    ]
    for key in [
        "migrations_changed",
        "economy_changed",
        "dependencies_changed",
        "lock_files_changed",
        "ci_workflows_changed",
        "write_actions_added",
        "dashboard_idempotency_key_created",
        "money_changing_service_called",
        "raw_payload_visible",
        "debug_json_visible",
        "secrets_visible",
        "fake_time_series_added",
        "synthetic_runtime_series_added",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
    ]:
        assert data[key] is False


def test_green_ci_log_proof_is_fixed_for_cycle_1491() -> None:
    data = load("reports/generated/green_ci_log_proof_v170_67.json")
    assert data["source_log"] == "logs_73205751012.zip"
    assert data["log_status"] == "green"
    assert data["gate_summary"] == "OK: all gate steps passed."
    assert data["steps"]["pytest"] == (
        "1635 passed, 8 skipped, 1 warning in 39.44s"
    )
    assert data["steps"]["frontend_build"].startswith("passed")
    assert data["not_claimed_for_new_archive_after_cycle_1491"] is True


def test_navigation_and_manifests_reference_cycle_1491() -> None:
    for path in [
        "KERNEL.md",
        "map_element.md",
        "docs/NORM/DASHBOARD_VISUAL_PLAN.md",
        "docs/NORM/DASHBOARD_VISUAL_KERNEL.md",
        "docs/cycles/WORK_CYCLES.md",
        "docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md",
        "docs/testing/TEST_GUARD_MANIFEST.md",
        "reports/REPORTS_INDEX.md",
    ]:
        txt = read(path)
        if path == "KERNEL.md":
            assert "Real Time-Series Backend Contracts" in txt
        else:
            assert "1491 — Real Time-Series Backend Contracts" in txt
    manifest = load("docs/testing/TEST_GUARD_MANIFEST.json")
    assert "test_real_time_series_backend_contracts.py" in str(manifest)
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "real_time_series_backend_contracts" in routes


def test_grafana_and_sandbox_reference_only() -> None:
    grafana = read(
        "docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS_GRAFANA_ELEMENT_ANALYSIS.md"
    )
    sandbox = read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    assert "reference-only" in grafana
    assert "Runtime-код Grafana" in grafana
    assert "No Grafana runtime code" not in read(
        "backend/app/routes/admin_observability_routes.py"
    )
    assert "No sandbox runtime code was copied" in sandbox
