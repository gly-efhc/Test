from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def _onboarding_block() -> str:
    src = read("backend/app/services/referral_service.py")
    return src.split(
        "async def onboard_user_at_first_creation", 1
    )[1].split(
        "# ----------------------------------------------------------------------",
        1,
    )[0]


def test_referral_onboarding_имеет_одну_commit_boundary() -> None:
    block = _onboarding_block()
    assert "create_new_account(" in block
    assert "_create_bot_user_identity(" in block
    assert "await db.commit()" in block
    assert "await db.rollback()" in block
    assert "INSERT INTO efhc_core.users" not in block
    assert "register_referral_and_reward" not in block
    assert block.index("create_new_account(") < block.index(
        "_create_bot_user_identity("
    ) < block.rindex("await db.commit()")


def test_invalid_referral_обрабатывается_до_commit() -> None:
    core = read("backend/app/identity/account_registration.py")
    block = _onboarding_block()
    user_create = core.index("user = User(")
    assert core.index('AccountRegistrationError("invalid_code")') < user_create
    assert core.index('AccountRegistrationError("code_not_found")') < user_create
    assert '"invalid_code"' in block
    assert '"code_not_found"' in block
    assert "ReferralOnboardingRejected" in block


def test_existing_user_блокируется_до_registration_core() -> None:
    block = _onboarding_block()
    assert block.index("select(User.id)") < block.index(
        "create_new_account("
    )
    assert 'reason="existing_user_locked"' in block
