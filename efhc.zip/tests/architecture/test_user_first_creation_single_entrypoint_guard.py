from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend/app"
REGISTRATION = Path("backend/app/identity/account_registration.py")


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def _user_constructor_paths() -> set[Path]:
    found: set[Path] = set()
    for path in BACKEND.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if isinstance(node.func, ast.Name) and node.func.id == "User":
                found.add(path.relative_to(ROOT))
    return found


def test_player_user_creation_uses_registration_core_only() -> None:
    insert_paths: set[str] = set()
    for path in BACKEND.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        if "INSERT INTO efhc_core.users" in text:
            insert_paths.add(path.relative_to(ROOT).as_posix())

    assert insert_paths == {
        "backend/app/release/initial_data.py",
    }
    assert _user_constructor_paths() == {REGISTRATION}

    onboarding = read("backend/app/services/referral_service.py")
    registration = read(
        "backend/app/identity/account_registration.py"
    )
    telegram = read(
        "backend/app/identity/telegram_auth_session.py"
    )
    ton = read(
        "backend/app/identity/ton_account_registration.py"
    )
    assert "async def onboard_user_at_first_creation" in onboarding
    assert "await create_new_account(" in onboarding
    assert "create_new_account(" in telegram
    assert "create_new_account(" in ton
    assert "INSERT INTO efhc_core.users" not in onboarding
    assert "user = User(" in registration

    seed = read("backend/app/release/initial_data.py")
    assert "BANK_EFHC" in seed
    assert "INSERT INTO efhc_core.users" in seed


def test_profile_and_money_routes_cannot_create_zero_users_implicitly() -> None:
    crud = read("backend/app/crud/user_crud.py")
    me = read("backend/app/routes/me_routes.py")
    money = read("backend/app/services/transactions_service.py")

    assert "async def ensure_user(" not in crud
    assert "INSERT INTO" not in crud
    assert "User.global_id == int(owner.global_id)" in me
    assert "user_not_onboarded" in me
    assert "ensure_user" not in me
    assert "_UPSERT_USER_SQL" not in money
    assert "ON CONFLICT (global_id) DO NOTHING" not in money
    assert "user_not_onboarded" in money
