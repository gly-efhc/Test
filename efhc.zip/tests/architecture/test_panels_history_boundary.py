from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PANELS = ROOT / "frontend/src/pages/panels.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"
LOCALES = ROOT / "frontend/public/locale"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_panels_has_account_history_boundary_marker() -> None:
    src = read(PANELS)
    assert 'data-panels-history-boundary="account-history-only"' in src
    assert 'data-panels-history-link="account-history"' in src
    assert 't("panels.history_boundary_note")' in src


def test_panels_does_not_link_to_wallet_from_panel_context() -> None:
    src = read(PANELS)
    assert 'openProfile("wallet")' not in src
    assert 't("panels.open_wallet")' not in src
    assert "data-panels-wallet-link" not in src


def test_panels_history_boundary_style_exists() -> None:
    css = read(CSS)
    assert "work pass" in css
    assert ".efhc-panels-history-boundary" in css
    assert ".efhc-panels-history-button" in css


def test_panels_history_boundary_locale_key_exists() -> None:
    key = '"panels.history_boundary_note"'
    for path in LOCALES.glob("*.json"):
        assert key in read(path)


def test_cycle_1285_documented() -> None:
    text = read(PLAN) + "\n" + read(REPORTS)
    assert "v168_83 / work pass" in text
    assert "Panels activation/history boundary" in text
    assert "account history" in text


def test_panels_open_wallet_key_removed_from_locales() -> None:
    key = '"panels.open_wallet"'
    for path in LOCALES.glob("*.json"):
        assert key not in read(
            path
        ), f"{path.name} still has deprecated panels.open_wallet"
