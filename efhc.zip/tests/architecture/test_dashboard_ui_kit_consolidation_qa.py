from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONTRACT = ROOT / "frontend/src/lib/dashboard/componentContract.ts"
DOC = ROOT / "docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md"
CYCLE = ROOT / "docs/cycles/WORK_CYCLES_1501_DASHBOARD_UI_KIT_CONSOLIDATION_QA.md"
REPORT = ROOT / "reports/generated/dashboard_ui_kit_consolidation_qa_v170_77.json"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
FUTURE = ROOT / "docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md"
AUDIT = ROOT / "docs/audits/AUDIT_TZ_REPAIR_1501_1504.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_cycle_1501_contract_action_extension_closed() -> None:
    src = read(CONTRACT)
    assert "onClick?: () => void" in src
    assert "actionKind?: DashboardPanelActionKind" in src
    assert "href?: string" in src
    assert "disabled?: boolean" in src
    assert "danger?: boolean" in src
    assert "EFHC_DASHBOARD_CONTRACT_V2" in src


def test_cycle_1501_action_kinds_are_explicit() -> None:
    src = read(CONTRACT)
    for marker in (
        '"nav"',
        '"mutation-safe"',
        '"copy"',
        '"external"',
    ):
        assert marker in src


def test_cycle_1501_parent_guard_boundary_documented() -> None:
    doc = read(DOC)
    assert "## Action kinds" in doc
    assert "Guard + confirm + idempotency" in doc
    assert "Dashboard components never call `apiRequest`" in doc
    assert "implemented at page level" in doc


def test_cycle_1501_no_backend_or_openapi_scope() -> None:
    report = json.loads(read(REPORT))
    boundaries = report["boundaries"]
    assert boundaries["backend_changed"] is False
    assert boundaries["openapi_changed"] is False
    assert boundaries["money_flow_changed"] is False
    assert boundaries["runtime_behavior_changed"] is False


def test_cycle_1501_navigation_and_audit_registered() -> None:
    assert "CYC-1459" in read(AUDIT)
    assert "DashboardPanelAction" in read(AUDIT)
    assert "DASH-01" in read(AUDIT)
    assert "DASH-02" in read(AUDIT)
    assert "DASH-03" in read(AUDIT)
    kernel = read(KERNEL)
    assert "Dashboard UI Kit Consolidation QA" in kernel
    for path in (MAP, FUTURE):
        text = read(path)
        assert "1501" in text
        assert "Dashboard UI Kit Consolidation QA" in text
    assert "WORK_CYCLES_1501_DASHBOARD_UI_KIT_CONSOLIDATION_QA.md" in read(MAP)
    assert "test_dashboard_ui_kit_consolidation_qa.py" in read(MAP)


def test_cycle_1501_reference_layers_only() -> None:
    text = read(CYCLE) + read(KERNEL) + read(MAP)
    assert "Песочница" in text
    assert "reference" in text
    assert "Grafana" in text
    assert "visual-pattern" in text
    assert "Runtime-код не переносился" in text
