from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1335_documents_exist() -> None:
    required = [
        "docs/audits/CI_LOGS_71056336346_REPAIR_V169_14.md",
        "docs/backend/CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK.md",
        (
            "reports/change_cycle_2026-05-27_v169_14_cycle_1335_ci_logs_"
            "71056336346_repair.md"
        ),
        "reports/generated/ci_logs_71056336346_repair_v169_14.json",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_requirements_test_pins_pytest_bootstrap_layer() -> None:
    text = read("requirements-test.txt")
    required = [
        "pytest==9.0.3",
        "pytest-asyncio==1.4.0",
        "freezegun==1.5.1",
        "psycopg[binary]==3.3.4",
        "alembic==1.18.4",
        "PyJWT==2.13.0",
    ]
    for item in required:
        assert item in text


def test_ci_installs_test_requirements_before_pytest() -> None:
    ci = read("ci.yml")
    install = "pip install -r extracted/requirements-test.txt"
    assert install in ci
    runner = "PYTHONPATH=backend pytest -q"
    assert runner in ci
    assert ci.index(install) < ci.index(runner)
    assert "OK: test dependency bootstrap" in ci


def test_runtime_requirements_stay_clean() -> None:
    runtime = read("backend/requirements.txt")
    lock = read("backend/requirements.lock")
    assert "freezegun" not in runtime
    assert "freezegun" not in lock
    assert "pytest-asyncio" not in runtime


def test_cycle_plan_shifts_shop_to_1336() -> None:
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1335: CI logs 71056336346 repair" in plan
    assert "1336: Shop admin actions" in plan
    assert "1357: Admin recovery checkpoint report" in plan


def test_audit_records_uploaded_log_failure() -> None:
    audit = read("docs/audits/CI_LOGS_71056336346_REPAIR_V169_14.md")
    assert "logs_71056336346.zip" in audit
    assert "ModuleNotFoundError: No module named 'freezegun'" in audit
    assert "Frontend Next.js 16.2.6 build is green" in audit
