from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_hub_has_two_canonical_typed_actions() -> None:
    hub = read("frontend/src/features/hub/HubPage.tsx")
    service = read("frontend/src/services/hub.service.ts")
    query = read("frontend/src/queries/useHub.ts")
    css = read("frontend/src/styles/globals.css")

    assert hub.count('data-hub-action=') == 2
    assert 'data-hub-runtime="two-canonical-actions"' in hub
    assert 'data-hub-visible-action-count="2"' in hub
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in hub
    assert 'data-hub-handoff-kind="external-top-up"' in hub
    assert "useHubEfhcHandoff" in hub
    assert "apiRequest" not in hub
    assert "VIP_URL" in hub
    assert "getgems.io/efhc-nft" in hub.lower()
    assert "hub.action_vip_nft" in hub
    assert "hub.action_top_up_efhc_description" not in hub
    assert "hubEfhcHandoffSchema" in service
    assert "HUB_EFHC_HANDOFF_PATH" in service
    assert 'apiRequest<unknown>(HUB_EFHC_HANDOFF_PATH, "POST")' in service
    assert "useMutation" in query
    assert ".efhc-hub-two-actions" in css
    assert ".efhc-hub-choice-grid" in css

def test_direct_deposit_visual_contract_is_mobile_responsive() -> None:
    css = read("frontend/src/styles/globals.css")
    assert ".efhc-direct-deposit_amount-control" in css
    assert ".efhc-direct-deposit_status.is-confirmed" in css
    assert ".efhc-direct-deposit_actions" in css
    assert "@media (max-width: 390px)" in css
    assert "grid-template-columns: 1fr;" in css
    assert "@media (min-width: 768px)" in css
