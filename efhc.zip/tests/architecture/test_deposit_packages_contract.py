from __future__ import annotations

import re
from pathlib import Path


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_deposit_packages_contract_items_is_canon() -> None:
    """Canon: /deposit/packages contract uses field 'items'.

    We enforce frontend and backend to agree on the same field name.
    """

    fe = Path("frontend/src/components/DepositModal.tsx")
    assert fe.exists(), "DepositModal.tsx missing"
    fe_txt = _read_text(fe)

    assert "r?.items" in fe_txt
    assert "r?.packages" not in fe_txt

    sch = Path("backend/app/schemas/deposit_schemas.py")
    assert sch.exists(), "deposit_schemas.py missing"
    sch_txt = _read_text(sch)

    assert re.search(r"class\s+DepositPackagesOut\b", sch_txt)
    assert re.search(r"\bitems\s*:\s*list\[", sch_txt)

    rt = Path("backend/app/routes/deposit_routes.py")
    assert rt.exists(), "deposit_routes.py missing"
    rt_txt = _read_text(rt)

    assert re.search(r"/packages\"", rt_txt)
    assert "response_model=DepositPackagesOut" in rt_txt
    assert "DepositPackagesOut(items=items)" in rt_txt
