from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_deposit_packages_contract_is_not_used_by_direct_deposit() -> None:
    """Package purchase and direct EFHC jetton deposit stay separate."""

    modal = read("frontend/src/components/DepositModal.tsx")
    assert 'data-direct-deposit-kind="efhc-jetton-to-efhcm"' in modal
    assert "/deposit/packages" not in modal
    assert "package_id" not in modal
    assert "r?.items" not in modal

    schemas = read("backend/app/schemas/deposit_schemas.py")
    assert re.search(r"class\s+DepositPackagesOut\b", schemas)
    assert re.search(r"\bitems\s*:\s*list\[", schemas)

    routes = read("backend/app/routes/deposit_routes.py")
    assert re.search(r'/packages"', routes)
    assert "response_model=DepositPackagesOut" in routes
    assert "DepositPackagesOut(items=items)" in routes


def test_package_route_is_not_global_header_plus_route() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    header = read("frontend/src/components/GlobalHeader.tsx")
    assert 'aria-label={t("deposit.direct_title")}' in header
    assert "setDepositOpen(true);" in layout
    assert "/deposit/packages" not in layout
    assert "browser-shop" not in layout.split(
        "function openDeposit()", 1
    )[1].split("}", 1)[0]
