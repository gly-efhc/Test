from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(".")
NFT_SERVICE = Path("backend/app/services/nft_check_service.py")
ME_ROUTES = Path("backend/app/routes/me_routes.py")
ADMIN_WITHDRAWALS = Path(
    "backend/app/services/admin/admin_withdrawals_service.py"
)
WITHDRAW_MODELS = Path("backend/app/models/withdraw_models.py")
MIGRATION_0001 = Path("backend/migrations/versions/0001_initial_release_schema.py")
DB_DRIFT_MATRIX = Path("docs/NORM/DB_DRIFT_MATRIX.md")
VIP_CANON = Path("docs/NORM/VIP_NFT_TONCONNECT_SYNC_CANON.md")
BONUS_STATUS = Path("docs/NORM/BONUS_AWARDS_LEGACY_STATUS.md")


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_nft_wallet_resolver_uses_wallet_bindings_before_legacy_ton_wallet() -> None:
    src = _read(NFT_SERVICE)
    binding_pos = src.index("FROM efhc_core.wallet_bindings")
    legacy_pos = src.index("FROM efhc_core.users")
    assert binding_pos < legacy_pos
    assert "is_active = TRUE" in src
    assert "legacy fallback" in src


def test_v1_me_does_not_gate_vip_refresh_by_users_ton_wallet() -> None:
    src = _read(ME_ROUTES)
    assert 'getattr(user, "ton_wallet", None) and stale' not in src
    assert "if stale and provider_tg_id is not None:" in src
    assert "check_user_vip_once" in src


def test_batch_nft_vip_discovery_includes_wallet_bindings_and_deduplicates() -> None:
    src = _read(NFT_SERVICE)
    assert "async def _fetch_wallet_candidates_batch" in src
    assert "WITH canonical AS" in src
    assert "FROM efhc_core.wallet_bindings" in src
    assert "UNION ALL" in src
    assert "NOT EXISTS" in src
    assert "wallet_source" in src


def test_bonus_awards_references_are_legacy_guarded() -> None:
    src = _read(ADMIN_WITHDRAWALS)
    assert "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE" in src
    assert "async def _legacy_bonus_awards_table_exists" in src
    assert "information_schema.tables" in src
    assert "return []" in src
    assert BONUS_STATUS.exists()
    doc = _read(BONUS_STATUS)
    assert "legacy/dead code" in doc
    assert "not active table" in doc


def test_withdraw_request_amount_precision_matches_user_balances() -> None:
    tree = ast.parse(_read(WITHDRAW_MODELS))
    src = _read(WITHDRAW_MODELS)
    amount_block = re.search(
        r"amount: Mapped\[object\] = mapped_column\(\s*Numeric\((\d+),\s*(\d+)\)",
        src,
        re.S,
    )
    assert amount_block is not None
    assert amount_block.groups() == ("30", "8")
    assert tree is not None
    migration = _read(MIGRATION_0001)
    assert "withdraw_requests_amount_numeric30_8" in migration
    assert "NUMERIC(30,8)" in migration


def test_legacy_withdrawals_constraint_name_is_documented() -> None:
    src = _read(WITHDRAW_MODELS)
    assert "ck_payment_intents_status_enum" in src
    assert "P3 legacy cosmetic drift" in src
    assert "not renamed to avoid migration noise" in src
    assert DB_DRIFT_MATRIX.exists()
    matrix = _read(DB_DRIFT_MATRIX)
    assert "withdrawals legacy" in matrix
    assert "documented legacy cosmetic drift" in matrix


def test_allowed_guarded_legacy_exceptions_are_documented() -> None:
    matrix = _read(DB_DRIFT_MATRIX)
    assert "admin_events" in matrix
    assert "nft_check_cache_ton" in matrix
    assert "deprecated_readonly" in matrix


def test_no_raw_sql_references_to_missing_tables_without_guard_or_legacy_doc() -> None:
    allowed = {
        "bonus_awards": "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE",
        "admin_events": "deprecated_readonly",
        "nft_check_cache_ton": "deprecated_readonly",
    }
    matrix = _read(DB_DRIFT_MATRIX)
    for table, marker in allowed.items():
        assert table in matrix
        assert marker in matrix
