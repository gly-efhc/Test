from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND_SRC = ROOT / "frontend" / "src"

UI_PARTS = {
    "components",
    "features",
    "pages",
}
ALLOW_FILES = {
    "frontend/src/lib/publicError.ts",
    "frontend/src/lib/adminError.ts",
}
SAFE_DETAIL_FILES = {
    "frontend/src/components/DepositModal.tsx",
    "frontend/src/features/browser-shop/BrowserShopPage.tsx",
    "frontend/src/pages/admin/panels.tsx",
    "frontend/src/pages/admin/users.tsx",
}

RAW_PATTERNS = [
    re.compile(r"\w+\s+instanceof\s+Error\s*\?\s*\w+\.message"),
    re.compile(r"\w+\?\.message\s*\|\|\s*String\(\w+\)"),
    re.compile(r"detail=\{(?:error|err)\}"),
    re.compile(r">\{(?:error|err)\}<"),
]


def iter_ui_files():
    for part in UI_PARTS:
        base = FRONTEND_SRC / part
        if not base.exists():
            continue
        yield from base.rglob("*.tsx")


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def test_ui_files_do_not_render_raw_error_variables() -> None:
    failures: list[str] = []
    for path in iter_ui_files():
        if rel(path) in ALLOW_FILES:
            continue
        text = path.read_text(encoding="utf-8")
        for pattern in RAW_PATTERNS:
            if (
                pattern.pattern.startswith("detail=")
                and rel(path) in SAFE_DETAIL_FILES
            ):
                continue
            if (
                pattern.pattern.startswith(">\\{")
                and "publicApiErrorMessage" in text
            ):
                continue
            if pattern.search(text):
                failures.append(f"{rel(path)}: {pattern.pattern}")

    assert not failures, "raw UI error patterns found:\n" + "\n".join(
        failures
    )


def test_admin_runtime_tails_use_safe_mapper() -> None:
    files = [
        "frontend/src/components/admin/"
        "AdminLogsEventsDashboardRuntime.tsx",
        "frontend/src/components/admin/"
        "AdminObservabilityTimeseriesDashboardRuntime.tsx",
    ]
    for file_name in files:
        text = (ROOT / file_name).read_text(encoding="utf-8")
        assert "adminSafeLoadError" in text
        assert "err instanceof Error ? err.message" not in text
        assert "error instanceof Error" not in text
