from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BANK = ROOT / "frontend" / "src" / "pages" / "admin" / "bank.tsx"
CSS = ROOT / "frontend" / "src" / "styles" / "globals.css"
PLAN = (
    ROOT
    / "docs"
    / "cycles"
    / "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_admin_bank_has_cycle_marker_and_no_route_diagnostics() -> None:
    src = read(BANK)
    assert 'data-admin-bank-cycle="1323"' in src
    assert "AdminRouteHealthStrip" not in src
    assert "Диагностика маршрута" not in src
    assert "endpoint" not in src.lower()
    assert "raw payload" not in src.lower()


def test_admin_bank_has_sandbox_inspired_interactive_visuals() -> None:
    src = read(BANK)
    assert "data-admin-bank-interactive-chart" in src
    assert "data-admin-bank-interactive-scheme" in src
    assert "chartMode" in src
    assert "setChartMode" in src
    assert "sandbox pattern" in src


def test_admin_bank_has_statistics_and_ledger_boundary() -> None:
    src = read(BANK)
    assert "data-admin-bank-statistics" in src
    assert "data-admin-bank-ledger-boundary" in src
    assert 'ADMIN_REPORTS_OVERVIEW_PATH' in src
    assert 'ADMIN_LOGS_TRANSFERS_PATH' in src
    assert "ADMIN_BANK_BALANCE_PATH" in src


def test_admin_bank_keeps_safe_confirmed_actions() -> None:
    src = read(BANK)
    assert "AdminPromptModal" in src
    assert "newIdempotencyKey" in src
    assert "ADMIN_BANK_MINT_PATH" in src
    assert "ADMIN_BANK_BURN_PATH" in src
    assert "Подтвердить mint" in src
    assert "Подтвердить burn" in src


def test_admin_bank_visual_css_exists() -> None:
    css = read(CSS)
    assert ".efhc-admin-visual-card" in css
    assert ".efhc-admin-chart-toggle" in css
    assert ".efhc-bank-flow" in css
    assert ".efhc-admin-ledger-table" in css


def test_cycle_plan_numbering_marks_1323_done() -> None:
    plan = read(PLAN)
    assert (
        "1323: Bank page statistics and ledger boundary. DONE in v169_"
        "01"
        in plan
    )
    assert (
        "1324: Bank action confirmations and idempotency proof." in plan
    )
