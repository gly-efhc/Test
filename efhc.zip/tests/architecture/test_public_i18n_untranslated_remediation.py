from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
LANGS = [
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]
REMEDIATED_KEYS = [
    "browser.auth_needed",
    "energy.activate_panel_action",
    "energy.activate_panel_note",
    "energy.available_kwh_chip",
    "energy.balance_chip",
    "energy.exchange_action",
    "energy.exchangeable_chip",
    "energy.interactive_overview",
    "energy.interactive_panels",
    "energy.interactive_exchange",
    "energy.interactive_live",
    "energy.interactive_title",
    "energy.next_action",
    "energy.open_action",
    "energy.public_interactivity_safe_note",
    "exchange.amount_hint",
    "exchange.amount_invalid_detail",
    "exchange.amount_over_available",
    "exchange.confirm_exchange_title",
    "exchange.confirm_exchange_detail",
    "exchange.confirmation_ready_detail",
    "exchange.open_wallet",
    "exchange.preview_unavailable_detail",
    "exchange.preview_unavailable_title",
    "exchange.result_hint_title",
    "exchange.result_hint_detail",
    "exchange.interactive_available",
    "exchange.interactive_available_hint",
    "exchange.interactive_confirm",
    "exchange.interactive_confirm_hint",
    "exchange.interactive_form_cta",
    "exchange.interactive_live",
    "exchange.interactive_loading",
    "exchange.interactive_max_amount",
    "exchange.interactive_preview",
    "exchange.interactive_preview_hint",
    "exchange.interactive_ready",
    "exchange.interactive_safe_note",
    "exchange.interactive_title",
    "exchange.full_withdraw_screen",
    "history.load_error",
    "history.filter_all",
    "history.filter_bonuses",
    "history.filter_exchange",
    "history.filter_panels",
    "history.filter_purchases",
    "history.filter_withdraw",
    "wallet.error_title",
    "wallet.error_body",
    "wallet.linked_wallets_count",
    "wallet.state_backend_error",
    "wallet.state_connected",
    "wallet.state_not_connected",
    "wallet.state_pending_proof",
    "wallet.state_bound",
    "portal.browser_shop.active_intent",
    "portal.browser_shop.active_intent_error",
    "portal.browser_shop.intent_create_failed",
    "portal.browser_shop.intent_order_label",
    "portal.browser_shop.memo_label",
    "portal.browser_shop.payment_details_title",
    "portal.browser_shop.payment_details_detail",
    "portal.browser_shop.payment_method_detail",
    "portal.browser_shop.payment_warning_title",
    "portal.browser_shop.payment_warning_detail",
    "portal.browser_shop.wallet_open_failed",
    "portal.browser_shop.payment_done_title",
    "portal.browser_shop.payment_error_title",
    "portal.browser_shop.ton_contour_title",
    "portal.browser_shop.ton_contour_detail",
    "portal.browser_shop.wallet_label",
    "public_profile_trust.title",
    "public_profile_trust.kicker",
    "public_profile_trust.detail",
    "public_profile_trust.cta_wallet",
    "public_profile_trust.cta_history",
    "public_profile_trust.cta_faq",
    "public_profile_trust.wallet_connected",
    "public_profile_trust.wallet_not_connected",
    "public_profile_trust.safe_badge",
    "tasks.error_title",
    "tasks.empty_title",
    "tasks.button_claimed",
    "tasks.button_unavailable",
    "tasks.status_available",
    "tasks.status_claimed",
    "referrals.bonus_rule_title",
    "referrals.bonus_rule_active",
    "ranks.filter_referrals",
    "ranks.filters_title",
    "ranks.referrals",
    "faq.counts_summary",
]
PLACEHOLDER_RE = re.compile(
    r"{[^}]+}|{[^}]+}|{{[^}]+}}|{[a-zA-Z0-9_]+}|{[a-zA-Z0-9_"
    r"]+}|{[^}]+}|{[^}]+}|{[^}]+}|{[a-zA-Z0-9_"
    r"]+}|{[^}]+}|{[^}]+}|{[^}]+}|{[^}]+}"
)
SINGLE_PLACEHOLDER_RE = re.compile(r"(?<!{){[a-zA-Z0-9_]+}(?!})")
DOUBLE_PLACEHOLDER_RE = re.compile(r"{{[a-zA-Z0-9_]+}}")


def load(lang: str) -> dict[str, str]:
    return json.loads(
        (LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8")
    )


def placeholders(value: str) -> set[str]:
    singles = set(SINGLE_PLACEHOLDER_RE.findall(value))
    doubles = set(DOUBLE_PLACEHOLDER_RE.findall(value))
    return singles | doubles


def test_remediation_document_and_generated_report_exist():
    assert (
        ROOT
        / "docs/frontend/PUBLIC_I18N_UNTRANSLATED_KEYS_REMEDIATION.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/I18N_PUBLIC_UNTRANSLATED_REMEDIATION_AUDIT_V169_48.md"
    ).exists()
    assert (
        ROOT
        / "reports/generated/i18n_public_untranslated_remediation_v169_48.json"
    ).exists()


def test_priority_public_i18n_keys_are_localized_and_non_empty():
    en = load("en")
    for lang in LANGS:
        data = load(lang)
        for key in REMEDIATED_KEYS:
            assert key in data, f"{lang} missing {key}"
            assert str(data[key]).strip(), f"{lang} {key} is empty"
            assert (
                data[key] != en[key]
            ), f"{lang} {key} still identical to English"


def test_priority_public_i18n_placeholders_are_preserved():
    en = load("en")
    for lang in LANGS:
        data = load(lang)
        for key in REMEDIATED_KEYS:
            assert placeholders(data[key]) == placeholders(
                en[key]
            ), f"{lang} {key} placeholder drift"


def test_hindi_critical_placeholders_still_preserved():
    hi = load("hi")
    assert "{count}" in hi["wallet.linked_wallets_count"]
    assert "{id}" in hi["withdraw.request_number"]


def test_locale_key_parity_still_exact():
    en_keys = set(load("en"))
    for lang in LANGS:
        assert set(load(lang)) == en_keys
