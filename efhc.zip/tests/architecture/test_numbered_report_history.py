"""Постоянный guard нумерованной истории EFHC reports."""
from __future__ import annotations

from ops.reports.check_numbered_reports import check


def test_история_нумерованных_отчётов_непрерывна_и_проверена_hash() -> None:
    result = check()
    assert result["passed"], result["violations"]
    assert int(result["report_count"]) >= 1
    assert int(result["max_report_number"]) == int(result["report_count"])
