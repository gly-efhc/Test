from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAGE = ROOT / "frontend/src/pages/referrals.tsx"
SERVICE = ROOT / "frontend/src/services/referrals.service.ts"
BACKEND = ROOT / "backend/app/routes/referrals_routes.py"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_referrals_page_contains_all_four_user_required_blocks() -> None:
    page = read(PAGE)

    assert 'data-referrals-progress-bar="true"' in page
    assert 'data-referral-link-main="true"' in page
    assert 'data-referral-share-grid="social"' in page
    assert 'data-referrals-tabs="active-inactive"' in page
    assert 'data-referrals-tab-button="active"' in page
    assert 'data-referrals-tab-button="inactive"' in page
    assert 'data-referrals-current-lvl="true"' in page
    assert 'data-referrals-level-scale="lvl-1-5"' in page


def test_referrals_tabs_are_inline_like_panels_not_navigation_buttons() -> None:
    page = read(PAGE)

    assert "useState<ReferralTab>(\"active\")" in page
    assert 'className="efhc-segmented efhc-referrals-tabs mb-3"' in page
    assert 'setReferralTab("active")' in page
    assert 'setReferralTab("inactive")' in page
    assert 'router.push("/referrals/active")' not in page
    assert 'router.push("/referrals/inactive")' not in page
    assert "<ReferralRoster" in page


def test_level_one_economic_formula_is_backend_owned() -> None:
    service = read(SERVICE)
    backend = read(BACKEND)
    page = read(PAGE)

    for field in [
        "unit_bonus_per_active",
        "level_steps",
        "direct_bonus_total",
        "level_bonus",
        "cumulative_level_bonus",
        "cumulative_total_reward",
        "bonus_asset",
        "full_cycle_direct_bonus",
        "full_cycle_level_bonus",
        "full_cycle_total_bonus",
    ]:
        assert field in service
        assert field in backend
        assert field in page

    assert "10 × 0.1 + 1 = 2 EFHCb" in read(
        ROOT / "backend/app/services/referral_service.py"
    )
