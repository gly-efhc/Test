from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KERNEL = ROOT / "docs/NORM/DASHBOARD_VISUAL_KERNEL.md"
PLAN = ROOT / "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
MAP = ROOT / "map_element.md"
ROOT_KERNEL = ROOT / "KERNEL.md"
REPORT = ROOT / "reports/generated/dashboard_visual_kernel_v170_31.json"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_dashboard_visual_kernel_is_active() -> None:
    text = read(KERNEL)
    assert "ACTIVE_DASHBOARD_VISUAL_KERNEL" in text
    assert "Dashboard Visual Direction Plan" in text
    assert "Admin Dashboard Layer" in text
    assert "Simulation Dashboard Layer" in text
    assert "1456" in text
    assert "Sandbox Dashboard Inventory" in text


def test_dashboard_reference_boundaries_are_guarded() -> None:
    text = read(KERNEL)
    required = [
        "EFHC Bot does not become Grafana",
        "Grafana is visual-pattern reference only",
        "Песочница is reference, navigation and prototype layer only",
        "Runtime code from Grafana or Песочница must not be copied",
        "Beautiful charts must not replace backend truth",
    ]
    for marker in required:
        assert marker in text


def test_plan_root_kernel_and_map_point_to_visual_kernel() -> None:
    plan = read(PLAN)
    root_kernel = read(ROOT_KERNEL)
    mapping = read(MAP)
    assert "Cycle 1455 note" in plan
    assert "DASHBOARD_VISUAL_KERNEL.md" in plan
    assert "v170.31 / dashboard visual kernel" in root_kernel
    assert "docs/NORM/DASHBOARD_VISUAL_KERNEL.md" in mapping
    assert "Cycle 1455" in mapping


def test_dashboard_visual_kernel_machine_report() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["direction"]["active"] is True
    assert data["direction"]["range"] == "1455-1495"
    assert data["direction"]["current_cycle"] == 1455
    assert data["direction"]["next_cycle"] == 1456
    assert data["reference_boundaries"]["grafana_runtime_code_copied"] is False
    assert data["reference_boundaries"]["sandbox_runtime_code_copied"] is False
    assert data["safety"]["economy_changed"] is False
    assert data["safety"]["tests_deleted_or_disabled"] is False


def test_operator_kernel_route_has_dashboard_visual_task() -> None:
    text = read(ROUTES)
    assert "dashboard_visual_direction:" in text
    assert "docs/NORM/DASHBOARD_VISUAL_KERNEL.md" in text
    assert "docs/NORM/DASHBOARD_VISUAL_PLAN.md" in text
    assert "backend/migrations/**/*" in text
    assert "frontend/package-lock.json" in text
