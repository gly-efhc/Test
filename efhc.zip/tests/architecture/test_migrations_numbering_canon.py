# SPDX-License-Identifier: MIT
"""Migrations numbering canon.

We enforce a simple ordered numbering scheme without importing Alembic.

- backend/migrations/versions/NNNN_description.py
- revision == "NNNN"
- down_revision chains NNNN -> previous NNNN.
"""

from __future__ import annotations

import re
from pathlib import Path

VERSIONS_DIR = (
    Path(__file__).resolve().parents[2]
    / "backend"
    / "migrations"
    / "versions"
)

NAME_RE = re.compile(r"^(\d{4})_.+\.py$")
REV_RE = re.compile(r"^revision\s*=\s*\"(\d{4})\"\s*$", re.M)
DOWN_RE = re.compile(
    r"^down_revision\s*=\s*(None|\"(\d{4})\")\s*$",
    re.M,
)


def test_versions_dir_exists() -> None:
    assert VERSIONS_DIR.exists()


def test_migration_filenames_match_canon() -> None:
    files = sorted([p.name for p in VERSIONS_DIR.glob("*.py")])
    assert files, "No migration files found."

    bad = [f for f in files if not NAME_RE.match(f)]
    assert not bad, "Bad migration names:\n" + "\n".join(bad)


def _extract_ids(text: str) -> tuple[str, str | None]:
    rev_m = REV_RE.search(text)
    assert rev_m, "Missing revision assignment."

    down_m = DOWN_RE.search(text)
    assert down_m, "Missing down_revision assignment."

    rev = rev_m.group(1)
    down = down_m.group(2)
    return rev, down


def test_revision_and_chain_match_filenames() -> None:
    paths = sorted([p for p in VERSIONS_DIR.glob("*.py")])

    prev = None
    for path in paths:
        m = NAME_RE.match(path.name)
        assert m
        num = m.group(1)

        text = path.read_text(encoding="utf-8")
        rev, down = _extract_ids(text)

        assert rev == num
        assert down == prev
        prev = num
