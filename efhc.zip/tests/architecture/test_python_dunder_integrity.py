from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BAD_PATTERNS = (
    re.compile(r"from\s+_future_\s+import"),
    re.compile(r"Path\(_file_\)"),
    re.compile(r"(?<!_)_name_(?!_)\s*=="),
    re.compile(r"logger\s*=\s*get_logger\(_name_\)"),
    re.compile(r"\b_main_\b"),
    re.compile(r"(?<!_)_all_(?!_)\s*="),
    re.compile(r"def\s+_init_(?!_)"),
    re.compile(r"def\s+_repr_(?!_)"),
    re.compile(r"def\s+_str_(?!_)"),
    re.compile(r"\._dict_(?!_)"),
    re.compile(r"(?<!_)_import_\("),
    re.compile(r"models_pkg\._path_(?!_)"),
    re.compile(r"(?<!_)_pycache_(?!_)"),
    re.compile(r"___file___"),
)


def iter_python_files():
    for root in ("backend", "ops", "tests", "api"):
        for path in (ROOT / root).rglob("*.py"):
            if "__pycache__" in path.parts:
                continue
            if path.name == "test_python_dunder_integrity.py":
                continue
            yield path


def test_python_dunder_tokens_are_not_degraded() -> None:
    offenders: list[str] = []
    for path in iter_python_files():
        text = path.read_text(encoding="utf-8", errors="ignore")
        text = text.replace("set_main_option", "SETMAINOPTION")
        text = text.replace("get_main_option", "GETMAINOPTION")
        text = text.replace("test_main_wallet", "TESTMAINWALLET")
        for pattern in BAD_PATTERNS:
            if pattern.search(text):
                offenders.append(
                    f"{path.relative_to(ROOT)}: {pattern.pattern}"
                )
    assert not offenders, (
        "Degraded Python dunder tokens found:\n" + "\n".join(offenders)
    )
