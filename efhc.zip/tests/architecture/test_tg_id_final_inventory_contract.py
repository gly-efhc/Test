"""Machine guard точного реестра tg_id цикла 1682."""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INVENTORY = ROOT / "reports/generated/tg_id_final_inventory.json"
TOKEN = re.compile(
    r"\b(?:tg_id|tg_provider_id|telegram_provider_id)\b"
)
EXTENSIONS = {
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".json",
    ".md",
    ".sql",
    ".yml",
    ".yaml",
}
SKIP_PARTS = {
    "node_modules",
    ".next",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}


def _current_count() -> int:
    total = 0
    for root_name in ("backend", "frontend", "tests", "contracts", "ops"):
        for path in (ROOT / root_name).rglob("*"):
            if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
                continue
            if SKIP_PARTS.intersection(path.parts):
                continue
            if path.name == "generate_tg_id_final_inventory.py":
                continue
            total += len(
                TOKEN.findall(
                    path.read_text(encoding="utf-8", errors="ignore")
                )
            )
    return total


def test_реестр_соответствует_exact_head() -> None:
    data = json.loads(INVENTORY.read_text(encoding="utf-8"))
    assert data["version"] == "v172.99"
    assert data["cycle"] == 1682
    assert data["total_token_occurrences"] == _current_count()
    assert len(data["items"]) == data["total_token_occurrences"]


def test_каждая_строка_матрицы_имеет_решение() -> None:
    data = json.loads(INVENTORY.read_text(encoding="utf-8"))
    required = {
        "file",
        "line",
        "column",
        "token",
        "symbol",
        "category",
        "status",
        "current_semantics",
        "target_semantics",
        "action",
    }
    for item in data["items"]:
        assert required <= item.keys()


def test_запрещённые_provider_names_отсутствуют_в_runtime() -> None:
    forbidden = re.compile(
        r"\b(?:tg_provider_id|telegram_provider_id)\b"
    )
    for root_name in ("backend/app", "frontend/src"):
        for path in (ROOT / root_name).rglob("*"):
            if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            assert not forbidden.search(text), path.relative_to(ROOT)
