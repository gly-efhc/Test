from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HEADER = ROOT / "frontend/src/components/GlobalHeader.tsx"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"
ENERGY = ROOT / "frontend/src/pages/index.tsx"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_global_header_owns_balance_boundary() -> None:
    text = _read(HEADER)
    assert 'data-balance-scope="global-header"' in text
    assert 'data-energy-balance-boundary="header-only"' in text
    assert "sumScaledDown(props.mainBalance, props.bonusBalance, 8)" in text
    assert 'aria-label={t("common.efhc_balance_aria")}' in text


def test_layout_passes_balances_only_to_header() -> None:
    text = _read(LAYOUT)
    assert "<GlobalHeader" in text
    assert 'mainBalance={props.snapshot?.profile?.main_balance || "0"}' in text
    assert 'bonusBalance={props.snapshot?.profile?.bonus_balance || "0"}' in text


def test_energy_page_does_not_duplicate_wallet_balances_or_exchange() -> None:
    page = _read(ENERGY)
    assert "LiveEnergyHeroAndProgress" in page
    assert "total_generated_hero" in page
    assert "EnergyMvpSummary" not in page
    assert "profile.main_balance" not in page
    assert "profile.bonus_balance" not in page
    assert 'href: "/exchange"' not in page
    assert "efhc-energy-stage_meter" in page
