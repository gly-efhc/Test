from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "docs/SSOT/faq_ssot/ru/faq_ru.json"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"
AI = ROOT / "docs/AI/AI_OPERATOR_RULES_EFHC.md"


def test_vip_replacements_present() -> None:
    data = json.loads(RU.read_text(encoding="utf-8"))
    sec = data["sections"][17]
    qs = {item["q"] for item in sec["items"]}
    assert "Как понять, что VIP уже учтён в аккаунте?" in qs
    assert (
        "Что делать, если EFHC VIP NFT есть, а статус VIP не появился?"
        in qs
    )
    assert (
        "Как связаны привязанные кошельки и автоматическая "
        "проверка VIP?"
    ) in qs
    assert (
        "Где проверять сам NFT, а где проверять уже активный "
        "статус VIP?"
    ) in qs
    assert (
        "Что произойдёт со статусом VIP, если NFT больше не "
        "находится в привязанном кошельке аккаунта?"
    ) in qs


def test_v5_wording_contains_deactivation_logic() -> None:
    text = RU.read_text(encoding="utf-8")
    assert "VIP-статус деактивируется для всех панелей" in text
    assert (
        "Наличие EFHC VIP NFT в кошельке для VIP-статуса обязательно."
        in text
    )


def test_cycle_109_and_minitz_rule_recorded() -> None:
    assert (
        "| 109 | done | RU VIP NFT approved rewrite wave 1."
        in WORK.read_text(encoding="utf-8")
    )
    assert (
        "Все будущие cycles in `docs/cycles/WORK_CYCLES_101-200.md`"
        not in AI.read_text(encoding="utf-8")
    )
    assert (
        "Все будущие cycles в серии `docs/cycles/"
        "WORK_CYCLES_0-100.md`, `101-200`, `201-300` и далее"
        in AI.read_text(encoding="utf-8")
    )
