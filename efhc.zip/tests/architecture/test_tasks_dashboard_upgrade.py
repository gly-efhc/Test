from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_tasks_dashboard_upgrade_docs_exist() -> None:
    required = [
        "docs/NORM/TASKS_DASHBOARD_UPGRADE.md",
        "docs/NORM/TASKS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1477_TASKS_DASHBOARD_UPGRADE.md",
        "reports/generated/tasks_dashboard_upgrade_v170_53.json",
        "reports/change_cycle_2026-06-07_v170_53_cycle_1477_tasks_dashboard_upgrade.md",
        "frontend/src/components/dashboard/TasksDashboardRuntime.tsx",
        "tests/architecture/test_tasks_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(read("reports/generated/tasks_dashboard_upgrade_v170_53.json"))
    assert data["cycle"] == 1477
    assert data["archive_version"] == "v170.53"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_tasks_route_changed"] is True
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["public_execution_history_visible"] is False
    assert data["backend_logs_visible_publicly"] is False
    assert data["idempotency_debug_visible_publicly"] is False
    assert data["fake_runtime_tasks_added"] is False
    assert data["grafana_runtime_code_copied"] is False


def test_tasks_dashboard_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/TasksDashboardRuntime.tsx")
    required = [
        "tasksDashboardRuntimeVersion",
        "EFHC_TASKS_DASHBOARD_RUNTIME_V1",
        "data-tasks-dashboard-runtime=\"1477\"",
        "data-tasks-dashboard-no-public-history=\"true\"",
        "data-tasks-dashboard-no-write-bypass=\"true\"",
        "data-tasks-dashboard-truth=\"raw-derived\"",
        "SimSegmentedProgress",
        "SimMiniBarChart",
        "SimActivityStrip",
        "task_status",
    ]
    for marker in required:
        assert marker in src


def test_tasks_dashboard_component_is_ui_only() -> None:
    src = read("frontend/src/components/dashboard/TasksDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "claimM",
        "watchAd(",
        "finishAd(",
        "/tasks/history",
        "/tasks/logs",
        "task_bonus_log",
        "task_complete_lock",
    ]
    for marker in forbidden:
        assert marker not in src


def test_tasks_dashboard_is_retained_as_legacy_but_replaced_on_page() -> None:
    page = read("frontend/src/pages/tasks.tsx")
    legacy = ROOT / "frontend/src/components/dashboard/TasksDashboardRuntime.tsx"
    assert legacy.exists()
    assert "TasksDashboardRuntime" not in page
    assert 'data-tasks-runtime="cycle-1557-react-query"' in page
    assert 'data-tasks-public-history="forbidden"' in page
    assert "useTasksCatalog" in page
    assert "useMyTasks" in page
    assert "/tasks/history" not in page
    assert "/tasks/logs" not in page


def test_public_tasks_execution_log_boundary_is_preserved() -> None:
    docs = read("docs/NORM/TASKS_DASHBOARD_UPGRADE.md") + read(
        "docs/NORM/ARCHITECTURAL_LOCKS.md"
    )
    assert "not a public execution log" in docs or "not a task\nhistory" in docs
    assert "idempotency/debug" in docs
    assert "new public `/tasks/history`" in docs
    assert "new public `/tasks/logs`" in docs


def test_locale_keys_exist_in_all_languages() -> None:
    required = [
        "tasks.dashboard_title",
        "tasks.dashboard_subtitle",
        "tasks.dashboard_fresh",
        "tasks.dashboard_source",
        "tasks.dashboard_raw_data",
        "tasks.dashboard_derived_display",
        "tasks.dashboard_total",
        "tasks.dashboard_ready",
        "tasks.dashboard_waiting",
        "tasks.dashboard_completed",
        "tasks.dashboard_available_reward",
        "tasks.dashboard_progress_title",
        "tasks.dashboard_reward_title",
        "tasks.dashboard_filter_label",
        "tasks.dashboard_no_history",
        "tasks.dashboard_action_boundary",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in required if key not in data]
        assert not missing, f"{path.name}: {missing}"


def test_tasks_dashboard_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1477 — Tasks Dashboard Upgrade",
        ".efhc-tasks-dashboard-runtime",
        ".efhc-tasks-dashboard-runtime__groups",
        ".efhc-tasks-dashboard-runtime__task.is-ready",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1477 — Tasks Dashboard Upgrade" in corpus
    assert "TASKS_DASHBOARD_UPGRADE" in corpus
    assert "1478 — Referrals Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/TASKS_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/TASKS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs
