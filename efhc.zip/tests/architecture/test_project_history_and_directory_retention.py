"""Fail-closed защита канонической истории и структуры каталогов EFHC."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from ops.reports.check_numbered_reports import check as check_reports

ROOT = Path(__file__).resolve().parents[2]
MANIFESTS = ROOT / "reports/manifests"
DIRECTORY_MANIFEST = ROOT / "ops/quality/protected_directories_manifest.json"
TRANSIENT_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "node_modules",
    ".next",
    "dist",
    "build",
    "coverage",
    ".coverage",
    ".sdd-cache",
}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _stable_directories() -> set[str]:
    out: set[str] = set()
    for path in ROOT.rglob("*"):
        if not path.is_dir():
            continue
        rel = path.relative_to(ROOT)
        if any(part in TRANSIENT_PARTS for part in rel.parts):
            continue
        out.add(rel.as_posix())
    return out


def test_циклы_сохраняются_ровно_в_канонических_диапазонах() -> None:
    cycle_dir = ROOT / "docs/cycles"
    expected = {
        f"WORK_CYCLES_{start:04d}-{start + 99:04d}.md"
        for start in range(1, 1800, 100)
    }
    actual = {path.name for path in cycle_dir.glob("*.md")}
    assert actual == expected

    rows = _csv(MANIFESTS / "CYCLE_ARCHIVE_MANIFEST.csv")
    assert len(rows) == 18
    manifest_paths = {row["archive_path"] for row in rows}
    expected_paths = {f"docs/cycles/{name}" for name in expected}
    assert manifest_paths == expected_paths
    for relative in manifest_paths:
        assert (ROOT / relative).is_file(), relative


def test_reports_нельзя_удалить_или_нарушить_нумерацию() -> None:
    result = check_reports()
    assert result["passed"], result["violations"]
    assert (ROOT / "reports/numbered").is_dir()
    assert (ROOT / "reports/current").is_dir()


def test_chats_перенесены_в_docs_и_защищены_hash_manifest() -> None:
    chat_dir = ROOT / "docs/chats"
    assert chat_dir.is_dir()
    assert not (ROOT / "АРТЕФАКТЫ").exists()
    rows = _csv(MANIFESTS / "CHAT_ARCHIVE_MANIFEST.csv")
    assert rows
    for row in rows:
        assert row["new_path"].startswith("docs/chats/")
        path = ROOT / row["new_path"]
        assert path.is_file(), row["new_path"]
        assert _sha(path) == row["sha256"], row["new_path"]
    for name in ("README.md", "CHAT_RECOVERY_REGISTRY.csv", "MISSING_TRANSCRIPTS.md"):
        assert (chat_dir / name).is_file(), name


def test_все_неартефактные_каталоги_зарегистрированы_и_не_удалены() -> None:
    data = json.loads(DIRECTORY_MANIFEST.read_text(encoding="utf-8"))
    registered = set(data["directories"])
    actual = _stable_directories()
    assert actual == registered, {
        "missing": sorted(registered - actual),
        "unregistered": sorted(actual - registered),
    }
    for rel in registered:
        assert (ROOT / rel).is_dir(), rel
