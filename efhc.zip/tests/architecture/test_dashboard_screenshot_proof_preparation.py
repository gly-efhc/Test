from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "reports/generated/dashboard_screenshot_proof_manifest_v170_30.json"
GREEN = ROOT / "reports/generated/green_ci_log_proof_v170_30.json"
DOC = ROOT / "docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md"
PLAN = ROOT / "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
MAP = ROOT / "map_element.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_screenshot_preparation_manifest_is_no_capture() -> None:
    data = load(MANIFEST)
    assert data["status"] == "SCREENSHOT_PREPARATION_READY_NO_CAPTURE"
    assert data["no_screenshot_claim"] is True
    assert data["new_archive_external_ci_green_claim"] is False
    assert data["dashboard_direction"]["range"] == "1455-1495"
    assert data["dashboard_direction"]["grafana_usage"] == (
        "visual-pattern reference only"
    )
    assert data["dashboard_direction"]["sandbox_usage"] == (
        "reference/navigation/prototype layer only"
    )


def test_screenshot_matrix_covers_routes_locales_and_viewports() -> None:
    data = load(MANIFEST)
    assert len(data["viewports"]) == 10
    assert len(data["locales"]) == 13
    public_routes = {item["route"] for item in data["public_routes"]}
    admin_routes = {item["route"] for item in data["admin_routes"]}
    assert {"/", "/panels", "/exchange", "/hub", "/withdraw"} <= public_routes
    assert {
        "/admin",
        "/admin/reports",
        "/admin/bank",
        "/admin/withdrawals",
        "/admin/system",
    } <= admin_routes


def test_green_ci_logs_are_recorded_without_new_archive_claim() -> None:
    data = load(GREEN)
    assert data["status"] == "GREEN_LOGS_RECORDED"
    assert data["logs_zip"] == "logs_72687610241.zip"
    assert data["new_archive_external_ci_green_claim"] is False
    assert data["gates"]["frontend_build"] == "passed"
    assert data["gates"]["ruff"] == "passed"
    assert "1306 passed" in data["gates"]["pytest"]
    assert data["gates"]["gate_summary"] == "OK: all gate steps passed."


def test_preparation_doc_forbids_fake_screenshot_claims() -> None:
    text = read(DOC)
    assert "SCREENSHOT_PREPARATION_READY_NO_CAPTURE" in text
    assert "Forbidden claim now" in text
    assert "browser screenshot proof complete" in text
    assert "Only real browser captures may create `.png` evidence" in text
    forbidden = [
        "Status: SCREENSHOT PROOF COMPLETE",
        "Status: RELEASE READY",
        "Status: LIVE TELEGRAM PROOF",
    ]
    for claim in forbidden:
        assert claim not in text


def test_dashboard_plan_and_map_point_to_screenshot_prep() -> None:
    plan = read(PLAN)
    mapping = read(MAP)
    assert "DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md" in plan
    assert "SCREENSHOT_PREPARATION_READY_NO_CAPTURE" in plan
    assert "Cycle 1454" in mapping
    assert "dashboard_screenshot_proof_manifest_v170_30.json" in mapping
    assert "Grafana" in mapping
