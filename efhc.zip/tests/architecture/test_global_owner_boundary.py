"""Постоянная граница владельца business-объектов."""

from __future__ import annotations

from pathlib import Path

from ops.identity.check_global_id_canon import (
    проверить as проверить_канон,
)

ROOT = Path(__file__).resolve().parents[2]


def test_business_owner_tg_id_равен_нулю() -> None:
    result = проверить_канон(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["business_owner_tg_id"] == 0


def test_критические_business_services_используют_global_id() -> None:
    required = {
        "backend/app/services/transactions_service.py": (
            "global_id",
            "resolve_and_lock_financial_write_owner",
        ),
        "backend/app/services/panels_service.py": ("global_id",),
        "backend/app/services/withdraw_service.py": ("global_id",),
        "backend/app/services/payment_intents_service.py": ("global_id",),
        "backend/app/services/referral_service.py": ("global_id",),
        "backend/app/services/tasks_service.py": ("global_id",),
        "backend/app/services/ranks_service.py": ("global_id",),
        "backend/app/services/wallets_service.py": ("global_id",),
    }
    missing: list[str] = []
    for relative, markers in required.items():
        text = (ROOT / relative).read_text(encoding="utf-8")
        for marker in markers:
            if marker not in text:
                missing.append(f"{relative}:{marker}")
    assert not missing, missing


def test_active_identity_alias_modules_отсутствуют() -> None:
    for relative in (
        "backend/app/identity/legacy_alias.py",
        "backend/app/identity/legacy_user_id.py",
        "backend/app/identity/user_id_backfill.py",
        "backend/app/identity/user_id_expand.py",
    ):
        assert not (ROOT / relative).exists(), relative
