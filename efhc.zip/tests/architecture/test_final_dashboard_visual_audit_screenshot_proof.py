from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALES = ROOT / "frontend" / "public" / "locale"
EXPECTED_LOCALES = {
    "da",
    "de",
    "en",
    "es",
    "fr",
    "hi",
    "id",
    "it",
    "pl",
    "ru",
    "sw",
    "tr",
    "uk",
}
DASHBOARD_PREFIXES = (
    "energy.dashboard_",
    "exchange.dashboard_",
    "profile.dashboard_",
    "ranks.dashboard_",
    "referrals.dashboard_",
    "tasks.dashboard_",
)
FORBIDDEN_PLACEHOLDER_PREFIXES = (
    "Локализовано:",
    "Локалізовано:",
    "Lokaliseret:",
    "Lokalisiert:",
    "Localizado:",
    "Localisé",
    "स्थानीय:",
    "Lokal:",
    "Localizzato:",
    "Lokalnie:",
    "Eneo:",
    "Yerel:",
)


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def load_locale(name: str) -> dict[str, str]:
    return json.loads((LOCALES / f"{name}.json").read_text())


def dashboard_keys(data: dict[str, str]) -> set[str]:
    return {
        key
        for key in data
        if key.startswith(DASHBOARD_PREFIXES)
    }


def test_cycle_1495_docs_and_reports_exist() -> None:
    paths = [
        "docs/NORM/FINAL_DASHBOARD_VISUAL_AUDIT_SCREENSHOT_PROOF.md",
        "docs/NORM/FINAL_DASHBOARD_VISUAL_AUDIT_GRAFANA_ELEMENT_ANALYSIS.md",
        (
            "docs/cycles/WORK_CYCLES_1495_FINAL_DASHBOARD_VISUAL_"
            "AUDIT_SCREENSHOT_PROOF.md"
        ),
        (
            "reports/generated/final_dashboard_visual_audit_"
            "screenshot_proof_v170_71.json"
        ),
        (
            "reports/change_cycle_2026-06-10_v170_71_cycle_1495_"
            "final_dashboard_visual_audit_screenshot_proof.md"
        ),
    ]
    missing = [path for path in paths if not (ROOT / path).exists()]
    assert missing == []


def test_public_dashboard_locale_files_are_thirteen_with_key_parity() -> None:
    actual = {path.stem for path in LOCALES.glob("*.json")}
    assert actual == EXPECTED_LOCALES
    en_keys = set(load_locale("en"))
    en_dashboard_keys = dashboard_keys(load_locale("en"))
    assert en_dashboard_keys
    for locale in EXPECTED_LOCALES:
        data = load_locale(locale)
        assert set(data) == en_keys
        assert dashboard_keys(data) == en_dashboard_keys


def test_dashboard_locale_values_have_no_placeholder_prefixes() -> None:
    offenders: list[str] = []
    for locale in EXPECTED_LOCALES:
        data = load_locale(locale)
        for key, value in data.items():
            if not key.startswith(DASHBOARD_PREFIXES):
                continue
            if not isinstance(value, str):
                continue
            if value.strip() == "":
                offenders.append(f"{locale}:{key}:empty")
                continue
            if any(value.startswith(p) for p in FORBIDDEN_PLACEHOLDER_PREFIXES):
                offenders.append(f"{locale}:{key}:{value}")
    assert offenders == []


def test_public_runtime_dashboards_use_label_props_not_inline_ru() -> None:
    runtime_files = [
        "frontend/src/components/dashboard/EnergyDashboardRuntime.tsx",
        "frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx",
        "frontend/src/components/dashboard/RanksDashboardRuntime.tsx",
        "frontend/src/components/dashboard/TasksDashboardRuntime.tsx",
        "frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx",
        "frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx",
        "frontend/src/components/dashboard/WebProfileAccountDashboard.tsx",
    ]
    for path in runtime_files:
        text = read(path)
        assert "labels" in text
        assert "Локализовано:" not in text


def test_admin_dashboard_locale_claim_is_russian_operator_canon() -> None:
    doc = read("docs/NORM/FINAL_DASHBOARD_VISUAL_AUDIT_SCREENSHOT_PROOF.md")
    assert "Public / TMA dashboard layer" in doc
    assert "PASS for 13 active locale files" in doc
    assert "Admin dashboard layer" in doc
    assert "Russian operator surface" in doc


def test_screenshot_matrix_is_static_and_does_not_fake_capture() -> None:
    report = json.loads(
        read(
            "reports/generated/final_dashboard_visual_audit_"
            "screenshot_proof_v170_71.json"
        )
    )
    assert report["browser_screenshot_capture_claimed"] is False
    assert report["static_screenshot_matrix_prepared"] is True
    evidence_root = ROOT / "reports/evidence/screenshots/dashboard_1495"
    assert not list(evidence_root.glob("*.png"))


def test_log_repair_guard_markers_are_present() -> None:
    route = read("backend/app/routes/admin_observability_routes.py")
    assert "_trusted_static_sql" in route
    assert "# nosec B608" in route
    assert "row: Mapping[str, Any]" in route
    admin_home = read("frontend/src/pages/admin/index.tsx")
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in admin_home
    assert "AdminInteractiveBankDashboard" not in admin_home
    route_guard = read("tests/architecture/test_admin_route_modules_canon.py")
    assert "admin_observability_routes.py" in route_guard
    openapi_guard = read("tests/architecture/test_openapi_rebuild_strict_contract_gate.py")
    assert "assert len(rows) == 136" in openapi_guard
