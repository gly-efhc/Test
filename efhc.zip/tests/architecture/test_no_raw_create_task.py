from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ALLOWED = {
    ROOT / "backend/app/core/async_tasks.py",
}


def test_no_raw_asyncio_create_task_outside_helper() -> None:
    bad: list[str] = []
    for path in (ROOT / "backend").rglob("*.py"):
        if path in ALLOWED:
            continue
        text = path.read_text(encoding="utf-8")
        if "asyncio.create_task(" in text:
            rel = path.relative_to(ROOT).as_posix()
            bad.append(rel)
    assert not bad, (
        "Use create_logged_task() instead of raw "
        f"asyncio.create_task(): {bad}"
    )
