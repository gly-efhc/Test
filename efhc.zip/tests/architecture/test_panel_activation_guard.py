from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_panel_activation_guard_1190() -> None:
    script = ROOT / "ops/routes/check_panel_activation.py"
    result = subprocess.run(
        [sys.executable, str(script)],
        cwd=ROOT,
        check=False,
        text=True,
        capture_output=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(
        (ROOT / "reports/generated/panel_activation.json").read_text(
            encoding="utf-8"
        )
    )
    assert data["all_required_present"] is True
