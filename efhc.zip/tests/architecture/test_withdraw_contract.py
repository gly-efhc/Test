from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_проверка_public_withdraw_uses_react_query_for_all_server_state() -> None:
    page = read("frontend/src/pages/withdraw.tsx")
    hooks = read("frontend/src/queries/useWithdrawals.ts")
    service = read("frontend/src/services/withdrawals.service.ts")
    assert 'data-withdraw-runtime="react-query-create-cancel-history"' in page
    assert "useWithdrawalsPage" in page
    assert "useWithdrawDetail" in page
    assert "useWalletBalanceHistory" in page
    assert "useWithdrawOutcome" in page
    assert "useCreateWithdrawRequest" in page
    assert "useCancelWithdrawRequest" in page
    assert "useInfiniteQuery" in hooks
    assert "invalidateWithdrawQueries" in hooks
    assert "queryKeys.snapshot.current" in hooks
    assert "queryKeys.profile.withdrawHistory" in hooks
    assert "parseWithdrawPageResponse" in service
    assert "parseWithdrawDetail" in service
    assert "parseWithdrawOutcomeBundle" in service
    assert "setItems(" not in page
    assert "getWithdrawalsPage(" not in page
    assert "apiRequest" not in page


def test_проверка_withdraw_create_cancel_and_primary_balance_contract_are_visible() -> None:
    page = read("frontend/src/pages/withdraw.tsx")
    assert 'data-withdraw-amount-input="efhcm-main-only"' in page
    assert 'data-withdraw-action="create"' in page
    assert 'data-withdraw-action="cancel"' in page
    assert 'data-withdraw-action="cancel-detail"' in page
    assert 'cmp8(normalized, "10.00000000") >= 0' in page
    assert "props.snap?.profile?.main_balance" in page
    assert "bonus_balance" not in page
    assert "walletConnected" in page
    assert "newIdempotencyKey()" in page


def test_проверка_admin_withdraw_operator_contour_keeps_decision_actions() -> None:
    page = read("frontend/src/pages/admin/withdrawals.tsx")
    assert "AdminWithdrawalsDashboardRuntime" in page
    assert "AdminWithdrawalsMobileDecisionPanel" in page
    assert "repair-consistency" in page
    assert "buildEfhcWithdrawTonConnectTx" in page
    assert "useWalletProvider" in page
    assert "sendTransaction(tx)" in page
    assert "tonConnectUI.sendTransaction" not in page
    assert "/approve" in page
    assert "/reject" in page
    assert "wallet_send_confirmed" in page
