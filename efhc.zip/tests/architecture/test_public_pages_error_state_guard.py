from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

PUBLIC_PAGES = [
    "frontend/src/pages/ranks.tsx",
    "frontend/src/pages/referrals.tsx",
    "frontend/src/pages/withdraw.tsx",
    "frontend/src/pages/exchange.tsx",
    "frontend/src/pages/tasks.tsx",
]

REQUIRED_COMMON_ERROR_KEYS = [
    "common.session_expired",
    "common.load_error",
]


def test_public_pages_use_localized_401_403_error_helper() -> None:
    helper = (ROOT / "frontend/src/lib/publicError.ts").read_text(
        encoding="utf-8"
    )
    assert "common.session_expired" in helper
    assert "common.load_error" in helper
    assert "401" in helper and "403" in helper
    for rel in PUBLIC_PAGES:
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert "publicApiErrorMessage" in text, rel


def test_common_error_keys_present_in_all_locales() -> None:
    base = ROOT / "frontend/public/locale"
    locale_files = sorted(base.glob("*.json"))
    assert len(locale_files) == 13
    for locale_file in locale_files:
        data = json.loads(locale_file.read_text(encoding="utf-8"))
        for key in REQUIRED_COMMON_ERROR_KEYS:
            assert (
                key in data
            ), f"Missing key {key!r} in {locale_file.name}"
            assert str(
                data[key]
            ).strip(), f"Empty key {key!r} in {locale_file.name}"
