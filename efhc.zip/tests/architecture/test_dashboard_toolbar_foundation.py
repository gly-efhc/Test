from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/DASHBOARD_TOOLBAR_FOUNDATION.md"
TSX = ROOT / "frontend/src/components/dashboard/DashboardToolbar.tsx"
ADMIN = ROOT / "frontend/src/components/admin/AdminDashboardUiKit.tsx"
SIM = ROOT / "frontend/src/components/dashboard/SimulationDashboardUiKit.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
MAP = ROOT / "map_element.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
REPORT = ROOT / "reports/generated/dashboard_toolbar_foundation_v170_41.json"
KERNEL = ROOT / "KERNEL.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_dashboard_toolbar_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_DASHBOARD_TOOLBAR_FOUNDATION" in text
    assert "DashboardTimeRangePicker" in text
    assert "DashboardRefreshPicker" in text
    assert "DashboardFreshnessBadge" in text
    assert "No Grafana source code is copied" in text


def test_dashboard_toolbar_runtime_components_exist() -> None:
    text = read(TSX)
    required = [
        "export function DashboardToolbar",
        "export function DashboardTimeRangePicker",
        "export function DashboardRefreshPicker",
        "export function DashboardFreshnessBadge",
        "EFHC_DASHBOARD_TOOLBAR_V1",
        "data-dashboard-toolbar=\"1465\"",
        "data-dashboard-time-range-picker=\"1465\"",
        "data-dashboard-refresh-picker=\"1465\"",
        "data-dashboard-freshness-badge=\"1465\"",
    ]
    for marker in required:
        assert marker in text
    forbidden = ["@grafana/", "SceneObject", "TimeRangePickerProps"]
    for marker in forbidden:
        assert marker not in text


def test_admin_and_simulation_kits_expose_toolbar_wrappers() -> None:
    admin = read(ADMIN)
    sim = read(SIM)
    for marker in [
        "AdminTimeRangePicker",
        "AdminRefreshPicker",
        "AdminFreshnessBadge",
        "EFHC_ADMIN_DASHBOARD_TOOLBAR_V1",
    ]:
        assert marker in admin
    for marker in [
        "SimDashboardToolbar",
        "SimPeriodSwitch",
        "SimFreshnessBadge",
        "EFHC_SIM_DASHBOARD_TOOLBAR_V1",
    ]:
        assert marker in sim


def test_dashboard_toolbar_css_uses_dashboard_tokens() -> None:
    css = read(CSS)
    required = [
        "Dashboard Toolbar Foundation",
        ".efhc-dashboard-toolbar",
        ".efhc-dashboard-toolbar-picker",
        ".efhc-dashboard-toolbar-refresh",
        ".efhc-dashboard-freshness-badge",
        "var(--efhc-dash-panel)",
        "var(--efhc-dash-border)",
    ]
    for marker in required:
        assert marker in css


def test_grafana_toolbar_map_is_reference_only() -> None:
    for path in [MAP, GRAFANA_MAP]:
        text = read(path)
        for marker in [
            "DashboardControls.tsx",
            "TimeRangePicker.tsx",
            "RelativeTimeRangePicker",
            "RefreshPicker.tsx",
            "PageToolbar.tsx",
            "ToolbarButton.tsx",
        ]:
            assert marker in text
        assert "No Grafana source code is copied" in text


def test_dashboard_toolbar_report_and_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1465
    assert data["version"] == "v170.41"
    assert data["boundaries"]["economy_changed"] is False
    assert data["boundaries"]["backend_contracts_changed"] is False
    assert data["boundaries"]["db_migrations_changed"] is False
    assert data["boundaries"]["new_dependencies_added"] is False
    assert data["boundaries"]["grafana_runtime_code_copied"] is False
    assert data["boundaries"]["sandbox_runtime_code_copied"] is False


def test_navigation_points_to_dashboard_toolbar_foundation() -> None:
    for path in [KERNEL, MAP, ROUTES]:
        text = read(path)
        assert "DASHBOARD_TOOLBAR_FOUNDATION" in text
        assert "DashboardToolbar.tsx" in text
        assert "test_dashboard_toolbar_foundation.py" in text


def test_grafana_archive_contains_toolbar_reference_files() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "PageToolbar.tsx",
        "ToolbarButton.tsx",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker
