from decimal import Decimal

from app.services.watcher_transport import (
    classify_watcher_transport,
    validate_payment_intent_transport,
)


def test_classify_native_ton_mode() -> None:
    dec = classify_watcher_transport(
        asset="TON",
        amount=Decimal("1.50000000"),
        amount_asset=0,
        jetton_master="",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
    )
    assert dec.transport_kind == "native_ton"
    assert dec.confirm_asset == "TON"
    assert str(dec.amount_asset_d8) == "1.50000000"


def test_classify_usdt_jetton_mode() -> None:
    dec = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=1234567,
        jetton_master="EQUSDT",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
    )
    assert dec.transport_kind == "jetton_transfer"
    assert dec.confirm_asset == "USDT"
    assert str(dec.amount_asset_d8) == "1.23456700"


def test_classify_efhc_jetton_mode() -> None:
    dec = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=123456789,
        jetton_master="EQEFHC",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
        efhc_decimals=8,
    )
    assert dec.transport_kind == "efhc_jetton"
    assert dec.confirm_asset == "EFHCJ"
    assert str(dec.amount_asset_d8) == "1.23456789"


def test_validate_payment_intent_transport_rejects_efhc_jetton() -> (
    None
):
    dec = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=100000000,
        jetton_master="EQEFHC",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
    )
    check = validate_payment_intent_transport(dec)
    assert check.ok is False
    assert check.reason == "EFHC_JETTON_NOT_ALLOWED_FOR_PAYMENT_INTENT"


def test_validate_payment_intent_transport_rejects_unknown_jetton() -> (
    None
):
    dec = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=1000000,
        jetton_master="EQOTHER",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
    )
    assert dec.transport_kind == "unknown_jetton"
    check = validate_payment_intent_transport(dec)
    assert check.ok is False
    assert check.reason == "UNKNOWN_JETTON_MASTER"


def test_validate_payment_intent_transport_allows_ton_and_usdt() -> (
    None
):
    ton = classify_watcher_transport(
        asset="TON",
        amount=Decimal("0.50000000"),
        amount_asset=0,
        jetton_master="",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
    )
    usdt = classify_watcher_transport(
        asset="JETTON",
        amount=0,
        amount_asset=2000000,
        jetton_master="EQUSDT",
        efhc_master="EQEFHC",
        usdt_master="EQUSDT",
    )
    assert validate_payment_intent_transport(ton).ok is True
    assert validate_payment_intent_transport(usdt).ok is True
