# tests/architecture/test_great_canon_guard.py
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


IGNORED_DIR_PARTS = {
    "__pycache__",
    "alembic",
    "migrations",
    ".venv",
    "venv",
    ".git",
    ".idea",
    ".pytest_cache",
}


@dataclass(frozen=True)
class CanonViolation:
    file_path: str
    line: int
    message: str


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _iter_target_py_files(repo_root: Path) -> Iterable[Path]:
    roots = [
        repo_root / "backend" / "app",
        repo_root / "ops",
    ]
    for base in roots:
        if not base.exists():
            continue
        for p in base.rglob("*.py"):
            if set(p.parts) & IGNORED_DIR_PARTS:
                continue
            yield p


def _is_own_guard_file(path: Path) -> bool:
    rel = path.as_posix()
    return rel.endswith(
        "tests/architecture/test_great_canon_guard.py"
    ) or rel.endswith(
        "tests/architecture/test_financial_integrity.py"
    )


def _compile_banned_patterns() -> list[tuple[re.Pattern[str], str]]:
    banned_identifiers = [
        "u" + "_" + "id",
        "user" + "_" + "id",
        "telegram" + "_" + "id",
        "user" + "Id",
        "telegram" + "Id",
    ]

    banned_lot_terms = [
        "lot" + "tery",
        "raf" + "fle",
        "dr" + "aw",
        "dr" + "aws",
    ]

    patterns: list[tuple[re.Pattern[str], str]] = []

    for tok in banned_identifiers:
        pat = re.compile(
            rf"(?<![A-Za-z0-9_]){re.escape(tok)}(?![A-Za-z0-9_])"
        )
        msg = (
            "Запрещённый идентификатор: "
            f"{tok}. Канон: tg_id."
        )
        patterns.append((pat, msg))

    for tok in banned_lot_terms:
        pat = re.compile(
            rf"(?<![A-Za-z0-9_]){re.escape(tok)}(?![A-Za-z0-9_])"
        )
        msg = (
            "Запрещённый термин раздела lotteries: "
            f"{tok}. Канон: lotteries."
        )
        patterns.append((pat, msg))

    patterns.append(
        (re.compile(r"(?i)\bTODO\b"), "Запрещено оставлять TODO.")
    )
    patterns.append(
        (re.compile(r"(?i)\bFIXME\b"), "Запрещено оставлять FIXME.")
    )

    return patterns


def _check_file_text(
    path: Path,
    patterns: list[tuple[re.Pattern[str], str]],
) -> list[CanonViolation]:
    text = path.read_text(encoding="utf-8", errors="replace")
    violations: list[CanonViolation] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        for pat, msg in patterns:
            if pat.search(line):
                violations.append(
                    CanonViolation(
                        file_path=path.as_posix(),
                        line=line_no,
                        message=msg,
                    )
                )
    return violations


def test_great_canon_guard() -> None:
    """
    The Great Canon Guard — единый архитектурно-лексический щит.

    Проверяет (backend/app + ops):
    - запрет legacy идентификаторов → канон tg_id;
    - запрет legacy терминов lotteries;
    - запрет TODO/FIXME;
    - игнор alembic/migrations.
    """
    root = _repo_root()

    # FULL-ARTIFACT GUARD (SSOT):
    # Артефакт efhc.zip обязан содержать SSOT-документы и реестр ошибок.
    required_paths = [
        root / "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
        root / "docs" / "SSOT_INDEX.md",
        root / "docs" / "TESTS_CATALOG.md",
        root / "ops" / "canon_rules.yaml",
        root / "backend" / "alembic.ini",
    ]
    missing = [str(rp.relative_to(root)) for rp in required_paths if not rp.exists()]
    if missing:
        raise AssertionError("FULL-ARTIFACT REQUIRED: missing " + ", ".join(missing))
    patterns = _compile_banned_patterns()

    violations: list[CanonViolation] = []
    for py_file in _iter_target_py_files(root):
        if _is_own_guard_file(py_file):
            continue
        violations.extend(_check_file_text(py_file, patterns))

    if violations:
        head = violations[:50]
        lines: list[str] = []
        for v in head:
            prefix = f"{v.file_path}:{v.line}: "
            lines.append(
                prefix + "CRITICAL CANON VIOLATION: " + v.message
            )
        if len(violations) > 50:
            tail = len(violations) - 50
            lines.append(f"... и ещё {tail} нарушений.")
        raise AssertionError("\n".join(lines))
