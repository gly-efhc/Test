# tests/architecture/test_great_canon_guard.py
from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

TELEGRAM_ALIAS_ALLOWLIST = {
    "backend/app/identity/compatibility_registry.py",
    "backend/app/identity/legacy_alias.py",
    "backend/app/models/user_models.py",
    "ops/identity/check_identity_compatibility_registry.py",
    "ops/identity/check_global_id_canon.py",
    "ops/identity/check_cross_language_identity_separation.py",
}


IGNORED_DIR_PARTS = {
    "__pycache__",
    "alembic",
    "migrations",
    ".venv",
    "venv",
    ".git",
    ".idea",
    ".pytest_cache",
}


@dataclass(frozen=True)
class CanonViolation:
    file_path: str
    line: int
    message: str


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _iter_target_py_files(repo_root: Path) -> Iterable[Path]:
    roots = [
        repo_root / "backend" / "app",
        repo_root / "ops",
    ]
    for base in roots:
        if not base.exists():
            continue
        for p in base.rglob("*.py"):
            if set(p.parts) & IGNORED_DIR_PARTS:
                continue
            yield p


def _is_own_guard_file(path: Path) -> bool:
    rel = path.as_posix()
    return rel.endswith(
        "tests/architecture/test_great_canon_guard.py"
    ) or rel.endswith("tests/architecture/test_financial_integrity.py")


def _compile_banned_patterns() -> list[tuple[re.Pattern[str], str]]:
    banned_identifiers = [
        "u" + "_" + "id",
        "telegram" + "_" + "id",
        "user" + "Id",
        "telegram" + "Id",
    ]

    banned_removed_domain_terms = [
        "lot" + "tery",
        "raf" + "fle",
        "dr" + "aw",
        "dr" + "aws",
    ]

    patterns: list[tuple[re.Pattern[str], str]] = []

    for tok in banned_identifiers:
        pat = re.compile(
            rf"(?<![A-Za-z0-9_]){re.escape(tok)}(?![A-Za-z0-9_])"
        )
        msg = (
            "Запрещённый идентификатор: "
            f"{tok}. Канон: global_id, id или tg_id по семантике."
        )
        patterns.append((pat, msg))

    for tok in banned_removed_domain_terms:
        pat = re.compile(
            rf"(?<![A-Za-z0-9_]){re.escape(tok)}(?![A-Za-z0-9_])"
        )
        msg = "Запрещённый legacy-термин удалённого домена: " f"{tok}."
        patterns.append((pat, msg))

    patterns.append(
        (re.compile(r"(?i)\bTODO\b"), "Запрещено оставлять TODO.")
    )
    patterns.append(
        (re.compile(r"(?i)\bFIXME\b"), "Запрещено оставлять FIXME.")
    )

    return patterns


def _check__file__text(
    path: Path,
    patterns: list[tuple[re.Pattern[str], str]],
) -> list[CanonViolation]:
    text = path.read_text(encoding="utf-8", errors="replace")
    violations: list[CanonViolation] = []
    root = _repo_root()
    try:
        relative = path.relative_to(root).as_posix()
    except ValueError:
        relative = path.as_posix()
    for line_no, line in enumerate(text.splitlines(), start=1):
        for pat, msg in patterns:
            if pat.search(line):
                telegram_alias = (
                    "telegram_id" in msg or "telegramId" in msg
                )
                if (
                    telegram_alias
                    and relative in TELEGRAM_ALIAS_ALLOWLIST
                ):
                    continue
                violations.append(
                    CanonViolation(
                        file_path=path.as_posix(),
                        line=line_no,
                        message=msg,
                    )
                )
    return violations


def test_great_canon_guard() -> None:
    """
    The Great Canon Guard — единый архитектурно-лексический щит.

    Проверяет (backend/app + ops):
    - запрет legacy имён при каноне global_id/id/tg_id;
    - telegram_id разрешён только как зарегистрированный ORM alias;
    - запрет legacy-терминов удалённого домена;
    - запрет TODO/FIXME;
    - игнор alembic/migrations.
    """
    root = _repo_root()

    # FULL-ARTIFACT GUARD (SSOT):
    # Артефакт efhc.zip обязан содержать SSOT-документы и реестр ошибок.
    required_paths = [
        root / "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
        root / "docs" / "SSOT" / "SSOT_INDEX.md",
        root / "docs" / "NORM" / "TESTS_CATALOG.md",
        root / "ops" / "canon_rules.yaml",
        root / "backend" / "alembic.ini",
    ]
    missing = [
        str(rp.relative_to(root))
        for rp in required_paths
        if not rp.exists()
    ]
    if missing:
        raise AssertionError(
            "FULL-ARTIFACT REQUIRED: missing " + ", ".join(missing)
        )
    patterns = _compile_banned_patterns()

    violations: list[CanonViolation] = []
    for py_file in _iter_target_py_files(root):
        if _is_own_guard_file(py_file):
            continue
        violations.extend(_check__file__text(py_file, patterns))

    if violations:
        head = violations[:50]
        lines: list[str] = []
        for v in head:
            prefix = f"{v.file_path}:{v.line}: "
            lines.append(
                prefix + "CRITICAL CANON VIOLATION: " + v.message
            )
        if len(violations) > 50:
            tail = len(violations) - 50
            lines.append(f"... и ещё {tail} нарушений.")
        raise AssertionError("\n".join(lines))
