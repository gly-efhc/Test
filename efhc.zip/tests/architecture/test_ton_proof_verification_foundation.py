"""Architecture contracts TON Proof цикла 1616."""

from __future__ import annotations

import json
from pathlib import Path

from ops.identity.check_ton_proof_verification import проверить
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def test_ton_proof_static_guard_проходит_без_импорта_приложения() -> None:
    result = проверить(ROOT)
    assert result["статус"] == "PASS", result["нарушения"]
    assert result["проверка_без_импорта_приложения"] is True


def test_ton_proof_contract_закрыт_при_ошибке_и_provider_neutral() -> None:
    contract = json.loads(
        (
            ROOT
            / "contracts/identity/ton_proof_verification_contract_v1.json"
        ).read_text(encoding="utf-8")
    )
    assert contract["provider"] == "ton"
    assert contract["проверки"]["ed25519_signature"] is True
    assert contract["проверки"]["replay"] == (
        "atomic_postgresql_consume_exact_challenge_id"
    )
    assert all(
        value is False
        for value in contract["побочные_эффекты"].values()
    )
    assert contract["alembic_head"] == "0001"
    assert contract["migration_0005"] is False


def test_имеет_точный_маршрут_operator_kernel() -> None:
    classified = classify_task(
        "Цикл 1616 TON Proof domain timestamp network state-init replay TTL"
    )
    assert classified["task_type"] == "ton_proof_verification"
    route = resolve_route("ton_proof_verification", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "ton_proof_verification"


def test_похожие_ton_vectors_объединены_без_потери_scope() -> None:
    unit = (
        ROOT
        / "tests/efhc_backend/identity/test_ton_proof_verification.py"
    ).read_text(encoding="utf-8")
    integration = (
        ROOT / "tests/integration/test_ton_proof_postgresql.py"
    ).read_text(encoding="utf-8")
    assert unit.count("@pytest.mark.parametrize") >= 4
    for marker in (
        "DOMAIN_MISMATCH",
        "TIMESTAMP_EXPIRED",
        "NETWORK_MISMATCH",
        "SIGNATURE_INVALID",
        "STATE_INIT_INVALID",
        "CHALLENGE_NOT_CONSUMABLE",
    ):
        assert marker in unit
    assert '@pytest.mark.parametrize("case",' in integration
    assert "asyncio.gather" in integration
