from pathlib import Path

from ops.operator_kernel.archive_hygiene import check_tree


def test_operator_kernel_archive_hygiene_required_anchors():
    result = check_tree(Path.cwd())
    assert "docs/SSOT" not in result["missing"]
    assert "HEALER_ATLAS.md" not in result["missing"]
    assert result["scope"] == "LOCAL_AUX_CHECK_ONLY"


def test_operator_kernel_configs_exist():
    base = Path("ops/operator_kernel/config")
    assert (base / "routes.yaml").exists()
    assert (base / "heavy_paths.yaml").exists()
    assert (base / "tool_registry.yaml").exists()
    assert (base / "invariants.yaml").exists()


def test_operator_kernel_archive_hygiene_rejects_runtime_logs(tmp_path):
    (tmp_path / "docs" / "SSOT").mkdir(parents=True)
    (tmp_path / "reports").mkdir()
    (tmp_path / "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md").write_text("x")
    (tmp_path / "HEALER_ATLAS.md").write_text("x")
    (tmp_path / ".local_artifacts" / "logs").mkdir(parents=True)
    (tmp_path / ".local_artifacts" / "logs" / "app.log").write_text("x")
    result = check_tree(tmp_path)
    assert not result["ok"]
    assert ".local_artifacts" in result["junk"]
    assert ".local_artifacts/logs/app.log" in result["junk"]
