from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1338_docs_exist() -> None:
    assert (
        ROOT / "docs/audits/CI_LOGS_71459043999_REPAIR_V169_17.md"
    ).exists()
    assert (
        ROOT / "docs/backend/CI_LOGS_71459043999_REPAIR_CANON.md"
    ).exists()
    assert (
        ROOT
        / "reports/change_cycle_2026-05-29_v169_17_cycle_1338_ci_logs_71459043999_repair.md"
    ).exists()


def test_ci__file__is_manual_control_and_not_claimed_changed() -> None:
    audit = read("docs/audits/CI_LOGS_71459043999_REPAIR_V169_17.md")
    assert "`ci.yml` was not edited" in audit
    assert "GitHub CI remains user-run" in audit


def test_stale_cycle_1262_guard_now_matches_active_frontend_canon() -> (
    None
):
    text = read("tests/architecture/test_docker_known_good_guard.py")
    assert "16.2.6" in text
    assert "19.2.6" in text
    assert "4.3.0" in text
    assert "^14.2.35" not in text


def test_no_frontend_tsbuildinfo_artifact() -> None:
    assert not (ROOT / "frontend/tsconfig.tsbuildinfo").exists()


def test_operator_kernel_cache_skips_historical__name__sources() -> (
    None
):
    text = read("ops/operator_kernel/file_map.py")
    assert "ORIGINAL_SOURCES" in text
    assert "CHAT_BRANCHES" in text
    assert "CHATS" in text

    data = json.loads(read("ops/operator_kernel/cache/file_map.json"))
    paths = [entry["path"] for entry in data["entries"]]
    assert not any(
        "/ORIGINAL_SOURCES/" in f"/{path}/" for path in paths
    )
    assert not any("/CHAT_BRANCHES/" in f"/{path}/" for path in paths)
    assert not any("/CHATS/" in f"/{path}/" for path in paths)


def test_next_cycle_shifted_to_1339() -> None:
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1338" in plan
    assert "logs_71459043999.zip" in plan
    assert "Shop admin actions" in plan
    assert "SHIFTED to 1339" in plan
