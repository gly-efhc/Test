from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_orphan_interactive_bank_dashboard_is_deleted() -> None:
    orphan = ROOT / (
        "frontend/src/components/admin/"
        "AdminInteractiveBankDashboard.tsx"
    )
    assert not orphan.exists()


def test_admin_home_uses_release_data_only() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in home
    assert "AdminInteractiveBankDashboard" not in home
    assert "Релизные данные" in home


def test_sim_ui_kit_consolidation_exports_plan_components() -> None:
    text = read("frontend/src/components/dashboard/SimulationDashboardUiKit.tsx")
    required = [
        "SimPanelCard",
        "SimPanelPortfolioSummary",
        "SimRankCard",
        "SimLeaderboardRow",
        "SimRankTierLadder",
        "SimCountdownBadge",
        "SimLiveIndicator",
        "SimValueDelta",
        "SimBalanceTicker",
        "SimLoadingCard",
        "SimEmptyCard",
        "SimErrorCard",
        "SimSkeleton",
        "EFHC_SIM_DASHBOARD_UI_KIT_V6_CONSOLIDATED",
    ]
    missing = [marker for marker in required if marker not in text]
    assert missing == []


def test_admin_ui_kit_consolidation_exports_plan_components() -> None:
    text = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    required = [
        "AdminDashboardSection",
        "AdminPanelActions",
        "AdminPanelMenu",
        "AdminStatCard",
        "AdminDataTable",
        "AdminCompactTable",
        "AdminEventFeed",
        "AdminLogList",
        "AdminLineChart",
        "AdminBarChart",
        "AdminStackedBarChart",
        "AdminStatusTimeline",
        "AdminPanelLoading",
        "AdminPanelEmpty",
        "AdminPanelError",
        "AdminPanelSkeleton",
    ]
    missing = [marker for marker in required if marker not in text]
    assert missing == []


def test_future_range_1501_1600_exists_and_tracks_audit_backlog() -> None:
    text = read("docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md")
    assert "1501–1600" in text
    assert "UI Kit Consolidation" in text
    assert "admin_domain_report_endpoints_backlog" in text
    assert "VIS-03" in text
    assert "Browser Screenshot Proof" in text


def test_1497_docs_record_direction_audit_followup() -> None:
    doc = read("docs/NORM/DASHBOARD_DIRECTION_AUDIT_FOLLOWUP.md")
    assert "DIRECTION_COMPLETE_WITH_KNOWN_GAPS" in doc
    assert "orphan_build_series_closed" in doc
    assert "ui_kit_component_gap_closed" in doc
    assert "admin_domain_report_endpoints_backlog" in doc
    assert "1501-1600" in doc
