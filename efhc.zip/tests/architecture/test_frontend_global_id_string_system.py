"""Причинная приёмка frontend GlobalId string system."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest
from ops.identity.check_frontend_global_id_string_system import (
    найти_числовые_global_id,
    проверить,
)

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "frontend/src/types/identity.ts"


def test_exact_head_соблюдает_frontend_global_id_string_canon() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["global_id_является_branded_string"] is True
    assert result["javascript_number_запрещён"] is True
    assert result["арифметика_запрещена"] is True


def test_guard_отклоняет_global_id_number(tmp_path: Path) -> None:
    bad = tmp_path / "frontend/src/bad.ts"
    bad.parent.mkdir(parents=True)
    bad.write_text("type Bad = { global_id: number };\n", encoding="utf-8")
    findings = найти_числовые_global_id(tmp_path)
    assert findings[0]["причина"] == "global_id_as_number"


def test_guard_отклоняет_числовое_преобразование(tmp_path: Path) -> None:
    bad = tmp_path / "frontend/src/bad.ts"
    bad.parent.mkdir(parents=True)
    bad.write_text("const value = Number(session.global_id);\n", encoding="utf-8")
    findings = найти_числовые_global_id(tmp_path)
    assert findings[0]["причина"] == "global_id_numeric_conversion"


def test_guard_отклоняет_арифметику(tmp_path: Path) -> None:
    bad = tmp_path / "frontend/src/bad.ts"
    bad.parent.mkdir(parents=True)
    bad.write_text("const next = globalId + 1;\n", encoding="utf-8")
    findings = найти_числовые_global_id(tmp_path)
    assert findings[0]["причина"] == "global_id_arithmetic"


def test_guard_отклоняет_небезопасный_cast(tmp_path: Path) -> None:
    bad = tmp_path / "frontend/src/bad.ts"
    bad.parent.mkdir(parents=True)
    bad.write_text("const value = raw as GlobalId;\n", encoding="utf-8")
    findings = найти_числовые_global_id(tmp_path)
    assert findings[0]["причина"] == "unsafe_global_id_cast"


def _require_tool(name: str) -> str:
    executable = shutil.which(name)
    if executable is None:
        pytest.skip(f"Инструмент {name} отсутствует в среде.")
    return executable


def _compile_identity(tmp_path: Path) -> Path:
    tsc = _require_tool("tsc")
    out = tmp_path / "compiled"
    result = subprocess.run(
        [
            tsc,
            str(SOURCE),
            "--target",
            "ES2020",
            "--module",
            "commonjs",
            "--strict",
            "--skipLibCheck",
            "--outDir",
            str(out),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    return out / "identity.js"


def test_runtime_сохраняет_ведущие_нули_и_отклоняет_ошибки(
    tmp_path: Path,
) -> None:
    node = _require_tool("node")
    compiled = _compile_identity(tmp_path)
    script = """
const assert = require("node:assert/strict");
const identity = require(process.argv[1]);
const value = identity.parseGlobalId("0000000042");
assert.equal(value, "0000000042");
assert.equal(identity.globalIdToApi(value), "0000000042");
assert.equal(identity.formatGlobalId(value), "0000000042");
assert.equal(identity.isGlobalId("0000000042"), true);
assert.equal(identity.isGlobalId("0000000000"), false);
for (const invalid of [42, "42", "0000000000", "１２３４５６７８９０", "0000000042 "]) {
  assert.throws(() => identity.parseGlobalId(invalid));
}
const error = (() => {
  try { identity.parseGlobalId(42); } catch (caught) { return caught; }
})();
assert.deepEqual(error.asObject(), {
  поле: "global_id",
  код: "global_id.frontend.type",
  сообщение: "Global ID должен быть строкой.",
});
"""
    result = subprocess.run(
        [node, "-e", script, str(compiled)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_typescript_не_принимает_number_как_global_id(
    tmp_path: Path,
) -> None:
    tsc = _require_tool("tsc")
    source = tmp_path / "identity.ts"
    source.write_text(SOURCE.read_text(encoding="utf-8"), encoding="utf-8")
    invalid = tmp_path / "invalid.ts"
    invalid.write_text(
        'import type { GlobalId } from "./identity";\n'
        "const bad: GlobalId = 42;\n"
        "const arithmetic = bad * 2;\n"
        "void arithmetic;\n",
        encoding="utf-8",
    )
    result = subprocess.run(
        [
            tsc,
            str(source),
            str(invalid),
            "--target",
            "ES2020",
            "--module",
            "commonjs",
            "--strict",
            "--skipLibCheck",
            "--noEmit",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode != 0
    assert "Type 'number' is not assignable to type 'GlobalId'" in (
        result.stdout + result.stderr
    )


def test_цикл_1605_имеет_точный_operator_kernel_route() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    classified = classify_task("Цикл 1605 Frontend GlobalId string system")
    assert classified["task_type"] == "frontend_global_id_string_system"
    route = resolve_route("frontend_global_id_string_system", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_guard_report_сериализуется_на_русском() -> None:
    payload = json.dumps(проверить(ROOT), ensure_ascii=False)
    assert "нарушения" in payload
    assert "пройдено" in payload


