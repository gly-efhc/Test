from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_tasks_frontend_uses_current_user_routes_and_query_hooks() -> None:
    page = read("frontend/src/pages/tasks.tsx")
    service = read("frontend/src/services/tasks.service.ts")
    queries = read("frontend/src/queries/useTasks.ts")
    assert '"/tasks/my"' in service
    assert '"/tasks/claim"' in service
    assert "/tasks/my/${tg_id}" not in page
    assert "/tasks/claim/${tg_id}" not in page
    assert "efhc-tasks-shell" in page
    assert "efhc-task-card" in page
    assert "helpText" in page
    assert "buttonLabel" in page
    assert 'data-tasks-runtime="cycle-1557-react-query"' in page
    assert "useClaimTask" in page
    assert "useFinishBuiltinTimerAd" in page
    assert "useMutation" not in page
    assert "useQueryClient" not in page
    assert "invalidateTaskState" in queries


def test_tasks_backend_routes_are_current_user() -> None:
    src = read("backend/app/routes/tasks_routes.py")
    assert '"/my"' in src
    assert '"/claim"' in src
    assert '"/my/{tg_id}"' in src
    assert '"/claim/{tg_id}"' in src
    assert "include_in_schema=False" in src
    assert "owner.legacy_tg_id" in src
    assert "int(tg_id) != int(legacy_tg_id)" in src


def test_tasks_css_and_locale_keys_exist() -> None:
    css = read("frontend/src/styles/globals.css")
    for token in [
        "efhc-tasks-hero",
        "efhc-task-card_bottom",
        "efhc-task-status--ready",
    ]:
        assert token in css

    keys = [
        "tasks.earning_kicker",
        "tasks.hero_detail",
        "tasks.help_watch_ad",
        "tasks.button_unavailable",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in keys:
            assert key in data, f"{path.name} misses {key}"


def test_human_questions_rule_is_recorded() -> None:
    doc = read("docs/audits/HUMAN_QUESTIONS_STYLE_RULE.md")
    assert "человеческим языком" in doc
    assert "технического робота" in doc
    assert "только через чат" in doc


def test_evidence_json_records_no_release_ready_claim() -> None:
    data = json.loads(read("reports/generated/tasks_compact_routes.json"))
    assert data["cycles"] == "1217-1218"
    assert data["frontend"]["uses_self_routes"] is True
    assert data["release_ready_claimed"] is False
