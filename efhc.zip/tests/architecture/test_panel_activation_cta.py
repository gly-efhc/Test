from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PANELS = ROOT / "frontend/src/pages/panels.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORT = (
    ROOT
    / "reports/generated"
    / "frontend_cycle_1280_panel_activation_v168_78.json"
)
LOCALES = ROOT / "frontend/public/locale"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_panel_activation_cta_has_canonical_markers() -> None:
    src = read(PANELS)
    assert 'data-panel-activation-cta="100-efhc"' in src
    assert (
        'data-panel-activation-debit="bonus-first-main-second"' in src
    )
    assert 't("panels.activation_price_100")' in src
    assert 't("panels.activation_debit_order")' in src


def test_panel_activation_uses_total_balance_for_ui_gate() -> None:
    src = read(PANELS)
    assert "bonus_balance" in src
    assert "sumScaledDown" in src
    assert "totalActivationBalance" in src
    assert 'cmp8(totalActivationBalance, "100") >= 0' in src
    assert 'cmp8(mainBalance, "100") >= 0' not in src


def test_panel_activation_note_is_styled() -> None:
    css = read(CSS)
    assert ".efhc-panels-activation-note" in css
    assert "min-width: min(15rem, 100%);" in css
    assert "border-radius: 1rem;" in css


def test_panel_activation_locale_keys_exist() -> None:
    required = [
        '"panels.activation_price_100"',
        '"panels.activation_debit_order"',
        '"panels.needs_100_efhc_total"',
    ]
    for path in LOCALES.glob("*.json"):
        text = read(path)
        missing = [key for key in required if key not in text]
        assert missing == []


def test_cycle_1280_is_documented() -> None:
    combined = read(PLAN) + "\n" + read(REPORT)
    assert "1280" in combined
    assert "panel activation CTA" in combined
    assert "100 EFHC" in combined
    assert "bonus-first" in combined
