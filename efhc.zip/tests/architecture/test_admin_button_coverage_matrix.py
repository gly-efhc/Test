from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/ADMIN_BUTTON_COVERAGE_MATRIX.md"
SECTIONS = [
    "Admin Overview",
    "Admin Users",
    "Admin Bank",
    "Admin Deposits",
    "Admin Withdrawals",
    "Admin Shop",
    "Admin Sale Packages",
    "Admin Tasks",
    "Admin Referrals",
    "Admin Panels",
    "Admin Ads",
    "Admin Logs / Events",
    "Admin Observability",
    "Admin Reports",
    "Admin Templates",
    "Admin System / Hub",
]


def _doc() -> str:
    return DOC.read_text(encoding="utf-8")


def test_admin_button_coverage_matrix_exists() -> None:
    assert DOC.exists()
    assert "| Admin section | Button/action |" in _doc()


def test_all_required_admin_sections_listed() -> None:
    text = _doc()
    missing = [section for section in SECTIONS if section not in text]
    assert not missing, missing


def test_no_ui_only_admin_actions_without_status() -> None:
    text = _doc()
    assert "UI_ONLY_BUG" in text
    assert "ROUTE_ONLY_BUG" in text


def test_no_mutating_admin_route_without_guard() -> None:
    text = _doc()
    assert "require_admin" in text
    assert "MISSING_GUARD" in text


def test_admin_mutations_have_audit_log_or_exception() -> None:
    text = _doc()
    assert "admin_action_log" in text
    assert "read-only log N/A" in text


def test_destructive_admin_actions_have_confirmation() -> None:
    text = _doc()
    assert "Confirmation" in text
    assert "required" in text


def test_admin_withdrawals_follow_admin_payout_canon() -> None:
    text = _doc()
    assert "operator wallet action" in text
    assert "not treasury access" in text
