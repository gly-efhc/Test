from __future__ import annotations

import csv
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _rows(root: Path) -> list[dict[str, str]]:
    p = root / "docs" / "SSOT" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
    with p.open("r", encoding="utf-8") as f:
        return [
            row
            for row in csv.DictReader(f)
            if (row.get("table") or "").strip()
        ]


def test_db_diagnostic_docs_match_ssot_tables() -> None:
    root = _repo_root()
    rows = _rows(root)
    text = (
        root / "docs" / "audits" / "DIAGNOSTIC_DB_INVENTORY.md"
    ).read_text(encoding="utf-8")
    assert "**2** (`efhc_core`, `efhc_admin`)" in text
    assert f"ORM-таблицы: **{len(rows)}**" in text
    assert "Historical traces допустимы только" in text


def test_ssot_db_schemas_tables_doc_matches_csv() -> None:
    root = _repo_root()
    rows = _rows(root)
    text = (
        root / "docs" / "SSOT" / "SSOT_DB_SCHEMAS_TABLES.md"
    ).read_text(encoding="utf-8")
    core = [r for r in rows if r["schema"].strip() == "efhc_core"]
    admin = [r for r in rows if r["schema"].strip() == "efhc_admin"]
    assert f"## Таблицы (ровно {len(rows)})" in text
    assert f"### efhc_core ({len(core)})" in text
    assert f"### efhc_admin ({len(admin)})" in text
    assert "### efhc_core (33)" not in text
    assert "## Таблицы (ровно 38)" not in text


def test_db__schema__doc_keeps_two__schema__canon() -> None:
    root = _repo_root()
    text = (root / "docs" / "GENERAL" / "DB_SCHEMA.md").read_text(
        encoding="utf-8"
    )
    assert "разрешены только `efhc_core` и `efhc_admin`" in text
    assert "третьи схемы запрещены" in text
    assert "Historical traces допустимы только" in text
