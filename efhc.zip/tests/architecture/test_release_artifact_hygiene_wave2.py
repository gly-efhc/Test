from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BUILD_SCRIPT = ROOT / "ops" / "build_efhc_zip.sh"
REQUIRED_RELEASE_EXCLUDES = (
    ".local_artifacts",
    "logs/",
    "./logs/*",
    "*.log",
    "${ZIP_OUT}",
)


def test_build_script_excludes_runtime_log_artifacts() -> None:
    text = BUILD_SCRIPT.read_text(encoding="utf-8")
    missing = [
        item for item in REQUIRED_RELEASE_EXCLUDES if item not in text
    ]
    assert not missing, (
        "build script misses runtime log excludes: " f"{missing}"
    )
