from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1500_docs_and_reports_exist() -> None:
    expected = [
        "docs/NORM/FINAL_RANGE_CLOSURE.md",
        "docs/cycles/WORK_CYCLES_1500_FINAL_RANGE_CLOSURE.md",
        "reports/generated/final_range_1401_1500_closure_v170_76.json",
        "reports/change_cycle_2026-06-11_v170_76_cycle_1500_final_range_closure.md",
    ]
    for rel in expected:
        assert (ROOT / rel).exists(), rel


def test_final_range_counters_are_closed() -> None:
    closure = read("docs/NORM/FINAL_RANGE_CLOSURE.md")
    cycles = read("docs/cycles/WORK_CYCLES.md")
    range_plan = read("docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md")
    assert "Overall range `1401–1500` | `100 / 100` done, `0 / 100` remaining" in closure
    assert "Dashboard direction `1455–1496` | `42 / 42` done, `0 / 42` remaining" in closure
    assert "Overall range `1401–1500`: `100 / 100` done, `0 / 100` remaining." in cycles
    assert "Range `1401–1500`: `100 / 100` done, `0 / 100` remaining." in range_plan


def test_future_range_transition_is_explicit() -> None:
    closure = read("docs/NORM/FINAL_RANGE_CLOSURE.md")
    future = read("docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md")
    assert "1501 — Dashboard UI Kit Consolidation QA" in closure
    assert "1501 — Dashboard UI Kit Consolidation QA" in future
    assert "1401–1500` is closed" in future
    proof_markers = [
        "Browser Screenshot Proof Matrix",
        "GitHub CI Rerun Proof",
        "Release Audit Preparation",
    ]
    for marker in proof_markers:
        assert marker in future
    if "AUDIT_TZ_REPAIR_1501_1504" in future:
        assert "1502 — DASH-01" in future
        assert "1503 — DASH-02" in future
        assert "1504 — DASH-03" in future
    else:
        assert "1502 — Admin Domain Report Endpoints Foundation" in future
        assert "1503 — Post-VIS-03 Regression QA" in future
        assert "1504 — Browser Screenshot Proof Matrix" in future


def test_final_closure_report_has_non_claims_and_evidence() -> None:
    report = json.loads(read("reports/generated/final_range_1401_1500_closure_v170_76.json"))
    assert report["status"] == "DONE_LOCALLY_RANGE_CLOSED"
    assert report["range_1401_1500"] == {"done": 100, "total": 100, "remaining": 0, "status": "CLOSED"}
    assert report["dashboard_direction_1455_1496"]["status"] == "CLOSED_FROZEN"
    assert report["verified"]["input_zip_testzip"] == "None"
    assert report["verified"]["ai_archive_laws_lock"] == "OK"
    assert "GitHub CI green for v170.76" in report["non_claims"]
    assert "release-ready" in report["non_claims"]


def test_kernel_routes_map_and_report_index_reference_1500() -> None:
    kernel = read("KERNEL.md")
    routes = read("ops/operator_kernel/config/routes.yaml")
    mapping = read("map_element.md")
    reports = read("reports/REPORTS_INDEX.md")
    assert "1500 — Final Range Closure / Transition to 1501–1600" in (
        kernel + mapping
    )
    assert "final_range_1401_1500_closure" in routes
    assert "FINAL_RANGE_CLOSURE.md" in mapping
    assert "final_range_1401_1500_closure_v170_76.json" in reports


def test_test_guard_manifest_records_cycle_1500() -> None:
    manifest = json.loads(read("docs/testing/TEST_GUARD_MANIFEST.json"))
    assert manifest["last_updated_cycle"] >= 1500
    assert manifest["active_architecture"] >= 322
    assert "cycle_1500_final_range_closure" in manifest
    assert any(
        item.get("file") == "tests/architecture/test_final_range_closure.py"
        for item in manifest.get("active_guards", [])
        if isinstance(item, dict)
    )


def test_reference_layers_remain_reference_only() -> None:
    closure = read("docs/NORM/FINAL_RANGE_CLOSURE.md")
    assert "Песочница использована только как reference/navigation/prototype layer. Runtime-код не переносился." in closure
    assert "Grafana использована только как visual-pattern/reference layer. Runtime-код не переносился." in closure
