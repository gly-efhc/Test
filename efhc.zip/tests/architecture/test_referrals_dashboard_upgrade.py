from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_referrals_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/REFERRALS_DASHBOARD_UPGRADE.md",
        "docs/NORM/REFERRALS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1478_REFERRALS_DASHBOARD_UPGRADE.md",
        "reports/generated/referrals_dashboard_upgrade_v170_54.json",
        "reports/change_cycle_2026-06-07_v170_54_cycle_1478_referrals_dashboard_upgrade.md",
        "frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx",
        "tests/architecture/test_referrals_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(
        read("reports/generated/referrals_dashboard_upgrade_v170_54.json")
    )
    assert data["cycle"] == 1478
    assert data["archive_version"] == "v170.54"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_referrals_route_changed"] is True
    assert data["source_endpoint"] == "/referrals/stats/me"
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["referral_bonus_rule_changed"] is False
    assert data["active_rule_changed"] is False
    assert data["raw_tg_id_visible_in_dashboard"] is False
    assert data["child_tg_id_visible_in_dashboard"] is False
    assert data["fake_referral_history_added"] is False
    assert data["fake_growth_timeseries_added"] is False
    assert data["grafana_runtime_code_copied"] is False


def test_referrals_dashboard_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx")
    required = [
        "referralsDashboardRuntimeVersion",
        "EFHC_REFERRALS_DASHBOARD_RUNTIME_V1",
        "data-referrals-dashboard-runtime=\"1478\"",
        "data-referrals-dashboard-no-raw-tg-id=\"true\"",
        "data-referrals-dashboard-no-fake-history=\"true\"",
        "data-referrals-dashboard-no-write-bypass=\"true\"",
        "data-referrals-dashboard-truth=\"raw-derived\"",
        "SimReferralScopeFilter",
        "SimSegmentedProgress",
        "SimMiniBarChart",
        "SimActivityStrip",
    ]
    for marker in required:
        assert marker in src


def test_referrals_dashboard_component_is_ui_only() -> None:
    src = read("frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "creditReferral",
        "referral_bonus_log",
        "child_tg_id",
        "tg_id",
        "synthetic_preview",
    ]
    for marker in forbidden:
        assert marker not in src


def test_referrals_page_uses_current_operational_surface_safely() -> None:
    page = read("frontend/src/pages/referrals.tsx")
    required = [
        "useReferralStats",
        'data-referrals-runtime="react-query-linkage-1558"',
        'data-referral-action="copy-link"',
        'data-referral-action="share-link"',
        'data-referrals-segments="active-inactive"',
        'data-referrals-list-mode="segmented-inline"',
        'data-referrals-tabs="active-inactive"',
        "ReferralRoster",
    ]
    for marker in required:
        assert marker in page
    assert "ReferralsDashboardRuntime" not in page
    assert "/referrals/history" not in page
    assert "/referrals/logs" not in page


def test_simulation_ui_kit_has_referral_scope_filter() -> None:
    src = read("frontend/src/components/dashboard/SimulationDashboardUiKit.tsx")
    assert "SimReferralScopeFilter" in src
    assert "referral_scope" in src
    assert "EFHC_SIM_VARIABLES_FILTERS_V2_REFERRALS" in src


def test_locale_keys_exist_in_all_languages() -> None:
    required = [
        "referrals.dashboard_title",
        "referrals.dashboard_subtitle",
        "referrals.dashboard_fresh",
        "referrals.dashboard_source",
        "referrals.dashboard_raw_data",
        "referrals.dashboard_derived_display",
        "referrals.dashboard_total",
        "referrals.dashboard_active",
        "referrals.dashboard_inactive",
        "referrals.dashboard_bonus_balance",
        "referrals.dashboard_bonus_total",
        "referrals.dashboard_progress_title",
        "referrals.dashboard_growth_title",
        "referrals.dashboard_bonus_title",
        "referrals.dashboard_scope_label",
        "referrals.dashboard_no_history",
        "referrals.dashboard_bonus_rule",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in required if key not in data]
        assert not missing, f"{path.name}: {missing}"


def test_referrals_dashboard_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1478 — Referrals Dashboard Upgrade",
        ".efhc-referrals-dashboard-runtime",
        ".efhc-referrals-dashboard-runtime__scope",
        ".efhc-referrals-dashboard-runtime__bonus",
        ".efhc-referrals-dashboard-runtime__cards",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1478 — Referrals Dashboard Upgrade" in corpus
    assert "REFERRALS_DASHBOARD_UPGRADE" in corpus
    assert "1479 — Exchange Dashboard Support Widgets" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/REFERRALS_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/REFERRALS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs
