from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_p0_identity_payment_schema_deposit_invariants_remain_active() -> None:
    referrals = read("backend/app/crud/referrals_crud.py")
    payment_model = read("backend/app/models/payment_intents_models.py")
    payment_service = read("backend/app/services/payment_intents_service.py")
    tx_model = read("backend/app/models/transactions_models.py")
    deposits = read("backend/app/services/efhc_deposits_service.py")

    assert "ReferralLink.inviter_tg_id == User.tg_id" in referrals
    assert "ReferralLink.inviter_tg_id == User.id" not in referrals

    assert "package_id: Mapped[int | None]" in payment_model
    assert "nullable=True" in payment_model
    assert '"package_id": package_id' in payment_service
    assert payment_service.count("package_id=None") >= 2
    assert "package_id=0" not in payment_service

    assert "direction: Mapped[str]" in tx_model
    assert "String(24)" in tx_model

    assert 'DEPOSIT_IDEMPOTENCY_SCOPE = "deposit:efhc"' in deposits
    assert 'DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"' in deposits
    assert "DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None" in deposits
    assert "idempotency_fingerprint_mismatch" in deposits
    assert "_ttl_seen" not in deposits


def test_p0_idempotency_transaction_withdraw_invariants_remain_active() -> None:
    tx_service = read("backend/app/services/transactions_service.py")
    withdraw_service = read("backend/app/services/withdraw_service.py")
    exchange_service = read("backend/app/services/exchange_service.py")

    assert "idempotency_conflict:" in tx_service.lower()
    assert 'startswith("idempotency_conflict:")' in tx_service
    assert "async def debit_user_to_bank_nocommit(" in tx_service

    tx_context_start = tx_service.index("async def _tx_context(db: AsyncSession):")
    tx_context_end = tx_service.index("settings = get_settings()", tx_context_start)
    tx_context = tx_service[tx_context_start:tx_context_end]
    assert "db.begin_nested" not in tx_context
    assert "await db.commit()" in tx_context
    assert "await db.rollback()" in tx_context

    request_start = withdraw_service.index("async def request_withdraw(")
    request_end = withdraw_service.index("async def cancel_withdraw", request_start)
    request_slice = withdraw_service[request_start:request_end]
    assert "HEAL-0024" in request_slice
    assert "async with _tx_context(db):" in request_slice
    assert "debit_user_to_bank_nocommit(" in request_slice
    assert "hold_done = TRUE" in request_slice

    preflight_start = exchange_service.index("before_state = await _read_user_exchange_state")
    preflight_end = exchange_service.index("exchange_partial_available_kwh_to_main(", preflight_start)
    preflight = exchange_service[preflight_start:preflight_end]
    assert "HEAL-0018" in preflight
    assert "await db.rollback()" in preflight


def test_p0_cross_guard_docs_and_manifest_track_cycle_1414() -> None:
    plan = read("docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md")
    manifest = read("docs/testing/TEST_GUARD_MANIFEST.md")
    atlas = read("HEALER_ATLAS.md")
    casebook = read("docs/healer/HEALER_CASEBOOK.md")

    assert "1414" in plan
    assert "P0 cross-guard consolidation" in plan
    assert "test_p0_cross_guard_consolidation.py" in manifest
    assert "HEAL-0055" in atlas
    assert "HEAL-0055" in casebook
