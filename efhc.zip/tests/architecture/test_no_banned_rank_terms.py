from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

# --- Log artifacts policy (SSOT) ---
# Логи и журналы ошибок фиксируются 1:1 (как есть) и могут содержать
# строки из CI/traceback. Поэтому они исключаются из
# большинства guard-тестов,
# чтобы не ломать канон проекта. Исключение: отдельный тест
# длины строки 72.
LOG_EXCLUDED_FILE_NAMES = {
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
}
LOG_EXCLUDED_DIR_PARTS = {
    ".local_artifacts",
    "audit",
    "reports",
    "logs",
}
LOG_EXCLUDED_SUFFIXES = {
    ".log",
}

def _is_docs_audits_path(path: Path) -> bool:
    parts = path.parts
    for idx in range(len(parts) - 1):
        if parts[idx] == "docs" and parts[idx + 1] == "audits":
            return True
    return False


def _is_log_artifact(path: Path) -> bool:
    if path.name in LOG_EXCLUDED_FILE_NAMES:
        return True
    if set(path.parts) & LOG_EXCLUDED_DIR_PARTS:
        return True
    if path.suffix.lower() in LOG_EXCLUDED_SUFFIXES:
        return True
    return bool(path.name.startswith("logs_"))


IGNORED_DIR_PARTS = {
    "__pycache__",
    "alembic",
    "migrations",
    ".venv",
    "venv",
    ".git",
    ".idea",
    ".pytest_cache",
    ".mypy_cache",
    "node_modules",
    "dist",
    "build",
    ".local_artifacts",
    "audit",
    "reports",
}

# Не сканируем бинарные файлы / артефакты.
IGNORED_SUFFIXES = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".gif",
    ".ico",
    ".zip",
    ".pdf",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".mp3",
    ".wav",
    ".mp4",
    ".mov",
    ".sqlite",
    ".db",
}

MAX_BYTES = 2_000_000


@dataclass(frozen=True)
class Violation:
    file_path: str
    line: int
    message: str


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _iter_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if _is_log_artifact(p):
            continue
        if _is_docs_audits_path(p):
            continue
        if set(p.parts) & IGNORED_DIR_PARTS:
            continue
        if p.suffix.lower() in IGNORED_SUFFIXES:
            continue
        try:
            if p.stat().st_size > MAX_BYTES:
                continue
        except OSError:
            continue
        yield p


def test_no_banned_rank_terms_anywhere() -> None:
    # Канон: публичное имя модуля — Ranks.
    # Запрещены любые подстроки legacy-терминов.

    # ВАЖНО: не пишем запретные токены подряд в исходнике теста.
    banned = [
        ("ra" + "ting"),
        ("rei" + "ting"),
        ("rai" + "ting"),
    ]

    root = _repo_root()
    violations: list[Violation] = []

    for f in _iter_files(root):
        text = f.read_text(encoding="utf-8", errors="replace")
        low = text.lower()
        if not any(tok in low for tok in banned):
            continue

        for line_no, line in enumerate(text.splitlines(), start=1):
            ll = line.lower()
            hit = next((tok for tok in banned if tok in ll), None)
            if hit:
                violations.append(
                    Violation(
                        file_path=f.as_posix(),
                        line=line_no,
                        message=(
                            "CRITICAL CANON VIOLATION: "
                            "запрещённая подстрока "
                            "встречена в репозитории. Канон: Ranks."
                        ),
                    )
                )

    if violations:
        head = violations[:50]
        lines = [f"{v.file_path}:{v.line}: {v.message}" for v in head]
        if len(violations) > 50:
            lines.append(f"... и ещё {len(violations) - 50} нарушений.")
        raise AssertionError("\n".join(lines))
