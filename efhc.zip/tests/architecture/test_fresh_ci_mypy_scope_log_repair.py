from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "reports/generated/fresh_ci_mypy_scope_log_repair_v171_07.json"
NORM = ROOT / "docs/NORM/FRESH_CI_MYPY_SCOPE_LOG_REPAIR.md"
CYCLE = (
    ROOT
    / "docs/cycles/WORK_CYCLES_1532_FRESH_CI_MYPY_SCOPE_LOG_REPAIR.md"
)
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_cycle_1532_report_and_docs_exist() -> None:
    assert REPORT.exists()
    assert NORM.exists()
    assert CYCLE.exists()
    data = load(REPORT)
    assert data["cycle"] == 1532
    assert data["input_head"] == "v171.06"
    assert data["output_head"] == "v171.07"
    assert data["log_verdict"] == "RED"
    assert data["failed_gates"] == ["ruff", "pytest"]


def test_cycle_1532_records_mypy_scope_success() -> None:
    data = load(REPORT)
    assert "283 source files" in data["mypy_summary"]
    assert "mypy" in data["passed_gates"]
    assert "ruff" in data["failed_gates"]
    assert "pytest" in data["failed_gates"]


def test_cycle_1532_does_not_claim_output_green_or_release_ready() -> None:
    data = load(REPORT)
    for key in [
        "github_ci_green_claimed_for_output",
        "full_pytest_green_claimed",
        "frontend_build_green_claimed_for_output",
        "live_telegram_proof_claimed",
        "real_tonconnect_proof_claimed",
        "release_ready_claimed",
    ]:
        assert data[key] is False


def test_cycle_1532_preserves_runtime_boundaries() -> None:
    data = load(REPORT)
    for key in [
        "runtime_changed",
        "money_flow_changed",
        "wallet_flow_changed",
        "withdraw_logic_changed",
        "tonconnect_changed",
        "frontend_runtime_changed",
        "economy_changed",
    ]:
        assert data[key] is False


def test_cycle_1532_navigation_updated() -> None:
    joined = "\n".join([read(KERNEL), read(MAP), read(NORM), read(CYCLE)])
    assert "v171_07 / v171.07" in joined
    assert "logs_74475316189.zip" in joined
    assert "Fresh CI rerun" in joined or "fresh CI rerun" in joined
