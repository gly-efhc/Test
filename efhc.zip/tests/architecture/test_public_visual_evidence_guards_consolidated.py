"""Запуск только действующих public visual case-модулей."""

from __future__ import annotations

import importlib.util
import inspect
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
CASE_DIR = ROOT / "tests/architecture/public_visual_cases"


def _load(path: Path) -> object:
    spec = importlib.util.spec_from_file_location(
        f"efhc_public_visual_{path.stem}", path
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _cases() -> list[tuple[Path, str]]:
    result: list[tuple[Path, str]] = []
    for path in sorted(CASE_DIR.glob("case_*.py")):
        module = _load(path)
        for name, value in inspect.getmembers(module):
            if name.startswith("test_") and callable(value):
                result.append((path, name))
    return result


CASES = _cases()


@pytest.mark.parametrize(
    ("path", "test_name"),
    CASES,
    ids=lambda value: value.name if isinstance(value, Path) else value,
)
def test_проверка_current_public_visual_case(path: Path, test_name: str) -> None:
    test = getattr(_load(path), test_name)
    signature = inspect.signature(test)
    if signature.parameters:
        pytest.skip(
            f"case requires pytest fixtures and is collected in its own module: {test_name}"
        )
    test()


def test_проверка_public_visual_case_inventory_is_not_empty() -> None:
    assert CASES
