from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
_MODULE_CACHE: dict[str, object] = {}


def _load_support_module(rel_path: str) -> object:
    cached = _MODULE_CACHE.get(rel_path)
    if cached is not None:
        return cached
    path = ROOT / rel_path
    assert path.exists(), rel_path
    module_name = (
        "efhc_consolidated_"
        + rel_path.replace("/", "_").replace(".", "_")
    )
    spec = importlib.util.spec_from_file_location(
        module_name,
        path,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MODULE_CACHE[rel_path] = module
    return module


_CASES = [
    (
        "tests/architecture/public_visual_cases/case_public_browser_screenshot_evidence_harness.py",
        "test_public_browser_screenshot_harness_artifacts_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_browser_screenshot_evidence_harness.py",
        "test_manifest_covers_all_public_routes_and_devices",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_browser_screenshot_evidence_harness.py",
        "test_harness_does_not_claim_fake_screenshot_proof",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_browser_screenshot_evidence_harness.py",
        "test_e2e_capture_is_env_gated_and_writes_png_evidence",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_browser_screenshot_evidence_harness.py",
        "test_product_filenames_keep_semantic_non_cycle_labels",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_qa_preparation_complete.py",
        "test_public_ui_qa_preparation_documents_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_qa_preparation_complete.py",
        "test_public_ui_qa_preparation_scope_has_all_routes",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_qa_preparation_complete.py",
        "test_locale_common_error_keys_are_complete",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_qa_preparation_complete.py",
        "test_public_ui_e2e_interaction_smokes_are_not_render_only",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_qa_preparation_complete.py",
        "test_offline_html_is_multilingual_fallback",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_regression_proof.py",
        "test_public_regression_proof_documents_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_regression_proof.py",
        "test_public_regression_proof_matrix_covers_all_public_routes",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_regression_proof.py",
        "test_generated_public_regression_json_matches_scope",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_regression_proof.py",
        "test_public_pages_exist_and_keep_expected_backend_markers",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_regression_proof.py",
        "test_public_proof_updates_cycle_and_ai_indexes",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_regression_proof.py",
        "test_public_proof_does_not_import_sandbox_runtime_or_touch_ci",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_repair_guard.py",
        "test_hub_has_no_public_technical_notice",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_repair_guard.py",
        "test_energy_keeps_only_contextual_canonical_first_action",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_repair_guard.py",
        "test_profile_hides_browser_and_pwa_technical_labels",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_repair_guard.py",
        "test_dark_shell_forces_readable_public_contrast",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_repair_guard.py",
        "test_local_smoke_test_and_safe_docker_docs_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_sandbox_audit.py",
        "test_public_ui_sandbox_audit_docs_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_sandbox_audit.py",
        "test_sandbox_sources_are_recorded",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_sandbox_audit.py",
        "test_public_ui_adoption_decision_is_safe",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_sandbox_audit.py",
        "test_operator_kernel_public_ui_route_exists",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_sandbox_audit.py",
        "test_cycle_plan_moves_to_public_energy",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_ui_sandbox_audit.py",
        "test_ci_manual_boundary_unchanged",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_energy_panels_exchange.py",
        "test_visual_beauty_artifacts_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_energy_panels_exchange.py",
        "test_energy_panels_exchange_have_visual_beauty_markers",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_energy_panels_exchange.py",
        "test_visual_css_supports_readable_chips_focus_and_mobile",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_energy_panels_exchange.py",
        "test_generated_manifest_tracks_three_surfaces_and_no_economics_change",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_energy_panels_exchange.py",
        "test_product_doc_keeps_semantic_filename_and_no_fake_browser_claim",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_tasks_referrals_ranks_visual_artifacts_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_shared_engagement_preview_has_visual_rail_and_no_admin_leak",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_tasks_surface_has_current_card_visual_state",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_referrals_surface_has_invite_share_visual_structure",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_ranks_surface_has_me_and_vertical_leaderboard_markers",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_visual_css_supports_chips_focus_mobile_and_motion_guard",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_generated_manifest_tracks_three_surfaces_and_no_economics_change",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_beauty_pass_tasks_referrals_ranks.py",
        "test_product_doc_keeps_semantic_filename_and_no_fake_browser_claim",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_profile_wallet_history_faq_visual_trust_artifacts_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_profile_surface_has_visual_trust_markers_and_no_admin_leak",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_public_profile_trust_layer_has_visual_rail_and_chips",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_wallet_and_history_sections_have_trust_rails",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_faq_surface_preserves_vertical_tree_and_trust_rail",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_visual_css_supports_trust_rails_focus_mobile_and_motion_guard",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_generated_manifest_tracks_four_surfaces_and_no_runtime_claim",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_profile_wallet_history_faq.py",
        "test_product_doc_keeps_semantic_filename_and_no_fake_browser_claim",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py",
        "test_public_visual_trust_document_and_manifest_exist",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py",
        "test_hub_browser_shop_withdraw_ads_have_public_trust_markers",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py",
        "test_visual_trust_css_supports_focus_mobile_and_reduced_motion",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py",
        "test_visual_trust_pass_does_not_import_admin_or_foreign_runtime",
    ),
    (
        "tests/architecture/public_visual_cases/case_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py",
        "test_hub_shop_withdraw_ads_economics_boundary_manifest",
    ),
]


@pytest.mark.parametrize(
    ("support_module", "function_name"),
    _CASES,
)
def test_public_visual_evidence_guard_case(
    support_module: str,
    function_name: str,
) -> None:
    module = _load_support_module(support_module)
    target = getattr(module, function_name)
    target()
