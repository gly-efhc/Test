from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "frontend" / "src"


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_faq_has_public_entry_points() -> None:
    header = read("frontend/src/components/GlobalHeader.tsx")
    profile = read("frontend/src/features/profile/WebProfilePage.tsx")
    assert 'router.push("/faq")' in header
    assert 'activeTab === "faq"' in profile
    assert 'label={t("faq.title")}' in profile
    assert "data-profile-faq-button-only" in profile
    assert 'href="/faq"' in profile


def test_admin_logs_route_exists() -> None:
    page = ROOT / "frontend" / "src" / "pages" / "admin" / "logs.tsx"
    assert page.exists()
    text = page.read_text(encoding="utf-8")
    assert "docker compose logs -f backend frontend" in text
    assert "docker compose down" in text
    assert "down -v" not in text


def test_no_link_wrapped_button_patterns_remain() -> None:
    offenders: list[str] = []
    for path in SRC.rglob("*.tsx"):
        text = path.read_text(encoding="utf-8")
        if (
            "<Link" in text
            and "<Button" in text
            and "<Link" in text.split("<Button", 1)[0][-80:]
        ):
            offenders.append(str(path.relative_to(ROOT)))
    assert offenders == []


def test_static_internal_route_links_resolve() -> None:
    pages_dir = ROOT / "frontend" / "src" / "pages"
    pages = {"/"}
    for path in pages_dir.rglob("*.tsx"):
        if path.name.startswith("_"):
            continue
        rel = str(path.relative_to(pages_dir))
        rel = rel.replace("index.tsx", "").replace(".tsx", "")
        route = "/" + rel.replace("/index", "").strip("/")
        pages.add(route or "/")

    static_links = {
        "/faq",
        "/admin/logs",
        "/admin",
        "/admin/users",
        "/admin/bank",
        "/admin/withdrawals",
        "/admin/shop",
        "/admin/tasks",
        "/admin/reports",
        "/admin/diagnostics",
        "/browser-shop",
        "/withdraw",
        "/exchange",
    }
    missing = sorted(link for link in static_links if link not in pages)
    assert missing == []
