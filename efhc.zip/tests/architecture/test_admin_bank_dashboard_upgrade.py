from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_bank_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_BANK_DASHBOARD_UPGRADE.md",
        "docs/NORM/ADMIN_BANK_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1483_ADMIN_BANK_DASHBOARD_UPGRADE.md",
        "reports/generated/admin_bank_dashboard_upgrade_v170_59.json",
        "reports/change_cycle_2026-06-08_v170_59_cycle_1483_"
        "admin_bank_dashboard_upgrade.md",
        "tests/architecture/test_admin_bank_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_bank_boundaries() -> None:
    data = json.loads(
        read("reports/generated/admin_bank_dashboard_upgrade_v170_59.json")
    )
    assert data["cycle"] == 1483
    assert data["archive_version"] == "v170.59"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_bank_route_changed"] is True
    assert data["fake_time_series_added"] is False
    assert data["synthetic_admin_analytics_added"] is False
    assert data["real_time_series_claimed"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["mint_burn_logic_changed"] is False
    assert data["bank_can_go_negative_canon_visible"] is True
    assert data["bank_ledger_boundary_visible"] is True
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False


def test_admin_bank_runtime_component_has_1483_markers() -> None:
    src = read("frontend/src/components/admin/AdminBankDashboardRuntime.tsx")
    required = [
        "adminBankDashboardRuntimeVersion",
        "EFHC_ADMIN_BANK_DASHBOARD_RUNTIME_V1",
        'data-admin-bank-dashboard-runtime="1483"',
        'data-admin-bank-truth="raw-derived"',
        'data-admin-bank-no-synthetic="true"',
        'data-admin-bank-no-write-actions="true"',
        'data-admin-bank-no-raw-payload="true"',
        'data-admin-bank-no-debug-json="true"',
        'data-admin-bank-canon="bank-can-go-negative"',
        "AdminDashboardToolbar",
        "AdminFreshnessBadge",
        "AdminRefreshPicker",
        "AdminPanelChrome",
        "AdminMiniBarChart",
        "AdminHeatStrip",
        "AdminProgressBar",
        "AdminFlowMapCard",
    ]
    for marker in required:
        assert marker in src


def test_admin_bank_runtime_component_is_read_only() -> None:
    src = read("frontend/src/components/admin/AdminBankDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "fetch(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "mutateAsync",
        "raw payload dump",
        "debug JSON dump",
        "synthetic_preview",
    ]
    for marker in forbidden:
        assert marker not in src
    assert "raw + derived snapshot" not in src
    assert "Derived snapshot display" in src


def test_admin_bank_page_integrates_runtime_dashboard() -> None:
    page = read("frontend/src/pages/admin/bank.tsx")
    assert "AdminBankDashboardRuntime" in page
    assert "AdminInteractiveOperatorPanel" not in page
    assert "ADMIN_BANK_MINT_PATH" in page
    assert "ADMIN_BANK_BURN_PATH" in page
    assert "AdminPromptModal" in page
    assert "newIdempotencyKey" in page
    assert 'data-admin-bank-cycle="1323"' in page
    assert 'data-admin-bank-action-proof="1324"' in page


def test_bank_canon_and_grafana_boundaries_are_documented() -> None:
    corpus = "\n".join(
        [
            read("docs/NORM/ADMIN_BANK_DASHBOARD_UPGRADE.md"),
            read("docs/NORM/ADMIN_BANK_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md"),
            read("docs/SSOT/BANK_CANON.md"),
        ]
    )
    required = [
        "bank can go negative",
        "user credit ⇒ bank debit",
        "user debit ⇒ bank credit",
        "no dashboard write bypass",
        "Grafana is used only as visual-pattern/reference layer",
        "Runtime code is not copied",
    ]
    for marker in required:
        assert marker in corpus


def test_admin_bank_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1483 — Admin Bank Dashboard Upgrade",
        'data-admin-bank-dashboard-runtime="1483"',
        ".efhc-admin-bank-dashboard-grid",
        ".efhc-admin-bank-dashboard-ledger-preview",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1483 — Admin Bank Dashboard Upgrade" in corpus
    assert "ADMIN_BANK_DASHBOARD_UPGRADE" in corpus
    assert "AdminBankDashboardRuntime.tsx" in corpus
    assert "1484 — Admin Users Dashboard Upgrade" in corpus


def test_old_bank_sandbox_operator_panel_is_not_on_bank_route() -> None:
    page = read("frontend/src/pages/admin/bank.tsx")
    assert "AdminInteractiveOperatorPanel" not in page
    assert "Песочница применена как donor-source" not in page
    component = read(
        "frontend/src/components/admin/AdminBankDashboardRuntime.tsx"
    )
    assert "fake time-series" not in component.lower()
    assert "synthetic admin analytics" not in component.lower()
