from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

RELEASE_HOME_ROUTES = (
    "/admin/users",
    "/admin/tasks",
    "/admin/ads",
    "/admin/panels",
    "/admin/referrals",
    "/admin/shop",
    "/admin/sale-packages",
    "/admin/withdrawals",
    "/admin/efhc-deposits",
    "/admin/reports",
)

RETAINED_TECHNICAL_ROUTES = (
    "/admin/diagnostics",
    "/admin/system",
)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_релизные_маршруты_существуют_и_показаны_на_главной() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    for route in RELEASE_HOME_ROUTES:
        file_name = route.rsplit("/", 1)[-1] + ".tsx"
        assert (ROOT / "frontend/src/pages/admin" / file_name).exists()
        assert f'href: "{route}"' in home


def test_технические_маршруты_сохранены_но_не_показаны_на_главной() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    for route in RETAINED_TECHNICAL_ROUTES:
        file_name = route.rsplit("/", 1)[-1] + ".tsx"
        assert (ROOT / "frontend/src/pages/admin" / file_name).exists()
        assert f'href: "{route}"' not in home


def test_главная_admin_использует_релизные_группы_модулей() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    assert '<AdminAppButtonGrid items={CORE_MODULES} />' in home
    assert '<AdminAppButtonGrid items={OPERATION_MODULES} />' in home
    assert "CORE_MODULES.length + OPERATION_MODULES.length" in home


def test_реклама_и_пакеты_остаются_рабочими_разделами() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    ads = read("frontend/src/pages/admin/ads.tsx")
    packages = read("frontend/src/features/admin/AdminSalePackagesPage.tsx")
    assert 'href: "/admin/ads"' in home
    assert 'href: "/admin/sale-packages"' in home
    assert 'label: "Пакеты"' in home
    assert 'label: "Рабочий раздел"' in ads
    assert "ADMIN_ADS_PROVIDERS_PATH" in ads
    assert "ADMIN_SALE_PACKAGES_PATH" in packages
    assert "ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH" in packages
    assert "ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH" in packages


def test_лаунчер_admin_использует_единые_svg_иконки() -> None:
    grid = read("frontend/src/components/admin/AdminAppButtonGrid.tsx")
    icon = read("frontend/src/components/admin/AdminModuleIcon.tsx")
    assert "AdminModuleIcon" in grid
    assert "efhc-admin-module-icon" in icon
    assert "ICONS:" not in grid
    assert "👤" not in grid
