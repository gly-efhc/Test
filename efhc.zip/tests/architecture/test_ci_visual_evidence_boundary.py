from __future__ import annotations

import json
from pathlib import Path

from tests import screenshot_companion_testkit

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_blocking_ci_excludes_png_evidence() -> None:
    workflow = read(".github/workflows/canon.yml")
    mirror = read("ci.yml")
    assert workflow == mirror
    assert "PYTHONPATH=backend pytest -q" in workflow
    assert "Chromium visual audit" in workflow
    assert "all_pages_route_backed_visual_audit.py" in workflow
    assert "exit_chromium_visual.txt" in workflow
    assert "visual_evidence_files=" in workflow
    assert "Screenshots.zip" not in workflow


def test_visual_evidence_has_explicit_local_target() -> None:
    makefile = read("Makefile")
    pytest_ini = read("pytest.ini")
    assert "visual-evidence:" in makefile
    assert "-m visual_evidence" in makefile
    assert "visual_evidence:" in pytest_ini


def test_regression_runner_accepts_marker_expression() -> None:
    runner = read("ops/ci_checks/run_full_regression_inventory.py")
    assert '"--marker-expression"' in runner
    assert 'command.extend(["-m", marker_expression])' in runner
    assert '"marker_expression": marker_expression' in runner


def test_companion_reader_skips_newer_archive_metadata(
    tmp_path: Path,
    monkeypatch,
) -> None:
    generated = tmp_path / "generated"
    generated.mkdir(parents=True)
    compatible = {
        "schema": "EFHC_SCREENSHOTS_COMPANION_MANIFEST_V1",
        "files": [
            {
                "path": "screenshots/proof.png",
                "size_bytes": 12345,
                "sha256": "a" * 64,
            }
        ],
    }
    metadata = {
        "schema": "EFHC_SCREENSHOTS_COMPANION_ARCHIVE_V1",
        "archive": "EFHC_Bot_v171_47_Screenshots.zip",
    }
    (generated / "screenshots_companion_manifest_v171_46.json").write_text(
        json.dumps(compatible),
        encoding="utf-8",
    )
    (generated / "screenshots_companion_manifest_v171_47.json").write_text(
        json.dumps(metadata),
        encoding="utf-8",
    )
    newest = {
        "schema": "EFHC_SCREENSHOTS_COMPANION_MANIFEST_V1",
        "files": [
            {
                "path": "screenshots/current.png",
                "size_bytes": 23456,
                "sha256": "b" * 64,
            }
        ],
    }
    (generated / "screenshots_companion_manifest_v171_50.json").write_text(
        json.dumps(newest),
        encoding="utf-8",
    )

    monkeypatch.setenv("EFHC_TEST_ARTIFACT_DIR", str(tmp_path))
    screenshot_companion_testkit._manifest_entries.cache_clear()
    try:
        assert screenshot_companion_testkit._manifest_entries() == {
            "screenshots/current.png": newest["files"][0],
            "screenshots/proof.png": compatible["files"][0],
        }
    finally:
        screenshot_companion_testkit._manifest_entries.cache_clear()
