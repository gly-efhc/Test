from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_tasks_referrals_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md",
        "docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1488_ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md",
        "reports/generated/admin_tasks_referrals_dashboard_upgrade_v170_64.json",
        "reports/change_cycle_2026-06-08_v170_64_cycle_1488_"
        "admin_tasks_referrals_dashboard_upgrade.md",
        "frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx",
        "tests/architecture/test_admin_tasks_referrals_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_tasks_referrals_boundaries() -> None:
    data = json.loads(
        read("reports/generated/admin_tasks_referrals_dashboard_upgrade_v170_64.json")
    )
    assert data["cycle"] == 1488
    assert data["archive_version"] == "v170.64"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_tasks_route_changed"] is True
    assert data["runtime_admin_referrals_route_changed"] is True
    assert data["new_backend_endpoint_added"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["db_migrations_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["ci_workflows_changed"] is False
    assert data["economy_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["dashboard_idempotency_key_created"] is False
    assert data["task_approve_reject_logic_changed"] is False
    assert data["referral_manual_bonus_logic_changed"] is False
    assert data["referral_reassign_logic_changed"] is False
    assert data["fake_time_series_added"] is False
    assert data["fake_referral_growth_added"] is False
    assert data["synthetic_admin_analytics_added"] is False
    assert data["real_time_series_claimed"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False
    assert data["vis_04_admin_tasks_active_inactive_labels_closed"] is True
    assert data["chat_docs_31_32_added"] is True


def test_admin_tasks_referrals_runtime_component_has_1488_markers() -> None:
    src = read("frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx")
    required = [
        "adminTasksReferralsDashboardRuntimeVersion",
        "EFHC_ADMIN_TASKS_REFERRALS_DASHBOARD_RUNTIME_V1",
        "AdminTasksDashboardRuntime",
        "AdminReferralsDashboardRuntime",
        'data-admin-tasks-dashboard-runtime="1488"',
        'data-admin-referrals-dashboard-runtime="1488"',
        'data-admin-tasks-referrals-dashboard-runtime="1488"',
        'data-admin-tasks-truth="raw-derived"',
        'data-admin-referrals-truth="raw-derived"',
        'data-admin-tasks-no-synthetic="true"',
        'data-admin-referrals-no-synthetic="true"',
        'data-admin-tasks-no-write-actions="true"',
        'data-admin-referrals-no-write-actions="true"',
        'data-admin-tasks-no-idempotency-key="true"',
        'data-admin-referrals-no-idempotency-key="true"',
        'data-admin-tasks-no-raw-payload="true"',
        'data-admin-referrals-no-raw-payload="true"',
        'data-admin-tasks-no-debug-json="true"',
        'data-admin-referrals-no-debug-json="true"',
        'data-admin-tasks-no-fake-timeseries="true"',
        'data-admin-referrals-no-fake-growth-timeseries="true"',
        'data-admin-tasks-vis04-closed="true"',
        'data-admin-referrals-vis04-closed="true"',
        "AdminDashboardToolbar",
        "AdminFreshnessBadge",
        "AdminRefreshPicker",
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminPanelChrome",
        "AdminMiniBarChart",
        "AdminProgressBar",
        "AdminHeatStrip",
        "AdminFlowMapCard",
        "AdminActionTable",
        "AdminStatusBadge",
    ]
    for marker in required:
        assert marker in src


def test_admin_tasks_referrals_runtime_component_is_read_only() -> None:
    src = read("frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "fetch(",
        '"POST"',
        '"PUT"',
        '"PATCH"',
        '"DELETE"',
        "newIdempotencyKey",
        "makeIdempotencyKey",
        "idempotencyKey:",
        "mutateAsync",
        "synthetic_preview",
        "raw payload dump",
        "debug JSON dump",
        "buildTrend",
        "setInterval",
        "manualBonus(",
        "reassign(",
        "moderateSubmission(",
        "runRefresh(",
    ]
    for marker in forbidden:
        assert marker not in src
    assert "derived snapshot only" in src
    assert "No fake" not in src


def test_admin_tasks_page_integrates_dashboard_without_moving_actions() -> None:
    page = read("frontend/src/pages/admin/tasks.tsx")
    component = read("frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx")
    assert "AdminTasksDashboardRuntime" in page
    assert "tasks={tasks}" in page
    assert "submissions={subs}" in page
    assert "traces={traceItems}" in page
    for marker in [
        "moderateSubmission",
        'adminApiRequest<AdminSubmissionItem>(',
        "makeIdempotencyKey",
        "runRefresh",
        'ADMIN_TASKS_REFRESH_STATUSES_PATH',
        "AdminTasksCatalogUxPanel",
        "AdminTasksExecutionTracePanel",
    ]:
        assert marker in page
        assert marker not in component


def test_admin_referrals_page_integrates_dashboard_without_moving_actions() -> None:
    page = read("frontend/src/pages/admin/referrals.tsx")
    component = read("frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx")
    assert "AdminReferralsDashboardRuntime" in page
    assert "items={items}" in page
    assert "selectedInviter={selectedInviter}" in page
    for marker in [
        "manualBonus",
        "ADMIN_REFERRAL_MANUAL_BONUS_PATH",
        "newIdk",
        "AdminPromptModal",
        "ADMIN_REFERRAL_REASSIGN_PATH",
        "reassignForm",
    ]:
        assert marker not in page
        assert marker not in component
    assert "ADMIN_REFERRAL_SUMMARY_PATH" in page


def test_vis_04_admin_tasks_active_inactive_labels_closed() -> None:
    catalog = read("frontend/src/components/admin/AdminTasksCatalogUxPanel.tsx")
    referrals = read("frontend/src/pages/admin/referrals.tsx")
    dashboard = read("frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx")
    visible_corpus = catalog + referrals + dashboard
    assert "Активно" in visible_corpus
    assert "Неактивно" in visible_corpus
    assert "Активные" in visible_corpus
    assert "Неактивные" in visible_corpus
    forbidden_visible = [
        '"active" : "inactive"',
        '? "active" : "inactive"',
        'label="active"',
        'label="inactive"',
    ]
    for marker in forbidden_visible:
        assert marker not in visible_corpus


def test_chat_docs_31_32_are_added_to_canonical_folder() -> None:
    for name, marker in {
        "31.md": "1447–1465",
        "32.md": "1466–1485",
    }.items():
        path = ROOT / "docs" / "NORM" / "CHATS" / name
        assert path.exists(), name
        assert marker in path.read_text(encoding="utf-8")
    index = read("docs/NORM/CHATS/CHATS_INDEX.md")
    readme = read("docs/NORM/CHATS/README.md")
    for name in ["31.md", "32.md"]:
        assert f"`{name}`" in index
        assert f"docs/NORM/CHATS/{name}" in index
        assert f"`{name}`" in readme


def test_admin_tasks_referrals_css_exists_and_mobile_safe() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1488 — Admin Tasks / Referrals Dashboard Upgrade",
        'data-admin-tasks-referrals-dashboard-runtime="1488"',
        ".efhc-admin-tasks-referrals-dashboard-runtime",
        ".efhc-admin-tasks-dashboard-runtime",
        ".efhc-admin-referrals-dashboard-runtime",
        'data-admin-tasks-dashboard-row="1488"',
        'data-admin-referrals-dashboard-row="1488"',
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
            read("docs/testing/TEST_GUARD_MANIFEST.md"),
        ]
    )
    assert "1488 — Admin Tasks / Referrals Dashboard Upgrade" in corpus
    assert "ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE" in corpus
    assert "AdminTasksReferralsDashboardRuntime.tsx" in corpus
    assert "1489 — Admin System Health Dashboard" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype" in docs
    assert "No Grafana source code" in docs
