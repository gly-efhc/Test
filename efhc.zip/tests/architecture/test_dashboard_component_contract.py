from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md"
TS = ROOT / "frontend/src/lib/dashboard/componentContract.ts"
REPORT = (
    ROOT / "reports/generated/dashboard_component_contract_v170_35.json"
)
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
PLAN = ROOT / "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
TOKENS = ROOT / "docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_dashboard_component_contract_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_DASHBOARD_COMPONENT_CONTRACT" in text
    assert "frontend/src/lib/dashboard/componentContract.ts" in text
    assert "Grafana is visual-pattern reference only" in text
    assert "Песочница is reference" in text
    assert "loading" in text
    assert "empty" in text
    assert "error" in text
    assert "stale" in text
    assert "success" in text


def test_dashboard_component_contract_types_exist() -> None:
    text = read(TS)
    assert "dashboardPanelStatuses" in text
    assert '"loading"' in text
    assert '"empty"' in text
    assert '"error"' in text
    assert '"stale"' in text
    assert '"success"' in text
    assert "DashboardComponentContract" in text
    assert "DashboardPanelSource" in text
    assert "DashboardPanelState" in text
    assert "dashboardContractVersion" in text


def test_dashboard_component_contract_data_kinds_are_explicit() -> None:
    text = read(TS)
    required = [
        '"raw"',
        '"derived"',
        '"synthetic_preview"',
        '"real_timeseries"',
    ]
    for marker in required:
        assert marker in text
    assert "synthetic?: boolean" in text
    assert "source: DashboardPanelSource" in text


def test_dashboard_component_contract_report_matches_cycle() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1459
    assert data["version"] == "v170.35"
    assert data["active_document"] == str(DOC.relative_to(ROOT))
    assert data["runtime_contract"] == str(TS.relative_to(ROOT))
    assert data["required_states"] == [
        "loading",
        "empty",
        "error",
        "stale",
        "success",
    ]
    assert data["boundaries"]["economy_changed"] is False
    assert data["boundaries"]["backend_contracts_changed"] is False
    assert data["boundaries"]["grafana_runtime_code_copied"] is False
    assert data["boundaries"]["sandbox_runtime_code_copied"] is False


def test_dashboard_contract_navigation_registered() -> None:
    assert "DASHBOARD_COMPONENT_CONTRACT.md" in read(KERNEL)
    assert "DASHBOARD_COMPONENT_CONTRACT.md" in read(MAP)
    assert "DASHBOARD_COMPONENT_CONTRACT.md" in read(PLAN)
    assert "DASHBOARD_COMPONENT_CONTRACT.md" in read(TOKENS)
    routes = read(ROUTES)
    assert "docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md" in routes
    assert "frontend/src/lib/dashboard/componentContract.ts" in routes
    assert "dashboard_component_contract_v170_35.json" in routes


def test_dashboard_component_contract_forbids_truth_drift() -> None:
    text = read(DOC)
    assert "Synthetic preview data must never be presented" in text
    assert "Money-changing actions must not be introduced" in text
    assert "must not show secrets" in text
    assert "must not invent financial returns" in text
    report_text = read(REPORT)
    assert "economy_changed" in report_text

def test_dashboard_panel_action_has_onclick() -> None:
    src = read(TS)
    assert "onClick?: () => void" in src


def test_dashboard_panel_action_has_action_kind() -> None:
    src = read(TS)
    assert "DashboardPanelActionKind" in src
    assert '"nav"' in src
    assert '"mutation-safe"' in src
    assert '"copy"' in src
    assert '"external"' in src


def test_dashboard_contract_version_v2() -> None:
    src = read(TS)
    assert "EFHC_DASHBOARD_CONTRACT_V2" in src
    assert "EFHC_DASHBOARD_CONTRACT_V1" not in src


def test_dashboard_action_rules_document_v2() -> None:
    text = read(DOC)
    assert "## Action kinds" in text
    assert "mutation-safe" in text
    assert "props.actions[].onClick" in text
    assert "EFHC_DASHBOARD_CONTRACT_V2" in text


def test_grafana_pattern_map_has_grid_layout() -> None:
    text = read(ROOT / "docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md")
    assert "## Grid layout" in text
    assert "AdminDashboardGrid" in text
    assert "SimDashboardGrid" in text
    assert "react-grid-layout" in text


def test_grafana_pattern_map_has_drilldown() -> None:
    text = read(ROOT / "docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md")
    assert "## Drill-down" in text
    assert "DashboardPanelAction" in text
    assert "actionKind: \"nav\"" in text
    assert "onClick" in text


def test_grafana_pattern_map_has_empty_error_states() -> None:
    text = read(ROOT / "docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md")
    assert "## Empty/error states" in text
    assert "AdminPanelEmpty" in text
    assert "AdminPanelError" in text
    assert "SimEmptyCard" in text
    assert "SimErrorCard" in text

