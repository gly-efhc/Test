from __future__ import annotations

from pathlib import Path

MIGRATION = Path("backend/migrations/versions/0001_initial_release_schema.py")


def _migration_text() -> str:
    return MIGRATION.read_text(encoding="utf-8")


def test_wallet_bindings_canonical_backfill_exists() -> None:
    text = _migration_text()
    assert "def _backfill_wallet_bindings_canonical" in text
    assert "canonicalize_ton_address" in text
    assert "wallet_bindings_canonical_backfill" in text


def test_wallet_bindings_backfill_runs_in_existing_repairs() -> None:
    text = _migration_text()
    repairs = text.split(
        "def _apply_existing_schema_repairs", 1
    )[1].split("def _to_regclass", 1)[0]
    assert "_backfill_wallet_bindings_canonical(conn)" in repairs


def test_wallet_bindings_backfill_updates_wallet_address() -> None:
    text = _migration_text()
    body = text.split("def _backfill_wallet_bindings_canonical", 1)[1]
    body = body.split("def _apply_existing_schema_repairs", 1)[0]
    assert "UPDATE efhc_core.wallet_bindings" in body
    assert "SET wallet_address=:addr" in body


def test_wallet_bindings_backfill_rejects_canonical_collisions() -> None:
    text = _migration_text()
    body = text.split("def _backfill_wallet_bindings_canonical", 1)[1]
    body = body.split("def _apply_existing_schema_repairs", 1)[0]
    assert "collisions" in body
    assert "RuntimeError" in body
    assert "canonical backfill collision" in body


def test_wallet_backfill_norm_doc_exists() -> None:
    text = Path(
        "docs/NORM/WALLET_BINDINGS_CANONICAL_BACKFILL.md"
    ).read_text(encoding="utf-8")
    assert "Existing databases" in text
    assert "_backfill_wallet_bindings_canonical(conn)" in text
    assert "wallet_bindings.wallet_address" in text
