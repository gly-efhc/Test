"""Причинные тесты provenance доказательств цикла 1601."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from ops.identity.audit_tg_id_usage import build_audit
from ops.identity.postgresql_environment_preflight import build_report
from ops.identity.render_identity_audit_russian import render


def _создать_минимальное_дерево(root: Path) -> None:
    source = root / "backend/app/models/sample.py"
    source.parent.mkdir(parents=True)
    source.write_text(
        "class Sample:\n    tg_id: int\n",
        encoding="utf-8",
    )


def test_raw_аудит_использует_переданный_head_и_цикл(
    tmp_path: Path,
) -> None:
    _создать_минимальное_дерево(tmp_path)
    output = tmp_path / "raw"

    summary = build_audit(
        tmp_path,
        output,
        source_head="EFHC_Bot_v171_98.zip",
        baseline_head="EFHC_Bot_v171_97.zip",
        cycle=1601,
    )

    persisted = json.loads(
        (output / "identity_audit_summary.json").read_text(
            encoding="utf-8"
        )
    )
    assert summary["source_head"] == "EFHC_Bot_v171_98.zip"
    assert summary["baseline_head"] == "EFHC_Bot_v171_97.zip"
    assert summary["cycle"] == 1601
    assert persisted == summary


def test_русский_аудит_не_подменяет_provenance(
    tmp_path: Path,
) -> None:
    _создать_минимальное_дерево(tmp_path)
    output = tmp_path / "ru"

    summary = render(
        tmp_path,
        output,
        source_head="EFHC_Bot_v171_98.zip",
        baseline_head="EFHC_Bot_v171_97.zip",
        cycle=1601,
    )

    assert summary["исходный_архив"] == "EFHC_Bot_v171_98.zip"
    assert summary["базовый_архив"] == "EFHC_Bot_v171_97.zip"
    assert summary["цикл"] == 1601


def test_postgresql_preflight_фиксирует_точный_head_и_цикл() -> None:
    report = build_report(
        cycle=1601,
        source_head="EFHC_Bot_v171_98.zip",
    )

    assert report["цикл"] == 1601
    assert report["исходный_архив"] == "EFHC_Bot_v171_98.zip"


@pytest.mark.parametrize(
    ("cycle", "source_head"),
    ((0, "EFHC_Bot_v171_98.zip"), (1601, "")),
)
def test_доказательства_provenance_отклоняют_невалидные_метаданные(
    tmp_path: Path,
    cycle: int,
    source_head: str,
) -> None:
    _создать_минимальное_дерево(tmp_path)

    with pytest.raises(ValueError):
        build_audit(
            tmp_path,
            tmp_path / "invalid",
            source_head=source_head,
            baseline_head="EFHC_Bot_v171_97.zip",
            cycle=cycle,
        )
