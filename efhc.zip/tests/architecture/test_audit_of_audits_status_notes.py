from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
AUDITS = ROOT / "docs/audits"


def test_high_impact_historical_audits_have_status_notes() -> None:
    targets = [
        "MVP_FINAL_RELEASE_GATE_AUDIT_2026_04_04.md",
        "TECHNICAL_AUDIT_V164_24_IMPORTED_AND_FIX_WAVE_2026_04_04.md",
        "FRONTEND_VISUAL_WHITE_SPOTS_AUDIT_2026_04_04.md",
        "FRONTEND_VISUAL_WHITE_SPOTS_CLOSURE_2026_04_04.md",
        "ROUTE_INVENTORY_FREEZE.md",
        "RUNTIME_DRIFT_INVENTORY.md",
    ]
    for name in targets:
        text = (AUDITS / name).read_text(encoding="utf-8")
        assert "Status note" in text or "Historical snapshot" in text


def test_audit_of_audits_exists() -> None:
    path = AUDITS / "AUDIT_OF_AUDITS_2026_04_04.md"
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert "Meta-audit of `docs/audits`" in text
