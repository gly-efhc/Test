from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REFERRALS = ROOT / "frontend/src/pages/referrals.tsx"
LOCALES = ROOT / "frontend/public/locale"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_referral_progress_and_levels_are_visible():
    text = read(REFERRALS)
    assert 'data-referrals-progress-levels="1297"' in text
    assert 'data-referrals-progress-bar="true"' in text
    assert 'data-referrals-achievements="visible"' in text
    assert 'data-referrals-current-lvl="true"' in text
    assert "Lvl {stats?.level ?? 0}" in text
    assert "stats?.refs_to_next" in text
    assert 'data-referrals-level-scale="lvl-1-5"' in text
    assert 'data-referral-level-step={step.level}' in text


def test_referral_bonus_wording_is_in_progress_not_each_row():
    text = read(REFERRALS)
    assert 'data-referral-bonus-wording="1298"' in text
    assert (
        'data-referral-bonus-map="direct-plus-level-cumulative"'
        in text
    )
    assert "referrals.bonus_rule_active" in text
    assert "referrals.direct_referral_rewards" in text
    assert "referrals.level_reward" in text
    assert "referrals.cumulative_level_rewards" in text
    assert "referrals.cumulative_reward" in text
    assert "referrals.full_cycle_total" in text
    assert "step.cumulative_level_bonus" in text
    assert "step.cumulative_total_reward" in text


def test_referral_bonus_locale_keys_exist_everywhere():
    required = [
        '"referrals.bonus_rule_title"',
        '"referrals.bonus_rule_active"',
        '"referrals.direct_referral_rewards"',
        '"referrals.level_reward"',
        '"referrals.cumulative_level_rewards"',
        '"referrals.cumulative_reward"',
        '"referrals.full_cycle_title"',
        '"referrals.full_cycle_direct"',
        '"referrals.full_cycle_levels"',
        '"referrals.full_cycle_total"',
    ]
    for path in LOCALES.glob("*.json"):
        text = read(path)
        for key in required:
            assert key in text, f"{path.name} missing {key}"
