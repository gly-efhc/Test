"""Контракт финальной financial shadow validation после squash."""

from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHECK = ROOT / "ops/identity/check_financial_shadow_validation.py"


def _load():
    spec = importlib.util.spec_from_file_location("financial_shadow", CHECK)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_financial_shadow_validation_проверяет_release_0001() -> None:
    result = _load().build()
    assert result["passed"], result
    assert result["alembic_head"] == "0001"
    assert result["single_release_migration"] is True


def test_financial_gate_сохраняет_нулевое_расхождение() -> None:
    gate = (
        ROOT / "ops/identity/postgresql_financial_shadow_validation_gate.py"
    ).read_text(encoding="utf-8")
    assert 'EXPECTED_REVISION: Final[str] = "0001"' in gate
    assert "monetary_discrepancy" in gate
    assert "idempotency_unchanged" in gate
