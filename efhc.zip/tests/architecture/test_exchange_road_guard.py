from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_exchange_road_guard_1189() -> None:
    script = ROOT / "ops/routes/check_exchange_road.py"
    result = subprocess.run(
        [sys.executable, str(script)],
        cwd=ROOT,
        check=False,
        text=True,
        capture_output=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(
        (ROOT / "reports/generated/exchange_road.json").read_text(
            encoding="utf-8"
        )
    )
    assert data["all_required_present"] is True
