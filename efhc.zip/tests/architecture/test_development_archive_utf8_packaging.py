import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BUILD_SH = ROOT / "ops" / "build_efhc_zip.sh"
BUILDER = ROOT / "ops" / "build_utf8_zip.py"


def test_сборщик_не_использует_info_zip_для_упаковки():
    text = BUILD_SH.read_text(encoding="utf-8")
    assert "zip -r" not in text
    assert "ops/build_utf8_zip.py" in text


def test_сборщик_ставит_utf8_флаг_имени(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    expected_name = "отчёт.txt"
    (source / expected_name).write_text(
        "данные",
        encoding="utf-8",
    )
    output = tmp_path / "result.zip"

    subprocess.run(
        [
            sys.executable,
            str(BUILDER),
            "--root",
            str(source),
            "--output",
            str(output),
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )

    with zipfile.ZipFile(output) as archive:
        info = archive.getinfo(expected_name)
        assert info.flag_bits & 0x800
        content = archive.read(expected_name).decode("utf-8")
        assert content == "данные"
        assert archive.testzip() is None
