from __future__ import annotations

from pathlib import Path

DOC = Path("docs/NORM/ADMIN_ORPHAN_ROUTE_STATUS.md")
SHOP_ROUTE = Path("backend/app/routes/admin_shop_routes.py")
TASKS_ROUTE = Path("backend/app/routes/admin_tasks_routes.py")


def test_admin_orphan_route_status_doc_exists() -> None:
    text = DOC.read_text(encoding="utf-8")
    assert "/admin/shop/items/set-price" in text
    assert "/admin/tasks/{task_id}" in text
    assert "LEGACY_INTERNAL_FINAL" in text


def test_shop_set_price_route_is_explicitly_internal_legacy() -> None:
    src = SHOP_ROUTE.read_text(encoding="utf-8")
    assert "/items/set-price" in src
    assert "ADMIN_ORPHAN_ROUTE_STATUS" in src
    assert "legacy/internal" in src.lower()


def test_tasks_single_get_route_is_explicitly_internal_legacy() -> None:
    src = TASKS_ROUTE.read_text(encoding="utf-8")
    assert '"/{task_id}"' in src or '"/{task_id}",' in src
    assert "ADMIN_ORPHAN_ROUTE_STATUS" in src
    assert "legacy/internal" in src.lower()
