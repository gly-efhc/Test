from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORTS = ROOT / "reports/generated"


def _load(name: str) -> dict:
    path = REPORTS / name
    assert path.is_file(), f"missing PostgreSQL proof report: {path}"
    return json.loads(path.read_text(encoding="utf-8"))


def test_postgres_release_proof_tool_is_semantic_and_fail_closed() -> (
    None
):
    script = ROOT / "ops/db/postgres_release_proof.py"
    text = script.read_text(encoding="utf-8")

    assert "sqlite" not in text.lower()
    assert "pg_dump" in text
    assert "pg_restore" in text
    assert "injected failure after balance and log writes" in text
    assert "source/restore catalog fingerprints differ" in text
    assert "temporary_dump_deleted" in text


def test_postgres_release_reports_are_verified_without_secret_leakage() -> (
    None
):
    migration = _load("postgresql_migration_v171_42.json")
    transaction = _load("postgresql_transaction_proof_v171_42.json")
    backup = _load("postgresql_backup_restore_v171_42.json")
    summary = _load("postgresql_runtime_summary_v171_42.json")

    assert migration["status"] == "VERIFIED"
    assert migration["migration"]["schemas"] == [
        "efhc_admin",
        "efhc_core",
    ]
    assert migration["migration"]["table_count"] == 45
    assert migration["migration"]["alembic_version"] == "0001"

    rollback = transaction["business_service_rollback"]
    assert rollback["status"] == "VERIFIED"
    assert all(rollback["checks"].values())
    assert rollback["observed"]["withdraw_request_count"] == 0
    assert rollback["observed"]["transfer_log_count"] == 0

    assert backup["status"] == "VERIFIED"
    assert backup["dump"]["temporary_dump_deleted"] is True
    assert backup["catalog"]["match"] is True
    assert backup["catalog"]["marker_restored"] is True
    assert backup["restored_database_rollback"]["status"] == "VERIFIED"

    assert summary["status"] == "VERIFIED"
    encoded = json.dumps(
        [migration, transaction, backup, summary],
        ensure_ascii=False,
    )
    assert "postgres:postgres" not in encoded
    assert "REAL_TONCONNECT_VERIFIED" not in encoded
