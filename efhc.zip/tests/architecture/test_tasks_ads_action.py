from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TASKS = ROOT / "frontend/src/pages/tasks.tsx"
TASKS_SERVICE = ROOT / "frontend/src/services/tasks.service.ts"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
MATRIX = ROOT / "docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md"
SCREEN = ROOT / "docs/frontend/FRONTEND_SCREEN_REGISTRY.md"
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_tasks_ads_action_has_direct_open_markers() -> None:
    src = read(TASKS)
    assert 'data-tasks-ads-action-boundary="1292"' in src
    assert 'adTask ? "watch-ad" : "claim-bonus"' in src
    assert 'adTask ? "ads-direct" : "claim-direct"' in src
    assert 'data-tasks-ad-modal="direct-open"' in src


def test_tasks_ads_button_has_no_extra_confirmation_gate() -> None:
    src = read(TASKS)
    assert "confirm(" not in src
    assert "watch_ad_confirm_title" not in src
    assert "watch_ad_confirm_detail" not in src


def test_tasks_ads_slot_does_not_leak_user_id_in_url() -> None:
    src = read(TASKS)
    service = read(TASKS_SERVICE)
    assert "/ads/slot?" in service
    assert "task_code" in service
    assert "builtin_timer" in service
    assert "&tg_id=" not in src
    assert "user_id=" not in src
    assert "tgId=" not in src
    assert "userId=" not in src


def test_tasks_ads_error_feedback_only_on_failure() -> None:
    src = read(TASKS)
    assert "setAdOpen(true)" in src
    assert 'ctx.toast(message, "error")' not in src
    assert "tasks.empty_detail" in src


def test_tasks_1292_docs_are_registered() -> None:
    docs = "\n".join(read(path) for path in [PLAN, MATRIX, SCREEN, REPORTS])
    assert "v168_90 / work pass" in docs
    assert "Ads task action" in docs
    assert "test_tasks_ads_action.py" in docs
    assert "watch ad button opens the ad flow immediately" in docs
