from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_energy_home_has_compact_contextual_bridge_action() -> None:
    page = _read("frontend/src/pages/index.tsx")
    summary = _read("frontend/src/components/energy/EnergyMvpSummary.tsx")
    assert 'data-first-screen-action-count="1"' in summary
    assert 'href: "/hub"' not in summary
    assert 'href: "/web-profile?section=wallet"' not in summary
    assert "energy.balance_chip" not in page
    assert "energy.available_kwh_chip" in page


def test_energy_action_count_stays_compact() -> None:
    summary = _read("frontend/src/components/energy/EnergyMvpSummary.tsx")
    assert summary.count('className="efhc-energy-action-card"') == 1


def test_internal_routes_do_not_pollute_openapi_ssot() -> None:
    routes = _read("docs/SSOT/ssot_pack/SSOT_ROUTES.csv")
    internal = _read("docs/SSOT/ssot_pack/SSOT_INTERNAL_ROUTES.csv")
    openapi = _read("backend/openapi/openapi.json")
    assert "/cron/tick" not in routes
    assert "/tg/webhook" not in routes
    assert "/cron/tick" in internal
    assert "/tg/webhook" in internal
    assert '"/cron/tick"' not in openapi
    assert '"/tg/webhook"' not in openapi
