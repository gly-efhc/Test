from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend/src"
ALLOWED_LOW_LEVEL = {ROOT / "frontend/src/lib/telegram.ts"}


def test_no_low_level_haptics_outside_telegram_lib() -> None:
    offenders: list[str] = []
    for path in FRONTEND.rglob("*.ts*"):
        if path in ALLOWED_LOW_LEVEL:
            continue
        text = path.read_text(encoding="utf-8")
        if "hapticImpact(" in text or "hapticNotify(" in text:
            offenders.append(str(path.relative_to(ROOT)))
    assert not offenders, f"low-level haptics used in: {offenders}"
