from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_layout_hides_public_bottom_nav_on_admin_routes() -> None:
    text = (ROOT / "frontend/src/components/Layout.tsx").read_text(
        encoding="utf-8"
    )
    assert 'router.pathname.startsWith("/admin")' in text
    assert "isAdminRoute" in text
    assert "shellBottomPadding" in text
    nav_pos = text.index("efhc-nav efhc-game-nav")
    guard_pos = text.rfind("!isAdminRoute", 0, nav_pos)
    assert (
        guard_pos >= 0
    ), "public bottom nav must be guarded by !isAdminRoute"
