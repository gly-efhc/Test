from __future__ import annotations

import ast
from pathlib import Path

ROUTES_DIR = Path("backend/app/routes")


def _iter_http_exception_detail_dicts() -> (
    list[tuple[str, int, list[str]]]
):
    rows: list[tuple[str, int, list[str]]] = []
    for path in sorted(ROUTES_DIR.glob("*_routes.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if (
                getattr(getattr(node, "func", None), "id", None)
                != "HTTPException"
            ):
                continue
            for kw in node.keywords:
                if kw.arg != "detail" or not isinstance(
                    kw.value, ast.Dict
                ):
                    continue
                keys: list[str] = []
                for key in kw.value.keys:
                    if isinstance(key, ast.Constant) and isinstance(
                        key.value, str
                    ):
                        keys.append(key.value)
                rows.append((str(path), node.lineno, keys))
    return rows


def test_http_exception_detail_dicts_use_canon_keys() -> None:
    bad: list[str] = []
    for path, lineno, keys in _iter_http_exception_detail_dicts():
        if set(keys) != {"error", "message", "details"}:
            bad.append(f"{path}:{lineno} keys={keys}")
    assert not bad, (
        "HTTPException(detail={...}) must use canon keys "
        "error/message/details.\n" + "\n".join(bad)
    )


def test__main__registers_http_exception_handlers() -> None:
    main_src = Path("backend/app/main.py").read_text(encoding="utf-8")
    errors_src = Path("backend/app/core/errors_core.py").read_text(
        encoding="utf-8"
    )
    assert "setup_exception_handlers(app)" in main_src
    assert (
        "app.add_exception_handler(HTTPException, "
        "http_exception_handler)"
    ) in errors_src
