from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_webapp_cannot_bind_or_rebind_referrals():
    app = read("frontend/src/pages/_app.tsx")
    service = read("frontend/src/services/referrals.service.ts")
    shell = read("frontend/src/services/appShell.service.ts")
    assert "bindReferralStartParam" not in app
    assert "bindReferralStartParam" not in service
    assert "bindReferralStartParam" not in shell
    assert '"/referrals/bind"' not in service
    assert '"/referrals/attach"' not in service


def test_referral_links_remain_bot_start_links():
    service = read("backend/app/services/referral_service.py")
    assert "?start=ref_" in service
    assert "startapp" not in service


def test_onboarding_tour_connected_as_ui_only():
    app = read("frontend/src/pages/_app.tsx")
    tour = read("frontend/src/components/OnboardingTour.tsx")
    assert "<OnboardingTour t={t} />" in app
    assert "onboarding_v1_seen" in tour
    assert "localStorage" in tour
    assert 'data-onboarding-tour="v1"' in tour
