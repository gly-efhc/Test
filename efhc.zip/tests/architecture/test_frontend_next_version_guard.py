from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "frontend" / "package.json"
LOCK = ROOT / "frontend" / "package-lock.json"
MIN_NEXT = "14.2.35"


def _norm(version: str) -> tuple[int, int, int]:
    raw = version.strip().lstrip("^~<>=v")
    main = raw.split("-")[0]
    a, b, c = main.split(".")[:3]
    return int(a), int(b), int(c)


def test_frontend_next_version_not_downgraded() -> None:
    pkg = json.loads(PACKAGE.read_text(encoding="utf-8"))
    ver = str(pkg["dependencies"]["next"])
    assert _norm(ver) >= _norm(MIN_NEXT), (
        "frontend next version is too old; "
        f"found {ver}, require >= {MIN_NEXT}"
    )


def test_frontend_next_lock_matches_package() -> None:
    pkg = json.loads(PACKAGE.read_text(encoding="utf-8"))
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    expected = str(pkg["dependencies"]["next"])
    pkg_ver = str(lock["packages"][""]["dependencies"]["next"])
    root_ver = str(lock["packages"]["node_modules/next"]["version"])
    assert pkg_ver == expected, (
        "package-lock root next dependency drift: "
        f"package.json={expected} lock={pkg_ver}"
    )
    assert _norm(root_ver) >= _norm(MIN_NEXT), (
        "installed next in lock is too old; "
        f"found {root_ver}, require >= {MIN_NEXT}"
    )
