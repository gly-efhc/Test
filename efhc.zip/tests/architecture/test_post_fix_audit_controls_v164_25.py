from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_database_url_asyncpg_is_postgres_only() -> None:
    text = (ROOT / "backend/app/core/config_core.py").read_text(
        encoding="utf-8"
    )
    assert "postgresql+asyncpg://" in text
    assert "DATABASE_URL must use PostgreSQL only" in text


def test__main__registers_routes_with_api_prefix() -> None:
    text = (ROOT / "backend/app/main.py").read_text(encoding="utf-8")
    assert re.search(
        r"register_routes\(app,\s*prefix\s*=\s*settings\.API_PREFIX\)",
        text,
    )


def test_withdraw_status_has_db_constraint() -> None:
    text = (ROOT / "backend/app/models/withdraw_models.py").read_text(
        encoding="utf-8"
    )
    assert "ck_withdraw_requests_status_enum" in text
    assert "PENDING','PAID','REJECTED','CANCELED" in text


def test_manual_vip_claim_is_not_compat_stub() -> None:
    path = ROOT / "backend/app/services/nft_requests_service.py"
    text = path.read_text(encoding="utf-8")
    assert '"mode": "compat_stub"' not in text
    assert "created_shop_order" in text


def test_user_routes_use_canonical_session_identity() -> None:
    text = (ROOT / "backend/app/routes/user_routes.py").read_text(
        encoding="utf-8"
    )
    assert "Depends(get_nonfinancial_read_owner)" in text
    assert 'req.headers.get("X-Telegram-User-Id")' not in text
    assert "X - Telegram - Id" not in text


def test_panel_price_is_frozen_to_100() -> None:
    text = (ROOT / "backend/app/services/panels_service.py").read_text(
        encoding="utf-8"
    )
    assert 'PANEL_PRICE: Decimal = d8("100")' in text
    assert 'getattr(settings, "PANEL_PRICE"' not in text
