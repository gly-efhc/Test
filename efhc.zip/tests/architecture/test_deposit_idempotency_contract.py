"""Постоянные инварианты идемпотентности EFHC deposit."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_проверка_deposit_idempotency_uses_admin_database_long_retention() -> None:
    content = _read("backend/app/services/efhc_deposits_service.py")
    assert 'DEPOSIT_IDEMPOTENCY_SCOPE = "deposit:efhc"' in content
    assert "IdempotencyKey" in content
    assert "pg_insert(IdempotencyKey)" in content
    assert 'DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"' in content
    assert "DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None" in content
    assert "expires_at=DEPOSIT_IDEMPOTENCY_EXPIRES_AT" in content
    assert "response_payload_json" in content
    assert "_read_deposit_idempotency_cache" in content
    assert "_store_deposit_idempotency_response" in content
    assert "idempotency_fingerprint_mismatch" in content
    assert "_ttl_seen" not in content


def test_проверка_deposit_credit_accepts_and_stores_metadata() -> None:
    service = _read("backend/app/services/efhc_deposits_service.py")
    transactions = _read("backend/app/services/transactions_service.py")
    assert "meta=meta" in service
    assert "meta: dict[str, Any] | None = None" in transactions
    assert "meta_user: dict[str, Any] = dict(meta or {})" in transactions


def test_проверка_monetary_runtime_has_no_ttl_seen_cache() -> None:
    for relative in (
        "backend/app/core/system_locks.py",
        "backend/app/services/efhc_deposits_service.py",
        "backend/app/services/transactions_service.py",
    ):
        assert "_ttl_seen" not in _read(relative)
