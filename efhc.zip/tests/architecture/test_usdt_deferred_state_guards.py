from pathlib import Path


def test_usdt_checkout_mode_is_live_tep74() -> None:
    src = Path(
        "backend/app/services/payment_intents_service.py"
    ).read_text(encoding="utf-8")
    assert 'return "tep74_live"' in src
    assert "USDT_DISABLED_UNTIL_REAL_JETTON_TRANSFER" not in src
    assert '"recipient_strategy": "owner_derived_wallet"' in src
    assert '"jetton_decimals": 6' in src


def test_hub_route_accepts_ton_and_usdt_for_browser_shop() -> None:
    src = Path("backend/app/routes/hub_routes.py").read_text(
        encoding="utf-8"
    )
    assert 'pay_method not in {"TON", "USDT"}' in src
    assert "USDT is disabled until real jetton transfer" not in src
    assert "usdt_enabled=" in src


def test_shop_service_catalog_exposes_usdt_when_priced() -> None:
    src = Path("backend/app/services/shop_service.py").read_text(
        encoding="utf-8"
    )
    assert "usdt_enabled = method_supported(it, PAY_USDT)" in src
    assert "usdt_disabled_until_real_jetton_transfer" not in src
