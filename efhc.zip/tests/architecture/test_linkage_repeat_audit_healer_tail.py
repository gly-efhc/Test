from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _load_repeat_module():
    path = ROOT / "ops/linkage/repeat_linkage_healer_audit.py"
    spec = importlib.util.spec_from_file_location("repeat_linkage_healer_audit", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_repeat_linkage_audit_reports_no_open_f001_to_f008_blockers():
    module = _load_repeat_module()
    report = module.build_report()
    assert report["status"] == "ok"
    assert report["blockers"] == []
    statuses = {item["id"]: item["repeat_audit_status"] for item in report["findings"]}
    assert set(statuses) == {f"F-{idx:03d}" for idx in range(1, 9)}
    assert statuses["F-006"] == "REPEAT_AUDIT_PASSED_LOCAL_STATIC_PENDING_LIVE_FASTAPI_PROOF"
    for finding_id, status in statuses.items():
        if finding_id != "F-006":
            assert status == "REPEAT_AUDIT_PASSED_LOCAL"


def test_repeat_linkage_audit_keeps_release_ready_false_without_external_proofs():
    module = _load_repeat_module()
    report = module.build_report()
    assert report["release_ready"] is False
    assert "GitHub CI" in report["release_ready_reason"]
    assert report["live_proof_pending"]


def test_healer_loader_accepts_current_atlas_and_casebook_schema_mix():
    from ops.healer.loader import load_atlas, load_casebook

    atlas_raw, cards = load_atlas(ROOT / "atlas.json")
    case_raw, cases = load_casebook(ROOT / "casebook.json")
    assert atlas_raw.get("version") or atlas_raw.get("atlas_version")
    assert case_raw.get("version") or case_raw.get("casebook_version")
    assert len(cards) >= 100
    assert len(cases) >= 100
    assert cards[0].heal_id.startswith("HEAL-")
    assert cases[0].case_id.startswith("CASE-")
    assert isinstance(cards[0].exceptions, list)
    assert isinstance(cases[0].verification_done, list)


def test_generated_repeat_audit_report_matches_current_cycle():
    module = _load_repeat_module()
    module.main()
    report_path = ROOT / "reports/generated/linkage_repeat_audit_healer_tail_v170_20.json"
    assert report_path.exists()
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["cycle"] == 1444
    assert report["version"] == "v170.20"
    assert report["status"] == "ok"
