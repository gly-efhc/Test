from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend/public/locale"
LANGS = [
    "en",
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]

REQUIRED_KEYS = {
    "ads.title",
    "ads.no_campaigns_title",
    "ads.no_campaigns_detail",
    "ads.open_tasks",
    "admin_guard.checking_title",
    "admin_guard.blocked_title",
    "admin_guard.checking_text",
    "admin_guard.blocked_text",
    "energy.gauge_title",
    "energy.total_label",
    "common.something_went_wrong",
    "common.unexpected_error",
    "common.reload",
    "common.image_placeholder",
    "common.close",
    "common.details",
    "common.efhc_balance_aria",
    "common.avatar_alt",
}


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_i18n_hardcoded_repair_keys_exist_in_all_locale_bundles() -> None:
    for lang in LANGS:
        data = json.loads((LOCALE_DIR / f"{lang}.json").read_text(encoding="utf-8"))
        missing = sorted(REQUIRED_KEYS - set(data))
        assert not missing, f"{lang} missing i18n hardcode repair keys: {missing}"


def test_ads_banner_no_hardcoded_user_text() -> None:
    content = _read("frontend/src/components/AdsBanner.tsx")
    forbidden = [
        "No active campaigns",
        "The ad slot remains available",
        "Open tasks",
        'title || "Ads"',
    ]
    for text in forbidden:
        assert text not in content
    assert 't("ads.title")' in content
    assert 't("ads.no_campaigns_title")' in content
    assert 't("ads.no_campaigns_detail")' in content
    assert 't("ads.open_tasks")' in content


def test_admin_route_guard_no_hardcoded_english() -> None:
    content = _read("frontend/src/pages/_app.tsx")
    forbidden = [
        "Checking Admin access",
        "Admin access is closed",
        "Please wait while EFHC checks the Telegram profile",
        "Safe return to the main screen is in progress.",
    ]
    for text in forbidden:
        assert text not in content
    assert 'props.t("admin_guard.checking_title")' in content
    assert 'props.t("admin_guard.blocked_title")' in content
    assert '<AdminRouteGuardState checking={adminRouteChecking} t={t} />' in content


def test_error_boundary_no_hardcoded_user_text() -> None:
    content = _read("frontend/src/components/ErrorBoundary.tsx")
    forbidden = [
        "Something went wrong",
        "Unexpected UI error",
        ">\n            Reload\n          </button>",
    ]
    for text in forbidden:
        assert text not in content
    assert 'translate("common.something_went_wrong")' in content
    assert 'translate("common.reload")' in content


def test_energy_gauge_no_hardcoded_public_labels() -> None:
    content = _read("frontend/src/components/EnergyGauge.tsx")
    assert 'title="Energy"' not in content
    assert "Total generated kWh" not in content
    assert 't("energy.gauge_title")' in content
    assert 't("energy.total_label")' in content


def test_surface_modal_and_product_card_no_hardcoded_fallbacks() -> None:
    surface = _read("frontend/src/components/ui/SurfaceFactsStrip.tsx")
    modal = _read("frontend/src/components/ui/Modal.tsx")
    card = _read("frontend/src/components/ui/telegram/TelegramProductCard.tsx")
    assert "Page overview" not in surface
    assert "aria-label=\"Close\"" not in modal
    assert "Image placeholder" not in card
    assert 'aria-label={t("common.close")}' in modal
    assert 't("common.image_placeholder")' in card
