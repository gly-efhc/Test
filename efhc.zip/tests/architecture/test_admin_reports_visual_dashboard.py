from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_reports_visual_component_exists() -> None:
    path = (
        ROOT
        / "frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx"
    )
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert 'data-admin-reports-visual-cycle="1343"' in text
    assert 'data-admin-reports-grafana-like="1482"' in text
    assert "chart-area-interactive" in text
    assert "section-cards" in text
    assert "data-table" in text
    assert "MaterialM EarningReports" in text


def test_reports_page_uses_visual_dashboard() -> None:
    text = read("frontend/src/pages/admin/reports.tsx")
    assert "AdminReportsVisualDashboardPanel" in text
    assert "AdminRouteHealthStrip" not in text
    assert "ADMIN_REPORTS_OVERVIEW_PATH" in text


def test_reports_visual_is_interactive() -> None:
    text = read(
        "frontend/src/components/admin/"
        "AdminReportsVisualDashboardPanel.tsx"
    )
    for marker in (
        "AdminFilterBar",
        "AdminDashboardToolbar",
        "AdminPanelChrome",
        "AdminPanelInspectorDrawer",
        "AdminAreaChart",
        "AdminMiniBarChart",
        "setScope",
        "setMode",
        "setSelectedPoint",
    ):
        assert marker in text


def test_reports_visual_is_not_fake_timeseries() -> None:
    text = read(
        "frontend/src/components/admin/"
        "AdminReportsVisualDashboardPanel.tsx"
    )
    assert "function buildTrend" not in text
    assert "setZoom" not in text
    assert "derived snapshot display" in text


def test_reports_cycle_docs_exist() -> None:
    assert (
        ROOT / "docs/admin/ADMIN_REPORTS_VISUAL_DASHBOARD.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/"
        / "FRONTEND_CYCLE_1343_ADMIN_REPORTS_VISUAL_AUDIT_V169_22.md"
    ).exists()
    assert (
        ROOT
        / "reports/"
        / "change_cycle_2026-05-30_v169_22_cycle_1343_"
        "admin_reports_visual_dashboard.md"
    ).exists()


def test_cycle_plan_shifted_to_1344() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert (
        "1343: Reports dashboard visual pass. DONE in v169_22." in text
    )
    assert "1344: Admin Reports export/download boundary" in text
