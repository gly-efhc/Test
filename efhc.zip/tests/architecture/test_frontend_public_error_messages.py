from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_withdraw_toast_uses_public_safe_message():
    src = read("frontend/src/pages/withdraw.tsx")
    assert "toast(e?.message || String(e)" not in src
    assert "publicApiErrorMessage(withdrawalsQ.error, t)" in src
    assert "publicApiErrorMessage(createWithdrawMutation.error, t)" in src
    assert "publicApiErrorMessage(cancelWithdrawMutation.error, t)" in src
    assert "toast(error" not in src
    assert "toast(message, \"error\")" not in src


def test_exchange_mutation_does_not_use_preview_error_copy():
    src = read("frontend/src/pages/exchange.tsx")
    failure = src.split("catch (error: unknown)", 1)[1]
    failure = failure.split("}", 1)[0]
    assert "preview_unavailable_detail" not in failure
    assert "exchange.exchange_failed" in failure
    assert "publicApiErrorMessage(" in failure
    assert '"exchange.exchange_failed"' in failure
