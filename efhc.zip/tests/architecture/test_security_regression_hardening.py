from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ROUTE_METHODS = "get|post|put|patch|delete|options"


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_every_admin_route_has_backend_require_admin() -> None:
    for path in sorted((ROOT / "backend/app/routes").glob("admin*.py")):
        source = path.read_text(encoding="utf-8")
        routes = re.findall(
            rf"^@(?:router|hub_router)\.({ROUTE_METHODS})\b",
            source,
            flags=re.MULTILINE,
        )
        if not routes:
            continue
        assert "from app.deps" in source and "require_admin" in source
        router_wide = "dependencies=[Depends(require_admin)]" in source
        per_route = source.count("Depends(require_admin)") >= len(
            routes
        )
        assert router_wide or per_route, path


def test_owner_scoped_money_routes_use_authenticated_owner() -> None:
    checked = {
        "backend/app/routes/payment_intents_routes.py": (
            "owner: FinancialReadOwner = Depends(get_financial_read_owner)",
            "global_id=owner.global_id",
        ),
        "backend/app/routes/deposit_routes.py": (
            "owner: FinancialReadOwner = Depends(get_financial_read_owner)",
            "require_wallet_connected",
            "current_global_id=int(owner.global_id)",
            "global_id=int(owner.global_id)",
        ),
        "backend/app/routes/withdraw_routes.py": (
            "owner: FinancialReadOwner = Depends(get_financial_read_owner)",
            "global_id=int(owner.global_id)",
        ),
        "backend/app/routes/wallets_routes.py": (
            "owner: FinancialReadOwner = Depends(get_financial_read_owner)",
            "global_id=owner.global_id",
            "current_tg_id: int = Depends(get_current_tg_id)",
            "tonconnect_proof_service.check_proof",
        ),
    }
    for rel, tokens in checked.items():
        source = read(rel)
        for token in tokens:
            assert token in source, f"{rel}: missing {token}"


def test_prod_docs_and_cors_are_fail_closed() -> None:
    main = read("backend/app/main.py")
    compat = read("backend/app/__init__.py")
    config = read("backend/app/core/config_core.py")
    prod_env = read("env.prod.example")

    assert "create_app()" in compat
    assert "from .main import app as main_app" in compat
    assert "return main_app" in compat

    assert (
        "openapi_url=getattr(settings, \"OPENAPI_URL\", None)"
        in main
    )
    assert "docs_url=getattr(settings, \"DOCS_URL\", None)" in main
    assert "redoc_url=getattr(settings, \"REDOC_URL\", None)" in main
    assert (
        'if "*" in uniq and settings.env_normalized == "prod"'
        in main
    )
    assert "CORS: '*' is forbidden in prod" in main

    assert 'DOCS_URL: str | None = Field(' in config
    assert "_empty_public_docs_url_to_none" in config
    assert "OPENAPI_URL=null" in prod_env
    assert "DOCS_URL=null" in prod_env
    assert "REDOC_URL=null" in prod_env


def test_telegram_webhook_dedupe_runs_after_secret_check() -> None:
    deps = read("backend/app/deps.py")
    system = read("backend/app/routes/system_routes.py")

    assert "register_external_event_after_secret" in deps
    assert "Secret-protected routes must call" in deps
    assert "external_event_dedupe_dep(\"telegram\")" not in system

    handler = system.split("async def telegram_webhook(", 1)[1]
    secret_pos = handler.index("hmac.compare_digest")
    dedupe_pos = handler.index("register_external_event_after_secret")
    assert secret_pos < dedupe_pos
    assert "Invalid telegram webhook secret" in handler[:dedupe_pos]


