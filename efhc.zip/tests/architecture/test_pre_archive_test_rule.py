from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

RULE = "Перед сборкой каждого архива обязателен прогон релевантного test/guard пакета"


def test_ai_docs_have_pre_archive_test_rule() -> None:
    for rel in [
        "docs/AI/AI_OPERATOR_RULES_EFHC.md",
        "docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md",
    ]:
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert RULE in text
