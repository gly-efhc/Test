from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ROUTES = ROOT / "backend/app/routes/skins_routes.py"
SCHEMAS = ROOT / "backend/app/schemas/skins_schemas.py"
SERVICE = ROOT / "backend/app/services/skins_service.py"
FRONT = ROOT / "frontend/src/services/skins.service.ts"
WORK = ROOT / "docs/cycles/WORK_CYCLES_0-100.md"


def test_switcher_routes_are_separate_from_legacy_buy_surface():
    text = ROUTES.read_text(encoding="utf-8")
    assert '"/switcher"' in text
    assert '"/switcher/activate/{skin_id}"' in text
    assert '"/buy/{skin_id}"' in text


def test_switcher__schema__uses_progress_shape_not_price_shape():
    text = SCHEMAS.read_text(encoding="utf-8")
    assert "class SkinSwitcherItem" in text
    assert "class SkinSwitcherOut" in text
    assert "available_skin_ids" in text
    assert "current_level" in text
    assert "is_unlocked" in text
    assert "is_active" in text


def test_service_syncs_active_skin_with_progression_canon():
    text = SERVICE.read_text(encoding="utf-8")
    assert "_available_skin_ids_for_level" in text
    assert "_sync_active_skin_id" in text
    assert "fallback_skin_id" in text
    assert "SKIN_NOT_UNLOCKED" in text
    assert "available_skin_ids" in text


def test_frontend_has_switcher_helper_surface():
    text = FRONT.read_text(encoding="utf-8")
    assert "getSkinSwitcher" in text
    assert "activateSwitcherSkin" in text
    assert "SkinSwitcherState" in text
    assert '"/skins/switcher"' in text
    assert '`/skins/switcher/activate/${skinId}`' in text


def test_cycle_92_marked_done():
    text = WORK.read_text(encoding="utf-8")
    assert "| 92 | done | Skin switcher implementation wave 1." in text
