from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

RUNTIME_DIRS = (
    ROOT / "backend/app/services",
    ROOT / "backend/app/routes",
    ROOT / "backend/app/crud",
)


def _texts() -> list[tuple[Path, str]]:
    out: list[tuple[Path, str]] = []
    for base in RUNTIME_DIRS:
        for path in base.rglob("*.py"):
            out.append((path, path.read_text(encoding="utf-8")))
    return out


def test_removed_wallet_models_file_has_canonical_replacement() -> None:
    removed = ROOT / "backend/app/models/wallet_models.py"
    replacement = ROOT / "backend/app/models/wallets_models.py"
    assert not removed.exists()
    assert replacement.exists()
    text = replacement.read_text(encoding="utf-8")
    assert "class WalletBinding" in text
    assert '__tablename__ = "wallet_bindings"' in text


def test_wallet_model_replacement_trace_doc_exists() -> None:
    doc = ROOT / "docs/NORM/WALLET_MODEL_REPLACEMENT_TRACE.md"
    text = doc.read_text(encoding="utf-8")
    assert "backend/app/models/wallets_models.py::WalletBinding" in text
    assert "canonicalize_ton_address" in text
    assert "wallets_service.py" in text
    assert "tonconnect_proof_service.py" in text


def test_runtime_imports_walletbinding_from_canonical_module() -> None:
    required = [
        ROOT / "backend/app/crud/wallets_crud.py",
        ROOT / "backend/app/services/efhc_deposits_service.py",
        ROOT / "backend/app/services/orders_service.py",
    ]
    for path in required:
        text = path.read_text(encoding="utf-8")
        assert "from app.models.wallets_models import WalletBinding" in text
        assert "app.models.wallet_models" not in text


def test_no_runtime_imports_removed_wallet_models_module() -> None:
    offenders = [
        str(path.relative_to(ROOT))
        for path, text in _texts()
        if "app.models.wallet_models" in text
    ]
    assert not offenders, offenders


def test_no_runtime_userwallet_alias_after_replacement() -> None:
    offenders = [
        str(path.relative_to(ROOT))
        for path, text in _texts()
        if "UserWallet" in text
    ]
    assert not offenders, offenders


def test_canonical_address_helper_is_active_replacement_piece() -> None:
    helper = ROOT / "backend/app/lib/ton_address.py"
    text = helper.read_text(encoding="utf-8")
    assert "def canonicalize_ton_address(address: str) -> str" in text
    assert "<workchain>:<64 lowercase hex account_id>" in text


def test_wallets_service_uses_canonical_address_helper() -> None:
    service = ROOT / "backend/app/services/wallets_service.py"
    text = service.read_text(encoding="utf-8")
    assert "canonicalize_ton_address" in text
    assert "normalize_wallet_address" in text


def test_kernel_and_map_link_replacement_trace() -> None:
    kernel = (ROOT / "KERNEL.md").read_text(encoding="utf-8")
    nav = (ROOT / "map_element.md").read_text(encoding="utf-8")
    combined = kernel + nav
    assert "WALLET_MODEL_REPLACEMENT_TRACE.md" in combined
    assert "WALLET_MODEL_REPLACEMENT_TRACE.md" in nav
    assert "wallets_models.py::WalletBinding" in combined
    assert "wallets_models.py::WalletBinding" in nav
