from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_outcome_service_has_telegram_short_delivery_path() -> None:
    text = _read("backend/app/services/outcome_service.py")
    assert "create_withdraw_outcome_web_profile_url" in text
    assert "build_withdraw_outcome_telegram_message" in text
    assert "Open your Web-Profile" in text
    assert "send_withdraw_outcome_telegram_notification" in text


def test_admin_withdrawals_trigger_telegram_delivery() -> None:
    text = _read(
        "backend/app/services/admin/admin_withdrawals_service.py"
    )
    assert (
        text.count("send_withdraw_outcome_telegram_notification") >= 2
    )


def test_auto_translation_stays_manual_override_only() -> None:
    text = _read("backend/app/services/outcome_service.py")
    assert "if clean_override:" in text
    assert "auto_translated=False" in text
    assert "manual_override_used=False" in text
