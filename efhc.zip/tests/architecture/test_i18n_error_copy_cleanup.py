from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALES = ROOT / "frontend" / "public" / "locale"
REQUIRED = [
    "common.screen_refresh_needed",
    "common.safe_recoverable_screen_detail",
    "common.service_temporarily_unavailable",
    "common.action_not_available_now",
    "common.try_later",
    "common.offline",
    "common.not_found",
    "common.route_not_found_title",
    "common.route_not_found_detail",
    "common.go_home",
    "admin.errors.action_failed",
    "admin.errors.load_failed",
    "admin.errors.data_unavailable_title",
    "admin.errors.data_unavailable_detail",
    "portal.shop_entry.open_failed_clean_detail",
]


def load(name: str) -> dict[str, str]:
    return json.loads((LOCALES / name).read_text(encoding="utf-8"))


def test_error_copy_keys_exist_in_all_active_locales() -> None:
    counts: dict[str, int] = {}
    for path in sorted(LOCALES.glob("*.json")):
        data = load(path.name)
        counts[path.name] = len(data)
        missing = [key for key in REQUIRED if key not in data]
        assert not missing, f"{path.name} missing {missing}"
    assert len(set(counts.values())) == 1
    assert min(counts.values()) >= 1548


def test_ru_uk_copy_no_longer_uses_noisy_default_error_or_rank_typos() -> None:
    ru = load("ru.json")
    uk = load("uk.json")
    assert ru["common.error"] == "Требует внимания"
    assert uk["common.error"] == "Потребує уваги"
    assert "рангиа" not in ru["ranks.load_error_detail"].lower()
    assert "рангиу" not in uk["ranks.load_error_detail"].lower()
    assert "Данные рейтинга" in ru["ranks.load_error_detail"]
    assert "Дані рейтингу" in uk["ranks.load_error_detail"]
