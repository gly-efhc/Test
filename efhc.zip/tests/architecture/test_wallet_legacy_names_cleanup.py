from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUNTIME_DIRS = [ROOT / "backend/app/services", ROOT / "backend/app/routes"]


def _runtime_texts() -> list[tuple[Path, str]]:
    out: list[tuple[Path, str]] = []
    for base in RUNTIME_DIRS:
        for path in base.rglob("*.py"):
            out.append((path, path.read_text(encoding="utf-8")))
    return out


def test_no_runtime_imports_userwallet_alias() -> None:
    offenders = [str(p) for p, t in _runtime_texts() if "UserWallet" in t]
    assert not offenders, offenders


def test_no_runtime_imports_app_models_wallet_models() -> None:
    offenders = [
        str(p)
        for p, t in _runtime_texts()
        if "app.models.wallet_models" in t
    ]
    assert not offenders, offenders


def test_walletbinding_is_only_runtime_wallet_binding_model() -> None:
    service = (ROOT / "backend/app/services/wallets_service.py").read_text(
        encoding="utf-8"
    )
    assert "WalletBinding" in service
    assert "UserWallet" not in service


def test_wallet_legacy_shim_removed_or_deprecated_not_runtime() -> None:
    shim = ROOT / "backend/app/models/wallet_models.py"
    assert not shim.exists()


def test_wallet_legacy_names_not_documented_as_active() -> None:
    docs = [
        ROOT / "docs/SSOT/WALLET_IDENTITY_SSOT.md",
        ROOT / "docs/NORM/WALLET_BINDING_CANON.md",
        ROOT / "docs/NORM/DB_DRIFT_MATRIX.md",
    ]
    for path in docs:
        text = path.read_text(encoding="utf-8")
        assert "UserWallet" not in text
        assert "wallet_models.py active" not in text


def test_kernel_uses_walletbinding_not_userwallet() -> None:
    text = (ROOT / "KERNEL.md").read_text(encoding="utf-8")
    assert "WalletBinding" in text
    assert "UserWallet" not in text


def test_map_element_uses_walletbinding_not_userwallet() -> None:
    text = (ROOT / "map_element.md").read_text(encoding="utf-8")
    assert "WalletBinding" in text
    assert "UserWallet" not in text
