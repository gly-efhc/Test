from __future__ import annotations

from decimal import Decimal

import pytest

sqlalchemy = pytest.importorskip("sqlalchemy")
text = sqlalchemy.text

pytestmark = pytest.mark.asyncio


async def _ensure_user(
    db_session,
    *,
    tg_id: int,
    main_balance: str = "0.00000000",
    bonus_balance: str = "0.00000000",
) -> None:
    await db_session.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, created_at, updated_at",
                    ") VALUES (",
                    "  :tg, NULL, FALSE, TRUE,",
                    "  :mb, :bb,",
                    "  0, now(), now()",
                    ")",
                    "ON CONFLICT (tg_id) DO UPDATE SET",
                    "  main_balance = excluded.main_balance,",
                    "  bonus_balance = excluded.bonus_balance,",
                    "  updated_at = now()",
                ]
            )
        ),
        {
            "tg": int(tg_id),
            "mb": str(main_balance),
            "bb": str(bonus_balance),
        },
    )


async def test_credit_from_bank_allows_deficit_but_no_double_credit(
    db_session,
) -> None:
    from app.services.transactions_service import credit_user_from_bank

    tg_id = 303001
    await _ensure_user(db_session, tg_id=tg_id)
    await db_session.commit()

    tx1 = await credit_user_from_bank(
        db_session,
        tg_id=tg_id,
        amount=Decimal("5.00000000"),
        reason="runtime_bank_deficit",
        idempotency_key="bank-deficit-1",
    )
    assert tx1.ok is True
    assert tx1.processed_with_deficit is True
    assert tx1.bank_main_balance == Decimal("-5.00000000")

    row = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id = :tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("5.00000000")
    assert Decimal(str(row[1])) == Decimal("0.00000000")

    bank_row = (
        await db_session.execute(
            text(
                "SELECT balance FROM efhc_core.bank_balance "
                "WHERE key = 'EFHC_MAIN'"
            )
        )
    ).first()
    assert bank_row is not None
    assert Decimal(str(bank_row[0])) == Decimal("-5.00000000")

    tx2 = await credit_user_from_bank(
        db_session,
        tg_id=tg_id,
        amount=Decimal("5.00000000"),
        reason="runtime_bank_deficit",
        idempotency_key="bank-deficit-1",
    )
    assert tx2.ok is True
    assert tx2.detail == "idempotent"

    row2 = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id = :tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row2 is not None
    assert Decimal(str(row2[0])) == Decimal("5.00000000")
    assert Decimal(str(row2[1])) == Decimal("0.00000000")

    log_count = int(
        (
            await db_session.execute(
                text(
                    "SELECT COUNT(*) FROM efhc_core.efhc_transfers_log "
                    "WHERE idempotency_key IN (:u, :m)"
                ),
                {
                    "u": "bank-deficit-1",
                    "m": "mirror:bank-deficit-1",
                },
            )
        ).scalar()
        or 0
    )
    assert log_count == 2


async def test_user_never_goes_negative_even_when_bank_can(
    db_session,
) -> None:
    from app.services.transactions_service import debit_user_to_bank

    tg_id = 303002
    await _ensure_user(
        db_session,
        tg_id=tg_id,
        main_balance="0.00000000",
        bonus_balance="9.00000000",
    )
    await db_session.commit()

    with pytest.raises(ValueError):
        await debit_user_to_bank(
            db_session,
            tg_id=tg_id,
            amount=Decimal("1.00000000"),
            reason="runtime_main_only",
            idempotency_key="bank-main-only-1",
        )

    row = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id = :tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("0.00000000")
    assert Decimal(str(row[1])) == Decimal("9.00000000")
