from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COMPONENT = ROOT / (
    "frontend/src/components/admin/AdminUiKitAdoptionProofPanel.tsx"
)
ADMIN_HOME = ROOT / "frontend/src/pages/admin/index.tsx"
DOC = ROOT / "docs/admin/ADMIN_UI_KIT_ADOPTION_PROOF_PASS.md"
AUDIT = (
    ROOT
    / "docs/audits"
    / (
        "FRONTEND_CYCLE_1353_ADMIN_UI_KIT_ADOPTION_PROOF_AUDIT_V169_"
        "32.md"
    )
)
REPORT = (
    ROOT
    / "reports"
    / (
        "change_cycle_2026-05-31_v169_32_cycle_1353_"
        "admin_ui_kit_adoption_proof.md"
    )
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_cycle_1353_documents_exist() -> None:
    for path in (COMPONENT, DOC, AUDIT, REPORT):
        assert path.exists(), str(path)


def test_admin_home_does_not_render_internal_adoption_proof() -> None:
    text = read(ADMIN_HOME)
    assert "AdminUiKitAdoptionProofPanel" not in text
    assert "Релизный центр управления" in text


def test_proof_panel_uses_shared_admin_ui_kit() -> None:
    text = read(COMPONENT)
    required = [
        "AdminSectionHeader",
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminChartCard",
        "AdminFlowMapCard",
        "AdminActionTable",
        "AdminStatusBadge",
    ]
    for marker in required:
        assert marker in text


def test_proof_panel_covers_real_admin_surfaces() -> None:
    text = read(COMPONENT)
    for marker in (
        "Bank / Users",
        "Withdrawals",
        "Shop / Web3",
        "Tasks",
        "Reports",
        "Diagnostics",
    ):
        assert marker in text


def test_sandbox_is_documented_but_runtime_not_copied() -> None:
    text = read(COMPONENT) + read(DOC)
    assert "data-admin-sandbox-source" in text
    assert "ui-main" in text
    assert "Telegram Mini App" in text
    forbidden = ("from 'vue'", "from 'solid-js'", "nuxt", "jquery")
    lowered = read(COMPONENT).lower()
    for marker in forbidden:
        assert marker not in lowered


def test_cycle_1353_boundaries_are_documented() -> None:
    text = read(DOC)
    assert "change EFHC economics" in text
    assert "change `ci.yml`" in text
    assert "Admin internals to public UI" in text
