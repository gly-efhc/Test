from __future__ import annotations

import json
from pathlib import Path

LANGS = [
    "ru",
    "uk",
    "en",
    "de",
    "fr",
    "es",
    "it",
    "pl",
    "tr",
    "da",
    "hi",
    "id",
    "sw",
]

FORBIDDEN_EFHC_HANDOFF_WORDS = [
    "товар",
    "product",
    "sku",
    "package",
    "vip nft",
    "купить",
    "buy",
    "purchase",
    "checkout",
]


def test_hub_efhc_handoff_is_neutral_in_locales() -> None:
    for lang in LANGS:
        p = Path(f"frontend/public/locale/{lang}.json")
        data = json.loads(p.read_text(encoding="utf-8"))
        title = str(data["hub.card_efhc_title"])
        desc = str(data["hub.card_efhc_description"])
        action = str(data["hub.card_efhc_action"])

        assert title.strip(), f"Missing title in {lang}"
        assert desc.strip(), f"Missing description in {lang}"
        assert action.strip(), f"Missing action in {lang}"

        combined = (title + " " + desc + " " + action).lower()
        for bad in FORBIDDEN_EFHC_HANDOFF_WORDS:
            assert (
                bad not in combined
            ), f"Forbidden product wording '{bad}' in {lang}"


def test_hub_efhc_handoff_ru_is_balance_topup() -> None:
    p = Path("frontend/public/locale/ru.json")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["hub.card_efhc_title"] == "Пополнить баланс"
    assert data["hub.card_efhc_action"] == "Открыть"
