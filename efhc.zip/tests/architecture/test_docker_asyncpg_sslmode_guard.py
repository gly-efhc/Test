from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_asyncpg_engine_strips_psycopg_sslmode() -> None:
    text = read("backend/app/core/database_core.py")

    assert "_normalise_asyncpg_connect" in text
    assert 'key.lower() == "sslmode"' in text
    assert 'connect_args["ssl"] = True' in text
    assert "connect_args=connect_args" in text


def test_docker_local_async_url_has_no_sslmode_disable() -> None:
    compose = read("docker-compose.yml")
    ops_compose = read("ops/docker/docker-compose.yml")
    docker_env = read("env.docker.example")

    local_async = "postgresql+asyncpg://postgres:postgres@db:5432/efhc"
    assert local_async in compose
    assert local_async in ops_compose
    psycopg_local = (
        "postgresql://postgres:postgres@db:5432/efhc?sslmode=disable"
    )
    assert "PSYCOPG_URL" in compose
    assert psycopg_local in compose
    assert psycopg_local in ops_compose
    assert psycopg_local in docker_env
