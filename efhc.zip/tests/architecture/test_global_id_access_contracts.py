from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_global_id_является_каноническим_business_owner() -> None:
    contract = (
        ROOT / "contracts/identity/global_owner_tg_id_boundary_v1.json"
    ).read_text(encoding="utf-8")
    assert "global_id" in contract
    assert "global_owner_alias.py" in contract


def test_alias_блокирует_неоднозначный_owner_selector() -> None:
    text = (
        ROOT / "backend/app/identity/global_owner_alias.py"
    ).read_text(encoding="utf-8")
    assert "Нельзя одновременно передавать" in text
    assert "global_id" in text
    assert "tg_id" in text
    assert "telegram_provider_id" not in text
    assert "tg_provider_id" not in text
