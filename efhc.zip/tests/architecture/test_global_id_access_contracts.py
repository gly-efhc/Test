from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_global_id_является_каноническим_business_owner() -> None:
    contract = json.loads(
        (
            ROOT
            / "contracts/identity/global_owner_tg_id_boundary_v1.json"
        ).read_text(encoding="utf-8")
    )
    assert contract["canonical_business_owner"] == "global_id"
    assert contract["temporary_alias_removed"] is True


def test_runtime_alias_global_owner_удалён() -> None:
    alias = ROOT / "backend/app/identity/global_owner_alias.py"
    assert not alias.exists()
    runtime = "\n".join(
        path.read_text(encoding="utf-8", errors="ignore")
        for path in (ROOT / "backend/app").rglob("*.py")
    )
    assert "accept_legacy_owner_alias" not in runtime
