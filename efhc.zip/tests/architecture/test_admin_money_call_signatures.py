from __future__ import annotations

import ast
from pathlib import Path

MONEY_FUNCTIONS = {
    "credit_user_from_bank",
    "credit_user_bonus_from_bank",
    "debit_user_to_bank",
    "debit_user_bonus_to_bank",
}

TX_FILE = Path("backend/app/services/transactions_service.py")
SEARCH_FILES = [
    *Path("backend/app/services/admin").glob("*.py"),
    *Path("backend/app/routes").glob("admin*.py"),
    TX_FILE,
]


def _call_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _signature_kwargs() -> dict[str, tuple[set[str], bool]]:
    tree = ast.parse(TX_FILE.read_text(encoding="utf-8"))
    signatures: dict[str, tuple[set[str], bool]] = {}
    for node in tree.body:
        if not isinstance(node, ast.AsyncFunctionDef):
            continue
        if node.name not in MONEY_FUNCTIONS:
            continue
        names = {arg.arg for arg in node.args.args}
        names.update(arg.arg for arg in node.args.kwonlyargs)
        has_var_kw = node.args.kwarg is not None
        signatures[node.name] = (names, has_var_kw)
    return signatures


def test_admin_money_call_sites_match_function_signatures() -> None:
    signatures = _signature_kwargs()
    missing = sorted(MONEY_FUNCTIONS - set(signatures))
    assert not missing, f"Missing money functions: {missing}"

    violations: list[str] = []
    for path in SEARCH_FILES:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _call_name(node.func)
            if name not in signatures:
                continue
            allowed, has_var_kw = signatures[name]
            if has_var_kw:
                continue
            for kw in node.keywords:
                if kw.arg is None:
                    violations.append(
                        f"{path}:{node.lineno} {name} uses **kwargs; "
                        "explicit keywords required for admin money "
                        "path"
                    )
                elif kw.arg not in allowed:
                    violations.append(
                        f"{path}:{node.lineno} {name} unexpected "
                        f"keyword {kw.arg!r}; allowed={sorted(allowed)}"
                    )
    assert not violations, "\n".join(violations)
