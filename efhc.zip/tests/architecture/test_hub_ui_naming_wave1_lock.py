from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_global_header_uses_hub_label() -> None:
    text = (
        ROOT / "frontend" / "src" / "components" / "GlobalHeader.tsx"
    ).read_text(encoding="utf-8")
    assert 'aria-label="Hub"' in text
    assert "<span>HUB</span>" in text
    assert 'aria-label="Shop"' not in text


def test_faq_meta_section_13_uses_hub() -> None:
    text = (
        ROOT / "frontend" / "src" / "data" / "faq" / "meta.ts"
    ).read_text(encoding="utf-8")
    assert '"13": "Hub"' in text
    assert '"13.1": "Hub"' in text
    assert '"13": "Shop"' not in text
    assert '"13.1": "Shop"' not in text
    assert '"13": "Магазин"' not in text
    assert '"13.1": "Магазин"' not in text


def test_locale_nav_and_title_use_hub() -> None:
    locale_dir = ROOT / "frontend" / "public" / "locale"
    for path in locale_dir.glob("*.json"):
        text = path.read_text(encoding="utf-8")
        assert '"nav.hub": "Hub"' in text
        assert '"hub.title": "Hub"' in text
        assert '"nav.shop": "Hub"' not in text
        assert '"shop.title": "Hub"' not in text
