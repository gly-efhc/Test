from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LANGS = [
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_responsive_rules_cover_phone_and_tablet_widths() -> None:
    css = read("frontend/src/styles/globals.css")
    for token in (
        'data-public-surface="web-profile"',
        'data-public-surface="faq"',
        "@media (max-width: 430px)",
        "@media (max-width: 360px)",
        "@media (min-width: 700px)",
        "overflow-wrap: anywhere;",
    ):
        assert token in css


def test_all_13_locales_have_profile_history_faq_keys() -> None:
    required = [
        "profile.page_title",
        "profile.section_profile_tab",
        "profile.section_wallet_tab",
        "profile.section_history_tab",
        "profile.language",
        "history.filter_all",
        "history.filter_withdraw",
        "faq.title",
        "faq.open_full",
    ]
    root = ROOT / "frontend/public/locale"
    assert sorted(p.stem for p in root.glob("*.json")) == sorted(LANGS)
    for lang in LANGS:
        data = json.loads(
            (root / f"{lang}.json").read_text(encoding="utf-8")
        )
        for key in required:
            assert key in data, f"{lang} missing {key}"
