from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task


def test_operator_kernel_classifies_core_tasks():
    ci = classify_task("repair logs_123 pytest freezegun")
    ci_ru = classify_task(
        "Исправь все ошибки по логам development и release архивов"
    )
    admin = classify_task("admin dashboard ui kit operator")
    shop = classify_task("shop payment web3 separation")
    assert ci["task_type"] == "ci_logs_repair_or_verification"
    assert ci_ru["task_type"] == "ci_logs_repair_or_verification"
    assert admin["task_type"] == "admin_ui_recovery"
    assert shop["task_type"] == "shop_payment_repair"


def test_operator_kernel_resolves_shop_route():
    route = resolve_route("shop_payment_repair")
    docs = "\n".join(route["docs"])
    globs = "\n".join(route["code_globs"])
    assert "SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT" in docs
    assert "BROWSER_SHOP_PAYMENT_FLOW_NORM" in docs
    assert "*shop*.py" in globs
