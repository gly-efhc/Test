from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_alembic_does_not_force_ssl_for_docker_local_db() -> None:
    text = read("backend/migrations/env.py")

    assert '"db", "postgres"' in text
    assert '"local", "dev", "development"' in text
    assert '"ci", "test"' in text
    assert "_host not in _local_hosts" in text
    assert "sslmode=require" in text


def test_docker_psycopg_url_disables_ssl_explicitly() -> None:
    compose = read("docker-compose.yml")
    ops_compose = read("ops/docker/docker-compose.yml")
    docker_env = read("env.docker.example")

    psycopg_local = (
        "postgresql://postgres:postgres@db:5432/efhc?sslmode=disable"
    )
    assert "PSYCOPG_URL" in compose
    assert psycopg_local in compose
    assert psycopg_local in ops_compose
    assert psycopg_local in docker_env


def test_async_database_url_stays_clean_for_asyncpg() -> None:
    compose = read("docker-compose.yml")
    async_local = "postgresql+asyncpg://postgres:postgres@db:5432/efhc"
    assert async_local in compose
    assert async_local + "?sslmode=disable" not in compose
