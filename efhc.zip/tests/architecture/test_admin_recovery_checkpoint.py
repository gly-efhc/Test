from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_admin_recovery_checkpoint_documents_exist() -> None:
    for rel in (
        "docs/admin/ADMIN_RECOVERY_CHECKPOINT.md",
        "docs/audits/ADMIN_RECOVERY_CHECKPOINT_AUDIT_V169_36.md",
        (
            "reports/change_cycle_2026-06-01_v169_36_cycle_1357_admin_"
            "recovery_checkpoint_sandbox_map.md"
        ),
        "reports/generated/admin_recovery_checkpoint_v169_36.json",
        "map_element.md",
    ):
        assert (ROOT / rel).exists(), rel


def test_cycle_and_ai_indexes_keep_admin_recovery_history() -> None:
    cycles = read("docs/cycles/WORK_CYCLES.md")
    ai = read("docs/AI/AI_DOCS_INDEX.md")
    assert "1357: Admin recovery checkpoint" in cycles
    assert "ADMIN_RECOVERY_CHECKPOINT.md" in ai
    assert "map_element.md" in ai
    assert "Active range: `1351-1375`" in cycles


def test_generated_checkpoint_json_matches_documents() -> None:
    data = json.loads(
        read("reports/generated/admin_recovery_checkpoint_v169_36.json")
    )
    assert data["version"] == "v169_36"
    assert data["cycle"] == 1357
    assert data["runtime_code_changed"] is False
    assert data["ci_changed_intentionally"] is False
    assert "Песочница.xz" in data["sandbox_sources"]
    assert "vuejs-template-master.zip" in data["sandbox_sources"]
