from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALES = [
    "ru",
    "uk",
    "en",
    "de",
    "fr",
    "es",
    "it",
    "pl",
    "tr",
    "da",
    "hi",
    "id",
    "sw",
]
FORBIDDEN = (
    "активац",
    "activate",
    "activation",
    "buy",
    "купить",
    "purchase",
    "checkout",
    "in-app",
    "in app",
)


def _load(lang: str) -> dict[str, str]:
    path = ROOT / "frontend" / "public" / "locale" / f"{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def test_hub_vip_card_stays_external_collection_wording() -> None:
    ru = _load("ru")
    assert ru["hub.card_vip_title"] == "Открыть VIP коллекцию"
    assert ru["hub.card_vip_action"] == "Открыть коллекцию"
    desc = ru["hub.card_vip_description"].lower()
    assert "внешняя" in desc
    assert "проверяет" in desc
    assert "статус" in desc


def test_hub_vip_card_avoids_in_app_sale_wording() -> None:
    for lang in LOCALES:
        data = _load(lang)
        text = " ".join(
            [
                data["hub.card_vip_title"],
                data["hub.card_vip_description"],
                data["hub.card_vip_action"],
            ]
        ).lower()
        for token in FORBIDDEN:
            assert token not in text, (lang, token, text)


def test_hub_page_exposes_canonical_vip_getgems_action() -> None:
    path = (
        ROOT / "frontend" / "src" / "features" / "hub" / "HubPage.tsx"
    )
    text = path.read_text(encoding="utf-8")
    assert 'data-hub-visible-action-count="2"' in text
    assert "action_vip_nft" in text
    assert "getgems.io/efhc-nft" in text
