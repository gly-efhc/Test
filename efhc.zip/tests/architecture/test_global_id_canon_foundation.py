"""Архитектурная приёмка канона Global ID цикла 1602."""

from __future__ import annotations

from pathlib import Path

from ops.identity.check_global_id_canon import (
    найти_новые_legacy_контракты,
    найти_смешение_provider_global_id,
    проверить,
)

ROOT = Path(__file__).resolve().parents[2]


def test_exact_head_соблюдает_канон_global_id() -> None:
    result = проверить(ROOT)
    assert result["пройдено"], result["нарушения"]
    assert result["физический_global_id"] is True
    assert result["historical_backfill"] is True
    assert result["переключение_чтения"] is True
    assert result["переключение_финансового_владения"] is True


def test_guard_отклоняет_присваивание_tg_id_в_global_id(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "backend/app/services/bad.py"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "def bad(tg_id):\n"
        "    global_id = int(tg_id)\n"
        "    return global_id\n",
        encoding="utf-8",
    )
    findings = найти_смешение_provider_global_id(tmp_path)
    assert findings
    assert findings[0]["причина"] in {
        "provider_to_global_assignment",
        "provider_to_global_ast_assignment",
    }


def test_guard_отклоняет_wallet_как_global_id_frontend(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "frontend/src/bad.ts"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "const globalId = walletAddress;\n",
        encoding="utf-8",
    )
    findings = найти_смешение_provider_global_id(tmp_path)
    assert findings


def test_цикл_1602_имеет_маршрут_operator_kernel() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    classified = classify_task("Цикл 1602 канонизация Global ID")
    assert classified["task_type"] == "global_id_canonicalization"
    route = resolve_route("global_id_canonicalization", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_identity_аудит_направляет_owner_на_global_id(
    tmp_path: Path,
) -> None:
    from ops.identity.audit_tg_id_usage import build_audit

    source = tmp_path / "backend/app/models/sample.py"
    source.parent.mkdir(parents=True)
    source.write_text(
        "class Sample:\n    tg_id: int\n",
        encoding="utf-8",
    )
    output = tmp_path / "audit"
    summary = build_audit(
        tmp_path,
        output,
        source_head="EFHC_Bot_v171_99.zip",
        baseline_head="EFHC_Bot_v171_98.zip",
        cycle=1602,
    )
    import json

    rows = json.loads(
        (output / "identity_usage_matrix.json").read_text(
            encoding="utf-8"
        )
    )
    assert summary["schema"] == "EFHC_GLOBAL_IDENTITY_AUDIT_V3"
    assert rows
    assert {row["target_field"] for row in rows} == {"global_id"}
    assert {row["decision"] for row in rows} == {
        "MIGRATE_TO_GLOBAL_ID"
    }


def test_guard_отклоняет_local_pk_как_global_id(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "backend/app/services/bad_local_pk.py"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "def bad(user):\n    global_id = user.id\n    return global_id\n",
        encoding="utf-8",
    )
    findings = найти_смешение_provider_global_id(tmp_path)
    assert findings


def test_guard_отклоняет_новый_dto_user_id(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "backend/app/schemas/bad.py"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "class Bad:\n    user_id: int\n",
        encoding="utf-8",
    )
    findings = найти_новые_legacy_контракты(tmp_path)
    assert findings[0]["причина"] == (
        "new_undefined_user_id_dto_or_field"
    )


def test_guard_отклоняет_fk_на_локальный_users_id(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "backend/app/models/bad.py"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        'owner_id = ForeignKey("users.id")\n',
        encoding="utf-8",
    )
    findings = найти_новые_legacy_контракты(tmp_path)
    assert findings[0]["причина"] == "new_fk_to_local_users_id"
