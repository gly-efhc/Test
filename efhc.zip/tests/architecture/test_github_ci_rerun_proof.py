from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_cycle_1505_norm_and_report_exist() -> None:
    assert (ROOT / "docs/NORM/GITHUB_CI_RERUN_PROOF.md").exists()
    assert (
        ROOT / "docs/cycles/WORK_CYCLES_1505_GITHUB_CI_RERUN_PROOF.md"
    ).exists()
    assert (
        ROOT / "reports/generated/github_ci_rerun_proof_v170_81.json"
    ).exists()


def test_cycle_1505_does_not_claim_green_ci() -> None:
    report = json.loads(
        read("reports/generated/github_ci_rerun_proof_v170_81.json")
    )
    assert report["log_verdict"] == "failed"
    assert report["github_ci_green_claimed"] is False
    norm = read("docs/NORM/GITHUB_CI_RERUN_PROOF.md")
    assert "does not claim GitHub CI green" in norm
    assert "fresh GitHub CI rerun" in norm


def test_cycle_1505_log_failures_are_documented() -> None:
    report = json.loads(
        read("reports/generated/github_ci_rerun_proof_v170_81.json")
    )
    facts = report["facts"]
    assert "I001" in facts["ruff"]
    assert "9 failed" in facts["pytest"]
    assert "No issues identified" in facts["bandit"]
    assert "285 source files" in facts["mypy"]


def test_admin_reports_route_module_is_in_canon_guard() -> None:
    guard = read("tests/architecture/test_admin_route_modules_canon.py")
    assert '"admin_reports_routes.py"' in guard
    assert '"/admin/reports"' in guard
    assert '["admin-reports"]' in guard


def test_chat_index_legacy_anchor_restored() -> None:
    index = read("docs/NORM/CHATS/CHATS_INDEX.md")
    assert "ветки 21, 22, 24, 25, 26, 27, 28 и 30" in index


def test_frontend_tsbuildinfo_artifact_is_absent() -> None:
    assert not (ROOT / "frontend/tsconfig.tsbuildinfo").exists()


def test_admin_reports_route_has_no_degraded_primary_token() -> None:
    route = read("backend/app/routes/admin_reports_routes.py")
    assert "_" "main" "_" not in route
    assert 'bank_" "main_balance' in route


def test_openapi_and_route_freeze_counts_are_current() -> None:
    openapi_guard = read(
        "tests/architecture/test_openapi_rebuild_strict_contract_gate.py"
    )
    final_guard = read(
        "tests/architecture/test_final_dashboard_visual_audit_screenshot_proof.py"
    )
    freeze_md = read("docs/audits/ROUTE_INVENTORY_FREEZE.md")
    assert "assert len(rows) == 136" in openapi_guard
    assert "assert len(rows) == 136" in final_guard
    assert "- Active routes in freeze: 136" in freeze_md
