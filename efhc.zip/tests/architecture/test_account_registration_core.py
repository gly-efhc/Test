"""Архитектурный замок единого центра регистрации циклов 1636–1639."""

from __future__ import annotations

import ast
from pathlib import Path

from app.identity.account_registration import (
    AccountRegistrationService,
    NewAccountRequest,
    build_account_registration_contract,
    create_new_account,
)

ROOT = Path(__file__).resolve().parents[2]
CORE = ROOT / "backend/app/identity/account_registration.py"
BOT = ROOT / "backend/app/services/referral_service.py"
TELEGRAM = ROOT / "backend/app/identity/telegram_auth_session.py"
TON = ROOT / "backend/app/identity/ton_account_registration.py"
MODEL = ROOT / "backend/app/models/referral_models.py"
MIGRATION = (
    ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_публичный_api_ядра_регистрации_существует() -> None:
    assert CORE.is_file()
    assert AccountRegistrationService is not None
    assert NewAccountRequest is not None
    assert callable(create_new_account)
    contract = build_account_registration_contract()
    assert contract["cycle"] == 1636
    assert contract["caller_migration"] == "bot_webapp_ton"


def test_ядро_требует_внешнюю_транзакцию_и_не_commit() -> None:
    source = _read(CORE)
    tree = ast.parse(source, filename=str(CORE))
    calls = {
        node.func.attr
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
    }
    assert "in_transaction" in calls
    assert "flush" in calls
    assert "commit" not in calls
    assert "rollback" not in calls
    assert 'AccountRegistrationError("TRANSACTION_REQUIRED")' in source


def test_ядро_создаёт_user_и_referral_через_orm() -> None:
    source = _read(CORE)
    assert "user = User(" in source
    assert "ReferralLink(" in source
    assert "INSERT INTO" not in source
    assert "session.add(user)" in source
    assert "invitee_global_id=global_id.value" in source
    assert "inviter_global_id=inviter_global_id.value" in source


def test_нормализация_referral_имеет_одну_реализацию() -> None:
    core = _read(CORE)
    bot = _read(BOT)
    assert "def normalize_referral_start_param" in core
    assert "def normalize_referral_start_param" not in bot
    assert "from app.identity.account_registration import" in bot
    assert "normalize_referral_start_param" in bot


def test_bot_webapp_и_ton_используют_единый_центр() -> None:
    bot = _read(BOT)
    telegram = _read(TELEGRAM)
    ton = _read(TON)
    onboarding = bot.split(
        "async def onboard_user_at_first_creation", 1
    )[1].split(
        "# ----------------------------------------------------------------------",
        1,
    )[0]
    assert "create_new_account(" in onboarding
    assert "INSERT INTO efhc_core.users" not in onboarding
    assert "_create_bot_user_identity(" in onboarding
    assert "create_new_account(" in telegram
    assert "create_new_account(" in ton
    assert "User(tg_id=verified.tg_id.value)" not in telegram
    assert "User(tg_id=None)" not in ton


def test_bot_identity_создаётся_до_единственного_commit() -> None:
    bot = _read(BOT)
    onboarding = bot.split(
        "async def onboard_user_at_first_creation", 1
    )[1].split(
        "# ----------------------------------------------------------------------",
        1,
    )[0]
    assert onboarding.index("create_new_account(") < onboarding.index(
        "_create_bot_user_identity("
    ) < onboarding.index("await db.commit()")
    assert "UserIdentity(" in bot
    assert "is_verified=True" in bot
    assert "is_primary=True" in bot


def test_referral_работает_fail_closed_и_без_late_binding() -> None:
    source = _read(CORE)
    for reason in (
        "invalid_code",
        "code_not_found",
        "self_ref",
        "ACCOUNT_ALREADY_EXISTS",
        "REFERRAL_ATTRIBUTION_CONFLICT",
    ):
        assert reason in source
    assert "with_for_update()" in source


def test_ton_referral_использует_global_id_без_fake_tg_id() -> None:
    core = _read(CORE)
    model = _read(MODEL)
    migration = _read(MIGRATION)
    assert "REFERRAL_INVITEE_TG_ID_REQUIRED" not in core
    assert "invitee_tg_id = (" in core
    assert "Mapped[int | None]" in model
    assert "invitee_tg_id DROP NOT NULL" in migration
    assert "fake_tg" not in core.lower()
