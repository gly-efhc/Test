from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_progress_system_runtime_components_exist() -> None:
    text = read("frontend/src/components/dashboard/ProgressSystem.tsx")
    required = [
        "DashboardProgressBar",
        "DashboardSegmentedProgress",
        "DashboardCircularProgress",
        "DashboardCountdownProgress",
        "DashboardMilestoneProgress",
        "EFHC_PROGRESS_SYSTEM_V1",
    ]
    for item in required:
        assert item in text


def test_progress_system_uses_real_countdown_math() -> None:
    text = read("frontend/src/components/dashboard/ProgressSystem.tsx")
    assert "SECONDS_PER_DAY = 86400" in text
    assert "SECONDS_PER_HOUR = 3600" in text
    assert "SECONDS_PER_MINUTE = 60" in text
    assert "Math.floor(safeSeconds / SECONDS_PER_DAY)" in text
    assert "/ 86" not in text
    assert "% 86" not in text
    assert "/ 3" not in text


def test_progress_system_tracks_truth_metadata() -> None:
    text = read("frontend/src/components/dashboard/ProgressSystem.tsx")
    assert "data-progress-kind" in text
    assert "data-progress-data-kind" in text
    assert "data-progress-synthetic" in text
    assert "synthetic ? \"true\" : \"false\"" in text


def test_simulation_and_admin_kits_expose_progress_wrappers() -> None:
    sim = read("frontend/src/components/dashboard/SimulationDashboardUiKit.tsx")
    admin = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    for item in [
        "SimSegmentedProgress",
        "SimCircularProgress",
        "SimCountdownProgress",
        "SimMilestoneProgress",
    ]:
        assert item in sim
    assert "AdminProgressBar" in admin
    assert "DashboardProgressBar" in admin


def test_progress_css_uses_dashboard_tokens() -> None:
    css = read("frontend/src/styles/globals.css")
    assert "Dashboard Progress System Foundation" in css
    assert ".efhc-dashboard-progress" in css
    assert "var(--efhc-dash-info)" in css
    assert "var(--efhc-dash-success)" in css
    assert "var(--efhc-dash-border)" in css


def test_progress_docs_and_grafana_map_registered() -> None:
    norm = read("docs/NORM/PROGRESS_SYSTEM_FOUNDATION.md")
    usage = read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
    map_text = read("map_element.md")
    assert "ACTIVE_PROGRESS_SYSTEM_FOUNDATION" in norm
    assert "BarGauge" in usage
    assert "RadialGauge" in usage
    assert "Progress System Foundation" in map_text
    assert "No Grafana runtime source is copied" in norm


def test_progress_machine_report_safety_flags() -> None:
    report = read("reports/generated/progress_system_foundation_v170_39.json")
    assert '"grafana_reference_only": true' in report
    assert '"runtime_code_copied_from_grafana": false' in report
    assert '"runtime_code_copied_from_sandbox": false' in report
    assert '"economy_changed": false' in report
    assert '"backend_contracts_changed": false' in report
