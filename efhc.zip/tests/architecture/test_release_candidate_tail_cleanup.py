from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_активная_migration_содержит_только_release_0001() -> None:
    versions = sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert versions == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]


def test_public_identity_api_не_экспортирует_pre_release_harnesses() -> None:
    source = _read("backend/app/identity/__init__.py")
    assert "app.identity.user_id_backfill" not in source
    assert "app.identity.user_id_expand" not in source
    assert "BACKFILL_APPLY_ENABLED" not in source
    assert "UserIdExpandPlan" not in source


def test_release_builder_исключает_pre_release_identity_harnesses() -> None:
    source = _read("ops/release/build_release_archive.py")
    for path in (
        "backend/app/identity/legacy_user_id.py",
        "backend/app/identity/user_id_backfill.py",
        "backend/app/identity/user_id_expand.py",
    ):
        assert path in source


def test_active_identity_contract_ссылается_на_release_0001() -> None:
    contract = _read("contracts/identity/user_identities_schema_v1.json")
    assert "0001_initial_release_schema.py" in contract
    assert "0003_user_identities_expand.py" not in contract
