from pathlib import Path

from ops.operator_kernel.patch_planner import plan_patch
from ops.operator_kernel.route_resolver import resolve_route


def test_operator_kernel_blocks_silent_ci_change():
    plan = plan_patch(
        "repair CI freezegun",
        changed_files=["ci.yml"],
        root=Path.cwd(),
    )
    assert plan["status"] == "blocked"
    assert "ci.yml" in plan["blocked_files"]


def test_operator_kernel_ci_route_marks_restricted():
    route = resolve_route("ci_log_repair")
    assert "ci.yml" in route["restricted"]
    config = Path("ops/operator_kernel/config/routes.yaml")
    assert "ci.yml" in config.read_text(encoding="utf-8")
