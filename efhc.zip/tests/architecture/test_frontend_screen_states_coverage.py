from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_wallet_states_covered() -> None:
    text = (
        ROOT / "frontend/src/components/profile/"
        "ProfileWalletSection.tsx"
    ).read_text(encoding="utf-8")
    assert "wallet.loading_wallets_title" in text
    assert "wallet.empty_title" in text
    assert "wallet.error_title" in text


def test_history_states_covered() -> None:
    text = (
        ROOT / "frontend/src/components/profile/"
        "ProfileHistorySection.tsx"
    ).read_text(encoding="utf-8")
    list_text = (
        ROOT / "frontend/src/components/profile/history/"
        "BalanceHistoryList.tsx"
    ).read_text(encoding="utf-8")
    empty_text = (
        ROOT / "frontend/src/components/profile/history/"
        "BalanceHistoryEmptyState.tsx"
    ).read_text(encoding="utf-8")
    withdraw_text = (
        ROOT / "frontend/src/components/profile/history/"
        "WithdrawHistoryList.tsx"
    ).read_text(encoding="utf-8")
    assert "historyError" in text
    assert "withdrawError" in text
    assert "history.loading_items" in list_text
    assert "history.empty_title" in empty_text
    assert "withdraw.loading_items" in withdraw_text
    assert "withdraw.empty_title" in withdraw_text


def test_hub_states_covered() -> None:
    text = (ROOT / "frontend/src/features/hub/HubPage.tsx").read_text(
        encoding="utf-8"
    )
    assert 'data-hub-visible-action-count="2"' in text
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in text
    assert "handoff.isPending" in text
    assert "disabled={handoff.isPending}" in text
    assert "handoff.mutateAsync()" in text
    assert "action_vip_nft" in text
