from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_hub_guarded_functions_cannot_be_collapsed_into_one_action() -> None:
    hub = read("frontend/src/features/hub/HubPage.tsx")
    locks = read("docs/NORM/ARCHITECTURAL_LOCKS.md")
    audit = read("docs/audits/RECENT_GUARD_CONTRADICTION_AUDIT_1562.md")
    assert hub.count('data-hub-action=') == 2
    assert 'data-hub-action="top-up"' in hub
    assert 'data-hub-action="vip-nft"' in hub
    assert "https://getgems.io/efhc-nft" in hub
    assert "request a user decision" in locks
    assert "No direct user decision authorised deletion" in audit


def test_energy_cleanup_cannot_add_wallet_exchange_or_hide_level_name() -> None:
    energy = read("frontend/src/pages/index.tsx")
    assert "EnergyMvpSummary" not in energy
    assert "profile.main_balance" not in energy
    assert "profile.bonus_balance" not in energy
    assert 'href: "/exchange"' not in energy
    assert "USER_LEVEL_SKINS" in energy
    assert 'data-energy-level-name={levelName}' in energy
    assert "Lvl {level}" in energy


def test_navigation_preserves_approved_baseline() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    css = read("frontend/src/styles/globals.css")
    icons = read("frontend/src/components/icons/AppNavIcon.tsx")
    assert 'data-nav-geometry="wide-rounded-six"' in layout
    assert 'data-nav-icon-system="rounded-outline-v2"' in layout
    assert 'data-nav-slot={props.slot}' in layout
    assert "premium-dock-v3" not in layout + css
    assert "floating-console-six" not in layout + css
    assert "layered-line-v3" not in layout + css
    assert "efhc-game-nav_icon-halo" not in layout + css
    assert '"data-nav-icon-system": "rounded-outline-v2"' in icons
