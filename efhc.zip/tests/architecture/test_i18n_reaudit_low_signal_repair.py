from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WAVE3_QUALITY_SCRIPTS = [
    "audit_da_locale_value_quality.py",
    "audit_de_locale_value_quality.py",
    "audit_es_locale_value_quality.py",
    "audit_fr_locale_value_quality.py",
    "audit_hi_locale_value_quality.py",
    "audit_id_locale_value_quality.py",
    "audit_it_locale_value_quality.py",
    "audit_pl_locale_value_quality.py",
    "audit_sw_locale_value_quality.py",
    "audit_tr_locale_value_quality.py",
]


def test_v169_82_reaudit_source_is_archived() -> None:
    source = (
        ROOT
        / "docs/audits/I18N_REAUDIT_REPORT_V169_82_2026_06_03.md"
    )
    assert source.exists()
    body = source.read_text(encoding="utf-8")
    assert "Версия:** v169.82" in body
    assert "Genuinely untranslated" in body
    assert "все = faq.title" in body


def test_shared_exact_value_allowlist_contains_low_signal_tokens() -> None:
    payload = json.loads(
        (
            ROOT / "ops/i18n/identical_to_english_allowlist.json"
        ).read_text(encoding="utf-8")
    )
    exact_values = set(payload["exact_values"])
    for value in {"FAQ", "1 kWh = 1 EFHC", "h", "d", "m", "s"}:
        assert value in exact_values


def test_wave3_quality_scripts_use_shared_allowlist_helper() -> None:
    helper = ROOT / "ops/i18n/locale_quality_allowlist.py"
    assert helper.exists()
    helper_body = helper.read_text(encoding="utf-8")
    assert "identical_to_english_allowlist.json" in helper_body
    assert "def is_allowed_identical" in helper_body

    for script in WAVE3_QUALITY_SCRIPTS:
        body = (ROOT / "ops/i18n" / script).read_text(
            encoding="utf-8"
        )
        assert "from locale_quality_allowlist import" in body, script
        assert "load_identical_allowlist()" in body, script
        assert "is_allowed_identical(" in body, script


def test_panels_service_comment_is_explicit_false_positive() -> None:
    guard = (
        ROOT / "ops/i18n/audit_forbidden_gambling_chance_contour.py"
    ).read_text(encoding="utf-8")
    assert "Цена панели фиксирована" in guard
    service = (ROOT / "backend/app/services/panels_service.py").read_text(
        encoding="utf-8"
    )
    assert "Цена панели фиксирована: 100 EFHC" in service


def test_generated_low_signal_report_preserves_non_claims() -> None:
    payload = json.loads(
        (
            ROOT
            / "reports/generated/i18n_reaudit_low_signal_repair_v169_83.json"
        ).read_text(encoding="utf-8")
    )
    assert payload["cycle"] == 1401
    assert payload["version"] == "v169.83"
    assert payload["repaired_findings"]["O1"]["status"] == "DONE"
    assert payload["repaired_findings"]["O2"]["status"] == "DONE"
    assert payload["repaired_findings"]["O3"]["status"] == "DONE"
    assert "no GitHub CI green for v169.83" in payload["non_claims"]
    assert "no release-ready verdict" in payload["non_claims"]
