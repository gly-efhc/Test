import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend/public/locale"
KEYS = {
    "exchange.exchange_failed",
    "onboarding.kicker",
    "onboarding.energy_title",
    "onboarding.energy_text",
    "onboarding.panels_title",
    "onboarding.panels_text",
    "onboarding.exchange_title",
    "onboarding.exchange_text",
    "onboarding.help_title",
    "onboarding.help_text",
    "onboarding.skip",
    "onboarding.next",
    "onboarding.done",
}


def test_new_public_i18n_keys_exist_in_all_locales():
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(KEYS - set(data))
        assert missing == [], f"{path.name}: {missing}"


def test_uk_ru_onboarding_not_raw_english():
    for lang in ("ru", "uk"):
        data = json.loads((LOCALE_DIR / f"{lang}.json").read_text())
        assert data["onboarding.next"] not in {"Next", "Done", "Skip"}
        assert "Exchange failed" not in data["exchange.exchange_failed"]
