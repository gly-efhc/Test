from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_game_details_component_exists() -> None:
    source = _read("frontend/src/components/ui/GameShell.tsx")
    css = _read("frontend/src/styles/globals.css")
    assert "export function GameDetails" in source
    assert "efhc-game-details" in source
    assert ".efhc-game-details" in css
    assert "efhc-compact-list-limit" in css


def test__main__user_pages_use_compact_disclosure() -> None:
    pages = [
        "frontend/src/pages/panels.tsx",
        "frontend/src/pages/exchange.tsx",
        "frontend/src/pages/tasks.tsx",
        "frontend/src/pages/referrals.tsx",
        "frontend/src/pages/ranks.tsx",
    ]
    for page in pages:
        text = _read(page)
        assert "GamePageShell" in text
        assert "GamePageShell" in text


def test_public_route_entry_points_are_preserved() -> None:
    for route in [
        "index",
        "panels",
        "exchange",
        "tasks",
        "referrals",
        "ranks",
        "hub",
        "browser-shop",
        "web-profile",
    ]:
        path = ROOT / "frontend/src/pages" / f"{route}.tsx"
        assert path.exists(), f"missing public route: {route}"


def test_dependency_warning_tail_is_closed() -> None:
    package = json.loads(_read("frontend/package.json"))
    deps = package["dependencies"]
    dev = package["devDependencies"]
    overrides = package.get("overrides", {})
    assert deps["axios"] >= "1.14.0"
    assert deps["next"].lstrip("^") >= "14.2.35"
    assert "@ton/ton" in deps
    assert dev["postcss"].lstrip("^") >= "8.4.0"
    assert isinstance(overrides, dict)


def test_cycles_and_reports_record_green_log_tail_closure() -> None:
    cycles = _read("docs/cycles/WORK_CYCLES_1200-1300.md")
    qa = _read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")
    report = _read(
        "reports/change_cycle_2026-05-18_v168_44_"
        "cycles_1251_1260_tail_closure.md",
    )
    assert "logs_69555566503.zip" in cycles
    assert "1251" in cycles and "1260" in cycles
    assert "green" in qa.lower()
    assert "538 passed" in report
