from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "docs"
SSOT = DOCS / "ssot_pack"


def _load_tables_count() -> int:
    with (SSOT / "SSOT_TABLES_ORM.csv").open(encoding="utf-8") as fh:
        return sum(1 for _ in csv.DictReader(fh))


def _load_routes_count() -> int:
    with (SSOT / "SSOT_ROUTES_TABLES_MIGRATIONS.csv").open(
        encoding="utf-8"
    ) as fh:
        return sum(1 for _ in csv.DictReader(fh))


def _load_test_files() -> list[str]:
    return sorted(
        path.relative_to(ROOT).as_posix()
        for path in (ROOT / "tests").rglob("test_*.py")
    )


def test_overview_docs_have_current_counts() -> None:
    tables = _load_tables_count()
    routes = _load_routes_count()
    tests = len(_load_test_files())
    required = [
        DOCS / "OVERVIEW_SSOT_SYNC.md",
        DOCS / "PROJECT_OVERVIEW_RU.md",
        DOCS / "DB_SCHEMA.md",
        DOCS / "DIAGNOSTIC_DB_INVENTORY.md",
        ROOT / "README.md",
    ]
    for path in required:
        data = path.read_text(encoding="utf-8")
        assert "efhc_core" in data
        assert "efhc_admin" in data
        if path.name != "DB_SCHEMA.md":
            assert f"**{routes}**" in data
            assert f"**{tests}**" in data
        if path.name != "README.md":
            assert f"**{tables}**" in data


def test_tests_catalog_matches_repo() -> None:
    catalog = (DOCS / "TESTS_CATALOG.md").read_text(encoding="utf-8")
    repo_tests = _load_test_files()
    for rel in repo_tests:
        assert f"`{rel}`" in catalog
