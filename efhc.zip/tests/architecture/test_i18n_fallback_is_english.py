from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
I18N = ROOT / "frontend/src/lib/i18n.ts"
EN = ROOT / "frontend/public/locale/en.json"
RU = ROOT / "frontend/public/locale/ru.json"

CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def _t_from_dicts_body() -> str:
    text = I18N.read_text(encoding="utf-8")
    fn_match = re.search(
        (
            r"export function tFromDicts\([^)]*\): string "
            r"\{(?P<body>.*?)\n\}"
        ),
        text,
        re.S,
    )
    assert fn_match, "tFromDicts function body missing"
    return fn_match.group("body")


def test_t_from_dicts_ignores_ru_argument_and_selects_embedded_english() -> (
    None
):
    """C1 regression guard: empty locale dict must fall back to EN, not RU.

    The architecture test cannot import the Next/TS module directly without a
    frontend build step, so it verifies the executable decision tree and mirrors
    the intended call on real locale data: tFromDicts(key, {}, non_empty_ru_dict).
    If `ru[k]` is restored before `embeddedEn[k]`, this test fails.
    """

    body = _t_from_dicts_body()
    en = json.loads(EN.read_text(encoding="utf-8"))
    ru = json.loads(RU.read_text(encoding="utf-8"))

    key = "tasks.title"
    assert en[key] == "Tasks"
    assert ru[key] != en[key]
    assert CYRILLIC_RE.search(
        ru[key]
    ), "fixture must contain Cyrillic RU value"

    assert (
        "void ru;" in body
    ), "ru compatibility argument must stay explicitly ignored"
    assert 'getEmbeddedDict("en")' in body
    assert "embeddedEn[k]" in body
    assert "humanizeMissingI18nKey(k)" in body
    assert "ru[k]" not in body
    assert 'getEmbeddedDict("ru")' not in body
    assert "embeddedRu" not in body

    return_expr_match = re.search(r"return (?P<expr>.*?);", body, re.S)
    assert return_expr_match, "tFromDicts return expression missing"
    return_expr = " ".join(return_expr_match.group("expr").split())
    assert return_expr.startswith(
        "dict[k] || embeddedEn[k] ||"
    ), return_expr

    # Mirrored call: tFromDicts(key, empty_dict, non_empty_ru_dict)
    result = en[key]
    assert result == "Tasks"
    assert result != ru[key]
    assert not CYRILLIC_RE.search(result)


def test_t_from_dicts_regression_tokens_are_absent() -> None:
    body = _t_from_dicts_body()
    forbidden = ("ru[k]", 'getEmbeddedDict("ru")', "embeddedRu")
    for token in forbidden:
        assert token not in body
