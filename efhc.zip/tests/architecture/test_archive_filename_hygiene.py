import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MD_PREFIX = (
    ROOT
    / "docs"
    / "GENERAL"
    / "ORIGINAL_SOURCES"
    / "EFHC_BOT_START"
    / "md"
)
EXCLUDED_PREFIXES = (
    "docs/cycles/",
    "docs/chats/",
    "reports/",
    "docs/healer/",
)
TRACEABILITY_FILES = {
    "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
    "docs/PLANS/WORK_PLAN_1693-1709.md",
    "CONTINUE_IN_NEW_CHAT.md",
    "HEALER_ATLAS.md",
    "atlas.json",
    "casebook.json",
}
MOJIBAKE_MARKERS = (
    "Γ",
    "╬",
    "├",
    "┬",
    "╞",
    "╢",
    "╣",
    "╜",
    "╨",
    "╤",
)
MAX_COMPONENT_BYTES = 120
MAX_REL_PATH_BYTES = 220
NUMBERED_WORK_PASS_FILENAME = re.compile(
    r"(?i)(?:^|[_-])cycles?[_-]?\d|(?<!v\d{3})_"
    r"(?:[3-9]\d{2}|1\d{3,4})(?:_(?:[3-9]\d{2}|1\d{3,4}))?(?=\.|_|$)"
)
NUMBERED_WORK_PASS_TEXT = re.compile(
    r"(?i)\bcycles?[_\s:#№-]*(?:[3-9]\d{2}|1\d{3,4})(?:\s*[-–—_/"
    r"]\s*(?:[3-9]\d{2}|1\d{3,4}))*\b"
)
DATE_TOKEN = re.compile(r"\d{4}[_-]\d{2}[_-]\d{2}")
VERSION_TOKEN = re.compile(r"(?i)v\d{2,4}_\d{1,4}")


def iter_files():
    for path in ROOT.rglob("*"):
        if (
            "__pycache__" in path.parts
            or ".pytest_cache" in path.parts
        ):
            continue
        if path.is_file():
            yield path


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def is_exception(path: Path) -> bool:
    r = rel(path)
    return r in TRACEABILITY_FILES or r.startswith(EXCLUDED_PREFIXES)


def is_allowed_numeric_filename(path: Path) -> bool:
    r = rel(path)
    name = path.name
    if is_exception(path):
        return True
    if r.startswith("docs/GENERAL/ADR/"):
        return True
    if re.search(
        (
            r"frontend/public/(?:images|assets)/"
            r".*efhc[_-]coin[_-]\d+\.(png|jpg|jpeg|webp)$"
        ),
        r,
        re.I,
    ):
        return True
    if "ORM_0001" in r or "MIGRATION_0001" in r or "SSOT_DB_0001" in r:
        return True
    if "100_QUESTIONS" in r or "180_days" in r:
        return True
    return bool(DATE_TOKEN.search(name))


def normalized_name_for_scan(name: str) -> str:
    name = VERSION_TOKEN.sub("VERSION", name)
    name = DATE_TOKEN.sub("DATE", name)
    name = re.sub(r"\d{8,}", "LOGID", name)
    return name


def test_no_problematic_long_or_mojibake_filenames():
    offenders = []
    for path in iter_files():
        if is_exception(path):
            continue
        r = rel(path)
        if any(marker in path.name for marker in MOJIBAKE_MARKERS):
            offenders.append(f"mojibake:{r}")
        if len(path.name.encode("utf-8")) > MAX_COMPONENT_BYTES:
            offenders.append(f"component-too-long:{r}")
        if len(r.encode("utf-8")) > MAX_REL_PATH_BYTES:
            offenders.append(f"path-too-long:{r}")
    assert not offenders, (
        "Problematic archive filenames found:\n" + "\n".join(offenders)
    )


def test_no_numbered_work_pass_labels_in_non_exception_filenames():
    offenders = []
    for path in iter_files():
        if is_allowed_numeric_filename(path):
            continue
        if NUMBERED_WORK_PASS_FILENAME.search(
            normalized_name_for_scan(path.name)
        ):
            offenders.append(rel(path))
    assert not offenders, (
        "Numbered work-pass labels remain in non-exception filenames:\n"
        + "\n".join(offenders)
    )


def test_no_numbered_work_pass_labels_in_non_exception_docs_and_indexes():
    offenders = []
    for path in iter_files():
        if is_exception(path):
            continue
        r = rel(path)
        if r.startswith((
            "tests/",
            "ops/",
            "scripts/",
            "reports/generated/",
        )):
            continue
        if r in {
            "KERNEL.md",
            "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
        }:
            continue
        if r.startswith(("docs/AI/", "docs/NORM/", "docs/SSOT/")):
            continue
        if r.startswith("docs/testing/"):
            # Testing documents may mention source cycles inside the body for
            # traceability. The ban applies to filenames in this layer.
            continue
        if path.suffix.lower() not in {
            ".md",
            ".py",
            ".json",
            ".yaml",
            ".yml",
            ".txt",
        }:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        scan_text = VERSION_TOKEN.sub("VERSION", text)
        scan_text = DATE_TOKEN.sub("DATE", scan_text)
        scan_text = re.sub(r"\d{8,}", "LOGID", scan_text)
        if NUMBERED_WORK_PASS_TEXT.search(scan_text):
            offenders.append(rel(path))
    assert not offenders, (
        "Numbered work-pass labels remain in non-"
        "exception text files:\n"
        + "\n".join(offenders)
    )


def test_docs_testing_filenames_do_not_use_cycle_suffixes():
    offenders = []
    for path in (ROOT / "docs" / "testing").rglob("*"):
        if not path.is_file():
            continue
        name = normalized_name_for_scan(path.name)
        if NUMBERED_WORK_PASS_FILENAME.search(name):
            offenders.append(rel(path))
    assert not offenders, (
        "docs/testing is not a cycle-label exception layer:\n"
        + "\n".join(offenders)
    )


def test_original_sources_md_folder_uses_clean_semantic_names():
    assert MD_PREFIX.exists(), "original-source md folder is missing"
    offenders = []
    for path in MD_PREFIX.glob("*.md"):
        name = path.name
        if re.search(r"\(\d+\)", name):
            offenders.append(f"copy-suffix:{name}")
        if any(marker in name for marker in MOJIBAKE_MARKERS):
            offenders.append(f"mojibake:{name}")
        if len(name.encode("utf-8")) > 80:
            offenders.append(f"md-name-too-long:{name}")
    assert not offenders, (
        "Unclean original-source md filenames found:\n"
        + "\n".join(offenders)
    )


def test_chat_branch_duplicates_removed_from_active_norm():
    assert not (ROOT / "docs" / "NORM" / "CHAT_BRANCHES").exists()
    assert not (ROOT / "docs" / "NORM" / "CHATS").exists()
    assert not (ROOT / "АРТЕФАКТЫ").exists()
    assert not (ROOT / "docs" / "history").exists()


def test_release_version_lineage_is_preserved():
    reports = ROOT / "reports" / "numbered"
    assert any(
        "v169_35" in path.name.lower()
        for path in reports.iterdir()
        if path.is_file()
    ), "release version lineage disappeared from numbered reports"
