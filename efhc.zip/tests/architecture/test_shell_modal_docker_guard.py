from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOCKERFILE = ROOT / "ops/docker/Dockerfile.backend"
COMPOSE = ROOT / "docker-compose.yml"
OPS_COMPOSE = ROOT / "ops/docker/docker-compose.yml"
DOCUMENT = ROOT / "frontend/src/pages/_document.tsx"
MODAL = ROOT / "frontend/src/components/ui/Modal.tsx"
HEADER = ROOT / "frontend/src/components/GlobalHeader.tsx"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
TRIAGE_MD = ROOT / "docs/audits/VISIBLE_FUNCTIONS_TRIAGE_TABLE.md"
TRIAGE_JSON = ROOT / "reports/generated/visible_functions_triage.json"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_docker_docs_and_api_healthcheck_are_wired() -> None:
    dockerfile = _read(DOCKERFILE)
    compose = _read(COMPOSE)
    ops_compose = _read(OPS_COMPOSE)

    assert "COPY docs /app/docs" in dockerfile
    assert "http://127.0.0.1:8000/api/health" in compose
    assert "http://127.0.0.1:8000/api/health" in ops_compose
    assert "http://127.0.0.1:8000/health" not in compose


def test_telegram_sdk_is_bootstrapped_in_document() -> None:
    src = _read(DOCUMENT)

    assert 'from "next/document"' in src
    assert "https://telegram.org/js/telegram-web-app.js" in src
    assert "<Main />" in src
    assert "<NextScript />" in src


def test_shared_modal_is_bottom_sheet_without__call__api_change() -> (
    None
):
    src = _read(MODAL)
    css = _read(CSS)

    for token in ["open", "onClose", "title", "PropsWithChildren"]:
        assert token in src
    assert "efhc-modal-sheet" in src
    assert "efhc-modal-header" in src
    assert "efhc-modal-body" in src
    assert "efhc-modal-sheet" in css
    assert "efhc-modal-title" in css


def test_global_header_actions_are_preserved() -> None:
    src = _read(HEADER)

    assert "props.onOpenWallet" in src
    assert "props.onDeposit" in src
    assert 'router.push("/hub")' in src
    assert 'aria-label={t("deposit.direct_title")}' in src
    assert "efhc-game-header_actions" in src


def test_global_header_balance_and_status_visual_contract() -> None:
    src = _read(HEADER)
    css = _read(CSS)

    assert "efhc-game-header_balance-value" in src
    assert "truncate" not in src.split(
        'className="efhc-game-header_balance-value"',
        1,
    )[1].split("</div>", 1)[0]
    assert 'data-status={props.kind}' in src
    assert 'data-active={props.active ? "true" : "false"}' in src
    assert "TelegramStatusBadge" not in src
    assert ".efhc-game-header_status{" in css
    cycle_css = css.split(
        "/* Cycle 1572: fully visible balance and text-only Activ/VIP states. */",
        1,
    )[1]
    status_css = cycle_css.split(
        ".efhc-game-header_status{",
        1,
    )[1].split("}", 1)[0]
    assert "background:transparent" in status_css
    assert "border:0" in status_css
    assert "box-shadow:none" in status_css
    balance_css = cycle_css.split(
        ".efhc-game-header_balance-value{",
        1,
    )[1].split("}", 1)[0]
    assert "text-overflow:clip" in balance_css
    assert "white-space:nowrap" in balance_css


def test_layout_preserves_bottom_menu_with_game_shell() -> None:
    src = _read(LAYOUT)

    labels = [
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
    ]
    routes = [
        "/",
        "/panels",
        "/exchange",
        "/tasks",
        "/referrals",
        "/ranks",
    ]
    for label in labels:
        assert f'visualLabel: "{label}"' in src
    for route in routes:
        assert f'href: "{route}"' in src
    assert "efhc-game-shell" in src
    assert "efhc-game-nav" in src
    assert "efhc-game-nav_grid" in src


def test_visible_function_triage_evidence_exists() -> None:
    data = json.loads(TRIAGE_JSON.read_text(encoding="utf-8"))
    md = _read(TRIAGE_MD)

    assert data["cycle"] == 1210
    assert data["rules"]["no_deletion_this_cycle"] is True
    assert data["rules"]["admin_only_through_admin"] is True
    assert len(data["rows"]) >= 10
    assert "leave/delete/admin/question" in md
    assert "Energy, Panels, Exchange, Tasks, Referrals, Ranks" in md
