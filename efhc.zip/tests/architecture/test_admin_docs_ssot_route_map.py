from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md"
REPORT = ROOT / (
    "reports/change_cycle_2026-06-01_v169_34_cycle_1355_"
    "admin_docs_ssot_route_map.md"
)
JSON_MAP = (
    ROOT / "reports/generated/admin_docs_ssot_route_map_v169_34.json"
)
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
CLASSIFIER = ROOT / "ops/operator_kernel/task_classifier.py"
RESOLVER = ROOT / "ops/operator_kernel/route_resolver.py"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_cycle_1355_documents_exist() -> None:
    for path in (DOC, REPORT, JSON_MAP):
        assert path.exists(), str(path)


def test_admin_route_map_covers_canonical_surfaces() -> None:
    text = read(DOC)
    for surface in (
        "/admin",
        "/admin/bank",
        "/admin/users",
        "/admin/withdrawals",
        "/admin/shop",
        "/admin/tasks",
        "/admin/reports",
        "/admin/diagnostics",
        "/admin/system",
    ):
        assert f"`{surface}`" in text


def test_admin_route_map_links_ssot_and_ui_kit() -> None:
    text = read(DOC)
    required = (
        "docs/SSOT/BANK_CANON.md",
        "docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md",
        "docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md",
        "docs/NORM/ADMIN_RBAC.md",
        "AdminUiKitAdoptionProofPanel",
        "AdminScreenshotQaPreparationPanel",
    )
    for marker in required:
        assert marker in text


def test_generated_json_contains_route_inventory() -> None:
    data = json.loads(read(JSON_MAP))
    assert data["cycle"] == 1355
    assert data["ci_changed"] is False
    assert len(data["surfaces"]) >= 17
    assert len(data["backend_endpoints"]) >= 50


def test_operator_kernel_has_admin_docs_route() -> None:
    route_text = read(ROUTES)
    classifier = read(CLASSIFIER)
    resolver = read(RESOLVER)
    assert "admin_docs_route_map" in route_text
    assert "admin_docs_route_map" in classifier
    assert "admin_docs_route_map" in resolver
    assert "docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md" in route_text


def test_cycle_1355_keeps_ci_manual_boundary() -> None:
    text = read(DOC) + read(REPORT)
    assert "CI/workflow files are manual-control" in text
    assert "`ci.yml` was not changed" in text
