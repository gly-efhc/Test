from __future__ import annotations

from pathlib import Path


def test_artifact_full_build_required() -> None:
    """Fail fast if the artifact is missing SSOT anchors (no truncated builds)."""

    repo_root = Path(__file__).resolve().parents[2]

    required_paths = [
        repo_root / "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
        repo_root / "docs" / "SSOT_INDEX.md",
        repo_root / "docs" / "TESTS_CATALOG.md",
        repo_root / "ops" / "canon_rules.yaml",
        repo_root / "backend" / "alembic.ini",
    ]

    missing: list[str] = []
    empty: list[str] = []

    for p in required_paths:
        if not p.exists():
            missing.append(str(p.relative_to(repo_root)))
            continue
        if p.is_file() and p.stat().st_size == 0:
            empty.append(str(p.relative_to(repo_root)))

    docs_dir = repo_root / "docs"
    if not docs_dir.exists() or not docs_dir.is_dir():
        missing.append("docs/")
    else:
        # docs must not be empty (at least one markdown file)
        has_any = any(x.is_file() for x in docs_dir.rglob("*"))
        if not has_any:
            empty.append("docs/ (empty)")

    if missing or empty:
        msg = []
        if missing:
            msg.append("Missing required SSOT paths: " + ", ".join(sorted(missing)))
        if empty:
            msg.append("Empty required SSOT paths: " + ", ".join(sorted(empty)))
        raise AssertionError("\n".join(msg))
