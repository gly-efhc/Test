from __future__ import annotations

import hashlib
import json
from pathlib import Path

from ops.identity.check_tg_id_domain_boundary import (
    check as check_identity_boundary,
)
from ops.identity.check_user_id_contract_patch_boundary import (
    check as check_patch_boundary,
)
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_cycle1594_has_exact_kernel_route() -> None:
    classified = classify_task(
        "Цикл 1594 UserId contract negative guards"
    )
    assert classified["task_type"] == "user_id_contract_foundation"
    route = resolve_route("user_id_contract_foundation", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "user_id_contract_foundation"


def test_canonical_contract_is_fixed_in_ssot_and_norm() -> None:
    ssot = read("docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md")
    norm = read("docs/NORM/GLOBAL_IDENTITY_MIGRATION_NORM.md")
    for token in (
        "users.global_id",
        "9999999999",
        "^[0-9]{10}$",
        "0000000000",
        "GlobalId",
        "TelegramId",
        "ExternalGlobalId",
    ):
        assert token in ssot or token in norm
    assert 'User.user_id = synonym("global_id")' in ssot
    assert "users.user_id → users.global_id" in norm

def test_strengthened_identity_boundary_passes() -> None:
    result = check_identity_boundary(
        ROOT,
        ROOT / "ops/identity/tg_id_domain_boundary_baseline.json",
    )
    assert result["passed"], result["errors"]
    assert result["cycle"] == 1646
    assert result["target_head"] == "EFHC_Bot_v172_66.zip"
    assert result["semantic_mix_offenders"] == 0

def test_cycle1594_patch_boundary_is_preserved_as_historical_proof() -> None:
    data = json.loads(
        read("ops/identity/user_id_contract_patch_boundary.json")
    )
    assert data["schema"] == (
        "EFHC_USER_ID_CONTRACT_PATCH_BOUNDARY_V1"
    )
    assert data["cycle"] == 1594
    assert data["target_head"] == "EFHC_Bot_v171_91.zip"
    assert data["allowed_new_files"] == [
        "backend/app/identity/__init__.py",
        "backend/app/identity/types.py",
    ]
    # Current-head enforcement moved to the cycle-1595 semantic guard.
    current = read(
        "ops/identity/user_id_value_type_patch_boundary.json"
    )
    assert "EFHC_USER_ID_VALUE_TYPE_PATCH_BOUNDARY_V1" in current


def test_patch_boundary_ignores_generated_python_caches(
    tmp_path: Path,
) -> None:
    protected = tmp_path / "backend/app/models/user_models.py"
    protected.parent.mkdir(parents=True)
    protected.write_text("# protected\n", encoding="utf-8")
    digest = hashlib.sha256(protected.read_bytes()).hexdigest()
    cache = protected.parent / "__pycache__/user_models.pyc"
    cache.parent.mkdir()
    cache.write_bytes(b"generated")
    manifest = {
        "schema": "EFHC_USER_ID_CONTRACT_PATCH_BOUNDARY_V1",
        "source_head": "source.zip",
        "target_head": "target.zip",
        "cycle": 1594,
        "protected_roots": ["backend/app/models"],
        "allowed_new_files": [],
        "protected_file_entries": [
            {
                "path_parts": [
                    "backend",
                    "app",
                    "models",
                    "user_models.py",
                ],
                "sha256_parts": [digest],
            }
        ],
    }
    manifest_path = tmp_path / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest),
        encoding="utf-8",
    )
    result = check_patch_boundary(tmp_path, manifest_path)
    assert result["passed"], result["errors"]


def test_cycle1594_does_not_switch_orm_or_auth_runtime() -> None:
    model = read("backend/app/models/user_models.py")
    deps = read("backend/app/deps.py")
    assert "global_id: Mapped[int | None] = mapped_column(" in model
    assert 'user_id = synonym("global_id")' in model
    assert "tg_id: Mapped[int | None] = mapped_column(" in model
    assert "class AuthContext:\n    tg_id: int" in deps
    assert "get_current_user_id" not in deps


def test_boundary_rejects_indirect_python_identity_mix(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "backend/app/routes/bad.py"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "def bad(tg_id, wallet_address):\n"
        "    user_id = int(tg_id)\n"
        "    other_user_id = wallet_address\n"
        "    return user_id, other_user_id\n",
        encoding="utf-8",
    )
    result = check_identity_boundary(
        tmp_path,
        ROOT / "ops/identity/tg_id_domain_boundary_baseline.json",
    )
    assert not result["passed"]
    assert any(
        "provider/system identity mix" in error
        for error in result["errors"]
    )


def test_boundary_rejects_frontend_identity_mix(
    tmp_path: Path,
) -> None:
    bad = tmp_path / "frontend/src/bad.ts"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "const userId = tgId;\n"
        "const user_id = wallet_address;\n",
        encoding="utf-8",
    )
    result = check_identity_boundary(
        tmp_path,
        ROOT / "ops/identity/tg_id_domain_boundary_baseline.json",
    )
    assert not result["passed"]
    assert result["semantic_mix_offenders"] == 2


def test_baseline_entries_have_semantics_and_sunset() -> None:
    data = json.loads(
        read("ops/identity/tg_id_domain_boundary_baseline.json")
    )
    assert data["schema"] == "EFHC_TG_ID_BOUNDARY_BASELINE_V4"
    for item in data["legacy_runtime_baseline"]:
        assert item["categories"]
        assert item["planned_migration_cycle"]
        assert item["planned_removal_cycle"] in {"1631", "1646-1647", "1698"}
