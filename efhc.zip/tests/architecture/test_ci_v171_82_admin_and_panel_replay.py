from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_admin_withdraw_validator_generator_covers_runtime_contract() -> None:
    generator = (
        ROOT / "ops/openapi/generate_frontend_seam_validators.py"
    ).read_text(encoding="utf-8")
    generated = (
        ROOT
        / "frontend/src/lib/api/generated/adminSeamValidators.ts"
    ).read_text(encoding="utf-8")

    required = (
        "fee_message_ton_amount",
        "AdminWithdrawOutcomePreviewResponseSchema",
        "parseAdminWithdrawOutcomePreviewResponse",
        "wallet_send_confirmed",
        "sender_wallet_address",
    )
    for marker in required:
        assert marker in generator
        assert marker in generated


def test_panel_replay_is_resolved_before_state_dependent_checks() -> None:
    source = (
        ROOT / "backend/app/services/panels_service.py"
    ).read_text(encoding="utf-8")

    replay = source.index(
        'debit_result.detail == "idempotent"'
    )
    balance_check = source.index(
        'total_user = d8(main_before + bonus_before)'
    )
    panel_limit = source.index(
        "if current_active + qty > MAX_PANELS"
    )
    assert replay < balance_check < panel_limit
    assert "Panel replay is missing created panel ids" in source
    assert "Idempotency-Key belongs to another panel" in source
