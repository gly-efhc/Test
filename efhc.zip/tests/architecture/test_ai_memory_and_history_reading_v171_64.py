from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_temporary_memory_is_bounded_operational_brain() -> None:
    text = _read("docs/AI/AI_TEMPORARY_MEMORY_PENDING.md")
    assert "ACTIVE OPERATIONAL MEMORY" in text
    assert "No unresolved governance items remain" in text
    assert len(text.splitlines()) < 80


def test_activ_is_permanent_status_canon() -> None:
    text = _read("docs/SSOT/USER_FACING_WORDING_CANON.md")
    assert "постоянный активный статус аккаунта -> `Activ`" in text
    assert "`Active` is not the account-status label" in text


def test_history_default_read_is_latest_two() -> None:
    text = _read("docs/AI/LOGS_AND_REPORTS_RETENTION_POLICY.md")
    assert "latest two entries" in text
    assert "full `reports/` tree" in text
    kernel = _read("KERNEL.md")
    assert "latest two relevant entries per layer" in kernel
