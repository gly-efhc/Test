from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
_MODULE_CACHE: dict[str, object] = {}


def _load_support_module(rel_path: str) -> object:
    cached = _MODULE_CACHE.get(rel_path)
    if cached is not None:
        return cached
    path = ROOT / rel_path
    assert path.exists(), rel_path
    module_name = (
        "efhc_consolidated_"
        + rel_path.replace("/", "_").replace(".", "_")
    )
    spec = importlib.util.spec_from_file_location(
        module_name,
        path,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MODULE_CACHE[rel_path] = module
    return module


_CASES = [
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_cycle_index_has_explicit_control_panel",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_economic_block_history_is_closed_honestly",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_cycle_numbering_and_terms_are_global",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_hardening_docs_are_closed_and_historical",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_legacy_cycle_markers_and_catalog_are_kept_consistent",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_bot_admin_entrypoint_cycle_95_lock_still_holds",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_payment_withdraw_and_ssot_hardening_locks_remain",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_release_build_script_excludes_artifacts_from_zip",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_audit__import__and_audit_of_audit_docs_exist",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_ai_runtime_dependencies_precheck_doc_present",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_bank_reconciliation_table_doc_exists",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_cycle_425_concurrency_proof_doc_exists",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_cycle_426_self_healing_audit_doc_exists",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_frontend_sandbox_and_archive_triage_docs_exist",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_healer_is_primary_error_store_rule_present",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_frontend_ui_healing_checklist_docs_exist",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_shop_reporting_and_log_transfer_audits_exist",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_watcher_reporting_and_raw_audits_exist",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py",
        "test_shop_hub_truth_layer_sync_present",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_archive_numbering_canon.py",
        "test_archive_numbering_canon_exists_in_ai_startup_docs",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_archive_numbering_canon.py",
        "test_invalid_aliases_are_mapped_to_canonical_versions",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_archive_numbering_canon.py",
        "test_active_cycle_plan_uses_canonical_numbering",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_archive_numbering_canon.py",
        "test_current_corrected_archive_uses_two_digit_suffix",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_archive_numbering_canon.py",
        "test_work_cycles_records_current_corrected_head",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_plan_docs_collapse_wave1_lock.py",
        "test_removed_plan_docs_91_130",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_plan_docs_collapse_wave1_lock.py",
        "test_work_cycles_records_truth_source",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_next_range_extension_checkpoint.py",
        "test_next_range_extension_checkpoint_documents_exist",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_next_range_extension_checkpoint.py",
        "test_work_cycle_indexes_keep_checkpoint_history_and_current_lane",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_next_range_extension_checkpoint.py",
        "test_generated_checkpoint_json_is_consistent",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_next_range_extension_checkpoint.py",
        "test_ai_and_operator_kernel_know_checkpoint_route",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_next_range_extension_checkpoint.py",
        "test_sandbox_map_has_next_public_visual_lane_without_runtime_import",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_next_range_extension_checkpoint.py",
        "test_checkpoint_preserves_non_claims_and_boundaries",
    ),
    (
        "tests/architecture/cycle_marker_cases/case_operator_kernel_cycle_sync.py",
        "test_operator_kernel_patch_plan_has_cycle_hooks",
    ),
]


@pytest.mark.parametrize(
    ("support_module", "function_name"),
    _CASES,
)
def test_cycle_marker_docs_guard_case(
    support_module: str,
    function_name: str,
) -> None:
    module = _load_support_module(support_module)
    target = getattr(module, function_name)
    target()
