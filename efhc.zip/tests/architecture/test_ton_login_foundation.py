"""Architecture contracts цикла 1615 без полного импорта приложения."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ROUTE = ROOT / "backend/app/routes/auth_ton_routes.py"
CHALLENGE = ROOT / "backend/app/identity/ton_login_challenge.py"
RESOLVER = ROOT / "backend/app/identity/ton_wallet_id_resolver.py"
PROOF = ROOT / "backend/app/services/tonconnect_proof_service.py"
CONTRACT = ROOT / "contracts/identity/ton_login_challenge_contract_v1.json"


def test_маршрут_ton_login_не_зависит_от_telegram() -> None:
    source = ROUTE.read_text(encoding="utf-8")
    assert 'prefix="/auth/ton"' in source
    assert '"/challenge"' in source
    assert "get_current_tg_id" not in source
    assert "TelegramWebApp" not in source
    assert "tg_id" not in source


def test_ton_login_challenge_использует_hash_auth_storage() -> None:
    source = CHALLENGE.read_text(encoding="utf-8")
    assert "AuthChallengeService" in source
    assert "AuthProvider.TON" in source
    assert 'TON_LOGIN_PURPOSE: Final[str] = "ton.login"' in source
    assert '"creates_account": False' in source
    assert '"creates_session": False' in source


def test_ton_wallet_id_имеет_единый_канонический_parser_ssot() -> None:
    resolver = RESOLVER.read_text(encoding="utf-8")
    proof = PROOF.read_text(encoding="utf-8")
    assert "parse_ton_address" in resolver
    assert "parse_canonical_ton_address" in proof
    assert "def _parse_raw_address" not in proof
    assert "def _parse_friendly_address" not in proof


def test_machine_contract_фиксирует_границы_цикла() -> None:
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    assert contract["цикл"] == 1615
    assert contract["provider"] == "ton"
    assert contract["инварианты"]["telegram_dependency"] is False
    assert contract["инварианты"]["verifies_ton_proof"] is False
    assert contract["инварианты"]["creates_session"] is False
