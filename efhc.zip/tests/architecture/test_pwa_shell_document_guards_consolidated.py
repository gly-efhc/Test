from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
_MODULE_CACHE: dict[str, object] = {}


def _load_support_module(rel_path: str) -> object:
    cached = _MODULE_CACHE.get(rel_path)
    if cached is not None:
        return cached
    path = ROOT / rel_path
    assert path.exists(), rel_path
    module_name = (
        "efhc_consolidated_"
        + rel_path.replace("/", "_").replace(".", "_")
    )
    spec = importlib.util.spec_from_file_location(
        module_name,
        path,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MODULE_CACHE[rel_path] = module
    return module


_CASES = [
    (
        "tests/architecture/pwa_shell_cases/case_pwa_browser_shell_guard.py",
        "test_browser_app_manifest_is_linked_from_app",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_browser_shell_guard.py",
        "test_service_worker_is_registered_safely",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_browser_shell_guard.py",
        "test_manifest_supports_standalone_browser_mode",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_browser_shell_guard.py",
        "test_service_worker_is_network_safe_for_apis",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_install_policy_guard.py",
        "test_pwa_policy_document_exists",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_install_policy_guard.py",
        "test_manifest_and_service_worker_remain_present",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_install_policy_guard.py",
        "test_no_custom_pwa_install_flow_in_frontend_src",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_install_policy_guard.py",
        "test_no_custom_install_button_labels_in_public_locale",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_pwa_offline_fallback_guard.py",
        "test_service_worker_has_offline_fallback_shell",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_common_shell_handoff_and_tonconnect_contract.py",
        "test_single_tonconnect_provider_lives_in_app_shell",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_common_shell_handoff_and_tonconnect_contract.py",
        "test_compat_hook_uses_real_connection_restored_promise",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_common_shell_handoff_and_tonconnect_contract.py",
        "test_efhc_handoff_and_external_storefront_contract_stay_split",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_telegram_mini_app_shell_polish.py",
        "test_telegram_shell_helpers_expose_viewport_and_safe_area_markers",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_telegram_mini_app_shell_polish.py",
        "test_layout_has_public_route_backbutton_without_admin_leak",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_telegram_mini_app_shell_polish.py",
        "test_tma_shell_css_exists_and_uses_safe_area_tokens",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_telegram_mini_app_shell_polish.py",
        "test_tma_shell_docs_and_generated_manifest_exist",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_telegram_mini_app_shell_polish.py",
        "test_sandbox_runtime_frameworks_not_imported_by_tma_polish",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_frontend_page_shell_coverage.py",
        "test_app_wraps_pages_with_layout",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_frontend_page_shell_coverage.py",
        "test_ads_page_is_redirect_only",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_frontend_page_shell_coverage.py",
        "test_user_pages_exist_under_pages_dir",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_first_paint_guard.py",
        "test_document_has_dark_first_paint_css",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_first_paint_guard.py",
        "test_global_css_prevents_blank_white_shell",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_first_paint_guard.py",
        "test_app_has_splash_timeout_escape",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_first_paint_guard.py",
        "test_browser_login_keeps_route_exceptions",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_first_paint_guard.py",
        "test_pwa_manifest_starts_at_energy_root",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_first_paint_guard.py",
        "test_service_worker_has_privacy_safe_cache_strategies",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_independent_shell_guard.py",
        "test_profile_opens_as_page_not_overlay",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_independent_shell_guard.py",
        "test_profile_page_has_back_and_exit_controls",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_independent_shell_guard.py",
        "test_profile_page_no_longer_requires_telegram_token",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_independent_shell_guard.py",
        "test_independent_shell_css_exists",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_independent_shell_guard.py",
        "test_locale_no_telegram_shell_for_profile_note",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_blank_screen_followup_guard.py",
        "test_first_paint_is_dark_before_javascript",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_blank_screen_followup_guard.py",
        "test_default_theme_is_dark_not_white_auto",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_blank_screen_followup_guard.py",
        "test_splash_cannot_wait_forever_on_empty_dictionaries",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_blank_screen_followup_guard.py",
        "test_energy_progress_bar_is_visible_at_zero_progress",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_blank_screen_followup_guard.py",
        "test_referrals_do_not_fetch_with_missing_tg_id",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_blank_screen_followup_guard.py",
        "test_chat_agreement_list_exists",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_browser_independence_guard.py",
        "test_browser_fallback_snapshot_exists",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_browser_independence_guard.py",
        "test_app_passes_visible_snapshot_without_tg_id",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_browser_independence_guard.py",
        "test_energy_keeps_page_without_tg_id",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_browser_independence_guard.py",
        "test_core_pages_do_not_blank_when_tg_id_missing",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_browser_independence_guard.py",
        "test_tasks_has_browser_fallback_actions",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_browser_independence_guard.py",
        "test_plain_language_rule_is_documented",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_splash_raw_i18n_guard.py",
        "test_i18n_has_human_fallback_instead_of_raw_key",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_splash_raw_i18n_guard.py",
        "test_locale_values_do_not_store_raw_i18n_keys",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_splash_raw_i18n_guard.py",
        "test_splash_uses_named_timeout_constants",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_splash_raw_i18n_guard.py",
        "test_shell_booting_and_ready_css_are_present",
    ),
    (
        "tests/architecture/pwa_shell_cases/case_splash_raw_i18n_guard.py",
        "test_old_public_raw_keys_are_not_locale_values",
    ),
]


@pytest.mark.parametrize(
    ("support_module", "function_name"),
    _CASES,
)
def test_pwa_shell_document_guard_case(
    support_module: str,
    function_name: str,
) -> None:
    module = _load_support_module(support_module)
    target = getattr(module, function_name)
    target()
