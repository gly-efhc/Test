from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def test_orm_0001_columns_guard_1184() -> None:
    root = Path(__file__).resolve().parents[2]
    script = root / "ops" / "routes" / "check_orm_0001_columns.py"
    out = root / "reports" / "generated" / "orm_0001_columns.json"
    result = subprocess.run(
        [sys.executable, "-S", str(script)],
        cwd=root,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr + result.stdout
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["all_required_present"] is True
    assert data["single_release_0001"] is True
    assert data["active_migrations"] == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]
