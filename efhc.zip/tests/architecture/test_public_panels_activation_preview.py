from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_public_panels_component_exists() -> None:
    text = read(
        "frontend/src/components/public/"
        "PublicPanelsActivationPreview.tsx"
    )
    assert 'data-public-panels-preview-cycle="1348"' in text
    assert 'data-panel-activation-preview="100-efhc"' in text
    assert 'data-public-ui-no-admin-internals="true"' in text
    assert "DisplayData rows" in text
    assert "hapticTap" in text


def test_panels_preview_has_durable_route_replacement() -> None:
    text = read("frontend/src/pages/panels.tsx")
    mapping = read(
        "docs/frontend/"
        "FRONTEND_PANELS_EXCHANGE_MVP_REPLACEMENT_MAPPING.md"
    )
    assert "PublicPanelsActivationPreview" not in text
    assert text.count('data-panel-activation-cta="100-efhc"') == 1
    assert "usePanelActivation" in text
    assert "DELETE_AFTER_REPLACEMENT" in mapping


def test_public_panels_does_not__import__admin_layer() -> None:
    text = read(
        "frontend/src/components/public/"
        "PublicPanelsActivationPreview.tsx"
    )
    assert "components/admin" not in text
    assert "Admin" not in text
    assert "endpoint" not in text.lower()
    assert "raw payload" not in text.lower()


def test_panel_interactive_locale_keys_exist() -> None:
    required = {
        "panels.interactive_title",
        "panels.interactive_live",
        "panels.interactive_activation",
        "panels.interactive_active",
        "panels.interactive_archive",
        "panels.interactive_price",
        "panels.interactive_progress",
        "panels.interactive_ready",
        "panels.interactive_not_ready",
        "panels.interactive_total_balance",
        "panels.interactive__main__balance",
        "panels.interactive_bonus_balance",
        "panels.interactive_archived_count",
        "panels.interactive_preview_title",
        "panels.interactive_activate_now",
        "panels.interactive_needs_more",
        "panels.interactive_safe_note",
        "panels.interactive_empty_preview",
    }
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(required.difference(data))
        assert not missing, f"{path.name}: {missing}"


def test_cycle_1348_docs_and_plan() -> None:
    assert (
        ROOT
        / "docs/frontend/"
        / "FRONTEND_PUBLIC_PANELS_ACTIVATION_PREVIEW.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/"
        / "FRONTEND_CYCLE_1348_PUBLIC_PANELS_PREVIEW_AUDIT_V169_27.md"
    ).exists()
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert (
        "1348: Public Panels activation preview. DONE in v169_27."
        in plan
    )
    assert (
        "1349: Public Exchange interactive preview. DONE in v169_28."
        in plan
    )
