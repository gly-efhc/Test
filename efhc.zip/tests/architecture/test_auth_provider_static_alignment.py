"""Guard статической согласованности AuthProvider без app import."""

from __future__ import annotations

from ops.identity.check_auth_provider_static_alignment import (
    build_report,
)


def test_auth_provider_статически_согласован_с_storage_и_contracts() -> None:
    report = build_report()
    assert report["импорт_приложения"] is False
    assert report["количество_provider"] == 8
    assert report["статус"] == "PASS", report["ошибки"]
