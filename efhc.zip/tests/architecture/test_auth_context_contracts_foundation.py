"""Architecture guards provider-neutral contracts цикла 1610."""

from __future__ import annotations

import ast
import inspect
import json
from pathlib import Path

import yaml
from alembic.config import Config
from alembic.script import ScriptDirectory
from app.identity import (
    AuthContextResponse,
    IdentityResolver,
    build_auth_context_contract,
)
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
CONTRACT_MODULES = (
    ROOT / "backend/app/identity/auth_context.py",
    ROOT / "backend/app/identity/resolver_contracts.py",
    ROOT / "backend/app/identity/auth_redaction.py",
)


def _imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    result: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            result.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            result.add(node.module)
    return result


def test_kernel_route_1610_является_exact_primary() -> None:
    task = classify_task(
        "Цикл 1610 — AuthContext contracts, resolver interfaces и "
        "security/redaction skeleton"
    )
    assert task["task_type"] == "auth_context_contracts_foundation"
    assert task["confidence"] >= 0.99
    route = resolve_route(task["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert "backend/app/identity/auth_context.py" in route["docs"]
    restricted = " ".join(route["restricted"])
    assert "PostgreSQL DDL" in restricted
    assert "runtime dependency switch" in restricted


def test_contract_modules_не_импортируют_domain_или_ddl() -> None:
    forbidden_imports = (
        "app.models",
        "app.services",
        "app.routes",
        "app.deps",
        "sqlalchemy",
        "fastapi",
        "alembic",
    )
    forbidden_text = (
        "CREATE TABLE",
        "ALTER TABLE",
        "INSERT INTO",
        "UPDATE users",
        "DELETE FROM",
        "auto_merge=True",
        "global_id = tg_id",
    )
    for path in CONTRACT_MODULES:
        imports = _imports(path)
        assert not any(
            item.startswith(forbidden_imports)
            for item in imports
        ), path
        text = path.read_text(encoding="utf-8")
        assert not any(item in text for item in forbidden_text), path


def test_resolver_interface_принимает_verified_identity() -> None:
    method = IdentityResolver.resolve_verified_identity
    signature = inspect.signature(method)
    assert tuple(signature.parameters) == ("self", "identity")
    assert "VerifiedIdentity" in str(
        signature.parameters["identity"].annotation
    )
    assert "IdentityResolution" in str(signature.return_annotation)


def test_endpoint_schema_не_содержит_tg_id_или_secrets() -> None:
    schema = AuthContextResponse.model_json_schema(
        mode="serialization"
    )
    serialized = json.dumps(schema, ensure_ascii=False)
    assert set(schema["properties"]) == {
        "global_id",
        "provider",
        "roles",
    }
    for forbidden in (
        "tg_id",
        "provider_subject",
        "session_id",
        "wallet_address",
        "proof",
        "token",
        "init_data",
    ):
        assert forbidden not in serialized


def test_active_json_contract_совпадает_с_python_ssot() -> None:
    path = ROOT / "contracts/identity/auth_context_contract_v1.json"
    actual = json.loads(path.read_text(encoding="utf-8"))
    assert actual == build_auth_context_contract()
    assert actual["endpoint_response"]["tg_id"] is False
    assert actual["diagnostics"]["token_redacted"] is True


def test_новый_contract_не_подключён_к_runtime_routes() -> None:
    references: list[str] = []
    for path in (ROOT / "backend/app").rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        if path in CONTRACT_MODULES or path.name == "__init__.py":
            continue
        text = path.read_text(encoding="utf-8")
        if "AuthContextResponse" in text:
            references.append(path.relative_to(ROOT).as_posix())
    assert references == [
        "backend/app/routes/auth_session_routes.py"
    ]

    legacy_deps = (ROOT / "backend/app/deps.py").read_text(
        encoding="utf-8"
    )
    assert "class AuthContext:\n    tg_id: int" in legacy_deps
    assert "from app.identity import AuthContext" not in legacy_deps


def test_logging_redaction_vocabulary_содержит_auth_secrets() -> None:
    text = (ROOT / "backend/app/core/logging_core.py").read_text(
        encoding="utf-8"
    )
    for name in (
        "provider_subject",
        "session_id",
        "access_token",
        "refresh_token",
        "raw_input",
        "wallet_proof",
        "nonce",
    ):
        assert f'"{name}"' in text


def test_auth_context_входит_в_single_release_schema() -> None:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    assert ScriptDirectory.from_config(config).get_heads() == ["0002"]
    versions = sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert versions == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]

def test_routes_yaml_фиксирует_границы_цикла_1610() -> None:
    data = yaml.safe_load(
        (ROOT / "ops/operator_kernel/config/routes.yaml").read_text(
            encoding="utf-8"
        )
    )
    route = data["tasks"]["auth_context_contracts_foundation"]
    validation = " ".join(route["validation"])
    restricted = " ".join(route["restricted"])
    assert "AuthContext не содержит tg_id" in validation
    assert "diagnostics редактируют secrets" in validation
    assert "IdentityResolver implementation" in restricted
    assert "GitHub CI" in restricted


def test_roadmap_подтверждает_цикл_1610() -> None:
    text = (
        ROOT
        / "docs/cycles/"
        "WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md"
    ).read_text(encoding="utf-8")
    assert (
        "Текущий подготовленный цикл после этой редакции: `1611`"
        in text
    )
    assert "Статус gate: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED`" in text
    assert "Следующий цикл после подтверждённого `PG-0 PASS`: `1612`" in text
