from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def test_panels_activate_route_is_present_in_ssot_and_openapi() -> None:
    routes = _read_csv(ROOT / "docs/SSOT/ssot_pack/SSOT_ROUTES.csv")
    keys = {(r["method"], r["path"]) for r in routes}
    assert ("POST", "/panels/activate") in keys

    spec = json.loads(
        (ROOT / "backend/openapi/openapi.json").read_text(
            encoding="utf-8"
        )
    )
    assert "/panels/activate" in spec["paths"]
    assert "post" in spec["paths"]["/panels/activate"]


def test_frontend_panels_page_uses_canonical_activation_route() -> None:
    text = (ROOT / "frontend/src/pages/panels.tsx").read_text(
        encoding="utf-8"
    )
    assert '"/panels/activate"' in text
    assert "/panels/buy/${tg_id}" not in text
