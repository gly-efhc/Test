from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

import pytest
from app.services import watcher_service as ws


@pytest.fixture(autouse=True)
def _stub_identity_boundary(monkeypatch) -> None:
    """Подменить только Telegram/provider resolution в unit-тестах watcher."""

    async def _by_tg(_db, tg_id: int):
        return SimpleNamespace(
            global_id=8_200_000_000 + int(tg_id),
            tg_id=int(tg_id),
        )

    async def _by_global(_db, global_id: int):
        return SimpleNamespace(global_id=int(global_id), tg_id=None)

    async def _retries(_db, *, tx_hash: str) -> int:
        del tx_hash
        return 0

    monkeypatch.setattr(ws, "_find_user_by_tg_id", _by_tg)
    monkeypatch.setattr(ws, "_find_user_by_global_id", _by_global)
    monkeypatch.setattr(ws, "_get_inbox_retries_count", _retries)


@pytest.mark.asyncio
async def test_unknown_jetton_intent_is_blocked_before_confirm(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    async def _not_final(_db, tx_hash: str) -> bool:
        del tx_hash
        return False

    async def _upsert(*args, **kwargs) -> None:
        return None

    async def _record_unmatched(*args, **kwargs) -> None:
        return None

    async def _should_not_confirm(*args, **kwargs):
        raise AssertionError(
            "_confirm_payment_intent must not be called"
        )

    monkeypatch.setattr(ws, "_ton_log_exists_final", _not_final)
    monkeypatch.setattr(ws, "_ton_log_upsert", _upsert)
    monkeypatch.setattr(
        ws, "_record_unmatched_incoming", _record_unmatched
    )
    monkeypatch.setattr(
        ws, "_confirm_payment_intent", _should_not_confirm
    )

    tx = SimpleNamespace(
        tx_hash="tx_unknown_jetton",
        from_address="EQ_FROM",
        to_address="EQ_RECEIVER",
        amount=Decimal("0"),
        amount_asset=1234567,
        asset="JETTON",
        jetton_master="EQ_UNKNOWN",
        memo="EFHC:deposit_efhc:77:8200009001",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == ws.STATUS_PENDING_MANUAL


@pytest.mark.asyncio
async def test_usdt_jetton_intent_passes_d6_amount_to_confirm(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")
    monkeypatch.setattr(
        ws.settings,
        "USDT_JETTON_MASTER_ADDRESS",
        "EQ_USDT_MASTER",
        raising=False,
    )

    captured: dict[str, object] = {}

    async def _not_final(_db, tx_hash: str) -> bool:
        del tx_hash
        return False

    async def _upsert(*args, **kwargs) -> None:
        return None

    async def _confirm(*args, **kwargs) -> str:
        captured.update(kwargs)
        return ws.STATUS_CREDITED

    monkeypatch.setattr(ws, "_ton_log_exists_final", _not_final)
    monkeypatch.setattr(ws, "_ton_log_upsert", _upsert)
    monkeypatch.setattr(ws, "_record_unmatched_incoming", _upsert)
    monkeypatch.setattr(ws, "_get_inbox_retries_count", _not_final)
    monkeypatch.setattr(ws, "_confirm_payment_intent", _confirm)

    tx = SimpleNamespace(
        tx_hash="tx_usdt_jetton",
        from_address="EQ_FROM",
        to_address="EQ_RECEIVER",
        amount=Decimal("0"),
        amount_asset=1234567,
        asset="JETTON",
        jetton_master="EQ_USDT_MASTER",
        memo="prefix EFHC:deposit_efhc:7:8200009001 suffix",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == ws.STATUS_CREDITED
    assert captured["asset"] == "USDT"
    assert str(captured["amount_asset"]) == "1.23456700"
    assert captured["payload"] == "EFHC:deposit_efhc:7:8200009001"


@pytest.mark.asyncio
async def test_process_incoming_tx_already_final_short_circuits(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    async def _final(_db, tx_hash: str) -> bool:
        del tx_hash
        return True

    async def _should_not_upsert(*args, **kwargs) -> None:
        raise AssertionError("_ton_log_upsert must not be called")

    monkeypatch.setattr(ws, "_ton_log_exists_final", _final)
    monkeypatch.setattr(ws, "_ton_log_upsert", _should_not_upsert)

    tx = SimpleNamespace(
        tx_hash="tx_final",
        from_address="EQ_FROM",
        to_address="EQ_RECEIVER",
        amount=Decimal("1.00000000"),
        amount_asset=0,
        asset="TON",
        jetton_master="",
        memo="EFHC:deposit_efhc:7:8200009001",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == "already_final"


@pytest.mark.asyncio
async def test_process_incoming_tx_skips_foreign_wallet_before_logs(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    async def _should_not_run(*args, **kwargs) -> None:
        raise AssertionError("watcher DB helpers must not be called")

    monkeypatch.setattr(ws, "_ton_log_exists_final", _should_not_run)
    monkeypatch.setattr(ws, "_ton_log_upsert", _should_not_run)

    tx = SimpleNamespace(
        tx_hash="tx_foreign",
        from_address="EQ_FROM",
        to_address="EQ_FOREIGN",
        amount=Decimal("1.00000000"),
        amount_asset=0,
        asset="TON",
        jetton_master="",
        memo="EFHC:deposit_efhc:7:8200009001",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == "skip:not_our_wallet"


@pytest.mark.asyncio
async def test_process_incoming_tx_native_ton_intent_uses_ton_amount(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")
    monkeypatch.setattr(
        ws.settings,
        "USDT_JETTON_MASTER_ADDRESS",
        "EQ_USDT_MASTER",
        raising=False,
    )

    captured: dict[str, object] = {}

    async def _not_final(_db, tx_hash: str) -> bool:
        del tx_hash
        return False

    async def _upsert(*args, **kwargs) -> None:
        return None

    async def _confirm(*args, **kwargs) -> str:
        captured.update(kwargs)
        return ws.STATUS_CREDITED

    monkeypatch.setattr(ws, "_ton_log_exists_final", _not_final)
    monkeypatch.setattr(ws, "_ton_log_upsert", _upsert)
    monkeypatch.setattr(ws, "_confirm_payment_intent", _confirm)

    tx = SimpleNamespace(
        tx_hash="tx_ton_intent",
        from_address="EQ_FROM",
        to_address="EQ_RECEIVER",
        amount=Decimal("2.50000000"),
        amount_asset=0,
        asset="TON",
        jetton_master="",
        memo="EFHC:deposit_efhc:11:8200009001",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == ws.STATUS_CREDITED
    assert captured["asset"] == "TON"
    assert str(captured["amount_asset"]) == "2.50000000"
    assert captured["payload"] == "EFHC:deposit_efhc:11:8200009001"


@pytest.mark.asyncio
async def test_process_incoming_tx_confirm_failure_goes_pending_manual(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    calls: dict[str, object] = {}

    async def _not_final(_db, tx_hash: str) -> bool:
        del tx_hash
        return False

    async def _upsert(*args, **kwargs) -> None:
        calls["upsert_status"] = kwargs.get("status")
        calls["upsert_note"] = kwargs.get("note")
        return None

    async def _record_unmatched(*args, **kwargs) -> None:
        calls["reason"] = kwargs.get("reason")
        return None

    async def _boom(*args, **kwargs) -> str:
        raise RuntimeError("confirm boom")

    monkeypatch.setattr(ws, "_ton_log_exists_final", _not_final)
    monkeypatch.setattr(ws, "_ton_log_upsert", _upsert)
    monkeypatch.setattr(
        ws, "_record_unmatched_incoming", _record_unmatched
    )
    monkeypatch.setattr(ws, "_confirm_payment_intent", _boom)

    tx = SimpleNamespace(
        tx_hash="tx_confirm_fail",
        from_address="EQ_FROM",
        to_address="EQ_RECEIVER",
        amount=Decimal("1.00000000"),
        amount_asset=0,
        asset="TON",
        jetton_master="",
        memo="EFHC:deposit_efhc:12:8200009001",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == ws.STATUS_PENDING_MANUAL
    assert calls["reason"] == "intent_confirm_failed"
    assert calls["upsert_status"] == ws.STATUS_PENDING_MANUAL


@pytest.mark.asyncio
async def test_process_incoming_tx_native_ton_intent_failure_records_reason(
    monkeypatch,
) -> None:
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    calls: list[str] = []

    async def _not_final(_db, tx_hash: str) -> bool:
        del tx_hash
        return False

    async def _upsert(*args, **kwargs) -> None:
        if kwargs.get("status"):
            calls.append(str(kwargs["status"]))
        return None

    async def _record_unmatched(*args, **kwargs) -> None:
        calls.append(str(kwargs.get("reason")))
        return None

    async def _boom(*args, **kwargs) -> str:
        raise ValueError("bad confirm")

    monkeypatch.setattr(ws, "_ton_log_exists_final", _not_final)
    monkeypatch.setattr(ws, "_ton_log_upsert", _upsert)
    monkeypatch.setattr(
        ws, "_record_unmatched_incoming", _record_unmatched
    )
    monkeypatch.setattr(ws, "_confirm_payment_intent", _boom)

    tx = SimpleNamespace(
        tx_hash="tx_ton_fail",
        from_address="EQ_FROM",
        to_address="EQ_RECEIVER",
        amount=Decimal("0.50000000"),
        amount_asset=0,
        asset="TON",
        jetton_master="",
        memo="EFHC:deposit_efhc:13:8200009001",
        utime=1,
    )

    st = await ws.process_incoming_tx(object(), tx)
    assert st == ws.STATUS_PENDING_MANUAL
    assert "intent_confirm_failed" in calls
    assert ws.STATUS_PENDING_MANUAL in calls
