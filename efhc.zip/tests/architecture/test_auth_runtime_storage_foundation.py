"""Architecture guards auth-core storage/services цикла 1613."""

from __future__ import annotations

import inspect
import json
from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from app.identity import (
    AuthChallengeService,
    AuthSessionService,
    UserRoleService,
    build_auth_runtime_services_contract,
    build_auth_runtime_storage_contract,
)
from app.models.auth_models import AuthChallenge, AuthSession, UserRole
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
MIGRATION = ROOT / "backend/migrations/versions/0001_initial_release_schema.py"



def test_kernel_route_1613_является_exact_primary() -> None:
    task = classify_task(
        "Цикл 1613 — auth_challenges, auth_sessions, user_roles, "
        "one-time challenge, hashed session и FastAPI dependencies"
    )
    assert task["task_type"] == "auth_runtime_foundation"
    assert task["confidence"] >= 0.99
    route = resolve_route(task["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert "backend/app/models/auth_models.py" in route["allowed_write"]


def test_auth_runtime_входит_в_единую_release_revision() -> None:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    assert script.get_heads() == ["0001"]
    assert script.get_revision("0001").down_revision is None

def test_orm_содержит_три_provider_neutral_auth_table() -> None:
    assert AuthChallenge.__table__.fullname == "efhc_core.auth_challenges"
    assert AuthSession.__table__.fullname == "efhc_core.auth_sessions"
    assert UserRole.__table__.fullname == "efhc_core.user_roles"
    assert "challenge" not in AuthChallenge.__table__.columns
    assert "token" not in AuthSession.__table__.columns
    assert "challenge_hash" in AuthChallenge.__table__.columns
    assert "token_hash" in AuthSession.__table__.columns
    assert "global_id" in UserRole.__table__.columns
    assert "tg_id" not in UserRole.__table__.columns


def test_release_schema_включает_auth_runtime_без_raw_secrets() -> None:
    source = MIGRATION.read_text(encoding="utf-8")
    for table in ("auth_challenges", "auth_sessions", "user_roles"):
        assert f"efhc_core.{table}" in source
    assert "Base.metadata.create_all" in source
    assert "challenge_hash" in AuthChallenge.__table__.columns
    assert "token_hash" in AuthSession.__table__.columns
    assert "challenge" not in AuthChallenge.__table__.columns
    assert "token" not in AuthSession.__table__.columns

def test_storage_contract_фиксирует_one_time_hash_and_global_roles() -> None:
    contract = build_auth_runtime_storage_contract()
    assert contract["цикл"] == 1613
    tables = contract["таблицы"]
    assert tables["auth_challenges"]["one_time"] is True
    assert tables["auth_challenges"]["raw_challenge_stored"] is False
    assert tables["auth_sessions"]["raw_session_token_stored"] is False
    assert tables["user_roles"]["owner"] == "global_id"


def test_services_contract_запрещает_scope_1614_plus() -> None:
    contract = build_auth_runtime_services_contract()
    assert contract["цикл"] == 1613
    assert contract["challenge"]["atomic_consume"] is True
    assert contract["session"]["hashed_token"] is True
    assert contract["roles"]["owner"] == "global_id"
    assert all(contract["запреты"].values())


def test_service_public_signatures_не_принимают_tg_id() -> None:
    for method in (
        AuthChallengeService.issue,
        AuthChallengeService.consume,
        AuthSessionService.issue,
        AuthSessionService.authenticate,
        UserRoleService.list_active,
        UserRoleService.grant,
        UserRoleService.revoke,
    ):
        assert "tg_id" not in inspect.signature(method).parameters


def test_machine_contracts_синхронизированы_с_json() -> None:
    storage = json.loads(
        (
            ROOT
            / "contracts/identity/auth_runtime_storage_contract_v1.json"
        ).read_text(encoding="utf-8")
    )
    services = json.loads(
        (
            ROOT
            / "contracts/identity/auth_runtime_services_contract_v1.json"
        ).read_text(encoding="utf-8")
    )
    assert storage == build_auth_runtime_storage_contract()
    assert services == build_auth_runtime_services_contract()
