from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_deposit_idempotency_uses_admin_db_long_retention() -> None:
    content = read("backend/app/services/efhc_deposits_service.py")

    assert "DEPOSIT_IDEMPOTENCY_SCOPE = \"deposit:efhc\"" in content
    assert "IdempotencyKey" in content
    assert "pg_insert(IdempotencyKey)" in content
    assert 'DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"' in content
    assert "DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None" in content
    assert "expires_at=DEPOSIT_IDEMPOTENCY_EXPIRES_AT" in content
    assert "response_payload_json" in content
    assert "_read_deposit_idempotency_cache" in content
    assert "_store_deposit_idempotency_response" in content
    assert "idempotency_fingerprint_mismatch" in content
    assert "_ttl_seen" not in content


def test_deposit_credit_accepts_and_stores_meta() -> None:
    service = read("backend/app/services/efhc_deposits_service.py")
    tx = read("backend/app/services/transactions_service.py")

    assert "meta=meta" in service
    assert "meta: dict[str, Any] | None = None" in tx
    assert "meta_user: dict[str, Any] = dict(meta or {})" in tx


def test_no_runtime_monetary_ttl_seen_cache() -> None:
    runtime_files = [
        "backend/app/core/system_locks.py",
        "backend/app/services/efhc_deposits_service.py",
        "backend/app/services/transactions_service.py",
    ]
    for rel in runtime_files:
        assert "_ttl_seen" not in read(rel)


def test_kernel_is_mandatory_start_core_navigation() -> None:
    entry = read("docs/AI/READING_ENTRYPOINT.md")
    topic = read("docs/AI/TOPIC_READING_ROUTES.md")
    synaptic = read("docs/AI/ARCHIVE_SYNAPTIC_LINKS.md")
    marker = read("KERNEL.md")

    for content in (entry, topic, synaptic):
        assert "Operator Kernel is a mandatory part" in content
        assert "ops/operator_kernel/cache/file_map.json" in content
        assert "ops/operator_kernel/config/routes.yaml" in content

    assert "Kernel preload (MANDATORY)" in entry
    assert "# Operator Kernel" in marker
    assert "python ops/operator_kernel/file_map.py --refresh" in marker


def test_file_map_warns_on_stale_cache_and_has_refresh_cli() -> None:
    content = read("ops/operator_kernel/file_map.py")

    assert "FILE_MAP_STALE_DAYS = 7" in content
    assert "warn_if_file_map_cache_stale" in content
    assert "--refresh" in content
    assert "file_map.json is older than" in content
    assert "file_map.json is missing" in content
    assert "if __package__ in {None, \"\"}" in content
