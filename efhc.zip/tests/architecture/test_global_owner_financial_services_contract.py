from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _source(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def _function(source: str, name: str) -> ast.AsyncFunctionDef:
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.AsyncFunctionDef) and node.name == name:
            return node
    raise AssertionError(f"missing function: {name}")


def _kwonly_names(node: ast.AsyncFunctionDef) -> set[str]:
    return {arg.arg for arg in node.args.kwonlyargs}


def test_транзакционные_entrypoints_принимают_канонического_owner() -> None:
    source = _source("backend/app/services/transactions_service.py")
    for name in (
        "credit_user_from_bank",
        "credit_user_from_bank_nocommit",
        "credit_user_bonus_from_bank",
        "credit_user_bonus_from_bank_nocommit",
        "debit_user_to_bank",
        "debit_user_to_bank_nocommit",
        "debit_user_bonus_to_bank",
        "spend_user_to_bank_bonus_then__main__nocommit",
    ):
        params = _kwonly_names(_function(source, name))
        assert {"global_id", "tg_id"}.issubset(params), name
    assert "WHERE global_id = :global_id" in source
    assert "tg_id,\n        global_id," in source
    assert 'meta_user["owner_global_id"]' in source


def test_сервисы_используют_global_owner_без_legacy_требования() -> None:
    cases = {
        "backend/app/services/panels_service.py": (
            "activate_panel",
            "create_panel_for_user",
            "archive_panel_for_user",
        ),
        "backend/app/services/withdraw_service.py": (
            "request_withdraw",
            "cancel_withdraw",
        ),
        "backend/app/services/payment_intents_service.py": (
            "create_intent_deposit_by_package",
            "create_intent_deposit_custom",
            "create_intent_shop_external",
        ),
    }
    for relative, names in cases.items():
        source = _source(relative)
        assert "require_legacy_tg_id" not in source
        for name in names:
            params = _kwonly_names(_function(source, name))
            assert "global_id" in params, (relative, name)
            if name != "create_intent_deposit_by_package":
                assert "tg_id" in params, (relative, name)


def test_ton_only_owner_имеет_nullable_provider_колонки() -> None:
    expected = {
        "backend/app/models/transactions_models.py": "Mapped[int | None]",
        "backend/app/models/panels_models.py": "Mapped[int | None]",
        "backend/app/models/withdraw_models.py": "Mapped[int | None]",
        "backend/app/models/payment_intents_models.py": "Mapped[int | None]",
    }
    for relative, marker in expected.items():
        source = _source(relative)
        assert marker in source
        assert "nullable=True" in source
    migration = _source(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    for table in (
        "efhc_transfers_log",
        "panels",
        "withdraw_requests",
        "payment_intents",
    ):
        assert f'"{table}"' in migration
    assert "ALTER COLUMN tg_id DROP NOT NULL" in migration
    assert "CREATE UNIQUE INDEX IF NOT EXISTS" in migration
    assert "uq_payment_intents_global_idempo" in migration
    assert "(global_id, purpose, idempotency_key)" in migration


def test_payment_payload_поддерживает_канонического_global_owner() -> None:
    source = _source("backend/app/services/payment_intents_service.py")
    assert 'owner_token = f"G{int(global_id):010d}"' in source
    parser = _source(
        "backend/app/services/intent_payload_parsing_service.py"
    )
    assert "G[0-9]{10}" in parser
    assert 'result["global_id"]' in parser
