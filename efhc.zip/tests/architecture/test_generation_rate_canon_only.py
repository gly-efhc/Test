from __future__ import annotations

from pathlib import Path

CANON_BASE = "0.00000692"
CANON_VIP = "0.00000741"

RUNTIME_FILES = [
    Path("backend/app/routes/sync_routes.py"),
    Path("backend/app/routes/user_routes.py"),
    Path("backend/app/services/panels_service.py"),
    Path("backend/app/services/energy_service.py"),
    Path("backend/app/core/config_core.py"),
    Path("backend/app/core/system_locks.py"),
    Path("frontend/src/hooks/useSnapshot.ts"),
]

BANNED_TOKENS = [
    "PANEL_GENERATION_NORMAL",
    "PANEL_GENERATION_VIP",
    "daily_generation_base",
    "daily_generation_vip",
    "DAILY_BASE",
    "DAILY_VIP",
]

BANNED_LITERALS = [
    "0.598",
    "0.64",
    "0.597888",
    "0.640224",
]


def test_only_canon_generation_rate_literals_are_used() -> None:
    found_base = False
    found_vip = False
    for path in RUNTIME_FILES:
        text = path.read_text(encoding="utf-8")
        if CANON_BASE in text:
            found_base = True
        if CANON_VIP in text:
            found_vip = True
        for token in BANNED_TOKENS:
            assert token not in text, f"{path}: banned token {token}"
        for literal in BANNED_LITERALS:
            assert (
                literal not in text
            ), f"{path}: banned daily/derived literal {literal}"
    assert found_base, "canon base per-sec rate literal not found"
    assert found_vip, "canon vip per-sec rate literal not found"
