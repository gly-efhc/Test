from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_web_profile_account_center_docs_exist() -> None:
    required = [
        "docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH.md",
        "docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1480_WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH.md",
        "reports/generated/web_profile_account_center_dashboard_polish_v170_56.json",
        "reports/change_cycle_2026-06-07_v170_56_cycle_1480_web_profile_account_center_dashboard_polish.md",
        "frontend/src/components/dashboard/WebProfileAccountDashboard.tsx",
        "tests/architecture/test_web_profile_account_center_dashboard_polish.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(
        read(
            "reports/generated/"
            "web_profile_account_center_dashboard_polish_v170_56.json"
        )
    )
    assert data["cycle"] == 1480
    assert data["archive_version"] == "v170.56"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_web_profile_route_changed"] is True
    assert data["fake_account_history_added"] is False
    assert data["raw_tg_id_visible"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False


def test_dashboard_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/WebProfileAccountDashboard.tsx")
    required = [
        "webProfileAccountDashboardVersion",
        "EFHC_WEB_PROFILE_ACCOUNT_DASHBOARD_V1",
        "data-web-profile-account-dashboard=\"1480\"",
        "data-web-profile-dashboard-truth=\"raw-derived\"",
        "data-web-profile-dashboard-no-write-actions=\"true\"",
        "data-web-profile-dashboard-no-raw-payload=\"true\"",
        "data-web-profile-dashboard-no-debug-payload=\"true\"",
        "SimDashboardToolbar",
        "SimStatCard",
        "SimPanelChrome",
        "SimActivityStrip",
        "SimProgressBar",
    ]
    for marker in required:
        assert marker in src


def test_dashboard_component_is_ui_only() -> None:
    src = read("frontend/src/components/dashboard/WebProfileAccountDashboard.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "fetch(",
        "mutateAsync",
        "tg_id",
        "initData",
        "debug JSON",
        "synthetic_preview",
    ]
    for marker in forbidden:
        assert marker not in src


def test_legacy_dashboard_is_retained_but_not_mounted() -> None:
    page = read("frontend/src/features/profile/WebProfilePage.tsx")
    mapping = read(
        "docs/frontend/"
        "FRONTEND_PROFILE_LEGACY_SURFACE_REPLACEMENT_MAPPING.md"
    )
    assert "WebProfileAccountDashboard" not in page
    assert "ProfileWalletSection" in page
    assert "ProfileHistorySection" in page
    assert "data-profile-primary-navigation" in page
    assert "WebProfileAccountDashboard.tsx" in mapping
    assert "not mounted" in mapping


def test_locale_keys_exist_in_all_languages() -> None:
    required = [
        "profile.dashboard_title",
        "profile.dashboard_subtitle",
        "profile.dashboard_fresh",
        "profile.dashboard_source",
        "profile.dashboard_raw_data",
        "profile.dashboard_derived_display",
        "profile.dashboard_total_balance",
        "profile.dashboard" + "_mai" + "n_" + "balance",
        "profile.dashboard_bonus_balance",
        "profile.dashboard_active_panels",
        "profile.dashboard_account_status_title",
        "profile.dashboard_wallet_title",
        "profile.dashboard_history_title",
        "profile.dashboard_quick_links_title",
        "profile.dashboard_link_profile",
        "profile.dashboard_link_wallet",
        "profile.dashboard_link_history",
        "profile.dashboard_link_faq",
        "profile.dashboard_no_raw_payload",
        "profile.dashboard_no_debug_payload",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in required if key not in data]
        assert not missing, f"{path.name}: {missing}"


def test_web_profile_dashboard_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1480 — Web Profile / Account Center Dashboard Polish",
        ".efhc-web-profile-dashboard",
        ".efhc-web-profile-dashboard__identity",
        ".efhc-web-profile-dashboard__metric-row",
        ".efhc-web-profile-dashboard__quick-links",
        ".efhc-web-profile-dashboard__quick-link",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1480 — Web Profile / Account Center Dashboard Polish" in corpus
    assert "WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH" in corpus
    assert "1481 — Admin Overview Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH.md")
        + read("docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs


def test_operator_kernel_route_exists_for_cycle() -> None:
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "web_profile_account_center_dashboard_polish:" in routes
    assert "WebProfileAccountDashboard.tsx" in routes
    assert "test_web_profile_account_center_dashboard_polish.py" in routes
