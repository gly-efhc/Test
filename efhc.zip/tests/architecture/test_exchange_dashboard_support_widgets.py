from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_exchange_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS.md",
        "docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1479_EXCHANGE_DASHBOARD_SUPPORT_WIDGETS.md",
        "reports/generated/exchange_dashboard_support_widgets_v170_55.json",
        "reports/change_cycle_2026-06-07_v170_55_cycle_1479_exchange_dashboard_support_widgets.md",
        "frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx",
        "tests/architecture/test_exchange_dashboard_support_widgets.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(
        read("reports/generated/exchange_dashboard_support_widgets_v170_55.json")
    )
    assert data["cycle"] == 1479
    assert data["archive_version"] == "v170.55"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_exchange_route_changed"] is True
    assert data["exchange_rate_rule"] == "1 kWh = 1 EFHC"
    assert data["reverse_exchange_added"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["fake_exchange_history_added"] is False
    assert data["fake_timeseries_added"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["grafana_runtime_code_copied"] is False


def test_exchange_dashboard_component_has_required_markers() -> None:
    src = read("frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx")
    required = [
        "exchangeDashboardRuntimeVersion",
        "EFHC_EXCHANGE_DASHBOARD_RUNTIME_V1",
        "data-exchange-dashboard-runtime=\"1479\"",
        "data-exchange-dashboard-rate=\"1-kwh-1-efhc\"",
        "data-exchange-dashboard-one-way=\"kwh-to-efhc-only\"",
        "data-exchange-dashboard-no-reverse=\"true\"",
        "data-exchange-dashboard-no-write-bypass=\"true\"",
        "data-exchange-dashboard-no-fake-history=\"true\"",
        "data-exchange-dashboard-truth=\"raw-derived\"",
        "SimExchangeScopeFilter",
        "SimMiniBarChart",
        "SimActivityStrip",
        "SimProgressBar",
    ]
    for marker in required:
        assert marker in src


def test_exchange_dashboard_component_is_ui_only() -> None:
    src = read("frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "mutateAsync",
        "synthetic_preview",
        "reverseExchange",
        "EFHC -> kWh",
    ]
    for marker in forbidden:
        assert marker not in src


def test_exchange_page_uses_cycle_1556_replacement() -> None:
    page = read("frontend/src/pages/exchange.tsx")
    service_ts = read("frontend/src/services/exchange.service.ts")
    mapping = read(
        "docs/frontend/"
        "FRONTEND_PANELS_EXCHANGE_MVP_REPLACEMENT_MAPPING.md"
    )
    assert "ExchangeDashboardRuntime" not in page
    assert "PublicExchangeInteractivePreview" not in page
    assert page.count("<ExchangePanel") == 1
    assert "useExchangePreview" in page
    assert "useExchangeConvert" in page
    assert "newIdempotencyKey" in page
    assert "EXCHANGE_CONVERT_PATH" in service_ts
    assert "EFHC → kWh" not in page
    assert "INACTIVE_LEGACY_REFERENCE" in mapping


def test_simulation_ui_kit_has_exchange_scope_filter() -> None:
    src = read("frontend/src/components/dashboard/SimulationDashboardUiKit.tsx")
    assert "SimExchangeScopeFilter" in src
    assert "exchange_scope" in src
    assert "sim-exchange-scope" in src


def test_locale_keys_exist_in_all_languages() -> None:
    required = [
        "exchange.dashboard_title",
        "exchange.dashboard_subtitle",
        "exchange.dashboard_fresh",
        "exchange.dashboard_source",
        "exchange.dashboard_raw_data",
        "exchange.dashboard_derived_display",
        "exchange.dashboard_available",
        "exchange.dashboard_max_exchangeable",
        "exchange.dashboard_receive",
        "exchange.dashboard_rate",
        "exchange.dashboard_one_way",
        "exchange.dashboard_no_reverse",
        "exchange.dashboard_flow_title",
        "exchange.dashboard_readiness_title",
        "exchange.dashboard_history_title",
        "exchange.dashboard_scope_label",
        "exchange.dashboard_reset",
        "exchange.dashboard_no_fake_history",
    ]
    for path in (ROOT / "frontend/public/locale").glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = [key for key in required if key not in data]
        assert not missing, f"{path.name}: {missing}"


def test_exchange_dashboard_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1479 — Exchange Dashboard Support Widgets",
        ".efhc-exchange-dashboard-runtime",
        ".efhc-exchange-dashboard-runtime__flow",
        ".efhc-exchange-dashboard-runtime__chips",
        ".efhc-exchange-dashboard-runtime__history",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1479 — Exchange Dashboard Support Widgets" in corpus
    assert "EXCHANGE_DASHBOARD_SUPPORT_WIDGETS" in corpus
    assert "1480 — Web Profile / Account Center Dashboard Polish" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS.md")
        + read(
            "docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS_GRAFANA_ELEMENT_ANALYSIS.md"
        )
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs
