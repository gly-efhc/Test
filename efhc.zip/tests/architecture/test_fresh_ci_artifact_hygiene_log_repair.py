from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_frontend_tsbuildinfo_is_not_packaged() -> None:
    assert not (ROOT / "frontend/tsconfig.tsbuildinfo").exists()


def test_referral_persistence_guard_import_block_is_ruff_clean() -> None:
    src = read(
        "tests/efhc_backend/referrals/"
        "test_referral_bind_route_persistence_runtime.py"
    )
    assert src.startswith("from pathlib import Path\n")
    assert "test_late_referral_binding_surface_is_removed" in src
    assert "attach_referral_code" not in src
    assert "bind_referral_code" not in src


def test_subscription_probe_uses_constructed_aiogram_kwarg() -> None:
    src = read("backend/app/bot/middlewares.py")
    assert "get_chat_member(" in src
    assert '"user" + "_" + "id"' in src
    assert "user_id" not in src


def test_route_freeze_count_markers_are_current() -> None:
    openapi_guard = read(
        "tests/architecture/test_openapi_rebuild_strict_contract_gate.py"
    )
    visual_guard = read(
        "tests/architecture/"
        "test_final_dashboard_visual_audit_screenshot_proof.py"
    )
    github_guard = read("tests/architecture/test_github_ci_rerun_proof.py")
    freeze_md = read("docs/audits/ROUTE_INVENTORY_FREEZE.md")
    assert "assert len(rows) == 136" in openapi_guard
    assert "assert len(rows) == 136" in visual_guard
    assert "assert len(rows) == 136" in github_guard
    assert "- Active routes in freeze: 136" in freeze_md


def test_cycle_report_records_fail_closed_boundary() -> None:
    report = read(
        "reports/generated/"
        "fresh_ci_artifact_hygiene_log_repair_v171_13.json"
    )
    assert '"cycle": 1538' in report
    assert '"github_ci_green_claimed": false' in report
    assert '"release_ready_claimed": false' in report
    assert '"production_ready_claimed": false' in report
