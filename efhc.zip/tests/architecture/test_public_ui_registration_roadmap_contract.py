from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(
        encoding="utf-8", errors="replace"
    )


def test_публичная_палитра_не_применяется_к_admin() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    css = read("frontend/src/styles/globals.css")
    assert 'isAdminRoute ? undefined : "soft-muted-v2"' in layout
    assert 'isAdminRoute ? undefined : "route-harmony-v2"' in layout
    assert '[data-public-color-system="soft-muted-v2"]' in css
    assert '/* Цикл 1635: публичная гармонизация маршрутов v2. */' in css


def test_баланс_адаптируется_но_остаётся_одной_строкой() -> None:
    header = read("frontend/src/components/GlobalHeader.tsx")
    css = read("frontend/src/styles/globals.css")
    assert 'data-header-balance-layout="single-line"' in header
    assert 'data-header-balance-density={balanceDensity}' in header
    for density in ("compact", "dense", "very-dense"):
        assert f'data-header-balance-density="{density}"' in css


def test_live_energy_не_называется_simulation() -> None:
    runtime = read(
        "frontend/src/components/dashboard/EnergyDashboardRuntime.tsx"
    )
    kit = read(
        "frontend/src/components/dashboard/SimulationDashboardUiKit.tsx"
    )
    assert 'eyebrow="EFHC"' in runtime
    assert 'props.eyebrow ?? "EFHC"' in kit
    assert '<details className="efhc-energy-dashboard-runtime__details">' in runtime
    for path in (
        "frontend/src/components/dashboard/EnergyDashboardSandboxPrototype.tsx",
        "frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx",
        "frontend/src/components/dashboard/RanksDashboardSandboxPrototype.tsx",
    ):
        assert 'eyebrow="EFHC Simulation"' in read(path)


def test_browser_login_имеет_компактный_public_contract() -> None:
    source = read("frontend/src/components/BrowserLoginDemo.tsx")
    assert 'data-public-login-layout="compact-inline"' in source


def test_план_1636_1640_и_ядро_1636_синхронизированы() -> None:
    plan = read(
        "docs/cycles/WORK_CYCLES_1636-1640_ACCOUNT_REGISTRATION_CENTER.md"
    )
    for cycle in range(1636, 1641):
        assert f"Цикл {cycle}" in plan
    assert "AccountRegistrationService" in plan
    assert "transactions_service.py" in plan
    assert "Цикл 1636 — ядро единой регистрации" in plan
    core = ROOT / "backend/app/identity/account_registration.py"
    assert core.is_file()
    source = core.read_text(encoding="utf-8")
    assert "class AccountRegistrationService" in source
    assert "caller_migration\": \"bot_webapp_ton" in source


def test_тз_сохранены_и_аудит_фиксирует_три_пути() -> None:
    for name in (
        "TZ_account_registration_service.md",
        "TZ_global_id_migration.md",
    ):
        assert (ROOT / "docs/NORM/TZ" / name).is_file()
    audit = read(
        "docs/audits/TZ_ACCOUNT_REGISTRATION_GLOBAL_ID_GAP_AUDIT_1635.md"
    )
    assert "три места создания `users`" in audit
    assert "неправильный код отклоняется до создания пользователя" in audit
    assert "backend и migration не изменяются" in audit


def test_operator_kernel_разделяет_1635_и_будущую_backend_работу() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    ui = classify_task(
        "Цикл 1635: публичная гармонизация маршрутов и адаптивный баланс"
    )
    assert ui["task_type"] == "public_ui_route_harmony"
    ui_route = resolve_route(ui["task_type"])
    assert ui_route["route_name"] == "public_ui_route_harmony"
    assert ui_route["config_primary"] is True
    assert ui_route["fallback_used"] is False

    registration = classify_task(
        "Цикл 1636: создать единый центр регистрации аккаунта"
    )
    assert registration["task_type"] == "account_registration_center"
    registration_route = resolve_route(registration["task_type"])
    assert registration_route["route_name"] == "account_registration_center"
    assert registration_route["config_primary"] is True
    assert registration_route["fallback_used"] is False


def test_нижняя_навигация_не_изменена() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    expected = {
        "Energy": "/",
        "Panels": "/panels",
        "Exchange": "/exchange",
        "Tasks": "/tasks",
        "Referrals": "/referrals",
        "Ranks": "/ranks",
    }
    for label, route in expected.items():
        assert f'visualLabel: "{label}"' in layout
        assert f'href: "{route}"' in layout


def test_скриншоты_не_включаются_в_тз_или_технические_материалы() -> None:
    assert not list((ROOT / "docs/NORM/TZ").rglob("*.png"))
    cycle = read("docs/cycles/WORK_CYCLE_1635_PUBLIC_ROUTE_HARMONY.md")
    assert "не копируются в development, release или matrix" in cycle.lower()
