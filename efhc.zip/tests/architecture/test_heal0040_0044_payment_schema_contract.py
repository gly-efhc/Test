from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_heal0040_payment_intent_model_allows_package_less_intents() -> None:
    model = _read("backend/app/models/payment_intents_models.py")
    assert "package_id: Mapped[int | None]" in model
    assert "nullable=True" in model
    assert "Do not use 0 as" in model


def test_heal0040_package_and_package_less_sql_paths_are_explicit() -> None:
    service = _read("backend/app/services/payment_intents_service.py")
    assert '"package_id": package_id' in service
    assert "package_id=int(package_id)" in service
    assert service.count("package_id=None") >= 2
    assert '"package_id": int(package_id or 0)' not in service
    assert "package_id=0" not in service


def test_heal0040_existing_db_migration_drops_not_null() -> None:
    migration = _read("backend/migrations/versions/0001_initial_release_schema.py")
    assert "heal0040_package_id_nullable=applied" in migration
    assert "ALTER COLUMN package_id DROP NOT NULL" in migration
    assert "payment_intents.package_id_nullable" in migration


def test_heal0044_direction_width_model_and_migration_are_locked() -> None:
    model = _read("backend/app/models/transactions_models.py")
    migration = _read("backend/migrations/versions/0001_initial_release_schema.py")
    assert "direction: Mapped[str]" in model
    assert "String(24)" in model
    assert "heal0044_direction_varchar24=applied" in migration
    assert "ALTER COLUMN direction TYPE varchar(24)" in migration
    assert "direction_varchar24" in migration
