from __future__ import annotations

import json
from pathlib import Path

import pytest
from tests.screenshot_companion_testkit import (
    assert_screenshot_evidence,
    screenshot_names,
)

ROOT = Path(__file__).resolve().parents[2]
PROOF = ROOT / "reports/generated/browser_admin_visual_button_click_proof_v170_94.json"
SCREENSHOTS_PREFIX = "reports/screenshots/admin_visual_1518"


def test_cycle_1518_visual_proof_report_has_honest_pass_boundary() -> None:
    data = json.loads(PROOF.read_text(encoding="utf-8"))

    assert data["schema"] == "EFHC_BROWSER_ADMIN_VISUAL_BUTTON_CLICK_PROOF_V1"
    assert data["cycle"] == 1518
    assert data["archive_version"] == "v170.94"
    assert data["status"] == "PASSED"
    assert data["routes_total"] == 7
    assert data["routes_ok"] == 7
    assert data["clicks_total"] == 6
    assert data["clicks_ok"] == 6

    boundary = data["proof_boundary"]
    assert boundary["admin_core_browser_visual"] == "VERIFIED_LOCALLY"
    assert boundary["admin_hub_navigation_clicks"] == "VERIFIED_LOCALLY"
    assert boundary["all_admin_routes_exhaustive_clicks"] == "NOT_CLAIMED"
    assert boundary["live_telegram"] == "NOT_VERIFIED"
    assert boundary["real_tonconnect"] == "NOT_VERIFIED"
    assert boundary["github_ci"] == "NOT_VERIFIED"
    assert boundary["release_ready"] == "NOT_CLAIMED"


@pytest.mark.visual_evidence
def test_cycle_1518_visual_proof_screenshots_exist_and_are_non_empty() -> None:
    data = json.loads(PROOF.read_text(encoding="utf-8"))
    for route in data["routes"]:
        assert route["status"] == "OK"
        assert_screenshot_evidence(
            route["screenshot"],
            expected_bytes=route["screenshot_bytes"],
        )

    expected = {
        "admin.png",
        "admin__bank.png",
        "admin__users.png",
        "admin__withdrawals.png",
        "admin__shop.png",
        "admin__tasks.png",
        "admin__reports.png",
    }
    assert expected.issubset(screenshot_names(SCREENSHOTS_PREFIX))


def test_cycle_1518_click_proof_is_limited_to_admin_hub_navigation() -> None:
    data = json.loads(PROOF.read_text(encoding="utf-8"))
    expected_targets = {
        "/admin/users",
        "/admin/bank",
        "/admin/withdrawals",
        "/admin/shop",
        "/admin/tasks",
        "/admin/reports",
    }
    clicks = data["clicks"]
    assert {click["target_href"] for click in clicks} == expected_targets
    assert all(click["from"] == "/admin" for click in clicks)
    assert all(click["status"] == "OK" for click in clicks)
    assert all(click["click_mode"] == "dom_click_due_nextjs_portal" for click in clicks)


def test_cycle_1518_playwright_e2e_has_system_chromium_fallback() -> None:
    conftest = (ROOT / "tests/frontend/e2e/conftest.py").read_text(encoding="utf-8")
    assert "_ChromiumLaunchAdapter" in conftest
    assert "EFHC_PLAYWRIGHT_CHROMIUM_PATH" in conftest
    assert "/usr/bin/chromium" in conftest
    assert "--no-sandbox" in conftest


def test_cycle_1518_local_tonconnect_restore_switch_is_e2e_only() -> None:
    app = (ROOT / "frontend/src/pages/_app.tsx").read_text(encoding="utf-8")
    assert "NEXT_PUBLIC_EFHC_E2E_DISABLE_TONCONNECT_RESTORE" in app
    assert "restoreConnection" in app


def test_cycle_1518_frontend_runtime_hardening_found_by_browser_proof() -> None:
    observability = (
        ROOT / "frontend/src/components/admin/AdminObservabilityTimeseriesDashboardRuntime.tsx"
    ).read_text(encoding="utf-8")
    users = (ROOT / "frontend/src/pages/admin/users.tsx").read_text(encoding="utf-8")

    assert "Array.isArray(snapshot.series?.points)" in observability
    assert "rawPoints.map" in observability
    assert "Array.isArray(data)" in users
    assert "Array.isArray(data?.items)" in users


def test_cycle_1518_docs_do_not_claim_release_or_exhaustive_click_proof() -> None:
    docs = [
        ROOT / "docs/NORM/BROWSER_ADMIN_VISUAL_BUTTON_CLICK_PROOF.md",
        ROOT / "docs/cycles/WORK_CYCLES_1518_BROWSER_ADMIN_VISUAL_CAPTURE_BUTTON_CLICK_PROOF.md",
        ROOT / "reports/change_cycle_2026-06-16_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.md",
    ]
    combined = "\n".join(path.read_text(encoding="utf-8") for path in docs)
    assert "exhaustive all-admin" in combined
    assert "GitHub CI green" in combined
    assert "release-ready" in combined
    assert "does not claim" in combined or "Not claimed" in combined
    assert "VERIFIED_LOCALLY" in combined
