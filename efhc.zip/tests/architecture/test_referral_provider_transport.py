"""Архитектурные замки referral transport и callers циклов 1638–1639."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_telegram_и_ton_api_принимают_referral_start_param() -> None:
    telegram_schema = _read(
        "backend/app/schemas/auth_telegram_schemas.py"
    )
    ton_schema = _read("backend/app/schemas/auth_ton_schemas.py")
    telegram_route = _read(
        "backend/app/routes/auth_telegram_routes.py"
    )
    ton_route = _read("backend/app/routes/auth_ton_routes.py")

    assert "class TelegramAuthSessionIn" in telegram_schema
    assert "referral_start_param" in telegram_schema
    assert "referral_start_param" in ton_schema
    assert "parse_referral_start_param" in telegram_route
    assert "parse_referral_start_param" in ton_route
    assert "referral_start_param=" in telegram_route
    assert "referral_start_param=" in ton_route


def test_browser_pwa_хранит_только_в_session_storage() -> None:
    transport = _read("frontend/src/lib/referral-start-param.ts")
    provider = _read("frontend/src/auth/AuthSessionProvider.tsx")

    assert '"efhc.referral.start.v1"' in transport
    assert "sessionStorage" in transport
    assert "localStorage" not in transport
    assert "rawValueStored: false" in transport
    assert "captureReferralStartParamFromFirstEntry" in provider
    for key in (
        "referral_start_param",
        "tgWebAppStartParam",
        "startapp",
        "start",
        "ref",
    ):
        assert f'"{key}"' in transport


def test_frontend_передаёт_код_telegram_и_ton_и_очищает() -> None:
    telegram = _read("frontend/src/lib/telegram-auth.ts")
    ton = _read("frontend/src/lib/ton-auth.ts")
    service = _read("frontend/src/services/authSession.service.ts")

    assert "readReferralStartParamForLogin" in telegram
    assert "readReferralStartParamForLogin" in ton
    assert "clearReferralStartParam" in telegram
    assert "clearReferralStartParam" in ton
    assert "clearReferralStartParamAfterFinalError" in telegram
    assert "clearReferralStartParamAfterFinalError" in ton
    assert "referral_start_param" in service
    assert "referral_start_param" in ton


def test_существующий_account_не_получает_late_binding() -> None:
    telegram = _read(
        "backend/app/identity/telegram_auth_session.py"
    )
    ton = _read(
        "backend/app/identity/ton_account_registration.py"
    )

    assert "create_new_account(" in telegram
    assert "create_new_account(" in ton
    assert "REFERRAL_CALLER_MIGRATION_PENDING" not in telegram
    assert "REFERRAL_CALLER_MIGRATION_PENDING" not in ton
    assert "_resolve_existing_identity" in telegram
    assert "_resolve_existing_identity" in ton
    assert "existing_legacy_account" in telegram


def test_raw_referral_не_становится_owner_или_idempotency() -> None:
    ingress = _read("backend/app/identity/referral_ingress.py")
    telegram_route = _read(
        "backend/app/routes/auth_telegram_routes.py"
    )
    ton_route = _read("backend/app/routes/auth_ton_routes.py")

    assert "normalized_code" in ingress
    assert "сырой_параметр_не_owner" in ingress
    assert "сырой_параметр_не_idempotency" in ingress
    assert "Idempotency-Key" not in telegram_route
    assert "Idempotency-Key" not in ton_route
