from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PLAN = (
    "docs/cycles/WORK_CYCLES_1321-1350_"
    "ADMIN_RECOVERY_EXTENSION_PLAN.md"
)
REPORT = (
    "reports/change_cycle_2026-05-30_v169_21_cycle_1342_"
    "admin_tasks_execution_trace_boundary.md"
)
AUDIT = (
    "docs/audits/FRONTEND_CYCLE_1342_ADMIN_TASKS_"
    "EXECUTION_TRACE_AUDIT_V169_21.md"
)
ADMIN_DOC = "docs/admin/ADMIN_TASKS_EXECUTION_TRACE_BOUNDARY.md"


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_trace_component_exists() -> None:
    path = ROOT / "frontend/src/components/admin"
    file_path = path / "AdminTasksExecutionTracePanel.tsx"
    assert file_path.exists()
    text = file_path.read_text(encoding="utf-8")
    assert "data-admin-tasks-execution-trace-boundary" in text
    assert "shortKey" in text
    assert "raw payload" in text
    assert "reason=task_bonus" in text


def test_admin_tasks_page_uses_trace_panel() -> None:
    text = read("frontend/src/pages/admin/tasks.tsx")
    assert "AdminTasksExecutionTracePanel" in text
    assert "ADMIN_LOGS_TRANSFERS_PATH" in text
    assert "reason" in text
    assert "task_bonus" in text
    assert "loadTaskTrace" in text


def test_trace_boundary_docs_exist() -> None:
    assert (
        ROOT / "docs/admin/ADMIN_TASKS_EXECUTION_TRACE_BOUNDARY.md"
    ).exists()
    assert (ROOT / AUDIT).exists()


def test_no_ci_workflow_claim_in_report() -> None:
    report = read(REPORT)
    assert "ci.yml` was not changed" in report
    assert "Full GitHub CI" not in report


def test_cycle_plan_shifted_to_reports() -> None:
    plan = read(PLAN)
    done = (
        "1342: Admin Tasks execution trace boundary. "
        "DONE in v169_21."
    )
    assert done in plan
    assert "1343: Reports dashboard visual pass" in plan


def test_public_task_execution_log_stays_forbidden() -> None:
    doc = read(ADMIN_DOC)
    assert "public Tasks execution history" in doc
    assert "raw meta dump" in doc
    assert "raw cursor payload" in doc
