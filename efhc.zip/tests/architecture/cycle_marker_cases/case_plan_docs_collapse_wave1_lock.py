from pathlib import Path


def test_removed_plan_docs_91_130() -> None:
    removed = [
        "docs/HUB_CYCLES_91_100_PLAN.md",
        "docs/POST_HANDOFF_CYCLES_101_110_PLAN.md",
        "docs/POST_HANDOFF_CYCLES_111_120_PLAN.md",
        "docs/PANELS_WORDING_REFACTOR_CYCLES_121_130_PLAN.md",
    ]
    for path in removed:
        assert not Path(path).exists()


def test_work_cycles_records_truth_source() -> None:
    txt = Path("docs/cycles/WORK_CYCLES_101-200.md").read_text(
        encoding="utf-8"
    )
    assert (
        "Main mini-TZ truth source: `docs/cycles/WORK_CYCLES.md`" in txt
    )
    assert "Collapsed plan-docs 91–130" in txt
