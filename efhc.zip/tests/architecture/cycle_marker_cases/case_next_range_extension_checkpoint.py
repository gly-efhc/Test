from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_next_range_extension_checkpoint_documents_exist() -> None:
    for rel in [
        "docs/frontend/PUBLIC_UI_NEXT_RANGE_EXTENSION_CHECKPOINT.md",
        (
            "docs/cycles/"
            "WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md"
        ),
        "docs/audits/NEXT_RANGE_EXTENSION_CHECKPOINT_AUDIT_V169_41.md",
        (
            "reports/change_cycle_2026-06-01_v169_41_cycle_1363_next_"
            "range_extension_checkpoint.md"
        ),
        (
            "reports/generated/"
            "next_range_extension_checkpoint_v169_41.json"
        ),
        "map_element.md",
    ]:
        assert (ROOT / rel).exists(), rel


def test_work_cycle_indexes_keep_checkpoint_history_and_current_lane() -> (
    None
):
    cycles = read("docs/cycles/WORK_CYCLES.md")
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md"
    )
    assert (
        "1363: Next range extension checkpoint. DONE in v169_41."
        in cycles
    )
    assert (
        "1364: Public browser screenshot evidence harness and capture "
        "manifest. DONE in v169_42"
        in cycles
    )
    assert (
        "1365: Public visual beauty pass for Energy, Panels and "
        "Exchange. DONE in v169_43"
        in cycles
    )
    assert (
        "1366: Public visual beauty pass for Tasks, Referrals and "
        "Ranks. DONE in v169_44"
        in cycles
    )
    assert (
        "1367: Profile / Wallet / History /"
        " FAQ visual trust pass. DONE in v169_45"
        in cycles
    )
    assert (
        "1368: HUB / Browser Shop / Withdraw /"
        " Ads visual trust pass. DONE in v169_46"
        in cycles
    )
    assert (
        "Next: `1376+ — blocked until a new audit is supplied in chat`"
        in cycles
    )
    assert (
        "1375: TonConnect /"
        " Wallet UX proof and range closure. DONE in v169_54"
        in cycles
    )
    assert (
        "WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md"
        in cycles
    )
    assert (
        "1363: Next range extension checkpoint. DONE in v169_41."
        in plan
    )


def test_generated_checkpoint_json_is_consistent() -> None:
    data = json.loads(
        read(
            "reports/generated/"
            "next_range_extension_checkpoint_v169_41.json"
        )
    )
    assert data["version"] == "v169_41"
    assert data["cycle"] == 1363
    assert data["status"] == "next_range_extension_checkpoint_complete"
    assert data["next_cycle"].startswith("1364")
    assert data["browser_screenshots_claimed"] is False
    assert data["github_ci_green_claimed"] is False
    assert data["sandbox_runtime_imported"] is False
    assert len(data["public_routes"]) == 14
    assert [item["cycle"] for item in data["planned_cycles"]] == list(
        range(1364, 1376)
    )


def test_ai_and_operator_kernel_know_checkpoint_route() -> None:
    ai = read("docs/AI/AI_DOCS_INDEX.md")
    topic = read("docs/AI/TOPIC_READING_ROUTES.md")
    routes_yaml = read("ops/operator_kernel/config/routes.yaml")
    classifier = read("ops/operator_kernel/task_classifier.py")
    resolver = read("ops/operator_kernel/route_resolver.py")
    for text in [ai, topic, routes_yaml, classifier, resolver]:
        assert (
            "PUBLIC_UI_NEXT_RANGE_EXTENSION_CHECKPOINT.md" in text
            or "public_range_extension_checkpoint" in text
        )
    assert (
        "WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md"
        in routes_yaml
    )
    assert "public_range_extension_checkpoint" in classifier
    assert "public_range_extension_checkpoint" in resolver


def test_sandbox_map_has_next_public_visual_lane_without_runtime_import() -> (
    None
):
    text = read("map_element.md")
    assert "next public visual lane map" in text
    assert "Browser screenshot evidence" in text
    assert "does not import runtime code" in text


def test_checkpoint_preserves_non_claims_and_boundaries() -> None:
    doc = read(
        "docs/frontend/PUBLIC_UI_NEXT_RANGE_EXTENSION_CHECKPOINT.md"
    )
    assert "This checkpoint does not claim" in doc
    assert "GitHub CI green" in doc
    assert "real browser screenshots captured" in doc
    assert "No Vue/Solid/Nuxt/Vanilla" not in doc
    assert "Next.js 16.2.6" in doc
    assert "React 19.2.6" in doc
    assert "Tailwind CSS 4.3.0" in doc
