# Consolidated test support modules

These files are not archived tests. They preserve original test functions after the cycle 1399 user-approved consolidation.
The active pytest entrypoint is the consolidated wrapper in `tests/architecture/`.
