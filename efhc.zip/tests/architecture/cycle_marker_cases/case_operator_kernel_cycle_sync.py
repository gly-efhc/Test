from ops.operator_kernel.patch_planner import plan_patch


def test_operator_kernel_patch_plan_has_cycle_hooks():
    plan = plan_patch(
        "shop payment repair",
        changed_files=["frontend/src/pages/admin/shop.tsx"],
    )
    hooks = "\n".join(plan["cycle_sync_hooks"])
    assert "WORK_CYCLES_1321-1350" in hooks
    assert "QUESTIONS_AND_ANSWERS_REGISTER" in hooks
    assert "HEALER_ATLAS" in hooks
    assert "reports/change_cycle_*.md" in hooks
