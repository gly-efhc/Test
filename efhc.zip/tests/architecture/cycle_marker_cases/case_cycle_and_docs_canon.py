from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BACKEND = ROOT / "backend/app"


def test_cycle_index_has_explicit_control_panel() -> None:
    text = (ROOT / "docs/cycles/WORK_CYCLES.md").read_text(
        encoding="utf-8"
    )
    assert "## Active control block" in text
    assert "- Номера блока: 432-451" in text
    assert "- Выполнено:" in text
    assert "- Осталось:" in text
    assert "- Последний выполненный цикл:" in text
    assert "- Следующий цикл:" in text
    assert "`v*` обозначения — это архивные итерации ZIP" in text


def test_economic_block_history_is_closed_honestly() -> None:
    text = (ROOT / "docs/cycles/WORK_CYCLES_301-400.md").read_text(
        encoding="utf-8"
    )
    assert "## work pass" in text
    assert "- Done: 20/20" in text
    assert "- Remaining: 0/20" in text
    assert "- Last completed work pass" in text
    assert "- Next cycle: none — economic block closed" in text
    assert "- 371/390: done." in text
    assert "- 390/390: done." in text
    assert "- 388 — done — focused economic regression pack" in text
    assert "economic release-gate audit завершён" in text


def test_cycle_numbering_and_terms_are_global() -> None:
    idx = (ROOT / "docs/cycles/WORK_CYCLES.md").read_text(
        encoding="utf-8"
    )
    glossary = (ROOT / "docs/SSOT/TERMS_GLOSSARY.md").read_text(
        encoding="utf-8"
    )
    assert "- Номера блока: 432-451" in idx
    assert "430/500" in idx
    assert "431/500" in idx
    assert "Цикл — один рабочий цикл по задаче." in glossary
    assert "Проход — несколько циклов подряд" in glossary
    assert (
        "Итерация по циклам — срочный диалог вопрос-ответ" in glossary
    )


def test_hardening_docs_are_closed_and_historical() -> None:
    index_text = (ROOT / "docs/cycles/WORK_CYCLES.md").read_text(
        encoding="utf-8"
    )
    range_text = (
        ROOT / "docs/cycles/WORK_CYCLES_301-400.md"
    ).read_text(encoding="utf-8")
    readiness = (ROOT / "docs/GENERAL/READINESS_AUDIT.md").read_text(
        encoding="utf-8"
    )
    gate = (
        ROOT / "docs/GENERAL/BROWSER_SHOP_RELEASE_GATE_V6.md"
    ).read_text(encoding="utf-8")
    assert "residual technical healing plan 02" in index_text
    assert "Cycles 19-20 are closed" in range_text
    assert "hardening line closure" in range_text
    assert "historical" in readiness.lower()
    assert "historical" in gate.lower()


def test_legacy_cycle_markers_and_catalog_are_kept_consistent() -> None:
    zero = (ROOT / "docs/cycles/WORK_CYCLES_0-100.md").read_text(
        encoding="utf-8"
    )
    catalog = (ROOT / "docs/NORM/TESTS_CATALOG.md").read_text(
        encoding="utf-8"
    )
    assert "| 42 | done |" in zero
    assert (
        "EFHC_Bot_v164_39_cycle_docs_canon_and_refresh_wave.zip"
        in catalog
    )
    assert "logs_63368478117.zip" in catalog
    assert "Confirmed current Python test files: **155**" in catalog


def test_bot_admin_entrypoint_cycle_95_lock_still_holds() -> None:
    keyboards = (ROOT / "backend/app/bot/keyboards.py").read_text(
        encoding="utf-8"
    )
    admin_main = (
        ROOT / "backend/app/bot/handlers/admin/admin__main__handlers.py"
    ).read_text(encoding="utf-8")
    admin_hub = (
        ROOT / "backend/app/bot/handlers/admin/admin_hub_handlers.py"
    ).read_text(encoding="utf-8")
    texts = (ROOT / "backend/app/bot/texts.py").read_text(
        encoding="utf-8"
    )
    work = (ROOT / "docs/cycles/WORK_CYCLES_0-100.md").read_text(
        encoding="utf-8"
    )
    assert "def kb_admin_entry()" in keyboards
    assert '"/admin/hub"' in keyboards
    assert '"🛠 Admin Hub"' in keyboards
    assert "kb_admin_entry" in admin_main
    assert "kb_admin_entry" in admin_hub
    assert "Admin Hub" in admin_main
    assert "Admin Hub" in admin_hub
    assert "/admin_hub" in texts
    assert "/admin_shop" not in texts
    assert "| 95 | done | Bot/webapp entrypoint stabilization." in work


def test_payment_withdraw_and_ssot_hardening_locks_remain() -> None:
    pay = (BACKEND / "services/payment_intents_service.py").read_text(
        encoding="utf-8"
    )
    withdraw = (BACKEND / "models/withdraw_models.py").read_text(
        encoding="utf-8"
    )
    rows = list(
        csv.DictReader(
            (ROOT / "docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv").open(
                encoding="utf-8"
            )
        )
    )
    tables = [r for r in rows if r.get("table") != "__schema__"]
    schemas = sorted({r["schema"] for r in tables})
    assert 'PI_TABLE = "efhc_core.payment_intents"' in pay
    assert "{SCHEMA}.payment_intents" not in pay
    assert "payment_intents_service requires efhc_core" in pay
    assert "uq_withdraw_processing_idempotency_key" in withdraw
    assert "uq_withdraw_payout_ref" in withdraw
    assert "ck_withdraw_requests_status_enum" in withdraw
    assert len(tables) == 48
    assert schemas == ["efhc_admin", "efhc_core"]


def test_release_build_script_excludes_artifacts_from_zip() -> None:
    text = (ROOT / "ops/build_efhc_zip.sh").read_text(encoding="utf-8")
    assert "python ops/cleanup_artifacts.py" in text
    assert 'rm -f "${ZIP_OUT}"' in text
    assert '--exclude "${ZIP_OUT}"' in text
    assert "rm -rf artifacts" not in text
    assert "artifacts/" in text


def test_audit__import__and_audit_of_audit_docs_exist() -> None:
    audits = (
        ROOT / "docs/audits/UNIFIED_STRICT_HEAD_AUDIT_2026_04_06.md"
    ).read_text(encoding="utf-8")
    aoa = (ROOT / "docs/audits/AUDIT_OF_AUDIT_2026_04_06.md").read_text(
        encoding="utf-8"
    )
    assert "ECO-001" in audits
    assert "ECO-008" in audits
    assert "ECO-001 — still live" in aoa
    assert "ECO-008 — still live" in aoa


def test_ai_runtime_dependencies_precheck_doc_present() -> None:
    docs = (ROOT / "docs/AI/AI_DOCS_INDEX.md").read_text(
        encoding="utf-8"
    )
    pre = (
        ROOT / "docs/AI/AI_RUNTIME_DEPENDENCIES_PRECHECK.md"
    ).read_text(encoding="utf-8")
    assert "AI_RUNTIME_DEPENDENCIES_PRECHECK.md" in docs
    assert "`pytest`" in pre
    assert "`ruff`" in pre
    assert "`compileall`" in pre
    assert "`sqlalchemy`" in pre
    assert "`aiosqlite`" in pre


def test_bank_reconciliation_table_doc_exists() -> None:
    doc = (
        ROOT / "docs/audits/BANK_RECONCILIATION_TABLE_2026_04_06.md"
    ).read_text(encoding="utf-8")
    assert "Единственное SSOT банка: `efhc_core.bank_balance`." in doc
    assert "`spend_user_to_bank_bonus_then_main`" in doc
    assert "`exchange_partial_available_kwh_to_main`" in doc
    assert "`shop_external`" in doc


def test_cycle_425_concurrency_proof_doc_exists() -> None:
    doc = Path(
        "docs/audits/IDEMPOTENCY_CONCURRENCY_PROOF_2026_04_06.md"
    ).read_text(encoding="utf-8")
    assert "Единственное SSOT банка" in doc
    assert "tests/test_concurrency_exchange_all.py" in doc
    assert "tests/test_economics_transactions.py" in doc


def test_cycle_426_self_healing_audit_doc_exists() -> None:
    doc = Path(
        "docs/audits/SELF_HEALING_PATH_AUDIT_2026_04_06.md"
    ).read_text(encoding="utf-8")
    assert "Energy generation" in doc
    assert "Snapshot resync" in doc
    assert "Scheduler recovery" in doc


def test_frontend_sandbox_and_archive_triage_docs_exist() -> None:
    front = (
        ROOT
        / "docs/audits/FRONTEND_SANDBOX_VISUAL_ACTUALIZATION_2026_04_07.md"
    ).read_text(encoding="utf-8")
    triage = (
        ROOT / "docs/audits/AUDIT_ARCHIVE_TRIAGE_2026_04_07.md"
    ).read_text(encoding="utf-8")
    reaudit = (
        ROOT / "docs/audits/REAUDIT_AFTER_SANDBOX_428_429_2026_04_07.md"
    ).read_text(encoding="utf-8")
    assert "Песочница.zip" in front
    assert "Оставить" in triage
    assert "Удалить после согласования" in triage
    assert "Что вылечено" in reaudit


def test_healer_is_primary_error_store_rule_present() -> None:
    rules = (ROOT / "docs/AI/AI_OPERATOR_RULES_EFHC.md").read_text(
        encoding="utf-8"
    )
    assert (
        "Healer — главное долговременное хранилище всех ошибок проекта"
        in rules
    )


def test_frontend_ui_healing_checklist_docs_exist() -> None:
    checklist = (
        ROOT
        / "docs/audits/FRONTEND_STRICT_AUDIT_HEALING_CHECKLIST_2026_04_07.md"
    ).read_text(encoding="utf-8")
    vismap = (
        ROOT
        / "docs/audits/FRONTEND_VISUAL_INCONSISTENCY_MAP_2026_04_07.md"
    ).read_text(encoding="utf-8")
    assert "BrowserShopPage" in checklist
    assert "BrowserShopPage" in vismap


def test_shop_reporting_and_log_transfer_audits_exist() -> None:
    shop = (
        ROOT
        / "docs/audits/RESIDUAL_SHOP_READ_REPORTING_AUDIT_2026_04_07.md"
    ).read_text(encoding="utf-8")
    logs = (
        ROOT
        / "docs/audits/GITHUB_CI_LOGS_HEALER_TRANSFER_2026_04_07.md"
    ).read_text(encoding="utf-8")
    assert "admin_list_orders" in shop
    assert "LOG_AUDIT_62449907231.md" in logs


def test_watcher_reporting_and_raw_audits_exist() -> None:
    watch = (
        ROOT / "docs/audits/WATCHER_REPORTING_ALIGNMENT_2026_04_07.md"
    ).read_text(encoding="utf-8")
    raw = (
        ROOT / "docs/audits/AUDIT_RAW_DEBT_LIST_2026_04_07.md"
    ).read_text(encoding="utf-8")
    assert "_find_pending_order" in watch
    assert "docs/audits/_raw" in raw


def test_shop_hub_truth_layer_sync_present() -> None:
    hub = (ROOT / "backend/app/routes/hub_routes.py").read_text(
        encoding="utf-8"
    )
    shopfront = (
        ROOT / "backend/app/routes/shopfront_routes.py"
    ).read_text(encoding="utf-8")
    browser = (
        ROOT / "frontend/src/features/browser-shop/BrowserShopPage.tsx"
    ).read_text(encoding="utf-8")
    hub_page = (
        ROOT / "frontend/src/features/hub/HubPage.tsx"
    ).read_text(encoding="utf-8")
    pay = (
        ROOT / "backend/app/services/payment_intents_service.py"
    ).read_text(encoding="utf-8")
    profile = (
        ROOT / "frontend/src/features/profile/WebProfilePage.tsx"
    ).read_text(encoding="utf-8")
    routes = (ROOT / "docs/SSOT/ssot_pack/SSOT_ROUTES.csv").read_text(
        encoding="utf-8"
    )
    assert '"/shop-truth"' in hub
    assert "active_payment" in shopfront
    assert "lifecycle_stage" in pay
    assert "useBrowserShopIntentStatus" in browser
    assert 'data-browser-shop-polling="react-query-5000ms"' in browser
    assert "useHubEfhcHandoff" in hub_page
    assert 'data-hub-visible-action-count="2"' in hub_page
    assert "data-profile-status-model" in profile
    assert "/hub/shop-truth" in routes
