from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_archive_numbering_canon_exists_in_ai_startup_docs():
    operator = read("docs/AI/AI_OPERATOR_RULES_EFHC.md")
    startup = read("docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md")
    norm = read("docs/NORM/ARCHIVE_NUMBERING_CANON.md")

    for text in (operator, startup, norm):
        assert "00" in text
        assert "99" in text
        assert "v(N+1)_00" in text or "v168_00" in text
        assert "vN_100" in text or "three-digit" in text


def test_invalid_aliases_are_mapped_to_canonical_versions():
    audit_path = (
        "docs/audits/" "ARCHIVE_NUMBERING_REGRESSION_AUDIT_V169_02.md"
    )
    audit = read(audit_path)
    assert "v168_100" in audit
    assert "v169_00" in audit
    assert "v168_101" in audit
    assert "v169_01" in audit
    assert "v169_02" in audit


def test_active_cycle_plan_uses_canonical_numbering():
    plan_path = (
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    plan = read(plan_path)
    assert "1321: Users page statistics" in plan
    assert "DONE in v168_99" in plan
    assert "1322: Users table readability" in plan
    assert "DONE in v169_00" in plan
    assert "1323: Bank page statistics" in plan
    assert "DONE in v169_01" in plan


def test_current_corrected_archive_uses_two_digit_suffix():
    generated_path = (
        "reports/generated/"
        "archive_numbering_regression_audit_v169_02.json"
    )
    generated = read(generated_path)
    assert "EFHC_Bot_v169_02_archive" in generated
    assert "current_corrected_archive" in generated
    assert "EFHC_Bot_v169_02_archive_numbering" in generated


def test_work_cycles_records_current_corrected_head():
    cycles = read("docs/cycles/WORK_CYCLES.md")
    assert "v169_02 emergency archive" in cycles
    assert "work pass = `v169_00`" in cycles
    assert "work pass = `v169_01`" in cycles
