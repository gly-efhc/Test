from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXCHANGE = ROOT / "frontend/src/pages/exchange.tsx"
EXCHANGE_SERVICE = ROOT / "frontend/src/services/exchange.service.ts"
PANEL = ROOT / "frontend/src/components/ExchangePanel.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_exchange_surface_is_kwh_to_efhc_only() -> None:
    src = read(EXCHANGE)
    service_ts = read(EXCHANGE_SERVICE)
    panel = read(PANEL)
    full = src + "\n" + panel
    assert 'data-exchange-boundary="kwh-to-efhc-only"' in full
    assert 'data-exchange-rate="1-kwh-1-efhc"' in full
    assert "1 kWh = 1 EFHC" in full
    assert "EXCHANGE_CONVERT_PATH" in service_ts
    assert "EXCHANGE_PREVIEW_PATH" in service_ts


def test_exchange_has_max_and_history_only_as_secondary() -> None:
    src = read(EXCHANGE)
    panel = read(PANEL)
    assert 'data-exchange-max-action="true"' in panel
    assert 'data-exchange-history-link="account-history"' in src
    assert 'openProfile("history")' in src
    assert 'openProfile("wallet")' not in src


def test_exchange_public_surface_has_no_withdraw_or_wallet_flow() -> (
    None
):
    src = read(EXCHANGE)
    banned = [
        "WITHDRAW_REQUEST_PATH",
        "ensureWithdrawRequestCreate",
        "parseWithdrawDetail",
        "useWalletsMe",
        "walletConnected",
        "doWithdraw",
        "action_withdraw",
        "withdraw_title",
        "withdraw_amount_label",
        "openWalletConnect",
        "full_withdraw_screen",
    ]
    for token in banned:
        assert token not in src


def test_exchange_public_surface_has_no_fast_action_overload() -> None:
    panel = read(PANEL)
    banned = [">25%<", ">50%<", ">100%<", "setPct"]
    for token in banned:
        assert token not in panel


def test_exchange_boundary_style_and_docs_exist() -> None:
    css = read(CSS)
    docs = read(PLAN) + "\n" + read(REPORTS)
    assert "work pass" in css
    assert ".efhc-exchange-history-link" in css
    assert "v168_84 / work pass" in docs
    assert "Exchange kWh to EFHC only boundary" in docs
