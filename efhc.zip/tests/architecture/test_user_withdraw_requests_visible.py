from pathlib import Path


def test_profile_history_has_user_withdraw_requests_view() -> None:
    src = Path(
        "frontend/src/components/ProfileModal.tsx"
    ).read_text(encoding="utf-8")
    assert "/withdraw/list?" in src
    assert "withdrawItems" in src
    assert "refreshWithdraws" in src


def test_profile_history_renders_withdraw_requests_block() -> None:
    src = Path(
        "frontend/src/components/profile/ProfileHistorySection.tsx"
    ).read_text(encoding="utf-8")
    assert "Заявки на вывод" in src
    assert "WithdrawHistoryList" in src
