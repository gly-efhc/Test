from __future__ import annotations

import csv
from pathlib import Path


def test_ssot_tables_use_only_two_schemas() -> None:
    csv_path = Path("docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv")
    assert csv_path.exists(), "SSOT_TABLES_ORM.csv missing"
    with csv_path.open(encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))
    schemas = {str(row["schema"]).strip() for row in rows}
    assert schemas == {"efhc_core", "efhc_admin"}
