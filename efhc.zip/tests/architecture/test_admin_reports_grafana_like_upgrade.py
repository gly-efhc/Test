from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_reports_grafana_like_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE.md",
        "docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1482_ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE.md",
        "reports/generated/admin_reports_grafana_like_upgrade_v170_58.json",
        "reports/"
        "change_cycle_2026-06-08_v170_58_cycle_1482_"
        "admin_reports_grafana_like_upgrade.md",
        "tests/architecture/test_admin_reports_grafana_like_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(
        read(
            "reports/generated/"
            "admin_reports_grafana_like_upgrade_v170_58.json"
        )
    )
    assert data["cycle"] == 1482
    assert data["archive_version"] == "v170.58"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_reports_route_changed"] is True
    assert data["source_endpoint"] == "/admin/reports/overview"
    assert data["fake_time_series_removed"] is True
    assert data["synthetic_admin_analytics_added"] is False
    assert data["real_time_series_claimed"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False


def test_admin_reports_component_has_1482_markers() -> None:
    src = read(
        "frontend/src/components/admin/"
        "AdminReportsVisualDashboardPanel.tsx"
    )
    required = [
        "adminReportsGrafanaLikeDashboardVersion",
        "EFHC_ADMIN_REPORTS_GRAFANA_LIKE_V1",
        "data-admin-reports-grafana-like=\"1482\"",
        "data-admin-reports-truth=\"raw-derived\"",
        "data-admin-reports-no-synthetic=\"true\"",
        "data-admin-reports-no-write-actions=\"true\"",
        "data-admin-reports-no-raw-payload=\"true\"",
        "data-admin-reports-no-debug-json=\"true\"",
        "AdminDashboardToolbar",
        "AdminFreshnessBadge",
        "AdminRefreshPicker",
        "AdminTimeRangePicker",
        "AdminPanelChrome",
        "AdminPanelInspectorDrawer",
        "AdminAreaChart",
        "AdminMiniBarChart",
        "AdminHeatStrip",
        "AdminProgressBar",
    ]
    for marker in required:
        assert marker in src


def test_admin_reports_fake_trend_removed() -> None:
    src = read(
        "frontend/src/components/admin/"
        "AdminReportsVisualDashboardPanel.tsx"
    )
    forbidden = [
        "function buildTrend",
        "chartPath(",
        "setZoom",
        "Visual trend",
        "игровых шагов",
        "SVG без chart dependency",
        "synthetic_preview",
    ]
    for marker in forbidden:
        assert marker not in src
    assert "derived snapshot display" in src
    assert "No real time-series claim" in src


def test_admin_reports_component_is_read_only() -> None:
    src = read(
        "frontend/src/components/admin/"
        "AdminReportsVisualDashboardPanel.tsx"
    )
    forbidden = [
        "apiRequest(",
        "fetch(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "mutateAsync",
        "raw payload dump",
        "debug JSON dump",
    ]
    for marker in forbidden:
        assert marker not in src


def test_admin_reports_page_keeps_export_boundary() -> None:
    page = read("frontend/src/pages/admin/reports.tsx")
    assert "AdminReportsVisualDashboardPanel" in page
    assert "AdminReportsExportDownloadPanel" in page
    assert "ADMIN_REPORTS_OVERVIEW_PATH" in page
    assert "AdminRouteHealthStrip" not in page


def test_admin_reports_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1482 — Admin Reports Grafana-like Upgrade",
        ".efhc-admin-reports-grafana-boundary",
        "overflow-wrap: anywhere",
        "data-admin-reports-grafana-like",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1482 — Admin Reports Grafana-like Upgrade" in corpus
    assert "ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE" in corpus
    assert "1483 — Admin Bank Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE.md")
        + read("docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype" in docs
    assert "No Grafana source code" in docs


def test_operator_kernel_route_exists_for_cycle() -> None:
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "admin_reports_grafana_like_upgrade:" in routes
    assert "AdminReportsVisualDashboardPanel.tsx" in routes
    assert "test_admin_reports_grafana_like_upgrade.py" in routes
