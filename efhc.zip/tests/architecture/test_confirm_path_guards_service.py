from __future__ import annotations

from app.services.confirm__path__guards_service import (
    guard_amount_exact_d8,
    guard_asset_exact,
    guard_destination_exact,
)


def test_guard_amount_exact_d8_accepts_exact_match() -> None:
    got = guard_amount_exact_d8(
        amount_asset="4.99000000",
        expected_d8="4.99000000",
    )
    assert got.ok is True


def test_guard_amount_exact_d8_rejects_extra_fraction_even_if_visually_close() -> (
    None
):
    got = guard_amount_exact_d8(
        amount_asset="4.99000001",
        expected_d8="4.99000000",
    )
    assert got.ok is False
    assert got.reason == "AMOUNT_EXACT_MISMATCH_D8"


def test_guard_amount_exact_d8_rejects_nanoton_overflow() -> None:
    got = guard_amount_exact_d8(
        amount_asset="1.500000001",
        expected_d8="1.50000000",
    )
    assert got.ok is False
    assert got.reason == "AMOUNT_SCALE_OVERFLOW_D8"


def test_guard_asset_and_destination_exact() -> None:
    assert (
        guard_asset_exact(asset="USDT", expected_asset="USDT").ok
        is True
    )
    assert (
        guard_asset_exact(asset="TON", expected_asset="USDT").ok
        is False
    )
    assert (
        guard_destination_exact(to_address="EQ1", expected_to="EQ1").ok
        is True
    )
    assert (
        guard_destination_exact(to_address="EQ2", expected_to="EQ1").ok
        is False
    )
