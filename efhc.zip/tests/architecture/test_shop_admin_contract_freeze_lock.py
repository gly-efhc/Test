from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_shop_admin_contract_freeze_doc_exists() -> None:
    path = (
        ROOT / "docs/GENERAL/"
        "SHOP_ADMIN_CONTRACT_FREEZE_IMPLEMENTATION_2026_03_31.md"
    )
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert "/shop/*" in text
    assert "/admin/shop/*" in text
    assert "frozen backend compatibility" in text


def test_openapi_still_keeps_shop_admin_contract_paths() -> None:
    spec = json.loads(
        (ROOT / "backend/openapi/openapi.json").read_text(
            encoding="utf-8"
        )
    )
    assert "/shop/catalog" in spec["paths"]
    assert "/shop/order-external" in spec["paths"]
    assert "/shop/orders" in spec["paths"]
    assert "/shop/purchase-efhc" in spec["paths"]
    assert "/admin/shop/orders" in spec["paths"]
    assert "/admin/shop/items/set-price" in spec["paths"]
