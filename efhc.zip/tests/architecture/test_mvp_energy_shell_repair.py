from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="ignore")


def test_snapshot_chain_is_service_and_schema_driven() -> None:
    service = read("frontend/src/services/snapshot.service.ts")
    hook = read("frontend/src/hooks/useSnapshot.ts")
    keys = read("frontend/src/queries/queryKeys.ts")
    assert 'from "zod"' in service
    assert "syncSnapshotSchema" in service
    assert "apiRequest<unknown>" in service
    assert "syncSnapshotSchema.parse(payload)" in service
    assert '"/sync/me?fresh=1"' in service
    assert "fetchSyncSnapshot" in hook
    assert "apiRequest" not in hook
    assert "queryKeys.snapshot.current" in hook
    assert "snapshot:" in keys


def test_app_propagates_live_preview_and_recoverable_states() -> None:
    app = read("frontend/src/pages/_app.tsx")
    assert (
        'snapshotMode = globalId === null ? "browser-preview" : "live"'
        in app
    )
    assert "snapshotStatus={visibleSnapshotStatus}" in app
    assert "snapshotRefreshing={snapshotRefreshing}" in app
    assert "refreshSnapshot={() =>" in app
    assert "getBrowserFallbackSnapshot" in app


def test_energy_route_is_one_cohesive_mvp_surface() -> None:
    page = read("frontend/src/pages/index.tsx")
    summary = read("frontend/src/components/energy/EnergyMvpSummary.tsx")
    assert "LiveEnergyHeroAndProgress" in page
    assert "EnergyMvpSummary" not in page
    assert "EnergyDashboardRuntime" not in page
    assert "PublicEnergyInteractiveOverview" not in page
    assert 'data-energy-state="loading"' in page
    assert 'data-energy-state="recoverable-error"' in page
    assert 'data-energy-state="content"' in page
    assert 'data-energy-chip-count="3"' in page
    assert 'data-energy-level-name={levelName}' in page
    assert "profile.main_balance" not in page
    assert "profile.bonus_balance" not in page
    assert 'href: "/exchange"' not in page
    assert "sumScaledDown" not in summary
    for marker in [
        "gen_per_sec_effective",
        "active_count",
        'data-energy-chip="generation-rate"',
        'data-energy-chip="active-panels"',
    ]:
        assert marker in page


def test_energy_public_copy_does_not_expose_transport_details() -> None:
    combined = read("frontend/src/pages/index.tsx") + read(
        "frontend/src/components/energy/EnergyMvpSummary.tsx"
    )
    forbidden = [
        "HTTP status",
        "stack trace",
        "failed to fetch",
        "API failed",
        "server error",
        "payload",
        "runtime snapshot",
        "raw snapshot",
        "internal id",
    ]
    for marker in forbidden:
        assert marker.lower() not in combined.lower()


def test_shell_uses_canonical_primitives_and_navigation_order() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    assert "<FrontendShellRoot" in layout
    assert '<FrontendShellFrame className="efhc-independent-shell_frame">' in layout
    assert "<FrontendShellMain" in layout
    expected = [
        'visualLabel: "Energy"',
        'visualLabel: "Panels"',
        'visualLabel: "Exchange"',
        'visualLabel: "Tasks"',
        'visualLabel: "Referrals"',
        'visualLabel: "Ranks"',
    ]
    positions = [layout.index(marker) for marker in expected]
    assert positions == sorted(positions)
    assert "localizedLabel={t(item.key)}" in layout
    assert "aria-label={props.localizedLabel}" in layout
    assert 'aria-current={props.active ? "page" : undefined}' in layout
    assert 'data-nav-key={props.navKey}' in layout
    assert "efhc-game-nav_active-indicator" in layout


def test_next_build_path_is_stable_without_runtime_change() -> None:
    config = read("frontend/next.config.js")
    package = read("frontend/package.json")
    cleaner = read("frontend/scripts/clean-next-build.mjs")
    assert "EFHC_NEXT_BUILD_CPUS" in config
    assert "cpus: buildCpus" in config
    assert "reactStrictMode: true" in config
    assert '"prebuild": "node scripts/prebuild.mjs"' in package
    prebuild = read("frontend/scripts/prebuild.mjs")
    assert "scripts/clean-next-build.mjs" in prebuild
    assert "scripts/verify-production-assets.mjs" in prebuild
    assert (
        '"build": "node scripts/build-next-production.mjs"'
        in package
    )
    driver = read("frontend/scripts/build-next-production.mjs")
    assert '"build", "--webpack"' in driver
    assert '"node_modules/typescript/bin/tsc"' in driver
    assert 'new URL("../.next", import.meta.url)' in cleaner
    assert 'new URL("../tsconfig.tsbuildinfo", import.meta.url)' in cleaner
    assert "recursive: true" in cleaner
    assert "force: true" in cleaner


def test_backend_sync_contract_and_economics_are_unchanged() -> None:
    route = read("backend/app/routes/sync_routes.py")
    assert 'router = APIRouter(prefix="/sync"' in route
    assert '"/user/{tg_id}"' in route
    assert "response_model=SyncSnapshotOut" in route
    assert "svc_generate_for_user" in route
    assert "svc_panels_summary" in route
    assert "svc_preview_exchange" in route
    assert "main_balance: str" in route
    assert "bonus_balance: str" in route
    assert "gen_per_sec_base: str" in route
    assert "gen_per_sec_effective: str" in route


def test_replacement_mapping_preserves_legacy_history() -> None:
    mapping = read(
        "docs/frontend/FRONTEND_ENERGY_MVP_REPLACEMENT_MAPPING.md"
    )
    assert "ACTIVE_REPLACEMENT_MAPPING" in mapping
    assert "EnergyDashboardRuntime" in mapping
    assert "INACTIVE_LEGACY_REFERENCE" in mapping
    assert "PublicEnergyInteractiveOverview" in mapping
    assert "DELETE_AFTER_REPLACEMENT" in mapping
    assert "1 EFHC = 1 kWh" in mapping
