import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

REQUIRED_ENDPOINTS = [
    "/admin/reports/users",
    "/admin/reports/bank",
    "/admin/reports/panels",
    "/admin/reports/withdrawals",
    "/admin/reports/deposits",
]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_all_domain_report_endpoints_in_openapi():
    openapi = json.loads(read("backend/openapi/openapi.json"))
    paths = openapi["paths"]
    for endpoint in REQUIRED_ENDPOINTS:
        assert endpoint in paths, f"Missing endpoint: {endpoint}"
        assert "get" in paths[endpoint], f"Must be GET: {endpoint}"


def test_domain_report_routes_are_read_only():
    routes = read("backend/app/routes/admin_reports_routes.py")
    for verb in [
        "@router.post",
        "@router.put",
        "@router.patch",
        "@router.delete",
    ]:
        assert verb not in routes, (
            "Domain report routes must be read-only. "
            f"Found: {verb}"
        )


def test_domain_report_no_sensitive_fields():
    routes = read("backend/app/routes/admin_reports_routes.py")
    forbidden = [
        "wallet_address",
        "tg_id",
        "initData",
        "telegram_id",
        "raw_payload",
    ]
    for field in forbidden:
        assert field not in routes, (
            "Sensitive field must not be in domain reports: "
            f"{field}"
        )


def test_domain_report_require_admin_on_all():
    routes = read("backend/app/routes/admin_reports_routes.py")
    assert routes.count("Depends(require_admin)") >= 5, (
        "All 5 domain report endpoints must require_admin"
    )


def test_domain_report_statement_timeout():
    routes = read("backend/app/routes/admin_reports_routes.py")
    assert "statement_timeout" in routes
    assert "3000ms" in routes


def test_domain_report_seams_exported():
    seams = read("frontend/src/lib/api/generated/adminSeams.ts")
    for path_const in [
        "ADMIN_REPORTS_USERS_PATH",
        "ADMIN_REPORTS_BANK_PATH",
        "ADMIN_REPORTS_PANELS_PATH",
        "ADMIN_REPORTS_WITHDRAWALS_PATH",
        "ADMIN_REPORTS_DEPOSITS_PATH",
    ]:
        assert path_const in seams, (
            f"Missing seam constant: {path_const}"
        )


def test_domain_report_response_type_exported():
    seams = read("frontend/src/lib/api/generated/adminSeams.ts")
    assert "AdminDomainReportResponse" in seams
    assert "data_kind: 'real_timeseries'" in seams
    assert "synthetic: boolean" in seams
    assert "snapshot: Record<string, number>" in seams


def test_domain_report_route_module_registered():
    init = read("backend/app/routes/__init__.py")
    assert '"admin_reports_routes"' in init


def test_domain_report_truth_markers():
    routes = read("backend/app/routes/admin_reports_routes.py")
    assert 'data_kind: Literal["real_timeseries"]' in routes
    assert "synthetic: bool = False" in routes
    for domain in [
        'domain="users"',
        'domain="bank"',
        'domain="panels"',
        'domain="withdrawals"',
        'domain="deposits"',
    ]:
        assert domain in routes


def test_openapi_snapshot_has_admin_report_ssot_handlers():
    openapi = json.loads(read("backend/openapi/openapi.json"))
    for endpoint in REQUIRED_ENDPOINTS:
        op = openapi["paths"][endpoint]["get"]
        assert op.get("x-efhc-admin-route") is True
        assert op.get("x-efhc-ssot-file") == (
            "backend/app/routes/admin_reports_routes.py"
        )
