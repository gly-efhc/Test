from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DOC = (
    ROOT
    / "docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md"
)
MANIFEST = (
    ROOT / "reports/generated/public_visual_beauty_pass_v169_44.json"
)
CSS = ROOT / "frontend/src/styles/globals.css"
ENGAGEMENT = (
    ROOT / "frontend/src/components/public/PublicEngagementPreview.tsx"
)
TASKS = ROOT / "frontend/src/pages/tasks.tsx"
REFERRALS = ROOT / "frontend/src/pages/referrals.tsx"
RANKS = ROOT / "frontend/src/pages/ranks.tsx"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_tasks_referrals_ranks_visual_artifacts_exist() -> None:
    assert DOC.exists()
    assert MANIFEST.exists()


def test_shared_engagement_preview_has_visual_rail_and_no_admin_leak() -> (
    None
):
    text = read(ENGAGEMENT)
    assert 'data-public-visual-beauty="tasks-referrals-ranks"' in text
    assert "efhc-public-engagement_visual-rail" in text
    assert "efhc-public-engagement_visual-chip" in text
    assert 'data-public-no-admin-diagnostics="true"' in text
    assert "components/admin" not in text


def test_tasks_surface_has_current_card_visual_state() -> None:
    text = read(TASKS)
    assert 'data-public-visual-beauty="tasks-referrals-ranks"' in text
    assert 'data-public-surface="tasks"' in text
    assert 'data-tasks-runtime="cycle-1557-react-query"' in text
    assert "efhc-task-card_state" in text
    assert "is-ready" in text
    assert "is-locked" in text
    assert "is-ad" in text
    assert "is-claim" in text
    assert "PublicEngagementPreview" not in text
    assert "components/admin" not in text


def test_referrals_surface_has_invite_share_visual_structure() -> None:
    text = read(REFERRALS)
    assert 'data-public-visual-beauty="tasks-referrals-ranks"' in text
    assert 'data-public-surface="referrals"' in text
    assert "efhc-referrals-invite-card" in text
    assert "efhc-referrals-share-grid" in text
    assert 'data-referral-action="copy-link"' in text
    assert 'data-referral-action="share-link"' in text
    assert "components/admin" not in text


def test_ranks_surface_has_me_and_vertical_leaderboard_markers() -> None:
    text = read(RANKS)
    assert 'data-public-visual-beauty="tasks-referrals-ranks"' in text
    assert 'data-public-surface="ranks"' in text
    assert "efhc-ranks-me-card" in text
    assert 'data-ranks-leaderboard="top-100"' in text
    assert 'data-ranks-card-layout="vertical-1299"' in text
    assert 'data-ranks-runtime="react-query-kwh-1558"' in text
    assert "components/admin" not in text


def test_visual_css_supports_chips_focus_mobile_and_motion_guard() -> (
    None
):
    text = read(CSS)
    required = [
        "Current public visual beauty pass: Tasks / Referrals / Ranks",
        "efhc-public-engagement_visual-rail",
        "efhc-task-card_visual-rail",
        "efhc-referrals-visual-rail",
        "efhc-ranks-podium-grid",
        'data-ranks-visual-row="leader-card"',
        "focus-visible",
        "prefers-reduced-motion",
        "max-width: 390px",
    ]
    missing = [item for item in required if item not in text]
    assert not missing, missing


def test_generated_manifest_tracks_three_surfaces_and_no_economics_change() -> (
    None
):
    data = json.loads(read(MANIFEST))
    assert data["status"] == "STATIC_VISUAL_POLISH_NO_SCREENSHOT_CLAIM"
    assert data["no_screenshot_claim"] is True
    assert data["economics_changed"] is False
    assert data["backend_changed"] is False
    surfaces = {item["surface"] for item in data["surfaces"]}
    assert surfaces == {"Tasks", "Referrals", "Ranks"}
    for item in data["surfaces"]:
        assert item["public_admin_boundary"] == "public-only"
        assert item["runtime_framework_imported_from_sandbox"] is False


def test_product_doc_keeps_semantic_filename_and_no_fake_browser_claim() -> (
    None
):
    assert (
        DOC.name == "PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md"
    )
    text = read(DOC)
    assert "NO SCREENSHOTS CLAIMED" in text
    forbidden = [
        "SCREENSHOT PROOF COMPLETE",
        "BROWSER VISUAL VERDICT COMPLETE",
        "GITHUB CI GREEN",
    ]
    for claim in forbidden:
        assert claim not in text
