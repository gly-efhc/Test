from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_hub_has_no_public_technical_notice() -> None:
    source = read("frontend/src/features/hub/HubPage.tsx")
    assert "clean_runtime_title" not in source
    assert "clean_runtime_detail" not in source
    assert "GameNotice" not in source
    assert "action_top_up_efhc" in source
    assert "action_vip_nft" in source
    assert 'data-hub-visible-action-count="2"' in source
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in source


def test_energy_keeps_only_contextual_canonical_first_action() -> None:
    page = read("frontend/src/pages/index.tsx")
    summary = read("frontend/src/components/energy/EnergyMvpSummary.tsx")
    assert 'data-first-screen-action-count="1"' in summary
    assert 'href: "/panels"' in summary
    assert 'href: "/exchange"' in summary
    assert 'href: "/hub"' not in summary
    assert 'href: "/web-profile?section=wallet"' not in summary
    assert "gen_per_sec_effective" in page
    assert "main_balance" in summary
    assert "available_kwh" in page


def test_profile_hides_browser_and_pwa_technical_labels() -> None:
    source = read("frontend/src/features/profile/WebProfilePage.tsx")
    assert "profile.guest_user" in source
    assert "profile.independent_shell_badge" not in source
    assert "profile.browser_ready" not in source
    assert '"PWA"' not in source
    assert "LVL {level}" in source
    assert "profile.admin_badge" in source


def test_dark_shell_forces_readable_public_contrast() -> None:
    css = read("frontend/src/styles/globals.css")
    assert "work pass: public dark contrast guardrails" in css
    assert "--tg-text: #fff8df" in css
    assert "--tg-button-text: #15110a" in css
    assert ".efhc-game-header_balance" in css
    assert (
        "display: none"
        not in css.split(
            ".efhc-game-header_balance",
            1,
        )[1].split("}", 1)[0]
    )


def test_local_smoke_test_and_safe_docker_docs_exist() -> None:
    smoke = read("ops/local/runtime_smoke.py")
    runbook = read("docs/GENERAL/LOCAL_ENV_AND_SMOKE_TESTS.md")
    docker_doc = read("docs/GENERAL/DOCKER_LOCAL.md")
    assert "backend health" in smoke
    assert "sync snapshot" in smoke
    assert "tasks catalog" in smoke
    assert "Volume deletion" in runbook
    assert "Do not use `docker compose down -v`" in docker_doc
