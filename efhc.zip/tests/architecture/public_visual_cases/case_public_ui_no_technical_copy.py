from __future__ import annotations

import json
from pathlib import Path

from ops.ci_checks.check_public_ui_forbidden_copy import main, scan


def test_public_ui_has_no_user_visible_technical_copy() -> None:
    findings = scan(Path.cwd())
    assert not findings, "public UI technical copy must stay blocked"


def test_public_ui_copy_guard_rejects_test_violation(tmp_path: Path) -> None:
    policy_dir = tmp_path / "ops" / "policy"
    policy_dir.mkdir(parents=True)
    policy = {
        "version": "test",
        "public_release_allowed_when_matches_found": False,
        "forbidden_terms": ["runtime"],
        "public_scan_paths": ["frontend/public/locale"],
        "file_extensions": [".json"],
        "technical_zone_path_parts": [],
        "locale_key_prefix_exclusions": ["admin."],
    }
    (policy_dir / "public_ui_forbidden_copy.json").write_text(
        json.dumps(policy),
        encoding="utf-8",
    )
    locale_dir = tmp_path / "frontend" / "public" / "locale"
    locale_dir.mkdir(parents=True)
    (locale_dir / "ru.json").write_text(
        json.dumps({"public.bad": "runtime text"}),
        encoding="utf-8",
    )
    assert main(["--root", str(tmp_path)]) == 1
