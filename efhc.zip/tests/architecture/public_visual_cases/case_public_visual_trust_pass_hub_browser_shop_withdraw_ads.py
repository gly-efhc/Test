from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_public_visual_trust_document_and_manifest_exist() -> None:
    assert (
        ROOT
        / "docs/frontend/PUBLIC_VISUAL_TRUST_PASS_HUB_BROWSER_SHOP_WITHDRAW_ADS.md"
    ).exists()
    assert (
        ROOT / "docs/audits/PUBLIC_VISUAL_TRUST_PASS_AUDIT_V169_46.md"
    ).exists()
    assert (
        ROOT / "reports/generated/public_visual_trust_pass_v169_46.json"
    ).exists()

    data = json.loads(
        (
            ROOT
            / "reports/generated/public_visual_trust_pass_v169_46.json"
        ).read_text(encoding="utf-8")
    )
    assert data["cycle"] == 1368
    assert data["archive"] == "v169_46"
    assert data["runtime_framework_migration"] is False
    assert data["backend_changed"] is False
    assert data["economics_changed"] is False
    assert data["admin_pages_changed"] is False
    assert data["screenshots_claimed"] is False
    assert data["github_ci_green_claimed"] is False


def test_hub_browser_shop_withdraw_ads_have_public_trust_markers() -> (
    None
):
    expected = {
        "frontend/src/features/hub/HubPage.tsx": [
            'data-public-surface="hub"',
            'data-hub-runtime="two-canonical-actions"',
            'data-hub-commerce-copy="forbidden-before-exit"',
        ],
        "frontend/src/features/browser-shop/BrowserShopPage.tsx": [
            'data-public-surface="browser-shop"',
            'data-browser-shop-linking="telegram-web-return"',
            'data-browser-shop-polling="react-query-5000ms"',
        ],
        "frontend/src/pages/withdraw.tsx": [
            'data-public-visual-trust="hub-browser-shop-withdraw-ads"',
            'data-public-surface="withdraw"',
            "efhc-withdraw-trust-rail",
        ],
        "frontend/src/pages/ads.tsx": [
            'data-public-visual-trust="hub-browser-shop-withdraw-ads"',
            'data-public-surface="ads"',
            "efhc-ads-trust-rail",
        ],
    }
    for path, markers in expected.items():
        source = read(path)
        for marker in markers:
            assert marker in source, f"Missing {marker!r} in {path}"


def test_visual_trust_css_supports_focus_mobile_and_reduced_motion() -> (
    None
):
    css = read("frontend/src/styles/globals.css")
    for marker in [
        ".efhc-hub-trust-rail",
        ".efhc-browser-shop-trust-rail",
        ".efhc-withdraw-trust-rail",
        ".efhc-ads-trust-rail",
        ".efhc-withdraw-metric-card",
        ".efhc-withdraw-request-card",
        "focus-within",
        "max-width: 430px",
        "prefers-reduced-motion: reduce",
    ]:
        assert marker in css


def test_visual_trust_pass_does_not_import_admin_or_foreign_runtime() -> (
    None
):
    public_files = [
        "frontend/src/features/hub/HubPage.tsx",
        "frontend/src/features/browser-shop/BrowserShopPage.tsx",
        "frontend/src/pages/withdraw.tsx",
        "frontend/src/pages/ads.tsx",
    ]
    forbidden = [
        "components/admin",
        "features/admin",
        "from 'vue'",
        'from "vue"',
        "solid-js",
        "nuxt",
        "@vue",
    ]
    for path in public_files:
        source = read(path).lower()
        for token in forbidden:
            assert (
                token not in source
            ), f"Forbidden token {token!r} in {path}"


def test_hub_shop_withdraw_ads_economics_boundary_manifest() -> None:
    data = json.loads(
        (
            ROOT
            / "reports/generated/public_visual_trust_pass_v169_46.json"
        ).read_text(encoding="utf-8")
    )
    assert {item["route"] for item in data["surfaces"]} == {
        "/hub",
        "/browser-shop",
        "/withdraw",
        "/ads",
    }
    assert data["economics_changed"] is False
    assert data["backend_changed"] is False
