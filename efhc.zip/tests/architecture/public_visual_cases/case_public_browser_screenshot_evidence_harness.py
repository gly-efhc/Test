from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
MANIFEST = (
    ROOT
    / "reports/generated/public_browser_screenshot_capture_manifest_v169_42.json"
)
DOC = (
    ROOT / "docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
)
E2E = (
    ROOT
    / "tests/frontend/e2e/test_public_screenshot_capture_manifest.py"
)

EXPECTED_PUBLIC_ROUTES = {
    "/",
    "/panels",
    "/exchange",
    "/tasks",
    "/referrals",
    "/referrals/active",
    "/referrals/inactive",
    "/ranks",
    "/web-profile",
    "/faq",
    "/hub",
    "/browser-shop",
    "/withdraw",
    "/ads",
}


def test_public_browser_screenshot_harness_artifacts_exist() -> None:
    assert DOC.exists()
    assert MANIFEST.exists()
    assert E2E.exists()


def test_manifest_covers_all_public_routes_and_devices() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert data["status"] == "HARNESS_READY_NO_SCREENSHOTS_CAPTURED"
    assert data["no_screenshot_claim"] is True
    routes = {item["route"] for item in data["public_routes"]}
    assert routes == EXPECTED_PUBLIC_ROUTES
    device_ids = {item["id"] for item in data["devices"]}
    assert {
        "mobile_tma_dark_ru",
        "mobile_tma_light_en",
        "desktop_pwa_dark_en",
    }.issubset(device_ids)
    for item in data["public_routes"]:
        assert item["expected_screenshots"], item["route"]
        assert all(
            path.startswith("reports/screenshots/public_ui/")
            for path in item["expected_screenshots"]
        )


def test_harness_does_not_claim_fake_screenshot_proof() -> None:
    text = DOC.read_text(encoding="utf-8")
    assert "NO SCREENSHOTS CLAIMED" in text
    assert "HARNESS_READY_NO_SCREENSHOTS_CAPTURED" in text
    forbidden_claims = [
        "Status: SCREENSHOT PROOF COMPLETE",
        "Status: BROWSER VISUAL VERDICT COMPLETE",
        "Status: GITHUB CI GREEN",
    ]
    for claim in forbidden_claims:
        assert claim not in text
    assert "Forbidden claim now" in text


def test_e2e_capture_is_env_gated_and_writes_png_evidence() -> None:
    text = E2E.read_text(encoding="utf-8")
    assert "EFHC_CAPTURE_SCREENSHOTS" in text
    assert "EFHC_SCREENSHOT_OUTPUT_DIR" in text
    assert ".png" in text
    assert "page.screenshot" in text
    assert "install_common_public_api_mocks" in text


def test_product_filenames_keep_semantic_non_cycle_labels() -> None:
    # cycle labels are allowed in docs/cycles, docs/audits and reports
    # only;
    # this harness file must remain semantic.
    assert not re.search(
        r"(?:cycle_?|_)(13\d{2}|v169_\d+)", DOC.name, re.I
    )
    assert not re.search(
        r"(?:cycle_?|_)(13\d{2}|v169_\d+)", E2E.name, re.I
    )
