from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]

PUBLIC_QA_ROUTES = [
    "`/`",
    "`/panels`",
    "`/exchange`",
    "`/tasks`",
    "`/referrals`",
    "`/referrals/active`",
    "`/referrals/inactive`",
    "`/ranks`",
    "`/web-profile`",
    "`/faq`",
    "`/hub`",
    "`/browser-shop`",
    "`/withdraw`",
    "`/ads`",
]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_public_ui_qa_preparation_documents_exist() -> None:
    for rel in [
        "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
        "docs/audits/PUBLIC_UI_QA_PREPARATION_AUDIT_V169_39.md",
        (
            "reports/change_cycle_2026-06-01_v169_39_cycle_1361_public_ui_"
            "qa_preparation.md"
        ),
        "reports/generated/public_ui_qa_preparation_v169_39.json",
    ]:
        assert (ROOT / rel).exists(), rel


def test_public_ui_qa_preparation_scope_has_all_routes() -> None:
    doc = read("docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md")
    for route in PUBLIC_QA_ROUTES:
        assert route in doc, route
    assert "READY FOR SCREENSHOT CAPTURE" in doc
    assert "no actual screenshot verdict is claimed" in doc


def test_locale_common_error_keys_are_complete() -> None:
    locale_files = sorted(
        (ROOT / "frontend/public/locale").glob("*.json")
    )
    assert len(locale_files) == 13
    for path in locale_files:
        data = json.loads(path.read_text(encoding="utf-8"))
        assert "common.session_expired" in data, path.name
        assert "common.load_error" in data, path.name
        assert data["common.session_expired"].strip(), path.name
        assert data["common.load_error"].strip(), path.name


def test_public_ui_e2e_interaction_smokes_are_not_render_only() -> None:
    for rel, marker in [
        (
            "tests/frontend/e2e/test_exchange_convert_flow.py",
            'page.route("**/api/exchange/convert", on_convert)',
        ),
        (
            "tests/frontend/e2e/test_hub_deposit_button.py",
            "POST /api/hub/efhc-handoff was not called",
        ),
        (
            "tests/frontend/e2e/test_withdraw_request_flow.py",
            "POST /api/withdraw/request was not called",
        ),
    ]:
        text = read(rel)
        assert marker in text, rel
        assert 'posted["done"]' in text, rel
        assert ".click()" in text, rel


def test_offline_html_is_multilingual_fallback() -> None:
    text = read("frontend/public/offline.html")
    assert "No connection" in text
    assert "Нет соединения" in text
    assert "Sin conexión" in text
    assert "Keine Verbindung" in text
    assert 'lang="mul"' in text
