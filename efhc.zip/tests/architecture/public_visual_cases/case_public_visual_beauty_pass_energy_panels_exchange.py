from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DOC = (
    ROOT
    / "docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_ENERGY_PANELS_EXCHANGE.md"
)
MANIFEST = (
    ROOT / "reports/generated/public_visual_beauty_pass_v169_43.json"
)
CSS = ROOT / "frontend/src/styles/globals.css"
ENERGY = (
    ROOT
    / "frontend/src/components/public/PublicEnergyInteractiveOverview.tsx"
)
PANELS = (
    ROOT
    / "frontend/src/components/public/PublicPanelsActivationPreview.tsx"
)
EXCHANGE = (
    ROOT
    / "frontend/src/components/public/PublicExchangeInteractivePreview.tsx"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_visual_beauty_artifacts_exist() -> None:
    assert DOC.exists()
    assert MANIFEST.exists()


def test_energy_panels_exchange_have_visual_beauty_markers() -> None:
    for path, surface in [
        (ENERGY, "energy"),
        (PANELS, "panels"),
        (EXCHANGE, "exchange"),
    ]:
        text = read(path)
        assert (
            'data-public-visual-beauty="energy-panels-exchange"' in text
        )
        assert f'data-public-surface="{surface}"' in text
        assert "_visual-rail" in text
        assert "_visual-chip" in text
        assert "components/admin" not in text


def test_visual_css_supports_readable_chips_focus_and_mobile() -> None:
    text = read(CSS)
    required = [
        "efhc-public-energy-interactive_visual-rail",
        "efhc-public-panels-preview_visual-rail",
        "efhc-public-exchange-preview_visual-rail",
        "focus-visible",
        "prefers-reduced-motion",
        "max-width: 390px",
    ]
    missing = [item for item in required if item not in text]
    assert not missing, missing


def test_generated_manifest_tracks_three_surfaces_and_no_economics_change() -> (
    None
):
    data = json.loads(read(MANIFEST))
    assert data["status"] == "STATIC_VISUAL_POLISH_NO_SCREENSHOT_CLAIM"
    assert data["no_screenshot_claim"] is True
    assert data["economics_changed"] is False
    surfaces = {item["surface"] for item in data["surfaces"]}
    assert surfaces == {"Energy", "Panels", "Exchange"}
    for item in data["surfaces"]:
        assert item["public_admin_boundary"] == "public-only"
        assert item["runtime_framework_imported_from_sandbox"] is False


def test_product_doc_keeps_semantic_filename_and_no_fake_browser_claim() -> (
    None
):
    assert (
        DOC.name
        == "PUBLIC_VISUAL_BEAUTY_PASS_ENERGY_PANELS_EXCHANGE.md"
    )
    text = read(DOC)
    assert "NO SCREENSHOTS CLAIMED" in text
    forbidden = [
        "SCREENSHOT PROOF COMPLETE",
        "BROWSER VISUAL VERDICT COMPLETE",
        "GITHUB CI GREEN",
    ]
    for claim in forbidden:
        assert claim not in text
