from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_public_ui_sandbox_audit_docs_exist() -> None:
    assert (
        ROOT
        / "docs/frontend/"
        / "FRONTEND_PUBLIC_INTERACTIVITY_SANDBOX_AUDIT.md"
    ).exists()
    assert (
        ROOT
        / "docs/frontend/"
        / "FRONTEND_PUBLIC_INTERACTIVITY_IMPLEMENTATION_ROADMAP.md"
    ).exists()
    assert (
        ROOT
        / "docs/admin/ADMIN_TASKS_REPORTS_DIAGNOSTICS_PROOF_PASS.md"
    ).exists()


def test_sandbox_sources_are_recorded() -> None:
    text = read(
        "docs/frontend/"
        "FRONTEND_PUBLIC_INTERACTIVITY_SANDBOX_AUDIT.md"
    )
    for marker in (
        "typescript-template-master.zip",
        "nuxt-telegram-mini-app-main.zip",
        "vanillajs-template-master.zip",
        "vuejs-template-master.zip",
        "solidjs-template-master.zip",
        "Песочница.xz",
    ):
        assert marker in text


def test_public_ui_adoption_decision_is_safe() -> None:
    text = read(
        "docs/frontend/"
        "FRONTEND_PUBLIC_INTERACTIVITY_SANDBOX_AUDIT.md"
    )
    for marker in (
        "Theme / Viewport CSS vars",
        "BackButton helper",
        "MainButton intent pattern",
        "Haptic feedback wrapper",
        "DisplayData rows",
        "ErrorBoundary / retry surface",
    ):
        assert marker in text
    for marker in (
        "Nuxt runtime",
        "Vue runtime",
        "Solid runtime",
        "jQuery view layer",
    ):
        assert marker in text


def test_operator_kernel_public_ui_route_exists() -> None:
    classifier = read("ops/operator_kernel/task_classifier.py")
    resolver = read("ops/operator_kernel/route_resolver.py")
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "public_ui_interactivity" in classifier
    assert "public_ui_interactivity" in resolver
    assert "public_ui_interactivity:" in routes
    assert "frontend/src/pages/admin/*" in resolver
    assert "ci.yml" in resolver


def test_cycle_plan_moves_to_public_energy() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1346: Tasks/Reports/Diagnostics proof pass" in text
    assert "DONE in v169_25" in text
    assert "1347: Public Energy interactive overview" in text
    assert "NEXT after v169_25" in text


def test_ci_manual_boundary_unchanged() -> None:
    text = read("docs/AI/AI_OPERATOR_RULES_EFHC.md")
    assert "CI files are manual-control" in text
    report = read(
        "reports/change_cycle_2026-05-31_v169_25_cycle_1346_public_ui_"
        "sandbox_audit.md"
    )
    assert "`ci.yml` was not changed" in report
