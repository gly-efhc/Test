from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]

PUBLIC_ROUTES = [
    "/",
    "/panels",
    "/exchange",
    "/tasks",
    "/referrals",
    "/referrals/active",
    "/referrals/inactive",
    "/ranks",
    "/web-profile",
    "/faq",
    "/hub",
    "/browser-shop",
    "/withdraw",
    "/ads",
]
PAGE_MAP = {
    "/": "frontend/src/pages/index.tsx",
    "/panels": "frontend/src/pages/panels.tsx",
    "/exchange": "frontend/src/pages/exchange.tsx",
    "/tasks": "frontend/src/pages/tasks.tsx",
    "/referrals": "frontend/src/pages/referrals.tsx",
    "/referrals/active": "frontend/src/pages/referrals/active.tsx",
    "/referrals/inactive": "frontend/src/pages/referrals/inactive.tsx",
    "/ranks": "frontend/src/pages/ranks.tsx",
    "/web-profile": "frontend/src/pages/web-profile.tsx",
    "/faq": "frontend/src/pages/faq.tsx",
    "/hub": "frontend/src/pages/hub.tsx",
    "/browser-shop": "frontend/src/pages/browser-shop.tsx",
    "/withdraw": "frontend/src/pages/withdraw.tsx",
    "/ads": "frontend/src/pages/ads.tsx",
}
BACKEND_MARKERS = {
    "/": ["/sync", "/user/me/panels-summary"],
    "/panels": ["/user/me/panels-summary", "/panels/activate"],
    "/exchange": ["EXCHANGE_CONVERT_PATH", "/exchange/preview"],
    "/tasks": ["/tasks/catalog", "/tasks/my", "/tasks/claim"],
    "/referrals": ["getReferralStats", "/referrals/active/me"],
    "/referrals/active": ["ReferralListPage"],
    "/referrals/inactive": ["ReferralListPage"],
    "/ranks": ["/ranks/my-plus-top/me", "/ranks/top/me"],
    "/web-profile": ["WebProfilePage"],
    "/faq": ["FaqVerticalTree", "useFaqCatalog"],
    "/hub": ["HUB_EFHC_HANDOFF_PATH", "/hub/efhc-handoff"],
    "/browser-shop": [
        "SHOPFRONT_BOOTSTRAP_PATH",
        "SHOPFRONT_CATALOG_PATH",
    ],
    "/withdraw": ["WITHDRAW_REQUEST_PATH", "/withdraw/request"],
    "/ads": ["/tasks"],
}


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_public_regression_proof_documents_exist() -> None:
    for rel in [
        "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
        "docs/audits/PUBLIC_UI_REGRESSION_PROOF_AUDIT_V169_40.md",
        (
            "reports/change_cycle_2026-06-01_v169_40_cycle_1362_public_ui_"
            "regression_proof_pass.md"
        ),
        "reports/generated/public_ui_regression_proof_v169_40.json",
    ]:
        assert (ROOT / rel).exists(), rel


def test_public_regression_proof_matrix_covers_all_public_routes() -> (
    None
):
    doc = read("docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md")
    for route in PUBLIC_ROUTES:
        assert f"`{route}`" in doc, route
    assert (
        "page, component family, backend road, SSOT/NORM anchor" in doc
    )
    assert "No `FAIL` surfaces" in doc
    assert "does **not** claim" in doc


def test_generated_public_regression_json_matches_scope() -> None:
    data = json.loads(
        read(
            "reports/generated/public_ui_regression_proof_v169_40.json"
        )
    )
    assert data["version"] == "v169_40"
    assert data["cycle"] == 1362
    assert data["browser_screenshots_claimed"] is False
    assert data["github_ci_green_claimed"] is False
    assert data["sandbox_runtime_imported"] is False
    routes = [item["route"] for item in data["surfaces"]]
    assert routes == PUBLIC_ROUTES
    assert all(
        item["verdict"].startswith("STATIC_PROOF_PASS")
        for item in data["surfaces"]
    )


def test_public_pages_exist_and_keep_expected_backend_markers() -> None:
    for route, rel in PAGE_MAP.items():
        assert (ROOT / rel).exists(), f"{route} -> {rel}"
        text = read(rel)
        combined = text
        combined += read(
            "frontend/src/lib/api/generated/economicUserSeams.ts"
        )
        if route == "/":
            combined += read("frontend/src/hooks/useSnapshot.ts")
            combined += read("frontend/src/services/snapshot.service.ts")
            combined += read("frontend/src/pages/panels.tsx")
            combined += read("frontend/src/services/panels.service.ts")
        if route == "/panels":
            combined += read("frontend/src/services/panels.service.ts")
        if route == "/exchange":
            combined += read("frontend/src/services/exchange.service.ts")
        if route == "/tasks":
            combined += read("frontend/src/services/tasks.service.ts")
        if route == "/referrals":
            combined += read("frontend/src/services/referrals.service.ts")
            combined += read("frontend/src/queries/useReferrals.ts")
        if route == "/ranks":
            combined += read("frontend/src/services/ranks.service.ts")
            combined += read("frontend/src/queries/useRanks.ts")
        if route == "/withdraw":
            combined += read("frontend/src/services/withdrawals.service.ts")
        if route == "/hub":
            combined += read("frontend/src/features/hub/HubPage.tsx")
            combined += read("frontend/src/services/hub.service.ts")
            combined += read("frontend/src/queries/useHub.ts")
        if route == "/browser-shop":
            combined += read(
                "frontend/src/features/browser-shop/BrowserShopPage.tsx"
            )
            combined += read(
                "frontend/src/services/browserShop.service.ts"
            )
        if route == "/web-profile":
            combined += read(
                "frontend/src/features/profile/WebProfilePage.tsx"
            )
        if route in ("/referrals/active", "/referrals/inactive"):
            combined += read(
                "frontend/src/components/referrals/ReferralListPage.tsx"
            )
        for marker in BACKEND_MARKERS[route]:
            assert marker in combined, f"{route} missing {marker}"


def test_public_proof_updates_cycle_and_ai_indexes() -> None:
    cycles = read("docs/cycles/WORK_CYCLES.md")
    ai = read("docs/AI/AI_DOCS_INDEX.md")
    assert (
        "1362: Public UI regression proof pass. DONE in v169_40"
        in cycles
    )
    assert "PUBLIC_UI_REGRESSION_PROOF_PASS.md" in ai
    assert "public_ui_regression_proof_v169_40.json" in ai


def test_public_proof_does_not_import_sandbox_runtime_or_touch_ci() -> (
    None
):
    doc = read("docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md")
    assert "No Vue/Solid/Nuxt/Vanilla runtime code" in doc
    assert "CI configuration" in doc
    assert (ROOT / "ci.yml").exists()
