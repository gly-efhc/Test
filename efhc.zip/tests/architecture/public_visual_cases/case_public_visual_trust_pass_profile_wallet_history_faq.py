from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DOC = (
    ROOT
    / "docs/frontend/PUBLIC_VISUAL_TRUST_PASS_PROFILE_WALLET_HISTORY_FAQ.md"
)
MANIFEST = (
    ROOT / "reports/generated/public_visual_trust_pass_v169_45.json"
)
CSS = ROOT / "frontend/src/styles/globals.css"
PROFILE = ROOT / "frontend/src/features/profile/WebProfilePage.tsx"
TRUST = (
    ROOT / "frontend/src/components/public/PublicProfileTrustLayer.tsx"
)
WALLET = (
    ROOT / "frontend/src/components/profile/ProfileWalletSection.tsx"
)
HISTORY = (
    ROOT / "frontend/src/components/profile/ProfileHistorySection.tsx"
)
FAQ = ROOT / "frontend/src/pages/faq.tsx"
FAQ_TREE = ROOT / "frontend/src/components/faq/FaqVerticalTree.tsx"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_profile_wallet_history_faq_visual_trust_artifacts_exist() -> (
    None
):
    assert DOC.exists()
    assert MANIFEST.exists()


def test_profile_surface_has_visual_trust_markers_and_no_admin_leak() -> (
    None
):
    text = read(PROFILE)
    assert (
        'data-public-visual-trust="profile-wallet-history-faq"' in text
    )
    assert 'data-public-surface="web-profile"' in text
    assert "efhc-profile-tabs" in text
    assert "data-profile-trust-tab" in text
    assert "WebProfileAccountDashboard" not in text
    assert "PublicProfileTrustLayer" not in text
    assert "components/admin" not in text


def test_public_profile_trust_layer_has_visual_rail_and_chips() -> None:
    text = read(TRUST)
    assert (
        'data-public-profile-visual-trust-layer="profile-wallet-'
        'history"'
        in text
    )
    assert "efhc-public-trust_visual-rail" in text
    assert "efhc-public-trust_visual-chip" in text
    assert 'data-public-no-admin-diagnostics="true"' in text
    assert "components/admin" not in text


def test_wallet_and_history_sections_have_trust_rails() -> None:
    wallet = read(WALLET)
    history = read(HISTORY)
    assert 'data-public-surface="wallet"' in wallet
    assert "efhc-wallet-trust-rail" in wallet
    assert 'data-wallet-trust-rail="connect-primary-proof"' in wallet
    assert 'data-public-surface="history"' in history
    assert "efhc-history-trust-rail" in history
    assert (
        'data-history-trust-rail="balances-filters-withdraws"'
        in history
    )
    assert "components/admin" not in wallet + history


def test_faq_surface_preserves_vertical_tree_and_trust_rail() -> None:
    faq = read(FAQ)
    tree = read(FAQ_TREE)
    assert 'data-public-surface="faq"' in faq
    assert "efhc-faq-trust-rail" in faq
    assert 'data-faq-trust-rail="sections-search-tree"' in faq
    assert (
        'data-faq-visual-trust-tree="profile-wallet-history-faq"'
        in tree
    )
    assert "FaqVerticalTree" in faq
    assert "components/admin" not in faq + tree


def test_visual_css_supports_trust_rails_focus_mobile_and_motion_guard() -> (
    None
):
    text = read(CSS)
    required = [
        (
            "Current public visual trust pass: Profile / Wallet /"
            " History / FAQ"
        ),
        "efhc-profile-trust-rail",
        "efhc-public-trust_visual-rail",
        "efhc-wallet-trust-rail",
        "efhc-history-trust-rail",
        "efhc-faq-trust-rail",
        'data-faq-visual-trust-tree="profile-wallet-history-faq"',
        "focus-visible",
        "prefers-reduced-motion",
        "max-width: 390px",
    ]
    missing = [item for item in required if item not in text]
    assert not missing, missing


def test_generated_manifest_tracks_four_surfaces_and_no_runtime_claim() -> (
    None
):
    data = json.loads(read(MANIFEST))
    assert (
        data["status"]
        == "STATIC_VISUAL_TRUST_POLISH_NO_SCREENSHOT_CLAIM"
    )
    assert data["no_screenshot_claim"] is True
    assert data["backend_changed"] is False
    assert data["economics_changed"] is False
    assert data["runtime_framework_imported_from_sandbox"] is False
    assert {item["surface"] for item in data["surfaces"]} == {
        "Profile",
        "Wallet",
        "History",
        "FAQ",
    }


def test_product_doc_keeps_semantic_filename_and_no_fake_browser_claim() -> (
    None
):
    assert (
        DOC.name
        == "PUBLIC_VISUAL_TRUST_PASS_PROFILE_WALLET_HISTORY_FAQ.md"
    )
    text = read(DOC)
    assert "NO SCREENSHOTS CLAIMED" in text
    forbidden = [
        "SCREENSHOT PROOF COMPLETE",
        "BROWSER VISUAL VERDICT COMPLETE",
        "GITHUB CI GREEN",
    ]
    for claim in forbidden:
        assert claim not in text
