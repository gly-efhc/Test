from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/admin/ADMIN_REGRESSION_PROOF_PASS.md"
AUDIT = ROOT / "docs/audits/ADMIN_REGRESSION_PROOF_AUDIT_V169_35.md"
REPORT = ROOT / (
    "reports/change_cycle_2026-06-01_v169_35_cycle_1356_"
    "admin_regression_proof_pass.md"
)
JSON_PROOF = (
    ROOT / "reports/generated/admin_regression_proof_v169_35.json"
)
ROUTE_MAP = ROOT / "docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md"
WORK_CYCLES = ROOT / "docs/cycles/WORK_CYCLES.md"
AI_INDEX = ROOT / "docs/AI/AI_DOCS_INDEX.md"
CI_YML = ROOT / "ci.yml"
EXPECTED_CI_SHA256 = (
    "5edec4d17a6178a75ed86a38b94c489ed9f9cf0b639e19fd9413fe378a3f0f73"
)

SURFACES = (
    "/admin",
    "/admin/bank",
    "/admin/users",
    "/admin/withdrawals",
    "/admin/shop",
    "/admin/tasks",
    "/admin/reports",
    "/admin/diagnostics",
    "/admin/system",
    "/admin/logs",
    "/admin/panels",
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_admin_regression_artifacts_exist() -> None:
    for path in (DOC, AUDIT, REPORT, JSON_PROOF):
        assert path.exists(), str(path)


def test_regression_proof_covers_required_admin_surfaces() -> None:
    text = read(DOC)
    data = json.loads(read(JSON_PROOF))
    assert data["cycle"] == 1356
    assert data["version"] == "v169_35"
    assert data["ci_changed"] is False
    assert data["summary"]["fail"] == 0
    covered = {item["surface"] for item in data["matrix"]}
    for surface in SURFACES:
        assert f"`{surface}`" in text
        assert surface in covered


def test_route_map_is_linked_to_regression_proof() -> None:
    route_map = read(ROUTE_MAP)
    proof = read(DOC)
    assert "ADMIN_REGRESSION_PROOF_PASS.md" in route_map
    assert "ADMIN_DOCS_SSOT_ROUTE_MAP.md" in proof
    assert (
        "reports/generated/admin_regression_proof_v169_35.json" in proof
    )


def test_work_cycles_keep_regression_proof_history() -> None:
    text = read(WORK_CYCLES)
    assert "Active range: `1351-1375`" in text
    assert "Legacy ranges: historical only" in text
    assert "1356: Admin regression proof pass. DONE in v169_35" in text
    assert "Current range: 1176-1230" not in text
    assert "Current range: `1176-1230`" not in text


def test_ai_index_mentions_regression_proof_route() -> None:
    text = read(AI_INDEX)
    assert "ADMIN_REGRESSION_PROOF_PASS.md" in text
    assert "admin_regression_proof_v169_35.json" in text
    assert "1351-1375" in text


def test_ci_workflow_is_normalized_and_mirrored() -> None:
    assert CI_YML.exists()
    active = ROOT / ".github/workflows/canon.yml"
    assert active.exists()
    assert CI_YML.read_text() == active.read_text()
    text = CI_YML.read_text()
    assert "PYTHONPATH=backend pytest -q" in text
    assert "Chromium visual audit" in text
    assert "actions/checkout@v7" in text
    assert "actions/upload-artifact@v7" in text
