from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_cycle_1330_docs_exist() -> None:
    assert (
        ROOT
        / "docs/audits/CI_LOGS_70999423442_REPAIR_AND_STANDARD_DOCS_V169_09.md"
    ).exists()
    assert (
        ROOT
        / "docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN.md"
    ).exists()


def test_frontend_target_standard_is_documented() -> None:
    text = (
        ROOT
        / "docs/frontend/FRONTEND_CODE_STANDARD_NEXT16_REACT19_TAILWIND4.md"
    ).read_text(encoding="utf-8")
    assert "Next.js 16.2.6" in text
    assert "React 19.2.6" in text
    assert "Tailwind CSS v4.3" in text
    assert "active implemented frontend runtime standard" in text


def test_dockerfile_keeps_stable_npm_ci_flags() -> None:
    text = (ROOT / "ops/docker/Dockerfile.frontend").read_text(
        encoding="utf-8"
    )
    assert "npm config set registry https://registry.npmjs.org/" in text
    assert "NPM_CONFIG_AUDIT=false" in text
    assert "NPM_CONFIG_FUND=false" in text
    assert "NPM_CONFIG_PROGRESS=false" in text
    assert "--fetch-retries=5" in text


def test_cycle_plan_shifted_again_after_1331_migration() -> None:
    text = (
        ROOT
        / "docs/cycles/WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    ).read_text(encoding="utf-8")
    assert "1330: CI logs repair" in text
    assert "1331: Frontend dependency migration" in text
    assert "1332: Shop admin actions" in text
    assert "final checkpoint moves to `1353`" in text
