from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/PANEL_CHROME_FOUNDATION.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
TSX = ROOT / "frontend/src/components/dashboard/PanelChrome.tsx"
ADMIN = ROOT / "frontend/src/components/admin/AdminDashboardUiKit.tsx"
SIM = ROOT / "frontend/src/components/dashboard/SimulationDashboardUiKit.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
REPORT = ROOT / "reports/generated/panel_chrome_foundation_v170_38.json"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_panel_chrome_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_PANEL_CHROME_FOUNDATION" in text
    assert "frontend/src/components/dashboard/PanelChrome.tsx" in text
    assert "AdminPanelChrome" in text
    assert "SimPanelChrome" in text
    assert "Grafana is visual-pattern reference only" in text
    assert "Песочница is reference" in text


def test_shared_panel_chrome_runtime_component_exists() -> None:
    text = read(TSX)
    required = [
        "export function PanelChrome",
        "PanelChromeProps",
        "PanelChromeMode",
        "panelChromeVersion",
        "EFHC_PANEL_CHROME_V1",
        "data-dashboard-panel-chrome=\"1462\"",
        "data-dashboard-data-kind",
        "data-panel-synthetic",
    ]
    for marker in required:
        assert marker in text
    forbidden = ["@grafana/", "SceneObject", "PanelData"]
    for marker in forbidden:
        assert marker not in text


def test_admin_and_simulation_wrappers_use_panel_chrome() -> None:
    admin = read(ADMIN)
    sim = read(SIM)
    assert "import { PanelChrome }" in admin
    assert "export function AdminPanelChrome" in admin
    assert "dataMarker=\"admin-panel-chrome\"" in admin
    assert "EFHC_ADMIN_DASHBOARD_UI_KIT_V2_PANEL_CHROME" in admin
    assert "import { PanelChrome }" in sim
    assert "export function SimPanelChrome" in sim
    assert "dataMarker=\"sim-panel-chrome\"" in sim
    assert "EFHC_SIM_DASHBOARD_UI_KIT_V2_PANEL_CHROME" in sim


def test_panel_chrome_css_uses_dashboard_tokens() -> None:
    css = read(CSS)
    required = [
        "Panel Chrome unified foundation",
        ".efhc-panel-chrome",
        ".efhc-panel-chrome__header",
        ".efhc-panel-chrome__status",
        ".efhc-panel-chrome--admin",
        ".efhc-panel-chrome--simulation",
        ".efhc-sim-panel-chrome",
        "var(--efhc-dash-panel)",
        "var(--efhc-dash-border)",
    ]
    for marker in required:
        assert marker in css


def test_grafana_map_has_deep_panel_chrome_analysis() -> None:
    text = read(GRAFANA_MAP)
    required = [
        "Cycle 1462 deep panel chrome analysis",
        "PanelChrome/PanelChrome.tsx",
        "PanelChrome/PanelStatus.tsx",
        "PanelChrome/PanelMenu.tsx",
        "PanelChrome/PanelDescription.tsx",
        "PanelChrome/HoverWidget.tsx",
        "PanelHeader/PanelHeaderMenuWrapper.tsx",
        "PanelInspector.tsx",
        "No Grafana source code is copied",
    ]
    for marker in required:
        assert marker in text


def test_panel_chrome_report_and_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1462
    assert data["version"] == "v170.38"
    assert data["runtime_components"]["shared"] == str(TSX.relative_to(ROOT))
    assert data["boundaries"]["economy_changed"] is False
    assert data["boundaries"]["backend_contracts_changed"] is False
    assert data["boundaries"]["grafana_runtime_code_copied"] is False
    assert data["boundaries"]["sandbox_runtime_code_copied"] is False


def test_navigation_points_to_panel_chrome_foundation() -> None:
    for path in [KERNEL, MAP, ROUTES]:
        text = read(path)
        assert "PANEL_CHROME_FOUNDATION" in text
        assert "PanelChrome.tsx" in text
        assert "test_panel_chrome_foundation.py" in text


def test_grafana_archive_contains_panel_chrome_reference_files() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "PanelChrome/PanelChrome.tsx",
        "PanelChrome/PanelStatus.tsx",
        "PanelChrome/PanelMenu.tsx",
        "PanelChrome/PanelDescription.tsx",
        "PanelChrome/HoverWidget.tsx",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker
