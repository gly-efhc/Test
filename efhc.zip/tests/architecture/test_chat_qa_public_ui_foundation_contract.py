from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHATS = ROOT / "docs/NORM/CHATS"
QA = ROOT / "docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md"
HEADER = ROOT / "frontend/src/components/GlobalHeader.tsx"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"

CHAT_NUMBERS = (40, 41, 43, 44, 45, 47, 49, 50, 51)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_чаты_40_51_сохранены_и_проиндексированы() -> None:
    index = read(CHATS / "CHATS_INDEX.md")
    readme = read(CHATS / "README.md")
    for number in CHAT_NUMBERS:
        path = CHATS / f"{number}.md"
        assert path.is_file(), path
        assert path.stat().st_size > 10_000, path
        assert f"`{number}.md`" in index
        assert f"`{number}.md`" in readme


def test_актуальный_qa_заменяет_устаревшие_ответы() -> None:
    text = read(QA)
    current = text.split("---", 1)[0]
    assert "Физической колонки `users.user_id` больше нет" in current
    assert "`0001_initial_release_schema.py`" in current
    assert "Компактно и в одну" in current
    assert "Ровно шесть" in current
    assert "2 411 EFHCb" in current
    assert "цикл 1635 не" not in current.lower()


def test_баланс_верхней_панели_компактный_и_однострочный() -> None:
    source = read(HEADER)
    assert 'data-header-balance-layout="single-line"' in source
    assert 'className="efhc-game-header_balance-value"' in source
    assert 'className="efhc-game-header_balance-unit"' in source
    assert "EFHC" in source


def test_публичная_оболочка_использует_мягкую_палитру() -> None:
    layout = read(LAYOUT)
    css = read(CSS)
    assert '"soft-muted-v2"' in layout
    assert "--efhc-public-accent:#c5b487" in css
    assert "--efhc-public-accent-strong:#a99668" in css
    assert 'data-header-balance-layout="single-line"' in css
    for label in (
        "Energy",
        "Panels",
        "Exchange",
        "Tasks",
        "Referrals",
        "Ranks",
    ):
        assert f'visualLabel: "{label}"' in layout


def test_ci_скриншоты_не_копируются_в_архив_чатов() -> None:
    assert not list(CHATS.rglob("*.png"))
    cycle = read(
        ROOT
        / "docs/cycles/WORK_CYCLE_1634_CHAT_QA_PUBLIC_UI_AUDIT.md"
    )
    assert "Chromium PNG остаются отдельным GitHub artifact" in cycle
    assert "цикл 1635 не" in cycle.lower()


def test_operator_kernel_имеет_точный_маршрут_цикла_1634() -> None:
    from ops.operator_kernel.route_resolver import resolve_route
    from ops.operator_kernel.task_classifier import classify_task

    query = (
        "Цикл 1634: чаты 40-51, аудит вопросов и ответов, "
        "мягкая публичная палитра и компактный баланс"
    )
    task = classify_task(query)
    assert task["task_type"] == "chat_qa_public_ui_foundation"
    route = resolve_route(task["task_type"])
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "chat_qa_public_ui_foundation"


def test_стенограммы_исключены_только_из_терминологического_scan() -> None:
    rules = read(ROOT / "ops/canon_rules.yaml")
    assert "docs/NORM/CHATS/**" in rules
    assert "docs/NORM/CHAT_BRANCHES/**" in rules
    assert "docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md" not in rules
