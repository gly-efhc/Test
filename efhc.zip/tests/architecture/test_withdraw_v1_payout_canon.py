
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

WITHDRAW_AUDIT = ROOT / "docs/NORM/WITHDRAW_AUDIT_CANON.md"
WITHDRAW_FLOW = ROOT / "docs/NORM/WITHDRAW_FLOW_NORM.md"
WITHDRAW_SSOT = ROOT / "docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md"
AUDIT_RULES = ROOT / "docs/NORM/AUDIT_RULES.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
REPORT = ROOT / "reports/generated/withdraw_canon_clarification_v170_82.json"
TZ = ROOT / "docs/audits/EFHC_PACK_01_WITHDRAW_CANON_CORRECTED_TZ.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_withdraw_v1_canon_doc_exists() -> None:
    assert WITHDRAW_AUDIT.exists()
    assert WITHDRAW_FLOW.exists()
    assert WITHDRAW_SSOT.exists()
    assert AUDIT_RULES.exists()
    assert TZ.exists()


def test_withdraw_v1_paid_does_not_require_backend_watcher_proof_by_canon() -> None:
    text = read(WITHDRAW_AUDIT) + read(WITHDRAW_FLOW) + read(WITHDRAW_SSOT)
    assert "не требует отдельного backend blockchain watcher proof" in text
    assert "не является обязательным условием" in text
    assert "backend watcher proof" in text


def test_wallet_send_confirmed_is_valid_v1_payout_signal_by_canon() -> None:
    text = read(WITHDRAW_AUDIT) + read(WITHDRAW_FLOW) + read(WITHDRAW_SSOT)
    assert "wallet_send_confirmed=true" in text
    assert "достаточным" in text
    assert "valid V1 payout signal" in text or "допустимым V1 payout signal" in text


def test_payout_ref_is_operational_reference_not_blockchain_proof_by_canon() -> None:
    text = read(WITHDRAW_AUDIT) + read(WITHDRAW_FLOW) + read(WITHDRAW_SSOT)
    assert "payout_ref" in text
    assert "operational reference" in text or "операционной ссылкой" in text
    assert "не обязан быть blockchain" in text


def test_audit_rules_must_follow_project_canon() -> None:
    text = read(AUDIT_RULES)
    assert "audit must follow project canon" in text
    assert "Запрещено классифицировать как P0/P1" in text
    assert "не является частью текущего канона" in text
    assert "без доступа к переписке" in text


def test_kernel_links_withdraw_v1_payout_canon() -> None:
    text = read(KERNEL)
    assert "Kernel lock: Withdraw V1 payout canon" in text
    assert "WITHDRAW_ADMIN_TONCONNECT_SSOT.md" in text
    assert "WITHDRAW_FLOW_NORM.md" in text
    assert "WITHDRAW_AUDIT_CANON.md" in text


def test_map_element_links_withdraw_canon_docs() -> None:
    text = read(MAP)
    for marker in [
        "docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md",
        "docs/NORM/WITHDRAW_FLOW_NORM.md",
        "docs/NORM/WITHDRAW_AUDIT_CANON.md",
        "docs/NORM/AUDIT_RULES.md",
    ]:
        assert marker in text


def test_withdraw_v1_docs_do_not_require_mandatory_settlement_fsm() -> None:
    text = "\n".join(
        read(path)
        for path in [WITHDRAW_AUDIT, WITHDRAW_FLOW, WITHDRAW_SSOT, AUDIT_RULES]
    )
    forbidden_required_claims = [
        "PAYOUT_CONFIRMING is required",
        "PAYOUT_CONFIRMED is required",
        "FAILED_SEND is required",
        "RETRY_PENDING is required",
        "REFUND_REQUIRED is required",
        "tx_hash is required for every PAID",
        "backend watcher proof is required for every PAID",
        "отсутствие backend watcher proof является P0/P1",
        "tx_hash обязателен для каждого PAID",
    ]
    for claim in forbidden_required_claims:
        assert claim not in text


def test_pending_to_paid_is_explicitly_allowed() -> None:
    text = read(WITHDRAW_FLOW)
    assert "`PENDING -> PAID`" in text
    assert "разрешённый admin/operator" in text


def test_cycle_1506_report_records_non_runtime_scope() -> None:
    data = json.loads(read(REPORT))
    assert data["cycle"] == 1506
    assert data["version"] == "v170.82"
    assert data["pack"] == "PACK-01"
    assert data["business_logic_changed"] is False
    assert data["economy_changed"] is False
    assert data["backend_write_flow_changed"] is False
    assert data["openapi_changed"] is False
    assert data["frontend_runtime_changed"] is False
    assert data["canon"]["operator_payout_finalizes_withdraw"] is True
    assert data["canon"]["mandatory_settlement_fsm_required_for_v1"] is False
