from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADMIN_HOME = ROOT / "frontend" / "src" / "pages" / "admin" / "index.tsx"
DASH = (
    ROOT
    / "frontend"
    / "src"
    / "components"
    / "admin"
    / "AdminInteractiveBankDashboard.tsx"
)
CSS = ROOT / "frontend" / "src" / "styles" / "globals.css"
PLAN = (
    ROOT
    / "docs"
    / "cycles"
    / "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_admin_home_keeps_only_release_dashboard_data() -> None:
    src = read(ADMIN_HOME)
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in src
    assert "AdminInteractiveBankDashboard" not in src
    assert "Релизный центр управления" in src
    assert "Ключевые показатели" in src


def test_legacy_interactive_dashboard_is_deleted_after_1502() -> None:
    assert not DASH.exists()
    assert (
        ROOT
        / "frontend"
        / "src"
        / "components"
        / "admin"
        / "AdminBankDashboardRuntime.tsx"
    ).exists()


def test_dashboard_visual_css_exists() -> None:
    src = read(CSS)
    assert ".efhc-admin-dashboard-section" in src
    assert ".efhc-admin-event-feed" in src
    assert ".efhc-sim-leaderboard-row" in src


def test_cycle_plan_marks_1325_interactive_dashboard_done() -> None:
    plan = read(PLAN)
    assert "1325: Admin interactive dashboard" in plan
    assert "DONE in v169_04" in plan
    assert "v168_104" not in plan
