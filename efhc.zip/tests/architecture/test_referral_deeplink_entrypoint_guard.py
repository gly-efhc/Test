from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_start_referral_входит_в_первое_создание_user() -> None:
    src = read("backend/app/bot/handlers/start_handlers.py")
    assert "_extract_start_payload" in src
    assert "onboard_user_at_first_creation" in src
    assert "attach_referral_code_for_user" not in src
    payload_pos = src.index("payload = _extract_start_payload")
    onboard_pos = src.index("await onboard_user_at_first_creation")
    gate_pos = src.index("if required_channel_id and not is_subscribed")
    assert payload_pos < onboard_pos < gate_pos


def test_bot_registration_использует_единый_центр() -> None:
    service = read("backend/app/services/referral_service.py")
    assert "class ReferralOnboardingResult" in service
    assert "class ReferralOnboardingRejected" in service
    assert "async def onboard_user_at_first_creation" in service
    assert 'reason="existing_user_locked"' in service
    assert '"created_zero_user"' in service
    assert '"created_with_referral"' in service
    assert "create_new_account(" in service
    assert "register_referral_and_reward" not in service
    onboarding = service.split(
        "async def onboard_user_at_first_creation", 1
    )[1].split(
        "# ----------------------------------------------------------------------",
        1,
    )[0]
    assert "INSERT INTO efhc_core.users" not in onboarding


def test_manual_referral_binding_routes_отсутствуют() -> None:
    src = read("backend/app/routes/referrals_routes.py")
    frontend = read("frontend/src/services/referrals.service.ts")
    app = read("frontend/src/pages/_app.tsx")
    assert '"/bind"' not in src
    assert '"/attach"' not in src
    assert "/referrals/bind" not in frontend
    assert "bindReferralStartParam" not in frontend
    assert "bindReferralStartParam" not in app


def test_referral_link_создаётся_единственным_runtime_path() -> None:
    service = read("backend/app/services/referral_service.py")
    core = read("backend/app/identity/account_registration.py")
    crud = read("backend/app/crud/referrals_crud.py")
    assert "register_referral_and_reward" not in service
    assert "ReferralLink(" in core
    assert "session.add(" in core
    assert "create_referral_link" not in crud
