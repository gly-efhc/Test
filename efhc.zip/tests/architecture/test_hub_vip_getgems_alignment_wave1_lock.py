from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_runtime_catalog_no_vip_shop_purchase_question():
    text = (ROOT / "frontend/src/data/faq/catalogs.ts").read_text(
        encoding="utf-8"
    )
    banned = [
        "Если я купил VIP NFT в Shop",
        "If I bought VIP NFT in Shop",
        "Якщо я купив VIP NFT у Shop",
        "Wenn ich im Shop ein VIP NFT gekauft habe",
        "Si j’ai acheté un VIP NFT dans Shop",
        "¿Si compré VIP NFT en Shop",
        "Se ho acquistato un VIP NFT nello Shop",
        "Shop'ta VIP NFT satın aldıysam",
        "Jeśli kupiłem VIP NFT w Shop",
        "Hvis jeg købte VIP NFT i Shop",
        "यदि मैंने Shop में VIP NFT खरीदा",
        "Jika saya membeli VIP NFT di Shop",
        "Nikinunua VIP NFT ndani ya Shop",
    ]
    for item in banned:
        assert item not in text


def test_runtime_catalog_has_getgems_vip_language():
    text = (ROOT / "frontend/src/data/faq/catalogs.ts").read_text(
        encoding="utf-8"
    )
    assert "GetGems" in text
    allowed = [
        "NFT ownership",
        "владению NFT",
        "presence in the linked wallet",
        "наличие NFT в привязанном кошельке",
    ]
    assert any(item in text for item in allowed)


def test_locale_manual_key_no_shop_order_wording():
    text = (ROOT / "frontend/public/locale/ru.json").read_text(
        encoding="utf-8"
    )
    assert "Покупки/заказы — через бэк" not in text
    assert "GetGems" in text


def test_hub_screen_renders_canonical_vip_link():
    text = (ROOT / "frontend/src/features/hub/HubPage.tsx").read_text(
        encoding="utf-8"
    )
    assert "https://getgems.io/efhc-nft" in text
    assert "hub.action_vip_nft" in text
    assert 'data-hub-action="vip-nft"' in text
