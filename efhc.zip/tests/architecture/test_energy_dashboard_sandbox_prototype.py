from __future__ import annotations

import json
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/ENERGY_DASHBOARD_SANDBOX_PROTOTYPE.md"
GRAFANA_ANALYSIS = ROOT / "docs/NORM/ENERGY_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md"
TSX = ROOT / "frontend/src/components/dashboard/EnergyDashboardSandboxPrototype.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
MAP = ROOT / "map_element.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
SANDBOX_INVENTORY = ROOT / "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md"
REPORT = ROOT / "reports/generated/energy_dashboard_sandbox_prototype_v170_43.json"
KERNEL = ROOT / "KERNEL.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
TEST_MANIFEST = ROOT / "docs/testing/TEST_GUARD_MANIFEST.md"
TEST_MANIFEST_JSON = ROOT / "docs/testing/TEST_GUARD_MANIFEST.json"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_energy_dashboard_sandbox_document_exists() -> None:
    text = read(DOC)
    assert "ACTIVE_ENERGY_DASHBOARD_SANDBOX_PROTOTYPE" in text
    assert "Energy Dashboard sandbox prototype" in text
    assert "synthetic_preview" in text
    assert "No Grafana source code is copied" in text
    assert "No Песочница runtime code is copied" in text
    assert "1 EFHC = 1 kWh" in text
    assert "kWh → EFHC only `1:1`" in text
    assert "npm ci" in text
    assert "5 vulnerabilities" in text
    assert "3 moderate" in text
    assert "2 high" in text


def test_grafana_energy_element_analysis_is_reference_only() -> None:
    text = read(GRAFANA_ANALYSIS)
    for marker in [
        "BigValue",
        "PercentChange",
        "Sparkline/Sparkline.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RelativeTimeRangePicker",
        "PanelChrome",
        "PanelHeader",
        "PanelStatus",
        "StatusHistoryPanel",
        "StateTimelinePanel",
        "DashboardGrid",
        "Variables",
    ]:
        assert marker in text
    assert "Grafana is not a code donor" in text
    assert "No Grafana source code is copied" in text
    assert "EFHC-owned code" in text or "EFHC-owned target code" in text


def test_energy_dashboard_sandbox_component_exists_and_is_marked_preview() -> None:
    text = read(TSX)
    required = [
        "export function EnergyDashboardSandboxPrototype",
        "EFHC_ENERGY_DASHBOARD_SANDBOX_PROTOTYPE_V1",
        "data-energy-dashboard-sandbox-prototype=\"1467\"",
        "data-energy-dashboard-data-kind=\"synthetic_preview\"",
        "data-energy-dashboard-preview-only=\"true\"",
        "data-grafana-reference-only=\"true\"",
        "data-sandbox-reference-only=\"true\"",
        "SimHeroEnergyCard",
        "SimStatCard",
        "SimMiniAreaChart",
        "SimMiniBarChart",
        "SimActivityStrip",
        "SimMiniSparkline",
        "SimSegmentedProgress",
        "SimPeriodSwitch",
        "SimFreshnessBadge",
        "truth-safe preview",
    ]
    for marker in required:
        assert marker in text
    forbidden = ["@grafana/", "SceneObject", "apiRequest", "fetch(", "axios"]
    for marker in forbidden:
        assert marker not in text


def test_energy_dashboard_sandbox_cta_boundary_is_safe() -> None:
    text = read(TSX)
    assert "href=\"/panels\"" in text
    assert "href=\"/exchange\"" in text
    forbidden_write_markers = [
        "method: \"POST\"",
        "method: \"PUT\"",
        "method: \"PATCH\"",
        "method: \"DELETE\"",
        "onSubmit",
        "formAction",
        "withdraw",
        "mint",
        "burn",
        "transfer-to-user",
    ]
    for marker in forbidden_write_markers:
        assert marker not in text


def test_energy_dashboard_sandbox_css_uses_dashboard_tokens() -> None:
    css = read(CSS)
    required = [
        "Cycle 1467 — Energy Dashboard Sandbox Prototype",
        ".efhc-energy-dashboard-sandbox",
        ".efhc-energy-dashboard-sandbox__kpi-strip",
        ".efhc-energy-dashboard-sandbox__rules",
        "var(--efhc-dash-border)",
        "var(--efhc-dash-accent)",
    ]
    for marker in required:
        assert marker in css


def test_energy_dashboard_report_and_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1467
    assert data["version"] == "v170.43"
    assert data["truth_model"]["data_kind"] == "synthetic_preview"
    assert data["truth_model"]["preview_only"] is True
    assert data["truth_model"]["runtime_truth_claimed"] is False
    assert data["truth_model"]["real_analytics_claimed"] is False
    for key in [
        "economy_changed",
        "backend_contracts_changed",
        "db_migrations_changed",
        "openapi_changed",
        "new_dependencies_added",
        "lock_files_changed",
        "ci_workflows_changed",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
        "write_flows_changed",
        "money_actions_added",
        "live_energy_route_changed",
    ]:
        assert data["boundaries"][key] is False
    assert data["dependency_audit_followup"]["npm_ci_reported_vulnerabilities"] == 5
    assert data["dependency_audit_followup"]["moderate"] == 3
    assert data["dependency_audit_followup"]["high"] == 2
    assert data["dependency_audit_followup"]["fixed_in_this_cycle"] is False


def test_navigation_and_guard_manifest_point_to_energy_prototype() -> None:
    for path in [KERNEL, MAP, ROUTES, TEST_MANIFEST]:
        text = read(path)
        assert "ENERGY_DASHBOARD_SANDBOX_PROTOTYPE" in text
        assert "EnergyDashboardSandboxPrototype.tsx" in text
        assert "test_energy_dashboard_sandbox_prototype.py" in text
    manifest = load(TEST_MANIFEST_JSON)
    assert "cycle_1467_energy_dashboard_sandbox_prototype" in manifest
    assert manifest["cycle_1467_energy_dashboard_sandbox_prototype"]["status"] == "active"


def test_dashboard_maps_include_energy_cycle() -> None:
    for path in [MAP, GRAFANA_MAP, SANDBOX_INVENTORY]:
        text = read(path)
        assert "Cycle 1467" in text
        assert "Energy" in text
        assert "No Grafana source code is copied" in text or path == SANDBOX_INVENTORY
    assert "No Песочница runtime code is copied" in read(DOC)


def test_grafana_archive_contains_energy_reference_elements() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    expected = [
        "BigValue.tsx",
        "PercentChange.tsx",
        "Sparkline/Sparkline.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "PanelChrome.tsx",
        "PanelStatus.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker


def test_sandbox_archive_contains_dashboard_reference_candidates() -> None:
    sandbox_path = ROOT.parent / "Песочница.xz"
    if not sandbox_path.exists():
        return
    with tarfile.open(sandbox_path) as archive:
        names = archive.getnames()
    expected = [
        "MaterialM-Tailwind-Nextjs-Free-main",
        "TelegramUI-main",
        "Mark42-master",
    ]
    for marker in expected:
        assert any(marker in name for name in names), marker
