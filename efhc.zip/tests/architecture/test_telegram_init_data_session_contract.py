"""Architecture guards Telegram initData/session цикла 1619."""

from __future__ import annotations

import ast
from pathlib import Path

from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
IDENTITY = ROOT / "backend/app/identity/telegram_init_data.py"
SESSION = ROOT / "backend/app/identity/telegram_auth_session.py"
ROUTE = ROOT / "backend/app/routes/auth_telegram_routes.py"
PG_TEST = ROOT / "tests/integration/test_telegram_auth_session_postgresql.py"


def test_kernel_route_1619_является_exact_primary() -> None:
    task = classify_task(
        "Цикл 1619 — Telegram initData adapter через "
        "IdentityResolver и session issue"
    )
    assert task["task_type"] == "telegram_init_data_session"
    route = resolve_route(task["task_type"], ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_adapter_не_делает_domain_side_effects() -> None:
    text = IDENTITY.read_text(encoding="utf-8")
    for forbidden in (
        "User(",
        "UserIdentity(",
        "AuthSession(",
        "INSERT INTO",
        "UPDATE ",
        "DELETE FROM",
    ):
        assert forbidden not in text
    assert "VerifiedIdentity" in text
    assert "AuthProvider.TELEGRAM" in text


def test_session_flow_использует_resolver_и_hash_replay() -> None:
    text = SESSION.read_text(encoding="utf-8")
    assert "PostgreSQLIdentityResolver" in text
    assert "resolve_in_transaction" in text
    assert "ProcessedExternalEvent" in text
    assert "telegram_init_data_auth" in text
    assert "AuthSessionService" in text
    assert "global_id_from_tg_id" in text


def test_route_не_возвращает_provider_identifier() -> None:
    route = ROUTE.read_text(encoding="utf-8")
    schema = (
        ROOT / "backend/app/schemas/auth_telegram_schemas.py"
    ).read_text(encoding="utf-8")
    assert 'prefix="/auth/telegram"' in route
    assert '"/session"' in route
    assert "X-Telegram-Init-Data" in route
    assert "tg_id" not in schema
    assert "provider_subject" not in schema


def test_postgresql_scope_имеет_шесть_tests_без_skip() -> None:
    source = PG_TEST.read_text(encoding="utf-8")
    tree = ast.parse(source)
    tests = [
        node.name
        for node in tree.body
        if isinstance(node, ast.AsyncFunctionDef)
        and node.name.startswith("test_")
    ]
    assert len(tests) == 6
    assert "pytest.skip" not in source
    assert "pytest.mark.xfail" not in source


def test_использует_единую_release_schema_0001() -> None:
    migrations = ROOT / "backend/migrations/versions"
    assert sorted(path.name for path in migrations.glob("*.py")) == [
        "0001_initial_release_schema.py",
    ]
    source = (migrations / "0001_initial_release_schema.py").read_text(
        encoding="utf-8"
    )
    assert 'revision = "0001"' in source
    assert "telegram_init_data" not in source
