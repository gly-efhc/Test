from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WATCHER = ROOT / "backend" / "app" / "services" / "watcher_service.py"
ADMIN_ROUTES = ROOT / "backend" / "app" / "routes" / "admin_routes.py"
WALLETS_MODEL = ROOT / "backend" / "app" / "models" / "wallets_models.py"
WALLETS_SERVICE = ROOT / "backend" / "app" / "services" / "wallets_service.py"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _find_user_by_wallet_body() -> str:
    src = read(WATCHER)
    start = src.index("async def _find_user_by_wallet")
    end = src.index("async def _find_user_by_tg_id", start)
    return src[start:end]


def test_deposit_watcher_uses_wallet_bindings_ssot() -> None:
    body = _find_user_by_wallet_body()
    assert "efhc_core.wallet_bindings" in body
    assert "wallet_address = :wa" in body
    assert "is_active = TRUE" in body
    assert "proof_verified = TRUE" in body
    assert "ORDER BY wb.is_primary DESC, wb.id DESC" in body
    assert "efhc_core.user_wallets" not in body
    assert "users.ton_wallet" not in body
    assert "ton_address" not in body
    assert "is_blocked" not in body


def test_deposit_reprocess_uses_wallet_bindings_ssot() -> None:
    watcher = read(WATCHER)
    admin_routes = read(ADMIN_ROUTES)
    reprocess_start = watcher.index("async def reprocess_single_tx")
    reprocess_body = watcher[reprocess_start:]
    assert "return await process_incoming_tx(db, tx)" in reprocess_body
    assert "_find_user_by_wallet" in watcher
    assert "reprocess_single_tx" in admin_routes
    assert '"/efhc-deposits/reprocess/{tx_hash}"' in admin_routes
    assert "Depends(require_admin)" in admin_routes


def test_wallet_bound_deposit_is_matched_to_user() -> None:
    watcher = read(WATCHER)
    assert "owner = await _find_user_by_wallet" in watcher
    assert "if owner is not None:" in watcher
    assert "found_by_wallet = True" in watcher
    assert "global_id=owner.global_id" in watcher
    assert "credit_user_from_bank(" in watcher


def test_revoked_wallet_binding_is_not_used_for_deposit_credit() -> None:
    body = _find_user_by_wallet_body()
    assert "is_active = TRUE" in body
    assert "proof_verified = TRUE" in body
    assert "COALESCE(is_active" not in body
    assert "WHERE wb.wallet_address = :wa" in body


def test_deposit_payment_intent_chain_complete() -> None:
    watcher = read(WATCHER)
    assert "_confirm_payment_intent(" in watcher
    assert "_ton_log_upsert(" in watcher
    assert "confirm_payment_intent" in watcher
    assert "parse_intent_payload" in watcher
    assert "external_tx_hash = :h" in watcher
    assert "UNIQUE(tx_hash)" in watcher or "UNIQUE tx_hash" in watcher


def test_admin_efhc_deposit_reprocess_has_admin_guard() -> None:
    admin_routes = read(ADMIN_ROUTES)
    start = admin_routes.index("async def admin_reprocess_efhc_deposit_tx")
    end = admin_routes.index("@router.get", start)
    body = admin_routes[start:end]
    assert "Depends(require_admin)" in body
    assert "reprocess_single_tx" in body
    assert "AdminEfhcDepositReplayOut" in body


def test_wallet_bindings_model_is_canonical_for_tonconnect() -> None:
    model = read(WALLETS_MODEL)
    service = read(WALLETS_SERVICE)
    assert '__tablename__ = "wallet_bindings"' in model
    assert "tg_id: Mapped[int]" in model
    assert "wallet_address: Mapped[str]" in model
    assert "is_active: Mapped[bool]" in model
    assert "proof_verified: Mapped[bool]" in model
    assert "efhc_core.wallet_bindings" in service
    assert "proof_verified = true" in service
