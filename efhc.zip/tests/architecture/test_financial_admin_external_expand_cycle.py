"""Границы financial/admin/external EXPAND цикла 1622."""

from __future__ import annotations

from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from ops.identity.check_financial_admin_external_expand import проверить
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_cycle_1622_имеет_exact_primary_route() -> None:
    task = classify_task(
        "Цикл 1622 — financial admin external schema expand: "
        "transactions deposits withdrawals wallets admin actors "
        "external events"
    )
    assert task["task_type"] == "financial_admin_external_schema_expand"
    route = resolve_route(task["task_type"], ROOT)
    assert route["route_name"] == "financial_admin_external_schema_expand"
    assert route["config_primary"] is True
    assert route["fallback_used"] is False


def test_financial_admin_schema_входит_в_единую_release_revision() -> None:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    assert script.get_heads() == ["0001"]
    assert script.get_revision("0001").down_revision is None

def test_financial_admin_external_static_guard_проходит() -> None:
    result = проверить(ROOT)
    assert result["успех"] is True, result["нарушения"]
    assert result["таблиц_expand"] == 16
    assert result["owner_actor_columns"] == 17
    assert result["openapi_paths"] == 131
    assert result["openapi_operations"] == 136
    assert result["backfill"] is False
    assert result["dual_write"] is False
    assert result["read_switch"] is False
    assert result["financial_owner_switch"] is False
    assert result["financial_value_rewrite"] is False


def test_release_schema_не_переписывает_financial_values() -> None:
    source = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    for forbidden in (
        "SET main_balance =",
        "SET bonus_balance =",
        "SET amount =",
        "SET amount_efhc =",
    ):
        assert forbidden not in source
    assert "users.global_id" in _read(
        "backend/app/models/transactions_models.py"
    )

def test_legacy_owner_and_financial_precision_сохранены() -> None:
    for relative in (
        "backend/app/models/transactions_models.py",
        "backend/app/models/payment_intents_models.py",
        "backend/app/models/withdraw_models.py",
        "backend/app/models/wallets_models.py",
        "backend/app/models/ton_logs_models.py",
        "backend/app/models/admin_models.py",
    ):
        assert "tg_id" in _read(relative)

    assert "Numeric(30, 8)" in _read(
        "backend/app/models/transactions_models.py"
    )
    assert "Numeric(38, 8)" in _read(
        "backend/app/models/payment_intents_models.py"
    )
    users = _read("backend/app/models/user_models.py")
    assert 'user_id = synonym("global_id")' in users
