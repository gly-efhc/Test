from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BANK = ROOT / "frontend" / "src" / "pages" / "admin" / "bank.tsx"
MODAL = (
    ROOT
    / "frontend"
    / "src"
    / "components"
    / "admin"
    / "AdminPromptModal.tsx"
)
PLAN = (
    ROOT
    / "docs"
    / "cycles"
    / "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_bank_actions_have_cycle_1324_proof_marker() -> None:
    src = read(BANK)
    assert 'data-admin-bank-action-proof="1324"' in src
    assert 'data-admin-bank-idempotency-proof="prepared-1324"' in src
    assert "BANK_CONFIRM_PHRASE" in src


def test_mint_burn_require_typed_confirmation() -> None:
    src = read(BANK)
    assert 'const BANK_CONFIRM_PHRASE = "ПОДТВЕРЖДАЮ";' in src
    assert "confirmText.trim() === BANK_CONFIRM_PHRASE" in src
    assert "submitDisabled={!isActionReady}" in src
    assert 'setConfirmText("")' in src
    assert "Подтверждение не завершено" in src


def test_bank_mutations_use_prepared_idempotency_key() -> None:
    src = read(BANK)
    assert "const [pendingIdk, setPendingIdk]" in src
    assert "setPendingIdk(newIdempotencyKey())" in src
    assert "const idk = pendingIdk || newIdempotencyKey();" in src
    assert "idempotencyKey: idk" in src
    assert "closeBankAction();" in src


def test_bank_ui_does_not_show_endpoint_text_to_operator() -> None:
    src = read(BANK)
    assert "Список берётся из `/admin/logs/transfers`" not in src
    assert "Рабочий ledger последних банковских проводок" in src
    assert "AdminRouteHealthStrip" not in src
    assert "raw payload" not in src.lower()


def test_admin_prompt_modal_can_disable_submit() -> None:
    src = read(MODAL)
    assert "submitDisabled?: boolean" in src
    assert "props.busy || props.submitDisabled" in src


def test_cycle_plan_marks_1324_done_in_valid_version() -> None:
    plan = read(PLAN)
    assert "1324: Bank action confirmations" in plan
    assert "DONE in v169_03" in plan
    assert "v168_103" not in plan
