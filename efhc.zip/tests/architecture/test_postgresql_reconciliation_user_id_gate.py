"""После schema freeze Global ID reconciliation остаётся read-only."""

from __future__ import annotations

import types
from pathlib import Path

from ops.identity.check_global_id_canon import проверить
from ops.identity.postgresql_reconciliation_gate import (
    capture,
    render_sql,
)

ROOT = Path(__file__).resolve().parents[2]


def test_reconciliation_sql_остаётся_read_only() -> None:
    sql = render_sql(cycle=1632)
    upper = sql.upper()
    assert "READ ONLY DEFERRABLE" in upper
    assert sql.rstrip().endswith("ROLLBACK;")
    for token in (
        "UPDATE EFHC_CORE",
        "INSERT INTO EFHC_CORE",
        "DELETE FROM EFHC_CORE",
        "TRUNCATE ",
        "ALTER TABLE ",
        "CREATE TABLE ",
        "DROP TABLE ",
    ):
        assert token not in upper


def test_без_database_gate_честно_заблокирован() -> None:
    report, exit_code = capture(None)
    assert exit_code == 3
    assert report["статус"] == "БЛОКИРОВАНО_СРЕДОЙ"
    assert report["реальный_postgresql_выполнен"] is False


def test_global_id_canon_соответствует_единой_release_schema() -> None:
    report = проверить(ROOT)
    assert report["пройдено"], report["нарушения"]
    versions = sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert versions == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]


def test_real_connection_использует_read_only_и_rollback(monkeypatch) -> None:
    import ops.identity.postgresql_reconciliation_gate as gate

    executed: list[str] = []

    class Cursor:
        def __init__(self) -> None:
            self.last_sql = ""

        def execute(self, sql: str) -> None:
            self.last_sql = sql
            executed.append(sql)

        def fetchone(self):
            values = {
                "SELECT current_setting('server_version_num')::bigint": (160000,),
                "SELECT version_num FROM efhc_core.alembic_version": ("0002",),
                "SELECT current_setting('transaction_read_only')": ("on",),
                "SELECT current_setting('transaction_isolation')": ("repeatable read",),
            }
            return values[self.last_sql]

        def close(self) -> None:
            executed.append("CURSOR_CLOSE")

    class Connection:
        autocommit = True

        def cursor(self) -> Cursor:
            return Cursor()

        def rollback(self) -> None:
            executed.append("ROLLBACK")

        def close(self) -> None:
            executed.append("CONNECTION_CLOSE")

    connection = Connection()
    driver = types.SimpleNamespace(connect=lambda _: connection)
    monkeypatch.setattr(
        gate,
        "_load_driver",
        lambda: (driver, "fake-psycopg", None),
    )
    monkeypatch.setattr(
        gate,
        "QUERIES",
        (
            gate.QuerySpec(
                "версия_postgresql",
                "SELECT current_setting('server_version_num')::bigint",
            ),
            gate.QuerySpec(
                "alembic_revision",
                "SELECT version_num FROM efhc_core.alembic_version",
            ),
            gate.QuerySpec(
                "режим_только_чтение",
                "SELECT current_setting('transaction_read_only')",
            ),
            gate.QuerySpec(
                "уровень_изоляции",
                "SELECT current_setting('transaction_isolation')",
            ),
        ),
    )
    monkeypatch.setattr(gate, "_sequence_next", lambda _: 1)
    monkeypatch.setattr(gate, "_capture_orphans", lambda _: {})
    monkeypatch.setattr(
        gate,
        "_schema_checks",
        lambda _: {
            "физическая_колонка_users_global_id": 1,
            "legacy_колонка_users_user_id_отсутствует": 1,
            "constraint_uq_users_global_id": 1,
            "constraint_ck_users_global_id_range": 1,
            "sequence_users_global_id_seq": 1,
        },
    )
    monkeypatch.setattr(
        gate,
        "evaluate_reconciliation",
        lambda _: types.SimpleNamespace(violations=(), warnings=()),
    )
    report, exit_code = gate.capture("postgresql://example.invalid/efhc")
    assert exit_code == 0
    assert report["статус"] == "ГОТОВО"
    assert any("READ ONLY DEFERRABLE" in item for item in executed)
    assert "ROLLBACK" in executed
