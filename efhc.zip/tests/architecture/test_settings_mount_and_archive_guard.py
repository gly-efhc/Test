from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_header_balance_digits_use_one_numeric_scale() -> None:
    css = read("frontend/src/styles/globals.css")
    header = read("frontend/src/components/GlobalHeader.tsx")
    current = css.split(
        "/* v171.61: trusted visual baseline recovery.",
        1,
    )[1]
    assert "font-variant-numeric:tabular-nums lining-nums" in current
    assert 'font-feature-settings:"tnum" 1,"lnum" 1' in current
    value = current.split(
        ".efhc-game-header_balance-value{",
        1,
    )[1].split("}", 1)[0]
    assert "font-size:clamp(.69rem,2.9vw,.88rem)" in value
    assert 'data-header-balance-value={total}' in header
    assert "{total}" in header
    assert "balance-whole" not in header
    assert "balance-fraction" not in header


def test_profile_settings_modal_is_visible_and_mounted() -> None:
    page = read("frontend/src/features/profile/WebProfilePage.tsx")
    assert 'import { ProfileModal } from "../../components/ProfileModal";' in page
    assert "const [settingsOpen, setSettingsOpen] = useState(false);" in page
    assert 'data-profile-settings-entry="profile-modal"' in page
    assert 'className="efhc-profile-settings-button"' in page
    assert 'aria-label={t("profile.settings_title")}' in page
    assert "onClick={() => setSettingsOpen(true)}" in page
    assert "<ProfileModal" in page
    assert "open={settingsOpen}" in page
    assert "onClose={() => setSettingsOpen(false)}" in page
    assert "availableWallets={ctx.availableWallets}" in page


def test_v171_59_manual_html_proof_is_quarantined_not_active() -> None:
    history = read("docs/history/invalid_application_proof_v171_59/README.md").lower()
    assert "invalid" in history
    assert "page.set_content" in history
    assert not (ROOT / "ops/frontend/cycle_1573_v171_59_browser_proof.py").exists()
    assert not (ROOT / "ops/frontend/profile_header_component_proof_v171_56.py").exists()
    assert "browser_component_page_proof_v171_59.json" not in read("START_HERE.md")
    assert "browser_component_page_proof_v171_59.json" not in read("KERNEL.md")


def test_main_archive_builder_excludes_technical_screenshots() -> None:
    build = read("ops/build_efhc_zip.sh")
    assert '--exclude "reports/screenshots/"' in build
    assert "(^|/)reports/screenshots/" in build
