from __future__ import annotations

import json
import re
from pathlib import Path

LANGS = (
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)

MIN_ITEMS = 250
MIN_MEANINGFUL_LEN = 6


def _load_ssot(root: Path, lang: str) -> dict[str, object]:
    path = root / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _has_real_text(value: str) -> bool:
    text = " ".join(value.split()).strip()
    if len(text) < MIN_MEANINGFUL_LEN:
        return False
    has_letter = any(ch.isalpha() for ch in text)
    not_only_punct_or_digits = any(ch.isalpha() for ch in text)
    return has_letter and not_only_punct_or_digits


def test_faq_ssot__all__langs_have_required_shape_and_real_qa() -> None:
    root = Path(__file__).resolve().parents[2]

    for lang in LANGS:
        ssot = _load_ssot(root, lang)
        sections = ssot["sections"]
        assert len(sections) == 20, lang

        total_questions = 0
        total_answers = 0
        for section in sections:
            items = section["items"]
            for item in items:
                question = str(item["q"])
                answer = str(item["a"])
                assert _has_real_text(question), (
                    lang,
                    item["id"],
                    question,
                )
                assert _has_real_text(answer), (
                    lang,
                    item["id"],
                    answer,
                )
                total_questions += 1
                total_answers += 1

        assert total_questions >= MIN_ITEMS, lang
        assert total_answers >= MIN_ITEMS, lang


def test_frontend_faq_catalogs_match_ssot_for__all__langs() -> None:
    root = Path(__file__).resolve().parents[2]
    catalogs_ts = (
        root / "frontend/src/data/faq/catalogs.ts"
    ).read_text(encoding="utf-8")
    index_ts = (root / "frontend/src/data/faq/index.ts").read_text(
        encoding="utf-8"
    )

    assert "faqCatalogByLang" in index_ts
    assert (
        "return faqCatalogByLang[lang] || faqCatalogByLang.ru;"
        in index_ts
    )

    for lang in LANGS:
        assert re.search(rf"\b{lang}: \{{", catalogs_ts), lang
        ssot = _load_ssot(root, lang)
        assert f'title: "{ssot["title"]}"' in catalogs_ts, lang

        for section in ssot["sections"]:
            sid = str(section["id"])
            stitle = str(section["title"])
            assert f'id: "{sid}"' in catalogs_ts, (lang, sid)
            assert f'title: "{stitle}"' in catalogs_ts, (lang, sid)
            for idx, item in enumerate(section["items"], start=1):
                question = str(item["q"])
                answer = str(item["a"])
                question_ts = json.dumps(
                    question,
                    ensure_ascii=False,
                )[1:-1]
                answer_ts = json.dumps(
                    answer,
                    ensure_ascii=False,
                )[1:-1]
                ref = f"{sid}:{idx}"
                assert question_ts in catalogs_ts, (
                    lang,
                    ref,
                    "question",
                )
                assert answer_ts in catalogs_ts, (lang, ref, "answer")
