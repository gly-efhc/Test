from __future__ import annotations

import json
from pathlib import Path


def test_ru_faq_synced_with_ssot_json() -> None:
    root = Path(__file__).resolve().parents[2]
    ssot = json.loads(
        (root / "docs/faq_ssot/ru/faq_ru.json").read_text(
            encoding="utf-8"
        )
    )
    ru_ts = (root / "frontend/src/data/faq/ru.ts").read_text(
        encoding="utf-8"
    )
    meta_ts = (root / "frontend/src/data/faq/meta.ts").read_text(
        encoding="utf-8"
    )

    assert len(ssot["sections"]) == 20

    total_items = sum(len(section["items"]) for section in ssot["sections"])
    assert ru_ts.count('question: ') == total_items
    assert ru_ts.count('answer: [') == total_items

    for section in ssot["sections"]:
        sid = str(section["id"])
        title = section["title"]
        assert f'"{sid}": "{title}"' in meta_ts
        assert f'title: "{title}"' in ru_ts

    assert 'subsections: [' in ru_ts
