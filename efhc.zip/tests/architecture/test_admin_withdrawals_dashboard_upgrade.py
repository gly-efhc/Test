from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_withdrawals_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md",
        "docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1486_ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md",
        "reports/generated/admin_withdrawals_dashboard_upgrade_v170_62.json",
        "reports/change_cycle_2026-06-08_v170_62_cycle_1486_"
        "admin_withdrawals_dashboard_upgrade.md",
        "frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx",
        "tests/architecture/test_admin_withdrawals_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_withdrawal_boundaries() -> None:
    data = json.loads(
        read("reports/generated/admin_withdrawals_dashboard_upgrade_v170_62.json")
    )
    assert data["cycle"] == 1486
    assert data["archive_version"] == "v170.62"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_withdrawals_route_changed"] is True
    assert data["new_backend_endpoint_added"] is False
    assert data["fake_time_series_added"] is False
    assert data["fake_handling_time_added"] is False
    assert data["synthetic_admin_analytics_added"] is False
    assert data["real_time_series_claimed"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["dashboard_idempotency_key_created"] is False
    assert data["final_status_overwrite_added"] is False
    assert data["approve_logic_changed"] is False
    assert data["reject_logic_changed"] is False
    assert data["tonconnect_payment_logic_changed"] is False
    assert data["consistency_repair_logic_changed"] is False
    assert data["withdraw_money_flow_changed"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False


def test_admin_withdrawals_runtime_component_has_1486_markers() -> None:
    src = read("frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx")
    required = [
        "adminWithdrawalsDashboardRuntimeVersion",
        "EFHC_ADMIN_WITHDRAWALS_DASHBOARD_RUNTIME_V1",
        'data-admin-withdrawals-dashboard-runtime="1486"',
        'data-admin-withdrawals-truth="raw-derived"',
        'data-admin-withdrawals-no-synthetic="true"',
        'data-admin-withdrawals-no-write-actions="true"',
        'data-admin-withdrawals-no-raw-payload="true"',
        'data-admin-withdrawals-no-debug-json="true"',
        'data-admin-withdrawals-no-secrets="true"',
        'data-admin-withdrawals-final-status-safe="true"',
        'data-admin-withdrawals-money-path="read-only"',
        "AdminDashboardToolbar",
        "AdminFreshnessBadge",
        "AdminRefreshPicker",
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminPanelChrome",
        "AdminMiniBarChart",
        "AdminProgressBar",
        "AdminHeatStrip",
        "AdminFlowMapCard",
        "AdminActionTable",
        "AdminStatusBadge",
    ]
    for marker in required:
        assert marker in src


def test_admin_withdrawals_runtime_component_is_read_only() -> None:
    src = read("frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "fetch(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdk",
        "idempotency",
        "mutateAsync",
        "synthetic_preview",
        "raw payload dump",
        "debug JSON dump",
        "buildTrend",
        "setInterval",
        "approveWith",
        "submitAction",
        "repairConsistency",
    ]
    for marker in forbidden:
        assert marker not in src
    assert "Derived snapshot display" in src
    assert "нет backend timestamps" in src


def test_admin_withdrawals_page_integrates_dashboard_safely() -> None:
    page = read("frontend/src/pages/admin/withdrawals.tsx")
    assert "AdminWithdrawalsDashboardRuntime" in page
    assert "loadDashboardSnapshots" in page
    assert "GET" in page
    assert "PENDING" in page
    assert "PAID" in page
    assert "REJECTED" in page
    assert "CANCELED" in page
    assert "AdminWithdrawalsMobileDecisionPanel" in page
    assert "AdminPromptModal" in page


def test_admin_withdrawals_guarded_actions_remain_outside_dashboard() -> None:
    page = read("frontend/src/pages/admin/withdrawals.tsx")
    component = read(
        "frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx"
    )
    for marker in [
        "payWithWallet",
        "openApprove",
        "openReject",
        "submitAction",
        "repairConsistency",
        "buildEfhcWithdrawTonConnectTx",
        "useWalletProvider",
        "sendTransaction(tx)",
    ]:
        assert marker in page
        assert marker not in component
    assert "idempotencyKey" in page
    assert "idempotencyKey" not in component


def test_admin_withdrawals_dashboard_does_not_overwrite_final_statuses() -> None:
    component = read(
        "frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx"
    )
    forbidden = [
        "setStatus(",
        "PAID =",
        "REJECTED =",
        "CANCELED =",
    ]
    # Type labels are allowed, but mutation-like assignments are forbidden.
    assert "final status" in component.lower()
    assert "Final statuses" in component
    for marker in forbidden:
        assert marker not in component


def test_admin_withdrawals_dashboard_has_no_raw_public_identifiers() -> None:
    component = read(
        "frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx"
    )
    assert "tg_id" not in component
    assert "raw payload" not in component.lower()
    assert "debug JSON" not in component
    assert "secrets" in component


def test_admin_withdrawals_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1486 — Admin Withdrawals Dashboard Upgrade",
        'data-admin-withdrawals-dashboard-runtime="1486"',
        ".efhc-admin-withdrawals-dashboard-grid",
        ".efhc-admin-withdrawals-dashboard-status-grid",
        ".efhc-admin-withdrawals-dashboard-table",
        ".efhc-admin-withdrawals-dashboard-row",
        ".efhc-admin-withdrawals-dashboard-boundary",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1486 — Admin Withdrawals Dashboard Upgrade" in corpus
    assert "ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE" in corpus
    assert "AdminWithdrawalsDashboardRuntime.tsx" in corpus
    assert "1487 — Admin Panels Dashboard Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype" in docs
    assert "No Grafana source code" in docs


def test_withdrawal_status_fields_are_real_runtime_fields() -> None:
    component = read(
        "frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx"
    )
    required = [
        "amount_efhc",
        "created_at",
        "processed_at",
        "error_message",
        "is_vip",
        "PENDING",
        "PAID",
        "REJECTED",
        "CANCELED",
    ]
    for marker in required:
        assert marker in component
    assert "fake withdrawal history" not in component.lower()
