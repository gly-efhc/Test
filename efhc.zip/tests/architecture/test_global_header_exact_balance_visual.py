from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HEADER = ROOT / "frontend/src/components/GlobalHeader.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"


def test_exact_balance_uses_one_same_size_numeric_run() -> None:
    source = HEADER.read_text(encoding="utf-8")
    assert 'className="efhc-game-header_balance-value"' in source
    assert 'data-header-balance-value={total}' in source
    assert 'title={total}' in source
    assert "{total}" in source
    assert "total.split" not in source
    assert "efhc-game-header_balance-whole" not in source
    assert "efhc-game-header_balance-fraction" not in source


def test_activ_and_vip_share_one_gold_active_style() -> None:
    css = CSS.read_text(encoding="utf-8")
    current = css.split(
        "/* v171.52: aligned gold status text and refined exact-balance card. */",
        1,
    )[1]
    shared_selector = (
        '.efhc-game-header_status[data-status="activ"]'
        '[data-active="true"],\n'
        '.efhc-game-header_status[data-status="vip"]'
        '[data-active="true"]'
    )
    assert shared_selector in current
    active_block = current.split(shared_selector, 1)[1].split("}", 1)[0]
    assert "color:#ffe29a" in active_block
    assert "text-shadow:" in active_block
    assert "background" not in active_block
    assert "box-shadow" not in active_block


def test_refined_balance_card_preserves_full_value_contract() -> None:
    css = CSS.read_text(encoding="utf-8")
    current = css.split(
        "/* v171.52: aligned gold status text and refined exact-balance card. */",
        1,
    )[1]
    assert ".efhc-game-header_balance{" in current
    assert "overflow:hidden" in current
    assert "linear-gradient" in current
    assert ".efhc-game-header_balance-value{" in current
    final = css.split(
        "/* v171.61: trusted visual baseline recovery.",
        1,
    )[1]
    value_block = final.split(
        ".efhc-game-header_balance-value{",
        1,
    )[1].split("}", 1)[0]
    assert "font-variant-numeric:tabular-nums lining-nums" in value_block
    assert "font-weight:900" in value_block
