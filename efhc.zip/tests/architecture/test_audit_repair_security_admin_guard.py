from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1329_docs_exist() -> None:
    required = [
        "docs/audits/AUDIT_REPAIR_CYCLE_1329_V169_08.md",
        "docs/security/ADMIN_ROUTE_GUARD_CANON.md",
        "docs/backend/ALEMBIC_MIGRATION_EVOLUTION_POLICY.md",
        "docs/backend/BACKEND_DEPENDENCY_RUNTIME_POLICY.md",
        "backend/requirements.lock",
        (
            "reports/change_cycle_2026-05-27_v169_08_cycle_1329_audit_"
            "repair_security_admin_guard.md"
        ),
        (
            "reports/generated/"
            "audit_repair_security_admin_guard_v169_08.json"
        ),
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_real_admin_tg_id_removed_from_repository_text() -> None:
    forbidden = "362" + "746" + "228"
    skip_dirs = {
        ".git",
        ".next",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        ".ruff_cache",
    }
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in skip_dirs for part in path.parts):
            continue
        if path.suffix.lower() in {
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".webp",
            ".pdf",
            ".zip",
            ".xz",
        }:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        assert forbidden not in text, str(path.relative_to(ROOT))


def test_frontend_has_global_admin_client_route_guard() -> None:
    text = read("frontend/src/pages/_app.tsx")
    assert 'router.pathname === "/admin"' in text
    assert 'router.pathname.startsWith("/admin/")' in text
    assert 'data-admin-client-route-guard="1329"' in text
    assert 'router.replace("/")' in text
    assert "AdminRouteGuardState" in text


def test__all__admin_pages_are_covered_by_namespace_guard() -> None:
    pages = sorted((ROOT / "frontend/src/pages/admin").glob("*.tsx"))
    assert len(pages) >= 17
    text = read("frontend/src/pages/_app.tsx")
    assert "isAdminRoute" in text
    assert "adminRouteBlocked" in text
    assert "adminRouteChecking" in text


def test_fastapi_docs_and_version_are_config_driven() -> None:
    text = read("backend/app/main.py")
    assert 'version=getattr(settings, "APP_VERSION", "0.0.0")' in text
    assert 'openapi_url=getattr(settings, "OPENAPI_URL", None)' in text
    assert 'docs_url=getattr(settings, "DOCS_URL", None)' in text
    assert 'redoc_url=getattr(settings, "REDOC_URL", None)' in text
    assert 'docs_url = "/docs"' not in text
    assert 'redoc_url = "/redoc"' not in text
    assert 'version = "1.0.0"' not in text


def test_config_converts_null_docs_urls_to_none() -> None:
    text = read("backend/app/core/config_core.py")
    assert "_empty_public_docs_url_to_none" in text
    assert '"OPENAPI_URL", "DOCS_URL", "REDOC_URL"' in text
    assert '{"", "null", "none", "false", "off"}' in text
    prod = read("env.prod.example")
    assert "OPENAPI_URL=null" in prod
    assert "DOCS_URL=null" in prod
    assert "REDOC_URL=null" in prod


def test_legacy_admin_headers_removed_from_admin_gate_and_cors() -> (
    None
):
    deps = read("backend/app/deps.py")
    main = read("backend/app/main.py")
    signature = deps.split("async def require_admin(", 1)[1].split(
        ") -> AuthContext", 1
    )[0]
    assert "X-Admin-Id" not in signature
    assert "X-Admin-Token" not in signature
    assert "admin_id_header" not in signature
    assert "admin_token" not in signature
    allow_headers = main.split("allow_headers=[", 1)[1].split("],", 1)[
        0
    ]
    assert "X-Admin-Id" not in allow_headers
    assert "X-Admin-Token" not in allow_headers


def test_runtime_requirements_do_not_include_test_helpers() -> None:
    text = read("backend/requirements.txt")
    lock = read("backend/requirements.lock")
    assert "pytest-asyncio" not in text
    assert "freezegun" not in text
    assert "pytest-asyncio" not in lock
    assert "freezegun" not in lock
    assert "uv pip compile backend/requirements.txt" in lock
    assert "requirements-dev.txt" in text
    assert "requirements-test.txt" in text


def test_reports_overview_is_bounded_single_snapshot_query() -> None:
    text = read("backend/app/routes/admin_routes.py")
    assert "SET LOCAL statement_timeout = '500ms'" in text
    assert "overview_q = text(" in text
    assert "with\n            ton as" in text
    reports_fn = text.split("async def reports_overview(", 1)[1]
    assert reports_fn.count("await db.execute") <= 2


def test_cycle_plan_shifted_after_out_of_plan_repair() -> None:
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1329: Out-of-plan audit repair" in text
    assert "1329: Out-of-plan audit repair" in text
    assert "1332: Shop admin actions" in text
    assert "SHIFTED from 1331" in text
    assert "1353: Admin recovery checkpoint report" in text


def test_admin_page_has_component_level_context_guard() -> None:
    text = read("frontend/src/components/admin/AdminPage.tsx")
    assert "LayoutContext" in text
    assert "ctx.isAdmin" in text
    assert "Доступ запрещён" in text
