from __future__ import annotations

from pathlib import Path

from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_wallet_provider_has_three_independent_adapters() -> None:
    provider = read("frontend/src/lib/wallet-provider/WalletProvider.tsx")
    types = read("frontend/src/lib/wallet-provider/types.ts")
    ton = read(
        "frontend/src/lib/wallet-provider/adapters/TonConnectAdapter.ts"
    )
    telegram = read(
        "frontend/src/lib/wallet-provider/adapters/TelegramWalletAdapter.ts"
    )
    native = read(
        "frontend/src/lib/wallet-provider/adapters/NativeGramWalletAdapter.ts"
    )

    assert '"tonconnect"' in types
    assert '"telegram_wallet"' in types
    assert '"native_gram_wallet"' in types
    assert "createTonConnectAdapter" in provider
    assert "createTelegramWalletAdapter" in provider
    assert "createNativeGramWalletAdapter" in provider
    assert provider.index("createTonConnectAdapter({") < provider.index(
        "createTelegramWalletAdapter()"
    ) < provider.index("createNativeGramWalletAdapter()")
    assert 'id: "tonconnect"' in ton
    assert 'id: "telegram_wallet"' in telegram
    assert 'id: "native_gram_wallet"' in native
    assert "adapterRevision" in provider
    assert "[activeAdapterId, adapterMap, adapterRevision]" in provider


def test_application_features_depend_only_on_wallet_provider() -> None:
    app = read("frontend/src/pages/_app.tsx")
    provider = read("frontend/src/lib/wallet-provider/WalletProvider.tsx")
    guarded = [
        "frontend/src/components/Layout.tsx",
        "frontend/src/components/DepositModal.tsx",
        "frontend/src/features/browser-shop/BrowserShopPage.tsx",
        "frontend/src/pages/admin/withdrawals.tsx",
        "frontend/src/components/profile/ProfileWalletSection.tsx",
        "frontend/src/components/profile/wallet/WalletConnectBanner.tsx",
    ]
    assert "<WalletProvider" in app
    assert "@tonconnect/ui-react" not in app
    assert "<TonConnectUIProvider" in provider
    for rel in guarded:
        source = read(rel)
        assert "@tonconnect/ui-react" not in source, rel
        assert "lib/tonconnect" not in source, rel
        assert "wallet-provider" in source or rel.endswith("Layout.tsx"), rel


def test_no_application_source_imports_tonconnect_sdk_directly() -> None:
    source_root = ROOT / "frontend/src"
    sdk_offenders: list[str] = []
    helper_offenders: list[str] = []
    for path in source_root.rglob("*"):
        if path.suffix not in {".ts", ".tsx"}:
            continue
        rel = path.relative_to(ROOT).as_posix()
        source = path.read_text(encoding="utf-8", errors="replace")
        if "@tonconnect/ui-react" in source and (
            "/lib/wallet-provider/" not in rel
        ):
            sdk_offenders.append(rel)
        if "lib/tonconnect" in source and (
            "/lib/wallet-provider/adapters/" not in rel
        ):
            helper_offenders.append(rel)
    assert sdk_offenders == []
    assert helper_offenders == []


def test_provider_contract_is_not_an_alias_of_tonconnect_types() -> None:
    types = read("frontend/src/lib/wallet-provider/types.ts")
    tx = read("frontend/src/lib/ton/tx.ts")
    assert 'from "../tonconnect"' not in types
    assert "WalletConnectionPhase" in types
    assert "WalletTransactionPhase" in types
    assert "WalletTransactionRequest = TonWalletTransaction" in types
    assert "TonWalletTransaction" in tx
    assert "@deprecated Compatibility alias" in tx


def test_unpublished_wallet_adapters_are_fail_closed_bridges() -> None:
    bridge = read(
        "frontend/src/lib/wallet-provider/adapters/bridgeAdapter.ts"
    )
    telegram = read(
        "frontend/src/lib/wallet-provider/adapters/TelegramWalletAdapter.ts"
    )
    native = read(
        "frontend/src/lib/wallet-provider/adapters/NativeGramWalletAdapter.ts"
    )
    assert 'version: "1"' in bridge
    assert "WalletAdapterUnavailableError" in bridge
    assert "if (!bridge || bridge.version !== \"1\")" in bridge
    assert "official Telegram/GRAM API is mapped inside its adapter only" in bridge
    assert "__EFHC_TELEGRAM_WALLET_ADAPTER__" in telegram
    assert "installTelegramWalletBridge" in telegram
    assert "__EFHC_NATIVE_GRAM_WALLET_ADAPTER__" in native
    assert "installNativeGramWalletBridge" in native
    assert "efhc:wallet-adapter:telegram_wallet" in telegram
    assert "efhc:wallet-adapter:native_gram_wallet" in native


def test_money_flows_dispatch_through_active_wallet_adapter() -> None:
    deposit = read("frontend/src/components/DepositModal.tsx")
    shop = read("frontend/src/features/browser-shop/BrowserShopPage.tsx")
    admin = read("frontend/src/pages/admin/withdrawals.tsx")
    for source in (deposit, shop, admin):
        assert "useWalletProvider" in source
        assert "sendTransaction" in source
    assert "providerName: walletProviderName" in admin
    assert "wallet_provider: provider" in admin
    assert 'data-wallet-transaction="signing"' in deposit
    assert "data-wallet-transaction={walletTxPhase}" in shop


def test_kernel_routes_native_wallet_request_exactly() -> None:
    query = (
        "Сделай Native-wallet adapter: WalletProvider, Wallet in Telegram "
        "и Native Gram Wallet"
    )
    result = classify_task(query)
    assert result["task_type"] == "wallet_provider_adapter_work"
    route = resolve_route("wallet_provider_adapter_work")
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "wallet_provider_adapter_layer"
    assert "docs/SSOT/WALLET_PROVIDER_SSOT.md" in route["docs"]
    assert any(
        "frontend/src/lib/wallet-provider" in item
        for item in route["allowed_write"]
    )
