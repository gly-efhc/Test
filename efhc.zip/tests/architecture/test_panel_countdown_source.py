from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVICE = ROOT / "backend/app/services/panels_service.py"
ROUTES = ROOT / "backend/app/routes/panels_routes.py"
FRONT = ROOT / "frontend/src/pages/panels.tsx"
FRONT_SEAMS = ROOT / (
    "frontend/src/lib/api/generated/economicUserSeams.ts"
)
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_backend_returns_remaining_seconds_contract() -> None:
    service = read(SERVICE)
    routes = read(ROUTES)
    assert "def _remaining_seconds(" in service
    assert '"remaining_seconds": _remaining_seconds(' in service
    assert "expires_at.astimezone(UTC)" in service
    assert "remaining_seconds: int | None = None" in routes
    assert 'remaining_seconds=i.get("remaining_seconds")' in routes


def test_frontend_uses_panel_list_server_now_anchor() -> None:
    src = read(FRONT)
    seams = read(FRONT_SEAMS)
    assert "listServerNowIso" in src
    assert "server_now_utc: string" in seams
    assert "pages.at(-1)?.server_now_utc" in src
    assert "panel-list-server-now-plus-client-stopwatch" in src
    assert 'data-panel-countdown-contract="1282"' in src


def test_frontend_countdown_displays_seconds_not_days_only() -> None:
    src = read(FRONT)
    assert "const SECONDS_PER_DAY = 86400" in src
    assert "const SECONDS_PER_HOUR = 3600" in src
    assert "const SECONDS_PER_MINUTE = 60" in src
    assert "const secs = afterHours % SECONDS_PER_MINUTE" in src
    assert '${secs}${t("common.sec_short")}' in src
    assert "common.day_short" in src
    assert "common.hour_short" in src
    assert "common.min_short" in src
    assert "common.sec_short" in src
    assert "p.remaining_seconds ?? null" in src


def test_frontend_countdown_arithmetic_values_are_correct() -> None:
    seconds_per_day = 86400
    seconds_per_hour = 3600
    seconds_per_minute = 60
    s = 180 * seconds_per_day
    assert s // seconds_per_day == 180
    assert (s % seconds_per_day) // seconds_per_hour == 0
    assert (s % seconds_per_hour) // seconds_per_minute == 0
    assert s % seconds_per_minute == 0


def test_cycle_1282_documented() -> None:
    plan = read(PLAN)
    reports = read(REPORTS)
    assert "v168_80 / work pass" in plan
    assert "remaining_seconds" in plan
    assert "v168_80 work pass" in reports
