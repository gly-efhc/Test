from __future__ import annotations

import re
from pathlib import Path


FORBIDDEN_PATTERNS = [
    r"available_kwh\s*-=",
    r"available_kwh\s*=\s*available_kwh\s*-",
    r"SET\s+available_kwh\s*=\s*available_kwh\s*-",
]


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def test_no_available_kwh_direct_debit_patterns() -> None:
    root = _repo_root()
    hits: list[str] = []
    for path in (root / "backend").rglob("*.py"):
        src = path.read_text(encoding="utf-8", errors="ignore")
        for pat in FORBIDDEN_PATTERNS:
            if re.search(pat, src):
                hits.append(f"{path.as_posix()}: {pat}")
    assert not hits, "Forbidden available_kwh direct debit: " + "; ".join(hits)
