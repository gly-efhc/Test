from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def _pinned(text: str, pkg: str) -> str:
    pattern = rf"{re.escape(pkg)}==(\d+\.\d+\.\d+)"
    match = re.search(pattern, text)
    assert match, f"{pkg} pin not found in requirements-test.txt"
    return match.group(1)


def _package_line(text: str, pkg: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{pkg}>="):
            return stripped
    raise AssertionError(f"{pkg} range not found")


def test_pytest_dev_allows_test_pin() -> None:
    pin = _pinned(read("requirements-test.txt"), "pytest")
    dev = read("requirements-dev.txt")
    major = int(pin.split(".")[0])
    line = _package_line(dev, "pytest")
    assert f"<{major}.0.0" not in line, (
        f"requirements-dev.txt blocks pytest major {major} "
        f"(pin={pin})"
    )


def test_pytest_asyncio_dev_allows_test_pin() -> None:
    pin = _pinned(read("requirements-test.txt"), "pytest-asyncio")
    dev = read("requirements-dev.txt")
    major = int(pin.split(".")[0])
    line = _package_line(dev, "pytest-asyncio")
    assert f"<{major}.0.0" not in line, (
        f"requirements-dev.txt blocks pytest-asyncio major {major} "
        f"(pin={pin})"
    )


def test_runtime_requirements_still_clean() -> None:
    runtime = read("backend/requirements.txt")
    lock = read("backend/requirements.lock")
    for pkg in ("pytest-asyncio", "freezegun"):
        assert pkg not in runtime
        assert pkg not in lock


def test_cycle_1340_policy_doc_exists() -> None:
    path = ROOT / "docs/backend/DEV_TEST_REQUIREMENTS_SYNC_POLICY.md"
    assert path.exists()


def test_webhook_secret_prod_guard_is_static_present() -> None:
    text = read("backend/app/core/config_core.py")
    assert '@model_validator(mode="after")' in text
    assert "_require_secrets_in_prod" in text
    assert "TELEGRAM_WEBHOOK_SECRET must be set in production" in text


def test_prod_env_example_has_secret_key_placeholder() -> None:
    text = read("env.prod.example")
    assert "SECRET_KEY=<your_hs256_secret_min_32_chars>" in text
