from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1326_documents_exist() -> None:
    paths = [
        "docs/admin/ADMIN_SANDBOX_PORTING_MAP.md",
        "docs/admin/ADMIN_DASHBOARD_UI_KIT_CANON.md",
        "docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md",
        (
            "docs/audits/"
            "FRONTEND_CYCLE_1326_ADMIN_SANDBOX_UI_KIT_AUDIT_V169_05.md"
        ),
        (
            "reports/"
            "change_cycle_2026-05-27_v169_05_cycle_1326_"
            "admin_sandbox_ui_kit.md"
        ),
    ]
    missing = [path for path in paths if not (ROOT / path).exists()]
    assert missing == []


def test_admin_ui_kit_foundation_exports_required_parts() -> None:
    text = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    required = [
        "AdminKpiCard",
        "AdminChartCard",
        "AdminFlowMapCard",
        "AdminFilterBar",
        "AdminActionTable",
        "AdminStatusBadge",
        "AdminConfirmationBlock",
        "AdminEmptyState",
        "AdminErrorState",
        "AdminSectionHeader",
    ]
    missing = [
        name for name in required if f"function {name}" not in text
    ]
    assert missing == []


def test_admin_dashboard_ui_kit_foundation_is_consolidated() -> None:
    text = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    required = [
        "AdminFilterBar",
        "AdminChartCard",
        "AdminFlowMapCard",
        "AdminKpiCard",
        "AdminEventFeed",
        "AdminDataTable",
    ]
    missing = [marker for marker in required if marker not in text]
    assert missing == []


def test_cycle_1325_runtime_replaced_and_orphan_deleted() -> None:
    home = read("frontend/src/pages/admin/index.tsx")
    orphan = ROOT / (
        "frontend/src/components/admin/"
        "AdminInteractiveBankDashboard.tsx"
    )
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in home
    assert "AdminInteractiveBankDashboard" not in home
    assert not orphan.exists()


def test_admin_ui_kit_not_static_only_after_cycle_1326() -> None:
    dashboard = read("frontend/src/components/admin/AdminDashboardUiKit.tsx")
    forbidden = [
        "static-only",
        "screenshot dashboard",
        "debug dump",
        "function buildSeries",
        "setInterval",
    ]
    bad = [
        marker for marker in forbidden if marker in dashboard.lower()
    ]
    assert bad == []
