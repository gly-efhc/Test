from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_shop_web3_component_exists_and_uses_ui_kit():
    text = read(
        "frontend/src/components/admin/AdminShopWeb3SeparationPanel.tsx"
    )
    assert 'data-admin-shop-web3-separation-cycle="1339"' in text
    assert "AdminSectionHeader" in text
    assert "AdminFilterBar" in text
    assert "AdminKpiCard" in text
    assert "AdminFlowMapCard" in text
    assert "AdminChartCard" in text
    assert "AdminActionTable" in text
    assert "AdminConfirmationBlock" in text
    assert "USDT planned" in text
    assert "Watcher match" in text or "watcher match" in text


def test_admin_shop_page_applies_panel_without_route_diagnostics_top():
    text = read("frontend/src/pages/admin/shop.tsx")
    assert "AdminShopWeb3SeparationPanel" in text
    assert "paymentLane" in text
    assert "AdminRouteHealthStrip" not in text
    assert "onPaymentLaneChange" in text


def test_admin_shop_docs_and_green_ci_checkpoint_exist():
    assert (
        ROOT / "docs/admin/ADMIN_SHOP_WEB3_SEPARATION_PANEL.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/CI_LOGS_71469302879_GREEN_CHECKPOINT_V169_18.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/FRONTEND_CYCLE_1339_ADMIN_SHOP_WEB3_SEPARATION_AUDIT_V169_18.md"
    ).exists()
    assert (
        ROOT
        / "reports/change_cycle_2026-05-29_v169_18_cycle_1339_admin_shop_web3_separation.md"
    ).exists()


def test_cycle_plan_moves_to_tasks_after_shop_cycle():
    text = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert (
        "1339: Shop admin actions and Web3 payment separation on UI "
        "Kit. DONE in v169_18."
        in text
    )
    assert "1340: Admin Tasks catalog UX" in text


def test_ci_workflow_remains_manual_control():
    text = read(
        "docs/audits/CI_LOGS_71469302879_GREEN_CHECKPOINT_V169_18.md"
    )
    assert "ci.yml was not changed" in text
    assert "manual-control" in text
