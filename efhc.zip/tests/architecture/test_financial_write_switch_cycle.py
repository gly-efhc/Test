"""Архитектурный замок write-side owner boundary цикла 1640."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = (
    ROOT / "backend/app/identity/financial_write_switch.py"
).read_text(encoding="utf-8")
READ_SOURCE = (
    ROOT / "backend/app/identity/financial_read_switch.py"
).read_text(encoding="utf-8")


def test_finансовая_запись_использует_global_id_как_канон() -> None:
    assert "class FinancialWriteOwner" in SOURCE
    assert "global_id: int" in SOURCE
    assert "legacy_tg_id: int | None" in SOURCE
    assert "rollback_ready: bool" in SOURCE


def test_finансовая_запись_блокирует_mapping_пользователя() -> None:
    assert "resolve_and_lock_financial_write_owner" in SOURCE
    assert ".with_for_update()" in SOURCE
    assert "User.global_id" in SOURCE
    assert "User.tg_id" in SOURCE
    assert "User.is_active" in SOURCE


def test_finансовая_запись_требует_dual_write() -> None:
    assert "control.dual_write_enabled" in SOURCE
    assert "Financial dual-write отключён" in SOURCE


def test_чтение_и_запись_используют_общий_control_loader() -> None:
    assert "async def _load_control" in READ_SOURCE
    assert "from app.identity.financial_read_switch import" in SOURCE
    assert "_load_control" in SOURCE
