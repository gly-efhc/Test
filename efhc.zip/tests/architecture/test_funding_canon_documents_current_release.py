from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_active_ssot_separates_direct_deposit_and_store_purchase() -> None:
    wallets = read("docs/SSOT/WALLETS_TONCONNECT_SSOT.md")
    hub = read("docs/SSOT/HUB_SSOT.md")
    assert "Direct deposit — `Прямое пополнение`" in wallets
    assert "Store purchase — `Пополнение`" in wallets
    assert "1 EFHCj = 1 EFHCm" in wallets
    assert "TON/GRAM or USDT jetton" in wallets
    assert "Прямое пополнение` is not a HUB function" in hub
    assert "GlobalHeader `+` MUST NOT open Browser Shop" in hub


def test_active_norms_do_not_keep_ton_only_or_usdt_deferred_state() -> None:
    rels = [
        "docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md",
        "docs/NORM/MVP_STAGING_AND_RELEASE_GATE_NORM.md",
        "docs/GENERAL/specification.md",
        "docs/GENERAL/architecture.md",
    ]
    for rel in rels:
        text = read(rel)
        assert "current live state is TON-only" not in text
        assert "USDT live storefront path remains cut" not in text
        assert "Текущий live checkout в browser-shop — TON-only" not in text
    browser = read("docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md")
    assert "USDT uses a real TEP-74 transfer body" in browser


def test_v171_35_direct_deposit_status_is_revoked() -> None:
    status = read("docs/NORM/RELEASE_PROOF_STATUS.md")
    assert "Release proof correction — v171.35" in status
    assert "INCORRECT_IMPLEMENTATION / REPAIR_REQUIRED" in status
    assert "All Direct Deposit verification claims" in status
