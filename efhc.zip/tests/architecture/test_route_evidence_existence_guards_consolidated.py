from __future__ import annotations

import ast
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
CASES_ROOT = ROOT / "tests/architecture/route_evidence_cases"
MODULE_CACHE: dict[str, object] = {}


def _case_functions(path: Path) -> list[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    return [
        node.name
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name.startswith("test_")
    ]


def _active_cases() -> list[tuple[str, str]]:
    cases: list[tuple[str, str]] = []
    for path in sorted(CASES_ROOT.glob("case_*.py")):
        rel = path.relative_to(ROOT).as_posix()
        cases.extend((rel, name) for name in _case_functions(path))
    return cases


def _load_support_module(rel_path: str) -> object:
    cached = MODULE_CACHE.get(rel_path)
    if cached is not None:
        return cached
    path = ROOT / rel_path
    spec = importlib.util.spec_from_file_location(
        "efhc_route_case_" + path.stem,
        path,
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    MODULE_CACHE[rel_path] = module
    return module


@pytest.mark.parametrize(
    ("support_module", "function_name"),
    _active_cases(),
)
def test_active_route_evidence_case(
    support_module: str,
    function_name: str,
) -> None:
    module = _load_support_module(support_module)
    getattr(module, function_name)()
