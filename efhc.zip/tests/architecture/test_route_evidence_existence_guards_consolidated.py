from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
_MODULE_CACHE: dict[str, object] = {}


def _load_support_module(rel_path: str) -> object:
    cached = _MODULE_CACHE.get(rel_path)
    if cached is not None:
        return cached
    path = ROOT / rel_path
    assert path.exists(), rel_path
    module_name = (
        "efhc_consolidated_"
        + rel_path.replace("/", "_").replace(".", "_")
    )
    spec = importlib.util.spec_from_file_location(
        module_name,
        path,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MODULE_CACHE[rel_path] = module
    return module


_CASES = [
    (
        "tests/architecture/route_evidence_cases/case_route_inventory_freeze_sync.py",
        "test_route_inventory_freeze_matches_ssot_routes",
    ),
    (
        "tests/architecture/route_evidence_cases/case_route_inventory_freeze_sync.py",
        "test_route_inventory_freeze_required_columns_present",
    ),
    (
        "tests/architecture/route_evidence_cases/case_route_inventory_freeze_sync.py",
        "test_route_inventory_freeze_markdown_count_sync",
    ),
    (
        "tests/architecture/route_evidence_cases/case_route_prefixes_no_embedded_api.py",
        "test_route_modules_do_not_embed_api_prefix",
    ),
    (
        "tests/architecture/route_evidence_cases/case_frontend_backend_contract_guard.py",
        "test_sensitive_frontend_seams_have_backend_routes",
    ),
    (
        "tests/architecture/route_evidence_cases/case_false_ui_road_guard.py",
        "test_false_ui_road_guard_1193",
    ),
    (
        "tests/architecture/route_evidence_cases/case_frontend_visible_functions_audit_guard.py",
        "test_visible_function_inventory_exists",
    ),
    (
        "tests/architecture/route_evidence_cases/case_frontend_visible_functions_audit_guard.py",
        "test_bottom_navigation_canon_is_unchanged",
    ),
    (
        "tests/architecture/route_evidence_cases/case_frontend_visible_functions_audit_guard.py",
        "test_audit_has_user_function_triage_model",
    ),
    (
        "tests/architecture/route_evidence_cases/case_frontend_visible_functions_audit_guard.py",
        "test_plan_preserves_canon_pages_and_dragon_visual_only",
    ),
    (
        "tests/architecture/route_evidence_cases/case_admin_visible_functions_guard_matrix.py",
        "test_admin_visible_functions_matrix_lists_all_admin_surfaces",
    ),
    (
        "tests/architecture/route_evidence_cases/case_admin_visible_functions_guard_matrix.py",
        "test_admin_visible_functions_have_backend_roads_and_guards",
    ),
    (
        "tests/architecture/route_evidence_cases/case_admin_visible_functions_guard_matrix.py",
        "test_admin_matrix_cross_links_existing_route_maps",
    ),
    (
        "tests/architecture/route_evidence_cases/case_admin_visible_functions_guard_matrix.py",
        "test_admin_matrix_preserves_sandbox_reference_boundary",
    ),
    (
        "tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py",
        "test_cycle_1394_guard_artifacts_exist",
    ),
    (
        "tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py",
        "test_generated_matrix_covers_public_triad_without_false_claims",
    ),
    (
        "tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py",
        "test_energy_route_component_and_public_boundary_chain",
    ),
    (
        "tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py",
        "test_panels_route_component_backend_and_money_chain",
    ),
    (
        "tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py",
        "test_exchange_route_component_backend_and_economy_chain",
    ),
    (
        "tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py",
        "test_cycle_1394_guard_is_registered_in_control_documents",
    ),
]


@pytest.mark.parametrize(
    ("support_module", "function_name"),
    _CASES,
)
def test_route_evidence_existence_guard_case(
    support_module: str,
    function_name: str,
) -> None:
    module = _load_support_module(support_module)
    target = getattr(module, function_name)
    target()
