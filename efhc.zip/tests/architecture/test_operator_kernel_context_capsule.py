from pathlib import Path

from ops.operator_kernel.context_capsule import build_context_capsule


def test_operator_kernel_context_capsule_contains_rules():
    text = build_context_capsule(
        "CI logs repair for pytest freezegun",
        root=Path.cwd(),
        archive_name="EFHC_Bot_v169_15.zip",
    )
    assert "EFHC Context Capsule" in text
    assert "ci_logs_repair_or_verification" in text
    assert "silent ci.yml" in text
    assert "LOCAL_AUX_CHECK_ONLY" in text
    cache = Path("ops/operator_kernel/cache/context_capsule_latest.md")
    assert cache.exists()
