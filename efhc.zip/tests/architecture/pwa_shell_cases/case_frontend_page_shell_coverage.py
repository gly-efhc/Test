from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PAGES = ROOT / "frontend" / "src" / "pages"
APP = PAGES / "_app.tsx"
ADS = PAGES / "ads.tsx"


def test_app_wraps_pages_with_layout() -> None:
    text = APP.read_text(encoding="utf-8")
    assert "<Layout" in text
    assert "</Layout>" in text


def test_ads_page_is_redirect_only() -> None:
    text = ADS.read_text(encoding="utf-8")
    assert 'replace("/tasks")' in text


def test_user_pages_exist_under_pages_dir() -> None:
    expected = {
        "index.tsx",
        "exchange.tsx",
        "faq.tsx",
        "panels.tsx",
        "ranks.tsx",
        "referrals.tsx",
        "tasks.tsx",
        "ads.tsx",
        "hub.tsx",
        "referrals/active.tsx",
        "referrals/inactive.tsx",
    }
    found = {
        str(p.relative_to(PAGES))
        for p in PAGES.rglob("*.tsx")
        if "admin/" not in str(p.relative_to(PAGES))
        and p.name != "app.tsx"
    }
    missing = expected - found
    assert not missing, f"Missing user pages: {sorted(missing)}"
