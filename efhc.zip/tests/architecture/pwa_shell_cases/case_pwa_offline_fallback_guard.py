from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def test_service_worker_has_offline_fallback_shell() -> None:
    sw = (ROOT / "frontend/public/sw.js").read_text(encoding="utf-8")
    assert "OFFLINE_URL" in sw
    assert "/offline.html" in sw
    assert "caches.match(fallback)" in sw
    assert "offline-readonly.html" in sw
    assert "navigationFallback" in sw
    assert (ROOT / "frontend/public/offline.html").exists()
