from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_first_paint_is_dark_before_javascript() -> None:
    src = read("frontend/src/pages/_document.tsx")
    assert '<Html lang="en" data-theme="dark">' in src
    assert 'background: "#0a0a0f"' in src
    assert "telegram-web-app.js" in src


def test_default_theme_is_dark_not_white_auto() -> None:
    src = read("frontend/src/lib/settings.ts")
    assert 'theme_mode: "dark"' in src
    assert "Default is dark" in src


def test_splash_cannot_wait_forever_on_empty_dictionaries() -> None:
    src = read("frontend/src/pages/_app.tsx")
    assert "uiDictLoaded" in src
    assert "ruDictLoaded" in src
    assert "descDictLoaded" in src
    assert "Object.keys(uiDict).length > 0" not in src
    assert "Object.keys(ruDict).length > 0" not in src
    assert "Object.keys(descDict).length > 0" not in src


def test_energy_progress_bar_is_visible_at_zero_progress() -> None:
    src = read("frontend/src/pages/index.tsx")
    assert "visibleProgressPct" in src
    assert "const visibleProgressPct = displayPct" in src
    assert "width: `${visibleProgressPct}%`" in src
    assert "data-has-progress={visibleProgressPct > 0" in src


def test_referrals_do_not_fetch_with_missing_tg_id() -> None:
    src = read("frontend/src/pages/referrals.tsx")
    assert "tg_id: number | null" in src
    query_src = read("frontend/src/queries/useReferrals.ts")
    assert "enabled: Boolean(globalId)" in query_src
    assert "referrals.browser_link_pending" in src
    list_src = read(
        "frontend/src/components/referrals/ReferralListPage.tsx",
    )
    assert "parent_tg_id: number | null" not in list_src
    assert "useReferralList(props.tab)" in list_src
    assert "enabled: Boolean(globalId)" in query_src


def test_chat_agreement_list_exists() -> None:
    src = read("docs/audits/CHAT_VISIBLE_FRONTEND_AGREEMENT.md")
    assert "Energy" in src
    assert "Referrals" in src
    assert "Profile / Wallet" in src
    assert "оставить" in src
