from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_browser_fallback_snapshot_exists() -> None:
    src = read("frontend/src/lib/browserFallback.ts")
    assert "getBrowserFallbackSnapshot" in src
    assert "EFHC Player" in src
    assert "browser-player" not in src
    assert "total_generated_kwh" in src
    assert "gen_per_sec_effective" in src


def test_app_passes_visible_snapshot_without_tg_id() -> None:
    src = read("frontend/src/pages/_app.tsx")
    assert "snap ?? getBrowserFallbackSnapshot()" in src
    assert "snapshot={visibleSnap}" in src
    assert "snap={visibleSnap}" in src


def test_energy_keeps_page_without_tg_id() -> None:
    src = read("frontend/src/pages/index.tsx")
    assert "if (!props.tg_id)" not in src
    assert "LiveEnergyHeroAndProgress" in src
    assert "efhc-energy-progress-track" in src


def test_core_pages_do_not_blank_when_tg_id_missing() -> None:
    for path in [
        "frontend/src/pages/panels.tsx",
        "frontend/src/pages/exchange.tsx",
        "frontend/src/pages/tasks.tsx",
        "frontend/src/pages/ranks.tsx",
        "frontend/src/pages/withdraw.tsx",
    ]:
        src = read(path)
        assert '<Card title={t("common.loading")}' not in src
        loading_empty = (
            '<TelegramEmptyState title={t("common.loading")}'
        )
        assert loading_empty not in src
        assert "withdraw.loading_title" not in src


def test_tasks_has_browser_fallback_actions() -> None:
    src = read("frontend/src/pages/tasks.tsx")
    assert "fallbackCatalog" in src
    assert "browser-demo" in src
    assert "tasks.demo_watch_ad_title" in src


def test_plain_language_rule_is_documented() -> None:
    src = read("docs/audits/HUMAN_QUESTIONS_STYLE_RULE.md")
    assert "technical" not in src.lower() or "human" in src.lower()
