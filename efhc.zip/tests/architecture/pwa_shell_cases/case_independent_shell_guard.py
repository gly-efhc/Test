from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_profile_opens_as_page_not_overlay() -> None:
    layout = read("frontend/src/components/Layout.tsx")
    assert 'pathname: "/web-profile"' in layout
    assert "setProfileOpen(true)" not in layout
    assert "<ProfileModal" not in layout


def test_profile_page_has_back_and_exit_controls() -> None:
    page = read("frontend/src/features/profile/WebProfilePage.tsx")
    assert 't("profile.back")' in page
    assert 't("profile.exit")' in page
    assert "goBack(router)" in page
    assert "goHome(router)" in page


def test_profile_page_no_longer_requires_telegram_token() -> None:
    page = read("frontend/src/features/profile/WebProfilePage.tsx")
    assert "token_required" not in page
    assert "SHOPFRONT_PROFILE_PATH" not in page
    assert "BrowserShopProfileResponse" not in page


def test_independent_shell_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    assert ".efhc-independent-shell" in css
    assert ".efhc-independent-shell_frame" in css
    assert "var(--efhc-app-width)" in css


def test_locale_no_telegram_shell_for_profile_note() -> None:
    en = read("frontend/public/locale/en.json")
    ru = read("frontend/public/locale/ru.json")
    assert "own game shell" in en
    assert "Telegram data can personalize" in en
    assert "собственную игровую оболочку" in ru
    assert "не являются условием работы" in ru
