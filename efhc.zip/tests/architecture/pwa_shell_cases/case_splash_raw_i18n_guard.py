from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
APP = ROOT / "frontend/src/pages/_app.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
I18N = ROOT / "frontend/src/lib/i18n.ts"
LOCALE_DIR = ROOT / "frontend/public/locale"

RAW_KEY_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$")


OLD_PUBLIC_KEYS = [
    "nav.hub",
    "energy.title",
    "energy.progress_label",
    "energy.remaining_to_next",
    "panels.title",
    "tasks.title",
    "referrals.title",
    "ranks.title",
]


def test_i18n_has_human_fallback_instead_of_raw_key() -> None:
    text = I18N.read_text(encoding="utf-8")
    assert "humanizeMissingI18nKey" in text
    assert "isRawI18nKey" in text
    assert "humanizeMissingI18nKey(k)" in text
    assert "|| k;" not in text


def test_locale_values_do_not_store_raw_i18n_keys() -> None:
    bad: list[str] = []
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key, value in data.items():
            if not isinstance(value, str):
                continue
            if RAW_KEY_RE.match(value.strip()):
                bad.append(f"{path.name}:{key}={value}")
    assert bad == []


def test_splash_uses_named_timeout_constants() -> None:
    text = APP.read_text(encoding="utf-8")
    assert "SHELL_BOOT_TIMEOUT_MS" in text
    assert "SPLASH_FADE_MS" in text
    assert "SPLASH_UNMOUNT_MS" in text
    assert "setShellTimeoutReady(true)" in text
    assert "efhcLoadingReason" in text


def test_shell_booting_and_ready_css_are_present() -> None:
    text = CSS.read_text(encoding="utf-8")
    assert 'html[data-efhc-shell="booting"] body' in text
    assert 'html[data-efhc-shell="booting"] #_next' in text
    assert 'html[data-efhc-shell="ready"] body' in text
    assert "background:#0a0a0f" in text


def test_old_public_raw_keys_are_not_locale_values() -> None:
    values: list[str] = []
    for path in sorted(LOCALE_DIR.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        values.extend(str(item).strip() for item in data.values())
    for key in OLD_PUBLIC_KEYS:
        assert key not in values
