from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
FRONTEND_SRC = ROOT / "frontend/src"
LOCALE_DIR = ROOT / "frontend/public/locale"
DOC = ROOT / "docs/frontend/FRONTEND_PWA_INSTALL_POLICY.md"
MANIFEST = ROOT / "frontend/public/manifest.webmanifest"
SW = ROOT / "frontend/public/sw.js"

FORBIDDEN_CODE_MARKERS = [
    "beforeinstallprompt",
    "deferredPrompt",
]

FORBIDDEN_LABELS = [
    "install app",
    "install efhc",
    "add to home screen",
    "установить приложение",
    "установить efhc",
]


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def _frontend_sources() -> list[Path]:
    suffixes = {".ts", ".tsx", ".js", ".jsx"}
    return sorted(
        p
        for p in FRONTEND_SRC.rglob("*")
        if p.is_file() and p.suffix in suffixes
    )


def test_pwa_policy_document_exists() -> None:
    text = _read(DOC)
    assert "browser/system install control" in text
    assert "No separate EFHC install button" in text
    assert "beforeinstallprompt" in text


def test_manifest_and_service_worker_remain_present() -> None:
    manifest = _read(MANIFEST)
    sw = _read(SW)
    assert '"display": "standalone"' in manifest
    assert '"start_url"' in manifest
    assert 'self.addEventListener("install"' in sw
    assert "event.respondWith" in sw
    assert "navigationFallback" in sw
    assert "cacheFirst" in sw


def test_no_custom_pwa_install_flow_in_frontend_src() -> None:
    offenders: list[str] = []
    for path in _frontend_sources():
        text = _read(path)
        for marker in FORBIDDEN_CODE_MARKERS:
            if marker in text:
                rel = path.relative_to(ROOT)
                offenders.append(f"{rel}: {marker}")
    assert offenders == []

    pwa = _read(ROOT / "frontend/src/components/PwaRuntimeStatus.tsx")
    assert "appinstalled" in pwa
    assert "navigator.storage.persist" in pwa


def test_no_custom_install_button_labels_in_public_locale() -> None:
    offenders: list[str] = []
    for path in sorted(LOCALE_DIR.glob("*.json")):
        text = _read(path).lower()
        for label in FORBIDDEN_LABELS:
            if label in text:
                rel = path.relative_to(ROOT)
                offenders.append(f"{rel}: {label}")
    assert offenders == []

    pwa = _read(ROOT / "frontend/src/components/PwaRuntimeStatus.tsx")
    assert "appinstalled" in pwa
    assert "navigator.storage.persist" in pwa
