from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
APP = ROOT / "frontend/src/pages/_app.tsx"
PWA = ROOT / "frontend/src/components/PwaRuntimeStatus.tsx"
MANIFEST = ROOT / "frontend/public/manifest.webmanifest"
SW = ROOT / "frontend/public/sw.js"
ICON_192 = ROOT / "frontend/public/assets/efhc/efhc_coin_192.png"
ICON_512 = ROOT / "frontend/public/assets/efhc/efhc_coin_512.png"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_browser_app_manifest_is_linked_from_app() -> None:
    src = _read(APP)

    assert 'import Head from "next/head";' in src
    assert '<link rel="manifest" href="/manifest.webmanifest" />' in src
    assert 'name="apple-mobile-web-app-capable"' in src
    assert 'name="theme-color"' in src


def test_service_worker_is_registered_safely() -> None:
    src = _read(APP)
    pwa = _read(PWA)

    assert '"serviceWorker" in navigator' in src
    assert '.register("/sw.js")' in pwa
    assert 'window.location.protocol !== "https:"' in pwa
    assert 'window.location.hostname === "localhost"' in pwa


def test_manifest_supports_standalone_browser_mode() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))

    assert data["name"] == "EFHC Bot"
    assert data["short_name"] == "EFHC"
    assert data["display"] == "standalone"
    assert data["start_url"] == "/?source=pwa"
    assert data["scope"] == "/"
    assert {icon["sizes"] for icon in data["icons"]} >= {
        "192x192",
        "512x512",
    }
    assert ICON_192.exists() and ICON_192.stat().st_size > 0
    assert ICON_512.exists() and ICON_512.stat().st_size > 0


def test_service_worker_is_network_safe_for_apis() -> None:
    src = _read(SW)

    assert "fetch" in src
    assert 'request.method !== "GET"' in src
    assert "fetch(request)" in src
    assert "isApiRequest" in src
    assert 'pathname.startsWith("/admin/")' in src
    assert "cache.put" in src
    assert "navigationFallback" in src
