from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
APP = ROOT / "frontend/src/pages/_app.tsx"
DOC = ROOT / "frontend/src/pages/_document.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
LAYOUT = ROOT / "frontend/src/components/Layout.tsx"
MANIFEST = ROOT / "frontend/public/manifest.webmanifest"
SW = ROOT / "frontend/public/sw.js"


def test_document_has_dark_first_paint_css() -> None:
    text = DOC.read_text(encoding="utf-8")
    assert "efhc-first-paint-css" in text
    assert "html,body,#_next" in text
    assert "background:#0a0a0f" in text
    assert "efhc-first-paint-body" in text


def test_global_css_prevents_blank_white_shell() -> None:
    text = CSS.read_text(encoding="utf-8")
    assert "#_next" in text
    assert ".efhc-first-paint-body" in text
    assert ".efhc-first-paint-safe" in text
    assert "overflow-x: hidden" in text


def test_app_has_splash_timeout_escape() -> None:
    text = APP.read_text(encoding="utf-8")
    assert "shellTimeoutReady" in text
    assert "effectiveSplashReady" in text
    assert "setShellTimeoutReady(true)" in text
    assert "root.dataset.efhcShell" in text
    assert "booting" in text
    assert "ready" in text


def test_browser_login_keeps_route_exceptions() -> None:
    text = LAYOUT.read_text(encoding="utf-8")
    assert "showBrowserLoginDemo" in text
    assert 'router.pathname !== "/browser-shop"' in text
    assert 'router.pathname.startsWith("/admin")' in text


def test_pwa_manifest_starts_at_energy_root() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert data["start_url"].startswith("/")
    assert data["display"] == "standalone"
    assert data["background_color"].startswith("#")
    assert data["theme_color"].startswith("#")


def test_service_worker_has_privacy_safe_cache_strategies() -> None:
    text = SW.read_text(encoding="utf-8")
    assert 'request.method !== "GET"' in text
    assert "isApiRequest" in text
    assert "navigationFallback" in text
    assert "cacheFirst" in text
    assert "staleWhileRevalidate" in text
    assert 'pathname.startsWith("/admin/")' in text
