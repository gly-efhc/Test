from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_telegram_shell_helpers_expose_viewport_and_safe_area_markers():
    src = read("frontend/src/lib/telegram.ts")
    assert "isTelegramMiniApp" in src
    assert "dataset.tmaShell" in src
    assert "dataset.tgPlatform" in src
    assert "dataset.tgViewportState" in src
    assert "--tg-content-safe-top" in src
    assert "--tg-device-safe-bottom" in src
    assert "viewportChanged" in src
    assert "applyTelegramCssVars();" in src


def test_layout_has_public_route_backbutton_without_admin_leak():
    src = read("frontend/src/components/Layout.tsx")
    assert (
        'data-tma-shell-polish="viewport-theme-backbutton-safe-area"'
        in src
    )
    assert (
        'data-public-shell-route={isAdminRoute ? "admin" : "public"}'
        in src
    )
    assert 'const publicRootRoute = router.pathname === "/";' in src
    assert (
        "isAdminRoute || depositOpen || walletModalOpened || "
        "publicRootRoute"
        in src
    )
    assert "navigateBackWithinApp(router);" in src
    controller = read("frontend/src/lib/appBackNavigation.ts")
    assert "router.back();" in controller
    assert 'root_fallback: "/"' in controller
    assert "__EFHC_ANDROID_BACK__" in controller


def test_tma_shell_css_exists_and_uses_safe_area_tokens():
    css = read("frontend/src/styles/globals.css")
    assert "1374 TMA shell polish" in css
    assert ".efhc-tma-shell" in css
    assert 'data-tma-shell="telegram"' in css
    assert 'data-tg-viewport-state="compact"' in css
    assert "--efhc-safe-top" in css
    assert "--efhc-safe-bottom" in css


def test_tma_shell_docs_and_generated_manifest_exist():
    assert (
        ROOT / "docs/frontend/TELEGRAM_MINI_APP_SHELL_POLISH.md"
    ).exists()
    assert (
        ROOT
        / "docs/audits/TELEGRAM_MINI_APP_SHELL_POLISH_AUDIT_V169_53.md"
    ).exists()
    assert (
        ROOT
        / "reports/generated/telegram_mini_app_shell_polish_v169_53.json"
    ).exists()


def test_sandbox_runtime_frameworks_not_imported_by_tma_polish():
    touched = "\n".join(
        [
            read("frontend/src/lib/telegram.ts"),
            read("frontend/src/components/Layout.tsx"),
        ]
    )
    forbidden = [
        "from 'vue'",
        'from "vue"',
        "from 'solid-js'",
        'from "solid-js"',
        "from 'nuxt'",
        'from "nuxt"',
    ]
    for marker in forbidden:
        assert marker not in touched
