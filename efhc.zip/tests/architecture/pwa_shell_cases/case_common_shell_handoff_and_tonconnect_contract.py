from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


def _read(*parts: str) -> str:
    return (ROOT.joinpath(*parts)).read_text(encoding="utf-8")


def test_single_tonconnect_provider_lives_in_app_shell() -> None:
    app = _read("frontend", "src", "pages", "_app.tsx")
    provider = _read(
        "frontend", "src", "lib", "wallet-provider", "WalletProvider.tsx"
    )
    assert app.count("<WalletProvider") == 1
    assert provider.count("<TonConnectUIProvider") == 1
    assert "actionsConfiguration" in provider
    assert "twaReturnUrl" in provider


def test_compat_hook_uses_real_connection_restored_promise() -> None:
    compat = _read(
        "frontend",
        "src",
        "lib",
        "vendor",
        "tonconnect-ui-react-compat.tsx",
    )
    assert (
        "export function useIsConnectionRestored(): boolean" in compat
    )
    assert "inst.connectionRestored" in compat
    assert "setRestoreSettled(true)" in compat
    assert "return useTonConnectContext().restoreSettled" in compat
    assert "setWallet(nextWallet)" in compat


def test_efhc_handoff_and_external_storefront_contract_stay_split() -> (
    None
):
    hub = _read("backend", "app", "routes", "hub_routes.py")
    schemas = _read("backend", "app", "schemas", "hub_schemas.py")
    hub_page = _read(
        "frontend", "src", "features", "hub", "HubPage.tsx"
    )
    hub_service = _read(
        "frontend", "src", "services", "hub.service.ts"
    )

    assert '"kind": "hub_efhc_handoff"' in hub
    assert '"aud": "efhc_buy_site"' in hub
    assert 'transport: Literal["external_url"]' in schemas
    assert 'storefront_mode: Literal["browser_shop_mvp"]' in schemas
    assert '"/hub/efhc-handoff"' in hub_service
    assert "useHubEfhcHandoff" in hub_page
    assert 'data-hub-visible-action-count="2"' in hub_page
    assert "getgems.io/efhc-nft" in hub_page
