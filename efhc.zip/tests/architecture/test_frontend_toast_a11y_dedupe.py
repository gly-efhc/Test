from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_toast_layer_has_dedupe_and_accessibility_roles() -> None:
    src = read("frontend/src/components/Layout.tsx")
    assert "createdAt - item.createdAt < 2500" in src
    assert ".slice(-3)" in src
    assert 'role={item.kind === "error" ? "alert" : "status"}' in src
    assert 'aria-live={item.kind === "error" ? "assertive" : "polite"}' in src
    assert 'aria-atomic="true"' in src


def test_tasks_and_withdraw_errors_do_not_duplicate_inline_and_toast() -> None:
    tasks = read("frontend/src/pages/tasks.tsx")
    withdraw = read("frontend/src/pages/withdraw.tsx")
    assert 'ctx.toast(message, "error")' not in tasks
    assert 'toast(message, "error")' not in withdraw
    assert 'ctx.toast(text, "success")' in tasks
    assert 'toast(t("withdraw.toast_created"), "success")' in withdraw
