from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_outcome_models_exist() -> None:
    text = _read("backend/app/models/outcome_models.py")
    assert "class WithdrawOutcomeEvent" in text
    assert "class OutcomeFallbackPromo" in text


def test_outcome_tables_are_integrated_into_0001() -> None:
    text = _read("backend/migrations/versions/0001_initial_release_schema.py")
    assert "withdraw_outcome_events" in text
    assert "outcome_fallback_promos" in text


def test_outcome_api_route_exists() -> None:
    text = _read("backend/app/routes/me_routes.py")
    assert "/v1/me/withdraw-outcomes/{request_id}" in text
    assert "get_withdraw_outcome_bundle" in text


def test_admin_withdrawals_persist_outcome_event() -> None:
    text = _read(
        "backend/app/services/admin/" "admin_withdrawals_service.py"
    )
    assert "build_withdraw_outcome_bundle" in text
    assert "save_withdraw_outcome_event" in text
