from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_frontend_dockerfile_uses_current_npm_ci_standard() -> None:
    dockerfile = read("ops/docker/Dockerfile.frontend")

    assert (
        "npm config set registry https://registry.npmjs.org/"
        in dockerfile
    )
    assert "RUN npm ci" in dockerfile
    assert "--no-audit" in dockerfile
    assert "--no-fund" in dockerfile
    assert "--progress=false" in dockerfile
    assert "--fetch-retries=5" in dockerfile
    assert 'CMD ["npm", "run", "dev"' in dockerfile


def test_package_uses_next16_react19_tailwind4_standard() -> None:
    data = json.loads(read("frontend/package.json"))
    deps = data.get("dependencies", {})
    dev_deps = data.get("devDependencies", {})

    assert deps.get("next") == "16.2.6"
    assert deps.get("react") == "19.2.6"
    assert deps.get("react-dom") == "19.2.6"
    assert dev_deps.get("tailwindcss") == "4.3.0"
    assert dev_deps.get("@tailwindcss/postcss") == "4.3.0"
    assert data.get("scripts", {}).get("dev") == "next dev --turbo"
    overrides = data.get("overrides", {})
    assert overrides.get("axios") == "$axios"
    assert overrides.get("postcss") == "$postcss"
    assert overrides.get("follow-redirects") == "^1.15.12"
