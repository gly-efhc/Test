from __future__ import annotations

import json
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / "docs/NORM/PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md"
GRAFANA_DOC = ROOT / "docs/NORM/PANELS_PORTFOLIO_SANDBOX_GRAFANA_ELEMENT_ANALYSIS.md"
TSX = ROOT / "frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx"
PANELS_PAGE = ROOT / "frontend/src/pages/panels.tsx"
CSS = ROOT / "frontend/src/styles/globals.css"
REPORT = ROOT / "reports/generated/panels_portfolio_sandbox_prototype_v170_47.json"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
TEST_MANIFEST = ROOT / "docs/testing/TEST_GUARD_MANIFEST.md"
TEST_MANIFEST_JSON = ROOT / "docs/testing/TEST_GUARD_MANIFEST.json"
CYCLE_DOC = ROOT / "docs/cycles/WORK_CYCLES_1471_PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md"
GRAFANA_MAP = ROOT / "docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md"
SANDBOX_INVENTORY = ROOT / "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_panels_portfolio_sandbox_docs_exist_and_set_scope() -> None:
    text = read(DOC)
    assert "ACTIVE_PANELS_PORTFOLIO_SANDBOX_PROTOTYPE" in text
    assert "Cycle: `1471`" in text
    assert "synthetic_preview" in text
    assert "runtime `/panels` route" in text
    assert "panel lifecycle = `180 days`" in text
    assert "activation remains in existing runtime guarded flow" in text
    assert "No Grafana source code is copied" in text
    assert "No Песочница runtime code is copied" in text


def test_panels_portfolio_sandbox_component_is_preview_only() -> None:
    text = read(TSX)
    required = [
        "export function PanelsPortfolioSandboxPrototype",
        "EFHC_PANELS_PORTFOLIO_SANDBOX_PROTOTYPE_V1",
        "data-panels-portfolio-sandbox-prototype=\"1471\"",
        "data-panels-portfolio-data-kind=\"synthetic_preview\"",
        "data-panels-portfolio-preview-only=\"true\"",
        "data-panels-portfolio-runtime-route-changed=\"false\"",
        "data-panels-portfolio-write-flow=\"false\"",
        "data-panel-lifetime-days=\"180\"",
        "data-grafana-reference-only=\"true\"",
        "data-sandbox-reference-only=\"true\"",
        "SimPanelStateFilter",
        "SimPeriodFilter",
        "SimCountdownProgress",
        "SimMiniAreaChart",
        "SimMiniBarChart",
        "SimMiniSparkline",
        "SimActivityStrip",
        "SimSegmentedProgress",
    ]
    for marker in required:
        assert marker in text

    forbidden = [
        "@grafana/",
        "SceneObject",
        "apiRequest",
        "fetch(",
        "axios",
        "method: \"POST\"",
        "method: \"PUT\"",
        "method: \"PATCH\"",
        "method: \"DELETE\"",
        "onSubmit",
        "formAction",
        "activatePanel(",
        "withdraw",
        "mint",
        "burn",
        "transfer-to-user",
    ]
    for marker in forbidden:
        assert marker not in text


def test_live_panels_route_was_not_ported_in_sandbox_cycle() -> None:
    text = read(PANELS_PAGE)
    assert "PanelsPortfolioSandboxPrototype" not in text
    assert "data-panels-layout=\"active-archive\"" in text
    assert "data-panel-activation-cta=\"100-efhc\"" in text
    assert "data-panel-activation-debit=\"bonus-first-main-second\"" in text


def test_panels_portfolio_css_uses_dashboard_tokens_and_mobile_safety() -> None:
    css = read(CSS)
    required = [
        "Cycle 1471 — Panels Portfolio Sandbox Prototype",
        ".efhc-panels-dashboard-sandbox",
        ".efhc-panels-dashboard-sandbox__kpi-strip",
        ".efhc-panels-dashboard-sandbox__summary-grid",
        ".efhc-panels-dashboard-sandbox__panel-grid",
        ".efhc-panels-dashboard-sandbox__rules",
        "var(--efhc-dash-border)",
        "var(--efhc-dash-accent)",
        "overflow-wrap: anywhere",
        "repeat(auto-fit, minmax(230px, 1fr))",
    ]
    for marker in required:
        assert marker in css


def test_generated_report_records_truth_boundaries() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1471
    assert data["version"] == "v170.47"
    assert data["truth_model"]["data_kind"] == "synthetic_preview"
    assert data["truth_model"]["preview_only"] is True
    assert data["truth_model"]["runtime_truth_claimed"] is False
    assert data["truth_model"]["real_analytics_claimed"] is False
    assert data["truth_model"]["live_panels_route_changed"] is False
    assert data["truth_model"]["panel_lifetime_days"] == 180
    for key in [
        "economy_changed",
        "backend_contracts_changed",
        "db_migrations_changed",
        "openapi_changed",
        "dependencies_changed",
        "lock_files_changed",
        "ci_workflows_changed",
        "grafana_runtime_code_copied",
        "sandbox_runtime_code_copied",
        "write_flows_changed",
        "money_actions_added",
        "live_panels_route_changed",
        "panel_activation_logic_changed",
    ]:
        assert data["boundaries"][key] is False
    assert data["tests"]["npm_audit_total_vulnerabilities"] == 0


def test_grafana_panels_analysis_is_reference_only() -> None:
    text = read(GRAFANA_DOC)
    for marker in [
        "PanelChrome.tsx",
        "PanelHeader",
        "PanelStatus.tsx",
        "DashboardGrid",
        "DashboardControls.tsx",
        "Variables",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "BigValue",
        "BarGauge",
        "Sparkline/Sparkline.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
        "No Grafana source code is copied",
        "EFHC-owned implementation target code",
    ]:
        assert marker in text
    assert "Grafana is not a code donor" in text


def test_navigation_and_manifest_register_panels_portfolio_cycle() -> None:
    for path in [KERNEL, MAP, ROUTES, TEST_MANIFEST, CYCLE_DOC]:
        text = read(path)
        assert "Panels Portfolio Sandbox Prototype" in text
        assert "PANELS_PORTFOLIO_SANDBOX_PROTOTYPE" in text
        assert "PanelsPortfolioSandboxPrototype.tsx" in text
        assert "test_panels_portfolio_sandbox_prototype.py" in text
    manifest = load(TEST_MANIFEST_JSON)
    item = manifest["cycle_1471_panels_portfolio_sandbox_prototype"]
    assert item["status"] == "active"
    assert item["browser_screenshots_claimed"] is False
    assert item["release_ready_claimed"] is False


def test_maps_include_panels_portfolio_reference_only_boundaries() -> None:
    for path in [MAP, GRAFANA_MAP, SANDBOX_INVENTORY]:
        text = read(path)
        assert "Cycle 1471" in text
        assert "Panels Portfolio" in text
    assert "No Grafana source code is copied" in read(GRAFANA_MAP)
    assert "No Песочница runtime code is copied" in read(SANDBOX_INVENTORY)


def test_grafana_archive_contains_panels_reference_anchors() -> None:
    zip_path = ROOT.parent / "grafana-main.zip"
    if not zip_path.exists():
        return
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    for marker in [
        "PanelChrome.tsx",
        "PanelStatus.tsx",
        "DashboardControls.tsx",
        "TimeRangePicker.tsx",
        "RefreshPicker.tsx",
        "Sparkline/Sparkline.tsx",
        "StatusHistoryPanel.tsx",
        "StateTimelinePanel.tsx",
        "TimeSeriesPanel.tsx",
        "TrendPanel.tsx",
    ]:
        assert any(marker in name for name in names), marker


def test_sandbox_archive_contains_panels_reference_candidates() -> None:
    sandbox_path = ROOT.parent / "Песочница.xz"
    if not sandbox_path.exists():
        return
    with tarfile.open(sandbox_path) as archive:
        names = archive.getnames()
    for marker in [
        "MaterialM-Tailwind-Nextjs-Free-main",
        "TelegramUI-main",
        "Mark42-master",
    ]:
        assert any(marker in name for name in names), marker
