from __future__ import annotations

import json
from pathlib import Path

import pytest
from tests.screenshot_companion_testkit import (
    assert_screenshot_evidence,
)

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(
        encoding="utf-8",
        errors="ignore",
    )


def load(rel: str) -> dict:
    return json.loads(read(rel))


def test_current_head_and_cycle_documents_are_linked() -> None:
    for rel in [
        "KERNEL.md",
        "map_element.md",
        "docs/cycles/WORK_CYCLES.md",
        "docs/NORM/RELEASE_PROOF_STATUS.md",
    ]:
        text = read(rel)
        assert "v171_31" in text or "v171.31" in text
        assert "1556" in text
    report = (
        "reports/change_cycle_2026-07-16_v171_31_"
        "cycle_1556_panels_exchange_release_readiness.md"
    )
    assert (ROOT / report).is_file()


def test_panels_page_uses_query_layer_not_transport() -> None:
    page = read("frontend/src/pages/panels.tsx")
    assert "usePanelsList" in page
    assert "usePanelsSummary" in page
    assert "usePanelActivation" in page
    assert "apiRequest" not in page
    assert "window.fetch(" not in page
    assert "globalThis.fetch(" not in page


def test_exchange_page_uses_query_layer_not_parallel_service_state() -> None:
    page = read("frontend/src/pages/exchange.tsx")
    assert "useExchangePreview" in page
    assert "useExchangeConvert" in page
    assert "apiRequest" not in page
    assert "window.fetch(" not in page
    assert "globalThis.fetch(" not in page
    assert (
        "data-exchange-runtime-proof=\"1556-react-query-transaction\""
        in page
    )


def test_services_validate_generated_economic_dtos() -> None:
    panels = read("frontend/src/services/panels.service.ts")
    exchange = read("frontend/src/services/exchange.service.ts")
    validators = read(
        "frontend/src/lib/api/generated/"
        "economicUserSeamValidators.ts"
    )
    assert "parsePanelsPageResponse" in panels
    assert "parsePanelsSummaryResponse" in panels
    assert "parsePanelActivationResponse" in panels
    assert "parseExchangePreviewResponse" in exchange
    assert "parseExchangeConvertResponse" in exchange
    assert "PanelsSummaryResponseSchema" in validators


@pytest.mark.visual_evidence
def test_panels_and_exchange_browser_evidence_passed() -> None:
    checks = {
        "reports/generated/"
        "panels_activation_interaction_proof_v171_31.json": (
            "activate one panel for 100 EFHC"
        ),
        "reports/generated/"
        "exchange_convert_interaction_proof_v171_31.json": (
            "convert 10 kWh to 10 EFHC"
        ),
    }
    for rel, action in checks.items():
        proof = load(rel)
        assert proof["status"] == "PASSED"
        assert proof["action"] == action
        assert proof["metrics"]["bodyNotBlank"] is True
        assert proof["metrics"]["splashVisible"] is False
        assert proof["metrics"]["horizontalOverflow"] is False
        assert proof["metrics"]["width"] == 390
        assert_screenshot_evidence(proof["screenshot"])


def test_linkage_matrix_is_complete_and_truthful() -> None:
    matrix = load(
        "reports/generated/panels_exchange_linkage_v171_31.json"
    )
    assert matrix["cycle"] == 1556
    assert len(matrix["flows"]) == 2
    for flow in matrix["flows"]:
        assert flow["service"]
        assert flow["dto_validator"]
        assert flow["backend_route"]
        assert flow["business_service"]
        assert flow["db_tables"]
        assert flow["idempotency"]
        assert flow["success_state"]
        assert flow["failure_state"]
        assert flow["local_postgres_transaction_proof"] == (
            "NOT_AVAILABLE_NO_POSTGRES_RUNTIME"
        )
        assert flow["ci_postgres_gate"] == "REQUIRED"


def test_release_master_plan_is_100_point_fail_closed_route() -> None:
    plan = load(
        "reports/generated/"
        "mvp_release_readiness_master_plan_v171_31.json"
    )
    items = [
        item
        for domain in plan["domains"]
        for item in domain["items"]
    ]
    assert len(plan["domains"]) == 12
    assert sum(item["points"] for item in items) == 100
    assert plan["target"]["readiness_points_required"] == 99
    assert plan["target"]["all_critical_items_verified"] is True
    assert plan["release_decision"]["status"] == (
        "NOT_RELEASE_READY"
    )
    assert any(item["status"] != "VERIFIED" for item in items)


def test_release_overclaims_remain_forbidden() -> None:
    status = read("docs/NORM/RELEASE_PROOF_STATUS.md")
    assert "GitHub CI" in status
    assert "not established" in status.lower()
    assert "Live Telegram" in status
    assert "Real TonConnect" in status
    assert "Release-ready" in status
    assert "production-ready" in status
