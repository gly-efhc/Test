from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_admin_overview_dashboard_docs_exist() -> None:
    required = [
        "docs/NORM/ADMIN_OVERVIEW_DASHBOARD_UPGRADE.md",
        "docs/NORM/ADMIN_OVERVIEW_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md",
        "docs/cycles/WORK_CYCLES_1481_ADMIN_OVERVIEW_DASHBOARD_UPGRADE.md",
        "reports/generated/admin_overview_dashboard_upgrade_v170_57.json",
        "reports/change_cycle_2026-06-07_v170_57_cycle_1481_admin_overview_dashboard_upgrade.md",
        "frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx",
        "tests/architecture/test_admin_overview_dashboard_upgrade.py",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_generated_report_records_boundaries() -> None:
    data = json.loads(
        read("reports/generated/admin_overview_dashboard_upgrade_v170_57.json")
    )
    assert data["cycle"] == 1481
    assert data["archive_version"] == "v170.57"
    assert data["truth_model"] == "raw_plus_derived_snapshot"
    assert data["runtime_admin_route_changed"] is True
    assert data["source_endpoint"] == "/admin/reports/overview"
    assert data["synthetic_admin_analytics_added"] is False
    assert data["raw_payload_visible"] is False
    assert data["debug_json_visible"] is False
    assert data["secrets_visible"] is False
    assert data["dashboard_write_actions_added"] is False
    assert data["economy_changed"] is False
    assert data["backend_changed"] is False
    assert data["openapi_changed"] is False
    assert data["dependencies_changed"] is False
    assert data["lock_files_changed"] is False
    assert data["write_flow_changed"] is False
    assert data["money_flow_changed"] is False
    assert data["grafana_runtime_code_copied"] is False
    assert data["sandbox_runtime_code_copied"] is False


def test_admin_overview_component_has_required_markers() -> None:
    src = read("frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx")
    required = [
        "adminOverviewDashboardRuntimeVersion",
        "EFHC_ADMIN_OVERVIEW_DASHBOARD_RUNTIME_V1",
        "data-admin-overview-dashboard=\"1481\"",
        "data-admin-overview-dashboard-truth=\"raw-derived\"",
        "data-admin-overview-no-write-actions=\"true\"",
        "data-admin-overview-no-raw-payload=\"true\"",
        "data-admin-overview-no-debug-json=\"true\"",
        "AdminDashboardToolbar",
        "AdminPanelChrome",
        "AdminStatusCard",
        "AdminTrendCard",
        "AdminAreaChart",
        "AdminHeatStrip",
        "AdminProgressBar",
    ]
    for marker in required:
        assert marker in src


def test_admin_overview_component_is_read_only() -> None:
    src = read("frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx")
    forbidden = [
        "apiRequest(",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "newIdempotencyKey",
        "fetch(",
        "mutateAsync",
        "raw payload dump",
        "debug JSON dump",
        "synthetic_preview",
    ]
    for marker in forbidden:
        assert marker not in src


def test_admin_page_integrates_release_summary_safely() -> None:
    page = read("frontend/src/pages/admin/index.tsx")
    required = [
        "AdminHeroPanel",
        "AdminStatCard",
        "AdminCharts",
        "AdminTable",
        "AdminAppButtonGrid",
        "CORE_MODULES",
        "OPERATION_MODULES",
        "Релизный центр управления",
    ]
    for marker in required:
        assert marker in page
    assert "AdminOverviewDashboardRuntime" not in page
    assert "AdminObservabilityTimeseriesDashboardRuntime" not in page
    assert "AdminInteractiveBankDashboard" not in page
    assert "ADMIN_REPORTS_OVERVIEW_PATH" in page
    assert "ADMIN_TON_RECONCILE_PATH" in page


def test_admin_overview_css_exists() -> None:
    css = read("frontend/src/styles/globals.css")
    required = [
        "Cycle 1481 — Admin Overview Dashboard Upgrade",
        ".efhc-admin-overview-dashboard",
        ".efhc-admin-overview-dashboard__main",
        ".efhc-admin-overview-dashboard__facts",
        ".efhc-admin-overview-dashboard__domain-grid",
        ".efhc-admin-overview-dashboard__quick-links",
        ".efhc-admin-overview-dashboard__boundary",
        "overflow-wrap: anywhere",
    ]
    for marker in required:
        assert marker in css


def test_navigation_docs_are_updated_for_next_cycle() -> None:
    corpus = "\n".join(
        [
            read("KERNEL.md"),
            read("map_element.md"),
            read("ops/operator_kernel/config/routes.yaml"),
            read("docs/cycles/WORK_CYCLES.md"),
            read("reports/REPORTS_INDEX.md"),
        ]
    )
    assert "1481 — Admin Overview Dashboard Upgrade" in corpus
    assert "ADMIN_OVERVIEW_DASHBOARD_UPGRADE" in corpus
    assert "1482 — Admin Reports Grafana-like Upgrade" in corpus


def test_grafana_and_sandbox_boundaries_are_preserved() -> None:
    docs = (
        read("docs/NORM/ADMIN_OVERVIEW_DASHBOARD_UPGRADE.md")
        + read("docs/NORM/ADMIN_OVERVIEW_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md")
        + read("docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md")
        + read("docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md")
    )
    assert "Grafana is used only as visual-pattern/reference layer" in docs
    assert "Runtime code is not copied" in docs
    assert "Песочница is used only as reference/navigation/prototype layer" in docs
    assert "No Grafana source code" in docs


def test_operator_kernel_route_exists_for_cycle() -> None:
    routes = read("ops/operator_kernel/config/routes.yaml")
    assert "admin_overview_dashboard_upgrade:" in routes
    assert "AdminOverviewDashboardRuntime.tsx" in routes
    assert "test_admin_overview_dashboard_upgrade.py" in routes


def test_admin_overview_does_not_modify_backend_or_locks() -> None:
    report = read("reports/change_cycle_2026-06-07_v170_57_cycle_1481_admin_overview_dashboard_upgrade.md")
    required = [
        "backend routes",
        "migrations",
        "OpenAPI",
        "dependencies",
        "lock files",
        "money and write flows were not changed",
    ]
    for marker in required:
        assert marker in report
