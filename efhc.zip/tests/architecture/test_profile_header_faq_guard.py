from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_header_balance_is_single_run_without_copy_side_effect() -> None:
    source = read("frontend/src/components/GlobalHeader.tsx")
    assert 'className="efhc-game-header_balance-value"' in source
    assert 'data-header-balance-value={total}' in source
    assert 'title={total}' in source
    assert "{total}" in source
    assert "total.split" not in source
    assert "navigator.clipboard" not in source
    assert 'from "./Layout"' not in source
    assert "useContext" not in source


def test_global_status_labels_are_canonical_english_in_all_locales() -> None:
    locale_dir = ROOT / "frontend/public/locale"
    locales = sorted(locale_dir.glob("*.json"))
    assert len(locales) == 13
    for locale in locales:
        data = json.loads(locale.read_text(encoding="utf-8"))
        assert data["profile.activ_badge"] == "Activ", locale.name
        assert data["profile.active_badge"] == "Activ", locale.name
        assert data["profile.vip_badge"] == "VIP", locale.name


def test_profile_settings_gear_stays_inside_profile_contract() -> None:
    profile = read("frontend/src/features/profile/WebProfilePage.tsx")
    css = read("frontend/src/styles/globals.css")
    assert 'activeTab === "profile"' in profile
    assert 'className="efhc-profile-settings-button"' in profile
    assert 'data-profile-settings-entry="profile-modal"' in profile
    assert 'aria-label={t("profile.settings_title")}' in profile
    assert "setSettingsOpen(true)" in profile
    assert 'data-profile-hero-layout="compact-1573"' not in profile
    assert ".efhc-profile-settings-button{" in css
    assert ".efhc-profile-card-heading{" in css


def test_french_faq_23_changed_and_27_unchanged_in_all_mirrors() -> None:
    old = "Quels boutons de l’écran principal sont les plus importants ?"
    new = "Que dois-je regarder en premier ?"
    mirrors = [
        "docs/SSOT/faq_ssot/fr/faq_fr.md",
        "docs/SSOT/faq_ssot/fr/faq_fr.json",
        "frontend/public/faq/fr.json",
        "frontend/src/data/faq/catalogs.ts",
    ]
    for mirror in mirrors:
        text = read(mirror)
        assert text.count(new) == 1, mirror
        assert text.count(old) == 1, mirror
        assert text.index(new) < text.index(old), mirror
