from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_cold_start_mvp_canon_exists_and_protects_first_screen():
    text = read("docs/NORM/COLD_START_MVP_UX_CANON.md")

    assert "Cold start latency is not a blocker" in text
    assert "Do not block the first screen waiting for the database" in text
    assert "Do not run Alembic migrations on a user request" in text
    assert "stale-while-revalidate" in text
    assert "Cloud Run `min instances = 0`" in text
    assert "Neon Free / scale-to-zero" in text


def test_energy_first_paint_uses_optimized_webp_asset():
    css = read("frontend/src/styles/globals.css")
    assert "url('/skins/1.webp')" in css
    assert "url('/skins/1.png')" not in css

    webp = ROOT / "frontend/public/skins/1.webp"
    png = ROOT / "frontend/public/skins/1.png"
    assert webp.exists()
    assert not png.exists()
    assert webp.stat().st_size <= 220_000


def test_cold_start_route_and_asset_docs_are_indexed():
    routes = read("ops/operator_kernel/config/routes.yaml")
    manifest = read("docs/testing/TEST_GUARD_MANIFEST.md")
    qna = read("docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md")

    assert "cold_start_mvp_ux_assets" in routes
    assert "docs/NORM/COLD_START_MVP_UX_CANON.md" in routes
    assert "frontend/public/skins/1.webp" in routes
    assert "Cycle 1435 cold start MVP UX asset guard" in manifest
    assert "Cloud Run / Neon cold start" in qna
