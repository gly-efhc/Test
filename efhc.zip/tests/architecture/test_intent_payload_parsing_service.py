from __future__ import annotations

from app.services.intent_payload_parsing_service import (
    parse_intent_payload,
)


def test_parse_intent_payload_exact() -> None:
    got = parse_intent_payload("EFHC:deposit_efhc:7:9001")
    assert got is not None
    assert got["purpose"] == "deposit_efhc"
    assert got["intent_id"] == 7
    assert got["tg_id"] == 9001


def test_parse_intent_payload_substring() -> None:
    got = parse_intent_payload(
        "JETTON_TRANSFER|FORWARD_PAYLOAD=EFHC:shop_external:13:7001"
    )
    assert got is not None
    assert got["purpose"] == "shop_external"
    assert got["payload"] == "EFHC:shop_external:13:7001"


def test_parse_intent_payload_для_global_owner() -> None:
    got = parse_intent_payload("EFHC:deposit_efhc:8:G0000001234")
    assert got is not None
    assert got["intent_id"] == 8
    assert got["global_id"] == 1234
    assert got["tg_id"] is None
