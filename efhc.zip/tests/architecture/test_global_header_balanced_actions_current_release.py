from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_header_uses_balanced_action_grid() -> None:
    header = read("frontend/src/components/GlobalHeader.tsx")
    css = read("frontend/src/styles/globals.css")
    assert 'data-header-action-layout="balanced-grid"' in header
    assert 'data-action-count={props.isAdmin ? "5" : "4"}' in header
    assert header.count('className="efhc-header-action') == 5
    assert "grid-template-areas:" in css
    assert '"profile balance"' in css
    assert '"actions actions"' in css
    assert "grid-template-columns:repeat(4,minmax(0,1fr));" in css
    assert "grid-template-columns:repeat(5,minmax(0,1fr));" in css


def test_vip_is_text_only_and_remains_permanent() -> None:
    header = read("frontend/src/components/GlobalHeader.tsx")
    assert 'kind="vip"' in header
    assert 'label={t("profile.vip_badge")}' in header
    assert 'active={props.isVip}' in header
    assert 'data-status={props.kind}' in header
    assert "efhc-vip-crown" not in header
    assert "👑" not in header
    assert "isVip ? (" not in header
