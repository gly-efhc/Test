from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_panels_frontend_uses_self_routes_and_compact_shell() -> None:
    src = read("frontend/src/pages/panels.tsx")
    css = read("frontend/src/styles/globals.css")

    assert '"/panels/active"' in src
    assert '"/panels/archive"' in src
    assert "`/panels/${tg_id}/active`" not in src
    assert "`/panels/${tg_id}/archive`" not in src

    assert "efhc-panels-shell" in src
    assert "efhc-panels-hero" in src
    assert "efhc-panel-tile" in src
    assert "efhc-segmented" in src

    for token in [
        ".efhc-panels-hero",
        ".efhc-panels-stats",
        ".efhc-panel-tile",
        ".efhc-segmented",
    ]:
        assert token in css


def test_panels_backend_self_routes_exist_and_legacy_is_hidden() -> (
    None
):
    src = read("backend/app/routes/panels_routes.py")

    assert '"/active"' in src
    assert '"/archive"' in src
    assert "list_my_active_panels" in src
    assert "list_my_archived_panels" in src
    assert "get_nonfinancial_read_owner" in src
    assert '"/{tg_id}/active"' in src
    assert '"/{tg_id}/archive"' in src
    assert "include_in_schema=False" in src


def test_exchange_compact_visual_repair_keeps_roads() -> None:
    src = read("frontend/src/pages/exchange.tsx")
    service_ts = read("frontend/src/services/exchange.service.ts")
    css = read("frontend/src/styles/globals.css")

    assert "efhc-exchange-shell" in src
    assert "data-exchange-route-contract" in src
    assert "ExchangePanel" in src
    assert "doPartialExchange" in src
    assert "EXCHANGE_CONVERT_PATH" in service_ts
    assert "WITHDRAW_REQUEST_PATH" not in src

    for token in [
        ".efhc-exchange-shell",
        ".efhc-exchange-panel",
        ".efhc-exchange-preview-row",
        ".efhc-exchange-history-link",
    ]:
        assert token in css


def test_cycle_1215_1216_docs_and_generated_evidence() -> None:
    audit = read("docs/audits/PANELS_EXCHANGE_COMPACT_REPAIR.md")
    data = json.loads(
        read("reports/generated/panels_exchange_compact.json")
    )

    assert "Panels compact visual repair" in audit
    assert "Exchange compact visual repair" in audit
    assert data["cycle"] == "1215-1216"
    assert data["panels"]["self_routes"] is True
    assert data["panels"]["legacy_routes_hidden"] is True
    assert data["exchange"]["compact_details"] is True
    assert data["canonical_bottom_menu_unchanged"] is True
