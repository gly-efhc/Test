from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def _function_body(source: str, name: str) -> str:
    marker = f"async def {name}("
    start = source.index(marker)
    tail = source[start + len(marker) :]
    next_async = tail.find("\n\nasync def ")
    next_sync = tail.find("\n\ndef ")
    candidates = [x for x in (next_async, next_sync) if x != -1]
    if not candidates:
        return source[start:]
    next_def = min(candidates)
    return source[start : start + len(marker) + next_def]


def test_проверка_spend_all_bonus_idempotency_retry_no_double_debit() -> None:
    tx = _read("backend/app/services/transactions_service.py")
    body = _function_body(tx, "spend_user_to_bank_bonus_then_main")
    nocommit = _function_body(
        tx,
        "spend_user_to_bank_bonus_then__main__nocommit",
    )
    finder = _function_body(
        tx,
        "_find_existing_bonus_then__main__spend_log",
    )

    assert 'bonus_key = f"{idempotency_key}:bonus"' in body
    assert 'main_key = f"{idempotency_key}:main"' in body
    assert "spend_user_to_bank_bonus_then__main__nocommit" in body
    assert "_find_existing_bonus_then__main__spend_log" in body
    assert "_read_through_bonus_then__main__spend" in body

    assert "await _find_log_by_idk(db, main_key)" in finder
    assert "await _find_log_by_idk(db, bonus_key)" in finder
    assert "return prev_main" in finder
    assert "return prev_bonus" in finder

    assert (
        "prev_spend = await _find_existing_bonus_then__main__spend_log"
        in nocommit
    )
    assert (
        "return await _read_through_bonus_then__main__spend"
        in nocommit
    )

    conflict = body.split("except Exception as exc:", 1)[1]
    assert "if _is_idempotency_conflict(exc):" in conflict
    assert (
        "prev = await _find_existing_bonus_then__main__spend_log"
        in conflict
    )
    assert (
        "return await _read_through_bonus_then__main__spend"
        in conflict
    )


def test_проверка_admin_manual_debit_no_typeerror() -> None:
    rel = "backend/app/services/admin/admin_bank_service.py"
    source = _read(rel)
    tree = ast.parse(source, filename=rel)
    forbidden = {"spend_bonus_first", "forbid_user_negative"}
    offenders: list[str] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        is_debit_call = (
            isinstance(func, ast.Name)
            and func.id
            in {"debit_user_to_bank", "debit_user_bonus_to_bank"}
        )
        if not is_debit_call:
            continue
        for kw in node.keywords:
            if kw.arg in forbidden:
                offenders.append(f"{kw.arg}@{node.lineno}")

    assert offenders == []


def test_проверка_panel_activation_debit_and_panel_create_are_atomic() -> None:
    panels = _read("backend/app/services/panels_service.py")
    body = _function_body(panels, "activate_panel")

    assert "async with bank._tx_context(db):" in body
    assert "spend_user_to_bank_bonus_then__main__nocommit" in body
    assert "_create_panel_records_bulk" in body
    assert "_merge_activation_payload" in body

    tx_pos = body.index("async with bank._tx_context(db):")
    spend_pos = body.index(
        "spend_user_to_bank_bonus_then__main__nocommit"
    )
    create_pos = body.index("_create_panel_records_bulk")
    merge_pos = body.index("_merge_activation_payload", create_pos)
    assert tx_pos < spend_pos < create_pos < merge_pos

    assert "spend_user_to_bank_bonus_then_main(" not in body
    assert "await db.commit()" not in body
    assert "await db.rollback()" not in body


def test_проверка_activation_payload_reads_bonus_and__main__logs() -> None:
    panels = _read("backend/app/services/panels_service.py")
    body = _function_body(panels, "_get_activation_payload_by_idk")

    assert 'main_key = f"{idempotency_key}:main"' in body
    assert 'bonus_key = f"{idempotency_key}:bonus"' in body
    assert "for key in (main_key, bonus_key):" in body
    assert "merged.update(_json_to_dict(row[0]))" in body


def test_проверка_panels_service_no_local_tx_context() -> None:
    panels = _read("backend/app/services/panels_service.py")

    assert "async with bank._tx_context(db):" in panels
    assert "def _tx_context(" not in panels
    assert "async def _tx_context(" not in panels
    assert "db.begin_nested()" not in panels
    assert "begin_nested" not in panels



def test_проверка_withdraw_cancel_and_reject_refund_are_atomic() -> None:
    source = _read("backend/app/services/withdraw_service.py")
    cancel_body = _function_body(source, "cancel_withdraw")
    reject_body = _function_body(source, "admin_reject_withdraw")
    tx_source = _read("backend/app/services/transactions_service.py")

    assert "async def credit_user_from_bank_nocommit" in tx_source
    assert "await _insert_log(" in _function_body(
        tx_source,
        "credit_user_from_bank_nocommit",
    )
    assert "await db.commit()" not in _function_body(
        tx_source,
        "credit_user_from_bank_nocommit",
    )

    for body, status in (
        (cancel_body, "WITHDRAW_REQ_CANCELED"),
        (reject_body, "WITHDRAW_REQ_REJECTED"),
    ):
        assert "async with _tx_context(db):" in body
        assert "FOR UPDATE" in body
        assert "credit_user_from_bank_nocommit" in body
        assert "refund_done = TRUE" in body
        assert status in body
        assert "await db.commit()" not in body
        assert "await db.rollback()" not in body
        assert "credit_user_from_bank(" not in body


def test_проверка_exchange_idempotency_check_inside_lock_retry_loop() -> None:
    tx = _read("backend/app/services/transactions_service.py")

    for name, ctx in (
        (
            "exchange_partial_available_kwh_to_main",
            "exchange_partial_preflight",
        ),
        (
            "exchange__all__available_kwh_to_main",
            "exchange_all_preflight",
        ),
    ):
        body = _function_body(tx, name)
        assert "_rollback_started_exchange_transaction" in body
        assert ctx in body
        assert "FOR UPDATE" in body
        assert "existing = await _find_log_by_idk" in body
        assert "return await _read_through_existing_tx" in body

        rollback_pos = body.index(
            "_rollback_started_exchange_transaction"
        )
        loop_pos = body.index("for _attempt in range")
        lock_pos = body.index("FOR UPDATE")
        existing_pos = body.index("existing = await _find_log_by_idk")
        assert rollback_pos < loop_pos < lock_pos < existing_pos

        before_loop = body[:loop_pos]
        assert "existing = await _find_log_by_idk" not in before_loop


def test_проверка_exchange_all_zero_available_log_direction_correct() -> None:
    tx = _read("backend/app/services/transactions_service.py")
    body = _function_body(tx, "exchange__all__available_kwh_to_main")
    branch = body.split('if available <= Decimal("0"):', 1)[1]
    branch = branch.split("new_user_main =", 1)[0]

    assert "exchange_rejected_no_kwh" in branch
    assert "created_log_id=None" in branch
    assert "meta=audit" in branch
    assert "await db.rollback()" in branch
    assert "await _insert_log(" not in branch
    assert 'direction="debit"' not in branch
    assert 'direction="credit"' not in branch


def test_проверка_exchange_partial_called_with_open_transaction_safe() -> None:
    tx = _read("backend/app/services/transactions_service.py")
    helper = _function_body(
        tx,
        "_rollback_started_exchange_transaction",
    )

    assert "db.in_transaction()" in helper
    assert "await _safe_rollback(db, ctx)" in helper

    for name, ctx in (
        (
            "exchange_partial_available_kwh_to_main",
            "exchange_partial_preflight",
        ),
        (
            "exchange__all__available_kwh_to_main",
            "exchange_all_preflight",
        ),
    ):
        body = _function_body(tx, name)
        assert "await _rollback_started_exchange_transaction" in body
        assert ctx in body
        assert "await db.commit()" in body


def test_проверка_withdraw_service_no_local_tx_context_copy() -> None:
    withdraw = _read("backend/app/services/withdraw_service.py")

    assert "from app.services.transactions_service import (" in withdraw
    assert "    _tx_context," in withdraw
    assert "@contextlib.asynccontextmanager" not in withdraw
    assert "async def _tx_context(" not in withdraw


def test_проверка_exchange_kwh_strict_uses_ssot_calculation_not_column() -> None:
    tx = _read("backend/app/services/transactions_service.py")
    body = _function_body(tx, "exchange_kwh_to_efhc")
    strict = body.split("if strict_kwh_check:", 1)[1]
    strict = strict.split("new_user_main =", 1)[0]

    assert "total_generated_kwh" in strict
    assert "exchanged_kwh_total" in strict
    assert "_available_from_total_exchanged" in strict
    assert "available_kwh" not in strict


def test_проверка_credit_bonus_meta_written_to_log() -> None:
    tx = _read("backend/app/services/transactions_service.py")
    body = _function_body(tx, "credit_user_bonus_from_bank")

    assert "meta=meta" in body
    assert "return await _run_idempotent" in body
    assert (
        "logger.debug(\"credit_user_bonus_from_bank meta=%s\""
        not in body
    )


def test_проверка_reconciliation_sum_invariant_after_all_ops() -> None:
    tx = _read("backend/app/services/transactions_service.py")
    docs = _read("docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md")
    assert (
        "SUM(user.main_balance + user.bonus_balance) + "
        "bank.balance"
        in docs
    )
    assert "INV-08" in docs
    assert "reconciliation" in docs.lower()
    assert "_update_user_balances" in tx
    assert "_update_bank_balances" in tx


def test_проверка_payment_intents_service_has_no_dynamic_sequence_sql() -> None:
    source = _read("backend/app/services/payment_intents_service.py")
    assert "nextval('" not in source
    assert "pg_get_serial_sequence(:pi_table, 'id')" in source


def test_проверка_user_balances_are_written_only_by_transactions_service() -> None:
    backend = ROOT / "backend/app"
    allowed = {
        ROOT / "backend/app/services/transactions_service.py",
    }
    sql_pattern = re.compile(
        r"(?:main_balance|bonus_balance)\s*=\s*:(?:[a-z_]+)",
        re.IGNORECASE,
    )
    orm_pattern = re.compile(
        r"\.(?:main_balance|bonus_balance)\s*=\s*"
    )
    offenders: list[str] = []
    for path in sorted(backend.rglob("*.py")):
        if path in allowed:
            continue
        for line_no, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            1,
        ):
            if sql_pattern.search(line) or orm_pattern.search(line):
                offenders.append(
                    f"{path.relative_to(ROOT)}:{line_no}: {line.strip()}"
                )
    assert not offenders, (
        "direct balance writes outside transactions_service: "
        + "; ".join(offenders)
    )


def test_проверка_available_kwh_writes_stay_inside_canonical_layer() -> None:
    backend = ROOT / "backend/app"
    allowed = {
        ROOT / "backend/app/services/transactions_service.py",
        ROOT / "backend/app/models/user_models.py",
    }
    sql_pattern = re.compile(
        r"available_kwh\s*=\s*:(?:[a-z_]+)",
        re.IGNORECASE,
    )
    orm_pattern = re.compile(r"\.available_kwh\s*=\s*")
    offenders: list[str] = []
    for path in sorted(backend.rglob("*.py")):
        if path in allowed:
            continue
        for line_no, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            1,
        ):
            if sql_pattern.search(line) or orm_pattern.search(line):
                offenders.append(
                    f"{path.relative_to(ROOT)}:{line_no}: {line.strip()}"
                )
    assert not offenders, (
        "available_kwh writes outside canonical layer: "
        + "; ".join(offenders)
    )


def test_проверка_referrals_never_resolve_business_owner_via_users_id() -> None:
    for rel in (
        "backend/app/services/referral_service.py",
        "backend/app/routes/admin_referral_routes.py",
    ):
        source = _read(rel)
        assert "SELECT id\n            FROM efhc_core.users" not in source
        assert "Вернуть users.id" not in source
        assert "users.id нужен" not in source


def test_проверка_withdraw_layers_keep_locking_and_status_constraint() -> None:
    model = _read("backend/app/models/withdraw_models.py")
    service = _read("backend/app/services/withdraw_service.py")
    admin = _read(
        "backend/app/services/admin/admin_withdrawals_service.py"
    )
    assert "ck_withdraw_requests_status_enum" in model
    assert "FOR UPDATE" in service
    assert "FOR UPDATE" in admin


def test_проверка_manual_vip_claim_is_not_compatibility_stub() -> None:
    source = _read("backend/app/services/nft_requests_service.py")
    assert '"mode": "compat_stub"' not in source
    assert '"status": "accepted"' not in source
    assert "INSERT INTO efhc_core.shop_orders" in source


def test_проверка_panel_activation_price_is_frozen_to_100() -> None:
    source = _read("backend/app/services/panels_service.py")
    assert 'PANEL_PRICE: Decimal = d8("100")' in source
    assert 'getattr(settings, "PANEL_PRICE"' not in source
