from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="ignore")


def test_v170_27_keeps_kernel_legacy_marker() -> None:
    kernel = read("KERNEL.md")
    mapping = read("map_element.md")
    nav = kernel + mapping
    assert "Operator Kernel" in kernel
    assert "v170.27 / CI log repair" in nav
    assert "python ops/operator_kernel/file_map.py --refresh" in nav


def test_v170_27_keeps_chat_index_legacy_anchors() -> None:
    index = read("docs/NORM/CHATS/CHATS_INDEX.md")
    assert "ветки 21, 22 и 24" in index
    assert "ветки 21, 22, 24 и 25" in index
    assert "ветки 21, 22, 24, 25, 26, 27, 28 и 30" in index


def test_v170_27_profile_history_reason_i18n_anchor() -> None:
    profile = read("frontend/src/features/profile/WebProfilePage.tsx")
    assert "balanceHistoryReasonLabel(reason, t)" in profile
    assert "history.reason.exchange_kwh" in profile
    assert "history.reason.panel_purchase" in profile


def test_v170_27_admin_withdraw_preview_type_is_generated() -> None:
    seam = read("frontend/src/lib/api/generated/adminSeams.ts")
    gen = read("ops/openapi/generate_frontend_seam_types.py")
    assert "export type AdminWithdrawOutcomePreviewResponse" in seam
    assert "AdminWithdrawOutcomeBundle" in seam
    assert "AdminWithdrawOutcomePreviewResponse" in gen


def test_v170_27_chat_26_canon_guard_terms_repaired() -> None:
    chat = read("docs/NORM/CHATS/26.md")
    forbidden = [
        "gam" + "bling/" + "lot" + "tery",
        "gam" + "bling;",
        "lot" + "tery;",
    ]
    for marker in forbidden:
        assert marker not in chat
