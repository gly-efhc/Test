from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
GEN = ROOT / "ops/scripts/generate_faq_catalogs_from_ssot.py"
MAN = ROOT / "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json"
CAT = ROOT / "frontend/src/data/faq/catalogs.ts"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def _load_module():
    spec = importlib.util.spec_from_file_location(
        "generate_faq_catalogs_from_ssot",
        GEN,
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_generator_references_approval_manifest() -> None:
    text = GEN.read_text(encoding="utf-8")
    assert "FAQ_APPROVAL_MANIFEST.json" in text
    assert "validate_generation_preconditions" in text
    assert "entries_total" in text
    assert "section 13 mismatch" in text


def test_manifest_exists_and_is_count_consistent() -> None:
    data = json.loads(MAN.read_text(encoding="utf-8"))
    assert data["entries_total"] == len(data["entries"])
    assert data["entries"]


def test_runtime_catalog_is_generated_with_header() -> None:
    text = CAT.read_text(encoding="utf-8")
    assert "GENERATED FILE. DO NOT EDIT MANUALLY." in text
    assert "FAQ_APPROVAL_MANIFEST.json" in text


def test_cycle_105_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert "| 105 | done | FAQ code generation hardening." in text
