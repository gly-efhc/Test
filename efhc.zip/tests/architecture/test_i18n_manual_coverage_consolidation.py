from __future__ import annotations

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_cycle_1383_docs_and_guard_exist() -> None:
    required = [
        ROOT / "ops/i18n/audit_i18n_manual_coverage_consolidation.py",
        ROOT / "docs/frontend/I18N_MANUAL_COVERAGE_CONSOLIDATION.md",
        ROOT
        / "docs/audits/I18N_MANUAL_COVERAGE_CONSOLIDATION_AUDIT_V169_63.md",
        ROOT
        / "reports/generated/i18n_manual_coverage_consolidation_v169_63.json",
    ]
    missing = [str(path) for path in required if not path.exists()]
    assert not missing, f"missing cycle 1383 artifacts: {missing}"


def test_consolidation_guard_passes() -> None:
    result = subprocess.run(
        [
            "python3",
            "ops/i18n/audit_i18n_manual_coverage_consolidation.py",
        ],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    assert result.returncode == 0, result.stdout
    assert "Unexpected English-identical values: 0" in result.stdout
    assert "Wave-3 Cyrillic tails: 0" in result.stdout
    assert (
        "Human linguistic certification: NOT CLAIMED" in result.stdout
    )


def test_hindi_residual_english_tail_fixed() -> None:
    hi = json.loads(
        (ROOT / "frontend/public/locale/hi.json").read_text(
            encoding="utf-8"
        )
    )
    assert hi["browser_login.badge"] != "Browser demo"
    assert hi["exchange.receive_label"] != "You receive"
    assert hi["browser_login.badge"] == "ब्राउज़र डेमो"
    assert hi["exchange.receive_label"] == "आपको मिलेगा"


def test_future_cycle_plan_remains_reserved() -> None:
    future_plan = (
        ROOT / "docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md"
    ).read_text(encoding="utf-8")
    assert "DRAFT" in future_plan or "RESERVED" in future_plan
    assert (
        "does not activate" in future_plan
        or "не актив" in future_plan.lower()
    )
