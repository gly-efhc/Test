from __future__ import annotations

from pathlib import Path

from app.identity.user_id_backfill import BACKFILL_APPLY_ENABLED
from app.models.user_models import User

ROOT = Path(__file__).resolve().parents[2]


def test_reverse_user_id_alias_is_compatibility_only() -> None:
    assert User.user_id.key == "user_id"
    assert User.__table__.c.global_id.name == "global_id"
    assert "user_id" not in User.__table__.c
    source = (
        ROOT / "backend/app/models/user_models.py"
    ).read_text(encoding="utf-8")
    assert 'user_id = synonym("global_id")' in source


def test_historical_backfill_is_disabled_after_schema_freeze() -> None:
    assert BACKFILL_APPLY_ENABLED is False
    apply_sql = (
        ROOT / "backend/app/identity/user_id_backfill.py"
    ).read_text(encoding="utf-8")
    assert "BACKFILL_APPLY_ENABLED" in apply_sql


def test_active_migration_layer_contains_only_release_0001() -> None:
    versions = sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert versions == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]
    migration = (
        ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    assert 'revision = "0001"' in migration
    assert "down_revision = None" in migration
    assert "users.user_id physical column forbidden" in migration
