from __future__ import annotations

from pathlib import Path

# LEGACY runtime compatibility tests. They protect pre-read-switch data
# semantics until the assigned expand/backfill/read-switch cycles.
# They do not define the target identity architecture.


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    path = _repo_root() / rel
    return path.read_text(encoding="utf-8", errors="replace")


def test_current_routes_use_canonical_owner_dependencies() -> None:
    nonfinancial = (
        "backend/app/routes/panels_routes.py",
        "backend/app/routes/user_routes.py",
        "backend/app/routes/tasks_routes.py",
        "backend/app/routes/sync_routes.py",
    )
    for rel in nonfinancial:
        src = _read(rel)
        assert "get_nonfinancial_read_owner" in src
        assert "owner.global_id" in src

    exchange = _read("backend/app/routes/exchange_routes.py")
    assert "get_financial_read_owner" in exchange
    assert "global_id=owner.global_id" in exchange
    assert "Depends(get_current_tg_id)" not in exchange

    sync = _read("backend/app/routes/sync_routes.py")
    assert '"/user/{tg_id}"' in sync
    assert '"/me"' in sync


def test_legacy_shop_join_remains_stable_before_read_switch() -> (
    None
):
    src = _read("backend/app/services/shop_service.py")
    assert "u.id = o.tg_id" not in src
    assert "u.tg_id = o.tg_id" in src
    assert '"tg_id": int(r[1])' in src
