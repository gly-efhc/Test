"""Архитектурный gate Chromium evidence цикла 1630."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_visual_workflow_script_проверяет_cross_provider_session() -> None:
    source = (
        ROOT / "ops/frontend/all_pages_route_backed_visual_audit.py"
    ).read_text(encoding="utf-8")
    assert "_cross_provider_session_proof" in source
    assert 'for provider in ("telegram", "ton_wallet")' in source
    assert '"cross_provider_session_proof"' in source
    assert '"raw_init_data_seen"' in source
    assert '"bearer_seen"' in source
    assert '"same_global_id": CROSS_PROVIDER_GLOBAL_ID' in source
    assert "failures or cross_provider_failures" in source


def test_visual_workflow_остаётся_неизменным() -> None:
    workflow = (
        ROOT / ".github/workflows/frontend-visual.yml"
    ).read_text(encoding="utf-8")
    assert "EXPECTED_SCREENSHOTS = 102" in workflow
    assert "page.goto(" in workflow
    assert "page.screenshot(" in workflow
    assert "page.set_content(" not in workflow
    assert "context.route(" not in workflow
    assert "playwright install --with-deps chromium" in workflow
