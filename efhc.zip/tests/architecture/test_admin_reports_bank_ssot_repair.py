from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADMIN_ROUTES = ROOT / "backend" / "app" / "routes" / "admin_routes.py"
FRONTEND_BANK = ROOT / "frontend" / "src" / "pages" / "admin" / "bank.tsx"
FRONTEND_REPORTS = ROOT / "frontend" / "src" / "pages" / "admin" / "reports.tsx"
REPORTS_PANEL = (
    ROOT
    / "frontend"
    / "src"
    / "components"
    / "admin"
    / "AdminReportsVisualDashboardPanel.tsx"
)
ADMIN_BANK_SERVICE = (
    ROOT / "backend" / "app" / "services" / "admin" / "admin_bank_service.py"
)
MIGRATIONS = ROOT / "backend" / "migrations" / "versions"
INITIAL_DATA = ROOT / "backend/app/release/initial_data.py"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _reports_overview_body() -> str:
    src = read(ADMIN_ROUTES)
    start = src.index("async def reports_overview")
    return src[start:]


def test_admin_reports_overview_uses_bank_balance_ssot() -> None:
    body = _reports_overview_body()
    assert "from efhc_core.bank_balance" in body
    assert "where key = 'EFHC_MAIN'" in body
    assert "coalesce(balance, 0)::numeric as bank_total" in body
    assert "efhc_admin.bank_balances" not in body
    assert "balance_key = 'main'" not in body
    assert "efhc_balance" not in body


def test_admin_reports_overview_response_shape_matches_frontend() -> None:
    reports_page = read(FRONTEND_REPORTS)
    reports_panel = read(REPORTS_PANEL)
    bank_page = read(FRONTEND_BANK)
    routes = read(ADMIN_ROUTES)

    assert 'ADMIN_REPORTS_OVERVIEW_PATH' in reports_page
    assert 'ADMIN_REPORTS_OVERVIEW_PATH' in bank_page
    assert "ReportsOverviewOut" in routes
    assert '"bank_total_efhc"' in routes
    assert "bank_total_efhc" in reports_panel
    assert "facts.bank_total_efhc" in reports_panel
    assert "facts" in bank_page
    assert '"bank_users_balance_diff_efhc"' in routes
    assert '"bank_users_balance_match"' in routes


def test_admin_bank_dashboard_uses_same_bank_total_as_bank_service() -> None:
    body = _reports_overview_body()
    service = read(ADMIN_BANK_SERVICE)
    bank_page = read(FRONTEND_BANK)

    assert "efhc_core.bank_balance" in body
    assert "EFHC_MAIN" in body
    assert "efhc_core.bank_balance" in service
    assert "BANK_INITIAL_TOTAL" in service
    assert "facts.bank_users_balance_diff_efhc" in bank_page
    assert "facts.bank_users_balance_match" in bank_page
    assert "ADMIN_BANK_BALANCE_PATH" in bank_page
    assert 'ADMIN_REPORTS_OVERVIEW_PATH' in bank_page


def test_openapi_admin_reports_overview_schema_matches_runtime() -> None:
    routes = read(ADMIN_ROUTES)
    assert '@router.get(\n    "/reports/overview",' in routes
    assert "response_model=ReportsOverviewOut" in routes
    assert "Depends(require_admin)" in routes
    assert "ReportsOverviewOut(" in routes
    assert "counters=counters" in routes
    assert "facts=facts" in routes


def test_bank_genesis_seed_is_idempotent_and_future_migrations_do_not_mint() -> None:
    seed = read(INITIAL_DATA)
    assert 'BANK_BALANCE = Decimal("5000000.00000000")' in seed
    assert '("EFHC_MAIN", BANK_BALANCE)' in seed
    assert "ON CONFLICT (key) DO NOTHING" in seed

    offenders: list[str] = []
    forbidden_markers = (
        "pg_insert(bb)",
        "insert(bb)",
        "values(key='EFHC_MAIN'",
        'values(key="EFHC_MAIN"',
        "balance=Decimal('5000000.00000000')",
        'balance=Decimal("5000000.00000000")',
    )
    for path in sorted(MIGRATIONS.glob("*.py")):
        text = read(path)
        if any(marker in text for marker in forbidden_markers):
            offenders.append(path.relative_to(ROOT).as_posix())

    assert not offenders, (
        "Migrations must not mint or rewrite the system bank. "
        "The idempotent production seed is the only genesis path; "
        "runtime mint/burn belongs to transaction services:\n"
        + "\n".join(offenders)
    )
