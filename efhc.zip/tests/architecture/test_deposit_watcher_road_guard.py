from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "ops/routes/check_deposit_watcher_road.py"


def _load():
    spec = importlib.util.spec_from_file_location(
        "deposit_watcher_road_1188",
        SCRIPT,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_deposit_watcher_truth_guard() -> None:
    module = _load()
    data = module.build()
    assert data["status"] == "ok"
    assert data["all_required_present"] is True
