from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_проверка_panels_countdown_math_uses_real_seconds() -> None:
    text = _read("frontend/src/pages/panels.tsx")
    assert "const SECONDS_PER_DAY = 86400" in text
    assert "const SECONDS_PER_HOUR = 3600" in text
    assert "const SECONDS_PER_MINUTE = 60" in text
    assert "s / SECONDS_PER_DAY" in text
    assert "afterDays / SECONDS_PER_HOUR" in text
    assert "afterHours / SECONDS_PER_MINUTE" in text
    assert "panels.countdown_expired" in text
    assert re.search(r"s\s*/\s*86(?!400)", text) is None
    assert re.search(r"s\s*%\s*86(?!400)", text) is None


def test_проверка_panel_countdown_arithmetic_correct() -> None:
    seconds_per_day = 86400
    seconds_per_hour = 3600
    seconds_per_minute = 60
    s = 180 * seconds_per_day
    days = s // seconds_per_day
    hours = (s % seconds_per_day) // seconds_per_hour
    mins = (s % seconds_per_hour) // seconds_per_minute
    secs = s % seconds_per_minute
    assert (days, hours, mins, secs) == (180, 0, 0, 0)
    assert (seconds_per_day // seconds_per_hour) == 24
    assert (seconds_per_hour // seconds_per_minute) == 60


def test_проверка_tasks_public_status_labels_do_not_return_raw_enum() -> None:
    text = _read("frontend/src/pages/tasks.tsx")
    labels = _read("frontend/src/lib/humanLabels.ts")
    assert "taskStatusLabel(status, t)" in text
    assert "return status;" not in text
    for token in [
        "not_started",
        "pending_check",
        "approved",
        "auto_paid",
        "rejected",
    ]:
        assert token in labels
    assert 'return t("tasks.status_unknown")' in labels


def test_проверка_balance_history_reason_humanization_has_safe_fallback() -> None:
    profile = _read("frontend/src/features/profile/WebProfilePage.tsx")
    withdraw = _read("frontend/src/pages/withdraw.tsx")
    labels = _read("frontend/src/lib/humanLabels.ts")
    assert "balanceHistoryReasonLabel(reason, t)" in profile
    assert "balanceHistoryReasonLabel(reason, t)" in withdraw
    assert "value.startsWith(\"task_bonus\")" in labels
    assert "return t(\"history.reason.unknown\")" in labels
    assert "return key ? t(key) : reason" not in profile


def test_проверка_withdraw_labels_and_return_target_are_human_readable() -> None:
    text = _read("frontend/src/pages/withdraw.tsx")
    assert "withdrawStatusLabel(status, t)" in text
    assert "withdrawOutcomeKindLabel(" in text
    assert "balanceTypeLabel(item.balance_type, t)" in text
    assert "historyReasonLabel(item.reason)" in text
    assert "router.push(`/web-profile?section=${section}`)" in text
    assert "Request #{latestOutcome.request_id}" not in text
    assert "{item.reason}" not in text
    assert "{item.balance_type}" not in text


def test_проверка_ranks_no_browser_player_fallback() -> None:
    text = _read("frontend/src/pages/ranks.tsx")
    assert "browser-player" not in text
    assert "ranks.browser_user_fallback" in text
    assert "username: null" in text


def test_проверка_admin_shop_russian_operator_labels_replace_raw_english() -> None:
    text = _read("frontend/src/pages/admin/shop.tsx")
    forbidden_visible = [
        "Bulk actions",
        "Bulk live",
        "Bulk hidden",
        "Bulk archive",
        "Select filtered",
        "Clear queues",
        ">\n                          bulk\n",
        ">\n                          delete queue\n",
        ">\n                    Archive\n",
        ">\n                    Delete\n",
        "Выбранная карточка facts",
    ]
    for token in forbidden_visible:
        assert token not in text
    assert "adminShopStatusLabel(currentStatus)" in text
    assert "Массовые действия" in text
    assert "Очередь удаления" in text


def test_проверка_admin_withdrawals_statuses_are_operator_readable() -> None:
    page = _read("frontend/src/pages/admin/withdrawals.tsx")
    mobile = _read(
        "frontend/src/components/admin/"
        "AdminWithdrawalsMobileDecisionPanel.tsx",
    )
    assert "adminWithdrawStatusLabel(w.status)" in page
    assert "adminWithdrawStatusLabel(selected.status)" in page
    assert "adminWithdrawOutcomeLabel(" in page
    assert "selectedSummary" in page
    assert "request #" not in page
    assert "user ${" not in page
    assert "status ${" not in page
    assert "adminWithdrawStatusLabel(item.status)" in mobile
    assert "label=\"PENDING\"" not in mobile
    assert "label=\"PAID\"" not in mobile


def test_проверка_admin_withdraw_tabs_have_russian_labels() -> None:
    mobile = _read(
        "frontend/src/components/admin/"
        "AdminWithdrawalsMobileDecisionPanel.tsx",
    )
    for token in [
        "`PENDING ${pending}`",
        "`PAID ${paid}`",
        "`REJECTED ${rejected}`",
        "`CANCELED ${canceled}`",
        "`ERROR ${error}`",
        "label=\"PENDING\"",
        "label=\"PAID\"",
        "label=\"REJECTED / CANCELED\"",
    ]:
        assert token not in mobile
    for token in [
        "Ожидает ${pending}",
        "Выплачено ${paid}",
        "Отклонено ${rejected}",
        "Отменено ${canceled}",
        "Ошибка ${error}",
        "label=\"Ожидает\"",
        "label=\"Выплачено\"",
    ]:
        assert token in mobile


def test_проверка_withdraw_history_balance_type_human_readable() -> None:
    text = _read("frontend/src/pages/withdraw.tsx")
    assert "balanceTypeLabel(item.balance_type, t)" in text
    assert "{item.balance_type}" not in text
    labels = _read("frontend/src/lib/humanLabels.ts")
    assert "withdraw.balance_main" in labels
    assert "withdraw.balance_bonus" in labels


def test_проверка_admin_tasks_badges_no_english_internal_labels() -> None:
    text = _read("frontend/src/pages/admin/tasks.tsx")
    forbidden = [
        'label: "helper"',
        'label: "moderation surface"',
        'label={task.is_active ? "active" : "inactive"}',
        "helper-only",
    ]
    for token in forbidden:
        assert token not in text
    assert 'label: "Задания"' in text
    assert 'label: "Модерация"' in text
    assert 'label={task.is_active ? "Активно" : "Неактивно"}' in text


def test_проверка_locale_files_no_nested_ghost_objects() -> None:
    locale_dir = ROOT / "frontend/public/locale"
    counts: set[int] = set()
    for path in sorted(locale_dir.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        nested = [
            key for key, value in data.items()
            if isinstance(value, dict)
        ]
        assert nested == [], f"{path.name}: {nested}"
        counts.add(len(data))
    assert len(counts) == 1


def test_проверка_hub_has_no_trust_rail_or_secondary_copy() -> None:
    text = _read("frontend/src/features/hub/HubPage.tsx")
    assert "efhc-hub-trust-rail" not in text
    assert 'data-hub-visible-action-count="2"' in text
    assert 'data-hub-commerce-copy="forbidden-before-exit"' in text
    assert "portal.browser_shop.handoff_title" not in text
    assert "action_vip_nft" in text


def test_проверка_energy_route_docs_match_actual_route() -> None:
    matrix = _read("docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md")
    assert "- /energy" not in matrix
    assert "`/` является единственным active Energy route" in matrix
    assert (ROOT / "frontend/src/pages/index.tsx").exists()
    assert not (ROOT / "frontend/src/pages/energy.tsx").exists()


def test_проверка_all_locales_have_new_visual_repair_keys() -> None:
    keys = {
        "panels.countdown_expired",
        "tasks.status_not_started",
        "tasks.status_pending_check",
        "tasks.status_approved",
        "tasks.status_auto_paid",
        "tasks.status_rejected",
        "history.reason.deposit",
        "history.reason.payment",
        "withdraw.status_approved",
        "withdraw.status_failed",
        "withdraw.status_unknown",
        "withdraw.outcome_success",
        "withdraw.outcome_rejected",
        "withdraw.outcome_failed",
        "withdraw.outcome_pending",
        "withdraw.outcome_canceled",
        "withdraw.outcome_unknown",
        "withdraw.balance_main",
        "withdraw.balance_bonus",
        "withdraw.balance_unknown",
        "ranks.browser_user_fallback",
    }
    locale_dir = ROOT / "frontend/public/locale"
    for path in sorted(locale_dir.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(keys.difference(data))
        assert missing == [], f"{path.name}: {missing}"
