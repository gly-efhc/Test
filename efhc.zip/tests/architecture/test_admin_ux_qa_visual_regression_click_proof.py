from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1514_docs_exist_and_are_honest() -> None:
    doc = read("docs/NORM/ADMIN_UX_QA_VISUAL_REGRESSION_CLICK_PROOF.md")
    assert "Cycle 1514" in doc
    assert "VISUAL_NOT_VERIFIED" in doc
    assert "CI_GREEN_NOT_CLAIMED" in doc
    assert "RELEASE_READY_NOT_CLAIMED" in doc
    assert "logs_74028431848.zip" in doc


def test_admin_pages_stay_on_generated_seams() -> None:
    pages = ROOT / "frontend/src/pages/admin"
    offenders: list[str] = []
    for path in sorted(pages.glob("*.tsx")):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if 'from "../../lib/api"' in text:
            offenders.append(path.name)
        if 'apiRequest("/admin' in text or 'apiRequest(`/admin' in text:
            offenders.append(path.name)
    assert offenders == []


def test_admin_notification_table_is_in_orm_and_ssot() -> None:
    models = read("backend/app/models/admin_models.py")
    ssot = read("docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv")
    matrix = read("docs/NORM/DB_DRIFT_MATRIX.md")
    assert "class AdminNotification" in models
    assert "__tablename__ = \"admin_notifications\"" in models
    assert "efhc_admin,admin_notifications,AdminNotification" in ssot
    assert "`admin_notifications`" in matrix


def test_outcome_delivery_uses_postgres_text_array_path() -> None:
    src = read("backend/app/services/outcome_service.py")
    assert "CAST(:path AS text[])" in src
    assert '"path": [str(channel)]' in src
    assert '"path": "{" + str(channel) + "}"' not in src


def test_tasks_service_has_no_top_level_get_bot_import() -> None:
    src = read("backend/app/services/tasks_service.py")
    assert "from app.bot.bot import get_bot  # noqa: E402" not in src
    notify_start = src.index("async def _notify_task_submission")
    notify_body = src[notify_start : notify_start + 900]
    assert "from app.bot.bot import get_bot" in notify_body


def test_cycle_1514_report_json_is_not_false_green() -> None:
    data = json.loads(
        read("reports/generated/admin_ux_qa_visual_regression_"
             "click_proof_v170_90.json")
    )
    assert data["cycle"] == 1514
    assert data["fresh_input_ci"] == "FAILED"
    assert data["output_github_ci"] == "NOT_VERIFIED"
    assert data["visual_status"] == "VISUAL_NOT_VERIFIED"
    assert data["release_status"] == "NOT_RELEASE_READY"
