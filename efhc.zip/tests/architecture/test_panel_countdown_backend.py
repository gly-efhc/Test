from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVICE = ROOT / "backend/app/services/panels_service.py"
ROUTES = ROOT / "backend/app/routes/panels_routes.py"
FRONT = ROOT / "frontend/src/pages/panels.tsx"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_panel_backend_has_activation_expiry_algorithm() -> None:
    src = read(SERVICE)
    assert "PANEL_LIFETIME_DAYS" in src
    assert (
        "expires_at = now + timedelta(days=PANEL_LIFETIME_DAYS)" in src
    )
    assert '"activated_at": now' in src
    assert '"expires": expires_at' in src


def test_panel_list_exposes_dates_for_countdown() -> None:
    svc = read(SERVICE)
    routes = read(ROUTES)
    assert '"activated_at": _as_iso(row.act_at)' in svc
    assert '"expires_at": _as_iso(row.expires_at)' in svc
    assert "server_now_utc: str" in routes
    assert "activated_at: str | None = None" in routes
    assert "expires_at: str | None = None" in routes


def test_panel_frontend_uses_server_anchor_not_raw_client_now() -> None:
    src = read(FRONT)
    assert "server_now_iso" in src
    assert "data-panel-countdown-source" in src
    assert "server-now-plus-client-stopwatch" in src
    assert "formatRemaining(rem, t)" in src


def test_cycle_1281_recorded_in_plan() -> None:
    plan = read(PLAN)
    assert "1281" in plan
    assert "panel countdown model" in plan.lower()
