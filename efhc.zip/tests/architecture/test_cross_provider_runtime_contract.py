"""Контракты cross-provider qualification и закрытия auth fallback."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_business_api_не_принимает_raw_telegram_init_data() -> None:
    deps = _read("backend/app/deps.py")
    impl = deps.split("async def _get_current_tg_id_impl", 1)[1]
    impl = impl.split("async def get_current_tg_id", 1)[0]
    assert "_bearer_auth_context" in impl
    assert "X-Telegram-Init-Data" not in impl
    assert 'getattr(request.state, "tg_id", None)' not in impl
    assert "server_session_bridge" in impl


def test_provider_neutral_reads_требуют_active_session() -> None:
    for relative in (
        "backend/app/identity/nonfinancial_read_dependency.py",
        "backend/app/identity/financial_read_dependency.py",
    ):
        source = _read(relative)
        assert "require_auth_context" in source
        assert "get_optional_auth_context" not in source
        assert "get_current_tg_id" not in source
        assert "global_id=context.global_id.value" in source


def test_admin_auth_не_имеет_telegram_transport_fallback() -> None:
    deps = _read("backend/app/deps.py")
    admin = deps.split("async def require_admin", 1)[1]
    admin = admin.split("# Health-проверка БД", 1)[0]
    assert "_bearer_auth_context" in admin
    assert "admin_global_session" in admin
    assert "admin_server_session_bridge" not in admin
    assert 'getattr(request.state, "tg_id", None)' not in admin
    assert "X-Telegram-Init-Data" not in admin


def test_frontend_generic_transport_только_bearer() -> None:
    api = _read("frontend/src/lib/api.ts")
    telegram_login = _read("frontend/src/services/authSession.service.ts")
    assert "getAuthAuthorizationHeader" in api
    assert "legacyTelegramFallback" not in api
    assert "X-Telegram-Init-Data" not in api
    assert '"X-Telegram-Init-Data": initData' in telegram_login


def test_legacy_selector_остаётся_только_internal_bridge_до_1631() -> None:
    deps = _read("backend/app/deps.py")
    assert "_provider_tg_for_global_id" in deps
    assert "context.global_id.value" in deps
    assert "request.state.provider_tg_id" in deps
    assert "request.state.tg_id" not in deps


def test_cross_provider_contract_сохранён_после_schema_squash() -> None:
    versions = ROOT / "backend/migrations/versions"
    assert sorted(path.name for path in versions.glob("*.py")) == [
        "0001_initial_release_schema.py",
    ]

