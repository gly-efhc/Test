from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend" / "src"


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_api_transport_uses_structured_api_error() -> None:
    src = read("frontend/src/lib/api.ts")
    assert "export class ApiError extends Error" in src
    assert "EFHC_API_REQUEST_FAILED" in src
    assert "throw new Error(`HTTP ${res.status}" not in src
    assert "throw new ApiError" in src


def test_public_profile_and_shop_do_not_render_raw_exception_messages() -> None:
    files = [
        "frontend/src/features/shop/ShopEntryPage.tsx",
        "frontend/src/components/ProfileModal.tsx",
        "frontend/src/features/profile/WebProfilePage.tsx",
    ]
    forbidden = [
        "err instanceof Error\n          ? err.message",
        "error instanceof Error\n          ? error.message",
        "walletsQ.error\n    ? String",
        ": String(error)",
    ]
    for file_name in files:
        src = read(file_name)
        for token in forbidden:
            assert token not in src, f"{file_name} still exposes {token!r}"
    assert "publicApiErrorMessage" in read("frontend/src/components/ProfileModal.tsx")
    assert "publicApiErrorMessage" in read("frontend/src/features/profile/WebProfilePage.tsx")


def test_admin_raw_message_setters_are_removed_from_first_wave() -> None:
    admin_files = list((FRONTEND / "pages" / "admin").glob("*.tsx"))
    admin_files += list((FRONTEND / "features" / "admin").glob("*.tsx"))
    admin_files += [
        FRONTEND / "components" / "admin" / "AdminLogsEventsDashboardRuntime.tsx",
        FRONTEND / "components" / "admin" / "AdminSystemHealthDashboardRuntime.tsx",
        FRONTEND / "components" / "admin" / "AdminObservabilityTimeseriesDashboardRuntime.tsx",
    ]
    forbidden = [
        re.compile(r"setError\(e\?\.message \|\| String\(e\)\)"),
        re.compile(r"setErr\(String\(e\?\.message \|\| e\)\)"),
        re.compile(r"setMsg\(String\(e\?\.message \|\| e\)\)"),
        re.compile(r"setMessage\(String\(e\?\.message \|\| e\)\)"),
        re.compile(r"error instanceof Error \? error\.message : String\(error\)"),
        re.compile(r"e instanceof Error \? e\.message : String\(e\)"),
        re.compile(r"\w+\s+instanceof\s+Error\s*\?\s*\w+\.message"),
        re.compile(r"detail=\{err\}"),
        re.compile(r">\{err\}<"),
        re.compile(r"detail=\{error\}"),
    ]
    for path in admin_files:
        src = path.read_text(encoding="utf-8")
        for pattern in forbidden:
            assert not pattern.search(src), f"{path} still has {pattern.pattern}"
    assert "adminUiErrorMessage" in read("frontend/src/lib/adminError.ts")
