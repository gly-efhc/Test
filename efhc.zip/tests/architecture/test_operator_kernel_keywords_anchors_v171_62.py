from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_keyword_anchor_groups_are_complete() -> None:
    path = ROOT / "docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md"
    assert path.exists()
    text = path.read_text(encoding="utf-8").casefold()
    required = {
        "frontend_visual": ("frontend", "screenshots", "frontend_visual_route_backed_work", "frontend_visual_route_backed_recovery"),
        "bottom_navigation": ("bottom nav", "6 canonical buttons", "canonical_bottom_navigation_guard", "frontend_canonical_navigation_guard"),
        "telegram_ton": ("live telegram", "tonconnect", "tonproof", "live_telegram_tonconnect_tonproof_transaction_gate"),
        "i18n": ("13 languages", "active", "vip", "frontend_i18n_guarded_work"),
        "ci_logs": ("green logs", "github ci", "ci_logs_repair_or_verification"),
        "archive": ("development archive", "release archive", "archive_build_and_release_boundary"),
        "kernel": ("v171.47", "operator_kernel_full_restore", "operator_kernel_full_restore_from_v171_47"),
    }
    for group, tokens in required.items():
        for token in tokens:
            assert token in text, f"{group} missing {token}"
    assert "where fixed" in text
    assert "validation" in text
