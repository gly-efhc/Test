from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INVENTORY = ROOT / "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md"
REPORT = ROOT / "reports/generated/sandbox_dashboard_inventory_v170_32.json"
PLAN = ROOT / "docs/NORM/DASHBOARD_VISUAL_PLAN.md"
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_sandbox_dashboard_inventory_document_exists() -> None:
    text = read(INVENTORY)
    assert "ACTIVE_INVENTORY_FOR_DASHBOARD_DIRECTION" in text
    assert "Песочница top projects" in text
    assert "Existing EFHC runtime dashboard candidates" in text
    assert "Forbidden port list" in text
    assert "1457 — Grafana Visual Pattern Map" in text


def test_inventory_machine_report_is_safe() -> None:
    data = load(REPORT)
    assert data["status"] == "ok"
    assert data["cycle"] == 1456
    assert data["version"] == "v170.32"
    assert data["sandbox"]["file_count"] > 1000
    assert data["sandbox"]["project_count"] >= 10
    assert data["grafana_reference"]["runtime_code_copied"] is False
    assert data["grafana_reference"]["dependencies_copied"] is False
    assert data["safety"]["economy_changed"] is False
    assert data["safety"]["tests_deleted_or_disabled"] is False


def test_inventory_classification_has_required_buckets() -> None:
    data = load(REPORT)
    classification = data["classification"]
    assert "AdminDashboardUiKit" in " ".join(
        classification["runtime_safe_existing_efhc"]
    )
    assert "Grafana dashboard shell" in " ".join(
        classification["prototype_only_sources"]
    )
    forbidden = " ".join(classification["forbidden_to_port"])
    assert "Grafana runtime code" in forbidden
    assert "Sandbox wallet/payment logic" in forbidden
    assert "Synthetic charts marked as real data" in forbidden


def test_kernel_plan_map_and_routes_point_to_inventory() -> None:
    assert "v170.32 / sandbox dashboard inventory" in read(KERNEL)
    assert "SANDBOX_DASHBOARD_INVENTORY.md" in read(PLAN)
    assert "SANDBOX_DASHBOARD_INVENTORY.md" in read(MAP)
    routes = read(ROUTES)
    assert "dashboard_visual_direction:" in routes
    assert "docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md" in routes
    assert "reports/generated/sandbox_dashboard_inventory_v170_32.json" in routes


def test_no_runtime_copy_claims_are_present() -> None:
    data = load(REPORT)
    assert data["safety"]["runtime_code_from_sandbox_copied"] is False
    assert data["safety"]["runtime_code_from_grafana_copied"] is False
    text = read(INVENTORY)
    assert "Runtime code copied" not in text
    assert "reference layers only" in text
