from pathlib import Path


def test_profile_history_uses_efhc_notation() -> None:
    text = Path(
        "frontend/src/components/profile/ProfileHistorySection.tsx"
    ).read_text(encoding="utf-8")
    assert "EFHC — общий баланс" in text
    assert "EFHCm — основные" in text
    assert "EFHCb — бонусные" in text


def test_exchange_page_uses_efhcm_notation() -> None:
    text = Path("frontend/src/pages/exchange.tsx").read_text(
        encoding="utf-8"
    )
    assert "Доступные kWh будут зачислены в EFHCm" in text
    assert "Доступно к выводу (EFHCm)" in text
    assert "Вывод от 10.00000000 EFHCm." in text
