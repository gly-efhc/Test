from __future__ import annotations

import json
from pathlib import Path

import pytest
from scripts.release.safe_extract_release import (
    parse_version,
    validate_compatibility,
)
from scripts.release.validate_migration_path import validate_path

ROOT = Path(__file__).resolve().parents[2]


def policy() -> dict[str, object]:
    return json.loads(
        (ROOT / "release_config/UPDATE_POLICY.json").read_text(
            encoding="utf-8"
        )
    )


def test_cutover_preparation_contract_is_explicit() -> None:
    data = policy()
    assert data["schema"] == "EFHC_RELEASE_UPDATE_POLICY_V4"
    assert data["version"] == data["release_version"]
    assert str(data["version"]).startswith("v172.")
    parse_version(str(data["release_version"]))
    assert data["archive_mode"] == "FULL_RELEASE_ARCHIVE"
    assert data["clean_install_supported"] is True
    assert data["update_policy"] == "pre_release_schema_freeze"
    assert data["supported_database_revisions"] == ["0001", "0002"]
    assert data["target_database_revision"] == "0002"
    assert data["database_migration_policy"] == (
        "cumulative_release_migrations"
    )
    assert data["database_migration_class"] == (
        "GLOBAL_ID_CUTOVER_PREPARATION"
    )
    assert data["rollback_database_policy"] == (
        "alembic_downgrade_or_snapshot"
    )


def test_schema_freeze_rejects_old_pre_release_source() -> None:
    data = policy()
    target = str(data["release_version"])
    minimum = str(data["minimum_supported_source_version"])
    with pytest.raises(ValueError, match="older than minimum"):
        validate_compatibility("v172.41", target, minimum)
    with pytest.raises(ValueError, match="already installed"):
        validate_compatibility(target, target, minimum)


def test_active_migration_path_is_cumulative() -> None:
    result = validate_path(
        ROOT / "backend/migrations/versions",
        "0001",
        "0002",
        ["0001", "0002"],
    )
    assert result["pending_revisions"] == ["0002"]
    assert sorted(
        path.name
        for path in (ROOT / "backend/migrations/versions").glob("*.py")
    ) == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]
