from __future__ import annotations

import json
from pathlib import Path

from ops.identity.export_user_id_api_contract import build_contract
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / (
    "ops/identity/user_id_api_contract_patch_boundary.json"
)


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_cycle1596_has_exact_kernel_route() -> None:
    classified = classify_task(
        "Цикл 1596 External API Pydantic UserId contract"
    )
    assert classified["task_type"] == "user_id_api_contract"
    route = resolve_route("user_id_api_contract", ROOT)
    assert route["config_primary"] is True
    assert route["fallback_used"] is False
    assert route["route_name"] == "user_id_api_contract"


def test_cycle1596_boundary_manifest_is_preserved() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert data["cycle"] == 1596
    assert data["target_head"] == "EFHC_Bot_v171_93.zip"
    assert len(data["entries"]) >= 480
    assert "backend/app/routes" in data["protected_roots"]
    assert "backend/app/schemas" in data["protected_roots"]


def test_contract_is_isolated_from_active_routes_and_schemas() -> None:
    for root_name in (
        "backend/app/routes",
        "backend/app/schemas",
        "backend/app/services",
        "backend/app/crud",
    ):
        for path in sorted((ROOT / root_name).rglob("*.py")):
            source = path.read_text(encoding="utf-8")
            assert "PydanticUserId" not in source
            assert "UserIdRequest" not in source
            assert "UserIdResponse" not in source


def test_cycle1596_keeps_orm_authcontext_and_migration_head() -> None:
    model = read("backend/app/models/user_models.py")
    deps = read("backend/app/deps.py")
    migrations = sorted(
        (ROOT / "backend/migrations/versions").glob("*.py")
    )
    assert "global_id: Mapped[int | None] = mapped_column(" in model
    assert 'user_id = synonym("global_id")' in model
    assert "id: Mapped[int] = mapped_column(" in model
    assert "class AuthContext:\n    tg_id: int" in deps
    assert "get_current_user_id" not in deps
    assert [path.name for path in migrations] == [
        "0001_initial_release_schema.py",
        "0002_global_id_cutover_preparation.py",
    ]


def test_api_contract_manifest_has_exact_scope() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert data["source_head"] == "EFHC_Bot_v171_92.zip"
    assert data["target_head"] == "EFHC_Bot_v171_93.zip"
    assert data["cycle"] == 1596
    assert "backend/app/routes" in data["protected_roots"]
    assert "backend/app/schemas" in data["protected_roots"]
    assert "frontend/src" in data["protected_roots"]
    assert "api" in data["protected_roots"]


def test_docs_mark_contract_prepared_but_not_runtime_wired() -> None:
    ssot = read(
        "docs/history/identity/"
        "USER_IDENTITY_AUTH_SSOT_PRE_GLOBAL_ID_v171_98.md"
    )
    norm = read(
        "docs/history/identity/"
        "USER_IDENTITY_MIGRATION_NORM_PRE_GLOBAL_ID_v171_98.md"
    )
    api_norm = read("docs/NORM/API_CONTRACTS.md")
    for token in (
        "PydanticUserId",
        "UserIdRequest",
        "UserIdResponse",
        "api_contract_prepared = true",
        "active_routes_wired = false",
        "v171.93",
    ):
        assert token in ssot or token in norm or token in api_norm

def test_exported_contract_is_string_only_and_not_active() -> None:
    contract = build_contract()
    assert contract["cycle"] == 1596
    assert contract["api_contract_prepared"] is True
    assert contract["active_routes_wired"] is False
    assert contract["existing_dtos_wired"] is False
    for key in (
        "path_parameter_schema",
        "response_field_schema",
        "pydantic_value_schema",
    ):
        schema = contract[key]
        assert schema["type"] == "string"
        assert schema["pattern"] == "^[0-9]{10}$"
        assert "integer" not in json.dumps(schema)

