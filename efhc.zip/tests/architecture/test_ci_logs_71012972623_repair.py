from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_cycle_1333_ci_log_repair_documents_exist() -> None:
    required = [
        "docs/audits/CI_LOGS_71012972623_REPAIR_V169_12.md",
        "docs/frontend/FRONTEND_PACKAGE_LOCK_REGISTRY_CANON.md",
        (
            "reports/change_cycle_2026-05-27_v169_12_cycle_1333_ci_logs_"
            "71012972623_repair.md"
        ),
        "reports/generated/ci_logs_71012972623_repair_v169_12.json",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel


def test_ci_installs_canonical_requirements_for_pytest() -> None:
    ci = read("ci.yml")
    assert "pip install -r extracted/backend/requirements.txt" in ci
    assert "pip install -r extracted/requirements-test.txt" in ci
    assert "OK: test dependency bootstrap" in ci
    assert "PYTHONPATH=backend pytest -q" in ci


def test_runtime_requirements_stay_free_of_test_only_deps() -> None:
    runtime = read("backend/requirements.txt")
    test_req = read("requirements-test.txt")
    assert "freezegun" not in runtime
    assert "pytest-asyncio" not in runtime
    assert "freezegun==1.5.1" in test_req


def test_frontend_lockfile_has_no_internal_registry_markers() -> None:
    lock = read("frontend/package-lock.json")
    forbidden = [
        "applied-caas-gateway",
        "internal.api.openai",
        "artifactory",
    ]
    for marker in forbidden:
        assert marker not in lock
    assert "https://registry.npmjs.org/next/-/next-16.2.6.tgz" in lock
    assert "https://registry.npmjs.org/react/-/react-19.2.6.tgz" in lock
    assert (
        "https://registry.npmjs.org/tailwindcss/-/tailwindcss-4.3.0.tgz"
        in lock
    )


def test_tailwind_v4_cleanup_remains_active() -> None:
    css = read("frontend/src/styles/globals.css")
    postcss = read("frontend/postcss.config.js")
    assert not (ROOT / "frontend/tailwind.config.js").exists()
    assert '@import "tailwindcss";' in css
    assert "@theme" in css
    assert '"@tailwindcss/postcss"' in postcss


def test_cycle_plan_shifts_shop_to_1334() -> None:
    plan = read(
        "docs/cycles/"
        "WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md"
    )
    assert "1333: CI logs 71012972623 repair" in plan
    assert "1334: Shop admin actions" in plan
    assert "1355: Admin recovery checkpoint report" in plan
