from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

TARGETS = [
    ROOT / "frontend/src/components/ProfileModal.tsx",
    ROOT / "frontend/src/components/profile/ProfileWalletSection.tsx",
    ROOT / "frontend/src/components/profile/ProfileHistorySection.tsx",
    ROOT
    / "frontend/src/components/profile/wallet/WalletConnectBanner.tsx",
    ROOT / "frontend/src/components/profile/wallet/WalletListItem.tsx",
    ROOT
    / "frontend/src/components/profile/wallet/WalletPrimaryCard.tsx",
    ROOT / "frontend/src/components/profile/history/"
    "BalanceHistoryEmptyState.tsx",
    ROOT
    / "frontend/src/components/profile/history/BalanceHistoryItem.tsx",
    ROOT / "frontend/src/components/profile/history/"
    "BalanceHistoryLoadMore.tsx",
    ROOT / "frontend/src/components/profile/history/"
    "BalanceHistoryLoadMore.tsx",
    ROOT
    / "frontend/src/components/profile/history/WithdrawHistoryItem.tsx",
    ROOT
    / "frontend/src/components/profile/history/WithdrawHistoryList.tsx",
    ROOT / "frontend/src/features/hub/HubPage.tsx",
]

BANNED = [
    '"Wallet connected"',
    '"Wallet required"',
    '"Connected"',
    '"Not connected"',
    '"Linked wallets"',
    '"Loading wallets"',
    '"No wallets linked yet"',
    '"Connect a wallet"',
    '"Primary wallet"',
    '"Skin preview unavailable"',
    '"Main Energy screen artwork"',
    '"Preview"',
    '"Purchase failed"',
    '"Activation failed"',
    '"Deposit failed"',
    '"Order failed"',
    '"Panel purchase"',
    '"Task reward"',
    '"Referral bonus"',
    '"Withdraw hold"',
    '"Withdraw refund"',
    '"Withdraw payout"',
    '"Shop purchase"',
]


def test_no_banned_hardcoded_ui_strings() -> None:
    for path in TARGETS:
        text = path.read_text(encoding="utf-8")
        for phrase in BANNED:
            assert phrase not in text, f"{phrase!r} found in {path}"
