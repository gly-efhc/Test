from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_telegram_initdata_auth_date_fails_closed() -> None:
    security = read("backend/app/core/security_core.py")
    tests = read("tests/efhc_backend/unit/test_telegram_init_data.py")

    assert "Missing auth_date in initData" in security
    assert "Invalid auth_date in initData" in security
    assert "if not auth_date:" in security
    assert "if not auth_date.isdigit():" in security
    assert "missing_auth_date_fails" in tests
    assert "non_numeric_auth_date_fails" in tests


def test_secrets_redactor_covers_production_aliases() -> None:
    logging_core = read("backend/app/core/logging_core.py")

    for alias in (
        "BOT_TOKEN",
        "TELEGRAM_BOT_TOKEN",
        "SECRET_KEY",
        "ADMIN_API_KEY",
        "TELEGRAM_WEBHOOK_SECRET",
        "WEBHOOK_SECRET",
        "CRON_SECRET",
        "SCHED_CRON_SECRET",
        "TON_API_KEY",
        "TONCENTER_API_KEY",
    ):
        assert f'"{alias}"' in logging_core

    assert "_secret_assignment_re" in logging_core
    assert "re.compile" in logging_core
    assert "self.MASK" in logging_core


def test_frontend_runtime_does_not_emit_legacy_headers() -> None:
    api = read("frontend/src/lib/api.ts")
    admin_home = read("frontend/src/pages/admin/index.tsx")
    ru = read("frontend/public/locale/ru.json")

    for token in (
        "X-Telegram-User-Id",
        "X-Admin-Id",
        "X-Admin-Token",
        "EFHC_ADMIN_ID",
        "EFHC_ADMIN_TOKEN",
    ):
        assert token not in api
        assert token not in admin_home

    assert "initDataUnsafe" not in api
    assert "localStorage" not in api
    assert "X-Admin-Id" not in ru
    assert "X-Admin-Token" not in ru
    assert "Telegram initData" in ru


def test_backend_cors_compat_layer_drops_legacy_headers() -> None:
    main = read("backend/app/main.py")
    compat = read("backend/app/__init__.py")

    for token in (
        "X-Telegram-User-Id",
        "X-Admin-Id",
        "X-Admin-Token",
    ):
        assert token not in main
        assert token not in compat

    assert "X-Telegram-Init-Data" in main
    assert "X-Telegram-Init-Data" in compat


def test_security_cycle_1430_documents_are_present() -> None:
    required = [
        "docs/cycles/WORK_CYCLES_1430_SECURITY_P2_REPLAY_OPSEC.md",
        (
            "reports/change_cycle_2026-06-04_v170_05_cycle_1430_"
            "security_p2_replay_opsec_repair.md"
        ),
        "docs/security/P0_SECURITY_REPAIR_CANON.md",
    ]
    for rel in required:
        assert (ROOT / rel).exists(), rel
