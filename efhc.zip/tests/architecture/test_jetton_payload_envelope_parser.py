from __future__ import annotations

from app.services.jetton_parsing_service import (
    parse_jetton_payload_envelope,
)


def test_jetton_payload_envelope_accepts_transfer_notification(
    monkeypatch,
):
    monkeypatch.setenv("USDT_JETTON_MASTER_ADDRESS", "EQ_USDT_MASTER")
    got = parse_jetton_payload_envelope(
        memo="JETTON_TRANSFER_NOTIFICATION|FORWARD_PAYLOAD=EFHC:deposit_efhc:7:9001",
        jetton_master="EQ_USDT_MASTER",
    )
    assert got.ok is True
    assert got.envelope_kind == "transfer_notification"
    assert got.forward_payload == "EFHC:deposit_efhc:7:9001"


def test_jetton_payload_envelope_blocks_fake_usdt(monkeypatch):
    monkeypatch.setenv("USDT_JETTON_MASTER_ADDRESS", "EQ_USDT_MASTER")
    got = parse_jetton_payload_envelope(
        memo="JETTON_TRANSFER_NOTIFICATION|FORWARD_PAYLOAD=EFHC:deposit_efhc:7:9001",
        jetton_master="EQ_FAKE_MASTER",
    )
    assert got.ok is False
    assert got.reason == "JETTON_MASTER_NOT_ALLOWED"


def test_jetton_payload_envelope_blocks_excesses(monkeypatch):
    monkeypatch.setenv("USDT_JETTON_MASTER_ADDRESS", "EQ_USDT_MASTER")
    got = parse_jetton_payload_envelope(
        memo="JETTON_EXCESSES|FORWARD_PAYLOAD=EFHC:deposit_efhc:7:9001",
        jetton_master="EQ_USDT_MASTER",
    )
    assert got.ok is False
    assert got.reason == "JETTON_EXCESSES_NOT_ALLOWED"


def test_jetton_payload_envelope_blocks_invalid_shape(monkeypatch):
    monkeypatch.setenv("USDT_JETTON_MASTER_ADDRESS", "EQ_USDT_MASTER")
    got = parse_jetton_payload_envelope(
        memo="prefix EFHC:deposit_efhc:7:9001 suffix",
        jetton_master="EQ_USDT_MASTER",
    )
    assert got.ok is False
    assert got.reason == "JETTON_ENVELOPE_INVALID"
