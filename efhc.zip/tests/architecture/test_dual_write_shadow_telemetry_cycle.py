from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MIGRATION = ROOT / "backend/migrations/versions/0001_initial_release_schema.py"


def test_release_0001_содержит_финальный_identity_runtime() -> None:
    source = MIGRATION.read_text(encoding="utf-8")
    assert 'revision = "0001"' in source
    assert "down_revision = None" in source
    assert "identity_migration_control" in source
    assert "legacy_authoritative" in source
    assert "dual_write_enabled" in source
    assert "shadow_read_enabled" in source
    assert "nonfinancial_read_global_id_enabled" in source
    assert "financial_read_global_id_enabled" in source
    assert "identity_ownership_shadow_telemetry" in source
    assert "BEFORE INSERT OR UPDATE" in source
    assert "dual-write conflict" in source


def test_shadow_gate_проверяет_release_revision_0002() -> None:
    path = ROOT / "ops/identity/postgresql_dual_write_shadow_gate.py"
    source = path.read_text(encoding="utf-8")
    assert 'EXPECTED_REVISION: Final[str] = "0001"' in source
    assert "READ ONLY DEFERRABLE" in source
    for marker in (
        '"fallback_rows"',
        '"mismatch_rows"',
        '"orphan_rows"',
        '"ambiguous_rows"',
    ):
        assert marker in source


def test_static_identity_runtime_guard_проходит() -> None:
    path = ROOT / "ops/identity/check_dual_write_shadow_telemetry.py"
    spec = importlib.util.spec_from_file_location("identity_runtime_guard", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    report = module.collect()
    assert report["статус"] == "PASS", report
