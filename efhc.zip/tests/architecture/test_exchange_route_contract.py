from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAGE = ROOT / "frontend/src/pages/exchange.tsx"
PANEL = ROOT / "frontend/src/components/ExchangePanel.tsx"
SEAMS = ROOT / "frontend/src/lib/api/generated/economicUserSeams.ts"
SERVICE_TS = ROOT / "frontend/src/services/exchange.service.ts"
ROUTES = ROOT / "backend/app/routes/exchange_routes.py"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"
SANDBOX = ROOT / "docs/frontend/FRONTEND_SANDBOX_REFERENCE.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_exchange_page_uses_current_user_contract_marker() -> None:
    src = read(PAGE)
    service_ts = read(SERVICE_TS)
    assert 'data-exchange-contract-proof="1289"' in src
    assert (
        'data-exchange-route-contract="current-user-no-tg-path"' in src
    )
    assert "EXCHANGE_PREVIEW_PATH" in service_ts
    assert "EXCHANGE_CONVERT_PATH" in service_ts


def test_exchange_frontend_does_not_build_tg_id_paths() -> None:
    src = read(PAGE) + "\n" + read(PANEL)
    banned = [
        "tg_id=",
        "tgId=",
        "user_id=",
        "userId=",
        "`/exchange/${",
        "`/api/exchange/${",
        "/exchange/transfer",
        "transfer_to_user",
        "user_transfer",
    ]
    for token in banned:
        assert token not in src


def test_exchange_generated_paths_have_no_user__path__params() -> None:
    src = read(SEAMS)
    assert '"/exchange/preview"' in src
    assert '"/exchange/convert"' in src
    assert "{tg_id}" not in src
    assert "{user_id}" not in src
    assert "/exchange/transfer" not in src


def test_exchange_backend_routes_depend_on_canonical_owner() -> None:
    src = read(ROUTES)
    assert 'prefix="/exchange"' in src
    assert "Depends(get_financial_read_owner)" in src
    assert "global_id=owner.global_id" in src
    assert '"/preview"' in src
    assert '"/convert"' in src
    assert '"/{tg_id}' not in src
    assert '"/{user_id}' not in src


def test_exchange_1289_docs_and_sandbox_reference_exist() -> None:
    docs = read(PLAN) + "\n" + read(REPORTS)
    sandbox = read(SANDBOX)
    assert "v168_87 / work pass" in docs
    assert "Exchange route and contract proof" in docs
    assert "Песочница.xz" in sandbox
    assert "визуальный донор" in sandbox
    assert "не HEAD" in sandbox
