from decimal import Decimal
from pathlib import Path

from app.services import referral_service

ROOT = Path(__file__).resolve().parents[2]


def test_full_referral_cycle_is_explicit_efhcb_truth() -> None:
    steps = referral_service.get_referral_level_steps()
    final = steps[-1]
    assert referral_service.REFERRAL_BONUS_ASSET == "EFHCb"
    assert final.required_active == 10_000
    assert final.direct_bonus_total == Decimal("1000.00000000")
    assert final.cumulative_level_bonus == Decimal("1411.00000000")
    assert final.cumulative_total_reward == Decimal("2411.00000000")


def test_api_and_frontend_show_no_hidden_lvl_arithmetic() -> None:
    route = (ROOT / "backend/app/routes/referrals_routes.py").read_text(encoding="utf-8")
    service = (ROOT / "frontend/src/services/referrals.service.ts").read_text(encoding="utf-8")
    page = (ROOT / "frontend/src/pages/referrals.tsx").read_text(encoding="utf-8")
    norm = (ROOT / "docs/NORM/REFERRALS_RULES.md").read_text(encoding="utf-8")
    for field in (
        "bonus_asset",
        "full_cycle_direct_bonus",
        "full_cycle_level_bonus",
        "full_cycle_total_bonus",
        "cumulative_level_bonus",
    ):
        assert field in route
        assert field in service
    assert 'data-referrals-full-cycle="10000-plus-lvl-1-5"' in page
    assert 'referrals.cumulative_level_rewards' in page
    assert 'stats?.bonus_asset ?? "EFHCb"' in page
    assert "1 000 + 1 411 = 2 411 EFHCb" in norm
