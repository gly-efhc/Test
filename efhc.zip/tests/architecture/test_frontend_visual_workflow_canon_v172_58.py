from hashlib import sha256
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORKFLOW = ROOT / ".github/workflows/frontend-visual.yml"
CANON_SHA256 = "fb976e2bf6d1cdc8c3e2750fae2717b0ce2db3535c48de78485335f48874f759"


def test_подтверждённый_screenshot_workflow_зафиксирован() -> None:
    content = WORKFLOW.read_bytes()
    assert sha256(content).hexdigest() == CANON_SHA256


def test_архитектура_screenshot_workflow_сохранена() -> None:
    text = WORKFLOW.read_text(encoding="utf-8")
    assert "page.goto(" in text
    assert "page.set_content(" not in text
    assert "request_interception" in text
    assert '"request_interception": False' in text
    assert "EXPECTED_SCREENSHOTS = 102" in text
    assert "screenshots_created" in text
    assert "actions/upload-artifact@v7" in text
