from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COMPONENT = ROOT / (
    "frontend/src/components/admin/"
    "AdminScreenshotQaPreparationPanel.tsx"
)
ADMIN_HOME = ROOT / "frontend/src/pages/admin/index.tsx"
DOC = ROOT / "docs/admin/ADMIN_SCREENSHOT_QA_PREPARATION.md"
AUDIT = (
    ROOT
    / "docs/audits"
    / ("FRONTEND_CYCLE_1354_ADMIN_SCREENSHOT_QA_AUDIT_V169_33.md")
)
REPORT = (
    ROOT
    / "reports"
    / (
        "change_cycle_2026-05-31_v169_33_cycle_1354_"
        "admin_screenshot_qa_preparation.md"
    )
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_cycle_1354_documents_exist() -> None:
    for path in (COMPONENT, DOC, AUDIT, REPORT):
        assert path.exists(), str(path)


def test_admin_home_does_not_render_internal_screenshot_qa() -> None:
    text = read(ADMIN_HOME)
    assert "AdminScreenshotQaPreparationPanel" not in text
    assert "Релизные данные" in text


def test_screenshot_panel_uses_shared_admin_ui_kit() -> None:
    text = read(COMPONENT)
    required = (
        "AdminSectionHeader",
        "AdminFilterBar",
        "AdminKpiCard",
        "AdminChartCard",
        "AdminFlowMapCard",
        "AdminActionTable",
        "AdminStatusBadge",
    )
    for marker in required:
        assert marker in text


def test_screenshot_panel_covers_admin_surfaces() -> None:
    text = read(COMPONENT)
    for marker in (
        "/admin",
        "/admin/bank",
        "/admin/users",
        "/admin/withdrawals",
        "/admin/shop",
        "/admin/tasks",
        "/admin/reports",
        "/admin/diagnostics",
    ):
        assert marker in text


def test_screenshot_panel_keeps_manual_qa_boundary() -> None:
    text = read(COMPONENT) + read(DOC)
    assert 'data-admin-screenshot-qa-preparation-cycle="1354"' in text
    assert "manual screenshot proof" in text
    assert "change `ci.yml`" in text
    assert "does not claim screenshot proof" in text


def test_sandbox_is_used_without_foreign_runtime() -> None:
    component = read(COMPONENT)
    doc = read(DOC)
    text = (component + doc).lower()
    assert "ui-main" in text
    assert "telegram mini app" in text
    for marker in ("from 'vue'", "from 'solid-js'", "jquery"):
        assert marker not in component.lower()


def test_cycle_1354_updates_next_plan() -> None:
    plan = read(
        ROOT / "docs/cycles/"
        "WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md"
    )
    assert (
        "1354: Admin screenshot QA preparation. DONE in v169_33."
        in plan
    )
    assert (
        "1355: Admin docs and SSOT route map update. DONE in v169_34."
        in plan
    )
    assert "1356: Admin regression proof pass. NEXT." in plan
