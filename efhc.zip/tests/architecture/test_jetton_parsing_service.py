from __future__ import annotations

from decimal import Decimal

from app.services.jetton_parsing_service import (
    is_strict_usdt_master,
    parse_payment_intent_transport_from_tx,
)


class _Tx:
    amount = Decimal("0")
    amount_asset = Decimal("1234567")
    asset = "JETTON"
    jetton_master = "EQ_USDT_MASTER"


def test_is_strict_usdt_master(monkeypatch):
    monkeypatch.setenv("USDT_JETTON_MASTER_ADDRESS", "EQ_USDT_MASTER")
    assert is_strict_usdt_master(jetton_master="EQ_USDT_MASTER") is True
    assert (
        is_strict_usdt_master(jetton_master="EQ_FAKE_MASTER") is False
    )


def test_parse_payment_intent_transport_from_tx_usdt(monkeypatch):
    monkeypatch.setenv("USDT_JETTON_MASTER_ADDRESS", "EQ_USDT_MASTER")
    monkeypatch.setenv("EFHC_JETTON_MASTER_ADDRESS", "EQ_EFHC_MASTER")
    tx = _Tx()
    res = parse_payment_intent_transport_from_tx(tx=tx)
    assert res.check.ok is True
    assert res.decision.confirm_asset == "USDT"
    assert str(res.decision.amount_asset_d8) == "1.23456700"
