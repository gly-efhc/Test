from pathlib import Path


def test_hub_shop_alias_sunset_and_0001_squash_lock() -> None:
    root = Path(".")
    hub = (root / "backend/app/bot/handlers/hub_handlers.py").read_text(
        encoding="utf-8"
    )
    admin = (
        root / "backend/app/bot/handlers/admin/admin_hub_handlers.py"
    ).read_text(encoding="utf-8")
    texts = (root / "backend/app/bot/texts.py").read_text(
        encoding="utf-8"
    )
    mig1 = (
        root / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    seed = (
        root / "backend/app/release/initial_data.py"
    ).read_text(encoding="utf-8")
    assert 'Command("shop")' not in hub
    assert 'Command("admin_shop")' not in admin
    assert "/shop — technical Hub alias" not in texts
    assert "/admin_shop" not in texts
    assert "INSERT INTO efhc_core.hub_links" not in mig1
    assert "INSERT INTO efhc_core.hub_links" in seed
    assert "SYSTEM_MANAGED_HUB_LINKS" in seed
    assert not (root / "frontend/src/pages/shop.tsx").exists()
