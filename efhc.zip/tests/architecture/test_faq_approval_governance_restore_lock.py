from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
GOV = ROOT / "docs/GENERAL/FAQ_APPROVAL_GOVERNANCE.md"
REG = ROOT / "docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md"
MAN = ROOT / "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json"
SSOT = ROOT / "docs/SSOT/FAQ_SSOT.md"
WORK = ROOT / "docs/cycles/WORK_CYCLES_101-200.md"


def test_governance_doc_exists_with_required_order() -> None:
    text = GOV.read_text(encoding="utf-8")
    required = [
        "draft package",
        "approval register",
        "approval manifest",
        "rewrite русского SSOT",
        "runtime rebuild",
        "ошибкой процесса",
    ]
    for marker in required:
        assert marker in text


def test_register_and_manifest_exist_and_match() -> None:
    reg = REG.read_text(encoding="utf-8")
    data = json.loads(MAN.read_text(encoding="utf-8"))
    assert "FAQ-APPROVAL-0001" in reg
    assert data["entries_total"] == len(data["entries"])
    assert data["entries"][0]["approval_id"] == "FAQ-APPROVAL-0001"
    assert data["entries"][0]["status"] == "implemented"
    assert data["entries"][0]["rewrite_allowed"] is True
    assert data["entries"][0]["runtime_rebuild_allowed"] is True


def test_ssot_doc_references_governance_layer() -> None:
    text = SSOT.read_text(encoding="utf-8")
    assert "FAQ approval governance" in text
    assert "FAQ_APPROVAL_REGISTER.md" in text
    assert "FAQ_APPROVAL_MANIFEST.json" in text


def test_cycle_103_marked_done() -> None:
    text = WORK.read_text(encoding="utf-8")
    assert "| 103 | done | FAQ approval governance restore." in text
