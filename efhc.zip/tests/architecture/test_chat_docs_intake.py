from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHATS_DIR = ROOT / "docs" / "NORM" / "CHATS"
CHAT_INDEX = CHATS_DIR / "CHATS_INDEX.md"
CHAT_README = CHATS_DIR / "README.md"
BRANCH_DIR = ROOT / "docs" / "NORM" / "CHAT_BRANCHES"


@dataclass(frozen=True)
class ChatGuardCase:
    name: str
    markers: tuple[str, ...]
    index_markers: tuple[str, ...]
    readme_marker: str | None = None
    report: str | None = None
    generated_report: str | None = None
    report_markers: tuple[str, ...] = ()
    sha256: str | None = None


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


CHAT_CASES = (
    ChatGuardCase(
        name="24.md",
        markers=(
            "# 24.md — экспорт рабочего чата EFHC Bot",
            "EFHC_Bot_v169_54_tonconnect_wallet_ux_range_closure.zip",
            "1351–1375 — CLOSED",
            "1376+ только после нового аудита/задачи",
        ),
        index_markers=(
            "docs/NORM/CHATS/24.md",
            "ветки 21, 22 и 24",
        ),
        readme_marker="`24.md` — ветка 24",
        report="reports/chat_24_intake_2026-06-03.md",
        generated_report="reports/generated/chat_24_intake_2026_06_03.json",
        report_markers=("`1376` не начат",),
    ),
    ChatGuardCase(
        name="25.md",
        markers=(
            "# 25.md — экспорт рабочего чата EFHC Bot",
            "EFHC_Bot_v169_72_cycle_1390_filename_hygiene_repair.zip",
            "1390–1400 — CI log repair and test healing",
        ),
        index_markers=(
            "docs/NORM/CHATS/25.md",
            "ветки 21, 22, 24 и 25",
        ),
        readme_marker="`25.md` — ветка 25",
        report="reports/chat_25_intake_2026-06-03.md",
        generated_report="reports/generated/chat_25_intake_2026_06_03.json",
        report_markers=("docs/NORM/CHATS/25.md",),
        sha256=(
            "2f5465aa394aaf08cfea0cc7ca05fec3a976113e09bb186010a"
            "398c32aa8d968"
        ),
    ),
    ChatGuardCase("26.md", (), ("1391–1400",)),
    ChatGuardCase("27.md", (), ("после закрытия",)),
    ChatGuardCase("28.md", (), ("v169.96 → v170.12",)),
    ChatGuardCase("30.md", (), ("linkage-линии",)),
    ChatGuardCase("31.md", (), ("1447–1465",)),
    ChatGuardCase("32.md", (), ("1466–1485",)),
    ChatGuardCase("33.md", (), ("1486–1499",)),
    ChatGuardCase("34.md", (), ("1500–1514",)),
    ChatGuardCase("35.md", (), ("1515–1525",)),
)


def test_uploaded_chat_exports_are_canonical_docs() -> None:
    for case in CHAT_CASES:
        path = CHATS_DIR / case.name
        assert path.exists(), case.name
        text = read(path)
        assert text.strip(), case.name
        for marker in case.markers:
            assert marker in text, f"{case.name}: {marker}"
        if case.sha256 is not None:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            assert digest == case.sha256


def test_chat_index_links_canonical_exports() -> None:
    index = read(CHAT_INDEX)
    readme = read(CHAT_README)
    for case in CHAT_CASES:
        assert f"`{case.name}`" in index
        assert f"docs/NORM/CHATS/{case.name}" in index
        for marker in case.index_markers:
            assert marker in index
        if case.readme_marker is not None:
            assert case.readme_marker in readme


def test_uploaded_chat_exports_have_no_branch_duplicates() -> None:
    for case in CHAT_CASES:
        assert not (BRANCH_DIR / case.name).exists(), case.name


def test_historical_chat_intake_reports_exist() -> None:
    for case in CHAT_CASES:
        if case.report is None or case.generated_report is None:
            continue
        report = ROOT / case.report
        generated = ROOT / case.generated_report
        assert report.exists(), case.name
        assert generated.exists(), case.name
        report_text = read(report)
        if case.name == "24.md":
            assert "cycle_1376" not in report_text.lower()
        for marker in case.report_markers:
            assert marker in report_text
        if case.sha256 is not None:
            assert case.sha256 in report_text
