from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_проверка_energy_progress_is_exact_and_data_driven() -> None:
    page = read("frontend/src/pages/index.tsx")
    assert "const progressPct = useMemo" in page
    assert "const visibleProgressPct = displayPct" in page
    assert 'style={{ width: `${visibleProgressPct}%` }}' in page
    assert 'data-has-progress={visibleProgressPct > 0 ? "true" : "false"}' in page
    assert "Math.max(2" not in page
    assert "minimum 2%" not in page
    assert "lifetime_generated_kwh" in page
    assert "gen_per_sec_effective" in page
    assert "available_kwh" in page
    assert "active_count" in page


def test_проверка_energy_information_surface_has_only_energy_metrics() -> None:
    page = read("frontend/src/pages/index.tsx")
    assert 'data-energy-chip="active-panels"' in page
    assert 'data-energy-chip="generation-rate"' in page
    assert 'data-energy-chip="available-kwh"' in page
    assert 'data-energy-range-safe="true"' in page
    assert 'data-energy-level-name={levelName}' in page
    assert "EnergyMvpSummary" not in page
    assert "profile.main_balance" not in page
    assert "profile.bonus_balance" not in page
    assert "nextAction" not in page
