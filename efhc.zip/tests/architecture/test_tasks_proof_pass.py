from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TASKS = ROOT / "frontend/src/pages/tasks.tsx"
ROUTES = ROOT / "backend/app/routes/tasks_routes.py"
PLAN = (
    ROOT
    / "docs/cycles"
    / "WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md"
)
REPORTS = ROOT / "reports/REPORTS_INDEX.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def test_tasks_has_final_proof_marker_and_clean_cards() -> None:
    src = read(TASKS)
    assert 'data-tasks-proof-pass="1294"' in src
    assert 'data-task-card="earning"' in src
    assert 'data-task-action-row="primary"' in src
    assert 'data-tasks-public-history="forbidden"' in src


def test_tasks_public_ui_stays_without_logs_or_debug_copy() -> None:
    src = read(TASKS)
    banned = [
        "TaskHistory",
        "ExecutionLog",
        "BackendLog",
        "idempotency_note",
        "task_complete_lock",
        "task_bonus_log",
        "/tasks/history",
        "/tasks/logs",
    ]
    for token in banned:
        assert token not in src


def test_tasks_routes_exist_without_public_history_route() -> None:
    src = read(ROUTES)
    assert '"/catalog"' in src
    assert '"/my"' in src
    assert '"/claim"' in src
    assert '"/history"' not in src
    assert '"/logs"' not in src


def test_cycle_1294_docs_are_registered() -> None:
    docs = read(PLAN) + "\n" + read(REPORTS)
    assert "v168_92 / work pass" in docs
    assert "Tasks proof pass" in docs
    assert "test_tasks_proof_pass.py" in docs
