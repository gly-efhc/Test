from __future__ import annotations

from decimal import Decimal

import pytest

sqlalchemy = pytest.importorskip("sqlalchemy")
text = sqlalchemy.text

pytestmark = pytest.mark.asyncio


async def _ensure_user(
    db_session,
    *,
    tg_id: int,
    main_balance: str,
    bonus_balance: str,
) -> None:
    await db_session.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, created_at, updated_at",
                    ") VALUES (",
                    "  :tg, NULL, FALSE, TRUE,",
                    "  :mb, :bb,",
                    "  0, now(), now()",
                    ")",
                    "ON CONFLICT (tg_id) DO UPDATE SET",
                    "  main_balance = excluded.main_balance,",
                    "  bonus_balance = excluded.bonus_balance,",
                    "  updated_at = now()",
                ]
            )
        ),
        {
            "tg": int(tg_id),
            "mb": str(main_balance),
            "bb": str(bonus_balance),
        },
    )


async def test_withdraw_request_uses_only_main_balance(
    db_session,
) -> None:
    from app.services.withdraw_service import request_withdraw

    tg_id = 304001
    await _ensure_user(
        db_session,
        tg_id=tg_id,
        main_balance="9.00000000",
        bonus_balance="50.00000000",
    )
    await db_session.commit()

    with pytest.raises(RuntimeError):
        await request_withdraw(
            db_session,
            tg_id=tg_id,
            amount=Decimal("10.00000000"),
            idempotency_key="wd-main-only-1",
        )

    row = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id = :tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("9.00000000")
    assert Decimal(str(row[1])) == Decimal("50.00000000")

    req = (
        await db_session.execute(
            text(
                "SELECT status, hold_done, refund_done "
                "FROM efhc_core.withdraw_requests "
                "WHERE tg_id = :tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert req is not None
    assert str(req[0]) == "PENDING"
    assert bool(req[1]) is False
    assert bool(req[2]) is False


async def test_cancel_withdraw_refunds_main_and_keeps_bonus(
    db_session,
) -> None:
    from app.services.withdraw_service import (
        cancel_withdraw,
        request_withdraw,
    )

    tg_id = 304002
    await _ensure_user(
        db_session,
        tg_id=tg_id,
        main_balance="20.00000000",
        bonus_balance="7.00000000",
    )
    await db_session.commit()

    dto = await request_withdraw(
        db_session,
        tg_id=tg_id,
        amount=Decimal("10.00000000"),
        idempotency_key="wd-cancel-1",
    )
    assert str(dto.status).upper() == "PENDING"
    assert bool(dto.hold_done) is True

    canceled = await cancel_withdraw(
        db_session,
        tg_id=tg_id,
        request_id=int(dto.id),
    )
    assert str(canceled.status).upper() == "CANCELED"
    assert bool(canceled.refund_done) is True

    row = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id = :tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("20.00000000")
    assert Decimal(str(row[1])) == Decimal("7.00000000")
