"""Контракт обновлённого универсального canonical CI."""

from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXPECTED_SHA256 = (
    "b9102704e27228a01c412653f172046b302cf5dbb0afe738471e3186ab59a3b0"
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_root_и_workflow_ci_совпадают() -> None:
    root_ci = ROOT / "ci.yml"
    workflow_ci = ROOT / ".github/workflows/canon.yml"
    assert root_ci.read_bytes() == workflow_ci.read_bytes()
    assert _sha256(root_ci) == EXPECTED_SHA256


def test_actions_v7_и_chromium_gate_закреплены() -> None:
    source = (ROOT / "ci.yml").read_text(encoding="utf-8")
    for action in (
        "actions/checkout@v7",
        "actions/setup-python@v7",
        "actions/setup-node@v7",
        "actions/upload-artifact@v7",
    ):
        assert action in source
    assert "Chromium visual audit" in source
    assert "all_pages_route_backed_visual_audit.py" in source
    assert "exit_chromium_visual.txt" in source
    assert 'NEXT_PUBLIC_ADMIN_TG_IDS: "1"' in source


def test_static_analyzer_install_commands_не_изменены() -> None:
    source = (ROOT / "ci.yml").read_text(encoding="utf-8")
    expected_counts = {
        "pip install flake8": 1,
        "pip install ruff": 1,
        "pip install mypy": 1,
        "pip install bandit": 1,
    }
    for command, expected in expected_counts.items():
        assert source.count(command) == expected
