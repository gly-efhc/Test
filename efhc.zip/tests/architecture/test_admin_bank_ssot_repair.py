from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVICE = ROOT / "backend" / "app" / "services" / "admin" / "admin_bank_service.py"
TX_SERVICE = ROOT / "backend" / "app" / "services" / "transactions_service.py"
ROUTES = ROOT / "backend" / "app" / "routes" / "admin_routes.py"
FRONTEND_BANK = ROOT / "frontend" / "src" / "pages" / "admin" / "bank.tsx"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_bank_money_routes_use_only_migrated_tables() -> None:
    src = read(SERVICE)
    tx = read(TX_SERVICE)

    forbidden_runtime_tables = (
        "efhc_admin.efhc_mint_burn",
        "efhc_core.internal_tx",
        " efhc_mint_burn",
        " internal_tx",
    )
    for table in forbidden_runtime_tables:
        assert table not in src

    assert "mint_bank_efhc" in src
    assert "burn_bank_efhc" in src
    assert "efhc_core.bank_balance" in src
    assert "efhc_core.efhc_transfers_log" in src
    assert "efhc_core.bank_balance" in tx
    assert "efhc_core.efhc_transfers_log" in tx


def test_money_routes_have_service_layer() -> None:
    routes = read(ROUTES)
    assert "async def admin_bank_mint" in routes
    assert "async def admin_bank_burn" in routes
    assert "AdminBankService.mint_efhc" in routes
    assert "AdminBankService.burn_efhc" in routes
    assert "require_idempotency_key_header_only" in routes
    assert "efhc_mint_burn" not in routes
    assert "internal_tx" not in routes


def test_no_direct_balance_write_outside_transactions_service() -> None:
    src = read(SERVICE)
    forbidden_write_markers = (
        "INSERT INTO efhc_core.bank_balance",
        "UPDATE efhc_core.bank_balance",
        "SET balance = :bal",
        "_set_bank_main",
    )
    for marker in forbidden_write_markers:
        assert marker not in src

    tx = read(TX_SERVICE)
    assert "INSERT INTO " in tx
    assert "UPDATE " in tx
    assert "efhc_core.bank_balance" in tx


def test_admin_bank_mint_burn_are_idempotent() -> None:
    src = read(SERVICE)
    tx = read(TX_SERVICE)
    routes = read(ROUTES)

    assert "idempotency_key" in src
    assert "result.detail == \"idempotent\"" in src
    assert "_find_log_by_idk" in tx
    assert "_bank_supply_idempotency_matches" in tx
    assert "IDEMPOTENCY_KEY_REUSED_FOR_DIFFERENT_BANK_OPERATION" in tx
    assert "Idempotency-Key обязателен" in tx
    assert "require_idempotency_key_header_only" in routes


def test_admin_bank_mint_burn_have_admin_guard() -> None:
    src = read(SERVICE)
    routes = read(ROUTES)

    assert "Depends(require_admin)" in routes
    assert "RBAC.resolve_admin" in routes
    assert "RBAC.resolve_admin" in src
    assert "RBAC.require_role(admin, AdminRole.SUPERADMIN)" in src


def test_admin_bank_mint_burn_write_audit_log() -> None:
    src = read(SERVICE)
    assert "AdminLogger.write" in src
    assert "action=\"BANK_MINT\"" in src
    assert "action=\"BANK_BURN\"" in src
    assert "ledger = efhc_transfers_log" in src


def test_frontend_admin_bank_waits_for_backend_confirmation() -> None:
    src = read(FRONTEND_BANK)
    assert "ADMIN_BANK_MINT_PATH" in src
    assert "ADMIN_BANK_BURN_PATH" in src
    assert "adminApiRequest" in src
    assert "bank_balance_after" in src
    assert "await load();" in src
