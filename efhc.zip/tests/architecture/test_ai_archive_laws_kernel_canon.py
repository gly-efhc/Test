from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_ai_archive_laws_integrity_guard_passes():
    root = Path(__file__).resolve().parents[2]
    proc = subprocess.run(
        [
            sys.executable,
            "scripts/ci/check_ai_archive_laws_integrity.py",
        ],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    assert proc.returncode == 0, proc.stdout
    assert "AI archive laws integrity guard passed" in proc.stdout


def test_ai_archive_laws_are_start_core_kernel_route():
    root = Path(__file__).resolve().parents[2]
    routes = (
        root / "ops/operator_kernel/config/routes.yaml"
    ).read_text(encoding="utf-8")
    assert "docs/AI/AI_ARCHIVE_LAWS.md" in routes
    assert "archive_laws_test_control" in routes


def test_ai_archive_laws_are_artifact_anchor():
    root = Path(__file__).resolve().parents[2]
    rules = (root / "ops/canon_rules.yaml").read_text(encoding="utf-8")
    assert "docs/AI/AI_ARCHIVE_LAWS.md" in rules
    assert "docs/AI/AI_ARCHIVE_LAWS_LOCK.json" in rules
