from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KERNEL = ROOT / "KERNEL.md"
MAP = ROOT / "map_element.md"
ROUTES = ROOT / "ops/operator_kernel/config/routes.yaml"
REPORT = (
    ROOT
    / "reports/generated/"
    / "fresh_ci_log_repair_kernel_anchor_restore_v171_04.json"
)
NORM = ROOT / "docs/NORM/FRESH_CI_LOG_REPAIR_KERNEL_ANCHOR_RESTORE.md"
CYCLE = (
    ROOT
    / "docs/cycles/"
    / "WORK_CYCLES_1529_FRESH_CI_LOG_REPAIR_KERNEL_ANCHOR_RESTORE.md"
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load(path: Path) -> dict:
    return json.loads(read(path))


def test_cycle_1529_docs_and_report_exist() -> None:
    assert NORM.exists()
    assert CYCLE.exists()
    assert REPORT.exists()
    report = load(REPORT)
    assert report["cycle"] == 1529
    assert report["version"] == "v171.04"
    assert report["log_verdict"] == "RED"
    assert report["log_failed_gate"] == "pytest"
    assert report["targeted_logged_failure_replay"] == "25 passed"


def test_compact_kernel_anchors_restored_for_legacy_guards() -> None:
    kernel = read(KERNEL)
    required = [
        "DASHBOARD_COMPONENT_CONTRACT.md",
        "v170.34 / Dashboard Design Tokens Foundation",
        "DASHBOARD_TOOLBAR_FOUNDATION",
        "ENERGY_DASHBOARD_RUNTIME_PORT",
        "ENERGY_DASHBOARD_SANDBOX_PROTOTYPE",
        "GRAFANA_PATTERN_MAP_COMPLETION.md",
        "PANEL_CHROME_FOUNDATION",
        "MINI_CHARTS_FOUNDATION",
        "VARIABLES_FILTERS_SYSTEM",
        "WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md",
    ]
    for marker in required:
        assert marker in kernel


def test_navigation_layers_record_current_repair() -> None:
    kernel = read(KERNEL)
    assert "Canonical archive lineage:" in kernel
    assert "fresh_ci_log_repair_kernel_anchor_restore" in read(ROUTES)
    assert "v171.04 / cycle 1529" in read(MAP)


def test_red_log_repair_does_not_claim_release_ready() -> None:
    report = load(REPORT)
    assert report["github_ci_green_claimed_for_output"] is False
    assert report["full_pytest_green_claimed"] is False
    assert report["frontend_build_green_claimed_for_output"] is False
    assert report["live_telegram_proof_claimed"] is False
    assert report["real_tonconnect_proof_claimed"] is False
    assert report["release_ready_claimed"] is False


def test_cycle_1529_does_not_change_runtime_or_economy() -> None:
    report = load(REPORT)
    for key in [
        "runtime_changed",
        "money_flow_changed",
        "wallet_flow_changed",
        "withdraw_logic_changed",
        "tonconnect_changed",
        "frontend_runtime_changed",
        "economy_changed",
    ]:
        assert report[key] is False
