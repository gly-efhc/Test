from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")


def test_direct_deposit_modal_is_efhc_jetton_only_surface() -> None:
    modal = _read("frontend/src/components/DepositModal.tsx")
    assert "useDirectDepositOpen" in modal
    assert "useDirectDepositStatus" in modal
    assert "buildEfhcDirectDepositTx" in modal
    assert 'data-direct-deposit-kind="efhc-jetton-to-efhcm"' in modal
    assert 'data-direct-deposit-label="direct"' in modal
    assert 'data-direct-deposit-amount="efhc-jetton"' in modal
    assert 'data-direct-deposit-action="send-efhc-jetton"' in modal
    assert "useWalletProvider" in modal
    assert "walletAddress" in modal
    assert "sendTransaction" in modal
    assert "sendTransaction(tx)" in modal
    assert "EFHCm" in modal

    forbidden = [
        'data-direct-deposit-amount="ton"',
        "tonAmountToNano",
        "wallet_open_url",
        "simple_deposit_auto",
        "package_id",
        "receiver_address",
        "apiRequest",
    ]
    for needle in forbidden:
        assert needle not in modal


def test_direct_deposit_service_owns_typed_efhc_contract_and_status() -> None:
    service = _read("frontend/src/services/directDeposit.service.ts")
    query = _read("frontend/src/queries/useDirectDeposit.ts")
    keys = _read("frontend/src/queries/queryKeys.ts")
    builder = _read("frontend/src/lib/ton/efhc-deposit-transfer.ts")

    assert 'apiRequest<unknown>("/deposit/direct-open", "POST")' in service
    assert 'z.literal("direct_efhc_jetton_deposit")' in service
    assert 'z.literal("EFHC")' in service
    assert "jetton_master_address" in service
    assert "jetton_decimals" in service
    assert "forward_payload_text" in service
    assert 'row.reason !== "efhc_external_deposit"' in service
    assert 'row.reason !== "efhc_jetton_nomemo_wallet_bound"' in service
    assert "simple_deposit_auto" not in service
    assert "tonAmountToNano" not in service
    assert "useDirectDepositOpen" in query
    assert "useDirectDepositStatus" in query
    assert "refetchInterval" in query
    assert "directDeposit:" in keys
    assert "parseEfhcJettonD8" in builder
    assert 'asset: "EFHC"' in builder
    assert "resolveSenderJettonWallet" in builder
    assert "buildJettonTransferTonConnectTx" in builder


def test_global_header_plus_opens_direct_deposit_without_shop() -> None:
    header = _read("frontend/src/components/GlobalHeader.tsx")
    layout = _read("frontend/src/components/Layout.tsx")
    expected = "const onDepositClick = () => {\n    props.onDeposit();"
    assert expected in header
    assert 'aria-label={t("deposit.direct_title")}' in header
    button = re.search(
        r"onClick=\{onDepositClick\}(?P<body>.*?)</button>",
        header,
        flags=re.S,
    )
    assert button
    button_body = button.group("body")
    assert '<HeaderActionIcon kind="deposit" />' in button_body
    assert "<span>EFHC</span>" in button_body
    for forbidden in ("browser-shop", "USDT", "TON / GRAM"):
        assert forbidden not in button_body
    open_deposit = re.search(
        r"function openDeposit\(\) \{(?P<body>.*?)\n  \}",
        layout,
        flags=re.S,
    )
    assert open_deposit
    body = open_deposit.group("body")
    assert "setDepositOpen(true);" in body
    assert "browser-shop" not in body
    assert "hub" not in body.lower()


def test_backend_direct_open_returns_efhc_jetton_metadata_only() -> None:
    routes = _read("backend/app/routes/deposit_routes.py")
    schemas = _read("backend/app/schemas/deposit_schemas.py")
    memo = _read("backend/app/integrations/ton_memo.py")
    assert '"/direct-open"' in routes
    assert "DirectDepositOpenOut" in schemas
    assert "build_deposit_memo" in routes
    assert 'return f"EFHC:{tg_id}"' in memo
    assert 'Literal["direct_efhc_jetton_deposit"]' in schemas
    assert 'Literal["EFHC"]' in schemas
    assert "jetton_master_address" in schemas
    assert "jetton_decimals" in schemas
    assert "forward_payload_text" in schemas
    assert "wallet_open_url" not in schemas
    assert "_build_ton_wallet_open_url" not in routes
    direct = re.search(
        r"async def open_direct_deposit\((?P<body>.*?)\n\n@router.get",
        routes,
        flags=re.S,
    )
    assert direct
    body = direct.group("body")
    assert "EFHC_JETTON_MASTER_ADDRESS" in body
    assert "package_id" not in body
    assert "create_intent_deposit_by_package" not in body


def test_watcher_direct_branch_is_exact_efhc_jetton_credit() -> None:
    watcher = _read("backend/app/services/watcher_service.py")
    branch = re.search(
        r'elif kind == "simple_efhc":(?P<body>.*?)\n\s*else:',
        watcher,
        flags=re.S,
    )
    assert branch
    body = branch.group("body")
    assert 'transport.transport_kind != "efhc_jetton"' in body
    assert "direct_deposit_requires_efhc_jetton" in body
    assert "direct_amount = d8(transport.amount_asset_d8)" in body
    assert 'reason="efhc_external_deposit"' in body
    assert 'idempotency_key=f"jetton:efhc:direct:{tx.tx_hash}"' in body
    assert "amount_ton" not in body
    assert "simple_deposit_auto" not in body
    assert "_resolve_simple_deposit_qty" not in watcher


def test_direct_deposit_locale_keys_exist_for_all_13_languages() -> None:
    locale_dir = ROOT / "frontend/public/locale"
    expected_langs = {
        "ru", "en", "uk", "de", "fr", "es", "it",
        "tr", "pl", "da", "hi", "id", "sw",
    }
    paths = sorted(locale_dir.glob("*.json"))
    assert {path.stem for path in paths} == expected_langs
    keys = {
        "deposit.direct_title",
        "deposit.direct_description",
        "deposit.direct_send_efhc",
        "deposit.wallet_required_title",
        "deposit.wallet_required",
        "deposit.connect_wallet",
        "deposit.amount_label",
        "deposit.amount_placeholder",
        "deposit.amount_hint",
        "deposit.amount_invalid",
        "deposit.status_checking_title",
        "deposit.status_checking_detail",
        "deposit.status_confirmed_title",
        "deposit.status_confirmed_detail",
        "deposit.status_retry",
    }
    for path in paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in keys:
            assert key in data, f"{path.name}: {key}"
            assert str(data[key]).strip(), f"{path.name}: {key} empty"
