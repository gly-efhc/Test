from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "ops/routes/check_withdraw_road.py"


def _load():
    spec = importlib.util.spec_from_file_location(
        "withdraw_road_1187",
        SCRIPT,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_withdraw_economic_road_guard() -> None:
    module = _load()
    data = module.build()
    assert data["статус"] == "ok"
    assert data["все_обязательные_условия"] is True
