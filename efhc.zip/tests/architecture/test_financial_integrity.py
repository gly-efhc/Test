from __future__ import annotations

import ast
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

ALLOWED_WRITE_FILE = Path(
    "backend/app/services/transactions_service.py"
)

FORBIDDEN_FIELDS = {
    "balance",
    "main_balance",
    "bonus_balance",
    "energy",
}

IGNORED_DIRS = {
    "alembic",
    "migrations",
    "__pycache__",
}


@dataclass(frozen=True)
class Breach:
    file_path: str
    line: int
    message: str


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _iter_backend_app_files(root: Path) -> Iterable[Path]:
    base = root / "backend" / "app"
    if not base.exists():
        return []

    for path in base.rglob("*.py"):
        if set(path.parts) & IGNORED_DIRS:
            continue
        yield path


def _is_allowed_write_file(path: Path) -> bool:
    allowed = ALLOWED_WRITE_FILE.as_posix()
    return path.as_posix().endswith(allowed)


def _extract__dict__keys(node: ast.AST) -> set[str]:
    keys: set[str] = set()

    if isinstance(node, ast.Dict):
        for key in node.keys:
            is_str = isinstance(key, ast.Constant) and isinstance(
                key.value, str
            )
            if is_str:
                keys.add(key.value)
        return keys

    if isinstance(node, ast.Call):
        is_dict = (
            isinstance(node.func, ast.Name) and node.func.id == "dict"
        )
        if is_dict:
            for kw in node.keywords:
                if kw.arg is not None:
                    keys.add(kw.arg)
        return keys

    return keys


class _Visitor(ast.NodeVisitor):
    def __init__(self, file_path: Path) -> None:
        self.file_path = file_path
        self.breaches: list[Breach] = []

    def _add(self, node: ast.AST, detail: str) -> None:
        line = getattr(node, "lineno", 1)
        self.breaches.append(
            Breach(
                file_path=self.file_path.as_posix(),
                line=line,
                message=detail,
            )
        )

    def _check_attr_write(self, target: ast.AST, node: ast.AST) -> None:
        is_attr = isinstance(target, ast.Attribute)
        if is_attr and target.attr in FORBIDDEN_FIELDS:
            msg = (
                "CRITICAL SECURITY BREACH: Прямая модификация "
                f"{target.attr} вне transactions_service.py. "
                "Используйте только функции из transactions_service.py!"
            )
            self._add(node, msg)

    def visit_Assign(self, node: ast.Assign) -> None:
        for target in node.targets:
            self._check_attr_write(target, node)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        self._check_attr_write(node.target, node)
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self._check_attr_write(node.target, node)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        func = node.func
        is_method = isinstance(func, ast.Attribute)
        if is_method and func.attr in {"update", "values"}:
            self._check_update_values(node, func.attr)
        self.generic_visit(node)

    def _check_update_values(self, node: ast.Call, name: str) -> None:
        touched: set[str] = set()

        for kw in node.keywords:
            if kw.arg is not None:
                touched.add(kw.arg)

        for arg in node.args:
            touched |= _extract__dict__keys(arg)

        forbidden = touched & FORBIDDEN_FIELDS
        if forbidden:
            fields = ", ".join(sorted(forbidden))
            msg = (
                "CRITICAL SECURITY BREACH: Запрещённое обновление "
                f"полей [{fields}] через .{name}() вне "
                "transactions_service.py. Используйте только "
                "функции из transactions_service.py!"
            )
            self._add(node, msg)


def test_financial_integrity_no_direct_balance_writes() -> None:
    root = _repo_root()
    breaches: list[Breach] = []

    for file_path in _iter_backend_app_files(root):
        if _is_allowed_write_file(file_path):
            continue

        source = file_path.read_text(encoding="utf-8")
        try:
            tree = ast.parse(source, filename=file_path.as_posix())
        except SyntaxError as exc:
            lineno = getattr(exc, "lineno", 1)
            msg = (
                "CRITICAL SECURITY BREACH: SyntaxError мешает AST "
                f"проверке в {file_path.as_posix()}:{lineno}"
            )
            raise AssertionError(msg) from exc

        visitor = _Visitor(file_path=file_path)
        visitor.visit(tree)
        breaches.extend(visitor.breaches)

    if breaches:
        lines: list[str] = []
        for breach in breaches[:25]:
            lines.append(
                f"{breach.file_path}:{breach.line}: {breach.message}"
            )

        if len(breaches) > 25:
            rest = len(breaches) - 25
            lines.append(f"... и ещё {rest} нарушений.")

        raise AssertionError("\n".join(lines))
