from __future__ import annotations

import importlib
import os

import pytest
from sqlalchemy import text

pytest.importorskip("sqlalchemy")


def _reload_for_postgres() -> object:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.payment_intents_service as pis

    return importlib.reload(pis)


@pytest.mark.asyncio
async def test_get_intent_status_owner_only(db_session) -> None:
    pis = _reload_for_postgres()

    text(
        'DELETE FROM efhc_core.payment_intents'
    )
    await db_session.execute(
        text(
            """
            INSERT INTO efhc_core.payment_intents (
                id, tg_id, purpose, package_id, asset,
                amount_asset_d8, efhc_amount_d8, status,
                idempotency_key, payload, to_address,
                external_tx_hash, created_at, expires_at, updated_at
            ) VALUES (
                9, 5001, 'deposit_efhc', 1, 'TON',
                '1.00000000', '10.00000000', 'SENT',
                'k1', 'EFHC:deposit_efhc:9:5001',
                'EQ_RECEIVER', NULL, now(), now(), now()
            )
            """
        )
    )
    await db_session.commit()

    ok = await pis.get_intent_status_for_user(db_session, tg_id=5001, intent_id=9)
    assert ok["ok"] is True

    no = await pis.get_intent_status_for_user(db_session, tg_id=7777, intent_id=9)
    assert no["ok"] is False
