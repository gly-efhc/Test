from __future__ import annotations

import importlib
import os

import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_payment_intents_service_postgres() -> object:
    # Канон: Postgres-only.
    if (os.getenv("DATABASE_URL") or "").startswith("sqlite"):
        pytest.fail("SQLite is forbidden by CANON")
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    import backend.app.services.payment_intents_service as pis
    return importlib.reload(pis)


@pytest.mark.asyncio
async def test_get_intent_status_owner_only() -> None:
    pis = _reload_payment_intents_service_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(pis, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with Session() as db:
        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.payment_intents (
                    id, tg_id, purpose, package_id, asset,
                    amount_asset_d8, efhc_amount_d8, status,
                    idempotency_key, payload, to_address,
                    external_tx_hash, created_at, expires_at, updated_at
                ) VALUES (
                    9, 5001, 'deposit_efhc', 1, 'TON',
                    '1.00000000', '10.00000000', 'SENT',
                    'k1', 'EFHC:deposit_efhc:9:5001',
                    'EQ_RECEIVER', NULL, now(), now(), now()
                )
                """
            )
        )
        await db.commit()

        ok = await pis.get_intent_status_for_user(
            db,
            tg_id=5001,
            intent_id=9,
        )
        assert ok is not None
        assert ok["id"] == 9
        assert ok["tg_id"] == 5001

        other = await pis.get_intent_status_for_user(
            db,
            tg_id=5002,
            intent_id=9,
        )
        assert other is None

    await engine.dispose()
