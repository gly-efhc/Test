"""Unit contract write-side owner boundary цикла 1640."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest
from app.identity.financial_write_switch import (
    FinancialWriteOwnerError,
    resolve_and_lock_financial_write_owner,
)


@dataclass
class _Result:
    value: Any

    def first(self) -> Any:
        return self.value


class _Session:
    def __init__(self, *rows: Any) -> None:
        self._rows = list(rows)
        self.statements: list[Any] = []

    async def execute(
        self,
        statement: Any,
        params: dict[str, Any] | None = None,
    ) -> _Result:
        self.statements.append((statement, params))
        return _Result(self._rows.pop(0))


def _control(*, dual_write_enabled: bool = True) -> Any:
    return type(
        "ControlRow",
        (),
        {
            "financial_read_global_id_enabled": True,
            "financial_read_rollback_ready": True,
            "dual_write_enabled": dual_write_enabled,
            "shadow_read_enabled": True,
            "legacy_authoritative": True,
        },
    )()


def _user(
    *,
    global_id: int = 1234567890,
    tg_id: int | None = 777000111,
    is_active: bool = True,
) -> Any:
    return type(
        "UserRow",
        (),
        {
            "global_id": global_id,
            "tg_id": tg_id,
            "is_active": is_active,
        },
    )()


@pytest.mark.asyncio
async def test_write_owner_by_global_id_блокирует_ton_only() -> None:
    session = _Session(_control(), _user(tg_id=None))

    owner = await resolve_and_lock_financial_write_owner(
        session,  # type: ignore[arg-type]
        global_id=1234567890,
    )

    assert owner.global_id == 1234567890
    assert owner.legacy_tg_id is None
    assert owner.rollback_ready is True
    statement = str(session.statements[1][0]).upper()
    assert "FOR UPDATE" in statement
    assert "GLOBAL_ID" in statement


@pytest.mark.asyncio
async def test_write_owner_by_tg_id_нормализует_global_id() -> None:
    session = _Session(_control(), _user())

    owner = await resolve_and_lock_financial_write_owner(
        session,  # type: ignore[arg-type]
        tg_id=777000111,
    )

    assert owner.global_id == 1234567890
    assert owner.legacy_tg_id == 777000111
    statement = str(session.statements[1][0]).upper()
    assert "FOR UPDATE" in statement
    assert "TG_ID" in statement


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("global_id", "tg_id"),
    ((None, None), (1234567890, 777000111)),
)
async def test_write_owner_требует_ровно_один_selector(
    global_id: int | None,
    tg_id: int | None,
) -> None:
    session = _Session()

    with pytest.raises(
        FinancialWriteOwnerError,
        match="ровно один identity selector",
    ):
        await resolve_and_lock_financial_write_owner(
            session,  # type: ignore[arg-type]
            global_id=global_id,
            tg_id=tg_id,
        )


@pytest.mark.asyncio
async def test_write_owner_отклоняет_выключенный_dual_write() -> None:
    session = _Session(_control(dual_write_enabled=False))

    with pytest.raises(FinancialWriteOwnerError, match="dual-write"):
        await resolve_and_lock_financial_write_owner(
            session,  # type: ignore[arg-type]
            global_id=1234567890,
        )


@pytest.mark.asyncio
async def test_write_owner_отклоняет_неактивный_account() -> None:
    session = _Session(_control(), _user(is_active=False))

    with pytest.raises(FinancialWriteOwnerError, match="неактивен"):
        await resolve_and_lock_financial_write_owner(
            session,  # type: ignore[arg-type]
            global_id=1234567890,
        )
