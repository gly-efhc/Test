from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]

# Scan only shipping code (not docs/tests).
SCAN_DIRS = [
    REPO_ROOT / "backend" / "app",
    REPO_ROOT / "frontend" / "src",
]

# Markers that typically indicate unfinished / stubbed implementation.
FORBIDDEN_PATTERNS = [
    re.compile(r"\bTODO\b", re.IGNORECASE),
    re.compile(r"\bFIXME\b", re.IGNORECASE),
    re.compile(r"\bTBD\b", re.IGNORECASE),
    re.compile(r"\bNOT\s * IMPLEMENTED\b", re.IGNORECASE),
    re.compile(r"NotImplementedError"),
    re.compile(r"\bSTUB\b", re.IGNORECASE),
    re.compile(r"pass\s*  # \s * (todo|fixme|tbd)", re.IGNORECASE),
]

ALLOWED_PATH_PARTS = {
    "__pycache__",
    ".next",
    "node_modules",
    "dist",
    "build",
}

FILE_EXTS = {".py", ".ts", ".tsx"}


def _is_allowed_path(path: Path) -> bool:
    parts = set(path.parts)
    return any(p in parts for p in ALLOWED_PATH_PARTS)


def test_no_placeholders_in_shipping_code():
    hits: list[str] = []

    for base in SCAN_DIRS:
        if not base.exists():
            continue

        for path in base.rglob("*"):
            if path.is_dir():
                continue
            if path.suffix not in FILE_EXTS:
                continue
            if _is_allowed_path(path):
                continue

            text = path.read_text(
                encoding="utf-8",
                errors="replace",
            )

            for lineno, line in enumerate(text.splitlines(), start = 1):
                # Frontend input placeholders are UI labels,
                # not unfinished markers.
                # code.
                is_ts = path.suffix in {".ts", ".tsx"}
                has_marker = "placeholder = " in line
                if is_ts and has_marker:
                    continue

                for pat in FORBIDDEN_PATTERNS:
                    if pat.search(line):
                        rel = path.relative_to(REPO_ROOT)
                        item = f"{rel}:{lineno}: {line.strip()}"
                        hits.append(item)
                        break

    assert not hits, (
        "Unfinished markers found:\n" + "\n".join(hits[:200])
    )

