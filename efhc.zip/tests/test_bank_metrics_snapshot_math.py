from app.services.bank_metrics_snapshot_service import (
    D8_SCALE,
    PCT_SCALE,
    calculate_bank_metrics_snapshot,
)


def d8(value: int) -> int:
    return value * D8_SCALE


def pct(value: int) -> int:
    return value * PCT_SCALE


def test_проверка_bank_metrics_snapshot_целые_формулы() -> None:
    metrics = calculate_bank_metrics_snapshot(
        {
            "reserve_efhc_d8": d8(400),
            "users_main_efhc_d8": d8(500),
            "users_bonus_efhc_d8": d8(100),
            "panel_spent_efhc_d8": d8(100),
            "generated_kwh_d8": d8(150),
            "converted_kwh_d8": d8(60),
            "fixed_generated_kwh_d8": d8(250),
            "fixed_population": 2,
            "minted_efhc_d8": 0,
            "burned_efhc_d8": d8(4_999_000),
        }
    )

    assert metrics["circulation_efhc_d8"] == d8(600)
    assert metrics["actual_mass_efhc_d8"] == d8(1_000)
    assert metrics["expected_supply_efhc_d8"] == d8(1_000)
    assert metrics["new_obligations_efhcm_d8"] == d8(50)
    assert metrics["fixed_obligations_efhcm_d8"] == d8(50)
    assert metrics["pending_kwh_d8"] == d8(90)
    assert metrics["reserve_pct_d8"] == pct(40)
    assert metrics["circulation_pct_d8"] == pct(60)
    assert metrics["new_obligations_pct_d8"] == pct(5)
    assert metrics["users_main_pct_d8"] == pct(50)
    assert metrics["users_bonus_pct_d8"] == pct(10)
    assert metrics["actual_mass_pct_d8"] == pct(100)
    assert metrics["fixed_obligations_pct_d8"] == pct(5)
    assert metrics["panel_spent_pct_d8"] == pct(20)
    assert metrics["generated_pct_d8"] == pct(15)
    assert metrics["converted_pct_d8"] == pct(40)
    assert metrics["pending_pct_d8"] == pct(60)
    assert metrics["integrity_pct_d8"] == pct(100)


def test_проверка_negative_spend_не_создаёт_двойное_вычитание() -> None:
    metrics = calculate_bank_metrics_snapshot(
        {
            "panel_spent_efhc_d8": -d8(100),
            "generated_kwh_d8": d8(150),
        }
    )
    assert metrics["panel_spent_efhc_d8"] == 0
    assert metrics["new_obligations_efhcm_d8"] == d8(150)
