from __future__ import annotations

import importlib
import os
from datetime import datetime, timezone

import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_payment_service_for_postgres() -> object:
    if (os.getenv("DATABASE_URL") or "").lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden by CANON")
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()
    import backend.app.services.payment_intents_service as ps
    return importlib.reload(ps)


async def _ensure_sale_package(db: AsyncSession, package_id: int = 1) -> None:
    # Minimal package required for create_intent_deposit_by_package
    await db.execute(
        text(
            """
            INSERT INTO efhc_admin.efhc_sale_packages
                (id, title, asset, price_asset_d8, efhc_amount_d8, is_active, created_at, updated_at)
            VALUES
                (:id, :title, :asset, :price, :amount, true, :now, :now)
            ON CONFLICT (id) DO UPDATE SET
                title = EXCLUDED.title,
                asset = EXCLUDED.asset,
                price_asset_d8 = EXCLUDED.price_asset_d8,
                efhc_amount_d8 = EXCLUDED.efhc_amount_d8,
                is_active = EXCLUDED.is_active,
                updated_at = EXCLUDED.updated_at
            """
        ),
        {
            "id": package_id,
            "title": "Package #1",
            "asset": "TON",
            "price": "100000000",  # d8 string
            "amount": "100000000",  # d8 string
            "now": datetime.now(timezone.utc),
        },
    )
    await db.commit()


@pytest.mark.asyncio
async def test_two_intents_same_user_no_unique_payload_conflict() -> None:
    ps = _reload_payment_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)

    core_schema = get_postgres_schema_default()
    # Keep admin schema clean too because we insert packages there.
    await truncate_schema_all_tables(engine, core_schema)
    await truncate_schema_all_tables(engine, "efhc_admin")

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with Session() as db:
        await _ensure_sale_package(db, package_id=1)

        r1 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=9001,
            idempotency_key="k1",
            package_id=1,
        )
        r2 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=9001,
            idempotency_key="k2",
            package_id=1,
        )

        assert r1["intent_id"] != r2["intent_id"]
        assert r1["payload"] != r2["payload"]
        assert r1["payload"].startswith("EFHC:deposit_efhc:")
        assert r2["payload"].startswith("EFHC:deposit_efhc:")

        cnt = (await db.execute(text("SELECT COUNT(*) FROM efhc_core.payment_intents"))).scalar_one()
        assert int(cnt) == 2

    await engine.dispose()


@pytest.mark.asyncio
async def test_two_shop_external_intents_same_user_no_conflict() -> None:
    ps = _reload_payment_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)

    core_schema = get_postgres_schema_default()
    await truncate_schema_all_tables(engine, core_schema)
    await truncate_schema_all_tables(engine, "efhc_admin")

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with Session() as db:
        # External shop intents do not require sale packages, but keep admin clean.
        r1 = await ps.create_intent_external_shop(
            db,
            tg_id=9002,
            idempotency_key="k1",
            payload_prefix="SHOP:ext:",
        )
        r2 = await ps.create_intent_external_shop(
            db,
            tg_id=9002,
            idempotency_key="k2",
            payload_prefix="SHOP:ext:",
        )

        assert r1["intent_id"] != r2["intent_id"]
        assert r1["payload"] != r2["payload"]
        assert r1["payload"].startswith("SHOP:ext:")
        assert r2["payload"].startswith("SHOP:ext:")

        cnt = (await db.execute(text("SELECT COUNT(*) FROM efhc_core.payment_intents"))).scalar_one()
        assert int(cnt) == 2

    await engine.dispose()
