from __future__ import annotations

import os

import pytest
from sqlalchemy import text

from tests.payment_intents_testkit import (
    ensure_deposit_package,
    ensure_payment_owner,
    reload_payment_service_postgres,
)

pytest.importorskip("sqlalchemy")


@pytest.mark.asyncio
async def test_two_intents_same_user_no_unique_payload_conflict(
    db_session,
) -> None:
    ps = reload_payment_service_postgres()

    await ensure_payment_owner(db_session, tg_id=9001)
    await ensure_deposit_package(db_session, package_id=1)

    r1 = await ps.create_intent_deposit_by_package(
        db_session,
        tg_id=9001,
        idempotency_key="k1",
        package_id=1,
    )
    r2 = await ps.create_intent_deposit_by_package(
        db_session,
        tg_id=9001,
        idempotency_key="k2",
        package_id=1,
    )

    assert r1["intent_id"] != r2["intent_id"]
    assert r1["payload"] != r2["payload"]
    assert r1["payload"].startswith("EFHC:deposit_efhc:")
    assert r2["payload"].startswith("EFHC:deposit_efhc:")

    cnt = (
        await db_session.execute(
            text("SELECT COUNT(*) FROM efhc_core.payment_intents")
        )
    ).scalar_one()
    assert int(cnt) == 2


@pytest.mark.asyncio
async def test_two_shop_external_intents_same_user_no_conflict(
    db_session,
) -> None:
    ps = reload_payment_service_postgres()

    await ensure_payment_owner(db_session, tg_id=9002)

    to_addr = os.getenv("TON_MAIN_WALLET") or "EQ_RECEIVER"

    r1 = await ps.create_intent_shop_external(
        db_session,
        tg_id=9002,
        idempotency_key="k1",
        asset="TON",
        amount_asset_d8=ps.d8("2.00000000"),
        to_address=to_addr,
    )
    r2 = await ps.create_intent_shop_external(
        db_session,
        tg_id=9002,
        idempotency_key="k2",
        asset="TON",
        amount_asset_d8=ps.d8("2.00000000"),
        to_address=to_addr,
    )

    assert r1["intent_id"] != r2["intent_id"]
    assert r1["payload"] != r2["payload"]

    cnt = (
        await db_session.execute(
            text(
                "SELECT COUNT(*) FROM efhc_core.payment_intents "
                "WHERE tg_id=9002"
            )
        )
    ).scalar_one()
    assert int(cnt) == 2
