from __future__ import annotations

import importlib
import os

import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import text


def _reload_payment_service() -> object:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    os.environ["DB_SCHEMA_ADMIN"] = "efhc_admin"
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.payment_intents_service as ps

    return importlib.reload(ps)


async def _ensure_deposit_package(db, *, package_id: int) -> None:
    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.shop_items (",
                    "  id, sku, title, description,",
                    "  quantity_efhc, is_active, extra",
                    ") VALUES (",
                    "  :id, :sku, :title, NULL,",
                    "  :qty, true, CAST(:extra AS jsonb)",
                    ")",
                    "ON CONFLICT (id) DO NOTHING",
                ]
            )
        ),
        {
            "id": int(package_id),
            "sku": f"EFHC_PACK_{int(package_id)}",
            "title": "EFHC Deposit Package",
            "qty": "10.00000000",
            "extra": '{"asset":"TON","price_asset_d8":"1.0"}',
        },
    )
    await db.commit()


@pytest.mark.asyncio
async def test_two_intents_same_user_no_unique_payload_conflict(
    db_session,
) -> None:
    ps = _reload_payment_service()

    await _ensure_deposit_package(db_session, package_id=1)

    r1 = await ps.create_intent_deposit_by_package(
        db_session,
        tg_id=9001,
        idempotency_key="k1",
        package_id=1,
    )
    r2 = await ps.create_intent_deposit_by_package(
        db_session,
        tg_id=9001,
        idempotency_key="k2",
        package_id=1,
    )

    assert r1["intent_id"] != r2["intent_id"]
    assert r1["payload"] != r2["payload"]
    assert r1["payload"].startswith("EFHC:deposit_efhc:")
    assert r2["payload"].startswith("EFHC:deposit_efhc:")

    cnt = (
        await db_session.execute(
            text("SELECT COUNT(*) FROM efhc_core.payment_intents")
        )
    ).scalar_one()
    assert int(cnt) == 2


@pytest.mark.asyncio
async def test_two_shop_external_intents_same_user_no_conflict(
    db_session,
) -> None:
    ps = _reload_payment_service()

    to_addr = os.getenv("TON_MAIN_WALLET") or "EQ_RECEIVER"

    r1 = await ps.create_intent_shop_external(
        db_session,
        tg_id=9002,
        idempotency_key="k1",
        asset="TON",
        amount_asset_d8=ps.d8("2.00000000"),
        to_address=to_addr,
    )
    r2 = await ps.create_intent_shop_external(
        db_session,
        tg_id=9002,
        idempotency_key="k2",
        asset="TON",
        amount_asset_d8=ps.d8("2.00000000"),
        to_address=to_addr,
    )

    assert r1["intent_id"] != r2["intent_id"]
    assert r1["payload"] != r2["payload"]

    cnt = (
        await db_session.execute(
            text(
                "SELECT COUNT(*) FROM efhc_core.payment_intents "
                "WHERE tg_id=9002"
            )
        )
    ).scalar_one()
    assert int(cnt) == 2