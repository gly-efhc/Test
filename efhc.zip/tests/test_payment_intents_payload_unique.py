from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timezone

import pytest


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_intents_schema(db_url: str) -> None:
    engine = create_async_engine(
        db_url,
        future=True,
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        # admin schema (SQLite attach) for efhc_admin.efhc_sale_packages
        await conn.execute(
            text("ATTACH DATABASE ':memory:' AS efhc_admin")
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS
                    efhc_admin.efhc_sale_packages (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    asset TEXT NOT NULL,
                    price_asset_d8 NUMERIC NOT NULL,
                    efhc_amount_d8 NUMERIC NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS efhc_core.payment_intents (
                    id INTEGER PRIMARY KEY,
                    tg_id INTEGER NOT NULL,
                    purpose TEXT NOT NULL,
                    package_id INTEGER,
                    asset TEXT NOT NULL,
                    amount_asset_d8 NUMERIC NOT NULL,
                    efhc_amount_d8 NUMERIC,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    to_address TEXT NOT NULL,
                    external_tx_hash TEXT,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
                    expires_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
                    UNIQUE (tg_id, purpose, idempotency_key),
                    UNIQUE (payload)
                )
                """
            )
        )

        await conn.execute(
            text(
                """
                INSERT INTO efhc_admin.efhc_sale_packages (
                    id, title, asset, price_asset_d8, efhc_amount_d8,
                    is_active
                ) VALUES (1, 'P1', 'TON', 1.00000000, 100.00000000, 1)
                """
            )
        )

    await engine.dispose()


def _reload_payment_service_for_sqlite() -> object:
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["TON_MAIN_WALLET"] = (
        "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"
    )
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.payment_intents_service as ps

    return importlib.reload(ps)


@pytest.mark.asyncio
async def test_two_intents_same_user_no_unique_payload_conflict(
    ) -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = f"sqlite+aiosqlite:///{td}/intents.sqlite"
        await _init_sqlite_intents_schema(db_url)

        ps = _reload_payment_service_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with Session() as db:
            r1 = await ps.create_intent_deposit_by_package(
                db,
                tg_id=9001,
                idempotency_key="k1",
                package_id=1,
            )
            r2 = await ps.create_intent_deposit_by_package(
                db,
                tg_id=9001,
                idempotency_key="k2",
                package_id=1,
            )

            assert r1["intent_id"] != r2["intent_id"]
            assert r1["payload"] != r2["payload"]
            assert r1["payload"].startswith("EFHC:deposit_efhc:")
            assert r2["payload"].startswith("EFHC:deposit_efhc:")

            cnt = (await db.execute(
                text("SELECT COUNT(*) FROM efhc_core.payment_intents")
            )).scalar_one()
            assert int(cnt) == 2

        await engine.dispose()


@pytest.mark.asyncio
async def test_two_shop_external_intents_same_user_no_conflict(
    ) -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = f"sqlite+aiosqlite:///{td}/intents2.sqlite"
        await _init_sqlite_intents_schema(db_url)

        ps = _reload_payment_service_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with Session() as db:
            r1 = await ps.create_intent_shop_external(
                db,
                tg_id=9002,
                idempotency_key="k1",
                asset="TON",
                amount_asset_d8=ps.d8("2.00000000"),
                to_address=os.environ["TON_MAIN_WALLET"],
            )
            r2 = await ps.create_intent_shop_external(
                db,
                tg_id=9002,
                idempotency_key="k2",
                asset="TON",
                amount_asset_d8=ps.d8("3.00000000"),
                to_address=os.environ["TON_MAIN_WALLET"],
            )

            assert r1["intent_id"] != r2["intent_id"]
            assert r1["payload"] != r2["payload"]
            assert r1["payload"].startswith("EFHC:shop_external:")
            assert r2["payload"].startswith("EFHC:shop_external:")

            cnt = (await db.execute(
                text(
                    "SELECT COUNT(*) FROM efhc_core.payment_intents "
                    "WHERE purpose='shop_external'"
                )
            )).scalar_one()
            assert int(cnt) == 2

        await engine.dispose()
