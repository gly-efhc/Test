from __future__ import annotations

import importlib
import os

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_panels_service_for_postgres():
    os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    from backend.app.services import panels_service
    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_global_id_grows_across_users() -> None:
    panels_service = _reload_panels_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(panels_service, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    tg_a = 5001
    tg_b = 5002

    async with Session() as db:
        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.users (tg_id, main_balance, bonus_balance)
                VALUES (:a, '200.00000000', '0.00000000'),
                       (:b, '200.00000000', '0.00000000')
                """
            ),
            {"a": tg_a, "b": tg_b},
        )
        await db.commit()

    async with Session() as db:
        out_a = await panels_service.create_panel_for_user(
            db,
            tg_id=tg_a,
            idempotency_key="gid-a",
        )
        out_b = await panels_service.create_panel_for_user(
            db,
            tg_id=tg_b,
            idempotency_key="gid-b",
        )
        await db.commit()

        assert out_a["id"] != out_b["id"]
        assert out_a["public_id"].startswith("ID")
        assert out_b["public_id"].startswith("ID")
        assert int(out_b["id"]) > int(out_a["id"])

    await engine.dispose()
