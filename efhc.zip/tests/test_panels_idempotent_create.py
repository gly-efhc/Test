from __future__ import annotations

import importlib

import pytest
from sqlalchemy import text


def _reload_panels_service():
    # Reload panels service to pick up canon env
    # (efhc_core/efhc_admin) from conftest
    from app.core import config_core
    config_core.get_settings.cache_clear()
    import app.services.panels_service as ps
    ps = importlib.reload(ps)
    return ps


@pytest.mark.asyncio
async def test_panels_idempotent_create(db_session, db_clean) -> None:
    ps = _reload_panels_service()
    tg_id = 3004

    await db_session.execute(
        text(
            'INSERT INTO efhc_core.users (tg_id, main_balance, '
            'bonus_balance) VALUES (:tg, 500.0, 0.0)'
        ),
        {"tg": tg_id},
    )
    await db_session.commit()

    p1 = await ps.create_panel_for_user(db_session, tg_id=tg_id, idempotency_key="same-key")
    await db_session.commit()
    p2 = await ps.create_panel_for_user(db_session, tg_id=tg_id, idempotency_key="same-key")
    await db_session.commit()

    assert int(p1["id"]) == int(p2["id"])
