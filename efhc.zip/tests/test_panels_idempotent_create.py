from __future__ import annotations

import asyncio
import importlib
import os
from datetime import datetime, timezone

import pytest

def _get_async_db_url() -> str:
    db_url = os.getenv("ASYNC_DATABASE_URL") or os.getenv("DATABASE_URL")
    if not db_url:
        pytest.skip("ASYNC_DATABASE_URL/DATABASE_URL required", allow_module_level=True)
    if db_url.startswith("postgresql+psycopg://"):
        db_url = "postgresql+asyncpg://" + db_url[len("postgresql+psycopg://"):]
    if db_url.startswith("postgresql://"):
        db_url = "postgresql+asyncpg://" + db_url[len("postgresql://"):]
    if db_url.startswith("postgres://"):
        db_url = "postgresql+asyncpg://" + db_url[len("postgres://"):]
    if db_url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return db_url
    return db_url


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    # SQLite is forbidden in Postgres-only CI canon
    pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return


def _reload_panels_service_for_sqlite():
        os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core

    importlib.reload(config_core)
    from backend.app.services import panels_service

    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_idempotency_create_same_key_same_panel() -> None:
    panels_service = _reload_panels_service_for_sqlite()

    fd, path = tempfile.mkstemp(prefix="efhc_panels_", suffix=".db")
    os.close(fd)
    db_url = _get_async_db_url()

    try:
        await _init_sqlite_schema(db_url)

        engine = create_async_engine(
            db_url,
            future=True,
                    )
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        tg_id = 1001
        idem = "panels-test-idem-1"

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO efhc_core.users (tg_id, main_balance, bonus_balance)
                    VALUES (:tg_id, 200.0, 0.0)
                    """
                ),
                {"tg_id": tg_id},
            )
            await db.commit()

        async with Session() as db:
            out1 = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_id,
                idempotency_key=idem,
            )
            await db.commit()

        async with Session() as db:
            out2 = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_id,
                idempotency_key=idem,
            )
            await db.commit()

            assert out1["id"] == out2["id"]
            assert out1["public_id"] == out2["public_id"]

            r = await db.execute(
                text("SELECT COUNT(*) FROM efhc_core.panels WHERE tg_id=:tg"),
                {"tg": tg_id},
            )
            assert int(r.scalar() or 0) == 1

            bal = await db.execute(
                text(
                    """
                    SELECT main_balance, bonus_balance
                    FROM efhc_core.users
                    WHERE tg_id=:tg
                    """
                ),
                {"tg": tg_id},
            )
            row = bal.fetchone()
            assert row is not None
            # списание должно произойти один раз на сумму 100
            assert float(row[0]) == pytest.approx(100.0)
            assert float(row[1]) == pytest.approx(0.0)

        await engine.dispose()
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
