from __future__ import annotations

import pytest

from tests.panels_testkit import (
    reload_panels_service,
    seed_user_with_balances,
)

pytestmark = pytest.mark.asyncio


async def test_panels_idempotent_create(db_session, db_clean) -> None:
    ps = reload_panels_service()
    tg_id = 3004

    await seed_user_with_balances(
        db_session,
        tg_id=tg_id,
        main_balance="500.0",
    )

    p1 = await ps.create_panel_for_user(
        db_session, tg_id=tg_id, idempotency_key="same-key"
    )
    await db_session.commit()
    p2 = await ps.create_panel_for_user(
        db_session, tg_id=tg_id, idempotency_key="same-key"
    )
    await db_session.commit()

    assert int(p1["id"]) == int(p2["id"])
