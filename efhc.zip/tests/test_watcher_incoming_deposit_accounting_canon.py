from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_same_tx_hash_replay_is_idempotent_noop() -> None:
    text = _read("docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md")
    assert "same transaction identity is an idempotent no-op" in text


def test_different_tx_hash_same_payload_is_new_deposit() -> None:
    text = _read("docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md")
    assert "payload, comment, or intent matches" in text
    assert "new incoming deposit" in text


def test_watcher_records_each_unique_incoming_transaction() -> None:
    text = _read("docs/SSOT/WATCHER_ACCOUNTING_SSOT.md")
    assert "Different `tx_hash` is a new incoming deposit" in text


def test_watcher_does_not_silently_drop_second_payment() -> None:
    doc = _read("docs/SSOT/WATCHER_ACCOUNTING_SSOT.md")
    code = _read("backend/app/services/payment_reconciliation_service.py")
    assert "silently drop a later different `tx_hash`" in doc
    assert "Do not silently drop" in code


def test_watcher_accounting_canon_docs_exist() -> None:
    assert (ROOT / "docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md").exists()
    assert (ROOT / "docs/SSOT/WATCHER_ACCOUNTING_SSOT.md").exists()


def test_kernel_links_watcher_accounting_canon() -> None:
    text = _read("KERNEL.md")
    assert "WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md" in text


def test_map_element_links_watcher_accounting_canon() -> None:
    text = _read("map_element.md")
    assert "WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md" in text
