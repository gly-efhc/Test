from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_same_tx_hash_replay_is_idempotent_noop() -> None:
    text = _read("docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md")
    assert "Повтор того же `tx_hash` является идемпотентным read-through" in text


def test_другой_tx_hash_видим_но_не_переиспользует_закрытый_intent() -> None:
    text = _read("docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md")
    assert "Другой `tx_hash` является другой on-chain транзакцией" in text
    assert "новый живой" in text


def test_watcher_records_each_unique_incoming_transaction() -> None:
    text = _read("docs/SSOT/WATCHER_ACCOUNTING_SSOT.md")
    assert "Другой `tx_hash` является отдельной on-chain транзакцией" in text


def test_watcher_does_not_silently_drop_second_payment() -> None:
    doc = _read("docs/SSOT/WATCHER_ACCOUNTING_SSOT.md")
    code = _read("backend/app/services/payment_reconciliation_service.py")
    assert "не должны молча терять второй реальный incoming" in doc
    assert '"INTENT_NOT_PENDING"' in code


def test_watcher_accounting_canon_docs_exist() -> None:
    assert (ROOT / "docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md").exists()
    assert (ROOT / "docs/SSOT/WATCHER_ACCOUNTING_SSOT.md").exists()


def test_kernel_links_watcher_accounting_canon() -> None:
    text = _read("KERNEL.md")
    assert "WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md" in text


