from __future__ import annotations

import importlib
import os
from datetime import datetime, timezone
from decimal import Decimal

import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_payment_service_for_postgres() -> object:
    if (os.getenv("DATABASE_URL") or "").lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden by CANON")
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()
    import backend.app.services.payment_intents_service as ps
    return importlib.reload(ps)


async def _ensure_sale_package(db: AsyncSession, package_id: int = 1) -> None:
    await db.execute(
        text(
            """
            INSERT INTO efhc_admin.efhc_sale_packages
                (id, title, asset, price_asset_d8, efhc_amount_d8, is_active, created_at, updated_at)
            VALUES
                (:id, :title, :asset, :price, :amount, true, :now, :now)
            ON CONFLICT (id) DO UPDATE SET
                title = EXCLUDED.title,
                asset = EXCLUDED.asset,
                price_asset_d8 = EXCLUDED.price_asset_d8,
                efhc_amount_d8 = EXCLUDED.efhc_amount_d8,
                is_active = EXCLUDED.is_active,
                updated_at = EXCLUDED.updated_at
            """
        ),
        {
            "id": package_id,
            "title": "Package #1",
            "asset": "USDT",
            "price": "100000000",
            "amount": "100000000",
            "now": datetime.now(timezone.utc),
        },
    )
    await db.commit()


@pytest.mark.asyncio
async def test_payment_intent_usdt_tx_and_confirm_smoke() -> None:
    ps = _reload_payment_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)

    core_schema = get_postgres_schema_default()
    await truncate_schema_all_tables(engine, core_schema)
    await truncate_schema_all_tables(engine, "efhc_admin")

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with Session() as db:
        await _ensure_sale_package(db, package_id=1)

        intent = await ps.create_intent_deposit_by_package(
            db,
            tg_id=9101,
            idempotency_key="k1",
            package_id=1,
        )
        assert intent["payload"].startswith("EFHC:deposit_efhc:")

        # Simulate linking a USDT tx and confirm (minimal fields; service should handle)
        tx_hash = "0x" + "12" * 32
        await db.execute(
            text(
                """
                UPDATE efhc_core.payment_intents
                   SET asset = 'USDT',
                       amount_asset_d8 = :amt,
                       tx_hash = :tx,
                       status = 'PENDING'
                 WHERE id = :id
                """
            ),
            {"amt": "100000000", "tx": tx_hash, "id": intent["intent_id"]},
        )
        await db.commit()

        confirmed = await ps.confirm_intent(
            db,
            tg_id=9101,
            intent_id=intent["intent_id"],
            confirmed_asset_amount=Decimal("1"),
            confirmed_tx_hash=tx_hash,
        )
        assert confirmed["status"] in ("CONFIRMED", "PAID")

        cnt = (await db.execute(text("SELECT COUNT(*) FROM efhc_core.payment_intents"))).scalar_one()
        assert int(cnt) == 1

    await engine.dispose()
