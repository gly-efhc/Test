# ruff: noqa: E402
from __future__ import annotations

import contextlib
import importlib
import os
import tempfile
from datetime import UTC, datetime
from decimal import Decimal

import pytest

pytest.importorskip("sqlalchemy")


from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.payment_intents_testkit import (
    ensure_payment_owner,
    get_async_db_url,
)


async def __init__sqlite_payment_intents(db_url: str) -> None:
    if not db_url.lower().startswith("sqlite"):
        return
    engine = create_async_engine(
        db_url,
        future=True,
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        with contextlib.suppress(Exception):
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(UTC).isoformat(),
            )

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text("""
                CREATE TABLE IF NOT EXISTS efhc_core.payment_intents (
                    id INTEGER PRIMARY KEY,
                    tg_id INTEGER NOT NULL,
                    purpose TEXT NOT NULL,
                    package_id INTEGER,
                    asset TEXT NOT NULL,
                    amount_asset_d8 TEXT NOT NULL,
                    efhc_amount_d8 TEXT,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    payload TEXT NOT NULL UNIQUE,
                    to_address TEXT NOT NULL,
                    external_tx_hash TEXT,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """)
        )
        await conn.execute(
            text("""
                CREATE TABLE IF NOT EXISTS efhc_core.tx_hash_locks (
                    id INTEGER PRIMARY KEY,
                    tx_hash TEXT NOT NULL UNIQUE,
                    purpose TEXT NOT NULL,
                    intent_id INTEGER NOT NULL,
                    order_id INTEGER,
                    tg_id INTEGER NOT NULL,
                    created_at TEXT NOT NULL
                )
                """)
        )

    await engine.dispose()


async def _restore_owner_control_for_postgresql(conn, db_url: str) -> None:
    """Восстановить canonical control после общего test cleanup."""

    if not db_url.lower().startswith("postgresql"):
        return
    await conn.execute(
        text(
            """
            INSERT INTO efhc_core.identity_migration_control (
                singleton_id, dual_write_enabled, shadow_read_enabled,
                legacy_authoritative
            ) VALUES (1, TRUE, TRUE, TRUE)
            ON CONFLICT (singleton_id) DO UPDATE SET
                dual_write_enabled = TRUE,
                shadow_read_enabled = TRUE,
                legacy_authoritative = TRUE,
                updated_at = now()
            """
        )
    )
    await conn.execute(
        text(
            """
            INSERT INTO efhc_core.users (tg_id)
            VALUES (9001)
            ON CONFLICT (tg_id) DO NOTHING
            """
        )
    )


def _reload_modules_for_sqlite() -> tuple[object, object]:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    os.environ["USDT_JETTON_MASTER_ADDRESS"] = "EQ_USDT_MASTER"
    os.environ["PAYMENTS_RECEIVER_ADDRESS"] = "EQ_RECEIVER"
    from app.core import config_core

    config_core.get_settings.cache_clear()

    import app.services.payment_intents_service as pis
    import app.services.watcher_service as ws

    return importlib.reload(pis), importlib.reload(ws)


@pytest.mark.asyncio
async def test_usdt_tx_uses_live_tep74_metadata() -> None:
    pis, _ws = _reload_modules_for_sqlite()
    assert pis.get_usdt_checkout_mode() == "tep74_live"
    tx = pis.build_tonconnect_tx(
        to_address="EQ_RECEIVER",
        amount_asset_d8=Decimal("12.34000000"),
        payload="EFHC:deposit_efhc:1:100",
        asset="USDT",
    )
    assert tx is None
    metadata = pis.build_transport_meta(
        asset="USDT",
        payload="EFHC:deposit_efhc:1:100",
    )
    assert metadata["tonconnect_transport_kind"] == "jetton_transfer"
    assert metadata["jetton_decimals"] == 6
    assert metadata["recipient_strategy"] == "owner_derived_wallet"


def test_watcher_parses_intent_payload_as_substring_for_usdt() -> None:
    _pis, ws = _reload_modules_for_sqlite()
    memo = "JETTON_TRANSFER|FORWARD_PAYLOAD=EFHC:deposit_efhc:7:9001"
    p = ws._parse_intent_payload(memo)
    assert p is not None
    assert p["payload"] == "EFHC:deposit_efhc:7:9001"


@pytest.mark.asyncio
async def test_watcher_confirm_usdt_idempotent_and__main__credit_once(
    monkeypatch,
    db_clean,
) -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await __init__sqlite_payment_intents(db_url)
        _pis, ws = _reload_modules_for_sqlite()

        engine = create_async_engine(
            db_url,
            future=True,
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        calls: list[tuple[int, str]] = []

        async def _credit_user_from_bank(
            db,
            tg_id: int,
            amount_efhc,
            reason: str,
            idempotency_key: str,
        ) -> None:
            calls.append((tg_id, idempotency_key))

        monkeypatch.setattr(
            ws, "credit_user_from_bank", _credit_user_from_bank
        )

        payload = "EFHC:deposit_efhc:7:9001"
        async with Session() as db:
            if db_url.lower().startswith("postgresql"):
                await ensure_payment_owner(db, tg_id=9001)
            await db.execute(
                text("""
                    INSERT INTO efhc_core.payment_intents (
                        id, tg_id, purpose, package_id, asset,
                        amount_asset_d8, efhc_amount_d8, status,
                        idempotency_key, payload, to_address,
                        external_tx_hash,
                        created_at,
                        expires_at,
                        updated_at
                    ) VALUES (
                        7, 9001, 'deposit_efhc', 1, 'USDT',
                        '12.34000000', '50.00000000', 'PENDING',
                        'k1', :p, 'EQ_RECEIVER',
                        NULL, now(), now(), now()
                    )
                    """),
                {"p": payload},
            )
            await db.commit()

            st1 = await ws._confirm_payment_intent(
                db,
                intent_id=7,
                tg_id=9001,
                purpose="deposit_efhc",
                payload=payload,
                tx_hash="tx1",
                amount_asset=Decimal("12.34000000"),
                asset="USDT",
                to_address="EQ_RECEIVER",
            )
            st2 = await ws._confirm_payment_intent(
                db,
                intent_id=7,
                tg_id=9001,
                purpose="deposit_efhc",
                payload=payload,
                tx_hash="tx1",
                amount_asset=Decimal("12.34000000"),
                asset="USDT",
                to_address="EQ_RECEIVER",
            )

            assert st1 == ws.STATUS_CREDITED
            assert st2 == ws.STATUS_CREDITED
            assert len(calls) == 1
            assert calls[0][0] == 9001

        await engine.dispose()


@pytest.mark.asyncio
async def test_process_incoming_tx_unknown_jetton_intent_goes_pending_manual(
    db_session,
    monkeypatch,
) -> None:
    _pis, ws = _reload_modules_for_sqlite()
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    async def _should_not_confirm(*args, **kwargs):
        raise AssertionError(
            "_confirm_payment_intent must not be called"
        )

    monkeypatch.setattr(
        ws, "_confirm_payment_intent", _should_not_confirm
    )

    class _Tx:
        tx_hash = "tx_unknown_jetton"
        from_address = "EQ_FROM"
        to_address = "EQ_RECEIVER"
        amount = Decimal("0")
        amount_asset = Decimal("1234567")
        asset = "JETTON"
        jetton_master = "EQ_UNKNOWN"
        memo = "EFHC:deposit_efhc:77:9001"
        utime = 1

    st = await ws.process_incoming_tx(db_session, _Tx())
    assert st == ws.STATUS_PENDING_MANUAL

    from sqlalchemy import text

    r = await db_session.execute(
        text(
            "SELECT COUNT(1) FROM efhc_core.unmatched_incoming "
            "WHERE tx_hash = 'tx_unknown_jetton'"
        )
    )
    assert int(r.scalar() or 0) == 1


@pytest.mark.asyncio
async def test_process_incoming_tx_usdt_jetton_uses_d6_amount_for_confirm(
    db_session,
    monkeypatch,
) -> None:
    _pis, ws = _reload_modules_for_sqlite()
    monkeypatch.setattr(ws, "MAIN_TON_WALLET", "EQ_RECEIVER")

    captured: dict[str, object] = {}

    async def _fake_confirm(
        db,
        *,
        intent_id: int,
        tg_id: int,
        purpose: str,
        payload: str,
        tx_hash: str,
        amount_asset,
        asset: str,
        to_address: str,
    ) -> str:
        captured["intent_id"] = intent_id
        captured["tg_id"] = tg_id
        captured["purpose"] = purpose
        captured["payload"] = payload
        captured["tx_hash"] = tx_hash
        captured["amount_asset"] = amount_asset
        captured["asset"] = asset
        captured["to_address"] = to_address
        return ws.STATUS_CREDITED

    monkeypatch.setattr(ws, "_confirm_payment_intent", _fake_confirm)

    class _Tx:
        tx_hash = "tx_usdt_jetton"
        from_address = "EQ_FROM"
        to_address = "EQ_RECEIVER"
        amount = Decimal("0")
        amount_asset = Decimal("1234567")
        asset = "JETTON"
        jetton_master = "EQ_USDT_MASTER"
        memo = "prefix EFHC:deposit_efhc:7:9001 suffix"
        utime = 1

    st = await ws.process_incoming_tx(db_session, _Tx())
    assert st == ws.STATUS_CREDITED
    assert captured["asset"] == "USDT"
    assert str(captured["amount_asset"]) == "1.23456700"
    assert captured["payload"] == "EFHC:deposit_efhc:7:9001"


@pytest.mark.asyncio
async def test_watcher_confirm_shop_external_without_order_is_fail_closed() -> (
    None
):
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await __init__sqlite_payment_intents(db_url)
        _pis, ws = _reload_modules_for_sqlite()

        engine = create_async_engine(
            db_url,
            future=True,
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with engine.begin() as conn:
            await _restore_owner_control_for_postgresql(conn, db_url)
            await conn.execute(
                text("""
                CREATE TABLE IF NOT EXISTS efhc_core.shop_orders (
                    id INTEGER PRIMARY KEY,
                    tg_id INTEGER NOT NULL,
                    type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    quantity_efhc TEXT,
                    expected_amount TEXT,
                    tx_hash TEXT,
                    memo TEXT,
                    idempotency_key TEXT,
                    extra JSONB,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    updated_at TIMESTAMPTZ DEFAULT NOW(),
                    paid_at TIMESTAMPTZ,
                    fulfilled_at TIMESTAMPTZ
                )
                """)
            )

        payload = "EFHC:shop_external:17:9001"
        async with Session() as db:
            await db.execute(
                text("""
                    INSERT INTO efhc_core.payment_intents (
                        id, tg_id, purpose, package_id, asset,
                        amount_asset_d8, efhc_amount_d8, status,
                        idempotency_key, payload, to_address,
                        external_tx_hash, created_at, expires_at, updated_at
                    ) VALUES (
                        17, 9001, 'shop_external', 0, 'TON',
                        '12.34000000', '0.00000000', 'PENDING',
                        'k_shop', :p, 'EQ_RECEIVER',
                        NULL, now(), now(), now()
                    )
                    """),
                {"p": payload},
            )
            await db.commit()

            st = await ws._confirm_payment_intent(
                db,
                intent_id=17,
                tg_id=9001,
                purpose="shop_external",
                payload=payload,
                tx_hash="tx_shop_missing_order",
                amount_asset=Decimal("12.34000000"),
                asset="TON",
                to_address="EQ_RECEIVER",
            )
            assert st == ws.STATUS_PENDING_MANUAL

            row = (
                await db.execute(
                    text("""
                        SELECT status, external_tx_hash
                          FROM efhc_core.payment_intents
                         WHERE id = 17
                    """)
                )
            ).first()
            assert row is not None
            assert str(row[0]) == "PENDING"
            assert row[1] is None

        await engine.dispose()


@pytest.mark.asyncio
async def test_watcher_confirm_shop_external_with_order_marks_paid_auto(
    monkeypatch,
) -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await __init__sqlite_payment_intents(db_url)
        _pis, ws = _reload_modules_for_sqlite()

        engine = create_async_engine(
            db_url,
            future=True,
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with engine.begin() as conn:
            await _restore_owner_control_for_postgresql(conn, db_url)
            await conn.execute(
                text("""
                CREATE TABLE IF NOT EXISTS efhc_core.shop_orders (
                    id INTEGER PRIMARY KEY,
                    tg_id INTEGER NOT NULL,
                    type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    quantity_efhc TEXT,
                    expected_amount TEXT,
                    tx_hash TEXT,
                    memo TEXT,
                    idempotency_key TEXT,
                    extra JSONB,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    updated_at TIMESTAMPTZ DEFAULT NOW(),
                    paid_at TIMESTAMPTZ,
                    fulfilled_at TIMESTAMPTZ
                )
                """)
            )

        calls = []

        async def _credit_user_from_bank(
            db,
            tg_id: int,
            amount_efhc,
            reason: str,
            idempotency_key: str,
        ) -> None:
            calls.append(
                (tg_id, str(amount_efhc), reason, idempotency_key)
            )

        from app.services import wallets_service as wallets_ws

        monkeypatch.setattr(
            wallets_ws, "credit_user_from_bank", _credit_user_from_bank
        )

        payload = "EFHC:shop_external:21:9001"
        async with Session() as db:
            await db.execute(
                text("""
                INSERT INTO efhc_core.payment_intents (
                    id, tg_id, purpose, package_id, asset,
                    amount_asset_d8, efhc_amount_d8, status,
                    idempotency_key, payload, to_address,
                    external_tx_hash, created_at, expires_at, updated_at
                ) VALUES (
                    21, 9001, 'shop_external', 0, 'TON',
                    '12.34000000', '0.00000000', 'PENDING',
                    'k_shop_ok', :p, 'EQ_RECEIVER',
                    NULL, now(), now(), now()
                )
            """),
                {"p": payload},
            )
            await db.execute(
                text("""
                INSERT INTO efhc_core.shop_orders (
                    id, tg_id, type, status, quantity_efhc,
                    expected_amount, tx_hash, memo,
                    idempotency_key, extra
                ) VALUES (
                    1, 9001, 'EFHC', 'PENDING', '50.00000000',
                    '12.34000000', NULL, :p,
                    'shop-order-1', '{}'::jsonb
                )
            """),
                {"p": payload},
            )
            await db.commit()

            st = await ws._confirm_payment_intent(
                db,
                intent_id=21,
                tg_id=9001,
                purpose="shop_external",
                payload=payload,
                tx_hash="tx_shop_ok",
                amount_asset=Decimal("12.34000000"),
                asset="TON",
                to_address="EQ_RECEIVER",
            )
            assert st == ws.STATUS_PAID_AUTO
            row = (
                await db.execute(
                    text(
                        "SELECT status, external_tx_hash FROM efhc_"
                        "core.payment_intents WHERE id = 21"
                    )
                )
            ).first()
            assert row is not None
            assert str(row[0]) == "CONFIRMED"
            assert str(row[1]) == "tx_shop_ok"
            order = (
                await db.execute(
                    text(
                        "SELECT status, tx_hash FROM efhc_core.shop_"
                        "orders WHERE id = 1"
                    )
                )
            ).first()
            assert order is not None
            assert str(order[0]) == "PAID_AUTO"
            assert str(order[1]) == "tx_shop_ok"

        assert calls == [
            (
                9001,
                "50.00000000",
                "shop_external_efhc_package_confirm",
                "intent:21:shop_credit",
            )
        ]
        await engine.dispose()


@pytest.mark.asyncio
async def test_watcher_confirm_shop_external_rejects_non_exact_amount(
    monkeypatch,
) -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await __init__sqlite_payment_intents(db_url)
        _pis, ws = _reload_modules_for_sqlite()

        engine = create_async_engine(db_url, future=True)
        Session = sessionmaker(
            engine, expire_on_commit=False, class_=AsyncSession
        )

        async with engine.begin() as conn:
            await _restore_owner_control_for_postgresql(conn, db_url)
            await conn.execute(
                text("""
                CREATE TABLE IF NOT EXISTS efhc_core.shop_orders (
                    id INTEGER PRIMARY KEY,
                    tg_id INTEGER NOT NULL,
                    type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    quantity_efhc TEXT,
                    expected_amount TEXT,
                    tx_hash TEXT,
                    memo TEXT,
                    idempotency_key TEXT,
                    extra JSONB,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    updated_at TIMESTAMPTZ DEFAULT NOW(),
                    paid_at TIMESTAMPTZ,
                    fulfilled_at TIMESTAMPTZ
                )
            """)
            )

        async def _credit_user_from_bank(*args, **kwargs) -> None:
            raise AssertionError(
                "credit must not happen for non-exact amount"
            )

        from app.services import wallets_service as wallets_ws

        monkeypatch.setattr(
            wallets_ws, "credit_user_from_bank", _credit_user_from_bank
        )

        payload = "EFHC:shop_external:22:9001"
        extra = '{"sku":"EFHC50","item_type":"EFHC_PACKAGE","payment_method":"TON","canonical_memo":"SKU:EFHC|Q:50|TG:9001","intent_payload":"EFHC:shop_external:22:9001","payment_owner_tg_id":"9001"}'
        async with Session() as db:
            await db.execute(
                text("""
                INSERT INTO efhc_core.payment_intents (
                    id, tg_id, purpose, package_id, asset, amount_asset_d8,
                    efhc_amount_d8, status, idempotency_key, payload, to_address,
                    external_tx_hash, created_at, expires_at, updated_at
                ) VALUES (
                    22, 9001, 'shop_external', 0, 'TON', '12.34000000',
                    '0.00000000', 'PENDING', 'k_shop_exact', :p, 'EQ_RECEIVER',
                    NULL, now(), now(), now()
                )
            """),
                {"p": payload},
            )
            await db.execute(
                text("""
                INSERT INTO efhc_core.shop_orders (
                    id, tg_id, type, status, quantity_efhc, expected_amount,
                    tx_hash, memo, idempotency_key, extra
                ) VALUES (
                    2, 9001, 'EFHC', 'PENDING', '50.00000000', '12.34000000',
                    NULL, :p, 'shop-order-2', CAST(:extra AS JSONB)
                )
            """),
                {"p": payload, "extra": extra},
            )
            await db.commit()

            st = await ws._confirm_payment_intent(
                db,
                intent_id=22,
                tg_id=9001,
                purpose="shop_external",
                payload=payload,
                tx_hash="tx_shop_non_exact",
                amount_asset=Decimal("12.35000000"),
                asset="TON",
                to_address="EQ_RECEIVER",
            )
            assert st == ws.STATUS_ERROR_SYS
            row = (
                await db.execute(
                    text(
                        "SELECT status, external_tx_hash FROM efhc_"
                        "core.payment_intents WHERE id = 22"
                    )
                )
            ).first()
            assert row is not None
            assert str(row[0]) == "PENDING"
            assert row[1] is None

        await engine.dispose()
