from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timezone
from decimal import Decimal

import pytest



def _get_async_db_url() -> str:
    url = os.getenv("ASYNC_DATABASE_URL") or os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if not url:
        pytest.skip("DATABASE_URL/ASYNC_DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    if url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to asyncpg SQLAlchemy URL
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://"):]
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://"):]
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgresql+psycopg://"):
        return "postgresql+asyncpg://" + url[len("postgresql+psycopg://"):]
    return url

pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_payment_intents(db_url: str) -> None:
    if not db_url.lower().startswith("sqlite"):
        return
    engine = create_async_engine(
        db_url,
        future=True,

    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS efhc_core.payment_intents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    purpose TEXT NOT NULL,
                    package_id INTEGER,
                    asset TEXT NOT NULL,
                    amount_asset_d8 TEXT NOT NULL,
                    efhc_amount_d8 TEXT,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    payload TEXT NOT NULL UNIQUE,
                    to_address TEXT NOT NULL,
                    external_tx_hash TEXT,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
        )

    await engine.dispose()


def _reload_modules_for_sqlite() -> tuple[object, object]:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    os.environ["USDT_JETTON_MASTER_ADDRESS"] = "EQ_USDT_MASTER"
    os.environ["PAYMENTS_RECEIVER_ADDRESS"] = "EQ_RECEIVER"
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.payment_intents_service as pis
    import backend.app.services.watcher_service as ws

    return importlib.reload(pis), importlib.reload(ws)


@pytest.mark.asyncio
async def test_build_tonconnect_tx_usdt_not_supported_removed() -> None:
    pis, _ws = _reload_modules_for_sqlite()
    tx = pis.build_tonconnect_tx(
        to_address="EQ_RECEIVER",
        amount_asset_d8=Decimal("12.34000000"),
        payload="EFHC:deposit_efhc:1:100",
        asset="USDT",
    )
    assert isinstance(tx, dict)
    assert "messages" in tx
    assert tx["messages"][0]["address"] == "EQ_USDT_MASTER"
    assert "payload" in tx["messages"][0]


def test_watcher_parses_intent_payload_as_substring_for_usdt() -> None:
    _pis, ws = _reload_modules_for_sqlite()
    memo = "JETTON_TRANSFER|FORWARD_PAYLOAD=EFHC:deposit_efhc:7:9001"
    p = ws._parse_intent_payload(memo)
    assert p is not None
    assert p["payload"] == "EFHC:deposit_efhc:7:9001"


@pytest.mark.asyncio
async def test_watcher_confirm_usdt_idempotent_and_main_credit_once(
    monkeypatch,
) -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_payment_intents(db_url)
        _pis, ws = _reload_modules_for_sqlite()

        engine = create_async_engine(
            db_url,
            future=True,

        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        calls: list[tuple[int, str]] = []

        async def _credit_user_from_bank(
            db,
            tg_id: int,
            amount_efhc,
            reason: str,
            idempotency_key: str,
        ) -> None:
            calls.append((tg_id, idempotency_key))

        monkeypatch.setattr(ws, "credit_user_from_bank", _credit_user_from_bank)

        payload = "EFHC:deposit_efhc:7:9001"
        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO efhc_core.payment_intents (
                        id, tg_id, purpose, package_id, asset,
                        amount_asset_d8, efhc_amount_d8, status,
                        idempotency_key, payload, to_address,
                        external_tx_hash, created_at, expires_at, updated_at
                    ) VALUES (
                        7, 9001, 'deposit_efhc', 1, 'USDT',
                        '12.34000000', '50.00000000', 'PENDING',
                        'k1', :p, 'EQ_RECEIVER',
                        NULL, now(), now(), now()
                    )
                    """
                ),
                {"p": payload},
            )
            await db.commit()

            st1 = await ws._confirm_payment_intent(
                db,
                intent_id=7,
                tg_id=9001,
                purpose="deposit_efhc",
                payload=payload,
                tx_hash="tx1",
                amount_asset=Decimal("12.34000000"),
                asset="USDT",
                to_address="EQ_RECEIVER",
            )
            st2 = await ws._confirm_payment_intent(
                db,
                intent_id=7,
                tg_id=9001,
                purpose="deposit_efhc",
                payload=payload,
                tx_hash="tx1",
                amount_asset=Decimal("12.34000000"),
                asset="USDT",
                to_address="EQ_RECEIVER",
            )

            assert st1 == ws.STATUS_CREDITED
            assert st2 == ws.STATUS_CREDITED
            assert len(calls) == 1
            assert calls[0][0] == 9001

        await engine.dispose()