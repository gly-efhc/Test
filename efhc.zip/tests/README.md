# EFHC active tests

`tests/` содержит только действующие тесты. Устаревшие version-specific,
cycle-specific и одноразовые evidence-тесты удалены из Development HEAD и
сохраняются только во внешнем `EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`.
Pytest не зависит от этих historical bytes.

## Identity rules

- Business fixtures и service calls используют `global_id`.
- На Python/SQL internal boundary `global_id` может быть `int/BIGINT`.
- Во внешнем JSON, OpenAPI и TypeScript `global_id` всегда строка
  `^[0-9]{10}$`; `0000000000` запрещён.
- `tg_id` допустим только для Telegram authentication, update sender,
  provider mapping, Bot API delivery и provider metadata.
- Нельзя создавать фиктивную пару `global_id = tg_id`.

## Layers

- `architecture/` — постоянные fail-closed инварианты;
- `efhc_backend/` — unit/contract tests backend;
- `integration/` — PostgreSQL и межсервисные контракты;
- `frontend/e2e/` — route-backed browser tests;
- `healer/` — self-healing и delivery protocol;
- корень `tests/` — тематические service/runtime tests и testkits.

E2E evidence записывается через `EFHC_TEST_ARTIFACT_DIR`, а не в проект.
