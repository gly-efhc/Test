"""Static guards provider-neutral referral ownership."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_referral_sql_uses_global_owner_and_filter_before_order() -> None:
    service = read("backend/app/services/referral_service.py")
    sql = service.split('SQL_LIST_REFERRALS_GLOBAL = """', 1)[1].split(
        '"""', 1
    )[0]
    assert "rl.inviter_global_id = :inviter_global_id" in sql
    assert "ON u.global_id = ref.ref_global" in sql
    assert "ON ref.ref_global = p.global_id" in sql
    assert "u.global_id AS global_id" in sql
    assert "ref.activated_at IS NOT NULL" in sql
    assert "ref.activated_at IS NULL" in sql
    assert sql.index(":want_active") < sql.index("ORDER BY")
    assert "OFFSET" not in sql.upper()
    assert "LIMIT CAST(:fetch_limit AS INTEGER)" in sql
    assert "CAST(:cursor_ts AS TIMESTAMPTZ)" in sql
    assert "CAST(:cursor_id AS BIGINT)" in sql


def test_active_count_uses_global_owner_and_permanent_flag() -> None:
    service = read("backend/app/services/referral_service.py")
    block = service.split("async def _count_active_referrals", 1)[1].split(
        "# Канонические public имена", 1
    )[0]
    assert "ReferralLink.inviter_global_id" in block
    assert "ReferralLink.activated_at.isnot(None)" in block
    assert "ReferralLink.inviter_tg_id" not in block
    assert "efhc_core.panels" not in block


def test_referral_crud_cursor_is_global_id_only() -> None:
    crud = read("backend/app/crud/referrals_crud.py")
    assert "ReferralLink.inviter_global_id" in crud
    assert "ReferralLink.invitee_global_id.desc()" in crud
    assert '"invitee_global_id"' in crud
    assert "inviter_tg_id:" not in crud
    assert "invitee_tg_id:" not in crud


def test_user_routes_are_self_only() -> None:
    routes = read("backend/app/routes/referrals_routes.py")
    for path in (
        '"/stats/me"',
        '"/counters/me"',
        '"/active/me"',
        '"/inactive/me"',
    ):
        assert path in routes
    assert "get_nonfinancial_read_owner" in routes
    assert "child_global_id" in routes
    assert "owner_global_id" in routes
    assert "child_tg_id" not in routes


def test_bank_and_referral_concurrency_guards_are_present() -> None:
    referral = read("backend/app/services/referral_service.py")
    crud = read("backend/app/crud/referrals_crud.py")
    transactions = read("backend/app/models/transactions_models.py")
    assert ".with_for_update()" in crud
    assert "activate_referral(" in referral
    assert "REF_ACT_UNIT:G" in referral
    assert "REF_LVL:G" in referral
    assert 'name="uq_efhc_transfers_idem_key"' in transactions


def test_referral_physical_owner_is_global_id() -> None:
    model = read("backend/app/models/referral_models.py")
    assert "inviter_global_id: Mapped[int]" in model
    assert "invitee_global_id: Mapped[int]" in model
    assert "global_id: Mapped[int]" in model
    assert "users.tg_id" not in model
    assert "uq_referral_links_invitee_global_id" in model
    assert "ck_ref_links_global_not_self" in model


def test_crud_health_registry_keeps_referrals_green() -> None:
    from app.crud import health_check

    rows = {name: (ok, missing) for name, ok, missing in health_check()}
    assert rows["user"] == (True, [])
    assert rows["referrals"] == (True, [])


def test_referral_query_indexes_exist_in_orm_metadata() -> None:
    from app.models.referral_models import ReferralLink

    names = {index.name for index in ReferralLink.__table__.indexes}
    assert "ix_referral_links_inviter_created_invitee_global" in names
    assert "ix_efhc_core_referral_links_inviter_global_id" in names
    assert "ix_efhc_core_referral_links_invitee_global_id" in names
