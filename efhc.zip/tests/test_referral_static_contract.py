"""Static guards for referral TG-ID, security and transaction contracts."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_referral_sql_uses_telegram_ids_and_filter_before_order() -> None:
    service = read("backend/app/services/referral_service.py")
    for forbidden in (
        "p.tg_id = u.id",
        "p.tg_id = u.u_pk",
        "OR p.tg_id = u.id",
        "OR p.tg_id = users.id",
        "-фильтр активности",
        'SQL_BASE + "\\nAND',
    ):
        assert forbidden not in service
    sql = service.split('SQL_LIST_REFERRALS = """', 1)[1].split(
        '"""', 1
    )[0]
    assert "ON u.tg_id = ref.ref_tg" in sql
    assert "ON ref.ref_tg = p.tg_id" in sql
    assert "ref.activated_at IS NOT NULL" in sql
    assert "ref.activated_at IS NULL" in sql
    assert "panels_count, 0) > 0) AS is_active" not in sql
    assert sql.index(":want_active") < sql.index("ORDER BY")
    assert "OFFSET" not in sql.upper()
    assert "LIMIT CAST(:fetch_limit AS INTEGER)" in sql
    assert "CAST(:cursor_ts AS TIMESTAMPTZ)" in sql
    assert "CAST(:cursor_id AS BIGINT)" in sql
    assert "CAST(:want_active AS BOOLEAN)" in sql


def test_active_count_never_uses_internal_user_primary_key() -> None:
    service = read("backend/app/services/referral_service.py")
    block = service.split("async def _count_active_referrals", 1)[1].split(
        "def _compute_level_and_progress", 1
    )[0]
    assert "rl.activated_at IS NOT NULL" in block
    assert "efhc_core.panels" not in block
    assert "users.id" not in block
    assert "u.id" not in block
    assert "u_pk" not in block
    admin_users = read(
        "backend/app/services/admin/admin_users_service.py"
    )
    brief = admin_users.split(
        "async def _get_referrals_brief", 1
    )[1].split("class AdminUsersService", 1)[0]
    assert "ReferralLink.activated_at.isnot(None)" in brief
    assert "efhc_core.panels" not in brief
    assert ".ref_links" not in brief


def test_legacy_crud_has_no_removed_fields_and_stable_cursor() -> None:
    crud = read("backend/app/crud/referrals_crud.py")
    for forbidden in (
        "ReferralLink.is_active",
        "link.is_active",
        "ReferralLink.activation_bonus_efhc",
        "link.activation_bonus_efhc",
        '"after_id"',
    ):
        assert forbidden not in crud
    assert "ReferralLink.created_at.desc()" in crud
    assert "ReferralLink.invitee_tg_id.desc()" in crud
    assert '"invited_at"' in crud
    assert '"invitee_tg_id"' in crud


def test_user_routes_are_self_only_and_deprecated_routes_guarded() -> None:
    routes = read("backend/app/routes/referrals_routes.py")
    for path in (
        '"/stats/me"',
        '"/counters/me"',
        '"/active/me"',
        '"/inactive/me"',
    ):
        assert path in routes
    assert "get_nonfinancial_read_owner" in routes
    assert "NonFinancialReadOwner" in routes
    assert "_require_self_parent" in routes
    assert "status.HTTP_403_FORBIDDEN" in routes
    assert "X-EFHC-Deprecated-Route" in routes


def test_bank_and_referral_concurrency_guards_are_present() -> None:
    referral = read("backend/app/services/referral_service.py")
    referral_crud = read("backend/app/crud/referrals_crud.py")
    transactions = read("backend/app/models/transactions_models.py")
    panels = read("backend/app/services/panels_service.py")
    assert ".with_for_update()" in referral_crud
    assert "UPDATE efhc_core.referral_links" not in referral
    assert "activate_referral(" in referral
    assert "REF_ACT_UNIT:" in referral
    assert "REF_LVL:" in referral
    assert 'name="uq_efhc_transfers_idem_key"' in transactions
    assert "on_user_first_panel_activation" in panels
    assert "bank._tx_context" in panels
    tx_service = read("backend/app/services/transactions_service.py")
    nocommit = tx_service.split(
        "async def credit_user_bonus_from_bank_nocommit", 1
    )[1].split("async def debit_user_to_bank", 1)[0]
    assert nocommit.count("_find_log_by_idk") >= 2
    assert nocommit.index("_ensure_user_locked") < nocommit.rindex(
        "_find_log_by_idk"
    )


def test_referral_composite_index_and_observability_events_exist() -> None:
    model = read("backend/app/models/referral_models.py")
    service = read("backend/app/services/referral_service.py")
    registration = read(
        "backend/app/identity/account_registration.py"
    )
    assert "ix_referral_links_inviter_created_invitee" in model
    assert "referral_link_created" in registration
    for event in (
        "referral_activated",
        "referral_unit_bonus_awarded",
        "referral_level_bonus_awarded",
        "referral_bonus_duplicate_skipped",
        "referral_bonus_transaction_rolled_back",
        "referral_active_count_calculated",
    ):
        assert event in service


def test_crud_health_registry_has_no_removed_ensure_user() -> None:
    crud_init = read("backend/app/crud/__init__.py")
    assert '"ensure_user"' not in crud_init
    assert '"activate_referral"' in crud_init
    assert '"list_active_refs_cursor"' in crud_init
    assert "SYMBOLS_PRESENT" in crud_init
    assert "does not prove that a symbol is wired" in crud_init


def test_crud_health_check_keeps_user_and_referrals_green() -> None:
    from app.crud import health_check

    rows = {
        name: (ok, missing)
        for name, ok, missing in health_check()
    }
    assert rows["user"] == (True, [])
    assert rows["referrals"] == (True, [])


def test_referral_start_param_normalizer_is_internal_only() -> None:
    service = read("backend/app/services/referral_service.py")
    public_block = service.split("__all__ = [", 1)[1].split("]", 1)[0]
    assert '"normalize_referral_start_param"' not in public_block


def test_referral_query_indexes_exist_in_orm_metadata() -> None:
    from app.models.panels_models import Panel
    from app.models.referral_models import ReferralLink

    panel_indexes = {index.name for index in Panel.__table__.indexes}
    referral_indexes = {
        index.name for index in ReferralLink.__table__.indexes
    }
    assert "ix_efhc_core_panels_tg_id" in panel_indexes
    assert (
        "ix_referral_links_inviter_created_invitee"
        in referral_indexes
    )
    assert "ix_efhc_core_referral_links_invitee_tg_id" in referral_indexes
