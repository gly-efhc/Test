from __future__ import annotations

import xml.etree.ElementTree as ET

from ops.ci_checks.assert_pytest_junit import _totals


def test_junit_totals_accept_complete_suite() -> None:
    root = ET.fromstring(
        '<testsuites><testsuite tests="24" failures="0" '
        'errors="0" skipped="0"/></testsuites>'
    )
    assert _totals(root) == (24, 0, 0, 0)


def test_junit_totals_surface_skips_and_failures() -> None:
    root = ET.fromstring(
        '<testsuites><testsuite tests="12" failures="1" '
        'errors="2" skipped="3"/><testsuite tests="12" failures="0" '
        'errors="0" skipped="1"/></testsuites>'
    )
    assert _totals(root) == (24, 1, 2, 4)
