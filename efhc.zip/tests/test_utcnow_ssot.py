"""SSOT UTC Now — single source of truth for UTC time.

These tests are intentionally lightweight and do not require a DB.
"""

from __future__ import annotations

from datetime import timezone
from pathlib import Path

import pytest

from backend.app.lib.time import utcnow


def test_utcnow_is_tz_aware_utc() -> None:
    dt = utcnow()
    assert dt.tzinfo is not None
    assert dt.utcoffset() == timezone.utc.utcoffset(dt)


def test_panels_service_uses_ssot_utcnow() -> None:
    p = Path("backend/app/services/panels_service.py")
    text = p.read_text(encoding="utf-8")
    assert "utcnow(" in text
    assert "datetime.now(timezone.utc)" not in text
    assert "datetime.utcnow()" not in text


def test_panels_routes_server_now_utc_is_ssot() -> None:
    p = Path("backend/app/routes/panels_routes.py")
    text = p.read_text(encoding="utf-8")
    assert "server_now_utc" in text
    assert "utcnow(" in text
    assert "datetime.now(" not in text
