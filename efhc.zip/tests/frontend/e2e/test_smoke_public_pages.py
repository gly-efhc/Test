from __future__ import annotations

import pytest

from ._helpers import (
    assert_not_blank,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

PUBLIC_SMOKE_ROUTES = [
    "/",
    "/app",
    "/panels",
    "/exchange",
    "/tasks",
    "/referrals",
    "/referrals/active",
    "/referrals/inactive",
    "/ranks",
    "/web-profile",
    "/faq",
    "/hub",
    "/browser-shop",
    "/withdraw",
    "/ads",
]


@pytest.mark.parametrize("path", PUBLIC_SMOKE_ROUTES)
def test_public_page_smoke(chromium, path: str) -> None:
    page = chromium.launch().new_page()
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)
        response = goto(page, path)
        assert response is None or response.status < 500
        assert_not_blank(page)
    finally:
        page.context.browser.close()
