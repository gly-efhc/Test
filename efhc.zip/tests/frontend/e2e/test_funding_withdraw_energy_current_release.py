from __future__ import annotations

import json
from pathlib import Path

from ._helpers import (
    assert_not_blank,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]
FOLDER = ROOT / "reports/screenshots/direct_deposit_withdraw_energy_1561"
GENERATED = ROOT / "reports/generated"


def _shot(page, name: str) -> str:
    FOLDER.mkdir(parents=True, exist_ok=True)
    target = FOLDER / name
    page.screenshot(path=str(target), full_page=True)
    return str(target.relative_to(ROOT))


def _no_overflow(page) -> bool:
    return not page.evaluate(
        "document.documentElement.scrollWidth > window.innerWidth"
    )


def test_direct_deposit_and_store_purchase_are_visually_separate(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    screenshots: list[str] = []
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        page.add_init_script(
            """
            window.__efhcOpenedLinks = [];
            window.Telegram.WebApp.openLink = (url) => {
              window.__efhcOpenedLinks.push(String(url));
            };
            """
        )
        page.route(
            "**/api/hub/efhc-handoff",
            lambda route: route.fulfill(
                status=200,
                json={
                    "redirect_url": (
                        "https://shop.efhc.example/"
                        "browser-shop?token=e2e-token"
                    ),
                    "expires_at": "2026-07-20T12:10:00Z",
                    "transport": "external_url",
                    "mode": "signed_token",
                },
            ),
        )
        page.route(
            "**/api/shopfront/bootstrap**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "mode": "handoff_bound",
                    "tg_linked": True,
                    "tg_id": 1001,
                    "wallet_linked": True,
                    "active_wallet_address": "UQE2EWALLET",
                    "wallets": [],
                    "wallet_sync_required": False,
                    "bot_open_url": None,
                    "telegram_sync_url": None,
                    "wallet_sync_url": None,
                    "storefront_mode": "browser_shop_mvp",
                    "access_mode": "telegram_handoff",
                    "future_game_entry_enabled": False,
                    "available_modules": ["catalog", "checkout"],
                    "usdt_checkout_mode": "tep74_live",
                    "flow_truth": None,
                    "active_payment": None,
                    "intent_history": [],
                },
            ),
        )
        page.route(
            "**/api/shopfront/catalog",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "sku": "EFHC-100",
                            "title": "100 EFHCm",
                            "description": "Пополнение игрового баланса",
                            "item_type": "EFHC_PACKAGE",
                            "ton_enabled": True,
                            "usdt_enabled": True,
                            "methods": {
                                "TON": {"price": "1.00000000"},
                                "USDT": {"price": "30.00000000"},
                            },
                        }
                    ]
                },
            ),
        )

        goto(page, "/")
        page.get_by_role("button", name="Прямое пополнение").click()
        page.wait_for_selector(
            '[data-direct-deposit-kind="efhc-jetton-to-efhcm"]'
        )
        assert page.locator(
            '[data-direct-deposit-amount="efhc-jetton"]'
        ).count() == 1
        text = page.locator(
            '[data-direct-deposit-kind="efhc-jetton-to-efhcm"]'
        ).inner_text()
        assert "EFHC jetton" in text
        assert "TON" not in page.locator(
            ".efhc-direct-deposit_amount-control strong"
        ).inner_text()
        screenshots.append(_shot(page, "direct_efhc_jetton_390x844_ru.png"))
        assert _no_overflow(page)

        page.keyboard.press("Escape")
        goto(page, "/hub")
        page.wait_for_selector(
            '[data-hub-action="top-up"]'
        )
        assert page.locator(
            '[data-hub-handoff-kind="external-top-up"]'
        ).count() == 1
        screenshots.append(_shot(page, "hub_top_up_390x844_ru.png"))
        assert _no_overflow(page)

        goto(page, "/browser-shop?token=e2e-token")
        page.wait_for_selector(
            '[data-browser-shop-product-count]'
        )
        body = page.locator("body").inner_text()
        assert "TON / GRAM" in body
        assert "USDT" in body
        assert "100 EFHCm" in body
        screenshots.append(_shot(page, "browser_shop_ton_usdt_430x932_ru.png"))
        assert _no_overflow(page)

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "funding_contours_v171_36.json").write_text(
            json.dumps(
                {
                    "cycle": 1561,
                    "status": "PASSED",
                    "direct_deposit": "EFHC jetton -> EFHCm only",
                    "store_purchase": "TON/GRAM or USDT jetton -> EFHCm",
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()


def test_withdraw_create_cancel_status_and_history(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    state = {"status": None, "create": 0, "cancel": 0, "list": 0}
    screenshots: list[str] = []
    request = {
        "id": 41,
        "tg_id": 1001,
        "amount": "25.00000000",
        "status": "PENDING",
        "created_at": "2026-07-20T12:00:00Z",
        "updated_at": "2026-07-20T12:00:00Z",
        "idempotency_key": "e2e",
        "hold_done": True,
        "refund_done": False,
        "payout_ref": None,
    }
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)

        def on_list(route):
            state["list"] += 1
            items = [] if state["status"] is None else [
                {
                    key: value
                    for key, value in request.items()
                    if key not in {
                        "idempotency_key", "hold_done",
                        "refund_done", "payout_ref",
                    }
                }
            ]
            route.fulfill(
                status=200,
                json={"items": items, "next_cursor": None},
            )

        page.route("**/api/withdraw/list**", on_list)

        def on_create(route):
            state["create"] += 1
            assert route.request.method == "POST"
            assert route.request.post_data_json == {"amount": "25.00000000"}
            assert route.request.headers.get("idempotency-key")
            state["status"] = "PENDING"
            request["status"] = "PENDING"
            route.fulfill(status=200, json=request)

        page.route("**/api/withdraw/request", on_create)

        def on_detail(route):
            route.fulfill(status=200, json=request)

        page.route("**/api/withdraw/41", on_detail)

        def on_cancel(route):
            state["cancel"] += 1
            assert route.request.method == "POST"
            assert route.request.headers.get("idempotency-key")
            state["status"] = "CANCELED"
            request["status"] = "CANCELED"
            request["refund_done"] = True
            request["updated_at"] = "2026-07-20T12:05:00Z"
            route.fulfill(status=200, json=request)

        page.route("**/api/withdraw/41/cancel", on_cancel)
        page.route(
            "**/api/api/v1/me/withdraw-outcomes/41",
            lambda route: route.fulfill(
                status=200,
                json={
                    "request_id": 41,
                    "tg_id": 1001,
                    "outcome_kind": "canceled",
                    "locale": "ru",
                    "comment": {
                        "text": "Заявка отменена, средства возвращены.",
                        "source": "system",
                        "locale": "ru",
                    },
                    "promo": None,
                    "top_zone_enabled": False,
                    "metadata": {},
                },
            ),
        )
        page.route(
            "**/api/wallets/balance-history**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "id": 5,
                            "amount_efhc": "25.00000000",
                            "direction": "credit",
                            "balance_type": "main",
                            "reason": "withdraw_refund",
                            "created_at": "2026-07-20T12:05:00Z",
                        }
                    ],
                    "next_cursor": None,
                },
            ),
        )

        goto(page, "/withdraw")
        assert_not_blank(page)
        page.wait_for_selector(
            '[data-withdraw-runtime="react-query-create-cancel-history"]'
        )
        amount = page.locator('[data-withdraw-amount-input="efhcm-main-only"]')
        amount.fill("25")
        screenshots.append(_shot(page, "withdraw_create_390x844_ru.png"))
        page.locator('[data-withdraw-action="create"]').click()
        page.wait_for_selector('[data-withdraw-request-status="PENDING"]')
        assert state["create"] == 1
        screenshots.append(_shot(page, "withdraw_pending_430x932_ru.png"))
        page.locator('[data-withdraw-action="cancel"]').first.click()
        page.wait_for_selector('[data-withdraw-request-status="CANCELED"]')
        assert state["cancel"] == 1
        assert "25" in page.locator(
            ".efhc-withdraw-history-row"
        ).first.inner_text()
        screenshots.append(_shot(page, "withdraw_canceled_390x844_ru.png"))
        assert state["list"] >= 3
        assert _no_overflow(page)

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "withdraw_interaction_v171_36.json").write_text(
            json.dumps(
                {
                    "cycle": 1561,
                    "status": "PASSED",
                    "create_posts": state["create"],
                    "cancel_posts": state["cancel"],
                    "list_refetches": state["list"],
                    "final_status": state["status"],
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()


def test_energy_progress_information_and_responsive_screenshots(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 360, "height": 800})
    screenshots: list[str] = []
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        snapshot = {
            "profile": {
                "tg_id": 1001,
                "username": "e2e_user",
                "is_vip": True,
                "has_activ": True,
                "main_balance": "250.00000000",
                "bonus_balance": "15.00000000",
                "available_kwh": "42.50000000",
                "total_generated_kwh": "150.00000000",
                "lifetime_generated_kwh": "150.00000000",
                "gen_per_sec_base": "0.00000692",
                "gen_per_sec_vip": "0.00000741",
            },
            "panels": {
                "active_count": 2,
                "total_generated_by_panels": "150.00000000",
                "nearest_expire_at": None,
            },
            "exchange_preview": {
                "ok": True,
                "available_kwh": "42.50000000",
                "max_exchangeable_kwh": "42.50000000",
                "rate_kwh_to_efhc": "1.00000000",
                "detail": "E2E mock",
            },
            "meta": {
                "server_now_iso": "2026-07-20T12:00:00Z",
                "gen_per_sec_effective": "0.00000741",
                "next_scheduler_eta_sec": 0,
                "fallback_task_id": None,
            },
        }
        page.route(
            "**/api/sync/user/**",
            lambda route: route.fulfill(status=200, json=snapshot),
        )
        for width, height in [
            (360, 800), (390, 844), (430, 932), (768, 1024)
        ]:
            page.set_viewport_size({"width": width, "height": height})
            goto(page, "/")
            page.wait_for_selector('[data-energy-state="content"]')
            page.wait_for_selector('.efhc-energy-progress-fill')
            page.wait_for_function(
                """() => {
                  const fill = document.querySelector(
                    '.efhc-energy-progress-fill'
                  );
                  return fill && parseFloat(fill.style.width) > 0;
                }"""
            )
            progress = page.locator(
                ".efhc-energy-progress-fill"
            ).evaluate("el => parseFloat(el.style.width)")
            assert 0 < progress <= 100
            body = page.locator("body").inner_text()
            for value in ["250", "15", "42.5", "0.00000741", "2"]:
                assert value in body
            assert _no_overflow(page)
            screenshots.append(
                _shot(page, f"energy_{width}x{height}_ru.png")
            )

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "energy_progress_v171_36.json").write_text(
            json.dumps(
                {
                    "cycle": 1561,
                    "status": "PASSED",
                    "viewports": [
                        "360x800", "390x844", "430x932", "768x1024"
                    ],
                    "generated_kwh": "150.00000000",
                    "progress_percent": 25,
                    "available_kwh": "42.50000000",
                    "active_panels": 2,
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()
