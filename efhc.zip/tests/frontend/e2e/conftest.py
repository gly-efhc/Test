from __future__ import annotations

import os
from pathlib import Path
from shutil import which
from typing import Any

import pytest

_E2E_ROOT = Path(__file__).resolve().parent


def _is_e2e_item(item: pytest.Item) -> bool:
    """Return True only for tests physically under tests/frontend/e2e.

    Regression context: a previous hook skipped every collected test when
    EFHC_RUN_E2E was not set, so CI reported 1121 skipped tests while
    exit_pytest stayed 0. The hook must never mark architecture/unit/DB
    tests outside this directory.
    """

    try:
        item_path = Path(str(item.fspath)).resolve()
    except Exception:
        return False
    return item_path == _E2E_ROOT or _E2E_ROOT in item_path.parents


def pytest_collection_modifyitems(config, items):
    if os.environ.get("EFHC_RUN_E2E") == "1":
        return
    skip = pytest.mark.skip(
        reason="Set EFHC_RUN_E2E=1 to run browser E2E smoke tests.",
    )
    for item in items:
        if _is_e2e_item(item):
            item.add_marker(skip)


class _ChromiumLaunchAdapter:
    """Inject a system Chromium path when Playwright browsers are absent.

    CI may use downloaded Playwright browsers, while archive/sandbox proof runs
    often have `/usr/bin/chromium` only. The e2e tests must exercise a real
    browser in both cases and must not silently skip visual/button proof just
    because bundled Playwright browser binaries are missing.
    """

    def __init__(self, chromium: Any, executable_path: str | None) -> None:
        self._chromium = chromium
        self._executable_path = executable_path

    def launch(self, *args: Any, **kwargs: Any) -> Any:
        if self._executable_path and "executable_path" not in kwargs:
            kwargs["executable_path"] = self._executable_path
        if self._executable_path:
            launch_args = list(kwargs.get("args") or [])
            if "--no-sandbox" not in launch_args:
                launch_args.append("--no-sandbox")
            kwargs["args"] = launch_args
        return self._chromium.launch(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chromium, name)


def _system_chromium_path() -> str | None:
    explicit = os.environ.get("EFHC_PLAYWRIGHT_CHROMIUM_PATH")
    if explicit:
        return explicit
    return which("chromium") or which("chromium-browser") or which("google-chrome")


@pytest.fixture(scope="session")
def chromium():
    pytest.importorskip("playwright.sync_api")
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        yield _ChromiumLaunchAdapter(p.chromium, _system_chromium_path())
