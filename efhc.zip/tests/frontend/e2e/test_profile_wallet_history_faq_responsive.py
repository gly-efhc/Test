from __future__ import annotations

import json
from pathlib import Path

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

LANGS = [
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]


def _settings(lang: str) -> str:
    return json.dumps({
        "confirm_actions": False,
        "confirm_purchase": False,
        "confirm_withdraw": False,
        "confirm_convert": False,
        "confirm_watch_ad": False,
        "haptics_enabled": False,
        "sfx_enabled": False,
        "toasts_enabled": False,
        "hide_balances": False,
        "theme_mode": "dark",
        "lang": lang,
    })


def _set_lang(page, lang: str) -> None:
    payload = _settings(lang)
    page.evaluate(
        """(value) => {
          localStorage.setItem('efhc_settings', value);
          localStorage.setItem('EFHC_USER_SETTINGS_V2', value);
        }""",
        payload,
    )




def _wait_shell_ready(page) -> None:
    page.wait_for_function(
        "document.documentElement.dataset.efhcShell === 'ready'",
        timeout=20_000,
    )
    page.wait_for_selector(
        "div.fixed.inset-0.z-50",
        state="detached",
        timeout=10_000,
    )
    page.wait_for_timeout(600)

def _assert_layout(page, width: int, lang: str) -> dict[str, object]:
    metrics = page.evaluate(
        """() => ({
          width: window.innerWidth,
          height: window.innerHeight,
          scrollWidth: document.documentElement.scrollWidth,
          lang: document.documentElement.lang,
          splashVisible: Boolean(
            document.querySelector('[data-splash-visible="true"]')
          ),
          bodyNotBlank: Boolean(document.body.innerText.trim())
        })"""
    )
    assert metrics["width"] == width
    assert metrics["scrollWidth"] <= width
    assert metrics["splashVisible"] is False
    assert metrics["bodyNotBlank"] is True
    return metrics


def _install_profile_mocks(page) -> None:
    install_common_public_api_mocks(page)
    page.route(
        "**/api/wallets/balance-history**",
        lambda route: route.fulfill(
            status=200,
            json={
                "items": [
                    {
                        "id": 101,
                        "amount_efhc": "25.00000000",
                        "direction": "credit",
                        "balance_type": "main",
                        "reason": "exchange_kwh",
                        "created_at": "2026-07-18T12:00:00Z",
                    },
                    {
                        "id": 102,
                        "amount_efhc": "100.00000000",
                        "direction": "debit",
                        "balance_type": "bonus",
                        "reason": "panel_purchase",
                        "created_at": "2026-07-17T12:00:00Z",
                    },
                ],
                "next_cursor": None,
            },
        ),
    )
    page.route(
        "**/api/withdraw/list/me**",
        lambda route: route.fulfill(
            status=200,
            json={
                "items": [
                    {
                        "id": 201,
                        "tg_id": 1001,
                        "amount": "15.00000000",
                        "status": "pending",
                        "created_at": "2026-07-18T13:00:00Z",
                        "updated_at": "2026-07-18T13:00:00Z",
                    },
                    {
                        "id": 202,
                        "tg_id": 1001,
                        "amount": "8.00000000",
                        "status": "completed",
                        "created_at": "2026-07-16T13:00:00Z",
                        "updated_at": "2026-07-16T14:00:00Z",
                    },
                ],
                "next_cursor": None,
            },
        ),
    )


def test_profile_wallet_history_faq_responsive_evidence(chromium) -> None:
    root = Path(__file__).resolve().parents[3]
    screenshots = (
        root
        / "reports"
        / "screenshots"
        / "profile_wallet_history_faq_1559"
    )
    screenshots.mkdir(parents=True, exist_ok=True)
    generated = root / "reports" / "generated"
    generated.mkdir(parents=True, exist_ok=True)
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(15_000)
    evidence: list[dict[str, object]] = []
    try:
        install_public_fallback(page, tg_id=1001)
        _install_profile_mocks(page)

        surfaces = [
            ("profile", 360, 800),
            ("wallet", 390, 844),
            ("history", 430, 932),
            ("profile-tablet", 768, 1024),
        ]
        for surface, width, height in surfaces:
            page.set_viewport_size({"width": width, "height": height})
            _set_lang(page, "ru")
            goto(page, "/web-profile")
            page.wait_for_selector(
                "[data-public-surface='web-profile']",
            )
            _wait_shell_ready(page)
            if surface == "wallet":
                page.locator(
                    "[data-profile-trust-tab='wallet']",
                ).click()
                page.wait_for_selector(
                    "[data-wallet-list-boundary]",
                )
            if surface == "history":
                page.locator(
                    "[data-profile-trust-tab='history']",
                ).click()
                page.wait_for_selector(
                    "[data-history-account-timeline]",
                )
                page.wait_for_timeout(800)
            metrics = _assert_layout(page, width, "ru")
            name = f"{surface}_{width}x{height}_ru.png"
            page.screenshot(
                path=str(screenshots / name),
                full_page=True,
            )
            evidence.append({
                "surface": surface,
                "lang": "ru",
                "screenshot": str(
                    (screenshots / name).relative_to(root)
                ),
                "metrics": metrics,
            })

        page.set_viewport_size({"width": 390, "height": 844})
        _set_lang(page, "ru")
        goto(page, "/faq")
        page.wait_for_selector("[data-public-surface='faq']")
        _wait_shell_ready(page)
        faq_metrics = _assert_layout(page, 390, "ru")
        faq_name = "faq_390x844_ru.png"
        page.screenshot(
            path=str(screenshots / faq_name),
            full_page=True,
        )
        evidence.append({
            "surface": "faq",
            "lang": "ru",
            "screenshot": str(
                (screenshots / faq_name).relative_to(root)
            ),
            "metrics": faq_metrics,
        })

        report = {
            "cycle": 1559,
            "archive_version": "v171_34",
            "status": "PASSED",
            "viewports": [
                "360x800",
                "390x844",
                "430x932",
                "768x1024",
            ],
            "languages": ["ru"],
            "evidence": evidence,
        }
        target = generated / (
            "profile_wallet_history_faq_responsive_v171_34.json"
        )
        target.write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()
