"""Chromium proof session-first ownership для Telegram и TON."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

import pytest

from ._helpers import (
    BASE_URL,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

pytestmark = pytest.mark.visual_evidence

GLOBAL_ID = "0000001630"
SESSION_KEY = "efhc.auth.session.v1"


def _install_session(page, *, provider: str) -> list[str]:
    token = ("t" if provider == "telegram" else "n") * 40
    expires = (datetime.now(UTC) + timedelta(hours=1)).isoformat()
    credential = {
        "access_token": token,
        "token_type": "Bearer",
        "expires_at": expires,
    }
    page.add_init_script(
        "window.sessionStorage.setItem("
        f"{json.dumps(SESSION_KEY)}, "
        f"{json.dumps(json.dumps(credential))});"
    )
    seen_init_data: list[str] = []

    def auth_session(route):
        header = route.request.headers.get("x-telegram-init-data")
        if header:
            seen_init_data.append(header)
        route.fulfill(
            status=200,
            json={
                "global_id": GLOBAL_ID,
                "provider": provider,
                "roles": [],
            },
        )

    page.route("**/api/auth/session", auth_session)
    return seen_init_data


@pytest.mark.parametrize("provider", ["telegram", "ton_wallet"])
def test_cross_provider_browser_session_использует_одного_owner(
    chromium,
    provider: str,
) -> None:
    browser = chromium.launch(headless=True)
    context = browser.new_context()
    page = context.new_page()
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        seen_init_data = _install_session(page, provider=provider)
        response = goto(page, "/")
        assert response is not None and response.status == 200
        page.wait_for_function(
            "() => document.body && document.body.innerText.length > 0"
        )
        stored = page.evaluate(
            "() => window.sessionStorage.getItem("
            f"{json.dumps(SESSION_KEY)})"
        )
        assert stored is not None
        assert seen_init_data == []
        assert page.locator("body").count() == 1
        assert page.url.startswith(BASE_URL)
    finally:
        context.close()
        browser.close()
