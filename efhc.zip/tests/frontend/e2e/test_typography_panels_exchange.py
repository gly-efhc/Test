from __future__ import annotations

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
    write_interaction_evidence,
)


def _panel(panel_id: int) -> dict[str, object]:
    return {
        "id": panel_id,
        "public_id": f"ID{panel_id:08d}",
        "activated_at": "2026-07-16T10:00:00+00:00",
        "created_at": "2026-07-16T10:00:00+00:00",
        "expires_at": "2027-01-12T10:00:00+00:00",
        "archived_at": None,
        "remaining_seconds": 15552000,
        "base_gen_per_sec": "0.00000692",
        "generated_kwh": "0.00000000",
        "is_active": True,
    }


def test_panels_exchange_use_compact_arial_one_line_values(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)
        page.route(
            "**/api/exchange/preview**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "ok": True,
                    "available_kwh": "100.00000000",
                    "max_exchangeable_kwh": "100.00000000",
                    "rate_kwh_to_efhc": "1.00000000",
                    "detail": "proof",
                },
            ),
        )
        goto(page, "/exchange")
        rate = page.get_by_text("1 kWh = 1 EFHC", exact=True)
        rate.wait_for()
        exchange_metrics = rate.evaluate(
            """element => {
              const style = getComputedStyle(element);
              const rect = element.getBoundingClientRect();
              return {
                fontFamily: style.fontFamily,
                fontSize: style.fontSize,
                lineHeight: style.lineHeight,
                whiteSpace: style.whiteSpace,
                width: rect.width,
                height: rect.height
              };
            }"""
        )
        assert "Arial" in exchange_metrics["fontFamily"]
        assert exchange_metrics["whiteSpace"] == "nowrap"
        assert exchange_metrics["height"] < 30
        write_interaction_evidence(
            page,
            slug="exchange_typography",
            route="/exchange",
            action="verify one-line exchange rate at 390px",
            details=exchange_metrics,
            cycle=1557,
            archive_version="v171_32",
            folder="tasks_typography_1557",
        )

        page.route(
            "**/api/user/me/panels-summary",
            lambda route: route.fulfill(
                status=200,
                json={
                    "active_count": 1,
                    "total_generated_by_panels": "0.00000000",
                    "nearest_expire_at": "2027-01-12T10:00:00+00:00",
                },
            ),
        )
        page.route(
            "**/api/panels/active**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [_panel(1)],
                    "next_cursor": None,
                    "server_now_utc": "2026-07-16T10:00:00+00:00",
                },
            ),
        )
        page.route(
            "**/api/panels/archive**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [],
                    "next_cursor": None,
                    "server_now_utc": "2026-07-16T10:00:00+00:00",
                },
            ),
        )
        goto(page, "/panels")
        page.wait_for_selector("text=ID00000001")
        panel_metrics = page.locator(
            ".efhc-panels-shell .efhc-game-stat_value"
        ).evaluate_all(
            """elements => elements.map(element => {
              const style = getComputedStyle(element);
              const rect = element.getBoundingClientRect();
              return {
                text: element.textContent?.trim(),
                fontFamily: style.fontFamily,
                fontSize: style.fontSize,
                whiteSpace: style.whiteSpace,
                height: rect.height
              };
            })"""
        )
        assert panel_metrics
        assert all("Arial" in item["fontFamily"] for item in panel_metrics)
        assert all(item["whiteSpace"] == "nowrap" for item in panel_metrics)
        assert all(item["height"] < 30 for item in panel_metrics)
        assert page.evaluate(
            "document.documentElement.scrollWidth <= window.innerWidth"
        )
        write_interaction_evidence(
            page,
            slug="panels_typography",
            route="/panels",
            action="verify compact one-line panel values at 390px",
            details={"values": panel_metrics},
            cycle=1557,
            archive_version="v171_32",
            folder="tasks_typography_1557",
        )
    finally:
        browser.close()
