from __future__ import annotations

import json
from pathlib import Path

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]
FOLDER = ROOT / "reports/screenshots/header_visual_1572"
REPORT = ROOT / "reports/generated/header_visual_v171_50.json"


def _snapshot(*, vip: bool, activ: bool) -> dict[str, object]:
    return {
        "profile": {
            "tg_id": 1001,
            "username": "e2e_user",
            "is_vip": vip,
            "has_activ": activ,
            "main_balance": "12345678.12345678",
            "bonus_balance": "0.87654321",
            "available_kwh": "42.50000000",
            "total_generated_kwh": "321.50000000",
            "gen_per_sec_base": "0.00000692",
            "gen_per_sec_vip": "0.00000741",
        },
        "panels": {
            "active_count": 2,
            "total_generated_by_panels": "5.00000000",
            "nearest_expire_at": None,
        },
        "exchange_preview": {
            "ok": True,
            "available_kwh": "42.50000000",
            "max_exchangeable_kwh": "42.50000000",
            "rate_kwh_to_efhc": "1.00000000",
        },
        "meta": {
            "server_now_iso": "2026-07-20T12:00:00Z",
            "gen_per_sec_effective": "0.00000741",
            "next_scheduler_eta_sec": 0,
            "fallback_task_id": None,
        },
    }


def _shot(page, name: str) -> str:
    FOLDER.mkdir(parents=True, exist_ok=True)
    target = FOLDER / name
    page.locator(".efhc-game-header").screenshot(path=str(target))
    return str(target.relative_to(ROOT))


def _assert_balanced_header(page) -> dict[str, object]:
    page.wait_for_selector(
        '[data-header-action-layout="balanced-grid"]'
    )
    buttons = page.locator(
        '[data-header-action-layout="balanced-grid"] '
        ".efhc-header-action"
    )
    assert buttons.count() == 4
    boxes = buttons.evaluate_all(
        "els => els.map(el => el.getBoundingClientRect().toJSON())"
    )
    widths = [float(box["width"]) for box in boxes]
    heights = [float(box["height"]) for box in boxes]
    assert max(widths) - min(widths) <= 1.5
    assert max(heights) - min(heights) <= 1.5
    assert page.locator('[data-status="vip"]').count() == 1
    assert page.locator('[data-status="activ"]').count() == 1
    assert page.locator(".efhc-vip-crown").count() == 0
    assert "👑" not in page.locator("body").inner_text()
    balance = page.locator('[data-balance-scope="global-header"]')
    balance_value = page.locator(".efhc-game-header_balance-value")
    assert balance_value.inner_text() == "12345678.99999999"
    assert balance_value.evaluate(
        "el => el.scrollWidth <= el.clientWidth + 1"
    )
    assert balance_value.evaluate(
        "el => getComputedStyle(el).textOverflow === 'clip'"
    )
    profile_box = page.locator(".efhc-game-header_profile").bounding_box()
    balance_box = balance.bounding_box()
    assert profile_box is not None
    assert balance_box is not None
    assert abs(float(profile_box["y"]) - float(balance_box["y"])) <= 1.5
    assert abs(float(profile_box["height"]) - float(balance_box["height"])) <= 1.5
    assert page.evaluate(
        "document.documentElement.scrollWidth <= window.innerWidth"
    )
    return {
        "buttons": buttons.count(),
        "widths": widths,
        "heights": heights,
        "vip_text_only": True,
        "balance_fully_visible": True,
        "top_row_aligned": True,
        "horizontal_overflow": False,
    }


def test_balanced_header_vip_states_and_screenshots(chromium) -> None:
    browser = chromium.launch()
    evidence: list[dict[str, object]] = []
    try:
        for vip, activ, name, viewport in (
            (
                False,
                False,
                "header_statuses_inactive_390x844_ru.png",
                {"width": 390, "height": 844},
            ),
            (
                True,
                True,
                "header_statuses_active_390x844_ru.png",
                {"width": 390, "height": 844},
            ),
            (
                True,
                True,
                "header_balance_full_360x800_ru.png",
                {"width": 360, "height": 800},
            ),
        ):
            page = browser.new_page(viewport=viewport)
            install_public_fallback(page)
            install_common_public_api_mocks(page)
            snapshot = _snapshot(vip=vip, activ=activ)

            def fulfill_snapshot(route, payload=snapshot) -> None:
                route.fulfill(status=200, json=payload)

            page.route("**/api/sync/user/**", fulfill_snapshot)
            goto(page, "/")
            metrics = _assert_balanced_header(page)
            screenshot = _shot(page, name)
            evidence.append(
                {
                    "vip": vip,
                    "activ": activ,
                    "viewport": viewport,
                    "screenshot": screenshot,
                    **metrics,
                }
            )
            page.close()
    finally:
        browser.close()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(
            {
                "cycle": 1572,
                "version": "v171.50",
                "status": "PASSED",
                "items": evidence,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
