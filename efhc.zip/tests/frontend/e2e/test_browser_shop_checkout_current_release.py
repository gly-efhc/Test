from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from ._helpers import (
    BASE_URL,
    assert_not_blank,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]
FOLDER = ROOT / "reports/screenshots/browser_shop_1562_repeat"
GENERATED = ROOT / "reports/generated"


def _shot(page, name: str) -> str:
    FOLDER.mkdir(parents=True, exist_ok=True)
    target = FOLDER / name
    page.screenshot(path=str(target), full_page=True)
    return str(target.relative_to(ROOT))


def _no_overflow(page) -> bool:
    return not page.evaluate(
        "document.documentElement.scrollWidth > window.innerWidth"
    )


def _bootstrap(*, token: bool, active_payment=None) -> dict:
    return {
        "mode": "handoff_bound" if token else "guest",
        "tg_linked": token,
        "tg_id": 1001 if token else None,
        "wallet_linked": token,
        "active_wallet_address": "UQE2EWALLET" if token else None,
        "wallets": [],
        "wallet_sync_required": not token,
        "bot_open_url": "https://t.me/efhc_bot?start=browser_shop_sync",
        "telegram_sync_url": (
            "https://t.me/efhc_bot?start=browser_shop_sync"
        ),
        "wallet_sync_url": (
            "https://t.me/efhc_bot?start=browser_shop_wallet"
        ),
        "storefront_mode": "browser_shop_mvp",
        "access_mode": "telegram_handoff",
        "future_game_entry_enabled": False,
        "available_modules": ["catalog", "checkout"],
        "usdt_checkout_mode": "tep74_live",
        "flow_truth": None,
        "active_payment": active_payment,
        "intent_history": [],
    }


def _catalog() -> dict:
    return {
        "items": [
            {
                "sku": "EFHC-100",
                "title": "100 EFHCm",
                "description": "EFHCm",
                "item_type": "EFHC_PACKAGE",
                "ton_enabled": True,
                "usdt_enabled": True,
                "methods": {
                    "TON": {"price": "1.00000000"},
                    "USDT": {"price": "30.00000000"},
                },
            },
            {
                "sku": "EFHC-500",
                "title": "500 EFHCm",
                "description": None,
                "item_type": "EFHC_PACKAGE",
                "ton_enabled": True,
                "usdt_enabled": True,
                "methods": {
                    "TON": {"price": "4.50000000"},
                    "USDT": {"price": "135.00000000"},
                },
            },
        ]
    }


def test_hub_energy_navigation_compact_visual_proof(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 360, "height": 800})
    page.set_default_timeout(15_000)
    screenshots: list[str] = []
    state = {"handoff": 0}
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        page.add_init_script(
            """
            window.__efhcOpenedLinks = [];
            window.Telegram.WebApp.openLink = (url) => {
              window.__efhcOpenedLinks.push(String(url));
            };
            """
        )

        def on_handoff(route):
            state["handoff"] += 1
            route.fulfill(
                status=200,
                json={
                    "redirect_url": (
                        "https://shop.efhc.example/"
                        "browser-shop?token=e2e-token"
                    ),
                    "expires_at": "2026-07-20T12:10:00Z",
                    "transport": "external_url",
                    "mode": "signed_token",
                },
            )

        page.route("**/api/hub/efhc-handoff", on_handoff)

        goto(page, "/")
        page.wait_for_selector('[data-energy-range-safe="true"]')
        page.wait_for_selector(
            '[data-energy-mark="balanced-lightning-v2"]'
        )
        assert page.locator('[data-app-nav-icon]').count() == 6
        assert page.locator(
            '[data-energy-mark="balanced-lightning-v2"]'
        ).count() == 1
        assert page.locator('[data-energy-summary-card-count]').count() == 0
        assert page.locator('[data-energy-level-name]').count() == 1
        assert page.locator('[data-energy-chip-count="3"]').count() == 1
        energy_text = page.locator("body").inner_text().lower()
        for removed in ("основной баланс", "бонусный баланс", "обменять"):
            assert removed not in energy_text
        assert _no_overflow(page)
        screenshots.append(_shot(page, "energy_compact_360x800_ru.png"))

        page.set_viewport_size({"width": 390, "height": 844})
        goto(page, "/hub")
        assert_not_blank(page)
        page.wait_for_selector('[data-hub-visible-action-count="2"]')
        assert page.locator('[data-hub-action]').count() == 2
        body = page.locator("body").inner_text().lower()
        for forbidden in ("ton", "usdt", "купить", "покуп", "магаз", "цена"):
            assert forbidden not in body
        assert "efhc vip nft" in body
        screenshots.append(_shot(page, "hub_two_actions_390x844_ru.png"))
        page.locator('[data-hub-action="top-up"]').click()
        page.wait_for_timeout(250)
        assert state["handoff"] == 1
        page.locator('[data-hub-action="vip-nft"]').click()
        page.wait_for_timeout(120)
        opened = page.evaluate("window.__efhcOpenedLinks")
        assert any("getgems.io/efhc-nft" in item for item in opened)
        assert _no_overflow(page)

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "hub_energy_visual_v171_38.json").write_text(
            json.dumps(
                {
                    "cycle": 1562,
                    "status": "PASSED",
                    "screenshots": screenshots,
                    "hub_visible_actions": 2,
                    "bottom_navigation_icons": 6,
                    "energy_range_overflow": False,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()


def test_browser_shop_link_return_ttl_and_payment_methods(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(20_000)
    screenshots: list[str] = []
    expiry = (datetime.now(UTC) + timedelta(minutes=8)).isoformat()
    state = {
        "access_key": 0,
        "create": [],
        "status": 0,
        "linked": False,
    }
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        page.add_init_script(
            """
            window.__efhcAssignedUrl = '';
            try {
              Object.defineProperty(Location.prototype, 'assign', {
                configurable: true,
                value(url) { window.__efhcAssignedUrl = String(url); }
              });
            } catch {}
            """
        )

        def on_bootstrap(route):
            token = "token=" in route.request.url
            state["linked"] = token
            route.fulfill(status=200, json=_bootstrap(token=token))

        page.route("**/api/shopfront/bootstrap**", on_bootstrap)
        page.route(
            "**/api/shopfront/catalog",
            lambda route: route.fulfill(status=200, json=_catalog()),
        )

        def on_access_key(route):
            state["access_key"] += 1
            route.fulfill(
                status=200,
                json={
                    "redirect_url": (
                        f"{BASE_URL}/browser-shop?token=web-token"
                    ),
                    "expires_at": expiry,
                    "transport": "external_url",
                    "mode": "signed_token",
                },
            )

        page.route("**/api/shopfront/access-key", on_access_key)

        def on_create(route):
            body = route.request.post_data_json
            state["create"].append(body)
            method = body["pay_method"]
            response = {
                "tg_id": 1001,
                "intent_id": 77 if method == "USDT" else 78,
                "order_id": 700 if method == "USDT" else 701,
                "item_type": "EFHC_PACKAGE",
                "pay_method": method,
                "amount": "30.00000000" if method == "USDT" else "1.00000000",
                "memo": "EFHC:SHOP:E2E",
                "to_wallet": "UQSHOP",
                "tonconnect_tx": {
                    "validUntil": 1999999999,
                    "messages": [{"address": "UQSHOP", "amount": "100000000"}],
                },
                "tonconnect_transport_kind": (
                    "tep74_jetton" if method == "USDT" else "native_ton"
                ),
                "jetton_master_address": (
                    "EQUSDTMASTER" if method == "USDT" else None
                ),
                "jetton_decimals": 6 if method == "USDT" else None,
                "forward_payload_text": "EFHC:SHOP:E2E",
                "fee_message_ton_amount": "0.05",
                "forward_ton_amount": "0.01",
                "recipient_strategy": "owner_derived_wallet",
                "usdt_checkout_mode": "tep74_live",
                "expires_at": expiry,
            }
            route.fulfill(status=200, json=response)

        page.route("**/api/shopfront/create-intent", on_create)

        def on_status(route):
            state["status"] += 1
            confirmed = state["status"] >= 2
            route.fulfill(
                status=200,
                json={
                    "id": 77,
                    "purpose": "SHOP_EXTERNAL",
                    "asset": "USDT",
                    "amount_asset_d8": "30.00000000",
                    "efhc_amount_d8": "100.00000000",
                    "status": "CONFIRMED" if confirmed else "PENDING",
                    "payload": "EFHC:SHOP:E2E",
                    "to_address": "UQSHOP",
                    "external_tx_hash": "tx-e2e" if confirmed else None,
                    "flow_truth": {
                        "lifecycle_stage": (
                            "completed" if confirmed else "payment_pending"
                        ),
                        "product_state": (
                            "terminal_success" if confirmed else "awaiting_payment"
                        ),
                        "lifecycle_terminal": confirmed,
                        "next_step": (
                            "open_profile" if confirmed else "wait_for_watcher"
                        ),
                        "next_action": (
                            "view_balance" if confirmed else "poll_status"
                        ),
                        "return_path": "/browser-shop",
                        "canonical_center": "browser_shop",
                        "user_message": (
                            "confirmed" if confirmed else "waiting"
                        ),
                        "watcher_status": (
                            "confirmed" if confirmed else "pending"
                        ),
                    },
                    "created_at": datetime.now(UTC).isoformat(),
                    "expires_at": expiry,
                },
            )

        page.route("**/api/shopfront/intent-status**", on_status)

        goto(page, "/browser-shop?sku=EFHC-100&method=USDT")
        page.wait_for_selector('[data-account-linked="false"]')
        screenshots.append(_shot(page, "shop_guest_link_390x844_ru.png"))
        assert _no_overflow(page)

        page.get_by_role("button", name="Открыть Web Profile").click()
        page.wait_for_timeout(300)
        assert state["access_key"] == 1
        assigned = page.evaluate("window.__efhcAssignedUrl || ''")
        if assigned:
            assert "token=web-token" in assigned
            assert "sku=EFHC-100" in assigned
            assert "method=USDT" in assigned

        # Managed Chromium may render local HTML at about:blank. Persist
        # the exact returned checkout context to exercise the production
        # session restore path without pretending the blocked navigation ran.
        page.add_init_script(
            """
            sessionStorage.setItem(
              'efhc.browserShop.token.v1',
              'web-token'
            );
            sessionStorage.setItem(
              'efhc.browserShop.sku.v1',
              'EFHC-100'
            );
            sessionStorage.setItem(
              'efhc.browserShop.method.v1',
              'USDT'
            );
            """
        )
        goto(
            page,
            "/browser-shop?token=web-token&sku=EFHC-100&method=USDT",
        )
        page.wait_for_selector('[data-account-linked="true"]')
        page.wait_for_selector('[data-wallet-linked="true"]')
        assert page.locator('[data-browser-shop-pay-method="USDT"]').count() >= 1
        screenshots.append(_shot(page, "shop_linked_usdt_390x844_ru.png"))

        card = page.locator('[data-checkout-sku="EFHC-100"]')
        card.get_by_role("button", name="Оплатить", exact=True).click()
        page.wait_for_function("() => document.body.innerText.includes('Истекает')")
        assert state["create"]
        assert state["create"][0]["pay_method"] == "USDT"
        assert state["create"][0]["sku"] == "EFHC-100"
        assert state["create"][0]["token"] == "web-token"
        screenshots.append(_shot(page, "shop_payment_ttl_390x844_ru.png"))

        page.wait_for_timeout(5_500)
        page.wait_for_function(
            "() => document.body.innerText.toUpperCase().includes('ОПЛАЧЕНО')"
        )
        assert state["status"] >= 2
        screenshots.append(_shot(page, "shop_confirmed_390x844_ru.png"))
        assert _no_overflow(page)

        page.set_viewport_size({"width": 768, "height": 1024})
        goto(
            page,
            "/browser-shop?token=web-token&sku=EFHC-500&method=TON",
        )
        page.wait_for_selector('[data-browser-shop-checkout="ton-usdt"]')
        screenshots.append(_shot(page, "shop_tablet_768x1024_ru.png"))
        assert _no_overflow(page)

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "browser_shop_interaction_v171_38.json").write_text(
            json.dumps(
                {
                    "cycle": 1562,
                    "status": "PASSED",
                    "access_key_posts": state["access_key"],
                    "created_methods": [
                        item["pay_method"] for item in state["create"]
                    ],
                    "status_calls": state["status"],
                    "ttl_visible": True,
                    "same_checkout_return": True,
                    "react_query_polling": True,
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()
