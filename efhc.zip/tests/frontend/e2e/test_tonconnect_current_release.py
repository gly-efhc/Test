from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from ._helpers import (
    assert_not_blank,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]
FOLDER = ROOT / "reports/screenshots/tonconnect_1563"
GENERATED = ROOT / "reports/generated"


def _shot(page, name: str) -> str:
    FOLDER.mkdir(parents=True, exist_ok=True)
    target = FOLDER / name
    page.screenshot(path=str(target), full_page=True)
    return str(target.relative_to(ROOT))


def _no_overflow(page) -> bool:
    return not page.evaluate(
        "document.documentElement.scrollWidth > window.innerWidth"
    )


def _install_connector(page, *, restored: bool = False) -> None:
    script = f"""
    (() => {{
      const listeners = [];
      const rawAddress = '0:' + '11'.repeat(32);
      let wallet = null;
      let connected = false;
      const restoredInitially = {str(restored).lower()};
      if (restoredInitially) {{
        localStorage.setItem('efhc.e2e.tonconnect.connected', '1');
      }}
      const restoredWallet = () => ({{
        account: {{
          address: rawAddress,
          chain: '-239',
          publicKey: '22'.repeat(32),
          walletStateInit: 'te6ccgEBAQEA'
        }},
        device: {{ appName: 'E2E Wallet' }},
        connectItems: {{}}
      }});
      const proofWallet = (payload) => ({{
        account: {{
          address: rawAddress,
          chain: '-239',
          publicKey: '22'.repeat(32),
          walletStateInit: 'te6ccgEBAQEA'
        }},
        device: {{ appName: 'E2E Wallet' }},
        connectItems: {{
          tonProof: {{
            proof: {{
              timestamp: Math.floor(Date.now() / 1000),
              domain: {{ lengthBytes: 9, value: '127.0.0.1' }},
              signature: 'e2e-signature',
              payload: String(payload || 'e2e-proof')
            }}
          }}
        }}
      }});
      const notify = () => listeners.slice().forEach((cb) => cb(wallet));
      window.__efhcTcConnectMode = 'success';
      window.__efhcTcTxMode = 'success';
      window.__efhcTcTransactions = [];
      window.__efhcTonConnectConnector = {{
        get wallet() {{ return wallet; }},
        get connected() {{ return connected; }},
        async restoreConnection() {{
          if (localStorage.getItem('efhc.e2e.tonconnect.connected') === '1') {{
            wallet = restoredWallet();
            connected = true;
            queueMicrotask(notify);
          }}
        }},
        async getWallets() {{
          return [{{
            name: 'E2E Wallet',
            appName: 'e2e',
            embedded: true,
            injected: true,
            jsBridgeKey: 'e2e',
            imageUrl: 'https://example.invalid/e2e.png',
            aboutUrl: 'https://example.invalid'
          }}];
        }},
        onStatusChange(cb) {{
          listeners.push(cb);
          return () => {{
            const index = listeners.indexOf(cb);
            if (index >= 0) listeners.splice(index, 1);
          }};
        }},
        connect(_source, options) {{
          if (window.__efhcTcConnectMode === 'reject') {{
            const error = new Error('USER_REJECTS_ERROR');
            error.code = 300;
            error.name = 'UserRejectsError';
            throw error;
          }}
          wallet = proofWallet(options?.request?.tonProof);
          connected = true;
          localStorage.setItem('efhc.e2e.tonconnect.connected', '1');
          queueMicrotask(notify);
          return '';
        }},
        async disconnect() {{
          wallet = null;
          connected = false;
          localStorage.removeItem('efhc.e2e.tonconnect.connected');
          notify();
        }},
        async sendTransaction(tx) {{
          window.__efhcTcTransactions.push(tx);
          if (window.__efhcTcTxMode === 'reject') {{
            const error = new Error('USER_REJECTS_ERROR');
            error.code = 300;
            error.name = 'UserRejectsError';
            throw error;
          }}
          return {{ boc: 'te6ccgEBAQEA', traceId: 'e2e-trace' }};
        }}
      }};
    }})();
    """
    page.add_init_script(script)
    page.evaluate(script)


def _bootstrap() -> dict:
    return {
        "mode": "handoff_bound",
        "tg_linked": True,
        "tg_id": 1001,
        "wallet_linked": True,
        "active_wallet_address": "UQE2EWALLET",
        "wallets": [],
        "wallet_sync_required": False,
        "bot_open_url": "https://t.me/efhc_bot",
        "telegram_sync_url": "https://t.me/efhc_bot",
        "wallet_sync_url": "https://t.me/efhc_bot",
        "active_payment": None,
        "storefront_mode": "browser_shop_mvp",
        "access_mode": "telegram_handoff",
        "future_game_entry_enabled": False,
        "available_modules": ["catalog", "checkout"],
        "usdt_checkout_mode": "tep74_live",
        "flow_truth": None,
        "intent_history": [],
    }


def _catalog() -> dict:
    return {
        "items": [
            {
                "sku": "EFHC-100",
                "title": "100 EFHCm",
                "description": None,
                "item_type": "EFHC_PACKAGE",
                "ton_enabled": True,
                "usdt_enabled": True,
                "methods": {
                    "TON": {"price": "1.00000000"},
                    "USDT": {"price": "30.00000000"},
                },
            }
        ]
    }


def test_tonconnect_restore_proof_connect_and_rejection(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(20_000)
    state = {"bound": False, "connect_posts": []}
    screenshots: list[str] = []
    try:
        install_public_fallback(page, tg_id=1001)
        _install_connector(page)
        install_common_public_api_mocks(page)

        def on_wallets(route):
            wallets = []
            if state["bound"]:
                wallets = [{
                    "id": 7,
                    "wallet_address": "0:" + "11" * 32,
                    "wallet_app": "E2E Wallet",
                    "is_primary": True,
                    "is_active": True,
                    "created_at": "2026-07-20T12:00:00Z",
                }]
            route.fulfill(
                status=200,
                json={
                    "is_connected": state["bound"],
                    "wallets": wallets,
                },
            )

        page.route("**/api/wallets/me**", on_wallets)

        def on_connect(route):
            body = route.request.post_data_json
            state["connect_posts"].append(body)
            assert route.request.headers.get("idempotency-key")
            assert body["address"].startswith("0:")
            assert body["wallet_app"] == "E2E Wallet"
            assert body["payload_token"] == "e2e-token"
            assert body["public_key"] == "22" * 32
            assert body["network"] == "-239"
            proof = body["proof"]
            assert proof["timestamp"] > 0
            assert proof["domain"]["value"] == "127.0.0.1"
            assert proof["signature"] == "e2e-signature"
            assert proof["payload"] == "e2e-proof"
            assert proof["state_init"] == "te6ccgEBAQEA"
            state["bound"] = True
            route.fulfill(
                status=200,
                json={
                    "wallet_id": 7,
                    "wallet_address": body["address"],
                    "is_connected": True,
                },
            )

        page.route("**/api/wallets/connect", on_connect)

        goto(page, "/web-profile?section=wallet")
        page.get_by_role("button", name="Кошелёк", exact=True).click()
        page.wait_for_selector('[data-tonconnect-phase="proof_ready"]')
        assert_not_blank(page)
        screenshots.append(_shot(page, "wallet_disconnected_390x844_ru.png"))
        assert _no_overflow(page)

        page.evaluate("window.__efhcTcConnectMode = 'reject'")
        page.locator('[data-tonconnect-action="connect"]').click()
        page.wait_for_selector('[data-tonconnect-phase="rejected"]')
        screenshots.append(_shot(page, "wallet_rejected_390x844_ru.png"))
        assert len(state["connect_posts"]) == 0

        page.evaluate("window.__efhcTcConnectMode = 'success'")
        page.locator('[data-tonconnect-action="connect"]').click()
        page.wait_for_selector('[data-tonconnect-phase="connected"]')
        page.wait_for_function(
            "() => document.body.innerText.includes('E2E Wallet')"
        )
        screenshots.append(_shot(page, "wallet_verified_390x844_ru.png"))
        assert len(state["connect_posts"]) == 1
        assert _no_overflow(page)

        page.close()
        page = browser.new_page(viewport={"width": 390, "height": 844})
        page.set_default_timeout(20_000)
        install_public_fallback(page, tg_id=1001)
        _install_connector(page, restored=True)
        install_common_public_api_mocks(page)
        page.route("**/api/wallets/me**", on_wallets)

        goto(page, "/web-profile?section=wallet")
        page.get_by_role("button", name="Кошелёк", exact=True).click()
        page.wait_for_selector('[data-tonconnect-phase="connected"]')
        page.wait_for_function(
            "() => document.body.innerText.includes('E2E Wallet')"
        )
        screenshots.append(_shot(page, "wallet_restored_390x844_ru.png"))
        assert len(state["connect_posts"]) == 1
        assert _no_overflow(page)

        page.set_viewport_size({"width": 768, "height": 1024})
        screenshots.append(_shot(page, "wallet_restored_768x1024_ru.png"))
        assert _no_overflow(page)

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "tonconnect_wallet_interaction_v171_39.json").write_text(
            json.dumps(
                {
                    "cycle": 1563,
                    "status": "PASSED",
                    "connect_posts": len(state["connect_posts"]),
                    "proof_envelope_complete": True,
                    "user_rejection_visible": True,
                    "session_restore_visible": True,
                    "responsive_viewports": ["390x844", "768x1024"],
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()


def test_tonconnect_transaction_rejection_and_success(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(20_000)
    expiry = (datetime.now(UTC) + timedelta(minutes=8)).isoformat()
    state = {"create": 0, "status": 0}
    screenshots: list[str] = []
    try:
        install_public_fallback(page, tg_id=1001)
        _install_connector(page, restored=True)
        install_common_public_api_mocks(page)
        page.route(
            "**/api/shopfront/bootstrap**",
            lambda route: route.fulfill(status=200, json=_bootstrap()),
        )
        page.route(
            "**/api/shopfront/catalog",
            lambda route: route.fulfill(status=200, json=_catalog()),
        )

        def on_create(route):
            state["create"] += 1
            body = route.request.post_data_json
            assert body["pay_method"] == "TON"
            assert body["token"] == "web-token"
            route.fulfill(
                status=200,
                json={
                    "tg_id": 1001,
                    "intent_id": 80 + state["create"],
                    "order_id": 700 + state["create"],
                    "item_type": "EFHC_PACKAGE",
                    "pay_method": "TON",
                    "amount": "1.00000000",
                    "memo": "EFHC:SHOP:E2E",
                    "to_wallet": "UQSHOP",
                    "tonconnect_tx": {
                        "validUntil": 1999999999,
                        "messages": [{
                            "address": "UQSHOP",
                            "amount": "1000000000",
                        }],
                    },
                    "tonconnect_transport_kind": "native_ton",
                    "jetton_master_address": None,
                    "jetton_decimals": None,
                    "forward_payload_text": "EFHC:SHOP:E2E",
                    "fee_message_ton_amount": "0.05",
                    "forward_ton_amount": "0.01",
                    "recipient_strategy": "owner_derived_wallet",
                    "usdt_checkout_mode": "tep74_live",
                    "expires_at": expiry,
                },
            )

        page.route("**/api/shopfront/create-intent", on_create)

        def on_status(route):
            state["status"] += 1
            confirmed = state["status"] >= 2
            route.fulfill(
                status=200,
                json={
                    "id": 82,
                    "purpose": "SHOP_EXTERNAL",
                    "asset": "TON",
                    "amount_asset_d8": "1.00000000",
                    "efhc_amount_d8": "100.00000000",
                    "status": "CONFIRMED" if confirmed else "PENDING",
                    "payload": "EFHC:SHOP:E2E",
                    "to_address": "UQSHOP",
                    "external_tx_hash": "tx-e2e" if confirmed else None,
                    "flow_truth": {
                        "lifecycle_stage": (
                            "completed" if confirmed else "payment_pending"
                        ),
                        "product_state": (
                            "terminal_success" if confirmed
                            else "awaiting_payment"
                        ),
                        "lifecycle_terminal": confirmed,
                        "next_step": (
                            "open_profile" if confirmed
                            else "wait_for_watcher"
                        ),
                        "next_action": (
                            "view_balance" if confirmed else "poll_status"
                        ),
                        "return_path": "/browser-shop",
                        "canonical_center": "browser_shop",
                        "user_message": (
                            "confirmed" if confirmed else "waiting"
                        ),
                        "watcher_status": (
                            "confirmed" if confirmed else "pending"
                        ),
                    },
                    "created_at": datetime.now(UTC).isoformat(),
                    "expires_at": expiry,
                },
            )

        page.route("**/api/shopfront/intent-status**", on_status)
        page.add_init_script(
            """
            sessionStorage.setItem('efhc.browserShop.token.v1', 'web-token');
            sessionStorage.setItem('efhc.browserShop.sku.v1', 'EFHC-100');
            sessionStorage.setItem('efhc.browserShop.method.v1', 'TON');
            """
        )

        goto(
            page,
            "/browser-shop?token=web-token&sku=EFHC-100&method=TON",
        )
        page.wait_for_selector('[data-account-linked="true"]')
        page.evaluate("window.__efhcTcTxMode = 'reject'")
        card = page.locator('[data-checkout-sku="EFHC-100"]')
        card.get_by_role("button", name="Оплатить", exact=True).click()
        page.wait_for_selector('[data-tonconnect-transaction="rejected"]')
        screenshots.append(_shot(page, "transaction_rejected_390x844_ru.png"))
        assert page.evaluate("window.__efhcTcTransactions.length") == 1
        assert _no_overflow(page)

        page.evaluate(
            """
            sessionStorage.setItem('efhc.browserShop.token.v1', 'web-token');
            sessionStorage.setItem('efhc.browserShop.sku.v1', 'EFHC-100');
            sessionStorage.setItem('efhc.browserShop.method.v1', 'TON');
            window.__efhcTcTxMode = 'success';
            """
        )
        state["status"] = 0
        goto(
            page,
            "/browser-shop?token=web-token&sku=EFHC-100&method=TON",
        )
        page.wait_for_selector('[data-account-linked="true"]')
        card = page.locator('[data-checkout-sku="EFHC-100"]')
        card.get_by_role("button", name="Оплатить", exact=True).click()
        page.wait_for_selector('[data-tonconnect-transaction="signed"]')
        page.wait_for_timeout(5_500)
        page.wait_for_function(
            "() => document.body.innerText.toUpperCase().includes('ОПЛАЧЕНО')"
        )
        screenshots.append(_shot(page, "transaction_confirmed_390x844_ru.png"))
        assert page.evaluate("window.__efhcTcTransactions.length") == 1
        assert state["status"] >= 2
        assert _no_overflow(page)

        GENERATED.mkdir(parents=True, exist_ok=True)
        (GENERATED / "tonconnect_transaction_interaction_v171_39.json").write_text(
            json.dumps(
                {
                    "cycle": 1563,
                    "status": "PASSED",
                    "transaction_attempts": state["create"],
                    "user_rejection_visible": True,
                    "signed_state_visible": True,
                    "watcher_confirmed_visible": True,
                    "status_calls": state["status"],
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()
