from __future__ import annotations

import re

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)


def test_withdraw_submit_fires_post_request(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page()
    posted = {"done": False}
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)
        page.route(
            "**/api/withdraw/list**",
            lambda route: route.fulfill(
                status=200, json={"items": [], "next_cursor": None}
            ),
        )

        def on_request(route):
            assert route.request.method == "POST"
            posted["done"] = True
            route.fulfill(
                status=200,
                json={
                    "id": 1,
                    "status": "PENDING",
                    "amount": "10.00000000",
                    "created_at": "2026-06-01T00:00:00Z",
                    "updated_at": "2026-06-01T00:00:00Z",
                    "hold_applied": True,
                    "refund_applied": False,
                },
            )

        page.route("**/api/withdraw/request", on_request)
        goto(page, "/withdraw")
        page.locator(
            "input[type='number'], input[inputmode='decimal']"
        ).first.fill("10")
        page.locator(
            "button[type='submit'], button",
            has_text=re.compile("вывест|withdraw|submit|создать", re.I),
        ).first.click()
        page.wait_for_timeout(800)
        assert posted[
            "done"
        ], "POST /api/withdraw/request was not called"
    finally:
        browser.close()
