from __future__ import annotations

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
    write_interaction_evidence,
)


def _panel(panel_id: int) -> dict[str, object]:
    return {
        "id": panel_id,
        "public_id": f"ID{panel_id:08d}",
        "activated_at": "2026-07-16T10:00:00+00:00",
        "created_at": "2026-07-16T10:00:00+00:00",
        "expires_at": "2027-01-12T10:00:00+00:00",
        "archived_at": None,
        "remaining_seconds": 15552000,
        "base_gen_per_sec": "0.00000692",
        "generated_kwh": "0.00000000",
        "is_active": True,
    }


def test_panel_activation_refreshes_list_and_sends_idempotency(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    state = {"activated": False, "post": False, "list_calls": 0}
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)

        def on_summary(route):
            route.fulfill(
                status=200,
                json={
                    "active_count": 2 if state["activated"] else 1,
                    "total_generated_by_panels": "0.00000000",
                    "nearest_expire_at": "2027-01-12T10:00:00+00:00",
                },
            )

        def on_active(route):
            state["list_calls"] += 1
            items = [_panel(1)]
            if state["activated"]:
                items.append(_panel(2))
            route.fulfill(
                status=200,
                json={
                    "items": items,
                    "next_cursor": None,
                    "server_now_utc": "2026-07-16T10:00:00+00:00",
                },
            )

        page.route("**/api/user/me/panels-summary", on_summary)
        page.route("**/api/panels/active**", on_active)
        page.route(
            "**/api/panels/archive**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [],
                    "next_cursor": None,
                    "server_now_utc": "2026-07-16T10:00:00+00:00",
                },
            ),
        )

        def on_activate(route):
            assert route.request.method == "POST"
            assert route.request.headers.get("idempotency-key")
            state["post"] = True
            state["activated"] = True
            route.fulfill(
                status=200,
                json={
                    "panel": {
                        "id": 2,
                        "public_id": "ID00000002",
                        "activated_at": "2026-07-16T10:00:00+00:00",
                        "expires_at": "2027-01-12T10:00:00+00:00",
                    },
                    "server_now_utc": "2026-07-16T10:00:00+00:00",
                },
            )

        page.route("**/api/panels/activate", on_activate)
        goto(page, "/panels")
        page.wait_for_selector("text=ID00000001")
        page.locator(
            "[data-panel-activation-cta='100-efhc']"
        ).click()
        page.wait_for_selector("text=ID00000002")
        assert state["post"] is True
        assert state["list_calls"] >= 2
        assert page.evaluate(
            "document.documentElement.scrollWidth <= window.innerWidth"
        )
        write_interaction_evidence(
            page,
            slug="panels_activation",
            route="/panels",
            action="activate one panel for 100 EFHC",
            details={
                "idempotency_present": True,
                "list_calls": state["list_calls"],
                "new_panel_public_id": "ID00000002",
            },
        )
    finally:
        browser.close()
