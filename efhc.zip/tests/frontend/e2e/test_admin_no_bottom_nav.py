from __future__ import annotations

from ._helpers import goto, install_admin_fallback


def test_admin_bank_has_no_public_bottom_nav(chromium) -> None:
    page = chromium.launch().new_page()
    try:
        install_admin_fallback(page)
        goto(page, "/admin/bank")
        assert page.locator(".efhc-game-nav").count() == 0
    finally:
        page.context.browser.close()
