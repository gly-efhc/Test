from __future__ import annotations

import re

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)


def test_hub_deposit_button_fires_post_handoff(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page()
    posted = {"done": False}
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)

        def on_handoff(route):
            assert route.request.method == "POST"
            posted["done"] = True
            route.fulfill(
                status=200,
                json={
                    "redirect_url": "https://t.me/wallet",
                    "expires_at": "2026-06-01T00:10:00Z",
                    "transport": "external_url",
                    "mode": "signed_token",
                },
            )

        page.route("**/api/hub/efhc-handoff", on_handoff)
        goto(page, "/hub")
        page.locator(
            "button",
            has_text=re.compile("пополнить|deposit|efhc|top up", re.I),
        ).first.click()
        page.wait_for_timeout(600)
        assert posted[
            "done"
        ], "POST /api/hub/efhc-handoff was not called"
    finally:
        browser.close()
