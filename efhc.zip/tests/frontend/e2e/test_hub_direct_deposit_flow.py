from __future__ import annotations

import json
from pathlib import Path

from ._helpers import (
    assert_not_blank,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]


def _screenshot(page, name: str) -> str:
    folder = (
        ROOT / "reports/screenshots/direct_deposit_withdraw_energy_1561"
    )
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / name
    page.screenshot(path=str(target), full_page=True)
    return str(target.relative_to(ROOT))


def test_hub_and_direct_deposit_visual_interaction_flow(
    chromium,
) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(15_000)
    state = {"handoff_posts": 0}
    screenshots: list[str] = []
    try:
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        page.add_init_script(
            """
            window.__efhcOpenedLinks = [];
            window.Telegram = window.Telegram || { WebApp: {} };
            window.Telegram.WebApp = window.Telegram.WebApp || {};
            window.Telegram.WebApp.openLink = (url) => {
              window.__efhcOpenedLinks.push(String(url));
            };
            window.open = (url) => {
              window.__efhcOpenedLinks.push(String(url));
              return null;
            };
            """
        )

        def on_handoff(route):
            state["handoff_posts"] += 1
            assert route.request.method == "POST"
            route.fulfill(
                status=200,
                json={
                    "redirect_url": (
                        "https://shop.efhc.example/"
                        "browser-shop?token=e2e-token"
                    ),
                    "expires_at": "2026-07-20T12:10:00Z",
                    "transport": "external_url",
                    "mode": "signed_token",
                },
            )

        page.route("**/api/hub/efhc-handoff", on_handoff)
        page.route(
            "**/api/shopfront/bootstrap**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "mode": "handoff_bound",
                    "tg_linked": True,
                    "tg_id": 1001,
                    "wallet_linked": True,
                    "active_wallet_address": "UQE2EWALLET",
                    "wallets": [],
                    "wallet_sync_required": False,
                    "bot_open_url": None,
                    "telegram_sync_url": None,
                    "wallet_sync_url": None,
                    "storefront_mode": "browser_shop_mvp",
                    "access_mode": "telegram_handoff",
                    "future_game_entry_enabled": False,
                    "available_modules": ["catalog", "checkout"],
                    "usdt_checkout_mode": "tep74_live",
                    "flow_truth": None,
                    "active_payment": None,
                    "intent_history": [],
                },
            ),
        )
        page.route(
            "**/api/shopfront/catalog",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "sku": "EFHC-100",
                            "title": "100 EFHCm",
                            "description": "Пополнение игрового баланса",
                            "item_type": "EFHC_PACKAGE",
                            "ton_enabled": True,
                            "usdt_enabled": True,
                            "methods": {
                                "TON": {"price": "1.00000000"},
                                "USDT": {"price": "30.00000000"},
                            },
                        }
                    ]
                },
            ),
        )

        goto(page, "/")
        page.get_by_role("button", name="Прямое пополнение").click()
        page.wait_for_selector(
            '[data-direct-deposit-kind="efhc-jetton-to-efhcm"]'
        )
        direct = page.locator(
            '[data-direct-deposit-kind="efhc-jetton-to-efhcm"]'
        )
        assert "EFHC jetton" in direct.inner_text()
        assert (
            page.locator(
                '[data-direct-deposit-amount="efhc-jetton"]'
            ).count()
            == 1
        )
        screenshots.append(
            _screenshot(page, "direct_efhc_jetton_390x844_ru.png")
        )

        page.keyboard.press("Escape")
        goto(page, "/hub")
        assert_not_blank(page)
        page.wait_for_selector(
            '[data-hub-action="top-up"]'
        )
        assert page.locator(".efhc-hub-choice").count() == 2
        screenshots.append(
            _screenshot(page, "hub_top_up_390x844_ru.png")
        )
        page.locator(".efhc-hub-choice").first.click()
        page.wait_for_timeout(500)
        assert state["handoff_posts"] == 1

        goto(page, "/browser-shop?token=e2e-token")
        page.wait_for_selector(
            '[data-browser-shop-product-count]'
        )
        page.wait_for_function(
            '() => document.body.innerText.includes("100 EFHCm")'
        )
        body = page.locator("body").inner_text()
        assert "TON / GRAM" in body
        assert "USDT" in body
        screenshots.append(
            _screenshot(page, "browser_shop_ton_usdt_430x932_ru.png")
        )
        assert not page.evaluate(
            "document.documentElement.scrollWidth > window.innerWidth"
        )

        target = ROOT / "reports/generated/funding_repair_v171_36.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                {
                    "cycle": 1561,
                    "status": "PASSED",
                    "direct_deposit": "EFHC jetton -> EFHCm only",
                    "store_purchase": "TON/GRAM or USDT jetton -> EFHCm",
                    "handoff_posts": state["handoff_posts"],
                    "screenshots": screenshots,
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()
