from __future__ import annotations

import pytest

from ._helpers import assert_not_blank, goto, install_admin_fallback

ADMIN_SMOKE_ROUTES = [
    "/admin",
    "/admin/bank",
    "/admin/users",
    "/admin/withdrawals",
    "/admin/shop",
    "/admin/tasks",
    "/admin/reports",
    "/admin/diagnostics",
    "/admin/system",
    "/admin/logs",
    "/admin/panels",
    "/admin/sale-packages",
    "/admin/efhc-deposits",
    "/admin/hub",
    "/admin/referrals",
    "/admin/templates",
    "/admin/ads",
]


@pytest.mark.parametrize("path", ADMIN_SMOKE_ROUTES)
def test_admin_page_smoke(chromium, path: str) -> None:
    page = chromium.launch().new_page()
    try:
        install_admin_fallback(page)
        response = goto(page, path)
        assert response is None or response.status < 500
        assert_not_blank(page)
    finally:
        page.context.browser.close()
