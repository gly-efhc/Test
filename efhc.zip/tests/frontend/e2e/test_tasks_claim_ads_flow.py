from __future__ import annotations

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
    write_interaction_evidence,
)


def test_tasks_claim_and_ad_refresh_without_double_action(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(15_000)
    state = {
        "claim_done": False,
        "ad_done": False,
        "claim_posts": 0,
        "ad_posts": 0,
        "mine_calls": 0,
    }
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)

        page.route(
            "**/api/tasks/catalog**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "id": 1,
                            "code": "claim_task",
                            "title": "Подтверждённое задание",
                            "description": "Получите доступную награду.",
                            "bonus_efhc": "2.50000000",
                            "is_active": True,
                            "kind": "custom",
                        },
                        {
                            "id": 2,
                            "code": "watch_ad",
                            "title": "Посмотреть рекламу",
                            "description": "Просмотрите таймер до конца.",
                            "bonus_efhc": "0.01000000",
                            "is_active": True,
                            "kind": "watch_ad",
                        },
                    ]
                },
            ),
        )

        def on_mine(route):
            state["mine_calls"] += 1
            route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "id": 11,
                            "task_id": 1,
                            "status": (
                                "claimed"
                                if state["claim_done"]
                                else "approved"
                            ),
                            "progress": None,
                            "bonus_efhc": "2.50000000",
                            "can_claim": not state["claim_done"],
                            "next_available_at": None,
                        },
                        {
                            "id": 0,
                            "task_id": 2,
                            "status": (
                                "claimed"
                                if state["ad_done"]
                                else "available"
                            ),
                            "progress": None,
                            "bonus_efhc": "0.01000000",
                            "can_claim": False,
                            "next_available_at": None,
                        },
                    ]
                },
            )

        page.route("**/api/tasks/my**", on_mine)

        def on_claim(route):
            state["claim_posts"] += 1
            assert route.request.method == "POST"
            assert route.request.headers.get("idempotency-key")
            assert route.request.post_data_json == {"task_id": 1}
            state["claim_done"] = True
            route.fulfill(
                status=200,
                json={
                    "ok": True,
                    "tg_id": 1001,
                    "task_id": 1,
                    "bonus_efhc": "2.50000000",
                    "bonus_balance": "2.50000000",
                    "main_balance": "100.00000000",
                    "detail": "ok",
                },
            )

        page.route("**/api/tasks/claim", on_claim)
        page.route(
            "**/api/ads/slot?**",
            lambda route: route.fulfill(
                status=200,
                json={"token": "ads-proof-1557", "min_view_sec": 1},
            ),
        )

        def on_ad_callback(route):
            state["ad_posts"] += 1
            assert route.request.method == "POST"
            assert route.request.post_data_json == {
                "token": "ads-proof-1557"
            }
            state["ad_done"] = True
            route.fulfill(
                status=200,
                json={
                    "ok": True,
                    "bonus_efhc": "0.01000000",
                    "replayed": False,
                    "detail": "credited",
                },
            )

        page.route("**/api/ads/callback/builtin_timer", on_ad_callback)

        goto(page, "/tasks")
        page.wait_for_selector("[data-task-code='claim_task']")
        claim_button = page.locator(
            "[data-task-code='claim_task'] "
            "[data-task-action='claim-bonus']"
        )
        claim_button.click()
        page.wait_for_function(
            """() => document.querySelector(
              "[data-task-code='claim_task']"
            )?.getAttribute('data-task-status') === 'claimed'"""
        )
        assert state["claim_posts"] == 1
        assert claim_button.is_disabled()

        ad_button = page.locator(
            "[data-task-code='watch_ad'] "
            "[data-task-action='watch-ad']"
        )
        ad_button.click()
        page.wait_for_selector("[data-tasks-ad-modal='direct-open']")
        page.wait_for_function(
            """() => document.querySelector(
              "[data-ad-countdown='seconds']"
            )?.textContent?.trim().startsWith('0')"""
        )
        page.locator(
            "[role='dialog'] .efhc-modal-body button"
        ).click()
        page.wait_for_function(
            """() => document.querySelector(
              "[data-task-code='watch_ad']"
            )?.getAttribute('data-task-status') === 'claimed'"""
        )
        assert state["ad_posts"] == 1
        assert state["mine_calls"] >= 3
        assert page.evaluate(
            "document.documentElement.scrollWidth <= window.innerWidth"
        )
        font_family = page.evaluate(
            "getComputedStyle(document.body).fontFamily"
        )
        assert "Arial" in font_family

        write_interaction_evidence(
            page,
            slug="tasks_claim_ads",
            route="/tasks",
            action="claim approved task and complete timer advertisement",
            details={
                "claim_post_count": state["claim_posts"],
                "ad_post_count": state["ad_posts"],
                "my_tasks_refetch_count": state["mine_calls"],
                "claim_status": "claimed",
                "ad_status": "claimed",
                "font_family": font_family,
            },
            cycle=1557,
            archive_version="v171_32",
            folder="tasks_typography_1557",
        )
    finally:
        browser.close()
