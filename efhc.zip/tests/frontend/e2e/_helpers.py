from __future__ import annotations

import json
import os
from contextlib import suppress
from pathlib import Path
from urllib.parse import urlparse

import pytest
import requests

playwright = pytest.importorskip("playwright.sync_api")

BASE_URL = os.environ.get(
    "EFHC_E2E_BASE_URL", "http://localhost:3000"
).rstrip("/")


def _managed_url_blocklist_active() -> bool:
    root = Path("/etc/chromium/policies/managed")
    if not root.exists():
        return False
    for policy in root.glob("*.json"):
        with suppress(Exception):
            if "*" in json.loads(
                policy.read_text(encoding="utf-8")
            ).get("URLBlocklist", []):
                return True
    return False


def _proxy_local_resource(route) -> None:
    parsed = urlparse(route.request.url)
    if parsed.path.startswith("/api/"):
        route.fallback()
        return
    if parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
        route.abort()
        return
    response = requests.get(route.request.url, timeout=20)
    headers = {
        key: value
        for key, value in response.headers.items()
        if key.lower()
        not in {
            "content-encoding",
            "content-length",
            "transfer-encoding",
        }
    }
    route.fulfill(
        status=response.status_code,
        headers=headers,
        body=response.content,
    )


def goto(page, path: str):
    """Navigate to the real running application.

    Application proof is fail-closed: a browser policy, unavailable server,
    or route failure must fail the run and must never be replaced by manual
    HTML injection.
    """
    target = f"{BASE_URL}{path}"
    admin_proof = (
        os.environ.get("EFHC_E2E_ADMIN_PROOF") == "1"
        and path.startswith("/admin")
    )
    if admin_proof:
        page.add_init_script(
            f"window.__EFHC_ADMIN_PROOF_PATH__={json.dumps(path)};"
        )
    return page.goto(target, wait_until="domcontentloaded")


def install_public_fallback(page, tg_id: int = 1001) -> None:
    if _managed_url_blocklist_active():
        page.route("**/*", _proxy_local_resource)
    base_url = json.dumps(BASE_URL.rstrip("/") + "/")
    script = f"""
        try {{
          window.localStorage.setItem('__efhc_probe__', '1');
          window.localStorage.removeItem('__efhc_probe__');
        }} catch {{
          const values = new Map();
          const storage = {{
            getItem: (key) => values.has(String(key))
              ? values.get(String(key))
              : null,
            setItem: (key, value) => {{
              values.set(String(key), String(value));
            }},
            removeItem: (key) => values.delete(String(key)),
            clear: () => values.clear(),
            key: (index) => Array.from(values.keys())[index] || null,
            get length() {{ return values.size; }}
          }};
          Object.defineProperty(window, 'localStorage', {{
            configurable: true,
            value: storage
          }});
          Object.defineProperty(window, 'sessionStorage', {{
            configurable: true,
            value: storage
          }});
        }}
        if (window.location.origin === 'null') {{
          const NativeURL = window.URL;
          const proofBaseUrl = {base_url};
          class ProofURL extends NativeURL {{
            constructor(url, base) {{
              const safeBase = !base || String(base) === 'null'
                ? proofBaseUrl
                : base;
              super(url, safeBase);
            }}
          }}
          if (NativeURL.createObjectURL) {{
            ProofURL.createObjectURL = NativeURL.createObjectURL.bind(
              NativeURL
            );
          }}
          if (NativeURL.revokeObjectURL) {{
            ProofURL.revokeObjectURL = NativeURL.revokeObjectURL.bind(
              NativeURL
            );
          }}
          window.URL = ProofURL;
          const replaceState = window.history.replaceState.bind(
            window.history
          );
          const pushState = window.history.pushState.bind(window.history);
          window.history.replaceState = (state, title) => {{
            try {{ replaceState(state, title); }} catch {{
              return undefined;
            }}
          }};
          window.history.pushState = (state, title) => {{
            try {{ pushState(state, title); }} catch {{
              return undefined;
            }}
          }};
        }}
        window.localStorage.setItem('onboarding_v1_seen', '1');
        window.localStorage.setItem('efhc_settings', JSON.stringify({{
          confirm_actions: false,
          confirm_purchase: false,
          confirm_withdraw: false,
          confirm_convert: false,
          confirm_watch_ad: false,
          haptics_enabled: false,
          sfx_enabled: false,
          toasts_enabled: false,
          hide_balances: false,
          theme_mode: 'dark',
          lang: 'ru'
        }}));
        window.localStorage.setItem(
          'EFHC_USER_SETTINGS_V2',
          window.localStorage.getItem('efhc_settings')
        );
        window.Telegram = window.Telegram || {{ WebApp: {{}} }};
        window.Telegram.WebApp.initData = 'query_id=e2e';
        window.Telegram.WebApp.initDataUnsafe = {{ user: {{ id: {tg_id}, username: 'e2e_user', first_name: 'E2E' }} }};
        window.Telegram.WebApp.themeParams = {{
          bg_color: '#05070a',
          text_color: '#f7fbff',
          hint_color: '#8aa0b8',
          secondary_bg_color: '#101827',
          button_color: '#35b8ff',
          button_text_color: '#001018'
        }};
        window.Telegram.WebApp.colorScheme = 'dark';
        window.Telegram.WebApp.ready = () => undefined;
        window.Telegram.WebApp.expand = () => undefined;
        window.Telegram.WebApp.showConfirm = async () => true;
        window.Telegram.WebApp.showPopup = (_opts, cb) => cb && cb('ok');
        window.Telegram.WebApp.openLink = (url) => window.open(url, '_blank', 'noopener,noreferrer');
        """
    page.add_init_script(script)
    page.evaluate(script)


def install_admin_fallback(page) -> None:
    install_public_fallback(page, tg_id=1)
    script = """
        window.localStorage.setItem('EFHC_ADMIN_ID', '1');
        window.localStorage.setItem('EFHC_ADMIN_TOKEN', 'e2e-token');
    """
    page.add_init_script(script)
    page.evaluate(script)


def install_common_public_api_mocks(page) -> None:
    snapshot = {
        "profile": {
            "global_id": "0000001001",
            "tg_id": 1001,
            "username": "e2e_user",
            "is_vip": False,
            "has_activ": True,
            "main_balance": "100.00000000",
            "bonus_balance": "0.00000000",
            "available_kwh": "100.00000000",
            "total_generated_kwh": "100.00000000",
            "gen_per_sec_base": "0.00000692",
            "gen_per_sec_vip": "0.00000741",
        },
        "panels": {
            "active_count": 1,
            "total_generated_by_panels": "0.00000000",
            "nearest_expire_at": None,
        },
        "exchange_preview": {
            "ok": True,
            "available_kwh": "100.00000000",
            "max_exchangeable_kwh": "100.00000000",
            "rate_kwh_to_efhc": "1.00000000",
            "detail": "E2E mock",
        },
        "meta": {
            "server_now_iso": "2026-06-01T00:00:00Z",
            "gen_per_sec_effective": "0.00000692",
            "next_scheduler_eta_sec": 0,
            "fallback_task_id": None,
        },
    }
    page.route(
        "**/api/sync/me**",
        lambda route: route.fulfill(status=200, json=snapshot),
    )
    page.route(
        "**/api/wallets/me**",
        lambda route: route.fulfill(
            status=200,
            json={
                "is_connected": True,
                "wallets": [
                    {
                        "id": 1,
                        "wallet_address": "UQtest1234567890",
                        "wallet_app": "e2e",
                        "is_primary": True,
                        "is_active": True,
                        "created_at": "2026-06-01T00:00:00Z",
                    }
                ],
            },
        ),
    )
    page.route(
        "**/api/wallets/balance-history**",
        lambda route: route.fulfill(
            status=200, json={"items": [], "next_cursor": None}
        ),
    )
    page.route(
        "**/api/wallets/tonconnect/proof-payload",
        lambda route: route.fulfill(
            status=200,
            json={
                "ton_proof_payload": "e2e-proof",
                "payload_token": "e2e-token",
                "expires_at": "2026-07-16T23:59:59Z",
                "domain": "127.0.0.1",
            },
        ),
    )
    page.route(
        "**/api/skins/my",
        lambda route: route.fulfill(
            status=200,
            json={"active_skin_id": 0, "owned": []},
        ),
    )
    page.route(
        "**/api/skins/switcher",
        lambda route: route.fulfill(
            status=200,
            json={
                "current_level": 1,
                "available_skin_ids": [],
                "active_skin_id": 0,
                "items": [],
            },
        ),
    )
    page.route(
        "https://config.ton.org/wallets-v2.json",
        lambda route: route.fulfill(status=200, json=[]),
    )


def assert_not_blank(page) -> None:
    body = page.locator("body")
    assert body.count() == 1
    assert len((body.inner_text() or "").strip()) > 0


def write_interaction_evidence(
    page,
    *,
    slug: str,
    route: str,
    action: str,
    details: dict[str, object],
    cycle: int = 1556,
    archive_version: str = "v171_31",
    folder: str = "panels_exchange_1556",
) -> None:
    root = Path(__file__).resolve().parents[3]
    screenshots = root / "reports" / "screenshots" / folder
    generated = root / "reports" / "generated"
    screenshots.mkdir(parents=True, exist_ok=True)
    generated.mkdir(parents=True, exist_ok=True)
    screenshot = screenshots / f"{slug}.png"
    page.screenshot(path=str(screenshot), full_page=True)
    metrics = page.evaluate(
        """() => ({
          bodyNotBlank: Boolean(document.body.innerText.trim()),
          splashVisible: Boolean(
            document.querySelector('[data-splash-visible="true"]')
          ),
          horizontalOverflow:
            document.documentElement.scrollWidth > window.innerWidth,
          width: window.innerWidth,
          height: window.innerHeight,
          lang: document.documentElement.lang
        })"""
    )
    payload = {
        "cycle": cycle,
        "route": route,
        "action": action,
        "status": "PASSED",
        "screenshot": str(screenshot.relative_to(root)),
        "metrics": metrics,
        "details": details,
    }
    target = generated / (
        f"{slug}_interaction_proof_{archive_version}.json"
    )
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
