from __future__ import annotations

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
    write_interaction_evidence,
)


def test_exchange_convert_updates_preview_and_sends_idempotency(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    posted: dict[str, object] = {"done": False}
    preview_calls = {"count": 0}
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)

        def on_snapshot(route):
            converted = bool(posted["done"])
            route.fulfill(
                status=200,
                json={
                    "profile": {
                        "tg_id": 1001,
                        "username": "e2e_user",
                        "is_vip": False,
                        "has_activ": True,
                        "main_balance": (
                            "110.00000000"
                            if converted
                            else "100.00000000"
                        ),
                        "bonus_balance": "0.00000000",
                        "available_kwh": (
                            "90.00000000"
                            if converted
                            else "100.00000000"
                        ),
                        "total_generated_kwh": "100.00000000",
                        "gen_per_sec_base": "0.00000692",
                        "gen_per_sec_vip": "0.00000741",
                    },
                    "panels": {
                        "active_count": 1,
                        "total_generated_by_panels": "0.00000000",
                        "nearest_expire_at": None,
                    },
                    "exchange_preview": {
                        "ok": True,
                        "available_kwh": (
                            "90.00000000"
                            if converted
                            else "100.00000000"
                        ),
                        "max_exchangeable_kwh": (
                            "90.00000000"
                            if converted
                            else "100.00000000"
                        ),
                        "rate_kwh_to_efhc": "1.00000000",
                        "detail": "E2E mock",
                    },
                    "meta": {
                        "server_now_iso": "2026-06-01T00:00:00Z",
                        "gen_per_sec_effective": "0.00000692",
                        "next_scheduler_eta_sec": 0,
                        "fallback_task_id": None,
                    },
                },
            )

        page.route("**/api/sync/user/**", on_snapshot)

        def on_preview(route):
            preview_calls["count"] += 1
            available = (
                "100.00000000"
                if preview_calls["count"] == 1
                else "90.00000000"
            )
            route.fulfill(
                status=200,
                json={
                    "ok": True,
                    "available_kwh": available,
                    "max_exchangeable_kwh": available,
                    "rate_kwh_to_efhc": "1.00000000",
                    "detail": "E2E preview",
                },
            )

        page.route("**/api/exchange/preview**", on_preview)

        def on_convert(route):
            assert route.request.method == "POST"
            posted["done"] = True
            posted["body"] = route.request.post_data_json
            posted["idempotency"] = route.request.headers.get(
                "idempotency-key"
            )
            route.fulfill(
                status=200,
                json={
                    "ok": True,
                    "exchanged_kwh": "10.00000000",
                    "credited_efhc": "10.00000000",
                    "new_available_kwh": "90.00000000",
                    "new__main__balance": "110.00000000",
                    "log_id": 501,
                    "detail": "converted",
                },
            )

        page.route("**/api/exchange/convert", on_convert)
        goto(page, "/exchange")
        input_box = page.locator(
            "[data-exchange-amount-input='kwh'], input[inputmode='decimal']"
        ).first
        input_box.fill("10")
        page.locator(".efhc-exchange-panel button").last.click()
        page.wait_for_function(
            "() => document.body.innerText.includes('90') "
            "&& document.body.innerText.includes('110')"
        )
        assert posted["done"] is True
        assert posted["body"] == {"amount_kwh": "10.00000000"}
        assert isinstance(posted["idempotency"], str)
        assert posted["idempotency"]
        assert preview_calls["count"] >= 2
        assert page.evaluate(
            "document.documentElement.scrollWidth <= window.innerWidth"
        )
        write_interaction_evidence(
            page,
            slug="exchange_convert",
            route="/exchange",
            action="convert 10 kWh to 10 EFHC",
            details={
                "request_body": posted["body"],
                "idempotency_present": True,
                "preview_calls": preview_calls["count"],
                "visible_available_kwh": "90.00000000",
                "visible_primary_balance": "110.00000000",
            },
        )
    finally:
        browser.close()
