from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]
MANIFEST = (
    ROOT
    / "reports/generated/public_browser_screenshot_capture_manifest_v169_42.json"
)


def _load_manifest() -> dict:
    return json.loads(MANIFEST.read_text(encoding="utf-8"))


@pytest.mark.parametrize(
    "route_entry",
    _load_manifest()["public_routes"],
    ids=lambda item: item["slug"],
)
@pytest.mark.parametrize(
    "device", _load_manifest()["devices"], ids=lambda item: item["id"]
)
def test_public_screenshot_capture_manifest(
    chromium, route_entry: dict, device: dict
) -> None:
    if os.environ.get("EFHC_CAPTURE_SCREENSHOTS") != "1":
        pytest.skip(
            "Set EFHC_CAPTURE_"
            "SCREENSHOTS=1 to write screenshot evidence files."
        )

    output_root = Path(
        os.environ.get(
            "EFHC_SCREENSHOT_OUTPUT_DIR",
            str(ROOT / "reports/screenshots/public_ui"),
        )
    )
    target_dir = output_root / route_entry["slug"]
    target_dir.mkdir(parents=True, exist_ok=True)
    target_file = target_dir / f"{device['id']}.png"

    browser = chromium.launch()
    page = browser.new_page(viewport=device["viewport"])
    try:
        install_public_fallback(page)
        install_common_public_api_mocks(page)
        page.add_init_script(
            f"""
            window.localStorage.setItem('efhc_settings', JSON.stringify({{
              theme_mode: '{device['theme']}',
              lang: '{device['locale']}',
              hide_balances: false,
              haptics_enabled: false,
              sfx_enabled: false,
              toasts_enabled: false
            }}));
            """
        )
        response = goto(page, route_entry["route"])
        assert response is None or response.status < 500
        body_text = (page.locator("body").inner_text() or "").strip()
        assert (
            body_text
        ), f"Blank public screen for {route_entry['route']}"
        assert page.locator(".efhc-admin-shell").count() == 0
        assert (
            "diagnostics" not in body_text.lower()
            or route_entry["route"] != "/"
        )
        page.screenshot(path=str(target_file), full_page=True)
        assert target_file.exists() and target_file.stat().st_size > 0
    finally:
        browser.close()
