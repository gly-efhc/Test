from __future__ import annotations

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
    write_interaction_evidence,
)


def _rank(
    tg_id: int,
    username: str | None,
    generated: str,
    rank_pos: int,
    *,
    vip: bool = False,
) -> dict[str, object]:
    return {
        "tg_id": tg_id,
        "username": username,
        "total_generated_kwh": generated,
        "rank_pos": rank_pos,
        "is_vip": vip,
        "active_referrals": 0,
    }


def test_referrals_ranks_share_and_navigation_evidence(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.set_default_timeout(12_000)
    state = {
        "rank_calls": 0,
        "stats_calls": 0,
    }
    try:
        install_public_fallback(page, tg_id=1001)
        page.add_init_script(
            """
            window.Telegram = window.Telegram || { WebApp: {} };
            window.Telegram.WebApp = window.Telegram.WebApp || {};
            window.Telegram.WebApp.initDataUnsafe = {
              user: {
                id: 1001,
                username: 'e2e_user',
                first_name: 'E2E'
              },
              start_param: 'ref_ABC123'
            };
            window.__efhcOpenedLinks = [];
            window.Telegram.WebApp.openLink = (url) => {
              window.__efhcOpenedLinks.push(String(url));
            };
            window.__efhcClipboard = [];
            Object.defineProperty(navigator, 'clipboard', {
              configurable: true,
              value: {
                writeText: async (value) => {
                  window.__efhcClipboard.push(String(value));
                }
              }
            });
            """
        )
        install_common_public_api_mocks(page)


        def on_stats(route):
            state["stats_calls"] += 1
            route.fulfill(
                status=200,
                json={
                    "bonus_balance": "7.50000000",
                    "referrals_bonus_total": "12.30000000",
                    "total_referrals": 108,
                    "active_referrals": 105,
                    "inactive_referrals": 3,
                    "level": 2,
                    "current_level_min": 100,
                    "next_level": 3,
                    "next_level_min": 1000,
                    "refs_to_next": 895,
                    "progress": 0.0055555556,
                    "unit_bonus_per_active": "0.10000000",
                    "max_active_for_unit_bonus": 10000,
                    "bonus_asset": "EFHCb",
                    "full_cycle_direct_bonus": "1000.00000000",
                    "full_cycle_level_bonus": "1411.00000000",
                    "full_cycle_total_bonus": "2411.00000000",
                    "level_steps": [
                        {
                            "level": 1,
                            "required_active": 10,
                            "level_bonus": "1.00000000",
                            "direct_bonus_total": "1.00000000",
                            "cumulative_level_bonus": "1.00000000",
                            "cumulative_total_reward": "2.00000000",
                        },
                        {
                            "level": 2,
                            "required_active": 100,
                            "level_bonus": "10.00000000",
                            "direct_bonus_total": "10.00000000",
                            "cumulative_level_bonus": "11.00000000",
                            "cumulative_total_reward": "21.00000000",
                        },
                        {
                            "level": 3,
                            "required_active": 1000,
                            "level_bonus": "100.00000000",
                            "direct_bonus_total": "100.00000000",
                            "cumulative_level_bonus": "111.00000000",
                            "cumulative_total_reward": "211.00000000",
                        },
                        {
                            "level": 4,
                            "required_active": 3000,
                            "level_bonus": "300.00000000",
                            "direct_bonus_total": "300.00000000",
                            "cumulative_level_bonus": "411.00000000",
                            "cumulative_total_reward": "711.00000000",
                        },
                        {
                            "level": 5,
                            "required_active": 10000,
                            "level_bonus": "1000.00000000",
                            "direct_bonus_total": "1000.00000000",
                            "cumulative_level_bonus": "1411.00000000",
                            "cumulative_total_reward": "2411.00000000",
                        },
                    ],
                    "referral_code": "ABC123",
                    "referral_link": (
                        "https://t.me/efhc_bot?start=ref_ABC123"
                    ),
                },
            )

        page.route("**/api/referrals/stats/me", on_stats)
        page.route(
            "**/api/referrals/active/me**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "child_tg_id": 2001,
                            "tg_id": 2001,
                            "username": "active_friend",
                            "joined_at": "2026-07-01T00:00:00Z",
                            "is_active": True,
                            "total_generated_kwh": "10.00000000",
                            "panels_count": 1,
                        }
                    ],
                    "next_cursor": None,
                },
            ),
        )
        page.route(
            "**/api/referrals/inactive/me**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "items": [
                        {
                            "child_tg_id": 2002,
                            "tg_id": 2002,
                            "username": "inactive_friend",
                            "joined_at": "2026-07-02T00:00:00Z",
                            "is_active": False,
                            "total_generated_kwh": "0.00000000",
                            "panels_count": 0,
                        }
                    ],
                    "next_cursor": None,
                },
            ),
        )

        def on_ranks(route):
            state["rank_calls"] += 1
            route.fulfill(
                status=200,
                json={
                    "snapshot_at": "2026-07-17T12:00:00Z",
                    "me": _rank(
                        1001,
                        "e2e_user",
                        "321.50000000",
                        4,
                        vip=True,
                    ),
                    "top": [
                        _rank(2001, "leader_one", "900.00000000", 1),
                        _rank(2002, "leader_two", "700.00000000", 2),
                        _rank(2003, None, "500.00000000", 3),
                    ],
                    "next_cursor": None,
                },
            )

        page.route("**/api/ranks/my-plus-top/me**", on_ranks)

        goto(page, "/referrals")
        page.wait_for_selector("[data-referral-link-value='true']")
        page.wait_for_function("() => document.body.innerText.includes('ABC123')")
        page.wait_for_function("() => window.__efhcClipboard !== undefined")
        page.locator("[data-referral-action='copy-link']").click()
        page.locator(
            "[data-referral-share-kind='telegram']"
        ).click()

        assert page.evaluate("window.__efhcClipboard.length") == 1
        copied = page.evaluate("window.__efhcClipboard[0]")
        assert copied.endswith("start=ref_ABC123")
        opened = page.evaluate("window.__efhcOpenedLinks")
        assert len(opened) == 1
        assert opened[0].startswith("https://t.me/share/url?")
        assert state["stats_calls"] >= 1
        assert page.locator("[data-referrals-current-lvl='true']").inner_text() == "Lvl 2"
        assert page.locator("[data-referral-level-step='1']").inner_text().endswith("2 EFHCb")
        assert page.locator("[data-referrals-full-cycle='10000-plus-lvl-1-5']").inner_text().endswith("2411 EFHCb")
        assert page.locator("[data-referrals-inline-list='active']").count() == 1
        page.locator("[data-referrals-tab-button='inactive']").click()
        page.wait_for_selector("[data-referrals-inline-list='inactive']")
        page.wait_for_function(
            "() => document.body.innerText.includes('inactive_friend')"
        )

        page.locator("[data-nav-key='nav.ranks']").click()
        page.wait_for_selector("[data-ranks-my-card='true']")
        page.wait_for_selector("[data-ranks-leaderboard='top-100']")
        page.wait_for_timeout(3000)
        body_text = page.locator("body").inner_text()
        assert "321.50 kWh" in body_text, {
            "rank_calls": state["rank_calls"],
            "body": body_text[-2000:],
        }
        assert page.locator(
            "[data-ranks-card='vertical-1299']"
        ).count() == 4
        page.get_by_role("button", name="Обновить").click()
        page.wait_for_function("() => document.body.innerText.includes('900.00 kWh')")
        assert state["rank_calls"] >= 2

        assert page.locator(
            "[data-header-balance-label='EFHC']"
        ).count() == 1
        header_text = page.locator(
            "[data-header-balance-label='EFHC']"
        ).inner_text()
        assert "EFHC" in header_text
        assert "Total" not in header_text
        assert page.locator(
            "[data-efhc-energy-mark='universal-lightning']"
        ).count() >= 1
        nav_icons = page.locator("[data-app-nav-icon]")
        assert nav_icons.count() == 6
        assert sorted(nav_icons.evaluate_all(
            "els => els.map(el => el.getAttribute('data-app-nav-icon'))"
        )) == sorted([
            "energy",
            "panels",
            "exchange",
            "tasks",
            "referrals",
            "ranks",
        ])
        assert page.evaluate(
            "document.documentElement.scrollWidth <= window.innerWidth"
        )

        write_interaction_evidence(
            page,
            slug="referrals_ranks_navigation",
            route="/referrals → /ranks",
            action=(
                "copy/share referral link, load and refresh kWh "
                "leaderboard"
            ),
            details={
                "referral_stats_calls": state["stats_calls"],
                "rank_calls": state["rank_calls"],
                "copied_link": copied,
                "share_target": "telegram",
                "my_rank": 4,
                "my_generated_kwh": "321.50000000",
                "leaderboard_cards": 4,
                "header_label": "EFHC",
                "universal_energy_mark": True,
                "bottom_navigation_icons": 6,
                "horizontal_overflow": False,
            },
            cycle=1558,
            archive_version="v171_33",
            folder="referrals_ranks_navigation_1558",
        )
    finally:
        browser.close()
