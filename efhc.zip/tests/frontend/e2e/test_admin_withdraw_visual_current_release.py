from __future__ import annotations

import json
from pathlib import Path

from ._helpers import goto, install_admin_fallback

ROOT = Path(__file__).resolve().parents[3]
FOLDER = ROOT / "reports/screenshots/direct_deposit_withdraw_energy_1561"


def test_admin_withdraw_operator_visual_proof(chromium) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 768, "height": 1024})
    try:
        install_admin_fallback(page)
        item = {
            "id": 41,
            "tg_id": 1001,
            "amount_efhc": "25.00000000",
            "status": "PENDING",
            "external_address": "UQtest12345678901234567890",
            "tx_hash": None,
            "created_at": "2026-07-20T12:00:00Z",
            "processed_at": None,
            "error_message": None,
            "is_vip": False,
            "payout_asset": "EFHC",
            "tonconnect_transport_kind": "jetton_transfer",
            "jetton_master_address": "EQ_EFHC_MASTER",
            "jetton_decimals": 8,
            "fee_message_ton_amount": "50000000",
        }
        page.route(
            "**/api/admin/withdrawals**",
            lambda route: route.fulfill(status=200, json=[item]),
        )
        page.route(
            "**/api/admin/withdrawals/41/outcome-preview**",
            lambda route: route.fulfill(
                status=200,
                json={
                    "request_id": 41,
                    "withdrawal_status": "PENDING",
                    "preview_mode": "auto",
                    "bundle": {
                        "request_id": 41,
                        "tg_id": 1001,
                        "outcome_kind": "pending",
                        "locale": "ru",
                        "comment": {
                            "text": "Заявка ожидает обработки оператором.",
                            "source": "system",
                            "locale": "ru",
                        },
                        "promo": None,
                        "top_zone_enabled": False,
                        "metadata": {},
                    },
                },
            ),
        )
        goto(page, "/admin/withdrawals")
        page.wait_for_timeout(3000)
        print("ADMIN_BODY", page.locator("body").inner_text())
        page.wait_for_selector(
            '[data-admin-withdrawals-dashboard-runtime="1486"]'
        )
        assert "25" in page.locator("body").inner_text()
        assert not page.evaluate(
            "document.documentElement.scrollWidth > window.innerWidth"
        )
        FOLDER.mkdir(parents=True, exist_ok=True)
        target = FOLDER / "admin_withdrawals_768x1024_ru.png"
        page.screenshot(path=str(target), full_page=True)
        report = ROOT / "reports/generated/admin_withdraw_visual_v171_36.json"
        report.write_text(
            json.dumps(
                {
                    "cycle": 1561,
                    "status": "PASSED",
                    "route": "/admin/withdrawals",
                    "request_id": 41,
                    "operator_status": "PENDING",
                    "screenshot": str(target.relative_to(ROOT)),
                    "horizontal_overflow": False,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    finally:
        browser.close()
