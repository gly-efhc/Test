from __future__ import annotations

import json
from pathlib import Path

import pytest

from ._helpers import (
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ROOT = Path(__file__).resolve().parents[3]
HEADER_DIR = ROOT / "reports" / "screenshots" / "header_visual_1573"
PROFILE_DIR = ROOT / "reports" / "screenshots" / "profile_visual_1573"
REPORT = ROOT / "reports" / "generated" / "profile_header_visual_v171_53.json"


def _settings(lang: str) -> str:
    return json.dumps({
        "confirm_actions": False,
        "confirm_purchase": False,
        "confirm_withdraw": False,
        "confirm_convert": False,
        "confirm_watch_ad": False,
        "haptics_enabled": False,
        "sfx_enabled": False,
        "toasts_enabled": True,
        "hide_balances": False,
        "theme_mode": "dark",
        "lang": lang,
    })


def _set_lang(page, lang: str) -> None:
    payload = _settings(lang)
    page.evaluate(
        """(value) => {
          localStorage.setItem('efhc_settings', value);
          localStorage.setItem('EFHC_USER_SETTINGS_V2', value);
        }""",
        payload,
    )


def _wait_shell_ready(page) -> None:
    page.wait_for_function(
        "document.documentElement.dataset.efhcShell === 'ready'",
        timeout=20_000,
    )
    page.wait_for_selector(
        "div.fixed.inset-0.z-50",
        state="detached",
        timeout=10_000,
    )
    page.wait_for_timeout(600)


def _snapshot(*, vip: bool, activ: bool) -> dict[str, object]:
    return {
        "profile": {
            "tg_id": 1001,
            "username": "e2e_user",
            "is_vip": vip,
            "has_activ": activ,
            "main_balance": "100.00000000",
            "bonus_balance": "0",
            "available_kwh": "42.50000000",
            "total_generated_kwh": "321.50000000",
            "gen_per_sec_base": "0.00000692",
            "gen_per_sec_vip": "0.00000741",
        },
        "panels": {
            "active_count": 2,
            "total_generated_by_panels": "5.00000000",
            "nearest_expire_at": None,
        },
        "exchange_preview": {
            "ok": True,
            "available_kwh": "42.50000000",
            "max_exchangeable_kwh": "42.50000000",
            "rate_kwh_to_efhc": "1.00000000",
        },
        "meta": {
            "server_now_iso": "2026-07-22T12:00:00Z",
            "gen_per_sec_effective": "0.00000741",
            "next_scheduler_eta_sec": 0,
            "fallback_task_id": None,
        },
    }


def _install_profile_mocks(page) -> None:
    install_common_public_api_mocks(page)
    page.route(
        "**/api/wallets/balance-history**",
        lambda route: route.fulfill(
            status=200,
            json={
                "items": [
                    {
                        "id": 101,
                        "amount_efhc": "25.00000000",
                        "direction": "credit",
                        "balance_type": "main",
                        "reason": "exchange_kwh",
                        "created_at": "2026-07-18T12:00:00Z",
                    },
                    {
                        "id": 102,
                        "amount_efhc": "100.00000000",
                        "direction": "debit",
                        "balance_type": "bonus",
                        "reason": "panel_purchase",
                        "created_at": "2026-07-17T12:00:00Z",
                    },
                ],
                "next_cursor": None,
            },
        ),
    )
    page.route(
        "**/api/withdraw/list/me**",
        lambda route: route.fulfill(
            status=200,
            json={
                "items": [
                    {
                        "id": 201,
                        "tg_id": 1001,
                        "amount": "15.00000000",
                        "status": "pending",
                        "created_at": "2026-07-18T13:00:00Z",
                        "updated_at": "2026-07-18T13:00:00Z",
                    }
                ],
                "next_cursor": None,
            },
        ),
    )


@pytest.mark.visual_evidence
def test_header_and_profile_visual_1573(chromium) -> None:
    HEADER_DIR.mkdir(parents=True, exist_ok=True)
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    browser = chromium.launch()
    evidence: dict[str, list[dict[str, object]]] = {
        "header": [],
        "profile": [],
    }
    try:
        for vip, activ, name, viewport in (
            (
                False,
                False,
                "header_statuses_inactive_390x844_ru.png",
                {"width": 390, "height": 844},
            ),
            (
                True,
                True,
                "header_statuses_active_390x844_ru.png",
                {"width": 390, "height": 844},
            ),
            (
                True,
                True,
                "header_balance_full_360x800_ru.png",
                {"width": 360, "height": 800},
            ),
        ):
            page = browser.new_page(viewport=viewport)
            install_public_fallback(page)
            install_common_public_api_mocks(page)
            snapshot = _snapshot(vip=vip, activ=activ)
            page.route(
                "**/api/sync/user/**",
                lambda route, payload=snapshot: route.fulfill(
                    status=200,
                    json=payload,
                ),
            )
            goto(page, "/")
            page.wait_for_selector('[data-balance-scope="global-header"]')
            balance = page.locator('[data-balance-scope="global-header"]')
            assert balance.inner_text().replace("\n", " ")
            assert page.locator('[data-status="vip"]').inner_text() == "VIP"
            assert page.locator('[data-status="activ"]').inner_text() == "Activ"
            assert page.locator('.efhc-game-header_balance-value').inner_text() == '100.00000000'
            assert balance.evaluate("el => el.scrollWidth <= el.clientWidth + 1")
            target = HEADER_DIR / name
            page.locator('.efhc-game-header').screenshot(path=str(target))
            evidence["header"].append({
                "path": str(target.relative_to(ROOT)),
                "viewport": viewport,
                "vip": vip,
                "activ": activ,
            })
            page.close()

        page = browser.new_page(viewport={"width": 390, "height": 844})
        page.set_default_timeout(15_000)
        install_public_fallback(page, tg_id=1001)
        _install_profile_mocks(page)
        surfaces = [
            ("profile", 360, 800, "ru"),
            ("wallet", 390, 844, "de"),
            ("history", 430, 932, "de"),
            ("profile-tablet", 768, 1024, "fr"),
        ]
        for surface, width, height, lang in surfaces:
            page.set_viewport_size({"width": width, "height": height})
            _set_lang(page, lang)
            goto(page, "/web-profile")
            page.wait_for_selector('[data-public-surface="web-profile"]')
            _wait_shell_ready(page)
            if surface == "wallet":
                page.locator('[data-profile-trust-tab="wallet"]').click()
                page.wait_for_selector('[data-wallet-list-boundary]')
            elif surface == "history":
                page.locator('[data-profile-trust-tab="history"]').click()
                page.wait_for_selector('[data-history-account-timeline]')
                page.wait_for_timeout(500)
            assert page.evaluate(
                "document.documentElement.scrollWidth <= window.innerWidth"
            )
            target = PROFILE_DIR / f"{surface}_{width}x{height}_{lang}.png"
            page.screenshot(path=str(target), full_page=True)
            evidence["profile"].append({
                "surface": surface,
                "viewport": f"{width}x{height}",
                "lang": lang,
                "path": str(target.relative_to(ROOT)),
            })
        page.close()
    finally:
        browser.close()

    REPORT.write_text(
        json.dumps(
            {
                "cycle": 1573,
                "archive_version": "v171.53",
                "status": "PASSED",
                "evidence": evidence,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
