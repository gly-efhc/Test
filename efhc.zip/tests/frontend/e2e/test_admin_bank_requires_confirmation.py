from __future__ import annotations

from pathlib import Path

from ._helpers import goto, install_admin_fallback

ROOT = Path(__file__).resolve().parents[3]
SCREENSHOT = (
    ROOT
    / "reports/screenshots/interaction_load_recovery_1570/admin"
    / "admin_bank_confirmation.png"
)


def test_admin_bank_requires_confirmation_before_money_actions(
    chromium,
) -> None:
    browser = chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    try:
        install_admin_fallback(page)
        goto(page, "/admin/bank")
        page.wait_for_selector(".efhc-admin-shell")
        page.get_by_role("button", name="Начислить").click()
        page.wait_for_selector('[role="dialog"]')
        text = page.locator("body").inner_text().lower()
        assert "подтвердить mint" in text
        assert "подтверждаю" in text
        SCREENSHOT.parent.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(SCREENSHOT), full_page=True)
    finally:
        browser.close()
