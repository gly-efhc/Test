from __future__ import annotations

import json
from pathlib import Path


def test_tonconnect_manifest_exists_and_has_fields() -> None:
    p = Path("frontend/public/tonconnect-manifest.json")
    assert p.exists(), "tonconnect-manifest.json is required"
    data = json.loads(p.read_text(encoding="utf-8"))
    for k in ["url", "name", "iconUrl"]:
        assert k in data and str(data[k]).strip(), f"Missing {k}"


def test_cloudstorage_forbids_wallet_state_keys() -> None:
    p = Path("frontend/src/lib/telegram.ts")
    txt = p.read_text(encoding="utf-8")
    for needle in [
        '"wallet"',
        '"wallets"',
        '"address"',
        '"connected"',
        '"tonconnect"',
    ]:
        assert needle in txt, f"Missing CloudStorage ban: {needle}"


def test_backend_walletgate_applied_to_required_routes() -> None:
    paths = {
        "backend/app/routes/shop_routes.py": [
            "feature=\"shop_external\"",
        ],
        "backend/app/routes/deposit_routes.py": [
            "feature=\"deposit\"",
        ],
        "backend/app/routes/withdraw_routes.py": [
            "feature=\"withdraw\"",
        ],
        "backend/app/routes/lotteries_routes.py": [
            "feature=\"lotteries\"",
        ],
    }

    for fp, needles in paths.items():
        p = Path(fp)
        assert p.exists(), fp
        txt = p.read_text(encoding="utf-8")
        assert "require_wallet_connected" in txt, fp
        for n in needles:
            assert n in txt, f"Missing {n} in {fp}"


def test_shop_purchase_efhc_is_not_deposit_and_not_gated() -> None:
    # purchase-efhc is shop_internal (off-chain), not deposit.
    # It must not be gated by WalletGate by default.
    p = Path("backend/app/routes/shop_routes.py")
    txt = p.read_text(encoding="utf-8")
    assert "feature=\"deposit\"" not in txt


def test_walletgate_error_contract_is_canonical() -> None:
    # Minimal SSOT guard for WALLET_REQUIRED contract.
    p = Path("backend/app/deps.py")
    txt = p.read_text(encoding="utf-8")
    assert "WALLET_REQUIRED" in txt
    assert "status.HTTP_403_FORBIDDEN" in txt
    assert "details\": {\"feature\":" in txt
