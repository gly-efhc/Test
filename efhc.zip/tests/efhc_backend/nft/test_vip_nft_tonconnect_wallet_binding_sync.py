from __future__ import annotations

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from app.routes import me_routes
from app.services.nft_check_service import (
    NftCheckService,
    _fetch_wallet_candidates_batch,
)


class _FakeResult:
    def __init__(self, rows: list[SimpleNamespace] | None = None):
        self._rows = rows or []

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def fetchall(self):
        return list(self._rows)


class _WalletResolverDb:
    def __init__(
        self,
        *,
        binding_wallet: str | None,
        legacy_wallet: str | None,
    ) -> None:
        self.binding_wallet = binding_wallet
        self.legacy_wallet = legacy_wallet
        self.queries: list[str] = []

    async def execute(self, sql, params=None):
        query = str(sql)
        self.queries.append(query)
        if "FROM efhc_core.wallet_bindings" in query:
            rows = (
                [SimpleNamespace(wallet_address=self.binding_wallet)]
                if self.binding_wallet
                else []
            )
            return _FakeResult(rows)
        if "FROM efhc_core.users" in query:
            rows = (
                [SimpleNamespace(ton_wallet=self.legacy_wallet)]
                if self.legacy_wallet
                else []
            )
            return _FakeResult(rows)
        raise AssertionError("unexpected query: " + query)


class _WalletBatchDb:
    def __init__(self, rows: list[SimpleNamespace]) -> None:
        self.rows = rows
        self.queries: list[str] = []

    async def execute(self, sql, params=None):
        query = str(sql)
        self.queries.append(query)
        assert "WITH canonical AS" in query
        assert "wallet_bindings" in query
        assert "users.ton_wallet" in query
        assert "NOT EXISTS" in query
        return _FakeResult(self.rows)


@pytest.mark.asyncio
async def test_canonical_wallet_binding_is_used_when_user_ton_wallet_empty():
    db = _WalletResolverDb(
        binding_wallet="EQ_CANONICAL_BINDING",
        legacy_wallet=None,
    )

    wallet = await NftCheckService.get_wallet_for_user(db, tg_id=910001)  # type: ignore[arg-type]

    assert wallet == "EQ_CANONICAL_BINDING"
    assert "wallet_bindings" in db.queries[0]
    assert len(db.queries) == 1


@pytest.mark.asyncio
async def test_legacy_ton_wallet_fallback_still_works_without_binding():
    db = _WalletResolverDb(
        binding_wallet=None,
        legacy_wallet="EQ_LEGACY_USER_TON_WALLET",
    )

    wallet = await NftCheckService.get_wallet_for_user(db, tg_id=910002)  # type: ignore[arg-type]

    assert wallet == "EQ_LEGACY_USER_TON_WALLET"
    assert "wallet_bindings" in db.queries[0]
    assert "FROM efhc_core.users" in db.queries[1]


@pytest.mark.asyncio
async def test_canonical_binding_has_priority_over_legacy_ton_wallet():
    db = _WalletResolverDb(
        binding_wallet="EQ_CANONICAL_PRIORITY",
        legacy_wallet="EQ_LEGACY_SHOULD_NOT_WIN",
    )

    wallet = await NftCheckService.get_wallet_for_user(db, tg_id=910003)  # type: ignore[arg-type]

    assert wallet == "EQ_CANONICAL_PRIORITY"
    assert len(db.queries) == 1


@pytest.mark.asyncio
async def test_v1_me_triggers_stale_refresh_for_tonconnect_user(monkeypatch):
    user = SimpleNamespace(
        tg_id=910004,
        username="tonconnect_user",
        is_vip=False,
        ton_wallet=None,
        vip_checked_at=datetime.now(UTC) - timedelta(seconds=1200),
    )
    fake_db = AsyncMock()
    check_mock = AsyncMock(return_value=None)

    monkeypatch.setattr(
        me_routes,
        "get_user_by_telegram",
        AsyncMock(return_value=user),
    )
    monkeypatch.setattr(me_routes, "check_user_vip_once", check_mock)

    result = await me_routes.me(db=fake_db, tg_id=user.tg_id)  # type: ignore[arg-type]

    check_mock.assert_awaited_once_with(
        fake_db,
        tg_id=user.tg_id,
        force_refresh=False,
    )
    fake_db.commit.assert_awaited_once()
    fake_db.refresh.assert_awaited_once_with(user)
    assert result["tg_id"] == user.tg_id


@pytest.mark.asyncio
async def test_batch_scheduler_includes_wallet_bindings_users():
    db = _WalletBatchDb(
        [
            SimpleNamespace(
                tg_id=910005,
                wallet_address="EQ_BATCH_BINDING",
                wallet_source="wallet_bindings",
            )
        ]
    )

    candidates = await _fetch_wallet_candidates_batch(db, offset=0, limit=50)  # type: ignore[arg-type]

    assert [c.tg_id for c in candidates] == [910005]
    assert candidates[0].wallet_address == "EQ_BATCH_BINDING"
    assert candidates[0].wallet_source == "wallet_bindings"


@pytest.mark.asyncio
async def test_batch_scheduler_has_no_duplicate_when_both_sources_exist():
    db = _WalletBatchDb(
        [
            SimpleNamespace(
                tg_id=910006,
                wallet_address="EQ_CANONICAL_ONLY_ONCE",
                wallet_source="wallet_bindings",
            )
        ]
    )

    candidates = await _fetch_wallet_candidates_batch(db, offset=0, limit=50)  # type: ignore[arg-type]

    assert len(candidates) == 1
    assert candidates[0].tg_id == 910006
    assert candidates[0].wallet_source == "wallet_bindings"

@pytest.mark.asyncio
async def test_v1_me_does_not_create_missing_user(monkeypatch):
    fake_db = AsyncMock()
    monkeypatch.setattr(
        me_routes,
        "get_user_by_telegram",
        AsyncMock(return_value=None),
    )

    with pytest.raises(Exception) as exc:
        await me_routes.me(db=fake_db, tg_id=910099)  # type: ignore[arg-type]

    assert getattr(exc.value, "status_code", None) == 404
    assert getattr(exc.value, "detail", None) == "user_not_onboarded"
    fake_db.commit.assert_not_awaited()
