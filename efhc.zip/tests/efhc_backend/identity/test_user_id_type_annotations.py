from __future__ import annotations

from typing import get_type_hints

from app.identity import TelegramId, validate_tg_id
from app.identity.legacy_user_id import (
    UserId,
    UserIdDisplay,
    format_user_id,
    parse_user_id,
    user_id_from_database,
    user_id_to_database,
    validate_user_id,
)


def test_boundary_functions_expose_nominal_types() -> None:
    format_hints = get_type_hints(format_user_id)
    parse_hints = get_type_hints(parse_user_id)
    from_db_hints = get_type_hints(user_id_from_database)
    to_db_hints = get_type_hints(user_id_to_database)
    assert format_hints == {
        "value": UserId,
        "return": UserIdDisplay,
    }
    assert parse_hints["return"] is UserId
    assert from_db_hints["return"] is UserId
    assert to_db_hints == {"value": UserId, "return": int}


def test_provider_and_system_validators_return_distinct_types() -> None:
    user_hints = get_type_hints(validate_user_id)
    telegram_hints = get_type_hints(validate_tg_id)
    assert user_hints["return"] is UserId
    assert telegram_hints["return"] is TelegramId
    assert UserId is not TelegramId
