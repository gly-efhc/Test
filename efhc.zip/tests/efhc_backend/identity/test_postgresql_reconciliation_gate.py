"""Модульные тесты Global ID PostgreSQL reconciliation gate."""

from __future__ import annotations

from copy import deepcopy

from app.identity.reconciliation import (
    ReconciliationStatus,
    compare_financial_snapshots,
    evaluate_reconciliation,
)


def _безопасные_метрики() -> dict[str, object]:
    return {
        "количество_пользователей": 3,
        "уникальные_tg_id": 3,
        "global_id_null": 3,
        "global_id_заполнен": 0,
        "дубликаты_tg_id": 0,
        "дубликаты_global_id": 0,
        "global_id_вне_диапазона": 0,
        "legacy_pk_вне_диапазона": 0,
        "планируемые_коллизии_global_id": 0,
        "дубликаты_кошельков": 0,
        "дубликаты_idempotency": 0,
        "дубликаты_tx_hash": 0,
        "нарушения_зеркала_kwh": 0,
        "расхождение_финансового_зеркала": "0.00000000",
        "следующий_global_id_sequence": 4,
        "максимальный_legacy_pk": 3,
        "максимальный_global_id": 0,
        "orphan_записи_legacy_tg_id": {
            "panels.tg_id": 0,
            "withdraw_requests.tg_id": 0,
        },
        "сумма_main_balance": "100.00000000",
        "сумма_bonus_balance": "10.00000000",
        "сумма_available_kwh": "5.00000000",
        "сумма_total_generated_kwh": "8.00000000",
        "сумма_exchanged_kwh_total": "3.00000000",
        "сумма_bank_balance": "1000.00000000",
        "количество_панелей": 4,
        "сумма_generated_kwh_панелей": "8.00000000",
        "количество_транзакций": 6,
        "сумма_транзакций": "25.00000000",
        "количество_выводов": 1,
        "сумма_выводов": "2.00000000",
        "количество_реферальных_связей": 2,
        "сумма_реферальных_наград": "0.20000000",
    }


def test_безопасный_снимок_разрешает_следующий_этап() -> None:
    verdict = evaluate_reconciliation(_безопасные_метрики())
    assert verdict.status is ReconciliationStatus.ГОТОВО
    assert verdict.historical_backfill_allowed is True
    assert verdict.violations == ()


def test_коллизия_global_id_закрывает_шлюз() -> None:
    metrics = _безопасные_метрики()
    metrics["планируемые_коллизии_global_id"] = 1
    verdict = evaluate_reconciliation(metrics)
    assert verdict.status is ReconciliationStatus.ОТКЛОНЕНО
    assert verdict.historical_backfill_allowed is False
    assert any("коллизии" in item for item in verdict.violations)


def test_сиротская_строка_закрывает_шлюз() -> None:
    metrics = _безопасные_метрики()
    metrics["orphan_записи_legacy_tg_id"] = {"panels.tg_id": 2}
    verdict = evaluate_reconciliation(metrics)
    assert verdict.status is ReconciliationStatus.ОТКЛОНЕНО
    assert any("сирот" in item for item in verdict.violations)


def test_последовательность_не_пересекает_существующие_id() -> None:
    metrics = _безопасные_метрики()
    metrics["следующий_global_id_sequence"] = 3
    verdict = evaluate_reconciliation(metrics)
    assert verdict.status is ReconciliationStatus.ОТКЛОНЕНО
    assert any("Последовательность" in item for item in verdict.violations)


def test_финансовые_снимки_совпадают_без_округления() -> None:
    before = _безопасные_метрики()
    after = deepcopy(before)
    assert compare_financial_snapshots(before, after) == ()


def test_финансовое_изменение_обнаруживается_точно() -> None:
    before = _безопасные_метрики()
    after = deepcopy(before)
    after["сумма_main_balance"] = "100.00000001"
    differences = compare_financial_snapshots(before, after)
    assert differences == ("сумма_main_balance: изменение 1E-8",)


def test_legacy_метрики_1599_читаются_только_для_совместимости() -> None:
    metrics = _безопасные_метрики()
    metrics["user_id_null"] = metrics.pop("global_id_null")
    metrics["user_id_заполнен"] = metrics.pop("global_id_заполнен")
    metrics["дубликаты_user_id"] = metrics.pop("дубликаты_global_id")
    metrics["user_id_вне_диапазона"] = metrics.pop("global_id_вне_диапазона")
    metrics["legacy_id_вне_диапазона"] = metrics.pop("legacy_pk_вне_диапазона")
    metrics["планируемые_коллизии_user_id"] = metrics.pop(
        "планируемые_коллизии_global_id"
    )
    metrics["следующий_user_id_sequence"] = metrics.pop(
        "следующий_global_id_sequence"
    )
    metrics["максимальный_legacy_id"] = metrics.pop("максимальный_legacy_pk")
    metrics["максимальный_user_id"] = metrics.pop("максимальный_global_id")
    metrics["orphan_записи"] = metrics.pop("orphan_записи_legacy_tg_id")
    verdict = evaluate_reconciliation(metrics)
    assert verdict.status is ReconciliationStatus.ГОТОВО
