from __future__ import annotations

import json
from typing import Annotated

import pytest
from app.identity import TelegramId
from app.identity.legacy_user_id import (
    ApiExternalUserId,
    PydanticUserId,
    UserId,
    UserIdRequest,
    UserIdResponse,
)
from fastapi import FastAPI, Path
from pydantic import TypeAdapter, ValidationError


def test_pydantic_user_id_parses_to_nominal_value() -> None:
    adapter = TypeAdapter(PydanticUserId)
    value = adapter.validate_python("0000000042")
    assert value == UserId(42)
    assert isinstance(value, UserId)


@pytest.mark.parametrize(
    "value",
    [
        1,
        0,
        True,
        1.0,
        TelegramId(1),
        "0000000000",
        "000000001",
        "00000000001",
        " 0000000001",
        "0000000001 ",
        "１２３４５６７８９０",
    ],
)
def test_pydantic_user_id_rejects_noncanonical_input(
    value: object,
) -> None:
    with pytest.raises(ValidationError):
        TypeAdapter(PydanticUserId).validate_python(value)


def test_pydantic_user_id_serializes_as_ten_digit_string() -> None:
    adapter = TypeAdapter(PydanticUserId)
    value = UserId(42)
    assert adapter.dump_python(value) == "0000000042"
    assert adapter.dump_json(value) == b'"0000000042"'


def test_request_stores_user_id_and_forbids_extra_fields() -> None:
    request = UserIdRequest(user_id="0000000042")
    assert request.user_id == UserId(42)
    assert request.model_dump() == {"user_id": "0000000042"}
    with pytest.raises(ValidationError):
        UserIdRequest(
            user_id="0000000042",
            tg_id=42,
        )


def test_response_requires_nominal_user_id_factory() -> None:
    response = UserIdResponse.from_user_id(UserId(42))
    assert response.user_id == UserId(42)
    assert response.model_dump_json() == (
        '{"user_id":"0000000042"}'
    )
    with pytest.raises(ValueError):
        UserIdResponse.from_user_id(42)  # type: ignore[arg-type]


def test_json_schema_is_string_only_and_canonical() -> None:
    schema = TypeAdapter(PydanticUserId).json_schema()
    assert schema["type"] == "string"
    assert schema["pattern"] == "^[0-9]{10}$"
    assert schema["minLength"] == 10
    assert schema["maxLength"] == 10
    assert schema["format"] == "efhc-global-id"
    assert schema["examples"] == ["0000000001"]
    assert "integer" not in json.dumps(schema)


def test_temporary_fastapi_openapi_is_string_only() -> None:
    app = FastAPI()

    @app.get(
        "/contract/users/{user_id}",
        response_model=UserIdResponse,
    )
    def read_contract_user(
        user_id: Annotated[
            ApiExternalUserId,
            Path(description="EFHC system user ID"),
        ],
    ) -> UserIdResponse:
        return UserIdResponse.from_user_id(
            TypeAdapter(PydanticUserId).validate_python(user_id)
        )

    openapi = app.openapi()
    operation = openapi["paths"][
        "/contract/users/{user_id}"
    ]["get"]
    parameter = operation["parameters"][0]["schema"]
    assert parameter["type"] == "string"
    assert parameter["pattern"] == "^[0-9]{10}$"
    response_ref = operation["responses"]["200"]["content"][
        "application/json"
    ]["schema"]["$ref"]
    assert response_ref.endswith("/UserIdResponse")
    field = openapi["components"]["schemas"][
        "UserIdResponse"
    ]["properties"]["user_id"]
    assert field["type"] == "string"
    assert field["format"] == "efhc-global-id"
