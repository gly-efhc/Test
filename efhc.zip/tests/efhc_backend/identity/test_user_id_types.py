from __future__ import annotations

from dataclasses import FrozenInstanceError

import pytest
from app.identity import (
    InvalidTelegramId,
    TelegramId,
    is_tg_id,
    validate_tg_id,
)
from app.identity.legacy_user_id import (
    USER_ID_MAX,
    ExternalUserId,
    InvalidUserId,
    UserId,
    UserIdDisplay,
    format_user_id,
    is_user_id,
    parse_user_id,
    user_id_from_database,
    user_id_to_database,
    validate_user_id,
    validate_user_id_display,
)
from pydantic import TypeAdapter, ValidationError


@pytest.mark.parametrize(
    ("value", "display"),
    [
        (1, "0000000001"),
        (42, "0000000042"),
        (USER_ID_MAX, "9999999999"),
    ],
)
def test_user_id_round_trip(value: int, display: str) -> None:
    user_id = validate_user_id(value)
    assert isinstance(user_id, UserId)
    assert int(user_id) == value
    assert user_id_to_database(user_id) == value
    assert format_user_id(user_id) == display
    assert str(user_id) == display
    assert parse_user_id(display) == user_id
    assert user_id_from_database(value) == user_id


@pytest.mark.parametrize(
    "value",
    [
        0,
        -1,
        USER_ID_MAX + 1,
        True,
        False,
        1.0,
        "1",
        TelegramId(1),
    ],
)
def test_internal_user_id_rejects_invalid_values(value: object) -> None:
    with pytest.raises(InvalidUserId):
        validate_user_id(value)


@pytest.mark.parametrize(
    "value",
    [
        "0000000000",
        "1",
        "000000001",
        "00000000001",
        "+000000001",
        " 0000000001",
        "0000000001 ",
        "00000000a1",
        "１２３４５６７８９０",
        1,
        UserId(1),
    ],
)
def test_external_user_id_rejects_noncanonical_values(
    value: object,
) -> None:
    with pytest.raises(InvalidUserId):
        parse_user_id(value)


def test_format_requires_validated_nominal_type() -> None:
    with pytest.raises(InvalidUserId):
        format_user_id(1)  # type: ignore[arg-type]
    with pytest.raises(InvalidUserId):
        user_id_to_database(1)  # type: ignore[arg-type]
    with pytest.raises(InvalidUserId):
        format_user_id(TelegramId(1))  # type: ignore[arg-type]


def test_user_id_is_immutable_hashable_and_not_an_int_alias() -> None:
    user_id = UserId(7)
    assert user_id != 7
    assert user_id != TelegramId(7)
    assert {user_id: "ok"}[UserId(7)] == "ok"
    with pytest.raises(FrozenInstanceError):
        user_id.value = 8  # type: ignore[misc]


def test_display_value_is_validated_on_direct_construction() -> None:
    value = UserIdDisplay("0000000001")
    assert value == "0000000001"
    assert validate_user_id_display(value) is value
    with pytest.raises(InvalidUserId):
        UserIdDisplay("0000000000")


def test_telegram_id_is_separate_and_strict() -> None:
    telegram_id = validate_tg_id(123)
    assert isinstance(telegram_id, TelegramId)
    assert int(telegram_id) == 123
    assert telegram_id.to_provider_value() == 123
    assert validate_tg_id(telegram_id) is telegram_id
    with pytest.raises(InvalidTelegramId):
        validate_tg_id(UserId(123))
    with pytest.raises(InvalidTelegramId):
        validate_tg_id(0)
    with pytest.raises(InvalidTelegramId):
        validate_tg_id(True)


def test_type_guards_refine_only_nominal_values() -> None:
    assert is_user_id(UserId(1))
    assert not is_user_id(1)
    assert not is_user_id(TelegramId(1))
    assert is_tg_id(TelegramId(1))
    assert not is_tg_id(1)
    assert not is_tg_id(UserId(1))


def test_pydantic_external_user_id_is_strict() -> None:
    adapter = TypeAdapter(ExternalUserId)
    assert adapter.validate_python("0000000001") == "0000000001"
    with pytest.raises(ValidationError):
        adapter.validate_python(1)
    with pytest.raises(ValidationError):
        adapter.validate_python("0000000000")
    with pytest.raises(ValidationError):
        adapter.validate_python("１２３４５６７８９０")
