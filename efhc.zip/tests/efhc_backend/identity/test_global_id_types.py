"""Причинные тесты канона Global ID цикла 1602."""

from __future__ import annotations

import pytest
from app.identity import (
    ApiExternalGlobalId,
    GlobalId,
    GlobalIdRequest,
    GlobalIdResponse,
    InvalidGlobalId,
    PydanticGlobalId,
    TelegramId,
    format_global_id,
    parse_global_id,
    validate_global_id,
)
from pydantic import TypeAdapter, ValidationError


def test_global_id_имеет_строгое_десятизначное_представление() -> None:
    global_id = validate_global_id(42)
    assert global_id == GlobalId(42)
    assert format_global_id(global_id) == "0000000042"
    assert parse_global_id("0000000042") == global_id


@pytest.mark.parametrize(
    "value",
    [0, -1, 10_000_000_000, True, 1.0, "42", TelegramId(42)],
)
def test_global_id_отклоняет_невалидные_и_provider_values(
    value: object,
) -> None:
    with pytest.raises(InvalidGlobalId):
        validate_global_id(value)


def test_legacy_user_id_не_экспортируется_каноническим_api() -> None:
    import app.identity as identity
    from app.identity.legacy_user_id import UserId

    assert not hasattr(identity, "UserId")
    assert UserId is GlobalId
    assert UserId(7) == GlobalId(7)


def test_pydantic_global_id_хранит_nominal_type_и_выдаёт_строку() -> None:
    adapter = TypeAdapter(PydanticGlobalId)
    value = adapter.validate_python("0000000042")
    assert value == GlobalId(42)
    assert adapter.dump_python(value) == "0000000042"
    with pytest.raises(ValidationError):
        adapter.validate_python(TelegramId(42))


def test_global_id_envelopes_используют_каноническое_поле() -> None:
    request = GlobalIdRequest(global_id="0000000042")
    response = GlobalIdResponse.from_global_id(GlobalId(42))
    assert request.model_dump() == {"global_id": "0000000042"}
    assert response.model_dump() == {"global_id": "0000000042"}
    assert TypeAdapter(ApiExternalGlobalId).validate_python(
        "0000000042"
    ) == "0000000042"
