from __future__ import annotations

from app.identity.user_id_expand import (
    USER_ID_MAX,
    USER_ID_MIN,
    build_user_id_expand_plan,
    postgres_existing_schema_expand_sql,
)


def test_expand_constants_match_user_id_contract() -> None:
    assert USER_ID_MIN == 1
    assert USER_ID_MAX == 9_999_999_999


def test_expand_sql_is_deterministic() -> None:
    first = postgres_existing_schema_expand_sql()
    second = postgres_existing_schema_expand_sql()
    assert first == second
    assert len(first) >= 10


def test_expand_does_not_backfill_existing_rows() -> None:
    sql = "\n".join(postgres_existing_schema_expand_sql()).upper()
    assert "UPDATE EFHC_CORE.USERS SET USER_ID" not in sql
    assert build_user_id_expand_plan().backfill_performed is False
