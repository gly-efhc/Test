from __future__ import annotations

import json

from app.identity.user_id_backfill import (
    LegacyUserSnapshot,
    build_user_id_backfill_plan,
)


def test_mapping_digest_is_order_independent() -> None:
    rows = [
        LegacyUserSnapshot(legacy_id=9, user_id=None),
        LegacyUserSnapshot(legacy_id=2, user_id=20),
    ]
    first = build_user_id_backfill_plan(rows)
    second = build_user_id_backfill_plan(reversed(rows))
    assert first.mapping_sha256 == second.mapping_sha256
    assert first.decisions == second.decisions


def test_plan_is_machine_serializable() -> None:
    plan = build_user_id_backfill_plan(
        [LegacyUserSnapshot(legacy_id=1, user_id=None)]
    )
    payload = {
        "cycle": plan.cycle,
        "source_head": plan.source_head,
        "target_head": plan.target_head,
        "apply_enabled": plan.apply_enabled,
        "mapping_sha256": plan.mapping_sha256,
    }
    encoded = json.dumps(payload, sort_keys=True)
    assert "EFHC_Bot_v171_95.zip" in encoded
    assert '"apply_enabled": false' in encoded
