# -*- coding: utf-8 -*-
"""Canon guard: project must not contain legacy words.

This is a FIRST-LAUNCH canonical rename to 'ranks' everywhere.
"""

from __future__ import annotations

from pathlib import Path


FORBIDDEN = ("ra" + "ting", "rei" + "ting")


def test_no_legacy_words_present() -> None:
    repo = Path(__file__).resolve().parents[3]  # repo root
    # skip binary / build dirs
    skip_dirs = {
        ".git",
        ".venv",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
    }

    offenders: list[str] = []
    for p in repo.rglob("*"):
        if p.is_dir():
            continue
        if any(part in skip_dirs for part in p.parts):
            continue
        bin_exts = {
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".webp",
            ".ico",
            ".pdf",
            ".zip",
            ".woff",
            ".woff2",
            ".ttf",
        }
        if p.suffix.lower() in bin_exts:
            continue
        try:
            data = p.read_text(encoding="utf-8")
        except Exception:
            continue
        low = data.lower()
        if any(w in low for w in FORBIDDEN):
            offenders.append(str(p.relative_to(repo)))

    assert offenders == [], (
        "Legacy words found: " + ", ".join(offenders)
    )
