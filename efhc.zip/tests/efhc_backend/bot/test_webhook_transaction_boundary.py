import sys
from types import ModuleType, SimpleNamespace
from typing import Any

import pytest
from app.routes import system_routes
from fastapi import HTTPException

pytestmark = pytest.mark.asyncio


class FakeDb:
    def __init__(self) -> None:
        self.calls: list[str] = []

    async def commit(self) -> None:
        self.calls.append("commit")

    async def rollback(self) -> None:
        self.calls.append("rollback")

    async def execute(self, *_args: Any, **_kwargs: Any) -> None:
        self.calls.append("execute")


class FakeRequest:
    def __init__(self, payload: dict[str, Any]) -> None:
        self.state = SimpleNamespace(_raw_body=None)
        self._payload = payload

    async def json(self) -> dict[str, Any]:
        return self._payload


async def test_webhook_success_commits_after_process_update(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db = FakeDb()

    async def fake_register(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
        return {"is_duplicate": False, "event_id": "evt-1"}

    async def fake_process_update(**kwargs: Any) -> None:
        assert kwargs["db"] is db
        assert kwargs["payload"] == {"update_id": 1}

    monkeypatch.setattr(
        system_routes,
        "register_external_event_after_secret",
        fake_register,
    )
    fake_bot_module = ModuleType("app.bot.bot")
    fake_bot_module.process_update = fake_process_update
    monkeypatch.setitem(sys.modules, "app.bot.bot", fake_bot_module)

    result = await system_routes.telegram_webhook(
        FakeRequest({"update_id": 1}),
        db=db,
    )

    assert result == {"status": "ok"}
    assert db.calls == ["commit"]


async def test_webhook_error_rolls_back_before_cleanup_commit(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db = FakeDb()

    async def fake_register(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
        return {"is_duplicate": False, "event_id": "evt-2"}

    async def fake_process_update(**_kwargs: Any) -> None:
        raise RuntimeError("handler failed")

    monkeypatch.setattr(
        system_routes,
        "register_external_event_after_secret",
        fake_register,
    )
    fake_bot_module = ModuleType("app.bot.bot")
    fake_bot_module.process_update = fake_process_update
    monkeypatch.setitem(sys.modules, "app.bot.bot", fake_bot_module)

    with pytest.raises(HTTPException):
        await system_routes.telegram_webhook(
            FakeRequest({"update_id": 2}),
            db=db,
        )

    assert db.calls[:3] == ["rollback", "execute", "commit"]
