# tests/backend/integration

Папка добавлена по канонической схеме репозитория.
