from __future__ import annotations

from decimal import Decimal

import pytest
from app.services import referral_service

pytestmark = pytest.mark.asyncio


async def test_unit_reward_calls_active_counter_with_single_db_argument(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db = object()
    calls: list[tuple[object, int]] = []
    credit_calls: list[dict[str, object]] = []

    async def _resolve_owner(
        candidate_db, *, global_id=None, tg_id=None
    ):
        assert candidate_db is db
        value = int(global_id if global_id is not None else tg_id)
        return referral_service._ReferralOwner(
            global_id=value,
            tg_id=(int(tg_id) if tg_id is not None else value),
        )

    async def _count(
        candidate_db, inviter_global_id: int, legacy_tg_id=None
    ) -> int:
        calls.append((candidate_db, int(inviter_global_id)))
        return 1

    async def _choose(candidate_db, *, canonical_key, legacy_key=None):
        assert candidate_db is db
        from app.identity.idempotency_compat import (
            CompatibleIdempotencyKey,
        )
        return CompatibleIdempotencyKey(
            selected=str(legacy_key or canonical_key),
            canonical=str(canonical_key),
            legacy=legacy_key,
            matched_existing=False,
        )

    async def _credit(**kwargs) -> None:
        credit_calls.append(kwargs)

    monkeypatch.setattr(
        referral_service,
        "_resolve_referral_owner",
        _resolve_owner,
    )
    monkeypatch.setattr(
        referral_service,
        "_count_active_referrals_global",
        _count,
    )
    monkeypatch.setattr(
        referral_service,
        "choose_compatible_idempotency_key",
        _choose,
    )
    monkeypatch.setattr(
        referral_service,
        "credit_user_bonus_from_bank_nocommit",
        _credit,
    )

    await referral_service._maybe_reward_active_unit_bonus(
        db,
        inviter_tg_id=901001,
        buyer_tg_id=901002,
    )

    assert calls == [(db, 901001)]
    assert len(credit_calls) == 1
    assert credit_calls[0]["db"] is db
    assert credit_calls[0]["global_id"] == 901001
    assert credit_calls[0]["amount"] == Decimal("0.10000000")
    assert credit_calls[0]["reason"] == "referral_active_unit"
    assert credit_calls[0]["idempotency_key"] == "REF_ACT_UNIT:901002"
