from __future__ import annotations

from pathlib import Path

from app.lib.ton_address import (
    canonicalize_ton_address,
    to_friendly_ton_address,
)

RAW = "0:" + "fb" * 32


def test_raw_and_friendly_same_wallet_normalize_to_same_canonical() -> None:
    friendly = to_friendly_ton_address(RAW, bounceable=True)
    assert canonicalize_ton_address(RAW) == canonicalize_ton_address(
        friendly
    )


def test_bounceable_and_nonbounceable_same_wallet_normalize_same() -> None:
    bounceable = to_friendly_ton_address(RAW, bounceable=True)
    nonbounceable = to_friendly_ton_address(RAW, bounceable=False)
    assert canonicalize_ton_address(bounceable) == canonicalize_ton_address(
        nonbounceable
    )


def test_base64_and_base64url_same_wallet_normalize_same() -> None:
    base64url = to_friendly_ton_address(RAW, url_safe=True)
    base64_std = to_friendly_ton_address(RAW, url_safe=False)
    assert canonicalize_ton_address(base64url) == canonicalize_ton_address(
        base64_std
    )


def test_wallet_binding_stores_canonical_address() -> None:
    src = Path("backend/app/services/wallets_service.py").read_text()
    assert "canonicalize_ton_address" in src
    assert "addr = normalize_wallet_address(address)" in src
    assert "INSERT INTO efhc_core.wallet_bindings" in src


def test_wallet_conflict_check_uses_canonical_address() -> None:
    src = Path("backend/app/services/wallets_service.py").read_text()
    block = src.split("addr = normalize_wallet_address(address)", 1)[1]
    block = block.split("q_find = text", 1)[0]
    assert "WHERE wallet_address = :addr" in block


def test_watcher_lookup_uses_canonical_address() -> None:
    src = Path("backend/app/services/watcher_service.py").read_text()
    body = src.split("async def _find_user_by_wallet", 1)[1]
    body = body.split("async def _find_user_by_tg_id", 1)[0]
    assert "_norm_addr(addr)" in body
    assert "WHERE wb.wallet_address = :wa" in body
    assert "proof_verified = TRUE" in body


def test_ui_can_display_friendly_without_affecting_canonical() -> None:
    friendly = to_friendly_ton_address(RAW)
    assert friendly != RAW
    assert canonicalize_ton_address(friendly) == RAW
