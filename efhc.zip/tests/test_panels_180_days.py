from __future__ import annotations

import importlib
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import text

def _reload_panels_service():
    # Reload panels service to pick up canon env (efhc_core/efhc_admin) from conftest
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()
    import backend.app.services.panels_service as ps
    ps = importlib.reload(ps)
    return ps


@pytest.mark.asyncio
async def test_panels_expires_exactly_180_days_utc(db_session, db_clean) -> None:
    ps = _reload_panels_service()
    tg_id = 3001

    await db_session.execute(
        text("INSERT INTO efhc_core.users (tg_id, main_balance, bonus_balance) VALUES (:tg, 200.0, 0.0)"),
        {"tg": tg_id},
    )
    await db_session.commit()

    out = await ps.create_panel_for_user(db_session, tg_id=tg_id, idempotency_key="life-180")
    await db_session.commit()

    r = await db_session.execute(
        text("SELECT activated_at, expires_at FROM efhc_core.panels WHERE id=:pid"),
        {"pid": int(out["id"])},
    )
    row = r.fetchone()
    assert row is not None
    act = row[0]
    exp = row[1]
    # Ensure tz-aware UTC
    assert act.tzinfo is not None
    assert exp.tzinfo is not None
    assert act.utcoffset() == timedelta(0)
    assert exp.utcoffset() == timedelta(0)
    assert exp - act == timedelta(days=180)
