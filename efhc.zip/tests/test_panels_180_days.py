from __future__ import annotations

from datetime import timedelta

import pytest
from sqlalchemy import text

from tests.panels_testkit import (
    reload_panels_service,
    seed_user_with_balances,
)

pytestmark = pytest.mark.asyncio


async def test_panels_expires_exactly_180_days_utc(
    db_session,
    db_clean,
) -> None:
    ps = reload_panels_service()
    tg_id = 3001

    await seed_user_with_balances(
        db_session,
        tg_id=tg_id,
        main_balance="200.0",
    )

    out = await ps.create_panel_for_user(
        db_session, tg_id=tg_id, idempotency_key="life-180"
    )
    await db_session.commit()

    r = await db_session.execute(
        text(
            "SELECT activated_at, expires_at FROM efhc_core.panels "
            "WHERE id=:pid"
        ),
        {"pid": int(out["id"])},
    )
    row = r.fetchone()
    assert row is not None
    act = row[0]
    exp = row[1]
    # Ensure tz-aware UTC
    assert act.tzinfo is not None
    assert exp.tzinfo is not None
    assert act.utcoffset() == timedelta(0)
    assert exp.utcoffset() == timedelta(0)
    assert exp - act == timedelta(days=180)
