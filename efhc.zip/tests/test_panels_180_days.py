from __future__ import annotations

import importlib
import os
from datetime import datetime, timedelta, timezone

import pytest

def _get_async_db_url() -> str:
    db_url = os.getenv("ASYNC_DATABASE_URL") or os.getenv("DATABASE_URL")
    if not db_url:
        pytest.skip("ASYNC_DATABASE_URL/DATABASE_URL required", allow_module_level=True)
    if db_url.startswith("postgresql+psycopg://"):
        db_url = "postgresql+asyncpg://" + db_url[len("postgresql+psycopg://"):]
    if db_url.startswith("postgresql://"):
        db_url = "postgresql+asyncpg://" + db_url[len("postgresql://"):]
    if db_url.startswith("postgres://"):
        db_url = "postgresql+asyncpg://" + db_url[len("postgres://"):]
    if db_url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return db_url
    return db_url


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    # SQLite is forbidden in Postgres-only CI canon
    pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return


def _reload_panels_service_for_sqlite():
        os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core

    importlib.reload(config_core)
    from backend.app.services import panels_service

    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_expires_exactly_180_days_utc() -> None:
    panels_service = _reload_panels_service_for_sqlite()

        db_url = _get_async_db_url()

    try:
        await _init_sqlite_schema(db_url)
        engine = create_async_engine(
            db_url,
            future=True,
                    )
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        tg_id = 3001

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO efhc_core.users (tg_id, main_balance, bonus_balance)
                    VALUES (:tg, 200.0, 0.0)
                    """
                ),
                {"tg": tg_id},
            )
            await db.commit()

        async with Session() as db:
            out = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_id,
                idempotency_key="life-180",
            )
            await db.commit()

            r = await db.execute(
                text(
                    """
                    SELECT activated_at, expires_at
                    FROM efhc_core.panels
                    WHERE id=:pid
                    """
                ),
                {"pid": int(out["id"])},
            )
            row = r.fetchone()
            assert row is not None
            act = datetime.fromisoformat(str(row[0]))
            exp = datetime.fromisoformat(str(row[1]))

            assert act.tzinfo is not None
            assert exp.tzinfo is not None
            assert act.utcoffset() == timedelta(0)
            assert exp.utcoffset() == timedelta(0)
            assert exp - act == timedelta(days=180)

        await engine.dispose()
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
