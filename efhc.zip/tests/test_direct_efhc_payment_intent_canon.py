from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_direct_efhc_intent_has_no_price_expiry_by_canon() -> None:
    text = _read("docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md")
    assert "not price protection" in text
    assert "EFHC = EFHC" in text


def test_expired_direct_efhc_intent_is_not_price_reject() -> None:
    text = _read("docs/SSOT/PAYMENT_INTENT_SSOT.md")
    assert "not price protection" in text
    assert "not\nas automatic rejection" in text


def test_same_tx_hash_for_direct_intent_is_idempotent_noop() -> None:
    text = _read("docs/NORM/PAYMENT_INTENT_FLOW_NORM.md")
    assert "same tx_hash = idempotent replay" in text


def test_two_different_tx_hashes_for_same_direct_intent() -> None:
    doc = _read("docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md")
    code = _read("backend/app/services/payment_reconciliation_service.py")
    assert "two different on-chain payments" in doc
    assert "different on-chain tx_hash" in code
    assert "intent already has a previous confirmed tx" in code


def test_direct_efhc_intent_can_end_by_allowed_events() -> None:
    text = _read("docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md")
    for phrase in ["payment execution", "cancellation", "manual closure"]:
        assert phrase in text
    assert "technical or abuse block" in text


def test_payment_intent_docs_define_expires_at() -> None:
    text = _read("docs/NORM/PAYMENT_INTENT_FLOW_NORM.md")
    assert "`expires_at` is not price protection" in text


def test_deposit_credit_idempotency_is_tx_scoped() -> None:
    code = _read("backend/app/services/payment_reconciliation_service.py")
    assert "intent:{intent_id}:confirm:{str(tx_hash)}" in code
