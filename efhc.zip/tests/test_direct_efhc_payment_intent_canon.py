from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_прямой_payment_intent_имеет_реальный_ttl() -> None:
    text = _read("docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md")
    assert "одноразовым server-owned settlement" in text
    assert "с реальным TTL" in text
    assert "exact amount" in text


def test_истекший_payment_intent_запрещает_автоматический_settlement() -> None:
    text = _read("docs/SSOT/PAYMENT_INTENT_SSOT.md")
    assert "expires_at" in text
    assert "PENDING" in text
    assert "истёк" in text or "истек" in text


def test_тот_же_tx_hash_после_confirmed_идемпотентен() -> None:
    text = _read("docs/NORM/PAYMENT_INTENT_FLOW_NORM.md")
    assert "CONFIRMED + same tx_hash" in text
    assert "идемпотентный read-through" in text


def test_другой_tx_hash_после_confirmed_требует_новый_intent() -> None:
    doc = _read("docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md")
    code = _read("backend/app/services/payment_reconciliation_service.py")
    assert "другой `tx_hash` после `CONFIRMED` — fail-closed" in doc
    assert 'status_val != "PENDING"' in code
    assert '"INTENT_NOT_PENDING"' in code


def test_payment_intent_закрывается_после_первого_settlement() -> None:
    text = _read("docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md")
    assert "После подтверждения, истечения, отмены" in text
    assert "не может использоваться для новой финансовой операции" in text


def test_expires_at_является_server_side_границей() -> None:
    text = _read("docs/NORM/PAYMENT_INTENT_FLOW_NORM.md")
    assert "реальная server-side граница" in text
    assert "expires_at" in text


def test_idempotency_финансового_credit_остаётся_tx_scoped() -> None:
    code = _read("backend/app/services/payment_reconciliation_service.py")
    assert "intent:{intent_id}:confirm:{str(tx_hash)}" in code
    lock = _read("backend/app/services/shop_payment_tx_hash_lock_service.py")
    assert "ON CONFLICT (tx_hash) DO NOTHING" in lock
