from __future__ import annotations

import importlib
import os

import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_wallets_service_for_postgres() -> object:
    if (os.getenv("DATABASE_URL") or "").startswith("sqlite"):
        pytest.fail("SQLite is forbidden by CANON")
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    import backend.app.services.wallets_service as ws
    return importlib.reload(ws)


@pytest.mark.asyncio
async def test_wallets_connect_idempotent_by_idempotency_key() -> None:
    ws = _reload_wallets_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(ws, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    addr = "EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0"

    async with Session() as db:
        r1 = await ws.connect_wallet(
            db,
            tg_id=1001,
            address=addr,
            wallet_app="tonkeeper",
            idempotency_key="k1",
        )
        r2 = await ws.connect_wallet(
            db,
            tg_id=1001,
            address=addr,
            wallet_app="tonkeeper",
            idempotency_key="k1",
        )

        assert r1["wallet_id"] == r2["wallet_id"]
        assert r1["wallet_address"] == r2["wallet_address"]

        cnt = (await db.execute(text(f"SELECT COUNT(*) FROM {schema}.wallet_bindings"))).scalar_one()
        assert int(cnt) == 1

        cnt2 = (await db.execute(text(f"SELECT COUNT(*) FROM {schema}.wallet_connect_idempotency"))).scalar_one()
        assert int(cnt2) == 1

    await engine.dispose()


@pytest.mark.asyncio
async def test_wallets_conflict_address_bound_other_tg() -> None:
    ws = _reload_wallets_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(ws, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    addr = "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"

    async with Session() as db:
        await ws.connect_wallet(
            db,
            tg_id=2001,
            address=addr,
            wallet_app=None,
            idempotency_key="k2",
        )

        with pytest.raises(ws.WalletConflict):
            await ws.connect_wallet(
                db,
                tg_id=2002,
                address=addr,
                wallet_app=None,
                idempotency_key="k3",
            )

    await engine.dispose()
