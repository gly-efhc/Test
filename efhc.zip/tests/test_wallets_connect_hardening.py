from __future__ import annotations

import asyncio
import importlib
import os
import tempfile
from datetime import datetime, timezone

import pytest



def __get_async_db_url() -> str:
    url = os.getenv("ASYNC_DATABASE_URL") or os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if not url:
        pytest.skip("DATABASE_URL/ASYNC_DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    if url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to asyncpg SQLAlchemy URL
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://"):]
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://"):]
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgresql+psycopg://"):
        return "postgresql+asyncpg://" + url[len("postgresql+psycopg://"):]
    return url

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_wallets_schema(db_url: str) -> None:
    engine = create_async_engine(
        db_url,
        future=True,

    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS efhc_core.wallet_bindings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    wallet_address TEXT NOT NULL UNIQUE,
                    wallet_app TEXT,
                    is_primary INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS
                    efhc_core.wallet_connect_idempotency (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    wallet_id INTEGER NOT NULL,
                    wallet_address TEXT NOT NULL,
                    created_at TEXT NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
                    UNIQUE (tg_id, idempotency_key)
                )
                """
            )
        )

    await engine.dispose()


def _reload_wallets_service_for_sqlite() -> object:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.wallets_service as ws

    return importlib.reload(ws)


@pytest.mark.asyncio
async def test_wallets_connect_idempotent_by_idempotency_key() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_wallets_schema(db_url)

        ws = _reload_wallets_service_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,

        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        addr = (
            "EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0"
        )

        async with Session() as db:
            r1 = await ws.connect_wallet(
                db,
                tg_id=1001,
                address=addr,
                wallet_app="tonkeeper",
                idempotency_key="k1",
            )
            r2 = await ws.connect_wallet(
                db,
                tg_id=1001,
                address=addr,
                wallet_app="tonkeeper",
                idempotency_key="k1",
            )

            assert r1["wallet_id"] == r2["wallet_id"]
            assert r1["wallet_address"] == r2["wallet_address"]

            cnt = (await db.execute(
                text("SELECT COUNT(*) FROM efhc_core.wallet_bindings")
            )).scalar_one()
            assert int(cnt) == 1

            q_cnt2 = text(
                "SELECT COUNT(*) FROM efhc_core.wallet_connect_idempotency"
            )
            cnt2 = (await db.execute(q_cnt2)).scalar_one()
            assert int(cnt2) == 1

        await engine.dispose()


@pytest.mark.asyncio
async def test_wallets_conflict_address_bound_other_tg() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_wallets_schema(db_url)

        ws = _reload_wallets_service_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,

        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        addr = (
            "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"
        )

        async with Session() as db:
            await ws.connect_wallet(
                db,
                tg_id=2001,
                address=addr,
                wallet_app=None,
                idempotency_key="k2",
            )

            with pytest.raises(ws.WalletConflict):
                await ws.connect_wallet(
                    db,
                    tg_id=2002,
                    address=addr,
                    wallet_app=None,
                    idempotency_key="k3",
                )

        await engine.dispose()
