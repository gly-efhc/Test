from __future__ import annotations

import os
import tempfile

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    create_async_engine,
)
from sqlalchemy.orm import sessionmaker

from tests.wallets_ton_testkit import (
    get_async_db_url,
    init_sqlite_wallets_schema,
    reload_wallets_service_for_sqlite,
)


async def _ensure_wallet_owner(
    db: AsyncSession,
    *,
    global_id: int,
    provider_tg_id: int,
) -> None:
    _ = provider_tg_id
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.users (
                global_id, is_active, created_at, updated_at
            ) VALUES (
                :global_id, TRUE, now(), now()
            )
            ON CONFLICT (global_id) DO UPDATE SET
                is_active = TRUE,
                updated_at = now()
            """
        ),
        {
            "global_id": int(global_id),
        },
    )
    await db.commit()


@pytest.mark.asyncio
async def test_wallets_connect_idempotent_by_idempotency_key() -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await init_sqlite_wallets_schema(db_url)

        ws = reload_wallets_service_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        addr = "EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0"

        async with Session() as db:
            await _ensure_wallet_owner(
                db, global_id=1001, provider_tg_id=1001
            )
            r1 = await ws.connect_wallet(
                db,
                global_id="0000001001",
                provider_tg_id=1001,
                address=addr,
                wallet_app="tonkeeper",
                idempotency_key="k1",
                verified_proof_payload_token="proof-token-1",
                verified_proof_source="PROOF_VERIFIED:test",
            )
            r2 = await ws.connect_wallet(
                db,
                global_id="0000001001",
                provider_tg_id=1001,
                address=addr,
                wallet_app="tonkeeper",
                idempotency_key="k1",
                verified_proof_payload_token="proof-token-1",
                verified_proof_source="PROOF_VERIFIED:test",
            )

            assert r1["wallet_id"] == r2["wallet_id"]
            assert r1["wallet_address"] == r2["wallet_address"]

            cnt = (
                await db.execute(
                    text(
                        "SELECT COUNT(*) FROM efhc_core.wallet_bindings"
                    )
                )
            ).scalar_one()
            assert int(cnt) == 1

            q_cnt2 = text(
                "SELECT COUNT(*) FROM "
                "efhc_core.wallet_connect_idempotency"
            )
            cnt2 = (await db.execute(q_cnt2)).scalar_one()
            assert int(cnt2) == 1

        await engine.dispose()


@pytest.mark.asyncio
async def test_wallets_conflict_address_bound_other_tg() -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await init_sqlite_wallets_schema(db_url)

        ws = reload_wallets_service_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        addr = "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"

        async with Session() as db:
            await _ensure_wallet_owner(
                db, global_id=2001, provider_tg_id=2001
            )
            await _ensure_wallet_owner(
                db, global_id=2002, provider_tg_id=2002
            )
            await ws.connect_wallet(
                db,
                global_id="0000002001",
                provider_tg_id=2001,
                address=addr,
                wallet_app=None,
                idempotency_key="k2",
                verified_proof_payload_token="proof-token-2",
                verified_proof_source="PROOF_VERIFIED:test",
            )

            with pytest.raises(ws.WalletConflict):
                await ws.connect_wallet(
                    db,
                    global_id="0000002002",
                    provider_tg_id=2002,
                    address=addr,
                    wallet_app=None,
                    idempotency_key="k3",
                    verified_proof_payload_token="proof-token-3",
                    verified_proof_source="PROOF_VERIFIED:test",
                )

        await engine.dispose()


@pytest.mark.asyncio
async def test_wallets_connect_requires_verified_proof() -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await init_sqlite_wallets_schema(db_url)

        ws = reload_wallets_service_for_sqlite()
        engine = create_async_engine(db_url, future=True)
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with Session() as db:
            await _ensure_wallet_owner(
                db, global_id=3001, provider_tg_id=3001
            )
            with pytest.raises(ws.WalletProofRequired):
                await ws.connect_wallet(
                    db,
                    global_id="0000003001",
                    provider_tg_id=3001,
                    address=(
                        "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHb"
                        "N_dgH-IfraFP8QKW"
                    ),
                    wallet_app=None,
                    idempotency_key="k4",
                    verified_proof_payload_token="",
                    verified_proof_source="",
                )

        await engine.dispose()


@pytest.mark.asyncio
async def test_wallets_connect_rejects_proof_replay() -> None:
    with tempfile.TemporaryDirectory():
        db_url = get_async_db_url()
        await init_sqlite_wallets_schema(db_url)

        ws = reload_wallets_service_for_sqlite()
        engine = create_async_engine(db_url, future=True)
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )
        addr1 = "EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0"
        addr2 = "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"

        async with Session() as db:
            await _ensure_wallet_owner(
                db, global_id=4001, provider_tg_id=4001
            )
            await ws.connect_wallet(
                db,
                global_id="0000004001",
                provider_tg_id=4001,
                address=addr1,
                wallet_app=None,
                idempotency_key="k5",
                verified_proof_payload_token="single-use-token",
                verified_proof_source="PROOF_VERIFIED:test",
            )
            with pytest.raises(ws.WalletProofReplay):
                await ws.connect_wallet(
                    db,
                    global_id="0000004001",
                    provider_tg_id=4001,
                    address=addr2,
                    wallet_app=None,
                    idempotency_key="k6",
                    verified_proof_payload_token="single-use-token",
                    verified_proof_source="PROOF_VERIFIED:test",
                )

        await engine.dispose()
