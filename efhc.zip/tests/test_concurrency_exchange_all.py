from __future__ import annotations

import asyncio
import importlib

import pytest

pytestmark = pytest.mark.asyncio
from app.schemas.common_schemas import d8_str  # noqa: E402
from sqlalchemy import text  # noqa: E402


def _reload_services():
    # Reload services to pick up canon env from conftest
    # (efhc_core/efhc_admin).
    from app.core import config_core
    config_core.get_settings.cache_clear()
    import app.services.transactions_service as ts
    ts = importlib.reload(ts)
    return ts


async def _ensure_user(
    db,
    *,
    tg_id: int,
    username: str = "user",
    ton_wallet: str = "",
    main_balance: str = "0.00000000",
) -> None:
    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  ton_wallet,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, exchanged_kwh_total,",
                    "  created_at, updated_at",
                    ") VALUES (",
                    "  :tg_id, :u, false, true,",
                    "  :tw,",
                    "  :mb, '0.00000000',",
                    "  '0.00000000', '0.00000000',",
                    "  NOW(), NOW()",
                    ")",
                    "ON CONFLICT (tg_id) DO NOTHING",
                ]
            )
        ),
        {
            "tg_id": tg_id,
            "u": username,
            "tw": ton_wallet,
            "mb": main_balance,
        },
    )
    await db.commit()


async def test_concurrency_double_exchange_all_no_double_credit(
    async_engine,
    db_clean,
) -> None:
    ts = _reload_services()

    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker
    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    bank_efhc_id = int(ts.BANK_EFHC)
    user_tg_id = 100001

    async with Session() as s:
        await _ensure_user(
            s,
            tg_id=bank_efhc_id,
            username="bank",
            ton_wallet="bank",
            main_balance="1000.00000000",
        )
        await _ensure_user(
            s,
            tg_id=user_tg_id,
            username="user",
            ton_wallet="w",
        )

        # Make sure user has available_kwh to exchange
        await s.execute(
            text(
                "UPDATE efhc_core.users "
                "SET total_generated_kwh=:tk, "
                "    exchanged_kwh_total='0.00000000' "
                "WHERE tg_id=:tg"
            ),
            {"tk": "10.00000000", "tg": user_tg_id},
        )
        await s.commit()

    async def _call():
        # Each concurrent call MUST use its own AsyncSession.
        async with Session() as s:
            return await ts.exchange_all_available_kwh_to_main(
                s,
                tg_id=user_tg_id,
                idempotency_key="ex-all-1",
                reason="exchange_all",
            )

    # Run two concurrent calls with same idk; no double-credit
    await asyncio.gather(
        _call(),
        _call(),
    )

    async with Session() as s:
        r = await s.execute(
            text(
                "SELECT exchanged_kwh_total, available_kwh "
                "FROM efhc_core.users "
                "WHERE tg_id=:tg"
            ),
            {"tg": user_tg_id},
        )
        row = r.fetchone()
        assert row is not None
        # available_kwh should be 0, exchanged should be 10 once
        assert d8_str(row[0]) == "10.00000000"
        assert d8_str(row[1]) == "0.00000000"
