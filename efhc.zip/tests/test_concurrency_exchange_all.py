from __future__ import annotations

import asyncio
import importlib

import pytest
from sqlalchemy import text


def _reload_services():
    # Reload services to pick up canon env from conftest (efhc_core/efhc_admin)
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()
    import backend.app.services.transactions_service as ts
    ts = importlib.reload(ts)
    return ts


async def _ensure_user(db, *, tg_id: int, username: str = "user", ton_wallet: str = "") -> None:
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.users (
                tg_id, username, is_vip, is_active,
                ton_wallet,
                main_balance, bonus_balance,
                total_generated_kwh, exchanged_kwh_total,
                available_kwh, created_at, updated_at
            ) VALUES (
                :tg_id, :u, false, true,
                :tw,
                0, 0,
                0, 0,
                :av, NOW(), NOW()
            )
            ON CONFLICT (tg_id) DO NOTHING
            """
        ),
        {"tg_id": tg_id, "u": username, "tw": ton_wallet, "av": "10.00000000"},
    )
    await db.commit()


async def test_concurrency_double_exchange_all_no_double_credit(db_session, db_clean) -> None:
    ts = _reload_services()

    bank_tg_id = int(ts.BANK_TG_ID)
    user_tg_id = 100001

    await _ensure_user(db_session, tg_id=bank_tg_id, username="bank", ton_wallet="bank")
    await _ensure_user(db_session, tg_id=user_tg_id, username="user", ton_wallet="w")

    # Make sure user has available_kwh to exchange
    await db_session.execute(
        text("UPDATE efhc_core.users SET available_kwh=:av WHERE tg_id=:tg"),
        {"av": "10.00000000", "tg": user_tg_id},
    )
    await db_session.commit()

    async def _call():
        return await ts.exchange_all_available_kwh_to_main(
            db_session,
            tg_id=user_tg_id,
            idempotency_key="ex-all-1",
            reason="exchange_all",
        )

    # Run two concurrent calls with same idempotency key; must not double-credit
    await asyncio.gather(_call(), _call())
    await db_session.commit()

    r = await db_session.execute(
        text("SELECT available_kwh, exchanged_kwh_total FROM efhc_core.users WHERE tg_id=:tg"),
        {"tg": user_tg_id},
    )
    row = r.fetchone()
    assert row is not None
    # available_kwh should be 0, exchanged should be 10 once
    assert str(row[0]) in ("0", "0.00000000")
    assert str(row[1]) in ("10", "10.00000000")
