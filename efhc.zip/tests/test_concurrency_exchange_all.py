from __future__ import annotations

import asyncio

import pytest
from sqlalchemy import text

from tests.concurrency_testkit import (
    ensure_core_user,
    reload_transactions_service,
)

pytestmark = pytest.mark.asyncio


async def test_concurrency_double_exchange__all__no_double_credit(
    async_engine,
    db_clean,
) -> None:
    ts = reload_transactions_service()

    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker

    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    user_tg_id = 100001

    async with Session() as s:
        await ensure_core_user(
            s,
            tg_id=user_tg_id,
            username="user",
            ton_wallet="w",
        )

        # Make sure user has available_kwh to exchange
        await s.execute(
            text(
                "UPDATE efhc_core.users "
                "SET total_generated_kwh=:tk, "
                "    exchanged_kwh_total='0.00000000' "
                "WHERE tg_id=:tg"
            ),
            {"tk": "10.00000000", "tg": user_tg_id},
        )
        await s.commit()

    async def _call():
        # Each concurrent call MUST use its own AsyncSession.
        async with Session() as s:
            return await ts.exchange__all__available_kwh_to_main(
                s,
                tg_id=user_tg_id,
                idempotency_key="ex-all-1",
                reason="exchange_all",
            )

    # Run two concurrent calls with same idk; no double-credit
    await asyncio.gather(
        _call(),
        _call(),
    )

    async with Session() as s:
        r = await s.execute(
            text(
                "SELECT exchanged_kwh_total, available_kwh "
                "FROM efhc_core.users "
                "WHERE tg_id=:tg"
            ),
            {"tg": user_tg_id},
        )
        row = r.fetchone()
        assert row is not None
        # available_kwh should be 0, exchanged should be 10 once
        from app.schemas.common_schemas import d8_str

        assert d8_str(row[0]) == "10.00000000"
        assert d8_str(row[1]) == "0.00000000"
        bank = await s.execute(
            text(
                "SELECT balance FROM efhc_core.bank_balance "
                "WHERE key = 'EFHC_MAIN'"
            )
        )
        bank_row = bank.fetchone()
        assert bank_row is not None
        from app.schemas.common_schemas import d8_str

        assert d8_str(bank_row[0]) == "-10.00000000"
