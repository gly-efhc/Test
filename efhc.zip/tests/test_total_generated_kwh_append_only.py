from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_exchange_never_mutates_total_generated_kwh() -> None:
    text = _read("backend/app/services/exchange_service.py")
    assert "SSOT Lock: total_generated_kwh is append-only" in text
    assert "total_generated_kwh" in text
    assert "SET total_generated_kwh" not in text
    assert "total_generated_kwh -" not in text
    assert "total_after" in text


def test_withdraw_never_mutates_total_generated_kwh() -> None:
    text = _read("backend/app/services/withdraw_service.py")
    assert "SET total_generated_kwh" not in text
    assert "total_generated_kwh -" not in text
