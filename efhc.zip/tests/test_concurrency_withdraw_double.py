from __future__ import annotations

import asyncio
import importlib

import pytest
from sqlalchemy import text


def _reload_withdraw_service():
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()
    import backend.app.services.withdraw_service as ws
    ws = importlib.reload(ws)
    return ws


async def _ensure_user(db, *, tg_id: int) -> None:
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.users (
                tg_id, username, is_vip, is_active,
                ton_wallet,
                main_balance, bonus_balance,
                total_generated_kwh, exchanged_kwh_total,
                available_kwh, created_at, updated_at
            ) VALUES (
                :tg_id, :u, false, true,
                :tw,
                :mb, 0,
                0, 0,
                0, NOW(), NOW()
            )
            ON CONFLICT (tg_id) DO NOTHING
            """
        ),
        {"tg_id": tg_id, "u": "user", "tw": "", "mb": "100.00000000"},
    )
    await db.commit()


async def test_concurrency_double_approve_withdraw_only_once(db_session, db_clean) -> None:
    ws = _reload_withdraw_service()

    user_tg_id = 200001
    await _ensure_user(db_session, tg_id=user_tg_id)

    # Create withdraw request
    req = await ws.request_withdraw(
        db_session,
        tg_id=user_tg_id,
        amount="1.00000000",
        idempotency_key="wd-1",
    )
    await db_session.commit()
    req_id = int(req["id"])

    async def _approve():
        # approve_withdraw_request is service-level approve
        return await ws.approve_withdraw_request(db_session, request_id=req_id)

    # Two concurrent approvals; one must win, the other should error or no-op
    results = await asyncio.gather(_approve(), _approve(), return_exceptions=True)
    await db_session.commit()

    # Exactly one should be non-exception
    ok = [r for r in results if not isinstance(r, Exception)]
    assert len(ok) == 1

    # Status should be PAID
    r = await db_session.execute(
        text("SELECT status FROM efhc_core.withdraw_requests WHERE id=:id"),
        {"id": req_id},
    )
    row = r.fetchone()
    assert row is not None
    assert str(row[0]).upper() == "PAID"
