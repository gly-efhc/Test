from __future__ import annotations

import asyncio

import pytest
from sqlalchemy import text

from tests.concurrency_testkit import (
    ensure_admin_whitelist,
    ensure_core_user,
    reload_withdraw_service,
)

pytestmark = pytest.mark.asyncio
pytest.importorskip("sqlalchemy")


async def test_concurrency_double_approve_withdraw_only_once(
    async_engine,
    db_clean,
    admin_tg_id,
) -> None:
    ws = reload_withdraw_service()

    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker

    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    user_tg_id = 200001

    async with Session() as db_session:
        await ensure_core_user(
            db_session,
            tg_id=user_tg_id,
            main_balance="100.00000000",
        )
        await ensure_admin_whitelist(db_session, tg_id=int(admin_tg_id))

        # Create withdraw request
        req = await ws.request_withdraw(
            db_session,
            tg_id=user_tg_id,
            amount="10.00000000",
            idempotency_key="wd-1",
        )
        await db_session.commit()
        req_id = int(req["id"])

    async def _approve(idk: str):
        # Each concurrent approve MUST use its own AsyncSession.
        async with Session() as s:
            return await ws.approve_withdraw_request(
                s,
                request_id=req_id,
                actor_tg_id=int(admin_tg_id),
                idempotency_key=idk,
            )

    # Two concurrent approvals; one must win.
    results = await asyncio.gather(
        _approve("appr-1"),
        _approve("appr-2"),
        return_exceptions=True,
    )

    # Exactly one should be non-exception
    ok = [r for r in results if not isinstance(r, Exception)]
    assert len(ok) == 1

    # Status should be PAID
    async with Session() as db_session:
        r = await db_session.execute(
            text(
                "SELECT status "
                "FROM efhc_core.withdraw_requests "
                "WHERE id=:id"
            ),
            {"id": req_id},
        )
        row = r.fetchone()
        assert row is not None
        assert str(row[0]).upper() == "PAID"


async def test_idempotency_approve_withdraw_same_key_twice(
    async_engine,
    db_clean,
    admin_tg_id,
) -> None:
    ws = reload_withdraw_service()

    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker

    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    user_tg_id = 200002
    req_id = None

    async with Session() as db_session:
        await ensure_core_user(
            db_session,
            tg_id=user_tg_id,
            main_balance="100.00000000",
        )
        await ensure_admin_whitelist(db_session, tg_id=int(admin_tg_id))
        req = await ws.request_withdraw(
            db_session,
            tg_id=user_tg_id,
            amount="10.00000000",
            idempotency_key="wd-2",
        )
        await db_session.commit()
        req_id = int(req["id"])

    idk = "appr-idem-1"

    async with Session() as s1:
        dto1 = await ws.approve_withdraw_request(
            s1,
            request_id=req_id,
            actor_tg_id=int(admin_tg_id),
            idempotency_key=idk,
        )
        assert str(dto1.status).upper() == "PAID"

    async with Session() as s2:
        dto2 = await ws.approve_withdraw_request(
            s2,
            request_id=req_id,
            actor_tg_id=int(admin_tg_id),
            idempotency_key=idk,
        )
        assert str(dto2.status).upper() == "PAID"

    async with Session() as db_session:
        r = await db_session.execute(
            text(
                "\n".join(
                    [
                        "SELECT COUNT(*)",
                        "FROM efhc_admin.admin_action_log",
                        "WHERE action='WITHDRAW_APPROVE'",
                        "  AND target_type='withdraw_request'",
                        "  AND target_id=:tid",
                        "  AND (details_json->>'details') LIKE :p",
                    ]
                )
            ),
            {"tid": str(req_id), "p": f"%idk={idk}%"},
        )
        c1 = int(r.scalar() or 0)
        assert c1 == 1
