from __future__ import annotations

import asyncio
import importlib

import pytest

pytestmark = pytest.mark.asyncio
from sqlalchemy import text  # noqa: E402


def _reload_withdraw_service():
    from app.core import config_core
    config_core.get_settings.cache_clear()
    import app.services.withdraw_service as ws
    ws = importlib.reload(ws)
    return ws


async def _ensure_user(db, *, tg_id: int) -> None:
    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  ton_wallet,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, exchanged_kwh_total,",
                    "  created_at, updated_at",
                    ") VALUES (",
                    "  :tg_id, :u, false, true,",
                    "  :tw,",
                    "  :mb, '0.00000000',",
                    "  '0.00000000', '0.00000000',",
                    "  NOW(), NOW()",
                    ")",
                    "ON CONFLICT (tg_id) DO NOTHING",
                ]
            )
        ),
        {"tg_id": tg_id, "u": "user", "tw": "", "mb": "100.00000000"},
    )
    await db.commit()


async def _ensure_admin(db, *, tg_id: int) -> None:
    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_admin.admin_whitelist (tg_id)",
                    "VALUES (:tg_id)",
                    "ON CONFLICT (tg_id) DO UPDATE",
                    "SET is_active = true",
                ]
            )
        ),
        {"tg_id": int(tg_id)},
    )
    await db.commit()


async def test_concurrency_double_approve_withdraw_only_once(
    async_engine,
    db_clean,
    admin_tg_id,
) -> None:
    ws = _reload_withdraw_service()

    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker
    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    user_tg_id = 200001

    async with Session() as db_session:
        await _ensure_user(db_session, tg_id=user_tg_id)
        await _ensure_admin(db_session, tg_id=int(admin_tg_id))

        # Create withdraw request
        req = await ws.request_withdraw(
            db_session,
            tg_id=user_tg_id,
            amount="10.00000000",
            idempotency_key="wd-1",
        )
        await db_session.commit()
        req_id = int(req["id"])

    async def _approve(idk: str):
        # Each concurrent approve MUST use its own AsyncSession.
        async with Session() as s:
            return await ws.approve_withdraw_request(
                s,
                request_id=req_id,
                actor_tg_id=int(admin_tg_id),
                idempotency_key=idk,
            )

    # Two concurrent approvals; one must win.
    results = await asyncio.gather(
        _approve("appr-1"),
        _approve("appr-2"),
        return_exceptions=True,
    )

    # Exactly one should be non-exception
    ok = [r for r in results if not isinstance(r, Exception)]
    assert len(ok) == 1

    # Status should be PAID
    async with Session() as db_session:
        r = await db_session.execute(
            text(
                "SELECT status "
                "FROM efhc_core.withdraw_requests "
                "WHERE id=:id"
            ),
            {"id": req_id},
        )
        row = r.fetchone()
        assert row is not None
        assert str(row[0]).upper() == "PAID"


async def test_idempotency_approve_withdraw_same_key_twice(
    async_engine,
    db_clean,
    admin_tg_id,
) -> None:
    ws = _reload_withdraw_service()

    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker
    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    user_tg_id = 200002
    req_id = None

    async with Session() as db_session:
        await _ensure_user(db_session, tg_id=user_tg_id)
        await _ensure_admin(db_session, tg_id=int(admin_tg_id))
        req = await ws.request_withdraw(
            db_session,
            tg_id=user_tg_id,
            amount="10.00000000",
            idempotency_key="wd-2",
        )
        await db_session.commit()
        req_id = int(req["id"])

    idk = "appr-idem-1"

    async with Session() as s1:
        dto1 = await ws.approve_withdraw_request(
            s1,
            request_id=req_id,
            actor_tg_id=int(admin_tg_id),
            idempotency_key=idk,
        )
        assert str(dto1.status).upper() == "PAID"

    async with Session() as s2:
        dto2 = await ws.approve_withdraw_request(
            s2,
            request_id=req_id,
            actor_tg_id=int(admin_tg_id),
            idempotency_key=idk,
        )
        assert str(dto2.status).upper() == "PAID"

    async with Session() as db_session:
        r = await db_session.execute(
            text(
                "\n".join(
                    [
                        "SELECT COUNT(*)",
                        "FROM efhc_admin.admin_action_log",
                        "WHERE action='WITHDRAW_APPROVE'",
                        "  AND target_type='withdraw_request'",
                        "  AND target_id=:tid",
                        "  AND (details_json->>'details') LIKE :p",
                    ]
                )
            ),
            {"tid": str(req_id), "p": f"%idk={idk}%"},
        )
        c1 = int(r.scalar() or 0)
        assert c1 == 1
