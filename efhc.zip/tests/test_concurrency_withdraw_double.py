from __future__ import annotations

import asyncio
import importlib
import json
import os
import tempfile
from datetime import datetime, timezone
from decimal import Decimal

import pytest


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


def _reload_services_for_sqlite() -> object:
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["ADMIN_BANK_TG_ID"] = "900100"  # тестовый банк
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.transactions_service as ts
    import backend.app.services.withdraw_service as ws

    importlib.reload(ts)
    ws = importlib.reload(ws)
    return ws


async def _init_schema(engine) -> None:
    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.users (
                    tg_id INTEGER PRIMARY KEY,
                    username TEXT,
                    is_vip INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    main_balance NUMERIC NOT NULL DEFAULT 0,
                    bonus_balance NUMERIC NOT NULL DEFAULT 0,
                    total_generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    exchanged_kwh_total NUMERIC NOT NULL DEFAULT 0,
                    available_kwh NUMERIC NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.efhc_transfers_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    direction TEXT NOT NULL,
                    balance_type TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    extra_info TEXT
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.withdraw_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    hold_done INTEGER NOT NULL DEFAULT 0,
                    refund_done INTEGER NOT NULL DEFAULT 0,
                    payout_ref TEXT,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )


@pytest.mark.asyncio
async def test_concurrency_double_withdraw_only_one_success() -> None:
    ws = _reload_services_for_sqlite()

    with tempfile.TemporaryDirectory() as td:
        db_url = f"sqlite+aiosqlite:///{td}/concurrency_3.db"
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )

        @event.listens_for(engine.sync_engine, "connect")
        def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
            try:
                dbapi_conn.create_function(
                    "now",
                    0,
                    lambda: datetime.now(timezone.utc).isoformat(),
                )
            except Exception:
                pass

        await _init_schema(engine)

        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
        )

        user_tg_id = 100003
        bank_tg_id = 900100

        async with Session() as s:
            await s.execute(
                text(
                    """
                    INSERT INTO main.users (
                        tg_id, username, is_vip, is_active,
                        main_balance, bonus_balance,
                        total_generated_kwh, exchanged_kwh_total,
                        available_kwh, created_at, updated_at
                    ) VALUES (
                        :tg_id, :u, 0, 1,
                        :mb, :bb,
                        0, 0,
                        0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                    )
                    """
                ),
                {
                    "tg_id": user_tg_id,
                    "u": "user",
                    "mb": "15.00000000",
                    "bb": "0.00000000",
                },
            )
            await s.execute(
                text(
                    """
                    INSERT INTO main.users (
                        tg_id, username, is_vip, is_active,
                        main_balance, bonus_balance,
                        total_generated_kwh, exchanged_kwh_total,
                        available_kwh, created_at, updated_at
                    ) VALUES (
                        :tg_id, :u, 0, 1,
                        :mb, :bb,
                        0, 0,
                        0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                    )
                    """
                ),
                {
                    "tg_id": bank_tg_id,
                    "u": "bank",
                    "mb": "0.00000000",
                    "bb": "0.00000000",
                },
            )
            await s.commit()

        async def _do_withdraw(client_idk: str) -> object:
            async with Session() as s:
                return await ws.request_withdraw(
                    s,
                    tg_id=user_tg_id,
                    amount=Decimal("10.00000000"),
                    client_idk=client_idk,
                )

        out = await asyncio.gather(
            _do_withdraw("k_wd_a"),
            _do_withdraw("k_wd_b"),
            return_exceptions=True,
        )

        ok_count = sum(1 for x in out if not isinstance(x, Exception))
        err_count = sum(1 for x in out if isinstance(x, Exception))
        assert ok_count == 1
        assert err_count == 1

        async with Session() as s:
            row = (
                await s.execute(
                    text(
                        """
                        SELECT COALESCE(main_balance, 0)
                        FROM main.users
                        WHERE tg_id = :tg
                        """
                    ),
                    {"tg": user_tg_id},
                )
            ).fetchone()
            assert Decimal(str(row[0])) == Decimal("5.00000000")

            logs = (
                await s.execute(
                    text(
                        """
                        SELECT extra_info
                        FROM main.efhc_transfers_log
                        WHERE tg_id = :tg
                        ORDER BY id
                        """
                    ),
                    {"tg": user_tg_id},
                )
            ).fetchall()

        # Должны быть как минимум 2 записи: success и rejected.
        statuses = []
        for (raw,) in logs:
            if not raw:
                continue
            try:
                payload = json.loads(str(raw))
            except Exception:
                continue
            if payload.get("op_type") == "WITHDRAW":
                statuses.append(payload.get("status"))

        assert "success" in statuses
        assert "rejected" in statuses

        await engine.dispose()
