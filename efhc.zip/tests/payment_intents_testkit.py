# ruff: noqa: E402
from __future__ import annotations

import importlib
import os

import pytest

pytest.importorskip("sqlalchemy")

from tests.conftest import get_async_db_url

TEST_TON_RECEIVER = "0:" + ("11" * 32)


def _configure_payment_test_env() -> None:
    os.environ.setdefault("TON_MAIN_WALLET", TEST_TON_RECEIVER)
    os.environ.setdefault("TON_WALLET_ADDRESS", TEST_TON_RECEIVER)
    os.environ.setdefault("PAYMENTS_RECEIVER_ADDRESS", TEST_TON_RECEIVER)


def reload_payment_service_postgres() -> object:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    os.environ["DB_SCHEMA_ADMIN"] = "efhc_admin"
    _configure_payment_test_env()
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.payment_intents_service as ps

    return importlib.reload(ps)


def load_payment_and_wallet_services() -> tuple[object, object]:
    _configure_payment_test_env()
    from app.core import config_core

    config_core.get_settings.cache_clear()
    from app.services import payment_intents_service as ps_module
    from app.services import wallets_service as ws_module

    ps = importlib.reload(ps_module)
    ws = importlib.reload(ws_module)
    return ps, ws


async def ensure_payment_owner(db, *, tg_id: int) -> int:
    """Подготовить control и один Telegram-account для owner-тестов."""
    from sqlalchemy import text

    await db.execute(
        text(
            """
            INSERT INTO efhc_core.identity_migration_control (
                singleton_id,
                dual_write_enabled,
                shadow_read_enabled,
                legacy_authoritative,
                nonfinancial_read_global_id_enabled,
                nonfinancial_read_rollback_ready,
                financial_read_global_id_enabled,
                financial_read_rollback_ready
            ) VALUES (
                1, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE
            )
            ON CONFLICT (singleton_id) DO UPDATE SET
                dual_write_enabled = TRUE,
                shadow_read_enabled = TRUE,
                legacy_authoritative = TRUE,
                nonfinancial_read_global_id_enabled = TRUE,
                nonfinancial_read_rollback_ready = TRUE,
                financial_read_global_id_enabled = TRUE,
                financial_read_rollback_ready = TRUE,
                updated_at = now()
            """
        )
    )
    result = await db.execute(
        text(
            """
            INSERT INTO efhc_core.users (tg_id, is_active)
            VALUES (:tg_id, TRUE)
            ON CONFLICT (tg_id) DO UPDATE SET is_active = TRUE
            RETURNING global_id
            """
        ),
        {"tg_id": int(tg_id)},
    )
    await db.commit()
    return int(result.scalar_one())


async def ensure_deposit_package(db, *, package_id: int) -> None:
    from sqlalchemy import text

    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.shop_items (",
                    "  id, sku, title, description,",
                    "  quantity_efhc, is_active, extra",
                    ") VALUES (",
                    "  :id, :sku, :title, NULL,",
                    "  :qty, true, CAST(:extra AS jsonb)",
                    ")",
                    "ON CONFLICT (id) DO NOTHING",
                ]
            )
        ),
        {
            "id": int(package_id),
            "sku": f"EFHC_PACK_{int(package_id)}",
            "title": "EFHC Deposit Package",
            "qty": "10.00000000",
            "extra": '{"asset":"TON","price_asset_d8":"1.00000000"}',
        },
    )
    await db.commit()


__all__ = [
    "ensure_deposit_package",
    "ensure_payment_owner",
    "get_async_db_url",
    "load_payment_and_wallet_services",
    "reload_payment_service_postgres",
]
