from __future__ import annotations

from pathlib import Path


def test_frontend_telegram_api_guard() -> None:
  """MUST: Telegram WebApp API access only via frontend/src/lib/telegram.ts."""

  root = Path(__file__).resolve().parents[1]
  allowed = root / "frontend" / "src" / "lib" / "telegram.ts"

  bad: list[str] = []

  for p in (root / "frontend" / "src").rglob("*.ts*"):
    if p == allowed:
      continue
    try:
      txt = p.read_text(encoding="utf-8")
    except Exception:
      continue

    if "window.Telegram" in txt:
      bad.append(str(p.relative_to(root)))

  assert not bad, (
    "Direct Telegram WebApp usage is forbidden outside telegram.ts. "
    "Fix files: " + ", ".join(sorted(bad))
  )
