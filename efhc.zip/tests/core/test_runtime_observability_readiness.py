from __future__ import annotations

from types import SimpleNamespace

import pytest
from app.core.logging_core import CorrelationIdMiddleware
from app.core.runtime_observability import (
    RuntimeObservabilityRegistry,
    normalize_route,
)
from app.middleware.request_observability import (
    RequestObservabilityMiddleware,
)
from app.routes import system_routes
from fastapi import FastAPI
from fastapi.testclient import TestClient


def test_route_normalization_drops_query_and_identifier_segments() -> None:
    assert normalize_route(
        "/api/withdraw/123456?token=secret"
    ) == "/api/withdraw/:id"
    assert normalize_route(
        "/admin/users/7f6a9cc25a904ddc"
    ) == "/admin/users/:id"


def test_registry_is_bounded_safe_and_emits_fail_closed_alert() -> None:
    registry = RuntimeObservabilityRegistry(max_samples=100)
    for index in range(20):
        registry.record(
            method="GET",
            route=f"/api/users/{index}",
            status_code=500 if index < 2 else 200,
            duration_ms=1700 if index == 0 else 20,
        )
    snapshot = registry.snapshot()
    assert snapshot["sample_count"] == 20
    assert snapshot["recent_5xx"] == 2
    assert snapshot["privacy"] == {
        "request_bodies_stored": False,
        "query_strings_stored": False,
        "identifiers_normalized": True,
    }
    assert any(
        item["id"] == "HTTP_5XX_RATIO_HIGH"
        for item in snapshot["alerts"]
    )
    assert all("secret" not in str(item) for item in snapshot.values())


def test_http_middlewares_return_correlation_and_timing_headers() -> None:
    app = FastAPI()
    app.add_middleware(RequestObservabilityMiddleware)
    app.add_middleware(CorrelationIdMiddleware)

    @app.get("/probe/{item_id}")
    async def probe(item_id: int) -> dict[str, int]:
        return {"item_id": item_id}

    client = TestClient(app)
    response = client.get(
        "/probe/123",
        headers={"X-Request-ID": "efhc-observe-1568"},
    )
    assert response.status_code == 200
    assert response.headers["x-request-id"] == "efhc-observe-1568"
    assert response.headers["server-timing"].startswith("app;dur=")
    assert float(response.headers["x-response-time-ms"]) >= 0


class _VersionResult:
    def scalar_one_or_none(self) -> str:
        return "0001"


class _ReadyDb:
    async def execute(self, statement: object) -> _VersionResult:
        return _VersionResult()


@pytest.mark.asyncio
async def test_readiness_accepts_database_and_canonical_migration(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        system_routes,
        "get_settings",
        lambda: SimpleNamespace(SCHEDULER_ENABLED=False),
    )
    monkeypatch.setattr(
        system_routes.runtime_observability,
        "snapshot",
        lambda: {"alerts": []},
    )
    result = await system_routes.health_readiness(db=_ReadyDb())
    assert isinstance(result, dict)
    assert result == {
        "ok": True,
        "database": "ready",
        "migration": "0001",
        "watcher": "disabled_by_configuration",
        "runtime_alerts": 0,
    }


@pytest.mark.asyncio
async def test_readiness_fails_closed_on_runtime_critical_alert(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        system_routes,
        "get_settings",
        lambda: SimpleNamespace(SCHEDULER_ENABLED=False),
    )
    monkeypatch.setattr(
        system_routes.runtime_observability,
        "snapshot",
        lambda: {
            "alerts": [
                {
                    "id": "HTTP_5XX_RATIO_HIGH",
                    "severity": "critical",
                }
            ]
        },
    )
    response = await system_routes.health_readiness(db=_ReadyDb())
    assert response.status_code == 503
