from __future__ import annotations

import logging
from types import SimpleNamespace

from app.core.logging_core import RedactingFilter


def test_sensitive_message_args_and_extra_fields_are_redacted() -> None:
    settings = SimpleNamespace(
        BOT_TOKEN="123456:secret-token",
        DATABASE_URL="postgresql://user:pass@db/app",
    )
    record = logging.LogRecord(
        "test",
        logging.INFO,
        __file__,
        1,
        "authorization=%s payload=%s",
        (
            "123456:secret-token",
            {"proof": "signed", "safe": "visible"},
        ),
        None,
    )
    record.init_data = "query_id=abc&hash=private"
    record.metadata = {
        "private_key": "secret-key",
        "nested": {"signature": "signed", "safe": "visible"},
    }

    assert RedactingFilter(settings).filter(record) is True
    assert "secret-token" not in str(record.msg)
    assert "secret-token" not in str(record.args)
    assert record.init_data == "****"
    assert record.metadata["private_key"] == "****"
    assert record.metadata["nested"]["signature"] == "****"
    assert record.metadata["nested"]["safe"] == "visible"
