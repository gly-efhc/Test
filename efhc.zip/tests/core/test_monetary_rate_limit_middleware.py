from __future__ import annotations

import logging

from app.core import system_locks
from app.core.system_locks import MonetaryRateLimitMiddleware
from fastapi import FastAPI
from fastapi.testclient import TestClient


def _app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(MonetaryRateLimitMiddleware)

    @app.get("/ping")
    async def ping():
        return {"ok": True}

    @app.post("/withdraw/request")
    async def withdraw():
        return {"ok": True}

    @app.post("/api/withdraw/request")
    async def api_withdraw():
        return {"ok": True}

    return app


def test_rate_limit_skips_non_monetary(monkeypatch) -> None:
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    async def _fake_global_id(request):
        _ = request
        return 123

    async def _fake_acquire(**kwargs):
        _ = kwargs
        return True

    monkeypatch.setattr(
        system_locks,
        "_resolve_monetary_global_id",
        _fake_global_id,
    )
    monkeypatch.setattr(
        system_locks,
        "_acquire_monetary_rate_limit_slot",
        _fake_acquire,
    )

    c = TestClient(_app())
    assert c.get("/ping").status_code == 200


def test_rate_limit_blocks_duplicate_burst(monkeypatch) -> None:
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    async def _fake_global_id(request):
        _ = request
        return 777

    state = {"calls": 0}

    async def _fake_acquire(**kwargs):
        _ = kwargs
        state["calls"] += 1
        return state["calls"] == 1

    monkeypatch.setattr(
        system_locks,
        "_resolve_monetary_global_id",
        _fake_global_id,
    )
    monkeypatch.setattr(
        system_locks,
        "_acquire_monetary_rate_limit_slot",
        _fake_acquire,
    )

    c = TestClient(_app())
    r1 = c.post("/withdraw/request")
    assert r1.status_code == 200

    r2 = c.post("/withdraw/request")
    assert r2.status_code == 429


def test_rate_limit_covers_runtime_api_prefix(monkeypatch) -> None:
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    async def _fake_global_id(request):
        _ = request
        return 888

    captured: list[str] = []

    async def _fake_acquire(**kwargs):
        captured.append(str(kwargs["scope_path"]))
        return True

    monkeypatch.setattr(
        system_locks,
        "_resolve_monetary_global_id",
        _fake_global_id,
    )
    monkeypatch.setattr(
        system_locks,
        "_acquire_monetary_rate_limit_slot",
        _fake_acquire,
    )

    response = TestClient(_app()).post("/api/withdraw/request")
    assert response.status_code == 200
    assert captured == ["/withdraw"]
