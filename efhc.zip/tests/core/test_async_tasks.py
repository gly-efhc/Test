from __future__ import annotations

import asyncio
import importlib
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))

async_tasks = importlib.import_module("app.core.async_tasks")
create_logged_task = async_tasks.create_logged_task


@pytest.mark.asyncio
async def test_create_logged_task_returns_result() -> None:
    async def _ok() -> int:
        await asyncio.sleep(0)
        return 7

    task = create_logged_task(_ok(), name="test:ok")
    assert await task == 7


@pytest.mark.asyncio
async def test_create_logged_task_logs_failure(monkeypatch) -> None:
    seen: list[tuple[str, str]] = []

    def _fake_exception(msg: str, name: str) -> None:
        seen.append((msg, name))

    monkeypatch.setattr(async_tasks.logger, "exception", _fake_exception)

    async def _boom() -> None:
        await asyncio.sleep(0)
        raise RuntimeError("boom")

    task = create_logged_task(_boom(), name="test:boom")
    with pytest.raises(RuntimeError):
        await task
    await asyncio.sleep(0)
    assert seen == [("background task failed: %s", "test:boom")]


@pytest.mark.asyncio
async def test_create_logged_task_silences_cancel(monkeypatch) -> None:
    called = False

    def _fake_exception(msg: str, name: str) -> None:
        nonlocal called
        called = True

    monkeypatch.setattr(async_tasks.logger, "exception", _fake_exception)

    async def _slow() -> None:
        await asyncio.sleep(10)

    task = create_logged_task(_slow(), name="test:cancel")
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    await asyncio.sleep(0)
    assert called is False
