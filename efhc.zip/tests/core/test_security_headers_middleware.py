from __future__ import annotations

from app.middleware.security_headers import SecurityHeadersMiddleware
from fastapi import FastAPI
from fastapi.testclient import TestClient


def _app(*, environment: str = "local") -> FastAPI:
    app = FastAPI()
    app.add_middleware(
        SecurityHeadersMiddleware,
        environment=environment,
        max_request_body_bytes=32,
    )

    @app.get("/api/ping")
    async def ping():
        return {"ok": True}

    @app.post("/api/body")
    async def body():
        return {"ok": True}

    return app


def test_api_security_headers_and_no_store() -> None:
    response = TestClient(_app()).get("/api/ping")
    assert response.status_code == 200
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["referrer-policy"] == "no-referrer"
    assert "camera=()" in response.headers["permissions-policy"]
    assert "default-src 'none'" in response.headers[
        "content-security-policy"
    ]
    assert response.headers["cache-control"] == "no-store"
    assert "strict-transport-security" not in response.headers


def test_hsts_is_enabled_for_production() -> None:
    response = TestClient(_app(environment="prod")).get("/api/ping")
    assert response.headers["strict-transport-security"].startswith(
        "max-age=31536000"
    )


def test_oversized_request_is_rejected_before_handler() -> None:
    response = TestClient(_app()).post(
        "/api/body",
        content=b"x" * 33,
    )
    assert response.status_code == 413
    assert response.json() == {"detail": "Request body is too large."}
