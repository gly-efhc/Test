from __future__ import annotations

import logging

from app.core import system_locks
from app.core.system_locks import (
    MonetaryIdempotencyMiddleware,
    idempotent_action,
)
from fastapi import FastAPI
from fastapi.testclient import TestClient


def _app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(MonetaryIdempotencyMiddleware)

    @app.get("/ping")
    async def ping():
        return {"ok": True}

    @app.post("/exchange/convert/123")
    async def convert():
        return {"ok": True}

    @app.post("/withdraw/request")
    async def withdraw():
        return {"ok": True}

    @app.post("/api/withdraw/request")
    async def api_withdraw():
        return {"ok": True}

    @app.post("/shop/buy")
    @idempotent_action(ttl_sec=10)
    async def buy():
        return {"ok": True}

    return app


def _patch_ttl_lock(monkeypatch) -> None:
    seen: set[tuple[str, int, str]] = set()

    async def _fake_global_id(request):
        _ = request
        return 7000000001

    async def _fake_acquire(
        *,
        path: str,
        global_id: int,
        idempotency_key: str,
        ttl_sec: int,
    ) -> bool:
        _ = ttl_sec
        key = (path, global_id, idempotency_key)
        if key in seen:
            return False
        seen.add(key)
        return True

    monkeypatch.setattr(
        system_locks,
        "_resolve_monetary_global_id",
        _fake_global_id,
    )
    monkeypatch.setattr(
        system_locks,
        "_acquire_idempotency_ttl_lock",
        _fake_acquire,
    )


def test_monetary_paths_require_idempotency_key_header(
    monkeypatch,
) -> None:
    # Some environments have a strict pytest logging formatter;
    # mute httpx request logs to avoid formatting issues.
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    _patch_ttl_lock(monkeypatch)
    app = _app()
    c = TestClient(app)

    assert c.get("/ping").status_code == 200

    r1 = c.post("/exchange/convert/123")
    assert r1.status_code == 400

    r2 = c.post(
        "/exchange/convert/123",
        headers={"Idempotency-Key": "abc"},
    )
    assert r2.status_code == 200

    r3 = c.post("/withdraw/request")
    assert r3.status_code == 400

    r4 = c.post("/withdraw/request", headers={"Idempotency-Key": "xyz"})
    assert r4.status_code == 200


def test_idempotency_ttl_blocks_duplicate_clicks(monkeypatch) -> None:
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    _patch_ttl_lock(monkeypatch)
    app = _app()
    c = TestClient(app)

    h = {"Idempotency-Key": "k1"}
    r1 = c.post("/shop/buy", headers=h)
    assert r1.status_code == 200

    r2 = c.post("/shop/buy", headers=h)
    assert r2.status_code == 409


def test_runtime_api_prefix_requires_idempotency_key(monkeypatch) -> None:
    logging.getLogger("httpx").setLevel(logging.CRITICAL)
    _patch_ttl_lock(monkeypatch)
    client = TestClient(_app())

    assert client.post("/api/withdraw/request").status_code == 400
    response = client.post(
        "/api/withdraw/request",
        headers={"Idempotency-Key": "api-prefix"},
    )
    assert response.status_code == 200
