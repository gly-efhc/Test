from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient
import logging

from backend.app.core.system_locks import MonetaryIdempotencyMiddleware
from backend.app.core.system_locks import idempotent_action


def _app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(MonetaryIdempotencyMiddleware)

    @app.get("/ping")
    async def ping():
        return {"ok": True}

    @app.post("/exchange/convert/123")
    async def convert():
        return {"ok": True}

    @app.post("/withdraw/request")
    async def withdraw():
        return {"ok": True}

    @app.post("/shop/buy")
    @idempotent_action(ttl_sec=10)
    async def buy():
        return {"ok": True}

    return app


def test_monetary_paths_require_idempotency_key_header() -> None:
    # Some environments have a strict pytest logging formatter;
    # mute httpx request logs to avoid formatting issues.
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    app = _app()
    c = TestClient(app)

    assert c.get("/ping").status_code == 200

    r1 = c.post("/exchange/convert/123")
    assert r1.status_code == 400

    r2 = c.post(
        "/exchange/convert/123",
        headers={"Idempotency-Key": "abc"},
    )
    assert r2.status_code == 200

    r3 = c.post("/withdraw/request")
    assert r3.status_code == 400

    r4 = c.post("/withdraw/request", headers={"Idempotency-Key": "xyz"})
    assert r4.status_code == 200


def test_idempotency_ttl_blocks_duplicate_clicks() -> None:
    logging.getLogger("httpx").setLevel(logging.CRITICAL)

    app = _app()
    c = TestClient(app)

    h = {"Idempotency-Key": "k1"}
    r1 = c.post("/shop/buy", headers=h)
    assert r1.status_code == 200

    r2 = c.post("/shop/buy", headers=h)
    assert r2.status_code == 409
