from __future__ import annotations

import importlib

import pytest

pytest.importorskip("sqlalchemy")


def reload_panels_service() -> object:
    from app.core import config_core

    config_core.get_settings.cache_clear()
    import app.services.panels_service as ps

    return importlib.reload(ps)


async def seed_user_with_balances(
    db,
    *,
    global_id: int,
    main_balance: str,
    bonus_balance: str = "0.0",
) -> None:
    from sqlalchemy import text

    await db.execute(
        text(
            "INSERT INTO efhc_core.users (global_id, main_balance, "
            "bonus_balance) VALUES (:tg, :mb, :bb)"
        ),
        {"tg": global_id, "mb": main_balance, "bb": bonus_balance},
    )
    await db.commit()


__all__ = [
    "reload_panels_service",
    "seed_user_with_balances",
]
