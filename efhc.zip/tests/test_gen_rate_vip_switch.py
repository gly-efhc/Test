from __future__ import annotations

from decimal import ROUND_DOWN, Decimal

from app.core.system_locks import get_rate_base_d8, get_rate_vip_d8


def d8(x: Decimal) -> Decimal:
    return Decimal(str(x)).quantize(
        Decimal("0.00000001"), rounding=ROUND_DOWN
    )


def test_vip_switch_changes_rate_for_same_panels_count() -> None:
    active_panels_count = 7

    base = get_rate_base_d8()
    vip = get_rate_vip_d8()
    assert vip != base

    gen_base = d8(Decimal(active_panels_count) * base)
    gen_vip = d8(Decimal(active_panels_count) * vip)

    assert gen_vip != gen_base
    assert gen_base == d8(Decimal(active_panels_count) * base)
    assert gen_vip == d8(Decimal(active_panels_count) * vip)
