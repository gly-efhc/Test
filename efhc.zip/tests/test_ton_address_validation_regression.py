from __future__ import annotations

from app.lib.ton_address import canonicalize_ton_address
from app.schemas.withdraw_schemas import WithdrawCreateIn
from app.services.wallets_service import normalize_wallet_address


def test_wallet_normalize_accepts_eq_uq_addresses_with_e_chars() -> (
    None
):
    addr1 = "EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0"
    addr2 = "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"
    norm1 = normalize_wallet_address(addr1)
    norm2 = normalize_wallet_address(addr2)
    assert norm1 == canonicalize_ton_address(addr1)
    assert norm2 == canonicalize_ton_address(addr2)
    assert norm1.startswith("0:")
    assert norm2.startswith("0:")


def test_withdraw__schema__accepts_realistic_ton_address_with_e_chars() -> (
    None
):
    dto = WithdrawCreateIn(
        amount_efhc="1",
        dest_ton_address=(
            "EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0"
        ),
    )
    assert dto.dest_ton_address.startswith("EQ")
