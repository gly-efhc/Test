> RAW OUTPUT NOTICE: this file includes command output; long lines may exist.

# EFHC Bot Load Tests (k6)

## Цель
- Реальный прогон 1000+ RPS для проверки, что PostgreSQL не попадает
в deadlocks при массовых покупках (денежные POST).

## Предусловия
1) Поднять PostgreSQL локально:
   - `docker compose -f ops/docker/docker-compose.yml up -d`

2) Запустить backend (локально), включив dev-аутентификацию заголовком:
   - `ALLOW_INSECURE_USER_HEADERS=true`
   - Backend должен слушать `http://localhost:8000`

## Сценарий: массовая покупка skins
Скрипт: `tests/load/k6-scenarios/skins_buy.js`

Пример запуска 1000 RPS (30 секунд):

```bash
k6 run \
  -e BASE_URL=http://localhost:8000 \
  -e TG_ID=1000000001 \
  -e SKIN_ID=1 \
  -e DURATION=30s \
  -e VUS=400 \
  -e MAX_VUS=1200 \
  tests/load/k6-scenarios/skins_buy.js
```

## Контроль deadlocks в Postgres
Параллельно запуску k6 выполните:

```sql
-- 1) Сколько deadlocks накопилось
SELECT deadlocks FROM pg_stat_database WHERE datname = current_database();

-- 2) Кто кого ждёт (в момент зависаний)
SELECT
  now() AS ts,
  a.pid,
  a.state,
  a.wait_event_type,
  a.wait_event,
  left(a.query, 120) AS query
FROM pg_stat_activity a
WHERE a.datname = current_database()
ORDER BY a.state, a.wait_event_type;
```

Если `deadlocks` растёт во время прогона — это P0.
