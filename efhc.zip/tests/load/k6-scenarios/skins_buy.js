import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = _ENV.BASE_URL || 'http://localhost:8000';
const INIT_DATA = _ENV.TELEGRAM_INIT_DATA || '';
const SKIN_ID = _ENV.SKIN_ID || '1';

// 1000 RPS constant arrival rate.
export const options = {
  scenarios: {
    buy_skins: {
      executor: 'constant-arrival-rate',
      rate: 1000,
      timeUnit: '1s',
      duration: _ENV.DURATION || '30s',
      preAllocatedVUs: Number(_ENV.VUS || 400),
      maxVUs: Number(_ENV.MAX_VUS || 1200),
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<300'],
  },
};

function idk() {
  // Idempotency-Key must be unique per request for load.
  return `${_VU}-${_ITER}-${Date.now()}`;
}

export default function () {
  const url = `${BASE_URL}/skins/buy/${SKIN_ID}`;
  const res = http.post(url, null, {
    headers: {
      'Content-Type': 'application/json',
      'Idempotency-Key': idk(),
      // Production-like load tests must pass signed Telegram initData.
      'X-Telegram-Init-Data': String(INIT_DATA),
    },
  });

  check(res, {
    'status is 200': (r) => r.status === 200,
  });

  sleep(0.001);
}
