import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8000';
const TG_ID = __ENV.TG_ID || '1000000001';
const SKIN_ID = __ENV.SKIN_ID || '1';

// 1000 RPS constant arrival rate.
export const options = {
  scenarios: {
    buy_skins: {
      executor: 'constant-arrival-rate',
      rate: 1000,
      timeUnit: '1s',
      duration: __ENV.DURATION || '30s',
      preAllocatedVUs: Number(__ENV.VUS || 400),
      maxVUs: Number(__ENV.MAX_VUS || 1200),
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<300'],
  },
};

function idk() {
  // Idempotency-Key must be unique per request for load.
  return `${__VU}-${__ITER}-${Date.now()}`;
}

export default function () {
  const url = `${BASE_URL}/skins/buy/${SKIN_ID}`;
  const res = http.post(url, null, {
    headers: {
      'Content-Type': 'application/json',
      'Idempotency-Key': idk(),
      // For local load tests, enable ALLOW_INSECURE_USER_HEADERS=true
      // on backend and pass a tg_id header.
      'X-Telegram-User-Id': String(TG_ID),
    },
  });

  check(res, {
    'status is 200': (r) => r.status === 200,
  });

  sleep(0.001);
}
