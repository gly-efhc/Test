# ruff: noqa: E402
from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

pytest.importorskip("sqlalchemy")
from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    create_async_engine,
)
from sqlalchemy.orm import sessionmaker

from tests.payment_intents_testkit import (
    ensure_deposit_package,
    ensure_payment_owner,
    get_async_db_url,
    load_payment_and_wallet_services,
)


async def _ensure_tx_hash_locks(db) -> None:
    await db.execute(
        text("""
        CREATE TABLE IF NOT EXISTS efhc_core.tx_hash_locks (
            id INTEGER PRIMARY KEY,
            tx_hash TEXT NOT NULL UNIQUE,
            purpose TEXT NOT NULL,
            intent_id INTEGER,
            order_id INTEGER,
            global_id BIGINT NOT NULL,
            trusted_operation_at TEXT NOT NULL,
                    server_first_seen_at TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    )
    await db.commit()


@pytest.mark.asyncio
async def test_two_intents_two_confirms_credit_twice_main() -> None:
    db_url = get_async_db_url()

    ps, ws = load_payment_and_wallet_services()
    engine = create_async_engine(
        db_url,
        future=True,
    )
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )

    calls: list[tuple[str, str]] = []

    async def _credit_mock(
        _db,
        *,
        global_id: str,
        amount_efhc,
        reason: str,
        idempotency_key: str,
        meta=None,
    ) -> None:
        calls.append((global_id, str(amount_efhc)))

    ws.credit_user_from_bank = _credit_mock

    async with Session() as db:
        tg_id = 99_887_766
        global_id = await ensure_payment_owner(
            db,
            global_id=8_100_000_001,
        )
        await _ensure_tx_hash_locks(db)
        await ensure_deposit_package(db, package_id=1)
        i1 = await ps.create_intent_deposit_by_package(
            db,
            global_id=global_id,
            idempotency_key="k1",
            package_id=1,
        )
        i2 = await ps.create_intent_deposit_by_package(
            db,
            global_id=global_id,
            idempotency_key="k2",
            package_id=1,
        )
        assert i1["intent_id"] != i2["intent_id"]
        assert i1["payload"] != i2["payload"]

        st1 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i1["intent_id"]),
            global_id=global_id,
            provider_tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i1["payload"]),
            tx_hash="tx1",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            external_amount_atomic=int(i1["external_amount_atomic"]),
            external_decimals=int(i1["external_decimals"]),
            to_address=str(i1["to_address"]),
            trusted_operation_at=datetime.now(UTC) - timedelta(seconds=1),
            server_first_seen_at=datetime.now(UTC),
        )
        st2 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i2["intent_id"]),
            global_id=global_id,
            provider_tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i2["payload"]),
            tx_hash="tx2",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            external_amount_atomic=int(i2["external_amount_atomic"]),
            external_decimals=int(i2["external_decimals"]),
            to_address=str(i2["to_address"]),
            trusted_operation_at=datetime.now(UTC) - timedelta(seconds=1),
            server_first_seen_at=datetime.now(UTC),
        )
        assert st1 == ws.STATUS_CREDITED
        assert st2 == ws.STATUS_CREDITED

        assert len(calls) == 2
        assert calls[0][0] == global_id
        assert calls[1][0] == global_id

        await engine.dispose()


@pytest.mark.asyncio
async def test_same_tx_hash_cannot_confirm_second_intent() -> None:
    db_url = get_async_db_url()

    ps, ws = load_payment_and_wallet_services()
    engine = create_async_engine(db_url, future=True)
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )

    calls: list[str] = []

    async def _credit_mock(
        _db,
        *,
        global_id: str,
        amount_efhc,
        reason: str,
        idempotency_key: str,
        meta=None,
    ) -> None:
        calls.append(idempotency_key)

    ws.credit_user_from_bank = _credit_mock

    async with Session() as db:
        tg_id = 1
        global_id = await ensure_payment_owner(
            db,
            global_id=8_100_000_002,
        )
        await ensure_deposit_package(db, package_id=1)
        i1 = await ps.create_intent_deposit_by_package(
            db,
            global_id=global_id,
            idempotency_key="k1",
            package_id=1,
        )
        i2 = await ps.create_intent_deposit_by_package(
            db,
            global_id=global_id,
            idempotency_key="k2",
            package_id=1,
        )

        st1 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i1["intent_id"]),
            global_id=global_id,
            provider_tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i1["payload"]),
            tx_hash="tx_same",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            external_amount_atomic=int(i1["external_amount_atomic"]),
            external_decimals=int(i1["external_decimals"]),
            to_address=str(i1["to_address"]),
            trusted_operation_at=datetime.now(UTC) - timedelta(seconds=1),
            server_first_seen_at=datetime.now(UTC),
        )
        st2 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i2["intent_id"]),
            global_id=global_id,
            provider_tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i2["payload"]),
            tx_hash="tx_same",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            external_amount_atomic=int(i2["external_amount_atomic"]),
            external_decimals=int(i2["external_decimals"]),
            to_address=str(i2["to_address"]),
            trusted_operation_at=datetime.now(UTC) - timedelta(seconds=1),
            server_first_seen_at=datetime.now(UTC),
        )

        assert st1 == ws.STATUS_CREDITED
        assert st2 == ws.STATUS_ERROR_SYS

    assert len(calls) == 1
    await engine.dispose()


@pytest.mark.asyncio
async def test_подтвержденный_intent_не_принимает_другой_tx_hash() -> None:
    db_url = get_async_db_url()
    ps, ws = load_payment_and_wallet_services()
    engine = create_async_engine(db_url, future=True)
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )
    calls: list[str] = []

    async def _credit_mock(
        _db,
        *,
        global_id: str,
        amount_efhc,
        reason: str,
        idempotency_key: str,
        meta=None,
    ) -> None:
        calls.append(idempotency_key)

    ws.credit_user_from_bank = _credit_mock
    async with Session() as db:
        global_id = await ensure_payment_owner(
            db,
            global_id=8_100_000_003,
        )
        await _ensure_tx_hash_locks(db)
        await ensure_deposit_package(db, package_id=1)
        intent = await ps.create_intent_deposit_by_package(
            db,
            global_id=global_id,
            idempotency_key="k_single_intent",
            package_id=1,
        )
        common = {
            "intent_id": int(intent["intent_id"]),
            "global_id": global_id,
            "provider_tg_id": None,
            "purpose": "deposit_efhc",
            "payload": str(intent["payload"]),
            "amount_asset": ps.d8("1.00000000"),
            "asset": "TON",
            "external_amount_atomic": int(intent["external_amount_atomic"]),
            "external_decimals": int(intent["external_decimals"]),
            "to_address": str(intent["to_address"]),
            "trusted_operation_at": datetime.now(UTC) - timedelta(seconds=1),
            "server_first_seen_at": datetime.now(UTC),
        }
        first = await ws._confirm_payment_intent(
            db,
            tx_hash="tx_first",
            **common,
        )
        second = await ws._confirm_payment_intent(
            db,
            tx_hash="tx_second",
            **common,
        )
        assert first == ws.STATUS_CREDITED
        assert second == "pending_manual"
        assert len(calls) == 1

    await engine.dispose()


@pytest.mark.asyncio
async def test_истекший_payment_intent_не_подтверждается() -> None:
    db_url = get_async_db_url()
    ps, ws = load_payment_and_wallet_services()
    engine = create_async_engine(db_url, future=True)
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )
    calls: list[str] = []

    async def _credit_mock(
        _db,
        *,
        global_id: str,
        amount_efhc,
        reason: str,
        idempotency_key: str,
        meta=None,
    ) -> None:
        calls.append(idempotency_key)

    ws.credit_user_from_bank = _credit_mock
    async with Session() as db:
        global_id = await ensure_payment_owner(
            db,
            global_id=8_100_000_004,
        )
        await _ensure_tx_hash_locks(db)
        await ensure_deposit_package(db, package_id=1)
        intent = await ps.create_intent_deposit_by_package(
            db,
            global_id=global_id,
            idempotency_key="k_expired_intent",
            package_id=1,
        )
        await db.execute(
            text(
                "UPDATE efhc_core.payment_intents "
                "SET expires_at = :expired WHERE id = :iid"
            ),
            {
                "expired": datetime.now(UTC) - timedelta(minutes=1),
                "iid": int(intent["intent_id"]),
            },
        )
        await db.commit()

        status = await ws._confirm_payment_intent(
            db,
            intent_id=int(intent["intent_id"]),
            global_id=global_id,
            provider_tg_id=None,
            purpose="deposit_efhc",
            payload=str(intent["payload"]),
            tx_hash="tx_expired",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(intent["to_address"]),
            trusted_operation_at=datetime.now(UTC) - timedelta(seconds=1),
            server_first_seen_at=datetime.now(UTC),
        )
        assert status == "pending_manual"
        assert calls == []

    await engine.dispose()
