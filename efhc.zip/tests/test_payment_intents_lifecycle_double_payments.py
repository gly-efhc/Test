from __future__ import annotations

import os

import pytest


def _get_async_db_url() -> str:
    db_url = os.getenv("ASYNC_DATABASE_URL")
    if not db_url:
        db_url = os.getenv("DATABASE_URL")
    if not db_url:
        pytest.skip(
            "ASYNC_DATABASE_URL/DATABASE_URL required",
            allow_module_level=True,
        )

    if db_url.startswith("postgresql+psycopg://"):
        suffix = db_url[len("postgresql+psycopg://"):]
        db_url = "postgresql+asyncpg://" + suffix
    if db_url.startswith("postgresql://"):
        suffix = db_url[len("postgresql://"):]
        db_url = "postgresql+asyncpg://" + suffix
    if db_url.startswith("postgres://"):
        suffix = db_url[len("postgres://"):]
        db_url = "postgresql+asyncpg://" + suffix

    if db_url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")

    return db_url


pytest.importorskip("sqlalchemy")

from sqlalchemy import text  # noqa: E402
from sqlalchemy.ext.asyncio import (  # noqa: E402
    AsyncSession,
    create_async_engine,
)
from sqlalchemy.orm import sessionmaker  # noqa: E402


async def _ensure_deposit_package(db, *, package_id: int) -> None:
    await db.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.shop_items (",
                    "  id, sku, title, description,",
                    "  quantity_efhc, is_active, extra",
                    ") VALUES (",
                    "  :id, :sku, :title, NULL,",
                    "  :qty, true, CAST(:extra AS jsonb)",
                    ")",
                    "ON CONFLICT (id) DO NOTHING",
                ]
            )
        ),
        {
            "id": int(package_id),
            "sku": f"EFHC_PACK_{int(package_id)}",
            "title": "EFHC Deposit Package",
            "qty": "10.00000000",
            "extra": '{"asset":"TON","price_asset_d8":"1.00000000"}',
        },
    )
    await db.commit()


def _load_services():
    # Import services in Postgres-only canon.
    from app.services import payment_intents_service as ps
    from app.services import wallets_service as ws
    return ps, ws

@pytest.mark.asyncio
async def test_two_intents_two_confirms_credit_twice_main() -> None:
    db_url = _get_async_db_url()

    ps, ws = _load_services()
    engine = create_async_engine(
        db_url,
        future=True,
    )
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )

    calls: list[tuple[int, str]] = []

    async def _credit_mock(
        _db,
        *,
        tg_id: int,
        amount_efhc,
        reason: str,
        idempotency_key: str,
    ) -> None:
        calls.append((tg_id, str(amount_efhc)))

    ws.credit_user_from_bank = _credit_mock

    async with Session() as db:
        tg_id = 99887766
        await _ensure_deposit_package(db, package_id=1)
        i1 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k1",
            package_id=1,
        )
        i2 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k2",
            package_id=1,
        )
        assert i1["intent_id"] != i2["intent_id"]
        assert i1["payload"] != i2["payload"]

        st1 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i1["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i1["payload"]),
            tx_hash="tx1",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i1["to_address"]),
        )
        st2 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i2["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i2["payload"]),
            tx_hash="tx2",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i2["to_address"]),
        )
        assert st1 == ws.STATUS_CREDITED
        assert st2 == ws.STATUS_CREDITED

        assert len(calls) == 2
        assert calls[0][0] == 99887766
        assert calls[1][0] == 99887766

        await engine.dispose()


@pytest.mark.asyncio
async def test_same_tx_hash_cannot_confirm_second_intent() -> None:
    db_url = _get_async_db_url()

    ps, ws = _load_services()
    engine = create_async_engine(db_url, future=True)
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )

    calls: list[str] = []

    async def _credit_mock(
            _db,
            *,
            tg_id: int,
            amount_efhc,
            reason: str,
            idempotency_key: str,
        ) -> None:
            calls.append(idempotency_key)

    ws.credit_user_from_bank = _credit_mock

    async with Session() as db:
        tg_id = 1
        await _ensure_deposit_package(db, package_id=1)
        i1 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k1",
            package_id=1,
        )
        i2 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k2",
            package_id=1,
        )

        st1 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i1["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i1["payload"]),
            tx_hash="tx_same",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i1["to_address"]),
        )
        st2 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i2["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i2["payload"]),
            tx_hash="tx_same",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i2["to_address"]),
        )

        assert st1 == ws.STATUS_CREDITED
        assert st2 == ws.STATUS_ERROR_SYS

    assert len(calls) == 1
    await engine.dispose()