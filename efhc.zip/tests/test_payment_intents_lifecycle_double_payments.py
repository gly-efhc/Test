# ruff: noqa: E402
from __future__ import annotations

import pytest

pytest.importorskip("sqlalchemy")
from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    create_async_engine,
)
from sqlalchemy.orm import sessionmaker

from tests.payment_intents_testkit import (
    ensure_deposit_package,
    ensure_payment_owner,
    get_async_db_url,
    load_payment_and_wallet_services,
)


async def _ensure_tx_hash_locks(db) -> None:
    await db.execute(
        text("""
        CREATE TABLE IF NOT EXISTS efhc_core.tx_hash_locks (
            id INTEGER PRIMARY KEY,
            tx_hash TEXT NOT NULL UNIQUE,
            purpose TEXT NOT NULL,
            intent_id INTEGER NOT NULL,
            order_id INTEGER,
            tg_id INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    )
    await db.commit()


@pytest.mark.asyncio
async def test_two_intents_two_confirms_credit_twice_main() -> None:
    db_url = get_async_db_url()

    ps, ws = load_payment_and_wallet_services()
    engine = create_async_engine(
        db_url,
        future=True,
    )
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )

    calls: list[tuple[int, str]] = []

    async def _credit_mock(
        _db,
        *,
        tg_id: int,
        amount_efhc,
        reason: str,
        idempotency_key: str,
    ) -> None:
        calls.append((tg_id, str(amount_efhc)))

    ws.credit_user_from_bank = _credit_mock

    async with Session() as db:
        tg_id = 99887766
        await ensure_payment_owner(db, tg_id=tg_id)
        await _ensure_tx_hash_locks(db)
        await ensure_deposit_package(db, package_id=1)
        i1 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k1",
            package_id=1,
        )
        i2 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k2",
            package_id=1,
        )
        assert i1["intent_id"] != i2["intent_id"]
        assert i1["payload"] != i2["payload"]

        st1 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i1["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i1["payload"]),
            tx_hash="tx1",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i1["to_address"]),
        )
        st2 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i2["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i2["payload"]),
            tx_hash="tx2",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i2["to_address"]),
        )
        assert st1 == ws.STATUS_CREDITED
        assert st2 == ws.STATUS_CREDITED

        assert len(calls) == 2
        assert calls[0][0] == 99887766
        assert calls[1][0] == 99887766

        await engine.dispose()


@pytest.mark.asyncio
async def test_same_tx_hash_cannot_confirm_second_intent() -> None:
    db_url = get_async_db_url()

    ps, ws = load_payment_and_wallet_services()
    engine = create_async_engine(db_url, future=True)
    Session = sessionmaker(
        engine,
        expire_on_commit=False,
        class_=AsyncSession,
    )

    calls: list[str] = []

    async def _credit_mock(
        _db,
        *,
        tg_id: int,
        amount_efhc,
        reason: str,
        idempotency_key: str,
    ) -> None:
        calls.append(idempotency_key)

    ws.credit_user_from_bank = _credit_mock

    async with Session() as db:
        tg_id = 1
        await ensure_payment_owner(db, tg_id=tg_id)
        await ensure_deposit_package(db, package_id=1)
        i1 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k1",
            package_id=1,
        )
        i2 = await ps.create_intent_deposit_by_package(
            db,
            tg_id=tg_id,
            idempotency_key="k2",
            package_id=1,
        )

        st1 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i1["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i1["payload"]),
            tx_hash="tx_same",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i1["to_address"]),
        )
        st2 = await ws._confirm_payment_intent(
            db,
            intent_id=int(i2["intent_id"]),
            tg_id=tg_id,
            purpose="deposit_efhc",
            payload=str(i2["payload"]),
            tx_hash="tx_same",
            amount_asset=ps.d8("1.00000000"),
            asset="TON",
            to_address=str(i2["to_address"]),
        )

        assert st1 == ws.STATUS_CREDITED
        assert st2 == ws.STATUS_ERROR_SYS

    assert len(calls) == 1
    await engine.dispose()
