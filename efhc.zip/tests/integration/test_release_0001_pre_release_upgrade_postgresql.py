"""PostgreSQL proof повторного 0001 поверх pre-release schema drift."""

from __future__ import annotations

import os
import uuid
from decimal import Decimal
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy.engine import make_url

psycopg = pytest.importorskip("psycopg")

ROOT = Path(__file__).resolve().parents[2]
EXPECTED_FK_COUNT = 39


def _base_url_or_skip() -> str:
    url = os.getenv("SYNC_DATABASE_URL") or os.getenv("DATABASE_URL")
    if url and str(url).startswith("postgresql"):
        return str(url)
    message = "Тест требует реальный PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _to_psycopg(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _config(url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option("script_location", str(ROOT / "backend/migrations"))
    config.set_main_option("sqlalchemy.url", url)
    return config


def _urls(base_url: str, database: str) -> tuple[str, str, str]:
    parsed = make_url(base_url)
    admin = parsed.set(database="postgres")
    target = parsed.set(database=database)
    sqlalchemy_url = target.render_as_string(hide_password=False)
    return (
        _to_psycopg(admin.render_as_string(hide_password=False)),
        sqlalchemy_url,
        _to_psycopg(sqlalchemy_url),
    )


def _create_database(admin_url: str, database: str) -> None:
    with psycopg.connect(admin_url, autocommit=True) as connection:
        connection.execute(f'CREATE DATABASE "{database}"')


def _drop_database(admin_url: str, database: str) -> None:
    with psycopg.connect(admin_url, autocommit=True) as connection:
        connection.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = %s AND pid <> pg_backend_pid()",
            (database,),
        )
        connection.execute(f'DROP DATABASE IF EXISTS "{database}"')


def _fk_count(connection: object) -> int:
    return int(
        connection.execute(  # type: ignore[attr-defined]
            """
            SELECT count(*)
            FROM pg_constraint c
            JOIN pg_attribute a
              ON a.attrelid = c.confrelid
             AND a.attnum = ANY(c.confkey)
            WHERE c.contype='f'
              AND c.confrelid='efhc_core.users'::regclass
              AND a.attname='global_id'
            """
        ).fetchone()[0]
    )


def test_0001_чинит_существующую_pre_release_schema() -> None:
    base = _base_url_or_skip()
    database = f"efhc_existing_{uuid.uuid4().hex[:12]}"
    admin_url, sqlalchemy_url, psycopg_url = _urls(base, database)
    _create_database(admin_url, database)
    try:
        command.upgrade(_config(sqlalchemy_url), "head")
        with psycopg.connect(psycopg_url) as connection:
            tg_id = 8_991_000_100_001
            global_id = connection.execute(
                "INSERT INTO efhc_core.users "
                "(tg_id, main_balance, bonus_balance) VALUES (%s, %s, %s) "
                "RETURNING global_id",
                (tg_id, Decimal("25.00000000"), Decimal("3.00000000")),
            ).fetchone()[0]
            connection.execute(
                "ALTER TABLE efhc_admin.admin_whitelist "
                "ALTER COLUMN global_id DROP NOT NULL"
            )
            connection.execute(
                "INSERT INTO efhc_admin.admin_whitelist (tg_id, global_id) "
                "VALUES (%s, NULL)",
                (tg_id,),
            )
            connection.execute(
                "ALTER TABLE efhc_core.user_skins "
                "ADD COLUMN IF NOT EXISTS tg_id bigint"
            )
            connection.execute(
                "ALTER TABLE efhc_core.ranks_snapshots "
                "ADD COLUMN IF NOT EXISTS tg_id bigint"
            )
            connection.execute(
                "UPDATE efhc_core.identity_migration_control SET "
                "dual_write_enabled=true, shadow_read_enabled=false, "
                "legacy_authoritative=true, "
                "nonfinancial_read_global_id_enabled=false, "
                "financial_read_global_id_enabled=false"
            )
            connection.execute("DELETE FROM efhc_core.alembic_version")
            connection.commit()

        command.upgrade(_config(sqlalchemy_url), "head")

        with psycopg.connect(psycopg_url) as connection:
            revision = connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone()[0]
            assert revision == "0001"
            repaired = connection.execute(
                "SELECT global_id FROM efhc_admin.admin_whitelist "
                "WHERE tg_id=%s",
                (tg_id,),
            ).fetchone()[0]
            assert int(repaired) == int(global_id)
            nullable = connection.execute(
                "SELECT is_nullable FROM information_schema.columns "
                "WHERE table_schema='efhc_admin' "
                "AND table_name='admin_whitelist' "
                "AND column_name='global_id'"
            ).fetchone()[0]
            assert nullable == "NO"
            for table in ("user_skins", "ranks_snapshots"):
                legacy_column = connection.execute(
                    "SELECT count(*) FROM information_schema.columns "
                    "WHERE table_schema='efhc_core' AND table_name=%s "
                    "AND column_name='tg_id'",
                    (table,),
                ).fetchone()[0]
                assert int(legacy_column) == 0
            control = connection.execute(
                "SELECT dual_write_enabled, shadow_read_enabled, "
                "legacy_authoritative, "
                "nonfinancial_read_global_id_enabled, "
                "financial_read_global_id_enabled "
                "FROM efhc_core.identity_migration_control "
                "WHERE singleton_id=1"
            ).fetchone()
            assert tuple(control) == (False, True, False, True, True)
            assert _fk_count(connection) == EXPECTED_FK_COUNT
            balance = connection.execute(
                "SELECT main_balance, bonus_balance FROM efhc_core.users "
                "WHERE global_id=%s",
                (global_id,),
            ).fetchone()
            assert tuple(map(Decimal, balance)) == (
                Decimal("25.00000000"),
                Decimal("3.00000000"),
            )
    finally:
        _drop_database(admin_url, database)


def test_0001_fail_closed_при_orphan_admin_provider() -> None:
    base = _base_url_or_skip()
    database = f"efhc_orphan_{uuid.uuid4().hex[:12]}"
    admin_url, sqlalchemy_url, psycopg_url = _urls(base, database)
    _create_database(admin_url, database)
    try:
        command.upgrade(_config(sqlalchemy_url), "head")
        with psycopg.connect(psycopg_url) as connection:
            connection.execute(
                "ALTER TABLE efhc_admin.admin_whitelist "
                "ALTER COLUMN global_id DROP NOT NULL"
            )
            connection.execute(
                "INSERT INTO efhc_admin.admin_whitelist (tg_id, global_id) "
                "VALUES (%s, NULL)",
                (8_991_999_999_991,),
            )
            connection.execute("DELETE FROM efhc_core.alembic_version")
            connection.commit()

        with pytest.raises(
            RuntimeError,
            match="admin whitelist global_id backfill incomplete",
        ):
            command.upgrade(_config(sqlalchemy_url), "head")
    finally:
        _drop_database(admin_url, database)
