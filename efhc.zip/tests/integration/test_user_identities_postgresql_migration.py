"""PostgreSQL package цикла 1611: PG-0 → 0003 → constraints.

В среде без PostgreSQL этот module корректно пропускается. В
каноническом GitHub CI тест обязан выполниться без skips.
"""

from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from ops.identity.pg0_user_identities_preflight import collect_pg0
from sqlalchemy import create_engine
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError

try:
    import psycopg
    from psycopg import errors
except ModuleNotFoundError as exc:
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        raise RuntimeError(
            "Канонический CI обязан установить requirements-test.txt"
        ) from exc
    pytest.skip(
        "psycopg отсутствует; PostgreSQL package локально не выполнен",
        allow_module_level=True,
    )

ROOT = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skip(
        reason=(
            "Исторический pre-squash переход удалён; "
            "final schema проверяет release 0001"
        )
    ),
]


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _sync_sqlalchemy_url(url: str) -> str:
    parsed = make_url(url)
    return parsed.set(drivername="postgresql+psycopg").render_as_string(
        hide_password=False
    )


def _async_sqlalchemy_url(url: str) -> str:
    parsed = make_url(url)
    return parsed.set(drivername="postgresql+asyncpg").render_as_string(
        hide_password=False
    )


def _database_url_or_skip() -> str:
    url = os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if url:
        return _sync_sqlalchemy_url(url)
    message = "DATABASE_URL обязателен для реального PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _alembic_config(database_url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    config.set_main_option("sqlalchemy.url", database_url)
    return config


def _set_database_environment(database_url: str) -> dict[str, str | None]:
    names = (
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    )
    previous = {name: os.getenv(name) for name in names}
    os.environ["DATABASE_URL"] = database_url
    os.environ["SYNC_DATABASE_URL"] = database_url
    os.environ["ASYNC_DATABASE_URL"] = _async_sqlalchemy_url(database_url)
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(database_url)
    return previous


def _restore_environment(previous: dict[str, str | None]) -> None:
    for name, value in previous.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


def _financial_snapshot(connection) -> tuple[object, ...]:
    row = connection.execute(
        """
        SELECT
            count(*),
            coalesce(sum(main_balance), 0),
            coalesce(sum(bonus_balance), 0),
            coalesce(sum(available_kwh), 0),
            coalesce(sum(total_generated_kwh), 0),
            coalesce(sum(exchanged_kwh_total), 0)
        FROM efhc_core.users
        """
    ).fetchone()
    assert row is not None
    counts = connection.execute(
        """
        SELECT
            (SELECT count(*) FROM efhc_core.panels),
            (SELECT count(*) FROM efhc_core.efhc_transfers_log),
            (SELECT count(*) FROM efhc_core.withdraw_requests),
            (SELECT count(*) FROM efhc_core.wallet_bindings)
        """
    ).fetchone()
    assert counts is not None
    return tuple(row) + tuple(counts)


def test_pg0_0002_затем_user_identities_0003_constraints() -> None:
    base_url = _database_url_or_skip()
    if base_url.lower().startswith("sqlite"):
        pytest.fail("SQLite запрещён: требуется настоящий PostgreSQL")

    parsed = make_url(base_url)
    database_name = f"identity_1611_{uuid.uuid4().hex[:12]}"
    admin_url = parsed.set(database="postgres")
    test_url = parsed.set(database=database_name)
    admin_psycopg = _to_psycopg_url(admin_url.render_as_string(False))
    test_sqlalchemy = test_url.render_as_string(False)
    test_psycopg = _to_psycopg_url(test_sqlalchemy)

    with psycopg.connect(admin_psycopg, autocommit=True) as admin:
        admin.execute(f'CREATE DATABASE "{database_name}"')

    previous = _set_database_environment(test_sqlalchemy)
    try:
        config = _alembic_config(test_sqlalchemy)
        command.upgrade(config, "0001")

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            version = connection.execute(
                "SELECT current_setting('server_version_num')::int"
            ).fetchone()
            assert version is not None and int(version[0]) >= 140000
            revision = connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone()
            assert revision == ("0001",)

            # Текущий ORM может создать будущую таблицу при clean
            # bootstrap через 0001. На существующей production revision
            # 0002 таблицы нет, поэтому тест удаляет только её пустой
            # bootstrap-вариант перед read-only снимком PG-0.
            connection.execute(
                "DROP TABLE IF EXISTS efhc_core.user_roles"
            )
            connection.execute(
                "DROP TABLE IF EXISTS efhc_core.auth_sessions"
            )
            connection.execute(
                "DROP TABLE IF EXISTS efhc_core.auth_challenges"
            )
            connection.execute(
                "DROP TABLE IF EXISTS efhc_core.user_identities"
            )
            assert connection.execute(
                "SELECT to_regclass('efhc_core.user_identities')"
            ).fetchone() == (None,)
            nullable = connection.execute(
                """
                SELECT is_nullable
                FROM information_schema.columns
                WHERE table_schema = 'efhc_core'
                  AND table_name = 'users'
                  AND column_name = 'user_id'
                """
            ).fetchone()
            assert nullable == ("YES",)
            assert connection.execute(
                "SELECT to_regclass('efhc_core.users_user_id_seq')"
            ).fetchone()[0] is not None

            connection.execute(
                """
                INSERT INTO efhc_core.users (
                    tg_id,
                    user_id,
                    main_balance,
                    bonus_balance,
                    total_generated_kwh,
                    exchanged_kwh_total
                ) VALUES
                    (910000001, 1001, 10.00000001, 2.00000002, 5, 1),
                    (910000002, 1002, 20.00000003, 3.00000004, 7, 2)
                """
            )
            before = _financial_snapshot(connection)

        engine = create_engine(test_sqlalchemy, future=True)
        try:
            with engine.connect() as sql_connection:
                pg0 = collect_pg0(
                    sql_connection,
                    expected_revision="0001",
                )
        finally:
            engine.dispose()
        assert pg0.passed, pg0.violations
        assert pg0.identity_table_state == "ABSENT"
        assert pg0.revision == "0001"

        command.upgrade(config, "0003")

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            revision = connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone()
            assert revision == ("0003",)
            after = _financial_snapshot(connection)
            assert after == before

            constraint_names = {
                row[0]
                for row in connection.execute(
                    """
                    SELECT c.conname
                    FROM pg_constraint c
                    JOIN pg_class t ON t.oid = c.conrelid
                    JOIN pg_namespace n ON n.oid = t.relnamespace
                    WHERE n.nspname = 'efhc_core'
                      AND t.relname = 'user_identities'
                    """
                ).fetchall()
            }
            assert {
                "pk_user_identities",
                "fk_user_identities_global_id_users_user_id",
                "uq_user_identities_provider_tenant_subject",
                "ck_user_identities_global_id_range",
                "ck_user_identities_provider_format",
                "ck_user_identities_provider_not_mock",
                "ck_user_identities_tenant_length",
                "ck_user_identities_subject_length",
                "ck_user_identities_status",
                "ck_user_identities_verified_at",
                "ck_user_identities_primary_state",
            } <= constraint_names
            index_names = {
                row[0]
                for row in connection.execute(
                    """
                    SELECT indexname
                    FROM pg_indexes
                    WHERE schemaname = 'efhc_core'
                      AND tablename = 'user_identities'
                    """
                ).fetchall()
            }
            assert {
                "ix_user_identities_global_id",
                "ix_user_identities_provider_status",
                "uq_user_identities_primary_per_global",
            } <= index_names

            connection.execute(
                """
                INSERT INTO efhc_core.user_identities (
                    global_id,
                    provider,
                    provider_tenant,
                    provider_subject,
                    is_verified,
                    verified_at,
                    is_primary
                ) VALUES (
                    1001,
                    'telegram',
                    'default',
                    '910000001',
                    true,
                    now(),
                    true
                )
                """
            )

            with pytest.raises(errors.UniqueViolation):
                connection.execute(
                    """
                    INSERT INTO efhc_core.user_identities (
                        global_id,
                        provider,
                        provider_tenant,
                        provider_subject
                    ) VALUES (
                        1002,
                        'telegram',
                        'default',
                        '910000001'
                    )
                    """
                )

            with pytest.raises(errors.ForeignKeyViolation):
                connection.execute(
                    """
                    INSERT INTO efhc_core.user_identities (
                        global_id,
                        provider,
                        provider_subject
                    ) VALUES (9999999999, 'telegram', 'missing')
                    """
                )

            with pytest.raises(errors.CheckViolation):
                connection.execute(
                    """
                    INSERT INTO efhc_core.user_identities (
                        global_id,
                        provider,
                        provider_subject,
                        is_primary
                    ) VALUES (1002, 'telegram', 'unverified', true)
                    """
                )

            with pytest.raises(errors.CheckViolation):
                connection.execute(
                    """
                    INSERT INTO efhc_core.user_identities (
                        global_id,
                        provider,
                        provider_subject
                    ) VALUES (1002, 'Telegram', 'uppercase-provider')
                    """
                )

            with pytest.raises(errors.CheckViolation):
                connection.execute(
                    """
                    INSERT INTO efhc_core.user_identities (
                        global_id,
                        provider,
                        provider_subject
                    ) VALUES (1002, 'mock', 'test-only')
                    """
                )

            with pytest.raises(errors.UniqueViolation):
                connection.execute(
                    """
                    INSERT INTO efhc_core.user_identities (
                        global_id,
                        provider,
                        provider_subject,
                        is_verified,
                        verified_at,
                        is_primary
                    ) VALUES (
                        1001,
                        'ton_wallet',
                        '0:canonical-address',
                        true,
                        now(),
                        true
                    )
                    """
                )

            with pytest.raises(DBAPIError):
                command.downgrade(config, "0001")
            assert connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone() == ("0003",)
            assert connection.execute(
                "SELECT count(*) FROM efhc_core.user_identities"
            ).fetchone()[0] == 1

            connection.execute(
                "DELETE FROM efhc_core.user_identities"
            )

        command.downgrade(config, "0001")
        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            assert connection.execute(
                "SELECT to_regclass('efhc_core.user_identities')"
            ).fetchone() == (None,)
            assert _financial_snapshot(connection) == before

        command.upgrade(config, "0003")
        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            assert connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone() == ("0003",)
    finally:
        _restore_environment(previous)
        with psycopg.connect(admin_psycopg, autocommit=True) as admin:
            admin.execute(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()",
                (database_name,),
            )
            admin.execute(f'DROP DATABASE IF EXISTS "{database_name}"')
