"""Authenticated referral API proof on the real PostgreSQL schema."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta

import pytest
from app.deps import get_db
from app.identity.nonfinancial_read_dependency import (
    get_nonfinancial_read_owner,
)
from app.identity.nonfinancial_read_switch import (
    resolve_nonfinancial_read_owner,
)
from app.main import app
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]

INVITER_TG = 8_842_000_000_000
OTHER_INVITER_TG = INVITER_TG + 100
ACTIVE_1 = INVITER_TG + 1
ACTIVE_2 = INVITER_TG + 2
INACTIVE_1 = INVITER_TG + 3


async def _seed_api_data(db: AsyncSession) -> None:
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.identity_migration_control (
                singleton_id, dual_write_enabled, shadow_read_enabled,
                legacy_authoritative,
                nonfinancial_read_global_id_enabled,
                nonfinancial_read_rollback_ready
            ) VALUES (1, TRUE, TRUE, TRUE, TRUE, TRUE)
            ON CONFLICT (singleton_id) DO UPDATE SET
                dual_write_enabled = EXCLUDED.dual_write_enabled,
                shadow_read_enabled = EXCLUDED.shadow_read_enabled,
                legacy_authoritative = EXCLUDED.legacy_authoritative,
                nonfinancial_read_global_id_enabled =
                    EXCLUDED.nonfinancial_read_global_id_enabled,
                nonfinancial_read_rollback_ready =
                    EXCLUDED.nonfinancial_read_rollback_ready,
                updated_at = now()
            """
        )
    )
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.users (
                tg_id, username, main_balance, bonus_balance, is_active
            )
            VALUES
                (:inviter, 'inviter', 0, 0, TRUE),
                (:other, 'other', 0, 0, TRUE),
                (:active1, 'active_1', 0, 0, TRUE),
                (:active2, 'active_2', 0, 0, TRUE),
                (:inactive1, 'inactive_1', 0, 0, TRUE)
            """
        ),
        {
            "inviter": INVITER_TG,
            "other": OTHER_INVITER_TG,
            "active1": ACTIVE_1,
            "active2": ACTIVE_2,
            "inactive1": INACTIVE_1,
        },
    )
    shared_time = datetime.now(UTC) - timedelta(minutes=2)
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.referral_links (
                inviter_tg_id, invitee_tg_id, created_at, activated_at
            )
            VALUES
                (:inviter, :active1, :shared_time, :shared_time),
                (:inviter, :active2, :shared_time, :shared_time),
                (:inviter, :inactive1, :inactive_time, NULL)
            """
        ),
        {
            "inviter": INVITER_TG,
            "active1": ACTIVE_1,
            "active2": ACTIVE_2,
            "inactive1": INACTIVE_1,
            "shared_time": shared_time,
            "inactive_time": shared_time + timedelta(minutes=1),
        },
    )
    await db.execute(
        text(
            """
            INSERT INTO efhc_core.panels (
                tg_id, public_id, is_active, is_archived,
                activated_at, expires_at, archived_at,
                last_generated_at, base_gen_per_sec, generated_kwh
            )
            VALUES
                (:active1, 'ITAPI00000001', TRUE, FALSE,
                 NOW(), NOW() + INTERVAL '180 days', NULL,
                 NOW(), 0, 0),
                (:active2, 'ITAPI00000002', FALSE, TRUE,
                 NOW(), NOW() + INTERVAL '180 days', NOW(),
                 NOW(), 0, 0)
            """
        ),
        {"active1": ACTIVE_1, "active2": ACTIVE_2},
    )
    await db.commit()


@asynccontextmanager
async def _client_for_user(
    *,
    db: AsyncSession,
    tg_id: int,
) -> AsyncIterator[AsyncClient]:
    async def override_db() -> AsyncIterator[AsyncSession]:
        yield db

    async def override_owner():
        return await resolve_nonfinancial_read_owner(
            db,
            tg_id=int(tg_id),
        )

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_nonfinancial_read_owner] = (
        override_owner
    )
    transport = ASGITransport(app=app)
    try:
        async with AsyncClient(
            transport=transport,
            base_url="http://testserver",
        ) as client:
            yield client
    finally:
        app.dependency_overrides.clear()


async def test_active_inactive_cursor_and_archive_semantics(
    db_session: AsyncSession,
) -> None:
    await _seed_api_data(db_session)
    async with _client_for_user(db=db_session, tg_id=INVITER_TG) as client:
        first = await client.get(
            "/api/referrals/active/me",
            params={"limit": 1},
        )
        assert first.status_code == 200
        first_payload = first.json()
        assert [item["tg_id"] for item in first_payload["items"]] == [
            ACTIVE_2
        ]
        assert first_payload["items"][0]["is_active"] is True
        assert first_payload["next_cursor"]

        second = await client.get(
            "/api/referrals/active/me",
            params={
                "limit": 1,
                "cursor": first_payload["next_cursor"],
            },
        )
        assert second.status_code == 200
        second_payload = second.json()
        assert [item["tg_id"] for item in second_payload["items"]] == [
            ACTIVE_1
        ]
        assert second_payload["next_cursor"] is None
        assert set(
            item["tg_id"]
            for item in first_payload["items"] + second_payload["items"]
        ) == {ACTIVE_1, ACTIVE_2}

        inactive = await client.get(
            "/api/referrals/inactive/me",
            params={"limit": 10},
        )
        assert inactive.status_code == 200
        payload = inactive.json()
        assert [item["tg_id"] for item in payload["items"]] == [
            INACTIVE_1
        ]
        assert payload["items"][0]["panels_count"] == 0


async def test_etag_returns_304_and_changes_after_dataset_mutation(
    db_session: AsyncSession,
) -> None:
    await _seed_api_data(db_session)
    async with _client_for_user(db=db_session, tg_id=INVITER_TG) as client:
        first = await client.get(
            "/api/referrals/inactive/me",
            params={"limit": 10},
        )
        assert first.status_code == 200
        old_etag = first.headers["etag"]
        repeated = await client.get(
            "/api/referrals/inactive/me",
            params={"limit": 10},
            headers={"If-None-Match": old_etag},
        )
        assert repeated.status_code == 304
        assert repeated.headers["etag"] == old_etag

        new_tg = INVITER_TG + 4
        await db_session.execute(
            text(
                "INSERT INTO efhc_core.users "
                "(tg_id, username, is_active) "
                "VALUES (:tg, 'new_inactive', TRUE)"
            ),
            {"tg": new_tg},
        )
        await db_session.execute(
            text(
                "INSERT INTO efhc_core.referral_links "
                "(inviter_tg_id, invitee_tg_id, created_at) "
                "VALUES (:inviter, :invitee, NOW())"
            ),
            {"inviter": INVITER_TG, "invitee": new_tg},
        )
        await db_session.commit()

        changed = await client.get(
            "/api/referrals/inactive/me",
            params={"limit": 10},
            headers={"If-None-Match": old_etag},
        )
        assert changed.status_code == 200
        assert changed.headers["etag"] != old_etag
        assert new_tg in [item["tg_id"] for item in changed.json()["items"]]


async def test_legacy_owner_routes_removed(
    db_session: AsyncSession,
) -> None:
    await _seed_api_data(db_session)
    async with _client_for_user(db=db_session, tg_id=INVITER_TG) as client:
        for path in (
            "/api/referrals/stats",
            "/api/referrals/counters",
            "/api/referrals/active",
            "/api/referrals/inactive",
        ):
            response = await client.get(
                path,
                params={"parent_tg_id": INVITER_TG},
            )
            assert response.status_code == 404


async def test_me_routes_never_accept_another_owner(
    db_session: AsyncSession,
) -> None:
    await _seed_api_data(db_session)
    async with _client_for_user(db=db_session, tg_id=INVITER_TG) as client:
        stats = await client.get(
            "/api/referrals/stats/me",
            params={"parent_tg_id": OTHER_INVITER_TG},
        )
        counters = await client.get(
            "/api/referrals/counters/me",
            params={"parent_tg_id": OTHER_INVITER_TG},
        )
        assert stats.status_code == 200
        assert counters.status_code == 200
        assert stats.json()["total_referrals"] == 3
        assert counters.json() == {"total": 3, "active": 2, "inactive": 1}
