"""Real PostgreSQL contract non-financial read switch цикла 1625."""

from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from ops.identity.postgresql_nonfinancial_read_switch_gate import (
    collect,
)
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError

try:
    import psycopg
except ModuleNotFoundError as exc:
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        raise RuntimeError(
            "Канонический CI обязан установить psycopg"
        ) from exc
    pytest.skip(
        "psycopg отсутствует; PostgreSQL локально не запущен",
        allow_module_level=True,
    )

ROOT = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skip(
        reason=(
            "Исторический pre-squash переход удалён; "
            "final schema проверяет release 0001"
        )
    ),
]


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _database_url_or_skip() -> str:
    value = os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if value:
        return value
    message = "DATABASE_URL обязателен для реального PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _config(url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    config.set_main_option("sqlalchemy.url", url)
    return config


def _set_environment(url: str) -> dict[str, str | None]:
    names = (
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    )
    previous = {name: os.getenv(name) for name in names}
    os.environ["DATABASE_URL"] = url
    os.environ["SYNC_DATABASE_URL"] = url
    os.environ["ASYNC_DATABASE_URL"] = url
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(url)
    return previous


def _restore_environment(previous: dict[str, str | None]) -> None:
    for name, value in previous.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


def test_0010_nonfinancial_read_switch_и_rollback_postgresql() -> None:
    base_url = _database_url_or_skip()
    if base_url.lower().startswith("sqlite"):
        pytest.fail("SQLite запрещён: нужен PostgreSQL")

    parsed = make_url(base_url)
    database = f"read_switch_1625_{uuid.uuid4().hex[:12]}"
    admin_url = parsed.set(database="postgres")
    test_url = parsed.set(database=database)
    admin_psycopg = _to_psycopg_url(
        admin_url.render_as_string(hide_password=False)
    )
    test_sqlalchemy = test_url.render_as_string(hide_password=False)
    test_psycopg = _to_psycopg_url(test_sqlalchemy)

    with psycopg.connect(admin_psycopg, autocommit=True) as admin:
        admin.execute(f'CREATE DATABASE "{database}"')

    previous = _set_environment(test_sqlalchemy)
    try:
        config = _config(test_sqlalchemy)
        command.upgrade(config, "0009")
        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            row = connection.execute(
                """
                INSERT INTO efhc_core.users (tg_id)
                VALUES (925000001)
                RETURNING global_id
                """
            ).fetchone()
            assert row is not None
            global_id = int(row[0])
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = false,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
            connection.execute(
                """
                INSERT INTO efhc_core.scheduler_task_log (
                    task_name,
                    status,
                    payload
                ) VALUES (
                    'resync_user_energy',
                    'pending',
                    '{"tg_id": 925000001}'::jsonb
                )
                """
            )

        with pytest.raises(DBAPIError, match="read switch gate failed"):
            command.upgrade(config, "0010")

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = true,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
            row = connection.execute(
                """
                UPDATE efhc_core.scheduler_task_log
                SET payload = payload
                WHERE task_name = 'resync_user_energy'
                RETURNING global_id
                """
            ).fetchone()
            assert row == (global_id,)

        command.upgrade(config, "0010")
        report = collect(test_sqlalchemy)
        assert report["статус"] == "PASS", report
        assert report["alembic_revision"] == "0010"
        assert report["nonfinancial_read_global_id_enabled"] is True
        assert report["legacy_authoritative"] is True
        telemetry = report["telemetry"]
        assert isinstance(telemetry, dict)
        assert all(int(value) == 0 for value in telemetry.values())

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET nonfinancial_read_global_id_enabled = false,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
            control = connection.execute(
                """
                SELECT
                    nonfinancial_read_global_id_enabled,
                    nonfinancial_read_rollback_ready,
                    legacy_authoritative
                FROM efhc_core.identity_migration_control
                WHERE singleton_id = 1
                """
            ).fetchone()
            assert control == (False, True, True)
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET nonfinancial_read_global_id_enabled = true,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
    finally:
        _restore_environment(previous)
        with psycopg.connect(admin_psycopg, autocommit=True) as admin:
            admin.execute(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()",
                (database,),
            )
            admin.execute(f'DROP DATABASE IF EXISTS "{database}"')
