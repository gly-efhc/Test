"""PostgreSQL qualification подготовки cutover цикла 1645."""

from __future__ import annotations

import pytest
from app.identity.global_id_cutover_service import (
    GlobalIdCutoverError,
    execute_global_id_cutover,
    rollback_global_id_cutover,
)
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

pytestmark = pytest.mark.integration


@pytest.mark.asyncio
async def test_0002_head_разрешает_atomic_cutover_и_rollback(
    db_session: AsyncSession,
) -> None:
    revision = (
        await db_session.execute(
            text("SELECT version_num FROM efhc_core.alembic_version")
        )
    ).scalar_one()
    assert revision == "0002"
    await db_session.commit()

    preflight = await execute_global_id_cutover(db_session)
    assert preflight.ready is True
    control = (
        await db_session.execute(
            text(
                "SELECT legacy_authoritative, "
                "financial_read_global_id_enabled, "
                "nonfinancial_read_global_id_enabled "
                "FROM efhc_core.identity_migration_control "
                "WHERE singleton_id = 1"
            )
        )
    ).one()
    assert control.legacy_authoritative is False
    assert control.financial_read_global_id_enabled is True
    assert control.nonfinancial_read_global_id_enabled is True
    await db_session.commit()

    await rollback_global_id_cutover(db_session)
    restored = (
        await db_session.execute(
            text(
                "SELECT legacy_authoritative, "
                "financial_read_global_id_enabled, "
                "nonfinancial_read_global_id_enabled "
                "FROM efhc_core.identity_migration_control "
                "WHERE singleton_id = 1"
            )
        )
    ).one()
    assert restored.legacy_authoritative is True
    assert restored.financial_read_global_id_enabled is False
    assert restored.nonfinancial_read_global_id_enabled is False


@pytest.mark.asyncio
async def test_cutover_fail_closed_при_shadow_mismatch(
    db_session: AsyncSession,
) -> None:
    first_global_id = (
        await db_session.execute(
            text(
                "INSERT INTO efhc_core.users (tg_id) "
                "VALUES (899164500001) RETURNING global_id"
            )
        )
    ).scalar_one()
    second_global_id = (
        await db_session.execute(
            text(
                "INSERT INTO efhc_core.users (tg_id) "
                "VALUES (899164500002) RETURNING global_id"
            )
        )
    ).scalar_one()

    # Создаём реальную mismatch-строку в underlying table. View telemetry
    # read-only и не должна использоваться как искусственная test-table.
    await db_session.execute(
        text(
            """
            UPDATE efhc_core.identity_migration_control
               SET financial_read_global_id_enabled = FALSE,
                   nonfinancial_read_global_id_enabled = FALSE,
                   dual_write_enabled = FALSE,
                   updated_at = now()
             WHERE singleton_id = 1
            """
        )
    )
    await db_session.execute(
        text(
            """
            INSERT INTO efhc_core.task_complete_lock
                (idempotency_key, tg_id, global_id, task_code, credited)
            VALUES
                ('cycle1645-mismatch', 899164500001, :wrong_global_id,
                 'cycle1645-cutover', FALSE)
            """
        ),
        {"wrong_global_id": int(second_global_id)},
    )
    await db_session.execute(
        text(
            """
            UPDATE efhc_core.identity_migration_control
               SET dual_write_enabled = TRUE,
                   nonfinancial_read_global_id_enabled = TRUE,
                   financial_read_global_id_enabled = TRUE,
                   updated_at = now()
             WHERE singleton_id = 1
            """
        )
    )
    await db_session.commit()

    assert int(first_global_id) != int(second_global_id)
    with pytest.raises(GlobalIdCutoverError, match="preflight не готов"):
        await execute_global_id_cutover(db_session)

    legacy = (
        await db_session.execute(
            text(
                "SELECT legacy_authoritative "
                "FROM efhc_core.identity_migration_control "
                "WHERE singleton_id = 1"
            )
        )
    ).scalar_one()
    assert legacy is True
