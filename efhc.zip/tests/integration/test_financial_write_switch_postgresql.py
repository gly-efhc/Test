"""PostgreSQL qualification write-side owner boundary цикла 1640."""

from __future__ import annotations

import pytest
from app.identity.financial_write_switch import (
    resolve_and_lock_financial_write_owner,
)
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

pytestmark = pytest.mark.integration


async def _seed_control_and_users(db: AsyncSession) -> tuple[int, int]:
    await db.execute(
        text(
            "INSERT INTO efhc_core.identity_migration_control "
            "(singleton_id) VALUES (1) "
            "ON CONFLICT (singleton_id) DO NOTHING"
        )
    )
    telegram_global_id = int(
        (
            await db.execute(
                text(
                    "INSERT INTO efhc_core.users (tg_id) "
                    "VALUES (916400001) RETURNING global_id"
                )
            )
        ).scalar_one()
    )
    ton_global_id = int(
        (
            await db.execute(
                text(
                    "INSERT INTO efhc_core.users (tg_id, ton_wallet) "
                    "VALUES (NULL, 'cycle1640-ton-only') "
                    "RETURNING global_id"
                )
            )
        ).scalar_one()
    )
    await db.commit()
    return telegram_global_id, ton_global_id


@pytest.mark.asyncio
async def test_write_owner_разрешает_tg_и_ton_only_global_id(
    db_session: AsyncSession,
) -> None:
    telegram_global_id, ton_global_id = await _seed_control_and_users(
        db_session
    )

    async with db_session.begin():
        telegram_owner = await resolve_and_lock_financial_write_owner(
            db_session,
            tg_id=916400001,
        )
        assert telegram_owner.global_id == telegram_global_id
        assert telegram_owner.legacy_tg_id == 916400001
        assert telegram_owner.rollback_ready is True

    async with db_session.begin():
        ton_owner = await resolve_and_lock_financial_write_owner(
            db_session,
            global_id=ton_global_id,
        )
        assert ton_owner.global_id == ton_global_id
        assert ton_owner.legacy_tg_id is None
        assert ton_owner.rollback_ready is True


@pytest.mark.asyncio
async def test_write_owner_for_update_блокирует_параллельную_мутацию(
    db_session: AsyncSession,
    integration_session_factory: async_sessionmaker[AsyncSession],
) -> None:
    telegram_global_id, _ = await _seed_control_and_users(db_session)

    async with (
        integration_session_factory() as first,
        integration_session_factory() as second,
        first.begin(),
    ):
        owner = await resolve_and_lock_financial_write_owner(
            first,
            global_id=telegram_global_id,
        )
        assert owner.global_id == telegram_global_id

        await second.execute(text("SET LOCAL lock_timeout = '100ms'"))
        with pytest.raises(DBAPIError):
            await resolve_and_lock_financial_write_owner(
                second,
                tg_id=916400001,
            )
        await second.rollback()