"""Real PostgreSQL contract financial read switch цикла 1627."""

from __future__ import annotations

import os
import uuid
from decimal import Decimal
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from ops.identity.postgresql_financial_read_switch_gate import collect
from ops.identity.postgresql_financial_shadow_validation_gate import (
    collect as collect_shadow,
)
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError

psycopg = pytest.importorskip("psycopg")

ROOT = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skip(
        reason=(
            "Исторический pre-squash переход удалён; "
            "final schema проверяет release 0001"
        )
    ),
]


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _database_url_or_skip() -> str:
    url = os.getenv("SYNC_DATABASE_URL") or os.getenv("DATABASE_URL")
    if url and str(url).startswith("postgresql"):
        return str(url)
    message = "Тест требует реальный PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _config(url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option("script_location", str(ROOT / "backend/migrations"))
    config.set_main_option("sqlalchemy.url", url)
    return config


def _set_environment(url: str) -> dict[str, str | None]:
    names = (
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    )
    previous = {name: os.getenv(name) for name in names}
    os.environ["DATABASE_URL"] = url
    os.environ["SYNC_DATABASE_URL"] = url
    os.environ["ASYNC_DATABASE_URL"] = url
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(url)
    return previous


def _restore_environment(previous: dict[str, str | None]) -> None:
    for name, value in previous.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


def test_0011_financial_read_switch_и_rollback_postgresql() -> None:
    base_url = _database_url_or_skip()
    parsed = make_url(base_url)
    database = f"financial_read_1627_{uuid.uuid4().hex[:12]}"
    admin_url = parsed.set(database="postgres")
    test_url = parsed.set(database=database)
    admin_psycopg = _to_psycopg_url(
        admin_url.render_as_string(hide_password=False)
    )
    test_sqlalchemy = test_url.render_as_string(hide_password=False)
    test_psycopg = _to_psycopg_url(test_sqlalchemy)

    with psycopg.connect(admin_psycopg, autocommit=True) as admin:
        admin.execute(f'CREATE DATABASE "{database}"')

    previous = _set_environment(test_sqlalchemy)
    try:
        command.upgrade(_config(test_sqlalchemy), "0010")
        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            global_id = int(
                connection.execute(
                    """
                    INSERT INTO efhc_core.users (tg_id)
                    VALUES (927000001)
                    RETURNING global_id
                    """
                ).fetchone()[0]
            )
            connection.execute(
                """
                INSERT INTO efhc_core.efhc_transfers_log (
                    tg_id, amount, direction, balance_type,
                    reason, idempotency_key
                ) VALUES (
                    927000001, 10.00000000, 'credit', 'main',
                    'cycle1627', 'cycle1627-transfer'
                )
                """
            )
            connection.execute(
                """
                INSERT INTO efhc_core.payment_intents (
                    tg_id, purpose, asset, amount_asset_d8,
                    efhc_amount_d8, status, idempotency_key,
                    payload, to_address,
                    created_at, expires_at, updated_at
                ) VALUES (
                    927000001, 'cycle1627', 'TON', 1.00000000,
                    4.00000000, 'PENDING', 'cycle1627-intent',
                    '{}', 'cycle1627-address',
                    now(), now() + interval '15 minutes', now()
                )
                """
            )

        before = collect_shadow(test_sqlalchemy)
        assert before["статус"] == "PASS", before
        assert before["monetary_discrepancy"] == "0.00000000"

        # Создаём измеряемый fallback и доказываем fail-closed 0011.
        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = false, updated_at = now()
                WHERE singleton_id = 1
                """
            )
            connection.execute(
                """
                INSERT INTO efhc_core.efhc_transfers_log (
                    tg_id, amount, direction, balance_type,
                    reason, idempotency_key
                ) VALUES (
                    927000001, 2.00000000, 'credit', 'main',
                    'cycle1627-fallback', 'cycle1627-fallback'
                )
                """
            )
        with pytest.raises(DBAPIError):
            command.upgrade(_config(test_sqlalchemy), "0011")

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            assert connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone()[0] == "0010"
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = true, updated_at = now()
                WHERE singleton_id = 1
                """
            )
            connection.execute(
                """
                UPDATE efhc_core.efhc_transfers_log
                SET tg_id = tg_id
                WHERE idempotency_key = 'cycle1627-fallback'
                """
            )

        repaired = collect_shadow(test_sqlalchemy)
        assert repaired["статус"] == "PASS", repaired
        assert repaired["monetary_discrepancy"] == "0.00000000"

        command.upgrade(_config(test_sqlalchemy), "0011")
        report = collect(test_sqlalchemy)
        assert report["статус"] == "PASS", report
        assert report["monetary_discrepancy"] == "0.00000000"
        assert report["financial_read_global_id_enabled"] is True
        assert report["financial_read_rollback_ready"] is True

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            row = connection.execute(
                """
                SELECT amount
                FROM efhc_core.efhc_transfers_log
                WHERE global_id = %s
                  AND idempotency_key = 'cycle1627-transfer'
                """,
                (global_id,),
            ).fetchone()
            assert Decimal(row[0]) == Decimal("10.00000000")

            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET financial_read_global_id_enabled = false,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
            control = connection.execute(
                """
                SELECT financial_read_global_id_enabled,
                       financial_read_rollback_ready,
                       legacy_authoritative
                FROM efhc_core.identity_migration_control
                WHERE singleton_id = 1
                """
            ).fetchone()
            assert control == (False, True, True)
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET financial_read_global_id_enabled = true,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )

        final = collect(test_sqlalchemy)
        assert final["статус"] == "PASS", final
        assert final["monetary_discrepancy"] == "0.00000000"
        assert final["precision_unchanged"] is True
        assert final["idempotency_unchanged"] is True
    finally:
        _restore_environment(previous)
        with psycopg.connect(admin_psycopg, autocommit=True) as admin:
            admin.execute(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()",
                (database,),
            )
            admin.execute(f'DROP DATABASE IF EXISTS "{database}"')
