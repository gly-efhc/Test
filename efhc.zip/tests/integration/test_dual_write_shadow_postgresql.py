"""Real PostgreSQL contract dual-write/shadow-read цикла 1624."""

from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from ops.identity.postgresql_dual_write_shadow_gate import collect
from sqlalchemy.engine import make_url

try:
    import psycopg
except ModuleNotFoundError as exc:
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        raise RuntimeError(
            "Канонический CI обязан установить psycopg"
        ) from exc
    pytest.skip(
        "psycopg отсутствует; PostgreSQL локально не запущен",
        allow_module_level=True,
    )

ROOT = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skip(
        reason=(
            "Исторический pre-squash переход удалён; "
            "final schema проверяет release 0001"
        )
    ),
]


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _database_url_or_skip() -> str:
    value = os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if value:
        return value
    message = "DATABASE_URL обязателен для реального PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _config(url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    config.set_main_option("sqlalchemy.url", url)
    return config


def _set_environment(url: str) -> dict[str, str | None]:
    names = (
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    )
    previous = {name: os.getenv(name) for name in names}
    os.environ["DATABASE_URL"] = url
    os.environ["SYNC_DATABASE_URL"] = url
    os.environ["ASYNC_DATABASE_URL"] = url
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(url)
    return previous


def _restore_environment(previous: dict[str, str | None]) -> None:
    for name, value in previous.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


def _create_user(cursor, tg_id: int) -> int:
    cursor.execute(
        """
        INSERT INTO efhc_core.users (tg_id)
        VALUES (%s)
        RETURNING global_id
        """,
        (tg_id,),
    )
    row = cursor.fetchone()
    assert row is not None
    return int(row[0])


def test_0009_dual_write_shadow_rollback_на_postgresql() -> None:
    base_url = _database_url_or_skip()
    if base_url.lower().startswith("sqlite"):
        pytest.fail("SQLite запрещён: нужен PostgreSQL")

    parsed = make_url(base_url)
    database = f"dual_write_1624_{uuid.uuid4().hex[:12]}"
    admin_url = parsed.set(database="postgres")
    test_url = parsed.set(database=database)
    admin_psycopg = _to_psycopg_url(
        admin_url.render_as_string(hide_password=False)
    )
    test_sqlalchemy = test_url.render_as_string(hide_password=False)
    test_psycopg = _to_psycopg_url(test_sqlalchemy)

    with psycopg.connect(admin_psycopg, autocommit=True) as admin:
        admin.execute(f'CREATE DATABASE "{database}"')

    previous = _set_environment(test_sqlalchemy)
    try:
        config = _config(test_sqlalchemy)
        command.upgrade(config, "0009")

        with psycopg.connect(
            test_psycopg,
            autocommit=True,
        ) as connection:
            with connection.cursor() as cursor:
                first_global = _create_user(cursor, 920000001)
                second_global = _create_user(cursor, 920000002)

                cursor.execute(
                    """
                    INSERT INTO efhc_core.efhc_transfers_log (
                        tg_id,
                        amount,
                        direction,
                        balance_type,
                        reason,
                        idempotency_key
                    ) VALUES (
                        920000001,
                        1.00000000,
                        'credit',
                        'main',
                        'cycle1624',
                        'cycle1624-direct'
                    )
                    RETURNING global_id
                    """
                )
                assert cursor.fetchone() == (first_global,)

                cursor.execute(
                    """
                    UPDATE efhc_core.efhc_transfers_log
                    SET tg_id = tg_id
                    WHERE idempotency_key = 'cycle1624-direct'
                    RETURNING global_id
                    """
                )
                assert cursor.fetchone() == (first_global,)

                cursor.execute(
                    """
                    INSERT INTO efhc_core.scheduler_task_log (
                        task_name,
                        status,
                        payload
                    ) VALUES (
                        'resync_user_energy',
                        'pending',
                        '{"tg_id": 920000001}'::jsonb
                    )
                    RETURNING global_id
                    """
                )
                assert cursor.fetchone() == (first_global,)

                cursor.execute(
                    """
                    INSERT INTO efhc_admin.admin_whitelist (
                        id,
                        tg_id,
                        is_active
                    ) VALUES (1, 920000001, true)
                    RETURNING global_id
                    """
                )
                assert cursor.fetchone() == (first_global,)

                cursor.execute(
                    """
                    INSERT INTO efhc_admin.admin_action_log (
                        admin_id,
                        action
                    ) VALUES (1, 'cycle1624')
                    RETURNING actor_global_id
                    """
                )
                assert cursor.fetchone() == (first_global,)

                cursor.execute(
                    """
                    INSERT INTO efhc_admin.idempotency_key (
                        key,
                        scope,
                        admin_id
                    ) VALUES (
                        'cycle1624-admin',
                        'test',
                        1
                    )
                    RETURNING global_id
                    """
                )
                assert cursor.fetchone() == (first_global,)

            with pytest.raises(
                psycopg.errors.RaiseException,
                match="dual-write conflict",
            ):
                connection.execute(
                    """
                    INSERT INTO efhc_core.efhc_transfers_log (
                        tg_id,
                        global_id,
                        amount,
                        direction,
                        balance_type,
                        reason,
                        idempotency_key
                    ) VALUES (
                        %s,
                        %s,
                        2.00000000,
                        'credit',
                        'main',
                        'conflict',
                        'cycle1624-conflict'
                    )
                    """,
                    (920000001, second_global),
                )

            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = false,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
            connection.execute(
                """
                INSERT INTO efhc_core.efhc_transfers_log (
                    tg_id,
                    amount,
                    direction,
                    balance_type,
                    reason,
                    idempotency_key
                ) VALUES (
                    920000001,
                    3.00000000,
                    'credit',
                    'main',
                    'rollback probe',
                    'cycle1624-fallback'
                )
                """
            )
            fallback_row = connection.execute(
                """
                SELECT global_id
                FROM efhc_core.efhc_transfers_log
                WHERE idempotency_key = 'cycle1624-fallback'
                """
            ).fetchone()
            assert fallback_row == (None,)

        fallback_report = collect(test_sqlalchemy)
        assert fallback_report["статус"] == "PASS_WITH_FALLBACK"
        assert fallback_report["legacy_authoritative"] is True
        fallback_totals = fallback_report["telemetry"]
        assert isinstance(fallback_totals, dict)
        assert int(fallback_totals["fallback_rows"]) >= 1
        assert int(fallback_totals["mismatch_rows"]) == 0

        with psycopg.connect(
            test_psycopg,
            autocommit=True,
        ) as connection:
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = true,
                    updated_at = now()
                WHERE singleton_id = 1
                """
            )
            row = connection.execute(
                """
                UPDATE efhc_core.efhc_transfers_log
                SET tg_id = tg_id
                WHERE idempotency_key = 'cycle1624-fallback'
                RETURNING global_id
                """
            ).fetchone()
            assert row == (first_global,)

        final_report = collect(test_sqlalchemy)
        assert final_report["статус"] == "PASS"
        final_totals = final_report["telemetry"]
        assert isinstance(final_totals, dict)
        assert int(final_totals["fallback_rows"]) == 0
        assert int(final_totals["mismatch_rows"]) == 0
        assert int(final_totals["orphan_rows"]) == 0
        assert int(final_totals["ambiguous_rows"]) == 0
        assert final_report["alembic_revision"] == "0009"
    finally:
        _restore_environment(previous)
        with psycopg.connect(admin_psycopg, autocommit=True) as admin:
            admin.execute(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()",
                (database,),
            )
            admin.execute(f'DROP DATABASE IF EXISTS "{database}"')
