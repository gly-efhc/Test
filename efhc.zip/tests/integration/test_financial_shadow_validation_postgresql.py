"""Real PostgreSQL contract financial shadow validation цикла 1626."""

from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from ops.identity.postgresql_financial_shadow_validation_gate import (
    collect,
)
from sqlalchemy.engine import make_url

try:
    import psycopg
except ModuleNotFoundError as exc:
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        raise RuntimeError("Канонический CI обязан установить psycopg") from exc
    pytest.skip(
        "psycopg отсутствует; PostgreSQL локально не запущен",
        allow_module_level=True,
    )

ROOT = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skip(
        reason=(
            "Исторический pre-squash переход удалён; "
            "final schema проверяет release 0001"
        )
    ),
]


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _database_url_or_skip() -> str:
    value = os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if value:
        return value
    message = "DATABASE_URL обязателен для реального PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _config(url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option("script_location", str(ROOT / "backend/migrations"))
    config.set_main_option("sqlalchemy.url", url)
    return config


def _set_environment(url: str) -> dict[str, str | None]:
    names = (
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    )
    previous = {name: os.getenv(name) for name in names}
    os.environ["DATABASE_URL"] = url
    os.environ["SYNC_DATABASE_URL"] = url
    os.environ["ASYNC_DATABASE_URL"] = url
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(url)
    return previous


def _restore_environment(previous: dict[str, str | None]) -> None:
    for name, value in previous.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


def test_финансовая_shadow_validation_точная_и_идемпотентная() -> None:
    base_url = _database_url_or_skip()
    parsed = make_url(base_url)
    database = f"financial_shadow_1626_{uuid.uuid4().hex[:12]}"
    admin_url = parsed.set(database="postgres")
    test_url = parsed.set(database=database)
    admin_psycopg = _to_psycopg_url(
        admin_url.render_as_string(hide_password=False)
    )
    test_sqlalchemy = test_url.render_as_string(hide_password=False)
    test_psycopg = _to_psycopg_url(test_sqlalchemy)

    with psycopg.connect(admin_psycopg, autocommit=True) as admin:
        admin.execute(f'CREATE DATABASE "{database}"')

    previous = _set_environment(test_sqlalchemy)
    try:
        command.upgrade(_config(test_sqlalchemy), "0010")
        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            global_id = int(
                connection.execute(
                    """
                    INSERT INTO efhc_core.users (tg_id)
                    VALUES (926000001)
                    RETURNING global_id
                    """
                ).fetchone()[0]
            )
            connection.execute(
                """
                INSERT INTO efhc_core.efhc_transfers_log (
                    tg_id, amount, direction, balance_type,
                    reason, idempotency_key
                ) VALUES (
                    926000001, 12.34567890, 'credit', 'main',
                    'cycle1626', 'cycle1626-transfer'
                )
                """
            )
            connection.execute(
                """
                INSERT INTO efhc_core.payment_intents (
                    tg_id, purpose, asset, amount_asset_d8,
                    efhc_amount_d8, status, idempotency_key,
                    payload, to_address,
                    created_at, expires_at, updated_at
                ) VALUES (
                    926000001, 'cycle1626', 'TON', 1.25000000,
                    5.00000000, 'PENDING', 'cycle1626-intent',
                    '{}', 'cycle1626-address',
                    now(), now() + interval '15 minutes', now()
                )
                """
            )
            owner_rows = connection.execute(
                """
                SELECT global_id FROM efhc_core.efhc_transfers_log
                WHERE idempotency_key = 'cycle1626-transfer'
                UNION ALL
                SELECT global_id FROM efhc_core.payment_intents
                WHERE idempotency_key = 'cycle1626-intent'
                """
            ).fetchall()
            assert owner_rows == [(global_id,), (global_id,)]

        before = collect(test_sqlalchemy)
        assert before["статус"] == "PASS", before
        assert before["monetary_discrepancy"] == "0.00000000"
        assert before["precision_unchanged"] is True
        assert before["idempotency_unchanged"] is True
        assert before["financial_read_switch"] is False

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = false, updated_at = now()
                WHERE singleton_id = 1
                """
            )
            connection.execute(
                """
                INSERT INTO efhc_core.efhc_transfers_log (
                    tg_id, amount, direction, balance_type,
                    reason, idempotency_key
                ) VALUES (
                    926000001, 2.00000000, 'credit', 'main',
                    'cycle1626-fallback', 'cycle1626-fallback'
                )
                """
            )
        fallback = collect(test_sqlalchemy)
        assert fallback["статус"] == "FAIL"
        assert int(fallback["telemetry"]["fallback_rows"]) >= 1

        with psycopg.connect(test_psycopg, autocommit=True) as connection:
            connection.execute(
                """
                UPDATE efhc_core.identity_migration_control
                SET dual_write_enabled = true, updated_at = now()
                WHERE singleton_id = 1
                """
            )
            connection.execute(
                """
                UPDATE efhc_core.efhc_transfers_log
                SET tg_id = tg_id
                WHERE idempotency_key = 'cycle1626-fallback'
                """
            )
        final = collect(test_sqlalchemy)
        assert final["статус"] == "PASS", final
        assert final["monetary_discrepancy"] == "0.00000000"
        assert final["idempotency_unchanged"] is True
    finally:
        _restore_environment(previous)
        with psycopg.connect(admin_psycopg, autocommit=True) as admin:
            admin.execute(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()",
                (database,),
            )
            admin.execute(f'DROP DATABASE IF EXISTS "{database}"')
