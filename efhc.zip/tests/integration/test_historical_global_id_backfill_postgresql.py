"""Real PostgreSQL qualification для historical backfill цикла 1623."""

from __future__ import annotations

import os
import uuid
from decimal import Decimal
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from ops.identity.postgresql_historical_backfill_gate import collect
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError

try:
    import psycopg
except ModuleNotFoundError as exc:
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        raise RuntimeError(
            "Канонический CI обязан установить psycopg"
        ) from exc
    pytest.skip(
        "psycopg отсутствует; PostgreSQL локально не запущен",
        allow_module_level=True,
    )

ROOT = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skip(
        reason=(
            "Исторический pre-squash переход удалён; "
            "final schema проверяет release 0001"
        )
    ),
]


def _to_psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _sync_url(url: str) -> str:
    parsed = make_url(url)
    return parsed.set(
        drivername="postgresql+psycopg"
    ).render_as_string(hide_password=False)


def _database_url_or_skip() -> str:
    url = os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if url:
        return _sync_url(url)
    message = "DATABASE_URL обязателен для реального PostgreSQL"
    if os.getenv("GITHUB_ACTIONS", "").lower() == "true":
        pytest.fail(message)
    pytest.skip(message)


def _config(url: str) -> Config:
    config = Config(str(ROOT / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend/migrations"),
    )
    config.set_main_option("sqlalchemy.url", url)
    return config


def _set_environment(url: str) -> dict[str, str | None]:
    names = (
        "DATABASE_URL",
        "SYNC_DATABASE_URL",
        "ASYNC_DATABASE_URL",
        "PSYCOPG_URL",
    )
    previous = {name: os.getenv(name) for name in names}
    os.environ["DATABASE_URL"] = url
    os.environ["SYNC_DATABASE_URL"] = url
    os.environ["ASYNC_DATABASE_URL"] = url
    os.environ["PSYCOPG_URL"] = _to_psycopg_url(url)
    return previous


def _restore_environment(previous: dict[str, str | None]) -> None:
    for name, value in previous.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


def _money_snapshot(cursor) -> tuple[Decimal, ...]:
    cursor.execute(
        """
        SELECT
            coalesce(sum(main_balance), 0)::numeric,
            coalesce(sum(bonus_balance), 0)::numeric,
            coalesce(sum(total_generated_kwh), 0)::numeric,
            coalesce(sum(exchanged_kwh_total), 0)::numeric
        FROM efhc_core.users
        """
    )
    users = cursor.fetchone()
    assert users is not None
    cursor.execute(
        "SELECT coalesce(sum(amount), 0)::numeric "
        "FROM efhc_core.efhc_transfers_log"
    )
    transfers = cursor.fetchone()
    assert transfers is not None
    return tuple(Decimal(value) for value in (*users, *transfers))


def _seed_historical_rows(cursor) -> None:
    cursor.execute(
        """
        INSERT INTO efhc_core.users (
            id, user_id, tg_id, main_balance, bonus_balance,
            total_generated_kwh, exchanged_kwh_total
        ) VALUES
            (101, NULL, 910000001, 12.34567890, 1.00000000,
             4.00000000, 1.00000000),
            (202, 9001, 910000002, 5.00000000, 2.00000000,
             3.00000000, 0.50000000)
        """
    )
    cursor.execute(
        """
        INSERT INTO efhc_core.efhc_transfers_log (
            tg_id, amount, direction, balance_type, reason,
            idempotency_key
        ) VALUES (
            910000001, 1.23456789, 'credit', 'main',
            'cycle1623', 'cycle1623-transfer'
        )
        """
    )
    cursor.execute(
        """
        INSERT INTO efhc_core.wallet_bindings (
            tg_id, global_id, wallet_address
        ) VALUES (
            910000001, NULL,
            '0:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
        )
        """
    )
    cursor.execute(
        """
        INSERT INTO efhc_core.scheduler_task_log (
            task_name, status, payload
        ) VALUES (
            'resync_user_energy', 'pending',
            '{"tg_id": 910000001}'::jsonb
        )
        """
    )
    cursor.execute(
        """
        INSERT INTO efhc_admin.admin_whitelist (
            id, tg_id, global_id, is_active
        ) VALUES (1, 910000001, NULL, true)
        """
    )
    cursor.execute(
        """
        INSERT INTO efhc_admin.admin_action_log (
            admin_id, actor_global_id, action
        ) VALUES
            (1, NULL, 'cycle1623_by_admin_pk'),
            (910000001, NULL, 'cycle1623_by_tg_id')
        """
    )
    cursor.execute(
        """
        INSERT INTO efhc_admin.idempotency_key (
            key, scope, admin_id, global_id
        ) VALUES (
            'cycle1623-idempotency', 'test', 1, NULL
        )
        """
    )


def test_0008_fail_closed_и_full_reconciliation_postgresql() -> None:
    base_url = _database_url_or_skip()
    if base_url.lower().startswith("sqlite"):
        pytest.fail("SQLite запрещён: нужен PostgreSQL")

    parsed = make_url(base_url)
    database = f"backfill_1623_{uuid.uuid4().hex[:12]}"
    admin_url = parsed.set(database="postgres")
    test_url = parsed.set(database=database)
    admin_psycopg = _to_psycopg_url(
        admin_url.render_as_string(hide_password=False)
    )
    test_sqlalchemy = test_url.render_as_string(hide_password=False)
    test_psycopg = _to_psycopg_url(test_sqlalchemy)

    with psycopg.connect(admin_psycopg, autocommit=True) as admin:
        admin.execute(f'CREATE DATABASE "{database}"')

    previous = _set_environment(test_sqlalchemy)
    try:
        config = _config(test_sqlalchemy)
        command.upgrade(config, "0007")

        with (
            psycopg.connect(
                test_psycopg,
                autocommit=True,
            ) as connection,
            connection.cursor() as cursor,
        ):
            _seed_historical_rows(cursor)
            cursor.execute(
                """
                INSERT INTO efhc_core.efhc_transfers_log (
                    tg_id, amount, direction, balance_type,
                    reason, idempotency_key
                ) VALUES (
                    999999999, 7.00000000, 'credit', 'main',
                    'orphan', 'cycle1623-orphan'
                )
                """
            )

        with pytest.raises(DBAPIError, match="orphan"):

            command.upgrade(config, "0008")

        with psycopg.connect(
            test_psycopg,
            autocommit=True,
        ) as connection:
            revision = connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone()
            assert revision == ("0007",)
            connection.execute(
                "DELETE FROM efhc_core.efhc_transfers_log "
                "WHERE idempotency_key = 'cycle1623-orphan'"
            )
            with connection.cursor() as cursor:
                before = _money_snapshot(cursor)

        command.upgrade(config, "0008")

        with psycopg.connect(
            test_psycopg,
            autocommit=True,
        ) as connection:
            revision = connection.execute(
                "SELECT version_num FROM efhc_core.alembic_version"
            ).fetchone()
            assert revision == ("0008",)
            with connection.cursor() as cursor:
                after = _money_snapshot(cursor)
            assert after == before
            assert connection.execute(
                "SELECT id, user_id FROM efhc_core.users ORDER BY id"
            ).fetchall() == [(101, 101), (202, 9001)]
            assert connection.execute(
                "SELECT global_id FROM efhc_core.efhc_transfers_log "
                "WHERE idempotency_key = 'cycle1623-transfer'"
            ).fetchone() == (101,)
            assert connection.execute(
                "SELECT global_id FROM efhc_core.wallet_bindings "
                "WHERE tg_id = 910000001"
            ).fetchone() == (101,)
            assert connection.execute(
                "SELECT global_id FROM efhc_core.scheduler_task_log "
                "WHERE task_name = 'resync_user_energy'"
            ).fetchone() == (101,)
            assert connection.execute(
                "SELECT global_id FROM efhc_admin.admin_whitelist "
                "WHERE id = 1"
            ).fetchone() == (101,)
            assert connection.execute(
                "SELECT actor_global_id "
                "FROM efhc_admin.admin_action_log ORDER BY id"
            ).fetchall() == [(101,), (101,)]
            assert connection.execute(
                "SELECT global_id FROM efhc_admin.idempotency_key "
                "WHERE key = 'cycle1623-idempotency'"
            ).fetchone() == (101,)

        report = collect(test_sqlalchemy)
        assert report["статус"] == "PASS"
        assert report["unresolved_rows"] == 0
        assert report["monetary_discrepancy"] == "0.00000000"
        assert report["alembic_revision"] == "0008"
    finally:
        _restore_environment(previous)
        with psycopg.connect(admin_psycopg, autocommit=True) as admin:
            admin.execute(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()",
                (database,),
            )
            admin.execute(f'DROP DATABASE IF EXISTS "{database}"')
