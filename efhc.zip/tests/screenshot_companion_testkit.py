from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATTERN = "screenshots_companion_manifest_v*.json"


@lru_cache(maxsize=1)
def _manifest_entries() -> dict[str, dict[str, Any]]:
    manifests = sorted(
        (ROOT / "reports/generated").glob(MANIFEST_PATTERN),
        key=lambda path: path.name,
        reverse=True,
    )
    entries: dict[str, dict[str, Any]] = {}
    for manifest in manifests:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        if data.get("schema") != "EFHC_SCREENSHOTS_COMPANION_MANIFEST_V1":
            continue
        for row in data.get("files", []):
            rel = str(row.get("path", "")).strip()
            if rel and rel not in entries:
                entries[rel] = row
    return entries


def assert_screenshot_evidence(
    relative_path: str,
    *,
    expected_bytes: int | None = None,
    minimum_bytes: int = 10_000,
) -> None:
    """Validate a screenshot in-tree or through the companion manifest."""
    path = ROOT / relative_path
    if path.is_file():
        size = path.stat().st_size
        assert size >= minimum_bytes, relative_path
        if expected_bytes is not None:
            assert size == expected_bytes, relative_path
        manifest = _manifest_entries().get(relative_path)
        if manifest:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            assert digest == manifest["sha256"], relative_path
        return

    manifest = _manifest_entries().get(relative_path)
    assert manifest is not None, relative_path
    size = int(manifest["size_bytes"])
    assert size >= minimum_bytes, relative_path
    if expected_bytes is not None:
        assert size == expected_bytes, relative_path
    digest = str(manifest["sha256"])
    assert len(digest) == 64
    int(digest, 16)


def screenshot_names(prefix: str) -> set[str]:
    normalized = prefix.rstrip("/") + "/"
    names = {
        path.name
        for path in (ROOT / normalized).glob("*.png")
        if path.is_file()
    }
    names.update(
        Path(rel).name
        for rel in _manifest_entries()
        if rel.startswith(normalized) and rel.endswith(".png")
    )
    return names
