"""Контракт production-состава release archive."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    """Прочитать исходный файл относительно корня проекта."""

    return (ROOT / path).read_text(encoding="utf-8")


def test_release_builder_исключает_всё_дерево_tests() -> None:
    builder = read("ops/release/build_release_archive.py")
    gate = read("ops/release/provider_portability_gate.py")
    assert '"tests",' in builder
    assert "CI_PROFILE_FILES" not in builder
    assert "test_release_archive_contract.py" not in builder
    assert "_release_purity_checks" in gate
    assert "RELEASE_TEST_CONTENT_FORBIDDEN" in gate


def test_release_builder_сохраняет_production_документы() -> None:
    builder = read("ops/release/build_release_archive.py")
    for name in (
        "INSTALL.md",
        "DEPLOY.md",
        "UPDATE.md",
        "UPDATE_AND_ROLLBACK.md",
        "BACKUP_RESTORE.md",
        "DOMAIN_CHANGE.md",
        "MIGRATION_TO_ANOTHER_VPS.md",
        "TROUBLESHOOTING.md",
        "UPDATE_POLICY.json",
        "release-manifest.json",
        "RELEASE_METADATA.json",
        "SHA256SUMS",
    ):
        assert name in builder


def test_release_builder_исключает_secrets_и_test_data() -> None:
    builder = read("ops/release/build_release_archive.py")
    for marker in (
        '".env"',
        '"node_modules"',
        '".pytest_cache"',
        '".mypy_cache"',
        '".ruff_cache"',
        '".log"',
        '".zip"',
    ):
        assert marker in builder


def test_release_packaging_не_перегенерирует_application_assets() -> None:
    builder = read("ops/release/build_release_archive.py")
    verifier = read("ops/release/prepare_frontend_release_assets.py")
    assert "verify_assets(ROOT, version)" in builder
    assert "prepare_assets(ROOT, version)" not in builder
    assert "generate_faq_catalogs_from_ssot.py" not in verifier
    assert "generate-pwa-build.mjs" not in verifier
    assert "subprocess.run" not in verifier
    assert ".write_text(" not in verifier
    assert "DUPLICATE_CONTROL_ONLY_NO_RUNTIME_WRITE" in verifier

def test_release_archive_name_без_описательного_суффикса() -> None:
    builder = read("ops/release/build_release_archive.py")
    extractor = read("scripts/release/safe_extract_release.py")
    updater = read("scripts/release/update.sh")
    assert 'f"EFHC_Bot_{_archive_version_token(version)}.zip"' in builder
    assert '_RELEASE.zip' not in builder
    assert 'return f"EFHC_Bot_{archive_token(version)}.zip"' in extractor
    assert '_RELEASE.zip' not in extractor
    assert 'r"EFHC_Bot_(v\\d+_\\d{2})\\.zip"' in updater
    assert '_RELEASE\\.zip' not in updater

