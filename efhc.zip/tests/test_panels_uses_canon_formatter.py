from __future__ import annotations

from pathlib import Path


def test_panels_uses_canon_formatter() -> None:
    p = Path("frontend/src/pages/panels.tsx")
    src = p.read_text(encoding="utf-8")

    assert "../lib/format" in src, "Panels must import the canon formatter module."
    assert "format8" in src, "Panels must use the 8-decimal DOWN formatter for SSOT numbers."

    # Basic safety: page should not crash if snapshot fields are
    # missing.
    # We expect optional chaining on snapshot access.
    assert "props.snap?." in src, "Panels should safely access snapshot via optional chaining."
