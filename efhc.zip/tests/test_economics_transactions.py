"""Economic invariants (Postgres-only).

Canon:
- spend purchases: BONUS then MAIN (atomic + idempotent)
- withdraw: only MAIN (BONUS never used)
"""

from __future__ import annotations

from decimal import Decimal

import pytest
from sqlalchemy import text


@pytest.mark.asyncio
async def test_purchase_bonus_then__main__atomic_idempotent(
    db_session,
) -> None:
    from app.services.transactions_service import (
        spend_user_to_bank_bonus_then_main,
    )

    tg_id = 101
    await db_session.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, created_at, updated_at",
                    ") VALUES (",
                    "  :tg, NULL, FALSE, TRUE,",
                    "  :mb, :bb,",
                    "  0, now(), now()",
                    ")",
                    "ON CONFLICT (tg_id) DO UPDATE SET",
                    "  main_balance=excluded.main_balance,",
                    "  bonus_balance=excluded.bonus_balance,",
                    "  updated_at=now()",
                ]
            )
        ),
        {"tg": tg_id, "mb": "10", "bb": "5"},
    )
    await db_session.commit()

    idk = "t_purchase_split_1"
    tx = await spend_user_to_bank_bonus_then_main(
        db_session,
        tg_id=tg_id,
        amount=Decimal("12"),
        reason="test_purchase",
        idempotency_key=idk,
        meta={"test": True},
    )
    assert tx.ok is True

    row = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id=:tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("3")
    assert Decimal(str(row[1])) == Decimal("0")

    bank_row = (
        await db_session.execute(
            text(
                "SELECT balance FROM efhc_core.bank_balance "
                "WHERE key = 'EFHC_MAIN'"
            )
        )
    ).first()
    assert bank_row is not None
    assert Decimal(str(bank_row[0])) == Decimal("12")

    logs = (
        await db_session.execute(
            text(
                "SELECT idempotency_key, amount "
                "FROM efhc_core.efhc_transfers_log "
                "WHERE idempotency_key IN (:b, :m) "
                "ORDER BY idempotency_key"
            ),
            {"b": f"{idk}:bonus", "m": f"{idk}:main"},
        )
    ).fetchall()
    assert len(logs) == 2

    tx2 = await spend_user_to_bank_bonus_then_main(
        db_session,
        tg_id=tg_id,
        amount=Decimal("12"),
        reason="test_purchase",
        idempotency_key=idk,
        meta={"test": True},
    )
    assert tx2.ok is True

    row2 = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id=:tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row2 is not None
    assert Decimal(str(row2[0])) == Decimal("3")
    assert Decimal(str(row2[1])) == Decimal("0")


@pytest.mark.asyncio
async def test_withdraw_uses_only_main(db_session) -> None:
    from app.services.transactions_service import debit_user_to_bank

    tg_id = 202
    await db_session.execute(
        text(
            "\n".join(
                [
                    "INSERT INTO efhc_core.users (",
                    "  tg_id, username, is_vip, is_active,",
                    "  main_balance, bonus_balance,",
                    "  total_generated_kwh, created_at, updated_at",
                    ") VALUES (",
                    "  :tg, NULL, FALSE, TRUE,",
                    "  :mb, :bb,",
                    "  0, now(), now()",
                    ")",
                    "ON CONFLICT (tg_id) DO UPDATE SET",
                    "  main_balance=excluded.main_balance,",
                    "  bonus_balance=excluded.bonus_balance,",
                    "  updated_at=now()",
                ]
            )
        ),
        {"tg": tg_id, "mb": "0", "bb": "10"},
    )
    await db_session.commit()

    with pytest.raises(ValueError):
        await debit_user_to_bank(
            db_session,
            tg_id=tg_id,
            amount=Decimal("1"),
            reason="withdraw_hold",
            idempotency_key="t_w_only_main",
        )

    row = (
        await db_session.execute(
            text(
                "SELECT main_balance, bonus_balance "
                "FROM efhc_core.users WHERE tg_id=:tg"
            ),
            {"tg": tg_id},
        )
    ).first()
    assert row is not None
    assert Decimal(str(row[0])) == Decimal("0")
    assert Decimal(str(row[1])) == Decimal("10")
