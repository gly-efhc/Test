from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def _run(cmd: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )


def test_cleanup_artifacts_detects_transient_junk(tmp_path: Path):
    repo = tmp_path / "repo"
    (repo / "backend").mkdir(parents=True)
    (repo / "frontend").mkdir(parents=True)
    (repo / "backend" / "__pycache__").mkdir()
    (repo / ".ruff_cache").mkdir()
    (repo / ".local_artifacts" / "logs").mkdir(parents=True)
    (repo / "artifacts" / "docs").mkdir(parents=True)
    (repo / "backend" / "__pycache__" / "x.pyc").write_bytes(b"x")
    (repo / ".ruff_cache" / "state").write_text("1")
    (repo / ".local_artifacts" / "logs" / "app.log").write_text("log")
    (repo / "artifacts" / "docs" / "keep.md").write_text("keep")
    target = REPO_ROOT / "ops" / "cleanup_artifacts.py"
    out = _run(
        [sys.executable, str(target), "--root", str(repo), "--dry-run"],
        cwd=REPO_ROOT,
    )
    assert out.returncode == 0, out.stdout
    stdout = out.stdout
    assert "__pycache__" in stdout
    assert ".ruff_cache" in stdout
    assert ".local_artifacts" in stdout
    assert "artifacts/docs/keep.md" not in stdout


def test_build_script_uses_cleanup_and_staging():
    text = (REPO_ROOT / "ops" / "build_efhc_zip.sh").read_text()
    assert "python ops/cleanup_artifacts.py" in text
    assert 'rm -f "${ZIP_OUT}"' in text
    assert '--exclude "${ZIP_OUT}"' in text
    assert 'rsync -a ./ "${STAGE_DIR}/"' in text
    assert "rm -rf artifacts" not in text
