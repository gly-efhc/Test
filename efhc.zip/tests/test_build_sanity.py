import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def _run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(REPO_ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )


def test_canon_guard_passes():
    tmp_bad = REPO_ROOT / "docs" / "_tmp_bad_canon_test_only.md"
    if tmp_bad.exists():
        tmp_bad.unlink()
    p = _run([sys.executable, "ops/canon_guard.py"])
    assert p.returncode == 0, p.stdout


def test_backend_importable():
    p = _run(
        [sys.executable, "-c", "import backend; import backend.app"]
    )
    assert p.returncode == 0, p.stdout


def test_compileall_backend_ops():
    p = _run(
        [sys.executable, "-m", "compileall", "backend", "ops", "-q"]
    )
    assert p.returncode == 0, p.stdout
