"""Test configuration (Postgres-only, canon).

- Enforces no bytecode files during tests
- Provides Postgres-only async SQLAlchemy engine/session fixtures
- Ensures schemas are canon: efhc_core / efhc_admin (no main)
- Prevents env cross-test pollution (DB_SCHEMA_CORE etc.)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import AsyncIterator, Iterator

import pytest

import asyncio
import subprocess


@pytest.fixture(scope="session")
def event_loop():
    """One asyncio loop for the whole test session.

    Fixes: 'Future attached to a different loop' when session-scoped async fixtures
    reuse engines/connections.
    """
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()

os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True


def _ensure_repo_root_on_syspath() -> None:
    # tests/ -> repo root
    root = Path(__file__).resolve().parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

_ensure_repo_root_on_syspath()


def _to_async_sqlalchemy_url(url: str) -> str:
    # prefer asyncpg for AsyncEngine
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgresql+psycopg://"):
        return "postgresql+asyncpg://" + url[len("postgresql+psycopg://"):]
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://"):]
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://"):]
    return url


def _get_async_db_url() -> str:
    url = (
        os.getenv("ASYNC_DATABASE_URL")
        or os.getenv("DATABASE_URL")
        or os.getenv("SYNC_DATABASE_URL")
    )
    if not url:
        pytest.skip(
            "DATABASE_URL/ASYNC_DATABASE_URL is required for CI",
            allow_module_level=True,
        )
    if url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return _to_async_sqlalchemy_url(url)

def get_async_db_url() -> str:
    """Backward-compatible helper for tests that need async SQLAlchemy URL."""
    return _get_async_db_url()


@pytest.fixture(autouse=True)
def _restore_env_and_syspath() -> Iterator[None]:
    # prevent cross-test env pollution (main schema etc.)
    _ensure_repo_root_on_syspath()
    saved = dict(os.environ)
    # enforce canon schemas
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    os.environ["DB_SCHEMA_ADMIN"] = "efhc_admin"
    # keep ADMIN bank id stable for tests that touch it
    os.environ.setdefault("ADMIN_BANK_TG_ID", "900100")
    try:
        yield
    finally:
        os.environ.clear()
        os.environ.update(saved)


@pytest.fixture(scope="session")
def schema_core() -> str:
    return "efhc_core"


@pytest.fixture(scope="session")
def schema_admin() -> str:
    return "efhc_admin"


@pytest.fixture(scope="session")
def async_db_url() -> str:
    return _get_async_db_url()


@pytest.fixture(scope="session")
def async_engine(async_db_url: str):
    pytest.importorskip("sqlalchemy")
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(
        async_db_url,
        future=True,
    )
    return engine


@pytest.fixture(scope="session")
async def schemas_ready(
    async_engine,
    schema_core: str,
    schema_admin: str,
) -> None:
    # Create canon schemas once per session.
    async with async_engine.begin() as conn:
        await _ensure_schema(conn, schema_admin)
        await _ensure_schema(conn, schema_core)





@pytest.fixture(scope="session")
async def db_migrated(
    db_migrated,
) -> None:
    # Make DB tests self-contained: ensure alembic upgraded to head.
    repo = Path(__file__).resolve().parents[1]
    backend_dir = repo / "backend"
    cmd = ["alembic", "-c", "alembic.ini", "upgrade", "head"]

    def _run() -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            cmd,
            cwd=str(backend_dir),
            capture_output=True,
            text=True,
        )

    p = await asyncio.to_thread(_run)
    if p.returncode != 0:
        out = (p.stdout or "") + (p.stderr or "")
        msg = "alembic upgrade head failed:\n" + out
        raise RuntimeError(msg)


async def _ensure_schema(conn, schema: str) -> None:
    from sqlalchemy import text
    # schema name is internal (from fixtures), keep it simple.
    await conn.execute(
        text(
            "CREATE SCHEMA IF NOT EXISTS "
            + schema
        )
    )
async def _truncate_schema_tables(conn, schema: str) -> None:
    # truncate all tables in schema except alembic_version
    from sqlalchemy import text
    q = text(
        """
        SELECT tablename
        FROM pg_catalog.pg_tables
        WHERE schemaname = :schema
          AND tablename <> 'alembic_version'
        """
    )
    res = await conn.execute(q, {"schema": schema})
    rows = res.fetchall()
    if not rows:
        return
    tbls = ", ".join([f'{schema}."{r[0]}"' for r in rows])
    await conn.execute(text(f"TRUNCATE TABLE {tbls} RESTART IDENTITY CASCADE"))


@pytest.fixture
async def db_clean(
    async_engine,
    schema_core: str,
    schema_admin: str,
    db_migrated,
) -> AsyncIterator[None]:
    # Clean tables per test (schemas created once per session).
    async with async_engine.begin() as conn:
        await _truncate_schema_tables(conn, schema_admin)
        await _truncate_schema_tables(conn, schema_core)
    yield
    async with async_engine.begin() as conn:
        await _truncate_schema_tables(conn, schema_admin)
        await _truncate_schema_tables(conn, schema_core)


@pytest.fixture
async def db_session(async_engine, db_clean):
    from sqlalchemy.ext.asyncio import AsyncSession
    from sqlalchemy.orm import sessionmaker

    Session = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    async with Session() as s:
        yield s