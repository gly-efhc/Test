"""Pytest bootstrap for EFHC Bot (CANON).

Goal: make project root importable when CI runs `pytest` from `extracted/`.
This avoids fragile dependence on external PYTHONPATH.
"""

from __future__ import annotations

import sys
from pathlib import Path
import os

# CANON: only efhc_core + efhc_admin. Force schema env for test runs to avoid legacy 'main' leakage.
os.environ.setdefault("DB_SCHEMA_CORE", "efhc_core")
os.environ.setdefault("DB_SCHEMA_ADMIN", "efhc_admin")


def _ensure_project_root_on_syspath() -> None:
    # tests/ is inside project root (flat zip layout).
    project_root = Path(__file__).resolve().parents[1]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))


_ensure_project_root_on_syspath()


import pytest

# These helpers are used to rewrite legacy sqlite tests to Postgres-only canon.

def get_postgres_schema_default() -> str:
    # Prefer settings if available; fallback to EFHC default.
    try:
        from backend.app.core.config_core import get_settings
        return getattr(get_settings(), "DB_SCHEMA_CORE", "efhc_core")
    except Exception:
        return os.getenv("DB_SCHEMA_CORE", "efhc_core") or "efhc_core"


def get_async_db_url() -> str:
    """Return an async SQLAlchemy URL for Postgres (asyncpg)."""
    url = os.getenv("ASYNC_DATABASE_URL") or os.getenv("DATABASE_URL") or ""
    if not url:
        pytest.skip("DATABASE_URL/ASYNC_DATABASE_URL is required for Postgres-only CI", allow_module_level=True)

    low = url.lower()
    if low.startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")

    # Normalize to asyncpg for create_async_engine
    if low.startswith("postgresql+asyncpg://") or low.startswith("postgres+asyncpg://"):
        return url

    # If SQLAlchemy sync dialect is provided (psycopg), convert for async tests.
    if low.startswith("postgresql+psycopg://"):
        return "postgresql+asyncpg://" + url[len("postgresql+psycopg://"):]
    if low.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://"):]
    if low.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://"):]
    return url


@pytest.fixture
def async_engine():
    """AsyncEngine bound to CI Postgres."""
    sqlalchemy = pytest.importorskip("sqlalchemy")
    from sqlalchemy.ext.asyncio import create_async_engine
    engine = create_async_engine(get_async_db_url(), future=True)
    try:
        yield engine
    finally:
        try:
            import asyncio
            asyncio.get_event_loop().run_until_complete(engine.dispose())
        except Exception:
            # best-effort disposal
            pass


async def truncate_schema_all_tables(engine, schema: str) -> None:
    """TRUNCATE all tables in schema except alembic_version."""
    sqlalchemy = pytest.importorskip("sqlalchemy")
    from sqlalchemy import text
    async with engine.begin() as conn:
        rows = await conn.execute(
            text(
                """
                SELECT tablename
                FROM pg_tables
                WHERE schemaname = :schema
                """
            ),
            {"schema": schema},
        )
        tables = [r[0] for r in rows.fetchall() if r and r[0] != "alembic_version"]
        if not tables:
            return
        fq = ", ".join([f"{schema}.{t}" for t in tables])
        await conn.execute(text(f"TRUNCATE TABLE {fq} RESTART IDENTITY CASCADE"))
