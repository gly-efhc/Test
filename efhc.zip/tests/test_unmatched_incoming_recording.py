from __future__ import annotations

from decimal import Decimal

import pytest


@pytest.mark.asyncio
async def test_unmatched_incoming_is_idempotent_by_tx_hash(
    db_session,
) -> None:
    import app.services.watcher_service as ws

    await ws._record_unmatched_incoming(
        db_session,
        tx_hash="tx_u1",
        asset="EFHC",
        amount_asset=Decimal("1.23000000"),
        from_address="EQ_FROM",
        to_address="EQ_TO",
        memo="",
        utime=1,
        reason="unmatched_payload",
    )
    await ws._record_unmatched_incoming(
        db_session,
        tx_hash="tx_u1",
        asset="EFHC",
        amount_asset=Decimal("1.23000000"),
        from_address="EQ_FROM",
        to_address="EQ_TO",
        memo="",
        utime=1,
        reason="unmatched_payload",
    )
    await db_session.commit()

    from sqlalchemy import text

    r = await db_session.execute(
        text("SELECT COUNT(1) FROM efhc_core.unmatched_incoming"),
    )
    assert int(r.scalar() or 0) == 1
