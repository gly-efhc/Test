from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timezone
from decimal import Decimal

import pytest



def __get_async_db_url() -> str:
    url = os.getenv("ASYNC_DATABASE_URL") or os.getenv("DATABASE_URL") or os.getenv("SYNC_DATABASE_URL")
    if not url:
        pytest.skip("DATABASE_URL/ASYNC_DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    if url.lower().startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to asyncpg SQLAlchemy URL
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://"):]
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://"):]
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgresql+psycopg://"):
        return "postgresql+asyncpg://" + url[len("postgresql+psycopg://"):]
    return url

pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_unmatched(db_url: str) -> None:
    engine = create_async_engine(
        db_url,
        future=True,

    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS efhc_core.unmatched_incoming (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tx_hash TEXT NOT NULL UNIQUE,
                    asset TEXT NOT NULL,
                    amount_asset_d8 TEXT NOT NULL,
                    from_address TEXT,
                    to_address TEXT,
                    memo TEXT,
                    utime INTEGER,
                    reason TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
        )

    await engine.dispose()


def _reload_for_sqlite() -> object:
    os.environ["DB_SCHEMA_CORE"] = "efhc_core"
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()
    import backend.app.services.watcher_service as ws

    return importlib.reload(ws)


@pytest.mark.asyncio
async def test_unmatched_incoming_is_idempotent_by_tx_hash() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_unmatched(db_url)
        ws = _reload_for_sqlite()

        engine = create_async_engine(
            db_url,
            future=True,

        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with Session() as db:
            await ws._record_unmatched_incoming(
                db,
                tx_hash="tx_u1",
                asset="TON",
                amount_asset=Decimal("1.23000000"),
                from_address="EQ_FROM",
                to_address="EQ_TO",
                memo="BAD",
                utime=1,
                reason="unmatched_payload",
            )
            await ws._record_unmatched_incoming(
                db,
                tx_hash="tx_u1",
                asset="TON",
                amount_asset=Decimal("1.23000000"),
                from_address="EQ_FROM",
                to_address="EQ_TO",
                memo="BAD",
                utime=1,
                reason="unmatched_payload",
            )
            await db.commit()

            r = await db.execute(
                text("SELECT COUNT(1) FROM efhc_core.unmatched_incoming")
            )
            assert int(r.scalar() or 0) == 1

        await engine.dispose()


@pytest.mark.asyncio
async def test_process_incoming_tx_unmatched_does_not_credit() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_unmatched(db_url)
        ws = _reload_for_sqlite()

        # Не даём тесту зависеть от ton_inbox_logs и других таблиц.
        async def _no_log(*_a, **_k) -> None:
            return None

        async def _false(*_a, **_k) -> bool:
            return False

        async def _none(*_a, **_k):
            return None

        ws._ton_log_upsert = _no_log  # type: ignore[attr-defined]
        ws._ton_log_exists_final = _false  # type: ignore[attr-defined]
        ws._find_user_by_wallet = _none  # type: ignore[attr-defined]

        called = {"credit": 0}

        async def _credit(*_a, **_k) -> None:
            called["credit"] += 1

        ws.credit_user_from_bank = _credit  # type: ignore[attr-defined]
        ws.MAIN_TON_WALLET = ""  # allow any to_address

        engine = create_async_engine(
            db_url,
            future=True,

        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        tx = ws.IncomingTx()
        tx.tx_hash = "tx_bad_1"
        tx.from_address = "EQ_FROM"
        tx.to_address = "EQ_TO"
        tx.amount = Decimal("1.00000000")
        tx.memo = "NO_PAYLOAD"
        tx.utime = 1

        async with Session() as db:
            st = await ws.process_incoming_tx(db, tx)
            await db.commit()

            assert st == ws.STATUS_PENDING_MANUAL
            assert called["credit"] == 0

            r = await db.execute(
                text(
                    "SELECT reason FROM efhc_core.unmatched_incoming "
                    "WHERE tx_hash='tx_bad_1'"
                )
            )
            assert str(r.scalar() or "") == "unmatched_payload"

        await engine.dispose()
