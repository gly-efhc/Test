from __future__ import annotations

import asyncio
import json
import os
from decimal import Decimal

import pytest

pytestmark = pytest.mark.asyncio


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text  # noqa: E402
from sqlalchemy.ext.asyncio import (  # noqa: E402
    AsyncSession,
    create_async_engine,
)
from sqlalchemy.orm import sessionmaker  # noqa: E402

from tests.concurrency_testkit import (  # noqa: E402
    ensure_core_user,
    get_async_database_url,
    reload_tx_and_withdraw_services_for_postgres,
    reset_core_tables,
)


@pytest.mark.asyncio
async def test_concurrency_exchange_withdraw() -> None:
    ts, ws = reload_tx_and_withdraw_services_for_postgres()
    db_url = get_async_database_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(ts, "SCHEMA", "efhc_core")
    await reset_core_tables(engine, schema)

    Session = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )

    user_tg_id = 100002

    async with Session() as s:
        await ensure_core_user(
            s,
            tg_id=user_tg_id,
            username="user",
            ton_wallet="w",
        )
        await s.execute(
            text(
                "UPDATE efhc_core.users "
                "SET total_generated_kwh=:tk, "
                "    exchanged_kwh_total='0.00000000' "
                "WHERE tg_id=:tg"
            ),
            {"tk": "50.00000000", "tg": user_tg_id},
        )
        await s.commit()

    async def _do_exchange() -> object:
        async with Session() as s:
            return await ts.exchange__all__available_kwh_to_main(
                s,
                tg_id=user_tg_id,
                idempotency_key="k_ex_with_wd",
                reason="test_exchange_all",
            )

    async def _do_withdraw() -> object:
        async with Session() as s:
            return await ws.request_withdraw(
                s,
                tg_id=user_tg_id,
                amount=Decimal("10.00000000"),
                idempotency_key="k_wd_1",
            )

    out = await asyncio.gather(
        _do_exchange(),
        _do_withdraw(),
        return_exceptions=True,
    )
    assert len(out) == 2

    async with Session() as s:
        row = (
            await s.execute(
                text(f"""
                    SELECT
                      COALESCE(exchanged_kwh_total, 0),
                      COALESCE(main_balance, 0),
                      COALESCE(available_kwh, 0)
                    FROM {schema}.users
                    WHERE tg_id = :tg
                    """),
                {"tg": user_tg_id},
            )
        ).fetchone()

        ex_total = Decimal(str(row[0]))
        main_bal = Decimal(str(row[1]))
        avail = Decimal(str(row[2]))

        assert ex_total == Decimal("50.00000000")
        assert avail == Decimal("0.00000000")
        assert main_bal in {
            Decimal("40.00000000"),
            Decimal("50.00000000"),
        }
        assert main_bal >= Decimal("0")
        bank = (
            await s.execute(
                text(
                    "SELECT balance FROM efhc_core.bank_balance "
                    "WHERE key = 'EFHC_MAIN'"
                )
            )
        ).fetchone()
        assert bank is not None
        bank_bal = Decimal(str(bank[0]))
        assert bank_bal in {
            Decimal("-40.00000000"),
            Decimal("-50.00000000"),
        }

        logs = (
            await s.execute(
                text(f"""
                    SELECT meta
                    FROM {schema}.efhc_transfers_log
                    WHERE tg_id = :tg
                    ORDER BY id
                    """),
                {"tg": user_tg_id},
            )
        ).fetchall()

    seen_exchange = False
    seen_withdraw = False
    for (raw,) in logs:
        if not raw:
            continue
        try:
            payload = (
                raw if isinstance(raw, dict) else json.loads(str(raw))
            )
        except Exception:
            continue

        if payload.get("op_type") == "EXCHANGE_ALL":
            after = payload.get("after") or {}
            assert "invariant_ok" in after
            seen_exchange = True

        if payload.get("op_type") == "WITHDRAW":
            before = payload.get("before") or {}
            after = payload.get("after") or {}
            assert "main_balance_before" in before
            assert "withdrawable__main__before" in before
            assert "amount" in before
            assert "min_amount" in before
            assert "main_balance_after" in after
            assert "withdrawable__main__after" in after
            assert "invariant_ok" in after
            seen_withdraw = True

    assert seen_exchange
    assert seen_withdraw

    await engine.dispose()
