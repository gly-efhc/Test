import io
import tokenize
from pathlib import Path


def _s(parts: list[str]) -> str:
    return "".join(parts)


# Build banned identifiers without embedding them verbatim in this file
# Canonical names ``user_id`` and ``tg_id`` are intentionally allowed.
# Only ambiguous aliases and non-canonical provider spellings are banned.
BANNED_EXACT = {
    _s(["t", "g", "i", "d"]),
    _s(["t", "g", "I", "d"]),
    _s(["T", "G", "I", "D"]),
    _s(["u", "_", "id"]),
    _s(["u", "ser", "I", "d"]),
    _s(["u", "ser", "id"]),
    _s(["u", "id"]),
    _s(["t", "elegram", "_", "id"]),
    _s(["t", "elegram", "I", "d"]),
    _s(["t", "elegram", "id"]),
    _s(["t", "elegram", "_", "user", "_", "id"]),
}

BANNED_PARTS = {
    _s(["lot", "tery"]),
    _s(["ra", "ffle"]),
    _s(["dr", "aw"]),
    _s(["dr", "aws"]),
}

APPROVED_TELEGRAM_ALIAS_FILES = {
    "backend/app/identity/compatibility_registry.py",
    "backend/app/models/user_models.py",
    "backend/app/identity/legacy_alias.py",
}


SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}


def _iter_py_files() -> list[Path]:
    repo_root = Path(__file__).resolve().parents[1]
    backend_root = repo_root / "backend"

    py_files: list[Path] = []
    for p in backend_root.rglob("*.py"):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        # Exclude migrations: they may contain legacy DB column names
        # and must not block the build.
        # be used as a source of truth for runtime identifiers.
        if "migrations" in p.parts:
            continue
        py_files.append(p)

    return py_files


def __name__has_banned_parts(name: str) -> bool:
    parts = name.split("_")
    return any(part in BANNED_PARTS for part in parts)


def test_no_banned_identifiers_in_code_names() -> None:
    offenders: list[str] = []
    repo_root = Path(__file__).resolve().parents[1]
    for path in _iter_py_files():
        relative = path.relative_to(repo_root).as_posix()
        approved_alias_file = (
            relative in APPROVED_TELEGRAM_ALIAS_FILES
        )
        src = path.read_text(encoding="utf-8")
        try:
            tokens = tokenize.generate_tokens(io.StringIO(src).readline)
        except tokenize.TokenError:
            continue

        for tok in tokens:
            if tok.type != tokenize.NAME:
                continue

            name = tok.string
            if name in BANNED_EXACT:
                if approved_alias_file and name == "telegram_id":
                    continue
                offenders.append(f"{path}:{tok.start[0]}:{name}")
                continue

            if name == "withdraw":
                continue  # protect against false positives

            if __name__has_banned_parts(name):
                offenders.append(f"{path}:{tok.start[0]}:{name}")

            # ``global_id`` is canonical; provider code uses ``tg_id``.
            # ``telegram_id`` is allowed only in the registered alias.
            parts = name.split("_")
            for i in range(len(parts) - 1):
                left = parts[i] == "telegram"
                right = parts[i + 1] == "id"
                if left and right:
                    if approved_alias_file and name == "telegram_id":
                        continue
                    offenders.append(f"{path}:{tok.start[0]}:{name}")

    assert not offenders, "Banned identifiers found:\n" + "\n".join(
        offenders
    )


def test_no_banned_identifiers_in_source_text_including_comments() -> (
    None
):
    banned_text = [
        _s(["t", "g", "i", "d"]),
        _s(["t", "g", "I", "d"]),
        _s(["T", "G", "I", "D"]),
        _s(["u", "_", "id"]),
        _s(["t", "elegram", "_", "id"]),
        _s(["u", "ser", "I", "d"]),
        _s(["t", "elegram", "I", "d"]),
        _s(["u", "ser", "id"]),
        _s(["t", "elegram", "id"]),
        _s(["t", "elegram", "_", "user", "_", "id"]),
    ]

    skip_files = {Path(__file__).resolve()}

    offenders: list[str] = []
    repo_root = Path(__file__).resolve().parents[1]
    for path in _iter_py_files():
        if path.resolve() in skip_files:
            continue

        relative = path.relative_to(repo_root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        for needle in banned_text:
            if (
                relative in APPROVED_TELEGRAM_ALIAS_FILES
                and needle == "telegram_id"
            ):
                continue
            if needle in text:
                offenders.append(f"{path}:{needle}")

    assert not offenders, (
        "Banned identifiers found in source text"
        " (including comments/strings):\n" + "\n".join(offenders)
    )
