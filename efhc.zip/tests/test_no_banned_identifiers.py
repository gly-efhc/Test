import io
import tokenize
from pathlib import Path


def _s(parts: list[str]) -> str:
    return "".join(parts)


# ARCHITECTURE_CANON identity guard.
# Canonical names ``user_id`` and ``global_id`` are intentionally allowed where their
# profile contracts permit them. This guard checks only non-canonical identity/provider aliases;
# gambling semantics are enforced by the separate semantic contour guard.
NON_CANONICAL_IDENTITY_EXACT = {
    _s(["t", "g", "i", "d"]),
    _s(["t", "g", "I", "d"]),
    _s(["T", "G", "I", "D"]),
    _s(["u", "_", "id"]),
    _s(["u", "ser", "I", "d"]),
    _s(["u", "ser", "id"]),
    _s(["u", "id"]),
    _s(["t", "elegram", "_", "id"]),
    _s(["t", "elegram", "I", "d"]),
    _s(["t", "elegram", "id"]),
    _s(["t", "elegram", "_", "user", "_", "id"]),
}


APPROVED_PROVIDER_WIRE_ALIASES = {
    "backend/app/routes/ads_routes.py": {"userId"},
    "backend/app/integrations/ads/richads.py": {"telegram_id"},
    "backend/app/integrations/ads/adsgram_bot.py": {"tgid"},
}


SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}


def _iter_py_files() -> list[Path]:
    repo_root = Path(__file__).resolve().parents[1]
    backend_root = repo_root / "backend"

    py_files: list[Path] = []
    for p in backend_root.rglob("*.py"):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        # Exclude migrations: they may contain legacy DB column names
        # and must not block the build.
        # be used as a source of truth for runtime identifiers.
        if "migrations" in p.parts:
            continue
        py_files.append(p)

    return py_files




def test_identity_code_names_follow_architecture_canon() -> None:
    offenders: list[str] = []
    for path in _iter_py_files():
        src = path.read_text(encoding="utf-8")
        try:
            tokens = tokenize.generate_tokens(io.StringIO(src).readline)
        except tokenize.TokenError:
            continue

        for tok in tokens:
            if tok.type != tokenize.NAME:
                continue

            name = tok.string
            if name in NON_CANONICAL_IDENTITY_EXACT:
                offenders.append(f"{path}:{tok.start[0]}:{name}")
                continue


            # ``global_id`` is canonical; provider code uses ``global_id``.
            parts = name.split("_")
            for i in range(len(parts) - 1):
                left = parts[i] == "telegram"
                right = parts[i + 1] == "id"
                if left and right:
                    offenders.append(f"{path}:{tok.start[0]}:{name}")

    assert not offenders, "Non-canonical identity identifiers found:\n" + "\n".join(
        offenders
    )


def test_identity_aliases_absent_from_runtime_source_text() -> (
    None
):
    noncanonical_text = [
        _s(["t", "g", "i", "d"]),
        _s(["t", "g", "I", "d"]),
        _s(["T", "G", "I", "D"]),
        _s(["u", "_", "id"]),
        _s(["t", "elegram", "_", "id"]),
        _s(["u", "ser", "I", "d"]),
        _s(["t", "elegram", "I", "d"]),
        _s(["u", "ser", "id"]),
        _s(["t", "elegram", "id"]),
        _s(["t", "elegram", "_", "user", "_", "id"]),
    ]

    skip_files = {Path(__file__).resolve()}

    offenders: list[str] = []
    for path in _iter_py_files():
        if path.resolve() in skip_files:
            continue

        text = path.read_text(encoding="utf-8", errors="replace")
        relative = path.relative_to(Path(__file__).resolve().parents[1]).as_posix()
        allowed = APPROVED_PROVIDER_WIRE_ALIASES.get(relative, set())
        for needle in noncanonical_text:
            if needle in text and needle not in allowed:
                offenders.append(f"{path}:{needle}")

    assert not offenders, (
        "Non-canonical identity aliases found in runtime source text"
        " (including comments/strings):\n" + "\n".join(offenders)
    )
