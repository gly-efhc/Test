from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest
from app.identity.idempotency_readthrough import (
    choose_idempotency_key_with_history,
)

pytestmark = pytest.mark.asyncio


class _Result:
    def __init__(self, key: str | None) -> None:
        self._key = key

    def first(self) -> Any:
        if self._key is None:
            return None
        return SimpleNamespace(idempotency_key=self._key)


class _Session:
    def __init__(self, existing: str | None = None) -> None:
        self.existing = existing

    async def execute(self, _statement: Any, _params: Any) -> _Result:
        return _Result(self.existing)


async def test_existing_legacy_key_имеет_приоритет_для_повтора() -> None:
    result = await choose_idempotency_key_with_history(
        _Session("REF_ACT_UNIT:123"),  # type: ignore[arg-type]
        canonical_key="REF_ACT_UNIT:G0000000456",
        legacy_key="REF_ACT_UNIT:123",
    )
    assert result.selected == "REF_ACT_UNIT:123"
    assert result.matched_existing is True


async def test_new_operation_всегда_выбирает_global_id_ключ() -> None:
    result = await choose_idempotency_key_with_history(
        _Session(),  # type: ignore[arg-type]
        canonical_key="REF_LVL:G0000000456:1",
        legacy_key="REF_LVL:123:1",
    )
    assert result.selected == "REF_LVL:G0000000456:1"
    assert result.matched_existing is False


async def test_new_exchange_operation_выбирает_global_id_ключ() -> None:
    result = await choose_idempotency_key_with_history(
        _Session(),  # type: ignore[arg-type]
        canonical_key="exchange:G0000000456:abc",
        legacy_key="exchange:123:abc",
    )
    assert result.selected == "exchange:G0000000456:abc"
    assert result.matched_existing is False
