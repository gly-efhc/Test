from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest
from app.identity import idempotency_compat

pytestmark = pytest.mark.asyncio


class _Result:
    def __init__(self, key: str | None) -> None:
        self._key = key

    def first(self) -> Any:
        if self._key is None:
            return None
        return SimpleNamespace(idempotency_key=self._key)


class _Session:
    def __init__(self, existing: str | None = None) -> None:
        self.existing = existing

    async def execute(self, _statement: Any, _params: Any) -> _Result:
        return _Result(self.existing)


async def test_existing_legacy_key_имеет_приоритет_для_повтора(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def _control(_db: Any) -> Any:
        return SimpleNamespace(legacy_authoritative=False)

    monkeypatch.setattr(idempotency_compat, "_load_control", _control)
    result = await idempotency_compat.choose_compatible_idempotency_key(
        _Session("REF_ACT_UNIT:123"),  # type: ignore[arg-type]
        canonical_key="REF_ACT_UNIT:G0000000456",
        legacy_key="REF_ACT_UNIT:123",
    )
    assert result.selected == "REF_ACT_UNIT:123"
    assert result.matched_existing is True


async def test_legacy_mode_сохраняет_совместимый_ключ(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def _control(_db: Any) -> Any:
        return SimpleNamespace(legacy_authoritative=True)

    monkeypatch.setattr(idempotency_compat, "_load_control", _control)
    result = await idempotency_compat.choose_compatible_idempotency_key(
        _Session(),  # type: ignore[arg-type]
        canonical_key="REF_LVL:G0000000456:1",
        legacy_key="REF_LVL:123:1",
    )
    assert result.selected == "REF_LVL:123:1"
    assert result.matched_existing is False


async def test_cutover_mode_выбирает_global_id_ключ(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def _control(_db: Any) -> Any:
        return SimpleNamespace(legacy_authoritative=False)

    monkeypatch.setattr(idempotency_compat, "_load_control", _control)
    result = await idempotency_compat.choose_compatible_idempotency_key(
        _Session(),  # type: ignore[arg-type]
        canonical_key="exchange:G0000000456:abc",
        legacy_key="exchange:123:abc",
    )
    assert result.selected == "exchange:G0000000456:abc"
    assert result.matched_existing is False
