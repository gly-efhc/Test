from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_panels_create_inserts_public_id_as_null() -> None:
    text = _read("backend/app/services/panels_service.py")
    assert "INSERT INTO" in text
    assert "public_id" in text
    assert "NULL" in text
    assert "public_id = NULL" not in text


def test_panels_public_id_format_id_8_digits() -> None:
    text = _read("backend/app/services/panels_service.py")
    assert "ID{int(panel_id):08d}" in text
    assert "ID{pid:08d}" in text


def test_panels_idempotent_replay_no_new_create_path() -> None:
    text = _read("backend/app/services/panels_service.py")
    assert "debit_result.detail == \"idempotent\"" in text
    assert "status = \"replay\"" in text
    assert "Missing created panel id" in text


def test_panels_audit_schema_version_present() -> None:
    text = _read("backend/app/services/panels_service.py")
    assert "audit_schema_version" in text
    assert "op_type\": \"PANEL_CREATE\"" in text


def test_panels_list_filter_uses_server_now_param() -> None:
    text = _read("backend/app/services/panels_service.py")
    assert "server_now_utc" in text
    assert "p.expires_at > :server_now_utc" in text
    assert "p.expires_at <= :server_now_utc" in text


def test_panels_routes_return_server_now_utc() -> None:
    text = _read("backend/app/routes/panels_routes.py")
    assert "server_now_utc" in text
    assert "utcnow()" in text
