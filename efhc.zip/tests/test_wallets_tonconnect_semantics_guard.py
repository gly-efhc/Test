from __future__ import annotations

from pathlib import Path

_DOC = Path("docs/WALLETS_TONCONNECT_SSOT.md")


def test_wallets_tonconnect_semantics_table_fixed() -> None:
    text = _DOC.read_text(encoding="utf-8")
    required = [
        "POST /deposit/efhc",
        "details.feature: `deposit`",
        "POST /shop/order-external",
        "details.feature: `shop_external`",
        "POST /withdraw/request",
        "details.feature: `withdraw`",
        "POST /lotteries/{id}/buy",
        "details.feature: `lotteries`",
        "POST /shop/purchase-efhc",
        "семантика: Shop internal",
        "details.feature: не применяется",
    ]
    missing = [s for s in required if s not in text]
    assert not missing, f"Missing in SSOT doc: {missing}"


def test_features_not_miswired_in_routes() -> None:
    shop = Path("backend/app/routes/shop_routes.py").read_text(
        encoding="utf-8",
    )
    deposit = Path("backend/app/routes/deposit_routes.py").read_text(
        encoding="utf-8",
    )
    assert "feature=\"deposit\"" not in shop
    assert "feature=\"deposit\"" in deposit
