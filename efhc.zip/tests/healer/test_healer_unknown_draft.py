from __future__ import annotations

import json
from pathlib import Path


def test_healer_pending_status_allowed() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    raw = json.loads((repo_root / "atlas.json").read_text("utf-8"))
    statuses = {card["treatment_status"] for card in raw["cards"]}
    assert statuses
