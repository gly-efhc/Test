from __future__ import annotations

import json
from pathlib import Path


def test_healer_atlas_rules() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    raw = json.loads((repo_root / "atlas.json").read_text("utf-8"))
    assert raw["cards_total"] == len(raw["cards"])
    required = {
        "heal_id",
        "name",
        "category",
        "severity",
        "zone",
        "symptom_patterns",
        "doc_checks",
        "exceptions",
        "confirmation_rule",
        "confirmation_basis",
        "card_status",
        "treatment_status",
        "medical_maturity",
        "action_priority",
        "first_seen",
        "last_seen",
        "times_seen",
        "casebook_refs",
        "forbidden_actions",
        "prevention",
    }
    allowed_card_status = {"draft", "confirmed", "deprecated"}
    allowed_treatment = {"empty", "pending", "partial", "confirmed"}
    allowed_maturity = {
        "diagnosis_only",
        "diagnosis_with_partial_treatment",
        "fully_protocolized",
    }
    allowed_priority = {"observe", "planned", "immediate"}
    for card in raw["cards"]:
        assert required.issubset(card)
        assert card["card_status"] in allowed_card_status
        assert card["treatment_status"] in allowed_treatment
        assert card["medical_maturity"] in allowed_maturity
        assert card["action_priority"] in allowed_priority
        assert card["confirmation_basis"]
        assert card["forbidden_actions"]
        assert card["prevention"]
        assert card["casebook_refs"]
        assert int(card["times_seen"]) >= 1
