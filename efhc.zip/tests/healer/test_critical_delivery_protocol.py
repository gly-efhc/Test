from __future__ import annotations

import json
from pathlib import Path

import pytest
from ops.healer.check_critical_delivery_protocol import (
    CONTROL_DOCS,
    DeliveryInputs,
    ProtocolViolation,
    validate_cycle_claims,
    validate_head_sync,
    validate_screenshot_provenance,
)


def _inputs(tmp_path: Path, *, mode: str = "inherited") -> DeliveryInputs:
    return DeliveryInputs(
        root=tmp_path,
        version="v171.55",
        cycle=1573,
        main_archive=tmp_path / "EFHC_Bot_v171_55.zip",
        screenshots_archive=tmp_path / "EFHC_Bot_v171_55_Screenshots.zip",
        manifest=tmp_path / "manifest.json",
        report=tmp_path / "report.md",
        generated_report=tmp_path / "cycle.json",
        screenshot_mode=mode,
        ui_change=False,
        heal_id="HEAL-0112",
        case_id="CASE-0121",
        receipt_out=tmp_path / "receipt.json",
    )


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def test_head_sync_fails_on_one_stale_control_document(tmp_path: Path) -> None:
    inputs = _inputs(tmp_path)
    for relative in CONTROL_DOCS:
        _write(tmp_path / relative, "v171.55 / cycle 1573 active\n")
    _write(tmp_path / "KERNEL.md", "v171.54 / cycle 1573 active\n")
    with pytest.raises(ProtocolViolation, match="HEAD sync failed"):
        validate_head_sync(inputs)


def test_synthetic_visual_proof_is_fail_closed(tmp_path: Path) -> None:
    inputs = _inputs(tmp_path)
    payload = {
        "archive_version": "v171.55",
        "cycle": 1573,
        "proof_type": "SYNTHETIC_UI_RENDER",
        "proof_method": "generated imitation",
        "fresh_cycle_png_count": 0,
        "inherited_from": "v171.54",
        "ui_change": False,
        "files": [
            {
                "path": "reports/screenshots/a.png",
                "size_bytes": 1,
                "sha256": "0" * 64,
            }
        ],
    }
    _write(inputs.manifest or tmp_path, json.dumps(payload))
    with pytest.raises(ProtocolViolation, match="synthetic/mock"):
        validate_screenshot_provenance(inputs)


def test_inherited_visual_proof_requires_explicit_provenance(
    tmp_path: Path,
) -> None:
    inputs = _inputs(tmp_path)
    payload = {
        "archive_version": "v171.55",
        "cycle": 1573,
        "proof_type": "INHERITED_BROWSER_CAPTURED_COMPONENT_PAGE_PROOF",
        "proof_method": "verified Chromium/Xvfb baseline",
        "fresh_cycle_png_count": 0,
        "inherited_from": "v171.54",
        "ui_change": False,
        "files": [
            {
                "path": "reports/screenshots/a.png",
                "size_bytes": 1,
                "sha256": "0" * 64,
            }
        ],
    }
    _write(inputs.manifest or tmp_path, json.dumps(payload))
    result = validate_screenshot_provenance(inputs)
    assert result is not None
    assert result["inherited_from"] == "v171.54"


def test_cycle_1573_cannot_advance_without_live_proof_or_explicit_deferral(
    tmp_path: Path,
) -> None:
    inputs = _inputs(tmp_path)
    _write(
        inputs.report,
        "# v171.55 / cycle 1573\nCycle remains active.\n",
    )
    payload = {
        "archive_version": "v171.55",
        "cycle": 1573,
        "cycle_status": "ACTIVE",
        "completion_claim": "NOT_COMPLETE",
        "next_cycle": "1574",
        "live_proof": {
            "live_telegram": False,
            "real_tonconnect": False,
            "real_tonproof": False,
            "real_transaction": False,
        },
    }
    _write(inputs.generated_report, json.dumps(payload))
    with pytest.raises(ProtocolViolation, match="cannot advance"):
        validate_cycle_claims(inputs)


def test_cycle_1573_can_advance_with_explicit_user_authorized_deferral(
    tmp_path: Path,
) -> None:
    inputs = _inputs(tmp_path)
    _write(
        inputs.report,
        "# v171.55 / cycle 1573\n"
        "Local scope complete; external verification deferred post-release.\n",
    )
    payload = {
        "archive_version": "v171.55",
        "cycle": 1573,
        "cycle_status": "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED",
        "completion_claim": "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED",
        "external_verification_disposition": "DEFERRED_POST_RELEASE_BY_USER",
        "local_scope_complete": True,
        "release_ready": False,
        "next_cycle": "1574 — local release-candidate audit",
        "live_proof": {
            "live_telegram": False,
            "real_tonconnect": False,
            "real_tonproof": False,
            "real_transaction": False,
        },
    }
    _write(inputs.generated_report, json.dumps(payload))
    validate_cycle_claims(inputs)


def test_protocol_source_has_blocked_and_pass_release_states() -> None:
    root = Path(__file__).resolve().parents[2]
    source = (
        root / "ops/healer/check_critical_delivery_protocol.py"
    ).read_text(encoding="utf-8")
    norm = (
        root / "docs/NORM/HEALER_CRITICAL_DELIVERY_PROTOCOL.md"
    ).read_text(encoding="utf-8")
    assert "BLOCKED_PROTOCOL" in source
    assert "USER_DELIVERY_ALLOWED" in source
    assert "CRITICAL_DELIVERY_PROTOCOL: PASS" in source
    assert "BLOCKED_PROTOCOL" in norm
    assert "USER_DELIVERY_ALLOWED" in norm
