from __future__ import annotations

import json
from pathlib import Path


def test_healer_casebook_sync() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    atlas = json.loads((repo_root / "atlas.json").read_text("utf-8"))
    raw = json.loads((repo_root / "casebook.json").read_text("utf-8"))
    assert raw["cases_total"] == len(raw["cases"])
    known_heal_ids = {card["heal_id"] for card in atlas["cards"]}
    seen_heal_ids: set[str] = set()
    for case in raw["cases"]:
        assert case["case_id"]
        assert case["heal_id"] in known_heal_ids
        assert "treatment_history" in case
        assert case["confirmation_basis"]
        seen_heal_ids.add(case["heal_id"])
    assert known_heal_ids == seen_heal_ids
