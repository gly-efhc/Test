from __future__ import annotations

from pathlib import Path


def test_healer_atlas__file__exists() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    assert (repo_root / "atlas.json").exists()
    assert (repo_root / "docs/healer/HEALER_ATLAS.md").exists()
