<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## TON provider-subject canon lock v173.23

Утверждено пользователем 2026-08-08: `provider=ton`, provider subject
`ton_wallet_id`, значение `ton_wallet_id` — сам адрес TON-кошелька. При первом
подтверждённом входе новый `ton_wallet_id` получает новый `global_id`; при
повторном входе используется существующая связь. `ton_address` запрещено как
provider-subject alias. Generic `user_identities.provider_subject` для TON
хранит значение `ton_wallet_id`. Технические address concepts
`wallet_bindings.wallet_address`, `users.ton_wallet`, `dest_ton_address` и
`app.lib.ton_address` не являются provider-subject aliases и не
переименовываются этим каноном.


## Identity-stage interpretation lock v173.06

Любые нижние блоки с `users.user_id`, Alembic `0002`, pre-read-switch или
legacy-authoritative ownership являются историческими cycle snapshots. Они не
могут переопределять current canon: `users.global_id` — physical owner, `tg_id`
— Telegram provider subject, один Alembic head — `0001_initial_release_schema.py`.

# Текущий статус v173.02 — цикл 1685

Цикл исправляет критическое повреждение v173.01 и продолжает
fix-forward переход referral/identity-resolution контура на
единственного business owner `global_id`.

GitHub CI v173.01 не завершился: pytest дошёл до 94%, показал три
реферальных падения, после чего PostgreSQL удерживал блокировки
`referral_links/users` до принудительной отмены job по лимиту времени.
Причина находилась в изменениях цикла 1684: чрезмерный test codemod
создал `provider_provider_tg_id`, рассинхронизировал provider fixtures,
оставил старые referral SQL/test contracts и допустил lock cascade.
GitHub infrastructure не является причиной сбоя.

В v173.02 повреждённые provider-имена и fixtures восстановлены, а
принудительный переход тестов контролируется семантическим AST-guard:
вызовов business services через `tg_id` — `0`. Telegram/provider,
physical schema и historical read-through употребления сохраняются
только как построчно зарегистрированные исключения.

Referral domain переведён по цепочке schema → ORM → CRUD → services →
routes → frontend → tests. `referral_links`, `referral_codes` и
`referral_bonus_ledger` используют обязательный `global_id` как owner;
Telegram-поля остаются nullable provider metadata без business FK,
unique или self-check. Concurrent Telegram `/start` сериализуется
advisory transaction lock до проверки и создания аккаунта.

Текущая матрица содержит `3349` identity token-употреблений. Из них
`1764` открыто либо требует symbol-level решения, `1585` разрешено или
сохранено. За цикл actionable/review-остаток сокращён на `117`.
Миграция не завершена.

```text
CURRENT_HEAD_V173_02
CI_FAILURES_CORRECTED_LOCALLY
CRITICAL_CI_TIMEOUT_CAUSE_REPAIRED_LOCALLY
REFERRALS_GLOBAL_OWNER_CUTOVER
REFERRAL_PHYSICAL_SCHEMA_GLOBAL_OWNER
SEMANTIC_TEST_GLOBAL_ID_CUTOVER
TEST_BUSINESS_SELECTOR_VIOLATIONS_ZERO
TG_ID_FINAL_MATRIX_UPDATED
BUSINESS_OWNER_TG_ID_NOT_ZERO
NEXT_CYCLE_1686
REMAINING_PLAN_CYCLES_5
EXACT_HEAD_CI_REQUIRED
```

---

# Утверждённый канон провайдеров — 2026-08-05

```text
Telegram → tg_id
TON      → ton_wallet_id
Google   → google_id
Apple    → apple_id
Facebook → fb_id
Discord  → discord_id
GitHub   → github_id
provider + subject → global_id
```

`global_id` — единственный business owner. Один `global_id` может иметь несколько provider identities. После identity resolution весь business runtime использует только `global_id`.

SSOT: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
Причинность: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
NORM: `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`.
Следующий цикл: реализация канона в runtime, ORM, API, migration, tests и guards.

---

# Текущий статус v172.70 — исправление CI и продолжение циклов 1641–1646

Fresh CI run `30944313472`, commit `02667638d2b423fbc733a8e32a88b44996a3ba6e`, подтвердил зелёные Alembic, Flake8, Mypy, Bandit, compileall, PostgreSQL diagnostic и frontend build. Исправлены 2 Ruff errors и 2 pytest failures. Tasks read API переведён на canonical `global_id` signatures с централизованным legacy alias boundary. Полный inventory `tg_id` хранится в `reports/generated/`.

```text
CURRENT_HEAD_V172_67
CI_FAILURES_CORRECTED_LOCALLY
TASKS_READ_OWNER_BATCH_IMPLEMENTED
TG_ID_GLOBAL_INVENTORY_GENERATED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.66 — безопасная пересборка global owner

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как доказательства и не переопределяют v172.66.

Fresh main CI run `30937377315` exact v172.65 подтвердил Alembic,
Flake8, compileall, PostgreSQL diagnostic и `npm ci`. Он выявил
механическое повреждение массового codemod:

- Ruff: 9 ошибок;
- Mypy: 22 ошибки;
- Bandit: 1 ошибка;
- frontend build: ошибки TypeScript;
- pytest: `181 failed, 3080 passed, 28 skipped`.


Обязательный процесс работы с пользовательскими CI-логами закреплён в
`docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md и docs/AI/TOPIC_READING_ROUTES.md`. При наличии полного
архива логов запрещены бессмысленные дублирующие полные локальные CI,
pytest-shards и повторы уже зелёных этапов. Разрешены только проверки,
непосредственно связанные с подтверждёнными failures.

Корневая причина — слепая замена семантически разных provider-полей и
business-owner полей одинаковым именем `global_id`. Она создала
duplicate arguments, повреждённые SQL, DTO и frontend contracts.

В v172.66 выполнена controlled rebase пересборка:

- рабочее runtime-ядро циклов 1641–1646 восстановлено из v172.64;
- canonical бизнес-владелец остаётся `global_id`;
- временный `global_owner_alias.py` сохранён как единая граница;
- Telegram provider ingress и физические legacy-поля изолированы;
- compatibility baseline заморожен: он может только уменьшаться;
- новые runtime-файлы с `tg_id` запрещены machine guard;
- ошибки Ruff/Mypy/frontend из повреждённого codemod устранены возвратом
  корректных реализаций;
- Bandit `B101` устранён без `assert`;
- точечный набор всех 90 test-файлов, упавших в переданном CI,
  прошёл: `384 passed, 90 skipped`;
- test collection: `3358 tests`;
- production cutover не выполнялся;
- public visual, Admin UX, screenshot workflow и canonical CI не менялись.

```text
CURRENT_HEAD_V172_66
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1646_RUNTIME_KERNEL_RESTORED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
TG_ID_COMPATIBILITY_BASELINE_FROZEN
TG_ID_COMPATIBILITY_MAY_ONLY_DECREASE
MECHANICAL_BIG_BANG_CODEMOD_REJECTED
USER_PROVIDED_CI_LOGS_REPAIR_CANON_LOCKED
EXACT_CI_FAILURE_SET_TARGETED_PASS
EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.65 — Global Owner Big-Bang Rewrite

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.65.

Выполнен глобальный аудит всех `tg_id` и массовый switch бизнес-runtime
на canonical `global_id` по методу первых identity-циклов.

- изменено 158 runtime-файлов;
- введён единый `global_owner_alias.py`;
- Telegram provider fact имеет каноническое имя `tg_id`;
- `User.tg_id` хранит только внешний Telegram ID и не является business owner;
- business runtime debt вне allowlist равен нулю;
- provider/schema/history/test употребления сохранены контролируемо;
- backend compileall завершён успешно;
- функциональные тесты, PostgreSQL и static CI намеренно отложены на
  следующую фазу;
- production cutover не выполнялся;
- public visual, Admin UX, screenshot workflow и canonical CI не менялись.

```text
CURRENT_HEAD_V172_65
APPROVED_PLAN_1640_1665_LOCKED
GLOBAL_TG_ID_AUDIT_COMPLETE
BUSINESS_RUNTIME_BULK_REWRITE_COMPLETE
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
BUSINESS_RUNTIME_TG_ID_DEBT_ZERO_BY_BOUNDARY_GUARD
GLOBAL_OWNER_BULK_REWRITE_READY_FOR_TEST_REPAIR
FUNCTIONAL_TEST_QUALIFICATION_NOT_STARTED
RUNTIME_NOT_QUALIFIED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.64 — циклы 1641–1646

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.64.

Fresh main CI run `30927024899` exact v172.63 подтвердил Alembic,
Ruff, Flake8, Bandit, compileall, PostgreSQL diagnostic и production
frontend build. Mypy нашёл одну nullable-selector ошибку. Pytest
завершился результатом `5 failed, 3251 passed, 28 skipped`.

В v172.64 локально исправлено:

- Exchange selector получил явное type narrowing для Mypy;
- cutover tests используют `efhc_core.alembic_version` и реальное
  shadow mismatch вместо записи в read-only telemetry view;
- nullable Tasks cursor имеет явный PostgreSQL `TEXT` cast;
- clean-schema contract приведён к фактическим 40 FK после `0002`;
- concurrency reset восстанавливает обязательный migration-control row;
- Alembic `0002` поддерживает offline SQL generation;
- проведён полный аудит legacy aliases;
- удалены четыре финансовых `*_by_tg_id` wrappers без runtime-callers;
- удалён мёртвый Payment Intent alias `STATUS_SENT`;
- provider-ingress и активные compatibility seams сохранены;
- canonical main CI и screenshot workflow не изменялись;
- public visual baseline и Admin UX не изменялись;
- production cutover не выполнялся.

```text
CURRENT_HEAD_V172_64
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1646_ALIAS_AUDIT_COMPLETE
CYCLE_1646_SAFE_ALIAS_REMOVAL_STARTED
CYCLE_1646_EXACT_HEAD_CI_REQUIRED
CYCLE_1647_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.63 — коррекция циклов 1641–1645

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.63.

Fresh main CI run `30921046975` exact v172.62 подтвердил Flake8,
Mypy, compileall, PostgreSQL diagnostic и production frontend build.
Alembic остановился на schema guard: ожидалось 38 FK на
`users.global_id`, фактически после Achievements их стало 39. Ruff нашёл
четыре unused Referral imports, Bandit — четыре dynamic SQL boundary.
Pytest завершился результатом `32 failed, 3094 passed, 28 skipped` и
`130 errors`; основная часть errors была каскадом незавершённого Alembic.

В v172.63 локально исправлено:

- schema validator и architecture contract приведены к фактическим 39 FK;
- четыре unused Referral imports удалены;
- cutover, Admin backend и Exchange используют фиксированные SQL/ORM;
- post-cutover read control поддерживает полный режим `0001 -> 0002`;
- readiness признаёт обе поддерживаемые revisions: `0001` и `0002`;
- переходные compatibility seams сохранены до циклов 1646–1647;
- HTTP self-routes продолжают использовать canonical `global_id`;
- прямые legacy-вызовы тестов не публикуют `tg_id` в новых HTTP API;
- wallet gate и Withdraw используют canonical owner;
- line-72 и identity-boundary guards исправлены без роста legacy scope;
- canonical main CI и screenshot workflow не изменялись;
- public visual baseline не изменён;
- production cutover не выполнялся.

Локальная полная проверка текущего дерева:

- полный pytest: `3107 passed, 252 skipped`;
- architecture registry: `2507 passed, 6 skipped`;
- domain sweep циклов 1641–1645: `126 passed, 97 skipped`;
- test collection: `3348 tests`;
- backend compileall: `PASS`.

```text
CURRENT_HEAD_V172_63
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLES_1641_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.62 — циклы 1644–1645

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.62.

Fresh main CI run `30869292077` exact v172.61 подтвердил Ruff, Flake8,
Mypy, Bandit, compileall, PostgreSQL diagnostic, Alembic `0001` и
production frontend build. Pytest завершился результатом
`21 failed, 3227 passed, 28 skipped`.

В v172.62 локально исправлено:

- nullable Referral idempotency parameter получил явный PostgreSQL cast;
- Tasks JSON expression приведён к единому JSONB contract;
- concurrency fixtures больше не сохраняют пустую строку `ton_wallet`;
- stale architecture baselines и запрещённый identifier alias устранены;
- этап 1644 guards приведены к canonical Tasks/Ranks/Wallet ownership;
- текущие user routes, bot handlers и service callers используют
  canonical `global_id` после server-side identity resolution;
- `/sync/me`, Exchange, Panels, Tasks, Ranks, Withdrawals и Payment
  Intents больше не требуют Telegram ID как business owner;
- Payment Intent watcher принимает canonical token `G##########` и
  TON-only wallet binding;
- Achievements и referral codes подготовлены к обязательному `global_id`;
- добавлена Alembic revision `0002` для cutover preparation;
- добавлен изолированный операторский preflight/cutover/rollback service;
- migration `0002` не переключает production flags автоматически;
- public UI, Admin UX, screenshot workflow и canonical main CI не менялись.

```text
CURRENT_HEAD_V172_62
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1644_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1645_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1644_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.61 — циклы 1643–1644

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.61.

Fresh main CI run `30870996170` exact v172.60 подтвердил Flake8,
Mypy, Bandit, compileall, PostgreSQL diagnostic, Alembic и production
frontend build. Ruff остановился на одном SIM117. Pytest завершился
результатом `36 failed, 3210 passed, 28 skipped`.

В v172.61 локально исправлено:

- duplicate seed обязательного `identity_migration_control` заменён
  идемпотентным `ON CONFLICT DO NOTHING`;
- nullable Referral SQL parameter получил явный `BIGINT` cast;
- bank mirror отделён от пользовательского owner и больше не создаёт
  orphan provider mapping;
- Admin, Panel и Payment Intent fixtures приведены к реальному identity
  contract без ослабления production dual-write triggers;
- цикл 1644 переводит Tasks, ad rewards, Ranks, Leaderboard и Wallet reads
  на canonical `global_id`;
- TON-only account поддержан в task reward, wallet reads и rankings;
- Telegram join/proof/connect остаются provider-specific operations;
- ranks snapshot включает всех active owners и хранит nullable `tg_id`;
- visual, Admin UX, screenshot workflow, canonical main CI и production
  cutover flags не изменялись.

```text
CURRENT_HEAD_V172_61
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1643_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1644_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1643_1644_EXACT_HEAD_CI_REQUIRED
CYCLE_1645_NOT_STARTED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.60 — циклы 1641–1643

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.60.

Fresh main CI run `30864230797` exact v172.59 подтвердил Alembic,
PostgreSQL diagnostic, compileall, Flake8 и production frontend build. Он
выявил четыре реальные группы ошибок: отсутствие обязательного singleton
после test-TRUNCATE, static/type/security нарушения, потерянный повторный
idempotency read-through и legacy referral fixtures без shadow global_id.

В v172.60 локально исправлено:

- test infrastructure восстанавливает обязательный
  `identity_migration_control` после очистки схемы;
- production resolver не ослаблен и не создаёт control row автоматически;
- Ruff, Mypy, Bandit и русскоязычные engineering-policy причины устранены;
- post-lock idempotency read-through возвращён в transaction entrypoints;
- цикл 1643 переводит referral reward ownership на canonical `global_id`;
- исторические referral rows читаются по `tg_id` только при
  `global_id IS NULL`;
- `REF_ACT_UNIT`, `REF_LVL` и exchange keys получили canonical
  `G##########` форму с compatibility read-through старых ключей;
- до cutover новые операции сохраняют legacy key при
  `legacy_authoritative=TRUE`, после cutover выбирают canonical key;
- visual, Admin, screenshot workflow, canonical main CI и production flags
  не изменялись.

```text
CURRENT_HEAD_V172_60
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1640_WRITE_OWNER_FOUNDATION_PRESERVED
CYCLE_1641_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1642_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1643_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1643_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.59 — циклы 1641–1642

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.59.

По прямой команде пользователя работа продолжена без screenshot-контура.
Frontend, Admin и screenshot workflow не изменялись. Изменения ограничены
каноническим финансовым владельцем и доменными сервисами.

Выполнено локально:

- денежные entrypoints принимают `global_id` или временный `tg_id`;
- каждая операция нормализуется до canonical `global_id`;
- ledger dual-write сохраняет `global_id` и nullable provider `tg_id`;
- idempotency read-through един для обоих selector;
- TON-only account поддержан в транзакциях без Telegram ID;
- Panels переведены на canonical owner;
- Withdraw request, hold, cancel и refund используют `global_id`;
- новые Payment Intents создаются по canonical owner;
- payload поддерживает legacy Telegram token и `G##########`;
- provider-колонки финансовых таблиц подготовлены как nullable;
- migration-control и production cutover flags не переключались.

Открытые границы:

- watcher ещё должен получить canonical payload owner в цикле callers;
- referral idempotency нормализуется отдельно;
- legacy aliases удаляются только в утверждённых cleanup-циклах;
- PostgreSQL, полный pytest и static gates требует exact-head CI.

```text
CURRENT_HEAD_V172_59
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1640_WRITE_OWNER_FOUNDATION_PRESERVED
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1642_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1642_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.58 — цикл 1640 visual corrective

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.58.

Пользователь полностью утвердил план циклов 1640–1665 и потребовал немедленно
удалить неутверждённый декоративный слой v172.51. v172.58 является
селективным visual rollback поверх v172.57: backend/global_id foundation не
откатывается.

Выполнено:

- `EFHC_Bot_v172_50.zip` закреплён как public visual baseline;
- удалены premium dock, halo, многослойные тени, active lift и separators;
- восстановлен простой `KwhIcon`;
- удалён Energy marker поверх progress bar;
- восстановлена исходная profile topbar;
- полностью удалён поздний 336-строчный CSS override layer;
- сохранены `navigateBackWithinApp()`, profile sections, safe-area и QA attrs;
- добавлен architecture guard против возврата отклонённых tokens;
- утверждённый план записан в
  `docs/cycles/WORK_CYCLES_1601-1700.md`.
- рабочий screenshot workflow run `30855423325` закреплён без переписывания.

Не изменялись schema, migrations, financial formulas, global_id write-side
foundation, canonical main CI и production cutover flags.

```text
CURRENT_HEAD_V172_58
APPROVED_PLAN_1640_1665_LOCKED
PUBLIC_VISUAL_BASELINE_V172_50_LOCKED
V172_51_DECORATIVE_LAYER_REMOVED
CYCLE_1639_SCREENSHOT_CAPTURE_PASS_102_OF_102_EXACT_V172_56
CYCLE_1639_VISUAL_ACCEPTANCE_FAILED_AND_CORRECTED_LOCALLY
CYCLE_1640_WRITE_OWNER_FOUNDATION_IMPLEMENTED
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.57 — цикл 1640

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены только как evidence и не переопределяют v172.57.

Директива пользователя изменила порядок работы: visual screenshots остаются
отдельной незакрытой evidence-задачей, но больше не блокируют развитие
`global_id` business ownership.

Подтверждено для базового exact v172.56:

- main GitHub CI PASS;
- PostgreSQL 16 и canonical Alembic `0001` PASS;
- pytest: `3220 passed`, `28 skipped`;
- Flake8, Ruff, Mypy, Bandit, compileall и frontend build PASS.

В v172.57 реализован фундамент цикла 1640:

- новый `resolve_and_lock_financial_write_owner()`;
- ровно один selector: `global_id` или `tg_id`;
- результат всегда нормализуется до canonical `global_id`;
- строка `users` блокируется через `FOR UPDATE`;
- write path требует `dual_write_enabled`;
- TON-only owner разрешён без `legacy_tg_id`;
- read/write используют единый loader migration control;
- завершён audit idempotency ownership;
- выявлены три Telegram-coupled key path для исправления в циклах 1641/1643.

Application services массово ещё не переключены. Schema/migration/finance
semantics в v172.57 не изменялись.

```text
CURRENT_HEAD_V172_57
CYCLE_1639_EXACT_HEAD_MAIN_CI_PASS
CYCLE_1639_VISUAL_EVIDENCE_DEFERRED_BY_USER
CYCLE_1640_WRITE_OWNER_FOUNDATION_IMPLEMENTED
CYCLE_1640_IDEMPOTENCY_AUDIT_COMPLETE
CYCLE_1640_LOCAL_TESTS_PASS
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
CYCLE_1642_NOT_STARTED
CYCLE_1643_NOT_STARTED
CYCLE_1644_NOT_STARTED
CYCLE_1645_NOT_STARTED
CYCLE_1646_NOT_STARTED
CYCLE_1647_NOT_STARTED
CYCLE_1648_NOT_STARTED
CYCLE_1649_NOT_STARTED
CYCLE_1650_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.56 — цикл 1639 corrective

Fresh GitHub CI `83583696254` проверил exact `v172.55`:

- размер: `12670026` байт;
- SHA-256: `cb90140a7aab41f3e9cd7210a517ab032c056db80b7dafecd0ccbe5afbe774f1`;
- PostgreSQL, Alembic `0001`, Flake8, Ruff, Mypy, Bandit, compileall и
  production frontend build: PASS;
- pytest: `3219 passed`, `28 skipped`, один PostgreSQL failure;
- Chromium: корректно пропущен после обязательного pytest failure;
- CI artifacts успешно загружены; fresh PNG отсутствуют.

Единственный failure находился в qualification fixture
`test_межпровайдерный_cycle_не_создаётся_late_binding`: fixture назначал
TON-first пользователю `tg_id` и в той же транзакции добавлял
`ReferralCode`, но не задавал явную точку flush. Поскольку ORM relationship
между этими операциями отсутствует, SQLAlchemy мог отправить INSERT кода до
UPDATE `users.tg_id`, и строгий PostgreSQL FK корректно отклонял запись.

`v172.56` исправляет только порядок qualification fixture:

- после назначения `b_user.tg_id` выполняется `await session.flush()`;
- затем вставляется `ReferralCode`;
- существующий FK `referral_codes_inviter_tg_id_fkey` не ослабляется;
- production registration code, ORM models, migration `0001`, referral
  attribution, locks, sessions, financial logic и public UI не меняются;
- цикл `1640` не начат.

```text
CURRENT_HEAD_V172_56
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_RUNTIME_QUALIFIED
CYCLE_1638_REFERRAL_TRANSPORT_RUNTIME_QUALIFIED
CYCLE_1639_ALL_PROVIDER_CALLERS_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
ALL_REGISTRATION_PATHS_USE_SINGLE_CENTER
PROVIDER_NEUTRAL_FIRST_REGISTRATION_IMPLEMENTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
---
# EFHC Bot — corrective Current HEAD v172.39

Fresh CI `83288192546` проверил exact `EFHC_Bot_v172_38.zip`
размером `12598937` байт. PostgreSQL, Alembic `0012`, Flake8,
Ruff, Mypy, Bandit, compileall, frontend build и весь Chromium
прошли. Полный pytest дал одну ошибку: development archive содержал
повреждённые русские имена файлов после ошибочной перепаковки ZIP.

v172.39 исправляет только этот доказанный finding: восстановлены
28 имён без изменения содержимого, development builder переведён с
Info-ZIP на Python `zipfile`, а tests теперь проверяют UTF-8-флаг ZIP.
Universal CI, migrations `0001–0012`, auth и financial runtime не
изменялись.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

До полного fresh PASS exact v172.39 запрещены migration `0013` и
physical rename. Следующий шаг — universal canonical CI на
`EFHC_Bot_v172_39.zip`.

---

# EFHC Bot — corrective Current HEAD v172.38

Fresh CI `83283286008` проверил exact `EFHC_Bot_v172_37.zip`
размером `12594830` байт. PostgreSQL, Alembic `0012`, Flake8,
Ruff, Mypy, Bandit, compileall, `npm ci`, production build и
cross-provider Chromium прошли. Полный pytest дал `6 failed`,
`3165 passed`, `21 skipped`; общий Chromium audit дал `51`
admin marker failures и `0` cross-provider failures.

v172.38 исправляет только доказанные current-head findings:
release markers, handoff, русскоязычные evidence, provider-boundary
именование и local-only browser proof для admin routes. Universal CI,
migrations `0001–0012`, финансовый runtime и auth cryptography
не изменялись.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

До полного fresh PASS exact v172.38 запрещены migration `0013` и
physical rename. Следующий обязательный шаг — universal canonical CI
на `EFHC_Bot_v172_38.zip`.

---

# EFHC Bot — corrective Current HEAD v172.37

Fresh universal canonical CI run `83263164491` проверил exact
`EFHC_Bot_v172_36.zip` размером `12183716` байт. PostgreSQL service,
DB profile, Alembic `0012`, Flake8, Ruff, Mypy, Bandit, compileall,
полный pytest (`3170 passed, 21 skipped`), `npm ci`, Next.js production
build и Telegram/TON cross-provider Chromium proof прошли.

Общий route-backed Chromium gate остался красным: `51` failures — это
`17` admin routes в трёх viewport. Все ответы имели HTTP `200`, без
page/console errors, но с `marker_count=0`. Причина локализована в
преждевременном решении client admin guard до завершения Telegram
identity bootstrap. v172.37 вводит явный `telegramIdentityResolved` и
не позволяет guard принимать решение на основании готовности splash.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Alembic head остаётся `0012`; migration `0013` отсутствует. Циклы
`1631` и `1632` не начаты. Следующий шаг — fresh exact-head canonical
CI на `EFHC_Bot_v172_37.zip`.

---

# EFHC Bot — корректирующая точка продолжения v172.36

Fresh CI `83255023989` проверил exact `EFHC_Bot_v172_35.zip`
размером `12176001` байт. PostgreSQL preflight, Alembic `0012`,
Flake8, Ruff, Mypy, Bandit, compileall и frontend build прошли.
Cross-provider Chromium proof Telegram/TON также прошёл:
`cross_provider_failures = 0`.

Общий CI остался красным из-за 12 pytest findings и 102 route-backed
Chromium failures. Один pytest finding относился к фактическому error
envelope `401`; остальные 11 были stale contracts прежнего CI. Browser
audit доказал production CSP defect: приложение подключает Telegram SDK,
но `script-src` не разрешал `https://telegram.org`. `/404` и `/500`
также ошибочно считались неожиданными status failures, а admin pages
были собраны без test-only allowlist.

В `v172.36` исправлены CSP, route-specific expected statuses, admin
Chromium build profile и stale CI contracts. Universal CI остаётся
fail-closed; full pytest и analyzer install commands не ослаблены.
Alembic head остаётся `0012`; migration `0013` отсутствует.

```text
CYCLE_1630_CROSS_PROVIDER_SESSION_CHROMIUM_PROOF_PASS
CYCLE_1630_ROUTE_BACKED_VISUAL_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — fresh universal canonical CI на exact
`EFHC_Bot_v172_36.zip`. Physical rename цикла `1631` не начинать до
полного PASS нового HEAD.

---

# EFHC Bot — корректирующая точка продолжения v172.35

Fresh CI `83240274364` проверил exact `EFHC_Bot_v172_34.zip`
размером `12225051` байт. PostgreSQL preflight, Alembic `0012`,
Mypy, Bandit, flake8, compileall и frontend build прошли. Общий gate
остался красным из-за трёх pytest findings, одного Ruff finding и
реального Chromium audit с `exit=1`.

Три pytest findings и Ruff локализованы в stale current-head contracts,
избыточном HTTP-header assertion и import ordering. Chromium создал 103
fresh evidence files, но прежний audit не печатал точную failure summary
в job log. В `v172.35` исправлены все статические findings, proof ожидает
реальный `/api/auth/session` request и при сбое выводит точный JSON.

По прямой команде пользователя обновлён универсальный canonical CI:
Actions `v7`, постоянный real Chromium gate, без изменения строк
установки Flake8/Ruff/Mypy/Bandit. Один и тот же `ci.yml` сохранён в
корне и `.github/workflows/canon.yml` с новым защищённым SHA-256.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — fresh canonical CI на exact
`EFHC_Bot_v172_35.zip`. До полного PostgreSQL/API/Chromium PASS
physical rename цикла `1631` не начинать.

---

# EFHC Bot — корректирующая точка продолжения v172.34

Fresh CI `83236222987` проверил exact `EFHC_Bot_v172_33.zip`
размером `12155973` байта. PostgreSQL preflight, Alembic `0012`,
Mypy, Bandit, flake8, compileall и frontend build прошли. Общий gate
остался красным из-за пяти pytest и трёх Ruff findings.

Четыре pytest и все Ruff findings являются локальными static/lint
контрактами. Пятый pytest использовал production `get_db` вместо
integration session factory и поэтому получил неправильный DB URL
profile до проверки raw-initData rejection. Реальный Chromium E2E в
этом run не выполнялся: browser tests остались среди `21 skipped`.

В `v172.34` исправлены все findings и test harness. Existing protected
`frontend-visual.yml` не менялся; вызываемый им visual-audit script
теперь сам выполняет Telegram/TON Bearer-session proof с одним
`global_id` и fail-closed при raw Telegram `initData` в business
transport. Alembic head остаётся `0012`; `0013` отсутствует.

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — fresh canonical CI и отдельный fresh
`frontend-visual` run на exact `EFHC_Bot_v172_34.zip`. До получения
real PostgreSQL negative API proof и real Chromium proof цикл `1631`
не начинать.

---

# EFHC Bot — актуальная точка продолжения v172.33

Fresh CI `83193385549` проверил exact `EFHC_Bot_v172_32.zip`
размером `12203082` байт. Real PostgreSQL применил Alembic `0012`.
Ruff, Bandit, flake8, compileall, PostgreSQL preflight и Alembic прошли.
Остались 8 stale architecture assertions, 2 локальные Mypy-ошибки в
`deps.py` и один TypeScript fixture без обязательного `global_id`.
Все findings классифицированы как `SIMPLE_CORRECTIVE_SCOPE`; critical
PostgreSQL, migration, financial, auth/security blocker не подтверждён.

Findings исправлены точечно. Цикл `1630` закрывает raw Telegram
`initData` как fallback для common/admin business API: обычный API
принимает server-side Bearer session, а `initData` остаётся только
явным credential для `/auth/telegram/session`. Добавлены real PostgreSQL
cross-provider API contracts и Chromium E2E contracts для Telegram и
TON sessions одного `global_id`. Alembic head остаётся `0012`; `0013`
не создаётся. OpenAPI остаётся `131/136`, linkage — `99/99`.

```text
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_EXACT_HEAD_PASS
CYCLE_1629_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1630_CROSS_PROVIDER_E2E_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — fresh canonical GitHub CI на exact
`EFHC_Bot_v172_33.zip`. Он обязан дать real PostgreSQL и real Chromium
exact-HEAD evidence цикла `1630`. Цикл `1631` не начат.

---

# EFHC Bot — актуальная точка продолжения v172.32

Fresh CI `83181651259` проверил exact `EFHC_Bot_v172_31.zip`
размером `12185448` байт. Real PostgreSQL применил Alembic `0012`.
Положительная owner-синхронизация прошла; `owner conflict` сработал
fail-closed внутри намеренного negative contract. Старый test harness
ошибочно ожидал SQLAlchemy `DBAPIError` вместо прямого `psycopg.Error`.
Два payment tests после cleanup теряли `identity_migration_control`.
Остальные findings были локальными static/Mypy/Ruff contracts. Critical
runtime, migration, financial, auth/security blocker не подтверждён.

Все подтверждённые findings исправлены без ослабления production guards.
Cycle `1629` реализует session-first full switch для common/admin API:
Bearer server-side session имеет приоритет, legacy Telegram transport
остаётся измеряемой compatibility-веткой, добавлен provider-neutral
`POST /sync/me`, а frontend owner cache использует `GlobalId`. Raw
Telegram `initData` больше не отправляется по умолчанию после bootstrap.
Новой schema необходимости нет, поэтому Alembic head остаётся `0012` и
migration `0013` отсутствует.

```text
CYCLE_1628_EXTENDED_DOMAIN_OWNER_EXACT_HEAD_PASS
CYCLE_1628_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_PACKAGE_READY
CYCLE_1629_EXACT_HEAD_CI_REQUIRED
CYCLE_1630_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — существующий канонический GitHub CI на exact
`EFHC_Bot_v172_32.zip`. Он обязан повторно выполнить исправленный real
PostgreSQL contract `0012`, включая post-conflict downgrade fail-closed
проверку. Цикл `1630` не начат.

---

# EFHC Bot — актуальная точка продолжения v172.31

Fresh CI `83164293703` проверил exact `EFHC_Bot_v172_30.zip` размером
`12161346` байт. Real PostgreSQL успешно применил Alembic `0011`;
financial read-switch contract прошёл с rollback, legacy write +
dual-write, нулевой telemetry и `monetary discrepancy = 0.00000000`.
Precision и idempotency подтверждены неизменными. Общий CI был красным
только из-за 7 stale/static pytest contracts и 8 Ruff findings; все они
классифицированы как `SIMPLE_CORRECTIVE_SCOPE` и исправлены в v172.31.

Cycle `1628` реализован только после этой qualification. Фактическая
schema v172.30 доказала отсутствие canonical owner columns в
`shop_orders`, `user_skins`, `user_cosmetics`, поэтому создана migration
`0012` с parent `0011`. Existing admin/external owner columns из `0007`
не дублируются. Shop/NFT/cosmetics/memo/notifications/external-event
ownership использует `global_id`; Telegram остаётся provider/channel или
legacy financial selector. Financial write semantics не менялись.

```text
CYCLE_1627_FINANCIAL_READ_SWITCH_EXACT_HEAD_PASS
CYCLE_1627_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1628_PACKAGE_READY
CYCLE_1628_EXACT_HEAD_CI_REQUIRED
CYCLE_1629_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — существующий канонический GitHub CI на exact
`EFHC_Bot_v172_31.zip`. Цикл `1629` не начат.

---

# EFHC Bot — актуальная точка продолжения v172.30

Fresh CI `83151379137` проверил exact `EFHC_Bot_v172_29.zip` размером
`12078462` байта. Real PostgreSQL успешно применил Alembic `0010`;
Ruff, Mypy, Bandit, flake8, compileall и frontend build прошли. Pytest:
`1 failed / 3129 passed / 20 skipped`; единственный finding — stale
`APP_VERSION` в `env.release.example`. Financial shadow validation
цикла `1626` прошла в том же real-PostgreSQL run.

В `v172.30` finding исправлен и реализован цикл `1627`: управляемый
financial read switch через `0011`, provider-neutral owner boundary и
rollback на legacy-read. Денежные write paths, precision, idempotency и
financial formulas не меняются.

```text
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_EXACT_HEAD_PASS
CYCLE_1627_FINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1627_EXACT_HEAD_CI_REQUIRED
CYCLE_1628_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_30.zip`. Цикл `1628` не начинать до qualification `0011`.

---

# EFHC Bot — актуальная точка продолжения v172.29

Fresh CI `83144620488` проверил exact `EFHC_Bot_v172_28.zip` размером
`12126121` байт. Real PostgreSQL успешно применил Alembic `0010`;
Mypy, Bandit, flake8, compileall и frontend build прошли. Ruff дал один
`I001`, а pytest — `7 failed / 3123 passed / 20 skipped`.

Findings локализованы: два stale current-phase contracts, обязательные
timestamps в financial shadow PostgreSQL fixture и четыре referral API
tests, где `db_clean` удалял singleton `identity_migration_control`.
Production financial runtime, суммы и migration `0010` не менялись.

```text
CYCLE_1625_POSTGRESQL_0010_PASS
CYCLE_1626_CI_FINDINGS_CORRECTED_IN_V172_29
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_REQUALIFICATION_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_29.zip`. Цикл `1627` запрещён до доказанного real
PostgreSQL financial shadow exit: `fallback/mismatch/orphan/ambiguous = 0`,
денежное расхождение `0.00000000`, precision/idempotency unchanged.

---

# EFHC Bot — актуальная точка продолжения v172.28

`START_HERE.md` остаётся единственным активным порядком старта.
Песочница ChatGPT временная; source восстанавливается только из
последнего development archive. В startup запрещено полностью
загружать тяжёлые machine artifacts без причинной задачи.

Fresh CI `83121417737` проверил exact `EFHC_Bot_v172_27.zip`
размером `12049685` байт. Real PostgreSQL успешно применил
`0001 → ... → 0010`. Mypy, flake8, compileall и frontend build
прошли. Ruff, Bandit и pytest выявили локализованные findings без
PostgreSQL или financial-integrity blocker; они исправлены в v172.28.

Цикл `1626` добавляет только read-only financial shadow validation.
Alembic head остаётся `0010`; migration `0011` отсутствует. Gate
требует `fallback/mismatch/orphan/ambiguous = 0`, денежное расхождение
`0.00000000`, неизменные Numeric precision/scale и idempotency
contracts. Financial read switch не выполняется.

Текущий статус:

```text
CYCLE_1625_POSTGRESQL_0010_PASS_CI_FINDINGS_CORRECTED
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_PACKAGE_READY
CYCLE_1626_EXACT_HEAD_CI_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_28.zip`. Цикл `1627` не начат.

---

# EFHC Bot — актуальная точка продолжения v172.27

`START_HERE.md` остаётся единственным активным порядком старта.
Песочница ChatGPT временная; source восстанавливается только из
последнего development archive. В startup запрещено полностью
загружать тяжёлые machine artifacts без причинной задачи.

Fresh CI `83098311619` проверил exact `EFHC_Bot_v172_26.zip`
размером `12085081` байт. Real PostgreSQL успешно применил
`0001 → ... → 0009`. Ruff, Mypy, Bandit, flake8, compileall и
frontend build прошли. Pytest: `1 failed / 3121 passed /
20 skipped`; единственный finding — SSOT priority marker.

В `v172.27` finding исправлен и реализован цикл `1625`:
non-financial reads для panels/energy/referrals/tasks/ranks получают
provider-neutral owner boundary и могут читать shadow ownership через
`global_id`. Legacy writes, dual-write и financial reads остаются без
переключения. Alembic head — `0010`.

Текущий статус:

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_27.zip`. Цикл `1626` не начат.

---

# EFHC Bot — актуальная точка продолжения v172.26

`START_HERE.md` является единственным активным порядком старта.
Песочница ChatGPT является временной; source восстанавливается из
последнего канонического development archive. В startup запрещено полностью загружать
тяжёлые machine artifacts без причинной задачи.

Fresh GitHub CI run `83093436890` проверил exact
`EFHC_Bot_v172_25.zip` размером `12075618` байт. Mypy, Bandit, flake8,
compileall и frontend build прошли, но Alembic `0009` упал на real
PostgreSQL с `syntax error at or near WITH`. Два Ruff `SIM114` и три
независимых static/governance findings также подтверждены. Остальные
PostgreSQL failures/errors являются каскадом неустановленной schema.

`v172.26` — corrective-only package цикла `1624`. Telemetry view SQL
исправлен без изменения dual-write/read-switch semantics. Alembic head
остаётся `0009`; legacy ownership authoritative; read switch отсутствует.

Текущий статус:

```text
CYCLE_1624_CRITICAL_POSTGRESQL_0009_BLOCKER_CONFIRMED
CYCLE_1624_CORRECTIVE_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_26.zip`. Цикл `1625` не начат.

---

# Исторический snapshot до v172.26

# EFHC Bot — актуальная точка продолжения v172.25

`START_HERE.md` является единственным активным порядком старта.
Песочница ChatGPT является временной; source восстанавливается из
последнего канонического development archive. Это последний канонический
HEAD для продолжения после сборки пакета `v172.25`.

Fresh GitHub CI run `83067297122` проверил exact
`EFHC_Bot_v172_24.zip` размером `11997028` байт. Real PostgreSQL
успешно применил `0008`; Ruff, Mypy, Bandit, compileall и frontend
production build прошли. Остались четыре pytest governance/release
findings, классифицированные как `SIMPLE_CORRECTIVE_SCOPE` и исправленные
в этом пакете.

Цикл `1624` реализует dual-write на PostgreSQL boundary, read-only
shadow telemetry, idempotent conflict guards и управляемый rollback.
Legacy ownership остаётся authoritative. Read switch отсутствует.

Текущий статус:

```text
CYCLE_1623_POSTGRESQL_0008_PASS_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1624_DUAL_WRITE_SHADOW_TELEMETRY_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_25.zip`. Цикл `1625` не начат.

---

# Исторический snapshot до v172.25

# EFHC Bot — актуальная точка продолжения v172.24

`START_HERE.md` является единственным активным порядком старта.
Песочница ChatGPT является временной; source всегда восстанавливается
из последнего канонического development archive. В startup запрещено полностью загружать
тяжёлые machine artifacts без причинной задачи. Источник кода — только
development archive текущего HEAD; release/matrix не являются source.

Обязательные управляющие опоры:

- `docs/AI/AI_ARCHIVE_LAWS.md` (`AI_ARCHIVE_LAWS`);
- `docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md`;
- `ops/operator_kernel/cache/file_map.summary.json`;
- `HEALER_CAPSULE.md` читается только по причинной необходимости;
- полный `file_map.json` не загружается без доказанной причины.

Fresh GitHub CI run `83053365488` проверил exact
`EFHC_Bot_v172_23.zip` размером `12053629` байт. Ruff, Mypy, Bandit,
compileall и frontend production build прошли частично/полностью по
соответствующим gates, но реальный PostgreSQL Alembic upgrade упал на
`0008`: `LOCK TABLE can only be used in transaction blocks`. Это
`CRITICAL_BLOCKER`, поэтому цикл `1624` не начат.

Корневая причина: schema bootstrap в `backend/migrations/env.py`
переводил тот же connection в `AUTOCOMMIT`, после чего migration
connection не возвращался в transactional isolation. В `v172.24`
schema bootstrap вынесен на отдельный AUTOCOMMIT connection, а Alembic
migrations запускаются на новом connection внутри реальной transaction.

Также исправлены два Ruff `SIM117`, четыре governance/document findings,
исторический phase guard и test-isolation конфликт `tx_hash`.
`0008` не переписана по data semantics; read switch и dual-write
по-прежнему отсутствуют.

Исторические квалификационные anchors сохраняются:

- `CYCLE_1611_EXACT_HEAD_PASS`;
- `CYCLE_1612_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED`;
- исторический result `2918 passed` подтверждён run `82850316409`.

Текущий статус:

```text
CYCLE_1623_CRITICAL_POSTGRESQL_BLOCKER_CONFIRMED
CYCLE_1623_CORRECTIVE_PACKAGE_READY
CYCLE_1623_EXACT_HEAD_CI_REQUIRED
CYCLE_1624_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий шаг — один канонический exact-HEAD GitHub CI на
`EFHC_Bot_v172_24.zip`. Цикл `1624` не начат.

## Актуализация цикла 1677

Текущий изменённый HEAD: `v172.96`. Исправлены подтверждённые CI-сбои v172.93; следующий обязательный шаг — exact-head GitHub CI.
