---
name: frontend-ui-engineering
description: Use for player-facing UI, copy firewall, no-direct-api gate and React Query flows.
---

# Frontend UI Engineering — EFHC Adapter

This skill is active only under `docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md`.
EFHC AI Archive Laws, SSOT, NORM, current HEAD and the user's live instruction
have higher priority than upstream skill defaults.

## EFHC workflow

1. Read the relevant AI/SSOT/NORM/HEAD context.
2. Classify task risk as P0, P1 or P2.
3. Keep the change bounded to the current cycle.
4. Do not change economy, balances, TON, wallet, withdraw, idempotency,
   migrations, CI or security boundaries unless explicitly in scope.
5. Prefer code plus targeted tests/guards over broad rewrites.
6. Update reports, Healer, registry and Kernel when the change is confirmed.
7. State what was not proven: GitHub CI, full pytest, frontend build, visual
   runtime, live Telegram, real TonConnect, release-ready or production-ready.

## Artifact rules

Do not create root `SPEC.md` or `tasks/plan.md` by default. Use EFHC-approved
locations: chat plan, `docs/audits/tz_v*.md`, stable AI/NORM docs, cycle docs,
reports and Healer/registry records.
