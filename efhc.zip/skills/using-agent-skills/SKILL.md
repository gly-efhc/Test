---
name: using-agent-skills
description: Discovers and applies EFHC-adapted Agent Skills. Use when starting an EFHC Bot coding/review session, when task risk is P0/P1, or when selecting a workflow for code, UI, API, security, CI, release, or archive-cycle work.
---

# Using EFHC Agent Skills

## Overview

Agent Skills are available in this repository through the EFHC Agent Skills
Adapter. They are workflow helpers, not a higher source of truth than EFHC AI
Archive Laws, SSOT, NORM, Operator Kernel, Healer, uploaded logs, current HEAD
or the user's live instruction.

## EFHC threshold model

Use a skill and the relevant gate when the task is P0 or P1.

P0 includes money, balances, Bank to User movement, withdraw, TON, TonConnect,
wallet binding, payment intents, idempotency, auth, Telegram InitData, admin
permissions, DB schema, migrations, public API contracts, generated seams,
public frontend API access, public-copy firewall, security, env, secrets and
release decisions.

P1 includes public route/page/component behavior, React Query hooks, service
API, i18n, visual proof harnesses, OpenAPI docs, scheduler/background tasks,
reports, Healer and registry updates.

P2 mechanical work may use a lightweight route. Examples: formatting, index
sync, internal-doc spelling, pure renames and comments. P2 still must not weaken
locks, tests, guards or evidence.

## Skill discovery

```text
Task arrives
  → read EFHC AI / SSOT / NORM / HEAD context
  → classify P0 / P1 / P2
  → choose mapped skill or lightweight route
  → perform bounded implementation
  → verify with targeted checks
  → update reports / Healer / registry / Kernel
```

Common mapping:

- New change or specification: `spec-driven-development`.
- Planning: `planning-and-task-breakdown`.
- Implementation: `incremental-implementation`.
- Tests and guards: `test-driven-development`.
- Log repair: `debugging-and-error-recovery`.
- Code review: `code-review-and-quality`.
- Security/auth/TON/wallet/admin/env: `security-and-hardening`.
- API, DTO, OpenAPI, seams: `api-and-interface-design`.
- Public frontend, React Query, copy firewall: `frontend-ui-engineering`.
- Migration or deprecation: `deprecation-and-migration`.
- CI and automation: `ci-cd-and-automation` with EFHC CI boundary.
- Launch review: `shipping-and-launch`.

## EFHC-specific behavior

Do not create `SPEC.md` or `tasks/plan.md` by default. Use chat, approved
`docs/audits/tz_v*.md`, stable AI/NORM docs, reports and cycle documents.

Do not claim GitHub CI green from local checks. Do not claim full pytest green,
frontend build green, live Telegram proof, real TonConnect proof, release-ready
or production-ready unless the required evidence exists for the current output.

Do not change money/auth/TON/withdraw/migration logic, CI, tests or guards
without the matching EFHC gate and explicit scope.
