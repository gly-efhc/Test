#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "docs/testing/TEST_GUARD_MANIFEST.json"
PYTEST_INI = ROOT / "pytest.ini"


def _load_manifest() -> dict:
    if not MANIFEST.exists():
        raise AssertionError("TEST_GUARD_MANIFEST.json is missing")
    return json.loads(MANIFEST.read_text(encoding="utf-8"))


def _active_architecture_tests() -> list[Path]:
    return sorted((ROOT / "tests/architecture").glob("test_*.py"))


def _assert_no_archived_tests() -> None:
    bad: list[str] = []
    for path in (ROOT / "tests").rglob("test_*.py"):
        rel = path.relative_to(ROOT).as_posix()
        parts = set(path.parts)
        if any(part.startswith("_archived") for part in parts):
            bad.append(rel)
        if (
            "archived" in rel.lower()
            and "tests/architecture" not in rel
        ):
            bad.append(rel)
    if bad:
        raise AssertionError(
            "Archived test files are hidden from pytest: "
            + ", ".join(bad[:20])
        )


def _pytest_norecursedirs() -> list[str]:
    if not PYTEST_INI.exists():
        return []
    text = PYTEST_INI.read_text(encoding="utf-8")
    found: list[str] = []
    capture = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("norecursedirs"):
            capture = True
            _, _, rest = line.partition("=")
            found.extend(rest.split())
            continue
        if capture:
            if raw.startswith((" ", "\t")):
                found.extend(line.split())
            else:
                capture = False
    return [x for x in found if x]


def _assert_pytest_ini(manifest: dict) -> None:
    allowed = set(manifest.get("allowed_pytest_norecursedirs", []))
    disallowed = []
    for item in _pytest_norecursedirs():
        if item in allowed:
            continue
        if "test" in item.lower() or "arch" in item.lower():
            disallowed.append(item)
    if disallowed:
        raise AssertionError(
            "pytest.ini excludes test-"
            "like directories without allowlist: "
            + ", ".join(disallowed)
        )


def _assert_manifest_mappings(manifest: dict) -> None:
    mappings = manifest.get("mappings") or []
    if not mappings:
        raise AssertionError("TEST_GUARD_MANIFEST has no mappings")
    missing = []
    for entry in mappings:
        replacement = entry.get("active_replacement")
        if not replacement:
            missing.append(str(entry))
            continue
        if not (ROOT / replacement).exists():
            missing.append(replacement)
    if missing:
        raise AssertionError(
            "Active replacement tests missing: "
            + ", ".join(missing[:20])
        )


def _assert_minimums(manifest: dict) -> None:
    minimums = manifest.get("minimums", {})
    min_arch = int(minimums.get("active_architecture_test_files", 0))
    active = _active_architecture_tests()
    if len(active) < min_arch:
        raise AssertionError(
            f"active architecture tests dropped: {len(active)} < {min_arch}"
        )


def _missing_collect_bootstrap_modules() -> list[str]:
    """Return backend/test modules required before pytest collection.

    This guard must fail with a precise bootstrap message before
    pytest emits a long list of misleading collection errors. It does
    not skip tests and does not weaken collection; it only reports the
    real missing dependency layer.
    """
    required = (
        "alembic",
        "fastapi",
        "freezegun",
        "jwt",
        "psycopg",
        "pytest",
        "pytest_asyncio",
        "sqlalchemy",
    )
    missing: list[str] = []
    for module_name in required:
        if importlib.util.find_spec(module_name) is None:
            missing.append(module_name)
    return missing


def _assert_collect_bootstrap_dependencies() -> None:
    missing = _missing_collect_bootstrap_modules()
    if not missing:
        return
    raise AssertionError(
        "pytest collect-only bootstrap dependencies are missing: "
        + ", ".join(missing)
        + ". Install backend/requirements.txt and "
        + "requirements-test.txt before full collection."
    )


def _run_collect_only(manifest: dict) -> None:
    minimums = manifest.get("minimums", {})
    min_total = int(minimums.get("pytest_collect_total_tests", 0))
    env = os.environ.copy()
    backend = str(ROOT / "backend")
    env["PYTHONPATH"] = backend + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, "-m", "pytest", "--collect-only", "-q"],
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=180,
        check=False,
    )
    if proc.returncode != 0:
        raise AssertionError(
            "pytest collect-only failed:\n" + proc.stdout[-4000:]
        )
    match = re.search(r"(\d+) tests collected", proc.stdout)
    if not match:
        raise AssertionError("pytest collect-only count missing")
    count = int(match.group(1))
    if count < min_total:
        raise AssertionError(
            f"pytest collect count dropped: {count} < {min_total}"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--no-collect",
        action="store_true",
        help="Skip pytest collect-only; structural checks still run.",
    )
    args = parser.parse_args()
    manifest = _load_manifest()
    _assert_no_archived_tests()
    _assert_pytest_ini(manifest)
    _assert_manifest_mappings(manifest)
    _assert_minimums(manifest)
    if not args.no_collect:
        _assert_collect_bootstrap_dependencies()
        _run_collect_only(manifest)
    active = len(_active_architecture_tests())
    print(
        "OK: test suite integrity guard passed. "
        f"active_architecture={active}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from None
