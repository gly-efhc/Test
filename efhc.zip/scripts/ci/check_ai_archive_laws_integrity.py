#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LAW = ROOT / "docs/AI/AI_ARCHIVE_LAWS.md"
LOCK = ROOT / "docs/AI/AI_ARCHIVE_LAWS_LOCK.json"

REQUIRED_LAW_CLAUSES = [
    "Закон запрета диверсий и саботажа проекта",
    "Любые диверсии и саботаж проекта запрещены",
    "повторять действие, которое пользователь прямо запретил",
    "объявлять задачу выполненной без фактической передачи доступного файла",
    "Песочница ChatGPT не сохраняется между чатами",
    "Единственный порядок старта задаёт `START_HERE.md`",
    "Kernel должен ускорять точечную работу",
    "Ручной HTML, `page.set_content`",
]

REQUIRED_REFERENCES = [
    "START_HERE.md",
    "KERNEL.md",
    "docs/AI/AI_OPERATOR_RULES_EFHC.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md",
    "docs/AI/READING_ENTRYPOINT.md",
    "docs/AI/TOPIC_READING_ROUTES.md",
    "docs/SSOT/AI_ARCHIVE_LAWS_CANON.md",
    "docs/SSOT/SSOT_INDEX.md",
    "docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md",
    "docs/NORM/ARCHITECTURAL_LOCKS.md",
    "docs/testing/TEST_GUARD_MANIFEST.md",
    "ops/operator_kernel/config/invariants.yaml",
    "ops/operator_kernel/config/routes.yaml",
    "ops/canon_rules.yaml",
]


def _read(path: Path) -> str:
    if not path.exists():
        raise AssertionError(f"missing required file: {path}")
    text = path.read_text(encoding="utf-8")
    if not text.strip():
        raise AssertionError(f"empty required file: {path}")
    return text


def main() -> int:
    law_text = _read(LAW)
    lock = json.loads(_read(LOCK))
    expected = lock.get("sha256")
    actual = hashlib.sha256(law_text.encode("utf-8")).hexdigest()
    if not expected or actual != expected:
        raise AssertionError(
            "AI_ARCHIVE_LAWS.md hash differs from active lock: "
            f"{actual} != {expected}"
        )
    if lock.get("law_path") != "docs/AI/AI_ARCHIVE_LAWS.md":
        raise AssertionError("AI_ARCHIVE_LAWS_LOCK.json law_path mismatch")
    if lock.get("archive_version") != "v171_62":
        raise AssertionError("AI law lock was not actualized for v171_62")

    missing = [c for c in REQUIRED_LAW_CLAUSES if c not in law_text]
    if missing:
        raise AssertionError("mandatory law clauses missing: " + ", ".join(missing))

    missing_refs=[]
    for rel in REQUIRED_REFERENCES:
        text=_read(ROOT/rel)
        if rel in {"START_HERE.md","KERNEL.md"}:
            if "AI_ARCHIVE_LAWS" not in text and "AI Archive Laws" not in text:
                missing_refs.append(rel)
        elif "AI_ARCHIVE_LAWS" not in text:
            missing_refs.append(rel)
    if missing_refs:
        raise AssertionError("AI laws not referenced by: " + ", ".join(missing_refs))

    print("OK: AI archive laws integrity guard passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
