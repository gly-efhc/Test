#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        raise AssertionError(f"missing: {rel}")
    return path.read_text(encoding="utf-8")


def main() -> int:
    start = read("START_HERE.md")
    kernel = read("KERNEL.md")
    entry = read("docs/AI/READING_ENTRYPOINT.md")
    agents = read("AGENTS.md")
    execution = read("docs/NORM/AI_EXECUTION_BOUNDS_AND_HANDOFF_STANDARD.md")
    routes = read("ops/operator_kernel/config/routes.yaml")

    assert "latest canonical" in start.lower() or "последнего канонического" in start
    assert "Песочница ChatGPT является временной" in start
    assert "единственным активным порядком старта" in start
    assert "ACTIVE OPERATOR KERNEL / FULL DETAILED DISPATCH LAYER" in kernel
    assert "It is not only navigation" in kernel
    assert "Key project keywords and triggers" in kernel
    assert "canonical anchors" in kernel.lower()
    assert "routes.yaml" in kernel
    assert "file_map.summary.json" in kernel
    assert "single canonical startup order is `START_HERE.md`" in entry
    assert "does not define a second reading order" in agents
    assert "The user has not prohibited CI" in execution
    assert "PNG screenshots are local visual evidence" in execution
    assert "page.set_content" in execution
    assert routes.startswith("version: 1\nstart_core:\n- START_HERE.md\n- KERNEL.md\n")
    assert "operator_kernel_full_restore_from_v171_47" in routes

    assert len(re.findall(r"^## 1\. Current HEAD$", kernel, flags=re.M)) == 1
    assert "reuse `/mnt/data/efhc_workspace`" not in kernel
    assert "GitHub CI belongs to the user by default" not in execution

    print("OK: governance entrypoint and active Operator Kernel guard passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
