#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REFERENCE_ONLY = {
    "security_legal_visual_proof.py",
    "observability_visual_proof.py",
    "admin_visual_button_click_proof.py",
}
APPLICATION_PROOFS = {
    "public_visual_runtime_proof.py",
    "full_regression_visual_proof.py",
    "route_backed_visual_audit_v171_61.py",
}
FORBIDDEN_SEMANTIC_TOKENS = (
    "set_content(",
    "page.set_content",
    "server-html-proxy",
    "_load_server_document",
    "set_content_mode",
)


def main() -> int:
    bad: list[str] = []
    frontend = ROOT / "ops/frontend"
    for name in REFERENCE_ONLY:
        path = frontend / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "valid application proof" in text.lower():
            bad.append(f"{path.relative_to(ROOT)}:reference_claims_application_proof")
    for name in APPLICATION_PROOFS:
        path = frontend / name
        if not path.exists():
            bad.append(f"ops/frontend/{name}:missing")
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if any(token in text for token in FORBIDDEN_SEMANTIC_TOKENS):
            bad.append(f"{path.relative_to(ROOT)}:manual_or_proxy_html")
    helper = ROOT / "tests/frontend/e2e/_helpers.py"
    helper_text = helper.read_text(encoding="utf-8", errors="ignore")
    if any(token in helper_text for token in FORBIDDEN_SEMANTIC_TOKENS):
        bad.append(f"{helper.relative_to(ROOT)}:semantic_fallback")
    for name in APPLICATION_PROOFS:
        path = frontend / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "page.goto(" not in text and "goto(page" not in text:
            bad.append(f"{path.relative_to(ROOT)}:missing_real_navigation")
    strict = frontend / "route_backed_visual_audit_v171_61.py"
    strict_text = strict.read_text(encoding="utf-8", errors="ignore")
    for marker in (
        '"navigation_mode": "page.goto"',
        '"proof_type": "REAL_NEXTJS_ROUTE_BACKED_PAGE_GOTO"',
        '"manual_html": False',
        'data-profile-settings-entry="profile-modal"',
    ):
        if marker not in strict_text:
            bad.append(f"{strict.relative_to(ROOT)}:missing:{marker}")
    if bad:
        raise AssertionError(
            "application screenshot provenance failure: " + ", ".join(bad)
        )
    print("OK: application screenshot provenance guard passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
