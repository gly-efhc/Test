#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

label="efhc-postgres"
output_dir=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --label)
      [[ $# -ge 2 ]] || fatal "--label requires a value"
      label="$2"
      shift 2
      ;;
    --output-dir)
      [[ $# -ge 2 ]] || fatal "--output-dir requires a value"
      output_dir="$2"
      shift 2
      ;;
    *) fatal "unknown backup_postgres option: $1" ;;
  esac
done

[[ "${label}" =~ ^[A-Za-z0-9._-]+$ ]] \
  || fatal "backup label contains unsafe characters"

need_command docker
need_command sha256sum
need_command python3
prepare_persistent_layout
prepare_shared_env_link
load_env
require_docker_access

require_pg_identifier "${POSTGRES_USER}" "POSTGRES_USER"
require_pg_identifier "${POSTGRES_DB}" "POSTGRES_DB"

backup_root="${BACKUP_DIR:-${BACKUPS_DIR}}"
resolved_backup_root="$(readlink -m -- "${backup_root}")"
[[ "${resolved_backup_root}" == "${BACKUPS_DIR}" ]] \
  || fatal "BACKUP_DIR must resolve to ${BACKUPS_DIR}"
output_directory="${output_dir:-${resolved_backup_root}/postgres}"
resolved_output_directory="$(readlink -m -- "${output_directory}")"
[[ "${resolved_output_directory}" == "${resolved_backup_root}"/* ]] \
  || fatal "backup output directory must stay inside ${resolved_backup_root}"
manifest_directory="${resolved_backup_root}/manifests"
install -d -m 0700 "${resolved_output_directory}" "${manifest_directory}"

timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
output="${resolved_output_directory}/${label}_${timestamp}.dump"
partial="${output}.partial"
checksum="${output}.sha256"
manifest="${manifest_directory}/$(basename -- "${output}").json"

cleanup_partial() {
  rm -f "${partial}"
}
trap cleanup_partial EXIT

info "creating PostgreSQL custom-format backup"
compose exec -T db pg_dump \
  --username "${POSTGRES_USER}" \
  --dbname "${POSTGRES_DB}" \
  --format custom \
  --compress 6 \
  --no-owner \
  --no-acl \
  --file - > "${partial}"

[[ -s "${partial}" ]] || fatal "pg_dump produced an empty file"
info "validating PostgreSQL dump inventory"
compose exec -T db pg_restore --list < "${partial}" >/dev/null \
  || fatal "pg_restore --list rejected the new backup"

mv "${partial}" "${output}"
(
  cd "$(dirname -- "${output}")"
  sha256sum "$(basename -- "${output}")" \
    > "$(basename -- "${checksum}")"
)
chmod 0600 "${output}" "${checksum}"

python3 - "${manifest}" "${output}" "$(sha256_file "${output}")" <<'PY'
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

manifest = Path(sys.argv[1])
backup = Path(sys.argv[2])
data = {
    "schema": "EFHC_POSTGRES_BACKUP_MANIFEST_V1",
    "created_at": datetime.now(UTC).isoformat(),
    "backup_path": str(backup),
    "filename": backup.name,
    "size_bytes": backup.stat().st_size,
    "sha256": sys.argv[3],
    "pg_restore_list_verified": True,
    "app_version": os.environ.get("APP_VERSION", "unknown"),
}
manifest.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
chmod 0600 "${manifest}"
trap - EXIT

info "backup created and verified: ${output}"
printf '%s\n' "${output}"
