#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

prepare_persistent_layout
prepare_shared_env_link
load_env
"${SCRIPT_DIR}/backup_bundle.sh"
"${SCRIPT_DIR}/rotate_backups.sh"

if [[ -n "${OFFSITE_BACKUP_TARGET:-}" ]]; then
  "${SCRIPT_DIR}/sync_offsite.sh"
else
  info "OFFSITE_BACKUP_TARGET is empty; off-site sync skipped"
fi
