#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

update_mode=false
skip_public_checks=false
skip_webhook=false
preupdate_backup_complete=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --update-mode) update_mode=true ;;
    --skip-public-checks) skip_public_checks=true ;;
    --skip-webhook) skip_webhook=true ;;
    --preupdate-backup-complete) preupdate_backup_complete=true ;;
    *) fatal "unknown deploy option: $1" ;;
  esac
  shift
done

need_command curl
need_command python3
prepare_persistent_layout
prepare_shared_env_link
require_docker_access
require_release_layout
require_file "${ENV_FILE}"
require_safe_env_permissions

DEPLOY_REPORT_FILE="${EFHC_DEPLOY_REPORT_FILE:-${SHARED_DIR}/last-deploy-state.json}"
deploy_started="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
current_stage="START"
public_status="PENDING"
webhook_status="PENDING"
local_status="FAILED"

write_report() {
  local status="$1"
  local failed_stage="${2:-}"
  python3 - \
    "${DEPLOY_REPORT_FILE}" \
    "${status}" \
    "${failed_stage}" \
    "${deploy_started}" \
    "${APP_VERSION:-unknown}" \
    "${update_mode}" \
    "${local_status}" \
    "${public_status}" \
    "${webhook_status}" <<'PY'
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

(
    path,
    status,
    failed_stage,
    started_at,
    version,
    update_mode,
    local_status,
    public_status,
    webhook_status,
) = sys.argv[1:]
data = {
    "schema": "EFHC_DEPLOY_STATE_V1",
    "status": status,
    "failed_stage": failed_stage or None,
    "started_at": started_at,
    "finished_at": datetime.now(UTC).isoformat(),
    "version": version,
    "mode": "update" if update_mode == "true" else "clean_or_direct",
    "local_deployment": local_status,
    "public_verification": public_status,
    "telegram_webhook": webhook_status,
}
Path(path).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
  chmod 0600 "${DEPLOY_REPORT_FILE}"
}

on_exit() {
  local code=$?
  if [[ ${code} -ne 0 ]]; then
    compose stop proxy frontend scheduler backend >/dev/null 2>&1 || true
    write_report "FAILED" "${current_stage}" || true
    warn "deployment failed at ${current_stage}; application services remain stopped"
  fi
  exit "${code}"
}
trap on_exit EXIT

current_stage="ENV_PREFLIGHT"
write_stage "ENV_PREFLIGHT"
info "validating production configuration"
python3 "${SCRIPT_DIR}/preflight_env.py" "${ENV_FILE}"
load_env
readarray -t release_contract < <(python3 - \
  "${RELEASE_ROOT}/RELEASE_METADATA.json" \
  "${RELEASE_ROOT}/release-manifest.json" <<'PY_CONTRACT'
import json
import sys
from pathlib import Path
metadata = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
manifest = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
version = str(manifest.get("release_version") or "")
if metadata.get("version") != version:
    raise SystemExit("release metadata and manifest version mismatch")
print(version)
print(str(bool(manifest.get("clean_install_supported"))).lower())
PY_CONTRACT
)
[[ "${APP_VERSION}" == "${release_contract[0]}" ]] \
  || fatal "APP_VERSION must equal release manifest version ${release_contract[0]}"
if [[ "${update_mode}" == "false" && "${release_contract[1]}" != "true" ]]; then
  fatal "this release does not support clean installation"
fi
"${SCRIPT_DIR}/render_public_config.sh"

current_stage="COMPOSE_VALIDATE"
write_stage "COMPOSE_VALIDATE"
compose config --quiet

current_stage="BUILD_IMAGES"
write_stage "BUILD_IMAGES"
compose build --pull migrate frontend

current_stage="START_DATABASE"
write_stage "START_DATABASE"
compose up -d db
wait_service_healthy db 180

existing_schema="$(
  compose exec -T db psql \
    --username "${POSTGRES_USER}" \
    --dbname "${POSTGRES_DB}" \
    --tuples-only \
    --no-align \
    --command "SELECT CASE WHEN EXISTS (
      SELECT 1 FROM pg_catalog.pg_tables
      WHERE schemaname IN ('efhc_core', 'efhc_admin')
    ) THEN 'yes' ELSE 'no' END" \
    | tr -d '[:space:]'
)"
if [[ "${existing_schema}" == "yes" ]]; then
  info "existing EFHC schema detected; verified backup is mandatory before migrations"
  if [[ "${SAFE_UPDATE_BACKUP:-true}" != "true" ]]; then
    fatal "SAFE_UPDATE_BACKUP must remain true"
  fi
  if [[ "${update_mode}" == "true" ]]; then
    [[ "${preupdate_backup_complete}" == "true" ]] \
      || fatal "update mode requires a verified pre-update backup"
    info "verified pre-update backup was completed by updater"
  else
    current_stage="CREATE_PREUPDATE_BACKUP"
    write_stage "CREATE_PREUPDATE_BACKUP"
    "${SCRIPT_DIR}/backup_postgres.sh" \
      --label "predeploy_${APP_VERSION}"
  fi
else
  info "empty PostgreSQL detected; pre-update backup is not required"
fi

current_stage="RUN_MIGRATIONS"
write_stage "RUN_MIGRATIONS"
run_migrations_once

current_stage="START_BACKEND"
write_stage "START_BACKEND"
compose up -d --no-deps backend
wait_service_healthy backend 240

current_stage="START_SCHEDULER"
write_stage "START_SCHEDULER"
compose up -d --no-deps scheduler
wait_service_healthy scheduler 240

current_stage="START_FRONTEND"
write_stage "START_FRONTEND"
compose up -d --no-deps frontend
wait_service_healthy frontend 240

current_stage="START_PROXY"
write_stage "START_PROXY"
compose up -d --no-deps proxy
wait_service_healthy proxy 120

current_stage="LOCAL_HEALTHCHECK"
write_stage "LOCAL_HEALTHCHECK"
"${SCRIPT_DIR}/post_move_verify.sh" --local-only
local_status="PASS"

if [[ "${skip_public_checks}" == "true" ]]; then
  public_status="PENDING"
  info "public verification intentionally deferred"
else
  current_stage="PUBLIC_HEALTHCHECK"
  write_stage "PUBLIC_HEALTHCHECK"
  "${SCRIPT_DIR}/verify_public.sh"
  public_status="PASS"
fi

if [[ "${skip_webhook}" == "true" ]]; then
  webhook_status="PENDING"
  info "Telegram webhook registration intentionally deferred"
else
  current_stage="SET_WEBHOOK"
  write_stage "SET_WEBHOOK"
  "${SCRIPT_DIR}/set_telegram_webhook.sh"
  webhook_status="PASS"
fi

current_stage="FINALIZE"
write_stage "FINALIZE"
if [[ "${update_mode}" == "false" && ! -L "${CURRENT_LINK}" ]]; then
  expected_release_root="${RELEASES_DIR}/${APP_VERSION}"
  [[ "${RELEASE_ROOT}" == "${expected_release_root}" ]] \
    || fatal "clean managed deploy must run from ${expected_release_root}"
  atomic_symlink "${RELEASE_ROOT}" "${CURRENT_LINK}"
  "${SCRIPT_DIR}/install_backup_timer.sh"
fi
write_report "SUCCESS"
trap - EXIT

info "deployment completed successfully"
compose ps
printf '%s\n' \
  'EFHC PRODUCTION DEPLOYMENT REPORT' \
  "version=${APP_VERSION}" \
  'database=migrated_and_validated' \
  'seed=idempotent' \
  'backend=healthy' \
  'scheduler=healthy' \
  'frontend=healthy' \
  'proxy=healthy' \
  "local_deployment=${local_status}" \
  "public_verification=${public_status}" \
  "telegram_webhook=${webhook_status}"
