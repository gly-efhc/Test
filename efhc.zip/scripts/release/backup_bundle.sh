#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command openssl
need_command tar
need_command sha256sum
prepare_persistent_layout
prepare_shared_env_link
load_env

EFHC_BACKUP_PASSPHRASE_FILE="${EFHC_BACKUP_PASSPHRASE_FILE:-${BACKUP_PASSPHRASE_FILE}}"
require_safe_persistent_file \
  "${EFHC_BACKUP_PASSPHRASE_FILE}" \
  "${BACKUP_PASSPHRASE_FILE}" \
  "backup passphrase"
require_file "${ENV_FILE}"

backup_output="$(${SCRIPT_DIR}/backup_postgres.sh)"
backup_file="$(tail -n 1 <<<"${backup_output}")"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
stage="$(mktemp -d)"
trap 'rm -rf "${stage}"' EXIT

cp "${backup_file}" "${backup_file}.sha256" "${stage}/"
backup_manifest="${BACKUP_MANIFESTS_DIR}/$(basename -- "${backup_file}").json"
require_file "${backup_manifest}"
cp "${backup_manifest}" "${stage}/"
cp "${COMPOSE_FILE}" "${RELEASE_ROOT}/Caddyfile" "${stage}/"

openssl enc -aes-256-cbc \
  -salt \
  -pbkdf2 \
  -iter 200000 \
  -pass "file:${EFHC_BACKUP_PASSPHRASE_FILE}" \
  -in "${ENV_FILE}" \
  -out "${stage}/production.env.enc"

(
  cd "${stage}"
  find . -maxdepth 1 -type f ! -name MANIFEST.sha256 \
    -print0 \
    | sort -z \
    | xargs -0 sha256sum > MANIFEST.sha256
)

bundle="${BUNDLES_BACKUPS_DIR}/efhc-recovery-${timestamp}.tar.gz"
tar -C "${stage}" -czf "${bundle}" .
(
  cd "$(dirname -- "${bundle}")"
  sha256sum "$(basename -- "${bundle}")" \
    > "$(basename -- "${bundle}").sha256"
)
chmod 0600 "${bundle}" "${bundle}.sha256"

info "recovery bundle created: ${bundle}"
printf '%s\n' "${bundle}"
