#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

app_domain="${1:-}"
api_domain="${2:-}"
[[ -n "${app_domain}" && -n "${api_domain}" ]] \
  || fatal "usage: change_domain.sh APP_DOMAIN API_DOMAIN"
[[ "${app_domain}" =~ ^[A-Za-z0-9.-]+$ ]] \
  || fatal "invalid app domain"
[[ "${api_domain}" =~ ^[A-Za-z0-9.-]+$ ]] \
  || fatal "invalid API domain"
require_file "${ENV_FILE}"

python3 - "${ENV_FILE}" "${app_domain}" "${api_domain}" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

path = Path(sys.argv[1])
app_domain = sys.argv[2]
api_domain = sys.argv[3]
updates = {
    "APP_DOMAIN": app_domain,
    "API_DOMAIN": api_domain,
    "APP_PUBLIC_URL": f"https://{app_domain}",
    "API_PUBLIC_URL": f"https://{api_domain}",
    "APP_URL": f"https://{app_domain}",
    "FRONTEND_URL": f"https://{app_domain}",
    "BACKEND_URL": f"https://{api_domain}",
    "WEBHOOK_URL": f"https://{api_domain}/api/tg/webhook",
    "TELEGRAM_WEBHOOK_PATH": "/api/tg/webhook",
    "WEBAPP_URL": f"https://{app_domain}/app",
    "WEB_PROFILE_PUBLIC_URL": (
        f"https://{app_domain}/web-profile"
    ),
    "CORS_ALLOW_ORIGINS": f"https://{app_domain}",
    "NEXT_PUBLIC_TWA_RETURN_URL": f"https://{app_domain}/app",
    "TELEGRAM_WEBHOOK_URL": f"https://{api_domain}/api/tg/webhook",
}
lines = path.read_text(encoding="utf-8").splitlines()
seen: set[str] = set()
out: list[str] = []
for line in lines:
    key = line.split("=", 1)[0].strip() if "=" in line else ""
    if key in updates:
        out.append(f"{key}={updates[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in updates.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n", encoding="utf-8")
PY

chmod 0600 "${ENV_FILE}"
"${SCRIPT_DIR}/render_public_config.sh"

info "domain configuration updated"
info "rebuild frontend and reload proxy with ./scripts/deploy.sh"
info "then run ./scripts/set_telegram_webhook.sh"
