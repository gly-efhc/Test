#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command rclone
load_env

source_path="${1:-${BACKUP_DIR:-${RELEASE_ROOT}/backups}}"
target="${2:-${OFFSITE_BACKUP_TARGET:-}}"
[[ -n "${target}" ]] \
  || fatal "set OFFSITE_BACKUP_TARGET or pass a destination"

rclone copy \
  --checksum \
  --immutable \
  --transfers 2 \
  "${source_path}" \
  "${target}"

info "offsite backup synchronization completed"
