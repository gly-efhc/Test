#!/usr/bin/env python3
"""Pure-stdlib production .env validation before Docker build."""

from __future__ import annotations

import argparse
import json
import re
import shlex
import sys
from pathlib import Path
from urllib.parse import unquote, urlparse

PLACEHOLDERS = (
    "CHANGE_ME",
    "<",
    ">",
    "example.org",
    "fill_",
)
REQUIRED = (
    "APP_VERSION",
    "SECRET_KEY",
    "APP_DOMAIN",
    "API_DOMAIN",
    "APP_PUBLIC_URL",
    "API_PUBLIC_URL",
    "WEBHOOK_URL",
    "TELEGRAM_WEBHOOK_URL",
    "WEBAPP_URL",
    "ACME_EMAIL",
    "POSTGRES_DB",
    "POSTGRES_USER",
    "POSTGRES_PASSWORD",
    "DATABASE_URL",
    "SYNC_DATABASE_URL",
    "TELEGRAM_BOT_TOKEN",
    "TELEGRAM_WEBHOOK_SECRET",
    "CRON_SECRET",
    "ADMIN_TG_ID",
    "ADMIN_TG_IDS",
    "NEXT_PUBLIC_ADMIN_TG_IDS",
    "TON_NETWORK",
    "TON_API_BASE_URL",
    "TON_API_KEY",
    "TON_MAIN_WALLET",
    "TON_NFT_COLLECTION",
    "TON_WALLET_ADDRESS",
    "EFHC_JETTON_MASTER_ADDRESS",
    "USDT_JETTON_MASTER_ADDRESS",
    "EFHC_BACKEND_IMAGE",
    "EFHC_FRONTEND_IMAGE",
    "BACKUP_DIR",
    "EFHC_BACKUP_PASSPHRASE_FILE",
)


def parse_env(path: Path) -> tuple[dict[str, str], list[str]]:
    values: dict[str, str] = {}
    errors: list[str] = []
    if not path.is_file():
        return values, [f"file not found: {path}"]
    for number, raw in enumerate(
        path.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        if not raw or raw.lstrip().startswith("#"):
            continue
        if raw != raw.strip():
            errors.append(f"line {number}: surrounding spaces")
            continue
        if "=" not in raw:
            errors.append(f"line {number}: missing '='")
            continue
        key, value = raw.split("=", 1)
        if not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
            errors.append(f"line {number}: invalid key {key!r}")
            continue
        if value != value.strip():
            errors.append(f"line {number}: spaces around value")
        if value[:1] in {'"', "'"} or value[-1:] in {'"', "'"}:
            errors.append(
                f"line {number}: remove surrounding shell quotes"
            )
        if key in values:
            errors.append(f"line {number}: duplicate key {key}")
        values[key] = value.strip()
    return values, errors


def origin(value: str, name: str, errors: list[str]) -> None:
    parsed = urlparse(value)
    if parsed.scheme != "https" or not parsed.hostname:
        errors.append(f"{name}: HTTPS origin is required")
    if parsed.path not in {"", "/"}:
        errors.append(f"{name}: domain/origin must not contain a path")
    if parsed.query or parsed.fragment:
        errors.append(f"{name}: query and fragment are forbidden")


def validate(path: Path) -> tuple[dict[str, str], list[str]]:
    values, errors = parse_env(path)
    for key in REQUIRED:
        value = values.get(key, "")
        if not value:
            errors.append(f"{key}: required value is empty")

    for key, value in values.items():
        if any(token in value for token in PLACEHOLDERS):
            errors.append(f"{key}: placeholder value remains")
        if any(char.isspace() for char in value):
            errors.append(f"{key}: whitespace in value is forbidden")

    password = values.get("POSTGRES_PASSWORD", "")
    if password.lower() in {
        "postgres",
        "password",
        "efhc",
        "admin",
        "123456",
    }:
        errors.append("POSTGRES_PASSWORD: standard password forbidden")
    if password and len(password) < 16:
        errors.append("POSTGRES_PASSWORD: minimum length is 16")

    for key in ("SECRET_KEY", "CRON_SECRET"):
        if len(values.get(key, "")) < 32:
            errors.append(f"{key}: minimum length is 32")
    if len(values.get("TELEGRAM_WEBHOOK_SECRET", "")) < 16:
        errors.append(
            "TELEGRAM_WEBHOOK_SECRET: minimum length is 16"
        )

    admin_id = values.get("ADMIN_TG_ID", "")
    if not admin_id.isdigit() or int(admin_id or "0") <= 0:
        errors.append("ADMIN_TG_ID must be a positive integer")

    admin_ids: list[int] = []
    try:
        parsed_admin_ids = json.loads(
            values.get("ADMIN_TG_IDS", "")
        )
        admin_ids = parsed_admin_ids
        if (
            not isinstance(admin_ids, list)
            or not admin_ids
            or any(
                not isinstance(item, int) or item <= 0
                for item in admin_ids
            )
        ):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        admin_ids = []
        errors.append(
            "ADMIN_TG_IDS must be a non-empty JSON list of "
            "positive integers"
        )

    notifications = values.get(
        "ADMIN_NOTIFICATIONS_CHAT_IDS",
        "[]",
    )
    try:
        parsed_notifications = json.loads(notifications)
        if (
            not isinstance(parsed_notifications, list)
            or any(
                not isinstance(item, str) or not item.strip()
                for item in parsed_notifications
            )
        ):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        errors.append(
            "ADMIN_NOTIFICATIONS_CHAT_IDS must be a JSON list "
            "of strings"
        )

    public_admins = values.get("NEXT_PUBLIC_ADMIN_TG_IDS", "")
    if public_admins != ",".join(str(item) for item in admin_ids):
        errors.append(
            "NEXT_PUBLIC_ADMIN_TG_IDS must match ADMIN_TG_IDS "
            "as a comma-separated list"
        )

    token = values.get("TELEGRAM_BOT_TOKEN", "")
    if token and not re.fullmatch(
        r"[0-9]{6,12}:[A-Za-z0-9_-]{30,}",
        token,
    ):
        errors.append("TELEGRAM_BOT_TOKEN: invalid token format")

    for key in ("APP_DOMAIN", "API_DOMAIN"):
        value = values.get(key, "")
        if value and (
            "://" in value
            or "/" in value
            or not re.fullmatch(
                r"[A-Za-z0-9.-]+",
                value,
            )
        ):
            errors.append(
                f"{key}: hostname without scheme/path required"
            )

    for key in ("APP_PUBLIC_URL", "API_PUBLIC_URL"):
        if values.get(key):
            origin(values[key], key, errors)

    app_origin = "https://" + values.get("APP_DOMAIN", "")
    api_origin = "https://" + values.get("API_DOMAIN", "")
    exact_urls = {
        "APP_PUBLIC_URL": app_origin,
        "API_PUBLIC_URL": api_origin,
        "APP_URL": app_origin,
        "FRONTEND_URL": app_origin,
        "BACKEND_URL": api_origin,
        "WEBAPP_URL": app_origin + "/app",
        "NEXT_PUBLIC_TWA_RETURN_URL": app_origin + "/app",
    }
    for key, expected in exact_urls.items():
        if values.get(key) != expected:
            errors.append(f"{key} must equal {expected}")

    db_contracts = (
        ("DATABASE_URL", "postgresql+asyncpg"),
        ("SYNC_DATABASE_URL", "postgresql"),
    )
    for key, scheme in db_contracts:
        parsed = urlparse(values.get(key, ""))
        if parsed.scheme != scheme:
            errors.append(f"{key}: scheme must be {scheme}")
        if parsed.hostname != "db" or parsed.port != 5432:
            errors.append(f"{key}: host must be db:5432")
        if unquote(parsed.username or "") != values.get(
            "POSTGRES_USER",
            "",
        ):
            errors.append(f"{key}: PostgreSQL user mismatch")
        if unquote(parsed.password or "") != values.get(
            "POSTGRES_PASSWORD",
            "",
        ):
            errors.append(f"{key}: PostgreSQL password mismatch")
        if parsed.path != "/" + values.get("POSTGRES_DB", ""):
            errors.append(f"{key}: database name mismatch")

    path = values.get("TELEGRAM_WEBHOOK_PATH", "")
    if path != "/api/tg/webhook":
        errors.append(
            "TELEGRAM_WEBHOOK_PATH must equal /api/tg/webhook"
        )
    expected_webhook = (
        "https://"
        + values.get("API_DOMAIN", "")
        + "/api/tg/webhook"
    )
    for key in ("WEBHOOK_URL", "TELEGRAM_WEBHOOK_URL"):
        if values.get(key) != expected_webhook:
            errors.append(
                f"{key} must equal {expected_webhook}"
            )

    ton_base = values.get("TON_API_BASE_URL", "")
    if ton_base:
        parsed = urlparse(ton_base)
        if parsed.scheme != "https" or not parsed.hostname:
            errors.append("TON_API_BASE_URL: HTTPS URL required")
        if parsed.path not in {"", "/"}:
            errors.append(
                "TON_API_BASE_URL must not include /v2 or other path"
            )
    if values.get("TON_NETWORK") not in {"mainnet", "testnet"}:
        errors.append("TON_NETWORK must be mainnet or testnet")

    version = values.get("APP_VERSION", "")
    if version and not re.fullmatch(r"v\d+\.\d+", version):
        errors.append("APP_VERSION must use v<major>.<minor>")
    expected_images = {
        "EFHC_BACKEND_IMAGE": f"efhc-backend:{version}",
        "EFHC_FRONTEND_IMAGE": f"efhc-frontend:{version}",
    }
    for key, expected in expected_images.items():
        if version and values.get(key) != expected:
            errors.append(f"{key} must equal {expected}")

    if values.get("BACKUP_DIR") != "/opt/efhc/backups":
        errors.append("BACKUP_DIR must equal /opt/efhc/backups")
    if values.get("EFHC_BACKUP_PASSPHRASE_FILE") != (
        "/opt/efhc/shared/secrets/backup-passphrase"
    ):
        errors.append(
            "EFHC_BACKUP_PASSPHRASE_FILE must equal "
            "/opt/efhc/shared/secrets/backup-passphrase"
        )

    return values, sorted(set(errors))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default=".env")
    parser.add_argument("--emit-shell", action="store_true")
    args = parser.parse_args()
    values, errors = validate(Path(args.path))
    if errors:
        print("EFHC production preflight failed:", file=sys.stderr)
        for item in errors:
            print(f" - {item}", file=sys.stderr)
        return 1
    if args.emit_shell:
        for key, value in values.items():
            print(f"export {key}={shlex.quote(value)}")
    else:
        print("EFHC production preflight: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
