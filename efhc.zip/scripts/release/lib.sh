#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
RELEASE_ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd -P)"
INSTALL_ROOT="${EFHC_INSTALL_ROOT:-/opt/efhc}"
RELEASES_DIR="${INSTALL_ROOT}/releases"
SHARED_DIR="${INSTALL_ROOT}/shared"
SHARED_SECRETS_DIR="${SHARED_DIR}/secrets"
SHARED_LOGS_DIR="${SHARED_DIR}/logs"
BACKUPS_DIR="${INSTALL_ROOT}/backups"
POSTGRES_BACKUPS_DIR="${BACKUPS_DIR}/postgres"
BUNDLES_BACKUPS_DIR="${BACKUPS_DIR}/bundles"
BACKUP_MANIFESTS_DIR="${BACKUPS_DIR}/manifests"
PACKAGES_DIR="${INSTALL_ROOT}/packages"
CURRENT_LINK="${INSTALL_ROOT}/current"
PREVIOUS_LINK="${INSTALL_ROOT}/previous"
UPDATE_LOCK="${INSTALL_ROOT}/update.lock"
SHARED_ENV_FILE="${SHARED_DIR}/.env"
BACKUP_PASSPHRASE_FILE="${SHARED_SECRETS_DIR}/backup-passphrase"
COMPOSE_FILE="${EFHC_COMPOSE_FILE:-${RELEASE_ROOT}/docker-compose.yml}"
ENV_FILE="${EFHC_ENV_FILE:-${RELEASE_ROOT}/.env}"
COMPOSE_PROJECT_NAME="${EFHC_COMPOSE_PROJECT_NAME:-efhc}"

fatal() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

info() {
  printf '[EFHC] %s\n' "$*"
}

warn() {
  printf 'WARNING: %s\n' "$*" >&2
}

need_command() {
  command -v "$1" >/dev/null 2>&1 \
    || fatal "required command not found: $1"
}

require_file() {
  [[ -f "$1" ]] || fatal "required file not found: $1"
}

require_pg_identifier() {
  local value="$1"
  local label="$2"
  [[ "${value}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] \
    || fatal "${label} must be a PostgreSQL identifier"
}

sha256_file() {
  sha256sum "$1" | awk '{print $1}'
}

verify_checksum() {
  local file="$1"
  local sidecar="${2:-${file}.sha256}"
  local directory
  local expected_name
  require_file "${file}"
  require_file "${sidecar}"
  directory="$(cd -- "$(dirname -- "${file}")" && pwd -P)"
  expected_name="$(basename -- "${file}")"
  python3 - "${file}" "${sidecar}" "${expected_name}" <<'PY'
import hashlib
import re
import sys
from pathlib import Path

archive = Path(sys.argv[1])
sidecar = Path(sys.argv[2])
expected_name = sys.argv[3]
lines = [line for line in sidecar.read_text(encoding="utf-8").splitlines() if line.strip()]
if len(lines) != 1:
    raise SystemExit("SHA-256 sidecar must contain exactly one non-empty line")
match = re.fullmatch(r"([0-9a-f]{64})  ([^/\\]+)", lines[0])
if not match:
    raise SystemExit("invalid SHA-256 sidecar format")
expected_hash, listed_name = match.groups()
if listed_name != expected_name:
    raise SystemExit(
        f"SHA-256 sidecar filename mismatch: expected {expected_name}, got {listed_name}"
    )
digest = hashlib.sha256()
with archive.open("rb") as stream:
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
if digest.hexdigest() != expected_hash:
    raise SystemExit("release archive SHA-256 mismatch")
PY
  (cd "${directory}" && sha256sum --check "$(basename -- "${sidecar}")") >/dev/null
}

require_safe_persistent_file() {
  local path="$1"
  local expected="$2"
  local label="$3"
  local resolved
  local normalized_expected
  local mode
  local owner_uid
  local expected_uid

  [[ -e "${path}" || -L "${path}" ]] \
    || fatal "${label} does not exist: ${path}"
  resolved="$(readlink -f -- "${path}" 2>/dev/null || true)"
  [[ -n "${resolved}" ]] || fatal "Unable to resolve ${label} path"
  [[ -f "${resolved}" ]] \
    || fatal "Resolved ${label} is not a regular file: ${resolved}"

  normalized_expected="$(readlink -m -- "${expected}")"
  [[ "${resolved}" == "${normalized_expected}" ]] \
    || fatal "${label} must resolve to ${normalized_expected}, got ${resolved}"

  mode="$(stat -Lc '%a' "${path}")"
  case "${mode}" in
    600|400) ;;
    *) fatal "${label} permissions must be 600 or 400, got ${mode}" ;;
  esac

  owner_uid="$(stat -Lc '%u' "${path}")"
  expected_uid="${EFHC_EXPECTED_OWNER_UID:-$(id -u)}"
  [[ "${owner_uid}" == "${expected_uid}" ]] \
    || fatal "${label} owner uid must be ${expected_uid}, got ${owner_uid}"
}

prepare_persistent_layout() {
  need_command install
  install -d -m 0755 "${INSTALL_ROOT}" "${RELEASES_DIR}"
  install -d -m 0700 \
    "${SHARED_DIR}" \
    "${SHARED_SECRETS_DIR}" \
    "${SHARED_LOGS_DIR}" \
    "${BACKUPS_DIR}" \
    "${POSTGRES_BACKUPS_DIR}" \
    "${BUNDLES_BACKUPS_DIR}" \
    "${BACKUP_MANIFESTS_DIR}" \
    "${PACKAGES_DIR}"

  if [[ ! -e "${UPDATE_LOCK}" ]]; then
    : > "${UPDATE_LOCK}"
  fi
  chmod 0600 "${UPDATE_LOCK}"

  if [[ ! -e "${BACKUP_PASSPHRASE_FILE}" && ! -L "${BACKUP_PASSPHRASE_FILE}" ]]; then
    need_command openssl
    local temporary
    temporary="$(mktemp "${SHARED_SECRETS_DIR}/.backup-passphrase.XXXXXX")"
    chmod 0600 "${temporary}"
    if ! openssl rand -base64 48 > "${temporary}"; then
      rm -f "${temporary}"
      fatal "unable to create backup passphrase"
    fi
    if [[ ! -e "${BACKUP_PASSPHRASE_FILE}" && ! -L "${BACKUP_PASSPHRASE_FILE}" ]]; then
      mv "${temporary}" "${BACKUP_PASSPHRASE_FILE}"
      chmod 0600 "${BACKUP_PASSPHRASE_FILE}"
      info "persistent backup passphrase created"
    else
      rm -f "${temporary}"
    fi
  fi
  require_safe_persistent_file \
    "${BACKUP_PASSPHRASE_FILE}" \
    "${BACKUP_PASSPHRASE_FILE}" \
    "backup passphrase"
}

prepare_shared_env_link() {
  local release_env="${RELEASE_ROOT}/.env"
  prepare_persistent_layout

  if [[ ! -e "${SHARED_ENV_FILE}" && ! -L "${SHARED_ENV_FILE}" ]]; then
    if [[ -f "${release_env}" && ! -L "${release_env}" ]]; then
      install -m 0600 "${release_env}" "${SHARED_ENV_FILE}"
      rm -f "${release_env}"
      ln -s "${SHARED_ENV_FILE}" "${release_env}"
      info "moved initial .env into persistent shared storage"
    else
      fatal "persistent .env is missing: ${SHARED_ENV_FILE}"
    fi
  fi

  if [[ "${ENV_FILE}" == "${release_env}" ]]; then
    if [[ ! -e "${release_env}" && ! -L "${release_env}" ]]; then
      ln -s "${SHARED_ENV_FILE}" "${release_env}"
    fi
  fi
}

require_safe_env_permissions() {
  local expected_env="${EFHC_EXPECTED_ENV_PATH:-${SHARED_ENV_FILE}}"
  require_safe_persistent_file "${ENV_FILE}" "${expected_env}" ".env"
  local resolved_env
  resolved_env="$(readlink -f -- "${ENV_FILE}")"
  [[ "${resolved_env}" == "${SHARED_DIR}/"* ]] \
    || fatal ".env resolves outside persistent shared storage"
}

require_no_placeholders() {
  if grep -nE '<[^>]+>|example\.org|CHANGE_ME|fill_' \
    "${ENV_FILE}" >/dev/null; then
    fatal ".env still contains placeholders"
  fi
}

load_env() {
  local safe_exports
  require_file "${ENV_FILE}"
  require_safe_env_permissions
  safe_exports="$(mktemp)"
  if ! python3 "${SCRIPT_DIR}/preflight_env.py" \
    --emit-shell "${ENV_FILE}" > "${safe_exports}"; then
    rm -f "${safe_exports}"
    fatal "production environment validation failed"
  fi
  # shellcheck disable=SC1090
  source "${safe_exports}"
  rm -f "${safe_exports}"
}

require_docker_access() {
  need_command docker
  if ! docker info >/dev/null 2>&1; then
    fatal "Docker daemon is unavailable to this user. Reconnect after install or run: newgrp docker"
  fi
  docker compose version >/dev/null 2>&1 \
    || fatal "Docker Compose plugin is unavailable"
}

compose() {
  docker compose \
    --project-name "${COMPOSE_PROJECT_NAME}" \
    --env-file "${ENV_FILE}" \
    -f "${COMPOSE_FILE}" \
    "$@"
}

require_release_layout() {
  local file
  for file in \
    Dockerfile.backend \
    Dockerfile.frontend \
    Caddyfile \
    docker-compose.yml \
    backend/alembic.ini \
    frontend/package-lock.json \
    RELEASE_METADATA.json \
    UPDATE_POLICY.json \
    release-manifest.json; do
    require_file "${RELEASE_ROOT}/${file}"
  done
}

wait_service_healthy() {
  local service="$1"
  local timeout_sec="${2:-180}"
  local deadline=$((SECONDS + timeout_sec))
  local container_id
  local status

  while (( SECONDS < deadline )); do
    container_id="$(compose ps -q "${service}")"
    if [[ -n "${container_id}" ]]; then
      status="$(docker inspect \
        --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' \
        "${container_id}" 2>/dev/null || true)"
      if [[ "${status}" == "healthy" || "${status}" == "running" ]]; then
        info "service ${service} is ${status}"
        return 0
      fi
      if [[ "${status}" == "unhealthy" || "${status}" == "exited" ]]; then
        compose logs --tail 120 "${service}" >&2 || true
        fatal "service ${service} entered state ${status}"
      fi
    fi
    sleep 2
  done

  compose logs --tail 120 "${service}" >&2 || true
  fatal "service ${service} did not become healthy in ${timeout_sec}s"
}

run_migrations_once() {
  info "running one-shot database bootstrap service"
  compose up \
    --no-deps \
    --force-recreate \
    --abort-on-container-exit \
    --exit-code-from migrate \
    migrate
}

atomic_symlink() {
  local target="$1"
  local link="$2"
  local temporary="${INSTALL_ROOT}/.$(basename -- "${link}").new.$$"
  ln -s "${target}" "${temporary}"
  mv -Tf "${temporary}" "${link}"
}

write_stage() {
  local stage="$1"
  info "stage=${stage}"
  if [[ -n "${EFHC_STAGE_FILE:-}" ]]; then
    printf '%s\n' "${stage}" > "${EFHC_STAGE_FILE}"
    chmod 0600 "${EFHC_STAGE_FILE}"
  fi
}
