#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

archive="${1:-}"
checksum="${2:-}"
[[ -n "${archive}" && -n "${checksum}" ]] || fatal \
  "usage: update.sh TARGET_RELEASE.zip TARGET_RELEASE.zip.sha256 [--yes] [--replace-failed-release] [--skip-public-checks] [--skip-webhook]"
shift 2

confirmed=false
replace_failed=false
skip_public=false
skip_webhook=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes) confirmed=true ;;
    --replace-failed-release) replace_failed=true ;;
    --skip-public-checks) skip_public=true ;;
    --skip-webhook) skip_webhook=true ;;
    *) fatal "unknown update option: $1" ;;
  esac
  shift
done

need_command python3
need_command sha256sum
need_command flock
need_command tee
prepare_persistent_layout
require_docker_access
require_file "${archive}"
require_file "${checksum}"

archive="$(cd -- "$(dirname -- "${archive}")" && pwd -P)/$(basename -- "${archive}")"
checksum="$(cd -- "$(dirname -- "${checksum}")" && pwd -P)/$(basename -- "${checksum}")"
archive_name="$(basename -- "${archive}")"
checksum_name="$(basename -- "${checksum}")"

target_hint="$(python3 - "${archive_name}" <<'PY'
import re
import sys
match = re.fullmatch(r"EFHC_Bot_(v\d+_\d+)_RELEASE\.zip", sys.argv[1])
if not match:
    raise SystemExit("release archive filename is invalid")
print(match.group(1).replace("_", "."))
PY
)"

[[ -L "${CURRENT_LINK}" ]] \
  || fatal "managed current release is missing; use deploy.sh for a clean install"
current_root="$(readlink -f -- "${CURRENT_LINK}")"
[[ -d "${current_root}" ]] || fatal "current release link is broken"
[[ "${current_root}" == "${RELEASES_DIR}/"* ]] \
  || fatal "current release resolves outside ${RELEASES_DIR}"
require_file "${current_root}/RELEASE_METADATA.json"
current_version="$(python3 - "${current_root}/RELEASE_METADATA.json" <<'PY'
import json
import sys
from pathlib import Path
print(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))["version"])
PY
)"

timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
update_log="${SHARED_LOGS_DIR}/update_${current_version}_to_${target_hint}_${timestamp}.log"
touch "${update_log}"
chmod 0600 "${update_log}"
exec > >(tee -a "${update_log}") 2>&1

exec 9>"${UPDATE_LOCK}"
flock -n 9 || fatal "another EFHC update is already running"

ENV_FILE="${current_root}/.env"
prepare_shared_env_link
require_safe_env_permissions
load_env
old_backend="${EFHC_BACKEND_IMAGE:-efhc-backend:${current_version}}"
old_frontend="${EFHC_FRONTEND_IMAGE:-efhc-frontend:${current_version}}"

stage="$(mktemp -d "${RELEASES_DIR}/.staging-${target_hint}-XXXXXX")"
stage_file="${SHARED_DIR}/update-stage-${target_hint}.txt"
deploy_report="${SHARED_DIR}/deploy-${target_hint}.json"
pending_state="${SHARED_DIR}/update-state.pending.json"
target_dir=""
pre_update_backup=""
env_backup="${SHARED_DIR}/.env.before-${target_hint}"
env_candidate="$(mktemp "${SHARED_DIR}/.env.candidate-${target_hint}.XXXXXX")"
current_stage="LOCK"
database_revision=""
target_database_revision=""
migration_path_json="{}"

cleanup() {
  if [[ -d "${stage}" ]]; then
    rm -rf --one-file-system "${stage}"
  fi
  rm -f "${stage_file}" "${env_candidate}"
}
trap cleanup EXIT

write_state() {
  local status="$1"
  local failed_stage="${2:-}"
  local finished="${3:-false}"
  python3 - \
    "${pending_state}" \
    "${status}" \
    "${failed_stage}" \
    "${current_version}" \
    "${target_hint}" \
    "${current_root}" \
    "${target_dir}" \
    "${pre_update_backup}" \
    "${current_stage}" \
    "${update_log}" \
    "${finished}" \
    "${skip_public}" \
    "${skip_webhook}" \
    "${database_revision}" \
    "${target_database_revision}" \
    "${migration_path_json}" <<'PY'
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

(
    path,
    status,
    failed_stage,
    source_version,
    target_version,
    source_path,
    release_path,
    backup_path,
    stage,
    log_path,
    finished,
    skip_public,
    skip_webhook,
    database_revision,
    target_database_revision,
    migration_path_json,
) = sys.argv[1:]
state_path = Path(path)
if state_path.exists():
    data = json.loads(state_path.read_text(encoding="utf-8"))
else:
    data = {
        "schema": "EFHC_UPDATE_STATE_V3",
        "started_at": datetime.now(UTC).isoformat(),
    }
try:
    migration_path = json.loads(migration_path_json)
except json.JSONDecodeError:
    migration_path = {}
data.update(
    {
        "status": status,
        "source_version": source_version,
        "target_version": target_version,
        "source_path": source_path,
        "release_path": release_path or None,
        "pre_update_backup": backup_path or None,
        "current_stage": stage,
        "failed_stage": failed_stage or None,
        "update_log": log_path,
        "source_database_revision": database_revision or None,
        "target_database_revision": target_database_revision or None,
        "pending_database_revisions": migration_path.get("pending_revisions", []),
        "database_migration": "success" if status == "success" else "pending",
        "backend": "healthy" if status == "success" else "not_confirmed",
        "scheduler": "healthy" if status == "success" else "not_confirmed",
        "frontend": "healthy" if status == "success" else "not_confirmed",
        "proxy": "healthy" if status == "success" else "not_confirmed",
        "public_verification": (
            "pending"
            if skip_public == "true"
            else ("success" if status == "success" else "not_confirmed")
        ),
        "telegram_webhook": (
            "pending"
            if skip_webhook == "true"
            else ("success" if status == "success" else "not_confirmed")
        ),
    }
)
if finished == "true":
    data["finished_at"] = datetime.now(UTC).isoformat()
state_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
  chmod 0600 "${pending_state}"
}

current_stage="VERIFY_PACKAGE"
write_stage "VERIFY_PACKAGE"
summary="$(${SCRIPT_DIR}/safe_extract_release.py \
  "${archive}" \
  "${stage}" \
  --checksum "${checksum}" \
  --current-version "${current_version}")"

readarray -t contract < <(python3 - "${summary}" <<'PY'
import json
import sys
data = json.loads(sys.argv[1])
print(data["release_version"])
print(data["minimum_supported_source_version"])
print(json.dumps(data["supported_database_revisions"], separators=(",", ":")))
print(data["target_database_revision"])
print(str(data["application_rollback_supported"]).lower())
print(str(data["database_restore_required"]).lower())
print(data.get("rollback_reason") or "")
print(data["archive_sha256"])
PY
)
target_version="${contract[0]}"
minimum_source="${contract[1]}"
supported_db_json="${contract[2]}"
target_database_revision="${contract[3]}"
app_rollback="${contract[4]}"
restore_required="${contract[5]}"
rollback_reason="${contract[6]}"
archive_hash="${contract[7]}"
[[ "${target_version}" == "${target_hint}" ]] \
  || fatal "archive filename and manifest target version differ"

current_stage="VERIFY_MANIFEST"
write_stage "VERIFY_MANIFEST"
info "verified release manifest for ${target_version}"
info "supported application range: ${minimum_source} <= source < ${target_version}"

if [[ "${confirmed}" != "true" ]]; then
  if [[ -t 0 ]]; then
    printf 'Update EFHC %s -> %s using %s? [y/N] ' \
      "${current_version}" "${target_version}" "${archive_name}"
    read -r answer
    [[ "${answer}" =~ ^[Yy]$ ]] || fatal "update cancelled"
  else
    fatal "non-interactive update requires --yes"
  fi
fi

target_dir="${RELEASES_DIR}/${target_version}"
if [[ -e "${target_dir}" || -L "${target_dir}" ]]; then
  if [[ "${replace_failed}" != "true" ]]; then
    fatal "target release directory already exists: ${target_dir}"
  fi
  current_target="$(readlink -f -- "${CURRENT_LINK}" 2>/dev/null || true)"
  previous_target="$(readlink -f -- "${PREVIOUS_LINK}" 2>/dev/null || true)"
  [[ "${target_dir}" != "${current_target}" && "${target_dir}" != "${previous_target}" ]] \
    || fatal "cannot replace current or previous release"
  [[ -f "${target_dir}/.efhc-failed-release" ]] \
    || fatal "--replace-failed-release requires a failed-release marker"
  rm -rf --one-file-system "${target_dir}"
fi

current_stage="VERIFY_ENV_COMPATIBILITY"
write_stage "VERIFY_ENV_COMPATIBILITY"
install -m 0600 "${SHARED_ENV_FILE}" "${env_candidate}"
new_backend="efhc-backend:${target_version}"
new_frontend="efhc-frontend:${target_version}"
python3 - "${env_candidate}" "${target_version}" "${new_backend}" "${new_frontend}" <<'PY_ENV'
import sys
from pathlib import Path

path = Path(sys.argv[1])
updates = {
    "APP_VERSION": sys.argv[2],
    "EFHC_BACKEND_IMAGE": sys.argv[3],
    "EFHC_FRONTEND_IMAGE": sys.argv[4],
    "BACKUP_DIR": "/opt/efhc/backups",
    "EFHC_BACKUP_PASSPHRASE_FILE": "/opt/efhc/shared/secrets/backup-passphrase",
    "SAFE_UPDATE_BACKUP": "true",
}
lines = path.read_text(encoding="utf-8").splitlines()
seen: set[str] = set()
output: list[str] = []
for line in lines:
    if not line or line.lstrip().startswith("#") or "=" not in line:
        output.append(line)
        continue
    key, _ = line.split("=", 1)
    if key in updates:
        output.append(f"{key}={updates[key]}")
        seen.add(key)
    else:
        output.append(line)
for key, value in updates.items():
    if key not in seen:
        output.append(f"{key}={value}")
path.write_text("\n".join(output) + "\n", encoding="utf-8")
PY_ENV
python3 "${stage}/scripts/release/preflight_env.py" "${env_candidate}"

current_stage="VERIFY_DATABASE_COMPATIBILITY"
write_stage "VERIFY_DATABASE_COMPATIBILITY"
compose up -d db
wait_service_healthy db 180
alembic_table="$({
  compose exec -T db psql \
    --username "${POSTGRES_USER}" \
    --dbname "${POSTGRES_DB}" \
    --tuples-only --no-align \
    --command "SELECT CASE WHEN to_regclass('efhc_core.alembic_version') IS NULL THEN 'no' ELSE 'yes' END"
} | tr -d '[:space:]')"
[[ "${alembic_table}" == "yes" ]] \
  || fatal "existing production database has no efhc_core.alembic_version"
revision_rows="$({
  compose exec -T db psql \
    --username "${POSTGRES_USER}" \
    --dbname "${POSTGRES_DB}" \
    --tuples-only --no-align \
    --command "SELECT version_num FROM efhc_core.alembic_version"
} | sed '/^[[:space:]]*$/d')"
[[ "$(wc -l <<<"${revision_rows}" | tr -d '[:space:]')" == "1" ]] \
  || fatal "production database must have exactly one Alembic head"
database_revision="$(tr -d '[:space:]' <<<"${revision_rows}")"
migration_path_json="$(python3 \
  "${stage}/scripts/release/validate_migration_path.py" \
  --migrations-dir "${stage}/backend/migrations/versions" \
  --current-revision "${database_revision}" \
  --target-revision "${target_database_revision}" \
  --supported-revisions-json "${supported_db_json}")"
info "database compatibility accepted: ${database_revision} -> ${target_database_revision}"
write_state "validated"

current_stage="CREATE_PREUPDATE_BACKUP"
write_stage "CREATE_PREUPDATE_BACKUP"
backup_output="$(
  cd "${current_root}"
  ./scripts/release/backup_postgres.sh \
    --label "preupdate_${current_version}_to_${target_version}"
)"
pre_update_backup="$(tail -n 1 <<<"${backup_output}")"
[[ -s "${pre_update_backup}" ]] || fatal "verified pre-update backup is missing"
[[ "$(readlink -f -- "${pre_update_backup}")" == "${POSTGRES_BACKUPS_DIR}/"* ]] \
  || fatal "pre-update backup was created outside ${POSTGRES_BACKUPS_DIR}"
require_file "${pre_update_backup}.sha256"
require_file "${BACKUP_MANIFESTS_DIR}/$(basename -- "${pre_update_backup}").json"
write_state "backup_complete"

current_stage="EXTRACT_STAGING"
write_stage "EXTRACT_STAGING"
ln -s "${SHARED_ENV_FILE}" "${stage}/.env"
mv "${stage}" "${target_dir}"
stage="$(mktemp -d "${RELEASES_DIR}/.cleanup-${target_version}-XXXXXX")"

current_stage="PREPARE_SHARED_LINKS"
write_stage "PREPARE_SHARED_LINKS"
install -m 0600 "${SHARED_ENV_FILE}" "${env_backup}"
install -m 0600 "${env_candidate}" "${SHARED_ENV_FILE}.new"
mv -f "${SHARED_ENV_FILE}.new" "${SHARED_ENV_FILE}"
chmod 0600 "${SHARED_ENV_FILE}"
ENV_FILE="${target_dir}/.env"
require_safe_env_permissions
write_state "deploying"

current_stage="BUILD_IMAGES"
write_stage "BUILD_IMAGES"
deploy_args=(--update-mode --preupdate-backup-complete)
if [[ "${skip_public}" == "true" ]]; then
  deploy_args+=(--skip-public-checks)
fi
if [[ "${skip_webhook}" == "true" ]]; then
  deploy_args+=(--skip-webhook)
fi

set +e
(
  cd "${target_dir}"
  EFHC_STAGE_FILE="${stage_file}" \
  EFHC_DEPLOY_REPORT_FILE="${deploy_report}" \
  ./scripts/release/deploy.sh "${deploy_args[@]}"
)
deploy_status=$?
set -e

if [[ ${deploy_status} -ne 0 ]]; then
  failed_stage="$(cat "${stage_file}" 2>/dev/null || printf '%s' "${current_stage}")"
  current_stage="${failed_stage}"
  install -m 0600 "${env_backup}" "${SHARED_ENV_FILE}"
  rollback_attempted=false
  rollback_result="not_permitted"
  migration_may_have_started=false
  case "${failed_stage}" in
    RUN_MIGRATIONS|START_BACKEND|START_SCHEDULER|START_FRONTEND|START_PROXY|LOCAL_HEALTHCHECK|PUBLIC_HEALTHCHECK|SET_WEBHOOK|FINALIZE)
      migration_may_have_started=true
      ;;
  esac
  rollback_permitted=false
  if [[ "${migration_may_have_started}" == "false" ]]; then
    rollback_permitted=true
  elif [[ "${app_rollback}" == "true" && "${restore_required}" == "false" ]]; then
    rollback_permitted=true
  fi
  if [[ "${rollback_permitted}" == "true" ]]; then
    rollback_attempted=true
    set +e
    (
      cd "${current_root}"
      ./scripts/release/rollback_images.sh \
        "${old_backend}" "${old_frontend}" --confirm
    )
    rollback_status=$?
    set -e
    if [[ ${rollback_status} -eq 0 ]]; then
      rollback_result="success"
    else
      rollback_result="failed"
    fi
  else
    (
      cd "${target_dir}"
      compose stop proxy frontend scheduler backend
    ) || true
  fi
  write_state "failed" "${failed_stage}" "true"
  python3 - "${pending_state}" "${rollback_attempted}" "${rollback_result}" "${rollback_reason}" <<'PY'
import json
import sys
from pathlib import Path
path = Path(sys.argv[1])
data = json.loads(path.read_text(encoding="utf-8"))
data["rollback_attempted"] = sys.argv[2] == "true"
data["rollback_result"] = sys.argv[3]
data["rollback_reason"] = sys.argv[4] or None
data["database_restored"] = False
path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
  failed_dir="${RELEASES_DIR}/${target_version}.failed-${timestamp}"
  touch "${target_dir}/.efhc-failed-release"
  mv "${target_dir}" "${failed_dir}"
  mv "${pending_state}" "${SHARED_DIR}/update-state.json"
  fatal "update failed at ${failed_stage}; current link remained ${current_version}; failed release preserved at ${failed_dir}"
fi

current_stage="INSTALL_BACKUP_TIMER"
write_stage "INSTALL_BACKUP_TIMER"
"${target_dir}/scripts/release/install_backup_timer.sh"

current_stage="SWITCH_CURRENT"
write_stage "SWITCH_CURRENT"
atomic_symlink "${current_root}" "${PREVIOUS_LINK}"
atomic_symlink "${target_dir}" "${CURRENT_LINK}"

current_stage="FINAL_HEALTHCHECK"
write_stage "FINAL_HEALTHCHECK"
set +e
(
  cd "${target_dir}"
  ./scripts/release/post_move_verify.sh --local-only
)
final_status=$?
set -e
if [[ ${final_status} -ne 0 ]]; then
  install -m 0600 "${env_backup}" "${SHARED_ENV_FILE}"
  if [[ "${app_rollback}" == "true" && "${restore_required}" == "false" ]]; then
    (
      cd "${current_root}"
      ./scripts/release/rollback_images.sh \
        "${old_backend}" "${old_frontend}" --confirm
    )
    atomic_symlink "${target_dir}" "${PREVIOUS_LINK}"
    atomic_symlink "${current_root}" "${CURRENT_LINK}"
  else
    (
      cd "${target_dir}"
      compose stop proxy frontend scheduler backend
    ) || true
  fi
  write_state "failed" "FINAL_HEALTHCHECK" "true"
  mv "${pending_state}" "${SHARED_DIR}/update-state.json"
  fatal "post-switch healthcheck failed; compatibility policy applied"
fi

current_stage="FINALIZE"
write_stage "FINALIZE"
archive_destination="${PACKAGES_DIR}/${archive_name}"
checksum_destination="${PACKAGES_DIR}/${checksum_name}"
if [[ "$(readlink -f -- "${archive}")" != "$(readlink -m -- "${archive_destination}")" ]]; then
  install -m 0600 "${archive}" "${archive_destination}"
else
  chmod 0600 "${archive_destination}"
fi
if [[ "$(readlink -f -- "${checksum}")" != "$(readlink -m -- "${checksum_destination}")" ]]; then
  install -m 0600 "${checksum}" "${checksum_destination}"
else
  chmod 0600 "${checksum_destination}"
fi
write_state "success" "" "true"
python3 - "${pending_state}" "${archive_hash}" "${CURRENT_LINK}" "${PREVIOUS_LINK}" <<'PY'
import json
import sys
from pathlib import Path
path = Path(sys.argv[1])
data = json.loads(path.read_text(encoding="utf-8"))
data["archive_sha256"] = sys.argv[2]
data["current_path"] = str(Path(sys.argv[3]).resolve())
data["previous_path"] = str(Path(sys.argv[4]).resolve())
data["database_migration"] = "success"
data["database_restored"] = False
path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
mv "${pending_state}" "${SHARED_DIR}/update-state.json"
chmod 0600 "${SHARED_DIR}/update-state.json"

trap - EXIT
cleanup
info "EFHC update completed successfully"
printf '%s\n' \
  "current_version=${target_version}" \
  "previous_version=${current_version}" \
  "source_database_revision=${database_revision}" \
  "target_database_revision=${target_database_revision}" \
  "current_link=${CURRENT_LINK}" \
  "previous_link=${PREVIOUS_LINK}" \
  "pre_update_backup=${pre_update_backup}" \
  "update_state=${SHARED_DIR}/update-state.json" \
  "update_log=${update_log}" \
  "rollback=/opt/efhc/current/scripts/release/rollback_release.sh --confirm"
