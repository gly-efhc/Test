#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command curl
need_command jq
load_env

: "${TELEGRAM_BOT_TOKEN:?TELEGRAM_BOT_TOKEN is required}"
: "${TELEGRAM_WEBHOOK_SECRET:?TELEGRAM_WEBHOOK_SECRET is required}"
: "${TELEGRAM_WEBHOOK_URL:?TELEGRAM_WEBHOOK_URL is required}"
[[ "${TELEGRAM_WEBHOOK_PATH:-}" == "/api/tg/webhook" ]] \
  || fatal "TELEGRAM_WEBHOOK_PATH must be /api/tg/webhook"
expected_url="https://${API_DOMAIN}/api/tg/webhook"
[[ "${TELEGRAM_WEBHOOK_URL}" == "${expected_url}" ]] \
  || fatal "TELEGRAM_WEBHOOK_URL must equal ${expected_url}"

info "verifying public webhook route is not 404"
route_code="$(curl --silent --show-error \
  --output /dev/null --write-out '%{http_code}' \
  --request POST \
  --header 'Content-Type: application/json' \
  --header \
  "X-Telegram-Bot-Api-Secret-Token: ${TELEGRAM_WEBHOOK_SECRET}" \
  --data '{}' \
  --max-time 20 \
  "${TELEGRAM_WEBHOOK_URL}" || true)"
[[ "${route_code}" != "404" && "${route_code}" != "000" ]] \
  || fatal "Telegram webhook route is unavailable: ${route_code}"

api="https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}"
result="$(curl --fail --silent --show-error \
  --request POST \
  --data-urlencode "url=${TELEGRAM_WEBHOOK_URL}" \
  --data-urlencode "secret_token=${TELEGRAM_WEBHOOK_SECRET}" \
  --data-urlencode "drop_pending_updates=false" \
  "${api}/setWebhook")"

ok="$(jq -r '.ok // false' <<<"${result}")"
[[ "${ok}" == "true" ]] || fatal "Telegram rejected setWebhook"

info "Telegram webhook accepted"
info "verifying Telegram webhook URL"
webhook_info="$(curl --fail --silent --show-error \
  "${api}/getWebhookInfo")"
actual_url="$(jq -r '.result.url // ""' <<<"${webhook_info}")"
[[ "${actual_url}" == "${TELEGRAM_WEBHOOK_URL}" ]] \
  || fatal "Telegram webhook URL mismatch"

info "Telegram webhook verified"
