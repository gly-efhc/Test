#!/usr/bin/env python3
"""Validate a cumulative Alembic migration path without importing Alembic."""

from __future__ import annotations

import argparse
import ast
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Revision:
    revision: str
    down_revision: str | None
    path: Path


def _literal_assignment(tree: ast.Module, name: str) -> Any:
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    return ast.literal_eval(node.value)
        if (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == name
            and node.value is not None
        ):
            return ast.literal_eval(node.value)
    raise ValueError(f"missing {name!r} assignment")


def load_revisions(directory: Path) -> dict[str, Revision]:
    if not directory.is_dir():
        raise ValueError(f"migration directory is missing: {directory}")
    revisions: dict[str, Revision] = {}
    for path in sorted(directory.glob("*.py")):
        if path.name.startswith("__"):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            revision = _literal_assignment(tree, "revision")
            down_revision = _literal_assignment(tree, "down_revision")
        except (OSError, SyntaxError, ValueError) as exc:
            raise ValueError(f"unable to read migration metadata from {path.name}: {exc}") from exc
        if not isinstance(revision, str) or not revision:
            raise ValueError(f"invalid revision in {path.name}")
        if down_revision is not None and not isinstance(down_revision, str):
            raise ValueError(
                f"branched or multiple down_revision is not supported for automatic update: {path.name}"
            )
        if revision in revisions:
            raise ValueError(f"duplicate migration revision: {revision}")
        revisions[revision] = Revision(revision, down_revision, path)
    if not revisions:
        raise ValueError("no Alembic migrations found")
    return revisions


def validate_path(
    migrations_dir: Path,
    current_revision: str,
    target_revision: str,
    supported_revisions: list[str],
) -> dict[str, object]:
    supported = [str(value) for value in supported_revisions]
    if not supported or any(not value for value in supported):
        raise ValueError("supported_database_revisions must be a non-empty string list")
    if len(set(supported)) != len(supported):
        raise ValueError("supported_database_revisions contains duplicates")
    if current_revision not in supported:
        raise ValueError(
            f"database revision {current_revision} is not supported by this release"
        )

    revisions = load_revisions(migrations_dir)
    if target_revision not in revisions:
        raise ValueError(
            f"target database revision is absent from release migrations: {target_revision}"
        )
    if current_revision not in revisions:
        raise ValueError(
            f"current database revision is absent from release migrations: {current_revision}"
        )

    reverse_path: list[str] = []
    cursor: str | None = target_revision
    visited: set[str] = set()
    while cursor != current_revision:
        if cursor is None:
            raise ValueError(
                f"no cumulative migration path from {current_revision} to {target_revision}"
            )
        if cursor in visited:
            raise ValueError(f"migration cycle detected at revision {cursor}")
        visited.add(cursor)
        migration = revisions.get(cursor)
        if migration is None:
            raise ValueError(f"migration chain references missing revision {cursor}")
        reverse_path.append(cursor)
        cursor = migration.down_revision

    pending = list(reversed(reverse_path))
    return {
        "schema": "EFHC_MIGRATION_PATH_VALIDATION_V1",
        "current_revision": current_revision,
        "target_revision": target_revision,
        "pending_revisions": pending,
        "migration_count": len(pending),
        "status": "compatible",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--migrations-dir", type=Path, required=True)
    parser.add_argument("--current-revision", required=True)
    parser.add_argument("--target-revision", required=True)
    parser.add_argument("--supported-revisions-json", required=True)
    args = parser.parse_args()
    try:
        parsed = json.loads(args.supported_revisions_json)
        if not isinstance(parsed, list):
            raise ValueError("supported revisions JSON must be an array")
        result = validate_path(
            args.migrations_dir.resolve(),
            args.current_revision,
            args.target_revision,
            [str(value) for value in parsed],
        )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"EFHC migration compatibility failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
