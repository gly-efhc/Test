#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
exec "${SCRIPT_DIR}/rollback_release.sh" "$@"
