#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command docker
need_command sha256sum
load_env
require_docker_access

require_pg_identifier "${POSTGRES_USER}" "POSTGRES_USER"
require_pg_identifier "${POSTGRES_DB}" "POSTGRES_DB"

backup="${1:-}"
[[ -n "${backup}" ]] || fatal "usage: restore_drill.sh FILE"
require_file "${backup}"
require_file "${backup}.sha256"
verify_checksum "${backup}"

drill_db="efhc_restore_$(date -u +%Y%m%d%H%M%S)"
require_pg_identifier "${drill_db}" "drill database"

cleanup() {
  compose exec -T db dropdb \
    --username "${POSTGRES_USER}" \
    --if-exists "${drill_db}" >/dev/null 2>&1 || true
}
trap cleanup EXIT

compose exec -T db createdb \
  --username "${POSTGRES_USER}" \
  "${drill_db}"
compose exec -T db pg_restore \
  --username "${POSTGRES_USER}" \
  --dbname "${drill_db}" \
  --exit-on-error --no-owner --no-acl < "${backup}"

compose exec -T db psql \
  --username "${POSTGRES_USER}" \
  --dbname "${drill_db}" \
  --set ON_ERROR_STOP=1 \
  --command \
  "SELECT version_num FROM efhc_core.alembic_version;"

compose run --rm --no-deps \
  -e POSTGRES_DB="${drill_db}" \
  backend python -m app.release.database_validation \
  --database-name "${drill_db}"

info "restore drill passed: ${drill_db}"
