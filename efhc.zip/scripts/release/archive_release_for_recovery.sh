#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command unzip
need_command sha256sum
load_env

archive="${1:-}"
[[ -n "${archive}" ]] \
  || fatal "usage: archive_release_for_recovery.sh RELEASE.zip"
require_file "${archive}"
require_file "${archive}.sha256"
verify_checksum "${archive}"
unzip -tq "${archive}" >/dev/null

BACKUP_DIR="${BACKUP_DIR:-${RELEASE_ROOT}/backups}"
target="${BACKUP_DIR}/releases"
mkdir -p "${target}"
chmod 0700 "${BACKUP_DIR}" "${target}"
cp --preserve=mode,timestamps \
  "${archive}" \
  "${archive}.sha256" \
  "${target}/"
chmod 0600 \
  "${target}/$(basename -- "${archive}")" \
  "${target}/$(basename -- "${archive}").sha256"

info "release archive stored for off-site recovery: ${target}"
