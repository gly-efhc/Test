#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

confirmation="${1:-}"
[[ "${confirmation}" == "--confirm" ]] \
  || fatal "usage: rollback_release.sh --confirm"

need_command python3
need_command flock
prepare_persistent_layout
require_docker_access

[[ -L "${CURRENT_LINK}" ]] || fatal "current release link is unavailable"
[[ -L "${PREVIOUS_LINK}" ]] || fatal "previous release link is unavailable"
current_root="$(readlink -f -- "${CURRENT_LINK}")"
previous_root="$(readlink -f -- "${PREVIOUS_LINK}")"
[[ -d "${current_root}" && -d "${previous_root}" ]] \
  || fatal "current or previous release link is broken"

exec 9>"${UPDATE_LOCK}"
flock -n 9 || fatal "another EFHC update or rollback is already running"

readarray -t versions < <(python3 - \
  "${current_root}/RELEASE_METADATA.json" \
  "${previous_root}/RELEASE_METADATA.json" \
  "${current_root}/release-manifest.json" <<'PY'
import json
import sys
from pathlib import Path
current = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
previous = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
manifest = json.loads(Path(sys.argv[3]).read_text(encoding="utf-8"))
rollback = manifest.get("rollback_compatibility") or {}
print(current["version"])
print(previous["version"])
print(str(bool(rollback.get("application_rollback_supported"))).lower())
print(str(bool(rollback.get("database_restore_required"))).lower())
print(str(rollback.get("reason") or ""))
PY
)
current_version="${versions[0]}"
previous_version="${versions[1]}"
app_rollback="${versions[2]}"
restore_required="${versions[3]}"
rollback_reason="${versions[4]}"

[[ "${app_rollback}" == "true" && "${restore_required}" == "false" ]] \
  || fatal "application rollback refused: ${rollback_reason:-database restore is required}"

env_backup="${SHARED_DIR}/.env.before-${current_version}"
require_file "${env_backup}"
install -m 0600 "${env_backup}" "${SHARED_ENV_FILE}"

readarray -t images < <(python3 - "${SHARED_ENV_FILE}" "${previous_version}" <<'PY'
import sys
from pathlib import Path
values = {}
for raw in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if raw and not raw.lstrip().startswith("#") and "=" in raw:
        key, value = raw.split("=", 1)
        values[key] = value
version = sys.argv[2]
print(values.get("EFHC_BACKEND_IMAGE", f"efhc-backend:{version}"))
print(values.get("EFHC_FRONTEND_IMAGE", f"efhc-frontend:{version}"))
PY
)
previous_backend="${images[0]}"
previous_frontend="${images[1]}"

info "rolling back EFHC application ${current_version} -> ${previous_version}"
(
  cd "${previous_root}"
  ./scripts/release/rollback_images.sh \
    "${previous_backend}" "${previous_frontend}" --confirm
)

atomic_symlink "${current_root}" "${PREVIOUS_LINK}"
atomic_symlink "${previous_root}" "${CURRENT_LINK}"

(
  cd "${previous_root}"
  ./scripts/release/post_move_verify.sh --local-only
  ./scripts/release/install_backup_timer.sh
)

state_file="${SHARED_DIR}/update-state.json"
python3 - \
  "${state_file}" \
  "${current_version}" \
  "${previous_version}" \
  "${current_root}" \
  "${previous_root}" <<'PY'
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
path = Path(sys.argv[1])
data = {}
if path.exists():
    data = json.loads(path.read_text(encoding="utf-8"))
data.update(
    {
        "schema": "EFHC_UPDATE_STATE_V3",
        "status": "rollback_complete",
        "rolled_back_at": datetime.now(UTC).isoformat(),
        "rollback_from_version": sys.argv[2],
        "rollback_to_version": sys.argv[3],
        "current_path": sys.argv[5],
        "previous_path": sys.argv[4],
        "database_restored": False,
        "backend": "healthy",
        "scheduler": "healthy",
        "frontend": "healthy",
        "proxy": "healthy",
    }
)
path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
chmod 0600 "${state_file}"

info "EFHC application rollback completed; PostgreSQL was not restored"
printf '%s\n' \
  "current_version=${previous_version}" \
  "previous_version=${current_version}" \
  "database_restored=false"
