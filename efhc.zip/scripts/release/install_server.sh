#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo ./scripts/release/install_server.sh" >&2
  exit 1
fi

. /etc/os-release
if [[ "${ID}" != "ubuntu" || "${VERSION_ID}" != "24.04" ]]; then
  echo "Ubuntu 24.04 is required by this installer." >&2
  exit 1
fi

apt-get update
apt-get install -y \
  ca-certificates curl gnupg jq unzip openssl rclone python3

install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc

cat > /etc/apt/sources.list.d/docker.sources <<EOF_DOCKER
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: ${UBUNTU_CODENAME:-noble}
Components: stable
Signed-By: /etc/apt/keyrings/docker.asc
EOF_DOCKER

apt-get update
apt-get install -y \
  docker-ce \
  docker-ce-cli \
  containerd.io \
  docker-buildx-plugin \
  docker-compose-plugin

systemctl enable --now docker

target_user="${EFHC_DOCKER_USER:-${SUDO_USER:-}}"
if [[ -n "${target_user}" && "${target_user}" != "root" ]]; then
  if ! id "${target_user}" >/dev/null 2>&1; then
    echo "Unknown EFHC_DOCKER_USER: ${target_user}" >&2
    exit 1
  fi
  usermod -aG docker "${target_user}"
fi

install -d -m 0755 /opt/efhc /opt/efhc/releases
install -d -m 0700 \
  /opt/efhc/shared \
  /opt/efhc/shared/secrets \
  /opt/efhc/shared/logs \
  /opt/efhc/backups \
  /opt/efhc/backups/postgres \
  /opt/efhc/backups/bundles \
  /opt/efhc/backups/manifests \
  /opt/efhc/packages

passphrase=/opt/efhc/shared/secrets/backup-passphrase
if [[ ! -e "${passphrase}" ]]; then
  umask 077
  openssl rand -base64 48 > "${passphrase}"
  chmod 0600 "${passphrase}"
fi

touch /opt/efhc/update.lock
chmod 0600 /opt/efhc/update.lock

if [[ -n "${target_user}" && "${target_user}" != "root" ]]; then
  usermod -aG docker "${target_user}"
  echo "Added ${target_user} to the docker group."
  echo "Open a new login session or run: newgrp docker"
  echo "Production files remain root-owned; use sudo for release operations."
fi

docker version
docker compose version
echo "EFHC server prerequisites and persistent layout installed."
