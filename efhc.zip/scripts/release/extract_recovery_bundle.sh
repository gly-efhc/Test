#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command openssl
need_command tar
need_command sha256sum

bundle="${1:-}"
confirmation="${2:-}"
[[ -n "${bundle}" ]] \
  || fatal "usage: extract_recovery_bundle.sh BUNDLE --confirm"
[[ "${confirmation}" == "--confirm" ]] \
  || fatal "bundle extraction requires explicit --confirm"
require_file "${bundle}"
require_file "${bundle}.sha256"
verify_checksum "${bundle}"

passphrase_file="${EFHC_BACKUP_PASSPHRASE_FILE:-}"
if [[ -z "${passphrase_file}" ]]; then
  passphrase_file="${RELEASE_ROOT}/secrets/backup-passphrase"
fi
require_file "${passphrase_file}"

stage="$(mktemp -d)"
trap 'rm -rf "${stage}"' EXIT
tar -C "${stage}" -xzf "${bundle}"
require_file "${stage}/MANIFEST.sha256"
(cd "${stage}" && sha256sum --check MANIFEST.sha256)

env_output="${RELEASE_ROOT}/.env.recovered"
[[ ! -e "${env_output}" ]] \
  || fatal "refusing to overwrite ${env_output}"
openssl enc -d -aes-256-cbc \
  -pbkdf2 \
  -iter 200000 \
  -pass "file:${passphrase_file}" \
  -in "${stage}/production.env.enc" \
  -out "${env_output}"
chmod 0600 "${env_output}"

recovery_dir="${RELEASE_ROOT}/recovered"
mkdir -p "${recovery_dir}"
chmod 0700 "${recovery_dir}"
find "${stage}" -maxdepth 1 -type f \
  \( -name '*.dump' -o -name '*.dump.sha256' \) \
  -exec cp --preserve=mode,timestamps {} "${recovery_dir}/" \;
chmod 0600 "${recovery_dir}"/*

info "recovered environment: ${env_output}"
info "recovered database files: ${recovery_dir}"
info "review .env.recovered, move it to .env, then restore the dump"
