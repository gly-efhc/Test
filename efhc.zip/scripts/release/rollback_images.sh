#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

require_docker_access
require_file "${ENV_FILE}"
require_safe_env_permissions
load_env

previous_backend="${1:-}"
previous_frontend="${2:-}"
confirmation="${3:-}"
[[ -n "${previous_backend}" && -n "${previous_frontend}" ]] \
  || fatal "usage: rollback_images.sh BACKEND_IMAGE FRONTEND_IMAGE --confirm"
[[ "${confirmation}" == "--confirm" ]] \
  || fatal "rollback requires explicit --confirm"

if ! docker image inspect "${previous_backend}" >/dev/null 2>&1; then
  fatal "previous backend image is not present: ${previous_backend}"
fi
if ! docker image inspect "${previous_frontend}" >/dev/null 2>&1; then
  fatal "previous frontend image is not present: ${previous_frontend}"
fi

info "rolling back application images without changing PostgreSQL"
EFHC_BACKEND_IMAGE="${previous_backend}" \
EFHC_FRONTEND_IMAGE="${previous_frontend}" \
  compose up -d --no-build --no-deps backend scheduler
wait_service_healthy backend 240
wait_service_healthy scheduler 240

EFHC_BACKEND_IMAGE="${previous_backend}" \
EFHC_FRONTEND_IMAGE="${previous_frontend}" \
  compose up -d --no-build --no-deps frontend
wait_service_healthy frontend 240

compose up -d --no-build --no-deps proxy
wait_service_healthy proxy 120
"${SCRIPT_DIR}/post_move_verify.sh" --local-only
info "application image rollback completed"
