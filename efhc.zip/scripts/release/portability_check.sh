#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command python3
require_release_layout

python3 - "${RELEASE_ROOT}" <<'PY'
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
required = [
    "Dockerfile.backend",
    "Dockerfile.frontend",
    "docker-compose.yml",
    "Caddyfile",
    ".env.example",
    "backend/run.py",
    "backend/app/services/scheduler_service.py",
    "backend/migrations/versions/0001_initial_release_schema.py",
    "scripts/release/install_server.sh",
    "scripts/release/deploy.sh",
    "scripts/release/rollback_images.sh",
    "scripts/release/backup_postgres.sh",
    "scripts/release/restore_postgres.sh",
    "scripts/release/change_domain.sh",
    "scripts/release/set_telegram_webhook.sh",
    "scripts/release/post_move_verify.sh",
    "scripts/release/render_public_config.sh",
]
missing = [item for item in required if not (root / item).exists()]
if missing:
    raise SystemExit(f"missing release files: {missing}")

runtime_files = [
    root / "docker-compose.yml",
    root / "Dockerfile.backend",
    root / "Dockerfile.frontend",
    root / "Caddyfile",
]
forbidden = (
    "ovhcloud",
    "vercel",
    "neon.tech",
    "google cloud",
    "cloud run",
)
findings: list[str] = []
for path in runtime_files:
    text = path.read_text(encoding="utf-8").lower()
    for token in forbidden:
        if token in text:
            findings.append(f"{path.name}:{token}")
if findings:
    raise SystemExit(f"provider lock-in found: {findings}")

compose = (root / "docker-compose.yml").read_text(encoding="utf-8")

def service_block(name: str, next_name: str | None) -> str:
    start = compose.index(f"  {name}:\n")
    end = (
        compose.index(f"  {next_name}:\n", start)
        if next_name
        else compose.index("\nvolumes:\n", start)
    )
    return compose[start:end]

blocks = {
    "db": service_block("db", "backend"),
    "backend": service_block("backend", "frontend"),
    "frontend": service_block("frontend", "proxy"),
    "proxy": service_block("proxy", None),
}
if "env_file:" in blocks["db"]:
    raise SystemExit("database must not receive the complete .env")
if "env_file:" in blocks["proxy"]:
    raise SystemExit("proxy must not receive the complete .env")
if "env_file:" not in blocks["backend"]:
    raise SystemExit("backend must receive the server-side .env")
for name, block in blocks.items():
    if "logging: *json-logging" not in block:
        raise SystemExit(f"bounded logging missing for {name}")

runner = (root / "backend/run.py").read_text(encoding="utf-8")
if "SchedulerService" not in runner:
    raise SystemExit("production runner does not use SchedulerService")
if "register_defaults(strict=True)" not in runner:
    raise SystemExit("production scheduler registration is not strict")

scheduler = (
    root / "backend/app/services/scheduler_service.py"
).read_text(encoding="utf-8")
for job in (
    "generate_energy",
    "check_ton_inbox",
    "check_vip_nft",
    "archive_panels",
    "update_ranks",
    "tasks_autorestart",
    "ads_rotation",
    "reports_daily",
):
    if f'"{job}"' not in scheduler:
        raise SystemExit(f"scheduler job missing: {job}")

restore = (
    root / "scripts/release/restore_postgres.sh"
).read_text(encoding="utf-8")
if "remain stopped" not in restore:
    raise SystemExit("restore failure does not state fail-closed behavior")
if re.search(r"trap\s+cleanup\s+EXIT", restore):
    raise SystemExit("unsafe unconditional restore cleanup remains")

for script in (root / "scripts/release").glob("*.sh"):
    if not os.access(script, os.X_OK):
        raise SystemExit(f"release script is not executable: {script.name}")

print("PROVIDER_INDEPENDENCE=PASS")
print("SCHEDULER_WIRING=PASS")
print("ENV_ISOLATION=PASS")
print("RESTORE_FAIL_CLOSED=PASS")
print("SCRIPT_MODES=PASS")
print("DOCKER_LOG_LIMITS=PASS")
PY
