#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command curl
prepare_shared_env_link
load_env
require_docker_access

local_only=false
if [[ "${1:-}" == "--local-only" ]]; then
  local_only=true
fi

for service in db backend scheduler frontend proxy; do
  wait_service_healthy "${service}" 120
done

info "validating migrated database, initial data and required routes"
compose exec -T backend python -m app.release.database_validation
compose exec -T backend python - <<'PY'
from app.release.initial_data import validate_initial_data
from app.release.route_validation import validate_routes

print(validate_initial_data())
print(validate_routes())
PY

info "checking backend, database health and release version"
compose exec -T backend python - "${APP_VERSION}" <<'PY'
import json
import sys
import urllib.error
import urllib.request

expected_version = sys.argv[1]
for url in (
    "http://127.0.0.1:8000/api/health",
    "http://127.0.0.1:8000/meta/health_db",
    "http://127.0.0.1:8000/openapi.json",
):
    with urllib.request.urlopen(url, timeout=10) as response:
        if response.status != 200:
            raise SystemExit(f"health failed: {url}")
        if url.endswith("openapi.json"):
            payload = json.load(response)
            actual = str(payload.get("info", {}).get("version", ""))
            if actual != expected_version:
                raise SystemExit(
                    f"backend version mismatch: expected {expected_version}, got {actual}"
                )

request = urllib.request.Request(
    "http://127.0.0.1:8000/api/tg/webhook",
    data=b"{}",
    method="POST",
    headers={"Content-Type": "application/json"},
)
try:
    urllib.request.urlopen(request, timeout=10)
except urllib.error.HTTPError as exc:
    if exc.code == 404:
        raise SystemExit("Telegram webhook route returned 404")
print(json.dumps({"webhook_route": "exists", "app_version": expected_version}))
PY

info "checking backend, scheduler and frontend image versions"
for pair in \
  "backend:${EFHC_BACKEND_IMAGE}" \
  "scheduler:${EFHC_BACKEND_IMAGE}" \
  "frontend:${EFHC_FRONTEND_IMAGE}"; do
  service="${pair%%:*}"
  expected_image="${pair#*:}"
  container_id="$(compose ps -q "${service}")"
  [[ -n "${container_id}" ]] || fatal "container missing for ${service}"
  actual_image="$(docker inspect --format '{{.Config.Image}}' "${container_id}")"
  [[ "${actual_image}" == "${expected_image}" ]] \
    || fatal "${service} image mismatch: expected ${expected_image}, got ${actual_image}"
done

info "checking frontend route"
compose exec -T frontend node - <<'JS'
fetch("http://127.0.0.1:3000/app")
  .then((response) => {
    if (!response.ok) process.exit(1);
  })
  .catch(() => process.exit(1));
JS

if [[ "${local_only}" == "false" ]]; then
  : "${APP_PUBLIC_URL:?APP_PUBLIC_URL is required}"
  : "${API_PUBLIC_URL:?API_PUBLIC_URL is required}"
  for url in \
    "${APP_PUBLIC_URL}/app" \
    "${APP_PUBLIC_URL}/panels" \
    "${APP_PUBLIC_URL}/exchange" \
    "${APP_PUBLIC_URL}/browser-shop" \
    "${API_PUBLIC_URL}/api/health" \
    "${API_PUBLIC_URL}/meta/health_db" \
    "${API_PUBLIC_URL}/openapi.json"; do
    info "checking ${url}"
    curl --fail --silent --show-error \
      --location --max-time 20 \
      --output /dev/null "${url}"
  done
fi

info "post-deployment verification passed"
