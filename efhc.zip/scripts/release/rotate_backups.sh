#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

prepare_persistent_layout
prepare_shared_env_link
load_env
retention="${BACKUP_RETENTION_DAYS:-14}"
[[ "${retention}" =~ ^[0-9]+$ ]] \
  || fatal "BACKUP_RETENTION_DAYS must be numeric"

for directory in \
  "${POSTGRES_BACKUPS_DIR}" \
  "${BUNDLES_BACKUPS_DIR}" \
  "${BACKUP_MANIFESTS_DIR}"; do
  find "${directory}" -type f -mtime "+${retention}" -delete
 done

info "persistent backup retention applied: ${retention} days"
