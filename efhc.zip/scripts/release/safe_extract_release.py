#!/usr/bin/env python3
"""Safely verify and extract an EFHC cumulative full release archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

REQUIRED_ROOT_FILES = {
    "RELEASE_METADATA.json",
    "UPDATE_POLICY.json",
    "release-manifest.json",
    "SHA256SUMS",
    "docker-compose.yml",
    ".env.example",
}
VERSION_RE = re.compile(r"v(?P<major>\d+)[._-](?P<minor>\d+)")
SIDECAR_RE = re.compile(r"(?P<hash>[0-9a-f]{64})  (?P<name>[^/\\]+)")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_version(value: str) -> tuple[int, int]:
    match = VERSION_RE.fullmatch(value)
    if not match:
        raise ValueError(f"unsupported EFHC version: {value}")
    return int(match.group("major")), int(match.group("minor"))


def archive_token(version: str) -> str:
    parse_version(version)
    return version.replace(".", "_")


def expected_archive_name(version: str) -> str:
    return f"EFHC_Bot_{archive_token(version)}_RELEASE.zip"


def verify_external_checksum(archive: Path, sidecar: Path) -> str:
    if not archive.is_file():
        raise ValueError(f"release archive is missing: {archive}")
    if not sidecar.is_file():
        raise ValueError(f"external checksum is missing: {sidecar}")
    lines = [
        line
        for line in sidecar.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(lines) != 1:
        raise ValueError(
            "external checksum must contain exactly one non-empty line"
        )
    match = SIDECAR_RE.fullmatch(lines[0])
    if not match:
        raise ValueError("invalid external checksum format")
    expected = match.group("hash")
    listed_name = match.group("name")
    if listed_name != archive.name:
        raise ValueError(
            "external checksum filename mismatch: "
            f"expected {archive.name}, got {listed_name}"
        )
    actual = sha256(archive)
    if actual != expected:
        raise ValueError("release archive SHA-256 mismatch")
    return actual


def safe_member(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if not name or name.startswith("/") or path.is_absolute():
        raise ValueError(f"unsafe absolute ZIP path: {name!r}")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"unsafe ZIP path component: {name!r}")
    return path


def member_kind(info: zipfile.ZipInfo) -> str:
    mode = (info.external_attr >> 16) & 0xFFFF
    file_type = stat.S_IFMT(mode)
    if info.is_dir() or file_type == stat.S_IFDIR:
        return "directory"
    if file_type == stat.S_IFLNK:
        raise ValueError(f"symbolic link is forbidden: {info.filename}")
    if file_type not in {0, stat.S_IFREG}:
        raise ValueError(
            f"unsafe ZIP special file is forbidden: {info.filename}"
        )
    return "file"


def validate_compatibility(
    current_version: str,
    target_version: str,
    minimum_supported_source_version: str,
) -> None:
    current = parse_version(current_version)
    target = parse_version(target_version)
    minimum = parse_version(minimum_supported_source_version)
    if target == current:
        raise ValueError(
            f"Update rejected: release {target_version} is already installed"
        )
    if target < current:
        raise ValueError(
            f"Update rejected: downgrade {current_version} -> {target_version} is forbidden"
        )
    if current < minimum:
        raise ValueError(
            f"Update rejected: current {current_version} is older than minimum "
            f"supported {minimum_supported_source_version}"
        )


def _load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"JSON root must be an object: {path.name}")
    return data


def _string_list(value: object, label: str) -> list[str]:
    if (
        not isinstance(value, list)
        or not value
        or any(not isinstance(item, str) or not item for item in value)
    ):
        raise ValueError(f"{label} must be a non-empty string list")
    result = list(value)
    if len(set(result)) != len(result):
        raise ValueError(f"{label} contains duplicates")
    return result


def _validate_contract(
    destination: Path,
    archive_name: str,
    current_version: str | None,
) -> dict[str, Any]:
    metadata = _load_json(destination / "RELEASE_METADATA.json")
    policy = _load_json(destination / "UPDATE_POLICY.json")
    manifest = _load_json(destination / "release-manifest.json")

    release_version = str(manifest.get("release_version") or "")
    parse_version(release_version)
    if metadata.get("version") != release_version:
        raise ValueError("release metadata and manifest version mismatch")
    if policy.get("release_version", policy.get("version")) != release_version:
        raise ValueError("update policy and manifest version mismatch")
    if archive_name != expected_archive_name(release_version):
        raise ValueError(
            "release archive name does not match manifest: "
            f"expected {expected_archive_name(release_version)}, got {archive_name}"
        )
    if policy.get("archive_mode") != "FULL_RELEASE_ARCHIVE":
        raise ValueError("only FULL_RELEASE_ARCHIVE updates are supported")
    update_policy = manifest.get("update_policy")
    migration_policy = manifest.get("database_migration_policy")
    rollback_policy = manifest.get("rollback_database_policy")
    allowed_contracts = {
        (
            "compatible_source_range",
            "cumulative_forward",
            "no_automatic_restore",
        ),
        (
            "pre_release_schema_freeze",
            "single_initial_release_schema",
            "restore_pre_squash_snapshot",
        ),
    }
    if (update_policy, migration_policy, rollback_policy) not in (
        allowed_contracts
    ):
        raise ValueError("unsupported release update/migration contract")

    minimum_source = str(
        manifest.get("minimum_supported_source_version") or ""
    )
    parse_version(minimum_source)
    supported_revisions = _string_list(
        manifest.get("supported_database_revisions"),
        "supported_database_revisions",
    )
    target_revision = str(manifest.get("target_database_revision") or "")
    if not target_revision:
        raise ValueError("target_database_revision is required")
    if target_revision not in supported_revisions:
        raise ValueError(
            "target_database_revision must be included in supported_database_revisions"
        )

    policy_pairs = {
        "update_policy": manifest.get("update_policy"),
        "minimum_supported_source_version": minimum_source,
        "supported_database_revisions": supported_revisions,
        "target_database_revision": target_revision,
        "database_migration_policy": manifest.get("database_migration_policy"),
        "rollback_database_policy": manifest.get("rollback_database_policy"),
    }
    for key, manifest_value in policy_pairs.items():
        if policy.get(key) != manifest_value:
            raise ValueError(f"update policy and manifest differ for {key}")

    if current_version is not None:
        validate_compatibility(
            current_version,
            release_version,
            minimum_source,
        )

    rollback = manifest.get("rollback_compatibility")
    if not isinstance(rollback, dict):
        raise ValueError("rollback_compatibility must be an object")
    app_rollback = rollback.get("application_rollback_supported")
    restore_required = rollback.get("database_restore_required")
    if not isinstance(app_rollback, bool) or not isinstance(
        restore_required, bool
    ):
        raise ValueError("rollback compatibility flags must be boolean")
    if app_rollback and restore_required:
        raise ValueError(
            "application rollback cannot be automatic when database restore is required"
        )

    return {
        "archive": archive_name,
        "version": release_version,
        "release_version": release_version,
        "source_head": metadata.get("source_head"),
        "clean_install_supported": bool(
            manifest.get("clean_install_supported", False)
        ),
        "update_policy": manifest.get("update_policy"),
        "minimum_supported_source_version": minimum_source,
        "supported_database_revisions": supported_revisions,
        "target_database_revision": target_revision,
        "database_migration_policy": manifest.get(
            "database_migration_policy"
        ),
        "database_migration_class": manifest.get(
            "database_migration_class"
        ),
        "rollback_database_policy": manifest.get(
            "rollback_database_policy"
        ),
        "application_rollback_supported": app_rollback,
        "database_restore_required": restore_required,
        "rollback_reason": str(rollback.get("reason") or ""),
    }


def extract(
    archive: Path,
    destination: Path,
    *,
    current_version: str | None = None,
) -> dict[str, object]:
    if destination.exists() and any(destination.iterdir()):
        raise ValueError(f"destination is not empty: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    seen_names: set[str] = set()
    seen_casefold: set[str] = set()

    with zipfile.ZipFile(archive) as bundle:
        bad = bundle.testzip()
        if bad is not None:
            raise ValueError(f"ZIP CRC failure: {bad}")
        for info in bundle.infolist():
            rel = safe_member(info.filename)
            normalized = rel.as_posix()
            if normalized in seen_names:
                raise ValueError(f"duplicate ZIP member: {normalized}")
            folded = normalized.casefold()
            if folded in seen_casefold:
                raise ValueError(f"case-colliding ZIP member: {normalized}")
            seen_names.add(normalized)
            seen_casefold.add(folded)
            kind = member_kind(info)
            target = destination.joinpath(*rel.parts)
            if kind == "directory":
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(info) as source, target.open("xb") as output:
                shutil.copyfileobj(source, output)
            mode = (info.external_attr >> 16) & 0o777
            os.chmod(target, mode or 0o644)

    found_root = {
        path.name for path in destination.iterdir() if path.is_file()
    }
    missing_root = sorted(REQUIRED_ROOT_FILES - found_root)
    if missing_root:
        raise ValueError("missing release root files: " + ", ".join(missing_root))

    checksums: dict[str, str] = {}
    checksum_file = destination / "SHA256SUMS"
    for number, raw in enumerate(
        checksum_file.read_text(encoding="utf-8").splitlines(), start=1
    ):
        if not raw.strip():
            continue
        try:
            expected, rel = raw.split("  ", 1)
        except ValueError as exc:
            raise ValueError(f"invalid SHA256SUMS line {number}") from exc
        if not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError(f"invalid SHA256SUMS hash at line {number}")
        safe_member(rel)
        if rel in checksums:
            raise ValueError(f"duplicate checksum entry: {rel}")
        checksums[rel] = expected

    actual_files = {
        path.relative_to(destination).as_posix()
        for path in destination.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS"
    }
    listed_files = set(checksums)
    if actual_files != listed_files:
        unlisted = sorted(actual_files - listed_files)
        missing = sorted(listed_files - actual_files)
        raise ValueError(
            "SHA256SUMS inventory mismatch; "
            f"unlisted={unlisted[:10]} missing={missing[:10]}"
        )
    for rel, expected in checksums.items():
        actual = sha256(destination / rel)
        if actual != expected:
            raise ValueError(f"checksum mismatch: {rel}")

    summary = _validate_contract(destination, archive.name, current_version)
    summary["file_count"] = len(actual_files) + 1
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--checksum", type=Path)
    parser.add_argument("--current-version")
    args = parser.parse_args()
    try:
        archive = args.archive.resolve()
        if args.checksum is not None:
            external_hash = verify_external_checksum(
                archive, args.checksum.resolve()
            )
        else:
            external_hash = None
        result = extract(
            archive,
            args.destination.resolve(),
            current_version=args.current_version,
        )
        result["archive_sha256"] = external_hash or sha256(archive)
    except (
        OSError,
        ValueError,
        zipfile.BadZipFile,
        json.JSONDecodeError,
    ) as exc:
        print(f"EFHC release extraction failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
