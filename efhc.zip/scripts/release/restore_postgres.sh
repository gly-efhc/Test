#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command sha256sum
require_docker_access
load_env

require_pg_identifier "${POSTGRES_USER}" "POSTGRES_USER"
require_pg_identifier "${POSTGRES_DB}" "POSTGRES_DB"

backup="${1:-}"
confirmation="${2:-}"
[[ -n "${backup}" ]] \
  || fatal "usage: restore_postgres.sh FILE --confirm"
[[ "${confirmation}" == "--confirm" ]] \
  || fatal "restore requires explicit --confirm"
require_file "${backup}"
require_file "${backup}.sha256"
verify_checksum "${backup}"

restore_completed=false
on_exit() {
  local code=$?
  if [[ "${restore_completed}" != "true" ]]; then
    warn "restore failed; backend, scheduler, frontend and proxy remain stopped"
    compose stop proxy frontend scheduler backend >/dev/null 2>&1 || true
  fi
  exit "${code}"
}
trap on_exit EXIT

info "stopping application services before restore"
compose stop proxy frontend scheduler backend

info "ensuring PostgreSQL is healthy"
compose up -d db
wait_service_healthy db 180

info "terminating database sessions"
compose exec -T db psql \
  --username "${POSTGRES_USER}" \
  --dbname postgres \
  --set ON_ERROR_STOP=1 \
  --set db_name="${POSTGRES_DB}" \
  --command "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = :'db_name' AND pid <> pg_backend_pid();"

info "recreating target database"
compose exec -T db dropdb \
  --username "${POSTGRES_USER}" \
  --if-exists "${POSTGRES_DB}"
compose exec -T db createdb \
  --username "${POSTGRES_USER}" \
  "${POSTGRES_DB}"

info "restoring PostgreSQL archive"
compose exec -T db pg_restore \
  --username "${POSTGRES_USER}" \
  --dbname "${POSTGRES_DB}" \
  --exit-on-error \
  --no-owner \
  --no-acl < "${backup}"

run_migrations_once

info "starting backend and scheduler"
compose up -d --no-deps backend scheduler
wait_service_healthy backend 240
wait_service_healthy scheduler 240

info "starting frontend"
compose up -d --no-deps frontend
wait_service_healthy frontend 240

info "starting HTTPS proxy"
compose up -d --no-deps proxy
wait_service_healthy proxy 120

"${SCRIPT_DIR}/post_move_verify.sh" --local-only
restore_completed=true
trap - EXIT
info "restore completed"
