#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

need_command python3
load_env

: "${APP_PUBLIC_URL:?APP_PUBLIC_URL is required}"

python3 - \
  "${RELEASE_ROOT}/frontend/public/tonconnect-manifest.json" \
  "${APP_PUBLIC_URL}" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from urllib.parse import urlparse

path = Path(sys.argv[1])
public_url = sys.argv[2].rstrip("/")
parsed = urlparse(public_url)
if parsed.scheme != "https" or not parsed.netloc:
    raise SystemExit("APP_PUBLIC_URL must be an HTTPS origin")
manifest = {
    "url": public_url,
    "name": "EFHC Bot",
    "iconUrl": f"{public_url}/icon.png",
    "termsOfUseUrl": (
        f"{public_url}/web-profile?legal=terms"
    ),
    "privacyPolicyUrl": (
        f"{public_url}/web-profile?legal=privacy"
    ),
}
path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
PY

info "public TonConnect manifest rendered for ${APP_PUBLIC_URL}"
