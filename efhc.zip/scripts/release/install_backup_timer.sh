#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

if [[ "${EUID}" -ne 0 ]]; then
  fatal "run as root: sudo ./scripts/release/install_backup_timer.sh"
fi

prepare_persistent_layout
service=/etc/systemd/system/efhc-backup.service
timer=/etc/systemd/system/efhc-backup.timer

cat > "${service}" <<'EOF_SERVICE'
[Unit]
Description=EFHC scheduled production backup
Requires=docker.service
After=docker.service network-online.target
Wants=network-online.target

[Service]
Type=oneshot
WorkingDirectory=/opt/efhc/current
ExecStart=/opt/efhc/current/scripts/release/run_scheduled_backup.sh
User=root
Group=root
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/efhc/backups
ReadWritePaths=/opt/efhc/shared
ReadWritePaths=/opt/efhc/packages
EOF_SERVICE

cat > "${timer}" <<'EOF_TIMER'
[Unit]
Description=Run EFHC production backup daily

[Timer]
OnCalendar=daily
Persistent=true
RandomizedDelaySec=900
Unit=efhc-backup.service

[Install]
WantedBy=timers.target
EOF_TIMER

systemctl daemon-reload
systemctl enable --now efhc-backup.timer
systemctl restart efhc-backup.timer
systemctl status efhc-backup.timer --no-pager
systemctl list-timers efhc-backup.timer --no-pager
info "daily backup timer installed through /opt/efhc/current"
