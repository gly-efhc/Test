#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib.sh
source "${SCRIPT_DIR}/lib.sh"

keep=3
dry_run=false
confirmed=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --keep)
      [[ $# -ge 2 ]] || fatal "--keep requires a number"
      keep="$2"
      shift 2
      ;;
    --dry-run)
      dry_run=true
      shift
      ;;
    --confirm)
      confirmed=true
      shift
      ;;
    *) fatal "unknown cleanup option: $1" ;;
  esac
done

[[ "${keep}" =~ ^[0-9]+$ && "${keep}" -ge 2 ]] \
  || fatal "--keep must be an integer of at least 2"
prepare_persistent_layout

current_target="$(readlink -f -- "${CURRENT_LINK}" 2>/dev/null || true)"
previous_target="$(readlink -f -- "${PREVIOUS_LINK}" 2>/dev/null || true)"

mapfile -t releases < <(
  find "${RELEASES_DIR}" -mindepth 1 -maxdepth 1 -type d \
    -name 'v[0-9]*.[0-9]*' -printf '%f\n' \
    | sort -V -r
)

protected=()
[[ -n "${current_target}" ]] && protected+=("${current_target}")
[[ -n "${previous_target}" ]] && protected+=("${previous_target}")

keep_paths=()
for release in "${releases[@]}"; do
  path="${RELEASES_DIR}/${release}"
  if [[ "${path}" == "${current_target}" || "${path}" == "${previous_target}" ]]; then
    keep_paths+=("${path}")
  fi
done
for release in "${releases[@]}"; do
  path="${RELEASES_DIR}/${release}"
  if [[ " ${keep_paths[*]} " == *" ${path} "* ]]; then
    continue
  fi
  if [[ ${#keep_paths[@]} -lt ${keep} ]]; then
    keep_paths+=("${path}")
  fi
done

delete_paths=()
for release in "${releases[@]}"; do
  path="${RELEASES_DIR}/${release}"
  if [[ " ${keep_paths[*]} " != *" ${path} "* ]]; then
    delete_paths+=("${path}")
  fi
done

printf 'EFHC release cleanup plan\n'
printf 'keep=%s\n' "${keep}"
printf 'protected current=%s\n' "${current_target:-none}"
printf 'protected previous=%s\n' "${previous_target:-none}"
if [[ ${#delete_paths[@]} -eq 0 ]]; then
  printf 'delete: none\n'
  exit 0
fi
for path in "${delete_paths[@]}"; do
  printf 'delete: %s\n' "${path}"
done

if [[ "${dry_run}" == "true" ]]; then
  info "dry-run complete; nothing deleted"
  exit 0
fi
[[ "${confirmed}" == "true" ]] \
  || fatal "actual deletion requires --confirm; use --dry-run first"

for path in "${delete_paths[@]}"; do
  [[ "${path}" != "${current_target}" && "${path}" != "${previous_target}" ]] \
    || fatal "refusing to delete protected release: ${path}"
  rm -rf --one-file-system "${path}"
done
info "old release cleanup completed; packages and backups were untouched"
