<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / SUPERSEDED EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **HISTORICAL / SUPERSEDED.** Этот план или аудит сохранён для истории.
> Действующий закон: `global_id` — главный персональный идентификатор и owner;
> `tg_id` — только Telegram provider subject. Старые стадии `user_id` не являются
> текущим контрактом.

# Аудит UserId и tg_id — v171.98

Цикл: `1601`.
Исходный архив: `EFHC_Bot_v171_97.zip`.
Целевой архив: `EFHC_Bot_v171_98.zip`.

## Актуальный пересчёт exact HEAD

- строк машинной матрицы: `5477`;
- файлов с употреблениями: `688`;
- реальных доменных зависимостей: `2054`;
- ORM-полей семейства `tg_id`: `32`;
- сервисных сигнатур: `336`;
- FastAPI routes: `143`;
- routes с `tg_id`: `65`.

Рост относительно отчёта v171.97 относится к новым документам и
причинному тесту цикла 1601. Число реальных доменных зависимостей,
ORM-полей, сигнатур и routes с `tg_id` не увеличилось.

## Архитектурный вердикт

`users.id` остаётся runtime primary key. `users.user_id` остаётся
nullable EXPAND-полем. Historical backfill, runtime read switch и
финансовый ownership switch не выполнены.

## PostgreSQL

Реальная PostgreSQL reconciliation заблокирована средой. Нельзя
утверждать отсутствие коллизий, orphan-ссылок либо финансового
расхождения на фактической базе.

## Provenance

Генератор аудита теперь получает exact `source_head`, `baseline_head`
и цикл явно. Жёсткая подмена метаданных старым циклом устранена.
