# EFHC Bot: канон Alembic после schema freeze

## Активная release-схема

С цикла `1632` active Alembic lineage содержит ровно одну revision:

```text
backend/migrations/versions/0001_initial_release_schema.py
revision = "0001"
down_revision = None
```

Исторические pre-release revisions `0002–0013` удалены из active
migration layer. Их задачи объединены в initial schema:

- финальная physical колонка `efhc_core.users.global_id`;
- sequence `efhc_core.users_global_id_seq`;
- все owner FK на `users(global_id)`;
- auth и identity tables;
- runtime control, compatibility triggers и telemetry;
- текущие ограничения диапазона, уникальности и финансовой точности.

## Причина squash

До первого production release промежуточные миграции не являются
публичной историей обновлений. После physical rename начальная migration
и последующие revisions стали описывать разные физические схемы. Поэтому
каноническое решение — создать одну непротиворечивую initial schema, а не
латать каждую историческую revision.

## Обновление pre-release баз

База со старой revision `0013` не обновляется поверх новой цепочки.
Разрешены только:

1. clean database → `alembic upgrade head`;
2. восстановление подготовленного снимка в clean schema;
3. проверка counts, ownership, sequence и денежных итогов после restore.

Production data ещё отсутствует, поэтому такой reset является штатной
pre-release операцией, а не потерей пользовательских данных.

## Следующие миграции

После production release любое новое изменение схемы создаётся отдельной
revision `0002` с parent `0001`. Изменять qualified `0001` после release
запрещено.

## Обязательные инварианты

- PostgreSQL-only;
- `global_id` остаётся account owner;
- `tg_id` и wallet address не становятся owner;
- финансовые значения и precision не переписываются;
- monetary discrepancy должна оставаться `0.00000000`;
- offline SQL не подменяет real PostgreSQL qualification;
- universal GitHub CI проверяет clean upgrade, runtime и restore.
