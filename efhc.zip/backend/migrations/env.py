# -*- coding: utf-8 -*-
# backend/migrations/env.py
# =====================================================================
# Назначение кода:
# Alembic-окружение для EFHC Bot с поддержкой Neon (PostgreSQL, SSL) и
# единой схемой (DB_SCHEMA_CORE). Работает в offline/online.
# Выставляет search_path и прогоняет миграции.
# search_path, совместим с async-приложением.
# Для миграций используем sync-движок.
#
# Канон / инварианты:
# • База — PostgreSQL (Neon), SSL обязателен (?sslmode=require в URL).
# • Все объекты — в единой схеме DB_SCHEMA_CORE.
#   По умолчанию: efhc_core.
# • Миграции не должны быть деструктивными без явной необходимости.
#
# ИИ-защиты:
# • Автоматическая нормализация URL: если в окружении только async URL
# (postgresql+asyncpg://...), Alembic получит sync-эквивалент
# (postgresql://...).
# • Явная установка search_path на схему из .env, чтобы миграции не
# «расползались».
# • Опциональная установка statement_timeout через окружение.
#
# Запреты:
# • Без жёсткого «затирания» схем/таблиц. Инициализацию схемы делаем в
# 0001_init.
# =====================================================================
from __future__ import annotations
import os


def _get_database_url() -> str:
    url = os.environ.get("PSYCOPG_URL")
    if url:
        return url
    url = os.environ.get("SYNC_DATABASE_URL")
    if url:
        return url
    url = os.environ.get("DATABASE_URL")
    if url:
        return url
    raise RuntimeError("DB URL missing")
import re
import logging
from urllib.parse import urlparse
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool, text
from alembic import context
# Конфигурация Alembic
config = context.config
# Логи Alembic
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
logger = logging.getLogger("alembic.env")
# --------------------------------------------------------------------
# Параметры окружения / схема / таймаут
# --------------------------------------------------------------------
DB_SCHEMA_CORE = os.getenv("DB_SCHEMA_CORE", "efhc_core")
DB_SCHEMA_ADMIN = os.getenv("DB_SCHEMA_ADMIN", "efhc_admin")
# Предпочитаем SYNC_DATABASE_URL для Alembic.
# Если его нет, используем DATABASE_URL.
SYNC_DATABASE_URL = os.getenv("SYNC_DATABASE_URL")
DATABASE_URL = os.getenv("DATABASE_URL")
if not SYNC_DATABASE_URL:
    if not DATABASE_URL:
        raise RuntimeError(
            "Нужно задать SYNC_DATABASE_URL или DATABASE_URL."
        )
    # Преобразуем async URL в sync.
    # postgresql+asyncpg:// → postgresql://
    SYNC_DATABASE_URL = re.sub(
        r"^postgresql\+asyncpg://",
        "postgresql://",
        DATABASE_URL,
    )
# Neon требует SSL: добавим ?sslmode=require, если его нет
# Neon требует SSL, но локальный CI Postgres обычно без SSL.
# Добавляем sslmode=require ТОЛЬКО если хост не localhost/127.0.0.1/::1 и параметра ещё нет.
if (
    SYNC_DATABASE_URL
    and "sslmode=" not in SYNC_DATABASE_URL
):
    _p = urlparse(SYNC_DATABASE_URL)
    _host = (_p.hostname or "").lower()
    if _host not in {"localhost", "127.0.0.1", "::1"}:
        join = "&" if "?" in SYNC_DATABASE_URL else "?"
        SYNC_DATABASE_URL = f"{SYNC_DATABASE_URL}{join}sslmode=require"
# Statement timeout (мс) опционально
PG_STATEMENT_TIMEOUT_MS = os.getenv("PG_STATEMENT_TIMEOUT_MS")
if PG_STATEMENT_TIMEOUT_MS:
    try:
        int(PG_STATEMENT_TIMEOUT_MS)
    except ValueError:
        raise RuntimeError(
            "PG_STATEMENT_TIMEOUT_MS: целое число (мс)")
# Прокидываем URL в конфиг Alembic
config.set_main_option("sqlalchemy.url", SYNC_DATABASE_URL)
# --------------------------------------------------------------------
# target_metadata — можно подключить Meta из моделей при необходимости
# автогенерации
# Мы оставляем None и пишем миграции явными скриптами (канон проекта).
# --------------------------------------------------------------------
target_metadata = None


def _set_search_path(connection) -> None:
    """
    Выставляет search_path на efhc_core и efhc_admin.
    """
    connection.execute(
        text(f"SET search_path TO {DB_SCHEMA_CORE}, {DB_SCHEMA_ADMIN}")
    )
    if PG_STATEMENT_TIMEOUT_MS:
        connection.execute(
            text(
                f"SET statement_timeout TO "
                f"{int(PG_STATEMENT_TIMEOUT_MS)}"
            )
        )


def run_migrations_offline() -> None:
    """
    Offline-режим: Alembic генерирует SQL без подключения к БД.
    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
        version_table_schema=DB_SCHEMA_CORE,
        include_schemas=True,
        render_as_batch=False,
    )
    with context.begin_transaction():
        # В offline search_path задаётся в 0001_init.
        # DDL: CREATE SCHEMA IF NOT EXISTS ...
        # NOT EXISTS
        context.run_migrations()
def run_migrations_online() -> None:
    """
    Online-режим: подключение к БД.
    Установка search_path и прогон миграций.
    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
        future=True,
    )
    with connectable.connect() as connection:
        # Важно: создаём все используемые схемы, если их нет (безопасно)
        # CI/0001_init используют Base.metadata.create_all, где часть таблиц
        for _schema in {DB_SCHEMA_CORE, DB_SCHEMA_ADMIN}:
            connection.execute(text(f"CREATE SCHEMA IF NOT EXISTS {_schema}"))
        _set_search_path(connection)
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
            version_table_schema=DB_SCHEMA_CORE,
            include_schemas=True,
            render_as_batch=False,
        )
        with context.begin_transaction():

            context.run_migrations()
                # SANITY: миграция обязана создать ключевые таблицы в канонических схемах
        users_ok = connection.execute(
            text("SELECT to_regclass('efhc_core.users')")
        ).scalar()
        wr_ok = connection.execute(
            text("SELECT to_regclass('efhc_core.withdraw_requests')")
        ).scalar()
        sale_ok = connection.execute(
            text("SELECT to_regclass('efhc_admin.efhc_sale_packages')")
        ).scalar()
        if users_ok is None or wr_ok is None or sale_ok is None:
            raise RuntimeError(
                "Alembic sanity failed: required tables missing "
                f"users={users_ok} withdraw_requests={wr_ok} efhc_sale_packages={sale_ok}"
            )


# Точка входа Alembic
if context.is_offline_mode():
    logger.info("EFHC Alembic offline mode; schemas=%s,%s", DB_SCHEMA_CORE, DB_SCHEMA_ADMIN)
    run_migrations_offline()
else:
    logger.info("EFHC Alembic online mode; schemas=%s,%s", DB_SCHEMA_CORE, DB_SCHEMA_ADMIN)
    run_migrations_online()