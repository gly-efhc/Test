# -*- coding: utf-8 -*-
# backend/migrations/env.py
# =====================================================================
# Назначение кода:
# Alembic-окружение для EFHC Bot (Postgres-only).
# Канон схем: efhc_core и efhc_admin.
# Online: создаёт схемы (если нет), ставит search_path.
# Затем гоняет миграции.
# Строго Postgres-only.
# Offline: генерирует SQL без подключения.
#
# Канон / инварианты:
# • База — PostgreSQL.
# • Объекты лежат в двух схемах:
#   DB_SCHEMA_CORE (по умолчанию efhc_core)
#   DB_SCHEMA_ADMIN (по умолчанию efhc_admin)
# • Миграции не должны быть деструктивными без явной необходимости.
#
# ИИ-защиты:
# • URL берём из окружения (Postgres-only).
# • Явная установка search_path на схему из .env, чтобы миграции не
# «расползались».
# • Опциональная установка statement_timeout через окружение.
#
# Запреты:
# • Без жёсткого «затирания» схем/таблиц. Инициализацию схемы делаем в
# 0001_init.
# =====================================================================
from __future__ import annotations

import logging
import os
from urllib.parse import urlparse
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool, text
from alembic import context


def _get_database_url() -> str:
    url = os.environ.get("PSYCOPG_URL")
    if url:
        return url
    url = os.environ.get("SYNC_DATABASE_URL")
    if url:
        return url
    url = os.environ.get("DATABASE_URL")
    if url:
        return url
    raise RuntimeError(
        "DB URL missing: set PSYCOPG_URL or SYNC_DATABASE_URL "
        "or DATABASE_URL"
    )


DB_URL = _get_database_url()
# Конфигурация Alembic
config = context.config
# Логи Alembic
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
logger = logging.getLogger("alembic.env")
# --------------------------------------------------------------------
# Параметры окружения / схема / таймаут
# --------------------------------------------------------------------
DB_SCHEMA_CORE = os.getenv("DB_SCHEMA_CORE", "efhc_core")
DB_SCHEMA_ADMIN = os.getenv("DB_SCHEMA_ADMIN", "efhc_admin")
# Для Neon/SSL: добавим sslmode=require, если параметра нет.
# В CI с localhost SSL обычно не нужен.
if "sslmode=" not in DB_URL:
    _p = urlparse(DB_URL)
    _host = (_p.hostname or "").lower()
    if _host not in {"localhost", "127.0.0.1", "::1"}:
        _join = "&" if "?" in DB_URL else "?"
        DB_URL = f"{DB_URL}{_join}sslmode=require"
# Statement timeout (мс) опционально
PG_STATEMENT_TIMEOUT_MS = os.getenv("PG_STATEMENT_TIMEOUT_MS")
if PG_STATEMENT_TIMEOUT_MS:
    try:
        int(PG_STATEMENT_TIMEOUT_MS)
    except ValueError:
        raise RuntimeError(
            "PG_STATEMENT_TIMEOUT_MS: целое число (мс)")
# Прокидываем URL в конфиг Alembic
config.set_main_option("sqlalchemy.url", DB_URL)
# --------------------------------------------------------------------
# target_metadata — можно подключить Meta из моделей при необходимости
# автогенерации
# Мы оставляем None и пишем миграции явными скриптами (канон проекта).
# --------------------------------------------------------------------
target_metadata = None


def _apply_schema_translate_map(connection):
    """Привязать объекты без схемы к efhc_core (Postgres-only)."""
    mp = {None: DB_SCHEMA_CORE}
    return connection.execution_options(schema_translate_map=mp)

def _set_search_path(connection) -> None:
    """
    Выставляет search_path на efhc_core и efhc_admin.
    """
    connection.execute(
        text(f"SET search_path TO {DB_SCHEMA_CORE}, {DB_SCHEMA_ADMIN}")
    )
    if PG_STATEMENT_TIMEOUT_MS:
        connection.execute(
            text(
                f"SET statement_timeout TO "
                f"{int(PG_STATEMENT_TIMEOUT_MS)}"
            )
        )

def run_migrations_offline() -> None:
    """
    Offline-режим: Alembic генерирует SQL без подключения к БД.
    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
        version_table_schema=DB_SCHEMA_CORE,
        include_schemas=True,
        render_as_batch=False,
    )
    with context.begin_transaction():
        # В offline search_path задаётся в 0001_init.
        # DDL: CREATE SCHEMA IF NOT EXISTS ...
        # NOT EXISTS
        context.run_migrations()
def run_migrations_online() -> None:
    """
    Online-режим: подключение к БД.
    Установка search_path и прогон миграций.
    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
        future=True,
    )
    with connectable.connect() as connection:
        # Важно: создаём все используемые схемы, если их нет (безопасно)
        # CI/0001_init используют Base.metadata.create_all, где таблицы
        for _schema in {DB_SCHEMA_CORE, DB_SCHEMA_ADMIN}:
            sql = f"CREATE SCHEMA IF NOT EXISTS {_schema}"
            connection.execute(text(sql))
        _set_search_path(connection)

        # Важно: таблицы без явной схемы должны идти в efhc_core.
        connection = _apply_schema_translate_map(connection)

        # Диагностика в CI: какая БД/хост видит Alembic.
        try:
            db = connection.execute(text("SELECT current_database()"))
            db = db.scalar()
            sp = connection.execute(text("SHOW search_path")).scalar()
            logger.info("DB diag: db=%s search_path=%s", db, sp)
        except Exception:
            logger.info("DB diag: unavailable")
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
            version_table_schema=DB_SCHEMA_CORE,
            include_schemas=True,
            render_as_batch=False,
        )
        with context.begin_transaction():
            context.run_migrations()

# Точка входа Alembic
if context.is_offline_mode():
    logger.info(
        "EFHC Alembic offline; schemas=%s,%s",
        DB_SCHEMA_CORE,
        DB_SCHEMA_ADMIN,
    )
    run_migrations_offline()
else:
    logger.info(
        "EFHC Alembic online; schemas=%s,%s",
        DB_SCHEMA_CORE,
        DB_SCHEMA_ADMIN,
    )
    run_migrations_online()