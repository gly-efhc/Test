"""wallet_connect_idempotency (efhc_core)

Idempotent creation of efhc_core.wallet_connect_idempotency table, unique constraint and indexes.

"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy import text

# Alembic identifiers
revision = "0002_wallet_connect_idempotency"
down_revision = "0001"
branch_labels = None
depends_on = None


SCHEMA_CORE = "efhc_core"
TABLE = "wallet_connect_idempotency"
UQ_NAME = "uq_wallet_connect_idempotency_tg_id_idempotency_key"
IX_TG_ID = "ix_wallet_connect_idempotency_tg_id"
IX_WALLET_ID = "ix_wallet_connect_idempotency_wallet_id"


def _schema_exists(conn, schema: str) -> bool:
    q = text(
        "SELECT 1 FROM information_schema.schemata WHERE schema_name = :schema LIMIT 1"
    )
    return conn.execute(q, {"schema": schema}).scalar() is not None


def _table_exists(conn, schema: str, table: str) -> bool:
    q = text(
        "SELECT 1 FROM information_schema.tables "
        "WHERE table_schema = :schema AND table_name = :table LIMIT 1"
    )
    return conn.execute(q, {"schema": schema, "table": table}).scalar() is not None


def _constraint_exists(conn, schema: str, table: str, constraint_name: str) -> bool:
    q = text(
        "SELECT 1 FROM information_schema.table_constraints "
        "WHERE table_schema = :schema AND table_name = :table AND constraint_name = :name "
        "LIMIT 1"
    )
    return conn.execute(q, {"schema": schema, "table": table, "name": constraint_name}).scalar() is not None


def _index_exists(conn, schema: str, index_name: str) -> bool:
    q = text(
        "SELECT 1 "
        "FROM pg_catalog.pg_class c "
        "JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace "
        "WHERE c.relkind = 'i' AND n.nspname = :schema AND c.relname = :name "
        "LIMIT 1"
    )
    return conn.execute(q, {"schema": schema, "name": index_name}).scalar() is not None


def upgrade() -> None:
    conn = op.get_bind()

    # Ensure schema exists (idempotent)
    if not _schema_exists(conn, SCHEMA_CORE):
        op.execute(sa.text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_CORE}"'))

    # Ensure table exists (idempotent)
    if not _table_exists(conn, SCHEMA_CORE, TABLE):
        op.create_table(
            TABLE,
            sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger(), nullable=False),
            sa.Column("idempotency_key", sa.String(length=128), nullable=False),
            sa.Column("wallet_id", sa.BigInteger(), nullable=True),
            sa.Column("wallet_address", sa.String(length=128), nullable=True),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            schema=SCHEMA_CORE,
        )

    # Unique constraint (idempotent)
    if not _constraint_exists(conn, SCHEMA_CORE, TABLE, UQ_NAME):
        op.create_unique_constraint(
            UQ_NAME,
            TABLE,
            ["tg_id", "idempotency_key"],
            schema=SCHEMA_CORE,
        )

    # Indexes (idempotent)
    if not _index_exists(conn, SCHEMA_CORE, IX_TG_ID):
        op.create_index(
            IX_TG_ID,
            TABLE,
            ["tg_id"],
            unique=False,
            schema=SCHEMA_CORE,
        )

    if not _index_exists(conn, SCHEMA_CORE, IX_WALLET_ID):
        op.create_index(
            IX_WALLET_ID,
            TABLE,
            ["wallet_id"],
            unique=False,
            schema=SCHEMA_CORE,
        )


def downgrade() -> None:
    # No destructive downgrade in CANON.
    pass
