"""Подготовка атомарного full cutover на canonical global_id.

Revision ID: 0002
Revises: 0001

Миграция не переключает production-флаги. Она только:
- разрешает управляемое legacy_authoritative=FALSE после preflight;
- сохраняет dual-write/shadow-read инварианты;
- добавляет canonical owner achievements.global_id;
- снимает legacy-authoritative блокировку с трёх owner triggers,
  не ослабляя orphan/conflict validation.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import context, op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

CORE = "efhc_core"

OWNER_TRIGGER_SPECS: tuple[tuple[str, str], ...] = (
    ("shop_orders", "efhc_1628_shop_order_owner"),
    ("user_skins", "efhc_1628_user_skin_owner"),
    ("user_cosmetics", "efhc_1628_user_cosmetics_owner"),
)


def _constraint_exists(
    conn: sa.Connection,
    *,
    schema: str,
    table: str,
    constraint: str,
) -> bool:
    return bool(
        conn.execute(
            sa.text(
                """
                SELECT 1
                FROM information_schema.table_constraints
                WHERE constraint_schema = :schema
                  AND table_name = :table
                  AND constraint_name = :constraint
                LIMIT 1
                """
            ),
            {
                "schema": schema,
                "table": table,
                "constraint": constraint,
            },
        ).scalar_one_or_none()
    )


def _column_exists(
    conn: sa.Connection,
    *,
    schema: str,
    table: str,
    column: str,
) -> bool:
    return bool(
        conn.execute(
            sa.text(
                """
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = :schema
                  AND table_name = :table
                  AND column_name = :column
                LIMIT 1
                """
            ),
            {"schema": schema, "table": table, "column": column},
        ).scalar_one_or_none()
    )


def _index_exists(conn: sa.Connection, *, schema: str, index: str) -> bool:
    return bool(
        conn.execute(
            sa.text(
                """
                SELECT 1
                FROM pg_indexes
                WHERE schemaname = :schema
                  AND indexname = :index
                LIMIT 1
                """
            ),
            {"schema": schema, "index": index},
        ).scalar_one_or_none()
    )



def _prepare_offline_current_release(conn: sa.Connection) -> None:
    """Сформировать детерминированный offline SQL поверх текущего 0001.

    Offline Alembic не возвращает результаты catalog SELECT. Текущий
    объединённый 0001 уже создаёт канонические колонки, индексы и внешние
    ключи из ORM metadata, поэтому 0002 генерирует только backfill, NOT NULL
    и изменения control/trigger.
    """
    conn.execute(
        sa.text(
            f"""
            UPDATE {CORE}.achievements AS a
               SET global_id = u.global_id
              FROM {CORE}.users AS u
             WHERE a.global_id IS NULL
               AND a.tg_id = u.tg_id
            """
        )
    )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.achievements "
            "ALTER COLUMN tg_id DROP NOT NULL"
        )
    )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.achievements "
            "ALTER COLUMN global_id SET NOT NULL"
        )
    )
    conn.execute(
        sa.text(
            f"""
            UPDATE {CORE}.referral_codes AS rc
               SET inviter_global_id = u.global_id
              FROM {CORE}.users AS u
             WHERE rc.inviter_global_id IS NULL
               AND rc.inviter_tg_id = u.tg_id
            """
        )
    )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.referral_codes "
            "ALTER COLUMN inviter_tg_id DROP NOT NULL"
        )
    )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.referral_codes "
            "ALTER COLUMN inviter_global_id SET NOT NULL"
        )
    )

def _owner_function_sql(table: str, function: str) -> str:
    relation = f"{CORE}.{table}"
    return f"""
CREATE OR REPLACE FUNCTION {CORE}.{function}()
RETURNS trigger
LANGUAGE plpgsql
AS $efhc_cutover_owner$
DECLARE
    dual_enabled boolean;
    resolved_global_id bigint;
BEGIN
    SELECT dual_write_enabled
      INTO dual_enabled
      FROM {CORE}.identity_migration_control
     WHERE singleton_id = 1;

    IF coalesce(dual_enabled, false) IS NOT TRUE THEN
        RAISE EXCEPTION '0002: dual_write is not ready';
    END IF;

    IF NEW.tg_id IS NOT NULL THEN
        SELECT global_id
          INTO resolved_global_id
          FROM {CORE}.users
         WHERE tg_id = NEW.tg_id;

        IF resolved_global_id IS NULL THEN
            RAISE EXCEPTION '0002: orphan owner {relation}.tg_id';
        END IF;

        IF NEW.global_id IS NOT NULL
           AND NEW.global_id <> resolved_global_id THEN
            RAISE EXCEPTION
                '0002: owner conflict {relation}.global_id';
        END IF;

        NEW.global_id := resolved_global_id;
    ELSIF NEW.global_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
              FROM {CORE}.users
             WHERE global_id = NEW.global_id
        ) THEN
            RAISE EXCEPTION
                '0002: orphan global owner {relation}.global_id';
        END IF;
    ELSE
        RAISE EXCEPTION '0002: owner selector is required for {relation}';
    END IF;

    RETURN NEW;
END
$efhc_cutover_owner$
""".strip()


def _replace_control_constraints(conn: sa.Connection) -> None:
    names = (
        "ck_identity_migration_control_financial_read",
        "ck_identity_migration_control_nonfinancial_read",
        "ck_identity_migration_control_legacy_authoritative",
    )
    for name in names:
        conn.execute(
            sa.text(
                f"ALTER TABLE {CORE}.identity_migration_control "
                f"DROP CONSTRAINT IF EXISTS {name}"
            )
        )

    conn.execute(
        sa.text(
            f"""
            ALTER TABLE {CORE}.identity_migration_control
            ADD CONSTRAINT ck_identity_migration_control_nonfinancial_read
            CHECK (
                NOT nonfinancial_read_global_id_enabled
                OR shadow_read_enabled
            )
            """
        )
    )
    conn.execute(
        sa.text(
            f"""
            ALTER TABLE {CORE}.identity_migration_control
            ADD CONSTRAINT ck_identity_migration_control_financial_read
            CHECK (
                NOT financial_read_global_id_enabled
                OR (
                    dual_write_enabled
                    AND shadow_read_enabled
                    AND nonfinancial_read_global_id_enabled
                )
            )
            """
        )
    )


def _prepare_achievements(conn: sa.Connection) -> None:
    if not _column_exists(
        conn,
        schema=CORE,
        table="achievements",
        column="global_id",
    ):
        conn.execute(
            sa.text(
                f"ALTER TABLE {CORE}.achievements "
                "ADD COLUMN global_id BIGINT NULL"
            )
        )

    conn.execute(
        sa.text(
            f"""
            UPDATE {CORE}.achievements AS a
               SET global_id = u.global_id
              FROM {CORE}.users AS u
             WHERE a.global_id IS NULL
               AND a.tg_id = u.tg_id
            """
        )
    )

    orphan_count = int(
        conn.execute(
            sa.text(
                f"SELECT COUNT(*) FROM {CORE}.achievements "
                "WHERE global_id IS NULL"
            )
        ).scalar_one()
        or 0
    )
    if orphan_count:
        raise RuntimeError(
            "0002: achievements содержит owner rows без global_id: "
            f"{orphan_count}"
        )

    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.achievements "
            "ALTER COLUMN tg_id DROP NOT NULL"
        )
    )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.achievements "
            "ALTER COLUMN global_id SET NOT NULL"
        )
    )

    fk_name = "fk_achievements_global_id_users"
    if not _constraint_exists(
        conn,
        schema=CORE,
        table="achievements",
        constraint=fk_name,
    ):
        conn.execute(
            sa.text(
                f"""
                ALTER TABLE {CORE}.achievements
                ADD CONSTRAINT {fk_name}
                FOREIGN KEY (global_id)
                REFERENCES {CORE}.users(global_id)
                ON DELETE CASCADE
                """
            )
        )

    index_name = "uq_achievements_global_level"
    if not _index_exists(conn, schema=CORE, index=index_name):
        conn.execute(
            sa.text(
                f"CREATE UNIQUE INDEX {index_name} "
                f"ON {CORE}.achievements(global_id, level)"
            )
        )



def _prepare_referral_codes(conn: sa.Connection) -> None:
    conn.execute(
        sa.text(
            f"""
            UPDATE {CORE}.referral_codes AS rc
               SET inviter_global_id = u.global_id
              FROM {CORE}.users AS u
             WHERE rc.inviter_global_id IS NULL
               AND rc.inviter_tg_id = u.tg_id
            """
        )
    )
    orphan_count = int(
        conn.execute(
            sa.text(
                f"SELECT COUNT(*) FROM {CORE}.referral_codes "
                "WHERE inviter_global_id IS NULL"
            )
        ).scalar_one()
        or 0
    )
    if orphan_count:
        raise RuntimeError(
            "0002: referral_codes содержит owner rows без global_id: "
            f"{orphan_count}"
        )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.referral_codes "
            "ALTER COLUMN inviter_tg_id DROP NOT NULL"
        )
    )
    conn.execute(
        sa.text(
            f"ALTER TABLE {CORE}.referral_codes "
            "ALTER COLUMN inviter_global_id SET NOT NULL"
        )
    )

def upgrade() -> None:
    conn = op.get_bind()
    _replace_control_constraints(conn)
    if context.is_offline_mode():
        _prepare_offline_current_release(conn)
    else:
        _prepare_achievements(conn)
        _prepare_referral_codes(conn)
    for table, function in OWNER_TRIGGER_SPECS:
        conn.execute(sa.text(_owner_function_sql(table, function)))


def downgrade() -> None:
    conn = op.get_bind()
    conn.execute(
        sa.text(
            f"""
            UPDATE {CORE}.identity_migration_control
               SET legacy_authoritative = TRUE,
                   financial_read_global_id_enabled = FALSE,
                   nonfinancial_read_global_id_enabled = FALSE,
                   updated_at = now()
             WHERE singleton_id = 1
            """
        )
    )
    _replace_control_constraints(conn)
    conn.execute(
        sa.text(
            f"""
            ALTER TABLE {CORE}.identity_migration_control
            ADD CONSTRAINT ck_identity_migration_control_legacy_authoritative
            CHECK (legacy_authoritative)
            """
        )
    )
    # Возвращаем исходные 0001 trigger functions с legacy gate.
    from importlib import import_module

    initial = import_module(
        "migrations.versions.0001_initial_release_schema"
    )
    for table, function in OWNER_TRIGGER_SPECS:
        conn.execute(sa.text(initial._owner_function_sql(table, function)))

    if _index_exists(
        conn,
        schema=CORE,
        index="uq_achievements_global_level",
    ):
        conn.execute(
            sa.text(
                f"DROP INDEX {CORE}.uq_achievements_global_level"
            )
        )
    if _constraint_exists(
        conn,
        schema=CORE,
        table="achievements",
        constraint="fk_achievements_global_id_users",
    ):
        conn.execute(
            sa.text(
                f"ALTER TABLE {CORE}.achievements "
                "DROP CONSTRAINT fk_achievements_global_id_users"
            )
        )
    if _column_exists(
        conn,
        schema=CORE,
        table="achievements",
        column="global_id",
    ):
        conn.execute(
            sa.text(
                f"ALTER TABLE {CORE}.achievements "
                "DROP COLUMN global_id"
            )
        )
