# backend/migrations/versions/0001_initial_release_schema.py
# =====================================================================
# EFHC Bot — единая начальная release migration для PostgreSQL.
#
# Канон:
# - Истина = ORM (backend/app/models/**, Base.metadata).
# - 0001 — единственная pre-release revision после объединения цикла 1632.
# - создаёт финальную физическую schema с users.global_id, auth/identity,
#   owner FK, canonical runtime control и identity telemetry.
# - migrations 0002–0013 удалены из активной Alembic lineage.
#
# Критерии готовности:
# - существуют схемы: efhc_core, efhc_admin
# - создаются ORM-таблицы из Base.metadata (2 схемы)
# - проверка: pg_namespace + to_regclass(<schema>.<table>)
# - ключевое ограничение: uq_payment_intents_idempo
# - частичный уникальный индекс external tx hash для payment_intents
#   технический marker экономического ограничения объявлен ниже
#   хранится в ORM metadata и поэтому также входит в 0001
# - таблицы результата withdrawal также входят в 0001, поскольку
#   до post-release migration phase действует единая база schema
#
# Запреты:
# - raw SQL допускается для idempotent pre-release repairs, identity control и telemetry
# - никаких schema=... внутри sa.Column(...)
# =====================================================================

from __future__ import annotations

import importlib
import pkgutil
import sys
from pathlib import Path

import sqlalchemy as sa
from alembic import context as alembic_context
from alembic import op
from sqlalchemy.dialects.postgresql import insert as pg_insert

# Alembic запускается из extracted/backend (CWD = backend).
# В sys.path уже есть backend, но часть CI/локалки может ломаться.
_backend_dir = Path(__file__).resolve().parents[2]
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from app import models as models_pkg  # noqa: E402
from app.lib.ton_address import (  # noqa: E402
    TonAddressError,
    canonicalize_ton_address,
)
from app.models.base import Base  # noqa: E402
from app.release.database_contract import (  # noqa: E402
    EXPECTED_TABLE_COUNT,
    expected_tables,
)

ECONOMIC_GUARD_MARKER = (
    "payment_intents external tx hash partial unique index"
)

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def __schema__exists(conn: sa.Connection, name: str) -> bool:
    q = sa.text("SELECT 1 FROM pg_namespace WHERE nspname=:n")
    res = conn.execute(q, {"n": name})
    if res is None:
        return False
    return res.scalar() is not None



def _column_exists(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> bool:
    q = sa.text(
        "SELECT 1 FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return False
    return res.scalar() is not None


def _column_is_nullable(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> bool:
    q = sa.text(
        "SELECT is_nullable FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return False
    return str(res.scalar() or "").upper() == "YES"


def _column_char_max_length(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> int | None:
    q = sa.text(
        "SELECT character_maximum_length "
        "FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return None
    value = res.scalar()
    return int(value) if value is not None else None


def _column_numeric_precision_scale(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> tuple[int | None, int | None]:
    q = sa.text(
        "SELECT numeric_precision, numeric_scale "
        "FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return None, None
    row = res.fetchone()
    if row is None:
        return None, None
    precision = getattr(row, "numeric_precision", None)
    scale = getattr(row, "numeric_scale", None)
    return (
        int(precision) if precision is not None else None,
        int(scale) if scale is not None else None,
    )




def _drop_foreign_keys_for_column(
    conn: sa.Connection,
    *,
    schema: str,
    table: str,
    column: str,
) -> None:
    """Удалить все FK, в которых указанная колонка является source."""

    rows = conn.execute(
        sa.text(
            """
SELECT DISTINCT c.conname
FROM pg_constraint c
JOIN pg_class t ON t.oid = c.conrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
JOIN unnest(c.conkey) AS key(attnum) ON true
JOIN pg_attribute a
  ON a.attrelid = c.conrelid AND a.attnum = key.attnum
WHERE c.contype = 'f'
  AND n.nspname = :schema
  AND t.relname = :table
  AND a.attname = :column
"""
        ),
        {"schema": schema, "table": table, "column": column},
    ).scalars().all()
    for constraint_name in rows:
        conn.execute(
            sa.text(
                f'ALTER TABLE {schema}.{table} '
                f'DROP CONSTRAINT IF EXISTS "{constraint_name}"'
            )
        )


def _backfill_canonical_owner(
    conn: sa.Connection,
    *,
    table: str,
    global_column: str = "global_id",
    tg_column: str = "tg_id",
) -> None:
    """Backfill owner через provider subject и закрепить NOT NULL."""

    if not _column_exists(
        conn, "efhc_core", table, global_column
    ):
        return
    if _column_exists(conn, "efhc_core", table, tg_column):
        conn.execute(
            sa.text(
                f"UPDATE efhc_core.{table} AS target "
                f"SET {global_column} = users.global_id "
                "FROM efhc_core.users AS users "
                f"WHERE target.{global_column} IS NULL "
                f"AND target.{tg_column} = users.tg_id"
            )
        )
    null_count = conn.execute(
        sa.text(
            f"SELECT count(*) FROM efhc_core.{table} "
            f"WHERE {global_column} IS NULL"
        )
    ).scalar()
    if int(null_count or 0) != 0:
        raise RuntimeError(
            "0001: canonical owner backfill incomplete for "
            f"efhc_core.{table}.{global_column}"
        )
    conn.execute(
        sa.text(
            f"ALTER TABLE efhc_core.{table} "
            f"ALTER COLUMN {global_column} SET NOT NULL"
        )
    )


def _ensure_wallet_proof_columns(conn: sa.Connection) -> None:
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_verified",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_verified boolean NOT NULL "
                "DEFAULT false"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_verified=applied\n"
        )
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_verified_at",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_verified_at timestamptz NULL"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_time=applied\n"
        )
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_payload_hash",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_payload_hash text NULL"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_hash=applied\n"
        )
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_source",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_source text NULL"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_source=applied\n"
        )



def _backfill_wallet_bindings_canonical(conn: sa.Connection) -> None:
    """Приводит wallet_bindings к каноническому формату EFHC.

    Новая БД уже канонична: wallets_service нормализует адрес до insert.
    В старой БД могли сохраниться friendly/raw формы TON-адреса. Поскольку
    Alembic 0001 является единственной активной migration, совместимый
    backfill выполняется здесь идемпотентно.

    Если две строки сводятся к одному адресу, операция останавливается с
    точными id, не повреждая ownership. Коллизию оператор устраняет до
    повторного запуска upgrade.
    """
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "wallet_address",
    ):
        return

    rows = (
        conn.execute(
            sa.text(
                "SELECT id, wallet_address "
                "FROM efhc_core.wallet_bindings "
                "WHERE wallet_address IS NOT NULL "
                "ORDER BY id ASC"
            )
        )
        .mappings()
        .all()
    )
    if not rows:
        return

    by_canonical: dict[str, list[int]] = {}
    updates: list[tuple[int, str]] = []
    invalid: list[int] = []
    for row in rows:
        row_id = int(row["id"])
        current = str(row["wallet_address"] or "").strip()
        try:
            canonical = canonicalize_ton_address(current)
        except TonAddressError:
            invalid.append(row_id)
            continue
        by_canonical.setdefault(canonical, []).append(row_id)
        if canonical != current:
            updates.append((row_id, canonical))

    collisions = {
        addr: ids for addr, ids in by_canonical.items() if len(ids) > 1
    }
    if collisions:
        details = "; ".join(
            f"{addr}=>{','.join(str(i) for i in ids)}"
            for addr, ids in sorted(collisions.items())
        )
        raise RuntimeError(
            "wallet_bindings canonical backfill collision: " + details
        )

    for row_id, canonical in updates:
        conn.execute(
            sa.text(
                "UPDATE efhc_core.wallet_bindings "
                "SET wallet_address=:addr, updated_at=timezone('utc', now()) "
                "WHERE id=:id"
            ),
            {"addr": canonical, "id": row_id},
        )

    sys.stdout.write(
        "0001: wallet_bindings_canonical_backfill="
        f"updated:{len(updates)} invalid:{len(invalid)}\n"
    )

def _apply_existing_schema_repairs(conn: sa.Connection) -> None:
    # users.global_id является обязательным физическим account owner.
    if _column_exists(conn, "efhc_core", "users", "global_id"):
        conn.execute(
            sa.text(
                "UPDATE efhc_core.users "
                "SET global_id = nextval("
                "'efhc_core.users_global_id_seq'::regclass) "
                "WHERE global_id IS NULL"
            )
        )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.users "
                "ALTER COLUMN global_id SET NOT NULL"
            )
        )
        reserved_conflicts = int(
            conn.execute(
                sa.text(
                    "SELECT count(*) FROM efhc_core.users "
                    "WHERE global_id = 1313131313 "
                    "AND COALESCE(meta ->> 'reserved_identity', '') "
                    "<> 'superadmin'"
                )
            ).scalar()
            or 0
        )
        if reserved_conflicts:
            raise RuntimeError(
                "0001: reserved_superadmin_global_id_conflict"
            )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.users DROP CONSTRAINT IF EXISTS "
                "ck_users_superadmin_global_id_reserved"
            )
        )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.users ADD CONSTRAINT "
                "ck_users_superadmin_global_id_reserved CHECK ("
                "global_id <> 1313131313 OR "
                "COALESCE(meta ->> 'reserved_identity', '') = "
                "'superadmin')"
            )
        )

    # Withdrawals сохраняют tg_id только как delivery metadata.
    # FK/ownership принадлежит исключительно global_id.
    for table_name in ("withdraw_requests", "withdrawals"):
        _backfill_canonical_owner(conn, table=table_name)
        if _column_exists(
            conn, "efhc_core", table_name, "tg_id"
        ):
            _drop_foreign_keys_for_column(
                conn,
                schema="efhc_core",
                table=table_name,
                column="tg_id",
            )
            conn.execute(
                sa.text(
                    f"ALTER TABLE efhc_core.{table_name} "
                    "ALTER COLUMN tg_id DROP NOT NULL"
                )
            )

    # Skins/cosmetics не имеют provider semantics: legacy tg_id owner
    # удаляется после deterministic backfill.
    for table_name in ("user_skins", "user_cosmetics"):
        _backfill_canonical_owner(conn, table=table_name)
        if _column_exists(
            conn, "efhc_core", table_name, "tg_id"
        ):
            conn.execute(
                sa.text(
                    f"ALTER TABLE efhc_core.{table_name} "
                    "DROP COLUMN IF EXISTS tg_id CASCADE"
                )
            )

    _ensure_wallet_proof_columns(conn)
    _backfill_wallet_bindings_canonical(conn)

    # TON provider subject canon: прежняя колонка admin whitelist
    # ``ton_address`` переименовывается в ``ton_wallet_id``. Это тот же
    # адрес TON-кошелька; отдельный числовой TON ID не создаётся.
    if (
        _column_exists(conn, "efhc_admin", "admin_whitelist", "ton_address")
        and not _column_exists(
            conn, "efhc_admin", "admin_whitelist", "ton_wallet_id"
        )
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_admin.admin_whitelist "
                "RENAME COLUMN ton_address TO ton_wallet_id"
            )
        )

    # Admin ownership: whitelist и административный actor используют
    # global_id. Telegram fields сохраняются только как provider metadata.
    if _column_exists(
        conn, "efhc_admin", "admin_whitelist", "global_id"
    ):
        conn.execute(
            sa.text(
                "UPDATE efhc_admin.admin_whitelist AS target "
                "SET global_id = users.global_id "
                "FROM efhc_core.users AS users "
                "WHERE target.global_id IS NULL "
                "AND target.tg_id = users.tg_id"
            )
        )
        null_count = conn.execute(
            sa.text(
                "SELECT count(*) FROM efhc_admin.admin_whitelist "
                "WHERE global_id IS NULL"
            )
        ).scalar()
        if int(null_count or 0) != 0:
            raise RuntimeError(
                "0001: admin whitelist global_id backfill incomplete"
            )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_admin.admin_whitelist "
                "ALTER COLUMN global_id SET NOT NULL, "
                "ALTER COLUMN tg_id DROP NOT NULL"
            )
        )

    # Admin NFT-доступ является производным состоянием штатной NFT-проверки.
    # Источник полномочия — точные NFT-item address из TON_ADMIN_NFT_IDS внутри VIP-коллекции.
    # Таблица хранит только материализованный результат и не является ручным
    # whitelist кошельков. Старые pre-release owner-поля удаляются без переноса
    # полномочий: следующая NFT-проверка заново создаст подтверждённое состояние.
    if _column_exists(
        conn, "efhc_admin", "admin_nft_whitelist", "id"
    ):
        if not _column_exists(
            conn,
            "efhc_admin",
            "admin_nft_whitelist",
            "ton_wallet_id",
        ):
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_admin.admin_nft_whitelist "
                    "ADD COLUMN ton_wallet_id varchar(128) NULL"
                )
            )
        has_nft_id = _column_exists(
            conn, "efhc_admin", "admin_nft_whitelist", "nft_id"
        )
        has_legacy_nft_key = _column_exists(
            conn, "efhc_admin", "admin_nft_whitelist", "nft_key"
        )
        if has_legacy_nft_key and not has_nft_id:
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_admin.admin_nft_whitelist "
                    "RENAME COLUMN nft_key TO nft_id"
                )
            )
        elif not has_nft_id:
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_admin.admin_nft_whitelist "
                    "ADD COLUMN nft_id varchar(256) NULL"
                )
            )
        if has_legacy_nft_key and has_nft_id:
            conn.execute(
                sa.text(
                    "UPDATE efhc_admin.admin_nft_whitelist "
                    "SET nft_id = COALESCE(nft_id, nft_key)"
                )
            )
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_admin.admin_nft_whitelist "
                    "DROP COLUMN IF EXISTS nft_key"
                )
            )
        if _column_exists(
            conn, "efhc_admin", "admin_nft_whitelist", "global_id"
        ):
            _drop_foreign_keys_for_column(
                conn,
                schema="efhc_admin",
                table="admin_nft_whitelist",
                column="global_id",
            )
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_admin.admin_nft_whitelist "
                    "DROP COLUMN IF EXISTS global_id"
                )
            )
        if _column_exists(
            conn,
            "efhc_admin",
            "admin_nft_whitelist",
            "created_by_global_id",
        ):
            _drop_foreign_keys_for_column(
                conn,
                schema="efhc_admin",
                table="admin_nft_whitelist",
                column="created_by_global_id",
            )
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_admin.admin_nft_whitelist "
                    "DROP COLUMN IF EXISTS created_by_global_id"
                )
            )
        conn.execute(
            sa.text(
                "UPDATE efhc_admin.admin_nft_whitelist "
                "SET is_active = FALSE, "
                "revoked_at = COALESCE(revoked_at, NOW()), "
                "updated_at = NOW() "
                "WHERE source IS DISTINCT FROM 'env_nft' "
                "OR nft_id IS NULL"
            )
        )
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_admin_nft_whitelist_ton_wallet_id "
                "ON efhc_admin.admin_nft_whitelist (ton_wallet_id) "
                "WHERE ton_wallet_id IS NOT NULL"
            )
        )
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_admin_nft_whitelist_active_nft_id "
                "ON efhc_admin.admin_nft_whitelist (nft_id) "
                "WHERE nft_id IS NOT NULL AND is_active = TRUE"
            )
        )

    if _column_exists(
        conn, "efhc_admin", "admin_role", "granted_by_global_id"
    ):
        conn.execute(
            sa.text(
                "UPDATE efhc_admin.admin_role AS target "
                "SET granted_by_global_id = users.global_id "
                "FROM efhc_core.users AS users "
                "WHERE target.granted_by_global_id IS NULL "
                "AND target.granted_by_tg_id = users.tg_id"
            )
        )

    if _column_exists(
        conn, "efhc_admin", "admin_action_log", "actor_global_id"
    ):
        conn.execute(
            sa.text(
                "UPDATE efhc_admin.admin_action_log AS target "
                "SET actor_global_id = whitelist.global_id "
                "FROM efhc_admin.admin_whitelist AS whitelist "
                "WHERE target.actor_global_id IS NULL "
                "AND target.admin_id = whitelist.id"
            )
        )
        conn.execute(
            sa.text(
                "UPDATE efhc_admin.admin_action_log AS target "
                "SET actor_global_id = users.global_id "
                "FROM efhc_core.users AS users "
                "WHERE target.actor_global_id IS NULL "
                "AND target.admin_id = users.tg_id"
            )
        )

    if _column_exists(
        conn, "efhc_admin", "idempotency_key", "global_id"
    ):
        conn.execute(
            sa.text(
                "UPDATE efhc_admin.idempotency_key AS target "
                "SET global_id = whitelist.global_id "
                "FROM efhc_admin.admin_whitelist AS whitelist "
                "WHERE target.global_id IS NULL "
                "AND target.admin_id = whitelist.id"
            )
        )

    # Provider-neutral регистрация сохраняет Telegram только как
    # provider-атрибут. У TON-first invitee при первой регистрации нет
    # invitee_tg_id, а invitee_global_id остаётся canonical owner.
    referral_invitee_needs_nullable = (
        _column_exists(
            conn,
            "efhc_core",
            "referral_links",
            "invitee_tg_id",
        )
        and not _column_is_nullable(
            conn,
            "efhc_core",
            "referral_links",
            "invitee_tg_id",
        )
    )
    if referral_invitee_needs_nullable:
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_links "
                "ALTER COLUMN invitee_tg_id DROP NOT NULL"
            )
        )
        sys.stdout.write(
            "0001: referral_invitee_tg_nullable=applied\n"
        )

    # Физический владелец referral-контура — только global_id.
    # Telegram-колонки остаются nullable metadata без FK, unique и
    # self-ownership constraints. Pre-release схема исправляется
    # идемпотентно до согласования metadata.
    if _column_exists(
        conn, "efhc_core", "referral_links", "inviter_tg_id"
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_links "
                "ALTER COLUMN inviter_tg_id DROP NOT NULL"
            )
        )
    for constraint_name in (
        "fk_ref_links_inviter_users_tg_id",
        "fk_ref_links_invitee_users_tg_id",
        "uq_referral_links_invitee_tg_id",
        "ck_ref_links_tg_not_self",
        "ck_referral_links_not_self",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_links "
                f"DROP CONSTRAINT IF EXISTS {constraint_name}"
            )
        )
    conn.execute(
        sa.text(
            "DROP INDEX IF EXISTS "
            "efhc_core.ix_referral_links_inviter_tg_id"
        )
    )
    conn.execute(
        sa.text(
            "DROP INDEX IF EXISTS "
            "efhc_core.ix_referral_links_invitee_tg_id"
        )
    )
    if _column_exists(
        conn, "efhc_core", "referral_links", "inviter_global_id"
    ):
        null_count = conn.execute(
            sa.text(
                "SELECT count(*) FROM efhc_core.referral_links "
                "WHERE inviter_global_id IS NULL "
                "OR invitee_global_id IS NULL"
            )
        ).scalar()
        if int(null_count or 0) != 0:
            raise RuntimeError(
                "0001: referral_links requires canonical global_id before cleanup"
            )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_links "
                "ALTER COLUMN inviter_global_id SET NOT NULL, "
                "ALTER COLUMN invitee_global_id SET NOT NULL"
            )
        )
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_referral_links_invitee_global_id "
                "ON efhc_core.referral_links (invitee_global_id)"
            )
        )
        conn.execute(
            sa.text(
                "CREATE INDEX IF NOT EXISTS "
                "ix_referral_links_inviter_created_invitee_global "
                "ON efhc_core.referral_links "
                "(inviter_global_id, created_at DESC, "
                "invitee_global_id DESC)"
            )
        )
    conn.execute(
        sa.text(
            "ALTER TABLE efhc_core.referral_links "
            "DROP COLUMN IF EXISTS inviter_tg_id CASCADE, "
            "DROP COLUMN IF EXISTS invitee_tg_id CASCADE"
        )
    )
    conn.execute(
        sa.text(
            "ALTER TABLE efhc_core.referral_links "
            "ADD COLUMN IF NOT EXISTS unit_reward_no INTEGER"
        )
    )
    conn.execute(
        sa.text(
            "CREATE UNIQUE INDEX IF NOT EXISTS "
            "uq_referral_links_inviter_unit_reward_no "
            "ON efhc_core.referral_links "
            "(inviter_global_id, unit_reward_no) "
            "WHERE unit_reward_no IS NOT NULL"
        )
    )
    conn.execute(
        sa.text(
            "DO $$ BEGIN "
            "IF NOT EXISTS ("
            "SELECT 1 FROM pg_constraint "
            "WHERE conname = 'ck_ref_links_unit_reward_no_range'"
            ") THEN "
            "ALTER TABLE efhc_core.referral_links "
            "ADD CONSTRAINT ck_ref_links_unit_reward_no_range "
            "CHECK (unit_reward_no IS NULL OR "
            "unit_reward_no BETWEEN 1 AND 10000); "
            "END IF; END $$"
        )
    )

    if _column_exists(
        conn, "efhc_core", "referral_codes", "inviter_tg_id"
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_codes "
                "ALTER COLUMN inviter_tg_id DROP NOT NULL"
            )
        )
    for constraint_name in (
        "fk_referral_codes_inviter_tg_id",
        "fk_ref_codes_inviter_users_tg_id",
        "uq_referral_codes_inviter_tg_id",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_codes "
                f"DROP CONSTRAINT IF EXISTS {constraint_name}"
            )
        )
    if _column_exists(
        conn, "efhc_core", "referral_codes", "inviter_global_id"
    ):
        null_count = conn.execute(
            sa.text(
                "SELECT count(*) FROM efhc_core.referral_codes "
                "WHERE inviter_global_id IS NULL"
            )
        ).scalar()
        if int(null_count or 0) != 0:
            raise RuntimeError(
                "0001: referral_codes requires canonical global_id before cleanup"
            )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_codes "
                "ALTER COLUMN inviter_global_id SET NOT NULL"
            )
        )
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_referral_codes_inviter_global_id "
                "ON efhc_core.referral_codes (inviter_global_id)"
            )
        )
    conn.execute(
        sa.text(
            "ALTER TABLE efhc_core.referral_codes "
            "DROP COLUMN IF EXISTS inviter_tg_id CASCADE"
        )
    )

    # Business runtime больше не имеет legacy owner-колонки.
    # Для существующей pre-release БД сначала выполняем backfill,
    # затем закрепляем NOT NULL и физически удаляем tg_id.
    # tx_hash_locks является глобальным settlement lock, а не только
    # PaymentIntent lock. Direct watcher/Admin recovery claims не
    # имеют intent_id, поэтому поле должно быть nullable в pre-release 0001.
    if _column_exists(conn, "efhc_core", "tx_hash_locks", "intent_id"):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.tx_hash_locks "
                "ALTER COLUMN intent_id DROP NOT NULL"
            )
        )

    for table_name in (
        "panels",
        "panels_archive",
        "user_tasks_status",
        "task_bonus_log",
        "task_complete_lock",
        "shop_orders",
        "ranks_snapshots",
        "ranks_top_cache",
        "ranks_user_snapshots",
        "achievements",
        "tx_hash_locks",
    ):
        has_global = _column_exists(
            conn, "efhc_core", table_name, "global_id"
        )
        has_tg = _column_exists(
            conn, "efhc_core", table_name, "tg_id"
        )
        if not has_global:
            continue
        if has_tg:
            conn.execute(
                sa.text(
                    f"UPDATE efhc_core.{table_name} AS target "
                    "SET global_id = users.global_id "
                    "FROM efhc_core.users AS users "
                    "WHERE target.global_id IS NULL "
                    "AND target.tg_id = users.tg_id"
                )
            )
        null_count = conn.execute(
            sa.text(
                f"SELECT count(*) FROM efhc_core.{table_name} "
                "WHERE global_id IS NULL"
            )
        ).scalar()
        if int(null_count or 0) != 0:
            raise RuntimeError(
                "0001: canonical owner backfill incomplete for "
                f"efhc_core.{table_name}"
            )
        conn.execute(
            sa.text(
                f"ALTER TABLE efhc_core.{table_name} "
                "ALTER COLUMN global_id SET NOT NULL"
            )
        )
        if has_tg:
            conn.execute(
                sa.text(
                    f"ALTER TABLE efhc_core.{table_name} "
                    "DROP COLUMN IF EXISTS tg_id CASCADE"
                )
            )
        sys.stdout.write(
            "0001: canonical_owner_only="
            f"efhc_core.{table_name}.global_id\n"
        )

    # ShopOrder idempotency принадлежит владельцу. PostgreSQL может
    # использовать ON CONFLICT(global_id, idempotency_key) только при
    # наличии matching UNIQUE arbiter. Существующие дубли не лечим
    # автоматически: pre-release migration останавливается fail-closed.
    if (
        _column_exists(conn, "efhc_core", "shop_orders", "global_id")
        and _column_exists(
            conn, "efhc_core", "shop_orders", "idempotency_key"
        )
    ):
        duplicate_count = conn.execute(
            sa.text(
                "SELECT count(*) FROM ("
                "SELECT global_id, idempotency_key "
                "FROM efhc_core.shop_orders "
                "WHERE idempotency_key IS NOT NULL "
                "GROUP BY global_id, idempotency_key HAVING count(*) > 1"
                ") AS duplicate_shop_order_idempotency"
            )
        ).scalar()
        if int(duplicate_count or 0) != 0:
            raise RuntimeError(
                "0001: duplicate owner-scoped shop order idempotency keys"
            )
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_shop_orders_global_id_idempotency "
                "ON efhc_core.shop_orders (global_id, idempotency_key)"
            )
        )

    # В task_submissions tg_id остаётся только nullable metadata доставки.
    if _column_exists(
        conn, "efhc_core", "task_submissions", "global_id"
    ):
        if _column_exists(
            conn, "efhc_core", "task_submissions", "tg_id"
        ):
            conn.execute(
                sa.text(
                    "UPDATE efhc_core.task_submissions AS target "
                    "SET global_id = users.global_id "
                    "FROM efhc_core.users AS users "
                    "WHERE target.global_id IS NULL "
                    "AND target.tg_id = users.tg_id"
                )
            )
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.task_submissions "
                    "ALTER COLUMN tg_id DROP NOT NULL"
                )
            )
        null_count = conn.execute(
            sa.text(
                "SELECT count(*) FROM efhc_core.task_submissions "
                "WHERE global_id IS NULL"
            )
        ).scalar()
        if int(null_count or 0) != 0:
            raise RuntimeError(
                "0001: task_submissions global owner backfill incomplete"
            )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.task_submissions "
                "ALTER COLUMN global_id SET NOT NULL"
            )
        )
        for constraint_name in (
            "uq_task_submissions_task_user_once",
            "uq_task_submissions_task_tg_once",
        ):
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.task_submissions "
                    f"DROP CONSTRAINT IF EXISTS {constraint_name}"
                )
            )
        conn.execute(
            sa.text(
                "DROP INDEX IF EXISTS "
                "efhc_core.ix_task_submissions_tg_id"
            )
        )
        conn.execute(
            sa.text(
                "DROP INDEX IF EXISTS "
                "efhc_core.ix_task_submissions_user_status"
            )
        )
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_task_submissions_task_global_once "
                "ON efhc_core.task_submissions (task_id, global_id)"
            )
        )
        if _column_exists(
            conn, "efhc_core", "task_submissions", "moderator_tg_id"
        ):
            conn.execute(
                sa.text(
                    "UPDATE efhc_core.task_submissions AS target "
                    "SET moderator_global_id = users.global_id "
                    "FROM efhc_core.users AS users "
                    "WHERE target.moderator_global_id IS NULL "
                    "AND target.moderator_tg_id = users.tg_id"
                )
            )
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.task_submissions "
                    "DROP COLUMN IF EXISTS moderator_tg_id CASCADE"
                )
            )

    # Канонический владелец — global_id. Telegram-поля становятся
    # необязательными provider-атрибутами, чтобы TON-only аккаунты
    # использовали те же финансовые и бизнес-пути.
    for table_name in (
        "efhc_transfers_log",
        "withdraw_requests",
        "withdrawals",
        "payment_intents",
    ):
        if (
            _column_exists(conn, "efhc_core", table_name, "tg_id")
            and not _column_is_nullable(
                conn, "efhc_core", table_name, "tg_id"
            )
        ):
            conn.execute(
                sa.text(
                    f"ALTER TABLE efhc_core.{table_name} "
                    "ALTER COLUMN tg_id DROP NOT NULL"
                )
            )
            sys.stdout.write(
                "0001: global_owner_legacy_tg_nullable="
                f"{table_name}.tg_id\n"
            )

    # Аварийный BANK_EFHC repair: Центральный банк — самостоятельная
    # system entity, а не фиктивный пользователь/provider identity. Новая БД
    # получает колонку из ORM metadata; существующей pre-release БД нужен
    # явный additive repair ниже.
    if not _column_exists(
        conn, "efhc_core", "efhc_transfers_log", "system_entity"
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.efhc_transfers_log "
                "ADD COLUMN system_entity varchar(64) NULL"
            )
        )
    conn.execute(
        sa.text(
            "CREATE INDEX IF NOT EXISTS "
            "ix_efhc_transfers_log_system_entity "
            "ON efhc_core.efhc_transfers_log (system_entity)"
        )
    )
    conn.execute(
        sa.text(
            "CREATE INDEX IF NOT EXISTS ix_eftl_system_entity_created "
            "ON efhc_core.efhc_transfers_log "
            "(system_entity, created_at)"
        )
    )
    # Ремонт существующей схемы: SQLAlchemy metadata не добавляет
    # новый UNIQUE к уже созданной таблице. Индекс обеспечивает тот же
    # контракт идемпотентности для операций владельца global_id.
    if _column_exists(
        conn,
        "efhc_core",
        "payment_intents",
        "global_id",
    ):
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_payment_intents_global_idempo "
                "ON efhc_core.payment_intents "
                "(global_id, purpose, idempotency_key)"
            )
        )
        sys.stdout.write(
            "0001: payment_intents_global_idempo=ready\n"
        )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.payment_intents "
                "DROP CONSTRAINT IF EXISTS "
                "uq_payment_intents_idempo"
            )
        )
        conn.execute(
            sa.text(
                "DROP INDEX IF EXISTS "
                "efhc_core.ix_payment_intents_tg_id"
            )
        )
        null_count = conn.execute(
            sa.text(
                "SELECT count(*) FROM "
                "efhc_core.payment_intents "
                "WHERE global_id IS NULL"
            )
        ).scalar()
        if int(null_count or 0) == 0:
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.payment_intents "
                    "ALTER COLUMN global_id SET NOT NULL"
                )
            )


    for table_name in (
        "wallet_bindings",
        "wallet_connect_idempotency",
        "wallet_proof_token_uses",
    ):
        if _column_exists(
            conn, "efhc_core", table_name, "global_id"
        ):
            null_count = conn.execute(
                sa.text(
                    f"SELECT count(*) FROM efhc_core.{table_name} "
                    "WHERE global_id IS NULL"
                )
            ).scalar()
            if int(null_count or 0) == 0:
                conn.execute(
                    sa.text(
                        f"ALTER TABLE efhc_core.{table_name} "
                        "ALTER COLUMN global_id SET NOT NULL"
                    )
                )

    # HEAL-0040: в БД до v169.88 поле payment_intents.package_id
    # могло остаться NOT NULL. Текущий контракт разрешает NULL
    # только для custom/package-less intents.
    package_id_needs_nullable = (
        _column_exists(
            conn,
            "efhc_core",
            "payment_intents",
            "package_id",
        )
        and not _column_is_nullable(
            conn,
            "efhc_core",
            "payment_intents",
            "package_id",
        )
    )
    if package_id_needs_nullable:
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.payment_intents "
                "ALTER COLUMN package_id DROP NOT NULL"
            )
        )
        sys.stdout.write(
            "0001: heal0040_package_id_nullable=applied\n"
        )

    # HEAL-0044: в старой БД direction мог остаться varchar(8).
    # Новая ORM metadata использует varchar(24); ALTER идемпотентен.
    if _column_exists(
        conn,
        "efhc_core",
        "efhc_transfers_log",
        "direction",
    ):
        current_len = _column_char_max_length(
            conn,
            "efhc_core",
            "efhc_transfers_log",
            "direction",
        )
        if current_len is not None and current_len < 24:
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.efhc_transfers_log "
                    "ALTER COLUMN direction TYPE varchar(24)"
                )
            )
            sys.stdout.write(
                "0001: heal0044_direction_varchar24=applied\n"
            )

    if _column_exists(
        conn,
        "efhc_core",
        "withdraw_requests",
        "amount",
    ):
        precision, scale = _column_numeric_precision_scale(
            conn,
            "efhc_core",
            "withdraw_requests",
            "amount",
        )
        if (precision, scale) != (30, 8):
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.withdraw_requests "
                    "ALTER COLUMN amount TYPE NUMERIC(30,8) "
                    "USING amount::numeric(30,8)"
                )
            )
            sys.stdout.write(
                "0001: withdraw_requests_amount_numeric30_8=applied\n"
            )

def _to_regclass(conn: sa.Connection, fq: str) -> bool:
    q = sa.text("SELECT to_regclass(:n)")
    res = conn.execute(q, {"n": fq})
    if res is None:
        return False
    return res.scalar() is not None


def __import___all__model_modules() -> None:
    # Канон: в Base.metadata должны попасть ВСЕ ORM-модели.
    #
    # app.models уже выполняет безопасный авто-импорт модельных модулей
    # при инициализации пакета. В alembic 0001 повторный жёсткий импорт
    # может заново дёргать декларативную регистрацию и ловить duplicate
    # table-definition drift на одном и том же MetaData.
    #
    # Поэтому здесь импортируем только ещё не загруженные *_models.py.
    loaded = set(getattr(models_pkg, "MODEL_MODULES_LOADED", []))
    for mod in pkgutil.iter_modules(models_pkg.__path__):
        if not mod.name.endswith("_models"):
            continue
        if mod.name in loaded:
            continue
        importlib.import_module(f"{models_pkg.__name__}.{mod.name}")



CORE = "efhc_core"
ADMIN = "efhc_admin"

# Инвентарь отключённых trigger перехода identity. Имена сохраняются только
# для того, чтобы единый pre-release 0001 мог удалить переходные DB-объекты
# из существующей development database. После квалификации global_id cutover
# dual-write/read-switch runtime больше не устанавливается.
_RETIRED_IDENTITY_DIRECT_TRIGGERS: tuple[tuple[int, str, str], ...] = (
    (1, CORE, "referral_links"),
    (2, CORE, "referral_links"),
    (3, CORE, "referral_codes"),
    (4, CORE, "referral_bonus_ledger"),
    (5, CORE, "task_submissions"),
    (6, CORE, "task_submissions"),
    (7, CORE, "ranks_snapshots"),
    (8, CORE, "ranks_top_cache"),
    (9, CORE, "ranks_user_snapshots"),
    (10, CORE, "efhc_transfers_log"),
    (11, CORE, "payment_intents"),
    (12, CORE, "withdraw_requests"),
    (13, CORE, "withdrawals"),
    (14, CORE, "withdraw_outcome_events"),
    (15, CORE, "wallet_bindings"),
    (16, CORE, "wallet_connect_idempotency"),
    (17, CORE, "wallet_proof_token_uses"),
    (18, CORE, "tx_hash_locks"),
    (19, CORE, "ton_inbox_logs"),
    (20, ADMIN, "admin_whitelist"),
    (21, ADMIN, "admin_whitelist"),
    (22, ADMIN, "admin_role"),
)


def _function_name(index: int) -> str:
    return f"efhc_1624_dual_write_{index:02d}"


def _trigger_name(index: int) -> str:
    return f"trg_1624_dual_write_{index:02d}"


# Owner triggers user_skins/user_cosmetics выведены в цикле 1688.
# Их номера и имена сохранены только в cleanup-командах ниже.


def _cleanup_retired_identity_runtime(conn: sa.Connection) -> None:
    """Удалить переходный DB-runtime миграции идентичности после cutover."""
    for index, schema_name, table_name in _RETIRED_IDENTITY_DIRECT_TRIGGERS:
        conn.execute(
            sa.text(
                f"DROP TRIGGER IF EXISTS {_trigger_name(index)} "
                f"ON {schema_name}.{table_name}"
            )
        )
        conn.execute(
            sa.text(
                f"DROP FUNCTION IF EXISTS {CORE}."
                f"{_function_name(index)}()"
            )
        )

    for trigger, table, function in (
        (
            "trg_1624_dual_write_scheduler",
            f"{CORE}.scheduler_task_log",
            "efhc_1624_dual_write_scheduler",
        ),
        (
            "trg_1624_dual_write_admin_action",
            f"{ADMIN}.admin_action_log",
            "efhc_1624_dual_write_admin_action",
        ),
        (
            "trg_1624_dual_write_admin_idempotency",
            f"{ADMIN}.idempotency_key",
            "efhc_1624_dual_write_admin_idempotency",
        ),
        (
            "trg_1628_shop_order_owner",
            f"{CORE}.shop_orders",
            "efhc_1628_shop_order_owner",
        ),
        (
            "trg_1628_user_skin_owner",
            f"{CORE}.user_skins",
            "efhc_1628_user_skin_owner",
        ),
        (
            "trg_1628_user_cosmetics_owner",
            f"{CORE}.user_cosmetics",
            "efhc_1628_user_cosmetics_owner",
        ),
    ):
        conn.execute(
            sa.text(f"DROP TRIGGER IF EXISTS {trigger} ON {table}")
        )
        conn.execute(
            sa.text(f"DROP FUNCTION IF EXISTS {CORE}.{function}()")
        )

    conn.execute(
        sa.text(
            f"DROP VIEW IF EXISTS {CORE}."
            "identity_ownership_shadow_telemetry"
        )
    )
    conn.execute(
        sa.text(
            f"DROP TABLE IF EXISTS {CORE}.identity_migration_control"
        )
    )


def _validate_release_identity_schema(conn: sa.Connection) -> None:
    physical = conn.execute(
        sa.text(
            """
SELECT
    count(*) FILTER (WHERE column_name = 'global_id') AS global_columns,
    count(*) FILTER (WHERE column_name = 'user_id') AS legacy_columns
FROM information_schema.columns
WHERE table_schema = 'efhc_core' AND table_name = 'users'
"""
        )
    ).mappings().one()
    if int(physical["global_columns"] or 0) != 1:
        raise RuntimeError("0001: users.global_id physical column missing")
    if int(physical["legacy_columns"] or 0) != 0:
        raise RuntimeError("0001: users.user_id physical column forbidden")

    sequence = conn.execute(
        sa.text(
            "SELECT pg_get_serial_sequence("
            "'efhc_core.users', 'global_id')"
        )
    ).scalar()
    if sequence != "efhc_core.users_global_id_seq":
        raise RuntimeError(
            "0001: users.global_id sequence ownership mismatch"
        )

    fk_total = conn.execute(
        sa.text(
            """
SELECT count(*)
FROM pg_constraint c
JOIN pg_attribute a
  ON a.attrelid = c.confrelid
 AND a.attnum = ANY(c.confkey)
WHERE c.contype = 'f'
  AND c.confrelid = 'efhc_core.users'::regclass
  AND a.attname = 'global_id'
"""
        )
    ).scalar()
    if int(fk_total or 0) != 41:
        raise RuntimeError(
            f"0001: expected 41 global owner FK, got {fk_total}"
        )

    legacy_owner_fk_total = conn.execute(
        sa.text(
            """
SELECT count(*)
FROM pg_constraint c
JOIN pg_attribute a
  ON a.attrelid = c.confrelid
 AND a.attnum = ANY(c.confkey)
WHERE c.contype = 'f'
  AND c.confrelid = 'efhc_core.users'::regclass
  AND a.attname = 'tg_id'
"""
        )
    ).scalar()
    if int(legacy_owner_fk_total or 0) != 0:
        raise RuntimeError(
            "0001: legacy users.tg_id owner FK forbidden"
        )


def upgrade() -> None:
    conn = op.get_bind()
    offline = bool(alembic_context.is_offline_mode())

    # Диагностика: какая БД/схема видна в Alembic-сессии.
    # В offline режиме нет живого коннекта.
    if not offline:
        try:
            db = conn.execute(sa.text("SELECT current_database()"))
            db = db.scalar()
            sp = conn.execute(sa.text("SHOW search_path")).scalar()
            sys.stdout.write(f"0001: db={db}\n")
            sys.stdout.write(f"0001: search_path={sp}\n")
        except Exception:
            sys.stdout.write("0001: db_diag_unavailable\n")
    # 1) Схемы создаются в env.py (AUTOCOMMIT), здесь не трогаем.

    # 2) ORM-таблицы создаём по schema, заданной в моделях.
    # Для без-schema таблиц применяем schema_translate_map -> efhc_core.
    conn.execute(sa.text("SET search_path TO efhc_core, efhc_admin"))
    conn2 = conn.execution_options(
        schema_translate_map={None: "efhc_core"}
    )

    # 2.1) Импортируем все модели, затем создаём таблицы
    __import___all__model_modules()

    sys.stdout.write(
        f"0001: metadata_tables={len(Base.metadata.tables)}\n"
    )

    required_fq = {
        "efhc_core.users",
        "efhc_core.user_identities",
        "efhc_core.auth_challenges",
        "efhc_core.auth_sessions",
        "efhc_core.user_roles",
        "efhc_core.withdraw_requests",
        "efhc_core.payment_intents",
        "efhc_core.withdraw_outcome_events",
        "efhc_core.outcome_fallback_promos",
        "efhc_core.tasks",
        "efhc_core.task_submissions",
        "efhc_core.user_tasks_status",
        "efhc_core.task_bonus_log",
        "efhc_core.task_complete_lock",
        "efhc_admin.efhc_sale_packages",
    }
    md_keys = set(Base.metadata.tables.keys())
    missing_md = sorted([t for t in required_fq if t not in md_keys])
    if missing_md:
        raise RuntimeError(
            "0001 sanity failed; missing in Base.metadata: "
            + ", ".join(missing_md)
        )

    # CI может запускать `alembic upgrade head` больше одного раза в
    # одной и той же БД. Держим 0001 идемпотентной, чтобы не ловить
    # DuplicateObject на ENUM и повторные CREATE TABLE.
    Base.metadata.create_all(bind=conn2, checkfirst=True)

    if not offline:
        conn.execute(
            sa.text(
                "ALTER SEQUENCE efhc_core.users_global_id_seq "
                "OWNED BY efhc_core.users.global_id"
            )
        )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.users ALTER COLUMN global_id "
                "SET DEFAULT nextval("
                "'efhc_core.users_global_id_seq'::regclass)"
            )
        )


    # Диагностика: сколько таблиц реально есть в core/admin.
    if not offline:
        try:
            q = sa.text(
                "SELECT count(*) FROM pg_class c "
                "JOIN pg_namespace n ON n.oid=c.relnamespace "
                "WHERE c.relkind='r' AND n.nspname IN (:c,:a)"
            )
            cnt = conn.execute(
                q, {"c": "efhc_core", "a": "efhc_admin"}
            ).scalar()
            sys.stdout.write(f"0001: tables_in_schemas={cnt}\n")
        except Exception:
            sys.stdout.write("0001: tables_in_schemas=unknown\n")

    # Старой БД нужны явные исправления контракта: create_all()
    # не меняет существующие колонки. Исправления идут до проверок.
    if not offline:
        _apply_existing_schema_repairs(conn)
        _cleanup_retired_identity_runtime(conn)

    # Сигнал в CI: дошли до DDL.
    sys.stdout.write("0001: create__all__done\n")

    # 3) Sanity-check (детерминированный)
    # В offline режиме Alembic генерирует SQL без подключения к БД.
    # Sanity проверки там запрещены.
    if not offline:
        missing: list[str] = []

        if not __schema__exists(conn, "efhc_core"):
            missing.append("schema:efhc_core")
        if not __schema__exists(conn, "efhc_admin"):
            missing.append("schema:efhc_admin")

        tables = sorted(Base.metadata.tables.keys())

        contract_tables = expected_tables()
        if len(tables) != EXPECTED_TABLE_COUNT:
            missing.append(
                "tables_count_expected_"
                f"{EXPECTED_TABLE_COUNT}_got_{len(tables)}"
            )
        actual_contract = {
            (str(table.schema or ""), str(table.name))
            for table in Base.metadata.sorted_tables
            if table.schema in {"efhc_core", "efhc_admin"}
        }
        if actual_contract != contract_tables:
            missing.append("ORM_metadata_contract_mismatch")

        for t in tables:
            fq = t if "." in t else f"efhc_core.{t}"
            if not _to_regclass(conn, fq):
                missing.append(fq)

        required_columns = {
            ("efhc_core", "users", "global_id"),
            ("efhc_core", "users", "tg_id"),
            ("efhc_core", "users", "main_balance"),
            ("efhc_core", "users", "bonus_balance"),
            ("efhc_core", "users", "available_kwh"),
            ("efhc_core", "users", "total_generated_kwh"),
            ("efhc_core", "users", "exchanged_kwh_total"),
            ("efhc_core", "users", "ton_wallet"),
            ("efhc_core", "users", "is_vip"),
            ("efhc_core", "users", "meta"),
            ("efhc_core", "withdraw_requests", "global_id"),
            ("efhc_core", "withdraw_requests", "amount"),
            ("efhc_core", "withdraw_requests", "status"),
            ("efhc_core", "withdraw_requests", "idempotency_key"),
            ("efhc_core", "withdraw_requests", "hold_done"),
            ("efhc_core", "withdraw_requests", "refund_done"),
            ("efhc_core", "withdraw_requests", "tx_hash"),
            (
                "efhc_core",
                "withdraw_requests",
                "processing_idempotency_key",
            ),
            ("efhc_core", "payment_intents", "tg_id"),
            ("efhc_core", "payment_intents", "purpose"),
            ("efhc_core", "payment_intents", "package_id"),
            ("efhc_core", "payment_intents", "asset"),
            ("efhc_core", "payment_intents", "amount_asset_d8"),
            ("efhc_core", "payment_intents", "efhc_amount_d8"),
            ("efhc_core", "payment_intents", "status"),
            ("efhc_core", "payment_intents", "idempotency_key"),
            ("efhc_core", "payment_intents", "payload"),
            ("efhc_core", "payment_intents", "external_tx_hash"),
            ("efhc_core", "panels", "global_id"),
            ("efhc_core", "panels", "is_active"),
            ("efhc_core", "panels", "is_archived"),
            ("efhc_core", "panels", "base_gen_per_sec"),
            ("efhc_core", "panels", "generated_kwh"),
            ("efhc_core", "shop_orders", "global_id"),
            ("efhc_core", "shop_orders", "type"),
            ("efhc_core", "shop_orders", "status"),
            ("efhc_core", "shop_orders", "idempotency_key"),
            ("efhc_core", "shop_orders", "quantity_efhc"),
            ("efhc_core", "shop_orders", "tx_hash"),
            ("efhc_core", "shop_orders", "payment_error_log"),
            ("efhc_core", "efhc_transfers_log", "tg_id"),
            ("efhc_core", "efhc_transfers_log", "system_entity"),
            ("efhc_core", "efhc_transfers_log", "amount"),
            ("efhc_core", "efhc_transfers_log", "direction"),
            ("efhc_core", "efhc_transfers_log", "balance_type"),
            ("efhc_core", "efhc_transfers_log", "reason"),
            ("efhc_core", "efhc_transfers_log", "idempotency_key"),
            ("efhc_core", "bank_balance", "key"),
            ("efhc_core", "bank_balance", "balance"),
            ("efhc_core", "wallet_bindings", "global_id"),
            ("efhc_core", "wallet_bindings", "tg_id"),
            ("efhc_core", "wallet_bindings", "wallet_address"),
            ("efhc_core", "wallet_bindings", "proof_verified"),
            ("efhc_core", "wallet_bindings", "proof_verified_at"),
            ("efhc_core", "wallet_bindings", "proof_payload_hash"),
            ("efhc_core", "wallet_bindings", "proof_source"),
            (
                "efhc_core",
                "wallet_connect_idempotency",
                "global_id",
            ),
            (
                "efhc_core",
                "wallet_connect_idempotency",
                "idempotency_key",
            ),
            (
                "efhc_core",
                "wallet_proof_token_uses",
                "global_id",
            ),
            (
                "efhc_core",
                "wallet_proof_token_uses",
                "proof_payload_hash",
            ),
            ("efhc_core", "tasks", "bonus_efhc"),
            ("efhc_core", "tasks", "meta"),
            ("efhc_core", "task_submissions", "global_id"),
            ("efhc_core", "task_submissions", "bonus_amount_efhc"),
            ("efhc_core", "task_bonus_log", "global_id"),
            ("efhc_core", "task_bonus_log", "amount_bonus_efhc"),
            ("efhc_core", "user_tasks_status", "global_id"),
            ("efhc_core", "user_tasks_status", "task_code"),
            ("efhc_core", "task_complete_lock", "global_id"),
            ("efhc_core", "task_complete_lock", "credited"),
        }
        for schema, table, column in sorted(required_columns):
            if not _column_exists(conn, schema, table, column):
                missing.append(f"{schema}.{table}.{column}")

        if not _column_is_nullable(
            conn,
            "efhc_core",
            "payment_intents",
            "package_id",
        ):
            missing.append(
                "efhc_core.payment_intents.package_id_nullable"
            )

        direction_len = _column_char_max_length(
            conn,
            "efhc_core",
            "efhc_transfers_log",
            "direction",
        )
        if direction_len is None or direction_len < 24:
            missing.append(
                "efhc_core.efhc_transfers_log.direction_varchar24"
            )

        if missing:
            raise RuntimeError(
                "0001 sanity failed; missing objects: "
                + ", ".join(missing)
            )

        _validate_release_identity_schema(conn)

# Жёсткая проверка: после create_all таблицы видимы.
# (проверка через to_regclass)
        missing = []
        for fq in sorted(required_fq):
            got = conn.execute(
                sa.text("SELECT to_regclass(:n)"), {"n": fq}
            )
            if got.scalar() is None:
                missing.append(fq)
        if missing:
            msg = "0001: missing_after_create_all=" + ",".join(missing)
            raise RuntimeError(msg)


    # Migration создаёт только bank schema. Идемпотентный
    # production bootstrap владеет начальными BANK_EFHC и EFHC_MAIN.
    # Отсутствие значений в Alembic исключает сброс balances и делает
    # повторные upgrade безопасными для данных.

    st = sa.Table(
        'system_templates',
        sa.MetaData(),
        sa.Column('key', sa.String(), nullable=False),
        sa.Column('content', sa.Text(), nullable=True),
        sa.Column('description', sa.String(), nullable=False),
        schema='efhc_core',
    )
    template_rows = [
        {
            'key': 'task_reject_fallback',
            'content': 'Выполнение не подтверждено.',
            'description': 'Автоответ при отклонении задания',
        },
        {
            'key': 'task_approve_fallback',
            'content': None,
            'description': 'Автоответ при одобрении задания',
        },
    ]
    localized_templates = {
        'task_approve_prefix': {
            'description': 'Префикс уведомления: задание подтверждено',
            'values': {
                'en': '✅ Task approved.',
                'ru': '✅ Задание подтверждено.',
                'uk': '✅ Завдання підтверджено.',
                'de': '✅ Aufgabe bestätigt.',
                'fr': '✅ Tâche confirmée.',
                'es': '✅ Tarea confirmada.',
                'it': '✅ Attività confermata.',
                'tr': '✅ Görev onaylandı.',
                'pl': '✅ Zadanie potwierdzone.',
                'da': '✅ Opgaven er bekræftet.',
                'hi': '✅ कार्य की पुष्टि हो गई।',
                'id': '✅ Tugas dikonfirmasi.',
                'sw': '✅ Kazi imethibitishwa.',
            },
        },
        'task_reject_prefix': {
            'description': 'Префикс уведомления: задание отклонено',
            'values': {
                'en': '⚠️ Task rejected.',
                'ru': '⚠️ Задание отклонено.',
                'uk': '⚠️ Завдання відхилено.',
                'de': '⚠️ Aufgabe abgelehnt.',
                'fr': '⚠️ Tâche refusée.',
                'es': '⚠️ Tarea rechazada.',
                'it': '⚠️ Attività rifiutata.',
                'tr': '⚠️ Görev reddedildi.',
                'pl': '⚠️ Zadanie odrzucone.',
                'da': '⚠️ Opgaven blev afvist.',
                'hi': '⚠️ कार्य अस्वीकृत किया गया।',
                'id': '⚠️ Tugas ditolak.',
                'sw': '⚠️ Kazi imekataliwa.',
            },
        },
        'task_approve_fallback': {
            'description': 'Fallback-комментарий: задание подтверждено',
            'values': {
                'en': 'Task result confirmed.',
                'ru': 'Результат задания подтвержден.',
                'uk': 'Результат завдання підтверджено.',
                'de': 'Das Ergebnis der Aufgabe wurde bestätigt.',
                'fr': 'Le résultat de la tâche a été confirmé.',
                'es': 'El resultado de la tarea fue confirmado.',
                'it': "Il risultato dell'attività è stato confermato.",
                'tr': 'Görev sonucu doğrulandı.',
                'pl': 'Wynik zadania został potwierdzony.',
                'da': 'Opgavens resultat er bekræftet.',
                'hi': 'कार्य का परिणाम पुष्टि कर दिया गया है।',
                'id': 'Hasil tugas telah dikonfirmasi.',
                'sw': 'Matokeo ya kazi yamehakikishwa.',
            },
        },
        'task_reject_fallback': {
            'description': 'Fallback-комментарий: задание отклонено',
            'values': {
                'en': 'Task result was not confirmed.',
                'ru': 'Выполнение не подтверждено.',
                'uk': 'Виконання не підтверджено.',
                'de': 'Die Ausführung wurde nicht bestätigt.',
                'fr': "L'exécution n'a pas été confirmée.",
                'es': 'La ejecución no fue confirmada.',
                'it': "L'esecuzione non è stata confermata.",
                'tr': 'Tamamlama doğrulanmadı.',
                'pl': 'Wykonanie nie zostało potwierdzone.',
                'da': 'Udførelsen blev ikke bekræftet.',
                'hi': 'कार्य पूरा होने की पुष्टि नहीं हुई।',
                'id': 'Penyelesaian tidak dikonfirmasi.',
                'sw': 'Utekelezaji haujathibitishwa.',
            },
        },
    }
    for base_key, spec in localized_templates.items():
        for lang, content in spec['values'].items():
            template_rows.append(
                {
                    'key': f'{base_key}.{lang}',
                    'content': content,
                    'description': (
                        f"{spec['description']} [{lang}]"
                    ),
                }
            )
    for row in template_rows:
        stmt = pg_insert(st).values(**row)
        stmt = stmt.on_conflict_do_update(
            index_elements=['key'],
            set_={
                'description': row['description'],
                'content': row['content'],
            },
        )
        conn.execute(stmt)

    # Системные строки создаёт только app.release.initial_data.

    sys.stdout.write("0001: ok\n")


def downgrade() -> None:
    # Канон: downgrade не удаляет объекты.
    pass
