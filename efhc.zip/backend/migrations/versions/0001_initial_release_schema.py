# backend/migrations/versions/0001_initial_release_schema.py
# =====================================================================
# EFHC Bot — единая начальная release migration для PostgreSQL.
#
# Канон:
# - Истина = ORM (backend/app/models/**, Base.metadata).
# - 0001 — единственная pre-release revision после объединения цикла 1632.
# - создаёт финальную физическую schema с users.global_id, auth/identity,
#   owner FK, runtime control, dual-write compatibility и telemetry.
# - migrations 0002–0013 удалены из активной Alembic lineage.
#
# Критерии готовности:
# - существуют схемы: efhc_core, efhc_admin
# - создаются ORM-таблицы из Base.metadata (2 схемы)
# - проверка: pg_namespace + to_regclass(<schema>.<table>)
# - ключевое ограничение: uq_payment_intents_idempo
# - частичный уникальный индекс external tx hash для payment_intents
#   технический marker экономического ограничения объявлен ниже
#   хранится в ORM metadata и поэтому также входит в 0001
# - таблицы результата withdrawal также входят в 0001, поскольку
#   до post-release migration phase действует единая база schema
#
# Запреты:
# - raw SQL допускается только для identity runtime control, triggers и telemetry
# - никаких schema=... внутри sa.Column(...)
# =====================================================================

from __future__ import annotations

import importlib
import pkgutil
import sys
from pathlib import Path

import sqlalchemy as sa
from alembic import context as alembic_context
from alembic import op
from sqlalchemy.dialects.postgresql import insert as pg_insert

# Alembic запускается из extracted/backend (CWD = backend).
# В sys.path уже есть backend, но часть CI/локалки может ломаться.
_backend_dir = Path(__file__).resolve().parents[2]
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from app import models as models_pkg  # noqa: E402
from app.lib.ton_address import (  # noqa: E402
    TonAddressError,
    canonicalize_ton_address,
)
from app.models.base import Base  # noqa: E402
from app.release.database_contract import (  # noqa: E402
    EXPECTED_TABLE_COUNT,
    expected_tables,
)

ECONOMIC_GUARD_MARKER = (
    "payment_intents external tx hash partial unique index"
)

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def __schema__exists(conn: sa.Connection, name: str) -> bool:
    q = sa.text("SELECT 1 FROM pg_namespace WHERE nspname=:n")
    res = conn.execute(q, {"n": name})
    if res is None:
        return False
    return res.scalar() is not None



def _column_exists(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> bool:
    q = sa.text(
        "SELECT 1 FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return False
    return res.scalar() is not None


def _column_is_nullable(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> bool:
    q = sa.text(
        "SELECT is_nullable FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return False
    return str(res.scalar() or "").upper() == "YES"


def _column_char_max_length(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> int | None:
    q = sa.text(
        "SELECT character_maximum_length "
        "FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return None
    value = res.scalar()
    return int(value) if value is not None else None


def _column_numeric_precision_scale(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> tuple[int | None, int | None]:
    q = sa.text(
        "SELECT numeric_precision, numeric_scale "
        "FROM information_schema.columns "
        "WHERE table_schema=:s AND table_name=:t AND column_name=:c"
    )
    res = conn.execute(q, {"s": schema, "t": table, "c": column})
    if res is None:
        return None, None
    row = res.fetchone()
    if row is None:
        return None, None
    precision = getattr(row, "numeric_precision", None)
    scale = getattr(row, "numeric_scale", None)
    return (
        int(precision) if precision is not None else None,
        int(scale) if scale is not None else None,
    )


def _ensure_wallet_proof_columns(conn: sa.Connection) -> None:
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_verified",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_verified boolean NOT NULL "
                "DEFAULT false"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_verified=applied\n"
        )
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_verified_at",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_verified_at timestamptz NULL"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_time=applied\n"
        )
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_payload_hash",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_payload_hash text NULL"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_hash=applied\n"
        )
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "proof_source",
    ):
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.wallet_bindings "
                "ADD COLUMN proof_source text NULL"
            )
        )
        sys.stdout.write(
            "0001: security1429_wallet_proof_source=applied\n"
        )



def _backfill_wallet_bindings_canonical(conn: sa.Connection) -> None:
    """Приводит wallet_bindings к каноническому формату EFHC.

    Новая БД уже канонична: wallets_service нормализует адрес до insert.
    В старой БД могли сохраниться friendly/raw формы TON-адреса. Поскольку
    Alembic 0001 является единственной активной migration, совместимый
    backfill выполняется здесь идемпотентно.

    Если две строки сводятся к одному адресу, операция останавливается с
    точными id, не повреждая ownership. Коллизию оператор устраняет до
    повторного запуска upgrade.
    """
    if not _column_exists(
        conn,
        "efhc_core",
        "wallet_bindings",
        "wallet_address",
    ):
        return

    rows = (
        conn.execute(
            sa.text(
                "SELECT id, wallet_address "
                "FROM efhc_core.wallet_bindings "
                "WHERE wallet_address IS NOT NULL "
                "ORDER BY id ASC"
            )
        )
        .mappings()
        .all()
    )
    if not rows:
        return

    by_canonical: dict[str, list[int]] = {}
    updates: list[tuple[int, str]] = []
    invalid: list[int] = []
    for row in rows:
        row_id = int(row["id"])
        current = str(row["wallet_address"] or "").strip()
        try:
            canonical = canonicalize_ton_address(current)
        except TonAddressError:
            invalid.append(row_id)
            continue
        by_canonical.setdefault(canonical, []).append(row_id)
        if canonical != current:
            updates.append((row_id, canonical))

    collisions = {
        addr: ids for addr, ids in by_canonical.items() if len(ids) > 1
    }
    if collisions:
        details = "; ".join(
            f"{addr}=>{','.join(str(i) for i in ids)}"
            for addr, ids in sorted(collisions.items())
        )
        raise RuntimeError(
            "wallet_bindings canonical backfill collision: " + details
        )

    for row_id, canonical in updates:
        conn.execute(
            sa.text(
                "UPDATE efhc_core.wallet_bindings "
                "SET wallet_address=:addr, updated_at=timezone('utc', now()) "
                "WHERE id=:id"
            ),
            {"addr": canonical, "id": row_id},
        )

    sys.stdout.write(
        "0001: wallet_bindings_canonical_backfill="
        f"updated:{len(updates)} invalid:{len(invalid)}\n"
    )

def _apply_existing_schema_repairs(conn: sa.Connection) -> None:
    _ensure_wallet_proof_columns(conn)
    _backfill_wallet_bindings_canonical(conn)

    # Provider-neutral регистрация сохраняет Telegram только как
    # provider-атрибут. У TON-first invitee при первой регистрации нет
    # invitee_global_id, а invitee_global_id остаётся canonical owner.
    referral_invitee_needs_nullable = (
        _column_exists(
            conn,
            "efhc_core",
            "referral_links",
            "invitee_tg_id",
        )
        and not _column_is_nullable(
            conn,
            "efhc_core",
            "referral_links",
            "invitee_tg_id",
        )
    )
    if referral_invitee_needs_nullable:
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.referral_links "
                "ALTER COLUMN invitee_tg_id DROP NOT NULL"
            )
        )
        sys.stdout.write(
            "0001: referral_invitee_tg_nullable=applied\n"
        )

    # Канонический владелец — global_id. Telegram-поля становятся
    # необязательными provider-атрибутами, чтобы TON-only аккаунты
    # использовали те же финансовые и бизнес-пути.
    for table_name in (
        "efhc_transfers_log",
        "panels",
        "panels_archive",
        "withdraw_requests",
        "withdrawals",
        "payment_intents",
        "user_tasks_status",
        "task_bonus_log",
        "task_complete_lock",
        "ranks_snapshots",
        "ranks_top_cache",
    ):
        if (
            _column_exists(conn, "efhc_core", table_name, "tg_id")
            and not _column_is_nullable(
                conn, "efhc_core", table_name, "tg_id"
            )
        ):
            conn.execute(
                sa.text(
                    f"ALTER TABLE efhc_core.{table_name} "
                    "ALTER COLUMN tg_id DROP NOT NULL"
                )
            )
            sys.stdout.write(
                "0001: global_owner_legacy_tg_nullable="
                f"{table_name}.tg_id\n"
            )

    # Ремонт существующей схемы: SQLAlchemy metadata не добавляет
    # новый UNIQUE к уже созданной таблице. Индекс обеспечивает тот же
    # контракт идемпотентности для операций владельца global_id.
    if _column_exists(
        conn,
        "efhc_core",
        "payment_intents",
        "global_id",
    ):
        conn.execute(
            sa.text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "uq_payment_intents_global_idempo "
                "ON efhc_core.payment_intents "
                "(global_id, purpose, idempotency_key)"
            )
        )
        sys.stdout.write(
            "0001: payment_intents_global_idempo=ready\n"
        )

    # HEAL-0040: в БД до v169.88 поле payment_intents.package_id
    # могло остаться NOT NULL. Текущий контракт разрешает NULL
    # только для custom/package-less intents.
    package_id_needs_nullable = (
        _column_exists(
            conn,
            "efhc_core",
            "payment_intents",
            "package_id",
        )
        and not _column_is_nullable(
            conn,
            "efhc_core",
            "payment_intents",
            "package_id",
        )
    )
    if package_id_needs_nullable:
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.payment_intents "
                "ALTER COLUMN package_id DROP NOT NULL"
            )
        )
        sys.stdout.write(
            "0001: heal0040_package_id_nullable=applied\n"
        )

    # HEAL-0044: в старой БД direction мог остаться varchar(8).
    # Новая ORM metadata использует varchar(24); ALTER идемпотентен.
    if _column_exists(
        conn,
        "efhc_core",
        "efhc_transfers_log",
        "direction",
    ):
        current_len = _column_char_max_length(
            conn,
            "efhc_core",
            "efhc_transfers_log",
            "direction",
        )
        if current_len is not None and current_len < 24:
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.efhc_transfers_log "
                    "ALTER COLUMN direction TYPE varchar(24)"
                )
            )
            sys.stdout.write(
                "0001: heal0044_direction_varchar24=applied\n"
            )

    if _column_exists(
        conn,
        "efhc_core",
        "withdraw_requests",
        "amount",
    ):
        precision, scale = _column_numeric_precision_scale(
            conn,
            "efhc_core",
            "withdraw_requests",
            "amount",
        )
        if (precision, scale) != (30, 8):
            conn.execute(
                sa.text(
                    "ALTER TABLE efhc_core.withdraw_requests "
                    "ALTER COLUMN amount TYPE NUMERIC(30,8) "
                    "USING amount::numeric(30,8)"
                )
            )
            sys.stdout.write(
                "0001: withdraw_requests_amount_numeric30_8=applied\n"
            )

def _to_regclass(conn: sa.Connection, fq: str) -> bool:
    q = sa.text("SELECT to_regclass(:n)")
    res = conn.execute(q, {"n": fq})
    if res is None:
        return False
    return res.scalar() is not None


def __import___all__model_modules() -> None:
    # Канон: в Base.metadata должны попасть ВСЕ ORM-модели.
    #
    # app.models уже выполняет безопасный авто-импорт модельных модулей
    # при инициализации пакета. В alembic 0001 повторный жёсткий импорт
    # может заново дёргать декларативную регистрацию и ловить duplicate
    # table-definition drift на одном и том же MetaData.
    #
    # Поэтому здесь импортируем только ещё не загруженные *_models.py.
    loaded = set(getattr(models_pkg, "MODEL_MODULES_LOADED", []))
    for mod in pkgutil.iter_modules(models_pkg.__path__):
        if not mod.name.endswith("_models"):
            continue
        if mod.name == "order_models" or mod.name in loaded:
            continue
        importlib.import_module(f"{models_pkg.__name__}.{mod.name}")



CORE = "efhc_core"
ADMIN = "efhc_admin"

DirectSpec = tuple[str, str, str, str]

DIRECT_SPECS: tuple[DirectSpec, ...] = (
    (CORE, "panels", "tg_id", "global_id"),
    (CORE, "panels_archive", "tg_id", "global_id"),
    (
        CORE,
        "referral_links",
        "inviter_tg_id",
        "inviter_global_id",
    ),
    (
        CORE,
        "referral_links",
        "invitee_tg_id",
        "invitee_global_id",
    ),
    (
        CORE,
        "referral_codes",
        "inviter_tg_id",
        "inviter_global_id",
    ),
    (CORE, "referral_bonus_ledger", "tg_id", "global_id"),
    (CORE, "task_submissions", "tg_id", "global_id"),
    (
        CORE,
        "task_submissions",
        "moderator_tg_id",
        "moderator_global_id",
    ),
    (CORE, "user_tasks_status", "tg_id", "global_id"),
    (CORE, "task_bonus_log", "tg_id", "global_id"),
    (CORE, "task_complete_lock", "tg_id", "global_id"),
    (CORE, "ranks_snapshots", "tg_id", "global_id"),
    (CORE, "ranks_top_cache", "tg_id", "global_id"),
    (CORE, "ranks_user_snapshots", "tg_id", "global_id"),
    (CORE, "efhc_transfers_log", "tg_id", "global_id"),
    (CORE, "payment_intents", "tg_id", "global_id"),
    (CORE, "withdraw_requests", "tg_id", "global_id"),
    (CORE, "withdrawals", "tg_id", "global_id"),
    (
        CORE,
        "withdraw_outcome_events",
        "tg_id",
        "global_id",
    ),
    (CORE, "wallet_bindings", "tg_id", "global_id"),
    (
        CORE,
        "wallet_connect_idempotency",
        "tg_id",
        "global_id",
    ),
    (
        CORE,
        "wallet_proof_token_uses",
        "tg_id",
        "global_id",
    ),
    (CORE, "tx_hash_locks", "tg_id", "global_id"),
    (
        CORE,
        "ton_inbox_logs",
        "parsed_tg_id",
        "resolved_global_id",
    ),
    (ADMIN, "admin_whitelist", "tg_id", "global_id"),
    (
        ADMIN,
        "admin_whitelist",
        "added_by_tg_id",
        "added_by_global_id",
    ),
    (
        ADMIN,
        "admin_role",
        "granted_by_tg_id",
        "granted_by_global_id",
    ),
)


def _control_enabled_sql() -> str:
    return (
        "SELECT dual_write_enabled "
        f"FROM {CORE}.identity_migration_control "
        "WHERE singleton_id = 1"
    )


def _function_name(index: int) -> str:
    return f"efhc_1624_dual_write_{index:02d}"


def _trigger_name(index: int) -> str:
    return f"trg_1624_dual_write_{index:02d}"


def _direct_function_sql(spec: DirectSpec, index: int) -> str:
    function = _function_name(index)
    relation = f"{spec[0]}.{spec[1]}"
    return f"""
CREATE OR REPLACE FUNCTION {CORE}.{function}()
RETURNS trigger
LANGUAGE plpgsql
AS $efhc_1624$
DECLARE
    enabled boolean;
    resolved_global_id bigint;
BEGIN
    {_control_enabled_sql()} INTO enabled;
    IF coalesce(enabled, false) IS NOT TRUE THEN
        RETURN NEW;
    END IF;

    IF NEW.{spec[2]} IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT global_id
      INTO resolved_global_id
      FROM {CORE}.users
     WHERE tg_id = NEW.{spec[2]};

    IF resolved_global_id IS NULL THEN
        RAISE EXCEPTION
            '0001: orphan dual-write {relation}.{spec[2]}';
    END IF;

    IF NEW.{spec[3]} IS NOT NULL
       AND NEW.{spec[3]} <> resolved_global_id THEN
        RAISE EXCEPTION
            '0001: dual-write conflict {relation}.{spec[3]}';
    END IF;

    NEW.{spec[3]} := resolved_global_id;
    RETURN NEW;
END
$efhc_1624$
""".strip()


def _direct_trigger_sql(spec: DirectSpec, index: int) -> str:
    function = _function_name(index)
    trigger = _trigger_name(index)
    relation = f"{spec[0]}.{spec[1]}"
    return f"""
CREATE TRIGGER {trigger}
BEFORE INSERT OR UPDATE OF {spec[2]}, {spec[3]}
ON {relation}
FOR EACH ROW
EXECUTE FUNCTION {CORE}.{function}()
""".strip()


def _scheduler_function_sql() -> str:
    return f"""
CREATE OR REPLACE FUNCTION {CORE}.efhc_1624_dual_write_scheduler()
RETURNS trigger
LANGUAGE plpgsql
AS $efhc_1624$
DECLARE
    enabled boolean;
    payload_tg text;
    legacy_tg_id bigint;
    resolved_global_id bigint;
BEGIN
    {_control_enabled_sql()} INTO enabled;
    IF coalesce(enabled, false) IS NOT TRUE THEN
        RETURN NEW;
    END IF;

    IF NEW.task_name <> 'resync_user_energy' THEN
        RETURN NEW;
    END IF;

    payload_tg := NEW.payload ->> 'tg_id';
    IF payload_tg IS NULL THEN
        RETURN NEW;
    END IF;

    IF payload_tg !~ '^[0-9]+$' THEN
        RAISE EXCEPTION
            '0001: invalid scheduler payload tg_id';
    END IF;

    legacy_tg_id := payload_tg::bigint;
    SELECT global_id
      INTO resolved_global_id
      FROM {CORE}.users
     WHERE tg_id = legacy_tg_id;

    IF resolved_global_id IS NULL THEN
        RAISE EXCEPTION
            '0001: orphan scheduler payload tg_id';
    END IF;

    IF NEW.global_id IS NOT NULL
       AND NEW.global_id <> resolved_global_id THEN
        RAISE EXCEPTION
            '0001: scheduler dual-write conflict';
    END IF;

    NEW.global_id := resolved_global_id;
    RETURN NEW;
END
$efhc_1624$
""".strip()


def _admin_action_function_sql() -> str:
    return f"""
CREATE OR REPLACE FUNCTION {CORE}.efhc_1624_dual_write_admin_action()
RETURNS trigger
LANGUAGE plpgsql
AS $efhc_1624$
DECLARE
    enabled boolean;
    by_admin_pk bigint;
    by_tg_id bigint;
    resolved_global_id bigint;
BEGIN
    {_control_enabled_sql()} INTO enabled;
    IF coalesce(enabled, false) IS NOT TRUE THEN
        RETURN NEW;
    END IF;

    IF NEW.admin_id IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT global_id
      INTO by_admin_pk
      FROM {ADMIN}.admin_whitelist
     WHERE id = NEW.admin_id;

    SELECT global_id
      INTO by_tg_id
      FROM {CORE}.users
     WHERE tg_id = NEW.admin_id;

    IF by_admin_pk IS NOT NULL
       AND by_tg_id IS NOT NULL
       AND by_admin_pk <> by_tg_id THEN
        RAISE EXCEPTION
            '0001: ambiguous admin action owner';
    END IF;

    resolved_global_id := coalesce(by_admin_pk, by_tg_id);
    IF resolved_global_id IS NULL THEN
        RAISE EXCEPTION
            '0001: orphan admin action owner';
    END IF;

    IF NEW.actor_global_id IS NOT NULL
       AND NEW.actor_global_id <> resolved_global_id THEN
        RAISE EXCEPTION
            '0001: admin action dual-write conflict';
    END IF;

    NEW.actor_global_id := resolved_global_id;
    RETURN NEW;
END
$efhc_1624$
""".strip()


def _admin_idempotency_function_sql() -> str:
    return f"""
CREATE OR REPLACE FUNCTION {CORE}.efhc_1624_dual_write_admin_idempotency()
RETURNS trigger
LANGUAGE plpgsql
AS $efhc_1624$
DECLARE
    enabled boolean;
    resolved_global_id bigint;
BEGIN
    {_control_enabled_sql()} INTO enabled;
    IF coalesce(enabled, false) IS NOT TRUE THEN
        RETURN NEW;
    END IF;

    IF NEW.admin_id IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT global_id
      INTO resolved_global_id
      FROM {ADMIN}.admin_whitelist
     WHERE id = NEW.admin_id;

    IF resolved_global_id IS NULL THEN
        RAISE EXCEPTION
            '0001: orphan admin idempotency owner';
    END IF;

    IF NEW.global_id IS NOT NULL
       AND NEW.global_id <> resolved_global_id THEN
        RAISE EXCEPTION
            '0001: admin idempotency dual-write conflict';
    END IF;

    NEW.global_id := resolved_global_id;
    RETURN NEW;
END
$efhc_1624$
""".strip()


def _direct_telemetry_sql(spec: DirectSpec) -> str:
    relation = f"{spec[0]}.{spec[1]}"
    scope = f"{relation}.{spec[2]}->{spec[3]}"
    return f"""
SELECT
    '{scope}'::text AS scope,
    count(*) FILTER (
        WHERE d.{spec[2]} IS NOT NULL
    )::bigint AS legacy_rows,
    count(*) FILTER (
        WHERE d.{spec[3]} IS NOT NULL
    )::bigint AS shadow_rows,
    count(*) FILTER (
        WHERE d.{spec[2]} IS NOT NULL
          AND u.global_id IS NOT NULL
          AND d.{spec[3]} = u.global_id
    )::bigint AS matched_rows,
    count(*) FILTER (
        WHERE d.{spec[2]} IS NOT NULL
          AND u.global_id IS NOT NULL
          AND d.{spec[3]} IS NULL
    )::bigint AS fallback_rows,
    count(*) FILTER (
        WHERE d.{spec[2]} IS NOT NULL
          AND u.global_id IS NOT NULL
          AND d.{spec[3]} IS NOT NULL
          AND d.{spec[3]} <> u.global_id
    )::bigint AS mismatch_rows,
    count(*) FILTER (
        WHERE d.{spec[2]} IS NOT NULL
          AND u.global_id IS NULL
    )::bigint AS orphan_rows,
    count(*) FILTER (
        WHERE d.{spec[2]} IS NULL
          AND d.{spec[3]} IS NOT NULL
    )::bigint AS shadow_only_rows,
    0::bigint AS ambiguous_rows
FROM {relation} d
LEFT JOIN {CORE}.users u
  ON u.tg_id = d.{spec[2]}
""".strip()


def _scheduler_telemetry_sql() -> str:
    return f"""
SELECT
    '{CORE}.scheduler_task_log.payload.tg_id->global_id'::text AS scope,
    count(*) FILTER (
        WHERE d.legacy_tg_id IS NOT NULL
    )::bigint AS legacy_rows,
    count(*) FILTER (
        WHERE d.global_id IS NOT NULL
    )::bigint AS shadow_rows,
    count(*) FILTER (
        WHERE d.legacy_tg_id IS NOT NULL
          AND u.global_id IS NOT NULL
          AND d.global_id = u.global_id
    )::bigint AS matched_rows,
    count(*) FILTER (
        WHERE d.legacy_tg_id IS NOT NULL
          AND u.global_id IS NOT NULL
          AND d.global_id IS NULL
    )::bigint AS fallback_rows,
    count(*) FILTER (
        WHERE d.legacy_tg_id IS NOT NULL
          AND u.global_id IS NOT NULL
          AND d.global_id IS NOT NULL
          AND d.global_id <> u.global_id
    )::bigint AS mismatch_rows,
    count(*) FILTER (
        WHERE d.legacy_tg_id IS NOT NULL
          AND u.global_id IS NULL
    )::bigint AS orphan_rows,
    count(*) FILTER (
        WHERE d.legacy_tg_id IS NULL
          AND d.global_id IS NOT NULL
    )::bigint AS shadow_only_rows,
    0::bigint AS ambiguous_rows
FROM (
    SELECT
        source.global_id,
        CASE
            WHEN (source.payload ->> 'tg_id') ~ '^[0-9]+$'
            THEN (source.payload ->> 'tg_id')::bigint
            ELSE NULL
        END AS legacy_tg_id
    FROM {CORE}.scheduler_task_log source
    WHERE source.task_name = 'resync_user_energy'
) d
LEFT JOIN {CORE}.users u
  ON u.tg_id = d.legacy_tg_id
""".strip()


def _admin_action_telemetry_sql() -> str:
    return f"""
SELECT
    '{ADMIN}.admin_action_log.admin_id->actor_global_id'::text AS scope,
    count(*) FILTER (
        WHERE d.admin_id IS NOT NULL
    )::bigint AS legacy_rows,
    count(*) FILTER (
        WHERE d.actor_global_id IS NOT NULL
    )::bigint AS shadow_rows,
    count(*) FILTER (
        WHERE d.expected_global_id IS NOT NULL
          AND d.actor_global_id = d.expected_global_id
    )::bigint AS matched_rows,
    count(*) FILTER (
        WHERE d.expected_global_id IS NOT NULL
          AND d.actor_global_id IS NULL
    )::bigint AS fallback_rows,
    count(*) FILTER (
        WHERE d.expected_global_id IS NOT NULL
          AND d.actor_global_id IS NOT NULL
          AND d.actor_global_id <> d.expected_global_id
    )::bigint AS mismatch_rows,
    count(*) FILTER (
        WHERE d.admin_id IS NOT NULL
          AND d.expected_global_id IS NULL
          AND NOT d.ambiguous
    )::bigint AS orphan_rows,
    count(*) FILTER (
        WHERE d.admin_id IS NULL
          AND d.actor_global_id IS NOT NULL
    )::bigint AS shadow_only_rows,
    count(*) FILTER (
        WHERE d.ambiguous
    )::bigint AS ambiguous_rows
FROM (
    SELECT
        resolved.admin_id,
        resolved.actor_global_id,
        CASE
            WHEN resolved.by_admin_pk IS NOT NULL
             AND resolved.by_tg_id IS NOT NULL
             AND resolved.by_admin_pk <> resolved.by_tg_id
            THEN NULL
            ELSE coalesce(
                resolved.by_admin_pk,
                resolved.by_tg_id
            )
        END AS expected_global_id,
        (
            resolved.by_admin_pk IS NOT NULL
            AND resolved.by_tg_id IS NOT NULL
            AND resolved.by_admin_pk <> resolved.by_tg_id
        ) AS ambiguous
    FROM (
        SELECT
            source.admin_id,
            source.actor_global_id,
            aw.global_id AS by_admin_pk,
            u.global_id AS by_tg_id
        FROM {ADMIN}.admin_action_log source
        LEFT JOIN {ADMIN}.admin_whitelist aw
          ON aw.id = source.admin_id
        LEFT JOIN {CORE}.users u
          ON u.tg_id = source.admin_id
    ) resolved
) d
""".strip()


def _admin_idempotency_telemetry_sql() -> str:
    return f"""
SELECT
    '{ADMIN}.idempotency_key.admin_id->global_id'::text AS scope,
    count(*) FILTER (
        WHERE d.admin_id IS NOT NULL
    )::bigint AS legacy_rows,
    count(*) FILTER (
        WHERE d.global_id IS NOT NULL
    )::bigint AS shadow_rows,
    count(*) FILTER (
        WHERE aw.global_id IS NOT NULL
          AND d.global_id = aw.global_id
    )::bigint AS matched_rows,
    count(*) FILTER (
        WHERE aw.global_id IS NOT NULL
          AND d.global_id IS NULL
    )::bigint AS fallback_rows,
    count(*) FILTER (
        WHERE aw.global_id IS NOT NULL
          AND d.global_id IS NOT NULL
          AND d.global_id <> aw.global_id
    )::bigint AS mismatch_rows,
    count(*) FILTER (
        WHERE d.admin_id IS NOT NULL
          AND aw.id IS NULL
    )::bigint AS orphan_rows,
    count(*) FILTER (
        WHERE d.admin_id IS NULL
          AND d.global_id IS NOT NULL
    )::bigint AS shadow_only_rows,
    0::bigint AS ambiguous_rows
FROM {ADMIN}.idempotency_key d
LEFT JOIN {ADMIN}.admin_whitelist aw
  ON aw.id = d.admin_id
""".strip()


def _telemetry_view_sql() -> str:
    selects = [_direct_telemetry_sql(spec) for spec in DIRECT_SPECS]
    selects.extend(
        (
            _scheduler_telemetry_sql(),
            _admin_action_telemetry_sql(),
            _admin_idempotency_telemetry_sql(),
        )
    )
    body = "\nUNION ALL\n".join(selects)
    return (
        f"CREATE OR REPLACE VIEW {CORE}."
        "identity_ownership_shadow_telemetry AS\n"
        f"{body}"
    )



OWNER_TRIGGER_SPECS: tuple[tuple[str, str, str], ...] = (
    (
        "shop_orders",
        "efhc_1628_shop_order_owner",
        "trg_1628_shop_order_owner",
    ),
    (
        "user_skins",
        "efhc_1628_user_skin_owner",
        "trg_1628_user_skin_owner",
    ),
    (
        "user_cosmetics",
        "efhc_1628_user_cosmetics_owner",
        "trg_1628_user_cosmetics_owner",
    ),
)


def _owner_function_sql(table: str, function: str) -> str:
    relation = f"{CORE}.{table}"
    return f"""
CREATE OR REPLACE FUNCTION {CORE}.{function}()
RETURNS trigger
LANGUAGE plpgsql
AS $efhc_release_owner$
DECLARE
    dual_enabled boolean;
    legacy_ok boolean;
    resolved_global_id bigint;
BEGIN
    SELECT dual_write_enabled, legacy_authoritative
      INTO dual_enabled, legacy_ok
      FROM {CORE}.identity_migration_control
     WHERE singleton_id = 1;

    IF coalesce(legacy_ok, false) IS NOT TRUE THEN
        RAISE EXCEPTION '0001: legacy_authoritative is not ready';
    END IF;

    IF NEW.tg_id IS NOT NULL THEN
        SELECT global_id
          INTO resolved_global_id
          FROM {CORE}.users
         WHERE tg_id = NEW.tg_id;

        IF resolved_global_id IS NULL THEN
            RAISE EXCEPTION '0001: orphan owner {relation}.tg_id';
        END IF;

        IF NEW.global_id IS NOT NULL
           AND NEW.global_id <> resolved_global_id THEN
            RAISE EXCEPTION
                '0001: owner conflict {relation}.global_id';
        END IF;

        IF coalesce(dual_enabled, false) IS TRUE THEN
            NEW.global_id := resolved_global_id;
        END IF;
    ELSIF NEW.global_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
              FROM {CORE}.users
             WHERE global_id = NEW.global_id
        ) THEN
            RAISE EXCEPTION
                '0001: orphan global owner {relation}.global_id';
        END IF;
    END IF;

    RETURN NEW;
END
$efhc_release_owner$
""".strip()


def _identity_control_table_sql() -> str:
    return f"""
CREATE TABLE IF NOT EXISTS {CORE}.identity_migration_control (
    singleton_id smallint NOT NULL,
    dual_write_enabled boolean NOT NULL DEFAULT true,
    shadow_read_enabled boolean NOT NULL DEFAULT true,
    legacy_authoritative boolean NOT NULL DEFAULT true,
    nonfinancial_read_global_id_enabled boolean NOT NULL DEFAULT true,
    nonfinancial_read_rollback_ready boolean NOT NULL DEFAULT true,
    nonfinancial_read_switched_at timestamptz NULL DEFAULT now(),
    financial_read_global_id_enabled boolean NOT NULL DEFAULT true,
    financial_read_rollback_ready boolean NOT NULL DEFAULT true,
    financial_read_switched_at timestamptz NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_identity_migration_control
        PRIMARY KEY (singleton_id),
    CONSTRAINT ck_identity_migration_control_singleton
        CHECK (singleton_id = 1),
    CONSTRAINT ck_identity_migration_control_legacy_authoritative
        CHECK (legacy_authoritative),
    CONSTRAINT ck_identity_migration_control_nonfinancial_read
        CHECK (
            NOT nonfinancial_read_global_id_enabled
            OR (shadow_read_enabled AND legacy_authoritative)
        ),
    CONSTRAINT ck_identity_migration_control_financial_read
        CHECK (
            NOT financial_read_global_id_enabled
            OR (
                dual_write_enabled
                AND shadow_read_enabled
                AND legacy_authoritative
                AND nonfinancial_read_global_id_enabled
            )
        )
)
""".strip()


def _install_identity_release_runtime(conn: sa.Connection) -> None:
    conn.execute(sa.text(_identity_control_table_sql()))
    conn.execute(
        sa.text(
            f"""
INSERT INTO {CORE}.identity_migration_control (
    singleton_id,
    dual_write_enabled,
    shadow_read_enabled,
    legacy_authoritative,
    nonfinancial_read_global_id_enabled,
    nonfinancial_read_rollback_ready,
    nonfinancial_read_switched_at,
    financial_read_global_id_enabled,
    financial_read_rollback_ready,
    financial_read_switched_at,
    updated_at
) VALUES (
    1, true, true, true, true, true, now(), true, true, now(), now()
)
ON CONFLICT (singleton_id) DO UPDATE SET
    dual_write_enabled = true,
    shadow_read_enabled = true,
    legacy_authoritative = true,
    nonfinancial_read_global_id_enabled = true,
    nonfinancial_read_rollback_ready = true,
    nonfinancial_read_switched_at = coalesce(
        {CORE}.identity_migration_control.nonfinancial_read_switched_at,
        now()
    ),
    financial_read_global_id_enabled = true,
    financial_read_rollback_ready = true,
    financial_read_switched_at = coalesce(
        {CORE}.identity_migration_control.financial_read_switched_at,
        now()
    ),
    updated_at = now()
"""
        )
    )

    for index, spec in enumerate(DIRECT_SPECS, start=1):
        conn.execute(sa.text(_direct_function_sql(spec, index)))
        conn.execute(
            sa.text(
                f"DROP TRIGGER IF EXISTS {_trigger_name(index)} "
                f"ON {spec[0]}.{spec[1]}"
            )
        )
        conn.execute(sa.text(_direct_trigger_sql(spec, index)))

    conn.execute(sa.text(_scheduler_function_sql()))
    conn.execute(
        sa.text(
            f"DROP TRIGGER IF EXISTS trg_1624_dual_write_scheduler "
            f"ON {CORE}.scheduler_task_log"
        )
    )
    conn.execute(
        sa.text(
            f"""
CREATE TRIGGER trg_1624_dual_write_scheduler
BEFORE INSERT OR UPDATE OF task_name, payload, global_id
ON {CORE}.scheduler_task_log
FOR EACH ROW
EXECUTE FUNCTION {CORE}.efhc_1624_dual_write_scheduler()
"""
        )
    )

    conn.execute(sa.text(_admin_action_function_sql()))
    conn.execute(
        sa.text(
            f"DROP TRIGGER IF EXISTS trg_1624_dual_write_admin_action "
            f"ON {ADMIN}.admin_action_log"
        )
    )
    conn.execute(
        sa.text(
            f"""
CREATE TRIGGER trg_1624_dual_write_admin_action
BEFORE INSERT OR UPDATE OF admin_id, actor_global_id
ON {ADMIN}.admin_action_log
FOR EACH ROW
EXECUTE FUNCTION {CORE}.efhc_1624_dual_write_admin_action()
"""
        )
    )

    conn.execute(sa.text(_admin_idempotency_function_sql()))
    conn.execute(
        sa.text(
            f"DROP TRIGGER IF EXISTS trg_1624_dual_write_admin_idempotency "
            f"ON {ADMIN}.idempotency_key"
        )
    )
    conn.execute(
        sa.text(
            f"""
CREATE TRIGGER trg_1624_dual_write_admin_idempotency
BEFORE INSERT OR UPDATE OF admin_id, global_id
ON {ADMIN}.idempotency_key
FOR EACH ROW
EXECUTE FUNCTION {CORE}.efhc_1624_dual_write_admin_idempotency()
"""
        )
    )

    for table, function, trigger in OWNER_TRIGGER_SPECS:
        conn.execute(sa.text(_owner_function_sql(table, function)))
        conn.execute(
            sa.text(
                f"DROP TRIGGER IF EXISTS {trigger} ON {CORE}.{table}"
            )
        )
        conn.execute(
            sa.text(
                f"""
CREATE TRIGGER {trigger}
BEFORE INSERT OR UPDATE OF tg_id, global_id
ON {CORE}.{table}
FOR EACH ROW
EXECUTE FUNCTION {CORE}.{function}()
"""
            )
        )

    conn.execute(sa.text(_telemetry_view_sql()))


def _validate_release_identity_schema(conn: sa.Connection) -> None:
    physical = conn.execute(
        sa.text(
            """
SELECT
    count(*) FILTER (WHERE column_name = 'global_id') AS global_columns,
    count(*) FILTER (WHERE column_name = 'user_id') AS legacy_columns
FROM information_schema.columns
WHERE table_schema = 'efhc_core' AND table_name = 'users'
"""
        )
    ).mappings().one()
    if int(physical["global_columns"] or 0) != 1:
        raise RuntimeError("0001: users.global_id physical column missing")
    if int(physical["legacy_columns"] or 0) != 0:
        raise RuntimeError("0001: users.user_id physical column forbidden")

    sequence = conn.execute(
        sa.text(
            "SELECT pg_get_serial_sequence("
            "'efhc_core.users', 'global_id')"
        )
    ).scalar()
    if sequence != "efhc_core.users_global_id_seq":
        raise RuntimeError(
            "0001: users.global_id sequence ownership mismatch"
        )

    fk_total = conn.execute(
        sa.text(
            """
SELECT count(*)
FROM pg_constraint c
JOIN pg_attribute a
  ON a.attrelid = c.confrelid
 AND a.attnum = ANY(c.confkey)
WHERE c.contype = 'f'
  AND c.confrelid = 'efhc_core.users'::regclass
  AND a.attname = 'global_id'
"""
        )
    ).scalar()
    if int(fk_total or 0) != 39:
        raise RuntimeError(
            f"0001: expected 39 global owner FK, got {fk_total}"
        )

    control = conn.execute(
        sa.text(
            f"""
SELECT
    dual_write_enabled,
    shadow_read_enabled,
    legacy_authoritative,
    nonfinancial_read_global_id_enabled,
    nonfinancial_read_rollback_ready,
    financial_read_global_id_enabled,
    financial_read_rollback_ready
FROM {CORE}.identity_migration_control
WHERE singleton_id = 1
"""
        )
    ).mappings().one_or_none()
    if control is None or not all(bool(value) for value in control.values()):
        raise RuntimeError("0001: identity runtime control is not ready")

    telemetry = conn.execute(
        sa.text(
            "SELECT to_regclass("
            "'efhc_core.identity_ownership_shadow_telemetry')"
        )
    ).scalar()
    if telemetry is None:
        raise RuntimeError("0001: identity telemetry view missing")

def upgrade() -> None:
    conn = op.get_bind()
    offline = bool(alembic_context.is_offline_mode())

    # Диагностика: какая БД/схема видна в Alembic-сессии.
    # В offline режиме нет живого коннекта.
    if not offline:
        try:
            db = conn.execute(sa.text("SELECT current_database()"))
            db = db.scalar()
            sp = conn.execute(sa.text("SHOW search_path")).scalar()
            sys.stdout.write(f"0001: db={db}\n")
            sys.stdout.write(f"0001: search_path={sp}\n")
        except Exception:
            sys.stdout.write("0001: db_diag_unavailable\n")
    # 1) Схемы создаются в env.py (AUTOCOMMIT), здесь не трогаем.

    # 2) ORM-таблицы создаём по schema, заданной в моделях.
    # Для без-schema таблиц применяем schema_translate_map -> efhc_core.
    conn.execute(sa.text("SET search_path TO efhc_core, efhc_admin"))
    conn2 = conn.execution_options(
        schema_translate_map={None: "efhc_core"}
    )

    # 2.1) Импортируем все модели, затем создаём таблицы
    __import___all__model_modules()

    sys.stdout.write(
        f"0001: metadata_tables={len(Base.metadata.tables)}\n"
    )

    required_fq = {
        "efhc_core.users",
        "efhc_core.user_identities",
        "efhc_core.auth_challenges",
        "efhc_core.auth_sessions",
        "efhc_core.user_roles",
        "efhc_core.withdraw_requests",
        "efhc_core.payment_intents",
        "efhc_core.withdraw_outcome_events",
        "efhc_core.outcome_fallback_promos",
        "efhc_core.tasks",
        "efhc_core.task_submissions",
        "efhc_core.user_tasks_status",
        "efhc_core.task_bonus_log",
        "efhc_core.task_complete_lock",
        "efhc_admin.efhc_sale_packages",
    }
    md_keys = set(Base.metadata.tables.keys())
    missing_md = sorted([t for t in required_fq if t not in md_keys])
    if missing_md:
        raise RuntimeError(
            "0001 sanity failed; missing in Base.metadata: "
            + ", ".join(missing_md)
        )

    # CI может запускать `alembic upgrade head` больше одного раза в
    # одной и той же БД. Держим 0001 идемпотентной, чтобы не ловить
    # DuplicateObject на ENUM и повторные CREATE TABLE.
    Base.metadata.create_all(bind=conn2, checkfirst=True)

    if not offline:
        conn.execute(
            sa.text(
                "ALTER SEQUENCE efhc_core.users_global_id_seq "
                "OWNED BY efhc_core.users.global_id"
            )
        )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.users ALTER COLUMN global_id "
                "SET DEFAULT nextval("
                "'efhc_core.users_global_id_seq'::regclass)"
            )
        )
        _install_identity_release_runtime(conn)

    # Диагностика: сколько таблиц реально есть в core/admin.
    if not offline:
        try:
            q = sa.text(
                "SELECT count(*) FROM pg_class c "
                "JOIN pg_namespace n ON n.oid=c.relnamespace "
                "WHERE c.relkind='r' AND n.nspname IN (:c,:a)"
            )
            cnt = conn.execute(
                q, {"c": "efhc_core", "a": "efhc_admin"}
            ).scalar()
            sys.stdout.write(f"0001: tables_in_schemas={cnt}\n")
        except Exception:
            sys.stdout.write("0001: tables_in_schemas=unknown\n")

    # Старой БД нужны явные исправления контракта: create_all()
    # не меняет существующие колонки. Исправления идут до проверок.
    if not offline:
        _apply_existing_schema_repairs(conn)

    # Сигнал в CI: дошли до DDL.
    sys.stdout.write("0001: create__all__done\n")

    # 3) Sanity-check (детерминированный)
    # В offline режиме Alembic генерирует SQL без подключения к БД.
    # Sanity проверки там запрещены.
    if not offline:
        missing: list[str] = []

        if not __schema__exists(conn, "efhc_core"):
            missing.append("schema:efhc_core")
        if not __schema__exists(conn, "efhc_admin"):
            missing.append("schema:efhc_admin")

        tables = sorted(Base.metadata.tables.keys())

        contract_tables = expected_tables()
        if len(tables) != EXPECTED_TABLE_COUNT:
            missing.append(
                "tables_count_expected_"
                f"{EXPECTED_TABLE_COUNT}_got_{len(tables)}"
            )
        actual_contract = {
            (str(table.schema or ""), str(table.name))
            for table in Base.metadata.sorted_tables
            if table.schema in {"efhc_core", "efhc_admin"}
        }
        if actual_contract != contract_tables:
            missing.append("ORM_metadata_contract_mismatch")

        for t in tables:
            fq = t if "." in t else f"efhc_core.{t}"
            if not _to_regclass(conn, fq):
                missing.append(fq)

        required_columns = {
            ("efhc_core", "users", "global_id"),
            ("efhc_core", "users", "tg_id"),
            ("efhc_core", "users", "main_balance"),
            ("efhc_core", "users", "bonus_balance"),
            ("efhc_core", "users", "available_kwh"),
            ("efhc_core", "users", "total_generated_kwh"),
            ("efhc_core", "users", "exchanged_kwh_total"),
            ("efhc_core", "users", "ton_wallet"),
            ("efhc_core", "users", "is_vip"),
            ("efhc_core", "users", "meta"),
            ("efhc_core", "withdraw_requests", "tg_id"),
            ("efhc_core", "withdraw_requests", "amount"),
            ("efhc_core", "withdraw_requests", "status"),
            ("efhc_core", "withdraw_requests", "idempotency_key"),
            ("efhc_core", "withdraw_requests", "hold_done"),
            ("efhc_core", "withdraw_requests", "refund_done"),
            ("efhc_core", "withdraw_requests", "tx_hash"),
            (
                "efhc_core",
                "withdraw_requests",
                "processing_idempotency_key",
            ),
            ("efhc_core", "payment_intents", "tg_id"),
            ("efhc_core", "payment_intents", "purpose"),
            ("efhc_core", "payment_intents", "package_id"),
            ("efhc_core", "payment_intents", "asset"),
            ("efhc_core", "payment_intents", "amount_asset_d8"),
            ("efhc_core", "payment_intents", "efhc_amount_d8"),
            ("efhc_core", "payment_intents", "status"),
            ("efhc_core", "payment_intents", "idempotency_key"),
            ("efhc_core", "payment_intents", "payload"),
            ("efhc_core", "payment_intents", "external_tx_hash"),
            ("efhc_core", "panels", "tg_id"),
            ("efhc_core", "panels", "is_active"),
            ("efhc_core", "panels", "is_archived"),
            ("efhc_core", "panels", "base_gen_per_sec"),
            ("efhc_core", "panels", "generated_kwh"),
            ("efhc_core", "shop_orders", "tg_id"),
            ("efhc_core", "shop_orders", "type"),
            ("efhc_core", "shop_orders", "status"),
            ("efhc_core", "shop_orders", "quantity_efhc"),
            ("efhc_core", "shop_orders", "tx_hash"),
            ("efhc_core", "shop_orders", "payment_error_log"),
            ("efhc_core", "efhc_transfers_log", "tg_id"),
            ("efhc_core", "efhc_transfers_log", "amount"),
            ("efhc_core", "efhc_transfers_log", "direction"),
            ("efhc_core", "efhc_transfers_log", "balance_type"),
            ("efhc_core", "efhc_transfers_log", "reason"),
            ("efhc_core", "efhc_transfers_log", "idempotency_key"),
            ("efhc_core", "bank_balance", "key"),
            ("efhc_core", "bank_balance", "balance"),
            ("efhc_core", "wallet_bindings", "tg_id"),
            ("efhc_core", "wallet_bindings", "wallet_address"),
            ("efhc_core", "wallet_bindings", "proof_verified"),
            ("efhc_core", "wallet_bindings", "proof_verified_at"),
            ("efhc_core", "wallet_bindings", "proof_payload_hash"),
            ("efhc_core", "wallet_bindings", "proof_source"),
            (
                "efhc_core",
                "wallet_connect_idempotency",
                "idempotency_key",
            ),
            (
                "efhc_core",
                "wallet_proof_token_uses",
                "proof_payload_hash",
            ),
            ("efhc_core", "tasks", "bonus_efhc"),
            ("efhc_core", "tasks", "meta"),
            ("efhc_core", "task_submissions", "bonus_amount_efhc"),
            ("efhc_core", "task_bonus_log", "amount_bonus_efhc"),
            ("efhc_core", "user_tasks_status", "task_code"),
            ("efhc_core", "task_complete_lock", "credited"),
        }
        for schema, table, column in sorted(required_columns):
            if not _column_exists(conn, schema, table, column):
                missing.append(f"{schema}.{table}.{column}")

        if not _column_is_nullable(
            conn,
            "efhc_core",
            "payment_intents",
            "package_id",
        ):
            missing.append(
                "efhc_core.payment_intents.package_id_nullable"
            )

        direction_len = _column_char_max_length(
            conn,
            "efhc_core",
            "efhc_transfers_log",
            "direction",
        )
        if direction_len is None or direction_len < 24:
            missing.append(
                "efhc_core.efhc_transfers_log.direction_varchar24"
            )

        if missing:
            raise RuntimeError(
                "0001 sanity failed; missing objects: "
                + ", ".join(missing)
            )

        _validate_release_identity_schema(conn)

# Жёсткая проверка: после create_all таблицы видимы.
# (проверка через to_regclass)
        missing = []
        for fq in sorted(required_fq):
            got = conn.execute(
                sa.text("SELECT to_regclass(:n)"), {"n": fq}
            )
            if got.scalar() is None:
                missing.append(fq)
        if missing:
            msg = "0001: missing_after_create_all=" + ",".join(missing)
            raise RuntimeError(msg)


    # Migration создаёт только bank schema. Идемпотентный
    # production bootstrap владеет начальными BANK_EFHC и EFHC_MAIN.
    # Отсутствие значений в Alembic исключает сброс balances и делает
    # повторные upgrade безопасными для данных.

    st = sa.Table(
        'system_templates',
        sa.MetaData(),
        sa.Column('key', sa.String(), nullable=False),
        sa.Column('content', sa.Text(), nullable=True),
        sa.Column('description', sa.String(), nullable=False),
        schema='efhc_core',
    )
    template_rows = [
        {
            'key': 'task_reject_fallback',
            'content': 'Выполнение не подтверждено.',
            'description': 'Автоответ при отклонении задания',
        },
        {
            'key': 'task_approve_fallback',
            'content': None,
            'description': 'Автоответ при одобрении задания',
        },
    ]
    localized_templates = {
        'task_approve_prefix': {
            'description': 'Префикс уведомления: задание подтверждено',
            'values': {
                'en': '✅ Task approved.',
                'ru': '✅ Задание подтверждено.',
                'uk': '✅ Завдання підтверджено.',
                'de': '✅ Aufgabe bestätigt.',
                'fr': '✅ Tâche confirmée.',
                'es': '✅ Tarea confirmada.',
                'it': '✅ Attività confermata.',
                'tr': '✅ Görev onaylandı.',
                'pl': '✅ Zadanie potwierdzone.',
                'da': '✅ Opgaven er bekræftet.',
                'hi': '✅ कार्य की पुष्टि हो गई।',
                'id': '✅ Tugas dikonfirmasi.',
                'sw': '✅ Kazi imethibitishwa.',
            },
        },
        'task_reject_prefix': {
            'description': 'Префикс уведомления: задание отклонено',
            'values': {
                'en': '⚠️ Task rejected.',
                'ru': '⚠️ Задание отклонено.',
                'uk': '⚠️ Завдання відхилено.',
                'de': '⚠️ Aufgabe abgelehnt.',
                'fr': '⚠️ Tâche refusée.',
                'es': '⚠️ Tarea rechazada.',
                'it': '⚠️ Attività rifiutata.',
                'tr': '⚠️ Görev reddedildi.',
                'pl': '⚠️ Zadanie odrzucone.',
                'da': '⚠️ Opgaven blev afvist.',
                'hi': '⚠️ कार्य अस्वीकृत किया गया।',
                'id': '⚠️ Tugas ditolak.',
                'sw': '⚠️ Kazi imekataliwa.',
            },
        },
        'task_approve_fallback': {
            'description': 'Fallback-комментарий: задание подтверждено',
            'values': {
                'en': 'Task result confirmed.',
                'ru': 'Результат задания подтвержден.',
                'uk': 'Результат завдання підтверджено.',
                'de': 'Das Ergebnis der Aufgabe wurde bestätigt.',
                'fr': 'Le résultat de la tâche a été confirmé.',
                'es': 'El resultado de la tarea fue confirmado.',
                'it': "Il risultato dell'attività è stato confermato.",
                'tr': 'Görev sonucu doğrulandı.',
                'pl': 'Wynik zadania został potwierdzony.',
                'da': 'Opgavens resultat er bekræftet.',
                'hi': 'कार्य का परिणाम पुष्टि कर दिया गया है।',
                'id': 'Hasil tugas telah dikonfirmasi.',
                'sw': 'Matokeo ya kazi yamehakikishwa.',
            },
        },
        'task_reject_fallback': {
            'description': 'Fallback-комментарий: задание отклонено',
            'values': {
                'en': 'Task result was not confirmed.',
                'ru': 'Выполнение не подтверждено.',
                'uk': 'Виконання не підтверджено.',
                'de': 'Die Ausführung wurde nicht bestätigt.',
                'fr': "L'exécution n'a pas été confirmée.",
                'es': 'La ejecución no fue confirmada.',
                'it': "L'esecuzione non è stata confermata.",
                'tr': 'Tamamlama doğrulanmadı.',
                'pl': 'Wykonanie nie zostało potwierdzone.',
                'da': 'Udførelsen blev ikke bekræftet.',
                'hi': 'कार्य पूरा होने की पुष्टि नहीं हुई।',
                'id': 'Penyelesaian tidak dikonfirmasi.',
                'sw': 'Utekelezaji haujathibitishwa.',
            },
        },
    }
    for base_key, spec in localized_templates.items():
        for lang, content in spec['values'].items():
            template_rows.append(
                {
                    'key': f'{base_key}.{lang}',
                    'content': content,
                    'description': (
                        f"{spec['description']} [{lang}]"
                    ),
                }
            )
    for row in template_rows:
        stmt = pg_insert(st).values(**row)
        stmt = stmt.on_conflict_do_update(
            index_elements=['key'],
            set_={
                'description': row['description'],
                'content': row['content'],
            },
        )
        conn.execute(stmt)

    # Системные строки создаёт только app.release.initial_data.

    sys.stdout.write("0001: ok\n")


def downgrade() -> None:
    # Канон: downgrade не удаляет объекты.
    pass
