# backend/migrations/versions/0001_initial_release_schema.py
# =====================================================================
# EFHC Bot — clean ORM-driven initial release schema для PostgreSQL.
#
# Greenfield CANON:
# - это единственная Alembic revision; 0002+ отсутствуют;
# - первый production launch создаётся на чистой БД, historical repair
#   choreography не является частью release schema;
# - ORM Base.metadata является полным физическим schema authority;
# - users.global_id — физический PK и единственный user business owner;
# - provider identity хранится в user_identities, TON ownership — только
#   в wallet_bindings; users.id/tg_id/ton_wallet отсутствуют;
# - panels_archive и legacy ranks_* tables retired по owner decision.
# =====================================================================

from __future__ import annotations

import importlib
import pkgutil
import sys
from pathlib import Path

import sqlalchemy as sa
from alembic import context as alembic_context
from alembic import op
from sqlalchemy.dialects.postgresql import insert as pg_insert

_backend_dir = Path(__file__).resolve().parents[2]
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from app import models as models_pkg  # noqa: E402
from app.models.base import Base  # noqa: E402
from app.release.database_contract import (  # noqa: E402
    EXPECTED_TABLE_COUNT,
    expected_tables,
)

ECONOMIC_GUARD_MARKER = (
    "payment_intents external tx hash partial unique index"
)

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

CORE = "efhc_core"
ADMIN = "efhc_admin"

_REQUIRED_FQ = frozenset(
    {
        "efhc_core.users",
        "efhc_core.user_identities",
        "efhc_core.auth_challenges",
        "efhc_core.auth_sessions",
        "efhc_core.user_roles",
        "efhc_core.wallet_bindings",
        "efhc_core.wallet_connect_idempotency",
        "efhc_core.wallet_proof_token_uses",
        "efhc_core.withdraw_requests",
        "efhc_core.payment_intents",
        "efhc_core.withdraw_outcome_events",
        "efhc_core.outcome_fallback_promos",
        "efhc_core.panels",
        "efhc_core.tasks",
        "efhc_core.task_submissions",
        "efhc_core.user_tasks_status",
        "efhc_core.task_bonus_log",
        "efhc_core.task_complete_lock",
        "efhc_admin.efhc_sale_packages",
    }
)

_REQUIRED_METADATA_NAMES = frozenset(
    {
        "uq_payment_intents_global_idempo",
        "ck_users_superadmin_global_id_reserved",
    }
)


def _schema_exists(conn: sa.Connection, name: str) -> bool:
    result = conn.execute(
        sa.text("SELECT 1 FROM pg_namespace WHERE nspname=:name"),
        {"name": name},
    )
    return result.scalar() is not None


def _to_regclass(conn: sa.Connection, fq_name: str) -> bool:
    result = conn.execute(
        sa.text("SELECT to_regclass(:name)"),
        {"name": fq_name},
    )
    return result.scalar() is not None


def _column_exists(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> bool:
    result = conn.execute(
        sa.text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_schema=:schema AND table_name=:table "
            "AND column_name=:column"
        ),
        {"schema": schema, "table": table, "column": column},
    )
    return result.scalar() is not None


def _column_is_nullable(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> bool:
    value = conn.execute(
        sa.text(
            "SELECT is_nullable FROM information_schema.columns "
            "WHERE table_schema=:schema AND table_name=:table "
            "AND column_name=:column"
        ),
        {"schema": schema, "table": table, "column": column},
    ).scalar()
    return value == "YES"


def _column_char_max_length(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> int | None:
    value = conn.execute(
        sa.text(
            "SELECT character_maximum_length "
            "FROM information_schema.columns "
            "WHERE table_schema=:schema AND table_name=:table "
            "AND column_name=:column"
        ),
        {"schema": schema, "table": table, "column": column},
    ).scalar()
    return int(value) if value is not None else None


def _column_data_type(
    conn: sa.Connection,
    schema: str,
    table: str,
    column: str,
) -> str | None:
    value = conn.execute(
        sa.text(
            "SELECT data_type FROM information_schema.columns "
            "WHERE table_schema=:schema AND table_name=:table "
            "AND column_name=:column"
        ),
        {"schema": schema, "table": table, "column": column},
    ).scalar()
    return str(value) if value is not None else None


def _import_all_model_modules() -> None:
    """Загрузить все *_models.py ровно один раз перед чтением metadata."""
    loaded = set(getattr(models_pkg, "MODEL_MODULES_LOADED", []))
    for module in pkgutil.iter_modules(models_pkg.__path__):
        if not module.name.endswith("_models") or module.name in loaded:
            continue
        importlib.import_module(f"{models_pkg.__name__}.{module.name}")


def _metadata_named_objects() -> set[str]:
    names: set[str] = set()
    for table in Base.metadata.tables.values():
        for constraint in table.constraints:
            if constraint.name:
                names.add(str(constraint.name))
        for index in table.indexes:
            if index.name:
                names.add(str(index.name))
    return names


def _expected_global_owner_fk_count() -> int:
    total = 0
    for table in Base.metadata.tables.values():
        for constraint in table.foreign_key_constraints:
            if any(
                element.target_fullname == "efhc_core.users.global_id"
                for element in constraint.elements
            ):
                total += 1
    return total


def _validate_release_identity_schema(conn: sa.Connection) -> None:
    columns = {
        str(row[0])
        for row in conn.execute(
            sa.text(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_schema='efhc_core' AND table_name='users'"
            )
        ).fetchall()
    }
    if "global_id" not in columns:
        raise RuntimeError("0001: users.global_id physical column missing")
    forbidden = {"id", "user_id", "tg_id", "ton_wallet"} & columns
    if forbidden:
        raise RuntimeError(
            "0001: retired users columns present: "
            + ",".join(sorted(forbidden))
        )

    primary_columns = {
        str(row[0])
        for row in conn.execute(
            sa.text(
                "SELECT kcu.column_name "
                "FROM information_schema.table_constraints tc "
                "JOIN information_schema.key_column_usage kcu "
                "ON tc.constraint_name=kcu.constraint_name "
                "AND tc.table_schema=kcu.table_schema "
                "WHERE tc.table_schema='efhc_core' "
                "AND tc.table_name='users' "
                "AND tc.constraint_type='PRIMARY KEY'"
            )
        ).fetchall()
    }
    if primary_columns != {"global_id"}:
        raise RuntimeError(
            f"0001: users PK must be global_id, got {sorted(primary_columns)}"
        )

    sequence = conn.execute(
        sa.text(
            "SELECT pg_get_serial_sequence("
            "'efhc_core.users', 'global_id')"
        )
    ).scalar()
    if sequence != "efhc_core.users_global_id_seq":
        raise RuntimeError(
            "0001: users.global_id sequence ownership mismatch"
        )

    fk_total = int(
        conn.execute(
            sa.text(
                "SELECT count(*) FROM pg_constraint c "
                "JOIN pg_attribute a ON a.attrelid=c.confrelid "
                "AND a.attnum=ANY(c.confkey) "
                "WHERE c.contype='f' "
                "AND c.confrelid='efhc_core.users'::regclass "
                "AND a.attname='global_id'"
            )
        ).scalar()
        or 0
    )
    expected_fk_total = _expected_global_owner_fk_count()
    if fk_total != expected_fk_total:
        raise RuntimeError(
            "0001: global owner FK mismatch: "
            f"expected {expected_fk_total}, got {fk_total}"
        )


def _validate_clean_schema(conn: sa.Connection) -> None:
    missing: list[str] = []
    if not _schema_exists(conn, CORE):
        missing.append(f"schema:{CORE}")
    if not _schema_exists(conn, ADMIN):
        missing.append(f"schema:{ADMIN}")

    tables = sorted(Base.metadata.tables.keys())
    if len(tables) != EXPECTED_TABLE_COUNT:
        missing.append(
            f"tables_count_expected_{EXPECTED_TABLE_COUNT}_got_{len(tables)}"
        )
    actual_contract = {
        (str(table.schema or ""), str(table.name))
        for table in Base.metadata.sorted_tables
        if table.schema in {CORE, ADMIN}
    }
    if actual_contract != expected_tables():
        missing.append("ORM_metadata_contract_mismatch")
    for table_name in tables:
        fq_name = (
            table_name if "." in table_name else f"{CORE}.{table_name}"
        )
        if not _to_regclass(conn, fq_name):
            missing.append(fq_name)

    required_columns = {
        (CORE, "users", "global_id"),
        (CORE, "users", "rank_position"),
        (CORE, "users", "rank_score_kwh"),
        (CORE, "users", "rank_calculated_at"),
        (CORE, "users", "main_balance"),
        (CORE, "users", "bonus_balance"),
        (CORE, "users", "available_kwh"),
        (CORE, "users", "total_generated_kwh"),
        (CORE, "users", "is_vip"),
        (CORE, "wallet_bindings", "global_id"),
        (CORE, "wallet_bindings", "wallet_address"),
        (CORE, "wallet_bindings", "proof_verified"),
        (CORE, "panels", "global_id"),
        (CORE, "panels", "is_active"),
        (CORE, "panels", "archived_at"),
        (CORE, "payment_intents", "global_id"),
        (CORE, "withdraw_requests", "global_id"),
        (CORE, "efhc_transfers_log", "global_id"),
        (CORE, "tasks", "bonus_efhc"),
        (CORE, "task_submissions", "global_id"),
    }
    for schema, table, column in sorted(required_columns):
        if not _column_exists(conn, schema, table, column):
            missing.append(f"{schema}.{table}.{column}")

    if not _column_is_nullable(conn, CORE, "payment_intents", "package_id"):
        missing.append("efhc_core.payment_intents.package_id_nullable")
    direction_len = _column_char_max_length(
        conn, CORE, "efhc_transfers_log", "direction"
    )
    if direction_len is None or direction_len < 24:
        missing.append("efhc_core.efhc_transfers_log.direction_varchar24")

    required_bigint_columns = {
        (ADMIN, "efhc_sale_packages", "id"),
        (CORE, "app_settings", "id"),
        (CORE, "efhc_transfers_log", "id"),
        (CORE, "payment_intents", "package_id"),
        (CORE, "referral_links", "id"),
        (CORE, "scheduler_task_log", "id"),
        (CORE, "shop_items", "id"),
        (CORE, "shop_orders", "id"),
        (CORE, "user_cosmetics", "id"),
        (CORE, "user_skins", "id"),
        (CORE, "users", "global_id"),
        (CORE, "wallet_bindings", "id"),
        (CORE, "wallet_proof_token_uses", "id"),
    }
    for schema, table, column in sorted(required_bigint_columns):
        if _column_data_type(conn, schema, table, column) != "bigint":
            missing.append(f"{schema}.{table}.{column}:expected_bigint")

    retired_tables = {
        f"{CORE}.panels_archive",
        f"{CORE}.ranks_snapshots",
        f"{CORE}.ranks_top_cache",
        f"{CORE}.ranks_user_snapshots",
    }
    for fq_name in retired_tables:
        if _to_regclass(conn, fq_name):
            missing.append(f"retired_table_present:{fq_name}")

    if missing:
        raise RuntimeError(
            "0001 sanity failed; objects: " + ", ".join(missing)
        )
    _validate_release_identity_schema(conn)


def upgrade() -> None:
    conn = op.get_bind()
    offline = bool(alembic_context.is_offline_mode())

    if not offline:
        try:
            database = conn.execute(
                sa.text("SELECT current_database()")
            ).scalar()
            search_path = conn.execute(sa.text("SHOW search_path")).scalar()
            sys.stdout.write(f"0001: db={database}\n")
            sys.stdout.write(f"0001: search_path={search_path}\n")
        except Exception:
            sys.stdout.write("0001: db_diag_unavailable\n")

    # Clean Greenfield DB не обязана заранее содержать application schemas.
    conn.execute(sa.text("CREATE SCHEMA IF NOT EXISTS efhc_core"))
    conn.execute(sa.text("CREATE SCHEMA IF NOT EXISTS efhc_admin"))
    conn.execute(sa.text("SET search_path TO efhc_core, efhc_admin"))
    conn2 = conn.execution_options(
        schema_translate_map={None: CORE}
    )
    _import_all_model_modules()
    sys.stdout.write(
        f"0001: metadata_tables={len(Base.metadata.tables)}\n"
    )

    metadata_tables = set(Base.metadata.tables.keys())
    missing_metadata = sorted(_REQUIRED_FQ - metadata_tables)
    if missing_metadata:
        raise RuntimeError(
            "0001 sanity failed; missing in Base.metadata: "
            + ", ".join(missing_metadata)
        )
    missing_named = sorted(
        _REQUIRED_METADATA_NAMES - _metadata_named_objects()
    )
    if missing_named:
        raise RuntimeError(
            "0001 sanity failed; missing metadata constraints/indexes: "
            + ", ".join(missing_named)
        )

    Base.metadata.create_all(bind=conn2, checkfirst=True)
    if not offline:
        conn.execute(
            sa.text(
                "ALTER SEQUENCE efhc_core.users_global_id_seq "
                "OWNED BY efhc_core.users.global_id"
            )
        )
        conn.execute(
            sa.text(
                "ALTER TABLE efhc_core.users ALTER COLUMN global_id "
                "SET DEFAULT nextval("
                "'efhc_core.users_global_id_seq'::regclass)"
            )
        )
        count = conn.execute(
            sa.text(
                "SELECT count(*) FROM pg_class c "
                "JOIN pg_namespace n ON n.oid=c.relnamespace "
                "WHERE c.relkind='r' "
                "AND n.nspname IN ('efhc_core','efhc_admin')"
            )
        ).scalar()
        sys.stdout.write(f"0001: tables_in_schemas={count}\n")
        _validate_clean_schema(conn)

    sys.stdout.write("0001: create_all_done\n")

    st = sa.Table(
        'system_templates',
        sa.MetaData(),
        sa.Column('key', sa.String(), nullable=False),
        sa.Column('content', sa.Text(), nullable=True),
        sa.Column('description', sa.String(), nullable=False),
        schema='efhc_core',
    )
    template_rows = [
        {
            'key': 'task_reject_fallback',
            'content': 'Выполнение не подтверждено.',
            'description': 'Автоответ при отклонении задания',
        },
        {
            'key': 'task_approve_fallback',
            'content': None,
            'description': 'Автоответ при одобрении задания',
        },
    ]
    localized_templates = {
        'task_approve_prefix': {
            'description': 'Префикс уведомления: задание подтверждено',
            'values': {
                'en': '✅ Task approved.',
                'ru': '✅ Задание подтверждено.',
                'uk': '✅ Завдання підтверджено.',
                'de': '✅ Aufgabe bestätigt.',
                'fr': '✅ Tâche confirmée.',
                'es': '✅ Tarea confirmada.',
                'it': '✅ Attività confermata.',
                'tr': '✅ Görev onaylandı.',
                'pl': '✅ Zadanie potwierdzone.',
                'da': '✅ Opgaven er bekræftet.',
                'hi': '✅ कार्य की पुष्टि हो गई।',
                'id': '✅ Tugas dikonfirmasi.',
                'sw': '✅ Kazi imethibitishwa.',
            },
        },
        'task_reject_prefix': {
            'description': 'Префикс уведомления: задание отклонено',
            'values': {
                'en': '⚠️ Task rejected.',
                'ru': '⚠️ Задание отклонено.',
                'uk': '⚠️ Завдання відхилено.',
                'de': '⚠️ Aufgabe abgelehnt.',
                'fr': '⚠️ Tâche refusée.',
                'es': '⚠️ Tarea rechazada.',
                'it': '⚠️ Attività rifiutata.',
                'tr': '⚠️ Görev reddedildi.',
                'pl': '⚠️ Zadanie odrzucone.',
                'da': '⚠️ Opgaven blev afvist.',
                'hi': '⚠️ कार्य अस्वीकृत किया गया।',
                'id': '⚠️ Tugas ditolak.',
                'sw': '⚠️ Kazi imekataliwa.',
            },
        },
        'task_approve_fallback': {
            'description': 'Fallback-комментарий: задание подтверждено',
            'values': {
                'en': 'Task result confirmed.',
                'ru': 'Результат задания подтвержден.',
                'uk': 'Результат завдання підтверджено.',
                'de': 'Das Ergebnis der Aufgabe wurde bestätigt.',
                'fr': 'Le résultat de la tâche a été confirmé.',
                'es': 'El resultado de la tarea fue confirmado.',
                'it': "Il risultato dell'attività è stato confermato.",
                'tr': 'Görev sonucu doğrulandı.',
                'pl': 'Wynik zadania został potwierdzony.',
                'da': 'Opgavens resultat er bekræftet.',
                'hi': 'कार्य का परिणाम पुष्टि कर दिया गया है।',
                'id': 'Hasil tugas telah dikonfirmasi.',
                'sw': 'Matokeo ya kazi yamehakikishwa.',
            },
        },
        'task_reject_fallback': {
            'description': 'Fallback-комментарий: задание отклонено',
            'values': {
                'en': 'Task result was not confirmed.',
                'ru': 'Выполнение не подтверждено.',
                'uk': 'Виконання не підтверджено.',
                'de': 'Die Ausführung wurde nicht bestätigt.',
                'fr': "L'exécution n'a pas été confirmée.",
                'es': 'La ejecución no fue confirmada.',
                'it': "L'esecuzione non è stata confermata.",
                'tr': 'Tamamlama doğrulanmadı.',
                'pl': 'Wykonanie nie zostało potwierdzone.',
                'da': 'Udførelsen blev ikke bekræftet.',
                'hi': 'कार्य पूरा होने की पुष्टि नहीं हुई।',
                'id': 'Penyelesaian tidak dikonfirmasi.',
                'sw': 'Utekelezaji haujathibitishwa.',
            },
        },
    }
    for base_key, spec in localized_templates.items():
        for lang, content in spec['values'].items():
            template_rows.append(
                {
                    'key': f'{base_key}.{lang}',
                    'content': content,
                    'description': (
                        f"{spec['description']} [{lang}]"
                    ),
                }
            )
    for row in template_rows:
        stmt = pg_insert(st).values(**row)
        stmt = stmt.on_conflict_do_update(
            index_elements=['key'],
            set_={
                'description': row['description'],
                'content': row['content'],
            },
        )
        conn.execute(stmt)

    # Системные строки создаёт только app.release.initial_data.
    sys.stdout.write("0001: ok\n")


def downgrade() -> None:
    # Канон: downgrade не удаляет production objects.
    pass
