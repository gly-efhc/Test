# -*- coding: utf-8 -*-
# backend/migrations/versions/0001_init.py
# =====================================================================
# EFHC Bot — первичная миграция (Postgres-only).
#
# Цель:
# • Создать канонические схемы efhc_core + efhc_admin.
# • Создать все ORM-таблицы проекта (Base.metadata) в efhc_core.
# • Создать таблицы, используемые raw SQL (если они не покрыты ORM),
#   а также admin-таблицы в efhc_admin.
# • Выполнить детерминированную проверку наличия объектов через
#   to_regclass('schema.table') — валим миграцию, если что-то отсутствует.
#
# Запреты/канон:
# • Никаких schema=... в sa.Column(...). Schema задаётся на уровне таблицы.
# • Никаких DROP. downgrade() — no-op.
# • Время — tz-aware (now()).
# • Денежные/энергетические величины: NUMERIC(30, 8).
# =====================================================================
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

import sys
from pathlib import Path

# Гарантируем импорт backend.* независимо от cwd alembic (CI запускает из
# extracted/backend). Нужно добавить extracted/ в sys.path.
_root = Path(__file__).resolve().parents[3]
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

# ORM metadata (канон таблиц проекта)
from backend.app.models import Base  # noqa: E402

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

NUM = sa.Numeric(30, 8)
TZ = sa.DateTime(timezone=True)


def _to_regclass(conn: sa.Connection, fq: str) -> bool:
    return conn.execute(sa.text("SELECT to_regclass(:n)"), {"n": fq}).scalar() is not None


def _ensure_schemas() -> None:
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_core")
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_admin")


def _create_raw_sql_core_tables(conn: sa.Connection) -> list[str]:
    """Таблицы, на которые есть реальные raw-SQL зависимости.

    ORM их не описывает, но код использует их через SQL (services/routes).
    Создаём минимально-достаточную структуру.
    """
    created: list[str] = []

    # efhc_core.payment_intents (services/payment_intents_service.py)
    if not _to_regclass(conn, "efhc_core.payment_intents"):
        op.create_table(
            "payment_intents",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("purpose", sa.String(64), nullable=False),
            sa.Column("package_id", sa.BigInteger, nullable=True),
            sa.Column("asset", sa.String(32), nullable=False),
            sa.Column("amount_asset_d8", NUM, nullable=False, server_default="0"),
            sa.Column("efhc_amount_d8", NUM, nullable=False, server_default="0"),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("idempotency_key", sa.String(128), nullable=False),
            sa.Column("payload", sa.String(256), nullable=False),
            sa.Column("to_address", sa.String(128), nullable=True),
            sa.Column("external_tx_hash", sa.String(128), nullable=True),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            sa.Column("expires_at", TZ, nullable=True),
            sa.Column("updated_at", TZ, nullable=False, server_default=sa.text("now()")),
            sa.UniqueConstraint("tg_id", "purpose", "idempotency_key", name="uq_payment_intents_tg_purpose_ikey"),
            schema="efhc_core",
        )
        op.create_index(
            "ix_payment_intents_tg_created",
            "payment_intents",
            ["tg_id", "created_at", "id"],
            schema="efhc_core",
        )
        created.append("efhc_core.payment_intents")

    # efhc_core.unmatched_incoming (services/watcher_service.py)
    if not _to_regclass(conn, "efhc_core.unmatched_incoming"):
        op.create_table(
            "unmatched_incoming",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tx_hash", sa.String(128), nullable=False),
            sa.Column("amount_d8", NUM, nullable=False, server_default="0"),
            sa.Column("asset", sa.String(32), nullable=True),
            sa.Column("payload", sa.String(256), nullable=True),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            sa.UniqueConstraint("tx_hash", name="uq_unmatched_incoming_tx_hash"),
            schema="efhc_core",
        )
        created.append("efhc_core.unmatched_incoming")

    # efhc_core.wallet_connect_idempotency (services/wallets_service.py)
    if not _to_regclass(conn, "efhc_core.wallet_connect_idempotency"):
        op.create_table(
            "wallet_connect_idempotency",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("key", sa.String(128), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            sa.UniqueConstraint("tg_id", "key", name="uq_wallet_connect_idempotency_tg_key"),
            schema="efhc_core",
        )
        created.append("efhc_core.wallet_connect_idempotency")

    # efhc_core.scheduler_task_log (scheduler jobs / sync)
    if not _to_regclass(conn, "efhc_core.scheduler_task_log"):
        op.create_table(
            "scheduler_task_log",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("task_name", sa.String(128), nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("details", sa.Text, nullable=True),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            schema="efhc_core",
        )
        op.create_index(
            "ix_scheduler_task_log_name_created",
            "scheduler_task_log",
            ["task_name", "created_at", "id"],
            schema="efhc_core",
        )
        created.append("efhc_core.scheduler_task_log")

    # Эти таблицы встречались как schema-qualified в текстах/depstrings.
    # Чтобы исключить "плавающее" ожидание, создаём минимальные заглушки.
    if not _to_regclass(conn, "efhc_core.processed_external_events"):
        op.create_table(
            "processed_external_events",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("event_key", sa.String(256), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            sa.UniqueConstraint("event_key", name="uq_processed_external_events_key"),
            schema="efhc_core",
        )
        created.append("efhc_core.processed_external_events")

    if not _to_regclass(conn, "efhc_core.admin_nft_whitelist"):
        op.create_table(
            "admin_nft_whitelist",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("note", sa.String(256), nullable=True),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            sa.UniqueConstraint("tg_id", name="uq_admin_nft_whitelist_tg_id"),
            schema="efhc_core",
        )
        created.append("efhc_core.admin_nft_whitelist")

    return created


def _create_admin_tables(conn: sa.Connection) -> list[str]:
    """Admin-таблицы, используемые code/sql."""
    created: list[str] = []

    # efhc_admin.efhc_sale_packages (shop packages)
    if not _to_regclass(conn, "efhc_admin.efhc_sale_packages"):
        op.create_table(
            "efhc_sale_packages",
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("title", sa.String(256), nullable=False),
            sa.Column("asset", sa.String(32), nullable=False),
            sa.Column("price_asset_d8", NUM, nullable=False, server_default="0"),
            sa.Column("efhc_amount_d8", NUM, nullable=False, server_default="0"),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("created_at", TZ, nullable=False, server_default=sa.text("now()")),
            schema="efhc_admin",
        )
        created.append("efhc_admin.efhc_sale_packages")

    # efhc_admin.bank_balances (admin bank)
    if not _to_regclass(conn, "efhc_admin.bank_balances"):
        op.create_table(
            "bank_balances",
            sa.Column("tg_id", sa.BigInteger, primary_key=True),
            sa.Column("main_balance", NUM, nullable=False, server_default="0"),
            sa.Column("bonus_balance", NUM, nullable=False, server_default="0"),
            sa.Column("updated_at", TZ, nullable=False, server_default=sa.text("now()")),
            schema="efhc_admin",
        )
        created.append("efhc_admin.bank_balances")

    return created


def upgrade() -> None:
    _ensure_schemas()

    bind = op.get_bind()
    conn: sa.Connection = bind  # type: ignore[assignment]

    # Создаём ORM-таблицы в efhc_core: используем search_path для схемы.
    op.execute("SET search_path TO efhc_core")
    Base.metadata.create_all(bind=conn)

    # Создаём таблицы, требуемые raw SQL (если их нет).
    _create_raw_sql_core_tables(conn)
    _create_admin_tables(conn)

    # -----------------------------------------------------------------
    # Sanity-check: схемы + таблицы должны существовать.
    # -----------------------------------------------------------------
    missing: list[str] = []

    # Схемы
    if not conn.execute(sa.text("SELECT 1 FROM pg_namespace WHERE nspname='efhc_core'")).scalar():
        missing.append("schema:efhc_core")
    if not conn.execute(sa.text("SELECT 1 FROM pg_namespace WHERE nspname='efhc_admin'")).scalar():
        missing.append("schema:efhc_admin")

    # ORM таблицы (в efhc_core)
    for tname in sorted(Base.metadata.tables.keys()):
        fq = f"efhc_core.{tname}"
        if not _to_regclass(conn, fq):
            missing.append(fq)

    # Raw SQL core/admin таблицы
    extra_required = [
        "efhc_core.payment_intents",
        "efhc_core.unmatched_incoming",
        "efhc_core.wallet_connect_idempotency",
        "efhc_core.scheduler_task_log",
        "efhc_core.processed_external_events",
        "efhc_core.admin_nft_whitelist",
        "efhc_admin.efhc_sale_packages",
        "efhc_admin.bank_balances",
    ]
    for fq in extra_required:
        if not _to_regclass(conn, fq):
            missing.append(fq)

    if missing:
        raise RuntimeError(
            "0001_init sanity failed, missing objects: " + ", ".join(missing)
        )


def downgrade() -> None:
    # Канон: 0001 — стартовая миграция. Удаления запрещены.
    pass
