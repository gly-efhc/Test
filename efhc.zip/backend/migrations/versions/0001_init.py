# -*- coding: utf-8 -*-
# backend/migrations/versions/0001_init.py
# =====================================================================
# EFHC Bot — первичная миграция (Postgres-only).
#
# Канон:
# - Истина = ORM (backend/app/models/**, Base.metadata).
# - 0001 — производный артефакт: создаёт 2 схемы и все ORM-таблицы
#   в efhc_core, затем детерминированно проверяет.
#
# DoD:
# - существуют схемы: efhc_core, efhc_admin
# - создано ровно 31 таблица из Base.metadata (в efhc_core)
# - sanity: pg_namespace + to_regclass('efhc_core.<table>')
#
# Запреты:
# - никаких "extra" таблиц из raw SQL
# - никаких schema=... внутри sa.Column(...)
# =====================================================================

import sys
from pathlib import Path

from alembic import op
import sqlalchemy as sa

# Alembic запускается из extracted/backend. Для импорта backend.* нужно
# добавить корень репозитория в sys.path.
_repo_root = Path(__file__).resolve().parents[3]
if str(_repo_root) not in sys.path:
    sys.path.insert(0, str(_repo_root))

from backend.app.models import Base  # noqa: E402

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def _schema_exists(conn: sa.Connection, name: str) -> bool:
    q = sa.text("SELECT 1 FROM pg_namespace WHERE nspname=:n")
    return conn.execute(q, {"n": name}).scalar() is not None


def _to_regclass(conn: sa.Connection, fq: str) -> bool:
    q = sa.text("SELECT to_regclass(:n)")
    return conn.execute(q, {"n": fq}).scalar() is not None


def upgrade() -> None:
    conn = op.get_bind()

    # 1) Схемы (ровно две)
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_core")
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_admin")

    # 2) Все ORM-таблицы строго в efhc_core
    conn.execute(sa.text("SET search_path TO efhc_core"))

    # ORM create_all: создаст ровно таблицы из Base.metadata
    Base.metadata.create_all(bind=conn)

    # 3) Sanity-check (детерминированный)
    missing = []

    if not _schema_exists(conn, "efhc_core"):
        missing.append("schema:efhc_core")
    if not _schema_exists(conn, "efhc_admin"):
        missing.append("schema:efhc_admin")

    tables = sorted(Base.metadata.tables.keys())
    for t in tables:
        fq = f"efhc_core.{t}"
        if not _to_regclass(conn, fq):
            missing.append(fq)

    # Канон: ровно 31 таблица.
    if len(tables) != 31:
        missing.append(f"tables_count_expected_31_got_{len(tables)}")

    if missing:
        raise RuntimeError(
            "0001 sanity failed; missing objects: " + ", ".join(missing)
        )


def downgrade() -> None:
    # Канон: downgrade не удаляет объекты.
    pass
