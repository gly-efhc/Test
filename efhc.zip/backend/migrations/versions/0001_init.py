# -*- coding: utf-8 -*-
# backend/migrations/versions/0001_init.py
# =====================================================================
# Назначение:
# Первичная миграция EFHC Bot под PostgreSQL/Neon. Создаёт ключевые
# таблицы, индексы и UNIQUE по канону. Безопасна к повторным запускам
# (ensure_*).
#
# Канон / инварианты:
# • Денежные величины: NUMERIC(30, 8), округление вниз в сервисах.
# • Идемпотентность: UNIQUE на idempotency_key/tx_hash где требуется.
# • Курсорная пагинация: индексы по (created_at, id).
# • Пользователи не уходят в минус — правило в сервисах.
# • Банк может быть в минусе — контролирует сервис банка.
#
# Запреты:
# • Никаких DROP/ALTER DROP. Для изменения типов — отдельные миграции.
# =====================================================================

from __future__ import annotations

from alembic import op
import sqlalchemy as sa

# Alembic загружает ревизии как отдельные модули; гарантируем, что корень проекта
# (директория extracted/) есть в sys.path, независимо от cwd.
import sys
from pathlib import Path
_root = Path(__file__).resolve().parents[3]
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from backend.migrations.lib.safe import (
    ensure_schema,
    ensure_table_with_basics,
)


# Идентификаторы Alembic
revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


# Общие типы
NUM = sa.Numeric(30, 8)
TZ = sa.DateTime(timezone=True)


def _assert_table_exists(table_name: str, schema: str) -> None:
    # Жёсткая проверка: если таблица не создана, пусть Alembic падает,
    # а не оставляет БД в "полу-успешном" состоянии.
    if not table_exists(table_name, schema=schema):
        bind = op.get_bind()
        q = sa.text(
            "SELECT table_schema, table_name FROM information_schema.tables "
            "WHERE table_name = :t ORDER BY table_schema"
        )
        rows = list(bind.execute(q, {"t": table_name}).fetchall())
        raise RuntimeError(
            f"Migration 0001: expected table {schema}.{table_name} to exist, found: {rows}"
        )

def upgrade() -> None:
    """Первичная миграция: схема efhc_core + базовые таблицы."""

    ensure_schema("efhc_core")
    ensure_schema("efhc_admin")
    # Некоторые legacy-тесты обращаются к schema "main"; создаём для совместимости.
    ensure_schema("main")

    # -----------------------------------------------------------------
    # users — профиль и балансы
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "users",
        schema="efhc_core",
        cols=[
            sa.Column(
                "id",
                sa.BigInteger,
                primary_key=True,
                autoincrement=True,
            ),
            sa.Column(
                "tg_id",
                sa.BigInteger,
                nullable=False,
                unique=True,
            ),
            sa.Column("username", sa.String(255)),
            sa.Column(
                "is_vip",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("false"),
            ),
            sa.Column(
                "is_active",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("true"),
            ),
            sa.Column("ton_wallet", sa.String(128), unique=True),
            sa.Column(
                "main_balance",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "bonus_balance",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "total_generated_kwh",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "exchanged_kwh_total",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "available_kwh",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.CheckConstraint(
                "total_generated_kwh >= 0",
                name="ck_users_total_generated_nonneg",
            ),
            sa.CheckConstraint(
                "exchanged_kwh_total >= 0",
                name="ck_users_exchanged_nonneg",
            ),
            sa.CheckConstraint(
                "exchanged_kwh_total <= total_generated_kwh",
                name="ck_users_exchanged_le_total_generated",
            ),
        ],
        indexes=[
            ("ix_users_created_id", ["created_at", "id"], False),
            ("ix_users_is_active_id", ["is_active", "id"], False),
        ],
    )
    _assert_table_exists("users", "efhc_core")

    # -----------------------------------------------------------------
    # efhc_admin.efhc_sale_packages — админ-пакеты продажи EFHC
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "efhc_sale_packages",
        schema="efhc_admin",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("title", sa.Text, nullable=False),
            sa.Column("asset", sa.String(16), nullable=False),
            sa.Column(
                "price_asset_d8",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "efhc_amount_d8",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "is_active",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("true"),
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[],
        indexes=[
            sa.Index(
                "ix_sale_packages_active",
                "is_active",
            ),
        ],
    )
    _assert_table_exists("efhc_sale_packages", "efhc_admin")

    # -----------------------------------------------------------------
    # payment_intents — тех. слой оплаты on-chain (A+B)
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "payment_intents",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("purpose", sa.String(32), nullable=False),
            sa.Column("package_id", sa.BigInteger, nullable=True),
            sa.Column("asset", sa.String(16), nullable=False),
            sa.Column(
                "amount_asset_d8",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "efhc_amount_d8",
                NUM,
                nullable=True,
            ),
            sa.Column("status", sa.String(16), nullable=False),
            sa.Column("idempotency_key", sa.Text, nullable=False),
            sa.Column("payload", sa.Text, nullable=False),
            sa.Column("to_address", sa.Text, nullable=False),
            sa.Column("external_tx_hash", sa.Text, nullable=True),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "expires_at",
                TZ,
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[
            sa.UniqueConstraint(
                "tg_id",
                "purpose",
                "idempotency_key",
                name="uq_payment_intents_idempo",
            ),
            sa.UniqueConstraint(
                "payload",
                name="uq_payment_intents_payload",
            ),
            sa.UniqueConstraint(
                "external_tx_hash",
                name="uq_payment_intents_tx_hash",
            ),
        ],
        indexes=[
            sa.Index(
                "ix_payment_intents_tg_created",
                "tg_id",
                "created_at",
                "id",
            ),
            sa.Index(
                "ix_payment_intents_status",
                "status",
            ),
        ],
    )
    _assert_table_exists("payment_intents", "efhc_core")

    # -----------------------------------------------------------------
    # unmatched_incoming — входящие on-chain без каноничного payload.
    # Автоначисления запрещены: требуется ручная обработка.
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "unmatched_incoming",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tx_hash", sa.Text, nullable=False, unique=True),
            sa.Column("asset", sa.String(16), nullable=False),
            sa.Column(
                "amount_asset_d8",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column("from_address", sa.Text, nullable=True),
            sa.Column("to_address", sa.Text, nullable=True),
            sa.Column("memo", sa.Text, nullable=True),
            sa.Column("utime", sa.BigInteger, nullable=True),
            sa.Column("reason", sa.String(64), nullable=False),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[],
        indexes=[
            sa.Index(
                "ix_unmatched_created",
                "created_at",
            ),
        ],
    )

    # Дополнение users до актуального канона (SSOT).
    from backend.migrations.lib.safe import ensure_column

    ensure_column("users", sa.Column("last_seen_at", TZ))
    ensure_column("users", sa.Column("last_sync_at", TZ))
    ensure_column("users", sa.Column("meta", sa.Text))


    # -----------------------------------------------------------------
    # wallet_bindings — привязки TON-кошельков к tg_id (TonConnect)
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "wallet_bindings",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column(
                "wallet_address",
                sa.Text,
                nullable=False,
                unique=True,
            ),
            sa.Column("wallet_app", sa.String(32), nullable=True),
            sa.Column(
                "is_primary",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("false"),
            ),
            sa.Column(
                "is_active",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("true"),
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            ("ix_wallet_bindings_tg_id", ["tg_id"], False),
            (
                "ix_wallet_bindings_active",
                ["tg_id", "is_active"],
                False,
            ),
        ],
    )

    # -----------------------------------------------------------------
    # wallet_connect_idempotency — журнал идемпотентности /wallets/connect
    # (техническая таблица, не доменная)
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "wallet_connect_idempotency",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("idempotency_key", sa.Text, nullable=False),
            sa.Column("wallet_id", sa.BigInteger, nullable=False),
            sa.Column("wallet_address", sa.Text, nullable=False),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            (
                "uq_wallet_connect_idk",
                ["tg_id", "idempotency_key"],
                True,
            ),
        ],
    )
    _assert_table_exists("wallet_connect_idempotency", "efhc_core")


    
    # -----------------------------------------------------------------
    # panels — панели пользователя (SSOT)
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "panels",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("public_id", sa.String(16), nullable=True),
            sa.Column(
                "is_active",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("true"),
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column("activated_at", TZ, nullable=False),
            sa.Column("expires_at", TZ, nullable=False),
            sa.Column("archived_at", TZ, nullable=True),
            sa.Column("last_generated_at", TZ),
            sa.Column(
                "base_gen_per_sec",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "generated_kwh",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column("title", sa.String(64)),
            sa.Column("meta", sa.Text),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.CheckConstraint(
                "expires_at > activated_at",
                name="ck_panels_expires_gt_activated",
            ),
        ],
        uniques=[
            ("uq_panels_public_id", ["public_id"]),
        ],
        indexes=[
            ("ix_panels_tg_id", ["tg_id"], False),
            ("ix_panels_active", ["tg_id", "is_active"], False),
            ("ix_panels_created_id", ["created_at", "id"], False),
        ],
    )

    # -----------------------------------------------------------------
    # efhc_transfers_log — банковские движения
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "efhc_transfers_log",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("direction", sa.String(16), nullable=False),
            sa.Column("balance_type", sa.String(16), nullable=False),
            sa.Column("reason", sa.String(64), nullable=False),
            sa.Column(
                "idempotency_key",
                sa.String(128),
                nullable=False,
            ),
            sa.Column("extra_info", sa.Text),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[("uq_efhc_transfers_idk", ["idempotency_key"])],
        indexes=[
            (
                "ix_efhc_transfers_created_id",
                ["created_at", "id"],
                False,
            ),
            (
                "ix_efhc_transfers_user_created",
                ["tg_id", "created_at"],
                False,
            ),
        ],
    )
    op.create_foreign_key(
        "fk_efhc_transfers_user",
        "efhc_transfers_log",
        "users",
        local_cols=["tg_id"],
        remote_cols=["tg_id"],
        ondelete="SET NULL",
    )

    # -----------------------------------------------------------------
    # ton_inbox_logs — входящие транзакции TON (вотчер)
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "ton_inbox_logs",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tx_hash", sa.String(128), nullable=False),
            sa.Column("from_address", sa.String(128)),
            sa.Column("to_address", sa.String(128)),
            sa.Column(
                "amount",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column("memo", sa.Text),
            sa.Column(
                "status",
                sa.String(32),
                nullable=False,
                server_default="received",
            ),
            sa.Column("next_retry_at", TZ),
            sa.Column(
                "retries_count",
                sa.Integer,
                nullable=False,
                server_default="0",
            ),
            sa.Column("processed_at", TZ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[("uq_ton_inbox_tx_hash", ["tx_hash"])],
        indexes=[
            (
                "ix_ton_inbox_status_retry",
                ["status", "next_retry_at"],
                False,
            ),
            ("ix_ton_inbox_created_id", ["created_at", "id"], False),
        ],
    )

    # -----------------------------------------------------------------
    # shop_orders — магазин
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "shop_orders",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("type", sa.String(16), nullable=False),
            sa.Column(
                "status",
                sa.String(32),
                nullable=False,
                server_default="PENDING",
            ),
            sa.Column("sku", sa.String(128), nullable=False),
            sa.Column(
                "quantity",
                sa.Integer,
                nullable=False,
                server_default="1",
            ),
            sa.Column(
                "amount",
                NUM,
                nullable=False,
                server_default="0",
            ),
            sa.Column("tx_hash", sa.String(128)),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            ("ix_shop_orders_tg", ["tg_id", "id"], False),
            ("ix_shop_orders_status", ["status", "id"], False),
            ("ix_shop_orders_created", ["created_at", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_shop_orders_user",
        "shop_orders",
        "users",
        local_cols=["tg_id"],
        remote_cols=["tg_id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------
    # withdrawals — заявки на вывод
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "withdrawals",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("wallet", sa.String(128), nullable=False),
            sa.Column("comment", sa.Text),
            sa.Column(
                "priority",
                sa.Integer,
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            ("ix_withdraw_tg_status", ["tg_id", "status"], False),
            ("ix_withdraw_created", ["created_at", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_withdraw_user",
        "withdrawals",
        "users",
        local_cols=["tg_id"],
        remote_cols=["tg_id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------
    # referrals — рефералы
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "referrals",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("inviter_id", sa.BigInteger, nullable=False),
            sa.Column("invitee_id", sa.BigInteger, nullable=False),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
            ),
        ],
        uniques=[("uq_referrals_pair", ["inviter_id", "invitee_id"])],
        indexes=[
            ("ix_ref_inviter", ["inviter_id", "id"], False),
            ("ix_ref_invitee", ["invitee_id", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_ref_inviter",
        "referrals",
        "users",
        local_cols=["inviter_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "fk_ref_invitee",
        "referrals",
        "users",
        local_cols=["invitee_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------
    # lotteries_draws — розыгрыши
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "lotteries_draws",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column(
                "details",
                sa.JSON,
                nullable=False,
                server_default=sa.text("'{}'"),
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            ("ix_draws_status", ["status", "id"], False),
            ("ix_draws_created", ["created_at", "id"], False),
        ],
    )

    # -----------------------------------------------------------------
    # lotteries_winners — победители
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "lotteries_winners",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("draw_id", sa.BigInteger, nullable=False),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("prize_amount", NUM, nullable=False),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            ("ix_winners_draw", ["draw_id", "id"], False),
            ("ix_winners_tg", ["tg_id", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_winners_draw",
        "lotteries_winners",
        "lotteries_draws",
        local_cols=["draw_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "fk_winners_user",
        "lotteries_winners",
        "users",
        local_cols=["tg_id"],
        remote_cols=["tg_id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------
    # admin_actions_log — аудит действий админа
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "admin_actions_log",
        schema="efhc_admin",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("admin_tg_id", sa.BigInteger, nullable=False),
            sa.Column("action", sa.String(64), nullable=False),
            sa.Column(
                "details",
                sa.JSON,
                nullable=False,
                server_default=sa.text("'{}'"),
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        indexes=[
            ("ix_admin_actions_time", ["created_at", "id"], False),
        ],
    )

    # -----------------------------------------------------------------
    # scheduler_task_log — лог задач планировщика
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "scheduler_task_log",
        schema="efhc_admin",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("task_name", sa.String(64), nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("error_text", sa.Text),
            sa.Column("retry_time", TZ),
            sa.Column(
                "executed_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
            sa.Column(
                "duration_sec",
                sa.Integer,
                nullable=False,
                server_default="0",
            ),
        ],
        indexes=[
            (
                "ix_sched_task_name_time",
                ["task_name", "executed_at"],
                False,
            ),
        ],
    )

    # -----------------------------------------------------------------
    # admin_bank_config — конфиг банка
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "admin_bank_config",
        schema="efhc_admin",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column(
                "bank_tg_id",
                sa.BigInteger,
                nullable=False,
            ),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[("uq_admin_bank_singleton", ["bank_tg_id"])],
    )
    # -----------------------------------------------------------------
    # panel_issuance — идемпотентность создания панели
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "panel_issuance",
        schema="efhc_core",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column(
                "idempotency_key",
                sa.String(128),
                nullable=False,
            ),
            sa.Column("panel_id", sa.BigInteger, nullable=False),
            sa.Column(
                "created_at",
                TZ,
                server_default=sa.text("now()"),
                nullable=False,
            ),
        ],
        uniques=[
            ("uq_panel_issuance_tg_key", ["tg_id", "idempotency_key"]),
            ("uq_panel_issuance_panel_id", ["panel_id"]),
        ],
        indexes=[
            ("ix_panel_issuance_tg_id", ["tg_id"], False),
        ],
    )


    # -----------------------------------------------------------------
    # CHECK-инварианты (PostgreSQL)
    # -----------------------------------------------------------------
    op.execute(
        sa.text(
            """
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
     WHERE table_name = 'users'
       AND constraint_name = 'ck_users_total_nonneg'
  ) THEN
    BEGIN
      ALTER TABLE users ADD CONSTRAINT ck_users_total_nonneg
        CHECK (total_generated_kwh >= 0);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
     WHERE table_name = 'users'
       AND constraint_name = 'ck_users_exchanged_nonneg'
  ) THEN
    BEGIN
      ALTER TABLE users ADD CONSTRAINT ck_users_exchanged_nonneg
        CHECK (exchanged_kwh_total >= 0);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
     WHERE table_name = 'users'
       AND constraint_name = 'ck_users_exchanged_le_total'
  ) THEN
    BEGIN
      ALTER TABLE users ADD CONSTRAINT ck_users_exchanged_le_total
        CHECK (exchanged_kwh_total <= total_generated_kwh);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
     WHERE table_name = 'users'
       AND constraint_name = 'ck_users_available_mirror'
  ) THEN
    BEGIN
      ALTER TABLE users ADD CONSTRAINT ck_users_available_mirror CHECK (
        available_kwh = GREATEST(
          total_generated_kwh - exchanged_kwh_total,
          0
        )
      );
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
     WHERE table_name = 'panels'
       AND constraint_name = 'ck_panels_expires_gt_activated'
  ) THEN
    BEGIN
      ALTER TABLE panels ADD CONSTRAINT ck_panels_expires_gt_activated
        CHECK (expires_at > activated_at);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END IF;
END $$;
            """
        )
    )




def downgrade() -> None:
    """Откат отключён каноном.

    Деструктивные шаги не делаем автоматически.
    """

    return None