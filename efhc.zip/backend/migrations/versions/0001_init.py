# -*- coding: utf-8 -*-
# backend/migrations/versions/0001_init.py
# =====================================================================
# Назначение:
# 0001 — единственная стартовая миграция EFHC Bot (Postgres-only).
# Создаёт 2 схемы и 30 таблиц (SSOT) и валится, если после upgrade
# чего-то не хватает (to_regclass).
#
# SSOT:
# - docs/SSOT_DB_SCHEMAS_TABLES.md
# =====================================================================

from __future__ import annotations

from alembic import op
import sqlalchemy as sa

from backend.migrations.lib.safe import ensure_table_with_basics

# Alembic revision identifiers
revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

TZ = sa.TIMESTAMP(timezone=True)
NUM = sa.Numeric(30, 8)


def _now_utc_sql() -> sa.TextClause:
    # tz-aware UTC, Postgres-side
    return sa.text("timezone('utc', now())")


def upgrade() -> None:
    # 2 схемы (канон)
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_core")
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_admin")

    # ----------------------------
    # efhc_core (26 таблиц)
    # ----------------------------
    ensure_table_with_basics(
        "users",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False, unique=True),
            sa.Column("username", sa.String(255)),
            sa.Column("is_vip", sa.Boolean, nullable=False, server_default=sa.text("false")),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("ton_wallet", sa.String(128), unique=True),
            sa.Column("main_balance", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("bonus_balance", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[
            ("uq_users_tg_id", ["tg_id"]),
        ],
        indexes=[
            ("ix_users_tg_id", ["tg_id"], True),
        ],
    )

    ensure_table_with_basics(
        "wallet_bindings",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("ton_wallet", sa.String(128), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_wallet_bindings_wallet", ["ton_wallet"])],
        indexes=[("ix_wallet_bindings_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "withdraw_requests",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("status", sa.String(32), nullable=False, server_default=sa.text("'PENDING'")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_withdraw_requests_tg_id", ["tg_id"], False),
                 ("ix_withdraw_requests_status", ["status"], False)],
    )

    ensure_table_with_basics(
        "withdrawals",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("tx_hash", sa.String(128)),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_withdrawals_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "panels",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("panel_level", sa.Integer, nullable=False, server_default=sa.text("1")),
            sa.Column("count", sa.Integer, nullable=False, server_default=sa.text("0")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_panels_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "achievements",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("level", sa.Integer, nullable=False),
            sa.Column("awarded_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_achievements_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "efhc_transfers_log",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("reason", sa.String(64)),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_efhc_transfers_log_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "ton_inbox_logs",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tx_hash", sa.String(128), nullable=False),
            sa.Column("ton_wallet", sa.String(128)),
            sa.Column("amount_ton", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_ton_inbox_logs_tx_hash", ["tx_hash"])],
    )

    ensure_table_with_basics(
        "shop_items",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("sku", sa.String(64), nullable=False),
            sa.Column("title", sa.String(255), nullable=False),
            sa.Column("price", NUM, nullable=False),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_shop_items_sku", ["sku"])],
    )

    ensure_table_with_basics(
        "shop_orders",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("item_sku", sa.String(64), nullable=False),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("status", sa.String(32), nullable=False, server_default=sa.text("'CREATED'")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_shop_orders_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "ads",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("title", sa.String(255)),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
    )

    ensure_table_with_basics(
        "tasks",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("code", sa.String(64), nullable=False),
            sa.Column("title", sa.String(255)),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_tasks_code", ["code"])],
    )

    ensure_table_with_basics(
        "task_submissions",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("task_code", sa.String(64), nullable=False),
            sa.Column("status", sa.String(32), nullable=False, server_default=sa.text("'PENDING'")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_task_submissions_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "app_settings",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("key", sa.String(128), nullable=False),
            sa.Column("value", sa.Text),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_app_settings_key", ["key"])],
    )

    ensure_table_with_basics(
        "bank_state",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("main_balance", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
    )

    ensure_table_with_basics(
        "idempotency_key",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("key", sa.String(128), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_idempotency_key_key", ["key"])],
    )

    ensure_table_with_basics(
        "referral_links",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("code", sa.String(64), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_referral_links_code", ["code"])],
        indexes=[("ix_referral_links_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "ranks_snapshots",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("score", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_ranks_snapshots_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "ranks_top_cache",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("rank", sa.Integer, nullable=False),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("score", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_ranks_top_cache_rank", ["rank"], True)],
    )

    ensure_table_with_basics(
        "user_skins",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("skin_code", sa.String(64), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_user_skins_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "user_cosmetics",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("cosmetic_code", sa.String(64), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_user_cosmetics_tg_id", ["tg_id"], False)],
    )

    # lotteries family (5)
    ensure_table_with_basics(
        "lotteries",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("code", sa.String(64), nullable=False),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        uniques=[("uq_lotteries_code", ["code"])],
    )

    ensure_table_with_basics(
        "lotteries_tickets",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("lottery_code", sa.String(64), nullable=False),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_lotteries_tickets_tg_id", ["tg_id"], False)],
    )

    ensure_table_with_basics(
        "lotteries_results",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("lottery_code", sa.String(64), nullable=False),
            sa.Column("result_json", sa.Text),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
    )

    ensure_table_with_basics(
        "lotteries_user_stats",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("wins", sa.Integer, nullable=False, server_default=sa.text("0")),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_lotteries_user_stats_tg_id", ["tg_id"], True)],
    )

    ensure_table_with_basics(
        "lotteries_nft_claims",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("tg_id", sa.BigInteger, nullable=False),
            sa.Column("lottery_code", sa.String(64), nullable=False),
            sa.Column("nft_address", sa.String(128)),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_core",
        indexes=[("ix_lotteries_nft_claims_tg_id", ["tg_id"], False)],
    )

    # ----------------------------
    # efhc_admin (4 таблицы)
    # ----------------------------
    ensure_table_with_basics(
        "admin_action_log",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("admin_tg_id", sa.BigInteger, nullable=False),
            sa.Column("action", sa.String(128), nullable=False),
            sa.Column("details_json", sa.Text),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_admin",
        indexes=[("ix_admin_action_log_admin_tg_id", ["admin_tg_id"], False)],
    )

    ensure_table_with_basics(
        "admin_bank_config",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("bank_main_balance", NUM, nullable=False, server_default=sa.text("0")),
            sa.Column("updated_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_admin",
    )

    ensure_table_with_basics(
        "admin_role",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("admin_tg_id", sa.BigInteger, nullable=False, unique=True),
            sa.Column("role", sa.String(64), nullable=False),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_admin",
    )

    ensure_table_with_basics(
        "admin_whitelist",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
            sa.Column("admin_tg_id", sa.BigInteger, nullable=False, unique=True),
            sa.Column("created_at", TZ, nullable=False, server_default=_now_utc_sql()),
        ],
        schema="efhc_admin",
    )

    # ----------------------------
    # SANITY: 2 схемы / 30 таблиц (to_regclass)
    # ----------------------------
    bind = op.get_bind()
    required = [
        # efhc_core (26)
        'efhc_core.users', 'efhc_core.wallet_bindings', 'efhc_core.withdraw_requests', 'efhc_core.withdrawals', 'efhc_core.panels', 'efhc_core.achievements', 'efhc_core.efhc_transfers_log', 'efhc_core.ton_inbox_logs', 'efhc_core.shop_orders', 'efhc_core.shop_items', 'efhc_core.ads', 'efhc_core.tasks', 'efhc_core.task_submissions', 'efhc_core.app_settings', 'efhc_core.bank_state', 'efhc_core.idempotency_key', 'efhc_core.referral_links', 'efhc_core.ranks_snapshots', 'efhc_core.ranks_top_cache', 'efhc_core.user_skins', 'efhc_core.user_cosmetics', 'efhc_core.lotteries', 'efhc_core.lotteries_tickets', 'efhc_core.lotteries_results', 'efhc_core.lotteries_user_stats', 'efhc_core.lotteries_nft_claims',
        # efhc_admin (4)
        'efhc_admin.admin_action_log', 'efhc_admin.admin_bank_config', 'efhc_admin.admin_role', 'efhc_admin.admin_whitelist',
    ]
    missing = []
    for name in required:
        val = bind.execute(sa.text("SELECT to_regclass(:name)"), {"name": name}).scalar()
        if val is None:
            missing.append(name)
    if missing:
        raise RuntimeError("0001_init did not create required table(s): " + ", ".join(missing))


def downgrade() -> None:
    # Канон: 0001 — стартовая миграция, downgrade не используется.
    pass
