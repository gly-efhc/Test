# -*- coding: utf-8 -*-
# backend/migrations/versions/0001_init.py
# =====================================================================
# EFHC Bot — первичная миграция (Postgres-only).
#
# Канон:
# - Истина = ORM (backend/app/models/**, Base.metadata).
# - 0001 — производный артефакт: создаёт 2 схемы и все ORM-таблицы
#   в efhc_core, затем детерминированно проверяет.
#
# DoD:
# - существуют схемы: efhc_core, efhc_admin
# - создано ровно 31 таблица из Base.metadata (в efhc_core)
# - sanity: pg_namespace + to_regclass('efhc_core.<table>')
#
# Запреты:
# - никаких "extra" таблиц из raw SQL
# - никаких schema=... внутри sa.Column(...)
# =====================================================================

import sys
from pathlib import Path

import importlib
import pkgutil

from alembic import op
import sqlalchemy as sa

# Alembic запускается из extracted/backend (CWD = backend).
# В sys.path уже есть extracted/backend, поэтому импортируем пакет 'app.*'
# и избегаем двойного импорта одних и тех же модулей как 'backend.app.*'.
_backend_dir = Path(__file__).resolve().parents[2]
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from app import models as models_pkg  # noqa: E402
from app.models import Base  # noqa: E402

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def _schema_exists(conn: sa.Connection, name: str) -> bool:
    q = sa.text("SELECT 1 FROM pg_namespace WHERE nspname=:n")
    return conn.execute(q, {"n": name}).scalar() is not None



def _expected_tables_from_ssot(repo_root: Path) -> int | None:
    try:
        p = repo_root / "docs" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
        if not p.exists():
            return None
        import csv
        with p.open("r", encoding="utf-8") as f:
            r = csv.DictReader(f)
            rows = [row for row in r if (row.get("table") or "").strip()]
        return len(rows) if rows else None
    except Exception:
        return None

def _to_regclass(conn: sa.Connection, fq: str) -> bool:
    q = sa.text("SELECT to_regclass(:n)")
    return conn.execute(q, {"n": fq}).scalar() is not None


def _import_all_model_modules() -> None:
    # Канон: в Base.metadata должны попасть ВСЕ ORM-модели.
    # Поэтому импортируем все модули вида *_models.py из пакета app.models.
    for mod in pkgutil.iter_modules(models_pkg.__path__):
        if not mod.name.endswith("_models"):
            continue
        importlib.import_module(f"{models_pkg.__name__}.{mod.name}")


def upgrade() -> None:
    conn = op.get_bind()

    # 1) Схемы (ровно две)
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_core")
    op.execute("CREATE SCHEMA IF NOT EXISTS efhc_admin")

    # 2) Все ORM-таблицы строго в efhc_core
    conn.execute(sa.text("SET search_path TO efhc_core"))

    # 2.1) Импортируем все модели, затем создаём таблицы
    _import_all_model_modules()
    Base.metadata.create_all(bind=conn)

    # 3) Sanity-check (детерминированный)
    missing = []

    if not _schema_exists(conn, "efhc_core"):
        missing.append("schema:efhc_core")
    if not _schema_exists(conn, "efhc_admin"):
        missing.append("schema:efhc_admin")

    tables = sorted(Base.metadata.tables.keys())

    # Канон: список таблиц берём строго из ORM (Base.metadata).
    expected_tables = 34  # обновляется вместе с SSOT_TABLES_ORM.csv
    if len(tables) != expected_tables:
        missing.append(f"tables_count_expected_{expected_tables}_got_{len(tables)}")

    for t in tables:
        # В MetaData ключи могут быть либо "table", либо "schema.table".
        fq = t if "." in t else f"efhc_core.{t}"
        if not _to_regclass(conn, fq):
            missing.append(fq)

    if missing:
        raise RuntimeError(
            "0001 sanity failed; missing objects: " + ", ".join(missing)
        )


def downgrade() -> None:
    # Канон: downgrade не удаляет объекты.
    pass
