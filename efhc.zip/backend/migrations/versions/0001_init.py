# -*- coding: utf-8 -*-
# backend/migrations/versions/0001_init.py
# =====================================================================
# EFHC Bot — первичная миграция (Postgres-only).
#
# Канон:
# - Истина = ORM (backend/app/models/**, Base.metadata).
# - 0001 — производный артефакт: создаёт 2 схемы и все ORM-таблицы
#   в efhc_core/efhc_admin, затем детерминированно проверяет.
#
# DoD:
# - существуют схемы: efhc_core, efhc_admin
# - создаются ORM-таблицы из Base.metadata (2 схемы)
# - sanity: pg_namespace + to_regclass(<schema>.<table>)
# - key constraints: uq_payment_intents_idempo
#
# Запреты:
# - никаких "extra" таблиц из raw SQL
# - никаких schema=... внутри sa.Column(...)
# =====================================================================

from __future__ import annotations

import importlib
import pkgutil
import sys
from pathlib import Path

from alembic import op
import sqlalchemy as sa
from decimal import Decimal
from sqlalchemy.dialects.postgresql import insert as pg_insert


# Alembic запускается из extracted/backend (CWD = backend).
# В sys.path уже есть backend, но часть CI/локалки может ломаться.
_backend_dir = Path(__file__).resolve().parents[2]
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from app import models as models_pkg  # noqa: E402
from app.models import Base  # noqa: E402


revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def _schema_exists(conn: sa.Connection, name: str) -> bool:
    q = sa.text("SELECT 1 FROM pg_namespace WHERE nspname=:n")
    return conn.execute(q, {"n": name}).scalar() is not None


def _expected_tables_from_ssot(repo_root: Path) -> int | None:
    p = repo_root / "docs" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
    if not p.exists():
        return None
    try:
        import csv

        with p.open("r", encoding="utf-8") as f:
            r = csv.DictReader(f)
            rows = [
                row for row in r if (row.get("table") or "").strip()
            ]
        return len(rows) if rows else None
    except Exception:
        return None


def _to_regclass(conn: sa.Connection, fq: str) -> bool:
    q = sa.text("SELECT to_regclass(:n)")
    return conn.execute(q, {"n": fq}).scalar() is not None


def _import_all_model_modules() -> None:
    # Канон: в Base.metadata должны попасть ВСЕ ORM-модели.
    #
    # Класс ошибки "missing required tables after alembic":
    # если авто-скан не подхватил модули моделей, то
    # create_all создаёт 0 таблиц и CI падает на post-sanity.
    #
    # Делаем двойной импорт:
    # 1) явный импорт ключевых модулей (минимум для 0001);
    # 2) авто-скан *_models.py (для полноты).
    required = [
        "admin_models",
        "user_models",
        "withdraw_models",
        "payment_intents_models",
    ]
    for name in required:
        importlib.import_module(f"{models_pkg.__name__}.{name}")

    for mod in pkgutil.iter_modules(models_pkg.__path__):
        if not mod.name.endswith("_models"):
            continue
        importlib.import_module(f"{models_pkg.__name__}.{mod.name}")


def upgrade() -> None:
    conn = op.get_bind()
    repo_root = _backend_dir.parent

    # Диагностика: какая БД/схема видна в Alembic-сессии.
    try:
        db = conn.execute(sa.text("SELECT current_database()"))
        db = db.scalar()
        sp = conn.execute(sa.text("SHOW search_path")).scalar()
        sys.stdout.write(f"0001: db={db}\n")
        sys.stdout.write(f"0001: search_path={sp}\n")
    except Exception:
        sys.stdout.write("0001: db_diag_unavailable\n")
    # 1) Схемы создаются в env.py (AUTOCOMMIT), здесь не трогаем.

    # 2) ORM-таблицы создаём по schema, заданной в моделях.
    # Для без-schema таблиц применяем schema_translate_map -> efhc_core.
    conn.execute(sa.text("SET search_path TO efhc_core, efhc_admin"))
    conn2 = conn.execution_options(
        schema_translate_map={None: "efhc_core"}
    )

    # 2.1) Импортируем все модели, затем создаём таблицы
    _import_all_model_modules()

    sys.stdout.write(
        f"0001: metadata_tables={len(Base.metadata.tables)}\n"
    )

    required_fq = {
        "efhc_core.users",
        "efhc_core.withdraw_requests",
        "efhc_core.payment_intents",
        "efhc_admin.efhc_sale_packages",
    }
    md_keys = set(Base.metadata.tables.keys())
    missing_md = sorted([t for t in required_fq if t not in md_keys])
    if missing_md:
        raise RuntimeError(
            "0001 sanity failed; missing in Base.metadata: "
            + ", ".join(missing_md)
        )

    Base.metadata.create_all(bind=conn2, checkfirst=False)

    # Диагностика: сколько таблиц реально есть в core/admin.
    try:
        q = sa.text(
            "SELECT count(*) FROM pg_class c "
            "JOIN pg_namespace n ON n.oid=c.relnamespace "
            "WHERE c.relkind='r' AND n.nspname IN (:c,:a)"
        )
        cnt = conn.execute(
            q, {"c": "efhc_core", "a": "efhc_admin"}
        ).scalar()
        sys.stdout.write(f"0001: tables_in_schemas={cnt}\n")
    except Exception:
        sys.stdout.write("0001: tables_in_schemas=unknown\n")

    # Сигнал в CI: дошли до DDL.
    sys.stdout.write("0001: create_all_done\n")

    # 3) Sanity-check (детерминированный)
    missing: list[str] = []

    if not _schema_exists(conn, "efhc_core"):
        missing.append("schema:efhc_core")
    if not _schema_exists(conn, "efhc_admin"):
        missing.append("schema:efhc_admin")

    tables = sorted(Base.metadata.tables.keys())

    expected_tables = _expected_tables_from_ssot(repo_root)
    if expected_tables is None:
        missing.append("SSOT_TABLES_ORM.csv_missing_or_unreadable")
    else:
        if len(tables) != int(expected_tables):
            missing.append(
                "tables_count_expected_"
                f"{expected_tables}_got_{len(tables)}"
            )

    for t in tables:
        fq = t if "." in t else f"efhc_core.{t}"
        if not _to_regclass(conn, fq):
            missing.append(fq)

    if missing:
        raise RuntimeError(
            "0001 sanity failed; missing objects: " + ", ".join(missing)
        )
    # Жёсткая проверка: после create_all таблицы обязаны быть видимы
    # в efhc_core/efhc_admin. Иначе миграция должна упасть.
    missing = []
    for fq in sorted(required_fq):
        got = conn.execute(sa.text("SELECT to_regclass(:n)"), {"n": fq})
        if got.scalar() is None:
            missing.append(fq)
    if missing:
        msg = "0001: missing_after_create_all=" + ",".join(missing)
        raise RuntimeError(msg)


    # Канон банка BANK_EFHC:
    # - в банке только EFHC_MAIN
    # - стартовый баланс: 5000000.00000000
    bb = sa.Table(
        'bank_balance',
        sa.MetaData(),
        sa.Column('key', sa.String(), nullable=False),
        sa.Column('balance', sa.Numeric(30, 8), nullable=False),
        schema='efhc_core',
    )
    # Удаляем любые неканоничные ключи (на случай исторических хвостов).
    conn.execute(
        sa.text(
            "DELETE FROM efhc_core.bank_balance "
            "WHERE key <> :k"
        ),
        {'k': 'EFHC_MAIN'},
    )
    stmt = pg_insert(bb).values(
        key='EFHC_MAIN',
        balance=Decimal('5000000.00000000'),
    )
    stmt = stmt.on_conflict_do_update(
        index_elements=['key'],
        set_={'balance': Decimal('5000000.00000000')},
    )
    conn.execute(stmt)

    sys.stdout.write("0001: ok\n")


def downgrade() -> None:
    # Канон: downgrade не удаляет объекты.
    pass
