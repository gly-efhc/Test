"""EFHC backend runner.

Orchestrates FastAPI and scheduler tasks.

No money/energy logic here: only process orchestration.
"""

from __future__ import annotations

import argparse
import asyncio
import importlib
import os
import random
import signal
import sys
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from typing import Awaitable, Callable, Optional

import uvicorn

# --- internal deps --------------------------------------------
from backend.app.core.logging_core import get_logger
from backend.app.core.config_core import get_settings
from backend.app.core.system_locks import assert_system_locks

logger = get_logger(__name__)
settings = get_settings()


# Конфигурация запуска

API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "info").lower()

# Включение планировщика (можно отключить переменной окружения)
SCHEDULER_ENABLED = (
    os.getenv("SCHEDULER_ENABLED", "true").lower()
    not in {"0", "false", "no"}
)
# Глобальный тик (сек) по канону — по умолчанию 600 (10 минут)
TICK_SEC = int(getattr(settings, "SCHEDULER_TICK_SECONDS", 600) or 600)

# Таймаут одной задачи: если дольше — прерываем
# и ждём следующий тик
TASK_TIMEOUT_SEC = int(os.getenv("TASK_TIMEOUT_SEC", "900"))
# 15 минут по канону
# Максимум одновременно выполняемых задач (ИИ-лимит параллельности)
MAX_PARALLEL_TASKS = int(
    os.getenv("MAX_PARALLEL_SCHEDULER_TASKS", "3")
)


# Описания задач планировщика (модуль → кандидат точки входа)
# Каждая задача должна работать долго и не падать. Мы
# равно страхуем снаружи (бэкофф, таймауты, рестарт).

@dataclass(frozen=True)
class TaskSpec:
    name: str
    module_path: str
    entry_candidates: tuple[str, ...]  # возможные названия точки входа

TASKS: tuple[TaskSpec, ...] = (
    TaskSpec(
        "generate_energy",
        "backend.app.scheduler.generate_energy",
        ("run_forever", "main_loop", "tick_forever", "run"),
    ),
    TaskSpec(
        "check_ton_inbox",
        "backend.app.scheduler.check_ton_inbox",
        ("run_forever", "main_loop", "tick_forever", "run"),
    ),
    TaskSpec(
        "check_vip_nft",
        "backend.app.scheduler.check_vip_nft",
        ("run_forever", "main_loop", "tick_forever", "run"),
    ),
    TaskSpec(
        "archive_panels",
        "backend.app.scheduler.archive_panels",
        ("run_forever", "main_loop", "tick_forever", "run"),
    ),
    TaskSpec(
        "update_ranks",
        "backend.app.scheduler.update_ranks",
        ("run_forever", "main_loop", "tick_forever", "run"),
    ),
    TaskSpec(
        "reports_daily",
        "backend.app.scheduler.reports_daily",
        ("run_forever", "main_loop", "tick_forever", "run"),
    ),
)



# Утилиты: загрузка точки входа, бэкофф и обёртка
# корутины

def _resolve_entry(
    module_path: str,
    candidates: tuple[str, ...],
) -> Optional[Callable[..., Awaitable[None]]]:
    """
    Импортирует модуль и ищет первую async-функцию из candidates.
Если функция синхронная — оборачиваем в to_thread.
    Возвращает awaitable-функцию либо None (если ничего не найдено).
    """
    try:
        module = importlib.import_module(module_path)
    except Exception as e:
        logger.error("scheduler: cannot import %s: %s", module_path, e)
        return None

    for attr in candidates:
        fn = getattr(module, attr, None)
        if not fn:
            continue
        # Если функция уже корутина — используем как есть
        if asyncio.iscoroutinefunction(fn):
            async def _runner_async(*args, _fn=fn, **kwargs):
                """Run a scheduler task entry."""
                await _fn(*args, **kwargs)
            return _runner_async
        # Иначе — оборачиваем синхронную функцию в to_thread
        async def _runner_thread(*args, _fn=fn, **kwargs):
            """Run a scheduler task entry."""
            await asyncio.to_thread(_fn, *args, **kwargs)
        return _runner_thread

    # Попытка найти «tick» и организовать цикл с TICK_SEC
    tick = getattr(module, "tick", None)
    if tick and callable(tick):
        async def _tick_adapter():
            """Run a scheduler task entry."""
            # Soft loop: call tick(), then sleep for TICK_SEC.
            while True:
                try:
                    if asyncio.iscoroutinefunction(tick):
                        await asyncio.wait_for(
    tick(),
    timeout=TASK_TIMEOUT_SEC,
)
                    else:
                        await asyncio.wait_for(
    asyncio.to_thread(tick),
    timeout=TASK_TIMEOUT_SEC,
)
                except asyncio.TimeoutError:
                    logger.warning(
                        "scheduler.tick adapter: timeout in %s.tick",
                        module_path,
                    )
                except Exception as e:
                    logger.warning(
                        "scheduler.tick adapter: error in %s.tick: %s",
                        module_path,
                        e,
                    )
                await asyncio.sleep(TICK_SEC)
        return _tick_adapter

    logger.error(
        "scheduler: no entry found in %s (candidates=%s)",
        module_path,
        candidates,
    )
    return None


def _backoff_gen():
    """
    Генератор экспоненциального бэкоффа с джиттером:
    5s, 10s, 20s, 40s, 60s (cap), 60s...
    """
    base = 5
    cap = 60
    delay = base
    while True:
        # Псевдослучайность, чтобы не биться стадным рестартом
        jitter = random.uniform(0.8, 1.2)
        yield int(min(cap, delay * jitter))
        delay = min(cap, delay * 2)

async def _run_supervised(
    name: str,
    entry: Callable[[], Awaitable[None]],
    sem: asyncio.Semaphore,
    stop_event: asyncio.Event,
):
    """
    Запускает задачу с таймаутом и вечным перезапуском.
    Если задача выбрасывает исключение — делаем бэкофф и пробуем снова.
    """
    bo = _backoff_gen()
    while not stop_event.is_set():
        await sem.acquire()
        try:
            logger.info("scheduler:%s starting", name)
            try:
                await entry()
                # Если функция вернулась сама — это нештатный кейс
                # завершением.
                logger.warning(
                    "scheduler:%s returned unexpectedly; restarting…",
                    name
                )
            except asyncio.CancelledError:
                logger.info("scheduler:%s cancelled", name)
                raise
            except Exception as e:
                logger.error("scheduler:%s crashed: %s", name, e)
            # Бэкофф перед рестартом
            delay = next(bo)
            logger.info("scheduler:%s backoff %ss", name, delay)
            await asyncio.wait([stop_event.wait()], timeout = delay)
        finally:
            with suppress(Exception):
                sem.release()



# Предзапуск: проверки канона и «лёгкая» проверка БД

async def _lightweight_db_ping() -> None:
    """
    Best-effort DB ping.

    Tries SELECT 1 via async_engine when available.
    Logs failures and does not block startup.
    """
    try:
        from app.core.database_core import (
            async_engine,
        )
    except Exception as e:  # pragma: no cover
        logger.warning(
            "db ping: async_engine not found (%s). Skipped.",
            e,
        )
        return

    if async_engine is None:
        logger.warning("db ping: async_engine is None. Skipped.")
        return

    try:
        async with async_engine.connect() as conn:
            await conn.execute("SELECT 1")
        logger.info("db ping: OK")
    except Exception as e:
        logger.warning(
    "db ping: failed (%s). Services will retry later.",
    e,
)


async def preflight_checks() -> None:
    """
    Глобальные проверки перед запуском:
    • Проверка архитектурных запретов и канона.
    • Лёгкий пинг БД (без паники при неуспехе).
    """
    assert_system_locks()
# Поднимает исключение, если нарушены инварианты
    await _lightweight_db_ping()



# Жизненный цикл: старт API, супервизор, обработка сигналов

async def start_api_server() -> None:
    """
    Программный старт uvicorn.Server. Блокирует до остановки.
    """
    config = uvicorn.Config(
        app="backend.app.main:app",
        host=API_HOST,
        port=API_PORT,
        log_level=LOG_LEVEL,
        proxy_headers=True,
        forwarded_allow_ips="*",
        # reload=False в проде; dev включай через Uvicorn CLI
        reload=False,
        loop="asyncio",
        timeout_keep_alive=30,
    )
    server = uvicorn.Server(config)
    await server.serve()


@asynccontextmanager
async def scheduler_context() -> asyncio.TaskGroup:
    """
    Контекст, который поднимает супервизор задач
    и корректно их гасит по выходу.
    Python 3.11 TaskGroup для упрощения управления набором задач.
    """
    stop_event = asyncio.Event()
    sem = asyncio.Semaphore(MAX_PARALLEL_TASKS)

    # Готовим TaskGroup и запускаем каждую задачу в «управляемом» режиме
    class _TG:
        def __init__(self):
            """TaskGroup wrapper."""
            self.tg: Optional[asyncio.TaskGroup] = None

        async def __aenter__(self):
            """Enter and start supervised tasks."""
            self.tg = asyncio.TaskGroup()
            await self.tg.__aenter__()
            # поднимаем все задачи
            for spec in TASKS:
                entry = _resolve_entry(
                    spec.module_path,
                    spec.entry_candidates,
                )
                if not entry:
                    logger.error(
                        "scheduler: task %s skipped — no entry",
                        spec.name,
                    )
                    continue
                self.tg.create_task(
                    _run_supervised(
                        spec.name,
                        entry,
                        sem,
                        stop_event,
                    )
                )
            return self.tg

        async def __aexit__(self, et, ev, tb):
            """Stop supervised tasks."""
            stop_event.set()
            await self.tg.__aexit__(et, ev, tb)

    tg_wrapper = _TG()
    try:
        tg = await tg_wrapper.__aenter__()
        try:
            yield tg  # внутри with-блока задачи работают
        finally:
            await tg_wrapper.__aexit__(None, None, None)
    except Exception:
        # всё уже залогировано выше; гарантируем продолжение остановки
        with suppress(Exception):
            stop_event.set()
        raise


def _install_signal_handlers(
    loop: asyncio.AbstractEventLoop,
    stopper: Callable[[], None],
) -> None:
    """
    Устанавливает обработчики SIGINT/SIGTERM для аккуратного завершения.
    На Windows SIGTERM не всегда доступен — ловим, что есть.
    """

    def _handler(sig_name: str):
        """Signal handler."""
        logger.info("signal: %s received, shutting down…", sig_name)
        stopper()

    for sig in ("SIGINT", "SIGTERM"):
        if hasattr(signal, sig):
            loop.add_signal_handler(getattr(signal, sig), _handler, sig)



# Основной сценарий запуска

async def run_all() -> int:
    """
    Запускает:
    1) preflight-проверки канона и БД,
    2) FastAPI сервер,
    3) супервизор планировщика (если включён).
    Ожидает завершения сервера (обычно по сигналу).
    """
    await preflight_checks()

    loop = asyncio.get_running_loop()
    stop = asyncio.Event()
    _install_signal_handlers(loop, stop.set)

    # Запуск: API-сервер в отдельной задаче, планировщик — в
    # контексте
    api_task = asyncio.create_task(
    start_api_server(),
    name="uvicorn-server",
)

    if SCHEDULER_ENABLED:
        logger.info(
            "scheduler: enabled (tick=%ss, max_parallel=%s)",
            TICK_SEC,
            MAX_PARALLEL_TASKS
        )
        async with scheduler_context():
            # Ждём или падения сервера, или запроса остановки
            done, pending = await asyncio.wait(
    {
        api_task,
        asyncio.create_task(
            stop.wait(),
            name="stop-waiter",
        ),
    },
                return_when = asyncio.FIRST_COMPLETED,)
            # Если сработала остановка — гасим сервер
            if stop.is_set():
                with suppress(asyncio.CancelledError):
                    api_task.cancel()
            # Дожимаем
            await asyncio.gather(*pending, return_exceptions = True)
    else:
        logger.info("scheduler: disabled by env")
        # Только API
        await api_task

    logger.info("run_all: terminated")
    return 0


async def run_api_only() -> int:
    """Запускает только FastAPI (без планировщика)."""
    await preflight_checks()
    await start_api_server()
    return 0


async def run_scheduler_only() -> int:
    """Запускает только супервизор планировщика (без API)."""
    await preflight_checks()
    loop = asyncio.get_running_loop()
    stop = asyncio.Event()
    _install_signal_handlers(loop, stop.set)
    async with scheduler_context():
        await stop.wait()
    return 0


def _parse_args(argv: list[str]) -> argparse.Namespace:
    """Parse CLI args."""
    p = argparse.ArgumentParser(
        prog="EFHC-runner",
        description=(
            "EFHC Bot runner: API + scheduler supervisor"
        ),
    )
    p.add_argument(
        "--mode",
        choices=("all", "api", "scheduler"),
        default="all",
        help=(
            "Режим запуска: all (по умолчанию), api, scheduler"
        ),
    )
    return p.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    """
    Точка входа для `python -m backend.run`
    и для прямого вызова файла.
    """
    args = _parse_args(argv or sys.argv[1:])
    try:
        if args.mode == "api":
            return asyncio.run(run_api_only())
        if args.mode == "scheduler":
            return asyncio.run(run_scheduler_only())
        return asyncio.run(run_all())
    except KeyboardInterrupt:
        logger.info("interrupted by user")
        return 130
    except Exception as e:
        logger.exception("fatal: %s", e)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())


# Пояснения «для чайника»:
# • Как запускать:
# python -m backend.run                  # API + планировщик
# python -m backend.run --mode api       # только API
# python -m backend.run --mode scheduler # только планировщик
#
# • Где менять порт/хост:
# Экспортируйте API_HOST / API_PORT или задайте их в .env.*.
#
# • Что делает супервизор:
# — ищет корутину run_forever()/main_loop() и т.п. в каждом
# модуле задач (generate_energy, check_ton_inbox, ...),
# — если нет, но есть tick(), организует цикл tick→sleep(TICK_SEC)
# — ограничивает параллелизм (MAX_PARALLEL_SCHEDULER_TASKS),
# — прерывает «долго живущие» вызовы по TASK_TIMEOUT_SEC,
# — перезапускает упавшие с экспоненциальным бэкоффом.
#
# • Почему не паникуем при недоступности БД/сети на старте:
# Канон: самовосстановление; сервисы и вотчер повторят попытки
# в рамках своих ретраев и статусов next_retry_at.
