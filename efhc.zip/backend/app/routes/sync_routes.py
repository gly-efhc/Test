# backend/app/routes/sync_routes.py
# ======================================================================
# EFHC Bot — единый синхро-роут для фронта (сверка «на входе в экран»)
# ----------------------------------------------------------------------
# Назначение:
# • По запросу фронта (например, при открытии раздела) быстро «догоняет»
# посекундную генерацию конкретного пользователя (идемпотентно),
# затем возвращает единый снапшот для UI:
# - профиль и балансы,
# - сводку панелей,
# - предпросмотр обмена,
# - производную метрику gen_per_sec_effective (для анимации),
# - server_now и next_scheduler_eta_sec (когда тикнет планировщик).
#
# ИИ-защита / автономность:
# • Если догон генерации временно не удался (timeout/lock/network),
# мы НЕ роняем запрос — возвращаем актуальные на сейчас данные,
# параллельно ставим задачу в scheduler_task_log на авто-повтор
# ('resync_user_energy') и отдаём caller'у fallback_task_id.
# • Никаких денежных операций — только энергия (безопасно).
#
# Контракт:
# POST /sync/user/{tg_id}?fresh=1
# fresh=1 — попытаться догнать генерацию перед сбором снапшота.
# Ответ: см. SyncSnapshotOut ниже.
# ======================================================================

from __future__ import annotations

import hashlib
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.system_locks import (
    get_rate_base_d8,
    get_rate_vip_d8,
)
from app.deps import get_db
from app.services.energy_service import (
    generate_for_user as svc_generate_for_user,
)
from app.services.exchange_service import (
    preview_exchange as svc_preview_exchange,
)
from app.services.panels_service import (
    panels_summary as svc_panels_summary,
)
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()

EFHC_DECIMALS: int = int(getattr(settings, "EFHC_DECIMALS", 8) or 8)
Q8 = Decimal(1).scaleb(-EFHC_DECIMALS)

def _d8_setting(name: str, default: str) -> Decimal:
    raw = getattr(settings, name, default) or default
    return Decimal(str(raw)).quantize(Q8, rounding=ROUND_DOWN)


GEN_PER_SEC_BASE_KWH = get_rate_base_d8()
GEN_PER_SEC_VIP_KWH = get_rate_vip_d8()
DAILY_BASE = _d8_setting("PANEL_GENERATION_NORMAL", "0.598")
DAILY_VIP = _d8_setting("PANEL_GENERATION_VIP", "0.64")

TICK_SECONDS = 600  # плановый ритм планировщика 10 минут


def d8(x: Any) -> Decimal:
    """Decimal d8, rounding down."""
    return Decimal(str(x)).quantize(Q8, rounding=ROUND_DOWN)

router = APIRouter(prefix="/sync", tags=["sync"])

# ----------------------------------------------------------------------
# Модели ответа
# ----------------------------------------------------------------------


class ProfilePart(BaseModel):
    tg_id: int
    username: str | None
    is_vip: bool
    main_balance: str
    bonus_balance: str
    available_kwh: str
    total_generated_kwh: str
    daily_generation_base: str
    daily_generation_vip: str
    gen_per_sec_base: str
    gen_per_sec_vip: str


class PanelsPart(BaseModel):
    active_count: int
    total_generated_by_panels: str
    nearest_expire_at: str | None = None


class ExchangePart(BaseModel):
    ok: bool
    available_kwh: str
    max_exchangeable_kwh: str
    rate_kwh_to_efhc: str
    detail: str


class SyncMeta(BaseModel):
    server_now_iso: str = Field(..., description="Время сервера")
    gen_per_sec_effective: str = Field(
        ...,
        description="Скорость генерации (кВт·ч/сек)",
    )
    next_scheduler_eta_sec: int = Field(
        ...,
        description="Секунд до следующего тика планировщика",
    )
    fallback_task_id: int | None = Field(
        None,
        description="Если догон не удался — id постановки в очередь",
    )


class SyncSnapshotOut(BaseModel):
    profile: ProfilePart
    panels: PanelsPart
    exchange_preview: ExchangePart
    meta: SyncMeta

# ----------------------------------------------------------------------
# Вспомогательные функции
# ----------------------------------------------------------------------

async def _enqueue_resync_energy(
    db: AsyncSession,
    *,
    tg_id: int,
    reason: str,
    minutes: int = 10,
) -> int:
    """Ставит задачу на догон генерации в scheduler_task_log."""
    row = await db.execute(text(
            """
            INSERT INTO efhc_core.scheduler_task_log
                (
                    task_name,
                    status,
                    error_text,
                    payload,
                    retry_time,
                    executed_at,
                    duration_sec,
                    created_at,
                    updated_at
                )
    await db.commit()
            VALUES
                ('resync_user_energy', 'queued', :err,
                 jsonb_build_object('tg_id', :tg),
                 NOW() + (:min || ' minutes')::interval,
                 NULL, NULL, NOW(), NOW())
            RETURNING id
            """),
        {
            "err": reason[:500],
            "tg": int(tg_id),
            "min": int(minutes),
        },
    )
    rid = row.fetchone()
    return int(rid[0]) if rid else 0


def _is_transient_error(e: Exception) -> bool:
    """Определяет временную (транзиентную) ошибку."""
    s = f"{type(e).__name__}: {e}".lower()
    signs = (
        "timeout",
        "temporar",
        "connection",
        "too many",
        "locked",
        "deadlock",
        "network",
        "server error",
    )
    return any(sign in s for sign in signs)


def _calc_next_tick_eta_sec(server_now_epoch: int) -> int:
    """
    Считает, сколько секунд до ближайшего «кратного 600» момента.
    Например, если TICK_SECONDS=600, то тики: 00:00, 00:10, 00:20, ...
    """
    r = server_now_epoch % TICK_SECONDS
    return 0 if r == 0 else (TICK_SECONDS - r)

# ----------------------------------------------------------------------
# POST /sync/user/{tg_id}?fresh=1 — «жёсткая» сверка снапшота для UI
# ----------------------------------------------------------------------

@router.post(
    "/user/{tg_id}",
    response_model=SyncSnapshotOut,
    summary="Синхро-снапшот для UI",
)
async def sync_user_snapshot(tg_id: int,
    fresh: bool = Query(
        True,
        description=(
            "Попытаться догнать генерацию "
            "перед сбором снапшота"
        ),
    ),
    request: Request | None = None,
    response: Response | None = None,
    db: AsyncSession = Depends(get_db),
) -> SyncSnapshotOut | Response:
    """Собирает единый снапшот для UI."""
    fallback_task_id: int | None = None

    # 1) При необходимости — «догон генерации» для пользователя
    # операция)
    if fresh:
        try:
            await svc_generate_for_user(db, tg_id = int(tg_id))
        except Exception as e:
            logger.warning(
                "sync: generate_for_user failed (user %s): %s",
                tg_id,
                e
            )
            if _is_transient_error(e):
                try:
                    reason = (
                        f"transient: {type(e).__name__}: {e}"
                    )
                    fallback_task_id = await _enqueue_resync_energy(
                        db,
                        tg_id=int(tg_id),
                        reason=reason,
                        minutes=10,
                    )
                except Exception as enq_err:
                    logger.warning(
                        "sync: enqueue resync failed: %s",
                        enq_err,
                    )
            # Даже если ошибка — продолжаем формировать снапшот
            # состояния

    # 2) Профиль/балансы
    row = await db.execute(text(
            """
            SELECT
              u.tg_id,
              u.username,
              COALESCE(u.is_vip, FALSE) AS is_vip,
              COALESCE(u.main_balance, 0) AS main_balance,
              COALESCE(u.bonus_balance, 0) AS bonus_balance,
              COALESCE(u.available_kwh, 0) AS available_kwh,
              COALESCE(u.total_generated_kwh, 0) AS total_generated_kwh
            FROM efhc_core.users u
            WHERE u.tg_id = :tg
            LIMIT 1
            """),
        {"tg": int(tg_id)},)
    rec = row.fetchone()
    if not rec:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="user_not_found",
        )

    is_vip = bool(rec[2])
    gen_rate = GEN_PER_SEC_VIP_KWH if is_vip else GEN_PER_SEC_BASE_KWH

    profile = ProfilePart(
        tg_id=int(rec[0]),
        username=rec[1],
        is_vip=is_vip,
        main_balance=str(d8(rec[3])),
        bonus_balance=str(d8(rec[4])),
        available_kwh=str(d8(rec[5])),
        total_generated_kwh=str(d8(rec[6])),
        daily_generation_base=str(DAILY_BASE),
        daily_generation_vip=str(DAILY_VIP),
        gen_per_sec_base=str(GEN_PER_SEC_BASE_KWH),
        gen_per_sec_vip=str(GEN_PER_SEC_VIP_KWH),
    )

    # 3) Сводка панелей
    ps = await svc_panels_summary(db, tg_id = int(tg_id))
    active_count = int(ps["active_count"])
    gen_per_sec_effective = d8(Decimal(active_count) * gen_rate)

    nearest = ps.get("nearest_expire_at")
    panels = PanelsPart(
        active_count=active_count,
        total_generated_by_panels=str(
            d8(ps["total_generated_by_panels"])
        ),
        nearest_expire_at=(nearest.isoformat() if nearest else None),
    )

    # 4) Предпросмотр обмена
    xp = await svc_preview_exchange(db, tg_id = int(tg_id))
    exchange_preview = ExchangePart(
        ok=bool(xp.ok),
        available_kwh=str(d8(xp.available_kwh)),
        max_exchangeable_kwh=str(d8(xp.max_exchangeable_kwh)),
        rate_kwh_to_efhc=str(d8(xp.rate_kwh_to_efhc)),
        detail=xp.detail,
    )

    # 5) Мета: время сервера и ETA до следующего тика планировщика
    # Получаем epoch через now() в БД, чтобы не зависеть от клиента
    now_sql = (
        "SELECT EXTRACT(EPOCH FROM NOW())::bigint, "
        "NOW()::timestamptz"
    )
    now_row = await db.execute(text(now_sql))
    epoch_val, now_ts = now_row.fetchone()
    eta = _calc_next_tick_eta_sec(int(epoch_val))

    meta = SyncMeta(
        server_now_iso=str(now_ts.isoformat()),
        gen_per_sec_effective=str(gen_per_sec_effective),
        next_scheduler_eta_sec=int(eta),
        fallback_task_id=fallback_task_id,
    )

    out = SyncSnapshotOut(
        profile=profile,
        panels=panels,
        exchange_preview=exchange_preview,
        meta=meta,
    )

    # ETag/304 по канону согласования фронта и бэка:
    # If-None-Match: ответ 304, если снапшот не изменился.
    # Здесь ETag вычисляется как sha256(json snapshot).
    try:
        payload = jsonable_encoder(out)
        raw = str(payload).encode("utf-8")
        etag = hashlib.sha256(raw).hexdigest()
        if response is not None:
            response.headers["ETag"] = etag
        inm = None
        if request is not None:
            inm = request.headers.get("If-None-Match")
        if inm and inm == etag:
            return Response(status_code=status.HTTP_304_NOT_MODIFIED)
    except Exception as e:
        logger.warning(
            "sync: etag compute failed: %s",
            e,
            exc_info=True,
        )

    return out
