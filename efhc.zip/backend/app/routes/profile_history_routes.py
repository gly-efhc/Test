"""HTTP-контур единой истории профиля и серверного экспорта."""

from __future__ import annotations

import csv
import os
import tempfile
from collections.abc import AsyncIterator
from datetime import UTC, datetime
from pathlib import Path

from app.core.database_core import get_session_factory
from app.identity.financial_owner import FinancialReadOwner
from app.identity.financial_read_dependency import get_financial_read_owner
from app.schemas.profile_history_schemas import (
    ProfileHistoryItemOut,
    ProfileHistoryPageOut,
)
from app.services.profile_history_service import (
    PROFILE_HISTORY_EXPORT_BATCH_SIZE,
    PROFILE_HISTORY_PAGE_SIZE,
    ProfileHistoryRecord,
    list_profile_history_page,
)
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

router = APIRouter(prefix="/profile", tags=["profile-history"])


def _wire_item(item: ProfileHistoryRecord) -> ProfileHistoryItemOut:
    return ProfileHistoryItemOut(
        id=item.id,
        source=item.source,
        kind=item.kind,
        occurred_at=item.occurred_at.astimezone(UTC).isoformat(),
        status=item.status,
        direction=item.direction,
        balance_type=item.balance_type,
        amount_efhc=item.amount_efhc,
        amount_asset=item.amount_asset,
        asset=item.asset,
        reason=item.reason,
    )


@router.get(
    "/history",
    response_model=ProfileHistoryPageOut,
    summary="Единая история профиля: ровно один keyset stream по 50 операций",
)
async def profile_history(
    cursor: str | None = Query(None),
    owner: FinancialReadOwner = Depends(get_financial_read_owner),
) -> ProfileHistoryPageOut:
    session_factory = get_session_factory()
    try:
        async with session_factory() as db:
            page = await list_profile_history_page(
                db,
                global_id=owner.global_id,
                cursor=cursor,
                page_size=PROFILE_HISTORY_PAGE_SIZE,
            )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="PROFILE_HISTORY_CURSOR_INVALID",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PROFILE_HISTORY_UNAVAILABLE",
        ) from exc
    return ProfileHistoryPageOut(
        items=[_wire_item(item) for item in page.items],
        next_cursor=page.next_cursor,
        page_size=PROFILE_HISTORY_PAGE_SIZE,
    )


def _csv_safe(value: object) -> str:
    raw = "" if value is None else str(value)
    if raw.startswith(("=", "+", "-", "@")):
        return "'" + raw
    return raw


def _row_values(item: ProfileHistoryRecord) -> list[str]:
    return [
        item.occurred_at.astimezone(UTC).isoformat(),
        item.source,
        item.kind,
        str(item.id),
        item.status or "",
        item.direction or "",
        item.balance_type or "",
        item.amount_efhc or "",
        item.amount_asset or "",
        item.asset or "",
        item.reason or "",
    ]


async def _history_records(global_id: int) -> AsyncIterator[ProfileHistoryRecord]:
    session_factory = get_session_factory()
    cursor: str | None = None
    seen: set[str] = set()
    async with session_factory() as db:
        while True:
            page = await list_profile_history_page(
                db,
                global_id=global_id,
                cursor=cursor,
                page_size=PROFILE_HISTORY_EXPORT_BATCH_SIZE,
            )
            for item in page.items:
                yield item
            next_cursor = page.next_cursor
            if not next_cursor:
                break
            if next_cursor in seen:
                raise RuntimeError("PROFILE_HISTORY_EXPORT_CURSOR_LOOP")
            seen.add(next_cursor)
            cursor = next_cursor


def _delete_temp_file(path: str) -> None:
    Path(path).unlink(missing_ok=True)


async def _build_csv_export(global_id: int) -> Path:
    fd, name = tempfile.mkstemp(prefix="efhc_history_", suffix=".csv")
    os.close(fd)
    path = Path(name)
    try:
        with path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle, lineterminator="\r\n")
            writer.writerow(
                [
                    "occurred_at",
                    "source",
                    "kind",
                    "id",
                    "status",
                    "direction",
                    "balance_type",
                    "amount_efhc",
                    "amount_asset",
                    "asset",
                    "reason",
                ]
            )
            async for item in _history_records(global_id):
                writer.writerow([_csv_safe(v) for v in _row_values(item)])
        return path
    except Exception:
        path.unlink(missing_ok=True)
        raise


@router.get("/history/export.csv", summary="CSV export общей истории профиля")
async def profile_history_csv(
    owner: FinancialReadOwner = Depends(get_financial_read_owner),
) -> FileResponse:
    try:
        path = await _build_csv_export(owner.global_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PROFILE_HISTORY_EXPORT_UNAVAILABLE",
        ) from exc
    day = datetime.now(UTC).date().isoformat()
    return FileResponse(
        path=path,
        media_type="text/csv; charset=utf-8",
        filename=f"EFHC_operations_{day}.csv",
        background=BackgroundTask(_delete_temp_file, str(path)),
    )


async def _build_xlsx_export(global_id: int) -> Path:
    try:
        from openpyxl import Workbook
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("XLSX_EXPORT_UNAVAILABLE") from exc

    fd, name = tempfile.mkstemp(prefix="efhc_history_", suffix=".xlsx")
    os.close(fd)
    path = Path(name)
    try:
        workbook = Workbook(write_only=True)
        sheet = workbook.create_sheet("Operations")
        sheet.append(
            [
                "occurred_at",
                "source",
                "kind",
                "id",
                "status",
                "direction",
                "balance_type",
                "amount_efhc",
                "amount_asset",
                "asset",
                "reason",
            ]
        )
        async for item in _history_records(global_id):
            sheet.append([_csv_safe(v) for v in _row_values(item)])
        workbook.save(path)
        return path
    except Exception:
        path.unlink(missing_ok=True)
        raise


@router.get("/history/export.xlsx", summary="XLSX export общей истории профиля")
async def profile_history_xlsx(
    owner: FinancialReadOwner = Depends(get_financial_read_owner),
) -> FileResponse:
    try:
        path = await _build_xlsx_export(owner.global_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="XLSX_EXPORT_UNAVAILABLE",
        ) from exc
    day = datetime.now(UTC).date().isoformat()
    return FileResponse(
        path=path,
        media_type=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
        filename=f"EFHC_operations_{day}.xlsx",
        background=BackgroundTask(_delete_temp_file, str(path)),
    )

__all__ = ["router"]
