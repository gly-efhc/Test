# -*- coding: utf-8 -*-
# backend/app/routes/admin_panels_routes.py
# ======================================================================
# Админские HTTP-ручки «Панели» EFHC Bot.
#
# UI:
# - GET /admin/panels?tg_id=...&is_active=true
# - PATCH /admin/panels/{panel_id}/activate
# - PATCH /admin/panels/{panel_id}/deactivate
#
# Канон:
# - require_admin
# - Idempotency-Key для изменений
# - логирование действия
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Query,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.utils_core import format_decimal_str
from backend.app.deps import d8, get_db, require_admin
from backend.app.services.admin.admin_logging import AdminLogger

S = get_settings()
SCHEMA_CORE: str = (
    getattr(S, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core"
)

router = APIRouter(prefix="/admin/panels", tags=["admin-panels"])


def _iso(dt: Any) -> Optional[str]:
    if dt is None:
        return None
    if isinstance(dt, str):
        return dt
    if isinstance(dt, datetime):
        return dt.isoformat()
    return str(dt)


def _require_idempotency(idem: Optional[str]) -> str:
    k = (idem or "").strip()
    if not k:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key header is required",
        )
    return k


class PanelItem(BaseModel):
    id: int
    tg_id: int
    is_active: bool
    created_at: str
    expires_at: Optional[str] = None
    archived_at: Optional[str] = None
    last_generated_at: Optional[str] = None
    base_gen_per_sec: str
    generated_kwh: str


class PanelsOut(BaseModel):
    ok: bool = True
    items: List[PanelItem] = Field(default_factory=list)


@router.get("/", response_model=PanelsOut)
async def admin_panels_list(
    tg_id: Optional[int] = Query(default=None),
    is_active: bool = Query(default=False),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> PanelsOut:
    where = []
    params: dict[str, Any] = {}

    if tg_id is not None:
        where.append("tg_id = :tg_id")
        params["tg_id"] = int(tg_id)
    if is_active:
        where.append("is_active = TRUE")

    where_sql = " AND ".join(where) if where else "TRUE"

    sql = text(
        f"""
        SELECT
            id,
            tg_id,
            COALESCE(is_active, TRUE) AS is_active,
            created_at,
            expires_at,
            archived_at,
            last_generated_at,
            COALESCE(base_gen_per_sec, 0) AS base_gen_per_sec,
            COALESCE(generated_kwh, 0) AS generated_kwh
        FROM {SCHEMA_CORE}.panels
        WHERE {where_sql}
        ORDER BY id DESC
        LIMIT 500
        """
    )
    r: Result = await db.execute(sql, params)

    items: List[PanelItem] = []
    for row in r.fetchall():
        items.append(
            PanelItem(
                id=int(row.id),
                tg_id=int(row.tg_id),
                is_active=bool(row.is_active),
                created_at=_iso(row.created_at) or "",
                expires_at=_iso(row.expires_at),
                archived_at=_iso(row.archived_at),
                last_generated_at=_iso(row.last_generated_at),
                base_gen_per_sec=format_decimal_str(
                    d8(row.base_gen_per_sec)
                ),
                generated_kwh=format_decimal_str(d8(row.generated_kwh)),
            )
        )

    return PanelsOut(ok=True, items=items)


@router.patch("/{panel_id}/activate", status_code=204)
async def admin_panels_activate(
    panel_id: int,
    idempotency_key: Optional[str] = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    idem = _require_idempotency(idempotency_key)

    sql = text(
        f"""
        UPDATE {SCHEMA_CORE}.panels
        SET
            is_active = TRUE,
            archived_at = NULL
        WHERE id = :id
        """
    )
    res = await db.execute(sql, {"id": int(panel_id)})
    if res.rowcount == 0:
        raise HTTPException(status_code=404, detail="panel not found")

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="activate",
        entity="panel",
        entity_id=int(panel_id),
        details=f"idem={idem}",
    )
    return None


@router.patch("/{panel_id}/deactivate", status_code=204)
async def admin_panels_deactivate(
    panel_id: int,
    idempotency_key: Optional[str] = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    idem = _require_idempotency(idempotency_key)

    sql = text(
        f"""
        UPDATE {SCHEMA_CORE}.panels
        SET
            is_active = FALSE,
            archived_at = COALESCE(
                archived_at,
                NOW() AT TIME ZONE 'UTC'
            )
        WHERE id = :id
        """
    )
    res = await db.execute(sql, {"id": int(panel_id)})
    if res.rowcount == 0:
        raise HTTPException(status_code=404, detail="panel not found")

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="deactivate",
        entity="panel",
        entity_id=int(panel_id),
        details=f"idem={idem}",
    )
    return None
