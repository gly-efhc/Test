# backend/app/routes/admin_panels_routes.py
# ======================================================================
# Админские HTTP-ручки «Панели» EFHC Bot.
#
# UI:
# - GET /admin/panels?tg_id=...&is_active=true
# - PATCH /admin/panels/{panel_id}/activate
# - PATCH /admin/panels/{panel_id}/deactivate
#
# Канон:
# - require_admin
# - Idempotency-Key для изменений
# - логирование действия
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any

from app.core.utils_core import format_decimal_str
from app.deps import d8, get_db, require_admin
from app.models.panels_models import Panel
from app.services.admin.admin_logging import AdminLogger
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Query,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/admin/panels", tags=["admin:panels"])


def _iso(dt: Any) -> str | None:
    if dt is None:
        return None
    if isinstance(dt, str):
        return dt
    if isinstance(dt, datetime):
        return dt.isoformat()
    return str(dt)


def _require_idempotency(idem: str | None) -> str:
    k = (idem or "").strip()
    if not k:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key header is required",
        )
    return k


class PanelItem(BaseModel):
    id: int
    tg_id: int
    is_active: bool
    created_at: str
    expires_at: str | None = None
    archived_at: str | None = None
    last_generated_at: str | None = None
    base_gen_per_sec: str
    generated_kwh: str


class PanelsOut(BaseModel):
    ok: bool = True
    items: list[PanelItem] = Field(default_factory=list)


@router.get("/", response_model=PanelsOut)
async def admin_panels_list(
    tg_id: int | None = Query(default=None),
    is_active: bool = Query(default=False),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> PanelsOut:
    stmt = select(Panel).order_by(Panel.id.desc()).limit(500)

    if tg_id is not None:
        stmt = stmt.where(Panel.tg_id == int(tg_id))
    if is_active:
        stmt = stmt.where(Panel.is_active.is_(True))

    res = await db.execute(stmt)
    items: list[PanelItem] = []

    for panel in res.scalars().all():
        items.append(
            PanelItem(
                id=int(panel.id),
                tg_id=int(panel.tg_id),
                is_active=bool(panel.is_active),
                created_at=_iso(panel.created_at) or "",
                expires_at=_iso(panel.expires_at),
                archived_at=_iso(panel.archived_at),
                last_generated_at=_iso(panel.last_generated_at),
                base_gen_per_sec=format_decimal_str(
                    d8(panel.base_gen_per_sec or 0)
                ),
                generated_kwh=format_decimal_str(
                    d8(panel.generated_kwh or 0)
                ),
            )
        )

    return PanelsOut(ok=True, items=items)


@router.patch("/{panel_id}/activate", status_code=204)
async def admin_panels_activate(
    panel_id: int,
    idempotency_key: str | None = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    idem = _require_idempotency(idempotency_key)

    sql = text("""
        UPDATE efhc_core.panels
        SET 
            is_active = TRUE,
            archived_at = NULL
        WHERE id = :id
        """)
    res = await db.execute(sql, {"id": int(panel_id)})
    if getattr(res, "rowcount", None) == 0:
        raise HTTPException(status_code=404, detail="panel not found")

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="activate",
        entity="panel",
        entity_id=int(panel_id),
        details=f"idem={idem}",
    )

    await db.commit()

    return None


@router.patch("/{panel_id}/deactivate", status_code=204)
async def admin_panels_deactivate(
    panel_id: int,
    idempotency_key: str | None = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    idem = _require_idempotency(idempotency_key)

    sql = text("""
        UPDATE efhc_core.panels
        SET
            is_active = FALSE, 
            archived_at = COALESCE(
                archived_at,
                NOW() AT TIME ZONE 'UTC'
            )
        WHERE id = :id
        """)
    res = await db.execute(sql, {"id": int(panel_id)})
    if getattr(res, "rowcount", None) == 0:
        raise HTTPException(status_code=404, detail="panel not found")

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="deactivate",
        entity="panel",
        entity_id=int(panel_id),
        details=f"idem={idem}",
    )

    await db.commit()

    return None
