# -*- coding: utf-8 -*-
# backend/app/routes/me_routes.py
# =====================================================================
# GET /api/v1/me — безопасная витрина профиля для Telegram WebApp.
# • Идентификация: deps.get_current_tg_id (initData/заголовки).
# • Денежных операций нет.
# • Если пользователя нет — ensure_user создаёт профиль без балансов.
# =====================================================================

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.crud.user_crud import ensure_user
from backend.app.deps import get_current_tg_id, get_db
from backend.app.services.nft_check_service import check_user_vip_once

logger = get_logger(__name__)

router = APIRouter(tags=["me"])


@router.get("/api/v1/me")
async def me(
    db: AsyncSession = Depends(get_db),
    tg_id: int = Depends(get_current_tg_id),
) -> dict:
    user = await ensure_user(db, tg_id=tg_id)

    try:
        now = datetime.now(timezone.utc)
        last_checked = getattr(user, "vip_checked_at", None)
        stale = (last_checked is None) or (
            now - last_checked > timedelta(seconds=600)
        )
        if getattr(user, "ton_wallet", None) and stale:
            await check_user_vip_once(
                db,
                tg_id=int(user.tg_id),
                force_refresh=False,
            )
            await db.commit()
            await db.refresh(user)
    except Exception:
        logger.warning("me: vip refresh failed", exc_info=True)

    return {
        "tg_id": int(user.tg_id),
        "username": user.username,
        "vip": bool(user.is_vip),
    }
