# backend/app/routes/deposit_routes.py
# ----------------------------------------------------------------------
# Deposit EFHC (on-chain): A+B контур.
# • packages list (pricing)
# • POST /deposit/efhc → PaymentIntent + TonConnect tx
# ----------------------------------------------------------------------

from __future__ import annotations

from app.deps import (
    get_current_tg_id,
    get_db,
    require_idempotency_key,
    require_wallet_connected,
)
from app.schemas.deposit_schemas import (
    DepositEFHCIn,
    DepositEFHCOut,
    DepositPackagesOut,
)
from app.services.payment_intents_service import (
    create_intent_deposit_by_package,
)
from fastapi import APIRouter, Depends, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/deposit", tags=["deposit"])

@router.get(
    "/packages",
    response_model=DepositPackagesOut,
    summary="Active EFHC sale packages (for deposit)",
)
async def list_deposit_packages(
    db: AsyncSession = Depends(get_db),
) -> DepositPackagesOut:
    # Канон: пакеты депозита берём из ORM-таблицы efhc_core.shop_items.
    # Важно: это устраняет зависимость от не-ORM таблиц (efhc_admin.*).
    # локально, чтобы не тянуть лишнее при импорте модуля
    from app.deps import d8  # d8 = Decimal(8) ROUND_DOWN
    from app.models.shop_models import ShopItem

    stmt = (
        select(ShopItem)
        .where(ShopItem.is_active.is_(True))
        .where(ShopItem.quantity_efhc.is_not(None))
        .order_by(ShopItem.id.asc())
    )
    rows = (await db.execute(stmt)).scalars().all()

    items = []
    for obj in rows:
        extra = obj.extra or {}
        asset = str(extra.get("asset") or "TON").upper()
        price_asset_d8 = extra.get("price_asset_d8")
        if price_asset_d8 is None:
            # Если цена не задана — не показываем позицию в депозит-
            # пакетах.
            continue
        items.append(
            {
                "id": int(obj.id),
                "title": str(obj.title or ""),
                "asset": asset,
                "price_asset_d8": str(d8(price_asset_d8)),
                # quantity_efhc хранится как Decimal(30,8) — это и есть
                # d8.
                "efhc_amount_d8": str(d8(obj.quantity_efhc)),
                "is_active": bool(obj.is_active),
            }
        )

    return DepositPackagesOut(items=items)




@router.post(
    "/efhc",
    response_model=DepositEFHCOut,
    status_code=status.HTTP_200_OK,
    summary="Deposit EFHC (on-chain, TonConnect required)",
)
async def deposit_efhc(
    request: Request,
    payload: DepositEFHCIn,
    db: AsyncSession = Depends(get_db),
    tg_id: int = Depends(get_current_tg_id),
    _idk: str = Depends(require_idempotency_key),
) -> DepositEFHCOut:
    """Создаёт deposit-intent и возвращает TonConnect transaction."""

    await require_wallet_connected(
        request,
        db=db,
        current_tg_id=tg_id,
        feature="deposit",
    )

    result = await create_intent_deposit_by_package(
        db,
        tg_id=int(tg_id),
        idempotency_key=str(_idk),
        package_id=int(payload.package_id),
    )
    return DepositEFHCOut(
        intent_id=int(result["intent_id"]),
        asset=str(result["asset"]),
        amount_asset_d8=str(result["amount_asset_d8"]),
        efhc_amount_d8=str(result["efhc_amount_d8"]),
        payload=str(result["payload"]),
        tonconnect_tx=result["tonconnect_tx"],
    )
