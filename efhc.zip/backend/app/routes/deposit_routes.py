# -*- coding: utf-8 -*-
# backend/app/routes/deposit_routes.py
# ----------------------------------------------------------------------
# Deposit EFHC (on-chain): A+B контур.
# • packages list (pricing)
# • POST /deposit/efhc → PaymentIntent + TonConnect tx
# ----------------------------------------------------------------------

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.deps import (
    get_current_tg_id,
    get_db,
    require_idempotency_key,
    require_wallet_connected,
)
from backend.app.schemas.deposit_schemas import (
    DepositEFHCIn,
    DepositEFHCOut,
    DepositPackagesOut,
)
from backend.app.services.payment_intents_service import (
    create_intent_deposit_by_package,
)


router = APIRouter(prefix="/deposit", tags=["deposit"])

S = get_settings()
SCHEMA_ADMIN = S.DB_SCHEMA_ADMIN
@router.get(
    "/packages",
    response_model=DepositPackagesOut,
    summary="Active EFHC sale packages (for deposit)",
)
async def list_deposit_packages(
    db: AsyncSession = Depends(get_db),
) -> DepositPackagesOut:
    q = text(
        "\n".join(
            [
                "SELECT id, title, asset,",
                "       price_asset_d8::numeric,",
                "       efhc_amount_d8::numeric,",
                "       COALESCE(is_active, TRUE) AS is_active",
                f"  FROM {SCHEMA_ADMIN}.efhc_sale_packages",
                " WHERE COALESCE(is_active, TRUE) = TRUE",
                " ORDER BY id ASC",
            ]
        )
    )
    rows = (await db.execute(q)).mappings().all()
    items = []
    for r in rows:
        items.append(
            {
                "id": int(r["id"]),
                "title": str(r["title"] or ""),
                "asset": str(r["asset"] or "TON"),
                "price_asset_d8": str(r["price_asset_d8"]),
                "efhc_amount_d8": str(r["efhc_amount_d8"]),
                "is_active": bool(r["is_active"]),
            }
        )
    return DepositPackagesOut(items=items)



@router.post(
    "/efhc",
    response_model=DepositEFHCOut,
    status_code=status.HTTP_200_OK,
    summary="Deposit EFHC (on-chain, TonConnect required)",
)
async def deposit_efhc(
    request: Request,
    payload: DepositEFHCIn,
    db: AsyncSession = Depends(get_db),
    tg_id: int = Depends(get_current_tg_id),
    _idk: str = Depends(require_idempotency_key),
) -> DepositEFHCOut:
    """Создаёт deposit-intent и возвращает TonConnect transaction."""

    await require_wallet_connected(
        request,
        db=db,
        current_tg_id=tg_id,
        feature="deposit",
    )

    result = await create_intent_deposit_by_package(
        db,
        tg_id=int(tg_id),
        idempotency_key=str(_idk),
        package_id=int(payload.package_id),
    )
    return DepositEFHCOut(
        intent_id=int(result["intent_id"]),
        asset=str(result["asset"]),
        amount_asset_d8=str(result["amount_asset_d8"]),
        efhc_amount_d8=str(result["efhc_amount_d8"]),
        payload=str(result["payload"]),
        tonconnect_tx=result["tonconnect_tx"],
    )