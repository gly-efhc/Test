# backend/app/routes/admin_shop_routes.py
# ======================================================================
# EFHC Bot — Admin: Shop routes
# ----------------------------------------------------------------------
# Назначение:
# Admin-layer для `/admin/shop`. Hub manager вынесен в
# отдельный router module и не вкладывается в shop router.
#
# Канон:
# • Только tg_id во внешнем слое.
# ======================================================================

from __future__ import annotations

from decimal import Decimal
from typing import Any, cast

from app.deps import get_db, require_admin
from app.services.admin.admin_shop_service import (
    admin_delete_item,
    admin_force_fulfill_order,
    admin_list_items,
    admin_list_orders,
    admin_set_item_status,
    admin_set_price,
    admin_upsert_item,
)
from app.services.orders_service import (
    get_order as legacy_get_order,
)
from app.services.orders_service import (
    list_user_orders as legacy_list_user_orders,
)
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/admin/shop", tags=["admin:shop"])


class LegacyOrderOut(BaseModel):
    order_id: int
    tg_id: int | None = None
    status: str
    type: str
    tx_hash: str | None = None
    memo: str | None = None


def _legacy_order_to_out(order: Any) -> LegacyOrderOut:
    raw_order_id = getattr(order, "order_id", None)
    if raw_order_id is None:
        raw_order_id = getattr(order, "id", 0)
    order_id = 0 if raw_order_id is None else int(raw_order_id)
    return LegacyOrderOut(
        order_id=order_id,
        tg_id=getattr(order, "tg_id", None),
        status=str(getattr(order, "status", "")),
        type=str(getattr(order, "type", "")),
        tx_hash=getattr(order, "tx_hash", None),
        memo=getattr(order, "memo", None),
    )


class AdminShopItemOut(BaseModel):
    id: int
    code: str
    sku: str
    title: str
    description: str = ""
    item_type: str
    is_active: bool
    status: str = "draft"
    quantity_efhc: str = ""
    image_url: str = ""
    price_ton: str = ""
    price_usdt: str = ""
    pay_currencies: list[str] = Field(default_factory=list)
    history_count: int = 0
    history_tail: list[dict[str, Any]] = Field(default_factory=list)


class AdminShopItemUpsertIn(BaseModel):
    code: str = Field(..., min_length=1, max_length=64)
    title: str = Field(..., min_length=1, max_length=128)
    description: str | None = Field(default=None, max_length=512)
    item_type: str = Field(
        default="EFHC_PACKAGE",
        min_length=1,
        max_length=64,
    )
    quantity_efhc: Decimal | None = None
    image_url: str | None = Field(default=None, max_length=2048)
    status: str = Field(default="draft", min_length=1, max_length=16)
    price_ton: Decimal | None = None
    price_usdt: Decimal | None = None
    pay_currencies: list[str] | None = None


class SetPriceIn(BaseModel):
    code: str = Field(..., min_length=1, max_length=64)
    price_efhc: Decimal | None = None
    price_ton: Decimal | None = None
    price_usdt: Decimal | None = None
    pay_currencies: list[str] | None = None
    is_active: bool | None = None


class SetItemStatusIn(BaseModel):
    code: str = Field(..., min_length=1, max_length=64)
    status: str = Field(..., min_length=1, max_length=16)


class DeleteItemIn(BaseModel):
    code: str = Field(..., min_length=1, max_length=64)


class ForceFulfillOrderIn(BaseModel):
    reason: str | None = Field(default=None, max_length=512)


@router.get("/orders")
async def admin_orders(
    limit: int = Query(default=50, ge=1, le=200),
    cursor: str | None = None,
    status: str | None = None,
    item_type: str | None = None,
    tg_id: int | None = None,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    """Админский список заказов магазина с курсорной пагинацией."""
    try:
        return cast(
            dict[str, Any],
            await admin_list_orders(
                db,
                limit=int(limit),
                cursor=cursor,
                status=status,
                item_type=item_type,
                tg_id=tg_id,
            ),
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=(f"admin orders failed: {e}"),
        ) from e


@router.post("/orders/{order_id}/force-fulfill")
async def admin_force_fulfill_shop_order(
    order_id: int,
    payload: ForceFulfillOrderIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    try:
        return cast(
            dict[str, Any],
            await admin_force_fulfill_order(
                db,
                order_id=int(order_id),
                reason=payload.reason,
            ),
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"force fulfill failed: {e}",
        ) from e


@router.get("/items", response_model=list[AdminShopItemOut])
async def admin_items(
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[AdminShopItemOut]:
    try:
        rows = await admin_list_items(db)
        return [AdminShopItemOut.model_validate(row) for row in rows]
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"admin items failed: {e}",
        ) from e


@router.post("/items/upsert")
async def admin_upsert_shop_item(
    payload: AdminShopItemUpsertIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    try:
        return cast(
            dict[str, Any],
            await admin_upsert_item(
                db,
                code=payload.code,
                title=payload.title,
                description=payload.description,
                item_type=payload.item_type,
                quantity_efhc=payload.quantity_efhc,
                image_url=payload.image_url,
                status=payload.status,
                price_ton=payload.price_ton,
                price_usdt=payload.price_usdt,
                pay_currencies=payload.pay_currencies,
            ),
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"admin upsert item failed: {e}",
        ) from e


@router.get("/order/legacy/{order_id}", response_model=LegacyOrderOut)
async def admin_legacy_get_order(
    order_id: int,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> LegacyOrderOut:
    """Read order via orders_service legacy path."""
    try:
        order = await legacy_get_order(db, order_id=int(order_id))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"legacy order read failed: {e}",
        ) from e
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return _legacy_order_to_out(order)


@router.get(
    "/orders/user/legacy/{tg_id}",
    response_model=list[LegacyOrderOut],
)
async def admin_legacy_list_user_orders(
    tg_id: int,
    limit: int = Query(default=50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[LegacyOrderOut]:
    """List user orders via orders_service legacy path."""
    try:
        rows = await legacy_list_user_orders(
            db,
            tg_id=int(tg_id),
            limit=int(limit),
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"legacy user orders failed: {e}",
        ) from e
    return [_legacy_order_to_out(order) for order in rows]


@router.post("/items/status")
async def admin_set_shop_item_status(
    payload: SetItemStatusIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    try:
        return cast(
            dict[str, Any],
            await admin_set_item_status(
                db,
                code=payload.code,
                status=payload.status,
            ),
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"admin set item status failed: {e}",
        ) from e


# ADMIN_ORPHAN_ROUTE_STATUS: legacy/internal route.
# UI currently uses /admin/shop/items/upsert for normal price edits.
# Keep this route for backward-compatible operator tools only.
@router.post("/items/set-price")
async def admin_set_item_price(
    payload: SetPriceIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    """Обновить цену/валюты оплаты товара (по code)."""
    try:
        return cast(
            dict[str, Any],
            await admin_set_price(
                db,
                code=payload.code,
                price_efhc=payload.price_efhc,
                price_ton=payload.price_ton,
                price_usdt=payload.price_usdt,
                pay_currencies=payload.pay_currencies,
                is_active=payload.is_active,
            ),
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=(f"admin set price failed: {e}"),
        ) from e


@router.post("/items/delete")
async def admin_delete_shop_item(
    payload: DeleteItemIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    try:
        return cast(
            dict[str, Any],
            await admin_delete_item(
                db,
                code=payload.code,
            ),
        )
    except ValueError as e:
        raise HTTPException(
            status_code=409,
            detail=f"admin delete item blocked: {e}",
        ) from e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"admin delete item failed: {e}",
        ) from e
