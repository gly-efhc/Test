# backend/app/routes/admin_shop_routes.py
# ======================================================================
# EFHC Bot — Admin: Shop / Hub admin aliases
# ----------------------------------------------------------------------
# Назначение:
# Переходный admin-layer для legacy `/admin/shop` и нового Hub links
# manager. Денежные shop-ручки сохранены как технический алиас, а Hub
# manager живёт в этом же модуле до полного завершения миграции.
#
# Канон:
# • Только tg_id во внешнем слое.
# • Изменения Hub links требуют Idempotency-Key.
# • User-facing/admin-facing label должен быть Hub.
# ======================================================================

from __future__ import annotations

from decimal import Decimal
from typing import Any, cast

from app.deps import (
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from app.schemas.hub_admin_schemas import (
    HubLinkAdminCreateIn,
    HubLinkAdminOut,
    HubLinkAdminReorderIn,
    HubLinkAdminToggleIn,
    HubLinkAdminUpdateIn,
)
from app.services.admin.admin_hub_links_service import (
    HubLinkAdminError,
    admin_create_hub_link,
    admin_list_hub_links,
    admin_reorder_hub_links,
    admin_toggle_hub_link,
    admin_update_hub_link,
)
from app.services.admin.admin_shop_service import (
    admin_list_orders,
    admin_set_price,
)
from app.services.orders_service import (
    get_order as legacy_get_order,
)
from app.services.orders_service import (
    list_user_orders as legacy_list_user_orders,
)
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/admin/shop", tags=["admin:shop"])
hub_router = APIRouter(prefix="/admin/hub", tags=["admin:hub"])


class LegacyOrderOut(BaseModel):
    order_id: int
    tg_id: int | None = None
    status: str
    type: str
    tx_hash: str | None = None
    memo: str | None = None


def _legacy_order_to_out(order: Any) -> LegacyOrderOut:
    raw_order_id = getattr(order, "order_id", None)
    if raw_order_id is None:
        raw_order_id = getattr(order, "id", 0)
    order_id = 0 if raw_order_id is None else int(raw_order_id)
    return LegacyOrderOut(
        order_id=order_id,
        tg_id=getattr(order, "tg_id", None),
        status=str(getattr(order, "status", "")),
        type=str(getattr(order, "type", "")),
        tx_hash=getattr(order, "tx_hash", None),
        memo=getattr(order, "memo", None),
    )


class SetPriceIn(BaseModel):
    code: str = Field(..., min_length=1, max_length=64)
    price_efhc: Decimal | None = None
    price_ton: Decimal | None = None
    price_usdt: Decimal | None = None
    pay_currencies: list[str] | None = None
    is_active: bool | None = None


@router.get("/orders")
async def admin_orders(
    limit: int = Query(default=50, ge=1, le=200),
    cursor: str | None = None,
    status: str | None = None,
    item_type: str | None = None,
    tg_id: int | None = None,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    """Админский список заказов магазина с курсорной пагинацией."""
    try:
        return cast(dict[str, Any], await admin_list_orders(
            db,
            limit=int(limit),
            cursor=cursor,
            status=status,
            item_type=item_type,
            tg_id=tg_id,
        ))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=(
                f"admin orders failed: {e}"
            ),
        ) from e



@router.get("/order/legacy/{order_id}", response_model=LegacyOrderOut)
async def admin_legacy_get_order(
    order_id: int,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> LegacyOrderOut:
    """Read order via orders_service legacy path."""
    try:
        order = await legacy_get_order(db, order_id=int(order_id))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"legacy order read failed: {e}",
        ) from e
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return _legacy_order_to_out(order)


@router.get(
    "/orders/user/legacy/{tg_id}",
    response_model=list[LegacyOrderOut],
)
async def admin_legacy_list_user_orders(
    tg_id: int,
    limit: int = Query(default=50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[LegacyOrderOut]:
    """List user orders via orders_service legacy path."""
    try:
        rows = await legacy_list_user_orders(
            db,
            tg_id=int(tg_id),
            limit=int(limit),
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"legacy user orders failed: {e}",
        ) from e
    return [_legacy_order_to_out(order) for order in rows]


@router.post("/items/set-price")
async def admin_set_item_price(
    payload: SetPriceIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
    _idk: str = Depends(require_idempotency_key_header_only),
) -> dict[str, Any]:
    """Обновить цену/валюты оплаты товара (по code)."""
    try:
        return cast(dict[str, Any], await admin_set_price(
            db,
            code=payload.code,
            price_efhc=payload.price_efhc,
            price_ton=payload.price_ton,
            price_usdt=payload.price_usdt,
            pay_currencies=payload.pay_currencies,
            is_active=payload.is_active,
        ))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=(
                f"admin set price failed: {e}"
            ),
        ) from e


async def _list_hub_links_impl(
    active_only: bool,
    db: AsyncSession,
    _auth: Any,
) -> list[HubLinkAdminOut]:
    rows = await admin_list_hub_links(db, active_only=active_only)
    return [HubLinkAdminOut.model_validate(row) for row in rows]


@hub_router.get("/links", response_model=list[HubLinkAdminOut])
async def admin_hub_links_list(
    active_only: bool = False,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[HubLinkAdminOut]:
    return await _list_hub_links_impl(active_only, db, _auth)




async def _create_hub_link_impl(
    payload: HubLinkAdminCreateIn,
    db: AsyncSession,
) -> HubLinkAdminOut:
    try:
        row = await admin_create_hub_link(
            db,
            code=payload.code,
            title=payload.title,
            subtitle=payload.subtitle,
            url=payload.url,
            target_kind=payload.target_kind,
            open_mode=payload.open_mode,
            sort_order=payload.sort_order,
            is_active=payload.is_active,
            icon_key=payload.icon_key,
        )
        await db.commit()
        return HubLinkAdminOut.model_validate(row)
    except HubLinkAdminError as exc:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"admin hub create failed: {exc}",
        ) from exc


@hub_router.post("/links", response_model=HubLinkAdminOut)
async def admin_hub_link_create(
    payload: HubLinkAdminCreateIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> HubLinkAdminOut:
    return await _create_hub_link_impl(payload, db)




async def _update_hub_link_impl(
    link_id: int,
    payload: HubLinkAdminUpdateIn,
    db: AsyncSession,
) -> HubLinkAdminOut:
    try:
        row = await admin_update_hub_link(
            db,
            link_id=link_id,
            title=payload.title,
            subtitle=payload.subtitle,
            url=payload.url,
            target_kind=payload.target_kind,
            open_mode=payload.open_mode,
            sort_order=payload.sort_order,
            is_active=payload.is_active,
            icon_key=payload.icon_key,
        )
        await db.commit()
        return HubLinkAdminOut.model_validate(row)
    except HubLinkAdminError as exc:
        await db.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"admin hub update failed: {exc}",
        ) from exc


@hub_router.put("/links/{link_id}", response_model=HubLinkAdminOut)
async def admin_hub_link_update(
    link_id: int,
    payload: HubLinkAdminUpdateIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> HubLinkAdminOut:
    return await _update_hub_link_impl(link_id, payload, db)




async def _toggle_hub_link_impl(
    link_id: int,
    payload: HubLinkAdminToggleIn,
    db: AsyncSession,
) -> HubLinkAdminOut:
    try:
        row = await admin_toggle_hub_link(
            db,
            link_id=link_id,
            is_active=payload.is_active,
        )
        await db.commit()
        return HubLinkAdminOut.model_validate(row)
    except HubLinkAdminError as exc:
        await db.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"admin hub toggle failed: {exc}",
        ) from exc


@hub_router.post(
    "/links/{link_id}/toggle",
    response_model=HubLinkAdminOut,
)
async def admin_hub_link_toggle(
    link_id: int,
    payload: HubLinkAdminToggleIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> HubLinkAdminOut:
    return await _toggle_hub_link_impl(link_id, payload, db)




async def _reorder_hub_links_impl(
    payload: HubLinkAdminReorderIn,
    db: AsyncSession,
) -> list[HubLinkAdminOut]:
    try:
        row_items = [item.model_dump() for item in payload.items]
        rows = await admin_reorder_hub_links(db, items=row_items)
        await db.commit()
        return [HubLinkAdminOut.model_validate(row) for row in rows]
    except HubLinkAdminError as exc:
        await db.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"admin hub reorder failed: {exc}",
        ) from exc


@hub_router.post("/links/reorder", response_model=list[HubLinkAdminOut])
async def admin_hub_links_reorder(
    payload: HubLinkAdminReorderIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[HubLinkAdminOut]:
    return await _reorder_hub_links_impl(payload, db)




router.include_router(hub_router)
