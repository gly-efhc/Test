# backend/app/routes/ads_routes.py
# =====================================================================
# EFHC Bot — Роуты рекламы с бонусным начислением
# ---------------------------------------------------------------------
# Что делает модуль:
# • GET  /ads/slot — выдаёт слот рекламы для пользователя.
#   - provider=builtin_timer → подписанный токен для фронта.
#   - provider=adsgram → конфиг/placement для мини-аппа Adsgram.
#   Выбор: ?provider=..., иначе берём первый включённый.
#
# • POST /ads/callback/{provider} — приём колбэков провайдера:
#   - verify через integrations/ads_providers.py
#   - начисление ИДЕМПОТЕНТНО через
#     tasks_service.confirm_ad_view_and_credit(...)
#
# Канон/инварианты:
# • Денежные операции — только через tasks_service (bonus_balance).
# • Идемпотентность: provider_ref → idempotency_key.
# • Суммы: Decimal с 8 знаками, округление вниз.
# • P2P нет; только «пользователь ↔ банк».
#
# Идентификация пользователя:
# • server-side Bearer session через общий auth dependency;
# • raw Telegram initData не является fallback для business route.
# =====================================================================

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8, get_db, make_etag
from app.identity.financial_owner import (
    resolve_financial_read_owner,
)
from app.identity.nonfinancial_read_dependency import (
    get_nonfinancial_read_owner,
)
from app.identity.nonfinancial_owner import NonFinancialReadOwner
from app.integrations.ads_providers import (
    get_verified_event,
    issue_builtin_timer_token,
)
from app.models.tasks_models import Task
from app.services.tasks_service import (
    confirm_ad_view_and_credit,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Request,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# ---------------------------------------------------------------------
# Конфиги провайдеров (из env)
# ---------------------------------------------------------------------

_ENABLED_RAW = getattr(
    settings,
    "ADS_ENABLED_PROVIDERS",
    "adsgram,builtin_timer",
)
ENABLED = [x.strip() for x in str(_ENABLED_RAW).split(",") if x.strip()]
DEFAULT_PROVIDER = ENABLED[0] if ENABLED else "builtin_timer"

BUILTIN_TTL_SEC = int(
    getattr(settings, "ADS_BUILTIN_TOKEN_TTL_SEC", 600) or 600
)
BUILTIN_MIN_VIEW_SEC = int(
    getattr(settings, "ADS_BUILTIN_MIN_VIEW_SEC", 20) or 20
)
ADSGRAM_PLACEMENT_ID = getattr(settings, "ADSGRAM_PLACEMENT_ID", None)

Q8 = Decimal("0.00000001")

HDR_TG_INIT = "X-Telegram-Init-Data"


class AdSlotOut(BaseModel):
    provider: str = Field(..., description="adsgram | builtin_timer")
    task_code: str
    global_id: str
    bonus_efhc: str

    # builtin_timer
    token: str | None = Field(
        None,
        description="Подписанный токен (builtin_timer)",
    )
    expires_at: str | None = Field(
        None,
        description="ISO-время истечения токена (builtin_timer)",
    )
    min_view_sec: int | None = Field(
        None,
        description="Минимальное время просмотра (builtin_timer)",
    )

    # adsgram
    placement_id: str | None = Field(
        None,
        description="ID плейсмента Adsgram (если задан)",
    )


class AdCallbackResultOut(BaseModel):
    ok: bool
    provider: str
    task_code: str
    provider_ref: str
    bonus_efhc: str
    replayed: bool = False


router = APIRouter(prefix="/ads", tags=["ads"])


@router.get(
    "/slot",
    response_model=AdSlotOut,
    summary="Выдать слот рекламы (token/config) для пользователя",
)
async def get_ad_slot(
    request: Request,
    response: Response,
    task_code: str,
    provider: str | None = None,
    owner: NonFinancialReadOwner = Depends(
        get_nonfinancial_read_owner
    ),
    db: AsyncSession = Depends(get_db),
):
    """Выдаёт слот рекламы: builtin_timer или adsgram."""

    _ = request

    provider_tg_id = owner.provider_tg_id
    if provider_tg_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="telegram_provider_required",
        )

    prov = (provider or DEFAULT_PROVIDER).strip().lower()
    if prov not in ENABLED:
        raise HTTPException(
            status_code=400,
            detail=f"Провайдер '{prov}' не активен",
        )

    stmt = (
        select(
            Task.code,
            Task.bonus_efhc,
            Task.active,
            Task.type,
        )
        .where(Task.code == task_code)
        .limit(1)
    )
    row = (await db.execute(stmt)).first()
    if not row:
        raise HTTPException(
            status_code=404,
            detail="Задание не найдено",
        )
    if not bool(row[2]):
        raise HTTPException(status_code=400, detail="Задание отключено")
    if str(row[3] or "") != "watch_ad":
        raise HTTPException(
            status_code=400,
            detail="Неверный тип задания (ожидается watch_ad)",
        )

    bonus_amount = Decimal(str(row[1])).quantize(
        Q8,
        rounding=ROUND_DOWN,
    )

    if prov == "builtin_timer":
        token = issue_builtin_timer_token(
            tg_id=int(provider_tg_id),
            task_code=task_code,
            bonus_efhc=bonus_amount,
            ttl_sec=BUILTIN_TTL_SEC,
        )
        exp_iso = (
            datetime.now(tz=UTC) + timedelta(seconds=BUILTIN_TTL_SEC)
        ).isoformat()
        et = make_etag(
            f"slot:{owner.global_id}:{task_code}:{prov}:"
            f"{bonus_amount}:{exp_iso}"
        )
        if request.headers.get("If-None-Match") == et:
            response.status_code = status.HTTP_304_NOT_MODIFIED
            response.headers["ETag"] = et
            return
        response.headers["ETag"] = et
        return AdSlotOut(
            provider="builtin_timer",
            task_code=task_code,
            global_id=f"{int(owner.global_id):010d}",
            bonus_efhc=str(d8(bonus_amount)),
            token=token,
            expires_at=exp_iso,
            min_view_sec=BUILTIN_MIN_VIEW_SEC,
            placement_id=None,
        )

    placement_id = ADSGRAM_PLACEMENT_ID
    placement_key = placement_id or ""
    et = make_etag(
        f"slot:{owner.global_id}:{task_code}:{prov}:"
        f"{bonus_amount}:{placement_key}"
    )
    if request.headers.get("If-None-Match") == et:
        response.status_code = status.HTTP_304_NOT_MODIFIED
        response.headers["ETag"] = et
        return
    response.headers["ETag"] = et
    return AdSlotOut(
        provider="adsgram",
        task_code=task_code,
        global_id=f"{int(owner.global_id):010d}",
        bonus_efhc=str(d8(bonus_amount)),
        placement_id=(placement_id or None),
        token=None,
        expires_at=None,
        min_view_sec=None,
    )


@router.post(
    "/callback/{provider}",
    response_model=AdCallbackResultOut,
    summary="Колбэк провайдера рекламы (идемпотентное начисление)",
)
async def ads_callback(
    provider: str,
    request: Request,
    response: Response,
    body: dict[str, Any],
    db: AsyncSession = Depends(get_db),
    idempotency_key_hdr: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
):
    """Verify у провайдера → начисление через tasks_service."""

    client_ip = request.client.host if request.client else None

    try:
        evt = await get_verified_event(
            provider,
            payload=body or {},
            headers=dict(request.headers),
            client_ip=client_ip,
        )
    except ValueError as e:
        reason = str(e)
        forbidden = {
            "provider_disabled",
            "ip_not_allowed",
            "missing_token",
            "token_expired",
            "signature_mismatch",
            "token_signature_mismatch",
            "missing_signature",
            "hash_mismatch",
            "invalid_tg_id",
        }
        code = 403 if reason in forbidden else 400
        raise HTTPException(status_code=code, detail=reason) from e
    except Exception as e:
        logger.error(
            "ads.callback verify failed prov=%s",
            provider,
            exc_info=True,
        )
        raise HTTPException(
            status_code=500,
            detail="internal_error",
        ) from e

    idk = evt.idempotency_key
    if idempotency_key_hdr and idempotency_key_hdr.strip():
        hdr = idempotency_key_hdr.strip()
        idk = f"{evt.idempotency_key}|hdr:{hdr}"

    try:
        global_id = await resolve_telegram_subject_global_id(
            db, int(evt.tg_id)
        )
        if global_id is None:
            raise FinancialReadOwnerError(
                "Account owner mapping не найден"
            )
        result = await confirm_ad_view_and_credit(
            db,
            global_id=int(global_id.value),
            task_code=str(evt.task_code),
            provider=str(evt.provider),
            provider_ref=str(evt.provider_ref),
            bonus_efhc=evt.bonus_efhc,
            idempotency_key=idk,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "ads.callback credit failed prov=%s task=%s",
            provider,
            evt.task_code,
            exc_info=True,
        )
        raise HTTPException(
            status_code=500,
            detail="credit_failed",
        ) from e

    replayed = bool(result.get("replayed", False))
    et = make_etag(
        f"ads_cb:{evt.provider}:{evt.provider_ref}:"
        f"{evt.tg_id}:{evt.task_code}:{replayed}"
    )
    response.headers["ETag"] = et

    return AdCallbackResultOut(
        ok=True,
        provider=str(evt.provider),
        task_code=str(evt.task_code),
        provider_ref=str(evt.provider_ref),
        bonus_efhc=str(
            d8(
                result.get(
                    "bonus_efhc",
                    result.get(
                        "bonus_efhc",
                        evt.bonus_efhc,
                    ),
                )
            )
        ),
        replayed=replayed,
    )
