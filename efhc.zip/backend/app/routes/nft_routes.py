# -*- coding: utf-8 -*-
# backend/app/routes/nft_routes.py
# =====================================================================
# Read-only эндпоинты NFT/VIP: проверка наличия NFT у кошелька.
# Никакой выдачи/доставки NFT здесь нет.
# =====================================================================

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from app.core.config_core import get_settings
from app.integrations.nft_api import has_nft_in_collection

settings = get_settings()
router = APIRouter(prefix="/nft", tags=["nft"])


@router.get("/has_vip")
async def has_vip_nft(
    wallet: str = Query(..., description="TON wallet address"),
) -> dict:
    collection = getattr(settings, "VIP_NFT_COLLECTION", None)
    if not collection:
        raise HTTPException(
            status_code=500,
            detail="VIP_NFT_COLLECTION not configured",
        )
    ok = await has_nft_in_collection(
        wallet_address=wallet,
        collection_address=collection,
    )
    return {
        "wallet": wallet,
        "collection": collection,
        "has_nft": bool(ok),
    }
