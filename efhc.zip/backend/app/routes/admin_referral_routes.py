# backend/app/routes/admin_referral_routes.py
# ======================================================================
# Admin: referrals
# ======================================================================

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from app.core.logging_core import get_logger
from app.deps import (
    d8,
    decode_cursor,
    encode_cursor,
    etag,
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Response,
    status,
)
from pydantic import BaseModel, Field, conint, constr, field_validator
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(
    prefix="/api/admin/referrals",
    tags=["admin:referrals"],
)

# Soft import: роутер не должен падать, если сервис ещё не готов.
try:
    from app.services.referral_service import (
        admin_manual_bonus,
        admin_reassign_inviter,
        admin_summary,
    )

    _REF_SVC_AVAILABLE = True
except Exception:
    admin_summary = None
    admin_manual_bonus = None
    admin_reassign_inviter = None
    _REF_SVC_AVAILABLE = False


class SummaryItem(BaseModel):
    inviter_tg_id: int = Field(..., description="Инвайтер")
    active_count: int = Field(..., ge=0, description="Активные")
    inactive_count: int = Field(..., ge=0, description="Неактивные")
    total_bonus_efhc: constr(strip_whitespace=True) = Field(
        ..., description="Сумма бонусов d8"
    )
    last_invited_at: datetime | None = Field(
        None, description="Последнее приглашение"
    )


class SummaryResponse(BaseModel):
    items: list[SummaryItem]
    next_cursor: str | None = None


class ManualBonusRequest(BaseModel):
    tg_id: int = Field(..., description="Получатель")
    amount: constr(strip_whitespace=True) = Field(
        ...,
        description="EFHC d8",
    )
    reason: str | None = Field(
        "referral_manual_bonus",
        description="Причина",
    )

    @field_validator("amount")
    def _valid_amount(cls, v: str) -> str:
        amt = d8(v)
        if amt <= Decimal("0"):
            raise ValueError("Сумма должна быть > 0")
        return str(amt)


class ReassignRequest(BaseModel):
    invitee_tg_id: int = Field(..., description="Кому")
    new_inviter_tg_id: int = Field(..., description="Новый инвайтер")
    note: str | None = Field(None, description="Пометка")


@router.get("/summary", response_model=SummaryResponse)
async def get_summary(
    response: Response,
    limit: conint(ge=1, le=200) = 50,
    cursor: str | None = None,
    _admin: Any = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> SummaryResponse:
    """Агрегированная сводка по инвайтерам (cursor + ETag)."""
    if not _REF_SVC_AVAILABLE or admin_summary is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="referral_service недоступен",
        )

    after: dict[str, Any] = {}
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            )

    try:
        data: dict[str, Any] = await admin_summary(
            db,
            limit=int(limit),
            after=after,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_summary failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка сводки",
        )

    items_in: list[dict[str, Any]] = list(data.get("items") or [])
    items: list[SummaryItem] = []
    for it in items_in:
        items.append(
            SummaryItem(
                inviter_tg_id=int(it["inviter_tg_id"]),
                active_count=int(it.get("active_count", 0)),
                inactive_count=int(it.get("inactive_count", 0)),
                total_bonus_efhc=str(
                    d8(it.get("total_bonus_efhc", "0"))
                ),
                last_invited_at=it.get("last_invited_at"),
            )
        )

    next_after: dict[str, Any] | None = data.get("next_after")
    next_cursor: str | None = None
    if next_after:
        next_cursor = encode_cursor(next_after)

    body = SummaryResponse(items=items, next_cursor=next_cursor)
    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning("ETag compute failed", exc_info=True)

    return body


@router.post("/manual-bonus", status_code=status.HTTP_204_NO_CONTENT)
async def post_manual_bonus(
    payload: ManualBonusRequest,
    idempotency_key: str = Depends(require_idempotency_key_header_only),
    _admin: Any = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    """Начислить бонус пользователю (денежная операция)."""
    key = (idempotency_key or "").strip()
    if not key:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key обязателен",
        )

    if not _REF_SVC_AVAILABLE or admin_manual_bonus is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="referral_service недоступен",
        )

    try:
        amt = d8(payload.amount)
        await _resolve_user_pk_by_tg(db, int(payload.tg_id))
        await admin_manual_bonus(
            db,
            int(payload.tg_id),
            amount=amt,
            reason=payload.reason or "referral_manual_bonus",
            idempotency_key=key,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_manual_bonus failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка начисления",
        )


@router.post("/reassign", status_code=status.HTTP_204_NO_CONTENT)
async def post_reassign_inviter(
    payload: ReassignRequest,
    idempotency_key: str = Depends(require_idempotency_key_header_only),
    _admin: Any = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    """Переназначить пригласившего."""
    if int(payload.invitee_tg_id) == int(payload.new_inviter_tg_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Self-invite запрещён",
        )

    if not _REF_SVC_AVAILABLE or admin_reassign_inviter is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="referral_service недоступен",
        )

    key = (idempotency_key or "").strip() or None

    try:
        await _resolve_user_pk_by_tg(db, int(payload.invitee_tg_id))
        await _resolve_user_pk_by_tg(db, int(payload.new_inviter_tg_id))
        await admin_reassign_inviter(
            db,
            invitee_tg_id=int(payload.invitee_tg_id),
            new_inviter_tg_id=int(payload.new_inviter_tg_id),
            note=payload.note or None,
            idempotency_key=key,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_reassign_inviter failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка переназначения",
        )


async def _resolve_user_pk_by_tg(db: AsyncSession, tg_id: int) -> int:
    """Вернуть users.id для tg_id."""
    from app.models.user_models import User
    from sqlalchemy import select

    stmt = (
        select(User.id)
        .where(User.tg_id == int(tg_id))
        .limit(1)
    )
    row = (await db.execute(stmt)).first()
    if not row:
        raise HTTPException(
            status_code=404,
            detail="Пользователь не найден",
        )
    return int(row[0])
