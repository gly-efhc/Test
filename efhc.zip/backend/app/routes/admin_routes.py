# backend/app/routes/admin_routes.py
# ======================================================================
# Назначение:
# Админ-API EFHC Bot: корректировки балансов «банк↔пользователь»,
# ручная реконсиляция входящих TON, сводные отчёты, тех.диагностика.
#
# Канон:
# - Любые денежные операции идут только через transactions_service.
# - Денежные POST требуют Idempotency-Key (строгая идемпотентность).
# - Пользователи не могут уходить в минус (правило сервисов/БД).
# - Банк может быть в минусе (фиксируется в логах).
# - Доступ: require_admin.
#
# Запреты:
# - Никаких прямых SQL для денег из роутов; только сервисные функции.
# - Никаких P2P user→user; корректировки только «пользователь↔банк».
# ======================================================================

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from app.core.logging_core import get_logger
from app.deps import (
    AuthContext,
    d8,
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from app.services.admin.admin_bank_service import (
    AdminBankService,
    MintBurnRequest,
)
from app.services.transactions_service import (
    credit_user_bonus_from_bank_by_tg_id,
    credit_user_main_from_bank_by_tg_id,
    debit_user_bonus_to_bank_by_tg_id,
    debit_user_main_to_bank_by_tg_id,
)
from app.services.watcher_service import (
    process_incoming_payments,
    reconcile_last_hours,
)
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


class AdminTransferIn(BaseModel):
    tg_id: int = Field(
        ...,
        description="TG ID пользователя (каноничный идентификатор)",
    )
    direction: str = Field(
        ...,
        description="Направление перевода (credit|debit)",
        pattern=r"^(credit|debit)$",
    )
    balance: str = Field(
        "main",
        description="Баланс (main|bonus)",
        pattern=r"^(main|bonus)$",
    )
    amount: Decimal = Field(..., description="Сумма EFHC (>= 0)")
    reason: str | None = Field(
        None,
        description="Причина/комментарий (логируется)",
        max_length=255,
    )


class AdminTransferOut(BaseModel):
    ok: bool
    tg_id: int
    balance: str
    direction: str
    amount: str
    bank_balance_after: str | None = None
    user_main_after: str | None = None
    user_bonus_after: str | None = None
    idempotency_key: str


class TonReconcileIn(BaseModel):
    """Режимы реконсиляции входящих TON."""

    since_utime: int | None = None
    last_hours: int | None = 6
    limit: int = 1000


class TonReconcileOut(BaseModel):
    ok: bool
    processed: int
    parsed: int
    credited: int
    duplicates: int
    errors: int
    note: str | None = None


class ReportsOverviewOut(BaseModel):
    ok: bool
    ts: datetime
    counters: dict[str, int]
    facts: dict[str, str] = Field(default_factory=dict)
    notes: str | None = None


@router.post(
    "/transfer",
    response_model=AdminTransferOut,
    summary=(
        "Корректировка «банк↔пользователь» "
        "(только через банк, read-through идемпотентность)"
    ),
)
async def admin_transfer(
    payload: AdminTransferIn,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> AdminTransferOut:
    if payload.amount is None or Decimal(payload.amount) < Decimal("0"):
        raise HTTPException(
            status_code=400,
            detail="Сумма должна быть ≥ 0.",
        )

    tg_id = int(payload.tg_id)
    amount_q8 = d8(payload.amount)

    try:
        if payload.direction == "credit":
            if payload.balance == "main":
                res = await credit_user_main_from_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_CORRECTION_MAIN",
                    idempotency_key=idempotency_key,
                )
            else:
                res = await credit_user_bonus_from_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_CORRECTION_BONUS",
                    idempotency_key=idempotency_key,
                )
        else:
            if payload.balance == "main":
                res = await debit_user_main_to_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_DEBIT_MAIN_TO_BANK",
                    idempotency_key=idempotency_key,
                )
            else:
                res = await debit_user_bonus_to_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=(
                        payload.reason or "ADMIN_DEBIT_BONUS_TO_BANK"
                    ),
                    idempotency_key=idempotency_key,
                )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("admin_transfer failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Не удалось выполнить корректировку.",
        ) from exc

    try:
        q = text(
            "\n".join(
                [
                    "select main_balance, bonus_balance",
                    "from efhc_core.users",
                    "where tg_id = :tg",
                ]
            )
        )
        row = await db.execute(q, {"tg": tg_id})
        mb, bb = row.fetchone() or (Decimal("0"), Decimal("0"))
    except Exception:
        mb, bb = Decimal("0"), Decimal("0")

    bank_after = None
    if isinstance(res, dict):
        bank_after = res.get("bank_balance_after")

    return AdminTransferOut(
        ok=True,
        tg_id=tg_id,
        balance=payload.balance,
        direction=payload.direction,
        amount=str(d8(payload.amount)),
        bank_balance_after=(
            str(bank_after) if bank_after is not None else None
        ),
        user_main_after=str(d8(mb)),
        user_bonus_after=str(d8(bb)),
        idempotency_key=idempotency_key,
    )


@router.get(
    "/bank/balance",
    summary="Баланс банка BANK_EFHC (efhc_core.bank_balance)",
)
async def admin_bank_balance(
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> dict[str, Any]:
    bal = await AdminBankService.get_bank_balance(db)
    return {
        "bank_name": str(bal.tg_id),
        "efhc_main": str(bal.balance),
    }


@router.post(
    "/bank/mint",
    summary="Эмиссия EFHC в банк (Idempotency-Key обязателен)",
)
async def admin_bank_mint(
    payload: MintBurnRequest,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> dict[str, Any]:
    payload.idempotency_key = idempotency_key
    res = await AdminBankService.mint_efhc(
        db,
        req=payload,
        admin_tg_id=int(_auth.tg_id),
    )
    return {
        "ok": True,
        "bank_balance_after": str(res.efhc_balance),
    }


@router.post(
    "/bank/burn",
    summary="Сжигание EFHC в банке (Idempotency-Key обязателен)",
)
async def admin_bank_burn(
    payload: MintBurnRequest,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> dict[str, Any]:
    payload.idempotency_key = idempotency_key
    res = await AdminBankService.burn_efhc(
        db,
        req=payload,
        admin_tg_id=int(_auth.tg_id),
    )
    return {
        "ok": True,
        "bank_balance_after": str(res.efhc_balance),
    }


@router.post(
    "/ton/reconcile",
    response_model=TonReconcileOut,
    summary=(
        "Реконсиляция входящих TON "
        "(since_utime/last_hours) + limit"
    ),
)
async def ton_reconcile(
    payload: TonReconcileIn,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> TonReconcileOut:
    if payload.since_utime is None and payload.last_hours is None:
        raise HTTPException(
            status_code=400,
            detail="Укажите since_utime или last_hours.",
        )

    try:
        if payload.since_utime is not None:
            stats = await process_incoming_payments(
                db=db,
                limit=int(payload.limit),
                since_utime=int(payload.since_utime),
            )
        else:
            if payload.last_hours is None:
                raise HTTPException(
                    status_code=422,
                    detail=(
                        "last_hours is required when "
                        "since_utime is null."
                    ),
                )
            stats = await reconcile_last_hours(
                db=db,
                hours=int(payload.last_hours),
            )
    except Exception as exc:
        logger.exception("ton_reconcile failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Ошибка реконсиляции входящих TON.",
        ) from exc

    return TonReconcileOut(
        ok=True,
        processed=int(stats.get("processed", 0)),
        parsed=int(stats.get("parsed", 0)),
        credited=int(stats.get("credited", 0)),
        duplicates=int(stats.get("duplicates", 0)),
        errors=int(stats.get("errors", 0)),
        note=stats.get("note"),
    )


@router.get(
    "/reports/overview",
    response_model=ReportsOverviewOut,
    summary="Быстрый обзор ключевых счётчиков",
)
async def reports_overview(
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> ReportsOverviewOut:
    counters: dict[str, int] = {
        "ton_inbox_total": 0,
        "ton_inbox_errors": 0,
        "efhc_transfers_total": 0,
        "efhc_transfers_deficit": 0,
        "users_total": 0,
    }
    facts: dict[str, str] = {
        "panels_total_bought": "0",
        "panels_total_active": "0",
        "panels_total_archived": "0",
        "panels_total_paid_efhc": "0.00000000",
        "panels_total_paid_main_efhc": "0.00000000",
        "panels_total_paid_bonus_efhc": "0.00000000",
        "users_total_generated_kwh": "0.00000000",
        "users_total_exchanged_kwh": "0.00000000",
        "users_total_main_efhc": "0.00000000",
        "users_total_bonus_efhc": "0.00000000",
    }
    notes: str | None = None

    try:
        row = await db.execute(
            text("select count(*) from efhc_core.ton_inbox_logs")
        )
        counters["ton_inbox_total"] = int(row.scalar() or 0)

        row = await db.execute(
            text(
                "\n".join(
                    [
                        "select count(*)",
                        "from efhc_core.ton_inbox_logs",
                        "where status like 'error_%'",
                    ]
                )
            )
        )
        counters["ton_inbox_errors"] = int(row.scalar() or 0)

        row = await db.execute(
            text("select count(*) from efhc_core.efhc_transfers_log")
        )
        counters["efhc_transfers_total"] = int(row.scalar() or 0)

        q = "\n".join(
            [
                "select count(*)",
                "from efhc_core.efhc_transfers_log",
                "where meta like '%processed_with_deficit%'",
            ]
        )
        row = await db.execute(text(q))
        counters["efhc_transfers_deficit"] = int(row.scalar() or 0)

        row = await db.execute(
            text("select count(*) from efhc_core.users")
        )
        counters["users_total"] = int(row.scalar() or 0)

        panels_q = text(
            "\n".join(
                [
                    "select",
                    "  coalesce(sum(case when is_active",
                    " then 1 else 0 end), 0)",
                    "    as active_cnt,",
                    "  coalesce(sum(case when is_active",
                    " then 0 else 1 end), 0)",
                    "    as archived_cnt,",
                    "  count(*) as total_cnt",
                    "from efhc_core.panels",
                ]
            )
        )
        panels_row = (await db.execute(panels_q)).fetchone()
        if panels_row:
            facts["panels_total_bought"] = str(
                int(panels_row.total_cnt or 0)
            )
            facts["panels_total_active"] = str(
                int(panels_row.active_cnt or 0)
            )
            facts["panels_total_archived"] = str(
                int(panels_row.archived_cnt or 0)
            )

        purchase_q = text(
            "\n".join(
                [
                    "select",
                    "  coalesce(sum(amount), 0)::numeric",
                    "    as total_paid,",
                    "  coalesce(sum(case when balance_type = 'main'",
                    " then amount else 0 end), 0)::numeric",
                    "    as total_paid_main,",
                    "  coalesce(sum(case when balance_type = 'bonus'",
                    " then amount else 0 end), 0)::numeric",
                    "    as total_paid_bonus",
                    "from efhc_core.efhc_transfers_log",
                    "where reason in (",
                    "  'panel_purchase', 'panel_activation'",
                    ")",
                    "  and direction = 'debit'",
                ]
            )
        )
        purchase_row = (await db.execute(purchase_q)).fetchone()
        if purchase_row:
            facts["panels_total_paid_efhc"] = str(
                d8(purchase_row.total_paid or 0)
            )
            facts["panels_total_paid_main_efhc"] = str(
                d8(purchase_row.total_paid_main or 0)
            )
            facts["panels_total_paid_bonus_efhc"] = str(
                d8(purchase_row.total_paid_bonus or 0)
            )

        users_q = text(
            "\n".join(
                [
                    "select",
                    "  coalesce(sum(main_balance), 0)::numeric",
                    "    as total_main,",
                    "  coalesce(sum(bonus_balance), 0)::numeric",
                    "    as total_bonus,",
                    "  coalesce(sum(total_generated_kwh), 0)::numeric",
                    "    as total_generated,",
                    "  coalesce(sum(exchanged_kwh_total), 0)::numeric",
                    "    as total_exchanged",
                    "from efhc_core.users",
                ]
            )
        )
        users_row = (await db.execute(users_q)).fetchone()
        if users_row:
            facts["users_total_generated_kwh"] = str(
                d8(users_row.total_generated or 0)
            )
            facts["users_total_exchanged_kwh"] = str(
                d8(users_row.total_exchanged or 0)
            )
            facts["users_total_main_efhc"] = str(
                d8(users_row.total_main or 0)
            )
            facts["users_total_bonus_efhc"] = str(
                d8(users_row.total_bonus or 0)
            )

    except Exception as exc:
        logger.warning("reports_overview partial: %s", exc)
        notes = (
            "Таблицы ещё не инициализированы или "
            "миграции не применены. "
            "Проверьте alembic."
        )

    return ReportsOverviewOut(
        ok=True,
        ts=datetime.now(UTC),
        counters=counters,
        facts=facts,
        notes=notes,
    )


