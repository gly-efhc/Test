# backend/app/routes/admin_routes.py
# ======================================================================
# Назначение:
# Админ-API EFHC Bot: корректировки балансов «банк↔пользователь»,
# ручная реконсиляция входящих TON, сводные отчёты, тех.диагностика.
#
# Канон:
# - Любые денежные операции идут только через transactions_service.
# - Денежные POST требуют Idempotency-Key (строгая идемпотентность).
# - Пользователи не могут уходить в минус (правило сервисов/БД).
# - Банк может быть в минусе (фиксируется в логах).
# - Доступ: require_admin.
#
# Запреты:
# - Никаких прямых SQL для денег из роутов; только сервисные функции.
# - Никаких P2P user→user; корректировки только «пользователь↔банк».
# ======================================================================

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from app.core.logging_core import get_logger
from app.deps import (
    AuthContext,
    d8,
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from app.models import User
from app.services.admin.admin_bank_service import (
    AdminBankService,
    MintBurnRequest,
)
from app.services.admin.admin_rbac import RBAC
from app.services.efhc_deposits_service import process_efhc_deposit
from app.services.reconcile_diagnostics_service import (
    summarize_reconcile_diagnostics,
)
from app.services.transactions_service import (
    credit_user_bonus_from_bank,
    credit_user_from_bank,
    debit_user_bonus_to_bank,
    debit_user_to_bank,
)
from app.services.watcher_service import (
    process_incoming_payments,
    reconcile_last_hours,
    reprocess_single_tx,
)
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


class AdminTransferIn(BaseModel):
    global_id: int | None = Field(
        None,
        ge=1,
        le=9_999_999_999,
        description="Канонический global_id пользователя",
    )
    direction: str = Field(
        ...,
        description="Направление перевода (credit|debit)",
        pattern=r"^(credit|debit)$",
    )
    balance: str = Field(
        "main",
        description="Баланс (main|bonus)",
        pattern=r"^(main|bonus)$",
    )
    amount: Decimal = Field(..., description="Сумма EFHC (>= 0)")
    reason: str | None = Field(
        None,
        description="Причина/комментарий (логируется)",
        max_length=255,
    )


class AdminTransferOut(BaseModel):
    ok: bool
    global_id: str
    balance: str
    direction: str
    amount: str
    bank_balance_after: str | None = None
    user__main__after: str | None = None
    user_bonus_after: str | None = None
    idempotency_key: str


class TonReconcileIn(BaseModel):
    """Режимы реконсиляции входящих TON."""

    since_utime: int | None = None
    last_hours: int | None = 6
    limit: int = 1000


class TonReconcileOut(BaseModel):
    ok: bool
    processed: int
    parsed: int
    credited: int
    duplicates: int
    errors: int
    diagnostics: dict[str, int] = Field(default_factory=dict)
    note: str | None = None


class ReportsOverviewOut(BaseModel):
    ok: bool
    ts: datetime
    counters: dict[str, int]
    facts: dict[str, str] = Field(default_factory=dict)
    notes: str | None = None


class AdminEfhcDepositIn(BaseModel):
    tx_hash: str = Field(..., min_length=1, max_length=255)
    amount: str = Field(..., min_length=1, max_length=64)
    memo: str | None = Field(None, max_length=255)
    from_address: str | None = Field(None, max_length=255)
    to_address: str | None = Field(None, max_length=255)
    raw_tx: dict[str, Any] | None = None


class AdminEfhcDepositOut(BaseModel):
    ok: bool
    detail: str | None = None
    error: str | None = None
    tx_hash: str
    amount: str
    global_id: int | None = None
    main_balance_after: str | None = None
    bonus_balance_after: str | None = None
    release_mode: str = "release_core_eligible"
    automation_mode: str = "operator_exception_path"
    release_gate_note: str = (
        "EFHC deposits use an automated primary path. "
        "This manual route is an operator exception path only."
    )


class AdminEfhcDepositsRuntimeOut(BaseModel):
    ok: bool
    release_mode: str = "release_core_eligible"
    automation_mode: str = "automated_with_operator_fallback"
    release_gate_note: str = (
        "EFHC deposits now use an automated primary path with "
        "operator fallback for exceptions and recovery."
    )
    primary_path: str = "watcher_automation"
    fallback_path: str = "operator_exception_and_replay"
    pending_manual_count: int = 0
    error_retry_count: int = 0
    error_user_count: int = 0
    auto_credited_count: int = 0
    pending_intents_count: int = 0


class AdminEfhcDepositReplayOut(BaseModel):
    ok: bool
    tx_hash: str
    replay_status: str
    release_mode: str = "release_core_eligible"
    automation_mode: str = "automated_with_operator_fallback"
    release_gate_note: str = (
        "Replay re-runs the automated watcher path. "
        "Operator remains a fallback only."
    )


@router.post(
    "/transfer",
    response_model=AdminTransferOut,
    summary=(
        "Корректировка «банк↔пользователь» "
        "(только через банк, read-through идемпотентность)"
    ),
)
async def admin_transfer(
    payload: AdminTransferIn,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> AdminTransferOut:
    if payload.amount is None or Decimal(payload.amount) < Decimal("0"):
        raise HTTPException(
            status_code=400,
            detail="Сумма должна быть ≥ 0.",
        )

    if (payload.global_id is None) == (payload.global_id is None):
        raise HTTPException(
            status_code=400,
            detail="Укажите ровно один owner selector",
        )
    global_id = (
        int(payload.global_id)
        if payload.global_id is not None
        else None
    )
    global_id = int(payload.global_id) if payload.global_id is not None else None
    amount_q8 = d8(payload.amount)

    try:
        if payload.direction == "credit":
            if payload.balance == "main":
                res = await credit_user_from_bank(
                    db=db,
                    global_id=global_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_CORRECTION_MAIN",
                    idempotency_key=idempotency_key,
                )
            else:
                res = await credit_user_bonus_from_bank(
                    db=db,
                    global_id=global_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_CORRECTION_BONUS",
                    idempotency_key=idempotency_key,
                )
        else:
            if payload.balance == "main":
                res = await debit_user_to_bank(
                    db=db,
                    global_id=global_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_DEBIT_MAIN_TO_BANK",
                    idempotency_key=idempotency_key,
                )
            else:
                res = await debit_user_bonus_to_bank(
                    db=db,
                    global_id=global_id,
                    amount=amount_q8,
                    reason=(
                        payload.reason or "ADMIN_DEBIT_BONUS_TO_BANK"
                    ),
                    idempotency_key=idempotency_key,
                )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("admin_transfer failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Не удалось выполнить корректировку.",
        ) from exc

    try:
        q = select(
            User.global_id,
            User.global_id,
            User.main_balance,
            User.bonus_balance,
        )
        if payload.global_id is not None:
            q = q.where(
                User.global_id == int(payload.global_id)
            )
        else:
            q = q.where(User.global_id == int(payload.global_id or 0))
        row = await db.execute(q)
        owner_row = row.fetchone()
        if owner_row:
            resolved_global_id = int(owner_row[0])
            resolved_global_id = (
                int(owner_row[1]) if owner_row[1] is not None else None
            )
            mb, bb = owner_row[2], owner_row[3]
        else:
            resolved_global_id = int(payload.global_id or 0)
            resolved_global_id = payload.global_id
            mb, bb = Decimal("0"), Decimal("0")
    except Exception:
        resolved_global_id = int(payload.global_id or 0)
        resolved_global_id = payload.global_id
        mb, bb = Decimal("0"), Decimal("0")

    bank_after = None
    if isinstance(res, dict):
        bank_after = res.get("bank_balance_after")
    else:
        bank_after = getattr(res, "bank__main__balance", None)

    return AdminTransferOut(
        ok=True,
        global_id=f"{int(resolved_global_id):010d}",
        balance=payload.balance,
        direction=payload.direction,
        amount=str(d8(payload.amount)),
        bank_balance_after=(
            str(bank_after) if bank_after is not None else None
        ),
        user__main__after=str(d8(mb)),
        user_bonus_after=str(d8(bb)),
        idempotency_key=idempotency_key,
    )


@router.get(
    "/bank/balance",
    summary="Баланс банка BANK_EFHC (efhc_core.bank_balance)",
)
async def admin_bank_balance(
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> dict[str, Any]:
    bal = await AdminBankService.get_bank_balance(db)
    return {
        "bank_name": str(bal.global_id),
        "efhc_main": str(bal.balance),
    }


@router.post(
    "/bank/mint",
    summary="Эмиссия EFHC в банк (Idempotency-Key обязателен)",
)
async def admin_bank_mint(
    payload: MintBurnRequest,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> dict[str, Any]:
    payload.idempotency_key = idempotency_key
    admin = await RBAC.resolve_admin(db, int(_auth.global_id))
    res = await AdminBankService.mint_efhc(
        db,
        req=payload,
        admin=admin,
    )
    await db.commit()
    return {
        "ok": True,
        "bank_balance_after": str(res.get("current_balance")),
        "idempotency_key": idempotency_key,
        "reused": bool(res.get("reused", False)),
    }


@router.post(
    "/bank/burn",
    summary="Сжигание EFHC в банке (Idempotency-Key обязателен)",
)
async def admin_bank_burn(
    payload: MintBurnRequest,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> dict[str, Any]:
    payload.idempotency_key = idempotency_key
    admin = await RBAC.resolve_admin(db, int(_auth.global_id))
    res = await AdminBankService.burn_efhc(
        db,
        req=payload,
        admin=admin,
    )
    await db.commit()
    return {
        "ok": True,
        "bank_balance_after": str(res.get("current_balance")),
        "idempotency_key": idempotency_key,
        "reused": bool(res.get("reused", False)),
    }


@router.post(
    "/ton/reconcile",
    response_model=TonReconcileOut,
    summary=(
        "Реконсиляция входящих TON (since_utime/last_hours) + limit"
    ),
)
async def ton_reconcile(
    payload: TonReconcileIn,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> TonReconcileOut:
    if payload.since_utime is None and payload.last_hours is None:
        raise HTTPException(
            status_code=400,
            detail="Укажите since_utime или last_hours.",
        )

    try:
        if payload.since_utime is not None:
            stats = await process_incoming_payments(
                db=db,
                limit=int(payload.limit),
                since_utime=int(payload.since_utime),
            )
        else:
            if payload.last_hours is None:
                raise HTTPException(
                    status_code=422,
                    detail=(
                        "last_hours is required when "
                        "since_utime is null."
                    ),
                )
            stats = await reconcile_last_hours(
                db=db,
                hours=int(payload.last_hours),
            )
    except Exception as exc:
        logger.exception("ton_reconcile failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Ошибка реконсиляции входящих TON.",
        ) from exc

    diagnostics = await summarize_reconcile_diagnostics(
        db,
        hours=int(payload.last_hours or 6),
    )
    return TonReconcileOut(
        ok=True,
        processed=int(stats.get("processed", 0)),
        parsed=int(stats.get("parsed", 0)),
        credited=int(stats.get("credited", 0)),
        duplicates=int(stats.get("duplicates", 0)),
        errors=int(stats.get("errors", 0)),
        diagnostics=diagnostics,
        note=stats.get("note"),
    )


@router.post(
    "/efhc-deposits/process",
    response_model=AdminEfhcDepositOut,
    summary="Ручная обработка внешнего EFHC депозита",
)
async def admin_process_efhc_deposit(
    payload: AdminEfhcDepositIn,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> AdminEfhcDepositOut:
    try:
        result = await process_efhc_deposit(
            db=db,
            tx_hash=payload.tx_hash,
            amount=payload.amount,
            memo=payload.memo,
            from_address=payload.from_address,
            to_address=payload.to_address,
            raw_tx=payload.raw_tx,
        )
        return AdminEfhcDepositOut(**result)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(
            "admin_process_efhc_deposit failed: %s",
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail="Не удалось обработать внешний депозит EFHC.",
        ) from exc


@router.get(
    "/efhc-deposits/runtime-summary",
    response_model=AdminEfhcDepositsRuntimeOut,
    summary="Runtime summary for EFHC deposits automation",
)
async def admin_efhc_deposits_runtime_summary(
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> AdminEfhcDepositsRuntimeOut:
    q_logs = text(
        """
        SELECT
          COALESCE(SUM(CASE WHEN status = 'pending_manual'
            THEN 1 ELSE 0 END), 0) AS pending_manual_count,
          COALESCE(SUM(CASE WHEN status = 'error_retry'
            THEN 1 ELSE 0 END), 0) AS error_retry_count,
          COALESCE(SUM(CASE WHEN status = 'error_user_not_found'
            THEN 1 ELSE 0 END), 0) AS error_user_count,
          COALESCE(SUM(CASE WHEN status = 'credited'
            THEN 1 ELSE 0 END), 0) AS auto_credited_count
        FROM efhc_core.ton_inbox_logs
        """
    )
    q_intents = text(
        """
        SELECT COALESCE(COUNT(*), 0) AS pending_intents_count
        FROM efhc_core.payment_intents
        WHERE purpose = 'deposit_efhc'
          AND status = 'PENDING'
        """
    )
    log_row_raw: Mapping[str, Any] = dict(
        (await db.execute(q_logs)).mappings().first() or {}
    )
    intent_row_raw: Mapping[str, Any] = dict(
        (await db.execute(q_intents)).mappings().first() or {}
    )
    log_row: Mapping[str, Any] = log_row_raw
    intent_row: Mapping[str, Any] = intent_row_raw
    return AdminEfhcDepositsRuntimeOut(
        ok=True,
        pending_manual_count=int(
            log_row.get("pending_manual_count", 0) or 0
        ),
        error_retry_count=int(log_row.get("error_retry_count", 0) or 0),
        error_user_count=int(log_row.get("error_user_count", 0) or 0),
        auto_credited_count=int(
            log_row.get("auto_credited_count", 0) or 0
        ),
        pending_intents_count=int(
            intent_row.get("pending_intents_count", 0) or 0
        ),
    )


@router.post(
    "/efhc-deposits/reprocess/{tx_hash}",
    response_model=AdminEfhcDepositReplayOut,
    summary="Replay the automated EFHC deposit watcher path",
)
async def admin_reprocess_efhc_deposit_tx(
    tx_hash: str,
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> AdminEfhcDepositReplayOut:
    if not str(tx_hash).strip():
        raise HTTPException(
            status_code=422,
            detail="tx_hash is required.",
        )
    try:
        replay_status = await reprocess_single_tx(
            db,
            str(tx_hash).strip(),
        )
        return AdminEfhcDepositReplayOut(
            ok=True,
            tx_hash=str(tx_hash).strip(),
            replay_status=str(replay_status),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(
            "admin_reprocess_efhc_deposit_tx failed: %s",
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail="Failed to replay automated EFHC deposit path.",
        ) from exc


@router.get(
    "/reports/overview",
    response_model=ReportsOverviewOut,
    summary="Быстрый обзор ключевых счётчиков",
)
async def reports_overview(
    db: AsyncSession = Depends(get_db),
    _auth: AuthContext = Depends(require_admin),
) -> ReportsOverviewOut:
    counters: dict[str, int] = {
        "ton_inbox_total": 0,
        "ton_inbox_errors": 0,
        "efhc_transfers_total": 0,
        "efhc_transfers_deficit": 0,
        "users_total": 0,
        "users_active": 0,
        "users_inactive": 0,
    }
    facts: dict[str, str] = {
        "panels_total_bought": "0",
        "panels_total_active": "0",
        "panels_total_archived": "0",
        "panels_total_paid_efhc": "0.00000000",
        "panels_total_paid__main__efhc": "0.00000000",
        "panels_total_paid_bonus_efhc": "0.00000000",
        "users_total_generated_kwh": "0.00000000",
        "users_total_exchanged_kwh": "0.00000000",
        "users_total__main__efhc": "0.00000000",
        "users_total_bonus_efhc": "0.00000000",
        "users_total_efhc": "0.00000000",
        "referrals_total_bonus_paid_efhc": "0.00000000",
        "withdraw_bonus_total_efhc": "0.00000000",
        "bank_total_efhc": "0.00000000",
        "bank_users_balance_diff_efhc": "0.00000000",
        "bank_users_balance_match": "OK",
    }
    notes: str | None = None

    try:
        # work pass audit repair: keep this admin report as a
        # bounded read-only snapshot. One SQL round-trip is easier
        # to reason about than 15+ sequential raw queries.
        await db.execute(text("SET LOCAL statement_timeout = '500ms'"))
        overview_q = text(
            """
            with
            ton as (
              select
                count(*)::bigint as total,
                count(*) filter (
                  where status like 'error_%'
                )::bigint as errors
              from efhc_core.ton_inbox_logs
            ),
            transfers as (
              select
                count(*)::bigint as total,
                count(*) filter (
                  where meta like '%processed_with_deficit%'
                )::bigint as deficit
              from efhc_core.efhc_transfers_log
            ),
            users_count as (
              select
                count(*)::bigint as total_users,
                coalesce(
                  sum(case when is_active then 1 else 0 end),
                  0
                )::bigint as active_users,
                coalesce(
                  sum(case when is_active then 0 else 1 end),
                  0
                )::bigint as inactive_users
              from efhc_core.users
            ),
            panels as (
              select
                count(*)::bigint as total_cnt,
                coalesce(
                  sum(case when is_active then 1 else 0 end),
                  0
                )::bigint as active_cnt,
                coalesce(
                  sum(case when is_active then 0 else 1 end),
                  0
                )::bigint as archived_cnt
              from efhc_core.panels
            ),
            purchase as (
              select
                coalesce(sum(amount), 0)::numeric as total_paid,
                coalesce(
                  sum(case when balance_type = 'main'
                    then amount else 0 end),
                  0
                )::numeric as total_paid_main,
                coalesce(
                  sum(case when balance_type = 'bonus'
                    then amount else 0 end),
                  0
                )::numeric as total_paid_bonus
              from efhc_core.efhc_transfers_log
              where reason in ('panel_purchase', 'panel_activation')
                and direction = 'debit'
            ),
            users_totals as (
              select
                coalesce(sum(main_balance), 0)::numeric as total_main,
                coalesce(sum(bonus_balance), 0)::numeric as total_bonus,
                coalesce(
                  sum(total_generated_kwh),
                  0
                )::numeric as total_generated,
                coalesce(
                  sum(exchanged_kwh_total),
                  0
                )::numeric as total_exchanged
              from efhc_core.users
            ),
            bank as (
              select coalesce(balance, 0)::numeric as bank_total
              from efhc_core.bank_balance
              where key = 'EFHC_MAIN'
              limit 1
            ),
            ref_bonus as (
              select
                coalesce(sum(amount), 0)::numeric as total_ref_bonus
              from efhc_core.efhc_transfers_log
              where reason in (
                'ref_direct_bonus',
                'ref_threshold_bonus'
              )
            ),
            withdraw_bonus as (
              select
                coalesce(
                  sum(amount),
                  0
                )::numeric as total_withdraw_bonus
              from efhc_core.efhc_transfers_log
              where reason like 'withdraw%'
                and balance_type = 'bonus'
            )
            select
              ton.total as ton_inbox_total,
              ton.errors as ton_inbox_errors,
              transfers.total as efhc_transfers_total,
              transfers.deficit as efhc_transfers_deficit,
              users_count.total_users,
              users_count.active_users,
              users_count.inactive_users,
              panels.total_cnt as panels_total_bought,
              panels.active_cnt as panels_total_active,
              panels.archived_cnt as panels_total_archived,
              purchase.total_paid,
              purchase.total_paid_main,
              purchase.total_paid_bonus,
              users_totals.total_generated,
              users_totals.total_exchanged,
              users_totals.total_main,
              users_totals.total_bonus,
              coalesce(bank.bank_total, 0)::numeric as bank_total,
              ref_bonus.total_ref_bonus,
              withdraw_bonus.total_withdraw_bonus
            from ton
            cross join transfers
            cross join users_count
            cross join panels
            cross join purchase
            cross join users_totals
            cross join ref_bonus
            cross join withdraw_bonus
            left join bank on true
            """
        )
        row = (await db.execute(overview_q)).mappings().first()
        if row:
            counters["ton_inbox_total"] = int(
                row["ton_inbox_total"] or 0
            )
            counters["ton_inbox_errors"] = int(
                row["ton_inbox_errors"] or 0
            )
            counters["efhc_transfers_total"] = int(
                row["efhc_transfers_total"] or 0
            )
            counters["efhc_transfers_deficit"] = int(
                row["efhc_transfers_deficit"] or 0
            )
            counters["users_total"] = int(row["total_users"] or 0)
            counters["users_active"] = int(row["active_users"] or 0)
            counters["users_inactive"] = int(row["inactive_users"] or 0)

            facts["panels_total_bought"] = str(
                int(row["panels_total_bought"] or 0)
            )
            facts["panels_total_active"] = str(
                int(row["panels_total_active"] or 0)
            )
            facts["panels_total_archived"] = str(
                int(row["panels_total_archived"] or 0)
            )
            facts["panels_total_paid_efhc"] = str(
                d8(row["total_paid"] or 0)
            )
            facts["panels_total_paid__main__efhc"] = str(
                d8(row["total_paid_main"] or 0)
            )
            facts["panels_total_paid_bonus_efhc"] = str(
                d8(row["total_paid_bonus"] or 0)
            )
            facts["users_total_generated_kwh"] = str(
                d8(row["total_generated"] or 0)
            )
            facts["users_total_exchanged_kwh"] = str(
                d8(row["total_exchanged"] or 0)
            )
            facts["users_total__main__efhc"] = str(
                d8(row["total_main"] or 0)
            )
            facts["users_total_bonus_efhc"] = str(
                d8(row["total_bonus"] or 0)
            )
            users_total = d8(
                (row["total_main"] or 0) + (row["total_bonus"] or 0)
            )
            facts["users_total_efhc"] = str(users_total)
            bank_total = d8(row["bank_total"] or 0)
            facts["bank_total_efhc"] = str(bank_total)
            facts["referrals_total_bonus_paid_efhc"] = str(
                d8(row["total_ref_bonus"] or 0)
            )
            facts["withdraw_bonus_total_efhc"] = str(
                d8(row["total_withdraw_bonus"] or 0)
            )
            diff_val = d8(bank_total - users_total)
            facts["bank_users_balance_diff_efhc"] = str(diff_val)
            facts["bank_users_balance_match"] = (
                "OK" if diff_val == d8(0) else "BUG"
            )

    except Exception as exc:
        logger.warning("reports_overview partial: %s", exc)
        notes = (
            "Таблицы ещё не инициализированы или "
            "миграции не применены. "
            "Проверьте alembic."
        )

    return ReportsOverviewOut(
        ok=True,
        ts=datetime.now(UTC),
        counters=counters,
        facts=facts,
        notes=notes,
    )
