from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from uuid import uuid4

from app.core.config_core import get_settings
from app.core.database_core import AsyncSessionLocal
from app.core.decimal_utils import d8
from app.core.security_core import (
    create_jwt_token,
    decode_jwt_token,
)
from app.deps import get_current_tg_id
from app.schemas.hub_schemas import (
    BrowserShopBootstrapOut,
    BrowserShopCatalogItemOut,
    BrowserShopCatalogOut,
    BrowserShopCreateIntentIn,
    BrowserShopCreateIntentOut,
    HubEfhcHandoffOut,
)
from app.schemas.payment_intents_schemas import PaymentIntentStatusOut
from app.schemas.shop_schemas import ShopOrderExternalIn
from app.services import wallets_service
from app.services.payment_intents_service import (
    create_intent_deposit_custom,
    create_intent_shop_external,
    get_intent_status_for_user,
    get_usdt_checkout_mode,
)
from app.services.shop_service import ShopService
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import text

router = APIRouter(prefix="/hub", tags=["hub"])


def _append_token(base_url: str, token: str) -> str:
    parts = urlsplit(base_url)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query["token"] = token
    return urlunsplit(
        (
            parts.scheme,
            parts.netloc,
            parts.path,
            urlencode(query),
            parts.fragment,
        )
    )


def _bot_open_url() -> str | None:
    uname = str(os.getenv("BOT_USERNAME") or "").strip().lstrip("@")
    if not uname:
        return None
    return f"https://t.me/{uname}"


def _telegram_sync_url() -> str | None:
    uname = str(os.getenv("BOT_USERNAME") or "").strip().lstrip("@")
    if not uname:
        return None
    return f"https://t.me/{uname}?start=browser_shop_sync"


def _wallet_sync_url() -> str | None:
    uname = str(os.getenv("BOT_USERNAME") or "").strip().lstrip("@")
    if not uname:
        return None
    return f"https://t.me/{uname}?start=browser_shop_wallet"


@router.post(
    "/efhc-handoff",
    response_model=HubEfhcHandoffOut,
    summary="Create signed Hub EFHC handoff URL",
)
async def create_efhc_handoff(
    current_tg_id: int = Depends(get_current_tg_id),
) -> HubEfhcHandoffOut:
    settings = get_settings()
    base_url = str(
        getattr(settings, "HUB_EFHC_BUY_URL", "") or ""
    ).strip()
    if not base_url:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Hub EFHC buy-flow is not connected yet"
            ),
        )

    ttl = int(
        getattr(settings, "HUB_EFHC_HANDOFF_TTL_SEC", 300) or 300
    )
    expires = datetime.now(tz=UTC) + timedelta(seconds=ttl)
    token = create_jwt_token(
        "hub_efhc_handoff",
        expires_delta=timedelta(seconds=ttl),
        extra={
            "kind": "hub_efhc_handoff",
            "aud": "efhc_buy_site",
            "tg_id": int(current_tg_id),
        },
    )
    return HubEfhcHandoffOut(
        redirect_url=_append_token(base_url, token),
        expires_at=expires,
    )


@router.get(
    "/browser-shop-bootstrap",
    response_model=BrowserShopBootstrapOut,
    summary="Get browser-shop bootstrap state",
)
async def get_browser_shop_bootstrap(
    token: str | None = None,
) -> BrowserShopBootstrapOut:
    if not token:
        return BrowserShopBootstrapOut(
            mode="guest",
            tg_linked=False,
            tg_id=None,
            wallet_linked=False,
            active_wallet_address=None,
            wallet_sync_required=True,
            bot_open_url=_bot_open_url(),
            telegram_sync_url=_telegram_sync_url(),
            wallet_sync_url=_wallet_sync_url(),
            usdt_checkout_mode=get_usdt_checkout_mode(),
        )

    payload = decode_jwt_token(str(token))
    if payload.get("kind") != "hub_efhc_handoff":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff kind",
        )
    if payload.get("aud") != "efhc_buy_site":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff audience",
        )

    tg_id_raw = payload.get("tg_id")
    try:
        tg_id = int(tg_id_raw)
    except Exception as err:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff tg_id",
        ) from err

    async with AsyncSessionLocal() as db:
        wallets = await wallets_service.list_wallets(db, tg_id=tg_id)

    active_wallet = next(
        (w for w in wallets if bool(getattr(w, "is_active", False))),
        None,
    )
    active_addr = (
        str(getattr(active_wallet, "wallet_address", ""))
        if active_wallet is not None
        else None
    )

    return BrowserShopBootstrapOut(
        mode="handoff_bound",
        tg_linked=True,
        tg_id=tg_id,
        wallet_linked=active_wallet is not None,
        active_wallet_address=active_addr,
        wallet_sync_required=active_wallet is None,
        bot_open_url=_bot_open_url(),
        telegram_sync_url=_telegram_sync_url(),
        wallet_sync_url=_wallet_sync_url(),
        usdt_checkout_mode=get_usdt_checkout_mode(),
    )



@router.get(
    "/browser-shop-catalog",
    response_model=BrowserShopCatalogOut,
    summary="Get browser-shop storefront cards",
)
async def get_browser_shop_catalog() -> BrowserShopCatalogOut:
    async with AsyncSessionLocal() as db:
        svc = ShopService(db)
        catalog = await svc.get_catalog(0)

    items: list[BrowserShopCatalogItemOut] = []
    for item in catalog.items:
        items.append(
            BrowserShopCatalogItemOut(
                sku=str(item.sku),
                title=str(item.title),
                description=item.description,
                item_type=str(item.type),
                ton_enabled=bool(item.ton_enabled),
                methods=item.methods,
            )
        )

    return BrowserShopCatalogOut(items=items)



@router.post(
    "/browser-shop-create-intent",
    response_model=BrowserShopCreateIntentOut,
    summary="Create browser-shop external intent",
)
async def create_browser_shop_intent(
    payload: BrowserShopCreateIntentIn,
) -> BrowserShopCreateIntentOut:
    token = str(payload.token or "").strip()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Browser-shop linking is required",
        )

    claims = decode_jwt_token(token)
    if claims.get("kind") != "hub_efhc_handoff":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff kind",
        )
    if claims.get("aud") != "efhc_buy_site":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff audience",
        )

    try:
        tg_id = int(claims.get("tg_id"))
    except Exception as err:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff tg_id",
        ) from err

    pay_method = str(payload.pay_method or "").upper()
    if pay_method not in {"TON"}:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported pay method",
        )

    try:
        qty = int(payload.quantity)
    except Exception as err:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid quantity",
        ) from err
    if qty != 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Browser-shop allows one item per operation",
        )

    sku = str(payload.sku or "").strip()
    if sku == "CUSTOM_EFHC":
        raw_custom = str(payload.custom_efhc_amount_d8 or "").strip()
        if not raw_custom:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Custom EFHC amount is required",
            )
        try:
            custom_efhc_amount = d8(Decimal(raw_custom))
        except Exception as err:  # noqa: BLE001
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid custom EFHC amount",
            ) from err
        if custom_efhc_amount < d8("10"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Minimum custom EFHC amount is 10",
            )
        client_nonce = str(payload.client_nonce or uuid4().hex)
        if pay_method != "TON":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="USDT is disabled until real jetton transfer",
            )
        amount_asset_d8 = d8(custom_efhc_amount * Decimal("0.3"))
        async with AsyncSessionLocal() as db:
            if not await wallets_service.has_active_wallet(
                db, tg_id=tg_id
            ):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=(
                        "Wallet sync is required before "
                        "intent creation"
                    ),
                )
            intent = await create_intent_deposit_custom(
                db,
                tg_id=int(tg_id),
                idempotency_key=client_nonce,
                asset=pay_method,
                amount_asset_d8=amount_asset_d8,
                efhc_amount_d8=custom_efhc_amount,
            )
        return BrowserShopCreateIntentOut(
            tg_id=tg_id,
            intent_id=int(intent["intent_id"]),
            order_id=0,
            item_type="CUSTOM_EFHC",
            pay_method=pay_method,
            amount=str(amount_asset_d8),
            memo=str(intent["payload"]),
            to_wallet=str(intent["to_address"]),
            tonconnect_tx=intent.get("tonconnect_tx"),
        )

    client_nonce = str(payload.client_nonce or uuid4().hex)
    order_payload = ShopOrderExternalIn(
        sku=sku,
        quantity=qty,
        pay_method=pay_method,
    )

    async with AsyncSessionLocal() as db:
        svc = ShopService(db)
        catalog = await svc.get_catalog(0)
        item = next(
            (
                it
                for it in catalog.items
                if str(it.sku) == sku and bool(it.active)
            ),
            None,
        )
        if item is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Storefront item not found",
            )
        methods = getattr(item, "methods", None) or {}
        if pay_method not in methods:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Selected pay method is not enabled for item",
            )

        if not await wallets_service.has_active_wallet(
                db, tg_id=tg_id
            ):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                        "Wallet sync is required before "
                        "intent creation"
                    ),
            )

        out = await svc.create_external_order(
            tg_id,
            order_payload,
            client_nonce,
        )
        pay = getattr(out, "pay", None) or out.get("pay")
        order = getattr(out, "order", None) or out.get("order")
        if not pay or not order:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="External order payload is incomplete",
            )

        asset = str(pay.get("method") or pay_method or "TON").upper()
        amt = d8(Decimal(str(pay.get("amount") or "0")))
        to_addr = str(pay.get("to_wallet") or "").strip()
        intent = await create_intent_shop_external(
            db,
            tg_id=int(tg_id),
            idempotency_key=client_nonce,
            asset=asset,
            amount_asset_d8=amt,
            to_address=to_addr,
        )

        try:
            order_id = int(order.get("id") or 0)
        except Exception:
            order_id = 0
        if order_id > 0:
            await db.execute(
                text(
                    "UPDATE efhc_core.shop_orders "
                    "SET memo = :m, updated_at = NOW() "
                    "WHERE id = :oid"
                ),
                {"m": str(intent["payload"]), "oid": order_id},
            )
            await db.commit()

    return BrowserShopCreateIntentOut(
        tg_id=tg_id,
        intent_id=int(intent["intent_id"]),
        order_id=order_id,
        item_type=str(getattr(item, "type", "UNKNOWN")),
        pay_method=asset,
        amount=str(amt),
        memo=str(intent["payload"]),
        to_wallet=to_addr,
        tonconnect_tx=(
            intent.get("tonconnect_tx")
            if isinstance(intent, dict)
            else None
        ),
    )



@router.get(
    "/browser-shop-intent-status",
    response_model=PaymentIntentStatusOut,
    summary="Get browser-shop intent status",
)
async def get_browser_shop_intent_status(
    token: str,
    intent_id: int,
) -> PaymentIntentStatusOut:
    claims = decode_jwt_token(str(token))
    if claims.get("kind") != "hub_efhc_handoff":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff kind",
        )
    if claims.get("aud") != "efhc_buy_site":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff audience",
        )
    try:
        tg_id = int(claims.get("tg_id"))
    except Exception as err:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff tg_id",
        ) from err

    async with AsyncSessionLocal() as db:
        row = await get_intent_status_for_user(
            db,
            tg_id=tg_id,
            intent_id=int(intent_id),
        )
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment intent not found",
        )
    return PaymentIntentStatusOut(**row)
