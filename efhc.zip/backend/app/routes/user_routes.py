# -*- coding: utf-8 -*-
# backend/app/routes/user_routes.py
# ======================================================================
# EFHC Bot — пользовательские ручки.
# Профиль, балансы, подсказки для UI.
#
# Канон:
# - Только чтение. Денежные операции выполняют сервисы.
# - Все суммы наружу: Decimal с 8 знаками, округление вниз (d8).
# - Посекундные ставки генерации передаются фронту как источник истины.
# ======================================================================

from __future__ import annotations

from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.system_locks import (
    get_rate_base_d8,
    get_rate_vip_d8,
)
from app.deps import d8, get_db
from app.services.exchange_service import (
    preview_exchange as svc_preview_exchange,
)
from app.services.panels_service import (
    panels_summary as svc_panels_summary,
)

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")
GEN_PER_SEC_BASE_KWH = get_rate_base_d8()
GEN_PER_SEC_VIP_KWH = get_rate_vip_d8()


class UserProfileOut(BaseModel):
    tg_id: int = Field(..., description="Telegram ID пользователя")
    username: Optional[str] = Field(
        None,
        description="Никнейм в Telegram (если есть)",
    )
    is_vip: bool = Field(
        ...,
        description="Флаг VIP статуса (по NFT)",
    )
    main_balance: str = Field(
        ...,
        description="Основной баланс EFHC (d8 строкой)",
    )
    bonus_balance: str = Field(
        ...,
        description="Бонусный баланс EFHC (d8 строкой)",
    )
    available_kwh: str = Field(
        ...,
        description="Доступная к обмену энергия (kWh)",
    )
    total_generated_kwh: str = Field(
        ...,
        description="Общая сгенерированная энергия (для рейтинга)",
    )
    gen_per_sec_base_kwh: str = Field(
        ...,
        description="Ставка без VIP, kWh/сек (канон)",
    )
    gen_per_sec_vip_kwh: str = Field(
        ...,
        description="Ставка VIP, kWh/сек (канон)",
    )


class PanelsSummaryOut(BaseModel):
    active_count: int
    total_generated_by_panels: str
    nearest_expire_at: Optional[str] = None


class ExchangePreviewOut(BaseModel):
    ok: bool
    available_kwh: str
    max_exchangeable_kwh: str
    rate_kwh_to_efhc: str
    detail: str


router = APIRouter(prefix="/user", tags=["user"])


def get_current_tg_id(req: Request) -> int:
    """Определяет tg_id текущего пользователя.

    Канон:
    - в prod берём tg_id из middleware авторизации (req.state.tg_id)
    - dev fallback возможен только при ALLOW_INSECURE_USER_HEADERS=true
    """
    if getattr(req.state, "tg_id", None):
        return int(req.state.tg_id)

    allow_insecure = bool(
        getattr(settings, "ALLOW_INSECURE_USER_HEADERS", False)
    )
    if not allow_insecure:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Требуется аутентификация "
                "(Telegram initData / middleware)."
            ),
        )

    hdr = (
        req.headers.get("X-Telegram-Id")
        or req.headers.get("X - Telegram - Id")
        or ""
    ).strip()
    if hdr.isdigit():
        return int(hdr)

    qv = (req.query_params.get("tg_id") or "").strip()
    if qv.isdigit():
        return int(qv)

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=(
            "Не удалось определить пользователя: "
            "отсутствует авторизация Telegram."
        ),
    )


async def get_user_profile_by_telegram(
    tg_id: int,
    db: AsyncSession,
) -> UserProfileOut:
    q = text(
        f"\n".join(
            [
                "SELECT",
                "  u.tg_id,",
                "  u.username,",
                "  COALESCE(u.is_vip, FALSE) AS is_vip,",
                "  COALESCE(u.main_balance, 0)::numeric",
                "    AS main_balance,",
                "  COALESCE(u.bonus_balance, 0)::numeric",
                "    AS bonus_balance,",
                "  COALESCE(u.available_kwh, 0)::numeric",
                "    AS available_kwh,",
                "  COALESCE(u.total_generated_kwh, 0)::numeric",
                "    AS total_generated_kwh",
                f"FROM {SCHEMA}.users u",
                "WHERE u.tg_id = :tg",
                "LIMIT 1",
            ]
        )
    )
    row = await db.execute(q, {"tg": int(tg_id)})
    rec = row.fetchone()
    if not rec:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Пользователь {tg_id} не найден.",
        )

    return UserProfileOut(
        tg_id=int(rec[0]),
        username=(str(rec[1]) if rec[1] is not None else None),
        is_vip=bool(rec[2]),
        main_balance=str(d8(rec[3])),
        bonus_balance=str(d8(rec[4])),
        available_kwh=str(d8(rec[5])),
        total_generated_kwh=str(d8(rec[6])),
        gen_per_sec_base_kwh=str(d8(GEN_PER_SEC_BASE_KWH)),
        gen_per_sec_vip_kwh=str(d8(GEN_PER_SEC_VIP_KWH)),
    )


@router.get(
    "/{tg_id}/me",
    response_model=UserProfileOut,
    summary="Профиль пользователя (me)",
)
async def get_user_me(
    tg_id: int,
    db: AsyncSession = Depends(get_db),
) -> UserProfileOut:
    return await get_user_profile_by_telegram(tg_id, db)


@router.get(
    "/me",
    response_model=UserProfileOut,
    summary="Профиль (tg_id из Telegram)",
)
async def get_me(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> UserProfileOut:
    tg_id = get_current_tg_id(request)
    return await get_user_profile_by_telegram(tg_id, db)


@router.get(
    "/{tg_id}/panels-summary",
    response_model=PanelsSummaryOut,
    summary="Сводка по панелям",
)
async def get_panels_summary(
    tg_id: int,
    db: AsyncSession = Depends(get_db),
) -> PanelsSummaryOut:
    try:
        s = await svc_panels_summary(db, tg_id=tg_id)
    except Exception as exc:
        logger.warning("panels_summary failed tg_id=%s: %s", tg_id, exc)
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите попытку.",
        ) from exc

    nearest = (
        s["nearest_expire_at"].isoformat()
        if s.get("nearest_expire_at")
        else None
    )
    return PanelsSummaryOut(
        active_count=int(s["active_count"]),
        total_generated_by_panels=str(
            d8(s["total_generated_by_panels"])
        ),
        nearest_expire_at=nearest,
    )


@router.get(
    "/{tg_id}/exchange/preview",
    response_model=ExchangePreviewOut,
    summary="Предпросмотр обмена kWh→EFHC",
)
async def preview_exchange(
    tg_id: int,
    db: AsyncSession = Depends(get_db),
) -> ExchangePreviewOut:
    try:
        p = await svc_preview_exchange(db, tg_id=tg_id)
    except Exception as exc:
        logger.warning(
            "exchange_preview failed tg_id=%s: %s",
            tg_id,
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите попытку.",
        ) from exc

    return ExchangePreviewOut(
        ok=bool(p.ok),
        available_kwh=str(d8(p.available_kwh)),
        max_exchangeable_kwh=str(d8(p.max_exchangeable_kwh)),
        rate_kwh_to_efhc=str(d8(p.rate_kwh_to_efhc)),
        detail=p.detail,
    )
