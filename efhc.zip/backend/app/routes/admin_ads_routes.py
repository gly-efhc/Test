# backend/app/routes/admin_ads_routes.py
# ======================================================================
# EFHC Bot — Admin: Ads
# ----------------------------------------------------------------------
# Назначение:
# Админский доступ к конфигурации рекламных провайдеров.
# ======================================================================

from __future__ import annotations

from typing import Any

from app.deps import require_admin
from app.services.admin.admin_ads_service import list_providers
from fastapi import APIRouter, Depends

router = APIRouter(prefix="/admin/ads", tags=["admin:ads"])


@router.get("/providers")
async def admin_ads_providers(
    _auth: Any = Depends(require_admin),
) -> list[dict[str, Any]]:
    """Список ads-провайдеров для UI админки."""
    return await list_providers()
