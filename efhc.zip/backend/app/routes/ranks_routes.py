# backend/app/routes/ranks_routes.py
# ======================================================================
# Public ranks routes for EFHC WebApp.
#
# Canon:
# - frontend must not pass explicit ids in public rank URLs;
# - /me routes resolve the current user through Telegram auth context;
# - kWh and Referrals are the only public rank modes;
# В строках рангов global_id может использоваться как служебный ID.
# Интерфейс не должен показывать его напрямую.
#   показывать username или нейтральную замену, не сырой global_id.
# ======================================================================

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from typing import Any

from app.core.logging_core import get_logger
from app.deps import d8, get_db
from app.identity.nonfinancial_read_dependency import (
    get_nonfinancial_read_owner,
)
from app.identity.nonfinancial_read_switch import (
    NonFinancialReadOwner,
    resolve_nonfinancial_read_owner,
)
from app.services.ranks_service import (
    get_my_plus_top,
    list_top_page,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/ranks", tags=["ranks"])


class RankItemOut(BaseModel):
    global_id: str
    tg_id: int | None = None
    username: str | None = None
    total_generated_kwh: str = Field(
        ...,
        description="kWh score as Decimal d8 string for kWh ranks",
    )
    rank_pos: int
    is_vip: bool
    active_referrals: int | None = None


class MyPlusTopOut(BaseModel):
    snapshot_at: str
    me: RankItemOut
    top: list[RankItemOut]
    next_cursor: str | None


class TopPageOut(BaseModel):
    snapshot_at: str
    items: list[RankItemOut]
    next_cursor: str | None


def _build_etag(payload: dict[str, Any]) -> str:
    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _rank_item_from_service(it: Any) -> RankItemOut:
    return RankItemOut(
        global_id=f"{int(it.global_id):010d}",
        tg_id=(int(it.tg_id) if it.tg_id is not None else None),
        username=it.username,
        total_generated_kwh=str(d8(it.total_kwh)),
        rank_pos=int(it.rank),
        is_vip=bool(it.is_vip),
    )


async def _kwh_my_plus_top_payload(
    *,
    db: AsyncSession,
    tg_id: int | None = None,
    owner: NonFinancialReadOwner | None = None,
    limit: int,
    cursor: str | None,
    force_refresh: bool,
    max_age_minutes: int,
) -> MyPlusTopOut:
    if owner is None:
        if tg_id is None:
            raise ValueError("Rank owner selector is required")
        owner = await resolve_nonfinancial_read_owner(
            db,
            tg_id=int(tg_id),
        )
    display_global_id = int(owner.global_id)
    display_tg_id = owner.legacy_tg_id

    me, top, meta, next_cursor = await get_my_plus_top(
        db,
        global_id=display_global_id,
        limit=int(limit),
        cursor=cursor,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
    )
    if me is None:
        me_out = RankItemOut(
            global_id=(
                f"{display_global_id:010d}"
                if display_global_id > 0
                else "0000000000"
            ),
            tg_id=display_tg_id,
            username=None,
            total_generated_kwh="0.00000000",
            rank_pos=0,
            is_vip=False,
        )
    else:
        me_out = _rank_item_from_service(me)
    return MyPlusTopOut(
        snapshot_at=meta.snapshot_at.astimezone(UTC).isoformat(),
        me=me_out,
        top=[_rank_item_from_service(it) for it in top],
        next_cursor=next_cursor,
    )


async def _kwh_top_payload(
    *,
    db: AsyncSession,
    limit: int,
    cursor: str | None,
    exclude_tg_id: int | None,
    force_refresh: bool,
    max_age_minutes: int,
    global_read: bool = False,
) -> TopPageOut:
    items, meta, next_cursor = await list_top_page(
        db,
        limit=int(limit),
        cursor=cursor,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
        global_read=bool(global_read),
    )
    if exclude_tg_id is not None:
        items = [
            it
            for it in items
            if it.tg_id is None or int(it.tg_id) != int(exclude_tg_id)
        ]
    return TopPageOut(
        snapshot_at=meta.snapshot_at.astimezone(UTC).isoformat(),
        items=[_rank_item_from_service(it) for it in items],
        next_cursor=next_cursor,
    )


def _referral_rank_out(row: Any) -> RankItemOut:
    active_refs = int(row.active_referrals or 0)
    return RankItemOut(
        global_id=f"{int(row.global_id):010d}",
        tg_id=(int(row.tg_id) if row.tg_id is not None else None),
        username=row.username,
        total_generated_kwh="0.00000000",
        rank_pos=int(row.rank_pos),
        is_vip=bool(row.is_vip),
        active_referrals=active_refs,
    )


async def _referral_my_plus_top_payload(
    *,
    db: AsyncSession,
    owner: NonFinancialReadOwner,
    limit: int,
) -> MyPlusTopOut:
    """Build referral ranking after provider identity resolution."""
    display_tg_id = owner.legacy_tg_id
    global_id = owner.global_id
    ranked_sql = text(
        """
        WITH ranked AS (
          SELECT
            u.global_id,
            u.tg_id,
            u.username,
            COALESCE(u.is_vip, FALSE) AS is_vip,
            COUNT(rl.invitee_global_id) FILTER (
              WHERE rl.activated_at IS NOT NULL
            ) AS active_referrals,
            ROW_NUMBER() OVER (
              ORDER BY COUNT(rl.invitee_global_id) FILTER (
                WHERE rl.activated_at IS NOT NULL
              ) DESC, u.global_id ASC
            ) AS rank_pos
          FROM efhc_core.users u
          LEFT JOIN efhc_core.referral_links rl
            ON rl.inviter_global_id = u.global_id
          WHERE COALESCE(u.is_active, TRUE) = TRUE
            AND u.global_id IS NOT NULL
          GROUP BY u.global_id, u.tg_id, u.username, u.is_vip
        )
        SELECT * FROM ranked
        WHERE global_id = :global_id
           OR rank_pos <= :limit
        ORDER BY rank_pos ASC, global_id ASC
        """
    )
    rows = (
        await db.execute(
            ranked_sql,
            {"global_id": int(global_id), "limit": int(limit)},
        )
    ).fetchall()
    me_row = next(
        (r for r in rows if int(r.global_id) == int(global_id)),
        None,
    )
    top_rows = [
        r for r in rows if int(r.global_id) != int(global_id)
    ][: int(limit)]
    if me_row is None:
        me = RankItemOut(
            global_id=f"{int(global_id):010d}",
            tg_id=display_tg_id,
            username=None,
            total_generated_kwh="0.00000000",
            rank_pos=0,
            is_vip=False,
            active_referrals=0,
        )
    else:
        me = _referral_rank_out(me_row)
    next_cursor = str(top_rows[-1].rank_pos) if top_rows else None
    return MyPlusTopOut(
        snapshot_at=datetime.now(tz=UTC).isoformat(),
        me=me,
        top=[_referral_rank_out(r) for r in top_rows],
        next_cursor=next_cursor,
    )


async def _referral_top_payload(
    *,
    db: AsyncSession,
    limit: int,
    cursor: str | None,
    exclude_tg_id: int | None,
) -> TopPageOut:
    """Build provider-neutral referral top by canonical ownership."""
    after_pos = int(cursor) if cursor and str(cursor).isdigit() else 0
    sql = text(
        """
        WITH ranked AS (
          SELECT
            u.global_id,
            u.tg_id,
            u.username,
            COALESCE(u.is_vip, FALSE) AS is_vip,
            COUNT(rl.invitee_global_id) FILTER (
              WHERE rl.activated_at IS NOT NULL
            ) AS active_referrals,
            ROW_NUMBER() OVER (
              ORDER BY COUNT(rl.invitee_global_id) FILTER (
                WHERE rl.activated_at IS NOT NULL
              ) DESC, u.global_id ASC
            ) AS rank_pos
          FROM efhc_core.users u
          LEFT JOIN efhc_core.referral_links rl
            ON rl.inviter_global_id = u.global_id
          WHERE COALESCE(u.is_active, TRUE) = TRUE
            AND u.global_id IS NOT NULL
          GROUP BY u.global_id, u.tg_id, u.username, u.is_vip
        )
        SELECT * FROM ranked
        WHERE rank_pos > :after_pos
          AND (:exclude_tg_id IS NULL OR tg_id <> :exclude_tg_id)
        ORDER BY rank_pos ASC, global_id ASC
        LIMIT :limit
        """
    )
    rows = (
        await db.execute(
            sql,
            {
                "after_pos": after_pos,
                "exclude_tg_id": exclude_tg_id,
                "limit": int(limit),
            },
        )
    ).fetchall()
    next_cursor = str(rows[-1].rank_pos) if rows else None
    return TopPageOut(
        snapshot_at=datetime.now(tz=UTC).isoformat(),
        items=[_referral_rank_out(r) for r in rows],
        next_cursor=next_cursor,
    )


def _etag_or_304(
    *,
    response: Response,
    if_none_match: str | None,
    payload: BaseModel,
    scope: str,
) -> None:
    raw = payload.model_dump()
    raw["scope"] = scope
    etag = _build_etag(raw)
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )
    response.headers["ETag"] = etag


@router.get(
    "/my-plus-top/me",
    response_model=MyPlusTopOut,
    summary="Current-user kWh rank: me + top",
)
async def get_my_kwh_rank_me(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> MyPlusTopOut:
    out = await _kwh_my_plus_top_payload(
        db=db,
        owner=owner,
        limit=int(limit),
        cursor=cursor,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_kwh_me",
    )
    return out


@router.get(
    "/top/me",
    response_model=TopPageOut,
    summary="Current-user kWh top page without explicit tg_id in URL",
)
async def get_kwh_top_me(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> TopPageOut:
    out = await _kwh_top_payload(
        db=db,
        limit=int(limit),
        cursor=cursor,
        exclude_tg_id=owner.legacy_tg_id,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_kwh_top_me",
    )
    return out


@router.get(
    "/referrals/my-plus-top/me",
    response_model=MyPlusTopOut,
    summary="Current-user referrals rank: me + top",
)
async def get_my_referrals_rank_me(
    response: Response,
    limit: int = 100,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> MyPlusTopOut:
    out = await _referral_my_plus_top_payload(
        db=db,
        owner=owner,
        limit=int(limit),
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_referrals_me",
    )
    return out


@router.get(
    "/referrals/top/me",
    response_model=TopPageOut,
    summary=(
        "Current-user referrals top page without explicit tg_id in URL"
    ),
)
async def get_referrals_top_me(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> TopPageOut:
    out = await _referral_top_payload(
        db=db,
        limit=int(limit),
        cursor=cursor,
        exclude_tg_id=owner.legacy_tg_id,
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_referrals_top_me",
    )
    return out


@router.get(
    "/my-plus-top",
    response_model=MyPlusTopOut,
    include_in_schema=False,
)
async def get_ranks_my_plus_top(
    tg_id: int,
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(None, convert_underscores=True),
    db: AsyncSession = Depends(get_db),
) -> MyPlusTopOut:
    response.headers["X-EFHC-Deprecated"] = (
        "Use /ranks/my-plus-top/me for current-user frontend calls."
    )
    out = await _kwh_my_plus_top_payload(
        db=db,
        tg_id=int(tg_id),
        limit=int(limit),
        cursor=cursor,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_kwh_legacy",
    )
    return out


@router.get(
    "/top",
    response_model=TopPageOut,
    include_in_schema=False,
)
async def get_ranks_top(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    exclude_tg_id: int | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(None, convert_underscores=True),
    db: AsyncSession = Depends(get_db),
) -> TopPageOut:
    response.headers["X-EFHC-Deprecated"] = (
        "Use /ranks/top/me for current-user frontend calls."
    )
    out = await _kwh_top_payload(
        db=db,
        limit=int(limit),
        cursor=cursor,
        exclude_tg_id=exclude_tg_id,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_kwh_top_legacy",
    )
    return out
