# backend/app/routes/ranks_routes.py
# ======================================================================
# Назначение кода:
# • Публичные ручки рейтинга: витрина «Я + TOP» и постраничный TOP.
# • «Принудительная синхронизация» при открытии:
#   ensure_latest_snapshot()
# освежает снапшот рейтинга конкурентно-безопасно (advisory-lock).
#
# Канон/инварианты:
# • Источник истины — total_generated_kwh, никакой «суточной» логики.
# • «Я» отображается с реальным местом; в TOP «Я» не дублируется.
# • Все числа — Decimal(8), строки в JSON (канон сериализации).
#
# ИИ-защиты:
# • ensure_latest_snapshot(): попытка освежить снапшот; при сбоях —
#   деградация
# к последнему доступному без падения ручек.
# • ETag/If-None-Match: экономия трафика, стабильность клиента.
# • Курсорная пагинация по rank_pos ASC без OFFSET — устойчива на
#   больших
# данных.
#
# Запреты:
# • Нет денежных операций, нет P2P, нет модификации балансов/тоталов.
# • Нет «живого» перерасчёта позиций вне снапшота (только snapshot).
# ======================================================================

from __future__ import annotations

import hashlib
import json
from datetime import UTC
from typing import Any

from app.core.logging_core import get_logger
from app.deps import d8, get_db  # централизованное Decimal(8)

# Витринный сервис рейтинга: снапшоты и выдача «Я + TOP»
from app.services.ranks_service import (
    ensure_latest_snapshot,
    get_my_plus_top,
    list_top_page,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/ranks", tags=["ranks"])

# ======================================================================
# Локальные хелперы ETag (стабильное хеширование полезной нагрузки)
# ======================================================================


def _build_etag(payload: dict[str, Any]) -> str:
    """Строит стабильный ETag по JSON-представлению payload."""
    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

# ======================================================================
# Pydantic-модели ответа (Decimal → строки, без потери точности)
# ======================================================================


class RankItemOut(BaseModel):
    tg_id: int
    username: str | None = None
    total_generated_kwh: str = Field(
        ...,
        description="Тотал kWh (строка Decimal d8)",
    )
    rank_pos: int
    is_vip: bool


class MyPlusTopOut(BaseModel):
    snapshot_at: str
    me: RankItemOut
    top: list[RankItemOut]
    next_cursor: str | None


class TopPageOut(BaseModel):
    snapshot_at: str
    items: list[RankItemOut]
    next_cursor: str | None

# ======================================================================
# GET /ranks/my-plus-top — «Я + TOP» с курсором и ETag
# ======================================================================

@router.get(
    "/my-plus-top",
    response_model=MyPlusTopOut,
    summary="Витрина рейтинга: «Я + TOP» (без дублирования «Я»)",
)
async def get_ranks_my_plus_top(
    tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
) -> MyPlusTopOut:
    """
    Что делает:
      • Обеспечивает актуальный снапшот (ensure_latest_snapshot).
      • Возвращает «Я» (реальное место) + TOP-страницу без «Я».
      • Курсорная пагинация по rank_pos ASC (без OFFSET).
      • Поддерживает ETag/If-None-Match для экономии трафика.
    Вход:
      • tg_id — ID пользователя.
      • limit (<=200), cursor — курсор rank_pos;
        force_refresh — rebuild.
    Выход:
      • snapshot_at (ISO UTC), me, top[], next_cursor.
    Исключения:
      • 500 — при сбоях базы (сервис старается деградировать).
    """
    await ensure_latest_snapshot(
        db,
        max_age_minutes=int(max_age_minutes),
        force_refresh=bool(force_refresh),
    )

    # 2) собрать витрину «Я + TOP»
    dto = await get_my_plus_top(
        db,
        tg_id=int(tg_id),
        limit=int(limit),
        cursor=cursor,
        force_refresh=False,
        max_age_minutes=int(max_age_minutes),
    )

    # 3) собрать полезную нагрузку для ETag
    snap_iso = dto.snapshot_at.astimezone(UTC).isoformat()
    payload = {
        "scope": "ranks_my_plus_top",
        "snapshot_at": snap_iso,
        "me": {
            "tg_id": dto.me.tg_id,
            "username": dto.me.username or "",
            "total_generated_kwh": str(d8(dto.me.total_generated_kwh)),
            "rank_pos": dto.me.rank_pos,
            "is_vip": bool(dto.me.is_vip),
        },
        "top": [
            {
                "tg_id": it.tg_id,
                "username": it.username or "",
                "total_generated_kwh": str(d8(it.total_generated_kwh)),
                "rank_pos": it.rank_pos,
                "is_vip": bool(it.is_vip),
            }
            for it in dto.top
        ],
        "next_cursor": dto.next_cursor or "",
    }
    etag = _build_etag(payload)

    # 4) отдаём 304 Not Modified, если ETag совпал
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    # 5) формируем ответ (строки для Decimal)
    out = MyPlusTopOut(
        snapshot_at=snap_iso,
        me=RankItemOut(
            tg_id=dto.me.tg_id,
            username=dto.me.username,
            total_generated_kwh=str(d8(dto.me.total_generated_kwh)),
            rank_pos=dto.me.rank_pos,
            is_vip=bool(dto.me.is_vip),
        ),
        top=[
            RankItemOut(
                tg_id=it.tg_id,
                username=it.username,
                total_generated_kwh=str(d8(it.total_generated_kwh)),
                rank_pos=it.rank_pos,
                is_vip=bool(it.is_vip),
            )
            for it in dto.top
        ],
        next_cursor=dto.next_cursor,
    )
    return Response(
        content=out.model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )

# ======================================================================
# GET /ranks/top — постраничный TOP (без «Я»), для пролистывания
# ======================================================================

@router.get(
    "/top",
    response_model=TopPageOut,
    summary=(
        "TOP - страница рейтинга "
        "(листинг по rank_pos ASC, без «Я»)"
    ),
)
async def get_ranks_top(
    limit: int = 100,
    cursor: str | None = None,
    exclude_tg_id: int | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
) -> TopPageOut:
    """
    Что делает:
      • Возвращает страницу TOP по снапшоту (rank_pos ASC) с курсором.
      • exclude_tg_id — исключить «Я» из листинга.
      • ETag/If-None-Match — для экономии трафика.
    Важно:
      • Денежных эффектов нет, это чистое чтение снапшота.
    """
    # 1) обеспечить свежий снапшот
    snapshot_at = await ensure_latest_snapshot(
        db,
        max_age_minutes=int(max_age_minutes),
        force_refresh=bool(force_refresh),
    )

    # 2) получить страницу TOP
    exc = int(exclude_tg_id) if exclude_tg_id else None
    items_dto, next_cursor = await list_top_page(
        db,
        snapshot_at=snapshot_at,
        limit=int(limit),
        cursor=cursor,
        exclude_tg_id=exc,
    )

    payload = {
        "scope": "ranks_top",
        "snapshot_at": snapshot_at.astimezone(UTC).isoformat(),
        "items": [
            {
                "tg_id": it.tg_id,
                "username": it.username or "",
                "total_generated_kwh": str(d8(it.total_generated_kwh)),
                "rank_pos": it.rank_pos,
                "is_vip": bool(it.is_vip),
            }
            for it in items_dto
        ],
        "next_cursor": next_cursor or "",
    }
    etag = _build_etag(payload)
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    out = TopPageOut(
        snapshot_at=snapshot_at.astimezone(UTC).isoformat(),
        items=[
            RankItemOut(
                tg_id=it.tg_id,
                username=it.username,
                total_generated_kwh=str(d8(it.total_generated_kwh)),
                rank_pos=it.rank_pos,
                is_vip=bool(it.is_vip),
            )
            for it in items_dto
        ],
        next_cursor=next_cursor,
    )
    return Response(
        content=out.model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )

# ======================================================================
# Пояснения «для чайника»:
# • Зачем снапшоты? Рейтинг на больших объёмах считать «на лету» дорого.
# Снапшот
# фиксирует срез (snapshot_at) и даёт быстрые, повторяемые ответы.
# • Почему курсор по rank_pos? Он стабилен и не страдает от
# смещений, как OFFSET. Каждая следующая страница берёт rank_pos > last.
# • Что делает force_refresh? Просит пересобрать снапшот прямо сейчас.
#   Advisory-lock защитит от гонок; при сбое вернётся последний.
# • Почему «Я» не дублируется в TOP? Чтобы не было повторов; «Я» идёт
# отдельным блоком, а TOP — без него.
# ======================================================================

