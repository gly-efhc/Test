# backend/app/routes/ranks_routes.py
"""Публичные routes рейтингов с provider-neutral владельцем ``global_id``."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from typing import Any

from app.core.logging_core import get_logger
from app.deps import d8, get_db
from app.identity.nonfinancial_owner import NonFinancialReadOwner
from app.identity.nonfinancial_read_dependency import (
    get_nonfinancial_read_owner,
)
from app.services.ranks_service import (
    get_my_plus_top,
    get_user_rank_context,
    list_top_page,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/ranks", tags=["ranks"])


class RankItemOut(BaseModel):
    global_id: str = Field(pattern=r"^[0-9]{10}$")
    username: str | None = None
    total_generated_kwh: str
    rank_pos: int
    is_vip: bool
    active_referrals: int | None = None


class MyPlusTopOut(BaseModel):
    snapshot_at: str
    me: RankItemOut
    top: list[RankItemOut]
    next_cursor: str | None


class TopPageOut(BaseModel):
    snapshot_at: str
    items: list[RankItemOut]
    next_cursor: str | None


def _build_etag(payload: dict[str, Any]) -> str:
    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _rank_item_from_service(item: Any) -> RankItemOut:
    return RankItemOut(
        global_id=f"{int(item.global_id):010d}",
        username=item.username,
        total_generated_kwh=str(d8(item.total_kwh)),
        rank_pos=int(item.rank),
        is_vip=bool(item.is_vip),
    )


async def _kwh_my_plus_top_payload(
    *,
    db: AsyncSession,
    owner: NonFinancialReadOwner,
    limit: int,
    cursor: str | None,
    force_refresh: bool,
    max_age_minutes: int,
) -> MyPlusTopOut:
    me, top, meta, next_cursor = await get_my_plus_top(
        db,
        global_id=int(owner.global_id),
        limit=int(limit),
        cursor=cursor,
        force_refresh=bool(force_refresh),
        max_age_minutes=int(max_age_minutes),
    )
    me_out = (
        _rank_item_from_service(me)
        if me is not None
        else RankItemOut(
            global_id=f"{int(owner.global_id):010d}",
            username=None,
            total_generated_kwh="0.00000000",
            rank_pos=0,
            is_vip=False,
        )
    )
    return MyPlusTopOut(
        snapshot_at=meta.snapshot_at.astimezone(UTC).isoformat(),
        me=me_out,
        top=[_rank_item_from_service(item) for item in top],
        next_cursor=next_cursor,
    )


async def _kwh_top_payload(
    *,
    db: AsyncSession,
    limit: int,
    cursor: str | None,
    exclude_global_id: int | None,
    around_me: bool,
    force_refresh: bool,
    max_age_minutes: int,
) -> TopPageOut:
    if around_me and exclude_global_id is not None:
        items, meta = await get_user_rank_context(
            db,
            global_id=int(exclude_global_id),
            radius=2,
            force_refresh=bool(force_refresh),
            max_age_minutes=int(max_age_minutes),
        )
        next_cursor = None
    else:
        items, meta, next_cursor = await list_top_page(
            db,
            limit=int(limit),
            cursor=cursor,
            force_refresh=bool(force_refresh),
            max_age_minutes=int(max_age_minutes),
            global_read=True,
        )
        if exclude_global_id is not None:
            items = [
                item
                for item in items
                if int(item.global_id) != int(exclude_global_id)
            ]
    return TopPageOut(
        snapshot_at=meta.snapshot_at.astimezone(UTC).isoformat(),
        items=[_rank_item_from_service(item) for item in items],
        next_cursor=next_cursor,
    )


def _referral_rank_out(row: Any) -> RankItemOut:
    return RankItemOut(
        global_id=f"{int(row.global_id):010d}",
        username=row.username,
        total_generated_kwh="0.00000000",
        rank_pos=int(row.rank_pos),
        is_vip=bool(row.is_vip),
        active_referrals=int(row.active_referrals or 0),
    )


async def _referral_rows(
    db: AsyncSession,
    *,
    limit: int,
    after_pos: int = 0,
    owner_global_id: int | None = None,
) -> list[Any]:
    sql = text(
        """
        WITH ranked AS (
          SELECT
            u.global_id,
            u.username,
            COALESCE(u.is_vip, FALSE) AS is_vip,
            COUNT(rl.invitee_global_id) FILTER (
              WHERE rl.activated_at IS NOT NULL
            ) AS active_referrals,
            ROW_NUMBER() OVER (
              ORDER BY COUNT(rl.invitee_global_id) FILTER (
                WHERE rl.activated_at IS NOT NULL
              ) DESC, u.global_id ASC
            ) AS rank_pos
          FROM efhc_core.users u
          LEFT JOIN efhc_core.referral_links rl
            ON rl.inviter_global_id = u.global_id
          WHERE COALESCE(u.is_active, TRUE) = TRUE
            AND u.global_id IS NOT NULL
          GROUP BY u.global_id, u.username, u.is_vip
        )
        SELECT * FROM ranked
        WHERE rank_pos > :after_pos
          AND (
            :owner_global_id IS NULL
            OR global_id = :owner_global_id
            OR rank_pos <= :limit
          )
        ORDER BY rank_pos ASC, global_id ASC
        LIMIT :query_limit
        """
    )
    query_limit = int(limit) + (1 if owner_global_id is not None else 0)
    result = await db.execute(
        sql,
        {
            "after_pos": int(after_pos),
            "owner_global_id": owner_global_id,
            "limit": int(limit),
            "query_limit": max(1, query_limit),
        },
    )
    return list(result.fetchall())


async def _referral_my_plus_top_payload(
    *,
    db: AsyncSession,
    owner: NonFinancialReadOwner,
    limit: int,
) -> MyPlusTopOut:
    owner_global_id = int(owner.global_id)
    page_limit = max(1, int(limit))
    rows = await _referral_rows(
        db,
        limit=page_limit + 2,
    )
    me_rows = await _referral_context_rows(
        db,
        owner_global_id=owner_global_id,
        radius=0,
    )
    me_row = me_rows[0] if me_rows else None
    filtered_rows = [
        row for row in rows if int(row.global_id) != owner_global_id
    ]
    has_more = len(filtered_rows) > page_limit
    top_rows = filtered_rows[:page_limit]
    me = (
        _referral_rank_out(me_row)
        if me_row is not None
        else RankItemOut(
            global_id=f"{owner_global_id:010d}",
            username=None,
            total_generated_kwh="0.00000000",
            rank_pos=0,
            is_vip=False,
            active_referrals=0,
        )
    )
    next_cursor = (
        str(top_rows[-1].rank_pos) if has_more and top_rows else None
    )
    return MyPlusTopOut(
        snapshot_at=datetime.now(tz=UTC).isoformat(),
        me=me,
        top=[_referral_rank_out(row) for row in top_rows],
        next_cursor=next_cursor,
    )


async def _referral_context_rows(
    db: AsyncSession,
    *,
    owner_global_id: int,
    radius: int = 2,
) -> list[Any]:
    sql = text(
        """
        WITH ranked AS (
          SELECT
            u.global_id,
            u.username,
            COALESCE(u.is_vip, FALSE) AS is_vip,
            COUNT(rl.invitee_global_id) FILTER (
              WHERE rl.activated_at IS NOT NULL
            ) AS active_referrals,
            ROW_NUMBER() OVER (
              ORDER BY COUNT(rl.invitee_global_id) FILTER (
                WHERE rl.activated_at IS NOT NULL
              ) DESC, u.global_id ASC
            ) AS rank_pos
          FROM efhc_core.users u
          LEFT JOIN efhc_core.referral_links rl
            ON rl.inviter_global_id = u.global_id
          WHERE COALESCE(u.is_active, TRUE) = TRUE
            AND u.global_id IS NOT NULL
          GROUP BY u.global_id, u.username, u.is_vip
        ),
        owner_rank AS (
          SELECT rank_pos FROM ranked
          WHERE global_id = :owner_global_id
        )
        SELECT * FROM ranked
        WHERE rank_pos BETWEEN
          GREATEST((SELECT rank_pos FROM owner_rank) - :radius, 1)
          AND (SELECT rank_pos FROM owner_rank) + :radius
        ORDER BY rank_pos ASC, global_id ASC
        """
    )
    result = await db.execute(
        sql,
        {
            "owner_global_id": int(owner_global_id),
            "radius": max(0, min(int(radius), 20)),
        },
    )
    return list(result.fetchall())


async def _referral_top_payload(
    *,
    db: AsyncSession,
    limit: int,
    cursor: str | None,
    exclude_global_id: int | None,
    around_me: bool,
) -> TopPageOut:
    if around_me and exclude_global_id is not None:
        rows = await _referral_context_rows(
            db,
            owner_global_id=int(exclude_global_id),
        )
        next_cursor = None
    else:
        page_limit = max(1, int(limit))
        after_pos = int(cursor) if cursor and str(cursor).isdigit() else 0
        rows = await _referral_rows(
            db,
            limit=page_limit + 2,
            after_pos=after_pos,
        )
        if exclude_global_id is not None:
            rows = [
                row
                for row in rows
                if int(row.global_id) != int(exclude_global_id)
            ]
        has_more = len(rows) > page_limit
        rows = rows[:page_limit]
        next_cursor = (
            str(rows[-1].rank_pos) if has_more and rows else None
        )
    return TopPageOut(
        snapshot_at=datetime.now(tz=UTC).isoformat(),
        items=[_referral_rank_out(row) for row in rows],
        next_cursor=next_cursor,
    )


def _etag_or_304(
    *,
    response: Response,
    if_none_match: str | None,
    payload: BaseModel,
    scope: str,
) -> None:
    raw = payload.model_dump()
    raw["scope"] = scope
    etag = _build_etag(raw)
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )
    response.headers["ETag"] = etag


@router.get("/my-plus-top/me", response_model=MyPlusTopOut)
async def get_my_kwh_rank_me(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> MyPlusTopOut:
    out = await _kwh_my_plus_top_payload(
        db=db,
        owner=owner,
        limit=limit,
        cursor=cursor,
        force_refresh=force_refresh,
        max_age_minutes=max_age_minutes,
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_kwh_me",
    )
    return out


@router.get("/top/me", response_model=TopPageOut)
async def get_kwh_top_me(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    around_me: bool = False,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> TopPageOut:
    out = await _kwh_top_payload(
        db=db,
        limit=limit,
        cursor=cursor,
        exclude_global_id=int(owner.global_id),
        around_me=around_me,
        force_refresh=force_refresh,
        max_age_minutes=max_age_minutes,
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_kwh_top_me",
    )
    return out


@router.get("/referrals/my-plus-top/me", response_model=MyPlusTopOut)
async def get_my_referrals_rank_me(
    response: Response,
    limit: int = 100,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> MyPlusTopOut:
    out = await _referral_my_plus_top_payload(
        db=db,
        owner=owner,
        limit=limit,
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_referrals_me",
    )
    return out


@router.get("/referrals/top/me", response_model=TopPageOut)
async def get_referrals_top_me(
    response: Response,
    limit: int = 100,
    cursor: str | None = None,
    around_me: bool = False,
    if_none_match: str | None = Header(None, convert_underscores=True),
    owner: NonFinancialReadOwner = Depends(get_nonfinancial_read_owner),
    db: AsyncSession = Depends(get_db),
) -> TopPageOut:
    out = await _referral_top_payload(
        db=db,
        limit=limit,
        cursor=cursor,
        exclude_global_id=int(owner.global_id),
        around_me=around_me,
    )
    _etag_or_304(
        response=response,
        if_none_match=if_none_match,
        payload=out,
        scope="ranks_referrals_top_me",
    )
    return out

