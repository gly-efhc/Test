# -*- coding: utf-8 -*-
# backend/app/routes/admin_logs_routes.py
# ======================================================================
# Админские логи EFHC Bot.
#
# UI:
# - GET /admin/logs/transfers?tg_id=...&reason=...&limit=100&cursor=...
#
# Канон:
# - require_admin
# - курсорная пагинация (SSOT encode_cursor/decode_cursor)
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.utils_core import format_decimal_str
from backend.app.deps import (
    d8,
    decode_cursor_or_400,
    get_db,
    require_admin,
)
from backend.app.utils.cursor_codec import encode_cursor

S = get_settings()
SCHEMA_CORE: str = (
    getattr(S, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core"
)

router = APIRouter(prefix="/admin/logs", tags=["admin-logs"])


def _iso(dt: Any) -> str:
    if isinstance(dt, datetime):
        return dt.isoformat()
    if dt is None:
        return ""
    return str(dt)


class TransferLogItem(BaseModel):
    id: int
    tg_id: int
    amount: str
    direction: str
    balance_type: str
    reason: str
    idempotency_key: str
    meta: Optional[Any] = None
    created_at: str


class TransferLogsOut(BaseModel):
    ok: bool = True
    items: List[TransferLogItem] = Field(default_factory=list)
    next_cursor: Optional[str] = None


@router.get("/transfers", response_model=TransferLogsOut)
async def admin_logs_transfers(
    tg_id: Optional[int] = Query(default=None),
    reason: str = Query(default="", max_length=64),
    limit: int = Query(default=100, ge=1, le=200),
    cursor: Optional[str] = Query(default=None, max_length=512),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> TransferLogsOut:
    reason_s = (reason or "").strip()

    where = []
    params: Dict[str, Any] = {"limit": int(limit) + 1}

    if tg_id is not None:
        where.append("tg_id = :tg_id")
        params["tg_id"] = int(tg_id)

    if reason_s:
        where.append("reason ILIKE :reason")
        params["reason"] = f"%{reason_s}%"

    if cursor:
        payload = decode_cursor_or_400(cursor)
        c_created = payload.get("created_at")
        c_id = payload.get("id")
        if not c_created or c_id is None:
            raise HTTPException(
                status_code=400,
                detail="cursor payload missing created_at/id",
            )
        where.append("(created_at, id) < (:c_created, :c_id)")
        params["c_created"] = str(c_created)
        params["c_id"] = int(c_id)

    where_sql = " AND ".join(where) if where else "TRUE"

    sql = text(
        f"""
        SELECT
            id,
            tg_id,
            amount,
            direction,
            balance_type,
            reason,
            idempotency_key,
            meta,
            created_at
        FROM {SCHEMA_CORE}.efhc_transfers_log
        WHERE {where_sql}
        ORDER BY created_at DESC, id DESC
        LIMIT :limit
        """
    )

    r: Result = await db.execute(sql, params)
    rows = r.fetchall()

    items: List[TransferLogItem] = []
    next_cursor: Optional[str] = None

    if len(rows) > limit:
        rows = rows[:limit]
        last = rows[-1]
        next_cursor = encode_cursor(
            {
                "created_at": _iso(last.created_at),
                "id": int(last.id),
            }
        )

    for row in rows:
        items.append(
            TransferLogItem(
                id=int(row.id),
                tg_id=int(row.tg_id),
                amount=format_decimal_str(d8(row.amount)),
                direction=str(row.direction),
                balance_type=str(row.balance_type),
                reason=str(row.reason),
                idempotency_key=str(row.idempotency_key),
                meta=row.meta,
                created_at=_iso(row.created_at),
            )
        )

    return TransferLogsOut(
        ok=True,
        items=items,
        next_cursor=next_cursor,
    )
