# backend/app/routes/admin_logs_routes.py
# ======================================================================
# Админские логи EFHC Bot.
#
# UI:
# - GET /admin/logs/transfers?tg_id=...&reason=...&limit=100&cursor=...
#
# Канон:
# - require_admin
# - курсорная пагинация (SSOT encode_cursor/decode_cursor)
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any

from app.core.utils_core import format_decimal_str
from app.deps import d8, decode_cursor_or_400, get_db, require_admin
from app.models.transactions_models import EfhcTransferLog
from app.utils.cursor_codec import encode_cursor
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import and_, desc, literal, select, tuple_
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/admin/logs", tags=["admin:logs"])


def _iso(dt: Any) -> str:
    if isinstance(dt, datetime):
        return dt.isoformat()
    if dt is None:
        return ""
    return str(dt)


def _parse_iso_dt(value: str) -> datetime:
    # decode_cursor хранит dt как isoformat().
    # Вариант с "Z" допускаем.
    s = (value or "").strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(s)
    except ValueError as err:
        raise HTTPException(
            status_code=400,
            detail="cursor created_at invalid",
        ) from err


class TransferLogItem(BaseModel):
    id: int
    tg_id: int
    amount: str
    direction: str
    balance_type: str
    reason: str
    idempotency_key: str
    meta: Any | None = None
    created_at: str


class TransferLogsOut(BaseModel):
    ok: bool = True
    items: list[TransferLogItem] = Field(default_factory=list)
    next_cursor: str | None = None


@router.get("/transfers", response_model=TransferLogsOut)
async def admin_logs_transfers(
    tg_id: int | None = Query(default=None),
    reason: str = Query(default="", max_length=64),
    limit: int = Query(default=100, ge=1, le=200),
    cursor: str | None = Query(default=None, max_length=512),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> TransferLogsOut:
    reason_s = (reason or "").strip()

    params_limit = int(limit) + 1

    filters = []

    if tg_id is not None:
        filters.append(EfhcTransferLog.tg_id == int(tg_id))

    if reason_s:
        filters.append(EfhcTransferLog.reason.ilike(f"%{reason_s}%"))

    if cursor:
        payload = decode_cursor_or_400(cursor)
        c_created = payload.get("created_at")
        c_id = payload.get("id")
        if not c_created or c_id is None:
            raise HTTPException(
                status_code=400,
                detail="cursor payload missing created_at/id",
            )
        dt = _parse_iso_dt(str(c_created))
        filters.append(
            tuple_(EfhcTransferLog.created_at, EfhcTransferLog.id)
            < tuple_(literal(dt), literal(int(c_id)))
        )

    stmt = select(
        EfhcTransferLog.id,
        EfhcTransferLog.tg_id,
        EfhcTransferLog.amount,
        EfhcTransferLog.direction,
        EfhcTransferLog.balance_type,
        EfhcTransferLog.reason,
        EfhcTransferLog.idempotency_key,
        EfhcTransferLog.meta,
        EfhcTransferLog.created_at,
    ).order_by(
        desc(EfhcTransferLog.created_at),
        desc(EfhcTransferLog.id),
    ).limit(params_limit)

    if filters:
        stmt = stmt.where(and_(*filters))

    r = await db.execute(stmt)
    rows = r.all()

    items: list[TransferLogItem] = []
    next_cursor: str | None = None

    if len(rows) > limit:
        rows = rows[:limit]
        last = rows[-1]
        next_cursor = encode_cursor(
            {
                "created_at": _iso(last.created_at),
                "id": int(last.id),
            }
        )

    for row in rows:
        items.append(
            TransferLogItem(
                id=int(row.id),
                tg_id=int(row.tg_id),
                amount=format_decimal_str(d8(row.amount)),
                direction=str(row.direction),
                balance_type=str(row.balance_type),
                reason=str(row.reason),
                idempotency_key=str(row.idempotency_key),
                meta=row.meta,
                created_at=_iso(row.created_at),
            )
        )

    return TransferLogsOut(
        ok=True,
        items=items,
        next_cursor=next_cursor,
    )
