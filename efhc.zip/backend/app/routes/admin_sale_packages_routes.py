# backend/app/routes/admin_sale_packages_routes.py
# =====================================================================
# Admin API: EFHC sale packages (pricing для deposit_efhc).
# =====================================================================

from __future__ import annotations

from app.core.logging_core import get_logger
from app.deps import get_db, require_admin, require_idempotency_key
from app.schemas.admin_sale_packages_schemas import (
    AdminSalePackageIn,
    AdminSalePackageOut,
    AdminSalePackagesOut,
)
from app.services.admin.admin_sale_packages_service import (
    list_packages,
)
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)

router = APIRouter(
    prefix="/admin/sale-packages",
    tags=["admin:sale-packages"],
)


@router.get("/", response_model=AdminSalePackagesOut)
async def admin_list_sale_packages(
    db: AsyncSession = Depends(get_db),
    _auth=Depends(require_admin),
) -> AdminSalePackagesOut:
    items = await list_packages(db)
    return AdminSalePackagesOut(items=items)


@router.post(
    "/",
    response_model=AdminSalePackageOut,
    status_code=status.HTTP_200_OK,
)
async def admin_create_sale_package(
    request: Request,
    payload: AdminSalePackageIn,
    _auth=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
    idk: str = Depends(require_idempotency_key),
) -> AdminSalePackageOut:
    raise HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail=(
            "sale-packages is an internal draft surface and "
            "is not writable in the release contour"
        ),
    )


@router.post(
    "/{package_id}/toggle",
    response_model=AdminSalePackageOut,
)
async def admin_toggle_sale_package(
    package_id: int,
    _auth=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
    idk: str = Depends(require_idempotency_key),
) -> AdminSalePackageOut:
    raise HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail=(
            "sale-packages is an internal draft surface and "
            "toggle is disabled in the release contour"
        ),
    )


@router.put(
    "/{package_id}",
    response_model=AdminSalePackageOut,
)
async def admin_update_sale_package(
    package_id: int,
    payload: AdminSalePackageIn,
    _auth=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
    idk: str = Depends(require_idempotency_key),
) -> AdminSalePackageOut:
    raise HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail=(
            "sale-packages is an internal draft surface and "
            "update is disabled in the release contour"
        ),
    )
