"""Provider-neutral session endpoints цикла 1618."""

from __future__ import annotations

from typing import Annotated

from app.identity.auth_context import AuthContext, AuthContextResponse
from app.identity.auth_dependencies import (
    get_auth_session_service,
    require_auth_context,
    require_auth_session_token,
)
from app.identity.auth_runtime_services import AuthSessionService
from fastapi import APIRouter, Depends, HTTPException, Response, status

router = APIRouter(prefix="/auth", tags=["auth"])


@router.get(
    "/session",
    response_model=AuthContextResponse,
    summary="Получить текущий provider-neutral auth context",
)
async def get_current_auth_session(
    response: Response,
    context: Annotated[AuthContext, Depends(require_auth_context)],
) -> AuthContextResponse:
    """Вернуть безопасный context без token и provider subject."""

    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return AuthContextResponse.from_auth_context(context)


@router.post(
    "/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Отозвать текущую server-side auth session",
)
async def logout_auth_session(
    token: Annotated[str, Depends(require_auth_session_token)],
    service: Annotated[
        AuthSessionService,
        Depends(get_auth_session_service),
    ],
) -> Response:
    """Атомарно отозвать bearer token без его логирования."""

    if not await service.revoke(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Auth session недействительна",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return Response(
        status_code=status.HTTP_204_NO_CONTENT,
        headers={
            "Cache-Control": "no-store",
            "Pragma": "no-cache",
        },
    )


__all__ = [
    "get_current_auth_session",
    "logout_auth_session",
    "router",
]
