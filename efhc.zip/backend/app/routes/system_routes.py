# -*- coding: utf-8 -*-
# backend/app/routes/system_routes.py
# ======================================================================
# Назначение:
# Системные ручки (health, cron tick, telegram webhook) для EFHC Bot.
#
# Канон:
# - Serverless-safe: /cron/tick выполняет один проход и отдаёт JSON.
# - Без вечных циклов внутри HTTP (иначе serverless timeout).
# - Telegram webhook: проверяем секрет (TELEGRAM_WEBHOOK_SECRET).
# ======================================================================

from __future__ import annotations

import json
import hmac
import time
from typing import Any, Dict

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.deps import external_event_dedupe_dep, get_db
from backend.app.services.scheduler_service import SchedulerService

logger = get_logger("efhc.routes.system")
router = APIRouter(tags=["system"])


@router.get("/health")
async def health() -> Dict[str, Any]:
    """Простейшая проверка живости сервиса."""
    return {"status": "ok"}


@router.get("/health/db")
async def health_db(
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    """Проверка подключения к БД и базовых инвариантов схемы.

    Возвращает компактный статус:
    - db.ok: выполнился SELECT 1
    - schema.ok: проверка ключевых колонок withdraw_requests
    """
    out: Dict[str, Any] = {
        "ok": False,
        "db": {"ok": False},
        "schema": {"ok": False},
    }

    try:
        await db.execute(text("SELECT 1"))
        out["db"]["ok"] = True
    except Exception as exc:
        out["db"]["error"] = str(exc)
        return out

    schema = await health_db_schema(db=db)
    out["schema"] = schema
    out["ok"] = bool(out["db"]["ok"] and schema.get("ok"))
    return out


@router.get("/health/db-schema")
async def health_db_schema(
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    """Проверка соответствия схемы БД текущему канону.

    Стоп-фактор: если миграции не прогнаны до head, код может падать на
    отсутствующих колонках. Ручка даёт понятный сигнал DevOps.

    Проверяем минимум: {DB_SCHEMA_CORE}.withdraw_requests содержит набор
    колонок для холда/рефанда.
    """
    schema = getattr(get_settings(), "DB_SCHEMA_CORE", "efhc_core")
    required_cols = {
        "id",
        "tg_id",
        "amount",
        "status",
        "idempotency_key",
        "hold_done",
        "refund_done",
        "payout_ref",
        "created_at",
        "updated_at",
    }

    q = text(
        "\n".join(
            [
                "SELECT column_name",
                "FROM information_schema.columns",
                "WHERE table_schema = :schema",
                "  AND table_name = 'withdraw_requests'",
            ]
        )
    )
    r = await db.execute(q, {"schema": schema})
    cols = {str(x[0]) for x in r.fetchall()}
    missing = sorted(required_cols - cols)

    if missing:
        return {
            "ok": False,
            "status": "schema_mismatch",
            "schema": schema,
            "table": f"{schema}.withdraw_requests",
            "missing": missing,
            "hint": "Run migrations: alembic upgrade head",
        }

    return {"ok": True, "status": "ok", "schema": schema}


@router.get("/cron/tick")
async def cron_tick(
    x_cron_secret: str | None = Header(
        default=None,
        alias="X-Cron-Secret",
    ),
) -> Dict[str, Any]:
    """Один проход планировщика (serverless-режим).

    Рекомендуется дергать внешним Cron (например, GitHub Actions) каждые
    5 минут.

    Безопасность:
    - если задан CRON_SECRET, требуем совпадение с заголовком
      X-Cron-Secret.
    """
    s = get_settings()
    if s.CRON_SECRET:
        token = x_cron_secret or ""
        if not hmac.compare_digest(token, str(s.CRON_SECRET)):
            raise HTTPException(
                status_code=401,
                detail="Invalid cron secret",
            )

    t0 = time.perf_counter()
    sched = SchedulerService()
    sched.register_defaults()
    stats = await sched.run_single_tick()
    stats["total_wall_ms"] = round(
        (time.perf_counter() - t0) * 1000.0,
        2,
    )
    return stats


@router.post("/tg/webhook")
async def telegram_webhook(
    request: Request,
    x_telegram_bot_api_secret_token: str | None = Header(
        default=None,
        alias="X-Telegram-Bot-Api-Secret-Token",
    ),
    ext: Dict[str, Any] = Depends(
        external_event_dedupe_dep("telegram"),
    ),
) -> Dict[str, Any]:
    """Единая ручка Telegram Webhook.

    Канон:
    - вебхук попадает в aiogram.Dispatcher, а не в "ручной парсер".

    Безопасность:
    - сравниваем секрет из заголовка с TELEGRAM_WEBHOOK_SECRET.
    """
    s = get_settings()
    if s.TELEGRAM_WEBHOOK_SECRET:
        token = x_telegram_bot_api_secret_token or ""
        if not hmac.compare_digest(
            token,
            str(s.TELEGRAM_WEBHOOK_SECRET),
        ):
            raise HTTPException(
                status_code=401,
                detail="Invalid telegram webhook secret",
            )

    if ext.get("is_duplicate"):
        return {"status": "ok", "dedupe": True}

    raw = getattr(request.state, "_raw_body", None)
    payload = (
        json.loads(raw.decode("utf-8"))
        if raw
        else await request.json()
    )

    from backend.app.bot.bot import get_dispatcher

    dp = get_dispatcher()
    await dp.feed_raw_update(
        bot=dp.bot,
        update=payload,
    )  # type: ignore[attr-defined]
    return {"status": "ok"}


__all__ = ["router"]
