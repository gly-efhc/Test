# -*- coding: utf-8 -*-
# backend/app/routes/admin_withdrawals_routes.py
# ======================================================================
# EFHC Bot — Admin: withdrawals.
# - Внешняя идентификация: только tg_id.
# - Финансовая модерация требует Idempotency-Key.
# - Роуты тонкие, логика в сервисах.
# ======================================================================

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.deps import (
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from backend.app.services.admin.admin_rbac import AdminUser
from backend.app.services.admin.admin_logging import AdminLogger
from backend.app.services.admin.admin_withdrawals_service import (
    WithdrawalApproveRequest,
    WithdrawalFilters,
    WithdrawalRecord,
    WithdrawalsService,
)

router = APIRouter(
    prefix="/admin/withdrawals",
    tags=["admin:withdrawals"],
)


def _fallback_admin(auth: Any) -> AdminUser:
    """Преобразовать AuthContext в AdminUser.

    В ранних окружениях таблица RBAC может отсутствовать.
    Для MVP допускаем
    упрощённого админа: tg_id из require_admin, роль SuperAdmin.
    """
    return AdminUser(
        id=0,
        tg_id=int(getattr(auth, "tg_id", 0) or 0),
        role="SuperAdmin",
        is_active=True,
    )


class RejectIn(BaseModel):
    reason: str = Field(..., min_length=1, max_length=500)


@router.get("", response_model=list[WithdrawalRecord])
async def admin_list_withdrawals(
    status_filter: Optional[str] = Query(
        default=None,
        alias="status",
    ),
    vip_only: bool = Query(default=False),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[WithdrawalRecord]:
    filters = WithdrawalFilters(
        status=(status_filter or None),
        vip_only=bool(vip_only),
        limit=int(limit),
        offset=int(offset),
    )
    try:
        return await WithdrawalsService.list_withdrawals(
            db,
            filters=filters,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"withdrawals list failed: {exc}",
        ) from exc


@router.post("/{request_id}/approve")
async def admin_approve(
    request_id: int,
    payload: Optional[dict] = None,
    db: AsyncSession = Depends(get_db),
    auth: Any = Depends(require_admin),
    idempotency_key: str = Depends(
        require_idempotency_key_header_only,
    ),
) -> dict:
    """Провести заявку на вывод.

    В этом сервисе статус становится PAID.
    """
    admin = _fallback_admin(auth)
    try:
        req = WithdrawalApproveRequest(
            tx_hash=(payload or {}).get("tx_hash"),
            idempotency_key=str(idempotency_key),
        )
        out = await WithdrawalsService.approve_withdrawal(
            db,
            withdrawal_id=int(request_id),
            req=req,
            admin=admin,
        )
        return {"ok": True, "result": out}
    except Exception as exc:
        await AdminLogger.write(
            db,
            admin_id=int(admin.tg_id),
            action="WITHDRAW_APPROVE_ATTEMPT_FAIL",
            entity="withdraw_request",
            entity_id=int(request_id),
            details=str(exc),
        )
        raise HTTPException(
            status_code=500,
            detail=f"approve failed: {exc}",
        ) from exc


@router.post("/{request_id}/reject")
async def admin_reject(
    request_id: int,
    payload: RejectIn,
    db: AsyncSession = Depends(get_db),
    auth: Any = Depends(require_admin),
    idempotency_key: str = Depends(
        require_idempotency_key_header_only,
    ),
) -> dict:
    """Отклонить заявку (рефанд делает сервис)."""
    admin = _fallback_admin(auth)
    try:
        out = await WithdrawalsService.reject_withdrawal(
            db,
            withdrawal_id=int(request_id),
            reason=str(payload.reason),
            idempotency_key=str(idempotency_key),
            admin=admin,
        )
        return {"ok": True, "result": out}
    except Exception as exc:
        await AdminLogger.write(
            db,
            admin_id=int(admin.tg_id),
            action="WITHDRAW_REJECT_ATTEMPT_FAIL",
            entity="withdraw_request",
            entity_id=int(request_id),
            details=str(exc),
        )
        raise HTTPException(
            status_code=500,
            detail=f"reject failed: {exc}",
        ) from exc


__all__ = ["router"]
