# backend/app/routes/admin_withdrawals_routes.py
# ======================================================================
# EFHC Bot — Admin: withdrawals.
# - Внешняя идентификация: только global_id.
# - Финансовая модерация требует Idempotency-Key.
# - Роуты тонкие, логика в сервисах.
# ======================================================================

from __future__ import annotations

from typing import Any

from app.deps import (
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from app.identity.api_contract import ApiExternalGlobalId
from app.schemas.outcome_schemas import (
    OutcomeCommentSchema,
    OutcomePromoSchema,
    WithdrawOutcomeBundleSchema,
    WithdrawOutcomePreviewSchema,
)
from app.services.admin.admin_logging import AdminLogger
from app.services.admin.admin_rbac import AdminUser
from app.services.admin.admin_withdrawals_service import (
    WithdrawalApproveRequest,
    WithdrawalFilters,
    WithdrawalRecord,
    WithdrawalsService,
)
from app.services.common_errors import EfhcConflictError
from app.services.outcome_service import (
    get_admin_withdraw_outcome_preview,
)
from app.services.withdraw_service import ensure_consistency
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(
    prefix="/admin/withdrawals",
    tags=["admin:withdrawals"],
)


def _admin_from_context(auth: Any) -> AdminUser:
    """Преобразовать проверенный admin context без повышения роли."""

    return AdminUser(
        id=int(auth.admin_id),
        global_id=int(auth.global_id),
        tg_id=None,
        role=str(auth.role),
        is_active=True,
    )


class RejectIn(BaseModel):
    reason: str = Field(..., min_length=1, max_length=500)
    comment_override: str | None = Field(default=None, max_length=1500)
    comment_auto_translated: bool = False


class WithdrawRepairOut(BaseModel):
    ok: bool
    auto_fixed_hold: int
    auto_fixed_refund: int


@router.post("/repair-consistency", response_model=WithdrawRepairOut)
async def admin_repair_consistency(
    scan_minutes: int = Query(default=240, ge=1, le=1440),
    batch_limit: int = Query(default=200, ge=1, le=1000),
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
    _idempotency_key: str = Depends(
        require_idempotency_key_header_only,
    ),
) -> WithdrawRepairOut:
    stats = await ensure_consistency(
        db,
        scan_minutes=int(scan_minutes),
        batch_limit=int(batch_limit),
    )
    return WithdrawRepairOut(
        ok=True,
        auto_fixed_hold=int(stats.get("auto_fixed_hold", 0) or 0),
        auto_fixed_refund=int(stats.get("auto_fixed_refund", 0) or 0),
    )


@router.get("", response_model=list[WithdrawalRecord])
async def admin_list_withdrawals(
    global_id: ApiExternalGlobalId | None = Query(default=None),
    status_filter: str | None = Query(
        default=None,
        alias="status",
    ),
    vip_only: bool = Query(default=False),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> list[WithdrawalRecord]:
    filters = WithdrawalFilters(
        global_id=global_id,
        status=(status_filter or None),
        vip_only=bool(vip_only),
        limit=int(limit),
        offset=int(offset),
    )
    try:
        rows = await WithdrawalsService.list_withdrawals(
            db,
            filters=filters,
        )
        return list(rows)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"withdrawals list failed: {exc}",
        ) from exc


@router.post("/{request_id}/approve")
async def admin_approve(
    request_id: int,
    payload: dict | None = None,
    db: AsyncSession = Depends(get_db),
    auth: Any = Depends(require_admin),
    idempotency_key: str = Depends(
        require_idempotency_key_header_only,
    ),
) -> dict:
    """Провести заявку на вывод.

    В этом сервисе статус становится PAID.
    """
    admin = _admin_from_context(auth)
    try:
        raw = payload or {}
        req = WithdrawalApproveRequest(
            tx_hash=raw.get("tx_hash"),
            payout_ref=raw.get("payout_ref"),
            wallet_send_confirmed=bool(
                raw.get("wallet_send_confirmed", False)
            ),
            wallet_provider=raw.get("wallet_provider"),
            sender_wallet_address=raw.get("sender_wallet_address"),
            comment_override=raw.get("comment_override"),
            comment_auto_translated=bool(
                raw.get("comment_auto_translated", False)
            ),
            idempotency_key=str(idempotency_key),
        )
        out = await WithdrawalsService.approve_withdrawal(
            db,
            withdrawal_id=int(request_id),
            req=req,
            admin=admin,
        )
        return {"ok": True, "result": out}
    except EfhcConflictError as exc:
        raise HTTPException(
            status_code=409,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        await AdminLogger.write(
            db,
            actor_global_id=admin.global_id,
            admin_id=admin.id,
            action="WITHDRAW_APPROVE_ATTEMPT_FAIL",
            entity="withdraw_request",
            entity_id=int(request_id),
            details=str(exc),
        )
        raise HTTPException(
            status_code=500,
            detail=f"approve failed: {exc}",
        ) from exc


@router.post("/{request_id}/reject")
async def admin_reject(
    request_id: int,
    payload: RejectIn,
    db: AsyncSession = Depends(get_db),
    auth: Any = Depends(require_admin),
    idempotency_key: str = Depends(
        require_idempotency_key_header_only,
    ),
) -> dict:
    """Отклонить заявку (рефанд делает сервис)."""
    admin = _admin_from_context(auth)
    try:
        out = await WithdrawalsService.reject_withdrawal(
            db,
            withdrawal_id=int(request_id),
            reason=str(payload.reason),
            idempotency_key=str(idempotency_key),
            admin=admin,
            comment_override=payload.comment_override,
            comment_auto_translated=bool(
                payload.comment_auto_translated
            ),
        )
        return {"ok": True, "result": out}
    except EfhcConflictError as exc:
        raise HTTPException(
            status_code=409,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        await AdminLogger.write(
            db,
            actor_global_id=admin.global_id,
            admin_id=admin.id,
            action="WITHDRAW_REJECT_ATTEMPT_FAIL",
            entity="withdraw_request",
            entity_id=int(request_id),
            details=str(exc),
        )
        raise HTTPException(
            status_code=500,
            detail=f"reject failed: {exc}",
        ) from exc


@router.get(
    "/{request_id}/outcome-preview",
    response_model=WithdrawOutcomePreviewSchema,
)
async def admin_withdraw_outcome_preview(
    request_id: int,
    mode: str = Query(default="auto"),
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> WithdrawOutcomePreviewSchema:
    preview = await get_admin_withdraw_outcome_preview(
        db,
        request_id=int(request_id),
        mode=str(mode or "auto"),
    )
    bundle = preview.bundle
    promo = bundle.promo
    return WithdrawOutcomePreviewSchema(
        request_id=int(preview.request_id),
        withdrawal_status=str(preview.withdrawal_status),
        preview_mode=str(preview.preview_mode),
        bundle=WithdrawOutcomeBundleSchema(
            request_id=int(bundle.request_id),
            global_id=f"{int(bundle.global_id):010d}",
            outcome_kind=str(bundle.outcome_kind),
            locale=str(bundle.locale),
            comment=OutcomeCommentSchema(
                text=str(bundle.comment.text),
                template_key=bundle.comment.template_key,
                source=str(bundle.comment.source),
                locale=str(bundle.comment.locale),
                manual_override_used=bool(
                    bundle.comment.manual_override_used
                ),
                auto_translated=bool(bundle.comment.auto_translated),
            ),
            promo=(
                OutcomePromoSchema(
                    enabled=bool(promo.enabled),
                    key=promo.key,
                    title=promo.title,
                    body=promo.body,
                    cta_label=promo.cta_label,
                    cta_url=promo.cta_url,
                    source=promo.source,
                )
                if promo is not None
                else None
            ),
            top_zone_enabled=bool(bundle.top_zone_enabled),
            metadata=dict(bundle.metadata or {}),
        ),
    )


__all__ = ["router"]
