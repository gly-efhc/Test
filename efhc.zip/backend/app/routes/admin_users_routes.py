# backend/app/routes/admin_users_routes.py
# ======================================================================
# Админские HTTP-ручки «Пользователи» EFHC Bot.
#
# Назначение:
# - поиск пользователей по tg_id (prefix search) для админ-панели;
# - просмотр карточки пользователя;
# - безопасные админ-действия (VIP/активность/сброс TON-кошелька).
#
# Канон:
# - только tg_id;
# - require_admin для всех ручек;
# - Idempotency-Key для любых изменений;
# - запись действия в admin_logs.
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any

from app.core.config_core import get_settings
from app.core.sql_aliases_core import canon_schema
from app.core.utils_core import format_decimal_str
from app.deps import d8, get_db, require_admin
from app.services import wallets_service
from app.services.admin.admin_logging import AdminLogger
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Query,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

S = get_settings()
SCHEMA_CORE: str = canon_schema(
    getattr(S, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core",
)

router = APIRouter(prefix="/admin/users", tags=["admin:users"])


def _iso(dt: Any) -> str | None:
    if dt is None:
        return None
    if isinstance(dt, str):
        return dt
    if isinstance(dt, datetime):
        return dt.isoformat()
    return str(dt)


class UserItem(BaseModel):
    tg_id: int = Field(..., description="tg_id пользователя")
    username: str | None = None
    is_active: bool
    is_vip: bool
    ton_wallet: str | None = None
    main_balance: str
    bonus_balance: str
    available_kwh: str
    total_generated_kwh: str
    last_seen_at: str | None = None


class UserDetail(UserItem):
    created_at: str
    updated_at: str
    vip_checked_at: str | None = None
    vip_since: str | None = None
    last_sync_at: str | None = None


class _PatchVipIn(BaseModel):
    is_vip: bool


class _PatchActiveIn(BaseModel):
    is_active: bool


def _require_idempotency(idem: str | None) -> str:
    k = (idem or "").strip()
    if not k:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key header is required",
        )
    return k


@router.get("/search", response_model=list[UserItem])
async def admin_users_search(
    q: str = Query("", max_length=64),
    limit: int = Query(50, ge=1, le=100),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> list[UserItem]:
    prefix = q.strip()
    is_empty = prefix == ""

    sql = text("""
        SELECT
            tg_id,
            username,
            COALESCE(is_active, TRUE)  AS is_active,
            COALESCE(is_vip, FALSE)    AS is_vip,
            ton_wallet,
            COALESCE(main_balance, 0)  AS main_balance,
            COALESCE(bonus_balance, 0) AS bonus_balance,
            COALESCE(available_kwh, 0) AS available_kwh,
            COALESCE(total_generated_kwh, 0) AS total_generated_kwh,
            last_seen_at
        FROM efhc_core.users
        WHERE
            :is_empty = TRUE
            OR CAST(tg_id AS TEXT) LIKE :pref
            OR COALESCE(username, '') ILIKE :username_pref
        ORDER BY id DESC
        LIMIT :limit
        """)
    r: Result = await db.execute(
        sql,
        {
            "is_empty": is_empty,
            "pref": f"{prefix}%",
            "username_pref": f"{prefix}%",
            "limit": int(limit),
        },
    )

    out: list[UserItem] = []
    for row in r.fetchall():
        out.append(
            UserItem(
                tg_id=int(row.tg_id),
                username=row.username,
                is_active=bool(row.is_active),
                is_vip=bool(row.is_vip),
                ton_wallet=row.ton_wallet,
                main_balance=format_decimal_str(d8(row.main_balance)),
                bonus_balance=format_decimal_str(d8(row.bonus_balance)),
                available_kwh=format_decimal_str(d8(row.available_kwh)),
                total_generated_kwh=format_decimal_str(
                    d8(row.total_generated_kwh)
                ),
                last_seen_at=_iso(row.last_seen_at),
            )
        )
    return out


@router.get("/{tg_id}", response_model=UserDetail)
async def admin_users_get(
    tg_id: int,
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> UserDetail:
    sql = text("""
        SELECT
            tg_id,
            username,
            COALESCE(is_active, TRUE)  AS is_active,
            COALESCE(is_vip, FALSE)    AS is_vip,
            vip_since,
            vip_checked_at,
            ton_wallet,
            COALESCE(main_balance, 0)  AS main_balance,
            COALESCE(bonus_balance, 0) AS bonus_balance,
            COALESCE(available_kwh, 0) AS available_kwh,
            COALESCE(total_generated_kwh, 0) AS total_generated_kwh,
            last_seen_at,
            last_sync_at,
            created_at,
            updated_at
        FROM efhc_core.users
        WHERE tg_id = :tg_id
        LIMIT 1
        """)
    r: Result = await db.execute(sql, {"tg_id": int(tg_id)})
    row = r.first()
    if not row:
        raise HTTPException(status_code=404, detail="user not found")

    return UserDetail(
        tg_id=int(row.tg_id),
        username=row.username,
        is_active=bool(row.is_active),
        is_vip=bool(row.is_vip),
        ton_wallet=row.ton_wallet,
        main_balance=format_decimal_str(d8(row.main_balance)),
        bonus_balance=format_decimal_str(d8(row.bonus_balance)),
        available_kwh=format_decimal_str(d8(row.available_kwh)),
        total_generated_kwh=format_decimal_str(
            d8(row.total_generated_kwh)
        ),
        last_seen_at=_iso(row.last_seen_at),
        last_sync_at=_iso(row.last_sync_at),
        created_at=_iso(row.created_at) or "",
        updated_at=_iso(row.updated_at) or "",
        vip_checked_at=_iso(row.vip_checked_at),
        vip_since=_iso(row.vip_since),
    )


@router.patch("/{tg_id}/vip", response_model=UserDetail)
async def admin_users_set_vip(
    tg_id: int,
    payload: _PatchVipIn,
    idempotency_key: str | None = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> UserDetail:
    idem = _require_idempotency(idempotency_key)
    is_vip = bool(payload.is_vip)

    sql = text("""
        UPDATE efhc_core.users
        SET
            is_vip = :is_vip,
            vip_checked_at = NOW() AT TIME ZONE 'UTC',
            vip_since = CASE
                WHEN :is_vip = TRUE THEN
                    COALESCE(vip_since, NOW() AT TIME ZONE 'UTC')
                ELSE NULL
            END,
            updated_at = NOW() AT TIME ZONE 'UTC'
        WHERE tg_id = :tg_id
        """)
    res = await db.execute(
        sql,
        {"tg_id": int(tg_id), "is_vip": is_vip},
    )
    if res.__dict__.get("rowcount") == 0:
        raise HTTPException(status_code=404, detail="user not found")

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="set_vip",
        entity="user",
        entity_id=int(tg_id),
        details=f"is_vip={is_vip}; idem={idem}",
    )

    await db.commit()

    return await admin_users_get(tg_id=tg_id, ctx=ctx, db=db)


@router.patch("/{tg_id}/active", response_model=UserDetail)
async def admin_users_set_active(
    tg_id: int,
    payload: _PatchActiveIn,
    idempotency_key: str | None = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> UserDetail:
    idem = _require_idempotency(idempotency_key)
    is_active = bool(payload.is_active)

    sql = text("""
        UPDATE efhc_core.users
        SET
            is_active = :is_active,
            updated_at = NOW() AT TIME ZONE 'UTC'
        WHERE tg_id = :tg_id
        """)
    res = await db.execute(
        sql,
        {"tg_id": int(tg_id), "is_active": is_active},
    )
    if res.__dict__.get("rowcount") == 0:
        raise HTTPException(status_code=404, detail="user not found")

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="set_active",
        entity="user",
        entity_id=int(tg_id),
        details=f"is_active={is_active}; idem={idem}",
    )
    await db.commit()

    return await admin_users_get(tg_id=tg_id, ctx=ctx, db=db)


@router.post("/{tg_id}/wallet/reset", status_code=204)
async def admin_users_reset_wallet(
    tg_id: int,
    idempotency_key: str | None = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    ctx=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    idem = _require_idempotency(idempotency_key)

    sql = text("""
        UPDATE efhc_core.users
        SET
            ton_wallet = NULL,
            updated_at = NOW() AT TIME ZONE 'UTC'
        WHERE tg_id = :tg_id
        """)
    res = await db.execute(sql, {"tg_id": int(tg_id)})
    if res.__dict__.get("rowcount") == 0:
        raise HTTPException(status_code=404, detail="user not found")

    bindings_reset = await wallets_service.admin_reset_wallet_bindings(
        db,
        tg_id=int(tg_id),
    )

    await AdminLogger.write(
        db,
        admin_id=int(getattr(ctx, "tg_id", 0) or 0),
        action="reset_wallet",
        entity="user",
        entity_id=int(tg_id),
        details=(
            "ton_wallet=NULL; "
            f"wallet_bindings_deactivated={bindings_reset}; "
            f"idem={idem}"
        ),
    )
    await db.commit()
    return None
