from __future__ import annotations

import sqlalchemy as sa
from app.core.database_core import AsyncSessionLocal
from app.core.security_core import decode_jwt_token
from app.routes.hub_routes import (
    _bot_open_url,
    _build_flow_truth,
    _get_active_intent_truth,
    _handoff_base_url,
    _telegram_sync_url,
    _wallet_sync_url,
    create_browser_shop_intent,
    create_efhc_handoff,
    get_browser_shop_bootstrap,
    get_browser_shop_catalog,
    get_browser_shop_intent_status,
)
from app.schemas.hub_schemas import (
    BrowserShopBootstrapOut,
    BrowserShopCatalogOut,
    BrowserShopCreateIntentIn,
    BrowserShopCreateIntentOut,
    BrowserShopProfileOut,
    HubEfhcHandoffOut,
)
from app.schemas.payment_intents_schemas import PaymentIntentStatusOut
from app.schemas.shop_schemas import ShopOrderViewOut
from app.schemas.wallet_schemas import WalletItemOut
from app.services import wallets_service
from app.services.outcome_service import (
    get_withdraw_outcome_bundle,
)
from app.services.payment_intents_service import (
    get_intent_status_for_user,
    list_recent_intents_for_user,
)
from app.services.shop_service import list_orders_for_user
from fastapi import APIRouter, Depends, HTTPException, status

router = APIRouter(prefix="/shopfront", tags=["shopfront"])


@router.get(
    "/profile",
    response_model=BrowserShopProfileOut,
    summary="Get external web profile by signed access key",
)
async def shopfront_profile(
    token: str,
) -> BrowserShopProfileOut:
    claims = decode_jwt_token(str(token))
    if claims.get("kind") != "hub_efhc_handoff":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff kind",
        )
    if claims.get("aud") != "efhc_buy_site":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff audience",
        )
    try:
        tg_id = int(claims.get("tg_id"))
    except Exception as err:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid handoff tg_id",
        ) from err

    async with AsyncSessionLocal() as db:
        wallets = await wallets_service.list_wallets(db, tg_id=tg_id)
        orders = await list_orders_for_user(db, tg_id=tg_id, limit=20)
        active_intent = await _get_active_intent_truth(
            db=db,
            tg_id=tg_id,
        )
        intent_history_rows = await list_recent_intents_for_user(
            db,
            tg_id=tg_id,
            limit=10,
        )
        active_payment = None
        latest_withdraw_request_id = None
        latest_withdraw_status = None
        latest_withdraw_outcome = None
        if active_intent is not None:
            row = await get_intent_status_for_user(
                db,
                tg_id=tg_id,
                intent_id=int(active_intent.intent_id),
            )
            if row.get("ok"):
                active_payment = PaymentIntentStatusOut(**row)
        latest_withdraw = (
            await db.execute(
                sa.text(
                    """
                    SELECT id, status
                    FROM efhc_core.withdraw_requests
                    WHERE tg_id = :tg_id
                      AND status IN ('PAID', 'REJECTED', 'CANCELED')
                    ORDER BY COALESCE(
                        processed_at,
                        updated_at,
                        created_at
                    ) DESC, id DESC
                    LIMIT 1
                    """
                ),
                {"tg_id": tg_id},
            )
        ).first()
        if latest_withdraw:
            latest_withdraw_request_id = int(latest_withdraw[0])
            latest_withdraw_status = str(latest_withdraw[1])
            latest_withdraw_outcome = await get_withdraw_outcome_bundle(
                db,
                request_id=latest_withdraw_request_id,
                tg_id=tg_id,
            )

    wallet_items = [WalletItemOut(**w.__dict__) for w in wallets]
    intent_history = [
        PaymentIntentStatusOut(**row) for row in intent_history_rows
    ]
    order_items = [
        ShopOrderViewOut(
            id=int(o.id),
            type=str(o.order_type or "EFHC_PACKAGE"),
            sku=str(o.sku or "UNKNOWN"),
            quantity=1,
            status=str(o.status),
            user_tg_id=int(o.tg_id),
            tx_hash=o.tx_hash,
            debited_bonus_efhc=None,
            debited__main__efhc=None,
            idempotency_key=o.idempotency_key,
            created_at=o.created_at,
            updated_at=o.updated_at,
        )
        for o in orders
    ]
    wallet_linked = any(
        bool(getattr(wallet, "is_active", False)) for wallet in wallets
    )
    flow_truth = _build_flow_truth(
        handoff_configured=bool(_handoff_base_url()),
        wallet_linked=wallet_linked,
        wallet_sync_required=not wallet_linked,
        active_intent=active_intent,
        require_handoff=False,
    )
    return BrowserShopProfileOut(
        tg_id=tg_id,
        wallets=wallet_items,
        orders=order_items,
        bot_open_url=_bot_open_url(),
        wallet_sync_url=_wallet_sync_url(),
        telegram_sync_url=_telegram_sync_url(),
        flow_truth=flow_truth,
        active_payment=active_payment,
        intent_history=intent_history,
        latest_withdraw_request_id=latest_withdraw_request_id,
        latest_withdraw_status=latest_withdraw_status,
        latest_withdraw_outcome=latest_withdraw_outcome,
    )


@router.post(
    "/access-key",
    response_model=HubEfhcHandoffOut,
    summary="Create signed access URL for external shopfront",
)
async def shopfront_access_key(
    out: HubEfhcHandoffOut = Depends(create_efhc_handoff),
) -> HubEfhcHandoffOut:
    return out


@router.get(
    "/bootstrap",
    response_model=BrowserShopBootstrapOut,
    summary="Get shopfront bootstrap state",
)
async def shopfront_bootstrap(
    token: str | None = None,
) -> BrowserShopBootstrapOut:
    return await get_browser_shop_bootstrap(token=token)


@router.get(
    "/catalog",
    response_model=BrowserShopCatalogOut,
    summary="Get shopfront catalog",
)
async def shopfront_catalog() -> BrowserShopCatalogOut:
    return await get_browser_shop_catalog()


@router.post(
    "/create-intent",
    response_model=BrowserShopCreateIntentOut,
    summary="Create external shopfront intent",
)
async def shopfront_create_intent(
    payload: BrowserShopCreateIntentIn,
) -> BrowserShopCreateIntentOut:
    return await create_browser_shop_intent(payload=payload)


@router.get(
    "/intent-status",
    response_model=PaymentIntentStatusOut,
    summary="Get external shopfront intent status",
)
async def shopfront_intent_status(
    token: str,
    intent_id: int,
) -> PaymentIntentStatusOut:
    return await get_browser_shop_intent_status(
        token=token,
        intent_id=int(intent_id),
    )
