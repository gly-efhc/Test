# backend/app/routes/referrals_routes.py
# ======================================================================
# Назначение кода:
# • Ручки «Рефералы»: витрины «Активные»/«Неактивные» + счётчики.
#
# Канон/инварианты:
# • Активный реферал — тот, кто купил хотя бы одну панель (перманентный
# статус).
# • Денежных действий здесь нет: чтение витрин + мягкая синхронизация.
# • Все числа Decimal сериализуются в строки с 8 знаками (канон).
#
# ИИ-защиты:
# • Курсорная пагинация без OFFSET (ORDER BY created_at, child_tg_id).
# • ETag/If-None-Match для снижения нагрузки и стабильности клиента.
# • sync=true — мягкая ensure_consistency() без падений, best-effort.
#
# Запреты:
# • Нет P2P, нет модификаций балансов, нет обратной конверсии.
# • Нет «ручной правки» активности: источник истины — panels (EXISTS).
# ======================================================================

from __future__ import annotations

import hashlib
import json
from datetime import UTC
from typing import Any

from app.core.logging_core import get_logger
from app.deps import d8, get_db
from app.services.referral_service import (
    ensure_consistency,
    get_counters,
    list_active_referrals,
    list_inactive_referrals,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/referrals", tags=["referrals"])

# ----------------------------------------------------------------------
# Локальный ETag-хелпер (стабильный SHA-256 по JSON)
# ----------------------------------------------------------------------


def _build_etag(payload: dict[str, Any]) -> str:
    """Строит стабильный ETag по JSON-представлению payload."""
    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

# ----------------------------------------------------------------------
# Pydantic-модели ответов (Decimal → строки)
# ----------------------------------------------------------------------


class ReferralItemOut(BaseModel):
    child_tg_id: int
    tg_id: int | None = None
    username: str | None = None
    joined_at: str = Field(..., description="ISO8601 UTC")
    is_active: bool
    total_generated_kwh: str = Field(
        ...,
        description="Decimal d8 строкой",
    )
    panels_count: int


class ReferralsPageOut(BaseModel):
    items: list[ReferralItemOut]
    next_cursor: str | None = None


class ReferralCountersOut(BaseModel):
    total: int
    active: int
    inactive: int

# ======================================================================
# GET /referrals/counters — бейджи «Всего/Активные/Неактивные»
# ======================================================================

@router.get(
    "/counters",
    response_model=ReferralCountersOut,
    summary="Счётчики: всего / активные / неактивные",
)
async def get_referral_counters(
    parent_tg_id: int,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
) -> ReferralCountersOut:
    """
    Что делает:
      • Возвращает три счётчика для бейджей на вкладках.
      • Чистое чтение; денежной логики нет.
    Вход:
      • parent_tg_id — владелец реферальной ссылки.
      • If-None-Match — поддержка 304 Not Modified.
    """
    dto = await get_counters(db, parent_tg_id=int(parent_tg_id))
    payload = {
        "scope": "referrals_counters",
        "parent_tg_id": int(parent_tg_id),
        "total": dto.total,
        "active": dto.active,
        "inactive": dto.inactive,
    }
    etag = _build_etag(payload)
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    out = ReferralCountersOut(
        total=dto.total,
        active=dto.active,
        inactive=dto.inactive,
    )
    return Response(
        content=out.model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )

# ======================================================================
# GET /referrals/active — витрина «Активные» (курсоры, ETag, sync)
# ======================================================================

@router.get(
    "/active",
    response_model=ReferralsPageOut,
    summary="Витрина «Активные рефералы» (курсоры)",
)
async def get_referrals_active(
    parent_tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
    sync: bool = True,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
) -> ReferralsPageOut:
    """
    Что делает:
      • Возвращает страницу «Активных» рефералов (купили ≥1 панель).
      • Курсорная пагинация без OFFSET по (created_at, child_tg_id).
      • Если sync=true — ensure_consistency() для parent_tg_id.
        Best-effort.
    """
    if sync:
        try:
            await ensure_consistency(db, parent_tg_id=int(parent_tg_id))
        except Exception as e:
            # не валим ручку; логируем и продолжаем
            logger.info("ensure_consistency(active) skipped: %s", e)

    page = await list_active_referrals(
        db,
        parent_tg_id=int(parent_tg_id),
        limit=int(limit),
        cursor=cursor,
    )

    payload = {
        "scope": "referrals_active",
        "parent_tg_id": int(parent_tg_id),
        "cursor": cursor or "",
        "items": [
            {
                "child_tg_id": it.child_tg_id,
                "tg_id": it.tg_id,
                "username": it.username or "",
                "joined_at": it.joined_at.astimezone(
                    UTC
                ).isoformat(),
                "is_active": bool(it.is_active),
                "total_generated_kwh": str(d8(it.total_generated_kwh)),
                "panels_count": int(it.panels_count),
            }
            for it in page.items
        ],
        "next_cursor": page.next_cursor or "",
    }
    etag = _build_etag(payload)
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    out = ReferralsPageOut(
        items=[
            ReferralItemOut(
                child_tg_id=it.child_tg_id,
                tg_id=it.tg_id,
                username=it.username,
                joined_at=it.joined_at.astimezone(
                    UTC
                ).isoformat(),
                is_active=bool(it.is_active),
                total_generated_kwh=str(d8(it.total_generated_kwh)),
                panels_count=int(it.panels_count),
            )
            for it in page.items
        ],
        next_cursor=page.next_cursor,
    )
    return Response(
        content=out.model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )

# ======================================================================
# GET /referrals/inactive — витрина «Неактивные» (курсоры, ETag, sync)
# ======================================================================

@router.get(
    "/inactive",
    response_model=ReferralsPageOut,
    summary="Витрина «Неактивные рефералы» (курсоры)",
)
async def get_referrals_inactive(
    parent_tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
    sync: bool = True,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
) -> ReferralsPageOut:
    """
    Что делает:
      • Возвращает страницу «Неактивных» (ещё не купили панель).
      • Курсорная пагинация без OFFSET по (created_at, child_tg_id).
      • Если sync=true — ensure_consistency() для parent_tg_id.
        Best-effort.
    """
    if sync:
        try:
            await ensure_consistency(db, parent_tg_id=int(parent_tg_id))
        except Exception as e:
            logger.info("ensure_consistency(inactive) skipped: %s", e)

    page = await list_inactive_referrals(
        db,
        parent_tg_id=int(parent_tg_id),
        limit=int(limit),
        cursor=cursor,
    )

    payload = {
        "scope": "referrals_inactive",
        "parent_tg_id": int(parent_tg_id),
        "cursor": cursor or "",
        "items": [
            {
                "child_tg_id": it.child_tg_id,
                "tg_id": it.tg_id,
                "username": it.username or "",
                "joined_at": it.joined_at.astimezone(
                    UTC
                ).isoformat(),
                "is_active": bool(it.is_active),
                "total_generated_kwh": str(d8(it.total_generated_kwh)),
                "panels_count": int(it.panels_count),
            }
            for it in page.items
        ],
        "next_cursor": page.next_cursor or "",
    }
    etag = _build_etag(payload)
    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    out = ReferralsPageOut(
        items=[
            ReferralItemOut(
                child_tg_id=it.child_tg_id,
                tg_id=it.tg_id,
                username=it.username,
                joined_at=it.joined_at.astimezone(
                    UTC
                ).isoformat(),
                is_active=bool(it.is_active),
                total_generated_kwh=str(d8(it.total_generated_kwh)),
                panels_count=int(it.panels_count),
            )
            for it in page.items
        ],
        next_cursor=page.next_cursor,
    )
    return Response(
        content=out.model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )

# ======================================================================
# Пояснения «для чайника»:
# • Почему два списка? Это ускоряет работу UI и упрощает начисления за
# активных.
# • Зачем курсор по (created_at, child_tg_id)? Он устойчив к вставкам и
# не страдает
# от смещений, как OFFSET; next_cursor кодирует последнюю пару значений.
# • Что делает sync=true? Перед отдачей страницы выполняется мягкая
# проверка/ремонт
# статуса активности (если есть referrals.is_active) — без падений,
# best-effort.
# • Зачем ETag? Чтобы клиент видел 304 и не перекачивал данные,
# и не перекачивать одинаковые страницы.
# ======================================================================

