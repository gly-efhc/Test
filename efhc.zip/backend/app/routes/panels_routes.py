# -*- coding: utf-8 -*-
# backend/app/routes/panels_routes.py
# =====================================================================
# Роуты панелей: summary, active, archive, buy.
# Канон:
# • Покупка панели — 100 EFHC (bonus → main).
# • Денежные POST требуют Idempotency-Key.
# • Пагинация — cursor-based, ETag поддерживается.
# • force_sync=1 может догнать генерацию (safe).
# =====================================================================

from __future__ import annotations

from app.lib.time import utcnow
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import (
    d8,
    etag,
    get_current_tg_id,
    get_db,
    require_idempotency_key,
)
from app.services import panels_service as svc
from app.services.energy_service import backfill_user

logger = get_logger(__name__)
settings = get_settings()

router = APIRouter(prefix="/panels", tags=["panels"])


class PanelItemOut(BaseModel):
    id: int
    created_at: Optional[str] = None
    expires_at: Optional[str] = None
    archived_at: Optional[str] = None
    base_gen_per_sec: str
    generated_kwh: str
    is_active: bool


class PanelsListOut(BaseModel):
    items: List[PanelItemOut]
    next_cursor: Optional[str] = Field(
        None,
        description="Курсор следующей страницы или null",
    )
    server_now_utc: str = Field(
        ...,
        description="SSOT UTC now (ISO 8601, tz-aware)",
    )


class PanelsSummaryOut(BaseModel):
    active_count: int
    total_generated_by_panels: str
    nearest_expire_at: Optional[str] = None


class PurchasePanelIn(BaseModel):
    pass


class PanelOut(BaseModel):
    id: int
    public_id: str
    activated_at: str
    expires_at: str


class BuyPanelOut(BaseModel):
    panel: PanelOut
    server_now_utc: str


@router.get(
    "/{tg_id}/summary",
    response_model=PanelsSummaryOut,
    summary="Сводка по панелям",
)
async def get_panels_summary(
    tg_id: int,
    force_sync: Optional[int] = 0,
    db: AsyncSession = Depends(get_db),
) -> PanelsSummaryOut:
    try:
        if force_sync:
            await backfill_user(db, tg_id=tg_id)

        s = await svc.panels_summary(db, tg_id=tg_id)
        total_gen = str(d8(s.total_generated_by_panels))
        return PanelsSummaryOut(
            active_count=int(s.active_count),
            total_generated_by_panels=total_gen,
            nearest_expire_at=(
                s.nearest_expire_at.isoformat()
                if s.nearest_expire_at
                else None
            ),
        )
    except Exception:
        logger.exception("panels.summary failed")
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите позже.",
        )


@router.get(
    "/{tg_id}/active",
    response_model=PanelsListOut,
    summary="Активные панели (курсорная пагинация)",
)
async def list_active_panels(
    tg_id: int,
    limit: int = 25,
    cursor: Optional[str] = None,
    force_sync: Optional[int] = 0,
    response: Optional[Response] = None,
    db: AsyncSession = Depends(get_db),
) -> PanelsListOut:
    try:
        server_now_utc = utcnow().isoformat()
        if force_sync:
            await backfill_user(db, tg_id=tg_id)

        page = await svc.list_active_panels(
            db,
            tg_id=tg_id,
            limit=limit,
            cursor=cursor,
        )
        items_out = [
            PanelItemOut(
                id=int(i["id"]),
                created_at=i.get("created_at"),
                expires_at=i.get("expires_at"),
                archived_at=i.get("archived_at"),
                base_gen_per_sec=str(i["base_gen_per_sec"]),
                generated_kwh=str(i["generated_kwh"]),
                is_active=bool(i["is_active"]),
            )
            for i in page.items
        ]
        payload = PanelsListOut(
            items=items_out,
            next_cursor=page.next_cursor,
            server_now_utc=server_now_utc,
        )

        e = etag(
            {
                "kind": "panels_active",
                "tg_id": int(tg_id),
                "ids": [int(i.id) for i in items_out],
                "next": page.next_cursor or "",
            }
        )
        if response is not None:
            response.headers["ETag"] = e
        return payload
    except Exception:
        logger.exception("panels.active failed")
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите позже.",
        )


@router.get(
    "/{tg_id}/archive",
    response_model=PanelsListOut,
    summary="Архивные панели (курсорная пагинация)",
)
async def list_archived_panels(
    tg_id: int,
    limit: int = 25,
    cursor: Optional[str] = None,
    force_sync: Optional[int] = 0,
    response: Optional[Response] = None,
    db: AsyncSession = Depends(get_db),
) -> PanelsListOut:
    try:
        server_now_utc = utcnow().isoformat()
        if force_sync:
            await backfill_user(db, tg_id=tg_id)

        page = await svc.list_archived_panels(
            db,
            tg_id=tg_id,
            limit=limit,
            cursor=cursor,
        )
        items_out = [
            PanelItemOut(
                id=int(i["id"]),
                created_at=i.get("created_at"),
                expires_at=i.get("expires_at"),
                archived_at=i.get("archived_at"),
                base_gen_per_sec=str(i["base_gen_per_sec"]),
                generated_kwh=str(i["generated_kwh"]),
                is_active=bool(i["is_active"]),
            )
            for i in page.items
        ]
        payload = PanelsListOut(
            items=items_out,
            next_cursor=page.next_cursor,
            server_now_utc=server_now_utc,
        )

        e = etag(
            {
                "kind": "panels_archived",
                "tg_id": int(tg_id),
                "ids": [int(i.id) for i in items_out],
                "next": page.next_cursor or "",
            }
        )
        if response is not None:
            response.headers["ETag"] = e
        return payload
    except Exception:
        logger.exception("panels.archive failed")
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите позже.",
        )


@router.post(
    "/buy/{tg_id}",
    response_model=BuyPanelOut,
    summary="Покупка панели (Idempotency-Key обязателен)",
)
async def buy_panel(
    tg_id: int,
    idempotency_key: str = Depends(require_idempotency_key),
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> BuyPanelOut:
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Idempotency-Key header is required by canon."
            ),
        )

    if int(tg_id) != int(current_tg_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Forbidden",
        )

    try:
        res = await svc.purchase_panel(
            db,
            tg_id=int(current_tg_id),
            qty=1,
            idempotency_key=idempotency_key.strip(),
        )
        if not res.created_panel_ids:
            raise HTTPException(
                status_code=500,
                detail="Panel creation failed",
            )
        panel_id = int(res.created_panel_ids[0])
        schema = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")
        row = await db.execute(
            text(
                f"""
                SELECT id, public_id, activated_at, expires_at
                FROM {schema}.panels
                WHERE id = :id AND tg_id = :tg_id
                """
            ),
            {"id": panel_id, "tg_id": int(current_tg_id)},
        )
        rec = row.fetchone()
        if not rec or not rec[1]:
            raise HTTPException(
                status_code=500,
                detail="Panel not found",
            )
        panel = PanelOut(
            id=int(rec[0]),
            public_id=str(rec[1]),
            activated_at=rec[2].isoformat(),
            expires_at=rec[3].isoformat(),
        )
        server_now_utc = utcnow().isoformat()
        return BuyPanelOut(panel=panel, server_now_utc=server_now_utc)
    except svc.UserInDebtError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except svc.PanelLimitExceeded as e:
        raise HTTPException(status_code=409, detail=str(e))
    except svc.IdempotencyRequiredError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except svc.PanelPurchaseError as e:
        logger.warning("panels.buy business error: %s", e)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception:
        logger.exception("panels.buy failed")
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите позже.",
        )
