# -*- coding: utf-8 -*-
"""backend/app/routes/skins_routes.py

HTTP API домена «Skins» (картинки для главной).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends

from app.deps import get_db, get_current_tg_id, require_idempotency_key
from app.schemas.skins_schemas import (
    SkinsCatalogOut,
    SkinsMyOut,
)
from app.services import skins_service

router = APIRouter(prefix="/skins", tags=["skins"])


@router.get("/catalog", response_model=SkinsCatalogOut)
async def skins_catalog():
    return {"items": skins_service.get_catalog()}


@router.get("/my", response_model=SkinsMyOut)
async def skins_my(
    tg_id: int = Depends(get_current_tg_id),
    db=Depends(get_db),
):
    return await skins_service.get_my(db, tg_id=int(tg_id))


@router.post("/buy/{skin_id}")
async def skins_buy(
    skin_id: int,
    tg_id: int = Depends(get_current_tg_id),
    idempotency_key: str = Depends(require_idempotency_key),
    db=Depends(get_db),
):
    await skins_service.buy_skin(
        db,
        tg_id=int(tg_id),
        skin_id=int(skin_id),
        idempotency_key=idempotency_key,
    )
    return {"ok": True}


@router.post("/activate/{skin_id}")
async def skins_activate(
    skin_id: int,
    tg_id: int = Depends(get_current_tg_id),
    idempotency_key: str = Depends(require_idempotency_key),
    db=Depends(get_db),
):
    # idempotency_key accepted for uniform client behavior
    await skins_service.activate_skin(
        db,
        tg_id=int(tg_id),
        skin_id=int(skin_id),
    )
    return {"ok": True}
