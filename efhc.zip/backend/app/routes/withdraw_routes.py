# backend/app/routes/withdraw_routes.py
# ======================================================================
# Пользовательские ручки заявок на вывод EFHC.
# - Денежные POST требуют Idempotency-Key.
# - Создание заявки холдирует сумму у пользователя.
#   Далее сумма уходит в Банк (через сервис).
# - Отмена делает рефанд (через сервис).
# - Список и детали: cursor + ETag/If-None-Match.
# - При открытии списка можно выполнить ensure_consistency().
# ======================================================================

from __future__ import annotations

from datetime import UTC
from decimal import Decimal, InvalidOperation
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import (
    d8,
    get_current_tg_id,
    get_db,
    require_idempotency_key,
)
from app.services.withdraw_service import (
    MIN_WITHDRAW_EFHC,
    WithdrawPageDTO,
    WithdrawRequestDTO,
    cancel_withdraw,
    ensure_consistency,
    list_user_withdraws,
    request_withdraw,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Request,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

router = APIRouter(prefix="/withdraw", tags=["withdraw"])


def _build_etag(payload: dict[str, Any]) -> str:
    import hashlib
    import json

    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class WithdrawCreateIn(BaseModel):
    amount: str = Field(
        ...,
        description="Сумма EFHC к выводу (d8 строкой)",
    )


class WithdrawOut(BaseModel):
    id: int
    tg_id: int
    amount: str
    status: str
    created_at: str
    updated_at: str


class WithdrawDetailOut(WithdrawOut):
    idempotency_key: str
    hold_done: bool
    refund_done: bool
    payout_ref: str | None = None


class WithdrawPageOut(BaseModel):
    items: list[WithdrawOut]
    next_cursor: str | None


def _parse_amount(amount: str) -> Decimal:
    try:
        return Decimal(str(d8(Decimal(amount))))
    except (InvalidOperation, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "amount must be a valid decimal string "
                "with up to 8 digits after the point."
            ),
        ) from exc


def _as_detail(dto: WithdrawRequestDTO) -> WithdrawDetailOut:
    return WithdrawDetailOut(
        id=dto.id,
        tg_id=dto.tg_id,
        amount=str(d8(dto.amount)),
        status=dto.status,
        idempotency_key=dto.idempotency_key,
        hold_done=bool(dto.hold_done),
        refund_done=bool(dto.refund_done),
        payout_ref=dto.payout_ref,
        created_at=dto.created_at,
        updated_at=dto.updated_at,
    )


@router.post(
    "/request",
    response_model=WithdrawDetailOut,
    summary="Создать заявку на вывод EFHC",
)
async def post_withdraw_request(
    request: Request,
    body: WithdrawCreateIn,
    db: AsyncSession = Depends(get_db),
    idempotency_key: str = Depends(require_idempotency_key),
    current_tg_id: int = Depends(get_current_tg_id),
) -> WithdrawDetailOut:
    from app.deps import require_wallet_connected

    await require_wallet_connected(
        request,
        db=db,
        current_tg_id=current_tg_id,
        feature="withdraw",
    )
    amt = _parse_amount(body.amount)
    if amt < MIN_WITHDRAW_EFHC:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Минимальная сумма вывода: {MIN_WITHDRAW_EFHC} "
                "EFHC"
            ),
        )

    try:
        dto = await request_withdraw(
            db,
            tg_id=int(current_tg_id),
            amount=amt,
            idempotency_key=str(idempotency_key),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("post_withdraw_request failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите позже.",
        ) from exc

    return _as_detail(dto)


@router.post(
    "/{request_id}/cancel",
    response_model=WithdrawDetailOut,
    summary="Отменить заявку",
)
async def post_withdraw_cancel(
    request_id: int,
    db: AsyncSession = Depends(get_db),
    idempotency_key: str = Depends(require_idempotency_key),
    current_tg_id: int = Depends(get_current_tg_id),
) -> WithdrawDetailOut:
    try:
        dto = await cancel_withdraw(
            db,
            request_id=int(request_id),
            tg_id=int(current_tg_id),
            idempotency_key=str(idempotency_key),
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("post_withdraw_cancel failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите позже.",
        ) from exc

    return _as_detail(dto)


@router.get(
    "/list",
    response_model=WithdrawPageOut,
    summary="Список заявок пользователя",
)
async def get_withdraw_list(
    tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
    status_filter: str | None = None,
    backfill: bool = True,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> WithdrawPageOut:
    if int(current_tg_id) <= 0:
        raise HTTPException(
            status_code=401,
            detail="Требуется аутентификация",
        )
    if int(tg_id) != int(current_tg_id):
        raise HTTPException(status_code=403, detail="Доступ запрещён")

    if backfill:
        try:
            stats = await ensure_consistency(
                db,
                scan_minutes=240,
                batch_limit=200,
            )
            fixed = (stats.get("auto_fixed_hold") or 0) or (
                stats.get("auto_fixed_refund") or 0
            )
            if fixed:
                logger.info("withdraw backfill auto-fixed: %s", stats)
        except Exception as exc:
            logger.warning("ensure_consistency skipped: %s", exc)

    try:
        page: WithdrawPageDTO = await list_user_withdraws(
            db,
            tg_id=int(current_tg_id),
            limit=int(limit),
            cursor=cursor,
            status_filter=(status_filter or None),
        )
    except Exception as exc:
        logger.error("get_withdraw_list failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка при чтении заявок.",
        ) from exc

    items = [
        WithdrawOut(
            id=i.id,
            tg_id=i.tg_id,
            amount=str(d8(i.amount)),
            status=i.status,
            created_at=i.created_at,
            updated_at=i.updated_at,
        )
        for i in page.items
    ]
    payload = {
        "scope": "withdraw_list",
        "tg_id": int(current_tg_id),
        "next_cursor": page.next_cursor or "",
        "items": [it.model_dump() for it in items],
    }
    etag = _build_etag(payload)

    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    resp = Response(
        content=WithdrawPageOut(
            items=items,
            next_cursor=page.next_cursor,
        ).model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )
    return resp  # type: ignore[return-value]


@router.get(
    "/{request_id}",
    response_model=WithdrawDetailOut,
    summary="Детали заявки",
)
async def get_withdraw_detail(
    request_id: int,
    if_none_match: str | None = Header(
        None,
        convert_underscores=True,
    ),
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> WithdrawDetailOut:
    q = text(
        "\n".join(
            [
                "SELECT",
                "  id,",
                "  tg_id,",
                "  amount,",
                "  status,",
                "  idempotency_key AS idempotency_key,",
                "  hold_done,",
                "  refund_done,",
                "  payout_ref,",
                "  created_at,",
                "  updated_at",
                f"FROM {SCHEMA}.withdraw_requests",
                "WHERE id = :rid",
                "LIMIT 1",
            ]
        )
    )
    r = await db.execute(q, {"rid": int(request_id)})
    row = r.fetchone()
    if not row:
        raise HTTPException(
            status_code=404,
            detail="Заявка не найдена.",
        )

    if int(row[1]) != int(current_tg_id):
        raise HTTPException(status_code=403, detail="Доступ запрещён")

    dto = WithdrawRequestDTO(
        id=int(row[0]),
        tg_id=int(row[1]),
        amount=d8(row[2]),
        status=str(row[3]),
        idempotency_key=str(row[4]),
        hold_done=bool(row[5]),
        refund_done=bool(row[6]),
        payout_ref=(str(row[7]) if row[7] else None),
        created_at=row[8].astimezone(UTC).isoformat(),
        updated_at=row[9].astimezone(UTC).isoformat(),
    )

    out = _as_detail(dto)
    payload = {
        "scope": "withdraw_detail",
        "id": out.id,
        "tg_id": out.tg_id,
        "amount": out.amount,
        "status": out.status,
        "idempotency_key": out.idempotency_key,
        "hold_done": bool(out.hold_done),
        "refund_done": bool(out.refund_done),
        "payout_ref": out.payout_ref or "",
        "updated_at": out.updated_at,
    }
    etag = _build_etag(payload)

    if if_none_match and if_none_match.strip() == etag:
        raise HTTPException(
            status_code=status.HTTP_304_NOT_MODIFIED,
            detail="Not Modified",
        )

    resp = Response(
        content=out.model_dump_json(),
        status_code=status.HTTP_200_OK,
        media_type="application/json",
        headers={"ETag": etag},
    )
    return resp  # type: ignore[return-value]


__all__ = ["router"]