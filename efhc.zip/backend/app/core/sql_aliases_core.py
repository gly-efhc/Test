# backend/app/core/sql_aliases_core.py
# Canonical SQL identifier aliases (transitional layer).
# line72: keep all lines <= 72 chars.

from __future__ import annotations

import re

# Only these schemas exist (canon).
SCHEMA_CORE = "efhc_core"
SCHEMA_ADMIN = "efhc_admin"

_SCHEMA_ALIASES = {
    "core": SCHEMA_CORE,
    "efhc": SCHEMA_CORE,
    "efhc-core": SCHEMA_CORE,
    "admin": SCHEMA_ADMIN,
    "efhc-admin": SCHEMA_ADMIN,
}

_IDENT_RE = re.compile(r"^[a-z][a-z0-9_]*$")

_ADMIN_TABLE_ALIASES = {
    "vip_log": "vip_status_log",
    "vip_status": "vip_status_log",
}

_ADMIN_TABLE_ALLOWED = {
    "admin_whitelist",
    "vip_status_log",
    "nft_check_cache_ton",
    "admin_audit_log",
}


def canon_schema(name: str) -> str:
    s = (name or "").strip()
    s = _SCHEMA_ALIASES.get(s, s)
    if s not in {SCHEMA_CORE, SCHEMA_ADMIN}:
        raise ValueError("schema must be efhc_core or efhc_admin")
    return s


def canon_ident(name: str) -> str:
    s = (name or "").strip()
    if not _IDENT_RE.match(s):
        raise ValueError("invalid identifier")
    return s


def canon_admin_table(name: str) -> str:
    s = canon_ident(name)
    s = _ADMIN_TABLE_ALIASES.get(s, s)
    if s not in _ADMIN_TABLE_ALLOWED:
        raise ValueError("admin table not allowed")
    return s
