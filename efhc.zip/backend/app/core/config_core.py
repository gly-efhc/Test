# backend/app/core/config_core.py
# ======================================================================
# Назначение кода:
# Центральные настройки проекта EFHC-Bot.
#
# Канон:
# • Все значения берутся из ENV (и могут быть заданы через .env файлы).
# • Настройки импортируются только через get_settings() (lru_cache).
# • В коде нет «зашитых» секретов (токен бота, DB URL и т.п.).
# ======================================================================

from __future__ import annotations

import os
import re
from decimal import Decimal
from functools import lru_cache

from app.core.env_loader import load_env_files
from pydantic import AliasChoices, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Загружаем .env файлы best-effort (ENV в окружении имеет приоритет).
load_env_files()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(
            ".env",
            ".env.local",
            ".env.neon",
            ".env.prod",
            ".env.ci",
        ),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # -----------------------------------------------------------------
    # Runtime
    # -----------------------------------------------------------------
    ENV: str = Field(default="local", description="local / prod / ci")
    LOG_LEVEL: str = Field(
        default="INFO",
        description="Уровень логирования",
    )
    APP_VERSION: str = Field(
        default="0.0.0",
        description="Версия приложения",
    )
    LOG_JSON: bool = Field(
        default=False,
        description="JSON логирование (prod)",
    )

    API_PREFIX: str = Field(
        default="/api",
        description="Префикс API роутов",
    )
    CORS_ORIGINS: list[str] = Field(
        default_factory=list,
        description="Разрешённые origins для CORS",
    )
    TRUSTED_HOSTS: list[str] = Field(
        default_factory=list,
        description="TrustedHostMiddleware allowlist",
    )
    OPENAPI_URL: str | None = Field(
        default="/openapi.json",
        description="URL OpenAPI схемы",
    )
    DOCS_URL: str | None = Field(
        default="/docs",
        description="URL Swagger UI",
    )
    REDOC_URL: str | None = Field(
        default="/redoc",
        description="URL ReDoc",
    )
    GZIP_MIN_BYTES: int = Field(
        default=500,
        ge=0,
        description="Минимальный размер для GZip",
    )


    @property
    def env_normalized(self) -> str:
        """SSOT нормализация переменной окружения ENV.

        Что делает:
        - Приводит ENV к каноническим значениям:
          local / dev / stage / prod / ci.

        Инвариант:
        - В проекте запрещено вычислять алиасы ENV «по месту».
          Любая логика опирается на это свойство.
        """
        v = (self.ENV or "local").strip().lower()
        aliases = {
            "production": "prod",
            "prod": "prod",
            "stage": "stage",
            "staging": "stage",
            "dev": "dev",
            "development": "dev",
            "local": "local",
            "ci": "ci",
            "test": "ci",
        }
        return aliases.get(v, v)

    # Serverless guard (Vercel)
    SERVERLESS: bool = Field(
        default=False,
        validation_alias=AliasChoices("SERVERLESS", "SCHED_SERVERLESS"),
        description=(
            "Если true — запрещаем вечные циклы (start()), "
            "используем /cron/tick"
        ),
    )

    # Опциональный секрет для защиты /cron/tick
    # (например, GitHub Actions)
    CRON_SECRET: str = Field(
        default="",
        validation_alias=AliasChoices(
            "CRON_SECRET",
            "SCHED_CRON_SECRET",
        ),
        description=(
            "Если задан — требуем совпадение с заголовком "
            "X-Cron-Secret"
        ),
    )

    # -----------------------------------------------------------------
    # DB
    # -----------------------------------------------------------------
    DATABASE_URL: str = Field(
        default=(
            "postgresql+asyncpg://postgres:postgres@localhost:5432/efhc"
            "?sslmode=disable"
        ),
        description="Async SQLAlchemy URL",
    )
    SYNC_DATABASE_URL: str = Field(
        default=(
            "postgresql://postgres:postgres@localhost:5432/efhc"
            "?sslmode=disable"
        ),
        description="Sync URL (alembic)",
    )
    DB_SCHEMA_CORE: str = Field(
        default="efhc_core",
        description="Главная схема данных",
    )

    DB_SCHEMA_ADMIN: str = Field(
        default="efhc_admin",
        description=(
            "Админская схема данных (таблицы "
            "админ-панели/банка/пакетов)"
        ),
    )

    @field_validator("DB_SCHEMA_CORE", mode="before")
    @classmethod
    def _canon_db_schema_core(cls, v: object) -> str:
        """Normalize schema aliases to canonical efhc_* names."""
        if v is None:
            return "efhc_core"
        s = str(v).strip()
        aliases = {
            "core": "efhc_core",
            "efhc": "efhc_core",
            "efhc-core": "efhc_core",
        }
        s = aliases.get(s, s)
        if s != "efhc_core":
            raise ValueError("DB_SCHEMA_CORE must be efhc_core")
        return s

    @field_validator("DB_SCHEMA_ADMIN", mode="before")
    @classmethod
    def _canon_db_schema_admin(cls, v: object) -> str:
        """Normalize schema aliases to canonical efhc_* names."""
        if v is None:
            return "efhc_admin"
        s = str(v).strip()
        aliases = {
            "admin": "efhc_admin",
            "efhc-admin": "efhc_admin",
        }
        s = aliases.get(s, s)
        if s != "efhc_admin":
            raise ValueError("DB_SCHEMA_ADMIN must be efhc_admin")
        return s

    # -----------------------------------------------------------------
    # Admin / Bank
    # -----------------------------------------------------------------
    BANK_EFHC: str = Field(
        # Канон: логический tg_id для зеркальных записей банка.
        # Истина баланса — efhc_core.bank_balance.
        default="0",
        description=(
            "Логический tg_id BANK_EFHC (алиас) для зеркальных "
            "записей efhc_transfers_log; может быть 0"
        ),
    )

    # -----------------------------------------------------------------
    # Lotteries (SSOT)
    # -----------------------------------------------------------------
    LOTTERIES_MAX_TICKETS_PER_USER: int = Field(
        default=10,
        description=(
            "Макс. билетов на 1 пользователя в одной lotteries "
            "(SSOT)."
        ),
    )

    LOTTERIES_EFHC_TOTAL_TICKETS: int = Field(
        default=200,
        description=(
            "Lotteries EFHC: всего билетов в розыгрыше (SSOT)."
        ),
    )
    LOTTERIES_EFHC_TICKET_PRICE_D8: Decimal = Field(
        default=Decimal("1.00000000"),
        description=(
            "Lotteries EFHC: цена 1 билета (d8)."
        ),
    )
    LOTTERIES_EFHC_PRIZE_BONUS_D8: Decimal = Field(
        default=Decimal("100.00000000"),
        description=(
            "Lotteries EFHC: приз победителю (EFHC bonus, d8)."
        ),
    )

    LOTTERIES_VIP_TOTAL_TICKETS: int = Field(
        default=1000,
        description=(
            "Lotteries VIP NFT EFHC: всего билетов в розыгрыше (SSOT)."
        ),
    )
    LOTTERIES_VIP_TICKET_PRICE_D8: Decimal = Field(
        default=Decimal("1.00000000"),
        description=(
            "Lotteries VIP NFT EFHC: цена 1 билета (d8)."
        ),
    )
    LOTTERIES_VIP_PRIZE_NFT_CODE: str = Field(
        default="VIP_EFHC",
        description=(
            "Lotteries VIP NFT EFHC: код приза (заявка на выдачу NFT)."
        ),
    )


    # -----------------------------------------------------------------
    # Tasks (defaults)
    # -----------------------------------------------------------------
    TASK_REWARD_BONUS_EFHC_DEFAULT: Decimal = Field(
        default=Decimal('0'),
        description=(
            'Дефолтная награда (bonus EFHC) для '
            'task, если не задано явно.'
        ),
    )
    # -----------------------------------------------------------------
    # Telegram Bot
    # -----------------------------------------------------------------
    BOT_TOKEN: str = Field(
        default="",
        validation_alias=AliasChoices(
            "TELEGRAM_BOT_TOKEN",
            "BOT_TOKEN",
        ),
        description="Telegram Bot Token",
    )
    ADMIN_TG_ID: int = Field(
        default=0,
        validation_alias=AliasChoices("ADMIN_TG_ID", "ADMIN_ID"),
        description="Единственный главный админ TG ID",
    )

    ADMIN_TG_IDS: list[int] = Field(
        default_factory=list,
        validation_alias=AliasChoices(
            "ADMIN_TG_IDS",
        ),
        description=(
            "Whitelist админов (TG IDs). Если задан — используется "
            "вместо ADMIN_TG_ID"
        ),
    )

    # -----------------------------------------------------------------
    # Webhook
    # -----------------------------------------------------------------
    TELEGRAM_WEBHOOK_PATH: str = Field(
        default="/tg/webhook",
        description="Путь webhook в FastAPI",
    )
    TELEGRAM_WEBHOOK_URL: str = Field(
        default="",
        description="Полный URL webhook (опционально)",
    )

    TELEGRAM_WEBHOOK_SECRET: str = Field(
        default="",
        validation_alias=AliasChoices(
            "TELEGRAM_WEBHOOK_SECRET",
            "WEBHOOK_SECRET",
        ),
        description="Secret token for Telegram webhook",
    )

    # -----------------------------------------------------------------
    # I18N (13 языков)
    # -----------------------------------------------------------------
    SUPPORTED_LANGS: list[str] = Field(
        # Канон (чат): 13 языков. UI остаётся EN, описания локализуются.
        default_factory=lambda: [
            "en",
            "ru",
            "ua",
            "de",
            "es",
            "fr",
            "it",
            "pl",
            "tr",
            "da",
            "id",
            "hi",
            "sw",
        ],
        description="Коды поддерживаемых языков",
    )

    # -----------------------------------------------------------------
    # VIP NFT / TON
    # -----------------------------------------------------------------
    VIP_NFT_COLLECTION: str = Field(
        default="",
        description="TON NFT collection address for VIP",
    )

    # -----------------------------------------------------------------
    # Energy generation SSOT constants (string -> Decimal d8)
    # -----------------------------------------------------------------
    GEN_PER_SEC_BASE_KWH: str = Field(
        default="0.00000692",
        description="SSOT base generation rate (kWh/sec) as string",
    )
    GEN_PER_SEC_VIP_KWH: str = Field(
        default="0.00000741",
        description="SSOT VIP generation rate (kWh/sec) as string",
    )
    EFHC_KWH_RATE: str = Field(
        default="1.0",
        description="SSOT conversion rate EFHC:kWh as string",
    )

    TON_WALLET: str = Field(
        default="",
        validation_alias=AliasChoices(
            "TON_WALLET",
            "PROJECT_TON_WALLET",
        ),
        description="TON wallet address for deposits",
    )

    # -----------------------------------------------------------------
    # Payments (A+B intents) — TonConnect
    # -----------------------------------------------------------------
    PAYMENTS_RECEIVER_ADDRESS: str = Field(
        default=(
            "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW"
        ),
        description=(
            "Адрес получателя on-chain оплат проекта. "
            "Используется для deposit/shop_external."
        ),
    )
    EFHC_JETTON_MASTER_ADDRESS: str = Field(
        default="EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw",
        description="EFHC jetton master address (mainnet, canon)",
    )

    EFHC_JETTON_DECIMALS: int = Field(
        default=8,
        ge=0,
        le=255,
        description="EFHC jetton decimals (canon, d8)",
    )

    USDT_JETTON_MASTER_ADDRESS: str = Field(
        default="",
        description=(
            "TON USDT jetton master address "
            "(for jetton transfer)"
        ),
    )
    JETTON_TRANSFER_FEE_NANO: str = Field(
        default="50000000",
        description="TON fee (nanotons) for jetton transfer message",
    )
    VIP_NFT_NETWORK: str = Field(
        default="mainnet",
        description="mainnet/testnet",
    )


    # -----------------------------------------------------------------
    # Referral thresholds (SSOT helper)
    # -----------------------------------------------------------------
    def parsed_ref_bonus_thresholds(self) -> list[tuple[int, str]]:
        """Парсит пороги реферальных бонусов из ENV.

        Форматы (любая смесь разделителей):
        - "10=0.1,50=0.2"
        - "10:0.1; 50:0.2"
        Пустое/не задано -> [].

        Возвращает список (k, v) как (int, str) без округления.
        Округление/Decimal делается в вызывающем коде.
        """
        raw = os.getenv("REF_BONUS_THRESHOLDS") or os.getenv(
            "REFERRAL_BONUS_THRESHOLDS", ""
        )
        raw = (raw or "").strip()
        if not raw:
            return []
        items: list[tuple[int, str]] = []
        # split pairs by comma/semicolon
        for part in re.split(r"[;,]", raw):
            part = (part or "").strip()
            if not part:
                continue
            if ":" in part:
                k_s, v_s = part.split(":", 1)
            elif "=" in part:
                k_s, v_s = part.split("=", 1)
            else:
                # unsupported piece - ignore
                continue
            k_s = (k_s or "").strip()
            v_s = (v_s or "").strip()
            if not k_s or not v_s:
                continue
            try:
                k = int(k_s)
            except ValueError:
                continue
            items.append((k, v_s))
        return items


@lru_cache(maxsize=1)
def _get_settings_cached() -> Settings:
    return Settings()


def get_settings() -> Settings:
    """SSOT: получить настройки проекта.

    В CI/тестах Settings часто собирается на лету через monkeypatch/env.
    Кэширование в таких средах ломает детерминизм.
    """
    raw = (os.getenv("ENV") or "local").strip().lower()
    aliases = {
        "production": "prod",
        "prod": "prod",
        "stage": "stage",
        "staging": "stage",
        "dev": "dev",
        "development": "dev",
        "local": "local",
        "ci": "ci",
        "test": "ci",
    }
    env_norm = aliases.get(raw, raw)

    if env_norm == "ci" or os.getenv("PYTEST_CURRENT_TEST"):
        return Settings()

    return _get_settings_cached()


# Совместимость: в проекте и тестах исторически вызывали
# get_settings.cache_clear().
# Мы сохраняем этот API, но кэш находится во внутренней функции
# _get_settings_cached.
get_settings.cache_clear = (
    _get_settings_cached.cache_clear  # type: ignore[attr-defined]
)
get_settings.cache_info = (
    _get_settings_cached.cache_info  # type: ignore[attr-defined]
)

settings = get_settings()

__all__ = ["Settings", "get_settings", "settings"]
