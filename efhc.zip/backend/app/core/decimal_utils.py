"""Совместимый decimal helper для исторических импортов."""

from __future__ import annotations

from app.deps import d8

__all__ = ["d8"]
