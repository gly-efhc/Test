from __future__ import annotations

# Совместимый decimal helper для старых импортов.
from app.deps import d8

__all__ = ["d8"]
