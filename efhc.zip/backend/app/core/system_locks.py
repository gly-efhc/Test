# backend/app/core/system_locks.py
# =====================================================================
# Назначение кода:
# Единый «канон-замок» EFHC Bot. Гарантирует инварианты до старта
# приложения и во время работы:
# • только per-sec ставки генерации;
# • обмен строго kWh→EFHC 1:1;
# • запрет P2P;
# • запрет авто-выдачи NFT;
# • обязательный Idempotency-Key для денежных запросов;
# • запрет отрицательных балансов у пользователей.
#
# Канон / инварианты (фиксируем жёстко):
# • GEN_PER_SEC_BASE_KWH и GEN_PER_SEC_VIP_KWH — единственные источники
# истинных ставок; никаких «суточных» констант в коде быть не должно.
# • EFHC_KWH_RATE == 1.0 навсегда. Обратной конверсии EFHC→kWh нет.
# • Любое движение EFHC — только «Банк ↔ Пользователь». P2P запрещён.
# • Пользователь НИКОГДА не уходит в минус (main/bonus).
# • Банк МОЖЕТ быть в минусе (дефицит не блокирует операции).
# • NFT не доставляются автоматически: заявка и ручная обработка.
# • Денежные POST/PUT/PATCH/DELETE — строго с Idempotency-Key.
#
# ИИ-защита / самовосстановление:
# • Проверки канона выполняются на старте (init_system_locks)
#   и при финансовом действии через публичные хелперы.
# • Middleware может «прикрыть» все денежные ручки по префиксам или по
# метке @monetary_op, даже если разработчик забыл зависимость в роуте.
# • Все проверки формируют исключения LockViolation или HTTP 400–403
# без падений процесса.
#
# Запреты:
# • Здесь нет бизнес-логики денег/энергии. Только проверки и middleware.
# • Никаких «суточных» (daily) ставок и VIP-множителей вне канона.
# =====================================================================

from __future__ import annotations

import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from fastapi import FastAPI, Header, HTTPException, Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
from starlette.types import ASGIApp

logger = get_logger(__name__)
settings = get_settings()

# --------------------------------------------------------------------
# Внутренние константы канона (сравниваем с .env)
# --------------------------------------------------------------------
Q8 = Decimal(1).scaleb(-8)  # точность Decimal(8), округление вниз

GEN_PER_SEC_BASE_KWH_CANON = Decimal("0.00000692").quantize(
    Q8,
    rounding=ROUND_DOWN,
)
GEN_PER_SEC_VIP_KWH_CANON = Decimal("0.00000741").quantize(
    Q8,
    rounding=ROUND_DOWN,
)
EFHC_KWH_RATE_CANON = Decimal("1.0").quantize(
    Q8,
    rounding=ROUND_DOWN,
)

# Backward-compatible aliases (constants; keep for older imports)
CANON_BASE = GEN_PER_SEC_BASE_KWH_CANON
CANON_VIP = GEN_PER_SEC_VIP_KWH_CANON
CANON_RATE = EFHC_KWH_RATE_CANON


# --------------------------------------------------------------------
# Исключения и DTO для нарушений канона
# --------------------------------------------------------------------


class LockViolation(RuntimeError):
    """
    Нарушение канона / архитектурных запретов.

    Важно:
    • Это ОШИБКА ПРОЕКТА, а не «ошибка пользователя».
    • Должна отлавливаться верхним слоем и логироваться,
      но не маскироваться под 500 без объяснения.
    """


@dataclass(frozen=True)


class BalanceSnapshot:
    """
    Снимок пользовательского баланса для проверки «не уйти в минус».

    main:
        Основной баланс EFHC (панели, покупки, вывод).
    bonus:
        Бонусный баланс EFHC (рефералка, задания, лотереи и т.п.).
    """

    main: Decimal
    bonus: Decimal


# --------------------------------------------------------------------
# Публичные проверки — импортируются сервисами / роутами
# --------------------------------------------------------------------


def assert_per_sec_canon() -> None:
    """
    Проверяет, что в конфиге заданы канонические per-sec ставки
    генерации и фиксированный курс 1:1.
    и фиксированный курс 1:1.

    Вызывается на старте (init_system_locks).
    При несоответствии поднимает
    LockViolation и не даёт приложению запуститься.
    """
    try:
        base = Decimal(str(settings.GEN_PER_SEC_BASE_KWH))
        vip = Decimal(str(settings.GEN_PER_SEC_VIP_KWH))
        rate = Decimal(str(settings.EFHC_KWH_RATE))
    except Exception as exc:  # noqa: BLE001
        raise LockViolation(
            "Некорректные per-sec ставки или курс в настройках: "
            f"{exc}",
        ) from exc

    base_q = base.quantize(Q8, rounding=ROUND_DOWN)
    vip_q = vip.quantize(Q8, rounding=ROUND_DOWN)
    rate_q = rate.quantize(Q8, rounding=ROUND_DOWN)

    if base_q != GEN_PER_SEC_BASE_KWH_CANON:
        raise LockViolation(
            "GEN_PER_SEC_BASE_KWH≠"
            f"{GEN_PER_SEC_BASE_KWH_CANON}. Найдено: {base}. "
            "Допустимо только каноническое значение.",
        )

    if vip_q != GEN_PER_SEC_VIP_KWH_CANON:
        raise LockViolation(
            "GEN_PER_SEC_VIP_KWH≠"
            f"{GEN_PER_SEC_VIP_KWH_CANON}. Найдено: {vip}. "
            "Допустимо только каноническое значение.",
        )

    if rate_q != EFHC_KWH_RATE_CANON:
        raise LockViolation(
            "EFHC_KWH_RATE должен быть ровно 1.0. "
            f"Найдено: {rate}.",
        )


def get_rate_base_d8() -> Decimal:
    """SSOT base per-sec rate as Decimal(d8), ROUND_DOWN."""
    return Decimal(str(settings.GEN_PER_SEC_BASE_KWH)).quantize(
        Q8,
        rounding=ROUND_DOWN,
    )


def get_rate_vip_d8() -> Decimal:
    """SSOT VIP per-sec rate as Decimal(d8), ROUND_DOWN."""
    return Decimal(str(settings.GEN_PER_SEC_VIP_KWH)).quantize(
        Q8,
        rounding=ROUND_DOWN,
    )


def assert_system_locks() -> None:
    """Единая точка стартовой проверки канона.

    Используется слоем запуска (backend.run) как компактная проверка
    «можно ли поднимать процесс». Без middleware и привязки к ASGI.
    """
    assert_per_sec_canon()


def assert_exchange_direction_kwh_to_efhc_only(
    *,
    reverse: bool = False,
) -> None:
    """
    Запрещает обратную конверсию EFHC→kWh.

    Сервис обмена должен вызывать без аргументов; передача reverse=True
    приводит к немедленной ошибке канона.
    """
    if reverse:
        raise LockViolation(
            "Обратная конверсия EFHC→kWh запрещена каноном EFHC.",
        )


def assert_p2p_forbidden(
    sender_tg_id: int | None,
    receiver_tg_id: int | None,
) -> None:
    """
    Запрещает любые прямые переводы user→user.

    Разрешены только операции «Банк↔Пользователь». Для банка следует
    передавать None вместо tg_id.
    """
    if sender_tg_id is not None and receiver_tg_id is not None:
        raise LockViolation(
            "P2P операции между пользователями запрещены каноном: "
            "разрешены только «Банк↔Пользователь».",
        )


def assert_no_auto_nft_delivery(*, auto: bool = False) -> None:
    """
    Запрещает авто-выдачу NFT.

    Любая попытка авто-доставки (auto=True) — нарушение канона. Выдача
    VIP-NFT и других NFT должна идти только по заявке и ручному апруву.
    """
    if auto:
        raise LockViolation("Автоматическая выдача NFT запрещена. "
            "Допустимы только заявки и ручная обработка.",)


def ensure_user_non_negative_after(
    before: BalanceSnapshot,
    delta_main: Decimal,
    delta_bonus: Decimal,
) -> None:
    """
    Проверка «не уйти в минус» для пользователя.

    Использование:
    • Вызывать ПЕРЕД применением списания.
    • Покупки за EFHC блокируем, если расчёт даёт отрицательный итог.
    • Пополнения и конвертация kWh→EFHC не блокируются.

    before:
        Текущий снимок баланса.
    delta_main:
        Планируемое изменение основного баланса (может быть отриц.).
    delta_bonus:
        Планируемое изменение бонусного баланса (может быть отриц.).
    """
    after_main = (before.main + delta_main).quantize(
        Q8,
        rounding=ROUND_DOWN,
    )
    after_bonus = (before.bonus + delta_bonus).quantize(
        Q8,
        rounding=ROUND_DOWN,
    )

    if after_main < 0 or after_bonus < 0:
        raise LockViolation(
            "Списание дало бы отрицательный баланс пользователя: "
            f"main={after_main}, bonus={after_bonus}. "
            "Операция запрещена.",
        )


def flag_bank_deficit_if_negative(after_bank_balance: Decimal) -> None:
    """
    Логирует дефицит Банка EFHC, если баланс отрицательный.

    Важно:
    • Банк МОЖЕТ уходить в минус, это не блокирует операции.
    • Хелпер для метрик/логов: позволяет отслеживать моменты,
      когда Банк выдаёт больше EFHC, чем получил.
    """
    if after_bank_balance < 0:
        logger.warning(
            "BANK DEFICIT MODE: after=%s",
            str(after_bank_balance),
        )

# --------------------------------------------------------------------
# Обязательный Idempotency-Key для денежных запросов
# --------------------------------------------------------------------
async def require_idempotency_key(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
) -> str:
    """
    FastAPI-зависимость для денежных POST/PUT/PATCH/DELETE.

    Возвращает ключ, либо 400, если заголовок пустой или отсутствует.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Idempotency-Key header is strictly required for "
                "monetary operations."
            ),
        )
    return idempotency_key.strip()


def monetary_op(func: Callable[..., Any]) -> Callable[..., Any]:
    """
    Декоратор-метка для эндпоинтов: middleware видит денежную операцию.

    Пример:
        @router.post(
            "/buy",
            dependencies=[Depends(require_idempotency_key)],
        )
        @monetary_op
        async def buy_panel(...):
            ...
    """
    func._monetary_op = True  # type: ignore[attr-defined]
    return func


def idempotent_action(
    *,
    ttl_sec: int = 30,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Декоратор: точечная идемпотентность (TTL) для одного эндпоинта.

    Это UX-замок от двойных кликов. Бизнес-идемпотентность остаётся
    обеспеченной SSOT/уникальностями доменных таблиц.

    ttl_sec:
        Окно блокировки дублей для пары (path, Idempotency-Key).
    """

    safe_ttl = int(ttl_sec)
    if safe_ttl < 1:
        safe_ttl = 1
    if safe_ttl > 3600:
        safe_ttl = 3600

    def _wrap(func: Callable[..., Any]) -> Callable[..., Any]:
        meta = func.__dict__
        meta["_idempotent_ttl_sec"] = safe_ttl
        meta["_monetary_op"] = True
        return func

    return _wrap


class MonetaryIdempotencyMiddleware(BaseHTTPMiddleware):
    """
    Middleware-страховка: если разработчик забыл зависимость
    require_idempotency_key на «денежной ручке», этот слой проверит
    заголовок
    по префиксам пути ИЛИ по явной метке @monetary_op и вернёт 400 при
    отсутствии ключа.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        path_prefixes: Iterable[str] | None = None,
        methods: tuple[str, ...] = (
            "POST",
            "PUT",
            "PATCH",
            "DELETE",
        ),
    ) -> None:
        """Создаёт middleware для проверки Idempotency-Key."""
        super().__init__(app)
        self.methods = methods

        # Конфигурируемые префиксы денежных зон:
        # • можно передать в конструктор;
        # • можно задать в settings.MONETARY_PATH_PREFIXES;
        # • иначе используются дефолтные значения.
        default_prefixes: tuple[str, ...] = (
            "/exchange",
            "/panels",
            "/shop",
            "/withdraw",
            "/admin",
        )

        if path_prefixes is not None:
            self.prefixes = tuple(path_prefixes)
        else:
            cfg = getattr(settings, "MONETARY_PATH_PREFIXES", None)
            if isinstance(cfg, list | tuple):
                self.prefixes = tuple(str(p) for p in cfg)
            else:
                self.prefixes = default_prefixes

        # TTL-кэш идемпотентности (в памяти процесса).
        # Замок от повторных кликов для @idempotent_action.
        self._ttl_seen: dict[str, float] = {}

    async def dispatch(  # type: ignore[override]
        self,
        request: Request,
        call_next: Callable[[Request], Any],
    ) -> Any:
        # Не проверяем безопасные методы.
        """Проверяет Idempotency-Key для денежного запроса."""
        if request.method not in self.methods:
            return await call_next(request)

        path = request.url.path or "/"

        # 1) Если путь «денежный» по префиксу — требуем ключ.
        path_matches = any(path.startswith(p) for p in self.prefixes)

        # 2) Если эндпоинт помечен @monetary_op — тоже требуем.
        marked = False
        ttl_sec: int | None = None
        router = getattr(request.app, "router", None)
        if router is not None:
            for route in router.routes:
                route_path = getattr(route, "path", None)
                route_methods = getattr(route, "methods", None)
                if route_path != path or not route_methods:
                    continue
                endpoint = getattr(route, "endpoint", None)
                endpoint_is_marked = bool(endpoint)
                if endpoint_is_marked:
                    endpoint_is_marked = bool(
                        getattr(endpoint, "_monetary_op", False)
                    )
                if endpoint_is_marked:
                    marked = True
                    ttl_attr = getattr(
                        endpoint,
                        "_idempotent_ttl_sec",
                        None,
                    )
                    if isinstance(ttl_attr, int) and ttl_attr > 0:
                        ttl_sec = int(ttl_attr)
                    break

        if path_matches or marked:
            idk = (
                request.headers.get("Idempotency-Key") or ""
            ).strip()
            if not idk:
                return _http_400(
                    "Idempotency-Key header is required "
                    "for monetary operations.",
                )

            # TTL-идемпотентность включаем только для
            # @idempotent_action.
            if ttl_sec is not None:
                now = time.time()
                key = f"{path}|{idk}"

                if self._ttl_seen:
                    expired = []
                    for k, exp in self._ttl_seen.items():
                        if exp <= now:
                            expired.append(k)
                    for k in expired[:2000]:
                        self._ttl_seen.pop(k, None)

                exp_at = self._ttl_seen.get(key)
                if exp_at is not None and exp_at > now:
                    return _json_response(
                        status.HTTP_409_CONFLICT,
                        {
                            "detail": (
                                "Duplicate request blocked by "
                                "idempotency TTL."
                            )
                        },
                    )
                self._ttl_seen[key] = now + float(ttl_sec)

        return await call_next(request)


def _http_400(msg: str) -> JSONResponse:
    """Короткий JSON-ответ 400."""
    return _json_response(
        status.HTTP_400_BAD_REQUEST,
        {"detail": msg},
    )


def _json_response(code: int, payload: dict) -> JSONResponse:
    """Короткий JSONResponse без лишних зависимостей."""
    return JSONResponse(
        status_code=code,
        content=payload,
    )

# --------------------------------------------------------------------
# Инициализация «замков» на старте приложения
# --------------------------------------------------------------------


def init_system_locks(app: FastAPI) -> None:
    """
    Инициализация канон-проверок и middleware.

    Вызывать один раз при сборке FastAPI:
        app = FastAPI(...)
        init_system_locks(app)
    """
    # 1) Жёсткая проверка per-sec ставок и курса.
    assert_per_sec_canon()
    logger.info(
        "SystemLocks: per-sec canon and 1:1 rate validated.",
    )

    # 2) Подключаем middleware страховки Idempotency-Key.
    app.add_middleware(MonetaryIdempotencyMiddleware)
    logger.info(
        "SystemLocks: MonetaryIdempotencyMiddleware installed.",
    )

    # 3) (опционально) Логи о режиме банка.
    allow_negative_bank = bool(
        getattr(settings, "ALLOW_NEGATIVE_BANK_BALANCE", True),
    )
    if not allow_negative_bank:
        logger.warning(
            "ALLOW_NEGATIVE_BANK_BALANCE = false. "
            "Это противоречит канону (банку разрешён минус). "
            "Рекомендуется установить true.",
        )

__all__ = [
    "LockViolation",
    "BalanceSnapshot",
    "assert_per_sec_canon",
    "get_rate_base_d8",
    "get_rate_vip_d8",
    "assert_system_locks",
    "assert_exchange_direction_kwh_to_efhc_only",
    "assert_p2p_forbidden",
    "assert_no_auto_nft_delivery",
    "ensure_user_non_negative_after",
    "flag_bank_deficit_if_negative",
    "require_idempotency_key",
    "monetary_op",
    "MonetaryIdempotencyMiddleware",
    "init_system_locks",
]

# =====================================================================
# Пояснения «для чайника»:
# • Сервисы должны вызывать ensure_user_non_negative_after(...) перед
# любыми списаниями с пользовательских балансов.
# Если расчёт даёт минус —
# поднимаем LockViolation и НЕ выполняем операцию.
# • Для банка: после применения операции вызывайте
# flag_bank_deficit_if_negative(...) чтобы фиксировать дефицит в логах.
# Операция при этом не блокируется — это штатная ситуация.
# • Денежные эндпоинты:
# а) dependencies=[Depends(require_idempotency_key)];
# б) декоратор-метка @monetary_op.
# Даже если забыли — middleware проверит по префиксу пути.
# • P2P: при любой попытке указать одновременно sender_tg_id и
# receiver_tg_id вызывайте assert_p2p_forbidden(...), чтобы немедленно
# поймать нарушение канона «нет внутренних переводов».
# • NFT: авто-доставка запрещена. watcher/shop должны создавать заявки
# со статусом наподобие PAID_PENDING_MANUAL, а админ-панель уже решает,
# когда и кому фактически выдавать NFT.
# =====================================================================

