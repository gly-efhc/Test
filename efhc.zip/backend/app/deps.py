# backend/app/deps.py
# ======================================================================
# EFHC Bot — Общие зависимости FastAPI: БД-сессия, идемпотентность,
# аутентификация,
# админ-гейт, keyset-пагинация, ETag и точность Decimal.
# ----------------------------------------------------------------------
# Канон/требования:
# • Все денежные POST — строго с Idempotency-Key (или client_nonce).
# • Списки — только cursor-based (keyset) пагинация.
# • Источник истины для генерации — посекундные ставки.
#   (В сервисах; здесь не считаем.)
# • Пользователь не может уходить в минус.
#   Банк — может (проверки в сервисах/locks).
#
# Этот модуль НЕ делает бизнес-логику, только инфраструктуру/валидацию.
# ======================================================================

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.utils.cursor_codec import decode_cursor, encode_cursor
from fastapi import (
    Depends,
    Header,
    HTTPException,
    Query,
    Request,
    status,
)
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()

# ----------------------------------------------------------------------
# БД-сессия
# ----------------------------------------------------------------------

from collections.abc import AsyncGenerator  # noqa: E402

from app.core.database_core import get_session_factory  # noqa: E402


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Выдаёт AsyncSession для роутов/сервисов.
    • Роут/сервис сам решает — коммитить или нет.
    • При исключении — безопасный rollback().
    """
    session_factory = get_session_factory()
    async with session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise


# Точность Decimal и утилиты для UI/списков
# ----------------------------------------------------------------------

EFHC_DECIMALS: int = int(getattr(settings, "EFHC_DECIMALS", 8) or 8)
Q8 = Decimal(1).scaleb(-EFHC_DECIMALS)


def d8(x: Any) -> Decimal:
    """Округление вниз до 8 знаков — строго по канону."""
    return Decimal(str(x)).quantize(Q8, rounding=ROUND_DOWN)


def make_etag(payload: dict[str, Any]) -> str:
    """
    Делает детерминированный ETag из JSON - представления payload.
    Используется фронтом для «304 Not Modified».
    """
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()



# Historical compatibility alias. New code uses make_etag().
etag = make_etag

def decode_cursor_or_400(cursor: str) -> dict[str, Any]:
    """Декодирует cursor (SSOT) и преобразует ошибку в HTTP 400.

    Зачем:
    - Роутам часто нужен немедленный 400.
    - SSOT-кодек остаётся чистым и даёт ValueError.
    """
    try:
        return dict(decode_cursor(cursor))
    except ValueError as err:
        raise HTTPException(
            status_code=400,
            detail="Некорректный cursor",
        ) from err


# ----------------------------------------------------------------------
# Идемпотентность денежных операций
# ----------------------------------------------------------------------


def normalize_idempotency_key(raw: str | None) -> str:
    """
    Нормализует произвольную строку пользователя в безопасный ключ.
    Удобно, когда client_nonce приходит в body.
    Роут может сам вызвать эту функцию.
    """
    if not raw or not raw.strip():
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key (или client_nonce) обязателен",
        )
    return hashlib.sha256(raw.strip().encode("utf-8")).hexdigest()


async def require_idempotency_key(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
    client_nonce: str | None = Query(
        default=None,
        description="Альтернатива заголовку Idempotency-Key",
    ),
) -> str:
    """Зависимость FastAPI: Idempotency-Key ИЛИ client_nonce.

    Возвращает нормализованный ключ (sha256 hex).
    Применять только для денежных POST.
    """
    raw = (idempotency_key or "").strip() or (
        client_nonce or ""
    ).strip()
    if not raw:
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key (или client_nonce) обязателен",
        )
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return digest


async def require_idempotency_key_header_only(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
) -> str:
    """Строгий вариант: только заголовок Idempotency-Key.

    Нужен там, где query/body nonce запрещены политикой.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key обязателен",
        )
    digest = hashlib.sha256(
        idempotency_key.strip().encode("utf-8")
    ).hexdigest()
    return digest


async def accept_idempotency_key(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
    client_nonce: str | None = Query(
        default=None,
        description="Альтернатива заголовку Idempotency-Key",
    ),
) -> str | None:
    """SHOULD-IDK: если ключ есть — нормализует и возвращает.
    Если ключа нет — возвращает None.

    Использовать для команд, где повторяемость запроса желательна.
    Например, служебные POST/PATCH.
    Но отсутствие ключа не должно блокировать пользователя/оператора.
    """
    raw = (idempotency_key or "").strip() or (
        client_nonce or ""
    ).strip()
    if not raw:
        return None
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ----------------------------------------------------------------------
# Аутентификация пользователя (auth-ready, с запасным контуром)
# ----------------------------------------------------------------------


@dataclass
class AuthContext:
    tg_id: int
    is_admin: bool = False
    global_id: int | None = None
    auth_source: str = "legacy_telegram"


async def register_external_event_after_secret(
    provider: str,
    request: Request,
    db: AsyncSession,
    *,
    x_event_id: str | None = None,
    x_delivery_id: str | None = None,
    x_update_id: str | None = None,
) -> dict[str, Any]:
    """Register external webhook/callback after source validation.

    Security canon: callers that have a provider secret/signature must
    verify that secret first and only then call this helper.
    This prevents invalid webhook attempts from poisoning the dedupe
    table before auth.
    """
    raw_id = (
        (x_event_id or "").strip()
        or (x_delivery_id or "").strip()
        or (x_update_id or "").strip()
    )

    body_bytes = await request.body()
    request.state._raw_body = body_bytes
    if not raw_id:
        raw_id = hashlib.sha256(body_bytes).hexdigest()

    event_id = hashlib.sha256(raw_id.encode("utf-8")).hexdigest()

    try:
        from sqlalchemy import text as _text

        q = _text(
            """
        INSERT INTO efhc_core.processed_external_events
                (provider, event_id)
            VALUES (:p, :e)
            ON CONFLICT (provider, event_id) DO NOTHING
            RETURNING 1
            """
        )
        r = await db.execute(q, {"p": provider, "e": event_id})
        inserted = r.scalar_one_or_none() == 1
        if inserted:
            await db.commit()
        return {
            "provider": provider,
            "event_id": event_id,
            "is_duplicate": (not inserted),
        }
    except Exception as e:
        logger.warning(
            "external_event_dedupe failed (provider=%s): %s",
            provider,
            e,
        )
        return {
            "provider": provider,
            "event_id": event_id,
            "is_duplicate": False,
            "warning": "dedupe_unavailable",
        }


def external_event_dedupe_dep(provider: str):
    """Dependency for external callbacks without a secret pre-check.

    Secret-protected routes must call
    register_external_event_after_secret() manually after verifying the
    provider token/signature.
    """

    async def _dep(
        request: Request,
        db: AsyncSession = Depends(get_db),
        x_event_id: str | None = Header(
            default=None,
            alias="X-Event-Id",
        ),
        x_delivery_id: str | None = Header(
            default=None,
            alias="X-Delivery-Id",
        ),
        x_update_id: str | None = Header(
            default=None,
            alias="X-Telegram-Update-Id",
        ),
    ) -> dict[str, Any]:
        return await register_external_event_after_secret(
            provider,
            request,
            db,
            x_event_id=x_event_id,
            x_delivery_id=x_delivery_id,
            x_update_id=x_update_id,
        )

    return _dep


def _try_int(val: Any) -> int | None:
    """Пытается преобразовать значение в int.

    При ошибке возвращает None.
    """
    try:
        v = int(val)
        return v if v > 0 else None
    except Exception:
        return None


async def _bearer_auth_context(request: Request):
    """Проверить Bearer session, если Authorization присутствует."""

    raw = request.headers.get("Authorization")
    if raw is None:
        return None
    scheme, separator, token = raw.partition(" ")
    if (
        separator != " "
        or scheme.lower() != "bearer"
        or not token
        or token != token.strip()
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Auth session недействительна",
            headers={"WWW-Authenticate": "Bearer"},
        )

    from app.identity.auth_errors import (
        AuthSessionNotActive,
        InvalidAuthRuntimeInput,
    )
    from app.identity.auth_runtime_services import AuthSessionService

    service = AuthSessionService(get_session_factory())
    try:
        context = await service.authenticate(token)
    except (AuthSessionNotActive, InvalidAuthRuntimeInput) as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Auth session недействительна",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc
    request.state.auth_context = context
    return context


async def _legacy_tg_for_global_id(global_id: int) -> int:
    """Разрешить legacy Telegram selector из canonical global_id."""

    session_factory = get_session_factory()
    async with session_factory() as session:
        row = (
            await session.execute(
                text(
                    "SELECT tg_id FROM efhc_core.users "
                    "WHERE global_id = :global_id LIMIT 1"
                ),
                {"global_id": int(global_id)},
            )
        ).first()
    if row is None or row.tg_id is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Legacy compatibility mapping не готов",
        )
    tg_id = _try_int(row.tg_id)
    if tg_id is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Legacy compatibility mapping недействителен",
        )
    return tg_id


async def _get_current_tg_id_impl(
    request: Request,
) -> int:
    """Вернуть legacy selector только из server-side session."""

    from app.identity.auth_transport_telemetry import (
        record_auth_transport,
    )

    context = await _bearer_auth_context(request)
    if context is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Требуется server-side auth session",
            headers={"WWW-Authenticate": "Bearer"},
        )
    legacy_selector = await _legacy_tg_for_global_id(
        context.global_id.value
    )
    request.state.legacy_tg_id = legacy_selector
    record_auth_transport("server_session_bridge")
    return legacy_selector


async def get_current_tg_id(*args, **kwargs) -> int:
    """Вернуть internal legacy selector после Bearer auth."""
    return await _get_current_tg_id_impl(*args, **kwargs)


async def require_wallet_connected(
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int | None = Depends(get_current_tg_id),
    current_global_id: int | None = None,
    feature: str | None = None,
) -> None:
    """WalletGate: требует активную привязку кошелька.

    Канон:
    - Истина о подключении кошелька берётся только из БД.
    - tg_id — internal compatibility selector после Bearer session.

    Ошибка:
    - 403 + code WALLET_REQUIRED + details.feature.
    """
    tg_id = (
        int(current_tg_id)
        if isinstance(current_tg_id, int) and current_tg_id > 0
        else None
    )
    global_id = (
        int(current_global_id)
        if current_global_id is not None
        else None
    )
    if (tg_id is None) == (global_id is None):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "WALLET_REQUIRED",
                "details": {"feature": feature or "unknown"},
            },
        )
    try:
        from app.services.wallets_service import (
            has_active_wallet,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Wallet service is not available",
        ) from e

    ok = await has_active_wallet(
        db,
        **(
            {"global_id": global_id}
            if global_id is not None
            else {"tg_id": tg_id}
        ),
    )
    if ok:
        return None

    logger.info(
        "wallet.required",
        extra={
            "audit__schema__version": "v1",
            "tg_id": tg_id,
            "global_id": global_id,
            "event": "wallet_gate",
            "result": "blocked",
            "feature": feature or "unknown",
        },
    )
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "code": "WALLET_REQUIRED",
            "details": {"feature": feature or "unknown"},
        },
    )


# ----------------------------------------------------------------------
# Админ-гейт (эмиссия/модерация и т.п.)
# ----------------------------------------------------------------------


async def require_admin(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> AuthContext:
    """Проверить admin whitelist только через server-side session."""

    from app.identity.auth_transport_telemetry import (
        record_auth_transport,
    )

    context = await _bearer_auth_context(request)
    if context is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Требуется server-side auth session",
            headers={"WWW-Authenticate": "Bearer"},
        )

    global_id = int(context.global_id.value)
    row = (
        await db.execute(
            text(
                "SELECT tg_id FROM efhc_core.users "
                "WHERE global_id = :global_id LIMIT 1"
            ),
            {"global_id": global_id},
        )
    ).first()
    if row is None or row.tg_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin compatibility mapping не готов",
        )
    tid = _try_int(row.tg_id)
    if tid is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin compatibility mapping недействителен",
        )

    try:
        admin_result = await db.execute(
            text(
                "SELECT 1 FROM efhc_admin.admin_whitelist "
                "WHERE tg_id = :tid AND is_active = true LIMIT 1"
            ),
            {"tid": tid},
        )
        if admin_result.fetchone():
            record_auth_transport("admin_server_session_bridge")
            return AuthContext(
                tg_id=tid,
                is_admin=True,
                global_id=global_id,
                auth_source="admin_server_session_bridge",
            )
    except Exception as exc:
        logger.warning("admin whitelist check failed: %s", exc)

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Доступ только для администратора Банка EFHC",
    )


# ----------------------------------------------------------------------
# Health-проверка БД
# ----------------------------------------------------------------------


async def db_ping(db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    """Health: выполняет простой запрос к БД.

    Возвращает статус доступности.
    """
    try:
        from sqlalchemy import text as _text

        row = await db.execute(_text("SELECT 1"))
        ok = row.scalar_one_or_none() == 1
        return {"db": "ok" if ok else "fail"}
    except Exception as e:
        logger.error("db_ping error: %s", e)
        return {"db": "fail", "error": str(e)}


# ======================================================================
# Пояснения «для чайника»:
# • get_db() — отдаёт AsyncSession.
#   При ошибках — rollback, затем исключение.
# • require_idempotency_key() — включайте как Depends
#   во всех денежных POST.
# Если клиент не может передать заголовок — используйте
# client_nonce в query,
# или нормализуйте body-поле через normalize_idempotency_key().
# • get_current_global_id() — внутренний compatibility selector,
#   доступный только после verified Bearer session.
# • require_admin() — разрешает session global_id и сверяет
#   legacy whitelist efhc_admin.admin_whitelist; старые admin headers
#   запрещены.
# • encode_cursor()/decode_cursor() — единые helpers
#   для keyset-пагинации
# списков.
# • Никаких «суточных» ставок в этом файле нет и быть не должно.
# ======================================================================

__all__ = [
    "decode_cursor",
    "encode_cursor",
]
