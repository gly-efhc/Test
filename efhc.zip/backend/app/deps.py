# backend/app/deps.py
# ======================================================================
# EFHC Bot — Общие зависимости FastAPI: БД-сессия, идемпотентность,
# аутентификация,
# админ-гейт, keyset-пагинация, ETag и точность Decimal.
# ----------------------------------------------------------------------
# Канон/требования:
# • Все денежные POST — строго с Idempotency-Key (или client_nonce).
# • Списки — только cursor-based (keyset) пагинация.
# • Источник истины для генерации — посекундные ставки.
#   (В сервисах; здесь не считаем.)
# • Пользователь не может уходить в минус.
#   Банк — может (проверки в сервисах/locks).
#
# Этот модуль НЕ делает бизнес-логику, только инфраструктуру/валидацию.
# ======================================================================

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.utils.cursor_codec import decode_cursor, encode_cursor
from fastapi import (
    Depends,
    Header,
    HTTPException,
    Query,
    Request,
    status,
)
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()

# ----------------------------------------------------------------------
# БД-сессия
# ----------------------------------------------------------------------

from collections.abc import AsyncGenerator  # noqa: E402

from app.core.database_core import get_session_factory  # noqa: E402


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Выдаёт AsyncSession для роутов/сервисов.
    • Роут/сервис сам решает — коммитить или нет.
    • При исключении — безопасный rollback().
    """
    session_factory = get_session_factory()
    async with session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise

# Точность Decimal и утилиты для UI/списков
# ----------------------------------------------------------------------

EFHC_DECIMALS: int = int(getattr(settings, "EFHC_DECIMALS", 8) or 8)
Q8 = Decimal(1).scaleb(-EFHC_DECIMALS)


def d8(x: Any) -> Decimal:
    """Округление вниз до 8 знаков — строго по канону."""
    return Decimal(str(x)).quantize(Q8, rounding=ROUND_DOWN)


def make_etag(payload: dict[str, Any]) -> str:
    """
    Делает детерминированный ETag из JSON - представления payload.
    Используется фронтом для «304 Not Modified».
    """
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()



def decode_cursor_or_400(cursor: str) -> dict[str, Any]:
    """Декодирует cursor (SSOT) и преобразует ошибку в HTTP 400.

    Зачем:
    - Роутам часто нужен немедленный 400.
    - SSOT-кодек остаётся чистым и даёт ValueError.
    """
    try:
        return dict(decode_cursor(cursor))
    except ValueError as err:
        raise HTTPException(
            status_code=400,
            detail="Некорректный cursor",
        ) from err

# ----------------------------------------------------------------------
# Идемпотентность денежных операций
# ----------------------------------------------------------------------


def normalize_idempotency_key(raw: str | None) -> str:
    """
    Нормализует произвольную строку пользователя в безопасный ключ.
    Удобно, когда client_nonce приходит в body.
    Роут может сам вызвать эту функцию.
    """
    if not raw or not raw.strip():
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key (или client_nonce) обязателен",
        )
    return hashlib.sha256(raw.strip().encode("utf-8")).hexdigest()

async def require_idempotency_key(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
    client_nonce: str | None = Query(
        default=None,
        description="Альтернатива заголовку Idempotency-Key",
    ),
) -> str:
    """Зависимость FastAPI: Idempotency-Key ИЛИ client_nonce.

    Возвращает нормализованный ключ (sha256 hex).
    Применять только для денежных POST.
    """
    raw = (
        (idempotency_key or "").strip()
        or (client_nonce or "").strip()
    )
    if not raw:
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key (или client_nonce) обязателен",
        )
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return digest

async def require_idempotency_key_header_only(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
) -> str:
    """Строгий вариант: только заголовок Idempotency-Key.

    Нужен там, где query/body nonce запрещены политикой.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key обязателен",
        )
    digest = hashlib.sha256(
        idempotency_key.strip().encode("utf-8")
    ).hexdigest()
    return digest


async def accept_idempotency_key(
    idempotency_key: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
    client_nonce: str | None = Query(
        default=None,
        description="Альтернатива заголовку Idempotency-Key",
    ),
) -> str | None:
    """SHOULD-IDK: если ключ есть — нормализует и возвращает.
    Если ключа нет — возвращает None.

    Использовать для команд, где повторяемость запроса желательна.
    Например, служебные POST/PATCH.
    Но отсутствие ключа не должно блокировать пользователя/оператора.
    """
    raw = (
        (idempotency_key or "").strip()
        or (client_nonce or "").strip()
    )
    if not raw:
        return None
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

# ----------------------------------------------------------------------
# Аутентификация пользователя (auth-ready, с запасным контуром)
# ----------------------------------------------------------------------

@dataclass


class AuthContext:
    tg_id: int
    is_admin: bool = False


def external_event_dedupe_dep(provider: str):
    """Dependency для внешних webhooks/callback.

    Внешние системы обычно имеют event-id / delivery-id.
    Для таких ручек Idempotency-Key не требуется.
    Dedupe делаем по external id.

    Канон: efhc_core.processed_external_events.
    UNIQUE(provider, event_id).
    Дубль: handler возвращает 200 OK без повторной обработки.
    """

    async def _dep(
        request: Request,
        db: AsyncSession = Depends(get_db),
        x_event_id: str | None = Header(
            default=None,
            alias="X-Event-Id",
        ),
        x_delivery_id: str | None = Header(
            default=None,
            alias="X-Delivery-Id",
        ),
        x_update_id: str | None = Header(
            default=None,
            alias="X-Telegram-Update-Id",
        ),
    ) -> dict[str, Any]:
        # 1) Берём внешний id из заголовков (предпочтительно).
        raw_id = (
            (x_event_id or "").strip()
            or (x_delivery_id or "").strip()
            or (x_update_id or "").strip()
        )

        # 2) Если внешний id не передали, используем sha256(body)
#    как аварийный
        # dedupe.
        # Это лучше, чем обрабатывать одно и то же событие дважды из-за
        # ретраев.
        body_bytes = await request.body()
        # Чтобы handler мог повторно распарсить без второго чтения.
        request.state._raw_body = body_bytes
        if not raw_id:
            raw_id = hashlib.sha256(body_bytes).hexdigest()

        event_id = hashlib.sha256(raw_id.encode("utf-8")).hexdigest()

        # 3) Пишем/проверяем processed_external_events.
        try:
            from sqlalchemy import text as _text

            # Вставка с ON CONFLICT даёт 0/1 строк.
# Это удобно для определения
            # дубля.
            q = _text(
            """
            INSERT INTO efhc_core.processed_external_events
                    (provider, event_id)
                VALUES (:p, :e)
                ON CONFLICT (provider, event_id) DO NOTHING
                RETURNING 1
                """)
            r = await db.execute(q, {"p": provider, "e": event_id})
            inserted = r.scalar_one_or_none() == 1
            if inserted:
                await db.commit()
            return {
                "provider": provider,
                "event_id": event_id,
                "is_duplicate": (not inserted),
            }
        except Exception as e:
            # Если таблицы ещё нет (не прогнаны миграции) — не блокируем
            # вебхук.
            # Но логируем: это снижает устойчивость к ретраям.
            logger.warning(
                "external_event_dedupe failed (provider=%s): %s",
                provider,
                e,
            )
            return {
                "provider": provider,
                "event_id": event_id,
                "is_duplicate": False,
                "warning": "dedupe_unavailable",
            }

    return _dep


def _try_int(val: Any) -> int | None:
    """Пытается преобразовать значение в int.
    
    При ошибке возвращает None.
    """
    try:
        v = int(val)
        return v if v > 0 else None
    except Exception:
        return None

async def _get_current_tg_id_impl(
    request: Request,
) -> int:
    """
    Определяет tg_id c приоритетами:
      1) Если middleware уже положил tg_id в request.state.tg_id
         — используем.
      2) Telegram WebApp initData (HMAC-валидируемый).
         Запасной путь, если middleware отключён.
    Если ничего не найдено — 401.
    """
    # 1) Middleware/авторизация уже проставила
    st_tg_id = getattr(request.state, "tg_id", None)
    tg_id = _try_int(st_tg_id)
    if tg_id:
        return tg_id


    # 5) Telegram initData (строгое подтверждение личности)
    # Предпочтительный путь — через middleware, который ставит
    # request.state.tg_id.
    # Этот блок — резервный (на случай отключенного middleware).
    init_data = request.headers.get("X-Telegram-Init-Data")
    if init_data:
        try:
            from app.core.security_core import (
                validate_telegram_init_data,
            )  # type: ignore

            parsed = validate_telegram_init_data(init_data)
            user_obj = parsed.get("user")
            if isinstance(user_obj, dict):
                tg_id = _try_int(user_obj.get("id"))
                if tg_id:
                    # Кладём в state, чтобы дальше всё шло единым путём.
                    request.state.tg_id = tg_id
                    return tg_id
        except Exception as e:
            logger.warning(
                "auth telegram init data validate failed: %s",
                e,
            )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Требуется аутентификация",
    )


async def get_current_tg_id(*args, **kwargs) -> int:
    """Канон: возвращает tg_id (Telegram user.id)."""
    return await _get_current_tg_id_impl(*args, **kwargs)


async def require_wallet_connected(
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
    feature: str | None = None,
) -> None:
    """WalletGate: требует активную привязку кошелька.

    Канон:
    - Истина о подключении кошелька берётся только из БД.
    - tg_id только из Telegram initData (Depends(get_current_tg_id)).

    Ошибка:
    - 403 + code WALLET_REQUIRED + details.feature.
    """
    tg_id = int(current_tg_id)
    try:
        from app.services.wallets_service import (
            has_active_wallet,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Wallet service is not available",
        ) from e

    ok = await has_active_wallet(db, tg_id=tg_id)
    if ok:
        return None

    logger.info(
        "wallet.required",
        extra={
            "audit_schema_version": "v1",
            "tg_id": tg_id,
            "event": "wallet_gate",
            "result": "blocked",
            "feature": feature or "unknown",
        },
    )
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "code": "WALLET_REQUIRED",
            "details": {"feature": feature or "unknown"},
        },
    )


# ----------------------------------------------------------------------
# Админ-гейт (эмиссия/модерация и т.п.)
# ----------------------------------------------------------------------

async def require_admin(
    request: Request,
    admin_id_header: int | None = Header(
        default=None,
        alias="X-Admin-Id",
    ),
    admin_token: str | None = Header(
        default=None,
        alias="X-Admin-Token",
    ),
    db: AsyncSession = Depends(get_db),
) -> AuthContext:
    """
    Пускает только администратора из efhc_admin.admin_whitelist.

    Канон безопасности:
    - все /admin/* роуты обязаны иметь require_admin;
    - заголовкам X-Admin-Id/X-Admin-Token не доверяем;
    - единственный фактор: request.state.tg_id ∈ admin_whitelist.
    """
    st_tg_id = getattr(request.state, "tg_id", None)
    tid = _try_int(st_tg_id)
    if tid:
        try:
            from sqlalchemy import text as _text

            q = _text(
                "SELECT 1 FROM efhc_admin.admin_whitelist "
                "WHERE tg_id = :tid AND is_active = true "
                "LIMIT 1"
            )
            row = await db.execute(q, {"tid": tid})
            if row.fetchone():
                return AuthContext(tg_id=tid, is_admin=True)
        except Exception as e:
            logger.warning("admin whitelist check failed: %s", e)

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Доступ только для администратора Банка EFHC",
    )

# ----------------------------------------------------------------------
# Health-проверка БД
# ----------------------------------------------------------------------

async def db_ping(db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    """Health: выполняет простой запрос к БД.
    
    Возвращает статус доступности.
    """
    try:
        from sqlalchemy import text as _text
        row = await db.execute(_text("SELECT 1"))
        ok = row.scalar_one_or_none() == 1
        return {"db": "ok" if ok else "fail"}
    except Exception as e:
        logger.error("db_ping error: %s", e)
        return {"db": "fail", "error": str(e)}

# ======================================================================
# Пояснения «для чайника»:
# • get_db() — отдаёт AsyncSession.
#   При ошибках — rollback, затем исключение.
# • require_idempotency_key() — включайте как Depends
#   во всех денежных POST.
# Если клиент не может передать заголовок — используйте
# client_nonce в query,
# или нормализуйте body-поле через normalize_idempotency_key().
# • get_current_tg_id() — готов к будущей Telegram/JWT-аутентификации,
# но уже работает в fallback-режиме (initData).
# • require_admin() — сверяет BANK_EFHC/ADMIN_TG_ID,
# допускает
# резервный X-Admin-Token == SECRET_KEY; опционально — whitelist в БД.
# • encode_cursor()/decode_cursor() — единые helpers
#   для keyset-пагинации
# списков.
# • Никаких «суточных» ставок в этом файле нет и быть не должно.
# ======================================================================

__all__ = [
    "decode_cursor",
    "encode_cursor",
]
