# -*- coding: utf-8 -*-
# backend/app/main.py
# ======================================================================
# EFHC Bot — точка входа FastAPI (КАНОН)
# ----------------------------------------------------------------------
# Что делает этот файл:
# • Создаёт приложение FastAPI и настраивает CORS.
# • На старте:
# - проверяет архитектурные запреты system_locks (если модуль есть),
# - в VPS-режиме может запустить фоновые агенты.
# • В Serverless (Vercel) не запускает вечные циклы.
#   Все фоновые задачи идут через /cron/tick.
# через /cron/tick (run_single_tick) и/или «forced sync» при действиях
# пользователя.
# ======================================================================

from __future__ import annotations

import os
from urllib.parse import urlparse
from contextlib import asynccontextmanager
from typing import Any, Dict, List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.database import async_session_maker

logger = get_logger(__name__)
settings = get_settings()

# --- PROD safety guard -----------------------------------------------
# If insecure user-id headers are enabled in PROD, fail fast on startup.
# This prevents configuration mistakes from turning into financial
# vulnerabilities.
_insecure_flag = (
    os.getenv('ALLOW_INSECURE_USER_HEADERS', '')
    .strip()
    .lower()
    in {'1', 'true', 'yes', 'on'}
)
if getattr(settings, 'ENV', '').lower() == 'prod' and _insecure_flag:
    raise RuntimeError(
        'SECURITY: ALLOW_INSECURE_USER_HEADERS = true is forbidden '
        'when ENV = prod'
    )


# ----------------------------------------------------------------------
# CORS: фронтенд/вебхуки из .env
# ----------------------------------------------------------------------


def _as_origin(raw: str) -> str:
    raw = (raw or "").strip()
    if not raw:
        return ""
    if raw == "*":
        return "*"
    p = urlparse(raw)
    if p.scheme and p.netloc:
        return f"{p.scheme}://{p.netloc}"
    return raw


def _build_cors_origins() -> List[str]:
    """SSOT: список доверенных Origin для CORS.

    Канон:
    - В prod НЕ разрешаем localhost.
    - Источник: CORS_ALLOW_ORIGINS (CSV) и базовые URL из settings.
    """
    origins: List[str] = []
    csv = (os.getenv("CORS_ALLOW_ORIGINS") or "").strip()
    if csv:
        for part in csv.split(","):
            v = part.strip()
            if v:
                origins.append(_as_origin(v))

    for name in (
        "APP_URL",
        "BACKEND_URL",
        "FRONTEND_URL",
        "WEBHOOK_URL",
    ):
        v = getattr(settings, name, None) or os.environ.get(name)
        if v:
            origins.append(_as_origin(str(v)))

    if getattr(settings, "env_normalized", "local") != "prod":
        origins.extend(
            [
                "http://localhost",
                "http://localhost:3000",
                "http://127.0.0.1",
                "http://127.0.0.1:3000",
            ]
        )

    uniq = sorted({o for o in origins if o})
    if "*" in uniq and settings.env_normalized == "prod":
        raise RuntimeError(
            "CORS: '*' is forbidden in prod when credentials "
            "are enabled"
        )
    return uniq

# ----------------------------------------------------------------------
# Лайфспан: старт/стоп приложения
# ----------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1) Жёсткие проверки архитектурных запретов
    #    (если модуль присутствует)
    """Асинхронная функция `lifespan` выполняет операцию
    в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля
    (см. имя функции и вызывающий код).

    Параметры:
    - `app` (FastAPI): входной параметр.

    Возвращает:
    - Результат операции (данные/DTO/модель) либо `None`.

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли.
      Идемпотентность достигается ключами и уникальными
      ограничениями.
    - Денежные значения в EFHC учитываются с точностью d8.
      Округление вниз: ROUND_DOWN, если применимо по
      модулю.
    - Для операций, затрагивающих баланс и банк, изменения
      должны проходить через банковский сервис транзакций
      (transactions_service)."""
    try:
        from backend.app.core.system_locks import (
            validate_on_start,
        )
    except Exception:
        logger.warning(
            "system_locks: модуль не найден — пропускаем "
            "жёсткие проверки на старте"
        )
    else:
        await validate_on_start()
        logger.info("system_locks: стартовые проверки канона пройдены")

    # 2) VPS-агенты — только если НЕ serverless.
    # В Vercel/serverless вечные циклы бессмысленны:
    # процесс «засыпает» и будет перезапущен.
    # Процесс будет перезапущен.
    if not settings.SERVERLESS:
        try:
            from backend.app.scheduler.check_ton_inbox import (
                start_check_ton_inbox_agent,
                stop_check_ton_inbox_agent,
            )
        except Exception:
            logger.warning(
                "startup: check_ton_inbox_agent не найден — "
                "пропускаем"
            )
            yield
            return

        try:
            await start_check_ton_inbox_agent()
            logger.info(
                "startup: check_ton_inbox_agent запущен "
                "(VPS mode)"
            )
        except Exception as e:
            logger.exception(
                "startup: не удалось запустить агента "
                "check_ton_inbox: %s",
                e
            )

        yield

        try:
            await stop_check_ton_inbox_agent()
        except Exception as e:
            logger.warning(
                "shutdown: ошибка остановки агента check_ton_inbox: %s",
                e
            )

    else:
        logger.info(
            "startup: SERVERLESS = true — фоновые агенты отключены; "
            "используйте /cron/tick"
        )
        yield


# ----------------------------------------------------------------------
# Приложение FastAPI
# ----------------------------------------------------------------------

app = FastAPI(title = getattr(settings, "PROJECT_NAME", "EFHC - Bot"),
    version = "1.0.0",
    docs_url = "/docs",
    redoc_url = "/redoc",
    lifespan = lifespan,)

app.add_middleware(CORSMiddleware,
    allow_origins = _build_cors_origins(),
    allow_credentials = True,
    allow_methods=[
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
    ],
    allow_headers=[
        "Authorization",
        "Content-Type",
        "Idempotency-Key",
        "X-Request-ID",
        "X-Telegram-Init-Data",
        "X-Telegram-User-Id",
        "X-Admin-Id",
        "X-Admin-Token",
        "X-Cron-Secret",
        "X-Telegram-Bot-Api-Secret-Token",
        "X-Event-Id",
        "X-Delivery-Id",
    ],
)

# ----------------------------------------------------------------------
# Security gate: Telegram WebApp initData → request.state.tg_id
# ----------------------------------------------------------------------
try:
    from backend.app.middleware.telegram_webapp_auth import (
        TelegramWebAppAuthMiddleware,
    )

    app.add_middleware(TelegramWebAppAuthMiddleware)
    logger.info("middleware: TelegramWebAppAuthMiddleware enabled")
except Exception as e:
    # Не блокируем запуск, но в этом случае
    # get_current_tg_id будет пытаться валидировать initData
    # валидировать initData в deps.py.
    logger.warning(
        "middleware: TelegramWebAppAuthMiddleware not enabled: %s",
        e
    )


# ----------------------------------------------------------------------
# Подключение HTTP-роутов (КАНОН)
# ----------------------------------------------------------------------

from backend.app.routes import register as register_routes

# Важно: не дублировать /api префиксы. Канон — без общего префикса.
register_routes(app, prefix = "")


# ----------------------------------------------------------------------
# Доп. health (быстрый снимок БД)
# ----------------------------------------------------------------------

@app.get("/meta/health_db", tags = ["meta"])
async def health_db() -> Dict[str, Any]:
    """Проверка доступности БД (полезно для мониторинга)."""
    try:
        async with async_session_maker() as db:
            await db.execute(text("SELECT 1"))
        return {"status": "ok"}
    except Exception as e:
        logger.exception("health_db: %s", e)
        return {"status": "error", "detail": str(e)}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "backend.app.main:app",
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        reload=True,
    )