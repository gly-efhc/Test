"""Точные D8-правила Панелей без доступа к базе.

OWNER 2026-10-21: универсальное списание цены 100 EFHC по
EFHCb -> EFHCm -> kWh (1:1 через EFHCm и ledger).
Защитная деактивация использует такую же текущую проводку,
а не историческое NET=100-R. R учитывается только при аннулировании
генерации и не ограничен ценой Панели. Историческая \
функция offset/refund удалена из исполняемого кода.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from app.standards.finance_rules import SpendBreakdown, d8

PANEL_PRICE_D8 = d8("100")
PROTECTIVELY_VOIDED_META_KEY = "protectively_voided"


@dataclass(frozen=True)
class ProtectiveVoidAmounts:
    """D8-результат аннулирования генерации одной Панели."""

    generated_kwh: Decimal
    available_kwh_before: Decimal
    unused_kwh: Decimal
    realized_kwh: Decimal
    reversal_price_efhc: Decimal


def calculate_protective_void_amounts(
    *,
    generated_kwh: Decimal,
    available_kwh: Decimal,
) -> ProtectiveVoidAmounts:
    """Рассчитать U/R для аннулирования и постоянную цену проводки."""

    generated = d8(generated_kwh)
    available = d8(available_kwh)
    if generated < Decimal("0") or available < Decimal("0"):
        raise ValueError("PANEL_PROTECTIVE_NEGATIVE_INPUT")

    unused = d8(min(generated, available))
    realized = d8(generated - unused)
    if realized < Decimal("0"):
        raise ValueError("PANEL_PROTECTIVE_REALIZED_OUT_OF_RANGE")

    return ProtectiveVoidAmounts(
        generated_kwh=generated,
        available_kwh_before=available,
        unused_kwh=unused,
        realized_kwh=realized,
        reversal_price_efhc=PANEL_PRICE_D8,
    )


def allocate_panel_payment_splits(
    *,
    panel_ids: list[int],
    spent_bonus: Decimal,
    spent_main: Decimal,
) -> dict[int, SpendBreakdown]:
    """Разложить batch-платёж на Panel ID в порядке создания.

    Канон оплаты всего batch — EFHCb -> EFHCm. Поэтому та же последовательность
    применяется к Панелям в ``panels_created_ids``: каждая цена 100 EFHC.
    """

    ids = [int(value) for value in panel_ids]
    if not ids or len(set(ids)) != len(ids):
        raise ValueError("PANEL_PAYMENT_IDS_INVALID")

    bonus_left = d8(spent_bonus)
    main_left = d8(spent_main)
    expected = d8(PANEL_PRICE_D8 * Decimal(len(ids)))
    if bonus_left < 0 or main_left < 0 or d8(bonus_left + main_left) != \
            expected:
        raise ValueError("PANEL_PAYMENT_TOTAL_MISMATCH")

    result: dict[int, SpendBreakdown] = {}
    for panel_id in ids:
        bonus_part = d8(min(bonus_left, PANEL_PRICE_D8))
        main_part = d8(PANEL_PRICE_D8 - bonus_part)
        if main_part > main_left:
            raise ValueError("PANEL_PAYMENT_ALLOCATION_MISMATCH")
        result[panel_id] = SpendBreakdown(
            bonus_part=bonus_part,
            main_part=main_part,
        )
        bonus_left = d8(bonus_left - bonus_part)
        main_left = d8(main_left - main_part)

    if bonus_left != d8("0") or main_left != d8("0"):
        raise ValueError("PANEL_PAYMENT_ALLOCATION_REMAINDER")
    return result


__all__ = [
    "PANEL_PRICE_D8",
    "PROTECTIVELY_VOIDED_META_KEY",
    "ProtectiveVoidAmounts",
    "allocate_panel_payment_splits",
    "calculate_protective_void_amounts",
]
