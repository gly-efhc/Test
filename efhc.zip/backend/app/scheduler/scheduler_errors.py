"""Совместимые исключения планировщика EFHC."""


class SchedulerError(Exception):
    """Базовая ошибка планировщика."""


class JobTimeout(SchedulerError):
    """Задача планировщика не уложилась в таймаут."""


__all__ = ["JobTimeout", "SchedulerError"]
