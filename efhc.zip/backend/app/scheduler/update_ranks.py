# backend/app/scheduler/update_ranks.py
# ======================================================================
# Назначение кода:
# Планировочная задача «пересчёт рейтинга» (Я + TOP).
#
# Канон:
# • Время — триггер. Пересчёт идёт по данным БД.
# • Результат фиксируется в ranks_snapshots.
# ======================================================================

from __future__ import annotations

from typing import Any

from app.core.database_core import async_session_maker_core
from app.core.logging_core import get_logger
from app.services.ranks_service import rebuild_rank_snapshot
from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = get_logger("efhc.scheduler.update_ranks")


class RanksJobSettings(BaseSettings):
    """Настройки батча рейтинга (алиасы для удобства на Vercel)."""

    RANKS_LIMIT_USERS: int = Field(
        default=200,
        validation_alias=AliasChoices(
            "RANKS_LIMIT_USERS",
            "SCHED_RANKS_LIMIT_USERS",
        ),
    )

    model_config = SettingsConfigDict(env_prefix="", extra="ignore")


S = RanksJobSettings()


async def run_once() -> dict[str, Any]:
    """Один проход пересчёта рейтинга."""

    async with async_session_maker_core() as db:
        meta = await rebuild_rank_snapshot(
            db,
            limit_users=int(S.RANKS_LIMIT_USERS),
        )

    logger.info(
        "update_ranks: snapshot_at=%s total_users=%s",
        meta.snapshot_at,
        meta.total_users,
    )
    return {
        "snapshot_at": meta.snapshot_at.isoformat(),
        "total_users": int(meta.total_users),
    }


__all__ = ["run_once"]

