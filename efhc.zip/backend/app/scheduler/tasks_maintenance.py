# -*- coding: utf-8 -*-
# backend/app/scheduler/tasks_maintenance.py
# ======================================================================
# Алиас для job_tasks_maintenance.py.
# Единая логика находится в tasks_autorestart.py.
# ======================================================================

from app.scheduler.tasks_autorestart import run_once

__all__ = ["run_once"]

