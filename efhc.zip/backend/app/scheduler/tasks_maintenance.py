"""Совместимый импорт обслуживания задач планировщика."""

from app.scheduler.tasks_autorestart import run_once

__all__ = ["run_once"]
