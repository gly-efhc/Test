"""Совместимый контекст API планировщика."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class TickContext:
    """Контекст времени запуска одного тика планировщика."""

    started_at: datetime


__all__ = ["TickContext"]
