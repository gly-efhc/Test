# -*- coding: utf-8 -*-
# backend/app/scheduler/bankstate_recalc.py
# ======================================================================
# Назначение кода:
# Пересчёт снимка состояния Банка EFHC (bank_state) из журнала операций
# efhc_transfers_log.
#
# Зачем:
# • При любых сбоях (ретраи, частичные тики) базовый источник правды —
# журнал операций. Снимок bank_state — это кэш.
# • Этот job возвращает bank_state в консистентное состояние.
#
# Канон:
# • Банк может быть отрицательным (политика дефицита), это НЕ ошибка.
# ======================================================================

from __future__ import annotations

from typing import Any

from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import text

from app.core.config_core import get_settings
from app.core.database_core import get_session
from app.core.logging_core import get_logger

logger = get_logger("efhc.scheduler.bankstate_recalc")


async def run_once() -> dict[str, Any]:
    """Пересчитать bank_state из efhc_transfers_log."""
    s = get_settings()
    schema = s.DB_SCHEMA_CORE
    bank_tg_id = int(s.BANK_TG_ID)

    async with get_session() as db:
        # Суммируем дебет/кредит банка по двум типам баланса.
        q = text(
            "\n".join(
                [
                    "WITH sums AS (",
                    "    SELECT",
                    "        balance_type,",
                    "        SUM(",
                    "            CASE",
                    "                WHEN "
                    "direction = 'credit' THEN amount",
                    "                ELSE - amount",
                    "            END",
                    "        ) AS bal",
                    f"    FROM {schema}.efhc_transfers_log",
                    "    WHERE tg_id = :bank_tg_id",
                    "    GROUP BY balance_type",
                    ")",
                    "SELECT",
                    "    COALESCE(",
                    "        (SELECT bal FROM sums",
                    "         WHERE balance_type = 'main'),",
                    "        0",
                    "    ) AS main_bal,",
                    "    COALESCE(",
                    "        (SELECT bal FROM sums",
                    "         WHERE balance_type = 'bonus'),",
                    "        0",
                    "    ) AS bonus_bal,",
                    "    COALESCE(",
                    "        (SELECT MAX(id)",
                    f"         FROM {schema}.efhc_transfers_log",
                    "         WHERE tg_id = :bank_tg_id),",
                    "        0",
                    "    ) AS last_id",
                ]
            )
        )
        row = (
            (await db.execute(q, {"bank_tg_id": bank_tg_id}))
            .mappings()
            .first()
            or {}
        )
        main_bal = Decimal(str(row.get("main_bal", 0)))
        bonus_bal = Decimal(str(row.get("bonus_bal", 0)))
        last_id = int(row.get("last_id", 0) or 0)

        now = datetime.now(timezone.utc)

        # Upsert bank_state.
        up = text(
            "\n".join(
                [
                    f"INSERT INTO {schema}.bank_state",
                    "    (",
                    "        bank_tg_id,",
                    "        balance_main,",
                    "        balance_bonus,",
                    "        last_recalc_log_id,",
                    "        last_recalc_at,",
                    "        created_at,",
                    "        updated_at",
                    "    )",
                    "VALUES",
                    "    (",
                    "        :bank_tg_id,",
                    "        :main_bal,",
                    "        :bonus_bal,",
                    "        :last_id,",
                    "        :now,",
                    "        :now,",
                    "        :now",
                    "    )",
                    "ON CONFLICT (bank_tg_id)",
                    "DO UPDATE SET",
                    "    balance_main = EXCLUDED.balance_main,",
                    "    balance_bonus = EXCLUDED.balance_bonus,",
                    "    last_recalc_log_id = "
                    "EXCLUDED.last_recalc_log_id,",
                    "    last_recalc_at = EXCLUDED.last_recalc_at,",
                    "    updated_at = EXCLUDED.updated_at",
                ]
            )
        )
        await db.execute(
            up,
            {
                "bank_tg_id": bank_tg_id,
                "main_bal": main_bal,
                "bonus_bal": bonus_bal,
                "last_id": last_id,
                "now": now,
            },
        )

    logger.info(
        "bankstate_recalc: bank_tg_id=%s main=%s bonus=%s last_id=%s",
        bank_tg_id,
        main_bal,
        bonus_bal,
        last_id,
    )
    return {
        "bank_tg_id": bank_tg_id,
        "balance_main": str(main_bal),
        "balance_bonus": str(bonus_bal),
        "last_recalc_log_id": last_id,
    }


__all__ = ["run_once"]

