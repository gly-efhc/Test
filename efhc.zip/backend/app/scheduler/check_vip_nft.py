# backend/app/scheduler/check_vip_nft.py
# ======================================================================
# Scheduler: check VIP by NFT ownership.
# ======================================================================

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from typing import Any, cast

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.services import nft_requests_service
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_settings()
logger = get_logger(__name__)

RETRY_ON_ERROR_SEC = 60
DEFAULT_BATCH_LIMIT = 1000


async def run_check_vip_nft_once(
    db: AsyncSession,
    *,
    batch_limit: int = DEFAULT_BATCH_LIMIT,
    force: bool = False,
) -> dict[str, Any]:
    """Один прогон due-записей через nft_requests_service."""
    if hasattr(nft_requests_service, "refresh_vip_status_due_batch"):
        fn = nft_requests_service.refresh_vip_status_due_batch
        typed_fn = cast(
            Callable[..., Awaitable[dict[str, Any]]],
            fn,
        )
        return await typed_fn(
            db,
            limit=batch_limit,
            force=force,
        )

    name = "refresh_vip_status_for_due_users"
    if hasattr(nft_requests_service, name):
        fn = nft_requests_service.refresh_vip_status_for_due_users
        typed_fn = cast(
            Callable[..., Awaitable[dict[str, Any]]],
            fn,
        )
        return await typed_fn(
            db,
            limit=batch_limit,
            force=force,
        )

    if hasattr(nft_requests_service, "check_vip_nft_due_batch"):
        fn = nft_requests_service.check_vip_nft_due_batch
        typed_fn = cast(
            Callable[..., Awaitable[dict[str, Any]]],
            fn,
        )
        return await typed_fn(
            db,
            limit=batch_limit,
            force=force,
        )

    raise RuntimeError(
        "nft_requests_service API не найден: ожидались "
        "refresh_vip_status_due_batch / "
        "refresh_vip_status_for_due_users / "
        "check_vip_nft_due_batch"
    )


async def scheduler_tick_check_vip_nft(
    db: AsyncSession,
) -> dict[str, Any]:
    """Один тик: обрабатываем due батчами."""
    t0 = time.monotonic()
    total_processed = 0
    total_updated = 0
    batches = 0
    last_step: dict | None = None

    while True:
        step = await run_check_vip_nft_once(
            db,
            batch_limit=DEFAULT_BATCH_LIMIT,
            force=False,
        )
        last_step = step
        batches += 1

        processed = int(step.get("processed", 0))
        updated = int(step.get("updated", 0))
        total_processed += processed
        total_updated += updated

        left = int(step.get("left", 0))
        if processed <= 0 and left <= 0:
            break

        await asyncio.sleep(0)

    took_ms = int((time.monotonic() - t0) * 1000)
    return {
        "total_processed": total_processed,
        "total_updated": total_updated,
        "batches": batches,
        "last_step": last_step or {},
        "took_ms": took_ms,
    }


async def scheduler_task_check_vip_nft(
    session_factory: Callable[[], AsyncSession],
    stop_event: asyncio.Event | None = None,
) -> None:
    """Фоновый цикл тиков; при ошибках — лог + пауза + следующий тик."""
    if settings.SCHEDULER_TICK_SECONDS:
        tick_sec = int(settings.SCHEDULER_TICK_SECONDS)
    else:
        tick_sec = 600

    logger.info(
        "VIP NFT checker started: tick=%ss, batch_limit=%s",
        tick_sec,
        DEFAULT_BATCH_LIMIT,
    )

    while True:
        t_loop_start = time.monotonic()
        try:
            async with session_factory() as db:
                stats = await scheduler_tick_check_vip_nft(db)
                await db.commit()
                logger.info(
                    "VIP NFT tick ok: processed=%s updated=%s "
                    "batches=%s took=%sms",
                    stats.get("total_processed"),
                    stats.get("total_updated"),
                    stats.get("batches"),
                    stats.get("took_ms"),
                )
        except asyncio.CancelledError:
            logger.warning("VIP NFT checker cancelled")
            break
        except Exception as e:
            logger.warning(
                "VIP NFT tick failed: %s",
                e,
                exc_info=settings.is_dev,
            )
            await asyncio.sleep(RETRY_ON_ERROR_SEC)

        elapsed = time.monotonic() - t_loop_start
        sleep_for = max(1.0, tick_sec - elapsed)

        if stop_event is not None and stop_event.is_set():
            logger.info("VIP NFT checker stop requested")
            break

        await asyncio.sleep(sleep_for)


async def run_once() -> dict[str, Any]:
    """Serverless entrypoint: один тик проверки VIP NFT."""
    from app.deps import get_db

    async for db in get_db():
        stats = await scheduler_tick_check_vip_nft(db)
        await db.commit()
        return stats

    return {
        "total_processed": 0,
        "total_updated": 0,
        "batches": 0,
        "last_step": {},
        "took_ms": 0,
    }


__all__ = [
    "run_once",
    "run_check_vip_nft_once",
    "scheduler_tick_check_vip_nft",
    "scheduler_task_check_vip_nft",
]
