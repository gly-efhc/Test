# -*- coding: utf-8 -*-
# backend/app/scheduler/__init__.py
"""Пакет планировщика (serverless - friendly)."""


__all__ = []
