# backend/app/scheduler/init.py
"""Пакет планировщика (serverless - friendly)."""

__all__ = []
