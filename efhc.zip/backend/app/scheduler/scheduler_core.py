"""Совместимый фасад единого тика канонического планировщика."""

from __future__ import annotations

from app.services.scheduler_service import SchedulerService


async def tick() -> None:
    """Запустить один тик через действующий ``SchedulerService``."""
    await SchedulerService().run_single_tick()


__all__ = ["tick"]
