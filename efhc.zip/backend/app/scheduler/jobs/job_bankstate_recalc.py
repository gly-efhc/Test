# -*- coding: utf-8 -*-
# backend/app/scheduler/jobs/job_bankstate_recalc.py
# ======================================================================
# Bridge-job: вызывает run_once() из scheduler.bankstate_recalc.
# ======================================================================

from __future__ import annotations

from backend.app.scheduler.bankstate_recalc import run_once
