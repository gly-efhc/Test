# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# Назначение кода:
# Bridge-job: вызывает run_once() из
# app.scheduler.process_withdrawals.
# ----------------------------------------------------------------------

from __future__ import annotations

from app.scheduler.process_withdrawals import run_once
