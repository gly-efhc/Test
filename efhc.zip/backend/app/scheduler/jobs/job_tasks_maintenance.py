# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------
# Назначение кода:
# Bridge-job: вызывает run_once() из
# backend.app.scheduler.tasks_maintenance.
# ---------------------------------------------------------------------

from __future__ import annotations

from app.scheduler.tasks_maintenance import run_once
