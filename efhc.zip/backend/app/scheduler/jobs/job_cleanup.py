# -*- coding: utf-8 -*-
# ======================================================================
# Bridge-job: вызывает run_once() из
# app.scheduler.archive_panels.
# ======================================================================

from __future__ import annotations

from app.scheduler.archive_panels import run_once

