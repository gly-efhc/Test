# backend/app/__init__.py
# ======================
# Инициализация серверной части EFHC Bot.
# Создаёт FastAPI app, подключает middleware/роутеры и хендлеры ошибок.

from __future__ import annotations

import logging
from collections.abc import AsyncIterator, Iterable
from contextlib import AsyncExitStack, asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.types import Lifespan

# ВАЖНО (Lock: packages importable)
# Этот модуль не должен выполнять тяжёлую инициализацию на этапе import.
# Зависимости (settings/logging/router) импортируются лениво.
# Точка входа: create_app().

# Зависимость для health/ping БД импортируем лениво внутри обработчика.
# Это позволяет импортировать пакет без настроек окружения и без БД.
_db_ping = None


def _build_description() -> str:
    """Текстовое описание API для Swagger UI/Redoc."""
    return (
        "EFHC Bot API — серверная часть экосистемы EFHC:\n\n"
        " - Панели, баланс, обмен kWh→EFHC (1:1)\n"
        " - Магазин: покупки за TON/USDT/EFHC, заявки на VIP NFT\n"
        " - Реферальная система и лотереи\n"
        " - Админ-панель (банк EFHC, товары, заказы,"
        " ставки генерации)\n"
    )


def _install_middlewares(
    app: FastAPI,
    origins: Iterable[str],
    trusted_hosts: Iterable[str],
    gzip_min_size: int,
) -> None:
    """Подключение middleware: CORS, GZip, TrustedHosts."""
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(origins),
        allow_credentials=True,
        allow_methods=[
            "GET",
            "POST",
            "PUT",
            "PATCH",
            "DELETE",
            "OPTIONS",
        ],
        allow_headers=[
            "Authorization",
            "Content-Type",
            "Idempotency-Key",
            "X-Request-ID",
            "X-Telegram-Init-Data",
            "X-Telegram-User-Id",
            "X-Admin-Id",
            "X-Admin-Token",
            "X-Cron-Secret",
            "X-Telegram-Bot-Api-Secret-Token",
            "X-Event-Id",
            "X-Delivery-Id",
        ],
        expose_headers=["Content-Disposition"],
        max_age=600,
    )

    app.add_middleware(GZipMiddleware, minimum_size=gzip_min_size)

    hosts = [h for h in trusted_hosts if h.strip()]
    if hosts:
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)


def _install_exception_handlers(app: FastAPI) -> None:
    """Единые обработчики ошибок с JSON-ответом."""

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        _: Request,
        exc: RequestValidationError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={
                "ok": False,
                "error": "validation_error",
                "details": exc.errors(),
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(
        _: Request,
        exc: Exception,
    ) -> JSONResponse:
        logging.getLogger("efhc").exception(
            "Unhandled error",
            exc_info=exc,
        )
        return JSONResponse(
            status_code=500,
            content={"ok": False, "error": "internal_error"},
        )


def _lifespan() -> Lifespan[FastAPI]:
    """Lifespan (startup/shutdown) через AsyncExitStack."""

    @asynccontextmanager
    async def _inner(app: FastAPI) -> AsyncIterator[None]:
        _ = app
        stack = AsyncExitStack()
        await stack.__aenter__()
        try:
            yield
        finally:
            await stack.aclose()

    return _inner


def _install_basic_routes(app: FastAPI) -> None:
    """Служебные маршруты: root/healthz."""

    @app.get("/", tags=["public"])
    async def root() -> dict:
        return {
            "ok": True,
            "service": app.title,
            "version": app.version,
        }

    @app.get("/healthz", tags=["public"])
    async def healthz() -> dict:
        global _db_ping

        if _db_ping is None:
            try:
                from .deps import db_ping as ping  # type: ignore

                _db_ping = ping
            except Exception:
                _db_ping = None

        if _db_ping:
            try:
                from .db import AsyncSessionFactory

                async with AsyncSessionFactory() as session:
                    result = await _db_ping(session)  # type: ignore
                return {"ok": True, "db": result.get("db", "unknown")}
            except Exception:
                return {"ok": False, "db": "fail"}

        return {"ok": True}


def create_app() -> FastAPI:
    """Фабрика FastAPI-приложения."""
    try:
        from .core.config_core import get_settings
        from .core.logging_core import configure_logging
        from .routes import api_router  # type: ignore
    except Exception as exc:
        msg = (
            "Не удалось импортировать зависимости приложения "
            "(settings/logging/router)."
        )
        raise RuntimeError(msg) from exc

    settings = get_settings()

    configure_logging(level=settings.LOG_LEVEL)

    app = FastAPI(
        title="EFHC Bot API",
        description=_build_description(),
        version=settings.APP_VERSION,
        openapi_url=settings.OPENAPI_URL,
        docs_url=settings.DOCS_URL,
        redoc_url=settings.REDOC_URL,
        lifespan=_lifespan(),
    )

    _install_middlewares(
        app=app,
        origins=settings.CORS_ORIGINS,
        trusted_hosts=settings.TRUSTED_HOSTS,
        gzip_min_size=settings.GZIP_MIN_BYTES,
    )

    _install_exception_handlers(app)
    _install_basic_routes(app)

    app.include_router(api_router, prefix=settings.API_PREFIX)

    app.state.settings = settings
    app.state.logger = logging.getLogger("efhc")

    return app


# ВАЖНО: не создаём app на этапе import.
# Entry point: app.main:app

def __getattr__(name: str):
    """Lazy exports for tests.

    Tests may import `services` from `backend.app`.
    We expose it lazily to avoid heavy imports at module import time.
    """
    if name == "services":
        from . import services as _services  # type: ignore
        return _services
    raise AttributeError(name)


__all__ = ["create_app", "services"]