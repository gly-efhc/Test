# -*- coding: utf-8 -*-
# backend/app/schemas/common_schemas.py
# ======================================================================
# Базовые Pydantic-схемы EFHC Bot:
# - курсорная пагинация;
# - сериализация Decimal наружу как строка d8 (ROUND_DOWN);
# - типовые формы ok/error.
# ======================================================================

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN, InvalidOperation

ZERO_D8 = Decimal("0.00000000")
from typing import Any, Generic, List, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field, field_validator

EFHC_DECIMALS: int = 8
_Q8 = Decimal(1).scaleb(-EFHC_DECIMALS)  # Decimal("0.00000001")


def utcnow_iso() -> str:
    """UTC now as ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _to_decimal_q8(x: Any) -> Decimal:
    """Coerce to Decimal and quantize to d8 using ROUND_DOWN."""
    try:
        d = Decimal(str(x))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Некорректное числовое значение")
    return d.quantize(_Q8, rounding=ROUND_DOWN)


def d8_str(x: Any) -> str:
    """Serialize as Decimal d8 string (ROUND_DOWN)."""
    return str(_to_decimal_q8(x))


class ErrorResponse(BaseModel):
    """Стандартная форма ошибки для фронтенда."""

    code: str = Field(
        ...,
        description="Короткий код ошибки (snake-case)",
    )
    detail: str = Field(
        ...,
        description="Человеко-читаемое описание проблемы",
    )


class OkMeta(BaseModel):
    """Мета об успешной обработке."""

    ok: bool = Field(True, description="Флаг успешной операции")
    server_time: str = Field(
        default_factory=utcnow_iso,
        description="UTC время формирования ответа (ISO-8601)",
    )


T = TypeVar("T")


class CursorPage(BaseModel, Generic[T]):
    """Курсорная страница списка (без OFFSET)."""

    items: List[T] = Field(
        ...,
        description="Элементы текущей страницы",
    )
    next_cursor: Optional[str] = Field(
        None,
        description="Курсор следующей страницы или None",
    )
    etag: Optional[str] = Field(
        None,
        description="Опциональный ETag ответа",
    )
    server_time: str = Field(
        default_factory=utcnow_iso,
        description="UTC время формирования ответа (ISO-8601)",
    )


class MoneyStr(BaseModel):
    """Денежное значение EFHC как строка d8."""

    value: str = Field(
        ...,
        description="Строка с 8 знаками после запятой",
    )

    @field_validator("value", mode="before")
    def _norm(cls, v: Any) -> str:
        return d8_str(v)


class EnergyStr(BaseModel):
    """Энергия (кВт·ч) как строка d8."""

    value: str = Field(
        ...,
        description="КВт·ч строкой с 8 знаками",
    )

    @field_validator("value", mode="before")
    def _norm(cls, v: Any) -> str:
        return d8_str(v)


class BalancePair(BaseModel):
    """Пара балансов пользователя (main/bonus) как строки d8."""

    main_balance: str = Field(
        ...,
        description="Основной баланс EFHC (str d8)",
    )
    bonus_balance: str = Field(
        ...,
        description="Бонусный баланс EFHC (str d8)",
    )

    @field_validator("main_balance", "bonus_balance", mode="before")
    def _norm(cls, v: Any) -> str:
        return d8_str(v)


class EnergyPair(BaseModel):
    """Раздельный учёт энергии как строки d8."""


    total_generated_kwh: str = Field(
        ...,
        description="Всего сгенерировано (кВт·ч), str d8",
    )
    available_kwh: str = Field(
        ...,
        description="Доступно для обмена (кВт·ч), str d8",
    )

    _FIELDS = ("total_generated_kwh", "available_kwh")

    @field_validator(*_FIELDS, mode="before")
    def _norm(cls, v: Any) -> str:
        return d8_str(v)


class VipFlags(BaseModel):
    """Мини-набор флагов статуса пользователя."""

    is_vip: bool = Field(
        ...,
        description="VIP по наличию NFT из коллекции",
    )


class StrictIn(BaseModel):
    """База для входящих DTO.

    Запрещает неизвестные поля (mass assignment).
    """

    model_config = ConfigDict(extra="forbid")


class IdempotencyContract(StrictIn):
    """Контракт идемпотентности для денежных POST."""

    client_nonce: Optional[str] = Field(
        None,
        description="Опциональный нонс клиента для трассировки",
    )


class PanelCard(BaseModel):
    """Карточка панели (активной/архивной)."""

    panel_id: int = Field(..., description="ID панели")
    is_active: bool = Field(..., description="Активность")
    created_at: str = Field(..., description="ISO-время создания")
    expires_at: Optional[str] = Field(
        None,
        description="ISO-время истечения (для активной)",
    )
    closed_at: Optional[str] = Field(
        None,
        description="ISO-время закрытия (для архивной)",
    )
    base_gen_per_sec: str = Field(
        ...,
        description="Ставка генерации, кВт·ч/сек (str d8)",
    )
    generated_kwh: str = Field(
        ...,
        description="Сгенерировано панелью, кВт·ч (str d8)",
    )

    @field_validator("base_gen_per_sec", "generated_kwh", mode="before")
    def _norm_decimals(cls, v: Any) -> str:
        return d8_str(v)


class ExchangePreviewDTO(BaseModel):
    """Предпросмотр обмена kWh→EFHC (ничего не списывает)."""

    ok: bool = Field(..., description="Можно ли выполнить обмен")
    available_kwh: str = Field(
        ...,
        description="Доступная энергия (кВт·ч), str d8",
    )
    max_exchangeable_kwh: str = Field(
        ...,
        description="Максимум к обмену (кВт·ч), str d8",
    )
    rate_kwh_to_efhc: str = Field(
        ...,
        description="Фиксированный курс 1.00000000",
    )
    detail: str = Field(
        ...,
        description="Подсказка/причина",
    )
