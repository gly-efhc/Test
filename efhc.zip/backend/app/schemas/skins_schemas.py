# -*- coding: utf-8 -*-
"""backend/app/schemas/skins_schemas.py

Pydantic схемы домена «Skins».
"""

from __future__ import annotations

from datetime import datetime
from pydantic import Field
from app.schemas.common_schemas import EfhcBaseModel


class SkinItem(EfhcBaseModel):
    skin_id: int = Field(..., ge=1)
    title: str
    price_efhc: str
    asset_path: str


class SkinsCatalogOut(EfhcBaseModel):
    items: list[SkinItem]


class MySkin(EfhcBaseModel):
    skin_id: int = Field(..., ge=1)
    purchased_at: datetime


class SkinsMyOut(EfhcBaseModel):
    active_skin_id: int = Field(..., ge=1)
    owned: list[MySkin]
