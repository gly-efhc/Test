# -*- coding: utf-8 -*-
"""backend/app/schemas/skins_schemas.py

Pydantic схемы домена «Skins».
"""

from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field


class SkinItem(BaseModel):
    skin_id: int = Field(..., ge=1)
    title: str
    price_efhc: str
    asset_path: str


class SkinsCatalogOut(BaseModel):
    items: list[SkinItem]


class MySkin(BaseModel):
    skin_id: int = Field(..., ge=1)
    purchased_at: datetime


class SkinsMyOut(BaseModel):
    active_skin_id: int = Field(..., ge=1)
    owned: list[MySkin]
