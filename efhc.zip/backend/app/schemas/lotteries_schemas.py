# backend/app/schemas/lotteries_schemas.py
# ======================================================================
# EFHC Bot — Lotteries (витрина и покупка билетов)
# ----------------------------------------------------------------------
# Назначение:
# Pydantic-схемы публичного API для подсистемы lotteries.
#
# Канон/инварианты:
# • Публичный слой не содержит tg_id — только tg_id.
# • Денежные значения: строка с d8 (Decimal(30,8) ROUND_DOWN) на уровне
# сервисов.
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any

from app.schemas.common_schemas import EfhcBaseModel, StrictIn
from pydantic import Field


class LotteriesOut(EfhcBaseModel):
    id: int
    title: str
    prize_type: str
    prize_value: str
    ticket_price: str
    total_tickets: int
    tickets_sold: int
    status: str
    created_at: datetime


class PaginatedLotteriesOut(EfhcBaseModel):
    items: list[LotteriesOut]
    next_cursor: str | None = None


class LotteriesResultOut(EfhcBaseModel):
    winning_ticket_id: int
    winner_tg_id: int
    winner_username: str | None = None
    winning_ticket_number: int | None = None
    completed_at: str


class LotteriestatusOut(EfhcBaseModel):
    id: int
    title: str
    prize_type: str
    prize_value: str
    ticket_price: str
    total_tickets: int
    tickets_sold: int
    status: str
    result: LotteriesResultOut | None = None


class LotteriesHistoryOut(EfhcBaseModel):
    """Элемент истории lotteries для админ‑витрины.

    С победителем/результатом, если lotteries завершён.
    """

    id: int
    title: str
    prize_type: str
    prize_value: str
    ticket_price: str
    total_tickets: int
    tickets_sold: int
    status: str
    created_at: datetime
    result: LotteriesResultOut | None = None


class PaginatedLotteriesHistoryOut(EfhcBaseModel):
    items: list[LotteriesHistoryOut]
    next_cursor: str | None = None


class PaginatedTicketsOut(EfhcBaseModel):
    items: list[int]
    next_cursor: str | None = None


class BuyTicketsIn(StrictIn):
    qty: int = Field(
        ...,
        ge=1,
        le=10,
        description="Количество билетов",
    )
    wallet_address: str | None = Field(
        None,
        description=(
            "TON-кошелёк для NFT-приза (если у пользователя "
            "ещё не привязан)"
        ),
    )


class BuyTicketsOut(EfhcBaseModel):
    lotteries_id: int
    qty: int
    ticket_ids: list[int]
    total_cost_efhc: str
    debit_bonus_efhc: str
    debit_main_efhc: str
    bank_log_bonus_id: int | None = None
    bank_log_main_id: int | None = None
    meta: dict[str, Any] | None = None


class LatestWinnerOut(EfhcBaseModel):
    lotteries_id: int
    title: str
    prize_type: str
    prize_value: str
    winning_ticket_id: int
    winning_ticket_number: int | None = None
    winner_tg_id: int
    winner_username: str | None = None
    completed_at: str


class LatestWinnersOut(EfhcBaseModel):
    efhc: LatestWinnerOut | None = None
    vip: LatestWinnerOut | None = None
