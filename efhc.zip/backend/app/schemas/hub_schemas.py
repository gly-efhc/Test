from __future__ import annotations

from datetime import datetime
from typing import Literal

from app.schemas.common_schemas import EfhcBaseModel
from pydantic import Field


class HubEfhcHandoffOut(EfhcBaseModel):
    """Ответ Hub handoff для внешнего контура покупки EFHC."""

    redirect_url: str = Field(
        ...,
        description="Signed external URL for EFHC buy-flow",
    )
    expires_at: datetime = Field(
        ...,
        description="UTC expiration timestamp for handoff token",
    )
    transport: Literal["external_url"] = "external_url"
    mode: Literal["signed_token"] = "signed_token"



class BrowserShopBootstrapOut(EfhcBaseModel):
    """Bootstrap contract for the external browser-shop shell."""

    mode: Literal["guest", "handoff_bound"] = Field(
        ...,
        description=(
            "Guest browser entry or signed "
            "handoff-bound entry."
        ),
    )
    tg_linked: bool = Field(
        ...,
        description=(
            "Whether Telegram identity is "
            "already bound at entry."
        ),
    )
    tg_id: int | None = Field(
        default=None,
        description=(
            "Telegram ID from signed handoff token, "
            "if available."
        ),
    )
    wallet_linked: bool = Field(
        ...,
        description="Whether an active wallet binding already exists.",
    )
    active_wallet_address: str | None = Field(
        default=None,
        description="Current active wallet address if available.",
    )
    wallet_sync_required: bool = Field(
        ...,
        description="Whether wallet sync action may still be required.",
    )
    bot_open_url: str | None = Field(
        default=None,
        description="Simple bot-open URL if configured.",
    )
    telegram_sync_url: str | None = Field(
        default=None,
        description="Telegram sync entry URL if configured.",
    )
    wallet_sync_url: str | None = Field(
        default=None,
        description="Wallet sync entry URL if configured.",
    )
    storefront_mode: Literal["browser_shop_mvp"] = "browser_shop_mvp"
    usdt_checkout_mode: str = "disabled"



class BrowserShopCatalogItemOut(EfhcBaseModel):
    sku: str
    title: str
    description: str | None = None
    item_type: str
    ton_enabled: bool = False
    methods: dict[str, object] | None = None


class BrowserShopCatalogOut(EfhcBaseModel):
    items: list[BrowserShopCatalogItemOut]



class BrowserShopCreateIntentIn(EfhcBaseModel):
    token: str | None = None
    sku: str
    quantity: int = Field(default=1, ge=1)
    pay_method: str = Field(
        ...,
        description="TON or USDT.",
    )
    custom_efhc_amount_d8: str | None = Field(
        default=None,
        description="Required for CUSTOM_EFHC intent creation.",
    )
    client_nonce: str | None = Field(
        default=None,
        min_length=1,
        max_length=128,
    )


class BrowserShopCreateIntentOut(EfhcBaseModel):
    tg_id: int
    intent_id: int
    order_id: int
    item_type: str
    pay_method: str
    amount: str
    memo: str
    to_wallet: str
    tonconnect_tx: dict[str, object] | None = None
    tonconnect_transport_kind: str | None = None
    jetton_master_address: str | None = None
    jetton_decimals: int | None = None
    forward_payload_text: str | None = None
    fee_message_ton_amount: str | None = None
    forward_ton_amount: str | None = None
    recipient_strategy: str | None = None
    usdt_checkout_mode: str | None = None
