# -*- coding: utf-8 -*-
# backend/app/schemas/tasks_schemas.py
# ----------------------------------------------------------------------
# Pydantic-схемы для задач и отправок выполнения.
# ----------------------------------------------------------------------

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    HttpUrl,
    conint,
    constr,
    field_validator,
)

from backend.app.schemas.common_schemas import (
    CursorPage,
    IdempotencyContract,
    OkMeta,
    d8_str,
)

TaskTypeStr = constr(strip_whitespace=True, min_length=1, max_length=50)
TaskTitleStr = constr(
    strip_whitespace=True,
    min_length=1,
    max_length=255,
)
ProofTypeStr = constr(strip_whitespace=True, max_length=50)
ProofHintStr = constr(strip_whitespace=True, max_length=255)
StatusStr = constr(strip_whitespace=True, max_length=32)


class TaskBase(BaseModel):
    """Базовое описание задания (create/update)."""

    code: constr(strip_whitespace=True, min_length=1, max_length=64)
    title: TaskTitleStr
    description: Optional[str] = None
    type: TaskTypeStr = "custom"
    active: bool = True

    reward_bonus_efhc: Decimal = Field(Decimal("0.00000000"))
    price_usd_hint: Optional[Decimal] = None

    limit_per_user: conint(ge=0) = 1
    total_limit: Optional[conint(ge=0)] = None

    proof_type: Optional[ProofTypeStr] = None
    proof_hint: Optional[ProofHintStr] = None

    model_config = ConfigDict(extra="ignore")


class TaskCreate(TaskBase):
    """Создание задания (админ)."""


class TaskUpdate(BaseModel):
    """Изменение задания (админ). Все поля опциональны."""

    title: Optional[TaskTitleStr] = None
    description: Optional[str] = None
    type: Optional[TaskTypeStr] = None
    active: Optional[bool] = None
    reward_bonus_efhc: Optional[Decimal] = None
    price_usd_hint: Optional[Decimal] = None
    limit_per_user: Optional[conint(ge=0)] = None
    total_limit: Optional[conint(ge=0)] = None
    proof_type: Optional[ProofTypeStr] = None
    proof_hint: Optional[ProofHintStr] = None

    model_config = ConfigDict(extra="ignore")


class TaskOut(BaseModel):
    """Витринная карточка задания (денежные поля: str, 8)."""

    id: int
    code: str
    title: str
    description: Optional[str] = None
    type: str
    active: bool

    reward_bonus_efhc: str
    price_usd_hint: Optional[str] = None

    limit_per_user: int
    total_limit: Optional[int] = None

    performed_count: int
    created_at: datetime
    updated_at: datetime

    @field_validator(
        "reward_bonus_efhc",
        "price_usd_hint",
        mode="before",
    )
    def _q8(cls, v: Any) -> Optional[str]:
        if v is None:
            return None
        return d8_str(v)

    model_config = ConfigDict(extra="ignore")


TasksPage = CursorPage[TaskOut]


class TasksQueryIn(BaseModel):
    """Параметры курсорного листинга задач."""

    next_cursor: Optional[str] = Field(
        None,
        description="Курсор следующей страницы (base64).",
    )
    limit: Optional[conint(ge=1, le=200)] = Field(
        None,
        description="Размер страницы (1..200).",
    )
    only_active: Optional[bool] = Field(
        None,
        description="Если true - только активные задания.",
    )

    model_config = ConfigDict(extra="ignore")


class SubmissionCreate(BaseModel):
    """Пользователь отправляет выполнение задания."""

    proof_text: Optional[str] = None
    proof_url: Optional[HttpUrl] = None

    model_config = ConfigDict(extra="ignore")


class SubmissionOut(BaseModel):
    """Витринная карточка отправки (reward_amount_efhc - str, 8)."""

    id: int
    task_id: int
    user_tg_id: int
    status: str
    proof_text: Optional[str] = None
    proof_url: Optional[str] = None

    reward_amount_efhc: str
    paid: bool
    paid_tx_id: Optional[int] = None
    moderator_tg_id: Optional[int] = None

    created_at: datetime
    updated_at: datetime

    @field_validator("reward_amount_efhc", mode="before")
    def _q8(cls, v: Any) -> str:
        return d8_str(v)

    model_config = ConfigDict(extra="ignore")


SubmissionsPage = CursorPage[SubmissionOut]


class SubmissionsQueryIn(BaseModel):
    """Параметры курсорного листинга отправок."""

    next_cursor: Optional[str] = Field(
        None,
        description="Курсор следующей страницы (base64).",
    )
    limit: Optional[conint(ge=1, le=200)] = Field(
        None,
        description="Размер страницы (1..200).",
    )
    status: Optional[StatusStr] = None

    model_config = ConfigDict(extra="ignore")


class SubmissionModerateIn(IdempotencyContract):
    """Решение по заявке (approve=True -> выплата через банк)."""

    approve: bool
    moderator_tg_id: int
    reward_override_efhc: Optional[Decimal] = None


class TasksSyncOut(BaseModel):
    """Служебная синхронизация витрины задач."""

    meta: OkMeta = Field(default_factory=OkMeta)
    refreshed: int = Field(..., ge=0, description="Сколько освежено.")
    errors: int = Field(..., ge=0, description="Сколько ошибок.")
    note: Optional[str] = Field(
        None,
        description="Короткий комментарий ('ok'/'partial').",
    )

    model_config = ConfigDict(extra="ignore")


class SubmissionsSyncOut(BaseModel):
    """Служебная синхронизация витрины отправок."""

    meta: OkMeta = Field(default_factory=OkMeta)
    refreshed: int = Field(..., ge=0)
    errors: int = Field(..., ge=0)
    note: Optional[str] = None

    model_config = ConfigDict(extra="ignore")
