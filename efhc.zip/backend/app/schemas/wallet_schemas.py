from __future__ import annotations

from datetime import datetime

from app.schemas.common_schemas import CursorPage, EfhcBaseModel
from pydantic import Field


class WalletItemOut(EfhcBaseModel):
    id: int
    wallet_address: str
    wallet_app: str | None
    is_primary: bool
    is_active: bool
    created_at: str


class WalletMeOut(EfhcBaseModel):
    is_connected: bool
    wallets: list[WalletItemOut]


class WalletConnectIn(EfhcBaseModel):
    address: str = Field(..., min_length=1, max_length=256)
    wallet_app: str | None = Field(default=None, max_length=32)


class WalletConnectOut(EfhcBaseModel):
    wallet_id: int
    wallet_address: str
    is_connected: bool


class WalletBalanceHistoryItem(EfhcBaseModel):
    id: int
    amount_efhc: str
    direction: str
    balance_type: str
    reason: str
    created_at: datetime


WalletBalanceHistoryOut = CursorPage[WalletBalanceHistoryItem]
