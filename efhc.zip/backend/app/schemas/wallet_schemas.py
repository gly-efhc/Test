from __future__ import annotations

from datetime import datetime

from app.schemas.common_schemas import CursorPage, EfhcBaseModel
from pydantic import Field


class WalletItemOut(EfhcBaseModel):
    id: int
    wallet_address: str
    wallet_app: str | None
    is_primary: bool
    is_active: bool
    created_at: str


class WalletMeOut(EfhcBaseModel):
    is_connected: bool
    wallets: list[WalletItemOut]


class WalletConnectIn(EfhcBaseModel):
    address: str = Field(..., min_length=1, max_length=256)
    wallet_app: str | None = Field(default=None, max_length=32)
    payload_token: str = Field(..., min_length=20, max_length=2048)
    proof: WalletTonProofProofIn
    public_key: str | None = Field(default=None, max_length=256)
    network: str | None = Field(default=None, max_length=32)


class WalletConnectOut(EfhcBaseModel):
    wallet_id: int
    wallet_address: str
    is_connected: bool


class WalletBalanceHistoryItem(EfhcBaseModel):
    id: int
    amount_efhc: str
    direction: str
    balance_type: str
    reason: str
    created_at: datetime


WalletBalanceHistoryOut = CursorPage[WalletBalanceHistoryItem]


class WalletTonProofPayloadOut(EfhcBaseModel):
    ton_proof_payload: str
    payload_token: str
    expires_at: datetime
    domain: str


class WalletTonProofDomainIn(EfhcBaseModel):
    lengthBytes: int
    value: str


class WalletTonProofProofIn(EfhcBaseModel):
    timestamp: int
    domain: WalletTonProofDomainIn
    signature: str
    payload: str
    state_init: str | None = None


class WalletTonProofCheckIn(EfhcBaseModel):
    address: str = Field(..., min_length=20, max_length=256)
    payload_token: str = Field(..., min_length=20, max_length=2048)
    proof: WalletTonProofProofIn
    network: str | None = Field(default=None, max_length=32)
    public_key: str | None = Field(default=None, max_length=256)


class WalletTonProofCheckOut(EfhcBaseModel):
    accepted: bool
    cryptographically_verified: bool
    reason: str
