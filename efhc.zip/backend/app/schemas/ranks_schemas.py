# -*- coding: utf-8 -*-
# backend/app/schemas/ranks_schemas.py
# ======================================================================
# Pydantic-схемы витрины рейтинга: строки, запрос, админ rebuild.
# ======================================================================

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, List, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    conint,
    constr,
    field_validator,
)

from app.deps import d8
from app.schemas.common_schemas import CursorPage, OkMeta


def d8_str(v: Any) -> str:
    """Строковое представление Decimal(8) для схем."""
    return str(d8(v))


class RanksRowOut(BaseModel):
    """Строка рейтинга (один пользователь)."""

    model_config = ConfigDict(extra="ignore")

    position: conint(ge=1) = Field(
        ...,
        description="Позиция в рейтинге (1-based)",
    )
    user_tg_id: int = Field(
        ...,
        description="ID пользователя Telegram",
    )
    username: Optional[
        constr(strip_whitespace=True, max_length=64)
    ] = Field(
        None,
        description="Никнейм (если известен)",
    )
    total_generated_kwh: Decimal = Field(
        ...,
        description="Тотал энергии (кВт·ч), Decimal d8",
    )
    is_me: bool = Field(
        False,
        description="True, если это текущий пользователь",
    )

    @field_validator("total_generated_kwh", mode="before")
    def _q8(cls, v: Decimal) -> Decimal:
        return d8(v)


class RanksQueryIn(BaseModel):
    """Параметры запроса рейтинга."""

    top_limit: conint(ge=1, le=100) = Field(
        100,
        description="Размер top-среза 1..100",
    )
    force_refresh: bool = Field(
        False,
        description="Принудительно обновить кэш/снимок",
    )
    cursor: Optional[str] = Field(
        None,
        description="Курсор продолжения",
    )


class RanksSnapshotMetaOut(BaseModel):
    """Метаданные последнего снимка/кэша."""

    snapshot_at: datetime
    item_count: int = Field(
        ...,
        description="Сколько строк в кэше",
    )


class AdminRebuildRanksIn(BaseModel):
    """Админский запуск пересчёта рейтинга."""

    reason: Optional[
        constr(strip_whitespace=True, max_length=200)
    ] = Field(
        None,
        description="Причина/комментарий для аудита",
    )
    force: bool = Field(
        False,
        description="Игнорировать кэш",
    )


class AdminRebuildRanksOut(BaseModel):
    """Результат пересчёта рейтинга для админки."""

    ok: bool = True
    snapshot_at: datetime
    processed_users: int = Field(
        ...,
        description="Количество пользователей в расчёте",
    )
    duration_ms: int = Field(
        ...,
        description="Длительность (мс)",
    )
    message: Optional[str] = Field(
        None,
        description="Короткое сообщение",
    )


# --- legacy Rank* schemas kept for completeness (no legacy names) ---
class RankRow(BaseModel):
    """Карточка участника для top-списка."""

    tg_id: int = Field(..., description="ID пользователя Telegram")
    username: Optional[str] = Field(
        None,
        description="Ник (если задан)",
    )
    place: int = Field(
        ...,
        ge=1,
        description="Позиция в рейтинге (1-based)",
    )
    total_generated_kwh: str = Field(
        ...,
        description="Тотал энергии (кВт·ч), str d8",
    )
    level_index: int = Field(
        ...,
        ge=1,
        le=12,
        description="Номер уровня 1..12",
    )
    level_name: str = Field(..., description="Название уровня")
    is_vip: bool = Field(
        ...,
        description="Флаг VIP (NFT из коллекции)",
    )

    @field_validator("total_generated_kwh", mode="before")
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class RankMeBlock(BaseModel):
    """Блок "я" (отдельный от top, чтобы избежать дубля)."""

    tg_id: int
    username: Optional[str]
    place: int
    total_generated_kwh: str
    level_index: int
    level_name: str
    is_vip: bool

    ahead_count: int = Field(
        ...,
        ge=0,
        description="Сколько пользователей выше",
    )
    behind_count: int = Field(
        ...,
        ge=0,
        description="Сколько пользователей ниже",
    )

    @field_validator("total_generated_kwh", mode="before")
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


TopPage = CursorPage[RankRow]


class RankFeedOut(BaseModel):
    """Ответ экрана рейтинга: me + top + meta."""

    meta: OkMeta = Field(default_factory=OkMeta)
    me: RankMeBlock
    top: TopPage


class RankLevelDef(BaseModel):
    """Витринное определение уровня (порог может быть скрыт)."""

    level_index: int = Field(
        ...,
        ge=1,
        le=12,
        description="Номер уровня 1..12",
    )
    level_name: str = Field(..., description="Название уровня")
    threshold_kwh: Optional[str] = Field(
        None,
        description="Порог тотала (кВт·ч), str d8 или None",
    )

    @field_validator("threshold_kwh", mode="before")
    def _q8(cls, v: Any) -> Optional[str]:
        if v is None:
            return None
        return d8_str(v)


class RankLevelsOut(BaseModel):
    """Справочник уровней для UI."""

    meta: OkMeta = Field(default_factory=OkMeta)
    levels: List[RankLevelDef] = Field(default_factory=list)


class RankTopQueryIn(BaseModel):
    """Параметры курсорной пагинации top-списка."""

    next_cursor: Optional[str] = Field(
        None,
        description="Курсор следующей страницы (base64)",
    )
    limit: Optional[int] = Field(
        None,
        ge=1,
        le=200,
        description="Размер страницы 1..200",
    )


class RankSyncOut(BaseModel):
    """Результат служебной синхронизации снимков рейтинга."""

    meta: OkMeta = Field(default_factory=OkMeta)
    refreshed: int = Field(
        ...,
        ge=0,
        description="Сколько записей обновлено",
    )
    errors: int = Field(
        ...,
        ge=0,
        description="Сколько ошибок за проход",
    )
    note: Optional[str] = Field(
        None,
        description="Короткая приметка",
    )
