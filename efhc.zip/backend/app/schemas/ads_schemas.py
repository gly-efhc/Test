# backend/app/schemas/ads_schemas.py
# ----------------------------------------------------------------------
# Pydantic v2 схемы для Ads API.
# ----------------------------------------------------------------------

from __future__ import annotations

from app.schemas.common_schemas import EfhcBaseModel
from pydantic import Field


class AdOut(EfhcBaseModel):
    id: int
    title: str
    status: str
    weight: int = Field(ge=1)
