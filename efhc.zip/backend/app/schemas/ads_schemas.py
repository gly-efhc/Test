# -*- coding: utf-8 -*-
# backend/app/schemas/ads_schemas.py
# ----------------------------------------------------------------------
# Pydantic v2 схемы для Ads API.
# ----------------------------------------------------------------------

from __future__ import annotations

from pydantic import Field
from app.schemas.common_schemas import EfhcBaseModel


class AdOut(EfhcBaseModel):
    id: int
    title: str
    status: str
    weight: int = Field(ge=1)
