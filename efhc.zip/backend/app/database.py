"""Совместимый фасад исторических импортов базы данных EFHC.

Каноническая реализация находится в ``app.core.database_core``.
Этот модуль не создаёт отдельную фабрику и не меняет DB semantics.
"""

from __future__ import annotations

from app.core.database_core import get_engine, get_session_factory

__all__ = ["get_engine", "get_session_factory"]
