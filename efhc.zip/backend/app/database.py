# -*- coding: utf-8 -*-
# backend/app/database.py
# =====================================================================
# DEPRECATED: старый DB-слой.
#
# Канон EFHC Bot: единственный DB-движок находится в:
#   app.core.database_core
#
# Этот модуль оставлен как совместимость для старых импортов.
# В проекте запрещено импортировать app.database напрямую.
# =====================================================================

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database_core import (
    get_db as get_db,
    get_engine as get_engine,
    get_session_factory as get_session_factory,
)


def async_session_maker() -> AsyncSession:
    """
    Совместимость со старыми вызовами:
        async with async_session_maker() as session:
            ...

    Возвращает AsyncSession.
    """
    session_factory = get_session_factory()
    return session_factory()
