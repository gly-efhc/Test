# -*- coding: utf-8 -*-
# backend/app/crud/user_crud.py
# ======================================================================
# CRUD-слой для таблицы users: создание/чтение/обновление и выборки.
# Денежных операций здесь нет: любые движения EFHC только через сервисы.
# Все списки используют курсор по (id ASC), без OFFSET.
# ======================================================================

from __future__ import annotations

from typing import List, Optional, Tuple

from sqlalchemy import Select, and_, func, or_, select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging_core import get_logger
from app.deps import decode_cursor, encode_cursor
from app.models.user_models import User

logger = get_logger(__name__)


# ======================================================================
# ВНУТРЕННИЕ ПОМОЩНИКИ
# ======================================================================


def _apply_user_filters(
    stmt: Select,
    *,
    is_active: Optional[bool] = None,
    is_vip: Optional[bool] = None,
    qtext: Optional[str] = None,
) -> Select:
    """Применить is_active/is_vip/qtext к выборке пользователей."""

    conds = []

    if is_active is not None:
        conds.append(User.is_active.is_(bool(is_active)))

    if is_vip is not None:
        conds.append(User.is_vip.is_(bool(is_vip)))

    if qtext:
        q = qtext.strip()
        if q.isdigit():
            like_expr = func.lower(User.username).like(
                func.lower(f"%{q}%")
            )
            conds.append(or_(like_expr, User.tg_id == int(q)))
        else:
            conds.append(
                func.lower(User.username).like(func.lower(f"%{q}%"))
            )

    if conds:
        stmt = stmt.where(and_(*conds))

    return stmt


# ======================================================================
# CREATE / READ
# ======================================================================


async def ensure_user(
    db: AsyncSession,
    *,
    tg_id: int,
    username: Optional[str] = None,
    is_active: bool = True,
) -> User:
    """Read-through создание пользователя по tg_id (ON CONFLICT)."""

    stmt_ins = (
        insert(User)
        .values(
            tg_id=int(tg_id),
            username=username,
            is_active=bool(is_active),
        )
        .on_conflict_do_nothing(index_elements=["tg_id"])
        .returning(User)
    )

    res = await db.execute(stmt_ins)
    row = res.scalar_one_or_none()
    if row:
        # Канон: если пользователь создан в этом запросе — фиксируем транзакцию.
        await db.commit()
        return row

    res = await db.execute(
        select(User).where(User.tg_id == int(tg_id)).limit(1)
    )
    exist = res.scalar_one_or_none()
    if not exist:
        logger.error(
            "ensure_user: failed to fetch after ON CONFLICT, tg=%s",
            tg_id,
        )
        raise RuntimeError(
            "ensure_user: inconsistent state after insert conflict"
        )

    return exist


async def get_user_by_id(
    db: AsyncSession,
    *,
    tg_id: int,
) -> Optional[User]:
    """Вернуть пользователя по внутреннему id или None."""

    res = await db.execute(select(User).where(User.tg_id == int(tg_id)))
    return res.scalar_one_or_none()


async def get_user_by_telegram(
    db: AsyncSession,
    *,
    tg_id: int,
) -> Optional[User]:
    """Вернуть пользователя по tg_id или None."""

    res = await db.execute(
        select(User).where(User.tg_id == int(tg_id)).limit(1)
    )
    return res.scalar_one_or_none()


async def get_user_for_update(
    db: AsyncSession,
    *,
    tg_id: int,
) -> Optional[User]:
    """Вернуть пользователя FOR UPDATE SKIP LOCKED."""

    stmt = (
        select(User)
        .where(User.tg_id == int(tg_id))
        .with_for_update(skip_locked=True)
    )
    res = await db.execute(stmt)
    return res.scalar_one_or_none()


# ======================================================================
# UPDATE (без денег)
# ======================================================================


async def update_username_if_changed(
    db: AsyncSession,
    *,
    tg_id: int,
    username: Optional[str],
) -> Optional[User]:
    """Обновить username, если изменился. Возвращает User или None."""

    res = await db.execute(select(User).where(User.tg_id == int(tg_id)))
    obj = res.scalar_one_or_none()
    if not obj:
        return None

    if username is not None and (obj.username or "") != username:
        obj.username = username
        await db.flush()

    return obj


async def set_is_active(
    db: AsyncSession,
    *,
    tg_id: int,
    is_active: bool,
) -> bool:
    """Включить/выключить пользователя. True, если обновлена запись."""

    res = await db.execute(
        update(User)
        .where(User.tg_id == int(tg_id))
        .values(is_active=bool(is_active))
    )
    return res.rowcount > 0


async def set_vip_flag(
    db: AsyncSession,
    *,
    tg_id: int,
    is_vip: bool,
) -> bool:
    """Установить флаг VIP. Денежных эффектов нет."""

    res = await db.execute(
        update(User)
        .where(User.tg_id == int(tg_id))
        .values(is_vip=bool(is_vip))
    )
    return res.rowcount > 0


async def set_ton_wallet(
    db: AsyncSession,
    *,
    tg_id: int,
    ton_wallet: Optional[str],
) -> bool:
    """Присвоить/сбросить кошелёк TON (пустая строка → NULL)."""

    wallet = (ton_wallet or "").strip() or None
    res = await db.execute(
        update(User)
        .where(User.tg_id == int(tg_id))
        .values(ton_wallet=wallet)
    )
    return res.rowcount > 0


# ======================================================================
# LIST — курсорная пагинация (id ASC)
# ======================================================================


async def list_users_cursor(
    db: AsyncSession,
    *,
    is_active: Optional[bool] = None,
    is_vip: Optional[bool] = None,
    qtext: Optional[str] = None,
    limit: int = 50,
    next_cursor: Optional[str] = None,
) -> Tuple[List[User], Optional[str]]:
    """Вернуть пользователей курсором по (id ASC)."""

    limit = max(1, min(int(limit), 200))

    after_id: Optional[int] = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        after_raw = payload.get("after_id")
        if after_raw is not None:
            after_id = int(after_raw or 0)

    stmt: Select = select(User)
    stmt = _apply_user_filters(
        stmt,
        is_active=is_active,
        is_vip=is_vip,
        qtext=qtext,
    )

    if after_id is not None:
        stmt = stmt.where(User.id > after_id)

    stmt = stmt.order_by(User.id.asc()).limit(limit)

    rows = (await db.execute(stmt)).scalars().all()

    nxt = None
    if rows and len(rows) == limit:
        nxt = encode_cursor({"after_id": int(rows[-1].id)})

    return list(rows), nxt


# ======================================================================
# ВЫБОРКИ ДЛЯ ПЛАНИРОВЩИКА / ИНТЕГРАЦИЙ
# ======================================================================


async def list_users_with_wallet_cursor(
    db: AsyncSession,
    *,
    limit: int = 500,
    next_cursor: Optional[str] = None,
) -> Tuple[List[User], Optional[str]]:
    """Пользователи с ton_wallet != NULL, курсор (id ASC)."""

    limit = max(1, min(int(limit), 1000))

    after_id: Optional[int] = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        after_raw = payload.get("after_id")
        if after_raw is not None:
            after_id = int(after_raw or 0)

    stmt: Select = select(User).where(User.ton_wallet.is_not(None))

    if after_id is not None:
        stmt = stmt.where(User.id > after_id)

    stmt = stmt.order_by(User.id.asc()).limit(limit)

    rows = (await db.execute(stmt)).scalars().all()

    nxt = None
    if rows and len(rows) == limit:
        nxt = encode_cursor({"after_id": int(rows[-1].id)})

    return list(rows), nxt


async def count_users(db: AsyncSession) -> int:
    """Счётчик пользователей (метрики/админка)."""

    res = await db.execute(select(func.count(User.id)))
    val = res.scalar_one() or 0
    return int(val)


async def count_users_vip(db: AsyncSession) -> int:
    """Счётчик пользователей с is_vip=true."""

    val = (
        await db.execute(
            select(func.count(User.id)).where(User.is_vip.is_(True))
        )
    ).scalar_one() or 0
    return int(val)
