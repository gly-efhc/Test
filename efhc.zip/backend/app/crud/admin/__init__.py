"""Admin-specific CRUD package.

Canonical active CRUD modules are imported explicitly by their services.
"""
