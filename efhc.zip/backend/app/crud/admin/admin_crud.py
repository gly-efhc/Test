# backend/app/crud/admin_crud.py
# ======================================================================
# Назначение кода:
# CRUD-уровень админских операций без прямых денежных действий:
# • Конфиг банка: чтение (истина банка = efhc_core.bank_balance).
# • TON-логи (ton_inbox_logs): курсорные списки, guarded-смена статусов,
# ретраи.
# • Магазин (shop_orders): курсорные списки, guarded-апдейты
# статусов/tx_hash.
# • Заявки на вывод (withdraw_requests): курсорные списки, guarded-смена
# статусов.
# • EFHC-логи (efhc_transfers_log): курсорные выборки с фильтрами для
# отчётности.
# • Вспомогательные агрегаты/счётчики для админ-панели.
#
# Канон / инварианты:
# • Денежной логики здесь НЕТ: никакого списания/начисления EFHC —
# только
# чтение/апдейты
# служебных полей и статусов. Любые деньги — строго через
# services/transactions_service.py.
# • Все списки — курсорная пагинация по id (ASC), без OFFSET.
# • Все статусные изменения — guarded (меняем только из ожидаемых
# статусов).
#
# ИИ-защита / самовосстановление:
# • Read-through паттерны при редких гонках (повторный апдейт статуса) —
# не
# валим процесс,
# безопасно возвращаем текущую запись.
# • Аккуратные апдейты ретраев в TON-логах:
# next_retry_at/retries_count/last_error.
# • Все функции не делают commit()/rollback() — транзакция управляется
# сервисом/роутом.
#
# Запреты:
# • Никаких P2P, никаких денежных побочных эффектов.
# • Никаких «незавершённостей»/заглушек. Функции готовы к продакшену.
# ======================================================================

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime
from typing import Any

from app.core.logging_core import get_logger

# Централизованные утилиты (единый источник истины для
# курсоров/ETag/Decimal)
from app.deps import (
    decode_cursor,
    encode_cursor,
)
from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

# курсорный кодек

logger = get_logger(__name__)

# EFHC логи (денежные логи, ТОЛЬКО чтение в CRUD-админке)
try:
    # В проекте может называться EFHCTransferLog или EfhcTransfersLog
    try:
        from app.models.transactions_models import (
            EFHCTransferLog,
        )  # type: ignore
    except Exception:
        from app.models.transactions_models import (
            EfhcTransfersLog as EFHCTransferLog,
        )  # type: ignore
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "Ожидается модель EFHCTransferLog "
        "в models/transactions_models.py"
    ) from exc

# TON входящие транзакции
try:
    from app.models.ton_logs_models import (
        TonInboxLog,
    )  # type: ignore
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "Ожидается модель TonInboxLog в models/ton_logs_models.py"
    ) from exc

# Магазин (заказы): EFHC-пакеты / NFT заявки
try:
    from app.models.shop_models import ShopOrder  # type: ignore
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "Ожидается модель ShopOrder в models/shop_models.py"
    ) from exc

# Заявки на вывод EFHC
try:
    from app.models.withdraw_models import (
        WithdrawRequest,
    )  # type: ignore
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "Ожидается модель WithdrawRequest в models/withdraw_models.py"
    ) from exc



def get_admin_bank_config() -> dict[str, object]:
    """Совместимый read-only конфиг банка для admin re-export слоёв."""
    return {
        "bank_enabled": True,
        "source": "compat_read_only",
    }

# ======================================================================
# EFHCTransferLog — отчётные выборки (денег не двигаем!)
# ======================================================================


async def list_efhc_transfers(session: AsyncSession,
    *,
    tg_id: int | None = None,
    direction: str | None = None,  # "credit" / "debit"
    balance_type: str | None = None,  # "main" / "bonus"
    reason_like: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    limit: int = 100,
    cursor: str | None = None,
) -> tuple[list[EFHCTransferLog], str | None]:
    """
    Курсорный список EFHC-логов для админ-панели. Без OFFSET.
    Возвращает (items, next_cursor).
    """
    after_id = decode_cursor(cursor) if cursor else None

    stmt = select(EFHCTransferLog)
    if tg_id is not None:
        stmt = stmt.where(EFHCTransferLog.tg_id == int(tg_id))
    if direction:
        stmt = stmt.where(EFHCTransferLog.direction == direction)
    if balance_type:
        stmt = stmt.where(EFHCTransferLog.balance_type == balance_type)
    if reason_like:
        stmt = stmt.where(
            EFHCTransferLog.reason.ilike(f"%{reason_like}%")
        )
    if created_from:
        stmt = stmt.where(EFHCTransferLog.created_at >= created_from)
    if created_to:
        stmt = stmt.where(EFHCTransferLog.created_at <= created_to)
    if after_id:
        stmt = stmt.where(EFHCTransferLog.id > int(after_id))

    stmt = stmt.order_by(EFHCTransferLog.id.asc()).limit(int(limit))
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor = None
    if items and len(items) == int(limit):
        next_cursor = encode_cursor(
            {"after_id": int(items[-1].id)}
        )
    return items, next_cursor

# ======================================================================
# TonInboxLog — TON входящие: списки/ретраи/статусы (денег здесь нет)
# ======================================================================

async def list_ton_inbox(session: AsyncSession,
    *,
    status: str | None = None,  # received/parsed/credited/error_*
    memo_like: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    limit: int = 100,
    cursor: str | None = None,
) -> tuple[list[TonInboxLog], str | None]:
    """
    Курсорный список входящих TON-транзакций для админ-панели.
    Без OFFSET.
    """
    after_id = decode_cursor(cursor) if cursor else None

    stmt = select(TonInboxLog)
    if status:
        stmt = stmt.where(TonInboxLog.status == status)
    if memo_like:
        stmt = stmt.where(TonInboxLog.memo.ilike(f"%{memo_like}%"))
    if created_from:
        stmt = stmt.where(TonInboxLog.created_at >= created_from)
    if created_to:
        stmt = stmt.where(TonInboxLog.created_at <= created_to)
    if after_id:
        stmt = stmt.where(TonInboxLog.id > int(after_id))

    stmt = stmt.order_by(TonInboxLog.id.asc()).limit(int(limit))
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor = None
    if items and len(items) == int(limit):
        next_cursor = encode_cursor(
            {"after_id": int(items[-1].id)}
        )
    return items, next_cursor

async def set_ton_log_status_guarded(session: AsyncSession,
    *,
    tx_hash: str,
    new_status: str,
    expected_prev: Sequence[str] | None = None,
    next_retry_at: datetime | None = None,
    last_error: str | None = None,
    inc_retry: bool = False,) -> TonInboxLog | None:
    """
    Guarded-смена статуса записи TON-лога.
    • Если expected_prev передан — меняем только из указанных статусов.
    • Можно инкрементировать счётчик ретраев и запланировать
      next_retry_at.
    """
    res = await session.execute(
        select(TonInboxLog)
        .where(TonInboxLog.tx_hash == tx_hash)
        .limit(1)
    )
    row = res.scalar_one_or_none()
    if not row:
        return None

    if expected_prev and row.status not in set(expected_prev):
        return row

    row.status = new_status
    if next_retry_at is not None:
        row.next_retry_at = next_retry_at
    if last_error is not None:
        row.last_error = last_error
    if inc_retry:
        row.retries_count = int(row.retries_count or 0) + 1
    row.updated_at = datetime.utcnow()
    await session.flush()
    return row

# ======================================================================
# ShopOrder — каталог/заявки: списки и guarded-апдейты статусов/tx_hash
# ======================================================================

async def list_shop_orders(session: AsyncSession,
    *,
    order_type: str | None = None,  # "EFHC" / "NFT"
    # PENDING/PAID_AUTO/PAID_PENDING_MANUAL/APPROVED/REJECTED
    status: str | None = None,
    tg_id: int | None = None,
    limit: int = 100,
    cursor: str | None = None,
) -> tuple[list[ShopOrder], str | None]:
    """
    Курсорный список заказов магазина (user/admin витрины). Без OFFSET.
    """
    after_id = decode_cursor(cursor) if cursor else None
    stmt = select(ShopOrder)
    if order_type:
        stmt = stmt.where(ShopOrder.type == order_type)
    if status:
        stmt = stmt.where(ShopOrder.status == status)
    if tg_id is not None:
        stmt = stmt.where(ShopOrder.tg_id == int(tg_id))
    if after_id:
        stmt = stmt.where(ShopOrder.id > int(after_id))

    stmt = stmt.order_by(ShopOrder.id.asc()).limit(int(limit))
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor = None
    if items and len(items) == int(limit):
        next_cursor = encode_cursor(
            {"after_id": int(items[-1].id)}
        )
    return items, next_cursor

async def set_shop_order_status_guarded(session: AsyncSession,
    *,
    order_id: int,
    new_status: str,
    expected_prev: Sequence[str] | None = None,
    moderator_tg_id: int | None = None,
    note: str | None = None,
    tx_hash: str | None = None,) -> ShopOrder | None:
    """
    Guarded-смена статуса заказа магазина.
    Пример: NFT: PAID_PENDING_MANUAL → APPROVED/REJECTED.
    Денег не трогаем — только статусы/метки.
    Финансовый поток делает watcher/банк-сервис.
    """
    res = await session.execute(
        select(ShopOrder)
        .where(ShopOrder.id == int(order_id))
        .limit(1)
    )
    order = res.scalar_one_or_none()
    if not order:
        return None

    if expected_prev and order.status not in set(expected_prev):
        return order

    order.status = new_status
    if moderator_tg_id is not None:
        order.moderator_tg_id = int(moderator_tg_id)
    if note is not None:
        order.admin_note = note
    if tx_hash is not None:
        order.tx_hash = tx_hash
    order.updated_at = datetime.utcnow()
    await session.flush()
    return order

# ======================================================================
# WithdrawRequest — списки и guarded-смена статусов (денег нет)
# ======================================================================

async def list_withdraw_requests(session: AsyncSession,
    *,
    # PENDING/APPROVED/REJECTED/PAID/FAILED
    status: str | None = None,
    tg_id: int | None = None,
    limit: int = 100,
    cursor: str | None = None,
) -> tuple[list[WithdrawRequest], str | None]:
    """
    Курсорный список заявок на вывод EFHC. Денег не двигаем.
    """
    after_id = decode_cursor(cursor) if cursor else None
    stmt = select(WithdrawRequest)
    if status:
        stmt = stmt.where(WithdrawRequest.status == status)
    if tg_id is not None:
        stmt = stmt.where(WithdrawRequest.tg_id == int(tg_id))
    if after_id:
        stmt = stmt.where(WithdrawRequest.id > int(after_id))

    stmt = stmt.order_by(WithdrawRequest.id.asc()).limit(int(limit))
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor = None
    if items and len(items) == int(limit):
        next_cursor = encode_cursor(
            {"after_id": int(items[-1].id)}
        )
    return items, next_cursor

async def set_withdraw_status_guarded(session: AsyncSession,
    *,
    request_id: int,
    new_status: str,
    expected_prev: Sequence[str] | None = None,
    moderator_tg_id: int | None = None,
    note: str | None = None,
    efhc_transfer_log_id: int | None = None,
) -> WithdrawRequest | None:
    """
    Guarded-смена статуса заявки на вывод.
    Здесь НЕТ выплат — только статусы/аудит.
    """
    prev = list(expected_prev) if expected_prev else ["PENDING"]
    prev_set = set(str(s) for s in prev)

    values: dict[str, Any] = {
        "status": str(new_status),
        "updated_at": datetime.utcnow(),
    }
    if str(new_status) in {"PAID", "REJECTED", "CANCELED"}:
        values["processed_at"] = datetime.utcnow()
    if moderator_tg_id is not None:
        values["moderator_tg_id"] = int(moderator_tg_id)
    if note is not None:
        values["admin_note"] = note
    if efhc_transfer_log_id is not None:
        values["efhc_transfer_log_id"] = int(efhc_transfer_log_id)

    r = await session.execute(
        update(WithdrawRequest)
        .where(
            and_(
                WithdrawRequest.id == int(request_id),
                WithdrawRequest.status.in_(prev_set),
            )
        )
        .values(**values)
        .returning(WithdrawRequest.id)
    )
    if r.scalar_one_or_none() is None:
        raise ValueError("Переход запрещён")

    res = await session.execute(
        select(WithdrawRequest)
        .where(WithdrawRequest.id == int(request_id))
        .limit(1)
    )
    req = res.scalar_one_or_none()
    await session.flush()
    return req

# ======================================================================
# Агрегаты/отчётность (для админ-панели; денежные суммы — только как
# метаданные)
# ======================================================================

async def ton_inbox_status_counters(
    session: AsyncSession,
) -> list[tuple[str, int]]:
    """
    Возвращает [(status, count), ...] по таблице TonInboxLog.
    Удобно для виджета статусов.
    """
    res = await session.execute(
        select(
            TonInboxLog.status,
            func.count(TonInboxLog.id),
        ).group_by(TonInboxLog.status)
    )
    return [(row[0], int(row[1])) for row in res.all()]

async def shop_order_status_counters(
    session: AsyncSession,
) -> list[tuple[str, int]]:
    """
    Возвращает [(status, count), ...] по таблице ShopOrder.
    Виджет статусов магазина.
    """
    res = await session.execute(
        select(
            ShopOrder.status,
            func.count(ShopOrder.id),
        ).group_by(ShopOrder.status)
    )
    return [(row[0], int(row[1])) for row in res.all()]

async def withdraw_status_counters(
    session: AsyncSession,
) -> list[tuple[str, int]]:
    """
    Возвращает [(status, count), ...] по таблице WithdrawRequest.
    Виджет статусов выводов.
    """
    res = await session.execute(
        select(
            WithdrawRequest.status,
            func.count(WithdrawRequest.id),
        ).group_by(WithdrawRequest.status)
    )
    return [(row[0], int(row[1])) for row in res.all()]

async def efhc_transfers_recent_total(session: AsyncSession,
    *,
    from_ts: datetime | None = None,
) -> tuple[int, int]:
    """
    Возвращает (кол-во credit, кол-во debit) логов EFHC.
    С момента from_ts (или за всё время).
    Это метаданные для админ-дашборда.
    Суммы не агрегируем здесь, деньги не считаем.
    """
    base = select(
        EFHCTransferLog.direction,
        func.count(EFHCTransferLog.id),
    )
    if from_ts:
        base = base.where(EFHCTransferLog.created_at >= from_ts)
    res = await session.execute(
        base.group_by(EFHCTransferLog.direction)
    )
    stats = {row[0]: int(row[1]) for row in res.all()}
    return stats.get("credit", 0), stats.get("debit", 0)

# ======================================================================
# Пояснения «для чайника»:
# • Почему в админ-CRUD нет денег?
# Канон проекта запрещает любые денежные изменения вне банковского
# сервиса.
# Админ-CRUD лишь читает/обновляет статусы и служебные поля (tx_hash,
# заметки).
#
# • Что значит guarded-апдейты?
# Мы меняем статус записи ТОЛЬКО из ожидаемого множества статусов
# (expected_prev).
# Это снижает гонки: если запись уже перешла дальше, мы безопасно
# возвращаем
# её текущее состояние без ошибок и падений.
#
# • Зачем курсорная пагинация?
# OFFSET дорог, может «гулять» при вставках. Курсор по id стабилен,
# быстрый и
# подходит для «вечно растущих» таблиц логов/заказов.
#
# • Где ретраи TON логов?
# Ретраи/планирование next_retry_at мы только фиксируем в TonInboxLog.
# Фактические
# повторные попытки делает планировщик/вотчер, который читает эти поля.
# ======================================================================

