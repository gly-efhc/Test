# backend/app/crud/ranks_crud.py
# =====================================================================
# Назначение кода:
# CRUD-утилиты уровня БД для витрин рейтинга EFHC («Я + TOP»):
# • построение снапшота рейтинга из users (по total_generated_kwh),
# • хранение «среза» в ranks_* (без тяжёлых live-запросов),
# • курсорная пагинация без OFFSET по снапшоту,
# • вычисление места пользователя (live или по снапшоту),
# • самовосстановление (force_refresh, heal).
#
# Канон/инварианты (важно):
# • Источник рейтинга — только total_generated_kwh (НЕ available_kwh).
# • «Я + TOP»: «Я» показывается один раз, TOP — по убыванию total.
# • Пагинация — только курсорная: (created_at,id) или (rank,id).
# • Никаких «суточных» ставок: рейтинг не связан с генерацией per-sec.
#
# ИИ-защита/самовосстановление:
# • Если нет актуального снапшота — можно собрать live-ранг и TOP.
# • force_refresh пересобирает снапшот атомарно; heal чинит срез.
# • Все суммы кВт⋅ч приводятся к Decimal с 8 знаками (округление вниз).
#
# Запреты:
# • Никаких операций с EFHC/балансами — только чтение/снапшоты рейтинга.
# • Никаких OFFSET-витрин — только курсоры.
# =====================================================================

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from typing import cast

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import (
    d8,
    decode_cursor,
    encode_cursor,
)
from app.models.ranks_models import (
    RanksSnapshot,
    RanksUserSnapshot,
)
from app.models.user_models import User
from sqlalchemy import and_, desc, func, or_, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()


# =====================================================================
# ВСПОМОГАТЕЛЬНОЕ: курсор для строки снапшота пользователя
# --------------------------------------------------------------------


def _cursor_for_snapshot_row(row: RanksUserSnapshot) -> str:
    """
    Курсор стабильный: (rank_position ASC, id ASC) → base64.
    """
    return cast(
        str,
        encode_cursor(
        {
            "rank": int(row.rank_position),
            "id": int(row.id),
        }
        ),
    )

# =====================================================================
# READ: получить последний снапшот
# --------------------------------------------------------------------
async def get_latest_snapshot(
    db: AsyncSession,
) -> RanksSnapshot | None:
    """
    Возвращает последний (по snapshot_at DESC, id DESC) RanksSnapshot.
    """
    q = (
        select(RanksSnapshot)
        .order_by(
            RanksSnapshot.snapshot_at.desc(),
            RanksSnapshot.id.desc(),
        )
        .limit(1)
    )
    res = await db.execute(q)
    return res.scalars().first()


# =====================================================================
# BUILD: пересобрать снепшот рейтинга из users
# --------------------------------------------------------------------
async def build_snapshot_from_users(
    db: AsyncSession,
    *,
    top_size: int = 100,
    note: str | None = None,
    snapshot_at: datetime | None = None,
) -> RanksSnapshot:
    """
    Строит новый снапшот рейтинга:
      1) Создаёт запись RanksSnapshot (пустую).
      2) Выбирает TOP-N пользователей по total_generated_kwh (NULL → 0),
         с детерминированной сортировкой: total DESC, tg_id ASC.
      3) Вычисляет позицию (row_number) и массово вставляет
         в RanksUserSnapshot.
    Возвращает созданный RanksSnapshot.

    Почему row_number: реальные «места» без пропусков (1,2,3...).
    """
    top_n = max(1, min(int(top_size), 1000))
    ts = snapshot_at or datetime.now(UTC)

    # 1) завести запись снапшота
    snap = RanksSnapshot(
        snapshot_at=ts,
        note=note or "",
        top_size=top_n,
    )
    db.add(snap)
    await db.flush()  # получим snap.id

    # 2) подготовить live выборку с row_number
    # coalesce(total_generated_kwh, 0) как total
    total_expr = func.coalesce(User.total_generated_kwh, Decimal("0"))
    subq = (
        select(
            User.id.label("user_pk"),
            User.tg_id.label("tg_id"),
            User.username.label("username"),
            total_expr.label("total"),
            func.row_number()
            .over(order_by=(desc(total_expr), User.tg_id.asc()))
            .label("pos"),
        )
        .where(User.is_active.is_(True))
        .subquery()
    )
    q = (
        select(
            subq.c.user_pk,
            subq.c.tg_id,
            subq.c.username,
            subq.c.total,
            subq.c.pos,
        )
        .where(subq.c.pos <= top_n)
        .order_by(subq.c.pos.asc(), subq.c.tg_id.asc())
    )
    rows = (await db.execute(q)).all()

    # 3) bulk insert в RanksUserSnapshot
    payload = [
        dict(
            snapshot_id=snap.id,
            tg_id=int(r.tg_id) if r.tg_id is not None else None,
            username=r.username,
            total_generated_kwh=d8(r.total),
            rank_position=int(r.pos),
            created_at=ts,
        )
        for r in rows
    ]
    if payload:
        await db.execute(insert(RanksUserSnapshot), payload)
    await db.flush()

    logger.info(
        "build_snapshot_from_users: snap_id=%s items=%s",
        snap.id,
        len(payload),
    )
    return snap


# =====================================================================
# HEAL: восстановление битого снапшота (если строк меньше, чем top_size)
# --------------------------------------------------------------------
async def heal_snapshot_if_incomplete(
    db: AsyncSession,
    *,
    snapshot: RanksSnapshot,
) -> bool:
    """
    Если снапшот есть, но строк меньше snapshot.top_size — пересобираем.
    Возвращает True, если лечили (пересобирали).
    """
    qcnt = select(func.count(RanksUserSnapshot.id)).where(
        RanksUserSnapshot.snapshot_id == snapshot.id
    )
    count = int((await db.execute(qcnt)).scalar_one() or 0)
    if count >= int(snapshot.top_size or 0):
        return False

    # Пересобрать снепшот: создаём новый, старый оставляем (аудит).
    await build_snapshot_from_users(
        db,
        top_size=int(snapshot.top_size or 100),
        note=f"heal {snapshot.id}",
        snapshot_at=datetime.now(UTC),
    )
    logger.warning(
        "heal_snapshot_if_incomplete: repaired (old_id=%s)",
        snapshot.id,
    )
    return True


# =====================================================================
# PAGE: получить страницу TOP по снапшоту (без OFFSET)
# --------------------------------------------------------------------
async def list_snapshot_top_cursor(
    db: AsyncSession,
    *,
    snapshot_id: int,
    limit: int = 100,
    next_cursor: str | None = None,
    asc: bool = True,
) -> tuple[list[RanksUserSnapshot], str | None]:
    """
    Возвращает страницу из RanksUserSnapshot:
      • сортировка по rank_position ASC (стабильно), tiebreaker: id ASC,
      • курсор — (rank_position, id).
    """
    limit = max(1, min(int(limit), 500))

    pos_from: int | None = None
    id_from: int | None = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        rank_raw = payload.get("rank")
        id_raw = payload.get("id")
        pos_from = int(rank_raw or 0) if rank_raw is not None else None
        id_from = int(id_raw or 0) if id_raw is not None else None

    q = select(RanksUserSnapshot).where(
        RanksUserSnapshot.snapshot_id == snapshot_id
    )

    if pos_from is not None and id_from is not None:
        if asc:
            q = q.where(
                or_(
                    RanksUserSnapshot.rank_position > pos_from,
                    and_(
                        RanksUserSnapshot.rank_position == pos_from,
                        RanksUserSnapshot.id > id_from,
                    ),
                )
            )
        else:
            q = q.where(
                or_(
                    RanksUserSnapshot.rank_position < pos_from,
                    and_(
                        RanksUserSnapshot.rank_position == pos_from,
                        RanksUserSnapshot.id < id_from,
                    ),
                )
            )

    if asc:
        q = q.order_by(
            RanksUserSnapshot.rank_position.asc(),
            RanksUserSnapshot.id.asc(),
        )
    else:
        q = q.order_by(
            RanksUserSnapshot.rank_position.desc(),
            RanksUserSnapshot.id.desc(),
        )

    q = q.limit(limit)
    res = await db.execute(q)
    items: list[RanksUserSnapshot] = list(res.scalars().all())

    next_c = None
    if items and len(items) == limit:
        next_c = _cursor_for_snapshot_row(items[-1])
    return items, next_c


# =====================================================================
# LIVE: вычислить место пользователя «на лету» (без снапшота)
# --------------------------------------------------------------------
async def get_user_rank_live(
    db: AsyncSession,
    *,
    tg_id: int,
) -> tuple[int, Decimal]:
    """
    Возвращает детерминированный live-ранг пользователя и его total:
      • total_u = COALESCE(user.total_generated_kwh, 0)
      • rank = 1
               + COUNT(users WHERE total > total_u)
               + COUNT(users WHERE total = total_u AND tg_id < tg_id)
    Такая формула избегает тяжёлых оконных функций в больших таблицах и
    даёт стабильный порядок при равенстве total
    (tiebreaker: tg_id ASC).
    """
    # 1) мой total по каноничному внешнему идентификатору tg_id
    q_me = select(
        func.coalesce(User.total_generated_kwh, Decimal("0"))
    ).where(User.tg_id == tg_id)
    me_total = (await db.execute(q_me)).scalar_one_or_none()
    total_u = d8(me_total or Decimal("0"))

    # 2) сколько строгих больше
    q_gt = select(func.count(User.id)).where(
        func.coalesce(User.total_generated_kwh, 0) > total_u
    )
    cnt_gt = int((await db.execute(q_gt)).scalar_one() or 0)

    # 3) сколько равных по total, но с меньшим tg_id (tiebreak)
    q_eq_lt = select(func.count(User.id)).where(
        and_(
            func.coalesce(User.total_generated_kwh, 0) == total_u,
            User.tg_id < tg_id,
        )
    )
    cnt_eq_lt = int((await db.execute(q_eq_lt)).scalar_one() or 0)

    rank = 1 + cnt_gt + cnt_eq_lt
    return rank, total_u


# =====================================================================
# SNAPSHOT: позиция пользователя из снапшота (если в TOP)
# --------------------------------------------------------------------
async def get_user_rank_from_snapshot(
    db: AsyncSession,
    *,
    snapshot_id: int,
    tg_id: int,
) -> tuple[int, Decimal] | None:
    """
    Возвращает (rank_position, total) пользователя, если он в TOP.
    Иначе — None.
    """
    q = select(
        RanksUserSnapshot.rank_position,
        RanksUserSnapshot.total_generated_kwh,
    ).where(
        and_(
            RanksUserSnapshot.snapshot_id == snapshot_id,
            RanksUserSnapshot.tg_id == tg_id,
        )
    )
    row = (await db.execute(q)).first()
    if not row:
        return None
    return int(row.rank_position), d8(row.total_generated_kwh)


# =====================================================================
# FORCE REFRESH: атомарная пересборка снапшота
# --------------------------------------------------------------------
async def force_refresh_snapshot(
    db: AsyncSession,
    *,
    top_size: int = 100,
    note: str | None = None,
) -> RanksSnapshot:
    """
    Полная пересборка нового снапшота. Старые не удаляются (аудит).
    """
    snap = await build_snapshot_from_users(
        db,
        top_size=int(top_size),
        note=note or "force_refresh",
        snapshot_at=datetime.now(UTC),
    )
    logger.info(
        "force_refresh_snapshot: new snap_id=%s",
        snap.id,
    )
    return snap


# =====================================================================
# ВСПОМОГАТЕЛЬНОЕ: список tg_id из снапшота (для «Я + TOP» фильтрации)
# --------------------------------------------------------------------
async def list_tg_ids_in_snapshot(
    db: AsyncSession,
    *,
    snapshot_id: int,
) -> list[int]:
    """
    Возвращает список tg_id, присутствующих в TOP снапшота.
    Используется, чтобы не дублировать «Я» при построении «Я + TOP».
    """
    q = select(RanksUserSnapshot.tg_id).where(
        RanksUserSnapshot.snapshot_id == snapshot_id
    )
    res = await db.execute(q)
    return [int(x) for x, in res.all()]


# =====================================================================
# Пояснения (для разработчиков/ревью):
# • build_snapshot_from_users: row_number() по total DESC, tg_id ASC,
# чтобы «места» шли 1..N без пропусков и порядок был детерминированным.
# • list_snapshot_top_cursor — курсорная пагинация по (rank,id).
# Никаких OFFSET — устойчиво и масштабируемо.
# • get_user_rank_live — формула ранга без оконных функций,
# но с детерминированным tiebreak (id ASC) — быстро и просто.
# • heal_snapshot_if_incomplete и force_refresh_snapshot — кирпичики
# ИИ-поддержки:
# если снапшот битый/короткий — собираем новый, старый оставляем.
# • CRUD гарантирует только операции с данными рейтинга.
# • «Я + TOP», ETag/кэш — уровень services/routes.
# =====================================================================

