"""CRUD-хелперы рейтинговых снимков по ``global_id``."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import cast

from app.core.logging_core import get_logger
from app.deps import d8, decode_cursor, encode_cursor
from app.lib.time import utcnow
from app.models.ranks_models import RanksSnapshot, RanksUserSnapshot
from app.models.user_models import User
from sqlalchemy import and_, desc, func, or_, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


def _cursor_for_snapshot_row(row: RanksUserSnapshot) -> str:
    return cast(
        str,
        encode_cursor(
            {"rank": int(row.rank_position), "id": int(row.id)}
        ),
    )


async def get_latest_snapshot(
    db: AsyncSession,
) -> RanksSnapshot | None:
    result = await db.execute(
        select(RanksSnapshot)
        .order_by(
            RanksSnapshot.snapshot_at.desc(),
            RanksSnapshot.rank_position.asc(),
            RanksSnapshot.id.asc(),
        )
        .limit(1)
    )
    return result.scalar_one_or_none()


async def build_snapshot_from_users(
    db: AsyncSession,
    *,
    top_size: int = 100,
    note: str | None = None,
    snapshot_at: datetime | None = None,
) -> RanksSnapshot:
    """Построить детерминированный рейтинг по ``global_id``."""
    top_n = max(1, min(int(top_size), 1000))
    captured_at = snapshot_at or utcnow()
    total = func.coalesce(User.total_generated_kwh, Decimal("0"))
    ranked = (
        select(
            User.global_id.label("global_id"),
            total.label("total"),
            func.dense_rank()
            .over(order_by=desc(total))
            .label("position"),
        )
        .where(
            User.is_active.is_(True),
            User.global_id.is_not(None),
        )
        .subquery()
    )
    rows = (
        await db.execute(
            select(
                ranked.c.global_id,
                ranked.c.total,
                ranked.c.position,
            )
            .where(ranked.c.position <= top_n)
            .order_by(ranked.c.position.asc(), ranked.c.global_id.asc())
        )
    ).all()
    payload = [
        {
            "snapshot_at": captured_at,
            "global_id": int(row.global_id),
            "rank_position": int(row.position),
            "total_generated_kwh": d8(row.total),
            "meta": {"note": str(note or "")},
        }
        for row in rows
    ]
    if payload:
        await db.execute(insert(RanksSnapshot), payload)
    await db.flush()
    result = await db.execute(
        select(RanksSnapshot)
        .where(RanksSnapshot.snapshot_at == captured_at)
        .order_by(RanksSnapshot.rank_position.asc())
        .limit(1)
    )
    first = result.scalar_one_or_none()
    if first is None:
        raise RuntimeError("ranking_snapshot_empty")
    logger.info(
        "build_snapshot_from_users: snapshot_at=%s items=%s",
        captured_at,
        len(payload),
    )
    return first


async def heal_snapshot_if_incomplete(
    db: AsyncSession,
    *,
    snapshot: RanksSnapshot,
) -> bool:
    count = int(
        (
            await db.execute(
                select(func.count(RanksSnapshot.id)).where(
                    RanksSnapshot.snapshot_at == snapshot.snapshot_at
                )
            )
        ).scalar_one()
        or 0
    )
    expected = max(int(snapshot.rank_position), 1)
    if count >= expected:
        return False
    await build_snapshot_from_users(
        db,
        top_size=max(expected, 100),
        note="heal",
    )
    return True


async def list_snapshot_top_cursor(
    db: AsyncSession,
    *,
    snapshot_id: int,
    limit: int = 100,
    next_cursor: str | None = None,
    asc: bool = True,
) -> tuple[list[RanksUserSnapshot], str | None]:
    """Прочитать строки планировщика по каноническому владельцу."""
    page_limit = max(1, min(int(limit), 500))
    position: int | None = None
    row_id: int | None = None
    if next_cursor:
        decoded = decode_cursor(next_cursor)
        position = int(decoded["rank"])
        row_id = int(decoded["id"])
    query = select(RanksUserSnapshot).where(
        RanksUserSnapshot.snapshot_id == int(snapshot_id)
    )
    if position is not None and row_id is not None:
        comparison = (
            or_(
                RanksUserSnapshot.rank_position > position,
                and_(
                    RanksUserSnapshot.rank_position == position,
                    RanksUserSnapshot.id > row_id,
                ),
            )
            if asc
            else or_(
                RanksUserSnapshot.rank_position < position,
                and_(
                    RanksUserSnapshot.rank_position == position,
                    RanksUserSnapshot.id < row_id,
                ),
            )
        )
        query = query.where(comparison)
    ordering = (
        (
            RanksUserSnapshot.rank_position.asc(),
            RanksUserSnapshot.id.asc(),
        )
        if asc
        else (
            RanksUserSnapshot.rank_position.desc(),
            RanksUserSnapshot.id.desc(),
        )
    )
    rows = list(
        (
            await db.execute(
                query.order_by(*ordering).limit(page_limit)
            )
        ).scalars().all()
    )
    cursor = (
        _cursor_for_snapshot_row(rows[-1])
        if len(rows) == page_limit
        else None
    )
    return rows, cursor


async def get_user_rank_live(
    db: AsyncSession,
    *,
    global_id: int,
) -> tuple[int, Decimal]:
    total = func.coalesce(User.total_generated_kwh, Decimal("0"))
    own_total = (
        await db.execute(
            select(total).where(
                User.global_id == int(global_id),
                User.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    canonical_total = d8(own_total or Decimal("0"))
    above = int(
        (
            await db.execute(
                select(func.count(User.id)).where(
                    User.is_active.is_(True),
                    total > canonical_total,
                )
            )
        ).scalar_one()
        or 0
    )
    return 1 + above, canonical_total


async def get_user_rank_from_snapshot(
    db: AsyncSession,
    *,
    snapshot_id: int,
    global_id: int,
) -> tuple[int, Decimal] | None:
    row = (
        await db.execute(
            select(
                RanksUserSnapshot.rank_position,
                RanksUserSnapshot.total_generated_kwh,
            ).where(
                RanksUserSnapshot.snapshot_id == int(snapshot_id),
                RanksUserSnapshot.global_id == int(global_id),
            )
        )
    ).first()
    if row is None:
        return None
    return int(row.rank_position), d8(row.total_generated_kwh)


async def force_refresh_snapshot(
    db: AsyncSession,
    *,
    top_size: int = 100,
    note: str | None = None,
) -> RanksSnapshot:
    return await build_snapshot_from_users(
        db,
        top_size=top_size,
        note=note or "force_refresh",
    )


async def list_global_ids_in_snapshot(
    db: AsyncSession,
    *,
    snapshot_id: int,
) -> list[int]:
    rows = await db.execute(
        select(RanksUserSnapshot.global_id).where(
            RanksUserSnapshot.snapshot_id == int(snapshot_id)
        )
    )
    return [int(value) for (value,) in rows.all()]
