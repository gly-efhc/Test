"""Read-only/history helpers and tx_hash attachment for canonical ShopOrder.

Active order creation and payment transitions belong to shop_service.
The former generic payment CRUD used absent columns and statuses and had
no callers; it cannot represent the canonical EFHC/NFT payment contract.
These helpers do not move balances or own the caller's root transaction.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import timedelta

from app.core.logging_core import get_logger
from app.lib.time import utcnow
from app.models.shop_models import ShopOrder
from sqlalchemy import and_, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


# ----------------------------------------------------------------------
# Базовые «get»
# ----------------------------------------------------------------------


async def get_order_by_id(
    session: AsyncSession,
    order_id: int,
) -> ShopOrder | None:
    """
    Что делает: Возвращает заказ по первичному ключу.
    Исключения: не бросает — возвращает None, если не найден.
    """
    res = await session.execute(
        select(ShopOrder).where(ShopOrder.id == int(order_id)).limit(1)
    )
    return res.scalar_one_or_none()


async def get_order_by_tx_hash(
    session: AsyncSession,
    tx_hash: str,
) -> ShopOrder | None:
    """
    Что делает: Возвращает заказ по уникальному tx_hash.
    Внешняя оплата TON/USDT.
    Исключения: не бросает — возвращает None, если не найден.
    """
    res = await session.execute(
        select(ShopOrder).where(ShopOrder.tx_hash == tx_hash).limit(1)
    )
    return res.scalar_one_or_none()


# ----------------------------------------------------------------------
# Привязка tx_hash (read-through)
# ----------------------------------------------------------------------


async def attach_tx_hash_if_absent(
    session: AsyncSession,
    *,
    order_id: int,
    tx_hash: str,
) -> ShopOrder:
    """
    Что делает: Привязывает к заказу tx_hash, если он еще не установлен.
    ИИ-защита: При конфликте UNIQUE.
    tx_hash уже привязан к другому заказу
    возвращаем существующую запись (read-through), не валим процесс.
    """
    order = await get_order_by_id(session, order_id)
    if not order:
        raise ValueError("Заказ не найден")

    if order.tx_hash and order.tx_hash != tx_hash:
        # Уже привязано «иное» поступление — отдаём как есть.
        # Пусть сервис
        # решит).
        return order

    order.tx_hash = tx_hash
    try:
        await session.flush()
    except IntegrityError:
        # tx_hash уже занят — возвращаем существующую запись.
        # С этим хэшем
        existing = await get_order_by_tx_hash(session, tx_hash)
        return existing or order
    return order


# ----------------------------------------------------------------------
# Курсорные списки (без OFFSET)
# ----------------------------------------------------------------------


async def list_orders_admin(
    session: AsyncSession,
    *,
    limit: int = 50,
    after_id: int | None = None,
    statuses: Sequence[str] | None = None,
    global_id: int | None = None,
) -> tuple[list[ShopOrder], int | None]:
    """
    Что делает: Админ-витрина заказов.
    Курсорная пагинация по id (ASC).
    Фильтры: по статусам и конкретному пользователю (опционально).
    """
    stmt = select(ShopOrder)
    if statuses:
        stmt = stmt.where(ShopOrder.status.in_(list(statuses)))
    if global_id is not None:
        stmt = stmt.where(
            ShopOrder.global_id == int(global_id)
        )
    if after_id:
        stmt = stmt.where(ShopOrder.id > int(after_id))
    stmt = stmt.order_by(ShopOrder.id.asc()).limit(int(limit))

    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor = None
    if items and len(items) == int(limit):
        next_cursor = items[-1].id
    return items, next_cursor


# ----------------------------------------------------------------------
# Наблюдаемость и периодическая уборка
# ----------------------------------------------------------------------


async def count_by_status(
    session: AsyncSession,
) -> list[tuple[str, int]]:
    """
    Что делает: Возвращает пары (status, count) — для админ-статистики.
    """
    res = await session.execute(
        select(
            ShopOrder.status,
            func.count(ShopOrder.id),
        ).group_by(ShopOrder.status)
    )
    return [(row[0], row[1]) for row in res.all()]


async def delete_cancelled_older_than(
    session: AsyncSession,
    *,
    days: int = 30,
    batch_limit: int = 1000,
) -> int:
    """
    Что делает: Мягкая очистка.
    Удаляет CANCELLED/EXPIRED/FAILED старше N дней партиями.
    Почему батчи: чтобы не держать долгую транзакцию.
    И не блокировать индексы.
    Возвращает: сколько записей удалено в текущем вызове.
    До batch_limit.
    """
    threshold = utcnow() - timedelta(days=int(days))
    res = await session.execute(
        select(ShopOrder)
        .where(
            and_(
                ShopOrder.updated_at < threshold,
                ShopOrder.status.in_(
                    ["CANCELLED", "EXPIRED", "FAILED"]
                ),
            )
        )
        .order_by(ShopOrder.id.asc())
        .limit(int(batch_limit))
    )
    items = list(res.scalars().all())
    for o in items:
        await session.delete(o)
    # flush/commit — на вызывающем уровне
    return len(items)
