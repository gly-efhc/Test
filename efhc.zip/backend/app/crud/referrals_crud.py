# backend/app/crud/referrals_crud.py
# ======================================================================
# Назначение кода:
# CRUD-слой работы с БД для реферальной системы EFHC:
# • Связи inviter↔invitee (чтение/активация).
# • Витрины списков «Активные / Неактивные» с курсорной пагинацией (без
# OFFSET).
# • Агрегаты для админ-панели (топ инвайтеров, суммы бонусов).
# • Журнал бонусов рефералов (создание записей, суммирование, «ранговые»
# маркеры).
#
# Канон/инварианты:
# • «Активным» реферал становится после ПЕРВОЙ активации панели (факт
# фиксируется
# вне этого CRUD,
# здесь — только хранение флага is_active/activated_at).
# • Денежных операций в CRUD нет. Любые EFHC-движения делает единый
# банковский
# сервис.
# • Идемпотентность денег обеспечивается в банковском сервисе; в журнале
# рефералов можно хранить
# ссылочные/описательные метаданные (meta) с idempotency_key/tx_id, но
# CRUD не
# эмитирует EFHC.
#
# ИИ-защита/самовосстановление:
# • Все списки — курсор по (created_at DESC, invitee_global_id DESC).
# росте
# данных.
# • Реферальная связь создаётся только сервисом первичного onboarding;
# этот CRUD не предоставляет позднюю или ручную привязку.
# • Вспомогательные функции «heal» не требуются — этот слой тонкий и
# детерминированный.
#
# Запреты:
# • Никаких начислений EFHC/списаний — только запись фактов и чтение.
# • Никаких OFFSET-пагинаций — только курсоры.
# ======================================================================

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import cast

from app.core.logging_core import get_logger
from app.deps import d8, decode_cursor, encode_cursor
from app.models.referral_models import (
    ReferralBonusLedger,
    ReferralLink,
)
from app.models.transactions_models import EfhcTransferLog
from app.models.user_models import User
from app.schemas.referral_schemas import BonusRecordCreate
from sqlalchemy import and_, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


# ======================================================================
# Связи inviter↔invitee
# ======================================================================


async def get_referral_link_by_invitee(
    db: AsyncSession,
    *,
    invitee_global_id: int,
) -> ReferralLink | None:
    """
    Вернуть связь по приглашённому пользователю, либо None.
    """
    stmt = (
        select(ReferralLink)
        .where(ReferralLink.invitee_global_id == invitee_global_id)
        .limit(1)
    )
    res = await db.execute(stmt)
    return res.scalars().first()


async def get_referrals_by_inviter(
    db: AsyncSession,
    *,
    inviter_global_id: int,
) -> list[ReferralLink]:
    """
    Вернуть все связи по конкретному пригласившему (без пагинации).
    Используйте курсорные витрины list_*_cursor для UI-списков.
    """
    stmt = (
        select(ReferralLink)
        .where(ReferralLink.inviter_global_id == inviter_global_id)
        .order_by(ReferralLink.id.asc())
    )
    res = await db.execute(stmt)
    return list(res.scalars().all())


@dataclass(frozen=True)
class ReferralActivationResult:
    """Result of the locked NULL -> activated_at transition."""

    link: ReferralLink | None
    activated_now: bool


async def activate_referral(
    db: AsyncSession,
    *,
    invitee_global_id: int | None = None,
    activation_bonus_hint: Decimal | None = None,
    activation_dt: datetime | None = None,
) -> ReferralActivationResult:
    """Lock and activate one referral link without committing.

    This CRUD function is the single owner of the concurrency-critical
    ``SELECT ... FOR UPDATE`` and ``activated_at`` transition. The
    caller owns the surrounding transaction and all monetary rewards.
    ``activated_now`` lets the service reward only the transaction that
    actually changed ``NULL`` to a timestamp.

    ``activation_bonus_hint`` remains accepted only for compatibility.
    CRUD never performs monetary operations.
    """
    del activation_bonus_hint
    if invitee_global_id is not None and invitee_global_id is not None:
        selector = or_(
            ReferralLink.invitee_global_id == int(invitee_global_id),
            and_(
                ReferralLink.invitee_global_id.is_(None),
                ReferralLink.invitee_global_id == int(invitee_global_id),
            ),
        )
    elif invitee_global_id is not None:
        selector = (
            ReferralLink.invitee_global_id == int(invitee_global_id)
        )
    elif invitee_global_id is not None:
        selector = ReferralLink.invitee_global_id == int(invitee_global_id)
    else:
        raise ValueError("Требуется invitee global_id или global_id")
    stmt = (
        select(ReferralLink)
        .where(selector)
        .limit(1)
        .with_for_update()
    )
    link = (await db.execute(stmt)).scalars().first()
    if link is None:
        return ReferralActivationResult(link=None, activated_now=False)
    if link.activated_at is not None:
        return ReferralActivationResult(link=link, activated_now=False)

    link.activated_at = activation_dt or datetime.now(UTC)
    db.add(link)
    await db.flush()
    return ReferralActivationResult(link=link, activated_now=True)


# ======================================================================
# Курсорные витрины «Активные / Неактивные»
# ======================================================================


async def _list_refs_cursor(
    db: AsyncSession,
    *,
    inviter_global_id: int,
    limit: int,
    next_cursor: str | None,
    want_active: bool,
) -> tuple[list[ReferralLink], str | None]:
    """Stable cursor page ordered by invitation time and Telegram ID."""
    safe_limit = max(1, min(int(limit), 200))
    cursor_ts: datetime | None = None
    cursor_tg: int | None = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        raw_ts = payload.get("invited_at")
        raw_tg = payload.get("invitee_global_id")
        if raw_ts is not None and raw_tg is not None:
            cursor_ts = datetime.fromisoformat(str(raw_ts))
            cursor_tg = int(raw_tg)

    activity_clause = (
        ReferralLink.activated_at.isnot(None)
        if want_active
        else ReferralLink.activated_at.is_(None)
    )
    stmt = select(ReferralLink).where(
        ReferralLink.inviter_global_id == int(inviter_global_id),
        activity_clause,
    )
    if cursor_ts is not None and cursor_tg is not None:
        stmt = stmt.where(
            or_(
                ReferralLink.created_at < cursor_ts,
                and_(
                    ReferralLink.created_at == cursor_ts,
                    ReferralLink.invitee_global_id < cursor_tg,
                ),
            )
        )

    stmt = stmt.order_by(
        ReferralLink.created_at.desc(),
        ReferralLink.invitee_global_id.desc(),
    ).limit(safe_limit + 1)
    items = list((await db.execute(stmt)).scalars().all())
    has_more = len(items) > safe_limit
    items = items[:safe_limit]
    next_value: str | None = None
    if has_more and items:
        last = items[-1]
        next_value = encode_cursor(
            {
                "invited_at": last.created_at.isoformat(),
                "invitee_global_id": int(last.invitee_global_id),
            }
        )
    return items, next_value


async def list_active_refs_cursor(
    db: AsyncSession,
    *,
    inviter_global_id: int,
    limit: int = 50,
    next_cursor: str | None = None,
) -> tuple[list[ReferralLink], str | None]:
    return await _list_refs_cursor(
        db,
        inviter_global_id=int(inviter_global_id),
        limit=int(limit),
        next_cursor=next_cursor,
        want_active=True,
    )


async def list_inactive_refs_cursor(
    db: AsyncSession,
    *,
    inviter_global_id: int,
    limit: int = 50,
    next_cursor: str | None = None,
) -> tuple[list[ReferralLink], str | None]:
    return await _list_refs_cursor(
        db,
        inviter_global_id=int(inviter_global_id),
        limit=int(limit),
        next_cursor=next_cursor,
        want_active=False,
    )


# ======================================================================
# Агрегаты по ссылкам
# ======================================================================


async def count_total_and_active(
    db: AsyncSession,
    *,
    inviter_global_id: int,
) -> tuple[int, int]:
    """
    Вернуть (total, active) по инвайтеру.
    """
    q_total = select(func.count(ReferralLink.id)).where(
        ReferralLink.inviter_global_id == inviter_global_id
    )
    q_active = select(func.count(ReferralLink.id)).where(
        and_(
            ReferralLink.inviter_global_id == inviter_global_id,
            ReferralLink.activated_at.isnot(None),
        )
    )
    total = int((await db.execute(q_total)).scalar_one() or 0)
    active = int((await db.execute(q_active)).scalar_one() or 0)
    return total, active


# ======================================================================
# Журнал бонусов рефералов (НЕ деньги, деньги — только через банк!)
# ======================================================================


async def add_bonus_record(
    db: AsyncSession,
    *,
    payload: BonusRecordCreate,
) -> ReferralBonusLedger:
    """
    Добавить строку в журнал бонусов рефералов.
    Суммы приводятся к Decimal(8) вниз.
    Денежное начисление EFHC должен сделать банковский сервис.
    """
    rec = ReferralBonusLedger(
        global_id=int(payload.global_id),
        amount_efhc=d8(payload.amount_efhc),
        kind=str(payload.kind),
        meta=payload.meta,
        created_at=datetime.now(UTC),
    )
    db.add(rec)
    await db.flush()
    return rec


async def sum_bonus_for_user(
    db: AsyncSession,
    *,
    global_id: int,
) -> Decimal:
    """
    Вернуть сумму EFHC из журнала бонусов по global_id.
    Это отчётная сумма журнала, она НЕ является балансом.
    Баланс — в users.*balance.
    """
    stmt = select(
        func.coalesce(
            func.sum(ReferralBonusLedger.amount_efhc),
            0,
        )
    ).where(ReferralBonusLedger.global_id == global_id)
    val = (await db.execute(stmt)).scalar_one() or 0
    return cast(Decimal, d8(Decimal(val)))


async def has_rank_bonus_paid(
    db: AsyncSession,
    *,
    global_id: int,
    threshold: int,
) -> bool:
    """
    Проверить, выплачивался ли ранговый бонус.
    По порогу активных рефералов.
    По соглашению, meta содержит «rank_threshold=<N>».
    """
    stmt = select(func.count(ReferralBonusLedger.id)).where(
        and_(
            ReferralBonusLedger.global_id == global_id,
            ReferralBonusLedger.kind == "rank",
            ReferralBonusLedger.meta.ilike(
                f"%rank_threshold = {threshold}%"
            ),
        )
    )
    count = (await db.execute(stmt)).scalar_one()
    return bool(count > 0)


# ======================================================================
# Админские выборки/топы (для витрин)
# ======================================================================


async def admin_top_inviters(
    db: AsyncSession,
    *,
    limit: int = 10,
) -> Sequence:
    """
    Топ по активным рефералам и сумме бонусов.

    SQL-идея:
      • active_subq: count(*) по activated_at IS NOT NULL,
        группой по inviter.
      • bonus_subq: sum(amount_efhc) по журналу бонусов (global_id).
      • Объединяем с users для получения username.
    """
    active_subq = (
        select(
            ReferralLink.inviter_global_id.label("global_id"),
            func.count(ReferralLink.id).label("active_count"),
        )
        .where(ReferralLink.activated_at.isnot(None))
        .group_by(ReferralLink.inviter_global_id)
        .subquery()
    )

    bonus_subq = (
        select(
            EfhcTransferLog.global_id.label("global_id"),
            func.coalesce(
                func.sum(EfhcTransferLog.amount),
                0,
            ).label("bonus_sum"),
        )
        .where(
            EfhcTransferLog.direction == "credit",
            EfhcTransferLog.balance_type == "bonus",
            EfhcTransferLog.reason.in_(
                [
                    "referral_active_unit",
                    "referral_level_bonus",
                ]
            ),
        )
        .group_by(EfhcTransferLog.global_id)
        .subquery()
    )

    stmt = (
        select(
            User.global_id.label("inviter_global_id"),
            User.username,
            func.count(ReferralLink.id).label("total_invited"),
            func.coalesce(
                active_subq.c.active_count,
                0,
            ).label("active_invited"),
            func.coalesce(
                bonus_subq.c.bonus_sum,
                0,
            ).label("total_bonus_efhc"),
        )
        .join(
            ReferralLink,
            ReferralLink.inviter_global_id == User.global_id,
            isouter=True,
        )
        .join(
            active_subq,
            active_subq.c.global_id == User.global_id,
            isouter=True,
        )
        .join(
            bonus_subq,
            bonus_subq.c.global_id == User.global_id,
            isouter=True,
        )
        .group_by(
            User.global_id,
            User.username,
            active_subq.c.active_count,
            bonus_subq.c.bonus_sum,
        )
        .order_by(
            func.coalesce(active_subq.c.active_count, 0).desc(),
            func.coalesce(bonus_subq.c.bonus_sum, 0).desc(),
        )
        .limit(max(1, min(int(limit), 100)))
    )
    res = await db.execute(stmt)
    return cast(Sequence[object], res.all())


# ======================================================================
# Пояснения (для разработчиков/ревью):
# • CRUD не двигает деньги — только хранит факты (связи и журнал
# бонусов).
# Любые EFHC-списки/начисления
# делаются строго банковским сервисом (transactions_service).
# • Витрины используют стабильный составной курсор:
# invitation time + TG ID.
# и
# масштабируемо.
# • list_active_refs_cursor / list_inactive_refs_cursor дают «чистые»
# выборки
# для UI «Активные / Неактивные».
# • Активность реферала устанавливается сервисом панелей при первой
# активации
# (здесь только флаг).
# • Админ-топ объединяет активных приглашённых и суммы бонусов из
# журнала — для
# дашборда.
# ======================================================================
