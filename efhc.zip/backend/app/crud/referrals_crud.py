# backend/app/crud/referrals_crud.py
# ======================================================================
# Назначение кода:
# CRUD-слой работы с БД для реферальной системы EFHC:
# • Связи inviter↔invitee (создание/чтение/переназначение/активация).
# • Витрины списков «Активные / Неактивные» с курсорной пагинацией (без
# OFFSET).
# • Агрегаты для админ-панели (топ инвайтеров, суммы бонусов).
# • Журнал бонусов рефералов (создание записей, суммирование, «ранговые»
# маркеры).
#
# Канон/инварианты:
# • «Активным» реферал становится после ПЕРВОЙ покупки панели (факт
# фиксируется
# вне этого CRUD,
# здесь — только хранение флага is_active/activated_at).
# • Денежных операций в CRUD нет. Любые EFHC-движения делает единый
# банковский
# сервис.
# • Идемпотентность денег обеспечивается в банковском сервисе; в журнале
# рефералов можно хранить
# ссылочные/описательные метаданные (meta) с idempotency_key/tx_id, но
# CRUD не
# эмитирует EFHC.
#
# ИИ-защита/самовосстановление:
# • Все списки — только курсорная пагинация по (id ASC) → устойчиво при
# росте
# данных.
# • Безопасные апдейты: IntegrityError на UNIQUE → мягко переводим в
# ValueError
# с пояснением.
# • Вспомогательные функции «heal» не требуются — этот слой тонкий и
# детерминированный.
#
# Запреты:
# • Никаких начислений EFHC/списаний — только запись фактов и чтение.
# • Никаких OFFSET-пагинаций — только курсоры.
# ======================================================================

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from decimal import Decimal
from typing import cast

from app.core.logging_core import get_logger
from app.deps import d8, decode_cursor, encode_cursor
from app.models.referral_models import (
    ReferralBonusLedger,
    ReferralLink,
)
from app.models.user_models import User
from app.schemas.referral_schemas import BonusRecordCreate
from sqlalchemy import and_, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


# ======================================================================
# Связи inviter↔invitee
# ======================================================================

async def create_referral_link(
    db: AsyncSession,
    *,
    inviter_tg_id: int,
    invitee_tg_id: int,
    note: str | None = None,
) -> ReferralLink:
    """
    Создать связь приглашения.
    Один invitee может иметь только одного inviter.
    UNIQUE-ограничение защищает от дублей.

    Исключения:
      • ValueError — если связь уже существует.
        Или нарушены внешние ключи.
    """
    link = ReferralLink(
        inviter_tg_id=inviter_tg_id,
        invitee_tg_id=invitee_tg_id,
        note=note,
    )
    db.add(link)
    try:
        await db.flush()
    except IntegrityError as e:
        await db.rollback()
        raise ValueError(
            "Invitee already has an inviter or invalid IDs"
        ) from e
    return link


async def get_referral_link_by_invitee(
    db: AsyncSession,
    *,
    invitee_tg_id: int,
) -> ReferralLink | None:
    """
    Вернуть связь по приглашённому пользователю, либо None.
    """
    stmt = select(ReferralLink).where(
        ReferralLink.invitee_tg_id == invitee_tg_id
    ).limit(1)
    res = await db.execute(stmt)
    return res.scalars().first()


async def get_referrals_by_inviter(db: AsyncSession,
    *,
    inviter_tg_id: int,) -> list[ReferralLink]:
    """
    Вернуть все связи по конкретному пригласившему (без пагинации).
    Используйте курсорные витрины list_*_cursor для UI-списков.
    """
    stmt = (
        select(ReferralLink)
        .where(ReferralLink.inviter_tg_id == inviter_tg_id)
        .order_by(ReferralLink.id.asc())
    )
    res = await db.execute(stmt)
    return list(res.scalars().all())


async def reassign_inviter(db: AsyncSession,
    *,
    invitee_tg_id: int,
    new_inviter_tg_id: int,
    note: str | None = None,) -> ReferralLink:
    """
    Переназначить пригласившего для приглашённого.
    Если связи не было — создаём.
    """
    link = await get_referral_link_by_invitee(
        db,
        invitee_tg_id=invitee_tg_id,
    )
    if link is None:
        return await create_referral_link(db,
            inviter_tg_id = new_inviter_tg_id,
            invitee_tg_id = invitee_tg_id,
            note = note,)
    link.inviter_tg_id = new_inviter_tg_id
    link.note = note
    db.add(link)
    await db.flush()
    return link


async def activate_referral(db: AsyncSession,
    *,
    invitee_tg_id: int,
    activation_bonus_hint: Decimal | None = None,
) -> ReferralLink | None:
    """
    Пометить реферала активным (после первой покупки панели).
    Возвращает обновлённую запись или None, если связи нет.

    Внимание: начисление бонусов EFHC делает сервис рефералов/банк.
    Здесь — только флаг.
    """
    link = await get_referral_link_by_invitee(
        db,
        invitee_tg_id=invitee_tg_id,
    )
    if link is None:
        return None
    if not link.is_active:
        link.is_active = True
        link.activated_at = datetime.now(UTC)
        # activation_bonus_efhc — информационное поле.
        # Для UI/отчетов
        # деньги — только через банк
        if activation_bonus_hint is not None:
            link.activation_bonus_efhc = d8(activation_bonus_hint)
        db.add(link)
        await db.flush()
    return link


# ======================================================================
# Курсорные витрины «Активные / Неактивные»
# ======================================================================

async def list_active_refs_cursor(db: AsyncSession,
    *,
    inviter_tg_id: int,
    limit: int = 50,
    next_cursor: str | None = None,
) -> tuple[list[ReferralLink], str | None]:
    """
    Список активных рефералов (is_active=TRUE) по курсору.
    Курсор кодирует (id ASC). Без OFFSET.
    """
    limit = max(1, min(int(limit), 200))
    after_id: int | None = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        raw = payload.get("after_id")
        after_id = int(raw) if raw is not None else None

    cond_after = None
    if after_id is not None:
        cond_after = ReferralLink.id > after_id

    stmt = (
        select(ReferralLink)
        .where(
            and_(
                ReferralLink.inviter_tg_id == inviter_tg_id,
                ReferralLink.is_active.is_(True),
            )
        )
        .order_by(ReferralLink.id.asc())
        .limit(limit)
    )
    if cond_after is not None:
        stmt = stmt.where(cond_after)

    res = await db.execute(stmt)
    items: list[ReferralLink] = list(res.scalars().all())
    next_c = None
    if items and len(items) == limit:
        next_c = encode_cursor({"after_id": int(items[-1].id)})
    return items, next_c


async def list_inactive_refs_cursor(db: AsyncSession,
    *,
    inviter_tg_id: int,
    limit: int = 50,
    next_cursor: str | None = None,
) -> tuple[list[ReferralLink], str | None]:
    """
    Список неактивных рефералов (is_active=FALSE) по курсору.
    Курсор кодирует (id ASC). Без OFFSET.
    """
    limit = max(1, min(int(limit), 200))
    after_id: int | None = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        raw = payload.get("after_id")
        after_id = int(raw) if raw is not None else None

    cond_after = None
    if after_id is not None:
        cond_after = ReferralLink.id > after_id

    stmt = (
        select(ReferralLink)
        .where(
            and_(
                ReferralLink.inviter_tg_id == inviter_tg_id,
                ReferralLink.is_active.is_(False),
            )
        )
        .order_by(ReferralLink.id.asc())
        .limit(limit)
    )
    if cond_after is not None:
        stmt = stmt.where(cond_after)

    res = await db.execute(stmt)
    items: list[ReferralLink] = list(res.scalars().all())
    next_c = None
    if items and len(items) == limit:
        next_c = encode_cursor({"after_id": int(items[-1].id)})
    return items, next_c


# ======================================================================
# Агрегаты по ссылкам
# ======================================================================

async def count_total_and_active(db: AsyncSession,
    *,
    inviter_tg_id: int,) -> tuple[int, int]:
    """
    Вернуть (total, active) по инвайтеру.
    """
    q_total = select(
        func.count(ReferralLink.id)
    ).where(ReferralLink.inviter_tg_id == inviter_tg_id)
    q_active = select(
        func.count(ReferralLink.id)
    ).where(
        and_(
            ReferralLink.inviter_tg_id == inviter_tg_id,
            ReferralLink.is_active.is_(True),
        )
    )
    total = int((await db.execute(q_total)).scalar_one() or 0)
    active = int((await db.execute(q_active)).scalar_one() or 0)
    return total, active


# ======================================================================
# Журнал бонусов рефералов (НЕ деньги, деньги — только через банк!)
# ======================================================================

async def add_bonus_record(db: AsyncSession,
    *,
    payload: BonusRecordCreate,) -> ReferralBonusLedger:
    """
    Добавить строку в журнал бонусов рефералов.
    Суммы приводятся к Decimal(8) вниз.
    Денежное начисление EFHC должен сделать банковский сервис.
    """
    rec = ReferralBonusLedger(tg_id = int(payload.tg_id),
        amount_efhc = d8(payload.amount_efhc),
        kind = str(payload.kind),
        meta = payload.meta,
        created_at = datetime.now(UTC),)
    db.add(rec)
    await db.flush()
    return rec


async def sum_bonus_for_user(db: AsyncSession,
    *,
    tg_id: int,) -> Decimal:
    """
    Вернуть сумму EFHC из журнала бонусов по tg_id.
    Это отчётная сумма журнала, она НЕ является балансом.
    Баланс — в users.*balance.
    """
    stmt = select(
        func.coalesce(
            func.sum(ReferralBonusLedger.amount_efhc),
            0,
        )
    ).where(ReferralBonusLedger.tg_id == tg_id)
    val = (await db.execute(stmt)).scalar_one() or 0
    return cast(Decimal, d8(Decimal(val)))


async def has_rank_bonus_paid(db: AsyncSession,
    *,
    tg_id: int,
    threshold: int,) -> bool:
    """
    Проверить, выплачивался ли ранговый бонус.
    По порогу активных рефералов.
    По соглашению, meta содержит «rank_threshold=<N>».
    """
    stmt = select(
        func.count(ReferralBonusLedger.id)
    ).where(
        and_(
            ReferralBonusLedger.tg_id == tg_id,
            ReferralBonusLedger.kind == "rank",
            ReferralBonusLedger.meta.ilike(
                f"%rank_threshold = {threshold}%"
            ),
        )
    )
    count = (await db.execute(stmt)).scalar_one()
    return bool(count > 0)


# ======================================================================
# Админские выборки/топы (для витрин)
# ======================================================================

async def admin_top_inviters(db: AsyncSession,
    *,
    limit: int = 10,) -> Sequence:
    """
    Топ по активным рефералам и сумме бонусов.

    SQL-идея:
      • active_subq: count(*) по is_active=TRUE группой по inviter.
      • bonus_subq: sum(amount_efhc) по журналу бонусов (tg_id).
      • Объединяем с users для получения username.
    """
    active_subq = (select(ReferralLink.inviter_tg_id.label("tg_id"),
            func.count(ReferralLink.id).label("active_count"),)
        .where(ReferralLink.is_active.is_(True))
        .group_by(ReferralLink.inviter_tg_id)
        .subquery())

    bonus_subq = (select(ReferralBonusLedger.tg_id.label("tg_id"),
            func.coalesce(
                func.sum(ReferralBonusLedger.amount_efhc),
                0,
            ).label("bonus_sum"),
        )
        .group_by(ReferralBonusLedger.tg_id)
        .subquery())

    stmt = (select(User.id,
            User.username,
            func.count(ReferralLink.id).label("total_invited"),
            func.coalesce(
                active_subq.c.active_count,
                0,
            ).label("active_invited"),
            func.coalesce(
                bonus_subq.c.bonus_sum,
                0,
            ).label("total_bonus_efhc"),
        )
        .join(
            ReferralLink,
            ReferralLink.inviter_tg_id == User.id,
            isouter=True,
        )
        .join(
            active_subq,
            active_subq.c.tg_id == User.id,
            isouter=True,
        )
        .join(bonus_subq, bonus_subq.c.tg_id == User.id, isouter = True)
        .group_by(
            User.id,
            User.username,
            active_subq.c.active_count,
            bonus_subq.c.bonus_sum,
        )
        .order_by(
            func.coalesce(active_subq.c.active_count, 0).desc(),
            func.coalesce(bonus_subq.c.bonus_sum, 0).desc(),
        )
        .limit(max(1, min(int(limit), 100))))
    res = await db.execute(stmt)
    return cast(Sequence[object], res.all())


# ======================================================================
# Пояснения (для разработчиков/ревью):
# • CRUD не двигает деньги — только хранит факты (связи и журнал
# бонусов).
# Любые EFHC-списки/начисления
# делаются строго банковским сервисом (transactions_service).
# • Витрины списков используют курсорную пагинацию по (id ASC) — надёжно
# и
# масштабируемо.
# • list_active_refs_cursor / list_inactive_refs_cursor дают «чистые»
# выборки
# для UI «Активные / Неактивные».
# • Активность реферала устанавливается сервисом панелей при первой
# покупке
# (здесь только флаг).
# • Админ-топ объединяет активных приглашённых и суммы бонусов из
# журнала — для
# дашборда.
# ======================================================================

