# -*- coding: utf-8 -*-
# backend/app/crud/panels_crud.py
# ======================================================================
# CRUD уровня БД для сущностей панелей:
# - создание панели пользователю (ставка per-sec);
# - выборка активных и архивных панелей с курсором (без OFFSET);
# - безопасная блокировка панелей под начисление (SKIP LOCKED);
# - закрытие/архивация просроченных панелей;
# - накопление generated_kwh с округлением вниз до d8;
# - reconcile_* проверки целостности (мягкая защита).
#
# Канон:
# per-sec ставки берутся только из Settings через SSOT helper.
# В БД панель хранит base_gen_per_sec (Decimal d8).
# Денежных операций EFHC здесь нет: только данные панелей.
# ======================================================================
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import and_, func, select, update, delete
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import aliased

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.core.system_locks import (
    get_rate_base_d8,
    get_rate_vip_d8,
)
from backend.app.lib.time import utcnow
from backend.app.deps import d8
from backend.app.core.system_locks import CANON_BASE
from backend.app.utils.cursor_codec import decode_cursor, encode_cursor
from backend.app.models.panels_models import Panel, PanelArchive

logger = get_logger(__name__)
settings = get_settings()

# Канон per-sec ставок (SSOT helper; без локальных копий литералов)
def _canon_rate_base_d8() -> Decimal:
    return get_rate_base_d8()


def _canon_rate_vip_d8() -> Decimal:
    return get_rate_vip_d8()

# Срок жизни панели по умолчанию (дней)
DEFAULT_PANEL_LIFETIME_DAYS: int = 180

# Максимум активных панелей у пользователя (канон)
MAX_PANELS: int = int(getattr(settings, "MAX_PANELS", 1000) or 1000)


# ======================================================================
# ВСПОМОГАТЕЛЬНОЕ: генерация курсора из записи панели
# ----------------------------------------------------------------------


def _make_cursor_for_panel(p: Panel) -> str:
    """
    Курсор строим по (created_at, id) — стабильный порядок, без OFFSET.
    """
    return encode_cursor(
        {"ts": p.created_at.isoformat(), "id": int(p.id)}
    )

# ======================================================================
# CREATE
# ----------------------------------------------------------------------
async def create_panel(
    db: AsyncSession,
    *,
    tg_id: int,
    base_gen_per_sec: Optional[Decimal] = None,
    lifetime_days: int = DEFAULT_PANEL_LIFETIME_DAYS,
    now: Optional[datetime] = None,
) -> Panel:
    """
    Создаёт новую панель для пользователя.
    • base_gen_per_sec — ставка per-sec; если None — канон
      GEN_PER_SEC_BASE_KWH.
    • lifetime_days — срок жизни (обычно 180).
    • Генерация начинается с generated_kwh=0 и
      last_generated_at=now.
    • Лимит MAX_PANELS проверяет сервисный уровень покупки.
    """
    ts = now or utcnow()
    if base_gen_per_sec is None:
        bps = _canon_rate_base_d8()
    else:
        bps = d8(base_gen_per_sec)

    p = Panel(
        tg_id=tg_id,
        created_at=ts,
        expires_at=ts + timedelta(days=int(lifetime_days)),
        last_generated_at=ts,
        base_gen_per_sec=d8(bps),
        generated_kwh=d8(0),
        is_active=True,
    )
    db.add(p)
    await db.flush()  # получим p.id
    logger.debug(
        "create_panel: tg_id=%s panel_id=%s bps=%s",
        tg_id,
        p.id,
        p.base_gen_per_sec,
    )
    return p


# ======================================================================
# READ: одна панель, счётчики, лимиты
# ----------------------------------------------------------------------
async def get_panel(db: AsyncSession, panel_id: int) -> Optional[Panel]:
    """Возвращает панель по id (или None)."""
    res = await db.execute(select(Panel).where(Panel.id == panel_id))
    return res.scalars().first()


async def count_active_by_user(db: AsyncSession, tg_id: int) -> int:
    """Считает активные панели пользователя."""
    stmt = select(func.count(Panel.id)).where(
        and_(Panel.tg_id == tg_id, Panel.is_active.is_(True))
    )
    res = await db.execute(stmt)
    return int(res.scalar_one() or 0)


# ======================================================================
# LIST: активные панели пользователя (курсоры без OFFSET)
# ----------------------------------------------------------------------
async def list_active_by_user_cursor(db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
    asc: bool = False,) -> Tuple[List[Panel], Optional[str]]:
    """
    Возвращает страницу активных панелей пользователя.
    Пагинация — по курсору (created_at, id), без OFFSET.
    """
    limit = max(1, min(int(limit), 200))

    created_from: Optional[datetime] = None
    id_from: Optional[int] = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        ts = payload.get("ts")
        created_from = datetime.fromisoformat(ts) if ts else None
        raw_id = payload.get("id")
        if raw_id is not None:
            id_from = int(raw_id or 0)

    q = select(Panel).where(
        and_(Panel.tg_id == tg_id, Panel.is_active.is_(True))
    )

    if created_from is not None and id_from is not None:
        # курсор: (created_at, id)
        if asc:
            q = q.where(
                (Panel.created_at, Panel.id) >
                (created_from, id_from)
            )
        else:
            q = q.where(
                (Panel.created_at, Panel.id) <
                (created_from, id_from)
            )

    # порядок стабилен, курсор построен аналогично
    if asc:
        q = q.order_by(Panel.created_at.asc(), Panel.id.asc())
    else:
        q = q.order_by(Panel.created_at.desc(), Panel.id.desc())

    q = q.limit(limit)
    res = await db.execute(q)
    items: List[Panel] = list(res.scalars().all())

    next_c = None
    if items and len(items) == limit:
        next_c = _make_cursor_for_panel(items[-1])
    return items, next_c


# ======================================================================
# LIST: архивные панели пользователя (курсоры без OFFSET)
# ----------------------------------------------------------------------
async def list_archived_by_user_cursor(db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
    asc: bool = False,) -> Tuple[List[PanelArchive], Optional[str]]:
    """
    Возвращает страницу архивных панелей пользователя.
    Пагинация — по курсору (archived_at, id), без OFFSET.
    """
    limit = max(1, min(int(limit), 200))
    archived_from: Optional[datetime] = None
    id_from: Optional[int] = None
    if next_cursor:
        payload = decode_cursor(next_cursor)
        ts = payload.get("ts")
        archived_from = datetime.fromisoformat(ts) if ts else None
        raw_id = payload.get("id")
        if raw_id is not None:
            id_from = int(raw_id or 0)

    q = select(PanelArchive).where(PanelArchive.tg_id == tg_id)

    if archived_from is not None and id_from is not None:
        if asc:
            q = q.where(
                (PanelArchive.archived_at, PanelArchive.id) >
                (archived_from, id_from)
            )
        else:
            q = q.where(
                (PanelArchive.archived_at, PanelArchive.id) <
                (archived_from, id_from)
            )

    if asc:
        q = q.order_by(
            PanelArchive.archived_at.asc(),
            PanelArchive.id.asc(),
        )
    else:
        q = q.order_by(
            PanelArchive.archived_at.desc(),
            PanelArchive.id.desc(),
        )

    q = q.limit(limit)
    res = await db.execute(q)
    items: List[PanelArchive] = list(res.scalars().all())

    if items and len(items) == limit:
        last = items[-1]
        next_c = encode_cursor(
            {"ts": last.archived_at.isoformat(), "id": int(last.id)}
        )
    else:
        next_c = None

    return items, next_c


# ======================================================================
# LOCK-FETCH: выдача активных панелей для начисления энергии
# ----------------------------------------------------------------------
async def lock_active_panels_for_energy(db: AsyncSession,
    *,
    limit: int = 500,) -> List[Panel]:
    """
    Возвращает пакет активных панелей под начисление,
    с FOR UPDATE SKIP LOCKED.
    блокируя их SKIP LOCKED — чтобы несколько воркеров не обрабатывали
    одни и те же панели.
    Порядок: по id (стабильно).
    """
    limit = max(1, min(int(limit), 2000))
    q = (select(Panel)
        .where(Panel.is_active.is_(True))
        .order_by(Panel.id.asc())
        .limit(limit)
        .with_for_update(skip_locked = True))
    res = await db.execute(q)
    panels: List[Panel] = list(res.scalars().all())
    return panels


# ======================================================================
# UPDATE: накапливание энергии по панели
# ----------------------------------------------------------------------
async def accrue_generated_kwh(
    db: AsyncSession,
    *,
    panel_id: int,
    delta_kwh: Decimal,
    new_last_generated_at: Optional[datetime] = None,
) -> Optional[Panel]:
    """Накопить generated_kwh на панели и обновить last_generated_at."""

    if delta_kwh <= 0:
        # ничего не делаем — это не ошибка
        logger.debug(
            "accrue_generated_kwh: skip non - positive "
            "delta (panel_id=%s, delta=%s)",
            panel_id,
            delta_kwh,
        )
        res = await db.execute(
            select(Panel).where(Panel.id == panel_id)
        )
        return res.scalars().first()

    stmt = select(Panel).where(
        and_(Panel.id == panel_id, Panel.is_active.is_(True))
    )
    res = await db.execute(stmt)
    p: Optional[Panel] = res.scalars().first()
    if not p:
        return None

    # вычисляем новое значение
    new_val = d8(Decimal(p.generated_kwh or 0) + Decimal(delta_kwh))
    p.generated_kwh = new_val
    if new_last_generated_at:
        p.last_generated_at = new_last_generated_at
    await db.flush()
    return p


# ======================================================================
# EXPIRE/ARCHIVE: перевод просроченных панелей в архив
# ----------------------------------------------------------------------
async def close_and_archive_due_panels(db: AsyncSession,
    *,
    now: Optional[datetime] = None,
    batch_limit: int = 1000,) -> int:
    """
    Находит активные панели с истёкшим сроком (expires_at <= now),
    помечает их неактивными и переносит в PanelArchive.
    Возвращает количество переведённых в архив.
    """
    ts = now or datetime.now(timezone.utc)

    # 1) достаём список просроченных активных панелей небольшими пачками
    q = (select(Panel)
        .where(and_(Panel.is_active.is_(True), Panel.expires_at <= ts))
        .order_by(Panel.id.asc())
        .limit(max(1, min(int(batch_limit), 5000)))
        .with_for_update(skip_locked = True))
    res = await db.execute(q)
    to_close: List[Panel] = list(res.scalars().all())
    if not to_close:
        return 0

    count = 0
    for p in to_close:
        # ставим флаг
        p.is_active = False
        await db.flush()

        # переносим в архив
        arch = PanelArchive(tg_id = p.tg_id,
            created_at = p.created_at,
            expires_at = p.expires_at,
            archived_at = ts,
            base_gen_per_sec = p.base_gen_per_sec,
            generated_kwh = p.generated_kwh,
            last_generated_at = p.last_generated_at,
            source_panel_id = p.id,)
        db.add(arch)
        count += 1

    await db.flush()
    logger.info("close_and_archive_due_panels: archived=%s", count)
    return count


# ======================================================================
# RECONCILE / HEALING: самовосстановительные помощники
# ----------------------------------------------------------------------
async def reconcile_negative_or_nulls(db: AsyncSession) -> int:
    """
    ИИ-защита: приводит поля generated_kwh к допустимым значениям.
    • Если где-то generated_kwh < 0 — поднимаем до 0.
    • last_generated_at NULL — ставим created_at.
    Возвращает количество «подлеченных» строк.
    """
    fixed = 0

    # generated_kwh < 0 → 0
    stmt = select(Panel).where(
        and_(Panel.generated_kwh.isnot(None), Panel.generated_kwh < 0)
    )
    res = await db.execute(stmt)
    bad_panels: List[Panel] = list(res.scalars().all())
    for p in bad_panels:
        p.generated_kwh = d8(0)
        fixed += 1

    # last_generated_at is NULL → created_at
    stmt = select(Panel).where(Panel.last_generated_at.is_(None))
    res = await db.execute(stmt)
    missing_ts: List[Panel] = list(res.scalars().all())
    for p in missing_ts:
        p.last_generated_at = p.created_at
        fixed += 1

    if fixed:
        await db.flush()
        logger.warning("reconcile_negative_or_nulls: fixed=%s", fixed)
    return fixed


async def reconcile_orphan_archives(db: AsyncSession) -> int:
    """
    ИИ-защита: если есть неактивные панели без записи
    в PanelArchive — создаём архивную запись.
    переносим их в архив, чтобы витрины были согласованы.
    Возвращает число перенесённых.
    """
    # находим «неактивные без архива»
    A = aliased(PanelArchive)
    q = (select(Panel)
        .where(Panel.is_active.is_(False))
        .where(
            ~select(A.id)
            .where(A.source_panel_id == Panel.id)
            .exists()
        )
        .order_by(Panel.id.asc())
        .limit(5000)
        .with_for_update(skip_locked = True))
    res = await db.execute(q)
    items: List[Panel] = list(res.scalars().all())
    if not items:
        return 0

    ts = datetime.now(timezone.utc)
    for p in items:
        arch = PanelArchive(tg_id = p.tg_id,
            created_at = p.created_at,
            expires_at = p.expires_at,
            archived_at = ts,
            base_gen_per_sec = p.base_gen_per_sec,
            generated_kwh = p.generated_kwh,
            last_generated_at = p.last_generated_at,
            source_panel_id = p.id,)
        db.add(arch)

    await db.flush()
    logger.warning(
        "reconcile_orphan_archives: created archives=%s",
        len(items)
    )
    return len(items)


# ======================================================================
# ВСПОМОГАТЕЛЬНОЕ: правка ставки на канон (если нужно).
# ----------------------------------------------------------------------
async def force_reset_base_rate_to_canon(db: AsyncSession,
    *,
    panel_ids: Sequence[int],) -> int:
    """
    Опционально: для аварийного исправления панелей, которым ошибочно
    проставили «не каноническую» ставку base_gen_per_sec.
    Здесь просто возвращаем значение на GEN_PER_SEC_BASE_KWH (не VIP!).
    Возвращает число обновлённых строк.
    """
    if not panel_ids:
        return 0
    q = (update(Panel)
        .where(Panel.id.in_(list(panel_ids)))
        .values(base_gen_per_sec=d8(CANON_BASE)))
    res = await db.execute(q)
    n = int(res.rowcount or 0)
    if n:
        await db.flush()
        logger.warning("force_reset_base_rate_to_canon: fixed=%s", n)
    return n


# ======================================================================
# Пояснения (для разработчиков/ревью):
# • list_*_by_user_cursor: курсор формируется по
# (created_at,id)/(archived_at,id).
# Это гарантирует стабильный «бесконечный скролл» без OFFSET.
# • lock_active_panels_for_energy: SKIP LOCKED защищает от гонок между
# воркерами
# начисления энергии. Обработка идёт пакетами, порядок — id.
# • accrue_generated_kwh: накапливает кВт⋅ч по панели (d8).
# знаками),
#   EFHC-операций нет. Балансы пользователя — вне этого модуля.
# • close_and_archive_due_panels: снимает флаг активности и
#   создаёт архивные записи.
# зеркальную запись в PanelArchive (для витрин «Архив»).
# • reconcile_* функции: мягкая поддержка целостности.
# молча лечат данные и пишут предупреждения в лог.
# ======================================================================

