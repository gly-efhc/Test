# -*- coding: utf-8 -*-
# backend/app/crud/lotteries_crud.py
# ======================================================================
# Назначение кода:
# CRUD-уровень для лотерей и билетов:
# • Лотереи: создать/обновить/получить, курсорные списки для витрин
# (user/admin),
# guarded-переключатели активности и временных окон.
# • Билеты: зарезервировать (idempotent по client_nonce),
#   изменить статус
# (RESERVED → PENDING_PAYMENT → PAID/REFUNDED/CANCELLED/EXPIRED),
# списки и счётчики, мягкая уборка старых записей.
#
# Канон / инварианты:
# • Денежной логики здесь НЕТ: никаких списаний/начислений EFHC — только
# сервисы.
# • Идемпотентность резерва билета — через уникальный client_nonce
#   (UNIQUE).
# • Все списки — курсорная пагинация по id (ASC), без OFFSET.
#
# ИИ-защита / самовосстановление:
# • «Read-through» при конфликте UNIQUE (client_nonce):
#   не валим процесс,
# возвращаем имеющуюся запись билета.
# • Guarded-апдейты статусов (меняем только из ожидаемого),
#   снижают гонки.
# • Уборка EXPIRED/CANCELLED партиями, чтобы не блокировать индексы.
#
# Запреты:
# • Никаких commit()/rollback() — транзакцией управляет сервис/роут.
# • Нет P2P и денежных операций: любые EFHC-движения — строго через
# банк-сервис.
# • Нет «незавершённостей» — функции готовы к продакшену.
# ======================================================================

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import and_, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger

# Канонические утилиты округления/безопасных чисел централизованы
try:
    from backend.app.deps import d8
    # основной путь (единый источник истины)
except Exception:  # pragma: no cover
    from backend.app.core.utils_core import d8  # type: ignore

# Ожидаемые модели из backend.app.models.lotteries_models
try:
    from backend.app.models.lotteries_models import (
        Lotteries,
        LotteriesTicket,
    )
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "Ожидаются модели Lotteries и LotteriesTicket "
        "в backend.app.models.lotteries_models. "
        "Проверьте синхронизацию моделей/миграций."
    ) from exc

logger = get_logger(__name__)

# Общие статусы билетов
TICKET_RESERVED = "RESERVED"
TICKET_PENDING = "PENDING_PAYMENT"
TICKET_PAID = "PAID"
TICKET_REFUNDED = "REFUNDED"
TICKET_CANCELLED = "CANCELLED"
TICKET_EXPIRED = "EXPIRED"

# ----------------------------------------------------------------------
# ЛОТЕРЕИ — базовые операции
# ----------------------------------------------------------------------

async def get_lotteries_by_id(
    session: AsyncSession,
    lotteries_id: int,
) -> Optional[Lotteries]:
    """Возвращает лотерею по первичному ключу (или None)."""
    stmt = (
        select(Lotteries)
        .where(Lotteries.id == int(lotteries_id))
        .limit(1)
    )
    res = await session.execute(stmt)
    return res.scalar_one_or_none()


async def get_lotteries_by_code(
    session: AsyncSession,
    code: str,
) -> Optional[Lotteries]:
    """Возвращает лотерею по уникальному коду (или None)."""
    stmt = select(Lotteries).where(Lotteries.code == code).limit(1)
    res = await session.execute(stmt)
    return res.scalar_one_or_none()


async def list_public_lotteries(
    session: AsyncSession,
    *,
    now: Optional[datetime] = None,
    only_active: bool = True,
    include_future: bool = True,
    limit: int = 50,
    after_id: Optional[int] = None,
) -> Tuple[List[Lotteries], Optional[int]]:
    """
    Витрина для пользователя. Возвращает лотереи курсором (ASC id).

    Фильтры:
      • only_active=True — только активные (flag).
      • include_future — включать ли ещё не стартовавшие.
      • по умолчанию показываем активные и «идущие/предстоящие».
    """
    now = now or datetime.utcnow()
    stmt = select(Lotteries)
    if only_active:
        stmt = stmt.where(Lotteries.active.is_(True))

    # Идущие или будущие
    if include_future:
        stmt = stmt.where(
            or_(
                Lotteries.ends_at.is_(None),
                Lotteries.ends_at >= now,
            )
        )
    else:
        # Только текущие
        stmt = stmt.where(
            and_(
                or_(
                    Lotteries.starts_at.is_(None),
                    Lotteries.starts_at <= now,
                ),
                or_(
                    Lotteries.ends_at.is_(None),
                    Lotteries.ends_at >= now,
                ),
            )
        )

    if after_id:
        stmt = stmt.where(Lotteries.id > int(after_id))
    stmt = stmt.order_by(Lotteries.id.asc()).limit(int(limit))

    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor: Optional[int] = None
    if items and len(items) == int(limit):
        next_cursor = int(items[-1].id)
    return items, next_cursor


async def list_admin_lotteries(session: AsyncSession,
    *,
    active: Optional[bool] = None,
    code_like: Optional[str] = None,
    limit: int = 50,
    after_id: Optional[int] = None,
) -> Tuple[List[Lotteries], Optional[int]]:
    """
    Витрина для админа. Курсорная пагинация по id (ASC).

    Фильтры: active/code.
    """
    stmt = select(Lotteries)
    if active is not None:
        stmt = stmt.where(Lotteries.active.is_(bool(active)))
    if code_like:
        stmt = stmt.where(Lotteries.code.ilike(f"%{code_like}%"))

    if after_id:
        stmt = stmt.where(Lotteries.id > int(after_id))
    stmt = stmt.order_by(Lotteries.id.asc()).limit(int(limit))

    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor: Optional[int] = None
    if items and len(items) == int(limit):
        next_cursor = int(items[-1].id)
    return items, next_cursor


async def create_lotteries(session: AsyncSession,
    *,
    code: str,
    title: str,
    description: Optional[str],
    ticket_price_efhc: Decimal,
    starts_at: Optional[datetime],
    ends_at: Optional[datetime],
    max_tickets_total: Optional[int],
    max_tickets_per_user: Optional[int] = None,
    vip_only: bool = False,
    active: bool = True,) -> Lotteries:
    """
    Что делает: Создаёт лотерею. Денежной логики нет — только INSERT.
    Важно: ticket_price_efhc хранится с точностью 8 знаков (d8).
    """
    lot = Lotteries(code = code,
        title = title,
        description = (description or None),
        ticket_price_efhc = d8(ticket_price_efhc),
        starts_at = starts_at,
        ends_at = ends_at,
        max_tickets_total=(
            int(max_tickets_total)
            if max_tickets_total is not None
            else None
        ),
        max_tickets_per_user=(
            int(max_tickets_per_user)
            if max_tickets_per_user is not None
            else None
        ),
        vip_only = bool(vip_only),
        active = bool(active),)
    session.add(lot)
    return lot


async def update_lotteries_fields(session: AsyncSession,
    *,
    lotteries_id: int,
    title: Optional[str] = None,
    description: Optional[str] = None,
    ticket_price_efhc: Optional[Decimal] = None,
    starts_at: Optional[datetime] = None,
    ends_at: Optional[datetime] = None,
    max_tickets_total: Optional[int] = None,
    max_tickets_per_user: Optional[int] = None,
    vip_only: Optional[bool] = None,
    active: Optional[bool] = None,) -> Optional[Lotteries]:
    """
    Обновляет поля лотереи. Возвращает актуальную запись или None.

    Guarded-логика статусов выполняется на сервисном уровне (например,
    запрет менять активность без проверок).
    активность вне дозволенных окон времени — не здесь).
    """
    lot = await get_lotteries_by_id(session, lotteries_id)
    if not lot:
        return None

    if title is not None:
        lot.title = title
    if description is not None:
        lot.description = description
    if ticket_price_efhc is not None:
        lot.ticket_price_efhc = d8(ticket_price_efhc)
    if starts_at is not None:
        lot.starts_at = starts_at
    if ends_at is not None:
        lot.ends_at = ends_at
    if max_tickets_total is not None:
        lot.max_tickets_total = int(max_tickets_total)
    if max_tickets_per_user is not None:
        lot.max_tickets_per_user = int(max_tickets_per_user)
    if vip_only is not None:
        lot.vip_only = bool(vip_only)
    if active is not None:
        lot.active = bool(active)

    await session.flush()
    return lot


async def set_lotteries_active_guarded(session: AsyncSession,
    *,
    lotteries_id: int,
    active: bool,
    expected_prev: Optional[Iterable[bool]] = None,
) -> Optional[Lotteries]:
    """
    Что делает: Меняет флаг активности guarded-образом:
      • если expected_prev задан — меняем только при совпадении.

    Это снижает гонки при параллельном управлении.
    """
    lot = await get_lotteries_by_id(session, lotteries_id)
    if not lot:
        return None

    if expected_prev is not None:
        if lot.active not in set(expected_prev):
            return lot

    lot.active = bool(active)
    await session.flush()
    return lot


# ----------------------------------------------------------------------
# БИЛЕТЫ — резервы/статусы/списки
# ----------------------------------------------------------------------

async def get_ticket_by_id(
    session: AsyncSession,
    ticket_id: int,
) -> Optional[LotteriesTicket]:
    """Возвращает билет по id (или None)."""
    stmt = (
        select(LotteriesTicket)
        .where(LotteriesTicket.id == int(ticket_id))
        .limit(1)
    )
    res = await session.execute(stmt)
    return res.scalar_one_or_none()


async def get_ticket_by_client_nonce(
    session: AsyncSession,
    *,
    lotteries_id: int,
    user_tg_id: int,
    client_nonce: str,
) -> Optional[LotteriesTicket]:
    """
    Возвращает билет по (lotteries_id, user_tg_id, client_nonce).

    Ожидается UNIQUE-индекс на эту тройку для идемпотентности резервов.
    """
    stmt = (
        select(LotteriesTicket)
        .where(
            and_(
                LotteriesTicket.lotteries_id == int(lotteries_id),
                LotteriesTicket.user_tg_id == int(user_tg_id),
                LotteriesTicket.client_nonce == client_nonce,
            )
        )
        .limit(1)
    )
    res = await session.execute(stmt)
    return res.scalar_one_or_none()


async def count_user_effective_tickets(
    session: AsyncSession,
    *,
    lotteries_id: int,
    user_tg_id: int,
    include_statuses: Sequence[str] = (
        TICKET_RESERVED,
        TICKET_PENDING,
        TICKET_PAID,
    ),
) -> int:
    """
    Возвращает количество «эффективных» билетов пользователя в лотерее.

    Учитываются статусы, влияющие на лимит per-user.
    """
    stmt = select(func.count(LotteriesTicket.id)).where(
        and_(
            LotteriesTicket.lotteries_id == int(lotteries_id),
            LotteriesTicket.user_tg_id == int(user_tg_id),
            LotteriesTicket.status.in_(list(include_statuses)),
        )
    )
    res = await session.execute(stmt)
    return int(res.scalar() or 0)


async def count_lotteries_effective_sold(
    session: AsyncSession,
    *,
    lotteries_id: int,
    include_statuses: Sequence[str] = (
        TICKET_RESERVED,
        TICKET_PENDING,
        TICKET_PAID,
    ),
) -> int:
    """
    Возвращает количество «занятых» билетов в заданных статусах.

    Нужна для проверки лимита max_tickets_total на сервисном уровне.
    """
    stmt = select(func.count(LotteriesTicket.id)).where(
        and_(
            LotteriesTicket.lotteries_id == int(lotteries_id),
            LotteriesTicket.status.in_(list(include_statuses)),
        )
    )
    res = await session.execute(stmt)
    return int(res.scalar() or 0)


async def reserve_ticket_idempotent(session: AsyncSession,
    *,
    lotteries_id: int,
    user_tg_id: int,
    client_nonce: str,
    status: str = TICKET_RESERVED,
    price_snapshot_efhc: Optional[Decimal] = None,) -> LotteriesTicket:
    """
    Идемпотентный резерв билета (client_nonce).

    При конфликте UNIQUE возвращает существующий билет (read-through).
    Лимиты total/per-user проверяются на сервисном уровне.
    """
    ticket = LotteriesTicket(lotteries_id=int(lotteries_id),
        user_tg_id=int(user_tg_id),
        status=status,
        client_nonce=client_nonce,
        price_snapshot_efhc=(
            d8(price_snapshot_efhc)
            if price_snapshot_efhc is not None
            else None
        ),
    )
    session.add(ticket)
    try:
        await session.flush()
        return ticket
    except IntegrityError:
        existing = await get_ticket_by_client_nonce(session,
            lotteries_id=lotteries_id,
            user_tg_id=user_tg_id,
            client_nonce=client_nonce,)
        if existing:
            return existing
        raise  # крайне редкий случай: отдаём выше


async def set_ticket_status_guarded(session: AsyncSession,
    *,
    ticket_id: int,
    new_status: str,
    expected_prev: Sequence[str] | None = None,
    paid_amount_efhc: Optional[Decimal] = None,
    paid_balance_type: Optional[str] = None,
    # "main" / "bonus" — если нужно
    efhc_transfer_log_id: Optional[int] = None,
    # ссылка на efhc_transfers_log
    paid_at: Optional[datetime] = None,) -> Optional[LotteriesTicket]:
    """
    Что делает: Меняет статус билета с защитой от гонок.
    Если expected_prev задан — меняем только из этих статусов.
    Иначе — без проверки.
    Побочные поля (оплата/логи) можно заполнить для аудита.
    """
    t = await get_ticket_by_id(session, ticket_id)
    if not t:
        return None

    if expected_prev and t.status not in set(expected_prev):
        return t

    t.status = new_status
    if paid_amount_efhc is not None:
        t.paid_amount_efhc = d8(paid_amount_efhc)
    if paid_balance_type is not None:
        t.paid_balance_type = paid_balance_type
    if efhc_transfer_log_id is not None:
        t.efhc_transfer_log_id = int(efhc_transfer_log_id)
    if paid_at is not None:
        t.paid_at = paid_at

    await session.flush()
    return t


async def expire_old_reservations(session: AsyncSession,
    *,
    lotteries_id: int,
    older_than_minutes: int = 15,
    batch_limit: int = 1000,) -> int:
    """
    Переводит «протухшие» RESERVED в EXPIRED партиями (до batch_limit).

    Освобождаем «занятые» места и снижаем ложный дефицит.
    """
    threshold = datetime.utcnow() - timedelta(
        minutes=int(older_than_minutes)
    )

    res = await session.execute(select(LotteriesTicket)
        .where(and_(LotteriesTicket.lotteries_id == int(lotteries_id),
                LotteriesTicket.status == TICKET_RESERVED,
                LotteriesTicket.created_at < threshold,))
        .order_by(LotteriesTicket.id.asc())
        .limit(int(batch_limit)))
    items = list(res.scalars().all())
    for t in items:
        t.status = TICKET_EXPIRED
        t.paid_amount_efhc = None
        t.paid_balance_type = None
        t.efhc_transfer_log_id = None
        t.paid_at = None
    await session.flush()
    return len(items)


async def list_tickets_for_user(session: AsyncSession,
    *,
    user_tg_id: int,
    lotteries_id: Optional[int] = None,
    limit: int = 50,
    after_id: Optional[int] = None,
    statuses: Optional[Sequence[str]] = None,
) -> Tuple[List[LotteriesTicket], Optional[int]]:
    """
    Что делает: Возвращает билеты пользователя курсором по id (ASC).
    Фильтры: по лотерее и/или по статусам.
    """
    stmt = select(LotteriesTicket).where(
        LotteriesTicket.user_tg_id == int(user_tg_id)
    )
    if lotteries_id is not None:
        stmt = stmt.where(
            LotteriesTicket.lotteries_id == int(lotteries_id)
        )
    if statuses:
        stmt = stmt.where(LotteriesTicket.status.in_(list(statuses)))
    if after_id:
        stmt = stmt.where(LotteriesTicket.id > int(after_id))

    stmt = stmt.order_by(LotteriesTicket.id.asc()).limit(int(limit))
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor: Optional[int] = None
    if items and len(items) == int(limit):
        next_cursor = int(items[-1].id)
    return items, next_cursor


async def list_tickets_admin(
    session: AsyncSession,
    *,
    lotteries_id: Optional[int] = None,
    user_tg_id: Optional[int] = None,
    statuses: Optional[Sequence[str]] = None,
    limit: int = 50,
    after_id: Optional[int] = None,
) -> Tuple[List[LotteriesTicket], Optional[int]]:
    """
    Админ-витрина билетов курсором по id (ASC).

    Фильтры: по лотерее, пользователю и/или статусам.
    """
    stmt = select(LotteriesTicket)
    if lotteries_id is not None:
        stmt = stmt.where(
            LotteriesTicket.lotteries_id == int(lotteries_id)
        )
    if user_tg_id is not None:
        stmt = stmt.where(LotteriesTicket.user_tg_id == int(user_tg_id))
    if statuses:
        stmt = stmt.where(LotteriesTicket.status.in_(list(statuses)))
    if after_id:
        stmt = stmt.where(LotteriesTicket.id > int(after_id))

    stmt = stmt.order_by(LotteriesTicket.id.asc()).limit(int(limit))
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    next_cursor: Optional[int] = None
    if items and len(items) == int(limit):
        next_cursor = int(items[-1].id)
    return items, next_cursor


async def count_ticket_statuses(session: AsyncSession,
    *,
    lotteries_id: int,) -> List[Tuple[str, int]]:
    """
    Возвращает агрегаты по статусам для лотереи.
    Полезно для админ - панели и мониторинга.
    """
    stmt = (
        select(
            LotteriesTicket.status,
            func.count(LotteriesTicket.id),
        )
        .where(LotteriesTicket.lotteries_id == int(lotteries_id))
        .group_by(LotteriesTicket.status)
    )
    res = await session.execute(stmt)
    return [(row[0], int(row[1])) for row in res.all()]


async def delete_old_soft(
    session: AsyncSession,
    *,
    days: int = 30,
    batch_limit: int = 1000,
    statuses: Sequence[str] = (
        TICKET_CANCELLED,
        TICKET_EXPIRED,
        TICKET_REFUNDED,
    ),
) -> int:
    """
    Удаляет «мягко завершённые» билеты старше N дней партиями,
    чтобы не блокировать индексы и не держать долгие транзакции.
    Возвращает: сколько записей удалено в этом вызове.
    """
    threshold = datetime.utcnow() - timedelta(days=int(days))
    stmt = (
        select(LotteriesTicket)
        .where(
            and_(
                LotteriesTicket.updated_at < threshold,
                LotteriesTicket.status.in_(list(statuses)),
            )
        )
        .order_by(LotteriesTicket.id.asc())
        .limit(int(batch_limit))
    )
    res = await session.execute(stmt)
    items = list(res.scalars().all())
    for t in items:
        await session.delete(t)
    # flush/commit — на вызывающем уровне
    return len(items)


# ======================================================================
# Пояснения «для чайника»:
# • Почему нет денег в CRUD?
# Любые EFHC-движения (покупка билета, возврат) живут в сервисах
# (shop/lotteries/transactions_service), чтобы обеспечить канон:
# единый банк, идемпотентность.
# зеркальные логи и запреты.
#
# • Зачем client_nonce?
# Это мягкая идемпотентность кликов во фронтенде. При повторе
# запроса с тем же client_nonce мы не создадим дубликат,
# а вернём существующий билет.
# билет — система «самовосстанавливается» без ручного вмешательства.
#
# • Курсов нет?
# Внутренний «курс» EFHC↔kWh фиксирован (1:1) и не относится к лотереям.
# Цены билетов в EFHC лежат в моделях/БД и передаются сервисам;
# CRUD только
# читает/пишет значения (d8).
#
# • Где проверка лимитов?
# Лимиты «всего билетов» и «на пользователя» считаются в сервисном слое,
# который
# перед reserve_ticket_idempotent проверяет счётчики через функции
# count_user_effective_tickets / count_lotteries_effective_sold
# и решает, можно ли резервировать.
# резервировать. CRUD не реализует бизнес-ветвления денег.
# ======================================================================

