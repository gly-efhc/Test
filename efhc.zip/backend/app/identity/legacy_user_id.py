"""Явный LEGACY compatibility layer физического имени ``user_id``.

Новый production-код не импортирует этот модуль. Он существует только
для исторических DTO, миграционных инструментов и контролируемой
очистки после физического rename ``users.user_id → users.global_id``.
"""

from __future__ import annotations

from typing import Final, TypeGuard

from app.identity.api_contract import (
    GLOBAL_ID_OPENAPI_EXAMPLE,
    GLOBAL_ID_OPENAPI_FORMAT,
    GLOBAL_ID_OPENAPI_SCHEMA,
    ApiExternalGlobalId,
    PydanticGlobalId,
)
from app.identity.types import (
    GLOBAL_ID_DIGITS,
    GLOBAL_ID_MAX,
    GLOBAL_ID_MIN,
    GLOBAL_ID_PATTERN,
    GLOBAL_ID_PATTERN_TEXT,
    ExternalGlobalId,
    GlobalId,
    GlobalIdDisplay,
    InvalidGlobalId,
    format_global_id,
    global_id_from_database,
    global_id_to_database,
    is_global_id,
    parse_global_id,
    validate_global_id,
    validate_global_id_display,
)
from pydantic import BaseModel, ConfigDict, Field

USER_ID_MIN: Final[int] = GLOBAL_ID_MIN
USER_ID_MAX: Final[int] = GLOBAL_ID_MAX
USER_ID_DIGITS: Final[int] = GLOBAL_ID_DIGITS
USER_ID_PATTERN_TEXT: Final[str] = GLOBAL_ID_PATTERN_TEXT
USER_ID_PATTERN = GLOBAL_ID_PATTERN

UserId = GlobalId
UserIdDisplay = GlobalIdDisplay
InvalidUserId = InvalidGlobalId
ExternalUserId = ExternalGlobalId
ApiExternalUserId = ApiExternalGlobalId
PydanticUserId = PydanticGlobalId
USER_ID_OPENAPI_FORMAT = GLOBAL_ID_OPENAPI_FORMAT
USER_ID_OPENAPI_EXAMPLE = GLOBAL_ID_OPENAPI_EXAMPLE
USER_ID_OPENAPI_SCHEMA = GLOBAL_ID_OPENAPI_SCHEMA


def validate_user_id(value: object) -> GlobalId:
    """LEGACY wrapper: использовать ``validate_global_id``."""

    return validate_global_id(value)


def validate_user_id_display(value: object) -> GlobalIdDisplay:
    """LEGACY wrapper: использовать ``validate_global_id_display``."""

    return validate_global_id_display(value)


def format_user_id(value: GlobalId) -> GlobalIdDisplay:
    """LEGACY wrapper: использовать ``format_global_id``."""

    return format_global_id(value)


def parse_user_id(value: object) -> GlobalId:
    """LEGACY wrapper: использовать ``parse_global_id``."""

    return parse_global_id(value)


def user_id_from_database(value: object) -> GlobalId:
    """LEGACY wrapper reverse alias ``User.user_id``.

    Физическая owner-колонка — ``users.global_id``.
    """

    return global_id_from_database(value)


def user_id_to_database(value: GlobalId) -> int:
    """LEGACY wrapper reverse alias ``User.user_id``.

    Физическая owner-колонка — ``users.global_id``.
    """

    return int(global_id_to_database(value))


def is_user_id(value: object) -> TypeGuard[GlobalId]:
    """LEGACY wrapper: использовать ``is_global_id``."""

    return bool(is_global_id(value))


class UserIdRequest(BaseModel):
    """LEGACY request envelope физического имени ``user_id``."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    user_id: PydanticGlobalId = Field(
        ...,
        description=(
            "LEGACY имя канонического global_id; только совместимость."
        ),
        examples=[GLOBAL_ID_OPENAPI_EXAMPLE],
    )


class UserIdResponse(BaseModel):
    """LEGACY response envelope физического имени ``user_id``."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    user_id: PydanticGlobalId = Field(
        ...,
        description=(
            "LEGACY имя канонического global_id; только совместимость."
        ),
        examples=[GLOBAL_ID_OPENAPI_EXAMPLE],
    )

    @classmethod
    def from_user_id(cls, user_id: GlobalId) -> UserIdResponse:
        """Построить LEGACY envelope из проверенного ``GlobalId``."""

        if not isinstance(user_id, GlobalId):
            raise InvalidGlobalId(
                "UserIdResponse требует проверенный GlobalId",
                code="global_id.nominal_required",
            )
        return cls(user_id=user_id)


__all__ = [
    "USER_ID_MIN",
    "USER_ID_MAX",
    "USER_ID_DIGITS",
    "USER_ID_PATTERN_TEXT",
    "USER_ID_PATTERN",
    "UserId",
    "UserIdDisplay",
    "InvalidUserId",
    "ExternalUserId",
    "ApiExternalUserId",
    "PydanticUserId",
    "USER_ID_OPENAPI_FORMAT",
    "USER_ID_OPENAPI_EXAMPLE",
    "USER_ID_OPENAPI_SCHEMA",
    "validate_user_id",
    "validate_user_id_display",
    "format_user_id",
    "parse_user_id",
    "user_id_from_database",
    "user_id_to_database",
    "is_user_id",
    "UserIdRequest",
    "UserIdResponse",
]
