"""Provider-specific canonical TON address resolver цикла 1615."""

from __future__ import annotations

from dataclasses import dataclass

from app.lib.ton_address import TonAddressError, parse_ton_address


class TonAddressResolutionError(ValueError):
    """TON provider subject не может быть определён однозначно."""

    code = "auth.ton_address_invalid"
    message = "TON-адрес недействителен"

    def __init__(self, reason: str = "ADDRESS_INVALID") -> None:
        self.reason = reason
        super().__init__(self.message)

    def as_dict(self) -> dict[str, str]:
        """Вернуть безопасный payload без исходного адреса."""

        return {
            "код": self.code,
            "сообщение": self.message,
            "причина": self.reason,
        }


@dataclass(frozen=True, slots=True)
class CanonicalTonAddress:
    """Канонический TON provider subject.

    Результат предназначен для будущего IdentityResolver.
    """

    raw: str
    workchain: int
    account_id_hex: str

    @property
    def provider_subject(self) -> str:
        """Вернуть канонический provider subject."""

        return self.raw

    def __repr__(self) -> str:
        return (
            "CanonicalTonAddress("
            f"workchain={self.workchain!r}, "
            "account_id_hex='<redacted>')"
        )


class CanonicalTonAddressResolver:
    """Преобразовать все допустимые TON формы в один raw subject."""

    def resolve(self, value: object) -> CanonicalTonAddress:
        try:
            parsed = parse_ton_address(value)
        except TonAddressError as exc:
            reason = str(exc) or "ADDRESS_INVALID"
            raise TonAddressResolutionError(reason) from exc
        return CanonicalTonAddress(
            raw=parsed.raw,
            workchain=parsed.workchain,
            account_id_hex=parsed.account_id_hex,
        )


def resolve_canonical_ton_address(value: object) -> CanonicalTonAddress:
    """Функциональная boundary для canonical TON address resolution."""

    return CanonicalTonAddressResolver().resolve(value)


__all__ = [
    "CanonicalTonAddress",
    "CanonicalTonAddressResolver",
    "TonAddressResolutionError",
    "resolve_canonical_ton_address",
]
