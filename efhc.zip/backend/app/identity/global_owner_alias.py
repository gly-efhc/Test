"""Временный глобальный alias-harness миграции ``tg_id -> global_id``.

Канонический runtime принимает только ``global_id``. Старый keyword
``tg_id`` разрешён исключительно декоратором совместимости и немедленно
преобразуется через таблицу identity в ``global_id``. После стабилизации
и полного CI этот модуль удаляется целиком.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from functools import wraps
from typing import Any, Awaitable, Callable, Literal, ParamSpec, TypeVar, cast

from sqlalchemy.ext.asyncio import AsyncSession

from app.identity.financial_read_switch import resolve_financial_read_owner
from app.identity.financial_write_switch import (
    resolve_and_lock_financial_write_owner,
)
from app.identity.nonfinancial_read_switch import (
    resolve_nonfinancial_read_owner,
)

P = ParamSpec("P")
R = TypeVar("R")
AliasMode = Literal["financial_write", "financial_read", "nonfinancial_read"]


class GlobalOwnerAliasError(RuntimeError):
    """Legacy owner alias нельзя однозначно нормализовать."""


@dataclass(frozen=True, slots=True)
class GlobalOwnerAlias:
    """Единый результат временного owner alias-harness."""

    global_id: int
    telegram_provider_id: int | None
    source: Literal["global_id", "legacy_tg_id_alias"]


async def resolve_global_owner_alias(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
    mode: AliasMode = "nonfinancial_read",
) -> GlobalOwnerAlias:
    """Нормализовать canonical id или старый Telegram-owner alias.

    ``tg_id`` здесь является только временным именем входного аргумента.
    Его числовое значение разрешается через identity mapping; оно никогда
    не используется напрямую как business owner.
    """

    if (global_id is None) == (tg_id is None):
        raise GlobalOwnerAliasError(
            "Требуется ровно один owner selector: global_id или legacy tg_id"
        )

    if mode == "financial_write":
        owner = await resolve_and_lock_financial_write_owner(
            db,
            global_id=global_id,
            tg_id=tg_id,
        )
        resolved_global_id = owner.global_id
        provider_id = owner.legacy_tg_id
    elif mode == "financial_read":
        owner = await resolve_financial_read_owner(
            db,
            global_id=global_id,
            tg_id=tg_id,
        )
        resolved_global_id = owner.global_id
        provider_id = owner.legacy_tg_id
    else:
        owner = await resolve_nonfinancial_read_owner(
            db,
            global_id=global_id,
            tg_id=tg_id,
        )
        resolved_global_id = owner.global_id
        provider_id = owner.legacy_tg_id

    return GlobalOwnerAlias(
        global_id=int(resolved_global_id),
        telegram_provider_id=(
            int(provider_id) if provider_id is not None else None
        ),
        source=(
            "global_id" if global_id is not None else "legacy_tg_id_alias"
        ),
    )


def accept_legacy_tg_id_alias(
    *,
    mode: AliasMode,
    provider_parameter: str | None = "telegram_provider_id",
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R]]]:
    """Разрешить старый ``tg_id=`` для canonical global-id функции.

    Декоратор нужен только на период массового rewrite. Каноническая
    функция не содержит ``tg_id`` в signature. Старый keyword извлекается
    до bind, разрешается через БД и заменяется на ``global_id``.
    """

    def decorate(
        function: Callable[P, Awaitable[R]],
    ) -> Callable[P, Awaitable[R]]:
        signature = inspect.signature(function)

        @wraps(function)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            raw_kwargs = cast(dict[str, Any], kwargs)
            legacy_tg_id = raw_kwargs.pop("tg_id", None)
            canonical_global_id = raw_kwargs.get("global_id")
            if legacy_tg_id is None:
                return await function(*args, **kwargs)
            if canonical_global_id is not None:
                raise GlobalOwnerAliasError(
                    "Нельзя одновременно передавать global_id и tg_id alias"
                )

            bound = signature.bind_partial(*args, **raw_kwargs)
            db = bound.arguments.get("db")
            if not isinstance(db, AsyncSession):
                raise GlobalOwnerAliasError(
                    "Legacy alias требует AsyncSession в аргументе db"
                )
            alias = await resolve_global_owner_alias(
                db,
                tg_id=int(legacy_tg_id),
                mode=mode,
            )
            raw_kwargs["global_id"] = alias.global_id
            if (
                provider_parameter
                and provider_parameter in signature.parameters
                and raw_kwargs.get(provider_parameter) is None
            ):
                raw_kwargs[provider_parameter] = alias.telegram_provider_id
            return await function(*args, **raw_kwargs)

        return wrapper

    return decorate


__all__ = [
    "AliasMode",
    "GlobalOwnerAlias",
    "GlobalOwnerAliasError",
    "accept_legacy_tg_id_alias",
    "resolve_global_owner_alias",
]
