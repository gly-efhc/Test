"""Временный глобальный alias-harness миграции ``tg_id -> global_id``.

Канонический runtime принимает только ``global_id`` (или доменное имя
вида ``inviter_global_id``). Старые Telegram-keywords разрешены только
этим модулем и немедленно нормализуются через identity mapping.
После полного exact-head PASS слой удаляется целиком.
"""

from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from functools import wraps
from typing import Any, Literal, ParamSpec, TypeVar, cast

from app.identity.financial_read_switch import (
    resolve_financial_read_owner,
)
from app.identity.financial_write_switch import (
    resolve_and_lock_financial_write_owner,
)
from app.identity.nonfinancial_read_switch import (
    resolve_nonfinancial_read_owner,
)
from sqlalchemy.ext.asyncio import AsyncSession

P = ParamSpec("P")
R = TypeVar("R")
AliasMode = Literal[
    "financial_write",
    "financial_read",
    "nonfinancial_read",
]


class GlobalOwnerAliasError(RuntimeError):
    """Legacy owner alias нельзя однозначно нормализовать."""


@dataclass(frozen=True, slots=True)
class GlobalOwnerAlias:
    """Единый результат временного owner alias-harness."""

    global_id: int
    subject: int | None
    source: Literal["global_id", "legacy_tg_id_alias"]


async def resolve_global_owner_alias(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
    mode: AliasMode = "nonfinancial_read",
) -> GlobalOwnerAlias:
    """Нормализовать canonical id или старый Telegram-owner alias."""

    if (global_id is None) == (tg_id is None):
        raise GlobalOwnerAliasError(
            "Требуется ровно один owner selector: "
            "global_id или legacy tg_id"
        )

    if mode == "financial_write":
        owner = await resolve_and_lock_financial_write_owner(
            db,
            global_id=global_id,
            tg_id=tg_id,
        )
        resolved_global_id = owner.global_id
        provider_id = owner.legacy_tg_id
    elif mode == "financial_read":
        owner = await resolve_financial_read_owner(
            db,
            global_id=global_id,
            tg_id=tg_id,
        )
        resolved_global_id = owner.global_id
        provider_id = owner.legacy_tg_id
    else:
        owner = await resolve_nonfinancial_read_owner(
            db,
            global_id=global_id,
            tg_id=tg_id,
        )
        resolved_global_id = owner.global_id
        provider_id = owner.legacy_tg_id

    return GlobalOwnerAlias(
        global_id=int(resolved_global_id),
        subject=(
            int(provider_id) if provider_id is not None else None
        ),
        source=(
            "global_id"
            if global_id is not None
            else "legacy_tg_id_alias"
        ),
    )


def accept_legacy_owner_alias(
    *,
    mode: AliasMode,
    legacy_parameter: str = "tg_id",
    canonical_parameter: str = "global_id",
    provider_parameter: str | None = "tg_id",
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R]]]:
    """Разрешить один старый Telegram keyword для canonical функции.

    Старый keyword отсутствует в исходной сигнатуре. Wrapper извлекает
    его до bind, разрешает identity и передаёт только canonical owner.
    """

    def decorate(
        function: Callable[P, Awaitable[R]],
    ) -> Callable[P, Awaitable[R]]:
        signature = inspect.signature(function)

        @wraps(function)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            raw_kwargs = cast(dict[str, Any], kwargs)
            legacy_value = raw_kwargs.pop(legacy_parameter, None)
            canonical_value = raw_kwargs.get(canonical_parameter)
            if legacy_value is None:
                return await function(*args, **kwargs)
            if canonical_value is not None:
                raise GlobalOwnerAliasError(
                    "Нельзя одновременно передавать "
                    f"{canonical_parameter} "
                    f"и {legacy_parameter} alias"
                )

            bound = signature.bind_partial(*args, **raw_kwargs)
            db = bound.arguments.get("db")
            if db is None or not hasattr(db, "execute"):
                raise GlobalOwnerAliasError(
                    "Legacy owner alias требует DB session "
                    "в аргументе db"
                )
            alias = await resolve_global_owner_alias(
                cast(AsyncSession, db),
                tg_id=int(legacy_value),
                mode=mode,
            )
            raw_kwargs[canonical_parameter] = alias.global_id
            if (
                provider_parameter
                and provider_parameter in signature.parameters
                and raw_kwargs.get(provider_parameter) is None
            ):
                raw_kwargs[provider_parameter] = (
                    alias.subject
                )
            return await function(*args, **raw_kwargs)

        return wrapper

    return decorate




__all__ = [
    "AliasMode",
    "GlobalOwnerAlias",
    "GlobalOwnerAliasError",
    "accept_legacy_owner_alias",
    "resolve_global_owner_alias",
]
