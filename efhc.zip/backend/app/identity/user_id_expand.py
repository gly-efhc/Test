"""PostgreSQL expand contract for ``users.user_id``.

The current EXPAND stage introduces only a nullable physical
system-ID column,
an independent sequence, a range check and uniqueness. Existing rows
remain untouched. Domain ownership continues to use the legacy fields
until the dedicated backfill and read-switch cycles.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

USER_ID_SCHEMA: Final[str] = "efhc_core"
USER_ID_TABLE: Final[str] = "users"
USER_ID_COLUMN: Final[str] = "user_id"
USER_ID_SEQUENCE: Final[str] = "users_user_id_seq"
USER_ID_UNIQUE: Final[str] = "uq_users_user_id"
USER_ID_CHECK: Final[str] = "ck_users_user_id_range"
USER_ID_MIN: Final[int] = 1
USER_ID_MAX: Final[int] = 9_999_999_999


@dataclass(frozen=True, slots=True)
class UserIdExpandPlan:
    """Machine-readable expand contract."""

    cycle: int
    source_head: str
    target_head: str
    schema: str
    table: str
    column: str
    sequence: str
    nullable: bool
    backfill_performed: bool
    runtime_read_switch: bool
    ton_wallet_login_enabled: bool


def build_user_id_expand_plan() -> UserIdExpandPlan:
    """Return the exact current EXPAND migration boundary."""

    return UserIdExpandPlan(
        cycle=1597,
        source_head="EFHC_Bot_v171_93.zip",
        target_head="EFHC_Bot_v171_94.zip",
        schema=USER_ID_SCHEMA,
        table=USER_ID_TABLE,
        column=USER_ID_COLUMN,
        sequence=USER_ID_SEQUENCE,
        nullable=True,
        backfill_performed=False,
        runtime_read_switch=False,
        ton_wallet_login_enabled=False,
    )


def postgres_existing_schema_expand_sql() -> tuple[str, ...]:
    """Return idempotent PostgreSQL DDL for an existing ``0001`` DB.

    The statements deliberately contain no row backfill. The sequence
    starts above every legacy ``users.id`` and any already assigned
    ``users.user_id`` value, so new rows cannot collide with the later
    deterministic backfill of historical rows.
    """

    return (
        """
ALTER TABLE efhc_core.users
ADD COLUMN IF NOT EXISTS user_id BIGINT NULL
""".strip(),
        """
DO $efhc_user_id_expand$
DECLARE
    desired_next BIGINT;
BEGIN
    SELECT GREATEST(
        COALESCE(MAX(id), 0),
        COALESCE(MAX(user_id), 0)
    ) + 1
    INTO desired_next
    FROM efhc_core.users;

    IF desired_next > 9999999999 THEN
        RAISE EXCEPTION
            'users.user_id sequence exhausted: %', desired_next;
    END IF;

    IF to_regclass(
        'efhc_core.users_user_id_seq'
    ) IS NULL THEN
        EXECUTE format(
            'CREATE SEQUENCE '
            'efhc_core.users_user_id_seq AS BIGINT '
            'MINVALUE 1 MAXVALUE 9999999999 '
            'START WITH %s NO CYCLE',
            desired_next
        );
    END IF;
END
$efhc_user_id_expand$
""".strip(),
        """
ALTER SEQUENCE efhc_core.users_user_id_seq
AS BIGINT
MINVALUE 1
MAXVALUE 9999999999
NO CYCLE
""".strip(),
        """
DO $efhc_user_id_sequence_sync$
DECLARE
    desired_next BIGINT;
    current_value BIGINT;
BEGIN
    SELECT GREATEST(
        COALESCE(MAX(id), 0),
        COALESCE(MAX(user_id), 0)
    ) + 1
    INTO desired_next
    FROM efhc_core.users;

    SELECT last_value
    INTO current_value
    FROM efhc_core.users_user_id_seq;

    IF desired_next > 9999999999 THEN
        RAISE EXCEPTION
            'users.user_id sequence exhausted: %', desired_next;
    END IF;

    IF current_value < desired_next THEN
        PERFORM setval(
            'efhc_core.users_user_id_seq',
            desired_next,
            false
        );
    END IF;
END
$efhc_user_id_sequence_sync$
""".strip(),
        """
ALTER SEQUENCE efhc_core.users_user_id_seq
OWNED BY efhc_core.users.user_id
""".strip(),
        """
ALTER TABLE efhc_core.users
ALTER COLUMN user_id SET DEFAULT
nextval('efhc_core.users_user_id_seq'::regclass)
""".strip(),
        """
DO $efhc_user_id_range_guard$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM efhc_core.users
        WHERE user_id IS NOT NULL
          AND (
              user_id < 1
              OR user_id > 9999999999
          )
    ) THEN
        RAISE EXCEPTION
            'users.user_id contains out-of-range values';
    END IF;
END
$efhc_user_id_range_guard$
""".strip(),
        """
DO $efhc_user_id_duplicate_guard$
BEGIN
    IF EXISTS (
        SELECT user_id
        FROM efhc_core.users
        WHERE user_id IS NOT NULL
        GROUP BY user_id
        HAVING COUNT(*) > 1
    ) THEN
        RAISE EXCEPTION
            'users.user_id contains duplicate values';
    END IF;
END
$efhc_user_id_duplicate_guard$
""".strip(),
        """
DO $efhc_user_id_check_constraint$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conrelid = 'efhc_core.users'::regclass
          AND conname = 'ck_users_user_id_range'
    ) THEN
        ALTER TABLE efhc_core.users
        ADD CONSTRAINT ck_users_user_id_range
        CHECK (
            user_id IS NULL
            OR user_id BETWEEN 1 AND 9999999999
        ) NOT VALID;
    END IF;
END
$efhc_user_id_check_constraint$
""".strip(),
        """
ALTER TABLE efhc_core.users
VALIDATE CONSTRAINT ck_users_user_id_range
""".strip(),
        """
DO $efhc_user_id_unique_constraint$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conrelid = 'efhc_core.users'::regclass
          AND conname = 'uq_users_user_id'
    ) THEN
        ALTER TABLE efhc_core.users
        ADD CONSTRAINT uq_users_user_id
        UNIQUE (user_id);
    END IF;
END
$efhc_user_id_unique_constraint$
""".strip(),
    )


def render_postgres_existing_schema_expand_sql() -> str:
    """Render focused PostgreSQL DDL with transaction markers."""

    body = ";\n\n".join(postgres_existing_schema_expand_sql())
    return "BEGIN;\n\n" + body + ";\n\nCOMMIT;\n"


__all__ = [
    "USER_ID_CHECK",
    "USER_ID_COLUMN",
    "USER_ID_MAX",
    "USER_ID_MIN",
    "USER_ID_SCHEMA",
    "USER_ID_SEQUENCE",
    "USER_ID_TABLE",
    "USER_ID_UNIQUE",
    "UserIdExpandPlan",
    "build_user_id_expand_plan",
    "postgres_existing_schema_expand_sql",
    "render_postgres_existing_schema_expand_sql",
]
