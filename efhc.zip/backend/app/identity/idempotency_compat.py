"""Совместимый выбор idempotency key на этапе global_id cutover."""

from __future__ import annotations

from dataclasses import dataclass

from app.identity.financial_read_switch import _load_control
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


@dataclass(frozen=True, slots=True)
class CompatibleIdempotencyKey:
    """Выбранный ключ и причина его выбора."""

    selected: str
    canonical: str
    legacy: str | None
    matched_existing: bool


async def choose_compatible_idempotency_key(
    db: AsyncSession,
    *,
    canonical_key: str,
    legacy_key: str | None = None,
) -> CompatibleIdempotencyKey:
    """Найти исторический ключ или выбрать ключ текущего режима.

    Сначала выполняется read-through обоих допустимых ключей. Если
    операция уже существует, повтор использует именно найденный ключ.
    Для новой операции до cutover сохраняется legacy key, а после
    переключения ``legacy_authoritative=FALSE`` используется canonical
    key на основе ``global_id``.
    """

    canonical = str(canonical_key).strip()
    legacy = str(legacy_key).strip() if legacy_key else None
    if not canonical:
        raise ValueError("canonical idempotency key пуст")
    if legacy == canonical:
        legacy = None

    row = (
        await db.execute(
            text(
                """
                SELECT idempotency_key
                FROM efhc_core.efhc_transfers_log
                WHERE idempotency_key = :canonical_key
                   OR (
                       :legacy_key IS NOT NULL
                       AND idempotency_key = :legacy_key
                   )
                ORDER BY
                    CASE
                        WHEN idempotency_key = :canonical_key THEN 0
                        ELSE 1
                    END
                LIMIT 1
                """
            ),
            {
                "canonical_key": canonical,
                "legacy_key": legacy,
            },
        )
    ).first()
    if row is not None:
        selected = str(row.idempotency_key)
        return CompatibleIdempotencyKey(
            selected=selected,
            canonical=canonical,
            legacy=legacy,
            matched_existing=True,
        )

    control = await _load_control(db)
    selected = (
        legacy
        if control.legacy_authoritative and legacy is not None
        else canonical
    )
    return CompatibleIdempotencyKey(
        selected=selected,
        canonical=canonical,
        legacy=legacy,
        matched_existing=False,
    )


__all__ = [
    "CompatibleIdempotencyKey",
    "choose_compatible_idempotency_key",
]
