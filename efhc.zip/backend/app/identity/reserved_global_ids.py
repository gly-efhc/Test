"""Зарезервированные account identifiers EFHC.

Эти значения валидны по формату ``global_id``, но не выдаются обычной
регистрацией. Они назначаются только явно утверждённым system/account roles.
"""

from __future__ import annotations

from typing import Final

SUPERADMIN_GLOBAL_ID_TEXT: Final[str] = "1313131313"
SUPERADMIN_GLOBAL_ID_DB: Final[int] = 1_313_131_313
RESERVED_GLOBAL_ID_DB_VALUES: Final[frozenset[int]] = frozenset(
    {SUPERADMIN_GLOBAL_ID_DB}
)


def is_reserved_global_id_db(value: int) -> bool:
    """Вернуть True, если DB-значение зарезервировано каноном."""

    return int(value) in RESERVED_GLOBAL_ID_DB_VALUES


__all__ = [
    "RESERVED_GLOBAL_ID_DB_VALUES",
    "SUPERADMIN_GLOBAL_ID_DB",
    "SUPERADMIN_GLOBAL_ID_TEXT",
    "is_reserved_global_id_db",
]
