"""Разделить canonical account owner и Telegram delivery channel."""

from __future__ import annotations

from dataclasses import dataclass

from app.identity.provider_registry import AuthProvider
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


class NotificationChannelError(RuntimeError):
    """Channel нельзя безопасно разрешить из canonical owner."""


@dataclass(frozen=True, slots=True)
class TelegramNotificationChannel:
    """Telegram delivery target, разрешённый из ``global_id``."""

    global_id: int
    tg_id: int
    source: str


def _positive_tg_id(value: str | int | None) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    text_value = str(value).strip()
    if not text_value.isascii() or not text_value.isdecimal():
        return None
    result = int(text_value)
    return result if result > 0 else None


async def resolve_telegram_notification_channel(
    db: AsyncSession,
    *,
    global_id: int,
    provider_tg_id: int | None = None,
) -> TelegramNotificationChannel | None:
    """Разрешить Telegram как channel, не используя его как owner.

    Проверенная активная Telegram identity имеет приоритет.
    Legacy ``users.tg_id`` допускается только как compatibility fallback
    для того же ``global_id``. Несколько разных Telegram identities или
    любой конфликт завершаются fail closed.
    """

    gid = int(global_id)
    if gid < 1 or gid > 9_999_999_999:
        raise NotificationChannelError("global_id вне диапазона")

    rows = (
        await db.execute(
            text(
                """
                SELECT provider_subject, is_primary
                  FROM efhc_core.user_identities
                 WHERE global_id = :global_id
                   AND provider = :provider
                   AND status = 'active'
                   AND is_verified = TRUE
                 ORDER BY is_primary DESC, id ASC
                """
            ),
            {
                "global_id": gid,
                "provider": AuthProvider.TELEGRAM.value,
            },
        )
    ).all()

    identity_ids = {
        parsed
        for row in rows
        if (parsed := _positive_tg_id(row.provider_subject))
        is not None
    }
    if len(identity_ids) > 1:
        raise NotificationChannelError(
            "Несколько Telegram channels для одного global_id"
        )
    identity_tg = next(iter(identity_ids), None)

    compatibility_tg = _positive_tg_id(provider_tg_id)
    if compatibility_tg is not None:
        mapped = (
            await db.execute(
                text(
                    """
                    SELECT global_id
                      FROM efhc_core.users
                     WHERE tg_id = :tg_id
                     LIMIT 1
                    """
                ),
                {"tg_id": compatibility_tg},
            )
        ).scalar_one_or_none()
        if mapped is None or int(mapped) != gid:
            raise NotificationChannelError(
                "Legacy Telegram channel конфликтует с global owner"
            )

    if (
        identity_tg is not None
        and compatibility_tg is not None
        and identity_tg != compatibility_tg
    ):
        raise NotificationChannelError(
            "Verified Telegram identity конфликтует с legacy channel"
        )

    if identity_tg is not None:
        return TelegramNotificationChannel(
            global_id=gid,
            tg_id=identity_tg,
            source="verified_identity",
        )
    if compatibility_tg is not None:
        return TelegramNotificationChannel(
            global_id=gid,
            tg_id=compatibility_tg,
            source="legacy_compatibility",
        )
    return None


__all__ = [
    "NotificationChannelError",
    "TelegramNotificationChannel",
    "resolve_telegram_notification_channel",
]
