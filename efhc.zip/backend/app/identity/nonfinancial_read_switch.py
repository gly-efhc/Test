"""Owner boundary для non-financial read switch цикла 1625."""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

GLOBAL_ID_MIN = 1
GLOBAL_ID_MAX = 9_999_999_999


class NonFinancialReadOwnerError(RuntimeError):
    """Read-owner нельзя разрешить без безопасного account mapping."""


@dataclass(frozen=True, slots=True)
class NonFinancialReadOwner:
    """Разрешённый account owner и контролируемый legacy fallback."""

    global_id: int
    legacy_tg_id: int | None
    use_global_id: bool
    rollback_ready: bool

    @property
    def legacy_telegram_provider_id(self) -> int | None:
        """Временное точное имя provider-атрибута."""

        return self.legacy_tg_id

    def require_legacy_tg_id(self) -> int:
        """Вернуть legacy Telegram id только для compatibility seam."""

        if self.legacy_tg_id is None:
            raise NonFinancialReadOwnerError(
                "Для legacy compatibility отсутствует TelegramId"
            )
        return int(self.legacy_tg_id)


def _validate_global_id(value: int) -> int:
    global_id = int(value)
    if global_id < GLOBAL_ID_MIN or global_id > GLOBAL_ID_MAX:
        raise NonFinancialReadOwnerError("global_id вне диапазона")
    return global_id


async def resolve_nonfinancial_read_owner(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
) -> NonFinancialReadOwner:
    """Разрешить owner через account row и DB control цикла 1625.

    Bearer/session callers передают ``global_id``. Legacy Telegram seam
    может передать ``tg_id``. Он используется только как ingress
    mapping; global-read затем выполняется по ``users.global_id``
    и shadow owner.
    """

    if (global_id is None) == (tg_id is None):
        raise NonFinancialReadOwnerError(
            "Требуется ровно один identity selector"
        )

    control = (
        await db.execute(
            text(
                """
                SELECT
                    nonfinancial_read_global_id_enabled,
                    nonfinancial_read_rollback_ready,
                    shadow_read_enabled,
                    legacy_authoritative
                FROM efhc_core.identity_migration_control
                WHERE singleton_id = 1
                """
            )
        )
    ).first()
    if control is None:
        raise NonFinancialReadOwnerError(
            "Identity migration control отсутствует"
        )
    if bool(control.nonfinancial_read_global_id_enabled):
        ready = bool(control.shadow_read_enabled)
    else:
        ready = bool(control.legacy_authoritative)
    if not ready:
        raise NonFinancialReadOwnerError(
            "Identity migration control не готов"
        )

    if global_id is not None:
        gid = _validate_global_id(global_id)
        user = (
            await db.execute(
                text(
                    """
                    SELECT global_id, tg_id
                    FROM efhc_core.users
                    WHERE global_id = :global_id
                    LIMIT 1
                    """
                ),
                {"global_id": gid},
            )
        ).first()
    else:
        legacy_tg = int(tg_id or 0)
        if legacy_tg <= 0:
            raise NonFinancialReadOwnerError("TelegramId недопустим")
        user = (
            await db.execute(
                text(
                    """
                    SELECT global_id, tg_id
                    FROM efhc_core.users
                    WHERE tg_id = :tg_id
                    LIMIT 1
                    """
                ),
                {"tg_id": legacy_tg},
            )
        ).first()

    if user is None or user.global_id is None:
        raise NonFinancialReadOwnerError(
            "Account owner mapping не найден"
        )

    gid = _validate_global_id(int(user.global_id))
    legacy_value = (
        int(user.tg_id) if user.tg_id is not None else None
    )
    return NonFinancialReadOwner(
        global_id=gid,
        legacy_tg_id=legacy_value,
        use_global_id=bool(control.nonfinancial_read_global_id_enabled),
        rollback_ready=bool(control.nonfinancial_read_rollback_ready),
    )


__all__ = [
    "NonFinancialReadOwner",
    "NonFinancialReadOwnerError",
    "resolve_nonfinancial_read_owner",
]
