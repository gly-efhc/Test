"""Операторский сервис подготовки, переключения и rollback global_id.

Сервис не подключён к публичному API и не запускается автоматически.
Изменения control row выполняются в одной транзакции с FOR UPDATE.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

ZERO = Decimal("0")


class GlobalIdCutoverError(RuntimeError):
    """Cutover запрещён без нулевого preflight."""


@dataclass(frozen=True, slots=True)
class GlobalIdCutoverPreflight:
    dual_write_enabled: bool
    shadow_read_enabled: bool
    legacy_authoritative: bool
    nonfinancial_read_global_id_enabled: bool
    financial_read_global_id_enabled: bool
    nonfinancial_read_rollback_ready: bool
    financial_read_rollback_ready: bool
    fallback_rows: int
    mismatch_rows: int
    orphan_rows: int
    ambiguous_rows: int
    users_without_global_id: int
    monetary_discrepancy: Decimal

    @property
    def ready(self) -> bool:
        return bool(
            self.dual_write_enabled
            and self.shadow_read_enabled
            and self.nonfinancial_read_global_id_enabled
            and self.financial_read_global_id_enabled
            and self.nonfinancial_read_rollback_ready
            and self.financial_read_rollback_ready
            and self.fallback_rows == 0
            and self.mismatch_rows == 0
            and self.orphan_rows == 0
            and self.ambiguous_rows == 0
            and self.users_without_global_id == 0
            and self.monetary_discrepancy == ZERO
        )


_MONEY_QUERIES: tuple[tuple[str, str], ...] = (
    (
        "efhc_transfers_log.amount",
        """
        SELECT
            COALESCE(sum(t.amount) FILTER (
                WHERE t.tg_id IS NOT NULL AND u.global_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount) FILTER (
                WHERE t.tg_id IS NOT NULL
                  AND t.global_id = u.global_id
            ), 0)
        FROM efhc_core.efhc_transfers_log t
        LEFT JOIN efhc_core.users u ON u.tg_id = t.tg_id
        """,
    ),
    (
        "payment_intents.amount_asset_d8",
        """
        SELECT
            COALESCE(sum(t.amount_asset_d8) FILTER (
                WHERE t.tg_id IS NOT NULL AND u.global_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount_asset_d8) FILTER (
                WHERE t.tg_id IS NOT NULL
                  AND t.global_id = u.global_id
            ), 0)
        FROM efhc_core.payment_intents t
        LEFT JOIN efhc_core.users u ON u.tg_id = t.tg_id
        """,
    ),
    (
        "withdraw_requests.amount",
        """
        SELECT
            COALESCE(sum(t.amount) FILTER (
                WHERE t.tg_id IS NOT NULL AND u.global_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount) FILTER (
                WHERE t.tg_id IS NOT NULL
                  AND t.global_id = u.global_id
            ), 0)
        FROM efhc_core.withdraw_requests t
        LEFT JOIN efhc_core.users u ON u.tg_id = t.tg_id
        """,
    ),
)


async def inspect_global_id_cutover(
    db: AsyncSession,
    *,
    lock: bool = False,
) -> GlobalIdCutoverPreflight:
    lock_sql = " FOR UPDATE" if lock else ""
    control = (
        await db.execute(
            text(
                """
                SELECT
                    dual_write_enabled,
                    shadow_read_enabled,
                    legacy_authoritative,
                    nonfinancial_read_global_id_enabled,
                    financial_read_global_id_enabled,
                    nonfinancial_read_rollback_ready,
                    financial_read_rollback_ready
                FROM efhc_core.identity_migration_control
                WHERE singleton_id = 1
                """
                + lock_sql
            )
        )
    ).first()
    if control is None:
        raise GlobalIdCutoverError(
            "identity migration control отсутствует"
        )

    telemetry = (
        await db.execute(
            text(
                """
                SELECT
                    COALESCE(sum(fallback_rows), 0) AS fallback_rows,
                    COALESCE(sum(mismatch_rows), 0) AS mismatch_rows,
                    COALESCE(sum(orphan_rows), 0) AS orphan_rows,
                    COALESCE(sum(ambiguous_rows), 0) AS ambiguous_rows
                FROM efhc_core.identity_ownership_shadow_telemetry
                """
            )
        )
    ).first()
    if telemetry is None:
        raise GlobalIdCutoverError("identity telemetry отсутствует")

    users_without_global_id = int(
        (
            await db.execute(
                text(
                    "SELECT COUNT(*) FROM efhc_core.users "
                    "WHERE global_id IS NULL"
                )
            )
        ).scalar_one()
        or 0
    )

    discrepancy = ZERO
    for _label, query in _MONEY_QUERIES:
        row = (await db.execute(text(query))).first()
        if row is None:
            raise GlobalIdCutoverError("денежный snapshot отсутствует")
        discrepancy += abs(Decimal(row[0]) - Decimal(row[1]))

    return GlobalIdCutoverPreflight(
        dual_write_enabled=bool(control.dual_write_enabled),
        shadow_read_enabled=bool(control.shadow_read_enabled),
        legacy_authoritative=bool(control.legacy_authoritative),
        nonfinancial_read_global_id_enabled=bool(
            control.nonfinancial_read_global_id_enabled
        ),
        financial_read_global_id_enabled=bool(
            control.financial_read_global_id_enabled
        ),
        nonfinancial_read_rollback_ready=bool(
            control.nonfinancial_read_rollback_ready
        ),
        financial_read_rollback_ready=bool(
            control.financial_read_rollback_ready
        ),
        fallback_rows=int(telemetry.fallback_rows or 0),
        mismatch_rows=int(telemetry.mismatch_rows or 0),
        orphan_rows=int(telemetry.orphan_rows or 0),
        ambiguous_rows=int(telemetry.ambiguous_rows or 0),
        users_without_global_id=users_without_global_id,
        monetary_discrepancy=discrepancy,
    )


async def execute_global_id_cutover(
    db: AsyncSession,
) -> GlobalIdCutoverPreflight:
    """Отключить legacy-authoritative после нулевого preflight."""

    async with db.begin():
        preflight = await inspect_global_id_cutover(db, lock=True)
        if not preflight.ready:
            raise GlobalIdCutoverError(
                "global_id cutover preflight не готов: "
                f"fallback={preflight.fallback_rows}, "
                f"mismatch={preflight.mismatch_rows}, "
                f"orphan={preflight.orphan_rows}, "
                f"ambiguous={preflight.ambiguous_rows}, "
                f"money={preflight.monetary_discrepancy}"
            )
        await db.execute(
            text(
                """
                UPDATE efhc_core.identity_migration_control
                   SET legacy_authoritative = FALSE,
                       updated_at = now()
                 WHERE singleton_id = 1
                """
            )
        )
    return preflight


async def rollback_global_id_cutover(db: AsyncSession) -> None:
    """Одним транзакционным действием вернуть legacy read authority."""

    async with db.begin():
        control = (
            await db.execute(
                text(
                    """
                    SELECT
                        nonfinancial_read_rollback_ready,
                        financial_read_rollback_ready
                    FROM efhc_core.identity_migration_control
                    WHERE singleton_id = 1
                    FOR UPDATE
                    """
                )
            )
        ).first()
        if control is None:
            raise GlobalIdCutoverError(
                "identity migration control отсутствует"
            )
        if not (
            bool(control.nonfinancial_read_rollback_ready)
            and bool(control.financial_read_rollback_ready)
        ):
            raise GlobalIdCutoverError(
                "rollback readiness не подтверждена"
            )
        await db.execute(
            text(
                """
                UPDATE efhc_core.identity_migration_control
                   SET financial_read_global_id_enabled = FALSE,
                       nonfinancial_read_global_id_enabled = FALSE,
                       legacy_authoritative = TRUE,
                       updated_at = now()
                 WHERE singleton_id = 1
                """
            )
        )


__all__ = [
    "GlobalIdCutoverError",
    "GlobalIdCutoverPreflight",
    "execute_global_id_cutover",
    "inspect_global_id_cutover",
    "rollback_global_id_cutover",
]
