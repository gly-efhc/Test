"""Переходный контракт ORM aliases для канона ``global_id``.

После цикла 1631 физическая owner-колонка называется ``global_id``.
Legacy ORM-имя ``User.user_id`` сохранено только как временный reverse
compatibility alias до schema squash и финальной qualification.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class GlobalIdAliasPlan:
    """Машиночитаемый жизненный цикл переходных aliases."""

    cycle_created: int
    physical_column: str
    canonical_alias: str
    canonical_target: str
    local_pk_alias: str
    local_pk_target: str
    telegram_alias: str
    telegram_target: str
    physical_rename_cycle: int
    compatibility_removal_cycle: int
    runtime_read_switch: bool
    database_schema_changed: bool


GLOBAL_ID_ALIAS_PLAN: Final[GlobalIdAliasPlan] = GlobalIdAliasPlan(
    cycle_created=1631,
    physical_column="users.global_id",
    canonical_alias="User.user_id",
    canonical_target="User.global_id",
    local_pk_alias="User.legacy_pk",
    local_pk_target="User.id",
    telegram_alias="User.telegram_id",
    telegram_target="User.global_id",
    physical_rename_cycle=1631,
    compatibility_removal_cycle=1632,
    runtime_read_switch=True,
    database_schema_changed=True,
)


def build_global_id_alias_plan() -> GlobalIdAliasPlan:
    """Вернуть текущий reverse compatibility contract цикла 1631."""

    return GLOBAL_ID_ALIAS_PLAN


# LEGACY экспорт для старых тестов и инструментов цикла 1598.
@dataclass(frozen=True, slots=True)
class LegacyUserIdAliasPlan:
    """Историческое представление старого compatibility contract."""

    cycle_created: int
    activation_cycle: int
    removal_cycle: int
    active_alias: str
    active_target: str
    future_alias: str
    future_target: str
    runtime_read_switch: bool
    allowed_scopes: tuple[str, ...]


USER_ID_LEGACY_ALIAS_PLAN: Final[LegacyUserIdAliasPlan] = (
    LegacyUserIdAliasPlan(
        cycle_created=1598,
        activation_cycle=1602,
        removal_cycle=1631,
        active_alias="User.legacy_runtime_id",
        active_target="User.id",
        future_alias="User.global_id",
        future_target="User.user_id",
        runtime_read_switch=False,
        allowed_scopes=(
            "migration_harness",
            "reconciliation",
            "legacy_compatibility_tests",
        ),
    )
)


def build_legacy_user_id_alias_plan() -> LegacyUserIdAliasPlan:
    """Вернуть исторический compatibility view для старых callers."""

    return USER_ID_LEGACY_ALIAS_PLAN


__all__ = [
    "GLOBAL_ID_ALIAS_PLAN",
    "GlobalIdAliasPlan",
    "build_global_id_alias_plan",
    "LegacyUserIdAliasPlan",
    "USER_ID_LEGACY_ALIAS_PLAN",
    "build_legacy_user_id_alias_plan",
]
