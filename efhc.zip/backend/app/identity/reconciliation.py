"""Оценка Global ID PostgreSQL reconciliation baseline.

Модуль не подключается к БД и не меняет данные. Он оценивает снимок,
снятый реальным PostgreSQL gate. Каноническое имя — ``global_id``;
физическая EXPAND-колонка на текущем этапе остаётся ``users.global_id``.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Any, Final

ДОПУСК_ДЕНЕЖНЫХ_РАСХОЖДЕНИЙ: Final[Decimal] = Decimal("0.00000000")


class ReconciliationStatus(StrEnum):
    """Допустимые результаты шлюза сверки."""

    ГОТОВО = "ГОТОВО"
    ОТКЛОНЕНО = "ОТКЛОНЕНО"
    БЛОКИРОВАНО_СРЕДОЙ = "БЛОКИРОВАНО_СРЕДОЙ"


@dataclass(frozen=True, slots=True)
class ReconciliationVerdict:
    """Машинно-проверяемый результат сверки."""

    status: ReconciliationStatus
    historical_backfill_allowed: bool
    violations: tuple[str, ...]
    warnings: tuple[str, ...]


def _value(metrics: Mapping[str, Any], key: str, *legacy: str) -> Any:
    if key in metrics:
        return metrics[key]
    for alias in legacy:
        if alias in metrics:
            return metrics[alias]
    return None


def _integer(
    metrics: Mapping[str, Any],
    key: str,
    *legacy: str,
) -> int:
    value = _value(metrics, key, *legacy)
    if isinstance(value, bool):
        raise ValueError(f"Метрика «{key}» не может быть bool")
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"Метрика «{key}» должна быть целым числом"
        ) from exc


def _decimal(metrics: Mapping[str, Any], key: str) -> Decimal:
    value = metrics.get(key)
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(
            f"Метрика «{key}» должна быть совместимой с Decimal"
        ) from exc


def _dict(
    metrics: Mapping[str, Any],
    key: str,
    *legacy: str,
) -> Mapping[str, Any]:
    value = _value(metrics, key, *legacy)
    if not isinstance(value, Mapping):
        raise ValueError(f"Метрика «{key}» должна быть объектом")
    return value


def evaluate_reconciliation(
    metrics: Mapping[str, Any],
) -> ReconciliationVerdict:
    """Проверить PostgreSQL-снимок до historical backfill."""

    violations: list[str] = []
    warnings: list[str] = []

    users_count = _integer(metrics, "количество_пользователей")
    unique_tg = _integer(metrics, "уникальные_global_id")
    null_global_ids = _integer(
        metrics,
        "global_id_null",
        "user_id_null",
    )
    populated_global_ids = _integer(
        metrics,
        "global_id_заполнен",
        "user_id_заполнен",
    )

    if users_count < 0:
        violations.append("Количество пользователей отрицательное")
    if unique_tg != users_count:
        violations.append(
            "Количество уникальных global_id не равно числу пользователей"
        )
    if null_global_ids + populated_global_ids != users_count:
        violations.append(
            "NULL и заполненные значения physical users.global_id "
            "не покрывают users"
        )

    zero_metrics = (
        (
            "дубликаты_global_id",
            (),
            "Обнаружены дубликаты global_id",
        ),
        (
            "дубликаты_global_id",
            ("дубликаты_user_id",),
            "Обнаружены дубликаты global_id",
        ),
        (
            "global_id_вне_диапазона",
            ("user_id_вне_диапазона",),
            "Обнаружены global_id вне диапазона 1–9999999999",
        ),
        (
            "legacy_pk_вне_диапазона",
            ("legacy_id_вне_диапазона",),
            "Обнаружены users.id вне диапазона будущего global_id",
        ),
        (
            "планируемые_коллизии_global_id",
            ("планируемые_коллизии_user_id",),
            "Обнаружены коллизии historical backfill global_id",
        ),
        (
            "дубликаты_кошельков",
            (),
            "Один адрес кошелька связан более одного раза",
        ),
        (
            "дубликаты_idempotency",
            (),
            "Обнаружены дубликаты ключей идемпотентности",
        ),
        (
            "дубликаты_tx_hash",
            (),
            "Обнаружены дубликаты хешей транзакций",
        ),
        (
            "нарушения_зеркала_kwh",
            (),
            "Нарушено равенство available_kwh = "
            "total_generated_kwh - exchanged_kwh_total",
        ),
    )
    for key, legacy, message in zero_metrics:
        if _integer(metrics, key, *legacy) != 0:
            violations.append(message)

    orphan_rows = _dict(
        metrics,
        "orphan_записи_legacy_telegram_provider_id",
        "orphan_записи",
    )
    for owner, raw_count in sorted(orphan_rows.items()):
        try:
            count = int(raw_count)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Метрика сиротских записей «{owner}» должна быть целой"
            ) from exc
        if count != 0:
            violations.append(
                f"Обнаружены сиротские записи: {owner}={count}"
            )

    financial_difference = _decimal(
        metrics,
        "расхождение_финансового_зеркала",
    )
    if financial_difference.copy_abs() > ДОПУСК_ДЕНЕЖНЫХ_РАСХОЖДЕНИЙ:
        violations.append("Финансовое расхождение превышает 0.00000000")

    sequence_next = _integer(
        metrics,
        "следующий_global_id_sequence",
        "следующий_user_id_sequence",
    )
    maximum_known = max(
        _integer(
            metrics,
            "максимальный_legacy_pk",
            "максимальный_legacy_id",
        ),
        _integer(
            metrics,
            "максимальный_global_id",
            "максимальный_user_id",
        ),
    )
    if sequence_next <= maximum_known:
        violations.append(
            "Последовательность users_global_id_seq пересекается "
            "с известными global_id или legacy PK"
        )
    if sequence_next > 9_999_999_999:
        violations.append(
            "Последовательность исчерпала диапазон GlobalId"
        )

    if null_global_ids:
        warnings.append(
            "Historical backfill потребуется для "
            f"{null_global_ids} строк physical users.global_id"
        )
    else:
        warnings.append("NULL physical users.global_id отсутствуют")

    if violations:
        return ReconciliationVerdict(
            status=ReconciliationStatus.ОТКЛОНЕНО,
            historical_backfill_allowed=False,
            violations=tuple(violations),
            warnings=tuple(warnings),
        )
    return ReconciliationVerdict(
        status=ReconciliationStatus.ГОТОВО,
        historical_backfill_allowed=True,
        violations=(),
        warnings=tuple(warnings),
    )


def compare_financial_snapshots(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
) -> tuple[str, ...]:
    """Сравнить финансовые метрики без округления."""

    keys = (
        "сумма_main_balance",
        "сумма_bonus_balance",
        "сумма_available_kwh",
        "сумма_total_generated_kwh",
        "сумма_exchanged_kwh_total",
        "сумма_bank_balance",
        "количество_панелей",
        "сумма_generated_kwh_панелей",
        "количество_транзакций",
        "сумма_транзакций",
        "количество_выводов",
        "сумма_выводов",
        "количество_реферальных_связей",
        "сумма_реферальных_наград",
    )
    differences: list[str] = []
    for key in keys:
        if key.startswith("сумма_"):
            delta = _decimal(after, key) - _decimal(before, key)
            if delta.copy_abs() > ДОПУСК_ДЕНЕЖНЫХ_РАСХОЖДЕНИЙ:
                differences.append(f"{key}: изменение {delta}")
            continue
        if _integer(before, key) != _integer(after, key):
            differences.append(
                f"{key}: {before.get(key)} → {after.get(key)}"
            )
    return tuple(differences)


__all__ = [
    "ДОПУСК_ДЕНЕЖНЫХ_РАСХОЖДЕНИЙ",
    "ReconciliationStatus",
    "ReconciliationVerdict",
    "compare_financial_snapshots",
    "evaluate_reconciliation",
]
