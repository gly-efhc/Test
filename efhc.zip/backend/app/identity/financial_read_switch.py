"""Owner boundary для financial read switch цикла 1627."""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

GLOBAL_ID_MIN = 1
GLOBAL_ID_MAX = 9_999_999_999


class FinancialReadOwnerError(RuntimeError):
    """Financial owner нельзя разрешить без безопасного mapping."""


@dataclass(frozen=True, slots=True)
class FinancialMigrationControl:
    """Общие singleton-флаги границ финансового чтения и записи."""

    financial_read_global_id_enabled: bool
    financial_read_rollback_ready: bool
    nonfinancial_read_global_id_enabled: bool
    dual_write_enabled: bool
    shadow_read_enabled: bool
    legacy_authoritative: bool


@dataclass(frozen=True, slots=True)
class FinancialReadOwner:
    """Account owner для financial read и управляемого rollback."""

    global_id: int
    legacy_tg_id: int | None
    use_global_id: bool
    rollback_ready: bool

    @property
    def legacy_telegram_provider_id(self) -> int | None:
        """Временное точное имя provider-атрибута."""

        return self.legacy_tg_id

    def require_legacy_tg_id(self) -> int:
        if self.legacy_tg_id is None:
            raise FinancialReadOwnerError(
                "Для legacy compatibility отсутствует TelegramId"
            )
        return int(self.legacy_tg_id)


def _validate_global_id(value: int) -> int:
    global_id = int(value)
    if global_id < GLOBAL_ID_MIN or global_id > GLOBAL_ID_MAX:
        raise FinancialReadOwnerError("global_id вне диапазона")
    return global_id


async def _load_control(
    db: AsyncSession,
) -> FinancialMigrationControl:
    """Загрузить singleton control для read/write owner boundary."""

    control = (
        await db.execute(
            text(
                """
                SELECT
                    financial_read_global_id_enabled,
                    financial_read_rollback_ready,
                    nonfinancial_read_global_id_enabled,
                    dual_write_enabled,
                    shadow_read_enabled,
                    legacy_authoritative
                FROM efhc_core.identity_migration_control
                WHERE singleton_id = 1
                """
            )
        )
    ).first()
    if control is None:
        raise FinancialReadOwnerError(
            "Identity migration control отсутствует"
        )
    nonfinancial_flag = getattr(
        control,
        "nonfinancial_read_global_id_enabled",
        True,
    )
    return FinancialMigrationControl(
        financial_read_global_id_enabled=bool(
            control.financial_read_global_id_enabled
        ),
        financial_read_rollback_ready=bool(
            control.financial_read_rollback_ready
        ),
        nonfinancial_read_global_id_enabled=bool(
            nonfinancial_flag
        ),
        dual_write_enabled=bool(control.dual_write_enabled),
        shadow_read_enabled=bool(control.shadow_read_enabled),
        legacy_authoritative=bool(control.legacy_authoritative),
    )


async def resolve_financial_read_owner(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
) -> FinancialReadOwner:
    """Разрешить financial owner через DB control цикла 1627."""

    if (global_id is None) == (tg_id is None):
        raise FinancialReadOwnerError(
            "Требуется ровно один identity selector"
        )

    control = await _load_control(db)
    if control.financial_read_global_id_enabled:
        ready = (
            bool(control.dual_write_enabled)
            and bool(control.shadow_read_enabled)
            and bool(control.nonfinancial_read_global_id_enabled)
        )
    else:
        ready = bool(control.legacy_authoritative)
    if not ready:
        raise FinancialReadOwnerError(
            "Financial migration control не готов"
        )

    if global_id is not None:
        gid = _validate_global_id(global_id)
        user = (
            await db.execute(
                text(
                    """
                    SELECT global_id, tg_id
                    FROM efhc_core.users
                    WHERE global_id = :global_id
                    LIMIT 1
                    """
                ),
                {"global_id": gid},
            )
        ).first()
    else:
        legacy_tg = int(tg_id or 0)
        if legacy_tg <= 0:
            raise FinancialReadOwnerError("TelegramId недопустим")
        user = (
            await db.execute(
                text(
                    """
                    SELECT global_id, tg_id
                    FROM efhc_core.users
                    WHERE tg_id = :tg_id
                    LIMIT 1
                    """
                ),
                {"tg_id": legacy_tg},
            )
        ).first()

    if user is None or user.global_id is None:
        raise FinancialReadOwnerError("Account owner mapping не найден")

    return FinancialReadOwner(
        global_id=_validate_global_id(int(user.global_id)),
        legacy_tg_id=(
            int(user.tg_id) if user.tg_id is not None else None
        ),
        use_global_id=bool(control.financial_read_global_id_enabled),
        rollback_ready=bool(control.financial_read_rollback_ready),
    )


__all__ = [
    "FinancialReadOwner",
    "FinancialReadOwnerError",
    "resolve_financial_read_owner",
]
