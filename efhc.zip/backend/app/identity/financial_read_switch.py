"""Provider ingress resolution для financial business reads."""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

GLOBAL_ID_MIN = 1
GLOBAL_ID_MAX = 9_999_999_999


class FinancialReadOwnerError(RuntimeError):
    """Financial owner нельзя разрешить без безопасного mapping."""


@dataclass(frozen=True, slots=True)
class FinancialReadOwner:
    """Канонический owner и опциональный Telegram delivery subject."""

    global_id: int
    provider_tg_id: int | None


def _validate_global_id(value: int) -> int:
    global_id = int(value)
    if global_id < GLOBAL_ID_MIN or global_id > GLOBAL_ID_MAX:
        raise FinancialReadOwnerError("global_id вне диапазона")
    return global_id


async def resolve_financial_read_owner(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
) -> FinancialReadOwner:
    """Нормализовать canonical или Telegram ingress до ``global_id``.

    Financial business services используют ``global_id``. Telegram subject
    допускается только на явно обозначенной provider-ingress границе.
    """

    if (global_id is None) == (tg_id is None):
        raise FinancialReadOwnerError(
            "Требуется ровно один identity selector"
        )

    if global_id is not None:
        gid = _validate_global_id(global_id)
        user = (
            await db.execute(
                text(
                    """
                    SELECT global_id, tg_id AS provider_id
                    FROM efhc_core.users
                    WHERE global_id = :global_id
                    LIMIT 1
                    """
                ),
                {"global_id": gid},
            )
        ).first()
    else:
        provider_tg = int(tg_id or 0)
        if provider_tg <= 0:
            raise FinancialReadOwnerError("TelegramId недопустим")
        user = (
            await db.execute(
                text(
                    """
                    SELECT
                        u.global_id,
                        ui.provider_subject AS provider_id
                    FROM efhc_core.user_identities ui
                    INNER JOIN efhc_core.users u
                        ON u.global_id = ui.global_id
                    WHERE ui.provider = 'telegram'
                      AND ui.provider_tenant = 'default'
                      AND ui.provider_subject = :subject
                      AND ui.status = 'active'
                      AND ui.is_verified = TRUE
                    LIMIT 1
                    """
                ),
                {"subject": str(provider_tg)},
            )
        ).first()
        if user is None:
            user = (
                await db.execute(
                    text(
                        """
                        SELECT global_id, tg_id AS provider_id
                        FROM efhc_core.users
                        WHERE tg_id = :tg_id
                        LIMIT 1
                        """
                    ),
                    {"tg_id": provider_tg},
                )
            ).first()

    if user is None or user.global_id is None:
        raise FinancialReadOwnerError("Account owner mapping не найден")

    return FinancialReadOwner(
        global_id=_validate_global_id(int(user.global_id)),
        provider_tg_id=(
            int(user.provider_id)
            if user.provider_id is not None
            else None
        ),
    )


__all__ = [
    "FinancialReadOwner",
    "FinancialReadOwnerError",
    "resolve_financial_read_owner",
]
