"""Render-only migration harness for future users.user_id backfill.

This stage does not execute a backfill. The module validates a
supplied
snapshot and renders guarded PostgreSQL SQL for a later approved cycle.
The deterministic rule for historical rows is ``user_id = users.id``.
Existing non-null ``user_id`` values are preserved. Telegram IDs, wallet
addresses and provider subjects never participate in the mapping.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import Final

from app.identity.types import (
    GlobalId,
    InvalidGlobalId,
    global_id_from_database,
)

BACKFILL_CYCLE: Final[int] = 1598
BACKFILL_SOURCE_HEAD: Final[str] = "EFHC_Bot_v171_94.zip"
BACKFILL_TARGET_HEAD: Final[str] = "EFHC_Bot_v171_95.zip"
BACKFILL_APPLY_ENABLED: Final[bool] = False


class BackfillStatus(StrEnum):
    """Decision for one legacy user row."""

    BACKFILL_LEGACY_ID = "BACKFILL_LEGACY_ID"
    PRESERVE_ASSIGNED = "PRESERVE_ASSIGNED"


class UserIdBackfillConflict(ValueError):
    """Raised when a deterministic future backfill is unsafe."""


@dataclass(frozen=True, slots=True)
class LegacyUserSnapshot:
    """Minimal non-financial row required by the harness."""

    legacy_id: int
    user_id: int | None


@dataclass(frozen=True, slots=True)
class UserIdBackfillDecision:
    """Planned canonical ID for one legacy user row."""

    legacy_id: int
    current_user_id: int | None
    planned_user_id: int
    status: BackfillStatus


@dataclass(frozen=True, slots=True)
class UserIdBackfillPlan:
    """Machine-readable deterministic backfill plan."""

    cycle: int
    source_head: str
    target_head: str
    apply_enabled: bool
    runtime_read_switch: bool
    row_count: int
    backfill_count: int
    preserved_count: int
    mapping_sha256: str
    decisions: tuple[UserIdBackfillDecision, ...]


def _legacy_telegram_provider_id(value: object) -> GlobalId:
    try:
        return global_id_from_database(value)
    except InvalidGlobalId as exc:
        raise UserIdBackfillConflict(
            "legacy users.id is outside the GlobalId range"
        ) from exc


def build_user_id_backfill_plan(
    rows: Iterable[LegacyUserSnapshot],
) -> UserIdBackfillPlan:
    """Validate and plan ``NULL user_id -> users.id`` mapping.

    The function is pure and has no database connection. Existing
    non-null system IDs are preserved. The final planned ID set must be
    unique and within the canonical range.
    """

    snapshots = tuple(rows)
    legacy_ids: set[int] = set()
    decisions: list[UserIdBackfillDecision] = []

    for row in snapshots:
        legacy = _legacy_telegram_provider_id(row.legacy_id).to_database()
        if legacy in legacy_ids:
            raise UserIdBackfillConflict(
                "duplicate legacy users.id in snapshot"
            )
        legacy_ids.add(legacy)

        if row.user_id is None:
            decisions.append(
                UserIdBackfillDecision(
                    legacy_id=legacy,
                    current_user_id=None,
                    planned_user_id=legacy,
                    status=BackfillStatus.BACKFILL_LEGACY_ID,
                )
            )
            continue

        current = global_id_from_database(row.user_id).to_database()
        decisions.append(
            UserIdBackfillDecision(
                legacy_id=legacy,
                current_user_id=current,
                planned_user_id=current,
                status=BackfillStatus.PRESERVE_ASSIGNED,
            )
        )

    planned_ids = [item.planned_user_id for item in decisions]
    if len(planned_ids) != len(set(planned_ids)):
        raise UserIdBackfillConflict(
            "planned users.user_id values are not unique"
        )

    ordered = tuple(sorted(decisions, key=lambda item: item.legacy_id))
    payload = [asdict(item) for item in ordered]
    digest = hashlib.sha256(
        json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()

    return UserIdBackfillPlan(
        cycle=BACKFILL_CYCLE,
        source_head=BACKFILL_SOURCE_HEAD,
        target_head=BACKFILL_TARGET_HEAD,
        apply_enabled=BACKFILL_APPLY_ENABLED,
        runtime_read_switch=False,
        row_count=len(ordered),
        backfill_count=sum(
            item.status is BackfillStatus.BACKFILL_LEGACY_ID
            for item in ordered
        ),
        preserved_count=sum(
            item.status is BackfillStatus.PRESERVE_ASSIGNED
            for item in ordered
        ),
        mapping_sha256=digest,
        decisions=ordered,
    )


def postgres_user_id_backfill_preflight_sql() -> str:
    """Return read-only PostgreSQL conflict and count checks."""

    return """
SELECT
    COUNT(*) AS users_count,
    COUNT(*) FILTER (WHERE user_id IS NULL) AS user_id_null_count,
    COUNT(*) FILTER (WHERE user_id IS NOT NULL)
        AS user_id_populated_count,
    COUNT(DISTINCT global_id) AS unique_global_id_count
FROM efhc_core.users;

SELECT COUNT(*) AS out_of_range_count
FROM efhc_core.users
WHERE id < 1
   OR id > 9999999999
   OR (
       user_id IS NOT NULL
       AND (user_id < 1 OR user_id > 9999999999)
   );

SELECT COUNT(*) AS duplicate_user_id_groups
FROM (
    SELECT user_id
    FROM efhc_core.users
    WHERE user_id IS NOT NULL
    GROUP BY user_id
    HAVING COUNT(*) > 1
) AS duplicates;

SELECT COUNT(*) AS planned_collision_count
FROM efhc_core.users AS legacy_user
JOIN efhc_core.users AS assigned_user
  ON assigned_user.user_id = legacy_user.id
 AND assigned_user.id <> legacy_user.id
WHERE legacy_user.user_id IS NULL;
""".strip() + "\n"


def postgres_user_id_backfill_apply_sql() -> str:
    """Render guarded future SQL; never execute it in this stage."""

    return """
BEGIN;

LOCK TABLE efhc_core.users
IN SHARE ROW EXCLUSIVE MODE;

DO $efhc_user_id_backfill_guard$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM efhc_core.users
        WHERE id < 1 OR id > 9999999999
    ) THEN
        RAISE EXCEPTION 'legacy users.id is out of GlobalId range';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM efhc_core.users AS legacy_user
        JOIN efhc_core.users AS assigned_user
          ON assigned_user.user_id = legacy_user.id
         AND assigned_user.id <> legacy_user.id
        WHERE legacy_user.user_id IS NULL
    ) THEN
        RAISE EXCEPTION 'users.user_id backfill collision';
    END IF;
END
$efhc_user_id_backfill_guard$;

UPDATE efhc_core.users
SET user_id = id
WHERE user_id IS NULL;

DO $efhc_user_id_backfill_verify$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM efhc_core.users
        WHERE user_id IS NULL
    ) THEN
        RAISE EXCEPTION 'users.user_id backfill left NULL rows';
    END IF;

    IF EXISTS (
        SELECT user_id
        FROM efhc_core.users
        GROUP BY user_id
        HAVING COUNT(*) > 1
    ) THEN
        RAISE EXCEPTION 'users.user_id backfill created duplicates';
    END IF;
END
$efhc_user_id_backfill_verify$;

SELECT setval(
    'efhc_core.users_user_id_seq',
    GREATEST(
        COALESCE((SELECT MAX(id) FROM efhc_core.users), 0),
        COALESCE((SELECT MAX(user_id) FROM efhc_core.users), 0)
    ) + 1,
    false
);

COMMIT;
""".strip() + "\n"


__all__ = [
    "BACKFILL_APPLY_ENABLED",
    "BACKFILL_CYCLE",
    "BACKFILL_SOURCE_HEAD",
    "BACKFILL_TARGET_HEAD",
    "BackfillStatus",
    "LegacyUserSnapshot",
    "UserIdBackfillConflict",
    "UserIdBackfillDecision",
    "UserIdBackfillPlan",
    "build_user_id_backfill_plan",
    "postgres_user_id_backfill_apply_sql",
    "postgres_user_id_backfill_preflight_sql",
]
