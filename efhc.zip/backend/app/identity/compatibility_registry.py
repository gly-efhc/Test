"""Единый реестр семантики идентификаторов EFHC.

Реестр закрепляет физический ``users.global_id``, временный reverse
alias ``User.user_id``, локальный primary key ``id`` и Telegram
provider ``tg_id`` после controlled physical rename цикла 1631.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Final, Literal

IdentitySemantic = Literal[
    "canonical_global_identity",
    "physical_legacy_global_column",
    "reverse_legacy_global_alias",
    "local_record_primary_key",
    "telegram_provider_identity",
]

RegistryStatus = Literal[
    "canonical",
    "compatibility",
    "local_only",
    "provider_only",
]


@dataclass(frozen=True, slots=True)
class IdentityNamePolicy:
    """Политика одного имени идентификатора."""

    name: str
    semantic: IdentitySemantic
    status: RegistryStatus
    owner_allowed: bool
    wire_type: str
    physical_database_name: str | None
    allowed_scopes: tuple[str, ...]
    forbidden_new_uses: tuple[str, ...]
    sunset_cycle: int | None


@dataclass(frozen=True, slots=True)
class CompatibilityAliasPolicy:
    """Политика явно зарегистрированного compatibility alias."""

    alias: str
    target: str
    semantic: IdentitySemantic
    allowed_scopes: tuple[str, ...]
    created_cycle: int
    sunset_cycle: int
    runtime_switch: bool


@dataclass(frozen=True, slots=True)
class HistoricalScopePolicy:
    """Путь, где историческая терминология не управляет runtime."""

    path_prefix: str
    purpose: str
    may_define_current_runtime: bool


@dataclass(frozen=True, slots=True)
class IdentityGuardFilePolicy:
    """Файл, разрешённый identity boundary единым реестром."""

    path: str
    max_identifier_occurrences: int
    semantic: str
    reason: str


IDENTITY_NAME_POLICIES: Final[tuple[IdentityNamePolicy, ...]] = (
    IdentityNamePolicy(
        name="global_id",
        semantic="canonical_global_identity",
        status="canonical",
        owner_allowed=True,
        wire_type="string_10_ascii_digits",
        physical_database_name="users.global_id",
        allowed_scopes=(
            "backend/app/identity",
            "frontend/src/contracts",
            "frontend/src/types",
            "future_domain_ownership",
        ),
        forbidden_new_uses=(
            "derive_from_provider",
            "derive_from_local_pk",
            "javascript_number",
        ),
        sunset_cycle=None,
    ),
    IdentityNamePolicy(
        name="user_id",
        semantic="reverse_legacy_global_alias",
        status="compatibility",
        owner_allowed=False,
        wire_type="legacy_only",
        physical_database_name="users.global_id",
        allowed_scopes=(
            "backend/app/models/user_models.py",
            "backend/app/identity/legacy_user_id.py",
            "backend/app/identity/user_id_backfill.py",
            "backend/app/identity/user_id_expand.py",
            "ops/identity",
            "tests/compatibility",
            "historical_documents",
        ),
        forbidden_new_uses=(
            "new_dto",
            "new_route_contract",
            "new_domain_owner",
            "new_foreign_key_name",
        ),
        sunset_cycle=1632,
    ),
    IdentityNamePolicy(
        name="id",
        semantic="local_record_primary_key",
        status="local_only",
        owner_allowed=False,
        wire_type="table_local",
        physical_database_name=None,
        allowed_scopes=(
            "local_table_primary_key",
            "local_relationship_internal",
        ),
        forbidden_new_uses=(
            "cross_subsystem_identity",
            "account_owner",
            "provider_subject",
        ),
        sunset_cycle=None,
    ),
    IdentityNamePolicy(
        name="tg_id",
        semantic="telegram_provider_identity",
        status="provider_only",
        owner_allowed=False,
        wire_type="telegram_safe_integer",
        physical_database_name="users.tg_id",
        allowed_scopes=(
            "telegram_adapter",
            "telegram_delivery",
            "telegram_source_event",
            "identity_resolution",
            "legacy_runtime_before_switch",
            "historical_documents",
        ),
        forbidden_new_uses=(
            "new_domain_owner",
            "new_financial_owner",
            "global_identity",
        ),
        sunset_cycle=None,
    ),
)

COMPATIBILITY_ALIASES: Final[
    tuple[CompatibilityAliasPolicy, ...]
] = (
    CompatibilityAliasPolicy(
        alias="User.user_id",
        target="User.global_id",
        semantic="reverse_legacy_global_alias",
        allowed_scopes=("orm_reverse_compatibility",),
        created_cycle=1631,
        sunset_cycle=1632,
        runtime_switch=False,
    ),
    CompatibilityAliasPolicy(
        alias="User.legacy_pk",
        target="User.id",
        semantic="local_record_primary_key",
        allowed_scopes=(
            "migration_harness",
            "reconciliation",
            "compatibility_tests",
        ),
        created_cycle=1602,
        sunset_cycle=1632,
        runtime_switch=False,
    ),
    CompatibilityAliasPolicy(
        alias="User.legacy_runtime_id",
        target="User.id",
        semantic="local_record_primary_key",
        allowed_scopes=(
            "migration_harness",
            "reconciliation",
            "compatibility_tests",
        ),
        created_cycle=1598,
        sunset_cycle=1632,
        runtime_switch=False,
    ),
    CompatibilityAliasPolicy(
        alias="User.telegram_id",
        target="User.tg_id",
        semantic="telegram_provider_identity",
        allowed_scopes=(
            "telegram_adapter",
            "identity_resolution",
            "compatibility_tests",
        ),
        created_cycle=1602,
        sunset_cycle=1632,
        runtime_switch=False,
    ),
    CompatibilityAliasPolicy(
        alias="UserId",
        target="GlobalId",
        semantic="canonical_global_identity",
        allowed_scopes=(
            "backend/app/identity/legacy_user_id.py",
            "compatibility_tests",
        ),
        created_cycle=1602,
        sunset_cycle=1632,
        runtime_switch=False,
    ),
)

IDENTITY_GUARD_FILES: Final[
    tuple[IdentityGuardFilePolicy, ...]
] = (
    IdentityGuardFilePolicy(
        path=(
            "backend/app/identity/"
            "compatibility_registry.py"
        ),
        max_identifier_occurrences=6,
        semantic="AUTH_IDENTITY",
        reason=(
            "Единый semantic registry имён и compatibility aliases."
        ),
    ),
)

HISTORICAL_SCOPES: Final[tuple[HistoricalScopePolicy, ...]] = (
    HistoricalScopePolicy(
        path_prefix="docs/history/identity/",
        purpose="Исторические решения identity migration.",
        may_define_current_runtime=False,
    ),
    HistoricalScopePolicy(
        path_prefix="docs/cycles/",
        purpose="Отчёты завершённых циклов и roadmap.",
        may_define_current_runtime=False,
    ),
    HistoricalScopePolicy(
        path_prefix="docs/audits/",
        purpose="Доказательные аудиты конкретных HEAD.",
        may_define_current_runtime=False,
    ),
    HistoricalScopePolicy(
        path_prefix="reports/",
        purpose="Машинные evidence и исторические результаты.",
        may_define_current_runtime=False,
    ),
)


def get_identity_name_policy(name: str) -> IdentityNamePolicy:
    """Вернуть зарегистрированную семантику имени."""

    for policy in IDENTITY_NAME_POLICIES:
        if policy.name == name:
            return policy
    raise KeyError(f"Имя идентификатора не зарегистрировано: {name}")


def get_compatibility_alias(alias: str) -> CompatibilityAliasPolicy:
    """Вернуть точный зарегистрированный compatibility alias."""

    for policy in COMPATIBILITY_ALIASES:
        if policy.alias == alias:
            return policy
    raise KeyError(f"Compatibility alias не зарегистрирован: {alias}")


def build_identity_compatibility_registry() -> dict[str, object]:
    """Сформировать JSON-ready представление единого реестра."""

    return {
        "схема_реестра": "EFHC_IDENTITY_COMPATIBILITY_REGISTRY_V1",
        "цикл": 1631,
        "канонический_идентификатор": "global_id",
        "физическая_owner_колонка": "global_id",
        "reverse_legacy_alias": "user_id",
        "локальный_primary_key": "id",
        "physical_rename_cycle": 1631,
        "политики_имён": [
            {
                **asdict(policy),
                "allowed_scopes": list(policy.allowed_scopes),
                "forbidden_new_uses": list(
                    policy.forbidden_new_uses
                ),
            }
            for policy in IDENTITY_NAME_POLICIES
        ],
        "compatibility_aliases": [
            {
                **asdict(policy),
                "allowed_scopes": list(policy.allowed_scopes),
            }
            for policy in COMPATIBILITY_ALIASES
        ],
        "разрешённые_guard_файлы": [
            {
                "путь": policy.path,
                "максимум_упоминаний": (
                    policy.max_identifier_occurrences
                ),
                "семантика": policy.semantic,
                "причина": policy.reason,
            }
            for policy in IDENTITY_GUARD_FILES
        ],
        "исторические_области": [
            asdict(policy) for policy in HISTORICAL_SCOPES
        ],
        "historical_backfill": True,
        "runtime_read_switch": True,
        "financial_ownership_switch": True,
        "physical_rename_complete": True,
    }


__all__ = [
    "COMPATIBILITY_ALIASES",
    "HISTORICAL_SCOPES",
    "IDENTITY_GUARD_FILES",
    "IDENTITY_NAME_POLICIES",
    "CompatibilityAliasPolicy",
    "HistoricalScopePolicy",
    "IdentityGuardFilePolicy",
    "IdentityNamePolicy",
    "build_identity_compatibility_registry",
    "get_compatibility_alias",
    "get_identity_name_policy",
]
