"""Действующий реестр семантики идентификаторов EFHC.

Реестр описывает post-cutover состояние цикла 1688. Retired ORM aliases
не являются частью active contract и не экспортируются как разрешённая
совместимость.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Final, Literal

IdentitySemantic = Literal[
    "canonical_global_identity",
    "local_record_primary_key",
    "provider_identity",
]
RegistryStatus = Literal["canonical", "local_only", "provider_only"]


@dataclass(frozen=True, slots=True)
class IdentityNamePolicy:
    """Политика одного имени идентификатора."""

    name: str
    semantic: IdentitySemantic
    status: RegistryStatus
    owner_allowed: bool
    wire_type: str
    physical_database_name: str | None
    allowed_scopes: tuple[str, ...]
    forbidden_new_uses: tuple[str, ...]
    sunset_cycle: int | None = None


@dataclass(frozen=True, slots=True)
class CompatibilityAliasPolicy:
    """Retired compatibility descriptor; active aliases отсутствуют."""

    alias: str
    target: str
    semantic: IdentitySemantic
    allowed_scopes: tuple[str, ...]
    created_cycle: int
    sunset_cycle: int
    runtime_switch: bool


@dataclass(frozen=True, slots=True)
class HistoricalScopePolicy:
    """Путь, где историческая терминология не управляет runtime."""

    path_prefix: str
    purpose: str
    may_define_current_runtime: bool


@dataclass(frozen=True, slots=True)
class IdentityGuardFilePolicy:
    """Файл действующего identity guard."""

    path: str
    max_identifier_occurrences: int
    semantic: str
    reason: str


IDENTITY_NAME_POLICIES: Final[tuple[IdentityNamePolicy, ...]] = (
    IdentityNamePolicy(
        name="global_id",
        semantic="canonical_global_identity",
        status="canonical",
        owner_allowed=True,
        wire_type="string_10_ascii_digits",
        physical_database_name="users.global_id",
        allowed_scopes=(
            "business_owner",
            "internal_api",
            "orm_fk",
            "admin_actor",
            "financial_idempotency",
        ),
        forbidden_new_uses=(
            "derive_from_provider_without_resolution",
            "derive_from_local_pk",
            "javascript_number",
            "json_number",
        ),
    ),
    IdentityNamePolicy(
        name="id",
        semantic="local_record_primary_key",
        status="local_only",
        owner_allowed=False,
        wire_type="table_local",
        physical_database_name=None,
        allowed_scopes=("local_table_primary_key",),
        forbidden_new_uses=(
            "account_owner",
            "cross_subsystem_identity",
            "provider_subject",
        ),
    ),
    IdentityNamePolicy(
        name="tg_id",
        semantic="provider_identity",
        status="provider_only",
        owner_allowed=False,
        wire_type="telegram_safe_integer",
        physical_database_name="users.tg_id",
        allowed_scopes=(
            "telegram_authentication",
            "telegram_ingress",
            "telegram_delivery",
            "provider_identity_mapping",
            "telegram_payment_metadata",
            "historical_provider_read_through",
        ),
        forbidden_new_uses=(
            "business_owner",
            "financial_owner",
            "owner_fk",
            "internal_api_owner",
            "admin_actor_owner",
        ),
    ),
)

# После cutover цикла 1688 активных aliases намеренно нет.
COMPATIBILITY_ALIASES: Final[tuple[CompatibilityAliasPolicy, ...]] = ()

IDENTITY_GUARD_FILES: Final[tuple[IdentityGuardFilePolicy, ...]] = (
    IdentityGuardFilePolicy(
        path="ops/identity/check_global_id_canon.py",
        max_identifier_occurrences=200,
        semantic="AUTH_IDENTITY_GUARD",
        reason="Fail-closed проверка current global_id canon.",
    ),
)

HISTORICAL_SCOPES: Final[tuple[HistoricalScopePolicy, ...]] = (
    HistoricalScopePolicy(
        path_prefix="docs/history/",
        purpose="Исторические решения и снимки migration period.",
        may_define_current_runtime=False,
    ),
    HistoricalScopePolicy(
        path_prefix="docs/cycles/",
        purpose="Отчёты завершённых рабочих циклов.",
        may_define_current_runtime=False,
    ),
    HistoricalScopePolicy(
        path_prefix="docs/audits/",
        purpose="Доказательные аудиты конкретных исторических HEAD.",
        may_define_current_runtime=False,
    ),
    HistoricalScopePolicy(
        path_prefix="reports/",
        purpose="Машинные evidence и generated reports.",
        may_define_current_runtime=False,
    ),
)


def get_identity_name_policy(name: str) -> IdentityNamePolicy:
    """Вернуть зарегистрированную семантику имени."""

    for policy in IDENTITY_NAME_POLICIES:
        if policy.name == name:
            return policy
    raise KeyError(f"Имя идентификатора не зарегистрировано: {name}")


def get_compatibility_alias(alias: str) -> CompatibilityAliasPolicy:
    """Fail closed: active compatibility aliases отсутствуют."""

    raise KeyError(f"Compatibility alias retired: {alias}")


def build_identity_compatibility_registry() -> dict[str, object]:
    """Сформировать JSON-ready current identity registry."""

    return {
        "схема_реестра": "EFHC_IDENTITY_REGISTRY_V2",
        "цикл": 1688,
        "версия": "v173.08",
        "канонический_идентификатор": "global_id",
        "физическая_owner_колонка": "users.global_id",
        "telegram_provider_subject": "tg_id",
        "identity_resolution": "provider + subject -> global_id",
        "business_owner_tg_id": 0,
        "active_compatibility_aliases": 0,
        "политики_имён": [
            {
                **asdict(policy),
                "allowed_scopes": list(policy.allowed_scopes),
                "forbidden_new_uses": list(policy.forbidden_new_uses),
            }
            for policy in IDENTITY_NAME_POLICIES
        ],
        "compatibility_aliases": [],
        "разрешённые_guard_файлы": [
            {
                "путь": policy.path,
                "максимум_упоминаний": (
                    policy.max_identifier_occurrences
                ),
                "семантика": policy.semantic,
                "причина": policy.reason,
            }
            for policy in IDENTITY_GUARD_FILES
        ],
        "исторические_области": [
            asdict(policy) for policy in HISTORICAL_SCOPES
        ],
        "historical_read_through_only": True,
        "runtime_read_switch": True,
        "financial_ownership_switch": True,
        "physical_rename_complete": True,
        "legacy_alias_removal_complete": True,
    }


__all__ = [
    "COMPATIBILITY_ALIASES",
    "HISTORICAL_SCOPES",
    "IDENTITY_GUARD_FILES",
    "IDENTITY_NAME_POLICIES",
    "CompatibilityAliasPolicy",
    "HistoricalScopePolicy",
    "IdentityGuardFilePolicy",
    "IdentityNamePolicy",
    "build_identity_compatibility_registry",
    "get_compatibility_alias",
    "get_identity_name_policy",
]
