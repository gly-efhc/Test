"""Owner boundary для financial write cutover цикла 1640."""

from __future__ import annotations

from dataclasses import dataclass

from app.identity.financial_read_switch import (
    FinancialReadOwnerError,
    _load_control,
    _validate_global_id,
)
from app.models.user_models import User
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class FinancialWriteOwnerError(RuntimeError):
    """Владелец финансовой мутации не разрешён и не заблокирован."""


@dataclass(frozen=True, slots=True)
class FinancialWriteOwner:
    """Канонический owner заблокированной финансовой мутации."""

    global_id: int
    legacy_tg_id: int | None
    rollback_ready: bool


async def resolve_and_lock_financial_write_owner(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
) -> FinancialWriteOwner:
    """Разрешить и заблокировать owner для финансовой мутации.

    На подготовительном этапе функция принимает ровно один селектор:
    канонический ``global_id`` или provider-specific ``tg_id``.
    Результат всегда нормализуется до ``global_id``.

    Строка пользователя блокируется ``FOR UPDATE`` в текущей транзакции.
    Это исключает параллельное расхождение owner mapping
    и денежных записей.
    Запись доступна только при включённом ``dual_write_enabled``.
    """

    if (global_id is None) == (tg_id is None):
        raise FinancialWriteOwnerError(
            "Требуется ровно один identity selector"
        )

    try:
        control = await _load_control(db)
    except FinancialReadOwnerError as exc:
        raise FinancialWriteOwnerError(str(exc)) from exc

    if not control.dual_write_enabled:
        raise FinancialWriteOwnerError("Financial dual-write отключён")

    if global_id is not None:
        try:
            validated_global_id = _validate_global_id(global_id)
        except FinancialReadOwnerError as exc:
            raise FinancialWriteOwnerError(str(exc)) from exc
        selector = User.global_id == validated_global_id
    else:
        legacy_tg_id = int(tg_id or 0)
        if legacy_tg_id <= 0:
            raise FinancialWriteOwnerError("TelegramId недопустим")
        selector = User.tg_id == legacy_tg_id

    statement = (
        select(User.global_id, User.tg_id, User.is_active)
        .where(selector)
        .limit(1)
        .with_for_update()
    )
    user = (await db.execute(statement)).first()

    if user is None or user.global_id is None:
        raise FinancialWriteOwnerError(
            "Account owner mapping не найден"
        )
    if user.is_active is not True:
        raise FinancialWriteOwnerError("Account owner неактивен")

    try:
        resolved_global_id = _validate_global_id(int(user.global_id))
    except FinancialReadOwnerError as exc:
        raise FinancialWriteOwnerError(str(exc)) from exc

    return FinancialWriteOwner(
        global_id=resolved_global_id,
        legacy_tg_id=(
            int(user.tg_id) if user.tg_id is not None else None
        ),
        rollback_ready=bool(control.financial_read_rollback_ready),
    )


__all__ = [
    "FinancialWriteOwner",
    "FinancialWriteOwnerError",
    "resolve_and_lock_financial_write_owner",
]
