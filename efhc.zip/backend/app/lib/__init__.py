"""Lightweight shared helpers.

This package intentionally stays small and dependency-free.
"""
