# backend/app/init.py
# Compatibility entrypoint retained for startup architecture guards.

from __future__ import annotations


def create_app():
    """Delegate to canonical app.main app object."""
    from .main import app as main_app

    return main_app


__all__ = ["create_app"]
