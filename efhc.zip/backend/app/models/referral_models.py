# -*- coding: utf-8 -*-
"""backend/app/models/referral_models.py

ORM-модель домена «Рефералы» EFHC Bot.

Канон:
- Денежных полей здесь нет: вознаграждения фиксируются в журнале банка.
- Один приглашённый может иметь только одного пригласившего.
- Нельзя пригласить самого себя.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column

from backend.app.core.config_core import get_settings
from . import Base


settings = get_settings()
CORE_SCHEMA = settings.DB_SCHEMA_CORE  # например, "efhc_core"


class ReferralLink(Base):
    """Связь «пригласивший → приглашённый»."""

    __tablename__ = "referral_links"
    __table_args__ = (
        UniqueConstraint(
            "invitee_tg_id",
            name="uq_referral_links_invitee",
        ),
        CheckConstraint(
            "inviter_tg_id <> invitee_tg_id",
            name="ck_referral_links_not_self",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    inviter_tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )
    invitee_tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    activated_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    campaign: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
    )
    meta: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
    )

    def __repr__(self) -> str:
        active = self.activated_at is not None
        return (
            f"<ReferralLink id={self.id} "
            f"{self.inviter_tg_id}->{self.invitee_tg_id} active={active}>"
        )


Index(
    "ix_ref_links_created_id",
    ReferralLink.created_at,
    ReferralLink.id,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_ref_links_referrer_created",
    ReferralLink.inviter_tg_id,
    ReferralLink.created_at,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_ref_links_activated_at",
    ReferralLink.activated_at,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)


class ReferralBonusLedger(Base):
    """Журнал реферальных бонусов (не баланс, не банк).

    Назначение:
      • хранит факт начисления бонуса/награды за реферальные действия,
        чтобы отчёты и лимиты не зависели от пересчётов.

    Канон:
      • сумма хранится как Numeric(20, 8), ROUND_DOWN на уровне сервиса.
      • meta — текстовое поле (нужен ilike в CRUD).
    """

    __tablename__ = "referral_bonus_ledger"
    __table_args__ = {"schema": CORE_SCHEMA}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{CORE_SCHEMA}.users.tg_id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    amount_efhc: Mapped[object] = mapped_column(
        Numeric(20, 8),
        nullable=False,
    )

    kind: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        index=True,
    )

    meta: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

__all__ = [
    "ReferralLink",
    "ReferralBonusLedger",
]
