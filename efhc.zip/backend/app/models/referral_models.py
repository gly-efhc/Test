# -*- coding: utf-8 -*-
"""backend/app/models/referral_models.py

ORM-модель домена «Рефералы» EFHC Bot.

Канон:
- Денежных полей здесь нет: вознаграждения фиксируются в журнале банка.
- Один приглашённый может иметь только одного пригласившего.
- Нельзя пригласить самого себя.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Index,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column

from backend.app.core.config_core import get_settings
from . import Base


settings = get_settings()
CORE_SCHEMA = settings.DB_SCHEMA_CORE  # например, "efhc_core"


class ReferralLink(Base):
    """Связь «пригласивший → приглашённый»."""

    __tablename__ = "referral_links"
    __table_args__ = (
        UniqueConstraint(
            "referee_id",
            name="uq_referral_links_referee",
        ),
        CheckConstraint(
            "referrer_id <> referee_id",
            name="ck_referral_not_self",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    referrer_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )
    referee_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    activated_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    campaign: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
    )
    meta: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
    )

    def __repr__(self) -> str:
        active = self.activated_at is not None
        return (
            f"<ReferralLink id={self.id} "
            f"{self.referrer_id}->{self.referee_id} active={active}>"
        )


Index(
    "ix_ref_links_created_id",
    ReferralLink.created_at,
    ReferralLink.id,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_ref_links_referrer_created",
    ReferralLink.referrer_id,
    ReferralLink.created_at,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_ref_links_activated_at",
    ReferralLink.activated_at,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)


__all__ = [
    "ReferralLink",
]
