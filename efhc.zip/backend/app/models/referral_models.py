"""backend/app/models/referral_models.py

ORM-модель домена «Рефералы» EFHC Bot.

Канон:
- Денежных полей здесь нет: начисления фиксируются в банке.
- Один приглашённый может иметь только одного пригласившего.
- Нельзя пригласить самого себя.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column

from ..core.config_core import get_settings
from . import Base

settings = get_settings()
CORE_SCHEMA = settings.DB_SCHEMA_CORE


class ReferralLink(Base):
    """Связь «пригласивший → приглашённый»."""

    __tablename__ = "referral_links"
    __table_args__ = (
        UniqueConstraint(
            "invitee_tg_id",
            name="uq_referral_links_invitee",
        ),
        CheckConstraint(
            "inviter_tg_id <> invitee_tg_id",
            name="ck_referral_links_not_self",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    inviter_tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )

    invitee_tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    activated_at: Mapped[datetime | None] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    campaign: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
        index=True,
    )

    meta: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
    )

    def __repr__(self) -> str:
        active = self.activated_at is not None
        return (
            "<ReferralLink "
            f"id={self.id} "
            f"{self.inviter_tg_id}->{self.invitee_tg_id} "
            f"active={active}>"
        )


Index(
    "ix_ref_links_created_id",
    ReferralLink.created_at,
    ReferralLink.id,
    postgresql_using="btree",
)
Index(
    "ix_ref_links_referrer_created",
    ReferralLink.inviter_tg_id,
    ReferralLink.created_at,
    postgresql_using="btree",
)
Index(
    "ix_ref_links_activated_at",
    ReferralLink.activated_at,
    postgresql_using="btree",
)


class ReferralBonusLedger(Base):
    """Журнал реферальных начислений (не баланс и не банк)."""

    __tablename__ = "referral_bonus_ledger"
    __table_args__ = {"schema": CORE_SCHEMA}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)

    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{CORE_SCHEMA}.users.tg_id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    amount_efhc: Mapped[object] = mapped_column(
        Numeric(20, 8),
        nullable=False,
    )

    kind: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        index=True,
    )

    meta: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )


__all__ = ["ReferralLink", "ReferralBonusLedger"]
