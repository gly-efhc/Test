# -*- coding: utf-8 -*-
# backend/app/models/lotteries_models.py
# =====================================================================
# Назначение кода:
# SQLAlchemy-модели подсистемы лотерей EFHC Bot.
#
# Канон/инварианты:
# • Модели описывают структуру данных. Денежной логики здесь нет.
# • Курсоры: индексы по (created_at, id) и по ticket_id.
# • Уникальность: один результат на лотерею; билеты уникальны в лотерее.
#
# Запреты:
# • Нет авто-выдачи NFT и P2P.
# • Нет расчётов генерации kWh.
# =====================================================================

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..core.config_core import get_settings
from . import Base

_settings = get_settings()
SCHEMA = _settings.DB_SCHEMA_CORE  # Канон: lotteries в efhc_core


LOTTERIES_STATUS_ENUM = ("draft", "active", "closed", "completed")
PRIZE_TYPE_ENUM = ("EFHC", "NFT")
NFT_CLAIM_STATUS_ENUM = ("pending", "issued", "rejected", "canceled")


class Lotteries(Base):
    """Карточка лотереи: параметры и агрегаты продажи билетов."""

    __tablename__ = "lotteries"
    __table_args__ = (
        CheckConstraint(
            f"status IN {LOTTERIES_STATUS_ENUM}",
            name="lotteries_status_check",
        ),
        CheckConstraint(
            f"prize_type IN {PRIZE_TYPE_ENUM}",
            name="lotteries_prize_type_check",
        ),
        CheckConstraint(
            "total_tickets >= 0",
            name="lotteries_total_tickets_nonneg",
        ),
        CheckConstraint(
            "tickets_sold >= 0",
            name="lotteries_tickets_sold_nonneg",
        ),
        CheckConstraint(
            "tickets_sold <= total_tickets",
            name="lotteries_sold_le_total",
        ),
        Index("ix_lotteries_status", "status"),
        Index("ix_lotteries_created_cursor", "created_at", "id"),
        {"schema": SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)

    prize_type: Mapped[str] = mapped_column(String(8), nullable=False)
    prize_value: Mapped[Optional[str]] = mapped_column(
        String(120),
        nullable=True,
    )

    ticket_price: Mapped[Decimal] = mapped_column(
        Numeric(30, 8),
        nullable=False,
    )

    max_participants: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    max_tickets_per_user: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    total_tickets: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    tickets_sold: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
    )

    status: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        default="draft",
    )
    auto_lotteries: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
    )
    restart_of_lotteries_id: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )
    finished_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
    )

    tickets: Mapped[list["LotteriesTicket"]] = relationship(
        back_populates="lotteries",
        cascade="all, delete-orphan",
        lazy="raise_on_sql",
    )
    result: Mapped[Optional["LotteriesResult"]] = relationship(
        back_populates="lotteries",
        uselist=False,
        cascade="all, delete-orphan",
        lazy="raise_on_sql",
    )
    nft_claims: Mapped[list["LotteriesNFTClaim"]] = relationship(
        back_populates="lotteries",
        cascade="all, delete-orphan",
        lazy="raise_on_sql",
    )


class LotteriesTicket(Base):
    """Билет: уникален по (lotteries_id, ticket_id)."""

    __tablename__ = "lotteries_tickets"
    __table_args__ = (
        UniqueConstraint(
            "lotteries_id",
            "ticket_id",
            name="uq_lotteries_ticket",
        ),
        Index(
            "ix_ticket_owner",
            "owner_tg_id",
            "lotteries_id",
            "ticket_id",
        ),
        Index(
            "ix_ticket_lotteries_cursor",
            "lotteries_id",
            "ticket_id",
        ),
        {"schema": SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    lotteries_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            f"{SCHEMA}.lotteries.id",
            ondelete="CASCADE",
        ),
        nullable=False,
    )
    ticket_id: Mapped[int] = mapped_column(Integer, nullable=False)
    owner_tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    lotteries: Mapped["Lotteries"] = relationship(
        back_populates="tickets",
        lazy="raise_on_sql",
    )


class LotteriesUserStat(Base):
    """Агрегаты по пользователю в лотерее."""

    __tablename__ = "lotteries_user_stats"
    __table_args__ = (
        UniqueConstraint(
            "lotteries_id",
            "tg_id",
            name="uq_lotteries_user_stat",
        ),
        Index(
            "ix_lotteries_user_stat_updated",
            "lotteries_id",
            "updated_at",
        ),
        {"schema": SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    lotteries_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            f"{SCHEMA}.lotteries.id",
            ondelete="CASCADE",
        ),
        nullable=False,
    )
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    tickets_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    lotteries: Mapped["Lotteries"] = relationship(lazy="raise_on_sql")




class LotteriesBuyIdempotency(Base):
    """Идемпотентность покупки билетов.

    SSOT:
    - Денежные операции уже идемпотентны по transfers_log,
      но билеты тоже должны быть read-through идемпотентны.
    - Ключ идемпотентности приходит заголовком Idempotency-Key.
    - Храним точный результат (qty + ticket_ids) для повторов.
    """

    __tablename__ = "lotteries_buy_idempotency"
    __table_args__ = (
        UniqueConstraint(
            "tg_id",
            "idempotency_key",
            name="uq_lotteries_buy_idk",
        ),
        Index("ix_lotteries_buy_idk_created", "created_at"),
        {"schema": SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    idempotency_key: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
    )

    lotteries_id: Mapped[int] = mapped_column(Integer, nullable=False)
    qty: Mapped[int] = mapped_column(Integer, nullable=False)
    ticket_ids: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
    )
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )
class LotteriesResult(Base):
    """Результат: один на лотерею."""

    __tablename__ = "lotteries_results"
    __table_args__ = (
        UniqueConstraint(
            "lotteries_id",
            name="uq_lotteries_result_unique",
        ),
        Index("ix_lotteries_result_created", "created_at"),
        {"schema": SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    lotteries_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            f"{SCHEMA}.lotteries.id",
            ondelete="CASCADE",
        ),
        nullable=False,
    )
    winning_ticket_id: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    winner_tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
    )
    winner_seed_hex: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )
    completed_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
    )

    lotteries: Mapped["Lotteries"] = relationship(
        back_populates="result",
        lazy="raise_on_sql",
    )


class LotteriesNFTClaim(Base):
    """Заявка на вручную выдаваемый NFT-приз (VIP).

    SSOT:
    - Каждый купленный VIP-билет создаёт 1 claim.
    - Claim хранит ticket_number (ticket_id) и tg_id владельца.
    - Выдача NFT выполняется админом.

    Важно:
    - wallet_address в claim — snapshot на момент покупки.
    - Фактическая выдача ориентируется на текущий primary wallet
      пользователя (если он изменился).
    """

    __tablename__ = "lotteries_nft_claims"
    __table_args__ = (
        UniqueConstraint(
            "lotteries_id",
            "ticket_id",
            name="uq_lotteries_nft_claim_ticket",
        ),
        CheckConstraint(
            f"status IN {NFT_CLAIM_STATUS_ENUM}",
            name="nft_claim_status_check",
        ),
        Index("ix_nft_claim_owner", "owner_tg_id", "lotteries_id"),
        Index("ix_nft_claim_status", "status"),
        {"schema": SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    lotteries_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            f"{SCHEMA}.lotteries.id",
            ondelete="CASCADE",
        ),
        nullable=False,
    )
    ticket_id: Mapped[int] = mapped_column(Integer, nullable=False)
    owner_tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False)

    status: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        default="pending",
    )

    wallet_address: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
    )

    meta: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    lotteries: Mapped["Lotteries"] = relationship(
        back_populates="nft_claims",
        lazy="raise_on_sql",
    )
