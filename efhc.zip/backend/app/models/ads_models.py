# backend/app/models/ads_models.py
# =====================================================================
# Назначение кода:
# ORM-модели рекламных слотов (показы в WebApp/боте).
# Канон:
# • Денег здесь нет. Ротация — в scheduler/ads_rotation.py.
# =====================================================================

from __future__ import annotations

from sqlalchemy import BigInteger, DateTime, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from ..core.config_core import get_settings
from . import Base

settings = get_settings()
SCHEMA: str = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


class Ad(Base):
    __tablename__ = "ads"
    __table_args__ = {"schema": SCHEMA}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    title: Mapped[str] = mapped_column(String(256), nullable=False)
    status: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        server_default="active",
    )
    weight: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default="1",
    )
    starts_at: Mapped[object | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    ends_at: Mapped[object | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    created_at: Mapped[object] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

