"""Совместимый реэкспорт канонической ORM-модели ``ShopOrder``.

Отдельная таблица здесь не объявляется; SSOT модели остаётся в
``app.models.shop_models``.
"""

from __future__ import annotations

from app.models.shop_models import ShopOrder

__all__ = ["ShopOrder"]
