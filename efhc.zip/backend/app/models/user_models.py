# -*- coding: utf-8 -*-
"""backend/app/models/user_models.py

ORM-модель домена «Пользователи» EFHC Bot.

Канон/инварианты:
- Единственный идентификатор пользователя в проекте: tg_id.
- Денежные/энергетические поля: Numeric(30, 8), округление вниз делают
  сервисы.
- Запрет «минуса»: main_balance, bonus_balance, available_kwh,
  total_generated_kwh всегда >= 0; exchanged_kwh_total всегда >= 0;
  exchanged_kwh_total <= total_generated_kwh;
  available_kwh — зеркальная ветка:
  available_kwh = total_generated_kwh - exchanged_kwh_total.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Computed,
    Index,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import Numeric

from ..core.config_core import get_settings
from . import Base


settings = get_settings()
CORE_SCHEMA = settings.DB_SCHEMA_CORE  # например, "efhc_core"


class User(Base):
    """Пользователь EFHC Bot (Telegram)."""

    __tablename__ = "users"
    __table_args__ = (
        UniqueConstraint("tg_id", name="uq_users_telegram"),
        UniqueConstraint("ton_wallet", name="uq_users_ton_wallet"),
        CheckConstraint(
            "main_balance >= 0",
            name="ck_users_main_balance_nonneg",
        ),
        CheckConstraint(
            "bonus_balance >= 0",
            name="ck_users_bonus_balance_nonneg",
        ),
        CheckConstraint(
            "available_kwh >= 0",
            name="ck_users_available_kwh_nonneg",
        ),
        CheckConstraint(
            "total_generated_kwh >= 0",
            name="ck_users_total_generated_kwh_nonneg",
        ),
        CheckConstraint(
            "exchanged_kwh_total >= 0",
            name="ck_users_exchanged_kwh_total_nonneg",
        ),
        CheckConstraint(
            "exchanged_kwh_total <= total_generated_kwh",
            name="ck_users_exchanged_le_total",
        ),
        CheckConstraint(
            (
                "available_kwh = "
                "(total_generated_kwh - exchanged_kwh_total)"
            ),
            name="ck_users_available_eq_mirror",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    tg_id: Mapped[int] = mapped_column(
        "tg_id",
        BigInteger,
        nullable=False,
        index=True,
    )
    username: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
    )

    is_active: Mapped[bool] = mapped_column(
        nullable=False,
        default=True,
        server_default="true",
        index=True,
    )
    is_vip: Mapped[bool] = mapped_column(
        nullable=False,
        default=False,
        server_default="false",
        index=True,
    )
    vip_since: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
    )
    vip_checked_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    ton_wallet: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        index=True,
    )

    main_balance: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        default="0",
        server_default="0",
    )
    bonus_balance: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        default="0",
        server_default="0",
    )
    available_kwh: Mapped[str] = mapped_column(
        Numeric(30, 8),
        Computed(
            "GREATEST(total_generated_kwh - exchanged_kwh_total, 0)",
            persisted=True,
        ),
        nullable=False,
    )
    total_generated_kwh: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        default="0",
        server_default="0",
    )
    exchanged_kwh_total: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        default="0",
        server_default="0",
    )


    last_seen_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    meta: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    def __repr__(self) -> str:
        return (
            f"<User tg_id={self.tg_id} vip={self.is_vip} "
            f"main={self.main_balance} bonus={self.bonus_balance}>"
        )


Index(
    "ix_users_created_id",
    User.created_at,
    User.id,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_users_total_kwh",
    User.total_generated_kwh,
    User.id,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_users_available_kwh",
    User.available_kwh,
    User.id,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)


__all__ = [
    "User",
]
