# backend/app/models/admin_models.py
# -*- coding: utf-8 -*-
"""Админские ORM-модели EFHC Bot.

Только структура таблиц и связи. Без бизнес-логики.

Канон:
- Админские таблицы живут в схеме
  settings.DB_SCHEMA_ADMIN (= efhc_admin).
- Истина структуры БД = ORM (Base.metadata), 0001_init создаёт схемы и
  ORM-таблицы.
"""

from __future__ import annotations

import enum
from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    Index,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import (
    Mapped,
    mapped_column,
    relationship,
    validates,
)
from sqlalchemy.types import Numeric

from ..core.config_core import settings

try:
    from . import Base  # type: ignore
except Exception as exc:  # pragma: no cover
    msg = (
        "Не найден общий Declarative Base. Проверь "
        "backend/app/models/__init__.py и убедись, что он "
        "экспортирует 'Base' (DeclarativeBase)."
    )
    raise ImportError(msg) from exc


ADMIN_SCHEMA = settings.DB_SCHEMA_ADMIN
# канон: админ-таблицы в efhc_admin


class RoleEnum(str, enum.Enum):
    """Роли администратора."""

    SUPERADMIN = "superadmin"
    ADMIN = "admin"
    SUPPORT = "support"
    AUDITOR = "auditor"


class AdminWhitelist(Base):
    """Белый список админов (tg_id обязателен)."""

    __tablename__ = "admin_whitelist"
    __table_args__ = (
        UniqueConstraint("tg_id", name="uq_admin_whitelist_telegram"),
        UniqueConstraint("ton_address", name="uq_admin_whitelist_ton"),
        {"schema": ADMIN_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        autoincrement=True,
        comment="PK записи",
    )

    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
        comment="Telegram ID администратора (уникален)",
    )
    ton_address: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        comment="TON-адрес администратора (user-friendly/Base64url)",
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("true"),
        comment="Статус: активен/заблокирован",
    )
    note: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="Комментарий",
    )
    added_by_tg_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        nullable=True,
        comment="Telegram ID того, кто добавил админа",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда создан (UTC)",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        onupdate=text("timezone('utc', now())"),
        comment="Когда обновлён (UTC)",
    )

    roles: Mapped[List["AdminRole"]] = relationship(
        back_populates="admin",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="AdminRole.created_at.desc()",
        lazy="selectin",
    )
    action_logs: Mapped[List["AdminActionLog"]] = relationship(
        back_populates="admin",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="AdminActionLog.created_at.desc()",
        lazy="selectin",
    )

    __mapper_args__ = {"eager_defaults": True}

    @validates("ton_address")
    def _validate_ton_address(
        self,
        key: str,
        value: Optional[str],
    ) -> Optional[str]:
        if value is None:
            return None
        val = value.strip()
        if not val:
            return None
        if not settings.is_valid_ton_address(val):
            raise ValueError(
                "Некорректный TON-адрес в AdminWhitelist. "
                "Проверь формат EQ/UQ."
            )
        return val

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<AdminWhitelist id={self.id} tg_id={self.tg_id} "
            f"active={self.is_active} ton={self.ton_address!r}>"
        )


Index(
    "ix_admin_whitelist_created_at",
    AdminWhitelist.created_at.desc(),
)


class AdminRole(Base):
    """Роль администратора (много ролей на одного админа)."""

    __tablename__ = "admin_role"
    __table_args__ = (
        UniqueConstraint("admin_id", "role", name="uq_admin_role_pair"),
        {"schema": ADMIN_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        autoincrement=True,
        comment="PK записи роли",
    )
    admin_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{ADMIN_SCHEMA}.admin_whitelist.id",
            ondelete="CASCADE",
            onupdate="CASCADE",
            name="fk_admin_role_admin",
        ),
        nullable=False,
        index=True,
        comment="FK → AdminWhitelist.id",
    )
    role: Mapped[RoleEnum] = mapped_column(
        Enum(RoleEnum, name="enum_admin_role", create_constraint=True),
        nullable=False,
        comment="Название роли",
    )
    granted_by_tg_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        nullable=True,
        comment="Кто назначил (Telegram ID)",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда назначена роль (UTC)",
    )

    admin: Mapped["AdminWhitelist"] = relationship(
        back_populates="roles",
        lazy="joined",
    )

    __mapper_args__ = {"eager_defaults": True}

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<AdminRole id={self.id} admin_id={self.admin_id} "
            f"role={self.role}>"
        )


Index(
    "ix_admin_role_created_at",
    AdminRole.created_at.desc(),
)


class AdminActionLog(Base):
    """Аудит действий администраторов."""

    __tablename__ = "admin_action_log"
    __table_args__ = ({"schema": ADMIN_SCHEMA},)

    id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        autoincrement=True,
        comment="PK записи лога",
    )

    admin_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{ADMIN_SCHEMA}.admin_whitelist.id",
            ondelete="SET NULL",
            onupdate="CASCADE",
            name="fk_admin_action_log_admin",
        ),
        nullable=True,
        index=True,
        comment="FK → AdminWhitelist.id (может быть NULL)",
    )

    action: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        index=True,
        comment="Короткое имя действия",
    )
    target_type: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
        comment="Тип цели",
    )
    target_id: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        index=True,
        comment="Идентификатор цели",
    )

    details_json: Mapped[Optional[dict]] = mapped_column(
        JSONB,
        nullable=True,
        comment="Подробности действия в JSON",
    )

    ip: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="IP-адрес источника (если известен)",
    )
    user_agent: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="User-Agent клиента (если известен)",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда зафиксировано действие (UTC)",
    )

    admin: Mapped[Optional["AdminWhitelist"]] = relationship(
        back_populates="action_logs",
        lazy="joined",
    )

    __mapper_args__ = {"eager_defaults": True}

    def __repr__(self) -> str:  # pragma: no cover
        tgt = f"{self.target_type}:{self.target_id}"
        return (
            f"<AdminActionLog id={self.id} admin_id={self.admin_id} "
            f"action={self.action} target={tgt}>"
        )


Index(
    "ix_admin_action_log_created_at",
    AdminActionLog.created_at.desc(),
)
Index(
    "ix_admin_action_log_action_type",
    AdminActionLog.action,
    AdminActionLog.target_type,
)



class BankBalanceRow(Base):
    """Баланс банка EFHC (админская таблица bank_balances)."""

    __tablename__ = "bank_balances"
    __table_args__ = (
        {"schema": ADMIN_SCHEMA},
    )

    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        comment="Логический tg_id банка (BANK_TG_ID)",
    )

    efhc_balance: Mapped[Decimal] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        server_default=text("0"),
        comment="Баланс EFHC банка (d8)",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Создано (UTC)",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        onupdate=text("timezone('utc', now())"),
        comment="Обновлено (UTC)",
    )

    __mapper_args__ = {"eager_defaults": True}

class IdempotencyKey(Base):
    """Ключи идемпотентности для опасных операций."""

    __tablename__ = "idempotency_key"
    __table_args__ = (
        UniqueConstraint("key", name="uq_idempotency_key_key"),
        {"schema": ADMIN_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        autoincrement=True,
        comment="PK записи ключа",
    )

    key: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        comment="Уникальный идемпотентный ключ (или его хэш)",
    )
    scope: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
        comment="Область применения ключа",
    )
    request_fingerprint: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        comment="Хэш входных данных запроса",
    )

    used: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("false"),
        index=True,
        comment="Признак, что ключ уже использован",
    )
    response_code: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        nullable=True,
        comment="Код результата первой обработки",
    )
    response_payload_json: Mapped[Optional[dict]] = mapped_column(
        JSONB,
        nullable=True,
        comment="Часть ответа первой обработки",
    )

    admin_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{ADMIN_SCHEMA}.admin_whitelist.id",
            ondelete="SET NULL",
            onupdate="CASCADE",
            name="fk_idempotency_key_admin",
        ),
        nullable=True,
        index=True,
        comment="FK → AdminWhitelist.id (если из админки)",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда создан ключ (UTC)",
    )
    expires_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        index=True,
        comment="Когда ключ истекает (UTC)",
    )

    __mapper_args__ = {"eager_defaults": True}

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<IdempotencyKey id={self.id} key={self.key} "
            f"scope={self.scope} used={self.used} "
            f"admin_id={self.admin_id}>"
        )


# ----------------------------------------------------------------------
# EFHC sale packages (pricing для deposit_efhc)
# ----------------------------------------------------------------------


class EFHCSalePackage(Base):
    """Админ-таблица прайс-пакетов продажи EFHC.

    Требуется сервисом:
    backend/app/services/admin/admin_sale_packages_service.py
    (SELECT/INSERT/UPDATE в efhc_admin.efhc_sale_packages).
    """

    __tablename__ = "efhc_sale_packages"
    __table_args__ = ({"schema": ADMIN_SCHEMA},)

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="PK пакета",
    )

    title: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        comment="Название пакета",
    )

    asset: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        server_default=text("'TON'"),
        comment="Актив цены (TON/USDT и т.п.)",
    )

    price_asset_d8: Mapped[Decimal] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        comment="Цена в asset (scale=8)",
    )

    efhc_amount_d8: Mapped[Decimal] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        comment="Сколько EFHC выдаём (scale=8)",
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("true"),
        comment="Активен ли пакет",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда создан (UTC)",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        onupdate=text("timezone('utc', now())"),
        comment="Когда обновлён (UTC)",
    )


Index(
    "ix_idempotency_key_expiry",
    IdempotencyKey.expires_at,
)
Index(
    "ix_idempotency_key_scope_used",
    IdempotencyKey.scope,
    IdempotencyKey.used,
)


__all__ = [
    "RoleEnum",
    "AdminWhitelist",
    "AdminRole",
    "AdminActionLog",
    "IdempotencyKey",
    "EFHCSalePackage",
]
