# -*- coding: utf-8 -*-
"""Wallet models (TonConnect bindings).

SSOT:
- User identifier is tg_id only.
- Wallet connected := at least one active wallet binding.

Notes:
- We keep this model separate from legacy user.ton_wallet.
"""

from __future__ import annotations

from sqlalchemy import Boolean, DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..models.base import Base


class WalletBinding(Base):
    """TON wallet binding for a Telegram user (tg_id)."""

    __tablename__ = "wallet_bindings"

    id: Mapped[int] = mapped_column(primary_key=True)
    tg_id: Mapped[int] = mapped_column(index=True)
    wallet_address: Mapped[str] = mapped_column(Text, unique=True)
    wallet_app: Mapped[str | None] = mapped_column(String(32))

    is_primary: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="true",
    )

    created_at: Mapped[object] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[object] = mapped_column(DateTime(timezone=True))
