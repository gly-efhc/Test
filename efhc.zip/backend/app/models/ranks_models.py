# backend/app/models/ranks_models.py
"""ORM-модели рейтинга с единственным владельцем ``global_id``."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import Numeric

from ..core.config_core import get_settings
from ..core.sql_aliases_core import canon_schema
from .base import Base

settings = get_settings()
CORE_SCHEMA = canon_schema(settings.DB_SCHEMA_CORE)


class RanksSnapshot(Base):
    """Историческая строка рейтинга canonical account owner."""

    __tablename__ = "ranks_snapshots"
    __table_args__ = (
        UniqueConstraint(
            "snapshot_at",
            "global_id",
            name="uq_ranks_snapshot_global_at",
        ),
        CheckConstraint(
            "global_id BETWEEN 1 AND 9999999999",
            name="ck_ranks_snapshot_global_id_range",
        ),
        CheckConstraint(
            "total_generated_kwh >= 0",
            name="ck_ranks_snapshot_total_nonneg",
        ),
        CheckConstraint(
            "rank_position >= 1",
            name="ck_ranks_snapshot_rank_pos",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    snapshot_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        index=True,
    )
    global_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{CORE_SCHEMA}.users.global_id",
            name="fk_ranks_snapshot_global_users_global_id",
            onupdate="RESTRICT",
            ondelete="RESTRICT",
        ),
        nullable=False,
        index=True,
    )
    rank_position: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        index=True,
    )
    total_generated_kwh: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
    )
    meta: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


Index(
    "ix_ranks_snapshots_at_pos_global",
    RanksSnapshot.snapshot_at,
    RanksSnapshot.rank_position,
    RanksSnapshot.global_id,
    postgresql_using="btree",
)


class RanksTopCache(Base):
    """Материализованный TOP-N по canonical ``global_id``."""

    __tablename__ = "ranks_top_cache"
    __table_args__ = (
        UniqueConstraint(
            "bucket",
            "snapshot_at",
            "global_id",
            name="uq_ranks_top_global_at_bucket",
        ),
        UniqueConstraint(
            "bucket",
            "snapshot_at",
            "rank_position",
            name="uq_ranks_top_pos_at_bucket",
        ),
        CheckConstraint(
            "global_id BETWEEN 1 AND 9999999999",
            name="ck_ranks_top_global_id_range",
        ),
        CheckConstraint(
            "total_generated_kwh >= 0",
            name="ck_ranks_top_total_nonneg",
        ),
        CheckConstraint(
            "rank_position >= 1",
            name="ck_ranks_top_rank_pos",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    bucket: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        index=True,
        default="global_top_100",
        server_default="global_top_100",
    )
    snapshot_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        index=True,
    )
    global_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{CORE_SCHEMA}.users.global_id",
            name="fk_ranks_top_global_users_global_id",
            onupdate="RESTRICT",
            ondelete="RESTRICT",
        ),
        nullable=False,
        index=True,
    )
    rank_position: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        index=True,
    )
    total_generated_kwh: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
    )
    meta: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


Index(
    "ix_ranks_top_cache_bucket_at_pos_global",
    RanksTopCache.bucket,
    RanksTopCache.snapshot_at,
    RanksTopCache.rank_position,
    RanksTopCache.global_id,
    postgresql_using="btree",
)


class RanksUserSnapshot(Base):
    """Совместимая строка scheduler-снапшота по ``global_id``."""

    __tablename__ = "ranks_user_snapshots"
    __table_args__ = (
        UniqueConstraint(
            "snapshot_id",
            "global_id",
            name="uq_ranks_user_snapshot_global",
        ),
        CheckConstraint(
            "global_id BETWEEN 1 AND 9999999999",
            name="ck_ranks_user_snapshot_global_id_range",
        ),
        CheckConstraint(
            "total_generated_kwh >= 0",
            name="ck_ranks_user_snapshot_total_nonneg",
        ),
        CheckConstraint(
            "rank_position >= 1",
            name="ck_ranks_user_snapshot_rank_pos",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    snapshot_id: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        index=True,
    )
    global_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{CORE_SCHEMA}.users.global_id",
            name="fk_ranks_user_snapshot_global_users_global_id",
            onupdate="RESTRICT",
            ondelete="RESTRICT",
        ),
        nullable=False,
        index=True,
    )
    username: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )
    total_generated_kwh: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
    )
    rank_position: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        index=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )


__all__ = ["RanksSnapshot", "RanksTopCache", "RanksUserSnapshot"]
