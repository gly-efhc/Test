"""backend/app/models/skins_models.py

ORM модели домена «Skins» (картинки/скины) EFHC Bot.

Таблицы создаются миграцией 20260223_0012_skins_tables.py:
- user_skins
- user_cosmetics
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Index,
    Integer,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column

from ..core.config_core import get_settings
from ..core.sql_aliases_core import canon_schema
from .base import Base

settings = get_settings()
CORE_SCHEMA = canon_schema(settings.DB_SCHEMA_CORE)


class UserSkin(Base):
    __tablename__ = "user_skins"
    __table_args__ = (
        UniqueConstraint("tg_id", "skin_id", name="uq_user_skins_one"),
        Index("ix_user_skins_tg_id", "tg_id"),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    skin_id: Mapped[int] = mapped_column(Integer, nullable=False)
    purchased_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )


class UserCosmetics(Base):
    __tablename__ = "user_cosmetics"
    __table_args__ = (
        UniqueConstraint("tg_id", name="uq_user_cosmetics_one"),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    active_skin_id: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
