from __future__ import annotations

# Совместимый shim для старого пути app.models.wallet_models.
from sqlalchemy import literal
from sqlalchemy.orm import column_property

from .wallets_models import WalletBinding

# Старый код ожидает поле asset_type для выбора TON-кошелька.
# В текущем каноне wallet_bindings хранят только TON-привязки,
# поэтому совместимо объявляем его как константное выражение.
WalletBinding.asset_type = column_property(literal("TON"))

UserWallet = WalletBinding

__all__ = ["WalletBinding", "UserWallet"]
