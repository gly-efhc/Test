# -*- coding: utf-8 -*-
# backend/app/models/__init__.py
# ======================================================================
# Единая точка входа слоя ORM-моделей EFHC Bot.
#
# Важно (канон):
# - Модели описывают структуру данных. Бизнес-логика и денежные операции
#   (hold/refund/commit/начисления/списания/efhc_transfers_log) — ТОЛЬКО
#   через services/transactions_service.py.
# - Никаких DDL/DML, create_all(), миграций, сессий и т.п. в этом
# модуле.
# - Alembic в CI запускается из каталога backend/ (верхний пакет = app),
#   поэтому здесь используются app.* импорты.
#
# Этот файл также экспортирует TimestampMixin, потому что часть моделей
# импортирует его через "from . import Base, TimestampMixin".
# ======================================================================

from __future__ import annotations

import importlib
import inspect
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Tuple, Type

from sqlalchemy import DateTime, text
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    declarative_mixin,
    mapped_column,
)

from app.core.config_core import get_settings
from app.core.logging_core import get_logger


logger = get_logger(__name__)
settings = get_settings()

# Каноническая основная схема (в большинстве таблиц проекта).
SCHEMA: str = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


class Base(DeclarativeBase):
    """Единый Declarative Base проекта.

    Важно: Base не должен тянуть инициализацию движка/сессии.
    """


@declarative_mixin
class TimestampMixin:
    """Примесь created_at / updated_at (UTC, tz-aware)."""

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда запись создана (UTC).",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        onupdate=text("timezone('utc', now())"),
        comment="Когда запись обновлена (UTC).",
    )


# ----------------------------------------------------------------------
# Автоподключение модулей с моделями.
# ----------------------------------------------------------------------
# Примечание: исторически встречались разные имена файлов (ед/мн.
# число).
# Чтобы не «ронять» импорт при неполном наборе моделей, пробуем
# варианты.
_MODEL_MODULE_CANDIDATES: List[str] = [
    # ядро пользователей/транзакций/TON-логов
    "user_models",
    "transactions_models",
    "ton_logs_models",

    "bank_balance_models",
    "settings_models",
    # панели/архив/ранги/скины/достижения/вывод
    "panels_models",
    "ranks_models",
    "skins_models",
    "achievements_models",
    "withdraw_models",
    # рефералы
    "referral_models",
    "referral_codes_models",
    # магазин/заказы/платёжные интенты/лотереи
    "shop_models",
    "order_models",
    "payment_intents_models",
    "lotteries_models",
    # задачи/планировщик/внешние события
    "tasks_models",
    "scheduler_models",
    "external_events_models",
    # админ-таблицы/кошельки/реклама
    "admin_models",
    "wallets_models",
    "ads_models",
]


def _safe_import(module_name: str):
    """Импортирует app.models.<module_name>.

    При ошибке возвращает None (не «роняем» процесс на неполном наборе).
    """

    full = f"app.models.{module_name}"
    try:
        mod = importlib.import_module(full)
        logger.debug("models: imported %s", full)
        return mod
    except Exception as exc:  # pragma: no cover
        logger.debug("models: skip %s (%s)", full, exc)
        return None


def _collect_model_classes(module) -> Dict[str, Type[Base]]:
    """Возвращает {ClassName: Class} для моделей SQLAlchemy.

    Критерий: подкласс Base + объявлен __tablename__.
    """

    registry: Dict[str, Type[Base]] = {}
    if not module:
        return registry

    for name, obj in vars(module).items():
        if not inspect.isclass(obj):
            continue
        try:
            is_model = issubclass(obj, Base)
        except Exception:
            continue
        if is_model and hasattr(obj, "__tablename__"):
            registry[name] = obj

    return registry


# ----------------------------------------------------------------------
# Строим глобальный реестр моделей.
# ----------------------------------------------------------------------
MODEL_REGISTRY: Dict[str, Type[Base]] = {}
MODEL_MODULES_LOADED: List[str] = []

for candidate in _MODEL_MODULE_CANDIDATES:
    mod = _safe_import(candidate)
    if not mod:
        continue
    classes = _collect_model_classes(mod)
    if classes:
        MODEL_REGISTRY.update(classes)
        MODEL_MODULES_LOADED.append(candidate)


def get_model(name: str) -> Optional[Type[Base]]:
    """Возвращает класс модели по имени Python-класса."""

    return MODEL_REGISTRY.get(name)


def list_models() -> List[Tuple[str, str]]:
    """Список (ClassName, __tablename__) по registry."""

    out: List[Tuple[str, str]] = []
    for cls_name, cls in sorted(
        MODEL_REGISTRY.items(),
        key=lambda kv: kv[0].lower(),
    ):
        out.append((cls_name, getattr(cls, "__tablename__", "?")))
    return out


def models_health() -> Dict[str, object]:
    """Минимальная диагностика полноты набора моделей."""

    required_class_names = [
        "User",
        "EFHCTransferLog",
        "TonInboxLog",
        "Panel",
        "PanelArchive",
        "ShopOrder",
    ]

    present_pairs = list_models()
    present_classes = {cls for cls, _ in present_pairs}
    missing_classes = [
        rc for rc in required_class_names
        if rc not in present_classes
    ]

    ok = len(missing_classes) == 0
    report = {
        "ok": ok,
        "missing_classes": missing_classes,
        "loaded_modules": list(MODEL_MODULES_LOADED),
        "present": present_pairs,
        "schema": SCHEMA,
    }

    if not ok:
        logger.warning("models_health: missing=%s", missing_classes)
    else:
        logger.info(
            "models_health: OK, %d models in %d modules",
            len(present_pairs),
            len(MODEL_MODULES_LOADED),
        )
    return report


__all__ = [
    "Base",
    "TimestampMixin",
    "SCHEMA",
    "MODEL_REGISTRY",
    "MODEL_MODULES_LOADED",
    "get_model",
    "list_models",
    "models_health",
]
