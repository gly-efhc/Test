"""Idempotent creation of required EFHC system data."""

from __future__ import annotations

import os
from decimal import Decimal

from app.release.database_connection import connect
from psycopg2.extras import Json

BANK_BALANCE = Decimal("5000000.00000000")
MIN_SYSTEM_BANK_ID = 900_000_000_000_000_000

SYSTEM_MANAGED_HUB_LINKS: dict[str, dict[str, object]] = {
    "efhc_buy": {
        "title": "Hub EFHC",
        "subtitle": "External buy-flow handoff for EFHC.",
        "url": "/hub/efhc-handoff",
        "target_kind": "backend_handoff",
        "open_mode": "same_app",
        "sort_order": 10,
        "is_active": True,
        "icon_key": "efhc",
    },
    "vip_getgems": {
        "title": "Hub VIP",
        "subtitle": "Open VIP NFT collection on GetGems.",
        "url": "https://getgems.io/efhc-nft",
        "target_kind": "external_url",
        "open_mode": "external_browser",
        "sort_order": 20,
        "is_active": True,
        "icon_key": "vip",
    },
}
# Every code not listed above is user-managed.
# Seed never changes it.
USER_MANAGED_HUB_LINK_CODES: frozenset[str] = frozenset()


def _bank_id() -> int:
    raw = os.environ.get("BANK_EFHC", "").strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError(
            "BANK_EFHC must be a reserved system user ID >= "
            f"{MIN_SYSTEM_BANK_ID}"
        ) from exc
    if value < MIN_SYSTEM_BANK_ID:
        raise RuntimeError(
            "BANK_EFHC must be a reserved system user ID >= "
            f"{MIN_SYSTEM_BANK_ID}"
        )
    return value


def seed_initial_data() -> dict[str, object]:
    """Insert only missing system rows; never reset user data."""
    bank_id = _bank_id()
    scheduler_defaults = {
        "scheduler.enabled": "true",
        "scheduler.ton_reconcile_tick_counter": "0",
        "scheduler.ton_reconcile_last_success_at": "",
        "ranks.last_snapshot_at": "",
        "ranks.total_users": "0",
    }
    templates = {
        "task_reject_fallback": (
            "Выполнение не подтверждено.",
            "Автоответ при отклонении задания",
        ),
        "task_approve_fallback": (
            None,
            "Автоответ при одобрении задания",
        ),
    }
    with connect() as conn, conn.cursor() as cur:
        cur.execute(
            "INSERT INTO efhc_core.users ("
            "tg_id, username, is_active, is_vip, "
            "main_balance, bonus_balance, "
            "total_generated_kwh, exchanged_kwh_total, meta"
            ") VALUES (%s, %s, false, false, 0, 0, 0, 0, %s) "
            "ON CONFLICT (tg_id) DO NOTHING",
            (
                bank_id,
                "BANK_EFHC",
                Json(
                    {
                        "system": True,
                        "kind": "bank_account",
                    }
                ),
            ),
        )
        cur.execute(
            "INSERT INTO efhc_core.bank_balance "
            "(key, balance) VALUES (%s, %s) "
            "ON CONFLICT (key) DO NOTHING",
            ("EFHC_MAIN", BANK_BALANCE),
        )
        for key, value in scheduler_defaults.items():
            cur.execute(
                "INSERT INTO efhc_core.app_settings "
                "(key, value) VALUES (%s, %s) "
                "ON CONFLICT (key) DO NOTHING",
                (key, value),
            )
        for key, (content, description) in templates.items():
            cur.execute(
                "INSERT INTO efhc_core.system_templates "
                "(key, content, description) "
                "VALUES (%s, %s, %s) "
                "ON CONFLICT (key) DO NOTHING",
                (key, content, description),
            )
        for code, row in SYSTEM_MANAGED_HUB_LINKS.items():
            cur.execute(
                "INSERT INTO efhc_core.hub_links "
                "(code, title, subtitle, url, target_kind, open_mode, "
                "is_active, sort_order, icon_key) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
                "ON CONFLICT (code) DO UPDATE SET "
                "title = EXCLUDED.title, "
                "subtitle = EXCLUDED.subtitle, "
                "url = EXCLUDED.url, "
                "target_kind = EXCLUDED.target_kind, "
                "open_mode = EXCLUDED.open_mode, "
                "is_active = EXCLUDED.is_active, "
                "sort_order = EXCLUDED.sort_order, "
                "icon_key = EXCLUDED.icon_key",
                (
                    code,
                    row["title"],
                    row["subtitle"],
                    row["url"],
                    row["target_kind"],
                    row["open_mode"],
                    row["is_active"],
                    row["sort_order"],
                    row["icon_key"],
                ),
            )
        conn.commit()

    return {
        "bank_efhc": bank_id,
        "settings": len(scheduler_defaults),
        "templates": len(templates),
        "hub_links": len(SYSTEM_MANAGED_HUB_LINKS),
        "status": "ok",
    }


def validate_initial_data() -> dict[str, object]:
    """Ensure required rows exist after idempotent seeding."""
    bank_id = _bank_id()
    with connect() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM efhc_core.users "
            "WHERE tg_id = %s AND username = 'BANK_EFHC'",
            (bank_id,),
        )
        if int(cur.fetchone()[0]) != 1:
            raise RuntimeError("BANK_EFHC system user is missing")
        cur.execute(
            "SELECT COUNT(*) FROM efhc_core.bank_balance "
            "WHERE key = 'EFHC_MAIN'"
        )
        if int(cur.fetchone()[0]) != 1:
            raise RuntimeError("EFHC_MAIN bank balance is missing")
    return {"status": "ok", "bank_efhc": bank_id}
