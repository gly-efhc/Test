from __future__ import annotations

from collections.abc import Awaitable, Callable

from fastapi import Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp

_SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": (
        "camera=(), microphone=(), geolocation=()"
    ),
    "Content-Security-Policy": (
        "default-src 'none'; base-uri 'none'; object-src 'none'; "
        "frame-ancestors 'none'; form-action 'none'"
    ),
}


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Adds security headers and rejects oversized bodies."""

    def __init__(
        self,
        app: ASGIApp,
        *,
        environment: str = "local",
        max_request_body_bytes: int = 1_048_576,
    ) -> None:
        super().__init__(app)
        self.environment = str(environment or "local").lower()
        self.max_request_body_bytes = max(
            1,
            int(max_request_body_bytes),
        )

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        content_length = request.headers.get(
            "content-length",
            "",
        ).strip()
        if content_length:
            try:
                body_bytes = int(content_length)
            except ValueError:
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={
                        "detail": "Invalid Content-Length header.",
                    },
                )
            if body_bytes > self.max_request_body_bytes:
                return JSONResponse(
                    status_code=status.HTTP_413_CONTENT_TOO_LARGE,
                    content={"detail": "Request body is too large."},
                )

        response = await call_next(request)
        for key, value in _SECURITY_HEADERS.items():
            response.headers.setdefault(key, value)
        if self.environment in {"prod", "stage", "staging"}:
            response.headers.setdefault(
                "Strict-Transport-Security",
                "max-age=31536000; includeSubDomains",
            )
        path = request.url.path or "/"
        if path.startswith(("/api", "/meta", "/health")):
            response.headers.setdefault("Cache-Control", "no-store")
        return response
