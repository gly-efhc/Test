# backend/app/middleware/init.py

"""Middleware package (канон EFHC Bot)."""

__all__ = []
