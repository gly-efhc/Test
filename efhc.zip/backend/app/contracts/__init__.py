"""
SSOT contracts package.

Contracts here define *interfaces* between routes/handlers and services.
No runtime side effects in package initialization.
"""

__all__: list[str] = []
