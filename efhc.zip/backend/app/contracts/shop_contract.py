# backend/app/contracts/shop_contract.py

from __future__ import annotations

from typing import Protocol

from app.schemas.shop_schemas import (
    ShopOrderExternalIn,
    ShopOrderExternalOut,
    ShopPurchaseByEFHCIn,
    ShopPurchaseByEFHCOut,
)


class ShopContract(Protocol):
    async def get_catalog(self, owner_id: int) -> list[dict]:
        """Каталог Shop для пользователя."""

    async def create_external_order(
        self,
        tg_id: int,
        payload: ShopOrderExternalIn,
        client_nonce: str | None,
    ) -> ShopOrderExternalOut:
        """Создать внешний заказ (оплата TON/USDT)."""

    async def purchase_by_efhc(
        self,
        tg_id: int,
        payload: ShopPurchaseByEFHCIn,
        idempotency_key: str,
    ) -> ShopPurchaseByEFHCOut:
        """Покупка за EFHC (движение через банк)."""


    async def list_orders_by_owner(
        self,
        global_id: int,
        legacy_tg_id: int | None,
        use_global_id: bool,
        limit: int,
        cursor: str | None,
    ) -> dict:
        """Список заказов по canonical owner с rollback seam."""

    async def list_orders(
        self,
        tg_id: int,
        limit: int,
        cursor: str | None,
    ) -> dict:
        """Список заказов пользователя (пагинация)."""
