# -*- coding: utf-8 -*-
# backend/app/contracts/shop_contract.py

from __future__ import annotations

from typing import List, Optional, Protocol

from backend.app.schemas.shop_schemas import (
    ShopOrderExternalIn,
    ShopOrderExternalOut,
    ShopPurchaseByEFHCIn,
    ShopPurchaseByEFHCOut,
)


class ShopContract(Protocol):
    async def get_catalog(self, tg_id: int) -> List[dict]:
        """Каталог Shop для пользователя."""

    async def create_external_order(
        self,
        tg_id: int,
        payload: ShopOrderExternalIn,
        client_nonce: Optional[str],
    ) -> ShopOrderExternalOut:
        """Создать внешний заказ (оплата TON/USDT)."""

    async def purchase_by_efhc(
        self,
        tg_id: int,
        payload: ShopPurchaseByEFHCIn,
        idempotency_key: str,
    ) -> ShopPurchaseByEFHCOut:
        """Покупка за EFHC (движение через банк)."""

    async def list_orders(
        self,
        tg_id: int,
        limit: int,
        cursor: Optional[str],
    ) -> dict:
        """Список заказов пользователя (пагинация)."""
