# -*- coding: utf-8 -*-
# backend/app/contracts/lotteries_contract.py
# ======================================================================
# SSOT контракт подсистемы lotteries: routes ↔ services.
# ======================================================================

from __future__ import annotations

from typing import Any, Dict, List, Optional, Protocol, Tuple

from sqlalchemy.ext.asyncio import AsyncSession


class LotteriesContract(Protocol):
    """Контракт сервисного слоя lotteries.

    Инварианты:
      • Cursor SSOT: cursor payload всегда dict.
      • Публичный слой: tg_id only.
    """

    async def list_active_lotteries(
        self,
        db: AsyncSession,
        *,
        limit: int,
        cursor: Optional[Dict[str, Any]] = None,
    ) -> Tuple[List[Dict[str, Any]], Optional[Dict[str, Any]]]:
        ...

    async def get_lotteries_status(
        self,
        db: AsyncSession,
        *,
        lotteries_id: int,
    ) -> Optional[Dict[str, Any]]:
        ...

    async def list_user_tickets(
        self,
        db: AsyncSession,
        *,
        lotteries_id: int,
        tg_id: int,
        limit: int,
        cursor: Optional[Dict[str, Any]] = None,
    ) -> Tuple[List[int], Optional[Dict[str, Any]]]:
        ...

    async def buy_tickets(
        self,
        db: AsyncSession,
        *,
        lotteries_id: int,
        tg_id: int,
        qty: int,
        idempotency_key: str,
    ) -> Dict[str, Any]:
        ...
