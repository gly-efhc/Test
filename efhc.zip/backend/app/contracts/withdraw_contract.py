# -*- coding: utf-8 -*-
# backend/app/contracts/withdraw_contract.py

from __future__ import annotations

from typing import Optional, Protocol

from backend.app.schemas.withdraw_schemas import (
    WithdrawCreateIn,
    WithdrawListOut,
    WithdrawPublicOut,
)


class WithdrawContract(Protocol):
    """Интерфейс withdraw-контура.

    Учёт заявок + hold/refund через transactions_service.
    """

    async def request_withdraw(
        self,
        tg_id: int,
        payload: WithdrawCreateIn,
        idempotency_key: str,
    ) -> WithdrawPublicOut:
        """Создаёт заявку на вывод и выполняет hold."""

    async def list_withdraws(
        self,
        tg_id: int,
        limit: int,
        cursor: Optional[str],
    ) -> WithdrawListOut:
        """Возвращает список заявок пользователя."""
