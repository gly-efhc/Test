# -*- coding: utf-8 -*-
# backend/app/contracts/admin_contract.py
# ======================================================================
# SSOT контракт admin-контура: routes ↔ services.
# Контракт привязан к фасаду:
# backend.app.services.admin.admin_facade.AdminService.
# ======================================================================

from __future__ import annotations

from typing import Any, Dict, List, Optional, Protocol

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.admin.admin_facade import (
    AdminUser,
    BankBalanceDTO,
    BonusPayoutFilters,
    CoinsStats,
    CreateLotteriesRequest,
    LotteriesInfo,
    LotteriestatusSummary,
    ManualBankTransferRequest,
    MintBurnRequest,
    Pagination,
    PanelsStats,
    PrizeClaimFilters,
    ReferralsStats,
    ShopStats,
    SystemSetting,
    SystemStats,
    UpdateLotteriesRequest,
    UserProgressSnapshot,
    WinnerTicket,
    WithdrawFilters,
    WithdrawRequestAdminDTO,
)


class AdminContract(Protocol):
    async def resolve_admin(
        self,
        db: AsyncSession,
        tg_id: int,
    ) -> AdminUser:
        ...

    async def list_admin_logs(
        self,
        db: AsyncSession,
        *,
        pg: Pagination,
        q: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        ...

    async def get_setting(
        self,
        db: AsyncSession,
        key: str,
    ) -> Optional[SystemSetting]:
        ...

    async def mget_settings(
        self,
        db: AsyncSession,
        keys: List[str],
    ) -> List[SystemSetting]:
        ...

    async def set_setting(
        self,
        db: AsyncSession,
        key: str,
        value: str,
        admin: AdminUser,
    ) -> None:
        ...

    async def mset_settings(
        self,
        db: AsyncSession,
        items: Dict[str, str],
        admin: AdminUser,
    ) -> None:
        ...

    async def get_bank_balance(
        self,
        db: AsyncSession,
    ) -> BankBalanceDTO:
        ...

    async def mint_efhc(
        self,
        db: AsyncSession,
        req: MintBurnRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        ...

    async def burn_efhc(
        self,
        db: AsyncSession,
        req: MintBurnRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        ...

    async def manual_bank_to_user(
        self,
        db: AsyncSession,
        req: ManualBankTransferRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        ...

    async def manual_user_to_bank(
        self,
        db: AsyncSession,
        req: ManualBankTransferRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        ...

    async def create_lotteries(
        self,
        db: AsyncSession,
        req: CreateLotteriesRequest,
        admin: AdminUser,
    ) -> int:
        ...

    async def update_lotteries(
        self,
        db: AsyncSession,
        lotteries_id: int,
        req: UpdateLotteriesRequest,
        admin: AdminUser,
    ) -> None:
        ...

    async def list_lotteries(
        self,
        db: AsyncSession,
        pg: Pagination,
    ) -> List[LotteriesInfo]:
        ...

    async def lotteries_lotteries(
        self,
        db: AsyncSession,
        lotteries_id: int,
        admin: AdminUser,
    ) -> Optional[WinnerTicket]:
        ...

    async def lotteries_status_summary(
        self,
        db: AsyncSession,
    ) -> LotteriestatusSummary:
        ...

    async def get_coins_stats(
        self,
        db: AsyncSession,
    ) -> CoinsStats:
        ...

    async def get_panels_stats(
        self,
        db: AsyncSession,
    ) -> PanelsStats:
        ...

    async def get_referrals_stats(
        self,
        db: AsyncSession,
    ) -> ReferralsStats:
        ...

    async def get_shop_stats(
        self,
        db: AsyncSession,
    ) -> ShopStats:
        ...

    async def get_system_stats(
        self,
        db: AsyncSession,
    ) -> SystemStats:
        ...

    async def debug_user_progress_by_telegram(
        self,
        db: AsyncSession,
        tg_id: int,
    ) -> UserProgressSnapshot:
        ...

    async def list_withdraw_requests(
        self,
        db: AsyncSession,
        pg: Pagination,
        filters: WithdrawFilters,
    ) -> List[WithdrawRequestAdminDTO]:
        ...

    async def admin_approve_withdraw(
        self,
        db: AsyncSession,
        withdraw_id: int,
        admin: AdminUser,
    ) -> None:
        ...

    async def admin_reject_withdraw(
        self,
        db: AsyncSession,
        withdraw_id: int,
        reason: str,
        admin: AdminUser,
    ) -> None:
        ...

    async def admin_mark_withdraw_paid(
        self,
        db: AsyncSession,
        withdraw_id: int,
        tx_hash: str,
        admin: AdminUser,
    ) -> None:
        ...

    async def list_bonus_payouts(
        self,
        db: AsyncSession,
        pg: Pagination,
        filters: BonusPayoutFilters,
    ) -> List[Dict[str, Any]]:
        ...

    async def list_prize_claims(
        self,
        db: AsyncSession,
        pg: Pagination,
        filters: PrizeClaimFilters,
    ) -> List[Dict[str, Any]]:
        ...

    async def mark_prize_claim_done(
        self,
        db: AsyncSession,
        claim_id: int,
        admin: AdminUser,
        tx_hash: str,
    ) -> None:
        ...

    async def reject_prize_claim(
        self,
        db: AsyncSession,
        claim_id: int,
        admin: AdminUser,
        reason: str,
    ) -> None:
        ...
