# backend/app/bot/states.py
# ======================================================================
# Назначение кода:
# Дерево состояний (FSM) и менеджер состояний для Telegram-бота EFHC.
# Позволяет «помнить», на каком шаге находится пользователь (например,
# ожидание доказательства задания, количества элементов
# участия и т. п.).
#
# Канон/инварианты:
# • Денежных операций здесь НЕТ — только навигационная логика бота.
# • Любые реальные списания/начисления выполняются строго в сервисах
# (transactions_service.py и др.) и только через «банк».
# • Состояние не может «исправлять» балансы и не взаимодействует с
# TON/NFT.
#
# ИИ-защита / самовосстановление:
# • Две ступени хранения: внешний backend (опционально) и встроенный
# in-memory fallback. При ошибках внешнего хранилища менеджер не падает
# —
# использует локальную память процесса и пытается «догонять» при
# следующем
# шаге.
# • TTL для разговорных состояний (автосброс по истечении времени
# неактивности).
# • Защита от «перегрева»: лимит размера data (серилизуем только
# JSON-безопасное).
# • Неблокирующий GC (фоновая очистка просроченных ключей).
#
# Запреты:
# • Никаких операций с БД/кошельками/балансами; FSM — только про
# UI-потоки.
# • Никаких скрытых «commit» действий — любые изменения денег строго вне
# FSM.
# ======================================================================

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import (
    Any,
    Protocol,
    runtime_checkable,
)

from app.core.async_tasks import create_logged_task
from app.core.config_core import get_settings
from app.core.logging_core import get_logger

StateKey = tuple[int, int]


logger = get_logger(__name__)
settings = get_settings()

# ======================================================================
# Константы и дефолты (настраиваемые через .env при желании)
# ======================================================================

# TTL разговора: через сколько секунд неактивности состояние будет
# обнулено.
DEFAULT_STATE_TTL_SECONDS: int = int(
    getattr(settings, "BOT_STATE_TTL_SECONDS", 15 * 60) or 900
)
# Период фоновой уборки просроченных записей
DEFAULT_GC_INTERVAL_SECONDS: int = int(
    getattr(settings, "BOT_STATE_GC_INTERVAL", 60) or 60
)
# Максимум безопасного JSON-payload для data (байт после сериализации)
MAX_STATE_DATA_BYTES: int = int(
    getattr(settings, "BOT_STATE_DATA_LIMIT", 4096) or 4096
)

def _now_ts() -> float:
    return time.time()

def _expires_ts() -> float:
    return time.time() + DEFAULT_STATE_TTL_SECONDS


# ======================================================================
# Набор «канонических» имен состояний (расширяем при необходимости)
# ======================================================================


class BotStates:
    """Строчные константы состояний бота (FSM)."""
    IDLE = "idle"  # нет активного шага

    # Задания (Tasks)
    # Задания (Tasks)
    # Ждём от пользователя доказательство выполнения
    TASK_AWAIT_PROOF = "task.await_proof"
    # Ждём ссылку/URL (если задание требует)
    TASK_AWAIT_LINK = "task.await_link"

    # Магазин/оплаты
    # Подсказали формат MEMO, ждём подтверждение/ввод
    SHOP_AWAIT_MEMO = "shop.await_memo"

    # Вывод средств
    # Ждём сумму EFHC для заявки
    WITHDRAW_AWAIT_AMOUNT = "withdraw.await_amount"

    # Админ
    # Ждём текст рассылки
    ADMIN_BROADCAST_TEXT = "admin.broadcast_text"

# ======================================================================
# Модель состояния (в памяти менеджера/адаптера)
# ======================================================================

@dataclass


class ConversationState:
    """
    Единица состояния диалога пользователя.

    state: строковой код (см. BotStates.*)
    data:  произвольный JSON - совместимый словарь (ограничение размера
    см. MAX_STATE_DATA_BYTES)
    updated_at: unix time последнего изменения
    expires_at: unix time, после которого запись считается просроченной
    (GC её чистит)
    """
    state: str = BotStates.IDLE
    data: dict[str, Any] = field(default_factory=dict)
    updated_at: float = field(default_factory=_now_ts)
    expires_at: float = field(default_factory=_expires_ts)

    def is_expired(self, now: float | None = None) -> bool:
        """Метод класса ConversationState.
        Функция `is_expired` выполняет операцию в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `now` (Optional[float]): входной параметр.

        Возвращает:
        - Значение типа/структуры: bool.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        now = now or time.time()
        return now >= (self.expires_at or 0)

    def touch(self, ttl: int | None = None) -> None:
        """Обновляет updated_at/expires_at не меняя состояние/данные."""
        now = time.time()
        self.updated_at = now
        self.expires_at = now + (ttl or DEFAULT_STATE_TTL_SECONDS)

    def as_dict(self) -> dict[str, Any]:
        """Метод класса ConversationState.
        Функция `as_dict` выполняет операцию в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - (нет пользовательских параметров; используются `self/cls`
        и/или контекст запроса)

        Возвращает:
        - Значение типа/структуры: Dict[str, Any].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return {
            "state": self.state,
            "data": self.data,
            "updated_at": self.updated_at,
            "expires_at": self.expires_at,
        }

    @staticmethod

    def from_dict(d: dict[str, Any]) -> ConversationState:
        """Метод класса ConversationState.
        Функция `from_dict` выполняет операцию в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `d` (Dict[str, Any]): входной параметр.

        Возвращает:
        - Значение типа/структуры: "ConversationState".

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return ConversationState(
            state=str(d.get("state") or BotStates.IDLE),
            data=dict(d.get("data") or {}),
            updated_at=float(d.get("updated_at") or time.time()),
            expires_at=float(
                d.get("expires_at")
                or (time.time() + DEFAULT_STATE_TTL_SECONDS)
            ),
        )

# ======================================================================
# Абстракция backend-хранилища состояний
# ======================================================================

@runtime_checkable


class StateBackend(Protocol):
    """Контракт backend-хранилища состояний (например Redis/DB).

    Ключ: (tg_id, chat_id).
    """

    # key: (tg_id, chat_id)
    async def get(
        self,
        key: StateKey,
    ) -> ConversationState | None:
        """Метод класса StateBackend.
        Асинхронная функция `get` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.

        Возвращает:
        - Значение типа/структуры: Optional[ConversationState].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        ...

    async def set(
        self,
        key: StateKey,
        value: ConversationState,
    ) -> None:
        """Метод класса StateBackend.
        Асинхронная функция `set` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.
        - `value` (ConversationState): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        ...

    async def clear(self, key: StateKey) -> None:
        """Метод класса StateBackend.
        Асинхронная функция `clear` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        ...

    async def cleanup(self) -> int:
        """Опционально: удалить просроченные записи.

        Возвращает число удалённых.
        """
        return 0

# ----------------------------------------------------------------------
# Встроенный in-memory backend (процесс-локальный, с TTL и GC)
# ----------------------------------------------------------------------


class MemoryStateBackend:

    def __init__(self) -> None:
        """Метод класса MemoryStateBackend.
        Функция `__init__` выполняет операцию в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - (нет пользовательских параметров; используются `self/cls`
        и/или контекст запроса)

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        self._store: dict[tuple[int, int], ConversationState] = {}
        self._lock = asyncio.Lock()

    async def get(self, key: StateKey) -> ConversationState | None:
        """Метод класса MemoryStateBackend.
        Асинхронная функция `get` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.

        Возвращает:
        - Значение типа/структуры: Optional[ConversationState].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        async with self._lock:
            st = self._store.get(key)
            if not st:
                return None
            if st.is_expired():
                # мягкая очистка при чтении
                self._store.pop(key, None)
                return None
            return st

    async def set(
        self,
        key: StateKey,
        value: ConversationState,
    ) -> None:
        """Метод класса MemoryStateBackend.
        Асинхронная функция `set` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.
        - `value` (ConversationState): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        async with self._lock:
            self._store[key] = value

    async def clear(self, key: StateKey) -> None:
        """Метод класса MemoryStateBackend.
        Асинхронная функция `clear` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        async with self._lock:
            self._store.pop(key, None)

    async def cleanup(self) -> int:
        """Метод класса MemoryStateBackend.
        Асинхронная функция `cleanup` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - (нет пользовательских параметров; используются `self/cls`
        и/или контекст запроса)

        Возвращает:
        - Значение типа/структуры: int.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        async with self._lock:
            now = time.time()
            to_del = [
                k
                for k, v in self._store.items()
                if v.is_expired(now)
            ]
            for k in to_del:
                self._store.pop(k, None)
            return len(to_del)

# ======================================================================
# Менеджер состояний с ИИ-самовосстановлением и fallback
# ======================================================================


class StateManager:
    """
    Высокоуровневый API работы с состояниями:
      • безопасные set/get/clear
      • атомарные переходы (transition), ожидающие текущее состояние
      • обновление data с защитой по лимиту
      • фоновый GC
    """

    def __init__(self, backend: StateBackend | None = None) -> None:
        """Метод класса StateManager.
        Функция `__init__` выполняет операцию в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `backend` (Optional[StateBackend]): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        self._primary = backend  # может быть None (только память)
        self._fallback = MemoryStateBackend()
        self._gc_task: asyncio.Task | None = None
        self._gc_interval = DEFAULT_GC_INTERVAL_SECONDS

    # --------------- утилиты ключей ---------------

    @staticmethod

    def make_key(tg_id: int, chat_id: int) -> tuple[int, int]:
        """Метод класса StateManager.
        Функция `make_key` выполняет операцию в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `tg_id` (int): входной параметр.
        - `chat_id` (int): входной параметр.

        Возвращает:
        - Значение типа/структуры: Tuple[int, int].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return (int(tg_id), int(chat_id))

    # --------------- низкоуровневые операции ---------------

    async def _get(self, key: StateKey) -> ConversationState | None:
        # 1) пытаемся из primary
        """Метод класса StateManager.
        Асинхронная функция `_get` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.

        Возвращает:
        - Значение типа/структуры: Optional[ConversationState].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        if self._primary:
            try:
                st = await self._primary.get(key)
                if st:
                    return st
            except Exception as e:
                logger.warning(
                    "StateManager: primary.get failed, "
                    "fallback used: %s",
                    e,
                )
        # 2) fallback
        return await self._fallback.get(key)

    async def _set(
        self,
        key: StateKey,
        state: ConversationState,
    ) -> None:
        """Метод класса StateManager.
        Асинхронная функция `_set` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.
        - `state` (ConversationState): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        ok_primary = False
        # 1) пытаемся записать в primary
        if self._primary:
            try:
                await self._primary.set(key, state)
                ok_primary = True
            except Exception as e:
                logger.warning(
                    "StateManager: primary.set failed, "
                    "fallback used: %s",
                    e,
                )
        # 2) всегда записываем в fallback (держим «горячую» копию)
        try:
            await self._fallback.set(key, state)
        except Exception as e:
            # Это уже критично: не можем держать даже локально.
            logger.error("StateManager: fallback.set failed: %s", e)
            if ok_primary:
                # хотя бы primary записался — продолжаем
                return
            raise

    async def _clear(self, key: StateKey) -> None:
        """Метод класса StateManager.
        Асинхронная функция `_clear` выполняет операцию в контуре бота
        EFHC.
        Назначение: бизнес‑логика соответствующего модуля (см. имя
        функции и вызывающий код).

        Параметры:
        - `key` (Tuple[int, int]): входной параметр.

        Возвращает:
        - Значение типа/структуры: None.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        if self._primary:
            try:
                await self._primary.clear(key)
            except Exception as e:
                logger.warning(
                    "StateManager: primary.clear failed: %s",
                    e,
                )
        try:
            await self._fallback.clear(key)
        except Exception as e:
            logger.error("StateManager: fallback.clear failed: %s", e)

    # --------------- высокоуровневый API ---------------

    async def get(self, tg_id: int, chat_id: int) -> ConversationState:
        """
        Возвращает актуальное состояние; при отсутствии — IDLE.
        Просроченное состояние автоматически очищается.
        """
        key = self.make_key(tg_id, chat_id)
        st = await self._get(key)
        if not st:
            return ConversationState(state=BotStates.IDLE)
        return st

    async def set(self,
        tg_id: int,
        chat_id: int,
        state: str,
        data: dict[str, Any] | None = None,
        *, ttl: int | None = None) -> ConversationState:
        """
        Устанавливает состояние и (опц.) data, продлевая TTL.
        """
        data = data or {}
        safe = self._sanitize_data(data)
        st = ConversationState(state=state, data=safe)
        st.touch(ttl)
        await self._set(self.make_key(tg_id, chat_id), st)
        return st

    async def clear(self, tg_id: int, chat_id: int) -> None:
        """Сбрасывает состояние в IDLE (удаляет запись)."""
        await self._clear(self.make_key(tg_id, chat_id))

    async def update_data(
        self,
        tg_id: int,
        chat_id: int,
        patch: dict[str, Any],
        *,
        ttl: int | None = None,
    ) -> ConversationState:
        """
        Безопасно сливает patch в data активного состояния.
        Не меняет state, только обновляет данные и TTL.
        """
        key = self.make_key(tg_id, chat_id)
        st = await self._get(key) or ConversationState()
        merged = dict(st.data or {})
        merged.update(patch or {})
        st.data = self._sanitize_data(merged)
        st.touch(ttl)
        await self._set(key, st)
        return st

    async def transition(self,
        tg_id: int,
        chat_id: int,
        expected_state: str | None,
        next_state: str,
        *, data: dict[str, Any] | None = None,
        ttl: int | None = None) -> tuple[bool, ConversationState]:
        """
        Атомарный переход, если текущее состояние совпадает с
        expected_state.
        Если expected_state=None — переход без проверки (форс).
        Возвращает (ok, новое_состояние). ok=False ─ если ожидание не
        совпало.
        """
        key = self.make_key(tg_id, chat_id)
        st = await self._get(key) or ConversationState()
        if expected_state is not None and st.state != expected_state:
            return False, st
        st.state = next_state
        if data:
            merged = dict(st.data or {})
            merged.update(data)
            st.data = self._sanitize_data(merged)
        st.touch(ttl)
        await self._set(key, st)
        return True, st

    # --------------- служебное ---------------

    async def start_background_gc(self) -> None:
        """
        Запускает фоновую задачу, которая периодически чистит
        просроченные записи.
        Безопасно вызывать несколько раз — будет только одна задача.
        """
        if self._gc_task and not self._gc_task.done():
            return

        async def _gc_loop():
            """Метод класса StateManager.
            Асинхронная функция `_gc_loop` выполняет операцию в контуре
            бота EFHC.
            Назначение: бизнес‑логика соответствующего модуля (см. имя
            функции и вызывающий код).

            Возвращает:
            - Результат операции (данные/DTO/модель) либо `None`.

            Инварианты и безопасность:
            - Повторный вызов не должен создавать дубли (идемпотентность
            достигается ключами/уникальными ограничениями).
            - Денежные значения в EFHC учитываются с точностью d8 и
            округлением вниз (ROUND_DOWN), если применимо по модулю.
            - Для операций, затрагивающих баланс/банк, изменения должны
            проходить через банковский сервис транзакций
            (transactions_service)."""
            while True:
                try:
                    # primary
                    if self._primary:
                        try:
                            removed = await self._primary.cleanup()
                            if removed:
                                logger.debug(
                                    "StateManager: primary GC removed "
                                    "%s",
                                    removed
                                )
                        except Exception as e:
                            logger.debug(
                                "StateManager: primary GC failed: %s",
                                e
                            )
                    # fallback
                    try:
                        removed_fb = await self._fallback.cleanup()
                        if removed_fb:
                            logger.debug(
                                "StateManager: fallback GC removed %s",
                                removed_fb
                            )
                    except Exception as e:
                        logger.debug(
                            "StateManager: fallback GC failed: %s",
                            e,
                        )
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.debug("StateManager GC loop error: %s", e)
                await asyncio.sleep(self._gc_interval)

        self._gc_task = create_logged_task(
            _gc_loop(),
            name="bot_state_gc",
        )

    def _sanitize_data(self, data: dict[str, Any]) -> dict[str, Any]:
        """
        Гарантирует JSON-совместимость и лимит размера.
        Если payload превышает MAX_STATE_DATA_BYTES — пробуем
        компактировать
        (например, удаляя «шумовые» ключи), затем — безопасно усечём.
        """
        safe = dict(data or {})
        try:
            payload = json.dumps(
                safe,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
        except Exception:
            # Если не сериализуется, делаем «плоские» строки значений
            flat = {
                k: (
                    str(v)
                    if not isinstance(
                        v,
                        str | int | float | bool | type(None),
                    )
                    else v
                )
                for k, v in safe.items()
            }
            safe = flat
            payload = json.dumps(
                safe,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
        if len(payload) <= MAX_STATE_DATA_BYTES:
            return safe

        # Попытка компактирования: удалим типичные шумовые поля
        noisy_keys = [
            k
            for k in safe
            if k.lower() in {"debug", "trace", "raw", "extra"}
        ]
        for k in noisy_keys:
            safe.pop(k, None)
        payload = json.dumps(
            safe,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        if len(payload) <= MAX_STATE_DATA_BYTES:
            return safe

        # Жёсткое усечение значений (оставим только «краткие»
        # строки/числа)
        trimmed: dict[str, Any] = {}
        for k, v in safe.items():
            if isinstance(v, str):
                # оставим до 256 символов
                trimmed[k] = (v[: 255] + "...") if len(v) > 256 else v
            elif isinstance(v, int | float | bool) or v is None:
                trimmed[k] = v
            else:
                trimmed[k] = str(v)[: 255] + "..."
        payload = json.dumps(
            trimmed,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        if len(payload) > MAX_STATE_DATA_BYTES:
            # последний барьер — удаляем ключи по одному, пока не влезем
            while trimmed and len(payload) > MAX_STATE_DATA_BYTES:
                trimmed.pop(next(iter(trimmed.keys())), None)
                payload = json.dumps(
                    trimmed,
                    separators=(",", ":"),
                    ensure_ascii=False,
                ).encode("utf-8")
        return trimmed

# ======================================================================
# Фабрика менеджера: можно подставить реальный backend (например, Redis)
# ======================================================================

_global_state_manager: StateManager | None = None


def get_state_manager(
    backend: StateBackend | None = None,
) -> StateManager:
    """
    Возвращает singleton StateManager для процесса. Если передать
    backend —
    используется он; иначе остаётся только in-memory хранение с
    fallback.
    """
    global _global_state_manager
    if _global_state_manager is None:
        _global_state_manager = StateManager(backend = backend)
        # Запускаем фоновую очистку сразу (не критично, если вызвать ещё
        # раз)
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # если уже в асинхронном контексте
                create_logged_task(
                    _global_state_manager.start_background_gc(),
                    name="bot_state_gc_bootstrap",
                )
        except RuntimeError:
            # не в асинхронном контексте — GC стартанёт при первом
            # async-вызове
            pass
    return _global_state_manager

# ======================================================================
# Декораторы-помощники для хэндлеров (упрощают работу с FSM)
# ======================================================================

Handler = Callable[..., Awaitable[Any]]


def require_state(
    expected: str | None,
) -> Callable[[Handler], Handler]:
    """
    Гейт для хэндлеров: пропускает только если у пользователя нужное
    состояние.
    Если expected=None — пропускает всегда (используйте tg_guard для
    прав/лимитов).
    """

    def _wrap(fn: Handler) -> Handler:
        """Оборачивает handler и проверяет ожидаемое состояние FSM.

        Параметры:
        - fn: исходный handler.

        Возвращает:
        - Handler.

        Инварианты и безопасность:
        - FSM не выполняет денежные операции.
        - Любые изменения баланса делаются вне FSM через сервисы.
        """
        async def _inner(*args: Any, **kwargs: Any) -> Any:
            # ожидаем сигнатуру handler(update, api, tg_id=...,
            # chat_id=...,
            # **ctx)
            """Выполняет handler только если состояние FSM подходит.

            Вход:
            - args/kwargs: параметры исходного обработчика.

            Возвращает:
            - результат выполнения обработчика.
            """
            tg_id = kwargs.get("tg_id")
            chat_id = kwargs.get("chat_id")
            if tg_id is None or chat_id is None:
                logger.debug(
                    "require_state: missing tg_id/chat_id in kwargs"
                )
                return await fn(*args, **kwargs)

            sm = get_state_manager()
            st = await sm.get(int(tg_id), int(chat_id))
            if expected is not None and st.state != expected:
                logger.debug(
                    "require_state: blocked (expected=%s, actual=%s)",
                    expected,
                    st.state
                )
                return None
            return await fn(*args, **kwargs)
        return _inner  # type: ignore[return-value]
    return _wrap


def advance_state(
    next_state: str,
    *,
    ttl: int | None = None,
    patch: dict[str, Any] | None = None,
) -> Callable[[Handler], Handler]:
    """
    После успешного выполнения хэндлера переводит пользователя в
    next_state,
    с опциональным обновлением data и продлением TTL.
    """

    def _wrap(fn: Handler) -> Handler:
        """Продвигает состояние FSM и обновляет data/TTL."""
        async def _inner(*args: Any, **kwargs: Any) -> Any:
            """Выполняет переход FSM и вызывает исходный handler."""
            tg_id = kwargs.get("tg_id")
            chat_id = kwargs.get("chat_id")
            res = await fn(*args, **kwargs)
            if tg_id is None or chat_id is None:
                return res
            sm = get_state_manager()
            await sm.set(
                int(tg_id),
                int(chat_id),
                next_state,
                data=patch or {},
                ttl=ttl,
            )
            return res
        return _inner  # type: ignore[return-value]
    return _wrap


def clear_state_after(fn: Handler) -> Handler:
    """Сбрасывает состояние пользователя в IDLE после handler.

    Удобно для завершающих шагов (например, «заявка принята»).
    """
    async def _inner(*args: Any, **kwargs: Any) -> Any:
        """Выполняет handler и затем очищает состояние пользователя."""
        tg_id = kwargs.get("tg_id")
        chat_id = kwargs.get("chat_id")
        res = await fn(*args, **kwargs)
        if tg_id is not None and chat_id is not None:
            sm = get_state_manager()
            await sm.clear(int(tg_id), int(chat_id))
        return res
    return _inner  # type: ignore[return-value]

# ======================================================================
# Пояснения «для чайника»:
# • Что такое FSM и зачем?
# Когда бот задаёт вопрос и ждёт ответ (например, «Сколько билетов
# купить?»),
# нужно запомнить «контекст ожидания». FSM хранит простую метку
# состояния
# (например, состояние ожидания ввода) и любые данные, нужные следующему
# шагу.
#
# • Где и как хранится?
# По умолчанию — в памяти процесса (MemoryStateBackend) + периодическая
# очистка
# просроченных записей. Можно подставить внешний backend (Redis и т.
# п.),
# реализовав
# StateBackend и передав его в get_state_manager(...).
#
# • Самовосстановление:
# Если внешний backend недоступен, менеджер не падает — пишет в
# локальную
# память.
# При следующем успешном обращении к внешнему хранилищу состояние
# продолжит
# жить.
#
# • Безопасность:
# FSM не делает деньги/TON/NFT. Это «навигация» и удобная память между
# шагами.
# Любая экономика — только через сервисы и «банк».
#
# • Как использовать в bot.py?
# sm = get_state_manager()
# await sm.set(tg_id, chat_id, BotStates.TASK_AWAIT_PROOF, {"task_id":
# 123})
# st = await sm.get(tg_id, chat_id)
# if st.state == BotStates.TASK_AWAIT_PROOF:
# ... читать доказательство и т. д.
# ======================================================================

