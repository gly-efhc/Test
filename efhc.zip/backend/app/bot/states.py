"""Backward-compatible facade for EFHC bot FSM modules.

The implementation was split into ``app.bot.fsm`` during the FSM split
range-closure repair pass to keep single-responsibility boundaries.
Keep this facade until imports migrate to ``app.bot.fsm`` directly.
"""

from app.bot.fsm import (
    DEFAULT_GC_INTERVAL_SECONDS,
    DEFAULT_STATE_TTL_SECONDS,
    MAX_STATE_DATA_BYTES,
    BotStates,
    ConversationState,
    Handler,
    MemoryStateBackend,
    StateBackend,
    StateKey,
    StateManager,
    advance_state,
    clear_state_after,
    get_state_manager,
    require_state,
)

__all__ = [
    "DEFAULT_GC_INTERVAL_SECONDS",
    "DEFAULT_STATE_TTL_SECONDS",
    "MAX_STATE_DATA_BYTES",
    "BotStates",
    "ConversationState",
    "Handler",
    "MemoryStateBackend",
    "StateBackend",
    "StateKey",
    "StateManager",
    "advance_state",
    "clear_state_after",
    "get_state_manager",
    "require_state",
]
