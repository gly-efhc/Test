"""Совместимый фасад для модулей FSM бота EFHC.

Реализация разделена в ``app.bot.fsm``. Фасад сохраняет исторический
публичный импорт до отдельного решения об удалении compatibility boundary.
"""

from app.bot.fsm import (
    DEFAULT_GC_INTERVAL_SECONDS,
    DEFAULT_STATE_TTL_SECONDS,
    MAX_STATE_DATA_BYTES,
    BotStates,
    ConversationState,
    Handler,
    MemoryStateBackend,
    StateBackend,
    StateKey,
    StateManager,
    advance_state,
    clear_state_after,
    get_state_manager,
    require_state,
)

__all__ = [
    "DEFAULT_GC_INTERVAL_SECONDS", "DEFAULT_STATE_TTL_SECONDS",
    "MAX_STATE_DATA_BYTES", "BotStates", "ConversationState", "Handler",
    "MemoryStateBackend", "StateBackend", "StateKey", "StateManager",
    "advance_state", "clear_state_after", "get_state_manager", "require_state",
]
