"""UI-тексты Telegram-бота EFHC.

Лёгкий helper для bot/help слоя.
Поддерживает оба вызова:
- t("help")
- t("ru", "help")
Fallback: ru.
"""

from __future__ import annotations

from typing import Any

TEXTS: dict[str, dict[str, str]] = {
    "ru": {
        "welcome": (
            "Привет, {username}! ⚡\n"
            "VIP: {vip_flag}\n"
            "Панели: {panels}\n"
            "Доступно kWh: {avail_kwh}"
        ),
        "menu": "Главное меню",
        "no_access": "⛔ Нет доступа.",
        "help": (
            "EFHC Bot — навигация к разделам "
            "WebApp.\n\n"
            "Основные команды:\n"
            "/start — открыть главное меню\n"
            "/help — краткая справка\n"
            "/hub — открыть Hub\n"
            "/faq — открыть FAQ\n"
            "/panels — сводка по панелям\n"
            "/profile — профиль\n"
            "/balance — баланс\n"
            "/tasks — задания\n"
            "/referrals — рефералы\n"
            "/ranks — рейтинг\n"
            "/withdraw — вывод\n"
            "/webapp — открыть Mini App\n\n"
            "FAQ: 20 разделов / 250 вопросов "
            "и ответов.\n"
            "Hub — навигационный слой "
            "проекта."
        ),
        "subscribe.required": (
            "Для доступа нужна подписка "
            "на канал {channel}."
        ),
        "panels.summary": (
            "⚡ Панели\n"
            "Активно: {count}\n"
            "Генерация в сек.: {per_sec} kWh\n"
            "Доступно: {avail_kwh} kWh"
        ),
        "profile.header": "👤 Профиль",
        "profile.lines": (
            "tg_id: {tg_id}\n"
            "VIP: {vip_flag}\n"
            "Активных панелей: {panels}\n"
            "Доступно kWh: {avail_kwh}\n"
            "Всего сгенерировано kWh: {total_kwh}"
        ),
        "exchange.preview": (
            "🔁 Обмен: {kwh} kWh → {efhc} "
            "EFHC"
        ),
        "ranks.me": "🏆 Ваш ранг: #{rank} · {total_kwh} kWh",
        "ranks.top.header": "Топ {limit}",
        "ranks.top.line": (
            "#{rank} {username} — {total_kwh} kWh"
        ),
        "referrals.header": "👥 Рефералы",
        "referrals.active.count": "Активных: {count}",
        "referrals.inactive.count": "Неактивных: {count}",
        "tasks.submitted": "🎯 Задания",
        "admin.entry": (
            "🛠 Откройте Admin Hub в "
            "WebApp кнопкой ниже."
        ),
        "admin.hub.entry": (
            "🧭 Управление Hub доступно "
            "через Admin Hub в WebApp."
        ),
        "faq.entry": (
            "❓ FAQ открыт в WebApp кнопкой ниже.\n"
            "Сейчас в FAQ: 20 разделов "
            "и 250 вопросов/ответов."
        ),
    },
    "en": {
        "welcome": (
            "Hi, {username}! ⚡\n"
            "VIP: {vip_flag}\n"
            "Panels: {panels}\n"
            "Available kWh: {avail_kwh}"
        ),
        "menu": "Main menu",
        "no_access": "⛔ Access denied.",
        "help": (
            "EFHC Bot is the navigation layer for the WebApp.\n\n"
            "Main commands:\n"
            "/start — open main menu\n"
            "/help — quick help\n"
            "/hub — open Hub\n"
            "/faq — open FAQ\n"
            "/webapp — open Mini App\n"
            "/admin_hub — open Admin Hub (admin only)\n\n"
            "FAQ: 20 sections / 250 questions and answers."
        ),
        "subscribe.required": "Subscribe to {channel} to continue.",
        "panels.summary": (
            "⚡ Panels\n"
            "Active: {count}\n"
            "Per second: {per_sec} kWh\n"
            "Available: {avail_kwh} kWh"
        ),
        "profile.header": "👤 Profile",
        "profile.lines": (
            "tg_id: {tg_id}\n"
            "VIP: {vip_flag}\n"
            "Active panels: {panels}\n"
            "Available kWh: {avail_kwh}\n"
            "Total generated kWh: {total_kwh}"
        ),
        "exchange.preview": (
            "🔁 Exchange: {kwh} kWh → "
            "{efhc} EFHC"
        ),
        "ranks.me": "🏆 Your rank: #{rank} · {total_kwh} kWh",
        "ranks.top.header": "Top {limit}",
        "ranks.top.line": "#{rank} {username} — {total_kwh} kWh",
        "referrals.header": "👥 Referrals",
        "referrals.active.count": "Active: {count}",
        "referrals.inactive.count": "Inactive: {count}",
        "tasks.submitted": "🎯 Tasks",
        "admin.entry": "🛠 Open Admin Hub in WebApp below.",
        "admin.hub.entry": (
            "🧭 Hub management is available via Admin Hub in WebApp."
        ),
        "faq.entry": (
            "❓ Open FAQ in WebApp using the button below.\n"
            "Current FAQ inventory: 20 sections / 250 "
            "questions and answers."
        ),
    },
}


def t(*args: str, **fmt: Any) -> str:
    """Return localized bot text.

    Supports backward-compatible call styles.
    """
    if not args:
        raise TypeError("t() requires at least one positional argument")
    if len(args) == 1:
        lang = "ru"
        key = args[0]
    else:
        maybe_lang, maybe_key = args[0], args[1]
        if maybe_lang in TEXTS:
            lang = maybe_lang
            key = maybe_key
        else:
            lang = "ru"
            key = maybe_lang
    d = TEXTS.get(lang) or TEXTS["ru"]
    template = d.get(key) or TEXTS["ru"].get(key) or key
    return template.format(**fmt)
