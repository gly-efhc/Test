"""Telegram bot package (aiogram v3 + webhook).

Canon notes:
- Webhook is integrated into FastAPI (routes/system_routes.py).
- No monetary operations in bot layer; only navigation and gating.
- Any economy goes via HTTP API WebApp and transaction bank.

Exports:
- get_dispatcher() / get_bot(): lazy singletons for serverless.
- process_update(db, payload): webhook entry point.
"""

from __future__ import annotations

from backend.app.bot.bot import get_bot, get_dispatcher, process_update

__all__ = ["get_bot", "get_dispatcher", "process_update"]

