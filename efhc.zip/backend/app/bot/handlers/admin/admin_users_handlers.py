# backend/app/bot/handlers/admin/admin_users_handlers.py
# ======================================================================
# Назначение кода:
# Админ-команда admin_users: безопасная точка входа в админ-операции
# через WebApp.
# Канон: админ-логика и деньги выполняются ТОЛЬКО через backend API и
# services слой.
# ======================================================================
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb__main__menu
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверка права админа по global_id.

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли.
    - Денежные значения EFHC: d8, ROUND_DOWN (где применимо).
    - Операции, затрагивающие баланс/банк, идут через
      transactions_service.
    """
    return int(tg_id) == int(getattr(settings, "ADMIN_TG_ID", 0))


@router.message(Command("admin_users"))
async def handler(message: Message) -> None:
    """Показывает точку входа в Admin → Users (WebApp)."""
    if not message.from_user:
        return
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "👥 Управление пользователями доступно в WebApp → "
        "Admin → Users.",
        reply_markup=kb__main__menu(),
    )
