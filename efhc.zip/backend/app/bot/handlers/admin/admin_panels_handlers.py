# backend/app/bot/handlers/admin/admin_panels_handlers.py
# ======================================================================
# Назначение кода:
# Админ-команда admin_panels: безопасная точка входа в админ-операции
# через WebApp.
# Канон: админ-логика и деньги выполняются ТОЛЬКО через backend API и
# services слой.
# ======================================================================
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb__main__menu
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверка права админа по global_id."""
    return int(global_id) == int(getattr(settings, "ADMIN_TG_ID", 0))


@router.message(Command("admin_panels"))
async def handler(message: Message) -> None:
    """Показывает точку входа в Admin → Panels (WebApp)."""
    if not message.from_user:
        return
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "☀️ Управление панелями доступно в WebApp → Admin → Panels.",
        reply_markup=kb__main__menu(),
    )
