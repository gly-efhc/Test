(
    'Бессрочный фасад совместимости исторического имени'
    ' Admin main handlers.\n'
    '\n'
    'Совместимый фасад исторического имени: этот точный'
    ' маркер оставлен намеренно,\n'
    'чтобы provider-boundary guard отличал compatibilit'
    'y wrapper от реального handler.\n'
    '\n'
    'Решение цикла 1728 для будущих аудитов: двойное по'
    'дчёркивание в имени файла\n'
    'не означает ошибку, дубль runtime-router или канди'
    'дат на автоматический cleanup.\n'
    'Реальная реализация живёт в ``admin_main_handlers`'
    '`; этот модуль только\n'
    'реэкспортирует ТОТ ЖЕ handler/router/keyboard для '
    'старых import paths.\n'
    '\n'
    'Новый код должен использовать ``admin_main_handler'
    's``. Здесь нельзя создавать\n'
    'новую Admin business-логику, второй router или аль'
    'тернативные права доступа.\n'
    'Отсутствие current callers не разрешает удалить co'
    'mpatibility seam без\n'
    'отдельного решения пользователя и полного delete-p'
    'roof.\n'
)

from __future__ import annotations

from app.bot.handlers.admin.admin_main_handlers import handler, router
from app.bot.keyboards import kb_admin_entry

ADMIN_HUB_LABEL = "Admin Hub"

__all__ = ["ADMIN_HUB_LABEL", "handler", "kb_admin_entry", "router"]
