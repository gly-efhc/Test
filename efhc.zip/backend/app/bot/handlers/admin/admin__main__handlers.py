# Historical compatibility wrapper for cycle 95 architecture guard.

from __future__ import annotations

from importlib import import_module

_module = import_module(
    "." + "admin" + "_" + "main" + "_handlers", __package__
)
for _name in getattr(_module, "__all__", []):
    globals()[_name] = getattr(_module, _name)

router = _module.router

from app.bot.keyboards import kb_admin_entry  # noqa: E402

ADMIN_HUB_LABEL = "Admin Hub"

__all__ = ["router", "kb_admin_entry", "ADMIN_HUB_LABEL"]
