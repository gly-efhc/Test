"""Совместимый фасад исторического имени Admin main handlers."""

from __future__ import annotations

from app.bot.handlers.admin.admin_main_handlers import handler, router
from app.bot.keyboards import kb_admin_entry

ADMIN_HUB_LABEL = "Admin Hub"

__all__ = ["ADMIN_HUB_LABEL", "handler", "kb_admin_entry", "router"]
