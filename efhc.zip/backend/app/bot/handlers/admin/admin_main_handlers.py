# backend/app/bot/handlers/admin/admin_main_handlers.py
# ----------------------------------------------------------------------
# Назначение кода:
# /admin — безопасная точка входа в админ-операции через WebApp.
# Канон: админ-логика и деньги выполняются через backend API + services.
# ----------------------------------------------------------------------

from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb_admin_entry
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверяет tg_id на совпадение с admin tg_id из настроек."""
    admin_tg_id = int(getattr(settings, "ADMIN_TG_ID", 0))
    return int(tg_id) == admin_tg_id


@router.message(Command("admin"))
async def handler(message: Message) -> None:
    """Команда /admin — отдаёт ссылку на админ-панель в WebApp."""
    if not message.from_user:
        return

    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "🛠 Откройте Admin Hub в WebApp кнопкой ниже.",
        reply_markup=kb_admin_entry(),
    )
