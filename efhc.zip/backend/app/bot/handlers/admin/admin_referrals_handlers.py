# backend/app/bot/handlers/admin/admin_referrals_handlers.py
# ======================================================================
# Назначение кода:
# Админ-команда admin_referrals: безопасная точка входа в админ-операции
# через WebApp.
# Канон: админ-логика и деньги выполняются ТОЛЬКО через backend API и
# services слой.
# ======================================================================
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb__main__menu
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверяет Telegram ID по настройке ADMIN_TG_ID."""
    admin_tg_id = int(getattr(settings, "ADMIN_TG_ID", 0))
    return int(tg_id) == admin_tg_id


@router.message(Command("admin_referrals"))
async def handler(message: Message) -> None:
    """Показывает точку входа в Admin → Referrals (WebApp)."""
    if not message.from_user:
        return
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "🔗 Управление рефералами доступно в WebApp → "
        "Admin → Referrals.",
        reply_markup=kb__main__menu(),
    )
