# backend/app/bot/handlers/admin/admin_hub_handlers.py
# ======================================================================
# Назначение кода:
# Админ-команда admin_hub: точка входа в Hub admin UI
# через WebApp.
# Канон: админ-логика и деньги выполняются ТОЛЬКО через backend API и
# services слой.
# ======================================================================
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb_admin_entry
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверка права админа по tg_id."""
    return int(tg_id) == int(getattr(settings, "ADMIN_TG_ID", 0))


@router.message(Command("admin_hub"))
async def handler(message: Message) -> None:
    """Показывает точку входа в Admin → Hub."""
    if not message.from_user:
        return
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "🧭 Управление Hub доступно через Admin Hub в WebApp.",
        reply_markup=kb_admin_entry(),
    )
