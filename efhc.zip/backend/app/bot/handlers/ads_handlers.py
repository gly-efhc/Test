"""Bot ads handlers.

Command /ads shows a hint about ad views. Bonuses are handled by backend
jobs.
"""

from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb__main__menu

router = Router()


@router.message(Command("ads"))
async def cmd_ads(message: Message) -> None:
    """Show hint for ad views and bonuses."""

    await message.answer(
        "📺 Просмотры рекламы и начисления доступны в WebApp 👇",
        reply_markup=kb__main__menu(),
    )
