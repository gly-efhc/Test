"""Bot ads handlers.

Command /ads shows a hint about ad views. Rewards are handled by backend
jobs.
"""

from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from backend.app.bot.keyboards import kb_main_menu

router = Router()


@router.message(Command("ads"))
async def cmd_ads(message: Message) -> None:
    """Show hint for ad views and rewards."""

    await message.answer(
        "📺 Просмотры рекламы и начисления доступны в WebApp 👇",
        reply_markup=kb_main_menu(),
    )
