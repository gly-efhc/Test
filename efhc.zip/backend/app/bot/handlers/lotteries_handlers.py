# -*- coding: utf-8 -*-
# backend/app/bot/handlers/lotteries_handlers.py
# ----------------------------------------------------------------------
# Назначение кода:
# /lotteries — список активных розыгрышей + подсказка WebApp.
# ----------------------------------------------------------------------

from __future__ import annotations

from typing import Optional

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards import kb_main_menu, kb_subscribe
from app.bot.texts import t
from app.services.lotteries_service import (
    svc_list_active_lotteries,
)

router = Router()


async def _gate_subscribe(
    message: Message,
    required_channel_id: Optional[int],
    is_subscribed: bool,
    required_channel_username: Optional[str],
) -> bool:
    """Проверяет подписку и показывает кнопку
    подписки при необходимости."""
    if required_channel_id and not is_subscribed:
        channel = required_channel_username or str(required_channel_id)
        await message.answer(
            t("subscribe.required", channel=channel),
            reply_markup=kb_subscribe(required_channel_username),
        )
        return True
    return False


@router.message(Command("lotteries"))
async def cmd_lotteries(
    message: Message,
    db: AsyncSession,
    is_subscribed: bool = True,
    required_channel_username: Optional[str] = None,
    required_channel_id: Optional[int] = None,
) -> None:
    """Команда /lotteries — показывает активные розыгрыши."""
    if await _gate_subscribe(
        message,
        required_channel_id,
        is_subscribed,
        required_channel_username,
    ):
        return

    try:
        items = await svc_list_active_lotteries(db, limit=10)
    except Exception:
        items = []

    if not items:
        require_subscribe = bool(required_channel_id)
        menu = kb_main_menu(require_subscribe=require_subscribe)
        await message.answer(
            "🎟 Активных лотерей нет. Следите за обновлениями.",
            reply_markup=menu,
        )
        return

    lines = ["🎟 Активные лотереи (TOP - 10):"]
    for it in items:
        title = str(it.get("title") or "Lotteries")
        price = str(it.get("ticket_price_efhc") or "0")
        ends = str(it.get("ends_at") or "—")
        lines.append(
            f"• {title} — билет {price} EFHC • до {ends}"
        )

    lines.append("\nОформление покупки билетов — в WebApp 👇")

    require_subscribe = bool(required_channel_id)
    await message.answer(
        "\n".join(lines),
        reply_markup=kb_main_menu(require_subscribe=require_subscribe),
    )
