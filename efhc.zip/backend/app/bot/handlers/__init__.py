"""Хендлеры Telegram-бота.

Основной обработчик обновлений живёт в backend/app/bot/bot.py.
"""

__all__ = []
