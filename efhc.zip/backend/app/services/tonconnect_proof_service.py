from __future__ import annotations

import base64
import json
import secrets
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from hashlib import sha256

import httpx
from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.security_core import _get_secret_key
from app.core.utils_core import hmac_sha256_hex
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PublicKey,
)

TTL_MINUTES = 10
MAX_CLOCK_SKEW_SECONDS = 15 * 60
TC_PREFIX = b"ton-connect"
TP_PREFIX = b"ton-proof-item-v2/"

logger = get_logger(__name__)


class TonProofError(Exception):
    pass


class TonProofExpired(TonProofError):
    pass


class TonProofInvalid(TonProofError):
    pass


@dataclass(slots=True)
class TonProofPayloadOut:
    payload: str
    payload_token: str
    expires_at: datetime
    domain: str


@dataclass(slots=True)
class TonProofCheckOut:
    accepted: bool
    cryptographically_verified: bool
    reason: str


@dataclass(slots=True)
class ParsedAddress:
    workchain: int
    account_id: bytes
    raw: str


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _b64u_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("utf-8").rstrip("=")


def _b64u_decode(value: str) -> bytes:
    pad = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + pad).encode("utf-8"))


def _try_b64_decode(
    value: bytes,
    decoder: Callable[[bytes], bytes],
) -> bytes | None:
    try:
        return decoder(value)
    except (TypeError, ValueError):
        return None


def _b64_any_decode(value: str) -> bytes:
    txt = str(value or "").strip()
    if not txt:
        raise TonProofInvalid("BASE64_REQUIRED")
    padded = (txt + ("=" * (-len(txt) % 4))).encode("utf-8")
    decoders = (base64.b64decode, base64.urlsafe_b64decode)
    for decoder in decoders:
        decoded = _try_b64_decode(padded, decoder)
        if decoded is not None:
            return decoded
    raise TonProofInvalid("BASE64_INVALID")


def _resolve_domain(host: str | None) -> str:
    host = str(host or "").strip().lower()
    if host:
        return host
    settings = get_settings()
    origin = str(getattr(settings, "APP_URL", "") or "").strip()
    if "//" in origin:
        origin = origin.split("//", 1)[1]
    return origin.split("/", 1)[0].lower() or "localhost"


def _sign_payload(data: dict[str, object]) -> str:
    body = json.dumps(data, sort_keys=True, separators=(",", ":"))
    sig = hmac_sha256_hex(_get_secret_key(), body)
    enc = _b64u_encode(body.encode("utf-8"))
    return f"{enc}.{sig}"


def _unsign_payload(token: str) -> dict[str, object]:
    try:
        enc, sig = str(token).split(".", 1)
        raw = _b64u_decode(enc).decode("utf-8")
    except Exception as err:
        raise TonProofInvalid("INVALID_TOKEN") from err
    wanted = hmac_sha256_hex(_get_secret_key(), raw)
    if wanted != sig:
        raise TonProofInvalid("INVALID_TOKEN_SIG")
    try:
        data = json.loads(raw)
    except Exception as err:
        raise TonProofInvalid("INVALID_TOKEN_BODY") from err
    if not isinstance(data, dict):
        raise TonProofInvalid("INVALID_TOKEN_BODY")
    return {str(key): value for key, value in data.items()}


def _crc16_xmodem(data: bytes) -> int:
    crc = 0
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


def _parse_raw_address(value: str) -> ParsedAddress:
    wc_txt, hex_txt = value.split(":", 1)
    try:
        wc = int(wc_txt)
    except ValueError as err:
        raise TonProofInvalid("ADDRESS_INVALID") from err
    try:
        account_id = bytes.fromhex(hex_txt)
    except ValueError as err:
        raise TonProofInvalid("ADDRESS_INVALID") from err
    if len(account_id) != 32:
        raise TonProofInvalid("ADDRESS_INVALID")
    return ParsedAddress(
        workchain=wc,
        account_id=account_id,
        raw=f"{wc}:{account_id.hex()}",
    )


def _parse_friendly_address(value: str) -> ParsedAddress:
    raw = _b64_any_decode(value)
    if len(raw) != 36:
        raise TonProofInvalid("ADDRESS_INVALID")
    body = raw[:34]
    checksum = int.from_bytes(raw[34:], "big")
    wanted = _crc16_xmodem(body)
    if checksum != wanted:
        raise TonProofInvalid("ADDRESS_CHECKSUM_INVALID")
    wc = int.from_bytes(body[1:2], "big", signed=True)
    account_id = body[2:34]
    return ParsedAddress(
        workchain=wc,
        account_id=account_id,
        raw=f"{wc}:{account_id.hex()}",
    )


def parse_ton_address(value: str) -> ParsedAddress:
    addr = str(value or "").strip()
    if not addr:
        raise TonProofInvalid("ADDRESS_INVALID")
    if ":" in addr:
        return _parse_raw_address(addr)
    return _parse_friendly_address(addr)


def _to_int32_be(value: int) -> bytes:
    return int(value).to_bytes(4, "big", signed=True)


def _to_uint32_le(value: int) -> bytes:
    return int(value).to_bytes(4, "little", signed=False)


def _to_uint64_le(value: int) -> bytes:
    return int(value).to_bytes(8, "little", signed=False)


def _proof_message(
    *,
    address: ParsedAddress,
    domain: str,
    timestamp: int,
    payload: str,
) -> bytes:
    domain_bytes = domain.encode("utf-8")
    payload_bytes = payload.encode("utf-8")
    msg = b"".join(
        [
            TP_PREFIX,
            _to_int32_be(address.workchain),
            address.account_id,
            _to_uint32_le(len(domain_bytes)),
            domain_bytes,
            _to_uint64_le(timestamp),
            payload_bytes,
        ]
    )
    head = b"\xff\xff" + TC_PREFIX
    return sha256(head + sha256(msg).digest()).digest()


def _parse_public_key(value: str | None) -> bytes:
    txt = str(value or "").strip().lower()
    if txt.startswith("0x"):
        txt = txt[2:]
    if not txt:
        raise TonProofInvalid("PUBLIC_KEY_REQUIRED")
    try:
        out = bytes.fromhex(txt)
    except ValueError as err:
        raise TonProofInvalid("PUBLIC_KEY_INVALID") from err
    if len(out) != 32:
        raise TonProofInvalid("PUBLIC_KEY_INVALID")
    return out


def _verify_signature(
    *,
    public_key: bytes,
    signature: str,
    message_hash: bytes,
) -> None:
    sig = _b64_any_decode(signature)
    try:
        Ed25519PublicKey.from_public_bytes(public_key).verify(
            sig,
            message_hash,
        )
    except InvalidSignature as err:
        raise TonProofInvalid("SIGNATURE_INVALID") from err
    except ValueError as err:
        raise TonProofInvalid("PUBLIC_KEY_INVALID") from err


def _candidate_api_bases() -> list[str]:
    settings = get_settings()
    seq: list[str] = []
    primary = str(getattr(settings, "TON_API_URL", "") or "").strip()
    if primary:
        seq.append(primary)
    fb = str(getattr(settings, "TON_API_FALLBACK_URLS", "") or "")
    seq.extend([u.strip() for u in fb.split(",") if u.strip()])
    seq.extend(
        [
            "https://tonapi.io/v2",
            "https://toncenter.com/api/v2",
            "https://testnet.toncenter.com/api/v2",
        ]
    )
    out: list[str] = []
    for item in seq:
        url = item.rstrip("/")
        if url and url not in out:
            out.append(url)
    return out


def _auth_headers() -> dict[str, str]:
    settings = get_settings()
    key = str(getattr(settings, "TON_API_KEY", "") or "").strip()
    if not key:
        return {}
    return {"Authorization": f"Bearer {key}"}


def _extract_nested(obj: object, keys: tuple[str, ...]) -> str | None:
    cur = obj
    for key in keys:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    if cur is None:
        return None
    txt = str(cur).strip()
    return txt or None


def _object_to_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        txt = value.strip()
        if not txt:
            return None
        try:
            return int(txt)
        except ValueError:
            return None
    return None


def _parse_tonapi_stateinit(
    data: dict[str, object],
) -> tuple[str, str] | None:
    variants = [data, data.get("result")]
    for item in variants:
        if not isinstance(item, dict):
            continue
        addr = _extract_nested(item, ("address",))
        pub = _extract_nested(item, ("public_key",))
        if addr and pub:
            return addr, pub
    return None


def _parse_toncenter_pubkey(data: dict[str, object]) -> str | None:
    stack = data.get("result")
    if isinstance(stack, dict):
        stack = stack.get("stack")
    if not isinstance(stack, list):
        return None
    for item in stack:
        if not isinstance(item, list) or len(item) < 2:
            continue
        value = str(item[1] or "").strip().lower()
        if value.startswith("0x"):
            value = value[2:]
        if value:
            return value.zfill(64)
    return None


async def _tonapi_stateinit_lookup(
    *,
    base: str,
    state_init: str,
) -> tuple[str, str] | None:
    if "tonapi" not in base:
        return None
    endpoint = base.rstrip("/")
    if not endpoint.endswith("/v2"):
        endpoint = endpoint + "/v2"
    url = endpoint + "/tonconnect/stateinit"
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.post(
            url,
            json={"state_init": state_init},
            headers=_auth_headers(),
        )
        resp.raise_for_status()
        data = resp.json()
    return _parse_tonapi_stateinit(data)


async def _toncenter_get_public_key(
    *,
    base: str,
    address: str,
) -> str | None:
    if "toncenter" not in base:
        return None
    url = base.rstrip("/") + "/runGetMethod"
    params = {
        "address": address,
        "method": "get_public_key",
        "stack": "[]",
    }
    headers = _auth_headers()
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(url, params=params, headers=headers)
        resp.raise_for_status()
        data = resp.json()
    return _parse_toncenter_pubkey(data)


async def _resolve_public_key(
    *,
    address: str,
    state_init: str | None,
) -> tuple[bytes | None, str]:
    bases = _candidate_api_bases()
    if state_init:
        for base in bases:
            try:
                out = await _tonapi_stateinit_lookup(
                    base=base,
                    state_init=state_init,
                )
            except Exception as err:
                logger.warning(
                    "ton_proof stateinit lookup failed: %s",
                    err,
                )
                continue
            if not out:
                continue
            addr_txt, state_pub_txt = out
            declared = parse_ton_address(address)
            derived = parse_ton_address(addr_txt)
            if declared.raw != derived.raw:
                raise TonProofInvalid("STATE_INIT_ADDRESS_MISMATCH")
            return _parse_public_key(state_pub_txt), "state_init_api"
    for base in bases:
        pub_txt: str | None
        try:
            pub_txt = await _toncenter_get_public_key(
                base=base,
                address=address,
            )
        except Exception as err:
            logger.warning(
                "ton_proof public key lookup failed: %s",
                err,
            )
            continue
        if pub_txt:
            return _parse_public_key(pub_txt), "chain_get_public_key"
    return None, "unresolved"


def issue_payload(
    *,
    tg_id: int,
    host: str | None,
) -> TonProofPayloadOut:
    now = _utcnow()
    exp = now + timedelta(minutes=TTL_MINUTES)
    payload = f"efhc_tp_{secrets.token_urlsafe(18)}"
    domain = _resolve_domain(host)
    token = _sign_payload(
        {
            "v": 1,
            "tg_id": int(tg_id),
            "payload": payload,
            "domain": domain,
            "exp": int(exp.timestamp()),
        }
    )
    return TonProofPayloadOut(
        payload=payload,
        payload_token=token,
        expires_at=exp,
        domain=domain,
    )


async def check_proof(
    *,
    tg_id: int,
    host: str | None,
    address: str,
    payload_token: str,
    proof: dict[str, object],
    public_key: str | None,
) -> TonProofCheckOut:
    token = _unsign_payload(payload_token)
    exp = _object_to_int(token.get("exp", 0))
    if exp is None:
        raise TonProofInvalid("INVALID_TOKEN_BODY")
    token_tg_id = _object_to_int(token.get("tg_id", 0))
    if token_tg_id is None:
        raise TonProofInvalid("INVALID_TOKEN_BODY")
    now_ts = int(_utcnow().timestamp())
    if token_tg_id != int(tg_id):
        raise TonProofInvalid("TG_ID_MISMATCH")
    if exp < now_ts:
        raise TonProofExpired("TOKEN_EXPIRED")
    expected_domain = str(token.get("domain", "") or "")
    host_domain = _resolve_domain(host)
    if (
        expected_domain
        and host_domain
        and host_domain != expected_domain
    ):
        raise TonProofInvalid("DOMAIN_MISMATCH")
    parsed_addr = parse_ton_address(address)
    payload = str(proof.get("payload", "") or "")
    if payload != str(token.get("payload", "") or ""):
        raise TonProofInvalid("PAYLOAD_MISMATCH")
    domain = proof.get("domain")
    if not isinstance(domain, dict):
        raise TonProofInvalid("DOMAIN_REQUIRED")
    proof_domain = str(domain.get("value", "") or "").lower().strip()
    if expected_domain and proof_domain != expected_domain:
        raise TonProofInvalid("PROOF_DOMAIN_MISMATCH")
    length_bytes = _object_to_int(domain.get("lengthBytes", 0))
    if length_bytes is None:
        raise TonProofInvalid("PROOF_DOMAIN_LENGTH_MISMATCH")
    if length_bytes != len(proof_domain.encode("utf-8")):
        raise TonProofInvalid("PROOF_DOMAIN_LENGTH_MISMATCH")
    timestamp = _object_to_int(proof.get("timestamp", 0))
    if timestamp is None:
        raise TonProofInvalid("TIMESTAMP_INVALID")
    if abs(now_ts - timestamp) > MAX_CLOCK_SKEW_SECONDS:
        raise TonProofInvalid("TIMESTAMP_EXPIRED")
    signature = str(proof.get("signature", "") or "")
    if not signature:
        raise TonProofInvalid("SIGNATURE_REQUIRED")
    state_init = str(proof.get("state_init", "") or "").strip() or None
    resolved_key, source = await _resolve_public_key(
        address=address,
        state_init=state_init,
    )
    client_key = _parse_public_key(public_key)
    if resolved_key is not None and resolved_key != client_key:
        raise TonProofInvalid("PUBLIC_KEY_MISMATCH")
    key = resolved_key or client_key
    msg_hash = _proof_message(
        address=parsed_addr,
        domain=proof_domain,
        timestamp=timestamp,
        payload=payload,
    )
    _verify_signature(
        public_key=key,
        signature=signature,
        message_hash=msg_hash,
    )
    if resolved_key is None and state_init:
        raise TonProofInvalid("PUBLIC_KEY_UNRESOLVED")
    reason = (
        "PROOF_VERIFIED" if resolved_key is not None else
        "PROOF_VERIFIED_CLIENT_KEY_ONLY"
    )
    return TonProofCheckOut(
        accepted=True,
        cryptographically_verified=True,
        reason=reason + ":" + source,
    )
