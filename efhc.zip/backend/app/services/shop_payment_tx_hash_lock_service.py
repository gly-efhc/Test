from __future__ import annotations

from app.lib.time import utcnow
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


async def acquire_tx_hash_lock(
    db: AsyncSession,
    *,
    tx_hash: str,
    purpose: str,
    intent_id: int,
    global_id: int,
    order_id: int | None = None,
) -> bool:
    q = text(
        """
        INSERT INTO efhc_core.tx_hash_locks (
            tx_hash, purpose, intent_id, order_id, global_id, created_at
        ) VALUES (
            :tx_hash, :purpose, :intent_id, :order_id,
            :global_id, :created_at
        )
        ON CONFLICT (tx_hash) DO NOTHING
        """
    )
    res = await db.execute(
        q,
        {
            "tx_hash": str(tx_hash),
            "purpose": str(purpose),
            "intent_id": int(intent_id),
            "order_id": int(order_id) if order_id is not None else None,
            "global_id": int(global_id),
            "created_at": utcnow(),
        },
    )
    return bool(getattr(res, "rowcount", 0))
