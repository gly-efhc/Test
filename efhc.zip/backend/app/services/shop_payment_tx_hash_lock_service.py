from __future__ import annotations

from app.identity.types import global_id_to_database, parse_global_id
from app.lib.time import utcnow
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


async def acquire_tx_hash_lock(
    db: AsyncSession,
    *,
    tx_hash: str,
    purpose: str,
    intent_id: int,
    global_id: str,
    order_id: int | None = None,
) -> bool:
    """Захватить неизменяемый on-chain tx lock для canonical owner."""
    query = text(
        """
        INSERT INTO efhc_core.tx_hash_locks (
            tx_hash, purpose, intent_id, order_id,
            global_id, created_at
        ) VALUES (
            :tx_hash, :purpose, :intent_id, :order_id,
            :global_id, :created_at
        )
        ON CONFLICT (tx_hash) DO NOTHING
        """
    )
    result = await db.execute(
        query,
        {
            "tx_hash": str(tx_hash),
            "purpose": str(purpose),
            "intent_id": int(intent_id),
            "order_id": (
                int(order_id) if order_id is not None else None
            ),
            "global_id": global_id_to_database(parse_global_id(global_id)),
            "created_at": utcnow(),
        },
    )
    return bool(getattr(result, "rowcount", 0))
