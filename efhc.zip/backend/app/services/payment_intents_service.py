# backend/app/services/payment_intents_service.py
# =====================================================================
# Назначение:
# Технический слой Payment Intents для on-chain оплат (TonConnect).
# Используется для:
# • deposit_efhc (Пополнить EFHC)
# • shop_external (внешний Shop за TON/USDT)
#
# Канон / инварианты:
# • tg_id — только из Telegram initData (routes/deps).
# • Денежные величины — Decimal D8, ROUND_DOWN.
# • Идемпотентность: UNIQUE(global_id,purpose,idempotency_key).
# • Payload для матчинга watcher'ом строго:
#   EFHC:<purpose>:<intent_id>:<global_id>
# • Статусы: PENDING|CONFIRMED|EXPIRED|CANCELED.
# • SENT больше не используется как серверный статус;
#   legacy alias сохранён только для безопасного перехода.
# =====================================================================

from __future__ import annotations

import base64
import time
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import timedelta
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.identity.financial_write_switch import (
    FinancialWriteOwner,
    resolve_and_lock_financial_write_owner,
)
from app.lib.time import utcnow
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
S = get_settings()
SCHEMA = getattr(S, "DB_SCHEMA_CORE", "efhc_core")
if str(SCHEMA) != "efhc_core":
    raise RuntimeError("payment_intents_service requires efhc_core")

PI_TABLE = "efhc_core.payment_intents"
PI_SEQUENCE_OWNER = PI_TABLE

"""Postgres-only."""


STATUS_PENDING = "PENDING"
PENDING_INTENT_LIMIT = 5
STATUS_CONFIRMED = "CONFIRMED"
STATUS_EXPIRED = "EXPIRED"
STATUS_CANCELED = "CANCELED"


STATUS_ERROR_RETRY = "error_retry"
STATUS_ERROR_NETWORK_RETRY = "error_network_retry"
STATUS_PENDING_MANUAL = "pending_manual"
STATUS_PENDING_MAPPING = "parsed_pending_mapping"
STATUS_RECEIVED = "received"
STATUS_PARSED = "parsed"


def _canonical_return_path(*, product_state: str) -> str:
    if product_state == "active":
        return "browser_shop"
    if product_state == "pending_external":
        return "web_profile"
    return "web_profile"


def _canonical_next_action(
    *,
    product_state: str,
    purpose: str,
) -> str:
    if product_state == "active":
        return "resume_browser_shop"
    if product_state == "pending_external":
        return "wait_network"
    if product_state == "manual_review":
        return "wait_manual_review"
    if product_state == "terminal_success":
        return (
            "back_to_telegram"
            if purpose == "deposit_efhc"
            else "open_web_profile"
        )
    if product_state in {"terminal_failed", "expired"}:
        return "create_new_intent"
    return "wait_processing"


def _wallet_readiness_payload(
    *,
    require_handoff: bool,
    handoff_configured: bool,
    wallet_linked: bool,
    wallet_sync_required: bool,
    has_active_intent: bool,
    next_action: str,
) -> dict[str, Any]:
    if require_handoff:
        return {
            "wallet_ready": False,
            "wallet_blocked": True,
            "action_allowed": False,
            "action_denied": True,
            "readiness_state": "telegram_handoff_required",
            "primary_cta": "open_telegram_handoff",
        }
    if not handoff_configured:
        return {
            "wallet_ready": wallet_linked,
            "wallet_blocked": True,
            "action_allowed": False,
            "action_denied": True,
            "readiness_state": "external_flow_missing",
            "primary_cta": "unavailable",
        }
    if wallet_sync_required or not wallet_linked:
        return {
            "wallet_ready": False,
            "wallet_blocked": True,
            "action_allowed": False,
            "action_denied": True,
            "readiness_state": "wallet_sync_required",
            "primary_cta": "sync_wallet",
        }
    if has_active_intent:
        return {
            "wallet_ready": True,
            "wallet_blocked": False,
            "action_allowed": True,
            "action_denied": False,
            "readiness_state": "resume_active_intent",
            "primary_cta": next_action,
        }
    return {
        "wallet_ready": True,
        "wallet_blocked": False,
        "action_allowed": True,
        "action_denied": False,
        "readiness_state": "ready",
        "primary_cta": next_action,
    }


def _is_expired_now(expires_at: Any) -> bool:
    try:
        if not expires_at:
            return False
        return bool(expires_at < (utcnow() - timedelta(seconds=1)))
    except Exception:
        return False


def _build_intent_flow_truth(
    *,
    purpose: str,
    intent_status: str,
    expires_at: Any,
    external_tx_hash: str | None,
    order: Mapping[str, Any] | None,
    inbox: Mapping[str, Any] | None,
) -> dict[str, Any]:
    status = str(intent_status or "").upper()
    watcher_status = (
        str(inbox.get("status") or "") if inbox is not None else None
    )
    watcher_last_error = (
        str(inbox.get("last_error") or "")
        if inbox is not None and inbox.get("last_error")
        else None
    )
    watcher_tx_hash = (
        str(inbox.get("tx_hash") or "")
        if inbox is not None and inbox.get("tx_hash")
        else external_tx_hash
    )
    order_id = (
        int(order["id"])
        if order is not None and order.get("id") is not None
        else None
    )
    order_status = (
        str(order.get("status") or "")
        if order is not None and order.get("status") is not None
        else None
    )
    payment_error_log = (
        str(order.get("payment_error_log") or "")
        if order is not None and order.get("payment_error_log")
        else None
    )

    if status == STATUS_CONFIRMED:
        if purpose == "deposit_efhc":
            return {
                "lifecycle_stage": "credited",
                "product_state": "terminal_success",
                "lifecycle_terminal": True,
                "next_step": "back_to_telegram",
                "next_action": _canonical_next_action(
                    product_state="terminal_success",
                    purpose=purpose,
                ),
                "return_path": _canonical_return_path(
                    product_state="terminal_success",
                ),
                "canonical_center": "web_profile",
                "user_message": (
                    "Payment confirmed. EFHC were already credited. "
                    "Check the balance and operation history."
                ),
                "watcher_status": watcher_status,
                "watcher_tx_hash": watcher_tx_hash,
                "watcher_last_error": watcher_last_error,
                "order_id": order_id,
                "order_status": order_status,
                "payment_error_log": payment_error_log,
            }
        if order_status in {"PAID_AUTO", "APPROVED"}:
            return {
                "lifecycle_stage": "credited",
                "product_state": "terminal_success",
                "lifecycle_terminal": True,
                "next_step": "back_to_telegram",
                "next_action": _canonical_next_action(
                    product_state="terminal_success",
                    purpose=purpose,
                ),
                "return_path": _canonical_return_path(
                    product_state="terminal_success",
                ),
                "canonical_center": "web_profile",
                "user_message": (
                    "Payment confirmed. "
                    "The order was already processed. "
                    "You can return to Telegram."
                ),
                "watcher_status": watcher_status,
                "watcher_tx_hash": watcher_tx_hash,
                "watcher_last_error": watcher_last_error,
                "order_id": order_id,
                "order_status": order_status,
                "payment_error_log": payment_error_log,
            }
        if order_status in {"PAID_PENDING_MANUAL", "PENDING"}:
            return {
                "lifecycle_stage": "manual_review",
                "product_state": "manual_review",
                "lifecycle_terminal": False,
                "next_step": "wait_manual_review",
                "next_action": _canonical_next_action(
                    product_state="manual_review",
                    purpose=purpose,
                ),
                "return_path": _canonical_return_path(
                    product_state="manual_review",
                ),
                "canonical_center": "web_profile",
                "user_message": (
                    "We can see the payment. The order is waiting for "
                    "completion and may still require manual review."
                ),
                "watcher_status": watcher_status,
                "watcher_tx_hash": watcher_tx_hash,
                "watcher_last_error": watcher_last_error,
                "order_id": order_id,
                "order_status": order_status,
                "payment_error_log": payment_error_log,
            }

    if status == STATUS_EXPIRED or _is_expired_now(expires_at):
        return {
            "lifecycle_stage": "expired",
            "product_state": "expired",
            "lifecycle_terminal": True,
            "next_step": "create_new_intent",
            "next_action": _canonical_next_action(
                product_state="expired",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="expired",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "The intent expired. Create a new intent for a new "
                "payment and do not reuse the old memo."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    if status == STATUS_CANCELED:
        return {
            "lifecycle_stage": "canceled",
            "product_state": "terminal_failed",
            "lifecycle_terminal": True,
            "next_step": "create_new_intent",
            "next_action": _canonical_next_action(
                product_state="terminal_failed",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="terminal_failed",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "The intent was canceled. Create a new intent only "
                "for a new attempt."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    if watcher_status in {STATUS_RECEIVED, STATUS_PARSED}:
        return {
            "lifecycle_stage": "network_seen",
            "product_state": "pending_external",
            "lifecycle_terminal": False,
            "next_step": "wait_network",
            "next_action": _canonical_next_action(
                product_state="pending_external",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="pending_external",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "We can see the payment and are processing it now. "
                "Wait for network confirmation and watcher processing."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    if watcher_status in {
        STATUS_ERROR_RETRY,
        STATUS_ERROR_NETWORK_RETRY,
    }:
        return {
            "lifecycle_stage": "network_seen",
            "product_state": "pending_external",
            "lifecycle_terminal": False,
            "next_step": "wait_network",
            "next_action": _canonical_next_action(
                product_state="pending_external",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="pending_external",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "We can see the payment, but confirmation is not "
                "finished yet. The system will retry automatically."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    if watcher_status in {
        STATUS_PENDING_MANUAL,
        STATUS_PENDING_MAPPING,
    }:
        return {
            "lifecycle_stage": "manual_review",
            "product_state": "manual_review",
            "lifecycle_terminal": False,
            "next_step": "wait_manual_review",
            "next_action": _canonical_next_action(
                product_state="manual_review",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="manual_review",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "The payment was detected, but it requires an "
                "additional review. Do not create a new intent."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    if order_status in {"REJECTED", "CANCELLED"}:
        return {
            "lifecycle_stage": "failed",
            "product_state": "terminal_failed",
            "lifecycle_terminal": True,
            "next_step": "create_new_intent",
            "next_action": _canonical_next_action(
                product_state="terminal_failed",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="terminal_failed",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "The payment path finished without crediting funds. "
                "Create a new intent only for a new attempt."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    if external_tx_hash:
        return {
            "lifecycle_stage": "network_seen",
            "product_state": "pending_external",
            "lifecycle_terminal": False,
            "next_step": "wait_network",
            "next_action": _canonical_next_action(
                product_state="pending_external",
                purpose=purpose,
            ),
            "return_path": _canonical_return_path(
                product_state="pending_external",
            ),
            "canonical_center": "web_profile",
            "user_message": (
                "The external transaction was already detected. "
                "Wait for confirmation and processing completion."
            ),
            "watcher_status": watcher_status,
            "watcher_tx_hash": watcher_tx_hash,
            "watcher_last_error": watcher_last_error,
            "order_id": order_id,
            "order_status": order_status,
            "payment_error_log": payment_error_log,
        }

    return {
        "lifecycle_stage": "initiated",
        "product_state": "active",
        "lifecycle_terminal": False,
        "next_step": "pay_or_wait",
        "next_action": _canonical_next_action(
            product_state="active",
            purpose=purpose,
        ),
        "return_path": _canonical_return_path(
            product_state="active",
        ),
        "canonical_center": "web_profile",
        "user_message": (
            "The intent was created. If you already sent the payment, "
            "wait for network confirmation. If not, use the current "
            "memo and address."
        ),
        "watcher_status": watcher_status,
        "watcher_tx_hash": watcher_tx_hash,
        "watcher_last_error": watcher_last_error,
        "order_id": order_id,
        "order_status": order_status,
        "payment_error_log": payment_error_log,
    }


def _ttl_minutes() -> int:
    val = getattr(S, "PAYMENT_INTENT_TTL_MIN", 15)
    try:
        n = int(val or 15)
    except Exception:
        n = 15
    return max(5, min(60, n))


def _ton_to_nano_from_d8(amount_d8: Decimal) -> str:
    """TON: D8 → nanotons (1e9), ROUND_DOWN."""
    amt = d8(amount_d8)
    nano = (amt * Decimal("1000000000")).quantize(
        Decimal("1"),
        rounding=ROUND_DOWN,
    )
    try:
        return str(int(nano))
    except Exception:
        return "0"


def _usdt_to_units_from_d8(amount_d8: Decimal) -> str:
    """USDT jetton: D8 → units (1e6), ROUND_DOWN.

    Примечание:
    • В проекте суммы хранятся как Decimal D8.
    • Для USDT (jetton) on-chain обычно используется 6 decimals.
    """
    amt = d8(amount_d8)
    units = (amt * Decimal("1000000")).quantize(
        Decimal("1"),
        rounding=ROUND_DOWN,
    )
    try:
        return str(int(units))
    except Exception:
        return "0"


def get_usdt_checkout_mode() -> str:
    """Server-truth runtime mode for USDT checkout."""
    return "tep74_live"


async def _assert_pending_intent_limit(
    db: AsyncSession,
    *,
    global_id: int,
    purpose: str,
) -> None:
    result = await db.execute(
        text(
            "SELECT count(*) FROM efhc_core.payment_intents "
            "WHERE global_id = :global_id AND purpose = :purpose "
            "AND status = 'PENDING' AND expires_at > NOW()"
        ),
        {"global_id": int(global_id), "purpose": str(purpose)},
    )
    if int(result.scalar() or 0) >= int(PENDING_INTENT_LIMIT):
        raise ValueError("PENDING_INTENT_LIMIT_REACHED")



def _b64_text(s: str) -> str:
    """Base64-encode text for TonConnect payload field."""
    raw = (s or "").encode("utf-8")
    return base64.b64encode(raw).decode("ascii")


_PI_SEQUENCE_EXPR = "pg_get_serial_sequence(:pi_table, 'id')"

def build_payload(
    *,
    purpose: str,
    intent_id: int,
    tg_id: int | None = None,
    global_id: int | None = None,
) -> str:
    """Build a provider or canonical-global payment payload."""
    if tg_id is not None:
        owner_token = str(int(tg_id))
    elif global_id is not None:
        owner_token = f"G{int(global_id):010d}"
    else:
        raise ValueError("PAYMENT_INTENT_OWNER_REQUIRED")
    return f"EFHC:{purpose}:{int(intent_id)}:{owner_token}"



def build_transport_meta(*, asset: str, payload: str) -> dict[str, Any]:
    asset_u = str(asset or "TON").upper()
    if asset_u == "TON":
        return {
            "tonconnect_transport_kind": "native_ton",
            "jetton_master_address": None,
            "jetton_decimals": None,
            "forward_payload_text": str(payload),
            "fee_message_ton_amount": None,
            "forward_ton_amount": None,
            "recipient_strategy": None,
            "usdt_checkout_mode": get_usdt_checkout_mode(),
        }

    if asset_u == "USDT":
        return {
            "tonconnect_transport_kind": "jetton_transfer",
            "jetton_master_address": (
                str(getattr(S, "USDT_JETTON_MASTER_ADDRESS", "") or "")
                or None
            ),
            "jetton_decimals": 6,
            "forward_payload_text": str(payload),
            "fee_message_ton_amount": (
                str(getattr(S, "JETTON_TRANSFER_FEE_NANO", "") or "")
                or None
            ),
            "forward_ton_amount": (
                str(
                    getattr(
                        S,
                        "JETTON_FORWARD_TON_AMOUNT_NANO",
                        "1",
                    )
                    or "1"
                )
            ),
            "recipient_strategy": "owner_derived_wallet",
            "usdt_checkout_mode": get_usdt_checkout_mode(),
        }

    return {
        "tonconnect_transport_kind": None,
        "jetton_master_address": None,
        "jetton_decimals": None,
        "forward_payload_text": str(payload),
        "fee_message_ton_amount": None,
        "forward_ton_amount": None,
        "recipient_strategy": None,
        "usdt_checkout_mode": get_usdt_checkout_mode(),
    }


@dataclass
class TonConnectTx:
    validUntil: int
    messages: list[dict[str, str]]


def build_tonconnect_tx(
    *,
    to_address: str,
    amount_asset_d8: Decimal,
    payload: str,
    asset: str,
) -> dict[str, Any] | None:
    """Собирает TonConnect transaction dict.

    TON transaction is returned directly. USDT returns transport
    metadata and is assembled as a TEP-74 transfer by the connected
    browser wallet.
    """
    asset_u = (asset or "TON").upper()
    ttl_sec = _ttl_minutes() * 60
    valid_until = int(time.time()) + int(ttl_sec)

    if asset_u == "TON":
        msg = {
            "address": str(to_address or "").strip(),
            "amount": _ton_to_nano_from_d8(amount_asset_d8),
            "payload": str(payload),
        }
        return {"validUntil": valid_until, "messages": [msg]}

    if asset_u == "USDT":
        # Payload TEP-74 собирается на клиенте, потому что кошелёк
        # отправителя jetton зависит от подключённого кошелька.
        return None

    raise ValueError("ASSET_NOT_SUPPORTED")


def _payments_receiver_address() -> str:
    value = (
        getattr(S, "PAYMENTS_RECEIVER_ADDRESS", "")
        or getattr(S, "TON_WALLET", "")
        or getattr(S, "TON_MAIN_WALLET", "")
        or getattr(S, "MAIN_WALLET", "")
        or ""
    ).strip()
    if not value:
        raise ValueError("TO_ADDRESS_NOT_SET")
    return value


async def _create_intent_row(
    db: AsyncSession,
    *,
    owner: FinancialWriteOwner,
    purpose: str,
    package_id: int | None,
    asset: str,
    amount_asset_d8: Decimal,
    efhc_amount_d8: Decimal,
    idempotency_key: str,
    to_address: str,
) -> dict[str, Any]:
    await _assert_pending_intent_limit(
        db, global_id=owner.global_id, purpose=purpose
    )
    now = utcnow()
    expires_at = now + timedelta(minutes=_ttl_minutes())
    next_id = int(
        (
            await db.execute(
                text("SELECT nextval(" + _PI_SEQUENCE_EXPR + ")"),
                {"pi_table": PI_SEQUENCE_OWNER},
            )
        ).scalar_one()
    )
    payload = build_payload(
        purpose=purpose,
        intent_id=next_id,
        tg_id=owner.legacy_tg_id,
        global_id=owner.global_id,
    )
    row = (
        await db.execute(
            text(
                """
                INSERT INTO efhc_core.payment_intents (
                    id, tg_id, global_id, purpose, package_id, asset,
                    amount_asset_d8, efhc_amount_d8, status,
                    idempotency_key, payload, to_address,
                    external_tx_hash, created_at, expires_at, updated_at
                ) VALUES (
                    :id, :tg_id, :global_id, :purpose, :package_id,
                    :asset, :amount_asset_d8, :efhc_amount_d8, :status,
                    :idempotency_key, :payload, :to_address, NULL,
                    :now, :expires_at, :now
                )
                ON CONFLICT (global_id, purpose, idempotency_key)
                DO NOTHING
                RETURNING *
                """
            ),
            {
                "id": next_id,
                "tg_id": owner.legacy_tg_id,
                "global_id": owner.global_id,
                "purpose": purpose,
                "package_id": package_id,
                "asset": asset,
                "amount_asset_d8": d8(amount_asset_d8),
                "efhc_amount_d8": d8(efhc_amount_d8),
                "status": STATUS_PENDING,
                "idempotency_key": idempotency_key,
                "payload": payload,
                "to_address": to_address,
                "now": now,
                "expires_at": expires_at,
            },
        )
    ).mappings().first()
    if row is None:
        row = (
            await db.execute(
                text(
                    """
                    SELECT * FROM efhc_core.payment_intents
                     WHERE global_id = :global_id
                       AND purpose = :purpose
                       AND idempotency_key = :idempotency_key
                     LIMIT 1
                    """
                ),
                {
                    "global_id": owner.global_id,
                    "purpose": purpose,
                    "idempotency_key": idempotency_key,
                },
            )
        ).mappings().first()
    if row is None:
        raise ValueError("INTENT_CREATE_FAILED")
    await db.commit()
    return dict(row)


def _intent_response(
    *,
    owner: FinancialWriteOwner,
    row: dict[str, Any],
    asset: str,
    amount_asset_d8: Decimal,
    efhc_amount_d8: Decimal,
    to_address: str,
) -> dict[str, Any]:
    payload = str(row["payload"])
    tx = build_tonconnect_tx(
        to_address=to_address,
        amount_asset_d8=amount_asset_d8,
        payload=payload,
        asset=asset,
    )
    result: dict[str, Any] = {
        "intent_id": int(row["id"]),
        "global_id": f"{owner.global_id:010d}",
        "tg_id": owner.legacy_tg_id,
        "purpose": str(row["purpose"]),
        "asset": asset,
        "amount_asset_d8": str(d8(amount_asset_d8)),
        "efhc_amount_d8": str(d8(efhc_amount_d8)),
        "to_address": to_address,
        "tonconnect_tx": tx,
        "payload": payload,
        "expires_at": row["expires_at"],
    }
    result.update(build_transport_meta(asset=asset, payload=payload))
    return result


async def create_intent_deposit_by_package(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    idempotency_key: str,
    package_id: int,
) -> dict[str, Any]:
    """Create an idempotent package intent for canonical owner."""
    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")
    owner = await resolve_and_lock_financial_write_owner(
        db, global_id=global_id, tg_id=tg_id
    )
    from app.models.shop_models import ShopItem  # noqa: WPS433
    from sqlalchemy import select  # noqa: PLC0415

    obj = (
        await db.execute(
            select(ShopItem)
            .where(ShopItem.id == int(package_id))
            .where(ShopItem.is_active.is_(True))
            .where(ShopItem.quantity_efhc.is_not(None))
            .limit(1)
        )
    ).scalars().first()
    if not obj:
        raise ValueError("PACKAGE_NOT_FOUND")
    extra = obj.extra or {}
    if extra.get("price_asset_d8") is None:
        raise ValueError("PACKAGE_PRICE_NOT_SET")
    asset = str(extra.get("asset") or "TON").upper()
    if asset not in {"TON", "USDT"}:
        raise ValueError("ASSET_NOT_SUPPORTED")
    to_address = _payments_receiver_address()
    amount_asset = d8(extra.get("price_asset_d8"))
    efhc_amount = d8(obj.quantity_efhc)
    row = await _create_intent_row(
        db,
        owner=owner,
        purpose="deposit_efhc",
        package_id=int(package_id),
        asset=asset,
        amount_asset_d8=amount_asset,
        efhc_amount_d8=efhc_amount,
        idempotency_key=str(idempotency_key),
        to_address=to_address,
    )
    return _intent_response(
        owner=owner, row=row, asset=asset,
        amount_asset_d8=amount_asset, efhc_amount_d8=efhc_amount,
        to_address=to_address,
    )



async def create_intent_deposit_custom(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    idempotency_key: str,
    asset: str,
    amount_asset_d8: Decimal,
    efhc_amount_d8: Decimal,
) -> dict[str, Any]:
    """Create custom deposit intent for canonical owner."""
    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")
    owner = await resolve_and_lock_financial_write_owner(
        db, global_id=global_id, tg_id=tg_id
    )
    asset_u = str(asset or "TON").upper()
    if asset_u not in {"TON", "USDT"}:
        raise ValueError("ASSET_NOT_SUPPORTED")
    amount_asset = d8(amount_asset_d8)
    efhc_amount = d8(efhc_amount_d8)
    to_address = _payments_receiver_address()
    row = await _create_intent_row(
        db, owner=owner, purpose="deposit_efhc", package_id=None,
        asset=asset_u, amount_asset_d8=amount_asset,
        efhc_amount_d8=efhc_amount,
        idempotency_key=str(idempotency_key),
        to_address=to_address,
    )
    return _intent_response(
        owner=owner, row=row, asset=asset_u,
        amount_asset_d8=amount_asset, efhc_amount_d8=efhc_amount,
        to_address=to_address,
    )



async def create_intent_shop_external(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    idempotency_key: str,
    asset: str,
    amount_asset_d8: Decimal,
    to_address: str,
) -> dict[str, Any]:
    """Create shop payment intent for canonical owner."""
    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")
    owner = await resolve_and_lock_financial_write_owner(
        db, global_id=global_id, tg_id=tg_id
    )
    asset_u = str(asset or "TON").upper()
    if asset_u not in {"TON", "USDT"}:
        raise ValueError("ASSET_NOT_SUPPORTED")
    amount_asset = d8(amount_asset_d8)
    target = str(to_address or "").strip()
    if not target:
        raise ValueError("TO_ADDRESS_NOT_SET")
    row = await _create_intent_row(
        db, owner=owner, purpose="shop_external", package_id=None,
        asset=asset_u, amount_asset_d8=amount_asset,
        efhc_amount_d8=d8("0"),
        idempotency_key=str(idempotency_key),
        to_address=target,
    )
    return _intent_response(
        owner=owner, row=row, asset=asset_u,
        amount_asset_d8=amount_asset, efhc_amount_d8=d8("0"),
        to_address=target,
    )



async def list_recent_intents_for_user(
    db: AsyncSession,
    *,
    global_id: int,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Возвращает последние payment intents пользователя.

    Используется для web-profile как канонического account center.
    """
    if limit < 1:
        limit = 1
    if limit > 50:
        limit = 50

    q = text(
        "\n".join(
            [
                "SELECT id",
                "  FROM efhc_core.payment_intents",
                " WHERE tg_id = :tg",
                " ORDER BY id DESC",
                " LIMIT :lim",
            ]
        )
    )
    rows = (
        (
            await db.execute(
                q,
                {
                    "tg": int(global_id),
                    "lim": int(limit),
                },
            )
        )
        .mappings()
        .all()
    )

    out: list[dict[str, Any]] = []
    for row in rows:
        item = await get_intent_status_for_user(
            db,
            global_id=int(global_id),
            intent_id=int(row["id"]),
        )
        if item.get("ok"):
            out.append(item)
    return out


async def get_intent_status_for_user(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    intent_id: int,
) -> dict[str, Any]:
    """Возвращает статус payment intent для владельца.

    Безопасность:
    • intent доступен только подтверждённому account owner.
    """
    if (tg_id is None) == (global_id is None):
        raise ValueError("Требуется ровно один owner selector")
    if global_id is not None:
        q = text(
            "\n".join(
                [
                    "SELECT id, tg_id, purpose, asset,",
                    "       amount_asset_d8::numeric,",
                    "       efhc_amount_d8::numeric,",
                    "       status, payload, to_address,",
                    "       external_tx_hash,",
                    "       created_at, expires_at",
                    "  FROM efhc_core.payment_intents",
                    " WHERE id = :iid AND global_id = :global_id",
                    " LIMIT 1",
                ]
            )
        )
        params = {
            "iid": int(intent_id),
            "global_id": int(global_id),
        }
    else:
        q = text(
            "\n".join(
                [
                    "SELECT id, tg_id, purpose, asset,",
                    "       amount_asset_d8::numeric,",
                    "       efhc_amount_d8::numeric,",
                    "       status, payload, to_address,",
                    "       external_tx_hash,",
                    "       created_at, expires_at",
                    "  FROM efhc_core.payment_intents",
                    " WHERE id = :iid AND tg_id = :tg",
                    " LIMIT 1",
                ]
            )
        )
        params = {"iid": int(intent_id), "tg": int(tg_id or 0)}
    row = (await db.execute(q, params)).mappings().first()

    if not row:
        return {"ok": False}

    order = None
    if str(row.get("purpose") or "") == "shop_external":
        order_q = text(
            "\n".join(
                [
                    "SELECT id, status, payment_error_log",
                    "  FROM efhc_core.shop_orders",
                    " WHERE tg_id = :tg",
                    "   AND (extra ->> 'intent_id') = :iid",
                    " ORDER BY id DESC",
                    " LIMIT 1",
                ]
            )
        )
        order = (
            (
                await db.execute(
                    order_q,
                    {
                        "tg": int(row.get("tg_id") or 0),
                        "iid": str(intent_id),
                    },
                )
            )
            .mappings()
            .first()
        )

    inbox_q = text(
        "\n".join(
            [
                "SELECT tx_hash, status, last_error",
                "  FROM efhc_core.ton_inbox_logs",
                " WHERE memo = :memo",
                "    OR tx_hash = :tx_hash",
                " ORDER BY created_at DESC, id DESC",
                " LIMIT 1",
            ]
        )
    )
    inbox_row = (
        (
            await db.execute(
                inbox_q,
                {
                    "memo": str(row.get("payload") or ""),
                    "tx_hash": str(row.get("external_tx_hash") or ""),
                },
            )
        )
        .mappings()
        .first()
    )
    inbox = dict(inbox_row) if inbox_row else None

    order_map = dict(order) if order is not None else None

    flow_truth = _build_intent_flow_truth(
        purpose=str(row.get("purpose") or ""),
        intent_status=str(row.get("status") or ""),
        expires_at=row.get("expires_at"),
        external_tx_hash=(
            str(row.get("external_tx_hash") or "") or None
        ),
        order=order_map,
        inbox=inbox,
    )

    out = {
        "ok": True,
        "id": int(row["id"]),
        "tg_id": int(row["tg_id"]),
        "purpose": str(row["purpose"]),
        "asset": str(row["asset"]),
        "amount_asset_d8": str(row["amount_asset_d8"]),
        "efhc_amount_d8": (
            str(row["efhc_amount_d8"])
            if row["efhc_amount_d8"] is not None
            else None
        ),
        "status": str(row["status"]),
        "payload": str(row["payload"]),
        "to_address": str(row["to_address"]),
        "external_tx_hash": (
            str(row["external_tx_hash"])
            if row["external_tx_hash"]
            else None
        ),
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
        "flow_truth": flow_truth,
    }
    out.update(
        build_transport_meta(
            asset=str(row["asset"]),
            payload=str(row["payload"]),
        )
    )
    return out
