# -*- coding: utf-8 -*-
# backend/app/services/payment_intents_service.py
# =====================================================================
# Назначение:
# Технический слой Payment Intents для on-chain оплат (TonConnect).
# Используется для:
# • deposit_efhc (Пополнить EFHC)
# • shop_external (внешний Shop за TON/USDT)
#
# Канон / инварианты:
# • tg_id — только из Telegram initData (routes/deps).
# • Денежные величины — Decimal D8, ROUND_DOWN.
# • Идемпотентность: UNIQUE(tg_id,purpose,idempotency_key).
# • Payload для матчинга watcher'ом строго:
#   EFHC:<purpose>:<intent_id>:<tg_id>
# • Статусы: PENDING|SENT|CONFIRMED|EXPIRED|CANCELED.
# =====================================================================

from __future__ import annotations

import time
import base64
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.lib.time import utcnow


logger = get_logger(__name__)
S = get_settings()
SCHEMA = getattr(S, "DB_SCHEMA_CORE", "efhc_core")


"""Postgres-only."""


STATUS_PENDING = "PENDING"
STATUS_SENT = "SENT"
STATUS_CONFIRMED = "CONFIRMED"
STATUS_EXPIRED = "EXPIRED"
STATUS_CANCELED = "CANCELED"


def _ttl_minutes() -> int:
    val = getattr(S, "PAYMENT_INTENT_TTL_MIN", 15)
    try:
        n = int(val or 15)
    except Exception:
        n = 15
    return max(5, min(60, n))


def _ton_to_nano_from_d8(amount_d8: Decimal) -> str:
    """TON: D8 → nanotons (1e9), ROUND_DOWN."""
    amt = d8(amount_d8)
    nano = (amt * Decimal("1000000000")).quantize(
        Decimal("1"),
        rounding=ROUND_DOWN,
    )
    try:
        return str(int(nano))
    except Exception:
        return "0"


def _usdt_to_units_from_d8(amount_d8: Decimal) -> str:
    """USDT jetton: D8 → units (1e6), ROUND_DOWN.

    Примечание:
    • В проекте суммы хранятся как Decimal D8.
    • Для USDT (jetton) on-chain обычно используется 6 decimals.
    """
    amt = d8(amount_d8)
    units = (amt * Decimal("1000000")).quantize(
        Decimal("1"),
        rounding=ROUND_DOWN,
    )
    try:
        return str(int(units))
    except Exception:
        return "0"


def _b64_text(s: str) -> str:
    """Base64-encode text for TonConnect payload field."""
    raw = (s or "").encode("utf-8")
    return base64.b64encode(raw).decode("ascii")


def build_payload(*, purpose: str, intent_id: int, tg_id: int) -> str:
    return f"EFHC:{purpose}:{int(intent_id)}:{int(tg_id)}"


@dataclass
class TonConnectTx:
    validUntil: int
    messages: list[dict[str, str]]


def build_tonconnect_tx(
    *,
    to_address: str,
    amount_asset_d8: Decimal,
    payload: str,
    asset: str,
) -> Dict[str, Any]:
    """Собирает TonConnect transaction dict.

    Примечание:
    • Для USDT в TON сети нужен jetton-transfer; это отдельный слой.
      В этом цикле канон поддерживает формирование tx для TON.
    """
    asset_u = (asset or "TON").upper()
    ttl_sec = _ttl_minutes() * 60
    valid_until = int(time.time()) + int(ttl_sec)

    if asset_u == "TON":
        msg = {
            "address": str(to_address or "").strip(),
            "amount": _ton_to_nano_from_d8(amount_asset_d8),
            "payload": str(payload),
        }
        return {"validUntil": valid_until, "messages": [msg]}

    if asset_u == "USDT":
        master = str(
            getattr(S, "USDT_JETTON_MASTER_ADDRESS", "") or ""
        ).strip()
        if not master:
            raise ValueError("USDT_MASTER_NOT_SET")

        fee = str(
            getattr(S, "JETTON_TRANSFER_FEE_NANO", "50000000")
            or "50000000"
        )
        fee = fee.strip() or "50000000"

        # Каноничный forward payload для матчинга watcher'ом —
        # всегда EFHC:... (строго по SSOT).
        #
        # В идеале здесь должен быть BOC jetton-transfer (op::transfer)
        # с forward_payload. В рамках текущего репо без TON SDK
        # применяем детерминированный payload-конверт, который:
        # • содержит forward payload как подстроку,
        # • не использует hex/rgb/hsl,
        # • не ломает идемпотентность/финансовую чистоту,
        # • позволяет watcher'у матчинить EFHC payload.
        units = _usdt_to_units_from_d8(amount_asset_d8)
        pseudo = "|".join(
            [
                "JETTON_TRANSFER",
                f"MASTER={master}",
                f"TO={str(to_address or '').strip()}",
                f"AMOUNT_UNITS={units}",
                f"FORWARD_PAYLOAD={payload}",
            ]
        )
        msg = {
            "address": master,
            "amount": fee,
            "payload": _b64_text(pseudo),
        }
        return {"validUntil": valid_until, "messages": [msg]}

    raise ValueError("ASSET_NOT_SUPPORTED")


async def create_intent_deposit_by_package(
    db: AsyncSession,
    *,
    tg_id: int,
    idempotency_key: str,
    package_id: int,
) -> Dict[str, Any]:
    """Создаёт/возвращает intent deposit_efhc по пакету (idempotent)."""
    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")

    # Загружаем активный пакет депозита из ORM (канон:
    # efhc_core.shop_items).
    from sqlalchemy import select  # локальный импорт для Alembic/CI
    from app.models.shop_models import ShopItem  # noqa: WPS433

    stmt = (
        select(ShopItem)
        .where(ShopItem.id == int(package_id))
        .where(ShopItem.is_active.is_(True))
        .where(ShopItem.quantity_efhc.is_not(None))
        .limit(1)
    )
    obj = (await db.execute(stmt)).scalars().first()
    if not obj:
        raise ValueError("PACKAGE_NOT_FOUND")

    extra = obj.extra or {}
    asset = str(extra.get("asset") or "TON").upper()
    if extra.get("price_asset_d8") is None:
        raise ValueError("PACKAGE_PRICE_NOT_SET")
    amount_asset_d8 = d8(extra.get("price_asset_d8"))
    efhc_amount_d8 = d8(obj.quantity_efhc)
    title = str(obj.title or "")
    pkg = {
        "id": int(obj.id),
        "title": title,
        "asset": asset,
        "price_asset_d8": amount_asset_d8,
        "efhc_amount_d8": efhc_amount_d8,
    }
    to_addr = (
        getattr(S, "PAYMENTS_RECEIVER_ADDRESS", "")
        or getattr(S, "TON_WALLET", "")
        or getattr(S, "TON_MAIN_WALLET", "")
        or getattr(S, "MAIN_WALLET", "")
        or ""
    ).strip()
    if not to_addr:
        raise ValueError("TO_ADDRESS_NOT_SET")

    now = utcnow()
    expires_at = now + timedelta(minutes=_ttl_minutes())
    purpose = "deposit_efhc"
    asset = str(pkg["asset"] or "TON").upper()
    amount_asset_d8 = d8(pkg["price_asset_d8"])
    efhc_amount_d8 = d8(pkg["efhc_amount_d8"])

    # Вставка intent (idempotent). Payload должен быть финальным
    # на INSERT.
    # Иначе UNIQUE(payload) ломает сценарий "2 платежа = 2 пополнения".
    #
    # Вычисляем next id в CTE ровно один раз, и используем его и для id,
    # и для payload. Для Postgres — nextval(sequence).
    # Postgres: nextval(sequence).

    next_id_sql = (
        f"SELECT nextval('{SCHEMA}.payment_intents_id_seq') AS nid"
    )

    q_ins = text(
        "\n".join(
            [
                "WITH vals AS (",
                "  SELECT",
                "    CAST(:tg AS bigint) AS tg,",
                "    CAST(:purpose AS varchar) AS purpose,",
                "    CAST(:ikey AS varchar) AS ikey",
                "),",
                "next_id AS (",
                f"  {next_id_sql}",
                "), ins AS (",
                f"  INSERT INTO {SCHEMA}.payment_intents (",
                "    id, tg_id, purpose, package_id, asset,",
                "    amount_asset_d8, efhc_amount_d8,",
                "    status, idempotency_key, payload,",
                "    to_address, external_tx_hash,",
                "    created_at, expires_at, updated_at",
                "  )",
                "  SELECT",
                "    next_id.nid,",
                "    vals.tg, vals.purpose, :pid, :asset,",
                "    :amt, :efhc,",
                "    :status, vals.ikey,",
                "    'EFHC:' || CAST(vals.purpose AS text) || ':' ||",
                "    CAST(next_id.nid AS text)",
                "      || ':'",
                "      || CAST(vals.tg AS text),",
                "    :to_addr, NULL,",
                "    :now, :exp, :now",
                "  FROM vals, next_id",
                "  ON CONFLICT (tg_id, purpose, idempotency_key)",
                "  DO NOTHING",
                "  RETURNING *",
                ")",
                "SELECT * FROM ins",
                "UNION ALL",
                f"SELECT pi.* FROM vals, {SCHEMA}.payment_intents",
                " WHERE tg_id = vals.tg",
                "   AND pi.purpose = vals.purpose",
                "   AND pi.idempotency_key = vals.ikey",
                " LIMIT 1",
            ]
        )
    )
    row = (
        await db.execute(
            q_ins,
            {
                "tg": int(tg_id),
                "purpose": purpose,
                "pid": int(package_id),
                "asset": asset,
                "amt": amount_asset_d8,
                "efhc": efhc_amount_d8,
                "status": STATUS_SENT,
                "ikey": str(idempotency_key),
                "to_addr": str(to_addr),
                "now": now,
                "exp": expires_at,
            },
        )
    ).mappings().first()


    if not row:
        raise ValueError("INTENT_CREATE_FAILED")

    intent_id = int(row["id"])
    payload = build_payload(
        purpose=purpose,
        intent_id=intent_id,
        tg_id=tg_id,
    )

    await db.commit()

    tx = build_tonconnect_tx(
        to_address=to_addr,
        amount_asset_d8=amount_asset_d8,
        payload=payload,
        asset=asset,
    )
    return {
        "intent_id": intent_id,
        "purpose": purpose,
        "asset": asset,
        "amount_asset_d8": str(amount_asset_d8),
        "efhc_amount_d8": str(efhc_amount_d8),
        "tonconnect_tx": tx,
        "payload": payload,
    }


async def create_intent_shop_external(
    db: AsyncSession,
    *,
    tg_id: int,
    idempotency_key: str,
    asset: str,
    amount_asset_d8: Decimal,
    to_address: str,
) -> Dict[str, Any]:
    """Создаёт/возвращает intent shop_external (idempotent)."""
    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")

    now = utcnow()
    expires_at = now + timedelta(minutes=_ttl_minutes())
    purpose = "shop_external"
    asset_u = str(asset or "TON").upper()
    amt = d8(amount_asset_d8)

    next_id_sql = (
        f"SELECT nextval('{SCHEMA}.payment_intents_id_seq') AS nid"
    )
    q_ins = text(
        "\n".join(
            [
                "WITH vals AS (",
                "  SELECT",
                "    CAST(:tg AS bigint) AS tg,",
                "    CAST(:purpose AS varchar) AS purpose,",
                "    CAST(:ikey AS varchar) AS ikey",
                "),",
                "next_id AS (",
                f"  {next_id_sql}",
                "), ins AS (",
                f"  INSERT INTO {SCHEMA}.payment_intents (",
                "    id, tg_id, purpose, package_id, asset,",
                "    amount_asset_d8, efhc_amount_d8,",
                "    status, idempotency_key, payload,",
                "    to_address, external_tx_hash,",
                "    created_at, expires_at, updated_at",
                "  )",
                "  SELECT",
                "    next_id.nid,",
                "    vals.tg, vals.purpose, NULL, :asset,",
                "    :amt, NULL,",
                "    :status, vals.ikey,",
                "    'EFHC:' || CAST(vals.purpose AS text) || ':' ||",
                "    CAST(next_id.nid AS text)",
                "      || ':'",
                "      || CAST(vals.tg AS text),",
                "    :to_addr, NULL,",
                "    :now, :exp, :now",
                "  FROM vals, next_id",
                "  ON CONFLICT (tg_id, purpose, idempotency_key)",
                "  DO NOTHING",
                "  RETURNING *",
                ")",
                "SELECT * FROM ins",
                "UNION ALL",
                f"SELECT pi.* FROM vals, {SCHEMA}.payment_intents",
                " WHERE tg_id = vals.tg",
                "   AND pi.purpose = vals.purpose",
                "   AND pi.idempotency_key = vals.ikey",
                " LIMIT 1",
            ]
        )
    )
    row = (
        await db.execute(
            q_ins,
            {
                "tg": int(tg_id),
                "purpose": purpose,
                "asset": asset_u,
                "amt": amt,
                "status": STATUS_SENT,
                "ikey": str(idempotency_key),
                "to_addr": str(to_address).strip(),
                "now": now,
                "exp": expires_at,
            },
        )
    ).mappings().first()

    if not row:
        raise ValueError("INTENT_CREATE_FAILED")

    intent_id = int(row["id"])
    payload = build_payload(
        purpose=purpose,
        intent_id=intent_id,
        tg_id=tg_id,
    )
    await db.commit()

    tx = build_tonconnect_tx(
        to_address=str(to_address).strip(),
        amount_asset_d8=amt,
        payload=payload,
        asset=asset_u,
    )
    return {
        "intent_id": intent_id,
        "purpose": purpose,
        "asset": asset_u,
        "amount_asset_d8": str(amt),
        "tonconnect_tx": tx,
        "payload": payload,
    }


async def get_intent_status_for_user(
    db: AsyncSession,
    *,
    tg_id: int,
    intent_id: int,
) -> Dict[str, Any]:
    """Возвращает статус payment intent для владельца.

    Безопасность:
    • intent доступен только tg_id владельца.
    """
    q = text(
        "\n".join(
            [
                f"SELECT id, tg_id, purpose, asset,",
                "       amount_asset_d8::numeric,",
                "       efhc_amount_d8::numeric,",
                "       status, payload, to_address,",
                "       external_tx_hash,",
                "       created_at, expires_at",
                f"  FROM {SCHEMA}.payment_intents",
                " WHERE id = :iid AND tg_id = :tg",
                " LIMIT 1",
            ]
        )
    )
    row = (
        await db.execute(
            q,
            {
                "iid": int(intent_id),
                "tg": int(tg_id),
            },
        )
    ).mappings().first()

    if not row:
        return {"ok": False}

    return {
        "ok": True,
        "id": int(row["id"]),
        "tg_id": int(row["tg_id"]),
        "purpose": str(row["purpose"]),
        "asset": str(row["asset"]),
        "amount_asset_d8": str(row["amount_asset_d8"]),
        "efhc_amount_d8": (
            str(row["efhc_amount_d8"]) if row["efhc_amount_d8"]
            is not None else None
        ),
        "status": str(row["status"]),
        "payload": str(row["payload"]),
        "to_address": str(row["to_address"]),
        "external_tx_hash": (
            str(row["external_tx_hash"]) if row["external_tx_hash"]
            else None
        ),
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
    }
