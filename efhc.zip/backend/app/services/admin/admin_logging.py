# -*- coding: utf-8 -*-
# backend/app/services/admin/admin_logging.py
# ======================================================================
# EFHC Bot — Логи действий администраторов
# ======================================================================

from __future__ import annotations

import json
from typing import Any, Optional

from pydantic import BaseModel, Field

from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
S = get_settings()

SCHEMA_CORE: str = (
    S.DB_SCHEMA_CORE or "efhc_core"
)


class AdminLog(BaseModel):
    """Одна запись в журнале действий админов."""

    id: int = Field(...)
    admin_id: int = Field(...)
    action: str = Field(..., min_length=1, max_length=128)
    entity: str = Field(..., min_length=1, max_length=128)
    entity_id: Optional[int] = None
    timestamp: str = Field(...)
    details: Optional[str] = None


class Pagination(BaseModel):
    """Параметры пагинации для админ-логов (SSOT)."""

    limit: int = Field(50, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = Field(True)

class AdminLogger:
    """Сервис логирования действий администраторов."""

@staticmethod
async def list(
    db: AsyncSession,
    *,
    pg: Pagination,
    admin_id: Optional[int] = None,
    action: Optional[str] = None,
    entity: Optional[str] = None,
) -> list[AdminLog]:
    """SSOT-обёртка над list_logs (ожидается фасадом/тестами)."""
    return await AdminLogger.list_logs(
        db,
        limit=int(pg.limit),
        offset=int(pg.offset),
        sort_desc=bool(pg.sort_desc),
        admin_id=admin_id,
        action=action,
        entity=entity,
    )


    @staticmethod
    async def write(
        db: AsyncSession,
        *,
        admin_id: int,
        action: str,
        entity: str,
        entity_id: Optional[int] = None,
        details: Optional[str] = None,
    ) -> None:
        try:
            if admin_id <= 0:
                logger.warning(
                    "AdminLogger.write: bad admin_id=%s",
                    admin_id,
                )
                return

            action_s = str(action or "").strip()[:128]
            entity_s = str(entity or "").strip()[:128]

            details_s: Optional[str]
            if details is None:
                details_s = None
            else:
                details_s = str(details)[:4000]

            if not action_s or not entity_s:
                logger.warning(
                    "AdminLogger.write: empty "
                    "action/entity admin_id=%s",
                    admin_id,
                )
                return

            sql = text(
                "\n".join(
                    [
                        f"INSERT INTO {SCHEMA_CORE}.admin_action_log",
                        "(admin_id, action, target_type, target_id, details_json)",
                        "VALUES (:admin_id, :action, :target_type, :target_id, :details_json::jsonb)",
                    ]
                )
            )

            entity_id_val: Optional[int]
            if entity_id is None:
                entity_id_val = None
            else:
                entity_id_val = int(entity_id)

            details_json_val = None if details_s is None else json.dumps({"details": details_s})

            await db.execute(
                sql,
                {
                    "admin_id": int(admin_id),
                    "action": action_s,
                    "target_type": entity_s,
                    "target_id": None if entity_id_val is None else str(entity_id_val),
                    "details_json": details_json_val,
                },
            )
        except Exception as e:
            logger.error(
                "AdminLogger.write: insert failed admin_id=%s: %s",
                admin_id,
                e,
            )

    @staticmethod
    async def list_logs(
        db: AsyncSession,
        *,
        limit: int = 50,
        offset: int = 0,
        sort_desc: bool = True,
        admin_id: Optional[int] = None,
        action: Optional[str] = None,
        entity: Optional[str] = None,
    ) -> list[AdminLog]:
        if limit < 1:
            limit = 1
        if limit > 500:
            limit = 500
        if offset < 0:
            offset = 0

        where: list[str] = ["1 = 1"]
        params: dict[str, Any] = {"limit": limit, "offset": offset}

        if admin_id is not None:
            where.append("admin_id = :aid")
            params["aid"] = int(admin_id)

        if action:
            where.append("action = :act")
            params["act"] = str(action).strip()[:128]

        if entity:
            where.append("target_type = :ent")
            params["ent"] = str(entity).strip()[:128]

        order = "DESC" if sort_desc else "ASC"

        sql = text(
            "\n".join(
                [
                    "SELECT id, admin_id, action, entity, entity_id,",
                    "timestamp, details",
                    f"FROM {SCHEMA_CORE}.admin_action_log",
                    f"WHERE {' AND '.join(where)}",
                    f"ORDER BY id {order}",
                    "LIMIT :limit OFFSET :offset",
                ]
            )
        )

        r: Result = await db.execute(sql, params)
        rows = r.fetchall()

        out: list[AdminLog] = []
        for row in rows:
            try:
                ent_id = getattr(row, "entity_id", None)
                if ent_id is None:
                    entity_id_out = None
                else:
                    entity_id_out = int(ent_id)

                ts = getattr(row, "timestamp", None)
                if hasattr(ts, "isoformat"):
                    ts_out = ts.isoformat()
                else:
                    ts_out = str(ts)

                det = getattr(row, "details", None)
                if det is None:
                    details_out = None
                elif isinstance(det, dict) and "details" in det:
                    details_out = str(det.get("details"))
                else:
                    try:
                        details_out = json.dumps(det, ensure_ascii=False)[:4000]
                    except Exception:
                        details_out = str(det)[:4000]

                out.append(
                    AdminLog(
                        id=int(getattr(row, "id")),
                        admin_id=int(getattr(row, "admin_id")),
                        action=str(getattr(row, "action")),
                        entity=str(getattr(row, "entity")),
                        entity_id=entity_id_out,
                        timestamp=ts_out,
                        details=details_out,
                    )
                )
            except Exception as e:
                logger.warning(
                    "AdminLogger.list_logs: skip broken row: %s",
                    e,
                )

        return out


__all__ = ["AdminLog", "AdminLogger", "Pagination"]