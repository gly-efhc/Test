# -*- coding: utf-8 -*-
# backend/app/services/admin/admin_logging.py
# =====================================================================
# EFHC Bot — Аудит действий администраторов (admin_action_log)
#
# Канон:
# - Таблица: efhc_admin.admin_action_log (ORM: AdminActionLog)
# - Любые админ-действия логируются.
# - Логирование best-effort: не ломает основную операцию.
# =====================================================================

from __future__ import annotations

import json
from typing import Any, Optional

from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger

logger = get_logger(__name__)
S = get_settings()

SCHEMA_ADMIN: str = (
    getattr(S, "DB_SCHEMA_ADMIN", "efhc_admin") or "efhc_admin"
)


class AdminLog(BaseModel):
    id: int = Field(...)
    admin_id: Optional[int] = None
    action: str = Field(..., min_length=1, max_length=64)
    target_type: Optional[str] = None
    target_id: Optional[str] = None
    created_at: str = Field(...)
    details_json: Optional[Any] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None


class Pagination(BaseModel):
    limit: int = Field(50, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = Field(True)


class AdminLogger:
    """Сервис логирования действий администраторов."""

    @staticmethod
    async def write(
        db: AsyncSession,
        *,
        admin_id: Optional[int],
        action: str,
        entity: str,
        entity_id: Optional[int] = None,
        details: Optional[str] = None,
        ip: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        """Записать действие админа в efhc_admin.admin_action_log."""
        try:
            action_s = (action or "").strip()[:64]
            target_type_s = (entity or "").strip()[:64] or None
            if entity_id is None:
                target_id_s = None
            else:
                target_id_s = str(int(entity_id))[:128]

            details_s = None if details is None else str(details)[:4000]
            ip_s = None if ip is None else str(ip)[:64]
            ua_s = None if user_agent is None else str(user_agent)[:512]

            if not action_s:
                logger.warning("AdminLogger.write: empty action")
                return

            details_json_val = None
            if details_s is not None:
                details_json_val = json.dumps(
                    {"details": details_s},
                    ensure_ascii=False,
                )

            sql = text(
                "\n".join(
                    [
                        f"INSERT INTO {SCHEMA_ADMIN}.admin_action_log",
                        "(admin_id, action, target_type, target_id,",
                        " details_json, ip, user_agent)",
                        "VALUES (:admin_id, :action, :target_type,",
                        " :target_id, CAST(:details_json AS jsonb),",
                        " :ip,",
                        " :user_agent)",
                    ]
                )
            )

            params = {
                "admin_id": None if admin_id is None else int(admin_id),
                "action": action_s,
                "target_type": target_type_s,
                "target_id": target_id_s,
                "details_json": details_json_val,
                "ip": ip_s,
                "user_agent": ua_s,
            }

            try:
                async with db.begin_nested():
                    await db.execute(sql, params)
                return
            except Exception as e:
                logger.warning(
                    "AdminLogger.write: insert failed"
                    " (admin_id=%s): %s",
                    admin_id,
                    e,
                )

            details_json_val2 = json.dumps(
                {
                    "details": details_s,
                    "admin_id_raw": None
                    if admin_id is None
                    else int(admin_id),
                },
                ensure_ascii=False,
            )
            params2 = dict(params)
            params2["admin_id"] = None
            params2["details_json"] = details_json_val2
            try:
                async with db.begin_nested():
                    await db.execute(sql, params2)
            except Exception as e:
                logger.warning(
                    "AdminLogger.write: fallback insert failed"
                    " (admin_id=%s): %s",
                    admin_id,
                    e,
                )

        except Exception as e:
            logger.error("AdminLogger.write: failed: %s", e)

    @staticmethod
    async def list_logs(
        db: AsyncSession,
        *,
        limit: int = 50,
        offset: int = 0,
        sort_desc: bool = True,
        admin_id: Optional[int] = None,
        action: Optional[str] = None,
        entity: Optional[str] = None,
    ) -> list[AdminLog]:
        if limit < 1:
            limit = 1
        if limit > 500:
            limit = 500
        if offset < 0:
            offset = 0

        where: list[str] = ["1=1"]
        params: dict[str, Any] = {
            "limit": int(limit),
            "offset": int(offset),
        }

        if admin_id is not None:
            where.append("admin_id = :aid")
            params["aid"] = int(admin_id)

        if action:
            where.append("action = :act")
            params["act"] = str(action).strip()[:64]

        if entity:
            where.append("target_type = :tt")
            params["tt"] = str(entity).strip()[:64]

        order = "DESC" if sort_desc else "ASC"

        sql = text(
            "\n".join(
                [
                    "SELECT id, admin_id, action, target_type,",
                    " target_id, details_json, ip, user_agent,",
                    " created_at",
                    f"FROM {SCHEMA_ADMIN}.admin_action_log",
                    f"WHERE {' AND '.join(where)}",
                    f"ORDER BY id {order}",
                    "LIMIT :limit OFFSET :offset",
                ]
            )
        )

        r: Result = await db.execute(sql, params)
        rows = r.fetchall()

        out: list[AdminLog] = []
        for row in rows:
            try:
                ts = getattr(row, "created_at", None)
                if hasattr(ts, "isoformat"):
                    ts_out = ts.isoformat()
                else:
                    ts_out = str(ts)

                det = getattr(row, "details_json", None)
                out.append(
                    AdminLog(
                        id=int(row.id),
                        admin_id=None
                        if row.admin_id is None
                        else int(row.admin_id),
                        action=str(row.action),
                        target_type=getattr(row, "target_type", None),
                        target_id=getattr(row, "target_id", None),
                        created_at=ts_out,
                        details_json=det,
                        ip=getattr(row, "ip", None),
                        user_agent=getattr(row, "user_agent", None),
                    )
                )
            except Exception:
                continue

        return out

    @staticmethod
    async def list(
        db: AsyncSession,
        *,
        pg: Pagination,
        admin_id: Optional[int] = None,
        action: Optional[str] = None,
        entity: Optional[str] = None,
    ) -> list[AdminLog]:
        return await AdminLogger.list_logs(
            db,
            limit=int(pg.limit),
            offset=int(pg.offset),
            sort_desc=bool(pg.sort_desc),
            admin_id=admin_id,
            action=action,
            entity=entity,
        )


__all__ = ["AdminLog", "Pagination", "AdminLogger"]
