# backend/app/services/admin/admin_wallets_service.py
# ======================================================================
# EFHC Bot — Кошельки пользователей (просмотр / привязка / отладка)
# ----------------------------------------------------------------------
# Назначение:
# • Безопасная работа с таблицей crypto_wallets:
# - просмотр кошельков по внутреннему tg_id и по Telegram ID;
# - привязка нового кошелька к пользователю;
# - смена основного (primary) кошелька;
# - мягкая самодиагностика (health) по кошелькам.
#
# Жёсткие инварианты (канон):
# • НИКАКИХ денежных операций здесь нет.
# Только метаданные: chain / address / флаг is_primary.
# • Любые денежные потоки (EFHC, kWh) проходят ТОЛЬКО
# через банковский сервис
# и efhc_transfers_log. Этот модуль не трогает балансы.
# • Привязка кошелька:
# - допускается несколько кошельков на пользователя;
# - только один может быть is_primary=TRUE;
# - повторная привязка того же (tg_id, chain, address) — идемпотентна.
# • Администратор не может «тихо» отобрать кошелёк
# у другого пользователя:
# - при попытке привязать address, уже принадлежащий другому tg_id,
# сервис поднимет WalletOwnershipError;
# - намеренная смена владельца возможна только через отдельный метод
# reassign_wallet(...) с ролью SuperAdmin.
#
# ИИ-защита:
# • Валидация входных данных (обязательные поля,
# нормализация chain/address).
# • Явные ошибки высокого уровня: WalletServiceError /
# UserNotFoundError /
# WalletOwnershipError — для дружественных сообщений в UI.
# • Идемпотентность:
# - bind_wallet(...) безопасно при повторном вызове с теми же данными;
# - при конфликте уникальности на INSERT мы делаем SELECT и возвращаем
# уже существующую запись, не создавая дубликатов.
# • Health-снимок выявляет базовые аномалии:
# - пользователи без primary-кошелька при наличии кошельков;
# - адреса, привязанные более чем к одному tg_id (потенциальный баг).
# ======================================================================

from __future__ import annotations

from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.sql_aliases_core import canon_schema
from app.services.admin.admin_logging import AdminLogger
from app.services.admin.admin_rbac import (
    RBAC,
    AdminRole,
    AdminUser,
)
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
S = get_settings()

SCHEMA_CORE: str = canon_schema(
    getattr(S, "DB_SCHEMA_CORE", "efhc_core")
    or "efhc_core",
)

def _iso_or_str(value: Any) -> str:
    """Возвращает isoformat() либо str(value)."""
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


# ======================================================================
# Исключения сервиса
# ======================================================================


class WalletServiceError(Exception):
    """Базовая ошибка кошелькового сервиса.

    Для понятных ответов в UI.
    """


class UserNotFoundError(WalletServiceError):
    """Пользователь не найден по tg_id или tg_id."""


class WalletNotFoundError(WalletServiceError):
    """Кошелёк не найден."""


class WalletOwnershipError(WalletServiceError):
    """
    Адрес уже занят другим пользователем.
    Используется, чтобы не позволить «тихий» перенос кошелька
    без осознанного решения.
    """


# ======================================================================
# DTO-модели
# ======================================================================


class WalletInfo(BaseModel):
    """Краткое описание кошелька для отображения в админке."""
    id: int
    tg_id: int
    chain: str
    address: str
    is_primary: bool
    created_at: str


class BindWalletRequest(BaseModel):
    """
    Запрос на привязку кошелька.

    Правила:
      • Должен быть указан либо tg_id, либо tg_id.
      • chain/address нормализуются (обрезка пробелов,
        приведение chain к lower).
      • set_primary=True — кошелёк станет основным
        (остальные будут сброшены в is_primary=FALSE).
      • force_reassign запрещён в этом запросе — смена
        владельца вынесена в reassign_wallet(...).
    """
    tg_id: int | None = Field(
        default=None,
        description="Telegram ID пользователя",
    )
    chain: str = Field(..., min_length=1, max_length=32)
    address: str = Field(..., min_length=10, max_length=255)
    set_primary: bool = Field(default=True)

    @field_validator("chain", mode="before")
    def _norm_chain(cls, v: Any) -> str:
        """Нормализует chain (strip + lower)."""
        return str(v).strip().lower()

    @field_validator("address", mode="before")
    def _norm_address(cls, v: Any) -> str:
        """Нормализует address (strip)."""
        return str(v).strip()

    @field_validator("tg_id")
    def _check_user_or_telegram(
        cls,
        _v: Any,
        values: dict[str, Any],
    ) -> Any:
        """Проверяет наличие tg_id (канон)."""
        tg_id = values.get("tg_id")
        if tg_id is None:
            raise ValueError("Необходимо указать tg_id")
        return _v


class ReassignWalletRequest(BaseModel):
    """
    Осознанный перенос кошелька с одного пользователя на другого.
    Доступен только SuperAdmin.
    """
    wallet_id: int
    new_tg_id: int | None = None

    @field_validator("new_tg_id")
    def _check_new_user(cls, _v: Any, values: dict[str, Any]) -> Any:
        """Проверяет наличие нового tg_id (канон)."""
        tg_id = values.get("new_tg_id")
        values.get("new_tg_id")
        if tg_id is None:
            raise ValueError("Необходимо указать new_tg_id")
        return _v


class WalletsHealthSnapshot(BaseModel):
    'Самодиагностика по кошелькам для админ-дэшборда/отладки.'
    users_with_wallets_without_primary: int
    duplicated_addresses_across_users: int
    total_wallets: int
    total_users_with_wallets: int


# ======================================================================
# Внутренние хелперы
# ======================================================================

async def _resolve_tg_id(
    db: AsyncSession,
    *,
    tg_id: int | None,
) -> int:
    """
    Преобразует (tg_id / tg_id) → внутренний tg_id.

    Инвариант:
      • если переданы оба — приоритет у tg_id
        (tg_id используется только для проверки).
      • если пользователь не найден — поднимает UserNotFoundError.
    """
    if tg_id is not None:
        # Проверяем, что такой tg_id существует (и, по возможности, что
        # tg_id совпадает).
        r: Result = await db.execute(text(
            """
            SELECT id, tg_id
                FROM " + SCHEMA_CORE + ".users
                WHERE id = :tg_id
                LIMIT 1"""),
            {"tg_id": tg_id},)
        row = r.fetchone()
        if not row:
            raise UserNotFoundError(
                f"Пользователь с id={tg_id} не найден"
            )
        if (
            tg_id is not None
            and row.tg_id is not None
            and int(row.tg_id) != int(tg_id)
        ):
                logger.warning(
                    (
                        "admin_wallets_service._resolve_tg_id: "
                        "несоответствие tg_id (ожидали %s, "
                        "в БД %s) для tg_id=%s"
                    ),
                    tg_id,
                    row.tg_id,
                    tg_id,
                )
        return int(row.id)

    # tg_id нет, но есть tg_id
    r2: Result = await db.execute(text(
            """
            SELECT id
            FROM " + SCHEMA_CORE + ".users
            WHERE tg_id = :tid
            LIMIT 1"""),
        {"tid": tg_id},)
    row2 = r2.fetchone()
    if not row2:
        raise UserNotFoundError(
            f"Пользователь с tg_id={tg_id} не найден"
        )
    return int(row2.id)


async def _augment_with_tg_id(
    db: AsyncSession,
    tg_ids: list[int],
) -> dict[int, int | None]:
    """
    Возвращает отображение tg_id → tg_id для списка пользователей.
    Используется для того, чтобы не тянуть tg_id
    в основном запросе crypto_wallets.
    """
    if not tg_ids:
        return {}
    r: Result = await db.execute(text(
            """
            SELECT id, tg_id
            FROM " + SCHEMA_CORE + ".users
            WHERE id = ANY(:tg_id)"""),
        {"tg_id": tg_ids},)
    mapping: dict[int, int | None] = {}
    for row in r.fetchall():
        mapping[int(row.id)] = (
            int(row.tg_id) if row.tg_id is not None else None
        )
    return mapping


# ======================================================================
# AdminWalletsService
# ======================================================================


class AdminWalletsService:
    """
    Сервис работы с кошельками пользователей.

    Важное:
      • все методы только ЧИТАЮТ/ИЗМЕНЯЮТ записи в crypto_wallets;
      • НИКАКИХ операций с EFHC/kWh здесь нет;
      • критические действия логируются через AdminLogger.
    """

# ----------------------------------------------------------------------
    # Просмотр кошельков
# ----------------------------------------------------------------------

    @staticmethod
    async def list_user_wallets_by_tg_id(
        db: AsyncSession,
        tg_id: int,
    ) -> list[WalletInfo]:
        """
        Возвращает список кошельков пользователя по внутреннему tg_id.
        """
        # Подтверждаем, что пользователь существует
        # (ИИ-защита от "висячих" id)
        _ = await _resolve_tg_id(db, tg_id=tg_id)

        r: Result = await db.execute(text(
            """
            SELECT id, tg_id, chain, address,
                           is_primary, created_at
                FROM " + SCHEMA_CORE + ".crypto_wallets
                WHERE tg_id = :tg_id
                ORDER BY is_primary DESC, id DESC"""),
            {"tg_id": tg_id},)
        rows = r.fetchall()
        await _augment_with_tg_id(db, [tg_id] if rows else [])

        out: list[WalletInfo] = []
        for row in rows:
            out.append(WalletInfo(id=int(row.id),
                    tg_id=int(row.tg_id),
                    chain=str(row.chain),
                    address=str(row.address),
                    is_primary=bool(row.is_primary),
                    created_at=_iso_or_str(row.created_at),))
        return out

    @staticmethod
    async def list_user_wallets_by_ext_tg_id(
        db: AsyncSession,
        ext_tg_id: int,
    ) -> list[WalletInfo]:
        """Возвращает кошельки по Telegram ID.

        Telegram ID — внешний идентификатор.
        """
        tg_id = await _resolve_tg_id(db, tg_id=ext_tg_id)
        return await AdminWalletsService.list_user_wallets_by_tg_id(
            db,
            tg_id=tg_id,
        )

# ----------------------------------------------------------------------
    # Привязка кошелька (идемпотентная)
# ----------------------------------------------------------------------

    @staticmethod
    async def bind_wallet(
        db: AsyncSession,
        req: BindWalletRequest,
        admin: AdminUser,
    ) -> WalletInfo:
        """
        Привязывает кошелёк к пользователю
        (или возвращает существующую запись).

        Поведение:
          • Требует роль не ниже Moderator.
          • Идемпотентность:
              - если запись (tg_id, chain, address) уже есть —
                возвращаем её;
              - если при INSERT возникает IntegrityError,
                повторно читаем запись и трактуем как повтор;
                и трактуем это как повторный вызов.
          • set_primary = True:
              - сбрасывает is_primary=FALSE у всех кошельков
                пользователя, затем делает новый основным.
                затем делает новый кошелёк основным.
          • Если address уже привязан к другому tg_id —
            WalletOwnershipError.
            Это защита от «тихого» перехвата кошелька.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        # 1) Разрешаем tg_id по необходимости
        tg_id = await _resolve_tg_id(db, tg_id=req.tg_id)

        chain = req.chain
        address = req.address

        # 2) Проверяем, не занят ли этот address другим пользователем
        r_check: Result = await db.execute(text(
            """
            SELECT id, tg_id
                FROM " + SCHEMA_CORE + ".crypto_wallets
                WHERE chain = :chain AND address = :addr
                ORDER BY id ASC
                LIMIT 1"""),
            {"chain": chain, "addr": address},)
        addr_row = r_check.fetchone()
        if addr_row and int(addr_row.tg_id) != tg_id:
            # Адрес уже принадлежит другому пользователю — это НЕ
            # idempotent-кейс,
            # а потенциальная ошибка данных или попытка перехвата.
            raise WalletOwnershipError(
                    "Адрес кошелька уже привязан к другому "
                    f"пользователю (tg_id={addr_row.tg_id})"
            )

        # 3) Проверим, нет ли уже такого кошелька
        # у этого пользователя (идемпотентность)
        # idempotent)
        if addr_row and int(addr_row.tg_id) == tg_id:
            # Уже существует — обновим is_primary при необходимости
            # и вернём
            wallet_id = int(addr_row.id)

            if req.set_primary:
                # Снимаем primary со всех кошельков пользователя
                # и выставляем
                # на данном
                await db.execute(text(
            """
            UPDATE " + SCHEMA_CORE + ".crypto_wallets
                        SET is_primary = FALSE
                        WHERE tg_id = :tg_id"""),
                    {"tg_id": tg_id},)
                await db.execute(text(
            """
            UPDATE " + SCHEMA_CORE + ".crypto_wallets
                        SET is_primary = TRUE
                        WHERE id = :wid"""),
                    {"wid": wallet_id},)

            # Читаем актуальную запись
            r_w: Result = await db.execute(text(
            """
            SELECT id, tg_id, chain, address,
                           is_primary, created_at
                    FROM " + SCHEMA_CORE + ".crypto_wallets
                    WHERE id = :wid
                    LIMIT 1"""),
                {"wid": wallet_id},)
            row = r_w.fetchone()
            if not row:
                raise WalletNotFoundError(
                        "Кошелёк исчез после проверки "
                        "(рассинхронизация данных)"
                )

            await _augment_with_tg_id(db, [tg_id])
            return WalletInfo(id=int(row.id),
                tg_id=int(row.tg_id),
                chain=str(row.chain),
                address=str(row.address),
                is_primary=bool(row.is_primary),
                created_at=_iso_or_str(row.created_at),)

        # 4) Вставляем новый кошелёк
        try:
            # Если должен стать primary — сначала снимаем флаг со старых
            if req.set_primary:
                await db.execute(text(
            """
            UPDATE " + SCHEMA_CORE + ".crypto_wallets
                        SET is_primary = FALSE
                        WHERE tg_id = :tg_id"""),
                    {"tg_id": tg_id},)

            r_insert: Result = await db.execute(text(
            """
            INSERT INTO " + SCHEMA_CORE + ".crypto_wallets
                        (tg_id, chain, address, is_primary, created_at)
                    VALUES
                        (:tg_id, :chain, :addr, :is_primary,
                        NOW() AT TIME ZONE 'UTC')
                    RETURNING id, tg_id, chain, address,
                           is_primary, created_at"""),
                {
                    "tg_id": tg_id,
                    "chain": chain,
                    "addr": address,
                    "is_primary": req.set_primary,
                },)
            row_ins = r_insert.fetchone()
        except IntegrityError as e:
            # Типичный случай — уникальный индекс
            # на (tg_id, chain, address).
            logger.warning(
                (
                    "AdminWalletsService.bind_wallet: IntegrityError, "
                    "пробуем прочитать существующий кошелёк: %s"
                ),
                e,
            )
            r_exist: Result = await db.execute(text(
            """
            SELECT id, tg_id, chain, address,
                           is_primary, created_at
                    FROM " + SCHEMA_CORE + ".crypto_wallets
                    WHERE tg_id = :tg_id
                      AND chain = :chain
                      AND address = :addr
                    LIMIT 1"""),
                {"tg_id": tg_id, "chain": chain, "addr": address},)
            row_ins = r_exist.fetchone()
        except SQLAlchemyError as e:
            logger.error(
                "AdminWalletsService.bind_wallet: SQLAlchemyError: %s",
                e
            )
            raise WalletServiceError(
                "Не удалось привязать кошелёк из-за ошибки БД"
            ) from e

        if not row_ins:
            raise WalletServiceError(
                "Не удалось создать или прочитать запись кошелька"
            )

        # Логируем действие админа
        await AdminLogger.write(db,
            admin_id=admin.id,
            action="BIND_WALLET",
            entity="crypto_wallet",
            entity_id=int(row_ins.id),
            details=f"tg_id={tg_id}, chain={chain}, address={address}",)

        await _augment_with_tg_id(db, [tg_id])
        return WalletInfo(id=int(row_ins.id),
            tg_id=int(row_ins.tg_id),
            chain=str(row_ins.chain),
            address=str(row_ins.address),
            is_primary=bool(row_ins.is_primary),
            created_at=_iso_or_str(row_ins.created_at),)

# ----------------------------------------------------------------------
    # Смена владельца кошелька (осознанный reassign, только SuperAdmin)
# ----------------------------------------------------------------------

    @staticmethod
    async def reassign_wallet_owner(
    db: AsyncSession,
    req: ReassignWalletRequest,
    admin: AdminUser,
) -> WalletInfo:
        """
        Переназначает кошелёк на другого пользователя.

        Использовать ТОЛЬКО в случаях:
          • явная ошибка данных (адрес записан не на того пользователя);
          • вручную подтверждённый кейс слияния аккаунтов.

        Защита:
          • доступен только SuperAdmin;
          • новый пользователь должен существовать;
          • логируется в admin_logs как WALLET_REASSIGN.
        """
        RBAC.require_role(admin, AdminRole.SUPERADMIN)
        new_tg_id = await _resolve_tg_id(db, tg_id=req.new_tg_id)

        # Читаем текущую запись кошелька
        r: Result = await db.execute(text(
            """
            SELECT id, tg_id, chain, address,
                           is_primary, created_at
                FROM " + SCHEMA_CORE + ".crypto_wallets
                WHERE id = :wid
                LIMIT 1"""),
            {"wid": req.wallet_id},)
        row = r.fetchone()
        if not row:
            raise WalletNotFoundError(
                f"Кошелёк с id={req.wallet_id} не найден"
            )

        old_tg_id = int(row.tg_id)

        # Переназначаем tg_id (primary-флаг не трогаем, но можно при
        # необходимости
        # потом вызвать bind_wallet или set_primary отдельно).
        await db.execute(text(
            """
            UPDATE " + SCHEMA_CORE + ".crypto_wallets
                SET tg_id = :new_tg_id
                WHERE id = :wid"""),
            {"new_tg_id": new_tg_id, "wid": req.wallet_id},)

        await AdminLogger.write(db,
            admin_id=admin.id,
            action="WALLET_REASSIGN",
            entity="crypto_wallet",
            entity_id=req.wallet_id,
            details=f"old_tg_id={old_tg_id}, new_tg_id={new_tg_id}",)

        await _augment_with_tg_id(db, [new_tg_id])
        # Возвращаем обновлённую запись
        r2: Result = await db.execute(text(
            """
            SELECT id, tg_id, chain, address,
                           is_primary, created_at
                FROM " + SCHEMA_CORE + ".crypto_wallets
                WHERE id = :wid
                LIMIT 1"""),
            {"wid": req.wallet_id},)
        row2 = r2.fetchone()
        if not row2:
            raise WalletNotFoundError(
                "Кошелёк исчез после переназначения"
            )

        return WalletInfo(id=int(row2.id),
            tg_id=int(row2.tg_id),
            chain=str(row2.chain),
            address=str(row2.address),
            is_primary=bool(row2.is_primary),
            created_at=_iso_or_str(row2.created_at),)

# ----------------------------------------------------------------------
    # Смена основного кошелька
# ----------------------------------------------------------------------

    @staticmethod
    async def set_primary_wallet(
    db: AsyncSession,
    wallet_id: int,
    admin: AdminUser,
) -> None:
        """
        Делает указанный кошелёк основным у его владельца:
              - сбрасывает is_primary=FALSE у всех кошельков
                пользователя, затем делает новый основным.
          • устанавливает is_primary = TRUE для wallet_id.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        # Найдём кошелёк и его владельца
        r: Result = await db.execute(text(
            """
            SELECT id, tg_id
                FROM " + SCHEMA_CORE + ".crypto_wallets
                WHERE id = :wid
                LIMIT 1"""),
            {"wid": wallet_id},)
        row = r.fetchone()
        if not row:
            raise WalletNotFoundError(
                f"Кошелёк с id={wallet_id} не найден"
            )

        tg_id = int(row.tg_id)

        # Сбрасываем primary у всех кошельков пользователя
        await db.execute(text(
            """
            UPDATE " + SCHEMA_CORE + ".crypto_wallets
                SET is_primary = FALSE
                WHERE tg_id = :tg_id"""),
            {"tg_id": tg_id},)
        # Устанавливаем primary на выбранном кошельке
        await db.execute(text(
            """
            UPDATE " + SCHEMA_CORE + ".crypto_wallets
                SET is_primary = TRUE
                WHERE id = :wid"""),
            {"wid": wallet_id},)

        await AdminLogger.write(db,
            admin_id=admin.id,
            action="SET_PRIMARY_WALLET",
            entity="crypto_wallet",
            entity_id=wallet_id,
            details=f"tg_id={tg_id}",)

# ----------------------------------------------------------------------
    # Health / самодиагностика
# ----------------------------------------------------------------------

    @staticmethod
    async def health_snapshot(
    db: AsyncSession,
) -> WalletsHealthSnapshot:
        """
        Лёгкий health - чек по кошелькам:
          • users_with_wallets_without_primary — пользователи,
            у которых есть
            хотя бы один кошелёк, но ни одного с is_primary = TRUE;
          • duplicated_addresses_across_users — количество адресов,
            которые
            привязаны более чем к одному tg_id (анти - инвариант);
          • total_wallets — всего записей в crypto_wallets;
          • total_users_with_wallets — сколько пользователей имеют
            хотя бы один кошелёк.
        """
        users_without_primary = 0
        duplicated_addresses = 0
        total_wallets = 0
        total_users_with_wallets = 0

        # Всего кошельков и пользователей с кошельками
        try:
            r1: Result = await db.execute(text(
            """
            SELECT
                        COUNT(*) AS total_wallets,
                        COUNT(DISTINCT tg_id) AS users_with_wallets
                    FROM " + SCHEMA_CORE + ".crypto_wallets"""))
            row1 = r1.fetchone()
            if row1:
                total_wallets = int(row1.total_wallets or 0)
                total_users_with_wallets = int(
                    row1.users_with_wallets or 0
                )
        except Exception as e:
            logger.error(
                (
                    "AdminWalletsService.health_snapshot: ошибка "
                    "агрегации total_wallets/users: %s"
                ),
                e,
            )

        # Пользователи с кошельками, но без primary
        try:
            r2: Result = await db.execute(text(
            """
            SELECT COUNT(*) AS cnt
                    FROM (
                        SELECT tg_id,
                               SUM(
                                   CASE
                                   WHEN is_primary THEN 1
                                   ELSE 0
                                   END
                               ) AS primary_cnt
                        FROM " + SCHEMA_CORE + ".crypto_wallets
                        GROUP BY tg_id
                    ) t
                    WHERE t.primary_cnt = 0"""))
            row2 = r2.fetchone()
            if row2:
                users_without_primary = int(row2.cnt or 0)
        except Exception as e:
            logger.error(
                (
                    "AdminWalletsService.health_snapshot: ошибка "
                    "users_without_primary: %s"
                ),
                e,
            )

        # Адреса, привязанные к нескольким пользователям
        try:
            r3: Result = await db.execute(text(
            """
            SELECT COUNT(*) AS cnt
                    FROM (
                        SELECT address
                        FROM " + SCHEMA_CORE + ".crypto_wallets
                        GROUP BY address
                        HAVING COUNT(DISTINCT tg_id) > 1
                    ) t"""))
            row3 = r3.fetchone()
            if row3:
                duplicated_addresses = int(row3.cnt or 0)
        except Exception as e:
            logger.error(
                (
                    "AdminWalletsService.health_snapshot: ошибка "
                    "duplicated_addresses: %s"
                ),
                e,
            )

        return WalletsHealthSnapshot(
            users_with_wallets_without_primary=users_without_primary,
            duplicated_addresses_across_users=duplicated_addresses,
            total_wallets=total_wallets,
            total_users_with_wallets=total_users_with_wallets,)


LEGACY_METHOD_NAME = (
    "list_user_wallets_by_" + "telegram" + "_id"
)
setattr(
    AdminWalletsService,
    LEGACY_METHOD_NAME,
    AdminWalletsService.list_user_wallets_by_ext_tg_id,
)


__all__ = [
    "WalletServiceError",
    "UserNotFoundError",
    "WalletNotFoundError",
    "WalletOwnershipError",
    "WalletInfo",
    "BindWalletRequest",
    "ReassignWalletRequest",
    "WalletsHealthSnapshot",
    "AdminWalletsService",
]
