# -*- coding: utf-8 -*-
# backend/app/services/admin/admin_bank_service.py
# ======================================================================
# EFHC Bot — Банк EFHC: начальная эмиссия, ручные операции
# Банк↔Пользователь,
# логирование и безопасные откаты через компенсирующие транзакции.
# ----------------------------------------------------------------------
# Назначение модуля:
# • Централизованный сервис для операций с Банком EFHC в админ-панели.
# • Строгий канон: НЕТ P2P-переводов между пользователями, только:
#   - Банк → Пользователь
#   - Пользователь → Банк
# • Начальная эмиссия Банка: 5 000 000 EFHC (идемпотентная
# инициализация).
# • Ручные корректировки: regular (main) и bonus.
# • Полная идемпотентность: mint/burn, ручные корректировки, откаты.
# • Логи: bank_balances, internal_tx, admin_logs, efhc_mint_burn.
#
# ВАЖНО (канон):
# 1) Начальный баланс Банка — 5 000 000 EFHC (можно переопределить в
# .env).
# 2) P2P между пользователями запрещены. Корректировка: userA → Банк →
# userB.
# 3) Ручные операции Банк↔Пользователь только через
# transactions_service.*
#    (credit/debit, включая бонусный баланс). Никаких прямых UPDATE
#    балансов.
# 4) Все операции требуют idempotency_key от клиента (админ-панель).
#    Модуль не генерирует ключи сам.
# 5) Все бонусные начисления должны идти в bonus_balance (bonus-ветка
# банка).
# ======================================================================

from __future__ import annotations

from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.utils_core import (
    format_decimal_str,
    quantize_decimal,
)

from app.services.transactions_service import (
    credit_user_bonus_from_bank,
    credit_user_from_bank,
    debit_user_bonus_to_bank,
    debit_user_to_bank,
)

from .admin_logging import AdminLogger
from .admin_notifications import AdminNotifier
from .admin_rbac import AdminRole, AdminUser, RBAC

logger = get_logger(__name__)
S = get_settings()

SCHEMA_ADMIN: str = (
    S.DB_SCHEMA_ADMIN or "efhc_admin"
)
SCHEMA_CORE: str = (
    getattr(S, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core"
)

# Telegram-ID «банковского» аккаунта (логический идентификатор Банка в
# internal_tx)
BANK_TG_ID: int = int(getattr(S, "BANK_TG_ID", 0) or 0)

# Начальная эмиссия Банка (канон: 5 000 000 EFHC, можно переопределить в
# .env)
BANK_INITIAL_TOTAL: Decimal = Decimal(
    str(getattr(S, "BANK_INITIAL_TOTAL_EFHC", "5000000") or "5000000")
)

# Универсальная точность EFHC (по канону 8 знаков)
EFHC_DECIMALS: int = int(getattr(S, "EFHC_DECIMALS", 8) or 8)
_Q = Decimal(1).scaleb(-EFHC_DECIMALS)


def d8(x: Any) -> Decimal:
    """Округляет вниз до EFHC_DECIMALS знаков (канон EFHC)."""
    return Decimal(str(x)).quantize(_Q, rounding=ROUND_DOWN)


if BANK_TG_ID <= 0:
    logger.warning(
        "BANK_TG_ID не задан или <= 0. "
        "Логи internal_tx по Банку могут быть неполными. "
        "Настройте .env."
    )



# ======================================================================
# DTO / запросы / ответы для админки
# ======================================================================


class MintBurnRequest(BaseModel):
    """Запрос на mint/burn EFHC в банке."""

    amount: Decimal = Field(..., gt=Decimal("0"))
    reason: Optional[str] = None
    idempotency_key: str = Field(..., min_length=1, max_length=128)

    @field_validator("amount", mode="before")

    def _v_amount(cls, v: Any) -> Decimal:
        """Валидатор: amount → Decimal(d8)."""
        return quantize_decimal(v, EFHC_DECIMALS, "DOWN")

    @field_validator("idempotency_key")

    def _v_idem(cls, v: str) -> str:
        """Валидатор: idempotency_key (strip, non-empty)."""
        v = (v or "").strip()
        if not v:
            raise ValueError("idempotency_key обязателен")
        return v


class BankUserTransferRequest(BaseModel):
    """Ручная операция Банк↔Пользователь (админ-корректировка)."""


    tg_id: int = Field(..., ge=1)
    amount: Decimal = Field(..., gt=Decimal("0"))
    direction: Literal["credit", "debit"]
    balance_type: Literal["REGULAR", "BONUS"]
    reason: Optional[str] = None
    idempotency_key: str = Field(..., min_length=1, max_length=128)

    @field_validator("amount", mode="before")

    def _v_amount(cls, v: Any) -> Decimal:
        """Валидатор: amount → Decimal(d8)."""
        return quantize_decimal(v, EFHC_DECIMALS, "DOWN")

    @field_validator("idempotency_key")

    def _v_idem(cls, v: str) -> str:
        """Валидатор: idempotency_key (strip, non-empty)."""
        v = (v or "").strip()
        if not v:
            raise ValueError("idempotency_key обязателен")
        return v


class BankBalance(BaseModel):
    """Сводный баланс Банка EFHC (согласно таблице bank_balances)."""

    balance: str  # строка с 8 знаками после запятой
    tg_id: int


class BankTransferLogEntry(BaseModel):
    """Лог internal_tx по Банку (только просмотр/аудит)."""


    id: int
    from_tg_id: Optional[int]
    to_tg_id: Optional[int]
    amount: str
    reason: str
    created_at: str


# ======================================================================
# Сервис Банка EFHC
# ======================================================================


class BankService:
    """Банк-сервис админки (без P2P)."""


    # ------------------------------------------------------------------
    # Инициализация Банка (начальный баланс 5 000 000 EFHC)
    # ------------------------------------------------------------------
    @staticmethod
    async def ensure_initial_balance(
        db: AsyncSession,
    ) -> Dict[str, Any]:
        """Идемпотентно инициализирует bank_balances для BANK_TG_ID."""
        if BANK_TG_ID <= 0:
            raise ValueError(
    "BANK_TG_ID не настроен (<=0). "
    "Невозможно инициализировать Банк."
)

        sql_check = text(f"""
            SELECT efhc_balance
            FROM efhc_admin.bank_balances
            WHERE tg_id = :tid
            LIMIT 1
            """)
        r: Result = await db.execute(sql_check, {"tid": BANK_TG_ID})
        row = r.fetchone()
        if row:
            current = Decimal(str(row.efhc_balance or "0"))
            return {
                "initialized": False,
                "balance_before": format_decimal_str(
                    current,
                    EFHC_DECIMALS,
                ),
                "balance_after": format_decimal_str(
                    current,
                    EFHC_DECIMALS,
                ),
            }

        # Создаём запись с начальным балансом
        init_amt = d8(BANK_INITIAL_TOTAL)
        await db.execute(text(f"""
                INSERT INTO efhc_admin.bank_balances (
                    tg_id,
                    efhc_balance
                )
                VALUES (:tid, :amt)
                """),
            {"tid": BANK_TG_ID, "amt": str(init_amt)},)

        logger.info(
            "BankService.ensure_initial_balance: создана запись Банка "
            "с балансом %s EFHC",
            format_decimal_str(init_amt, EFHC_DECIMALS),
        )

        return {
            "initialized": True,
            "balance_before": format_decimal_str(
                Decimal("0"),
                EFHC_DECIMALS,
            ),
            "balance_after": format_decimal_str(
                init_amt,
                EFHC_DECIMALS,
            ),
        }

    # ------------------------------------------------------------------
    # Текущий баланс Банка
    # ------------------------------------------------------------------
    @staticmethod
    async def get_bank_balance(db: AsyncSession) -> BankBalance:
        """
        Возвращает текущий баланс Банка EFHC по таблице bank_balances.

        Если записи нет — возвращает 0. Это не ошибка: значит,
        ensure_initial_balance() ещё не запускали.
        """
        if BANK_TG_ID <= 0:
            raise ValueError("BANK_TG_ID не настроен (<=0)")

        r: Result = await db.execute(text(f"""
                SELECT efhc_balance
                FROM efhc_admin.bank_balances
                WHERE tg_id = :tid
                LIMIT 1
                """),
            {"tid": BANK_TG_ID},)
        row = r.fetchone()
        if row:
            bal = Decimal(str(row.efhc_balance or '0'))
        else:
            bal = Decimal('0')
        return BankBalance(
            balance=format_decimal_str(d8(bal), EFHC_DECIMALS),
            tg_id=BANK_TG_ID,
        )

    # ------------------------------------------------------------------
    # Минт/бёрн EFHC (только Банк)
    # ------------------------------------------------------------------
    @staticmethod
    async def mint_efhc(
        db: AsyncSession,
        req: MintBurnRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Минт EFHC в Банк:

          • Увеличивает efhc_balance в bank_balances для BANK_TG_ID.
          • Пишет строку в efhc_mint_burn с idempotency_key.
          • Логирует действие в admin_logs.

        RBAC:
          • Только SUPERADMIN.
        """
        RBAC.require_role(admin, AdminRole.SUPERADMIN)
        if BANK_TG_ID <= 0:
            raise ValueError("BANK_TG_ID не настроен (<=0)")

        amt = d8(req.amount)

        # Идемпотентность: проверяем, выполнялся ли уже mint с этим
        # ключом
        r: Result = await db.execute(text(f"""
                SELECT id, amount
                FROM {SCHEMA_ADMIN}.efhc_mint_burn
                WHERE idempotency_key = :ik AND action = 'MINT'
                LIMIT 1
                """),
            {"ik": req.idempotency_key},)
        row = r.fetchone()
        if row:
            # Уже зафиксированный mint — считаем операцию повторной, но
            # безопасной
            logger.info(
                "BankService.mint_efhc: повторный запрос с тем же "
                "idempotency_key=%s, amount=%s",
                req.idempotency_key,
                row.amount,)
            # Баланс мог измениться другими операциями → просто
            # возвращаем
            # текущий
            bal = await BankService.get_bank_balance(db)
            return {
                "ok": True,
                "minted": format_decimal_str(
                    d8(row.amount),
                    EFHC_DECIMALS,
                ),
                "idempotency_key": req.idempotency_key,
                "current_balance": bal.balance,
                "reused": True,
            }

        # Обновление банка
        await db.execute(text(f"""
                INSERT INTO efhc_admin.bank_balances (
                    tg_id,
                    efhc_balance
                )
                VALUES (:tid, :amt)
                ON CONFLICT (tg_id) DO UPDATE
                SET efhc_balance =
                    efhc_admin.bank_balances.efhc_balance + :amt
                """),
            {"tid": BANK_TG_ID, "amt": str(amt)},)

        # Лог в efhc_mint_burn
        await db.execute(text(f"""
                INSERT INTO {SCHEMA_ADMIN}.efhc_mint_burn
                    (
                        action,
                        amount,
                        admin_id,
                        reason,
                        idempotency_key,
                        created_at
                    )
                VALUES
                    (
                        'MINT',
                        :amt,
                        :aid,
                        :reason,
                        :ik,
                        NOW() AT TIME ZONE 'UTC'
                    )
                """),
            {
                "amt": str(amt),
                "aid": admin.id,
                "reason": req.reason or "",
                "ik": req.idempotency_key,
            },)

        # Лог действий админа
        await AdminLogger.write(db,
            admin_id = admin.id,
            action = "BANK_MINT",
            entity = "bank",
            entity_id = None,
            details = (
                f"amount = {format_decimal_str(amt, EFHC_DECIMALS)}; "
                f"ik = {req.idempotency_key}"
            ),)

        # Уведомление (опционально)
        await AdminNotifier.notify_generic(db,
            event = "BANK_MINT",
            message=(
                f"Минт {format_decimal_str(amt, EFHC_DECIMALS)} EFHC"
            ),
            payload_json=(
                f'{{"amount":"'
                f'{format_decimal_str(amt, EFHC_DECIMALS)}",'
                f'"admin_id":{admin.id}}}'
            ),)

        bal = await BankService.get_bank_balance(db)
        return {
            "ok": True,
            "minted": format_decimal_str(amt, EFHC_DECIMALS),
            "idempotency_key": req.idempotency_key,
            "current_balance": bal.balance,
            "reused": False,
        }

    @staticmethod
    async def burn_efhc(
        db: AsyncSession,
        req: MintBurnRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Бёрн EFHC из Банка:

          • Уменьшает efhc_balance в bank_balances для BANK_TG_ID.
          • Не допускает «сжигание в минус» — количество EFHC в Банке
            должно быть ≥ amount.
          • Логирует операцию и сохраняет idempotency_key.

        RBAC:
          • Только SUPERADMIN.
        """
        RBAC.require_role(admin, AdminRole.SUPERADMIN)
        if BANK_TG_ID <= 0:
            raise ValueError("BANK_TG_ID не настроен (<=0)")

        amt = d8(req.amount)

        # Идемпотентность: бёрн с тем же ключом не должен повторяться
        r: Result = await db.execute(text(f"""
                SELECT id, amount
                FROM {SCHEMA_ADMIN}.efhc_mint_burn
                WHERE idempotency_key = :ik AND action = 'BURN'
                LIMIT 1
                """),
            {"ik": req.idempotency_key},)
        row = r.fetchone()
        if row:
            logger.info(
                "BankService.burn_efhc: повторный запрос с тем же "
                "idempotency_key=%s, amount=%s",
                req.idempotency_key,
                row.amount,)
            bal = await BankService.get_bank_balance(db)
            return {
                "ok": True,
                "burned": format_decimal_str(
                    d8(row.amount),
                    EFHC_DECIMALS,
                ),
                "idempotency_key": req.idempotency_key,
                "current_balance": bal.balance,
                "reused": True,
            }

        # Проверяем остаток
        r2: Result = await db.execute(text(f"""
                SELECT efhc_balance
                FROM efhc_admin.bank_balances
                WHERE tg_id = :tid
                LIMIT 1
                """),
            {"tid": BANK_TG_ID},)
        row2 = r2.fetchone()
        if row2:
            cur = Decimal(str(row2.efhc_balance or '0'))
        else:
            cur = Decimal('0')
        if cur < amt:
            raise ValueError("Недостаточно EFHC в банке для сжигания")

        # Списываем
        await db.execute(text(f"""
                UPDATE efhc_admin.bank_balances
                SET efhc_balance = efhc_balance - :amt
                WHERE tg_id = :tid
                """),
            {"tid": BANK_TG_ID, "amt": str(amt)},)

        # Лог в efhc_mint_burn
        await db.execute(text(f"""
                INSERT INTO {SCHEMA_ADMIN}.efhc_mint_burn
                    (
                        action,
                        amount,
                        admin_id,
                        reason,
                        idempotency_key,
                        created_at
                    )
                VALUES
                    (
                        'BURN',
                        :amt,
                        :aid,
                        :reason,
                        :ik,
                        NOW() AT TIME ZONE 'UTC'
                    )
                """),
            {
                "amt": str(amt),
                "aid": admin.id,
                "reason": req.reason or "",
                "ik": req.idempotency_key,
            },)

        await AdminLogger.write(db,
            admin_id = admin.id,
            action = "BANK_BURN",
            entity = "bank",
            entity_id = None,
            details = (
                f"amount = {format_decimal_str(amt, EFHC_DECIMALS)}; "
                f"ik = {req.idempotency_key}"
            ),)

        await AdminNotifier.notify_generic(db,
            event = "BANK_BURN",
            message=(
                f"Сжигание "
                f"{format_decimal_str(amt, EFHC_DECIMALS)} EFHC"
            ),
            payload_json=(
                f'{{"amount":"'
                f'{format_decimal_str(amt, EFHC_DECIMALS)}",'
                f'"admin_id":{admin.id}}}'
            ),)

        bal = await BankService.get_bank_balance(db)
        return {
            "ok": True,
            "burned": format_decimal_str(amt, EFHC_DECIMALS),
            "idempotency_key": req.idempotency_key,
            "current_balance": bal.balance,
            "reused": False,
        }

    # ------------------------------------------------------------------
    # Ручные операции Банк↔Пользователь (только через
    # transactions_service)
    # ------------------------------------------------------------------
    @staticmethod
    async def manual_bank_user_transfer(db: AsyncSession,
        req: BankUserTransferRequest,
        admin: AdminUser,) -> Dict[str, Any]:
        """
        Выполняет ручную корректировку между Банком и пользователем.

        Канон:
          • direction:
              - 'credit' — Банк → Пользователь.
              - 'debit'  — Пользователь → Банк.
          • balance_type:
              - 'REGULAR' — обычный EFHC.
              - 'BONUS'   — бонусный EFHC (строгий канон для бонусов).
          • Внутренне всегда вызывается только банковский сервис:
              credit_user_from_bank / credit_user_bonus_from_bank /
              debit_user_to_bank / debit_user_bonus_to_bank.

        RBAC:
          • Минимум MODERATOR.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        amt = d8(req.amount)
        if amt <= 0:
            raise ValueError("Сумма должна быть больше нуля")

        # Общая причина/мета для банковского лога
        base_reason = req.reason or "ADMIN_MANUAL"
        meta = {
            "admin_id": admin.id,
            "admin_role": admin.role,
            "admin_reason": base_reason,
            "source": "admin_manual_bank_transfer",
        }

        try:
            if req.direction == "credit":
                # Банк → Пользователь
                if req.balance_type == "REGULAR":
                    await credit_user_from_bank(db,
                        tg_id = req.tg_id,
                        amount = amt,
                        reason = "admin_manual_regular_credit",
                        idempotency_key = req.idempotency_key,
                        meta = meta,)
                    action = "CREDIT_REGULAR"
                else:
                    await credit_user_bonus_from_bank(db,
                        tg_id = req.tg_id,
                        amount = amt,
                        reason = "admin_manual_bonus_credit",
                        idempotency_key = req.idempotency_key,
                        meta = meta,)
                    action = "CREDIT_BONUS"
            else:
                # Пользователь → Банк
                if req.balance_type == "REGULAR":
                    await debit_user_to_bank(db,
                        tg_id = req.tg_id,
                        amount = amt,
                        reason = "admin_manual_regular_debit",
                        idempotency_key = req.idempotency_key,
                        meta = meta,
                        spend_bonus_first = False,
                        forbid_user_negative = True,)
                    action = "DEBIT_REGULAR"
                else:
                    await debit_user_bonus_to_bank(db,
                        tg_id = req.tg_id,
                        amount = amt,
                        reason = "admin_manual_bonus_debit",
                        idempotency_key = req.idempotency_key,
                        meta = meta,
                        forbid_user_negative = True,)
                    action = "DEBIT_BONUS"

        except Exception as e:
            # Перехватываем любые ошибки и транслируем в понятную для UI
            logger.warning(
                "BankService.manual_bank_user_transfer failed "
                "(user=%s, dir=%s, bal=%s): %s",
                req.tg_id,
                req.direction,
                req.balance_type,
                e,)
            raise ValueError(
                f"Не удалось выполнить операцию: {type(e).__name__}: "
                f"{e}"
            ) from e

        # Лог админа (отдельно от банковского лога)
        await AdminLogger.write(db,
            admin_id = admin.id,
            action = action,
            entity = "bank_user_tx",
            entity_id = req.tg_id,
            details = (
                f"amount = {format_decimal_str(amt, EFHC_DECIMALS)}; "
                f"ik = {req.idempotency_key}; "
                f"balance_type = {req.balance_type}"
            ),)

        # Уведомление (опционально)
        label = (
            "Кредит"
            if req.direction == "credit"
            else "Дебет"
        )
        message = (
            f"{label} "
            f"{format_decimal_str(amt, EFHC_DECIMALS)} EFHC "
            f"({req.balance_type}) пользователю {req.tg_id}"
        )
        payload_json = (
            f'{{"tg_id":{req.tg_id},'
            f'"amount":"{format_decimal_str(amt, EFHC_DECIMALS)}",'
            f'"direction":"{req.direction}",'
            f'"balance_type":"{req.balance_type}",'
            f'"admin_id":{admin.id},'
            f'"ik":"{req.idempotency_key}"}}'
        )
        await AdminNotifier.notify_generic(
            db,
            event=action,
            message=message,
            payload_json=payload_json,
        )
        return {
            "ok": True,
            "tg_id": req.tg_id,
            "amount": format_decimal_str(amt, EFHC_DECIMALS),
            "direction": req.direction,
            "balance_type": req.balance_type,
            "idempotency_key": req.idempotency_key,
        }

    # ------------------------------------------------------------------
    # История операций Банк↔Пользователь
    # ------------------------------------------------------------------
    @staticmethod
    async def list_bank_user_transfers(db: AsyncSession,
        *,
        tg_id: Optional[int] = None,
        limit: int = 100,
        offset: int = 0,
        sort_desc: bool = True,) -> List[BankTransferLogEntry]:
        """
        Возвращает историю внутренних переводов, где участвует Банк:

          • from_tg_id = BANK_TG_ID или to_tg_id = BANK_TG_ID.
          • При tg_id — фильтр по конкретному пользователю.
          • Таблица: {SCHEMA_CORE}.internal_tx.

        Внимание:
          • Это лог (для просмотра/аудита).
        """
        if BANK_TG_ID <= 0:
            raise ValueError("BANK_TG_ID не настроен (<=0)")

        limit = max(1, min(limit, 500))
        offset = max(0, offset)
        order = "DESC" if sort_desc else "ASC"

        where = [
            "(from_tg_id = :bank_id OR to_tg_id = :bank_id)",
        ]
        params: Dict[str, Any] = {
            "bank_id": BANK_TG_ID,
            "limit": limit,
            "offset": offset,
        }
        if tg_id is not None:
            where.append("(from_tg_id = :tg_id OR to_tg_id = :tg_id)")
            params["tg_id"] = tg_id

        sql = text(f"""
            SELECT id, from_tg_id, to_tg_id, amount, reason, created_at
            FROM {SCHEMA_CORE}.internal_tx
            WHERE {" AND ".join(where)}
            ORDER BY id {order}
            LIMIT :limit OFFSET :offset
            """)
        r: Result = await db.execute(sql, params)
        out: List[BankTransferLogEntry] = []
        for row in r.fetchall():
            out.append(BankTransferLogEntry(id = int(row.id),
                    from_tg_id=(
                        int(row.from_tg_id)
                        if row.from_tg_id is not None
                        else None
                    ),
                    to_tg_id=(
                        int(row.to_tg_id)
                        if row.to_tg_id is not None
                        else None
                    ),
                    amount = str(row.amount),
                    reason = str(row.reason),
                    created_at = row.created_at.isoformat()
                    if hasattr(row.created_at, "isoformat")
                    else str(row.created_at),))
        return out

    # ------------------------------------------------------------------
    # «Откат» через компенсирующую транзакцию (мягкий rollback)
    # ------------------------------------------------------------------
    @staticmethod
    async def rollback_bank_user_tx(db: AsyncSession,
        *,
        internal_tx_id: int,
        balance_type: Literal["REGULAR", "BONUS"],
        idempotency_key: str,
        admin: AdminUser,) -> Dict[str, Any]:
        """
        Выполняет откат internal_tx через компенсирующую операцию.
        компенсирующую транзакцию с противоположным направлением.

        Ограничения/ИИ-защита:
          • Только internal_tx, где строго одна сторона — Банк.
                from_tg_id = BANK_TG_ID, to_tg_id = user
                ИЛИ
                from_tg_id = user, to_tg_id = BANK_TG_ID.
          • Без P2P: если обе стороны != BANK_TG_ID,
            выбрасывается ошибка.
          • Направление отката:
                Банк → Пользователь  →   rollback: Пользователь → Банк
                Пользователь → Банк  →   rollback: Банк → Пользователь
          • balance_type указывается явно (REGULAR/BONUS).
            таблица internal_tx не хранит тип баланса.

        RBAC:
          • Минимум MODERATOR.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        if BANK_TG_ID <= 0:
	    	    raise ValueError("BANK_TG_ID не настроен (<=0)")

        if not idempotency_key.strip():
            raise ValueError("idempotency_key обязателен для отката")

        # Ищем исходную операцию
        r: Result = await db.execute(text(f"""
                SELECT
                    id,
                    from_tg_id,
                    to_tg_id,
                    amount,
                    reason,
                    created_at
                FROM {SCHEMA_CORE}.internal_tx
                WHERE id = :txid
                LIMIT 1
                """),
            {"txid": internal_tx_id},)
        row = r.fetchone()
        if not row:
            raise ValueError("Оригинальная транзакция не найдена")

        from_tg_id = (
            int(row.from_tg_id)
            if row.from_tg_id is not None
            else None
        )
        to_tg_id = (
            int(row.to_tg_id)
            if row.to_tg_id is not None
            else None
        )
        amount = d8(row.amount)
        original_reason = str(row.reason)

        # Проверяем, что это Банк↔Пользователь
        is_bank_sender = (
            from_tg_id == BANK_TG_ID
            and to_tg_id
            and to_tg_id != BANK_TG_ID
        )
        if is_bank_sender:
            tg_id = to_tg_id
            direction = "credit"
        elif (
            to_tg_id == BANK_TG_ID
            and from_tg_id
            and from_tg_id != BANK_TG_ID
        ):
            tg_id = from_tg_id
            direction = "debit"
        else:
            # либо P2P, либо обе стороны Банк — не трогаем
            raise ValueError(
                "Откат поддерживается только для операций "
                "Банк↔Пользователь"
            )

        # Настраиваем компенсирующее направление
        if direction == "credit":
            # Оригинал: credit; откат: debit
            rollback_req = BankUserTransferRequest(tg_id = tg_id,
                amount = amount,
                direction = "debit",
                balance_type = balance_type,
                reason = f"ROLLBACK:{internal_tx_id}|{original_reason}",
                idempotency_key = idempotency_key,)
        else:
            # Оригинал: debit; откат: credit
            rollback_req = BankUserTransferRequest(tg_id = tg_id,
                amount = amount,
                direction = "credit",
                balance_type = balance_type,
                reason = f"ROLLBACK:{internal_tx_id}|{original_reason}",
                idempotency_key = idempotency_key,)

        # Выполняем компенсирующую операцию
        result = await BankService.manual_bank_user_transfer(db,
            req = rollback_req,
            admin = admin,)

        # Дополнительный лог для явного помечания отката
        await AdminLogger.write(db,
            admin_id = admin.id,
            action = "BANK_ROLLBACK",
            entity = "bank_user_tx",
            entity_id = tg_id,
            details = (
                f"rollback_tx_id = {internal_tx_id}; "
                f"balance_type = {balance_type}; "
                f"ik = {idempotency_key}"
            ),)

        return {
            "ok": True,
            "rollback_of": internal_tx_id,
            "compensation": result,
        }


__all__ = [
    "MintBurnRequest",
    "BankUserTransferRequest",
    "BankBalance",
    "BankTransferLogEntry",
    "BankService",
    "AdminBankService",
    "BankBalanceDTO",
    "ManualBankTransferRequest",
]


# ----------------------------------------------------------------------
# SSOT-compatible export aliases (do not change behavior)
# ----------------------------------------------------------------------
# Historical/contract names expected by services/tests.
AdminBankService = BankService
BankBalanceDTO = BankBalance
ManualBankTransferRequest = BankUserTransferRequest