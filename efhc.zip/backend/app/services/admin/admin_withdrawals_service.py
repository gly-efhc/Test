# backend/app/services/admin/admin_withdrawals_service.py
# ======================================================================
# EFHC Bot — Сервис выдачи EFHC и NFT (выводы, бонусы)
# ----------------------------------------------------------------------
# Назначение модуля:
# • Управление заявками на вывод EFHC пользователями.
# • Legacy-контур бонусных выплат EFHC (bonus_awards) guarded/no-op.
#
# Жёсткие каноны:
# 1) НЕТ внутренних переводов между пользователями (P2P).
# Любое движение EFHC:
# Банк ↔ Пользователь
# и только через банковский сервис (transactions_service).
# 2) Все бонусные начисления идут только в бонусный баланс пользователя
# (bonus_balance / bonus ветка банка).
# 3) Все операции (выводы, бонусы) ИДЕМПОТЕНТНЫ:
# - обязательный idempotency_key (админ/система передаёт его явно),
# - повторные вызовы с тем же ключом не создают дублей.
# 4) Для бонусов есть возможность фильтрации по VIP-статусу
# пользователя (is_vip) для приоритизации обработки.
# 5) Изменение статусов в таблицах:
# • withdrawal_requests: PENDING → PAID/REJECTED/CANCELED
# • bonus_awards:       LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE.
#
# Где храним данные:
# • efhc_core.withdraw_requests — заявки на вывод EFHC.
# • efhc_admin.bonus_awards — legacy/dead-code table, not active.
#
# ВНИМАНИЕ:
# • Финансовые изменения балансов всегда делегируются в
# app.services.transactions_service
# и нигде в этом модуле балансы пользователей напрямую не обновляются.
# ======================================================================

from __future__ import annotations

import json
from decimal import ROUND_DOWN, Decimal
from typing import Any, Literal

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.sql_aliases_core import canon_schema
from app.core.utils_core import (
    format_decimal_str,
)
from app.services.common_errors import EfhcConflictError
from app.services.outcome_service import (
    build_withdraw_outcome_bundle,
    save_withdraw_outcome_event,
    send_withdraw_outcome_telegram_notification,
)
from app.services.transactions_service import (
    credit_user_bonus_from_bank,
    credit_user_from_bank,
    debit_user_to_bank,
)
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from .admin_logging import AdminLogger
from .admin_notifications import AdminNotifier
from .admin_rbac import RBAC, AdminRole, AdminUser
from .admincommoncrud import AdminCommonCrud

logger = get_logger(__name__)
S = get_settings()

SCHEMA_ADMIN: str = canon_schema(
    getattr(S, "DB_SCHEMA_ADMIN", "efhc_admin") or "efhc_admin",
)
SCHEMA_CORE: str = canon_schema(
    getattr(S, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core",
)

BANK_EFHC: int = int(getattr(S, "BANK_EFHC", 0) or 0)
EFHC_DECIMALS: int = int(getattr(S, "EFHC_DECIMALS", 8) or 8)
_Q = Decimal(1).scaleb(-EFHC_DECIMALS)

LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE = (
    "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE"
)


def d8(x: Any) -> Decimal:
    """Округление вниз до EFHC_DECIMALS знаков (канон для EFHC)."""
    return Decimal(str(x)).quantize(_Q, rounding=ROUND_DOWN)


async def _legacy_bonus_awards_table_exists(db: AsyncSession) -> bool:
    """Return True only if the deprecated bonus_awards table exists.

    DB drift closure canon: bonus_awards is not an active table.
    Historical references require this explicit legacy guard.
    """
    sql = text(
        """
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = :schema
          AND table_name = 'bonus_awards'
        LIMIT 1
        """
    )
    r: Result = await db.execute(sql, {"schema": SCHEMA_ADMIN})
    return r.fetchone() is not None


async def _ensure_legacy_bonus_awards_table(db: AsyncSession) -> None:
    """Fail closed when legacy bonus_awards table is not present."""
    if await _legacy_bonus_awards_table_exists(db):
        return
    raise ValueError(
        LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE
        + ": bonus_awards is documented legacy/dead code"
    )


# ======================================================================
# Общие DTO и перечисления
# ======================================================================

_WithdrawSt = Literal[
    "PENDING",
    "PAID",
    "REJECTED",
    "CANCELED",
]


class WithdrawalStatus(str):
    """Статусы заявок на вывод EFHC."""

    PENDING = "PENDING"  # создана, ждёт обработки
    PAID = "PAID"  # успешно выплачена
    REJECTED = "REJECTED"  # отклонена админом
    CANCELED = "CANCELED"  # отменена


class BonusAwardStatus(str):
    """Статусы бонусных выплат EFHC (bonus_awards)."""

    PENDING = "PENDING"
    PAID = "PAID"
    REJECTED = "REJECTED"
    ERROR = "ERROR"


class WithdrawalFilters(BaseModel):
    """Фильтры для списка заявок на вывод EFHC."""

    global_id: int | None = None
    status: _WithdrawSt | None = None
    vip_only: bool = False
    limit: int = Field(100, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = True


class BonusAwardFilters(BaseModel):
    """Фильтры для списка бонусных выплат EFHC."""

    global_id: int | None = None
    status: _WithdrawSt | None = None
    source: str | None = None
    vip_only: bool = False
    limit: int = Field(100, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = True


class WithdrawalRecord(BaseModel):
    """Строка списка заявок на вывод для UI админки."""

    id: int
    global_id: int
    amount_efhc: str
    status: str
    external_address: str | None
    tx_hash: str | None
    created_at: str
    processed_at: str | None
    error_message: str | None
    is_vip: bool
    payout_asset: str = "EFHC"
    tonconnect_transport_kind: str | None = "jetton_transfer"
    jetton_master_address: str | None = None
    jetton_decimals: int | None = None
    fee_message_ton_amount: str | None = None


class BonusAwardRecord(BaseModel):
    """Строка списка бонусных выплат EFHC (bonus_awards)."""

    id: int
    global_id: int
    amount_efhc: str
    status: str
    source: str
    created_at: str
    processed_at: str | None
    meta_json: str | None
    is_vip: bool


class WithdrawalApproveRequest(BaseModel):
    """
    Запрос на подтверждение/выплату заявки на вывод.

    tx_hash                — внешний tx, можно указать позже.
    payout_ref             — proof/ref строки wallet-send события.
    wallet_send_confirmed  — был ли подтверждён факт нажатия Send.
    wallet_provider        — Tonkeeper / MyTonWallet / другой runtime.
    sender_wallet_address  — адрес кошелька оператора.
    idempotency_key        — ключ идемпотентности дебета.
    """

    tx_hash: str | None = None
    payout_ref: str | None = Field(default=None, max_length=255)
    wallet_send_confirmed: bool = False
    wallet_provider: str | None = Field(default=None, max_length=64)
    sender_wallet_address: str | None = Field(
        default=None,
        max_length=255,
    )
    comment_override: str | None = Field(default=None, max_length=1500)
    comment_auto_translated: bool = False
    idempotency_key: str = Field(..., min_length=1, max_length=128)

    @field_validator("idempotency_key")
    def _v_idem(cls, v: str) -> str:
        """Валидация idempotency_key."""
        v = (v or "").strip()
        if not v:
            raise ValueError("idempotency_key обязателен")
        return v


class BonusAwardProcessRequest(BaseModel):
    """
    Запрос на выплату бонуса EFHC из bonus_awards.

    Для совместимости с outcome-service допускаем такой же
    payload подтверждения, как и у обычного approve path.
    """

    tx_hash: str | None = None
    payout_ref: str | None = Field(default=None, max_length=255)
    wallet_send_confirmed: bool = False
    wallet_provider: str | None = Field(default=None, max_length=64)
    sender_wallet_address: str | None = Field(
        default=None,
        max_length=255,
    )
    comment_override: str | None = Field(default=None, max_length=1500)
    comment_auto_translated: bool = False
    idempotency_key: str = Field(..., min_length=1, max_length=128)

    @field_validator("idempotency_key")
    def _v_idem(cls, v: str) -> str:
        """Валидация idempotency_key."""
        v = (v or "").strip()
        if not v:
            raise ValueError("idempotency_key обязателен")
        return v


# ======================================================================
# Сервис обработки выводов и бонусов
# ======================================================================


class WithdrawalsService:
    """Admin-сервис очередей: выводы и бонусы."""

    # --------------------------------------------------------------
    # БЛОК 1. Список заявок на вывод EFHC
    # --------------------------------------------------------------

    @staticmethod
    async def list_withdrawals(
        db: AsyncSession,
        filters: WithdrawalFilters,
    ) -> list[WithdrawalRecord]:
        """
        Возвращает список заявок на вывод EFHC.

        Особенности:
          • Можно фильтровать по global_id, status.
          • vip_only = True — выбираем только пользователей с is_vip.
          • Сортировка по id (DESC/ASC).
        """
        where = ["1=1"]
        params: dict[str, Any] = {
            "limit": filters.limit,
            "offset": filters.offset,
        }

        if filters.global_id is not None:
            where.append("w.global_id = :global_id")
            params["global_id"] = filters.global_id
        if getattr(filters, "global_id", None) is not None:
            where.append("u.global_id = :tg")
            params["tg"] = int(filters.global_id or 0)
        if filters.status is not None:
            where.append("w.status = :st")
            params["st"] = filters.status
        if filters.vip_only:
            where.append("u.is_vip = TRUE")
        order = "DESC" if filters.sort_desc else "ASC"

        items = await AdminCommonCrud.fetch_all(
            db,
            sql=(
                "\n".join(
                    [
                        "SELECT",
                        "    w.id,",
                        "    u.global_id,",
                        "    w.amount,",
                        "    w.status,",
                        "    w.external_address,",
                        "    w.tx_hash,",
                        "    w.created_at,",
                        "    w.processed_at,",
                        "    w.error_message,",
                        "    COALESCE(u.is_vip, FALSE) AS is_vip",
                        "FROM " + SCHEMA_CORE + ".withdraw_requests w",
                        (
                            "JOIN "
                            + SCHEMA_CORE
                            + ".users u ON u.global_id = w.global_id"
                        ),
                        f"WHERE {' AND '.join(where)}",
                        f"ORDER BY w.id {order}",
                        "LIMIT :limit OFFSET :offset",
                    ]
                )
            ),
            params=params,
        )

        out: list[WithdrawalRecord] = []
        for row in items:
            created = row.get("created_at")
            processed = row.get("processed_at")
            created_iso = getattr(created, "isoformat", None)
            created_s = (
                created_iso() if callable(created_iso) else str(created)
            )
            iso = getattr(processed, "isoformat", None)
            processed_s = iso() if callable(iso) else None
            out.append(
                WithdrawalRecord(
                    id=int(row["id"]),
                    global_id=int(row["global_id"]),
                    amount_efhc=str(row["amount"]),
                    status=str(row["status"]),
                    external_address=row.get("external_address"),
                    tx_hash=row.get("tx_hash"),
                    created_at=created_s,
                    processed_at=processed_s,
                    error_message=row.get("error_message"),
                    is_vip=bool(row.get("is_vip")),
                    payout_asset="EFHC",
                    tonconnect_transport_kind="jetton_transfer",
                    jetton_master_address=(
                        str(
                            getattr(
                                S,
                                "EFHC_JETTON_MASTER_ADDRESS",
                                "",
                            )
                            or ""
                        )
                        or None
                    ),
                    jetton_decimals=int(
                        getattr(S, "EFHC_JETTON_DECIMALS", 8) or 8
                    ),
                    fee_message_ton_amount=(
                        str(
                            getattr(
                                S,
                                "JETTON_TRANSFER_FEE_NANO",
                                "",
                            )
                            or ""
                        )
                        or None
                    ),
                )
            )
        return out

    # --------------------------------------------------------------
    # БЛОК 2. Обработка заявки на вывод EFHC (approve / reject)
    # --------------------------------------------------------------

    @staticmethod
    async def approve_withdrawal(
        db: AsyncSession,
        *,
        withdrawal_id: int,
        req: WithdrawalApproveRequest,
        admin: AdminUser,
    ) -> dict[str, Any]:
        """
        Подтверждает и проводит заявку на вывод EFHC:

          • Проверяет статус заявки (должен быть PENDING).
          • Делает дебет пользователя → Банк по основному балансу.
          • Обновляет статус заявки на PAID и сохраняет tx/idempotency.
          • В случае ошибки:
              - статус заявки остаётся PENDING,
              - error_message заполняется,
              - исключение прокидывается наверх в «дружелюбном» виде.

        RBAC:
          • Минимум MODERATOR.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        if not req.idempotency_key.strip():
            raise ValueError("idempotency_key обязателен")

        # Берём заявку под лок (FOR UPDATE), чтобы не было гонки.
        r: Result = await db.execute(
            text(
                """
            SELECT
                    id,
                    global_id,
                    amount,
                    status,
                    idempotency_key,
                    hold_done,
                    refund_done,
                    external_address,
                    tx_hash,
                    processing_idempotency_key,
                    error_message
                FROM efhc_core.withdraw_requests
                WHERE id = :wid
                FOR UPDATE"""
            ),
            {"wid": withdrawal_id},
        )
        row = r.fetchone()
        if not row:
            raise ValueError("Заявка на вывод не найдена")

        final_statuses = (
            WithdrawalStatus.PAID,
            WithdrawalStatus.REJECTED,
            WithdrawalStatus.CANCELED,
        )
        processing_ik = str(row.processing_idempotency_key or "")
        if row.status in final_statuses:
            if (
                row.status == WithdrawalStatus.PAID
                and processing_ik == req.idempotency_key
            ):
                return {
                    "ok": True,
                    "status": WithdrawalStatus.PAID,
                    "idempotency_key": req.idempotency_key,
                    "tx_hash": row.tx_hash,
                }
            logger.info(
                "approve_withdrawal: withdrawal_id=%s final=%s",
                withdrawal_id,
                row.status,
            )
            raise EfhcConflictError("already processed")

        # Проверка идемпотентности обработки: если уже есть
        # processing_idempotency_key
        if processing_ik:
            if processing_ik == req.idempotency_key:
                # Повторный вызов с тем же ключом — idempotent replay.
                logger.info(
                    "approve_withdrawal: idem=%s wid=%s",
                    req.idempotency_key,
                    withdrawal_id,
                )
                return {
                    "ok": True,
                    "status": str(row.status),
                    "idempotency_key": req.idempotency_key,
                    "tx_hash": row.tx_hash,
                }
            else:
                raise EfhcConflictError(
                    "already processing with another key"
                )

        global_id = int(row.global_id)
        amount = d8(row.amount)
        # Если холд не был сделан — пытаемся восстановить.
        if not bool(row.hold_done):
            try:
                await debit_user_to_bank(
                    db,
                    global_id=global_id,
                    amount=amount,
                    reason="withdraw_hold_repair",
                    idempotency_key=f"{str(row.idempotency_key)}:hold",
                    meta={
                        "admin_id": admin.id,
                        "admin_role": admin.role,
                        "withdrawal_id": withdrawal_id,
                        "source": "withdraw_request_repair",
                    },
                )
                res = await db.execute(
                    text(
                        """
            UPDATE efhc_core.withdraw_requests
                        SET hold_done = TRUE,
                            updated_at = NOW() AT TIME ZONE 'UTC'
                        WHERE id = :wid
                          AND status = 'PENDING'"""
                    ),
                    {"wid": withdrawal_id},
                )
                if getattr(res, "rowcount", 0) == 0:
                    logger.warning(
                        (
                            "hold_done update skipped "
                            "(not PENDING): wid=%s"
                        ),
                        withdrawal_id,
                    )
            except Exception as e:
                err_text = f"{type(e).__name__}: {e}"
                res = await db.execute(
                    text(
                        """
            UPDATE efhc_core.withdraw_requests
                        SET processing_idempotency_key = :ik,
                            error_message = :err,
                            updated_at = NOW() AT TIME ZONE 'UTC'
                        WHERE id = :wid
                          AND status = 'PENDING'"""
                    ),
                    {
                        "ik": req.idempotency_key,
                        "err": err_text[:500],
                        "wid": withdrawal_id,
                    },
                )
                if getattr(res, "rowcount", 0) == 0:
                    logger.warning(
                        (
                            "withdraw error update skipped "
                            "(not PENDING): wid=%s"
                        ),
                        withdrawal_id,
                    )
                await AdminLogger.write(
                    db,
                    admin_id=admin.id,
                    action="WITHDRAWAL_ERROR",
                    entity="withdraw_request",
                    entity_id=withdrawal_id,
                    details=err_text,
                )
                msg = f"Не удалось выполнить холд по заявке: {err_text}"
                raise ValueError(msg) from e

        # Помечаем заявку как PAID.
        r_paid: Result = await db.execute(
            text("""
                UPDATE efhc_core.withdraw_requests 
                   SET status = 'PAID',
                       processing_idempotency_key = :ik,
                       tx_hash = COALESCE(:txh, tx_hash),
                       payout_ref = COALESCE(:pref, payout_ref),
                       error_message = NULL,
                       processed_at = NOW() AT TIME ZONE 'UTC'
                 WHERE id = :wid
                   AND status = 'PENDING'
                """),
            {
                "ik": req.idempotency_key,
                "txh": req.tx_hash,
                "pref": req.payout_ref,
                "wid": withdrawal_id,
            },
        )
        if int(getattr(r_paid, "rowcount", 0) or 0) == 0:
            await AdminLogger.write(
                db,
                admin_id=admin.id,
                action="WITHDRAWAL_PAID_FORBIDDEN",
                entity="withdrawal",
                entity_id=withdrawal_id,
                details="transition forbidden",
            )
            raise ValueError("Переход запрещён")

        amount_s = format_decimal_str(amount, EFHC_DECIMALS)
        details = (
            f"global_id={global_id}; amount={amount_s}; "
            f"tx_hash={req.tx_hash or ''}; "
            f"payout_ref={req.payout_ref or ''}; "
            f"wallet_send_confirmed={req.wallet_send_confirmed}; "
            f"wallet_provider={req.wallet_provider or ''}; "
            f"sender_wallet={req.sender_wallet_address or ''}"
        )
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="WITHDRAWAL_PAID",
            entity="withdrawal",
            entity_id=withdrawal_id,
            details=details,
        )

        message = (
            f"Выплачен вывод # {withdrawal_id} пользователю {global_id} "
            f"на сумму {amount_s} EFHC"
        )
        payload = {
            "withdrawal_id": withdrawal_id,
            "global_id": global_id,
            "amount": amount_s,
            "tx_hash": req.tx_hash or "",
            "payout_ref": req.payout_ref or "",
            "wallet_send_confirmed": bool(req.wallet_send_confirmed),
            "wallet_provider": req.wallet_provider or "",
            "sender_wallet_address": req.sender_wallet_address or "",
        }
        outcome_bundle = await build_withdraw_outcome_bundle(
            db,
            request_id=withdrawal_id,
            global_id=global_id,
            outcome_kind="success",
            manual_comment=req.comment_override,
            auto_translated=bool(req.comment_auto_translated),
        )
        outcome_bundle.metadata.update(
            {
                "status": WithdrawalStatus.PAID,
                "tx_hash": req.tx_hash or "",
                "payout_ref": req.payout_ref or "",
                "wallet_send_confirmed": bool(
                    req.wallet_send_confirmed
                ),
                "wallet_provider": req.wallet_provider or "",
                "sender_wallet_address": (
                    req.sender_wallet_address or ""
                ),
            }
        )
        await save_withdraw_outcome_event(
            db,
            bundle=outcome_bundle,
        )
        await send_withdraw_outcome_telegram_notification(
            db,
            bundle=outcome_bundle,
        )
        payload_json = json.dumps(payload, ensure_ascii=False)
        await AdminNotifier.notify_generic(
            db,
            event="WITHDRAWAL_PAID",
            message=message,
            payload_json=payload_json,
        )
        await db.commit()

        return {
            "ok": True,
            "status": WithdrawalStatus.PAID,
            "idempotency_key": req.idempotency_key,
            "tx_hash": req.tx_hash,
            "payout_ref": req.payout_ref,
            "wallet_send_confirmed": bool(req.wallet_send_confirmed),
            "wallet_provider": req.wallet_provider,
            "sender_wallet_address": req.sender_wallet_address,
            "outcome": {
                "request_id": outcome_bundle.request_id,
                "global_id": outcome_bundle.global_id,
                "outcome_kind": outcome_bundle.outcome_kind,
                "locale": outcome_bundle.locale,
                "comment": {
                    "text": outcome_bundle.comment.text,
                    "template_key": outcome_bundle.comment.template_key,
                    "source": outcome_bundle.comment.source,
                    "locale": outcome_bundle.comment.locale,
                    "manual_override_used": (
                        outcome_bundle.comment.manual_override_used
                    ),
                    "auto_translated": (
                        outcome_bundle.comment.auto_translated
                    ),
                },
                "promo": (
                    None
                    if outcome_bundle.promo is None
                    else {
                        "enabled": outcome_bundle.promo.enabled,
                        "key": outcome_bundle.promo.key,
                        "title": outcome_bundle.promo.title,
                        "body": outcome_bundle.promo.body,
                        "cta_label": outcome_bundle.promo.cta_label,
                        "cta_url": outcome_bundle.promo.cta_url,
                        "source": outcome_bundle.promo.source,
                    }
                ),
                "top_zone_enabled": bool(outcome_bundle.promo),
                "metadata": outcome_bundle.metadata,
            },
        }

    @staticmethod
    async def reject_withdrawal(
        db: AsyncSession,
        *,
        withdrawal_id: int,
        reason: str,
        idempotency_key: str,
        admin: AdminUser,
        comment_override: str | None = None,
        comment_auto_translated: bool = False,
    ) -> dict[str, Any]:
        """Отклоняет заявку на вывод EFHC с идемпотентностью."""
        RBAC.require_role(admin, AdminRole.MODERATOR)
        ik = str(idempotency_key).strip()
        if not ik:
            raise ValueError("idempotency_key обязателен")

        r_req: Result = await db.execute(
            text(
                """
                SELECT
                    id,
                    global_id,
                    amount,
                    status,
                    idempotency_key,
                    hold_done,
                    refund_done,
                    processing_idempotency_key
                FROM efhc_core.withdraw_requests
                WHERE id = :wid
                FOR UPDATE
                """
            ),
            {"wid": withdrawal_id},
        )
        row = r_req.fetchone()
        if not row:
            raise ValueError("Заявка на вывод не найдена")

        final_statuses = (
            WithdrawalStatus.PAID,
            WithdrawalStatus.REJECTED,
            WithdrawalStatus.CANCELED,
        )
        processing_ik = str(row.processing_idempotency_key or "")
        if row.status in final_statuses:
            if (
                row.status == WithdrawalStatus.REJECTED
                and processing_ik == ik
            ):
                return {
                    "ok": True,
                    "status": WithdrawalStatus.REJECTED,
                    "reason": reason,
                    "idempotency_key": ik,
                }
            raise EfhcConflictError("already processed")
        if processing_ik:
            if processing_ik == ik:
                return {
                    "ok": True,
                    "status": str(row.status),
                    "reason": reason,
                    "idempotency_key": ik,
                }
            raise EfhcConflictError(
                "withdrawal already processing with another key"
            )

        r_rej: Result = await db.execute(
            text(
                """
                UPDATE efhc_core.withdraw_requests
                   SET status = 'REJECTED',
                       processing_idempotency_key = :ik,
                       error_message = :reason,
                       processed_at = NOW() AT TIME ZONE 'UTC'
                 WHERE id = :wid
                   AND status = 'PENDING'
                RETURNING
                   global_id,
                   amount,
                   idempotency_key,
                   hold_done,
                   refund_done
                """
            ),
            {
                "ik": ik,
                "reason": reason[:500],
                "wid": withdrawal_id,
            },
        )
        row = r_rej.fetchone()
        if not row:
            await AdminLogger.write(
                db,
                admin_id=admin.id,
                action="WITHDRAWAL_REJECT_FORBIDDEN",
                entity="withdrawal",
                entity_id=withdrawal_id,
                details="transition forbidden",
            )
            raise ValueError("Переход запрещён")

        if bool(row.hold_done) and not bool(row.refund_done):
            await credit_user_from_bank(
                db,
                global_id=int(row.global_id),
                amount=d8(row.amount),
                reason="withdraw_refund",
                idempotency_key=f"{str(row.idempotency_key)}:refund",
            )
            await db.execute(
                text(
                    """
                    UPDATE efhc_core.withdraw_requests
                       SET refund_done = TRUE,
                           updated_at = NOW() AT TIME ZONE 'UTC'
                     WHERE id = :wid
                    """
                ),
                {"wid": withdrawal_id},
            )

        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="WITHDRAWAL_REJECT",
            entity="withdrawal",
            entity_id=withdrawal_id,
            details=reason,
        )
        outcome_bundle = await build_withdraw_outcome_bundle(
            db,
            request_id=withdrawal_id,
            global_id=int(row.global_id),
            outcome_kind="reject",
            manual_comment=(comment_override or reason),
            auto_translated=bool(comment_auto_translated),
        )
        outcome_bundle.metadata.update(
            {"status": WithdrawalStatus.REJECTED, "reason": reason}
        )
        await save_withdraw_outcome_event(
            db,
            bundle=outcome_bundle,
        )
        await send_withdraw_outcome_telegram_notification(
            db,
            bundle=outcome_bundle,
        )
        await AdminNotifier.notify_generic(
            db,
            event="WITHDRAWAL_REJECT",
            message=f"Отклонён вывод #{withdrawal_id}: {reason}",
        )
        await db.commit()
        return {
            "ok": True,
            "status": WithdrawalStatus.REJECTED,
            "reason": reason,
            "idempotency_key": ik,
            "outcome": {
                "request_id": outcome_bundle.request_id,
                "global_id": outcome_bundle.global_id,
                "outcome_kind": outcome_bundle.outcome_kind,
                "locale": outcome_bundle.locale,
                "comment": {
                    "text": outcome_bundle.comment.text,
                    "template_key": outcome_bundle.comment.template_key,
                    "source": outcome_bundle.comment.source,
                    "locale": outcome_bundle.comment.locale,
                    "manual_override_used": (
                        outcome_bundle.comment.manual_override_used
                    ),
                    "auto_translated": (
                        outcome_bundle.comment.auto_translated
                    ),
                },
                "promo": None,
                "top_zone_enabled": False,
                "metadata": outcome_bundle.metadata,
            },
        }

    # --------------------------------------------------------------
    # БЛОК 3. Бонусные выплаты EFHC (bonus_awards → бонусный баланс)
    # --------------------------------------------------------------

    @staticmethod
    async def list_bonus_awards(
        db: AsyncSession,
        filters: BonusAwardFilters,
    ) -> list[BonusAwardRecord]:
        """
        Возвращает legacy bonus_awards, если таблица есть.

        В активном каноне таблицы нет: возвращается пустой список.
        Можно фильтровать по global_id, status, source и vip_only.
        """
        if not await _legacy_bonus_awards_table_exists(db):
            return []

        where = ["1=1"]
        params: dict[str, Any] = {
            "limit": filters.limit,
            "offset": filters.offset,
        }
        if filters.global_id is not None:
            where.append("b.global_id = :global_id")
            params["global_id"] = filters.global_id
        if filters.status is not None:
            where.append("b.status = :st")
            params["st"] = filters.status
        if filters.source is not None:
            where.append("b.source = :src")
            params["src"] = filters.source
        if filters.vip_only:
            where.append("u.is_vip = TRUE")

        order = "DESC" if filters.sort_desc else "ASC"
        where_clause = " AND ".join(where)
        sql_tpl = """
            SELECT
                b.id,
                b.global_id,
                b.amount,
                b.status,
                b.source,
                b.created_at,
                b.processed_at,
                b.meta_json,
                COALESCE(u.is_vip, FALSE) AS is_vip
            FROM efhc_admin.bonus_awards b
            JOIN efhc_core.users u ON u.global_id = b.global_id
            WHERE {where_clause}
            ORDER BY b.id {order}
            LIMIT :limit OFFSET :offset
            """
        sql = text(
            sql_tpl.replace("efhc_admin", SCHEMA_ADMIN)
            .replace("efhc_core", SCHEMA_CORE)
            .replace("{where_clause}", where_clause)
            .replace("{order}", order)
        )
        r: Result = await db.execute(sql, params)
        out: list[BonusAwardRecord] = []
        for row in r.fetchall():
            created = row.created_at
            processed = getattr(row, "processed_at", None)
            created_iso = getattr(created, "isoformat", None)
            created_s = (
                created_iso() if callable(created_iso) else str(created)
            )
            iso = getattr(processed, "isoformat", None)
            processed_s = iso() if callable(iso) else None
            meta_raw = getattr(row, "meta_json", None)
            meta_json = str(meta_raw) if meta_raw is not None else None
            out.append(
                BonusAwardRecord(
                    id=int(row.id),
                    global_id=int(row.global_id),
                    amount_efhc=str(row.amount),
                    status=str(row.status),
                    source=str(row.source),
                    created_at=created_s,
                    processed_at=processed_s,
                    meta_json=meta_json,
                    is_vip=bool(row.is_vip),
                )
            )
        return out

    @staticmethod
    async def process_bonus_award(
        db: AsyncSession,
        *,
        award_id: int,
        req: BonusAwardProcessRequest,
        admin: AdminUser,
    ) -> dict[str, Any]:
        """
        Выплачивает бонус EFHC по записи bonus_awards.

          • Требует статус PENDING или ERROR.
          • Использует credit_user_bonus_from_bank(...).
          • Обновляет статус bonus_awards на PAID и сохраняет ключ.
          • Идемпотентен по полю processing_idempotency_key.

        RBAC:
          • Минимум MODERATOR.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        await _ensure_legacy_bonus_awards_table(db)
        if not req.idempotency_key.strip():
            raise ValueError("idempotency_key обязателен")

        # Читаем запись
        r: Result = await db.execute(
            text(
                """
            SELECT
                    id,
                    global_id,
                    amount,
                    status,
                    processing_idempotency_key,
                    source
                FROM efhc_admin.bonus_awards
                WHERE id = :aid
                FOR UPDATE"""
            ),
            {"aid": award_id},
        )
        row = r.fetchone()
        if not row:
            raise ValueError("Бонусная запись не найдена")

        final_statuses = (
            BonusAwardStatus.PAID,
            BonusAwardStatus.REJECTED,
        )
        if row.status in final_statuses:
            return {
                "ok": False,
                "status": str(row.status),
                "detail": "Бонус уже обработан",
            }

        # Идемпотентность
        if row.processing_idempotency_key:
            processing_ik = str(row.processing_idempotency_key)
            if processing_ik == req.idempotency_key:
                logger.info(
                    "process_bonus_award: idem=%s aid=%s",
                    req.idempotency_key,
                    award_id,
                )
                return {
                    "ok": True,
                    "status": str(row.status),
                    "idempotency_key": req.idempotency_key,
                }
            else:
                raise ValueError(
                    "Бонус уже обрабатывается с другим ключом"
                )

        global_id = int(row.global_id)
        amount = d8(row.amount)
        src = str(row.source)

        meta = {
            "admin_id": admin.id,
            "admin_role": admin.role,
            "award_id": award_id,
            "source": src,
        }

        try:
            await credit_user_bonus_from_bank(
                db,
                global_id=global_id,
                amount=amount,
                reason=f"bonus_award:{src}",
                idempotency_key=req.idempotency_key,
                meta=meta,
            )
        except Exception as e:
            err_text = f"{type(e).__name__}: {e}"
            logger.warning(
                "process_bonus_award: credit failed aid=%s tg=%s: %s",
                award_id,
                global_id,
                err_text,
            )
            res = await db.execute(
                text(
                    """
            UPDATE efhc_admin.bonus_awards
                    SET status = 'ERROR',
                        processing_idempotency_key=:ik,
                        processed_at = NOW() AT TIME ZONE 'UTC'
                    WHERE id = :aid
                      AND status = 'PENDING'"""
                ),
                {"ik": req.idempotency_key, "aid": award_id},
            )
            if getattr(res, "rowcount", 0) == 0:
                logger.warning(
                    (
                        "BONUS_AWARD ERROR update skipped "
                        "(not PENDING): aid=%s"
                    ),
                    award_id,
                )
            await AdminLogger.write(
                db,
                admin_id=admin.id,
                action="BONUS_AWARD_ERROR",
                entity="bonus_awards",
                entity_id=award_id,
                details=err_text,
            )
            msg = f"Не удалось начислить бонус EFHC: {err_text}"
            raise ValueError(msg) from e

        res = await db.execute(
            text(
                """
            UPDATE efhc_admin.bonus_awards
                SET status = 'PAID',
                    processing_idempotency_key=:ik,
                    processed_at = NOW() AT TIME ZONE 'UTC'
                WHERE id = :aid
                  AND status = 'PENDING'"""
            ),
            {"ik": req.idempotency_key, "aid": award_id},
        )
        if getattr(res, "rowcount", 0) == 0:
            logger.warning(
                (
                    "BONUS_AWARD PAID update skipped "
                    "(not PENDING): aid=%s"
                ),
                award_id,
            )

        amount_s = format_decimal_str(amount, EFHC_DECIMALS)
        details = f"global_id={global_id}; amount={amount_s}"
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="BONUS_AWARD_PAID",
            entity="bonus_awards",
            entity_id=award_id,
            details=details,
        )

        message = (
            f"Выплачен бонус {amount_s} EFHC пользователю {global_id} "
            "(bonus)"
        )
        payload = {
            "award_id": award_id,
            "global_id": global_id,
            "amount": amount_s,
            "source": src,
            "admin_id": admin.id,
        }
        outcome_bundle = await build_withdraw_outcome_bundle(
            db,
            request_id=award_id,
            global_id=global_id,
            outcome_kind="success",
            manual_comment=req.comment_override,
            auto_translated=bool(req.comment_auto_translated),
        )
        outcome_bundle.metadata.update(
            {
                "status": WithdrawalStatus.PAID,
                "tx_hash": req.tx_hash or "",
                "payout_ref": req.payout_ref or "",
                "wallet_send_confirmed": bool(
                    req.wallet_send_confirmed
                ),
                "wallet_provider": req.wallet_provider or "",
                "sender_wallet_address": (
                    req.sender_wallet_address or ""
                ),
            }
        )
        await save_withdraw_outcome_event(
            db,
            bundle=outcome_bundle,
        )
        payload_json = json.dumps(payload, ensure_ascii=False)
        await AdminNotifier.notify_generic(
            db,
            event="BONUS_AWARD_PAID",
            message=message,
            payload_json=payload_json,
        )

        return {
            "ok": True,
            "status": BonusAwardStatus.PAID,
            "idempotency_key": req.idempotency_key,
        }

    @staticmethod
    async def reject_bonus_award(
        db: AsyncSession,
        *,
        award_id: int,
        reason: str,
        admin: AdminUser,
    ) -> dict[str, Any]:
        """
        Отклоняет бонусную выплату (без движения средств).

        Используется, если запись bonus_awards создана ошибочно или
        больше не актуальна.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        await _ensure_legacy_bonus_awards_table(db)

        r: Result = await db.execute(
            text(
                """
            SELECT id, status
                FROM efhc_admin.bonus_awards
                WHERE id = :aid
                LIMIT 1"""
            ),
            {"aid": award_id},
        )
        row = r.fetchone()
        if not row:
            raise ValueError("Бонусная запись не найдена")

        final_statuses = (
            BonusAwardStatus.PAID,
            BonusAwardStatus.REJECTED,
        )
        if row.status in final_statuses:
            return {
                "ok": False,
                "status": str(row.status),
                "detail": "Бонус уже обработан",
            }

        res = await db.execute(
            text(
                """
            UPDATE efhc_admin.bonus_awards
                SET status = 'REJECTED',
                    processed_at = NOW() AT TIME ZONE 'UTC'
                WHERE id = :aid
                  AND status = 'PENDING'"""
            ),
            {"aid": award_id},
        )
        if getattr(res, "rowcount", 0) == 0:
            logger.warning(
                (
                    "BONUS_AWARD REJECTED update skipped "
                    "(not PENDING): aid=%s"
                ),
                award_id,
            )

        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="BONUS_AWARD_REJECT",
            entity="bonus_awards",
            entity_id=award_id,
            details=reason,
        )

        await AdminNotifier.notify_generic(
            db,
            event="BONUS_AWARD_REJECT",
            message=f"Отклонён бонус  # {award_id}: {reason}",
        )

        return {"ok": True, "status": BonusAwardStatus.REJECTED}


__all__ = [
    "WithdrawalStatus",
    "BonusAwardStatus",
    "WithdrawalFilters",
    "BonusAwardFilters",
    "WithdrawalRecord",
    "BonusAwardRecord",
    "WithdrawalApproveRequest",
    "BonusAwardProcessRequest",
    "WithdrawalsService",
    "LEGACY_BONUS_AWARDS_NO_ACTIVE_TABLE",
]
