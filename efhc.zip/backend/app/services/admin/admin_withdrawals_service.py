# -*- coding: utf-8 -*-
# backend/app/services/admin/admin_withdrawals_service.py
# ======================================================================
# EFHC Bot — Сервис выдачи EFHC и NFT (выводы, бонусы, призы)
# ----------------------------------------------------------------------
# Назначение модуля:
# • Управление заявками на вывод EFHC пользователями.
# • Управление очередью бонусных выплат EFHC (bonus_awards).
# • Управление заявками на выдачу NFT (prize_claims).
#
# Жёсткие каноны:
# 1) НЕТ внутренних переводов между пользователями (P2P).
# Любое движение EFHC:
# Банк ↔ Пользователь
# и только через банковский сервис (transactions_service).
# 2) Все бонусные начисления идут только в бонусный баланс пользователя
# (bonus_balance / bonus ветка банка).
# 3) Все операции (выводы, бонусы, призы) ИДЕМПОТЕНТНЫ:
# - обязательный idempotency_key (админ/система передаёт его явно),
# - повторные вызовы с тем же ключом не создают дублей.
# 4) Для NFT-призов и бонусов есть возможность фильтрации по VIP-статусу
# пользователя (is_vip) для приоритизации обработки.
# 5) Изменение статусов в таблицах:
# • withdrawal_requests: PENDING → PAID/REJECTED/CANCELED
# • bonus_awards:       PENDING → PAID/REJECTED/ERROR
# • prize_claims:       PENDING → DONE /REJECTED
#
# Где храним данные:
# • {SCHEMA_CORE}.withdraw_requests — заявки на вывод EFHC.
# • {SCHEMA_ADMIN}.bonus_awards — бонусные выплаты EFHC.
# • {SCHEMA_ADMIN}.prize_claims — заявки на выдачу NFT.
#
# ВНИМАНИЕ:
# • Финансовые изменения балансов всегда делегируются в
# app.services.transactions_service
# и нигде в этом модуле балансы пользователей напрямую не обновляются.
# ======================================================================

from __future__ import annotations

import json

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.utils_core import (
    format_decimal_str,
    quantize_decimal,
)

from app.services.transactions_service import (
    credit_user_bonus_from_bank,
    credit_user_from_bank,
    debit_user_to_bank,
)
from app.services.common_errors import EfhcConflictError

from .admin_rbac import AdminUser, AdminRole, RBAC
from .admin_logging import AdminLogger
from .admin_notifications import AdminNotifier
from .admincommoncrud import AdminCommonCrud

logger = get_logger(__name__)
S = get_settings()

SCHEMA_ADMIN: str = (
    S.DB_SCHEMA_ADMIN or "efhc_admin"
)
SCHEMA_CORE: str = (
    getattr(S, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core"
)

BANK_TG_ID: int = int(getattr(S, "BANK_TG_ID", 0) or 0)
EFHC_DECIMALS: int = int(getattr(S, "EFHC_DECIMALS", 8) or 8)
_Q = Decimal(1).scaleb(-EFHC_DECIMALS)


def d8(x: Any) -> Decimal:
    """Округление вниз до EFHC_DECIMALS знаков (канон для EFHC)."""
    return Decimal(str(x)).quantize(_Q, rounding=ROUND_DOWN)

# ======================================================================
# Общие DTO и перечисления
# ======================================================================

_WithdrawSt = Literal[
    "PENDING",
    "PAID",
    "REJECTED",
    "CANCELED",
    "ERROR",
]


class WithdrawalStatus(str):
    """Статусы заявок на вывод EFHC."""
    PENDING = "PENDING"  # создана, ждёт обработки
    PAID = "PAID"  # успешно выплачена
    REJECTED = "REJECTED"  # отклонена админом
    CANCELED = "CANCELED"  # отменена
    ERROR = "ERROR"  # ошибка при обработке (нужна ручная проверка)


class BonusAwardStatus(str):
    """Статусы бонусных выплат EFHC (bonus_awards)."""
    PENDING = "PENDING"
    PAID = "PAID"
    REJECTED = "REJECTED"
    ERROR = "ERROR"


class PrizeClaimStatus(str):
    """Статусы выдачи призов (NFT/иное)."""
    PENDING = "PENDING"
    DONE = "DONE"
    REJECTED = "REJECTED"


class WithdrawalFilters(BaseModel):
    """Фильтры для списка заявок на вывод EFHC."""
    tg_id: Optional[int] = None
    status: Optional[_WithdrawSt] = None
    vip_only: bool = False
    limit: int = Field(100, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = True


class BonusAwardFilters(BaseModel):
    """Фильтры для списка бонусных выплат EFHC."""
    tg_id: Optional[int] = None
    status: Optional[_WithdrawSt] = None
    source: Optional[str] = None
    vip_only: bool = False
    limit: int = Field(100, ge = 1, le = 500)
    offset: int = Field(0, ge = 0)
    sort_desc: bool = True


class PrizeClaimFilters(BaseModel):
    """Фильтры для заявок на выдачу призов (NFT и др.)."""
    tg_id: Optional[int] = None
    status: Optional[Literal["PENDING", "DONE", "REJECTED"]] = None
    vip_only: bool = False
    prize_type: Optional[str] = None  # например "NFT_VIP"
    limit: int = Field(100, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = True


class WithdrawalRecord(BaseModel):
    """Строка списка заявок на вывод для UI админки."""
    id: int
    tg_id: int
    amount_efhc: str
    status: str
    external_address: Optional[str]
    tx_hash: Optional[str]
    created_at: str
    processed_at: Optional[str]
    error_message: Optional[str]
    is_vip: bool


class BonusAwardRecord(BaseModel):
    """Строка списка бонусных выплат EFHC (bonus_awards)."""
    id: int
    tg_id: int
    amount_efhc: str
    status: str
    source: str
    created_at: str
    processed_at: Optional[str]
    meta_json: Optional[str]
    is_vip: bool


class PrizeClaimRecord(BaseModel):
    """Строка списка заявок на призы (NFT и др.)."""
    id: int
    lotteries_id: Optional[int]
    tg_id: int
    prize_type: str
    prize_value: str
    wallet_address: Optional[str]
    status: str
    created_at: str
    processed_at: Optional[str]
    reject_reason: Optional[str]
    tx_hash: Optional[str]
    is_vip: bool


class WithdrawalApproveRequest(BaseModel):
    """
    Запрос на подтверждение/выплату заявки на вывод.

    tx_hash         — внешний tx, можно указать позже (опционально).
    idempotency_key  — ключ идемпотентности дебета пользователя → Банк.
    """
    tx_hash: Optional[str] = None
    idempotency_key: str = Field(..., min_length=1, max_length=128)

    @field_validator("idempotency_key")
    def _v_idem(cls, v: str) -> str:
        """Валидация idempotency_key."""
        v = (v or "").strip()
        if not v:
            raise ValueError("idempotency_key обязателен")
        return v


class BonusAwardProcessRequest(BaseModel):
    """
    Запрос на выплату бонуса EFHC из bonus_awards:

      idempotency_key — ключ идемпотентности начисления бонуса.
    """
    idempotency_key: str = Field(..., min_length=1, max_length=128)

    @field_validator("idempotency_key")
    def _v_idem(cls, v: str) -> str:
        """Валидация idempotency_key."""
        v = (v or "").strip()
        if not v:
            raise ValueError("idempotency_key обязателен")
        return v


class PrizeClaimProcessRequest(BaseModel):
    """
    Запрос на пометку заявки на приз как выполненной:

      tx_hash — внешний tx, если приз выдаётся на блокчейне (NFT).
    """
    tx_hash: Optional[str] = None


class PrizeClaimRejectRequest(BaseModel):
    """Запрос на отклонение заявки на приз (с указанием причины)."""
    reason: str = Field(..., min_length=1, max_length=500)


# ======================================================================
# Сервис обработки выводов, бонусов и призов
# ======================================================================


class WithdrawalsService:
    """Admin-сервис очередей: выводы, бонусы, призы."""

    # --------------------------------------------------------------
    # БЛОК 1. Список заявок на вывод EFHC
    # --------------------------------------------------------------

    @staticmethod
    async def list_withdrawals(
        db: AsyncSession,
        filters: WithdrawalFilters,
    ) -> List[WithdrawalRecord]:
        """
        Возвращает список заявок на вывод EFHC.

        Особенности:
          • Можно фильтровать по tg_id, status.
          • vip_only = True — выбираем только пользователей с is_vip.
          • Сортировка по id (DESC/ASC).
        """
        where = ["1=1"]
        params: Dict[str, Any] = {
            "limit": filters.limit,
            "offset": filters.offset,
        }

        if filters.tg_id is not None:
            where.append("w.tg_id = :tg_id")
            params["tg_id"] = filters.tg_id
        if getattr(filters, "tg_id", None) is not None:
            where.append("u.tg_id = :tg")
            params["tg"] = int(getattr(filters, "tg_id"))
        if filters.status is not None:
            where.append("w.status = :st")
            params["st"] = filters.status
        if filters.vip_only:
            where.append("u.is_vip = TRUE")
        order = "DESC" if filters.sort_desc else "ASC"

        items = await AdminCommonCrud.fetch_all(
            db,
            sql=(
                "\n".join(
                    [
                        "SELECT",
                        "    w.id,",
                        "    u.tg_id,",
                        "    w.amount,",
                        "    w.status,",
                        "    w.external_address,",
                        "    w.tx_hash,",
                        "    w.created_at,",
                        "    w.processed_at,",
                        "    w.error_message,",
                        "    COALESCE(u.is_vip, FALSE) AS is_vip",
                        f"FROM {SCHEMA_CORE}.withdraw_requests w",
                        f"JOIN {SCHEMA_CORE}.users u ON u.id = w.tg_id",
                        f"WHERE {' AND '.join(where)}",
                        f"ORDER BY w.id {order}",
                        "LIMIT :limit OFFSET :offset",
                    ]
                )
            ),
            params=params,
        )

        out: List[WithdrawalRecord] = []
        for row in items:
            created = row.get("created_at")
            processed = row.get("processed_at")
            created_s = (
                created.isoformat()
                if hasattr(created, "isoformat")
                else str(created)
            )
            processed_s = (
                processed.isoformat()
                if processed and hasattr(processed, "isoformat")
                else None
            )
            out.append(
                WithdrawalRecord(
                    id=int(row["id"]),
                    tg_id=int(row["tg_id"]),
                    amount_efhc=str(row["amount"]),
                    status=str(row["status"]),
                    external_address=row.get("external_address"),
                    tx_hash=row.get("tx_hash"),
                    created_at=created_s,
                    processed_at=processed_s,
                    error_message=row.get("error_message"),
                    is_vip=bool(row.get("is_vip")),
                )
            )
        return out

    # --------------------------------------------------------------
    # БЛОК 2. Обработка заявки на вывод EFHC (approve / reject)
    # --------------------------------------------------------------

    @staticmethod
    async def approve_withdrawal(
        db: AsyncSession,
        *,
        withdrawal_id: int,
        req: WithdrawalApproveRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Подтверждает и проводит заявку на вывод EFHC:

          • Проверяет статус заявки (должен быть PENDING).
          • Делает дебет пользователя → Банк по основному балансу.
          • Обновляет статус заявки на PAID и сохраняет tx/idempotency.
          • В случае ошибки:
              - статус заявки → ERROR,
              - error_message заполняется,
              - исключение прокидывается наверх в «дружелюбном» виде.

        RBAC:
          • Минимум MODERATOR.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        if not req.idempotency_key.strip():
            raise ValueError("idempotency_key обязателен")

        # Берём заявку под лок (FOR UPDATE), чтобы не было гонки.
        r: Result = await db.execute(text(f"""
                SELECT
                    id,
                    tg_id,
                    amount,
                    status,
                    idempotency_key,
                    hold_done,
                    refund_done,
                    external_address,
                    tx_hash,
                    processing_idempotency_key,
                    error_message
                FROM {SCHEMA_CORE}.withdraw_requests
                WHERE id = :wid
                FOR UPDATE
                """),
            {"wid": withdrawal_id},)
        row = r.fetchone()
        if not row:
            raise ValueError("Заявка на вывод не найдена")

        final_statuses = (
            WithdrawalStatus.PAID,
            WithdrawalStatus.REJECTED,
            WithdrawalStatus.CANCELED,
        )
        if row.status in final_statuses:
            logger.info(
                "approve_withdrawal: withdrawal_id=%s final=%s",
                withdrawal_id,
                row.status,
            )
            raise EfhcConflictError("already processed")

        # Проверка идемпотентности обработки: если уже есть
        # processing_idempotency_key
        if row.processing_idempotency_key:
            processing_ik = str(row.processing_idempotency_key)
            if processing_ik == req.idempotency_key:
                # Повторный вызов с тем же ключом — idempotent replay.
                logger.info(
                    "approve_withdrawal: idem=%s wid=%s",
                    req.idempotency_key,
                    withdrawal_id,
                )
                return {
                    "ok": True,
                    "status": str(row.status),
                    "idempotency_key": req.idempotency_key,
                    "tx_hash": row.tx_hash,
                }
            else:
                raise EfhcConflictError(
                    "already processing with another key"
                )

        tg_id = int(row.tg_id)
        amount = d8(row.amount)
        # Если холд не был сделан — пытаемся восстановить.
        if not bool(row.hold_done):
            try:
                await debit_user_to_bank(
                    db,
                    tg_id=tg_id,
                    amount=amount,
                    reason="withdraw_hold_repair",
                    idempotency_key=f"{str(row.idempotency_key)}:hold",
                    meta={
                        "admin_id": admin.id,
                        "admin_role": admin.role,
                        "withdrawal_id": withdrawal_id,
                        "source": "withdraw_request_repair",
                    },
                    spend_bonus_first=False,
                    forbid_user_negative=True,
                )
                res = await db.execute(text(f"""
                        UPDATE {SCHEMA_CORE}.withdraw_requests
                        SET hold_done = TRUE,
                            updated_at = NOW() AT TIME ZONE 'UTC'
                        WHERE id = :wid
                          AND status = 'PENDING'
                        """),
                    {"wid": withdrawal_id},)
                if getattr(res, "rowcount", 0) == 0:
                    logger.warning(
                        (
                            "hold_done update skipped "
                            "(not PENDING): wid=%s"
                        ),
                        withdrawal_id,
                    )
            except Exception as e:
                err_text = f"{type(e).__name__}: {e}"
                res = await db.execute(text(f"""
                        UPDATE {SCHEMA_CORE}.withdraw_requests
                        SET status = 'ERROR',
                            processing_idempotency_key = :ik,
                            error_message = :err,
                            processed_at = NOW() AT TIME ZONE 'UTC'
                        WHERE id = :wid
                          AND status = 'PENDING'
                        """),
                    {
                        "ik": req.idempotency_key,
                        "err": err_text[:500],
                        "wid": withdrawal_id,
                    },)
                if getattr(res, "rowcount", 0) == 0:
                    logger.warning(
                        (
                            "ERROR status update skipped "
                            "(not PENDING): wid=%s"
                        ),
                        withdrawal_id,
                    )
                await AdminLogger.write(
                    db,
                    admin_id=admin.id,
                    action="WITHDRAWAL_ERROR",
                    entity="withdraw_request",
                    entity_id=withdrawal_id,
                    details=err_text,
                )
                msg = (
                    "Не удалось выполнить холд по заявке: "
                    f"{err_text}"
                )
                raise ValueError(msg) from e

        # Помечаем заявку как PAID.
        r_paid: Result = await db.execute(
            text(
                f"""
                UPDATE {SCHEMA_CORE}.withdraw_requests
                   SET status = 'PAID',
                       processing_idempotency_key = :ik,
                       tx_hash = COALESCE(:txh, tx_hash),
                       error_message = NULL,
                       processed_at = NOW() AT TIME ZONE 'UTC'
                 WHERE id = :wid
                   AND status = 'PENDING'
                """
            ),
            {
                "ik": req.idempotency_key,
                "txh": req.tx_hash,
                "wid": withdrawal_id,
            },
        )
        if int(r_paid.rowcount or 0) == 0:
            await AdminLogger.write(
                db,
                admin_id=admin.id,
                action="WITHDRAWAL_PAID_FORBIDDEN",
                entity="withdrawal",
                entity_id=withdrawal_id,
                details="transition forbidden",
            )
            raise ValueError("Переход запрещён")

        amount_s = format_decimal_str(amount, EFHC_DECIMALS)
        details = (
            f"tg_id={tg_id}; amount={amount_s}; "
            f"tx_hash={req.tx_hash or ''}"
        )
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="WITHDRAWAL_PAID",
            entity="withdrawal",
            entity_id=withdrawal_id,
            details=details,
        )

        message = (
            f"Выплачен вывод # {withdrawal_id} пользователю {tg_id} "
            f"на сумму {amount_s} EFHC"
        )
        payload = {
            "withdrawal_id": withdrawal_id,
            "tg_id": tg_id,
            "amount": amount_s,
            "tx_hash": req.tx_hash or "",
        }
        payload_json = json.dumps(payload, ensure_ascii=False)
        await AdminNotifier.notify_generic(
            db,
            event="WITHDRAWAL_PAID",
            message=message,
            payload_json=payload_json,
        )

        return {
            "ok": True,
            "status": WithdrawalStatus.PAID,
            "idempotency_key": req.idempotency_key,
            "tx_hash": req.tx_hash,
        }

    @staticmethod
    async def reject_withdrawal(
        db: AsyncSession,
        *,
        withdrawal_id: int,
        reason: str,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Отклоняет заявку на вывод EFHC (без движения средств).

        Логика:
          • Ожидается, что списание ещё не производилось (заявка в
            статусе PENDING или ERROR).
          • Статус → REJECTED, error_message содержит причину.
          • Если по каналу ранее было списание (нестандартный сценарий),
            откат выполняется через отдельный механизм Банка (rollback),
            а не здесь — чтобы не создать скрытого P2P.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        r_rej: Result = await db.execute(
            text(
                f"""
                UPDATE {SCHEMA_CORE}.withdraw_requests
                   SET status = 'REJECTED',
                       error_message = :reason,
                       processed_at = NOW() AT TIME ZONE 'UTC'
                 WHERE id = :wid
                   AND status = 'PENDING'
                RETURNING
                   tg_id,
                   amount,
                   idempotency_key,
                   hold_done,
                   refund_done
                """
            ),
            {
                "reason": reason[:500],
                "wid": withdrawal_id,
            },
        )
        row = r_rej.fetchone()
        if not row:
            await AdminLogger.write(
                db,
                admin_id=admin.id,
                action="WITHDRAWAL_REJECT_FORBIDDEN",
                entity="withdrawal",
                entity_id=withdrawal_id,
                details="transition forbidden",
            )
            raise ValueError("Переход запрещён")

        if bool(row.hold_done) and not bool(row.refund_done):
            await credit_user_from_bank(
                db,
                tg_id=int(row.tg_id),
                amount=d8(row.amount),
                reason="withdraw_refund",
                idempotency_key=f"{str(row.idempotency_key)}:refund",
            )
            await db.execute(
                text(
                    f"""
                    UPDATE {SCHEMA_CORE}.withdraw_requests
                       SET refund_done = TRUE,
                           updated_at = NOW() AT TIME ZONE 'UTC'
                     WHERE id = :wid
                    """
                ),
                {"wid": withdrawal_id},
            )

        await AdminLogger.write(db,
            admin_id=admin.id,
            action="WITHDRAWAL_REJECT",
            entity="withdrawal",
            entity_id=withdrawal_id,
            details=reason,)

        await AdminNotifier.notify_generic(db,
            event="WITHDRAWAL_REJECT",
            message=f"Отклонён вывод  # {withdrawal_id}: {reason}",)

        return {"ok": True, "status": WithdrawalStatus.REJECTED}

    # --------------------------------------------------------------
    # БЛОК 3. Бонусные выплаты EFHC (bonus_awards → бонусный баланс)
    # --------------------------------------------------------------

    @staticmethod
    async def list_bonus_awards(db: AsyncSession,
        filters: BonusAwardFilters,) -> List[BonusAwardRecord]:
        """
        Возвращает список bonus_awards (только бонусные EFHC).

        Можно фильтровать по:
          • tg_id, status, source;
          • vip_only — только пользователи - випы.
        """
        where = ["1=1"]
        params: Dict[str, Any] = {
            "limit": filters.limit,
            "offset": filters.offset,
        }
        if filters.tg_id is not None:
            where.append("b.tg_id = :tg_id")
            params["tg_id"] = filters.tg_id
        if filters.status is not None:
            where.append("b.status = :st")
            params["st"] = filters.status
        if filters.source is not None:
            where.append("b.source = :src")
            params["src"] = filters.source
        if filters.vip_only:
            where.append("u.is_vip = TRUE")

        order = "DESC" if filters.sort_desc else "ASC"

        sql = text(f"""
            SELECT
                b.id,
                b.tg_id,
                b.amount,
                b.status,
                b.source,
                b.created_at,
                b.processed_at,
                b.meta_json,
                COALESCE(u.is_vip, FALSE) AS is_vip
            FROM {SCHEMA_ADMIN}.bonus_awards b
            JOIN {SCHEMA_CORE}.users u ON u.id = b.tg_id
            WHERE {" AND ".join(where)}
            ORDER BY b.id {order}
            LIMIT :limit OFFSET :offset
            """)
        r: Result = await db.execute(sql, params)
        out: List[BonusAwardRecord] = []
        for row in r.fetchall():
            created = row.created_at
            processed = getattr(row, "processed_at", None)
            created_s = (
                created.isoformat()
                if hasattr(created, "isoformat")
                else str(created)
            )
            processed_s = (
                processed.isoformat()
                if processed and hasattr(processed, "isoformat")
                else None
            )
            meta_raw = getattr(row, "meta_json", None)
            meta_json = str(meta_raw) if meta_raw is not None else None
            out.append(
                BonusAwardRecord(
                    id=int(row.id),
                    tg_id=int(row.tg_id),
                    amount_efhc=str(row.amount),
                    status=str(row.status),
                    source=str(row.source),
                    created_at=created_s,
                    processed_at=processed_s,
                    meta_json=meta_json,
                    is_vip=bool(row.is_vip),
                )
            )
        return out

    @staticmethod
    async def process_bonus_award(
        db: AsyncSession,
        *,
        award_id: int,
        req: BonusAwardProcessRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Выплачивает бонус EFHC по записи bonus_awards.

          • Требует статус PENDING или ERROR.
          • Использует credit_user_bonus_from_bank(...).
          • Обновляет статус bonus_awards на PAID и сохраняет ключ.
          • Идемпотентен по полю processing_idempotency_key.

        RBAC:
          • Минимум MODERATOR.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        if not req.idempotency_key.strip():
            raise ValueError("idempotency_key обязателен")

        # Читаем запись
        r: Result = await db.execute(text(f"""
                SELECT
                    id,
                    tg_id,
                    amount,
                    status,
                    processing_idempotency_key,
                    source
                FROM {SCHEMA_ADMIN}.bonus_awards
                WHERE id = :aid
                FOR UPDATE
                """),
            {"aid": award_id},)
        row = r.fetchone()
        if not row:
            raise ValueError("Бонусная запись не найдена")

        final_statuses = (
            BonusAwardStatus.PAID,
            BonusAwardStatus.REJECTED,
        )
        if row.status in final_statuses:
            return {
                "ok": False,
                "status": str(row.status),
                "detail": "Бонус уже обработан",
            }

        # Идемпотентность
        if row.processing_idempotency_key:
            processing_ik = str(row.processing_idempotency_key)
            if processing_ik == req.idempotency_key:
                logger.info(
                    "process_bonus_award: idem=%s aid=%s",
                    req.idempotency_key,
                    award_id,
                )
                return {
                    "ok": True,
                    "status": str(row.status),
                    "idempotency_key": req.idempotency_key,
                }
            else:
                raise ValueError(
                    "Бонус уже обрабатывается с другим ключом"
                )

        tg_id = int(row.tg_id)
        amount = d8(row.amount)
        src = str(row.source)

        meta = {
            "admin_id": admin.id,
            "admin_role": admin.role,
            "award_id": award_id,
            "source": src,
        }

        try:
            await credit_user_bonus_from_bank(
                db,
                tg_id=tg_id,
                amount=amount,
                reason=f"bonus_award:{src}",
                idempotency_key=req.idempotency_key,
                meta=meta,
            )
        except Exception as e:
            err_text = f"{type(e).__name__}: {e}"
            logger.warning(
                "process_bonus_award: credit failed aid=%s tg=%s: %s",
                award_id,
                tg_id,
                err_text,
            )
            res = await db.execute(text(f"""
                    UPDATE {SCHEMA_ADMIN}.bonus_awards
                    SET status = 'ERROR',
                        processing_idempotency_key=:ik,
                        processed_at = NOW() AT TIME ZONE 'UTC'
                    WHERE id = :aid
                      AND status = 'PENDING'
                    """),
                {"ik": req.idempotency_key, "aid": award_id},)
            if getattr(res, "rowcount", 0) == 0:
                logger.warning(
                    (
                        "BONUS_AWARD ERROR update skipped "
                        "(not PENDING): aid=%s"
                    ),
                    award_id,
                )
            await AdminLogger.write(
                db,
                admin_id=admin.id,
                action="BONUS_AWARD_ERROR",
                entity="bonus_awards",
                entity_id=award_id,
                details=err_text,
            )
            msg = f"Не удалось начислить бонус EFHC: {err_text}"
            raise ValueError(msg) from e

        res = await db.execute(text(f"""
                UPDATE {SCHEMA_ADMIN}.bonus_awards
                SET status = 'PAID',
                    processing_idempotency_key=:ik,
                    processed_at = NOW() AT TIME ZONE 'UTC'
                WHERE id = :aid
                  AND status = 'PENDING'
                """),
            {"ik": req.idempotency_key, "aid": award_id},)
        if getattr(res, "rowcount", 0) == 0:
            logger.warning(
                (
                    "BONUS_AWARD PAID update skipped "
                    "(not PENDING): aid=%s"
                ),
                award_id,
            )

        amount_s = format_decimal_str(amount, EFHC_DECIMALS)
        details = f"tg_id={tg_id}; amount={amount_s}"
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="BONUS_AWARD_PAID",
            entity="bonus_awards",
            entity_id=award_id,
            details=details,
        )

        message = (
            f"Выплачен бонус {amount_s} EFHC пользователю {tg_id} "
            "(bonus)"
        )
        payload = {
            "award_id": award_id,
            "tg_id": tg_id,
            "amount": amount_s,
            "source": src,
            "admin_id": admin.id,
        }
        payload_json = json.dumps(payload, ensure_ascii=False)
        await AdminNotifier.notify_generic(
            db,
            event="BONUS_AWARD_PAID",
            message=message,
            payload_json=payload_json,
        )

        return {
            "ok": True,
            "status": BonusAwardStatus.PAID,
            "idempotency_key": req.idempotency_key,
        }

    @staticmethod
    async def reject_bonus_award(db: AsyncSession,
        *,
        award_id: int,
        reason: str,
        admin: AdminUser,) -> Dict[str, Any]:
        """
        Отклоняет бонусную выплату (без движения средств).

        Используется, если запись bonus_awards создана ошибочно или
        больше не актуальна.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        r: Result = await db.execute(text(f"""
                SELECT id, status
                FROM {SCHEMA_ADMIN}.bonus_awards
                WHERE id = :aid
                LIMIT 1
                """),
            {"aid": award_id},)
        row = r.fetchone()
        if not row:
            raise ValueError("Бонусная запись не найдена")

        final_statuses = (
            BonusAwardStatus.PAID,
            BonusAwardStatus.REJECTED,
        )
        if row.status in final_statuses:
            return {
                "ok": False,
                "status": str(row.status),
                "detail": "Бонус уже обработан",
            }

        res = await db.execute(text(f"""
                UPDATE {SCHEMA_ADMIN}.bonus_awards
                SET status = 'REJECTED',
                    processed_at = NOW() AT TIME ZONE 'UTC'
                WHERE id = :aid
                  AND status = 'PENDING'
                """),
            {"aid": award_id},)
        if getattr(res, "rowcount", 0) == 0:
            logger.warning(
                (
                    "BONUS_AWARD REJECTED update skipped "
                    "(not PENDING): aid=%s"
                ),
                award_id,
            )

        await AdminLogger.write(db,
            admin_id=admin.id,
            action="BONUS_AWARD_REJECT",
            entity="bonus_awards",
            entity_id=award_id,
            details=reason,)

        await AdminNotifier.notify_generic(db,
            event="BONUS_AWARD_REJECT",
            message=f"Отклонён бонус  # {award_id}: {reason}",)

        return {"ok": True, "status": BonusAwardStatus.REJECTED}

    # --------------------------------------------------------------
    # БЛОК 4. Заявки на призы (NFT и пр.) — prize_claims
    # --------------------------------------------------------------

    @staticmethod
    async def list_prize_claims(
        db: AsyncSession,
        filters: PrizeClaimFilters,
    ) -> List[PrizeClaimRecord]:
        """
        Возвращает список заявок на призы (NFT/прочее) из prize_claims.

        Особенности:
          • vip_only = True — фильтрация по is_vip.
          • prize_type — можно ограничить, например, 'NFT_VIP'.
        """
        where = ["1=1"]
        params: Dict[str, Any] = {
            "limit": filters.limit,
            "offset": filters.offset,
        }
        if filters.tg_id is not None:
            where.append("p.tg_id = :tg_id")
            params["tg_id"] = filters.tg_id
        if filters.status is not None:
            where.append("p.status = :st")
            params["st"] = filters.status
        if filters.prize_type is not None:
            where.append("p.prize_type = :ptype")
            params["ptype"] = filters.prize_type
        if filters.vip_only:
            where.append("u.is_vip = TRUE")

        order = "DESC" if filters.sort_desc else "ASC"

        sql = text(f"""
            SELECT
                p.id,
                p.lotteries_id,
                p.tg_id,
                p.prize_type,
                p.prize_value,
                p.wallet_address,
                p.status,
                p.created_at,
                p.processed_at,
                p.reject_reason,
                p.tx_hash,
                COALESCE(u.is_vip, FALSE) AS is_vip
            FROM {SCHEMA_ADMIN}.prize_claims p
            JOIN {SCHEMA_CORE}.users u ON u.id = p.tg_id
            WHERE {" AND ".join(where)}
            ORDER BY p.id {order}
            LIMIT :limit OFFSET :offset
            """)
        r: Result = await db.execute(sql, params)
        out: List[PrizeClaimRecord] = []
        for row in r.fetchall():
            lotteries_id = (
                int(row.lotteries_id)
                if row.lotteries_id is not None
                else None
            )
            created = row.created_at
            processed = getattr(row, "processed_at", None)
            created_s = (
                created.isoformat()
                if hasattr(created, "isoformat")
                else str(created)
            )
            processed_s = (
                processed.isoformat()
                if processed and hasattr(processed, "isoformat")
                else None
            )
            out.append(
                PrizeClaimRecord(
                    id=int(row.id),
                    lotteries_id=lotteries_id,
                    tg_id=int(row.tg_id),
                    prize_type=str(row.prize_type),
                    prize_value=str(row.prize_value),
                    wallet_address=row.wallet_address,
                    status=str(row.status),
                    created_at=created_s,
                    processed_at=processed_s,
                    reject_reason=row.reject_reason,
                    tx_hash=row.tx_hash,
                    is_vip=bool(row.is_vip),
                )
            )
        return out

    @staticmethod
    async def mark_prize_claim_done(
        db: AsyncSession,
        *,
        claim_id: int,
        req: PrizeClaimProcessRequest,
        admin: AdminUser,
    ) -> None:
        """Помечает заявку на приз как DONE и сохраняет tx_hash."""
        RBAC.require_role(admin, AdminRole.MODERATOR)

        r: Result = await db.execute(text(f"""
                SELECT id, status
                FROM {SCHEMA_ADMIN}.prize_claims
                WHERE id = :cid
                LIMIT 1
                """),
            {"cid": claim_id},)
        row = r.fetchone()
        if not row:
            raise ValueError("Заявка на приз не найдена")

        final_statuses = (
            PrizeClaimStatus.DONE,
            PrizeClaimStatus.REJECTED,
        )
        if row.status in final_statuses:
            return

        await db.execute(text(f"""
                UPDATE {SCHEMA_ADMIN}.prize_claims
                SET status = 'DONE',
                    processed_at = NOW() AT TIME ZONE 'UTC',
                    tx_hash = COALESCE(:txh, tx_hash)
                WHERE id = :cid
                """),
            {"cid": claim_id, "txh": req.tx_hash},)

        await AdminLogger.write(db,
            admin_id=admin.id,
            action="PRIZE_DONE",
            entity="prize_claim",
            entity_id=claim_id,
            details=req.tx_hash or "",)

    @staticmethod
    async def reject_prize_claim(
        db: AsyncSession,
        *,
        claim_id: int,
        req: PrizeClaimRejectRequest,
        admin: AdminUser,
    ) -> None:
        """
        Отклоняет заявку на приз.

        Пример: кошелёк неверен или данных недостаточно.

        Важно:
          • Денежных списаний/начислений здесь нет.
          • Возврат EFHC за покупку — отдельная операция банка.
            Не выполняется здесь.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        await db.execute(text(f"""
                UPDATE {SCHEMA_ADMIN}.prize_claims
                SET status = 'REJECTED',
                    processed_at = NOW() AT TIME ZONE 'UTC',
                    reject_reason=:reason
                WHERE id = :cid
                """),
            {"cid": claim_id, "reason": req.reason[: 500]},)

        await AdminLogger.write(db,
            admin_id=admin.id,
            action="PRIZE_REJECT",
            entity="prize_claim",
            entity_id=claim_id,
            details=req.reason,)


__all__ = [
    "WithdrawalStatus",
    "BonusAwardStatus",
    "PrizeClaimStatus",
    "WithdrawalFilters",
    "BonusAwardFilters",
    "PrizeClaimFilters",
    "WithdrawalRecord",
    "BonusAwardRecord",
    "PrizeClaimRecord",
    "WithdrawalApproveRequest",
    "BonusAwardProcessRequest",
    "PrizeClaimProcessRequest",
    "PrizeClaimRejectRequest",
    "WithdrawalsService",
]

