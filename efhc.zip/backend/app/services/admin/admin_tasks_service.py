# -*- coding: utf-8 -*-
"""Admin tasks helpers.

Thin wrapper over tasks_service for admin-triggered sync.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession


async def force_tasks_sync(db: AsyncSession) -> None:
    """Force tasks sync. Safe no-op if service is unavailable."""
    try:
        import backend.app.services.tasks_service as _tasks
    except Exception:
        return
    await _tasks.sync_tasks_for_all(db)
