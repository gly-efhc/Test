"""Admin tasks helpers.

Thin wrapper for admin-triggered maintenance of tasks contour.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession


async def force_tasks_sync(db: AsyncSession) -> dict[str, Any]:
    """Run safe maintenance for tasks contour.

    In the current MVP this is not a money operation. It is limited
    to maintenance of task locks via the scheduler task. If the
    maintenance layer is unavailable, return a safe no-op payload
    instead of crashing the admin UI.
    """
    try:
        from app.scheduler.tasks_autorestart import run_once
    except Exception:
        return {
            "ok": False,
            "detail": "tasks maintenance unavailable",
        }

    result = await run_once()
    deleted = int(result.get("deleted", 0) or 0)
    if result.get("ok"):
        return {
            "ok": True,
            "detail": (
                f"Task maintenance completed; cleared locks: {deleted}"
            ),
            "deleted": deleted,
        }
    return {
        "ok": False,
        "detail": result.get("error") or "tasks maintenance failed",
        "deleted": deleted,
    }
