"""Административное представление рекламных провайдеров.

Страница не раскрывает секреты и не позволяет записывать ENV из браузера.
Она показывает реальный provider registry и готовность конфигурации.
"""

from __future__ import annotations

from typing import Any

from app.core.config_core import get_settings
from app.integrations.ads_providers import ENABLED

settings = get_settings()


async def list_providers() -> list[dict[str, Any]]:
    """Вернуть реальные рекламные провайдеры и безопасный статус настройки."""
    adsgram_secret = bool(
        str(getattr(settings, "ADSGRAM_SECRET", "") or "").strip()
    )
    adsgram_placement = bool(
        str(getattr(settings, "ADSGRAM_PLACEMENT_ID", "") or "").strip()
    )
    builtin_secret = bool(
        str(
            getattr(settings, "ADS_BUILTIN_SECRET", "")
            or getattr(settings, "SECRET_KEY", "")
            or ""
        ).strip()
    )

    return [
        {
            "code": "builtin_timer",
            "title": "Встроенный таймер",
            "is_active": "builtin_timer" in ENABLED,
            "is_configured": builtin_secret,
            "integration_mode": "signed_timer",
            "required_env": ["ADS_BUILTIN_SECRET"],
            "note": (
                "Встроенный рекламный просмотр с подписанным токеном; "
                "SECRET_KEY используется только как ограниченный fallback."
            ),
        },
        {
            "code": "adsgram",
            "title": "Adsgram",
            "is_active": "adsgram" in ENABLED,
            "is_configured": adsgram_secret and adsgram_placement,
            "integration_mode": "external_provider",
            "required_env": [
                "ADSGRAM_SECRET",
                "ADSGRAM_PLACEMENT_ID",
            ],
            "note": (
                "Внешний provider: секрет и placement задаются на сервере; "
                "Admin UI показывает только готовность, но не значения."
            ),
        },
    ]
