"""Admin ads helpers.

Thin admin wrapper for available ads providers.
"""

from __future__ import annotations

from typing import Any


async def list_providers() -> list[dict[str, Any]]:
    """Return available ads providers for admin UI."""
    # MVP: static list. In future it can be loaded from DB.
    return [
        {
            "code": "default",
            "title": "Default provider",
            "is_active": True,
        },
    ]
