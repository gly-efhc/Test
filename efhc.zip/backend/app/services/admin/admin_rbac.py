# -*- coding: utf-8 -*-
# backend/app/services/admin/admin_rbac.py
# ======================================================================
# EFHC Bot — RBAC для админ-панели
# ======================================================================

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
S = get_settings()

SCHEMA_ADMIN: str = (
    S.DB_SCHEMA_ADMIN or "efhc_admin"
)

ROOT_ADMIN_TG_ID: int = int(
    getattr(S, "ROOT_ADMIN_TG_ID", 0) or 0
)


class AdminRole(str):
    """Роли администраторов (белый список)."""

    SUPERADMIN = "SuperAdmin"
    MODERATOR = "Moderator"
    ANALYST = "Analyst"


_ROLE_LEVEL: dict[str, int] = {
    AdminRole.ANALYST: 1,
    AdminRole.MODERATOR: 2,
    AdminRole.SUPERADMIN: 3,
}


class AdminAuthError(PermissionError):
    """Ошибка авторизации/прав администратора."""


class AdminUser(BaseModel):
    """Администратор для бизнес-логики."""

    id: int = Field(...)
    tg_id: int = Field(...)
    role: str
    is_active: bool = Field(default=True)


class RBAC:
    """Проверка прав администраторов и разрешение admin-пользователя."""

    @staticmethod
    def _normalize_role(role_raw: str) -> str:
        role = (role_raw or "").strip()
        if role not in _ROLE_LEVEL:
            raise AdminAuthError(
                f"Неизвестная роль администратора: {role!r}"
            )
        return role

    @staticmethod
    def _level(role: str) -> int:
        return _ROLE_LEVEL.get(role, 0)

    @staticmethod
    async def resolve_admin(
        db: AsyncSession,
        tg_id: int,
    ) -> AdminUser:
        if tg_id <= 0:
            raise AdminAuthError("Некорректный tg_id администратора")

        if ROOT_ADMIN_TG_ID and tg_id == ROOT_ADMIN_TG_ID:
            try:
                admin = await RBAC._fetch_admin_from_db(db, tg_id)
                if admin is not None:
                    if admin.role != AdminRole.SUPERADMIN:
                        logger.warning(
                            "ROOT_ADMIN tg_id=%s role=%s; "
                            "elevate to SuperAdmin",
                            tg_id,
                            admin.role,
                        )
                        admin.role = AdminRole.SUPERADMIN
                    return admin
            except Exception as e:
                logger.error(
                    "RBAC: DB error for ROOT admin tg_id=%s: %s",
                    tg_id,
                    e,
                )

            logger.warning(
                "RBAC: virtual ROOT SuperAdmin for tg_id=%s",
                tg_id,
            )
            return AdminUser(
                id=-1,
                tg_id=tg_id,
                role=AdminRole.SUPERADMIN,
                is_active=True,
            )

        admin = await RBAC._fetch_admin_from_db(db, tg_id)
        if admin is None:
            raise AdminAuthError("Администратор не найден или отключён")
        return admin

    @staticmethod
    async def _fetch_admin_from_db(
        db: AsyncSession,
        tg_id: int,
    ) -> Optional[AdminUser]:
        sql = text(
            "\n".join(
                [
                    "SELECT id, tg_id, role,",
                    "COALESCE(is_active, TRUE) AS is_active",
                    f"FROM {SCHEMA_ADMIN}.admin_users",
                    "WHERE tg_id = :tid",
                    "LIMIT 1",
                ]
            )
        )

        try:
            r: Result = await db.execute(sql, {"tid": tg_id})
            row = r.fetchone()
        except Exception as e:
            logger.error(
                "RBAC: DB error while resolving tg_id=%s: %s",
                tg_id,
                e,
            )
            raise

        if not row:
            return None

        try:
            role = RBAC._normalize_role(str(row.role))
        except AdminAuthError as e:
            logger.error(
                "RBAC: invalid role for tg_id=%s: %r",
                tg_id,
                getattr(row, "role", None),
            )
            raise e

        is_active = bool(getattr(row, "is_active", True))
        if not is_active:
            logger.info(
                "RBAC: admin disabled tg_id=%s",
                tg_id,
            )
            return None

        return AdminUser(
            id=int(row.id),
            tg_id=int(row.tg_id),
            role=role,
            is_active=is_active,
        )

    @staticmethod
    async def try_resolve_admin(
        db: AsyncSession,
        tg_id: int,
    ) -> Optional[AdminUser]:
        try:
            return await RBAC.resolve_admin(db, tg_id)
        except AdminAuthError as e:
            logger.info(
                "RBAC.try_resolve_admin: denied: %s",
                e,
            )
            return None

    @staticmethod
    def require_role(admin: AdminUser, minimal: str) -> None:
        minimal_norm = RBAC._normalize_role(minimal)
        admin_level = RBAC._level(admin.role)
        need_level = RBAC._level(minimal_norm)
        if admin_level < need_level:
            raise AdminAuthError(
                f"Недостаточно прав: нужен >= {minimal_norm}, "
                f"у администратора {admin.role}"
            )

    @staticmethod
    def is_superadmin(admin: AdminUser) -> bool:
        return admin.role == AdminRole.SUPERADMIN


__all__ = ["AdminRole", "AdminUser", "AdminAuthError", "RBAC"]
