"""Admin shop helpers.

Thin wrapper over shop_service.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import app.services.shop_service as _shop
from app.services.user_service import get_user_by_tg_id
from sqlalchemy.ext.asyncio import AsyncSession


async def admin_list_orders(
    db: AsyncSession,
    *,
    limit: int = 50,
    cursor: str | None = None,
    status: str | None = None,
    item_type: str | None = None,
    tg_id: int | None = None,
) -> dict[str, Any]:
    if tg_id is not None:
        await get_user_by_tg_id(db, int(tg_id))
    return await _shop.admin_list_orders(
        db,
        limit=int(limit),
        cursor=cursor,
        status=status,
        item_type=item_type,
        tg_id=tg_id,
    )


async def admin_set_price(
    db: AsyncSession,
    *,
    code: str,
    price_efhc: Decimal | None = None,
    price_ton: Decimal | None = None,
    price_usdt: Decimal | None = None,
    pay_currencies: list[str] | None = None,
    is_active: bool | None = None,
) -> dict[str, Any]:
    return await _shop.admin_set_price(
        db,
        code=code,
        price_efhc=price_efhc,
        price_ton=price_ton,
        price_usdt=price_usdt,
        pay_currencies=pay_currencies,
        is_active=is_active,
    )
