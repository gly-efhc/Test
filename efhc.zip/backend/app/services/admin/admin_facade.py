# -*- coding: utf-8 -*-
# backend/app/services/admin/admin_facade.py
# ======================================================================
# EFHC Bot — AdminService (фасад админ-подсистемы)
# ----------------------------------------------------------------------
# Назначение:
# • Дать ЕДИНЫЙ высокий уровень API для админ-роутов и фоновых воркеров.
# • Инкапсулировать всю внутреннюю модульную структуру admin-модуля.
# • Дополнительно защищать канон проекта на уровне публичного
# интерфейса:
# - НЕТ P2P переводов «пользователь ↔ пользователь»;
# - ВСЕ бонусы → только бонусный баланс;
# - ВСЕ денежные операции идемпотентны (idempotency_key на нижнем
# уровне);
# - ВСЕ транзакции только «Банк ↔ Пользователь».
#
# ВНИМАНИЕ (жёсткий канон):
# 1) Начальный баланс банка: 5 000 000 EFHC. Любые корректировки только
# через банк-сервис (минт/бёрн/ручные транзакции «банк ↔ пользователь»).
# 2) Внутренние переводы между пользователями (user → user) ЗАПРЕЩЕНЫ.
# В этом фасаде нет и не будет методов, которые позволяли бы делать P2P.
# 3) Все бонусные начисления (реферальные, задания, лотереи и др.) идут
# только
# на бонусный счет. Фасад не даёт доступ к «бонус→regular» конверсиям.
# 4) Все операции, двигающие EFHC (включая ручные действия админа),
# обязаны
# использовать идемпотентные сервисы нижнего уровня с явным ключом.
#
# Как использовать:
# from app.services.admin.admin_facade import AdminService
#
# admin = await AdminService.resolve_admin(db, tg_id)
# stats = await AdminService.get_system_stats(db)
# lotteries = await AdminService.list_lotteries(db, pg)
# ======================================================================

from __future__ import annotations

from decimal import Decimal
from typing import Any, Dict, List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

# RBAC / логи / настройки / нотификации
from app.services.admin.admin_rbac import (
    AdminAuthError,
    AdminRole,
    AdminUser,
    RBAC,
)
from app.services.admin.admin_logging import (
    AdminLog,
    AdminLogger,
    Pagination,
)
from app.services.admin.admin_settings import (
    ALLOWED_SETTINGS,
    SettingsService,
    SystemSetting,
)
from app.services.admin.admin_notifications import (
    AdminNotification,
    AdminNotifier,
)

# Банк EFHC
from app.services.admin.admin_bank_service import (
    AdminBankService,
    BankBalanceDTO,
    ManualBankTransferRequest,
    MintBurnRequest,
)

# Лотереи / билеты / призы
from app.services.admin.admin_lotteries_service import (
    AdminLotteriesService,
    CreateLotteriesRequest,
    LotteriesInfo,
    LotteriestatusSummary,
    UpdateLotteriesRequest,
    WinnerTicket,
)

# Панели пользователей
from app.services.admin.admin_panels_service import (
    AdminPanelsService,
    PanelToggleRequest,
)

# Реферальные бонусы
from app.services.admin.admin_referral_service import (
    AdminReferralService,
)

# Кошельки пользователей
from app.services.admin.admin_wallets_service import (
    AdminWalletsService,
)

# Статистика
from app.services.admin.admin_stats_service import (
    AdminStatsService,
    CoinsStats,
    PanelsStats,
    ReferralsStats,
    ShopStats,
    SystemStats,
)

# Пользователи / прогресс / отладка
from app.services.admin.admin_users_service import (
    AdminUsersService,
    UserProgressSnapshot,
)

# Вывод EFHC / призовые заявки / бонус-на-вывод
from app.services.admin.admin_withdrawals_service import (
    WithdrawalsService,
    WithdrawalApproveRequest,
    WithdrawalFilters,
    BonusAwardFilters,
    PrizeClaimFilters,
    WithdrawalRecord,
    BonusAwardRecord,
    PrizeClaimRecord,
)

class AdminService:
    """
    Высокоуровневый фасад над всеми админ-подсистемами.

    ВАЖНО:
      • Здесь НЕТ бизнес-логики по деньгам — только делегация.
      • Канон безопасности обеспечивается тем, ЧТО именно мы
      экспортируем:
          - нет методов P2P-переводов;
          - нет методов «прямого» изменения user.balance в обход банка;
          - нет обратных обменов EFHC↔kWh.
    """

    # ------------------------------------------------------------------
    # --- #
    # 0. RBAC / Аутентификация админа
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def resolve_admin(db: AsyncSession, tg_id: int) -> AdminUser:
        """
        Возвращает AdminUser по tg_id или бросает AdminAuthError.

        Используется роутами для авторизации входа в админ-панель.
        """
        return await RBAC.resolve_admin(db, tg_id = tg_id)

    @staticmethod

    def require_role(admin: AdminUser, minimal: str) -> None:
        """
        Проверка, что роль admin «не ниже», чем требуемая minimal.
        """
        RBAC.require_role(admin, minimal)

    # ------------------------------------------------------------------
    # --- #
    # 1. ЛОГИ АДМИНОВ
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def list_admin_logs(db: AsyncSession,
        pg: Pagination,
        admin_id: Optional[int] = None,
        action: Optional[str] = None,
        entity: Optional[str] = None,) -> List[AdminLog]:
        """
        Возвращает список логов действий админов (для аудита).
        """
        return await AdminLogger.list(
            db,
            pg=pg,
            admin_id=admin_id,
            action=action,
            entity=entity,
        )

    # ------------------------------------------------------------------
    # --- #
    # 2. СИСТЕМНЫЕ НАСТРОЙКИ АДМИНКИ (+ ежедневные снапшоты / откат)
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def get_setting(
        db: AsyncSession,
        key: str,
    ) -> Optional[SystemSetting]:
        """Прочитать одну настройку (или None, если не существует)."""
        return await SettingsService.get(db, key)

    @staticmethod
    async def mget_settings(
        db: AsyncSession,
        keys: List[str],
    ) -> List[SystemSetting]:
        """Пакетное чтение нескольких настроек."""
        return await SettingsService.mget(db, keys)

    @staticmethod
    async def set_setting(
        db: AsyncSession,
        key: str,
        value: str,
        admin: AdminUser,
    ) -> None:
        """
        Установить/обновить одну настройку.

        ИИ-страховка:
          • key проверяется на принадлежность ALLOWED_SETTINGS.
          • Значения проходят валидацию (числа/пороги/строки).
        """
        return await SettingsService.set(
            db,
            key,
            value,
            admin_id=admin.id,
        )

    @staticmethod
    async def mset_settings(
        db: AsyncSession,
        items: Dict[str, str],
        admin: AdminUser,
    ) -> None:
        """
        Пакетное обновление настроек (каждая — через set_setting).
        """
        return await SettingsService.mset(
            db,
            items,
            admin_id=admin.id,
        )

    @staticmethod
    async def snapshot_settings_daily(db: AsyncSession) -> None:
        """
        Сохранение слепка настроек (для отката). Вызывается
        планировщиком раз в сутки.
        """
        await SettingsService.snapshot_all(db)

    @staticmethod
    async def restore_settings_from_snapshot(
        db: AsyncSession,
        snapshot_id: int,
        admin: AdminUser,
    ) -> None:
        """
        Откат настроек к выбранному снапшоту (ИИ-защита от ошибочных
        изменений).
        """
        RBAC.require_role(admin, AdminRole.SUPERADMIN)
        await SettingsService.restore_from_snapshot(
            db,
            snapshot_id=snapshot_id,
            admin_id=admin.id,
        )

    # ------------------------------------------------------------------
    # --- #
    # 3. БАНК EFHC: минт/бёрн/ручные транзакции Банк↔Пользователь
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def get_bank_balance(db: AsyncSession) -> BankBalanceDTO:
        """
        Возвращает агрегированный баланс банка EFHC (для дашборда).
        """
        return await AdminBankService.get_bank_balance(db)

    @staticmethod
    async def mint_efhc(
        db: AsyncSession,
        req: MintBurnRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Минт EFHC в банк. НЕ начисляет пользователям напрямую.
        """
        return await AdminBankService.mint_efhc(
            db,
            req=req,
            admin=admin,
        )

    @staticmethod
    async def burn_efhc(
        db: AsyncSession,
        req: MintBurnRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Сжигание EFHC из банка (требуется достаточный остаток).
        """
        return await AdminBankService.burn_efhc(
            db,
            req=req,
            admin=admin,
        )


    @staticmethod
    async def manual_bank_user_transfer(
        db: AsyncSession,
        req: ManualBankTransferRequest,
        admin: AdminUser,
    ) -> Dict[str, Any]:
        """
        Ручная операция Банк↔Пользователь.

        req.direction = credit|debit
          - credit: user credit ⇒ bank debit
          - debit:  user debit  ⇒ bank credit
        """
        return await AdminBankService.manual_bank_user_transfer(
            db,
            req=req,
            admin=admin,
        )

    # ------------------------------------------------------------------
    # --- #
    # 4. ЛОТЕРЕИ / БИЛЕТЫ / ПРИЗЫ
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def create_lotteries(
        db: AsyncSession,
        req: CreateLotteriesRequest,
        admin: AdminUser,
    ) -> int:
        """
        Создание лотереи (универсальный конструктор).

        Параметры (через req) могут полностью менять:
          • цену билета,
          • лимиты участников/билетов,
          • тип/размер приза (бонус EFHC или NFT VIP).
        """
        return await AdminLotteriesService.create_lotteries(
            db,
            req=req,
            admin=admin,
        )

    @staticmethod
    async def update_lotteries(
        db: AsyncSession,
        lotteries_id: int,
        req: UpdateLotteriesRequest,
        admin: AdminUser,
    ) -> None:
        """
        Частичное обновление лотереи:
          • изменение стоимости билета, лимитов, статуса
          (ACTIVE/PAUSED/FINISHED).
        """
        return await AdminLotteriesService.update_lotteries(
            db,
            lotteries_id=lotteries_id,
            req=req,
            admin=admin,
        )

    @staticmethod
    async def list_lotteries(
        db: AsyncSession,
        pg: Pagination,
    ) -> List[LotteriesInfo]:
        """Список лотерей с краткой информацией для админ - панели."""
        return await AdminLotteriesService.list_lotteries(db, pg=pg)

    @staticmethod
    async def lotteries_lotteries(
        db: AsyncSession,
        lotteries_id: int,
        admin: AdminUser,
    ) -> Optional[WinnerTicket]:
        """
        Розыгрыш лотереи:
          • выбирается один победитель;
          • создаются идемпотентные заявки на приз (bonus_awards /
          prize_claims);
          • сама лотерея переводится в FINISHED.
        """
        return await AdminLotteriesService.lotteries_lotteries(
            db,
            lotteries_id=lotteries_id,
            admin=admin,
        )

    @staticmethod
    async def lotteries_status_summary(
        db: AsyncSession,
    ) -> LotteriestatusSummary:
        """
        Краткая сводка по лотереям (активные, на паузе, завершённые,
        автоперезапуск).
        """
        return await AdminLotteriesService.get_status_summary(db)

    @staticmethod
    async def fix_lotteries_tickets(db: AsyncSession,
        lotteries_id: int,
        *,
        tg_id: int,
        new_tickets_count: int,
        admin: AdminUser,) -> Dict[str, Any]:
        """
        Ручная корректировка количества билетов пользователя в лотерее.

        Используется, если из - за сбоев идемпотентности покупки билетов
        возник
        рассинхрон. Все коррекции логируются.
        """
        return await AdminLotteriesService.fix_user_tickets(db,
            lotteries_id=lotteries_id,
            tg_id=tg_id,
            new_tickets_count=new_tickets_count,
            admin=admin,)

    # ------------------------------------------------------------------
    # --- #
    # 5. ПАНЕЛИ ПОЛЬЗОВАТЕЛЕЙ
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def toggle_user_panel(db: AsyncSession,
        req: PanelToggleRequest,
        admin: AdminUser,) -> Dict[str, Any]:
        """
        Включение/выключение панелей пользователя (ручная
        корректировка).
        """
        return await AdminPanelsService.toggle_user_panel(
            db,
            req=req,
            admin=admin,
        )

    # ------------------------------------------------------------------
    # --- #
    # 6. РЕФЕРАЛЬНАЯ СИСТЕМА (ВСЕГДА БОНУСНЫЙ СЧЁТ)
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def award_referral_on_first_panel(db: AsyncSession,
        inviter_tg_id: int,
        invitee_id: int,) -> None:
        """
        0.1 EFHC бонусом за первую панель реферала (идемпотентно).
        """
        await AdminReferralService.award_referral_on_first_panel(
            db,
            inviter_tg_id=inviter_tg_id,
            invitee_id=invitee_id,
        )

    @staticmethod
    async def award_referral_thresholds(
        db: AsyncSession,
        inviter_tg_id: int,
    ) -> List[int]:
        """
        Проверяет и выплачивает пороговые награды за рефералов
        (10/100/1000/...),
        все выплаты — на бонусный счёт, строго идемпотентно по порогам.
        """
        return await AdminReferralService.award_referral_thresholds(
            db,
            inviter_tg_id=inviter_tg_id,
        )

    # ------------------------------------------------------------------
    # --- #
    # 7. КОШЕЛЬКИ ПОЛЬЗОВАТЕЛЕЙ
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def list_user_wallets(
        db: AsyncSession,
        tg_id: int,
    ) -> List[Dict[str, Any]]:
        """
        Возвращает список привязанных кошельков пользователя.

        Используется для:
          • выдачи NFT VIP,
          • проверок покупок,
          • проверок адресов при выводе.
        """
        return await AdminWalletsService.list_user_wallets(
            db,
            tg_id=tg_id,
        )

    @staticmethod
    async def bind_user_wallet(db: AsyncSession,
        tg_id: int,
        chain: str,
        address: str,
        *,
        set_primary: bool = True,
        admin: Optional[AdminUser] = None,) -> int:
        """
        Привязывает кошелек к пользователю, опционально делая его
        основным.
        """
        return await AdminWalletsService.bind_user_wallet(db,
            tg_id=tg_id,
            chain=chain,
            address=address,
            set_primary=set_primary,
            admin=admin,)

    # ------------------------------------------------------------------
    # --- #
    # 8. СТАТИСТИКА ДЛЯ ДАШБОРДА
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def get_coins_stats(db: AsyncSession) -> CoinsStats:
        """Метод класса AdminService.
        Асинхронная функция `get_coins_stats` выполняет операцию в
        контуре бота EFHC.
        Назначение: получить/прочитать данные и вернуть результат без
        побочных эффектов (кроме логирования).

        Параметры:
        - `db` (AsyncSession): входной параметр.

        Возвращает:
        - Значение типа/структуры: CoinsStats.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return await AdminStatsService.get_coins_stats(db)

    @staticmethod
    async def get_panels_stats(db: AsyncSession) -> PanelsStats:
        """Метод класса AdminService.
        Асинхронная функция `get_panels_stats` выполняет операцию в
        контуре бота EFHC.
        Назначение: получить/прочитать данные и вернуть результат без
        побочных эффектов (кроме логирования).

        Параметры:
        - `db` (AsyncSession): входной параметр.

        Возвращает:
        - Значение типа/структуры: PanelsStats.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return await AdminStatsService.get_panels_stats(db)

    @staticmethod
    async def get_referrals_stats(db: AsyncSession) -> ReferralsStats:
        """Метод класса AdminService.
        Асинхронная функция `get_referrals_stats` выполняет операцию в
        контуре бота EFHC.
        Назначение: получить/прочитать данные и вернуть результат без
        побочных эффектов (кроме логирования).

        Параметры:
        - `db` (AsyncSession): входной параметр.

        Возвращает:
        - Значение типа/структуры: ReferralsStats.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return await AdminStatsService.get_referrals_stats(db)

    @staticmethod
    async def get_shop_stats(db: AsyncSession) -> ShopStats:
        """Метод класса AdminService.
        Асинхронная функция `get_shop_stats` выполняет операцию в
        контуре бота EFHC.
        Назначение: получить/прочитать данные и вернуть результат без
        побочных эффектов (кроме логирования).

        Параметры:
        - `db` (AsyncSession): входной параметр.

        Возвращает:
        - Значение типа/структуры: ShopStats.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return await AdminStatsService.get_shop_stats(db)

    @staticmethod
    async def get_system_stats(db: AsyncSession) -> SystemStats:
        """Метод класса AdminService.
        Асинхронная функция `get_system_stats` выполняет операцию в
        контуре бота EFHC.
        Назначение: получить/прочитать данные и вернуть результат без
        побочных эффектов (кроме логирования).

        Параметры:
        - `db` (AsyncSession): входной параметр.

        Возвращает:
        - Значение типа/структуры: SystemStats.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли (идемпотентность
        достигается ключами/уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8 и
        округлением вниз (ROUND_DOWN), если применимо по модулю.
        - Для операций, затрагивающих баланс/банк, изменения должны
        проходить через банковский сервис транзакций
        (transactions_service)."""
        return await AdminStatsService.get_system_stats(db)

    # ------------------------------------------------------------------
    # --- #
    # 9. ПОЛЬЗОВАТЕЛИ / БАЛАНСЫ / ПРОГРЕСС / ОТЛАДКА
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def get_user_balances(
        db: AsyncSession,
        tg_id: int,
    ) -> Dict[str, str]:
        """
        Текущие балансы пользователя (EFHC обычные, EFHC бонусные, kWh).

        ВНИМАНИЕ:
          • Это только чтение; любые изменения балансов идут через банк
          - сервис.
        """
        return await AdminUsersService.get_user_balances(
            db,
            tg_id=tg_id,
        )

    @staticmethod
    async def debug_user_progress_by_telegram(
        db: AsyncSession,
        tg_id: int,
    ) -> UserProgressSnapshot:
        """
        Открывает «окно игры» пользователя по Telegram ID:
        • панели, VIP-статус,
        • энергия (available_kwh, total_generated_kwh),
        • уровни/достижения,
        • последние операции.

        Используется для отладки сбоев и ручных исправлений.
        """
        return await AdminUsersService.debug_user_progress_by_telegram(
            db,
            tg_id=tg_id,
        )

    @staticmethod
    async def credit_bonus_efhc(
        db: AsyncSession,
        tg_id: int,
        amount: Decimal,
        *,
        reason: str = "ADMIN",
        admin: Optional[AdminUser] = None,
    ) -> None:
        """
        Ручное бонусное начисление EFHC пользователю.

        Ограничения:
        • только бонусный счёт;
        • операции считаются «банк → пользователь» и логируются;
        • идемпотентность обеспечивается на уровне
          AdminUsersService/BankService.
        """
        await AdminUsersService.credit_bonus_efhc(
            db,
            tg_id=tg_id,
            amount=amount,
            reason=reason,
            admin=admin,
        )

    @staticmethod
    async def credit_regular_efhc(db: AsyncSession,
        tg_id: int,
        amount: Decimal,
        *,
        reason: str = "ADMIN",
        admin: Optional[AdminUser] = None,) -> None:
        """
        Ручное начисление обычных EFHC пользователю (редкие
        корректировки).

        Разрешено только администраторам с соответствующей ролью.
        """
        await AdminUsersService.credit_regular_efhc(
            db,
            tg_id=tg_id,
            amount=amount,
            reason=reason,
            admin=admin,
        )

    # ------------------------------------------------------------------
    # --- #
    # 10. ЗАЯВКИ НА ВЫВОД EFHC / БОНУСЫ НА ВЫВОД / NFT ПО ЗАЯВКАМ
    # #
    # ------------------------------------------------------------------
    # --- #

    @staticmethod
    async def list_withdraw_requests(db: AsyncSession,
        filters: WithdrawalFilters,) -> List[WithdrawalRecord]:
        """
        Список заявок на вывод EFHC (для обработки админами).
        """
        return await WithdrawalsService.list_withdrawals(
            db,
            filters=filters,
        )

    @staticmethod
    async def admin_approve_withdraw(
        db: AsyncSession,
        request_id: int,
        req: WithdrawalApproveRequest,
        admin: AdminUser,) -> Dict[str, Any]:
        """
        Админ утвердил вывод (внешняя транзакция будет выполнена
        вручную/интеграцией).
        """
        return await WithdrawalsService.approve_withdrawal(
            db,
            request_id=request_id,
            admin=admin,
        )

    @staticmethod
    async def admin_reject_withdraw(
        db: AsyncSession,
        request_id: int,
        admin: AdminUser,
        reason: str,) -> Dict[str, Any]:
        """
        Админ отклонил вывод:
          • выполняется идемпотентный рефанд EFHC пользователю из Банка;
          • заявка помечается как REJECTED.
        """
        return await WithdrawalsService.reject_withdrawal(
            db,
            request_id=request_id,
            admin=admin,
            reason=reason,)

    @staticmethod
    async def admin_mark_withdraw_paid(
        db: AsyncSession,
        request_id: int,
        admin: AdminUser,
        *,
        payout_ref: Optional[str] = None,) -> Dict[str, Any]:
        """
        Админ помечает заявку как PAID после внешней выплаты.

        Канон: используйте approve_withdrawal().
        payout_ref сохранён в контуре WebApp.
        """
        _ = db
        _ = request_id
        _ = admin
        _ = payout_ref
        raise ValueError("Use approve_withdrawal")

    @staticmethod
    async def list_bonus_payouts(db: AsyncSession,
        filters: BonusAwardFilters,) -> List[Dict[str, Any]]:
        """
        Список бонусных начислений «на вывод» (например, из
        лотерей/заданий),
        которые ожидают подтверждения/обработки.
        """
        return await WithdrawalsService.list_bonus_awards(
            db,
            filters=filters,
        )

    @staticmethod
    async def list_prize_claims(db: AsyncSession,
        filters: PrizeClaimFilters,) -> List[Dict[str, Any]]:
        """
        Список заявок на выдачу призов (NFT VIP и др.) по
        магазинам/лотереям.
        """
        return await WithdrawalsService.list_prize_claims(
            db,
            filters=filters,
        )

    @staticmethod
    async def mark_prize_claim_done(db: AsyncSession,
        claim_id: int,
        admin: AdminUser,
        tx_hash: Optional[str] = None,) -> None:
        """
        Пометить заявку на приз как выполненную (NFT/внешний актив
        выдан).
        """
        await WithdrawalsService.mark_prize_claim_done(
            db,
            claim_id=claim_id,
            admin=admin,
            tx_hash=tx_hash,
        )

    @staticmethod
    async def reject_prize_claim(db: AsyncSession,
        claim_id: int,
        admin: AdminUser,
        reason: str,) -> None:
        """
        Отклонить заявку на приз с указанием причины.
        """
        await WithdrawalsService.reject_prize_claim(
            db,
            claim_id=claim_id,
            admin=admin,
            reason=reason,
        )


# ======================================================================
# Публичный API модуля
# #
# ======================================================================

__all__ = [
    "AdminService",
    # Базовые сущности для удобства использования в роутерах:
    "AdminUser",
    "AdminRole",
    "AdminAuthError",
    "AdminLog",
    "Pagination",
    "SystemSetting",
    "ALLOWED_SETTINGS",
    "AdminNotification",
    "CreateLotteriesRequest",
    "UpdateLotteriesRequest",
    "LotteriesInfo",
    "WinnerTicket",
    "LotteriestatusSummary",
    "PanelToggleRequest",
    "MintBurnRequest",
    "ManualBankTransferRequest",
    "BankBalanceDTO",
    "CoinsStats",
    "PanelsStats",
    "ReferralsStats",
    "ShopStats",
    "SystemStats",
    "UserProgressSnapshot",
    "WithdrawalRecord",
    "WithdrawalFilters",
    "BonusAwardFilters",
    "PrizeClaimFilters",
]

