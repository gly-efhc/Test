from __future__ import annotations

from typing import Any

from app.crud.admin.admin_hub_links_crud import (
    add_hub_link,
    get_hub_link_by_code,
    get_hub_link_by_id,
    list_hub_links,
    save_hub_link,
)
from app.models.hub_links_models import HubLink
from sqlalchemy.ext.asyncio import AsyncSession


class HubLinkAdminError(ValueError):
    """Validation/domain error for admin Hub links manager."""


def _to_dict(link: HubLink) -> dict[str, Any]:
    return {
        "id": int(link.id),
        "code": link.code,
        "title": link.title,
        "subtitle": link.subtitle,
        "url": link.url,
        "target_kind": link.target_kind,
        "open_mode": link.open_mode,
        "sort_order": int(link.sort_order),
        "is_active": bool(link.is_active),
        "icon_key": link.icon_key,
        "created_at": link.created_at,
        "updated_at": link.updated_at,
    }


async def admin_list_hub_links(
    db: AsyncSession,
    *,
    active_only: bool = False,
) -> list[dict[str, Any]]:
    rows = await list_hub_links(db, active_only=active_only)
    return [_to_dict(row) for row in rows]


async def admin_seed_hub_link_if_missing(
    db: AsyncSession,
    *,
    code: str,
    title: str,
    subtitle: str | None,
    url: str,
    target_kind: str,
    open_mode: str,
    sort_order: int,
    is_active: bool = True,
    icon_key: str | None = None,
) -> dict[str, Any]:
    existing = await get_hub_link_by_code(db, code=code)
    if existing is not None:
        return _to_dict(existing)

    created = await add_hub_link(
        db,
        code=code,
        title=title,
        subtitle=subtitle,
        url=url,
        target_kind=target_kind,
        open_mode=open_mode,
        sort_order=sort_order,
        is_active=is_active,
        icon_key=icon_key,
    )
    return _to_dict(created)


async def admin_create_hub_link(
    db: AsyncSession,
    *,
    code: str,
    title: str,
    subtitle: str | None,
    url: str,
    target_kind: str,
    open_mode: str,
    sort_order: int,
    is_active: bool,
    icon_key: str | None,
) -> dict[str, Any]:
    existing = await get_hub_link_by_code(db, code=code)
    if existing is not None:
        raise HubLinkAdminError(f"hub link code already exists: {code}")
    created = await add_hub_link(
        db,
        code=code,
        title=title,
        subtitle=subtitle,
        url=url,
        target_kind=target_kind,
        open_mode=open_mode,
        sort_order=sort_order,
        is_active=is_active,
        icon_key=icon_key,
    )
    return _to_dict(created)


async def admin_update_hub_link(
    db: AsyncSession,
    *,
    link_id: int,
    title: str,
    subtitle: str | None,
    url: str,
    target_kind: str,
    open_mode: str,
    sort_order: int,
    is_active: bool,
    icon_key: str | None,
) -> dict[str, Any]:
    link = await get_hub_link_by_id(db, link_id=link_id)
    if link is None:
        raise HubLinkAdminError(f"hub link not found: {link_id}")
    link.title = title
    link.subtitle = subtitle
    link.url = url
    link.target_kind = target_kind
    link.open_mode = open_mode
    link.sort_order = int(sort_order)
    link.is_active = bool(is_active)
    link.icon_key = icon_key
    saved = await save_hub_link(db, link=link)
    return _to_dict(saved)


async def admin_toggle_hub_link(
    db: AsyncSession,
    *,
    link_id: int,
    is_active: bool,
) -> dict[str, Any]:
    link = await get_hub_link_by_id(db, link_id=link_id)
    if link is None:
        raise HubLinkAdminError(f"hub link not found: {link_id}")
    link.is_active = bool(is_active)
    saved = await save_hub_link(db, link=link)
    return _to_dict(saved)


async def admin_reorder_hub_links(
    db: AsyncSession,
    *,
    items: list[dict[str, int]],
) -> list[dict[str, Any]]:
    changed: list[HubLink] = []
    for item in items:
        link = await get_hub_link_by_id(db, link_id=int(item["id"]))
        if link is None:
            raise HubLinkAdminError(
                f"hub link not found: {item['id']}"
            )
        link.sort_order = int(item["sort_order"])
        changed.append(link)
    for link in changed:
        await save_hub_link(db, link=link)
    rows = await list_hub_links(db, active_only=False)
    return [_to_dict(row) for row in rows]
