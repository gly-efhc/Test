# backend/app/services/admin/init.py
"""Сервисы админки (сборка из доменных сервисов/CRUD)."""

__all__ = []
