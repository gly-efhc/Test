# backend/app/services/admin/__init__.py
"""Сервисы админки (сборка из доменных сервисов/CRUD)."""


__all__ = []
