"""Read-only access to historical/internal ShopOrder rows.

All active shop writes are owned by the canonical shop/browser-shop services.
This module deliberately exposes no payment, stock, or NFT write path.
"""

from __future__ import annotations

from app.models.shop_models import ShopOrder
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


async def get_order(
    session: AsyncSession,
    *,
    order_id: int,
) -> ShopOrder | None:
    """Return one order by primary key."""
    return await session.get(ShopOrder, int(order_id))


async def list_user_orders(
    session: AsyncSession,
    *,
    global_id: int,
    limit: int = 50,
) -> list[ShopOrder]:
    """Return latest orders for the canonical account owner."""
    result = await session.execute(
        select(ShopOrder)
        .where(ShopOrder.global_id == int(global_id))
        .order_by(ShopOrder.order_id.desc())
        .limit(int(limit))
    )
    return list(result.scalars().all())


__all__ = ["get_order", "list_user_orders"]
