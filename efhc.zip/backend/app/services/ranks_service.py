"""Materialized EFHC leaderboard aligned with ORM models."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from app.core.logging_core import get_logger
from app.deps import d8
from app.utils.cursor_codec import decode_cursor, encode_cursor
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)

ADVISORY_LOCK_KEY = 0x45F1_00AB
TOP_BUCKET = "global_top_100"
META_TIME_KEY = "ranks.last_snapshot_at"
META_TOTAL_KEY = "ranks.total_users"


@dataclass
class RankRow:
    tg_id: int
    username: str | None
    total_kwh: str
    rank: int
    is_vip: bool


@dataclass
class RankSnapshotMeta:
    snapshot_at: datetime
    total_users: int


async def rebuild_rank_snapshot(
    db: AsyncSession,
    *,
    force_refresh: bool = False,
    limit_users: int | None = None,
) -> RankSnapshotMeta:
    """Rebuild cache and history atomically, including an empty DB."""
    _ = force_refresh
    got_lock = await _try_advisory_xact_lock(
        db,
        ADVISORY_LOCK_KEY,
    )
    if not got_lock:
        meta = await _current_meta(db)
        if meta is not None:
            logger.info("ranks rebuild skipped: lock held")
            return meta
        logger.warning("ranks lock held and meta is missing")
        return RankSnapshotMeta(
            snapshot_at=datetime.now(tz=UTC),
            total_users=0,
        )

    users_sql = (
        "SELECT u.tg_id, u.username, u.is_vip, "
        "COALESCE(u.total_generated_kwh, 0) "
        "FROM efhc_core.users u "
        "WHERE COALESCE(u.is_active, true) = true "
        "ORDER BY COALESCE(u.total_generated_kwh, 0) DESC, "
        "u.tg_id ASC"
    )
    if limit_users is not None and int(limit_users) > 0:
        result = await db.execute(
            text(users_sql + " LIMIT :limit"),
            {"limit": int(limit_users)},
        )
    else:
        result = await db.execute(text(users_sql))
    users = result.fetchall()
    snapshot_at = datetime.now(tz=UTC)

    await db.execute(
        text(
            "DELETE FROM efhc_core.ranks_top_cache "
            "WHERE bucket = :bucket"
        ),
        {"bucket": TOP_BUCKET},
    )

    cache_sql = text(
        "INSERT INTO efhc_core.ranks_top_cache "
        "(bucket, snapshot_at, tg_id, rank_position, "
        "total_generated_kwh, meta) "
        "VALUES (:bucket, :snap, :tg_id, :rank, :kwh, "
        "CAST(:meta AS jsonb))"
    )
    history_sql = text(
        "INSERT INTO efhc_core.ranks_snapshots "
        "(snapshot_at, tg_id, rank_position, "
        "total_generated_kwh, meta) "
        "VALUES (:snap, :tg_id, :rank, :kwh, "
        "CAST(:meta AS jsonb)) "
        "ON CONFLICT (snapshot_at, tg_id) DO NOTHING"
    )

    for rank, row in enumerate(users, start=1):
        params = {
            "bucket": TOP_BUCKET,
            "snap": snapshot_at,
            "tg_id": int(row[0]),
            "rank": rank,
            "kwh": str(d8(row[3])),
            "meta": '{"scope":"global"}',
        }
        await db.execute(cache_sql, params)
        await db.execute(history_sql, params)

    await _write_meta(
        db,
        snapshot_at=snapshot_at,
        total_users=len(users),
    )
    await db.commit()

    logger.info(
        "ranks snapshot complete users=%s at=%s",
        len(users),
        snapshot_at.isoformat(),
    )
    return RankSnapshotMeta(
        snapshot_at=snapshot_at,
        total_users=len(users),
    )


async def get_user_rank_and_top(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    top_limit: int = 100,
) -> tuple[RankRow | None, list[RankRow], RankSnapshotMeta]:
    """Return current user, TOP list and snapshot metadata."""
    if (tg_id is None) == (global_id is None):
        raise ValueError("Rank owner selector is required")
    meta = await _current_meta(db)
    if meta is None:
        return await _live_me_and_top(
            db,
            tg_id=tg_id,
            global_id=global_id,
            top_limit=top_limit,
        )

    if global_id is not None:
        me_sql = (
            "SELECT u.tg_id, u.username, u.is_vip, "
            "c.total_generated_kwh, c.rank_position "
            "FROM efhc_core.ranks_top_cache c "
            "JOIN efhc_core.users u ON u.global_id = c.global_id "
            "WHERE c.bucket = :bucket "
            "AND c.global_id = :global_id "
            "ORDER BY c.snapshot_at DESC LIMIT 1"
        )
        me_params = {
            "bucket": TOP_BUCKET,
            "global_id": int(global_id),
        }
        top_sql = (
            "SELECT u.tg_id, u.username, u.is_vip, "
            "c.total_generated_kwh, c.rank_position "
            "FROM efhc_core.ranks_top_cache c "
            "JOIN efhc_core.users u ON u.global_id = c.global_id "
            "WHERE c.bucket = :bucket AND u.tg_id IS NOT NULL "
            "ORDER BY c.rank_position ASC, u.tg_id ASC "
            "LIMIT :limit"
        )
    else:
        me_sql = (
            "SELECT c.tg_id, u.username, u.is_vip, "
            "c.total_generated_kwh, c.rank_position "
            "FROM efhc_core.ranks_top_cache c "
            "JOIN efhc_core.users u ON u.tg_id = c.tg_id "
            "WHERE c.bucket = :bucket AND c.tg_id = :tg_id "
            "ORDER BY c.snapshot_at DESC LIMIT 1"
        )
        me_params = {"bucket": TOP_BUCKET, "tg_id": int(tg_id or 0)}
        top_sql = (
            "SELECT u.tg_id, u.username, u.is_vip, "
            "c.total_generated_kwh, c.rank_position "
            "FROM efhc_core.ranks_top_cache c "
            "JOIN efhc_core.users u ON u.tg_id = c.tg_id "
            "WHERE c.bucket = :bucket AND u.tg_id IS NOT NULL "
            "ORDER BY c.rank_position ASC, u.tg_id ASC "
            "LIMIT :limit"
        )

    me_result = await db.execute(text(me_sql), me_params)
    me = _rank_from_row(me_result.fetchone())
    top_result = await db.execute(
        text(top_sql),
        {"bucket": TOP_BUCKET, "limit": int(top_limit)},
    )
    top = [
        item
        for item in (
            _rank_from_row(row) for row in top_result.fetchall()
        )
        if item is not None
        and (me is None or item.tg_id != me.tg_id)
    ]
    return me, top, meta


async def get_leaderboard_page(
    db: AsyncSession,
    *,
    after_cursor: str | None,
    page_size: int = 100,
    global_read: bool = False,
) -> tuple[list[RankRow], str | None, RankSnapshotMeta]:
    """Return a stable cursor-based leaderboard page."""
    meta = await _current_meta(db)
    if meta is None:
        meta = RankSnapshotMeta(
            snapshot_at=datetime.now(tz=UTC),
            total_users=0,
        )
        return [], None, meta

    params: dict[str, Any] = {
        "bucket": TOP_BUCKET,
        "limit": int(page_size),
    }
    cursor_is_valid = False
    if after_cursor:
        try:
            payload = decode_cursor(after_cursor)
            params["pos"] = int(payload.get("pos") or 0)
            params["tg_id"] = int(payload.get("tg_id") or 0)
            cursor_is_valid = True
        except Exception as exc:
            logger.warning("invalid ranks cursor: %s", exc)

    if global_read:
        base_select = (
            "SELECT u.tg_id, u.username, u.is_vip, "
            "c.total_generated_kwh, c.rank_position "
            "FROM efhc_core.ranks_top_cache c "
            "JOIN efhc_core.users u ON u.global_id = c.global_id "
            "WHERE c.bucket = :bucket AND u.tg_id IS NOT NULL "
        )
    else:
        base_select = (
            "SELECT u.tg_id, u.username, u.is_vip, "
            "c.total_generated_kwh, c.rank_position "
            "FROM efhc_core.ranks_top_cache c "
            "JOIN efhc_core.users u ON u.tg_id = c.tg_id "
            "WHERE c.bucket = :bucket AND u.tg_id IS NOT NULL "
        )
    if cursor_is_valid:
        page_sql = text(
            base_select
            + "AND (c.rank_position, u.tg_id) > (:pos, :tg_id) "
            "ORDER BY c.rank_position ASC, u.tg_id ASC "
            "LIMIT :limit"
        )
    else:
        page_sql = text(
            base_select
            + "ORDER BY c.rank_position ASC, u.tg_id ASC "
            "LIMIT :limit"
        )
    result = await db.execute(page_sql, params)
    items = [
        item
        for item in (
            _rank_from_row(row) for row in result.fetchall()
        )
        if item is not None
    ]
    next_cursor = None
    if items:
        last = items[-1]
        next_cursor = encode_cursor(
            {"pos": last.rank, "tg_id": last.tg_id}
        )
    return items, next_cursor, meta


async def _current_meta(
    db: AsyncSession,
) -> RankSnapshotMeta | None:
    result = await db.execute(
        text(
            "SELECT key, value FROM efhc_core.app_settings "
            "WHERE key IN (:time_key, :total_key)"
        ),
        {"time_key": META_TIME_KEY, "total_key": META_TOTAL_KEY},
    )
    values = {str(row[0]): str(row[1]) for row in result.fetchall()}
    raw_time = values.get(META_TIME_KEY, "").strip()
    if not raw_time:
        return None
    try:
        snapshot_at = datetime.fromisoformat(raw_time)
        if snapshot_at.tzinfo is None:
            snapshot_at = snapshot_at.replace(tzinfo=UTC)
        total_users = int(values.get(META_TOTAL_KEY, "0"))
    except (TypeError, ValueError):
        return None
    return RankSnapshotMeta(
        snapshot_at=snapshot_at,
        total_users=max(0, total_users),
    )


async def _write_meta(
    db: AsyncSession,
    *,
    snapshot_at: datetime,
    total_users: int,
) -> None:
    sql = text(
        "INSERT INTO efhc_core.app_settings (key, value) "
        "VALUES (:key, :value) "
        "ON CONFLICT (key) DO UPDATE SET "
        "value = EXCLUDED.value, updated_at = now()"
    )
    await db.execute(
        sql,
        {"key": META_TIME_KEY, "value": snapshot_at.isoformat()},
    )
    await db.execute(
        sql,
        {"key": META_TOTAL_KEY, "value": str(total_users)},
    )


async def _live_me_and_top(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    top_limit: int,
) -> tuple[RankRow | None, list[RankRow], RankSnapshotMeta]:
    result = await db.execute(
        text(
            "SELECT u.tg_id, u.username, u.is_vip, "
            "COALESCE(u.total_generated_kwh, 0), "
            "ROW_NUMBER() OVER (ORDER BY "
            "COALESCE(u.total_generated_kwh, 0) DESC, u.tg_id ASC) "
            "FROM efhc_core.users u "
            "WHERE COALESCE(u.is_active, true) = true "
            "ORDER BY COALESCE(u.total_generated_kwh, 0) DESC, "
            "u.tg_id ASC LIMIT :limit"
        ),
        {"limit": max(int(top_limit), 1)},
    )
    all_rows = [
        item
        for item in (
            _rank_from_row(row) for row in result.fetchall()
        )
        if item is not None
    ]
    if global_id is not None:
        me_tg_result = await db.execute(
            text(
                "SELECT tg_id FROM efhc_core.users "
                "WHERE global_id = :global_id"
            ),
            {"global_id": int(global_id)},
        )
        me_tg_raw = me_tg_result.scalar_one_or_none()
        me_tg = int(me_tg_raw) if me_tg_raw is not None else None
    else:
        me_tg = int(tg_id or 0)
    me = next(
        (row for row in all_rows if row.tg_id == me_tg),
        None,
    )
    top = [row for row in all_rows if row.tg_id != me_tg]
    count_result = await db.execute(
        text(
            "SELECT COUNT(*) FROM efhc_core.users "
            "WHERE COALESCE(is_active, true) = true"
        )
    )
    meta = RankSnapshotMeta(
        snapshot_at=datetime.now(tz=UTC),
        total_users=int(count_result.scalar_one()),
    )
    return me, top, meta


def _rank_from_row(row: Any) -> RankRow | None:
    if row is None:
        return None
    return RankRow(
        tg_id=int(row[0]),
        username=row[1],
        is_vip=bool(row[2]),
        total_kwh=str(d8(row[3])),
        rank=int(row[4]),
    )


async def _try_advisory_xact_lock(
    db: AsyncSession,
    key: int,
) -> bool:
    result = await db.execute(
        text("SELECT pg_try_advisory_xact_lock(:key)"),
        {"key": int(key)},
    )
    return bool(result.scalar_one_or_none())


async def ensure_ranks_tables(db: AsyncSession) -> None:
    await ensure_latest_snapshot(db)


async def ensure_latest_snapshot(
    db: AsyncSession,
    *,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
) -> RankSnapshotMeta:
    meta = await _current_meta(db)
    now = datetime.now(tz=UTC)
    if meta is None or force_refresh:
        return await rebuild_rank_snapshot(db, force_refresh=True)
    age_seconds = (now - meta.snapshot_at).total_seconds()
    if age_seconds > max(0, int(max_age_minutes)) * 60:
        return await rebuild_rank_snapshot(db, force_refresh=True)
    return meta


async def get_my_plus_top(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
) -> tuple[
    RankRow | None,
    list[RankRow],
    RankSnapshotMeta,
    str | None,
]:
    _ = cursor
    meta = await ensure_latest_snapshot(
        db,
        force_refresh=force_refresh,
        max_age_minutes=max_age_minutes,
    )
    me, top, _ = await get_user_rank_and_top(
        db,
        tg_id=tg_id,
        global_id=global_id,
        top_limit=int(limit),
    )
    next_cursor = None
    if top:
        last = top[-1]
        next_cursor = encode_cursor(
            {"pos": last.rank, "tg_id": last.tg_id}
        )
    return me, top, meta, next_cursor


async def list_top_page(
    db: AsyncSession,
    *,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
    global_read: bool = False,
) -> tuple[list[RankRow], RankSnapshotMeta, str | None]:
    meta = await ensure_latest_snapshot(
        db,
        force_refresh=force_refresh,
        max_age_minutes=max_age_minutes,
    )
    items, next_cursor, _ = await get_leaderboard_page(
        db,
        after_cursor=cursor,
        page_size=int(limit),
        global_read=bool(global_read),
    )
    return items, meta, next_cursor


__all__ = [
    "RankRow",
    "RankSnapshotMeta",
    "ensure_latest_snapshot",
    "ensure_ranks_tables",
    "get_leaderboard_page",
    "get_my_plus_top",
    "get_user_rank_and_top",
    "list_top_page",
    "rebuild_rank_snapshot",
]
