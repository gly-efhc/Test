# backend/app/services/ranks_service.py
# ----------------------------------------------------------------------
# Ranks service: materialized leaderboard based on total_generated_kwh.
# Sort order: (total_generated_kwh DESC, tg_id ASC).
# Paginates by cursor.
# ----------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.utils.cursor_codec import decode_cursor, encode_cursor
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()


@dataclass
class RankRow:
    tg_id: int
    username: str | None
    total_kwh: str
    rank: int
    is_vip: bool


@dataclass
class RankSnapshotMeta:
    snapshot_at: datetime
    total_users: int


SQL_ENSURE_TABLES = ""

ADVISORY_LOCK_KEY = 0x45F1_00AB



async def rebuild_rank_snapshot(
    db: AsyncSession,
    *,
    force_refresh: bool = False,
    limit_users: int | None = None,
) -> RankSnapshotMeta:
    """Rebuild ranks_top_cache from users and store meta."""
    _ = force_refresh

    got_lock = await _try_advisory_xact_lock(db, ADVISORY_LOCK_KEY)
    if not got_lock:
        logger.info(
            "ranks_service: skip rebuild; lock held",
        )
        meta = await _current_meta(db)
        if meta:
            return meta
        logger.warning(
            "ranks_service: meta missing; rebuilding without lock",
        )

    limit_clause = ""
    if limit_users and int(limit_users) > 0:
        limit_clause = f"LIMIT {int(limit_users)}"

    q_users = text(
        "\n".join(
            [
                "SELECT",
                "  u.tg_id AS tg_id,",
                "  u.username,",
                "  COALESCE(u.total_generated_kwh, 0) AS total_kwh",
                "FROM efhc_core.users u",
                "WHERE COALESCE(u.is_active, TRUE) = TRUE",
                "ORDER BY COALESCE(u.total_generated_kwh, 0) DESC,",
                "  u.tg_id ASC",
                limit_clause,
            ]
        )
    )
    rows = await db.execute(q_users)
    data = rows.fetchall()

    total_users = 0
    rank = 0
    snapshot_at = datetime.now(tz=UTC)

    await db.execute(text("TRUNCATE TABLE efhc_core.ranks_top_cache"))

    q_upsert = text(
        "\n".join(
            [
                "INSERT INTO efhc_core.ranks_top_cache (", # nosec
                "  tg_id, username, total_generated_kwh,",
                "  rank_position, snapshot_at",
                ")",
                "VALUES (:tg_id, :username, :is_vip, :kwh,",
                "  :rank, :snap)",
                "ON CONFLICT (tg_id) DO UPDATE",
                "SET",
                "  username = EXCLUDED.username,",
                "  total_generated_kwh = EXCLUDED.total_generated_kwh,",
                "  rank_position = EXCLUDED.rank_position,",
                "  snapshot_at = EXCLUDED.snapshot_at",
            ]
        )
    )

    for rank, rec in enumerate(data, start=1):
        total_users += 1
        tg_id = int(rec[0])
        username = rec[1]
        _is_vip = bool(rec[2])
        total_kwh = d8(rec[3])
        await db.execute(
            q_upsert,
            {
                "tg_id": tg_id,
                "username": username,
                "is_vip": _is_vip,
                "kwh": str(total_kwh),
                "rank": rank,
                "snap": snapshot_at,
            },
        )

    q_meta = text(
        "\n".join(
            [
                "INSERT INTO efhc_core.ranks_snapshots (", # nosec
                "  snapshot_at, total_users, built_ms",
                ")",
                "VALUES (:snap, :total, 0)",
            ]
        )
    )
    await db.execute(
        q_meta,
        {"snap": snapshot_at, "total": total_users},
    )
    await db.commit()

    logger.info(
        "ranks_service: snapshot rebuilt at %s with %s users",
        snapshot_at.isoformat(),
        total_users,
    )
    return RankSnapshotMeta(
        snapshot_at=snapshot_at,
        total_users=total_users,
    )


async def get_user_rank_and_top(
    db: AsyncSession,
    *,
    tg_id: int,
    top_limit: int = 100,
) -> tuple[RankRow | None, list[RankRow], RankSnapshotMeta]:
    """Return (me, top_rows, meta) from ranks_top_cache."""

    meta = await _current_meta(db)
    if not meta:
        logger.warning(
            "ranks_service: meta missing; falling back to live read",
        )
        me, top, meta = await _live_me_and_top(
            db,
            tg_id=tg_id,
            top_limit=top_limit,
        )
        return me, top, meta

    q_me = text(
        "\n".join(
            [
                "SELECT",
                "  c.tg_id, c.username, c.is_vip,",
                "  c.total_generated_kwh, c.rank_position",
                "FROM efhc_core.ranks_top_cache c",
                "WHERE c.tg_id = :tg_id",
                "LIMIT 1",
            ]
        )
    )
    me_row = await db.execute(q_me, {"tg_id": int(tg_id)})
    me = me_row.fetchone()
    me_obj: RankRow | None = None
    if me:
        me_obj = RankRow(
            tg_id=int(me[0]),
            username=me[1],
            total_kwh=str(d8(me[3])),
            rank=int(me[4]),
            is_vip=bool(me[2]),
        )

    q_top = text(
        "\n".join(
            [
                "SELECT",
                "  c.tg_id, c.username, c.is_vip,",
                "  c.total_generated_kwh, c.rank_position",
                "FROM efhc_core.ranks_top_cache c",
                "ORDER BY c.rank_position ASC",
                "LIMIT :lim",
            ]
        )
    )
    rs = await db.execute(q_top, {"lim": int(top_limit)})

    top_rows: list[RankRow] = []
    for r in rs.fetchall():
        row_tg_id = int(r[0])
        if me_obj and row_tg_id == me_obj.tg_id:
            continue
        top_rows.append(
            RankRow(
                tg_id=row_tg_id,
                username=r[1],
                total_kwh=str(d8(r[3])),
                rank=int(r[4]),
                is_vip=bool(r[2]),
            )
        )
    return me_obj, top_rows, meta


async def get_leaderboard_page(
    db: AsyncSession,
    *,
    after_cursor: str | None,
    page_size: int = 100,
) -> tuple[list[RankRow], str | None, RankSnapshotMeta]:
    """Return page of RankRow plus next_cursor."""

    meta = await _current_meta(db)
    if not meta:
        empty = RankSnapshotMeta(
            snapshot_at=datetime.now(tz=UTC),
            total_users=0,
        )
        return [], None, empty

    where = ""
    params: dict[str, Any] = {"lim": int(page_size)}
    if after_cursor:
        try:
            payload = decode_cursor(after_cursor)
            pos = int(payload.get("pos") or 0)
            cursor_tg_id = int(payload.get("tg_id") or 0)
            where = "WHERE (c.rank_position, c.tg_id) > (:pos, :tg_id)"
            params.update({"pos": pos, "tg_id": cursor_tg_id})
        except Exception as e:
            logger.warning(
                "ranks_service: bad cursor %s: %s",
                after_cursor,
                e,
            )

    q_page = text(
        "\n".join(
            [
                "SELECT",
                "  c.tg_id, c.username, c.is_vip,",
                "  c.total_generated_kwh, c.rank_position",
                "FROM efhc_core.ranks_top_cache c",
                where,
                "ORDER BY c.rank_position ASC, c.tg_id ASC",
                "LIMIT :lim",
            ]
        )
    )
    rs = await db.execute(q_page, params)
    data = rs.fetchall()

    items: list[RankRow] = [
        RankRow(
            tg_id=int(r[0]),
            username=r[1],
            total_kwh=str(d8(r[3])),
            rank=int(r[4]),
            is_vip=bool(r[2]),
        )
        for r in data
    ]

    next_cursor: str | None = None
    if items:
        last = items[-1]
        next_cursor = encode_cursor(
            {"pos": int(last.rank), "tg_id": int(last.tg_id)}
        )

    return items, next_cursor, meta


async def _current_meta(db: AsyncSession) -> RankSnapshotMeta | None:
    q = text(
        "\n".join(
            [
                "SELECT s.snapshot_at, s.total_users",
                "FROM efhc_core.ranks_snapshots s",
                "ORDER BY s.snapshot_at DESC",
                "LIMIT 1",
            ]
        )
    )
    row = await db.execute(q)
    rec = row.fetchone()
    if not rec:
        return None
    return RankSnapshotMeta(
        snapshot_at=rec[0],
        total_users=int(rec[1]),
    )


async def _live_me_and_top(
    db: AsyncSession,
    *,
    tg_id: int,
    top_limit: int,
) -> tuple[RankRow | None, list[RankRow], RankSnapshotMeta]:
    """Live fallback without ranks_top_cache."""
    q_me = text(
        "\n".join(
            [
                "SELECT u.tg_id, u.username,",
                "  COALESCE(u.total_generated_kwh, 0) AS total_kwh",
                "FROM efhc_core.users u",
                "WHERE u.tg_id = :tg_id",
                "LIMIT 1",
            ]
        )
    )
    me_q = await db.execute(q_me, {"tg_id": int(tg_id)})
    me = me_q.fetchone()

    me_obj: RankRow | None = None
    if me:
        q_rank = text(
            "\n".join(
                [
                    "SELECT 1 + COUNT(*) AS my_rank",
                    "FROM efhc_core.users uu",
                    "WHERE COALESCE(uu.total_generated_kwh, 0) >",
                    "  :my_kwh",
                    "  OR (COALESCE(uu.total_generated_kwh, 0) =",
                    "      :my_kwh",
                    "      AND uu.tg_id < :tg_id)",
                ]
            )
        )
        rank_q = await db.execute(
            q_rank,
            {"my_kwh": me[3], "tg_id": int(me[0])},
        )
        r = rank_q.fetchone()
        me_obj = RankRow(
            tg_id=int(me[0]),
            username=me[1],
            total_kwh=str(d8(me[3])),
            rank=int(r[0]) if r else 1,
            is_vip=bool(me[2]),
        )

    q_top = text(
        "\n".join(
            [
                "SELECT u.tg_id, u.username,",
                "  COALESCE(u.total_generated_kwh, 0) AS total_kwh",
                "FROM efhc_core.users u",
                "ORDER BY COALESCE(u.total_generated_kwh, 0) DESC,",
                "  u.tg_id ASC",
                "LIMIT :lim",
            ]
        )
    )
    rs = await db.execute(q_top, {"lim": int(top_limit)})

    top_rows: list[RankRow] = []
    for idx, row in enumerate(rs.fetchall(), start=1):
        row_tg_id = int(row[0])
        if me_obj and row_tg_id == me_obj.tg_id:
            continue
        top_rows.append(
            RankRow(
                tg_id=row_tg_id,
                username=row[1],
                total_kwh=str(d8(row[3])),
                rank=idx,
                is_vip=bool(row[2]),
            )
        )

    meta = RankSnapshotMeta(
        snapshot_at=datetime.now(tz=UTC),
        total_users=await _count_users(db),
    )
    return me_obj, top_rows, meta


async def _count_users(db: AsyncSession) -> int:
    sql = "SELECT COUNT(*) FROM efhc_core.users" # nosec
    row = await db.execute(text(sql))
    return int(row.scalar_one())


async def _try_advisory_xact_lock(db: AsyncSession, key: int) -> bool:
    q = text("SELECT pg_try_advisory_xact_lock(:k)")
    rs = await db.execute(q, {"k": int(key)})
    return bool(rs.scalar_one_or_none())


__all__ = [
    "RankRow",
    "RankSnapshotMeta",
    "ensure_ranks_tables",
    "rebuild_rank_snapshot",
    "get_user_rank_and_top",
    "get_leaderboard_page",
]

# ======================================================================
# Public service facade (used by HTTP routes)
# ======================================================================


async def ensure_ranks_tables(db: AsyncSession) -> None:
    await ensure_latest_snapshot(db)


async def ensure_latest_snapshot(
    db: AsyncSession,
    *,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
) -> RankSnapshotMeta:
    """Ensure snapshot is fresh enough; rebuild when needed.

    For first launch we keep it simple:
    - If there is no meta row -> rebuild.
    - If force_refresh -> rebuild.
    - If snapshot is older than max_age_minutes -> rebuild.
    """

    meta = await _current_meta(db)
    now = datetime.now(tz=UTC)
    if (meta is None) or force_refresh:
        return await rebuild_rank_snapshot(db, force_refresh=True)

    age_s = (now - meta.snapshot_at).total_seconds()
    if age_s > max(0, int(max_age_minutes)) * 60:
        return await rebuild_rank_snapshot(db, force_refresh=True)

    return meta


async def get_my_plus_top(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
) -> tuple[
    RankRow | None,
    list[RankRow],
    RankSnapshotMeta,
    str | None,
]:
    """Return (me, top, meta, next_cursor) for My + Top."""
    meta = await ensure_latest_snapshot(
        db,
        force_refresh=force_refresh,
        max_age_minutes=max_age_minutes,
    )
    me, top, _meta = await get_user_rank_and_top(
        db,
        tg_id=int(tg_id),
        top_limit=int(limit),
    )

    # next_cursor based on last top row (rank_position, tg_id)
    next_cursor_out: str | None = None
    if top:
        last = top[-1]
        next_cursor_out = encode_cursor(
            {"pos": int(last.rank), "tg_id": int(last.tg_id)}
        )

    return me, top, meta, next_cursor_out


async def list_top_page(
    db: AsyncSession,
    *,
    limit: int = 100,
    cursor: str | None = None,
    force_refresh: bool = False,
    max_age_minutes: int = 10,
) -> tuple[list[RankRow], RankSnapshotMeta, str | None]:
    """Return (items, meta, next_cursor) for a leaderboard page."""
    meta = await ensure_latest_snapshot(
        db,
        force_refresh=force_refresh,
        max_age_minutes=max_age_minutes,
    )
    items, next_cursor, _meta = await get_leaderboard_page(
        db,
        after_cursor=cursor,
        page_size=int(limit),
    )
    return items, meta, next_cursor
