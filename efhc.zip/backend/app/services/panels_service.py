# backend/app/services/panels_service.py
# =====================================================================
# EFHC Bot — Сервис панелей (покупка, учёт, списки, архивирование)
# --------------------------------------------------------------------
# Назначение (коротко, 1–3 строки):
# • Операции с «солнечными панелями» пользователя: покупка за EFHC, учёт
# активных
# и архивных панелей, сводка для UI, архивирование просроченных.
#
# Канон/инварианты (строго):
# • Цена панели фиксирована: 100 EFHC.
# • Строгий порядок списания: СНАЧАЛА бонусный баланс, затем основной (1
# операция — 2 дебета).
# • Пользователь НИКОГДА не уходит в минус: при дефиците —
# отказ.
# • Банк EFHC может быть в минусе — операции НЕ блокируем (это не зона
# ответственности сервиса).
# • Генерация энергии везде посекундная (SSOT per-sec ставки).
# Ставка VIP определяется наличием NFT.
# Панели хранят базовую ставку на момент
# создания,
# но фактические начисления делает energy_service по текущему статусу
# VIP.
# • Лимит активных панелей на пользователя: MAX_PANELS.
# • Срок жизни панели: 180 дней; по окончании — перевод в архив
# (is_active=false).
# • Все денежные движения только через единый банковский сервис
# (transactions_service).
#
# ИИ-защиты/самовосстановление:
# • Блокировки на уровне SQL (FOR UPDATE SKIP LOCKED) гасят гонки за
# один и тот же tg_id.
# • Read-through идемпотентность делается в банковском сервисе по
# idempotency_key.
# • Сервис устойчив к частичным отказам: если не удалось создать запись
# панели после успешных дебетов,
# повтор с теми же idempotency_key безопасен (read-through банка).
# • Для массовой покупки qty>1 — детерминированные ключи идемпотентности
# (suffix #1, #2, ...).
#
# Запреты:
# • Никаких P2P-переводов. Никаких EFHC→kWh. Никаких суточных расчётов.
# • Никаких прямых правок балансов — только через transactions_service.
# =====================================================================

# SSOT: p.expires_at > :server_now_utc
# SSOT: p.expires_at <= :server_now_utc
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.system_locks import (
    get_rate_base_d8,
    get_rate_vip_d8,
)
from app.deps import (
    d8,
    decode_cursor,
    encode_cursor,
)
from app.lib.time import utcnow
from app.models.panels_models import Panel
from app.services import transactions_service as bank
from sqlalchemy import desc, func, select, text, tuple_
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


def _tx_context(db: AsyncSession):
    if getattr(db, "in_transaction", None) and db.in_transaction():
        return db.begin_nested()
    return db.begin()

settings = get_settings()

# Константы канона (источник истины — Settings + SSOT helpers)
GEN_PER_SEC_BASE_KWH: Decimal = get_rate_base_d8()
GEN_PER_SEC_VIP_KWH: Decimal = get_rate_vip_d8()
PANEL_PRICE: Decimal = d8(
    getattr(settings, "PANEL_PRICE", "100") or "100"
)
MAX_PANELS: int = int(getattr(settings, "MAX_PANELS", 1000) or 1000)
PANEL_LIFETIME_DAYS: int = int(
    getattr(settings, "PANEL_LIFETIME_DAYS", 180) or 180
)

# --------------------------------------------------------------------
# Исключения домена (понятные коду роутов)
# --------------------------------------------------------------------


class PanelPurchaseError(Exception):
    """Общая ошибка покупки панели (детали в сообщении)."""


class UserInDebtError(PanelPurchaseError):
    """Исторический минус: покупки за EFHC заблокированы."""


class PanelLimitExceeded(PanelPurchaseError):
    """Превышен лимит активных панелей."""


class IdempotencyRequiredError(PanelPurchaseError):
    """Для денежных операций обязателен idempotency_key."""


class PanelReplayMissingDataError(PanelPurchaseError):
    """Replay-операция без данных о созданных панелях."""

# --------------------------------------------------------------------
# DTO для ответов сервиса
# --------------------------------------------------------------------
@dataclass


class PurchaseResult:
    ok: bool
    qty: int
    total_spent_bonus: Decimal
    total_spent_main: Decimal
    created_panel_ids: list[int]
    detail: str


@dataclass


class PanelsSummary:
    active_count: int
    total_generated_by_panels: Decimal
    nearest_expire_at: datetime | None


@dataclass


class PagedPanels:
    items: list[dict[str, Any]]
    next_cursor: str | None

# --------------------------------------------------------------------
# Внутренние утилиты
# --------------------------------------------------------------------
async def _lock_user_row(
    db: AsyncSession,
    tg_id: int,
) -> dict[str, Any] | None:
    """Лочит запись пользователя (SKIP LOCKED)."""
    row = await db.execute(
        text(
            """
            SELECT id, tg_id, is_vip,
                   main_balance, bonus_balance,
                   total_generated_kwh, available_kwh
              FROM efhc_core.users
             WHERE tg_id = :tg_id
             FOR UPDATE SKIP LOCKED
            """
        ),
        {"tg_id": int(tg_id)},
    )
    rec = row.fetchone()
    if not rec:
        return None
    return {
        "id": int(rec[0]),
        "tg_id": int(rec[1]),
        "is_vip": bool(rec[2]),
        "main_balance": d8(rec[3]),
        "bonus_balance": d8(rec[4]),
        "total_generated_kwh": d8(rec[5]),
        "available_kwh": d8(rec[6]),
    }


async def _get_active_panels_count(db: AsyncSession, tg_id: int) -> int:
    """Возвращает кол-во активных панелей пользователя."""
    now_utc = utcnow()
    r = await db.execute(
        text(
            """
            SELECT COUNT(*)
            FROM efhc_core.panels
            WHERE tg_id = :tg_id
              AND expires_at > :now_utc
            """
        ),
        {"tg_id": int(tg_id), "now_utc": now_utc},
    )
    return int(r.scalar() or 0)


async def _create_panel_record(db: AsyncSession, tg_id: int) -> int:
    """
    Создаём одну панель.
    Базовая ставка хранится как GEN_PER_SEC_BASE_KWH.
    Фактическая генерация учитывает VIP в energy_service (канон).
    """
    now = utcnow()
    expires_at = now + timedelta(days=PANEL_LIFETIME_DAYS)
    r = await db.execute(
        text(
            """
            INSERT INTO efhc_core.panels
              (
                tg_id,
                public_id,
                activated_at,
                created_at,
                expires_at,
                last_generated_at,
                base_gen_per_sec,
                generated_kwh,
                is_active,
                is_archived,
                archived_at
              )
            VALUES
              (
                :tg_id,
                NULL,
                :activated_at,
                :created_at,
                :expires_at,
                :last_gen,
                :base_rate,
                0,
                TRUE,
                FALSE,
                NULL
              )
            RETURNING id
            """
        ),
        {
            "tg_id": int(tg_id),
            "activated_at": now,
            "created_at": now,
            "expires_at": expires_at,
            "last_gen": now,
            "base_rate": str(GEN_PER_SEC_BASE_KWH),
        },
    )
    new_id = int(r.scalar())
    await _fill_public_id(db, panel_id=new_id)
    return new_id


async def _fill_public_id(db: AsyncSession, *, panel_id: int) -> str:
    """Заполняет public_id = ID######## на основе PK.

    Канон: при INSERT public_id хранится как NULL,
    затем UPDATE выполняется в той же транзакции.
    """
    public_id = f"ID{int(panel_id):08d}"
    await db.execute(
        text(
            """
            UPDATE efhc_core.panels
            SET public_id = :public_id
            WHERE id = :id
            """
        ),
        {"public_id": public_id, "id": int(panel_id)},
    )
    return public_id


async def _create_panel_records_bulk(
    db: AsyncSession,
    *,
    tg_id: int,
    qty: int,
) -> list[int]:
    """Создать qty панелей одним SQL INSERT.

    Это снижает число запросов к БД и делает создание панелей
    «всё или ничего» в рамках одной транзакции.
    """
    if qty <= 0:
        return []

    now = utcnow()
    expires_at = now + timedelta(days=PANEL_LIFETIME_DAYS)
    q = text(
        """
        INSERT INTO efhc_core.panels
          (
            tg_id,
            public_id,
            activated_at,
            created_at,
            expires_at,
            last_generated_at,
            base_gen_per_sec,
            generated_kwh,
            is_active,
            is_archived,
            archived_at
          )
        SELECT
          :tg_id,
          NULL,
          :activated_at,
          :created,
          :expires,
          :last_gen,
          :base_rate,
          0,
          TRUE,
          FALSE,
          NULL
        FROM generate_series(1, :qty)
        RETURNING id
        """
    )
    r = await db.execute(
        q,
        {
            "tg_id": int(tg_id),
            "activated_at": now,
            "created": now,
            "expires": expires_at,
            "last_gen": now,
            "base_rate": str(GEN_PER_SEC_BASE_KWH),
            "qty": int(qty),
        },
    )
    ids = [int(x[0]) for x in r.fetchall()]
    for pid in ids:
        await _fill_public_id(db, panel_id=pid)
    return ids


def _json_to_dict(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except Exception:
            return {}
        if isinstance(parsed, dict):
            return dict(parsed)
        return {}
    return {}


async def _get_purchase_payload_by_idk(
    db: AsyncSession,
    *,
    idempotency_key: str,
) -> dict[str, Any]:
    """Возвращает extra_info для :main ключа списания."""
    main_key = f"{idempotency_key}:main"
    r = await db.execute(
        text(
            """
            SELECT meta
            FROM efhc_core.efhc_transfers_log
            WHERE idempotency_key = :idk
            LIMIT 1
            """
        ),
        {"idk": main_key},
    )
    row = r.fetchone()
    if not row:
        return {}
    return _json_to_dict(row[0])


async def _merge_purchase_payload(
    db: AsyncSession,
    *,
    idempotency_key: str,
    patch: dict[str, Any],
) -> None:
    """Мержит extra_info в журнале покупки панели.

    Делается диалект-safe: читаем → мержим → пишем.
    """
    main_key = f"{idempotency_key}:main"
    bonus_key = f"{idempotency_key}:bonus"
    prev = await _get_purchase_payload_by_idk(
        db,
        idempotency_key=idempotency_key,
    )
    merged = dict(prev)
    merged.update(dict(patch))
    payload = json.dumps(merged, ensure_ascii=False)
    # Канон: любые правки efhc_transfers_log — только через
    # transactions_service.
    patch_dict = json.loads(payload) if payload else {}
    for idk in (bonus_key, main_key):
        await bank.append_transfer_meta_by_idempotency_key(
            db,
            idempotency_key=str(idk),
            meta=dict(patch_dict),
        )

# --------------------------------------------------------------------
# Публичные функции сервиса
# --------------------------------------------------------------------
async def purchase_panel(
    db: AsyncSession,
    *,
    tg_id: int,
    qty: int = 1,
    idempotency_key: str | None = None,
) -> PurchaseResult:
    """
    Покупка панелей: списание EFHC и создание записей панелей.
    Идемпотентность обеспечивается банком (read-through по ключу).

    Вход:
      • tg_id — целевой пользователь
      • qty — количество панелей (>=1)
      • idempotency_key — обязателен для денежных операций

    Побочные эффекты:
      • EFHC списывается с пользователя и зачисляется Банку.
      • Создаются активные панели, базовая ставка GEN_PER_SEC_BASE_KWH.

    Исключения:
      • IdempotencyRequiredError — если не передан ключ идемпотентности
      • UserInDebtError — если у пользователя исторический минус
      • PanelLimitExceeded — если будет превышен лимит активных панелей
      • PanelPurchaseError — прочие ошибки
    """
    if not idempotency_key or not idempotency_key.strip():
        msg = (
            "Idempotency-Key is required by canon for "
            "monetary operations."
        )
        raise IdempotencyRequiredError(msg)

    if qty <= 0:
        raise PanelPurchaseError("Количество панелей должно быть >= 1.")

    # 1) Лочим пользователя (skip locked).
    # Если занято — повтор запроса из роутера/клиента.
    user = await _lock_user_row(db, tg_id = tg_id)
    if not user:
        msg = (
            "Пользователь не найден или временно "
            "заблокирован другой операцией."
        )
        raise PanelPurchaseError(msg)

    # 2) Исторический минус блокирует покупки за EFHC.
    # Но не пополнения и не обмен kWh→EFHC.
    total_user = d8(user["main_balance"]) + d8(user["bonus_balance"])
    if total_user < d8("0"):
        msg = (
            "У пользователя отрицательный баланс: "
            "покупки за EFHC запрещены до выхода в 0."
        )
        raise UserInDebtError(msg)

    # 3) Проверка лимита активных панелей
    current_active = await _get_active_panels_count(db, tg_id = tg_id)
    if current_active + qty > MAX_PANELS:
        msg = (
            f"Лимит активных панелей {MAX_PANELS} "
            "будет превышен."
        )
        raise PanelLimitExceeded(msg)

    # 4) Денежный поток: списываем EFHC в пользу Банка.
    # Сначала бонус, потом основной.
    # Для qty>1 делаем ОДНО списание общей суммой (атомарно).
    total_amount = d8(PANEL_PRICE) * d8(qty)

    bonus_before = d8(user["bonus_balance"])
    main_before = d8(user["main_balance"])
    debit_result = None
    breakdown = bank.split_bonus_then_main(
        bonus_balance=bonus_before,
        main_balance=main_before,
        amount=d8(total_amount),
    )
    try:
        debit_result = await bank.spend_user_to_bank_bonus_then_main(
            db,
            tg_id=int(tg_id),
            amount=d8(total_amount),
            reason="panel_purchase",
            idempotency_key=str(idempotency_key),
            meta={
                "module": "panels_service",
                "qty": int(qty),
                "price_per_panel": str(d8(PANEL_PRICE)),
            },
        )
    except ValueError as e:
        logger.warning(
            "panel purchase denied tg_id=%s: %s",
            tg_id,
            e,
        )
        raise PanelPurchaseError(
            "Недостаточно EFHC для покупки панелей "
            "без ухода в минус."
        ) from e
    except Exception as e:
        logger.exception(
            "panel purchase debit failed tg_id=%s: %s",
            tg_id,
            e,
        )
        raise PanelPurchaseError(f"Ошибка списания EFHC: {e}") from e

    created_ids: list[int] = []
    created_public_ids: list[str] = []
    status = "success"

    if debit_result and debit_result.detail == "idempotent":
        status = "replay"
        payload = await _get_purchase_payload_by_idk(
            db,
            idempotency_key=str(idempotency_key),
        )
        ids = payload.get("panels_created_ids")
        pubs = payload.get("panels_public_ids")
        ids_ok = (
            isinstance(ids, list)
            and all(isinstance(x, int) for x in ids)
        )
        if ids_ok:
            created_ids = [int(x) for x in ids]
            if isinstance(pubs, list) and all(
                isinstance(x, str) for x in pubs
            ):
                created_public_ids = [str(x) for x in pubs]
            try:
                await _merge_purchase_payload(
                    db,
                    idempotency_key=str(idempotency_key),
                    patch={
                        "audit_schema_version": "v1",
                        "op_type": "PANEL_CREATE",
                        "tg_id": int(tg_id),
                        "idempotency_key": str(idempotency_key),
                        "status": "replay",
                    },
                )
                await db.commit()
            except Exception:
                await db.rollback()
        else:
            # Дебет был, но панели не зафиксированы в журнале.
            # Дозавершаем создание без повторного дебета.
            logger.warning(
                "panel purchase replay missing ids tg_id=%s",
                tg_id,
            )

    if not created_ids:
        try:
            async with _tx_context(db):
                created_ids = await _create_panel_records_bulk(
                    db,
                    tg_id=int(tg_id),
                    qty=int(qty),
                )
        except Exception as e:
            logger.exception(
                "panel purchase create failed tg_id=%s: %s",
                tg_id,
                e,
            )
            msg = f"Ошибка создания панелей: {e}"
            raise PanelPurchaseError(msg) from e

        # Вычислим public_id для ответа и аудита.
        created_public_ids = [
            f"ID{int(pid):08d}" for pid in created_ids
        ]

        try:
            await _merge_purchase_payload(
                db,
                idempotency_key=str(idempotency_key),
                patch={
                    "audit_schema_version": "v1",
                    "op_type": "PANEL_CREATE",
                    "tg_id": int(tg_id),
                    "idempotency_key": str(idempotency_key),
                    "status": status,
                    "panels_created_ids": created_ids,
                    "panels_public_ids": created_public_ids,
                },
            )
            await db.commit()
        except Exception as e:
            await db.rollback()
            logger.warning(
                "panel purchase audit merge failed tg_id=%s: %s",
                tg_id,
                e,
            )

    return PurchaseResult(
        ok=True,
        qty=qty,
        total_spent_bonus=d8(breakdown.bonus_part),
        total_spent_main=d8(breakdown.main_part),
        created_panel_ids=created_ids,
        detail="Панели успешно куплены.",
    )


async def create_panel_for_user(
    db: AsyncSession,
    *,
    tg_id: int,
    idempotency_key: str,
) -> dict[str, Any]:
    """SSOT: создание одной панели (покупка=активация).

    MUST: один (tg_id, Idempotency-Key) → одна и та же панель.
    """
    res = await purchase_panel(
        db,
        tg_id=int(tg_id),
        qty=1,
        idempotency_key=str(idempotency_key),
    )
    if not res.created_panel_ids:
        raise PanelReplayMissingDataError("Missing created panel id")
    pid = int(res.created_panel_ids[0])
    return {
        "id": pid,
        "public_id": f"ID{pid:08d}",
    }


async def archive_panel_for_user(
    db: AsyncSession,
    *,
    tg_id: int,
    panel_id: int,
) -> None:
    """Архивирует панель пользователя (для админки/тестов)."""
    now = utcnow()
    await db.execute(
        text(
            """
            UPDATE efhc_core.panels
            SET is_archived = TRUE,
                is_active = FALSE,
                archived_at = :now
            WHERE id = :pid
              AND tg_id = :tg
            """
        ),
        {"pid": int(panel_id), "tg": int(tg_id), "now": now},
    )

# --------------------------------------------------------------------
# Витрины/списки для UI (курсорная пагинация)
# --------------------------------------------------------------------
async def list_active_panels(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 25,
    cursor: str | None = None,
) -> PagedPanels:
    """Список активных панелей, курсорная пагинация."""
    return await list_user_panels(
        db,
        tg_id=int(tg_id),
        kind="active",
        limit=int(limit),
        cursor=cursor,
    )


async def list_user_panels(
    db: AsyncSession,
    *,
    tg_id: int,
    kind: str,
    limit: int = 25,
    cursor: str | None = None,
) -> PagedPanels:
    """SSOT: список панелей пользователя (active/archive).

    Фильтрация определяется server_now_utc, а не now() БД.
    """
    limit = max(1, min(100, int(limit)))
    server_now_utc = utcnow()

    if hasattr(kind, "value"):
        kind = kind.value  # type: ignore
    kind = (kind or "").strip().lower()
    if kind not in ("active", "archive"):
        raise ValueError("Invalid kind")

    act_at = func.coalesce(Panel.activated_at, Panel.created_at)

    stmt = select(
        Panel.id,
        Panel.public_id,
        act_at.label("act_at"),
        Panel.expires_at,
        Panel.base_gen_per_sec,
        Panel.generated_kwh,
        Panel.archived_at,
    ).where(
        Panel.tg_id == int(tg_id),
    )

    if kind == "active":
        stmt = stmt.where(Panel.expires_at > server_now_utc)
    else:
        stmt = stmt.where(Panel.expires_at <= server_now_utc)

    if cursor:
        payload = decode_cursor(cursor)
        created_at_iso = payload.get("ts")
        last_id = int(payload.get("id") or 0)

        c_at = None
        if isinstance(created_at_iso, str) and created_at_iso:
            try:
                c_at = datetime.fromisoformat(created_at_iso)
            except Exception:
                c_at = None

        if c_at is not None and last_id > 0:
            stmt = stmt.where(
                tuple_(act_at, Panel.id) < (c_at, int(last_id))
            )

    stmt = stmt.order_by(desc(act_at), desc(Panel.id)).limit(
        int(limit) + 1
    )

    res = await db.execute(stmt)
    rows = res.fetchall()

    items: list[dict[str, Any]] = []
    next_cursor: str | None = None

    for row in rows[: int(limit)]:
        items.append(
            {
                "id": int(row.id),
                "public_id": str(row.public_id),
                "created_at": _as_iso(row.act_at),
                "expires_at": _as_iso(row.expires_at),
                "archived_at": _as_iso(row.archived_at),
                "base_gen_per_sec": d8(row.base_gen_per_sec),
                "generated_kwh": d8(row.generated_kwh),
                "is_active": bool(
                    row.expires_at > server_now_utc
                ),
            }
        )

    if len(rows) > int(limit):
        last = rows[int(limit) - 1]
        next_cursor = encode_cursor(
            ts=_as_iso(last.act_at) or "",
            id=int(last.id),
        )

    return PagedPanels(items=items, next_cursor=next_cursor)


async def list_archived_panels(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 25,
    cursor: str | None = None,
) -> PagedPanels:
    """Список архивных панелей, курсорная пагинация."""
    return await list_user_panels(
        db,
        tg_id=int(tg_id),
        kind="archive",
        limit=int(limit),
        cursor=cursor,
    )


async def panels_summary(
    db: AsyncSession,
    *,
    tg_id: int,
) -> PanelsSummary:
    """
    Короткая сводка для экрана Panels:
      • active_count — число активных панелей
      • total_generated_by_panels — суммарная генерация по полю панелей
      • nearest_expire_at — ближайшая дата истечения активной панели
    """
    now_utc = utcnow()
    r = await db.execute(
        text(
            """
            SELECT
              COUNT(*) FILTER (
                WHERE expires_at > :now_utc
              ) AS active_count,
              COALESCE(
                SUM(generated_kwh),
                0
              ) AS total_generated_by_panels,
              MIN(expires_at) FILTER (WHERE expires_at > :now_utc)
                AS nearest_expire_at
            FROM efhc_core.panels
            WHERE tg_id = :tg_id
            """
        ),
        {"tg_id": int(tg_id), "now_utc": now_utc},
    )
    row = r.fetchone()
    return PanelsSummary(
        active_count=int(row[0] or 0),
        total_generated_by_panels=d8(row[1] or 0),
        nearest_expire_at=row[2],
    )

# --------------------------------------------------------------------
# Архивирование просроченных панелей (для планировщика)
# --------------------------------------------------------------------
async def archive_expired_panels(
    db: AsyncSession,
    *,
    limit: int = 1000,
) -> int:
    """
    Переводит просроченные панели в архив (is_active=false).
    Проставляет archived_at.
    Возвращает количество переведённых записей.

    Реализация через CTE + RETURNING.
      • выбираем порцию id под блокировку (SKIP LOCKED),
      • обновляем только эти записи,
      • считаем количество по числу возвращённых строк.
    """
    now = utcnow()
    r = await db.execute(text(
            """
            WITH cte AS (
                SELECT id
                FROM efhc_core.panels
                WHERE is_active = TRUE
                  AND expires_at <= :now
                ORDER BY id
                LIMIT :lim
                FOR UPDATE SKIP LOCKED
            )
            UPDATE efhc_core.panels AS p
               SET is_active = FALSE,
                   archived_at = :now
            FROM cte
            WHERE p.id = cte.id
            RETURNING p.id
            """),
        {"now": now, "lim": int(limit)},)
    rows = r.fetchall()
    return len(rows)

# --------------------------------------------------------------------
# Вспомогательные
# --------------------------------------------------------------------


def _as_iso(dt: datetime | None) -> str | None:
    """ISO-строка в UTC (или None)."""
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC).isoformat()

# =====================================================================
# Экспорт для import *
# =====================================================================
__all__ = [
    # исключения
    "PanelPurchaseError",
    "UserInDebtError",
    "PanelLimitExceeded",
    "IdempotencyRequiredError",
    # DTO
    "PurchaseResult",
    "PanelsSummary",
    "PagedPanels",
    # public API
    "purchase_panel",
    "list_active_panels",
    "list_archived_panels",
    "panels_summary",
    "archive_expired_panels",
]

# =====================================================================
# Пояснения:
# • Почему списание «бонус→основной»? Канон: бонусы тратятся первыми.
#   Их номинал возвращается в Банк, чтобы не создавать скрытую эмиссию.
# • Почему панели хранят base_gen_per_sec?
#   Чтобы не зашивать VIP в запись.
#   За VIP отвечает energy_service.
# • Почему блокируем покупки при историческом минусе?
#   Канон безопасности:
#   пользователь должен выйти из минуса сам (пополнение/обмен kWh→EFHC).
# • Почему суффиксы в idempotency_key "#i"? Чтобы qty>1 можно было
#   безопасно переисполнять без дублей при сетевых сбоях.
# • Почему курсоры? Курсорная пагинация стабильнее и дешевле OFFSET.
# =====================================================================
