# backend/app/services/panels_service.py
# =====================================================================
# EFHC Bot — Сервис панелей (активация, учёт, списки, архивирование)
# --------------------------------------------------------------------
# Назначение (коротко, 1–3 строки):
# • Операции с «солнечными панелями» пользователя:
#   активация за EFHC, учёт
# активных
# и архивных панелей, сводка для UI, архивирование просроченных.
#
# Канон/инварианты (строго):
# • Цена панели фиксирована: 100 EFHC.
# • Строгий порядок списания: СНАЧАЛА бонусный баланс, затем основной (1
# операция — 2 дебета).
# • Пользователь НИКОГДА не уходит в минус: при дефиците —
# отказ.
# • Банк EFHC может быть в минусе — операции НЕ блокируем (это не зона
# ответственности сервиса).
# • Генерация энергии везде посекундная (SSOT per-sec ставки).
# Ставка VIP определяется наличием NFT.
# Панели хранят базовую ставку на момент
# создания,
# но фактические начисления делает energy_service по текущему статусу
# VIP.
# • Лимит активных панелей на пользователя: MAX_PANELS.
# • Срок жизни панели: 180 дней; по окончании — перевод в архив
# (is_active=false).
# • Все денежные движения только через единый банковский сервис
# (transactions_service).
#
# ИИ-защиты/самовосстановление:
# • Блокировки на уровне SQL (FOR UPDATE) сериализуют денежные гонки за
# один и тот же global_id.
# • Read-through идемпотентность делается в банковском сервисе по
# idempotency_key.
# • Активация панели атомарна: списание EFHC, создание panel records,
# first-panel referral activation and rewards execute in one
# bank._tx_context; при ошибке всё откатывается вместе.
# • Для массовой активации qty>1 —
#   детерминированные ключи идемпотентности
# (suffix #1, #2, ...).
#
# Запреты:
# • Никаких P2P-переводов. Никаких EFHC→kWh. Никаких суточных расчётов.
# • Никаких прямых правок балансов — только через transactions_service.
# =====================================================================

# SSOT: p.expires_at > :server_now_utc
# SSOT: p.expires_at <= :server_now_utc
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.system_locks import (
    get_rate_base_d8,
    get_rate_vip_d8,
)
from app.deps import (
    d8,
    decode_cursor,
    encode_cursor,
)
from app.identity.financial_write_switch import (
    resolve_and_lock_financial_write_owner,
)
from app.lib.time import utcnow
from app.models.panels_models import Panel
from app.services import referral_service
from app.services import transactions_service as bank
from sqlalchemy import desc, func, select, text, tuple_
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


settings = get_settings()

# Константы канона (источник истины — Settings + SSOT helpers)
GEN_PER_SEC_BASE_KWH: Decimal = get_rate_base_d8()
GEN_PER_SEC_VIP_KWH: Decimal = get_rate_vip_d8()
# Канон EFHC: активация панели всегда 100 EFHC.
PANEL_PRICE: Decimal = d8("100")
MAX_PANELS: int = int(getattr(settings, "MAX_PANELS", 1000) or 1000)
PANEL_LIFETIME_DAYS: int = int(
    getattr(settings, "PANEL_LIFETIME_DAYS", 180) or 180
)

# --------------------------------------------------------------------
# Исключения домена (понятные коду роутов)
# --------------------------------------------------------------------


class PanelPurchaseError(Exception):
    """Общая ошибка активации панели (детали в сообщении)."""


class UserInDebtError(PanelPurchaseError):
    """Исторический минус: активации за EFHC заблокированы."""


class PanelLimitExceeded(PanelPurchaseError):
    """Превышен лимит активных панелей."""


class IdempotencyRequiredError(PanelPurchaseError):
    """Для денежных операций обязателен idempotency_key."""


class PanelReplayMissingDataError(PanelPurchaseError):
    """Replay-операция без данных о созданных панелях."""


# --------------------------------------------------------------------
# DTO для ответов сервиса
# --------------------------------------------------------------------
@dataclass
class PurchaseResult:
    ok: bool
    qty: int
    total_spent_bonus: Decimal
    total_spent_main: Decimal
    created_panel_ids: list[int]
    detail: str


@dataclass
class PanelsSummary:
    active_count: int
    total_generated_by_panels: Decimal
    nearest_expire_at: datetime | None


@dataclass
class PagedPanels:
    items: list[dict[str, Any]]
    next_cursor: str | None


# --------------------------------------------------------------------
# Внутренние утилиты
# --------------------------------------------------------------------
async def _lock_user_row(
    db: AsyncSession,
    *,
    global_id: int,
) -> dict[str, Any] | None:
    """Lock the canonical account row for panel mutation."""
    row = await db.execute(
        text(
            """
            SELECT id, global_id, tg_id, is_vip,
                   main_balance, bonus_balance,
                   total_generated_kwh, available_kwh
              FROM efhc_core.users
             WHERE global_id = :global_id
             FOR UPDATE
            """
        ),
        {"global_id": int(global_id)},
    )
    rec = row.fetchone()
    if not rec:
        return None
    return {
        "id": int(rec[0]),
        "global_id": int(rec[1]),
        "tg_id": (int(rec[2]) if rec[2] is not None else None),
        "is_vip": bool(rec[3]),
        "main_balance": d8(rec[4]),
        "bonus_balance": d8(rec[5]),
        "total_generated_kwh": d8(rec[6]),
        "available_kwh": d8(rec[7]),
    }



async def _get_active_panels_count(
    db: AsyncSession, global_id: int
) -> int:
    """Return active panel count for canonical owner."""
    now_utc = utcnow()
    r = await db.execute(
        text(
            """
            SELECT COUNT(*)
            FROM efhc_core.panels
            WHERE global_id = :global_id
              AND expires_at > :now_utc
            """
        ),
        {"global_id": int(global_id), "now_utc": now_utc},
    )
    return int(r.scalar() or 0)



async def _create_panel_record(
    db: AsyncSession,
    *,
    global_id: int,
    tg_id: int | None,
) -> int:
    """Create one panel with canonical owner dual-write."""
    ids = await _create_panel_records_bulk(
        db, global_id=global_id, tg_id=tg_id, qty=1
    )
    return int(ids[0]) if ids else 0



async def _fill_public_id(db: AsyncSession, *, panel_id: int) -> str:
    """Заполняет public_id = ID######## на основе PK.

    Канон: при INSERT public_id хранится как NULL,
    затем UPDATE выполняется в той же транзакции.
    """
    public_id = f"ID{int(panel_id):08d}"
    await db.execute(
        text(
            """
            UPDATE efhc_core.panels
            SET public_id = :public_id
            WHERE id = :id
            """
        ),
        {"public_id": public_id, "id": int(panel_id)},
    )
    return public_id


async def _create_panel_records_bulk(
    db: AsyncSession,
    *,
    global_id: int,
    tg_id: int | None,
    qty: int,
) -> list[int]:
    """Create panels in one statement under canonical ownership."""
    if qty <= 0:
        return []
    now = utcnow()
    expires_at = now + timedelta(days=PANEL_LIFETIME_DAYS)
    q = text(
        """
        INSERT INTO efhc_core.panels
          (
            tg_id, global_id, public_id, activated_at, created_at,
            expires_at, last_generated_at, base_gen_per_sec,
            generated_kwh, is_active, is_archived, archived_at
          )
        SELECT
          :tg_id, :global_id, NULL, :activated_at, :created,
          :expires, :last_gen, :base_rate, 0, TRUE, FALSE, NULL
        FROM generate_series(1, :qty)
        RETURNING id
        """
    )
    r = await db.execute(
        q,
        {
            "tg_id": (int(tg_id) if tg_id is not None else None),
            "global_id": int(global_id),
            "activated_at": now,
            "created": now,
            "expires": expires_at,
            "last_gen": now,
            "base_rate": str(GEN_PER_SEC_BASE_KWH),
            "qty": int(qty),
        },
    )
    ids = [int(x[0]) for x in r.fetchall()]
    for panel_id in ids:
        await _fill_public_id(db, panel_id=panel_id)
    return ids



def _json_to_dict(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except Exception:
            return {}
        if isinstance(parsed, dict):
            return dict(parsed)
        return {}
    return {}


async def _get_activation_payload_by_idk(
    db: AsyncSession,
    *,
    idempotency_key: str,
) -> dict[str, Any]:
    """Возвращает merged meta по :main и :bonus ключам списания.

    Guard: all-bonus panel activation creates only the
    ``:bonus`` spend log. Replay must therefore read both derived keys,
    otherwise it may miss existing panel ids and create duplicate panels
    without a new debit.
    """
    main_key = f"{idempotency_key}:main"
    bonus_key = f"{idempotency_key}:bonus"
    merged: dict[str, Any] = {}
    for key in (main_key, bonus_key):
        r = await db.execute(
            text(
                """
                SELECT meta
                FROM efhc_core.efhc_transfers_log
                WHERE idempotency_key = :idk
                LIMIT 1
                """
            ),
            {"idk": key},
        )
        row = r.fetchone()
        if row:
            merged.update(_json_to_dict(row[0]))
    return merged


async def _merge_activation_payload(
    db: AsyncSession,
    *,
    idempotency_key: str,
    patch: dict[str, Any],
) -> None:
    """Мержит extra_info в журнале активации панели.

    Делается диалект-safe: читаем → мержим → пишем.
    """
    main_key = f"{idempotency_key}:main"
    bonus_key = f"{idempotency_key}:bonus"
    prev = await _get_activation_payload_by_idk(
        db,
        idempotency_key=idempotency_key,
    )
    merged = dict(prev)
    merged.update(dict(patch))
    payload = json.dumps(merged, ensure_ascii=False)
    # Канон: любые правки efhc_transfers_log — только через
    # transactions_service.
    patch_dict = json.loads(payload) if payload else {}
    for idk in (bonus_key, main_key):
        await bank.append_transfer_meta_by_idempotency_key(
            db,
            idempotency_key=str(idk),
            meta=dict(patch_dict),
        )


# --------------------------------------------------------------------
# Публичные функции сервиса
# --------------------------------------------------------------------
async def activate_panel(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    qty: int = 1,
    idempotency_key: str | None = None,
) -> PurchaseResult:
    """Activate panels atomically for canonical ``global_id`` owner."""
    if not idempotency_key or not idempotency_key.strip():
        raise IdempotencyRequiredError(
            "Idempotency-Key is required by canon for "
            "monetary operations."
        )
    if qty <= 0:
        raise PanelPurchaseError("Количество панелей должно быть >= 1.")

    total_amount = d8(PANEL_PRICE) * d8(qty)
    created_ids: list[int] = []
    created_public_ids: list[str] = []
    status = "success"
    breakdown = bank.SpendBreakdown(
        bonus_part=d8("0"), main_part=d8("0")
    )

    try:
        async with bank._tx_context(db):
            owner = await resolve_and_lock_financial_write_owner(
                db, global_id=global_id, tg_id=tg_id
            )
            user = await _lock_user_row(
                db, global_id=owner.global_id
            )
            if not user:
                raise PanelPurchaseError("Пользователь не найден.")
            bonus_before = d8(user["bonus_balance"])
            main_before = d8(user["main_balance"])

            debit_result = await (
                bank.spend_user_to_bank_bonus_then__main__nocommit
            )(
                db,
                global_id=owner.global_id,
                amount=d8(total_amount),
                reason="panel_activation",
                idempotency_key=str(idempotency_key),
                meta={
                    "module": "panels_service",
                    "owner_global_id": str(owner.global_id),
                    "qty": int(qty),
                    "price_per_panel": str(d8(PANEL_PRICE)),
                    "panel_activation_atomicity": "true",
                },
            )

            current_active = await _get_active_panels_count(
                db, owner.global_id
            )
            if debit_result.detail == "idempotent":
                status = "replay"
                payload = await _get_activation_payload_by_idk(
                    db, idempotency_key=str(idempotency_key)
                )
                ids = payload.get("panels_created_ids")
                pubs = payload.get("panels_public_ids")
                if not (
                    isinstance(ids, list)
                    and all(isinstance(value, int) for value in ids)
                ):
                    raise PanelReplayMissingDataError(
                        "Panel replay is missing created panel ids."
                    )
                payload_global_id = int(
                    payload.get("global_id") or owner.global_id
                )
                payload_qty = int(payload.get("qty") or len(ids))
                if (
                    payload_global_id != owner.global_id
                    or payload_qty != int(qty)
                ):
                    raise PanelPurchaseError(
                        "Idempotency-Key belongs to another panel "
                        "activation request."
                    )
                created_ids = [int(value) for value in ids]
                if isinstance(pubs, list) and all(
                    isinstance(value, str) for value in pubs
                ):
                    created_public_ids = [str(value) for value in pubs]
                breakdown = bank.SpendBreakdown(
                    bonus_part=d8(payload.get("spent_bonus") or "0"),
                    main_part=d8(payload.get("spent_main") or "0"),
                )
            else:
                total_user = d8(main_before + bonus_before)
                if total_user < d8("0"):
                    raise UserInDebtError(
                        "У пользователя отрицательный баланс: "
                        "активации за EFHC запрещены до выхода в 0."
                    )
                if current_active + qty > MAX_PANELS:
                    raise PanelLimitExceeded(
                        f"Лимит активных панелей {MAX_PANELS} "
                        "будет превышен."
                    )
                breakdown = bank.split_bonus_then_main(
                    bonus_balance=bonus_before,
                    main_balance=main_before,
                    amount=d8(total_amount),
                )

            if not created_ids:
                created_ids = await _create_panel_records_bulk(
                    db,
                    global_id=owner.global_id,
                    tg_id=owner.legacy_tg_id,
                    qty=int(qty),
                )
                created_public_ids = [
                    f"ID{int(panel_id):08d}" for panel_id in created_ids
                ]
                if current_active == 0:
                    on_first = (
                        referral_service.on_user_first_panel_activation
                    )
                    await on_first(
                        db,
                        buyer_tg_id=owner.legacy_tg_id,
                        buyer_global_id=owner.global_id,
                    )

            await _merge_activation_payload(
                db,
                idempotency_key=str(idempotency_key),
                patch={
                    "audit__schema__version": "v2-global-owner",
                    "op_type": "PANEL_CREATE",
                    "global_id": owner.global_id,
                    "tg_id": owner.legacy_tg_id,
                    "idempotency_key": str(idempotency_key),
                    "status": status,
                    "qty": int(qty),
                    "price_per_panel": str(d8(PANEL_PRICE)),
                    "total_amount": str(d8(total_amount)),
                    "spent_bonus": str(d8(breakdown.bonus_part)),
                    "spent_main": str(d8(breakdown.main_part)),
                    "bonus_first": True,
                    "panels_created_ids": created_ids,
                    "panels_public_ids": created_public_ids,
                    "panel_activation_atomicity": "true",
                },
            )
    except ValueError as exc:
        logger.warning(
            "panel activation denied global_id=%s tg_id=%s: %s",
            global_id,
            tg_id,
            exc,
        )
        raise PanelPurchaseError(
            "Недостаточно EFHC для активации панелей без ухода в минус."
        ) from exc
    except PanelPurchaseError:
        raise
    except Exception as exc:
        logger.exception(
            "panel activation failed global_id=%s tg_id=%s: %s",
            global_id,
            tg_id,
            exc,
        )
        raise PanelPurchaseError(
            f"Ошибка создания панелей: {exc}"
        ) from exc

    return PurchaseResult(
        ok=True,
        qty=qty,
        total_spent_bonus=d8(breakdown.bonus_part),
        total_spent_main=d8(breakdown.main_part),
        created_panel_ids=created_ids,
        detail="Панели успешно активированы.",
    )



async def create_panel_for_user(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    idempotency_key: str,
) -> dict[str, Any]:
    """Create one idempotent panel for canonical owner."""
    result = await activate_panel(
        db,
        tg_id=tg_id,
        global_id=global_id,
        qty=1,
        idempotency_key=str(idempotency_key),
    )
    if not result.created_panel_ids:
        raise PanelReplayMissingDataError("Missing created panel id")
    pid = int(result.created_panel_ids[0])
    return {"id": pid, "public_id": f"ID{pid:08d}"}



async def archive_panel_for_user(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    panel_id: int,
) -> None:
    """Archive one panel owned by canonical account."""
    owner = await resolve_and_lock_financial_write_owner(
        db, global_id=global_id, tg_id=tg_id
    )
    await db.execute(
        text(
            """
            UPDATE efhc_core.panels
            SET is_archived = TRUE,
                is_active = FALSE,
                archived_at = :now
            WHERE id = :panel_id
              AND global_id = :global_id
            """
        ),
        {
            "panel_id": int(panel_id),
            "global_id": owner.global_id,
            "now": utcnow(),
        },
    )



# --------------------------------------------------------------------
# Витрины/списки для UI (курсорная пагинация)
# --------------------------------------------------------------------
async def list_active_panels(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    limit: int = 25,
    cursor: str | None = None,
) -> PagedPanels:
    """Список активных панелей по выбранному owner contract."""
    return await list_user_panels(
        db,
        tg_id=tg_id,
        global_id=global_id,
        kind="active",
        limit=int(limit),
        cursor=cursor,
    )


async def list_user_panels(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    kind: str,
    limit: int = 25,
    cursor: str | None = None,
) -> PagedPanels:
    """SSOT: список панелей пользователя (active/archive).

    Фильтрация определяется server_now_utc, а не now() БД.
    """
    limit = max(1, min(100, int(limit)))
    server_now_utc = utcnow()

    if hasattr(kind, "value"):
        kind = kind.value  # type: ignore
    kind = (kind or "").strip().lower()
    if kind not in ("active", "archive"):
        raise ValueError("Invalid kind")

    act_at = func.coalesce(Panel.activated_at, Panel.created_at)

    if global_id is not None:
        owner_filter = Panel.global_id == int(global_id)
    elif tg_id is not None:
        owner_filter = Panel.tg_id == int(tg_id)
    else:
        raise ValueError("Panel owner is required")

    stmt = select(
        Panel.id,
        Panel.public_id,
        act_at.label("act_at"),
        Panel.expires_at,
        Panel.base_gen_per_sec,
        Panel.generated_kwh,
        Panel.archived_at,
    ).where(owner_filter)

    if kind == "active":
        stmt = stmt.where(Panel.expires_at > server_now_utc)
    else:
        stmt = stmt.where(Panel.expires_at <= server_now_utc)

    if cursor:
        payload = decode_cursor(cursor)
        created_at_iso = payload.get("ts")
        last_id = int(payload.get("id") or 0)

        c_at = None
        if isinstance(created_at_iso, str) and created_at_iso:
            try:
                c_at = datetime.fromisoformat(created_at_iso)
            except Exception:
                c_at = None

        if c_at is not None and last_id > 0:
            stmt = stmt.where(
                tuple_(act_at, Panel.id) < (c_at, int(last_id))
            )

    stmt = stmt.order_by(desc(act_at), desc(Panel.id)).limit(
        int(limit) + 1
    )

    res = await db.execute(stmt)
    rows = res.fetchall()

    items: list[dict[str, Any]] = []
    next_cursor: str | None = None

    for row in rows[: int(limit)]:
        items.append(
            {
                "id": int(row.id),
                "public_id": str(row.public_id),
                "activated_at": _as_iso(row.act_at),
                "created_at": _as_iso(row.act_at),
                "expires_at": _as_iso(row.expires_at),
                "archived_at": _as_iso(row.archived_at),
                "remaining_seconds": _remaining_seconds(
                    row.expires_at,
                    server_now_utc,
                ),
                "base_gen_per_sec": d8(row.base_gen_per_sec),
                "generated_kwh": d8(row.generated_kwh),
                "is_active": bool(row.expires_at > server_now_utc),
            }
        )

    if len(rows) > int(limit):
        last = rows[int(limit) - 1]
        next_cursor = encode_cursor(
            {"ts": _as_iso(last.act_at) or "", "id": int(last.id)}
        )

    return PagedPanels(items=items, next_cursor=next_cursor)


async def list_archived_panels(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    limit: int = 25,
    cursor: str | None = None,
) -> PagedPanels:
    """Список архивных панелей по выбранному owner contract."""
    return await list_user_panels(
        db,
        tg_id=tg_id,
        global_id=global_id,
        kind="archive",
        limit=int(limit),
        cursor=cursor,
    )


async def panels_summary(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
) -> PanelsSummary:
    """
    Короткая сводка для экрана Panels:
      • active_count — число активных панелей
      • total_generated_by_panels — суммарная генерация по полю панелей
      • nearest_expire_at — ближайшая дата истечения активной панели
    """
    now_utc = utcnow()
    r = await db.execute(
        text(
            """
            SELECT
              COUNT(*) FILTER (
                WHERE expires_at > :now_utc
              ) AS active_count,
              COALESCE(
                SUM(generated_kwh),
                0
              ) AS total_generated_by_panels,
              MIN(expires_at) FILTER (WHERE expires_at > :now_utc)
                AS nearest_expire_at
            FROM efhc_core.panels
            WHERE (
              (:global_id IS NOT NULL AND global_id = :global_id)
              OR (:global_id IS NULL AND tg_id = :tg_id)
            )
            """
        ),
        {
            "tg_id": int(tg_id) if tg_id is not None else None,
            "global_id": (
                int(global_id) if global_id is not None else None
            ),
            "now_utc": now_utc,
        },
    )
    row = r.fetchone()
    if row is None:
        return PanelsSummary(
            active_count=0,
            total_generated_by_panels=d8(0),
            nearest_expire_at=None,
        )
    return PanelsSummary(
        active_count=int(row[0] or 0),
        total_generated_by_panels=d8(row[1] or 0),
        nearest_expire_at=row[2],
    )


# --------------------------------------------------------------------
# Архивирование просроченных панелей (для планировщика)
# --------------------------------------------------------------------
async def archive_expired_panels(
    db: AsyncSession,
    *,
    limit: int = 1000,
) -> int:
    """
    Переводит просроченные панели в архив (is_active=false).
    Проставляет archived_at.
    Возвращает количество переведённых записей.

    Реализация через CTE + RETURNING.
      • выбираем порцию id под блокировку (SKIP LOCKED),
      • обновляем только эти записи,
      • считаем количество по числу возвращённых строк.
    """
    now = utcnow()
    r = await db.execute(
        text(
            """
            WITH cte AS (
                SELECT id
                FROM efhc_core.panels
                WHERE is_active = TRUE
                  AND expires_at <= :now
                ORDER BY id
                LIMIT :lim
                FOR UPDATE SKIP LOCKED
            )
            UPDATE efhc_core.panels AS p
               SET is_active = FALSE,
                   archived_at = :now
            FROM cte
            WHERE p.id = cte.id
            RETURNING p.id
            """
        ),
        {"now": now, "lim": int(limit)},
    )
    rows = r.fetchall()
    return len(rows)


# --------------------------------------------------------------------
# Вспомогательные
# --------------------------------------------------------------------


def _as_iso(dt: datetime | None) -> str | None:
    """ISO-строка в UTC (или None)."""
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC).isoformat()


def _remaining_seconds(
    expires_at: datetime | None,
    server_now_utc: datetime,
) -> int | None:
    """Остаток секунд панели по серверному времени."""
    if not expires_at:
        return None
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=UTC)
    if server_now_utc.tzinfo is None:
        server_now_utc = server_now_utc.replace(tzinfo=UTC)
    delta = expires_at.astimezone(UTC) - server_now_utc.astimezone(UTC)
    return max(0, int(delta.total_seconds()))


# =====================================================================
# Экспорт для import *
# =====================================================================
__all__ = [
    # исключения
    "PanelPurchaseError",
    "UserInDebtError",
    "PanelLimitExceeded",
    "IdempotencyRequiredError",
    # DTO
    "PurchaseResult",
    "PanelsSummary",
    "PagedPanels",
    # public API
    "activate_panel",
    "list_active_panels",
    "list_archived_panels",
    "panels_summary",
    "archive_expired_panels",
]

# =====================================================================
# Пояснения:
# • Почему списание «бонус→основной»? Канон: бонусы тратятся первыми.
#   Их номинал возвращается в Банк, чтобы не создавать скрытую эмиссию.
# • Почему панели хранят base_gen_per_sec?
#   Чтобы не зашивать VIP в запись.
#   За VIP отвечает energy_service.
# • Почему блокируем активации при историческом минусе?
#   Канон безопасности:
#   пользователь должен выйти из минуса сам (пополнение/обмен kWh→EFHC).
# • Почему суффиксы в idempotency_key "#i"? Чтобы qty>1 можно было
#   безопасно переисполнять без дублей при сетевых сбоях.
# • Почему курсоры? Курсорная пагинация стабильнее и дешевле OFFSET.
# =====================================================================
