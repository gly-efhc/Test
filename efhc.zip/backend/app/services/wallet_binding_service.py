"""Wallet binding service.

Purpose:
- Start a bind request (nonce + memo instruction).
- Finalize bind by an on-chain transfer memo: BIND:{tg_id}:{nonce}.
- Support rebind (old inactive, new active) and admin block/unblock.

Canonical rules:
- User identifier is tg_id only.
- Best-effort code must not use silent-pass; log and keep behavior.
"""

from __future__ import annotations

import secrets
import string
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

# ----------------------------------------------------------------------
# Настройки и логгер
# ----------------------------------------------------------------------
settings = get_settings()
logger = get_logger(__name__)

CORE_SCHEMA: str = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")
# Каноническое название кошелька проекта в настройках — TON_MAIN_WALLET
MAIN_TON_WALLET: str = getattr(settings, "TON_MAIN_WALLET", "") or ""

if not MAIN_TON_WALLET:
    logger.warning(
        "[WALLET_BIND] TON_MAIN_WALLET не задан в конфигурации. "
        "BIND-транзакции работать не будут."
    )

# Управление политикой привязок:
MAX_WALLETS_PER_USER: int = int(
    getattr(settings, "MAX_WALLETS_PER_USER", 1) or 1
)
BIND_REQUEST_TTL_MIN: int = int(
    getattr(settings, "BIND_REQUEST_TTL_MIN", 15) or 15
)

# Формат челленджа в MEMO on-chain перевода:
# BIND:{tg_id}:{nonce}
BIND_MEMO_PREFIX = "BIND"


def _now_utc() -> datetime:
    """Return current UTC time for this service."""
    return datetime.now(UTC)

# ----------------------------------------------------------------------
# Ошибки предметной области (понятные вызывающему коду)
# ----------------------------------------------------------------------


class WalletError(Exception):
    """Базовая ошибка привязки кошелька."""


class AddressInUse(WalletError):
    """Адрес уже привязан к другому пользователю или заблокирован."""


class ActiveWalletLimit(WalletError):
    """Превышен лимит активных кошельков для пользователя."""


class NoPendingRequest(WalletError):
    """Нет ожидающей заявки на привязку.

    Причины: nonce не найден, просрочен или уже закрыт.
    """


class AddressMismatch(WalletError):
    """Отправитель транзакции не совпадает с candidate_addr заявки."""


class AlreadyBound(WalletError):
    """У пользователя уже активен этот адрес."""


# ----------------------------------------------------------------------
# DTO для ответов сервиса (удобно возвращать наружу)
# ----------------------------------------------------------------------
@dataclass(slots=True)
class BindStartResult:
    tg_id: int
    candidate_addr: str
    nonce: str
    memo: str
    to_wallet: str
    expires_at: datetime


@dataclass(slots=True)
class WalletState:
    tg_id: int
    active_address: str | None
    is_blocked: bool
    bind_pending: bool
    bind_nonce: str | None


# ======================================================================
# Публичный API
# ======================================================================
async def start_bind_request(
    db: AsyncSession,
    *,
    tg_id: int,
    candidate_addr: str,
) -> BindStartResult:
    """Start wallet bind request (nonce + memo instruction)."""
    candidate_addr = _norm_addr(candidate_addr)

    # 0) Базовые проверки конфигурации
    if not MAIN_TON_WALLET:
        raise WalletError(
            "TON_MAIN_WALLET не настроен на сервере, "
            "привязка невозможна."
        )

    # 1) Запретить присвоение адреса, если он занят другим
    # пользователем/заблокирован
    owner = await _find_wallet_owner(db, candidate_addr)
    if owner and owner != tg_id:
        raise AddressInUse(
            "Этот адрес уже привязан к другому пользователю."
        )
    if await _is_wallet_blocked(db, candidate_addr):
        raise AddressInUse(
            "Этот адрес заблокирован и не может быть привязан."
        )

    # 2) Если у пользователя уже активен именно этот адрес — нет смысла
    # начинать
    active_addr = await _get_active_wallet(db, tg_id)
    if active_addr and _norm_addr(active_addr) == candidate_addr:
        raise AlreadyBound("Этот кошелёк уже активен у пользователя.")

    # 3) Проверяем лимит активных кошельков (по умолчанию 1)
    active_count = await _count_active_wallets(db, tg_id)
    if active_count >= MAX_WALLETS_PER_USER:
        raise ActiveWalletLimit(
            f"Превышен лимит активных кошельков "
            f"({MAX_WALLETS_PER_USER}). "
            "Сначала отключите текущий, затем привяжите новый."
        )

    # 4) Снимаем старые pending-заявки пользователя (очистка)
    await db.execute(text(f"""
            UPDATE {CORE_SCHEMA}.wallet_bind_requests
               SET status = 'canceled', updated_at = now()
             WHERE tg_id = :tg_id AND status = 'pending'
            """),
        {"tg_id": tg_id},)

    # 5) Создаём новую заявку с nonce и временем жизни
    nonce = _gen_nonce()
    expires_at = _now_utc() + timedelta(minutes=BIND_REQUEST_TTL_MIN)

    await db.execute(text(f"""
            INSERT INTO {CORE_SCHEMA}.wallet_bind_requests
                (tg_id, candidate_addr, nonce, status, expires_at)
            VALUES (:tg_id, :addr, :nonce, 'pending', :exp)
            """),
        {
            "tg_id": tg_id,
            "addr": candidate_addr,
            "nonce": nonce,
            "exp": expires_at,
        },
    )
    await db.commit()

    memo = f"{BIND_MEMO_PREFIX}:{tg_id}:{nonce}"

    return BindStartResult(
        tg_id=tg_id,
        candidate_addr=candidate_addr,
        nonce=nonce,
        memo=memo,
        to_wallet=MAIN_TON_WALLET,
        expires_at=expires_at,
    )


async def finalize_bind_by_tx(
    db: AsyncSession,
    *,
    tg_id: int,
    from_address: str,
    memo: str,
    tx_hash: str,
) -> str:
    """Finalize bind by on-chain memo BIND:{tg_id}:{nonce}."""
    if not MAIN_TON_WALLET:
        logger.warning(
            "[WALLET_BIND] finalize_bind_by_tx вызван без "
            "настроенного TON_MAIN_WALLET"
        )
        return "error:config"

    parsed = _parse_bind_memo(memo)
    if not parsed or parsed[0] != tg_id:
        # не наш memo — мягкий skip
        return "skip:not_our_memo"

    _, nonce = parsed
    from_address = _norm_addr(from_address)

    try:
        await db.begin()

        # 1) Находим заявку и блокируем её
        req = await _get_request_for_update(db, tg_id, nonce)
        if not req:
            # заявки нет вообще → либо протухла, либо удалена
            await db.rollback()
            raise NoPendingRequest("Нет заявки с таким nonce.")

        req_id = req["id"]
        candidate_addr = _norm_addr(req["candidate_addr"])
        status = req["status"]
        expires_at = req["expires_at"]
        prev_tx_hash = req["tx_hash"]

        # 2) Проверяем TTL
        if expires_at and expires_at < _now_utc():
            # протухла → помечаем expired (если ещё не помечена)
            if status == "pending":
                await db.execute(text(f"""
                        UPDATE {CORE_SCHEMA}.wallet_bind_requests
                           SET status = 'expired', updated_at = now()
                         WHERE id = :rid AND status = 'pending'
                        """),
                    {"rid": req_id},)
            await db.commit()
            raise NoPendingRequest("Заявка на привязку истекла.")

        # 3) Идемпотентность по статусу заявки
        if status == "confirmed":
            # если тот же tx_hash → безопасный replay
            if prev_tx_hash and prev_tx_hash == tx_hash:
                await db.commit()
                return "ok_replay"
            await db.commit()
            return "skip:already_confirmed"
        if status in ("expired", "canceled"):
            await db.commit()
            raise NoPendingRequest(
                f"Заявка уже имеет статус '{status}'."
            )

        # 4) Статус pending → проверяем совпадение адресов
        if candidate_addr != from_address:
            await db.rollback()
            raise AddressMismatch(
                "Адрес отправителя не совпадает с заявкой."
            )

        # 5) Если лимит активных кошельков = 1,
        # выключаем предыдущий активный
        if MAX_WALLETS_PER_USER == 1:
            await db.execute(text(f"""
                    UPDATE {CORE_SCHEMA}.user_wallets
                       SET is_active = false,
                           is_primary = false,
                           updated_at = now()
                     WHERE tg_id = :tg_id AND is_active IS TRUE
                    """),
                {"tg_id": tg_id},)

        # 6) Активируем/создаём запись в user_wallets
        existing = await db.execute(text(f"""
                SELECT id, is_blocked
                  FROM {CORE_SCHEMA}.user_wallets
                 WHERE ton_address = :addr
                 LIMIT 1
                """),
            {"addr": from_address},)
        row = existing.fetchone()
        if row:
            if bool(row[1]):
                await db.rollback()
                raise AddressInUse(
                    "Этот адрес заблокирован и не может быть "
                    "активирован."
                )
            await db.execute(text(f"""
                    UPDATE {CORE_SCHEMA}.user_wallets
                       SET tg_id = :tg_id,
                           is_active = true,
                           is_primary = true,
                           updated_at = now()
                     WHERE ton_address = :addr
                    """),
                {"tg_id": tg_id, "addr": from_address},)
        else:
            await db.execute(text(f"""
                    INSERT INTO {CORE_SCHEMA}.user_wallets
                        (
                            tg_id,
                            ton_address,
                            is_active,
                            is_blocked,
                            is_primary,
                        )
                    VALUES (:tg_id, :addr, true, false, true)
                    """),
                {"tg_id": tg_id, "addr": from_address},)

        # 7) Закрываем заявку
        await db.execute(text(f"""
                UPDATE {CORE_SCHEMA}.wallet_bind_requests
                   SET status = 'confirmed',
                       tx_hash = :tx,
                       updated_at = now()
                 WHERE id = :rid AND status = 'pending'
                """),
            {"rid": req_id, "tx": tx_hash},)

        await db.commit()
        logger.info(
            "[WALLET_BIND] user=%s bound wallet=%s via tx=%s",
            tg_id,
            from_address,
            tx_hash
        )
        return "ok"
    except Exception:
        try:
            await db.rollback()
        except Exception:
            logger.debug(
                "[WALLET_BIND] rollback failed",
                exc_info=True,
            )
        raise


async def block_active_wallet(db: AsyncSession,
    *,
    tg_id: int,
    reason: str = "",) -> str | None:
    """Block active wallet for user, return blocked address."""
    row = await db.execute(text(f"""
            SELECT ton_address
              FROM {CORE_SCHEMA}.user_wallets
             WHERE tg_id = :tg_id AND is_active IS TRUE
             LIMIT 1
            """),
        {"tg_id": tg_id},)
    r = row.fetchone()
    if not r:
        return None
    addr = _norm_addr(r[0])

    await db.execute(text(f"""
            UPDATE {CORE_SCHEMA}.user_wallets
               SET is_active = false,
                   is_blocked = true,
                   is_primary = false,
                   updated_at = now()
             WHERE tg_id = :tg_id AND ton_address = :addr
            """),
        {"tg_id": tg_id, "addr": addr},)
    await db.commit()
    logger.info(
        "[WALLET_BIND] blocked addr=%s for user=%s; reason=%s",
        addr,
        tg_id,
        reason
    )
    # (при необходимости можно писать в отдельную log-таблицу
    # причин блокировок)
    return addr


async def unblock_wallet(db: AsyncSession,
    *,
    address: str,) -> bool:
    """
    Разблокировка кошелька (is_blocked=false). Не активирует его.
    Возвращает True, если статус изменён.
    """
    addr = _norm_addr(address)
    res = await db.execute(text(f"""
            UPDATE {CORE_SCHEMA}.user_wallets
               SET is_blocked = false, updated_at = now()
             WHERE ton_address = :addr AND is_blocked IS TRUE
            """),
        {"addr": addr},)
    await db.commit()
    return res.rowcount > 0


async def get_wallet_state(
    db: AsyncSession,
    *,
    tg_id: int,
) -> WalletState:
    """
    Возвращает текущее состояние кошелька пользователя:
      • active_address — активный адрес (или None),
      • is_blocked     — если активный есть, заблокирован ли он,
      • bind_pending   — есть ли незавершённая заявка,
      • bind_nonce     — nonce последней 'pending' заявки (если есть).
    """
    active = await db.execute(text(f"""
            SELECT ton_address, is_blocked
              FROM {CORE_SCHEMA}.user_wallets
             WHERE tg_id = :tg_id AND is_active IS TRUE
             LIMIT 1
            """),
        {"tg_id": tg_id},)
    r = active.fetchone()
    active_addr = _norm_addr(r[0]) if r else None
    is_blocked = bool(r[1]) if r else False

    pending = await db.execute(text(f"""
            SELECT nonce
              FROM {CORE_SCHEMA}.wallet_bind_requests
             WHERE tg_id = :tg_id AND status = 'pending'
             ORDER BY created_at DESC
             LIMIT 1
            """),
        {"tg_id": tg_id},)
    p = pending.fetchone()
    return WalletState(tg_id = tg_id,
        active_address = active_addr,
        is_blocked = is_blocked,
        bind_pending = bool(p),
        bind_nonce = str(p[0]) if p else None,)


# ======================================================================
# Вспомогательные функции
# ======================================================================


def _norm_addr(addr: str) -> str:
    """Простейшая нормализация TON - адреса: убираем пробелы."""
    return (addr or "").replace(" ", "")


def _gen_nonce(length: int = 12) -> str:
    """Генерация безопасного одноразового кода для MEMO."""
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _parse_bind_memo(memo: str) -> tuple[int, str] | None:
    """
    Разбирает MEMO 'BIND:{tg_id}:{nonce}' → (tg_id, nonce) или None.
    """
    if not memo:
        return None
    parts = memo.strip().split(":")
    if len(parts) != 3:
        return None
    if parts[0].upper() != BIND_MEMO_PREFIX:
        return None
    try:
        tg_id = int(parts[1])
    except ValueError:
        return None
    nonce = parts[2]
    if not nonce or len(nonce) > 64:
        return None
    return (tg_id, nonce)

async def _find_wallet_owner(
    db: AsyncSession,
    address: str,
) -> int | None:
    """
    Возвращает tg_id владельца адреса из user_wallets (если есть).
    """
    addr = _norm_addr(address)
    row = await db.execute(text(f"""
            SELECT tg_id
              FROM {CORE_SCHEMA}.user_wallets
             WHERE ton_address = :addr
             LIMIT 1
            """),
        {"addr": addr},)
    r = row.fetchone()
    return int(r[0]) if r and r[0] is not None else None


async def _is_wallet_blocked(db: AsyncSession, address: str) -> bool:
    """
    True, если адрес помечен заблокированным (is_blocked=true).
    """
    addr = _norm_addr(address)
    row = await db.execute(text(f"""
            SELECT is_blocked
              FROM {CORE_SCHEMA}.user_wallets
             WHERE ton_address = :addr
             LIMIT 1
            """),
        {"addr": addr},)
    r = row.fetchone()
    return bool(r[0]) if r else False


async def _get_active_wallet(
    db: AsyncSession,
    tg_id: int,
) -> str | None:
    """
    Возвращает активный адрес пользователя (или None).
    """
    row = await db.execute(text(f"""
            SELECT ton_address
              FROM {CORE_SCHEMA}.user_wallets
             WHERE tg_id = :tg_id AND is_active IS TRUE
             LIMIT 1
            """),
        {"tg_id": tg_id},)
    r = row.fetchone()
    return _norm_addr(r[0]) if r else None


async def _count_active_wallets(db: AsyncSession, tg_id: int) -> int:
    """
    Считает активные кошельки пользователя.
    """
    row = await db.execute(text(f"""
            SELECT COUNT(*)
              FROM {CORE_SCHEMA}.user_wallets
             WHERE tg_id = :tg_id AND is_active IS TRUE
            """),
        {"tg_id": tg_id},)
    r = row.fetchone()
    return int(r[0]) if r and r[0] is not None else 0


async def _get_request_for_update(db: AsyncSession,
    tg_id: int,
    nonce: str,) -> dict[str, Any] | None:
    """
    Возвращает заявку по (tg_id, nonce) с блокировкой FOR UPDATE.

    ИИ-защита:
      • Если придут несколько транзакций с одним nonce,
        row-level lock не даст двум воркерам менять одну заявку.
    """
    row = await db.execute(text(f"""
            SELECT
                id,
                tg_id,
                candidate_addr,
                nonce,
                status,
                expires_at,
                tx_hash
              FROM {CORE_SCHEMA}.wallet_bind_requests
             WHERE tg_id = :tg_id AND nonce = :nonce
             ORDER BY created_at DESC
             FOR UPDATE
             LIMIT 1
            """),
        {"tg_id": tg_id, "nonce": nonce},)
    r = row.fetchone()
    if not r:
        return None
    return {
        "id": int(r[0]),
        "tg_id": int(r[1]),
        "candidate_addr": str(r[2]),
        "nonce": str(r[3]),
        "status": str(r[4]),
        "expires_at": r[5],
        "tx_hash": r[6],
    }

