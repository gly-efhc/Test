from __future__ import annotations

import re
from typing import Any

_OWNER = r"(?P<owner>G[0-9]{10}|[0-9]{1,20})"
_RE_INTENT_EXACT = re.compile(
    r"^EFHC:(?P<purpose>deposit_efhc|shop_external)"
    rf":(?P<intent_id>[0-9]{{1,20}}):{_OWNER}$"
)
_RE_INTENT_SUBSTR = re.compile(
    r"EFHC:(?P<purpose>deposit_efhc|shop_external)"
    rf":(?P<intent_id>[0-9]{{1,20}}):{_OWNER}"
)


def _result(match: re.Match[str], payload: str) -> dict[str, Any]:
    owner = str(match.group("owner"))
    result: dict[str, Any] = {
        "purpose": str(match.group("purpose")),
        "intent_id": int(match.group("intent_id")),
        "payload": payload,
    }
    if owner.startswith("G"):
        result["global_id"] = int(owner[1:])
        result["tg_id"] = None
    else:
        result["tg_id"] = int(owner)
        result["global_id"] = None
    return result


def parse_intent_payload(memo: str) -> dict[str, Any] | None:
    """Разобрать payload Telegram или канонического владельца."""
    memo = (memo or "").strip()
    exact = _RE_INTENT_EXACT.match(memo)
    if exact:
        return _result(exact, memo)
    partial = _RE_INTENT_SUBSTR.search(memo)
    if not partial:
        return None
    return _result(partial, str(partial.group(0)))
