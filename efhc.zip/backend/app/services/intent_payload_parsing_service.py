from __future__ import annotations

import re
from typing import Any

_RE_INTENT_EXACT = re.compile(
    r"^EFHC:(?P<purpose>deposit_efhc|shop_external)"
    r":(?P<intent_id>\d{1,20}):(?P<tg_id>\d{1,20})$"
)
_RE_INTENT_SUBSTR = re.compile(
    r"EFHC:(?P<purpose>deposit_efhc|shop_external)"
    r":(?P<intent_id>\d{1,20}):(?P<tg_id>\d{1,20})"
)


def parse_intent_payload(memo: str) -> dict[str, Any] | None:
    memo = (memo or "").strip()
    m = _RE_INTENT_EXACT.match(memo)
    if m:
        return {
            "purpose": str(m.group("purpose")),
            "intent_id": int(m.group("intent_id")),
            "tg_id": int(m.group("tg_id")),
            "payload": memo,
        }
    m2 = _RE_INTENT_SUBSTR.search(memo)
    if not m2:
        return None
    payload = str(m2.group(0))
    return {
        "purpose": str(m2.group("purpose")),
        "intent_id": int(m2.group("intent_id")),
        "tg_id": int(m2.group("tg_id")),
        "payload": payload,
    }
