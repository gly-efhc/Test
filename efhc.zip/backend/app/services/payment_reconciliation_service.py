from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from app.deps import d8
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .confirm__path__guards_service import (
    guard_amount_exact_d8,
    guard_asset_exact,
    guard_destination_exact,
)
from .shop_payment_tx_hash_lock_service import acquire_tx_hash_lock


@dataclass(frozen=True)
class ConfirmPaymentResult:
    status: str
    note: str | None = None


async def confirm_payment_intent(
    db: AsyncSession,
    *,
    intent_id: int,
    global_id: int,
    purpose: str,
    payload: str,
    tx_hash: str,
    amount_asset: Decimal,
    asset: str,
    to_address: str,
    status_credited: str,
    status_paid_auto: str,
    status_error_memo: str,
    status_error_sys: str,
    status_pending_manual: str,
    item_type_efhc_package: str,
    item_type_nft_vip: str,
    now_func: Callable[[], Any],
    credit_orig: Any,
    credit_user_from_bank_fn: Any,
    logger_obj: Any,
) -> ConfirmPaymentResult:
    q = text(
        "\n".join(
            [
                "SELECT * FROM efhc_core.payment_intents",
                " WHERE id = :iid",
                "   AND global_id = :tg",
                "   AND payload = :p",
                " FOR UPDATE",
            ]
        )
    )
    row = (
        (
            await db.execute(
                q,
                {
                    "iid": int(intent_id),
                    "tg": int(global_id),
                    "p": str(payload),
                },
            )
        )
        .mappings()
        .first()
    )
    if not row:
        return ConfirmPaymentResult(
            status_error_memo,
            "intent_not_found",
        )

    status_val = str(row.get("status") or "")
    existing_tx_hash = str(row.get("external_tx_hash") or "").strip()
    incoming_tx_hash = str(tx_hash or "").strip()
    if status_val == "CONFIRMED":
        if purpose == "deposit_efhc":
            if (
                existing_tx_hash
                and existing_tx_hash == incoming_tx_hash
            ):
                return ConfirmPaymentResult(status_credited, None)
            # Direct EFHC intent canon: a different on-chain tx_hash
            # for the same direct intent is a separate incoming
            # deposit. Do not silently drop it just because the intent
            # already has a previous confirmed tx.
            # intent already has a previous confirmed tx
        elif purpose == "shop_external":
            return ConfirmPaymentResult(status_paid_auto, None)
        else:
            return ConfirmPaymentResult(status_credited, None)

    asset_expected = str(row.get("asset") or "TON").upper()
    asset_guard = guard_asset_exact(
        asset=str(asset or "TON"),
        expected_asset=asset_expected,
    )
    if not asset_guard.ok:
        return ConfirmPaymentResult(
            status_error_sys,
            asset_guard.reason,
        )

    to_guard = guard_destination_exact(
        to_address=str(to_address or ""),
        expected_to=str(row.get("to_address") or ""),
    )
    if not to_guard.ok:
        return ConfirmPaymentResult(status_error_sys, to_guard.reason)

    amount_guard = guard_amount_exact_d8(
        amount_asset=amount_asset,
        expected_d8=row.get("amount_asset_d8") or 0,
    )
    if not amount_guard.ok:
        return ConfirmPaymentResult(
            status_error_sys,
            amount_guard.reason,
        )

    q_tx = text(
        "\n".join(
            [
                "SELECT id FROM efhc_core.payment_intents",
                " WHERE external_tx_hash = :h",
                "   AND id <> :iid",
                " LIMIT 1",
            ]
        )
    )
    tx_row = (
        await db.execute(
            q_tx,
            {"h": str(tx_hash), "iid": int(intent_id)},
        )
    ).first()
    if tx_row:
        return ConfirmPaymentResult(
            status_error_sys,
            "TX_HASH_ALREADY_USED",
        )

    q_upd = text(
        "\n".join(
            [
                "UPDATE efhc_core.payment_intents",
                "   SET status = 'CONFIRMED',",
                "       external_tx_hash = :h,",
                "       updated_at = :now",
                " WHERE id = :iid",
            ]
        )
    )

    if purpose == "deposit_efhc":
        lock_ok = await acquire_tx_hash_lock(
            db,
            tx_hash=str(tx_hash),
            purpose=str(purpose),
            intent_id=int(intent_id),
            global_id=int(global_id),
            order_id=None,
        )
        if not lock_ok:
            logger_obj.error(
                "deposit confirm blocked: tx_hash lock conflict "
                "(intent_id=%s global_id=%s tx_hash=%r)",
                intent_id,
                global_id,
                tx_hash,
            )
            return ConfirmPaymentResult(
                status_error_sys,
                "TX_HASH_LOCK_CONFLICT",
            )

        if status_val != "CONFIRMED":
            await db.execute(
                q_upd,
                {
                    "iid": int(intent_id),
                    "h": str(tx_hash),
                    "now": now_func(),
                },
            )
        efhc_amt = d8(row.get("efhc_amount_d8") or 0)
        credit_fn = credit_user_from_bank_fn
        if credit_fn is credit_orig:
            from . import wallets_service as ws

            credit_fn = ws.credit_user_from_bank

        await credit_fn(
            db,
            global_id=int(global_id),
            amount_efhc=efhc_amt,
            reason="deposit_efhc_confirm",
            idempotency_key=(
                f"intent:{intent_id}:confirm:{str(tx_hash)}"
            ),
        )
        await db.commit()
        return ConfirmPaymentResult(status_credited, None)

    if purpose == "shop_external":
        q_order = text(
            "\n".join(
                [
                    "SELECT o.id AS order_id,",
                    "       o.type AS order_type,",
                    "       o.quantity_efhc AS quantity_efhc,",
                    "       o.extra AS extra_json",
                    "  FROM efhc_core.shop_orders o",
                    " WHERE o.global_id = :tg",
                    "   AND o.memo = :m",
                    "   AND o.status = 'PENDING'",
                    " ORDER BY o.id ASC",
                    " LIMIT 1",
                ]
            )
        )
        o = (
            (
                await db.execute(
                    q_order,
                    {"tg": int(global_id), "m": str(payload)},
                )
            )
            .mappings()
            .first()
        )
        if not o:
            logger_obj.warning(
                "shop_external confirm blocked: "
                "pending order not found "
                "(intent_id=%s global_id=%s payload=%r tx_hash=%r)",
                intent_id,
                global_id,
                payload,
                tx_hash,
            )
            return ConfirmPaymentResult(
                status_pending_manual,
                "PENDING_ORDER_NOT_FOUND",
            )

        extra_json = o.get("extra_json") or {}
        legacy_order_shape = not bool(extra_json)

        async def _set_order_error(msg: str) -> None:
            await db.execute(
                text(
                    "UPDATE efhc_core.shop_orders "
                    "SET payment_error_log = :msg, updated_at = NOW() "
                    "WHERE id = :oid"
                ),
                {"oid": int(o["order_id"]), "msg": str(msg)},
            )

        extra_sku = str(extra_json.get("sku") or "").strip()
        extra_item_type = str(extra_json.get("item_type") or "").strip()
        extra_method = (
            str(extra_json.get("payment_method") or "").strip().upper()
        )
        extra_canonical_memo = str(
            extra_json.get("canonical_memo") or ""
        ).strip()
        extra_intent_payload = str(
            extra_json.get("intent_payload") or ""
        ).strip()
        extra_owner_tg = str(
            extra_json.get("payment_owner_global_id") or ""
        ).strip()
        if (
            not extra_sku
            or not extra_item_type
            or not extra_canonical_memo
            or not extra_intent_payload
            or not extra_owner_tg
        ):
            if not legacy_order_shape:
                logger_obj.warning(
                    "shop_external confirm blocked: "
                    "order extra snapshot is incomplete "
                    "(intent_id=%s order_id=%s)",
                    intent_id,
                    int(o["order_id"]),
                )
                await _set_order_error(
                    "ORDER_EXTRA_SNAPSHOT_INCOMPLETE"
                )
                return ConfirmPaymentResult(
                    status_pending_manual,
                    "ORDER_EXTRA_SNAPSHOT_INCOMPLETE",
                )
            extra_intent_payload = str(payload)
            extra_owner_tg = str(int(global_id))
            if str(o.get("order_type") or "") == "EFHC":
                extra_item_type = str(item_type_efhc_package)
                qty_raw = o.get("quantity_efhc")
                qty_int = int(Decimal(str(qty_raw or "0")))
                extra_canonical_memo = (
                    f"SKU:EFHC|Q:{qty_int}|TG:{int(global_id)}"
                )
            elif str(o.get("order_type") or "") == "NFT":
                extra_item_type = str(item_type_nft_vip)
                extra_canonical_memo = (
                    f"SKU:NFT_VIP|Q:1|TG:{int(global_id)}"
                )

        if extra_intent_payload != str(payload):
            logger_obj.warning(
                "shop_external confirm blocked: "
                "intent payload snapshot mismatch "
                "(intent_id=%s order_id=%s)",
                intent_id,
                int(o["order_id"]),
            )
            await _set_order_error("INTENT_PAYLOAD_SNAPSHOT_MISMATCH")
            return ConfirmPaymentResult(
                status_pending_manual,
                "INTENT_PAYLOAD_SNAPSHOT_MISMATCH",
            )

        if extra_owner_tg != str(int(global_id)):
            logger_obj.warning(
                "shop_external confirm blocked: payment owner mismatch "
                "(intent_id=%s order_id=%s)",
                intent_id,
                int(o["order_id"]),
            )
            await _set_order_error("PAYMENT_OWNER_MISMATCH")
            return ConfirmPaymentResult(
                status_pending_manual,
                "PAYMENT_OWNER_MISMATCH",
            )

        expected_canonical_memo = ""
        if extra_item_type == item_type_efhc_package:
            qty_raw = o.get("quantity_efhc")
            qty_int = int(Decimal(str(qty_raw or "0")))
            expected_canonical_memo = (
                f"SKU:EFHC|Q:{qty_int}|TG:{int(global_id)}"
            )
        elif extra_item_type == item_type_nft_vip:
            expected_canonical_memo = f"SKU:NFT_VIP|Q:1|TG:{int(global_id)}"

        if (
            expected_canonical_memo
            and extra_canonical_memo != expected_canonical_memo
        ):
            logger_obj.warning(
                "shop_external confirm blocked: "
                "canonical memo mismatch "
                "(intent_id=%s order_id=%s got=%r expected=%r)",
                intent_id,
                int(o["order_id"]),
                extra_canonical_memo,
                expected_canonical_memo,
            )
            await _set_order_error("CANONICAL_MEMO_MISMATCH")
            return ConfirmPaymentResult(
                status_pending_manual,
                "CANONICAL_MEMO_MISMATCH",
            )

        if extra_method and extra_method != asset_expected:
            logger_obj.warning(
                "shop_external confirm blocked: "
                "payment method mismatch "
                "(intent_id=%s order_id=%s got=%r expected=%r)",
                intent_id,
                int(o["order_id"]),
                extra_method,
                asset_expected,
            )
            await _set_order_error("PAYMENT_METHOD_MISMATCH")
            return ConfirmPaymentResult(
                status_pending_manual,
                "PAYMENT_METHOD_MISMATCH",
            )

        lock_ok = await acquire_tx_hash_lock(
            db,
            tx_hash=str(tx_hash),
            purpose=str(purpose),
            intent_id=int(intent_id),
            global_id=int(global_id),
            order_id=int(o["order_id"]),
        )
        if not lock_ok:
            logger_obj.error(
                "shop_external confirm blocked: tx_hash lock conflict "
                "(intent_id=%s order_id=%s global_id=%s tx_hash=%r)",
                intent_id,
                int(o["order_id"]),
                global_id,
                tx_hash,
            )
            await _set_order_error("confirm__path__guard_failed")
            return ConfirmPaymentResult(
                status_error_sys,
                "confirm__path__guard_failed",
            )

        row_paid = (
            (
                await db.execute(
                    text(
                        "UPDATE efhc_core.shop_orders "
                        "SET status = 'PAID_AUTO', "
                        "tx_hash = :h, "
                        "payment_error_log = NULL, "
                        "updated_at = NOW() "
                        "WHERE id = :oid "
                        "AND status = 'PENDING' "
                        "RETURNING type AS order_type, "
                        "quantity_efhc AS quantity_efhc"
                    ),
                    {
                        "h": str(tx_hash),
                        "oid": int(o["order_id"]),
                    },
                )
            )
            .mappings()
            .first()
        )
        if not row_paid:
            logger_obj.warning(
                "shop_external confirm blocked: "
                "order update not applied "
                "(intent_id=%s order_id=%s tx_hash=%r)",
                intent_id,
                int(o["order_id"]),
                tx_hash,
            )
            await _set_order_error("ORDER_UPDATE_NOT_APPLIED")
            return ConfirmPaymentResult(
                status_pending_manual,
                "ORDER_UPDATE_NOT_APPLIED",
            )

        if status_val != "CONFIRMED":
            await db.execute(
                q_upd,
                {
                    "iid": int(intent_id),
                    "h": str(tx_hash),
                    "now": now_func(),
                },
            )

        order_type = str(row_paid.get("order_type") or "")
        quantity_efhc = row_paid.get("quantity_efhc")
        if order_type == "EFHC" and quantity_efhc is not None:
            qty = d8(Decimal(str(quantity_efhc)))
            if qty > d8("0"):
                from . import wallets_service as ws

                await ws.credit_user_from_bank(
                    db,
                    global_id=int(global_id),
                    amount_efhc=qty,
                    reason="shop_external_efhc_package_confirm",
                    idempotency_key=f"intent:{intent_id}:shop_credit",
                )
        await db.commit()
        try:
            from .shop_order_notifications_service import (
                dispatch_shop_order_notifications,
            )

            await dispatch_shop_order_notifications(db, limit=25)
            await db.commit()
        except Exception as exc:
            logger_obj.warning(
                "shop_external notification dispatch skipped "
                "(intent_id=%s order_id=%s err=%s)",
                intent_id,
                o["order_id"],
                exc,
            )
        return ConfirmPaymentResult(status_paid_auto, None)

    await db.commit()
    return ConfirmPaymentResult(
        status_error_sys,
        "unsupported_confirm_purpose",
    )
