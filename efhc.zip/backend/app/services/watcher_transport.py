from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal
from typing import Any


def d8(value: Any) -> Decimal:
    return Decimal(str(value or 0)).quantize(
        Decimal("0.00000001"),
        rounding=ROUND_DOWN,
    )


@dataclass(frozen=True)
class WatcherTransportDecision:
    transport_kind: str
    confirm_asset: str
    amount_asset_d8: Decimal


@dataclass(frozen=True)
class WatcherIntentTransportCheck:
    ok: bool
    reason: str | None


def _norm_upper(value: Any) -> str:
    return str(value or "").strip().upper()


def _jetton_units_to_d8(amount_raw: Any, decimals: int) -> Decimal:
    raw = Decimal(str(amount_raw or 0))
    return d8(raw / (Decimal(10) ** int(decimals)))


def classify_watcher_transport(
    *,
    asset: Any,
    amount: Any,
    amount_asset: Any,
    jetton_master: Any,
    efhc_master: str,
    usdt_master: str,
    efhc_decimals: int = 8,
    usdt_decimals: int = 6,
) -> WatcherTransportDecision:
    asset_u = _norm_upper(asset) or "TON"
    master_u = _norm_upper(jetton_master)
    efhc_master_u = _norm_upper(efhc_master)
    usdt_master_u = _norm_upper(usdt_master)

    if asset_u == "JETTON" and master_u and master_u == efhc_master_u:
        return WatcherTransportDecision(
            transport_kind="efhc_jetton",
            confirm_asset="EFHCJ",
            amount_asset_d8=_jetton_units_to_d8(
                amount_asset,
                efhc_decimals,
            ),
        )

    if asset_u == "JETTON" and master_u and master_u == usdt_master_u:
        return WatcherTransportDecision(
            transport_kind="jetton_transfer",
            confirm_asset="USDT",
            amount_asset_d8=_jetton_units_to_d8(
                amount_asset,
                usdt_decimals,
            ),
        )

    if asset_u == "JETTON":
        return WatcherTransportDecision(
            transport_kind="unknown_jetton",
            confirm_asset="JETTON_UNKNOWN",
            amount_asset_d8=d8(0),
        )

    return WatcherTransportDecision(
        transport_kind="native_ton",
        confirm_asset="TON",
        amount_asset_d8=d8(amount or 0),
    )


def validate_payment_intent_transport(
    decision: WatcherTransportDecision,
) -> WatcherIntentTransportCheck:
    if decision.transport_kind == "native_ton":
        return WatcherIntentTransportCheck(ok=True, reason=None)

    if decision.transport_kind == "jetton_transfer":
        return WatcherIntentTransportCheck(ok=True, reason=None)

    if decision.transport_kind == "efhc_jetton":
        return WatcherIntentTransportCheck(
            ok=False,
            reason="EFHC_JETTON_NOT_ALLOWED_FOR_PAYMENT_INTENT",
        )

    if decision.transport_kind == "unknown_jetton":
        return WatcherIntentTransportCheck(
            ok=False,
            reason="UNKNOWN_JETTON_MASTER",
        )

    return WatcherIntentTransportCheck(
        ok=False,
        reason="UNSUPPORTED_TRANSPORT_KIND",
    )
