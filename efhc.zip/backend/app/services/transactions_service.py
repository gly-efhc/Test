# -*- coding: utf-8 -*-
# backend/app/services/transactions_service.py
# =====================================================================
# EFHC Bot — Банковский сервис
# (READ-THROUGH идемпотентность)
# ---------------------------------------------------------------------
# ЕДИНСТВЕННАЯ точка входа
# для денежных движений EFHC.
# Канон (функции):
# • credit_user_from_bank(...)        — кредит на MAIN
# • credit_user_bonus_from_bank(...)  — кредит на BONUS
# • debit_user_to_bank(...)           — дебет с MAIN
# • debit_user_bonus_to_bank(...)     — дебет с BONUS
# • exchange_kwh_to_efhc(...) — кредит EFHC
#   1:1 за энергию
# ---------------------------------------------------------------------
# Правила:
# • Пользователь не может уйти в минус
#   (main/bonus).
# • Банк может уйти в минус
#   операции не блокируются.
# • Операция идемпотентна по idempotency_key
#   (UNIQUE в логе).
# • Decimal(30,8), округление вниз — deps.d8().
# • Зеркальный лог Банка: mirror:<idempotency_key>.
# • Никаких P2P
#   только «пользователь ↔ банк».
# =====================================================================

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any, Awaitable, Callable, Optional, Tuple

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


async def _safe_rollback(db: AsyncSession, ctx: str) -> None:
    try:
        await db.rollback()
    except Exception as exc:
        logger.warning("DB rollback failed (%s): %s", ctx, exc)

# Telegram ID банковского аккаунта (из .env)
BANK_TG_ID = int(
    getattr(settings, "ADMIN_BANK_TG_ID", "0") or "0"
)
if BANK_TG_ID <= 0:
    logger.warning(
        (
            "ADMIN_BANK_TG_ID не задан — "
"зеркальные логи банка "
"отключены."
        )
    )

# ---------------------------------------------------------------------
# DTO результата операции
# ---------------------------------------------------------------------


@dataclass
class TxResult:
    ok: bool
    tg_id: int
    amount: Decimal
    balance_type: str  # "main" | "bonus"
    reason: str
    idempotency_key: str
    user_main_balance: Decimal
    user_bonus_balance: Decimal
    bank_main_balance: Optional[Decimal] = None
    created_log_id: Optional[int] = None
    detail: str = "ok"
    processed_with_deficit: bool = False


# ---------------------------------------------------------------------
# Низкоуровневые SQL
# (осознанно без ORM, ради прозрачности)
# ---------------------------------------------------------------------

_GET_USER_FOR_UPDATE_SQL = text(
    f"""
    SELECT
        tg_id,
        COALESCE(main_balance, 0)  AS main_balance,
        COALESCE(bonus_balance, 0) AS bonus_balance
    FROM {SCHEMA}.users
            WHERE tg_id = :tg_id
    FOR UPDATE
    """
)

_GET_USER_SQL = text(
    f"""
    SELECT
        tg_id,
        COALESCE(main_balance, 0)  AS main_balance,
        COALESCE(bonus_balance, 0) AS bonus_balance
    FROM {SCHEMA}.users
    WHERE tg_id = :tg_id
    """
)

_UPSERT_USER_SQL = text(
    f"""
    INSERT INTO {SCHEMA}.users (
        tg_id,
        username,
        is_vip,
        is_active,
        main_balance,
        bonus_balance,
        total_generated_kwh,
        created_at,
        updated_at
    )
    VALUES (
                :tg_id,
        :username,
        FALSE,
        TRUE,
        0,
        0,
        0,
        NOW(),
        NOW()
    )
    ON CONFLICT (tg_id) DO NOTHING
    """
)
_UPSERT_USER_SQLITE_SQL = text(
    f"""
    INSERT INTO {SCHEMA}.users (
        tg_id,
        username,
        is_vip,
        is_active,
        main_balance,
        bonus_balance,
        total_generated_kwh,
        created_at,
        updated_at
    )
    VALUES (
        :tg_id,
        :username,
        0,
        1,
        0,
        0,
        0,
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP
    )
    ON CONFLICT (tg_id) DO NOTHING
    """
)



_UPDATE_USER_BALANCES_SQL = text(
    f"""
    UPDATE {SCHEMA}.users
    SET
        main_balance  = :mb,
        bonus_balance = :bb,
        updated_at    = NOW()
            WHERE tg_id = :tg_id
    """
)

_UPDATE_USER_BALANCES_SQLITE_SQL = text(
    f"""
    UPDATE {SCHEMA}.users
    SET
        main_balance  = :mb,
        bonus_balance = :bb,
        updated_at    = CURRENT_TIMESTAMP
            WHERE tg_id = :tg_id
    """
)

_INSERT_LOG_SQL = text(
    f"""
    INSERT INTO {SCHEMA}.efhc_transfers_log (
        tg_id,
        amount,
        direction,
        balance_type,
        reason,
        idempotency_key,
        created_at,
        extra_info
    )
    VALUES (
        :tg_id,
        :amount,
        :direction,
        :balance_type,
        :reason,
        :idk,
        NOW(),
        COALESCE(:extra_info::jsonb, '{{}}'::jsonb)
    )
    RETURNING id
    """
)

_SELECT_LOG_BY_IDK_SQL = text(
    f"""
    SELECT
        id,
        tg_id,
        amount,
        direction,
        balance_type,
        reason,
        idempotency_key,
        created_at
    FROM {SCHEMA}.efhc_transfers_log
    WHERE idempotency_key = :idk
    LIMIT 1
    """
)

_MARK_IDK_CONFLICT_SQL = text(
    f"""
    UPDATE {SCHEMA}.efhc_transfers_log
    SET extra_info =
        COALESCE(extra_info, '{{}}'::jsonb)
        || '{{"idk_conflict":"true"}}'::jsonb
    WHERE idempotency_key = :idk
    """
)


_APPEND_LOG_EXTRA_PG_SQL = text(
    f"""
    UPDATE {SCHEMA}.efhc_transfers_log
    SET extra_info = COALESCE(extra_info, '{{}}'::jsonb) || (:extra::jsonb)
    WHERE id = :log_id
    """
)


_APPEND_LOG_EXTRA_BY_IDK_PG_SQL = text(
    f"""
    UPDATE {SCHEMA}.efhc_transfers_log
    SET extra_info = COALESCE(extra_info, '{{}}'::jsonb) || (:extra::jsonb)
    WHERE idempotency_key = :idk
    """
)


async def append_transfer_extra_info(
    db: AsyncSession,
    *,
    log_id: int,
    extra_info: dict[str, Any],
) -> None:
    """Каноничный путь модификации efhc_transfers_log.extra_info.

    Правило проекта: любые записи/правки efhc_transfers_log должны
    происходить только через transactions_service.

    Реализация:
    - Postgres: jsonb merge (||)
    - SQLite (локальные тесты/старые окружения): read-merge-write в Python.
    """

    if not log_id or int(log_id) <= 0:
        return

    payload = dict(extra_info or {})
    bind = db.get_bind()
    dialect = getattr(getattr(bind, "dialect", None), "name", "")
    if dialect == "sqlite":
        cur = await db.execute(
            text(
                f"""
                SELECT extra_info
                  FROM {SCHEMA}.efhc_transfers_log
                 WHERE id = :log_id
                 LIMIT 1
                """
            ),
            {"log_id": int(log_id)},
        )
        existing_raw = cur.scalar()
        try:
            existing = json.loads(existing_raw) if existing_raw else {}
        except Exception:
            existing = {}
        merged = dict(existing)
        merged.update(payload)
        await db.execute(
            text(
                f"""
                UPDATE {SCHEMA}.efhc_transfers_log
                   SET extra_info = :extra
                 WHERE id = :log_id
                """
            ),
            {"log_id": int(log_id), "extra": json.dumps(merged)},
        )
        return

    await db.execute(
        _APPEND_LOG_EXTRA_PG_SQL,
        {"log_id": int(log_id), "extra": json.dumps(payload)},
    )


async def append_transfer_extra_info_by_idempotency_key(
    db: AsyncSession,
    *,
    idempotency_key: str,
    extra_info: dict[str, Any],
) -> None:
    """Каноничный путь модификации efhc_transfers_log.extra_info по idempotency_key."""

    if not idempotency_key or not str(idempotency_key).strip():
        return
    payload = dict(extra_info or {})

    bind = db.get_bind()
    dialect = getattr(getattr(bind, "dialect", None), "name", "")
    if dialect == "sqlite":
        cur = await db.execute(
            text(
                f"""
                SELECT id, extra_info
                  FROM {SCHEMA}.efhc_transfers_log
                 WHERE idempotency_key = :idk
                """
            ),
            {"idk": str(idempotency_key)},
        )
        rows = cur.fetchall() or []
        for rid, existing_raw in rows:
            try:
                existing = json.loads(existing_raw) if existing_raw else {}
            except Exception:
                existing = {}
            merged = dict(existing)
            merged.update(payload)
            await db.execute(
                text(
                    f"""
                    UPDATE {SCHEMA}.efhc_transfers_log
                       SET extra_info = :extra
                     WHERE id = :rid
                    """
                ),
                {"rid": int(rid), "extra": json.dumps(merged)},
            )
        return

    await db.execute(
        _APPEND_LOG_EXTRA_BY_IDK_PG_SQL,
        {"idk": str(idempotency_key), "extra": json.dumps(payload)},
    )




def _available_from_total_exchanged(
    total_generated_kwh: Decimal,
    exchanged_kwh_total: Decimal,
) -> Decimal:
    """SSOT mirror: available_kwh = max(total - exchanged, 0).

    All values are scale=8 (DOWN) via d8().
    """
    total_v = d8(total_generated_kwh)
    exch_v = d8(exchanged_kwh_total)
    avail = d8(total_v - exch_v)
    return avail if avail > Decimal('0') else Decimal('0')
# ---------------------------------------------------------------------
# Утилиты блокировки пользователя
# и фиксации балансов
# ---------------------------------------------------------------------


async def _ensure_user_locked(
    db: AsyncSession,
    tg_id: int,
) -> Tuple[Decimal, Decimal]:
    """Возвращает (main, bonus) с FOR UPDATE."""
    bind = db.get_bind()
    dialect = getattr(getattr(bind, 'dialect', None), 'name', '')
    if dialect == "sqlite":
        get_sql = _GET_USER_SQL
        upsert_sql = _UPSERT_USER_SQLITE_SQL
    else:
        get_sql = _GET_USER_FOR_UPDATE_SQL
        upsert_sql = _UPSERT_USER_SQL

    res = await db.execute(
        get_sql,
        {"tg_id": int(tg_id)},
    )
    row = res.fetchone()
    if row:
        return d8(row[1] or 0), d8(row[2] or 0)

    await db.execute(
        upsert_sql,
        {"tg_id": int(tg_id), "username": None},
    )
    res2 = await db.execute(
        get_sql,
        {"tg_id": int(tg_id)},
    )
    row2 = res2.fetchone()
    if not row2:
        raise RuntimeError(
            (
                "Не удалось создать/"
                "заблокировать "
                f"пользователя tg_id={tg_id}"
            )
        )

    return d8(row2[1] or 0), d8(row2[2] or 0)

async def _update_user_balances(
    db: AsyncSession,
    tg_id: int,
    main_balance: Decimal,
    bonus_balance: Decimal,
) -> None:
    """Обновляет балансы пользователя."""
    await db.execute(
        _UPDATE_USER_BALANCES_SQL,
        {
            "tg_id": int(tg_id),
            "mb": str(d8(main_balance)),
            "bb": str(d8(bonus_balance)),
        },
    )


async def _insert_log(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    direction: str,
    balance_type: str,
    reason: str,
    idk: str,
    extra_info: Optional[dict[str, Any]] = None,
) -> int:
    """Пишет операцию в журнал."""
    dialect = ""
    try:
        bind = getattr(db, "bind", None)
        d = getattr(getattr(bind, "dialect", None), "name", "")
        dialect = str(d)
    except Exception:
        dialect = ""

    if dialect == "sqlite":
        insert_sql = text(
            f"""
            INSERT INTO {SCHEMA}.efhc_transfers_log (
                tg_id,
                amount,
                direction,
                balance_type,
                reason,
                idempotency_key,
                created_at,
                extra_info
            )
            VALUES (
                :tg_id,
                :amount,
                :direction,
                :balance_type,
                :reason,
                :idk,
                now(),
                COALESCE(:extra_info, '{{}}')
            )
            RETURNING id
            """
        )
        extra_payload = json.dumps(extra_info or {})
    else:
        insert_sql = _INSERT_LOG_SQL
        extra_payload = json.dumps(extra_info or {})

    try:
        res = await db.execute(
            insert_sql,
            {
            "tg_id": int(tg_id),
            "amount": str(d8(amount)),
            "direction": direction,
            "balance_type": balance_type,
            "reason": reason,
            "idk": idk,
            "extra_info": extra_payload,
            },
        )
    except IntegrityError:
        # Idempotency: return existing log id for same idempotency_key.
        res2 = await db.execute(
            _SELECT_LOG_BY_IDK_SQL,
            {"idk": idk},
        )
        row = res2.fetchone()
        if row:
            return int(row[0])
        raise
    rid = res.fetchone()[0]
    return int(rid)


async def _find_log_by_idk(
    db: AsyncSession,
    idk: str,
) -> Optional[dict[str, Any]]:
    """Ищет операцию по idempotency_key."""
    res = await db.execute(_SELECT_LOG_BY_IDK_SQL, {"idk": idk})
    row = res.fetchone()
    if not row:
        return None
    return {
        "id": int(row[0]),
        "tg_id": (int(row[1]) if row[1] is not None else None),
        "amount": Decimal(str(row[2])),
        "direction": str(row[3]),
        "balance_type": str(row[4]),
        "reason": str(row[5]),
        "idempotency_key": str(row[6]),
        "created_at": row[7],
    }


# ---------------------------------------------------------------------
# READ-THROUGH обвязка
# идемпотентной операции
# ---------------------------------------------------------------------

RunCore = Callable[
    ...,
    Awaitable[Tuple[Decimal, Decimal, Decimal, bool]],
]


async def _run_idempotent(
    db: AsyncSession,
    *,
    idempotency_key: str,
    tg_id: int,
    balance_type: str,
    amount: Decimal,
    reason: str,
    direction: str,
    exec_core: RunCore,
) -> TxResult:
    """Выполняет операцию атомарно."""
    max_tries = 3
    backoff = 0.15
    last_exc: Optional[Exception] = None

    for attempt in range(1, max_tries + 1):
        try:
            await db.begin()

            user_main, user_bonus = await _ensure_user_locked(db, tg_id)

            bank_main = Decimal("0")
            bank_bonus = Decimal("0")
            bank_id = None
            if BANK_TG_ID > 0:
                bank_id = int(BANK_TG_ID)
                bank_main, bank_bonus = await _ensure_user_locked(
                    db,
                    BANK_TG_ID,
                )

            new_user_main, new_user_bonus, new_bank_main, deficit = (
                await exec_core(
                    db=db,
                    tg_id=int(tg_id),
                    user_main=user_main,
                    user_bonus=user_bonus,
                    bank_main=bank_main,
                    bank_id=bank_id,
                    bank_bonus=bank_bonus,
                    amount=d8(amount),
                    balance_type=balance_type,
                    reason=reason,
                    idempotency_key=idempotency_key,
                )
            )

            is_negative = (
                new_user_main < Decimal("0")
                or new_user_bonus < Decimal("0")
            )
            if is_negative:
                raise ValueError("User balance negative is forbidden")

            await _update_user_balances(
                db,
                tg_id,
                new_user_main,
                new_user_bonus,
            )
            if BANK_TG_ID > 0:
                await _update_user_balances(
                    db,
                    BANK_TG_ID,
                    new_bank_main,
                    bank_bonus,
                )

            extra_info_user: dict[str, Any] = {}
            if deficit:
                extra_info_user["bank_deficit_mode"] = "true"

            log_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=d8(amount),
                direction=direction,
                balance_type=balance_type,
                reason=reason,
                idk=idempotency_key,
                extra_info=extra_info_user,
            )

            if BANK_TG_ID > 0:
                mirror_key = f"mirror:{idempotency_key}"
                mirror_direction = f"{direction}_mirror"
                extra_info_bank = {
                    "mirror_for_user": int(tg_id),
                    "mirror_of_idk": idempotency_key,
                }
                try:
                    await _insert_log(
                        db,
                        tg_id=int(BANK_TG_ID),
                        amount=d8(amount),
                        direction=mirror_direction,
                        balance_type="main",
                        reason=f"mirror:{reason}",
                        idk=mirror_key,
                        extra_info=extra_info_bank,
                    )
                except Exception as me:
                    if "unique" not in str(me).lower():
                        logger.warning(
                            (
                                "Mirror log insert error: %s"
                                "%s"
                            ),
                            me,
                        )

            await db.commit()

            return TxResult(
                ok=True,
                tg_id=int(tg_id),
                amount=d8(amount),
                balance_type=balance_type,
                reason=reason,
                idempotency_key=idempotency_key,
                user_main_balance=d8(new_user_main),
                user_bonus_balance=d8(new_user_bonus),
                bank_main_balance=(
                    d8(new_bank_main) if BANK_TG_ID > 0 else None
                ),
                created_log_id=int(log_id),
                processed_with_deficit=bool(deficit),
                detail="ok",
            )

        except Exception as e:
            try:
                await db.rollback()
            except Exception as exc:
                logger.warning("DB rollback failed (tx): %s", exc)

            msg = str(e).lower()

            if "unique" in msg and "idempotency_key" in msg:
                try:
                    await db.execute(
                        _MARK_IDK_CONFLICT_SQL,
                        {"idk": idempotency_key},
                    )
                    await db.commit()
                except Exception:
                    await _safe_rollback(db, "idk_conflict_mark")

                prev = await _find_log_by_idk(db, idempotency_key)
                if prev:
                    um, ub = await _ensure_user_locked(db, tg_id)
                    await _safe_rollback(db, "idk_read_through")
                    return TxResult(
                        ok=True,
                        tg_id=int(tg_id),
                        amount=d8(prev["amount"]),
                        balance_type=str(prev["balance_type"]),
                        reason=str(prev["reason"]),
                        idempotency_key=idempotency_key,
                        user_main_balance=d8(um),
                        user_bonus_balance=d8(ub),
                        bank_main_balance=None,
                        created_log_id=int(prev["id"]),
                        detail="idempotent_replay_read_through",
                        processed_with_deficit=False,
                    )

                await asyncio.sleep(backoff * attempt)
                last_exc = e
                continue

            transient = (
                "deadlock" in msg
                or "could not serialize" in msg
                or "serialization" in msg
                or "conflict" in msg
            )
            if transient:
                await asyncio.sleep(backoff * attempt)
                last_exc = e
                continue

            last_exc = e
            logger.error(
                "Bank tx fatal error (attempt %s/%s): %s",
                attempt,
                max_tries,
                e,
            )
            break

    raise RuntimeError(
        (
            f"Bank transaction failed after {max_tries} attempts: "
            f"{last_exc}"
        )
    )


# ---------------------------------------------------------------------
# Бизнес-операции (канон)
# ---------------------------------------------------------------------


async def credit_user_from_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Optional[Decimal] = None,
    amount: Optional[Decimal] = None,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Кредит MAIN пользователю из Банка."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> Tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        new_user_main = d8(user_main + amount_local)
        new_user_bonus = user_bonus
        new_bank_main = d8(bank_main - amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="main",
        amount=amt,
        reason=reason,
        direction="bank_to_user",
        exec_core=_core,
    )


async def credit_user_bonus_from_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Optional[Decimal] = None,
    amount: Optional[Decimal] = None,
    reason: str,
    idempotency_key: str,
    meta: Optional[dict[str, Any]] = None,
) -> TxResult:
    """Кредит BONUS пользователю из Банка."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> Tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        new_user_main = user_main
        new_user_bonus = d8(user_bonus + amount_local)
        new_bank_main = d8(bank_main - amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    result = await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="bonus",
        amount=amt,
        reason=reason,
        direction="bank_to_user",
        exec_core=_core,
    )

    if meta:
        logger.debug("credit_user_bonus_from_bank meta=%s", meta)

    return result


async def debit_user_to_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Optional[Decimal] = None,
    amount: Optional[Decimal] = None,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет MAIN пользователя в Банк."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> Tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        if user_main - amount_local < Decimal("0"):
            raise ValueError(
                (
                    "Недостаточно средств ",
                    "на основном балансе",
                )
            )

        new_user_main = d8(user_main - amount_local)
        new_user_bonus = user_bonus
        new_bank_main = d8(bank_main + amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="main",
        amount=amt,
        reason=reason,
        direction="user_to_bank",
        exec_core=_core,
    )


async def debit_user_bonus_to_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Optional[Decimal] = None,
    amount: Optional[Decimal] = None,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет BONUS пользователя в Банк."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> Tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        if user_bonus - amount_local < Decimal("0"):
            raise ValueError(
                (
                    "Недостаточно средств ",
                    "на бонусном балансе",
                )
            )

        new_user_main = user_main
        new_user_bonus = d8(user_bonus - amount_local)
        new_bank_main = d8(bank_main + amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="bonus",
        amount=amt,
        reason=reason,
        direction="user_to_bank",
        exec_core=_core,
    )


async def exchange_kwh_to_efhc(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_kwh: Optional[Decimal] = None,
    amount: Optional[Decimal] = None,
    reason: str,
    idempotency_key: str,
    strict_kwh_check: bool = False,
) -> TxResult:
    """Обмен kWh → EFHC (1:1)."""
    if amount is None and amount_kwh is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_kwh",
            )
        )
    if amount is None:
        amount = amount_kwh

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> Tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        if strict_kwh_check:
            q = (
                "SELECT COALESCE(available_kwh, 0) "
                f"FROM {SCHEMA}.users WHERE tg_id = :tg_id"
            )
            row = await db.execute(text(q), {"tg_id": int(tg_id)})
            ak = Decimal(str(row.scalar() or "0"))
            if ak < amount_local:
                raise ValueError(
("Недостаточно доступной " "энергии")
                )

        new_user_main = d8(user_main + amount_local)
        new_user_bonus = user_bonus
        new_bank_main = d8(bank_main - amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="main",
        amount=amt,
        reason=reason,
        direction="bank_to_user",
        exec_core=_core,
    )


async def exchange_all_available_kwh_to_main(
    db: AsyncSession,
    *,
    tg_id: int,
    idempotency_key: str,
    reason: str = "exchange_all",
) -> TxResult:
    """EXCHANGE_ALL по SSOT:

    - total_generated_kwh (lifetime) НЕ уменьшается (append-only).
    - exchanged_kwh_total растёт (append-only).
    - available_kwh = total_generated_kwh - exchanged_kwh_total.
    - начисление строго в EFHC MAIN 1:1.
    - операция идемпотентна по idempotency_key.

    Важно: атомарность обеспечивается блокировкой строки пользователя.
    """

    if not idempotency_key or not str(idempotency_key).strip():
        raise ValueError("Idempotency-Key обязателен")

    existing = await _find_log_by_idk(db, str(idempotency_key))
    if existing:
        main, _bonus = await get_user_balances_snapshot(
            db,
            tg_id=int(tg_id),
        )
        return TxResult(
            ok=True,
            created_log_id=int(existing["id"]),
            user_main_balance=d8(main),
            user_bonus_balance=Decimal("0"),
        )

    max_tries = 3
    last_exc: Optional[Exception] = None

    for _attempt in range(1, max_tries + 1):
        try:
            bind = db.get_bind()
            dialect = getattr(bind.dialect, "name", "")

            # SQLite не поддерживает FOR UPDATE.
            # Конкурентность в тестах: BEGIN IMMEDIATE + ретраи.
            # обеспечиваем BEGIN IMMEDIATE (с ретраями по max_tries).
            if dialect == "sqlite":
                await db.execute(text("BEGIN IMMEDIATE"))
                lock = ""
            else:
                await db.begin()
                lock = " FOR UPDATE"

            q_user = (
                "SELECT "
                "COALESCE(main_balance, 0), "
                "COALESCE(bonus_balance, 0), "
                "COALESCE(total_generated_kwh, 0), "
                "COALESCE(exchanged_kwh_total, 0) "
                f"FROM {SCHEMA}.users "
                "WHERE tg_id = :tg_id "
                f"{lock}"
            )
            rec = await db.execute(text(q_user), {"tg_id": int(tg_id)})
            row = rec.fetchone()
            if not row:
                raise ValueError("User not found")

            user_main = d8(row[0] or 0)
            user_bonus = d8(row[1] or 0)
            total_kwh = d8(row[2] or 0)
            exchanged_total = d8(row[3] or 0)

            if exchanged_total > total_kwh:
                raise ValueError("SSOT violated: exchanged > total")

            available = _available_from_total_exchanged(
                total_kwh, exchanged_total,
            )

            bank_main = Decimal("0")
            bank_bonus = Decimal("0")
            bank_id = None
            if BANK_TG_ID > 0:
                bank_id = int(BANK_TG_ID)
                bank_main, bank_bonus = await _ensure_user_locked(
                    db,
                    BANK_TG_ID,
                )

            if available <= Decimal("0"):
                total_equiv_before = d8(user_main + available)
                audit = {
                    "audit_schema_version": "v1",
                    "exchange_all_audit": True,
                    "op_type": "EXCHANGE_ALL",
                    "status": "rejected",
                    "reason": "no_available_kwh",
                    "before": {
                        "total_generated_kwh": str(total_kwh),
                        "exchanged_kwh_total": str(exchanged_total),
                        "available_kwh": str(available),
                        "main_balance": str(user_main),
                        "total_equivalent": str(total_equiv_before),
                    },
                    "after": {
                        "total_generated_kwh": str(total_kwh),
                        "exchanged_kwh_total": str(exchanged_total),
                        "available_kwh": str(available),
                        "main_balance": str(user_main),
                        "total_equivalent": str(total_equiv_before),
                        "invariant_ok": True,
                    },
                }
                log_id = await _insert_log(
                    db,
                    tg_id=int(tg_id),
                    amount=Decimal("0"),
                    direction="noop",
                    balance_type="main",
                    reason=reason,
                    idk=str(idempotency_key),
                    extra_info=audit,
                )
                await db.commit()
                return TxResult(
                    ok=False,
                    created_log_id=int(log_id),
                    user_main_balance=user_main,
                    user_bonus_balance=user_bonus,
                )

            new_user_main = d8(user_main + available)
            new_user_bonus = user_bonus

            new_bank_main = d8(bank_main - available)
            deficit = new_bank_main < Decimal("0")

            new_exchanged_total = d8(exchanged_total + available)
            # By definition after exchange-all available becomes 0.
            new_available = _available_from_total_exchanged(
                total_kwh, new_exchanged_total,
            )

            await _update_user_balances(
                db,
                int(tg_id),
                new_user_main,
                new_user_bonus,
            )
            if BANK_TG_ID > 0:
                await _update_user_balances(
                    db,
                    int(BANK_TG_ID),
                    new_bank_main,
                    bank_bonus,
                )

            q_energy = (
                f"UPDATE {SCHEMA}.users "
                "SET exchanged_kwh_total = :ex, "
                                "    updated_at = now() "
                "WHERE tg_id = :tg_id"
            )
            await db.execute(
                text(q_energy),
                {
                    "ex": str(d8(new_exchanged_total)),
                                        "tg_id": int(tg_id),
                },
            )

            total_equiv_before = d8(user_main + available)
            total_equiv_after = d8(new_user_main + new_available)

            audit_ok = bool(total_equiv_before == total_equiv_after)
            audit = {
                "audit_schema_version": "v1",
                    "exchange_all_audit": True,
                "op_type": "EXCHANGE_ALL",
                "status": "success",
                "rate": "1.00000000",
                "before": {
                    "total_generated_kwh": str(total_kwh),
                    "exchanged_kwh_total": str(exchanged_total),
                    "available_kwh": str(available),
                    "main_balance": str(user_main),
                    "total_equivalent": str(total_equiv_before),
                },
                "params": {
                    "amount_kwh": str(d8(available)),
                    "amount_efhc": str(d8(available)),
                },
                "after": {
                    "total_generated_kwh": str(total_kwh),
                    "exchanged_kwh_total": str(new_exchanged_total),
                    "available_kwh": str(new_available),
                    "main_balance": str(new_user_main),
                    "total_equivalent": str(total_equiv_after),
                    "invariant_ok": bool(audit_ok),
                },
            }
            extra_user: dict[str, Any] = {}
            if deficit:
                extra_user["bank_deficit_mode"] = "true"
            extra_user.update(audit)

            log_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=d8(available),
                direction="bank_to_user",
                balance_type="main",
                reason=reason,
                idk=str(idempotency_key),
                extra_info=extra_user,
            )

            if BANK_TG_ID > 0:
                mirror_key = f"mirror:{idempotency_key}"
                mirror_direction = "bank_to_user_mirror"
                extra_bank = {
                    "mirror_for_user": int(tg_id),
                    "mirror_of_idk": str(idempotency_key),
                }
                await _insert_log(
                    db,
                    tg_id=int(BANK_TG_ID),
                    amount=d8(available),
                    direction=mirror_direction,
                    balance_type="main",
                    reason=f"mirror:{reason}",
                    idk=mirror_key,
                    extra_info=extra_bank,
                )

            await db.commit()
            return TxResult(
                ok=True,
                created_log_id=int(log_id),
                user_main_balance=new_user_main,
                user_bonus_balance=new_user_bonus,
            )
        except Exception as e:
            last_exc = e
            try:
                await db.rollback()
            except Exception:
                pass
    raise last_exc or RuntimeError("exchange_all failed")


# ---------------------------------------------------------------------
# Доп. утилита (для роутов/админки)
# ---------------------------------------------------------------------


async def get_user_balances_snapshot(
    db: AsyncSession,
    *,
    tg_id: int,
) -> Tuple[Decimal, Decimal]:
    """Возвращает (main_balance, bonus_balance)."""
    """Без блокировки."""
    q = (
        "SELECT "
        "COALESCE(main_balance, 0), "
        "COALESCE(bonus_balance, 0) "
        f"FROM {SCHEMA}.users "
        "WHERE tg_id = :tg_id"
    )
    row = await db.execute(text(q), {"tg_id": int(tg_id)})
    rec = row.fetchone()
    if not rec:
        return (Decimal("0"), Decimal("0"))
    return d8(rec[0] or 0), d8(rec[1] or 0)


# =====================================================================
# Пояснения:
# • READ-THROUGH:
#   нет предварительного SELECT по idempotency_key.
# • При UNIQUE(idempotency_key) → rollback
#   и возврат существующей записи.
# • Пользователь никогда не уходит
#   в минус; Банк может.
# • direction:
#   - bank_to_user: кредит/обмен
#   - user_to_bank: покупки/выводы
#   - *_mirror: аудит для BANK_TG_ID
# =====================================================================


# =====================================================================
# Канонические операции трат/вывода (SSOT денег)
# =====================================================================

@dataclass(frozen=True)
class SpendBreakdown:
    bonus_part: Decimal
    main_part: Decimal


def split_bonus_then_main(
    *,
    bonus_balance: Decimal,
    main_balance: Decimal,
    amount: Decimal,
) -> SpendBreakdown:
    """Канон: сначала BONUS, затем MAIN.
    Возвращает разбиение суммы на bonus_part + main_part.
    Бросает ValueError при недостатке средств.
    """
    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Amount must be > 0")

    b = d8(bonus_balance)
    m = d8(main_balance)
    if b < Decimal("0") or m < Decimal("0"):
        raise ValueError("Balance must be >= 0")

    if d8(b + m) < amt:
        raise ValueError("Insufficient funds (bonus+main)")

    bonus_part = d8(min(b, amt))
    main_part = d8(amt - bonus_part)
    return SpendBreakdown(bonus_part=bonus_part, main_part=main_part)


async def spend_user_to_bank_bonus_then_main(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
    extra_info: Optional[dict[str, Any]] = None,
) -> TxResult:
    """Списание EFHC при покупках: сначала BONUS, затем MAIN.

    Важно:
    - Атомарно (одна DB-транзакция).
    - Идемпотентно по idempotency_key (используются ключи :bonus/:main).
    - Пишет 1–2 записи в журнал (bonus/main)
      + зеркальные записи Банка.
    """
    bonus_key = f"{idempotency_key}:bonus"
    main_key = f"{idempotency_key}:main"

    # read-through idempotency:
    # если main-часть уже записана — считаем выполнено
    prev_main = await _find_log_by_idk(db, main_key)
    if prev_main:
        um, ub = await _ensure_user_locked(db, int(tg_id))
        # без commit: только чтение
        return TxResult(
            ok=True,
            tg_id=int(tg_id),
            amount=d8(amount),
            balance_type="mixed",
            reason=reason,
            idempotency_key=idempotency_key,
            user_main_balance=d8(um),
            user_bonus_balance=d8(ub),
            bank_main_balance=None,
            created_log_id=int(prev_main["id"]),
            processed_with_deficit=False,
            detail="idempotent",
        )

    await db.begin()
    try:
        user_main, user_bonus = await _ensure_user_locked(
            db,
            int(tg_id),
        )

        bank_main = Decimal("0")
        bank_bonus = Decimal("0")
        if BANK_TG_ID > 0:
            bank_main, bank_bonus = await _ensure_user_locked(
                db,
                int(BANK_TG_ID),
            )

        breakdown = split_bonus_then_main(
            bonus_balance=user_bonus,
            main_balance=user_main,
            amount=d8(amount),
        )
        new_user_bonus = d8(user_bonus - breakdown.bonus_part)
        new_user_main = d8(user_main - breakdown.main_part)

        new_bank_main = bank_main
        deficit = False
        if BANK_TG_ID > 0:
            new_bank_main = d8(bank_main + d8(amount))
            deficit = new_bank_main < Decimal("0")

        await _update_user_balances(
            db,
            int(tg_id),
            new_user_main,
            new_user_bonus,
        )
        if BANK_TG_ID > 0:
            await _update_user_balances(
                db,
                int(BANK_TG_ID),
                new_bank_main,
                bank_bonus,
            )

        created_id: Optional[int] = None
        extra = dict(extra_info or {})
        extra.update(
            {
                "spend_bonus_part": str(breakdown.bonus_part),
                "spend_main_part": str(breakdown.main_part),
            }
        )

        # write logs (user)
        if breakdown.bonus_part > Decimal("0"):
            created_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=breakdown.bonus_part,
                direction="user_to_bank",
                balance_type="bonus",
                reason=reason,
                idk=bonus_key,
                extra_info=extra,
            )
        if breakdown.main_part > Decimal("0"):
            created_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=breakdown.main_part,
                direction="user_to_bank",
                balance_type="main",
                reason=reason,
                idk=main_key,
                extra_info=extra,
            )

        # mirror logs (bank)
        if BANK_TG_ID > 0:
            mirror_for = int(tg_id)
            if breakdown.bonus_part > Decimal("0"):
                try:
                    await _insert_log(
                        db,
                        tg_id=int(BANK_TG_ID),
                        amount=breakdown.bonus_part,
                        direction="user_to_bank_mirror",
                        balance_type="main",
                        reason=f"mirror:{reason}",
                        idk=f"mirror:{bonus_key}",
                        extra_info={
                            "mirror_for_user": mirror_for,
                            "mirror_of_idk": bonus_key,
                        },
                    )
                except Exception as me:
                    if "unique" not in str(me).lower():
                        logger.warning(
                            "Mirror log insert error: %s",
                            me,
                        )
            if breakdown.main_part > Decimal("0"):
                try:
                    await _insert_log(
                        db,
                        tg_id=int(BANK_TG_ID),
                        amount=breakdown.main_part,
                        direction="user_to_bank_mirror",
                        balance_type="main",
                        reason=f"mirror:{reason}",
                        idk=f"mirror:{main_key}",
                        extra_info={
                            "mirror_for_user": mirror_for,
                            "mirror_of_idk": main_key,
                        },
                    )
                except Exception as me:
                    if "unique" not in str(me).lower():
                        logger.warning(
                            "Mirror log insert error: %s",
                            me,
                        )

        await db.commit()

        return TxResult(
            ok=True,
            tg_id=int(tg_id),
            amount=d8(amount),
            balance_type="mixed",
            reason=reason,
            idempotency_key=idempotency_key,
            user_main_balance=d8(new_user_main),
            user_bonus_balance=d8(new_user_bonus),
            bank_main_balance=(
                d8(new_bank_main) if BANK_TG_ID > 0 else None
            ),
            created_log_id=int(created_id or 0),
            processed_with_deficit=bool(deficit),
            detail="ok",
        )
    except Exception:
        await db.rollback()
        raise


async def withdraw_main_only_to_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
    extra_info: Optional[dict[str, Any]] = None,
) -> TxResult:
    """Вывод/холд средств: только MAIN (bonus не трогаем)."""
    # Используем каноничный дебет MAIN (он уже атомарен и идемпотентен).
    return await debit_user_to_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=idempotency_key,
        meta=extra_info,
    )

# ---------------------------------------------------------------------
# Backward-compatible helpers (route-level names)
# ---------------------------------------------------------------------

async def credit_user_main_from_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Кредит MAIN пользователю из Банка (alias для admin_routes)."""
    return await credit_user_from_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )


async def credit_user_bonus_from_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Кредит BONUS пользователю из Банка (alias для admin_routes)."""
    return await credit_user_bonus_from_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )


async def debit_user_main_to_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет MAIN пользователя в Банк (alias для admin_routes)."""
    return await debit_user_to_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )


async def debit_user_bonus_to_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет BONUS пользователя в Банк (alias для admin_routes)."""
    return await debit_user_bonus_to_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )
