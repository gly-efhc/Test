# backend/app/services/lotteries_service.py
# ======================================================================
# Назначение кода:
# Сервис lotteries EFHC Bot: витрины, покупка билетов (денежная
# операция),
# админ-операции (создание, закрытие продаж, розыгрыш), выборки с
# курсором.
#
# Канон/инварианты:
# • Денежные списания за билеты идут через единый банковский сервис
# EFHC.
# • Строгое правило списаний: СНАЧАЛА bonus_balance, затем main_balance.
# • Пользователь НИКОГДА не уходит в минус (жёсткий запрет).
# • Банк может уйти в минус — это допустимо (операции не блокируются).
# • Любые денежные POST — с Idempotency-Key. Здесь реализован read-
# through:
# – бонусная часть: idk+":B"
# – основная часть: idk+":M"
# • Приз NFT не выдаётся автоматически — только заявка (claim), ручная
# выдача.
#
# ИИ-защита/самовосстановление:
# • Все выборки — курсорные (без OFFSET), устойчивые к перегрузкам.
# • Идемпотентность опирается на уникальные ключи банковских логов.
# • Блокировка гонок: SELECT ... FOR UPDATE SKIP LOCKED по строке
# лотереи
# при распределении билетов, чтобы не продать один и тот же номер
# дважды.
#
# Запреты:
# • Никаких P2P, обратных конверсий и прочих нестандартных списаний.
# • Никаких суточных ставок — подсистема лотерей не знает о генерации
# энергии.
# ======================================================================

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

import sqlalchemy as sa
from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.models.lotteries_models import (
    Lotteries,
    LotteriesBuyIdempotency,
    LotteriesNFTClaim,
    LotteriesResult,
    LotteriesTicket,
    LotteriesUserStat,
)
from app.models.user_models import User
from fastapi import HTTPException, status
from sqlalchemy import and_, asc, desc, select
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)


def _require_wallet_for_nft_ticket_purchase(
    wallet_addr: str | None,
) -> str:
    """SSOT: VIP NFT билеты покупаются только с кошельком.

    Возвращает нормализованный адрес или кидает HTTP 409.
    """
    from fastapi import HTTPException

    if not wallet_addr or not str(wallet_addr).strip():
        raise HTTPException(
            status_code=409,
            detail="wallet_required_for_vip_nft",
        )
    return str(wallet_addr).strip()


settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# ----------------------------------------------------------------------
# DTO/утилиты
# ----------------------------------------------------------------------


@dataclass
class CursorPoint:
    created_at: datetime
    id: int



# ----------------------------------------------------------------------
# SSOT: lotteries ticket counts
# ----------------------------------------------------------------------
# Канон: EFHC prize lotteries = 200 tickets (исторический дефолт).
# Канон: NFT prize lotteries = 1000 tickets (по требованию канона).
DEFAULT_LOTTERIES_TOTAL_TICKETS_EFHC = 200
DEFAULT_LOTTERIES_TOTAL_TICKETS_NFT = 1000


def _build_cursor(items: Sequence[dict]) -> CursorPoint | None:
    """Функция `_build_cursor` выполняет операцию в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля (см. имя функции и
    вызывающий код).

    Параметры:
    - `items` (Sequence[dict]): входной параметр.

    Возвращает:
    - Значение типа/структуры: Optional[CursorPoint].

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли (идемпотентность
    достигается ключами/уникальными ограничениями).
    - Денежные значения в EFHC учитываются с точностью d8 и округлением
    вниз (ROUND_DOWN), если применимо по модулю.
    - Для операций, затрагивающих баланс/банк, изменения должны
      проходить через transactions_service.
    """
    if not items:
        return None
    last = items[-1]
    return CursorPoint(created_at = last["created_at"], id = last["id"])


def _cursor_filter(q, cursor: CursorPoint | None):
    """
    Для стабильной пагинации по возрастанию (created_at, id).
    """
    if not cursor:
        return q
    return q.where((Lotteries.created_at > cursor.created_at)
        | and_(
            Lotteries.created_at == cursor.created_at,
            Lotteries.id > cursor.id,
        ))


# ----------------------------------------------------------------------
# Bootstrap: гарантируем наличие 2 активных розыгрышей (EFHC и VIP).
# ----------------------------------------------------------------------


async def _ensure_default_rounds(db: AsyncSession) -> None:
    """SSOT: в системе всегда должны быть активные розыгрыши.

    Нет таймеров: розыгрыш завершается по sold-out и тут же
    создаётся следующий.
    """
    # Ищем любую активную EFHC и любую активную VIP(NFT).
    q = select(Lotteries.id, Lotteries.prize_type).where(
        Lotteries.status == "active",
    )
    rows = (await db.execute(q)).all()
    has_efhc = any(str(r.prize_type).upper() == "EFHC" for r in rows)
    has_nft = any(str(r.prize_type).upper() == "NFT" for r in rows)

    now = datetime.now(UTC)

    if not has_efhc:
        db.add(
            Lotteries(
                title="Lotteries EFHC",
                prize_type="EFHC",
                prize_value=str(settings.LOTTERIES_EFHC_PRIZE_BONUS_D8),
                ticket_price=d8(
                    settings.LOTTERIES_EFHC_TICKET_PRICE_D8,
                ),
                max_participants=100000,
                max_tickets_per_user=int(
                    settings.LOTTERIES_MAX_TICKETS_PER_USER
                ),
                total_tickets=int(
                    settings.LOTTERIES_EFHC_TOTAL_TICKETS,
                ),
                tickets_sold=0,
                status="active",
                auto_lotteries=True,
                restart_of_lotteries_id=None,
                created_at=now,
                updated_at=now,
            )
        )

    if not has_nft:
        db.add(
            Lotteries(
                title="Lotteries VIP NFT EFHC",
                prize_type="NFT",
                prize_value=str(settings.LOTTERIES_VIP_PRIZE_NFT_CODE),
                ticket_price=d8(
                    settings.LOTTERIES_VIP_TICKET_PRICE_D8,
                ),
                max_participants=100000,
                max_tickets_per_user=int(
                    settings.LOTTERIES_MAX_TICKETS_PER_USER
                ),
                total_tickets=int(
                    settings.LOTTERIES_VIP_TOTAL_TICKETS,
                ),
                tickets_sold=0,
                status="active",
                auto_lotteries=True,
                restart_of_lotteries_id=None,
                created_at=now,
                updated_at=now,
            )
        )
# ----------------------------------------------------------------------
# Витрина активных лотерей
# ----------------------------------------------------------------------

async def svc_list_active_lotteries(db: AsyncSession,
    limit: int,
    cursor: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    """Возвращает активные lotteries (status='active')
    с курсорной пагинацией.

    Cursor SSOT:
      - cursor payload всегда dict.
      - ожидаемые ключи: created_at (ISO str), id (int).
    """
    await _ensure_default_rounds(db)
    cur_point: CursorPoint | None = None
    if cursor:
        try:
            cur_point = CursorPoint(
                created_at=datetime.fromisoformat(
                    str(cursor.get("created_at")),
                ),
                id = int(cursor.get("id")),)
        except Exception:
            cur_point = None

    base_q = (select(Lotteries.id,
            Lotteries.title,
            Lotteries.prize_type,
            Lotteries.prize_value,
            Lotteries.ticket_price,
            Lotteries.total_tickets,
            Lotteries.tickets_sold,
            Lotteries.status,
            Lotteries.created_at,)
        .where(Lotteries.status == "active")
        .order_by(asc(Lotteries.created_at), asc(Lotteries.id))
        .limit(limit))
    q = _cursor_filter(base_q, cur_point)
    rows = (await db.execute(q)).all()

    items = [
        {
            "id": r.id,
            "title": r.title,
            "prize_type": r.prize_type,
            "prize_value": r.prize_value,
            "ticket_price": d8(r.ticket_price),
            "total_tickets": r.total_tickets,
            "tickets_sold": r.tickets_sold,
            "status": r.status,
            "created_at": r.created_at,
        }
        for r in rows
    ]

    next_cur = _build_cursor(items)
    next_payload = (
        {
            "created_at": next_cur.created_at.isoformat(),
            "id": int(next_cur.id),
        }
        if next_cur
        else None)
    return items, next_payload


# ----------------------------------------------------------------------
# История lotteries (админ‑витрина)
# ----------------------------------------------------------------------


def _cursor_filter_desc(q, cur: CursorPoint | None):
    """Фильтр курсора для сортировки DESC (created_at DESC, id DESC)."""
    if not cur:
        return q
    # Для DESC берём элементы "строго меньше" текущей точки
    return q.where((Lotteries.created_at < cur.created_at)
        | (
            (Lotteries.created_at == cur.created_at)
            & (Lotteries.id < cur.id)
        ))

async def svc_list_lotteries_history(db: AsyncSession,
    limit: int,
    cursor: dict[str, Any] | None = None,
    status_in: list[str] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    """Возвращает историю lotteries (closed/completed по умолчанию),
    включая результат (если он есть).

    Cursor SSOT:
      - cursor payload всегда dict.
      - ожидаемые ключи: created_at (ISO str), id (int).
    """
    cur_point: CursorPoint | None = None
    if cursor:
        try:
            cur_point = CursorPoint(
                created_at=datetime.fromisoformat(
                    str(cursor.get("created_at")),
                ),
                id=int(cursor.get("id")),)
        except Exception:
            cur_point = None

    statuses = status_in or ["completed", "closed"]
    base_q = (select(Lotteries.id,
            Lotteries.title,
            Lotteries.prize_type,
            Lotteries.prize_value,
            Lotteries.ticket_price,
            Lotteries.total_tickets,
            Lotteries.tickets_sold,
            Lotteries.status,
            Lotteries.created_at,
            LotteriesResult.winning_ticket_id,
            LotteriesResult.winner_tg_id,
            LotteriesResult.completed_at,)
        .select_from(Lotteries)
        .outerjoin(
            LotteriesResult,
            LotteriesResult.lotteries_id == Lotteries.id,
        )
        .where(Lotteries.status.in_(statuses))
        .order_by(desc(Lotteries.created_at), desc(Lotteries.id))
        .limit(limit))

    q = _cursor_filter_desc(base_q, cur_point)
    rows = (await db.execute(q)).all()

    items: list[dict[str, Any]] = []
    for r in rows:
        result = None
        if (
            r.winning_ticket_id is not None
            and r.winner_tg_id is not None
            and r.completed_at is not None
        ):
            result = {
                "winning_ticket_id": int(r.winning_ticket_id),
                "winner_tg_id": int(r.winner_tg_id),
                "completed_at": str(r.completed_at),
            }

        items.append({
                "id": r.id,
                "title": r.title,
                "prize_type": r.prize_type,
                "prize_value": r.prize_value,
                "ticket_price": d8(r.ticket_price),
                "total_tickets": r.total_tickets,
                "tickets_sold": r.tickets_sold,
                "status": r.status,
                "created_at": r.created_at,
                "result": result,
            })

    next_cur = _build_cursor_desc(items)
    next_payload = (
        {
            "created_at": next_cur.created_at.isoformat(),
            "id": int(next_cur.id),
        }
        if next_cur
        else None
    )
    return items, next_payload


def _build_cursor_desc(
    items: list[dict[str, Any]],
) -> CursorPoint | None:
    """Берёт последнюю строку в текущей странице (DESC) и делает курсор
    после неё."""
    if not items:
        return None
    last = items[-1]
    try:
        return CursorPoint(
            created_at=last["created_at"],
            id=int(last["id"]),
        )
    except Exception:
        return None

# ----------------------------------------------------------------------
# Статус лотереи
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# Winners (latest finished for each type)
# ----------------------------------------------------------------------

async def svc_get_latest_winners(
    db: AsyncSession,
) -> dict[str, Any]:
    """Возвращает последние завершённые winners по типам призов."""
    q = (
        select(
            Lotteries.id,
            Lotteries.title,
            Lotteries.prize_type,
            Lotteries.prize_value,
            LotteriesResult.winning_ticket_id,
            LotteriesResult.winner_tg_id,
            LotteriesResult.completed_at,
            User.username,
        )
        .select_from(Lotteries)
        .join(
            LotteriesResult,
            LotteriesResult.lotteries_id == Lotteries.id,
        )
        .join(
            User,
            User.tg_id == LotteriesResult.winner_tg_id,
            isouter=True,
        )
        .where(Lotteries.status == "completed")
        .order_by(desc(Lotteries.finished_at), desc(Lotteries.id))
        .limit(50)
    )
    rows = (await db.execute(q)).all()
    out: dict[str, Any] = {}
    for r in rows:
        pt = str(r.prize_type).upper()
        if pt in out:
            continue
        out[pt] = {
            "lotteries_id": int(r.id),
            "title": str(r.title),
            "prize_type": str(r.prize_type),
            "prize_value": str(r.prize_value),
            "winning_ticket_id": int(r.winning_ticket_id),
            "winning_ticket_number": int(r.winning_ticket_id),
            "winner_tg_id": int(r.winner_tg_id),
            "winner_username": (
                
                    str(r.username)
                    if getattr(r, "username", None)
                    else None
                
            ),
            "completed_at": (
                r.completed_at.isoformat()
                if getattr(r.completed_at, "isoformat", None)
                else str(r.completed_at)
            ),
        }
        if len(out) >= 2:
            break
    return out

async def svc_get_lotteries_status(
    db: AsyncSession,
    lotteries_id: int,
) -> dict[str, Any] | None:
    """EFHC Bot: сервисная функция бизнес-логики.
    
    Правила:
    - Идемпотентность: ключи/уникальные ограничения.
    - EFHC суммы: d8, ROUND_DOWN при необходимости.
    - Баланс/банк: только через transactions_service.
    """
    lot = (
        await db.execute(
            select(Lotteries).where(Lotteries.id == lotteries_id),
        )
    ).scalar_one_or_none()
    if not lot:
        return None

    result = (
        await db.execute(
            select(LotteriesResult).where(
                LotteriesResult.lotteries_id == lotteries_id,
            ),
        )
    ).scalar_one_or_none()

    result_payload = None
    if result:
        result_payload = {
            "winning_ticket_id": result.winning_ticket_id,
            "winner_tg_id": result.winner_tg_id,
            "completed_at": result.completed_at.isoformat(),
        }

    return {
        "id": lot.id,
        "title": lot.title,
        "prize_type": lot.prize_type,
        "prize_value": lot.prize_value,
        "ticket_price": d8(lot.ticket_price),
        "total_tickets": lot.total_tickets,
        "tickets_sold": lot.tickets_sold,
        "status": lot.status,
        "result": result_payload,
    }

# ----------------------------------------------------------------------
# Мои билеты (курсорно)
# ----------------------------------------------------------------------

async def svc_list_user_tickets(db: AsyncSession,
    lotteries_id: int,
    tg_id: int,
    limit: int,
    cursor: dict[str, Any] | None = None,
) -> tuple[list[int], dict[str, Any] | None]:
    """Возвращает ID билетов пользователя по возрастанию
    ticket_id (курсорно).

    Cursor SSOT:
      - cursor payload всегда dict.
      - ожидаемый ключ: ticket_id (int) — последний возвращённый
      ticket_id.
    """
    last_id = 0
    if cursor:
        try:
            last_id = int(cursor.get("ticket_id") or 0)
        except Exception:
            last_id = 0

    rows = (await db.execute(select(LotteriesTicket.ticket_id)
            .where(LotteriesTicket.lotteries_id == lotteries_id,
                LotteriesTicket.owner_tg_id == tg_id,
                LotteriesTicket.ticket_id > last_id,)
            .order_by(asc(LotteriesTicket.ticket_id))
            .limit(limit))).all()

    tickets = [r.ticket_id for r in rows]
    next_payload = {"ticket_id": int(tickets[-1])} if tickets else None
    return tickets, next_payload

# ----------------------------------------------------------------------
# Внутренние helpers
# ----------------------------------------------------------------------

async def _load_user_by_telegram(
    db: AsyncSession,
    tg_id: int,
) -> User | None:
    """EFHC Bot: сервисная функция бизнес-логики.
    
    Правила:
    - Идемпотентность: ключи/уникальные ограничения.
    - EFHC суммы: d8, ROUND_DOWN при необходимости.
    - Баланс/банк: только через transactions_service.
    """
    return (
        await db.execute(
            select(User).where(User.tg_id == tg_id),
        )
    ).scalar_one_or_none()


async def _lock_lotteries(
    db: AsyncSession,
    lotteries_id: int,
) -> Lotteries | None:
    """
    Блокируем строку лотереи на время распределения билетов.
    """
    lot = (await db.execute(select(Lotteries)
            .where(Lotteries.id == lotteries_id)
            .with_for_update(skip_locked = True))).scalar_one_or_none()
    return lot


def _compute_spend_parts(
    total: Decimal,
    bonus_balance: Decimal,
) -> tuple[Decimal, Decimal]:
    """
    Возвращает (spend_bonus, spend_main) при правиле bonus-first.
    """
    use_bonus = min(bonus_balance, total)
    use_main = total - use_bonus
    return d8(use_bonus), d8(use_main)

async def _append_tickets_and_stats(db: AsyncSession,
    lot: Lotteries,
    buyer_tg: int,
    quantity: int,) -> tuple[list[int], int]:
    """
    Распределяет билеты [old_sold+1 .. old_sold+quantity], обновляет
    счётчики и stats.
    Предполагается, что lot уже заблокирован (FOR UPDATE SKIP LOCKED).
    """
    if lot.status != "active":
        raise ValueError("Продажи закрыты или лотерея завершена.")

    if lot.tickets_sold + quantity > lot.total_tickets:
        raise ValueError("Недостаточно доступных билетов.")

    start = lot.tickets_sold + 1
    end = lot.tickets_sold + quantity
    ticket_ids = list(range(start, end + 1))

    # Вставка билетов
    now = datetime.now(UTC)
    for t_id in ticket_ids:
        db.add(LotteriesTicket(lotteries_id = lot.id,
                ticket_id = t_id,
                owner_tg_id = buyer_tg,
                created_at = now,))

    # Обновляем счётчик в лотерее
    lot.tickets_sold = lot.tickets_sold + quantity
    lot.updated_at = now

    # Обновляем агрегат пользователя
    stat = (
        await db.execute(
            select(LotteriesUserStat).where(
                LotteriesUserStat.lotteries_id == lot.id,
                LotteriesUserStat.tg_id == buyer_tg,
            ),
        )
    ).scalar_one_or_none()

    if not stat:
        stat = LotteriesUserStat(lotteries_id = lot.id,
            tg_id = buyer_tg,
            tickets_count = quantity,
            updated_at = now,)
        db.add(stat)
    else:
        stat.tickets_count += quantity
        stat.updated_at = now

    return ticket_ids, lot.tickets_sold

# ----------------------------------------------------------------------
# Покупка билетов с bonus-first списанием и read-through
# идемпотентностью
# ----------------------------------------------------------------------

async def svc_buy_tickets(
    db: AsyncSession,
    lotteries_id: int,
    tg_id: int,
    qty: int,
    idempotency_key: str,
    wallet_address: str | None = None,
) -> dict[str, Any]:
    """Денежная операция: купить билеты.

    SSOT:
    - списание BONUS -> MAIN (bonus-first)
    - пользователь не уходит в минус
    - max 10 билетов на пользователя на один розыгрыш
    - при недостатке билетов: частично исполняем по остатку
    - при недостатке средств: отклоняем (409)
    - для VIP NFT: требуется привязанный TON wallet (wallet_bindings)
    - read-through идемпотентность по Idempotency-Key
    """
    if qty < 1 or qty > 10:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="qty вне диапазона 1..10.",
        )

    existing = (
        await db.execute(
            select(LotteriesBuyIdempotency).where(
                LotteriesBuyIdempotency.tg_id == int(tg_id),
                LotteriesBuyIdempotency.idempotency_key == str(
                    idempotency_key,
                ),
            ),
        )
    ).scalar_one_or_none()
    if existing:
        ids: list[int] = []
        try:
            ids = list(existing.ticket_ids.get("ticket_ids") or [])
        except Exception:
            ids = []
        return {
            "lotteries_id": int(existing.lotteries_id),
            "qty": int(existing.qty),
            "ticket_ids": [int(x) for x in ids],
            "total_cost_efhc": "0.00000000",
            "debit_bonus_efhc": "0.00000000",
            "debit_main_efhc": "0.00000000",
            "meta": {
                "replayed": True,
                "idempotency_key": str(idempotency_key),
            },
        }

    user = await _load_user_by_telegram(db, int(tg_id))
    if not user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Пользователь не найден.",
        )

    lot = await _lock_lotteries(db, int(lotteries_id))
    if not lot:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Лотерея занята параллельной операцией.",
        )
    if lot.status != "active":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Продажи закрыты.",
        )

    remaining = int(lot.total_tickets or 0) - int(lot.tickets_sold or 0)
    if remaining <= 0:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Sold out.",
        )

    requested_qty = int(qty)
    if qty > remaining:
        qty = int(remaining)

    max_per_user = int(lot.max_tickets_per_user or 0) or 10
    stat = (
        await db.execute(
            select(LotteriesUserStat).where(
                LotteriesUserStat.lotteries_id == int(lot.id),
                LotteriesUserStat.tg_id == int(tg_id),
            ),
        )
    ).scalar_one_or_none()
    already = int(stat.tickets_count) if stat else 0
    if already + int(qty) > int(max_per_user):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Max tickets per user exceeded.",
        )

    wallet_snapshot: str | None = None
    if str(lot.prize_type).upper() == "NFT":
        wallet_snapshot = await _require_wallet_for_nft_ticket_purchase(
            db=db,
            tg_id=int(tg_id),
            feature="lotteries",
            wallet_address=wallet_address,
        )

    price = d8(lot.ticket_price)
    total_cost = d8(price * d8(Decimal(int(qty))))
    bonus_balance = d8(getattr(user, "bonus_balance", Decimal("0")))
    spend_bonus, spend_main = _compute_spend_parts(
        total=total_cost,
        bonus_balance=bonus_balance,
    )

    main_balance = d8(getattr(user, "main_balance", Decimal("0")))
    if d8(bonus_balance + main_balance) < total_cost:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Insufficient funds.",
        )

    from app.services.transactions_service import (
        spend_user_to_bank_bonus_then_main,
    )

    await spend_user_to_bank_bonus_then_main(
        db,
        tg_id=int(tg_id),
        amount=d8(total_cost),
        reason="lotteries_buy_tickets",
        idempotency_key=str(idempotency_key),
        meta={
            "lotteries_id": int(lot.id),
            "requested_qty": int(requested_qty),
            "final_qty": int(qty),
        },
    )

    ticket_ids, _new_sold = await _append_tickets_and_stats(
        db,
        lot=lot,
        buyer_tg=int(tg_id),
        quantity=int(qty),
    )

    if str(lot.prize_type).upper() == "NFT":
        now = datetime.now(UTC)
        for t_id in ticket_ids:
            db.add(
                LotteriesNFTClaim(
                    lotteries_id=int(lot.id),
                    ticket_id=int(t_id),
                    owner_tg_id=int(tg_id),
                    status="pending",
                    wallet_address=str(wallet_snapshot)
                    if wallet_snapshot
                    else None,
                    meta={
                        "nft_code": str(
                            settings.LOTTERIES_VIP_PRIZE_NFT_CODE,
                        ),
                        "use_current_wallet_on_issue": True,
                    },
                    created_at=now,
                )
            )

    db.add(
        LotteriesBuyIdempotency(
            tg_id=int(tg_id),
            idempotency_key=str(idempotency_key),
            lotteries_id=int(lot.id),
            qty=int(qty),
            ticket_ids={"ticket_ids": [int(x) for x in ticket_ids]},
        )
    )

    auto = await _auto_lotteries_if_sold_out(
        db=db,
        lot=lot,
        idempotency_key=str(idempotency_key),
    )

    return {
        "lotteries_id": int(lot.id),
        "qty": int(qty),
        "ticket_ids": [int(x) for x in ticket_ids],
        "total_cost_efhc": str(d8(total_cost)),
        "debit_bonus_efhc": str(d8(spend_bonus)),
        "debit_main_efhc": str(d8(spend_main)),
        "meta": {
            "requested_qty": int(requested_qty),
            "final_qty": int(qty),
            "auto_lotteries": bool(auto.get("auto_lotteries")),
            "new_lotteries_id": auto.get("new_lotteries_id"),
        },
    }


async def _get_current_wallet_for_tg_id(
    db: AsyncSession,
    tg_id: int,
) -> str | None:
    """Возвращает текущий primary wallet пользователя из БД."""
    try:
        from app.models.wallets_models import WalletBinding
    except Exception:
        return None

    row = (
        await db.execute(
            select(WalletBinding.wallet_address).where(
                WalletBinding.tg_id == int(tg_id),
                WalletBinding.is_active.is_(True),
                WalletBinding.is_primary.is_(True),
            )
        )
    ).scalar_one_or_none()
    if row:
        return str(row)

    row2 = (
        await db.execute(
            select(WalletBinding.wallet_address).where(
                WalletBinding.tg_id == int(tg_id),
                WalletBinding.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    return str(row2) if row2 else None


async def _require_wallet_for_nft_ticket_purchase(
    db: AsyncSession,
    tg_id: int,
    feature: str,
    wallet_address: str | None = None,
) -> str:
    """SSOT: VIP NFT покупка требует кошелёк (из профиля)."""
    _ = (feature, wallet_address)
    w = await _get_current_wallet_for_tg_id(db, int(tg_id))
    if w:
        return str(w)

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "code": "WALLET_REQUIRED",
            "details": {"feature": "lotteries"},
        },
    )


async def _auto_lotteries_if_sold_out(
    db: AsyncSession,
    lot: Lotteries,
    idempotency_key: str,
) -> dict[str, Any]:
    """SSOT: sold-out -> закрыть lotteries, выбрать winner,
    выдать приз и создать новый lotteries.
    """
    if int(lot.tickets_sold or 0) < int(lot.total_tickets or 0):
        return {"ok": True, "auto_lotteries": False}

    existing = (
        await db.execute(
            select(LotteriesResult).where(
                LotteriesResult.lotteries_id == int(lot.id),
            ),
        )
    ).scalar_one_or_none()
    if existing:
        return {
            "ok": True,
            "auto_lotteries": True,
            "new_lotteries_id": None,
        }

    import secrets

    total = int(lot.total_tickets or 0)
    seed_hex = secrets.token_hex(32)
    win_ticket_id = int(secrets.randbelow(total)) + 1

    owner = (
        await db.execute(
            select(LotteriesTicket.owner_tg_id).where(
                LotteriesTicket.lotteries_id == int(lot.id),
                LotteriesTicket.ticket_id == int(win_ticket_id),
            ),
        )
    ).scalar_one_or_none()
    if owner is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Winner ticket owner not found.",
        )

    now = datetime.now(UTC)
    db.add(
        LotteriesResult(
            lotteries_id=int(lot.id),
            winning_ticket_id=int(win_ticket_id),
            winner_tg_id=int(owner),
            winner_seed_hex=str(seed_hex),
            completed_at=now,
        )
    )

    if str(lot.prize_type).upper() == "EFHC":
        from app.services.transactions_service import (
            credit_user_bonus_from_bank_by_tg_id,
        )

        prize_idk = f"{idempotency_key}:lotteries_prize"
        await credit_user_bonus_from_bank_by_tg_id(
            db=db,
            tg_id=int(owner),
            amount=d8(settings.LOTTERIES_EFHC_PRIZE_BONUS_D8),
            idempotency_key=str(prize_idk),
            reason="lotteries_prize_bonus",
            meta={
                "lotteries_id": int(lot.id),
                "ticket_id": int(win_ticket_id),
            },
        )

    lot.status = "completed"
    lot.finished_at = now
    lot.updated_at = now

    new_id: int | None = None
    if bool(lot.auto_lotteries):
        r = await _auto_restart_lotteries(
            db=db,
            lot=lot,
            idempotency_key=str(idempotency_key),
        )
        try:
            new_id = int(r.get("new_lotteries_id"))
        except Exception:
            new_id = None

    return {
        "ok": True,
        "auto_lotteries": True,
        "new_lotteries_id": new_id,
    }

async def _auto_restart_lotteries(
    db: AsyncSession,
    lot: Lotteries,
    idempotency_key: str,
) -> dict[str, Any]:
    """SSOT: после завершения lotteries создаём новый активный
    lotteries-клон.

    Scheduler не нужен: это часть атомарного бизнес-потока.
    """
    _ = idempotency_key
    now = datetime.now(UTC)
    new_lot = Lotteries(
        title=str(lot.title),
        prize_type=str(lot.prize_type),
        prize_value=lot.prize_value,
        ticket_price=d8(lot.ticket_price),
        max_participants=int(
            lot.max_participants or lot.total_tickets or 0,
        ),
        max_tickets_per_user=int(
            getattr(lot, "max_tickets_per_user", 0) or 0,
        ),
        total_tickets=int(lot.total_tickets or 0),
        tickets_sold=0,
        status="active",
        auto_lotteries=bool(lot.auto_lotteries),
        created_at=now,
        updated_at=now,
        restart_of_lotteries_id=int(lot.id),
    )
    db.add(new_lot)
    await db.flush()

    # SSOT: хранить 1000 завершённых розыгрышей, старше удалять.
    keep = 1000
    res = await db.execute(
        select(Lotteries.id)
        .where(
            Lotteries.prize_type == str(lot.prize_type),
            Lotteries.status == "completed",
        )
        .order_by(desc(Lotteries.finished_at), desc(Lotteries.id))
        .offset(int(keep))
        .limit(2000),
    )
    old_ids = list(res.scalars().all())
    if old_ids:
        await db.execute(
            sa.delete(Lotteries).where(Lotteries.id.in_(old_ids)),
        )

    return {"ok": True, "new_lotteries_id": int(new_lot.id)}


async def _force_lotteries_internal(
    db: AsyncSession,
    lot: Lotteries,
    idempotency_key: str,
) -> dict[str, Any]:
    """Админ: принудительно завершить lotteries.

    Выбираем случайный билет из проданных (1 билет = 1 шанс),
    создаём LotteriesResult и выдаём приз победителю.
    """
    existing = (
        await db.execute(
            select(LotteriesResult).where(
                LotteriesResult.lotteries_id == int(lot.id),
            )
        )
    ).scalar_one_or_none()
    if existing:
        return {
            "ok": True,
            "status": "completed",
            "idempotency": "read-through",
        }

    sold = (
        await db.execute(
            select(
                LotteriesTicket.ticket_id,
                LotteriesTicket.owner_tg_id,
            )
            .where(LotteriesTicket.lotteries_id == int(lot.id))
            .order_by(LotteriesTicket.ticket_id.asc())
        )
    ).all()
    if not sold:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="No tickets sold.",
        )

    import secrets

    seed_hex = secrets.token_hex(32)
    win_idx = int(secrets.randbelow(len(sold)))
    win_ticket_id, owner = sold[win_idx]

    now = datetime.now(UTC)
    db.add(
        LotteriesResult(
            lotteries_id=int(lot.id),
            winning_ticket_id=int(win_ticket_id),
            winner_tg_id=int(owner),
            winner_seed_hex=str(seed_hex),
            completed_at=now,
        )
    )

    if str(lot.prize_type).upper() == "EFHC":
        from app.services.transactions_service import (
            credit_user_bonus_from_bank_by_tg_id,
        )

        prize_idk = f"{idempotency_key}:lotteries_prize"
        await credit_user_bonus_from_bank_by_tg_id(
            db=db,
            tg_id=int(owner),
            amount=d8(settings.LOTTERIES_EFHC_PRIZE_BONUS_D8),
            idempotency_key=str(prize_idk),
            reason="lotteries_prize_bonus",
            meta={
                "lotteries_id": int(lot.id),
                "ticket_id": int(win_ticket_id),
            },
        )

    lot.status = "completed"
    lot.finished_at = now
    lot.updated_at = now

    new_id: int | None = None
    if bool(lot.auto_lotteries):
        r = await _auto_restart_lotteries(
            db=db,
            lot=lot,
            idempotency_key=str(idempotency_key),
        )
        try:
            new_id = int(r.get("new_lotteries_id"))
        except Exception:
            new_id = None

    return {
        "ok": True,
        "status": str(lot.status),
        "winner_tg_id": int(owner),
        "winning_ticket_id": int(win_ticket_id),
        "new_lotteries_id": new_id,
    }


# ----------------------------------------------------------------------
# Админ: создание лотереи
# ----------------------------------------------------------------------


async def svc_admin_create_lotteries(
    db: AsyncSession,
    admin_tg_id: int,
    payload: dict[str, Any],
    idempotency_key: str,
) -> dict[str, Any]:
    """Создать lotteries.

    Денежных списаний нет, но применяем идемпотентность
    на уровне бизнес-объекта: повтор с тем же idk
    должен вернуть ту же lotteries.
    объекта: повтор с тем же idk должен вернуть ту же lotteries.
    """
    _ = (admin_tg_id, idempotency_key)
    now = datetime.now(UTC)
    title = str(payload["title"]).strip()
    prize_type = str(payload["prize_type"]).strip()
    prize_value = payload.get("prize_value")
    ticket_price = d8(payload["ticket_price"])
    max_participants = int(payload.get("max_participants") or 0)
    max_per_user = int(payload.get("max_tickets_per_user") or 0)

    if prize_type.upper() == "NFT":
        max_participants = DEFAULT_LOTTERIES_TOTAL_TICKETS_NFT
        if max_per_user <= 0:
            max_per_user = 10
    else:
        if max_participants <= 0:
            max_participants = DEFAULT_LOTTERIES_TOTAL_TICKETS_EFHC
        if max_per_user <= 0:
            max_per_user = 10

    auto_lotteries = bool(payload.get("auto_lotteries", True))

    cutoff = now - timedelta(minutes=5)
    res = await db.execute(
        select(Lotteries)
        .where(
            Lotteries.title == title,
            Lotteries.created_at >= cutoff,
        )
        .order_by(desc(Lotteries.created_at))
        .limit(1),
    )
    existing = res.scalar_one_or_none()
    if existing:
        return {
            "id": int(existing.id),
            "title": str(existing.title),
            "status": str(existing.status),
        }

    lot = Lotteries(
        title=title,
        prize_type=prize_type,
        prize_value=prize_value,
        ticket_price=ticket_price,
        max_participants=max_participants,
        max_tickets_per_user=max_per_user,
        total_tickets=max_participants,
        tickets_sold=0,
        status="active",
        auto_lotteries=auto_lotteries,
        created_at=now,
        updated_at=now,
    )
    db.add(lot)
    await db.flush()
    return {
        "id": int(lot.id),
        "title": str(lot.title),
        "status": lot.status,
    }


# ----------------------------------------------------------------------
# Админ: закрыть продажи
# ----------------------------------------------------------------------
async def svc_admin_close_sales(db: AsyncSession,
    admin_tg_id: int,
    lotteries_id: int,
    idempotency_key: str,) -> dict[str, Any]:
    """EFHC Bot: сервисная функция бизнес-логики.
    
    Правила:
    - Идемпотентность: ключи/уникальные ограничения.
    - EFHC суммы: d8, ROUND_DOWN при необходимости.
    - Баланс/банк: только через transactions_service.
    """
    lot = (await db.execute(select(Lotteries)
            .where(Lotteries.id == lotteries_id)
            .with_for_update(skip_locked = True))).scalar_one_or_none()
    if not lot:
        raise ValueError("Лотерея не найдена.")
    if lot.status != "active":
        return {"ok": True, "status": lot.status}

    lot.status = "closed"
    lot.updated_at = datetime.now(UTC)
    return {"ok": True, "status": lot.status}

# ----------------------------------------------------------------------
# Админ: принудительный розыгрыш
# ----------------------------------------------------------------------

async def svc_admin_force_lotteries(db: AsyncSession,
    admin_tg_id: int,
    lotteries_id: int,
    idempotency_key: str,) -> dict[str, Any]:
    """
    Розыгрыш: выбираем случайный билет из проданных (равномерно),
    фиксируем результат в LotteriesResult и переводим статус в
    'completed'.
    Если prize_type='EFHC' — начисление призовых EFHC победителю как
    БОНУСОВ.
    Если prize_type='NFT' — создаём LotteriesNFTClaim(status='pending').
    """
    lot = (await db.execute(select(Lotteries)
            .where(Lotteries.id == lotteries_id)
            .with_for_update(skip_locked = True))).scalar_one_or_none()
    if not lot:
        raise ValueError("Лотерея не найдена.")
    return await _force_lotteries_internal(
        db=db,
        lot=lot,
        idempotency_key=str(idempotency_key),
    )


async def svc_admin_set_auto_lotteries(
    db: AsyncSession,
    admin_tg_id: int,
    lotteries_id: int,
    enabled: bool,
) -> dict:
    """Включает/выключает auto_lotteries у лотереи.
    Тумблер авторозыгрыша."""
    lot = (
        await db.execute(
            select(Lotteries)
            .where(Lotteries.id == int(lotteries_id))
            .with_for_update(skip_locked=True),
        )
    ).scalar_one_or_none()
    if not lot:
        raise ValueError("Лотерея не найдена.")
    lot.auto_lotteries = bool(enabled)
    lot.updated_at = datetime.now(UTC)
    return {
        "ok": True,
        "lotteries_id": int(lot.id),
        "auto_lotteries": bool(lot.auto_lotteries),
    }