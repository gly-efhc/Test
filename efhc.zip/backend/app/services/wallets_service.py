"""Wallet bindings service for TonConnect.

SSOT rules:
- Wallet ownership and read-side queries use canonical ``global_id``.
- Telegram proof/connect remains provider-specific.
  It requires ``tg_id``.
- wallet_connected := at least one active verified wallet binding.
- /wallets/connect requires Idempotency-Key and a verified
  TonConnect proof bound to tg_id/domain/payload/address.

This module is infrastructure for wallet bindings only.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from hashlib import sha256
from typing import cast

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.identity.nonfinancial_read_switch import (
    resolve_nonfinancial_read_owner,
)
from app.lib.time import utcnow
from app.services import transactions_service as tx
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

# ---------------------------------------------------------------------
# Совместимость: watcher_service и тесты monkeypatch ожидают
# wallets_service.credit_user_from_bank.
# Денежная логика остаётся в transactions_service (канон).
# ---------------------------------------------------------------------


async def credit_user_from_bank(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
    amount_efhc: Decimal | None = None,
    amount: Decimal | None = None,
    reason: str,
    idempotency_key: str,
) -> tx.TxResult:
    """Compatibility facade над canonical transaction owner."""
    return await tx.credit_user_from_bank(
        db,
        tg_id=tg_id,
        global_id=global_id,
        amount_efhc=amount_efhc,
        amount=amount,
        reason=str(reason),
        idempotency_key=str(idempotency_key),
    )


logger = get_logger(__name__)
settings = get_settings()
CORE_SCHEMA: str = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# Совместимость: тесты ожидают эти статусы в wallets_service.
STATUS_CREDITED = "credited"
STATUS_ERROR_SYS = "error_retry"

# ---------------------------------------------------------------------
# ---------------------------------------------------------------------


class WalletConflict(Exception):
    pass


class InvalidWalletAddress(Exception):
    pass


class WalletProofRequired(Exception):
    pass


class WalletProofReplay(Exception):
    pass


def normalize_wallet_address(raw: str) -> str:
    """Return EFHC canonical TON address for wallet ownership."""
    from app.lib.ton_address import (
        TonAddressError,
        canonicalize_ton_address,
    )

    addr = str(raw or "").strip()
    if not addr:
        raise InvalidWalletAddress("INVALID_WALLET_ADDRESS")
    try:
        return cast(str, canonicalize_ton_address(addr))
    except TonAddressError as err:
        raise InvalidWalletAddress("INVALID_WALLET_ADDRESS") from err


@dataclass(slots=True)
class WalletBindingOut:
    id: int
    wallet_address: str
    wallet_app: str | None
    is_primary: bool
    is_active: bool
    created_at: str


async def list_wallets(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
) -> list[WalletBindingOut]:
    """Вернуть bindings по canonical ``global_id``."""
    owner = await resolve_nonfinancial_read_owner(
        db,
        tg_id=tg_id,
        global_id=global_id,
    )
    rows = (
        await db.execute(
            text(
                """
                SELECT id,
                       wallet_address,
                       wallet_app,
                       is_primary,
                       is_active,
                       created_at
                  FROM efhc_core.wallet_bindings
                 WHERE global_id = :global_id
                 ORDER BY is_primary DESC, id DESC
                """
            ),
            {"global_id": owner.global_id},
        )
    ).mappings().all()
    return [
        WalletBindingOut(
            id=int(row["id"]),
            wallet_address=str(row["wallet_address"]),
            wallet_app=(
                str(row["wallet_app"])
                if row["wallet_app"]
                else None
            ),
            is_primary=bool(row["is_primary"]),
            is_active=bool(row["is_active"]),
            created_at=str(row["created_at"]),
        )
        for row in rows
    ]


async def has_active_wallet(
    db: AsyncSession,
    *,
    tg_id: int | None = None,
    global_id: int | None = None,
) -> bool:
    """Проверить verified active binding canonical owner."""
    owner = await resolve_nonfinancial_read_owner(
        db,
        tg_id=tg_id,
        global_id=global_id,
    )
    result = await db.execute(
        text(
            """
            SELECT 1
              FROM efhc_core.wallet_bindings
             WHERE global_id = :global_id
               AND is_active = true
               AND proof_verified = true
             LIMIT 1
            """
        ),
        {"global_id": owner.global_id},
    )
    return bool(result.first())


def _proof_token_hash(payload_token: str) -> str:
    token = str(payload_token or "").strip()
    if not token:
        raise WalletProofRequired("TONCONNECT_PROOF_REQUIRED")
    return sha256(token.encode("utf-8")).hexdigest()


async def _ensure_verified_proof_not_used(
    db: AsyncSession,
    *,
    proof_payload_hash: str,
) -> None:
    row = (
        await db.execute(
            text("""
                SELECT 1
                  FROM efhc_core.wallet_proof_token_uses
                 WHERE proof_payload_hash = :proof_hash
                 LIMIT 1
                """),
            {"proof_hash": proof_payload_hash},
        )
    ).first()
    if row:
        raise WalletProofReplay("TONCONNECT_PROOF_REPLAY")


async def _mark_verified_proof_single_use(
    db: AsyncSession,
    *,
    global_id: int,
    wallet_address: str,
    proof_payload_hash: str,
    idempotency_key: str,
) -> None:
    res = await db.execute(
        text("""
            INSERT INTO efhc_core.wallet_proof_token_uses
                (tg_id, wallet_address, proof_payload_hash,
                 idempotency_key, created_at)
            VALUES
                (:tg_id, :addr, :proof_hash, :ik, :now)
            ON CONFLICT (proof_payload_hash) DO NOTHING
            RETURNING id
            """),
        {
            "tg_id": int(tg_id),
            "addr": wallet_address,
            "proof_hash": proof_payload_hash,
            "ik": idempotency_key,
            "now": utcnow(),
        },
    )
    if res.first() is None:
        raise WalletProofReplay("TONCONNECT_PROOF_REPLAY")


async def connect_wallet(
    db: AsyncSession,
    *,
    global_id: int,
    address: str,
    wallet_app: str | None,
    idempotency_key: str,
    verified_proof_payload_token: str,
    verified_proof_source: str,
) -> dict:
    logger.info(
        "wallet.connect attempt",
        extra={
            "audit__schema__version": "v1",
            "tg_id": tg_id,
            "event": "wallet_connect",
            "result": "attempt",
        },
    )

    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")
    proof_hash = _proof_token_hash(verified_proof_payload_token)
    proof_source = str(verified_proof_source or "").strip()
    if not proof_source:
        raise WalletProofRequired("TONCONNECT_PROOF_REQUIRED")

    q_idk = text("""
        SELECT wallet_id, wallet_address
          FROM efhc_core.wallet_connect_idempotency
         WHERE tg_id = :tg_id AND idempotency_key = :ik  
         LIMIT 1
        """)
    idk_row = (
        (
            await db.execute(
                q_idk, {"tg_id": tg_id, "ik": idempotency_key}
            )
        )
        .mappings()
        .first()
    )
    if idk_row:
        logger.info(
            "wallet.connect replay",
            extra={
                "audit__schema__version": "v1",
                "tg_id": tg_id,
                "event": "wallet_connect",
                "result": "replay",
            },
        )
        return {
            "wallet_id": int(idk_row["wallet_id"]),
            "wallet_address": str(idk_row["wallet_address"]),
            "is_connected": True,
        }

    addr = normalize_wallet_address(address)
    await _ensure_verified_proof_not_used(
        db,
        proof_payload_hash=proof_hash,
    )

    q_owner = text("""
        SELECT tg_id
          FROM efhc_core.wallet_bindings
         WHERE wallet_address = :addr
         LIMIT 1  
        """)
    owner = (await db.execute(q_owner, {"addr": addr})).first()
    if owner and int(owner[0]) != int(tg_id):
        logger.info(
            "wallet.connect conflict",
            extra={
                "audit__schema__version": "v1",
                "tg_id": tg_id,
                "event": "wallet_connect",
                "result": "conflict",
            },
        )
        raise WalletConflict("WALLET_CONFLICT")

    q_find = text("""
        SELECT id, is_active
          FROM efhc_core.wallet_bindings
         WHERE wallet_address = :addr AND tg_id = :tg_id
         LIMIT 1
        """)
    ex = await db.execute(q_find, {"addr": addr, "tg_id": tg_id})
    row = ex.mappings().first()

    now = utcnow()

    if row:
        wallet_id = int(row["id"])
        await db.execute(
            text("""
                UPDATE efhc_core.wallet_bindings
                   SET is_active = true,
                       proof_verified = true,
                       proof_verified_at = :now,
                       proof_payload_hash = :proof_hash,
                       proof_source = :proof_source,
                       wallet_app = COALESCE(:wallet_app, wallet_app),
                       updated_at = :now
                 WHERE id = :id
                """),
            {
                "id": wallet_id,
                "wallet_app": wallet_app,
                "proof_hash": proof_hash,
                "proof_source": proof_source,
                "now": now,
            },
        )
        await _mark_verified_proof_single_use(
            db,
            tg_id=tg_id,
            wallet_address=addr,
            proof_payload_hash=proof_hash,
            idempotency_key=idempotency_key,
        )
        await _save_connect_idempotency(
            db,
            tg_id=tg_id,
            idempotency_key=idempotency_key,
            wallet_id=wallet_id,
            wallet_address=addr,
        )
        await db.commit()
        return {
            "wallet_id": wallet_id,
            "wallet_address": addr,
            "is_connected": True,
        }

    ins = text("""
        INSERT INTO efhc_core.wallet_bindings
            (tg_id, wallet_address, wallet_app,
             is_primary, is_active, proof_verified,
             proof_verified_at, proof_payload_hash, proof_source,
             created_at, updated_at)
        VALUES
            (:tg_id, :addr, :wallet_app,
             false, true, true,
             :now, :proof_hash, :proof_source,
             :now, :now)
        RETURNING id
        """)
    wallet_id = int(
        (
            await db.execute(
                ins,
                {
                    "tg_id": tg_id,
                    "addr": addr,
                    "wallet_app": wallet_app,
                    "proof_hash": proof_hash,
                    "proof_source": proof_source,
                    "now": now,
                },
            )
        ).scalar_one()
    )

    await _mark_verified_proof_single_use(
        db,
        tg_id=tg_id,
        wallet_address=addr,
        proof_payload_hash=proof_hash,
        idempotency_key=idempotency_key,
    )

    # Make primary if none.
    q_has = text("""
        SELECT 1
          FROM efhc_core.wallet_bindings
         WHERE tg_id = :tg_id
           AND is_primary = true
           AND is_active = true
           AND proof_verified = true
         LIMIT 1
        """)
    if not (await db.execute(q_has, {"tg_id": tg_id})).first():
        await _make_primary_tx(db, tg_id=tg_id, wallet_id=wallet_id)

    await _save_connect_idempotency(
        db,
        tg_id=tg_id,
        idempotency_key=idempotency_key,
        wallet_id=wallet_id,
        wallet_address=addr,
    )

    await db.commit()
    logger.info(
        "wallet.connect ok",
        extra={
            "audit__schema__version": "v1",
            "tg_id": tg_id,
            "event": "wallet_connect",
            "result": "ok",
        },
    )
    return {
        "wallet_id": wallet_id,
        "wallet_address": addr,
        "is_connected": True,
    }


async def _save_connect_idempotency(
    db: AsyncSession,
    *,
    global_id: int,
    idempotency_key: str,
    wallet_id: int,
    wallet_address: str,
) -> None:
    now = utcnow()
    await db.execute(
        text("""
            INSERT INTO efhc_core.wallet_connect_idempotency
                (tg_id, idempotency_key, wallet_id, wallet_address,
                 created_at)
            VALUES
                (:tg_id, :ik, :wallet_id, :addr, :now)
            ON CONFLICT (tg_id, idempotency_key) DO NOTHING
            """),
        {
            "tg_id": tg_id,
            "ik": idempotency_key,
            "wallet_id": wallet_id,
            "addr": wallet_address,
            "now": now,
        },
    )


async def make_primary(
    db: AsyncSession,
    *,
    global_id: int,
    wallet_id: int,
) -> None:
    await _make_primary_tx(db, tg_id=tg_id, wallet_id=wallet_id)
    await db.commit()
    logger.info(
        "wallet.make_primary",
        extra={
            "audit__schema__version": "v1",
            "tg_id": tg_id,
            "event": "wallet_make_primary",
            "result": "ok",
        },
    )


async def admin_reset_wallet_bindings(
    db: AsyncSession,
    *,
    global_id: int,
) -> int:
    """Deactivate all canonical wallet bindings for admin wallet reset.

    This function intentionally does not commit. The caller must persist
    legacy users.ton_wallet cleanup, canonical binding reset and
    admin audit log in one transaction.
    """
    result = await db.execute(
        text("""
            UPDATE efhc_core.wallet_bindings
               SET is_active = false,
                   is_primary = false,
                   updated_at = :now
             WHERE global_id = :global_id
               AND (is_active = true OR is_primary = true)
            """),
        {"global_id": int(global_id), "now": utcnow()},
    )
    return int(getattr(result, "rowcount", 0) or 0)


async def deactivate_wallet(
    db: AsyncSession,
    *,
    tg_id: int,
    wallet_id: int,
) -> None:
    await db.execute(
        text("""
            UPDATE efhc_core.wallet_bindings
               SET is_active = false,
                   is_primary = false,
                   updated_at = :now
             WHERE id = :id AND tg_id = :tg_id
            """),
        {"id": wallet_id, "tg_id": tg_id, "now": utcnow()},
    )
    await db.commit()
    logger.info(
        "wallet.deactivate",
        extra={
            "audit__schema__version": "v1",
            "tg_id": tg_id,
            "event": "wallet_deactivate",
            "result": "ok",
        },
    )


async def _make_primary_tx(
    db: AsyncSession,
    *,
    tg_id: int,
    wallet_id: int,
) -> None:
    now = utcnow()
    await db.execute(
        text("""
            UPDATE efhc_core.wallet_bindings
               SET is_primary = false,
                   updated_at = :now
             WHERE tg_id = :tg_id
            """),
        {"tg_id": tg_id, "now": now},
    )
    await db.execute(
        text("""
            UPDATE efhc_core.wallet_bindings  
               SET is_primary = true,
                   is_active = true,
                   updated_at = :now
             WHERE id = :id AND tg_id = :tg_id
            """),
        {"id": wallet_id, "tg_id": tg_id, "now": now},
    )


# -------------------------------------------------------------------
# Compatibility wrapper for tests
# -------------------------------------------------------------------


async def _confirm_payment_intent(
    db,
    *,
    intent_id: int,
    global_id: int,
    purpose: str,
    payload: str,
    tx_hash: str,
    amount_asset,
    asset: str,
    to_address: str,
) -> str:
    """Совместимость: тесты вызывают
    wallets_service._confirm_payment_intent.

    Истина подтверждения находится в
    watcher_service._confirm_payment_intent.
    """
    from .watcher_service import _confirm_payment_intent as _c

    result = await _c(
        db,
        intent_id=int(intent_id),
        global_id=int(global_id),
        purpose=str(purpose),
        payload=str(payload),
        tx_hash=str(tx_hash),
        amount_asset=amount_asset,
        asset=str(asset),
        to_address=str(to_address),
    )
    return str(result)
