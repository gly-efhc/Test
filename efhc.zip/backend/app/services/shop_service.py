# -*- coding: utf-8 -*-
# backend/app/services/shop_service.py
# ====================================================================
# Назначение кода:
# Сервис магазина EFHC: каталожные позиции (сидер), витрины,
# создание заказов, генерация MEMO для внешних платежей
# (TON/USDT), внутренняя оплата EFHC (списание: сначала bonus,
# затем main), интеграция с Банком и Вотчером.
#
# Канон/инварианты:
# • Обмен только kWh→EFHC (1:1), обратной конверсии нет.
# • P2P запрещено. Любые движения EFHC — только «банк ↔ пользователь».
# • NFT — только заявка и ручная обработка.
# • EFHC-пакеты оплачиваются только внешне (TON/USDT).
#   Мы создаём заказ PENDING и генерируем MEMO.
#   оплата за EFHC запрещена.
# • Денежные POST — обязателен Idempotency-Key / client_nonce.
# • Пользователь не уходит в минус. Банк может (дефицит не блокирует).
#
# ИИ-защита/самовосстановление:
# • Идемпотентность: конфликт idempotency_key → вернуть
#   зафиксированный результат из логов; повторный вызов безопасен.
# • Лог-ориентированность: заказы и MEMO фиксируются в БД; вотчер
#   подхватывает оплату по tx_hash и обновляет статусы.
# • Витрина отдаёт флаги доступности и disabled_reason для UI;
#   кнопки деактивируются при минусе/недостатке средств/неподдержке.
#
# Запреты:
# • Никакой автодоставки NFT. Только заявка PAID_PENDING_MANUAL.
# • EFHC-пакеты оплачиваются только внешне (TON/USDT).
#   Мы создаём заказ PENDING и генерируем MEMO.
# • Никаких скрытых начислений, минуя Банк.
# ====================================================================

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple

from fastapi import HTTPException, status

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8, encode_cursor, decode_cursor
from app.services import transactions_service as bank

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# ---- Канонические типы/статусы
# ------------------------------------------------

ITEM_TYPE_EFHC_PACKAGE = "EFHC_PACKAGE"
# пакеты EFHC: 10..1000 (внешняя оплата)
ITEM_TYPE_NFT_VIP = "NFT_VIP"  # VIP NFT (TON/USDT/EFHC)
ITEM_TYPE_VIRTUAL = "VIRTUAL"
# прочие виртуальные товары (за EFHC внутри)

PAY_TON = "TON"
PAY_USDT = "USDT"
PAY_EFHC = "EFHC"

ORDER_STATUS_PENDING = "PENDING"  # заказ создан, ждём внешнюю оплату
ORDER_STATUS_PAID_AUTO = "PAID_AUTO"
# оплачен автоматически: внешний платёж подтверждён
# вотчером / авто-логика
ORDER_STATUS_PAID_PENDING_MANUAL = "PAID_PENDING_MANUAL"
# оплачен, ожидание ручной выдачи (NFT)
ORDER_STATUS_CANCELLED = "CANCELLED"
ORDER_STATUS_REJECTED = "REJECTED"

# ---- Вспомогательные DTO
# ------------------------------------------------------

@dataclass


class ShopItemDTO:
    id: int
    code: str
    title: str
    item_type: str
    is_active: bool
    price_efhc: Optional[Decimal]
    price_ton: Optional[Decimal]
    price_usdt: Optional[Decimal]
    pay_currencies: List[str]
    extra_json: Dict[str, Any]

@dataclass


class OrderDTO:
    id: int
    tg_id: int
    item_id: int
    status: str
    payment_method: Optional[str]
    memo: Optional[str]
    tx_hash: Optional[str]
    created_at: datetime

# ---- Утилиты
# ------------------------------------------------------------------


def _now_utc() -> datetime:
    """Функция `_now_utc` выполняет операцию
в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

    Возвращает:
    - Значение типа/структуры: datetime.

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
    - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
    - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
    return datetime.now(timezone.utc)


def _pay_methods_from_row(row) -> List[str]:
    # pay_currencies хранится как массив TEXT[] или JSON — нормализуем к
    # List[str]
    """Функция `_pay_methods_from_row` выполняет операцию
в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

    Параметры:
    - `row`: входной параметр.

    Возвращает:
    - Значение типа/структуры: List[str].

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
    - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
    - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
    val = row["pay_currencies"]
    if val is None:
        return []
    if isinstance(val, list):
        return [str(x) for x in val]
    if isinstance(val, str):
        # на случай JSON-строки
        try:
            import json
            arr = json.loads(val)
            if isinstance(arr, list):
                return [str(x) for x in arr]
            return []
        except Exception:
            return []
    return []

# ---- Сидер каталога под список EFHC-пакетов и VIP
# ----------------------------

async def seed_default_items(db: AsyncSession) -> Dict[str, Any]:
    """
    Идемпотентный сидер: создаёт (если нет) базовые карточки товаров.
    Цены НЕ жёсткие — будут отредактированы в админ-панели.
    """
    rockets = [10, 50, 100, 200, 300, 400, 500, 1000]
    inserts = 0
    updated = 0  # зарезервировано под будущие обновления

    # EFHC-пакеты (внешняя оплата TON/USDT)
    for qty in rockets:
        code = f"EFHC_{qty}"
        title = f"{qty} EFHC"
        pay_currencies = [PAY_TON, PAY_USDT]  # только внешние методы
        q = text(f"""
            INSERT INTO {SCHEMA}.shop_items
              (
               code,
               title,
               item_type,
               is_active,
               price_efhc,
               price_ton,
               price_usdt,
               pay_currencies,
               extra_json,
               created_at,
               updated_at
              )
            SELECT
                :code, :title, :itype, TRUE,
                NULL, NULL, NULL,
                :pays, :extra::jsonb,
                NOW(), NOW()
            WHERE NOT EXISTS (
                SELECT 1 FROM {SCHEMA}.shop_items WHERE code = :code
            )
            RETURNING id
        """)
        res = await db.execute(q, {
            "code": code,
            "title": title,
            "itype": ITEM_TYPE_EFHC_PACKAGE,
            "pays": pay_currencies,
            "extra": '{"quantity_efhc": %d}' % qty,
        })
        if res.fetchone():
            inserts += 1

    # VIP NFT — три карточки товара: за TON, USDT, EFHC
    vip_variants = [
        ("VIP_NFT_TON",  "VIP NFT (TON)",  [PAY_TON],  None, None),
        ("VIP_NFT_USDT", "VIP NFT (USDT)", [PAY_USDT], None, None),
        ("VIP_NFT_EFHC", "VIP NFT (EFHC)", [PAY_EFHC], None, None),
    ]
    for code, title, pays, price_ton, price_usdt in vip_variants:
        q = text(f"""
            INSERT INTO {SCHEMA}.shop_items
              (
               code,
               title,
               item_type,
               is_active,
               price_efhc,
               price_ton,
               price_usdt,
               pay_currencies,
               extra_json,
               created_at,
               updated_at
              )
            SELECT
                :code, :title, :itype, TRUE,
                NULL, :pt, :pu,
                :pays, :extra::jsonb,
                NOW(), NOW()
            WHERE NOT EXISTS (
                SELECT 1 FROM {SCHEMA}.shop_items WHERE code = :code
            )
            RETURNING id
        """)
        res = await db.execute(q, {
            "code": code,
            "title": title,
            "itype": ITEM_TYPE_NFT_VIP,
            "pt": price_ton,
            "pu": price_usdt,
            "pays": pays,
            "extra": (
                '{"nft_collection": "%s"}'
                % getattr(settings, "TON_NFT_COLLECTION", "")
            ),
        })
        if res.fetchone():
            inserts += 1

    await db.commit()
    return {"inserted": inserts, "updated": updated}

# ---- Балансы пользователя
# -----------------------------------------------------

async def _get_user_balances(
    db: AsyncSession,
    tg_id: int,
) -> Tuple[Decimal, Decimal]:
    """Асинхронная функция `_get_user_balances` выполняет операцию
в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

    Параметры:
    - `db` (AsyncSession): входной параметр.
    - `tg_id` (int): входной параметр.

    Возвращает:
    - Значение типа/структуры: Tuple[Decimal, Decimal].

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
    - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
    - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
    q = text(f"""
        SELECT COALESCE(main_balance,0) AS main_balance,
               COALESCE(bonus_balance,0) AS bonus_balance
        FROM {SCHEMA}.users WHERE id = :tg_id
        LIMIT 1
    """)
    row = (
        await db.execute(q, {"tg_id": tg_id})
    ).mappings().first()
    if not row:
        raise ValueError(f"User id = {tg_id} not found")
    return d8(row["main_balance"]), d8(row["bonus_balance"])

# ---- Загрузка каталога
# --------------------------------------------------------

async def _fetch_items(db: AsyncSession) -> List[ShopItemDTO]:
    """Асинхронная функция `_fetch_items` выполняет операцию
в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

    Параметры:
    - `db` (AsyncSession): входной параметр.

    Возвращает:
    - Значение типа/структуры: List[ShopItemDTO].

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
    - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
    - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
    q = text(f"""
        SELECT id, code, title, item_type, is_active,
               price_efhc,
               price_ton,
               price_usdt,
               pay_currencies,
               extra_json
        FROM {SCHEMA}.shop_items
        WHERE COALESCE(is_active, TRUE) = TRUE
        ORDER BY id ASC
    """)
    rows = (await db.execute(q)).mappings().all()
    items: List[ShopItemDTO] = []
    for r in rows:
        items.append(ShopItemDTO(id = r["id"],
            code = r["code"],
            title = r["title"],
            item_type = r["item_type"],
            is_active = bool(r["is_active"]),
            price_efhc=(
                d8(r["price_efhc"])
                if r["price_efhc"] is not None
                else None
            ),
            price_ton=(
                d8(r["price_ton"])
                if r["price_ton"] is not None
                else None
            ),
            price_usdt=(
                d8(r["price_usdt"])
                if r["price_usdt"] is not None
                else None
            ),
            pay_currencies = _pay_methods_from_row(r),
            extra_json = r["extra_json"] or {},))
    return items

# ---- Витрина магазина для пользователя
# ---------------------------------------

async def list_shop_for_user(
    db: AsyncSession,
    tg_id: int,
) -> Dict[str, Any]:
    """
    Витрина магазина для пользователя:
      • отдаёт весь активный каталог товаров;
      • по каждой карточке товара рассчитывает
        доступность кнопок по методам оплаты;
      • для EFHC-покупок — проверяет, хватает ли
        (bonus+main) и не в «минусе» ли пользователь.
    """
    main, bonus = await _get_user_balances(db, tg_id)
    total_efhc = d8(main + bonus)

    items = await _fetch_items(db)

    def check_efhc_afford(item: ShopItemDTO) -> Tuple[bool, str]:
        """Функция `check_efhc_afford` выполняет операцию
в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

        Параметры:
        - `item` (ShopItemDTO): входной параметр.

        Возвращает:
        - Значение типа/структуры: Tuple[bool, str].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
        - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
        if item.item_type == ITEM_TYPE_EFHC_PACKAGE:
            # EFHC-пакеты нельзя покупать за EFHC
            return (False, "efhc_not_supported_for_packages")
        if item.price_efhc is None:
            return (False, "price_not_set")
        if total_efhc < item.price_efhc:
            return (False, "insufficient_efhc_balance")
        return (True, "")

    def method_supported(item: ShopItemDTO, method: str) -> bool:
        """Функция `method_supported` выполняет операцию
в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

        Параметры:
        - `item` (ShopItemDTO): входной параметр.
        - `method` (str): входной параметр.

        Возвращает:
        - Значение типа/структуры: bool.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
        - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
        return method in item.pay_currencies

    out_items: List[Dict[str, Any]] = []
    for it in items:
        can_efhc, reason_efhc = check_efhc_afford(it)
        efhc_enabled = can_efhc and method_supported(it, PAY_EFHC)
        ton_enabled = method_supported(it, PAY_TON) and (
            it.price_ton is not None
        )
        usdt_enabled = method_supported(it, PAY_USDT) and (
            it.price_usdt is not None
        )

        out_items.append({
            "id": it.id,
            "code": it.code,
            "title": it.title,
            "type": it.item_type,
            "prices": {
                "EFHC": (
                    str(it.price_efhc)
                    if it.price_efhc is not None
                    else None
                ),
                "TON": (
                    str(it.price_ton)
                    if it.price_ton is not None
                    else None
                ),
                "USDT": (
                    str(it.price_usdt)
                    if it.price_usdt is not None
                    else None
                ),
            },
            "supported_methods": it.pay_currencies,
            "available": {
                "EFHC": {
                    "enabled": efhc_enabled,
                    "disabled_reason": (
                        None
                        if efhc_enabled
                        else (
                            reason_efhc
                            if not can_efhc
                            else "method_not_supported"
                        )
                    ),
                },
                "TON": {
                    "enabled": ton_enabled,
                    "disabled_reason": (
                        None
                        if ton_enabled
                        else (
                            "price_not_set"
                            if it.price_ton is None
                            else "method_not_supported"
                        )
                    ),
                },
                "USDT": {
                    "enabled": usdt_enabled,
                    "disabled_reason": (
                        None
                        if usdt_enabled
                        else (
                            "price_not_set"
                            if it.price_usdt is None
                            else "method_not_supported"
                        )
                    ),
                },
            },
            "extra": it.extra_json,
        })

    return {
        "balances": {
            "main_balance": str(main),
            "bonus_balance": str(bonus),
            "total_efhc": str(total_efhc),
        },
        "items": out_items,
    }

# ---- MEMO-формат по канону
# ----------------------------------------------------


def _build_memo_for_external(item: ShopItemDTO, user_tg_id: int) -> str:
    """
    EFHC-пакеты: SKU:EFHC|Q:<INT>|TG:<id>
    VIP NFT:    SKU:NFT_VIP|Q:1|TG:<id>
    Прочие SKU можно расширять по мере добавления типов товаров.
    """
    if item.item_type == ITEM_TYPE_EFHC_PACKAGE:
        qty = 0
        if item.extra_json and "quantity_efhc" in item.extra_json:
            try:
                qty = int(item.extra_json["quantity_efhc"])
            except Exception:
                qty = 0
        return f"SKU:EFHC|Q:{qty}|TG:{user_tg_id}"
    elif item.item_type == ITEM_TYPE_NFT_VIP:
        return f"SKU:NFT_VIP|Q:1|TG:{user_tg_id}"
    return f"SKU:UNKNOWN|TG:{user_tg_id}"

# ---- Загрузка карточки товара по code
# -----------------------------------------

async def _get_item_by_code(db: AsyncSession, code: str) -> ShopItemDTO:
    """Асинхронная функция `_get_item_by_code` выполняет операцию
в контуре бота EFHC.
    Назначение: бизнес‑логика соответствующего модуля
(см. имя функции и вызывающий код).

    Параметры:
    - `db` (AsyncSession): входной параметр.
    - `code` (str): входной параметр.

    Возвращает:
    - Значение типа/структуры: ShopItemDTO.

    Инварианты и безопасность:
    - Повторный вызов не должен создавать дубли
  (идемпотентность достигается ключами/
  уникальными ограничениями).
    - Денежные значения в EFHC учитываются с точностью d8
  и округлением вниз (ROUND_DOWN), если применимо
  по модулю.
    - Для операций, затрагивающих баланс/банк, изменения
  проходят через банковский сервис транзакций
  (transactions_service)."""
    q = text(f"""
        SELECT id, code, title, item_type, is_active,
               price_efhc,
               price_ton,
               price_usdt,
               pay_currencies,
               extra_json
        FROM {SCHEMA}.shop_items
        WHERE code = :code AND COALESCE(is_active, TRUE) = TRUE
        LIMIT 1
    """)
    r = (await db.execute(q, {"code": code})).mappings().first()
    if not r:
        msg = (
            f"shop_item code={code} not found "
            "or inactive"
        )
        raise ValueError(msg)
    return ShopItemDTO(id = r["id"],
        code = r["code"],
        title = r["title"],
        item_type = r["item_type"],
        is_active = bool(r["is_active"]),
            price_efhc=(
                d8(r["price_efhc"])
                if r["price_efhc"] is not None
                else None
            ),
            price_ton=(
                d8(r["price_ton"])
                if r["price_ton"] is not None
                else None
            ),
            price_usdt=(
                d8(r["price_usdt"])
                if r["price_usdt"] is not None
                else None
            ),
        pay_currencies = _pay_methods_from_row(r),
        extra_json = r["extra_json"] or {},)

# ---- Создание заказа: внешняя оплата (TON/USDT)
# -------------------------------

async def create_order_external(db: AsyncSession,
    *,
    tg_id: int,
    user_tg_id: int,
    item_code: str,
    payment_method: str,
    client_order_id: str,) -> Dict[str, Any]:
    """
    Создаёт заказ под внешнюю оплату (TON/USDT) для товара,
    генерирует MEMO.
    Денежных списаний здесь нет: деньги придут извне;
    вотчер подтвердит и начислит/создаст заявку.

    Идемпотентность:
      • client_order_id обязателен и уникален на стороне клиента.
      • Повторный вызов с тем же client_order_id вернёт
        уже существующий заказ (read-through).
    """
    if not client_order_id or not client_order_id.strip():
        raise ValueError(
            "client_order_id is required for external orders"
            " (idempotency)"
        )

    if payment_method not in (PAY_TON, PAY_USDT):
        raise ValueError("external payments support only TON/USDT")

    item = await _get_item_by_code(db, item_code)
    if payment_method == PAY_TON and item.price_ton is None:
        raise ValueError("price_ton not set for item")
    if payment_method == PAY_USDT and item.price_usdt is None:
        raise ValueError("price_usdt not set for item")
    if payment_method not in item.pay_currencies:
        raise ValueError("payment method not supported for this item")

    memo = _build_memo_for_external(item, user_tg_id = user_tg_id)

    # Идемпотентно создаём PENDING-заказ
    q = text(f"""
        WITH ins AS (
          INSERT INTO {SCHEMA}.shop_orders
            (
                tg_id,
                item_id,
                status,
                payment_method,
                memo,
                client_order_id,
                created_at,
                updated_at,
            )
          VALUES (
            :tg_id, :item_id, :status, :pm,
            :memo, :coid,
            NOW(), NOW()
          )
          ON CONFLICT (client_order_id) DO NOTHING
          RETURNING
            id, tg_id, item_id, status,
            payment_method, memo, tx_hash, created_at
        )
        SELECT * FROM ins
        UNION ALL
        SELECT
          id, tg_id, item_id, status,
          payment_method, memo, tx_hash, created_at
        FROM {SCHEMA}.shop_orders
        WHERE client_order_id = :coid
        LIMIT 1
    """)
    row = (await db.execute(q, {
        "tg_id": tg_id,
        "item_id": item.id,
        "status": ORDER_STATUS_PENDING,
        "pm": payment_method,
        "memo": memo,
        "coid": client_order_id,
    })).mappings().first()
    await db.commit()

    order = OrderDTO(
        id=row["id"],
        tg_id=row["tg_id"],
        item_id=row["item_id"],
        status=row["status"],
        payment_method=row["payment_method"],
        memo=row["memo"],
        tx_hash=row["tx_hash"],
        created_at=row["created_at"],
    )
    return {
        "order": asdict(order),
        "pay": {
            "method": payment_method,
            # Цену берём из карточки товара — UI сам отобразит стоимость
            # стороне TON/USDT.
            "amount": str(
                item.price_ton
                if payment_method == PAY_TON
                else item.price_usdt
            ),
            "memo": memo,
            "to_wallet": getattr(
                settings, "TON_MAIN_WALLET", None
            ),
            # адрес проекта
        }
    }

# ---- Создание заказа: внутренняя оплата EFHC
# ----------------------------------

async def purchase_with_efhc(db: AsyncSession,
    *,
    tg_id: int,
    item_code: str,
    idempotency_key: str,) -> Dict[str, Any]:
    """
    Покупка товара за EFHC: списание bonus→main с
    зачислением в Банк.

    Ограничения:
      • EFHC-пакеты нельзя покупать EFHC (запрещено).
      • Пользователь не должен уходить в минус:
        если не хватает — ошибка.
      • Для VIP NFT: после списания EFHC создаётся заказ
        со статусом PAID_PENDING_MANUAL.
        (ручная выдача админом), вотчер здесь не участвует.
      • Для прочих виртуальных товаров: заказ помечается
        PAID_AUTO (автодоставка логическая).

    Идемпотентность:
      • строго через idempotency_key;
      • Денежные операции используют под-ключи idk
        (":B", ":M"), заказ — client_order_id=idk.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise ValueError('Idempotency-Key is required')

    item = await _get_item_by_code(db, item_code)
    if PAY_EFHC not in item.pay_currencies:
        raise ValueError("EFHC payment not supported for this item")
    if item.price_efhc is None:
        raise ValueError("price_efhc not set")

    # 1) Проверка балансов пользователя (минус запрещён)
    main, bonus = await _get_user_balances(db, tg_id)
    need = d8(item.price_efhc)
    if d8(main + bonus) < need:
        raise ValueError("insufficient_efhc_balance")

# 2) Списание: сначала бонусы, затем основной баланс.
#    Все списания — в транзакциях банка.
    # Банк.
# Идемпотентность: делим ключ на под-операции,
# чтобы повтор был безопасен.
    spend_bonus = min(bonus, need)
    spend_main = d8(need - spend_bonus)

    if spend_bonus > 0:
        await bank.debit_user_bonus_to_bank(db,
            tg_id = tg_id,
            amount = spend_bonus,
            reason = f"shop:{item.code}",
            idempotency_key = f"{idempotency_key}:B",)
    if spend_main > 0:
        await bank.debit_user_to_bank(db,
            tg_id = tg_id,
            amount = spend_main,
            reason = f"shop:{item.code}",
            idempotency_key = f"{idempotency_key}:M",)

    # 3) Создаём заказ в нужном статусе
    status = ORDER_STATUS_PAID_AUTO
    if item.item_type == ITEM_TYPE_NFT_VIP:
        status = ORDER_STATUS_PAID_PENDING_MANUAL
        # ручная выдача VIP (заявка)

    q = text(f"""
        INSERT INTO {SCHEMA}.shop_orders
            (
                tg_id,
                item_id,
                status,
                payment_method,
                memo,
                client_order_id,
                created_at,
                updated_at,
            )
        VALUES (
          :tg_id, :item_id, :status, :pm, NULL, :coid,
          NOW(), NOW()
        )
        ON CONFLICT (client_order_id) DO NOTHING
          RETURNING
            id, tg_id, item_id, status,
            payment_method, memo, tx_hash, created_at
    """)
    row = (await db.execute(q, {
        "tg_id": tg_id,
        "item_id": item.id,
        "status": status,
        "pm": PAY_EFHC,
        "coid": idempotency_key,
        # используем idk как client_order_id для идемпотентности
    })).mappings().first()

    if not row:
# read-through: вернуть уже существующий заказ
# по client_order_id
        r2 = (await db.execute(text(f"""
        SELECT
          id, tg_id, item_id, status,
          payment_method, memo, tx_hash, created_at
            FROM {SCHEMA}.shop_orders
            WHERE client_order_id = :coid
            LIMIT 1
        """), {"coid": idempotency_key})).mappings().first()
        if not r2:
            await db.rollback()
            raise RuntimeError(
                "idempotent order insert failed"
                " unexpectedly"
            )
        row = r2

    await db.commit()

    order = OrderDTO(
        id=row["id"],
        tg_id=row["tg_id"],
        item_id=row["item_id"],
        status=row["status"],
        payment_method=row["payment_method"],
        memo=row["memo"],
        tx_hash=row["tx_hash"],
        created_at=row["created_at"],
    )
    return {"order": asdict(order)}

# ---- Админ-APIs для управления ценами
# -----------------------------------------

async def admin_set_price(db: AsyncSession,
    *,
    code: str,
    price_efhc: Optional[Decimal] = None,
    price_ton: Optional[Decimal] = None,
    price_usdt: Optional[Decimal] = None,
    pay_currencies: Optional[List[str]] = None,
    is_active: Optional[bool] = None,) -> Dict[str, Any]:
    """
    Из админ-панели: задать/обновить цены
    и доступные методы оплаты карточки товара.
    Все цены квантуются до 8 знаков (d8).
    Можно включать/выключать товар.
    """
    pe = d8(price_efhc) if price_efhc is not None else None
    pt = d8(price_ton) if price_ton is not None else None
    pu = d8(price_usdt) if price_usdt is not None else None

    sets = ["updated_at = NOW()"]
    params: Dict[str, Any] = {"code": code}

    if pe is not None:
        sets.append("price_efhc = :pe")
        params["pe"] = pe
    if pt is not None:
        sets.append("price_ton = :pt")
        params["pt"] = pt
    if pu is not None:
        sets.append("price_usdt = :pu")
        params["pu"] = pu
    if pay_currencies is not None:
        sets.append("pay_currencies = :pays")
        params["pays"] = pay_currencies
    if is_active is not None:
        sets.append("is_active = :ia")
        params["ia"] = bool(is_active)

    if len(sets) == 1:
        return {"updated": 0}

    q = text(f"""
        UPDATE {SCHEMA}.shop_items
        SET {", ".join(sets)}
        WHERE code = :code
        RETURNING id
    """)
    r = (await db.execute(q, params)).first()
    await db.commit()
    return {"updated": 1 if r else 0}

# ---- Витрина заказов пользователя (для WebApp)
# --------------------------------

async def list_orders_for_user(db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 50,
    after_id: Optional[int] = None,) -> List[OrderDTO]:
    """
    Список заказов пользователя (курсорно по id DESC).
    Роутер добавит обёртку с ETag и next_cursor.
    """
    if limit > 200:
        limit = 200
    cond = "tg_id = :tg_id"
    params: Dict[str, Any] = {"tg_id": tg_id}
    if after_id:
        cond += " AND id < :after_id"
        params["after_id"] = after_id

    q = text(f"""
        SELECT
          id, tg_id, item_id, status,
          payment_method, memo, tx_hash, created_at
        FROM {SCHEMA}.shop_orders
        WHERE {cond}
        ORDER BY id DESC
        LIMIT :lim
    """)
    params["lim"] = limit
    rows = (await db.execute(q, params)).mappings().all()
    out: List[OrderDTO] = []
    for r in rows:
        out.append(
            OrderDTO(
                id=r["id"],
                tg_id=r["tg_id"],
                item_id=r["item_id"],
                status=r["status"],
                payment_method=r["payment_method"],
                memo=r["memo"],
                tx_hash=r["tx_hash"],
                created_at=r["created_at"],
            )
        )
    return out

# ---- Админ-витрина заказов (глобальный список с курсором)
# ---------------------

async def admin_list_orders(db: AsyncSession,
    *,
    limit: int = 50,
    cursor: Optional[str] = None,
    status: Optional[str] = None,
    item_type: Optional[str] = None,
    tg_id: Optional[int] = None,) -> Dict[str, Any]:
    """
    Админская витрина заказов с курсорной пагинацией.
    Сортировка: created_at DESC, id DESC.
    Курсор кодирует (created_at_iso, id)
    через encode_cursor/decode_cursor.

    Фильтры:
      • status    — ORDER_STATUS_*
      • item_type — ITEM_TYPE_EFHC_PACKAGE / ITEM_TYPE_NFT_VIP /
        ITEM_TYPE_VIRTUAL
      • tg_id   — конкретный пользователь.
    """
    limit = max(1, min(int(limit or 50), 200))

    after_created_at: Optional[str] = None
    after_id: Optional[int] = None
    if cursor:
        try:
            payload = decode_cursor(cursor)
            ts = payload.get("ts")
            after_created_at = str(ts) if ts is not None else None
            pid = payload.get("id")
            after_id = int(pid) if pid is not None else None
        except Exception as e:
            logger.warning(
                "admin_list_orders: bad cursor %s: %s",
                cursor,
                e,
            )

    conds = ["1 = 1"]
    params: Dict[str, Any] = {}

    if status:
        conds.append("o.status = :st")
        params["st"] = status
    if tg_id:
        conds.append("o.tg_id = :tg_id")
        params["tg_id"] = tg_id
    if item_type:
        conds.append("i.item_type = :itype")
        params["itype"] = item_type
    if after_created_at and after_id is not None:
        conds.append("(o.created_at, o.id) < (:ca, :cid)")
        params["ca"] = after_created_at
        params["cid"] = after_id

    where = " AND ".join(conds)

    q = text(f"""
        SELECT
          o.id,
          o.tg_id,
          u.tg_id,
          u.username,
          o.item_id,
          i.code AS item_code,
          i.title AS item_title,
          i.item_type,
          o.status,
          o.payment_method,
          o.memo,
          o.tx_hash,
          o.created_at
        FROM {SCHEMA}.shop_orders o
        LEFT JOIN {SCHEMA}.shop_items i ON i.id = o.item_id
        LEFT JOIN {SCHEMA}.users u ON u.id = o.tg_id
        WHERE {where}
        ORDER BY o.created_at DESC, o.id DESC
        LIMIT :lim
    """)
    params["lim"] = limit + 1
    # +1: определить наличие next_cursor

    rs = await db.execute(q, params)
    rows = rs.fetchall()

    items: List[Dict[str, Any]] = []
    for r in rows[: limit]:
        items.append({
            "id": int(r[0]),
            "tg_id": int(r[2]) if r[2] is not None else None,
            "username": r[3],
            "item_id": int(r[4]) if r[4] is not None else None,
            "item_code": r[5],
            "item_title": r[6],
            "item_type": r[7],
            "status": r[8],
            "payment_method": r[9],
            "memo": r[10],
            "tx_hash": r[11],
            "created_at": r[12].isoformat() if r[12] else None,
        })

    next_cursor: Optional[str] = None
    if len(rows) > limit:
        last = rows[limit - 1]
        last_created_at = last[12]
        last_id = last[0]
        if last_created_at:
            next_cursor = encode_cursor(
                {
                    "ts": last_created_at.isoformat(),
                    "id": int(last_id),
                }
            )

    return {"items": items, "next_cursor": next_cursor}

# ====================================================================
# Пояснения «для чайника»:
# • Этот модуль не рассылает деньги сам — все денежные движения проводит
# Банковский сервис (transactions_service); здесь мы
# только инициируем списания.
# EFHC.
# • EFHC-пакеты оплачиваются только внешне (TON/USDT).
#   Мы создаём заказ PENDING и генерируем MEMO.
# – EFHC-пакеты: кредит EFHC пользователю из Банка (read-through
# идемпотентность).
# – VIP NFT: создаётся заявка PAID_PENDING_MANUAL
#   (ручная выдача админом).
# • Внутренние EFHC-покупки (виртуальные товары, VIP за EFHC):
# – списание bonus→main с зачислением в Банк
#   (две операции с под-ключами idk).
# – заявка на VIP создаётся как PAID_PENDING_MANUAL (без автодоставки).
# • Безопасность/ИИ:
# – Идемпотентность: все денежные действия
#   используют idempotency_key (или client_nonce).
# client_order_id).
# – Витрина: возвращает флаги доступности методов оплаты
#   и причины отключения для UI.
# кнопок.
# – Запрет минуса: если EFHC не хватает — покупка
#   за EFHC не выполняется.
# выполняется.
# • Админ-витрина:
# – admin_list_orders даёт список заказов с фильтрами
#   и курсором по (created_at, id).
# (created_at,id),
# чтобы админка могла безопасно листать историю без OFFSET.
# ====================================================================

# ====================================================================
# Contract facade for routes (NO DTO DRIFT)
# ====================================================================

from app.contracts.shop_contract import ShopContract
from app.schemas.shop_schemas import (ShopCatalogItemOut,
    ShopOrderExternalIn,
    ShopOrderExternalOut,
    ShopPurchaseByEFHCIn,
    ShopPurchaseByEFHCOut,)


# NOTE (SSOT): фасад ShopFacade ожидает существование этих функций.
# В текущем контуре они служат как контрактные точки расширения.
# Если логика будет реализована в другом модуле, держите эти обёртки
# как стабильный API для routes/facade.


async def get_catalog(*, db: AsyncSession, tg_id: int):
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Shop catalog is not implemented",
    )


async def create_external_order(
    *,
    db: AsyncSession,
    tg_id: int,
    payload: ShopOrderExternalIn,
    client_nonce: Optional[str],
):
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Shop external order is not implemented",
    )


class ShopFacade(ShopContract):
    """Фасад Shop‑контура: единая точка входа для роутов.

    Что делает:
      • Роуты обращаются только к ShopFacade (контрактный entrypoint).
      • Исключает рассинхрон между routes и services
        по DTO и названиям методов.
    """

    def __init__(self, db: AsyncSession):
        self._db = db

    async def get_catalog(self, tg_id: int):
        return await get_catalog(db = self._db, tg_id = int(tg_id))

    async def create_external_order(
        self,
        tg_id: int,
        payload: ShopOrderExternalIn,
        client_nonce: Optional[str],
    ) -> ShopOrderExternalOut:
        data = await create_external_order(db = self._db,
            tg_id = int(tg_id),
            payload = payload,
            client_nonce = client_nonce,)
        return ShopOrderExternalOut(**data)

    async def purchase_by_efhc(
        self,
        tg_id: int,
        payload: ShopPurchaseByEFHCIn,
        idempotency_key: str,
    ) -> ShopPurchaseByEFHCOut:
        data = await purchase_with_efhc(self._db,
            tg_id = int(tg_id),
            item_code = payload.sku,
            qty = int(payload.quantity),
            idempotency_key = idempotency_key,)
        return ShopPurchaseByEFHCOut(**data)

    async def list_orders(
        self,
        tg_id: int,
        limit: int,
        cursor: Optional[str],
    ) -> dict:
        return await list_orders_for_user(
            self._db,
            tg_id=int(tg_id),
            limit=limit,
            cursor=cursor,
        )


def get_shop_service(db: AsyncSession) -> ShopContract:
    """FastAPI dependency: возвращает контрактный Shop‑сервис."""
    return ShopFacade(db)

