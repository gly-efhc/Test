# backend/app/services/shop_service.py
# ====================================================================
# Назначение кода:
# Сервис магазина EFHC: каталожные позиции (сидер), витрины,
# создание заказов, генерация MEMO для внешних платежей
# (TON/USDT), внутренняя оплата EFHC (списание: сначала bonus,
# затем main), интеграция с Банком и Вотчером.
#
# Канон/инварианты:
# • Обмен только kWh→EFHC (1:1), обратной конверсии нет.
# • P2P запрещено. Любые движения EFHC — только «банк ↔ пользователь».
# • NFT — только заявка и ручная обработка.
# • EFHC-пакеты оплачиваются только внешне (TON/USDT).
#   Мы создаём заказ PENDING и генерируем MEMO.
#   оплата за EFHC запрещена.
# • Денежные POST — обязателен Idempotency-Key / client_nonce.
# • Пользователь не уходит в минус. Банк может (дефицит не блокирует).
#
# ИИ-защита/самовосстановление:
# • Идемпотентность: конфликт idempotency_key → вернуть
#   зафиксированный результат из логов; повторный вызов безопасен.
# • Лог-ориентированность: заказы и MEMO фиксируются в БД; вотчер
#   подхватывает оплату по tx_hash и обновляет статусы.
# • Витрина отдаёт флаги доступности и disabled_reason для UI;
#   кнопки деактивируются при минусе/недостатке средств/неподдержке.
#
# Запреты:
# • Никакой автодоставки NFT. Только заявка PAID_PENDING_MANUAL.
# • EFHC-пакеты оплачиваются только внешне (TON/USDT).
#   Мы создаём заказ PENDING и генерируем MEMO.
# • Никаких скрытых начислений, минуя Банк.
# ====================================================================

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import asdict, dataclass
from datetime import datetime, UTC
from decimal import Decimal
import json
from typing import Any, cast

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8, decode_cursor, encode_cursor
from app.identity.financial_owner import resolve_financial_read_owner
from app.services import transactions_service as bank
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()


def _build_nft_collection_json(settings) -> str:
    """JSON для extra.nft_collection (коротко и канонично)."""
    col = getattr(settings, "TON_NFT_COLLECTION", "")
    return f'{{"nft_collection": "{col}"}}'


# ---- Канонические типы/статусы
# ------------------------------------------------

ITEM_TYPE_EFHC_PACKAGE = "EFHC_PACKAGE"
# пакеты EFHC: 10..1000 (внешняя оплата)
ITEM_TYPE_NFT_VIP = "NFT_VIP"  # VIP NFT (TON/USDT/EFHC)
ITEM_TYPE_VIRTUAL = "VIRTUAL"
# прочие виртуальные товары (за EFHC внутри)

PAY_TON = "TON"
PAY_USDT = "USDT"
PAY_EFHC = "EFHC"
USDT_DISABLED_REASON = "usdt_price_or_method_not_ready"

ORDER_STATUS_PENDING = "PENDING"  # заказ создан, ждём внешнюю оплату
ORDER_STATUS_PAID_AUTO = "PAID_AUTO"
# оплачен автоматически: внешний платёж подтверждён
# вотчером / авто-логика
ORDER_STATUS_PAID_PENDING_MANUAL = "PAID_PENDING_MANUAL"
# оплачен, ожидание ручной выдачи (NFT)
ORDER_STATUS_CANCELLED = "CANCELLED"
ORDER_STATUS_REJECTED = "REJECTED"

# ---- Вспомогательные DTO
# ------------------------------------------------------


@dataclass
class ShopItemDTO:
    id: int
    code: str
    title: str
    item_type: str
    is_active: bool
    price_efhc: Decimal | None
    price_ton: Decimal | None
    price_usdt: Decimal | None
    pay_currencies: list[str]
    extra_json: dict[str, Any]


@dataclass
class OrderDTO:
    id: int
    global_id: int
    status: str
    memo: str | None
    tx_hash: str | None
    created_at: datetime
    item_id: int | None = None
    payment_method: str | None = None
    order_type: str | None = None
    quantity_efhc: str | None = None
    expected_amount: str | None = None
    sku: str | None = None


# ---- Утилиты
# ------------------------------------------------------------------


def _now_utc() -> datetime:
    """Функция `_now_utc` выполняет операцию
    в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля
    (см. имя функции и вызывающий код).

        Возвращает:
        - Значение типа/структуры: datetime.

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли
      (идемпотентность достигается ключами/
      уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8
      и округлением вниз (ROUND_DOWN), если применимо
      по модулю.
        - Для операций, затрагивающих баланс/банк, изменения
      проходят через банковский сервис транзакций
      (transactions_service)."""
    return datetime.now(UTC)


def _pay_methods_from_row(row) -> list[str]:
    # pay_currencies хранится как массив TEXT[] или JSON — нормализуем к
    # List[str]
    """Функция `_pay_methods_from_row` выполняет операцию
    в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля
    (см. имя функции и вызывающий код).

        Параметры:
        - `row`: входной параметр.

        Возвращает:
        - Значение типа/структуры: List[str].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли
      (идемпотентность достигается ключами/
      уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8
      и округлением вниз (ROUND_DOWN), если применимо
      по модулю.
        - Для операций, затрагивающих баланс/банк, изменения
      проходят через банковский сервис транзакций
      (transactions_service)."""
    val = row["pay_currencies"]
    if val is None:
        return []
    if isinstance(val, list):
        return [str(x) for x in val]
    if isinstance(val, str):
        # на случай JSON-строки
        try:
            import json

            arr = json.loads(val)
            if isinstance(arr, list):
                return [str(x) for x in arr]
            return []
        except Exception:
            return []
    return []


def _extra_obj(row: Any) -> dict[str, Any]:
    raw = row.get("extra") if hasattr(row, "get") else None
    if raw is None and hasattr(row, "get"):
        raw = row.get("extra_json")
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str) and raw.strip():
        try:
            loaded = json.loads(raw)
            return loaded if isinstance(loaded, dict) else {}
        except Exception:
            return {}
    return {}


def _infer_item_type(row: Any) -> str:
    if hasattr(row, "get"):
        direct = row.get("item_type")
        if direct:
            return str(direct)
    extra = _extra_obj(row)
    if isinstance(extra.get("item_type"), str):
        return str(extra["item_type"])
    qty = None
    if hasattr(row, "get"):
        qty = row.get("quantity_efhc")
    if qty is not None:
        return ITEM_TYPE_EFHC_PACKAGE
    sku = None
    if hasattr(row, "get"):
        sku = row.get("sku") or row.get("code")
    sku_s = str(sku or "")
    if "NFT" in sku_s or "VIP" in sku_s:
        return ITEM_TYPE_NFT_VIP
    return ITEM_TYPE_VIRTUAL


def _price_from_extra(
    extra: dict[str, Any],
    key: str,
) -> Decimal | None:
    raw = extra.get(key)
    if raw is None:
        prices = extra.get("prices")
        if isinstance(prices, dict):
            raw = prices.get(key)
    if raw is None:
        return None
    try:
        parsed = cast(Decimal, d8(raw))
        return parsed
    except (ArithmeticError, TypeError, ValueError):
        try:
            parsed = cast(Decimal, d8(Decimal(str(raw))))
            return parsed
        except (ArithmeticError, TypeError, ValueError):
            return None


def _pay_methods_from_item(row: Any) -> list[str]:
    if hasattr(row, "get"):
        direct = row.get("pay_currencies")
        if direct is not None:
            if isinstance(direct, list):
                return [str(x).upper() for x in direct]
            if isinstance(direct, str):
                arr: list[Any] | None = None
                try:
                    loaded = json.loads(direct)
                    if isinstance(loaded, list):
                        arr = loaded
                except (TypeError, ValueError, json.JSONDecodeError):
                    arr = None
                if arr is not None:
                    return [str(x).upper() for x in arr]
    extra = _extra_obj(row)
    pays = extra.get("pay_currencies")
    if isinstance(pays, list):
        return [str(x).upper() for x in pays]
    item_type = _infer_item_type(row)
    if item_type == ITEM_TYPE_EFHC_PACKAGE:
        return [PAY_TON, PAY_USDT]
    if item_type == ITEM_TYPE_NFT_VIP:
        return [PAY_EFHC, PAY_TON, PAY_USDT]
    return [PAY_EFHC]


def _item_to_dto(row: Any) -> ShopItemDTO:
    extra = _extra_obj(row)
    code = None
    if hasattr(row, "get"):
        code = row.get("code") or row.get("sku")
    return ShopItemDTO(
        id=int(row["id"]),
        code=str(code),
        title=str(row["title"]),
        item_type=_infer_item_type(row),
        is_active=bool(row.get("is_active", True)),
        price_efhc=_price_from_extra(extra, "price_efhc"),
        price_ton=_price_from_extra(extra, "price_ton"),
        price_usdt=_price_from_extra(extra, "price_usdt"),
        pay_currencies=_pay_methods_from_item(row),
        extra_json=extra,
    )


def _order_type_for_item(item: ShopItemDTO) -> str:
    return "NFT" if item.item_type == ITEM_TYPE_NFT_VIP else "EFHC"


def _item_quantity_text(item: ShopItemDTO) -> str | None:
    if item.extra_json:
        for key in (
            "quantity_efhc",
            "quantity",
            "efhc_quantity",
            "qty",
            "package_qty",
            "pack_quantity",
            "nominal",
            "efhc_amount",
        ):
            val = item.extra_json.get(key)
            if val is not None:
                return str(val)
    if item.item_type == ITEM_TYPE_EFHC_PACKAGE and "_" in item.code:
        tail = item.code.split("_")[-1]
        if tail.isdigit():
            return tail
    return None


def _order_extra(
    item: ShopItemDTO,
    payment_method: str | None = None,
    canonical_memo: str | None = None,
) -> dict[str, Any]:
    return {
        "sku": str(item.code),
        "item_type": str(item.item_type),
        "payment_method": (
            str(payment_method).upper() if payment_method else None
        ),
        "canonical_memo": (
            str(canonical_memo) if canonical_memo else None
        ),
    }


# ---- Сидер каталога под список EFHC-пакетов и VIP
# ----------------------------


async def seed_default_items(db: AsyncSession) -> dict[str, Any]:
    """
    Идемпотентный сидер: создаёт (если нет) базовые карточки товаров.
    Цены НЕ жёсткие — будут отредактированы в админ-панели.
    """
    rockets = [10, 50, 100, 200, 300, 400, 500, 1000]
    inserts = 0
    updated = 0  # зарезервировано под будущие обновления

    # EFHC-пакеты (внешняя оплата TON/USDT)
    for qty in rockets:
        code = f"EFHC_{qty}"
        title = f"{qty} EFHC"
        pay_currencies = [PAY_TON, PAY_USDT]  # только внешние методы
        q = text(
            """
            INSERT INTO efhc_core.shop_items
              (
               code,
               title,
               item_type,
               is_active,
               price_efhc,
               price_ton,
               price_usdt,
               pay_currencies,
               extra_json,
               created_at,
               updated_at
              )
            SELECT
                :code, :title, :itype, TRUE,
                NULL, NULL, NULL,
                :pays, :extra::jsonb,
                NOW(), NOW()
            WHERE NOT EXISTS (
                SELECT 1 FROM efhc_core.shop_items WHERE code = :code
            )
            RETURNING id
        """
        )
        res = await db.execute(
            q,
            {
                "code": code,
                "title": title,
                "itype": ITEM_TYPE_EFHC_PACKAGE,
                "pays": pay_currencies,
                "extra": f'{"{"} "quantity_efhc": {qty} {"}"}',
            },
        )
        if res.fetchone():
            inserts += 1

    # VIP NFT — три карточки товара: за TON, USDT, EFHC
    vip_variants = [
        ("VIP_NFT_TON", "VIP NFT (TON)", [PAY_TON], None, None),
        ("VIP_NFT_USDT", "VIP NFT (USDT)", [PAY_USDT], None, None),
        ("VIP_NFT_EFHC", "VIP NFT (EFHC)", [PAY_EFHC], None, None),
    ]
    for code, title, pays, price_ton, price_usdt in vip_variants:
        q = text(
            """
            INSERT INTO efhc_core.shop_items
              (
               code,
               title,
               item_type,
               is_active,
               price_efhc,
               price_ton,
               price_usdt,
               pay_currencies,
               extra_json,
               created_at,
               updated_at
              )
            SELECT
                :code, :title, :itype, TRUE,
                NULL, :pt, :pu,
                :pays, :extra::jsonb,
                NOW(), NOW()
            WHERE NOT EXISTS (
                SELECT 1 FROM efhc_core.shop_items WHERE code = :code
            )
            RETURNING id
        """
        )
        res = await db.execute(
            q,
            {
                "code": code,
                "title": title,
                "itype": ITEM_TYPE_NFT_VIP,
                "pt": price_ton,
                "pu": price_usdt,
                "pays": pays,
                "extra": _build_nft_collection_json(settings),
            },
        )
        if res.fetchone():
            inserts += 1

    await db.commit()

    return {"inserted": inserts, "updated": updated}


# ---- Балансы пользователя
# -----------------------------------------------------


async def _get_user_balances(
    db: AsyncSession,
    global_id: int,
) -> tuple[Decimal, Decimal]:
    """Асинхронная функция `_get_user_balances` выполняет операцию
    в контуре бота EFHC.
        Назначение: бизнес‑логика соответствующего модуля
    (см. имя функции и вызывающий код).

        Параметры:
        - `db` (AsyncSession): входной параметр.
        - `global_id` (int): входной параметр.

        Возвращает:
        - Значение типа/структуры: Tuple[Decimal, Decimal].

        Инварианты и безопасность:
        - Повторный вызов не должен создавать дубли
      (идемпотентность достигается ключами/
      уникальными ограничениями).
        - Денежные значения в EFHC учитываются с точностью d8
      и округлением вниз (ROUND_DOWN), если применимо
      по модулю.
        - Для операций, затрагивающих баланс/банк, изменения
      проходят через банковский сервис транзакций
      (transactions_service)."""
    q = text(
        """
            SELECT COALESCE(main_balance,0) AS main_balance,
               COALESCE(bonus_balance,0) AS bonus_balance
        FROM efhc_core.users WHERE global_id = :global_id
        LIMIT 1
    """
    )
    row = (
        await db.execute(q, {"global_id": int(global_id)})
    ).mappings().first()
    if not row:
        raise ValueError(f"global_id={global_id:010d} not found")
    return d8(row["main_balance"]), d8(row["bonus_balance"])


# ---- Загрузка каталога
# --------------------------------------------------------


async def _fetch_items(db: AsyncSession) -> list[ShopItemDTO]:
    """Чтение карточек магазина по каноничной схеме shop_items."""
    q = text(
        """
        SELECT id, sku, title, description, quantity_efhc,
               COALESCE(is_active, TRUE) AS is_active,
               extra
          FROM efhc_core.shop_items
         ORDER BY id ASC
        """
    )
    rows = (await db.execute(q)).mappings().all()
    return [_item_to_dto(r) for r in rows]


# ---- Витрина магазина для пользователя
# ---------------------------------------


async def list_shop_for_user(
    db: AsyncSession,
    global_id: int,
) -> dict[str, Any]:
    """
    Витрина магазина для пользователя:
      • отдаёт весь активный каталог товаров;
      • по каждой карточке товара рассчитывает
        доступность кнопок по методам оплаты;
      • для EFHC-покупок — проверяет, хватает ли
        (bonus+main) и не в «минусе» ли пользователь.
    """
    main, bonus = await _get_user_balances(db, global_id)
    total_efhc = d8(main + bonus)

    items = await _fetch_items(db)

    def check_efhc_afford(item: ShopItemDTO) -> tuple[bool, str]:
        """Функция `check_efhc_afford` выполняет операцию
        в контуре бота EFHC.
                Назначение: бизнес‑логика соответствующего модуля
        (см. имя функции и вызывающий код).

                Параметры:
                - `item` (ShopItemDTO): входной параметр.

                Возвращает:
                - Значение типа/структуры: Tuple[bool, str].

                Инварианты и безопасность:
                - Повторный вызов не должен создавать дубли
          (идемпотентность достигается ключами/
          уникальными ограничениями).
                - Денежные значения в EFHC учитываются с точностью d8
          и округлением вниз (ROUND_DOWN), если применимо
          по модулю.
                - Для операций, затрагивающих баланс/банк, изменения
          проходят через банковский сервис транзакций
          (transactions_service)."""
        if item.item_type == ITEM_TYPE_EFHC_PACKAGE:
            # EFHC-пакеты нельзя покупать за EFHC
            return (False, "efhc_not_supported_for_packages")
        if item.price_efhc is None:
            return (False, "price_not_set")
        if total_efhc < item.price_efhc:
            return (False, "insufficient_efhc_balance")
        return (True, "")

    def method_supported(item: ShopItemDTO, method: str) -> bool:
        """Функция `method_supported` выполняет операцию
        в контуре бота EFHC.
                Назначение: бизнес‑логика соответствующего модуля
        (см. имя функции и вызывающий код).

                Параметры:
                - `item` (ShopItemDTO): входной параметр.
                - `method` (str): входной параметр.

                Возвращает:
                - Значение типа/структуры: bool.

                Инварианты и безопасность:
                - Повторный вызов не должен создавать дубли
          (идемпотентность достигается ключами/
          уникальными ограничениями).
                - Денежные значения в EFHC учитываются с точностью d8
          и округлением вниз (ROUND_DOWN), если применимо
          по модулю.
                - Для операций, затрагивающих баланс/банк, изменения
          проходят через банковский сервис транзакций
          (transactions_service)."""
        return method in item.pay_currencies

    out_items: list[dict[str, Any]] = []
    for it in items:
        can_efhc, reason_efhc = check_efhc_afford(it)
        efhc_enabled = can_efhc and method_supported(it, PAY_EFHC)
        ton_enabled = method_supported(it, PAY_TON) and (
            it.price_ton is not None
        )
        usdt_enabled = method_supported(it, PAY_USDT) and (
            it.price_usdt is not None
        )

        out_items.append(
            {
                "id": it.id,
                "code": it.code,
                "title": it.title,
                "type": it.item_type,
                "prices": {
                    "EFHC": (
                        str(it.price_efhc)
                        if it.price_efhc is not None
                        else None
                    ),
                    "TON": (
                        str(it.price_ton)
                        if it.price_ton is not None
                        else None
                    ),
                    "USDT": (
                        str(it.price_usdt)
                        if it.price_usdt is not None
                        else None
                    ),
                },
                "supported_methods": it.pay_currencies,
                "available": {
                    "EFHC": {
                        "enabled": efhc_enabled,
                        "disabled_reason": (
                            None
                            if efhc_enabled
                            else (
                                reason_efhc
                                if not can_efhc
                                else "method_not_supported"
                            )
                        ),
                    },
                    "TON": {
                        "enabled": ton_enabled,
                        "disabled_reason": (
                            None
                            if ton_enabled
                            else (
                                "price_not_set"
                                if it.price_ton is None
                                else "method_not_supported"
                            )
                        ),
                    },
                    "USDT": {
                        "enabled": usdt_enabled,
                        "disabled_reason": (
                            None
                            if usdt_enabled
                            else (
                                "price_not_set"
                                if it.price_usdt is None
                                else USDT_DISABLED_REASON
                            )
                        ),
                    },
                },
                "extra": it.extra_json,
            }
        )

    return {
        "balances": {
            "main_balance": str(main),
            "bonus_balance": str(bonus),
            "total_efhc": str(total_efhc),
        },
        "items": out_items,
    }


# ---- MEMO-формат по канону
# ----------------------------------------------------


def _build_memo_for_external(
    item: ShopItemDTO,
    global_id: int,
) -> str:
    """
    EFHC-пакеты: SKU:EFHC|Q:<INT>|G:<global_id>
    VIP NFT:    SKU:NFT_VIP|Q:1|G:<global_id>
    Прочие SKU можно расширять по мере добавления типов товаров.
    """
    if item.item_type == ITEM_TYPE_EFHC_PACKAGE:
        qty = 0
        if item.extra_json and "quantity_efhc" in item.extra_json:
            try:
                qty = int(item.extra_json["quantity_efhc"])
            except Exception:
                qty = 0
        return f"SKU:EFHC|Q:{qty}|G:{global_id:010d}"
    elif item.item_type == ITEM_TYPE_NFT_VIP:
        return f"SKU:NFT_VIP|Q:1|G:{global_id:010d}"
    return f"SKU:UNKNOWN|G:{global_id:010d}"


# ---- Загрузка карточки товара по code
# -----------------------------------------


async def _get_item_by_code(db: AsyncSession, code: str) -> ShopItemDTO:
    """Загрузка карточки товара по каноничному SKU."""
    q = text(
        """
        SELECT id, sku, title, description, quantity_efhc,
               COALESCE(is_active, TRUE) AS is_active,
               extra
          FROM efhc_core.shop_items
         WHERE sku = :code AND COALESCE(is_active, TRUE) = TRUE
         LIMIT 1
        """
    )
    r = (await db.execute(q, {"code": code})).mappings().first()
    if not r:
        msg = f"shop_item code={code} not found or inactive"
        raise ValueError(msg)
    return _item_to_dto(r)


# ---- Создание заказа: внешняя оплата (TON/USDT)
# -------------------------------


async def create_order_external(
    db: AsyncSession,
    *,
    global_id: int,
    item_code: str,
    payment_method: str,
    client_order_id: str,
) -> dict[str, Any]:
    """
    Создаёт заказ под внешнюю оплату (TON/USDT) для товара,
    генерирует MEMO.
    Денежных списаний здесь нет: деньги придут извне;
    вотчер подтвердит и начислит/создаст заявку.

    Идемпотентность:
      • client_order_id обязателен и уникален на стороне клиента.
      • Повторный вызов с тем же client_order_id вернёт
        уже существующий заказ (read-through).
    """
    if not client_order_id or not client_order_id.strip():
        raise ValueError(
            "client_order_id is required for external orders"
            " (idempotency)"
        )

    if payment_method not in {PAY_TON, PAY_USDT}:
        raise ValueError("PAYMENT_METHOD_NOT_SUPPORTED")

    item = await _get_item_by_code(db, item_code)
    if payment_method == PAY_TON and item.price_ton is None:
        raise ValueError("price_ton not set for item")
    if payment_method == PAY_USDT and item.price_usdt is None:
        raise ValueError("price_usdt not set for item")
    if payment_method not in item.pay_currencies:
        raise ValueError("payment method not supported for this item")

    memo = _build_memo_for_external(item, global_id=int(global_id))
    order_extra = _order_extra(
        item,
        payment_method,
        canonical_memo=memo,
    )

    # Идемпотентно создаём PENDING-заказ
    order_type = _order_type_for_item(item)
    expected_amount = (
        item.price_ton if payment_method == PAY_TON else item.price_usdt
    )
    q = text(
        """
        WITH ins AS (
            INSERT INTO efhc_core.shop_orders (
                global_id,
                type,
                status,
                quantity_efhc,
                expected_amount,
                memo,
                idempotency_key,
                extra,
                created_at,
                updated_at
            )
            VALUES (
                :global_id, :otype, :status, :qty, :expected_amount,
                :memo, :idk, :extra::jsonb, NOW(), NOW()
            )
            ON CONFLICT (idempotency_key) DO NOTHING
            RETURNING id, global_id, type, status, quantity_efhc,
                      expected_amount, memo, tx_hash, created_at, extra
        )
        SELECT * FROM ins
        UNION ALL
        SELECT id, global_id, type, status, quantity_efhc,
               expected_amount, memo, tx_hash, created_at, extra
          FROM efhc_core.shop_orders
         WHERE idempotency_key = :idk
         LIMIT 1
        """
    )
    row = (
        (
            await db.execute(
                q,
                {
                    "global_id": int(global_id),
                    "otype": order_type,
                    "status": ORDER_STATUS_PENDING,
                    "qty": _item_quantity_text(item),
                    "expected_amount": (
                        str(expected_amount)
                        if expected_amount is not None
                        else None
                    ),
                    "memo": memo,
                    "idk": client_order_id,
                    "extra": json.dumps(order_extra),
                },
            )
        )
        .mappings()
        .first()
    )
    await db.commit()
    if row is None:
        raise RuntimeError("shop order insert/select returned no row")

    extra = row.get("extra") or {}
    if isinstance(extra, str):
        try:
            extra = json.loads(extra)
        except Exception:
            extra = {}
    order = OrderDTO(
        id=row["id"],
        global_id=int(row["global_id"]),
        status=row["status"],
        memo=row["memo"],
        tx_hash=row["tx_hash"],
        created_at=row["created_at"],
        order_type=row.get("type"),
        quantity_efhc=(
            str(row["quantity_efhc"])
            if row.get("quantity_efhc") is not None
            else None
        ),
        expected_amount=(
            str(row["expected_amount"])
            if row.get("expected_amount") is not None
            else None
        ),
        payment_method=extra.get("payment_method"),
        sku=extra.get("sku"),
    )
    return {
        "order": asdict(order),
        "pay": {
            "method": payment_method,
            "amount": str(expected_amount),
            "memo": memo,
            "to_wallet": getattr(settings, "TON_MAIN_WALLET", None),
        },
    }


# ---- Создание заказа: внутренняя оплата EFHC
# ----------------------------------


async def purchase_with_efhc(
    db: AsyncSession,
    *,
    global_id: int,
    item_code: str,
    qty: int = 1,
    idempotency_key: str,
) -> dict[str, Any]:
    """
    Покупка товара за EFHC: списание bonus→main с
    зачислением в Банк.

    Ограничения:
      • EFHC-пакеты нельзя покупать EFHC (запрещено).
      • Пользователь не должен уходить в минус:
        если не хватает — ошибка.
      • Для VIP NFT: после списания EFHC создаётся заказ
        со статусом PAID_PENDING_MANUAL.
        (ручная выдача админом), вотчер здесь не участвует.
      • Для прочих виртуальных товаров: заказ помечается
        PAID_AUTO (автодоставка логическая).

    Идемпотентность:
      • строго через idempotency_key;
      • денежное списание централизовано через
        spend_user_to_bank_bonus_then_main(...);
      • заказ использует client_order_id=idempotency_key.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise ValueError("Idempotency-Key is required")

    if qty < 1 or qty > 10:
        raise ValueError("qty must be 1..10")

    item = await _get_item_by_code(db, item_code)
    if PAY_EFHC not in item.pay_currencies:
        raise ValueError("EFHC payment not supported for this item")
    if item.price_efhc is None:
        raise ValueError("price_efhc not set")

    # 1) Проверка балансов пользователя (минус запрещён).
    main, bonus = await _get_user_balances(db, global_id)
    need = d8(d8(item.price_efhc) * Decimal(int(qty)))
    if d8(main + bonus) < need:
        raise ValueError("insufficient_efhc_balance")

    # 2) Каноническое списание: сначала bonus, затем main.
    # Весь денежный поток ведёт bank service одной операцией.
    owner = await resolve_financial_read_owner(
        db, global_id=int(global_id)
    )
    await bank.spend_user_to_bank_bonus_then_main(
        db,
        global_id=owner.global_id,
        amount=d8(need),
        reason=f"shop:{item.code}",
        idempotency_key=str(idempotency_key),
        meta={
            "module": "shop_service",
            "item_code": str(item.code),
            "qty": int(qty),
        },
    )

    # 3) Создаём заказ в нужном статусе
    status = ORDER_STATUS_PAID_AUTO
    if item.item_type == ITEM_TYPE_NFT_VIP:
        status = ORDER_STATUS_PAID_PENDING_MANUAL

    order_type = _order_type_for_item(item)
    extra_json = json.dumps(_order_extra(item, PAY_EFHC))
    q = text(
        """
        INSERT INTO efhc_core.shop_orders (
            global_id, type, status, quantity_efhc, expected_amount,
            memo, idempotency_key, extra, created_at, updated_at
        )
        VALUES (
            :global_id, :otype, :status, :qty, :expected_amount,
            NULL, :idk, :extra::jsonb, NOW(), NOW()
        )
        ON CONFLICT (idempotency_key) DO NOTHING
        RETURNING id, global_id, type, status, quantity_efhc,
                  expected_amount, memo, tx_hash, created_at, extra
        """
    )
    row = (
        (
            await db.execute(
                q,
                {
                    "global_id": int(global_id),
                    "otype": order_type,
                    "status": status,
                    "qty": (
                        str(item.price_efhc * Decimal(int(qty)))
                        if item.price_efhc is not None
                        else None
                    ),
                    "expected_amount": str(need),
                    "idk": idempotency_key,
                    "extra": extra_json,
                },
            )
        )
        .mappings()
        .first()
    )

    if not row:
        r2 = (
            (
                await db.execute(
                    text(
                        """
            SELECT id, global_id, type, status, quantity_efhc,
                   expected_amount, memo, tx_hash, created_at, extra
              FROM efhc_core.shop_orders
             WHERE idempotency_key = :idk
             LIMIT 1
            """
                    ),
                    {"idk": idempotency_key},
                )
            )
            .mappings()
            .first()
        )
        if not r2:
            await db.rollback()
            raise RuntimeError(
                "idempotent order insert failed unexpectedly"
            )
        row = r2

    await db.commit()
    extra = row.get("extra") or {}
    if isinstance(extra, str):
        try:
            extra = json.loads(extra)
        except Exception:
            extra = {}
    order = OrderDTO(
        id=row["id"],
        global_id=int(row["global_id"]),
        status=row["status"],
        memo=row["memo"],
        tx_hash=row["tx_hash"],
        created_at=row["created_at"],
        order_type=row.get("type"),
        quantity_efhc=(
            str(row["quantity_efhc"])
            if row.get("quantity_efhc") is not None
            else None
        ),
        expected_amount=(
            str(row["expected_amount"])
            if row.get("expected_amount") is not None
            else None
        ),
        payment_method=extra.get("payment_method"),
        sku=extra.get("sku"),
    )
    return {"order": asdict(order)}


async def admin_list_items(db: AsyncSession) -> list[dict[str, Any]]:
    """Полный список карточек магазина для админки."""
    q = text(
        """
        SELECT
          id, code, title, item_type, is_active,
          price_efhc, price_ton, price_usdt, pay_currencies,
          description, extra_json, created_at, updated_at
        FROM efhc_core.shop_items
        ORDER BY id ASC
        """
    )
    rows = (await db.execute(q)).mappings().all()
    out: list[dict[str, Any]] = []
    for row in rows:
        extra = row.get("extra_json") or {}
        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except Exception:
                extra = {}
        if not isinstance(extra, dict):
            extra = {}
        status = str(
            extra.get("status")
            or ("live" if row.get("is_active") else "hidden")
        )
        out.append(
            {
                "id": int(row["id"]),
                "code": str(row.get("code") or ""),
                "sku": str(row.get("code") or ""),
                "title": str(row.get("title") or ""),
                "description": (
                    str(row.get("description"))
                    if row.get("description")
                    else ""
                ),
                "item_type": str(
                    row.get("item_type") or ITEM_TYPE_EFHC_PACKAGE
                ),
                "is_active": bool(row.get("is_active", True)),
                "status": status,
                "quantity_efhc": str(extra.get("quantity_efhc") or ""),
                "image_url": str(extra.get("image_url") or ""),
                "price_ton": str(row.get("price_ton") or ""),
                "price_usdt": str(row.get("price_usdt") or ""),
                "pay_currencies": _pay_methods_from_item(row),
                "created_at": row.get("created_at"),
                "updated_at": row.get("updated_at"),
                "history_count": len(extra.get("history") or []),
                "history_tail": list(extra.get("history") or [])[:5],
            }
        )
    return out


def _admin_normalize_item_status(
    status: str | None,
) -> tuple[str, bool]:
    st = str(status or "draft").lower()
    if st not in {"live", "hidden", "draft"}:
        st = "draft"
    return st, st == "live"


def _admin_item_snapshot(row: Any) -> dict[str, Any]:
    extra = row.get("extra_json") or {}
    if isinstance(extra, str):
        try:
            extra = json.loads(extra)
        except Exception:
            extra = {}
    if not isinstance(extra, dict):
        extra = {}
    return {
        "code": str(row.get("code") or ""),
        "title": str(row.get("title") or ""),
        "description": str(row.get("description") or ""),
        "item_type": str(
            row.get("item_type") or ITEM_TYPE_EFHC_PACKAGE
        ),
        "is_active": bool(row.get("is_active", True)),
        "status": str(extra.get("status") or "draft"),
        "quantity_efhc": str(extra.get("quantity_efhc") or ""),
        "image_url": str(extra.get("image_url") or ""),
        "price_ton": str(row.get("price_ton") or ""),
        "price_usdt": str(row.get("price_usdt") or ""),
        "pay_currencies": _pay_methods_from_item(row),
        "updated_at": str(row.get("updated_at") or ""),
    }


async def _admin_get_item_row(
    db: AsyncSession,
    *,
    code: str,
) -> Any | None:
    q = text(
        """
        SELECT
          id, code, title, item_type, is_active,
          price_efhc, price_ton, price_usdt, pay_currencies,
          description, extra_json, created_at, updated_at
        FROM efhc_core.shop_items
        WHERE code = :code
        LIMIT 1
        """
    )
    return (await db.execute(q, {"code": code})).mappings().first()


async def _admin_append_item_history(
    db: AsyncSession,
    *,
    code: str,
    action: str,
    detail: str,
    before: dict[str, Any] | None = None,
    after: dict[str, Any] | None = None,
) -> None:
    row = await _admin_get_item_row(db, code=code)
    if row is None:
        return
    extra = row.get("extra_json") or {}
    if isinstance(extra, str):
        try:
            extra = json.loads(extra)
        except Exception:
            extra = {}
    if not isinstance(extra, dict):
        extra = {}
    history = extra.get("history") or []
    if not isinstance(history, list):
        history = []
    history.insert(
        0,
        {
            "at": datetime.utcnow().isoformat() + "Z",
            "action": action,
            "detail": detail,
            "before": before,
            "after": after,
        },
    )
    extra["history"] = history[:20]
    q = text(
        """
        UPDATE efhc_core.shop_items
           SET extra_json = CAST(:extra_json AS jsonb),
               updated_at = NOW()
         WHERE code = :code
        """
    )
    await db.execute(q, {"code": code, "extra_json": json.dumps(extra)})


async def admin_upsert_item(
    db: AsyncSession,
    *,
    code: str,
    title: str,
    description: str | None = None,
    item_type: str = ITEM_TYPE_EFHC_PACKAGE,
    quantity_efhc: Decimal | None = None,
    image_url: str | None = None,
    status: str = "draft",
    price_ton: Decimal | None = None,
    price_usdt: Decimal | None = None,
    pay_currencies: list[str] | None = None,
) -> dict[str, Any]:
    """Создать или обновить карточку товара для admin shop."""
    st, active = _admin_normalize_item_status(status)
    pt = d8(price_ton) if price_ton is not None else None
    pu = d8(price_usdt) if price_usdt is not None else None
    qty = d8(quantity_efhc) if quantity_efhc is not None else None
    pays = [
        str(x).upper() for x in (pay_currencies or []) if str(x).strip()
    ]
    if not pays:
        if pt is not None and pu is not None:
            pays = [PAY_TON, PAY_USDT]
        elif pt is not None:
            pays = [PAY_TON]
        elif pu is not None:
            pays = [PAY_USDT]
        elif item_type == ITEM_TYPE_NFT_VIP:
            pays = [PAY_TON, PAY_USDT]
        else:
            pays = [PAY_TON]
    extra = {
        "item_type": str(item_type),
        "status": st,
    }
    if qty is not None:
        extra["quantity_efhc"] = str(qty)
    if image_url:
        extra["image_url"] = str(image_url)
    before_row = await _admin_get_item_row(db, code=code)
    before = (
        _admin_item_snapshot(before_row)
        if before_row is not None
        else None
    )
    q = text(
        """
        INSERT INTO efhc_core.shop_items (
          code, title, description, item_type, is_active,
          price_ton, price_usdt, pay_currencies, extra_json,
          created_at, updated_at
        )
        VALUES (
          :code, :title, :description, :item_type, :is_active,
          :price_ton, :price_usdt, :pay_currencies, :extra_json::jsonb,
          NOW(), NOW()
        )
        ON CONFLICT (code) DO UPDATE SET
          title = EXCLUDED.title,
          description = EXCLUDED.description,
          item_type = EXCLUDED.item_type,
          is_active = EXCLUDED.is_active,
          price_ton = EXCLUDED.price_ton,
          price_usdt = EXCLUDED.price_usdt,
          pay_currencies = EXCLUDED.pay_currencies,
          extra_json = EXCLUDED.extra_json,
          updated_at = NOW()
        RETURNING id
        """
    )
    row = (
        await db.execute(
            q,
            {
                "code": code,
                "title": title,
                "description": description,
                "item_type": item_type,
                "is_active": active,
                "price_ton": pt,
                "price_usdt": pu,
                "pay_currencies": pays,
                "extra_json": json.dumps(extra),
            },
        )
    ).first()
    after_row = await _admin_get_item_row(db, code=code)
    await _admin_append_item_history(
        db,
        code=code,
        action="upsert",
        detail="admin shop item upsert",
        before=before,
        after=(
            _admin_item_snapshot(after_row)
            if after_row is not None
            else None
        ),
    )
    await db.commit()
    return {
        "ok": True,
        "id": int(row[0]) if row else None,
        "code": code,
    }


# ---- Админ-APIs для управления ценами
# -----------------------------------------


async def admin_set_price(
    db: AsyncSession,
    *,
    code: str,
    price_efhc: Decimal | None = None,
    price_ton: Decimal | None = None,
    price_usdt: Decimal | None = None,
    pay_currencies: list[str] | None = None,
    is_active: bool | None = None,
) -> dict[str, Any]:
    """
    Из админ-панели: задать/обновить цены
    и доступные методы оплаты карточки товара.
    Все цены квантуются до 8 знаков (d8).
    Можно включать/выключать товар.
    """
    pe = d8(price_efhc) if price_efhc is not None else None
    pt = d8(price_ton) if price_ton is not None else None
    pu = d8(price_usdt) if price_usdt is not None else None

    sets = ["updated_at = NOW()"]
    params: dict[str, Any] = {"code": code}

    if pe is not None:
        sets.append("price_efhc = :pe")
        params["pe"] = pe
    if pt is not None:
        sets.append("price_ton = :pt")
        params["pt"] = pt
    if pu is not None:
        sets.append("price_usdt = :pu")
        params["pu"] = pu
    if pay_currencies is not None:
        sets.append("pay_currencies = :pays")
        params["pays"] = pay_currencies
    if is_active is not None:
        sets.append("is_active = :ia")
        params["ia"] = bool(is_active)

    if len(sets) == 1:
        return {"updated": 0}

    q = text(
        """
            UPDATE efhc_core.shop_items
        SET {", ".join(sets)}
        WHERE code = :code
        RETURNING id
    """
    )
    r = (await db.execute(q, params)).first()
    await db.commit()
    return {"updated": 1 if r else 0}


async def admin_delete_item(
    db: AsyncSession,
    *,
    code: str,
) -> dict[str, Any]:
    """Hard delete for admin shop item with order guard."""
    before_row = await _admin_get_item_row(db, code=code)
    used_q = text(
        """
        SELECT COUNT(*)
        FROM efhc_core.shop_orders
        WHERE memo = :code
        """
    )
    used = int((await db.execute(used_q, {"code": code})).scalar() or 0)
    if used > 0:
        raise ValueError(
            "shop item delete blocked: historical orders "
            "reference this code"
        )
    q = text(
        """
        DELETE FROM efhc_core.shop_items
        WHERE code = :code
        RETURNING id
        """
    )
    row = (await db.execute(q, {"code": code})).first()
    await db.commit()
    return {
        "deleted": 1 if row else 0,
        "code": code,
        "last_snapshot": (
            _admin_item_snapshot(before_row)
            if before_row is not None
            else None
        ),
    }


# ---- Витрина заказов пользователя (для WebApp)
# --------------------------------


async def list_orders_for_owner(
    db: AsyncSession,
    *,
    global_id: int,
    limit: int = 50,
    after_id: int | None = None,
) -> list[OrderDTO]:
    """Список заказов только по canonical ``global_id``."""
    limit = max(1, min(int(limit), 200))
    params: dict[str, Any] = {
        "global_id": int(global_id),
        "lim": limit,
    }
    if after_id is None:
        query = text(
            "SELECT id, global_id, type, status, quantity_efhc, "
            "expected_amount, memo, tx_hash, idempotency_key, "
            "created_at, extra "
            "FROM efhc_core.shop_orders "
            "WHERE global_id = :global_id "
            "ORDER BY id DESC LIMIT :lim"
        )
    else:
        params["after_id"] = int(after_id)
        query = text(
            "SELECT id, global_id, type, status, quantity_efhc, "
            "expected_amount, memo, tx_hash, idempotency_key, "
            "created_at, extra "
            "FROM efhc_core.shop_orders "
            "WHERE global_id = :global_id AND id < :after_id "
            "ORDER BY id DESC LIMIT :lim"
        )
    rows = (await db.execute(query, params)).mappings().all()
    return _order_rows_to_dto(rows)


def _order_rows_to_dto(rows: Sequence[Any]) -> list[OrderDTO]:
    out: list[OrderDTO] = []
    for row in rows:
        extra = row.get("extra") or {}
        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except Exception:
                extra = {}
        out.append(
            OrderDTO(
                id=int(row["id"]),
                global_id=int(row["global_id"]),
                status=str(row["status"]),
                memo=row["memo"],
                tx_hash=row["tx_hash"],
                created_at=row["created_at"],
                order_type=row.get("type"),
                quantity_efhc=(
                    str(row["quantity_efhc"])
                    if row.get("quantity_efhc") is not None
                    else None
                ),
                expected_amount=(
                    str(row["expected_amount"])
                    if row.get("expected_amount") is not None
                    else None
                ),
                payment_method=extra.get("payment_method"),
                sku=extra.get("sku"),
            )
        )
    return out


# ---- Админ-витрина заказов (глобальный список с курсором)
# ---------------------


async def admin_list_orders(
    db: AsyncSession,
    *,
    limit: int = 50,
    cursor: str | None = None,
    status: str | None = None,
    item_type: str | None = None,
    global_id: int | None = None,
) -> dict[str, Any]:
    """
    Админская витрина заказов с курсорной пагинацией.
    Сортировка: created_at DESC, id DESC.
    Курсор кодирует (created_at_iso, id)
    через encode_cursor/decode_cursor.

    Фильтры:
      • status    — ORDER_STATUS_*
      • item_type — ITEM_TYPE_EFHC_PACKAGE / ITEM_TYPE_NFT_VIP /
        ITEM_TYPE_VIRTUAL
      • global_id   — конкретный пользователь.
    """
    limit = max(1, min(int(limit or 50), 200))

    after_created_at: str | None = None
    after_id: int | None = None
    if cursor:
        try:
            payload = decode_cursor(cursor)
            ts = payload.get("ts")
            after_created_at = str(ts) if ts is not None else None
            pid = payload.get("id")
            after_id = int(pid) if pid is not None else None
        except Exception as e:
            logger.warning(
                "admin_list_orders: bad cursor %s: %s",
                cursor,
                e,
            )

    conds = ["1 = 1"]
    params: dict[str, Any] = {}

    if status:
        conds.append("o.status = :st")
        params["st"] = status
    if global_id is not None:
        conds.append("o.global_id = :global_id")
        params["global_id"] = int(global_id)
    if item_type:
        conds.append("o.type = :itype")
        params["itype"] = item_type
    if after_created_at and after_id is not None:
        conds.append("(o.created_at, o.id) < (:ca, :cid)")
        params["ca"] = after_created_at
        params["cid"] = after_id

    where_clause = " AND ".join(conds)

    sql_tpl = """
            SELECT
          o.id,
          o.global_id,
          u.username,
          o.type,
          o.status,
          o.memo,
          o.tx_hash,
          o.payment_error_log,
          o.created_at,
          o.extra,
          o.quantity_efhc,
          o.expected_amount
        FROM efhc_core.shop_orders o
        LEFT JOIN efhc_core.users u ON u.global_id = o.global_id
        WHERE {where_clause}
        ORDER BY o.created_at DESC, o.id DESC
        LIMIT :lim
        """
    q = text(sql_tpl.replace("{where_clause}", where_clause))
    params["lim"] = limit + 1
    # +1: определить наличие next_cursor

    rs = await db.execute(q, params)
    rows = rs.fetchall()

    items: list[dict[str, Any]] = []
    for r in rows[:limit]:
        payment_error_log = r[7]
        extra = r[9] or {}
        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except Exception:
                extra = {}
        item_code = extra.get("sku")
        item_title = extra.get("item_title") or item_code
        payment_method = extra.get("payment_method")
        items.append(
            {
                "id": int(r[0]),
                "global_id": f"{int(r[1]):010d}",
                "username": r[2],
                "item_id": None,
                "item_code": item_code,
                "item_title": item_title,
                "item_type": r[3],
                "status": r[4],
                "payment_method": payment_method,
                "memo": r[5],
                "tx_hash": r[6],
                "payment_error_log": (
                    str(payment_error_log)
                    if payment_error_log is not None
                    else None
                ),
                "created_at": r[8].isoformat() if r[8] else None,
                "quantity_efhc": (
                    str(r[10]) if r[10] is not None else None
                ),
                "expected_amount": (
                    str(r[11]) if r[11] is not None else None
                ),
            }
        )

    next_cursor: str | None = None
    if len(rows) > limit:
        last = rows[limit - 1]
        last_created_at = last[8]
        last_id = last[0]
        if last_created_at:
            next_cursor = encode_cursor(
                {
                    "ts": last_created_at.isoformat(),
                    "id": int(last_id),
                }
            )

    return {"items": items, "next_cursor": next_cursor}


# ====================================================================
# Пояснения «для чайника»:
# • Этот модуль не рассылает деньги сам — все денежные движения проводит
# Банковский сервис (transactions_service); здесь мы
# только инициируем списания.
# EFHC.
# • EFHC-пакеты оплачиваются только внешне (TON/USDT).
#   Мы создаём заказ PENDING и генерируем MEMO.
# – EFHC-пакеты: кредит EFHC пользователю из Банка (read-through
# идемпотентность).
# – VIP NFT: создаётся заявка PAID_PENDING_MANUAL
#   (ручная выдача админом).
# • Внутренние EFHC-покупки (виртуальные товары, VIP за EFHC):
# – списание bonus→main с зачислением в Банк
#   (две операции с под-ключами idk).
# – заявка на VIP создаётся как PAID_PENDING_MANUAL (без автодоставки).
# • Безопасность/ИИ:
# – Идемпотентность: все денежные действия
#   используют idempotency_key (или client_nonce).
# client_order_id).
# – Витрина: возвращает флаги доступности методов оплаты
#   и причины отключения для UI.
# кнопок.
# – Запрет минуса: если EFHC не хватает — покупка
#   за EFHC не выполняется.
# выполняется.
# • Админ-витрина:
# – admin_list_orders даёт список заказов с фильтрами
#   и курсором по (created_at, id).
# (created_at,id),
# чтобы админка могла безопасно листать историю без OFFSET.
# ====================================================================

# ====================================================================
# Контрактный facade маршрутов без расхождения DTO
# ====================================================================

from app.contracts.shop_contract import ShopContract
from app.schemas.shop_schemas import (
    ShopCatalogItemOut,
    ShopCatalogOut,
    ShopOrderExternalIn,
    ShopOrderExternalOut,
    ShopPurchaseByEFHCIn,
    ShopPurchaseByEFHCOut,
)

# NOTE (SSOT): фасад ShopFacade ожидает существование этих функций.
# В текущем контуре они служат как контрактные точки расширения.
# Если логика будет реализована в другом модуле, держите эти обёртки
# как стабильный API для routes/facade.


async def get_catalog(*, db: AsyncSession, owner_id: int):
    """Каталог магазина (SKU) для WebApp.

    Канон:
    - Только чтение из efhc_core.shop_items.
    - Никаких денежных операций.
    - Возвращаем items с methods, чтобы router мог добавить дизейблы.
    """
    q = text(
        """
            SELECT
          id, sku, title, description,
          quantity_efhc, COALESCE(is_active, TRUE) AS is_active,
          extra, created_at, updated_at
        FROM efhc_core.shop_items
        WHERE COALESCE(is_active, TRUE) = TRUE
        ORDER BY id ASC
    """
    )
    rows = (await db.execute(q)).mappings().all()
    items = []
    for r in rows:
        item = _item_to_dto(r)
        if item.item_type == ITEM_TYPE_NFT_VIP:
            continue

        methods = {}
        pays_norm = [str(x).upper() for x in item.pay_currencies]
        if PAY_EFHC in pays_norm and item.price_efhc is not None:
            methods["EFHC"] = {"price": str(item.price_efhc)}
        if PAY_TON in pays_norm and item.price_ton is not None:
            methods["TON"] = {"price": str(item.price_ton)}
        if PAY_USDT in pays_norm and item.price_usdt is not None:
            methods["USDT"] = {"price": str(item.price_usdt)}

        items.append(
            ShopCatalogItemOut(
                id=int(r["id"]),
                type=str(item.item_type),
                sku=str(item.code),
                title=str(r["title"]),
                description=(
                    str(r["description"]) if r["description"] else None
                ),
                active=bool(r["is_active"]),
                price_efhc=item.price_efhc,
                ton_enabled=(PAY_TON in pays_norm),
                ton_dest_address=getattr(
                    settings, "TON_MAIN_WALLET", None
                ),
                ton_price_hint=item.price_ton,
                memo_template=(None),
                max_per_user=None,
                stock_total=None,
                stock_left=None,
                image_url=((_extra_obj(r)).get("image_url")),
                created_at=r["created_at"],
                updated_at=r["updated_at"],
                methods=methods,
            )
        )

    return ShopCatalogOut(items=items)


async def create_external_order(
    *,
    db: AsyncSession,
    global_id: int,
    payload: ShopOrderExternalIn,
    client_nonce: str | None,
):
    """Контрактная обёртка для routes: создаёт внешний заказ TON/USDT.

    Канон:
    - Денег в EFHC здесь не списываем.
    - Создаём PENDING-заказ в efhc_core.shop_orders.
    - Идемпотентность — через client_nonce (у нас = Idempotency-Key).
    """
    data = await create_order_external(
        db,
        global_id=int(global_id),
        item_code=str(payload.sku),
        payment_method=str(payload.pay_method).upper(),
        client_order_id=str(client_nonce or ""),
    )
    return data


class ShopFacade(ShopContract):
    """Фасад Shop‑контура: единая точка входа для роутов.

    Что делает:
      • Роуты обращаются только к ShopFacade (контрактный entrypoint).
      • Исключает рассинхрон между routes и services
        по DTO и названиям методов.
    """

    def __init__(self, db: AsyncSession):
        self._db = db

    async def get_catalog(self, owner_id: int):
        return await get_catalog(db=self._db, owner_id=int(owner_id))

    async def create_external_order(
        self,
        global_id: int,
        payload: ShopOrderExternalIn,
        client_nonce: str | None,
    ) -> ShopOrderExternalOut:
        data = await create_external_order(
            db=self._db,
            global_id=int(global_id),
            payload=payload,
            client_nonce=client_nonce,
        )
        return ShopOrderExternalOut(**data)

    async def purchase_by_efhc(
        self,
        global_id: int,
        payload: ShopPurchaseByEFHCIn,
        idempotency_key: str,
    ) -> ShopPurchaseByEFHCOut:
        data = await purchase_with_efhc(
            self._db,
            global_id=int(global_id),
            item_code=payload.sku,
            qty=int(payload.quantity),
            idempotency_key=idempotency_key,
        )
        return ShopPurchaseByEFHCOut(**data)

    async def list_orders_by_owner(
        self,
        global_id: int,
        limit: int,
        cursor: str | None,
    ) -> dict:
        after_id: int | None = None
        if cursor:
            try:
                cur = decode_cursor(cursor)
                raw = cur.get("after_id")
                after_id = int(raw) if raw else None
            except Exception:
                after_id = None

        rows = await list_orders_for_owner(
            self._db,
            global_id=int(global_id),
            limit=int(limit),
            after_id=after_id,
        )
        items = [asdict(r) for r in rows]
        next_cursor = None
        if items:
            next_cursor = encode_cursor(
                {"after_id": int(items[-1]["id"])}
            )
        return {"items": items, "next_cursor": next_cursor}

