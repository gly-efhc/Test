from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from app.models.hub_links_models import HubLink
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

SUPPORT_LINK_CODE_PREFIX = "support_"


def _support_namespace():
    return func.lower(func.trim(HubLink.code)).startswith(
        SUPPORT_LINK_CODE_PREFIX, autoescape=True
    )


def _public_support_link(link: HubLink) -> dict[str, Any]:
    return {
        "id": int(link.id),
        "title": link.title,
        "subtitle": link.subtitle,
        "url": link.url,
        "open_mode": link.open_mode,
        "icon_key": link.icon_key,
    }


async def list_active_support_links(
    db: AsyncSession,
) -> list[dict[str, Any]]:
    stmt = (
        select(HubLink)
        .where(
            _support_namespace(),
            HubLink.is_active.is_(True),
        )
        .order_by(HubLink.sort_order, HubLink.id)
    )
    rows: Sequence[HubLink] = (await db.execute(stmt)).scalars().all()
    return [_public_support_link(row) for row in rows]


async def list_active_hub_links(db: AsyncSession) -> Sequence[HubLink]:
    stmt = (
        select(HubLink)
        .where(~_support_namespace(), HubLink.is_active.is_(True))
        .order_by(HubLink.sort_order, HubLink.id)
    )
    return (await db.execute(stmt)).scalars().all()
