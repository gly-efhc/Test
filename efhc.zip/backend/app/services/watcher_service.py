# backend/app/services/watcher_service.py
# =====================================================================
# EFHC Bot — Вотчер входящих платежей TON (автозачисления через Банк)
# --------------------------------------------------------------------
# Назначение:
# Обрабатывает входящие транзакции TON по адресу проекта, разбирает MEMO
# по канону и выполняет действия: автодоставка EFHC-пакетов,
# создание заявки на NFT (ручная выдача), автоматический депозит EFHC по
# правилам. Все денежные движения — строго через банковский сервис.
#
# Канон/инварианты:
# • Только посекундная генерация в проекте (здесь не применяется).
# • Денежные операции производит единый банк: никакой «эмиссии в обход».
# • P2P запрещён. Обратной конверсии EFHC→kWh нет.
# • NFT: только заявка (PAID_PENDING_MANUAL), никакой автодоставки.
# • Идемпотентность по tx_hash (UNIQUE в ton_inbox_logs) + read-through.
# • Идентификация пользователя:
# 1) по привязанному активному кошельку (user_wallets),
# 2) при отсутствии — по tg_id из MEMO.
#
# ИИ-защиты / самовосстановление:
# • Read-through: повторная обработка одной транзакции не даёт дублей
# (UNIQUE(tx_hash) + возврат финального результата).
# • «Догон хвостов»: повторная обработка логов
#   с не финальными статусами.
# у которых next_retry_at IS NULL или <= NOW().
# • Деградация: сетевые/временные ошибки TON API не рушат цикл —
# помечаются error_* и переигрываются отдельно.
#
# Запреты:
# • Этот модуль не создаёт NFT и не меняет ставки генерации.
# • Не трогает пользовательские балансы напрямую — только через Банк
# (app.services.transactions_service).
# =====================================================================

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.services.transactions_service import (
    credit_user_from_bank,
)
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

_CREDIT_ORIG = credit_user_from_bank
# noqa: E402
# noqa: E402
from app.integrations.ton_api import TonAPIClient, TonAPIEvent  # noqa
from app.services.shop_service import (  # noqa: E402
    ITEM_TYPE_EFHC_PACKAGE,
    ITEM_TYPE_NFT_VIP,
)

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

MAIN_TON_WALLET: str = (
    getattr(settings, "TON_MAIN_WALLET", None)
    or getattr(settings, "MAIN_WALLET", "")
    or ""
)
if not MAIN_TON_WALLET:
    logger.warning(
        "[WATCHER] TON_MAIN_WALLET/MAIN_WALLET is not set in config "
        "— watcher will not work correctly."
    )

# --------------------------------------------------------------------
# Регулярные выражения парсинга MEMO (строго по канону)
# --------------------------------------------------------------------
# NOTE: regex groups must NOT contain spaces after ?P
_RE_SIMPLE_EFHC = re.compile(r"^EFHC(?P<tg_id>\d{1,20})$")
_RE_SKU_EFHC = re.compile(
    r"^SKU:EFHC\|Q:(?P<qty>\d{1,12})\|TG:(?P<tg_id>\d{1,20})$"
)
_RE_SKU_NFT = re.compile(
    r"^SKU:NFT_VIP\|Q:(?P<qty>\d{1,12})\|TG:(?P<tg_id>\d{1,20})$"
)

# PaymentIntent payload (A+B): EFHC:<purpose>:<intent_id>:<tg_id>
# exact: memo == payload
_RE_INTENT_EXACT = re.compile(
    r"^EFHC:(?P<purpose>deposit_efhc|shop_external)"
    r":(?P<intent_id>\d{1,20}):(?P<tg_id>\d{1,20})$"
)
# substr: payload is inside a larger memo
_RE_INTENT_SUBSTR = re.compile(
    r"EFHC:(?P<purpose>deposit_efhc|shop_external)"
    r":(?P<intent_id>\d{1,20}):(?P<tg_id>\d{1,20})"
)

# --------------------------------------------------------------------
# Константы статусов логов inbox (тон-инбокс)
# --------------------------------------------------------------------
# Запись создана/обновлена, ещё ничего не делали.
STATUS_RECEIVED = "received"
STATUS_PARSED = "parsed"  # распознали тип/пользователя/параметры
STATUS_CREDITED = "credited"  # EFHC начислены успешно
STATUS_PAID_AUTO = "paid_auto"  # заказ найден и оплачен (для EFHC SKU)
# NFT-заявка создана/обновлена (ручная выдача).
STATUS_NFT_MANUAL = "paid_pending_manual"
STATUS_ERROR_MEMO = "error_bad_memo"  # нераспознаваемый MEMO
# Не нашли пользователя ни по кошельку, ни по MEMO.
STATUS_ERROR_USER = "error_user_not_found"
# Сетевой/временный сбой внешнего API (TON).
STATUS_ERROR_NET = "error_network_retry"
STATUS_ERROR_SYS = "error_retry"  # общий сбой (ретрай)
# Простой EFHC-депозит без однозначного прайса — ждём маппинг.
STATUS_PENDING_MAP = "parsed_pending_mapping"
STATUS_PENDING_MANUAL = "pending_manual"

FINAL_STATUSES = {
    STATUS_CREDITED,
    STATUS_PAID_AUTO,
    STATUS_NFT_MANUAL,
    STATUS_PENDING_MANUAL,
}

# --------------------------------------------------------------------
# DTO входящей транзакции (если вызывают из scheduler без TonAPIEvent)
# --------------------------------------------------------------------
@dataclass
class IncomingTx:
    tx_hash: str
    from_address: str
    to_address: str
    amount: Decimal
    memo: str
    utime: int  # unixtime сек


# =====================================================================
# Вспомогательные функции: нормализация, парсинг MEMO, работа с логами,
# поиск пользователя/заказов
# =====================================================================


def _now_utc() -> datetime:
    """Текущее время UTC (timezone-aware)."""
    return datetime.now(UTC)


def _retry_backoff_delay(retries_count: int) -> timedelta:
    """Экспоненциальная задержка для ретраев.

    Цель:
    - Снизить нагрузку на TON API и БД в периоды нестабильности.
    - Держать задержку ограниченной (cap).

    retries_count — ожидается "после" инкремента.
    """
    n = max(1, int(retries_count))
    base_sec = 30
    cap_sec = 15 * 60
    sec = base_sec * (2 ** (n - 1))
    sec = min(cap_sec, sec)
    return timedelta(seconds=int(sec))


async def _get_inbox_retries_count(
    db: AsyncSession,
    *,
    tx_hash: str,
) -> int:
    """Получить текущее retries_count из ton_inbox_logs (0 если нет)."""
    q = text("""
        SELECT COALESCE(retries_count, 0)  # nosec B608
          FROM efhc_core.ton_inbox_logs
         WHERE tx_hash = :tx_hash
        """
    )
    r = await db.execute(q, {"tx_hash": str(tx_hash)})
    v = r.scalar()
    try:
        return int(v or 0)
    except Exception:
        return 0


def _norm_addr(addr: str) -> str:
    """Простейшая нормализация TON - адреса (убираем пробелы)."""
    return (addr or "").replace(" ", "")


def _parse_memo(memo: str) -> tuple[str, dict[str, int]]:
    """
    Детерминированно распарсить MEMO по канону.

    Возвращает:
        (kind, params), где:
            kind ∈ {"simple_efhc", "sku_efhc", "sku_nft", "bad"}
            params:
              • simple_efhc: {"tg_id": int}
              • sku_efhc   : {"tg_id": int, "qty": int}
              • sku_nft    : {"tg_id": int, "qty": int}
    """
    memo = (memo or "").strip()
    m = _RE_SIMPLE_EFHC.match(memo)
    if m:
        return "simple_efhc", {"tg_id": int(m.group("tg_id"))}
    m = _RE_SKU_EFHC.match(memo)
    if m:
        return "sku_efhc", {
            "tg_id": int(m.group("tg_id")),
            "qty": int(m.group("qty")),
        }
    m = _RE_SKU_NFT.match(memo)
    if m:
        return "sku_nft", {
            "tg_id": int(m.group("tg_id")),
            "qty": int(m.group("qty")),
        }
    return "bad", {}


def _parse_intent_payload(memo: str) -> dict[str, Any] | None:
    memo = (memo or "").strip()

    # Канон: payload сам по себе строка EFHC:...
    m = _RE_INTENT_EXACT.match(memo)
    if m:
        return {
            "purpose": str(m.group("purpose")),
            "intent_id": int(m.group("intent_id")),
            "tg_id": int(m.group("tg_id")),
            "payload": memo,
        }

    # Для jetton-transfer (USDT) forward payload может быть вложен
    # в memo/комментарий. Разрешаем искать точное вхождение EFHC:...
    # как подстроку.
    m2 = _RE_INTENT_SUBSTR.search(memo)
    if not m2:
        return None
    payload = str(m2.group(0))
    return {
        "purpose": str(m2.group("purpose")),
        "intent_id": int(m2.group("intent_id")),
        "tg_id": int(m2.group("tg_id")),
        "payload": payload,
    }


async def _record_unmatched_incoming(
    db: AsyncSession,
    *,
    tx_hash: str,
    asset: str,
    amount_asset: Decimal,
    from_address: str,
    to_address: str,
    memo: str,
    utime: int,
    reason: str,
) -> None:
    """Зафиксировать входящую транзакцию без каноничного payload.

    Правило SSOT:
    • Автоначисление возможно:
      - по payload/intent (канон EFHC:purpose:id:tg_id),
      - либо при пустом MEMO по привязанному кошельку,
        с обязательной записью в unmatched_incoming.
    """

    q = text("""
        INSERT INTO efhc_core.unmatched_incoming (
            tx_hash, asset, amount_asset_d8,
            from_address, to_address, memo,
            utime, reason, created_at
        ) VALUES (
            :tx, :asset, :amt,
            :fa, :ta, :memo,
            :ut, :reason, :now
        )
        ON CONFLICT (tx_hash) DO NOTHING
        """
    )  # nosec B608
    await db.execute(
        q,
        {
            "tx": str(tx_hash),
            "asset": str(asset or "TON").upper(),
            "amt": d8(amount_asset),
            "fa": str(from_address or ""),
            "ta": str(to_address or ""),
            "memo": str(memo or ""),
            "ut": int(utime or 0),
            "reason": str(reason or "unmatched"),
            "now": _now_utc(),
        },
    )


async def _confirm_payment_intent(
    db: AsyncSession,
    *,
    intent_id: int,
    tg_id: int,
    purpose: str,
    payload: str,
    tx_hash: str,
    amount_asset: Decimal,
    asset: str,
    to_address: str,
) -> str:
    """Подтверждает payment_intent и выполняет side-effects.

    Правила:
    • Атомарно (FOR UPDATE) → no-op если уже CONFIRMED.
    • deposit_efhc: credit MAIN.
    • shop_external: отмечаем заказ PAID_AUTO;
      EFHC_PACKAGE → credit MAIN.
    """
    q = text(
        "\n".join(
            [
                "SELECT * FROM efhc_core.payment_intents",  # nosec B608
                " WHERE id = :iid",
                "   AND tg_id = :tg",  # nosec B608
                "   AND payload = :p",
                " FOR UPDATE",
            ]
        )
    )
    row = (
        await db.execute(
            q,
            {
                "iid": int(intent_id),
                "tg": int(tg_id),
                "p": str(payload),
            },
        )
    ).mappings().first()
    if not row:
        return STATUS_ERROR_MEMO

    status_val = str(row.get("status") or "")
    if status_val == "CONFIRMED":
        if purpose == "deposit_efhc":
            return STATUS_CREDITED
        if purpose == "shop_external":
            return STATUS_PAID_AUTO
        return STATUS_CREDITED

    # Базовые проверки соответствия (asset, destination, amount).
    asset_expected = str(row.get("asset") or "TON").upper()
    if str(asset or "TON").upper() != asset_expected:
        return STATUS_ERROR_SYS

    to_expected = _norm_addr(str(row.get("to_address") or ""))
    if to_expected and _norm_addr(str(to_address or "")) != to_expected:
        return STATUS_ERROR_SYS

    amt_expected = d8(row.get("amount_asset_d8") or 0)
    if d8(amount_asset) < amt_expected:
        return STATUS_ERROR_SYS

    # Защита: один tx_hash не может подтвердить второй intent.
    # Даже если уникальность есть на уровне БД, возвращаем
    # управляемую ошибку вместо IntegrityError.
    q_tx = text(  # nosec B608
        "\n".join(
            [
    # nosec B608
                "SELECT id FROM efhc_core.payment_intents",
                " WHERE external_tx_hash = :h",
                "   AND id <> :iid",  # nosec B608
                " LIMIT 1",
            ]
        )
    )
    tx_row = (
        await db.execute(
            q_tx,
            {
                "h": str(tx_hash),
                "iid": int(intent_id),
            },
        )
    ).first()
    if tx_row:
        return STATUS_ERROR_SYS

    q_upd = text(
        "\n".join(
            [
                "UPDATE efhc_core.payment_intents",
                "   SET status = 'CONFIRMED',",
                "       external_tx_hash = :h,",
                "       updated_at = NOW()",
                " WHERE id = :iid",
            ]
        )
    )
    await db.execute(q_upd, {"iid": int(intent_id), "h": str(tx_hash)})

    if purpose == "deposit_efhc":
        efhc_amt = d8(row.get("efhc_amount_d8") or 0)
        # IMPORTANT:
        # В тестах есть два паттерна monkeypatch:
        # 1) watcher_service.credit_user_from_bank
        # 2) wallets_service.credit_user_from_bank
        # Поэтому выбираем хук:
        # - если credit_user_from_bank заменён в watcher_service,
        #   используем его;
        # - иначе берём wallets_service.credit_user_from_bank.
        credit_fn = credit_user_from_bank
        if credit_fn is _CREDIT_ORIG:
            from . import wallets_service as ws

            credit_fn = ws.credit_user_from_bank

        await credit_fn(
            db,
            tg_id=int(tg_id),
            amount_efhc=efhc_amt,
            reason="deposit_efhc_confirm",
            idempotency_key=f"intent:{intent_id}:confirm",
        )
        await db.commit()
        return STATUS_CREDITED

    if purpose == "shop_external":
        # Заказ связан по memo=payload.
        q_order = text(
            "\n".join(
                [
                    "SELECT o.id AS order_id,",
                    "       o.item_id AS item_id",
                    "  FROM efhc_core.shop_orders o",
                    " WHERE o.tg_id = :tg",
                    "   AND o.memo = :m",
                    "   AND o.status = 'PENDING'",
                    " ORDER BY o.id ASC",
                    " LIMIT 1",
                ]
            )
        )
        o = (
            await db.execute(
                q_order,
                {"tg": int(tg_id), "m": str(payload)},
            )
        ).mappings().first()
        if o:
            await db.execute(
                text("UPDATE efhc_core.shop_orders "
                    "SET status = 'PAID_AUTO', tx_hash = :h, "
                    "updated_at = NOW() WHERE id = :oid"
                ),  # nosec B608
                {"h": str(tx_hash), "oid": int(o["order_id"])},
            )

            # Если это EFHC_PACKAGE — кредит MAIN количеством
            # из item.extra.
            q_item = text(
                "\n".join(
                    [
                        "SELECT item_type, extra_json",
                        "  FROM efhc_core.shop_items",
                        " WHERE id = :iid",
                        " LIMIT 1",
                    ]
                )
            )
            it = (
                await db.execute(q_item, {"iid": int(o["item_id"])})
            ).mappings().first()
            if (
                it
                and str(it.get("item_type") or "")
                == ITEM_TYPE_EFHC_PACKAGE
            ):
                extra = it.get("extra_json") or {}
                qty = 0
                try:
                    qty = int(extra.get("quantity_efhc") or 0)
                except Exception:
                    qty = 0
                if qty > 0:
                    from . import wallets_service as ws

                    await ws.credit_user_from_bank(
                        db,
                        tg_id=int(tg_id),
                        amount_efhc=d8(Decimal(qty)),
                        reason="shop_external_efhc_package_confirm",
                        idempotency_key=(
                            f"intent:{intent_id}:shop_credit"
                        ),
                    )
            await db.commit()
            return STATUS_PAID_AUTO

        await db.commit()
        return STATUS_PAID_AUTO

    await db.commit()
    return STATUS_ERROR_SYS

async def _ton_log_upsert(
    db: AsyncSession,
    *,
    tx: IncomingTx | TonAPIEvent,
    status: str,
    note: str | None = None,
    next_retry_at: datetime | None = None,
) -> None:
    # nosec B608
    """Upsert ton_inbox_logs (read-through, UNIQUE tx_hash)."""
    q = """
        INSERT INTO efhc_core.ton_inbox_logs
          (
            tx_hash,
            from_address,
            to_address,
            amount,
            memo,
            utime,
            status,
            retries_count,
            last_error,
            next_retry_at,
            processed_at,
            created_at,
            updated_at
          )
        VALUES
          (
            :tx_hash,
            :from_addr,
            :to_addr,
            :amount,
            :memo,
            to_timestamp(:utime),
            :status,
            CASE WHEN :is_error THEN 1 ELSE 0 END,
            :note,
            :next_retry_at,
            CASE
              WHEN :status IN (
                :st_credited,
                :st_paid_auto,
                :st_nft_manual
              ) THEN NOW()
              ELSE NULL
            END,
            NOW(),
            NOW()
          )
        ON CONFLICT (tx_hash) DO UPDATE SET
          status = EXCLUDED.status,
          retries_count = CASE
            WHEN EXCLUDED.status LIKE 'error%%'
            THEN efhc_core.ton_inbox_logs.retries_count + 1
            ELSE efhc_core.ton_inbox_logs.retries_count
          END,
          last_error = CASE
            WHEN EXCLUDED.status LIKE 'error%%'
            THEN EXCLUDED.last_error
            ELSE NULL
          END,
          next_retry_at = EXCLUDED.next_retry_at,
          updated_at = NOW(),
          processed_at = CASE
            WHEN EXCLUDED.status IN (
              :st_credited,
              :st_paid_auto,
              :st_nft_manual
            ) THEN NOW()
            ELSE efhc_core.ton_inbox_logs.processed_at
          END
        """

    await db.execute(
        text(q),
        {
            "tx_hash": tx.tx_hash,
            "from_addr": _norm_addr(tx.from_address),
            "to_addr": _norm_addr(tx.to_address),
            "amount": str(d8(tx.amount)),
            "memo": (tx.memo or "").strip(),
            "utime": int(getattr(tx, "utime", 0) or 0),
            "status": status,
            "is_error": status.startswith("error"),
            "note": (note or None),
            "next_retry_at": next_retry_at,
            "st_credited": STATUS_CREDITED,
            "st_paid_auto": STATUS_PAID_AUTO,
            "st_nft_manual": STATUS_NFT_MANUAL,
        },
    )


async def _ton_log_exists_final(db: AsyncSession, tx_hash: str) -> bool:
    # nosec B608
    """Проверка: транзакция уже в финальном статусе (read-through)."""
    q = (
        "SELECT status FROM efhc_core.ton_inbox_logs "
        "WHERE tx_hash = :h LIMIT 1"
    )
    row = await db.execute(text(q), {"h": tx_hash})  # nosec B608
    rec = row.fetchone()
    if not rec:
        return False
    return rec[0] in FINAL_STATUSES


async def _find_user_by_wallet(
    db: AsyncSession,
    addr: str,
) -> int | None:
    """
    Поиск пользователя по привязанному TON-кошельку.

    Канон:
      • Привязки хранятся в efhc_core.user_wallets.
      • user_wallets.tg_id = tg_id пользователя.
      • Используем только is_active = TRUE и is_blocked = FALSE.
    """
    if not addr:
        return None
    naddr = _norm_addr(addr)
    row = await db.execute(
        text("""
            SELECT tg_id
              FROM efhc_core.user_wallets
             WHERE ton_address = :wa
               AND is_active   = TRUE  # nosec B608
               AND is_blocked  = FALSE
             LIMIT 1
            """
        ),
        {"wa": naddr},
    )
    r = row.fetchone()
    return int(r[0]) if r and r[0] is not None else None


async def _find_user_by_tg_id(
    db: AsyncSession,
    tg_id: int,
) -> int | None:
    """
    Поиск пользователя по tg_id.

    Канон:
      • Во всех денежных сервисах tg_id == tg_id.
      • Здесь проверяем наличие записи в users.
        Если нет — возвращаем None.
    """
    row = await db.execute(
        text("""
            SELECT tg_id
              FROM efhc_core.users
             WHERE tg_id = :tg
             LIMIT 1
            """  # nosec B608
        ),
        {"tg": int(tg_id)},
    )
    r = row.fetchone()
    return int(r[0]) if r and r[0] is not None else None


async def _find_pending_order(
    db: AsyncSession,
    *,
    tg_id: int,
    qty: int,
) -> int | None:
    """
    Поиск PENDING-заказа EFHC-пакета по MEMO SKU:EFHC|Q:<qty>|TG:<id>.

    Логика:
      • Ищем активный товар ITEM_TYPE_EFHC_PACKAGE с quantity_efhc,
        равным qty.
      • Затем берём самый старый PENDING-заказ на этот item_id.
    """
    row = await db.execute(
        text("""
            SELECT o.id
              FROM efhc_core.shop_orders o
              JOIN efhc_core.shop_items i ON i.id = o.item_id
             WHERE o.tg_id = :tg_id
               AND o.status  = 'PENDING'
               AND i.item_type = :itype  # nosec B608
               AND COALESCE(
                     (i.extra_json->>'quantity_efhc')::bigint,
                     0
                   ) = :q
             ORDER BY o.created_at ASC, o.id ASC
             LIMIT 1
            """
        ),
        {
            "tg_id": int(tg_id),
            "itype": ITEM_TYPE_EFHC_PACKAGE,
            "q": int(qty),
        },
    )
    r = row.fetchone()
    return int(r[0]) if r else None


async def _mark_order_paid_auto(
    db: AsyncSession,
    order_id: int,
    tx_hash: str,
) -> None:
    """Перевести заказ в PAID_AUTO и привязать tx_hash."""
    res = await db.execute(
        text("""
            UPDATE efhc_core.shop_orders
               SET status = 'PAID_AUTO',
                   tx_hash = COALESCE(tx_hash, :h),
                   updated_at = NOW()
             WHERE id = :oid
               AND status = 'PENDING'
            """  # nosec B608
        ),
        {"oid": int(order_id), "h": tx_hash},
    )
    if getattr(res, "rowcount", 0) == 0:
        logger.warning(
            "PAID_AUTO update skipped (not PENDING): oid=%s",
            order_id,
        )


async def _create_nft_manual_request(
    db: AsyncSession,
    tg_id: int,
    *,
    tx_hash: str,
    qty: int = 1,
) -> int:
    """
    NFT: создаём заявку PAID_PENDING_MANUAL в shop_orders.

    Канон:
      • Здесь нет автодоставки NFT — только заявка.
      • Админ вручную сопоставляет заявку с NFT и передаёт пользователю.
    """
    # Пытаемся найти NFT-карточку по item_type = ITEM_TYPE_NFT_VIP.
    row = await db.execute(
        text("""
            INSERT INTO efhc_core.shop_orders
                (
                    tg_id,
                    item_id,
                    status,
                    tx_hash,
                    created_at,
                    updated_at  # nosec B608
                )
            SELECT :tg_id, i.id, 'PAID_PENDING_MANUAL', :h, NOW(), NOW()
              FROM efhc_core.shop_items i
             WHERE i.item_type = :itype
               AND COALESCE(i.is_active, TRUE) = TRUE
             ORDER BY i.id ASC
             LIMIT 1
            ON CONFLICT DO NOTHING
            RETURNING id
            """
        ),
        {
            "tg_id": int(tg_id),
            "h": tx_hash,
            "itype": ITEM_TYPE_NFT_VIP,
        },
    )
    r = row.fetchone()
    if r:
        return int(r[0])

    # Если в каталоге нет NFT-позиции — создаём «обезличенную» заявку.
    row2 = await db.execute(
        text("""
            INSERT INTO efhc_core.shop_orders
                (tg_id, status, tx_hash, created_at, updated_at)
            VALUES (:tg_id, 'PAID_PENDING_MANUAL', :h, NOW(), NOW())
            RETURNING id
            """
        ),
        {"tg_id": int(tg_id), "h": tx_hash},
    )
    r2 = row2.fetchone()  # nosec B608
    if r2 is None:
        raise RuntimeError("shop_order_insert_failed")
    return int(r2[0])


async def _resolve_simple_deposit_qty(
    db: AsyncSession,
    *,
    amount_ton: Decimal,
) -> int | None:
    """Определить qty по price_ton EFHC-товара; иначе вернуть None."""
    row = await db.execute(
        text("""
            SELECT price_ton
              FROM efhc_core.shop_items
             WHERE item_type = :itype
               AND COALESCE(is_active, TRUE) = TRUE
               AND price_ton IS NOT NULL
             ORDER BY id ASC
             LIMIT 1
            """
        ),
        {"itype": ITEM_TYPE_EFHC_PACKAGE},  # nosec B608
    )
    r = row.fetchone()
    if not r or r[0] is None:
        return None
    try:
        price = d8(r[0])
        if price <= 0:
            return None
        qty = int(d8(amount_ton) / price)
        return qty if qty > 0 else None
    except Exception:
        return None


# =====================================================================
# Ядро обработки одной транзакции (read-through идемпотентность)
# =====================================================================

async def process_incoming_tx(
    db: AsyncSession,
    tx: IncomingTx | TonAPIEvent,
) -> str:
    """
    Обрабатывает одну входящую транзакцию TON.

    Вход:
      • tx_hash, from_address, to_address, amount, memo, utime.

    Итог:
      • Статус из набора FINAL / ERROR_* / STATUS_PENDING_MAP.
      • Побочные эффекты:
          – запись/обновление efhc_core.ton_inbox_logs,
          – начисление EFHC (credit_user_from_bank),
          – перевод заказа в PAID_AUTO,
          – создание заявки NFT (PAID_PENDING_MANUAL).

    Идемпотентность:
      • UNIQUE(tx_hash) в ton_inbox_logs.
      • Повторные вызовы для одной и той же транзакции безопасны.
    """
    # Нормализуем адрес назначения и отфильтровываем «чужие» транзакции.
    to_addr = _norm_addr(getattr(tx, "to_address", ""))
    main_addr = _norm_addr(MAIN_TON_WALLET)
    if MAIN_TON_WALLET and to_addr != main_addr:
        # Мягкий skip: фиксировать в лог нет смысла, это не наш кошелёк.
        return "skip:not_our_wallet"

    # 1) Быстрый read-through: если уже финализировано — возврат статуса
    if await _ton_log_exists_final(db, tx.tx_hash):
        logger.debug("[WATCHER] tx %s already finalized", tx.tx_hash)
        return "already_final"

    # 2) Upsert «получили»
    await _ton_log_upsert(db, tx=tx, status=STATUS_RECEIVED)

    try:
        # 2.1) PaymentIntent payload (A+B) имеет приоритет.
        ip = _parse_intent_payload(getattr(tx, "memo", "") or "")
        if ip:
            await _ton_log_upsert(db, tx=tx, status=STATUS_PARSED)
            try:
                st = await _confirm_payment_intent(
                    db,
                    intent_id=int(ip["intent_id"]),
                    tg_id=int(ip["tg_id"]),
                    purpose=str(ip["purpose"]),
                    payload=str(ip["payload"]),
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    amount_asset=d8(getattr(tx, "amount", 0)),
                    asset="TON",
                    to_address=str(getattr(tx, "to_address", "")),
                )
            except Exception as e:
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset="TON",
                    amount_asset=d8(getattr(tx, "amount", 0)),
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="intent_confirm_failed",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note=f"Intent confirm failed: {e}",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            await _ton_log_upsert(db, tx=tx, status=st)
            return st

        # 3) Идентификация: приоритет у привязанного кошелька.
        found_by_wallet = False
        tg_id: int | None = await _find_user_by_wallet(
            db,
            tx.from_address,
        )
        if tg_id is not None:
            found_by_wallet = True

        kind: str = "bad"
        params: dict[str, int] = {}


        # 3.0) КАНОН: автоначисление без MEMO допускается
        # ТОЛЬКО для входящих EFHC (jetton) и только если
        # from_address привязан к tg_id в user_wallets.
        # Для TON/чужих jetton: без MEMO — не начисляем.
        memo_s = str(getattr(tx, "memo", "") or "").strip()
        efhc_master = str(
            getattr(settings, "EFHC_JETTON_MASTER_ADDRESS", "")
            or ""
        ).strip().upper()
        tx_asset = str(getattr(tx, "asset", "TON") or "TON")
        tx_master = str(
            getattr(tx, "jetton_master", "") or ""
        ).strip().upper()

        if found_by_wallet and not memo_s:
            if tx_asset == "JETTON" and tx_master == efhc_master:
                dec_raw = getattr(settings, "EFHC_JETTON_DECIMALS", 8)
                dec = int(dec_raw) if dec_raw is not None else 8
                raw_amt = Decimal(str(getattr(tx, "amount_asset", 0)))
                amt = d8(raw_amt / (Decimal(10) ** dec))
                if amt > 0:
                    await credit_user_from_bank(
                        db=db,
                        tg_id=int(tg_id),
                        amount_efhc=amt,
                        reason="efhc_jetton_nomemo_wallet_bound",
                        idempotency_key=(
                            f"jetton:efhc:nomemo:{tx.tx_hash}"
                        ),
                    )
                    await _ton_log_upsert(
                        db,
                        tx=tx,
                        status=STATUS_CREDITED,
                        note="EFHC jetton nomemo wallet-bound",
                    )
                    return STATUS_CREDITED

                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note="EFHC jetton nomemo amount<=0",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_MEMO,
                note="No memo but asset is not EFHC jetton",
                next_retry_at=None,
            )
            return "skip:nomemo_not_efhc"

        # 3.0b) Если MEMO пустой и кошелёк НЕ привязан к пользователю,
        # то это «вне бота» и без идентификации. По канону — игнор.
        # Никаких начислений и никаких unmatched-записей.
        if not memo_s and tg_id is None:
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_USER,
                note="No memo and wallet is not bound: ignored",
                next_retry_at=None,
            )
            return "skip:nomemo_unbound"

        if tg_id is None:
            # Нет привязки кошелька → пробуем MEMO
            kind, params = _parse_memo(getattr(tx, "memo", "") or "")
            if kind == "bad":
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset=str(getattr(tx, "asset", "TON")),
                    amount_asset=d8(
                        getattr(tx, "amount_asset", 0)
                        or getattr(tx, "amount", 0)
                    ),

                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="unmatched_payload",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note="Unrecognized MEMO (pending manual)",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            tg_id = params.get("tg_id")
            if not tg_id:
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_ERROR_USER,
                    note="Missing TG in memo",
                    next_retry_at=None,
                )
                return STATUS_ERROR_USER

            tg_id = await _find_user_by_tg_id(db, tg_id)

        # Если и сейчас не нашли пользователя — это ошибка данных.
        if tg_id is None:
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_USER,
                note="User not found by wallet/memo",
                next_retry_at=None,
            )
            return STATUS_ERROR_USER

        # 4) Разбор MEMO, если ещё не сделали (user найден по кошельку).
        if kind == "bad":
            kind, params = _parse_memo(getattr(tx, "memo", "") or "")

        await _ton_log_upsert(db, tx=tx, status=STATUS_PARSED)

        # 5) Ветвление по типу MEMO
        if kind == "sku_efhc":
            # Автодоставка EFHC-пакета
            qty = int(params.get("qty", 0))
            if qty <= 0:
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_ERROR_MEMO,
                    note="EFHC qty <= 0",
                )
                return STATUS_ERROR_MEMO

            # 5.1) Найдём PENDING-заказ на этот пакет, если есть
            order_id = await _find_pending_order(
                db,
                tg_id=tg_id,
                qty=qty,
            )
            if order_id:
                await _mark_order_paid_auto(
                    db,
                    order_id=order_id,
                    tx_hash=tx.tx_hash,
                )

            # 5.2) Начислим EFHC пользователю (1:1 по qty) через Банк
            await credit_user_from_bank(
                db=db,
                tg_id=int(tg_id),
                amount_efhc=d8(qty),
                reason="shop_auto_delivery",
                idempotency_key=f"ton:sku_efhc:{tx.tx_hash}",
            )

            status = STATUS_PAID_AUTO if order_id else STATUS_CREDITED
            await _ton_log_upsert(db, tx=tx, status=status)
            return status

        elif kind == "sku_nft":
            # 5.3) NFT — только заявка (ручная выдача)
            qty_raw = params.get("qty", 1)
            qty = int(qty_raw) if qty_raw is not None else 1
            await _create_nft_manual_request(
                db,
                tg_id=int(tg_id),
                tx_hash=tx.tx_hash,
                qty=qty,
            )
            await _ton_log_upsert(db, tx=tx, status=STATUS_NFT_MANUAL)
            return STATUS_NFT_MANUAL

        elif kind == "simple_efhc":
            # 5.4) Простой депозит EFHC<tg_id>.
            qty = await _resolve_simple_deposit_qty(
                db,
                amount_ton=d8(tx.amount),
            )
            if qty and qty > 0:
                await credit_user_from_bank(
                    db=db,
                    tg_id=int(tg_id),
                    amount_efhc=d8(qty),
                    reason="simple_deposit_auto",
                    idempotency_key=f"ton:simple:{tx.tx_hash}",
                )
                await _ton_log_upsert(db, tx=tx, status=STATUS_CREDITED)
                return STATUS_CREDITED

            # Нельзя однозначно вычислить — ждём ручной маппинг
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_PENDING_MAP,
                note="Await mapping/pricing",
                next_retry_at=None,
            )
            return STATUS_PENDING_MAP

        else:
            # Неподдерживаемый формат:
            # • если user найден по кошельку, это не ошибка MEMO,
            #   а "неразобранный кейс" → pending manual
            if found_by_wallet:
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset="TON",
                    amount_asset=d8(getattr(tx, "amount", 0)),
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="unsupported_memo_wallet_bound",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note=(
                        "Unsupported memo for wallet-bound user: "
                        f"{kind}"
                    ),
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_MEMO,

                note=f"Unsupported kind {kind}",
                next_retry_at=None,
            )
            return STATUS_ERROR_MEMO

    except Exception as e:
        # Общий сбой — помечаем и назначаем ретрай
        logger.exception(
            "[WATCHER] process tx failed %s: %s",
            getattr(tx, "tx_hash", "?"),
            e,
        )
        prev = await _get_inbox_retries_count(
            db,
            tx_hash=getattr(tx, "tx_hash", ""),
        )
        # В upsert retries_count будет увеличен ещё на 1.
        next_count = int(prev) + 1
        delay = _retry_backoff_delay(next_count)
        await _ton_log_upsert(
            db,
            tx=tx,
            status=STATUS_ERROR_SYS,
            note=str(e),
            next_retry_at=_now_utc() + delay,
        )
        return STATUS_ERROR_SYS


# =====================================================================
# Высокоуровневые циклы: чтение из TON API и догон «хвостов»
# =====================================================================

async def process_incoming_payments(
    db: AsyncSession,
    *,
    limit: int = 200,
    since_utime: int | None = None,
) -> dict[str, int]:
    """
    Получить из TON API порцию входящих платежей и обработать
    их идемпотентно.

    Вход:
      • limit, since_utime (unixtime).
        Если since_utime не задан — TonAPIClient решает сам.

    Выход:
      • Счётчики по статусам.

    ИИ - защита:
      • Сетевые ошибки TON API не приводят к падению цикла.
    """
    stats: dict[str, int] = {}
    client = TonAPIClient()

    if not MAIN_TON_WALLET:
        logger.warning(
            "[WATCHER] MAIN_TON_WALLET is empty, skip fetching"
        )
        return {"error_network": 1}

    try:
        events: list[TonAPIEvent] = await client.get_incoming_payments(
            to_address=MAIN_TON_WALLET,
            limit=int(limit),
            since_utime=since_utime,
        )
    except Exception as e:
        logger.warning("[WATCHER] TonAPI fetch failed: %s", e)
        return {"error_network": 1}

    for ev in events:
        st = await process_incoming_tx(db, ev)
        stats[st] = stats.get(st, 0) + 1

    return stats


async def reprocess_unfinished_logs(
    db: AsyncSession,
    *,
    limit: int = 500,
) -> dict[str, int]:
    """Догон ton_inbox_logs с не финальными статусами, готовых к ретраю.

    Вход:
      • limit — ограничение на количество записей за проход.

    Выход:
      • Счётчики по статусам после повторной обработки.
    """
    stats: dict[str, int] = {}
    row = await db.execute(
        text("""
            SELECT tx_hash,
                   from_address,
                   to_address,
                   amount,
                   memo,
                   EXTRACT(
                     EPOCH FROM COALESCE(utime, NOW())
                   )::bigint AS utime
              FROM efhc_core.ton_inbox_logs
             WHERE status NOT IN (:s1, :s2, :s3)
    # nosec B608
               AND (next_retry_at IS NULL OR next_retry_at <= NOW())
             ORDER BY COALESCE(updated_at, created_at) ASC
             LIMIT :lim
            """
        ),
        {
            "s1": STATUS_CREDITED,
            "s2": STATUS_PAID_AUTO,
            "s3": STATUS_NFT_MANUAL,
            "lim": int(limit),
        },
    )
    items = row.fetchall()
    for r in items:
        tx = IncomingTx(
            tx_hash=str(r[0]),
            from_address=str(r[1] or ""),
            to_address=str(r[2] or ""),
            amount=d8(r[3] or 0),
            memo=str(r[4] or ""),
            utime=int(r[5] or 0),
        )
        st = await process_incoming_tx(db, tx)
        stats[st] = stats.get(st, 0) + 1
    return stats


# =====================================================================
# Утилиты для админских задач: сверка по времени и по tx_hash
# =====================================================================

async def reconcile_last_hours(
    db: AsyncSession,
    *,
    hours: int = 24,
    limit: int = 500,
) -> dict[str, int]:
    """
    Защитный «догон» всех входящих за последние N часов
    напрямую из TON API.

    Вход:
      • hours — диапазон по времени.
      • limit — размер порции.

    Выход:
      • Счётчики по статусам.

    ИИ - защита:
      • process_incoming_tx идемпотентен, повтор безопасен.
    """
    since = int((_now_utc() - timedelta(hours=hours)).timestamp())
    total: dict[str, int] = {}
    page_since = since

    # Мягкое ограничение в 1000 страниц, чтобы не зациклиться
    for _ in range(0, 1000):
        stats = await process_incoming_payments(
            db,
            limit=limit,
            since_utime=page_since,
        )
        if not stats:
            break
        for k, v in stats.items():
            total[k] = total.get(k, 0) + v
        await asyncio.sleep(0.1)

    return total


async def reprocess_single_tx(db: AsyncSession, tx_hash: str) -> str:
    """
    Повторная обработка конкретной транзакции по её tx_hash (из лога).

    Используется для админских сценариев или отладки.
    """
    row = await db.execute(
        text("""
            SELECT tx_hash,
                   from_address,
                   to_address,
                   amount,
                   memo,
                   EXTRACT(
                     EPOCH FROM COALESCE(utime, NOW())
                   )::bigint AS utime
              FROM efhc_core.ton_inbox_logs
             WHERE tx_hash = :h
             LIMIT 1
            """  # nosec B608
        ),
        {"h": tx_hash},
    )
    r = row.fetchone()
    if not r:
        return "not_found"

    tx = IncomingTx(
        tx_hash=str(r[0]),
        from_address=str(r[1] or ""),
        to_address=str(r[2] or ""),
        amount=d8(r[3] or 0),
        memo=str(r[4] or ""),
        utime=int(r[5] or 0),
    )
    return await process_incoming_tx(db, tx)


# =====================================================================
# Пояснения «для чайника»:
# • Этот модуль не «создаёт деньги» сам — все начисления EFHC
#   проходят через transactions_service.credit_user_from_bank(...).
# • Благодаря UNIQUE(tx_hash) и read-through та же транзакция TON
#   не будет
# начислена дважды: при повторе вернётся финальный статус.
# • NFT не выдаётся автоматически: здесь создаётся только заявка
#   со статусом
# PAID_PENDING_MANUAL, которую обработает администратор.
# • Если для простого депозита EFHC<tg_id> нельзя однозначно
#   определить объём
# по прайсу EFHC-пакетов, запись получает статус parsed_pending_mapping
# и
# ждёт ручного сопоставления.
# • Любые временные/сетевые сбои помечаются error_* с next_retry_at.
#   Планировщик периодически вызывает reprocess_unfinished_logs()
#   для догона.
# =====================================================================
