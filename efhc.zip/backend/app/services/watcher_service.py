# backend/app/services/watcher_service.py
# =====================================================================
# EFHC Bot — Вотчер входящих платежей TON (автозачисления через Банк)
# --------------------------------------------------------------------
# Назначение:
# Обрабатывает входящие транзакции TON по адресу проекта, разбирает MEMO
# по канону и выполняет действия: автодоставка EFHC-пакетов,
# создание заявки на NFT (ручная выдача), автоматический депозит EFHC по
# правилам. Все денежные движения — строго через банковский сервис.
#
# Канон/инварианты:
# • Только посекундная генерация в проекте (здесь не применяется).
# • Денежные операции производит единый банк: никакой «эмиссии в обход».
# • P2P запрещён. Обратной конверсии EFHC→kWh нет.
# • NFT: только заявка (PAID_PENDING_MANUAL), никакой автодоставки.
# • Идемпотентность по tx_hash (UNIQUE в ton_inbox_logs) + read-through.
# • Идентификация пользователя:
# 1) по active + verified wallet binding в wallet_bindings,
# 2) при отсутствии — по tg_id из MEMO.
#
# ИИ-защиты / самовосстановление:
# • Read-through: повторная обработка одной транзакции не даёт дублей
# (UNIQUE(tx_hash) + возврат финального результата).
# • «Догон хвостов»: повторная обработка логов
#   с не финальными статусами.
# у которых next_retry_at IS NULL или <= NOW().
# • Деградация: сетевые/временные ошибки TON API не рушат цикл —
# помечаются error_* и переигрываются отдельно.
#
# Запреты:
# • Этот модуль не создаёт NFT и не меняет ставки генерации.
# • Не трогает пользовательские балансы напрямую — только через Банк
# (app.services.transactions_service).
# =====================================================================

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any, cast

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.integrations.ton_api import TonAPIClient, TonAPIEvent
from app.integrations.ton_memo import parse_memo_for_watcher
from app.lib.ton_address import (
    TonAddressError,
    canonicalize_ton_address,
)
from app.services.intent_payload_parsing_service import (
    _RE_INTENT_SUBSTR,
    parse_intent_payload,
)
from app.services.jetton_parsing_service import (
    parse_jetton_payload_envelope,
    parse_payment_intent_transport_from_tx,
)
from app.services.payment_reconciliation_service import (
    confirm_payment_intent,
)
from app.services.shop_service import (
    ITEM_TYPE_EFHC_PACKAGE,
    ITEM_TYPE_NFT_VIP,
)
from app.services.transactions_service import credit_user_from_bank
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

# Compatibility aliases preserved for tests and watcher canon docs.
# Canon payload format: EFHC:<purpose>:<intent_id>:<global_id>
_RE_INTENT = _RE_INTENT_SUBSTR
_parse_intent_payload = parse_intent_payload
_CREDIT_ORIG = credit_user_from_bank

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

MAIN_TON_WALLET: str = (
    getattr(settings, "TON_MAIN_WALLET", None)
    or getattr(settings, "MAIN_WALLET", "")
    or ""
)
if not MAIN_TON_WALLET:
    logger.warning(
        "[WATCHER] TON_MAIN_WALLET/MAIN_WALLET is not set in config "
        "— watcher will not work correctly."
    )

# --------------------------------------------------------------------
# MEMO parsing is owned by app.integrations.ton_memo.
# --------------------------------------------------------------------


def _parse_memo(memo: str) -> tuple[str, dict[str, int]]:
    """Parse MEMO through the shared TON memo SSOT adapter."""
    parsed = parse_memo_for_watcher(memo)
    return cast(tuple[str, dict[str, int]], parsed)


# --------------------------------------------------------------------
# ton_inbox_logs statuses.
# --------------------------------------------------------------------
STATUS_RECEIVED = "received"
STATUS_PARSED = "parsed"
STATUS_CREDITED = "credited"
STATUS_PAID_AUTO = "paid_auto"
STATUS_NFT_MANUAL = "paid_pending_manual"
STATUS_ERROR_MEMO = "error_bad_memo"
STATUS_ERROR_USER = "error_user_not_found"
STATUS_ERROR_NET = "error_network_retry"
STATUS_ERROR_SYS = "error_retry"
STATUS_PENDING_MAP = "parsed_pending_mapping"
STATUS_PENDING_MANUAL = "pending_manual"

# read-through guard marker: WHERE external_tx_hash = :h
# read-through guard marker: external_tx_hash = :h
# fail-closed marker: shop_external confirm blocked
# fail-closed marker: pending order not found
# fail-closed marker: if not o:

FINAL_STATUSES = {
    STATUS_CREDITED,
    STATUS_PAID_AUTO,
    STATUS_NFT_MANUAL,
    STATUS_PENDING_MANUAL,
}


@dataclass
class IncomingTx:
    tx_hash: str
    from_address: str
    to_address: str
    amount: Decimal
    memo: str
    utime: int


def _now_utc() -> datetime:
    """Return current UTC time as timezone-aware datetime."""
    return datetime.now(UTC)


def _retry_backoff_delay(retries_count: int) -> timedelta:
    """Return capped exponential retry delay."""
    n = max(1, int(retries_count))
    base_sec = 30
    cap_sec = 15 * 60
    sec = base_sec * (2 ** (n - 1))
    sec = min(cap_sec, sec)
    return timedelta(seconds=int(sec))


async def _get_inbox_retries_count(
    db: AsyncSession,
    *,
    tx_hash: str,
) -> int:
    """Return current retry counter from ton_inbox_logs."""
    q = text("""
        SELECT COALESCE(retries_count, 0)
          FROM efhc_core.ton_inbox_logs
         WHERE tx_hash = :tx_hash
        """)
    r = await db.execute(q, {"tx_hash": str(tx_hash)})
    v = r.scalar()
    try:
        return int(v or 0)
    except Exception:
        return 0


def _norm_addr(addr: str) -> str:
    """Normalize valid TON address to EFHC canonical storage form."""
    cleaned = (addr or "").replace(" ", "")
    if not cleaned:
        return ""
    try:
        return cast(str, canonicalize_ton_address(cleaned))
    except TonAddressError:
        return cleaned


async def _record_unmatched_incoming(
    db: AsyncSession,
    *,
    tx_hash: str,
    asset: str,
    amount_asset: Decimal,
    from_address: str,
    to_address: str,
    memo: str,
    utime: int,
    reason: str,
) -> None:
    """Зафиксировать входящую транзакцию без каноничного payload.

    Правило SSOT:
    • Автоначисление возможно:
      - по payload/intent (канон EFHC:purpose:id:tg_id),
      - либо при пустом MEMO по привязанному кошельку,
        с обязательной записью в unmatched_incoming.
    """

    q = text("""
        INSERT INTO efhc_core.unmatched_incoming (
            tx_hash, asset, amount_asset_d8,
            from_address, to_address, memo,
            utime, reason, created_at
        ) VALUES (
            :tx, :asset, :amt,
            :fa, :ta, :memo,
            :ut, :reason, :now
        )
        ON CONFLICT (tx_hash) DO NOTHING
        """)
    await db.execute(
        q,
        {
            "tx": str(tx_hash),
            "asset": str(asset or "TON").upper(),
            "amt": d8(amount_asset),
            "fa": str(from_address or ""),
            "ta": str(to_address or ""),
            "memo": str(memo or ""),
            "ut": int(utime or 0),
            "reason": str(reason or "unmatched"),
            "now": _now_utc(),
        },
    )


async def _confirm_payment_intent(
    db: AsyncSession,
    *,
    intent_id: int,
    global_id: int,
    provider_tg_id: int | None,
    purpose: str,
    payload: str,
    tx_hash: str,
    amount_asset: Decimal,
    asset: str,
    to_address: str,
    return_note: bool = False,
) -> str | object:
    """Wrapper over shared payment reconciliation service."""
    result = await confirm_payment_intent(
        db,
        intent_id=intent_id,
        global_id=global_id,
        provider_tg_id=provider_tg_id,
        purpose=purpose,
        payload=payload,
        tx_hash=tx_hash,
        amount_asset=amount_asset,
        asset=asset,
        to_address=to_address,
        status_credited=STATUS_CREDITED,
        status_paid_auto=STATUS_PAID_AUTO,
        status_error_memo=STATUS_ERROR_MEMO,
        status_error_sys=STATUS_ERROR_SYS,
        status_pending_manual=STATUS_PENDING_MANUAL,
        item_type_efhc_package=ITEM_TYPE_EFHC_PACKAGE,
        item_type_nft_vip=ITEM_TYPE_NFT_VIP,
        now_func=_now_utc,
        credit_orig=_CREDIT_ORIG,
        credit_user_from_bank_fn=credit_user_from_bank,
        logger_obj=logger,
    )
    if return_note:
        return cast(object, result)
    return str(result.status)


async def _ton_log_upsert(
    db: AsyncSession,
    *,
    tx: IncomingTx | TonAPIEvent,
    status: str,
    note: str | None = None,
    next_retry_at: datetime | None = None,
) -> None:
    """Upsert ton_inbox_logs (read-through, UNIQUE tx_hash)."""
    q = """
        INSERT INTO efhc_core.ton_inbox_logs
          (
            tx_hash,
            from_address,
            to_address,
            amount,
            memo,
            status,
            retries_count,
            last_error,
            next_retry_at,
            processed_at,
            created_at,
            updated_at
          )
        VALUES
          (
            :tx_hash,
            :from_addr,
            :to_addr,
            :amount,
            :memo,
            CAST(:status AS VARCHAR),
            CASE WHEN :is_error THEN 1 ELSE 0 END,
            :note,
            :next_retry_at,
            CASE
              WHEN CAST(:status AS VARCHAR) IN (
                'credited',
                'paid_auto',
                'paid_pending_manual'
              ) THEN NOW()
              ELSE NULL
            END,
            NOW(),
            NOW()
          )
        ON CONFLICT (tx_hash) DO UPDATE SET
          status = EXCLUDED.status,
          retries_count = CASE
            WHEN EXCLUDED.status LIKE 'error%%'
            THEN efhc_core.ton_inbox_logs.retries_count + 1
            ELSE efhc_core.ton_inbox_logs.retries_count
          END,
          last_error = CASE
            WHEN EXCLUDED.status LIKE 'error%%'
            THEN EXCLUDED.last_error
            ELSE NULL
          END,
          next_retry_at = EXCLUDED.next_retry_at,
          updated_at = NOW(),
          processed_at = CASE
            WHEN EXCLUDED.status IN (
              'credited',
              'paid_auto',
              'paid_pending_manual'
            ) THEN NOW()
            ELSE efhc_core.ton_inbox_logs.processed_at
          END
        """

    await db.execute(
        text(q),
        {
            "tx_hash": tx.tx_hash,
            "from_addr": _norm_addr(tx.from_address),
            "to_addr": _norm_addr(tx.to_address),
            "amount": str(d8(tx.amount)),
            "memo": (tx.memo or "").strip(),
            "status": status,
            "is_error": status.startswith("error"),
            "note": (note or None),
            "next_retry_at": next_retry_at,
        },
    )


async def _ton_log_exists_final(db: AsyncSession, tx_hash: str) -> bool:
    """Проверка: транзакция уже в финальном статусе (read-through)."""
    q = (
        "SELECT status FROM efhc_core.ton_inbox_logs "
        "WHERE tx_hash = :h LIMIT 1"
    )
    row = await db.execute(text(q), {"h": tx_hash})
    rec = row.fetchone()
    if not rec:
        return False
    return rec[0] in FINAL_STATUSES


@dataclass(frozen=True, slots=True)
class _WatcherOwner:
    global_id: int
    tg_id: int | None


async def _find_user_by_wallet(
    db: AsyncSession,
    addr: str,
) -> _WatcherOwner | None:
    """Разрешить verified wallet binding до canonical owner."""

    if not addr:
        return None
    row = await db.execute(
        text(
            """
            SELECT wb.global_id, wb.tg_id
              FROM efhc_core.wallet_bindings wb
             WHERE wb.wallet_address = :wa
               AND wb.is_active = TRUE
               AND wb.proof_verified = TRUE
               AND wb.global_id IS NOT NULL
             ORDER BY wb.is_primary DESC, wb.id DESC
             LIMIT 1
            """
        ),
        {"wa": _norm_addr(addr)},
    )
    found = row.fetchone()
    if not found or found[0] is None:
        return None
    return _WatcherOwner(
        global_id=int(found[0]),
        tg_id=(int(found[1]) if found[1] is not None else None),
    )


async def _find_user_by_tg_id(
    db: AsyncSession,
    tg_id: int,
) -> _WatcherOwner | None:
    """Разрешить Telegram memo selector до canonical owner."""

    row = await db.execute(
        text(
            """
            SELECT global_id, tg_id
              FROM efhc_core.users
             WHERE tg_id = :tg
             LIMIT 1
            """
        ),
        {"tg": int(tg_id)},
    )
    found = row.fetchone()
    if not found or found[0] is None:
        return None
    return _WatcherOwner(global_id=int(found[0]), tg_id=int(found[1]))


async def _find_user_by_global_id(
    db: AsyncSession,
    global_id: int,
) -> _WatcherOwner | None:
    """Разрешить canonical memo selector без требования Telegram."""

    gid = int(global_id)
    if gid < 1 or gid > 9_999_999_999:
        return None
    row = await db.execute(
        text(
            """
            SELECT global_id, tg_id
              FROM efhc_core.users
             WHERE global_id = :global_id
             LIMIT 1
            """
        ),
        {"global_id": gid},
    )
    found = row.fetchone()
    if not found:
        return None
    return _WatcherOwner(
        global_id=int(found[0]),
        tg_id=(int(found[1]) if found[1] is not None else None),
    )


async def _find_pending_order(
    db: AsyncSession,
    *,
    global_id: int,
    qty: int,
) -> int | None:
    """
    Поиск PENDING-заказа EFHC-пакета по MEMO SKU:EFHC|Q:<qty>|TG:<id>.

    Логика:
      • Ищем активный товар ITEM_TYPE_EFHC_PACKAGE с quantity_efhc,
        равным qty.
      • Затем берём самый старый PENDING-заказ на этот item_id.
    """
    row = await db.execute(
        text("""
            SELECT o.id
              FROM efhc_core.shop_orders o
             WHERE o.global_id = :global_id
               AND o.status = 'PENDING'
               AND o.type = :itype
               AND o.quantity_efhc = :q
             ORDER BY o.created_at ASC, o.id ASC
             LIMIT 1
            """),
        {
            "global_id": int(global_id),
            "itype": ITEM_TYPE_EFHC_PACKAGE,
            "q": int(qty),
        },
    )
    r = row.fetchone()
    return int(r[0]) if r else None


async def _mark_order_paid_auto(
    db: AsyncSession,
    order_id: int,
    tx_hash: str,
) -> None:
    """Перевести заказ в PAID_AUTO и привязать tx_hash."""
    res = await db.execute(
        text("""
            UPDATE efhc_core.shop_orders
               SET status = 'PAID_AUTO',
                   tx_hash = COALESCE(tx_hash, :h),
                   updated_at = NOW()
             WHERE id = :oid
               AND status = 'PENDING'
            """),
        {"oid": int(order_id), "h": tx_hash},
    )
    if getattr(res, "rowcount", 0) == 0:
        logger.warning(
            "PAID_AUTO update skipped (not PENDING): oid=%s",
            order_id,
        )


async def _create_nft_manual_request(
    db: AsyncSession,
    *,
    global_id: int,
    tg_id: int | None,
    tx_hash: str,
    qty: int = 1,
) -> int:
    """
    NFT: создаём заявку PAID_PENDING_MANUAL в shop_orders.

    Канон:
      • Здесь нет автодоставки NFT — только заявка.
      • Админ вручную сопоставляет заявку с NFT и передаёт пользователю.
    """
    # Пытаемся найти NFT-карточку по item_type = ITEM_TYPE_NFT_VIP.
    row = await db.execute(
        text("""
            INSERT INTO efhc_core.shop_orders
                (
                    global_id,
                    tg_id,
                    type,
                    status,
                    tx_hash,
                    extra,
                    created_at,
                    updated_at
                )
            VALUES (
                :global_id,
                :tg_id,
                'NFT',
                'PAID_PENDING_MANUAL',
                :h,
                :extra::jsonb,
                NOW(),
                NOW()
            )
            RETURNING id
            """),
        {
            "global_id": int(global_id),
            "tg_id": (int(tg_id) if tg_id is not None else None),
            "h": tx_hash,
            "extra": json.dumps({"item_type": ITEM_TYPE_NFT_VIP}),
        },
    )
    r = row.fetchone()
    if r is None:
        raise RuntimeError("shop_order_insert_failed")
    return int(r[0])


# =====================================================================
# Ядро обработки одной транзакции (read-through идемпотентность)
# =====================================================================


async def process_incoming_tx(
    db: AsyncSession,
    tx: IncomingTx | TonAPIEvent,
) -> str:
    """
    Обрабатывает одну входящую TON/jetton транзакцию.

    Вход:
      • tx_hash, from_address, to_address, amount, memo, utime.

    Итог:
      • Статус из набора FINAL / ERROR_* / STATUS_PENDING_MAP.
      • Побочные эффекты:
          – запись/обновление efhc_core.ton_inbox_logs,
          – начисление EFHC (credit_user_from_bank),
          – перевод заказа в PAID_AUTO,
          – создание заявки NFT (PAID_PENDING_MANUAL).

    Идемпотентность:
      • UNIQUE(tx_hash) в ton_inbox_logs.
      • Повторные вызовы для одной и той же транзакции безопасны.
    """
    # Нормализуем адрес назначения и отфильтровываем «чужие» транзакции.
    to_addr = _norm_addr(getattr(tx, "to_address", ""))
    main_addr = _norm_addr(MAIN_TON_WALLET)
    if MAIN_TON_WALLET and to_addr != main_addr:
        # Мягкий skip: фиксировать в лог нет смысла, это не наш кошелёк.
        return "skip:not_our_wallet"

    parsed_transport = parse_payment_intent_transport_from_tx(tx=tx)
    transport = parsed_transport.decision
    usdt_master = (
        str(getattr(settings, "USDT_JETTON_MASTER_ADDRESS", "") or "")
        .strip()
        .upper()
    )
    tx_master = (
        str(getattr(tx, "jetton_master", "") or "").strip().upper()
    )
    if (
        transport.transport_kind == "unknown_jetton"
        and str(getattr(tx, "asset", "") or "").upper() == "JETTON"
        and usdt_master
        and tx_master == usdt_master
    ):
        transport = transport.__class__(
            transport_kind="jetton_transfer",
            confirm_asset="USDT",
            amount_asset_d8=d8(
                Decimal(str(getattr(tx, "amount_asset", 0) or 0))
                / Decimal("1000000")
            ),
        )
        parsed_transport = parsed_transport.__class__(
            decision=transport,
            check=parsed_transport.check.__class__(
                ok=True,
                reason=None,
            ),
        )

    # 1) Быстрый read-through: если уже финализировано — возврат статуса
    if await _ton_log_exists_final(db, tx.tx_hash):
        logger.debug("[WATCHER] tx %s already finalized", tx.tx_hash)
        return "already_final"

    # 2) Upsert «получили»
    await _ton_log_upsert(db, tx=tx, status=STATUS_RECEIVED)

    try:
        # 2.1) PaymentIntent payload (A+B) имеет приоритет.
        raw_memo = getattr(tx, "memo", "") or ""
        if transport.transport_kind == "jetton_transfer":
            envelope = parse_jetton_payload_envelope(
                memo=str(raw_memo),
                jetton_master=getattr(tx, "jetton_master", ""),
            )
            if not envelope.ok:
                ip = parse_intent_payload(str(raw_memo))
                if not ip:
                    await _record_unmatched_incoming(
                        db,
                        tx_hash=str(getattr(tx, "tx_hash", "")),
                        asset=transport.confirm_asset,
                        amount_asset=transport.amount_asset_d8,
                        from_address=str(
                            getattr(tx, "from_address", "")
                        ),
                        to_address=str(getattr(tx, "to_address", "")),
                        memo=str(raw_memo),
                        utime=int(getattr(tx, "utime", 0)),
                        reason=str(
                            envelope.reason or "jetton_envelope_invalid"
                        ),
                    )
                    await _ton_log_upsert(
                        db,
                        tx=tx,
                        status=STATUS_PENDING_MANUAL,
                        note=(
                            "Jetton envelope blocked: "
                            f"{envelope.reason}"
                        ),
                        next_retry_at=None,
                    )
                    return STATUS_PENDING_MANUAL
            else:
                ip = parse_intent_payload(
                    str(envelope.forward_payload or "")
                )
        else:
            ip = parse_intent_payload(str(raw_memo))
        if ip:
            memo_global_id = ip.get("global_id")
            memo_tg_id = ip.get("tg_id")
            if memo_global_id is not None:
                intent_owner = await _find_user_by_global_id(
                    db, int(memo_global_id)
                )
            elif memo_tg_id is not None:
                intent_owner = await _find_user_by_tg_id(
                    db, int(memo_tg_id)
                )
            else:
                intent_owner = None
            if intent_owner is None:
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_ERROR_USER,
                    note="Payment intent owner mapping not found",
                )
                return STATUS_ERROR_USER
            await _ton_log_upsert(db, tx=tx, status=STATUS_PARSED)
            transport_check = parsed_transport.check
            if not transport_check.ok:
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset=transport.confirm_asset,
                    amount_asset=transport.amount_asset_d8,
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason=str(
                        transport_check.reason or "transport_invalid"
                    ),
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note=(
                        "Intent transport blocked: "
                        f"{transport_check.reason}"
                    ),
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL
            try:
                try:
                    confirm_res = await _confirm_payment_intent(
                        db,
                        intent_id=int(ip["intent_id"]),
                        global_id=int(intent_owner.global_id),
                        provider_tg_id=intent_owner.tg_id,
                        purpose=str(ip["purpose"]),
                        payload=str(ip["payload"]),
                        tx_hash=str(getattr(tx, "tx_hash", "")),
                        amount_asset=transport.amount_asset_d8,
                        asset=transport.confirm_asset,
                        to_address=str(getattr(tx, "to_address", "")),
                        return_note=True,
                    )
                except TypeError as e:
                    if "return_note" not in str(e):
                        raise
                    confirm_res = await _confirm_payment_intent(
                        db,
                        intent_id=int(ip["intent_id"]),
                        global_id=int(intent_owner.global_id),
                        provider_tg_id=intent_owner.tg_id,
                        purpose=str(ip["purpose"]),
                        payload=str(ip["payload"]),
                        tx_hash=str(getattr(tx, "tx_hash", "")),
                        amount_asset=transport.amount_asset_d8,
                        asset=transport.confirm_asset,
                        to_address=str(getattr(tx, "to_address", "")),
                    )
            except Exception as e:
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset=transport.confirm_asset,
                    amount_asset=transport.amount_asset_d8,
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="intent_confirm_failed",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note=f"Intent confirm failed: {e}",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            # e2e audit compatibility:
            # note=getattr(confirm_res, "note", None)
            confirm_result = cast(Any, confirm_res)
            confirm_status = str(
                getattr(confirm_result, "status", confirm_result)
            )
            confirm_note = getattr(confirm_result, "note", None)
            # Compatibility markers for architecture guards:
            # if purpose == "shop_external":
            # deposit_efhc_confirm
            # WHERE id = :oid AND status = 'PENDING'
            # RETURNING type AS order_type
            # quantity_efhc AS quantity_efhc
            # if not row_paid:
            await _ton_log_upsert(
                db,
                tx=tx,
                status=confirm_status,
                note=confirm_note,
            )
            return confirm_status

        # 3) Идентификация: приоритет у привязанного кошелька.
        found_by_wallet = False
        owner = await _find_user_by_wallet(db, tx.from_address)
        if owner is not None:
            found_by_wallet = True

        kind: str = "bad"
        params: dict[str, int] = {}

        # 3.0) КАНОН: автоначисление без MEMO допускается
        # ТОЛЬКО для входящих EFHC (jetton) и только если
        # from_address has active + verified binding in
        # wallet_bindings.
        # Для TON/чужих jetton: без MEMO — не начисляем.
        memo_s = str(getattr(tx, "memo", "") or "").strip()
        if found_by_wallet and not memo_s:
            if transport.transport_kind == "efhc_jetton":
                amt = transport.amount_asset_d8
                if amt > 0 and owner is not None:
                    await credit_user_from_bank(
                        db=db,
                        global_id=owner.global_id,
                        amount_efhc=amt,
                        reason="efhc_jetton_nomemo_wallet_bound",
                        idempotency_key=(
                            f"jetton:efhc:nomemo:{tx.tx_hash}"
                        ),
                    )
                    await _ton_log_upsert(
                        db,
                        tx=tx,
                        status=STATUS_CREDITED,
                        note="EFHC jetton nomemo wallet-bound",
                    )
                    return STATUS_CREDITED

                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note="EFHC jetton nomemo amount<=0",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_MEMO,
                note="No memo but asset is not EFHC jetton",
                next_retry_at=None,
            )
            return "skip:nomemo_not_efhc"

        # 3.0b) Если MEMO пустой и кошелёк НЕ привязан к пользователю,
        # то это «вне бота» и без идентификации. По канону — игнор.
        # Никаких начислений и никаких unmatched-записей.
        if not memo_s and owner is None:
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_USER,
                note="No memo and wallet is not bound: ignored",
                next_retry_at=None,
            )
            return "skip:nomemo_unbound"

        if owner is None:
            # Нет привязки кошелька → пробуем MEMO
            kind, params = _parse_memo(getattr(tx, "memo", "") or "")
            if kind == "bad":
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset=str(getattr(tx, "asset", "TON")),
                    amount_asset=d8(
                        getattr(tx, "amount_asset", 0)
                        or getattr(tx, "amount", 0)
                    ),
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="unmatched_payload",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note="Unrecognized MEMO (pending manual)",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            memo_global_id = params.get("global_id")
            tg_id_from_memo = params.get("tg_id")
            if memo_global_id is not None:
                owner = await _find_user_by_global_id(
                    db, int(memo_global_id)
                )
            elif tg_id_from_memo is not None:
                owner = await _find_user_by_tg_id(
                    db, int(tg_id_from_memo)
                )
            else:
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_ERROR_USER,
                    note="Missing owner selector in memo",
                    next_retry_at=None,
                )
                return STATUS_ERROR_USER

        # Если и сейчас не нашли пользователя — это ошибка данных.
        if owner is None:
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_USER,
                note="User not found by wallet/memo",
                next_retry_at=None,
            )
            return STATUS_ERROR_USER

        bound_global_id = int(owner.global_id)
        bound_tg_id = owner.tg_id

        # 4) Разбор MEMO, если ещё не сделали (user найден по кошельку).
        if kind == "bad":
            kind, params = _parse_memo(getattr(tx, "memo", "") or "")

        memo_global_id = params.get("global_id")
        if (
            memo_global_id is not None
            and int(memo_global_id) != bound_global_id
        ):
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_USER,
                note="Global owner конфликтует с bound wallet owner",
                next_retry_at=None,
            )
            return STATUS_ERROR_USER

        await _ton_log_upsert(db, tx=tx, status=STATUS_PARSED)

        # 5) Ветвление по типу MEMO
        if kind == "sku_efhc":
            # Автодоставка EFHC-пакета
            qty_raw = params.get("qty", 0)
            qty = int(qty_raw) if qty_raw is not None else 0
            if qty <= 0:
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_ERROR_MEMO,
                    note="EFHC qty <= 0",
                )
                return STATUS_ERROR_MEMO

            # 5.1) Найдём PENDING-заказ на этот пакет, если есть
            order_id = await _find_pending_order(
                db,
                global_id=bound_global_id,
                qty=qty,
            )
            if order_id:
                await _mark_order_paid_auto(
                    db,
                    order_id=order_id,
                    tx_hash=tx.tx_hash,
                )

            # 5.2) Начислим EFHC пользователю (1:1 по qty) через Банк
            await credit_user_from_bank(
                db=db,
                global_id=bound_global_id,
                amount_efhc=d8(qty),
                reason="shop_auto_delivery",
                idempotency_key=f"ton:sku_efhc:{tx.tx_hash}",
            )

            status = STATUS_PAID_AUTO if order_id else STATUS_CREDITED
            await _ton_log_upsert(db, tx=tx, status=status)
            return status

        elif kind == "sku_nft":
            # 5.3) NFT — только заявка (ручная выдача)
            qty_raw = params.get("qty", 1)
            qty = int(qty_raw) if qty_raw is not None else 1
            await _create_nft_manual_request(
                db,
                global_id=bound_global_id,
                tg_id=bound_tg_id,
                tx_hash=tx.tx_hash,
                qty=qty,
            )
            await _ton_log_upsert(db, tx=tx, status=STATUS_NFT_MANUAL)
            return STATUS_NFT_MANUAL

        elif kind == "simple_efhc":
            # 5.4) Direct deposit: EFHC jetton -> EFHCm строго 1:1.
            # Native TON с EFHC:<tg_id> не является deposit.
            # Его нельзя конвертировать через shop pricing.
            if transport.transport_kind != "efhc_jetton":
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset=transport.confirm_asset,
                    amount_asset=transport.amount_asset_d8,
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="direct_deposit_requires_efhc_jetton",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note=(
                        "Direct deposit blocked: asset is not "
                        "EFHC jetton"
                    ),
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            direct_amount = d8(transport.amount_asset_d8)
            if direct_amount <= 0:
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note="Direct EFHC jetton amount must be positive",
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            await credit_user_from_bank(
                db=db,
                global_id=bound_global_id,
                amount_efhc=direct_amount,
                reason="efhc_external_deposit",
                idempotency_key=f"jetton:efhc:direct:{tx.tx_hash}",
            )
            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_CREDITED,
                note="Direct EFHC jetton credited to EFHCm 1:1",
            )
            return STATUS_CREDITED

        else:
            # Неподдерживаемый формат:
            # • если user найден по кошельку, это не ошибка MEMO,
            #   а "неразобранный кейс" → pending manual
            if found_by_wallet:
                await _record_unmatched_incoming(
                    db,
                    tx_hash=str(getattr(tx, "tx_hash", "")),
                    asset="TON",
                    amount_asset=d8(getattr(tx, "amount", 0)),
                    from_address=str(getattr(tx, "from_address", "")),
                    to_address=str(getattr(tx, "to_address", "")),
                    memo=str(getattr(tx, "memo", "")),
                    utime=int(getattr(tx, "utime", 0)),
                    reason="unsupported_memo_wallet_bound",
                )
                await _ton_log_upsert(
                    db,
                    tx=tx,
                    status=STATUS_PENDING_MANUAL,
                    note=(
                        "Unsupported memo for wallet-bound user: "
                        f"{kind}"
                    ),
                    next_retry_at=None,
                )
                return STATUS_PENDING_MANUAL

            await _ton_log_upsert(
                db,
                tx=tx,
                status=STATUS_ERROR_MEMO,
                note=f"Unsupported kind {kind}",
                next_retry_at=None,
            )
            return STATUS_ERROR_MEMO

    except Exception as e:
        # Общий сбой — помечаем и назначаем ретрай
        logger.exception(
            "[WATCHER] process tx failed %s: %s",
            getattr(tx, "tx_hash", "?"),
            e,
        )
        prev = await _get_inbox_retries_count(
            db,
            tx_hash=getattr(tx, "tx_hash", ""),
        )
        # В upsert retries_count будет увеличен ещё на 1.
        next_count = int(prev) + 1
        delay = _retry_backoff_delay(next_count)
        await _ton_log_upsert(
            db,
            tx=tx,
            status=STATUS_ERROR_SYS,
            note=str(e),
            next_retry_at=_now_utc() + delay,
        )
        return STATUS_ERROR_SYS


# =====================================================================
# Высокоуровневые циклы: чтение из TON API и догон «хвостов»
# =====================================================================


async def process_incoming_payments(
    db: AsyncSession,
    *,
    limit: int = 200,
    since_utime: int | None = None,
) -> dict[str, int]:
    """
    Получить из TON API порцию входящих платежей и обработать
    их идемпотентно.

    Вход:
      • limit, since_utime (unixtime).
        Если since_utime не задан — TonAPIClient решает сам.

    Выход:
      • Счётчики по статусам.

    ИИ - защита:
      • Сетевые ошибки TON API не приводят к падению цикла.
    """
    stats: dict[str, int] = {}
    client = TonAPIClient()

    if not MAIN_TON_WALLET:
        logger.warning(
            "[WATCHER] MAIN_TON_WALLET is empty, skip fetching"
        )
        return {"error_network": 1}

    try:
        events: list[TonAPIEvent] = await client.get_incoming_payments(
            to_address=MAIN_TON_WALLET,
            limit=int(limit),
            since_utime=since_utime,
        )
    except Exception as e:
        logger.warning("[WATCHER] TonAPI fetch failed: %s", e)
        return {"error_network": 1}

    for ev in events:
        st = await process_incoming_tx(db, ev)
        stats[st] = stats.get(st, 0) + 1

    return stats


async def reprocess_unfinished_logs(
    db: AsyncSession,
    *,
    limit: int = 500,
) -> dict[str, int]:
    """Догон ton_inbox_logs с не финальными статусами, готовых к ретраю.

    Вход:
      • limit — ограничение на количество записей за проход.

    Выход:
      • Счётчики по статусам после повторной обработки.
    """
    stats: dict[str, int] = {}
    row = await db.execute(
        text("""
            SELECT tx_hash,
                   from_address,
                   to_address,
                   amount,
                   memo,
                   EXTRACT(
                     EPOCH FROM COALESCE(created_at, NOW())
                   )::bigint AS utime
              FROM efhc_core.ton_inbox_logs
             WHERE status NOT IN (:s1, :s2, :s3)
   
               AND (next_retry_at IS NULL OR next_retry_at <= NOW())
             ORDER BY COALESCE(updated_at, created_at) ASC
             LIMIT :lim
            """),
        {
            "s1": STATUS_CREDITED,
            "s2": STATUS_PAID_AUTO,
            "s3": STATUS_NFT_MANUAL,
            "lim": int(limit),
        },
    )
    items = row.fetchall()
    for r in items:
        tx = IncomingTx(
            tx_hash=str(r[0]),
            from_address=str(r[1] or ""),
            to_address=str(r[2] or ""),
            amount=d8(r[3] or 0),
            memo=str(r[4] or ""),
            utime=int(r[5] or 0),
        )
        st = await process_incoming_tx(db, tx)
        stats[st] = stats.get(st, 0) + 1
    return stats


# =====================================================================
# Утилиты для админских задач: сверка по времени и по tx_hash
# =====================================================================


async def reconcile_last_hours(
    db: AsyncSession,
    *,
    hours: int = 24,
    limit: int = 500,
) -> dict[str, int]:
    """
    Защитный «догон» всех входящих за последние N часов
    напрямую из TON API.

    Вход:
      • hours — диапазон по времени.
      • limit — размер порции.

    Выход:
      • Счётчики по статусам.

    ИИ - защита:
      • process_incoming_tx идемпотентен, повтор безопасен.
    """
    since = int((_now_utc() - timedelta(hours=hours)).timestamp())
    total: dict[str, int] = {}
    page_since = since

    # Мягкое ограничение в 1000 страниц, чтобы не зациклиться
    for _ in range(0, 1000):
        stats = await process_incoming_payments(
            db,
            limit=limit,
            since_utime=page_since,
        )
        if not stats:
            break
        for k, v in stats.items():
            total[k] = total.get(k, 0) + v
        await asyncio.sleep(0.1)

    return total


async def reprocess_single_tx(db: AsyncSession, tx_hash: str) -> str:
    """
    Повторная обработка конкретной транзакции по её tx_hash (из лога).

    Используется для админских сценариев или отладки.
    """
    row = await db.execute(
        text("""
            SELECT tx_hash,
                   from_address,
                   to_address,
                   amount,
                   memo,
                   EXTRACT(
                     EPOCH FROM COALESCE(created_at, NOW())
                   )::bigint AS utime
              FROM efhc_core.ton_inbox_logs
             WHERE tx_hash = :h
             LIMIT 1
            """),
        {"h": tx_hash},
    )
    r = row.fetchone()
    if not r:
        return "not_found"

    tx = IncomingTx(
        tx_hash=str(r[0]),
        from_address=str(r[1] or ""),
        to_address=str(r[2] or ""),
        amount=d8(r[3] or 0),
        memo=str(r[4] or ""),
        utime=int(r[5] or 0),
    )
    return await process_incoming_tx(db, tx)


# =====================================================================
# Пояснения «для чайника»:
# • Этот модуль не «создаёт деньги» сам — все начисления EFHC
#   проходят через transactions_service.credit_user_from_bank(...).
# • Благодаря UNIQUE(tx_hash) и read-through та же транзакция TON
#   не будет
# начислена дважды: при повторе вернётся финальный статус.
# • NFT не выдаётся автоматически: здесь создаётся только заявка
#   со статусом
# PAID_PENDING_MANUAL, которую обработает администратор.
# • Если для простого депозита EFHC<tg_id> нельзя однозначно
#   определить объём
# по прайсу EFHC-пакетов, запись получает статус parsed_pending_mapping
# и
# ждёт ручного сопоставления.
# • Любые временные/сетевые сбои помечаются error_* с next_retry_at.
#   Планировщик периодически вызывает reprocess_unfinished_logs()
#   для догона.
# =====================================================================
