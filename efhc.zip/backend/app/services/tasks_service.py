"""Сервис заданий EFHC Bot.

Что умеет:
- выдаёт список доступных заданий (cursor-based);
- завершает задания (join_channel, watch_ad и т.п.);
- отдаёт историю бонусов за задания (cursor-based).

Канон:
- начисления только через банковский сервис (bonus_balance);
- жёсткая идемпотентность по idempotency_key;
- пользователь не уходит в минус; P2P запрещён.

Надёжность:
- replay по одному idempotency_key безопасен;
- мягкие сбои не ломают поток: pending_check/cooldown.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.integrations.telegram_bot_api import TelegramAPI
from app.services.transactions_service import (
    credit_user_bonus_from_bank,
)
from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()

# ------------------------------------------------------------------
# Внутренние DTO для страниц
# ------------------------------------------------------------------

@dataclass
class TaskItem:
    task_code: str
    title: str
    description: str | None
    reward_bonus_efhc: Decimal
    is_repeatable: bool
    # available | done | cooldown | pending_check | disabled
    user_status: str
    icon: str | None = None
    meta: dict[str, Any] | None = None

@dataclass
class TasksPage:
    items: list[TaskItem]
    next_after: dict[str, Any] | None

@dataclass
class TaskRewardLogItem:
    id: int
    ts: datetime
    task_code: str
    amount_bonus_efhc: Decimal
    idempotency_key: str

@dataclass
class TaskRewardsLogPage:
    items: list[TaskRewardLogItem]
    next_after_id: int | None

# ------------------------------------------------------------------
# SQL — осознанно без ORM, ради прозрачности и контроля
# Таблицы (миграции должны это создать):
# • {schema}.tasks
# (task_code TEXT PK, title TEXT, description TEXT NULL,
# reward_bonus_efhc NUMERIC(30,8), is_repeatable BOOL, is_active BOOL,
# cooldown_sec INT NULL, type TEXT, icon TEXT NULL, meta JSONB NULL)
# • {schema}.user_tasks_status
# (tg_id BIGINT, task_code TEXT, status TEXT,
# last_completed_at TIMESTAMPTZ NULL,
# next_available_at TIMESTAMPTZ NULL, UNIQUE(tg_id, task_code))
# • {schema}.task_rewards_log
# (id BIGSERIAL PK, tg_id BIGINT, ts TIMESTAMPTZ, task_code TEXT,
# amount_bonus_efhc NUMERIC(30,8), idempotency_key TEXT UNIQUE)
# • {schema}.task_complete_lock
# (id BIGSERIAL PK, idempotency_key TEXT UNIQUE, tg_id BIGINT, task_code
# TEXT,
# created_at TIMESTAMPTZ, updated_at TIMESTAMPTZ,
# credited BOOL DEFAULT FALSE)
# ------------------------------------------------------------------

_SQL_LIST_TASKS = text(
            """
            SELECT
        task_code,
        title,
        description,
        reward_bonus_efhc,
        is_repeatable,
        is_active,
        COALESCE(cooldown_sec,0) AS cooldown_sec,
        type,
        icon,
        meta
      FROM efhc_core.tasks
     WHERE is_active = TRUE
       AND (:after_code IS NULL OR task_code > :after_code)
     ORDER BY task_code ASC
     LIMIT :lim
    """)

_SQL_USER_TASK_STATUS = text(
            """
            SELECT status, last_completed_at, next_available_at
      FROM efhc_core.user_tasks_status
     WHERE tg_id = :tg_id AND task_code = :code
     LIMIT 1
    """)

_SQL_UPSERT_USER_TASK_STATUS = text(
            """
            INSERT INTO efhc_core.user_tasks_status
      (tg_id, task_code, status, last_completed_at, next_available_at)
    VALUES
      (:tg_id, :code, :status, :lca, :naa)
    ON CONFLICT (tg_id, task_code) DO UPDATE
       SET status = EXCLUDED.status,
           last_completed_at = EXCLUDED.last_completed_at,
           next_available_at = EXCLUDED.next_available_at
    """)

_SQL_INSERT_REWARD_LOG = text(
            """
            INSERT INTO efhc_core.task_rewards_log
      (tg_id, ts, task_code, amount_bonus_efhc, idempotency_key)
    VALUES
      (:tg_id, NOW(), :code, :amt, :idk)
    ON CONFLICT (idempotency_key) DO NOTHING
    """)

_SQL_SELECT_REWARD_LOG_BY_IDK = text(
            """
            SELECT id, tg_id, ts, task_code,
                   amount_bonus_efhc, idempotency_key
      FROM efhc_core.task_rewards_log
     WHERE idempotency_key = :idk
     LIMIT 1
    """)

_SQL_LIST_REWARD_LOG = text(
            """
            SELECT id, ts, task_code, amount_bonus_efhc, idempotency_key
      FROM efhc_core.task_rewards_log
     WHERE tg_id = :tg_id
       AND (:after_id IS NULL OR id < :after_id)
     ORDER BY id DESC
     LIMIT :lim
    """)

_SQL_LOCK_UPSERT = text(
            """
            INSERT INTO efhc_core.task_complete_lock
      (
        idempotency_key,
        tg_id,
        task_code,
        created_at,
        updated_at,
        credited
      )
    VALUES
      (:idk, :tg_id, :code, NOW(), NOW(), FALSE)
    ON CONFLICT (idempotency_key) DO NOTHING
    """)

_SQL_LOCK_SELECT_FOR_UPDATE = text(
            """
            SELECT id, tg_id, task_code, credited
      FROM efhc_core.task_complete_lock
     WHERE idempotency_key = :idk
     FOR UPDATE
    """)

_SQL_LOCK_SET_CREDITED = text(
            """
            UPDATE efhc_core.task_complete_lock
       SET credited = TRUE, updated_at = NOW()
     WHERE idempotency_key = :idk
    """)

_SQL_GET_TASK = text(
            """
            SELECT
        task_code,
        title,
        description,
        reward_bonus_efhc,
        is_repeatable,
        is_active,
        COALESCE(cooldown_sec,0) AS cooldown_sec,
        type,
        icon,
        meta
      FROM efhc_core.tasks
     WHERE task_code = :code
     LIMIT 1
    """)

# ------------------------------------------------------------------
# Вспомогательные функции
# ------------------------------------------------------------------


def _now_utc() -> datetime:
    """Возвращает текущее UTC-время."""
    return datetime.now(tz=UTC)


def _as_task_item_row(row: Any, user_status: str) -> TaskItem:
    """Преобразует строку SQL-выборки в TaskItem."""
    return TaskItem(
        task_code=str(row[0]),
        title=str(row[1]),
        description=(row[2] if row[2] is not None else None),
        reward_bonus_efhc=d8(row[3] or 0),
        is_repeatable=bool(row[4]),
        user_status=user_status,
        icon=(row[8] if row[8] is not None else None),
        meta=(row[9] if row[9] is not None else None),
    )


def _calc_user_status(
    base_status: str | None,
    next_available_at: datetime | None,
) -> str:
    """Нормализует статус пользователя."""
    if base_status == "pending_check":
        return "pending_check"
    if next_available_at and next_available_at > _now_utc():
        return "cooldown"
    return base_status or "available"

# ------------------------------------------------------------------
# Публичное API сервиса — список заданий
# ------------------------------------------------------------------

async def list_available_tasks(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 50,
    after: dict[str, Any] | None = None,
) -> TasksPage:
    """
    Cursor-based список активных заданий для пользователя.
    Курсор: {"after_code": "<последний task_code>"}.
    """
    lim = max(1, min(200, int(limit)))
    after_code = None
    if after:
        after_code = after.get("after_code")

    rows = (
        await db.execute(
            _SQL_LIST_TASKS,
            {"after_code": after_code, "lim": lim},
        )
    ).fetchall()
    items: list[TaskItem] = []
    last_code: str | None = None

    for r in rows:
        code = str(r[0])
        st_row = (
            await db.execute(
                _SQL_USER_TASK_STATUS,
                {"tg_id": int(tg_id), "code": code},
            )
        ).fetchone()
        base_status = st_row[0] if st_row else None
        next_av = st_row[2] if st_row else None
        status_norm = _calc_user_status(base_status, next_av)
        items.append(_as_task_item_row(r, status_norm))
        last_code = code

    next_after = None
    if rows and len(rows) == lim:
        next_after = {"after_code": last_code}
    return TasksPage(items=items, next_after=next_after)

# ------------------------------------------------------------------
# Публичное API сервиса — завершение задания (join_channel/watch_ad)
# ------------------------------------------------------------------

async def complete_task(
    db: AsyncSession,
    *,
    tg_id: int,
    task_code: str,
    proof: dict[str, Any],
    idempotency_key: str,
) -> dict[str, Any]:
    """Идемпотентно завершает задание и при успехе начисляет бонус."""
    if not idempotency_key or not idempotency_key.strip():
        raise ValueError("idempotency_key is required")
    idk = idempotency_key.strip()

    # 0) Регистрируем ключ (если он уже есть — безопасный replay)
    try:
        await db.begin()
        await db.execute(
            _SQL_LOCK_UPSERT,
            {"idk": idk, "tg_id": int(tg_id), "code": task_code},
        )
        row = await db.execute(
            _SQL_LOCK_SELECT_FOR_UPDATE,
            {"idk": idk},
        )
        lock = row.fetchone()
        if not lock:
            await db.rollback()
            raise RuntimeError("failed to acquire tasks lock (race)")
        _, _, _, credited = lock
        if credited:
            await db.commit()
            prev = (
                await db.execute(
                    _SQL_SELECT_REWARD_LOG_BY_IDK,
                    {"idk": idk},
                )
            ).fetchone()
            if prev:
                return {
                    "ok": True,
                    "task_code": str(prev[3]),
                    "reward_bonus_efhc": d8(prev[4] or 0),
                    "user_bonus_balance": None,
                    "replayed": True,
                }
            return {
                "ok": True,
                "task_code": task_code,
                "reward_bonus_efhc": Decimal("0"),
                "user_bonus_balance": None,
                "replayed": True,
            }
        await db.commit()
    except Exception:
        try:
            await db.rollback()
        except Exception:
            logger.debug(
                "tasks_service: rollback failed on lock acquire",
                exc_info=True,
            )
        raise

    # 1) Загружаем задание
    task_row = (
        await db.execute(
            _SQL_GET_TASK,
            {"code": task_code},
        )
    ).fetchone()
    if not task_row:
        raise ValueError("task not found")
    if not bool(task_row[5]):  # is_active
        raise ValueError("task is disabled")

    # "join_channel" | "watch_ad" | ...
    t_type = str(task_row[7] or "").strip()
    reward = d8(task_row[3] or 0)
    cooldown_sec = int(task_row[6] or 0)
    meta = task_row[9] or {}

    # 2) Проверяем персональный статус (cooldown/one-time)
    st_row = (
        await db.execute(
            _SQL_USER_TASK_STATUS,
            {"tg_id": int(tg_id), "code": task_code},
        )
    ).fetchone()
    last_completed_at = st_row[1] if st_row else None
    next_available_at = st_row[2] if st_row else None
    if next_available_at and next_available_at > _now_utc():
        raise ValueError("task is in cooldown")
    # is_repeatable == False, уже делал
    if st_row and (not bool(task_row[4])):
        raise ValueError("task is one - time and already completed")

    # 3) Доменная проверка
    if t_type == "join_channel":
        # Ожидаем список каналов в meta["channels"].
        # Резервно — настройки.
        if (
            isinstance(meta, dict)
            and "channels" in meta
            and isinstance(meta["channels"], list)
        ):
            required = [
                str(x).strip()
                for x in meta["channels"]
                if str(x).strip()
            ]
        else:
            env_raw = getattr(settings, "REQUIRED_CHANNELS", "") or ""
            required = [
                x.strip()
                for x in env_raw.split(",")
                if x.strip()
            ]

        if not required:
            raise ValueError("task misconfigured: no channels")

        tg = TelegramAPI()
        try:
            checks = await tg.batch_is_user_subscribed(
                tg_id=int(tg_id),
                chats=required,
            )
        except Exception as err:
            logger.warning(
                "tasks_service: TelegramAPI failure user=%s task=%s",
                tg_id,
                task_code,
                exc_info=True,
            )
            raise ValueError("telegram_api_unavailable") from err

        not_sub = [c.chat for c in checks if not c.subscribed]
        if not_sub:
            msg = "user is not subscribed to: " + ", ".join(not_sub)
            raise ValueError(msg)

        # Успех → идём к начислению
        result = await _credit_bonus_and_finalize(
            db,
            tg_id=int(tg_id),
            task_code=task_code,
            reward=reward,
            idempotency_key=idk,
            cooldown_sec=cooldown_sec,
        )
        return result

    elif t_type == "watch_ad":
        # pending_check: начисление после колбэка провайдера.
        await db.execute(
            _SQL_UPSERT_USER_TASK_STATUS,
            {
                "tg_id": int(tg_id),
                "code": task_code,
                "status": "pending_check",
                "lca": last_completed_at,
                # cooldown начнётся после фактического начисления
                "naa": None,
            },
        )
        await db.commit()
        return {
            "ok": True,
            "task_code": task_code,
            "reward_bonus_efhc": Decimal("0"),
            "user_bonus_balance": None,
            "replayed": False,
        }

    else:
        raise ValueError("unsupported task type")

# ------------------------------------------------------------------
# Публичное API — завершение рекламной сессии по колбэку провайдера
# ------------------------------------------------------------------

async def confirm_ad_view_and_credit(
    db: AsyncSession,
    *,
    tg_id: int,
    task_code: str,
    provider: str,
    provider_ref: str,
    reward_bonus_efhc: Decimal,
    idempotency_key: str,
) -> dict[str, Any]:
    """Идемпотентно начисляет бонус за просмотр рекламы (по колбэку)."""
    if not idempotency_key or not idempotency_key.strip():
        raise ValueError("idempotency_key is required")
    idk = idempotency_key.strip()

    # 0) Регистрируем ключ — если уже был кредит, вернём replay
    try:
        await db.begin()
        await db.execute(
            _SQL_LOCK_UPSERT,
            {"idk": idk, "tg_id": int(tg_id), "code": task_code},
        )
        row = await db.execute(
            _SQL_LOCK_SELECT_FOR_UPDATE,
            {"idk": idk},
        )
        lock = row.fetchone()
        if not lock:
            await db.rollback()
            raise RuntimeError("failed to acquire tasks lock (race)")
        _, _, _, credited = lock
        if credited:
            await db.commit()
            prev = (
                await db.execute(
                    _SQL_SELECT_REWARD_LOG_BY_IDK,
                    {"idk": idk},
                )
            ).fetchone()
            if prev:
                return {
                    "ok": True,
                    "task_code": str(prev[3]),
                    "reward_bonus_efhc": d8(prev[4] or 0),
                    "user_bonus_balance": None,
                    "replayed": True,
                }
            return {
                "ok": True,
                "task_code": task_code,
                "reward_bonus_efhc": Decimal("0"),
                "user_bonus_balance": None,
                "replayed": True,
            }
        await db.commit()
    except Exception:
        try:
            await db.rollback()
        except Exception:
            logger.debug(
                "tasks_service: rollback failed on confirm_ad_view",
                exc_info=True,
            )
        raise

    # 1) Проверяем задание: watch_ad и cooldown.
    task_row = (
        await db.execute(
            _SQL_GET_TASK,
            {"code": task_code},
        )
    ).fetchone()
    if not task_row:
        raise ValueError("task not found")
    if not bool(task_row[5]):
        raise ValueError("task is disabled")

    t_type = str(task_row[7] or "").strip()
    if t_type != "watch_ad":
        raise ValueError("task type mismatch for ad confirmation")

    cooldown_sec = int(task_row[6] or 0)

    # 2) Определяем награду: доверяем провайдеру, но жёстко квантуем d8
    reward = d8(reward_bonus_efhc or 0)

    logger.info(
        "tasks_service: confirm_ad_view user=%s task=%s",
        tg_id,
        task_code,
    )

    # 3) Начисляем и финализируем (cooldown берём из tasks.cooldown_sec)
    result = await _credit_bonus_and_finalize(
        db,
        tg_id=int(tg_id),
        task_code=task_code,
        reward=reward,
        idempotency_key=idk,
        cooldown_sec=cooldown_sec,
    )
    return result

# ------------------------------------------------------------------
# Публичное API сервиса — история наград
# ------------------------------------------------------------------

async def list_task_rewards_log(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 50,
    after_id: int | None = None,
) -> TaskRewardsLogPage:
    """Возвращает историю наград (cursor-based по after_id)."""
    lim = max(1, min(200, int(limit)))
    rows = (
        await db.execute(
            _SQL_LIST_REWARD_LOG,
            {"tg_id": int(tg_id), "after_id": after_id, "lim": lim},
        )
    ).fetchall()
    items: list[TaskRewardLogItem] = []
    last_id = None
    for r in rows:
        rid, ts, code, amt, idk = r
        items.append(
            TaskRewardLogItem(
                id=int(rid),
                ts=ts,
                task_code=str(code),
                amount_bonus_efhc=d8(amt or 0),
                idempotency_key=str(idk),
            )
        )
        last_id = int(rid)
    next_after_id = None if len(rows) < lim else last_id
    return TaskRewardsLogPage(items=items, next_after_id=next_after_id)

# ------------------------------------------------------------------
# Внутреннее: единый путь начисления бонуса и финализации статусов
# ------------------------------------------------------------------

async def _credit_bonus_and_finalize(
    db: AsyncSession,
    *,
    tg_id: int,
    task_code: str,
    reward: Decimal,
    idempotency_key: str,
    cooldown_sec: int,
) -> dict[str, Any]:
    """Единый путь: кредит, лог, статус, отметка credited."""
    reward_q = d8(reward or 0)

    # 1) Кредитуем бонусы из Банка (в bonus_balance)
    await credit_user_bonus_from_bank(
        db=db,
        tg_id=int(tg_id),
        amount=reward_q,
        reason=f"task_reward:{task_code}",
        idempotency_key=idempotency_key,
        meta={"task_code": task_code},
    )

    # 2) Лог награды
    await db.execute(
        _SQL_INSERT_REWARD_LOG,
        {
            "tg_id": int(tg_id),
            "code": task_code,
            "amt": str(reward_q),
            "idk": idempotency_key,
        },
    )

    # 3) Обновляем персональный статус по заданию
    next_av = None
    if cooldown_sec and cooldown_sec > 0:
        next_av = _now_utc() + timedelta(seconds = int(cooldown_sec))
        status = "cooldown"
    else:
        status = "done"

    now = _now_utc()
    await db.execute(_SQL_UPSERT_USER_TASK_STATUS,
        {
            "tg_id": int(tg_id),
            "code": task_code,
            "status": status,
            "lca": now,
            "naa": next_av,
        },)

    # 4) Помечаем lock как credited
    await db.execute(_SQL_LOCK_SET_CREDITED, {"idk": idempotency_key})
    await db.commit()

    return {
        "ok": True,
        "task_code": task_code,
        "reward_bonus_efhc": reward_q,
        # баланс не считываем (экономия); фронт может спросить профиль
        "user_bonus_balance": None,
        "replayed": False,
    }


# ----------------------------------------------------------------------
# Admin API (используется backend/app/routes/admin_tasks_routes.py)
# Канон:
# - tg_id единственный идентификатор пользователя.
# - Денежные начисления только через transactions_service (банк).
# - Для операций записи: обязательный commit().
# ----------------------------------------------------------------------

from app.models.tasks_models import Task, TaskSubmission  # noqa: E402
from sqlalchemy import select  # noqa: E402


async def admin_create_task(
    db: AsyncSession,
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Создать Task (ORM)."""
    obj = Task(
        code=str(
            payload.get("code")
            or payload.get("task_code")
            or ""
        ).strip() or "custom",
        title=str(payload.get("title") or "").strip(),
        description=payload.get("description"),
        type=str(
            payload.get("kind")
            or payload.get("type")
            or "custom"
        ),
        active=bool(payload.get("is_active", True)),
        reward_bonus_efhc=d8(
            payload.get("reward_efhc")
            or payload.get("reward_bonus_efhc")
            or settings.TASK_REWARD_BONUS_EFHC_DEFAULT
        ),
        meta=payload.get("meta"),
    )
    db.add(obj)
    await db.commit()
    await db.refresh(obj)
    return {
        "id": int(obj.id),
        "title": obj.title,
        "description": obj.description,
        "is_active": bool(obj.active),
        "reward_efhc": str(d8(obj.reward_bonus_efhc)),
        "kind": str(obj.type),
        "meta": obj.meta,
        "created_at": obj.created_at,
        "updated_at": obj.updated_at,
    }

async def admin_get_task(
    db: AsyncSession,
    task_id: int,
) -> dict[str, Any] | None:
    stmt = (
        select(Task)
        .where(Task.id == int(task_id))
        .limit(1)
    )
    row = (await db.execute(stmt)).scalar_one_or_none()
    if not row:
        return None
    return {
        "id": int(row.id),
        "title": row.title,
        "description": row.description,
        "is_active": bool(row.active),
        "reward_efhc": str(d8(row.reward_bonus_efhc)),
        "kind": str(row.type),
        "meta": row.meta,
        "created_at": row.created_at,
        "updated_at": row.updated_at,
    }

async def admin_list_tasks(
    db: AsyncSession,
    *,
    limit: int = 50,
    after: dict[str, Any] | None = None,
    q: str | None = None,
    active: bool | None = None,
) -> dict[str, Any]:
    lim = max(1, min(200, int(limit)))
    after_id = None
    if after and after.get("after_id") is not None:
        try:
            raw_after = after.get("after_id")
            after_id = (
                None if raw_after is None else int(raw_after)
            )
        except Exception:
            after_id = None

    stmt = select(Task).order_by(Task.id.desc()).limit(lim)
    if after_id is not None:
        stmt = stmt.where(Task.id < after_id)
    if q:
        qq = f"%{q.strip()}%"
        stmt = stmt.where(Task.title.ilike(qq))
    if active is not None:
        stmt = stmt.where(Task.active.is_(bool(active)))

    rows = (await db.execute(stmt)).scalars().all()
    items=[]
    last_id=None
    for t in rows:
        last_id=int(t.id)
        items.append({
            "id": int(t.id),
            "title": t.title,
            "description": t.description,
            "is_active": bool(t.active),
            "reward_efhc": str(d8(t.reward_bonus_efhc)),
            "kind": str(t.type),
            "meta": t.meta,
            "created_at": t.created_at,
            "updated_at": t.updated_at,
        })
    next_after = last_id if rows and len(rows)==lim else None
    return {"items": items, "next_after": next_after}

async def admin_update_task(
    db: AsyncSession,
    task_id: int,
    payload: dict[str, Any],
) -> dict[str, Any] | None:
    stmt = (
        select(Task)
        .where(Task.id == int(task_id))
        .with_for_update()
    )
    t = (await db.execute(stmt)).scalar_one_or_none()
    if not t:
        return None
    if "title" in payload and payload["title"] is not None:
        t.title = str(payload["title"])
    if "description" in payload:
        t.description = payload.get("description")
    if "is_active" in payload and payload["is_active"] is not None:
        t.active = bool(payload["is_active"])
    if "reward_efhc" in payload and payload["reward_efhc"] is not None:
        t.reward_bonus_efhc = d8(payload["reward_efhc"])
    if "kind" in payload and payload["kind"] is not None:
        t.type = str(payload["kind"])
    if "meta" in payload:
        t.meta = payload.get("meta")
    await db.commit()
    await db.refresh(t)
    return await admin_get_task(db, int(t.id))

async def admin_delete_task(db: AsyncSession, task_id: int) -> bool:
    stmt = (
        select(Task)
        .where(Task.id == int(task_id))
        .with_for_update()
    )
    t = (await db.execute(stmt)).scalar_one_or_none()
    if not t:
        return False
    await db.delete(t)
    await db.commit()
    return True

async def admin_list_submissions(
    db: AsyncSession,
    *,
    task_id: int | None = None,
    limit: int = 50,
    after: dict[str, Any] | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    lim = max(1, min(200, int(limit)))
    after_id=None
    if after and after.get("after_id") is not None:
        try:
            raw_after = after.get("after_id")
            after_id = (
                None if raw_after is None else int(raw_after)
            )
        except Exception:
            after_id=None
    stmt = (
        select(TaskSubmission)
        .order_by(TaskSubmission.id.desc())
        .limit(lim)
    )
    if after_id is not None:
        stmt = stmt.where(TaskSubmission.id < after_id)
    if task_id is not None:
        stmt = stmt.where(TaskSubmission.task_id == int(task_id))
    if status:
        stmt = stmt.where(TaskSubmission.status == str(status))
    rows=(await db.execute(stmt)).scalars().all()
    items=[]
    last_id=None
    for s in rows:
        last_id=int(s.id)
        items.append({
            "id": int(s.id),
            "task_id": int(s.task_id),
            "tg_id": int(s.tg_id),
            "status": str(s.status),
            "proof_url": s.proof_url,
            "submitted_at": s.created_at,
            "reviewed_at": (
                None
                if s.moderator_tg_id is None
                else s.updated_at
            ),
            "reward_efhc": (
                str(d8(s.reward_amount_efhc))
                if s.reward_amount_efhc is not None
                else None
            ),
            "moderator_tg_id": (
                int(s.moderator_tg_id)
                if s.moderator_tg_id is not None
                else None
            ),
        })
    next_after = last_id if rows and len(rows)==lim else None
    return {"items": items, "next_after": next_after}

async def moderate_submission_and_pay(
    db: AsyncSession,
    *,
    submission_id: int,
    approve: bool,
    moderator_tg_id: int | None = None,
    reward_override_efhc: Decimal | None = None,
) -> dict[str, Any]:
    """Модерация заявки.

    Если approve — начисление бонуса через банк.
    """
    stmt = (
        select(TaskSubmission)
        .where(TaskSubmission.id == int(submission_id))
        .with_for_update()
    )
    sub = (await db.execute(stmt)).scalar_one_or_none()
    if not sub:
        raise ValueError("submission not found")

    # финальность
    if str(sub.status) in ("approved","rejected") or bool(sub.paid):
        raise ValueError("submission already finalized")

    if not approve:
        sub.status = "rejected"
        sub.moderator_tg_id = (
            int(moderator_tg_id)
            if moderator_tg_id is not None
            else None
        )
        await db.commit()
        return {"ok": True, "status": "rejected"}

    # approve path
    # approve path
    stmt = (
        select(Task)
        .where(Task.id == int(sub.task_id))
        .limit(1)
    )
    task = (await db.execute(stmt)).scalar_one_or_none()
    if not task:
        raise ValueError("task not found for submission")

    reward = d8(
        reward_override_efhc
        if reward_override_efhc is not None
        else task.reward_bonus_efhc
    )

    # Канон: идемпотентность через bank log key,
    # привязанный к submission_id
    idk = f"task_submission:{int(sub.id)}"

    res = await credit_user_bonus_from_bank(
        db,
        tg_id=int(sub.tg_id),
        amount=reward,
        reason="task_reward",
        idempotency_key=idk,
        meta={"task_id": int(task.id), "submission_id": int(sub.id)},
    )

    sub.status = "approved"
    sub.moderator_tg_id = (
        int(moderator_tg_id)
        if moderator_tg_id is not None
        else None
    )
    sub.reward_amount_efhc = reward
    sub.paid = True
    try:
        sub.paid_tx_id = int(getattr(res, "log_id", None) or 0) or None
    except Exception:
        sub.paid_tx_id = None

    await db.commit()
    return {"ok": True, "status": "approved", "amount": str(reward)}

# ======================================================================
# Public (user) tasks API used by routes/tasks_routes.py
# Канон:
# - Денежные операции (начисление бонуса)
#   только через transactions_service.
# - Cursor pagination for lists.
# ======================================================================


import sqlalchemy as sa  # noqa: E402
from app.services import transactions_service  # noqa: E402
from sqlalchemy import func  # noqa: E402
from sqlalchemy.orm import aliased  # noqa: E402


async def list_tasks_catalog(
    db: AsyncSession,
    *,
    after_id: int | None,
    limit: int,
) -> tuple[list[dict[str, Any]], int | None]:
    q = (
        select(
            Task.id,
            Task.code,
            Task.title,
            Task.description,
            Task.reward_amount_efhc,
            Task.type,
        )
        .where(Task.active.is_(True))
        .order_by(Task.id.asc())
        .limit(int(limit))
    )
    if after_id is not None:
        q = q.where(Task.id > int(after_id))

    r = await db.execute(q)
    rows = r.all()
    items = [
        {
            "id": int(row[0]),
            "code": str(row[1]),
            "title": str(row[2]),
            "description": (
                str(row[3]) if row[3] is not None else None
            ),
            "reward_efhc": row[4],
            "type": str(row[5]),
        }
        for row in rows
    ]
    next_after_id = int(rows[-1][0]) if rows else None
    return items, next_after_id


async def list_user_tasks(
    db: AsyncSession,
    *,
    tg_id: int,
    after_id: int | None,
    limit: int,
) -> tuple[list[dict[str, Any]], int | None]:
    # Показываем связку Task + последняя submission (если есть)
    sub = aliased(TaskSubmission)
    q = (
        select(
            Task.id.label("task_id"),
            Task.reward_amount_efhc.label("reward_efhc"),
            sub.id.label("id"),
            func.coalesce(
                sub.status,
                sa.literal("not_started"),
            ).label("status"),
            sa.literal(None).label("progress"),
            sa.literal(True).label("can_claim"),
        )
        .select_from(Task)
        .outerjoin(
            sub,
            sa.and_(
                sub.task_id == Task.id,
                sub.tg_id == int(tg_id),
            ),
        )
        .where(Task.active.is_(True))
        .order_by(Task.id.asc())
        .limit(int(limit))
    )
    if after_id is not None:
        q = q.where(Task.id > int(after_id))

    r = await db.execute(q)
    rows = r.all()
    items = []
    for row in rows:
        status = str(row.status)
        can_claim = status in ("approved", "auto_paid") and not bool(
            getattr(row, "paid", False)
        )
        items.append(
            {
                "id": int(row.id) if row.id is not None else 0,
                "task_id": int(row.task_id),
                "status": status,
                "progress": None,
                "reward_efhc": row.reward_efhc,
                "can_claim": can_claim,
            }
        )
    next_after_id = int(rows[-1].task_id) if rows else None
    return items, next_after_id


class _ClaimResult:
    def __init__(
        self,
        *,
        ok: bool,
        tg_id: int,
        reward_efhc: Decimal,
        user_bonus_balance: Decimal,
        user_main_balance: Decimal,
        detail: str | None = None,
    ):
        self.ok = ok
        self.tg_id = tg_id
        self.reward_efhc = reward_efhc
        self.user_bonus_balance = user_bonus_balance
        self.user_main_balance = user_main_balance
        self.detail = detail


async def claim_task_reward(
    db: AsyncSession,
    *,
    tg_id: int,
    task_id: int,
    idempotency_key: str,
) -> _ClaimResult:
    # 1) Load task and submission with lock.
    task = await db.get(Task, int(task_id))
    if not task or not bool(task.active):
        raise HTTPException(status_code=404, detail="Task not found")

    q = (
        select(TaskSubmission)
        .where(
            TaskSubmission.task_id == int(task_id),
            TaskSubmission.tg_id == int(tg_id),
        )
        .with_for_update()
    )
    r = await db.execute(q)
    sub = r.scalar_one_or_none()
    if not sub:
        raise HTTPException(
            status_code=409,
            detail="Task not submitted",
        )

    if bool(sub.paid):
        # Already paid: idempotent response (no double credit).
        bal = await transactions_service.get_user_balances(
            db, tg_id=int(tg_id)
        )
        return _ClaimResult(
            ok=True,
            tg_id=int(tg_id),
            reward_efhc=Decimal(str(sub.reward_amount_efhc)),
            user_bonus_balance=bal["bonus_balance"],
            user_main_balance=bal["main_balance"],
            detail="already_paid",
        )

    if str(sub.status) not in ("approved", "auto_paid"):
        raise HTTPException(
            status_code=409,
            detail="Submission is not approved",
        )

    reward = Decimal(str(task.reward_amount_efhc or 0))
    if reward <= Decimal("0"):
        raise HTTPException(
            status_code=409,
            detail="No reward for this task",
        )

    # 2) Credit bonus from bank via
    # transactions_service (economic canon).
    credit_fn = (
        transactions_service.credit_user_bonus_from_bank_by_tg_id
    )
    tx = await credit_fn(
        db,
        tg_id=int(tg_id),
        amount=reward,
        idempotency_key=str(idempotency_key),
        reason="task_reward",
        meta={"task_id": int(task_id), "submission_id": int(sub.id)},
    )

    # 3) Mark paid.
    sub.paid = True
    sub.paid_tx_id = (
        int(tx["transfer_id"])
        if tx and tx.get("transfer_id")
        else None
    )
    sub.reward_amount_efhc = reward
    await db.commit()

    bal = await transactions_service.get_user_balances(
        db, tg_id=int(tg_id)
    )
    return _ClaimResult(
        ok=True,
        tg_id=int(tg_id),
        reward_efhc=reward,
        user_bonus_balance=bal["bonus_balance"],
        user_main_balance=bal["main_balance"],
        detail="ok",
    )

