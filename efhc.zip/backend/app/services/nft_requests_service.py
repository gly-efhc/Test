from __future__ import annotations

# Совместимый фасад поверх nft_check_service для legacy-импортов.
import json
from typing import Any, cast
from uuid import uuid4

from app.services import nft_check_service
from sqlalchemy import text


async def refresh_vip_status_due_batch(
    db,
    *,
    limit: int = 1000,
    force: bool = False,
) -> dict[str, Any]:
    _ = limit, force
    result = await nft_check_service.check__all__users_once(db)
    return cast(dict[str, Any], result)


async def refresh_vip_status_for_due_users(
    db,
    *,
    limit: int = 1000,
    force: bool = False,
) -> dict[str, Any]:
    return await refresh_vip_status_due_batch(
        db,
        limit=limit,
        force=force,
    )


async def check_vip_nft_due_batch(
    db,
    *,
    limit: int = 1000,
    force: bool = False,
) -> dict[str, Any]:
    return await refresh_vip_status_due_batch(
        db,
        limit=limit,
        force=force,
    )


async def submit_manual_vip_nft_claim(
    db,
    *,
    tg_id: int,
    wallet_address: str = "",
    comment: str = "",
    created_by_admin_tid: int | None = None,
) -> dict[str, Any]:
    """Создать реальную manual VIP claim-заявку в shop_orders."""
    payload = {
        "source": "manual_vip_claim",
        "wallet_address": str(wallet_address or ""),
        "comment": str(comment or ""),
        "created_by_admin_tid": created_by_admin_tid,
    }
    q = text(
        """
        INSERT INTO efhc_core.shop_orders (
            tg_id,
            type,
            status,
            memo,
            idempotency_key,
            extra,
            created_at,
            updated_at
        )
        VALUES (
            :tg_id,
            'NFT',
            'PAID_PENDING_MANUAL',
            :memo,
            :idempotency_key,
            CAST(:extra AS jsonb),
            NOW(),
            NOW()
        )
        RETURNING id, status
        """
    )
    row = await db.execute(
        q,
        {
            "tg_id": int(tg_id),
            "memo": str(comment or "VIP NFT manual claim"),
            "idempotency_key": (
                f"manual-vip-claim:{tg_id}:{uuid4().hex}"
            ),
            "extra": json.dumps(
                payload,
                ensure_ascii=False,
            ),
        },
    )
    rec = row.fetchone()
    if rec is None:
        raise RuntimeError("vip_nft_manual_claim_insert_failed")
    return {
        "status": str(rec[1]),
        "mode": "created_shop_order",
        "order_id": int(rec[0]),
    }


__all__ = [
    "refresh_vip_status_due_batch",
    "refresh_vip_status_for_due_users",
    "check_vip_nft_due_batch",
    "submit_manual_vip_nft_claim",
]
