# backend/app/services/efhc_deposits_service.py
# ----------------------------------------------------------------------
# EFHC Bot — приём внешних депозитов EFHC с блокчейна во внутренний банк
# бота
# ----------------------------------------------------------------------
# Назначение:
# • После того как вотчер увидел входящую on-chain транзакцию EFHC
# на проектный внешний кошелёк, этот сервис:
# 1) Однозначно привязывает её к пользователю бота.
# 2) Начисляет пользователю EFHC из центрального "банка EFHC"
# по курсу 1:1 (внутренняя транзакция).
# 3) Гарантирует идемпотентность по tx_hash (никаких дублей).
#
# Канон/инварианты:
# • Источник внутренних EFHC — только банк EFHC.
#   credit_user_from_bank(
#       ..., idempotency_key="deposit:efhc:<tx_hash>"
#   )
# • Пользователь НИКОГДА не уходит в минус. Банк МОЖЕТ (операции не
# блокируем).
# • Курс фиксированный: 1 EFHC on-chain = 1 EFHC внутри бота.
# • Идемпотентность:
# idempotency_key = "deposit:efhc:<tx_hash>"
# Повторная обработка той же транзакции НЕ создаёт повторных начислений.
# • Привязка к пользователю:
# 1) Если есть корректный MEMO → global_id.
# 2) Если MEMO нет/невалиден → по адресу отправителя через таблицу
# привязанных кошельков (WalletBinding).
# • Если пользователя определить нельзя — депозит НЕ зачисляется,
# возвращаем
# error=user_not_resolved (для ручной обработки в админке).
#
# Контекст использования:
# • Внешний TON-кошелёк проекта принимает EFHC от пользователя.
# • Старт этой транзакции инициируется нажатием кнопки в боте
# ("Пополнить EFHC"), но сервис депозитов этого не требует — ему важен
# факт
# on-chain транзакции.
# • Начальный баланс банка EFHC (например, 5_000_000 EFHC) создаётся
# миграцией
# или отдельным скриптом — здесь мы только уменьшаем банк/увеличиваем
# баланс пользователя через banking-сервис.
# ----------------------------------------------------------------------

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from app.core.logging_core import get_logger
from app.deps import d8  # Decimal с 8 знаками, округление вниз
from app.identity.types import (
    global_id_from_database,
    global_id_to_database,
    parse_global_id,
)
from app.integrations.ton_memo import (
    MemoDepositEFHC,
    MemoDepositEFHCGlobal,
    parse_memo,
)
from app.lib.ton_address import (
    TonAddressError,
    canonicalize_ton_address,
)
from app.models.admin_models import IdempotencyKey
from app.models.user_models import User
from app.models.wallets_models import WalletBinding
from app.services import transactions_service as tx
from app.services.shop_payment_tx_hash_lock_service import (
    claim_tx_hash_settlement,
)
from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
DEPOSIT_IDEMPOTENCY_SCOPE = "deposit:efhc"
# HEAL-0055: deposit idempotency is an audit record,
# not a short HTTP-click lock. It must not expire automatically
# because on-chain replay/reconciliation can happen long after
# a serverless process has disappeared. Keep this constant
# explicit so future changes cannot silently reintroduce TTL.
DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"
DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None


def _canonical_deposit_idempotency_key(tx_hash: str) -> str:
    """Build the long-retention deposit idempotency key.

    The canonical value remains ``deposit:efhc:<tx_hash>`` while it fits
    the efhc_admin.idempotency_key.key limit. If a watcher
    supplies an unusually long transaction hash, store a stable
    digest key instead of truncating the source value.
    """
    raw_hash = str(tx_hash or "").strip()
    raw_key = f"deposit:efhc:{raw_hash}"
    if len(raw_key) <= 128:
        return raw_key
    digest = hashlib.sha256(raw_hash.encode("utf-8")).hexdigest()
    return f"deposit:efhc:{digest}"


def _deposit_request_fingerprint(
    *,
    tx_hash: str,
    amount: Any,
    memo: str | None,
    from_address: str | None,
    to_address: str | None,
) -> str:
    """Return a stable fingerprint for a deposit watcher payload."""
    payload = {
        "amount": str(amount),
        "from_address": from_address,
        "memo": memo,
        "to_address": to_address,
        "tx_hash": str(tx_hash or "").strip(),
    }
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


async def _read_deposit_idempotency_cache(
    db: AsyncSession,
    *,
    key: str,
    fingerprint: str,
) -> dict[str, Any] | None:
    """Read a stored long-retention deposit response, if any."""
    stmt = (
        select(
            IdempotencyKey.used,
            IdempotencyKey.request_fingerprint,
            IdempotencyKey.response_code,
            IdempotencyKey.response_payload_json,
        )
        .where(IdempotencyKey.key == str(key))
        .where(IdempotencyKey.scope == DEPOSIT_IDEMPOTENCY_SCOPE)
        .limit(1)
    )
    row = (await db.execute(stmt)).mappings().first()
    if not row:
        return None
    existing_fingerprint = row.get("request_fingerprint")
    if (
        existing_fingerprint
        and str(existing_fingerprint) != str(fingerprint)
    ):
        raise DepositError(
            "idempotency_fingerprint_mismatch: "
            "same deposit tx_hash was replayed with different payload"
        )

    payload = row.get("response_payload_json")
    if bool(row.get("used")) and isinstance(payload, dict):
        cached = dict(payload)
        cached.setdefault("idempotency_key", str(key))
        cached["detail"] = "idempotent_deposit_cache"
        return cached
    return None


async def _reserve_deposit_idempotency_key(
    db: AsyncSession,
    *,
    key: str,
    fingerprint: str,
) -> None:
    """Persist a non-expiring EFHC deposit idempotency record."""
    stmt = (
        pg_insert(IdempotencyKey)
        .values(
            key=str(key),
            scope=DEPOSIT_IDEMPOTENCY_SCOPE,
            request_fingerprint=str(fingerprint),
            used=False,
            expires_at=DEPOSIT_IDEMPOTENCY_EXPIRES_AT,
        )
        .on_conflict_do_nothing(index_elements=[IdempotencyKey.key])
    )
    await db.execute(stmt)


async def _store_deposit_idempotency_response(
    db: AsyncSession,
    *,
    key: str,
    fingerprint: str,
    response: dict[str, Any],
    response_code: int = 200,
) -> None:
    """Store the first deposit response in admin idempotency."""
    payload = json.loads(
        json.dumps(
            response,
            ensure_ascii=False,
            sort_keys=True,
            default=str,
        )
    )
    stmt = (
        update(IdempotencyKey)
        .where(IdempotencyKey.key == str(key))
        .values(
            scope=DEPOSIT_IDEMPOTENCY_SCOPE,
            request_fingerprint=str(fingerprint),
            used=True,
            response_code=int(response_code),
            response_payload_json=payload,
            expires_at=DEPOSIT_IDEMPOTENCY_EXPIRES_AT,
        )
    )
    await db.execute(stmt)
    await db.commit()


# ----------------------------------------------------------------------
# Ошибки и утилиты
# ----------------------------------------------------------------------


class DepositError(Exception):
    """Ошибка сервиса депозитов EFHC (для UI/логов, не про деньги)."""


def _as_decimal(value: Any) -> Decimal:
    """Безопасно привести к Decimal."""
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise DepositError(
            "Некорректное числовое значение amount"
        ) from exc


@dataclass
class ResolvedUser:
    global_id: str
    provider_tg_id: int | None = None


async def _resolve_user_by_memo(
    db: AsyncSession,
    memo: str | None,
) -> ResolvedUser | None:
    """Resolve canonical memo; read historical Telegram memo."""
    if not memo:
        return None
    memo_text = str(memo).strip()
    parsed = parse_memo(memo_text)
    if isinstance(parsed, MemoDepositEFHCGlobal):
        row = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(
                    User.global_id
                    == global_id_to_database(parse_global_id(parsed.global_id))
                )
                .limit(1)
            )
        ).first()
    elif isinstance(parsed, MemoDepositEFHC):
        row = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(User.tg_id == int(parsed.tg_id))
                .limit(1)
            )
        ).first()
    elif memo_text.isdigit():
        # Historical read-through: bare numeric memo was Telegram ID.
        row = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(User.tg_id == int(memo_text))
                .limit(1)
            )
        ).first()
    else:
        return None
    if row is None or row[0] is None:
        return None
    return ResolvedUser(
        global_id=str(global_id_from_database(row[0])),
        provider_tg_id=(int(row[1]) if row[1] is not None else None),
    )


async def _resolve_user_by_wallet(
    db: AsyncSession,
    from_address: str | None,
) -> ResolvedUser | None:
    """Resolve wallet binding to canonical account owner."""
    if not from_address:
        return None
    addr_raw = str(from_address).strip()
    if not addr_raw:
        return None
    try:
        addr_norm = canonicalize_ton_address(addr_raw)
    except TonAddressError:
        addr_norm = addr_raw
    row = (
        await db.execute(
            select(WalletBinding.global_id, WalletBinding.tg_id)
            .where(WalletBinding.wallet_address == addr_norm)
            .order_by(WalletBinding.id.asc())
            .limit(1)
        )
    ).first()
    if row is None:
        return None
    if row[0] is not None:
        user = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(
                    User.global_id
                    == global_id_to_database(global_id_from_database(row[0]))
                )
                .limit(1)
            )
        ).first()
    elif row[1] is not None:
        # Историческое чтение по кошельку; начисление остаётся global.
        user = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(User.tg_id == int(row[1]))
                .limit(1)
            )
        ).first()
    else:
        return None
    if user is None or user[0] is None:
        return None
    return ResolvedUser(
        global_id=str(global_id_from_database(user[0])),
        provider_tg_id=(
            int(user[1]) if user[1] is not None else None
        ),
    )


async def _resolve_deposit_user(
    db: AsyncSession,
    *,
    memo: str | None,
    from_address: str | None,
) -> ResolvedUser | None:
    """Сначала разрешить владельца по memo, затем по кошельку."""
    user = await _resolve_user_by_memo(db, memo)
    if user:
        return user
    return await _resolve_user_by_wallet(db, from_address)


# ----------------------------------------------------------------------
# Основная функция приёма депозита EFHC
# ----------------------------------------------------------------------


async def process_efhc_deposit(
    db: AsyncSession,
    *,
    tx_hash: str,
    amount: Any,
    memo: str | None,
    from_address: str | None,
    to_address: str | None = None,
    raw_tx: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Обработка одной on-chain транзакции EFHC.

    Вход:
      • tx_hash      — хэш транзакции (строка, уникальный в сети).
      • amount       — количество EFHC on-chain (Decimal-совместимое).
      • memo         — комментарий платежа; canonical G/GID содержит global_id.
      • from_address — кошелёк отправителя (пользователь).
      • to_address   — кошелёк проекта (для логов/контроля).
      • raw_tx — сырые данные транзакции (опц.)

    Логика:
      1) amount > 0, приводим к Decimal с 8 знаками (d8).
      2) Регистрируем долгосрочную DB-идемпотентность в
         efhc_admin.idempotency_key без expires_at.
      3) Определяем пользователя:
           a) canonical MEMO → global_id;
           b) если MEMO нет/невалиден → WalletBinding
              по from_address.
      4) Если пользователя не нашли → без начисления, но с сохранением
         idempotency-response для повторов того же tx_hash.
      5) Начисляем пользователю EFHC из банка по курсу 1:1 через
         credit_user_from_bank(...)
         idempotency_key="deposit:efhc:<tx_hash>".

    Важно:
      • Эта функция НИКОГДА не трогает on-chain балансы напрямую.
        Вся логика — внутренний банк EFHC.
      • HEAL-0055: защита от повторной обработки tx_hash живёт в БД,
        а не в in-memory TTL-кэше.
    """
    if not tx_hash or not str(tx_hash).strip():
        raise DepositError("tx_hash обязателен для идемпотентности")

    # 1) Сумма
    dec_amount = d8(_as_decimal(amount))
    if dec_amount <= Decimal("0"):
        raise DepositError("Сумма депозита EFHC должна быть больше 0")

    # 2) Долгосрочная DB-идемпотентность депозита.
    # HEAL-0055: защита от дублей должна жить в БД, а не в
    # in-memory TTL-кэше, потому что serverless/multi-instance среда
    # не разделяет память между инстансами.
    idem_key = _canonical_deposit_idempotency_key(str(tx_hash))
    fingerprint = _deposit_request_fingerprint(
        tx_hash=str(tx_hash),
        amount=str(dec_amount),
        memo=memo,
        from_address=from_address,
        to_address=to_address,
    )
    cached = await _read_deposit_idempotency_cache(
        db,
        key=idem_key,
        fingerprint=fingerprint,
    )
    if cached is not None:
        return cached
    await _reserve_deposit_idempotency_key(
        db,
        key=idem_key,
        fingerprint=fingerprint,
    )

    # 3) Определяем пользователя
    resolved = await _resolve_deposit_user(
        db,
        memo=memo,
        from_address=from_address,
    )
    if not resolved:
        logger.warning(
            "EFHC deposit: user not resolved "
            "(tx_hash=%s amount=%s memo=%r from=%r)",
            tx_hash,
            dec_amount,
            memo,
            from_address,
        )
        response = {
            "ok": False,
            "error": "user_not_resolved",
            "detail": (
                "Пользователь не найден по MEMO и по адресу кошелька."
            ),
            "tx_hash": tx_hash,
            "amount": str(dec_amount),
            "memo": memo,
            "from_address": from_address,
            "to_address": to_address,
            "idempotency_key": idem_key,
        }
        await _store_deposit_idempotency_response(
            db,
            key=idem_key,
            fingerprint=fingerprint,
            response=response,
            response_code=200,
        )
        return response

    global_id = resolved.global_id
    provider_tg_id = resolved.provider_tg_id

    # 4) Глобальный settlement claim по blockchain tx_hash.
    # Он общий для watcher, PaymentIntent и Admin recovery и поэтому
    # блокирует повторное финансовое зачисление одной on-chain операции
    # под другим бизнес-idempotency namespace.
    claim = await claim_tx_hash_settlement(
        db,
        tx_hash=str(tx_hash),
        purpose="admin_efhc_deposit",
        global_id=global_id,
    )
    if not claim.can_continue:
        response = {
            "ok": False,
            "error": "settlement_already_claimed",
            "detail": (
                "Эта blockchain-транзакция уже заявлена другим "
                "settlement-контуром и не может быть начислена повторно."
            ),
            "tx_hash": tx_hash,
            "amount": str(dec_amount),
            "global_id": global_id,
            "provider_tg_id": provider_tg_id,
            "from_address": from_address,
            "to_address": to_address,
            "memo": memo,
            "idempotency_key": idem_key,
        }
        await _store_deposit_idempotency_response(
            db,
            key=idem_key,
            fingerprint=fingerprint,
            response=response,
            response_code=409,
        )
        return response

    # 5) Начисление из банка EFHC 1:1
    meta: dict[str, Any] = {
        "domain": "efhc_external_deposit",
        "tx_hash": tx_hash,
        "from_address": from_address,
        "to_address": to_address,
        "memo": memo,
        "global_id": global_id,
        "provider_tg_id": provider_tg_id,
        "external_settlement": "received",
        "settlement_status": "confirmed",
        "bank_counterparty": "BANK_EFHC",
    }
    if raw_tx is not None:
        meta["raw_tx"] = raw_tx

    try:
        tx_result = await tx.credit_user_from_bank(
            db=db,
            global_id=global_id_to_database(parse_global_id(global_id)),
            amount=dec_amount,
            reason="efhc_external_deposit",
            idempotency_key=idem_key,
            meta=meta,
        )
    except Exception as exc:
        msg = f"Не удалось зачислить EFHC: {type(exc).__name__}: {exc}"
        raise DepositError(msg) from exc

    main_balance = d8(tx_result.user__main__balance)
    bonus_balance = d8(tx_result.user_bonus_balance)

    logger.info(
        "EFHC deposit processed: global_id=%s amount=%s tx_hash=%s",
        global_id,
        dec_amount,
        tx_hash,
    )

    response = {
        "ok": True,
        "tx_hash": tx_hash,
        "amount": str(dec_amount),
        "global_id": global_id,
        "provider_tg_id": provider_tg_id,
        "from_address": from_address,
        "to_address": to_address,
        "memo": memo,
        "idempotency_key": idem_key,
        "new__main__balance": str(main_balance),
        "new_bonus_balance": str(bonus_balance),
    }
    await _store_deposit_idempotency_response(
        db,
        key=idem_key,
        fingerprint=fingerprint,
        response=response,
        response_code=200,
    )
    return response


# ----------------------------------------------------------------------
# Схематический пример интеграции с watcher:
# ----------------------------------------------------------------------
# async def обработать_новый_перевод(tx):
# async with db_session() as db:
# внутри db.begin():
# результат = await process_efhc_deposit(
# db,
# tx_hash=tx.hash,
# amount=tx.amount,        # Decimal или строка
# memo=tx.comment,         # может быть None
# from_address=tx.from_addr,
# to_address=tx.to_addr,
# raw_tx=tx.to_dict(),     # опционально
# )
# # result["ok"] / result["error"] можно использовать для
# уведомлений/логов.
#
# Стартовый баланс банка EFHC (например, 5_000_000 EFHC) должен быть
# задан
# миграцией/скриптом в таблице банка (см. transactions_service и
# описание
# Банка).
# ----------------------------------------------------------------------

__all__ = [
    "DepositError",
    "process_efhc_deposit",
]
