# backend/app/services/referral_service.py
# ======================================================================
# Назначение кода:
# Сервис реферальной системы EFHC Bot:
# • Курсорные выборки «Активные / Неактивные» рефералы
#   для пригласившего.
# • Регистрация реферальной связи при старте бота по ссылке
#   (без бонуса).
# • Автоматическое однократное начисление 0.1 EFHCb прямому inviter
# при первой активации панели invitee, но только для первых
# 10 000 активных прямых рефералов inviter.
# • Ранги (уровни 0–5) по количеству АКТИВНЫХ прямых рефералов,
# разовые денежные бонусы за достижение уровней и прогресс до
# следующего уровня для фронтенда.
# • Генерация постоянного реферального кода/ссылки для пользователя.
#
# Канон/инварианты:
# • Флаг Activ — разовая активация: `activated_at` проставляется
#   один раз в `activate_referral()` при первой панели и остаётся
#   навсегда. Он не вычисляется из текущего количества или наличия
#   панелей. Архивация, истечение срока и будущее физическое удаление
#   панелей не влияют на статус; `panels_count` служит только UI.
# • Бонусы:
# • За каждого прямого реферала: один раз +0.1 EFHCb в bonus balance
# пригласившему при первой панели, максимум для первых 10 000
# активных прямых рефералов.
# • За достижение уровней начисляются разовые бонусы:
# 1 уровень: 10 активных рефералов    → +1 EFHCb
# 2 уровень: 100 активных рефералов   → +10 EFHCb
# 3 уровень: 1000 активных рефералов  → +100 EFHCb
# 4 уровень: 3000 активных рефералов  → +300 EFHCb
# 5 уровень: 10000 активных рефералов → +1000 EFHCb
#
# • Любые начисления идут ТОЛЬКО через банк (transactions_service),
# Decimal(30,8), округление вниз, bonus-first.
# • Пользователь НЕ может уйти в минус; Банк МОЖЕТ
#   (операции не блокируем).
# • Денежные операции — строго идемпотентны (idempotency-key банка).
#
# ИИ-защита/самовосстановление:
# • Курсорная пагинация без OFFSET: (invited_at, invitee_global_id) как
# курсор.
# • «Мягкие» SQL: сервис использует текстовые запросы, легко
#   адаптируется миграциями.
# • on_user_first_panel_activation(...) использует один locked
#   NULL -> activated_at transition в CRUD и начисляет награды только
#   транзакции-владельцу перехода; денежные ключи остаются
#   идемпотентными.
# • Уровневые награды начисляются отдельным helper с
#   идемпотентным ключом на каждый достигнутый уровень.
#
# Запреты:
# • Нет P2P-переводов; никаких прямых операций user→user.
# • Нет «суточных» расчётов; сервис не знает про генерацию энергии.
# ======================================================================

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any, cast

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.crud.referrals_crud import activate_referral
from app.deps import d8
from app.identity.account_registration import (
    AccountRegistrationError,
    NewAccountRequest,
    create_new_account,
    resolve_referral_code,
)
from app.identity.account_registration import (
    normalize_referral_start_param as _normalize_referral_start_param,
)
from app.identity.auth_provider import AuthProvider
from app.identity.idempotency_compat import (
    choose_compatible_idempotency_key,
)
from app.identity.user_identities_storage_contract import (
    USER_IDENTITY_DEFAULT_TENANT,
    UserIdentityStatus,
)
from app.models.identity_models import UserIdentity
from app.models.referral_models import ReferralLink
from app.models.transactions_models import EfhcTransferLog
from app.models.user_models import User
from app.services.transactions_service import (
    credit_user_bonus_from_bank_nocommit,
)
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)

# Legacy direct import сохранён без включения в ``__all__``.
normalize_referral_start_param = _normalize_referral_start_param
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# ----------------------------------------------------------------------
# Константы реферальной системы
# ----------------------------------------------------------------------

# 0.1 EFHCb один раз за первую панель каждого прямого реферала
REF_BONUS_PER_ACTIVE_UNIT_RAW = (
    getattr(settings, "REFERRAL_BONUS_PER_ACTIVE_UNIT", "0.1") or "0.1"
)
REF_BONUS_PER_ACTIVE_UNIT = d8(REF_BONUS_PER_ACTIVE_UNIT_RAW)

# Ограничение количества АКТИВНЫХ рефералов с бонусом 0.1 EFHCb
REF_MAX_ACTIVE_FOR_UNIT_BONUS: int = int(
    getattr(settings, "REFERRAL_MAX_ACTIVE_FOR_UNIT_BONUS", 10_000)
    or 10_000
)

# All referral monetary rewards use bonus_balance.
# Their canonical asset label is EFHCb.
REFERRAL_BONUS_ASSET = "EFHCb"


# Конфигурация уровней 1–5 (по ЧИСЛУ АКТИВНЫХ рефералов)
@dataclass(frozen=True)
class ReferralLevelConfig:
    level: int
    required_active: int
    bonus: Decimal  # EFHCb, начисляется разово при достижении уровня


REF_LEVELS: tuple[ReferralLevelConfig, ...] = (
    ReferralLevelConfig(level=1, required_active=10, bonus=d8("1")),
    ReferralLevelConfig(level=2, required_active=100, bonus=d8("10")),
    ReferralLevelConfig(level=3, required_active=1000, bonus=d8("100")),
    ReferralLevelConfig(level=4, required_active=3000, bonus=d8("300")),
    ReferralLevelConfig(
        level=5,
        required_active=10000,
        bonus=d8("1000"),
    ),
)


@dataclass(frozen=True)
class ReferralLevelStep:
    """Canonical cumulative economics at a referral level threshold."""

    level: int
    required_active: int
    level_bonus: Decimal
    direct_bonus_total: Decimal
    cumulative_level_bonus: Decimal
    cumulative_total_reward: Decimal


def get_referral_level_steps() -> tuple[ReferralLevelStep, ...]:
    """Return the canonical visible Lvl scale without duplicating math.

    ``direct_bonus_total`` is ``required_active × 0.1 EFHCb``.
    ``cumulative_level_bonus`` includes every one-time Lvl reward
    reached by that threshold. Therefore Lvl 1 is exactly
    ``10 × 0.1 + 1 = 2 EFHCb``.
    """
    cumulative_level_bonus = d8("0")
    steps: list[ReferralLevelStep] = []
    for cfg in REF_LEVELS:
        cumulative_level_bonus = d8(cumulative_level_bonus + cfg.bonus)
        direct_bonus_total = d8(
            REF_BONUS_PER_ACTIVE_UNIT * Decimal(cfg.required_active)
        )
        steps.append(
            ReferralLevelStep(
                level=cfg.level,
                required_active=cfg.required_active,
                level_bonus=cfg.bonus,
                direct_bonus_total=direct_bonus_total,
                cumulative_level_bonus=cumulative_level_bonus,
                cumulative_total_reward=d8(
                    direct_bonus_total + cumulative_level_bonus
                ),
            )
        )
    return tuple(steps)

# Настройки реферального кода/ссылки
REF_CODE_LENGTH: int = int(
    getattr(settings, "REFERRAL_CODE_LENGTH", 8) or 8
)
REF_CODE_ALPHABET: str = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
REF_SALT: str = (
    getattr(settings, "REFERRAL_SALT", "efhc_ref_salt")
    or "efhc_ref_salt"
)
BOT_USERNAME: str = getattr(settings, "BOT_USERNAME", "") or ""

# ----------------------------------------------------------------------
# DTO курсорных ответов и статистики
# ----------------------------------------------------------------------


@dataclass
class ReferralItem:
    child_tg_id: int
    global_id: int
    username: str | None
    joined_at: datetime
    is_active: bool
    total_generated_kwh: Decimal
    panels_count: int
    invited_at: datetime
    activated_at: datetime | None


CursorTuple = tuple[str, int]  # (created_at_iso, invitee_global_id)


@dataclass
class ReferralStats:
    inviter_tg_id: int | None
    total_referrals: int  # все рефералы (по ссылке)
    active_referrals: int  # активные (активировали ≥1 панель)
    level: int  # 0..5
    next_level: int | None  # None, если достигнут 5 уровень
    # Сколько активных нужно для текущего уровня (0 для уровня 0).
    current_level_min: int
    # Сколько активных нужно для следующего уровня.
    next_level_min: int | None
    # Сколько активных не хватает до следующего уровня (0, если max).
    refs_to_next: int
    progress: float  # 0.0–1.0 прогресс от текущего уровня до следующего
    referral_code: str  # стабильный код
    referral_link: str | None  # t.me-ссылка, если BOT_USERNAME задан


@dataclass
class ReferralPageStats:
    inviter_tg_id: int | None
    bonus_balance: Decimal
    referrals_bonus_total: Decimal
    total_referrals: int
    active_referrals: int
    inactive_referrals: int
    level: int
    current_level_min: int
    next_level: int | None
    next_level_min: int | None
    refs_to_next: int
    progress: float
    unit_bonus_per_active: Decimal
    max_active_for_unit_bonus: int
    bonus_asset: str
    full_cycle_direct_bonus: Decimal
    full_cycle_level_bonus: Decimal
    full_cycle_total_bonus: Decimal
    level_steps: tuple[ReferralLevelStep, ...]
    referral_code: str
    referral_link: str | None


# ----------------------------------------------------------------------
# Витрина главной страницы referrals
# ----------------------------------------------------------------------


async def _get_user_bonus_balance(
    db: AsyncSession,
    *,
    inviter_tg_id: int | None = None,
    inviter_global_id: int | None = None,
) -> Decimal:
    if (inviter_tg_id is None) == (inviter_global_id is None):
        raise ValueError("Требуется ровно один identity selector")
    owner_clause = (
        User.global_id == int(inviter_global_id)
        if inviter_global_id is not None
        else User.tg_id == int(inviter_tg_id or 0)
    )
    row = await db.execute(
        select(User.bonus_balance).where(owner_clause).limit(1)
    )
    value = cast(Decimal | None, row.scalar())
    if value is None:
        return Decimal("0")
    return Decimal(str(value)).quantize(Decimal("0.00000000"))


async def _sum_referrals_bonus_total(
    db: AsyncSession,
    *,
    inviter_tg_id: int | None = None,
    inviter_global_id: int | None = None,
) -> Decimal:
    if (inviter_tg_id is None) == (inviter_global_id is None):
        raise ValueError("Требуется ровно один identity selector")
    owner_clause = (
        EfhcTransferLog.global_id == int(inviter_global_id)
        if inviter_global_id is not None
        else EfhcTransferLog.tg_id == int(inviter_tg_id or 0)
    )
    row = await db.execute(
        select(
            func.coalesce(
                func.sum(EfhcTransferLog.amount),
                0,
            )
        ).where(
            owner_clause,
            EfhcTransferLog.direction == "credit",
            EfhcTransferLog.balance_type == "bonus",
            EfhcTransferLog.reason.in_(
                [
                    "referral_active_unit",
                    "referral_level_bonus",
                ]
            ),
        )
    )
    value = cast(Decimal | None, row.scalar())
    if value is None:
        return Decimal("0")
    return Decimal(str(value)).quantize(Decimal("0.00000000"))


async def get_referrals_page_stats(
    db: AsyncSession,
    *,
    inviter_tg_id: int,
) -> ReferralPageStats:
    base = await get_referral_stats(
        db,
        inviter_tg_id=int(inviter_tg_id),
    )
    bonus_balance = await _get_user_bonus_balance(
        db,
        inviter_tg_id=int(inviter_tg_id),
    )
    bonuses_total = await _sum_referrals_bonus_total(
        db,
        inviter_tg_id=int(inviter_tg_id),
    )
    inactive_refs = max(0, base.total_referrals - base.active_referrals)
    level_steps = get_referral_level_steps()
    full_cycle = level_steps[-1]
    return ReferralPageStats(
        inviter_tg_id=int(inviter_tg_id),
        bonus_balance=bonus_balance,
        referrals_bonus_total=bonuses_total,
        total_referrals=int(base.total_referrals),
        active_referrals=int(base.active_referrals),
        inactive_referrals=int(inactive_refs),
        level=int(base.level),
        current_level_min=int(base.current_level_min),
        next_level=(
            int(base.next_level)
            if base.next_level is not None
            else None
        ),
        next_level_min=(
            int(base.next_level_min)
            if base.next_level_min is not None
            else None
        ),
        refs_to_next=int(base.refs_to_next),
        progress=float(base.progress),
        unit_bonus_per_active=REF_BONUS_PER_ACTIVE_UNIT,
        max_active_for_unit_bonus=REF_MAX_ACTIVE_FOR_UNIT_BONUS,
        bonus_asset=REFERRAL_BONUS_ASSET,
        full_cycle_direct_bonus=full_cycle.direct_bonus_total,
        full_cycle_level_bonus=full_cycle.cumulative_level_bonus,
        full_cycle_total_bonus=full_cycle.cumulative_total_reward,
        level_steps=level_steps,
        referral_code=str(base.referral_code),
        referral_link=base.referral_link,
    )


# ----------------------------------------------------------------------
# Внутренние SQL-хелперы для списков рефералов
# ----------------------------------------------------------------------

# Таблицы по канону:
# • efhc_core.referral_links(
# inviter_global_id BIGINT,
# invitee_global_id BIGINT,
# created_at TIMESTAMPTZ,
# activated_at TIMESTAMPTZ NULL
# )
# • efhc_core.users(id PK, global_id BIGINT, username TEXT, ...)
# • efhc_core.panels(id PK, tg_id Telegram ID, is_active BOOL, ...)
#
# Activ читается только из неизменяемого activation flag:
# referral_links.activated_at IS NOT NULL. panel_counts нужен только
# для информационного поля UI и не участвует в статусе.
SQL_LIST_REFERRALS = """
WITH ref AS (
    SELECT
        rl.invitee_tg_id AS ref_tg,
        rl.inviter_tg_id AS inv_tg,
        rl.created_at AS invited_at,
        rl.activated_at AS activated_at
    FROM efhc_core.referral_links rl
    WHERE rl.inviter_tg_id = :inviter_tg
),
panel_counts AS (
    SELECT
        p.tg_id,
        COUNT(p.id)::BIGINT AS panels_count
    FROM efhc_core.panels p
    INNER JOIN ref
        ON ref.ref_tg = p.tg_id
    GROUP BY p.tg_id
)
SELECT
    ref.ref_tg AS child_tg_id,
    ref.ref_tg AS tg_id,
    u.username AS username,
    u.created_at AS joined_at,
    (ref.activated_at IS NOT NULL) AS is_active,
    COALESCE(u.total_generated_kwh, 0) AS total_generated_kwh,
    COALESCE(pc.panels_count, 0) AS panels_count,
    ref.invited_at AS invited_at,
    ref.activated_at AS activated_at
FROM ref
INNER JOIN efhc_core.users u
    ON u.tg_id = ref.ref_tg
LEFT JOIN panel_counts pc
    ON pc.tg_id = ref.ref_tg
WHERE (
    (
        CAST(:cursor_ts AS TIMESTAMPTZ) IS NULL
        AND CAST(:cursor_id AS BIGINT) IS NULL
    )
    OR (
        (ref.invited_at, ref.ref_tg)
        < (
            CAST(:cursor_ts AS TIMESTAMPTZ),
            CAST(:cursor_id AS BIGINT)
        )
    )
)
AND (
    (
        CAST(:want_active AS BOOLEAN) = TRUE
        AND ref.activated_at IS NOT NULL
    )
    OR (
        CAST(:want_active AS BOOLEAN) = FALSE
        AND ref.activated_at IS NULL
    )
)
ORDER BY
    ref.invited_at DESC,
    ref.ref_tg DESC
LIMIT CAST(:fetch_limit AS INTEGER)
"""


async def _svc_list_referrals(
    db: AsyncSession,
    *,
    inviter_tg_id: int,
    limit: int,
    cursor: CursorTuple | None,
    want_active: bool,
) -> tuple[list[ReferralItem], CursorTuple | None]:
    """Return one stable cursor page filtered entirely by PostgreSQL."""
    safe_limit = max(1, min(int(limit), 200))
    cur_ts, cur_id = _normalize_cursor(cursor)
    rows = await db.execute(
        text(SQL_LIST_REFERRALS),
        {
            "inviter_tg": int(inviter_tg_id),
            "cursor_ts": cur_ts,
            "cursor_id": cur_id,
            "want_active": bool(want_active),
            "fetch_limit": safe_limit + 1,
        },
    )
    fetched = rows.fetchall()
    has_more = len(fetched) > safe_limit
    page_rows = fetched[:safe_limit]
    items = [
        ReferralItem(
            child_tg_id=int(row[0]),
            global_id=int(row[1]),
            username=(str(row[2]) if row[2] is not None else None),
            joined_at=row[3],
            is_active=bool(row[4]),
            total_generated_kwh=Decimal(str(row[5])),
            panels_count=int(row[6]),
            invited_at=row[7],
            activated_at=row[8],
        )
        for row in page_rows
    ]
    next_cursor = _next_cursor(items) if has_more else None
    logger.info(
        "referral_active_count_calculated inviter_tg_id=%s "
        "want_active=%s returned=%s has_more=%s",
        int(inviter_tg_id),
        bool(want_active),
        len(items),
        has_more,
    )
    return items, next_cursor


async def svc_list_referrals_active(
    db: AsyncSession,
    inviter_tg_id: int,
    limit: int,
    cursor: CursorTuple | None,
) -> tuple[list[ReferralItem], CursorTuple | None]:
    return await _svc_list_referrals(
        db,
        inviter_tg_id=int(inviter_tg_id),
        limit=int(limit),
        cursor=cursor,
        want_active=True,
    )


async def svc_list_referrals_inactive(
    db: AsyncSession,
    inviter_tg_id: int,
    limit: int,
    cursor: CursorTuple | None,
) -> tuple[list[ReferralItem], CursorTuple | None]:
    return await _svc_list_referrals(
        db,
        inviter_tg_id=int(inviter_tg_id),
        limit=int(limit),
        cursor=cursor,
        want_active=False,
    )


# ----------------------------------------------------------------------
# Публичные функции: API-обёртки (имена из routes/referrals_routes.py)
# ----------------------------------------------------------------------


@dataclass
class ReferralsPage:
    items: list[ReferralItem]
    next_cursor: str | None


@dataclass
class ReferralCounters:
    total: int
    active: int
    inactive: int


def _parse_cursor_str(cursor: str | None) -> CursorTuple | None:
    if not cursor:
        return None
    raw = str(cursor).strip()
    if not raw:
        return None
    sep = "|" if "|" in raw else ("," if "," in raw else None)
    if not sep:
        return None
    parts = raw.split(sep, 1)
    if len(parts) != 2:
        return None
    ts = parts[0].strip()
    try:
        rid = int(parts[1].strip())
    except Exception:
        return None
    return (ts, rid)


def _format_cursor(cur: CursorTuple | None) -> str | None:
    if not cur:
        return None
    ts, rid = cur
    return f"{ts}|{int(rid)}"


def _normalize_cursor(
    cursor: CursorTuple | None,
) -> tuple[datetime | None, int | None]:
    if not cursor:
        return None, None
    ts_raw, rid = cursor
    try:
        ts = datetime.fromisoformat(str(ts_raw))
    except Exception:
        ts = None
    try:
        cid = int(rid) if rid is not None else None
    except Exception:
        cid = None
    return ts, cid


def _next_cursor(
    items: list[ReferralItem],
) -> CursorTuple | None:
    if not items:
        return None
    last = items[-1]
    try:
        ts = last.invited_at
        ts_s = ts.isoformat() if isinstance(ts, datetime) else str(ts)
        return (ts_s, int(last.tg_id))
    except Exception:
        return None


def build_referral_link(code: str) -> str:
    uname = str(BOT_USERNAME).lstrip("@").strip()
    return f"https://t.me/{uname}?start=ref_{code}"


def _generate_referral_code(length: int = 10) -> str:
    import secrets
    import string

    alphabet = string.ascii_uppercase + string.digits
    n = max(6, min(32, int(length)))
    return "".join(secrets.choice(alphabet) for _ in range(n))


async def ensure_consistency(
    db: AsyncSession,
    *,
    parent_tg_id: int,
) -> None:
    # Best-effort: гарантируем наличие таблицы и кода.
    await ensure_referral_codes_table(db)
    await get_or_create_referral_code(
        db,
        inviter_tg_id=int(parent_tg_id),
    )


async def list_active_referrals(
    db: AsyncSession,
    *,
    parent_tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
) -> ReferralsPage:
    cur = _parse_cursor_str(cursor)
    items, next_cur = await svc_list_referrals_active(
        db,
        inviter_tg_id=int(parent_tg_id),
        limit=int(limit),
        cursor=cur,
    )
    return ReferralsPage(
        items=items,
        next_cursor=_format_cursor(next_cur),
    )


async def list_inactive_referrals(
    db: AsyncSession,
    *,
    parent_tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
) -> ReferralsPage:
    cur = _parse_cursor_str(cursor)
    items, next_cur = await svc_list_referrals_inactive(
        db,
        inviter_tg_id=int(parent_tg_id),
        limit=int(limit),
        cursor=cur,
    )
    return ReferralsPage(
        items=items,
        next_cursor=_format_cursor(next_cur),
    )


async def get_counters(
    db: AsyncSession,
    *,
    parent_tg_id: int,
) -> ReferralCounters:
    total = await _count_total_referrals(
        db, inviter_tg_id=int(parent_tg_id)
    )
    active = await _count_active_referrals(
        db, inviter_tg_id=int(parent_tg_id)
    )
    inactive = max(int(total) - int(active), 0)
    return ReferralCounters(
        total=int(total),
        active=int(active),
        inactive=int(inactive),
    )


@dataclass(frozen=True)
class ReferralOnboardingResult:
    created: bool
    referral_attached: bool
    reason: str
    inviter_tg_id: int | None = None


class ReferralOnboardingRejected(ValueError):
    """Fail-closed rejection before a new user is created."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


async def _create_bot_user_identity(
    db: AsyncSession,
    *,
    global_id: int,
    tg_id: int,
    verified_at: datetime,
) -> None:
    """Создать проверенную Telegram identity нового bot account."""

    db.add(
        UserIdentity(
            global_id=int(global_id),
            provider=AuthProvider.TELEGRAM.value,
            provider_tenant=USER_IDENTITY_DEFAULT_TENANT,
            provider_subject=str(int(tg_id)),
            status=UserIdentityStatus.ACTIVE.value,
            is_primary=True,
            is_verified=True,
            verified_at=verified_at,
            provider_metadata={
                "source": "telegram_bot_start",
                "cycle": 1637,
            },
        )
    )
    await db.flush()


async def _user_exists_after_storage_conflict(
    db: AsyncSession,
    *,
    tg_id: int,
) -> bool:
    """Проверить конкурентно созданный account после rollback."""

    existing_row = await db.scalar(
        select(User.id).where(User.tg_id == int(tg_id)).limit(1)
    )
    await db.rollback()
    return existing_row is not None


async def onboard_user_at_first_creation(
    db: AsyncSession,
    *,
    global_id: int,
    username: str | None = None,
    start_param: str | None = None,
    created_at: datetime | None = None,
) -> ReferralOnboardingResult:
    """Создать Bot account, referral и identity одной транзакцией.

    Существующий пользователь, включая permanent ``0 user``, не может
    получить referral позднее. Неверный переданный код отклоняется до
    создания account. WebApp и TON используют то же registration core.
    """

    user_tg_id = int(tg_id)
    existing = await db.scalar(
        select(User.id)
        .where(User.tg_id == user_tg_id)
        .limit(1)
        .with_for_update()
    )
    if existing is not None:
        await db.rollback()
        return ReferralOnboardingResult(
            created=False,
            referral_attached=False,
            reason="existing_user_locked",
        )

    verified_at = created_at or datetime.now(tz=UTC)
    try:
        registration = await create_new_account(
            db,
            NewAccountRequest(
                provider=AuthProvider.TELEGRAM,
                tg_id=user_tg_id,
                referral_start_param=start_param,
                username=username,
            ),
        )
        await _create_bot_user_identity(
            db,
            global_id=registration.global_id.value,
            tg_id=user_tg_id,
            verified_at=verified_at,
        )

        inviter_tg_id: int | None = None
        if registration.referral_attached:
            link = await db.scalar(
                select(ReferralLink)
                .where(
                    ReferralLink.invitee_global_id
                    == registration.global_id.value
                )
                .limit(1)
            )
            if link is None:
                raise RuntimeError("referral_link_not_created")
            inviter_tg_id = int(link.inviter_tg_id)

        await db.commit()
    except AccountRegistrationError as exc:
        await db.rollback()
        if exc.reason in {
            "invalid_code",
            "code_not_found",
            "self_ref",
        }:
            raise ReferralOnboardingRejected(exc.reason) from exc
        if exc.reason == "ACCOUNT_ALREADY_EXISTS":
            return ReferralOnboardingResult(
                created=False,
                referral_attached=False,
                reason="existing_user_locked",
            )
        if (
            exc.reason == "STORAGE_CONFLICT"
            and await _user_exists_after_storage_conflict(
                db,
                tg_id=user_tg_id,
            )
        ):
            return ReferralOnboardingResult(
                created=False,
                referral_attached=False,
                reason="existing_user_locked",
            )
        raise
    except Exception:
        await db.rollback()
        raise

    return ReferralOnboardingResult(
        created=True,
        referral_attached=registration.referral_attached,
        reason=(
            "created_with_referral"
            if registration.referral_attached
            else "created_zero_user"
        ),
        inviter_tg_id=inviter_tg_id,
    )


@dataclass(frozen=True, slots=True)
class _ReferralOwner:
    global_id: int
    tg_id: int | None


async def _resolve_referral_owner(
    db: AsyncSession,
    *,
    global_id: int | None = None,
    tg_id: int | None = None,
) -> _ReferralOwner | None:
    """Разрешить реферального владельца до canonical ``global_id``."""
    if global_id is not None:
        stmt = (
            select(User.global_id, User.tg_id)
            .where(User.global_id == int(global_id))
            .limit(1)
        )
    elif tg_id is not None:
        stmt = (
            select(User.global_id, User.tg_id)
            .where(User.tg_id == int(tg_id))
            .limit(1)
        )
    else:
        return None
    row = (await db.execute(stmt)).first()
    if row is None or row.global_id is None:
        return None
    return _ReferralOwner(
        global_id=int(row.global_id),
        tg_id=(int(row.tg_id) if row.tg_id is not None else None),
    )


# ----------------------------------------------------------------------
# Авто-активация и бонусы при первой активации панели приглашённым
# Вызывается panels_service после успешной активации ПЕРВОЙ панели.
# ----------------------------------------------------------------------


async def on_user_first_panel_activation(
    db: AsyncSession,
    buyer_tg_id: int | None = None,
    activation_dt: datetime | None = None,
    *,
    buyer_global_id: int | None = None,
) -> None:
    """Помечает реферала активным и начисляет бонусы.

    Caller owns commit/rollback. The function is intentionally
    no-commit so first-panel creation and all rewards remain atomic.

    Действия:
    • Один unit-бонус 0.1 EFHCb за первую панель прямого реферала
      (до 10 000 активных прямых рефералов inviter).
    • Разовые денежные бонусы за достигнутые уровни 1–5.
    """
    buyer = await _resolve_referral_owner(
        db,
        global_id=buyer_global_id,
        tg_id=buyer_tg_id,
    )
    if buyer is None:
        logger.warning(
            "referral: buyer owner mapping missing "
            "global_id=%s tg_id=%s",
            buyer_global_id,
            buyer_tg_id,
        )
        return
    activation = await activate_referral(
        db,
        invitee_global_id=buyer.global_id,
        invitee_tg_id=buyer.tg_id,
        activation_dt=activation_dt,
    )
    link = activation.link
    if link is None:
        # Пользователь пришёл без реф-ссылки — нечего активировать.
        logger.debug(
            "referral: no link for buyer global_id=%s tg_id=%s",
            buyer.global_id,
            buyer.tg_id,
        )
        return
    if not activation.activated_now:
        logger.info(
            "referral_activation_duplicate_skipped "
            "inviter_tg_id=%s invitee_tg_id=%s",
            int(link.inviter_tg_id),
            int(buyer.tg_id or 0),
        )
        return

    inviter = await _resolve_referral_owner(
        db,
        global_id=(
            int(link.inviter_global_id)
            if link.inviter_global_id is not None
            else None
        ),
        tg_id=int(link.inviter_tg_id),
    )
    if inviter is None:
        logger.warning(
            "referral: inviter owner mapping not found global_id=%s",
            link.inviter_tg_id,
        )
        return
    inviter_tg = int(inviter.tg_id or 0)
    logger.info(
        "referral_activated inviter_tg_id=%s invitee_tg_id=%s",
        inviter_tg,
        int(buyer.tg_id or 0),
    )

    await _award_first_panel_referral_rewards(
        db=db,
        inviter_global_id=inviter.global_id,
        inviter_tg_id=inviter.tg_id,
        buyer_global_id=buyer.global_id,
        buyer_tg_id=buyer.tg_id,
    )


# ----------------------------------------------------------------------
# Статистика для фронтенда: уровни, прогресс, ссылка
# ----------------------------------------------------------------------


async def get_referral_stats(
    db: AsyncSession,
    *,
    inviter_tg_id: int,
) -> ReferralStats:
    """
    Возвращает агрегированную статистику для реферального раздела:
      • total_referrals      — общее число рефералов (по ссылке)
      • active_referrals     — активные (активировали ≥1 панель)
      • level (0–5)
      • next_level / refs_to_next / progress (0.0–1.0)
      • referral_code, referral_link
    """
    total_refs = await _count_total_referrals(
        db,
        inviter_tg_id=inviter_tg_id,
    )
    inviter_tg: int = int(inviter_tg_id)
    active_refs = await _count_active_referrals(
        db,
        inviter_tg_id=inviter_tg,
    )

    (
        level,
        current_min,
        next_level,
        next_min,
        refs_to_next,
        progress,
    ) = _compute_level_and_progress(active_refs)

    code = await get_or_create_referral_code(
        db,
        inviter_tg_id=inviter_tg_id,
    )
    link = build_referral_link(code) if code and BOT_USERNAME else None

    return ReferralStats(
        inviter_tg_id=int(inviter_tg_id),
        total_referrals=total_refs,
        active_referrals=active_refs,
        level=level,
        next_level=next_level,
        current_level_min=current_min,
        next_level_min=next_min,
        refs_to_next=refs_to_next,
        progress=progress,
        referral_code=code,
        referral_link=link,
    )


# ----------------------------------------------------------------------
# Денежная логика: 0.1 EFHCb за первую панель прямого реферала
# и разовые награды за достижение реферальных уровней
# ----------------------------------------------------------------------


async def _award_first_panel_referral_rewards(
    *,
    db: AsyncSession,
    inviter_global_id: int,
    inviter_tg_id: int | None,
    buyer_global_id: int,
    buyer_tg_id: int | None,
) -> None:
    """Run unit and level rewards with fail-through semantics."""
    try:
        await _maybe_reward_active_unit_bonus(
            db=db,
            inviter_global_id=int(inviter_global_id),
            inviter_tg_id=inviter_tg_id,
            buyer_global_id=int(buyer_global_id),
            buyer_tg_id=buyer_tg_id,
        )
        await _sync_inviter_level_rewards(
            db=db,
            inviter_global_id=int(inviter_global_id),
            inviter_tg_id=inviter_tg_id,
        )
    except Exception:
        logger.exception(
            "referral_bonus_transaction_rolled_back "
            "inviter_tg_id=%s invitee_tg_id=%s",
            int(inviter_tg_id or 0),
            int(buyer_tg_id or 0),
        )
        raise


async def _maybe_reward_active_unit_bonus(
    db: AsyncSession,
    inviter_tg_id: int | None,
    buyer_tg_id: int | None,
    *,
    inviter_global_id: int | None = None,
    buyer_global_id: int | None = None,
) -> None:
    """Начислить unit-бонус с global owner и совместимым ключом."""
    inviter = await _resolve_referral_owner(
        db, global_id=inviter_global_id, tg_id=inviter_tg_id
    )
    buyer = await _resolve_referral_owner(
        db, global_id=buyer_global_id, tg_id=buyer_tg_id
    )
    if inviter is None or buyer is None:
        logger.warning(
            "referral: owner mapping missing for unit bonus "
            "inviter_global_id=%s buyer_global_id=%s",
            inviter_global_id,
            buyer_global_id,
        )
        return

    active_refs = await _count_active_referrals_global(
        db,
        inviter_global_id=inviter.global_id,
        legacy_tg_id=inviter.tg_id,
    )
    if active_refs > REF_MAX_ACTIVE_FOR_UNIT_BONUS:
        logger.info(
            "referral: max active unit bonus reached global_id=%s "
            "active_refs=%s",
            inviter.global_id,
            active_refs,
        )
        return
    if d8("0") >= REF_BONUS_PER_ACTIVE_UNIT:
        return

    canonical_key = f"REF_ACT_UNIT:G{buyer.global_id:010d}"
    legacy_key = (
        f"REF_ACT_UNIT:{buyer.tg_id}"
        if buyer.tg_id is not None
        else None
    )
    key = await choose_compatible_idempotency_key(
        db,
        canonical_key=canonical_key,
        legacy_key=legacy_key,
    )
    result = await credit_user_bonus_from_bank_nocommit(
        db=db,
        global_id=inviter.global_id,
        amount=REF_BONUS_PER_ACTIVE_UNIT,
        reason="referral_active_unit",
        idempotency_key=key.selected,
        meta={
            "inviter_global_id": inviter.global_id,
            "inviter_tg": inviter.tg_id,
            "buyer_global_id": buyer.global_id,
            "buyer_tg": buyer.tg_id,
            "canonical_idempotency_key": canonical_key,
            "legacy_idempotency_key": legacy_key,
        },
    )
    duplicate = str(getattr(result, "detail", "ok")).startswith(
        "idempotent"
    )
    logger.info(
        "%s inviter_global_id=%s buyer_global_id=%s "
        "idempotency_key=%s",
        (
            "referral_bonus_duplicate_skipped"
            if duplicate
            else "referral_unit_bonus_awarded"
        ),
        inviter.global_id,
        buyer.global_id,
        key.selected,
    )


async def _sync_inviter_level_rewards(
    db: AsyncSession,
    inviter_tg_id: int | None,
    *,
    inviter_global_id: int | None = None,
) -> None:
    """Начислить уровневые бонусы по canonical global owner."""
    inviter = await _resolve_referral_owner(
        db, global_id=inviter_global_id, tg_id=inviter_tg_id
    )
    if inviter is None:
        logger.warning(
            "referral: inviter owner mapping missing for level sync "
            "global_id=%s tg_id=%s",
            inviter_global_id,
            inviter_tg_id,
        )
        return
    active_refs = await _count_active_referrals_global(
        db,
        inviter_global_id=inviter.global_id,
        legacy_tg_id=inviter.tg_id,
    )
    if active_refs <= 0:
        return

    for cfg in REF_LEVELS:
        if active_refs < cfg.required_active:
            continue
        canonical_key = (
            f"REF_LVL:G{inviter.global_id:010d}:{cfg.level}"
        )
        legacy_key = (
            f"REF_LVL:{inviter.tg_id}:{cfg.level}"
            if inviter.tg_id is not None
            else None
        )
        key = await choose_compatible_idempotency_key(
            db,
            canonical_key=canonical_key,
            legacy_key=legacy_key,
        )
        result = await credit_user_bonus_from_bank_nocommit(
            db=db,
            global_id=inviter.global_id,
            amount=cfg.bonus,
            reason="referral_level_bonus",
            idempotency_key=key.selected,
            meta={
                "inviter_global_id": inviter.global_id,
                "inviter_tg": inviter.tg_id,
                "level": cfg.level,
                "required_active": cfg.required_active,
                "active_refs": active_refs,
                "canonical_idempotency_key": canonical_key,
                "legacy_idempotency_key": legacy_key,
            },
        )
        duplicate = str(getattr(result, "detail", "ok")).startswith(
            "idempotent"
        )
        logger.info(
            "%s inviter_global_id=%s level=%s idempotency_key=%s",
            (
                "referral_bonus_duplicate_skipped"
                if duplicate
                else "referral_level_bonus_awarded"
            ),
            inviter.global_id,
            cfg.level,
            key.selected,
        )


# ----------------------------------------------------------------------
# Подсчёт total/active рефералов и ранговая логика
# ----------------------------------------------------------------------


async def _count_total_referrals(
    db: AsyncSession,
    inviter_tg_id: int,
) -> int:
    """Возвращает общее число рефералов (по ссылке)."""
    row = await db.execute(
        text("""
            SELECT COUNT(*)
            FROM efhc_core.referral_links
            WHERE inviter_tg_id = :tg
            """),
        {"tg": int(inviter_tg_id)},
    )
    val = row.scalar() or 0
    return int(val)


async def _count_active_referrals(
    db: AsyncSession,
    inviter_tg_id: int,
) -> int:
    """Return direct referrals with the permanent Activ flag set.

    ``referral_links.activated_at`` is the only status source. Current
    panel rows are intentionally irrelevant after first activation.
    """
    result = await db.execute(
        text("""
            SELECT COUNT(*)
            FROM efhc_core.referral_links rl
            WHERE rl.inviter_tg_id = :inviter_tg
              AND rl.activated_at IS NOT NULL
            """),
        {"inviter_tg": int(inviter_tg_id)},
    )
    value = int(result.scalar() or 0)
    logger.info(
        "referral_active_count_calculated inviter_tg_id=%s active=%s",
        int(inviter_tg_id),
        value,
    )
    return value


def _compute_level_and_progress(
    active_refs: int,
) -> tuple[int, int, int | None, int | None, int, float]:
    """
    Возвращает:
      level, current_min, next_level, next_min, refs_to_next,
      progress(0..1)
    Логика:
      • Уровень 0 — до достижения первой ступени (10 активных).
      • Для уровней 1–5 используется граница
        REF_LEVELS.required_active.
      • progress считает путь от текущего уровня к следующему.
    """
    if active_refs < 0:
        active_refs = 0

    if not REF_LEVELS:
        return 0, 0, None, None, 0, 0.0

    current_level = 0
    current_min = 0
    for cfg in REF_LEVELS:
        if active_refs >= cfg.required_active:
            current_level = cfg.level
            current_min = cfg.required_active
        else:
            break

    next_cfg: ReferralLevelConfig | None = None
    for cfg in REF_LEVELS:
        if cfg.required_active > active_refs:
            next_cfg = cfg
            break

    if not next_cfg:
        # достигнут максимум (5 уровень)
        return current_level, current_min, None, None, 0, 1.0

    next_level = next_cfg.level
    next_min = next_cfg.required_active
    refs_to_next = max(0, next_min - active_refs)

    span = max(1, next_min - current_min)
    done = max(0, active_refs - current_min)
    progress = float(done) / float(span)
    if progress < 0.0:
        progress = 0.0
    if progress > 1.0:
        progress = 1.0

    return (
        current_level,
        current_min,
        next_level,
        next_min,
        refs_to_next,
        progress,
    )


# ----------------------------------------------------------------------
# Реферальный код и ссылка (постоянные)
# ----------------------------------------------------------------------


async def ensure_referral_codes_table(db: AsyncSession) -> None:
    """Канон: таблица referral_codes из 0001 (ORM-only).


    Сервис не выполняет DDL. Функция оставлена как «мягкий» якорь
    обратной совместимости для существующих вызовов.
    """
    return


async def get_or_create_referral_code(
    db: AsyncSession,
    inviter_tg_id: int | None = None,
    *,
    inviter_global_id: int | None = None,
) -> str:
    """Вернуть стабильный code canonical owner с legacy входом."""

    from app.models.referral_codes_models import ReferralCode

    if inviter_global_id is None:
        if inviter_tg_id is None:
            raise ValueError("owner selector is required")
        owner_row = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(User.tg_id == int(inviter_tg_id))
                .limit(1)
            )
        ).first()
    else:
        owner_row = (
            await db.execute(
                select(User.global_id, User.tg_id)
                .where(User.global_id == int(inviter_global_id))
                .limit(1)
            )
        ).first()
    if owner_row is None or owner_row[0] is None:
        raise ValueError("referral owner not found")
    gid = int(owner_row[0])
    legacy_tg = (
        int(owner_row[1]) if owner_row[1] is not None else None
    )

    row = await db.execute(
        select(ReferralCode.code)
        .where(ReferralCode.inviter_global_id == gid)
        .limit(1)
    )
    code = row.scalar()
    if code:
        return str(code)

    for _ in range(10):
        code = _generate_referral_code()
        try:
            db.add(
                ReferralCode(
                    code=str(code),
                    inviter_global_id=gid,
                    inviter_tg_id=legacy_tg,
                )
            )
            await db.commit()
            return str(code)
        except Exception:
            await db.rollback()
            existing = (
                await db.execute(
                    select(ReferralCode.code)
                    .where(ReferralCode.inviter_global_id == gid)
                    .limit(1)
                )
            ).scalar()
            if existing:
                return str(existing)

    raise RuntimeError("failed_to_generate_referral_code")


async def _ensure_user_exists_by_tg(
    db: AsyncSession,
    tg_id: int,
) -> int | None:
    """Проверить существование пользователя по tg_id."""
    row = await db.execute(
        text("""
            SELECT tg_id
            FROM efhc_core.users
            WHERE tg_id = :tg
            LIMIT 1
            """),
        {"tg": int(tg_id)},
    )
    rec = row.fetchone()
    if not rec:
        return None
    return int(rec[0])


# ======================================================================
# Пояснения «для чайника»:
# ----------------------------------------------------------------------
# • Бонусы только за АКТИВНЫХ рефералов:
# Регистрация по ссылке ничего не даёт финансово.
# Бонусы начинаются только после первой активации панели рефералом
# (on_user_first_panel_activation).
#
# • 0.1 EFHCb:
# За первую панель каждого прямого реферала inviter получает 0.1 EFHCb
# на bonus-баланс,
# но только для первых 10 000 активных рефералов. Лимит задаётся
# REF_MAX_ACTIVE_FOR_UNIT_BONUS.
#
# • Уровни 1–5:
# Считаются по ЧИСЛУ АКТИВНЫХ прямых рефералов. При первом достижении
# порогов 10 / 100 / 1000 / 3000 / 10000 начисляются разовые награды
# 1 / 10 / 100 / 300 / 1000 EFHCb соответственно.
#
# • Прогресс-бар:
# get_referral_stats(...) отдаёт:
# level (0–5), next_level, refs_to_next и progress (0.0–1.0),
# чтобы фронтенд мог показать шкалу от текущего уровня к следующему.
#
# • Реферальная ссылка:
# get_referral_stats(...) также даёт referral_code и referral_link.
# Формат ссылки: https://t.me/<BOT_USERNAME>?start=ref_<code>.
#
# • Идемпотентность:
# Все денежные операции используют жёсткие Idempotency-Key:
# - "REF_ACT_UNIT:G<buyer_global_id>" — однократные 0.1 EFHCb за первую
#   панель прямого реферала;
# - "REF_LVL:G<inviter_global_id>:<level>" — разовая награда за уровень.
# Повторные вызовы безопасны — банк не создаст дубль записи.
# ======================================================================

__all__ = [
    # Списки для фронтенда
    "ReferralItem",
    "CursorTuple",
    "svc_list_referrals_active",
    "svc_list_referrals_inactive",
    # Триггеры
    "on_user_first_panel_activation",
    # Статистика / ссылка
    "ReferralStats",
    "get_referral_stats",
    "get_or_create_referral_code",
    "build_referral_link",
    "resolve_referral_code",
    "onboard_user_at_first_creation",
    "ReferralOnboardingResult",
    "ReferralOnboardingRejected",
    "ReferralPageStats",
    "get_referrals_page_stats",
]


# ----------------------------------------------------------------------
# Admin API (используется backend/app/routes/admin_referral_routes.py)
# Канон:
# - LEGACY runtime: global_id используется до перехода рефералов.
#   Целевой owner key — канонический global_id.
# - таблицы только ORM (efhc_core.referral_links,
# efhc_core.referral_bonus_ledger, efhc_core.users).
# - любые записи должны быть явно детерминированы и проверяемы.
# ----------------------------------------------------------------------

async def admin_summary(
    db: AsyncSession,
    *,
    limit: int = 50,
    after: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Агрегированная сводка по инвайтерам (cursor-based).

    Курсор: {"after_inviter_tg_id": <int>}
    """
    lim = max(1, min(200, int(limit)))
    after_id: int | None = None
    if after:
        try:
            raw = after.get("after_inviter_tg_id")
            after_id = int(raw) if raw is not None else None
        except Exception:
            after_id = None

    # Группируем по inviter_global_id
    stmt = (
        select(
            ReferralLink.inviter_global_id.label("inviter_global_id"),
            ReferralLink.inviter_tg_id.label("inviter_tg_id"),
            func.count()
            .filter(ReferralLink.activated_at.isnot(None))
            .label("active_count"),
            func.count()
            .filter(ReferralLink.activated_at.is_(None))
            .label("inactive_count"),
            func.max(ReferralLink.created_at).label("last_invited_at"),
        )
        .group_by(
            ReferralLink.inviter_global_id,
            ReferralLink.inviter_tg_id,
        )
        .order_by(ReferralLink.inviter_tg_id.asc())
        .limit(lim)
    )
    if after_id is not None:
        stmt = stmt.where(ReferralLink.inviter_tg_id > after_id)

    rows = (await db.execute(stmt)).mappings().all()

    items: list[dict[str, Any]] = []
    last_inviter: int | None = None

    for r in rows:
        inviter_tg_id = int(r["inviter_tg_id"])
        inviter_global_id = (
            int(r["inviter_global_id"])
            if r["inviter_global_id"] is not None
            else None
        )
        last_inviter = inviter_tg_id

        owner_clause = (
            EfhcTransferLog.global_id == inviter_global_id
            if inviter_global_id is not None
            else EfhcTransferLog.tg_id == inviter_tg_id
        )
        # Сумма прямых и уровневых referral-бонусов.
        sum_stmt = select(
            func.coalesce(func.sum(EfhcTransferLog.amount), 0)
        ).where(
            owner_clause,
            EfhcTransferLog.direction == "credit",
            EfhcTransferLog.balance_type == "bonus",
            EfhcTransferLog.reason.in_(
                [
                    "referral_active_unit",
                    "referral_level_bonus",
                ]
            ),
        )
        total_bonus = (await db.execute(sum_stmt)).scalar() or 0

        items.append(
            {
                "inviter_global_id": inviter_global_id,
                "inviter_tg_id": inviter_tg_id,
                "active_count": int(r["active_count"] or 0),
                "inactive_count": int(r["inactive_count"] or 0),
                "total_bonus_efhc": str(d8(total_bonus)),
                "last_invited_at": (
                    r["last_invited_at"].isoformat()
                    if r["last_invited_at"]
                    else None
                ),
            }
        )

    next_after = None
    if rows and len(rows) == lim and last_inviter is not None:
        next_after = {"after_inviter_tg_id": last_inviter}

    return {"items": items, "next_after": next_after}

# ----------------------------------------------------------------------
# Цикл 1625: provider-neutral non-financial read switch
# ----------------------------------------------------------------------

SQL_LIST_REFERRALS_GLOBAL = """
WITH ref AS (
    SELECT
        rl.invitee_global_id AS ref_global,
        rl.created_at AS invited_at,
        rl.activated_at AS activated_at
    FROM efhc_core.referral_links rl
    WHERE rl.inviter_global_id = :inviter_global_id
),
panel_counts AS (
    SELECT
        p.global_id,
        COUNT(p.id)::BIGINT AS panels_count
    FROM efhc_core.panels p
    INNER JOIN ref
        ON ref.ref_global = p.global_id
    GROUP BY p.global_id
)
SELECT
    u.tg_id AS child_tg_id,
    u.tg_id AS tg_id,
    u.username AS username,
    u.created_at AS joined_at,
    (ref.activated_at IS NOT NULL) AS is_active,
    COALESCE(u.total_generated_kwh, 0) AS total_generated_kwh,
    COALESCE(pc.panels_count, 0) AS panels_count,
    ref.invited_at AS invited_at,
    ref.activated_at AS activated_at
FROM ref
INNER JOIN efhc_core.users u
    ON u.global_id = ref.ref_global
LEFT JOIN panel_counts pc
    ON pc.global_id = ref.ref_global
WHERE (
    (
        CAST(:cursor_ts AS TIMESTAMPTZ) IS NULL
        AND CAST(:cursor_id AS BIGINT) IS NULL
    )
    OR (
        (ref.invited_at, u.tg_id)
        < (
            CAST(:cursor_ts AS TIMESTAMPTZ),
            CAST(:cursor_id AS BIGINT)
        )
    )
)
AND (
    (
        CAST(:want_active AS BOOLEAN) = TRUE
        AND ref.activated_at IS NOT NULL
    )
    OR (
        CAST(:want_active AS BOOLEAN) = FALSE
        AND ref.activated_at IS NULL
    )
)
AND u.tg_id IS NOT NULL
ORDER BY
    ref.invited_at DESC,
    u.tg_id DESC
LIMIT CAST(:fetch_limit AS INTEGER)
"""


async def _svc_list_referrals_global(
    db: AsyncSession,
    *,
    inviter_global_id: int,
    limit: int,
    cursor: CursorTuple | None,
    want_active: bool,
) -> tuple[list[ReferralItem], CursorTuple | None]:
    """Читать referral ownership по ``global_id`` shadow columns."""

    safe_limit = max(1, min(int(limit), 200))
    cur_ts, cur_id = _normalize_cursor(cursor)
    rows = await db.execute(
        text(SQL_LIST_REFERRALS_GLOBAL),
        {
            "inviter_global_id": int(inviter_global_id),
            "cursor_ts": cur_ts,
            "cursor_id": cur_id,
            "want_active": bool(want_active),
            "fetch_limit": safe_limit + 1,
        },
    )
    fetched = rows.fetchall()
    has_more = len(fetched) > safe_limit
    page_rows = fetched[:safe_limit]
    items = [
        ReferralItem(
            child_tg_id=int(row[0]),
            global_id=int(row[1]),
            username=(str(row[2]) if row[2] is not None else None),
            joined_at=row[3],
            is_active=bool(row[4]),
            total_generated_kwh=Decimal(str(row[5])),
            panels_count=int(row[6]),
            invited_at=row[7],
            activated_at=row[8],
        )
        for row in page_rows
    ]
    next_cursor = _next_cursor(items) if has_more else None
    return items, next_cursor


async def list_active_referrals_global(
    db: AsyncSession,
    *,
    parent_global_id: int,
    limit: int = 100,
    cursor: str | None = None,
) -> ReferralsPage:
    cur = _parse_cursor_str(cursor)
    items, next_cur = await _svc_list_referrals_global(
        db,
        inviter_global_id=int(parent_global_id),
        limit=int(limit),
        cursor=cur,
        want_active=True,
    )
    return ReferralsPage(
        items=items,
        next_cursor=_format_cursor(next_cur),
    )


async def list_inactive_referrals_global(
    db: AsyncSession,
    *,
    parent_global_id: int,
    limit: int = 100,
    cursor: str | None = None,
) -> ReferralsPage:
    cur = _parse_cursor_str(cursor)
    items, next_cur = await _svc_list_referrals_global(
        db,
        inviter_global_id=int(parent_global_id),
        limit=int(limit),
        cursor=cur,
        want_active=False,
    )
    return ReferralsPage(
        items=items,
        next_cursor=_format_cursor(next_cur),
    )


async def _count_total_referrals_global(
    db: AsyncSession,
    inviter_global_id: int,
) -> int:
    result = await db.execute(
        text(
            """
            SELECT COUNT(*)
            FROM efhc_core.referral_links
            WHERE inviter_global_id = :global_id
            """
        ),
        {"global_id": int(inviter_global_id)},
    )
    return int(result.scalar() or 0)


async def _count_active_referrals_global(
    db: AsyncSession,
    inviter_global_id: int,
    legacy_tg_id: int | None = None,
) -> int:
    """Считать Activ по global owner с read-through старых строк."""
    result = await db.execute(
        text(
            """
            SELECT COUNT(*)
            FROM efhc_core.referral_links
            WHERE (
                    inviter_global_id = :global_id
                    OR (
                        inviter_global_id IS NULL
                        AND CAST(:legacy_tg_id AS BIGINT) IS NOT NULL
                        AND inviter_tg_id = CAST(
                            :legacy_tg_id AS BIGINT
                        )
                    )
                  )
              AND activated_at IS NOT NULL
            """
        ),
        {
            "global_id": int(inviter_global_id),
            "legacy_tg_id": (
                int(legacy_tg_id)
                if legacy_tg_id is not None
                else None
            ),
        },
    )
    return int(result.scalar() or 0)


async def get_counters_global(
    db: AsyncSession,
    *,
    parent_global_id: int,
) -> ReferralCounters:
    total = await _count_total_referrals_global(
        db,
        inviter_global_id=int(parent_global_id),
    )
    active = await _count_active_referrals_global(
        db,
        inviter_global_id=int(parent_global_id),
    )
    return ReferralCounters(
        total=total,
        active=active,
        inactive=max(total - active, 0),
    )


async def get_referral_stats_global(
    db: AsyncSession,
    *,
    inviter_global_id: int,
    legacy_tg_id: int | None = None,
) -> ReferralStats:
    """Non-financial counters читаются по global owner.

    Создание referral-code остаётся legacy-compatible
    до полного API switch.
    """

    total_refs = await _count_total_referrals_global(
        db,
        inviter_global_id=int(inviter_global_id),
    )
    active_refs = await _count_active_referrals_global(
        db,
        inviter_global_id=int(inviter_global_id),
    )
    (
        level,
        current_min,
        next_level,
        next_min,
        refs_to_next,
        progress,
    ) = _compute_level_and_progress(active_refs)
    code = await get_or_create_referral_code(
        db,
        inviter_global_id=int(inviter_global_id),
    )
    link = build_referral_link(code) if code and BOT_USERNAME else None
    return ReferralStats(
        inviter_tg_id=(
            int(legacy_tg_id) if legacy_tg_id is not None else None
        ),
        total_referrals=total_refs,
        active_referrals=active_refs,
        level=level,
        next_level=next_level,
        current_level_min=current_min,
        next_level_min=next_min,
        refs_to_next=refs_to_next,
        progress=progress,
        referral_code=code,
        referral_link=link,
    )


async def get_referrals_page_stats_global(
    db: AsyncSession,
    *,
    inviter_global_id: int,
    legacy_tg_id: int | None = None,
) -> ReferralPageStats:
    """Переключить non-financial referral reads.

    Financial seam сохраняется. bonus_balance и referral transfer
    history до циклов 1626-1627 остаются legacy-read по ``tg_id``.
    Это намеренно не является financial read switch.
    """

    base = await get_referral_stats_global(
        db,
        inviter_global_id=int(inviter_global_id),
        legacy_tg_id=legacy_tg_id,
    )
    bonus_balance = await _get_user_bonus_balance(
        db,
        inviter_global_id=int(inviter_global_id),
    )
    bonuses_total = await _sum_referrals_bonus_total(
        db,
        inviter_global_id=int(inviter_global_id),
    )
    inactive_refs = max(0, base.total_referrals - base.active_referrals)
    level_steps = get_referral_level_steps()
    full_cycle = level_steps[-1]
    return ReferralPageStats(
        inviter_tg_id=(
            int(legacy_tg_id) if legacy_tg_id is not None else None
        ),
        bonus_balance=bonus_balance,
        referrals_bonus_total=bonuses_total,
        total_referrals=int(base.total_referrals),
        active_referrals=int(base.active_referrals),
        inactive_referrals=int(inactive_refs),
        level=int(base.level),
        current_level_min=int(base.current_level_min),
        next_level=base.next_level,
        next_level_min=base.next_level_min,
        refs_to_next=int(base.refs_to_next),
        progress=float(base.progress),
        unit_bonus_per_active=REF_BONUS_PER_ACTIVE_UNIT,
        max_active_for_unit_bonus=REF_MAX_ACTIVE_FOR_UNIT_BONUS,
        bonus_asset=REFERRAL_BONUS_ASSET,
        full_cycle_direct_bonus=full_cycle.direct_bonus_total,
        full_cycle_level_bonus=full_cycle.cumulative_level_bonus,
        full_cycle_total_bonus=full_cycle.cumulative_total_reward,
        level_steps=level_steps,
        referral_code=str(base.referral_code),
        referral_link=base.referral_link,
    )
