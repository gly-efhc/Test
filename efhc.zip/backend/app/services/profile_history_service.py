"""Единая глобально упорядоченная история профиля с keyset-пагинацией."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Final

from app.utils.cursor_codec import decode_cursor, encode_cursor
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

PROFILE_HISTORY_PAGE_SIZE: Final[int] = 50
PROFILE_HISTORY_EXPORT_BATCH_SIZE: Final[int] = 500


@dataclass(frozen=True, slots=True)
class ProfileHistoryRecord:
    """Нормализованная логическая операция из разнородных источников."""

    id: int
    source: str
    kind: str
    occurred_at: datetime
    status: str | None
    direction: str | None
    balance_type: str | None
    amount_efhc: str | None
    amount_asset: str | None
    asset: str | None
    reason: str | None
    source_rank: int


@dataclass(frozen=True, slots=True)
class ProfileHistoryPage:
    """Одна keyset-страница общего порядка."""

    items: tuple[ProfileHistoryRecord, ...]
    next_cursor: str | None


def _parse_cursor(cursor: str | None) -> tuple[datetime, int, int] | None:
    if not cursor:
        return None
    payload = decode_cursor(cursor)
    try:
        ts = datetime.fromisoformat(str(payload["ts"]))
        rank = int(payload["rank"])
        source_id = int(payload["id"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("PROFILE_HISTORY_CURSOR_INVALID") from exc
    if ts.tzinfo is None or ts.utcoffset() is None:
        raise ValueError("PROFILE_HISTORY_CURSOR_INVALID")
    return ts.astimezone(UTC), rank, source_id


def _make_cursor(record: ProfileHistoryRecord) -> str:
    return str(
        encode_cursor(
            {
                "ts": record.occurred_at.astimezone(UTC).isoformat(),
                "rank": int(record.source_rank),
                "id": int(record.id),
            }
        )
    )


async def list_profile_history_page(
    db: AsyncSession,
    *,
    global_id: int,
    cursor: str | None = None,
    page_size: int = PROFILE_HISTORY_PAGE_SIZE,
) -> ProfileHistoryPage:
    """Вернуть единую страницу без схемы 50+50+50."""

    limit = int(page_size)
    if limit < 1 or limit > PROFILE_HISTORY_EXPORT_BATCH_SIZE:
        raise ValueError("PROFILE_HISTORY_PAGE_SIZE_INVALID")
    parsed = _parse_cursor(cursor)
    cursor_ts = parsed[0] if parsed else None
    cursor_rank = parsed[1] if parsed else None
    cursor_id = parsed[2] if parsed else None

    query = text(
        """
        WITH unified AS (
            SELECT
                t.id AS source_id,
                50::integer AS source_rank,
                'ledger'::text AS source,
                CASE
                    WHEN t.reason = 'exchange_kwh_to_efhc'
                    THEN 'exchange'
                    ELSE 'balance_transfer'
                END::text AS kind,
                t.created_at AS occurred_at,
                NULL::text AS status,
                t.direction::text AS direction,
                t.balance_type::text AS balance_type,
                t.amount::text AS amount_efhc,
                NULL::text AS amount_asset,
                CASE
                    WHEN t.balance_type = 'bonus' THEN 'EFHCb'
                    ELSE 'EFHCm'
                END::text AS asset,
                t.reason::text AS reason
            FROM efhc_core.efhc_transfers_log t
            WHERE t.global_id = :global_id
              AND t.reason NOT IN (
                  'withdraw_hold',
                  'withdraw_refund',
                  'withdraw_reject_refund'
              )

            UNION ALL

            SELECT
                w.id,
                40::integer,
                'withdraw_request'::text,
                'withdraw_request'::text,
                w.created_at,
                w.status::text,
                NULL::text,
                'main'::text,
                w.amount::text,
                NULL::text,
                'EFHCm'::text,
                'withdraw_request'::text
            FROM efhc_core.withdraw_requests w
            WHERE w.global_id = :global_id

        )
        SELECT
            source_id,
            source_rank,
            source,
            kind,
            occurred_at,
            status,
            direction,
            balance_type,
            amount_efhc,
            amount_asset,
            asset,
            reason
        FROM unified
        WHERE (
            CAST(:cursor_ts AS timestamptz) IS NULL
            OR occurred_at < CAST(:cursor_ts AS timestamptz)
            OR (
                occurred_at = CAST(:cursor_ts AS timestamptz)
                AND source_rank < CAST(:cursor_rank AS integer)
            )
            OR (
                occurred_at = CAST(:cursor_ts AS timestamptz)
                AND source_rank = CAST(:cursor_rank AS integer)
                AND source_id < CAST(:cursor_id AS bigint)
            )
        )
        ORDER BY occurred_at DESC, source_rank DESC, source_id DESC
        LIMIT :limit_plus_one
        """
    )
    rows = (
        await db.execute(
            query,
            {
                "global_id": int(global_id),
                "cursor_ts": cursor_ts,
                "cursor_rank": cursor_rank,
                "cursor_id": cursor_id,
                "limit_plus_one": limit + 1,
            },
        )
    ).all()
    has_more = len(rows) > limit
    selected = rows[:limit]
    records: list[ProfileHistoryRecord] = []
    for row in selected:
        occurred_at = row[4]
        if not isinstance(occurred_at, datetime):
            raise RuntimeError("PROFILE_HISTORY_TIMESTAMP_INVALID")
        records.append(
            ProfileHistoryRecord(
                id=int(row[0]),
                source_rank=int(row[1]),
                source=str(row[2]),
                kind=str(row[3]),
                occurred_at=occurred_at.astimezone(UTC),
                status=str(row[5]) if row[5] is not None else None,
                direction=str(row[6]) if row[6] is not None else None,
                balance_type=(
                    str(row[7]) if row[7] is not None else None
                ),
                amount_efhc=(
                    str(row[8]) if row[8] is not None else None
                ),
                amount_asset=(
                    str(row[9]) if row[9] is not None else None
                ),
                asset=str(row[10]) if row[10] is not None else None,
                reason=str(row[11]) if row[11] is not None else None,
            )
        )
    next_cursor = _make_cursor(records[-1]) if has_more and records else None
    return ProfileHistoryPage(items=tuple(records), next_cursor=next_cursor)


__all__ = [
    "PROFILE_HISTORY_EXPORT_BATCH_SIZE",
    "PROFILE_HISTORY_PAGE_SIZE",
    "ProfileHistoryPage",
    "ProfileHistoryRecord",
    "list_profile_history_page",
]
