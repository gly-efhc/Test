# -*- coding: utf-8 -*-
# backend/app/services/__init__.py
# ======================================================================
# EFHC Bot — сервисный слой (единая точка входа)
# ----------------------------------------------------------------------
# Назначение файла:
# • Дать единый, стабильный вход для доменных сервисов EFHC Bot.
# • Явно зафиксировать «канонический» набор сервисов, чтобы роуты/
# воркеры
# не бегали по отдельным файлам.
# • Предоставить лёгкие ИИ-обёртки:
# - агрегированный health-snapshot по ключевым сервисам,
# - глобальный ensure_consistency() для фоновых задач (банк/обмен/
# вывод).
#
# Важные принципы:
# • Никакой бизнес-логики здесь нет — только импорты и тонкие прокси.
# • Никаких сторонних HTTP-запросов/блокирующих операций на уровне
# импорта.
# • Все тяжёлые операции (генерация, обмен, вывод, банк) реализованы
# в отдельных модулях и сюда только импортируются.
# ======================================================================

from __future__ import annotations

from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging_core import get_logger

# Базовые сервисы домена
from .energy_service import (
    generate_energy_tick,
    generate_energy_for_user,
    backfill_all as energy_backfill_all,
)
from .exchange_service import (
    preview_exchange,
    request_exchange,
    max_exchangeable_kwh,
    user_balances_brief,
    health_snapshot as exchange_health_snapshot,
    ExchangeError,
    ExchangeValidationError,
    ExchangeDirectionForbidden,
    ExchangeInsufficientEnergy,
    ExchangeIdempotencyRequired,
)
from .withdraw_service import (
    request_withdraw,
    cancel_withdraw,
    approve_withdraw_request,
    reject_withdraw_request,
    cancel_withdraw_request,
    admin_approve_withdraw,
    admin_reject_withdraw,
    admin_mark_paid,
    list_user_withdraws,
    ensure_consistency as withdraw_ensure_consistency,
)
from .transactions_service import (
    credit_user_from_bank,
    credit_user_bonus_from_bank,
    debit_user_to_bank,
    debit_user_bonus_to_bank,
    exchange_kwh_to_efhc,
)

# Админ-подсистема (фасад и подмодули)
from .admin.admin_facade import AdminService
from .admin.admin_rbac import (
    AdminRole,
    AdminUser,
    AdminAuthError,
)
from .admin.admin_logging import (
    AdminLog,
    AdminLogger,
)

# Wallet bindings (TonConnect)
from . import wallets_service
from .admin.admin_settings import (
    SettingsService,
    SystemSetting,
)
from .admin.admin_notifications import (
    AdminNotification,
    AdminNotifier,
)
from .admin.admin_bank_service import AdminBankService
from .admin.admin_lotteries_service import AdminLotteriesService
from .admin.admin_users_service import AdminUsersService
from .admin.admin_panels_service import AdminPanelsService
from .admin.admin_referral_service import AdminReferralService
from .admin.admin_wallets_service import AdminWalletsService
from .admin.admin_stats_service import AdminStatsService

logger = get_logger(__name__)

# ======================================================================
# Глобальные ИИ-утилиты: health-сводка и ensure_consistency
# для фоновых задач
# ======================================================================

async def services_health_snapshot(db: AsyncSession) -> dict[str, Any]:
    """
    Лёгкий агрегированный health-snapshot по основным сервисам.

    Задача:
      • не падать из-за ошибок одного сервиса;
      • дать админ-панели/мониторингу единый JSON со статусом ядра.

    Сейчас включает:
      • состояние обменника (kWh→EFHC);
      • суммарную доступную энергию в системе.

    При необходимости можно расширять (энергия, банк, выводы и т.д.),
    но только через лёгкие read-only запросы.
    """
    out: dict[str, Any] = {
        "exchange": None,
        "errors": [],
    }

    # Обменник (kWh→EFHC)
    try:
        out["exchange"] = await exchange_health_snapshot(db)
    except Exception as e:
        logger.warning(
            "services_health_snapshot: exchange_health failed: %s",
            e,
        )
        out["errors"].append({"component": "exchange", "error": str(e)})

    return out

async def ensure_global_consistency(
    db: AsyncSession,
    *,
    scan_minutes: int = 240,
    batch_limit: int = 200,
) -> dict[str, Any]:
    """
    Глобальная «ИИ-самовосстановление» по сервисам:

      • withdraw_ensure_consistency:
          - подтягивает висящие холды/рефанды по заявкам на вывод EFHC;

    Принципы:
      • Любая ошибка локализуется в своём блоке и только логируется.
      • Возвращаем отчёт по каждому под-сервису, чтобы админ-панель
        могла подсветить проблемные подсистемы.
    """
    result: dict[str, Any] = {
        "withdraw": None,
        "errors": [],
    }

    # 1) Консистентность заявок на вывод EFHC
    try:
        result["withdraw"] = await withdraw_ensure_consistency(
            db,
            scan_minutes=scan_minutes,
            batch_limit=batch_limit,
        )
    except Exception as e:
        logger.warning(
            "ensure_global_consistency: withdraw.ensure_consistency "
            "failed: %s",
            e,
        )
        result["errors"].append(
            {"component": "withdraw", "error": str(e)}
        )

    return result


# ======================================================================
# Экспортируемый интерфейс пакета app.services
# ======================================================================

__all__ = [
    # --- energy_service ---
    "generate_energy_tick",
    "generate_energy_for_user",
    "energy_backfill_all",
    # --- exchange_service ---
    "preview_exchange",
    "request_exchange",
    "max_exchangeable_kwh",
    "user_balances_brief",
    "ExchangeError",
    "ExchangeValidationError",
    "ExchangeDirectionForbidden",
    "ExchangeInsufficientEnergy",
    "ExchangeIdempotencyRequired",
    # --- withdraw_service ---
    "request_withdraw",
    "cancel_withdraw",
    "approve_withdraw_request",
    "reject_withdraw_request",
    "cancel_withdraw_request",
    "admin_approve_withdraw",
    "admin_reject_withdraw",
    "admin_mark_paid",
    "list_user_withdraws",
    "withdraw_ensure_consistency",
    # --- transactions_service ---
    "credit_user_from_bank",
    "credit_user_bonus_from_bank",
    "debit_user_to_bank",
    "debit_user_bonus_to_bank",
    "exchange_kwh_to_efhc",
    # --- admin facade ---
    "AdminService",
    # --- admin core modules ---
    "AdminRole",
    "AdminUser",
    "AdminAuthError",
    "AdminLog",
    "AdminLogger",
    "SettingsService",
    "SystemSetting",
    "AdminNotification",
    "AdminNotifier",
    "AdminBankService",
    "AdminLotteriesService",
    "AdminUsersService",
    "AdminPanelsService",
    "AdminReferralService",
    "AdminWalletsService",
    "AdminStatsService",
    # --- global helpers ---
    "services_health_snapshot",
    "ensure_global_consistency",
]


from . import skins_service
