"""Основа безопасного финансового retention до физического partitioning.

Модуль не выполняет DDL и не удаляет строки. Он фиксирует owner-approved
границы времени, набор шести history-таблиц, UTC-месячные окна
и fail-closed классификацию terminal/non-terminal состояний.
Физический PARTITION/DROP
подключается только отдельным этапом после exact-head CI этой основы.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

FINANCIAL_EXECUTION_DAYS = 180
FINANCIAL_HISTORY_RETAINED_MONTHS = 13

APPROVED_FINANCIAL_HISTORY_TABLES = (
    "efhc_transfers_log",
    "payment_intents",
    "shop_orders",
    "withdraw_requests",
    "withdraw_outcome_events",
    "ton_inbox_logs",
)


@dataclass(frozen=True, slots=True)
class FinancialPartitionPolicy:
    """Fail-closed policy одной owner-approved history-таблицы."""

    table: str
    partition_key: str
    terminal_statuses: frozenset[str]
    blocking_statuses: frozenset[str]
    depends_on: tuple[str, ...] = ()


PARTITION_POLICIES: dict[str, FinancialPartitionPolicy] = {
    "efhc_transfers_log": FinancialPartitionPolicy(
        table="efhc_transfers_log",
        partition_key="created_at",
        terminal_statuses=frozenset(),
        blocking_statuses=frozenset(),
    ),
    "payment_intents": FinancialPartitionPolicy(
        table="payment_intents",
        partition_key="created_at",
        terminal_statuses=frozenset(
            {"CONFIRMED", "EXPIRED", "CANCELED"}
        ),
        blocking_statuses=frozenset({"PENDING"}),
    ),
    "shop_orders": FinancialPartitionPolicy(
        table="shop_orders",
        partition_key="created_at",
        terminal_statuses=frozenset(
            {
                "PAID_AUTO",
                "APPROVED",
                "REJECTED",
                "CANCELED",
                "CANCELLED",
            }
        ),
        blocking_statuses=frozenset({"PENDING", "PAID_PENDING_MANUAL"}),
    ),
    "withdraw_requests": FinancialPartitionPolicy(
        table="withdraw_requests",
        partition_key="created_at",
        terminal_statuses=frozenset({"PAID", "REJECTED", "CANCELED"}),
        blocking_statuses=frozenset({"PENDING"}),
    ),
    "withdraw_outcome_events": FinancialPartitionPolicy(
        table="withdraw_outcome_events",
        partition_key="created_at",
        terminal_statuses=frozenset(),
        blocking_statuses=frozenset(),
        depends_on=("withdraw_requests",),
    ),
    "ton_inbox_logs": FinancialPartitionPolicy(
        table="ton_inbox_logs",
        partition_key="created_at",
        terminal_statuses=frozenset(
            {"credited", "paid_auto", "expired_no_credit"}
        ),
        blocking_statuses=frozenset(
            {
                "received",
                "parsed",
                "parsed_pending_mapping",
                "pending_manual",
                "paid_pending_manual",
                "error_bad_memo",
                "error_user_not_found",
                "error_network_retry",
                "error_retry",
            }
        ),
    ),
}


def require_utc(value: datetime) -> datetime:
    """Принять только timezone-aware UTC без неявной конвертации."""

    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("RETENTION_TIME_MUST_BE_AWARE_UTC")
    if value.utcoffset() != timedelta(0):
        raise ValueError("RETENTION_TIME_MUST_BE_UTC")
    return value


def month_start_utc(value: datetime) -> datetime:
    """Вернуть начало UTC-месяца для проверенного времени."""

    value = require_utc(value)
    return datetime(value.year, value.month, 1, tzinfo=UTC)


def shift_months(month_start: datetime, delta: int) -> datetime:
    """Сдвинуть начало UTC-месяца на целое число месяцев."""

    month_start = month_start_utc(month_start)
    absolute = month_start.year * 12 + (month_start.month - 1) + delta
    year, month_zero = divmod(absolute, 12)
    return datetime(year, month_zero + 1, 1, tzinfo=UTC)


def retained_month_starts(now: datetime) -> tuple[datetime, ...]:
    """Вернуть current month + 12 previous в возрастающем порядке."""

    current = month_start_utc(now)
    oldest = shift_months(
        current,
        -(FINANCIAL_HISTORY_RETAINED_MONTHS - 1),
    )
    return tuple(
        shift_months(oldest, offset)
        for offset in range(FINANCIAL_HISTORY_RETAINED_MONTHS)
    )


def oldest_retained_month_start(now: datetime) -> datetime:
    """Вернуть начало самого старого сохраняемого месяца."""

    return retained_month_starts(now)[0]


def partition_bounds(
    month_start: datetime,
) -> tuple[datetime, datetime]:
    """Вернуть полуинтервал RANGE partition: [month, next_month)."""

    start = month_start_utc(month_start)
    return start, shift_months(start, 1)


def partition_name(table: str, month_start: datetime) -> str:
    """Построить детерминированное имя monthly partition."""

    if table not in PARTITION_POLICIES:
        raise ValueError("RETENTION_TABLE_NOT_APPROVED")
    start = month_start_utc(month_start)
    return f"{table}_{start.year:04d}_{start.month:02d}"


def month_is_outside_history_retention(
    month_start: datetime,
    *,
    now: datetime,
) -> bool:
    """Проверить, вышел ли целый месяц за current+previous-12 окно."""

    start = month_start_utc(month_start)
    return start < oldest_retained_month_start(now)


def droppable_months(
    partition_months: Sequence[datetime],
    *,
    now: datetime,
) -> tuple[datetime, ...]:
    """Вернуть календарно старые месяцы до state guard."""

    require_utc(now)
    return tuple(
        sorted(
            {
                month_start_utc(value)
                for value in partition_months
                if month_is_outside_history_retention(value, now=now)
            }
        )
    )


def tx_hash_cleanup_cutoff(now: datetime) -> datetime:
    """Вернуть строгую границу cleanup: age >= 180 суток."""

    return require_utc(now) - timedelta(days=FINANCIAL_EXECUTION_DAYS)


def tx_hash_cleanup_eligible(
    trusted_operation_at: datetime,
    *,
    now: datetime,
) -> bool:
    """Разрешить cleanup marker только при trusted age >= 180 суток."""

    trusted = require_utc(trusted_operation_at)
    cutoff = tx_hash_cleanup_cutoff(now)
    return trusted <= cutoff


def row_is_terminal_for_drop(
    table: str,
    row: Mapping[str, object],
) -> bool:
    """Fail-closed проверить строку перед будущим DROP partition."""

    if table not in PARTITION_POLICIES:
        return False
    if table == "efhc_transfers_log":
        return True
    if table == "withdraw_outcome_events":
        return row.get("parent_withdraw_terminal") is True

    status_raw = row.get("status")
    if not isinstance(status_raw, str) or not status_raw:
        return False

    if table == "ton_inbox_logs":
        status = status_raw.lower()
    else:
        status = status_raw.upper()

    policy = PARTITION_POLICIES[table]
    if status not in policy.terminal_statuses:
        return False

    if table == "withdraw_requests":
        hold_done = row.get("hold_done") is True
        refund_done = row.get("refund_done") is True
        if status == "PAID":
            return row.get("processed_at") is not None
        if status in {"REJECTED", "CANCELED"}:
            return (not hold_done) or refund_done
        return False

    return True


def month_state_allows_drop(
    table: str,
    rows: Sequence[Mapping[str, object]],
) -> bool:
    """Разрешить DROP только когда каждая строка terminal-safe."""

    if table not in PARTITION_POLICIES:
        return False
    return all(row_is_terminal_for_drop(table, row) for row in rows)


def month_bundle_state_allows_drop(
    rows_by_table: Mapping[str, Sequence[Mapping[str, object]]],
) -> bool:
    """Разрешить month-bundle только при полном наборе safe-таблиц."""

    if set(rows_by_table) != set(APPROVED_FINANCIAL_HISTORY_TABLES):
        return False
    return all(
        month_state_allows_drop(table, rows_by_table[table])
        for table in APPROVED_FINANCIAL_HISTORY_TABLES
    )

@dataclass(frozen=True, slots=True)
class FinancialPhysicalPartitionContract:
    """Физический contract до разрешения PARTITION BY."""

    table: str
    partition_key: str
    current_primary_key: tuple[str, ...]
    global_unique_keys: tuple[tuple[str, ...], ...]
    foreign_keys: tuple[str, ...]
    activation_blockers: tuple[str, ...]


PHYSICAL_PARTITION_CONTRACTS: dict[
    str,
    FinancialPhysicalPartitionContract,
] = {
    "efhc_transfers_log": FinancialPhysicalPartitionContract(
        table="efhc_transfers_log",
        partition_key="created_at",
        current_primary_key=("id",),
        global_unique_keys=(("idempotency_key",),),
        foreign_keys=("global_id -> users.global_id",),
        activation_blockers=(
            "PRIMARY_KEY_ID_EXCLUDES_PARTITION_KEY",
            "GLOBAL_IDEMPOTENCY_KEY_EXCLUDES_PARTITION_KEY",
        ),
    ),
    "payment_intents": FinancialPhysicalPartitionContract(
        table="payment_intents",
        partition_key="created_at",
        current_primary_key=("id",),
        global_unique_keys=(
            ("global_id", "purpose", "idempotency_key"),
            ("external_tx_hash",),
        ),
        foreign_keys=("global_id -> users.global_id",),
        activation_blockers=(
            "PRIMARY_KEY_ID_EXCLUDES_PARTITION_KEY",
            "GLOBAL_IDEMPOTENCY_KEY_EXCLUDES_PARTITION_KEY",
            "GLOBAL_EXTERNAL_TX_HASH_EXCLUDES_PARTITION_KEY",
        ),
    ),
    "shop_orders": FinancialPhysicalPartitionContract(
        table="shop_orders",
        partition_key="created_at",
        current_primary_key=("id",),
        global_unique_keys=(
            ("tx_hash",),
            ("global_id", "idempotency_key"),
        ),
        foreign_keys=("global_id -> users.global_id",),
        activation_blockers=(
            "PRIMARY_KEY_ID_EXCLUDES_PARTITION_KEY",
            "GLOBAL_TX_HASH_EXCLUDES_PARTITION_KEY",
            "GLOBAL_IDEMPOTENCY_KEY_EXCLUDES_PARTITION_KEY",
        ),
    ),
    "withdraw_requests": FinancialPhysicalPartitionContract(
        table="withdraw_requests",
        partition_key="created_at",
        current_primary_key=("id",),
        global_unique_keys=(
            ("idempotency_key",),
            ("processing_idempotency_key",),
            ("payout_ref",),
        ),
        foreign_keys=("global_id -> users.global_id",),
        activation_blockers=(
            "PRIMARY_KEY_ID_EXCLUDES_PARTITION_KEY",
            "GLOBAL_IDEMPOTENCY_KEY_EXCLUDES_PARTITION_KEY",
            "GLOBAL_PROCESSING_KEY_EXCLUDES_PARTITION_KEY",
            "GLOBAL_PAYOUT_REF_EXCLUDES_PARTITION_KEY",
            "WITHDRAW_CHILD_FK_REQUIRES_GLOBAL_PARENT_KEY",
        ),
    ),
    "withdraw_outcome_events": FinancialPhysicalPartitionContract(
        table="withdraw_outcome_events",
        partition_key="created_at",
        current_primary_key=("id",),
        global_unique_keys=(("withdraw_request_id",),),
        foreign_keys=(
            "withdraw_request_id -> withdraw_requests.id",
            "global_id -> users.global_id",
        ),
        activation_blockers=(
            "PRIMARY_KEY_ID_EXCLUDES_PARTITION_KEY",
            "UNIQUE_WITHDRAW_REQUEST_ID_EXCLUDES_PARTITION_KEY",
            "WITHDRAW_PARENT_FK_IS_NOT_MONTH_AWARE",
        ),
    ),
    "ton_inbox_logs": FinancialPhysicalPartitionContract(
        table="ton_inbox_logs",
        partition_key="created_at",
        current_primary_key=("id",),
        global_unique_keys=(("tx_hash",),),
        foreign_keys=("resolved_global_id -> users.global_id",),
        activation_blockers=(
            "PRIMARY_KEY_ID_EXCLUDES_PARTITION_KEY",
            "GLOBAL_TX_HASH_EXCLUDES_PARTITION_KEY",
        ),
    ),
}


def physical_partition_activation_blockers() -> tuple[str, ...]:
    """Вернуть полный fail-closed blocker set для physical rewrite."""

    blockers: list[str] = []
    for table in APPROVED_FINANCIAL_HISTORY_TABLES:
        contract = PHYSICAL_PARTITION_CONTRACTS[table]
        blockers.extend(
            f"{table}:{blocker}"
            for blocker in contract.activation_blockers
        )
    return tuple(blockers)


def physical_partition_activation_allowed() -> bool:
    """Не разрешать physical PARTITION BY пока есть blocker."""

    return not physical_partition_activation_blockers()


def require_physical_partition_activation_ready() -> None:
    """Fail-closed остановить premature destructive activation."""

    blockers = physical_partition_activation_blockers()
    if blockers:
        raise RuntimeError(
            "RETENTION_PHYSICAL_PARTITION_NOT_QUALIFIED:"
            + ",".join(blockers)
        )

