"""EFHC backend package bootstrap anchor for archive guards."""
