# Current navigation pointer — v171.90

Canonical development HEAD: `EFHC_Bot_v171_90.zip`.
Production mirror: `EFHC_Bot_v171_90_RELEASE.zip`.
Current cycle: `1593`.
Exact routes: `ci_log_exact_failure_repair`,
`frontend_visual_route_backed_recovery` and
`archive_numbering_and_release_gate`.
Fallback: not used.

Current evidence:

- release run `82110466270` for v171.87 is green;
- development run `82109237157` failed one brittle PostgreSQL exact
  index-name assertion while Ruff, Mypy, Bandit, Alembic and frontend
  production build passed;
- the plan test now parses `EXPLAIN (FORMAT JSON)` nodes and requires
  canonical referral and panel index sets;
- the complete physical frontend inventory is 15 public routes,
  17 protected Admin routes and two safe system states;
- `/app`, `/admin/system`, `/404` and `/500` are aligned across the
  screen registry, source map and machine visual manifest;
- real visual proof must use `page.goto()` at 360, 390 and 430 px;
- clean local `npm ci` was blocked by registry HTTP 503, therefore no
  new screenshot proof is claimed;
- referral economics remain `1 000 + 1 411 = 2 411 EFHCb`;
- one Alembic head `0001` and 44 ORM tables remain unchanged;
- fresh exact-HEAD v171.90 development and release CI is required;
- `production_release_ready=false`.

Compatibility marker retained: next public visual lane map.
Current archive: `EFHC_Bot_v171_90.zip`.
Next changed archive: `EFHC_Bot_v171_91.zip`.

---

# Current navigation pointer — v171.67

Canonical archive lineage: `v171.64 → v171.65 → v171.66 → v171.67`.
Current cycle: `1574 — CI log root-cause repair and local RC audit`.
The only startup order remains `START_HERE.md` → `KERNEL.md`.

Current repair evidence:

- supplied log: `logs_81507543006.zip`;
- exact route: `ci_log_exact_failure_repair`;
- input HEAD: `EFHC_Bot_v171_66.zip`;
- output development HEAD: `EFHC_Bot_v171_67.zip`;
- report: `reports/change_cycle_2026-07-24_v171_67_cycle_1574_ci_log_root_cause_repair.md`;
- machine evidence: `reports/generated/ci_logs_81507543006_repair_v171_67.json`;
- exact 58 failed pytest nodes now pass locally;
- CI/workflow files remain manual-control and are unchanged.

Historical route compatibility retained: `v171_31 / v171.31`, cycle
`1556`, including Panels / Exchange release-readiness evidence.

---

# Current map update — v171.59 / cycle 1573 corrective browser proof

Working path: `/mnt/data/efhc_workspace`.

Current route:

1. `docs/AI/READING_ENTRYPOINT.md`;
2. `docs/NORM/RELEASE_PROOF_STATUS.md`;
3. `reports/change_cycle_2026-07-23_v171_59_cycle_1573_corrective_browser_proof.md`;
4. `reports/generated/cycle_1573_corrective_browser_proof_v171_59.json`;
5. `reports/generated/browser_component_page_proof_v171_59.json`;
6. `reports/generated/screenshots_companion_manifest_v171_59.json`.

Current truth:

- fresh browser component/page proof is available;
- Profile settings are mounted and visible;
- live proof remains open;
- Native Wallet Adapter remains planning-only.
---

# Current map update — v171.57 / cycle 1573 live contour gate

Working tree: `/mnt/data/efhc_workspace`. The map remains a reference layer only. In v171.57 the relevant Pесочница/TonConnect/Telegram references stay audit-only; no donor runtime code is imported.

Current use of the map: support future live Telegram, TonConnect, TonProof and transaction evidence planning without replacing EFHC architecture. Cycle 1573 remains blocked until factual external live proof exists.
---

# Current navigation map — v171.55 / cycle 1573 active

Read in order:

1. `AGENTS.md`;
2. `docs/AI/READING_ENTRYPOINT.md`;
3. `docs/NORM/HEALER_CRITICAL_DELIVERY_PROTOCOL.md`;
4. `KERNEL.md`;
5. `CONTINUE_IN_NEW_CHAT.md`;
6. `reports/change_cycle_2026-07-22_v171_55_cycle_1573_healer_critical_delivery_gate.md`;
7. `reports/generated/cycle_1573_healer_critical_delivery_gate_v171_55.json`;
8. `ops/healer/check_critical_delivery_protocol.py`;
9. `tests/healer/test_critical_delivery_protocol.py`.

Current truth: `HEAL-0112 / CASE-0121` is P0. Delivery is prohibited while
`BLOCKED_PROTOCOL` is active. Cycle 1573 remains active and cannot advance to
1574 before all live proof requirements are factually satisfied.
---

# Current navigation map — v171.47

Current cycle: `1571 — Full regression and GitHub workflow
normalization`.

Primary evidence:

- `docs/audits/FULL_REGRESSION_GITHUB_WORKFLOW_NORMALIZATION_1571.md`;
- `reports/generated/full_regression_v171_47.json`;
- `reports/generated/workflow_normalization_v171_47.json`;
- `reports/generated/log_repair_v171_47.json`;
- `reports/generated/cache_policy_v171_47.json`;
- `reports/generated/frontend_build_v171_47.json`;
- `reports/generated/frontend_compressed_route_budgets_v171_47.json`;
- `reports/generated/public_visual_v171_47.json`;
- `reports/generated/admin_visual_v171_47.json`;
- `reports/generated/full_regression_visual_v171_47.json`;
- `reports/generated/CYCLE_1571_REPORT.md`.

Visual proof is stored in companion archive
`EFHC_Bot_v171_47_Screenshots.zip`; its archive and file-level evidence is
registered in
`reports/generated/screenshots_companion_manifest_v171_47.json`.

Next route: cycle 1572 fresh GitHub rerun intake and release blocker
triage.

---

# Current navigation map — v171.42

Current cycle: `1566 — PostgreSQL atomicity, concurrency, migrations,
backup/restore and real transaction proof`.

Primary evidence:

- `docs/audits/POSTGRESQL_ATOMICITY_CONCURRENCY_BACKUP_RESTORE_1566.md`;
- `reports/generated/postgresql_migration_v171_42.json`;
- `reports/generated/postgresql_transaction_proof_v171_42.json`;
- `reports/generated/postgresql_concurrency_v171_42.json`;
- `reports/generated/postgresql_backup_restore_v171_42.json`;
- `reports/generated/postgresql_runtime_summary_v171_42.json`;
- `reports/generated/log_repair_v171_42.json`;
- `reports/generated/frontend_build_v171_42.json`;
- `reports/generated/full_regression_v171_42.json`;
- `reports/generated/postgresql_visual_summary_v171_42.json`;
- `reports/generated/frontend_visual_improvements_v171_42.json`;
- `reports/generated/CYCLE_1566_REPORT.md`.

Visual proof is stored in companion archive
`EFHC_Bot_v171_42_Screenshots.zip`; its file-level manifest remains in the
main source archive at
`reports/generated/screenshots_companion_manifest_v171_42.json`.

Next route: cycle 1567 security, privacy, legal and abuse hardening.

---

# Current navigation map — v171.41

Current cycle artifacts:

- `docs/audits/FULL_UI_BACKEND_LINKAGE_MATRIX_1565.md`;
- `reports/generated/full_ui_backend_linkage_v171_41.json`;
- `reports/generated/linkage_gaps_v171_41.json`;
- `reports/generated/linkage_browser_interaction_v171_41.json`;
- `reports/generated/public_admin_visual_matrix_v171_41.json`;
- `reports/generated/full_regression_v171_41.json`;
- `reports/generated/frontend_build_v171_41.json`;
- `reports/generated/CYCLE_1565_REPORT.md`;
- visual proof: `reports/screenshots/linkage_matrix_1565/` inside
  companion archive `EFHC_Bot_v171_41_Screenshots.zip`;
- archive split manifest:
  `reports/generated/archive_split_v171_41.json`.

Next route: cycle 1566 PostgreSQL atomicity and transaction proof.

---

# Current navigation map — v171.36

Start here:
`docs/AI/READING_ENTRYPOINT.md` -> `KERNEL.md`.

Current cycle evidence:

- cycle report:
  `reports/change_cycle_2026-07-19_v171_36_cycle_1561_`
  `direct_deposit_withdraw_energy.md`;
- funding linkage:
  `reports/generated/funding_contours_v171_36.json`;
- funding repair proof:
  `reports/generated/funding_repair_v171_36.json`;
- Withdraw proof:
  `reports/generated/withdraw_interaction_v171_36.json`;
- Energy proof:
  `reports/generated/energy_progress_v171_36.json`;
- screenshots:
  `reports/screenshots/direct_deposit_withdraw_energy_1561/`;
- release register:
  `reports/generated/mvp_release_readiness_master_plan_v171_36.json`.

Canonical funding distinction:

- `Прямое пополнение`: EFHC jetton -> EFHCm;
- `Пополнение`: HUB -> Browser Shop -> TON/GRAM or USDT -> EFHCm.

---

# Current route — HUB and Direct Deposit

- HEAD: `v171_35`.
- Work cycle: `1560`.
- Input: `EFHC_Bot_v171_34.zip`.
- Output: `EFHC_Bot_v171_35.zip`.
- Public route: `/hub`.
- Header entry: Global Header `+`.
- HUB page: `frontend/src/features/hub/HubPage.tsx`.
- HUB service/query: `hub.service.ts` and `useHub.ts`.
- Deposit modal: `frontend/src/components/DepositModal.tsx`.
- Deposit service/query: `directDeposit.service.ts` and
  `useDirectDeposit.ts`.
- Browser evidence: `hub_direct_deposit_v171_35.json`.
- Screenshots: `reports/screenshots/hub_direct_deposit_1560/`.
- Next planned work cycle: `1561`.

---

# Current route — Profile, Wallet, History and FAQ

- HEAD: `v171_34`.
- Work cycle: `1559`.
- Input: `EFHC_Bot_v171_33.zip`.
- Output: `EFHC_Bot_v171_34.zip`.
- Public routes: `/web-profile` and `/faq`.
- Profile page: `frontend/src/features/profile/WebProfilePage.tsx`.
- Wallet component:
  `frontend/src/components/profile/ProfileWalletSection.tsx`.
- History component:
  `frontend/src/components/profile/ProfileHistorySection.tsx`.
- Typed service: `frontend/src/services/profile.service.ts`.
- Query layer: `frontend/src/queries/useProfile.ts`.
- Replacement mapping:
  `docs/frontend/FRONTEND_PROFILE_LEGACY_SURFACE_REPLACEMENT_MAPPING.md`.
- Responsive evidence:
  `reports/generated/profile_wallet_history_faq_responsive_v171_34.json`.
- Thirteen-language evidence:
  `reports/generated/profile_faq_13_languages_v171_34.json`.
- Screenshots:
  `reports/screenshots/profile_wallet_history_faq_1559/`.
- Next planned work cycle: `1560`; it is not executed in this iteration.

---

# Current route — Referrals, Ranks and navigation icons

- HEAD: `v171_33`.
- Work cycle: `1558`.
- Input: `EFHC_Bot_v171_32.zip`.
- Output: `EFHC_Bot_v171_33.zip`.
- Public routes: `/referrals`, `/referrals/active`,
  `/referrals/inactive` and `/ranks`.
- Referral page: `frontend/src/pages/referrals.tsx`.
- Referral query/service: `frontend/src/queries/useReferrals.ts` and
  `frontend/src/services/referrals.service.ts`.
- Ranks page: `frontend/src/pages/ranks.tsx`.
- Ranks query/service: `frontend/src/queries/useRanks.ts` and
  `frontend/src/services/ranks.service.ts`.
- Start-param binding: `frontend/src/pages/_app.tsx`.
- Header energy mark: `GlobalHeader.tsx` and `icons/EfhcCoin.tsx`.
- Navigation icon system: `icons/AppNavIcon.tsx`.
- Linkage: `reports/generated/referrals_ranks_linkage_v171_33.json`.
- Browser evidence:
  `referrals_ranks_navigation_interaction_proof_v171_33.json`.
- Next planned cycle: `1559`; it is not executed in this iteration.

---

# Current route — Tasks, Ads alias and typography

- HEAD: `v171_32`.
- Work cycle: `1557`.
- Input: `EFHC_Bot_v171_31.zip`.
- Output: `EFHC_Bot_v171_32.zip`.
- Public route: `/tasks`; compatibility alias: `/ads`.
- Page: `frontend/src/pages/tasks.tsx`.
- Query/service: `frontend/src/queries/useTasks.ts` and
  `frontend/src/services/tasks.service.ts`.
- Backend: `backend/app/routes/tasks_routes.py`,
  `backend/app/services/tasks_service.py` and Ads callback routes.
- Linkage: `reports/generated/tasks_ads_linkage_v171_32.json`.
- Browser evidence: `reports/generated/tasks_claim_ads_interaction_proof_v171_32.json`.
- Typography evidence: `exchange_typography_interaction_proof_v171_32.json`
  and `panels_typography_interaction_proof_v171_32.json`.
- Next planned cycle: `1558`; it is not executed in this iteration.

---

# Current route — Panels, Exchange and release readiness

- HEAD: `v171_31`.
- Work cycle: `1556`.
- Input: `EFHC_Bot_v171_30.zip`.
- Output: `EFHC_Bot_v171_31.zip`.
- Primary public routes: `/panels` and `/exchange`.
- Panels page: `frontend/src/pages/panels.tsx`.
- Exchange page: `frontend/src/pages/exchange.tsx`.
- Query hooks: `frontend/src/queries/usePanels.ts` and
  `frontend/src/queries/useExchange.ts`.
- Services: `frontend/src/services/panels.service.ts` and
  `frontend/src/services/exchange.service.ts`.
- Generated DTO seams: `economicUserSeams.ts` and
  `economicUserSeamValidators.ts`.
- Backend routes: `backend/app/routes/panels_routes.py` and
  `backend/app/routes/exchange_routes.py`.
- Linkage matrix:
  `reports/generated/panels_exchange_linkage_v171_31.json`.
- Browser interaction evidence:
  `reports/generated/panels_activation_interaction_proof_v171_31.json` and
  `reports/generated/exchange_convert_interaction_proof_v171_31.json`.
- Release plan:
  `docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`.
- Machine release register:
  `reports/generated/mvp_release_readiness_master_plan_v171_31.json`.
- Release gate: `ops/release/mvp_release_readiness_master_gate.py`.
- Current local statuses: `CODE_FIXED`, `TARGETED_TESTS_PASSED`,
  `LOCAL_FRONTEND_BUILD_PASSED` and `LOCAL_VISUAL_PROOF_PASSED` for
  `/panels` and `/exchange` only.
- PostgreSQL transaction proof, fresh GitHub CI, live Telegram, real
  TonConnect and the final 99-percent audit are not established.
- Next planned cycle: `1557`; it is not executed in this iteration.

---

# Current route — shell, Energy runtime and public browser proof

- HEAD: `v171_30`.
- Work cycle: `1555`.
- Input: `EFHC_Bot_v171_29.zip`.
- Output: `EFHC_Bot_v171_30.zip`.
- Primary routes: all twelve protected public routes.
- Shell: `frontend/src/components/Layout.tsx` and
  `frontend/src/components/shell/FrontendShell.tsx`.
- Browser notice: `frontend/src/components/BrowserLoginDemo.tsx`.
- Energy runtime: `frontend/src/pages/index.tsx`.
- Document locale: `frontend/src/pages/_app.tsx`.
- Public visual harness:
  `ops/frontend/public_visual_runtime_proof.py`.
- Admin visual harness:
  `ops/frontend/admin_visual_button_click_proof.py`.
- Language canon: `docs/SSOT/LANGUAGE_CANON_SSOT.md`.
- Active guard:
  `tests/architecture/test_shell_language_browser_proof.py`.
- Cycle report:
  `reports/change_cycle_2026-07-16_v171_30_cycle_1555_shell_energy_navigation_browser_proof.md`.
- Generated evidence:
  `reports/generated/shell_energy_navigation_browser_proof_v171_30.json`.
- Public browser report:
  `reports/generated/public_pages_browser_proof_v171_30.json`.
- Current local statuses: `CODE_FIXED`, `TARGETED_TESTS_PASSED`,
  `LOCAL_FRONTEND_BUILD_PASSED`, and public-scope
  `LOCAL_VISUAL_PROOF_PASSED`.
- Public visual scope: twelve routes, thirteen languages, `390x844`.
- Admin visual proof, GitHub CI, live Telegram, real TonConnect and MVP
  release audit are not established.

---

# Current route — MVP Energy and frontend shell repair

- HEAD: `v171_29`.
- Work cycle: `1554`.
- Input: `EFHC_Bot_v171_28.zip`.
- Output: `EFHC_Bot_v171_29.zip`.
- Primary route: `/`.
- Active page: `frontend/src/pages/index.tsx`.
- Active Energy view: `frontend/src/components/energy/EnergyMvpSummary.tsx`.
- Snapshot DTO/service: `frontend/src/services/snapshot.service.ts`.
- React Query hook: `frontend/src/hooks/useSnapshot.ts`.
- Backend truth: `backend/app/routes/sync_routes.py`.
- Shell: `frontend/src/components/Layout.tsx` plus
  `frontend/src/components/shell/FrontendShell.tsx`.
- Replacement mapping:
  `docs/frontend/FRONTEND_ENERGY_MVP_REPLACEMENT_MAPPING.md`.
- Active guard: `tests/architecture/test_mvp_energy_shell_repair.py`.
- Cycle report:
  `reports/change_cycle_2026-07-16_v171_29_cycle_1554_mvp_energy_shell_repair.md`.
- Generated evidence:
  `reports/generated/mvp_energy_shell_repair_v171_29.json`.
- Current local statuses: `CODE_FIXED`, `TARGETED_TESTS_PASSED`,
  `LOCAL_FRONTEND_BUILD_PASSED` (repeatable clean Next webpack path).
- Full pytest: `2228 passed, 126 skipped`.
- Not established: `LOCAL_VISUAL_PROOF_PASSED`, `GITHUB_CI_VERIFIED`,
  `LIVE_TELEGRAM_VERIFIED`, `REAL_TONCONNECT_VERIFIED`,
  `MVP_RELEASE_AUDIT_PASSED`.

---

# v171.28 / cycle 1553 — Fresh CI archive and skills log repair

- Output: `EFHC_Bot_v171_28.zip`.
- Input: `EFHC_Bot_v171_27.zip`.
- Uploaded log: `logs_75642227264.zip`.
- Failed gates: `ruff`, `pytest`.
- Root causes: unused test variables, missing fail-closed release-status
  anchor, CI-created local log artifacts, line72 drift in Agent Skills
  scanner and legacy Ranks-forbidden substrings in copied skills/personas.
- Repair: tests and docs aligned with compact archive canon; CI/local
  logging no longer creates `.local_artifacts` during test runs; Agent
  Skills text cleaned without changing runtime behavior.
- No runtime, money, TON, withdraw, auth, DB or frontend business logic
  changed.
- GitHub CI green, full pytest green, frontend build green and
  release-ready are not claimed.

---

# v171.27 / cycle 1552 — Archive Purity and Naming Repair

- Output: `EFHC_Bot_v171_27.zip`.
- Input: `EFHC_Bot_v171_26_cycle_1551_agent_skills_adapter_fix.zip`.
- Incident: `v171_26` contained `.local_artifacts/logs/app.log` despite a
  false `forbidden artifacts 0` report.
- Repair: runtime log artifacts removed; operator/archive hygiene guards
  strengthened; compact filename canon added.
- Canon: current archive filenames use `EFHC_Bot_v<major>_<minor>.zip`; cycle
  and title stay inside Kernel/map/reports.
- No runtime, money, TON, withdraw, auth, DB or frontend business logic changed.
- GitHub CI green, full pytest green, frontend build green and release-ready are
  not claimed.

---

# v171.26 / cycle 1551 — Agent Skills Adapter Fix

- Output: `EFHC_Bot_v171_26_cycle_1551_agent_skills_adapter_fix.zip`.
- Input: `EFHC_Bot_v171_25_cycle_1550_agent_skills_adapter_foundation.zip`.
- TZ: `docs/audits/tz_v171_26_agent_skills_adapter_fix.md`.
- Fixed invalid `/ship` TOML commands in `commands/` and `.gemini/commands/`.
- Fixed EFHC startup hook test anchor.
- Replaced broken agent persona links to `../docs/agents.md` with the EFHC
  Agent Skills Adapter reference.
- Hardened `check_agent_skills_adapter.py` with TOML validation and persona
  link checks.
- Extended the public UI direct API gate to catch `EventSource(` and
  `WebSocket(` in public UI zones.
- Fixed `hooks/hooks.json` fallback chain for plugin-local, project-local and
  legacy `.claude` hook layouts.
- Adapted `plugin.json` metadata to EFHC.
- Runtime, economy, wallet, TonConnect, idempotency, withdraw and money-flow
  logic were not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed.

---

# v171.25 / cycle 1550 — Agent Skills Adapter Foundation

- Output: `EFHC_Bot_v171_25_cycle_1550_agent_skills_adapter_foundation.zip`.
- Input: `EFHC_Bot_v171_24_cycle_1549_fresh_ci_service_api_gate_log_repair.zip`.
- Uploaded TZ: `docs/audits/tz_v171_24_agent_skills_kernel_integration.md`.
- Upstream reference: `agent-skills-main.zip`.
- Added root entrypoints: `AGENTS.md`, `CLAUDE.md`.
- Added adapter: `docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md`.
- Added adapted `skills/`, `agents/`, `commands/`, `.claude/commands`,
  `.gemini/commands`, `references/`, `hooks/` and upstream index.
- Added scanner: `ops/ci_checks/check_agent_skills_adapter.py`.
- Added guard: `tests/architecture/test_agent_skills_adapter_contract.py`.
- Added permanent service/query standard docs.
- Agent Skills are subordinate to EFHC AI Archive Laws, SSOT and NORM.
- Runtime, economy, wallet, TonConnect, idempotency, withdraw and money-flow
  logic were not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed.

---

# v171.24 / cycle 1549 — Fresh CI Service API Gate Log Repair

- Output: `EFHC_Bot_v171_24_cycle_1549_fresh_ci_service_api_gate_log_repair.zip`.
- Input: `EFHC_Bot_v171_23_cycle_1548_service_api_react_query_gate.zip`.
- Uploaded log: `logs_74815399993.zip`.
- Failed gate in uploaded log: `pytest`.
- Passed gates in uploaded log: `ruff`, `mypy backend/app`, `bandit`,
  `compileall`, Alembic, `npm ci`, frontend build.
- Pytest in uploaded log: `32 failed, 2231 passed, 8 skipped, 2 warnings`.
- Root cause: stale architecture guards after public UI API access moved from
  pages/components into services and React Query hooks.
- Repaired: stale panels/exchange/tasks/browser-shop/profile/TonConnect/referral
  guards, canonical `tg_id` naming in new query seams and numbered-label
  hygiene from the migration-gate documents.
- Public API migration gate and public copy firewall remain active and pass
  locally.
- Runtime, economy, wallet, TonConnect, idempotency, withdraw and money-flow
  logic were not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed.

---

# v171.23 / cycle 1548 — API Service React Query Migration Gate

- Output: `EFHC_Bot_v171_23_cycle_1548_service_api_react_query_gate.zip`.
- Input: `EFHC_Bot_v171_22_cycle_1547_fresh_ci_public_copy_log_repair.zip`.
- Uploaded TZ: `docs/audits/tz_v171_20.md`.
- Goal: make `DTO → Service API → React Query → UI` a migration gate, not a
  broad rewrite.
- Added scanner: `ops/ci_checks/check_no_direct_api_in_public_ui.py`.
- Added policy: `ops/policy/public_ui_direct_api_allowlist.json`.
- Added pytest guard: `tests/architecture/frontend/case_no_direct_api_in_public_ui.py`.
- Added docs: `docs/GENERAL/API_SERVICE_REACT_QUERY_MIGRATION_GATE.md`.
- Added reports: `reports/generated/public_api_migration_gate.txt`,
  `reports/generated/frontend_typecheck.txt`,
  `reports/generated/api_service_react_query_migration_gate_v171_23.json`.
- P0 migrated flows: browser-shop, withdraw, tasks, panels, exchange.
- Direct `/api` in public UI: blocked by CI scanner.
- React Query for server state: mandatory for migrated/new flows.
- Full frontend rewrite: not performed.
- Public UI release-ready: still depends on visual/beauty/live proof gates.
- Runtime, economy, wallet, TonConnect, idempotency, withdraw and money-flow
  logic were not changed.

---

# v171.22 / cycle 1547 — Fresh CI Public Copy Log Repair

- Output: `EFHC_Bot_v171_22_cycle_1547_fresh_ci_public_copy_log_repair.zip`.
- Input: `EFHC_Bot_v171_21_cycle_1546_visual_proof_splash_settle_guard.zip`.
- Uploaded log: `logs_74688208405.zip`.
- Failed gates in uploaded log: `ruff`, `pytest`.
- Passed gates in uploaded log: `flake8`, `mypy backend/app`, `bandit`,
  `compileall`, Alembic, `npm ci`, frontend build.
- Repaired: public-copy scanner ruff style, public-copy guard import ordering,
  webhook transaction test import ordering, FAQ SSOT/generated drift,
  non-English `portal.web_profile.no_data` values, stale public-copy exact
  guards and numbered-label hygiene.
- Public copy scanner now passes after FAQ/locale cleanup.
- Runtime, economy, wallet, TonConnect, idempotency, withdraw and money-flow
  logic were not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed.

---

# v171.21 / cycle 1546 — Visual Proof Splash Settle Guard

- Output: `EFHC_Bot_v171_21_cycle_1546_visual_proof_splash_settle_guard.zip`.
- Input: `EFHC_Bot_v171_20_cycle_1545_public_copy_firewall_guard.zip`.
- Uploaded audit/TZ/patch:
  `docs/audits/a_v171_18.md`, `docs/audits/tz_v171_18.md`,
  `docs/audits/visual_proof_splash_fix_v171_17_v2.patch`.
- Goal: make public/admin visual proof screenshots splash-aware.
- Public proof: `ops/frontend/public_visual_runtime_proof.py` imports and uses
  `_wait_for_shell_visual_ready` and `_splash_visible`.
- Admin proof: `ops/frontend/admin_visual_button_click_proof.py` defines
  `VISUAL_PROOF_MIN_SETTLE_MS = 2_500` and
  `VISUAL_PROOF_READY_TIMEOUT_MS = 5_000`.
- Old fixed waits `700/500/450ms` are no longer readiness signals.
- Success now requires `splash_visible == false`.
- DOM marker alone is not sufficient proof.
- New guard: `tests/architecture/test_visual_proof_splash_settle_v2.py`.
- Runtime screenshot rerun was attempted but not claimed as passed in sandbox.
- No product UI, economy, wallet, TonConnect or withdraw logic changes.

---

# v171.20 / cycle 1545 — Public Copy Firewall Guard

- Output: `EFHC_Bot_v171_20_cycle_1545_public_copy_firewall_guard.zip`.
- Input: `EFHC_Bot_v171_19_cycle_1544_fresh_ci_memo_log_repair.zip`.
- Uploaded TZ: `docs/audits/tz_v171_17_copy_guard.md`.
- Goal: stop technical text from returning to public UI.
- Added policy: `ops/policy/public_ui_forbidden_copy.json`.
- Added scanner: `ops/ci_checks/check_public_ui_forbidden_copy.py`.
- Added pytest guard:
  `tests/architecture/public_visual_cases/case_public_ui_no_technical_copy.py`.
- Added public norm: `docs/GENERAL/PUBLIC_COPY_FIREWALL.md`.
- CI linkage: `Makefile public-copy`, frontend
  `npm run check:public-copy`, pytest discovery for `case_*.py`.
- Public copy scanner result: passed.
- Rough empty-state examples are also blocked in public copy.
- Locale/copy cleanup touched public user-visible copy only.
- No economy, wallet, TonConnect, idempotency or withdraw money-flow changes.
- DOM visual proof was not performed in sandbox.
- Live Telegram proof and real TonConnect proof were not performed.

---

# v171.19 / cycle 1544 — Fresh CI Memo Log Repair

- Output: `EFHC_Bot_v171_19_cycle_1544_fresh_ci_memo_log_repair.zip`.
- Input: `EFHC_Bot_v171_18_cycle_1543_memo_canon_webhook_raw_error_repair.zip`.
- CI log: `logs_74672087378.zip`.
- Log failed gates: `ruff`, `mypy backend/app`, `pytest`.
- Log passed gates for input archive: `flake8`, `bandit`, `compileall`,
  Alembic, `npm ci`, frontend build.
- Pytest log: `3 failed, 2098 passed, 8 skipped, 2 warnings`.
- Root repairs:
  - ruff `UP028` / `SIM102` in raw-error guard;
  - ruff import-order in webhook transaction test;
  - mypy `no-any-return` in watcher memo adapter;
  - stale i18n key-count guards after active count became `1465`;
  - memo SSOT guard changed from exact return-string to semantic bridge.
- P0 memo canon remains closed: watcher still consumes
  `parse_memo_for_watcher(...)` from `ton_memo.py`.
- No economy, wallet, TonConnect, idempotency or withdraw money-flow changes.
- Live Telegram proof and real TonConnect proof were not performed.

---

# v171.18 / cycle 1543 — Memo Canon / Webhook / Raw Error Repair

- Output: `EFHC_Bot_v171_18_cycle_1543_memo_canon_webhook_raw_error_repair.zip`.
- Input: `EFHC_Bot_v171_17_cycle_1542_fresh_ci_rerun_guard_repair.zip`.
- Audit/TZ: `docs/audits/a_v171_17.md`, `docs/audits/tz_v171_17.md`.
- Closed P0: direct deposit memo drift between `/deposit/direct-open`
  generator and watcher parser.
- Memo SSOT: `backend/app/integrations/ton_memo.py`; watcher adapter:
  `parse_memo_for_watcher(...)`.
- Canonical memo: `build_deposit_memo(123456789)` ->
  `EFHC:123456789`; watcher recognises it as `simple_efhc`.
- Legacy supported: `EFHC123456789`, `SKU:EFHC|Q:<qty>|TG:<tg_id>`,
  `SKU:NFT_VIP|Q:<qty>|TG:<tg_id>`.
- Panels activation now uses `publicApiErrorMessage(...,
  "panels.activate_failed")`.
- Telegram webhook now commits after successful `process_update(...)` and
  rolls back before dedupe cleanup on exceptions.
- Admin runtime logs/observability dashboards use `adminSafeLoadError(...)`.
- Raw-error guards now catch `err/error/e` style `.message` patterns.
- No economy, rates, balances, wallet, TonConnect, money-flow, referral bonus
  or withdraw business logic changed.
- Live Telegram proof, real TonConnect proof, release-ready and
  production-ready are not claimed.

---

# v171.17 / cycle 1542 — Fresh CI Rerun Guard Repair

- Output: `EFHC_Bot_v171_17_cycle_1542_fresh_ci_rerun_guard_repair.zip`.
- Input: `EFHC_Bot_v171_16_cycle_1541_fresh_ci_frontend_noise_log_repair.zip`.
- Log: `logs_74653569841.zip`.
- Failed gates in input log: `pytest` only.
- Passed gates in input log: flake8, ruff, mypy backend/app, bandit,
  compileall, Alembic, npm ci and frontend build.
- Pytest in input log: `1 failed, 2083 passed, 8 skipped, 2 warnings`.
- Repaired locally: stale exact-whitespace architecture assertion for referral
  persistence import block. The guard now checks semantic import symbols rather
  than a fragile blank-line layout.
- Added guard: `tests/architecture/test_fresh_ci_frontend_noise_rerun_confirmation.py`.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, live Telegram proof, real TonConnect
  proof, release-ready and production-ready are not claimed.

---

# v171.16 / cycle 1541 — Fresh CI Frontend Noise Log Repair

- Output: `EFHC_Bot_v171_16_cycle_1541_fresh_ci_frontend_noise_log_repair.zip`.
- Input: `EFHC_Bot_v171_15_cycle_1540_frontend_error_noise_cleanup.zip`.
- Log: `logs_74645134614.zip`.
- Failed gates in input log: `ruff`, `pytest`.
- Passed gates in input log: flake8, mypy backend/app, bandit, compileall,
  Alembic, npm ci and frontend build.
- Pytest in input log: `16 failed, 2060 passed, 8 skipped, 2 warnings`.
- Repaired locally: referral persistence test import ordering, stale
  duplicate-error-toast guards, stale ErrorBoundary guard, non-English
  public error-state translations, PWA offline shell/cache compatibility,
  line-length drift and root-doc numbered-label hygiene.
- Added guard: `tests/architecture/test_fresh_ci_frontend_noise_log_repair.py`.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, live Telegram proof, real TonConnect
  proof, release-ready and production-ready are not claimed.

---

# v171.15 / cycle 1540 — Frontend Error Noise Cleanup

- Output: `EFHC_Bot_v171_15_cycle_1540_frontend_error_noise_cleanup.zip`.
- Input: `EFHC_Bot_v171_14_cycle_1539_fresh_ci_live_referral_proof_gate.zip`.
- New audit/TZ: `a_v171_12.md`, `tz_v171_12.md` read and stored under `docs/audits/`.
- Chat 36 added to canonical chat section: `docs/NORM/CHATS/36.md`.
- Closed locally: raw HTTP transport, ErrorBoundary raw detail, admin raw backend messages, ShopEntry/Profile raw public messages, duplicate error channels, toast dedupe/a11y, route/offline fallbacks, production console hygiene and i18n copy cleanup.
- Added guards: `test_frontend_no_raw_error_messages.py`, `test_frontend_error_boundary_safe_copy.py`, `test_admin_safe_error_messages.py`, `test_frontend_toast_a11y_dedupe.py`, `test_frontend_route_offline_fallbacks.py`, `test_i18n_error_copy_cleanup.py`.
- Runtime economy, rates, balances, referral bonus amount, wallet binding, TonConnect proof, idempotency, money-flow and withdraw business logic were not changed.
- Runtime code from Песочница or template archives was not copied.
- GitHub CI green, full pytest green, frontend build green, live Telegram proof, real TonConnect proof, release-ready and production-ready are not claimed.

---

# v171.14 / cycle 1539 — Fresh CI / Live Referral Proof Gate

- Output: `EFHC_Bot_v171_14_cycle_1539_fresh_ci_live_referral_proof_gate.zip`.
- Input: `EFHC_Bot_v171_13_cycle_1538_fresh_ci_artifact_hygiene_log_repair.zip`.
- New `logs_*.zip`: none provided.
- New audit/TZ: none provided.
- Closed locally: fail-closed proof gate documentation, cycle guard,
  Operator Kernel route registration and release-proof status refresh.
- Added guard: `tests/architecture/test_fresh_ci_live_referral_proof_gate.py`.
- Runtime economy, money-flow, wallet-flow, withdraw logic, TonConnect,
  referral bonus amount and frontend money mutations were not changed.
- Runtime code from Песочница or uploaded template archives was not copied.
- GitHub CI green, full pytest green, frontend build green, live Telegram
  proof, real WebApp referral proof, real TonConnect proof, release-ready and
  production-ready are not claimed.
- Release gate remains fail-closed.

---

# v171.13 / cycle 1538 — Fresh CI Artifact Hygiene Log Repair

- Output: `EFHC_Bot_v171_13_cycle_1538_fresh_ci_artifact_hygiene_log_repair.zip`.
- Input: `EFHC_Bot_v171_12_cycle_1537_referral_persistence_webhook_repair.zip`.
- Log: `logs_74600883162.zip`.
- Red gates repaired locally: `ruff` and `pytest`.
- Removed transient `frontend/tsconfig.tsbuildinfo` artifact.
- Route freeze and guard count markers now follow current count `132`.
- Bot subscription middleware no longer contains the banned literal
  identity keyword spelling while preserving aiogram API semantics.
- Runtime economy, money-flow, wallet-flow, withdraw logic, TonConnect
  and frontend money mutations were not changed.
- Release gate remains fail-closed.

---

# v171.12 / cycle 1537 — Referral Persistence Webhook Repair

- Output: `EFHC_Bot_v171_12_cycle_1537_referral_persistence_webhook_repair.zip`.
- Input: `EFHC_Bot_v171_11_cycle_1536_fresh_ci_referral_log_repair.zip`.
- Audit/TZ: `docs/audits/a_v171_11.md`, `docs/audits/tz_v171_11.md`.
- Closed locally: referral attach durable commit boundary, Telegram webhook
  canonical DB DI, route persistence proof, exchange mutation fallback and
  WebApp retryable bind marker.
- `telegram_webhook` now calls `process_update(db=db, payload=payload)`.
- `attach_referral_code_for_user` owns commit/rollback for successful
  referral binding only.
- Runtime economy, money-flow, wallet-flow, withdraw logic, TonConnect and
  frontend money mutations were not changed.
- Release gate remains fail-closed.

---

# v171.11 / cycle 1536 — Fresh CI Referral Log Repair

- Output: `EFHC_Bot_v171_11_cycle_1536_fresh_ci_referral_log_repair.zip`.
- Input: `EFHC_Bot_v171_10_cycle_1535_referral_ux_fix.zip`.
- Log: `logs_74569153381.zip`.
- Red gates repaired locally: ruff, mypy and pytest.
- OpenAPI static snapshot was rebuilt after referral bind/attach routes.
- Public i18n parity remains 13 languages / 1447 keys / 0 missing.
- Runtime economy, money-flow, wallet-flow, withdraw logic, TonConnect and
  frontend money mutations were not changed.
- Release gate remains fail-closed.

---

# v171.10 / cycle 1535 — Referral UX Fix

- Input: `EFHC_Bot_v171_09_cycle_1534_fresh_ci_hygiene_log_repair.zip`.
- Output: `EFHC_Bot_v171_10_cycle_1535_referral_ux_fix.zip`.
- Audit/TZ: `docs/audits/a_v171_09.md`, `docs/audits/tz_v171_09.md`.
- Closed: referral deeplink binding, withdraw public-safe error toast,
  exchange mutation error copy, first-run onboarding tour.
- Guards: referral deeplink entrypoint, frontend public error messages,
  i18n public keys, WebApp start_param/onboarding guard.
- No economy, money-flow, wallet-flow, withdraw business logic or
  TonConnect changes.

---

# v171.09 / cycle 1534 — Fresh CI Rerun / Hygiene Log Repair

- Input HEAD: `v171.08`.
- Output HEAD: `v171_09 / v171.09`.
- Uploaded log: `logs_74538464541.zip`.
- Log verdict: red. Failed gates: `ruff` and `pytest`.
- Passed in the log: mypy full report, bandit, compileall, Alembic,
  npm ci and frontend build.
- Root cause: filename/body hygiene drift after the scheduler notify/facade
  repair, plus one ruff import-order issue in NFT route runtime test.
- Repaired: renamed NORM report without numeric work-pass label, removed
  numbered work-pass text from root Kernel and Healer indexes, and fixed
  import ordering.
- Runtime, money-flow, wallet flow, withdraw logic, TonConnect, frontend
  runtime and EFHC economy were not changed.
- Output GitHub CI green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.

---

# v171.08 / cycle 1533 — Scheduler Notify Fix / Admin Facade Cleanup

- Input HEAD: `v171.07`.
- Output HEAD: `v171_08 / v171.08`.
- Audit input: `docs/audits/a_v171.07.md`.
- TZ input: `docs/audits/tz_v171.07.md`.
- Closed: `P1-WITHDRAWALS-PROCESSOR-DOUBLE-BUG`.
- Closed: `P1-REPORTS-DAILY-NOTIFY-GENERIC`.
- Closed: dead admin facade approve/reject withdraw contract drift.
- Scheduler notify events are now canonical: `withdrawals.stale` and
  `reports.daily`.
- Mypy scope now includes scheduler notify files and admin facade.
- Runtime code copied from Песочница: none.
- Output GitHub CI green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed.

---

# v171.07 / cycle 1532 — Fresh CI rerun / mypy scope follow-up

- Input HEAD: `v171.06`.
- Output HEAD: `v171_07 / v171.07`.
- Uploaded log: `logs_74475316189.zip`.
- Log verdict: red. Failed gates: `ruff` and `pytest`.
- Passed in the log: flake8 critical/full, mypy full report, bandit,
  compileall, PSQL pre-check, Alembic upgrade head, npm ci and frontend
  build.
- Mypy full scope evidence: `Success: no issues found in 283 source files`.
- Pytest failure: stale `test_fresh_ci_log_repair_kernel_anchor_restore.py`
  expected exact `v171_05 / v171.05` in current root Kernel after the HEAD
  had moved to `v171.06`.
- Ruff failures: I001 import ordering in three new cycle 1531 runtime tests.
- Repair: import ordering normalized and stale guard converted to semantic
  Kernel assertion plus historical map/routes assertions.
- Runtime, money-flow, wallet flow, withdraw logic, TonConnect, frontend
  runtime and EFHC economy were not changed.
- Output GitHub CI green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.

---

# v171.06 / cycle 1531 — Global signature drift fix

- Input HEAD: `v171.05`.
- Output HEAD: `v171.06`.
- Audit/TZ inputs: `docs/audits/AUDIT_V171_05_GLOBAL.md` and
  `docs/audits/CYCLE_1525_GLOBAL.md`.
- Closed locally: panels pagination cursor TypeError, scheduler archive
  panels TypeError, bot referrals kwarg mismatch, bot ranks signature/unpack
  bug, NFT has_vip route kwarg mismatch, admin decimal formatting mismatch
  and staged mypy scope gap.
- New docs: `docs/NORM/GLOBAL_SIGNATURE_DRIFT_FIX_REPORT.md`,
  `docs/NORM/BACKEND_SIGNATURE_DRIFT_GUARD.md`,
  `docs/NORM/MYPY_SCOPE_EXPANSION_PLAN.md`.
- New guards/tests: backend signature drift guard, global signature drift
  regression guard and runtime tests under `tests/efhc_backend/`.
- Proof boundary: targeted local pack passed; full pytest timed out locally;
  `ruff`, `mypy` and `bandit` were unavailable in sandbox; fresh GitHub CI
  rerun for `v171.06` is still required.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.

---

# v171.05 / cycle 1530 — Fresh CI green confirmation

- `docs/cycles/WORK_CYCLES_1530_FRESH_CI_GREEN_CONFIRMATION.md` — cycle
  record.
- `docs/NORM/FRESH_CI_GREEN_CONFIRMATION.md` — green CI evidence note for
  `logs_74465909794.zip`.
- `reports/generated/fresh_ci_green_confirmation_v171_05.json` —
  machine-readable evidence status.
- `tests/architecture/test_fresh_ci_green_confirmation.py` — guard for green
  evidence, no output-CI overclaim and no release-ready overclaim.
- Evidence: the uploaded GitHub CI log is green for input HEAD `v171.04`.
  Gate summary: `OK: all gate steps passed.`
- Key summaries: pytest `1962 passed, 8 skipped, 2 warnings`; ruff
  `All checks passed!`; mypy `Success: no issues found in 283 source files`;
  frontend build compiled successfully.
- Status: GitHub CI green confirmed for input HEAD `v171.04`. The output
  archive `v171.05` is not itself claimed as CI-green until a fresh rerun is
  provided for `v171.05`. Live Telegram proof, real TonConnect proof and
  release-ready are not claimed.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.

# v171.04 / cycle 1529 — Fresh CI red-log repair

- `docs/cycles/WORK_CYCLES_1529_FRESH_CI_LOG_REPAIR_KERNEL_ANCHOR_RESTORE.md`
  — cycle record.
- `docs/NORM/FRESH_CI_LOG_REPAIR_KERNEL_ANCHOR_RESTORE.md` — root-cause
  note for `logs_74445426759.zip`.
- `reports/generated/fresh_ci_log_repair_kernel_anchor_restore_v171_04.json`
  — machine-readable local repair status.
- `tests/architecture/test_fresh_ci_log_repair_kernel_anchor_restore.py` —
  guard for restored compact Kernel anchors and no false release claims.
- Root cause: cycle 1528 compacted `KERNEL.md` while older architecture
  guards still expected exact Kernel navigation anchors.
- Fix: restore compact compatibility anchors in `KERNEL.md`; preserve
  `map_element.md` as detailed historical navigation layer.
- Status: uploaded CI log was red; factual pytest failures repaired locally.
  GitHub CI green for output archive, full pytest green, live Telegram proof,
  real TonConnect proof and release-ready are not claimed.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.

## Exact legacy navigation anchors preserved for guards

- `v170.34 / Dashboard Design Tokens Foundation`
- `v170.33 / Grafana Visual Pattern Map`
- `v170.32 / sandbox dashboard inventory`

# v171.03 / cycle 1528 — Kernel/map_element compaction

- `docs/cycles/WORK_CYCLES_1528_KERNEL_MAP_COMPACTION_TEST_CONSOLIDATION.md`
  — cycle record.
- `docs/NORM/KERNEL_MAP_ELEMENT_COMPACTION_PASS.md` — Kernel/map_element
  compaction boundary and reference-only sandbox note.
- `docs/NORM/TEST_GUARD_CONSOLIDATION_EXECUTION.md` — mapping for the
  executed low-risk chat-docs test consolidation.
- `reports/generated/kernel_map_compaction_test_consolidation_v171_03.json`
  — machine-readable fail-closed cycle status.
- `tests/architecture/test_kernel_map_compaction_test_consolidation.py` —
  guard for current HEAD anchors, compaction docs and consolidation mapping.
- `tests/architecture/test_chat_docs_intake.py` — consolidated active guard
  for chat exports `24.md`, `25.md`, `26.md`, `27.md`, `28.md`, `30.md`,
  `31.md`, `32.md`, `33.md`, `34.md` and `35.md`.
- Status: no `logs_*.zip` was provided. GitHub CI green, full pytest green,
  frontend build green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed. Runtime and money-flow were not changed.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.

## Historical navigation below

The historical `map_element.md` anchors are preserved below for older guards
and navigation. This pass adds a compact current section without deleting
legacy anchors.

# v171.02 / cycle 1527 — CI evidence / chat docs / test consolidation

- `docs/cycles/WORK_CYCLES_1527_CI_EVIDENCE_CHAT_DOCS_TEST_CONSOLIDATION.md` — cycle record.
- `docs/NORM/CHATS/34.md` — visible chat export for cycles `1500–1514`.
- `docs/NORM/CHATS/35.md` — visible chat export for cycles `1515–1525`.
- `docs/NORM/CHAT_DOCS_RECENT_INTAKE.md` — recent chat intake note.
- `docs/NORM/TEST_GUARD_CONSOLIDATION_CANDIDATES.md` — proposal-only list of tests that may be merged in a future controlled cycle.
- `reports/generated/ci_evidence_chat_docs_test_consolidation_v171_02.json` — machine-readable fail-closed cycle status.
- `tests/architecture/test_chat_docs_recent_intake_and_consolidation_plan.py` — guard for chat docs, proposal-only consolidation and no false proof claims.
- Status: no `logs_*.zip` was provided. GitHub CI green, full pytest green,
  live Telegram proof, real TonConnect proof and release-ready are not
  claimed. Runtime and money-flow were not changed.
- Песочница used only as reference/navigation/prototype layer. Runtime code
  was not copied.
- Runtime code was not copied from Песочница.
- Grafana used only as visual-pattern/reference layer. Runtime code was not
  copied.

# v171.01 / cycle 1526 — Fresh CI / live proof gate refresh

- `docs/cycles/WORK_CYCLES_1526_FRESH_CI_LIVE_TONCONNECT_PROOF.md` — cycle record.
- `reports/generated/fresh_ci_live_tonconnect_proof_v171_01.json` — local proof boundary summary.
- `reports/generated/live_release_readiness_gate_v171_01_cycle_1526.json` — fail-closed external proof gate for current HEAD.
- `reports/change_cycle_2026-06-16_v171_01_cycle_1526_fresh_ci_live_tonconnect_proof.md` — change report.
- `tests/architecture/test_current_release_readiness_gate.py` — guard against false current-cycle release proof claims.
- Status: no GitHub CI green, no live Telegram proof, no real TonConnect proof
  and no release-ready claim. Runtime and money-flow were not changed.

# v171.00 / cycle 1525 — Archive numbering rollover repair

- `docs/NORM/ARCHIVE_NUMBERING_ROLLOVER_REPAIR.md` — controlled repair norm.
- `docs/NORM/ARCHIVE_NUMBERING_CANON.md` — two-digit suffix and rollover canon.
- `docs/cycles/WORK_CYCLES_1525_ARCHIVE_NUMBERING_ROLLOVER_REPAIR.md` — cycle record.
- `reports/generated/archive_numbering_rollover_repair_v171_00.json` — machine-readable repair report.
- `reports/change_cycle_2026-06-16_v171_00_cycle_1525_archive_numbering_rollover_repair.md` — change report.
- `tests/architecture/test_archive_numbering_rollover_guard.py` — guard against future three-digit minor suffixes.
- Status: canonical reissue only. Runtime, money-flow, withdraw logic,
  TonConnect behavior and EFHC economy were not changed. Release-ready is
  not claimed.

# v171.00 / cycle 1524 — Fresh CI withdrawals test isolation repair

- `docs/NORM/FRESH_CI_WITHDRAWALS_RUNTIME_TEST_ISOLATION.md` — cycle 1524 norm and root-cause report.
- `docs/cycles/WORK_CYCLES_1524_FRESH_CI_WITHDRAWALS_TEST_ISOLATION_REPAIR.md` — cycle record.
- `reports/generated/fresh_ci_withdrawals_runtime_test_isolation_v171_00.json` — machine-readable red-log repair report.
- `reports/change_cycle_2026-06-16_v171_00_cycle_1524_fresh_ci_withdrawals_test_isolation_repair.md` — change report.
- `tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py` — guard against restoring empty-string `users.ton_wallet` fixtures.
- `tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py` — DB-backed service runtime tests now use `NULL` for absent legacy wallet.
- `tests/efhc_backend/admin/test_admin_withdrawals_routes_runtime.py` — route-level runtime tests now use `NULL` for absent legacy wallet.
- Status: uploaded CI log was red; factual pytest failures repaired locally. Fresh CI green for output archive and release-ready are not claimed.

# v170.99 / work item 1523 — P0 admin withdrawals list regression fix

- `docs/NORM/ADMIN_WITHDRAWALS_P0_LIST_REGRESSION_FIX.md` — P0 fix norm.
- `docs/NORM/ADMIN_WITHDRAWALS_LIST_RUNTIME_PROOF.md` — runtime proof plan.
- `docs/NORM/BONUS_AWARDS_LEGACY_GUARD_SCOPE.md` — legacy guard scope norm.
- `tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py` —
  DB-backed service runtime tests.
- `tests/efhc_backend/admin/test_admin_withdrawals_routes_runtime.py` —
  route-level admin list tests.
- `tests/architecture/test_bonus_awards_legacy_guard_scope.py` — AST guard.
- `tests/architecture/test_withdraw_bonus_awards_regression_guard.py` —
  regression guard against returning the cycle 1519 drift.
- `reports/generated/p0_admin_withdrawals_list_regression_fix_v170_99.json`
  — machine-readable local proof boundary.

# v170.98 / cycle 1522 — Fresh CI rerun log repair

- `docs/NORM/FRESH_CI_RERUN_LOG_REPAIR.md` — red CI log repair norm.
- `reports/generated/fresh_ci_rerun_log_repair_v170_98.json` —
  machine-readable repair report.
- `tests/architecture/test_fresh_ci_rerun_log_repair.py` — guard for
  line72, panel seam evidence and no false release claims.
- `frontend/src/pages/panels.tsx` — restored static route evidence while
  keeping generated panel seam constants.
- `tests/architecture/route_evidence_cases/case_public_energy_panels_exchange_guard_matrix.py` —
  stale direct raw route expectation updated to generated seam canon.
- Status: uploaded CI log was red; factual failures repaired locally. Fresh
  CI green for `v170.98` and release-ready are not claimed.

# v170.97 / cycle 1521 — Live release readiness proof gate

- `docs/NORM/LIVE_TELEGRAM_REAL_TONCONNECT_RELEASE_PROOF_GATE.md` —
  fail-closed release proof gate norm.
- `ops/release/release_readiness_proof_gate.py` — local proof gate runner.
- `reports/generated/live_release_readiness_gate_v170_97.json` —
  machine-readable release gate result.
- `tests/architecture/test_live_release_readiness_gate.py` — guard against
  false live Telegram, real TonConnect, GitHub CI and release-ready claims.
- Status: local proof gate added; live Telegram, real TonConnect, fresh CI and
  release-ready remain blocked until external evidence is supplied.

# v170.96 / cycle 1520 — Frontend i18n Visual Closure

- `docs/NORM/FRONTEND_I18N_VISUAL_CLOSURE_REPORT.md` —
  main cycle 1520 closure report.
- `docs/NORM/I18N_PUBLIC_KEYS_CLOSURE_REPORT.md` — all 37 missing
  used i18n keys added to 13 locales.
- `docs/NORM/UK_LOCALE_RU_LEAK_CLOSURE_REPORT.md` — current UK
  Russian-tail marker closed.
- `docs/NORM/VISUAL_PROOF_RUNTIME_ERROR_GUARD.md` — HTTP 200 is not
  enough when runtime overlays are visible.
- `docs/NORM/PUBLIC_PAGES_BROWSER_PROOF_REPORT.md` — local public
  pages browser proof table.
- `docs/NORM/TONCONNECT_E2E_SANDBOX_GUARD.md` — e2e-only TonConnect
  sandbox guard.
- `ops/frontend/public_visual_runtime_proof.py` — public visual proof
  harness.
- `ops/frontend/admin_visual_button_click_proof.py` — admin visual
  runtime guard harness.
- `tests/architecture/test_public_frontend_buttons_api_i18n_drift.py` —
  public buttons/API/i18n/visual guard.
- `reports/generated/frontend_i18n_visual_closure_v170_96.json` —
  generated cycle metadata.
- `reports/generated/public_pages_browser_proof_v170_96.json` —
  public visual proof report.
- `reports/screenshots/public_visual_1520/` — public screenshots.
- `reports/screenshots/admin_visual_1520/` — admin runtime guard
  screenshots.
- Status: local closure done; GitHub CI green and release-ready are not
  claimed.

# v170.93 / cycle 1517 — Frontend Buttons / API / i18n Drift Audit

- `docs/NORM/FRONTEND_BUTTONS_API_I18N_DRIFT_AUDIT.md` — cycle 1517 audit/closure report.
- `frontend/src/features/admin/AdminHubPage.tsx` — migrated to `adminApiRequest` / `adminPath`.
- `frontend/src/features/admin/AdminSalePackagesPage.tsx` — migrated to admin seam constants and `adminPath`.
- `frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx` — migrated to `ADMIN_LOGS_TRANSFERS_PATH` and `adminApiRequest`.
- `frontend/src/components/admin/AdminObservabilityTimeseriesDashboardRuntime.tsx` — migrated to `adminApiRequest`.
- `ops/i18n/audit_locale_placeholders.js` — fixed CommonJS `__dirname`.
- `ops/i18n/audit_identical_to_english.js` — fixed CommonJS `__dirname`.
- `tests/architecture/test_frontend_buttons_api_i18n_drift_audit.py` — new guard for admin seams, static hrefs and i18n scripts.
- `frontend/package-lock.json` — npm audit fix, `form-data@4.0.6`.
- Next safe cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.

# v170.92 / cycle 1516 — DB Drift Closure / VIP-NFT TonConnect Sync Repair

- `docs/NORM/DB_DRIFT_CLOSURE_REPORT.md` — cycle 1516 closure report.
- `docs/NORM/VIP_NFT_TONCONNECT_SYNC_CANON.md` — canonical VIP/NFT wallet resolver: `wallet_bindings` first, `users.ton_wallet` fallback.
- `docs/NORM/BONUS_AWARDS_LEGACY_STATUS.md` — `bonus_awards` legacy/dead-code decision and guard rule.
- `docs/NORM/WALLETS_TONCONNECT_SSOT.md` — TonConnect wallet SSOT update.
- `docs/NORM/DB_DRIFT_MATRIX.md` — cycle 1516 DB drift addendum.
- `backend/app/services/nft_check_service.py` — wallet resolver, batch candidate discovery and health snapshot update.
- `backend/app/routes/me_routes.py` — stale VIP refresh no longer gated by `users.ton_wallet`.
- `backend/app/services/admin/admin_withdrawals_service.py` — `bonus_awards` legacy guard.
- `backend/app/models/withdraw_models.py` — `withdraw_requests.amount` `Numeric(30,8)` and legacy withdrawals constraint documentation.
- `backend/migrations/versions/0001_initial_release_schema.py` — existing-schema repair for `withdraw_requests.amount`.
- `tests/efhc_backend/nft/test_vip_nft_tonconnect_wallet_binding_sync.py` — runtime guard for TonConnect VIP/NFT sync.
- `tests/architecture/test_db_drift_matrix.py` — DB drift architecture guard.
- `reports/generated/db_drift_closure_vip_nft_sync_repair_v170_92.json` — generated metadata.
- `reports/change_cycle_2026-06-15_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.md` — change report.
- Status: local repair done; GitHub CI green, browser proof, live TonConnect proof and release-ready are not claimed.

# v170.91 / cycle 1515 — Fresh CI rerun proof / Visual proof preparation

- `docs/NORM/FRESH_CI_RERUN_VISUAL_PROOF_PREP.md` — honest proof boundary and visual/button-click preparation matrix.
- `docs/cycles/WORK_CYCLES_1515_FRESH_CI_RERUN_VISUAL_PREP.md` — cycle 1515 cycle note.
- `tests/architecture/test_fresh_ci_rerun_visual_prep.py` — guard against false CI/visual/release claims and runtime-code transfer from reference layers.
- `reports/generated/fresh_ci_rerun_visual_prep_v170_91.json` — generated proof metadata.
- `reports/change_cycle_2026-06-15_v170_91_cycle_1515_fresh_ci_rerun_visual_prep.md` — change report.
- Status: local validation passed; fresh GitHub CI and browser click proof are not claimed.

## Cycle 1511 — GitHub CI log repair

- `docs/NORM/GITHUB_CI_LOG_REPAIR.md` — CI log repair canon
  for `logs_74007805923.zip`.
- `tests/architecture/test_github_ci_log_repair.py` — guard for
  the repaired ruff/mypy/pytest root causes.
- `reports/generated/github_ci_log_repair_v170_87.json` — generated
  proof status for v170.87.

# v170.86 / cycle 1510 — Wallet model replacement trace

- `docs/NORM/WALLET_MODEL_REPLACEMENT_TRACE.md` — exact replacement
  trace for removed `backend/app/models/wallet_models.py`.
- Replacement answer: `backend/app/models/wallets_models.py::WalletBinding`.
- Canonical address helper:
  `backend/app/lib/ton_address.py::canonicalize_ton_address`.
- Active runtime service: `backend/app/services/wallets_service.py`.
- Active proof service:
  `backend/app/services/tonconnect_proof_service.py`.
- Guard: `tests/architecture/test_wallet_model_replacement_trace.py`.

# v170.85 / cycle 1509 — PACK-03 final cleanup

- `docs/audits/EFHC_PACK_03_FINAL_CLEANUP_AND_CONSISTENCY_TZ.md` — self-contained PACK-03 task source.
- `docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md` — direct EFHC payment intent canon.
- `docs/NORM/WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md` — watcher incoming deposit accounting canon.
- `docs/SSOT/PAYMENT_INTENT_SSOT.md` — payment intent SSOT.
- `docs/SSOT/WATCHER_ACCOUNTING_SSOT.md` — watcher accounting SSOT.
- `docs/NORM/DB_DRIFT_MATRIX.md` — full DB drift matrix.
- `docs/NORM/ADMIN_BUTTON_COVERAGE_MATRIX.md` — admin button/action coverage matrix.
- `docs/NORM/FRONTEND_API_I18N_CONSISTENCY.md` — frontend/API/i18n consistency matrix.
- `docs/NORM/RELEASE_PROOF_STATUS.md` — honest release proof status.
- `backend/app/services/payment_reconciliation_service.py` — direct EFHC repeated-payment accounting guard.
- `tests/architecture/test_wallet_legacy_names_cleanup.py` — wallet legacy naming cleanup guard.
- `tests/test_direct_efhc_payment_intent_canon.py` — direct EFHC intent canon guard.
- `tests/test_watcher_incoming_deposit_accounting_canon.py` — watcher accounting canon guard.
- `tests/architecture/test_full_db_drift_matrix.py` — DB drift matrix guard.
- `tests/architecture/test_admin_button_coverage_matrix.py` — admin button coverage guard.
- `tests/architecture/test_frontend_api_i18n_consistency.py` — frontend/API/i18n guard.

# v170.84 / cycle 1508 — PACK-02 tails wallet cleanup

- `docs/NORM/ADMIN_WALLET_LEGACY_CLEANUP.md` — removal of the legacy admin `crypto_wallets` wallet contour.
- `docs/NORM/WALLET_BINDINGS_CANONICAL_BACKFILL.md` — existing-DB backfill for historical `wallet_bindings.wallet_address` formats.
- `backend/migrations/versions/0001_initial_release_schema.py` — active 0001-only migration layer with `_backfill_wallet_bindings_canonical(conn)`.
- `backend/app/services/admin/admin_facade.py` — no longer imports or delegates to `AdminWalletsService`.
- `tests/architecture/test_admin_wallet_legacy_cleanup.py` — guard for removed `admin_wallets_service.py` and `crypto_wallets` runtime.
- `tests/architecture/test_wallet_bindings_canonical_backfill.py` — guard for canonical backfill in 0001.

# v170.83 / cycle 1507 — PACK-02 TON Wallet Canon

- `docs/audits/EFHC_PACK_02_TON_WALLET_CANON_ADMIN_PAYOUT_CANON_TZ.md` — self-contained PACK-02 task source.
- `docs/SSOT/WALLET_IDENTITY_SSOT.md` — SSOT for canonical TON wallet identity and active wallet proof path.
- `docs/NORM/WALLET_CANONICAL_ADDRESS_NORM.md` — TON canonical address norm.
- `docs/NORM/WALLET_BINDING_CANON.md` — single active wallet binding mechanism canon.
- `docs/NORM/ADMIN_PAYOUT_CANON.md` — admin payout canon: operator wallet-flow does not grant treasury/private funds access.
- `docs/NORM/DB_DRIFT_MATRIX.md` — wallet-related DB drift status.
- `backend/app/lib/ton_address.py` — dependency-free canonical TON address helper.
- `backend/app/services/wallets_service.py` — active TonConnect wallet binding service.
- `backend/app/routes/wallets_routes.py` — active wallet routes using TonConnect proof.
- `backend/app/services/watcher_service.py` — watcher lookup uses canonical `wallet_bindings.wallet_address`.
- `tests/test_wallet_canonical_address.py` — canonical address regression tests.
- `tests/architecture/test_single_wallet_binding_canon.py` — single wallet binding canon guard.
- `tests/architecture/test_admin_payout_canon.py` — admin payout canon guard.
- `reports/generated/ton_wallet_canon_admin_payout_v170_83.json` — generated cycle evidence.
- `reports/change_cycle_2026-06-13_v170_83_cycle_1507_ton_wallet_canon_admin_payout.md` — change report.

Песочница использована только как reference/navigation/prototype layer.
Runtime-код не переносился.

Grafana использована только как visual-pattern/reference layer.
Runtime-код не переносился.

# Work item 1505 — GitHub CI Rerun Proof / v170.81

- Input: `EFHC_Bot_v170_80_cycle_1504_grafana_pattern_map_completion.zip`.
- Output: `EFHC_Bot_v170_81_cycle_1505_github_ci_rerun_proof.zip`.
- Log: `logs_73728142603.zip`.
- Norm: `docs/NORM/GITHUB_CI_RERUN_PROOF.md`.
- Cycle doc: `docs/cycles/WORK_CYCLES_1505_GITHUB_CI_RERUN_PROOF.md`.
- Guard: `tests/architecture/test_github_ci_rerun_proof.py`.
- Report: `reports/generated/github_ci_rerun_proof_v170_81.json`.
- Change report: `reports/change_cycle_2026-06-12_v170_81_cycle_1505_github_ci_rerun_proof.md`.
- Log verdict: red CI rerun repaired locally; GitHub CI green is not
  claimed for v170.81 until a fresh rerun proves it.

# v170.80 / cycle 1504 — DASH-03 Grafana Pattern Map Completion

- `docs/NORM/GRAFANA_PATTERN_MAP_COMPLETION.md`
- `docs/NORM/GRAFANA_PATTERN_MAP_COMPLETION_ELEMENT_ANALYSIS.md`
- `docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md`
- `docs/cycles/WORK_CYCLES_1504_DASH_03_GRAFANA_PATTERN_MAP_COMPLETION.md`
- `reports/generated/grafana_pattern_map_completion_v170_80.json`
- `reports/change_cycle_2026-06-12_v170_80_cycle_1504_grafana_pattern_map_completion.md`
- `tests/architecture/test_grafana_pattern_map_completion.py`

Cycle anchors:

- Closed audit finding: `DASH-03`.
- Completed Grafana pattern map sections: Grid layout, Drill-down and
  Empty/error states.
- Audit/TZ repair block `1501–1504` is closed locally.
- No runtime, CSS, backend, OpenAPI, migration, dependency, lock file,
  CI/workflow, economy or money-flow change.
- Next safe cycle: `1505 — GitHub CI Rerun Proof`.
- Песочница remains reference/navigation/prototype layer only.
- Grafana remains visual-pattern/reference layer only.

# v170.79 / cycle 1503 — DASH-02 Admin Domain Report Endpoints

- `backend/app/routes/admin_reports_routes.py`
- `docs/NORM/ADMIN_DOMAIN_REPORT_ENDPOINTS_FOUNDATION.md`
- `docs/cycles/WORK_CYCLES_1503_DASH_02_ADMIN_DOMAIN_REPORT_ENDPOINTS_FOUNDATION.md`
- `reports/generated/admin_domain_report_endpoints_v170_79.json`
- `reports/change_cycle_2026-06-12_v170_79_cycle_1503_admin_domain_report_endpoints_foundation.md`
- `tests/architecture/test_admin_domain_report_endpoints.py`
- `docs/NORM/CHATS/33.md`

Cycle anchors:

- Closed audit finding: `DASH-02`.
- Added five admin-only read-only report endpoints.
- OpenAPI route-source snapshot and frontend admin seams synced.
- No migration, money-flow, economy or write-route change.
- Next safe cycle: `1504 — DASH-03 Grafana Pattern Map Completion`.
- Песочница remains reference/navigation/prototype layer only.
- Grafana remains visual-pattern/reference layer only.

# v170.78 / cycle 1502 — DASH-01 Orphan Bank Dashboard Deletion

- `docs/NORM/ORPHAN_BANK_DASHBOARD_DELETION.md`
- `docs/cycles/WORK_CYCLES_1502_DASH_01_ORPHAN_BANK_DASHBOARD_DELETION.md`
- `reports/generated/orphan_bank_dashboard_deletion_v170_78.json`
- `reports/change_cycle_2026-06-12_v170_78_cycle_1502_dash_01_orphan_bank_dashboard_deletion.md`
- `tests/architecture/test_orphan_bank_dashboard_deleted.py`

Cycle anchors:

- Closed audit finding: `DASH-01`.
- Deleted orphan `AdminInteractiveBankDashboard.tsx`.
- Canonical runtime replacement remains `AdminBankDashboardRuntime.tsx`.
- No backend/OpenAPI/money-flow/runtime bank behavior change.
- Remaining audit/TZ findings: `DASH-02`, `DASH-03`.
- Next safe cycle: `1503 — DASH-02 Admin Domain Report Endpoints Foundation`.
- Песочница remains reference/navigation/prototype layer only; Runtime-код не переносился.
- Grafana remains visual-pattern/reference layer only; Runtime-код не переносился.

# v170.77 / cycle 1501 — Dashboard UI Kit Consolidation QA

- `docs/NORM/DASHBOARD_UI_KIT_CONSOLIDATION_QA.md`
- `docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`
- `docs/audits/AUDIT_TZ_REPAIR_1501_1504.md`
- `docs/cycles/WORK_CYCLES_1501_DASHBOARD_UI_KIT_CONSOLIDATION_QA.md`
- `reports/generated/dashboard_ui_kit_consolidation_qa_v170_77.json`
- `reports/change_cycle_2026-06-12_v170_77_cycle_1501_dashboard_ui_kit_consolidation_qa.md`
- `frontend/src/lib/dashboard/componentContract.ts`
- `tests/architecture/test_dashboard_component_contract.py`
- `tests/architecture/test_dashboard_ui_kit_consolidation_qa.py`

Cycle anchors:

- Closed audit finding: `CYC-1459`.
- `DashboardPanelAction` supports `onClick` and `actionKind`.
- Contract version is `EFHC_DASHBOARD_CONTRACT_V2`.
- Remaining audit/TZ findings: `DASH-01`, `DASH-02`, `DASH-03`.
- Next safe cycle: `1502 — DASH-01 Orphan AdminInteractiveBankDashboard deletion`.
- No backend/OpenAPI/money-flow/runtime behavior change.
- Песочница remains reference/navigation/prototype layer only; Runtime-код не переносился.
- Grafana remains visual-pattern/reference layer only; Runtime-код не переносился.

# v170.76 / cycle 1500 — Final Range Closure / Transition to 1501–1600

- `docs/NORM/FINAL_RANGE_CLOSURE.md`
- `docs/cycles/WORK_CYCLES_1500_FINAL_RANGE_CLOSURE.md`
- `reports/generated/final_range_1401_1500_closure_v170_76.json`
- `reports/change_cycle_2026-06-11_v170_76_cycle_1500_final_range_closure.md`
- `tests/architecture/test_final_range_closure.py`

Closure anchors:

- Range `1401–1500` is closed: `100 / 100`, remaining `0 / 100`.
- Dashboard direction `1455–1496` remains closed/frozen: `42 / 42`, remaining `0 / 42`.
- Next range: `1501–1600`.
- Next safe cycle: `1501 — Dashboard UI Kit Consolidation QA`.
- No release-ready, GitHub CI green, browser screenshot proof, live Telegram proof or real TonConnect proof is claimed.
- Песочница remains reference/navigation/prototype layer only; runtime code was not copied.
- Grafana remains visual-pattern/reference layer only; runtime code was not copied.

# v170.73 / cycle 1497 — Dashboard Direction Audit Follow-up / Future Range Foundation

- `docs/NORM/DASHBOARD_DIRECTION_AUDIT_FOLLOWUP.md`
- `docs/NORM/DASHBOARD_DIRECTION_AUDIT_FOLLOWUP_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1497_DASHBOARD_DIRECTION_AUDIT_FOLLOWUP.md`
- `docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`
- `reports/generated/dashboard_direction_audit_followup_v170_73.json`
- `reports/change_cycle_2026-06-10_v170_73_cycle_1497_dashboard_direction_audit_followup.md`
- `tests/architecture/test_dashboard_direction_audit_followup.py`

Audit repair anchors:

- Orphan synthetic `buildSeries` risk closed.
- UI Kit gap closed through reusable wrapper exports.
- Admin domain report endpoints frozen into `1501–1600` as `admin_domain_report_endpoints_backlog`.

# v170.72 / cycle 1496 — Dashboard Direction Handoff / Backlog Freeze

- `docs/NORM/DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md`
- `docs/NORM/DASHBOARD_DIRECTION_HANDOFF_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1496_DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md`
- `reports/generated/dashboard_direction_handoff_backlog_freeze_v170_72.json`
- `reports/change_cycle_2026-06-10_v170_72_cycle_1496_dashboard_direction_handoff_backlog_freeze.md`
- `tests/architecture/test_dashboard_direction_handoff_backlog_freeze.py`
- `frontend/src/components/dashboard/ProgressSystem.tsx`
- `frontend/src/components/dashboard/MiniCharts.tsx`
- `frontend/src/components/dashboard/EnergyDashboardRuntime.tsx`
- `frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx`
- `frontend/src/components/dashboard/RanksDashboardRuntime.tsx`
- `frontend/src/pages/index.tsx`
- `frontend/src/pages/panels.tsx`
- `frontend/public/locale/*.json`

Dashboard direction is closed: `42 / 42`. Public user-facing dashboards have a 13-language locale invariant. Admin dashboards remain Russian operator surface unless a separate admin i18n cycle is approved.

# v170.70 / cycle 1494 — Accessibility / Localization / Overflow QA

- `docs/NORM/ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA.md`
- `docs/NORM/ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1494_ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA.md`
- `reports/generated/accessibility_localization_overflow_qa_v170_70.json`
- `reports/change_cycle_2026-06-10_v170_70_cycle_1494_accessibility_localization_overflow_qa.md`
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`
- `frontend/src/components/dashboard/ProgressSystem.tsx`
- `frontend/src/components/admin/AdminObservabilityTimeseriesDashboardRuntime.tsx`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/*.json`
- `tests/architecture/test_accessibility_localization_overflow_qa.py`

Next safe cycle: `1495 — Final Dashboard Visual Audit / Screenshot Proof`.

# v170.69 / cycle 1493 — Visual Performance / Bundle Safety

- `docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY.md`
- `docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1493_VISUAL_PERFORMANCE_BUNDLE_SAFETY.md`
- `reports/generated/visual_performance_bundle_safety_v170_69.json`
- `reports/change_cycle_2026-06-10_v170_69_cycle_1493_visual_performance_bundle_safety.md`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_visual_performance_bundle_safety.py`

Next safe cycle: `1494 — Accessibility / Localization / Overflow QA`.

# v170.67 / cycle 1491 — Real Time-Series Backend Contracts

- `docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS.md`
- `docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1491_REAL_TIME_SERIES_BACKEND_CONTRACTS.md`
- `reports/generated/real_time_series_backend_contracts_v170_67.json`
- `reports/generated/green_ci_log_proof_v170_67.json`
- `reports/change_cycle_2026-06-10_v170_67_cycle_1491_real_time_series_backend_contracts.md`
- `backend/app/routes/admin_observability_routes.py`
- `backend/openapi/openapi.json`
- `frontend/src/lib/api/generated/adminSeams.ts`
- `tests/architecture/test_real_time_series_backend_contracts.py`

Next safe cycle: `1492 — Synthetic Data Cleanup / Truth Hardening`.

# v170.66 / cycle 1490 — Admin Logs / Events Dashboard

- `docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD.md`
- `docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1490_ADMIN_LOGS_EVENTS_DASHBOARD.md`
- `reports/generated/admin_logs_events_dashboard_v170_66.json`
- `reports/change_cycle_2026-06-09_v170_66_cycle_1490_admin_logs_events_dashboard.md`
- `frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `tests/architecture/test_admin_logs_events_dashboard.py`

Next safe cycle: `1491 — Real Time-Series Backend Contracts`.

# v170.64 / cycle 1488 — Admin Tasks / Referrals Dashboard Upgrade

- `docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1488_ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_tasks_referrals_dashboard_upgrade_v170_64.json`
- `reports/change_cycle_2026-06-08_v170_64_cycle_1488_admin_tasks_referrals_dashboard_upgrade.md`
- `frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `tests/architecture/test_admin_tasks_referrals_dashboard_upgrade.py`
- `docs/NORM/CHATS/31.md`
- `docs/NORM/CHATS/32.md`

Next safe cycle: `1489 — Admin System Health Dashboard`.

# v170.63 / cycle 1487 — Admin Panels Dashboard Upgrade

- `docs/NORM/ADMIN_PANELS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_PANELS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1487_ADMIN_PANELS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_panels_dashboard_upgrade_v170_63.json`
- `frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `tests/architecture/test_admin_panels_dashboard_upgrade.py`
- Truth model: `raw + derived snapshot`; no synthetic admin analytics.
- Panels dashboard is read-only; activate/deactivate stay guarded.
- 180-day lifecycle and generation logic are not changed.
- 1485 deposits progress coverage UX debt is closed by showing Pending intents as the third denominator share.
- Grafana and Песочница are reference-only layers.
- Next safe cycle: `1488 — Admin Tasks / Referrals Dashboard Upgrade`.

# v170.62 / cycle 1486 — Admin Withdrawals Dashboard Upgrade

- `docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1486_ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_withdrawals_dashboard_upgrade_v170_62.json`
- `frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`
- `tests/architecture/test_admin_withdrawals_dashboard_upgrade.py`
- Truth model: `raw + derived snapshot`; no synthetic admin analytics.
- Withdrawals dashboard is read-only; pay/approve/reject/repair stay guarded.
- Final statuses are display-only and are not overwritten by dashboard code.
- Grafana and Песочница are reference-only layers.
- Next safe cycle: `1487 — Admin Panels Dashboard Upgrade`.

# v170.61 / cycle 1485 — Admin Deposits Dashboard Upgrade

- `docs/NORM/ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_DEPOSITS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1485_ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_deposits_dashboard_upgrade_v170_61.json`
- `frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `tests/architecture/test_admin_deposits_dashboard_upgrade.py`
- Truth model: `raw + derived snapshot`; no synthetic admin analytics.
- Deposit dashboard is read-only; replay/exception/force fulfill stay guarded.
- Grafana and Песочница are reference-only layers.
- Next safe cycle: `1486 — Admin Withdrawals Dashboard Upgrade`.

# v170.60 / cycle 1484 — Admin Users Dashboard Upgrade

- `docs/NORM/ADMIN_USERS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_USERS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1484_ADMIN_USERS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_users_dashboard_upgrade_v170_60.json`
- `frontend/src/components/admin/AdminUsersDashboardRuntime.tsx`
- `frontend/src/pages/admin/users.tsx`
- `tests/architecture/test_admin_users_dashboard_upgrade.py`
- Truth model: `raw + derived snapshot`; no synthetic admin analytics.
- Users dashboard is read-only; sensitive actions stay in guarded page controls.
- Grafana and Песочница are reference-only layers.
- Next safe cycle: `1485 — Admin Deposits Dashboard Upgrade`.

# v170.59 / cycle 1483 — Admin Bank Dashboard Upgrade

- `docs/NORM/ADMIN_BANK_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_BANK_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1483_ADMIN_BANK_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_bank_dashboard_upgrade_v170_59.json`
- `frontend/src/components/admin/AdminBankDashboardRuntime.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `tests/architecture/test_admin_bank_dashboard_upgrade.py`
- Truth model: `raw + derived snapshot`; no synthetic admin analytics.
- Bank canon: bank can go negative; no dashboard write bypass.
- Grafana and Песочница are reference-only layers.
- Next safe cycle: `1484 — Admin Users Dashboard Upgrade`.

# Map entry 1482 — v170.58 Admin Reports Grafana-like Upgrade

- Current HEAD: `v170.58 / admin reports grafana-like upgrade`.
- Step: `1482`.
- Cycle title: `1482 — Admin Reports Grafana-like Upgrade`.
- Active document: `docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE.md`.
- Grafana analysis: `docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`.
- Runtime route: `frontend/src/pages/admin/reports.tsx`.
- Guard: `tests/architecture/test_admin_reports_grafana_like_upgrade.py`.
- Truth model: `raw + derived snapshot`; fake time-series are forbidden.
- Safe inspector does not show raw payload, secrets or debug JSON.
- Dashboard layer is read-only and does not add write-flow bypass.
- Economy, backend, DB, OpenAPI, CI/workflows, dependencies, lock files,
  TonConnect/wallet and write/money flows changed: no.
- Grafana remains visual-pattern/reference layer only. Runtime code is not copied.
- Песочница remains reference/navigation/prototype layer only. Runtime code is not copied.

Next safe step: `1483 — Admin Bank Dashboard Upgrade`.

# Map entry 1481 — v170.57 Admin Overview Dashboard Upgrade

- Current HEAD: `v170.57 / admin overview dashboard upgrade`.
- Step: `1481`.
- Cycle title: `1481 — Admin Overview Dashboard Upgrade`.
- Active document: `docs/NORM/ADMIN_OVERVIEW_DASHBOARD_UPGRADE.md`.
- Grafana analysis: `docs/NORM/ADMIN_OVERVIEW_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx`.
- Runtime route: `frontend/src/pages/admin/index.tsx`.
- Guard: `tests/architecture/test_admin_overview_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot`; synthetic admin analytics are forbidden.
- Secrets, raw payload dumps and debug JSON are forbidden in overview panels.
- Dashboard layer is read-only and does not add write-flow bypass.
- Economy, backend, DB, OpenAPI, CI/workflows, dependencies, lock files,
  TonConnect/wallet and write/money flows changed: no.
- Grafana remains visual-pattern/reference layer only. Runtime code is not copied.
- Песочница remains reference/navigation/prototype layer only. Runtime code is not copied.

Next safe step: `1482 — Admin Reports Grafana-like Upgrade`.

# Work step 1480 — v170.56 Web Profile / Account Center Dashboard Polish

- Current HEAD: `v170.56 / web profile account center dashboard polish`.
- Step: `1480`.
- Cycle title: `1480 — Web Profile / Account Center Dashboard Polish`.
- Active document: `docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH.md`.
- Grafana analysis: `docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_GRAFANA_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/dashboard/WebProfileAccountDashboard.tsx`.
- Runtime route: `frontend/src/pages/web-profile.tsx`.
- Feature page: `frontend/src/features/profile/WebProfilePage.tsx`.
- Guard: `tests/architecture/test_web_profile_account_center_dashboard_polish.py`.
- Truth model: `raw + derived snapshot`; fake account history is forbidden.
- Raw payload, raw `tg_id`, initData and debug JSON are forbidden in the public dashboard.
- Wallet/history write flows are not changed and are not bypassed.
- Economy, backend, DB, OpenAPI, CI/workflows, dependencies, lock files,
  TonConnect/wallet and write/money flows changed: no.
- Grafana remains visual-pattern/reference layer only. Runtime code is not copied.
- Песочница remains reference/navigation/prototype layer only. Runtime code is not copied.

Next safe step: `1481 — Admin Overview Dashboard Upgrade`.

# Map entry 1479 — v170.55 Exchange Dashboard Support Widgets

- Current HEAD: `v170.55 / exchange dashboard support widgets`.
- Step: `1479`.
- Cycle title: `1479 — Exchange Dashboard Support Widgets`.
- Active document: `docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS.md`.
- Grafana analysis: `docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS_GRAFANA_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx`.
- Runtime route: `frontend/src/pages/exchange.tsx`.
- Guard: `tests/architecture/test_exchange_dashboard_support_widgets.py`.
- Truth model: `raw + derived snapshot`; fake exchange history is forbidden.
- Canonical rule remains `1 kWh = 1 EFHC`; reverse exchange is forbidden.
- Dashboard widgets do not call write APIs and do not bypass ExchangePanel.
- Economy, backend, DB, OpenAPI, CI/workflows, dependencies, lock files,
  TonConnect/wallet and write/money flows changed: no.
- Grafana remains visual-pattern/reference layer only. Runtime code is not copied.
- Песочница remains reference/navigation/prototype layer only. Runtime code is not copied.

Next safe step: `1481 — Admin Overview Dashboard Upgrade`.

# Cycle 1478 — v170.54 Referrals Dashboard Upgrade

- Active document: `docs/NORM/REFERRALS_DASHBOARD_UPGRADE.md`.
- Grafana analysis: `docs/NORM/REFERRALS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx`.
- Runtime route: `frontend/src/pages/referrals.tsx`.
- Guard: `tests/architecture/test_referrals_dashboard_upgrade.py`.
- Generated report: `reports/generated/referrals_dashboard_upgrade_v170_54.json`.
- Truth model: `raw + derived snapshot`.
- Source endpoint: `/referrals/stats/me`.
- Fake referral history added: no.
- Public raw `tg_id` visible in dashboard: no.
- Referral bonus rule changed: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

Next safe step: `1479 — Exchange Dashboard Support Widgets`.

# Cycle 1477 — v170.53 Tasks Dashboard Upgrade

- Active document: `docs/NORM/TASKS_DASHBOARD_UPGRADE.md`.
- Grafana analysis: `docs/NORM/TASKS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/dashboard/TasksDashboardRuntime.tsx`.
- Runtime route: `frontend/src/pages/tasks.tsx`.
- Guard: `tests/architecture/test_tasks_dashboard_upgrade.py`.
- Generated report: `reports/generated/tasks_dashboard_upgrade_v170_53.json`.
- Truth model: `raw + derived snapshot`.
- Public execution history visible on `/tasks`: no.
- Backend logs / idempotency debug visible publicly: no.
- Fake runtime tasks added: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

Next safe step: `1478 — Referrals Dashboard Upgrade`.

# Cycle 1476 — v170.52 Leaderboard Visual System

- Active document: `docs/NORM/LEADERBOARD_VISUAL_SYSTEM.md`.
- Grafana analysis: `docs/NORM/LEADERBOARD_VISUAL_SYSTEM_GRAFANA_ELEMENT_ANALYSIS.md`.
- Shared component: `frontend/src/components/dashboard/LeaderboardVisualSystem.tsx`.
- Runtime integration: `frontend/src/components/dashboard/RanksDashboardRuntime.tsx`.
- Guard: `tests/architecture/test_leaderboard_visual_system.py`.
- Generated report: `reports/generated/leaderboard_visual_system_v170_52.json`.
- Truth model: `raw + derived snapshot`.
- Fake runtime leaderboard rows added: no.
- Raw `tg_id` visible in public UI: no.
- Internal 12 Energy levels exposed in Ranks: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

Next safe step: `1477 — Tasks Dashboard Upgrade`.

# Cycle 1475 — v170.51 Ranks Dashboard Runtime Port

- Active document: `docs/NORM/RANKS_DASHBOARD_RUNTIME_PORT.md`.
- Grafana analysis: `docs/NORM/RANKS_DASHBOARD_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md`.
- Runtime component: `frontend/src/components/dashboard/RanksDashboardRuntime.tsx`.
- Runtime route: `frontend/src/pages/ranks.tsx`.
- Guard: `tests/architecture/test_ranks_dashboard_runtime_port.py`.
- Generated report: `reports/generated/ranks_dashboard_runtime_port_v170_51.json`.
- Truth model: `raw + derived snapshot`.
- Runtime `/ranks` changed: yes, UI-only read-only dashboard.
- Fake `rank_pos=1` fallback removed: yes.
- Raw `tg_id` visible in public UI: no.
- Internal 12 Energy levels exposed in Ranks: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

Next safe step: `1476 — Leaderboard Visual System`.

# Cycle 1474 — v170.50 Ranks Dashboard Sandbox Prototype

- Active document: `docs/NORM/RANKS_DASHBOARD_SANDBOX_PROTOTYPE.md`.
- Grafana analysis: `docs/NORM/RANKS_DASHBOARD_SANDBOX_GRAFANA_ELEMENT_ANALYSIS.md`.
- Sandbox component: `frontend/src/components/dashboard/RanksDashboardSandboxPrototype.tsx`.
- Guard: `tests/architecture/test_ranks_dashboard_sandbox_prototype.py`.
- Generated report: `reports/generated/ranks_dashboard_sandbox_prototype_v170_50.json`.
- Truth model: `synthetic_preview`.
- Runtime `/ranks` changed: no.
- Raw `tg_id` exposed: no.
- Internal 12 Energy levels exposed in Ranks: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

Next safe step: `1475 — Ranks Dashboard Runtime Port`.

# Cycle 1473 — v170.49 Panel Cards Deep Polish

Cycle 1473 polishes panel cards and hardens sandbox preview formulas.

Primary files:

- `docs/NORM/PANEL_CARDS_DEEP_POLISH.md`;
- `docs/NORM/PANEL_CARDS_DEEP_POLISH_GRAFANA_ELEMENT_ANALYSIS.md`;
- `docs/cycles/WORK_CYCLES_1473_PANEL_CARDS_DEEP_POLISH.md`;
- `reports/generated/panel_cards_deep_polish_v170_49.json`;
- `reports/change_cycle_2026-06-07_v170_49_cycle_1473_panel_cards_deep_polish.md`;
- `tests/architecture/test_panel_cards_deep_polish.py`;
- `frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx`;
- `frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx`;
- `frontend/src/pages/panels.tsx`;
- `frontend/src/styles/globals.css`;
- `frontend/public/locale/*.json`.

Runtime scope:

- stronger panel-card hierarchy;
- micro states: newly active, active cycle, expiring soon, archived complete;
- explicit kWh and kWh/s units;
- formatted UTC dates;
- one lifecycle progress per archived card;
- accessibility labels.

Sandbox formula scope:

- old hardcoded inconsistent rates removed;
- preview rates derived by `generated_kwh / period_seconds`;
- preview remains `synthetic_preview` only.

Boundaries:

- activation price changed: no;
- debit order changed: no;
- backend/OpenAPI/dependencies/lock files changed: no;
- write/money flow changed: no;
- Grafana runtime code copied: no;
- Песочница runtime code copied: no.

Next safe step: `1474 — Ranks Dashboard Sandbox Prototype`.

# Cycle 1472 — v170.48 Panels Portfolio Runtime Port

Cycle 1472 ports the Panels Portfolio Dashboard into live `/panels`.

Primary files:

- `docs/NORM/PANELS_PORTFOLIO_RUNTIME_PORT.md`;
- `docs/NORM/PANELS_PORTFOLIO_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md`;
- `docs/cycles/WORK_CYCLES_1472_PANELS_PORTFOLIO_RUNTIME_PORT.md`;
- `reports/generated/panels_portfolio_runtime_port_v170_48.json`;
- `reports/change_cycle_2026-06-07_v170_48_cycle_1472_panels_portfolio_runtime_port.md`;
- `tests/architecture/test_panels_portfolio_runtime_port.py`;
- `frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx`;
- `frontend/src/pages/panels.tsx`;
- `frontend/src/styles/globals.css`.

Runtime scope:

- active/archive filter connected to existing tab state;
- raw panels summary;
- derived loaded-list metrics;
- 180-day lifecycle progress;
- real panel cards from current loaded records;
- no synthetic runtime data;
- no real time-series claim.

Boundaries:

- activation price changed: no;
- debit order changed: no;
- backend/OpenAPI/dependencies/lock files changed: no;
- write/money flow changed: no;
- Grafana runtime code copied: no;
- Песочница runtime code copied: no.

Next safe step: `1473 — Panel Cards Deep Polish`.

# Cycle 1471 — v170.47 Panels Portfolio Sandbox Prototype

Cycle 1471 creates a sandbox-only Panels Portfolio Dashboard prototype.

Primary files:

- `docs/NORM/PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`;
- `docs/NORM/PANELS_PORTFOLIO_SANDBOX_GRAFANA_ELEMENT_ANALYSIS.md`;
- `docs/cycles/WORK_CYCLES_1471_PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`;
- `reports/generated/panels_portfolio_sandbox_prototype_v170_47.json`;
- `reports/change_cycle_2026-06-07_v170_47_cycle_1471_panels_portfolio_sandbox_prototype.md`;
- `tests/architecture/test_panels_portfolio_sandbox_prototype.py`;
- `frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx`;
- `frontend/src/styles/globals.css`.

Prototype scope:

- portfolio summary;
- active/archive state filter;
- period filter;
- 180-day lifecycle countdown;
- individual panel cards;
- synthetic portfolio trend;
- distribution preview;
- activity strip preview;
- truth/safety boundary.

Boundaries:

- runtime `/panels` route changed: no;
- panel activation/write flow changed: no;
- economy/backend/OpenAPI/dependencies/lock files changed: no;
- Grafana runtime code copied: no;
- Песочница runtime code copied: no.

Next safe step: `1472 — Panels Portfolio Runtime Port`.

# Cycle 1470 — v170.46 Energy Dashboard Visual QA

Cycle 1470 performs visual QA over the runtime Energy Dashboard introduced in cycle 1469.

Primary files:

- `docs/NORM/ENERGY_DASHBOARD_VISUAL_QA.md`;
- `docs/NORM/ENERGY_DASHBOARD_VISUAL_QA_GRAFANA_ELEMENT_ANALYSIS.md`;
- `docs/cycles/WORK_CYCLES_1470_ENERGY_DASHBOARD_VISUAL_QA.md`;
- `reports/generated/energy_dashboard_visual_qa_v170_46.json`;
- `reports/change_cycle_2026-06-07_v170_46_cycle_1470_energy_dashboard_visual_qa.md`;
- `tests/architecture/test_energy_dashboard_visual_qa.py`;
- `frontend/src/components/dashboard/EnergyDashboardRuntime.tsx`;
- `frontend/src/styles/globals.css`;
- `frontend/public/locale/ru.json`.

Visual QA fixes:

- Russian labels now avoid English `raw snapshot` and `derived display`;
- Energy runtime dashboard has explicit `data-energy-dashboard-visual-qa="1470"`;
- mobile overflow hardening is added for long EFHC/kWh values, source labels, freshness labels and rule chips.

Browser proof status:

- local HTTP probe succeeded;
- Chromium/Playwright screenshot capture was environment-blocked with `net::ERR_BLOCKED_BY_ADMINISTRATOR`;
- screenshot proof is not claimed.

Next safe step: `1471 — Panels Portfolio Sandbox Prototype`.

Grafana remains visual-pattern/reference layer only. Runtime code is not copied.

Песочница remains reference/navigation/prototype layer only. Runtime code is not copied.

# Cycle 1468 — v170.44 Dependency Audit Triage

Cycle 1468 repairs supplied CI-log failures and closes npm dependency audit findings before Energy Dashboard Runtime Port.

Primary files:

- `docs/NORM/DEPENDENCY_AUDIT_TRIAGE.md`;
- `docs/NORM/DEPENDENCY_AUDIT_GRAFANA_ELEMENT_ANALYSIS.md`;
- `docs/cycles/WORK_CYCLES_1468_DEPENDENCY_AUDIT_TRIAGE.md`;
- `reports/generated/dependency_audit_triage_v170_44.json`;
- `reports/change_cycle_2026-06-07_v170_44_cycle_1468_dependency_audit_triage.md`;
- `tests/architecture/test_dependency_audit_triage.py`;
- `frontend/package.json`;
- `frontend/package-lock.json`.

Log repair anchors:

- `KERNEL.md` keeps compatibility marker `v170.27 / CI log repair`;
- `frontend/tsconfig.tsbuildinfo` is forbidden and must not exist in release tree.

Dependency repair anchors:

- `npm audit --json` must report `0` vulnerabilities after controlled update;
- no Next.js / React / Tailwind downgrade;
- no `npm audit fix --force`;
- no CI/workflow change.

Next safe step: `1469 — Energy Dashboard Runtime Port`.

Grafana remains visual-pattern/reference layer only. Runtime code is not copied.

Песочница remains reference/navigation/prototype layer only. Runtime code is not copied.

# Cycle 1467 — v170.43 Energy Dashboard Sandbox Prototype

Cycle 1467 creates the Energy Dashboard sandbox prototype for the EFHC Bot Dashboard Visual Direction.

Active anchors:
- `docs/NORM/ENERGY_DASHBOARD_SANDBOX_PROTOTYPE.md`.
- `docs/NORM/ENERGY_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- `frontend/src/components/dashboard/EnergyDashboardSandboxPrototype.tsx`.
- `tests/architecture/test_energy_dashboard_sandbox_prototype.py`.
- `reports/generated/energy_dashboard_sandbox_prototype_v170_43.json`.

Grafana Energy element analysis for EFHC usage:
- `BigValue` -> `SimHeroEnergyCard` and `SimStatCard` for kWh/EFHC values.
- `PercentChange` -> future derived delta label only, never synthetic runtime truth.
- `Sparkline/Sparkline.tsx` -> `SimMiniSparkline` / `SimMiniAreaChart`, EFHC-owned SVG/CSS only.
- `TimeSeriesPanel.tsx` / `TrendPanel.tsx` -> future real time-series panel after read-only backend contracts.
- `DashboardControls.tsx` -> `SimDashboardToolbar` placement discipline.
- `TimeRangePicker.tsx` / `RelativeTimeRangePicker` -> simple 24h/7d/30d `SimPeriodSwitch`.
- `PanelChrome` / `PanelHeader` / `PanelStatus` -> `SimPanelChrome` source/status/freshness discipline.
- `StatusHistoryPanel` / `StateTimelinePanel` -> `SimActivityStrip` activity signal.
- `DashboardGrid` -> `SimDashboardGrid` responsive structure.
- `Variables` -> already covered by cycle 1466; Energy prototype stays light.

No Grafana source code is copied.
Песочница used only as reference/navigation/prototype layer.
Dependency audit follow-up: cycle 1466 `npm ci` reported 5 vulnerabilities (3 moderate, 2 high); lock/dependency repair requires separate permission cycle.

# Cycle 1466 — v170.42 Variables / Filters System

Cycle 1466 creates the shared EFHC-owned variables / filters foundation
for Admin Dashboard Layer and Simulation Dashboard Layer.

Active anchors:
- `docs/NORM/VARIABLES_FILTERS_SYSTEM.md`.
- `frontend/src/components/dashboard/DashboardFilters.tsx`.
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- `tests/architecture/test_variables_filters_system.py`.

Grafana variables/filter analysis for EFHC usage:
- `Variables` -> visual discipline for dashboard variables only.
- `DashboardControls.tsx` -> toolbar/filter placement discipline.
- `TimeRangePicker.tsx` -> admin date range concept only.
- `RelativeTimeRangePicker/` -> period preset discipline.
- `RefreshPicker.tsx` -> must stay separate from filter business truth.
- `PageToolbar.tsx` -> page-level control hierarchy.

Use these as design anchors only. Do not copy Grafana runtime code,
packages, schemas, lock files, CI, scenes runtime or plugins.

Next safe step: `1469 — Energy Dashboard Runtime Port`.

# Cycle 1465 — v170.41 Dashboard Toolbar Foundation

Cycle 1465 creates the shared EFHC-owned toolbar foundation for Admin
Dashboard Layer and Simulation Dashboard Layer.

Active anchors:
- `docs/NORM/DASHBOARD_TOOLBAR_FOUNDATION.md`.
- `frontend/src/components/dashboard/DashboardToolbar.tsx`.
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- `tests/architecture/test_dashboard_toolbar_foundation.py`.

Grafana toolbar analysis for EFHC usage:
- `dashboard-scene/scene/DashboardControls.tsx` -> toolbar layout
  discipline for admin dashboards.
- `DateTimePickers/TimeRangePicker.tsx` -> admin time range
  picker concept only.
- `DateTimePickers/RelativeTimeRangePicker/` -> compact relative
  range presets for future admin filters.
- `DateTimePickers/TimeRangeInput.tsx` -> future safe date input
  reference only.
- `RefreshPicker/RefreshPicker.tsx` -> refresh and auto-refresh
  concept only.
- `PageLayout/PageToolbar.tsx` -> page toolbar hierarchy.
- `ToolbarButton/ToolbarButton.tsx` -> compact toolbar action
  discipline.

Use these as design anchors only. Do not copy Grafana runtime code,
packages, schemas, lock files, CI, scenes runtime or plugins.

Next safe step: `1466 — Variables / Filters System`.

# Cycle 1462 — v170.38 Panel Chrome Foundation

Cycle 1462 creates the shared EFHC-owned panel chrome foundation for
Admin Dashboard Layer and Simulation Dashboard Layer.

Active anchors:
- `docs/NORM/PANEL_CHROME_FOUNDATION.md`.
- `frontend/src/components/dashboard/PanelChrome.tsx`.
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- `tests/architecture/test_panel_chrome_foundation.py`.

Grafana PanelChrome analysis for EFHC usage:
- `PanelChrome/PanelChrome.tsx` -> shared `PanelChrome` shell.
- `PanelChrome/PanelStatus.tsx` -> status badge vocabulary.
- `PanelChrome/PanelMenu.tsx` -> safe actions slot only.
- `PanelChrome/PanelDescription.tsx` -> subtitle/source text.
- `PanelChrome/HoverWidget.tsx` -> future safe details affordance.
- `PanelHeader/PanelHeaderMenuWrapper.tsx` -> future menu wrapper.
- `PanelHeader/PanelHeaderNotice.tsx` -> future stale/error notice.
- `PanelInspector.tsx` -> safe inspector drawer only.

Use these as design anchors only. Do not copy Grafana runtime code,
packages, schemas, lock files, CI, scenes runtime or plugins.

Next safe step: `1463 — Progress System Foundation`.

# Cycle 1461 — v170.37 Admin Dashboard UI Kit Foundation

Cycle 1461 adds the EFHC-owned Admin Dashboard UI Kit foundation and a
more detailed Grafana element usage map for future code work.

Active anchors:
- `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`.
- `docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md`.
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- `frontend/src/styles/globals.css`.
- `tests/architecture/test_admin_dashboard_ui_kit_foundation.py`.

Grafana elements mapped for EFHC implementation:
- `PanelChrome` -> `AdminPanelChrome` / future `SimPanelChrome`.
- `PanelHeader` -> `AdminPanelHeader`.
- `PanelStatus` -> `AdminPanelStatus`.
- `PanelMenu` -> safe panel actions only.
- `DashboardGrid` -> `AdminDashboardGrid` / `SimDashboardGrid`.
- `DashboardPageProxy` -> `AdminDashboardPage` / route shell.
- `DashboardControls` -> `AdminDashboardToolbar`.
- `RefreshPicker` -> future `AdminRefreshPicker`.
- `TimeRangePicker` -> future `AdminTimeRangePicker`.
- `Variables` -> `AdminVariableBar` / `AdminFilterBar`.
- `PanelInspector` -> `AdminPanelInspectorDrawer` safe mode.
- `BigValue` -> `AdminStatusCard` / `AdminTrendCard`.
- `Sparkline` -> EFHC-owned SVG mini chart foundation.

Use these elements as visual discipline only. Do not copy Grafana
runtime code, dependencies, lock files, CI files, backend logic, scenes
runtime, plugins, or schemas into EFHC Bot.

Песочница and Grafana are reference/navigation/prototype layers only.

# Cycle 1460 — v170.36 Simulation Dashboard UI Kit Foundation

Cycle 1460 creates the EFHC-owned Simulation Dashboard UI Kit
foundation and answers the user's dashboard deletion questions.

Active anchors:
- `docs/NORM/SIMULATION_DASHBOARD_UI_KIT_FOUNDATION.md`.
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- `docs/audits/DASHBOARD_DELETION_CHECK_V170_36.md`.
- `reports/generated/simulation_dashboard_ui_kit_foundation_v170_36.json`.
- `tests/architecture/test_simulation_dashboard_ui_kit_foundation.py`.

Preserved old dashboards:
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`.
- `ops/monitoring/grafana/dashboards/backend.json`.
- `ops/monitoring/grafana/dashboards/scheduler.json`.
- `ops/monitoring/grafana/dashboards/ton_watcher.json`.

Strict rule:
- Do not delete old dashboards while adding simulation UI kit.
- Do not copy Grafana runtime code.
- Do not copy Песочница runtime code.
- Do not use preview/synthetic data as runtime truth.

Next safe step: `1461 — Admin Dashboard UI Kit Foundation`.

# Cycle 1458 — v170.34 Dashboard Design Tokens Foundation

Cycle 1458 creates the EFHC-owned dashboard design token layer.

Active anchors:

- `docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`.
- `frontend/src/styles/globals.css`.
- `reports/generated/dashboard_design_tokens_foundation_v170_34.json`.
- `tests/architecture/test_dashboard_design_tokens_foundation.py`.
- `docs/cycles/WORK_CYCLES_1458_DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`.

Token families:

- surface, panel and background;
- border and border-strong;
- text, muted and muted-2;
- accent and semantic status colors;
- radius, spacing, shadow and typography.

Strict rule:

- Dashboard tokens are EFHC-owned CSS variables.
- Do not copy Grafana runtime theme code.
- Do not copy Песочница runtime design systems.
- Do not use tokens to change EFHC economy or backend truth.

Next safe step: `1459 — Dashboard Component Contract`.

# Cycle 1457 — v170.33 Grafana Visual Pattern Map

Cycle 1457 creates the active Grafana pattern reference map for
Dashboard Visual Direction.

Active anchors:

- `docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md`.
- `reports/generated/grafana_visual_pattern_map_v170_33.json`.
- `tests/architecture/test_grafana_visual_pattern_map.py`.
- `docs/cycles/WORK_CYCLES_1457_GRAFANA_VISUAL_PATTERN_MAP.md`.

Grafana patterns mapped to EFHC-owned implementations:

| Grafana pattern | EFHC target |
|---|---|
| PanelChrome | `AdminPanelChrome` / `SimPanelChrome` |
| PanelHeader/menu | `AdminPanelHeader` / `AdminPanelActions` |
| DashboardGrid | `AdminDashboardGrid` / `SimDashboardGrid` |
| DashboardPageProxy | `AdminDashboardPage` / `SimDashboardShell` |
| DateTimePickers | `AdminTimeRangePicker` / `SimPeriodSwitch` |
| RefreshPicker | `AdminRefreshPicker` / freshness badge |
| Variables | `AdminVariableBar` / `DashboardFilterBar` |
| Inspector | `AdminPanelInspectorDrawer` safe mode |
| BigValue | `AdminStatCard` / `SimStatCard` |
| Sparkline | dependency-safe EFHC mini charts |

Strict rule:

- Do not copy Grafana runtime code.
- Do not copy Grafana dependencies, lock files, CI files or backend
  logic.
- Use Grafana only as visual-pattern reference.
- Use Песочница only as reference/navigation/prototype layer.

Next safe step: `1458 — Dashboard Design Tokens Foundation`.

# Cycle 1456 — v170.32 Sandbox Dashboard Inventory

Cycle 1456 builds the inventory map for Dashboard Visual Direction.

Active anchors:

- `docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md`.
- `reports/generated/sandbox_dashboard_inventory_v170_32.json`.
- `tests/architecture/test_sandbox_dashboard_inventory.py`.
- `docs/cycles/WORK_CYCLES_1456_SANDBOX_DASHBOARD_INVENTORY.md`.

Inventory result:

- Песочница: 37,532 entries, 32 project buckets.
- Grafana: reference archive checked with `testzip=None`.
- Existing EFHC dashboard candidates mapped.
- Runtime-safe / prototype-only / forbidden / truth-hardening buckets
  created.

Important next step:

- Cycle 1457 must create Grafana Visual Pattern Map.
- Do not copy Grafana runtime code.
- Do not copy Песочница runtime code.
- Use both sources only as reference/prototype/navigation layers.

# Cycle 1455 — v170.31 Dashboard Visual Kernel

Dashboard Visual Direction has started.

Active dashboard navigation:

- Kernel: `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
- Direction: `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Screenshot preparation:
  `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`.
- Machine report:
  `reports/generated/dashboard_visual_kernel_v170_31.json`.

Cycle 1456 start point:

- Build Sandbox Dashboard Inventory.
- Inspect Песочница and current admin/simulation UI components.
- Classify every candidate as runtime-safe, prototype-only or forbidden.
- Do not port runtime code during inventory.

Grafana remains reference only. Use pattern names such as PanelChrome,
DashboardGrid, RefreshPicker, DateTimePickers, PanelHeader and
DashboardPageProxy as visual/navigation anchors, not as copied code.

Runtime code copied from Grafana: no.
Runtime code copied from Песочница: no.

# Cycle 1454 — v170.30 screenshot proof preparation

Cycle 1454 records green CI logs from `logs_72687610241.zip` and
prepares screenshot proof for the Dashboard Visual Direction Plan.

Green log facts:

- ruff: passed;
- mypy: passed;
- bandit: passed;
- backend compileall: passed;
- Alembic upgrade: passed;
- pytest: `1306 passed, 8 skipped, 1 warning`;
- npm ci: passed;
- frontend build: passed;
- gate summary: `OK: all gate steps passed.`

Screenshot preparation anchors:

- `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`;
- `reports/generated/dashboard_screenshot_proof_manifest_v170_30.json`;
- `reports/generated/green_ci_log_proof_v170_30.json`;
- `tests/architecture/test_dashboard_screenshot_proof_preparation.py`;
- `reports/screenshots/public_ui/`;
- `reports/screenshots/admin_ui/`;
- `reports/screenshots/dashboard_visual/`.

Dashboard/Grafana boundary:

- Grafana remains visual-pattern reference only.
- Песочница remains reference/navigation/prototype layer only.
- No runtime code, dependencies, lock files, CI files or backend logic
  were copied.

No screenshots are claimed in cycle 1454. This is preparation only.

# Cycle 1453 — v170.29 CI log repair + Grafana map prep

Cycle 1453 reads `logs_72685602190.zip` first and repairs the exact
pytest-only CI failure from that run.

Log facts:

- ruff: passed;
- mypy: passed;
- Alembic: passed;
- frontend build: passed in the supplied CI log;
- pytest: failed on two stale guard anchors.

Repaired anchors:

- `backend/app/services/admin/admin_bank_service.py` → import block now
  keeps the active guard-compatible admin RBAC order;
- `KERNEL.md` → keeps the `v170.27 / CI log repair` compatibility
  marker while moving active HEAD to `v170.29`.

Grafana reference map for Dashboard Visual Direction Plan:

| Grafana reference path | EFHC usage |
|---|---|
| `packages/grafana-ui/src/components/PanelChrome/` | panel shell and panel menu discipline only |
| `public/app/features/dashboard/dashgrid/DashboardGrid.tsx` | dashboard grid layout reference only |
| `packages/grafana-ui/src/components/RefreshPicker/` | admin refresh picker reference only |
| `packages/grafana-ui/src/components/DateTimePickers/` | time range picker reference only |
| `public/app/features/dashboard/dashgrid/PanelHeader/` | panel header/menu reference only |
| `public/app/features/dashboard/containers/DashboardPageProxy.tsx` | dashboard page boundary reference only |

Strict rule:

- Do not copy Grafana runtime code into EFHC Bot.
- Do not copy Grafana dependencies, lock files, CI files or backend
  logic.
- Use Grafana only as visual-pattern reference.
- Use Песочница only as reference/navigation/prototype layer.

Reports:

- `docs/cycles/WORK_CYCLES_1453_CI_LOG_REPAIR_DASHBOARD_PREP.md`.
- `reports/generated/ci_log_repair_dashboard_prep_v170_29.json`.
- `reports/change_cycle_2026-06-06_v170_29_cycle_1453_ci_log_repair_dashboard_prep.md`.

# Cycle 1450 — visual P0 countdown follow-up repair / v170.26

Cycle 1450 repairs the additional visual/i18n/buttons UX audit verdict
`P0_VISUAL_OR_BUTTON_RISK_FOUND` without changing economy, backend
contracts, DB migrations, CI workflows or lock files.

Navigation anchors:

- `frontend/src/pages/panels.tsx` → countdown display constants;
- `frontend/src/components/admin/AdminWithdrawalsMobileDecisionPanel.tsx` → Russian operator labels;
- `frontend/src/pages/withdraw.tsx` → human balance type in history;
- `frontend/src/pages/admin/tasks.tsx` → Russian task badges;
- `frontend/src/features/hub/HubPage.tsx` → two-span trust rail;
- `frontend/public/locale/*.json` → flat locale files only;
- `tests/architecture/test_frontend_visual_i18n_ux_repair.py` → visual follow-up guard;
- `tests/architecture/test_panel_countdown_source.py` → countdown arithmetic guard;
- `docs/cycles/WORK_CYCLES_1450_VISUAL_P0_COUNTDOWN_FOLLOWUP_REPAIR.md` → cycle closure;
- `reports/generated/frontend_visual_p0_countdown_followup_repair_v170_26.json` → machine report.

Песочница: reference/navigation only. Runtime-code transfer is forbidden
and was not used.

# Cycle 1447 — chat docs intake / v170.23

Cycle 1447 loads user-provided visible chat exports into the canonical
chat documents section.

Navigation anchors:

- `docs/NORM/CHATS/26.md` → chat export for cycles `1391–1400`;
- `docs/NORM/CHATS/27.md` → chat export after `v169.82`;
- `docs/NORM/CHATS/28.md` → archive line `v169.96 → v170.12`;
- `docs/NORM/CHATS/30.md` → visible linkage-line chat `1437–1446`;
- `docs/NORM/CHATS/CHATS_INDEX.md` → canonical chat index;
- `tests/architecture/test_chat_docs_intake.py` → active guard;
- `reports/generated/chat_docs_intake_v170_23.json` → machine report.

Песочница: reference/navigation only. Runtime-code transfer is forbidden
and was not used.

# Cycle 1446 — CI rerun log repair / v170.22

Cycle 1446 reads `logs_72627437860.zip` first and repairs the exact failed gates from
that run.

Navigation anchors:

- `docs/cycles/WORK_CYCLES_1446_CI_RERUN_LOG_REPAIR.md` → cycle closure;
- `reports/generated/ci_log_repair_v170_22.json` → machine log-repair
  report;
- `reports/change_cycle_2026-06-05_v170_22_cycle_1446_ci_rerun_log_repair.md`
  → human change report;
- `tests/architecture/test_ci_log_repair_guards.py` → active regression
  guard;
- `docs/audits/ROUTE_INVENTORY_FREEZE.md` → historical route inventory
  snapshot now explicitly marked with `Status note`.

Log result repaired locally:

- ruff `I001` in admin bank / transactions services;
- pytest historical audit status-note failure.

Песочница: reference/navigation only. Runtime-code transfer is forbidden
and was not used.

# v170.20 cycle 1444 linkage repeat audit + HEALER tail reconciliation

Cycle 1444 repeat-audits the repaired linkage findings from `P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md` and reconciles the HEALER loader/schema tail.

Navigation anchors:
- `ops/linkage/repeat_linkage_healer_audit.py` → local repeat-audit scanner for `F-001…F-008`;
- `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json` → machine repeat-audit report;
- `tests/architecture/test_linkage_repeat_audit_healer_tail.py` → guard for repeat audit + HEALER loader compatibility;
- `ops/healer/loader.py` → compatibility normalization for historical atlas/casebook entries;
- `ops/healer/run_once.py` → accepts both explicit and compact version keys;
- `atlas.json` / `casebook.json` → current HEALER memory inputs.

Repeat audit status:
- blockers: `[]`;
- `F-006` remains live-proof pending only, not live FastAPI-proven;
- no release-ready claim without external proof gates.

Песочница: reference/navigation only. Runtime-code transfer is forbidden and was not used.

# v170.19 cycle 1443 full linkage architecture tests

Cycle 1443 adds the full static linkage guard layer for `F-007` and `F-008`.

Navigation anchors:
- `ops/linkage/build_full_linkage_report.py` → dependency-light full linkage scanner;
- `reports/generated/full_linkage_report_v170_19.json` → machine report;
- `tests/architecture/test_full_linkage_architecture_and_ui_states.py` → active guard;
- `backend/openapi/openapi.json` → checked-in route contract from cycle 1442;
- `frontend/src/pages/*` and `frontend/src/features/*` → critical UI state evidence.

Guard surface:
- backend route → OpenAPI → frontend API call;
- admin route guard markers;
- legacy money-table runtime reference ban;
- direct balance-write boundary;
- public `tg_id` ownership check;
- critical loading/error/empty states.

Remaining cycle slots:
- `1444 — Linkage repeat audit + HEALER tail reconciliation`;
- `1445 — CI/log proof and residual audit-tail closure if fresh logs are supplied`.

Песочница: reference/navigation only. Runtime-code transfer is forbidden and was not used.

# v170.18 cycle 1442 OpenAPI rebuild and strict contract gate

Cycle 1442 repaired the checked-in OpenAPI / route contract layer for `F-006`.

Navigation anchors:
- `ops/routes/rebuild_openapi_contract_snapshot.py` → dependency-light backend route source scanner and OpenAPI/SSOT rebuilder;
- `ops/routes/check_openapi_strict_contract_gate.py` → strict static backend/OpenAPI/frontend contract gate;
- `ops/openapi/refresh_openapi_from_ssot.py` → compatibility wrapper to the new rebuilder;
- `backend/openapi/openapi.json` → rebuilt checked-in OpenAPI snapshot;
- `backend/openapi/openapi_manifest.json` → snapshot manifest;
- `docs/SSOT/ssot_pack/SSOT_ROUTES.csv` → route SSOT refreshed from backend route source;
- `tests/architecture/test_openapi_rebuild_strict_contract_gate.py` → active guard;
- `reports/generated/openapi_strict_contract_gate_v170_18.json` → machine proof report.

Important boundary:
- checked-in OpenAPI is rebuilt from backend route source without importing runtime dependencies;
- live FastAPI `app.openapi()` proof is not claimed here because local tool environment lacks `sqlalchemy`;
- `F-006` is repaired locally for checked-in contract drift, but release-ready still requires repeat audit and CI/full environment proof.

Next cycles:
- `1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards`;
- `1444 — Linkage repeat audit + HEALER tail reconciliation`;
- `1445 — CI/log proof and residual audit-tail closure if fresh logs are supplied`.

Песочница: reference/navigation only. Runtime-code transfer is forbidden and was not used.

# v170.17 cycle 1441 Admin wallet reset semantic repair

Cycle 1441 repaired `F-005` from the active linkage audit.

Runtime anchors:
- `backend/app/routes/admin_users_routes.py` → `POST /admin/users/{tg_id}/wallet/reset`;
- `backend/app/services/wallets_service.py` → `admin_reset_wallet_bindings()`;
- `backend/app/models/wallets_models.py` → canonical `WalletBinding` / `efhc_core.wallet_bindings`;
- `backend/app/services/watcher_service.py` → deposit lookup ignores deactivated bindings;
- `frontend/src/pages/admin/users.tsx` → reset action reloads detail/list after backend confirmation;
- `tests/architecture/test_admin_wallet_reset_semantic_repair.py`.

Decision applied:
- Admin wallet reset fully unbinds canonical `wallet_bindings`.
- Legacy `users.ton_wallet` cleanup remains compatibility cleanup only.
- Frontend must not block reset only because legacy `ton_wallet` is empty.

Remaining next cycles from audit/HEALER tails:
- `1442 — OpenAPI rebuild and strict contract gate`;
- `1443 — Full linkage architecture tests + UI states`;
- `1444 — Linkage repeat audit + HEALER tail reconciliation`;
- `1445 — CI/log proof and residual audit-tail closure if fresh logs are supplied`.

Песочница: reference/navigation only. Runtime-code transfer is forbidden and was not used.

# v170.16 cycle 1440 Admin Hub route prefix repair

Cycle 1440 repaired `F-004` from the active linkage audit.

Runtime anchors:
- `backend/app/routes/admin_hub_routes.py` → canonical Admin Hub router;
- `backend/app/routes/admin_shop_routes.py` → Shop-only router; no Hub nesting;
- `backend/app/routes/__init__.py` → includes `admin_hub_routes`;
- `frontend/src/features/admin/AdminHubPage.tsx` → canonical `/admin/hub/links*` calls;
- `tests/architecture/test_admin_hub_route_prefix_repair.py`.

Decision applied:
- Admin Hub is a separate admin section;
- canonical path is `/admin/hub/*`;
- accidental `/admin/shop/admin/hub/*` is forbidden and guarded.

Remaining next cycle: `1441 — Admin wallet reset semantic repair`.

Песочница: reference/navigation only. Runtime-code transfer is forbidden and was not used.

# v170.15 cycle 1439 Admin reports bank table repair

Cycle 1439 repaired `F-003` from the active linkage audit.

Runtime anchors:
- `backend/app/routes/admin_routes.py` → `GET /admin/reports/overview`;
- `tests/architecture/test_admin_reports_bank_ssot_repair.py`.

Decision applied:
- admin reports bank total reads canonical `efhc_core.bank_balance`, `key='EFHC_MAIN'`;
- legacy `efhc_admin.bank_balances` is not used by `/admin/reports/overview`;
- response shape remains compatible with admin reports and admin bank dashboard facts.

Bank genesis / migration guard:
- only `backend/migrations/versions/0001_initial_release_schema.py` may create the genesis `5000000.00000000 EFHC` bank seed;
- future migrations must not mint/rewrite bank balance silently;
- runtime supply changes must use `AdminBankService` + `transactions_service` with idempotency/audit.

Remaining next cycle: `1440 — Admin Hub route prefix repair`.

Песочница использована только как reference/navigation layer. Runtime-код не переносился.

# v170.14 cycle 1438 P0 Deposit watcher wallet SSOT repair

Cycle 1438 repaired `F-002` from the active linkage audit.

Runtime anchors:

- `backend/app/services/watcher_service.py`
- `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`

Decision applied: deposit watcher and admin replay use canonical `efhc_core.wallet_bindings`, not legacy `efhc_core.user_wallets` or `users.ton_wallet`.

Bank start balance navigation answer:

- physical seed: `backend/migrations/versions/0001_initial_release_schema.py` → `efhc_core.bank_balance`, `key='EFHC_MAIN'`, `balance=5000000.00000000`;
- runtime fallback: `backend/app/services/admin/admin_bank_service.py` → `BANK_INITIAL_TOTAL` fallback `5000000`;
- live SSOT: `efhc_core.bank_balance`.

Remaining next cycle: `1439 — Admin reports bank table repair`.

Песочница использована только как reference/navigation layer. Runtime-код не переносился.

# v170.13 cycle 1437 P0 Bank SSOT repair

Cycle 1437 repaired `F-001` from the active linkage audit.

Runtime anchors:

- `backend/app/services/admin/admin_bank_service.py`
- `backend/app/services/transactions_service.py`
- `tests/architecture/test_admin_bank_ssot_repair.py`

Decision applied: no separate mint/burn ledger/table; admin bank mint/burn use existing official/canonical tables only.

Remaining next cycle: `1438 — P0 Deposit watcher wallet SSOT repair`.

Песочница использована только как reference/navigation layer. Runtime-код не переносился.

# v170.12 cycle 1436 user decisions doc update

The user answered the open linkage-repair questions from cycle 1436.

Decision anchors:

- `docs/NORM/ITERATION_QUESTIONS_FORMAT_STANDARD.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/cycles/WORK_CYCLES_1436_USER_DECISIONS_DOC_UPDATE.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`

Locked repair inputs:

- Cycle 1437: no separate `efhc_mint_burn` ledger/table; use existing official/canonical tables.
- Cycle 1440: Admin Hub canonical path `/admin/hub/*`.
- Cycle 1441: admin wallet reset fully unbinds `wallet_bindings`.

Question format for future iterations: problem, simple question, options, recommendation, short recommended answers.

# v170.11 cycle 1436 migrations/routes linkage freeze map update

Cycle 1436 used `map_element.md` and sandbox/template archives only as
reference/navigation context while registering the P0 migrations/routes/backend-
frontend linkage audit. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files,
wallet/payment donor logic, economics, secrets, configs or translations were
imported.

Active linkage audit anchors:

- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`

Next repair lane starts at cycle 1437 with P0 Bank SSOT repair.


# v170.04 cycle 1429 P0 security repair map update

Cycle 1429 used `map_element.md` and sandbox archives only as a reference/navigation layer while repairing the P0 security wallet proof boundary and cron control-plane secret. TonConnect and TMA references were used only to confirm architecture/navigation concepts. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor logic, economics, secrets, configs or translations were imported.

Next security lane: cycle 1430 for Telegram initData strict `auth_date`, secrets redaction and legacy frontend header cleanup.

Cycle 1427 used `map_element.md` and the uploaded sandbox archives only as
reference/navigation context while repairing logged CI failures from
`logs_72342361356.zip`. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock
files, wallet/payment logic, foreign economy or translations were imported.

# v170_02 CI log repair sandbox note

Cycle 1426 used `map_element.md` and the uploaded sandbox archives only as
reference/navigation context while closing economic re-audit `NEW-001` in
`panels_service.py`. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files,
wallet/payment logic, foreign economy or translations were imported.

# v170_00 economic cleanup/reconciliation sandbox note

Cycle 1425 used `map_element.md` and the uploaded sandbox archives only as
reference/navigation context while closing economic cleanup findings
`FIND-006..010` and documenting reconciliation hardening. No Vue/Solid/Nuxt/
Vanilla runtime, CI files, lock files, wallet/payment donor logic, translations
or foreign economy were imported.

# v169_98 panel activation atomicity sandbox note

Cycle 1423 used `map_element.md` and the uploaded sandbox archives only as
reference/navigation context while repairing backend panel activation atomicity.
No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor
logic, translations or foreign economy were imported.

# v169_91 HEAL-0024 / Operator Kernel refresh sandbox note

Cycles 1410-1411 used `map_element.md` and sandbox archives only as reference/navigation context while repairing backend withdraw atomicity and optimizing the Operator Kernel cache flow. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor logic or translations were imported.

Active EFHC result:

- `HEAL-0024`: withdraw request creation, balance hold, transfer audit meta and `hold_done=TRUE` are committed in one service-owned boundary on the primary request path.
- Operator Kernel: `refresh.sh` regenerates cache outputs in one command; `routes.yaml` is versioned and validated by `config_loader`.

# v169_89 P0 idempotency / transaction-boundary sandbox note

Cycles 1408-1409 used `map_element.md` and sandbox archives only as reference/navigation context while hardening backend idempotency and mapping transaction ownership. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor logic or translations were imported.

Active EFHC result:

- `HEAL-0023`: explicit idempotency conflict marker handled by shared read-through detector.
- `HEAL-0018`: transaction-boundary map created before runtime repair.

# v169_88 P0 backend/schema repair sandbox note

Cycles 1406-1407 used `map_element.md` and the sandbox archives only as reference/navigation context while repairing backend payment/schema contracts. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment logic or translations were imported.

The active implementation stayed inside EFHC backend ORM/service/migration/test layers:

- `HEAL-0040`: nullable package-less `payment_intents.package_id` contract;
- `HEAL-0044`: existing-DB proof for `efhc_transfers_log.direction varchar(24)`.

# v169_69 AI archive laws note

`map_element.md` remains a sandbox navigation/reference layer only. Any
future use of sandbox references must obey `docs/AI/AI_ARCHIVE_LAWS.md`:
no runtime copy, no test/CI weakening, no hidden regression and no
self-authorized law changes.

# v169_64 i18n browser text stress screenshot-readiness map update

Status: cycle 1384 completed a planning-only browser text stress / screenshot-readiness matrix after the manual i18n repair lane.

Sandbox archives remained reference/navigation only. They were used only for long-label wrapping, Telegram-like cards/cells, shop-card density, FAQ tree readability, wallet row density and TMA viewport/safe-area context. No template English labels, donor runtime code, wallet/payment logic, lock files or CI files were used.

No screenshots were captured and no browser visual verdict is claimed. Next i18n lane: range closure and browser-evidence handoff.

# v169_62 wave-3 hub/energy/wallet/ranks/referrals tail translation map update

Status: cycle 1382 completed the wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID, covering guarded `hub.*`, `energy.*`, `wallet.*`, `ranks.*` and `referrals.*` public UI keys.

Sandbox archives remained reference/navigation only. They were used only for hub-card, energy-hint, wallet-status, rank-row, referral-row and mobile-wrapping context; no template English labels, donor runtime code, wallet/payment logic, lock files or CI files were used.

Next i18n lane: consolidation and remaining-tail audit from verified Russian meaning.

# v169_61 wave-3 panels/tasks/history translation map update

Status: cycle 1381 completed the wave-3 panels/tasks/history manual translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID, covering guarded `panels.*`, `tasks.*` and `history.*` public UI keys.

Sandbox archives remained reference/navigation only. They were used only for panel-card, task-card, history-list, status-chip and mobile-wrapping context; no template English labels, donor runtime code, wallet/payment logic, lock files or CI files were used.

Next i18n lane: wave-3 hub/energy/wallet/ranks/referrals tail manual translation from verified Russian meaning.

# v169_60 wave-3 profile/trust translation map update

Status: cycle 1380 completed the wave-3 profile/public-profile-trust manual translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID, covering guarded `profile.*` and `public_profile_trust.*` public account/trust keys.

Sandbox archives remained reference/navigation only. They were used only for account-card, wallet-row, trust-rail and mobile-wrapping context; no template English labels, donor runtime code, wallet/payment logic, lock files or CI files were used.

Next i18n lane: wave-3 panels/tasks/history manual translation from verified Russian meaning.

# v169_59 wave-3 portal/shop translation map update

Status: cycle 1379 completed the wave-3 portal/shop manual translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID, covering `portal.browser_shop.*` and `portal.shop_entry.*`.

Sandbox archives remained reference/navigation only. They were used only for shop-card, payment-state, wallet-handoff and mobile-wrapping context; no template English labels, donor runtime code, wallet/payment logic, lock files or CI files were used.

Next i18n lane: wave-3 profile/public-profile-trust manual translation from verified Russian meaning.

# v169_58 wave-3 public engagement translation map update

Status: cycle 1378 completed the wave-3 `public_engagement.*` manual translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID. Sandbox archives remained reference/navigation only; no template English labels or donor runtime code were used as translation sources.

Next i18n lane: wave-3 portal/shop manual translation. Use sandbox only for UI stress context around cards, shop entries, long labels and mobile wrapping.

# v169_57 UK public manual translation map update

Status: cycle 1377 completed the Ukrainian public manual translation pass. Sandbox archives remained reference/navigation only; no template English labels or donor runtime code were used as translation sources.

Next i18n lane: wave-3 `public_engagement` manual translation for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID from verified Russian meaning.

# v169_55 i18n reaudit manual translation map update

Status: `1376-1385` opened by user-supplied i18n reaudit. Sandbox archives remain
reference/navigation only. They may help with long-label stress, mobile cards,
FAQ tree layout and TMA text wrapping, but they are not translation sources.

Manual translation rule: verified Russian meaning -> target language. Do not use
Vue/Solid/Nuxt/Vanilla template English labels as source copy.

Active documents:

- `docs/audits/I18N_REAUDIT_REPORT_V169_54_2026_06_03.md`;
- `docs/frontend/I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`;
- `docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`.

# v169_54 range-closure map update

Status: `1351-1375` closed. `1376+` must wait for a new audit/task in chat.

For wallet/TonConnect continuation, use sandbox only as reference for UX structure, Telegram shell behavior, BackButton, viewport, TonConnect connection patterns and E2E organization. Do not import Vue/Solid/Nuxt/Vanilla runtime or donor wallet/payment logic.

Active closure document: `docs/frontend/TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md`.

# map_element.md — карта элементов Песочницы EFHC Bot

## 1. Назначение

Этот документ является отдельной картой элементов Песочницы для EFHC Bot. Он фиксирует, какие UI/UX, Telegram Mini App, TonConnect, TON, backend, testing и dashboard-паттерны доступны как **reference layer**. Документ не переносит runtime-код и не меняет текущий frontend-канон проекта.

Текущий обязательный frontend-канон EFHC Bot остаётся: **Next.js 16.2.6 / React 19.2.6 / Tailwind CSS 4.3.0**. Vue, Solid, Nuxt, Vanilla, Angular, PHP, Go и другие шаблоны в Песочнице используются только как доноры идей, структуры, UX и проверочных сценариев.

## 2. Источники Песочницы

| Источник | Статус | Назначение |
|---|---:|---|
| `Песочница.xz` / `EFHC_SANDBOX_COMPACT_v002` | 29407 файлов / 8118 директорий | Главная историческая Песочница компонентов, SDK, mini-app примеров, TON/TonConnect и dashboard references. |
| `vuejs-template-master.zip` | 43 файлов | Дополнительный Telegram Mini App template reference: `vuejs-template`. |
| `solidjs-template-master.zip` | 44 файлов | Дополнительный Telegram Mini App template reference: `solidjs-template`. |
| `nuxt-telegram-mini-app-main.zip` | 42 файлов | Дополнительный Telegram Mini App template reference: `nuxt-telegram-mini-app`. |
| `typescript-template-master.zip` | 46 файлов | Дополнительный Telegram Mini App template reference: `typescript-template`. |
| `vanillajs-template-master.zip` | 36 файлов | Дополнительный Telegram Mini App template reference: `vanillajs-template`. |

## 3. Жёсткие правила использования

- Песочница — это **reference layer**, а не источник прямого копирования runtime-кода.
- Нельзя мигрировать EFHC Bot на Vue/Solid/Nuxt/Angular/Vanilla только потому, что эти шаблоны есть в Песочнице.
- Нельзя переносить чужие CI/workflow, lock-файлы, deploy-конфиги, секреты, env-примеры и backend runtime без отдельного аудита.
- UI-паттерн можно переносить только как переосмысленный React/Tailwind v4 компонент под EFHC.
- TON/TonConnect/Jetton/NFT примеры использовать только через EFHC SSOT/NORM и отдельный security/economics review.
- Admin и public UI нельзя смешивать: dashboard/admin patterns идут в Admin, Telegram Mini App public patterns идут в публичный контур.

## 4. Глобальная таксономия элементов

| Класс элементов | Источники | Применение в EFHC Bot | Статус |
|---|---|---|---|
| Telegram UI primitives | Mark42, TelegramUI, TeleVue, Telebook, Nuxt tg components | Cells, sections, buttons, tabbar, inputs, modals, lists, placeholders | Candidate |
| Admin dashboard kit | MaterialM, TelegramUI, Telebook | Admin home, Bank, Users, Reports, Shop, Tasks, Panels | Candidate |
| Telegram Mini App shell | tma.js, React/Next/Vue/Solid/TS/Vanilla templates, Nuxt TMA | initData, launchParams, themeParams, BackButton, viewport, mockEnv | Candidate |
| TonConnect / wallet UX | TonConnect SDK, demo-dapp, templates, demo bot | Wallet connect, manifest, auth button, transaction form, QR/modal patterns | Candidate with security review |
| TON SDK / contract references | ton, ton-core, ton-crypto, token-contract, assets-sdk, minter | Jetton/NFT/client primitives as reference only | Audit-only |
| Shop / catalog / orders | telegram-web-app-shop, MaterialM, Telebook | Browser Shop, product cards, order state, skeletons | Candidate |
| Gamification | idle-game, crypto-clicker | Tasks/energy generation visuals, progress loops | Reference only |
| Backend/bot/API | advanced-telegram-bots, fastapi TMA, pytonconnect, demo bot | Bot handlers, DB, tests, TonConnect backend examples | Audit-only |
| Assets / icons / illustrations | MaterialM public images, TelegramUI icons, TonConnect icons, template assets | Visual polish only after license/safety check | Reference only |
| Tests/storybook/devtools | TelegramUI Storybook, Mark42 Storybook, Nuxt tests, SDK tests | Visual QA and component acceptance references | Candidate |

## 5. Главная Песочница: source-project map

| Source project | Files | Класс | Что брать | Что не брать |
|---|---:|---|---|---|
| `mytonwallet-master` | 5251 | Wallet implementation | Большой reference по wallet UX, TON flows, security boundaries. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `sdk-main` | 769 | TonConnect SDK/UI | TonConnectButton, provider, modal, QR, wallet item, transaction demos. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `tma.js-master` | 531 | Telegram Mini App SDK layer | BackButton/MainButton/viewport/initData/themeParams/bridge reference. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `TelegramUI-main` | 426 | Telegram UI design system | Главный донор Telegram-native компонентов и поведения touch/tappable. | Чужой branding/assets как есть, старые dependency assumptions, raw visual dump. |
| `MaterialM-Tailwind-Nextjs-Free-main` | 236 | Next/Tailwind admin/dashboard kit | Донор dashboard cards, tables, charts containers, profile/shop visual blocks. | Чужой branding/assets как есть, старые dependency assumptions, raw visual dump. |
| `advanced-telegram-bots-master` | 227 | Telegram bot backend patterns | FSM/testing/db/alembic/bot template ideas. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `telebook-main` | 196 | Booking mini-app UI | Донор amount/list/date/section/page/fixed-footer patterns для карточек и каталогов. | Чужой branding/assets как есть, старые dependency assumptions, raw visual dump. |
| `minter-main` | 164 | Minting/Jetton tooling | Reference for minting flows; не переносить без экономического SSOT. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `ton-core-main` | 164 | TON core primitives | Address, boc, contract, crypto, dict, tuple utilities. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `telegram-web-app-shop-main` | 142 | Shop/order mini-app | Донор product card/order/customer detail/skeleton patterns. | Чужой branding/assets как есть, старые dependency assumptions, raw visual dump. |
| `assets-sdk-main` | 136 | TON assets SDK | Jetton/NFT/storage/client examples; использовать только через адаптеры. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `react-telegram-web-app-master` | 97 | Reference source | Использовать только после ручного анализа конкретного элемента. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `ton-main` | 93 | TON client SDK | Client/wallet/jetton/multisig modules. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `demo-dapp-master` | 68 | TonConnect dApp | AuthButton/TxForm/connector/manifest patterns. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `Mark42-master` | 66 | Telegram UI primitives | Кандидаты для карточек, секций, avatar/cell/page/switch patterns. | Чужой branding/assets как есть, старые dependency assumptions, raw visual dump. |
| `tma-starter-kit-main` | 59 | Full-stack TMA starter | Frontend/backend/devops reference; framework migration запрещена. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `token-contract-main` | 56 | Jetton/NFT FunC contracts | Reference only; не смешивать с текущим EFHC runtime without audit. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `idle-game-master` | 53 | Idle game mechanics | Reference for passive generation UX patterns. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `nextjs-template-master` | 47 | Next TMA template | Reference shell, routes and TonConnect manifest ideas под Next. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `reactjs-template-master` | 41 | React TMA template | Reference для App/Root/Page/Theme/Launch/TonConnect page. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `ton-crypto-master` | 40 | TON crypto primitives | Mnemonic, password, primitive utils; not UI. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `crypto-clicker-miniapp-main` | 39 | Game miniapp mechanics | Reference only for gamified tasks; PHP runtime не переносить. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `fastapi-telegram-mini-app-main` | 39 | FastAPI TMA backend | API/db/monitoring patterns. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `ng-telegram-webapp-master` | 37 | Angular TMA reference | Angular runtime не переносить. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `pytonconnect-main` | 37 | Python TonConnect | Bot/backend TonConnect reference. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `ton-access-main` | 36 | TON access endpoints | Network endpoint access/reference. | Прямой перенос финансовой/крипто-логики без отдельного аудита и SSOT/NORM approval. |
| `TeleVue-master` | 35 | Telegram Vue UI primitives | Reference для простых Telegram controls; runtime Vue не переносить. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `twa-template-main` | 29 | TWA Ton/Jetton example | Reference for Jetton/TransferTon components; only after EFHC security review. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `demo-telegram-bot-master` | 19 | Bot TonConnect demo | Connect-wallet menu and manifest reference. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `react-circle-master` | 19 | React visual/shape sample | Reference for circular visual blocks if useful. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `awesome-telegram-mini-apps-main` | 6 | Reference list | Navigation/catalog of TMA examples. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |
| `README.md` | 1 | Sandbox root readme | Index-only source. | Runtime/framework migration, CI/deploy configs, secrets/env, lock-file drift. |

## 6. UI/design-system элементы

### 6.1. Mark42

- Компоненты: AppearanceProvider, Avatar, Cell, Image, ImageAvatar, InitialsAvatar, Page, Section, Switch.
- Потенциал EFHC: мягкие Telegram-like карточки, аватары, секции, switch controls, page container.
- Не переносить: Linaria/Storybook конфигурацию как обязательный runtime.

### 6.2. TelegramUI

| Категория | Элементы |
|---|---|
| Blocks | Accordion, Avatar, AvatarStack, Badge, Banner, Blockquote, Button, Card, Cell, IconButton, IconContainer, Image, InlineButtons, List, Placeholder, Section, Steps, Timeline |
| Feedback | CircularProgress, Progress, Skeleton, Snackbar, Spinner, Spoiler |
| Form | Checkbox, Chip, ColorInput, FileInput, FormInput, Input, Multiselect, Multiselectable, PinInput, Radio, Rank, Select, Selectable, Slider, Switch, Textarea |
| Layout | FixedLayout, Tabbar |
| Navigation | Breadcrumbs, CompactPagination, Link, Pagination, SegmentedControl, TabsList |
| Overlays | Modal, Popper, Tooltip |
| Service | AppRoot, HorizontalScroll, RootRenderer, Tappable, Touch, VisuallyHidden |
| Typography | Caption, Headline, LargeTitle, Subheadline, Text, Title, Typography |

Потенциал EFHC: главный эталон для Telegram-native ощущения, touch states, modal/popover behavior, tabbar, inputs, skeletons, progress, typography.

### 6.3. MaterialM Tailwind Next.js

- UI primitives: Accordion, Alert, Avatar, Badge, Breadcrumb, Button, Calendar, Card, Carousel, Checkbox, Collapsible, Command, Dialog, Drawer, DropdownMenu, InputOTP, Input, Label, Popover, Progress, RadioGroup, Select, Separator, Sheet, Skeleton, Switch, Table, Tabs, Textarea, Tooltip.
- Dashboard widgets: BlogCards, EarningReports, PopularProducts, SalesProfit, TotalFollowers, TotalIncome.
- App blocks: blog, notes, tickets, auth login/register, shared CardBox, user-profile shell.
- Потенциал EFHC: Admin dashboard, Reports, Bank/User tables, Shop cards, KPI cards, charts containers, clean admin layout.
- Не переносить: branding, demo commerce images, старые визуальные assumptions без EFHC theme.

### 6.4. TeleVue

- Компоненты: Checkbox, List, RadioButton, Section, Switch.
- Потенциал EFHC: простые mobile controls как reference для React equivalents.
- Не переносить: Vue runtime.

### 6.5. Telebook

- Компоненты: Amount, Avatar, DataOverview, DataOverviewItem, DatePicker, DatePickerCompact, FixedFooter, Icon, Input, List, ListCard, ListItem, ListItemExpandable, Lottie, PageWithHeader, Placeholder, Rank, Section, Sections, Text.
- Экраны: Home, Hotel, Location, Room.
- Потенциал EFHC: catalogue/list patterns, amount display, rank, sections, fixed footer, page with header, date-like filters.
- Не переносить: booking domain logic.

### 6.6. Telegram web app shop

- Компоненты: container, discount, product, skeleton, customer-detail, order-list, order-setting, button-menu.
- Экраны: admin, bot, home, index, user/profile.
- Потенциал EFHC: Browser Shop, order cards, skeleton loading, customer detail panel, admin/order boundary examples.
- Не переносить: чужую business logic магазина и старые payload assumptions.

## 7. Telegram Mini App shell elements

| Источник | Shell elements | EFHC применение |
|---|---|---|
| `tma.js-master` | bridge, sdk, sdk-react, sdk-solid, sdk-vue, init-data-node, toolkit, transformers, BackButton, MainButton, SettingsButton, Popup, Viewport docs | Telegram/WebApp shell, launchParams, initData, themeParams, viewport, back-button behavior. |
| `reactjs-template-master` | App, Root, DisplayData, EnvUnsupported, ErrorBoundary, Link, Page, RGB, IndexPage, InitDataPage, LaunchParamsPage, ThemeParamsPage, TONConnectPage | React-compatible reference for public shell and debug-safe environment pages. |
| `nextjs-template-master` | Next shell, pages, TonConnect manifest, Telegram init patterns | Reference for Next-native integration only; verify against current Next 16. |
| `twa-template-main` | Counter, Jetton, TransferTon, hooks, contracts | Jetton/Transfer UI ideas only after EFHC security review. |
| `tma-starter-kit-main` | full-stack TMA starter, HomePage, admin page, frontend/backend/devops separation | Architecture reference; no framework migration. |
| `ng-telegram-webapp-master` | Angular Telegram WebApp example | Concept-only reference; Angular runtime rejected for EFHC frontend. |

### 7.x. `vuejs-template-master.zip`

- Package: `vuejs-template`.
- Dependencies: `@tma.js/sdk-vue, @tonconnect/ui, eruda, vue, vue-router`.
- Components: `AppDisplayData`, `AppLink`, `AppPage`, `AppRGB`, `IconTonConnect`.
- Pages: `IndexPage`, `InitDataPage`, `LaunchParamsPage`, `ThemeParamsPage`, `TonConnectPage`.
- Utilities/helpers: `src/composables/useBackButton.ts`, `src/helperts/publicUrl.ts`, `src/init.ts`, `src/mockEnv.ts`, `src/router/index.ts`.
- Manifests: `public/tonconnect-manifest.json`.
- EFHC статус: reference-only; переносить идею/структуру, а не framework/runtime.

### 7.x. `solidjs-template-master.zip`

- Package: `solidjs-template`.
- Dependencies: `@solidjs/router, @tma.js/sdk-solid, @tonconnect/ui, eruda, solid-js`.
- Components: `App`, `DisplayData`, `Link`, `Page`, `RGB`, `Root`.
- Pages: `IndexPage`, `InitDataPage`, `LaunchParamsPage`, `ThemeParamsPage`, `TonConnectPage`.
- Utilities/helpers: `src/helpers/publicUrl.ts`, `src/init.ts`, `src/mockEnv.ts`, `src/navigation/routes.tsx`.
- Manifests: `public/tonconnect-manifest.json`.
- EFHC статус: reference-only; переносить идею/структуру, а не framework/runtime.

### 7.x. `nuxt-telegram-mini-app-main.zip`

- Описание package: Structure and configurations for building a Telegram Mini App using Nuxt and TailWind, hosted on Netlify.
- Package: `nuxt-telegram-mini-app`.
- Dependencies: `@nuxt/eslint, @nuxt/fonts, @nuxt/icon, eslint, nuxt, vue, vue-router`.
- Components: `Button`, `Cell`, `Content`, `ErrorBoundary`, `Hero`, `Nav`, `Section`.
- Pages: `components`, `functions`, `utilities`.
- Utilities/helpers: `app/composables/telegram.ts`, `app/utils/color.ts`.
- EFHC статус: reference-only; переносить идею/структуру, а не framework/runtime.

### 7.x. `typescript-template-master.zip`

- Описание package: Telegram Mini Apps application template using TypeScript and Vite.
- Package: `typescript-template`.
- Dependencies: `@telegram-apps/sdk, @tonconnect/ui, eruda, jquery`.
- Components: `DisplayData`, `Link`, `Page`, `RGB`, `TonConnectButton`, `WalletProvider`.
- Pages: `HomePage`, `InitDataPage`, `LaunchParamsPage`, `PageComponent`, `ThemeParamsPage`, `TonConnectPage`.
- Utilities/helpers: `src/context/types.ts`, `src/initComponents.ts`, `src/initNavigator.ts`, `src/initTonConnectUI.ts`, `src/mockEnv.ts`, `src/navigation/routes.ts`, `src/utils/filterChildren.ts`, `src/utils/toArray.ts`.
- Manifests: `public/tonconnect-manifest.json`.
- EFHC статус: reference-only; переносить идею/структуру, а не framework/runtime.

### 7.x. `vanillajs-template-master.zip`

- Описание package: Telegram Mini Apps application template using JavaScript.
- Package: `vanillajs-template`.
- Components: `DisplayData`, `Link`, `Page`, `PageComponent`, `RGB`, `TonConnectButton`, `WalletProvider`.
- Pages: `HomePage`, `InitDataPage`, `LaunchParamsPage`, `ThemeParamsPage`, `TonConnectPage`.
- Utilities/helpers: `dist/js/initTonConnect.js`, `dist/js/utils.js`.
- Manifests: `dist/tonconnect-manifest.json`.
- EFHC статус: reference-only; переносить идею/структуру, а не framework/runtime.

## 8. TonConnect / wallet / TON elements

| Источник | Элементы | EFHC применение | Контроль |
|---|---|---|---|
| `sdk-main` | TonConnectButton, TonConnectUIProvider, modal, notification, QR code, wallet item, tab bar, TonProofDemo, TxForm, TransferUsdt, SignDataTester, wallet batch tester | Wallet/TonConnect UX для EFHC Wallet/Profile/Withdraw/Shop | Security review, manifest review, no raw transaction copy |
| `demo-dapp-master` | AppTitle, AuthButton, TxForm, connector, nft-transaction, tonconnect-manifest | Auth/transaction form reference | Review before any financial flow |
| `demo-telegram-bot-master` | connect-wallet-menu, bot commands, ton-connect helpers, manifest | Bot-side TonConnect entry patterns | Backend audit |
| `pytonconnect-main` | Python TonConnect patterns | Backend/bot integration reference | Python service review |
| `mytonwallet-master` | wallet UX, TON flows, account/security boundaries | High-value UX/security reference | Large codebase; never direct import |
| `ton-main` | client, config, elector, jetton, multisig, wallets | TON client concepts | Adapter only |
| `ton-core-main` | address, boc, contract, crypto, dict, tuple, utils | Low-level TON primitives | Version/security review |
| `ton-crypto-master` | hd, mnemonic, passwords, primitives, utils | Crypto primitive reference | Do not implement wallet secrets in EFHC UI |
| `ton-access-main` | nodes/web access, test infra | Network endpoint/reference | Reliability review |
| `assets-sdk-main` | TonAPI, jetton, nft, storage, wallets, examples mint/transfer/use-tonconnect | Asset/Jetton/NFT reference | No economics bypass |
| `token-contract-main` | Jetton minter/wallet, NFT collection/item/sale/marketplace, wrappers, sandbox tests | Contract reference only | Separate smart-contract audit required |
| `minter-main` | minting flow reference | Mint/admin ideas only | Must not bypass EFHC emission canon |

## 9. Backend / bot / API elements

| Источник | Элементы | EFHC применение |
|---|---|---|
| `advanced-telegram-bots-master` | handler tests, FSM tests, SQLAlchemy Core/ORM, Alembic, bot template, Docker/NATS/logs/I18N | Bot architecture, tests, migrations, i18n and handler QA references. |
| `fastapi-telegram-mini-app-main` | routers, services, db models/schemas, Alembic, Grafana/Loki/Prometheus configs | API/service separation and observability reference. |
| `tma-starter-kit-main` | Go backend, HTTP API, db/domain/devops split | Full-stack layering reference only. |
| `demo-telegram-bot-master` | bot commands, wallet connect menu, TonConnect helper | Bot-wallet integration pattern. |

## 10. Public EFHC UI mapping

| EFHC surface | Sandbox candidates | Что взять | Что не брать |
|---|---|---|---|
| Energy | TelegramUI Progress/Card/Section/Typography, idle-game progress loops, Mark42 Page/Section | kWh cards, progress, generation visual rhythm | Game economy logic |
| Panels | TelegramUI Card/Cell/Progress/Tabs, Telebook List/Section, MaterialM cards | active/archive cards, timers, activation confirmation | Percent boost logic or foreign economy |
| Exchange | TelegramUI Form/Input/Button/Modal, TonConnect UX references | clean kWh→EFHC flow, confirmation, disabled states | Reverse exchange or P2P patterns |
| Tasks | TelegramUI List/Badge/Skeleton, crypto-clicker/idle-game gamification reference | task cards, status, progress, reward feedback | PHP game backend/runtime |
| Referrals | TelegramUI Cell/Avatar/Button, Telebook list | referral row, share/copy cards, active/inactive states | user-to-user transfer semantics |
| Ranks | TelegramUI TabsList/List/AvatarStack, Telebook Rank | vertical rank cards, filters, show-me anchor | 12-level static catalogue |
| Profile/Wallet/History | TonConnect SDK UI, demo-dapp, TelegramUI Tabs/Cell/Modal | wallet connect, history list, safe wallet cards | raw private wallet handling |
| FAQ | TelegramUI Accordion/Section/Typography | tree-style FAQ, nested sections | flat button dump |
| HUB | TelegramUI Button/Card/Section, TonConnect manifest examples | two-button hub and clear payment intent | debug diagnostics in public UI |
| Browser Shop | telegram-web-app-shop, MaterialM product cards, Telebook ListCard | product grid, skeletons, order summary | raw payload/memo exposure in UI |

## 11. Admin EFHC UI mapping

| Admin surface | Sandbox candidates | Что взять | Что контролировать |
|---|---|---|---|
| `/admin` | MaterialM dashboard widgets, TelegramUI Card/Progress/Tabs, Telebook DataOverview | KPI cards, live panels, charts containers, operator overview | No diagnostics dump on business home |
| `/admin/bank` | MaterialM Table/Card/Dialog, TelegramUI Modal/Input/Button, TonConnect SDK transaction examples | bank operations table, confirm modal, idempotency UI | Money actions need confirmation/idempotency |
| `/admin/users` | TelegramUI Avatar/Cell/List/Tabs, MaterialM table | user cards, filters, status tags | tg_id/id boundary |
| `/admin/withdrawals` | TonConnect SDK modal/wallet item, TelegramUI Modal/Button/Snackbar | withdrawal review, approve/reject confirmation | final statuses not overwritten |
| `/admin/shop` | telegram-web-app-shop order components, MaterialM product cards | shop admin orders/products view | no public/admin UI mixing |
| `/admin/tasks` | TelegramUI List/Badge/Skeleton, gamification references | task catalog and execution trace views | no fake static dashboard |
| `/admin/reports` | MaterialM charts/cards, Telebook DataOverview | visual report dashboard, export boundaries | export/download boundary |
| `/admin/diagnostics` | FastAPI monitoring refs, TelegramUI Typography/Section | technical diagnostics page | diagnostics isolated from business surfaces |
| `/admin/system` | MaterialM settings/card/table, TelegramUI Switch/Form | system settings scaffold | no unsafe direct system actions |
| `/admin/logs` | TelegramUI List/Section/Skeleton, FastAPI logs refs | read-only logs viewer | no log deletion |
| `/admin/panels` | TelegramUI Card/Progress/Tabs, Telebook List | panel operation dashboard | confirmation for dangerous panel operations |

## 12. Visual asset map

| Asset class | Sources | EFHC use |
|---|---|---|
| Icons | TelegramUI icons, TonConnect UI icons, MaterialM logos/svgs | Replace with EFHC/TON-compatible icons after license check. |
| Product images | MaterialM products, telegram-web-app-shop public images | Layout placeholders only; not production imagery. |
| Profile/avatar images | MaterialM profile assets, Telebook assets | Avatar layout reference only. |
| Hero illustrations | Nuxt TMA hero-user, MaterialM dashboard images | Public/admin visual polish reference. |
| Audio/game assets | crypto-clicker assets | Do not use in production unless separately approved. |

## 13. Testing / QA / Storybook map

| Source | Elements | EFHC use |
|---|---|---|
| Mark42 Storybook | AppearanceProvider/Cell/Page/Section stories and tests | Component documentation style reference. |
| TelegramUI Storybook | UI component examples, platform/palette docs | Visual QA reference for Telegram-like components. |
| Nuxt TMA tests | utility tests and app shell tests | Reference for Telegram utility test ideas. |
| SDK/TonConnect tests | transaction, wallet, modal flows | Reference only; adapt to EFHC guards. |
| advanced-telegram-bots tests | handlers/FSM/DB testing | Backend test patterns. |

## 14. Priority adoption matrix

| Priority | Workstream | Sandbox sources | Expected EFHC value |
|---|---|---|---|
| P0 | Telegram Mini App shell safety | tma.js, React/Next/TS templates, Nuxt telegram utilities | prevents Browser/WebApp white screen and theme/init errors. |
| P0 | Admin dashboard visual foundation | MaterialM, TelegramUI, Telebook | turns admin from static/fake dashboard into usable operator surface. |
| P1 | Public UI visual polish | TelegramUI, Mark42, Telebook, telegram-web-app-shop | better cards, lists, tabs, skeletons, FAQ, shop and profile UX. |
| P1 | TonConnect UX | TonConnect SDK, demo-dapp, templates | safer wallet connect and transaction confirmation screens. |
| P2 | Backend/API testing patterns | advanced bots, FastAPI TMA | stronger handler/service tests and observability. |
| P2 | Gamification | idle-game, crypto-clicker | task/progress feel without importing economy logic. |
| P3 | TON/contract references | ton-core, ton, assets-sdk, token-contract | only for separate audited smart-contract/SDK tasks. |

## 15. Rejection list

- Не переносить Vue/Solid/Nuxt/Angular runtime в EFHC Bot.
- Не переносить compiled `dist` из Vanilla template как production-код.
- Не переносить PHP game backend, Go starter backend, чужие Docker/CI без отдельной задачи.
- Не переносить TON/Jetton/NFT contract code без отдельного аудита.
- Не переносить чужие картинки/брендинг как production assets без проверки лицензии и смысла.
- Не использовать sandbox examples для изменения EFHC экономики, TG_ID canon, Bank/withdraw invariants или admin/public boundary.

## 16. Практический порядок работы

1. Для каждого нового UI-улучшения сначала выбрать sandbox source и компонентный pattern.
2. Переписать pattern под EFHC React/Tailwind v4, без чужой framework-зависимости.
3. Связать новый EFHC компонент с существующим SSOT/NORM anchor.
4. Добавить visual/architecture guard, если pattern влияет на route boundary, money action, wallet, admin diagnostics или public UI.
5. Не объявлять regression proof без проверки фактической page → component → route → SSOT/NORM связки.

## 17. Appendix A — расширения в главной Песочнице

| Extension | Count |
|---|---:|
| `.tsx` | 8073 |
| `.json` | 5560 |
| `.ts` | 5089 |
| `.md` | 2456 |
| `[no_ext]` | 850 |
| `.swift` | 843 |
| `.png` | 786 |
| `.kt` | 764 |
| `.svg` | 746 |
| `.html` | 489 |
| `.js` | 359 |
| `.txt` | 332 |
| `.xml` | 321 |
| `.css` | 318 |
| `.ico` | 259 |
| `.py` | 231 |
| `.scss` | 229 |
| `.mdx` | 215 |
| `.java` | 152 |
| `.jpg` | 135 |
| `.yml` | 106 |
| `.h` | 79 |
| `.tgs` | 79 |
| `.yaml` | 77 |
| `.mjs` | 57 |

## 18. Appendix B — project raw index

| Project | Files | Top dirs | Detected components/pages/manifests |
|---|---:|---|---|
| `advanced-telegram-bots-master` | 227 | `08_Databases`, `10_Template`, `04_Testing`, `.DS_Store`, `.gitignore`, `README.md` | no UI elements auto-detected; use as library/backend/reference source |
| `assets-sdk-main` | 136 | `src`, `.github`, `examples`, `.editorconfig`, `.gitignore`, `LICENSE`, `README.md`, `contributing.md` | no UI elements auto-detected; use as library/backend/reference source |
| `awesome-telegram-mini-apps-main` | 6 | `.github`, `CONTRIBUTING.md`, `LICENSE`, `README.md`, `assets`, `resources_other_languages.md` | no UI elements auto-detected; use as library/backend/reference source |
| `crypto-clicker-miniapp-main` | 39 | `assets`, `api`, `cron`, `README.md`, `_boosters.php`, `_dbconnect.php`, `app.css`, `app.js` | no UI elements auto-detected; use as library/backend/reference source |
| `demo-dapp-master` | 68 | `src`, `docs`, `config`, `public`, `scripts`, `.eslintignore`, `.eslintrc.js`, `.gitignore` | components: `AppTitle`, `AuthButton`, `TxForm`; manifests: `asset-manifest.json`, `tonconnect-manifest.json`, `tonconnect-manifest.json` |
| `demo-telegram-bot-master` | 19 | `src`, `.env.example`, `.eslintrc.js`, `.gitignore`, `.nvmrc`, `.prettierrc.json`, `LICENSE`, `README.md` | manifests: `tonconnect-manifest.json` |
| `fastapi-telegram-mini-app-main` | 39 | `etc`, `db`, `migrations`, `utils`, `services`, `routers`, `.env.example`, `.github` | no UI elements auto-detected; use as library/backend/reference source |
| `idle-game-master` | 53 | `carpir`, `.gitignore`, `README.md` | no UI elements auto-detected; use as library/backend/reference source |
| `Mark42-master` | 66 | `src`, `.storybook`, `.github`, `.babelrc`, `.browserslistrc`, `.eslintignore`, `.eslintrc`, `.gitignore` | components: `AppearanceProvider`, `Avatar`, `Cell`, `Image`, `ImageAvatar`, `InitialsAvatar`, `Page`, `Section`, `Switch` |
| `MaterialM-Tailwind-Nextjs-Free-main` | 236 | `package`, `landingpage`, `README.md`, `discount-code.html`, `docs.html`, `hire-us.html` | components: `apps`, `auth`, `dashboard`, `shared`, `user-profile`, `theme-provider`, `ui` |
| `minter-main` | 164 | `src`, `public`, `.github`, `.env`, `.gitignore`, `.husky`, `.prettierrc.json`, `LICENSE` | components: `AddressLink`, `BigNumberDisplay`, `FieldDescription`, `LoadingContainer`, `LoadingImage`, `Popup`, `Screen`, `SectionLabel`, `appButton`, `appHeading`, `appInput`, `appLogo`, `checkWalletBalancePopup`, `editLogoPopup`, `footer`, `form`, `header`, `hoverableIcon`; pages: `deployer`, `jetton`; manifests: `manifest.json`, `tonconnect-manifest.json` |
| `mytonwallet-master` | 5251 | `mobile`, `src`, `changelogs`, `public`, `dev`, `tests`, `docs`, `deploy` | components: `overscroll`, `AlphaGradientLayout`, `AutoScaleContainerView`, `BackDrawable`, `ConfettiView`, `CopyTextView`, `ExpandableFrameLayout`, `INavigationPopup`, `IPopup`, `WAlertLabel`, `WAmountEditText`, `WAmountInput`, `WAnimationView`, `WBaseView`, `WBlurryBackgroundView`, `WButton`, `WCell`, `WConstraintSet`; pages: `ledgerConnect`, `ledgerWallets`, `AgentComposerView`, `AgentHintsSectionView`, `AgentOutgoingBubbleDrawable`, `GradientShaderDrawable`, `TypingIndicatorView`, `NftAttributesView`, `NftHeaderView`, `ScrollState`, `TokenHeaderView`, `ActivityListView`; manifests: `site.webmanifest`, `site.webmanifest`, `manifest.json`, `mytonwallet-multisend-tonconnect-manifest.json`, `site.webmanifest` |
| `nextjs-template-master` | 47 | `src`, `public`, `.eslintrc.json`, `.gitignore`, `README.md`, `assets`, `next.config.ts`, `package.json` | components: `DisplayData`, `ErrorBoundary`, `ErrorPage`, `Link`, `LocaleSwitcher`, `Page`, `RGB`, `Root`; manifests: `tonconnect-manifest.json` |
| `ng-telegram-webapp-master` | 37 | `projects`, `.vscode`, `.editorconfig`, `.github`, `.gitignore`, `LICENSE`, `README.md`, `angular.json` | no UI elements auto-detected; use as library/backend/reference source |
| `pytonconnect-main` | 37 | `pytonconnect`, `examples`, `.flake8`, `.gitignore`, `.vscode`, `LICENSE`, `Makefile`, `README.md` | manifests: `pytonconnect-manifest.json` |
| `react-circle-master` | 19 | `example`, `__tests__`, `src`, `.DS_Store`, `.gitignore`, `.nvmrc`, `.travis.yml`, `LICENSE` | no UI elements auto-detected; use as library/backend/reference source |
| `react-telegram-web-app-master` | 97 | `src`, `demo`, `tests`, `docs`, `.github`, `.changeset`, `.eslintignore`, `.eslintrc.json` | no UI elements auto-detected; use as library/backend/reference source |
| `reactjs-template-master` | 41 | `src`, `.github`, `.eslintrc.cjs`, `.gitignore`, `LICENSE`, `README.md`, `assets`, `eslint.config.js` | components: `App`, `DisplayData`, `EnvUnsupported`, `ErrorBoundary`, `Link`, `Page`, `RGB`, `Root`; pages: `IndexPage`, `InitDataPage`, `LaunchParamsPage`, `TONConnectPage`, `ThemeParamsPage`; manifests: `tonconnect-manifest.json` |
| `README.md` | 1 |  | no UI elements auto-detected; use as library/backend/reference source |
| `sdk-main` | 769 | `packages`, `docs`, `apps`, `.github`, `assets`, `guidelines`, `.changeset`, `.gitignore` | components: `CreateJettonDemo`, `FindTransactionDemo`, `Footer`, `Header`, `MerkleExample`, `NetworkPicker`, `SignDataTester`, `TonProofDemo`, `TransferUsdt`, `TxForm`, `WalletBatchLimitsTester`, `TonConnectButton`, `TonConnectUIProvider`, `.gitignore`, `CHANGELOG`, `LICENSE`, `README`, `favicon`; pages: `account-button`, `modals`; manifests: `tonconnect-manifest.json` |
| `telebook-main` | 196 | `client`, `docs`, `server`, `.editorconfig`, `.gitignore`, `.vscode`, `LICENSE`, `README.md` | components: `Amount`, `Avatar`, `DataOverview`, `DatePicker`, `Icon`, `Input`, `List`, `Lottie`, `Page`, `Placeholder`, `README`, `Rank`, `Section`, `Text`, `DatePickerCompact`, `FixedFooter`, `ListCard`, `ListItem`; pages: `Home`, `Hotel`, `Location`, `Room` |
| `telegram-web-app-shop-main` | 142 | `src`, `public`, `.vscode`, `screenshots`, `.drone.yml`, `.editorconfig`, `.eslintrc.cjs`, `.gitattributes` | components: `container`, `discount`, `product`, `skeleton`, `customer-detail`, `order-list`, `order-setting`, `button-menu`; pages: `admin`, `bot`, `home`, `user` |
| `TelegramUI-main` | 426 | `src`, `.storybook`, `.eslintrc.js`, `.gitignore`, `.pretterrc`, `LICENSE`, `README.md`, `jest.config.js` | components: `Blocks`, `Feedback`, `Form`, `Layout`, `Misc`, `Navigation`, `Overlays`, `Service`, `Typography` |
| `TeleVue-master` | 35 | `src`, `.storybook`, `.github`, `.gitignore`, `LICENSE`, `README.md`, `TeleVue.png`, `package-lock.json` | components: `Checkbox`, `List`, `RadioButton`, `Section`, `Switch` |
| `tma-starter-kit-main` | 59 | `frontend`, `backend`, `.gitignore`, `README.md`, `devops` | pages: `ErrorNotFound`, `HomePage`, `admin` |
| `tma.js-master` | 531 | `packages`, `apps`, `.github`, `.changeset`, `.gitattributes`, `.gitignore`, `.npmrc`, `CODE_OF_CONDUCT.md` | components: `back-button`, `main-button`, `popup`, `settings-button`, `viewport` |
| `token-contract-main` | 56 | `ft`, `nft`, `wrappers`, `scripts`, `sandbox_tests`, `.gitignore`, `LICENSE`, `README.md` | no UI elements auto-detected; use as library/backend/reference source |
| `ton-access-main` | 36 | `lib`, `test`, `dist`, `src`, `html-test`, `.gitignore`, `.vscode`, `LICENSE` | no UI elements auto-detected; use as library/backend/reference source |
| `ton-core-main` | 164 | `src`, `.github`, `.editorconfig`, `.gitignore`, `.yarnrc.yml`, `CHANGELOG.md`, `CONTRIBUTING.md`, `LICENSE` | no UI elements auto-detected; use as library/backend/reference source |
| `ton-crypto-master` | 40 | `src`, `.github`, `.gitignore`, `.yarn`, `.yarnrc.yml`, `LICENSE`, `README.md`, `jest.config.js` | no UI elements auto-detected; use as library/backend/reference source |
| `ton-main` | 93 | `src`, `.github`, `.editorconfig`, `.gitignore`, `.yarn`, `.yarnrc.yml`, `CHANGELOG.md`, `LICENSE` | no UI elements auto-detected; use as library/backend/reference source |
| `twa-template-main` | 29 | `src`, `.github`, `.gitignore`, `LICENSE`, `README.md`, `configure.js`, `index.html`, `package.json` | components: `Counter`, `Jetton`, `TransferTon`, `styled` |

## 19. Appendix C — extra template raw map

### `vuejs-template-master.zip`

- Files: 43
- Package: `vuejs-template`
- Components: `AppDisplayData`, `AppLink`, `AppPage`, `AppRGB`, `IconTonConnect`
- Pages: `IndexPage`, `InitDataPage`, `LaunchParamsPage`, `ThemeParamsPage`, `TonConnectPage`
- Utilities: `src/composables/useBackButton.ts`, `src/helperts/publicUrl.ts`, `src/init.ts`, `src/mockEnv.ts`, `src/router/index.ts`
- Manifests: `public/tonconnect-manifest.json`

### `solidjs-template-master.zip`

- Files: 44
- Package: `solidjs-template`
- Components: `App`, `DisplayData`, `Link`, `Page`, `RGB`, `Root`
- Pages: `IndexPage`, `InitDataPage`, `LaunchParamsPage`, `ThemeParamsPage`, `TonConnectPage`
- Utilities: `src/helpers/publicUrl.ts`, `src/init.ts`, `src/mockEnv.ts`, `src/navigation/routes.tsx`
- Manifests: `public/tonconnect-manifest.json`

### `nuxt-telegram-mini-app-main.zip`

- Files: 42
- Package: `nuxt-telegram-mini-app`
- Components: `Button`, `Cell`, `Content`, `ErrorBoundary`, `Hero`, `Nav`, `Section`
- Pages: `components`, `functions`, `utilities`
- Utilities: `app/composables/telegram.ts`, `app/utils/color.ts`

### `typescript-template-master.zip`

- Files: 46
- Package: `typescript-template`
- Components: `DisplayData`, `Link`, `Page`, `RGB`, `TonConnectButton`, `WalletProvider`
- Pages: `HomePage`, `InitDataPage`, `LaunchParamsPage`, `PageComponent`, `ThemeParamsPage`, `TonConnectPage`
- Utilities: `src/context/types.ts`, `src/initComponents.ts`, `src/initNavigator.ts`, `src/initTonConnectUI.ts`, `src/mockEnv.ts`, `src/navigation/routes.ts`, `src/utils/filterChildren.ts`, `src/utils/toArray.ts`
- Manifests: `public/tonconnect-manifest.json`

### `vanillajs-template-master.zip`

- Files: 36
- Package: `vanillajs-template`
- Components: `DisplayData`, `Link`, `Page`, `PageComponent`, `RGB`, `TonConnectButton`, `WalletProvider`
- Pages: `HomePage`, `InitDataPage`, `LaunchParamsPage`, `ThemeParamsPage`, `TonConnectPage`
- Utilities: `dist/js/initTonConnect.js`, `dist/js/utils.js`
- Manifests: `dist/tonconnect-manifest.json`



## 20. Operational checkpoint update

Status: active navigation map for sandbox elements.
Version: v169_37.

### 20.1. Current use

`map_element.md` is the fast navigation layer for old and new sandbox archives.
It must be updated whenever a new sandbox archive is uploaded or when an EFHC
work pass adopts a new donor pattern.

### 20.2. Immediate next use

The next public screenshot QA preparation should use this priority order:

1. Telegram-native shell patterns: theme params, viewport, BackButton, haptics,
   compact cards and section layout.
2. Public screen readability patterns: progress, skeleton, placeholder, tabs,
   segmented controls, accordions and fixed footer.
3. Wallet/TonConnect patterns: manifest, connect button, wallet card and safe
   transaction handoff only after EFHC security review.
4. Admin-only patterns: KPI cards, decision panels, flow maps, tables and
   diagnostics health strips.

### 20.3. Active rejection boundary

Do not import Vue/Solid/Nuxt/Vanilla template runtime code into EFHC. The
accepted output is an EFHC-native React/Tailwind implementation under the
current dependency canon.

### 20.4. Link to operational intake

See also:

- `docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md`;
- `docs/admin/ADMIN_RECOVERY_CHECKPOINT.md`;
- `docs/AI/TOPIC_READING_ROUTES.md`.


## 15. v169_37 audit-fixes usage map

Uploaded audit source: `docs/audits/TZ_FIXES_AUDIT_v169_35.md`.

The sandbox was used as a reference layer for the audit-fixes implementation pass:

| Fix group | Sandbox guidance used | EFHC result |
|---|---|---|
| Admin/public boundary | Telegram tabbar/fixed-layout separation patterns | public bottom nav hidden on `/admin/*` |
| E2E smoke scaffold | template testing structures and TMA mock assumptions | `tests/frontend/e2e/` baseline added |
| Sale Packages actions | admin card/action/modal ergonomics | create/edit/toggle wired with confirmation/idempotency |
| Public error states | Telegram empty-state conventions | localized auth/load error helper |
| PWA offline fallback | mobile shell resilience pattern | `offline.html` fallback shell |
| Wallet opening | TMA link/back-button safety | `openLink`/`window.open` instead of history replacement |

Still prohibited: copying Vue/Solid/Nuxt/Vanilla runtime into EFHC Bot or using
sandbox financial/TON code without separate SSOT/security review.


## Public screenshot QA navigation update

Current public QA work should use this map as follows:

| EFHC public surface | Primary sandbox references | Use as | Do not use as |
|---|---|---|---|
| Energy | TelegramUI, Mark42, Telebook | cards, progress, skeleton, readable first screen | new economics or generation logic |
| Panels | TelegramUI tabs/sections, Telebook fixed footer | active/archive layout, activation affordance | admin control surface |
| Exchange | TonConnect templates, TelegramUI input/cards | amount preview, safe CTA hierarchy | reverse exchange or raw payload display |
| Tasks | TelegramUI cards, game references | earning-card hierarchy, modal states | uncontrolled gamification economics |
| Referrals | Telegram share/cell patterns | copy/share clarity and invite-card structure | admin identity or raw referral internals |
| Ranks | list/avatar/progress patterns | vertical list clarity and show-me affordance | catalog of internal levels |
| Profile / Wallet / History | TonConnect button/provider references | wallet card and activity-list UX | raw transaction payload dump |
| FAQ | accordion/search/section patterns | tree navigation and empty states | flat button-only FAQ |
| HUB | Telegram action cards, TonConnect handoff patterns | two approved actions and safe wallet handoff | diagnostics or operator dumps |
| Browser Shop | telegram-web-app-shop, Telebook, MaterialM cards | clean product cards and order state | public memo/payload diagnostics |

This update is navigational only. It does not authorize framework migration, direct sandbox imports or changes to EFHC economics.

## 18. Обновление v169_39: Public UI QA и residual audit fixes

Песочница используется как reference layer для Public UI screenshot QA,
но не переносится в runtime EFHC. В текущем проходе карта связана с тремя
остаточными дефектами аудита:

| Defect | Что взято из Песочницы как идея | Что реализовано в EFHC |
|---|---|---|
| Localized 401/403 public errors | multi-locale Mini App UX expectation | `common.session_expired` и `common.load_error` добавлены во все 13 locale JSON |
| Interaction E2E smoke | template-level user-flow tests | Exchange/HUB/Withdraw E2E tests теперь проверяют фактические POST calls |
| Full route smoke scope | TMA route matrix discipline | public smoke: 14 routes; admin smoke: 17 routes |
| Offline fallback readability | PWA shell fallback UX | `offline.html` получил multilingual fallback line |

Следующий public regression proof pass должен использовать эту карту для proof-matrix:

`public page -> components -> backend roads -> SSOT/NORM anchor -> guard -> visual verdict`.



## v169_40 — Public UI regression proof usage

`map_element.md` was used as a navigation layer for the public regression proof
pass. The active EFHC surfaces were matched to sandbox pattern families without
importing donor runtime code:

- Energy/Panels/Exchange/Tasks/Ranks: TelegramUI/Mark42-style cards, buttons,
  badges, sections, skeletons and progress patterns;
- Referrals/Profile/FAQ: list/cell/tree/search patterns from TelegramUI,
  Telebook and Mark42;
- HUB/Browser Shop/Withdraw: TonConnect handoff, shop-card/order-state and
  wallet interaction references;
- Ads: task/ad-card public action patterns without execution-trace leakage.

The canonical implementation remains Next.js 16.2.6 / React 19.2.6 / Tailwind
CSS 4.3.0. Vue, Solid, Nuxt, Vanilla and other templates remain donor/reference
sources only.

## 17. v169_41 next public visual lane map

The current checkpoint uses the sandbox only as a reference map for the next
public visual work lane. The approved adoption order is:

| Lane | Sandbox reference | EFHC target | Guardrail |
|---|---|---|---|
| Browser screenshot evidence | Nuxt/TypeScript/Vanilla test naming and TMA page coverage ideas | screenshot evidence manifest for public routes | no fake screenshot claim |
| Energy/Panels/Exchange beauty | TelegramUI, Mark42, Telebook, idle-game visual loops | cards, progress, CTA hierarchy, empty/loading states | no economics change |
| Tasks/Referrals/Ranks beauty | TelegramUI cells, badges, list sections, skeletons | earning cards, invite rows, ranking cards | no raw execution traces |
| Profile/Wallet/History/FAQ trust | Telebook list/page patterns, TonConnect UX references | wallet cards, history filters, FAQ tree | no raw wallet payloads |
| HUB/Shop/Withdraw/Ads trust | telegram-web-app-shop, Telebook, TonConnect handoff concepts | product cards, handoff clarity, withdraw form clarity | no foreign payment logic |
| Telegram Mini App shell | tma.js, TypeScript/Vanilla templates | BackButton, viewport, themeParams, safe area | no framework migration |
| TonConnect / Wallet UX | TonConnect SDK demos, wallet templates | connection state and handoff polish | security/SSOT review before transaction changes |

This update does not import runtime code. It only adds navigation for the next
public visual evidence lane.


## 21. Browser screenshot evidence harness

| Element | Sandbox source | EFHC use | Restriction |
|---|---|---|---|
| Viewport matrix | TypeScript / Vanilla TMA templates | `mobile_tma_dark_ru`, `mobile_tma_light_en`, `desktop_pwa_dark_en` screenshot device matrix | reference only |
| Screenshot test organization | Nuxt Telegram mini app | `tests/frontend/e2e/test_public_screenshot_capture_manifest.py` structure | no Nuxt runtime |
| Telegram visual primitives | TelegramUI / Telebook / Mark42 | checklist labels for cards, cells, tabbar, safe-area and modals | no direct runtime import |
| Browser Shop visual reference | telegram-web-app-shop | future 1368 visual review of `/browser-shop` | no payment logic transfer |
| Wallet UX references | TonConnect demos | future 1370 handoff screenshots | security/SSOT review required |

Harness output:

- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`;
- `tests/frontend/e2e/test_public_screenshot_capture_manifest.py`.

Status: harness ready; no actual screenshots claimed.


## v169_43 — Energy / Panels / Exchange visual polish

| EFHC surface | Sandbox reference family | Adopted pattern | Not adopted |
|---|---|---|---|
| Energy | TelegramUI / Mark42 cards and chips | visual rail, active chips, focus polish | foreign runtime code |
| Panels | Telebook sections and Telegram card hierarchy | ready/locked state classes, compact chips | economic changes |
| Exchange | TonConnect handoff UX references and Telegram cells | ready/loading state classes and CTA depth | wallet transaction logic |

This update remains reference-only. No Vue/Solid/Nuxt/Vanilla runtime, lock file,
CI file or payment logic was imported into EFHC Bot.

## v169_44 — Tasks / Referrals / Ranks visual polish

| EFHC surface | Sandbox reference family | Adopted pattern | Not adopted |
|---|---|---|---|
| Tasks | TelegramUI / Mark42 cells, badges, status chips; idle-game visual rhythm | ready/locked/ad/claim task-card states, status/reward rail, focus polish | external game runtime, task economy changes |
| Referrals | Telegram share/cell patterns, Telebook compact lists | invite card polish, copy/share visual rail, larger share touch targets | admin identity leakage, raw referral internals |
| Ranks | TelegramUI list/badge patterns, Telebook rank layouts | filter/me/podium visual markers, leader-card row highlight | rank formula changes, static internal-level catalog |

This update remains reference-only. No Vue/Solid/Nuxt/Vanilla runtime, lock file,
CI file, bot runtime, payment logic or TON transaction logic was imported into
EFHC Bot.

Next visual lane: Profile / Wallet / History / FAQ trust pass.

## Profile / Wallet / History / FAQ visual trust pass

Status: reference-only sandbox navigation updated for the account-trust public lane after the current visual trust pass.

### EFHC target surfaces

| Surface | EFHC files | Sandbox pattern class used | Runtime rule |
|---|---|---|---|
| Profile | `frontend/src/features/profile/WebProfilePage.tsx`, `frontend/src/components/public/PublicProfileTrustLayer.tsx` | TelegramUI/Mark42 chips, cells, badges, trust-card hierarchy | Keep Next.js/React/Tailwind EFHC runtime |
| Wallet | `frontend/src/components/profile/ProfileWalletSection.tsx` | Telegram status cells, connected/primary/proof rail | Do not import sandbox wallet/payment logic |
| History | `frontend/src/components/profile/ProfileHistorySection.tsx` | Telebook compact list hierarchy and filter chips | Do not change ledger, withdraw or balance logic |
| FAQ | `frontend/src/pages/faq.tsx`, `frontend/src/components/faq/FaqVerticalTree.tsx` | Telegram-like tree/list readability, focus states | Keep EFHC FAQ data/model and vertical tree canon |

### Adoption rules

- Use sandbox visual concepts only: chips, rails, cards, touch/focus states, compact mobile rhythm.
- Do not port Vue, Solid, Nuxt, Vanilla runtime, lock files, CI files or payment/wallet logic.
- Do not claim screenshots unless `EFHC_CAPTURE_SCREENSHOTS=1` browser evidence exists.
- Preserve public/admin boundary and do not render diagnostics/raw payload on public account surfaces.

## HUB / Browser Shop / Withdraw / Ads visual trust pass

Status: reference-only sandbox navigation updated for the commerce/withdraw public lane after the current visual trust pass.

### EFHC target surfaces

| Surface | EFHC files | Sandbox pattern class used | Runtime rule |
|---|---|---|---|
| HUB | `frontend/src/features/hub/HubPage.tsx` | TelegramUI/Mark42 action cards, chips and external handoff clarity | Keep two canonical HUB actions only |
| Browser Shop | `frontend/src/features/browser-shop/BrowserShopPage.tsx` | telegram-web-app-shop product hierarchy, Telebook sections, TonConnect handoff concepts | Do not import foreign payment logic or raw payload UI |
| Withdraw | `frontend/src/pages/withdraw.tsx` | Telebook list/card rhythm, Telegram status chips and wallet state clarity | Do not change withdraw mechanics, idempotency or ledger logic |
| Ads | `frontend/src/pages/ads.tsx` | compatibility/redirect explanation card | Keep `/ads` as alias to Tasks, not a standalone player page |

### Adopted pattern classes

- trust rails for multi-step user comprehension;
- compact rounded chips for state clarity;
- stronger card hierarchy for commerce and withdraw actions;
- focus-visible and 390px mobile polish;
- reduced-motion safety.

### Not adopted

- Vue/Solid/Nuxt/Vanilla runtime;
- foreign wallet/payment code;
- raw transaction payloads;
- admin diagnostics;
- changes to EFHC economics or withdraw semantics.

Next visual lane: Telegram Mini App shell polish.


## I18N / localization audit repair lane

Status: active language repair lane added after the v169.45 localization audit.

### Evidence sources

| Source | Role | Runtime rule |
|---|---|---|
| `docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md` | Human-readable localization audit | Treat as audit evidence, not runtime code |
| `reports/generated/i18n_audit_summary_v169_45.json` | Machine-readable audit summary | Use for routing and guard planning |
| `frontend/public/locale/*.json` | Player-facing locale bundles | Preserve 13-language key parity and placeholders |
| `frontend/src/lib/i18n.ts` | Runtime fallback chain | Player fallback must be English-first |
| `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` | FAQ translation status | Structural parity is not quality completion |

### Sandbox relevance

The visual/component sandboxes are not translation sources. They remain useful
only for layout stress patterns when long translated strings are later rendered
in browser screenshot passes. No Vue/Solid/Nuxt/Vanilla runtime is imported.

### Next i18n map targets

- repair public untranslated key tail;
- repair FAQ wave-3 identical-to-English answers/questions;
- add/strengthen guards for English-first fallback, placeholder parity and empty values;
- later validate long translations through screenshot evidence harness.


## 15. I18N remediation navigation — v169_48

The public i18n remediation lane uses `map_element.md` only as UI/context navigation. Translation values must come from locale files and i18n audit documents, not from sandbox runtime code.

Current language-repair lane:

- v169_47 closed critical fallback/empty/placeholder defects;
- v169_48 remediates priority public untranslated keys;
- the remaining FAQ wave-3 and broader identical-to-English tail are routed to the next language pass.

Sandbox usage in this lane:

- Telegram UI references can guide tone length and mobile label compactness;
- TMA templates can guide error-state brevity;
- sandbox frameworks are not translation sources and are not runtime migration sources.


## 16. FAQ wave-3 translation repair navigation — v169_49

The FAQ wave-3 repair lane uses `map_element.md` only as orientation. The actual translation source of truth is `docs/SSOT/faq_ssot/*/faq_*.json`.

### Active FAQ language-repair artifacts

- `docs/frontend/FAQ_WAVE3_TRANSLATION_STATUS_REPAIR.md` — human-readable repair map.
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` — current structural/quality status.
- `reports/generated/faq_wave3_translation_repair_v169_49.json` — generated evidence map.
- `frontend/src/data/faq/catalogs.ts` — regenerated runtime FAQ catalog.

### Sandbox relevance

Sandbox templates are not translation dictionaries. They remain useful later for checking long translated text in cards, trees, accordions and mobile safe-area shells.

## 17. FAQ semantic alignment navigation — v169_50

This section supersedes any assumption that v169_49 FAQ wave-3 repair is final semantic approval.

### Active semantic artifacts

- `docs/frontend/FAQ_SEMANTIC_ALIGNMENT_REPAIR.md` — semantic correction map.
- `docs/audits/FAQ_SEMANTIC_ALIGNMENT_AUDIT_V169_50.md` — audit verdict.
- `reports/generated/faq_semantic_alignment_repair_v169_50.json` — generated item matrix.
- `tests/architecture/test_faq_semantic_alignment_repair.py` — static guard.

### Rule

Sandbox archives are not translation sources. For FAQ meaning, check Q/A and FAQ approval records first. RU/FAQ is the anchor only after it passes that regression check; EN and all other languages are translation layers.

### Corrected areas

- Wallet/account linking semantics.
- Navigation and rules items 162-172.
- Main wallet top-up wording without deposit semantics.

Next non-FAQ lane after this corrective pass: Telegram Mini App shell polish.

## FAQ semantic approval gate navigation

Current FAQ/i18n lane uses sandbox archives only as navigation/reference. They
are not translation sources. For FAQ semantics, the route is:

1. `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
2. `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`
3. `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md`
4. `docs/SSOT/FAQ_SSOT.md`
5. `docs/SSOT/faq_ssot/ru/faq_ru.md`
6. non-RU FAQ files as translations from the approved Russian meaning

Do not use Vue/Solid/Nuxt/Vanilla sandbox text as FAQ copy.


## v169_52 language canon note

Sandbox archives are visual/UX/reference layers only. They are not language canon sources. For EFHC Bot localization, the semantic source is verified Russian canon: Q/A register → FAQ approval layer → RU FAQ/SSOT. EN and every other locale must be translated from that verified Russian meaning.

Do not use sandbox English labels as source text for Russian EFHC UI/FAQ.


## v169_53 Telegram Mini App shell polish navigation

The active TMA shell polish lane uses sandbox archives as reference only.

### Useful sandbox references

- `typescript-template-master.zip` — Telegram launch/theme/viewport assumptions and compact TMA structure.
- `vanillajs-template-master.zip` — minimal BackButton and browser-safe fallback patterns.
- `nuxt-telegram-mini-app-main.zip` — test organization and TMA lifecycle ideas.
- `vuejs-template-master.zip` / `solidjs-template-master.zip` — reference-only shell patterns; no runtime migration.
- `Песочница.xz` Telegram UI references — card/shell rhythm, safe-area thinking and mobile spacing.

### EFHC files to inspect

- `frontend/src/lib/telegram.ts`
- `frontend/src/components/Layout.tsx`
- `frontend/src/pages/app.tsx`
- `frontend/src/styles/globals.css`
- `docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md`
- `docs/frontend/FRONTEND_SHELL_ARCHITECTURE.md`

### Boundaries

Do not copy sandbox runtime frameworks, lockfiles, CI files, wallet/payment logic or English labels into EFHC. The language canon remains verified Russian meaning → all translations.

## v169.56 off-queue i18n process correction navigation

Sandbox archives remain reference-only. This off-queue pass does not import any
sandbox runtime or translation text. It only hardens the EFHC i18n process before
manual translation continuation: audit scripts run without work-pass artifacts by
default, strict mode is explicit, the English fallback guard is strengthened, the
`1 kWh = 1 EFHC` formula is allowlisted, and public `game task` wording is kept
neutral rather than broadly allowlisted.

## v169.63 i18n consolidation navigation

Cycle 1383 uses `map_element.md` only as a navigation/reference layer for UI
text stress planning and future screenshot-readiness work. The consolidation
pass does not import sandbox runtime code and does not use sandbox English labels
as translation sources.

Active i18n consolidation artifacts:

- `docs/frontend/I18N_MANUAL_COVERAGE_CONSOLIDATION.md`;
- `docs/audits/I18N_MANUAL_COVERAGE_CONSOLIDATION_AUDIT_V169_63.md`;
- `ops/i18n/audit_i18n_manual_coverage_consolidation.py`.

Next use: cycle 1384 may use sandbox UI references for text wrapping,
long-label stress and screenshot-readiness planning only. It must not claim real
browser screenshots unless actual capture exists.

## v169_65 CI logs repair map update

`map_element.md` remained reference/navigation-only during cycle 1385. The uploaded logs were repaired without importing sandbox runtime code, wallet logic, payment logic, lock files or CI workflow files.


## v169_66 CI logs/test execution repair map update

`map_element.md` remained reference/navigation-only during cycle 1386. The uploaded CI log repair did not import sandbox runtime code, wallet/payment logic, lock files or CI workflow files. The repaired issue was internal EFHC test/build infrastructure: E2E skip scoping, ORM `__table_args__`, and `/app` route vs `_app.tsx` shell separation.

## v169.68 critical test-control repair navigation

`map_element.md` remains reference/navigation-only. It must not be used to
justify removing tests or lowering guards. During v169.68 the repair base was
v169.66, not v169.67. The test-control incident was handled by restoring active
architecture-test visibility and adding `TEST_GUARD_MANIFEST` plus
`scripts/ci/check_test_suite_integrity.py`.

Sandbox references may guide future domain consolidation, but only after exact
old-test to active-replacement invariant mapping exists.

## v169_70 CI log repair navigation note

`map_element.md` remains reference/navigation only. During cycle 1390 it was not
used as a source for runtime code, CI workflow, test deletion, translation, or
financial logic. Test consolidation remains audit-only until the user approves
a concrete one-to-one mapping.


## v169_71 test-control note

Pесочница remains reference-only. Test consolidation in cycle 1390 was limited to mapped wave-3 i18n guards and did not import sandbox runtime, CI or translations.

## v169_75 fresh CI shell verification map update

`map_element.md` remained a reference/navigation layer during cycle 1393.
The fresh CI log was used to verify the EFHC-native shell/build state only.
No Vue, Solid, Nuxt, Vanilla runtime, lock file, CI file, wallet/payment
logic, sandbox translation or foreign economy was imported.

The next sandbox-relevant lane remains public UI guard work for Energy,
Panels and Exchange, using donor patterns only as visual/UX references.

## v169_76 — Public Energy / Panels / Exchange guard matrix

The active 1394 guard pass uses this map as reference/navigation only. The
protected EFHC triad is:

| Surface | Reference family | EFHC guard target | Boundary |
|---|---|---|---|
| Energy | TelegramUI / Mark42 cards, chips and progress rhythm | first-screen public action cards to `/panels` and `/exchange` | no admin diagnostics or economy change |
| Panels | TelegramUI sections, Telebook compact rows | `100 EFHC` activation preview, active/archive roads and idempotent activation | bonus-first/main-second invariant preserved |
| Exchange | Telegram DisplayData rows and safe MainButton intent | one-way `kWh → EFHC` preview/convert flow | no reverse exchange, no withdraw road mixing |

No Vue, Solid, Nuxt, Vanilla runtime, foreign lock files, CI files or wallet
payment logic is imported into EFHC Bot by this pass.



## v169_77 — Admin visible functions guard matrix usage

The user supplied `Песочница.xz` and five extra Telegram Mini App templates
during the Admin evidence pass. They were checked as reference/navigation
sources only. The main sandbox manifest reports 29407 files and 8118
directories with zero nested archives remaining. Extra template ZIP files
passed `testzip=None`.

Cycle 1395 used the sandbox only for Admin/TMA evidence orientation and kept
EFHC runtime under the current Next.js / React / Tailwind canon. No Vue,
Solid, Nuxt, Vanilla, foreign lock file, CI file, wallet/payment logic or
translation source was copied.

New evidence layer:

- `docs/admin/ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX.md`;
- `docs/audits/ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX_AUDIT_V169_77.md`;
- `reports/generated/admin_visible_functions_guard_matrix_v169_77.json`;
- `tests/architecture/test_admin_visible_functions_guard_matrix.py`.

## v169_78 — cycle 1396 wording boundary update

Status: reference-only sandbox navigation update.

Cycle 1396 used the sandbox only as orientation for Ranks, Hub and
Browser-Shop wording boundaries. No Vue, Solid, Nuxt, Vanilla, foreign lock
file, CI file, wallet/payment logic or translation source was imported.

User correction applied: the word `game` is allowed for ordinary EFHC Bot
product language. The active ban is gambling, loto, betting,
tournament-like financial contests and random financial reward meaning.

The active guard is now named by meaning:

- `ops/i18n/audit_forbidden_gambling_chance_contour.py`.

The old path remains only as a compatibility shim:

- `ops/i18n/audit_forbidden_gaming_contour.py`.

The 1396 public wording matrix is:

- `docs/frontend/RANKS_HUB_BROWSER_SHOP_WORDING_GUARD_MATRIX.md`.

## v169_82 range closure navigation note

Cycle 1400 closed the `1390-1400` range. The sandbox remains a reference
layer only. No Vue, Solid, Nuxt, Vanilla runtime, CI file, lock file, wallet
logic, payment logic or translation source was imported during the closure.

Next use of this map should wait for the new audit and then route only the
needed UI, TMA, TonConnect or Admin patterns through EFHC React/Tailwind and
SSOT/NORM guards.

## v169_85 — P0 backend and FSM planning use

Cycle 1403 used this sandbox map only as a reference/navigation layer for architecture discipline, module-split planning and guard organization. No Vue/Solid/Nuxt/Vanilla runtime, lock file, CI file, wallet/payment logic, donor economics, donor translations or sandbox code was imported into EFHC Bot.

Backend P0 repair work remains governed by EFHC SSOT/NORM, active tests, AI Archive Laws and direct user instructions. FSM split planning uses sandbox separation ideas only at the conceptual level; implementation must remain EFHC-native Python code.


## v169_86 — P0 backend/deposit-cache planning navigation

`map_element.md` was consulted as a sandbox navigation/reference layer only. The cycle-1404 work did not import sandbox runtime code, CI files, lock files, wallet/payment logic or translations.

For upcoming P0 backend cycles, sandbox relevance is limited to audit organization and TMA/payment UX context. Financial idempotency and deposit protection must follow EFHC backend canon and `efhc_admin.idempotency_key`, not donor template code.



## v169_87 — HEAL-0045 identity repair navigation

Cycle 1405 used `map_element.md` and the sandbox archives only as a
reference/navigation layer while repairing backend identity canon. No sandbox
runtime, lock file, CI file, wallet/payment logic or translation text was
imported.

Active EFHC result:

- `backend/app/crud/referrals_crud.py::admin_top_inviters()` now joins
  referral and bonus `tg_id` aggregates to `User.tg_id`, not internal `User.id`;
- `tests/architecture/test_heal0045_tg_id_identity_canon.py` locks this
  identity boundary.

This update is navigational only and does not authorize framework migration or
runtime copy from Vue/Solid/Nuxt/Vanilla/template sandboxes.

## v169_90 — HEAL-0018 transaction-boundary repair navigation

Cycle 1409-1410 used `map_element.md` and sandbox archives only as
reference/navigation context for architecture discipline. No Vue/Solid/Nuxt/
Vanilla runtime, lock file, CI file, wallet/payment logic, donor economics or
translations were imported.

Active EFHC result:

- `backend/app/services/transactions_service.py` now uses service-owned
  commit/rollback in the core money transaction helper;
- hidden `begin_nested()` fallback is removed from that helper;
- `backend/app/services/exchange_service.py` closes read-only preflight
autobegin before entering transactions_service;
- withdraw atomicity remains routed to HEAL-0024 / cycle 1411.


## v169_92 — Kernel mandatory Start Core and HEAL-0055 deposit cache

Pесочница remains reference/navigation only. Runtime code was not imported from sandbox archives.

Operator Kernel is now mandatory in Start Core navigation. Before topic analysis, load:

- `ops/operator_kernel/cache/file_map.json`;
- `ops/operator_kernel/config/routes.yaml`.

Deposit duplicate protection is now routed through DB-backed long-retention idempotency in `efhc_admin.idempotency_key`, not process-local memory cache.


## v169_93 — P0 retention/cross-guard navigation update

Operator Kernel and this sandbox map were used only as reference/navigation
layers for cycles 1413-1414. Runtime code from sandbox archives was not
imported.

Current backend P0 route focus:

| Cycle | Focus | Primary files |
|---|---|---|
| 1413 | HEAL-0055 deposit idempotency retention | `backend/app/services/efhc_deposits_service.py`, `docs/backend/P0_HEAL0055_DEPOSIT_RETENTION_POLICY.md` |
| 1414 | P0 cross-guard consolidation | `tests/architecture/test_p0_cross_guard_consolidation.py`, existing HEAL guards |

The next backend route is cycle 1415 targeted backend checks/log repair. If logs
are supplied, logs must be read before running broad checks.


## v169.94 CI log repair navigation note

Operator Kernel remained mandatory for Start Core. The supplied CI log was read
first, then the exact ruff/pytest failures were repaired. Sandbox archives were
used only as navigation/reference context; no runtime code was imported.

## v169_95 — FSM split navigation update

Cycles 1417-1420 used the sandbox only as a reference/navigation layer for bot,
backend and testing patterns. Runtime code, CI files, lock files, wallet/payment
logic and translations were not imported.

FSM implementation is now split into:

- `backend/app/bot/fsm/dto.py`;
- `backend/app/bot/fsm/backend.py`;
- `backend/app/bot/fsm/manager.py`;
- `backend/app/bot/fsm/decorators.py`.

`backend/app/bot/states.py` remains a compatibility facade until a separate
handler import migration is approved.

## v169.96 CI log repair navigation update

Operator Kernel remained mandatory for the log-repair pass. The sandbox archives
were used only as reference/navigation context; no runtime, CI, lock file,
wallet/payment logic or translation source was imported.

Relevant repair anchors:

- `backend/app/bot/fsm/manager.py` — supervised task spawning through
  `create_logged_task()`;
- `docs/audits/P0_CI_LOG_REPAIR_AUDIT_V169_96.md` — log-first repair audit;
- `docs/cycles/WORK_CYCLES_1421_CI_LOG_REPAIR.md` — cycle record;
- `reports/generated/p0_ci_log_repair_v169_96.json` — machine-readable
  evidence.

# v169.97 cycle 1422 economic risk repair sandbox note

Cycle 1422 used `map_element.md` and the sandbox archives only as
reference/navigation context while repairing backend economic invariants. No
Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor
logic, donor economics or translations were imported.

Песочница использована только как reference/navigation layer. Runtime-код не
переносился.


# v169.99 cycle 1424 withdraw/exchange atomicity note

Cycle 1424 used `map_element.md` and the uploaded sandbox archives only as
reference/navigation context. Runtime code, CI files, lock files, wallet/payment
logic, donor economics and donor translations were not imported.

Navigation anchors added/updated:

- `backend/app/services/transactions_service.py` — `credit_user_from_bank_nocommit`, exchange rollback guard, exchange idempotency inside lock/retry loop.
- `backend/app/services/withdraw_service.py` — atomic cancel/reject refund paths.
- `tests/architecture/test_economic_risk_guards.py` — P1 withdraw/exchange guards.
- `docs/cycles/WORK_CYCLES_1424_WITHDRAW_EXCHANGE_ATOMICITY_REPAIR.md`.
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`.

## v170.03 — Security audit reconciliation navigation update

Status: cycle `1428` is a planning/reconciliation pass after the supplied P0
security audit. It does not import or reuse sandbox runtime code.

Primary EFHC files for the next security lane:

| Topic | EFHC files | Sandbox role |
|---|---|---|
| Wallet proof boundary | `backend/app/routes/wallets_routes.py`, `backend/app/services/wallets_service.py`, `backend/app/services/tonconnect_proof_service.py` | Reference only for TonConnect UX and handoff patterns |
| Cron control plane | `backend/app/core/config_core.py`, `backend/app/routes/system_routes.py`, `env.prod.example` | No sandbox runtime use |
| Telegram auth freshness | `backend/app/core/security_core.py`, `backend/app/middleware/telegram_webapp_auth.py` | TMA auth shape reference only |
| Legacy frontend headers | `frontend/src/lib/api.ts`, `frontend/src/lib/auth.ts`, `frontend/src/lib/telegram.ts` | Reference only for shell/client separation |
| Regression hardening | `tests/architecture/`, `tests/efhc_backend/` | Test organization ideas only |

Sandbox rule for this lane:

- Песочница may help navigate TonConnect/TMA UI ideas.
- Песочница must not supply wallet/payment runtime logic.
- Песочница must not supply secrets, configs, lock files, CI files or
  production security policy.
- EFHC backend security canon and audit documents remain the source of truth.

Audit truth decision:

- The audit title mentions `v170.01`.
- The audit body states the inspected archive was `v170.02`.
- The repair line proceeds from actual HEAD `v170.02`.

## Cycle 1430 sandbox / security reference note

Cycle 1430 used `map_element.md` and the sandbox archives only as
reference/navigation context for Telegram Mini App auth boundaries, admin
surface separation and OPSEC discipline. Runtime code, CI files, lock files,
wallet/payment logic, economics, secrets/configs and translations were not
copied from sandbox.

Primary EFHC files touched by the cycle:

| Surface | EFHC file | Sandbox use |
|---|---|---|
| Telegram initData freshness | `backend/app/core/security_core.py` | TMA auth-shape reference only |
| Secrets redaction | `backend/app/core/logging_core.py` | OPSEC discipline reference only |
| Legacy headers | `frontend/src/lib/api.ts`, `backend/app/main.py`, `backend/app/__init__.py` | Boundary/navigation reference only |
| Admin UX note | `frontend/src/pages/admin/index.tsx` | Admin shell wording discipline only |

The source of truth remains EFHC security canon and audit documents.


## Cycle 1431 sandbox / security regression note

Cycle 1431 used `map_element.md` and the uploaded sandbox archives only as a
reference/navigation layer while adding EFHC-native security regression guards.
No sandbox runtime code, wallet/payment logic, CI files, lock files, configs,
secrets, economics or translations were copied.

Primary EFHC files for cycle 1431:

| Topic | EFHC files | Sandbox role |
|---|---|---|
| Admin route auth | `backend/app/routes/admin*.py` | Navigation reference only |
| Owner-scoped money routes | `deposit_routes.py`, `withdraw_routes.py`, `payment_intents_routes.py`, `wallets_routes.py` | Navigation reference only |
| Webhook dedupe order | `backend/app/routes/system_routes.py`, `backend/app/deps.py` | No runtime use |
| Regression guards | `tests/architecture/test_security_regression_hardening.py` | No test code copied |


## Cycle 1432 navigation note

Current HEAD after this pass: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`.
Use `docs/audits/CI_LOG_REPAIR_1432_LOGS_72432961872.md` and
`docs/cycles/WORK_CYCLES_1432_CI_LOG_REPAIR.md` for the CI-log repair path.
Security/economic runtime anchors remain in `backend/app/services/wallets_service.py`,
`backend/app/core/config_core.py`, `backend/app/services/transactions_service.py`
and `backend/app/services/panels_service.py`.

# v170.08 cycle 1433 Operator Kernel-first sandbox note

Cycle 1433 used `map_element.md` and the uploaded sandbox/template archives
only as a reference/navigation layer while strengthening the existing Operator
Kernel. The result is a docs-only Kernel-first standard, not a new competing
Kernel. No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment
logic, foreign economy, secrets/configs or translations were imported.


# v170.09 cycle 1434 security minor repair navigation note

Cycle 1434 used `map_element.md` and the uploaded sandbox/template archives
only as a reference/navigation layer while closing the v170.08 security audit
minor findings. No sandbox runtime code, wallet/payment logic, CI files, lock
files, configs, secrets, economics or translations were copied.

Primary EFHC files for cycle 1434:

| Topic | EFHC files | Sandbox role |
|---|---|---|
| Ads test-mode fail-fast | `backend/app/core/config_core.py`, `backend/app/integrations/ads_providers.py` | OPSEC reference only |
| Monetary rate-limit prefixes | `backend/app/core/system_locks.py` | Navigation reference only |
| Prod env placeholders | `env.prod.example` | OPSEC reference only |
| Guards | `tests/architecture/test_security_audit_v170_08_minor_repair.py`, `test_monetary_rate_limit_enabled.py` | No test code copied |


## Cycle 1435 — cold start MVP UX / first-paint asset

- Canon: `docs/NORM/COLD_START_MVP_UX_CANON.md`.
- Visual norm: `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`.
- Asset SSOT: `docs/SSOT/PROJECT_ASSET_LINKS.md`.
- First-paint image: `frontend/public/skins/1.webp`.
- CSS anchor: `frontend/src/styles/globals.css`.
- Guard: `tests/architecture/test_cold_start_mvp_ux_asset_guard.py`.
- Rule: cold start is not an MVP blocker when cached shell first and
  stale-while-revalidate UX are preserved.

## Cycle 1445 — CI/log repair + BNB/source skin cleanup / v170.21

- Input HEAD: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`.
- Input logs: `logs_72623328892.zip`.
- Output archive: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`.
- Main log roots: ruff import ordering, mypy bank typing, stale admin bank guard, missing admin hub module guard, Kernel refresh marker, line72, legacy-word false positive, route inventory count drift, Healer atlas schema drift and wallet test DB isolation.
- Removed old source skin: `frontend/public/skins/1.png`.
- Canonical runtime skin asset remains: `frontend/public/skins/1.webp`.
- Песочница использована только как reference/navigation layer. Runtime-код не переносился.

## v170.24 / cycle 1448 — linkage minor findings repair

- Cycle doc: `docs/cycles/WORK_CYCLES_1448_LINKAGE_MINOR_FINDINGS_REPAIR.md`.
- Audit doc: `docs/audits/LINKAGE_MINOR_FINDINGS_REPAIR_AUDIT_V170_24.md`.
- Machine report: `reports/generated/full_linkage_report_v170_24.json`.
- Repair report: `reports/generated/linkage_minor_findings_repair_v170_24.json`.
- Main guard: `tests/architecture/test_full_linkage_architecture_and_ui_states.py`.
- Admin Hub seam: `frontend/src/lib/api/generated/adminSeams.ts`.
- Admin Hub page: `frontend/src/features/admin/AdminHubPage.tsx`.
- Generator: `ops/openapi/generate_frontend_seam_types.py`.
- Песочница used only as reference/navigation layer.

# v170_25 cycle 1449 frontend visual/i18n/UX repair

Status: safe static repair pass closed F-01 through F-09 from the
visual/i18n/buttons UX audit. Use `frontend/src/lib/humanLabels.ts` for
shared public/admin human labels. Screenshot proof F-10 remains a
future runtime browser/TMA validation cycle.

## Cycle 1451 — v170.27 CI log repair

- Input logs: `logs_72682359351.zip`.
- Root causes: ruff import order, stale chat/Kernel/profile/canon
  guards, and missing generated admin withdraw preview type.
- Repair report: `reports/generated/ci_log_repair_v170_27.json`.
- Guard: `tests/architecture/test_ci_log_repair_v170_27_guards.py`.
- Next safe step: fresh CI rerun proof or factual log repair.


## Cycle 1452 — v170.28 dashboard visual direction plan

- Active plan: `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Range: `1455–1496`, 42 cycles.
- Direction: Admin Dashboard Layer + Simulation Dashboard Layer.
- Grafana archive: `grafana-main.zip` inspected as reference only.
- Runtime code from Grafana was not copied.
- Песочница remains reference/navigation/prototype layer only.
- Machine report: `reports/generated/dashboard_visual_direction_plan_v170_28.json`.
- Guard: `tests/architecture/test_dashboard_visual_direction_plan.py`.


## Cycle 1459 — Dashboard Component Contract Map

Status: `ACTIVE_DASHBOARD_COMPONENT_CONTRACT`

Primary contract:

- `docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`.
- `frontend/src/lib/dashboard/componentContract.ts`.

Machine proof:

- `reports/generated/dashboard_component_contract_v170_35.json`.
- `tests/architecture/test_dashboard_component_contract.py`.

Contract states:

- loading;
- empty;
- error;
- stale;
- success.

Contract data kinds:

- raw;
- derived;
- synthetic_preview;
- real_timeseries.

Grafana reference alignment:

| Grafana pattern | EFHC contract meaning |
|---|---|
| PanelChrome | title, source, state, actions |
| DashboardGrid | panels keep stable state model |
| RefreshPicker | freshness and updatedAt are explicit |
| Variables | filters affect display only |
| Inspector | safe drawer, no secrets or raw payload |
| BigValue | source and data kind stay visible |
| Sparkline | synthetic preview must be marked |

Boundary:

- No Grafana runtime code copied.
- No Песочница runtime code copied.
- No dependencies, locks, CI, backend logic or economy copied.


## Cycle 1463 — Progress System Foundation Map

Status: `ACTIVE_PROGRESS_SYSTEM_FOUNDATION`.

Primary runtime anchor:

- `frontend/src/components/dashboard/ProgressSystem.tsx`.

Wrappers:

- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`;
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`.

Progress components:

- `DashboardProgressBar`;
- `DashboardSegmentedProgress`;
- `DashboardCircularProgress`;
- `DashboardCountdownProgress`;
- `DashboardMilestoneProgress`.

Grafana reference anchors for this cycle:

| Grafana anchor | EFHC use |
|---|---|
| `BarGauge` | linear / segmented progress discipline |
| `RadialGauge` | circular progress discipline |
| `BigValue/PercentChange` | progress value / delta label discipline |
| `StatusHistoryPanel` | future activity strip discipline |
| `StateTimelinePanel` | future milestone timeline discipline |
| `ProgressBar` | simple linear progress reference |

Boundary:

- Grafana runtime code copied: no.
- Песочница runtime code copied: no.
- Heavy chart dependency added: no.
- Economy/backend/DB/CI/locks changed: no.

## Cycle 1464 — Mini Charts Foundation Map

Status: `DONE_LOCAL` in `v170.40`.

Active document:

`docs/NORM/MINI_CHARTS_FOUNDATION.md`

Runtime component:

`frontend/src/components/dashboard/MiniCharts.tsx`

Mini chart components:

- `DashboardMiniSparkline`;
- `DashboardMiniAreaChart`;
- `DashboardMiniBarChart`;
- `DashboardActivityStrip`.

Grafana reference anchors for this cycle:

| Grafana anchor | EFHC use |
|---|---|
| `Sparkline/Sparkline.tsx` | compact sparkline discipline |
| `Sparkline/utils.ts` | point normalization idea only |
| `Table/Cells/SparklineCell.tsx` | table-cell mini chart reference |
| `TimeSeriesPanel.tsx` | future full time-series discipline |
| `TrendPanel.tsx` | future trend panel discipline |
| `XYChartPanel.tsx` | future relationship chart discipline |
| `StatusHistoryPanel.tsx` | activity strip discipline |
| `StateTimelinePanel.tsx` | future timeline discipline |

Use these only as visual/reference anchors. Do not copy Grafana
runtime code, dependencies, lock files, CI files, backend logic or
plugin runtime into EFHC Bot.

No Grafana source code is copied.

Guard: `tests/architecture/test_mini_charts_foundation.py`.


## Cycle 1469 — Energy Dashboard Runtime Port Map

Status: `ACTIVE_ENERGY_DASHBOARD_RUNTIME_PORT`.

Primary runtime anchor:

- `frontend/src/components/dashboard/EnergyDashboardRuntime.tsx`.
- `frontend/src/pages/index.tsx`.

Docs and proof:

- `docs/NORM/ENERGY_DASHBOARD_RUNTIME_PORT.md`.
- `docs/NORM/ENERGY_DASHBOARD_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md`.
- `docs/cycles/WORK_CYCLES_1469_ENERGY_DASHBOARD_RUNTIME_PORT.md`.
- `reports/generated/energy_dashboard_runtime_port_v170_45.json`.
- `tests/architecture/test_energy_dashboard_runtime_port.py`.

Runtime truth model:

- raw values from existing `SyncSnapshot`;
- derived visual progress and split metrics;
- no synthetic preview data in runtime;
- no real time-series claim until read-only backend contracts exist.

Grafana reference anchors for this cycle:

| Grafana anchor | EFHC use |
|---|---|
| `DashboardControls.tsx` | Energy toolbar discipline |
| `TimeRangePicker.tsx` | snapshot-only period control |
| `RefreshPicker.tsx` | freshness marker discipline |
| `PanelChrome.tsx` | panel shell/source/status discipline |
| `PanelStatus.tsx` | freshness/status semantics |
| `BigValue` | hero KPI hierarchy |
| `Sparkline/Sparkline.tsx` | future real trend reference only |
| `TimeSeriesPanel.tsx` | future real time-series reference only |
| `TrendPanel.tsx` | future trend discipline only |
| `StatusHistoryPanel.tsx` | activity strip discipline |
| `StateTimelinePanel.tsx` | future timeline discipline |

Boundary:

- No Grafana source code is copied.
- No Песочница runtime code is copied.
- No backend/economy/write-flow/dependency/lock change.


## Cycle 1489 — Admin System Health Dashboard

- Runtime component: `frontend/src/components/admin/AdminSystemHealthDashboardRuntime.tsx`
- Route: `frontend/src/pages/admin/system.tsx`
- Norm: `docs/NORM/ADMIN_SYSTEM_HEALTH_DASHBOARD.md`
- Grafana reference analysis: `docs/NORM/ADMIN_SYSTEM_HEALTH_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- Guard: `tests/architecture/test_admin_system_health_dashboard.py`


## v170.68 / cycle 1492 — Synthetic Data Cleanup / Truth Hardening
- Norm: `docs/NORM/SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md`
- Grafana analysis: `docs/NORM/SYNTHETIC_DATA_CLEANUP_GRAFANA_ELEMENT_ANALYSIS.md`
- Runtime component: `frontend/src/components/admin/AdminObservabilityTimeseriesDashboardRuntime.tsx`
- Backend route hardened: `backend/app/routes/admin_observability_routes.py`
- Guard: `tests/architecture/test_synthetic_data_cleanup_truth_hardening.py`
- Report: `reports/generated/synthetic_data_cleanup_truth_hardening_v170_68.json`
- Next: `1493 — Visual Performance / Bundle Safety`.


## Cycle 1495 — Final Dashboard Visual Audit / Screenshot Proof

- Norm: `docs/NORM/FINAL_DASHBOARD_VISUAL_AUDIT_SCREENSHOT_PROOF.md`
- Grafana analysis: `docs/NORM/FINAL_DASHBOARD_VISUAL_AUDIT_GRAFANA_ELEMENT_ANALYSIS.md`
- Guard: `tests/architecture/test_final_dashboard_visual_audit_screenshot_proof.py`
- Report: `reports/generated/final_dashboard_visual_audit_screenshot_proof_v170_71.json`
- Evidence dir: `reports/evidence/screenshots/dashboard_1495/`
- Next: `1496 — Dashboard Direction Handoff / Backlog Freeze`.


## Work item 1498 — CI Log Repair / Public Dashboard i18n Hardening

- Norm: `docs/NORM/CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md`
- Grafana analysis: `docs/NORM/CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_GRAFANA_ELEMENT_ANALYSIS.md`
- Cycle note: `docs/cycles/WORK_CYCLES_1498_CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md`
- Guard: `tests/architecture/test_ci_log_repair_public_dashboard_i18n_hardening.py`
- Report: `reports/generated/ci_log_repair_public_dashboard_i18n_hardening_v170_74.json`
- Log repaired: `logs_73496341059.zip`
- Public dashboard locale invariant: 13 active languages for user-facing dashboards only.
- No Grafana runtime code copied. No Песочница runtime code copied.


## Work item 1499 — VIS-03 Withdraw History Semantic Repair / Final Range Cleanup

- Active norm: `docs/NORM/VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md`
- Grafana analysis: `docs/NORM/VIS_03_WITHDRAW_HISTORY_GRAFANA_ELEMENT_ANALYSIS.md`
- Cycle note: `docs/cycles/WORK_CYCLES_1499_VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md`
- Change report: `reports/change_cycle_2026-06-11_v170_75_cycle_1499_vis_03_withdraw_history_semantic_repair.md`
- Generated report: `reports/generated/vis_03_withdraw_history_semantic_repair_v170_75.json`
- Green CI proof: `reports/generated/green_ci_log_proof_v170_75.json`
- Guard: `tests/architecture/test_vis_03_withdraw_history_semantic_repair.py`
- Runtime surface: `frontend/src/pages/withdraw.tsx`
- Finding closed: `VIS-03` public withdraw history balance type no longer renders raw `main` / `bonus` values.
- Песочница/Grafana remain reference-only layers.


## Withdraw V1 payout canon / PACK-01

- `docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md` — SSOT по admin
  withdraw payout-flow.
- `docs/NORM/WITHDRAW_FLOW_NORM.md` — нормативная модель статусов
  withdraw.
- `docs/NORM/WITHDRAW_AUDIT_CANON.md` — правила аудита withdraw-flow.
- `docs/NORM/AUDIT_RULES.md` — общие правила аудита по канону проекта.
- `docs/NORM/WITHDRAW_CANON_CLARIFICATION.md` — completion norm for
  PACK-01.
- `tests/architecture/test_withdraw_v1_payout_canon.py` — regression
  guard for V1 payout canon.

## Cycle 1512 — Admin Runtime Fix / Admin Seams Cleanup

- `docs/NORM/ADMIN_RUNTIME_FIX_AND_SEAMS_CLEANUP.md` — P1 admin runtime
  fix canon and proof boundaries.
- `docs/NORM/ADMIN_SEAMS_CLEANUP_TRACKING.md` — tracked admin seam
  migration debt.
- `docs/NORM/ADMIN_ORPHAN_ROUTE_STATUS.md` — legacy/internal status for
  admin routes without direct UI.
- `tests/architecture/test_admin_money_call_signatures.py` — AST guard
  for admin money call signatures.
- `tests/efhc_backend/admin/test_admin_withdrawals_hold_repair_runtime.py`
  — runtime guard for withdraw hold repair branch.
- `tests/efhc_backend/admin/test_admin_bank_bonus_debit_runtime.py` —
  runtime guard for admin BONUS debit branch.

## Cycle 1513 — Admin seams full migration / tail closure

- `docs/NORM/TAIL_FIX_REPORT.md` — цикл 1513: хвосты CI/admin seams/runtime proof.
- `docs/NORM/ADMIN_SEAMS_FULL_MIGRATION_REPORT.md` — отчёт полной миграции admin pages на `adminSeams.ts`.
- `docs/NORM/ADMIN_RUNTIME_TEST_PROOF.md` — статус runtime P1 tests и требование fresh CI proof.
- `docs/NORM/ADMIN_ORPHAN_ROUTE_STATUS.md` — финальный статус P3 orphan routes.
- `tests/architecture/test_tail_closure.py` — guard честного proof-статуса 1513.
- `tests/architecture/test_admin_frontend_uses_admin_seams.py` — strict guard: raw admin `apiRequest` в admin pages запрещён.
## Cycle 1514 — Admin UX QA / Visual Regression / Full Button Click Proof

- `docs/NORM/ADMIN_UX_QA_VISUAL_REGRESSION_CLICK_PROOF.md` — cycle 1514 truth/proof boundary and root-cause repairs.
- `docs/cycles/WORK_CYCLES_1514_ADMIN_UX_QA_VISUAL_REGRESSION_CLICK_PROOF.md` — work-cycle note.
- `tests/architecture/test_admin_ux_qa_visual_regression_click_proof.py` — guard for cycle 1514 docs, admin seams, admin notification table and outcome delivery JSONB path.
- `reports/generated/admin_ux_qa_visual_regression_click_proof_v170_90.json` — machine-readable proof status.


## Cycle 1518 — Browser/Admin Visual Capture / Button-click Proof Execution

Navigation anchors:

- Norm: `docs/NORM/BROWSER_ADMIN_VISUAL_BUTTON_CLICK_PROOF.md`
- Cycle: `docs/cycles/WORK_CYCLES_1518_BROWSER_ADMIN_VISUAL_CAPTURE_BUTTON_CLICK_PROOF.md`
- Harness: `ops/frontend/admin_visual_button_click_proof.py`
- Proof JSON: `reports/generated/browser_admin_visual_button_click_proof_v170_94.json`
- Screenshots: `reports/screenshots/admin_visual_1518/`
- Guard: `tests/architecture/test_browser_admin_visual_button_click_proof.py`

Reference layers:

- Песочница remains reference/navigation/prototype layer only.
- Grafana remains visual-pattern/reference layer only.
- No runtime code was copied from either source.
- `python ops/operator_kernel/file_map.py --refresh`

## Cycle 1568 — Observability, deployment and rollback readiness

Navigation anchors:

- Norm: `docs/NORM/OBSERVABILITY_DEPLOYMENT_ROLLBACK_NORM.md`
- Audit: `docs/audits/OBSERVABILITY_DEPLOYMENT_ROLLBACK_READINESS_1568.md`
- Runbooks: `docs/RUNBOOKS/DEPLOYMENT_ROLLBACK.md` and
  `docs/RUNBOOKS/OBSERVABILITY_INCIDENTS.md`
- Runtime metrics: `backend/app/core/runtime_observability.py`
- Readiness routes: `backend/app/routes/system_routes.py`
- Deployment: `ops/k8s/`
- Rollback tools: `ops/release/rollback_preflight.py` and
  `ops/release/rollback_drill.py`
- Visual proof: `reports/generated/observability_visual_matrix_v171_44.json`
- Admin proof: `reports/generated/observability_admin_visual_v171_44.json`
- Visual implementation registry:
  `reports/generated/frontend_visual_improvements_v171_44.json`
- Full GitHub CI and real cluster operations remain operator-owned and are not
  claimed by this local cycle.



## PWA / WebView / WCAG / performance current route
- `docs/audits/PWA_TELEGRAM_WEBVIEW_DEVICE_WCAG_PERFORMANCE_1569.md`
- `reports/generated/cache_policy_v171_45.json`
- `reports/generated/pwa_webview_device_wcag_performance_v171_45.json`
- `tests/architecture/test_pwa_webview_wcag_performance_current_release.py`

## Cycle 1570 — full interaction, recovery and adaptive cache

Navigation anchors:

- Audit:
  `docs/audits/FULL_PUBLIC_ADMIN_INTERACTION_LOAD_RECOVERY_MATRIX_1570.md`
- Cycle report: `reports/generated/CYCLE_1570_REPORT.md`
- Full matrix:
  `reports/generated/full_public_admin_interaction_load_recovery_v171_46.json`
- Cache truth: `reports/generated/cache_policy_v171_46.json`
- Performance budgets:
  `reports/generated/frontend_compressed_route_budgets_v171_46.json`
- Public proof: `reports/generated/public_interaction_visual_v171_46.json`
- Admin proof: `reports/generated/admin_interaction_visual_v171_46.json`
- Recovery proof: `reports/generated/load_recovery_visual_v171_46.json`
- Guard: `tests/architecture/test_dynamic_cache_performance_matrix.py`
- Screenshots are stored in the separate v171.46 companion archive.

## Cycle 1572 continuation route / v171.49

- Workspace: `/mnt/data/efhc_workspace`
- Current kernel: `KERNEL.md`
- Transfer boundary: `docs/NORM/AI_EXECUTION_BOUNDS_AND_HANDOFF_STANDARD.md`
- Release status: `docs/NORM/RELEASE_PROOF_STATUS.md`
- Master route: `docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`
- Active cycle index: `docs/cycles/WORK_CYCLES.md`
- Range plan: `docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`
- Last repair evidence: `reports/generated/cycle_1572_transfer_repair_v171_48.json`
- Planning sync evidence: `reports/generated/cycle_1572_planning_sync_v171_49.json`
- Next input: newest user-supplied `logs_*.zip`; no current log is embedded.


## Cycle 1589 — referral activation and PostgreSQL test depth

- Cycle: `docs/cycles/WORK_CYCLE_1589_REFERRAL_ACTIVATION_RUNTIME_TEST_DEPTH.md`
- Runtime: `backend/app/crud/referrals_crud.py`,
  `backend/app/services/referral_service.py`,
  `backend/app/services/panels_service.py`
- PostgreSQL proof: `tests/integration/test_referral_runtime.py`
- CI proof gate: `ops/ci_checks/assert_pytest_junit.py`
- Causal record: `reports/causal_v171_86_referral_activation_runtime_test_depth.json`
