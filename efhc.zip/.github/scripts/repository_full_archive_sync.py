#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import os
import re
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

ARCHIVE_RE = re.compile(r"^FRONTEND_v\d+\.zip$")
VERSION_RE = re.compile(r"^FRONTEND_v\d+$")
PERSISTENT_IMPORT_README = PurePosixPath("_import/README.md")
ENV_APPROVAL_PATH = PurePosixPath("release_config/ENV_OWNER_APPROVAL.json")
ENV_POLICY_PATH = PurePosixPath("release_config/ENV_OWNER_PROTECTION.json")
REQUIRED_SELF_HOSTED = (
    PurePosixPath(".github/workflows/repository-import-sync.yml"),
    PurePosixPath(".github/scripts/repository_full_archive_sync.py"),
    PERSISTENT_IMPORT_README,
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_member(info: zipfile.ZipInfo) -> PurePosixPath:
    rel = PurePosixPath(info.filename)
    if rel.is_absolute() or not rel.parts or ".." in rel.parts:
        raise RuntimeError(f"unsafe archive path: {info.filename!r}")
    if rel.parts[0] == ".git":
        raise RuntimeError(f".git payload forbidden: {info.filename!r}")
    file_type = (info.external_attr >> 16) & 0o170000
    if file_type == stat.S_IFLNK:
        raise RuntimeError(f"symlink archive entry forbidden: {info.filename!r}")
    return rel


def extract_release(archive: Path, staging: Path) -> None:
    with zipfile.ZipFile(archive) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"ZIP CRC failure: {bad}")
        infos = zf.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise RuntimeError("ZIP contains duplicate entries")
        for info in infos:
            rel = safe_member(info)
            target = staging.joinpath(*rel.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(info))
            mode = (info.external_attr >> 16) & 0o777
            target.chmod(mode or 0o644)


def validate_release(staging: Path, archive: Path) -> str:
    if not ARCHIVE_RE.fullmatch(archive.name):
        raise RuntimeError(f"invalid release archive name: {archive.name}")
    version_path = staging / "VERSION"
    if not version_path.is_file():
        raise RuntimeError("VERSION missing from release")
    version = version_path.read_text(encoding="utf-8").strip()
    if not VERSION_RE.fullmatch(version):
        raise RuntimeError(f"invalid VERSION: {version!r}")
    if archive.stem != version:
        raise RuntimeError(f"archive/VERSION mismatch: {archive.stem!r} != {version!r}")

    suffix = version.removeprefix("FRONTEND_")
    required = [
        staging / f"FRONTEND_{suffix}.html",
        staging / f"SHOP_{suffix}.html",
        *(staging.joinpath(*path.parts) for path in REQUIRED_SELF_HOSTED),
    ]
    missing = [str(path.relative_to(staging)) for path in required if not path.is_file()]
    if missing:
        raise RuntimeError(f"release self-hosting/companion files missing: {missing}")

    import_dir = staging / "_import"
    for path in import_dir.rglob("*"):
        if path.is_file() and path.suffix.lower() == ".zip":
            raise RuntimeError(f"physical release must not carry transport ZIP inside itself: {path.relative_to(staging)}")
    return version


def is_owner_protected_env(rel: PurePosixPath) -> bool:
    name = rel.name.lower()
    return name == ".env" or name.startswith(".env.") or name.startswith("env.")


def protected_env_inventory(root: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for path in root.rglob("*"):
        if not path.is_file() or ".git" in path.relative_to(root).parts:
            continue
        rel = PurePosixPath(path.relative_to(root).as_posix())
        if is_owner_protected_env(rel):
            result[rel.as_posix()] = sha256_file(path)
    return result


def load_env_owner_approval(staging: Path, version: str) -> dict[tuple[str, str, str, str], bool]:
    path = staging.joinpath(*ENV_APPROVAL_PATH.parts)
    if not path.is_file():
        return {}
    import json
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema") != "EFHC_ENV_OWNER_APPROVAL_V1":
        raise RuntimeError("invalid ENV OWNER approval schema")
    if data.get("direct_owner_approval") is not True:
        raise RuntimeError("ENV approval must declare direct_owner_approval=true")
    if data.get("release_version") != version:
        raise RuntimeError("ENV approval release_version mismatch")
    approvals: dict[tuple[str, str, str, str], bool] = {}
    for item in data.get("mutations") or []:
        key = (
            str(item.get("path") or ""),
            str(item.get("action") or ""),
            str(item.get("before_sha256") or ""),
            str(item.get("after_sha256") or ""),
        )
        approvals[key] = True
    return approvals


def assert_env_owner_protection(staging: Path, repo: Path, version: str) -> None:
    policy = staging.joinpath(*ENV_POLICY_PATH.parts)
    if not policy.is_file():
        raise RuntimeError("ENV OWNER protection policy missing from physical release")
    before = protected_env_inventory(repo)
    after = protected_env_inventory(staging)
    approvals = load_env_owner_approval(staging, version)
    for rel, before_sha in sorted(before.items()):
        after_sha = after.get(rel)
        if after_sha is None:
            key = (rel, "delete", before_sha, "")
            if key not in approvals:
                raise RuntimeError(
                    f"OWNER-PROTECTED ENV deletion forbidden without exact OWNER approval: {rel}"
                )
        elif after_sha != before_sha:
            key = (rel, "replace", before_sha, after_sha)
            if key not in approvals:
                raise RuntimeError(
                    f"OWNER-PROTECTED ENV replacement forbidden without exact OWNER approval: {rel}"
                )


def remove_path(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)


def mirror_release(staging: Path, repo: Path) -> None:
    staging_names = {p.name for p in staging.iterdir()}
    for current in list(repo.iterdir()):
        if current.name == ".git":
            continue
        if current.name not in staging_names:
            remove_path(current)

    for source in staging.iterdir():
        target = repo / source.name
        if target.exists() or target.is_symlink():
            remove_path(target)
        if source.is_dir():
            shutil.copytree(source, target, copy_function=shutil.copy2)
        else:
            shutil.copy2(source, target)


def file_inventory(root: Path) -> dict[str, tuple[str, int]]:
    result: dict[str, tuple[str, int]] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or ".git" in path.relative_to(root).parts:
            continue
        rel = path.relative_to(root).as_posix()
        result[rel] = (sha256_file(path), stat.S_IMODE(path.stat().st_mode))
    return result


def verify_exact(staging: Path, repo: Path) -> None:
    expected = file_inventory(staging)
    actual = file_inventory(repo)
    if expected != actual:
        missing = sorted(set(expected) - set(actual))[:20]
        extra = sorted(set(actual) - set(expected))[:20]
        changed = sorted(k for k in set(expected) & set(actual) if expected[k] != actual[k])[:20]
        raise RuntimeError(f"repository mirror mismatch missing={missing} extra={extra} changed={changed}")
    readme = repo / "_import/README.md"
    if not readme.is_file():
        raise RuntimeError("persistent _import/README.md missing after mirror")
    transport_zips = sorted((repo / "_import").glob("FRONTEND_v*.zip"))
    if transport_zips:
        raise RuntimeError(f"transport ZIP remained after mirror: {[p.name for p in transport_zips]}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Mirror a full EFHC Frontend physical release into the GitHub working tree")
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--repo-root", default=".", type=Path)
    args = parser.parse_args()

    repo = args.repo_root.resolve()
    archive = args.archive.resolve()
    expected_import = (repo / "_import").resolve()
    if archive.parent != expected_import:
        raise RuntimeError("release archive must be uploaded directly into repository _import/")

    archive_sha = sha256_file(archive)
    with tempfile.TemporaryDirectory(prefix="efhc-full-release-") as tmp:
        staging = Path(tmp) / "release"
        staging.mkdir(parents=True)
        extract_release(archive, staging)
        version = validate_release(staging, archive)
        assert_env_owner_protection(staging, repo, version)
        mirror_release(staging, repo)
        verify_exact(staging, repo)

    print(f"FULL_RELEASE_SYNC_READY version={version} archive_sha256={archive_sha}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
