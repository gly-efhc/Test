<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / SUPERSEDED EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **HISTORICAL / SUPERSEDED.** Этот план или аудит сохранён для истории.
> Действующий закон: `global_id` — главный персональный идентификатор и owner;
> `tg_id` — только Telegram provider subject. Старые стадии `user_id` не являются
> текущим контрактом.

# Аудит global_id и tg_id — v171.99

Цикл: `1602`.
Baseline: `EFHC_Bot_v171_98.zip`.
Target: `EFHC_Bot_v171_99.zip`.

## Актуальный пересчёт

- строк матрицы: `5570`;
- файлов с упоминаниями: `700`;
- ORM-полей семейства `tg_id`: `33`;
- сервисных сигнатур: `336`;
- FastAPI routes: `143`;
- routes с `tg_id`: `65`;
- доменных owner/actor зависимостей: `2056`.

Увеличение ORM-полей с 32 до 33 вызвано только утверждённым
`User.telegram_id = synonym("tg_id")`; физическая колонка не добавлена.
Рост строк и файлов относится к SSOT/NORM, guards и причинным тестам.

## Каноническое решение

- `MIGRATE_TO_GLOBAL_ID`: `2056`;
- `ADD_RESOLVED_GLOBAL_ID`: `741`;
- `KEEP_TG_ID`: `106`;
- `DUAL_WRITE_TEMPORARILY`: `76`.

`global_id` — единственный целевой owner. Физическое переходное поле —
`users.user_id`. Provider ID не может формировать `global_id`.

## Runtime

Historical backfill, read switch и financial ownership switch не
выполнялись. Alembic head остаётся `0002`.
