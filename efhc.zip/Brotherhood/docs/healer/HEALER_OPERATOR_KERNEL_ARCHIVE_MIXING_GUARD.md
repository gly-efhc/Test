# HEALER OPERATOR KERNEL ARCHIVE MIXING GUARD

Do not mix historical/reference/source/canonical artifacts; packaging must use one selected HEAD and deterministic rules.
