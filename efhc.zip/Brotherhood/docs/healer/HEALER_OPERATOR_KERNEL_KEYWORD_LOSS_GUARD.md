# HEALER OPERATOR KERNEL KEYWORD LOSS GUARD

Major Brotherhood domains and project-specific terms must remain mapped to a route and anchor.
