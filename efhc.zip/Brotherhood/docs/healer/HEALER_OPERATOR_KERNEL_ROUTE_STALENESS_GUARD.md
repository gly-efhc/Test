# HEALER OPERATOR KERNEL ROUTE STALENESS GUARD

Every active route required_read path must exist; stale routes fail architecture tests.
