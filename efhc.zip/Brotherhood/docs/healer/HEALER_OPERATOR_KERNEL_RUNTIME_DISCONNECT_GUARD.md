# HEALER OPERATOR KERNEL RUNTIME DISCONNECT GUARD

Resolver must load routes from config at runtime; hardcoded route tables are forbidden as primary truth.
