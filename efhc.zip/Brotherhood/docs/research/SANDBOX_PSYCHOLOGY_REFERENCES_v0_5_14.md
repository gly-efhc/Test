# Sandbox psychology/reference provenance — v0.5.14

Purpose: record what was learned from user-supplied reference archives without mechanically importing their source/assets.

## Big-Five-Personality-Test-master.zip

Observed README: Android implementation of a 50-item IPIP Big Five Markers test. The README explicitly notes that translations can alter results if they are not independently validated. Brotherhood uses this as a methodological reminder about construct coverage, scoring discipline and language validation. The direct questionnaire UX is NOT copied because Brotherhood's canon requires indirect visual/associative tasks.

Underlying IPIP materials are public domain according to the official IPIP site. Brotherhood currently uses construct families/research anchors, not copied questionnaire items.

## Personality-Test-master.zip

Observed README: category-separated question/answer MVP with Firebase storage and MVP architecture. Used only as a historical UX/data-flow reference. Direct question content is incompatible with Brotherhood's current assessment canon and is not imported.

## mentalys-app-android-master.zip

Observed README: MIT-licensed Android mental-health project with multiple assessment modalities. Used only as architecture/UX reference for multi-modal flows and clear separation of assessment stages. Brotherhood does not import its diagnostic claims, proprietary services, credentials, assets or mental-health classification logic.

## Boundary

User-supplied archives are reference material. Brotherhood's current visual-latent model, Quality Fit ontology and positive/contextual interpretation are Brotherhood-specific implementation and remain subject to Brotherhood-specific empirical validation.
