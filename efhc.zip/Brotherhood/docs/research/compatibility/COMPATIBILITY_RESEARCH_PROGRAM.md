# Brotherhood Compatibility Research Program

Status: **ACTIVE RESEARCH PROGRAM — Cycle 0008 FOUNDATION COMPLETE / CYCLE 0009 NEXT**

## Objective
Создать evidence-governed семейство независимых metric engines для pairwise Compatibility, сохраняя отдельными Quality Fit, Trust и Data Coverage.

## Research layers
1. Source registry and claim ledger.
2. Construct definitions and reference measures.
3. Measurement quality and indirect/visual hypothesis testing.
4. Role-specific dyadic models.
5. Score normalization/interpretation.
6. Privacy-safe explanation.
7. Longitudinal outcome validation.
8. Fairness, exact 13-locale (`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`) equivalence/invariance/DIF and replication.
9. Versioned release governance.

## Metrics
PC Psychology; IC Interests; VC Values; CC Communication; LC Lifestyle; PT Brotherhood Personality Type; EN Enneagram; NU Numerology; AS Astrology.

## Common methodology contract
Для каждой метрики документируются purpose, scope, role contexts, inputs, constructs, candidate scoring, normalization, minimum data, coverage/confidence, evidence class, source→claim map, limitations, privacy, explanation, validation, versioning and outcome calibration.

## Scientific boundary
Ни один external source не определяет Brotherhood production coefficient напрямую. Literature establishes constructs/methodological expectations/candidate relations. Brotherhood-specific pair functions remain `HYPOTHESIS` until internally validated for intended use.

## Outcome boundary
Outcome labels (30/90/180-day continuation, reciprocal messages, voluntary meetings/activities, project completion, self-reported success etc.) enter research datasets only under consent/privacy policy. They feed analysis, not auto-learning in production.

## Exit criteria for research-to-production candidate
- intended use defined;
- measurement validity/reliability evidence sufficient for the input constructs;
- dyadic/criterion validation on holdout;
- subgroup and 13-locale measurement-invariance/DIF checks appropriate to the intended comparison;
- model card/version manifest;
- explanation/privacy review;
- owner/release approval.

Until then status stays `HYPOTHESIS`, `PILOT_CALIBRATED` or another evidence-qualified non-production state.
