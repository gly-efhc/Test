# Brotherhood Compatibility — Scientific Research Master Plan

Status: **ACTIVE RESEARCH PROGRAM**  
Scope: research/documentation only until an owner-authorized implementation cycle.

## 1. Scientific objective
Transform Brotherhood from a set of plausible matching hypotheses into a versioned measurement-and-prediction program where every metric has:

`construct definition -> measurement evidence -> pair model -> role context -> outcome criterion -> validation -> release status`.

The goal is **not** to prove one universal theory of human compatibility. The product intentionally supports several independent metrics and lets the user choose which matter to him.

## 2. Metric families
### Empirical / scientific-development family
- PC Psychology;
- IC Interests;
- VC Values;
- CC Communication;
- LC Lifestyle.

### Brotherhood typology family
- PT Brotherhood Personality Type;
- EN Enneagram (external typology, mixed evidence).

### Alternative/traditional family
- NU Numerology;
- AS Astrology/Zodiac.

### Separate signals
- QF Quality Fit;
- TR Trust;
- DC Data Coverage.

## 3. Evidence states
Every metric/model/stimulus has one explicit state:
1. `IDEA` — product concept only;
2. `HYPOTHESIS` — formalized scientific hypothesis;
3. `TECHNICAL_PILOT` — instrumentation works, no validity claim;
4. `PILOT_CALIBRATED` — preliminary calibration on development cohort;
5. `INTERNALLY_VALIDATED` — locked holdout evidence;
6. `EXTERNALLY_REPLICATED` — independent/external cohort support;
7. `PRODUCTION_QUALIFIED` — intended-use, fairness, privacy and operational gates pass;
8. `TRADITIONAL_ALTERNATIVE` — deterministic alternative method, no psychometric claim.

A model cannot jump stages because its UI looks convincing.

## 4. Scientific workstreams
### WS-A Construct architecture
Define what is being measured; remove duplicate/moralized constructs; map each construct to external theory/evidence and Brotherhood use.

### WS-B Measurement development
Design indirect visual/behavioral stimuli; calibrate response model; test reliability, invariance and validity.

### WS-C Dyadic compatibility
Learn which pair relations matter: similarity, complementarity, asymmetry, conditional interactions.

### WS-D Role context
Separate friend, business partner, worker/team, mentor, project collaboration. One pair can receive different score in different contexts.

### WS-E Outcomes
Define prospective real-world criteria rather than training against retrospective self-approval alone.

### WS-F Fairness/privacy
Language equivalence, subgroup stability, consent, sensitive-data minimization, explanation boundaries.

### WS-G Alternative methods
Numerology/astrology remain deterministic, separately labeled and user-selected; research can study user utility but not mislabel them as psychometrics.

## 5. Required scientific comparisons
Every learned empirical engine must beat or justify itself against transparent baselines:
- random ranking;
- demographics/location-only where legally/ethically appropriate;
- simple interest overlap;
- simple trait similarity;
- role requirement distance;
- popularity/activity baseline.

If complex model does not add out-of-sample value, keep the simpler model.

## 6. Calibration hierarchy
1. Technical data-quality pilot.
2. Measurement pilot.
3. Locked calibration cohort.
4. Locked internal validation holdout.
5. Cross-language replication.
6. Prospective dyadic outcomes.
7. External/independent replication where possible.

Sample sizes are not hard-coded in canon. Each study must have a precision/power/simulation justification based on the model and desired uncertainty.

## 7. Research artifacts
- source registry;
- construct map;
- stimulus manifest;
- calibration dataset schema;
- statistical analysis plan;
- model manifest;
- validation report;
- fairness report;
- release decision;
- rollback plan.

## 8. Non-negotiable scientific prohibitions
- no arbitrary visual cue -> trait truth;
- no production coefficient justified by intuition only;
- no reuse of validation holdout for iterative tuning;
- no “confidence” label when it only means completion count;
- no probability wording for a normalized compatibility index without probability calibration;
- no combining scientific and alternative methods before explicit user selection;
- no hidden global weights across selected metrics;
- no automatic production model mutation from live data.

## 9. Source anchors
See `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.md/json`. Methodological high-priority anchors include APA/AERA/NCME testing standards, IPIP, HEXACO reference literature/licensing constraints, forced-choice psychometrics, friendship systematic reviews, interpersonal circumplex, values, vocational interests/person-environment fit and team trust.
