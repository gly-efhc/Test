# Astrology / Zodiac Compatibility — METHOD

Status: **RESEARCH METHOD / TRADITIONAL_ALTERNATIVE / NEGATIVE_SCIENTIFIC_BOUNDARY**
Metric ID: `AS`

## Purpose
Compute one independent Compatibility result for a specific pair and role context. This method is not Quality Fit, Trust or Overall.

## Constructs
basic Zodiac layer; future natal/synastry only after separate exact methodology/provenance.

## Inputs
method-required birth data with data minimization; advanced natal methods may require time/place and therefore heightened privacy controls.

## Candidate scoring model
Independent versioned traditional method, 0..100. Zodiac and synastry must not be silently conflated.

## Normalization
Final public service result is constrained to `0..100` and must preserve a versioned interpretation. Normalization parameters are learned/fixed only under the validation/versioning plan; score is not a probability unless explicitly calibrated as one.

## Minimum data / coverage
Required birth inputs for chosen layer.

## Privacy/explanation
Use only permitted inputs. Explanation describes pair interaction at a safe abstraction level and never reveals the other person's raw private latent profile.

## Limitations
No psychometric validity claim. Controlled negative evidence prevents scientific relabeling; user may still voluntarily select the alternative engine.

## Outcome calibration
Outcome data may evaluate predictive/criterion usefulness but cannot automatically mutate production.
