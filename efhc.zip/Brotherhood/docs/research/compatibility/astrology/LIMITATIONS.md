# Astrology / Zodiac Compatibility — LIMITATIONS

Status: **ACTIVE LIMITATION BOUNDARY**

No psychometric validity claim. Controlled negative evidence prevents scientific relabeling; user may still voluntarily select the alternative engine.

This engine remains user-selectable and independent. Its lower/different evidence class is not a reason to delete it, and is not a reason to present it as empirical psychometrics. Overall aggregation never gives it a hidden fixed percentage.
