# Astrology / Zodiac Compatibility — MODEL SPEC

Status: **CANDIDATE MODEL SPEC / REQUIRES_VALIDATION**
Metric ID: `AS`

## Contract
Input: pair A/B + role context + permitted versioned metric inputs. Output: independent `score 0..100`, coverage, freshness, evidence/model/method versions and safe explanation metadata.

## Construct layer
basic Zodiac layer; future natal/synastry only after separate exact methodology/provenance.

## Pair-feature layer
Independent versioned traditional method, 0..100. Zodiac and synastry must not be silently conflated.

## Missingness
Missing/withheld inputs are not zeros. Engine returns reduced coverage or `INSUFFICIENT_DATA` according to a predeclared versioned gate.

## Calibration
Candidate transformations and coefficients are fit only on research data separated from locked validation/holdout. Model selection must compare transparent baselines.

## Role context
Role-specific parameters/models are allowed inside this metric when supported; they do not create cross-metric weights.

## Status
No coefficient in this document is asserted as current validated production truth.
