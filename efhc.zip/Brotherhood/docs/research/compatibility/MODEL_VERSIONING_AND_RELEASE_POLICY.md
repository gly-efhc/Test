# Compatibility Model Versioning & Release Policy

Status: **ACTIVE RESEARCH/PRODUCTION GOVERNANCE**.

## 1. Immutable identity
Every model is identified by:
`metric_id / role_context / measurement_version / compatibility_version / normalization_version`.

## 2. Never overwrite history
A score produced by PC v1.2 stays reproducible after PC v1.3 exists. Historical pair snapshots keep the original version.

## 3. Model manifest
Required fields:
- model id/version/status;
- intended uses and prohibited uses;
- training/calibration cohort ids;
- source-to-claim references;
- input constructs/stimuli versions;
- feature generation code hash;
- parameters/model artifact hash;
- normalization to 0..100;
- coverage rule;
- fairness/validation summary;
- approval record;
- rollback target.

## 4. Promotion gates
`HYPOTHESIS -> TECHNICAL_PILOT -> PILOT_CALIBRATED -> INTERNALLY_VALIDATED -> EXTERNALLY_REPLICATED -> PRODUCTION_QUALIFIED`.

Each promotion needs recorded evidence; code deployment alone does not change evidence status.

## 5. Online learning prohibition
Production observations may be collected for research, but must not automatically modify production weights. New model is trained offline, validated, reviewed and released as a new version.

## 6. Rollback
Any model release needs a previous known model or safe baseline. Rollback must restore both scoring and explanation version.

## 7. Alternative methods
Numerology/astrology versions are deterministic rule manifests and remain `TRADITIONAL_ALTERNATIVE`; they do not pass through psychometric validation labels.
