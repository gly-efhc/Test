# Brotherhood Compatibility — Causal Relationship Model

Status: **ACTIVE RESEARCH CAUSAL MAP**.  
This document separates causal hypotheses from predictive correlations.

## 1. Why a causal map is required
A matching product can produce a high predictive score for the wrong reason. Geography, activity level or profile completeness can correlate with friendship formation while not being the psychological mechanism we claim to model. Therefore every major relation must state whether it is:
- causal hypothesis;
- predictive feature only;
- confounder/control;
- mediator;
- outcome;
- measurement artifact.

## 2. Measurement causal chain
```text
latent construct
  -> affects response tendencies across multiple stimuli
  -> observed choices / latency / consistency
  -> measurement model
  -> estimated latent profile + uncertainty
```

Forbidden shortcut:
```text
one attractive visual feature -> one moral trait -> exact 0..100 truth
```

A visual anchor may contribute to a versioned Brotherhood model only after the applicable research/release process. Q34 still allows the approved model to display its exact algorithmic `0..100%` result; this is not a claim of immutable ground-truth personality.

## 3. Relationship causal chain
```text
Person A profile + Person B profile
          + role context
          + interests / values / lifestyle constraints
          + opportunity to interact
          + communication process
          + external circumstances
                    ↓
          relationship experience
                    ↓
     30 / 90 / 180-day outcomes
```

Compatibility can influence outcomes, but outcomes also depend on opportunity, time, geography, network, life events and mutual choice.

## 4. Main hypothesized paths
### Psychology
Traits/interpersonal motives -> behavior expectations and responses -> interaction quality -> persistence/satisfaction.

### Interests
Shared/complementary interests -> more interaction opportunities/topics -> initiation/joint activity -> relationship persistence.

### Values
Value alignment/conflict -> agreement on goals/norms -> reduced or increased chronic conflict -> relationship quality.

### Communication
Disclosure preference + responsiveness + agency/communion + conflict/repair -> felt understanding and safety -> relationship quality.

### Lifestyle
Schedule/geography/availability -> feasible contact frequency -> opportunity for relationship maintenance.

### Quality Fit
Search requirements -> candidate evidence fit -> perceived relevance -> contact/selection -> role-specific outcomes.

### Trust
Verification + observed reliable commitments + resolved incidents -> perceived/operational trust -> willingness to cooperate. Trust is not psychological compatibility.

## 5. Important confounders
- geographic proximity;
- language;
- age cohort;
- socioeconomic context;
- platform activity frequency;
- profile completeness;
- attractiveness/photo quality;
- existing social network overlap;
- occupation/industry;
- availability/time zone;
- ranking exposure and recommendation position;
- novelty effects;
- self-selection into tests/metrics.

A model that predicts only because high-activity users get more exposure must not be interpreted as personality validity.

## 6. Selection bias
Brotherhood observes outcomes only for pairs who were exposed and chose to interact. This creates selection bias. Research datasets must preserve:
`pre-exposure input/model snapshot -> eligibility -> recommendation policy/rank -> actual exposure -> profile open/explicit feedback -> message -> reply/reciprocal opportunity -> side-specific status -> survey/outcome`.

Without exposure logs, non-contacts are not clean negative examples. `No click` and `no reply` are also not automatically negative Compatibility labels.

## 7. Feedback loops
```text
algorithm score -> user sees candidate -> user contacts candidate -> outcome data -> future model
```
This creates algorithmic feedback. Therefore maintain randomized/exploration cohorts where ethically acceptable, frozen model versions and off-policy evaluation methods where possible.

## 8. Mediation examples
Possible mechanisms to test rather than assume:
- shared interest -> more conversation -> friendship quality;
- communication compatibility -> perceived responsiveness -> persistence;
- value alignment -> fewer recurring conflicts -> business continuity;
- lifestyle fit -> more feasible meetings -> relationship persistence.

## 9. Moderation / context dependence
The same pair feature can have different meaning by role:
- agency complementarity may help leader/subordinate dynamics but not equal partnership;
- risk preference similarity may matter differently for business vs friendship;
- shared interests may strongly help friend formation but add little to specialist hiring.

## 10. Causal claim policy
Brotherhood may say `associated with`, `predicts in our validation sample`, or `used by this model` unless a design supports stronger causal inference. Observational platform data alone does not justify “causes successful friendship”.

## 11. Required causal evidence table
Every future engine report must include:
| Feature | Hypothesized mechanism | Confounders | Outcome | Study design | Status |
|---|---|---|---|---|---|

## 12. Research objective
The purpose of this map is not to force causal modeling everywhere. It prevents a prediction score from being marketed as a psychological mechanism without evidence.

### Q35 governance
Brotherhood is explicitly also a research platform. Canonical data contracts: `../outcomes/`. Any exploration/randomization, propensity method or causal adjustment remains a preregistered study design choice; cycle 0014 sets no production experiment percentage. Relationship statuses are side-specific/multi-label and mutual confirmation requires two explicit compatible reports.
