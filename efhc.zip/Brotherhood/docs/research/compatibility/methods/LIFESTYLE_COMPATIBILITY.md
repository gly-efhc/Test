# Methodology — Lifestyle Compatibility (LC)

Status: **TRANSPARENT PREFERENCE/CONSTRAINT MODEL**.
Evidence family: `EXPLICIT_PREFERENCE`, not a hidden personality test.

## 1. Product question
Насколько реальный режим и ограничения жизни позволяют двум людям поддерживать желаемый формат отношений/сотрудничества?

## 2. Candidate fields
- geography / travel radius;
- online vs offline preference;
- preferred meeting frequency;
- daily schedule/chronotype preference;
- activity level and sport;
- travel frequency;
- availability windows;
- family/time constraints;
- disclosed smoking/alcohol/religious lifestyle only as explicit optional sensitive fields;
- mobility/relocation willingness.

## 3. Scoring principle
Separate:
- `hard_constraints`: conflict can make a pairing operationally impossible;
- `soft_preferences`: graded compatibility;
- `neutral`: not selected by user.

Hard constraints must not be converted into psychiatric/character conclusions.

## 4. Role awareness
Friendship emphasizes feasible contact and shared activities; business emphasizes timezone/availability/travel; team work emphasizes schedule overlap; mentor emphasizes session cadence.

## 5. Validation
Check whether LC predicts actual meeting/project continuation above geography alone. Re-estimate fields that add no incremental value.

## 6. Privacy
Sensitive lifestyle fields are opt-in, purpose-limited and must be removable. Do not infer health status.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
