# Methodology — Trust (TR) and Data Coverage (DC)

Status: **SEPARATE SUPPORTING SIGNALS**. Neither is Compatibility.

## Trust (TR)
Trust answers: насколько подтвержден и надежен **операционный профиль/история** пользователя по правилам Brotherhood. Candidate ingredients may include identity verification, verified work/skills, completed commitments, moderation incidents with appeal status, account age and anti-abuse signals.

### Trust prohibitions
- no psych diagnosis;
- no secret morality score from personality tests;
- no guilt by association;
- incidents need provenance, status and appeal;
- protected/sensitive traits must not reduce Trust.

`TRUST-001` supports importance of trust in team performance but does not validate Brotherhood Trust formula.

## Data Coverage (DC)
Coverage answers: насколько достаточно и актуально данных **для конкретной метрики**.

Recommended components:
- completion ratio;
- measurement reliability;
- recency;
- language/model validity status;
- minimum required constructs available.

Coverage is shown as a separate indicator and does not silently multiply cross-metric overall. Low coverage can block metric score or label it preliminary.

## Pair display
Example:
- Psychology 84% · coverage 91%;
- Interests 93% · coverage 70%;
- Trust 88/100 (separate);
- QF 94% (separate).

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
