# Methodology — Numerology Compatibility (NU)

Status: **TRADITIONAL_ALTERNATIVE**.
Evidence family: `TRADITIONAL_RULE_SYSTEM`; no psychometric validity claim.

## 1. Product purpose
Дать пользователю независимый, прозрачный нумерологический индекс совместимости, если он сам считает эту систему значимой.

## 2. Mandatory separation
NU не является психологией и никогда не изменяет latent traits, PC, Trust, QF или научный evidence status других metrics.

## 3. Tradition/version
Каждая реализация обязана назвать традицию и версию. Текущий проект содержит Vedic/date-based elements; перед production pair score требуется отдельный audit: какие числа используются, как вычисляются, какие правила pair interpretation.

Potential versions:
- `NU_VEDIC_DATE_V1`;
- future name-derived contour only as another explicit version.

Смешивать несколько традиций в один скрытый score запрещено.

## 4. Deterministic contract
`date/profile inputs -> canonical number derivation -> documented pair table/formula -> 0..100`.
Одинаковые inputs + version обязаны давать одинаковый result.

## 5. Score semantics
`NU=73` означает только: согласно указанной нумерологической традиции и правилам Brotherhood эта пара получила индекс 73/100. Нельзя называть это вероятностью дружбы/успеха.

## 6. UX
Badge: `Альтернативная методика`. Detail page показывает традицию и принцип вычисления. Пользователь может полностью отключить NU.

## 7. Research option
Можно отдельно изучать, имеет ли NU user-perceived usefulness/engagement value. Даже если такая связь появится, она не превращает традицию автоматически в psychometric construct.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
