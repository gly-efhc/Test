# Methodology — Interests Compatibility (IC)

Status: **RESEARCH DESIGN / TRANSPARENT BASELINE AVAILABLE**.
Evidence family: `EMPIRICAL_BEHAVIORAL + VOCATIONAL_INTEREST`.

## 1. Product question
Насколько интересы двух пользователей создают реальную основу для общения, совместных занятий или совместной профессиональной деятельности?

## 2. Two contours
### Social/hobby interests
Темы общения, спорт, путешествия, игры, технологии, искусство, локальные активности, волонтерство и т.д.

### Vocational/domain interests
Профессиональные интересы и domain preferences для business/work contexts. RIASEC-подобная структура может быть reference-кандидатом, но production taxonomy Brotherhood должна иметь собственный versioned словарь.

## 3. Inputs
Для каждого `interest_id`:
- intensity `0..1`;
- activity frequency;
- importance;
- `want_company` / `solo_ok`;
- proficiency/experience (если применимо);
- recency;
- privacy level.

## 4. Baseline score
До learned model допустим прозрачный weighted overlap baseline: пересечение значимых интересов с учетом intensity/importance. Он должен быть опубликован как `BASELINE`, а не как доказанная оптимальная формула.

## 5. Role awareness
- Friend: shared leisure/topic opportunities.
- Business: domain overlap + complementary professional interests.
- Worker/team: interest-environment congruence отдельно от skills.
- Mentor: domain overlap + learning/teaching interest.

## 6. Hard rule
Количество одинаковых тегов не должно автоматически означать качество отношений. Совпадение — возможность взаимодействия, которую затем надо проверять outcome-данными.

## 7. Validation
- prediction of contact initiation;
- conversation survival;
- joint activity;
- 30/90/180-day relationship outcomes;
- work persistence/performance only with ethically collected criterion data;
- compare weighted overlap, cosine/Jaccard baselines and learned models on locked holdout.

## 8. Evidence anchors
`INTEREST-001`, `INTEREST-002`, `FIT-001`, `FIT-002`, `FRIEND-001`.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
