# Methodology — Psychological Compatibility (PC)

Status: **RESEARCH DESIGN**. Existing production hypotheses are not considered scientifically validated merely because code exists.
Evidence family: `EMPIRICAL_PSYCHOMETRIC`.

## 1. Product question
`PC(A,B,role)` отвечает: **насколько приватные психологические профили двух мужчин сочетаются в выбранном контексте отношений?**

Это не вопрос «насколько люди похожи». Для разных constructs возможны сходство, дополнение, асимметрия и отсутствие доказанного эффекта.

## 2. Intended uses
- поиск друга;
- бизнес-/проектного партнера;
- работника/участника команды;
- наставника/ученика;
- общий социальный контакт.

Не предназначено для клинической диагностики, медицинских выводов, найма без человека-решающего, предсказания преступности или моральной оценки.

## 3. Measurement inputs
Целевой production input — versioned latent profile, полученный из валидированного Brotherhood assessment battery. Research cohorts могут дополнительно иметь reference measures.

Reference construct candidates:
- Big Five/IPIP: broad domains и выбранные facets;
- HEXACO: особенно Honesty–Humility как исследовательский candidate при соблюдении лицензии;
- Interpersonal Circumplex: Agency × Communion;
- attachment/relational tendencies — только если конкретная шкала и intended use подтверждены;
- conflict/repair, autonomy/support, disclosure/responsiveness — как отдельные relational constructs, не как моральные ярлыки.

## 4. Relation taxonomy
Каждая pair-feature обязана иметь versioned relation rule:
- `SIMILARITY`: близость значений потенциально полезна;
- `COMPLEMENTARITY`: сочетание разных полюсов потенциально полезно;
- `ASYMMETRIC`: эффект зависит от ролей A/B;
- `CONDITIONAL`: эффект зависит от role_context или третьего construct;
- `NEUTRAL`: не включать в score;
- `UNKNOWN`: недостаточно evidence.

Universal `100 - abs(A-B)` запрещен как общая психологическая методика.

## 5. Pair feature model
Research pipeline:
`private profile A + private profile B + role_context -> pair features -> calibrated model -> PC 0..100`.

Pair features могут включать расстояние по trait, знак/величину complementarity, interaction terms, profile reliability, response recency. До калибровки они не получают произвольные production-веса.

## 6. Role contexts
### Friend
Приоритет исследования: mutual responsiveness, autonomy support, communication comfort, conflict/repair, shared activity tendency, устойчивость контакта.

### Business partner
Приоритет исследования: decision style, risk alignment/complementarity, conscientious execution, agency distribution, conflict handling, integrity-related constructs.

### Worker/team
Отделить person-person compatibility от Quality Fit к роли. PC описывает взаимодействие; QF — соответствие требованиям работы.

### Mentor
Исследовать support style, autonomy, communication expectations, agency asymmetry и learning orientation.

## 7. Score semantics
`PC=87` означает: текущая versioned психологическая модель Brotherhood оценивает пару как высоко совместимую в данном role context при указанном coverage. Это **не** «87% вероятности дружбы».

## 8. Validation program
Необходимы:
1. reliability measurement layer;
2. test-retest;
3. convergent/discriminant validity against reference measures;
4. measurement invariance 13 locales (`sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`);
5. dyadic validity;
6. incremental validity против простых baseline (`random`, demographics-only, interests-only, pure similarity);
7. longitudinal outcome validity 30/90/180 days;
8. calibration/holdout separation;
9. subgroup fairness + uncertainty;
10. external replication before `PRODUCTION_QUALIFIED`.

## 9. Explanations
Разрешено: «Ваши стили принятия решений хорошо сочетаются».
Запрещено: «У кандидата скрытая агрессивность 78» или раскрытие latent coordinates.

## 10. Key evidence anchors
Source registry IDs: `STD-APA-001`, `IPIP-001..004`, `HEXACO-001..003`, `VIS-FC-001..005`, `FRIEND-001..006`, `IPC-001..002`.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
