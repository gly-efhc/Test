# Methodology — Astrology / Zodiac Compatibility (AS)

Status: **TRADITIONAL_ALTERNATIVE**.
Evidence family: `TRADITIONAL_RULE_SYSTEM + NEGATIVE_SCIENTIFIC_EVIDENCE`.

## 1. Product purpose
Опциональная система для пользователей, желающих сравнивать по астрологической традиции. Не является частью PC.

## 2. Evidence disclosure
Registry `ASTRO-001` хранит double-blind negative evidence; поэтому Brotherhood не делает утверждение, что AS измеряет scientifically validated personality compatibility.

## 3. Separate method versions
- `AS_ZODIAC_BASIC_V1`: базовые date/sign rules;
- future `AS_SYNASTRY_V1`: полная натальная/synastry methodology, только после точной specification и source audit.

Нельзя скрыто смешивать basic zodiac и synastry.

## 4. Deterministic scoring
Все astronomical/calendar inputs, ephemeris source, timezone rules и pair rules versioned. Output 0..100 is an index under that tradition.

## 5. UX
Badge `Альтернативная методика`; ссылка «Как рассчитывается»; явное отличие от psychological evidence family.

## 6. Isolation
AS входит в overall только по галочке пользователя; никогда не меняет PC/QF/TR.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
