# Methodology — Quality Fit (QF)

Status: **SEPARATE DIRECTIONAL MATCHING SYSTEM** — not a compatibility metric.
Evidence family: `PERSON_REQUIREMENT_FIT`.

## 1. Product question
`QF(viewer -> candidate, search_request)` отвечает: **насколько этот кандидат соответствует тем качествам и условиям, которые ищет конкретный пользователь для конкретной роли?**

## 2. Directionality
`QF(A->B)` не равно `QF(B->A)`. Это фундаментальное отличие от большинства pair compatibility metrics.

## 3. Search request
User explicitly selects:
- role: friend/business partner/worker/mentor/project member/etc.;
- desired qualities;
- desired range/priority;
- must-have / nice-to-have;
- public constraints: location, language, availability, skills, interests, etc.

## 4. Candidate evidence
QF может использовать только разрешенные versioned signals: private validated traits, explicit profile fields, verified skills/experience, interests/values where relevant. Raw private trait values не раскрываются viewer.

## 5. Scoring
Each requirement gets a fit function (target range, minimum threshold, complementarity or exact requirement). Aggregate **inside QF** may be weighted by the search author's priorities because это часть одного search request, а не cross-metric overall. Weight source must be user selection or validated role model, never hidden arbitrary constants.

## 6. Temporal integrity
QF должен хранить version search_request and candidate profile snapshot/model version; нельзя пересчитать старую историю без trace.

## 7. Evidence
Work/person-environment fit research (`FIT-001`, `FIT-002`, `INTEREST-001/002`) informs structure, but Brotherhood QF requires own criterion validation.

## 8. Output
QF score 0..100 + matched reasons + missing evidence + timestamp. Not included in overall Compatibility average.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
