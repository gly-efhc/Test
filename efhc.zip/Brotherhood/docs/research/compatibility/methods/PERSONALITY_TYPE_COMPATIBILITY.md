# Methodology — Brotherhood Personality Type Compatibility (PT)

Status: **CYCLE0018 RESEARCH ENGINE / NOT PRODUCTION ACTIVE**.

Brotherhood-32 keeps its 32 existing archetypes as an interpretation layer. The scientific/research representation is continuous-first: five existing `0..100` Brotherhood axes → soft membership across all 32 prototypes. Hard threshold code is not treated as a biological/natural essence.

`PTC-R0` is the transparent baseline: five continuous axis affinities → arithmetic mean → exact versioned `0..100`. It uses full-axis coverage and `INSUFFICIENT_DATA`; it is not a probability and does not inherit the legacy runtime `15% bondStyle` term.

Relation modes (`SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC`, `NEUTRAL`, `UNKNOWN_RESEARCH_ONLY`) are versioned hypotheses. Role-specific and directional models remain challengers until dyadic data validate them.

PT stays independent from Psychology and Enneagram; skills/requirements stay Quality Fit; verification/reliability stays Trust. Raw candidate axes/type/membership remain private by default. Own self-analysis may show the Brotherhood interpretation type.

Q35: exposure-time profile/model/membership/score is frozen for longitudinal evaluation; outcomes never auto-train production. Q36: all registered scientific sources are one synthesis corpus; rights provenance is a separate axis.
