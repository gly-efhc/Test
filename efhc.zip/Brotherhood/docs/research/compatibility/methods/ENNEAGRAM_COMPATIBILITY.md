# Methodology — Enneagram Compatibility (EN)

Status: **TYPOLOGICAL / EXPERIMENTAL**.
Evidence family: `MIXED_EVIDENCE_TYPOLOGY`.

## 1. Purpose
Опциональная совместимость по Эннеаграмме для пользователей, которым эта типология имеет личную ценность. Не заменяет PC.

## 2. Evidence status
Систематический обзор (registry `ENNEA-001`) сообщает смешанные данные по reliability/validity, частичное соответствие Big Five и слабую поддержку некоторых вторичных элементов. Поэтому Brotherhood не маркирует EN как validated psychometric science.

## 3. Inputs
Versioned Enneagram profile derived from a clearly documented instrument/model. Wings, arrows/intertype movement and instincts must be отдельными optional features с собственным evidence status.

## 4. Pair calculation
Начальный EN score может использовать theory-derived pair matrix only as `EXPERIMENTAL`. Production refinement — на собственных dyadic outcomes Brotherhood.

## 5. Output
`EN 0..100`, method version, coverage, badge `Типологическая методика`.

## 6. Isolation rule
EN никогда автоматически не меняет PC, Trust или QF. В overall попадает только если пользователь поставил галочку EN.

## 7. Validation target
Retest stability, agreement with established Enneagram instrument where licensable, predictive dyadic outcomes, incremental value vs PC.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
