# Methodology — Overall Compatibility Convenience Aggregate

Status: **ACTIVE PRODUCT RULE / NOT AN INDEPENDENT SCIENTIFIC METRIC**.

## 1. Owner rule
Каждая compatibility metric имеет собственный 0..100 score и сохраняет самостоятельную ценность. Пользователь выбирает галочками, какие metrics хочет учитывать.

## 2. Formula
Для `n` выбранных и доступных metrics:

`Overall = (score_1 + score_2 + ... + score_n) / n`.

Никаких скрытых cross-metric weights.

## 3. Examples
- только PC=87 → Overall=87;
- PC=87, IC=94, NU=71 → Overall=84.0;
- смена checkbox немедленно пересчитывает arithmetic mean.

## 4. Exclusions
Не входят в average:
- Quality Fit;
- Trust;
- Data Coverage;
- metrics, которые пользователь не выбрал;
- metrics без доступного valid score.

Unavailable metric должна быть явно помечена и не может тихо считаться как 0.

## 5. Semantics
Overall — UI convenience feature, а не «главная истинная совместимость». Detail UI всегда показывает individual scores.

## 6. Auditability
Store checkbox selection + individual metric versions/scores + calculation timestamp so overall can be reconstructed exactly.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
