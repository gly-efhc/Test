# Methodology — Values Compatibility (VC)

Status: **ACTIVE RESEARCH DESIGN — CYCLE 0015 v1.1**.  
Evidence family: `EMPIRICAL_VALUES`.  
Canonical expanded spec: `../values/VALUES_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.

Historical `VC-R0` from v0.5.44 remains frozen for reproducibility. Brotherhood VC compares versioned **centered relative motivational priorities** using a distinct independent `0..100` engine. `VC-R0.1` is the current transparent benchmark combining profile-shape similarity, rank agreement and top-priority overlap; it is not a Schwartz compatibility formula and is not production-active. Circular, nonlinear response-surface, directional-role and perceived-similarity models are research challengers requiring their own evidence and validation.

Values are not moral good/bad labels. Actual/perceived similarity are distinct. Team/work evidence is not converted directly into dyadic coefficients. Values can change after relationships form, so historical pre-exposure profiles/scores are frozen before later outcomes are joined.

Q34 applies: an approved version exposes the exact result it computed. Scientific model revision may later produce a different exact score; neither result is automatically a probability of relationship success.
