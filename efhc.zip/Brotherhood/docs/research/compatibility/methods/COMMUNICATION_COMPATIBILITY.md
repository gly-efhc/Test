# Methodology — Communication Compatibility (CC)

Status: **RESEARCH DESIGN; high-priority Brotherhood differentiator**.
Evidence family: `RELATIONAL_BEHAVIOR`.

## 1. Product question
Насколько два пользователя способны поддерживать взаимно комфортный и устойчивый стиль общения?

## 2. Candidate constructs
- desired communication frequency;
- response tempo tolerance;
- directness vs contextual style;
- emotional disclosure preference;
- perceived responsiveness/support need;
- autonomy need;
- problem-solving vs emotional-support orientation;
- conflict directness;
- repair/reconciliation style;
- agency/communion pattern.

## 3. Inputs
Initial profile comes from assessments and explicit preferences. After consented real interaction, outcome layer may use **non-content** interaction metadata and periodic dyadic surveys. Private message text must not silently become psychological training data.

## 4. Pair logic
CC is not pure similarity. Example: two highly dominant communication styles may conflict; moderate agency complementarity can be helpful in some contexts, while communion usually requires mutual responsiveness. These are hypotheses until calibrated.

## 5. Outcomes
- mutual conversation continuation;
- perceived being understood;
- satisfaction with response tempo;
- conflict occurrence and successful repair;
- voluntary continuation at 30/90/180 days.

## 6. Privacy rule
No hidden semantic surveillance of chat content for compatibility scoring without a separate explicit consent model and research protocol. Default engine uses assessment/preferences + aggregate interaction outcomes.

## 7. Validation
Dyadic prospective study; compare predicted CC to both participants' ratings; calibration by role; test incremental value beyond PC/IC.

## 8. Evidence anchors
`FRIEND-001..004`, `IPC-001..002`.

## Общие обязательные правила
- Индекс `0..100` — **индекс методики Brotherhood**, а не вероятность дружбы, успеха бизнеса или клинический диагноз.
- Метрика не получает скрытый вес относительно других метрик.
- Вычисление всегда versioned: `metric_id + metric_version + role_context + inputs_version`.
- Raw latent profile другого пользователя не раскрывается. UI показывает только парный вывод и объяснения безопасного уровня.
- Если данных недостаточно, система показывает `Недостаточно данных`/coverage, а не выдумывает точный score.
- Любая связь, не подтвержденная собственными данными Brotherhood или внешним evidence для intended use, маркируется `HYPOTHESIS`.
