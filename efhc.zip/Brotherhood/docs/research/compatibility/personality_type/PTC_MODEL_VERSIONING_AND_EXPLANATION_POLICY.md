# PTC model versioning and explanation policy

Status: **RESEARCH GOVERNANCE**

Every PTC result must bind: metric/model ID+version, axis model/scoring version, input snapshot IDs, construct/type registry version, membership transform version, pair-feature version, normalization version, role, locale/adaptation version, coverage and calculation timestamp.

Historical `score_at_exposure` is immutable. Recalculation under a new model creates a new result and never impersonates the old score.

Own profile may show a familiar Brotherhood type and soft top memberships. Candidate raw axes/type/membership vector remain private by default. Pair explanations use safe interaction-level abstractions and must not disclose hidden latent data.

No research outcome automatically updates production. Promotion requires offline analysis, locked holdout/temporal validation, fairness/privacy/scientific review and owner/release approval.
