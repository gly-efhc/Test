# Personality-Type continuous membership model

Status: **RESEARCH TRANSFORM / NOT PRODUCTION ACTIVE**
Version: `PTC-MEMBERSHIP-v1.0`

## Goal
Preserve the familiar 32 Brotherhood-32 archetypes while removing hard dichotomy as the only internal representation.

For each existing axis value `x_i ∈ [0,100]`, define normalized high-pole membership `h_i=x_i/100` and low-pole membership `l_i=1-h_i`.

For each existing prototype `t` with one low/high pole on each of the five axes:

`w_t = product_i( h_i if t uses the high pole else l_i )`

For a complete five-axis profile, the 32 non-negative weights sum to exactly `1` (up to numeric rounding). These values are called **soft prototype memberships/interpretation weights**, not probabilities that a person “really is” a categorical type.

## Interpretation layer
- `top_type = argmax_t(w_t)` may be used for the owner-facing Brotherhood type label.
- top-N memberships may explain mixed/borderline profiles.
- membership entropy and top-margin describe classification ambiguity only; they are not Compatibility.
- candidate raw code/axes/membership vector remain private by default.

## Stability rule
An empirical cluster solution discovered later does not automatically replace the 32 owner/product prototypes. Any new typology requires stability, replication, interpretability, cross-locale/fairness review and owner approval.
