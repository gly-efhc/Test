# PTC normalization and coverage policy

Status: **RESEARCH POLICY / NOT PRODUCTION ACTIVE**

- Public metric range after future production approval: exact versioned `0..100%` under Q34.
- `PTC-R0` maps mean five-axis affinity linearly to `0..100` and rounds to two decimals.
- coverage is a separate field and never a multiplier that silently depresses the score.
- `PTC-R0` initial gate requires 5/5 valid axes for both profiles; otherwise `INSUFFICIENT_DATA`.
- missing / withheld / stale / invalid != 0 and does not imply incompatibility.
- model uncertainty does not make the arithmetic output imprecise; model version/provenance remains explicit.
- a compatibility index is not an event probability unless a separate predictive probability model is validated and calibrated.
