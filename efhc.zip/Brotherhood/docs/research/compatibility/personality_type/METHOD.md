# Brotherhood Personality-Type Compatibility — METHOD

Status: **CYCLE0018 RESEARCH METHOD / NOT PRODUCTION ACTIVE**
Metric ID: `PT`

Primary research inputs are the existing five continuous Brotherhood-32 axes. `PTC-MEMBERSHIP-v1.0` maps them to soft memberships across the same 32 product prototypes; the familiar hard code/title remains an interpretation layer.

`PTC-R0` is a transparent five-axis similarity comparator with full-axis coverage gate. It is independent from Psychology, Enneagram, Quality Fit and Trust. Similarity is a baseline, not a universal claim; role-specific complementarity/asymmetry/neutrality remain challengers pending data.

Raw candidate axes/type/memberships stay private by default. Exact `0..100` score semantics follow Q34; score is not an event probability. Outcomes may evaluate future versions but cannot auto-mutate production.
