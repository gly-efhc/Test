# PTC longitudinal outcome validation plan

Status: **REQUIRES DATA / RESEARCH ONLY**

## Predictor
Immutable PTC score/model/five-axis/membership/coverage snapshot captured at actual recommendation exposure.

## Outcomes
Evaluate separately by role and observation window: contact initiation/opportunity, reciprocity, voluntary friendship satisfaction, 30/90/180/365 persistence, shared activity, project/business/team/mentor continuation and role-specific voluntary success ratings. Conflict/repair is process/outcome evidence, not automatically a negative label.

## Confounders
Exposure/rank/policy, prior tie, geography/opportunity, SearchIntent, Quality Fit, Trust, Psychology/Values/Communication/Lifestyle/Interests scores, role, reassessment timing, measurement error and relationship-driven personality/self-perception change.

## Analyses
Compare PTC-R0 with hard-code-only baseline, continuous-axis alternatives, role/directional challengers, soft-prototype models and PTC-R5 incremental models. Use prospective holdout/temporal replication. If PT adds no incremental utility beyond continuous Psychology/other metrics, retain it primarily as a user interpretation/typology layer rather than manufacture an effect.
