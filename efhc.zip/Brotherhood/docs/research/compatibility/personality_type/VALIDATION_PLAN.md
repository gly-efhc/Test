# Brotherhood Personality-Type Compatibility — VALIDATION PLAN

Status: **REQUIRES DATA / NOT PRODUCTION ACTIVE**

1. Validate reliability/meaning of the five proprietary Brotherhood axes; do not relabel them as external constructs without convergent/discriminant evidence.
2. Evaluate continuous-axis test-retest and measurement error.
3. Evaluate soft membership stability and calibration diagnostics.
4. Compare hard-code-only, PTC-R0, soft-prototype and dimensional baselines.
5. Test role-specific dyadic outcomes prospectively with actual exposure provenance.
6. Test similarity/complementarity/asymmetry/neutral alternatives without assuming universal same-type benefit.
7. For empirical profiles, require multi-method clustering/LPA/GMM stability, out-of-sample replication and temporal/cross-sample robustness.
8. Test incremental validity beyond Psychology, Values, Communication, Lifestyle, Interests, Quality Fit and Trust; no double counting.
9. Exact 13-locale adaptation; native QA and, when measurement is language-sensitive, invariance/DIF.
10. Fairness/privacy/subgroup review, locked holdout/temporal validation and owner/release approval.

Failure/ambiguity keeps the model research-only.
