# Personality-Type source → claim synthesis matrix — Cycle 0018

Status: **ACTIVE SCIENTIFIC SYNTHESIS MAP**

The complete Brotherhood Source Registry is one Q36 evidence corpus. The entries below are the most direct new anchors for PTC; they do not form a separate silo.

| Claim family | Direct anchors | Brotherhood synthesis |
|---|---|---|
| Continuous-first; categories are compression | TYPE-001, TYPE-002, TYPE-003 | Keep continuous axes and soft memberships; hard code is interpretation only. |
| Person-centered profiles can add a useful lens | TYPE-003, TYPE-005, TYPE-006, TYPE-011 | Maintain profile challengers, but compare against dimensional baselines. |
| Clustering can be method/sample dependent or spurious | TYPE-002, TYPE-004, TYPE-005, TYPE-006, TYPE-011 | Multi-method stability + replication before any empirical type is promoted. |
| Similarity is not universally beneficial | TYPE-007, TYPE-008, TYPE-009, TYPE-010 | PTC-R0 similarity is a transparent baseline, not universal scientific truth. |
| Perceived vs actual similarity differ | TYPE-008, TYPE-010 | Keep perception/outcome constructs separate from actual pre-exposure profile similarity. |
| Actor/partner/directional effects can matter | TYPE-009, TYPE-010 | Directional challenger for asymmetric roles; no imported coefficients. |
| Cross-population transport requires validation | TYPE-004, TYPE-011, STD-ITC-ADAPT-001 | Exact 13-locale plan, no locale→type inference. |
| Historical prospective validation | RESEARCH-001, RESEARCH-004, RESEARCH-005 | Freeze exposure-time model/input/membership/score; no auto-learning. |
