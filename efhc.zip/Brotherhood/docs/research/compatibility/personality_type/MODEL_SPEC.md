# Brotherhood Personality-Type Compatibility — MODEL SPEC

Status: **CYCLE0018 CANDIDATE MODEL FAMILY / REQUIRES VALIDATION**
Metric ID: `PT`

Canonical research baseline: `PTC-R0`; membership transform: `PTC-MEMBERSHIP-v1.0`; construct/type registry: `PTC-CONSTRUCT-TYPE-v1.0`; pair registry: `PTC-PAIR-v1.0`.

Output contract: independent `score 0..100`, coverage, metric/model/input/axis/prototype/membership/pair/normalization/locale versions and safe explanation metadata. Missing inputs are never zeros.

PTC-R0 uses continuous axes and does not inherit the current runtime hard type matrix or the legacy `15% bondStyle` durability coefficient. Challenger models test role, directional, soft-prototype, empirical-profile and incremental-validity hypotheses.
