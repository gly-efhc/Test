# Cycle 0018 — factual Brotherhood-32 contract audit

Status: **READ-ONLY AUDIT OF INPUT HEAD `Brotherhood_v0_5_47.zip`**

## Confirmed current model surface
- `shared/personality-32/model.json`: model `Brotherhood-32`, version `0.5.7`, five axes (`social_energy`, `perception`, `decision_style`, `life_rhythm`, `bond_style`) and `32` types.
- `shared/personality-32/types.json`: 32 existing type codes with RU/UK/EN titles.
- Android `Personality32Engine.AxisInput`: all five axes are already continuous integers `0..100`.
- Android `classify()`: each axis is thresholded at `50` to form one hard 5-letter code.
- Current runtime compatibility computes average absolute-axis similarity and then applies a separate `15%` `bondStyle` durability term.

## Cycle 0018 decision
This cycle does **not** modify any of those runtime files or protected visual/scoring mechanics. Research PTC uses the existing continuous axes as versioned inputs, keeps the 32 codes as an interpretation layer, and does not promote the legacy hard threshold or `15%` durability coefficient into scientific truth.

## Boundary
The five Brotherhood axes are project-defined dimensions. Cycle 0018 does not claim they are equivalent to Big Five, HEXACO, MBTI or another external instrument. Mapping requires its own convergent/discriminant validation.
