# PTC-R0 baseline algorithm

Status: **TRANSPARENT RESEARCH COMPARATOR / NOT PRODUCTION ACTIVE**

## Inputs
Two immutable pre-exposure Brotherhood-32 five-axis snapshots, each axis in `0..100`.

## Full-axis coverage gate
`PTC-R0` requires all five valid axes for both people. Missing / withheld / stale / invalid != 0. If the complete profile is unavailable: return `INSUFFICIENT_DATA`; coverage is reported separately.

## Per-axis affinity
Normalize one axis as `a,b ∈ [0,1]`. Treat each as a two-pole soft-membership vector `[1-a,a]` and `[1-b,b]`.

`affinity_i = sqrt(a*b) + sqrt((1-a)*(1-b))`

The value is in `[0,1]` and equals `1` when the two continuous pole-membership vectors are identical.

## Score
`PTC_R0 = round(100 * arithmetic_mean(all_5_axis_affinities), 2)`

No ML baseline. No hard type-pair lookup. No hidden role coefficient. No legacy `15% bondStyle durabilityFloor` term is inherited into PTC-R0.

This exact number is the arithmetic result of version `PTC-R0`; it is **not a probability** of friendship, business success, team performance or relationship survival.

## Research limitation
Similarity is only a transparent null/baseline comparator. The scientific program explicitly tests axis-specific complementarity, asymmetry, neutrality and role effects rather than presuming universal similarity benefit.
