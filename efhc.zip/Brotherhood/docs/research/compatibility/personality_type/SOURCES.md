# Brotherhood Personality-Type Compatibility — SOURCES

Status: **ACTIVE Q36 SCIENTIFIC SYNTHESIS MAP**

Direct type-method anchors: `TYPE-001..TYPE-011`, plus the 189 migrated scientific-evidence records now stored inside the single 217-source typed map.

Canonical metadata and rights/provenance live in `../../source_map/BROTHERHOOD_SOURCE_MAP_v004.json`; claim applicability is versioned in `../CLAIM_EVIDENCE_LEDGER.json` and `PERSONALITY_TYPE_SOURCE_TO_CLAIM_MATRIX.md`.

Sources are used to build Brotherhood constructs, model guards, challenger hypotheses and validation plans. The `60` original vs post-Q30 distinction remains rights/provenance metadata and is not a scientific synthesis barrier. No source automatically supplies a production coefficient.
