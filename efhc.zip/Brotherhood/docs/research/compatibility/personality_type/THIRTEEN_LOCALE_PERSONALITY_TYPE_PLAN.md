# Personality-Type — exact 13-locale adaptation plan

Status: **ARCHITECTURE COMPLETE / VALIDATION REQUIRED**

Canonical locales: `sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`.

## Current factual gap
The existing `shared/personality-32/types.json` contains type titles for **RU/UK/EN only**. Cycle 0018 does not alter that protected runtime registry. Therefore the 13-locale research/product contract is defined, but the remaining 10 user-facing title sets are **REQUIRES_NATIVE_LINGUISTIC_QA / NOT ACTIVATED BY THIS DOC CYCLE**.

## Rules
- locale is never a proxy for personality or type membership;
- translate/adapt interpretation wording, not hidden score coefficients;
- native linguistic QA and cultural review are required before activation;
- if language-sensitive measurement is introduced later, measurement invariance/DIF and locale calibration are required;
- type code remains stable across locales; localization cannot silently change the underlying five-axis snapshot or PTC score.
