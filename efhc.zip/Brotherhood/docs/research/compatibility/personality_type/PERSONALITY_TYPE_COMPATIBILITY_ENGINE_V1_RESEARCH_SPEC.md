# Brotherhood Personality-Type Compatibility Engine v1 — Research Architecture

Status: **CYCLE 0018 COMPLETE / RESEARCH ONLY / NOT PRODUCTION ACTIVE**
Metric ID: `PT`
Baseline: `PTC-R0`

## 1. Independent metric boundary
Personality Type is its own optional Compatibility metric. It is not Psychology, Enneagram, Interests, Values, Communication, Lifestyle, Quality Fit or Trust. Overall remains the simple arithmetic mean of user-selected Compatibility metrics; no hidden cross-metric weights are introduced.

## 2. Continuous-first representation
The current Brotherhood-32 runtime already produces five continuous `0..100` axes before reducing them to a hard code. Research PTC keeps these continuous axes and derives soft membership across all 32 existing Brotherhood prototypes. Hard type code/title is an interpretation layer, not the sole internal representation and not a claim that humanity consists of 32 natural classes.

## 3. Protected-mechanics boundary
Cycle 0018 does not edit protected `100×6`, visual stimulus→latent mappings, Android runtime, backend, database, `shared/personality-32` or current production scoring. The current threshold-at-50 classifier and legacy compatibility remain factual runtime history, not automatically validated coefficients for PTC-R0.

## 4. PTC-R0
PTC-R0 is a deterministic equal-axis similarity comparator over continuous two-pole memberships. It uses five per-axis Bhattacharyya affinities and their arithmetic mean, requires complete five-axis coverage, reports coverage separately and returns `INSUFFICIENT_DATA` when the gate fails. It is not a probability.

## 5. Relation modes and roles
Research relation modes: `SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC`, `NEUTRAL`, `UNKNOWN_RESEARCH_ONLY`. PTC-R0 uses similarity only as a transparent baseline. Role-specific hypotheses are tested separately for `friend`, `business_partner`, `worker_team`, `mentor`, `project_partner`, `activity_partner`; no role coefficients are asserted as production truth.

## 6. Challenger program
`PTC-R1-ROLE-RELATION`, `PTC-R2-PROTOTYPE-PAIR`, `PTC-R3-DIRECTIONAL`, `PTC-R4-EMPIRICAL-PROFILES`, `PTC-R5-INCREMENTAL`. Empirical clustering must be multi-method, replicated and stability-tested; it may challenge but cannot silently overwrite product archetypes.

## 7. Scientific synthesis
All registered Brotherhood scientific sources are one synthesis corpus under Q36. Evidence is used to define constructs, methodological guards, challenger designs and validation—not as a mechanism for importing external coefficients. Person-centered literature supports studying profiles while also demonstrating method/sample dependence and the danger of spurious clusters; dyadic literature makes universal same-type/same-trait benefit an invalid default research assumption.

## 8. Research Platform
Freeze PTC model, axis inputs, soft memberships, score, coverage, role, exposure/rank/policy and versions at exposure. Later outcomes at 7/30/90/180/365 are linked without temporal back-fill. No click/reply/relationship ending is an automatic incompatibility label.

## 9. Privacy
Own interpretation may be shown. Candidate raw type, axes and membership vector remain private by default. No private-chat semantics or free-text personality inference is introduced in this cycle.

## 10. Production gate
PTC-R0 and all challengers remain research-only until Brotherhood data establish measurement quality, role-specific dyadic validity, incremental utility, temporal/external validation, fairness/privacy and owner approval.
