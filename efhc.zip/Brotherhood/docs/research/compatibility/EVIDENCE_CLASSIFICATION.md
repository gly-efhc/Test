# Brotherhood Evidence Classification — Active through Cycle 0009

Status: **ACTIVE CANONICAL CROSSWALK**  
Updated: `2026-08-10`

This document reconciles the owner's `A/B/C/D/HYPOTHESIS` shorthand with the detailed source classes already used by Brotherhood. It **does not create a second grading system**. The detailed registry classes in `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json` remain canonical.

## 1. Source evidence class

- **A** — standards, official scientific reference frameworks, meta-analyses, systematic reviews and high-value scholarly reviews: `A_STANDARD`, `A_REFERENCE`, `A_META_ANALYSIS`, `A_SYSTEMATIC_REVIEW`, `A_REVIEW`, plus `A_PRIMARY` where the registry explicitly treats a foundational primary source as such.
- **B** — peer-reviewed empirical/method evidence: `B_PRIMARY`, `B_LONGITUDINAL`, `B_DYADIC`, `B_METHOD`, `B_ECOLOGICAL`, `B_PRIMARY_NEGATIVE`, `B_REFERENCE`.
- **C** — historical/theoretical/supporting material: `C_HISTORICAL_THEORY`. Product/UX reference sources are tracked separately as `A_PRODUCT_REFERENCE` and are **not scientific evidence** merely because their prefix is `A`.
- **D** — traditional/alternative-system provenance: `D_TRADITIONAL`. This can document a tradition or reproducible algorithm while explicitly not establishing psychometric validity.
- **A_POLICY** — official licensing/use policy. This class answers permission/use questions, not scientific validity.

## 2. Brotherhood claim/model status — a different axis

A strong external source can support a construct while a Brotherhood-specific relation remains unvalidated. Allowed statuses:

`HYPOTHESIS -> TECHNICAL_PILOT -> PILOT_CALIBRATED -> INTERNALLY_VALIDATED -> EXTERNALLY_REPLICATED -> PRODUCTION_QUALIFIED`

Alternative and typological systems may also use explicit statuses such as `TRADITIONAL_ALTERNATIVE` or `TYPOLOGICAL_EXPERIMENTAL` without pretending to be psychometric science.

## 3. Review depth — a different axis

Each claim extraction must state one of:

- `FULL_TEXT_REVIEWED` — relevant full text/method/result sections were inspected;
- `ABSTRACT_REVIEWED` — only abstract/structured database record was used for the extracted claim;
- `OFFICIAL_PAGE_VERIFIED` — an official standards/licensing/repository page supports the claim;
- `IDENTITY_ONLY` — source identity/metadata confirmed, but no substantive claim extracted.

No unobserved sample, effect size, coefficient, limitation or license term may be invented.

## 4. Applicability / transportability — a different axis

- `DIRECT_METHOD` — directly informs how Brotherhood should design/validate a measurement method, but not its coefficient.
- `ADJACENT_CONSTRUCT` — supports relevance of a construct in a related population/context.
- `OUTCOME_CONTEXT` — supports why an outcome matters but not a pairwise predictor.
- `NEGATIVE_BOUNDARY` — constrains what Brotherhood must not claim.
- `PRODUCT_REFERENCE_ONLY` — UX/software provenance, not scientific evidence.
- `TRADITIONAL_PROVENANCE_ONLY` — documents a traditional system/algorithm source.

Population/context mismatch lowers transportability even when source quality is high.

## 5. Rights / licensing — independent from evidence

Source/public terms and Brotherhood-specific authorization are separate fields. The owner has confirmed official permission for all 60 sources in the active cycle-0005 registry **including commercial release/commercial use**; current product positioning is `SOCIAL_PRODUCT`. This project authorization does not alter evidence class or psychometric validity.

Source/public term labels may use one of:

- `PUBLIC_DOMAIN_VERIFIED`
- `PERMISSIVE_LICENSE_VERIFIED`
- `OPEN_SOURCE_LICENSE_WITH_CONDITIONS_VERIFIED`
- `CONTROLLED_LICENSE_REQUIRES_PERMISSION`
- `REUSE_RESTRICTED_OR_NONCOMMERCIAL`
- `RIGHTS_UNKNOWN_REQUIRES_REVIEW`
- `CITATION_ONLY_NO_EMBEDDING_PLANNED`
- `NOT_APPLICABLE`

Project authorization uses `OWNER_CONFIRMED_COMMERCIAL_RELEASE_PERMISSION` for the existing 60-source pack. Sources added later are not automatically covered.

Scientific relevance **never implies** permission, and permission never implies scientific validity or production-scoring eligibility.

## 6. Production-scoring eligibility

External evidence may:
1. justify measuring a construct;
2. justify a validation method;
3. motivate a candidate relation;
4. falsify or constrain a claim.

External evidence does **not** directly authorize a Brotherhood coefficient. A coefficient may affect production scoring only after Brotherhood intended-use validation, versioned review and owner/release approval. No evidence grade becomes a hidden numeric weight.

## 7. Minimum claim record

Every priority claim stores: `claim_id`, `metric/domain`, `claim`, `source_ids`, `exact_support`, `population`, `method`, `effect_or_metric`, `limitation`, `applicability`, `rights_status`, `review_depth`, `brotherhood_implication`, `brotherhood_status`, `production_scoring_allowed`.
