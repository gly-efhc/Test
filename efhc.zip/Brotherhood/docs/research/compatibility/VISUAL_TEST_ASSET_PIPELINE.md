# Visual Test Asset Pipeline

Status: ACTIVE RESEARCH/PRODUCTION PIPELINE DESIGN

## Stages
1. Construct hypothesis.
2. Paradigm selection.
3. Storyboard/composition specification.
4. Asset creation from approved/licensed source.
5. Visual-confound checklist.
6. Accessibility/culture review.
7. Option identity + position-counterbalance manifest.
8. Technical rendering test 320/360/390/412dp + large font where relevant.
9. Pilot data.
10. Psychometric item analysis.
11. APPROVE / REWORK / RETIRE.
12. Version freeze + provenance hash.

## Required per-asset metadata
`asset_id`, `stimulus_id`, creator/source, license, SHA-256, dimensions, palette/contrast descriptors, object count/visual complexity notes, language dependence, culture risks, version, approval state.

## Visual equivalence
If four answer options differ in irrelevant salience, the model can learn salience rather than personality. Therefore visual complexity and interaction effort are tracked as nuisance variables.

## Production separation
Research assets may exist in a candidate library. Only approved versioned assets enter the release bank. Retired stimuli remain historical for reproducibility but cannot be served to new production users.
