# Source → Claim Matrix

Status: **ACTIVE PROJECTION — CYCLE 0015 v1.1 / 111 claims**

| Claim ID | Metric | Sources | Brotherhood status | Production scoring |
|---|---|---|---|---|
| `CLM-MEAS-001` | `psychology/all_empirical` | `STD-APA-001`, `STD-ITC-TBA-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-DIGITAL-001` | `visual_tests` | `STD-ITC-TBA-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-LOCALE-001` | `all_empirical` | `STD-ITC-ADAPT-001`, `IPIP-004` | `REQUIRES_VALIDATION` | `false` |
| `CLM-IPIP-001` | `psychology` | `IPIP-001`, `IPIP-003` | `REFERENCE_CANDIDATE` | `false` |
| `CLM-HEX-001` | `psychology` | `HEXACO-001`, `HEXACO-002`, `HEXACO-003` | `REFERENCE_CANDIDATE` | `false` |
| `CLM-VIS-001` | `visual_tests` | `VIS-FC-IMG-001`, `VIS-FC-001` | `HYPOTHESIS` | `false` |
| `CLM-VIS-002` | `visual_tests` | `VIS-FC-FAKING-001`, `VIS-FC-006`, `VIS-FC-007`, `VIS-FC-008` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PROJ-001` | `visual_tests` | `PROJECTIVE-001`, `FREUD-001`, `FREUD-002` | `HYPOTHESIS` | `false` |
| `CLM-FRIEND-001` | `friendship` | `FRIEND-001` | `HYPOTHESIS` | `false` |
| `CLM-FRIEND-002` | `communication/friendship` | `FRIEND-002` | `HYPOTHESIS` | `false` |
| `CLM-FRIEND-003` | `psychology/friendship` | `FRIEND-005`, `FRIEND-006`, `FRIEND-007`, `IPC-001`, `IPC-002` | `HYPOTHESIS` | `false` |
| `CLM-FRIEND-004` | `friendship/lifestyle/communication` | `FRIEND-008` | `RESEARCH_OUTCOME_CANDIDATE` | `false` |
| `CLM-COMM-001` | `communication` | `COMM-001` | `HYPOTHESIS` | `false` |
| `CLM-ATTACH-001` | `psychology/communication` | `ATTACH-001` | `HYPOTHESIS` | `false` |
| `CLM-SOCIAL-001` | `longitudinal_outcomes` | `SOCIAL-001` | `BACKGROUND_EVIDENCE` | `false` |
| `CLM-VALUES-001` | `values` | `VALUES-SCHWARTZ-1994`, `VALUES-001`, `VALUES-004`, `VALUES-005` | `HYPOTHESIS` | `false` |
| `CLM-INTEREST-001` | `interests/work` | `INTEREST-001`, `INTEREST-002`, `INTEREST-004` | `HYPOTHESIS` | `false` |
| `CLM-FIT-001` | `quality_fit` | `FIT-001`, `FIT-002`, `FIT-003` | `HYPOTHESIS` | `false` |
| `CLM-TRUST-001` | `trust` | `TRUST-001`, `TRUST-002` | `SEPARATE_ENGINE_CANON` | `false` |
| `CLM-MENTOR-001` | `mentor` | `MENTOR-001` | `HYPOTHESIS` | `false` |
| `CLM-TYPE-001` | `personality_type` | `TYPE-001` | `HYPOTHESIS` | `false` |
| `CLM-EN-001` | `enneagram` | `ENNEA-001` | `TYPOLOGICAL_EXPERIMENTAL` | `false` |
| `CLM-ASTRO-001` | `astrology` | `ASTRO-001`, `ALT-VEDASTRO-001` | `TRADITIONAL_ALTERNATIVE` | `false` |
| `CLM-DIIA-001` | `product_ia` | `DIIA-UX-001` | `PRODUCT_REFERENCE_ONLY` | `false` |
| `CLM-VALID-002` | `psychology/all_empirical` | `VALID-MESSICK-1995`, `VALID-CRONBACH-MEEHL-1955`, `STD-APA-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-REL-001` | `psychology/all_empirical` | `REL-CRONBACH-1951`, `REL-SHROUT-FLEISS-1979`, `STD-APA-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-MTMM-001` | `psychology/visual_tests` | `VALID-CAMPBELL-FISKE-1959`, `VALID-CRONBACH-MEEHL-1955` | `REQUIRES_VALIDATION` | `false` |
| `CLM-MI-001` | `all_empirical/localization` | `STD-ITC-ADAPT-001`, `STD-ITC-TBA-001`, `MI-PUTNICK-BORNSTEIN-2016`, `MI-CHEUNG-RENSVOLD-2002`, `MI-CHEN-2007` | `REQUIRES_VALIDATION` | `false` |
| `CLM-SAMPLE-001` | `psychology/validation` | `SAMPLE-WOLF-2013` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-DYADIC-001` | `psychology/dyadic_method` | `DYADIC-KENNY-1996`, `DYADIC-KENNY-COOK-1999` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-DYADIC-002` | `psychology/dyadic_method` | `DYADIC-ORTH-2013`, `VALID-CAMPBELL-FISKE-1959` | `REQUIRES_VALIDATION` | `false` |
| `CLM-SIM-001` | `psychology/similarity` | `SIM-MONTOYA-2008` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-FRIEND-005` | `psychology/friendship` | `FRIEND-010`, `FRIEND-011`, `FRIEND-012` | `HYPOTHESIS` | `false` |
| `CLM-IPC-002` | `psychology/interpersonal` | `IPC-001`, `IPC-002`, `IPC-003` | `HYPOTHESIS` | `false` |
| `CLM-TEAM-001` | `psychology/worker_team` | `TEAM-001` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PC-ROLE-001` | `psychology/role_contexts` | `MENTOR-001`, `TEAM-001`, `SIM-MONTOYA-2008`, `DYADIC-KENNY-COOK-1999` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-FRIEND-006` | `friendship/formation` | `FRIEND-013`, `FRIEND-014` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-FRIEND-007` | `friendship/maintenance` | `FRIEND-015`, `FRIEND-016`, `FRIEND-017` | `RESEARCH_OUTCOME_CANDIDATE` | `false` |
| `CLM-FRIEND-008` | `friendship/mattering` | `FRIEND-018` | `HYPOTHESIS` | `false` |
| `CLM-FRIEND-009` | `friendship/digital_maintenance` | `FRIEND-019` | `REQUIRES_VALIDATION` | `false` |
| `CLM-FRIEND-010` | `friendship/conflict_repair` | `FRIEND-020` | `HYPOTHESIS` | `false` |
| `CLM-FRIEND-011` | `friendship/male_context` | `FRIEND-021`, `FRIEND-023` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-FRIEND-012` | `friendship/dissolution` | `FRIEND-022`, `FRIEND-008` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-FRIEND-013` | `friendship/outcomes` | `FRIEND-001`, `FRIEND-013`, `FRIEND-014`, `FRIEND-015`, `FRIEND-022` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-FRIEND-014` | `friendship/localization` | `FRIEND-018`, `FRIEND-020`, `FRIEND-021`, `STD-ITC-ADAPT-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-001` | `business_partner/research_architecture` | `BUS-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-002` | `business_partner/team_composition` | `BUS-002`, `BUS-009` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-003` | `business_partner/conflict_repair` | `BUS-003`, `BUS-004`, `BUS-007`, `BUS-008` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-004` | `business_partner/leadership` | `BUS-005`, `BUS-006`, `BUS-014` | `HYPOTHESIS` | `false` |
| `CLM-BUS-005` | `business_partner/risk` | `BUS-010` | `HYPOTHESIS` | `false` |
| `CLM-BUS-006` | `business_partner/formation_selection` | `BUS-011` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-007` | `business_partner/viability_satisfaction` | `BUS-012`, `BUS-001` | `RESEARCH_OUTCOME_CANDIDATE` | `false` |
| `CLM-BUS-008` | `business_partner/psychological_safety` | `BUS-013` | `HYPOTHESIS` | `false` |
| `CLM-BUS-009` | `business_partner/stability` | `BUS-015` | `RESEARCH_OUTCOME_CANDIDATE` | `false` |
| `CLM-BUS-010` | `business_partner/quality_fit_boundary` | `FIT-001`, `FIT-002`, `BUS-002` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-011` | `business_partner/trust_execution_boundary` | `BUS-012`, `BUS-015`, `TRUST-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-BUS-012` | `business_partner/values_boundary` | `VALUES-SCHWARTZ-1994`, `VALUES-001`, `BUS-009` | `HYPOTHESIS` | `false` |
| `CLM-BUS-013` | `business_partner/localization` | `STD-ITC-ADAPT-001`, `BUS-001`, `BUS-011` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-WORK-001` | `work_fit` | `FIT-001`, `FIT-002` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-002` | `interests/work` | `INTEREST-001`, `INTEREST-002` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-003` | `team_composition` | `TEAM-001`, `BUS-009` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-004` | `teamwork_process` | `WORK-001` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-005` | `team_cognition` | `WORK-002` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-006` | `information_sharing` | `WORK-003` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-007` | `psychological_safety` | `WORK-006`, `BUS-013` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-008` | `diversity` | `WORK-007` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-009` | `team_selection` | `WORK-009` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-010` | `quality_fit` | `WORK-010` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-011` | `team_training` | `WORK-011` | `REQUIRES_VALIDATION` | `false` |
| `CLM-WORK-012` | `team_efficacy` | `WORK-012` | `REQUIRES_VALIDATION` | `false` |
| `CLM-MENTOR-002` | `mentoring/functions` | `MENTOR-001`, `MENTOR-004` | `REQUIRES_VALIDATION` | `false` |
| `CLM-MENTOR-003` | `mentoring/competencies` | `MENTOR-005` | `REQUIRES_VALIDATION` | `false` |
| `CLM-MENTOR-004` | `mentoring/reciprocity` | `MENTOR-006` | `REQUIRES_VALIDATION` | `false` |
| `CLM-MENTOR-005` | `mentoring/negative_experience` | `MENTOR-007` | `REQUIRES_VALIDATION` | `false` |
| `CLM-MENTOR-006` | `mentoring/plasticity` | `MENTOR-008` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PP-001` | `project_partner/teamwork_quality` | `PP-001` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PP-002` | `project_partner/expertise_coordination` | `PP-002` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PP-003` | `project_partner/temporal_process` | `PP-003` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PP-004` | `project_partner/interdependence` | `PP-004` | `REQUIRES_VALIDATION` | `false` |
| `CLM-PP-005` | `project_partner/dynamics` | `PP-005` | `REQUIRES_VALIDATION` | `false` |
| `CLM-Q34-001` | `psychology/score_semantics` | `STD-APA-001`, `VALID-MESSICK-1995` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-IC-001` | `interests/friendship` | `INTEREST-005` | `REQUIRES_VALIDATION` | `false` |
| `CLM-IC-002` | `interests/activity` | `INTEREST-006` | `REQUIRES_VALIDATION` | `false` |
| `CLM-IC-003` | `interests/vocational` | `INTEREST-007` | `REQUIRES_VALIDATION` | `false` |
| `CLM-IC-004` | `interests/freshness` | `INTEREST-008` | `REQUIRES_VALIDATION` | `false` |
| `CLM-IC-005` | `interests/model` | `INTEREST-001`, `INTEREST-002`, `INTEREST-007` | `REQUIRES_VALIDATION` | `false` |
| `CLM-RESEARCH-001` | `research/causality` | `RESEARCH-001` | `REQUIRES_VALIDATION` | `false` |
| `CLM-RESEARCH-002` | `research/feedback_loops` | `RESEARCH-002` | `REQUIRES_VALIDATION` | `false` |
| `CLM-RESEARCH-003` | `research/people_recommenders` | `RESEARCH-003` | `REQUIRES_VALIDATION` | `false` |
| `CLM-RESEARCH-004` | `research/causality` | `RESEARCH-004` | `REQUIRES_VALIDATION` | `false` |
| `CLM-RESEARCH-005` | `research/causality` | `RESEARCH-005` | `REQUIRES_VALIDATION` | `false` |
| `CLM-RESEARCH-006` | `research/governance` | `RESEARCH-001`, `RESEARCH-004`, `RESEARCH-005` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-VC-001` | `values` | `VALUES-006` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-002` | `values` | `VALUES-007`, `VALUES-014` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-003` | `values` | `VALUES-008` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-004` | `values` | `VALUES-009` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-005` | `values` | `VALUES-010`, `VALUES-013` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-006` | `values` | `VALUES-011` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-007` | `values` | `VALUES-012` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-008` | `values` | `VALUES-006`, `VALUES-007` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-009` | `values` | `VALUES-004`, `VALUES-005`, `STD-ITC-ADAPT-001` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-010` | `values` | `RESEARCH-001`, `RESEARCH-004`, `RESEARCH-005` | `CANONICAL_METHOD_RULE` | `false` |


## Cycle 0015 hardening — Values v0.5.45

| Claim | Sources | Status | Production |
|---|---|---|---|
| `CLM-VC-011` | `VALUES-004`, `VALUES-015`, `VALUES-019` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-VC-012` | `VALUES-016`, `VALUES-017` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-013` | `VALUES-018`, `VALUES-012` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-014` | `VALUES-020`, `VALUES-021`, `VALUES-022` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-015` | `SIM-MONTOYA-2008`, `VALUES-008`, `VALUES-023`, `VALUES-025` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-VC-016` | `FIT-001`, `VALUES-018`, `VALUES-010`, `VALUES-013` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-VC-017` | `VALUES-016`, `VALUES-017`, `RESEARCH-001`, `RESEARCH-004`, `RESEARCH-005` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-VC-018` | `VALUES-024` | `REQUIRES_VALIDATION` | `false` |
| `CLM-VC-019` | `VALUES-007`, `VALUES-014`, `VALUES-026` | `CANONICAL_METHOD_RULE` | `false` |


## Cycle 0016 — Communication Compatibility Engine

| Claim | Sources | Status | Production |
|---|---|---|---|
| `CLM-CC-001` | `COMM-002`, `RESEARCH-001`, `RESEARCH-004` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-CC-002` | `COMM-002`, `COMM-003` | `REQUIRES_VALIDATION` | `false` |
| `CLM-CC-003` | `COMM-001`, `COMM-002`, `COMM-006` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-CC-004` | `COMM-008`, `COMM-006` | `REQUIRES_VALIDATION` | `false` |
| `CLM-CC-005` | `COMM-004` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-CC-006` | `COMM-005`, `FRIEND-020` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-CC-007` | `COMM-007` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-CC-008` | `COMM-009`, `COMM-010` | `REQUIRES_VALIDATION` | `false` |
| `CLM-CC-009` | `COMM-011`, `SIM-MONTOYA-2008` | `REQUIRES_VALIDATION` | `false` |
| `CLM-CC-010` | `COMM-009`, `STD-ITC-ADAPT-001` | `CANONICAL_METHOD_RULE` | `false` |
| `CLM-CC-011` | `COMM-008`, `IPC-001`, `IPC-002` | `REQUIRES_VALIDATION` | `false` |
| `CLM-CC-012` | `RESEARCH-001`, `RESEARCH-004`, `RESEARCH-005`, `COMM-009` | `CANONICAL_METHOD_RULE` | `false` |


## Cycle 0017 — Lifestyle Compatibility

- `CLM-LC-001` — lifestyle/independence — sources: `FRIEND-013, FIT-001` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-002` — lifestyle/proximity — sources: `LIFE-001` — `REQUIRES_VALIDATION` — production_scoring_allowed=`false`.
- `CLM-LC-003` — lifestyle/time_together — sources: `FRIEND-013, LIFE-007, FRIEND-008` — `REQUIRES_VALIDATION` — production_scoring_allowed=`false`.
- `CLM-LC-004` — lifestyle/relocation_mode — sources: `LIFE-002, COMM-010` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-005` — lifestyle/schedule_timing — sources: `LIFE-003` — `REQUIRES_VALIDATION` — production_scoring_allowed=`false`.
- `CLM-LC-006` — lifestyle/temporal_socialization — sources: `LIFE-004` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-007` — lifestyle/alcohol_boundary — sources: `LIFE-005` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-008` — lifestyle/smoking_boundary — sources: `LIFE-005, RESEARCH-005` — `HYPOTHESIS_TO_VALIDATE` — production_scoring_allowed=`false`.
- `CLM-LC-009` — lifestyle/life_context — sources: `LIFE-006` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-010` — lifestyle/online_offline — sources: `LIFE-002, COMM-010` — `REQUIRES_VALIDATION` — production_scoring_allowed=`false`.
- `CLM-LC-011` — lifestyle/hard_constraints — sources: `FIT-001, RESEARCH-004` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-012` — lifestyle/worker_team_sensitive_guard — sources: `STD-ITC-ADAPT-001, RESEARCH-005` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-013` — lifestyle/localization — sources: `STD-ITC-ADAPT-001, LIFE-006` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.
- `CLM-LC-014` — lifestyle/model_governance — sources: `RESEARCH-001, RESEARCH-004, RESEARCH-005, LIFE-004` — `CANONICAL_METHOD_RULE` — production_scoring_allowed=`false`.

## Cycle 0018 — Personality-Type Compatibility

| Claim | Metric | Sources | Status | Production |
|---|---|---|---|---|
| `CLM-PTC-001` | `personality_type/representation` | `TYPE-001, TYPE-002, TYPE-003, TYPE-005` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-002` | `personality_type/clustering_guard` | `TYPE-002, TYPE-004, TYPE-005, TYPE-006` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-003` | `personality_type/person_centered` | `TYPE-003, TYPE-005, TYPE-006, TYPE-011` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-004` | `personality_type/cross_population` | `TYPE-004, TYPE-005, TYPE-011` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-005` | `personality_type/similarity` | `TYPE-007, TYPE-008, TYPE-009, TYPE-010` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-006` | `personality_type/perceived_vs_actual` | `TYPE-008, TYPE-010` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-007` | `personality_type/directional` | `TYPE-009, TYPE-010` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-008` | `personality_type/membership_uncertainty` | `TYPE-002, TYPE-011` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-009` | `personality_type/legacy_coefficient_guard` | `TYPE-007, TYPE-009, TYPE-010` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-010` | `personality_type/incremental_validity` | `TYPE-005, TYPE-006, TYPE-011` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-011` | `personality_type/locale_validation` | `STD-ITC-ADAPT-001, TYPE-011` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-012` | `personality_type/historical_provenance` | `RESEARCH-001, RESEARCH-004, RESEARCH-005` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-013` | `personality_type/no_auto_learning` | `RESEARCH-001, RESEARCH-004, RESEARCH-005` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |
| `CLM-PTC-014` | `personality_type/relationship_change` | `TYPE-008, TYPE-010` | `CYCLE0018_RESEARCH_METHOD_RULE` | `false` |

## Cycle 0028 psychological methodology expansion

| Source | Claim(s) | Brotherhood methodology role |
|---|---|---|
| `FREUD-001`, `FREUD-002` | `CLM-METH-001` | Free-association/reflection method lineage |
| `JUNG-WAT-001`, `JUNG-WAT-002` | `CLM-METH-002` | Word-association cue/response + response-process methodology |
| `IAT-GREENWALD-1998` | `CLM-METH-003` | Implicit association reaction-time/error methodology |
| `TRAUMA-VDK-001` | `CLM-METH-004` | Trauma-informed safety/self-regulation/body/relationship context |
| `TRAUMA-MATE-001`, `MATE-CI-001` | `CLM-METH-005` | Trauma/attachment/implicit-memory reflective context |
| `ABA-BAER-1968` | `CLM-METH-006` | Observed behavior/outcome methodology |
