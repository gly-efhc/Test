# Compatibility Page UX Specification — Diia-style service architecture

Status: ACTIVE PRODUCT DESIGN

## UX formula
`VK = person/resume depth` + `Telegram = direct communication` + `Diia = service clarity/modularity` + `Brotherhood = compatibility intelligence`.

Diia is used as an information-architecture reference: clear service modules, few-click access, stable navigation shell. No Diia data or visual assets are copied.

## Main page `/people/{global_id}/compatibility`
1. Back/title `Совместимость`.
2. Compact candidate resume header: photo, name, age, city, public role/context.
3. `Сравниваем как:` role-context selector.
4. Optional overall convenience score: only arithmetic mean of checked metrics; shows `по N выбранным методикам`.
5. Group `Научно-эмпирические`: Psychology, Interests, Values, Communication, Lifestyle.
6. Group `Типологии`: Brotherhood Personality Type, Enneagram.
7. Group `Альтернативные`: Numerology, Astrology/Zodiac.
8. Each row: checkbox, metric name, score 0..100, coverage/research badge where appropriate, chevron to detail.
9. Separate block: `Соответствие вашему запросу / Quality Fit`.
10. Separate block: `Trust`.
11. CTA: `Написать` and optional `Сохранить сравнение`.

## Detail page template
- metric name;
- pair and role_context;
- score 0..100;
- neutral interpretation label;
- 3–6 relationship-level explanations **without exposing candidate latent traits**;
- data coverage/freshness;
- `Как рассчитывается`;
- `Научная база` or `Статус методики`;
- model version/history.

## Navigation
Persistent bottom nav remains present on authenticated routes. Compatibility is a service/detail surface, not a new bottom tab unless owner later changes canon.
