# Lifestyle Compatibility — MODEL SPEC

Status: **CYCLE0017 RESEARCH MODEL FAMILY / NOT PRODUCTION ACTIVE**

Current comparator: `LC-R0` (see `LC_BASELINE_ALGORITHM.md`). Machine-readable contracts: `LIFESTYLE_INPUT_SCHEMA.json`, `LIFESTYLE_CONSTRUCT_REGISTRY.json`, `LIFESTYLE_PAIR_FEATURE_REGISTRY.json`, `LIFESTYLE_MODEL_CHALLENGER_REGISTRY.json`.

Output contract: exact versioned `score 0..100` when evaluable, `soft_coverage`, `constraint_coverage`, `hard_conflict_state`, freshness/provenance and safe explanation metadata. Missing/withheld data never become zero.
