# Lifestyle Compatibility — SOURCES

Status: **ACTIVE SYNTHESIS MAP — CYCLE0017**

Canonical metadata: `../../source_map/BROTHERHOOD_SOURCE_MAP_v004.json`. Canonical claims: `../CLAIM_EVIDENCE_LEDGER.json`. Cycle synthesis: `LIFESTYLE_SOURCE_TO_CLAIM_MATRIX.md` and `WEB_RESEARCH_EVIDENCE_LEDGER_CYCLE0017.md`.

All registered scientific sources are usable as evidence inputs for Brotherhood’s own analytical-system design. The original 60-source owner-confirmed commercial-permission snapshot vs post-Q30 sources remains rights/provenance metadata, not a scientific-synthesis barrier. This does not mean post-Q30 copyrighted text/assets may be copied into the product without separate rights review, and no source directly authorizes a production coefficient.
