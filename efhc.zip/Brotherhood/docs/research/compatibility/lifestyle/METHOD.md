# Lifestyle Compatibility — METHOD

Status: **CYCLE0017 ACTIVE RESEARCH METHOD / NOT PRODUCTION ACTIVE**  
Metric ID: `LC`

Canonical implementation-neutral research specification: `LIFESTYLE_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.

LC is deterministic constraint/preference matching over immutable pre-exposure lifestyle snapshots. It separates hard constraints, soft acceptable ranges, directional feasibility and sensitive controlled constraints. SearchIntent/QF requirements, Interests topics, Communication style, Values, Psychology and Trust remain separate.

Current transparent comparator: `LC-R0`; coverage is separate; `missing != zero`; no ML is used by the baseline.
