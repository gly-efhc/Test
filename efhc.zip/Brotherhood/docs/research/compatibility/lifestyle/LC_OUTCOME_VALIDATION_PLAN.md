# LC outcome validation plan

Status: **REQUIRES DATA / RESEARCH ONLY**

## Predictor
Immutable LC score/model/input/coverage/hard-constraint snapshot captured at recommendation exposure.

## Outcomes
Evaluate separately by role: actual meeting feasibility, scheduling success/friction, repeated shared activity, distance/travel friction, voluntary lifestyle-fit satisfaction, relationship status transitions and persistence at 7/30/90/180/365 days.

## Critical confounders
Exposure/rank/policy, prior tie, actual geographic opportunity, distance measurement, relocation, timezone changes, work/study or life-capacity changes, seasonality/holidays, temporary travel, remote/offline channel availability, accessibility/health changes only when separately consented, role and observation window.

## Temporal leakage guards
- Current distance cannot impersonate distance at exposure.
- Current schedule cannot impersonate schedule at exposure.
- Post-contact habit/sleep/activity convergence cannot be back-filled as pre-contact similarity.
- Not shown / no opportunity / no meeting are not negative compatibility labels.

## Analyses
Compare LC-R0 against: eligibility/distance-only baseline, schedule-only baseline, role challengers, non-compensatory challengers, directional models and temporal models. Use prospective/held-out evaluation and calibration of score utility; do not convert LC into event probability unless a separate calibrated probability model is explicitly validated.
