# LC-R0 — Transparent Lifestyle Compatibility baseline

Status: **CURRENT TRANSPARENT RESEARCH COMPARATOR / NOT PRODUCTION ACTIVE**  
Metric: `LC`  
Version: `LC-R0`

## 1. Intended use
`LC-R0` asks whether two people's **declared current practical lifestyles and boundaries** can support the requested relationship role. It does not ask whether they share the same interests, personality, values, competence or trustworthiness.

## 2. Stage 0 — ownership / eligibility boundary
SearchIntent candidate requirements and discovery radius remain SearchIntent / Quality Fit / eligibility. LC never duplicates a requirement such as “candidate must live in X” or “candidate must not smoke” as a hidden score input. LC compares each person's own pre-exposure practical profile and declared boundaries after candidate eligibility is established.

## 3. Stage 1 — explicit hard-constraint checks
Every field marked `HARD` is evaluated before soft aggregation. Check state is one of:
`PASS | CONFLICT | MISSING_COUNTERPART | NOT_APPLICABLE`.

A verified bilateral/practical `CONFLICT` is non-compensatory in `LC-R0`: `score = 0.00`, `hard_conflict=true`. A missing/withheld counterpart never becomes conflict or zero. If an activated hard constraint cannot be evaluated, return `INSUFFICIENT_DATA` rather than guessing.

Habit and worldview-practice checks are **constraint-only**. Matching smoking/alcohol use or matching identity never earns a positive similarity bonus.

## 4. Stage 2 — soft pair features
Available pair features are deterministically mapped to `[0,1]` using the versioned functions in `LIFESTYLE_PAIR_FEATURE_REGISTRY.json`.

Soft score families:
1. `LOCATION_MODE`
2. `TIME_CONTACT`
3. `ACTIVITY_PACE`
4. `TRAVEL_MOBILITY`
5. `LIFE_CONTEXT`

Within a family, use the arithmetic mean of available soft features. Missing features are excluded; they are not zeros.

## 5. Stage 3 — coverage gate
Current engineering research gate:
- at least `3/5` soft families available;
- at least `0.60` of applicable non-sensitive soft pair features available;
- no unresolved activated hard constraint.

Otherwise result status = `INSUFFICIENT_DATA`.

These thresholds are transparent research defaults, not validated production truths.

## 6. Stage 4 — exact score
If the coverage gate passes and there is no hard conflict:

`LC_R0 = round(100 * arithmetic_mean(available_family_scores), 2)`

The arithmetic mean is **internal to LC-R0 only**. Overall Brotherhood Compatibility remains the unweighted arithmetic mean of user-selected independent metric scores and gets no hidden LC weight.

`LC_R0 = 82.40%` means the current version calculated exactly `82.40%` for that frozen input snapshot. It is **not a probability** that friendship/business/project success will occur.

## 7. Geography is feasibility, not raw-distance punishment
Distance is interpreted together with declared in-person/remote acceptance and travel tolerance. Two geographically distant people who both accept a remote relationship are not automatically penalized as if distance alone were incompatibility.

## 8. Temporal boundary
Current location/schedule/habits cannot replace historical pre-exposure values. Relocation, seasonality, schedule change or socialization after contact belong to later snapshots/outcomes.

## 9. No ML baseline
LC-R0 intentionally uses deterministic functions. A more complex model must demonstrate incremental validity on prospective/held-out outcomes before it can replace the transparent comparator.
