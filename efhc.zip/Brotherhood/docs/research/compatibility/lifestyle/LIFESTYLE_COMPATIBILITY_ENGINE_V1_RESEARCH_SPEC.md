# Brotherhood Lifestyle Compatibility Engine v1 — research architecture

Status: **CYCLE 0017 COMPLETED RESEARCH ARCHITECTURE / NOT PRODUCTION ACTIVE**  
Metric ID: `LC`  
Current comparator: `LC-R0`

## Separation contract
Lifestyle is one independent Compatibility metric. It is not Psychology, Interests, Values, Communication, Quality Fit or Trust.

- Interests: *what* activity/topic a person likes.
- Lifestyle: *when/how often/where/in what practical mode* a relationship or activity can happen.
- Communication: conversational style/cadence/modality preference; LC owns real-world availability and meeting feasibility.
- Values: motivational priorities; LC accepts only voluntary practical practice constraints, never value-profile similarity.
- Psychology: latent traits; LC uses explicit current behavior/preferences/constraints and does not infer personality.
- Quality Fit/SearchIntent: asymmetric candidate requirements/eligibility; LC does not copy them into the score.
- Trust: verified reliability/history; never an LC construct.

## Inputs
Canonical machine contract: `LIFESTYLE_INPUT_SCHEMA.json`. Inputs are versioned immutable **pre-exposure** snapshots. Candidate sources are explicit preference/profile data and only future validated inference that is prospectively frozen before exposure.

## Construct architecture
Canonical registry: `LIFESTYLE_CONSTRUCT_REGISTRY.json` (`15` constructs). It covers location/mode, schedule/contact opportunity, activity rhythm, travel/mobility, practical planning pace, optional habit boundaries, life-capacity constraints and optional controlled worldview-practice constraints.

## Constraint taxonomy
1. `HARD`: explicitly non-negotiable practical boundary; non-compensatory if both sides are known and conflict.
2. `SOFT`: graded acceptable range/preference.
3. `NEUTRAL/NOT_APPLICABLE`: excluded from scoring.
4. `MISSING/WITHHELD`: unknown, never zero.
5. `SENSITIVE_CONTROLLED`: optional, purpose-limited constraint check; no positive same-identity/same-habit bonus.

## Pair architecture
Canonical registry: `LIFESTYLE_PAIR_FEATURE_REGISTRY.json` (`16` features). Relation functions include set intersection, schedule overlap, range overlap, directional feasibility and controlled directional constraint checks.

## LC-R0
`LC_BASELINE_ALGORITHM.md` defines a deterministic constraint-first comparator. No ML is used. After coverage gates and absence of hard conflict, soft family scores are combined by an internal unweighted arithmetic mean and normalized exactly to `0..100`.

Hard conflict and coverage are exposed separately. `0.00` is reserved for an explicitly evaluated hard conflict, not missingness.

## Role contexts
- `friend`: feasibility of voluntary contact/meetings and sustainable activity rhythm.
- `business_partner`: availability/timezone/travel coordination; competence/ownership/role requirements remain QF.
- `worker_team`: schedule/location feasibility only; family/worldview/habit identity matching is disabled by default.
- `mentor`: directional session availability/travel/remote feasibility; expertise remains QF.
- `project_partner`: project contact/travel/time-window feasibility; project skills remain QF.
- `activity_partner`: activity frequency/intensity/meeting feasibility; activity topic remains Interests.

LC-R0 itself is a role-neutral transparent comparator with role applicability gates. `LC-R1-ROLE` and later challengers must earn role-specific parameters empirically.

## Sensitive boundaries
Smoking/alcohol disclosure is optional and is never rewarded as “same habit = compatible.” The only LC-R0 use is directional compatibility between voluntarily disclosed current context and the other person’s explicit exposure/shared-environment boundary.

Family **status** is not scored. Only voluntary time/capacity constraints may be used. Worldview/religion/politics are not inferred; optional worldview-practice constraints use controlled codes and are excluded from worker/team scoring by default.

## Geography and online/offline
Raw distance is not synonymous with incompatibility. Pair feasibility depends on distance-at-exposure, mobility/travel tolerance and whether a remote path is mutually acceptable. Search radius remains discovery eligibility rather than a hidden LC coefficient.

## Research evidence synthesis
The complete Brotherhood Scientific Source Registry is treated as a unified evidence corpus for constructing Brotherhood’s own analytical systems. Source entries support constructs, causal boundaries, challenger hypotheses and validation design. The original 60-source commercial-permission snapshot versus post-Q30 sources remains a rights/provenance axis, **not** a scientific synthesis barrier. No source automatically becomes a Brotherhood coefficient and post-Q30 source content/assets are not copied merely because scientific ideas/methods are synthesized.

## Research Platform
`LC_RESEARCH_PLATFORM_EXTENSION.json` binds historical predictor snapshot → exposure → user decision → actual meeting/shared activity → relationship status → longitudinal outcomes at 7/30/90/180/365 days. Confounders explicitly include geographic opportunity, relocation, schedule changes, seasonality, remote/offline availability and observation window.

## Production learning
Forbidden: `outcome -> automatic active LC weights`.
Allowed: `versioned research dataset -> offline analysis -> challenger -> holdout/temporal validation -> privacy/fairness/scientific review -> owner approval -> new version`.
