# Lifestyle Compatibility — exact 13-locale plan

Canonical locales: `sw, ru, en, uk, de, fr, es, it, tr, pl, da, hi, id`.

All controlled labels, consent text, boundary semantics, measurement prompts and explanations are designed for all 13 locales from the schema level onward.

## Validation layers
1. source-language construct definition;
2. forward translation + native linguistic QA;
3. cognitive review for ranges/terms such as “often”, “routine distance”, “meeting”, “travel”, “smoking exposure”, “alcohol environment”, “family/life capacity” and “hard boundary”;
4. unit/format localization (distance, date/time, week/day conventions) while storing canonical normalized values;
5. cultural review without locale→individual stereotype inference;
6. measurement invariance/DIF only for multi-item language-sensitive assessments;
7. locale-specific calibration only if evidence requires it, with a versioned adapter.

Geography/locale is never used to infer smoking, alcohol, religion/politics, family preferences, activity level or meeting style. Translation completeness is not psychometric equivalence.
