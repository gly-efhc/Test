# LC model versioning and explanation policy

Status: **ACTIVE RESEARCH GOVERNANCE**

Every stored result binds `metric_id=LC + model_id + model_version + input_schema_version + construct_registry_version + pair_feature_registry_version + normalization_version + role_context + locale/adaptation_version + A/B snapshot IDs + derived distance/timezone snapshot + timestamp`.

Historical results are immutable provenance. A future approved model may calculate a different exact `0..100%` value but cannot overwrite the score seen at exposure time.

Safe explanations describe pair interaction: e.g. “your available meeting windows overlap well” or “your preferred in-person frequency conflicts with the currently declared distance/mobility constraints.” They do not expose the other person's precise location, hidden family information, health inference, political/religious identity, raw worldview text, or private messages.

Sensitive constraint explanations should reveal the minimum necessary result (`compatible boundary`, `declared conflict`, `insufficient disclosure`) instead of the counterpart’s raw response.

No challenger becomes production from literature or outcome correlation alone. Promotion requires frozen prospective data, holdout/temporal evaluation, role-specific validity, privacy/fairness review, locale validation where applicable, scientific review and owner/release approval.
