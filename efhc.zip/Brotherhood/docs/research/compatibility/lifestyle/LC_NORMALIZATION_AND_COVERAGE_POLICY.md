# LC normalization, constraints and coverage policy

Status: **RESEARCH POLICY / NOT PRODUCTION ACTIVE**

- `missing / withheld / stale / invalid != 0`.
- Coverage is independent metadata, never hidden inside the public Compatibility score.
- A confirmed hard lifestyle conflict can produce `0.00` only when the relevant pair facts are explicitly known; missing disclosure cannot.
- Activated hard constraints with unknown counterpart state yield `INSUFFICIENT_DATA`, not inferred pass/fail.
- Habit/worldview/family identity matching is not a positive-score mechanism.
- SearchIntent/QF eligibility failures are not silently encoded as LC zeros.

Current LC-R0 soft coverage gate is `>=3/5 families` and `>=0.60 applicable non-sensitive soft features`; this is a transparent engineering baseline to validate, not a scientific coefficient.

Normalization is deterministic to `[0,100]`; an exact output is the exact result of that version, not an outcome probability.
