# Lifestyle source → claim synthesis matrix — cycle 0017

This matrix is **not a bibliography-only layer**. It records how the unified Brotherhood evidence corpus is transformed into constructs, boundaries, challenger hypotheses and validation tests without copying source content or treating a paper as a production coefficient.

| Claim | Evidence synthesis | Brotherhood use |
|---|---|---|
| LC-001 | proximity/opportunity + time-together research | model feasible contact separately from abstract similarity |
| LC-002 | relocation + communication-mode research | freeze distance/mode at exposure; remote path can alter distance effect |
| LC-003 | chronotype/timing and sleep-pattern research | represent schedule overlap; do not create a chronotype compatibility coefficient |
| LC-004 | friendship maintenance/time-allocation research | validate meeting/activity opportunity longitudinally |
| LC-005 | adult alcohol social-network review | treat alcohol as optional boundary/confound; never reward same drinking |
| LC-006 | lifespan contact-frequency evidence | life context/contact opportunity are time-varying confounders, not family-status similarity |
| LC-007 | ITC/adaptation governance | 13-locale language/culture validation without stereotypes |
| LC-008 | Research Platform causal governance | immutable exposure snapshot; no automatic learning |

Canonical claim IDs and source IDs live in `../CLAIM_EVIDENCE_LEDGER.json`.
