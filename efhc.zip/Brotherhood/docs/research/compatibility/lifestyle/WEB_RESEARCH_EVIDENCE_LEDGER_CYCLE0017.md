# Cycle 0017 web research evidence ledger — Lifestyle Compatibility

Status: **VERIFIED SOURCE METADATA / RESEARCH SYNTHESIS / NO PRODUCTION COEFFICIENTS**

The source registry is used as a unified scientific input corpus. This cycle adds focused evidence for opportunity/proximity, relocation/contact mode, temporal schedule patterns, lifestyle convergence, alcohol-network selection/influence and life-course contact. These studies do **not** prescribe LC weights.

## New sources
- `LIFE-001` — Rohrer et al. (2021), randomized classroom proximity experiment. Proximity increased friendship opportunity in a child classroom context; transport to adult Brotherhood is limited.
- `LIFE-002` — Cho & Smith (2023; online 2022), relocation and contact mode among older adults. Distance effects differ by communication mode; population/age limits apply.
- `LIFE-003` — Aledavood et al. (2018), chronotype/social-network patterns in >700 volunteer students. Motivates timing/schedule research, not a chronotype match coefficient.
- `LIFE-004` — Kok et al. (2025), actigraphy-estimated sleep similarity among university friend pairs. Similarity/covariation after friendship requires selection/socialization leakage guards.
- `LIFE-005` — Knox et al. (2019), systematic review of adult alcohol use and social networks. Alcohol/network association does not justify positive same-use scoring.
- `LIFE-006` — Sander et al. (2017), longitudinal social-contact frequency across the adult lifespan. Contact opportunity changes with life course/context.
- `LIFE-007` — Roberts & Dunbar (2011), 18-month relationship-maintenance study. Time/activities support outcome hypotheses, not a fixed pair coefficient.

Existing sources reused include `FRIEND-013`, `FRIEND-008`, `COMM-010`, `STD-ITC-ADAPT-001`, `RESEARCH-001/004/005` and existing fit/interests evidence.

## Synthesis rule
Scientific findings may define what Brotherhood should measure, what it must not infer, which confounders to preserve and which challenger models to test. They do not automatically authorize a production coefficient or probability interpretation.
