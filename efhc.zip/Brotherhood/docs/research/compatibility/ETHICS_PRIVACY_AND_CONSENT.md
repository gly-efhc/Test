# Ethics, Privacy and Consent — Compatibility Research

Status: ACTIVE DESIGN NORM

## Private psychological profile
Raw latent traits, hidden loadings, diagnostic flags and research evidence are not public profile fields.

## Research consent
Calibration cohorts must know that responses are used to develop/validate matching models, what data are collected, retention/withdrawal terms and whether reference questionnaires are included.

## Data minimization
Collect the minimum needed for a claim. Private chat content is not required for normal compatibility/outcome research; prefer metadata and explicit ratings. Sensitive lifestyle/health/religious data are optional and purpose-bound.

## Profiling risks
Prevent public moral ranking, employment exclusion claims without validation, hidden protected-class proxies, and irreversible reputation scores.

## Right to change
Profiles evolve. Retakes update versioned evidence; historic scores remain auditable but do not become permanent labels.

## Alternative methods
Numerology/astrology/Enneagram must be opt-in and evidence-labeled. They must never silently influence scientific psychology, Trust or employment-quality claims.
