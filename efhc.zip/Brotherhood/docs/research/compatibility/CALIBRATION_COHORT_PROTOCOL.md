# Calibration Cohort Protocol

Status: **RESEARCH PROTOCOL TEMPLATE**.

## 1. Objective
Collect data capable of testing visual measurement hypotheses without contaminating production claims.

## 2. Cohort stages
1. technical micro-pilot — rendering/events/data pipeline only;
2. measurement pilot — item behavior and obvious confounds;
3. calibration cohort — fit candidate measurement models;
4. internal holdout — untouched model evaluation;
5. multilingual replication — all 13 owner-approved locales (`sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`);
6. longitudinal dyadic cohort — matching outcomes;
7. external replication — independent population/site where feasible.

## 3. Sample-size rule
No fixed N is canonized without analysis. Before each study, define desired precision/effect detection, model complexity, expected attrition, subgroup/language comparisons and simulate/power the design.

## 4. Recruitment
Document inclusion/exclusion, source, incentives, region/language distribution, device distribution and whether participants know the research purpose. Avoid only recruiting highly engaged Brotherhood power users for initial validation.

## 5. Consent
Separate:
- product use;
- assessment participation;
- research use;
- longitudinal follow-up;
- optional use of interaction metadata;
- optional sensitive fields.

Withdrawal must be operationally possible.

## 6. Session design
Avoid placing reference questionnaire immediately adjacent to visual stimuli if this would reveal constructs and prime choices. Counterbalance order when scientifically necessary.

## 7. Quality controls
Attention/consistency indicators, minimum/maximum latency flags, device/rendering diagnostics, duplicate detection, position balance, missingness reasons.

## 8. Freeze points
Before holdout evaluation freeze:
- stimulus manifest;
- scoring pipeline;
- exclusions;
- statistical plan;
- outcome definitions.

## 9. Deliverables
Cohort manifest, consent version, data dictionary, exclusions log, quality report, reproducible analysis scripts, model manifest, independent verdict.
