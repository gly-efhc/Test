# Brotherhood Compatibility — Causal Model

Status: **ACTIVE CAUSAL RESEARCH MAP**

## Measurement-to-score chain
`Scientific sources → construct definitions → reference measures → visual stimulus hypotheses → calibration responses → validated measurement parameters → private user latent profile → role-specific metric engine → metric score 0..100 → user-selected metric checkboxes → simple mean convenience Overall`.

Every arrow is a separate claim requiring evidence. In particular `visual stimulus → trait` starts as `HYPOTHESIS`.

## SearchIntent chain
`SearchIntent + desired quality vector/constraints + candidate private/public permitted inputs → directional Quality Fit`.

Quality Fit is not a Compatibility engine and is asymmetric.

## Trust chain
`verified identity + auditable reliability evidence + moderation/security evidence + due-process policy → Trust`.

Trust is not a psychological trait or Compatibility input by default.

## Decision/outcome chain
`pre-exposure inputs → exact versioned Compatibility + Quality Fit + Trust snapshot → recommendation policy/rank → actual exposure → user decision/action → interaction opportunity → voluntary status/outcome → consented versioned research dataset → reviewed model revision candidate`.

## Prohibited shortcut
`longitudinal outcome → automatic production model mutation` = **FORBIDDEN**.

Only: `outcomes → research analysis → human/scientific review → versioned candidate model → validation → owner/release approval → production`.

## Confounding controls
Outcome analyses must distinguish eligibility from actual exposure and must preserve recommendation-policy/rank provenance, geography, availability, prior familiarity, communication opportunity, role selection, locale, missingness and self-selection. `Unseen`, `no click`, `no reply` and `ended relationship` are not interchangeable negative labels. A successful relation after high exposure is not automatically evidence for a psychological coefficient.

## Causal status vocabulary
- `OBSERVED_ASSOCIATION`
- `HYPOTHESIS`
- `VALIDATED_MEASUREMENT_RELATION`
- `PREDICTIVE_HOLDOUT_EVIDENCE`
- `CAUSAL_NOT_ESTABLISHED`

Pairwise Compatibility may be useful predictively without claiming causal determinism.

## Q35 research-platform record
Canonical event/status architecture: `../outcomes/INDEX.md`. Historical model/input/policy/exposure snapshots are immutable provenance. Later outcomes may evaluate a historical model or train a separate candidate model, but never rewrite the historical score or mutate production automatically.
