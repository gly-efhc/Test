# Compatibility Metric Evidence Matrix

Status: **ACTIVE RESEARCH SUMMARY**.

| Metric | Family | Current evidence state | Main evidence sources | Biggest scientific gap | Primary validation outcome |
|---|---|---|---|---|---|
| PC Psychology | empirical psychometric | HYPOTHESIS_TO_CALIBRATE | IPIP, HEXACO candidates, forced-choice, IPC, friendship literature | visual→latent mappings and dyadic pair model unvalidated | prospective role-specific relationship outcomes |
| IC Interests | empirical/behavioral | transparent baseline possible | vocational-interest meta-analyses, friendship/shared activity evidence | social-interest weighting and pair model | initiation, joint activity, persistence; work criteria by role |
| VC Values | empirical values | research design | Schwartz/PVQ literature | Brotherhood indirect value measurement + dyadic model | chronic conflict/goal alignment/relationship quality |
| CC Communication | relational | research design | friendship quality, disclosure/responsiveness, IPC | measurement and outcome definitions | mutual satisfaction, persistence, conflict repair |
| LC Lifestyle | explicit preference | transparent constraint model | fit/friendship context | which constraints add incremental value | feasible contact/collaboration persistence |
| PT Brotherhood type | typological experimental | not established | dimensional personality warnings + future Brotherhood data | stable soft type derivation | incremental value beyond continuous PC |
| EN Enneagram | typological mixed evidence | experimental | systematic review | pair compatibility evidence | optional user usefulness + dyadic outcomes |
| NU Numerology | alternative | traditional | tradition documentation, not psychometrics | exact canonical tradition/pair rules | deterministic reproducibility; user utility only |
| AS Astrology | alternative | traditional + negative scientific evidence | Carlson double-blind test + tradition spec | exact versioned zodiac/synastry rules | deterministic reproducibility; user utility only |
| QF Quality Fit | separate directional fit | strong conceptual architecture, Brotherhood formula pending | P-E fit / vocational interests | requirement mapping and criterion validation | role selection/performance/satisfaction as appropriate |
| TR Trust | separate reliability signal | concept only | team trust meta-analysis + product verification evidence | trustworthy operational formula/fairness | cooperation, incidents, commitments, appeals |
| DC Coverage | separate measurement quality | design | measurement standards | per-metric completeness/reliability rule | calibration of uncertainty, not relationship outcome |

## Interpretation rule
Evidence supporting a construct does **not** validate Brotherhood’s current formula. Example: Big Five evidence supports personality constructs; it does not prove that a specific Brotherhood image option measures conscientiousness.
