# License and Use Constraints — Brotherhood Scientific Sources

Status: **ACTIVE RIGHTS/COMPLIANCE REGISTER — Cycle 0007**

## 1. Separate axes
`scientific evidence`, `public/source terms`, `Brotherhood-specific permission`, `attribution/notice`, and `production scoring eligibility` are separate fields.

## 2. Current 60-source pack
Owner instruction Q30 confirms **commercial-release permission for all 60 source IDs** in the active registry. Therefore commercial use itself is not an internal blocker for this snapshot.

Canonical project status:
- permission: `OWNER_CONFIRMED_COMMERCIAL_RELEASE_PERMISSION`;
- commercial release: `AUTHORIZED`;
- product positioning: `SOCIAL_PRODUCT`;
- permission correspondence independently audited in archive: `NO`;
- scientific validity automatically upgraded: `NO`;
- production coefficients automatically authorized: `NO`.

## 3. Source-specific obligations
Public licenses, attribution requirements, notices, citation requests, trademark restrictions, redistribution conditions and instrument-specific administration rules remain metadata to honor where applicable. A project permission does not erase attribution/provenance duties.

## 4. Adaptation
Commercial permission to use a source/instrument does not establish equivalence of 13-locale adaptations. ITC adaptation guidance still requires empirical equivalence/validity evidence for the intended populations.

## 5. New sources
A future source may be cited for research without being embedded as test content, but it is not covered by the current 60-source commercial authorization unless the owner explicitly extends the authorization.


## 6. Q36 scientific synthesis
All registry sources, including post-Q30 additions, may be used as scientific evidence inputs to design Brotherhood's own constructs, algorithms, tests, causal guards, challengers and validation protocols. This project-level research-synthesis directive is distinct from content-copying/embedding rights. Therefore `CITATION_RESEARCH_REFERENCE_ONLY_NO_EMBEDDING_PLANNED` does **not** mean “bibliography only”; it means source content/assets are not assumed embeddable, while scientific findings/methods may be synthesized with provenance.
