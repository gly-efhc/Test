# Longitudinal Outcome Program

Status: ACTIVE RESEARCH DESIGN

## Зачем
Настоящая ценность Brotherhood возникает, когда compatibility engine проверяется не только against questionnaires, но и against real relationships/actions over time.

## Outcome families
### Friend
- message reciprocity;
- continuing contact 30/90/180 days;
- voluntary meetings/shared activities (opt-in self-report);
- mutual relationship-quality rating;
- perceived support/autonomy/mattering;
- conflict and repair;
- would-contact-again / would-recommend.

### Business / project
- collaboration started;
- milestone completion;
- continuation 30/90/180 days;
- role clarity;
- reliability of commitments;
- conflict resolution;
- mutual satisfaction;
- project outcome category.

### Worker/team
- hired/engaged;
- retention;
- task completion quality;
- supervisor/team satisfaction;
- training/performance outcomes where lawful and consented.

### Mentor
- interaction frequency;
- perceived instrumental/psychosocial support;
- relationship quality;
- goal progress.

## Privacy
No private message content is required for outcome validation by default. Prefer event metadata + explicit opt-in ratings. Sensitive inferences require separate consent/data policy.

## Temporal integrity
Only measurements existing **before** candidate selection/match can be used as predictors of that outcome. Later tests cannot explain earlier decisions.

## Model governance
Outcome data generates a `recalibration proposal`; it never silently updates production coefficients.
