# Numerology Compatibility — METHOD

Status: **RESEARCH METHOD / TRADITIONAL_ALTERNATIVE**
Metric ID: `NU`

## Purpose
Compute one independent Compatibility result for a specific pair and role context. This method is not Quality Fit, Trust or Overall.

## Constructs
one explicitly selected numerological tradition and its components; provenance is part of the method.

## Inputs
only method-required inputs, e.g. birth-date-derived numbers, with privacy minimization.

## Candidate scoring model
Deterministic, versioned traditional algorithm; components and normalization 0..100 documented. No hidden 5% in cross-metric Overall.

## Normalization
Final public service result is constrained to `0..100` and must preserve a versioned interpretation. Normalization parameters are learned/fixed only under the validation/versioning plan; score is not a probability unless explicitly calibrated as one.

## Minimum data / coverage
All inputs required by the selected tradition.

## Privacy/explanation
Use only permitted inputs. Explanation describes pair interaction at a safe abstraction level and never reveals the other person's raw private latent profile.

## Limitations
Traditional/cultural system, not psychometric validity. Cycle 0004 does not select new production formulas.

## Outcome calibration
Outcome data may evaluate predictive/criterion usefulness but cannot automatically mutate production.
