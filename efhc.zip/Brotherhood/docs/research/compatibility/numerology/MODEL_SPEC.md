# Numerology Compatibility — MODEL SPEC

Status: **ACTIVE DETERMINISTIC TRADITIONAL MODEL v1 / INDEPENDENT Q28 METRIC**  
Metric ID: `NU`  
Compatibility version: `vedic-numerology-runtime-v1`

## Contract
Input: two users with permitted date-derived numerology inputs. Output: independent `NU score 0..100`, four component scores, model/calculation versions, provenance and disclosure metadata.

Numerology is a traditional/cultural interpretive system. This specification does not claim that NU is a scientific psychological construct or psychometric measure.

## Pair inputs
Active pair compatibility uses date-derived Brotherhood Vedic values only:
- Soul Number A/B;
- Destiny Number A/B.

Name-derived Soul/Expression values are descriptive self-analysis and are excluded from NU compatibility.

## Deterministic component calculation
The four internal components are:
- Soul pair: `40%`;
- Destiny pair: `35%`;
- cross Soul↔Destiny relation: `15%`;
- date composite relation: `10%`.

The component percentages belong only **inside NU**. Under Q28, NU has no hidden fixed percentage in cross-metric Overall Compatibility.

## Missingness
Missing/withheld required inputs are not zeros. The metric returns unavailable/insufficient data according to the current server contract.

## Reproducibility
Fixed birth-date-derived inputs + fixed `vedic-numerology-runtime-v1` produce the same deterministic result. Stored pair comparisons preserve the version and component breakdown so historical output can be reread.

## Product separation
NU remains separate from:
- Psychology / psychological test systems;
- Trust;
- Account Rating;
- Hospitality Reputation;
- Quality Fit;
- Zodiac/AS;
- Enneagram/EN.

When NU is explicitly selected in Q28 Overall, top-level aggregation remains the Q28 unweighted arithmetic mean of selected available metrics.

## Future outcome analysis
Later friendship outcomes may evaluate whether NU or any NU component is observationally associated with real relationships. Such research is challenger/evidence analysis only and does not auto-modify the active formula or any production weight.
