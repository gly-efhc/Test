# Brotherhood Psychometric Validation Protocol

Status: **ACTIVE VALIDATION GATE**.

## 1. Governing principle
Evidence must support the **specific interpretation and intended use** of a score. A reliable response pattern is not automatically a valid personality construct, and a valid personality measure is not automatically a valid friendship/business matching algorithm.

## 2. Validation layers
### Layer 1 — Data integrity
Missingness, duplicate sessions, bots, random responding, response-time anomalies, rendering errors, position imbalance.

### Layer 2 — Item/stimulus functioning
Entropy, item information, discrimination, local dependence, position/device/locale effects, differential item functioning.

### Layer 3 — Measurement reliability
Internal consistency where appropriate, model-based reliability/information, test-retest stability, measurement error.

### Layer 4 — Structural validity
Factor/latent structure, dimensionality, competing models, cross-validation.

### Layer 5 — Convergent/discriminant validity
Association with intended reference constructs and weak association with unrelated constructs. Do not select only correlations that support the hypothesis.

### Layer 6 — Cross-language/cultural validity
13-locale measurement invariance or justified partial invariance; separate calibration if needed.

### Layer 7 — Dyadic compatibility validity
Can pair score predict role-specific outcomes above transparent baselines?

### Layer 8 — Fairness
Subgroup error/calibration, measurement invariance, exposure bias, protected characteristic review, accessibility.

### Layer 9 — External replication
New cohort/site/time period before strongest claims.

## 3. Train/validation/test discipline
- calibration/training cohort;
- model-selection validation set;
- untouched final holdout;
- prospective temporal holdout when possible;
- no tuning on the final outcome report.

## 4. Metrics to report
Depending on model: reliability coefficients, test-retest correlation/ICC, factor fit, item information, convergent/discriminant correlations, calibration curves, ranking metrics, Brier/log-loss if probabilistic, ROC/PR only for properly defined binary outcomes, effect sizes and confidence intervals.

A normalized 0..100 compatibility index requires monotonicity and calibration checks but is not described as probability unless directly calibrated as such.

## 5. Missing data
Do not impute psychologically meaningful answers simply to create a full profile. Distinguish missing-at-random assumptions from user nonparticipation. Coverage must remain visible.

## 6. Retake policy research
Monthly retake is a product rule/candidate. Empirically study practice effects, temporal stability and meaningful change. Keep first/retake histories and versioned models.

## 7. Release verdicts
`FAIL`, `HYPOTHESIS`, `TECHNICAL_PILOT`, `PILOT_CALIBRATED`, `INTERNALLY_VALIDATED`, `EXTERNALLY_REPLICATED`, `PRODUCTION_QUALIFIED`.

## 8. Independent review
Any promotion to `INTERNALLY_VALIDATED+` requires a verifier not responsible for the final model tuning to review leakage, data splits, claims, code/model manifest and reproducibility.

## 9. Standards/reference anchors
`STD-APA-001`, `STD-COSMIN-001/002`, `VIS-FC-001..005`, relevant reference-instrument sources.
