# Brotherhood Compatibility Research Base — INDEX

Status: **ACTIVE MASTER INDEX — source consolidation current through cycle 0024**  
Runtime source milestone remains versioned separately; source governance revision: `v0.5.59-cycle0024-single-source-ssot`.

## 1. Canon/product anchors
- `../../CANON/BROTHERHOOD_COMPATIBILITY_CANON.md`
- `../../CANON/PSYCHOLOGICAL_MATCHING_CANON.md` — protected owner-lock mechanics; unchanged in cycles 0004–0005
- `../../CANON/BROTHERHOOD_SIMULATION_RELEASE_PARITY_CANON.md`
- `../../PRODUCT/BROTHERHOOD_COMPATIBILITY_PRODUCT_SPEC.md`
- `../../PRODUCT/BROTHERHOOD_SEARCH_INTENT_AND_QUALITY_FIT.md`
- `../../PRODUCT/BROTHERHOOD_TRUST_BOUNDARY.md`

## 2. Research governance
- `COMPATIBILITY_RESEARCH_PROGRAM.md`
- `EVIDENCE_AND_CLAIM_POLICY.md`
- `EVIDENCE_CLASSIFICATION.md`
- `../source_map/BROTHERHOOD_SOURCE_MAP_v004.md/.json` — sole active 217-source typed registry; scientific evidence is selected by class/metadata; former 189-source registry is consolidated and removed;
- `CLAIM_EVIDENCE_LEDGER.md/.json` — 151 claim records with population/method/effect/limitations;
- `SOURCE_TO_CLAIM_MATRIX.md` — compact source→claim projection;
- `LICENSE_AND_USE_CONSTRAINTS.md` — rights/use gate separated from scientific evidence;
- `OWNER_SOURCE_USE_AUTHORIZATION.md` — owner-confirmed official permission for all 60 active-registry sources **including commercial release/commercial use**; current product positioning `SOCIAL_PRODUCT`;
- `BIBLIOGRAPHY.md` — registry-backed bibliography;
- `OPEN_RESEARCH_QUESTIONS.md` — unresolved research decisions for later cycles;
- `WEB_RESEARCH_EVIDENCE_LEDGER_2026_08_10.md` — cycle-0005 web verification trace
- `CAUSAL_MODEL.md`
- `METRIC_ENGINE_CONTRACT.md`
- legacy predecessor contract/model docs remain retained for traceability.

## 3. Independent metric methodologies
- `psychology/` — PC; cycle 0006 construct architecture remains 23 constructs; cycle 0009 adds the research-only `PSYCHOLOGICAL_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`, pair-feature registry, role contracts, normalization contract, baseline/challenger ladder, model manifest schema and dyadic validation/privacy gates without production activation;
- `interests/` — IC; cycle 0014 adds IC v1 research spec, canonical interest taxonomy/input schema, transparent IC-R0 baseline, role contracts and longitudinal outcome validation;
- `values/` — VC; cycle 0015 adds the 19-value taxonomy and historical `VC-R0`; v0.5.45 hardening adds explicit scoring/normalization provenance, current transparent `VC-R0.1`, challenger registry (`VC-R1-CIRCLE/VC-R2-RSA/VC-R3-ROLE-DYADIC`), 13-locale comparability ladder and longitudinal outcome interface; production remains inactive;
- `communication/` — CC; cycle 0016 adds `COMMUNICATION_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`, CC-R0 transparent pre-exposure preference baseline, construct/input/pair-feature/challenger registries, 13-locale validation and longitudinal Research Platform extension; production remains inactive;
- `lifestyle/` — LC;
- `personality_type/` — PT;
- `enneagram/` — EN;
- `numerology/` — NU;
- `astrology/` — AS.

`methods/*.md` are retained consolidated predecessor specs; the directories above are the cycle-0004 canonical expanded methodology set.

## 4. Visual/indirect assessment research
Canonical expanded program: `../visual_tests/` — forced-choice foundations, projective caution, stimulus taxonomy/hypothesis registry, item-bank metadata, reference battery, cohort/reliability/retest/randomization/latency/multilingual/fairness/retirement/model-versioning/explanation protocols.

Existing `VISUAL_*`, calibration and statistical files in this directory remain supporting research material. Protected 100×6 production mechanics are not rewritten. Cycle-0008 calibration/validation protocols are in `../validation/` and use the exact 13-locale scope `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`.

## 5. Role research
`../roles/`: friend, business_partner, worker_team, mentor, project_partner.

## 6. Source provenance
- current unified typed map: `../source_map/BROTHERHOOD_SOURCE_MAP_v004.md/.json`;
- scientific evidence: stored in the same unified `../source_map/BROTHERHOOD_SOURCE_MAP_v004.json` via `source_classes` + `scientific_evidence`;
- historical predecessor maps: `../source_map/APK_SOURCE_MAP_v003.*`, `APK_SOURCE_MAP_v002.*`;
- predecessor `APK_SOURCE_MAP_v002` is preserved unchanged as `REFERENCE/STALE_PROJECT_MAPPING` for its old v0.5.19 target map.

## 7. Roadmap
- active: `../../CYCLES/BROTHERHOOD_CYCLES_0024_0073.md` + `../../CYCLES/BROTHERHOOD_ROADMAP_0024_0073.md`;
- predecessor `BROTHERHOOD_ROADMAP_0004_0030.md` is retained as superseded/restructured history.

## 8. Known runtime gap
`android/.../HybridCompatibilityEngine.kt` and some runtime localization text still encode the legacy fixed-weight/15-layer model. This is confirmed current-code evidence and **not modified** by research cycles 0004–0015. Future compatibility-runtime migration requires explicit protected implementation authorization. Cycle 0008 changed localization/calibration infrastructure only; cycles 0009–0016 remain research/documentation only.

## 9. Scientific status
Cycle 0006 fixes the psychological construct architecture but does not retroactively validate current coefficients. Evidence strength, claim applicability, review depth, source terms and owner project authorization are tracked as separate axes. Owner commercial-release authorization covers the existing 60-source pack; it does not upgrade scientific validity. Every Brotherhood-specific stimulus relation or pair coefficient remains evidence-qualified (`HYPOTHESIS / REQUIRES_VALIDATION` etc.) until validation.

## 10. Cycle 0007 — Visual Stimulus Scientific Program
The master expanded visual research layer is `../visual_tests/`. Cycle 0007 adds a read-only runtime snapshot, primitive/composition registries, stimulus hypothesis schema, social-desirability balance, response-quality, holdout/cross-validation and visual source→claim protocols. Current protected `visual-latent-v2 / scene-library-v4` mechanics remain unchanged and scientifically `HYPOTHESIS / REQUIRES_VALIDATION`.



## 11. Cycle 0008 — Calibration & Psychometric Validation Protocol
Canonical validation layer: `../validation/`. It defines intended-use validation, calibration cohorts, reference-battery execution, reliability/test-retest, construct validity and MTMM, 13-locale measurement invariance/DIF, sample-size/power/precision, holdout/external replication, model selection/promotion and versioned validation-run records. The exact locale set is `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`. Structural runtime localization does not imply semantic/native translation completion or psychometric equivalence; those remain separate evidence gates.


## 12. Cycle 0009 — Psychological Compatibility Engine v1 Research Spec
Canonical research spec: `psychology/PSYCHOLOGICAL_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`. PC is a role-specific exact algorithmic `0..100` result under its active model version/input snapshot; it is not automatically a success probability. Pair relation modes remain construct×role hypotheses until validation. Dyadic non-independence, actor/partner structure, shared-method bias, locked holdout, 13-locale comparability, privacy and no-auto-promotion are explicit gates. New cycle-0009 references are citation/research additions and do not inherit the original 60-source commercial-permission snapshot.

## Cycle 0010 — Friendship Compatibility Science
- Master package: `../roles/friendship/INDEX.md`.
- Source registry: 93 sources total = original 60 owner-authorized commercial-release snapshot + 33 post-Q30 citation/research references.
- Claim ledger: 45 claims; 0 production-scoring-authorized.
- New friend evidence IDs: `FRIEND-013..023`.
- Outcome hierarchy, male-context boundary, causal/confound plan, 13-locale adaptation plan and privacy-safe longitudinal data contract are frozen as research interfaces.
- Production Friendship/PC coefficients remain `REQUIRES_DATA / REQUIRES_VALIDATION`.

## Cycle 0011
Business Partner Science package: `../roles/business_partner/INDEX.md`. Scientific registry = 108 sources; claim ledger = 58 claims; all new business-partner relations remain research-only.

## Cycle 0012 Worker / Team Fit Science
- `../roles/worker_team/INDEX.md` — active worker/team role-science package.
- Psychology epistemic anchor: `../../CANON/BROTHERHOOD_PSYCHOLOGY_EPISTEMIC_CANON.md`.


## Cycle 0013 Mentor / Project Partner Compatibility
Canonical role package: `../roles/mentor_project/INDEX.md`. Mentor science is directional; Project Partner is peer/mutual by default with explicit ordered modes when roles differ. PC/QF/Trust/Communication/Values/Interests/Lifestyle remain separate. Q34 semantics apply: active algorithms expose exact versioned `0..100%` results; model improvement can change future versioned scores. Scientific registry: 132; claim ledger: 81.

## Cycle 0014 — Interests Compatibility Engine + Research Platform
- Canonical IC spec: `interests/INTERESTS_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.
- Research feedback/outcome architecture: `../outcomes/INDEX.md`.
- Source registry: 141 total = original 60 owner-authorized commercial-release snapshot + 81 post-Q30 citation/research references.
- Claim ledger: 92 claims; 0 external claims directly authorize production coefficients.
- Q35: Brotherhood is also a research platform; exposure, feedback, relationship status and longitudinal outcomes can evaluate future versioned models, but never auto-mutate production.
- IC-R0 is a transparent research baseline, not a production promotion.


## Cycle 0015 — Values Compatibility Engine
- Canonical spec: `values/VALUES_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.
- Historical transparent benchmark: `VC-R0`; current hardened research comparator: `VC-R0.1`; production inactive.
- Value taxonomy: 19-value refined motivational continuum; equal circular spacing is **not** assumed.
- Source registry: 162 total = original 60 owner-authorized commercial-release snapshot + 102 post-Q30 research/citation references.
- Claim ledger: 111 claims; external evidence directly authorizes 0 production coefficients.
- Research-platform linkage stores decision-time VC/model/input/exposure provenance before joining later outcomes.


### v0.5.45 hardening
- `VC-R0` remains frozen for reproducibility; v0.5.45 does not rewrite historical scores.
- `VC-R0.1` makes centered relative-priority/scoring-adapter provenance explicit and remains a project-designed research index, not an external formula.
- `VC-R2-RSA` adds a difference-score guard and offline response-surface challenger.
- Value-profile freshness, unit-of-analysis/direction and exact 13-locale comparability states are explicit.
- Research platform outcome linkage preserves decision-time model/input/exposure provenance and no-auto-learning.


## Cycle 0016 — Communication Compatibility Engine
- Canonical spec: `communication/COMMUNICATION_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.
- Current research comparator: `CC-R0`; production inactive.
- Source registry: 172 total = 60 original owner-authorized snapshot + 112 post-Q30 references.
- Claim ledger: 123 claims; production-scoring-authorized claims: 0.
- Strict temporal boundary: pre-exposure preferences predict; actual replies/latency/reciprocity/conflict/repair are process/outcome signals unless separately prospectively validated.
- Exact locales: `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`.


## Cycle 0017 — Lifestyle Compatibility Engine
Canonical research package: `lifestyle/`. `LC-R0` is a deterministic constraint-first transparent comparator over immutable pre-exposure lifestyle snapshots. It separates hard constraints, soft ranges, directional feasibility, sensitive constraint-only fields and coverage. SearchIntent/QF requirements, Interests topics, Communication style, Values, Psychology and Trust remain separate. Scientific Source Registry/Claim Ledger are a unified Q36 evidence corpus for Brotherhood model synthesis; rights provenance remains separately tracked. No production/runtime implementation was authorized.

## Cycle 0018 — Brotherhood Personality-Type Compatibility Engine

Canonical package: `personality_type/PERSONALITY_TYPE_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md` plus machine-readable input, construct/type, pair-feature, challenger and Research Platform registries. `PTC-R0` is a research-only continuous-axis similarity comparator; the existing 32 Brotherhood codes remain an interpretation layer. Source Registry: `189`; Claim Ledger: `151`; Q36 unified synthesis and exact 13-locale contract apply. Production/runtime scoring is unchanged.
