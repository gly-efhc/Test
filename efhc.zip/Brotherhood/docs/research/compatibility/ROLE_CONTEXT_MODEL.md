# Role Context Model

Status: ACTIVE PRODUCT/RESEARCH DESIGN

Совместимость зависит не только от двух людей, но и от контекста взаимодействия. Один и тот же профиль может хорошо работать в дружбе и хуже — в совместном бизнесе, или наоборот.

## Канонические role_context
- `FRIEND`
- `CLOSE_FRIEND`
- `BUSINESS_PARTNER`
- `PROJECT_PARTNER`
- `WORKER_SPECIALIST`
- `TEAMMATE`
- `MANAGER_DIRECTOR`
- `MENTOR`
- `ACTIVITY_PARTNER`
- `MUTUAL_AID`
- `CUSTOM`

Role context **не задаёт пользователю желаемые качества**. Для Quality Fit пользователь сам выбирает качества. Role context только выбирает научно/продуктово релевантную интерпретацию pair interaction.

## Как context влияет на метрики
- Psychology: similarity/complementarity/asymmetry rule может отличаться по роли.
- Interests: friend = leisure/social interests; work/business = vocational/domain interests.
- Values: относительная цена конфликта ценностей может отличаться по роли.
- Communication: manager/subordinate и friend require different reciprocity expectations.
- Lifestyle: обычно важнее для дружбы/activity partner, слабее для удалённого business collaboration.
- Alternative metrics: context может менять только выбранную традиционную interpretation, но не превращает её в науку.
