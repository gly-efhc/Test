# Research Questions and Hypotheses Backlog

Status: ACTIVE RESEARCH BACKLOG

## Psychology
- Which visual paradigms predict stable reference traits above chance and beyond simple visual-preference factors?
- Which latent dimensions show test-retest stability?
- Which dimensions contribute to friendship/business/team outcomes incrementally over interests/values?
- For each dimension, is pair fit better described by similarity, complementarity, asymmetry or no effect?

## Friendship
- Which factors predict first contact vs sustained 30/90/180-day interaction?
- Do perceived similarity, communication complementarity, autonomy support and reliable alliance explain different stages?
- Does the best model for friendship formation differ from the best model for friendship quality?

## Business/team
- Which person-job/person-group/value/interest combinations predict collaboration start, retention and milestone completion?
- Does Trust moderate outcomes without belonging inside Compatibility itself?

## Alternative metrics
- Do users who opt into numerology/astrology report greater subjective usefulness? This question concerns UX/meaning, not scientific validity of the tradition.
- Does selecting an alternative metric change behavior even when empirical metrics are held constant?

## Falsification principle
Every hypothesis must specify a result that would cause us to retire or reduce the role of a construct/stimulus. A metric that cannot fail a test is not a scientific metric.
