# Psychology Compatibility — Limitations

Status: **ACTIVE SCIENTIFIC BOUNDARY — CYCLE 0006**

- Existing protected 100×6 mechanics are not proof that their visual stimulus→latent loadings are valid.
- Big Five/IPIP or HEXACO reference validity does not validate Brotherhood indirect measurement.
- Big Five and HEXACO broad domains partly overlap; treating them as independent additive evidence can double-count shared variance.
- IPC agency/communion describe interpersonal space but do not by themselves determine which pair configuration is optimal in a Brotherhood role.
- Adult attachment evidence often comes from romantic/close relationships; transfer to male friendship/business/team/mentorship is not assumed.
- Responsiveness/conflict/repair may be relational processes rather than stable traits; ontology must be empirically tested.
- Psychological trust/cooperation is not platform Trust.
- Risk preference can be domain-specific; one global risk scalar is not assumed.
- Trait measurement validity does not prove pairwise compatibility validity.
- Pair prediction does not establish causation.
- Similarity is not universally optimal; relation type is construct/role dependent.
- Language/culture/selection/age effects require explicit analysis.
- Private latent/construct scores must not be exposed in candidate explanations.
- No clinical diagnosis or moral ranking.
- No automatic production learning from longitudinal outcomes.
