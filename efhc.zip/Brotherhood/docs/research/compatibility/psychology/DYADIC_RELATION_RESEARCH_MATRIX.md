# Psychological Constructs — Dyadic Relation Research Matrix

Status: **HYPOTHESIS MATRIX / CYCLE 0009 DYADIC EVIDENCE EXTENSION / NO PRODUCTION WEIGHTS**

Every cell below is a research candidate. It is not a validated coefficient or final relation mode.

| Construct/family | Friend | Business partner | Worker/team | Mentor | Project partner | Activity partner |
|---|---|---|---|---|---|---|
| Big Five broad traits | similarity may matter selectively | mixed/context-specific | role/task dependent | mostly contextual | mixed/context-specific | activity/context dependent |
| Honesty–Humility | investigate pair/outcome relevance | investigate strongly but without moral labeling | investigate conduct/cooperation boundaries | investigate | investigate | likely secondary |
| IPC Agency | similarity or complementarity candidate | role-allocation complementarity candidate | hierarchy/team-role dependent | inherently asymmetric candidate | role-allocation candidate | contextual |
| IPC Communion | similarity/affiliation candidate | cooperation/conflict context | team climate context | support context | cooperation context | social comfort context |
| Attachment anxiety/avoidance | transfer validity required | transfer validity required | likely secondary unless role evidence | potentially asymmetric support/learning | contextual | likely secondary |
| Responsiveness/support | strong candidate | candidate | candidate | strong asymmetric candidate | candidate | candidate |
| Conflict/repair | strong process candidate | strong process candidate | strong process candidate | repair/feedback candidate | strong process candidate | context dependent |
| Psychological trust/cooperation | candidate | strong candidate but separate from platform Trust | team candidate | candidate | strong candidate | contextual |
| Domain-specific risk | usually secondary | strong role-specific candidate | job/task dependent | secondary | strong project-specific candidate | activity risk dependent |
| Decision tempo | cadence candidate | strong candidate | workflow dependent | feedback/learning tempo | strong candidate | activity dependent |

## Conversion rule
A future model may convert a cell to `SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC` or `NEUTRAL` only after the relation is operationally defined and supported by validation/outcome evidence for that role. Until then it is `HYPOTHESIS`.

## Cycle 0009 evidence constraints
- `SIM-MONTOYA-2008` prevents treating actual similarity as a universal compatibility law.
- `FRIEND-010..012` motivate trait/context-specific friendship-selection hypotheses and a separation of selection from later relationship outcomes.
- `IPC-001..003` support testing agency/communion similarity/complementarity/process effects but do not validate a single complementarity formula.
- `DYADIC-KENNY-1996`, `DYADIC-KENNY-COOK-1999`, `DYADIC-ORTH-2013` require dyadic dependence and method-bias controls.
- `TEAM-001` is team-level evidence and cannot be silently converted into a two-person worker/team PC coefficient.

These anchors constrain hypotheses; they do not promote any matrix cell to validated.
