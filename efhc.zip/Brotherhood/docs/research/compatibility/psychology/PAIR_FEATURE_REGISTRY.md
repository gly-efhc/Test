# Psychology PC v1 — Pair Feature Registry

Status: **RESEARCH CANDIDATES / NO PRODUCTION COEFFICIENTS**

| ID | Constructs | Candidate relation | Roles | Directionality | Status | Sources |
|---|---|---|---|---|---|---|
| PF-B5-SIM | B5-O, B5-C, B5-E, B5-A, B5-N | SIMILARITY | friend, business_partner, worker_team, mentor, project_partner, activity_partner | SYMMETRIC | HYPOTHESIS_TRAIT_SPECIFIC_NOT_UNIVERSAL | SIM-MONTOYA-2008, FRIEND-010, FRIEND-011, FRIEND-012 |
| PF-HH-PAIR | HX-HH | CONTEXT_DEPENDENT | business_partner, worker_team, mentor, project_partner | UNRESOLVED | HYPOTHESIS_REQUIRES_INCREMENTAL_VALIDITY | HEXACO-001, HEXACO-002 |
| PF-IPC-AG-SIM | IPC-AG | SIMILARITY | friend, activity_partner | SYMMETRIC | HYPOTHESIS | IPC-001, IPC-002 |
| PF-IPC-AG-COMP | IPC-AG | COMPLEMENTARITY | business_partner, worker_team, mentor, project_partner | ROLE_DEFINED | HYPOTHESIS_NO_BLANKET_OPPOSITES_RULE | IPC-001, IPC-002, IPC-003 |
| PF-IPC-CO-SIM | IPC-CO | SIMILARITY | friend, business_partner, worker_team, mentor, project_partner, activity_partner | SYMMETRIC | HYPOTHESIS | IPC-001, IPC-002 |
| PF-IPC-DYNAMIC | IPC-AG, IPC-CO | ASYMMETRIC | mentor, worker_team | ORDERED_ACTOR_PARTNER | HYPOTHESIS_PROCESS_SENSITIVE | DYADIC-KENNY-COOK-1999, IPC-003 |
| PF-ATT-ANX | ATT-ANX | CONTEXT_DEPENDENT | friend, mentor | ORDERED_OR_SYMMETRIC_TO_TEST | HYPOTHESIS_TRANSPORT_REQUIRED | ATTACH-001 |
| PF-ATT-AVD | ATT-AVD | CONTEXT_DEPENDENT | friend, mentor | ORDERED_OR_SYMMETRIC_TO_TEST | HYPOTHESIS_TRANSPORT_REQUIRED | ATTACH-001 |
| PF-RESP-ASYM | RESP | ASYMMETRIC | friend, mentor, business_partner, project_partner | ORDERED_ACTOR_PARTNER | HYPOTHESIS_STATE_TRAIT_BOUNDARY_UNRESOLVED | COMM-001, MENTOR-001 |
| PF-REPAIR | BH-LH-03 | CONTEXT_DEPENDENT | friend, business_partner, worker_team, mentor, project_partner | PAIR_PROCESS | HYPOTHESIS_BROTHERHOOD_SPECIFIC | none — Brotherhood hypothesis |
| PF-AUTONOMY | BH-LH-04 | ASYMMETRIC | mentor, friend | ORDERED_ACTOR_PARTNER | HYPOTHESIS_BROTHERHOOD_SPECIFIC | MENTOR-001 |
| PF-DECISION-TEMPO | BH-LH-05 | CONTEXT_DEPENDENT | business_partner, worker_team, mentor, project_partner, activity_partner | ROLE_DEFINED | HYPOTHESIS_REQUIRES_EXTERNAL_REFERENCE_AND_VALIDATION | none — Brotherhood hypothesis |
| PF-ROLE-RISK | BH-LH-06 | CONTEXT_DEPENDENT | business_partner, project_partner, activity_partner | ROLE_DEFINED | HYPOTHESIS_REQUIRES_EXTERNAL_REFERENCE_AND_VALIDATION | none — Brotherhood hypothesis |
| PF-PSY-COOP | PSY-TRUST | CONTEXT_DEPENDENT | friend, business_partner, worker_team, mentor, project_partner | PAIR_OR_ORDERED_TO_TEST | HYPOTHESIS_SEPARATE_FROM_PLATFORM_TRUST | TRUST-001, TRUST-002 |
| PF-METHOD-DYAD | method/control | NEUTRAL | friend, business_partner, worker_team, mentor, project_partner, activity_partner | METHOD_CONTROL | CANONICAL_METHOD_CONTROL | DYADIC-KENNY-1996, DYADIC-KENNY-COOK-1999, DYADIC-ORTH-2013 |
| PF-METHOD-UNCERTAINTY | method/control | NEUTRAL | friend, business_partner, worker_team, mentor, project_partner, activity_partner | METHOD_CONTROL | CANONICAL_METADATA_NOT_SCORE_BONUS | STD-APA-001, VALID-MESSICK-1995 |

Every row is either a method control or a candidate hypothesis. Relation mode becomes model-active only after preregistered role-specific validation. Missing source anchors never justify author-defined coefficients.
