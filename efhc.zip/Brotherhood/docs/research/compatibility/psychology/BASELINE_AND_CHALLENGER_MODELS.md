# PC v1 — Baseline and Challenger Models

Status: **RESEARCH MODEL LADDER / NO WINNER / NO PRODUCTION ACTIVATION**

## B0 — null/reference
Outcome-appropriate base-rate/intercept comparator. Prevents celebrating a complex model that adds no useful out-of-sample signal.

## B1 — transparent prespecified pair-feature baseline
Uses only validated construct estimates and preregistered pair transforms. No automatic feature discovery. Primary scientific baseline.

## B2 — regularized parametric model
Generalized linear/ordinal/survival form selected from the outcome definition. Regularization and tuning occur only inside training/development partitions.

## B3 — generalized additive model
Allows preregistered nonlinear relation shapes without abandoning inspectability. Must beat B1/B2 on locked validation while preserving calibration/fairness.

## B4 — hierarchical role/locale model
May partially pool parameters across roles/locales only after measurement comparability supports that interpretation. Failed invariance means no automatic shared scale.

## C1 — ML challenger
Tree/boosting or another non-linear challenger is research-only. It must use a locked feature set, grouped/person/dyad-safe splits, no protected-outcome leakage, calibration assessment, fairness review and privacy-safe explanation. It cannot auto-promote.

## Selection principle
Prefer the simpler model when performance/utility differences are negligible or unstable. Model selection must report uncertainty, calibration and transportability, not only one discrimination metric.
