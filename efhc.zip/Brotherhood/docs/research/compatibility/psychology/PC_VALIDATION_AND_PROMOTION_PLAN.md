# PC v1 — Validation and Promotion Plan

Status: **RESEARCH GATE / NO AUTO-PROMOTION**

## A. Pre-model gates
1. Freeze intended use and role outcome.
2. Freeze eligible construct versions.
3. Freeze candidate relation mode for each pair feature.
4. Confirm measurement validity/precision and 13-locale scope.
5. Register confounds, exclusions and temporal cutoff.

## B. Dyadic design
- preserve dyad/person IDs;
- split data so the same people/dyads do not leak across train/holdout in ways that inflate performance;
- model actor/partner/dyad dependence where design requires it;
- test shared-method variance and visual-method artifacts;
- separate pair formation/selection from later quality/maintenance outcomes.

## C. Model comparison
Compare B0→B4 and optional C1 on preregistered metrics appropriate to the outcome. Report confidence intervals/uncertainty, calibration, missingness/coverage effects and subgroup/locale stability.

## D. Multilingual gate
For every locale `sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id` record:
- translation/adaptation version;
- measurement invariance/DIF status;
- calibration sample and uncertainty;
- outcome-model calibration;
- whether common, partially pooled or locale-specific parameters are scientifically supported.

A locale with insufficient evidence remains `INSUFFICIENT_VALIDATION`; it is not silently mapped through another language's coefficients.

## E. Replication/promotion
`HYPOTHESIS → TECHNICAL_PILOT → PILOT_CALIBRATED → INTERNALLY_VALIDATED → EXTERNALLY_REPLICATED → PRODUCTION_QUALIFIED`.

Research results may propose a versioned candidate. Only human/scientific review plus owner/release approval can authorize production. Longitudinal outcomes never auto-update production.
