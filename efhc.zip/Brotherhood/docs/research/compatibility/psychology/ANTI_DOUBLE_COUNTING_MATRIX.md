# Psychology Construct Anti-Double-Counting Matrix

Status: **ACTIVE RESEARCH CONTROL — CYCLE 0006**

Purpose: prevent artificial score inflation caused by feeding overlapping psychological constructs into PC as if they were independent evidence.

| Candidate signal A | Potential overlap B | Risk | Required treatment |
|---|---|---|---|
| Big Five Extraversion | HEXACO Extraversion | HIGH | alternative coordinate representations; never additive without residual/incremental evidence |
| Big Five Agreeableness | HEXACO Agreeableness | HIGH | alternative representation; compare models rather than sum |
| Big Five Conscientiousness | HEXACO Conscientiousness | HIGH | alternative representation; shared variance explicitly controlled |
| Big Five Openness | HEXACO Openness | HIGH | alternative representation |
| Neuroticism / Emotional Stability | HEXACO Emotionality | MEDIUM/HIGH | related but non-identical; discriminant model required |
| Agreeableness | Honesty–Humility | MEDIUM | do not assume equivalence; test incremental value of H-H |
| Extraversion | IPC Agency | MEDIUM | distinguish broad sociability/energy from interpersonal dominance/control |
| Agreeableness | IPC Communion | MEDIUM | distinguish broad agreeableness from warmth/affiliation coordinate |
| Attachment anxiety | Neuroticism/negative emotionality | MEDIUM | discriminant validity required; do not substitute one for another |
| Attachment avoidance | Introversion/low communion | MEDIUM | distinguish closeness regulation from sociability/affiliation |
| Responsiveness | CC responsiveness | HIGH cross-engine | single provenance; PC only if justified as personality relation and incremental beyond CC |
| Repair readiness | CC conflict/repair | HIGH cross-engine | default home is CC unless PC-specific incremental validity is demonstrated |
| Psychological trust | platform Trust | CRITICAL semantic | hard separation: psychological construct never overwrites identity/reliability/moderation Trust |
| Cooperation/reciprocity | Quality Fit desired qualities | MEDIUM cross-engine | QF expresses seeker preference; PC describes pair relation; no hidden transfer |
| Risk posture | lifestyle risky activities | MEDIUM cross-engine | distinguish psychological risk preference from practical lifestyle constraints |
| Decision tempo | lifestyle pace / work-role requirement | MEDIUM cross-engine | person preference vs environmental/role requirement must remain separate |
| Commitment discipline | Conscientiousness / platform reliability | CRITICAL | if retained, must prove distinct measurement; platform behavioral reliability remains Trust-domain evidence |

## Statistical/modeling controls
Candidate combined models must predeclare at least one overlap strategy: model comparison, residualization where interpretable, regularization, latent-variable modeling, hierarchical feature grouping, or exclusion of redundant coordinates. Selection is validation-driven; no method is canonical before data.

## Engine ownership rule
When the same measurement is useful to multiple engines, store one versioned measurement lineage and let each engine consume only explicitly authorized derived features. Do not duplicate measurement events to make evidence look stronger.
