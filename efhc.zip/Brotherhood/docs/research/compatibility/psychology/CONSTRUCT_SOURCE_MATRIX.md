# Psychological Construct → Source/Evidence Matrix

Status: **ACTIVE CYCLE 0006 EVIDENCE MAP**

| Construct family | Scientific registry anchors (original 60-source authorized snapshot + later citation references where applicable) | Cycle-0006 external verification | What evidence supports | What remains Brotherhood-specific |
|---|---|---|---|---|
| Big Five/IPIP | `IPIP-001..004` | official IPIP Big-Five marker pages | existence/measurement of five broad dimensions and public-domain IPIP resources | indirect visual loading, pair relation, role coefficients |
| HEXACO | `HEXACO-001..003` | official HEXACO domain/scale/reference pages | six-domain model/reference inventory | incremental value, Brotherhood pair relation, visual mapping |
| IPC | `IPC-001`, `IPC-002` | IPC literature on agency/communion | two-dimensional interpersonal structure; complementarity is empirically researchable | exact role-specific compatibility function |
| Attachment | `ATTACH-001` | Fraley et al. 2000 PMID 10707340; ECR-RS PMID 21443364 | dimensional anxiety/avoidance assessment and relationship-context measurement | transfer to Brotherhood male friendship/business/team roles |
| Responsiveness | `COMM-001` | Canevello & Crocker 2010 PMID 20565187 | responsiveness is associated with close relationship quality/process | PC-vs-CC ownership and pair scoring |
| Conflict/repair | supporting role/friendship sources | De Dreu & Weingart 2003 PMID 12940412; Behfar et al. 2008 PMID 18211143 | conflict types/processes relate to team outcomes/satisfaction | stable-vs-state ontology and Brotherhood pair coefficient |
| Psychological trust/cooperation | `TRUST-001`, `TRUST-002`, `HEXACO-001/002` | HEXACO cooperation studies reviewed as support | trust/cooperation are relevant constructs/outcome correlates | person-pair PC feature and separation from platform Trust |
| Risk/decision | no dedicated source in authorized 60 pack | DOSPERT Blais & Weber 2006; Columbia DOSPERT page | risk preference is domain-specific and can separate propensity/perception/benefit | exact reference rights, Brotherhood risk feature, pair relation |
| Brotherhood-specific hypotheses | indirect support only | none can validate them externally by definition | theoretical motivation only | entire construct definition, measurement, incremental and outcome validity |

## Production rule
No row authorizes production scoring. External construct validity is evidence for what may be measured; Brotherhood must separately validate how it measures it and how two people should be compared.
