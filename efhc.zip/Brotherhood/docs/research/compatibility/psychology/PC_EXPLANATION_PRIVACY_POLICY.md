# PC v1 — Explanation and Privacy Policy

Status: **RESEARCH CANON / RAW LATENT PROFILE PRIVATE**

## Public result surface
Allowed fields: role, PC score, coverage, freshness, model/evidence status, short strengths-first interaction explanation and methodology/version link.

## Forbidden disclosure
No raw latent coordinates, hidden test loadings, item responses, stimulus choices, consistency/invalid-response flags, diagnostic labels, inferred sensitive attributes, exact private profile reconstruction or raw partner-effect decomposition for another person.

## Explanation rule
An explanation must be generated from a validated, versioned pair-feature lineage. It describes the **interaction pattern**, not a hidden diagnosis of the other user. Unsupported causal language is forbidden.

## Sensitive/fairness variables
Sensitive attributes are not PC prediction features by default. Where lawful/consented, they may be used in separated fairness auditing. Fairness-audit variables do not become hidden score features.

## Asymmetric roles
For mentor or supervisor/member research, directional explanations must disclose the role perspective (for example, mentor→mentee) without exposing the other person's private latent profile.
