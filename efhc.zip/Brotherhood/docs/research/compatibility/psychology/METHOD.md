# Psychology Compatibility — METHOD

Status: **ACTIVE RESEARCH METHOD / CYCLE 0006 ARCHITECTURE / REQUIRES_VALIDATION**  
Metric ID: `PC`

## Purpose
Compute one independent Psychology Compatibility result for a specific pair and role context. `PC` is not Quality Fit, platform Trust, Communication Compatibility or Overall.

## Construct architecture
Canonical reference: `PSYCHOLOGICAL_CONSTRUCT_ARCHITECTURE.md`.

Candidate construct spaces are Big Five/IPIP, HEXACO, IPC agency/communion, attachment anxiety/avoidance, responsiveness/support, conflict/repair, psychological trust/cooperation and risk/decision research. Big Five and HEXACO are overlapping coordinate families rather than automatically additive feature sets.

Brotherhood-specific latent dimensions are allowed only as `HYPOTHESIS` until they demonstrate measurement, discriminant, incremental and role-outcome validity.

## Inputs
Versioned private construct estimates derived from validated assessments; role context; measurement reliability/quality; recency/freshness; declared provenance/coverage. Missing or withheld inputs are never imputed as neutral personality.

## Dyadic relation model
Each active construct-role cell must ultimately use exactly one owner-canonical relation mode: `SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC`, or `NEUTRAL`. A research cell may be marked `CONTEXT_DEPENDENT` while unresolved, but that flag cannot become a production scoring operator.

## Candidate scoring model
Role-specific dyadic model over versioned pair features. Transparent baselines are mandatory before more complex models. No universal trait-distance rule and no arbitrary production weights.

## Normalization
Public service output is an exact `0..100` result of the active Brotherhood model version for the given inputs. Future approved versions may recalculate a different exact result. It is not automatically a probability of friendship/business success unless a future version is explicitly outcome-calibrated and labeled accordingly.

## Minimum data / coverage
Minimum construct coverage is model-version specific. Insufficient measurement returns `INSUFFICIENT_DATA`; missingness never becomes score zero.

## Privacy/explanation
Only pair-level safe explanations are public. Do not reveal another person's raw construct scores, hidden type, test trace or sensitive inferred data.

## Outcome calibration
Outcomes may evaluate criterion/predictive usefulness. They never mutate production automatically: research analysis → human/scientific review → candidate version → validation → owner/release approval.
