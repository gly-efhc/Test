# Psychology Compatibility — MODEL SPEC

Status: **CYCLE 0006 FOUNDATION — SUPERSEDED IN DETAIL BY CYCLE 0009 V1 RESEARCH SPEC / RETAINED FOR TRACEABILITY**  
Metric ID: `PC`

Current detailed replacement: `PSYCHOLOGICAL_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`. This file remains the cycle-0006 foundation and is not deleted.

## Contract
Input: pair A/B + role context + permitted versioned construct estimates.  
Output: independent `score 0..100`, coverage, freshness, evidence/model/method versions and privacy-safe explanation metadata.

## Stage 1 — measurement layer
Estimate declared constructs with explicit source/instrument/model provenance. Protected Brotherhood visual responses can contribute only through a validated measurement model; current visual→latent links remain hypotheses.

## Stage 2 — construct representation
Compare parsimonious candidate representations rather than stacking overlapping coordinate systems:
- Big Five baseline;
- HEXACO baseline;
- IPC interpersonal baseline;
- validated combined representation with anti-double-counting controls;
- Brotherhood-specific additions only after incremental-validity evidence.

## Stage 3 — dyadic feature transform
For each role, transform person A/B construct estimates according to a predeclared relation mode: `SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC`, or `NEUTRAL`. `CONTEXT_DEPENDENT` is research metadata only.

## Stage 4 — role model
Role-specific models are permitted inside PC, because friend/business/team/mentor/project contexts may have different relation criteria. Role differences do not create cross-metric weights.

## Stage 5 — score normalization
Normalize the validated role model into the exact versioned `0..100%` Brotherhood Psychology Compatibility score produced by frozen parameters of the active model version. Coverage/confidence remains separate and cannot silently inflate/deflate PC. A later approved model version may legitimately recalculate a different exact score.

## Missingness
Missing/withheld constructs are not zeros. Model uses only declared available features and returns reduced coverage or `INSUFFICIENT_DATA` under a frozen gate.

## Selection/validation
Candidate models are fit on research data separate from locked validation/holdout. Compare against transparent baselines; prefer parsimony and interpretability when predictive differences are negligible.

## Hard exclusions
- no platform Trust inputs as PC score components by default;
- no Quality Fit desired vector folded into PC;
- no direct reuse of the same CC signal without feature-lineage/incremental-validity review;
- no post-match outcome leakage into pre-match features;
- no production coefficient asserted by this document.
