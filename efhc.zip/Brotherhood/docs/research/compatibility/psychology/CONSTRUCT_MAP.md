# Psychology Compatibility — Construct Map

Status: **ACTIVE MASTER CONSTRUCT MAP — CYCLE 0006 / REQUIRES_VALIDATION**

Master architecture: `PSYCHOLOGICAL_CONSTRUCT_ARCHITECTURE.md`  
Machine-readable registry: `CONSTRUCT_REGISTRY.json`  
Overlap control: `ANTI_DOUBLE_COUNTING_MATRIX.md`  
Reference battery: `REFERENCE_BATTERY_ARCHITECTURE.md`

| Family | Canonical construct space | Ontology | Candidate dyadic relation | Evidence/use boundary |
|---|---|---|---|---|
| Big Five / IPIP | Extraversion, Agreeableness, Conscientiousness, Emotional Stability/Neuroticism, Openness/Intellect | TRAIT | role-specific `SIMILARITY/COMPLEMENTARITY/ASYMMETRIC/NEUTRAL` | reference coordinate family; visual→trait mappings remain hypotheses |
| HEXACO | Honesty–Humility, Emotionality, Extraversion, Agreeableness, Conscientiousness, Openness | TRAIT | role-specific | alternative/reference coordinate system; do not double-count five neighboring domains with Big Five |
| IPC | Agency, Communion | RELATIONAL_ORIENTATION | especially role/context dependent | interpersonal coordinate system; complementarity requires dyadic validation |
| Attachment | Anxiety, Avoidance | RELATIONAL_ORIENTATION | similarity/asymmetry candidates; not fixed | close-relationship evidence requires transfer validation to Brotherhood roles |
| Responsiveness/support | perceived responsiveness, autonomy-supportive response | RELATIONAL_ORIENTATION / STATE_PROCESS | asymmetric or pair-process candidates | potential overlap with `CC`; incremental-validity gate required |
| Conflict/repair | conflict type/sensitivity, escalation, repair readiness | STATE_PROCESS / RELATIONAL_ORIENTATION | context dependent | do not force state/process data into trait ontology |
| Psychological trust/cooperation | dispositional trust, cooperation, reciprocity | TRAIT / RELATIONAL_ORIENTATION | context dependent | **not** platform Trust score |
| Risk/decision | domain-specific risk propensity/perception/benefit; decision tempo hypothesis | PREFERENCE / TRAIT candidate | role-specific | domain specificity required; no universal “riskiness” score assumed |
| Brotherhood latent hypotheses | agency flexibility, reciprocity orientation, repair readiness, autonomy-support orientation, decision tempo, role-risk alignment | HYPOTHESIS | unresolved until validation | must demonstrate discriminant + incremental + outcome validity before retention |

## Relation-type rule
The final model version assigns each active construct-role cell one canonical relation mode: `SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC`, or `NEUTRAL`. `CONTEXT_DEPENDENT` only flags unresolved research and is not itself a scoring mode.

## Anti-double-counting rule
A construct can be measured once and reused through explicit feature lineage, but PC/CC/VC/Quality Fit/platform Trust must not silently duplicate the same signal under different labels.

## Moral neutrality
Trait positions are not good/bad-person labels. Utility is role/context/pair dependent, and public explanations must remain positive/contextual and privacy-safe.
