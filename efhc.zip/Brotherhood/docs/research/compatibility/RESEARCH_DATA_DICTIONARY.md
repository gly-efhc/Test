# Compatibility Research Data Dictionary

Status: **TARGET RESEARCH SCHEMA; not proof current DB implements it**.

## 1. Principles
- `global_id` remains product identity; research exports use pseudonymous study identifiers where possible.
- Raw assessment data, derived profiles, pair scores and outcome data are separate tables/exports.
- Every record carries model/stimulus version and timestamp.

## 2. Core entities
### participant_research_profile
`research_subject_id`, consent_version, locale, cohort, enrollment_at, withdrawal_at.

### stimulus_response
assessment_version, series_id, stimulus_id, asset_version, option_id, rendered_position, latency_ms, viewport_class, session_id, retake_index, quality_flags.

### reference_measure_score
instrument_id/version, scale_id, score, reliability_context, administration_at. Raw licensed items are not exported unless legally permitted.

### latent_profile_snapshot
model_version, construct_id, estimate, standard_error/uncertainty, evidence_count, calculated_at.

### compatibility_pair_snapshot
viewer_subject, candidate_subject, role_context, metric_id/version, score_0_100, coverage, explanation_version, calculated_at.

### exposure_event
recommendation_model_version, ranking_position, candidate shown/opened, metric UI shown, checkbox selection. Needed to understand selection bias.

### interaction_outcome
message_started, reciprocal_reply, continued_30d/90d/180d, user-reported satisfaction, relationship type, optional meeting/project outcome, withdrawal flags.

## 3. Prohibited shortcuts
- do not store “ground_truth_personality=true” from one questionnaire;
- do not infer negative outcome merely from no message if candidate was never exposed;
- do not use raw message text as research data by default;
- do not overwrite old model outputs after model update.

## 4. Provenance
Every derived field must be reproducible from immutable input snapshot + model manifest. Model version is mandatory.
