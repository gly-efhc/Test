# Visual Test Stimulus & Material Specification

Status: **ACTIVE MATERIAL REQUIREMENTS; cycle-0007 detailed taxonomy/primitive/composition registries live in `../visual_tests/`**.

## 1. Purpose
Define exactly what visual materials are needed for the 100×6 Brotherhood assessment research program and how every asset remains scientifically traceable.

## 2. Mandatory manifest fields per asset
```text
asset_id
asset_version
stimulus_id
option_id
paradigm_family
hypothesized_constructs[]
competing_explanations[]
role_in_item: target | distractor | control
visual_parameters
semantic_description
creation_source
license/provenance
locale_dependence
accessibility_notes
mobile_render_targets
hash_sha256
approval_status
pilot_statistics
```

## 3. Material classes
### A. Abstract geometry
Spatial order, density, balance, asymmetry, direction, grouping. Suitable for low-language stimuli but especially vulnerable to aesthetic confounds.

### B. Object/scene organization
Workspace, task sequence, resources, arrangement decisions. Must not encode obvious “responsible” answer.

### C. Social interaction scenes
Cooperation, autonomy, proximity, turn-taking, support. Require stereotype/bias review and multiple equivalent scene variants.

### D. Decision/risk scenes
Visual uncertainty, resource allocation, exploration/exploitation. Must distinguish risk preference from numeracy or visual comprehension.

### E. Temporal/planning sequences
Choose next step/order/priority. Must control for domain knowledge.

### F. Control stimuli
Designed to estimate color preference, visual salience, position effects, attention and response quality rather than personality.

## 4. Visual equivalence checklist
Options within one task should be comparable in:
- pixel/occupied area;
- luminance/contrast;
- saturation;
- edge density;
- number of objects;
- text amount (preferably zero);
- emotional valence unless valence is the intended variable;
- cultural familiarity;
- apparent quality/beauty.

Automated image statistics are diagnostic only; human review remains required.

## 5. Multi-language strategy
Prefer language-light stimuli. Any text-bearing material requires 13-locale semantic equivalence review and separate localization version. Cross-language measurement invariance still must be tested even for language-free images because culture affects interpretation.

## 6. Asset provenance
No unknown-license internet image may enter production research. Every asset must be owner-created, properly licensed, public-domain/compatible, or have documented permission. Store provenance separately from runtime delivery assets.

## 7. Rendering matrix
At minimum review 320, 360, 390, 412/430px mobile widths, light/dark themes where stimulus background can influence perception, and major density/font accessibility settings where text exists.

## 8. Anti-cueing review
Independent reviewer asks:
- Which option looks morally/socially “better”? 
- Which is prettier or higher quality?
- Which has more contrast/detail?
- Which implies wealth/status?
- Which may reveal the construct to a motivated participant?

Any obvious cue requires rework or explicit calibration as a confound.

## 9. Production package
A production stimulus release must include:
- immutable manifest;
- hashes;
- asset bundle;
- measurement model version;
- approved locale map;
- accessibility report;
- calibration report;
- rollback reference.
