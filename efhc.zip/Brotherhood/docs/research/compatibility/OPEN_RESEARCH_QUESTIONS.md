# Open Research Questions after Cycle 0010

Status: **ACTIVE — feeds cycles 0011+ and empirical validation**

## Highest-priority unresolved scientific questions

1. Which protected Brotherhood visual stimuli predict the cycle-0006 reference constructs out-of-sample after controlling position, device, locale, aesthetic preference and response-style effects?
2. Which cycle-0006 construct families add incremental role-outcome prediction beyond simpler Big Five/IPIP, IPC, Interests, Values, Communication and Lifestyle baselines?
3. For every retained construct × role cell, which canonical relation mode is supported: `SIMILARITY`, `COMPLEMENTARITY`, `ASYMMETRIC`, or `NEUTRAL`? `CONTEXT_DEPENDENT` remains research metadata only.
4. Does Honesty–Humility add incremental role-relevant information beyond Big Five/IPC in Brotherhood samples, or is a simpler representation preferable?
5. How much of IPC Agency/Communion is incremental beyond Extraversion/Agreeableness in the Brotherhood intended-use population?
6. Do attachment anxiety/avoidance generalize validly from close/romantic research to male friendship, business, team, mentorship and project contexts?
7. Which responsiveness/conflict/repair variables are stable individual orientations versus interaction states/processes? They must not be forced into a trait ontology without evidence.
8. Which current PC candidate signals belong instead to the independent Communication Compatibility engine, and what incremental-validity rule prevents cross-engine double counting?
9. Which psychological trust/cooperation variables are useful for PC while remaining completely separate from platform Trust identity/reliability/moderation evidence?
10. Which exact domain-specific risk reference and decision-style measures are selected for calibration, and are they needed outside business/project/activity contexts?
11. Does Brotherhood-specific `BH-LH-01..06` add discriminant/incremental validity? Any failed hypothesis must be retired or redefined rather than preserved by narrative preference.
12. Which exact IPIP scales/facets are the shortest adequate Tier-A reference battery after overlap/power analysis?
13. Which HEXACO representation is used in the calibration battery, given that owner-confirmed project permission now removes the previous permission blocker for the current 60-source pack?
14. Which exact attachment/IPC/conflict/risk instruments should be frozen for the first empirical calibration battery, and what item-level rights apply if they are outside the owner-authorized 60-source pack? Cycle 0008 froze the execution protocol but did not pretend this instrument-selection question was empirically resolved.
15. `PARTIALLY RESOLVED IN 0010`: Friendship outcomes now have a fixed hierarchy (eligible exposure → initiation → reciprocity → early continuity → dyadic quality → persistence → optional shared value/repair-dissolution). The exact pilot primary endpoint(s) remain to be preregistered before observing data; cycle 0010 recommends comparing mutual continuity with dyadic quality rather than using raw engagement.
16. How should self-selection bias be handled when longitudinal outcomes exist mostly for pairs that choose to interact?
17. What minimum sample size/power is required for construct measurement, relation-mode comparisons, role-specific models and subgroup fairness checks? Do not guess before the analysis degrees of freedom are frozen.
18. How stable are indirect visual responses across retest intervals, devices and 13 locales (`sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`)?
19. How should response latency be used: quality-control only, optional process feature or trait signal? It remains `HYPOTHESIS` until incremental validity is demonstrated.
20. What falsification/retirement thresholds apply to a visual stimulus, Brotherhood-specific construct or candidate dyadic relation before pilot data are examined?

## Rights / provenance state after owner clarification

- **Resolved for the original cycle-0005 60-source authorization snapshot:** owner confirms official permission for all 60 source IDs in that snapshot **including commercial release/commercial use**. Current product positioning is social; monetization status is not a permission blocker for this snapshot.
- **Still source-specific compliance:** attribution/notice/scope conditions remain metadata and must be honored according to the permission/source terms.
- **Not automatically covered:** external references added after the 60-source snapshot, including cycle-0006 attachment/conflict/risk verification references, require their own embedding/reuse decision if item/content reuse is later proposed.
- Permission status does not change evidence class, psychometric validity or production-scoring eligibility.

## Non-question: fixed inter-metric weights

There is no research question about restoring hidden inter-metric weights. Each metric is independent; Overall remains only the simple arithmetic mean of the user-selected available Compatibility scores.

## Resolved architecture decisions through cycle 0009
- PC is role-specific dyadic research modeling, not one universal similarity distance.
- Dyad non-independence and actor/partner directionality are explicit method requirements.
- `score 0..100` is the exact output of a versioned Brotherhood algorithm for its inputs; it is not called a success probability without separate probability validation.
- Similarity/complementarity/asymmetry remain construct×role hypotheses; no universal `100−distance` or "opposites attract" rule is authorized.
- All 13 locales remain in scope from research design onward; pooling across locales requires measurement/outcome evidence.
- New post-Q30 references do not silently inherit the original 60-source commercial-use permission snapshot.
- No cycle-0009 claim or pair feature has production-scoring authorization.

## Cycle 0010 resolved architecture decisions
- Friendship Science is a friend-role outcome/validation program, not a tenth Compatibility engine.
- Formation, quality and persistence use different denominators and must not be collapsed without an explicit model.
- No reply/noncontinuation is not a negative without exposure/opportunity/censoring evidence.
- Friendship maintenance, responsiveness, mattering and conflict/repair are primarily relationship process/outcome constructs until stable antecedents are separately validated.
- Population-level male friendship findings cannot define individual users; Brotherhood supports both dyadic and group/club social pathways.
- Raw private message content is not required by the default longitudinal research contract.
- Exact friendship research locale scope remains all 13 canonical locales.
