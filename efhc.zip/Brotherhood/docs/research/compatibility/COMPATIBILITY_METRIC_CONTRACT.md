# Compatibility Metric Contract

Status: **ACTIVE CONTRACT FOR ALL COMPATIBILITY ENGINES**.

Every metric engine must implement the following conceptual contract before it can be wired into the common Compatibility page.

## 1. Identity
- `metric_id` — stable short identifier;
- `metric_name`;
- `metric_family`: empirical / typological / alternative;
- `metric_version`;
- `evidence_status`;
- supported `role_contexts`.

## 2. Input contract
Document exactly:
- which public/private profile data are used;
- minimum data;
- measurement/model versions;
- optional sensitive fields;
- missing-data policy;
- recency policy.

## 3. Output contract
```text
metric_id
metric_version
role_context
score_0_100 | unavailable
coverage
calculated_at
explanation_version
evidence_status
input_snapshot_refs
```

## 4. Score semantics
`score_0_100` is the exact numeric output of the declared `metric_version/model_version` for the declared input snapshot, normalized to `0..100` inside that method. The same version+inputs must reproduce the same result when the algorithm is deterministic. A future approved version may return a different exact value. The percentage is not automatically an outcome probability unless a separate probability-calibration protocol explicitly establishes that semantic.

## 5. No cross-metric weights
A metric engine has no authority to decide its weight in Overall. Cross-metric Overall is calculated by `OVERALL_AGGREGATION.md`: simple arithmetic mean of user-selected available metrics.

Internal weighting *inside one metric* is allowed only if documented and justified by user configuration, transparent baseline logic or empirical calibration.

## 6. Role context
The engine must either:
- return a role-specific model result; or
- declare the context unsupported; or
- explicitly state that the same method is context-invariant.

Silent reuse of a `friend` model as `business partner` is forbidden.

## 7. Coverage
Coverage is separate from score. A 95% score with 20% usable evidence must not visually imitate a 95% score with strong evidence. Engine defines minimum coverage and blocking rule.

## 8. Explanation
Must expose pair-level reasons without revealing another user’s hidden test answers or latent coordinates. Explanation text is versioned because interpretation can change independently from numerical model.

## 9. Evidence and claim
Every production claim links to `BROTHERHOOD_SOURCE_MAP_v004` and/or Brotherhood validation report. `HYPOTHESIS` is an allowed honest status.

## 10. Privacy/security
Metric contract lists:
- raw data sensitivity;
- retention;
- export/delete behavior;
- whether the metric is visible to candidate, viewer, both, or research admin;
- whether inputs may be used for research training.

## 11. Validation gate
Empirical metrics: follow `PSYCHOMETRIC_VALIDATION_PROTOCOL.md` / outcome validation as applicable. Typological/alternative metrics use their own disclosed evidence status and deterministic reproducibility tests.

## 12. Failure behavior
Never fabricate a score. Return one of:
- `AVAILABLE`;
- `INSUFFICIENT_DATA`;
- `UNSUPPORTED_CONTEXT`;
- `MODEL_UNAVAILABLE`;
- `CONSENT_REQUIRED`;
- `RESEARCH_ONLY`.
