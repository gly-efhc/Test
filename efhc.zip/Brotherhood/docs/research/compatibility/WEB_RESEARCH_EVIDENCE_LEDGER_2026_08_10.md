# Web Research Evidence Ledger — 2026-08-10 — Cycle 0005

Status: **VERIFIED WEB RESEARCH OBSERVATIONS**

## Standards / use boundaries
- AERA/APA/NCME `Standards for Educational and Psychological Testing` rechecked; the standards apply broadly to psychological/personality/interest assessment uses and emphasize evidence for intended interpretations/uses.
- ITC technology-based assessment guidance rechecked; validity/fairness are use/context dependent and digital administration can introduce measurement threats.
- ITC test-adaptation guidance rechecked; multilingual/cultural adaptation is a methodological process, not simple translation.
- IPIP official site rechecked: items/scales are public domain and may be copied, edited, translated or used for any purpose without permission/fee.
- HEXACO official non-academic-use page rechecked: non-academic use is controlled under a separate licensing process. Exact current commercial terms must be rechecked at adoption time.

## Forced-choice / visual evidence
- Martínez & Salgado (2021) meta-analysis added for forced-choice faking resistance.
- Valone & Meade (2024) added as falsification/robustness boundary: forced-choice is not a panacea for faking.
- Existing Hilliard image-based studies remain evidence for a specific calibrated image-based assessment, not for arbitrary Brotherhood image→trait mappings.

## Friendship / relationship evidence
- Laakasuo et al. (2020) added: real-life friendship-group homophily effects are trait/context-specific.
- Roberts & Dunbar (2015) added: maintenance effort and interaction context relate to longitudinal relationship decay/persistence.
- Deventer et al. (2019) added: personality/relationship transactions are longitudinal and facet/time dependent.
- Canevello & Crocker (2010) added for perceived responsiveness.
- Feeney & Collins (2019) added as attachment/support review.
- Holt-Lunstad et al. (2010) added as outcome-context evidence only; mortality associations are explicitly barred from pairwise compatibility scoring.

## Values / work fit
- Schwartz & Cieciuch (2022) added for refined PVQ psychometrics across 49 cultural groups.
- Sagiv & Schwartz (2022) added as cross-cultural values review.
- Stoll et al. (2017) added as longitudinal vocational-interest evidence beyond IQ/Big Five.
- DeRue & Morgeson (2007) added to show person-team vs person-role fit can differ over time.

## Trust / mentor effect extraction
- De Jong et al. (2016): corrected trust–team performance relation `ρ=.30` recorded at claim level; this remains Trust evidence, not Compatibility weighting.
- Eby et al. (2013): 173 samples / combined N=40,737 and abstract-level correlation ranges recorded with explicit cross-sectional/single-source limitations.

## Traditional/software provenance
- VedAstro exact repository rechecked as public MIT-licensed traditional Vedic astrology/numerology/matching software provenance. It remains `D_TRADITIONAL`, not scientific validation.
- Diia exact official Android repository rechecked as EUPL-1.2; remains product/IA reference only.
- Historic unresolved `nikitakapoor/Numerology` is not replaced by a different repository.

## Review-depth rule
Where cycle 0005 used an abstract/database record, records are labeled `ABSTRACT_REVIEWED`; where an official page/license was checked, `OFFICIAL_PAGE_VERIFIED`; where PDF guideline sections were inspected, `FULL_TEXT_REVIEWED`. No unobserved effect size or sample detail is asserted.
