# Communication Compatibility — Longitudinal Outcome Validation Plan

Status: **REQUIRES_DATA / RESEARCH-ONLY**

## Predictor
The predictor is the immutable **exposure-time CC snapshot**, not a score recomputed later.

## Observation windows
Use Research Platform checkpoints `7 / 30 / 90 / 180 / 365 days` unless a later canonical protocol versions them.

## Process/outcome candidates
- candidate/profile action after actual exposure;
- message initiated;
- response opportunity and response occurrence kept separately;
- mutual communication / continuity buckets;
- voluntary communication comfort/satisfaction;
- voluntary perceived understanding/responsiveness;
- cadence satisfaction;
- disclosure comfort;
- conflict occurrence as a process event, not automatic failure;
- voluntary repair attempt and repair success;
- role-specific relationship status and persistence;
- role-specific voluntary success outcome.

## Confounders / context
At minimum preserve or model when available:
- actual exposure and rank;
- SearchIntent/recommendation policy;
- prior relationship/contact;
- shared language and locale;
- time zone, availability/workload and notification opportunity;
- geography/offline opportunity where relevant;
- communication channel/modality;
- role context;
- moderation/blocking/technical delivery constraints;
- relationship stage/tie strength.

## Invalid negative labels
- `not shown -> negative` — forbidden;
- `no click -> dislike` — forbidden;
- `no reply without opportunity/delivery/observation window -> incompatibility` — forbidden;
- `conflict -> incompatibility` — forbidden;
- `contact ended -> algorithm wrong` — forbidden.

## Analytic plan
Compare CC-R0 with challengers using dyad-aware validation, locked and temporal holdouts, calibration/criterion metrics appropriate to the declared outcome, subgroup/locale diagnostics and incremental validity. Do not choose the model on the same outcome sample used for the final claim.
