# Communication Compatibility — VALIDATION PLAN

Status: **REQUIRES_DATA / RESEARCH-ONLY**

Required gates:
1. intended-use/construct review and Psychology/Values/Interests/Lifestyle/QF/Trust boundary audit;
2. input reliability/response-quality and freshness analysis;
3. dyadic role-specific criterion/outcome validation;
4. actual vs perceived similarity separation;
5. baseline (`CC-R0`) versus directional/role/RSA challengers;
6. locked holdout + temporal holdout + no post-contact leakage;
7. opportunity-aware outcome labels (`no reply` is not negative without delivery/opportunity/window);
8. 13-locale native QA, cultural review, invariance/DIF where applicable;
9. subgroup/fairness/proxy-leakage review;
10. privacy/consent/retention review with no default private-message semantic analysis;
11. external/temporal replication where feasible;
12. scientific/human review + owner/release approval.

Failure/ambiguity keeps the model at research status. No automatic coefficient adjustment is allowed.
