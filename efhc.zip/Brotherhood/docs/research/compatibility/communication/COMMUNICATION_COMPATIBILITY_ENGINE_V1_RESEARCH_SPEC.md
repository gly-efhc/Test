# Communication Compatibility Engine v1 — Research Specification

Status: **CYCLE 0016 COMPLETE / RESEARCH-ONLY / NOT PRODUCTION ACTIVE**  
Metric ID: `CC`  
Current transparent comparator: `CC-R0`  
Canonical roles: `friend`, `business_partner`, `worker_team`, `mentor`, `project_partner`, `activity_partner`  
Canonical locales: `sw, ru, en, uk, de, fr, es, it, tr, pl, da, hi, id`

## 1. Purpose and metric boundary

Communication Compatibility answers one narrow question: **how well two people's declared or independently assessed communication preferences fit for a declared role context under a specific versioned CC model**.

It is independent from:
- Psychology — latent personality/attachment/interpersonal constructs;
- Interests — what people like/do;
- Values — motivational priorities;
- Lifestyle — geography, schedule, habits and practical availability;
- Quality Fit — whether a candidate meets explicit role requirements;
- Trust — verified reliability, identity and behavioural history.

CC is not a relationship-success probability. A score such as `81.37%` means that the active CC algorithm version, for the stored input snapshot and role contract, computed exactly `81.37%`. A later approved algorithm may compute a different exact result for the same pair. This preserves Q34: **model uncertainty != arithmetic uncertainty**.

## 2. Temporal boundary: predictor versus process/outcome

The v1 research architecture separates two time layers.

### PRE_EXPOSURE predictor layer
Eligible CC inputs are collected before the recommendation/exposure decision or come from an earlier immutable snapshot:
- explicit communication preferences;
- voluntary structured assessments about preferred interaction;
- future validated indirect inferences only under a separate approved model/version;
- declared acceptable ranges and directional receiving/provision preferences.

### POST_CONTACT process/outcome layer
The following are **not** retroactive pre-exposure traits in CC-R0:
- actual response latency;
- whether a reply occurred;
- actual reciprocity;
- actual self-disclosure in the relationship;
- observed conflict/demand-withdraw behaviour;
- actual repair behaviour;
- relationship persistence/satisfaction.

These can evaluate a historical CC prediction only under Research Platform consent/provenance. Post-contact events must never leak into the historical predictor snapshot that preceded them.

## 3. Construct architecture

Machine SSOT: `COMMUNICATION_CONSTRUCT_REGISTRY.json`.

The v1 construct set is intentionally preference-centred:
1. `directness_preference`;
2. `disclosure_pacing_preference`;
3. `disclosure_depth_preference`;
4. `contact_frequency_preference`;
5. `response_latency_tolerance`;
6. `modality_preference`;
7. `support_receiving_preference`;
8. `support_provision_intent`;
9. `responsiveness_expectation`;
10. `feedback_directness_preference`;
11. `conflict_engagement_timing_preference`;
12. `repair_timing_preference`;
13. `autonomy_contact_boundary_preference`;
14. `reciprocity_expectation`.

A communication preference is not automatically a stable personality trait. `support_provision_intent` is self-report/intention, not verified behavioural reliability. Actual reliability remains Trust/outcome evidence.

## 4. Pair relation architecture

Machine SSOT: `COMMUNICATION_PAIR_FEATURE_REGISTRY.json`.

Allowed research relation modes:
- `SYMMETRIC_SIMILARITY` — tested when matched preferences plausibly reduce coordination friction;
- `RANGE_OVERLAP` — preferred point/range is compared with the other person's tolerance range;
- `DIRECTIONAL_CROSS_FIT` — A's intended provision is compared with B's receiving preference and separately B→A;
- `ROLE_CONDITIONAL` — relation may differ by role and must be validated per role;
- `NEUTRAL` — no contribution in a declared model version;
- `UNKNOWN_RESEARCH_ONLY` — evidence is insufficient to choose a relation.

There is no universal rule `more similarity = better communication`, and no universal complementarity rule.

## 5. CC-R0 transparent comparator

`CC-R0` is a Brotherhood-designed deterministic **research benchmark**, not an externally validated formula and not production active.

It uses five macro-families:
- `STYLE_DISCLOSURE`;
- `CADENCE_BOUNDARIES`;
- `SUPPORT_RESPONSIVENESS`;
- `CONFLICT_FEEDBACK_REPAIR`;
- `MODALITY`.

For each family only observed, schema-valid pair features are used. Family scores are bounded to `[0,1]`. The final score is:

`CC_R0 = round(100 * arithmetic_mean(available_family_scores), 2)`

subject to the declared coverage gate. The equal-family arithmetic mean is an engineering baseline chosen for transparency, **not an empirical law or production coefficient**.

Detailed formulas and coverage gates: `CC_BASELINE_ALGORITHM.md` and `CC_NORMALIZATION_AND_COVERAGE_POLICY.md`.

## 6. Role context

CC-R0 is deliberately role-neutral in its coefficients so it can serve as a transparent comparator. The role is still mandatory provenance. Role-specific relationships are evaluated only by challengers or later approved model versions.

Examples of hypotheses to validate rather than assume:
- `friend`: disclosure pacing, support/response expectations and cadence tolerance;
- `business_partner`: feedback directness, conflict/repair timing, cadence boundaries;
- `worker_team`: feedback/problem-solving and coordination expectations, while competence remains Quality Fit;
- `mentor`: directional mentor→mentee feedback/support fit; expertise remains Quality Fit;
- `project_partner`: conflict/repair and coordination preferences, without importing team-level effects as dyadic coefficients;
- `activity_partner`: contact/cadence/modality fit while schedule/geography remain Lifestyle.

## 7. Research challengers

Machine SSOT: `COMMUNICATION_MODEL_CHALLENGER_REGISTRY.json`.

Registered research-only challengers:
- `CC-R1-ROLE` — role-specific calibrated relations;
- `CC-R2-DIRECTIONAL` — deeper ordered giver→receiver cross-fit;
- `CC-R3-RSA` — nonlinear congruence/tolerance surfaces instead of raw difference-score assumptions;
- `CC-R4-PROCESS` — longitudinal communication-process model for research evaluation, explicitly isolated from pre-exposure CC until temporal-leakage and intended-use gates are passed.

No challenger can silently replace production scoring.

## 8. Research evidence boundaries

Current evidence supports studying disclosure, perceived responsiveness, support modes, texting/cadence similarity, conversational timing, conflict patterns and recovery/repair. However much of that evidence comes from romantic/close-relationship or context-specific populations. It therefore supports **constructs, hypotheses, outcome design and falsification boundaries**, not a Brotherhood coefficient.

Particularly:
- actual self-disclosure and perceived responsiveness are interaction processes/outcomes as well as potential structured preferences;
- face-to-face/subsecond response-time findings do not define asynchronous-message thresholds;
- demand/withdraw and conflict-recovery findings do not justify a universal pair penalty;
- messaging frequency/responsiveness effects vary by relationship context and culture;
- perceived communication similarity must not be substituted for independently measured pair similarity.

See `COMMUNICATION_SOURCE_TO_CLAIM_MATRIX.md`.

## 9. Research Platform integration

Machine contract: `CC_RESEARCH_PLATFORM_EXTENSION.json`.

At recommendation/exposure time preserve:
- `cc_score_at_exposure`;
- CC model/input/construct/pair-feature/normalization versions;
- role;
- coverage and missingness state;
- locale/adaptation version;
- immutable person A/B input snapshot IDs;
- SearchIntent and recommendation-policy version;
- candidate eligibility, rank and actual exposure timestamp.

Later events/outcomes are joined to that historical record, not used to rewrite it.

## 10. Privacy

Default CC research does **not** read or semantically analyse private message content. Preferred sources are explicit preferences, structured assessments, voluntary feedback and consented structural interaction events. Any future content analysis requires a separate cycle, explicit purpose/consent/retention policy and privacy review.

Raw private latent profiles are never exposed in pair explanations. Explanations use safe abstractions such as "preferred contact pace is within both users' stated tolerance".

## 11. 13-language validation

Translation is not psychometric equivalence. Every language-sensitive CC instrument/adaptation must pass native linguistic QA, cultural review, cognitive testing where appropriate, measurement invariance/DIF checks and locale-specific calibration if required.

Locale must never be used as a stereotype proxy such as `locale -> expected directness/cadence`. User-level measurements/preferences remain the input.

## 12. Promotion rule

Research progression remains:

`HYPOTHESIS -> TECHNICAL_PILOT -> PILOT_CALIBRATED -> INTERNALLY_VALIDATED -> EXTERNALLY_REPLICATED -> PRODUCTION_QUALIFIED`

Promotion requires preregistered intended use, measurement quality, dyadic/role outcome validation, locked/temporal holdout, calibration, fairness, privacy, 13-locale comparability and owner/release approval.

Production learning remains forbidden:

`production data -> research dataset -> offline candidate -> validation/review -> owner approval -> new version`

and never:

`user behaviour -> silent online score mutation`.
