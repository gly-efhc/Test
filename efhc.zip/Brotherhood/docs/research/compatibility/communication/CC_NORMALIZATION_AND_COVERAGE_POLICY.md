# CC Normalization, Missingness and Coverage Policy

Status: **CYCLE 0016 RESEARCH CONTRACT**

## Score normalization
All CC-R0 primitive and family values are bounded to `[0,1]`; the public-style research score is `round(100*x, 2)`.

## Missingness
`missing / withheld / stale / invalid != 0`.

A missing input removes only the dependent pair feature from the available-feature set. It never generates an incompatibility penalty.

## Family coverage
Each macro-family reports:
- available feature count;
- declared feature count;
- family coverage ratio;
- missing reason codes.

A family is available for CC-R0 when at least half of its declared pair features are computable; for the single-feature `MODALITY` family, the feature itself must be present for both users.

## Global research gate
CC-R0 is returned only when:
- at least **3 of 5** macro-families are available; and
- total available declared pair features are at least **60%** of the CC-R0 registry.

Otherwise output is `INSUFFICIENT_DATA` plus coverage metadata, not `0%`.

These thresholds are transparent engineering gates for the research comparator, not scientifically validated universal constants. Challenger/pilot work must test sensitivity to alternative gates before production qualification.

## Freshness
Communication preferences may change. Every snapshot stores collection time and freshness-policy version. No universal expiry duration is asserted in cycle 0016; reassessment intervals are `REQUIRES_DATA`.

## Coverage is never averaged into Compatibility
Coverage accompanies CC but is not a multiplier, penalty or hidden cross-metric weight.
