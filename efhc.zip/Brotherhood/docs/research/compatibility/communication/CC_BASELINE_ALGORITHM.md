# CC-R0 — Transparent Communication Compatibility Research Baseline

Status: **RESEARCH COMPARATOR / NOT PRODUCTION ACTIVE**

## Inputs
Only immutable `PRE_EXPOSURE` snapshots conforming to `COMMUNICATION_INPUT_SCHEMA.json`.

## Primitive functions
For normalized scalar preferences `a,b in [0,1]`:

`similarity(a,b) = 1 - |a-b|`

For a preferred point `x` and another user's acceptable interval `[l,u]`:

- `range_fit = 1` when `l <= x <= u`;
- otherwise `range_fit = max(0, 1 - distance(x, nearest(l,u)))`.

For two normalized simplex vectors `p,q`:

`vector_fit(p,q) = 1 - L1(p,q)/2`.

All primitive outputs are bounded `[0,1]`.

## Pair features
Declared formulas are SSOT in `COMMUNICATION_PAIR_FEATURE_REGISTRY.json`.

A pair feature is `MISSING`, never zero, when any required input is missing/withheld/invalid.

## Five macro-families
1. `STYLE_DISCLOSURE` — directness, disclosure pacing/depth.
2. `CADENCE_BOUNDARIES` — contact frequency, response-latency tolerance, autonomy/contact boundaries.
3. `SUPPORT_RESPONSIVENESS` — directional support fit plus responsiveness/reciprocity expectations.
4. `CONFLICT_FEEDBACK_REPAIR` — feedback directness, conflict engagement and repair timing.
5. `MODALITY` — declared communication-mode preference overlap.

Within each family:

`family_score = arithmetic_mean(available_declared_pair_features)`

only when that family passes its availability gate.

## Final baseline

`CC_R0 = round(100 * arithmetic_mean(available_family_scores), 2)`

only when the global coverage gate passes.

This equal-family arithmetic mean is a deliberately simple Brotherhood research comparator. It is **not** claimed as an empirically optimal weighting law. It creates a falsifiable baseline for `CC-R1..R4` challengers.

## Role semantics
Role is mandatory in provenance. CC-R0 uses no hidden role coefficients. Role-specific challengers must outperform/falsify this comparator under declared outcomes before any promotion.

## Q34
The numerical output of this deterministic model is exact for its version/input snapshot; it is not a probability of friendship/business/team success.
