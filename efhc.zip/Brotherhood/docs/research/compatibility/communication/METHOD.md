# Communication Compatibility — METHOD

Status: **CYCLE 0016 RESEARCH METHOD / NOT PRODUCTION ACTIVE**  
Metric ID: `CC`

Canonical full specification: `COMMUNICATION_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.

The method compares immutable pre-exposure communication preferences through transparent similarity, tolerance-range and directional cross-fit features. Post-contact actual behaviour is Research Platform process/outcome evidence and cannot leak into the historical predictor. CC-R0 returns an exact deterministic `0..100` research result when coverage gates pass; it is not a relationship-success probability.

Machine contracts: `COMMUNICATION_INPUT_SCHEMA.json`, `COMMUNICATION_CONSTRUCT_REGISTRY.json`, `COMMUNICATION_PAIR_FEATURE_REGISTRY.json`, `COMMUNICATION_MODEL_CHALLENGER_REGISTRY.json`, `CC_RESEARCH_PLATFORM_EXTENSION.json`.
