# Cycle 0016 Web Research Evidence Ledger

Access/revalidation date: `2026-08-10`  
Status: **SOURCE/CITATION RESEARCH ONLY**

Verified research additions:
- `COMM-002` — Laurenceau, Barrett & Pietromonaco (1998), self-disclosure/partner disclosure/perceived responsiveness, DOI `10.1037/0022-3514.74.5.1238`.
- `COMM-003` — Collins & Miller (1994), self-disclosure and liking meta-analysis, DOI `10.1037/0033-2909.116.3.457`.
- `COMM-004` — Schrodt, Witt & Shimkowski (2014), demand/withdraw meta-analysis (74 studies; N=14,255), DOI `10.1080/03637751.2013.813632`.
- `COMM-005` — Salvatore et al. (2011), conflict recovery longitudinal/observational study, DOI `10.1177/0956797610397055`.
- `COMM-006` — Gable, Gonzaga & Strachman (2006), supportive responses to positive-event disclosure, DOI `10.1037/0022-3514.91.5.904`.
- `COMM-007` — Templeton et al. (2022), conversational response timing/social connection, DOI `10.1073/pnas.2116915119`.
- `COMM-008` — Morelli et al. (2015), emotional/instrumental support provision, DOI `10.1037/emo0000084`.
- `COMM-009` — Vauclair et al. (2023), instant messaging/relationship satisfaction across 19 countries, DOI `10.5817/CP2023-3-8`.
- `COMM-010` — Holtzman et al. (2021), context-dependent texting frequency/responsiveness in long-distance vs geographically close romantic relationships, DOI `10.1177/02654075211043296`.
- `COMM-011` — Ohadi et al. (2018), perceived partner texting similarity and relationship satisfaction, DOI `10.1016/j.chb.2017.08.048`.

Research-use rule: sources can motivate constructs, boundaries, validation design and challenger hypotheses. None directly authorizes a Brotherhood production coefficient.
