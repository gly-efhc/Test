# Communication Compatibility — MODEL SPEC

Status: **CC-R0 TRANSPARENT RESEARCH COMPARATOR / REQUIRES_VALIDATION**

Current comparator: `CC-R0`, defined in `CC_BASELINE_ALGORITHM.md`.

Input: pair A/B immutable pre-exposure snapshots + role + locale/adaptation/version provenance. Output: exact versioned `score 0..100` or `INSUFFICIENT_DATA`, plus coverage and safe explanation metadata.

Missing/withheld inputs are not zeros. Five macro-families are aggregated with an unweighted arithmetic mean only after declared coverage gates. Equal-family weighting is a project-designed falsifiable baseline, not an external scientific law. Role-specific and nonlinear/directional models remain challengers and are not production active.
