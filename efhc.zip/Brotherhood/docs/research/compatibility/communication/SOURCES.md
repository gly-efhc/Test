# Communication Compatibility — SOURCES

Status: **ACTIVE CYCLE 0016 SOURCE MAP**

Primary communication IDs: `COMM-001..COMM-011`, with adjacent `FRIEND-*`, `IPC-*`, research-method and test-adaptation sources where explicitly mapped in the Claim Ledger.

Cycle 0016 adds `COMM-002..COMM-011` as **post-Q30 citation/research references only**. They do not inherit the original 60-source owner permission snapshot and do not authorize production coefficients.

Canonical metadata: `../../source_map/BROTHERHOOD_SOURCE_MAP_v004.json`.  
Claim boundaries: `../CLAIM_EVIDENCE_LEDGER.json` and `COMMUNICATION_SOURCE_TO_CLAIM_MATRIX.md`.
