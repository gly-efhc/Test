# Communication Compatibility — 13-Language Adaptation and Validation Plan

Status: **RESEARCH PLAN / 13-LOCALE CANON**

Exact scope: `sw, ru, en, uk, de, fr, es, it, tr, pl, da, hi, id`.

For every language-sensitive preference item, explanation and feedback survey:
1. construct definition frozen before translation;
2. native translation + independent linguistic QA;
3. cognitive/debrief testing for meaning and response-scale use;
4. cultural review of directness, disclosure, support, feedback, conflict and cadence wording;
5. measurement invariance and DIF where the construct is modeled across locales;
6. locale-specific calibration only when evidence requires it and version provenance is explicit;
7. explanation QA and privacy review.

## Critical anti-stereotype guard
`locale/country -> assumed directness, disclosure, support or response-latency preference` is forbidden. Cross-cultural research is used to design validation and detect transport failure, not to assign a person's communication profile from nationality/language.

## Digital-channel guard
Response-time expectations can depend on relationship stage, platform/channel, availability and culture. Face-to-face or romantic texting findings do not define one universal Brotherhood response-time threshold.
