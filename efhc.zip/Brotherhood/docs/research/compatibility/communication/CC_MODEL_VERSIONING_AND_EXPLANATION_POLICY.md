# CC Model Versioning and Explanation Policy

Status: **CANONICAL RESEARCH CONTRACT — CYCLE 0016**

Every result snapshot must identify:
- `model_id` and `model_version`;
- `input_schema_version`;
- person A/B input snapshot IDs;
- `construct_registry_version`;
- `pair_feature_registry_version`;
- `normalization_version`;
- role;
- locale/adaptation version;
- coverage/missingness state;
- computed score or `INSUFFICIENT_DATA`;
- timestamp.

Historical results are immutable provenance. A newer model may recalculate the same pair differently; it must not overwrite the score that was actually used at an earlier exposure.

## Safe explanation
Permitted examples:
- “Ваши предпочтения по темпу общения находятся в совместимом диапазоне.”
- “По указанным предпочтениям один человек чаще предлагает тот тип поддержки, который другой предпочитает получать.”

Forbidden explanation patterns:
- revealing the other user's raw private questionnaire/profile;
- “он игнорирует вас” based only on a preference score;
- moral labels;
- diagnosis/personality inference from CC;
- “81% probability that this friendship will succeed” without a separately validated probability model.
