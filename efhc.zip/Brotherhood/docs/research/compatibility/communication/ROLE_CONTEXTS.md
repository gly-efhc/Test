# Communication Compatibility — Role Context Research Contracts

Status: **RESEARCH HYPOTHESES / NO ROLE COEFFICIENTS PRODUCTION-ACTIVE**

| Role | Candidate CC questions | Must stay outside CC | Outcome examples |
|---|---|---|---|
| `friend` | cadence tolerance, disclosure pacing, support/responsiveness expectations, repair preferences | friendship opportunity, Trust, values/interests | reciprocal contact, comfort, 30/90/180/365 persistence |
| `business_partner` | feedback directness, conflict engagement/repair, cadence boundaries | competence, execution reliability, ownership terms | communication satisfaction, repair, partnership continuation |
| `worker_team` | feedback/problem-solving preferences, communication coordination expectations | job skills, performance, team climate as personality | coordination satisfaction, team-process outcomes |
| `mentor` | directional feedback/support fit, cadence and autonomy boundaries | mentor expertise/experience | mentoring continuity, satisfaction, goal/process ratings |
| `project_partner` | conflict/repair, feedback and coordination preferences | project competence, actual delivery reliability | project continuation, communication/repair outcomes |
| `activity_partner` | contact frequency/modality and directness preferences | geography, schedules and activity interests | joint-activity continuation, coordination satisfaction |

`mentor` may require ordered A→B and B→A modelling. Team-level research may not be converted automatically into pair coefficients.
