# Investor Demo — Research & Product Parity Specification

Status: **ACTIVE DOCUMENTED REQUIREMENT**.

## Owner principle
Standalone HTML demo is not a simplified prototype. It is a release-parity simulation surface for investors and product development.

## Required parity classes
- full navigation/routes;
- full product sections;
- full compatibility metric registry;
- role contexts;
- metric checkboxes and individual 0..100 scores;
- simple arithmetic overall of selected metrics;
- QF/TR/DC separate;
- full assessment flows using release-equivalent test mechanics;
- backend route/state simulation;
- database/table-state simulation required by the demo contract;
- chat/community/profile/search state transitions;
- model/evidence badges;
- error/loading/empty/offline states;
- persistence/reset/catch-up where applicable.

## Prohibition
No investor-facing demo may substitute six trivial questions, hardcoded compatibility outcomes or fake lightweight endpoints for existing release mechanics and still be called `full demo`.

## Scientific honesty
A full technical simulation may show `HYPOTHESIS/PILOT` scores, but UI must not imply a scientific validation state that the research registry does not support.
