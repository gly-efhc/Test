# Owner Source Use Authorization — 60-Source Scientific Registry

Status: **OWNER_CONFIRMED / COMMERCIAL RELEASE AUTHORIZED**  
Recorded: `2026-08-10`  
Supersedes rights-context wording from Q29/cycle 0006 where it depended on `NON_COMMERCIAL` status.  
Applies to: exactly the **60 source IDs** present in `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json` at cycle-0005 completion.

## Owner statement
The project owner explicitly states that official permission has been obtained for use of all 60 active-registry sources in Brotherhood **including commercial release/commercial use**.

Brotherhood is currently characterized by the owner primarily as a **social product**. Whether the present distribution is monetized is not a permission gate for this 60-source pack because the granted permission scope already includes commercial release.

## Project authorization state
- `project_use_authorization = OWNER_CONFIRMED_COMMERCIAL_RELEASE_PERMISSION`
- `commercial_release_scope = AUTHORIZED`
- `current_product_positioning = SOCIAL_PRODUCT`
- `underlying_permission_correspondence_in_archive = false`

The archive records the owner's explicit instruction as project truth. It does not claim an independent audit of the third-party correspondence because the permission letters/contracts themselves are not stored in this archive.

## Governance consequence
Old project flags such as `REQUIRES_PERMISSION`, `RIGHTS_UNKNOWN`, `NON_COMMERCIAL_ONLY`, or a warning that commercial release is blocked must not block these exact 60 sources merely because of use-right uncertainty. Public/source-specific terms remain provenance/compliance metadata, while the Brotherhood-specific permission gate is satisfied for commercial release according to the owner.

## Independent axes that remain unchanged
Commercial permission does **not** prove:
- scientific validity;
- construct validity;
- reliability;
- equivalence of a translation/adaptation;
- validity of Brotherhood visual `stimulus→trait` mappings;
- validity of a role-specific compatibility model;
- production-scoring eligibility.

Those claims remain governed by `EVIDENCE_AND_CLAIM_POLICY.md`, validation protocols and owner/release approval.

## Future sources
This authorization does not automatically cover source IDs added after the current 60-source snapshot.
