# IC Role Contexts

Status: **RESEARCH ROLE CONTRACT**

| Role | Interest evidence that may matter | Boundary |
|---|---|---|
| friend | hobby/social/activity overlap; joint readiness | not friendship probability |
| activity_partner | activity interest + joint readiness | schedule/geography remain Lifestyle |
| business_partner | professional/vocational orientation + selected shared interests | skills/experience remain Quality Fit |
| project_partner | project-domain/professional interests | execution competence remains QF/outcome |
| worker_team | vocational interests/context | person-job skill fit remains QF |
| mentor | shared topic/domain interests | expertise and mentoring need-fit remain QF |

Role-specific internal IC parameters are candidates, not automatic translations of literature effect sizes.
