# Interest Taxonomy Specification

Status: **RESEARCH TAXONOMY V1**

## Hierarchy
`domain → category → canonical interest_id → optional locale label`.

Canonical IDs are language-independent. The 13 UI languages translate labels/descriptions but do not create different taxonomy concepts.

Domains:
- `SOCIAL_HOBBY`
- `ACTIVITY`
- `PROFESSIONAL_VOCATIONAL`

## User-profile dimensions per interest
- `affinity` — how much the person likes/is interested;
- `engagement` — actual current participation frequency where meaningful;
- `importance` — priority/identity relevance as explicitly stated;
- `joint_readiness` — willingness to do this with another person;
- `freshness` — when confirmed/updated;
- `visibility` — public/match-only/private;
- `role_scope` — optional context.

These dimensions are not interchangeable. Liking football, playing weekly, and wanting a football partner are three different facts.

## Prohibited shortcuts
Do not infer competence from interest. Do not infer hidden personality from a hobby without a separately validated research model. Do not convert category popularity to pair compatibility.

## Vocabulary evolution
Interest taxonomy is versioned. Merges/splits preserve mapping provenance so historical IC snapshots remain reproducible.
