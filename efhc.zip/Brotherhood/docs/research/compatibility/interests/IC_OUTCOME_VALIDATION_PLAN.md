# IC Outcome Validation Plan

Status: **REQUIRES_DATA / Cycle 0014**

## Core design
Join the exact historical IC snapshot at exposure time to later role-aware outcomes through `docs/research/outcomes/`.

## Candidate primary questions
- Does IC add information about reciprocal interaction/relationship continuity beyond exposure opportunity and basic context?
- Does explicit joint-readiness improve activity-partner outcomes over tag overlap alone?
- For work/business roles, does vocational-interest congruence add value beyond hobby overlap while keeping competence in Quality Fit?

## Baselines
- null/base-rate by role and observation window;
- simple common-tag count (expected weak baseline only);
- transparent IC-R0;
- later regularized/nonlinear challengers.

## Causal controls
Rank/exposure/recommendation policy, prior acquaintance, geography/availability, search intent, activity opportunity and cohort/time must be considered. `unseen` is not a negative pair.

## Anti-leakage
No post-exposure action/status/outcome can enter the feature snapshot used to predict that same later outcome.

## 13 locales
All language-sensitive inputs/outcome surveys follow `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`. Pooling across locales requires evidence; otherwise estimate/report separately.

## Promotion
Locked holdout/external replication where feasible + fairness/privacy/explanation review + owner/release approval. No automatic mutation.
