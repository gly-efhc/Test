# Web Research Evidence Ledger — Cycle 0014

Status: **VERIFIED WEB RESEARCH TRACE — 2026-08-10**

## Interest science
- `INTEREST-005` Selfhout et al. (2009), DOI `10.1016/j.adolescence.2007.11.004`, PMID `18164756`: one-year longitudinal study of early-adolescent friendship formation/stability and music-preference similarity. Use: domain-specific evidence that shared preferences can relate to friend selection; not a universal adult friendship coefficient.
- `INTEREST-006` Schaefer et al. (2011), DOI `10.1037/a0024091`, PMID `21639618`: extracurricular co-participation and friendship network formation in adolescents. Use: shared activity/opportunity matters and must not be confused with latent compatibility.
- `INTEREST-007` O*NET Interest Profiler official/technical manual: vocational interests represented via RIASEC; official materials document scoring/reliability/validity and occupational linkage. Use: vocational-interest reference architecture; no automatic embedding rights assumed for this post-Q30 reference.
- `INTEREST-008` Low et al. (2005), DOI `10.1037/0033-2909.131.5.713`, PMID `16187855`: meta-analysis of vocational-interest stability from adolescence to adulthood. Use: interests can be stable yet developmental; store freshness/version rather than assume lifetime immutability.

## Research/recommender methodology
- `RESEARCH-001` Schnabel et al. (2016), PMLR 48: recommendation/training data are subject to selection bias from users and the recommender; causal/IPW methods are studied for debiasing.
- `RESEARCH-002` Mansoury et al. (2020), DOI `10.1145/3340531.3412152`: simulation evidence that iterative recommender feedback can amplify popularity bias and reduce aggregate diversity/homogenize experience.
- `RESEARCH-003` Fabbri et al. (2022), DOI `10.1609/icwsm.v16i1.19284`: people-recommender feedback simulations show long-term exposure inequality/rich-get-richer dynamics.
- `RESEARCH-004` Chaney et al. (2018), DOI `10.1145/3240323.3240370`: simulation evidence of algorithmic confounding when learning from behavior generated under recommendations.
- `RESEARCH-005` Krauth, Wang & Jordan, DOI `10.1145/3728372` (ACM ToRS publication record 2025): causal-adjustment method for recommender feedback loops; use as methodological candidate, not automatic Brotherhood implementation.

All nine are **post-Q30 research/citation references** and do not inherit the original owner-authorized 60-source commercial-release snapshot.
