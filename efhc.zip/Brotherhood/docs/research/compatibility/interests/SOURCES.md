# Interests Compatibility — SOURCES

Status: **ACTIVE SOURCE MAP — Cycle 0014**

Primary interest/work IDs: `INTEREST-001..008, FIT-001..003`.
Research-feedback methodology IDs: `RESEARCH-001..005`.

Canonical metadata/URLs/evidence classes: `../../source_map/BROTHERHOOD_SOURCE_MAP_v004.json`.
Claim boundaries: `../SOURCE_TO_CLAIM_MATRIX.md` and `../../outcomes/`.

External evidence supports constructs, boundary conditions and research methods; it does not import effect sizes as Brotherhood production coefficients. The original 60-source commercial-permission snapshot remains separate from post-Q30 citation/research additions.
