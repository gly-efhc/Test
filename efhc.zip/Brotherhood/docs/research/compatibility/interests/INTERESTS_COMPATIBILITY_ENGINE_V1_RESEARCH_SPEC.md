# Interests Compatibility Engine v1 — Research Spec

Status: **CANDIDATE RESEARCH ENGINE / CYCLE 0014 / NOT PRODUCTION-ACTIVE**
Metric: `IC`

## 1. Purpose
Return an independent exact `0..100%` Interests Compatibility score for a pair under a declared active IC algorithm version and role context. `IC` measures compatibility by interests/preferences; it does not estimate personality, competence, Trust or success probability.

## 2. Interest domains
Three canonical families remain distinguishable:
1. **social/hobby interests** — topics, culture, creative/leisure interests;
2. **activity interests** — things a person wants to do, including explicit willingness to do them jointly;
3. **professional/vocational interests** — work/activity preference structure; RIASEC-like research may be used here.

## 3. Input model
Each taxonomy item may store, under user control:
- canonical `interest_id`;
- interest strength/affinity `0..1`;
- engagement/frequency `0..1` where meaningful;
- importance/priority `0..1`;
- joint-participation willingness `0..1` where meaningful;
- source (`explicit_profile`, `assessment`, separately consented research signal);
- freshness timestamp/version;
- visibility/privacy;
- optional role scope.

Missing/withheld values are not zeros.

## 4. Boundary rules
- skills/experience/competence → Quality Fit/public resume, not IC;
- psychological traits inferred from interests → forbidden by default;
- Communication/Values/Lifestyle remain independent metrics;
- number of common tags ≠ probability of friendship;
- popularity of an interest does not make a user more compatible.

## 5. Transparent research baseline IC-R0
For explicit sparse interest vectors `a_i,b_i∈[0,1]` and preregistered taxonomy weights `w_i` (default research baseline `w_i=1` unless a non-person-specific taxonomy normalization is justified):

`J = Σ w_i·min(a_i,b_i) / Σ w_i·max(a_i,b_i)`.

Candidate internal components:
- `HOBBY_OVERLAP` — weighted Jaccard on social/hobby interests;
- `ACTIVITY_OVERLAP` — weighted Jaccard on activity interests;
- `JOINT_READINESS` — pairwise agreement/minimum over explicitly shared activities both are willing to do together;
- `VOCATIONAL_CONGRUENCE` — separately researched similarity/congruence on vocational-interest profile for work/business roles.

For research baseline `IC-R0`, available component scores are combined by **unweighted arithmetic mean** to avoid inventing hidden literature-derived coefficients:
`IC_R0 = 100 × mean(available_component_scores)`.

This is a transparent baseline to beat, not a claim that equal internal weights are psychologically optimal. Future role-specific internal coefficients are allowed only after outcome validation/versioning. Cross-metric weights remain forbidden.

## 6. Role context
`friend`: hobbies/activity and joint participation are primary candidates; vocational profile should not dominate.
`activity_partner`: activity match + joint readiness are primary candidates.
`business_partner/project_partner/worker_team`: professional/vocational interests can become relevant, but competence remains Quality Fit.
`mentor`: vocational/topic interests may support shared domain orientation but mentoring expertise/need fit remains Quality Fit.

## 7. Coverage/freshness
Coverage is separate from IC. Old interest declarations can be down-statused as stale/unknown rather than silently treated as current. Exact freshness policy is versioned.

## 8. Q34 score semantics
When a future IC version is owner-approved for production, its displayed `0..100%` is the exact computation of that algorithm version/input snapshot. Later improved versions may calculate a different exact score. IC is not automatically `P(friendship success)`.

## 9. Research feedback integration
IC validation joins historical pre-exposure IC snapshots to later voluntary outcomes through the canonical research platform. Exposure/rank/policy are required controls because Brotherhood influences which pairs ever get an opportunity to interact.

## 10. Promotion gate
No IC-R0 or challenger becomes production simply because it correlates with clicks/statuses. Required: causal/leakage review, longitudinal criterion definition, baseline comparison, locked holdout, 13-locale review, privacy/fairness review, independent verification and owner/release approval.
