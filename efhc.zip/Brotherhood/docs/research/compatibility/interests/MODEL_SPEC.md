# Interests Compatibility — MODEL SPEC

Status: **CANDIDATE MODEL SPEC / Cycle 0014 / REQUIRES_VALIDATION**
Metric ID: `IC`

Canonical engine spec: `INTERESTS_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.
Baseline algorithm: `IC_BASELINE_ALGORITHM.md`.
Machine inputs/features: `INTEREST_INPUT_SCHEMA.json`, `INTEREST_PAIR_FEATURE_REGISTRY.json`.

Input: pair A/B + role context + versioned permitted interest inputs. Output: independent exact `score_0_100` under the active approved version, coverage, freshness and provenance.

Cycle 0014 defines IC-R0 as a **research baseline only**. No coefficient in this file is a current production promotion. Competence remains Quality Fit; psychology is not inferred from interest tags; missing data are not zeros.

Validation uses historical pre-exposure score snapshots and later voluntary outcomes with exposure-policy controls. `IC` is not automatically a friendship/project success probability.
