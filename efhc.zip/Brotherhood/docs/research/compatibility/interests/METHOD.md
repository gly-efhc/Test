# Interests Compatibility — METHOD

Status: **ACTIVE RESEARCH METHOD / Cycle 0014**
Metric ID: `IC`

Canonical detailed spec: `INTERESTS_COMPATIBILITY_ENGINE_V1_RESEARCH_SPEC.md`.

## Purpose
Compute one independent versioned `0..100` Interests Compatibility result for a pair and role context. IC is not Quality Fit, Trust, Psychology or Overall.

## Constructs
`social/hobby`, `activity`, `professional/vocational`, plus explicit intensity/priority/current engagement and joint-participation readiness where meaningful.

## Transparent baseline
Cycle 0014 freezes `IC-R0` as a benchmark: domain-level weighted Jaccard / explicit joint-readiness / optional vocational-profile component, normalized independently and combined by the arithmetic mean of available components. Equal internal baseline weighting is a transparency choice, **not** asserted to be scientifically optimal.

## Missingness/coverage/freshness
Missing/withheld data are not zero. Coverage and freshness are separate diagnostics. Interests are versioned/time-sensitive.

## Research improvement
Historical exact IC snapshots may be joined to later voluntary role-aware outcomes through `../../outcomes/`; rank/exposure/policy provenance is mandatory. Outcomes never auto-mutate production.

## 13 locales
`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`; canonical taxonomy IDs are language-independent.
