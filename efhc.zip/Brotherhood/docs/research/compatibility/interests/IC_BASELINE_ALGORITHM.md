# IC Baseline Algorithm — IC-R0

Status: **TRANSPARENT RESEARCH BASELINE / NOT PRODUCTION-ACTIVE**

## Component similarity
For a domain with explicit vectors `a,b`:
`weighted_jaccard(a,b)=Σ w_i min(a_i,b_i) / Σ w_i max(a_i,b_i)`.

Baseline taxonomy weights are equal (`w_i=1`) unless a non-person-specific normalization is preregistered. Equal weight is chosen for transparency, not claimed as scientifically optimal.

## Joint readiness
For an activity shared by both users, a conservative candidate is `min(joint_readiness_A, joint_readiness_B)`. Aggregate only across eligible shared activity items. This is an explicit pair-preference construct, not personality inference.

## Vocational component
Represent vocational interests as a six-dimensional RIASEC-like profile only when valid inputs exist and role context makes it relevant. Candidate comparison may benchmark cosine/profile correlation/distance-derived mappings; no single transform is production canon in 0014.

## Research aggregate
Normalize each available component to `[0,1]`, then:
`IC_R0 = 100 × arithmetic_mean(available_components)`.

Missing components are omitted and reduce separate coverage. They are not imputed as 0.

## Challenge requirement
Future models must compare against IC-R0. Added complexity is accepted only if it improves preregistered longitudinal outcomes/robustness on locked evaluation while preserving privacy, explainability and fairness.
