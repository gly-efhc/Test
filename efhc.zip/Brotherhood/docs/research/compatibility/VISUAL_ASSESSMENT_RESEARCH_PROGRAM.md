# Brotherhood Visual Assessment Research Program

Status: **ACTIVE RESEARCH DESIGN; cycle-0007 expanded master program is `../visual_tests/VISUAL_ASSESSMENT_RESEARCH_PROGRAM.md`; current 100×6 bank remains protected until owner-authorized implementation revision**.

## 1. Objective
Develop indirect, enjoyable visual/behavioral assessments that reduce obvious self-presentation cues while still producing psychometrically defensible latent measurements.

Indirectness is a design property, **not validity evidence**. Each stimulus must earn its relation to a construct empirically.

## 2. Core experimental unit
```text
stimulus_series
  -> 6 tasks
  -> each task has versioned visual options
  -> randomized/counterbalanced option position
  -> response + latency + device/render metadata
  -> no user-facing construct label during response
```

The current canonical product size is 100 series × 6 tasks. Research may mark individual stimuli `KEEP/REWORK/REJECT`, but protected production assets are changed only by an explicit owner-authorized implementation cycle.

## 3. Visual paradigm families to research
These are **hypothesis families**, not trait truths:
- spatial organization / order;
- ambiguity preference / exploration;
- allocation and prioritization scenes;
- planning/sequencing choices;
- social-distance/coordination scenes;
- cooperation/resource dilemmas represented visually;
- novelty vs familiarity choices;
- risk/uncertainty scenes;
- attention/salience patterns;
- aesthetic preference controls used primarily to detect confounds.

Each paradigm must have a construct rationale and competing explanations.

## 4. Stimulus design requirements
Every item must minimize accidental differences unrelated to the intended hypothesis:
- equalized visual salience;
- comparable brightness/contrast/color load;
- comparable semantic complexity;
- no obviously “good” or prestigious answer;
- no textual moral labels;
- no gender/race/class stereotype cue unless explicitly studied and ethically justified;
- accessible on 320–430px mobile widths;
- color-blind/low-vision review where relevant;
- fixed asset provenance/license.

## 5. Position and order control
- randomize option positions using stored permutation;
- balance option exposure across participants;
- randomize task order only where measurement model permits;
- preserve anchor items for longitudinal comparability;
- log actual rendered order, not only canonical option IDs.

## 6. Response data
Minimum research event:
- anonymous/research participant id;
- assessment/model version;
- stimulus_id + asset_version;
- option_id;
- rendered_position;
- response latency;
- locale;
- viewport/device class;
- session/order index;
- retake id;
- consent cohort;
- quality flags.

Latency is diagnostic/calibration evidence until specifically validated as trait information.

## 7. Reference calibration
Research participants complete selected reference instruments in separated sessions where possible. Reference measures are chosen by construct and licensing status; IPIP is preferred when suitable because of its public-domain pool. HEXACO can be a reference candidate subject to use permissions.

## 8. Item/stimulus evaluation
For every visual task evaluate:
- option entropy;
- floor/ceiling and dominant-choice rate;
- position bias;
- device/locale effects;
- response-time anomalies;
- test-retest behavior;
- association with target reference construct;
- unwanted association with unrelated constructs;
- differential item functioning / subgroup instability;
- incremental information over other stimuli.

## 9. Item disposition
`KEEP` — useful, stable evidence.  
`REWORK` — promising construct signal but confounded/weak.  
`CONTROL` — useful for bias/attention but not trait scoring.  
`REJECT` — insufficient or misleading evidence.  
`RESEARCH_ONLY` — not production qualified.

## 10. Scoring candidates
Compare classical composite scoring, regression/regularized models, IRT/Thurstonian forced-choice approaches and other interpretable models. Model complexity must be justified by out-of-sample benefit.

## 11. Anti-overfitting
- participant-level train/validation/test separation;
- no option/stimulus leakage between splits where inappropriate;
- locked final holdout;
- preregistered or frozen analysis plan for decisive validation;
- versioned feature-generation pipeline.

## 12. User result layer
User-facing result remains useful and non-stigmatizing, but positivity must not become generic Barnum text. Explanations should reference stable measured tendencies without exposing private raw coordinates to other users.

## 13. Release gate
No visual→trait mapping becomes `PRODUCTION_QUALIFIED` solely because it is aesthetically convincing. Required measurement and intended-use validation are defined in `PSYCHOMETRIC_VALIDATION_PROTOCOL.md`.
