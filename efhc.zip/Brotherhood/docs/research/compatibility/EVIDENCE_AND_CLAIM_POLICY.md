# Evidence and Claim Policy — Brotherhood Compatibility Research

Status: ACTIVE RESEARCH NORM

## 1. Главный принцип
Brotherhood — метасистема сопоставления людей. Она может содержать научно-эмпирические, типологические и альтернативные модели одновременно, но обязана разделять **тип доказательств** и **пользовательскую интерпретацию**.

## 2. Статусы каждой metric version
- `HYPOTHESIS` — логически/теоретически мотивированная, но не калиброванная формула.
- `PILOT_CALIBRATED` — прошла технический пилот и предварительную калибровку; недостаточно для сильных claims.
- `EMPIRICALLY_SUPPORTED` — есть reproducible internal evidence по reliability/validity для заявленного use.
- `OUTCOME_SUPPORTED` — score показал predictive/criterion связь с реальными Brotherhood outcomes на holdout/cohort data.
- `EXTERNAL_REPLICATED` — результат воспроизведён независимой внешней командой/выборкой.
- `TRADITIONAL_ALTERNATIVE` — формализованная традиционная система без психометрического claim.
- `TYPOLOGICAL_EXPERIMENTAL` — типология с ограниченным/смешанным научным основанием.

## 3. Нельзя смешивать
1. Психологическая compatibility ≠ нумерология ≠ астрология.
2. Quality Fit ≠ Compatibility.
3. Trust ≠ Compatibility.
4. Data Coverage/measurement confidence ≠ Compatibility.
5. Overall convenience average ≠ probability of friendship/business success.

## 4. Claim language
Разрешено: `Индекс психологической совместимости Brotherhood: 82%`.
Запрещено до доказательств: `Вероятность, что вы станете друзьями, 82%`.

## 5. Evidence ledger для любой формулы
Каждая формула хранит: construct definition, intended use, source claims, population, language, model version, training set, validation set, reliability, structural/convergent/discriminant/criterion evidence, fairness checks, limitations, rollback version.

## 6. Evidence-class crosswalk
Owner shorthand `A/B/C/D/HYPOTHESIS` is reconciled in `EVIDENCE_CLASSIFICATION.md`. Existing detailed registry classes remain canonical. `HYPOTHESIS` is a claim/model status rather than a source class.

## 7. Production influence gate
Even an A-class external source does not authorize a Brotherhood-specific coefficient. Production scoring requires intended-use validation, versioning, human/scientific review and owner/release approval.

## Q33/Q34 — model humility + exact algorithmic score
Evidence can strengthen or falsify a Brotherhood psychological model and justify a new version. The model must not be described internally as immutable person essence. **However, the approved production algorithm returns an exact `0..100%` result for its model version and input snapshot, and the product may present that value directly.** Research status must not be injected as a repetitive user-facing disclaimer. `100% probability of relationship success` remains a separate claim that requires its own probability calibration.

## Q36 — unified evidence-corpus synthesis
All registered scientific sources are inputs to Brotherhood's own research synthesis. Source citations/IDs exist for provenance and auditability, not as an end in themselves. Evidence may shape constructs, measurement design, causal guards, challenger hypotheses and validation plans across the corpus. The original 60-source commercial-permission snapshot vs post-Q30 sources remains a **rights/content-use metadata axis**, not a scientific-synthesis barrier. No source automatically supplies a production coefficient, and no post-Q30 copyrighted content/asset is embedded merely because its scientific result informs the design.

