# Friendship Compatibility — Outcome Model

Status: **CYCLE 0010 ACTIVE RESEARCH OUTCOME SPECIFICATION / NOT PRODUCTION-ACTIVE**

Detailed master outcome package: `../roles/friendship/INDEX.md`.

## Outcome levels
### O0 — Eligible exposure/opportunity
Candidate was actually shown; contact was technically and practically possible. This is denominator/control evidence, not success.

### O1 — Interest/initiation
Profile/compatibility opened or direct contact initiated.

### O2 — Reciprocity
The candidate had a real opportunity to respond and reciprocal interaction occurred.

### O3 — Early continuity
Mutual interaction continues across a preregistered early window.

### O4 — Dyadic friendship quality
Opt-in evaluation of usefulness, comfort, understanding, mutuality, responsiveness/mattering and wish to continue. Multi-informant evidence is preferred.

### O5 — Persistence
30/90/180-day continuation under explicit censoring rules.

### O6 — Shared real-world value
Optional self-report of shared activity, meeting, mutual help/collaboration or “would choose again”.

### O7 — Conflict/repair or dissolution
Opt-in repair outcome or relationship-ending status/reason where known.

## Primary-outcome policy
No universal composite is frozen. A future pilot preregisters primary endpoint(s) before inspecting outcome data. Cycle 0010 recommends experimentally comparing a mutual behavioral-continuity endpoint with a dyadic self-reported quality endpoint, rather than optimizing raw engagement.

## Negative-label protection
No reply/noncontinuation is not a valid negative when exposure, opportunity, account activity, moderation/privacy state or observation time are insufficient. Unknown dissolution reason remains unknown.

## Causal controls
Exposure/rank, prior acquaintance, network position, geography/timezone, language, availability, platform activity, shared interests/opportunity, SearchIntent, calendar cohort and censoring are tracked as potential confounds rather than silently converted into compatibility.

## Privacy
No raw private message content is required. Event metadata and voluntary dyadic surveys are the default evidence layer.
