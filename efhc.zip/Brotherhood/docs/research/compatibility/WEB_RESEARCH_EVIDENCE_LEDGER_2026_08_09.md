# Web Research Evidence Ledger — 2026-08-09

Status: **CYCLE 0004 VERIFIED-BY-WEB OBSERVATIONS**

## Scientific / standards
Verified current source pages/search metadata for: AERA/APA/NCME Standards; IPIP Reliability/Validity; HEXACO official inventory/use policy; Hilliard et al. image-based forced-choice studies (PMID 35225927 / 35780596); Cao & Drasgow forced-choice meta-analysis (PMID 31070382); Speer et al. meta-analysis (PMID 37326537); friendship review/longitudinal sources; Schwartz values paper; vocational/person-environment fit sources; team-trust meta-analyses; Enneagram systematic review; McCrae & Costa MBTI reinterpretation; Carlson astrology test; Lilienfeld/Wood/Garb projective-techniques review; Freud Museum historical material; official Diia Android repository.

Web access is a source-identity/claim check, not a substitute for full-text methodological extraction. Where only abstract/search metadata was available, no unobserved effect size or methodological detail is asserted.

## Repository provenance
- `Mentalys-App/mentalys-app-android`: public current resolved repository fetched; MIT shown on repository page.
- `VedAstro/VedAstro`: public exact repository fetched.
- `Alovoa/alovoa`: public exact repository fetched.
- Eleven other original user URLs from v002 returned direct 404 during this audit. Their v002 `candidate/unresolved` status is **not upgraded**; 404 is not interpreted as proof of deletion.
- `diia-open-source/android-diia`: official public repository fetched; modular source structure and EUPL license visible.

Exact registry URLs live in JSON/Markdown source registries; repository/provenance continuity is consolidated in `BROTHERHOOD_SOURCE_MAP_v004.json`; v003 remains historical provenance.
