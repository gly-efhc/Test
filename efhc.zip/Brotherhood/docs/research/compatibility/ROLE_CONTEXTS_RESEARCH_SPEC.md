# Role Contexts — Friend / Business / Worker / Mentor / Project

Status: **ACTIVE ROLE ARCHITECTURE**.

## Principle
Metric is *how* two profiles are compared; role context is *for what relationship*. The same metric can have different pair logic by context.

## FRIEND
Outcome focus: reciprocal contact, friendship quality, support, autonomy, shared activities, persistence, conflict repair.

## BUSINESS_PARTNER
Outcome focus: goal/values agreement, complementary competences, reliable execution, decision/risk alignment, conflict resolution, continuation of cooperation. Financial success cannot be attributed to personality score without controlling external factors.

## WORKER / TEAM_MEMBER
Separate person-job Quality Fit from interpersonal/team compatibility. Outcomes may include retention, task performance, team satisfaction and supervisor/peer ratings subject to employment fairness and legal review.

## MENTOR
Focus: domain relevance, communication expectations, autonomy support, learning orientation, reliability and sustained mentoring relationship.

## PROJECT_PARTNER
Focus: domain interest, availability, execution style, decision process, commitment duration, conflict/repair and complementary skills.

## MUTUAL_AID / ACTIVITY_PARTNER
Focus: practical availability, shared goal/activity, trust/verification, communication and geography more than deep personality.

## Rule matrix
Every metric specification must state which role contexts are supported. Unsupported context returns `NOT_VALIDATED_FOR_CONTEXT`, not a generic reused score.
