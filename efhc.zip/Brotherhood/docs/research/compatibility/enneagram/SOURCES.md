# Enneagram Compatibility — SOURCES

Status: **ACTIVE SOURCE MAP**

Primary registry IDs: `ENNEA-001.`.

Canonical metadata/URLs/evidence classes live in `../../source_map/BROTHERHOOD_SOURCE_MAP_v004.json`; claim boundaries live in `../SOURCE_TO_CLAIM_MATRIX.md`. This file intentionally does not duplicate bibliography metadata.

Evidence rule: external evidence may support constructs/methods/limitations but does not directly authorize Brotherhood production coefficients. Metric-specific relation functions remain `HYPOTHESIS` until validation.
