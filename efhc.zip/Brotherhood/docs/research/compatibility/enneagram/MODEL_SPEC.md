# Enneagram Compatibility — MODEL SPEC

Status: **CANDIDATE MODEL SPEC / REQUIRES_VALIDATION**
Metric ID: `EN`

## Contract
Input: pair A/B + role context + permitted versioned metric inputs. Output: independent `score 0..100`, coverage, freshness, evidence/model/method versions and safe explanation metadata.

## Construct layer
a specifically versioned Enneagram tradition/instrument and its claimed type relations; no psychometric substitution.

## Pair-feature layer
Independent deterministic/typological compatibility model with transparent versioned matrix/rules. Does not feed PC automatically.

## Missingness
Missing/withheld inputs are not zeros. Engine returns reduced coverage or `INSUFFICIENT_DATA` according to a predeclared versioned gate.

## Calibration
Candidate transformations and coefficients are fit only on research data separated from locked validation/holdout. Model selection must compare transparent baselines.

## Role context
Role-specific parameters/models are allowed inside this metric when supported; they do not create cross-metric weights.

## Status
No coefficient in this document is asserted as current validated production truth.
