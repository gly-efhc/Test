# Enneagram Compatibility — METHOD

Status: **RESEARCH METHOD / TYPOLOGICAL_EXPERIMENTAL / REQUIRES_VALIDATION**
Metric ID: `EN`

## Purpose
Compute one independent Compatibility result for a specific pair and role context. This method is not Quality Fit, Trust or Overall.

## Constructs
a specifically versioned Enneagram tradition/instrument and its claimed type relations; no psychometric substitution.

## Inputs
only data collected under the selected Enneagram method or explicit user-provided type where policy permits.

## Candidate scoring model
Independent deterministic/typological compatibility model with transparent versioned matrix/rules. Does not feed PC automatically.

## Normalization
Final public service result is constrained to `0..100` and must preserve a versioned interpretation. Normalization parameters are learned/fixed only under the validation/versioning plan; score is not a probability unless explicitly calibrated as one.

## Minimum data / coverage
Valid type/membership input under the chosen method.

## Privacy/explanation
Use only permitted inputs. Explanation describes pair interaction at a safe abstraction level and never reveals the other person's raw private latent profile.

## Limitations
Systematic-review evidence is mixed; no claim of validated latent psychometrics without additional evidence.

## Outcome calibration
Outcome data may evaluate predictive/criterion usefulness but cannot automatically mutate production.
