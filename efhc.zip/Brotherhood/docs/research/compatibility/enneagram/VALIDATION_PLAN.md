# Enneagram Compatibility — VALIDATION PLAN

Status: **REQUIRES_VALIDATION**

## Gates
1. Construct/intended-use review.
2. Input measurement reliability/quality where applicable.
3. Test-retest / temporal stability or preference freshness analysis.
4. Convergent/discriminant evidence where applicable.
5. Dyadic/criterion/outcome validation by role.
6. Baseline comparison and incremental validity.
7. 13-locale equivalence (`sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`) where measurement is language-sensitive.
8. Subgroup/fairness/adverse-impact analysis.
9. Locked holdout/cross-validation; no leakage from post-match outcomes into pre-match features.
10. Model/version/explanation/privacy review and owner/release approval.

## Failure rule
Failed/ambiguous gates keep the model `HYPOTHESIS`/`PILOT_CALIBRATED`; they do not justify automatic coefficient adjustment.

## Metric-specific limitation
Systematic-review evidence is mixed; no claim of validated latent psychometrics without additional evidence.
