# Statistical Analysis Plan — Compatibility Research

Status: DESIGN TEMPLATE; each study requires a preregistered/adapted instance.

## Data splits
- development/training;
- validation/model selection;
- locked final holdout;
- later temporal or external replication cohort.

## Measurement analyses
Depending on format: factor analysis/CFA, IRT/Thurstonian forced-choice models, reliability/test-retest, item information, local dependence, DIF and measurement invariance.

## Pair/outcome analyses
Use dyadic-aware methods where both members contribute outcomes; compare simple baselines to candidate models. Candidate methods include multilevel models, APIM-style dyadic models, survival/persistence models and calibrated classification/regression where appropriate.

## Required baselines
- random ranking;
- demographic/filter-only ranking;
- simple interest overlap;
- simple absolute personality distance;
- current production/legacy algorithm when ethically/testably available.

A new model is promoted only if it improves relevant criteria without unacceptable fairness/privacy tradeoffs.

## Metrics
Do not optimize a single accuracy number. Track discrimination, calibration, confidence intervals, stability, subgroup performance, missingness, data coverage and user-level outcome utility.

## Multiple testing
Large stimulus banks create false-positive risk. Predefine construct families, correction/FDR strategy, locked holdout and replication. Exploratory effects must be labeled exploratory.

## Recalibration
Research may propose coefficient changes; production promotion is manual, versioned, reversible and accompanied by a model card.
