# Metric Engine Contract — Brotherhood

Status: **ACTIVE TARGET CONTRACT / DOCUMENTATION**  
Detailed predecessor retained: `COMPATIBILITY_METRIC_CONTRACT.md`.

## Input
- `subject_global_id`
- `candidate_global_id`
- `metric_id`
- `role_context`
- versioned permitted measurement inputs
- optional explicit preferences/constraints where metric methodology allows them
- `as_of` / freshness context

## Output
- `metric_id`
- `role_context`
- `score`: nullable decimal/int in `[0,100]`
- `result_status`: `AVAILABLE | INSUFFICIENT_DATA | NOT_APPLICABLE | MODEL_UNAVAILABLE`
- `model_version`
- `method_version`
- `evidence_status`
- `coverage`
- `data_freshness`
- `explanation_policy_version`
- public-safe explanation references

## Invariants
1. One engine computes one metric family; no hidden cross-metric weights.
2. Quality Fit/Trust/Coverage are not Compatibility metric IDs.
3. Missing data do not become zero.
4. Score does not imply probability unless a separately calibrated probability model explicitly says so.
5. Role-specific math is versioned within a metric.
6. Private latent inputs never leave the protected boundary through explanations.
7. Model history is immutable/auditable.

## Aggregator
`overall(selected metric results)` filters to selected `AVAILABLE` results and computes arithmetic mean. It returns the selected/available count and list of versions used. It does not use evidence class or confidence as hidden weights.

## Research status
Any coefficient not supported by Brotherhood validation is `HYPOTHESIS/REQUIRES_VALIDATION` and cannot be described as empirically established.
