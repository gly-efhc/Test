# Diia Android architecture review — cycle 0024

Status: `VERIFIED_PRIMARY_SOURCE / UX_ARCHITECTURE_DONOR_ONLY`

## Verified source

- Repository: `diia-open-source/android-diia`.
- Verified revision: `067c4dc19332c0fdd83b12db2274771494128a50`.
- Revision date: `2025-10-10`.
- Licence file at the verified revision: EUPL 1.2.
- Verification date for Brotherhood: `2026-08-11`.

## Files actually reviewed

1. `settings.gradle.kts` — confirms separation into application, reusable libraries and feature modules, including `ui_base`, `core`, `diia_storage`, `home`, `search`, `publicservice` and other feature boundaries.
2. `ui_base/.../HomeScreenTab.kt` — explicit Android `BackHandler`, reusable root shell and independent top/body/bottom containers.
3. `ui_base/.../ServiceScreen.kt` — explicit back action derived from navigation data, reusable toolbar/body/bottom composition and service-specific body container.
4. `publicservice/.../PublicServicesCategoriesComposeScreen.kt` — dedicated feature flow using the same shell/container principles.
5. `LICENSE.md` — EUPL 1.2 terms verified from the repository.

## What Brotherhood adopts

The source is used as an architecture/UX donor, not as a visual template:

- one screen / one primary task;
- stable reusable application and feature shells;
- feature isolation instead of monolithic pages;
- explicit Back behavior;
- top bar / body / bottom action separation;
- progressive disclosure: summary → detail → deeper detail;
- dedicated search/detail/service flows;
- reusable components and predictable navigation contracts.

## What Brotherhood does not copy

- Diia branding, colors, government visual identity or document metaphors;
- government/service data;
- backend/API semantics;
- source-code bodies or assets in cycle 0024.

## Cycle 0024 application

These principles are applied to the HTML-first recovery contract. The standalone simulator remains a Brotherhood product surface and follows:

`Backend → routes → Simulation Engine → routes → Frontend`.

The front end does not calculate fake product data locally. Compatibility, report history and stateful product responses are requested through the Simulation Engine, while the workbench exposes the same source-contract route/table coverage used by the backend mirror.

Visual acceptance remains an owner gate. No Compose mirror is authorized merely because this architecture reference was studied.
