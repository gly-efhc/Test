# Diia UI architecture reference — Brotherhood v0.5.29

Status: source-grounded research note. Diia is used only as an architecture/UX reference; no Diia code or data is copied into Brotherhood.

Observed reference files in `diia-open-source/android-diia`:

- `ui_base/.../HomeScreenTab.kt`: explicit `BackHandler`, stable Compose home root, and separated top/body/bottom containers.
- `ui_base/.../ServiceScreen.kt`: explicit Back action derived from toolbar navigation data and separated toolbar/body/bottom root containers.
- `home/.../HomeScreenComposeMapper.kt`: bottom tab bar is modeled as a reusable infrastructure organism rather than page-local ad hoc markup.

Applied Brotherhood principles:

1. Main five-tab navigation is root application-shell infrastructure, not content of the Home page.
2. Nested routes render inside the stable shell; Settings, Tests, Results, Chat and detail pages no longer remove the five-tab navigation.
3. Android system Back is explicit product navigation and remains backed by route/tab history.
4. Welcome Home stays low-density; specialized content belongs to specialized routes.
5. Demo architecture mirrors application architecture: state/data boundary → simulation/runtime state → frontend, instead of embedding unrelated state in each page renderer.

Not copied:

- Diia business data;
- visual branding;
- government/document flows;
- source code bodies;
- API contracts or backend semantics.

## Re-verification — cycle 0024 / 2026-08-11

The official repository was re-verified at revision `067c4dc19332c0fdd83b12db2274771494128a50` dated 2025-10-10. In addition to the previously recorded screen-shell observations, `settings.gradle.kts` confirms a modular split between reusable libraries and feature modules. Cycle 0024 therefore formalizes **feature isolation + reusable shell + explicit Back + top/body/bottom composition** as Brotherhood UX-architecture donor principles. Full evidence and the exact reviewed paths are recorded in `DIIA_UI_ARCHITECTURE_REVIEW_0024.md` and `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json` (`DIIA-UX-001`).
