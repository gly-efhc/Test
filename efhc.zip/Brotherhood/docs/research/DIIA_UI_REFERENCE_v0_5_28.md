# Diia Android UI/navigation reference — Brotherhood v0.5.28

Status: RESEARCH REFERENCE ONLY. No Diia code is copied into Brotherhood.

Primary repository: `diia-open-source/android-diia` (official Diia open-source Android repository, EUPL-1.2).

Observed reference files:
- `ui_base/.../infrastructure/HomeScreenTab.kt`: explicitly installs Compose `BackHandler` and sends a toolbar-navigation-back UI action; screen composition is separated into top bar, body and bottom containers.
- `ui_base/.../infrastructure/ServiceScreen.kt`: likewise handles Android Back explicitly and maps it to the configured navigation-panel back action; toolbar/body/bottom containers are separate.
- `login/.../ui/LoginF.kt`: navigation is event-driven rather than exposing every capability on one page.

Brotherhood application of the reference:
1. Android Back is made explicit instead of relying on Activity default exit behavior.
2. Home remains a low-density entry surface; secondary capabilities live behind dedicated routes/services.
3. Bottom navigation remains the stable primary domain switcher.
4. Detailed results receive a dedicated route rather than being scattered through the dashboard.

Brotherhood-specific branding, information architecture, product semantics, colors, components and source code remain independent.
