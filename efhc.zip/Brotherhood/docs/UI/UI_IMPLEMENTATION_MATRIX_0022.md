# UI Implementation Matrix — active recovery through cycle 0028

Cycle 0028 produces the Full HTML Acceptance Candidate after materializing seven scientific psychological test systems. `H=PASS` is not visual acceptance; only explicit owner review can set `VA=PASS`.

| Surface | Current factual state | Visual state | Next action |
|---|---|---|---|
| My Profile | route-backed digital social/professional resume; no self-Compatibility | VA_PENDING | owner review |
| People | `/v1/people` through SimulationEngine; 200-person dataset; search/role/filter/progressive loading | VA_PENDING | owner review |
| Candidate | person-first identity/professional/social presentation; compatibility/trust/further details below | VA_PENDING | owner review |
| Compatibility Details | Q28 PC/IC/VC/CC/LC/PT/EN/NU/AS + seven independent psychological-system compatibilities; Trust/Rating/Fit separate | VA_PENDING | owner review |
| Tests Home | 7 scientific systems v1 with plain-language summaries; technical source/calibration internals removed from respondent UX | VA_BLOCKED_STIMULUS_PROVENANCE | continue scientific item/stimulus filling |
| Test module | system-specific user explanation and progress; scientific trace remains in audit/methodology data, not normal respondent UI | VA_BLOCKED_STIMULUS_PROVENANCE | continue item-level provenance |
| Test execution | stable no-jump selection patch; current scene-library-v4 is GENERATED_PROTOTYPE, not scientific-source imagery | VA_BLOCKED_STIMULUS_PROVENANCE | replace active stimuli with original/licensed provenance-tracked assets |
| Test result | meaningful per-system result + coverage + strengths/growth; raw source/model internals excluded from normal UX | VA_BLOCKED_STIMULUS_PROVENANCE | finish scientific item bank, then owner review |
| Psychological Profile | seven system aggregates + coverage + model/calibration disclosure | VA_PENDING | owner review |
| Psychological Report/history | report v2: seven sections + summary/strengths/growth/source trace/limitations + immutable history | VA_PENDING | owner review |
| Chat | route-backed direct/group communication from cycle 0026 | VA_PENDING | owner review |
| Groups | route-backed community/group flow from cycle 0026 | VA_PENDING | owner review |
| Search Requests | first-class persistent/API flow from cycle 0026 | VA_PENDING | owner review |
| Trust | retained, separate from psychological tendencies/Compatibility | VA_PENDING | cycle 0027 still outstanding |
| Hospitality | existing source lifecycle retained | VA_PENDING | cycle 0027 still outstanding |
| Services | retained | VA_PENDING | cycle 0027 still outstanding |

## Scientific Tests v1
Current independent systems:
1. Черты и саморегуляция (`traits_core`);
2. Межличностный стиль (`interpersonal_style`);
3. Коммуникация и конфликт (`communication_conflict`);
4. Доверие, поддержка и границы (`trust_support_boundaries`);
5. Решения, риск и рабочий стиль (`decision_work_style`);
6. Социальная энергия и роль в группе (`social_group_role`);
7. Адаптивность и неопределённость (`adaptability_uncertainty`).

Internal calibration `research-calibration-v1` is active now from canonical scientific evidence. Future outcome data can harden a later version but is not a launch prerequisite.

## Simulation evidence
Current HEAD simulation contract: **94 paths / 112 operations / 50 tables / 21 Android AppRoutes**; **200 deterministic synthetic candidates + current demo user**. Local route probe: **112/112 operations, 0 failures**.

## Acceptance rule
`H=PASS` does not imply `VA=PASS`. Accepted HTML becomes Compose visual authority only after explicit owner approval.
