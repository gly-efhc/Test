# UI Acceptance Recovery Plan — cycle 0028 acceptance candidate

## Current acceptance state
Cycles 0025/0026 created the route-backed product shell. Cycle 0028 corrects the missing scientific-tests materialization and produces the new consolidated standalone candidate. Status: **SOURCE_HTML_IMPLEMENTED / SCIENTIFIC_TEST_SYSTEMS_V1 / VISUAL_ACCEPTANCE_PENDING**.

## Review artifact
`tools/visual_checks/BROTHERHOOD_UI_SIMULATOR_v0_5_38.html` — must remain byte-identical to active root/tools demo mirrors and is delivered separately with the DEVELOPMENT archive.

## Mandatory review order
1. My Profile — identity/social/professional resume; no self-compatibility.
2. People — search, explicit Search Requests, compact cards, progressive list.
3. Candidate — person first, metrics second.
4. Compatibility Details — Q28 systems + seven psychological-system scores; Trust/Rating/Fit separate.
5. Tests Home — seven scientific systems, purpose, progress, source/calibration trace.
6. Test System → execution → per-series result → aggregate system result.
7. Psychological Profile — seven system aggregates and coverage.
8. Psychological Report v2 — human-readable synthesis, seven system sections, sources, limitations, immutable history.
9. Messages — direct/group timeline, E2EE boundary, reply/edit/delete/reactions/attachments/typing/read.
10. Groups/Communities — list/detail/join/leave/create and group chat creation.
11. Search Requests — list/create/edit/pause/archive/apply-to-People.
12. Trust/Hospitality/Services — still require cycle 0027 recovery before they can be called cycle-0027-complete.

## Scientific calibration acceptance rule
The HTML must show a working product now. It must not describe multi-year external cohort collection as a prerequisite for current scoring. Current v1 uses `research-calibration-v1`; future outcomes can support explicitly reviewed version hardening only.

## Following sequence
- immediate: owner visual review/corrections of v0_5_38;
- cycle 0027 remains outstanding and must still be implemented unless explicitly superseded;
- Compose mirror only after explicit owner `VA=PASS` for the accepted HTML;
- GitHub CI/APK only after accepted Compose source exists.

## Donor discipline
- early VK: person/profile/social-resume depth;
- Telegram: communication mechanics and timeline clarity;
- Diia: reusable shell, explicit Back, top/body/bottom decomposition, progressive disclosure.
No donor may override scientific scoring or another source-class authority.

## Hard gate
Parser/JS/API/SimulationEngine tests are not visual acceptance. Owner visual review remains PENDING until explicit approval.
