# Brotherhood v0.5.18 — Android compilation corrective release

Android target: `versionName 0.5.18`, `versionCode 23`, `applicationId org.federationofavatars.brotherhood`.

## Evidence
GitHub run `83241548302` reached Android resource/signing preparation and failed at `:app:compileDebugKotlin` with three source errors:

- `AssessmentLocalStore.kt`: missing `compositionVariant`;
- `BrotherhoodApp.kt`: unresolved `compositionVariant`;
- `MainViewModel.kt`: removed `friendshipExpectationsScore` parameter still supplied.

## Corrective scope
- persist/restore `composition_variant` in local response traces;
- expose the deterministic non-scoring composition variant on core visual profile questions;
- remove the retired Friendship Expectations named argument;
- update stale unit tests;
- add exact regression guards;
- synchronize backend/OpenAPI/source/canonical workflow metadata to 0.5.18 / 23.

No product algorithm, Compatibility weight, Vedic 5%, Quality Fit rule, Trust rule, controlled-pilot design, applicationId or signing policy changed.

## Local verification
- backend + architecture: 99/99 PASS;
- focused pure Kotlin core compile: PASS;
- OpenAPI: 0.5.18 / 45 paths;
- full local Gradle: environment blocked by `UnknownHostException: github.com`, therefore exact-HEAD GitHub CI remains required.

Verdict: `LOCAL_PASS_LIVE_DEFERRED`.
