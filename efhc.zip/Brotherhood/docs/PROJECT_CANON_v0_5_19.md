# Brotherhood project canon v0.5.19

> **STATUS NOTE (Cycle 0004, 2026-08-09): HISTORICAL VERSION / SUPERSEDED FOR CURRENT COMPATIBILITY AGGREGATION.** Fixed 15-layer/inter-metric weights and Vedic 5% statements below are preserved as historical scope evidence; current target canon is `docs/CANON/BROTHERHOOD_COMPATIBILITY_CANON.md` (independent scores + simple mean of user-selected metrics). Other historical mechanics statements remain evidence unless separately superseded.


## Identity and version
- `applicationId = org.federationofavatars.brotherhood`
- `versionName = 0.5.19`
- `versionCode = 24`
- canonical owner identifier: `global_id`, display format `0000000001`

## Product scope
Brotherhood is for platonic male friendship 18+, not dating. Trust, Compatibility, Account Completeness and Quality Fit are mathematically and semantically separate.

## Canonical Compatibility weights — unchanged
| Layer | Weight |
|---|---:|
| psychological/behavioral friendship tests | 18% |
| character | 10% |
| values | 10% |
| friendship goals | 9% |
| interests | 8% |
| lifestyle | 7% |
| communication | 7% |
| conflict/repair | 7% |
| Brotherhood-32 | 7% |
| Vedic numerology | **5%** |
| Enneagram | 4% |
| zodiac | 3% |
| geography | 2% |
| business/mutual aid | 2% |
| social format | 1% |

TOTAL = 100%.
Quality Fit is not a sixteenth layer.

## Psychological/behavioral bank v2
- exactly 100 tests × 6 = 600 tasks;
- indirect visual/associative format only;
- target constructs and loadings are internal;
- no universal good/bad trait direction;
- multiple tasks contribute to each hidden coordinate;
- fixed answer position is not a scoring cue; presentation order may be shuffled;
- `visual-latent-v2` is the active model version;
- direct-question legacy results are quarantined and do not feed the new model.

## Quality Fit
The searching user explicitly selects a role/context and desired qualities. Role never auto-injects desired qualities. Candidate hidden profile + explicit selected qualities -> request-specific Quality Fit. Public output contains safe positive quality labels, not raw latent coordinates.


## Retired v0.5.12 Friendship Expectations shadow
The former fixed-ID diagnostic (`f065` + `f071–f080`) is retired for `visual-latent-v2` because the new visual bank no longer gives those IDs the old direct-question semantics. Expectations such as contact frequency, directness and boundaries are represented as explicit user-selected Quality Fit qualities. The retired shadow does not become a 16th Compatibility layer.

## Positive interpretation
All detailed internal findings remain private to algorithms. Public profile emphasizes strengths and contextually useful qualities. Low/high poles are not moral labels.

## Vedic friendship compatibility — locked
Friendship compatibility uses only two dates of birth: soul 40%, destiny 35%, cross 15%, date composite 10%. Name-derived numbers are descriptive only. Overall Vedic Numerology weight remains exactly 5%. Numerology is not a test.

## Numerology knowledge
The v0.5.13 complete user-supplied numerology knowledge integration remains preserved and unchanged.

## Trust and completeness
Complaints alone do not reduce public reputation; only confirmed moderation incidents may affect Trust. Account Completeness remains 50% unique current-model psychological test completion + 50% profile sections and is not a personality score.

## Branding / Android security
No change to master logo, applicationId, permission canon, production signing or signing secrets. No `REQUEST_INSTALL_PACKAGES` and no broad media/storage permission.

## v0.5.18 empirical calibration and language canon
- Active visual model: `visual-latent-v2`; stimulus library: `scene-library-v4` with 48 neutral scene archetypes.
- Item-level response traces are private calibration evidence and never public profile/API data.
- Calibration output is review-only; no automatic production loading/weight mutation.
- Quality Fit catalog contains 112 user-selectable contextual qualities; role never injects defaults.
- Localization is data-driven. Current enabled locales: RU/UK/EN; future locales are activated by complete packs, not source branches.
- Language selector is a carousel. One locale state controls all user-facing sections, assessments/results, Quality Fit labels, self-analysis, numerology and status text.
- RTL/LTR direction is locale metadata. Incomplete language packs are not activated.
- Built-in city labels and bundled demo presentation content follow the selected locale; canonical city search/storage values remain stable. User-authored content is never silently rewritten by locale changes.



## v0.5.18 first-user calibration pilot canon
- Active scoring model remains `visual-latent-v2`; stimulus provenance is `scene-library-v4`.
- The 600-task bank exercises 48 scene archetypes and 16 paradigms.
- Raw item-level traces are separate from the aggregate operational profile and require explicit `calibration-consent-v2` opt-in for server retention.
- Withdrawal purges retained raw calibration attempts while preserving the aggregate profile used by ordinary product functionality.
- Calibration trace includes deterministic presentation slot, first-selection latency, selection-change count and randomized task position.
- Early-pilot analysis does not require 30/90-day outcomes; outcome analysis uses only assessments completed on/before match time.
- Calibration flags are review candidates, never diagnoses, moral/reputation labels or automatic production changes.


## v0.5.18 visual-composition and controlled-cohort canon
- A composition variant is visual presentation evidence only; it MUST NOT alter latent loadings or scoring.
- All four answer options in one task MUST share the same base scene composition so the choice cannot be confounded by a different background.
- The active bank uses 48 scene archetypes, 16 paradigms and 8 deterministic composition variants across the actual 600 tasks.
- Closed pilot enrollment requires current consent, explicit acknowledgement, supported locale, available total/locale quota and a valid unredeemed invitation digest.
- Plaintext invitation codes are transient request data only and MUST NOT be stored, queued offline, logged or committed.
- Withdrawal is unconditional and deletes retained raw attempts while preserving the aggregate operational profile.
- GitHub run 83237541436 source failure was caused by a truncated Kotlin compatibility section; the restored panel contains all 15 canonical layers and is protected by a structural regression test.


## v0.5.18 corrective Android compilation canon

GitHub run `83241548302` proved three independent Kotlin source regressions in the exact v0.5.17 HEAD:

1. `AssessmentLocalStore` did not restore the required `compositionVariant` field and did not persist it locally.
2. `CoreProfileQuestion` did not expose the composition variant required by the visual UI.
3. `MainViewModel` still passed the retired `friendshipExpectationsScore` argument to `HybridCompatibilityEngine`.

v0.5.18 fixes all three root causes together. The retired Friendship Expectations diagnostic remains inactive; active expectation matching remains user-authored Quality Fit. No Compatibility weights, Trust rules, stimulus loadings, pilot architecture, applicationId or signing policy are changed.


## v0.5.19 Android unit-test corrective canon

GitHub run `83256062351` proved that production `compileDebugKotlin` passes, but `compileDebugUnitTestKotlin` failed because tests still referenced fields removed with the direct-text questionnaire (`pairId`, `reverse`, `text`, `situationalText`). v0.5.19 updates only the test contract and release metadata: visual-latent-v2 / scene-library-v4 production algorithms, 15 Compatibility weights, Vedic 5%, Quality Fit, controlled pilot, applicationId and signing policy remain unchanged. Cross-test contradictions are internal consistency evidence only and never moral risk.
