# Research → Product Materialization Matrix — cycle 0024

| Module | Research/spec | Measurement / algorithm | Backend/runtime source | HTML simulator | User explanation | Remaining gate |
|---|---|---|---|---|---|---|
| Psychological visual assessment | substantial; validation still incomplete | current 100×6 baseline, 10 module projection | results API + module compatibility source | full 200-person synthetic pair data | per-test/profile/report | quality redesign + empirical validation + VA |
| PC | research/spec present | pair similarity from common assessment evidence + module detail | Q28 server contract implemented | route-backed | score/coverage/model/status | live E2E + validation |
| IC | cycle 0014 research | normalized interest overlap | Q28 server contract implemented | route-backed | independent metric | validation/VA |
| VC | cycle 0015 research | normalized value overlap | Q28 server contract implemented | route-backed | independent metric | validation/VA |
| CC | cycle 0016 research | current communication assessment comparator | Q28 server contract implemented | route-backed | independent metric | validation/VA |
| LC | cycle 0017 research | normalized lifestyle overlap | Q28 server contract implemented | route-backed | independent metric | validation/VA |
| PT / Brotherhood-32 | cycle 0018 | five-axis similarity + current durability/bond rule | Q28 server contract implemented | route-backed | independent metric | validation/VA |
| EN | existing descriptive runtime | existing current type compatibility only | mirrored; no new engine research | route-backed synthetic profiles | independent metric | new Enneagram research deferred to 0029 |
| NU | existing date-based numerology | current date-number comparator `0–100`; name does not affect current pair calculation | Q28 server contract implemented | 200 synthetic profiles + independent NU | independent metric | later validation/research vNext 0030 |
| AS | existing cultural runtime | current Zodiac/element comparator | mirrored; no new research | route-backed | independent metric | new research deferred 0031 |
| Psychological analysis | research foundations | deterministic synthesis | source implemented | route-backed product flow | full sections | scientific validation + VA |
| Psychological report | recovery spec | immutable/versioned snapshot + SHA-256 input fingerprint | migration/API/history implemented | save/latest/history/by-id | report/history | live DB + VA + Compose + CI/E2E |
| Trust | established domain | separate trust mechanisms | source implemented | simulated | separate from Compatibility | VA/live qualification |
| Hospitality | cycles 0019–0022 | verified-stay/reputation lifecycle | source implemented | simulated end-to-end | substantial | VA/live qualification |

Rule: `research complete` does not become `product implemented` until the chain reaches applicable runtime, UI, acceptance and live gates.
