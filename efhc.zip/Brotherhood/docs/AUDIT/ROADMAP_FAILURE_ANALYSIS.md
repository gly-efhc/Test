# Why the Roadmap Advanced While the Product Stayed Incomplete

## Verified structural cause
Cycles 0004–0018 primarily delivered scientific foundations: source registry, constructs, evidence/claim architecture, research specifications, compatibility hypotheses/models and validation protocols. In several cycle artifacts runtime was explicitly unchanged or production inactive. The historical registry nevertheless flattened heterogeneous outcomes into `COMPLETED`, and manifest progress counts did not distinguish research completion from runtime/UI/acceptance qualification.

## Consequence
Document/cycle count increased much faster than the user-ready vertical. API routes, specifications, simulator stubs and research reports were repeatedly treated as progress even when a person could not complete the full product path `test → meaningful result → psychological profile → psychological report → pair compatibility → communication → trusted offline interaction`.

## Corrected status model
Every major module now tracks independent gates: `R Research / S Spec / B Backend-Domain / H HTML / VA Owner Visual Acceptance / A Android Mirror / CI APK / E2E Live`. A later gate cannot be inferred from an earlier gate.

## Corrections materialized
- 0023 converted Tests/Psychology/Report/Q28 from documentation gaps into source-level product flows.
- 0024 adds immutable Psychological Report persistence/history, Q28 server contracts, selection persistence and a full source-contract simulator with 200 deterministic synthetic people.
- Research-tail cycles remain deferred until the owner-accepted base product is restored.
- HTML is the visual development/acceptance surface; Compose and CI/APK follow explicit owner acceptance rather than being used to discover the interface.

## What remains unresolved
Cycle 0024 source implementation still is not visual acceptance, Android UI mirror, real PostgreSQL qualification or LIVE E2E. Those statuses remain explicitly pending/not run.
