# Brotherhood UI implementation gap audit — cycle 0022 correction

Status: FACTUAL AUDIT FROM `Brotherhood_v0_5_52.zip`, active CANON/SSOT and GitHub CI logs `logs_85282662386.zip`.
Date: 2026-08-11.

## Executive finding
The project has substantial backend, research, simulation-contract and Android functionality, but the previously reported SOURCE/LOCAL RC status was incorrectly allowed to stand in for owner-approved product UI completion. The owner has not accepted the current UI. The current HTML demonstrates that broad VK + Telegram + Diia product architecture was documented, but only partially converted into a coherent visual product.

## What is actually implemented
- Authenticated Home is compliant with the owner canon: exactly four primary actions — People Search, Messages, Tests, Search Requests.
- Root Android shell has five tabs: Home / People / Chats / Groups / Profile.
- Android chat source contains direct/group chat, E2EE boundary, typing refresh, attachments, reply/edit/delete/reactions, block/report and Hospitality structured cards.
- Hospitality backend/runtime and Android source exist.
- HTML has stateful BackendSimulator/SimulationEngine and broad route coverage.

## Confirmed UI gaps
### Early-VK person depth — incomplete
The active product reference requires resume-like identity, biography/activity, interests, profession/skills, communities, social context and direct communication. Current `FriendCandidate` and `UserProfile` UI models contain name/age/city, interests/goals/values/lifestyle and matching models, but do not contain a complete profession/skills/experience/projects/activity/social-context resume model. Therefore the early-VK profile concept is not fully implemented in the active UI model.

### Telegram visual/interaction parity — Android source ahead of HTML
Android chat source includes richer interaction than the HTML mirror. Current HTML `chatScreen()` exposes basic send/reaction/delete/block/report, but does not visually mirror the full Android attachment/reply/edit/typing/read/security-fingerprint interaction set. Therefore HTML cannot be treated as full chat UX parity.

### Diia service discipline — partial
Home is low-density, but Profile and Candidate/Compatibility remain long, dense scrolling surfaces. Candidate detail renders the large Compatibility metric panel inline rather than a calm service landing page with drill-down. Profile likewise contains numerous metrics, discovery/self-analysis blocks and personality sections in one long page. The documented anti-pattern “dozens of unrelated CTAs / giant dashboard-like page” is not systematically eliminated outside Home.

### HTML route parity was mistaken for UI parity
Cycle 0022 validated source-contract counts, routes, parser/JS syntax and simulation state. Those checks prove coverage and runtime structure, not that every screen visually implements the approved product architecture. Browser visual smoke was environment-blocked, and there was no owner visual acceptance. Declaring the UI ready for another APK checkpoint was therefore not justified.

## Why the agreed interface did not materialize
1. Cycles 0004–0018 concentrated on research/compatibility architecture, not a full visual migration.
2. Cycle 0019 planned Hospitality; 0020 implemented backend/database; 0021 added Hospitality Android functionality; 0022 focused release-parity/simulation/security.
3. Owner answers were preserved in Q&A/CANON, but were not converted into one mandatory screen-by-screen UI migration matrix with acceptance status.
4. Architecture tests checked markers, route counts and boundaries more strongly than visual information hierarchy.
5. I treated “function exists / route exists / simulator has action” as too close to “UI implementation complete”. That was the process error.
6. I then asked for CI/APK qualification before owner visual acceptance, even though the UI Demo CANON defines the HTML as the review surface before another APK cycle.

## CI log findings
GitHub compilation produced 87 Kotlin errors from only three root causes:
- 85 calls from `HospitalityScreens.kt` / `ServiceScreens.kt` could not access file-private `MainViewModel.t(...)`;
- explicit `androidx.compose.foundation.layout.weight` import is incompatible with the current Compose API surface;
- explicit `calculateBottomPadding` import is unresolved; the `PaddingValues` member call remains valid without that import.
The source hotfix changes only the relevant UI files and does not change product mechanics.

## Correct gate from now on
`full HTML simulator implementation → owner visual acceptance → mirror accepted UI in Android Compose → compile/static checks → GitHub CI/APK`.

Existing CI logs may be used to fix confirmed compiler errors, but another build request is not a substitute for visual review.
