# Auth / session boundary — Brotherhood v0.5.7

## Канон

`global_id` принадлежит аккаунту Brotherhood. Google, Telegram, Facebook и будущие провайдеры только подтверждают доступ к этому аккаунту.

```text
Provider credential
       ↓ verify on Vercel
user_identities(provider, subject)
       ↓
global_id
       ↓
auth_sessions(server-side token hash)
       ↓
Android Bearer session
```

## Что уже реализовано

- `users.global_id` как `BIGINT IDENTITY` 1..9999999999;
- `user_identities` с уникальностью `(provider, tenant, provider_subject)`;
- `auth_sessions` с server-side SHA-256 hash токена;
- `/internal/identity/resolve` — только после provider verification;
- `/internal/sessions/issue` — выдача приложения session token после подтверждённой provider identity;
- `INTERNAL_AUTH_SECRET` обязателен для внутренних auth endpoints в PostgreSQL runtime;
- общие write endpoints сверяют заявленный `global_id` с server-side session;
- debug runtime может использовать локальную тестовую сессию, production — нет.

## Что требует внешних credentials

Реальное подтверждение Google / Telegram / Facebook не может быть завершено без app/client IDs, redirect URIs и секретов соответствующих провайдеров. Эти значения добавляются только в Vercel/GitHub Secrets.

После настройки provider adapter должен:

1. получить credential от провайдера;
2. проверить подпись/issuer/audience/expiry на сервере;
3. получить стабильный provider subject;
4. вызвать внутренний identity resolver;
5. выпустить Brotherhood session;
6. вернуть Android только короткоживущий/отзываемый app session, а не provider secret.
