# GitHub APK build fix — Brotherhood v0.5.7

## Source
`logs_83032884747.zip`, GitHub Actions run on 2026-07-31.

## Confirmed CI state
- `Brotherhood.zip` integrity: PASS (`No errors detected in compressed data`).
- Archive extraction and Android project discovery: PASS.
- JDK 17 / Gradle / Android SDK 36: PASS.
- Android resources and Kotlin production compilation: PASS.
- Unit tests: 15 executed, 1 failed.
- Failing test: `Personality32EngineTest.identical_profiles_have_maximum_compatibility`.

## Root cause
`bondStyle` is scored from stable/committed (0) to adaptive/independent (100), but the compatibility formula treated the raw value as a positive loyalty score. That inverted the durability contribution and also conflicted with a test that assumed an arbitrary identical profile must always equal 100.

## Fix
- durability is now `100 - bondStyle`;
- the long-term friendship score uses the weaker durability of the pair;
- the maximum-compatibility regression test now uses a fully stable bond profile;
- an additional regression test verifies that an identical highly adaptive profile does not outrank an identical stable profile for long-term friendship.

This preserves the project goal: similarity is important, but long-term male friendship also rewards stable commitment.
