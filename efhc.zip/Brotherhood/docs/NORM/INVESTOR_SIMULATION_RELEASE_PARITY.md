# Investor simulation release-parity contract

Status: ACTIVE NORM.

## Owner rule

`BROTHERHOOD_UI_DEMO.html` is an investor-facing release simulation, never a simplified prototype. Simulation must preserve the actual product mechanics and current source contracts. UI/design work may change presentation only; it must not replace tests, scoring, hidden metrics, source maps, backend contracts, database entities or product philosophy with simplified substitutes.

## Required local parity gates

A demo may be described as locally investor-qualified only when all of the following are mechanically verified against the current source tree:

1. Full OpenAPI inventory is embedded and handled by the standalone backend simulator. Current source after Hospitality cycle 0022: **80 paths / 93 operations**.
2. Full SQL table inventory is represented by the standalone backend table store. Current source after Hospitality cycle 0022: **47 migration-defined tables**. Empty tables are allowed when the current demo scenario has no row for that entity; silently omitting the table is not.
3. Every Android `AppRoute` has an HTML route mirror. Current source after Hospitality cycle 0022: **21 AppRoutes**. Additional demo/workbench routes are allowed.
4. Active scientific questionnaire contracts match backend/domain/scoring and the standalone simulator; removed visual/protected mechanics are not restored as fallback.
5. The 100×6 visual assessment bank, hidden latent scoring/profile aggregation and positive public projection are exercised through the simulation engine; direct primitive questions or independent fake scoring are forbidden.
6. Stateful user flows are verified in a real JavaScript/browser runtime: navigation, bottom navigation, test completion/result, theme, messaging/state mutation and backend contract probe.
7. The standalone file has no required external runtime assets/network dependency.

## Evidence boundary

This contract proves a local investor simulation against source contracts. It does **not** prove real PostgreSQL, real OAuth/providers, real E2EE transport, production deployment, APK compilation or installed-device behavior. Those remain separate LIVE/APK gates.

## Blocking regression rule

The following must fail verification/package qualification rather than be silently simplified:

- OpenAPI operation count/path drift without simulation contract refresh from source;
- database table loss;
- Android AppRoute loss;
- active scientific questionnaire/scoring contract drift;
- missing source maps;
- primitive/direct replacement of the visual tests;
- missing backend handler domain;
- backend probe returning `SIM_ROUTE_NOT_FOUND`, error or 5xx for any current operation;
- HTML route missing for a current APK AppRoute.

The guard may only be updated from actual current source contracts. It must never be weakened to make a failing demo appear green.


## Hospitality cycle 0022 parity
The current contract includes all Hospitality source surfaces introduced in cycles 0020–0021: 21 Hospitality HTTP operations, eight Hospitality data tables and seven Hospitality Android routes. The standalone simulator must preserve accepted-only exact-arrival privacy, lifecycle/version semantics, bilateral verified-stay confirmation, blind-review publication, separate Hospitality Reputation and no automatic production learning.
