# Brotherhood RELEASE archive policy

Status: ACTIVE NORM

## Purpose
`DEVELOPMENT` and `RELEASE` are separate artifacts. The development archive preserves the full project context. The release archive is a clean runtime/build source package for Android/server deployment and recovery; it is not an AI working archive.

## RELEASE allowlist
The release packager may include only:
- Android Gradle/runtime source required to build the APK (`android/**`, excluding test/debug cache/output directories);
- runtime backend/API source and config templates (`backend/app/**`, `backend/api/**`, selected backend root config files);
- database migrations/policies and restoration README;
- runtime shared contracts/assets (`shared/**`);
- the frozen Android GitHub workflow;
- minimal build/deployment/restoration documentation and third-party notices;
- a generated `RELEASE_MANIFEST.json`.

## RELEASE denylist
Never include:
- `docs/AI/**`, `docs/CANON/**`, `docs/SSOT/**`, `docs/NORM/**`, `docs/ADR/**`, `docs/healer/**` except explicitly allowlisted deployment/build docs;
- `reports/**`, `analysis/**`, `tools/**`, `tests/**`, Android unit-test sources, demo HTML/workbench files;
- logs, screenshots, caches, `node_modules`, virtual environments, Gradle/build output;
- secrets, private keys, keystores, certificates with private material, real `.env`, tokens, cookies or sessions;
- historical archives or nested ZIP/APK/AAB artifacts.

## Build truth
The frozen `.github/workflows/android-build.yml` remains byte-identical unless a separately evidenced CI task authorizes a change. A RELEASE archive does not itself prove an APK build. Full Android compile/assemble qualification remains GitHub CI evidence.

## Required validation
Before delivery: allowlist/denylist check, ZIP CRC, single `Brotherhood/` top root, no traversal, no symlinks, no nested archives, secret-extension scan, and manifest/file-list parity.

## Delivery naming
Versioned user-facing ZIP names use only the clean sequential form `Brotherhood_v0_5_NN.zip`. `DEVELOPMENT` versus `RELEASE` remains a content/policy distinction and is recorded inside manifests/governance, not in an automatic filename suffix. If both artifact classes are explicitly requested, assign separate consecutive archive numbers. Historical filenames remain historical evidence.
