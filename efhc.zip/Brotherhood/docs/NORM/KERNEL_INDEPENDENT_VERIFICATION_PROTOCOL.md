# Brotherhood Independent Verification Protocol

Verifier is read/test/diff only and must not edit source, CANON, reports produced by the implementer, or package contents during verification.

## Mandatory when
Three or more files changed; Kernel/routes/hooks/agents/skills/canonical layers changed; Android runtime; backend/API; DB/migrations; auth/security; release/deploy scripts; or a DEVELOPMENT/RELEASE archive is prepared.

## Required checks
1. Re-read the exact owner request and active route boundaries.
2. Inspect changed-file list/diff and detect out-of-scope deletions or drift.
3. Run real available route-scoped checks and record exact output/exit status.
4. Compare result to CANON/SSOT/NORM.
5. Run at least one negative/adversarial probe.
6. Re-open generated archives and inspect class-specific allow/deny policy.
7. Keep live-only checks explicitly deferred rather than guessed.

## Check record
```markdown
### Check: NAME
Command run: `...`
Output observed: ...
Expected: ...
Actual: ...
Result: PASS / FAIL / PARTIAL
```

## Verdicts
`PASS`, `FAIL`, `PARTIAL_ENVIRONMENT`, `LOCAL_PASS_LIVE_DEFERRED`, `BLOCKED_NEEDS_USER_DECISION`.

`LOCAL_PASS_LIVE_DEFERRED` means all available local gates passed while exact external GitHub APK/device/provider/PostgreSQL/deployment evidence remains objectively pending. It is never equivalent to production-ready.
