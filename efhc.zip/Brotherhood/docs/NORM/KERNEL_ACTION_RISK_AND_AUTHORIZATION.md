# Brotherhood Action Risk and Authorization

Core rule: Operator Kernel does not veto local source/product edits requested by the owner. Risk classes organize execution and evidence. Real external side effects remain separately authorized because they mutate systems outside the local development archive.

| Class | Meaning | Default authorization |
|---|---|---|
| LOCAL_REVERSIBLE | scoped edits/tests/packages in working copy | allowed; route is advisory for context and validation |
| LOCAL_DESTRUCTIVE | delete/overwrite/restructure locally | allowed when directed by current task; record diff/rollback evidence |
| SHARED_REVERSIBLE | shared source change represented locally | allowed in current task; remote push/merge remains an external action |
| EXTERNAL_SIDE_EFFECT | push, message, publish, remote change | separate explicit authorization |
| PRODUCTION_LIVE | deploy, production migration/secrets/provider change | live gate + explicit authorization + evidence |
| IRREVERSIBLE | destructive real-data/external irreversible action | explicit confirmation + recovery/proof before action |

Every route/skill declares `risk_class`, `authorization_scope`, `rollback_required`, `rollback_plan`, `external_side_effects`, and `user_confirmation_required`.

External actions include git push/merge, publishing release, deploy, production DB migration or deletion, DNS, external message, real Telegram/provider mutation, production secret/permission changes and on-chain transactions. Local source packaging does not grant authority for any of them.
