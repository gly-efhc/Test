# Brotherhood Localization and Language Pack Norm

Status: **ACTIVE NORM — Q31 / 13-LOCALE**

## 1. One runtime language state
`AppLanguage.tag` is the single user-facing locale state. Current owner-approved tags are `sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`.

## 2. Registry
`shared/locales/supported.json` is SSOT and is mirrored into Android `assets/i18n/languages.json`. Current order follows the owner-provided 13-language selector: `sw` Kiswahili, `ru` Русский, `en` English, `uk` Українська, `de` Deutsch, `fr` Français, `es` Español, `it` Italiano, `tr` Türkçe, `pl` Polski, `da` Dansk, `hi` हिन्दी, `id` Bahasa Indonesia.

## 3. Data-driven activation
Every enabled language requires: language metadata, a complete `shared/locales/packs/<tag>.json` mirror in APK assets, every `required_keys.json` key, and a numerology locale block. Missing structural coverage disables the locale. New languages must not require widespread Kotlin/backend branching.

## 4. Translation quality status
Each new pack carries explicit status. `DRAFT_COMPLETE_REQUIRES_NATIVE_QA` means runtime key coverage is complete but native-speaker linguistic review and psychometric equivalence are not yet claimed. Placeholders, stable machine keys, brand tokens, IDs and protocol syntax must survive translation unchanged.

## 5. Assessment adaptation
For all 13 locales, test/stimulus adaptation follows `docs/research/validation/MEASUREMENT_INVARIANCE_13_LOCALES_PROTOCOL.md` and `DIF_ITEM_BIAS_13_LOCALES_PROTOCOL.md`. Translation alone never authorizes score comparisons. The current 100×6 mechanics remain baseline-guarded against translation/UI drift; Q41 permits explicit versioned assessment redesign.

## 6. Numerology
Numerology is a separate cultural/traditional engine, not a psychological test. Every enabled locale has a complete presentation block. Translation does not change formulas, compatibility semantics or evidence class.

## 7. Direction and geography
Direction is locale metadata. Built-in city values remain canonical storage/search values; translated labels live in packs. User-authored text is not auto-translated.

## 8. Generator
`scripts/update_locale_catalog.py` regenerates the translation template, RU/UK/EN source aliases, required keys and registry mirror. It must preserve all enabled data packs and validate coverage rather than reset the active locale set.

## 9. Forbidden drift
- partial pack presented as fully localized: FORBIDDEN;
- translation claimed as measurement invariance: FORBIDDEN;
- locale-specific scoring without validated/versioned model: FORBIDDEN;
- fixed RU/UK/EN-only runtime validation: FORBIDDEN;
- hidden test/scoring changes under localization scope: FORBIDDEN.
