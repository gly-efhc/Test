# Brotherhood project canon v0.5.22

> **STATUS NOTE (Cycle 0004, 2026-08-09): HISTORICAL VERSION / SUPERSEDED FOR CURRENT COMPATIBILITY AGGREGATION.** Fixed 15-layer/inter-metric weights and Vedic 5% statements below are preserved as historical scope evidence; current target canon is `docs/CANON/BROTHERHOOD_COMPATIBILITY_CANON.md` (independent scores + simple mean of user-selected metrics). Other historical mechanics statements remain evidence unless separately superseded.


- `versionName = 0.5.22`
- `versionCode = 27`
- `applicationId = org.federationofavatars.brotherhood`

## Cycle scope

1. Positive user result after every visual psychological block.
2. Positive discoveries on Home/Profile/Self-analysis, including latest discovery, next best step, useful contexts and discovery history.
3. Data-driven horizontally scrollable RU/UK/EN language carousel with complete-pack activation gates.
4. Screenshot-driven UX corrections for candidate fit explanation, adaptive People CTA, non-passive chat empty state, differentiated Groups cards, aligned Profile result blocks, honest manual Development installation UI and collapsible pilot section.
5. Runtime error fallbacks are locale-aware and do not expose raw exception text.
6. The universal version-independent `android-build.yml` remains frozen and byte-identical.

## Preserved canon

100×6 tasks, `visual-latent-v2`, `scene-library-v4`, 50 latent coordinates, 112 selectable qualities, 48 scenes, 16 paradigms, 8 compositions, 15 Compatibility weights, Vedic Numerology 5%, Trust/Compatibility/Account Completeness/Quality Fit separation, `global_id`, brand geometry, E2EE boundaries and calibration architecture remain unchanged.

## Evidence boundary

This version is a source milestone until GitHub APK build and device screenshots complete the cycle-0002 APK acceptance gate. Source/local checks may establish `LOCAL_PASS`; they do not establish `APK_VISIBLE`.
