# GitHub APK build fix — Brotherhood v0.5.4

Источник диагностики: `logs_83019404336.zip`, GitHub Actions run 2026-07-31.

## Что сработало

CI успешно:
- получил `Brotherhood.zip`;
- проверил ZIP;
- распаковал `Brotherhood/`;
- нашёл `Brotherhood/android`;
- установил Temurin JDK 17;
- подготовил Gradle Wrapper;
- настроил Gradle cache;
- установил Android platform-tools, platform 36 и build-tools 36.0.0;
- запустил Gradle и дошёл до Kotlin compilation.

Следовательно, причина падения не в workflow, ZIP, Android SDK или Gradle bootstrap.

## Исправленные Kotlin errors

1. `BrotherhoodApp.kt:25`
   - удалён `import androidx.compose.foundation.layout.weight`;
   - в текущем Compose API `Modifier.weight()` доступен через `RowScope`/`ColumnScope`, а явный импорт резолвился в internal `RowColumnParentData.weight`.

2. `ServiceScreens.kt:19`
   - исправлено аналогично.

3. `BrotherhoodCacheStore.kt:168`
   - `arrayOf(error.take(500), id)` при Kotlin 2.3.21 выводил intersection type `Comparable<*> & Serializable`;
   - заменено на `arrayOf<Any?>(error.take(500), id)`, соответствующее Android SQLite `execSQL(..., bindArgs)`.

## Версия

- Android `versionCode`: 9.
- Android `versionName`: 0.5.4.

## Повторная квалификация

Следующая каноническая проверка — тот же workflow `android-build.yml` с новым `Brotherhood.zip`.
