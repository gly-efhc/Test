# Cycle 0003 — LIVE E2E qualification runbook

1. Deploy exact Brotherhood backend from `v0.5.31` over HTTPS.
2. Configure real `DATABASE_URL` and apply migrations 0001→0008 from a trusted admin environment.
3. Configure `GOOGLE_CLIENT_ID`; verify `/v1/auth/google/config` returns only the public client ID.
4. Register Telegram HTTPS callback `/v1/auth/telegram/callback` in BotFather; set Client ID/Secret and `TELEGRAM_APP_CALLBACK_URI=brotherhood://telegram-login/callback`.
5. Configure email challenge secret/provider and sender.
6. Configure passkey RP ID/origin and host valid `assetlinks.json` for the Android application/signing certificate.
7. Set GitHub secret `BROTHERHOOD_API_BASE_URL` to the deployed HTTPS API. Do not edit `android-build.yml`.
8. Run real Google/Telegram/email/passkey login, restart app, refresh session, logout/revocation, settings persistence, and owner-isolation checks.
9. Record DB/API/device evidence. Only then promote relevant paths to `LIVE_E2E`.
