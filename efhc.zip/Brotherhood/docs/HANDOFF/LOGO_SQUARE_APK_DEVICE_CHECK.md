# Brotherhood square-logo APK/device acceptance

Status: REQUIRED acceptance gate for v0.5.27+

## APK gate

Run against the exact APK produced by the frozen GitHub workflow:

```bash
python scripts/verify_square_logo_apk.py Brotherhood-v*.apk
```

Expected:
- no `ic_launcher_round` resource;
- no adaptive `ic_launcher_foreground` resource;
- no monochrome/themed logo derivative;
- square launcher PNGs 48/72/96/144/192 px for mdpi..xxxhdpi;
- runtime `logo_brotherhood.png` present.

This verifies packaged assets, not installed-device appearance.

## Installed-device gate

After a clean installation of the exact APK:
1. Open Auth screen and confirm the logo is a complete square at the 96dp slot with all four gold-frame corners visible.
2. Enter the app and inspect Home, People, Chats, Groups and Profile TopAppBar: square logo at the 38dp slot, no circular/oval/pill background or clipping.
3. Inspect launcher icon. Brotherhood supplies only a square legacy icon; if the device launcher visually reshapes it, record that as launcher/OEM presentation rather than an in-app round asset.
4. On Android 12+, system splash must not display a cropped/round Brotherhood logo; it is intentionally logo-free and the first Compose surface shows the square logo.
5. Capture screenshots of Auth, one TopAppBar, and launcher. Only then may the result be marked `APK_VISIBLE`.
