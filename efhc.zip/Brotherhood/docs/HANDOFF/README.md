# Handoff

`CURRENT_HANDOFF.md` is the human-readable adapter for the active cycle. Generated release handoffs remain in `reports/generated/`.
