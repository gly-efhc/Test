# CURRENT HANDOFF — Brotherhood cycle 0036

Updated: 2026-08-17

## Current HEAD truth
- input DEVELOPMENT package: `Brotherhood_v0_5_81.zip`;
- target package after freeze: `Brotherhood_v0_5_82.zip`;
- cycles `0034`–`0036` are implemented;
- cycle `0111` remains completed out-of-order historical inventory evidence;
- next executable cycle: `0037 — Retake, Alternate Order & Practice-Effect Runtime`;
- active bank: `scientific-questionnaire-bank-v1.3`; instrument `text-situational-neutral-v1`; scoring `scientific-questionnaire-v1` unchanged;
- active HTML: `BROTHERHOOD_UI_SIMULATOR_v0_5_52.html`, VA=PENDING;
- Android source/runtime unchanged in cycle0036;
- CI: `NOT_RUN_BY_OWNER_ORDER`.

## Cycle 0036 result
180 situational items now use respondent-neutral behavioral A/B wording. 17 direct public-domain anchors remain separate. A/B presentation is determined by the persisted opaque item token and remains stable across resume; BA responses are mapped back to canonical answer direction before scoring. `comprehension_flag`, `wording_version` and `side_order` are persisted in existing response metadata. Public test administration still exposes only one opaque item at a time and never returns construct/polarity/scoring keys/full bank.

No DB migration and no new API route are required. Current runtime contract remains `145 paths / 164 operations / 60 DB tables / 21 Android AppRoutes / schema19`.

## Scientific boundary
Cycle0036 is a wording/response-design change, not empirical validation. Reliability, factor validity, measurement invariance, DIF/fairness validity, diagnostic validity and faking-detection validity remain unclaimed.

## Next
`0037 — Retake, Alternate Order & Practice-Effect Runtime`.
