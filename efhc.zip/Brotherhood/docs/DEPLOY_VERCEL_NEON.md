# Деплой backend на Vercel и Neon

1. Подключить GitHub-репозиторий к Vercel.
2. Установить Root Directory: `backend`.
3. Добавить pooled Neon `DATABASE_URL` в Vercel Environment Variables.
4. Применить SQL из `database/migrations`, затем политики из `database/policies`.
5. После production-деплоя передать адрес API в GitHub Secret `BROTHERHOOD_API_BASE_URL`.
6. Пересобрать тестовый APK из `Brotherhood.zip`.

Локальный запуск:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
uvicorn app.main:app --reload
```
