# GitHub APK build fix — Brotherhood v0.5.6

Источник диагностики: `logs_83021345746.zip`, GitHub Actions run 2026-07-31.

## Что сработало

Workflow успешно прошёл распаковку ZIP, Java 17, Gradle Wrapper, Android SDK 36 и дошёл до `:app:compileDebugKotlin`.

## Причина падения

В `MainViewModel` одновременно существовали:

- свойство `var language`, для которого JVM генерирует setter `setLanguage(AppLanguage)`;
- ручная функция `fun setLanguage(value: AppLanguage)`.

На JVM обе декларации имеют одинаковую сигнатуру, поэтому Kotlin 2.3.21 остановил компиляцию с `Platform declaration clash`.

## Исправление

Публичная функция переименована в `changeLanguage(value: AppLanguage)` и обновлены все вызовы в `BrotherhoodApp.kt`. Внутренний `SettingsStore.setLanguage(...)` сохранён: он находится в другом классе и конфликта не создаёт.

## Версия

- Android `versionCode`: 10.
- Android `versionName`: 0.5.6.

## Повторная квалификация

Повторно запустить тот же GitHub workflow сборки APK из `Brotherhood.zip`.
