# Brotherhood project canon v0.5.12

## Identity and version
- `applicationId = org.federationofavatars.brotherhood`
- `versionName = 0.5.12`
- `versionCode = 17`
- canonical owner identifier: `global_id`, display format `0000000001`

## Product scope
Brotherhood is for platonic male friendship 18+, not dating. Trust, Compatibility and Account Completeness remain mathematically separate.

## Compatibility
The weighted production model remains unchanged at 100%:

| Layer | Weight |
|---|---:|
| friendship tests | 18% |
| character | 10% |
| values | 10% |
| friendship goals | 9% |
| interests | 8% |
| lifestyle | 7% |
| communication | 7% |
| conflict/repair | 7% |
| Brotherhood-32 | 7% |
| Vedic numerology | **5%** |
| Enneagram | 4% |
| zodiac | 3% |
| geography | 2% |
| business/mutual aid | 2% |
| social format | 1% |

`Friendship Expectations` is a shadow diagnostic calculated from `f065` and `f071–f080`: freedom of other friendships, depth/frequency of contact, reply expectations, channel preference, shared activity, humor boundaries, directness, debate, comfortable silence and planning. It has no production percentage in v0.5.12.

## Longitudinal calibration
`friendship_outcomes` stores the compatibility snapshot at connection time plus 30/90-day activity, 30-day message count and neutral ending reason. It is internal analytics only. Quarterly/offline analysis may fit standardized logistic regression against `still_active_90d`; output is a candidate for human review, never an automatic production-weight update.

## Assessments
- exactly 100 tests / 600 questions;
- each unique completed test adds 0.5% account completeness, maximum 50%;
- prompts are presented as situational behavioural items;
- exact construct titles are hidden until completion;
- three direct/reverse pairs are created per six-question test and presentation order is shuffled per attempt;
- this reduces demand characteristics but is not represented as proof of hidden intent or future conduct.

## Vedic numerology
Friendship compatibility uses only the two dates of birth: soul 40%, destiny 35%, cross 15%, date composite 10%. Name number may be descriptive but does not affect friendship compatibility.

## Avatar
The user chooses a single image through the system picker. Android copies it to app-private storage, resizes to at most 768 px on the long side, encodes a bounded JPEG and syncs at most 512 KiB through the backend. No broad storage/media permission is added.

## Branding
The canonical master logo is not redrawn. UI uses the existing `ic_brotherhood_logo` derived from the master and the canonical colors `#000000` / `#ECAF21`.

## Database additions
- `0002_friendship_outcomes.sql`
- `0003_profile_avatars.sql`

These are additive pre-release migrations; no existing migration or production data path is rewritten in this cycle.
