# Sandbox source audit — Brotherhood v0.5.10

Проверены все предоставленные пользователем песочницы. Цель — взять полезные продуктовые/UX-паттерны без переноса несовместимого стека, чужой архитектуры или кода с рискованной лицензией.

| Архив | Лицензия | Использование | Решение |
|---|---|---|---|
| `alovoa-master.zip` | AGPL-3.0 | reference_only | AGPL: no source/assets copied; privacy/open-source product ideas only |
| `humbble-main.zip` | MIT | patterns | MIT: privacy-first matching and customizable matchmaking preferences informed Brotherhood filters |
| `Complete-Dating-App-main.zip` | MIT | patterns | MIT: discover/profile/location/notification screen decomposition informed native Compose UX |
| `pegava-dating-app-master.zip` | CC0-1.0 | patterns | CC0: card pagination/action-bar/skip-back interaction informed Quick Discovery |
| `tinder-clone-master.zip` | NO LICENSE FILE | reference_only | No license file: visual/feature reference only, no code/assets copied |
| `tinder-react-native-master.zip` | MIT | patterns | MIT: Explore/Matches/Messages/Profile information architecture and match-percentage presentation considered |
| `tindev-main.zip` | MIT | patterns | MIT: profile/discovery separation reviewed; no source copied |
| `DostiPak-main.zip` | MIT | patterns | MIT: profile statistics, visibility, radius/geolocation, typing/online/voice patterns informed Brotherhood UX |
| `android-java-dating-app-main.zip` | NO LICENSE FILE | reference_only | No license file: visual reference only, no code/assets copied |
| `Numerology-main.zip` | NO LICENSE FILE | reference_only | No license file: conceptual reference only; Brotherhood VedicNumerologyEngine remains independent and date-math based |

## Реально внедрено в v0.5.10

- Quick Discovery deck: один кандидат за раз, `skip`, `undo`, детальная совместимость, friendship request.
- Persisted discovery filters: verified-only, online-only, shared interests, min Trust, min compatibility, hide requested.
- Профильные режимы `discoverable / connections / private`, синхронизируемые с backend.
- Passport city mode поверх уже существующего поиска по городам.
- Дополнительная статистика профиля: запросы, чаты, группы.
- Сохранены существующие Brotherhood-модули: 15 слоёв совместимости, E2EE direct chat, group chat, typing/online/voice/media, география, Trust и self-analysis.

## Что намеренно НЕ переносилось

- AGPL-3.0 Alovoa: код и ассеты не копировались.
- Проекты без явной LICENSE (`tinder-clone`, `android-java-dating-app`, `Numerology`): код/ассеты не копировались.
- React Native / Flutter реализации не встраивались в Kotlin/Compose как зависимости; нужные UX-паттерны реализованы заново нативно.
- Чужие логотипы, фотографии, шрифты, иконки и бренд-ассеты не включены.
- Нумерологический код из `Numerology-main` не используется; Brotherhood ведическая нумерология остаётся независимым математическим движком по датам рождения.

## SHA-256 входных архивов

- `alovoa-master.zip`: `869a0d88f38181308aac19a0b3c1d99e0f03e8067362a8085de3c942a8a89e19`
- `humbble-main.zip`: `c13e43edcec8a4476b4bdabf0a758e47712db9377c1ad7f88ebfb263b8c3e88c`
- `Complete-Dating-App-main.zip`: `113fa28e9114a507478ad499d1984e51e0b970fc26dece1e1709eb0626f1364a`
- `pegava-dating-app-master.zip`: `d91865967ff610252b9206373a811725d9105be9077fe1a8c166904719408538`
- `tinder-clone-master.zip`: `1c1d5b3fe38b3da3fdee3e5b7715bf832e5dcfee99dff21a8e650352ce633c53`
- `tinder-react-native-master.zip`: `01b9be2a04d34bd8ed3e1726a303fb63baf82a75521c2ec884572973447a91cd`
- `tindev-main.zip`: `c85f406943fd28d664b3029d5a049fad17f80f4441e9c3f6fe26dd9b900e1c38`
- `DostiPak-main.zip`: `698a4f771dbe3532b0a95cff094696f3c5f8356edbd63329d136b08533aba065`
- `android-java-dating-app-main.zip`: `48e244047f119e8dd19d4767161a449ff449d8cb39ebe8a30e90dc0f848aeaea`
- `Numerology-main.zip`: `668a114194c0baa3792bee2be0be845aad74a353c239083b07c7fb2007623c9b`
