# Brotherhood project canon v0.5.20

> **STATUS NOTE (Cycle 0004, 2026-08-09): HISTORICAL VERSION / SUPERSEDED FOR CURRENT COMPATIBILITY AGGREGATION.** Fixed 15-layer/inter-metric weights and Vedic 5% statements below are preserved as historical scope evidence; current target canon is `docs/CANON/BROTHERHOOD_COMPATIBILITY_CANON.md` (independent scores + simple mean of user-selected metrics). Other historical mechanics statements remain evidence unless separately superseded.


- `versionName = 0.5.20`
- `versionCode = 25`
- `applicationId = org.federationofavatars.brotherhood`

## Cycle scope

1. Positive user result after every visual psychological block.
2. Positive discoveries on Home/Profile/Self-analysis.
3. Data-driven horizontally scrollable language carousel.
4. Screenshot-confirmed UX corrections: candidate fit explanation, non-passive chat empty state, aligned profile cards, honest manual Development installation UI and collapsible pilot section.
5. One universal version-independent `android-build.yml`, frozen after this cycle.

## Preserved canon

100×6 tasks, visual-latent-v2, scene-library-v4, 50 latent coordinates, 112 selectable qualities, 48 scenes, 16 paradigms, 8 compositions, 15 Compatibility weights, Vedic 5%, Trust/Compatibility/Completeness/Quality Fit separation, global_id, brand geometry and E2EE boundaries remain unchanged.
