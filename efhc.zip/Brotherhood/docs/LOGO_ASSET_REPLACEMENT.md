# Brotherhood canonical logo — PNG master integrated in v0.5.24; PNG-specific layout corrected in v0.5.27

The project owner supplied the new canonical Brotherhood artwork on 2026-08-08. Binary inspection showed the transport file was JPEG/JFIF despite its `.png` filename; the decoded 1536×1536 RGB pixels were therefore saved losslessly as the real canonical PNG.

Canonical source:
- `brand/logo_brotherhood.png`
- PNG SHA-256 `47657ba1a1f9dd99cb9b275ea485b8bfdf3a5ac19de33f5187934eaf3b573e19`
- byte-exact owner upload provenance: `brand/source_provenance/logo_brotherhood_owner_upload_2026-08-08.jpg` (`22272c9dfbd9710447857011f6e8a7ccad4a501b8941ab1a61ead24516a8eba8`)

Runtime derivatives:
- `brand/logo_brotherhood_1024.png`
- `brand/logo_brotherhood_512.png`
- `brand/logo_brotherhood_256.png`
- `android/app/src/main/res/drawable-nodpi/logo_brotherhood.png`
- adaptive launcher / splash foreground generated from the same PNG
- Android 13 themed-icon alpha derivative generated from the same PNG

The old BR monogram SVG has been retained only in `brand/history/BR_logo_master_v0_5_10.svg` and is no longer an active asset.

Compose renders the full-colour bitmap using `Image` + `ContentScale.Fit`, not a tinted Material `Icon`. The old SVG was a vector glyph inside separate containers; the new PNG is already a complete framed square artwork and must not inherit the SVG inner-glyph sizing model. v0.5.27 restores the known-good total screen footprints: Authentication uses a 96dp PNG slot and the global TopAppBar uses a 38dp PNG slot, both with `ContentScale.Fit` and no extra clip. Adaptive launcher uses the full 108dp artwork layer and lets the OEM mask own launcher cropping.

Visual regression page:
`tools/visual_checks/logo_brotherhood_preview.html`.


## Square-only correction v0.5.27

- Removed `android:roundIcon` and every `ic_launcher_round` resource.
- Removed adaptive launcher XML and monochrome/themed logo derivative.
- Added square-only launcher PNGs at 48/72/96/144/192 px.
- Android 12+ system splash no longer displays the Brotherhood logo because that system surface masks the icon to a circular safe region; the first Compose UI shows the canonical square logo instead.
- In-app Auth remains 96dp square and TopAppBar remains 38dp square, both with `ContentScale.Fit` and no logo clip mask.
