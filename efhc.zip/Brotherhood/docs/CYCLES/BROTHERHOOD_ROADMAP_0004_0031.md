# Brotherhood Roadmap 0004–0031


Status: **SUPERSEDED BY HOSPITALITY ROADMAP INSERTION — current: `docs/CYCLES/BROTHERHOOD_ROADMAP_0004_0035.md`**
Historical numbering is retained below for provenance; do not use its `NEXT_PLANNED` markers as current state.
Status: **ACTIVE OWNER-RESTRUCTURED ROADMAP**

This is the 28-cycle research/product sequence. Runtime implementation is authorized only by each later cycle's explicit scope; research specs alone do not grant code-write permission.

| Cycle | Status | Result | Scope | Exit gate |
|---|---|---|---|---|
| 0004 | COMPLETED | Compatibility Research Foundation | Большая research/product documentation base, modular canon, source registry, cause map, source→claim matrix, visual test program, roadmap. Runtime unchanged. | All required canon/methodology docs exist; Q28 reflected; protected guard PASS. |
| 0005 | COMPLETED | Scientific Source Registry & Evidence Taxonomy | Deeper web/full-text source review, licensing/use constraints, effect-level claim extraction, bibliography and open questions. | Claim ledger has population/method/effect/limits for priority claims; licenses resolved where needed. |
| 0006 | COMPLETED | Psychological Construct Architecture | Big Five/IPIP, HEXACO coordinate family, IPC, attachment/conflict/responsiveness/trust/risk and Brotherhood latent hypotheses; 23-record construct registry; overlap/ontology/relation taxonomy; reference-battery architecture. Runtime unchanged. | Construct map + reference battery + anti-double-counting map + source/role relation matrices complete; all Brotherhood-specific additions remain HYPOTHESIS/REQUIRES_VALIDATION. |
| 0007 | COMPLETED | Visual Stimulus Scientific Program | Stimulus taxonomy, forced-choice design, balance/social desirability, item bank metadata, hypothesis registry, asset requirements. | Protected 600-item bank fully mapped for research metadata without unauthorized mechanics edits. |
| 0008 | COMPLETED | Calibration & Psychometric Validation Protocol | Cohorts, reference battery, reliability/test-retest, convergent/discriminant validity, cross-validation, bias, locale equivalence, holdout. | Independent protocol review; analysis plan frozen before calibration claims. |
| 0009 | COMPLETED | Psychological Compatibility Engine v1 Research Spec | Role-context dyadic models; similarity/complementarity/asymmetry; pair-feature registry; score semantics 0..100; dyadic method/privacy/13-locale gates; no production activation. | Versioned research spec + pair features + role contracts + baselines/challengers + validation/model-manifest gates complete; runtime scoring unchanged. |
| 0010 | COMPLETED | Friendship Compatibility Science | Friendship quality, reciprocity, responsiveness, disclosure, maintenance, conflict/repair, shared activities, longitudinal outcomes. | Friend role construct/outcome model + confound plan. |
| 0011 | COMPLETED | Business Partner Compatibility Science | Decision/risk style, responsibility, execution, leadership/complementarity, value conflict, trust boundary. | Business role model + outcome/baseline plan. |
| 0012 | COMPLETED | Worker / Team Fit Science | Person-job/group/supervisor fit, vocational interests, work style, competence boundary. | Worker/team research model separates PC/QF/Trust. |
| 0013 | COMPLETED | Mentor / Project Partner Compatibility | Mentoring expectations, communication, reciprocity, experience/needs fit, project execution/complementarity. | Directional mentor + project-partner role science, outcomes/confounds, 13-locale plan and Q34 exact-score semantics complete; runtime/protected mechanics unchanged. |
| 0014 | COMPLETED | Interests Compatibility Engine | Hobby/social/activity/professional interests; transparent IC-R0; RIASEC-like vocational reference; research exposure/feedback/status/outcome architecture. | Independent IC spec + transparent baseline + Q35 research-platform contracts complete; runtime/DB unchanged. |
| 0015 | COMPLETED | Values Compatibility Engine | Refined human-value priorities, explicit scoring/normalization provenance, congruence/conflict challengers, role/context interpretation and research outcomes. | Frozen VC-R0 + transparent VC-R0.1 + VC-R1/2/3/4 challengers + 13-locale comparability/outcome governance; production inactive. |
| 0016 | COMPLETED | Communication Compatibility Engine | Disclosure, responsiveness, directness, cadence, autonomy, feedback, conflict/repair. | Independent CC candidate method + dyadic validation plan. |
| 0017 | COMPLETED | Lifestyle Compatibility Engine | Geography, schedule, habits, activities, meetings/online style, constraints/preferences. | Independent interpretable LC model + sensitive-data policy. |
| 0018 | COMPLETED | Brotherhood Personality-Type Engine | Soft probabilistic typology over continuous dimensions; private latent profile boundary. | PT candidate model/versioning; no hard binary public labels. |
| 0019 | NEXT_PLANNED | Enneagram Engine | Exact typological method, evidence status, independent score, limitations/versioning. | EN independent engine spec stays typological/experimental. |
| 0020 | PLANNED | Numerology Engine | Choose/fix exact tradition, formula/provenance, independent 0..100, honest evidence class. | NU method fully reproducible and separately labeled. |
| 0021 | PLANNED | Astrology / Zodiac Engine | Zodiac and optional future natal/synastry layers, provenance/evidence boundary, independent score. | AS method version and privacy/input requirements fixed. |
| 0022 | PLANNED | Quality Fit / SearchIntent v2 | Directional desired-person vector by role, requirements/qualities, hidden-profile mapping and safe explanation. | QF remains asymmetric/separate and passes privacy/baseline review. |
| 0023 | PLANNED | Trust v2 | Identity/reliability/moderation/interaction evidence, fairness/privacy/appeals, no Compatibility fusion. | Trust model and due-process policy versioned. |
| 0024 | PLANNED | Unified Compatibility Service & Checkbox Aggregation | Metric registry/preferences/version history; independent scores; simple selected-score arithmetic mean only. | No hidden inter-metric weights; missing-data behavior and version history tested. |
| 0025 | PLANNED | Compatibility Page + Metric Detail IA | Diia-like service page, role selector, checkboxes, metric detail, QF/Trust separation, resume + direct message path. | UX contract approved; no latent disclosure; responsive/accessibility checks. |
| 0026 | PLANNED | Backend / PostgreSQL Compatibility Architecture | Tables/API/contracts/model manifests/results/preferences/validation runs/outcomes; migration only under explicit code authorization. | Architecture/migration review complete before implementation. |
| 0027 | PLANNED | Release-Parity Simulation Engine v2 | Mirror full backend tables/routes/state/lifecycle/metrics/QF/Trust in investor HTML without simplification. | Simulation contract parity + persistence/error/offline scenarios verified. |
| 0028 | PLANNED | Longitudinal Outcome Research Layer | Consent-based 30/90/180 outcomes, project/friend success labels, research warehouse, no auto-learning. | Temporal leakage, consent, provenance and retention guards pass. |
| 0029 | PLANNED | Fairness, Privacy, Ethics, Explainability | Bias/proxy leakage, consent, delete/export, research opt-in, explanation policy. | Formal privacy/fairness release gates and rollback paths exist. |
| 0030 | PLANNED | Multilingual Controlled Pilot | 13-locale calibration waves (`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`), locale equivalence, position/latency/retest, manual review. | Versioned candidate model reaches declared evidence status or remains hypothesis. |
| 0031 | PLANNED | Integrated Investor / Release Candidate | Full backend + APK/frontend + release-parity HTML + evidence-qualified engines + security/reliability/investor docs + rollout gates. | No false PASS: CI/device/live/production gates independently evidenced. |

### Cross-cycle invariants
Protected 100×6 test mechanics stay owner-locked; Compatibility/QF/Trust remain separate; no hidden cross-metric weights; alternative systems remain optional/evidence-labeled; simulation stays release-parity; outcomes never auto-mutate production; APK/device/LIVE claims require corresponding external evidence.

### 0007 completion note
Completed at documentation revision `v0.5.36-docs-cycle0007`: expanded visual scientific program, runtime read-only snapshot, primitive/composition registries, stimulus hypothesis schema, response-process/position/latency controls, social-desirability balance, holdout/cross-validation and evidence map. Protected mechanics unchanged; cycle 0008 then established the 13-locale calibration/validation architecture and structural i18n runtime expansion.


### 0008 completion note
Cycle 0008 establishes the intended-use validation architecture, calibration cohorts, reference-battery execution, reliability/test-retest, construct/convergent/discriminant validation, MTMM, measurement invariance and DIF/item-bias protocols, sample-size/power/precision planning, holdout/external replication, promotion gates and machine-readable validation-run schema. The canonical multilingual scope is now exactly 13 locales: `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`. Android/shared locale registries and backend calibration defaults are structurally expanded to all 13; protected 100×6 content/scoring is unchanged. Runtime source milestone advances to `v0.5.32 / versionCode 37` because user-visible i18n runtime changed. Semantic/native linguistic QA and psychometric equivalence are not claimed for all locales; those remain explicit validation gates. Next = 0009.

### 0009 completion note
Completed at development revision `v0.5.38-cycle0009`: actionable source/locale documentation tails from 0005–0008 were reconciled; PC v1 is specified as a role-specific dyadic research engine with construct×role relation hypotheses, actor/partner dependence, method-bias controls, versioned `0..100` method-index semantics, baseline/challenger comparison, privacy/explanation and all-13-locale validation gates. No production compatibility coefficient or protected test mechanic changed. Next = 0010.

## Cycle 0010 completion — 2026-08-10
`0010 Friendship Compatibility Science` completed as research/documentation scope. Next major cycle: `0011 Business Partner Compatibility Science`. See `docs/research/roles/friendship/INDEX.md`.

### Cycle 0011 completion evidence — v0.5.40-cycle0011
Cycle 0011 completes Business Partner Compatibility Science as research/documentation work. Scientific registry expands 93→108 and claim ledger 45→58; a business-partner construct/process boundary, role-governance model, conflict/repair model, outcome hierarchy, causal/confound plan, baseline/validation plan, longitudinal data contract and exact 13-locale plan are established. Team/venture evidence cannot silently become pair coefficients. PC/QF/Trust/VC/CC/IC/LC remain separate. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0012.

### Cycle 0012 completion evidence — v0.5.41-cycle0012
Cycle 0012 completes Worker / Team Fit Science as research/documentation work. Scientific registry expands 108→120 and claim ledger 58→70; PJ/PG/PS fit, vocational interests, competence/QF boundaries, teamwork processes, team cognition, psychological safety, team efficacy, level-of-analysis and exact 13-locale validation are separated. Q33 introduced internal research humility/model plasticity; **Q34 in cycle 0013 later clarified the controlling product semantics**: Brotherhood shows the exact `0..100%` output of the active approved algorithm/version for the declared inputs, and a later approved model may recalculate a different exact value. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0013.


### Cycle 0013 completion evidence — v0.5.42-cycle0013
Cycle 0013 completes Mentor / Project Partner Compatibility as research/documentation work. Scientific registry expands 120→132 and claim ledger 70→81. Mentor is explicitly directional; project partner is peer/mutual by default with ordered role mode only when roles are explicit. PC/QF/Trust/CC/VC/IC/LC boundaries, mentor expectations/functions/reciprocity, project coordination/expertise/interdependence, causal/outcome plans and exact 13-locale validation are documented. Q34 supersedes the over-broad product reading of Q33: scientific models remain versioned/improvable, while the product exposes the exact `0..100%` result of the active algorithm version/input snapshot. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0014.

### Cycle 0014 completion note
Interests Compatibility now has a versioned research specification and transparent IC-R0 benchmark. Q35 adds a product/research architecture for storing pre-exposure score/model snapshots, recommendation exposure, explicit feedback, side-specific relationship statuses and longitudinal outcomes. These data can support future model research only through reviewed/versioned validation; no backend/DB telemetry implementation or production auto-learning was authorized in cycle 0014.


### Cycle 0015 hardening evidence — v0.5.45
Historical `VC-R0` remains frozen/reproducible. Registry = 162 sources (60 + 102); claim ledger = 111; production inactive. Next = 0016.


### Cycle 0016 completion note
Communication Compatibility now has an independent research-only v1 architecture with pre-exposure input/construct/pair-feature registries, transparent `CC-R0`, role/directional/nonlinear challengers, explicit missingness/coverage, 13-locale validation and exposure-time longitudinal outcome provenance. Post-contact actual reply latency, reciprocity, conflict and repair remain process/outcome evidence and cannot leak backward into historical CC predictors. Scientific registry `162->172`; claim ledger `111->123`; original owner-authorized source snapshot remains exactly 60. Android/backend/database/protected 100x6 and production scoring remain unchanged. Next: `0017 — Lifestyle Compatibility Engine`.

### Cycle 0018 completion
Brotherhood Personality-Type Compatibility now uses a continuous-first research architecture over the existing five Brotherhood-32 axes, a soft 32-prototype interpretation distribution and transparent `PTC-R0`; hard type remains an interpretation layer. The existing runtime threshold classifier and legacy compatibility formula remain untouched and are not promoted as research-validated coefficients. New profile/dyadic evidence is synthesized through Q36; source registry `179->189`, claim ledger `137->151`; exact 13 locales and Q35 exposure-time provenance are defined. Next: `0019 — Enneagram Engine`.
