# Brotherhood — canonical major cycles 0001–0035

Status: **SUPERSEDED AS ACTIVE ROADMAP by `BROTHERHOOD_CYCLES_0001_0041.md` after owner functional-reality audit 2026-08-11. Retained as historical predecessor.**

## Historical/runtime gates
- `0001` remains completed historical foundation.
- `0002` remains `CHECKPOINT_PENDING` until exact GitHub APK/device evidence.
- `0003` remains `LIVE_E2E_PENDING / EXTERNAL_GATE`; later owner-authorized cycles do not claim its live acceptance.
- Cycles `0004–0018` preserve their completed scientific/product milestones.
- Owner directive dated 2026-08-10 inserts Hospitality as cycles `0019–0022` and moves the previously planned Enneagram-and-later tail by `+4` without deleting any prior planned major outcome.

## Major roadmap
| Cycle | Status | Major result | Scope | Exit gate |
|---|---|---|---|---|
| 0004 | COMPLETED | Compatibility Research Foundation | Большая research/product documentation base, modular canon, source registry, cause map, source→claim matrix, visual test program, roadmap. Runtime unchanged. | All required canon/methodology docs exist; Q28 reflected; protected guard PASS. |
| 0005 | COMPLETED | Scientific Source Registry & Evidence Taxonomy | Deeper web/full-text source review, licensing/use constraints, effect-level claim extraction, bibliography and open questions. | Claim ledger has population/method/effect/limits for priority claims; licenses resolved where needed. |
| 0006 | COMPLETED | Psychological Construct Architecture | Big Five/IPIP, HEXACO coordinate family, IPC, attachment/conflict/responsiveness/trust/risk and Brotherhood latent hypotheses; 23-record construct registry; overlap/ontology/relation taxonomy; reference-battery architecture. Runtime unchanged. | Construct map + reference battery + anti-double-counting map + source/role relation matrices complete; all Brotherhood-specific additions remain HYPOTHESIS/REQUIRES_VALIDATION. |
| 0007 | COMPLETED | Visual Stimulus Scientific Program | Stimulus taxonomy, forced-choice design, balance/social desirability, item bank metadata, hypothesis registry, asset requirements. | Protected 600-item bank fully mapped for research metadata without unauthorized mechanics edits. |
| 0008 | COMPLETED | Calibration & Psychometric Validation Protocol | Cohorts, reference battery, reliability/test-retest, convergent/discriminant validity, cross-validation, bias, locale equivalence, holdout. | Independent protocol review; analysis plan frozen before calibration claims. |
| 0009 | COMPLETED | Psychological Compatibility Engine v1 Research Spec | Role-context dyadic models; similarity/complementarity/asymmetry; pair-feature registry; score semantics 0..100; dyadic method/privacy/13-locale gates; no production activation. | Versioned research spec + pair features + role contracts + baselines/challengers + validation/model-manifest gates complete; runtime scoring unchanged. |
| 0010 | COMPLETED | Friendship Compatibility Science | Friendship quality, reciprocity, responsiveness, disclosure, maintenance, conflict/repair, shared activities, longitudinal outcomes. | Friend role construct/outcome model + confound plan. |
| 0011 | COMPLETED | Business Partner Compatibility Science | Decision/risk style, responsibility, execution, leadership/complementarity, value conflict, trust boundary. | Business role model + outcome/baseline plan. |
| 0012 | COMPLETED | Worker / Team Fit Science | Person-job/group/supervisor fit, vocational interests, work style, competence boundary. | Worker/team research model separates PC/QF/Trust. |
| 0013 | COMPLETED | Mentor / Project Partner Compatibility | Mentoring expectations, communication, reciprocity, experience/needs fit, project execution/complementarity. | Directional mentor + project-partner role science, outcomes/confounds, 13-locale plan and Q34 exact-score semantics complete; runtime/protected mechanics unchanged. |
| 0014 | COMPLETED | Interests Compatibility Engine | Hobby/social/activity/professional interests; transparent IC-R0; RIASEC-like vocational reference; research exposure/feedback/status/outcome architecture. | Independent IC spec + transparent baseline + Q35 research-platform contracts complete; runtime/DB unchanged. |
| 0015 | COMPLETED | Values Compatibility Engine | Schwartz refined values, instrument-aware centered priorities, similarity/conflict, nonlinear/directional challengers, longitudinal outcome validation. | Independent VC-R0.1 benchmark + challenger/locale/research-platform contracts; production inactive. |
| 0016 | COMPLETED | Communication Compatibility Engine | Disclosure, responsiveness, directness, cadence, autonomy, feedback, conflict/repair. | Independent CC candidate method + dyadic validation plan. |
| 0017 | COMPLETED | Lifestyle Compatibility Engine | Geography, schedule, habits, activities, meetings/online style, constraints/preferences. | Independent interpretable LC model + sensitive-data policy. |
| 0018 | COMPLETED | Brotherhood Personality-Type Engine | Soft probabilistic typology over continuous dimensions; private latent profile boundary. | PT candidate model/versioning; no hard binary public labels. |
| 0019 | COMPLETED | Hospitality Integration Plan / Research Outcome Architecture | Owner TZ ingestion, route-scoped implementation decomposition, safety/privacy boundaries, research-platform bridge and downstream roadmap renumbering. No runtime change. | Plan maps every TZ requirement to cycles 0020–0022; owner-locked 100×6/runtime unchanged; next implementation cycle explicit. |
| 0020 | COMPLETED | Hospitality Foundation + Backend Lifecycle | Merge original TZ 0032+0033: migration/schema, HostProfile/Availability/StayRequest/events/confirmations/reviews/restrictions, AEAD private location, eligibility, APIs, atomic capacity, lifecycle/scheduler, conversation binding, push/privacy, backend/DB/security tests. | Backend lifecycle works create→completed behind feature flag; exact location protected; migration/schema/OpenAPI parity; no protected assessment changes. |
| 0021 | COMPLETED | Hospitality Verified Stay / Reviews / Trust + Android UX | Merge original TZ 0034+0035: confirmations, verified_interactions, blind reviews, reputation/restrictions/moderation/appeals plus Android models/repository/screens/discovery/map/chat cards/push/secure local store/offline and all 13 locales. | Verified stay evidence and blind-review anti-retaliation work; full APK user flow works without pre-acceptance location disclosure; Trust/Account Rating/Compatibility remain separate. |
| 0022 | SOURCE_COMPLETED / VISUAL_ACCEPTANCE_REOPENED | Hospitality Release-Parity / Research Outcomes / Security / E2E RC | Original TZ 0036 plus Brotherhood Research Platform bridge: simulation/demo parity, lifecycle/security/adversarial/E2E, OpenAPI/migration parity, protected guard, verified-stay longitudinal linkage and privacy-safe global meeting indicators. | Integrated Hospitality RC only after independent evidence gates; historical exposure→verified stay→relationship outcome provenance works; no auto-learning. |
| 0023 | PLANNED_BLOCKED_BY_0022_UI_ACCEPTANCE | Enneagram Engine | Exact typological method, evidence status, independent score, limitations/versioning. | EN independent engine spec stays typological/experimental. |
| 0024 | PLANNED | Numerology Engine | Choose/fix exact tradition, formula/provenance, independent 0..100, honest evidence class. | NU method fully reproducible and separately labeled. |
| 0025 | PLANNED | Astrology / Zodiac Engine | Zodiac and optional future natal/synastry layers, provenance/evidence boundary, independent score. | AS method version and privacy/input requirements fixed. |
| 0026 | PLANNED | Quality Fit / SearchIntent v2 | Directional desired-person vector by role, requirements/qualities, hidden-profile mapping and safe explanation. | QF remains asymmetric/separate and passes privacy/baseline review. |
| 0027 | PLANNED | Trust v2 | Identity/reliability/moderation/interaction evidence, fairness/privacy/appeals, no Compatibility fusion. | Trust model and due-process policy versioned. |
| 0028 | PLANNED | Unified Compatibility Service & Checkbox Aggregation | Metric registry/preferences/version history; independent scores; simple selected-score arithmetic mean only. | No hidden inter-metric weights; missing-data behavior and version history tested. |
| 0029 | PLANNED | Compatibility Page + Metric Detail IA | Diia-like service page, role selector, checkboxes, metric detail, QF/Trust separation, resume + direct message path. | UX contract approved; no latent disclosure; responsive/accessibility checks. |
| 0030 | PLANNED | Backend / PostgreSQL Compatibility Architecture | Tables/API/contracts/model manifests/results/preferences/validation runs/outcomes; migration only under explicit code authorization. | Architecture/migration review complete before implementation. |
| 0031 | PLANNED | Release-Parity Simulation Engine v2 | Mirror full backend tables/routes/state/lifecycle/metrics/QF/Trust in investor HTML without simplification. | Simulation contract parity + persistence/error/offline scenarios verified. |
| 0032 | PLANNED | Longitudinal Outcome Research Layer | Consent-based 30/90/180 outcomes, project/friend success labels, research warehouse, no auto-learning. Hospitality verified stays become one high-value real-world outcome source, not an automatic compatibility coefficient. | Temporal leakage, consent, provenance and retention guards pass. |
| 0033 | PLANNED | Fairness, Privacy, Ethics, Explainability | Bias/proxy leakage, consent, delete/export, research opt-in, explanation policy. | Formal privacy/fairness release gates and rollback paths exist. |
| 0034 | PLANNED | Multilingual Controlled Pilot | 13-locale calibration waves (`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`), locale equivalence, position/latency/retest, manual review. | Versioned candidate model reaches declared evidence status or remains hypothesis. |
| 0035 | PLANNED | Integrated Investor / Release Candidate | Full backend + APK/frontend + release-parity HTML + evidence-qualified engines + Hospitality + security/reliability/investor docs + rollout gates. | No false PASS: CI/device/live/production gates independently evidenced. |

## Hospitality sequencing rule
- `0019` is planning/governance only and does **not** implement runtime.
- `0020–0022` are explicitly owner-authorized Hospitality implementation cycles, but each still obeys Operator Kernel route/write boundaries, protected-mechanics guard and evidence gates.
- The owner-supplied implementation specification is preserved verbatim at `docs/CYCLES/HOSPITALITY/BROTHERHOOD_HOSPITALITY_IMPLEMENTATION_TZ_OWNER_INPUT.md`.
- Detailed compressed implementation mapping: `docs/CYCLES/HOSPITALITY/HOSPITALITY_CYCLES_0019_0022_PLAN.md`.

## Numbering / supersession
The previous `BROTHERHOOD_CYCLES_0001_0031.md` and `BROTHERHOOD_ROADMAP_0004_0031.md` remain historical predecessor plans. Where numbering or next-cycle status differs, this `0001–0035` roadmap and `CYCLE_STATUS_REGISTRY.md` control. No historical planned outcome was deleted; the old tail `0019–0031` was shifted to `0023–0035`.

## Reserve
`0036–0100 = UNUSED_RESERVE` until the owner assigns further major work.
