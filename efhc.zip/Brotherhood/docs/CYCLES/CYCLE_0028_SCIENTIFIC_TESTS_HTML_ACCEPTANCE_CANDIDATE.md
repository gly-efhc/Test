# Cycle 0028 — Scientific Test Systems v1 + Full HTML Acceptance Candidate

Date: 2026-08-11  
Initial cycle input DEVELOPMENT HEAD: `Brotherhood_v0_5_61.zip`
Continuation input DEVELOPMENT HEAD: `Brotherhood_v0_5_62.zip`  
Current continuation target DEVELOPMENT archive: `Brotherhood_v0_5_64.zip`  
Status: **SOURCE_HTML_IMPLEMENTED / SCIENTIFIC_BASELINE_V1_ACTIVE / STIMULUS_PROVENANCE_CORRECTION_ACTIVE / VA_BLOCKED**

## Owner correction that triggered the cycle
The owner identified that the previous Tests flow was not enough: the project had a technical 100×6 visual assessment bank and result/report surfaces, but did not yet expose a set of clearly separated scientific test systems materialized from the accumulated research corpus. The owner also explicitly prohibited postponing product calibration for years waiting for an external cohort.

Therefore cycle 0028 changes the recovery checkpoint: scientific-test productization is completed **before** requesting visual acceptance. Visual acceptance itself remains pending until the owner opens and explicitly approves the standalone HTML.

## Active calibration CANON
Current calibration version: `research-calibration-v1`.

Brotherhood calibrates v1 internally from the canonical scientific corpus:

`canonical source → construct contract → visual measurement signals → deterministic scoring → coverage/uncertainty → human result → pair compatibility → Psychological Report`.

Future longitudinal/cohort evidence may justify an explicitly reviewed later model version. It is not a launch prerequisite and never mutates current production scoring automatically.

Canonical documents:
- `docs/CANON/BROTHERHOOD_INTERNAL_SCIENTIFIC_CALIBRATION_CANON.md`;
- `docs/research/psychology/PSYCHOLOGICAL_TEST_SYSTEMS_V1.md`;
- `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md`;
- `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json`.

## Seven independent scientific systems v1

| System ID | Product title | Current series | Primary construct role | Pair compatibility |
|---|---|---:|---|---|
| `traits_core` | Черты и саморегуляция | 20 | broad traits/self-regulation | independent `0–100%` |
| `interpersonal_style` | Межличностный стиль | 10 | interpersonal orientation/relationship style | independent `0–100%` |
| `communication_conflict` | Коммуникация и конфликт | 20 | communication/conflict/repair | independent `0–100%` |
| `trust_support_boundaries` | Доверие, поддержка и границы | 20 | psychological trust tendency/support/boundaries | independent `0–100%` |
| `decision_work_style` | Решения, риск и рабочий стиль | 10 | decision/risk/planning/work style | independent `0–100%` |
| `social_group_role` | Социальная энергия и роль в группе | 10 | social/group/collaboration role | independent `0–100%` |
| `adaptability_uncertainty` | Адаптивность и неопределённость | 10 | adaptability/uncertainty/self-control | independent `0–100%` |

Catalog allocation covers all current assessment series `f001..f100` exactly once. The underlying 100×6 bank is retained as the current versioned v1 item bank; cycle 0028 does not silently alter the existing 600 task mechanics. Owner Q41 continues to allow a future quality-led redesign/version.

## Backend/domain implementation
Added `backend/app/psychological_test_systems.py` with:
- seven versioned system definitions;
- source IDs from the single 217-source SSOT;
- construct/trait-key contracts;
- deterministic aggregate scoring from current visual-latent results;
- evidence-weighting using existing response consistency;
- coverage calculation from series + available constructs;
- status without fabricated zero;
- positive/non-clinical human interpretation labels;
- independent pair similarity for common supported constructs;
- explicit model/calibration/method identifiers.

Public models/API intentionally exclude private raw trait-coordinate maps.

## API implementation
Added:
- `GET /v1/psychological-test-systems`;
- `GET /v1/psychological-test-systems/{global_id}`;
- `GET /v1/psychological-test-systems/{global_id}/{system_id}`;
- `GET /v1/psychological-test-systems/compatibility/{requester_global_id}/{candidate_global_id}`.

Current generated source contract after cycle 0028:
- 94 OpenAPI paths;
- 112 HTTP operations;
- 50 migration-defined DB tables;
- 21 Android AppRoutes.

## Simulation Engine implementation
Mandatory path remains:

`backend/domain + DB → routes → BackendSimulator → SimulationEngine → route responses/client projection → frontend`.

Cycle 0028 mirrors the four new test-system route families through Simulation Engine. Existing 200 candidate fixtures remain backend-simulator population only; candidate assessment rows are generated deterministically through the current assessment definitions/loadings so the seven pair compatibilities are computed from compatible evidence rather than arithmetic decoration.

HTML persistence schema is `12`.

## HTML test UX/provenance candidate v0_5_40
Active versioned artifact after owner stimulus review: `tools/visual_checks/BROTHERHOOD_UI_SIMULATOR_v0_5_40.html`.

The active root/tools HTML mirrors expose:
- Tests Home with seven scientific systems, progress, coverage, source/calibration trace;
- test-system detail with constructs/sources/assigned series;
- execution through the current versioned item bank;
- per-series result + updated aggregate system result;
- Psychological Profile with all seven systems;
- Psychological Report v2 with one section per system, overall synthesis, strengths/growth, coverage, scientific source trace, methodology/calibration, limitations and immutable history;
- Candidate Compatibility Details with seven independent psychological-system compatibilities in addition to independent Q28 metrics;
- explicit internal-calibration wording: current scoring does not wait for a future multi-year external cohort.

## Psychological Report v2
Report model/version is upgraded to scientific-system synthesis. Report input remains a safe immutable snapshot and history continues to use the cycle-0024 persistence/API contract. The report does not persist/expose raw private visual response traces or private trait coordinate maps.

## Tests / evidence
Targeted backend scientific-system tests verify:
- exactly seven systems;
- exactly 100 unique assigned assessment series;
- canonical scientific source anchors;
- deterministic internal calibration;
- independent pair compatibility in `0–100%`;
- missing evidence is not represented as fake zero;
- private trait coordinates are absent from public API payloads.

HTML evidence includes parser/no-network validation, two inline JavaScript syntax checks and a Node SimulationEngine route probe covering all current HTTP operations.

Final exact test counts are recorded in `reports/generated/reports_00007_cycle_0028_scientific_tests_html_acceptance_candidate.md` after package validation.

## Stage matrix
- R = PASS — existing canonical scientific corpus/source trace used;
- S = PASS — system/calibration/report contracts written;
- B = SOURCE_IMPLEMENTED_LOCAL_TESTED;
- SIM = PASS_LOCAL_DETERMINISTIC;
- H = PASS — standalone acceptance candidate implemented;
- VA = PENDING — only owner can close this;
- A = NOT_STARTED — intentionally blocked until VA;
- CI = NOT_RUN;
- E2E = NOT_RUN.

## Sequencing note
Cycle 0027 remains `PLANNED / UNCOMPLETED`; it was not silently marked complete. The owner explicitly directed work on 0028. Trust/Hospitality/Services still require their planned recovery unless explicitly superseded later.

Cycles 0043–0053 are reinterpreted as Test Platform **v2 hardening/expansion** because v1 systems now exist in cycle 0028. They can decouple future batteries from legacy 100×6, improve stimuli, add instruments, harden language/fairness/reproducibility and version the models without blocking the present product.

## Exit gate
Current cycle stops at **Full HTML Acceptance Candidate / VA_PENDING**. Next legal visual-development action is owner review/correction of `BROTHERHOOD_UI_SIMULATOR_v0_5_39.html`. Compose mirror and GitHub CI/APK remain blocked until explicit owner `VA=PASS`.

## Q43 continuation — corrected launch logic

The owner clarified that future Brotherhood outcome metrics may require many years to mature and therefore cannot be the prerequisite for the first usable model. Cycle 0028 now explicitly separates:

- **launch scientific baseline** — existing scientific corpus is synthesized into the current v1 test/scoring/compatibility contract now;
- **post-release recalibration** — versioned outcome evidence collected after launch may later support v2/v3.

New machine synthesis: `docs/research/psychology/SCIENTIFIC_BASELINE_SYNTHESIS_V1.json`. It maps the seven systems to systematic evidence bundles derived from the single source map and claim ledger, and freezes compatibility feature IDs needed for reproducible future outcome analysis.

The public/runtime test-system contract now exposes `evidence_bundle_version`, `release_baseline_status`, `future_recalibration_policy` and compatibility feature IDs in the catalog while keeping user trait coordinates private.

## Owner stimulus/UX correction
Owner visual review identified two concrete defects: test execution jumps during answer selection, and the current pictures do not have provenance as literal scientific-study images. Both findings are confirmed by code/source audit.

- `scene-library-v4` is generated by Brotherhood `VisualAssessmentFactory`/Canvas and is therefore `GENERATED_PROTOTYPE`, not a scientific-source image bank.
- `VIS-FC-IMG-001` supports a scientifically studied image-based forced-choice development method. The paper created image concepts from Goldberg/IPIP statements and sourced its own assets from Shutterstock; that does not validate or license Brotherhood's current Canvas scenes.
- HTML v0_5_40 prevents full-screen rerender/scroll reset on answer selection and removes source IDs, calibration IDs, model IDs, hashes and Simulation Engine terminology from the respondent test flow.
- New active provenance contract: `docs/research/psychology/SCIENTIFIC_STIMULUS_PROVENANCE_CONTRACT_V1.md`.
- First item-level content bank: `docs/research/psychology/SCIENTIFIC_VISUAL_ITEM_CONCEPTS_V1.json`.
- Seven-system concept bank: `docs/research/psychology/SCIENTIFIC_SYSTEM_ITEM_CONCEPT_BANK_V1.json` — 70 Brotherhood-original science-derived concepts, 10/system, 42 constructs; total current content concepts 90; release visual assets 0.

Updated stage: `H=PARTIAL_CORRECTED / VA=BLOCKED_STIMULUS_PROVENANCE`. Scientific test filling continues; this cycle is not ready to close.
