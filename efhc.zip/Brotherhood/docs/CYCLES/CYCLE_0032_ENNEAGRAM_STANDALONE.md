# Cycle 0032 — Enneagram Standalone Application + Full Development Demo Runtime

Status: **SOURCE_HTML_IMPLEMENTED / EN_BROTHERHOOD_CORE_PROFILE_V1 / DEVELOPMENT_FULL_DEMO_V1 / ROUTE_BACKED_SIMULATION / VA_PENDING**  
Date: 2026-08-13  
Input DEVELOPMENT HEAD: `Brotherhood_v0_5_72.zip`  
Target DEVELOPMENT HEAD: `Brotherhood_v0_5_73.zip`

## Owner objective

1. Productize `Развитие → Эннеаграмма` as a complete standalone optional application.
2. Correct the incomplete Development-demo interpretation from cycle 0031: the owner requires the **full `Развитие` demo to be active in Simulator code**, not merely a visible root tab.
3. Preserve HTML-first visual acceptance; do not mirror Compose/APK before owner VA.

## Development full-demo correction

Cycle 0031 correctly established that the HTML root tab existed, but that did **not** satisfy the owner requirement for a fully active Development demo. The active HTML had mixed readiness:

- Tests had only a partial seeded result set;
- Associative methods had seed results;
- Numerology and Zodiac had seeded personal readings but comparison/history state was not guaranteed as one unified demo scenario;
- Enneagram was still a decorative `modelScreen` placeholder.

Cycle 0032 therefore makes the Simulator itself authoritative for a complete demo bootstrap:

`DEVELOPMENT_FULL_DEMO_V1`

The default schema-17 simulator state now contains:

- Tests: **12/12** user-facing apps with result/history data;
- Associative/Implicit: **3/3** implemented methods with saved results;
- Numerology: saved reading + saved NU pair comparison/history;
- Zodiac: saved reading + saved AS pair comparison/history;
- Enneagram: saved reading + saved EN pair comparison/history.

A dedicated workbench action `Development demo` / application action `ACTIVATE_DEVELOPMENT_DEMO` restores this complete scenario through Simulator state. Root navigation still correctly defaults to `Профиль`; the Development tab is active and immediately demonstrable when opened.

This correction is independent of the still-stale Android pre-Q45 root mirror. Android remains unchanged because the current owner request is explicitly about Simulator/demo activation.

## Enneagram authority and scientific boundary

Active method:

`EN_BROTHERHOOD_CORE_PROFILE_V1`

Existing Brotherhood instrument basis:

- **18 local visual items**;
- exactly **2 items per each of 9 Enneagram types**;
- deterministic visual choice generation already present in the Android `CoreProfileCatalog`;
- deterministic type/wing selection already present in `EnneagramEngine`;
- existing independent Q28 EN pair scorer reused, not reinvented.

Versioned contracts:

- instrument: `enneagram-core-profile-18-v1`;
- reading: `enneagram-reading-v1`;
- catalog: `enneagram-type-catalog-v1`;
- compatibility: `enneagram-existing-runtime-v1`;
- independent Q28 metric: `EN 0–100%`.

Active scientific source boundary: `ENNEA-001` — systematic review reporting mixed reliability/validity evidence. Therefore:

- Enneagram is **typological/experimental**;
- it is not presented as validated psychometrics;
- it is not diagnosis;
- EN is not a probability of friendship/relationship success;
- EN never automatically changes PC, Trust, Account Rating, Hospitality Reputation or Quality Fit.

No additional type-character descriptions are invented from model memory. The standalone type catalog exposes only the existing type labels and adjacent wing candidates until an approved descriptive source contract exists.

## Existing type/wing runtime retained

Type labels preserved from current Brotherhood runtime:

1. Реформатор
2. Помощник
3. Достигатель
4. Индивидуалист
5. Исследователь
6. Лоялист
7. Энтузиаст
8. Защитник
9. Миротворец

Reading scoring preserves the existing Android semantics:

- two visual items contribute to each type score;
- type = maximum type score;
- wing = stronger of the two circularly adjacent types;
- ties preserve existing deterministic ordering.

Public instrument responses expose visual composition fields but **never expose hidden scoring keys/loadings**.

## Independent EN compatibility

Existing Brotherhood/Q28 formula is retained exactly:

- same main type: `88`;
- otherwise circular type distance on the 1..9 ring;
- base: `82 - 6 × circular_distance`;
- `+10` if either person's wing points to the other person's main type;
- clamp to `35..95`.

Standalone Enneagram and Q28 EN use one shared scorer. Exhaustive regression covers all **81 ordered main-type pairs** with supported wings.

Missing type data is insufficient data / conflict, not a fabricated zero.

## Persistence / DB

Migration:

`database/migrations/0017_enneagram_vnext.sql`

Adds only:

- `enneagram_readings`;
- `enneagram_pair_comparisons`.

Reading snapshots are immutable/versioned. Identical 18-answer input under the same instrument/calculation version is idempotent. Pair history freezes type/wing inputs and scoring provenance for later reread.

Persistence schema becomes **17**.

## Public Enneagram API

1. `GET /v1/enneagram/spec`
2. `GET /v1/enneagram/instrument`
3. `GET /v1/enneagram/types/{locale}`
4. `GET /v1/enneagram/types/{locale}/{type_id}`
5. `POST /v1/enneagram/readings`
6. `GET /v1/enneagram/readings/{global_id}`
7. `GET /v1/enneagram/readings/{global_id}/latest`
8. `GET /v1/enneagram/readings/{global_id}/{reading_id}`
9. `POST /v1/enneagram/compatibility`
10. `GET /v1/enneagram/compatibility/{global_id}/history`

## HTML / Simulation

Active standalone acceptance candidate: `BROTHERHOOD_UI_SIMULATOR_v0_5_48.html`.

`Развитие → Эннеаграмма` exposes:

- standalone home/current saved profile;
- **Метод** — 18-item and evidence boundary disclosure;
- **Прохождение** — 18 four-choice visual tasks;
- **Профиль** — type, wing and all 9 deterministic type scores;
- **9 типов** — route-backed catalog without invented personality claims;
- **История** — immutable reading snapshots / reread / retake;
- **Сравнение** — independent EN `0–100%`, circular distance, wing bonus, explanation and saved pair history/reread.

Development home now reads latest Numerology, Zodiac and Enneagram summaries through routes and visibly reports `5/5 ONLINE` for the full demo bootstrap.

All current Development product data follows:

`domain/DB → routes → BackendSimulator → SimulationEngine → route responses → frontend`.

Current source/simulation contract:

- **136 OpenAPI paths**;
- **155 HTTP operations**;
- **58 migration-defined DB tables**;
- **21 Android AppRoutes**;
- **200 deterministic synthetic candidates**;
- persistence schema **17**.

Local Node SimulationEngine operation probe: **155/155 PASS / 0 failures / 58 tables**.

## Verification state before final package gate

Completed:

- Operator Kernel `validate-config`: **PASS — 16 routes / 8 hooks / 6 agents / 6 skills**;
- full backend regression: **115/115 PASS**;
- architecture/current-product regression: **285/285 PASS**;
- JSON validation: **127/127 PASS**;
- Enneagram backend suite: **8/8 PASS**;
- Numerology + Zodiac + Enneagram targeted backend: **27/27 PASS**;
- protected Development/0028/0029/0030/0031/0032 focused regression: **42/42 PASS**;
- standalone/Q28 EN parity covered for **81 ordered type pairs**;
- HTML parser: **PASS**;
- JavaScript syntax: **2/2 PASS**;
- active HTML copies synchronized byte-for-byte;
- full embedded Simulator operation probe: **155/155 PASS / 0 failures / 58 tables**;
- full Development demo bootstrap assertion: schema17, demo active, Tests 12/12, Associative 3/3, NU/AS/EN reading+comparison seeds.

Backend/architecture/current-product regression is complete. Manifest/file-map parity and deterministic package verification are executed at the final package gate after the source tree is frozen.

## Stage state

- R: PASS
- S: PASS
- B: PASS
- H: PASS
- VA: **PENDING**
- A: NOT_STARTED_BY_DESIGN
- CI: NOT_RUN
- E2E: NOT_RUN

## Explicitly not claimed

- owner visual acceptance: PENDING;
- Android Compose mirror: NOT_STARTED_BY_DESIGN;
- APK/AAB as visual acceptance mechanism: NOT_RUN;
- GitHub CI/APK/device: NOT_RUN;
- live PostgreSQL migration `0017`: NOT_RUN;
- live/device E2E: NOT_RUN.

## Next

`0033 — Quality Fit / SearchIntent v2` after cycle-0032 package/owner review corrections.

## Browser runtime hotfix — v48

The v47 acceptance candidate was subsequently proven broken in real Chromium despite HTML parser and JavaScript syntax PASS. Root causes were cross-script lexical-scope references (`ZODIAC_SIGN_ORDER` first, then other hidden constants) plus an omitted `testsScreen()` referenced by the route map.

v48 fixes those defects without changing backend/API/DB/Android semantics. Real Chromium verification: **64/64 workbench screens rendered, 0 page errors**, and interactive Development flow PASS across Tests, Associations, Numerology/NU, Zodiac/AS and Enneagram/EN. Static syntax checks are no longer accepted as sufficient standalone-runtime evidence.
