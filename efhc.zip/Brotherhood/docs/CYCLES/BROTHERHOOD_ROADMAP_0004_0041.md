# Brotherhood — owner roadmap 0004–0041

> **STATUS UPDATE 2026-08-11:** this plan is retained as predecessor/history for its already executed milestones. Active assigned planning from cycle 0024 onward is `BROTHERHOOD_ROADMAP_0024_0073.md`. Where future cycle assignments overlap, the 0024–0073 plan is authoritative.


Status: **ACTIVE AFTER FUNCTIONAL-REALITY AUDIT / 2026-08-11**

This file is the detailed current roadmap companion to `BROTHERHOOD_CYCLES_0001_0041.md`.

## Why this roadmap supersedes 0004–0035
The previous roadmap correctly produced extensive scientific/research artifacts but did not enforce a mandatory transfer from research to finished product. The owner’s 2026-08-11 audit establishes that Tests, psychological analysis, psychological report and the broader UI remain incomplete relative to the research and product CANON. Therefore the immediate priority is product recovery, not additional typology research.

## Evidence gates per major feature
1. `RESEARCH_COMPLETE`
2. `SOURCE_IMPLEMENTED`
3. `HTML_VISUALLY_ACCEPTED`
4. `ANDROID_MIRRORED`
5. `CI_APK_VERIFIED`
6. `LIVE_E2E_VERIFIED`
7. `PRODUCTION_QUALIFIED` where applicable

No earlier gate implies a later one.

## Cycles 0004–0022 — preserved truth
- `0004–0018`: research/science/documentation milestones complete in their own scope; most corresponding production engines remain inactive or productization-pending.
- `0019`: Hospitality planning complete.
- `0020`: Hospitality backend source implementation exists; live DB qualification separate.
- `0021`: Hospitality verified-stay/review/Trust/Android source exists; full owner visual acceptance not achieved.
- `0022`: release-parity/source work plus confirmed CI hotfix exists, but owner rejected the full HTML/product UI; functional-reality audit reopens product completion.

## Cycles 0023–0028 — mandatory Functional/UI Recovery Program

### 0023 — Functional Recovery Foundation — SOURCE_IMPLEMENTED / SUPERSEDED_BY_0024
Implemented in source:
- current assessment bank grouped into 10 independently visible psychological modules: loyalty, integrity, reliability, conflict, boundaries, support, competition, communication, mutual aid, lifestyle;
- meaningful per-test result, strengths/growth/coverage/version and monthly retake gate;
- aggregate Psychological Profile + synthesis/Analysis + versioned Psychological Report snapshot;
- Q28 independent `PC/IC/VC/CC/LC/PT/EN/NU/AS` and selected-metric arithmetic mean;
- each current psychological module can produce its own pair compatibility `0–100%` when common evidence exists;
- existing date-based Numerology exposed as independent `NU=0–100`, not as a hidden fixed percentage;
- first recovery HTML surfaces for Tests/Psychology/Report/My Profile/People/Candidate/Compatibility.

Exit evidence: source recovery exists; persistence/server gaps transferred to 0024; visual acceptance remains pending.

Q41 supersedes permanent-lock interpretation of the historical 100×6 baseline. Future test redesign is allowed only as an explicit versioned quality program with construct, measurement, scoring, validation, migration and result-compatibility work; UI-only cycles must not silently change assessment semantics.

### 0024 — Runtime persistence and server contracts + full simulation — ACTIVE / SOURCE_IMPLEMENTED / FULL_SIMULATION_PARITY / VA_PENDING
Implementation scope:
- immutable Psychological Report persistence/history, safe input snapshot, SHA-256 fingerprint, idempotent save and history/latest/by-id routes;
- persistent Q28 metric selection;
- server-backed `PC/IC/VC/CC/LC/PT/EN/NU/AS`, coverage/status/model provenance and `INSUFFICIENT_DATA` instead of synthetic zero;
- ten independent PC submodule comparators `0–100%` where pair evidence exists;
- current Numerology compatibility as independent date-based `NU`;
- Android network contracts only; no unaccepted Compose visual mirror;
- generated source contract `87 paths / 100 operations / 49 DB tables / 21 AppRoutes`;
- exact simulator chain `backend/domain+DB → routes → BackendSimulator → SimulationEngine → route-shaped responses → frontend`;
- one current synthetic user + exactly 200 deterministic synthetic candidates + 20,100 assessment-result rows;
- report history and compatibility preferences inside simulation state;
- route-backed frontend metrics/report content with no frontend-invented arithmetic offsets;
- official Diia Android source recorded as an architecture/UX donor for feature isolation, reusable screen shell, Back handling and top/body/bottom progressive flows; no code/branding/data copying.

Exit evidence currently: `R=PASS; S=PASS; B=SOURCE_IMPLEMENTED_LIVE_DB_NOT_RUN; H=SOURCE_IMPLEMENTED_FULL_SIMULATION; VA=PENDING; A=NETWORK_CONTRACT_ONLY; CI=NOT_RUN; E2E=NOT_RUN`.

### 0025 — UI Recovery A — HTML owner review — NEXT
Screens/flows:
1. My Profile — digital identity + social/professional resume, privacy/service actions, no self-Compatibility.
2. People — search, role chips, compact filters, advanced filters as secondary flow, person cards.
3. Candidate — person-first hierarchy, biography/professional/interests/goals/social context/actions.
4. Compatibility Details — selectable Q28 metrics, separate PC psychological modules, Trust/Rating outside Overall, missing-data explanation.
5. Tests Home — module catalog, completion state, progress, purpose/output explanation.
6. Test Execution — current baseline mechanics behind clean shell, progress, resume/persistence.
7. Test Result — meaningful result, strengths, growth, explanation, coverage/version, link to profile.
8. Psychological Profile — structured current model and evidence/coverage.
9. Psychological Analysis — human-readable synthesis sections.
10. Psychological Report/history — current report + immutable previous versions/history.

Design system gate:
- early-VK information richness for a person/profile;
- Telegram interaction clarity for communication entrypoints;
- Diia-style feature isolation/progressive disclosure/screen shell;
- one primary task per screen; summary → details → deep details;
- no deletion of existing functions when reducing density.

Exit gate: standalone route-backed HTML is explicitly accepted by owner. Until then `VA=PENDING`; no Compose visual mirror.

### 0026 — HTML UI Recovery B — Chat + Groups + Search Requests
- direct/group chat timeline, reply/edit/delete/reactions/attachments/typing and profile navigation while preserving existing E2EE/security contracts;
- groups/community discovery, membership/context and group conversation flows;
- Search Requests creation/edit/status/results as a dedicated intent flow;
- progressive disclosure and route-backed simulation for all states/errors/empty/loading/history cases.
Exit gate: owner-accepted HTML for all three surfaces.

### 0027 — HTML UI Recovery C — Trust + Hospitality + Services + integration
- Trust detail, evidence/status/history without conflating Trust with Compatibility or Account Rating;
- Hospitality host/discovery/eligibility/request/acceptance/private-arrival/verified-stay/blind-review/reputation flow;
- Services as separate feature flows rather than overloaded mega-pages;
- integrated navigation/state continuity across the complete 200-person simulator.
Exit gate: complete integrated HTML owner acceptance candidate.

### 0028 — Full HTML acceptance → Android mirror → APK qualification
- freeze accepted HTML visual authority and record accepted version/hash;
- mirror only the accepted UI/flows to Compose, preserving backend/domain/network contracts and all existing functionality;
- functional-composition diff before/after Android mirror;
- only then run Android build/GitHub CI and fix confirmed compiler/build errors;
- device/runtime/E2E qualification remains a separate evidence gate.
Exit gate: `VA=PASS → A=PASS → CI_APK_VERIFIED`; `LIVE_E2E` still separately evidenced.

## Deferred/product-completion roadmap — 0029–0041

### 0029 — Enneagram Engine vNext
Canonical ledger label: `0029 Enneagram Engine`.
Research → exact input model → deterministic scoring/versioning → user result → independent `EN 0–100` pair compatibility → report integration → simulation → HTML acceptance. Remains blocked until 0028 recovery gate.

### 0030 — Numerology Research/Validation vNext
Audit the existing date-based engine and knowledge corpus; freeze exact tradition/formulas/provenance/version; separate birth-date calculation from name-based descriptive layers; add reproducibility fixtures, explanation/limitations, independent `NU 0–100`, report/profile integration and 200-person simulation coverage. Base `NU` already works in source, so this is hardening/validation rather than first implementation.

### 0031 — Astrology/Zodiac Engine vNext
Versioned evidence-class-labelled model, explicit inputs, deterministic calculation, independent `AS 0–100`, report/profile explanation, simulation and UI acceptance. It never receives a hidden weight.

### 0032 — Quality Fit / SearchIntent v2
Role/goal-specific fit remains separate from Compatibility. Implement intent model, desired qualities, explainable fit, filters/search ranking, API/persistence, simulator and accepted UI.

### 0033 — Trust v2
Evidence provenance, moderation/appeal/status/history, verified interactions and Hospitality evidence integration; no hidden compatibility bonus; backend/simulation/UI/live qualification separated.

### 0034 — Compatibility Service v2 / role-aware product hardening
Build on cycle-0024 Q28 server service rather than replacing it: metric registry/version history, role-aware PC variants only where validated, caching/performance, privacy/access rules, backward compatibility and migration. No hidden inter-metric weights.

### 0035 — Compatibility Page + Metric Detail IA
Final accepted information architecture for overall selected mean, each metric, ten/current-or-versioned psychology modules, coverage, model version, explanations and insufficient-data states.

### 0036 — PostgreSQL/runtime hardening for compatibility + reports
Execute/verify migrations in a real DB environment, indexes/query plans/concurrency/idempotence/retention/backup behavior, API authorization and observability. Source schema presence alone is not exit evidence.

### 0037 — Simulation Engine v2 / release-parity hardening
Continue the mandatory round trip `backend → routes → simulator → routes → frontend`; cover every current API/table/AppRoute, fault states, persistence transitions, deterministic fixtures and parity guards. No decorative mocks.

### 0038 — Longitudinal Outcome Research Layer
Outcome events/cohorts/confounders, exposure provenance, holdouts and no automatic production learning. Research evidence does not silently change user scores.

### 0039 — Fairness / Privacy / Ethics / Explainability qualification
DIF/invariance/fairness/privacy threat model, sensitive-data minimization, explanation contracts, model/version disclosure and appeal/correction pathways where applicable.

### 0040 — Multilingual Controlled Pilot + assessment quality program
Native-language QA and psychometric equivalence for all canonical locales, versioned assessment-bank quality review, reliability/test-retest/convergent/discriminant/fairness evaluation and explicit migration plan if the historical bank is replaced. Quality, not the legacy item count, is authoritative.

### 0041 — Integrated Release Candidate
Only after all applicable stage evidence: accepted UI, Android mirror, CI/APK, live DB/auth/runtime E2E, functional-composition diff, security/privacy qualification and complete core user journey from profile → tests → result/report → people → compatibility → communication/group/search → Trust → Hospitality.

## Final rule
No future report may say “feature implemented” merely because a research spec, route, class, API or simulator state exists. Product completion requires the applicable gate evidence.
