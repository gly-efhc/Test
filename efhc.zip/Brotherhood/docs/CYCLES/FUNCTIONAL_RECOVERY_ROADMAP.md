# Functional Recovery Roadmap — active through cycle 0028 scientific-test productization / HTML acceptance candidate

> Full assigned program now continues through cycle `0073`: `BROTHERHOOD_CYCLES_0024_0073.md` + `BROTHERHOOD_ROADMAP_0024_0073.md`. This file remains the focused recovery view for 0023–0041.
> Active source authority: `docs/CANON/BROTHERHOOD_SOURCE_AUTHORITY_CANON.md` + `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.*`.

## Mandatory stage model
Every module records `R/S/B/H/VA/A/CI/E2E` independently. `SOURCE_IMPLEMENTED` never means `VISUALLY_ACCEPTED`, `APK_VERIFIED` or `LIVE`.

## 0023 — Functional Recovery Foundation — SOURCE_IMPLEMENTED / SUPERSEDED_BY_0024 / VA_PENDING
Materialized Tests product modules, meaningful results, monthly retake, Psychological Profile/Analysis/Report snapshot, Q28 independent compatibility, ten psychological submodule comparators and base Numerology `NU 0–100` plus first recovery HTML surfaces.

## 0024 — Persistent Runtime Contracts + Full Simulation — SOURCE_IMPLEMENTED / FULL_SIMULATION_PARITY / VA_PENDING
Materialized:
- immutable/versioned Psychological Report persistence/history and safe input fingerprints;
- save/latest/history/by-id server routes;
- persistent Q28 metric selection;
- independent server `PC/IC/VC/CC/LC/PT/EN/NU/AS` with coverage/model/status and `INSUFFICIENT_DATA` rather than fabricated zero;
- ten current psychological module pair scores `0–100` when common evidence exists: loyalty, integrity, reliability, conflict, boundaries, support, competition, communication, mutual aid, lifestyle;
- cycle-0024 generated source contract at that milestone: `87 paths / 100 HTTP operations / 49 migration-defined tables / 21 Android AppRoutes`;
- full standalone simulator: backend/domain+DB → routes → BackendSimulator → SimulationEngine → route responses → frontend;
- exactly 200 deterministic synthetic candidates + current user, 20,100 assessment rows, report history and compatibility preferences;
- current date-based Numerology participates as an independent `NU` module, never a hidden weight;
- Diia Android donor principles recorded and applied at architecture/UX level only.

Gate: `R=PASS; S=PASS; B=SOURCE_IMPLEMENTED_LIVE_DB_NOT_RUN; H=SOURCE_IMPLEMENTED_FULL_SIMULATION; VA=PENDING; A=NETWORK_CONTRACT_ONLY; CI=NOT_RUN; E2E=NOT_RUN`.

## 0025 — HTML UI Recovery A — HTML_IMPLEMENTED / VA_PENDING
Own Profile → People → Candidate → Compatibility Details → Tests Home → Test Execution → Test Result → Psychological Profile → Psychological Analysis → Psychological Report/history.

Required design semantics:
- Own Profile = identity/social/professional resume; no compatibility with self.
- Candidate = person first; dense metrics are details.
- Q28 systems are independent `0–100`; Overall = arithmetic mean of explicitly selected available systems only.
- psychological test systems remain separately visible and independently comparable `0–100` when evidence exists.
- missing scores display insufficient data, never `0%`.
- early VK = information depth about the person; Telegram = communication clarity; Diia = feature isolation/progressive disclosure/screen shell.
- reducing overload means moving secondary content into detail/bottom-sheet/separate flows, not deleting functions.

Exit: explicit owner acceptance of the route-backed standalone HTML. No Compose mirror before this.

## 0026 — HTML UI Recovery B — SOURCE_HTML_IMPLEMENTED / VA_PENDING
Chat → Groups → Search Requests is materialized in source + standalone HTML. Existing direct/group/E2EE Chat backend is preserved; cycle 0026 adds first-class Search Request persistence/API and explicit community membership routes. Active generated contract: `90 paths / 108 operations / 50 tables / 21 Android AppRoutes`. Social frontend reads through SimulationEngine route responses/client projection rather than direct People/Communities/Chat/SearchRequest fixtures. Exit remains owner HTML acceptance.

## 0027 — Root IA + Development Hub — NEXT PLANNED
Owner Q45 supersedes the old Home/Services shell. Implement the root order `Профиль → Люди → Чаты → Группы → Развитие`; Profile is first/default. Development becomes a Diia-style catalog whose primary standalone apps are Tests, Numerology and Zodiac. Search Requests move under People. Trust and Hospitality remain contextual Profile/Candidate/interaction flows and are not deleted. Exit: integrated route-backed HTML owner acceptance candidate.

## 0028 — Scientific Questionnaire Systems v1.2 + Full HTML acceptance candidate — SOURCE_HTML_IMPLEMENTED / VA_PENDING
The former generated 100×6/600-task visual branch is removed from active runtime and is not a fallback. The active psychological baseline is `scientific-questionnaire-bank-v1.2`: **7 systems / 197 items / 64 construct-system pairs / minimum 3 signals per construct-system pair**.

The bank contains 17 public-domain IPIP anchors and 180 Brotherhood-original situational/redundancy/triangulation items. Broad direct anchors keep broad-factor semantics; original situational items use construct-relevant contexts and explicit adaptation provenance. Active item evidence no longer cites visual forced-choice research as questionnaire scoring authority.

Server-authoritative scoring produces deterministic construct/system results, Psychological Profile/Report sections and seven independent psychological pair compatibilities `0–100%`. Future product outcomes are post-release recalibration evidence, not a release prerequisite.

Current source/simulation contract: `97 paths / 115 operations / 50 tables / 21 Android AppRoutes / 200 candidates`. Current gate: owner reviews `BROTHERHOOD_UI_SIMULATOR_v0_5_41.html`; explicit `VA=PASS` is still required before visual Compose acceptance and APK/CI qualification. Cycle 0027 remains uncompleted because the owner explicitly redirected work to 0028.

## 0029 — Associative & Implicit Measurement Systems v1 — HIGH PRIORITY AFTER 0027
Implement independent non-self-report instruments in order: Jung Word Association → Freud Free Association → IAT/reaction-time. Store cue/block/version, response/action, latency, edits/errors/omissions, quality metadata and method-specific result/history. Any pair score is an independent versioned `0–100%` method metric; no hidden blend with questionnaire psychology.

## 0030 — Numerology standalone application vNext
Audit/harden the existing date-based engine and knowledge corpus; freeze tradition/formulas/provenance; separate date calculation from optional name-descriptive material; reproducibility fixtures; explanation/limitations; independent `NU=0–100`; report/profile/simulator/UI. Base NU is already source-implemented in 0023/0024.

## 0031 — Zodiac standalone application
Explicit inputs/versioned deterministic calculation → personal profile/characteristics/context/history → independent `AS=0–100` pair comparison → explanation/simulator/UI; no hidden weight.

## 0032 — Enneagram standalone optional application
Exact method/provenance/version → deterministic result → independent `EN=0–100` → Development-app flow/report/profile/simulator/UI. No hidden weight.

## 0033 — Quality Fit/SearchIntent v2
Role/goal-specific fit remains separate from Compatibility. Implement model + persistence/API + People/Search Request filters/ranking + explanation + simulation + accepted UI.

## 0034 — Unified multi-method Compatibility Service + persistence
Harden the cycle-0024 Q28 service and add explicit method provenance for questionnaire/associative/implicit psychological channels. Persist reproducible score snapshots, selection preferences, model manifests, calculation fingerprints and recency/invalidation. Never introduce hidden inter-method or inter-metric weights.

## 0035 — Compatibility Metric/Method Detail IA
Final UI/UX for selected Overall, each Q28 metric, questionnaire systems, associative/implicit method results, coverage/model/version/explanation and insufficient-data states. Trust and Quality Fit remain outside Overall.

## 0036 — Trust v2 + observed-behavior evidence boundaries
Evidence provenance, verified interactions, moderation/appeal/history and Hospitality integration while remaining independent of Compatibility. Define observed-behavior research events separately so launch-day behavior can later be compared with declared profiles without auto-changing Trust or psychology.

## 0037 — Simulation Engine v2
100% source-contract parity after all prior modules: every current API/table/AppRoute plus mutations, faults, history and deterministic fixtures. Frontend never invents business values outside route contracts.

## 0038 — Post-release outcome data capture & recalibration runtime
Start collection from launch day: exposure/model/input snapshots, voluntary 7/30/90/180/365-day outcomes, relationship/project/Hospitality statuses and privacy-scoped observed-behavior events. Mature 5–7-year data are later recalibration evidence; collection infrastructure, not waiting, is the cycle exit. No automatic production learning or silent score change.

## 0039 — Fairness/privacy/ethics/explainability
DIF/invariance/fairness, privacy/security model, data minimization, explanation/version disclosures and correction/appeal mechanisms where applicable.

## 0040 — Multilingual controlled pilot + assessment quality program
Native QA and psychometric equivalence across canonical locales; explicitly versioned redesign/replacement of weak tests when supported by construct/measurement/scoring/reliability/validity/fairness evidence; migration compatibility with prior result versions. Quality, not the historical `100×6` count, is authoritative.

## 0041 — Integrated release candidate
Core journey must work end to end: profile → tests → meaningful result → psychological profile/report → people → independent compatibility → chat → groups → search requests → Trust → Hospitality, with accepted UI, Compose parity, CI/APK and separately verified live runtime.

## Assessment-quality invariant
Any future test-system redesign must trace `scientific source → construct → measurement → stimuli/items → scoring → runtime → result explanation → independent pair compatibility → validation → version/migration`. A research document alone never activates a production test.


### Q44 assessment replacement
Former 100×6/600-task generated visual bank is removed. Active test work proceeds only on the seven scientific questionnaire systems and their source/claim-traced item banks.
