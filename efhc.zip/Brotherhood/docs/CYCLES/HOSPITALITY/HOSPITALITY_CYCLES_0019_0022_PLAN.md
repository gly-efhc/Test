# Cycle 0019 — Hospitality integration plan for cycles 0020–0022

Status: **COMPLETED — PLANNING / GOVERNANCE ONLY**  
Source HEAD: `Brotherhood_v0_5_48.zip`  
Source HEAD SHA-256: `9a5526eea2b5d6e6a17700bf0741deaa25312aa1fa030e85396d1b3e0ea5d2a2`  
Owner implementation TZ: `BROTHERHOOD_HOSPITALITY_IMPLEMENTATION_TZ.md`  
Owner TZ SHA-256: `d9b93a1ea62c6ab27868ca8f940d51dc9640b3d30ebdb281d5ee7066dd9b2687`

## 1. Purpose
Insert Brotherhood Hospitality & Stays immediately after cycle 0018. Cycle 0019 performs no runtime implementation. It converts the supplied five-cycle TZ implementation plan into three larger implementation cycles `0020–0022`, while preserving every major contract, security boundary and acceptance gate.

Hospitality remains a Brotherhood social function, not a lodging marketplace: free P2P hosting, existing `global_id`, existing People/Profile/Chat/Trust/Push/Simulation, no fifth Home primary action, no new identity/chat/moderation system and no change to protected `100×6` / owner-locked assessment mechanics.

## 2. Strategic research bridge
Owner goal: use Hospitality as a strong indicator of real-world relationship development and meetings worldwide.

The module therefore gains a privacy-safe Research Platform bridge without creating a Hospitality Compatibility score:

`recommendation/search exposure`
→ `host profile exposure`
→ `eligibility result`
→ `stay request`
→ `accepted`
→ `completed`
→ `stay confirmation`
→ `verified hospitality_stay evidence`
→ `voluntary relationship status / follow-up`
→ `7/30/90/180/365 longitudinal outcome`.

Required causal guards:
- not shown != negative;
- no request != incompatibility;
- rejected/cancelled != incompatibility;
- completed != physical stay;
- allegation/no-show claim != verified negative evidence;
- verified stay != friendship by itself;
- post-stay relationship status is an outcome, not a feature of the historical prediction;
- exact address/coordinates/private chat content never enter research exports;
- production scoring never auto-learns from stay events.

Privacy-safe aggregate research may count cross-city/cross-country verified stays and relationship-status transitions using coarse geography and pseudonymized identifiers. Exact address and exact coordinates remain outside analytics/research datasets.

## 3. Cycle 0020 — Hospitality Foundation + Backend Lifecycle
**Status: COMPLETED in v0.5.50-cycle0020.**  
**Absorbs original TZ cycles 0032 + 0033.**

### Implementation scope
1. `database/migrations/0009_hospitality.sql`; canonical schema parity.
2. HostProfile, Availability, StayRequest, RequestEvents, StayConfirmations, StayReviews, HospitalityRestrictions and required indexes.
3. Existing `global_id` ownership only; UUID only for module entities.
4. Application-level AEAD private-location contract; key versioning/env; no plaintext exact location.
5. Feature flag `HOSPITALITY_ENABLED`.
6. Pydantic DTOs and separated public/owner/private DTO boundaries.
7. Backend-authoritative eligibility: Account Rating, required completed tests, blocks, restrictions, dates, capacity, max days/guests, privacy/discovery.
8. Host profile + availability + public host + eligibility + request create/list/detail/status APIs.
9. Transactional acceptance, atomic capacity, optimistic versioning and idempotency.
10. 48h pending expiry, timezone-aware completion scheduler/tick.
11. Existing E2EE direct-conversation binding + structured Hospitality events; no request-message plaintext in StayRequest.
12. Encrypted immutable arrival snapshot at acceptance + participant-only endpoint.
13. Privacy-safe push contracts.
14. DB/backend/API/security/IDOR/race/replay tests.
15. Research bridge foundation: immutable IDs/timestamps needed to connect future verified stay to the historical exposure/request snapshot, without changing any Compatibility engine.

### DoD
Backend lifecycle works from host configuration and request creation through accepted/completed behind a feature flag; exact location is encrypted and inaccessible before acceptance; capacity race and state transitions are server-authoritative; owner-locked assessment and existing Compatibility scoring remain byte-stable unless a separately authorized contract requires otherwise.

## 4. Cycle 0021 — Verified Stay / Reviews / Trust + Android UX
**Status: COMPLETED in v0.5.51-cycle0021.**  
**Absorbs original TZ cycles 0034 + 0035.**

### Implementation scope
1. stay confirmations and verified-stay evidence contract; one request -> max one verified interaction.
2. `verified_interactions(interaction_type=hospitality_stay)` integration.
3. blind reviews, simultaneous/7-day publication, encrypted private feedback, anti-probing/anti-retaliation.
4. Hospitality Reputation summary kept separate from Account Rating, Trust and Compatibility.
5. no-show/dispute -> Trust Incident -> evidence -> moderation -> decision -> restriction/appeal; no automatic penalty from allegation.
6. Android Hospitality models/repository/ViewModel.
7. `Мой дом`, Host Settings, Availability Calendar, incoming/outgoing requests, request detail, Stay Details, Review.
8. People filter `Может принять у себя`, city/date/guest filters and public Host block.
9. eligibility UX and request modal.
10. safe pre-acceptance map + exact accepted map only from encrypted request snapshot.
11. chat structured cards + existing E2EE messages; push deep links.
12. Android Keystore secure arrival store; no plaintext private cache.
13. offline-safe public/request state.
14. all 13 locales.
15. voluntary Research Platform post-stay prompt may link verified stay to existing relationship status and longitudinal follow-up; no forced friendship label.

### DoD
Verified physical-stay evidence is evidence-backed; blind review cannot be probed before publication; Android end-to-end user flow works without sensitive-location disclosure before acceptance; Trust/moderation due process is preserved; 13 locale keys pass structural coverage.

## 5. Cycle 0022 — Release-Parity / Research Outcomes / Security / Integrated Hospitality RC
**Status: COMPLETED_SOURCE_LOCAL_RC / GITHUB_APK_CHECKPOINT_PENDING in v0.5.52-cycle0022.**  
**Absorbs original TZ cycle 0036 and closes the owner-requested research-indicator objective.**

### Implementation/qualification scope
1. DemoBackendSimulator, DemoSimulationEngine, DemoRepository and HTML release-parity Hospitality state machine.
2. Full lifecycle simulation: host, availability, eligibility, request, accept/reject/cancel/expiry/completion, secure arrival, confirmations, blind reviews, restrictions.
3. adversarial security: IDOR, address leakage, push/log leakage, E2EE boundary, review probing, replay/idempotency, stale version, block/restriction, capacity race.
4. migration upgrade + canonical schema + OpenAPI parity.
5. integrated backend+Android E2E where environment evidence is available; keep SOURCE_ONLY/LOCAL_PASS/APK_VISIBLE/LIVE_E2E/PRODUCTION_QUALIFIED distinct.
6. Research Platform bridge: historical recommendation/score/policy/rank/exposure provenance linked to request/stay IDs; verified-stay event; optional relationship-status and 7/30/90/180/365 follow-up.
7. privacy-safe aggregate indicators: requests, accepts, verified stays, repeat hosting, coarse cross-city/cross-country stays, post-stay relationship-status transitions and persistence. No exact location analytics.
8. confound tracking: travel opportunity, city/country, dates/seasonality, pre-existing relationship, prior conversation, recommendation exposure, host availability, cancellations, moderation/disputes.
9. no auto-learning; any future model change follows offline analysis -> validation -> fairness/privacy -> scientific/owner review -> new version.
10. regression audit and protected mechanics guard.

### DoD
Hospitality reaches integrated RC only when its real implementation and release-parity simulation satisfy the applicable evidence gates. Verified stays become a first-class real-world research outcome source without being mislabeled as automatic friendship or hidden Compatibility multiplier / hidden Compatibility weight.

## 6. Roadmap renumbering
The previously planned tail is preserved and shifted by +4:
- old 0019 Enneagram -> **0023**;
- old 0020 Numerology -> **0024**;
- old 0021 Astrology -> **0025**;
- old 0022 Quality Fit -> **0026**;
- old 0023 Trust -> **0027**;
- old 0024 Unified Compatibility -> **0028**;
- old 0025 Compatibility UI -> **0029**;
- old 0026 Backend/PostgreSQL Compatibility -> **0030**;
- old 0027 Release-Parity Simulation v2 -> **0031**;
- old 0028 Longitudinal Outcome Research -> **0032**;
- old 0029 Fairness/Privacy/Ethics -> **0033**;
- old 0030 Multilingual Pilot -> **0034**;
- old 0031 Integrated Investor/RC -> **0035**.

Reserve becomes `0036–0100`.

## 7. Next cycle
`0023 — Enneagram Engine`.


### Cycle 0020 implementation result
Implemented backend/data/security foundation through calendar completion: migration/schema, encrypted HostProfile private location, availability, server-authoritative eligibility, idempotent StayRequest creation, canonical direct-conversation reuse, status transitions, atomic capacity recheck, acceptance-time encrypted arrival snapshot, participant-only access audit and idempotent lifecycle tick. Structured Hospitality events are the privacy-safe backend notification/event contract; this source HEAD contains canonical `push_tokens` registration but no existing FCM/APNs sender, so external push delivery is not falsely claimed and remains an integration task with Android/push routing in 0021. Confirmation/review/verified-stay/Trust evidence remains deliberately inactive until 0021.


### Cycle 0021 implementation result
Implemented source contracts for bilateral stay confirmation and exactly-once verified `hospitality_stay` evidence; no-show/dispute guard; blind-review anti-probing and bilateral-or-7-day publication; encrypted private review feedback; separate Hospitality Reputation; Trust incident/moderation/restriction/appeal due process; participant-authorized structured conversation events; Android Hospitality models/repository/ViewModel/screens/routes; My Home and availability; People/host discovery with server eligibility before request; public city-level map and accepted-only exact map; E2EE message + structured-event timeline; Keystore-backed private arrival cache; push/deep-link routing; structural 13-locale key coverage. Android runtime source milestone is `v0.5.33 / versionCode 38`. Actual Gradle/APK/device qualification and external push delivery remain unclaimed; release-parity simulation/HTML is intentionally deferred to 0022.

### Cycle 0022 implementation result
Release-parity source implementation now mirrors the current 80-path / 93-operation OpenAPI contract, 47 migration-defined tables and all 21 Android AppRoutes. Standalone HTML implements all Hospitality screens plus host/availability/eligibility/request/state/secure-arrival/verification/blind-review/reputation/restriction simulation; protected 100×6 mechanics remain source-locked. Android DEBUG/offline simulation gains Hospitality fixtures/state/lifecycle and MainViewModel fallback without replacing production repositories when a real session is present. Research outcome contracts freeze decision-time recommendation/model/score/rank provenance and link only privacy-safe Hospitality events to voluntary 7/30/90/180/365 outcomes; exact address/coordinates/arrival contact/private feedback/E2EE plaintext are excluded and production auto-learning remains forbidden. GitHub APK/device/LIVE_E2E evidence is external and not claimed by this source completion.
