# Техническое задание
# Brotherhood — модуль «Гостеприимство / Hospitality & Stays»

**Тип документа:** техническое задание на внедрение нового модуля  
**Исходный проект:** `Brotherhood_v0_5_48.zip`  
**Назначение:** реализация P2P-гостеприимства между пользователями Brotherhood без создания отдельного приложения, параллельной системы идентичности, отдельного чата или отдельной системы репутации.  
**Статус:** IMPLEMENTATION SPECIFICATION  
**План внедрения:** 5 циклов — `0032–0036`

---

## 1. Цель модуля

Модуль «Гостеприимство / Hospitality & Stays» должен позволить пользователям Brotherhood:

- включать режим хоста и предлагать бесплатное гостевое размещение другим пользователям;
- искать пользователей, готовых принять гостя;
- фильтровать хостов по городу, датам, количеству гостей и условиям проживания;
- устанавливать собственный входной барьер для гостя на основании существующего `Account Rating` и факта прохождения выбранных тестов;
- отправлять и обрабатывать заявки на проживание;
- автоматически создавать или повторно использовать прямой чат между гостем и хостом;
- открывать точный адрес только после принятия заявки;
- завершать визит через формализованный жизненный цикл;
- оставлять двусторонние слепые отзывы;
- формировать подтвержденное `verified stay evidence`;
- использовать подтвержденные события проживания как отдельный источник Trust/Hospitality Reputation;
- создавать реальные офлайн-связи между пользователями Brotherhood через безопасный и контролируемый процесс.

Модуль должен быть встроен в существующую социальную архитектуру Brotherhood и усиливать People Discovery, Profile, Chat, Trust, Push и Simulation, а не дублировать их.

---

## 2. Продуктовая модель

### 2.1. Базовый сценарий

1. Пользователь A включает режим «Готов принимать гостей».
2. Пользователь A задает условия проживания и минимальные требования к гостю.
3. Пользователь B находит A через существующий каталог людей.
4. Backend проверяет B по требованиям A.
5. B выбирает даты, количество гостей и отправляет заявку.
6. Создается `StayRequest`.
7. Создается или повторно используется direct conversation.
8. Хост принимает или отклоняет заявку.
9. После принятия гостю открываются приватные данные прибытия.
10. После окончания проживания заявка завершается.
11. Обе стороны получают форму blind review.
12. После публикации отзывов формируется репутационное evidence.

### 2.2. Что не входит в текущую версию

Без отдельного ТЗ не внедрять:

- оплату проживания;
- комиссию Brotherhood;
- аренду недвижимости;
- залоги;
- escrow;
- внутренний marketplace жилья;
- коммерческие объявления;
- бронирование отелей;
- туристические пакеты;
- продажу дополнительных услуг;
- автоматическое страхование;
- изменение существующих Compatibility-алгоритмов;
- изменение owner-locked механики тестов `100×6`.

Hospitality остается социальной функцией Brotherhood.

---

# 3. Обязательные архитектурные границы Brotherhood

## 3.1. Идентичность

Использовать существующий `global_id`.

В текущем backend Brotherhood:

- внутренний `global_id` — `bigint`;
- диапазон — `1..9_999_999_999`;
- публичное отображение выполняется 10-значным `global_id_display`.

Запрещено:

- создавать параллельный UUID пользователя;
- использовать email/provider/local Android ID как owner key;
- создавать новую identity-систему специально для Hospitality.

UUID использовать только для самостоятельных сущностей модуля.

## 3.2. Assessment / тесты

Owner-locked систему `100×6` не изменять.

Hospitality может читать только:

- факт завершения теста `f001..f100`;
- текущий Account Rating;
- разрешенные публичные агрегаты.

Hospitality не должен раскрывать:

- raw answers;
- hidden links;
- latent coordinates;
- приватные психологические признаки;
- внутреннюю механику scoring.

## 3.3. Разделение метрик

Не объединять в один показатель:

- Account Rating;
- Trust;
- Hospitality Reputation;
- Compatibility;
- Quality Fit;
- Psychology;
- Personality Type;
- Enneagram;
- другие compatibility metrics.

`Account Rating` используется как admission gate.

`Hospitality Reputation` используется как отдельная репутация подтвержденных проживаний.

## 3.4. Direct Chat / E2EE

Текущую E2EE boundary direct chat сохранить.

Статусы StayRequest передавать через отдельные structured Hospitality events, связанные с `conversation_id`.

Сопроводительное сообщение гостя отправлять через существующий E2EE direct-chat механизм.

Не хранить plaintext сообщения гостя внутри `stay_requests`.

## 3.5. Home navigation

Не создавать пятую основную Home-кнопку.

Hospitality встроить через:

- People / Поиск людей;
- профиль пользователя;
- «Мой профиль» → «Гостеприимство / Мой дом»;
- связанные экраны заявок.

## 3.6. Локализация

Все новые строки добавить во все 13 активных локалей:

`sw, ru, en, uk, de, fr, es, it, tr, pl, da, hi, id`.

Новые ключи должны войти в `required_keys`.

---

# 4. Пользовательские роли

## 4.1. Host

Хост может:

- включить/выключить прием гостей;
- настроить условия;
- управлять календарем;
- установить максимальное количество гостей;
- установить max days;
- выбрать sleeping condition;
- задать house rules;
- установить минимальный Account Rating;
- выбрать обязательные тесты;
- получать/принимать/отклонять заявки;
- отменять принятый визит;
- подтверждать факт проживания;
- оставлять отзыв;
- создавать Hospitality-linked Trust Incident.

## 4.2. Guest

Гость может:

- искать хостов;
- видеть публичные условия;
- получать собственный eligibility result;
- отправлять заявку только после backend validation;
- общаться через E2EE direct chat;
- отменять заявку до check-in;
- видеть адрес только после `accepted`;
- подтверждать визит;
- оставлять blind review;
- создавать incident/report.

## 4.3. Moderator

Не создавать отдельную moderation system.

Использовать существующие:

- `trust_incidents`;
- `incident_evidence`;
- `moderation_decisions`;
- `appeals`.

Hospitality restriction применяется только после подтвержденного moderation decision.

---

# 5. Основные пользовательские сценарии

## 5.1. Включение режима хоста

1. Пользователь открывает «Мой профиль».
2. Выбирает «Гостеприимство / Мой дом».
3. Заполняет обязательные параметры.
4. Сохраняет точный адрес.
5. Backend шифрует приватные данные.
6. Пользователь включает «Готов принимать гостей».
7. Только после полной серверной валидации профиль появляется в Hospitality discovery.

## 5.2. Поиск хоста

1. Guest открывает People.
2. Активирует фильтр «Может принять у себя».
3. Указывает город.
4. При необходимости — даты.
5. Указывает количество гостей.
6. Backend возвращает подходящих активных хостов.
7. Для каждого результата возвращается public Hospitality summary.
8. Для авторизованного requester возвращается персональный eligibility summary.

## 5.3. Отправка заявки

1. Guest открывает профиль хоста.
2. Видит условия приема.
3. Backend рассчитывает eligibility.
4. Guest выбирает даты.
5. Guest выбирает количество человек.
6. Guest вводит сообщение.
7. Backend повторно валидирует eligibility.
8. Backend создает `StayRequest`.
9. Backend создает/reuses direct conversation.
10. Android отправляет сообщение через E2EE chat.
11. Backend создает structured request event.
12. Хост получает privacy-safe push.

## 5.4. Принятие заявки

1. Host открывает request.
2. Backend подтверждает права host.
3. Backend повторно проверяет status/dates/availability/capacity/blocks/restrictions.
4. Capacity резервируется атомарно.
5. Status → `accepted`.
6. Создается encrypted arrival snapshot.
7. Создается Hospitality event.
8. Guest получает push.
9. Guest получает доступ к secure Stay Details.

## 5.5. Завершение

`Completed` — календарное завершение lifecycle, но не автоматическое доказательство физического визита.

Для `verified stay evidence` требуется независимое подтверждение факта проживания.

---

# 6. Модель данных

Создать новую миграцию:

`database/migrations/0009_hospitality.sql`

После применения синхронизировать:

`backend/schema.sql`

Старые миграции не редактировать.

## 6.1. `hospitality_host_profiles`

```sql
CREATE TABLE hospitality_host_profiles (
    host_global_id bigint PRIMARY KEY
        REFERENCES users(global_id) ON DELETE CASCADE,

    is_hosting_active boolean NOT NULL DEFAULT false,

    max_guests smallint NOT NULL,
    max_days smallint NOT NULL,

    city_id uuid NOT NULL REFERENCES cities(city_id),
    public_area_text text,
    timezone_name text NOT NULL,

    sleeping_condition text NOT NULL
        CHECK (sleeping_condition IN (
            'private_room',
            'shared_room',
            'sofa',
            'entire_space'
        )),

    house_rules jsonb NOT NULL DEFAULT '[]'::jsonb,

    min_required_rating numeric(5,2) NOT NULL DEFAULT 0
        CHECK (min_required_rating BETWEEN 0 AND 100),

    required_completed_tests text[] NOT NULL DEFAULT '{}',

    availability_mode text NOT NULL DEFAULT 'always'
        CHECK (availability_mode IN ('always', 'calendar')),

    private_location_ciphertext bytea NOT NULL,
    private_location_nonce bytea NOT NULL,
    private_location_key_version smallint NOT NULL,

    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),

    CHECK (max_guests > 0),
    CHECK (max_days > 0)
);
```

В encrypted JSON payload хранить:

```json
{
  "exact_address": "...",
  "arrival_instructions": "...",
  "exact_lat": 0.0,
  "exact_lon": 0.0,
  "arrival_contact": "..."
}
```

Не создавать plaintext-колонки exact address/coordinates/contact.

До acceptance публичная карта использует `cities.center_lat`/`center_lon` либо безопасную публичную точку района.

## 6.2. `hospitality_availability`

```sql
CREATE TABLE hospitality_availability (
    availability_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    host_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    date_from date NOT NULL,
    date_to date NOT NULL,
    availability_state text NOT NULL
        CHECK (availability_state IN ('available', 'unavailable')),
    capacity_override smallint,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (date_to > date_from),
    CHECK (capacity_override IS NULL OR capacity_override > 0)
);
```

Интервал: `[date_from, date_to)`.

`availability_mode = always`:
- даты доступны по умолчанию;
- `unavailable` блокирует интервалы.

`availability_mode = calendar`:
- доступны только интервалы `available`;
- `unavailable` имеет приоритет.

## 6.3. `stay_requests`

```sql
CREATE TABLE stay_requests (
    request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    guest_global_id bigint NOT NULL REFERENCES users(global_id),
    host_global_id bigint NOT NULL REFERENCES users(global_id),
    check_in_date date NOT NULL,
    check_out_date date NOT NULL,
    guests_count smallint NOT NULL,

    status text NOT NULL DEFAULT 'pending'
        CHECK (status IN (
            'pending',
            'accepted',
            'rejected',
            'cancelled_by_guest',
            'cancelled_by_host',
            'completed',
            'expired'
        )),

    response_due_at timestamptz NOT NULL,
    conversation_id uuid REFERENCES conversations(conversation_id),
    eligibility_snapshot jsonb NOT NULL,
    rejection_reason text,
    cancellation_reason text,
    accepted_at timestamptz,
    completed_at timestamptz,

    arrival_details_ciphertext bytea,
    arrival_details_nonce bytea,
    arrival_details_key_version smallint,
    private_access_expires_at timestamptz,

    review_deadline_at timestamptz,
    version integer NOT NULL DEFAULT 1,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),

    CHECK (guest_global_id <> host_global_id),
    CHECK (check_out_date > check_in_date),
    CHECK (guests_count > 0)
);
```

### Eligibility snapshot

Хранить immutable snapshot условий на момент создания заявки:

```json
{
  "contract_version": "hospitality-eligibility-v1",
  "guest_account_rating": 87.5,
  "host_min_required_rating": 85.0,
  "required_tests": ["f004", "f018"],
  "completed_required_tests": ["f004", "f018"],
  "missing_tests": [],
  "guest_count": 1,
  "max_guests": 2,
  "stay_days": 3,
  "max_days": 7,
  "compatibility_summary": {},
  "quality_fit_summary": {},
  "evaluated_at": "..."
}
```

Не помещать туда raw tests, hidden profile, exact address, private chat, private moderation.

### Arrival snapshot

При `accepted` копировать текущие private arrival details хоста в отдельный encrypted snapshot request. Изменение HostProfile после acceptance не должно менять адрес уже принятого визита.

## 6.4. `hospitality_request_events`

```sql
CREATE TABLE hospitality_request_events (
    event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    conversation_id uuid NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    actor_global_id bigint REFERENCES users(global_id),
    event_type text NOT NULL,
    public_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);
```

Event types:

- `request_created`;
- `request_accepted`;
- `request_rejected`;
- `request_cancelled_by_guest`;
- `request_cancelled_by_host`;
- `request_expired`;
- `stay_completed`;
- `reviews_opened`;
- `reviews_published`;
- `hospitality_restriction_applied`.

`public_payload` не содержит exact address или скрытые тестовые данные.

## 6.5. `hospitality_stay_confirmations`

```sql
CREATE TABLE hospitality_stay_confirmations (
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id),
    confirmation text NOT NULL
        CHECK (confirmation IN ('stay_occurred', 'no_show', 'dispute')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (request_id, global_id)
);
```

`verified stay evidence` создавать только после accepted → completed и подтверждения состоявшегося визита сторонами по утвержденному verification contract.

Если есть `no_show` или `dispute`, автоматическое verified evidence не создавать.

## 6.6. `stay_reviews`

```sql
CREATE TABLE stay_reviews (
    review_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    author_global_id bigint NOT NULL REFERENCES users(global_id),
    target_global_id bigint NOT NULL REFERENCES users(global_id),

    adequacy smallint NOT NULL CHECK (adequacy BETWEEN 1 AND 5),
    rules_compliance smallint NOT NULL CHECK (rules_compliance BETWEEN 1 AND 5),
    description_accuracy smallint NOT NULL CHECK (description_accuracy BETWEEN 1 AND 5),

    review_score numeric(5,2) NOT NULL CHECK (review_score BETWEEN 0 AND 100),
    review_contract_version text NOT NULL,
    review_text text,

    private_feedback_ciphertext bytea,
    private_feedback_nonce bytea,
    private_feedback_key_version smallint,

    submitted_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz,
    moderated_at timestamptz,

    UNIQUE (request_id, author_global_id),
    CHECK (author_global_id <> target_global_id)
);
```

`rating_impact` не принимать от клиента. Репутационное влияние рассчитывает backend по versioned policy.

User-visible review score:

```text
average = (adequacy + rules_compliance + description_accuracy) / 3
review_score_0_100 = ((average - 1) / 4) * 100
```

## 6.7. `hospitality_restrictions`

```sql
CREATE TABLE hospitality_restrictions (
    restriction_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id),
    scope text NOT NULL CHECK (scope IN ('guest', 'host', 'all')),
    source_incident_id uuid NOT NULL REFERENCES trust_incidents(incident_id),
    reason_code text NOT NULL,
    starts_at timestamptz NOT NULL,
    ends_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);
```

Restriction создавать только после подтвержденного moderation decision.

---

# 7. Индексы

Минимум:

```sql
CREATE INDEX hospitality_host_active_city_idx
ON hospitality_host_profiles(city_id, is_hosting_active);

CREATE INDEX hospitality_availability_host_dates_idx
ON hospitality_availability(host_global_id, date_from, date_to);

CREATE INDEX stay_requests_host_status_dates_idx
ON stay_requests(host_global_id, status, check_in_date, check_out_date);

CREATE INDEX stay_requests_guest_status_dates_idx
ON stay_requests(guest_global_id, status, check_in_date, check_out_date);

CREATE INDEX stay_requests_pending_due_idx
ON stay_requests(response_due_at)
WHERE status = 'pending';

CREATE INDEX stay_requests_completed_review_idx
ON stay_requests(review_deadline_at)
WHERE status = 'completed';

CREATE INDEX stay_reviews_target_published_idx
ON stay_reviews(target_global_id, published_at);

CREATE INDEX hospitality_restrictions_active_idx
ON hospitality_restrictions(global_id, starts_at, ends_at);
```

---

# 8. Eligibility Engine

Создать единый backend-authoritative сервис, например в:

`backend/app/hospitality.py`

```python
evaluate_hospitality_eligibility(
    guest_global_id,
    host_global_id,
    check_in_date,
    check_out_date,
    guests_count,
)
```

Заявка разрешена только если:

```text
host exists
AND host.is_hosting_active
AND guest != host
AND no active user block between participants
AND no active guest Hospitality restriction
AND no active host Hospitality restriction
AND guest Account Rating >= host.min_required_rating
AND required_completed_tests ⊆ guest.completed_tests
AND guests_count <= effective_capacity
AND stay_days <= host.max_days
AND requested dates are available
AND capacity is available for entire interval
AND dates are valid
AND privacy/discovery rules allow interaction
```

Android eligibility — только предварительный UI. Окончательная проверка всегда на backend.

---

# 9. Eligibility response

```json
{
  "eligible": false,
  "contract_version": "hospitality-eligibility-v1",
  "reasons": [
    {
      "code": "RATING_TOO_LOW",
      "required": 85.0,
      "actual": 81.5
    },
    {
      "code": "MISSING_REQUIRED_TESTS",
      "tests": ["f018"]
    }
  ],
  "account_rating": 81.5,
  "min_required_rating": 85.0,
  "missing_required_tests": ["f018"],
  "date_available": true,
  "capacity_available": true
}
```

---

# 10. Продолжительность проживания

Единое правило:

```text
stay_days = check_out_date - check_in_date
```

`check_out_date` — день выезда и не входит в срок размещения.

---

# 11. Capacity и защита от двойного принятия

Операция `accept` должна быть транзакционной.

Минимальный алгоритм:

1. `SELECT ... FOR UPDATE` HostProfile;
2. перечитать accepted stays с пересечением дат;
3. вычислить занятую capacity;
4. повторно проверить availability/capacity;
5. изменить request → accepted;
6. создать arrival snapshot;
7. создать event;
8. commit.

При race:

- HTTP `409`;
- `HOSPITALITY_CAPACITY_CHANGED`.

---

# 12. State Machine

Статусы:

- `pending`
- `accepted`
- `rejected`
- `cancelled_by_guest`
- `cancelled_by_host`
- `completed`
- `expired`

`cancelled_by_host` обязателен: хост должен иметь возможность отменить уже принятый визит.

| From | To | Actor |
|---|---|---|
| pending | accepted | host |
| pending | rejected | host |
| pending | cancelled_by_guest | guest |
| pending | expired | system |
| accepted | cancelled_by_guest | guest, до check-in |
| accepted | cancelled_by_host | host |
| accepted | completed | system |
| completed | terminal | — |
| rejected | terminal | — |
| expired | terminal | — |
| cancelled_by_guest | terminal | — |
| cancelled_by_host | terminal | — |

Terminal → pending запрещено.

---

# 13. Временная логика

## 13.1. Pending expiry

```text
response_due_at = created_at + 48 hours
```

Если request остается pending и срок истек → `expired`.

## 13.2. Completed

После `check_out_date` заявка переводится в `completed` в 00:00 следующего дня по timezone хоста.

Для этого HostProfile хранит IANA `timezone_name`.

System timestamps хранить в UTC.

## 13.3. Review deadline

```text
review_deadline_at = completed_at + 7 days
```

---

# 14. Scheduler / Hospitality Tick

Создать idempotent internal operation:

`POST /internal/hospitality/tick`

Защитить существующим internal-secret механизмом.

Операция должна:

1. pending overdue → expired;
2. accepted с завершившимся сроком → completed;
3. открыть review window;
4. опубликовать blind reviews после 7 дней;
5. завершать private arrival access по policy;
6. завершать истекшие restrictions;
7. безопасно переживать повторный вызов.

Lifecycle нельзя рассчитывать только на Android.

---

# 15. Private Address Security

## До `accepted`

Можно видеть:

- city;
- region/public area;
- safe public map point;
- public host conditions.

Нельзя получить:

- exact address;
- exact lat/lon;
- arrival instructions;
- arrival contact.

## После `accepted`

Доступ имеют только guest и host конкретного request.

Проверка:

```text
authenticated_global_id IN (guest_global_id, host_global_id)
AND request.status = accepted
AND private access active
```

## Шифрование

Использовать application-level AEAD:

- AES-256-GCM;
- отдельный key version;
- уникальный nonce;
- ключ только в backend environment;
- ключ никогда не передавать Android и не коммитить.

Env:

```text
HOSPITALITY_PRIVATE_KEY_V1_B64=
HOSPITALITY_PRIVATE_KEY_ACTIVE_VERSION=1
```

Если `cryptography` не закреплена прямой dependency, добавить ее явно.

Не логировать exact address, coordinates, arrival contact, private feedback, E2EE plaintext.

---

# 16. Accepted Stay Private Snapshot

При acceptance:

1. decrypt current HostProfile private payload;
2. создать новый encrypted arrival snapshot внутри StayRequest;
3. привязать к конкретному визиту;
4. дальнейшее изменение HostProfile не меняет уже accepted stay.

---

# 17. Backend API

Текущий Brotherhood использует namespace `/v1`, поэтому новые endpoints реализовать там. Не создавать параллельный набор `/api/v1` в коде.

Если deployment proxy добавляет `/api`, это routing-layer задача.

## 17.1. Host Profile

### `GET /v1/hospitality/profile`

Получить собственные настройки.

### `PUT /v1/hospitality/profile`

Create/update HostProfile.

Owner определяется по session, а не по body.

## 17.2. Availability

### `GET /v1/hospitality/availability`
### `PUT /v1/hospitality/availability`
### `DELETE /v1/hospitality/availability/{availability_id}`

## 17.3. Public Host Details

### `GET /v1/hospitality/hosts/{host_global_id}`

Только public HostProfile + requester eligibility.

## 17.4. Eligibility

### `GET /v1/hospitality/hosts/{host_global_id}/eligibility`

Query:

- `check_in_date`
- `check_out_date`
- `guests_count`

## 17.5. Create Stay Request

### `POST /v1/hospitality/requests`

```json
{
  "host_global_id": 123,
  "check_in_date": "2026-09-10",
  "check_out_date": "2026-09-13",
  "guests_count": 1
}
```

Backend:

1. берет guest из session;
2. evaluate eligibility;
3. open/reuse direct conversation;
4. create request;
5. save snapshot;
6. create request event;
7. return request + conversation_id.

Сообщение из модального окна Android отправляет через существующий E2EE chat после создания request.

## 17.6. Requests list

### `GET /v1/hospitality/requests`

Query:

- `direction=incoming|outgoing|all`
- `status=`
- pagination.

## 17.7. Request Detail

### `GET /v1/hospitality/requests/{request_id}`

Только participant-authorized data.

## 17.8. Secure Arrival Details

### `GET /v1/hospitality/requests/{request_id}/arrival-details`

Только accepted participants.

Arrival details не помещать в общий list endpoint.

## 17.9. Status Update

### `PATCH /v1/hospitality/requests/{request_id}/status`

```json
{
  "action": "accept",
  "reason": null,
  "expected_version": 3
}
```

Actions:

- `accept`
- `reject`
- `cancel_guest`
- `cancel_host`

Клиент не может передавать произвольный status.

## 17.10. Stay Confirmation

### `POST /v1/hospitality/requests/{request_id}/confirmation`

```json
{
  "confirmation": "stay_occurred"
}
```

Допустимо:

- `stay_occurred`
- `no_show`
- `dispute`

## 17.11. Review

### `POST /v1/hospitality/requests/{request_id}/reviews`

```json
{
  "adequacy": 5,
  "rules_compliance": 5,
  "description_accuracy": 4,
  "review_text": "...",
  "private_feedback": "..."
}
```

Backend сам определяет author, target, score, publication, reputation evidence.

## 17.12. Public Reviews

### `GET /v1/users/{global_id}/hospitality-reviews`

Только `published_at IS NOT NULL`.

## 17.13. Reputation Summary

### `GET /v1/hospitality/reputation/{global_id}`

Пример:

```json
{
  "verified_stays_as_host": 8,
  "verified_stays_as_guest": 6,
  "published_reviews": 12,
  "average_host_review": 91.0,
  "average_guest_review": 94.0,
  "active_restriction": false,
  "policy_version": "hospitality-reputation-v1"
}
```

Не смешивать с Account Rating.

---

# 18. API Error Contract

Минимальные codes:

- `HOSPITALITY_HOST_INACTIVE`
- `HOSPITALITY_SELF_REQUEST_FORBIDDEN`
- `HOSPITALITY_RATING_TOO_LOW`
- `HOSPITALITY_REQUIRED_TESTS_MISSING`
- `HOSPITALITY_DATES_INVALID`
- `HOSPITALITY_STAY_TOO_LONG`
- `HOSPITALITY_TOO_MANY_GUESTS`
- `HOSPITALITY_DATES_UNAVAILABLE`
- `HOSPITALITY_CAPACITY_UNAVAILABLE`
- `HOSPITALITY_CAPACITY_CHANGED`
- `HOSPITALITY_BLOCKED_RELATIONSHIP`
- `HOSPITALITY_RESTRICTED`
- `HOSPITALITY_INVALID_STATE_TRANSITION`
- `HOSPITALITY_NOT_PARTICIPANT`
- `HOSPITALITY_PRIVATE_DETAILS_NOT_AVAILABLE`
- `HOSPITALITY_REVIEW_NOT_OPEN`
- `HOSPITALITY_REVIEW_ALREADY_SUBMITTED`
- `HOSPITALITY_REVIEW_HIDDEN`
- `HOSPITALITY_VERSION_CONFLICT`

HTTP:

- `400` malformed request;
- `401` no auth;
- `403` forbidden;
- `404` not found/not visible;
- `409` state/capacity/version conflict;
- `422` business eligibility failure.

---

# 19. Blind Review System

После `completed` обе стороны получают review form.

Первый submitted review не показывается другой стороне.

### Обе стороны отправили

Во второй submission transaction:

- оба reviews получают `published_at`;
- publication происходит одновременно;
- создается notification event.

### Отправила одна сторона

До 7-дневного deadline review скрыт.

После deadline опубликован submitted review.

Если вторая сторона ничего не отправила — отсутствующий review не создается.

## Защита от probing

До публикации peer не должен узнать:

- отправлен ли первый review;
- оценку;
- текст;
- private feedback.

Можно показывать только собственный статус submission и deadline.

## Editing

До publication owner может редактировать свой review.

После publication review immutable, кроме moderation/audit-safe механизма.

---

# 20. Verified Stay Evidence

После утвержденного verification contract создать запись в существующем `verified_interactions`:

```text
interaction_type = hospitality_stay
```

```json
{
  "request_id": "...",
  "verification_contract": "hospitality-stay-v1",
  "host_confirmed": true,
  "guest_confirmed": true,
  "completed_at": "..."
}
```

Не включать address, coordinates, chat content, private feedback.

Один StayRequest → максимум один verified interaction.

---

# 21. Hospitality Reputation / Trust

Подтвержденное проживание является высокодоверенным evidence class относительно неподтвержденной обычной peer-оценки.

При этом:

- Account Rating не менять;
- клиент не задает `rating_impact`;
- complaint не дает автоматический penalty;
- `completed` не равно verified physical stay;
- review не превращается в Psychology score;
- Hospitality не становится hidden Compatibility multiplier.

Negative flow:

1. no-show/violation claim;
2. Trust Incident;
3. evidence;
4. moderation;
5. confirmed decision;
6. при необходимости restriction/negative Trust evidence;
7. appeal path сохраняется.

---

# 22. No-show

Автоматически надежно определить физическую неявку только по календарю нельзя.

Поэтому `no_show` — заявление участника, которое проходит moderation.

Автоматический reputation penalty без подтверждения запрещен.

---

# 23. Интеграция с People Discovery

Существующий `/v1/people` расширить optional filters:

```text
can_host=true
hospitality_city_id=
stay_check_in=
stay_check_out=
stay_guests=
sleeping_condition=
eligible_only=
```

Не создавать второй каталог пользователей.

Новые поля `Person` response сделать optional для backward compatibility.

---

# 24. Host Card

Добавить блок «Условия приема».

Показывать:

- hosting active;
- city/public area;
- sleeping condition;
- max guests;
- max days;
- house rules summary;
- Account Rating хоста;
- Hospitality reputation summary;
- verified stays;
- разрешенные Compatibility/QF результаты;
- eligibility текущего guest.

Не показывать exact address/coordinates/contact/raw assessment/private moderation.

---

# 25. Eligibility UI

PASS:

`Вы соответствуете требованиям хоста`

Кнопка `Запросить проживание` активна.

Rating fail:

`Требуется рейтинг 85.0. Ваш рейтинг: 81.5.`

Tests fail:

`Необходимо пройти: ...`

Capacity/date fail:

`На выбранные даты мест нет.`

Не раскрывать данные других гостей.

---

# 26. Экран «Мой дом / Гостеприимство»

Обязательные элементы:

1. Hosting active switch.
2. City.
3. Public area.
4. Exact address.
5. Arrival instructions.
6. Arrival contact.
7. Sleeping condition.
8. Max guests.
9. Max days.
10. House rules editor.
11. Account Rating gate.
12. Required tests picker.
13. Availability mode.
14. Calendar.
15. Public preview.
16. Accepted-guest private preview.

Нельзя включить hosting active при неполной конфигурации.

---

# 27. Required Tests Picker

Источник — существующий catalog `f001..f100`.

В HostProfile хранить только test codes.

Backend обязан валидировать существование каждого кода.

---

# 28. Calendar UX

Host:

- available periods;
- unavailable periods;
- accepted stays как занятые интервалы;
- capacity override.

Guest:

- видит только факт availability;
- не видит личности/requests других гостей.

---

# 29. Request Modal

Поля:

- check-in;
- check-out;
- guests count;
- message.

До submit показать:

- max days;
- max guests;
- eligibility;
- house rules;
- предупреждение о приватности адреса.

После submit открыть request detail/conversation.

---

# 30. Chat Integration

При StayRequest:

1. найти существующую direct conversation;
2. если нет — создать;
3. сохранить `conversation_id`;
4. создать Hospitality event;
5. Android объединяет E2EE messages и structured Hospitality cards в timeline.

Пример:

```text
Запрос на проживание
10–13 сентября
1 гость
Статус: Ожидает ответа
```

После acceptance:

```text
Статус: Принято
[Открыть данные прибытия]
```

Exact address не вставлять в system message.

---

# 31. Push Notifications

Использовать существующий `push_tokens`.

Host при новом request получает safe summary:

- display name;
- dates;
- guests count;
- Account Rating;
- required tests result;
- разрешенный matching summary.

Не помещать:

- exact address;
- hidden tests;
- private message plaintext;
- private feedback.

Guest events:

- accepted;
- rejected;
- expired;
- cancelled by host;
- review available;
- reviews published.

---

# 32. Exact Address в Android

Exact arrival details не хранить в обычном cache.

Создать secure local store:

- Android Keystore;
- AES/GCM;
- per-install key;
- expiry metadata.

Plaintext SharedPreferences запрещены.

---

# 33. Map

До acceptance:

- `cities.center_lat/center_lon` или безопасная публичная точка.

После acceptance:

- exact coordinates из accepted request snapshot.

Exact coordinates не входят в public host DTO.

---

# 34. Host disables hosting

При `is_hosting_active=false`:

- новые requests запрещены;
- host исчезает из discovery;
- pending requests рекомендуется переводить в `rejected` с system reason `HOST_DISABLED_HOSTING`;
- accepted stays не отменяются молча;
- accepted arrival snapshot сохраняется до отдельной cancellation/lifecycle policy.

---

# 35. Host edits conditions

Новые условия влияют на новые requests.

Уже созданный request сохраняет eligibility snapshot.

Перед acceptance повторно проверяются capacity/date/block/restriction.

Accepted stay использует acceptance-time arrival snapshot.

---

# 36. User Blocks

Существующий `user_blocks` — hard gate.

При block в любую сторону:

- нельзя создать request;
- нельзя accept;
- discovery обязан учитывать privacy rules;
- private arrival details не выдавать новым доступом.

Block после acceptance требует safe cancellation/report UX и отдельной проверки физической безопасности.

---

# 37. Rate Limiting / Anti-abuse

Добавить конфигурируемые ограничения на:

- массовое создание requests;
- повторные requests одному host;
- host ID enumeration;
- review spam;
- confirmation replay;
- status replay.

Конкретные числовые лимиты определить при implementation cycle после проверки общей rate-limit архитектуры проекта.

---

# 38. Idempotency

Idempotent должны быть:

- request create;
- accept;
- reject;
- cancel;
- confirmation;
- review publication;
- scheduler tick;
- verified interaction creation;
- reputation evidence application.

Для create предусмотреть idempotency key/client request id.

---

# 39. Optimistic Concurrency

`stay_requests.version` увеличивается при каждом state change.

Client передает `expected_version`.

При stale version:

`409 HOSPITALITY_VERSION_CONFLICT`.

---

# 40. Offline-first

Можно кэшировать:

- public host summary;
- собственные requests;
- public events;
- house rules;
- review state.

Нельзя plaintext-кэшировать:

- exact address;
- exact coordinates;
- arrival contact;
- private feedback;
- E2EE plaintext.

Offline acceptance не является окончательным без backend acknowledgement.

---

# 41. Simulation / Demo parity

Обновить:

- `DemoBackendSimulator`;
- `DemoSimulationEngine`;
- `DemoRepository`;
- Android demo state;
- `BROTHERHOOD_UI_DEMO.html`, если входит в действующий release-parity contract.

Simulation обязана воспроизводить:

- HostProfile;
- availability;
- eligibility;
- request lifecycle;
- address reveal;
- expiry;
- completion;
- blind reviews;
- publication;
- restrictions;
- capacity conflict.

Не заменять state machine статичными картинками.

---

# 42. Backend integration points

## `backend/app/models.py`

Добавить модели:

- HostProfileUpsert;
- HostProfilePrivateRecord;
- HostPublicSummary;
- HospitalityAvailabilityUpsert;
- HospitalityEligibilityResponse;
- StayRequestCreate;
- StayRequestRecord;
- StayRequestStatusAction;
- StayConfirmationUpsert;
- StayReviewUpsert;
- StayReviewRecord;
- HospitalityReputationSummary;
- HospitalityRequestEvent.

## Новый `backend/app/hospitality.py`

Разместить:

- eligibility engine;
- state machine;
- encryption/decryption;
- capacity orchestration;
- blind review publication;
- verified stay logic;
- scheduler/tick;
- reputation evidence orchestration.

## `backend/app/repository.py`

PostgreSQL CRUD/queries.

## `backend/app/storage.py`

Memory/debug implementation с теми же contracts.

## `backend/app/main.py`

Routes.

## `backend/schema.sql`

Canonical schema parity.

## `backend/.env.example`

Encryption/config contracts.

## `backend/tests/`

Новый Hospitality test suite.

## `docs/openapi.json`

Обновить после реализации.

---

# 43. Android integration points

Создать `model/HospitalityModels.kt`.

Models:

- HostProfile;
- HostPublicSummary;
- HospitalityEligibility;
- HospitalityAvailability;
- StayRequest;
- StayRequestStatus;
- StayReview;
- StayConfirmation;
- HospitalityEvent;
- HospitalityReputation.

Создать `network/HospitalityRemoteRepository.kt` и использовать существующий `BrotherhoodApi`.

Интеграции:

- `MainViewModel.kt`;
- `BrotherhoodApp.kt`;
- `ServiceScreens.kt`;
- People discovery;
- Candidate profile;
- Chat timeline;
- Push routing;
- secure local store;
- DemoBackendSimulator;
- DemoSimulationEngine;
- DemoRepository.

Unrelated refactoring запрещен.

---

# 44. UI Routes

Добавить service routes:

- `HOSPITALITY_HOME`
- `HOSPITALITY_HOST_SETTINGS`
- `HOSPITALITY_AVAILABILITY`
- `HOSPITALITY_REQUESTS`
- `HOSPITALITY_REQUEST_DETAIL`
- `HOSPITALITY_REVIEW`
- `HOSPITALITY_STAY_DETAILS`

Home primary structure не менять.

---

# 45. Экраны

## Hospitality Home

- host status;
- ближайшие визиты;
- входящие requests;
- исходящие requests;
- reviews pending;
- Hospitality reputation;
- settings.

## Host Settings

Полная форма HostProfile.

## Availability Calendar

Управление availability.

## Incoming Requests

- guest;
- dates;
- guests count;
- Account Rating;
- required tests status;
- Compatibility/QF summary;
- Accept/Reject.

## Outgoing Requests

- host;
- dates;
- status;
- cancel;
- chat;
- address после accepted.

## Stay Details

- dates;
- participants;
- exact address;
- map;
- arrival instructions;
- contact;
- house rules;
- chat;
- cancel/report.

## Review

Критерии:

- Адекватность;
- Соблюдение правил;
- Соответствие описанию.

Поля:

- public review;
- private feedback.

---

# 46. Репутация в профиле

Добавить отдельный Hospitality block:

- verified stays as host;
- verified stays as guest;
- average published review;
- review count;
- host active status;
- Hospitality Reputation/Trust indicator, когда policy активна.

Не заменять существующие metrics.

---

# 47. Privacy rules

1. exact home address — private;
2. exact coordinates — private;
3. arrival contact — private;
4. private feedback — moderation-only;
5. raw tests — forbidden;
6. E2EE plaintext — server-inaccessible;
7. push — no sensitive payload;
8. logs — no private address;
9. analytics — only safe event metadata;
10. public reviews — only after blind publication;
11. unpublished review cannot be probed;
12. arrival access — only request participants.

---

# 48. Authorization Matrix

| Resource | Guest | Host | Other | Moderator/System |
|---|---:|---:|---:|---:|
| Public Host Summary | yes | yes | yes | yes |
| Host private settings | no | owner | no | no by default |
| Exact HostProfile location | no | owner | no | no by default |
| Accepted arrival snapshot | participant | participant | no | controlled exceptional path |
| Request | own | own | no | controlled |
| Unpublished peer review | own authored only | own authored only | no | policy-controlled |
| Published review | yes | yes | yes | yes |
| Private feedback | no peer | no peer | no | moderation only |
| Restriction details | safe own state | safe own state | safe summary | yes |

---

# 49. Обязательные security/adversarial tests

1. Third user запрашивает чужой request.
2. Third user запрашивает arrival details.
3. Guest пытается accept.
4. Host пытается действовать как guest.
5. Подмена host ID.
6. Self-request.
7. Обход rating gate прямым POST.
8. Обход required tests прямым POST.
9. Обход max days.
10. Concurrent accepts превышают capacity.
11. Accept expired request.
12. Возврат terminal → pending.
13. Address попадает в host list.
14. Address попадает в logs.
15. Address попадает в push.
16. Blind review probing.
17. Client подставляет rating impact.
18. Client подставляет target review.
19. Complaint сразу снижает reputation.
20. Blocked user получает доступ.
21. Accepted request получает новый address после host edit.
22. Scheduler создает duplicate evidence.
23. Duplicate review.
24. Confirmation replay.
25. Missing localization ломает критическую кнопку.

---

# 50. Database tests

Проверить:

- FK;
- CHECK;
- dates;
- unique reviews;
- confirmation uniqueness;
- cascades;
- indexes;
- migration from current HEAD;
- schema parity;
- no plaintext exact location;
- transactional capacity acceptance.

---

# 51. Backend tests

## HostProfile

- create/update;
- owner auth;
- encryption;
- active/inactive;
- invalid tests;
- invalid rating.

## Eligibility

- rating pass/fail;
- tests pass/fail;
- max guests;
- max days;
- dates;
- availability;
- block;
- restriction;
- self-request.

## Lifecycle

- create;
- accept;
- reject;
- guest cancel;
- host cancel;
- expire;
- complete;
- invalid transitions;
- version conflict.

## Privacy

- no address before accepted;
- address only participants;
- arrival snapshot survives profile edit;
- no address in search/list.

## Blind review

- first hidden;
- second publishes both;
- one publishes after 7 days;
- private feedback not public;
- duplicates rejected.

## Trust

- completed != verified;
- confirmations create verified interaction;
- no-show/dispute prevents auto verification;
- moderation required for penalty.

---

# 52. Android tests

Проверить:

- host toggle;
- HostProfile validation;
- calendar;
- People Hospitality filter;
- eligibility PASS/FAIL;
- request modal;
- incoming request;
- accept/reject;
- secure address screen;
- chat event card;
- cancellation;
- blind review;
- all 13 locale keys;
- offline public cache;
- no plaintext private cache;
- push deep links;
- process recreation;
- stale version handling.

---

# 53. E2E scenarios

## E2E-01 Successful stay

Host config → eligible guest → request → chat → accept → address → complete → both confirm → both review → publish → one verified interaction → reputation evidence exactly once.

## E2E-02 Rating fail

Direct POST блокируется backend.

## E2E-03 Missing test

Backend blocks request.

## E2E-04 Capacity race

Два guests одновременно пытаются занять последний capacity slot. Только допустимый вариант проходит.

## E2E-05 Expired request

Host не может accept после 48h.

## E2E-06 Blind review

Первый review скрыт до второго/deadline.

## E2E-07 No-show

Нет автоматического penalty. Incident → moderation → confirmed decision → restriction/evidence.

## E2E-08 Address privacy

Third user не получает exact address ни через один endpoint.

---

# 54. Observability

Privacy-safe events:

- `hospitality_host_enabled`;
- `hospitality_host_disabled`;
- `hospitality_request_created`;
- `hospitality_request_accepted`;
- `hospitality_request_rejected`;
- `hospitality_request_cancelled`;
- `hospitality_request_expired`;
- `hospitality_stay_completed`;
- `hospitality_stay_verified`;
- `hospitality_review_submitted`;
- `hospitality_reviews_published`;
- `hospitality_restriction_applied`;
- `hospitality_private_details_accessed`.

Никогда не логировать address/coordinates/contact/review text/chat plaintext.

---

# 55. Versioning Contracts

```text
hospitality-profile-v1
hospitality-eligibility-v1
hospitality-request-state-v1
hospitality-stay-verification-v1
hospitality-review-v1
hospitality-reputation-v1
hospitality-private-payload-v1
```

Snapshots сохраняют contract version.

---

# 56. Backward Compatibility

После внедрения:

- пользователи без HostProfile работают как раньше;
- `/v1/people` без Hospitality filters сохраняет прежний основной semantics;
- profiles не требуют принудительной Hospitality-миграции;
- Chat сохраняет conversation semantics;
- Account Rating не меняется;
- assessments не меняются;
- Compatibility/QF engines не меняются;
- Trust incidents не ломаются;
- Home primary actions не меняются.

---

# 57. API/OpenAPI

Обновить:

- FastAPI models;
- `docs/openapi.json`;
- API tests;
- Android DTO parsing.

Разделить DTO:

- PublicHost DTO;
- OwnerHostProfile DTO;
- AcceptedArrivalDetails DTO.

Не использовать один универсальный DTO с private fields, которые просто иногда `null`.

---

# 58. Rollout

1. Добавить migration.
2. Deploy schema.
3. Deploy backend с module disabled.
4. Проверить DB/API.
5. Deploy Android support.
6. Включить controlled feature flag.
7. Test cohort.
8. Privacy/security audit.
9. Расширить rollout.

Feature flag:

```text
HOSPITALITY_ENABLED=false|true
```

---

# 59. Config / Env

```text
HOSPITALITY_ENABLED=
HOSPITALITY_PRIVATE_KEY_ACTIVE_VERSION=
HOSPITALITY_PRIVATE_KEY_V1_B64=
HOSPITALITY_PENDING_TTL_HOURS=48
HOSPITALITY_REVIEW_WINDOW_DAYS=7
```

48 часов и 7 дней — продуктовый контракт.

---

# 60. Account Rating

Hospitality gate использует существующий server-side Account Rating:

```text
account_rating.total_rating >= min_required_rating
```

Отдельный Hospitality Account Rating не создавать.

---

# 61. Required Completed Tests

Источник — canonical backend assessment results.

Android local completion не является authority.

---

# 62. Compatibility и совпадения

В host card/push показывать только существующие public-safe outputs.

Не создавать новый скрытый Hospitality Compatibility score без отдельного контракта.

---

# 63. House Rules

`house_rules` — ordered array строк.

Добавить:

- ограничение количества;
- ограничение длины;
- trim;
- Unicode-safe validation;
- XSS-safe web/HTML rendering.

House rules не использовать как automatic psychological signal.

---

# 64. Reject / Cancellation Reasons

Reject reason optional.

Cancellation reason optional.

Сам по себе текст причины не меняет reputation и не становится penalty без moderation evidence.

---

# 65. Address Access Audit

Каждый запрос arrival details логирует только:

- request_id;
- viewer_global_id;
- timestamp;
- granted/denied.

Private payload в audit не писать.

---

# 66. User Deletion / Deactivation

При удалении account:

- HostProfile исчезает;
- public listing исчезает;
- private payload больше не доступен обычным пользователям;
- accepted upcoming stays получают controlled cancellation/notification flow;
- retention requests/reviews/incidents подчиняется общей project privacy/retention policy.

---

# 67. Review Moderation

Public review может быть:

- published;
- hidden by moderation;
- restored;
- изменен только audit-safe moderation operation.

Private feedback никогда автоматически не публикуется.

---

# 68. Acceptance Criteria всего модуля

Модуль считается внедренным только если:

1. HostProfile работает end-to-end.
2. Exact address encrypted at rest.
3. Public search не раскрывает exact location.
4. Date/capacity filtering работает.
5. Account Rating gate backend-authoritative.
6. Required tests gate backend-authoritative.
7. State machine реализована.
8. 48h expiration работает серверно.
9. Completion scheduler учитывает timezone.
10. Acceptance защищен от race.
11. Direct chat интегрирован без ослабления E2EE.
12. Structured request cards работают.
13. Push не содержит sensitive data.
14. Exact address доступен только accepted participants.
15. Blind reviews работают.
16. 7-day publication работает.
17. Completed не создает auto verified physical stay.
18. No-show/violation penalties требуют moderation.
19. Restrictions связаны с Trust/appeal flow.
20. Hospitality reputation отделена от Compatibility/QF/Account Rating.
21. People discovery интегрирован.
22. Android screens работают.
23. Все 13 locales покрыты.
24. Simulation соответствует реальной state machine.
25. Negative security tests проходят.
26. Existing Brotherhood functionality не удалена/не упрощена.
27. Owner-locked `100×6` unchanged.
28. OpenAPI обновлен.
29. Migration и canonical schema синхронны.
30. Integrated E2E проходит.

---

# 69. План внедрения — 5 циклов

## Цикл 0032 — Hospitality Foundation / Data / Security Contracts

### Реализовать

- migration `0009_hospitality.sql`;
- HostProfile;
- Availability;
- StayRequest;
- RequestEvents;
- StayConfirmations;
- StayReviews;
- HospitalityRestrictions;
- indexes;
- Pydantic DTO;
- encryption contract;
- eligibility service;
- state-machine contract;
- timezone contract;
- feature flag;
- schema parity;
- DB/backend tests.

### DoD

Backend foundation готов, private location зашифрована, owner-locked assessment не изменен, feature может оставаться disabled.

---

## Цикл 0033 — Requests / Availability / Chat / Scheduler / Push

### Реализовать

- HostProfile API;
- Availability API;
- public Host API;
- Eligibility API;
- create/list/detail requests;
- accept/reject/cancel;
- host cancellation;
- 48h expiration;
- completion scheduler;
- atomic capacity;
- optimistic version;
- conversation binding;
- Hospitality events;
- secure arrival snapshot;
- arrival-details endpoint;
- push events;
- IDOR/security tests.

### DoD

Полный backend request lifecycle работает от create до completed.

---

## Цикл 0034 — Blind Reviews / Verified Stay / Trust / Moderation

### Реализовать

- stay confirmations;
- verified stay contract;
- `verified_interactions` integration;
- blind reviews;
- atomic publication;
- 7-day publication;
- private feedback encryption;
- Hospitality reputation summary;
- no-show/dispute incident integration;
- restrictions;
- moderation binding;
- appeals compatibility;
- idempotent reputation evidence;
- anti-retaliation tests.

### DoD

Blind review не допускает retaliation; verified stay создается по evidence contract; allegation не превращается автоматически в penalty.

---

## Цикл 0035 — Android Hospitality UX / Discovery / Map / Chat Cards

### Реализовать

- Hospitality models;
- HospitalityRemoteRepository;
- ViewModel state/actions;
- «Мой дом»;
- Host Settings;
- Availability Calendar;
- People filter «Может принять у себя»;
- city/date/guest filters;
- host profile block;
- eligibility UX;
- request modal;
- incoming/outgoing requests;
- Stay Details;
- safe public map;
- exact accepted map;
- chat cards;
- push deep links;
- review screen;
- reputation profile block;
- secure private local store;
- offline-safe states;
- 13 locales.

### DoD

Полный пользовательский flow работает в APK без раскрытия sensitive location до acceptance.

---

## Цикл 0036 — Release-Parity Simulation / Security / E2E / Integrated RC

### Реализовать/проверить

- DemoBackendSimulator parity;
- DemoSimulationEngine parity;
- DemoRepository parity;
- HTML release-parity representation;
- full lifecycle simulation;
- scheduler simulation;
- capacity races;
- address privacy;
- E2EE boundary;
- blind-review probing;
- idempotency/replay;
- stale version;
- blocks/restrictions;
- moderation;
- 13-locale coverage;
- migration upgrade path;
- OpenAPI parity;
- integrated backend + Android E2E;
- regression audit;
- protected mechanics guard.

### DoD

Hospitality достигает integrated release candidate только после соответствующих evidence gates проекта. Local pass, APK-visible, LIVE E2E и production qualification не подменяют друг друга.

---

# 70. Критические запреты

1. Не удалять существующие функции Brotherhood.
2. Не выполнять unrelated refactoring.
3. Не создавать новый user identity key.
4. Не менять owner-locked `100×6`.
5. Не раскрывать raw tests.
6. Не смешивать Account Rating и Hospitality Reputation.
7. Не смешивать Trust и Compatibility.
8. Не хранить exact address plaintext.
9. Не показывать exact location до accepted.
10. Не помещать exact address в push.
11. Не ослаблять E2EE direct chat.
12. Не хранить request message plaintext вне E2EE.
13. Не позволять Android решать окончательный eligibility.
14. Не позволять Android задавать `rating_impact`.
15. Не штрафовать только по allegation.
16. Не считать `completed` доказательством физического визита.
17. Не публиковать первый blind review досрочно.
18. Не создавать параллельный People catalog.
19. Не создавать параллельную moderation system.
20. Не добавлять пятый primary Home action.
21. Не изменять старые migrations.
22. Не выдавать local pass за production evidence.

---

# 71. Итоговый результат

После завершения циклов `0032–0036` Brotherhood должен получить встроенную систему P2P-гостеприимства, где:

- пользователи могут принимать друг друга;
- хост сам задает входной барьер;
- backend проверяет рейтинг и обязательные тесты;
- поиск работает по городу, датам и capacity;
- точный адрес остается приватным;
- direct chat сохраняет E2EE;
- accepted stay становится формализованным социальным событием;
- подтвержденный визит может стать verified interaction;
- отзывы защищены blind-review механизмом;
- тяжелые нарушения проходят moderation/appeal path;
- Hospitality Reputation отделена от Compatibility;
- модуль усиливает реальные знакомства, дружбу, сотрудничество и личностные связи;
- существующая архитектура Brotherhood не ломается и не заменяется параллельной системой.

---

**Конец технического задания.**
