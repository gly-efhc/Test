# Brotherhood — аудит текущего состояния и дорожная карта 0024–0073

Дата аудита: 2026-08-11  
Базовый DEVELOPMENT HEAD аудита: `Brotherhood_v0_5_57.zip`

Cycle 0024 continuation source candidate: `v0.5.35 / versionCode 40`; governance/source-map synchronization is incorporated before final `Brotherhood_v0_5_58.zip` packaging.  
Плановый диапазон: **50 циклов, 0024–0073 включительно**

Status: **ACTIVE ROADMAP 0024–0073 / owner-approved planning direction**

Active unified source map: `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.*`.

## 1. Основание плана

Новая дорожная карта строится не по количеству документов, источников, классов и маршрутов, а по законченности пользовательского пути и по независимым evidence gates:

`R Research → S Spec → B Backend/Domain → SIM Simulation parity → H HTML implementation → VA Visual acceptance → A Android mirror → CI APK build → E2E Live → PQ Production qualified`.

Запрещено сворачивать эти стадии в один статус `COMPLETED`.

Для user-facing функции обязательна цепочка:

`backend/domain → routes/contracts → Simulation Engine → routes/read models → HTML frontend → owner visual acceptance → Android mirror → CI/APK → live E2E`.

Simulation Engine не является декоративным demo. Он должен воспроизводить тот же contract и ту же бизнес-семантику, что production source, и заполнять все доступные маршруты детерминированными синтетическими данными.

---

# 2. Аудит чата / решений владельца

## 2.1. Зафиксированные обязательные решения

1. **Research ≠ product implementation.** Цикл исследования не закрывает runtime/UI.
2. **HTML-first.** HTML является visual development surface до Compose/APK.
3. **APK/CI не является средством проектирования UI.** Новый APK нужен после visual acceptance соответствующего HTML.
4. **Own Profile не содержит compatibility с самим собой.** Pair metrics появляются только в контексте A↔B.
5. **VK donor:** глубина личности, социальное и профессиональное резюме, интересы, проекты, сообщества и связи.
6. **Telegram donor:** прямое и групповое общение, быстрый timeline, reply/edit/delete/reactions/attachments/typing и переход в профиль из header.
7. **Diia donor:** feature isolation, простой screen shell, progressive disclosure, summary→details, отдельные service/search flows, reusable containers.
8. **Старый 100×6 / 600-task visual bank удалён из активного продукта по прямому решению владельца.** Он не является baseline, fallback или regression-authority. Активный baseline — семь scientific questionnaire systems с versioned item/scoring contracts; новые версии тестов развиваются из научного корпуса и не обязаны сохранять старую visual-механику.
9. **Разные психологические системы разделяются на независимые модули.** Каждая система получает собственный result/profile и собственную pair compatibility `0–100%`.
10. **Q28 сохраняется:** верхнеуровневые `PC/IC/VC/CC/LC/PT/EN/NU/AS` независимы; Overall — только явное простое среднее выбранных доступных метрик. Trust и Quality Fit отдельно.
11. **Numerology — самостоятельная система.** Она не имеет скрытого веса в Psychology; `NU=0–100%` рассчитывается отдельно и versioned.
12. **Simulation architecture:** backend → routes → Simulation Engine → routes → frontend. Нужны реальные структуры всех таблиц/маршрутов и минимум 200 синтетических личностей для полной продуктовой симуляции.
13. **Progressive disclosure ≠ deletion.** Перегруженный функционал переносится в detail/bottom sheet/secondary flow, но не уничтожается.
14. **Не проверил — не утверждай.** Source-only, HTML-visible, APK-visible и live evidence всегда различаются.
15. Позднее владелец предоставит **полный patch карты источников**. Он должен быть интегрирован как новый входной SSOT без уничтожения уже зарегистрированной provenance/history.

---

# 3. Аудит фактического архива v0_5_57

## 3.1. Структура и целостность

- ZIP SHA-256: `0b3950bfd2fe196b623b0baf22ba974ecedc3a59f856cf80297622eebccb217c`.
- Один корень: `Brotherhood/`.
- 883 файлов, 1003 ZIP entries.
- CRC: PASS.
- traversal: 0.
- symlink: 0.
- nested ZIP/APK/AAB: 0.
- Operator Kernel `validate-config`: PASS.
- Kernel config: 16 routes / 8 hooks / 6 agents / 6 skills.

## 3.2. Версия

`PROJECT_MANIFEST.json`:
- `version = 0.5.34`;
- Android `versionName=0.5.34`, `versionCode=39`;
- `development_archive_revision = v0.5.57-cycle0023-functional-recovery`;
- `development_archive_filename = Brotherhood_v0_5_57.zip`;
- `source_archive = Brotherhood_v0_5_56.zip` — это provenance входного архива, а не текущий HEAD.

## 3.3. Фактический source contract

Текущий generated source contract содержит:
- **80 OpenAPI paths**;
- **93 HTTP operations**;
- **47 migration-defined DB tables**;
- **21 Android AppRoutes**.

При этом HTML workbench всё ещё показывает старую подпись **70 API operations / 39 DB tables**. Это подтверждённый simulator/documentation drift.

## 3.4. Simulation gap

В `BROTHERHOOD_UI_DEMO.html` текущий `people` fixture содержит **6 кандидатов**. Есть ещё 3 owner/persona fixtures, но это не выполнение требования 200 simulated people.

Следовательно:

`200-person full simulation = NOT IMPLEMENTED in v0_5_57`.

## 3.5. Psychological Report

В Android source существует `PsychologicalProductEngine` и deterministic report snapshot.

Но в v0_5_57:
- нет dedicated DB migration Psychological Report history;
- нет persistent immutable report-history API;
- HTML сам пишет, что persistent report history ещё не подключена.

Статус:

`Psychological Report generation = SOURCE_IMPLEMENTED/PARTIAL`  
`Psychological Report persistence/history = MISSING`.

## 3.6. Compatibility backend

`/v1/compatibility` сейчас остаётся legacy visual-test-layer endpoint. Он рассчитывает общность существующих assessment IDs и category scores, но не является server-authoritative Q28 contract для `PC/IC/VC/CC/LC/PT/EN/NU/AS`.

Статус:

`Independent Q28 Android/domain adapter = SOURCE_IMPLEMENTED`  
`Server-backed independent Q28 contract = MISSING/PARTIAL`.

## 3.7. Current test bank

Текущий source baseline содержит 100 серий × 6 visual tasks и 10 групп:
- LOYALTY;
- INTEGRITY;
- RELIABILITY;
- CONFLICT;
- BOUNDARIES;
- SUPPORT;
- COMPETITION;
- COMMUNICATION;
- MUTUAL_AID;
- LIFESTYLE.

Это фактический baseline, а не финальный вечный product design.

## 3.8. Roadmap tooling drift

`CYCLE_STATUS_REGISTRY.md` уже назначает:
- 0023 = functional recovery;
- 0024 = report persistence/server compatibility contracts;
- 0025–0028 = UI recovery / acceptance / mirror.

Но `ops/operator_kernel/check_cycle_ecosystem.py` всё ещё ожидает старую схему:
- 0024 = Psychological Analysis;
- 0025 = Full Psychological Report.

В результате cycle ecosystem checker фактически падает на stale token expectation.

Статус:

`cycle registry = NEW MODEL`  
`cycle ecosystem checker = STALE / REQUIRES SYNCHRONIZATION`.

## 3.9. Handoff drift

Верхняя часть `CURRENT_HANDOFF.md` уже ссылается на cycle 0023/v0.5.34 и 0024 как следующий dependency. Ниже в том же handoff сохранён старый session block с `v0_5_56` и предыдущей последовательностью Tests→Analysis→Report.

Историю удалять нельзя, но active/historical boundaries должны быть сделаны машинно однозначными.

---

# 4. Аудит источников

## 4.1. Центральный registry — RESOLVED IN CYCLE 0024 CONSOLIDATION

Pre-consolidation audit found a parallel 189-source registry. It has now been machine-matched `189/189` into `BROTHERHOOD_SOURCE_MAP_v004.json`; missing=0, ambiguous=0. The unified map contains 225 canonical sources and is the sole active source SSOT.
Former 189-source subset audit before removal:
- matched unique source IDs = 189/189;
- duplicate IDs = 0;
- duplicate URLs = 0;
- missing mappings = 0; ambiguous mappings = 0.

Current canonical map:
- 225 unique canonical source IDs / 225 unique canonical URLs;
- 6 typed authority classes;
- active source registries = 1.

Права/provenance:
- 60 источников: `OWNER_CONFIRMED_COMMERCIAL_RELEASE_PERMISSION`;
- 129 источников: `CITATION_RESEARCH_REFERENCE_ONLY_NO_EMBEDDING_PLANNED`.

`CLAIM_EVIDENCE_LEDGER.json`:
- 157 claims;
- source references expanded with methodology claims;
- unresolved source references remain 0;
- `production_scoring_allowed=false` for all registered methodology additions; no silent scoring import.

Это означает: scientific corpus разрешён для research synthesis/constructs/validation в пределах его правил, но опубликованные эффекты не становятся production weights автоматически.

## 4.2. Registry drift — RESOLVED

The stale 189-source JSON/Markdown pair is removed from the active tree after full data migration. Scientific evidence/provenance/authorization/cycle lineage now live inside the 224-source typed map; a second active source registry is forbidden.

## 4.3. Неравномерность покрытия

По source-ID/domain classification сильнее представлены:
- Values — 27 IDs;
- Friendship — 23;
- Business — 15;
- Worker/team — 12;
- Personality Type — 11;
- Communication — 11;
- Visual/forced-choice — крупный отдельный корпус;
- Interests — 8;
- Mentoring — 8;
- Lifestyle — 7.

Тонкие зоны текущего центрального registry:
- Enneagram — 1 прямой source ID;
- Numerology — 1 прямой software/traditional provenance source;
- Astrology — 2 direct/traditional/negative-test references;
- VK — нет отдельного source ID;
- Telegram — нет отдельного source ID;
- Hospitality — нет явно классифицированного hospitality source ID в центральном compatibility registry.

Это не доказывает отсутствие материалов во всём архиве; это факт именно центрального registry.

## 4.4. Diia

`DIIA-UX-001` уже присутствует в registry. Официальный `diia-open-source/android-diia` подтверждает modular feature/library architecture и reusable screen infrastructure. Этот источник используется только как UX/architecture donor, не как основание копировать бренд, персональные данные, assets или продуктовый UI один-в-один.

## 4.5. Правило для будущего source-map patch

Когда владелец пришлёт полный patch карты источников:
1. patch становится новым входом текущего active cycle — не нужно ждать отдельного номера;
2. текущие 189 entries не удаляются без явного supersession mapping;
3. выполняется dedupe by canonical URL/DOI/title/ID;
4. отдельно фиксируются scientific grade, rights, applicability, embedding rights, research-only status и production eligibility;
5. source→construct→measurement→algorithm→runtime→UI→validation trace становится обязательным.

---

# 5. 50-цикловая дорожная карта 0024–0073

## Фаза I — Functional/UI Recovery Gate (0024–0028)

### 0024 — Psychological Report Persistence + Server Compatibility + Recovery Simulation Contract
**Цель:** закрыть runtime-разрыв, оставшийся после 0023.

**Реализация:**
- immutable Psychological Report snapshot persistence;
- `report_id`, report/model versions, created_at, safe input fingerprint, coverage, completed assessments, sections, limitations;
- API: create/regenerate, latest, history, report-by-id;
- idempotency для одинакового input/version;
- server-backed independent `PC/IC/VC/CC/LC/PT/EN/NU/AS` response;
- nested psychological module scores `0–100%` с coverage/model provenance;
- persistence пользовательского selected metric set;
- отсутствие данных = explicit `INSUFFICIENT_DATA`, а не искусственный `0%`;
- generated source contract пересчитывается автоматически;
- Simulation Engine получает те же report/compatibility routes;
- dataset расширяется до **200 deterministic synthetic people** с профилями, тестовыми результатами, интересами, ценностями, lifestyle, PT/EN/NU/AS и роль-контекстами;
- simulator workbench показывает реальные generated contract counts, не hardcoded 70/39.

**Exit gate:** `B=PASS`, `SIM=PASS`, HTML consumes simulated route contract; report history and independent metrics actually round-trip through route layer.

### 0025 — UI Recovery A: My Profile → People → Candidate → Compatibility → Tests/Psychology
**Цель:** сделать центральную пользовательскую вертикаль визуально понятной.

**Реализация:**
- Own Profile как early-VK-depth digital resume, без self-compatibility;
- People search по 200 simulated profiles;
- role/context chips, quick filters, advanced filters as bottom sheet;
- Candidate page: сначала человек, затем details;
- Compatibility Details с независимыми системами;
- Tests Home, module details, execution, result, history;
- Psychological Profile + Psychological Report + report history;
- Diia-like screen shell: top/body/bottom, grouped lists, one primary task per screen;
- весь функционал скрывается только progressive disclosure, не удаляется.

**Exit gate:** полный standalone HTML для этих surfaces; `VA=PENDING` до явного решения владельца.

### 0026 — UI Recovery B: Chat → Groups → Search Requests
**Cycle 0026 achieved status (2026-08-11):** `SOURCE_HTML_IMPLEMENTED / ROUTE_BACKED_SIMULATION / VA_PENDING`. Search Requests persistence/API and explicit Community membership were added; Chat existing backend contract was preserved and surfaced through the simulator. Current generated inventory: `90 paths / 108 operations / 50 tables / 21 Android AppRoutes`.

**Цель:** оживить коммуникационный и intent-контур.

**Реализация:**
- Telegram-class direct chat timeline;
- reply/edit/delete/reactions/attachments/typing/read states;
- group chat shell;
- Groups/Communities: interest/business/project/mutual-aid contexts;
- Search Requests как отдельный flow поиска людей/партнёров/команд;
- переходы Candidate↔Chat↔Group↔Search Request;
- simulator events и persistence для всех actions.

**Exit gate:** полный HTML flow + backend/simulator route parity, без Compose mirror до visual acceptance.

### 0027 — Root IA + Development Hub + contextual Trust/Hospitality recovery
**Owner Q45 priority:** replace the obsolete authenticated Home root with the canonical shell `Профиль → Люди → Чаты → Группы → Развитие`.

**Implementation:**
- root tabs in exactly the owner order: Profile, People, Chats, Groups, Development;
- Profile is the first/default authenticated page and remains the user's own digital resume;
- Search Requests move under People/discovery;
- Development is a Diia-style catalog, not a dashboard;
- primary Development apps: Tests, Numerology, Zodiac;
- every Development app must open a complete standalone flow with state/history/details/actions;
- Tests use the already implemented 7-system/197-item baseline and expose result/history/Profile/Report;
- Numerology and Zodiac receive product entry shells ready for their dedicated 0030/0031 full productization;
- Trust lives in Profile/Candidate/reputation context, not as a root tab;
- Hospitality lives in Profile/Candidate/interaction context, not as a root tab;
- HTML-first implementation over the full Simulation Engine; no Compose mirror before owner VA.

**Exit gate:** integrated HTML root shell and Development catalog are visually reviewable end-to-end; old Home root is absent from active navigation; no existing Trust/Hospitality functionality is deleted.

**Cycle 0027 achieved status (2026-08-13):** `SOURCE_HTML_IMPLEMENTED / ROUTE_BACKED_SIMULATION / VA_PENDING`. Root navigation now follows Q45; Development exposes Tests/Numerology/Zodiac as standalone flows. Tests product layer contains 12 thematic apps partitioning all 197 active questionnaire items exactly once over 7 internal scientific systems. Generated source contract: `100 paths / 118 operations / 50 tables / 21 Android AppRoutes`; local simulator probe `118/118`, failures `0`.

### 0028 — Scientific Questionnaire Systems v1.2 → owner HTML VA gate
**Owner-directed product correction (2026-08-11):** the former generated `100×6 / 600-task` visual branch and its blocking control layer are removed from active product authority. Cycle 0028 now productizes the authorized scientific corpus directly into a release-usable questionnaire baseline instead of waiting for future multi-year outcomes or for a visual-stimulus redesign.

**Active baseline:**
- `scientific-questionnaire-bank-v1.2`;
- 7 independent systems;
- 197 active items;
- 64 construct-system pairs;
- minimum 3 independent signals per construct-system pair;
- 17 public-domain IPIP anchors + 180 Brotherhood-original situational/redundancy/triangulation items;
- server-authoritative deterministic `scientific-questionnaire-v1` scoring;
- independent pair compatibility `0–100%` for each psychological system;
- source/claim trace from the single 225-source SSOT;
- visual forced-choice literature is not active questionnaire scoring evidence.

**Scientific correction:** broad Mini-IPIP anchors remain broad-factor anchors (`social_energy`, `agreeableness_orientation`, `conscientiousness_orientation`, `emotional_stability`, `openness_intellect`) rather than being mislabeled as narrow facets. Primary situational items use construct-relevant neutral contexts instead of recycled generic scenarios. Original Brotherhood wording is explicitly an adaptation; source/claim trace supports construct/method synthesis and does not pretend the sentence is a literal published item.

**Runtime/product path:**
`source → claim → construct → versioned item → backend scoring → per-system result → Psychological Profile/Report → independent compatibility`.

The current simulator contract is `114 OpenAPI paths / 133 HTTP operations / 54 DB tables / 21 Android AppRoutes / 200 synthetic candidates`. The frontend uses the Simulation Engine boundary; the removed visual bank is not a fallback.

**Launch/recalibration rule:** v1 launches from the existing authorized scientific corpus. Production outcomes collected later are versioned post-release recalibration evidence for possible v2/v3; they do not block v1 and never mutate scoring automatically.

**HTML acceptance sequence:**
1. owner reviews `BROTHERHOOD_UI_SIMULATOR_v0_5_41.html`;
2. corrections stay HTML-first until explicit `VA=PASS`;
3. accepted HTML is frozen by version/hash;
4. only then complete visual Compose mirror and APK/CI gate.

**Current exit status:** `R=PASS / S=PASS / B=SOURCE_IMPLEMENTED_LOCAL_TESTED / SIM=PASS_LOCAL / H=IMPLEMENTED_CANDIDATE / VA=PENDING / A=SOURCE_UPDATED_NOT_VISUALLY_ACCEPTED / CI=NOT_RUN / E2E=NOT_RUN`.

---

## Фаза II — Independent Model Productization (0029–0037)

### 0029 — Associative & Implicit Measurement Systems v1
**Priority:** high. The active 7-system questionnaire is retained as the conscious/situational lane; this cycle adds an independent non-self-report lane rather than replacing it.

**Scientific basis:** registered Freud free-association lineage, Jung/Zurich word-association methodology and Greenwald/McGhee/Schwartz IAT/reaction-time methodology; method variance/multi-method evidence requires method provenance to remain explicit.

**Implementation order:**
1. `WORD_ASSOCIATION_V1` — standardized cue bank, first response, latency, edits/omissions/repetitions, semantic features, result/history;
2. `ASSOCIATIVE_FREE_CHAIN_V1` — cue → free association chain with latency/transitions and user-readable thematic summary; no universal symbolic dictionary;
3. `IMPLICIT_ASSOCIATION_RT_V1` — compatible/incompatible blocks, trial latency/errors, device/timing-quality controls and independent result.

**Data contract:** every raw event stores stimulus/version/order, response/action, latency, correction/error state, quality metadata and model version. Raw/private features do not leak to public candidate UI.

**Compatibility:** any associative/implicit pair score is a separate versioned `0–100%` method metric. It is not silently averaged with questionnaire PC, Trust or Quality Fit.

**Exit gate:** at least Jung Word Association and IAT complete `backend → routes → Simulation Engine → HTML → result/history`, with Freud free-association runtime present or explicitly PARTIAL with exact remaining work.

**Cycle 0029 achieved status (2026-08-13):** `SOURCE_HTML_IMPLEMENTED / SIM=PASS / VA=PENDING`. All three methods are implemented, not partial: `WORD_ASSOCIATION_V1` (24 cues), `ASSOCIATIVE_FREE_CHAIN_V1` (8 seeds × 5 transitions), `IMPLICIT_ASSOCIATION_RT_V1` (48 trials / 32 critical). Result/history and per-method pair compatibility are source-implemented. Generated source contract: `108 paths / 127 operations / 52 tables / 21 Android AppRoutes`; local simulator probe `127/127`, failures `0`.

**Owner Q48 reverse research extension:** cycle 0029 also implements `Reverse Friendship Pattern Discovery v1`. For mutually confirmed friendships, Brotherhood preserves the pre-friendship/exposure predictor snapshot and compares similarity, difference/complementarity and method-level features against sufficiently exposed comparison pairs. Output is descriptive pattern evidence/hypothesis only; it never auto-mutates production scoring. Detailed contract: `docs/research/outcomes/REVERSE_FRIENDSHIP_PATTERN_DISCOVERY_V1.md`.

### 0030 — Numerology standalone application vNext
**Цель:** превратить существующий NU runtime в полностью описанную standalone system.

**Реализация:**
- аудит текущих `VedicNumerologyEngine` и `NumerologyReadingEngine`;
- versioned calculation spec;
- birth-date inputs отдельно от name-based interpretations;
- deterministic edge-case test vectors;
- NU profile, detail, history;
- NU pair compatibility `0–100%` с component breakdown;
- explicit traditional/non-psychometric disclosure;
- backend/simulator/HTML/Android parity.

**Exit gate:** fixed input+version → fixed result; no hidden 5% semantics.

**Cycle 0030 achieved status (2026-08-13, same-cycle expanded pass):** `SOURCE_HTML_IMPLEMENTED / NUMEROLOGY_READING_V3 / SIM=PASS / VA=PENDING`. Server-authoritative `numerology-reading-v3` keeps the existing date-based semantics and adds transparent calculation traces, ruler metadata, a complete 1–9 date-digit inventory, exact calendar dates for the four already-defined Pinnacle ages, and read-only access to the full 97-record / 5-group normalized `numerology-knowledge-v1` catalog. Persistent `NU 0–100%` pair history now freezes the date-derived Soul/Destiny inputs and exposes ruler/relation details while preserving Soul 40% / Destiny 35% / cross 15% / date composite 10% as **internal NU components only**. Name-derived values remain descriptive-only. No unsupported personal-year/month/day or alternate tradition was introduced. Generated source contract: `117 paths / 136 operations / 54 tables / 21 Android AppRoutes`; local simulator probe `136/136`, failures `0`. Owner Q49 Friendship Reflection Surveys remain a future research-only mechanism, not runtime scoring in 0030.

### 0031 — Zodiac standalone application
**Цель:** отделить basic Zodiac от более сложной Astrology.

**Реализация:**
- AS registry и model versions;
- basic birth-date zodiac layer;
- future richer astrology only behind explicit version;
- AS pair compatibility `0–100%`;
- scientific/traditional labeling;
- independent HTML detail.

**Exit gate:** AS самостоятельна и никогда не выдаётся за psychological evidence.

**Cycle 0031 achieved status (2026-08-13):** `SOURCE_HTML_IMPLEMENTED / AS_ZODIAC_BASIC_V1 / SIM=PASS / VA=PENDING`. The existing birth-date sign boundaries and Q28/Android basic AS rule were consolidated into a single server-authoritative `zodiac-runtime-v1` scorer. Cycle 0031 adds immutable `zodiac-basic-reading-v1` history, a route-backed 12-sign catalog, transparent method/scientific-boundary UI and persisted pair comparison/history with frozen sign snapshots. Exhaustive regression covers all 144 ordered sign pairs against Q28 AS parity. No natal chart, houses, aspects, Moon, Ascendant or synastry were invented; `AS_SYNASTRY_V1` remains future-only. Generated source contract: `126 paths / 145 operations / 56 tables / 21 Android AppRoutes`; local simulator probe `145/145`, failures `0`, schema16. Root `Развитие` is active in HTML/CANON; Android remains on the pre-Q45 `HOME` root only because Compose mirroring is still gated by owner VA.

### 0032 — Enneagram standalone optional application
**Цель:** productize Enneagram only after the higher-priority questionnaire/associative lanes and Development shell are operational.

**Implementation:** standalone EN profile/result/version/history, source/method disclosure, pair compatibility `0–100%`, Development-app shell, backend/simulator/HTML/Android parity when visually accepted.

**Exit gate:** EN remains independent from scientific questionnaire psychology, Numerology, Zodiac and Trust.

**Cycle 0032 achieved status (2026-08-13):** `SOURCE_HTML_IMPLEMENTED / EN_BROTHERHOOD_CORE_PROFILE_V1 / DEVELOPMENT_FULL_DEMO_V1 / SIM=PASS / VA=PENDING`. Productized the existing 18-item (2×9 type) Brotherhood visual Enneagram instrument, deterministic type/wing runtime and existing Q28 EN scorer into immutable readings/history, route-backed 9-type catalog and persisted pair comparison/history. `ENNEA-001` keeps the module typological/experimental with mixed reliability/validity evidence; no new type psychology is invented. The Simulator now explicitly boots a full Development demo: 12/12 Tests, 3/3 Associative methods, and saved NU/AS/EN readings plus pair histories. Generated source contract: `136 paths / 155 operations / 58 tables / 21 Android AppRoutes`; schema17; local operation probe `155/155`, failures `0`. Android remains unchanged pending owner VA; the owner-requested Development demo activation is implemented in standalone Simulator code.

### 0033 — Quality Fit / SearchIntent v2
**Цель:** вычислять не «насколько люди одинаковые», а насколько конкретный человек соответствует текущему запросу пользователя.

**Реализация:**
- role/search intent;
- desired qualities/requirements selected by the searching user;
- hard constraints vs preferences;
- directional `A → B` score;
- Quality Fit separately from Compatibility and Trust;
- explanation + missing data;
- Search Requests live inside the People domain under owner Q45.

**Exit gate:** separate QF contract/UI/history with no hidden psychological moral ranking.

**Cycle 0033 achieved status (2026-08-16):** `SOURCE_HTML_IMPLEMENTED / QUALITY_FIT_SEARCH_INTENT_V2 / STABLE_SERVICE_UX / CHROMIUM_E2E_PASS / VA=PENDING`. Added `quality-fit-search-intent-v2` + `quality-fit-directional-v2` with only explicit user requirements, separate hard/preference semantics, `INSUFFICIENT_DATA` for missing evidence, persisted/idempotent evaluation history and a route-backed A→B detail surface. Migration 0018 adds structured SearchIntent requirements and only one new table, `quality_fit_evaluations`. The Development/Test demo was also stabilized after owner feedback: all 12 seeded tests are immediately retakeable without weakening the calendar-month product rule; background engine ticks/non-current messages no longer reset scroll/focus; Development/Tests/results use a calmer service-first hierarchy informed by PRODUCT_DONOR research. Real Chromium gate completes a seeded test, preserves scroll `500→500`, opens Quality Fit, reports zero runtime errors and probes all `160/160` operations. Generated source contract: `141 paths / 160 operations / 59 tables / 21 Android AppRoutes`; schema18. Android remains unchanged pending owner VA.

### 0034 — Unified Multi-method Compatibility Service + persistence
**Цель:** make server/domain the canonical compatibility authority while preserving every method/metric independently and reproducibly.

**Реализация:**
- canonical server service for `PC/IC/VC/CC/LC/PT/EN/NU/AS`;
- questionnaire psychological system scores remain independent;
- associative/implicit method scores from 0029 remain separately inspectable and versioned;
- selected metrics + optional arithmetic Overall only for explicitly selected available top-level metrics;
- per-metric/method model version, input version, coverage, status and calculation fingerprint;
- PostgreSQL score snapshots, selection preferences, model manifests, recency/invalidation and privacy-safe input provenance;
- role context passed explicitly;
- no invented score when evidence is insufficient;
- no hidden permanent weight between conscious, implicit, esoteric or observed-behavior channels.

**Exit gate:** backend, Simulation Engine and clients use one reproducible persisted compatibility contract.

### 0035 — Compatibility Page + Metric/Method Detail IA
**Цель:** превратить проценты в понятный продукт.

**Реализация:**
- summary page;
- metric checkboxes;
- one detail screen per metric;
- nested psychological system details;
- “что учитывалось / чего не хватает / версия / ограничения”;
- Quality Fit and Trust side-by-side but not averaged.

**Exit gate:** visual acceptance отдельного Compatibility experience.

### 0036 — Trust v2 + observed-behavior evidence boundaries
**Цель:** make Trust explainable from verified events while preparing a separate observed-behavior research lane without contaminating psychology.

**Implementation:**
- verified interactions, moderation decisions, appeals, recency/evidence provenance;
- Hospitality Reputation remains separate;
- observed-behavior event definitions are explicit/versioned and may later compare stated traits with real outcomes;
- behavior/outcome evidence never becomes an automatic Trust bonus or an automatic psychological score update;
- launch-day provenance is retained for later 0038 recalibration analysis.

**Exit gate:** Trust is explainable from evidence; observed-behavior research data are separately typed and reproducible.

### 0037 — Release-Parity Simulation Engine v2
**Цель:** симуляция всей расширенной модели, а не отдельных screens.

**Реализация:**
- all current backend operations/tables/routes auto-imported from source contract;
- 200+ deterministic people;
- complete synthetic social graph;
- assessment/report/compatibility/trust/hospitality/search/chat/group datasets;
- deterministic event/tick lifecycle;
- route request/response fixtures generated from canonical models;
- parity guard: route/table removed or added in backend → simulator check fails until synchronized.

**Exit gate:** simulator parity is machine-checked, not manually declared.

---

## Фаза III — Outcomes / Fairness / Pilot / RC-1 (0038–0041)

### 0038 — Post-Release Outcome Data Capture & Recalibration Runtime
**Цель:** замкнуть research→real outcome feedback без auto-learning.

**Реализация:**
- exposure snapshots;
- voluntary 7/30/90/180/365-day outcomes;
- relationship status changes;
- friendship/project/hospitality outcomes;
- frozen prediction provenance;
- research exports with privacy controls;
- **Q49 Friendship Reflection Surveys:** versioned eligibility/invitation policies after verified meetings or mutual friendship confirmation, independent bilateral survey responses, consent/purpose/retention state, and join to frozen pre-friendship Q48 snapshots;
- research-only derived features such as bilateral factor agreement, reported similarity/complementarity, measured-vs-reported alignment, factor frequencies/interactions and unexplained-friendship residuals.

**Exit gate:** prediction and later outcome связаны; Q49 can demonstrate `verified interaction/friendship → eligible invitation → independent A/B responses → research join/aggregate`; future model promotion still requires separate review.

**Q48 hardening:** extend Reverse Friendship Pattern Discovery v1 with pre/post trajectories, opportunity denominators, uncertainty/minimum-N, subgroup/fairness checks and selection-vs-convergence analysis; implementation is launch-day infrastructure, not waiting years.

**Q49 plan:** `docs/research/outcomes/FRIENDSHIP_REFLECTION_SURVEYS_V1.md`. The surveys capture the friends’ own retrospective explanations and are analyzed alongside, not substituted for, the historical measured snapshot.
### 0039 — Fairness / Privacy / Ethics / Explainability
**Цель:** product-grade governance моделей.

**Реализация:**
- sensitive attribute policy;
- subgroup/fairness checks;
- explanation boundaries;
- consent/data retention;
- delete/export flows;
- anti-discrimination constraints;
- threat model for profile inference.

**Exit gate:** documented and runtime-enforced privacy/fairness controls.

### 0040 — 13-Locale Product QA + Measurement Hardening

**Q49 addition:** pilot Friendship Reflection Survey wording, bilateral comprehension, sampling/non-response diagnostics and locale semantic parity across the canonical 13 locales.
**Цель:** проверить 13-языковый UX и собрать дополнительное evidence для будущего hardening; это не блокирует запуск уже работающей внутренне калиброванной v1.

**Реализация:**
- all 13 locale UI parity;
- translation QA states;
- test instruction equivalence;
- locale-specific rendering;
- optional measurement-invariance evidence plan for future reviewed model versions;
- QA/outcome instrumentation that never auto-mutates v1 scoring.

**Exit gate:** UI/localization QA is reported separately from optional future measurement-hardening evidence; absence of an external cohort does not invalidate the current internal research calibration v1.

### 0041 — Integrated Investor / Release Candidate 1
**Цель:** собрать всё достигнутое в единый демонстрируемый продуктовый кандидат.

**Реализация:**
- full backend/simulator/frontend walkthrough;
- 200+ profiles;
- Tests→Report→People→Compatibility→Chat→Groups→Search Requests→Trust→Hospitality;
- contract/state/history visibility;
- owner HTML acceptance checkpoint;
- Android/APK checkpoint only if HTML accepted.

**Exit gate:** RC-1 с честной матрицей оставшихся gaps.

---

## Фаза IV — Test System v2 hardening / expanded measurement (0042–0053)

> Cycle 0028 уже материализовал семь научно-трассируемых systems v1 и Psychological Report v2. Поэтому 0043–0053 — **не первое появление тестов**, а v2 hardening: расширение/замена stimulus banks, decoupling от removed legacy 100×6, дополнительные instruments, reproducibility/fairness/localization hardening и улучшение model versions без блокировки текущего продукта.

### 0042 — Source Registry v2 + Owner Source-Map Patch Consolidation
**Цель:** превратить полный будущий source patch владельца в новый canonical evidence graph.

**Реализация:**
- ingest нового source-map patch;
- canonical IDs/DOI/URL dedupe;
- supersession links вместо удаления истории;
- rights/evidence/applicability/embedding/use axes;
- source→claim→construct→measurement trace;
- stale Markdown projections генерируются из JSON-SSOT;
- source-count drift становится guard failure.

**Exit gate:** one machine SSOT и автоматически синхронизированные projections.

### 0043 — Test System v2 Architecture hardening
**Цель:** развить уже работающий cycle-0028 scientific questionnaire baseline v1.2: item governance, construct overlap audit, alternative batteries, version migration, randomization and reproducibility without changing historical results задним числом.

**Реализация:**
- `TestSystemRegistry`;
- независимые batteries/modules;
- versioned input/scoring/result contracts;
- minimum/maximum items per system определяется качеством, а не историческим числом;
- старый 100×6 не используется как active/legacy fallback; исторические документы остаются только provenance истории проекта;
- каждая system обязана иметь собственный compatibility interface `0–100%`.

**Exit gate:** новая архитектура допускает параллельные тестовые системы без hidden coupling.

### 0044 — Associative & Implicit v2 hardening / additional instruments
**Цель:** harden the cycle-0029 associative/implicit v1 after it already exists in product.

**Implementation:**
- cue-bank quality/redundancy review;
- semantic-analysis versioning and multilingual adaptation;
- timing/device-quality robustness;
- alternate task blocks and order randomization;
- test-retest and method-agreement analysis where launch data exist;
- optional additional indirect instruments only with explicit source/method provenance;
- no return of the removed 600-image branch as fallback.

**Exit gate:** associative/implicit v2 is reproducible, multilingual-ready and remains independently inspectable from questionnaire psychology.

### 0045 — Psychological System: Trait Dimensions
**Цель:** hardening/расширение уже работающего `traits_core` v1 новым versioned instrument layer.

**Реализация:**
- construct registry;
- validated/reference item/stimulus mapping only where rights allow;
- standalone result/profile/history;
- `PC_TRAITS 0–100%` pair compatibility;
- uncertainty/coverage;
- no clinical labels.

**Exit gate:** complete module from measurement→result→pair score→UI.

### 0046 — Psychological System: Interpersonal / Relationship Style
**Цель:** hardening/расширение уже работающего `interpersonal_style` v1 отдельно от общих traits.

**Реализация:**
- interpersonal orientation;
- reciprocity;
- autonomy/boundaries;
- attachment-related constructs only where source/spec supports them;
- independent result;
- `PC_INTERPERSONAL 0–100%`.

**Exit gate:** module independent, explainable and not merged into Trust.

### 0047 — Psychological System: Communication + Conflict
**Цель:** hardening/расширение уже работающего `communication_conflict` v1.

**Реализация:**
- directness/tact;
- disclosure/responsiveness;
- conflict engagement/avoidance;
- repair/forgiveness;
- result/history;
- `PC_COMMUNICATION 0–100%`;
- CC top-level metric remains separately defined where profile communication preferences are explicit.

**Exit gate:** no double-counting across PC and CC without explicit provenance rule.

### 0048 — Psychological System: Empathy / Trust Tendencies / Boundaries
**Цель:** hardening/расширение уже работающего `trust_support_boundaries` v1; это личностные tendencies, не публичная репутация.

**Реализация:**
- empathy/support;
- trust openness;
- confidentiality;
- vulnerability comfort;
- boundary respect;
- independent result;
- `PC_RELATIONAL_TRUST 0–100%`.

**Exit gate:** psychological trust tendency clearly separated from operational Trust Score.

### 0049 — Psychological System: Decisions / Risk / Planning / Work Style
**Цель:** hardening/расширение уже работающего `decision_work_style` v1.

**Реализация:**
- decisiveness;
- planning;
- cautiousness;
- risk tolerance;
- attention to detail;
- initiative/adaptability;
- `PC_DECISION_WORK 0–100%`.

**Exit gate:** useful for work/project context without claiming occupational diagnosis.

### 0050 — Psychological System: Social Energy / Group Role / Collaboration
**Цель:** hardening/расширение уже работающего `social_group_role` v1.

**Реализация:**
- social energy;
- group orientation;
- leadership orientation;
- cooperation/competition;
- mutual aid;
- `PC_GROUP_ROLE 0–100%`.

**Exit gate:** result connected to group/project context, not to moral ranking.

### 0051 — Psychological System: Stress / Uncertainty / Adaptability
**Цель:** hardening/расширение уже работающего `adaptability_uncertainty` v1 только по поддержанным constructs.

**Реализация:**
- stress tolerance;
- ambiguity tolerance;
- self-control;
- adaptability;
- optimism/coping only where validated;
- `PC_ADAPTABILITY 0–100%`;
- explicit limitations.

**Exit gate:** unsupported constructs не заполняются догадками.

### 0052 — Test Orchestrator / Progress / History / Retake v2
**Цель:** сделать Tests законченной платформой.

**Реализация:**
- Tests Home catalog;
- prerequisites/recommended order;
- progress per system;
- resume;
- retake/version rules;
- result history;
- profile contribution/coverage;
- cross-device persistence;
- no “Профиль обновлён” вместо содержательного result.

**Exit gate:** пользователь понимает что проходит, зачем и что получил.

### 0053 — Psychological Profile / Report v2 + Modular Psychological Compatibility
**Цель:** собрать независимые systems без скрытого смешивания.

**Реализация:**
- current state per psychological system;
- synthesis layer with source provenance;
- strengths/growth/communication/conflict/decisions/group/work/friendship/limitations;
- report history;
- каждая psychological system показывает собственный `0–100%` pair score;
- optional `PC Overall` = явное arithmetic mean только выбранных доступных psychological modules, если этот aggregation включён пользователем;
- Q28 Overall остаётся отдельным arithmetic mean selected top-level metrics.

**Exit gate:** full Tests→Profile→Report→psychological module compatibility path.

---

## Фаза V — Profile / Discovery / Social Graph (0054–0061)

### 0054 — My Profile / Digital Resume v2
**Цель:** сделать профиль центральным representation человека.

**Реализация:** identity, bio, profession, specialization, skills, experience, education, projects, achievements, current activity, interests, groups, travel, goals, what-I-offer, reputation summaries, personality links.

**Exit gate:** own/public representation differs only by edit/privacy/service controls.

### 0055 — Identity / Verification / Privacy Controls
**Цель:** управляемая достоверность и видимость данных.

**Реализация:** provider verification, field-level visibility, audience controls, location granularity, verified badges provenance, blocked/private fields, export/delete settings.

**Exit gate:** privacy is enforced by backend contract, not only hidden in UI.

### 0056 — People Discovery / Ranking v2
**Цель:** полноценный поиск людей.

**Реализация:** search, roles, geo, interests, skills, availability, metric selection, Trust/Rating filters, QF, sort/ranking provenance, no self result, no hidden pair weights.

**Exit gate:** 200-person simulator exercises realistic discovery distributions.

### 0057 — Search Requests Marketplace of Intent
**Цель:** искать не только profiles, но и конкретные намерения.

**Реализация:** friend/business/project/mentor/team/activity/custom requests; requirements; owner visibility; response flow; lifecycle; archive; abuse protection.

**Exit gate:** request→candidate→chat/project path complete.

### 0058 — Candidate Deep Profile v2
**Цель:** сначала понять человека, затем метрики.

**Реализация:** person summary, bio, professional, interests, projects, mutual context, compact compatibility, trust/rating, actions, detail links, hospitality availability.

**Exit gate:** no laboratory-like first screen; details progressive.

### 0059 — Groups / Communities v2
**Цель:** социальные структуры вокруг интересов и деятельности.

**Реализация:** interest/local/business/project/mutual-aid groups; roles; join/invite; moderation; events/posts if supported; group search and profile links.

**Exit gate:** full group lifecycle in simulator/backend/HTML.

### 0060 — Projects / Skills / Team Formation
**Цель:** расширить Brotherhood из знакомства в совместную деятельность.

**Реализация:** project cards, roles needed, skills, invitations, team candidates, QF/compatibility context, project chat/group binding, status/history.

**Exit gate:** project partner/team member user journey complete.

### 0061 — Notifications / Activity / Relationship History
**Цель:** связать asynchronous product flows.

**Реализация:** message/group/request/project/hospitality/trust notifications; deep links; read state; activity history; privacy-safe summaries; simulator event bus parity.

**Exit gate:** user does not need manually poll sections.

---

## Фаза VI — Communication / Trust / Hospitality / Services (0062–0067)

### 0062 — Direct Chat v2
**Цель:** Telegram-class direct communication production flow.

**Реализация:** E2EE boundary, reply/edit/delete/reactions, attachments, typing, delivery/read, retry/offline queue, profile header, block/report.

**Exit gate:** backend/device/simulator state machines agree.

### 0063 — Group Chat / Media / Moderation
**Цель:** полноценное group communication.

**Реализация:** membership/roles, group timeline, media/files, mentions/replies, moderation actions, join/leave events, retention and privacy controls.

**Exit gate:** groups are communication products, not static directories.

### 0064 — Verified Interactions / Trust / Appeals Runtime v3

**Q49 integration:** verified real-interaction and mutual-friendship events become eligible triggers for research survey invitations; survey answers remain outside Trust/Rating scoring.
**Цель:** связать real interaction evidence с репутацией.

**Реализация:** verified interactions, evidence events, moderation, restrictions, appeals, recency, audit history, safe public summary.

**Exit gate:** every Trust change has provenance.

### 0065 — Hospitality Host/Guest Experience v2
**Цель:** trusted offline interaction, не hotel marketplace.

**Реализация:** host profile, availability, requirements, guest request, eligibility, acceptance, private arrival data, direct-chat reuse, lifecycle and cancellation.

**Exit gate:** no payments/escrow/booking marketplace drift.

### 0066 — Hospitality Verification / Reviews / Reputation / Safety
**Цель:** закрыть stay outcome and reputation loop.

**Реализация:** bilateral confirmation, no-show/dispute, blind reviews, review deadlines, separate Hospitality Reputation, safety/reporting/appeal flows, verified stay ≠ friendship.

**Exit gate:** physical interaction evidence is precise and abuse-resistant.

### 0067 — Services / Mutual Aid / Offline Handoff
**Цель:** собрать практические возможности Brotherhood в простую service architecture.

**Реализация:** service catalog, mutual aid, activity coordination, meeting handoff, location/privacy boundaries, feature-specific flows using Diia principles.

**Exit gate:** Services remains simple despite backend complexity.

---

## Фаза VII — Localization / Reliability / Security / Final Release (0068–0073)

### 0068 — 13-Locale Product & Measurement QA
**Цель:** полная multilingual product parity.

**Реализация:** native-language QA states, fallback rules, key completeness, locale-sensitive layouts, test instruction review, report language versioning, translation provenance.

**Exit gate:** UI completeness and psychometric equivalence reported separately.

### 0069 — Accessibility / Performance / Responsive Quality
**Цель:** production UX across real devices.

**Реализация:** screen-reader semantics, contrast, text scaling, keyboard/focus where applicable, low-end Android performance, list virtualization, image/media budgets, responsive layouts.

**Exit gate:** measurable performance/accessibility budgets.

### 0070 — Offline / Sync / Conflict / Recovery
**Цель:** устойчивость реального приложения.

**Реализация:** offline queues, optimistic updates, conflict resolution, idempotency, retry, local state recovery, server reconciliation, report/test/chat/hospitality recovery scenarios.

**Exit gate:** forced reconnect/resume scenarios have deterministic outcomes.

### 0071 — Security / Privacy / Abuse / Moderation Release Audit
**Цель:** release-grade protection.

**Реализация:** auth/session boundaries, E2EE key lifecycle, access control, exact-location protection, rate limits, abuse/report/moderation flows, secrets audit, data retention, export/delete, dependency/security review.

**Exit gate:** unresolved critical finding blocks release qualification.

### 0072 — Full Release-Parity Simulation + Live E2E Rehearsal
**Цель:** доказать полный путь до production qualification.

**Реализация:** generated contract parity for every table/route; 200+ deterministic people; full lifecycle scenarios; PostgreSQL migration rehearsal; backup/restore; rollback; observability; synthetic failure injection; end-to-end scripts for every critical user journey.

**Exit gate:** simulator/source parity PASS plus live-environment E2E evidence where available.

### 0073 — Release Candidate 2 / Production Qualification
**Цель:** релизный Brotherhood.

**Обязательный пользовательский путь:**
`auth/profile → tests → per-test results → psychological profile → psychological report/history → people/search requests → candidate → independent compatibility metrics/modules → chat/group → Trust → Hospitality → verified interaction/review`.

**Реализация и gates:**
- final HTML owner acceptance;
- accepted HTML hash becomes visual authority;
- exact Compose mirror;
- functional composition diff before/after = no unintended removals;
- GitHub CI/APK/AAB;
- migrations and runtime checks;
- live E2E;
- final R/S/B/SIM/H/VA/A/CI/E2E/PQ matrix.

**Exit gate:** `PRODUCTION_QUALIFIED` только для реально доказанных слоёв; оставшиеся внешние gates перечисляются явно.

---

# 6. Cross-cycle обязательные правила

Для **каждого** цикла 0024–0073:

1. Operator Kernel → HEAD → active SSOT/CANON → code reality.
2. Новый `reports_NNNNN`.
3. Обновление canonical cycle ledger и stage matrix.
4. Нельзя писать `IMPLEMENTED`, если сделан только research/spec/schema/route/simulator shell.
5. Backend/source contract генерируется из фактического source.
6. Simulation Engine обновляется при изменении маршрутов/таблиц/models.
7. User-facing feature получает HTML implementation.
8. Compose меняется только после соответствующего HTML visual acceptance, если речь о redesign/new surface.
9. Existing functionality нельзя удалять без прямой задачи; progressive disclosure используется вместо удаления.
10. Test/model versioning обязателен: old results должны сохранять интерпретируемость.
11. Compatibility metrics не получают скрытых cross-metric weights.
12. Trust, Account Rating, Hospitality Reputation, Quality Fit, Psychology и Compatibility не смешиваются семантически.
13. `INSUFFICIENT_DATA` лучше, чем выдуманный `0%`.
14. Scientific claim не становится production coefficient автоматически.
15. Full local test suite/GitHub CI не используется без отдельной причины/gate; целевые проверки фиксируются отдельно.
16. Архивный historical документ не переписывается задним числом: новый canon supersedes его явной ссылкой.

---

# 7. Контрольные продуктовые checkpoints

- **0024:** Runtime Recovery checkpoint — report history + server Q28 + 200-person simulation foundation.
- **0028:** Recovery Visual/Android/APK checkpoint.
- **0037:** Full Simulation v2 checkpoint.
- **0041:** Integrated RC-1 checkpoint.
- **0053:** Psychological/Test Platform v2 checkpoint.
- **0061:** Social/Discovery platform checkpoint.
- **0067:** Communication/Trust/Hospitality checkpoint.
- **0073:** Final RC-2 / Production Qualification checkpoint.

APK не требуется после каждого цикла.

---

# 8. Главный критерий успеха дорожной карты

Прогресс считается не по числу sources/cycles/classes/routes, а по тому, существует ли полный реальный путь пользователя:

`кто я → что показываю другим → какие тесты я прошёл → что они означают → каков мой психологический профиль → какой у меня отчёт и история → кого я ищу → кто передо мной → насколько мы совместимы по каждой отдельной системе → почему → можем ли мы общаться → можем ли работать/дружить/объединиться в группу → насколько подтверждено доверие → можем ли встретиться/принять друг друга в гостях → как результат реального взаимодействия возвращается в подтверждённую репутацию и исследовательскую систему`.

Пока этот путь не доказан на соответствующих слоях, Brotherhood не называется функционально завершённым.


### Q44 assessment replacement
Former 100×6/600-task generated visual bank is removed. Active test work proceeds only on the seven scientific questionnaire systems and their source/claim-traced item banks.
