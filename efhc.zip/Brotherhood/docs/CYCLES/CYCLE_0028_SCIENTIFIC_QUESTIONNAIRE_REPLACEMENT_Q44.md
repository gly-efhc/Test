# Cycle 0028 — Scientific Questionnaire Replacement Q44

Date: 2026-08-11  
Input HEAD: `Brotherhood_v0_5_64.zip`  
Target DEVELOPMENT: `Brotherhood_v0_5_65.zip`  
HTML candidate: `BROTHERHOOD_UI_SIMULATOR_v0_5_41.html`  
Status: **SCIENTIFIC_QUESTIONNAIRE_V1_2_SOURCE_HTML_IMPLEMENTED / VA_PENDING**

## Owner directive
Remove the former 600 generated visual tasks and all governance locks that protected that unfinished branch. Continue by converting the already authorized scientific corpus into useful tests, metrics, reports and compatibility-ready data.

## What replaced the old branch
Active bank: `scientific-questionnaire-bank-v1.2`.

- 7 independent psychological systems;
- 197 active questionnaire items;
- 64 construct-system pairs;
- minimum 3 independent item signals per construct-system pair;
- 17 direct public-domain Mini-IPIP anchors;
- 70 primary construct-relevant situational continua;
- 45 redundancy signals;
- 65 triangulation signals;
- backend/server-authoritative deterministic scoring;
- independent per-system pair compatibility `0–100%`;
- substantive per-test result + Psychological Profile + versioned Psychological Report.

## Scientific corrections in this continuation
1. Removed visual forced-choice source IDs from active text-questionnaire evidence.
2. Corrected broad Mini-IPIP semantics: broad factors are not silently relabeled as narrow facets.
3. Increased measurement depth from two to at least three signals per construct-system pair.
4. Replaced recycled generic primary situations with construct-relevant neutral contexts.
5. Added explicit evidence semantics: Brotherhood-original wording is an adaptation; source/claim trace supports construct/method synthesis and does not claim literal published wording.
6. Rebuilt the active scientific synthesis around the questionnaire bank rather than legacy `f001…f100`/Canvas measurements.

## Runtime contract
`backend/domain + DB → routes → BackendSimulator → SimulationEngine → route responses → frontend`.

Current generated source contract:
- 97 OpenAPI paths;
- 115 HTTP operations;
- 50 DB tables;
- 21 Android AppRoutes;
- 200 deterministic synthetic candidates.

## Removed control layer
Owner-lock/protected-hash/product-veto guards for the old visual bank were removed. Functional API/domain/regression tests remain because they test current behavior instead of prohibiting development.

## Stage status
- R = PASS — canonical scientific corpus is active development input;
- S = PASS — seven-system questionnaire/scoring/report/compatibility contract;
- B = SOURCE_IMPLEMENTED;
- SIM = LOCAL_PASS — 115/115 route operations, 0 failures, 50 tables, 200 candidates, 7 systems / 197 items;
- H = IMPLEMENTED_CANDIDATE;
- VA = PENDING owner review;
- A = SOURCE_UPDATED_NOT_VISUALLY_ACCEPTED;
- CI = NOT_RUN;
- E2E = NOT_RUN.

## Verification
- backend: 81/81 PASS;
- architecture: 259/259 PASS;
- combined local regression: 340/340 PASS;
- HTML parser: PASS;
- inline JavaScript syntax: 2/2 PASS;
- external runtime assets: 0;
- Simulation Engine runtime probe: 115/115 operations PASS, 0 failures; catalog 7 systems / 197 items; `traits_core` 50-item score route saved; Psychological Report exposes 7 system sections; persistence schema 12;
- Operator Kernel config: PASS 16 routes / 8 hooks / 6 agents / 6 skills; local product-edit enforcement is advisory/non-blocking.

## Scientific continuation rule
The v1.2 bank is sufficient to continue release/product work. Further scientific work should continue as non-blocking quality improvement: multilingual semantic adaptation, construct-overlap audit, item wording/bias review, alternative batteries and post-release version comparison. No multi-year outcome cohort is required before launch.


## Psychological methodology expansion — 2026-08-13
Cycle 0028 additionally registers independent methodology families for Freud/free association, Jung/word association, Greenwald-McGhee-Schwartz/IAT, Bessel van der Kolk/trauma-self-regulation, Gabor Maté/trauma-context + Compassionate Inquiry, and Baer-Wolf-Risley/observed behavior. This does not modify the current 7-system questionnaire score. It establishes the next productization lane for associative and implicit instruments and trauma-informed report context. See `PSYCHOLOGICAL_METHODOLOGY_CATALOG_V1`.
