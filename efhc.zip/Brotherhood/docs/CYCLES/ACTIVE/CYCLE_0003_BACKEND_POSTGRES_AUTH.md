# Cycle 0003 — REAL BACKEND / DATABASE / AUTH

Status: ACTIVE — current source HEAD v0.5.31 / LIVE_E2E PENDING
Activated by explicit user instruction: 2026-08-08.

## Source milestone
- FastAPI public auth endpoints for provider exchange, refresh, session, logout, email OTP, passkey and Telegram OIDC.
- PostgreSQL migration 0008 for refresh sessions, email/OIDC challenges, passkeys, device-bound login tickets and user settings.
- Provider identity remains access identity; `global_id` remains sole owner. Verified-email linking is serialized and conflicts require explicit recovery.
- Android stores session encrypted with Android Keystore, restores `global_id`, rotates refresh, synchronizes settings and never receives DB/provider secrets.
- Google Client ID is fetched as public runtime config from Brotherhood backend, so frozen GitHub workflow needs no change.
- Telegram uses registered HTTPS backend callback + PKCE; the app receives only a short-lived one-time ticket bound to the initiating device.
- Passkey server requires discoverable credential + user verification. Production Android passkey requires real RP domain + Digital Asset Links.

## Local evidence
- backend + architecture: 139 PASS.
- Python compileall: PASS.
- JSON/XML parse: PASS.
- Workflow hash: unchanged.

## Exit gates still external
- real PostgreSQL/Neon database + migration application;
- deployed HTTPS FastAPI endpoint + real `BROTHERHOOD_API_BASE_URL`;
- Google/Telegram/email/passkey production credentials/config;
- real Android ↔ backend ↔ PostgreSQL/provider path;
- passkey RP origin + Digital Asset Links.

Until these gates pass, status must not be promoted to `LIVE_E2E`.

## CI correction — run 84786542178
- First real failed step: Gradle Kotlin DSL script compilation, before Android test/compile/assemble tasks.
- Root cause: `java.net.URI(...)` in `android/app/build.gradle.kts` resolved against the Gradle DSL namespace and failed on `net`; the `it` failure in the path expression was cascading.
- Fix: `uri(telegramAppCallbackUri.get())` using the Gradle script API.
- Workflow: unchanged. Version: unchanged (`0.5.23 / 28`).
- Local targeted regression: 14/14 PASS. GitHub rerun required for build evidence.

## Owner-directed brand update — v0.5.25

During the active cycle the project owner explicitly replaced the Brotherhood logo with the supplied PNG master. This is not a new product cycle and does not alter cycle 0003 auth/database semantics. Active brand SSOT is now `docs/CANON/BROTHERHOOD_BRAND_CANON.md` / `brand/logo_brotherhood.png`. Runtime visual change justified `versionName 0.5.25 / versionCode 30`. Cycle 0003 remains ACTIVE / LIVE_E2E PENDING.

## CI correction — runs 84790063345 / 84792124384
- First real failed step in both runs: `:app:compileDebugKotlin`.
- Confirmed error: unresolved `ApiConfig` references in `BrotherhoodApp.kt`; the object already existed under the `network` package but its import was missing.
- Minimal fix: import `org.federationofavatars.brotherhood.network.ApiConfig`.
- Android source change: YES. Workflow change: NO. Archive change: YES. Version change: NO.
- Run 84792124384 also emitted a non-fatal `libandroidx.graphics.path.so` strip warning; it is not the build failure.
- Exact GitHub rerun remains required before Kotlin/build status is promoted.

## Maintained visual-check tool correction
`tools/visual_checks/logo_brotherhood_preview.html` is now a genuinely standalone file. The previous relative source-tree image path was invalid when the HTML was downloaded separately. A scaled 512×512 PNG derivative of the unchanged canonical logo is embedded once as a CSS data URI; no JavaScript or external file path is required.


### Maintenance correction absorbed into cycle 0003 — v0.5.25
Owner screenshot triggered a bounded brand-layout correction and an Android installation diagnostic. This does not create a new product cycle and does not alter cycle-0003 auth semantics. Device install failure remains NOT CONFIRMED until exact Package Installer/adb evidence is available; missing permanent Development signing remains the strongest confirmed update-risk from supplied CI.

### Maintenance correction absorbed into cycle 0003 — v0.5.27 installation regression isolation
Known-good v0.5.19 was compared against v0.5.21/v0.5.22/v0.5.23/v0.5.24 and current source. The first major binary/package delta is v0.5.23 auth integration. v0.5.27 retains auth functionality but stabilizes Credential Manager at 1.6.0 and removes `autoVerify` from the custom Telegram scheme. PNG layout is corrected independently to 96dp Auth / 38dp TopAppBar total slots. Owner then required strict square-only logo presentation: `roundIcon`, round launcher resources, adaptive-icon XML and themed monochrome logo resources are removed; Android 12+ system splash is logo-free to avoid its circular system mask. No workflow change. APK/device appearance remains an evidence gate.

### Maintenance correction absorbed into cycle 0003 — v0.5.28 UX recovery
Owner installed v0.5.27 through SAI and reported device-visible UX defects: overloaded Home, unclear hierarchy, no obvious completed-test-results destination, and Android system Back not returning to the previous Brotherhood screen. v0.5.28 keeps all existing capabilities but simplifies Home, adds a dedicated results route, and adds route/tab history with Compose BackHandler. Diia Android was consulted only for navigation/screen-structure reference. New APK/device verification is required; current evidence is SOURCE_ONLY/LOCAL_PASS until GitHub/device test.


### Maintenance correction absorbed into cycle 0003 — v0.5.28 full offline UX workbench correction
Owner rejected the reduced HTML preview and required a full standalone copy of the current user-facing Brotherhood application for rapid UX review. The v0.5.28 demo maintenance adds a stateful offline workbench modeled on the supplied FRONTEND_v066 pattern, with live phone preview, route/state controls, all current user-facing route families and synthetic demo identities. `Глава Федерации` is removed from active Brotherhood demo UI; Synthetic demo identity data is now also used by the explicit Android DEBUG simulation boundary; production account identity semantics are unchanged. No product capability was removed and the frozen GitHub workflow was not changed. APK/device UX evidence remains separate.

### Maintenance correction absorbed into cycle 0003 — v0.5.30 persistent shell + simulation boundary

Owner rejected the v0.5.28 demo architecture as too weak and reported bottom-navigation disappearance and poor light mode. Source audit confirmed the defects and confirmed that Android had backend repositories + DemoRepository/ViewModel fallback rather than a clean separate simulation engine. v0.5.30 adds a root persistent navigation shell, explicit DEBUG `DemoBackendSimulator → DemoSimulationEngine`, and coherent light palette. Production backend/auth routes are preserved. Standalone HTML now mirrors a stateful BackendSimulator → SimulationEngine → frontend architecture. GitHub Android compile/APK and installed-device UX evidence remain pending.

### Maintenance correction absorbed into cycle 0003 — v0.5.30 product/Kernel integration

Owner product clarification and the supplied Kernel v002 specification are absorbed into the active source milestone without activating cycle 0004. Home is now the four-action business-club entry surface; Kernel governance/release packaging are upgraded. Backend/provider LIVE_E2E remains pending and Android v0.5.30 APK qualification remains GitHub/device pending.


### Critical recovery absorbed into cycle 0003 — v0.5.31 protected mechanics + full investor simulation

Owner identified a critical semantic regression: the standalone investor demo had substituted the protected indirect visual assessment mechanics with primitive direct text questions and an independent fake score. Forensic SHA-256 comparison against the pre-UX/demo v0.5.27 baseline proved the Android/release psychometric core and source maps themselves were not changed. The regression was confined to the HTML simulation path. v0.5.31 restores the release 100×6 visual-latent mechanics in the investor demo and adds a 17-file protected-mechanics manifest enforced by both packagers and architecture tests.

The standalone investor simulation is now mechanically tied to the current source contracts: 60 OpenAPI paths / 70 operations, 39 database tables and all 14 Android AppRoutes are represented; browser contract probe observed 70/70 handled with zero failures. This is local source-contract simulation evidence, not proof of real PostgreSQL/provider/E2EE transport/deployment. Exact Android compile/APK/device remains frozen-GitHub/device pending.
