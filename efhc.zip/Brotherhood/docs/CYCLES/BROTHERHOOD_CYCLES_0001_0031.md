# Brotherhood — canonical major cycles 0001–0031


Status: **SUPERSEDED BY HOSPITALITY ROADMAP INSERTION — current: `docs/CYCLES/BROTHERHOOD_CYCLES_0001_0035.md`**
Historical numbering is retained below for provenance; do not use its `NEXT_PLANNED` markers as current state.
Status: **ACTIVE ROADMAP AFTER CYCLE 0011**

## Historical/runtime gates
- `0001` remains completed historical foundation.
- `0002` remains `CHECKPOINT_PENDING` until exact GitHub APK/device evidence.
- `0003` remains `LIVE_E2E_PENDING / EXTERNAL_GATE`; cycle 0004 does not claim its live acceptance.
- Owner directive continues documentation/research cycles while 0003 external live gate remains open; cycles 0004–0008 continue under the owner-authorized research/product roadmap while external cycle-0003 live evidence remains pending.

## Major roadmap
| Cycle | Status | Major result | Scope | Exit gate |
|---|---|---|---|---|
| 0004 | COMPLETED | Compatibility Research Foundation | Большая research/product documentation base, modular canon, source registry, cause map, source→claim matrix, visual test program, roadmap. Runtime unchanged. | All required canon/methodology docs exist; Q28 reflected; protected guard PASS. |
| 0005 | COMPLETED | Scientific Source Registry & Evidence Taxonomy | Deeper web/full-text source review, licensing/use constraints, effect-level claim extraction, bibliography and open questions. | Claim ledger has population/method/effect/limits for priority claims; licenses resolved where needed. |
| 0006 | COMPLETED | Psychological Construct Architecture | Big Five/IPIP, HEXACO coordinate family, IPC, attachment/conflict/responsiveness/trust/risk and Brotherhood latent hypotheses; 23-record construct registry; overlap/ontology/relation taxonomy; reference-battery architecture. Runtime unchanged. | Construct map + reference battery + anti-double-counting map + source/role relation matrices complete; all Brotherhood-specific additions remain HYPOTHESIS/REQUIRES_VALIDATION. |
| 0007 | COMPLETED | Visual Stimulus Scientific Program | Stimulus taxonomy, forced-choice design, balance/social desirability, item bank metadata, hypothesis registry, asset requirements. | Protected 600-item bank fully mapped for research metadata without unauthorized mechanics edits. |
| 0008 | COMPLETED | Calibration & Psychometric Validation Protocol | Cohorts, reference battery, reliability/test-retest, convergent/discriminant validity, cross-validation, bias, locale equivalence, holdout. | Independent protocol review; analysis plan frozen before calibration claims. |
| 0009 | COMPLETED | Psychological Compatibility Engine v1 Research Spec | Role-context dyadic models; similarity/complementarity/asymmetry; pair-feature registry; score semantics 0..100; dyadic method/privacy/13-locale gates; no production activation. | Versioned research spec + pair features + role contracts + baselines/challengers + validation/model-manifest gates complete; runtime scoring unchanged. |
| 0010 | COMPLETED | Friendship Compatibility Science | Friendship quality, reciprocity, responsiveness, disclosure, maintenance, conflict/repair, shared activities, longitudinal outcomes. | Friend role construct/outcome model + confound plan. |
| 0011 | COMPLETED | Business Partner Compatibility Science | Decision/risk style, responsibility, execution, leadership/complementarity, value conflict, trust boundary. | Business role model + outcome/baseline plan. |
| 0012 | COMPLETED | Worker / Team Fit Science | Person-job/group/supervisor fit, vocational interests, work style, competence boundary. | Worker/team research model separates PC/QF/Trust. |
| 0013 | COMPLETED | Mentor / Project Partner Compatibility | Mentoring expectations, communication, reciprocity, experience/needs fit, project execution/complementarity. | Directional mentor + project-partner role science, outcomes/confounds, 13-locale plan and Q34 exact-score semantics complete; runtime/protected mechanics unchanged. |
| 0014 | COMPLETED | Interests Compatibility Engine | Hobby/social/activity/professional interests; transparent IC-R0; RIASEC-like vocational reference; research exposure/feedback/status/outcome architecture. | Independent IC spec + transparent baseline + Q35 research-platform contracts complete; runtime/DB unchanged. |
| 0015 | COMPLETED | Values Compatibility Engine | Schwartz refined values, instrument-aware centered priorities, similarity/conflict, nonlinear/directional challengers, longitudinal outcome validation. | Independent VC-R0.1 benchmark + challenger/locale/research-platform contracts; production inactive. |
| 0016 | COMPLETED | Communication Compatibility Engine | Disclosure, responsiveness, directness, cadence, autonomy, feedback, conflict/repair. | Independent CC candidate method + dyadic validation plan. |
| 0017 | COMPLETED | Lifestyle Compatibility Engine | Geography, schedule, habits, activities, meetings/online style, constraints/preferences. | Independent interpretable LC model + sensitive-data policy. |
| 0018 | COMPLETED | Brotherhood Personality-Type Engine | Soft probabilistic typology over continuous dimensions; private latent profile boundary. | PT candidate model/versioning; no hard binary public labels. |
| 0019 | NEXT_PLANNED | Enneagram Engine | Exact typological method, evidence status, independent score, limitations/versioning. | EN independent engine spec stays typological/experimental. |
| 0020 | PLANNED | Numerology Engine | Choose/fix exact tradition, formula/provenance, independent 0..100, honest evidence class. | NU method fully reproducible and separately labeled. |
| 0021 | PLANNED | Astrology / Zodiac Engine | Zodiac and optional future natal/synastry layers, provenance/evidence boundary, independent score. | AS method version and privacy/input requirements fixed. |
| 0022 | PLANNED | Quality Fit / SearchIntent v2 | Directional desired-person vector by role, requirements/qualities, hidden-profile mapping and safe explanation. | QF remains asymmetric/separate and passes privacy/baseline review. |
| 0023 | PLANNED | Trust v2 | Identity/reliability/moderation/interaction evidence, fairness/privacy/appeals, no Compatibility fusion. | Trust model and due-process policy versioned. |
| 0024 | PLANNED | Unified Compatibility Service & Checkbox Aggregation | Metric registry/preferences/version history; independent scores; simple selected-score arithmetic mean only. | No hidden inter-metric weights; missing-data behavior and version history tested. |
| 0025 | PLANNED | Compatibility Page + Metric Detail IA | Diia-like service page, role selector, checkboxes, metric detail, QF/Trust separation, resume + direct message path. | UX contract approved; no latent disclosure; responsive/accessibility checks. |
| 0026 | PLANNED | Backend / PostgreSQL Compatibility Architecture | Tables/API/contracts/model manifests/results/preferences/validation runs/outcomes; migration only under explicit code authorization. | Architecture/migration review complete before implementation. |
| 0027 | PLANNED | Release-Parity Simulation Engine v2 | Mirror full backend tables/routes/state/lifecycle/metrics/QF/Trust in investor HTML without simplification. | Simulation contract parity + persistence/error/offline scenarios verified. |
| 0028 | PLANNED | Longitudinal Outcome Research Layer | Consent-based 30/90/180 outcomes, project/friend success labels, research warehouse, no auto-learning. | Temporal leakage, consent, provenance and retention guards pass. |
| 0029 | PLANNED | Fairness, Privacy, Ethics, Explainability | Bias/proxy leakage, consent, delete/export, research opt-in, explanation policy. | Formal privacy/fairness release gates and rollback paths exist. |
| 0030 | PLANNED | Multilingual Controlled Pilot | 13-locale calibration waves (`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`), locale equivalence, position/latency/retest, manual review. | Versioned candidate model reaches declared evidence status or remains hypothesis. |
| 0031 | PLANNED | Integrated Investor / Release Candidate | Full backend + APK/frontend + release-parity HTML + evidence-qualified engines + security/reliability/investor docs + rollout gates. | No false PASS: CI/device/live/production gates independently evidenced. |

## Numbering rule
Cycles are major outcomes, not individual files/tests/errors/packages. Small fixes are absorbed into the active major cycle.

## Supersession
Earlier 0004–0010 descriptions in `BROTHERHOOD_CYCLES_0001_0100.md` and `BROTHERHOOD_ROADMAP_0004_0030.md` are retained as historical predecessor planning. Where they conflict with this 0004–0031 owner roadmap, this document controls.

### Cycle 0007 completion evidence — v0.5.36-docs-cycle0007
Cycle 0007 completed the Visual Stimulus Scientific Program as research/documentation work only. It added read-only runtime scientific metadata for the protected 100×6 bank, visual primitive/composition registries, hypothesis schema, option/social-desirability balance, response-quality/latency, holdout/cross-validation, multilingual/fairness and visual source→claim controls. No Android/backend/database/UI/scoring/protected-test mechanics were modified. Q30 records commercial-release permission for all 60 active-registry sources. Next cycle: 0008.


### Cycle 0008 completion evidence — v0.5.37-cycle0008
Cycle 0008 completed the Calibration & Psychometric Validation Protocol and made the canonical locale architecture 13-language from the start: `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`. It adds intended-use validity, calibration design, reliability/test-retest, construct validity/MTMM, measurement invariance, DIF/item bias, sample-size/power/precision, holdout/external replication and model-promotion gates. Shared/Android locale registries and backend calibration defaults are structurally 13-locale; test content, hidden/latent mechanics and production scoring remain protected. Runtime advances to `v0.5.32 / versionCode 37` solely because user-visible localization runtime changed. Translation/native QA and psychometric equivalence are tracked per locale and are not falsely claimed complete. Next cycle: 0009.

### Cycle 0009 completion evidence — v0.5.38-cycle0009
Cycle 0009 first closes actionable documentation/research tails from 0005–0008, then freezes the Psychological Compatibility Engine v1 **research** interface. PC is a role-specific dyadic engine that yields an exact versioned `0..100%` Compatibility result; that percentage is not automatically an event-success probability unless separately probability-calibrated. The cycle adds 9 post-Q30 citation/research sources (registry 73→82), 7 evidence claims (29→36), dyadic non-independence/shared-method controls, pair-feature registry, role/direction contracts, normalization semantics, baseline/challenger ladder, 13-locale validation inheritance, privacy/explanation policy and model-manifest schema. Original 60-source commercial-release authorization remains a separate snapshot; protected 100×6/scoring/runtime are unchanged. Next cycle: 0010.

### Cycle 0010 completion evidence — v0.5.39-cycle0010
Cycle 0010 completes Friendship Compatibility Science as research/documentation work. It expands the scientific registry 82→93 and claim ledger 36→45; defines friend formation/maintenance/repair/dissolution stages, outcome hierarchy, male-only population boundary, causal/confound plan, privacy-safe longitudinal contract and exact 13-locale adaptation. Friendship Science is an outcome/role-validation program, not a tenth Compatibility metric. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0011.

### Cycle 0011 completion evidence — v0.5.40-cycle0011
Cycle 0011 completes Business Partner Compatibility Science as research/documentation work. Scientific registry expands 93→108 and claim ledger 45→58; a business-partner construct/process boundary, role-governance model, conflict/repair model, outcome hierarchy, causal/confound plan, baseline/validation plan, longitudinal data contract and exact 13-locale plan are established. Team/venture evidence cannot silently become pair coefficients. PC/QF/Trust/VC/CC/IC/LC remain separate. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0012.

### Cycle 0012 completion evidence — v0.5.41-cycle0012
Cycle 0012 completes Worker / Team Fit Science as research/documentation work. Scientific registry expands 108→120 and claim ledger 58→70; PJ/PG/PS fit, vocational interests, competence/QF boundaries, teamwork processes, team cognition, psychological safety, team efficacy, level-of-analysis and exact 13-locale validation are separated. Q33 introduced internal research humility/model plasticity; **Q34 in cycle 0013 later clarified the controlling product semantics**: Brotherhood shows the exact `0..100%` output of the active approved algorithm/version for the declared inputs, and a later approved model may recalculate a different exact value. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0013.


### Cycle 0013 completion evidence — v0.5.42-cycle0013
Cycle 0013 completes Mentor / Project Partner Compatibility as research/documentation work. Scientific registry expands 120→132 and claim ledger 70→81. Mentor is explicitly directional; project partner is peer/mutual by default with ordered role mode only when roles are explicit. PC/QF/Trust/CC/VC/IC/LC boundaries, mentor expectations/functions/reciprocity, project coordination/expertise/interdependence, causal/outcome plans and exact 13-locale validation are documented. Q34 supersedes the over-broad product reading of Q33: scientific models remain versioned/improvable, while the product exposes the exact `0..100%` result of the active algorithm version/input snapshot. No Android/backend/database/protected 100×6/scoring change was made. Next cycle: 0014.

### Cycle 0014 completion note
Interests Compatibility now has a versioned research specification and transparent IC-R0 benchmark. Q35 adds a product/research architecture for storing pre-exposure score/model snapshots, recommendation exposure, explicit feedback, side-specific relationship statuses and longitudinal outcomes. These data can support future model research only through reviewed/versioned validation; no backend/DB telemetry implementation or production auto-learning was authorized in cycle 0014.


### Cycle 0015 completion note
Values Compatibility has the refined 19-value taxonomy and frozen historical `VC-R0`. The v0.5.45 hardening makes instrument/scoring-adapter/centering/normalization provenance explicit, adds current transparent `VC-R0.1`, `VC-R1-CIRCLE`, `VC-R2-RSA`, `VC-R3-ROLE-DYADIC`, coverage/freshness guards, exact 13-locale comparability states and deeper Q35 exposure→outcome validation. Scientific registry expands `141→162`; claim ledger `92→111`; the original owner-authorized source snapshot remains exactly 60. No Android/backend/database/protected 100×6/production scoring change is authorized by cycle 0015. Next cycle: `0016 — Communication Compatibility Engine`.


### Cycle 0016 completion note
Communication Compatibility now has an independent research-only v1 architecture with pre-exposure input/construct/pair-feature registries, transparent `CC-R0`, role/directional/nonlinear challengers, explicit missingness/coverage, 13-locale validation and exposure-time longitudinal outcome provenance. Post-contact actual reply latency, reciprocity, conflict and repair remain process/outcome evidence and cannot leak backward into historical CC predictors. Scientific registry `162->172`; claim ledger `111->123`; original owner-authorized source snapshot remains exactly 60. Android/backend/database/protected 100x6 and production scoring remain unchanged. Next: `0017 — Lifestyle Compatibility Engine`.

### Cycle 0018 completion
Brotherhood Personality-Type Compatibility now uses a continuous-first research architecture over the existing five Brotherhood-32 axes, a soft 32-prototype interpretation distribution and transparent `PTC-R0`; hard type remains an interpretation layer. The existing runtime threshold classifier and legacy compatibility formula remain untouched and are not promoted as research-validated coefficients. New profile/dyadic evidence is synthesized through Q36; source registry `179->189`, claim ledger `137->151`; exact 13 locales and Q35 exposure-time provenance are defined. Next: `0019 — Enneagram Engine`.
