# Cycle 0026 — UI Recovery B: Chat → Groups → Search Requests

Date: 2026-08-11  
Status: `SOURCE_HTML_IMPLEMENTED / ROUTE_BACKED_SIMULATION / VISUAL_ACCEPTANCE_PENDING`

## Purpose
Close the next user-facing recovery vertical without using Compose/APK as a design surface:

`Candidate → Direct Chat → Group Chat / Communities → Search Requests → People`

Cycle 0026 preserves existing Chat/domain behavior and adds only confirmed missing contracts required by the product flow.

## Fact audit before implementation

### Existing in HEAD
Backend already contained:
- direct conversations and group conversations;
- direct E2EE contract and group server-encryption contract;
- conversation membership;
- message list/send;
- reply linkage;
- media attachments;
- edit/delete;
- reactions;
- typing;
- read receipts;
- block/report;
- push-token registration.

### Confirmed gaps
1. Search Requests existed only as HTML/discovery controls and were not a first-class persistent backend entity.
2. Communities had storage membership data but no explicit user join/leave API contract.
3. HTML Chat/Groups/Search Requests did not expose the full current backend feature set.
4. HTML social surfaces still contained fixture/state bypasses instead of obtaining product data through SimulationEngine routes.

## Source implementation

### Search Requests
Added:
- model `SearchRequestCreate` / `SearchRequestUpdate` / `SearchRequestRecord`;
- status `active / paused / archived`;
- DB migration `database/migrations/0012_search_requests.sql`;
- canonical schema parity in `backend/schema.sql`;
- memory + PostgreSQL repository implementations;
- API:
  - `POST /v1/search-requests`;
  - `GET /v1/search-requests`;
  - `GET /v1/search-requests/{request_id}`;
  - `PUT /v1/search-requests/{request_id}`;
  - `DELETE /v1/search-requests/{request_id}` — archive semantics.

Search Request stores explicit owner intent and filters. It does not create hidden Compatibility weights.

### Community membership
Added:
- `GET /v1/communities/{community_id}/membership`;
- `PUT /v1/communities/{community_id}/membership`;
- `DELETE /v1/communities/{community_id}/membership`.

Existing community creation and existing DB `community_members` are preserved.

### Simulation contract after source regeneration
- OpenAPI paths: `90`;
- HTTP operations: `108`;
- migration-defined tables: `50`;
- Android AppRoutes: `21` — unchanged by design;
- synthetic candidates: `200` + current synthetic user.

## HTML implementation — `v0_5_37`

### Chat
The active frontend obtains conversation/message product records through SimulationEngine routes and exposes:
- direct/group conversation distinction;
- direct E2EE client boundary;
- reply;
- edit own message;
- delete own message;
- reactions;
- demo attachment flow through attachment-shaped route data;
- typing state;
- read state/unread clearing;
- block/report;
- profile transition from direct-chat header;
- group creation with selected members.

Direct-chat plaintext remains client-side in simulation; the BackendSimulator route shape keeps direct message body encrypted/null and SimulationEngine performs the demo client-decryption projection for UI.

### Groups / Communities
- community list via `/v1/communities`;
- join/leave via membership routes;
- separate community-create flow;
- interest/project presentation modes;
- transition from community to group conversation creation;
- group participant selection.

### Search Requests
- standalone list/history surface;
- create/edit/pause/archive;
- persisted filters and desired qualities;
- explicit Apply → People transition;
- route-backed storage via `/v1/search-requests*`;
- no direct `state.searchRequests.rows` reads in frontend screen layer.

## Route-parity rule
Active social frontend screen layer contains no direct reads of:
- `FIXTURES.people`;
- `FIXTURES.communities`;
- `state.chats.messages`;
- `state.searchRequests.rows`.

Synthetic fixtures remain BackendSimulator seed data only.

## Evidence
- Operator Kernel: PASS before/final cycle verification — `16 routes / 8 hooks / 6 agents / 6 skills`.
- full source/architecture/backend regression with `PYTHONPATH=backend`: `368/368 PASS`.
- focused cycle-0026/protected/backend regression: `52/52 PASS`.
- cycle ecosystem guard: `PASS`.
- existing + new backend API tests: PASS.
- cycle 0025 historical evidence preserved in `BROTHERHOOD_UI_SIMULATOR_v0_5_36.html`.
- active copies target: root demo + visual-check demo + `BROTHERHOOD_UI_SIMULATOR_v0_5_37.html` byte-identical.
- HTML parser: PASS.
- inline JS syntax: PASS.
- local Simulation Engine contract probe: `108/108 operations`, `0 failures`, `50 tables`, `200 people`, schema `11`.
- owner visual acceptance: `PENDING`.
- Compose mirror: `NOT_STARTED_BY_DESIGN`.
- GitHub CI/APK: `NOT_RUN`.
- live PostgreSQL migration 0012: `NOT_RUN`.
- LIVE E2E: `NOT_RUN`.

## Stage model
`R=PASS, S=PASS, B=SOURCE_IMPLEMENTED_LOCAL_TESTED_LIVE_DB_NOT_RUN, H=PASS, VA=PENDING, A=NOT_STARTED_BY_DESIGN, CI=NOT_RUN, E2E=NOT_RUN`

## Next cycle
`0027 — UI Recovery C: Trust → Hospitality → Services`.

Cycle 0027 must continue HTML-first. It may not silently convert the unaccepted 0025/0026 visual candidate into Compose authority.
