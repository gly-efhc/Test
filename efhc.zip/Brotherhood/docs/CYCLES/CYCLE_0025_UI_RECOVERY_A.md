# Cycle 0025 — UI Recovery A

Status: **HTML_IMPLEMENTED / ROUTE_BACKED_SIMULATION / VISUAL_ACCEPTANCE_PENDING**  
Date: 2026-08-11

## Goal
Recover the central owner-facing product vertical in standalone HTML without changing current backend/domain semantics or bypassing the Simulation Engine:
`My Profile → People → Candidate → Compatibility Details → Tests → Test Execution → Test Result → Psychological Profile → Psychological Report/history`.

## Implemented
- My Profile is a digital social/professional resume; self-compatibility is absent.
- People reads `/v1/people` through `SimulationEngine.request(...)`, supports search, role/filter state and 20-item progressive loading over the 200-person simulated dataset.
- Candidate is person-first: identity, profession, bio, interests/values/goals, common context, actions, then deeper compatibility/reputation/Hospitality links.
- Compatibility Details reads the independent Q28 server-simulation contract; PC/IC/VC/CC/LC/PT/EN/NU/AS remain independent 0–100 systems. Trust, Account Rating and Quality Fit remain outside Compatibility.
- Tests Home, module view, 6-task execution and meaningful result hierarchy were recovered. Test completion persists through `/v1/assessment-results`.
- Psychological Profile reads assessment results through the route boundary.
- Psychological Report supports current/history selection and immutable report snapshots through report routes.
- Core cycle-0025 frontend surfaces no longer read `FIXTURES.people` directly; fixtures remain backend-simulator data only.
- Active HTML mirror: `tools/visual_checks/BROTHERHOOD_UI_SIMULATOR_v0_5_36.html`; historical `v0_5_35` is preserved unchanged.

## Simulation boundary
Mandatory chain: `backend/domain + DB → routes/source contract → BackendSimulator → SimulationEngine → route responses → frontend`.
Current source-contract inventory remains 87 OpenAPI paths / 100 HTTP operations / 49 DB tables / 21 Android AppRoutes with 200 deterministic synthetic candidates plus the current demo user. This mirrors the **current implemented HEAD**, not future roadmap functions that do not yet exist.

## Verification
- HTML parser: PASS.
- Inline JavaScript `node --check`: PASS (2/2 scripts).
- Cycle 0024/0025 + backend targeted regression: PASS 58/58.
- Historical UI/Hospitality/standalone regression: PASS 32/32.
- Full architecture + backend regression after synchronization: PASS 359/359.
- Node Simulation Engine runtime probe: PASS 100/100 API operations, 0 failures, 49 tables, 200 people; persisted schema 10 reload PASS.
- Browser visual acceptance: **NOT_RUN / owner review required**.
- Android Compose mirror: **NOT_STARTED_BY_DESIGN**.
- GitHub CI/APK: **NOT_RUN**.
- LIVE E2E/live PostgreSQL: **NOT_RUN**.

## Exit state
`R=PASS, S=PASS, B=PASS(current source contract), H=PASS, VA=PENDING, A=NOT_STARTED, CI=NOT_RUN, E2E=NOT_RUN`.

Next gate: owner opens the standalone HTML and provides visual acceptance/corrections. Cycle 0026 implementation does not authorize skipping this visual gate.
