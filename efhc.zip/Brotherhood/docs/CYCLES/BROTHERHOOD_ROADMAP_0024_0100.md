# Brotherhood — подробная однозначная дорожная карта 0024–0100
> **OWNER SEQUENTIAL-ORDER OVERRIDE — 2026-08-17:** execution proceeds by ascending parent cycle ID. `0034`–`0036` are implemented; `0037` is NEXT. The completed 0111 inventory artifact is preserved as out-of-order historical evidence; 0112+ are not active execution IDs.

> **OWNER CORRECTIVE 0035:** technical result copy was rejected; cycle 0035 is used for the human-result continuation of secure administration. The old 0111+ scientific-audit decomposition remains reference material and must not be mistaken for the active sequence.

Status: **ACTIVE OWNER-REPLANNED SINGLE-MODULE PROGRAM**  
Recorded: `2026-08-16`  
Authority: прямое указание владельца — *один цикл = один законченный модуль; не менять несколько психологических систем одновременно*.

## 1. Что именно изменено

- Реализованные циклы `0024–0033` и их evidence **не переписываются**.
- Ранее запланированные, но не реализованные смыслы `0034–0073` **superseded** этим планом до начала их source implementation.
- Диапазон активной программы расширен до `0100`; свободного reserve внутри `0001–0100` больше нет.
- Cycles `0034`–`0036` are implemented. The owner sequential-order correction makes **0037 — Retake, Alternate Order & Practice-Effect Runtime** the next executable cycle. Historical 0111 evidence remains preserved but no longer controls routing.
- Никакой цикл ниже не имеет права «заодно» реализовать соседний модуль. Любая новая идея уходит в следующий номер или отдельный owner-approved replan.

## 2. Неизменяемые правила каждого будущего цикла

1. Один главный продуктовый/исследовательский модуль.
2. Сначала source/method/data contract, затем backend/DB, routes, SimulationEngine, standalone HTML, Chromium E2E.
3. Пользовательский UI не показывает internal IDs, hashes, model keys, construct/scoring secrets или raw research telemetry.
4. Исторические snapshots/versioned results immutable; новая формула = новая version.
5. Missing evidence = `INSUFFICIENT_DATA`, не `0`.
6. Research evidence не меняет production scoring автоматически.
7. Каждый цикл имеет собственные метрики сбора данных и denominator, если он существует.
8. Owner VA остаётся отдельным gate; CI/APK не является визуальной приёмкой.
9. Финал цикла: regression + real Chromium/mobile runtime + persistence reload + deterministic package verification.
10. Если внешний пакет copyleft, его код не копируется в proprietary Android/client автоматически; интеграция выполняется только в явно выбранном compliant режиме.

## 3. Лицензированная технологическая песочница

Подробный инвентарь: `docs/research/tooling/LICENSED_ASSESSMENT_TOOLING_SANDBOX_V1.md`. Эти источники — **TECHNICAL / PRODUCT_DONOR**, а не научная scoring authority.

## Фаза A — Безопасная тестовая администрация и научная коррекция (0034–0043)

### 0034 — Secure Test Administration Runtime v1

**Цель.** Закрыть публичный банк вопросов и scoring keys; выдавать задания только последовательными server-authoritative сессиями.

**Входы и разрешённые доноры.** SurveyJS Form Library 1.12.17 (MIT); Form.io.js 5.5.1 (MIT); текущие 12 Brotherhood test-apps/197 items.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** session_id, item_order_seed, item_presented_at, response_at, response_latency_ms, completion_state, interruption_count; scoring key только server-side.

**Критерий выхода.** Нельзя получить полный item bank/construct mapping обычным API; один вопрос за раз; resume; deterministic server scoring; Chromium проходит 12/12 apps.

**Achieved 2026-08-16.** `SOURCE_HTML_IMPLEMENTED / LOCAL_REGRESSION_PASS / CHROMIUM_PASS / VA_PENDING`; current contract `144 paths / 163 operations / 60 tables / 21 AppRoutes / schema19`; CI NOT_RUN by owner order.

**Вне scope.** Не менять научные формулировки/веса — это 0035–0036.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0035 — Secure Test Administration Runtime v1 — Human Results (OWNER CORRECTIVE OVERRIDE)

**Цель.** Провести полный аудит 197 items: source trace, construct, polarity, reverse-keying, дубли, логическая согласованность и доказуемые ошибки ключей.

**Входы и разрешённые доноры.** Активный Source SSOT; scientific-questionnaire-bank-v1.2; ITC guidance; найденная stress_tolerance anomaly.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** item_version, source_claim_ids, construct_id, intended_polarity, reverse_key, audit_status, reviewer_notes.

**Критерий выхода.** 197/197 audited; противоречия устранены только с evidence; новый immutable bank v1.3; исторический v1.2 сохранён.

**Вне scope.** Не переписывать UX и результаты — это отдельные циклы.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0036 — Neutral Respondent Wording & Response Design v1

**Цель.** Переписать respondent-facing формулировки так, чтобы ответ не подсказывал измеряемую черту и «социально правильный» выбор.

**Входы и разрешённые доноры.** Item bank v1.3; ITC test-security/adaptation principles; owner UX требования.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** wording_version, desirability_balance_review, A/B side randomization, comprehension_flag.

**Критерий выхода.** 180 ситуационных items не раскрывают названия полюсов; 17 anchor items маркированы отдельно; A/B стороны рандомизированы; browser review PASS.

**Вне scope.** Не менять scoring semantics без отдельной научной причины.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0037 — Retake, Alternate Order & Practice-Effect Runtime

**Цель.** Сделать корректное повторное прохождение: история, cooldown, альтернативный порядок, demo-retake и измерение practice effects.

**Входы и разрешённые доноры.** Текущий calendar-month retake contract; SurveyJS save/resume patterns.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** attempt_no, days_since_previous, order_seed, completion_time, score_delta, practice_effect_flag.

**Критерий выхода.** Все 12 demo tests можно повторить; production cooldown сохранён; результаты разных версий не смешиваются; retest history читаема.

**Вне scope.** Не объявлять score_delta личностным изменением без 0049.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0038 — Response Quality & Test Security Metrics v1

**Цель.** Собирать research-only признаки качества прохождения без автоматического наказания пользователя.

**Входы и разрешённые доноры.** Secure sessions 0034; item timing 0037; psychometric governance.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** item_latency, very_fast_rate, straightline_rate, missing_rate, change_rate, interruption_rate, inconsistency_features.

**Критерий выхода.** Quality signals versioned; public result не содержит обвинений; scoring не меняется скрыто; denominator сохраняется.

**Вне scope.** Не использовать как Trust/Account Rating.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0039 — Classical Psychometrics Engine v1

**Цель.** Ввести отдельный серверный модуль reliability/scale analysis для калибровки Brotherhood tests.

**Входы и разрешённые доноры.** psych 2.6.5 (GPL>=2) как отдельный research/analytics service/reference; текущие response datasets.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** n, item_mean, item_sd, item_total_corr, alpha, omega_when_supported, missingness, confidence intervals.

**Критерий выхода.** Расчёты воспроизводимы на frozen dataset/version; результаты не попадают напрямую в user score; export + report.

**Вне scope.** Не встраивать GPL-код в Android client.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0040 — Factor Structure Validation Engine v1

**Цель.** Проверять, соответствует ли фактическая структура ответов заявленным constructs/systems.

**Входы и разрешённые доноры.** psych factor-analysis capabilities; Source SSOT construct model.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** correlation_matrix_version, factor_solution, loadings, communalities, cross_loadings, fit/diagnostic flags.

**Критерий выхода.** Каждая система получает validation report; слабые items помечаются для будущей версии, а не тихо удаляются.

**Вне scope.** Не менять production model автоматически.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0041 — IRT Calibration Service v1

**Цель.** Оценивать параметры items и информативность шкал через IRT.

**Входы и разрешённые доноры.** mirt 1.46.10 (GPL>=3) в изолированном server/research service; frozen response datasets.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** item_difficulty, discrimination, thresholds, information_curve, person_theta_research, model_version.

**Критерий выхода.** Воспроизводимая калибровка; model diagnostics; item information catalog; никакого скрытого влияния до promotion gate.

**Вне scope.** CAT не включать — это 0048.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0042 — DIF, Group Fairness & Measurement Invariance v1

**Цель.** Проверять, работают ли items сопоставимо между языковыми/демографическими группами.

**Входы и разрешённые доноры.** mirt multiple-group/DIF; ITC adaptation guidance; locale metadata.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** group_n, DIF_stat, DIF_effect, invariance_status, language_version, excluded_reason.

**Критерий выхода.** Минимальные sample gates; small-N = INSUFFICIENT_DATA; issue registry на item/version; не исправлять «по ощущениям».

**Вне scope.** Не использовать protected group как ranking feature.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0043 — Psychological Test Results & Report v3

**Цель.** Сделать взрослый, читаемый результат: вывод, профиль проявлений, уверенность, ограничения, динамика и история.

**Входы и разрешённые доноры.** Validated output contracts 0035–0042; current Psychological Report canon.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** score_version, coverage, confidence, stability, history_delta, interpretation_id, evidence_level.

**Критерий выхода.** Нет внутренних IDs/weights на основном UI; report immutable/versioned; Chrome mobile reading E2E PASS.

**Вне scope.** Не смешивать Trust, Quality Fit, Compatibility.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза B — Единая платформа опросов и тестов (0044–0051)

### 0044 — Survey Definition Runtime Core v1

**Цель.** Создать единый JSON contract форм/опросов: validation, branching, multi-step, partial save, resume, lazy loading.

**Входы и разрешённые доноры.** SurveyJS MIT; Form.io.js MIT как engineering donors.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** definition_version, page_id, branch_taken, validation_errors, partial_save, resume_count.

**Критерий выхода.** Native Brotherhood schema + renderer; backend authoritative definition; импорт/экспорт JSON; browser parity.

**Вне scope.** Не делать admin builder — 0045.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0045 — Assessment Authoring & Version Management v1

**Цель.** Внутренний инструмент создания/редактирования assessments с review/publish workflow.

**Входы и разрешённые доноры.** Form.io builder concepts; SurveyJS schema concepts.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** draft_version, reviewer, approval_state, publish_at, supersedes_version, change_reason.

**Критерий выхода.** Draft ≠ production; immutable published versions; diff; rollback; no scoring key exposure to respondent.

**Вне scope.** Не менять научное содержание без reviewer evidence.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0046 — Assessment Localization Pipeline v1

**Цель.** Версионировать переводы/адаптации по 13 locales и отделить перевод от измерительной эквивалентности.

**Входы и разрешённые доноры.** ITC adaptation guidance; Survey/Lime multilingual patterns.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** locale, translator_version, backtranslation_status, reviewer_status, comprehension_notes.

**Критерий выхода.** 13-locale catalog; fallback policy; locale version pinned per attempt; untranslated ≠ auto-approved.

**Вне scope.** DIF решается в 0042, не этим циклом.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0047 — Mobile Assessment UX & Accessibility v1

**Цель.** Сделать прохождение тестов Android-first: один вопрос, понятный прогресс, крупные touch targets, отсутствие прыжков, accessibility.

**Входы и разрешённые доноры.** Brotherhood service UX canon; SurveyJS mobile patterns; current Chromium gates.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** viewport_mode, navigation_error, abandon_step, completion_time, accessibility_audit.

**Критерий выхода.** Standalone открывается mobile-first; no auto-scroll jumps; keyboard/screen-reader basics; 12 apps E2E.

**Вне scope.** Не менять психометрику.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0048 — Adaptive Test Selection Pilot v1

**Цель.** Пилотировать сокращение теста на основе item information без ухудшения coverage.

**Входы и разрешённые доноры.** IRT outputs 0041; secure session runtime 0034.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** selected_item_reason, information_before/after, stop_rule, administered_count, precision_estimate.

**Критерий выхода.** Research-only CAT pilot; deterministic replay; сравнение с full form; promotion только после evidence.

**Вне scope.** Не включать в production по умолчанию.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0049 — Longitudinal Test History & Change v1

**Цель.** Отделить реальное устойчивое изменение от шума/версий/практики.

**Входы и разрешённые доноры.** Attempts 0037; reliability 0039; versioned reports 0043.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** test_retest_interval, reliable_change_index_when_supported, version_bridge, trend_confidence.

**Критерий выхода.** История читабельна; несовместимые версии не сравниваются как одинаковая шкала; uncertainty shown.

**Вне scope.** Не трактовать изменение как диагноз.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0050 — Research Dataset Builder & Codebook v1

**Цель.** Формировать обезличенные frozen datasets для научного анализа без ручной выгрузки БД.

**Входы и разрешённые доноры.** Survey runtime; consent/governance; psych/mirt analytics.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** dataset_id, cohort_definition, denominator, variables, missingness, extraction_version, pseudonymization.

**Критерий выхода.** Reproducible export + machine-readable codebook; no direct identifiers; provenance complete.

**Вне scope.** Не давать аналитикам production secrets.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0051 — Assessment Consent & Data Governance Runtime v1

**Цель.** Версионировать согласия, research-use permissions, withdrawal и правила сохранения обезличенных агрегатов.

**Входы и разрешённые доноры.** Owner authorization; current calibration consent; privacy canon.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** consent_version, purposes, granted_at, withdrawn_at, data_lane, deidentified_retention_state.

**Критерий выхода.** Каждый research dataset имеет consent basis; withdrawal lifecycle tested; aggregate/norm retention rules documented.

**Вне scope.** Не смешивать согласие с legal acceptance других продуктов.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза C — Ассоциации и implicit — полноценные приложения и нормативы (0052–0062)

### 0052 — Word Association UX v2

**Цель.** Полностью переделать «Быстрые ассоциации»: один стимул, понятная инструкция, ввод ответа, минимум технических деталей, полезный результат.

**Входы и разрешённые доноры.** WORD_ASSOCIATION_V1; Jung method line; mobile UX canon.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** response_text, latency_ms, skip, edit_count, repeat_flag; technical details hidden from main UI.

**Критерий выхода.** 24 cues пройти приятно; ответ всегда видим; result explains what was observed; Chromium mobile E2E.

**Вне scope.** Не ставить диагноз по одному слову.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0053 — УрРАС Norm Import & VPS Store v1

**Цель.** Импортировать УрРАС как versioned normative corpus в отдельное VPS-хранилище.

**Входы и разрешённые доноры.** Owner-authorized УрРАС; association norms authorization.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** stimulus, response, count, frequency, rank, sample metadata, source_version, provenance_hash.

**Критерий выхода.** Repeatable importer; source snapshot hash; indexes stimulus→response/response→stimulus; integrity report.

**Вне scope.** Не объединять с другими нормами — 0056.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0054 — ЕВРАС Norm Import & VPS Store v1

**Цель.** Импортировать ЕВРАС в собственный versioned corpus без потери прямого/обратного словаря.

**Входы и разрешённые доноры.** Owner-authorized ЕВРАС.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** stimulus, response, count/frequency, direction, sample/source metadata, provenance_hash.

**Критерий выхода.** Importer + indexes + parity checks + source-specific namespace.

**Вне scope.** Не усреднять с УрРАС.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0055 — РАС Norm Import & VPS Store v1

**Цель.** Импортировать РАС как отдельный исторический/нормативный слой с точным provenance.

**Входы и разрешённые доноры.** Owner-authorized РАС.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** stimulus, response, rank/frequency where available, source_edition, provenance_hash.

**Критерий выхода.** Source-specific dataset; integrity + lookup API; missing fields explicit.

**Вне scope.** Не выдумывать отсутствующие частоты.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0056 — Unified Russian Association Norms Service v1

**Цель.** Объединить lookup поверх УрРАС/ЕВРАС/РАС без потери происхождения и различий выборок.

**Входы и разрешённые доноры.** 0053–0055 corpora.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** per_source_frequency, pooled_frequency_if_methodologically_allowed, source_agreement, source_disagreement, coverage.

**Критерий выхода.** One API; source-specific and cross-source views; conflict rules; missing=INSUFFICIENT_DATA.

**Вне scope.** Не превращать pooled value в психологический score.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0057 — Association Content Analysis v2

**Цель.** Добавить содержательный анализ ответа: типичность, редкость, ассоциативная сила, направление и семантические relation features.

**Входы и разрешённые доноры.** Norms service 0056; current association events.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** norm_strength, rank, rarity_percentile, response_coverage, semantic_relation_id, source_support_count.

**Критерий выхода.** Каждая feature имеет provenance; unknown response честно unknown; user summary без technical IDs.

**Вне scope.** Не делать клинические выводы.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0058 — Association Process Analysis v2

**Цель.** Усилить process layer: latency, edits, skips, repetitions, intra-session dynamics, device timing quality.

**Входы и разрешённые доноры.** WORD_ASSOCIATION_V1 raw events; jsPsych timing concepts.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** latency_z_within_session, edit_rate, skip_rate, repetition_pattern, timing_quality.

**Критерий выхода.** Versioned process features; device quality flag; public summary понятен.

**Вне scope.** Не считать длинную latency автоматически проблемой.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0059 — Association Interpretation Graph v1

**Цель.** Создать комбинационный evidence graph до 1000 контекстных гипотез на ответ вместо 1000 шаблонных диагнозов.

**Входы и разрешённые доноры.** 0057 content + 0058 process + user longitudinal context + expert boundary packs later.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** hypothesis_id, supporting_features, contradicting_features, confidence_tier, source_refs, suppression_reason.

**Критерий выхода.** Детерминированное top-N для пользователя; до 1000 research hypotheses stored/queryable; contradictions visible.

**Вне scope.** Никакой «скрытой истины»/диагноза.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0060 — Free Association Chain v2

**Цель.** Сделать free-chain самостоятельным приложением: переходы, тематическая устойчивость, semantic drift, возвраты и process dynamics.

**Входы и разрешённые доноры.** ASSOCIATIVE_FREE_CHAIN_V1; norms/analysis 0056–0059.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** transition_strength, semantic_distance, return_pattern, chain_depth, latency_by_transition.

**Критерий выхода.** 8×5 flow; chain graph; history; clear result; pair metric остаётся отдельным.

**Вне scope.** Не применять универсальный символический словарь.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0061 — Implicit RT / IAT Runtime v2

**Цель.** Перестроить reaction-time эксперимент на профессиональную timeline/plugin архитектуру и timing-quality capture.

**Входы и разрешённые доноры.** jsPsych MIT; IMPLICIT_ASSOCIATION_RT_V1; PsychoPy as benchmark/reference.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** trial_type, stimulus_onset, response_time, correctness, block_order, device_timing_quality.

**Критерий выхода.** 48/32 contract preserved; deterministic scoring; browser timing tests; no tech clutter in user UI.

**Вне scope.** Не смешивать с conscious questionnaire.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0062 — Association Longitudinal Profile v1

**Цель.** Показывать изменения ассоциативных и process-паттернов во времени без переинтерпретации прошлого.

**Входы и разрешённые доноры.** 0052–0061 versioned results.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** cue_history, response_stability, latency_stability, interpretation_stability, version_bridge.

**Критерий выхода.** History readable; old results immutable; version-aware comparisons.

**Вне scope.** Не объявлять drift личностным изменением без evidence.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза D — Эксперименты, research surveys, Q48/Q49 и метрики (0063–0071)

### 0063 — Behavioral Experiment Runtime v1

**Цель.** Создать универсальный Brotherhood experiment runtime для timelines/plugins, stimulus presentation и event capture.

**Входы и разрешённые доноры.** jsPsych MIT; PsychoPy experimental architecture as reference.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** trial_id, timeline_node, stimulus_type, onset, response, rt, device_context, completion.

**Критерий выхода.** Plugin contract; replayable experiment definitions; SimulationEngine route-backed.

**Вне scope.** Не включать конкретный новый психологический тест.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0064 — Experimental Timing Validation Lab v1

**Цель.** Отдельно валидировать точность RT/стимулов на устройствах и браузерах, сравнивая с лабораторным эталоном.

**Входы и разрешённые доноры.** PsychoPy GPLv3 isolated lab/reference tool; jsPsych runtime.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** expected_duration, observed_duration, jitter, dropped_frames, device/browser, calibration_status.

**Критерий выхода.** Timing qualification matrix; unsupported devices flagged; benchmark code isolated from proprietary client.

**Вне scope.** Не менять IAT score без version promotion.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0065 — In-App Research Survey Targeting v1

**Цель.** Запускать опросы по сегментам/событиям без спама и изменения приложения.

**Входы и разрешённые доноры.** Formbricks snapshot: targeting/journey concepts; MIT SDK areas where applicable; current event bus.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** trigger_event, eligibility, segment, cooldown, invitation_sent, opened, completed, declined.

**Критерий выхода.** Targeting rules versioned; frequency caps; no duplicate invite; denominator preserved.

**Вне scope.** Не копировать AGPL core в клиент без отдельного compliance decision.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0066 — Research Survey Builder & Closed Access v1

**Цель.** Внутренний конструктор исследовательских анкет с закрытым доступом, токенами, multilingual и anonymized mode.

**Входы и разрешённые доноры.** LimeSurvey GPLv2+ as isolated service/reference; SurveyJS/Form.io MIT schema runtime.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** survey_version, access_mode, invite_token_hash, locale, anonymous_flag, completion_state.

**Критерий выхода.** Closed/open surveys; tokens; anonymous mode; exports; 13 locales; service isolation documented.

**Вне scope.** Не смешивать research survey с public Tests catalog.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0067 — Sampling, Randomization & Denominator Runtime v1

**Цель.** Единый механизм randomized/stratified sampling, cooldown и учёта denominator/nonresponse.

**Входы и разрешённые доноры.** Q49 owner canon; Formbricks targeting concepts; research statistics hygiene.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** eligible_n, sampled_n, invited_n, started_n, completed_n, refused_n, strata, randomization_seed.

**Критерий выхода.** Every research result knows denominator; deterministic sampling replay; non-response explicit.

**Вне scope.** Не анализировать только responders.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0068 — Q49 Friendship Reflection Survey Runtime v1

**Цель.** Реализовать независимые A/B опросы «почему вы стали друзьями?» после проверенных триггеров.

**Входы и разрешённые доноры.** FRIENDSHIP_REFLECTION_SURVEYS_V1; 0066–0067 runtime.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** pair_id, outcome_id, respondent_side, reasons, turning_point, meeting_reason, timing, consent, response_delay.

**Критерий выхода.** Ответы независимы до закрытия; bilateral agreement/disagreement; history/follow-up.

**Вне scope.** Не менять Compatibility/Trust автоматически.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0069 — Q48 Reverse Friendship Outcome Hardening v2

**Цель.** Усилить pre-friendship snapshot/exposure comparison и строго отделить homophily от convergence.

**Входы и разрешённые доноры.** Q48 canon; verified interactions; 0067 denominator runtime.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** snapshot_version, exposure_units, outcome_class, confirmation, similarity/difference features, followup_time.

**Критерий выхода.** Friend vs sufficiently-exposed controls; descriptive evidence; reproducible cohorts.

**Вне scope.** Не сравнивать с случайными людьми.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0070 — Longitudinal Follow-up & Recontact Runtime v1

**Цель.** Версионировать повторные приглашения и измерения через заданные интервалы.

**Входы и разрешённые доноры.** Surveys 0066; sampling 0067; Q49/Q48.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** schedule_version, due_at, contact_attempts, completion, attrition_reason, interval_days.

**Критерий выхода.** No spam; cooldown; exact follow-up cohorts; attrition measured.

**Вне scope.** Не использовать background job без audit trail.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0071 — Deidentified Research Warehouse & Metrics Catalog v1

**Цель.** Свести measurement lanes в обезличенное research-хранилище с каталогом метрик и provenance.

**Входы и разрешённые доноры.** 0050 dataset builder; association/test/outcome modules.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** metric_id, definition_version, data_lane, cohort, denominator, provenance, sensitivity_class.

**Критерий выхода.** One metric catalog; reproducible extracts; source/user identifiers separated; access audit.

**Вне scope.** Не превращать warehouse в production scoring DB.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза E — Профессиональные knowledge packs и интерпретация (0072–0077)

### 0072 — Psychologist Knowledge Pack v1

**Цель.** Создать versioned профессиональный knowledge pack для психометрики, интервью, интерпретации и ограничений тестов.

**Входы и разрешённые доноры.** ITC guidelines; psych/mirt outputs; current scientific corpus.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** rule_id, domain, evidence_refs, applicability, contraindication, reviewer_status, version.

**Критерий выхода.** Rules traceable; no free-form LLM authority; expert review surface; update/diff.

**Вне scope.** Не выдавать психиатрию за психологию.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0073 — Psychiatry Boundary & Clinical Safety Pack v1

**Цель.** Формализовать границы: что Brotherhood может описывать, что требует клинической оценки, какие red flags требуют безопасной маршрутизации.

**Входы и разрешённые доноры.** Clinical assessment governance sources in Source SSOT; owner requirement for psychiatrist skill.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** boundary_rule, red_flag_category, allowed_language, prohibited_inference, escalation_guidance.

**Критерий выхода.** No diagnosis from tests/associations; user-facing language guard; clinical flags separate from compatibility.

**Вне scope.** Не создавать автоматический диагноз.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0074 — Expert Review Workflow v1

**Цель.** Ввести независимый review/approval процесс для items, interpretations, knowledge rules и scoring promotions.

**Входы и разрешённые доноры.** 0072–0073 packs; authoring 0045.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** artifact_id, reviewer_role, decision, rationale, requested_change, approved_version.

**Критерий выхода.** Two-stage review where configured; audit history; rejected rule cannot ship.

**Вне scope.** Не подменять owner VA научным review.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0075 — Interpretation Evidence Ledger v1

**Цель.** Каждое пользовательское психологическое утверждение связать с evidence tier, method contract и ограничениями.

**Входы и разрешённые доноры.** Source SSOT; expert reviews; all psychological modules.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** interpretation_id, evidence_level, source_ids, method_id, population_scope, caveats.

**Критерий выхода.** No orphan interpretations; unsupported text fails guard; public wording decoupled from technical provenance.

**Вне scope.** Не показывать IDs на main UI.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0076 — Psychological Profile v3

**Цель.** Собрать текущий структурированный психологический профиль только из допустимых независимых evidence lanes.

**Входы и разрешённые доноры.** Validated tests; associative/implicit; longitudinal data.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** profile_version, lane_status, coverage, confidence, last_updated, missing_lanes.

**Критерий выхода.** Missing=INSUFFICIENT_DATA; no hidden blending; each lane inspectable.

**Вне scope.** Trust/Rating/QF excluded.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0077 — Psychological Report v4

**Цель.** Сделать immutable human-readable report с выводами, неопределённостью, изменениями и рекомендациями наблюдения.

**Входы и разрешённые доноры.** Profile v3; interpretation ledger; history.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** report_version, profile_snapshot_hash, interpretation_set, confidence, caveats.

**Критерий выхода.** Readable director-quality/user-quality report; re-open history; no technical clutter.

**Вне scope.** Не прогнозировать диагноз или судьбу отношений.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза F — Compatibility / Quality Fit / Trust / outcome promotion (0078–0083)

### 0078 — Unified Multi-method Compatibility Service v1

**Цель.** Реализовать единый сервис независимых PC/IC/VC/CC/LC/PT/EN/NU/AS с выбором систем и простым средним.

**Входы и разрешённые доноры.** Q28 canon; existing per-system scorers.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** selected_systems, per_system_score/status, selected_overall, missing_systems, version_set.

**Критерий выхода.** No hidden weights; missing=INSUFFICIENT_DATA; immutable comparison snapshots/history.

**Вне scope.** Trust/QF excluded.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0079 — Compatibility Detail & Explanation IA v1

**Цель.** Отдельный взрослый экран объяснения каждой системы, метода, данных и ограничений.

**Входы и разрешённые доноры.** 0078 service; methodology catalogs.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** viewed_metric, detail_depth, explanation_version.

**Критерий выхода.** Person-first UI; Overall → metrics → method details; technical provenance only secondary.

**Вне scope.** Не менять scoring.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0080 — Quality Fit / SearchIntent v3

**Цель.** Расширить directional QF на versioned explicit requirements, evidence coverage и explainable eligibility.

**Входы и разрешённые доноры.** 0033 QF v2; validated metric catalog.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** intent_version, requirement_type, evidence_source, eligibility, confidence, explanation.

**Критерий выхода.** A→B directional; hard/preference separate; missing explicit.

**Вне scope.** Не превращать QF в Compatibility.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0081 — Trust v2 Observed-Behavior Runtime

**Цель.** Отдельно продуктировать Trust как evidence-ledger поведения/верификаций/инцидентов с апелляциями.

**Входы и разрешённые доноры.** Current trust incidents; observed behavior methodology; verified interactions.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** evidence_event, weight_version if defined, moderation_state, appeal_state, recency.

**Критерий выхода.** Transparent event history; appeals; no psychology/numerology influence.

**Вне scope.** Не смешивать с Account Rating/Hospitality.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0082 — Outcome-based Recalibration Governance v1

**Цель.** Формализовать продвижение research evidence в новую production model version только через review/promotion.

**Входы и разрешённые доноры.** Q48/Q49; research warehouse; psychometric validation.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** candidate_model, evidence_bundle, fairness_checks, reviewer_decision, rollout_version.

**Критерий выхода.** No silent auto-weight changes; rollback; frozen old comparisons reproducible.

**Вне scope.** Не запускать self-learning production scoring без gate.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0083 — Friendship Mechanism Research Dashboard v1

**Цель.** Показать исследовательской команде агрегаты Q48+Q49: что измерено заранее, что произошло, что сами друзья считают причиной.

**Входы и разрешённые доноры.** 0068–0069; warehouse 0071.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** factor_frequency, bilateral_agreement, asymmetry, outcome_rate, cohort_denominator, persistence.

**Критерий выхода.** Research-only dashboard; filters/cohorts; no user-level deanonymization.

**Вне scope.** Не показывать как public compatibility score.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза G — Социальный продукт, коммуникации, Hospitality и offline services (0084–0096)

### 0084 — My Profile / Digital Resume v3

**Цель.** Сделать Профиль взрослым социальным резюме: личность, опыт, навыки, интересы, цели, доступность и privacy.

**Входы и разрешённые доноры.** Root IA canon; profile data.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** section_completeness, visibility, update_history.

**Критерий выхода.** Default root screen; edit/read parity; privacy per section.

**Вне scope.** Не смешивать psych raw data.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0085 — People Discovery & Ranking v3

**Цель.** Поиск людей по явным запросам/фильтрам с person-first выдачей и отдельными metrics.

**Входы и разрешённые доноры.** People canon; QF/compat services.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** query, filters, candidate_exposure, rank_features_version, opened_profile.

**Критерий выхода.** No hidden sensitive filters; explainable ranking lanes; 200 synthetic candidates parity.

**Вне scope.** Не использовать Trust как Compatibility.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0086 — Search Requests Marketplace of Intent v3

**Цель.** Полноценные запросы «кого/для чего ищу» с жизненным циклом, matching и откликами.

**Входы и разрешённые доноры.** Existing search_requests; SearchIntent.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** request_state, requirements, visibility, applications, matches, close_reason.

**Критерий выхода.** Create/edit/pause/close/history; route-backed UI.

**Вне scope.** Не объединять с generic People query.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0087 — Candidate Deep Profile v3

**Цель.** Глубокий профиль другого человека: identity, resume, compatibility/QF/Trust отдельными блоками, история взаимодействий.

**Входы и разрешённые доноры.** Profile/compat/QF/Trust services.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** profile_view, section_access, comparison_created, contact_action.

**Критерий выхода.** Person first; progressive disclosure; permission-aware.

**Вне scope.** No raw psychological answers.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0088 — Groups / Communities v3

**Цель.** Полноценные сообщества: каталог, вступление, роли, правила, события/темы и модерация.

**Входы и разрешённые доноры.** Existing communities.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** membership_state, role, join_source, activity, moderation_event.

**Критерий выхода.** Join/leave/roles/history; group profile; route-backed.

**Вне scope.** Chat media отдельно 0091.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0089 — Projects / Skills / Team Formation v2

**Цель.** Проекты и команды: роли, навыки, потребности, кандидаты и team-fit evidence отдельно от общего QF.

**Входы и разрешённые доноры.** Mentor/project/team research; profile skills.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** project_role, required_skill, application, team_candidate, fit_breakdown.

**Критерий выхода.** Project lifecycle; role-specific matching; no hidden psychology weights.

**Вне scope.** Не смешивать с employment compliance.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0090 — Direct Chat v3

**Цель.** Довести личный чат до production-grade UX: messages, attachments, reactions, receipts, search, safety actions.

**Входы и разрешённые доноры.** Existing messaging backend; Telegram clarity donor.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** delivery_state, read_state, attachment, reaction, report/block actions.

**Критерий выхода.** Stable scroll; offline queue hooks; search/history.

**Вне scope.** Group moderation отдельно 0091.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0091 — Group Chat / Media / Moderation v3

**Цель.** Отдельный групповой communication module: media, threads/replies if canon, moderation and permissions.

**Входы и разрешённые доноры.** Groups 0088; messaging.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** member_role, message_event, media, moderation_action, report.

**Критерий выхода.** Permissions enforced; moderation audit; performance tests.

**Вне scope.** Не включать verified meetings.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0092 — Verified Real-world Interactions v3

**Цель.** Фиксировать проверенные встречи/совместные активности как отдельный outcome/evidence слой.

**Входы и разрешённые доноры.** Q48/Q49 triggers; current verified_interactions.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** interaction_id, participants, verification_method, occurred_at, consent, outcome_link.

**Критерий выхода.** Mutual/verified states; privacy; triggers research surveys.

**Вне scope.** Не повышать Trust автоматически без contract.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0093 — Hospitality Host/Guest Experience v3

**Цель.** Полный host/guest lifecycle: availability, request, accept/decline, stay, completion.

**Входы и разрешённые доноры.** Existing hospitality source cycles.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** availability, request_state, event_history, stay_confirmation.

**Критерий выхода.** Host/guest screens; state machine; history.

**Вне scope.** Reputation/safety отдельно 0094.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0094 — Hospitality Reputation & Safety v3

**Цель.** Отдельно reviews, reputation, restrictions, safety incidents and appeals for stays.

**Входы и разрешённые доноры.** Hospitality reviews/restrictions; Trust separation canon.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** review, stay_verified, reputation_components, restriction, appeal.

**Критерий выхода.** Only verified stay review; transparent history; no cross-contamination with account rating.

**Вне scope.** Не смешивать Compatibility.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0095 — Services / Mutual Aid / Offline Handoff v2

**Цель.** Каталог взаимопомощи/услуг с запросом, откликом, договорённостью и завершением офлайн.

**Входы и разрешённые доноры.** Brotherhood mutual-aid canon.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** service_offer/request, match, handoff, completion, cancellation.

**Критерий выхода.** Lifecycle + safety/reporting hooks; person-first.

**Вне scope.** Не превращать в payments marketplace без отдельного canon.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0096 — Notifications, Activity & Relationship History v2

**Цель.** Единая лента важных событий и история отношений без спама.

**Входы и разрешённые доноры.** All social modules.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** notification_type, delivery, opened, muted, relationship_event.

**Критерий выхода.** Preference controls; aggregation; history timeline.

**Вне scope.** Не включать скрытые research events.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## Фаза H — Надёжность, безопасность и release qualification (0097–0100)

### 0097 — Offline / Sync / Conflict / Recovery v2

**Цель.** Сделать устойчивую синхронизацию основных пользовательских данных и восстановление после обрыва.

**Входы и разрешённые доноры.** Existing device_sync_state; route contracts.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** sync_cursor, pending_ops, conflict_type, resolution, recovery_result.

**Критерий выхода.** Deterministic conflict rules; no data loss in tested scenarios.

**Вне scope.** Не менять бизнес-правила модулей.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0098 — Security, Privacy, Abuse & Moderation Release Audit

**Цель.** Финальный отдельный security/privacy/abuse audit всех активных поверхностей и данных.

**Входы и разрешённые доноры.** Auth, privacy, moderation, consent, data warehouse.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** finding_id, severity, affected_surface, remediation, verification.

**Критерий выхода.** No open critical/high unresolved under release policy; secrets scan; permissions audit.

**Вне scope.** Не заменяет owner VA.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0099 — Full Release-Parity Simulation + Live E2E Rehearsal

**Цель.** Полный сквозной прогон всех реализованных модулей через единый SimulationEngine и live-like environment.

**Входы и разрешённые доноры.** All modules 0034–0098.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** route_coverage, scenario_coverage, failures, persistence_reload, recovery.

**Критерий выхода.** 100% active route probe; lifecycle scenarios; browser/mobile runtime; persistence parity.

**Вне scope.** Не объявлять production qualified — 0100.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

### 0100 — Release Candidate / Production Qualification

**Цель.** Собрать финальный RC, закрыть evidence gates и выдать production qualification decision.

**Входы и разрешённые доноры.** 0099 evidence + security + VA + Android/CI/E2E.

**Что должно быть реализовано.**
- отдельный versioned domain/spec contract;
- минимально необходимые persistence/API изменения;
- BackendSimulator + SimulationEngine parity;
- самостоятельный пользовательский/исследовательский HTML-flow, если модуль имеет UI;
- history/re-read/replay там, где результат должен быть воспроизводимым;
- методологические/лицензионные границы непосредственно в contract, а не скрытым устным допущением.

**Что собираем.** artifact_hashes, gate_status, known_risks, rollback_plan, qualification_decision.

**Критерий выхода.** Deterministic archive/APK/AAB; manifest/file-map parity; owner VA; CI; live E2E; signed decision.

**Вне scope.** Никаких новых функций в этом цикле.

**Обязательный gate цикла.** Kernel + cycle ecosystem + JSON + backend + architecture + targeted module tests + protected-current-product regression + HTML parser + JS syntax + external-assets scan + real Chromium/mobile E2E + full SimulationEngine route probe + new-route probe + persistence reload + active-copy parity + manifest/file-map parity + deterministic package verification.

## 4. Управленческие checkpoints

- `0043`: тесты научно и продуктово приведены в порядок; отчёты читаемы.
- `0051`: единая secure assessment/survey platform и data governance готовы.
- `0062`: ассоциативный блок полноценен и использует versioned normative corpora.
- `0071`: research surveys/Q48/Q49 и warehouse дают воспроизводимые метрики.
- `0077`: профессиональные knowledge packs и психологические report/profile готовы.
- `0083`: Compatibility/Trust/outcome promotion разделены и воспроизводимы.
- `0096`: основной социальный продукт и real-world сервисы закрыты отдельными модулями.
- `0100`: Production Qualification — без новых функций.
