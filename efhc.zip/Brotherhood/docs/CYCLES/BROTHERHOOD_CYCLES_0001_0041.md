# Brotherhood — canonical major cycles 0001–0041

> **STATUS UPDATE 2026-08-11:** this plan is retained as predecessor/history for its already executed milestones. Active assigned planning from cycle 0024 onward is `BROTHERHOOD_CYCLES_0024_0073.md`. Where future cycle assignments overlap, the 0024–0073 plan is authoritative.


Status: **ACTIVE OWNER ROADMAP AFTER FUNCTIONAL-REALITY AUDIT 2026-08-11**

## Product-truth rule
A cycle may be complete in one evidence dimension without the application feature being complete. This roadmap distinguishes:
`RESEARCH_COMPLETE`, `SOURCE_IMPLEMENTED`, `HTML_VISUALLY_ACCEPTED`, `ANDROID_MIRRORED`, `CI_APK_VERIFIED`, `LIVE_E2E_VERIFIED`, `PRODUCTION_QUALIFIED`.

Flat `COMPLETED` must not be interpreted as “user feature finished”.

## Historical gates
- `0001`: historical foundation complete.
- `0002`: source milestone exists; APK/device acceptance remains historical `CHECKPOINT_PENDING`.
- `0003`: backend/auth source exists; `LIVE_E2E_PENDING / EXTERNAL_GATE` remains unresolved.
- `0004–0018`: research/scientific milestones are preserved as **RESEARCH_COMPLETE**, but do not imply product runtime activation.
- `0019–0022`: Hospitality planning/source program exists; owner visual acceptance for the full product remains open.

## Active roadmap
| Cycle | Status | Major result | Product exit gate |
|---|---|---|---|
| 0004 | RESEARCH_COMPLETE / PRODUCTIZATION_PENDING | Compatibility Research Foundation | Research docs only; no product-complete claim. |
| 0005 | RESEARCH_COMPLETE / PRODUCTIZATION_PENDING | Scientific Source Registry & Evidence Taxonomy | Evidence corpus complete for that milestone; runtime unaffected. |
| 0006 | RESEARCH_COMPLETE / PRODUCTIZATION_PENDING | Psychological Construct Architecture | Construct architecture exists; psychological product not completed. |
| 0007 | RESEARCH_COMPLETE / PRODUCTIZATION_PENDING | Visual Stimulus Scientific Program | Research metadata/protocol exists; production item-bank qualification pending. |
| 0008 | RESEARCH_COMPLETE / EMPIRICAL_VALIDATION_PENDING | Calibration & Psychometric Validation Protocol | Protocol exists; calibration/equivalence claims require real data. |
| 0009 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Psychological Compatibility Engine v1 Research Spec | Research spec exists; production scoring unchanged. |
| 0010 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Friendship Compatibility Science | Research model only. |
| 0011 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Business Partner Compatibility Science | Research model only. |
| 0012 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Worker / Team Fit Science | Research model only. |
| 0013 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Mentor / Project Partner Compatibility | Research model only. |
| 0014 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Interests Compatibility Engine | IC research baseline; production inactive. |
| 0015 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Values Compatibility Engine | VC research baseline; production inactive. |
| 0016 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Communication Compatibility Engine | CC research baseline; production inactive. |
| 0017 | RESEARCH_COMPLETE / PRODUCTION_INACTIVE | Lifestyle Compatibility Engine | LC research baseline; production inactive. |
| 0018 | RESEARCH_COMPLETE / PRODUCTIZATION_PENDING | Brotherhood Personality-Type Engine | Continuous/type-membership research architecture; production migration pending. |
| 0019 | PLAN_COMPLETE | Hospitality Integration Plan / Research Outcome Architecture | Planning only. |
| 0020 | SOURCE_IMPLEMENTED / LIVE_DB_PENDING | Hospitality Foundation + Backend Lifecycle | Source/backend tests exist; live DB/runtime evidence separate. |
| 0021 | SOURCE_IMPLEMENTED / HTML_ACCEPTANCE_PENDING | Hospitality Verified Stay / Reviews / Trust + Android UX | Source exists; full UX not owner accepted. |
| 0022 | SOURCE_COMPLETED / FUNCTIONAL_REALITY_AUDIT / VISUAL_ACCEPTANCE_REOPENED | Hospitality release-parity + CI hotfix + full product truth correction | Current HTML rejected by owner; no new CI as UX gate. |
| 0023 | SOURCE_RECOVERY_IMPLEMENTED / SUPERSEDED_BY_0024 / VA_PENDING | **Product Recovery I / Functional Recovery Foundation — Tests + Results + Retake + Psychology + Report + Q28/Numerology** | Assessment modules/results/retake, psychological profile/analysis/report snapshot, independent compatibility + NU and recovery HTML were source-implemented; later persistence/server gaps moved to 0024. |
| 0024 | ACTIVE_SOURCE_IMPLEMENTED / FULL_SIMULATION_PARITY / VA_PENDING | **Runtime Recovery II — Report persistence + server compatibility contracts + full simulation** | Immutable report history, Q28 server/prefs, 200-person full simulator and 87/100/49/21 source-contract parity implemented; live DB/VA/Compose/CI/E2E remain open. |
| 0025 | NEXT / HTML_UI_RECOVERY_A | **UI Recovery A — Own Profile + People + Candidate + Compatibility + Tests/Psychology + Full Psychological Report history** | Complete the first owner-facing HTML acceptance iteration for the recovered core. |
| 0026 | PLANNED | **UI Recovery B — Chat + Groups + Search Requests** | Telegram-class communication presentation and progressive intent/community flows; HTML accepted. |
| 0027 | PLANNED | **UI Recovery C — Trust + Hospitality + Services** | Complete service decomposition and integrated HTML; owner accepted. |
| 0028 | PLANNED | **Visual Acceptance → Android Mirror → APK/CI** | Full standalone HTML owner acceptance, exact accepted Compose mirror, then CI/APK and later live qualification. |
| 0029 | DEFERRED_PLANNED | Enneagram Engine | Original scope preserved; starts only after base product recovery. |
| 0030 | DEFERRED_VNEXT | Numerology Research / Validation vNext | Base date-based numerology + independent NU are source-productized in 0023/0024; this slot hardens exact tradition/formulas/provenance, reproducibility, explanation and validation after recovery. |
| 0031 | DEFERRED_PLANNED | Astrology / Zodiac Engine | Original scope preserved. |
| 0032 | DEFERRED_PLANNED | Quality Fit / SearchIntent v2 | Original scope preserved. |
| 0033 | DEFERRED_PLANNED | Trust v2 | Original scope preserved. |
| 0034 | DEFERRED_BACKEND_VNEXT | Compatibility Service v2 / role-aware hardening | Cycle 0024 already implements canonical Q28 server/prefs; this slot adds version history, validated role-aware variants, privacy/access, caching/performance and backward-compatible hardening. |
| 0035 | DEFERRED_PLANNED | Compatibility Page + Metric Detail IA | Original scope preserved. |
| 0036 | DEFERRED_RUNTIME_HARDENING | PostgreSQL/runtime hardening for Compatibility + Reports | Execute real migrations and qualify indexes/query plans/concurrency/idempotence/retention/authorization/observability; source schema is not exit evidence. |
| 0037 | DEFERRED_PLANNED | Simulation Engine v2 / release-parity hardening | Extend mandatory backend→routes→simulation→routes→frontend parity across all later modules, mutations, fault states and deterministic fixtures. |
| 0038 | DEFERRED_PLANNED | Longitudinal Outcome Research Layer | Original scope preserved. |
| 0039 | DEFERRED_PLANNED | Fairness, Privacy, Ethics, Explainability | Original scope preserved. |
| 0040 | DEFERRED_PLANNED | Multilingual Controlled Pilot | Original scope preserved. |
| 0041 | DEFERRED_PLANNED | Integrated Investor / Release Candidate | Final gate only after functional/UI/product recovery and independent evidence. |

## Recovery sequencing

### 0023 — Functional Recovery Foundation — current source milestone
- current 100×6 bank remains the active baseline, while Q41 now permits future evidence-led redesign; exact count is not immutable;
- `AssessmentProductEngine` materializes 10 current psychological modules, meaningful per-test result and calendar-month retake policy;
- `PsychologicalProductEngine` materializes aggregate profile, synthesis/analysis and versioned report snapshot;
- `IndependentCompatibilityEngine` implements Q28 independent `PC/IC/VC/CC/LC/PT/EN/NU/AS` + arithmetic mean of selected metrics;
- `AssessmentModuleCompatibilityEngine` exposes each current psychological test module as its own 0–100 pair comparator when data exists;
- existing date-based Numerology is retained and productized as independent `NU=0–100`; fixed-5% semantics are superseded;
- full HTML recovery candidate includes Tests, results, Psychological Profile/Report, Own Profile, People, Candidate and Compatibility Details;
- owner visual acceptance is pending; accepted Compose mirror and CI are not claimed.

### 0024 — Runtime persistence/contracts + full simulation — source milestone
- Psychological Report snapshots/history are persistable/versioned in source;
- server-backed safe Q28 + per-psychological-module pair scores are implemented;
- Q28 selection/model/status provenance is preserved;
- full simulator mirrors the regenerated 87/100/49/21 source contract with 200 deterministic candidates;
- VA/live DB/Compose/CI/E2E remain open.

### 0025–0027 — HTML UI recovery
`0025`: Own Profile → People → Candidate → Compatibility → Tests/Psychology.
`0026`: Chat → Groups → Search Requests.
`0027`: Trust → Hospitality → Services and full integration.
No function is deleted for visual simplification; progressive disclosure moves detail to appropriate surfaces.

### 0028 — acceptance/mirror/qualification
Full HTML owner acceptance → exact accepted Compose mirror → source checks → CI/APK → later live E2E.

## APK/CI rule
CI/APK is a technical qualification gate **after** the relevant HTML UI has been visually accepted and mirrored to Compose. Existing CI logs may be used to fix confirmed compiler defects, but new builds are not an interface design mechanism.

## Numbering / supersession
`BROTHERHOOD_CYCLES_0001_0035.md` and `BROTHERHOOD_ROADMAP_0004_0035.md` are retained as historical predecessor plans. The prior deferred tail `0023–0035` is shifted to `0029–0041` without deleting its outcomes.

## Reserve
`0042–0100 = UNUSED_RESERVE` until owner assignment.
