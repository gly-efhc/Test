# Cycle 0031 — Zodiac Standalone Application vNext

Status: **SOURCE_HTML_IMPLEMENTED / AS_ZODIAC_BASIC_V1 / ROUTE_BACKED_SIMULATION / VA_PENDING**  
Date: 2026-08-13  
Input DEVELOPMENT HEAD: `Brotherhood_v0_5_71.zip`  
Target DEVELOPMENT HEAD: `Brotherhood_v0_5_72.zip`

## Owner objective

Productize `Развитие → Зодиак` as a complete standalone application and determine why `Развитие` still appears inactive in the Android product surface.

## Root-IA diagnosis — why Development is still inactive

The product/CANON root IA is already active and remains exactly:

`Профиль → Люди → Чаты → Группы → Развитие`.

The standalone HTML baseline v45 already implements this fifth root tab and routes `home` to `development`.

The inactive/stale surface is the **Android source mirror**, not the HTML/source CANON. Android still has the pre-Q45 root enum:

`HOME / DISCOVER / MESSAGES / COMMUNITIES / PROFILE`

and still labels `HOME` as `Главная`. There is no Android `Development` root tab/AppRoute yet.

This is not a feature flag or backend failure. It is an intentional HTML-first sequencing consequence: cycles 0024–0030 remain `VA=PENDING`, so the accepted HTML root IA has not yet been mirrored into Compose. Cycle 0031 does **not** bypass that owner gate. Android source remains unchanged until explicit visual acceptance.

## Active Zodiac methodology boundary

Active method: `AS_ZODIAC_BASIC_V1`.

Versioned contracts:

- personal reading: `zodiac-basic-reading-v1`;
- catalog: `zodiac-basic-catalog-v1`;
- pair compatibility: `zodiac-runtime-v1`;
- Q28 metric: independent `AS 0–100%`.

The current method is deliberately limited to:

`birth date → basic Zodiac sign → existing sign/group relation → AS score`.

The following are **not active** in 0031 and are not invented from model memory:

- natal chart;
- houses;
- aspects;
- Moon sign;
- Ascendant;
- synastry;
- `AS_SYNASTRY_V1`.

`AS_SYNASTRY_V1` remains a future method requiring its own exact methodology, astronomical input/provenance contract, privacy review and release approval.

The active source boundary includes `ASTRO-001` negative controlled evidence. Therefore Zodiac/AS is labeled traditional/alternative and opt-in; it is not psychological or psychometric evidence and is not a probability of friendship/relationship success.

## Basic sign contract

The existing Brotherhood ZodiacEngine month/day boundaries are retained unchanged for all 12 signs. Cycle 0031 moves the existing v1 characteristics from frontend-only copy into a server-authoritative catalog contract and attaches:

- sign id;
- localized sign label;
- symbol;
- start/end month-day boundary;
- year-wrap marker for Capricorn;
- existing four-group metadata (`FIRE / EARTH / AIR / WATER`);
- existing v1 characteristics;
- explicit evidence/product-copy status.

No new personality claims are inferred from Zodiac.

## Independent AS pair compatibility

Cycle 0031 preserves the existing Q28/Android Zodiac score exactly:

- same sign — `86`;
- same existing element/group — `90`;
- existing supported cross-group pair (`FIRE↔AIR`, `EARTH↔WATER`) — `84`;
- all other supported sign pairs — `66`.

The standalone Zodiac scorer and Q28 AS scorer now share the same backend scoring function. Exhaustive regression verifies parity for all **144 ordered sign pairs**.

AS remains independent from:

- psychological `PC` and its internal systems;
- `NU`;
- `EN`;
- Trust;
- Account Rating;
- Hospitality Reputation;
- Quality Fit.

Selected Overall remains the arithmetic mean of selected available Q28 systems; no hidden cross-model weight is introduced.

## Persistence / DB

Migration:

`database/migrations/0016_zodiac_vnext.sql`

Adds only:

- `zodiac_readings`;
- `zodiac_pair_comparisons`.

Personal readings are immutable/versioned and identical fixed input+version is idempotent under the existing project persistence pattern. Pair history freezes both sign snapshots and relation/scoring provenance so a saved comparison can be reread later.

Persistence schema becomes **16**.

## Public Zodiac API

1. `GET /v1/zodiac/spec`
2. `GET /v1/zodiac/catalog/{locale}`
3. `GET /v1/zodiac/catalog/{locale}/{sign_id}`
4. `POST /v1/zodiac/readings`
5. `GET /v1/zodiac/readings/{global_id}`
6. `GET /v1/zodiac/readings/{global_id}/latest`
7. `GET /v1/zodiac/readings/{global_id}/{reading_id}`
8. `POST /v1/zodiac/compatibility`
9. `GET /v1/zodiac/compatibility/{global_id}/history`

## HTML / Simulation

Active standalone acceptance candidate: `BROTHERHOOD_UI_SIMULATOR_v0_5_46.html`.

`Развитие → Зодиак` now exposes the standalone flow:

- Zodiac home / create-update reading;
- **Профиль** — saved birth date, sign, group, boundaries and characteristics;
- **Как считается** — transparent sign boundary and four compatibility rules plus scientific/traditional boundary;
- **12 знаков** — route-backed catalog and sign detail pages;
- **История** — immutable reading history and reread;
- **Сравнение** — selected person, independent AS `0–100%`, frozen pair sign details/relation and saved comparison history/reread.

The Development home card now reads latest Numerology and Zodiac summaries through their backend routes instead of calculating a second Zodiac business answer in the frontend.

All new Zodiac UI data follows:

`domain/DB → routes → BackendSimulator → SimulationEngine → route responses → frontend`.

Current source/simulation contract:

- **126 OpenAPI paths**;
- **145 HTTP operations**;
- **56 migration-defined DB tables**;
- **21 Android AppRoutes**;
- **200 deterministic synthetic candidates**;
- persistence schema **16**.

Local SimulationEngine route probe: **145/145 PASS / 0 failures / 56 tables**.

## Verification state

Completed before the final package/file-map gate:

- Operator Kernel `validate-config`: **PASS — 16 routes / 8 hooks / 6 agents / 6 skills**;
- cycle ecosystem: **PASS**, current through cycle 0031 with next gate 0032;
- JSON validation: **127/127 PASS**;
- full backend regression: **107/107 PASS**;
- full architecture/current-product regression: **278/278 PASS**;
- focused Zodiac/Numerology/Q28/0029 guards: **38/38 PASS**;
- new Zodiac backend suite: **8/8 PASS**;
- exhaustive standalone/Q28 AS parity: **144/144 ordered sign pairs covered** inside the Zodiac suite;
- HTML parser: **PASS**; JavaScript syntax: **2/2 PASS**; external asset references: **0**;
- source contract generated: **126 / 145 / 56 / 21**;
- nine new Zodiac runtime operations: **9/9 PASS**;
- standalone persistence reload: **PASS**, schema16 readings and pair history retained;
- complete SimulationEngine route probe: **145/145 PASS / 0 failures / 56 tables**;
- adversarial probe: invalid date `422`, unknown sign `404`, inactive future synastry route `404`;
- active HTML copies synchronized byte-for-byte;
- Android source delta versus v71: **0 added / 0 changed / 0 removed**.

Deterministic archive/CRC/file-map/security verification is performed only after the final `refresh-map`, without mutating the source tree afterward.

## Stage state

- R: PASS
- S: PASS
- B: PASS
- H: PASS
- VA: **PENDING**
- A: NOT_STARTED_BY_DESIGN
- CI: NOT_RUN
- E2E: NOT_RUN

## Explicitly not claimed

- owner visual acceptance: PENDING;
- Android root-IA/Compose mirror: NOT_STARTED_BY_DESIGN;
- APK/AAB as a visual acceptance mechanism: NOT_RUN;
- GitHub CI/APK/device: NOT_RUN;
- live PostgreSQL migration `0016`: NOT_RUN;
- live/device E2E: NOT_RUN.

## Next after owner acceptance/corrections

`0032 — Enneagram standalone optional application`.
