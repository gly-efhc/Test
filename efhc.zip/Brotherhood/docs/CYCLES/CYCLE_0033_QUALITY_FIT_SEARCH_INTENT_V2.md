# Cycle 0033 — Quality Fit / SearchIntent v2 + Stable Service UX

Status: **SOURCE_HTML_IMPLEMENTED / QUALITY_FIT_SEARCH_INTENT_V2 / STABLE_SERVICE_UX / CHROMIUM_E2E_PASS / VA_PENDING**  
Date: 2026-08-16  
Input DEVELOPMENT HEAD: `Brotherhood_v0_5_74.zip`  
Target DEVELOPMENT HEAD: `Brotherhood_v0_5_75.zip`  
Target standalone HTML: `BROTHERHOOD_UI_SIMULATOR_v0_5_49.html`

## Owner objectives

1. Finish cycle 0033 Quality Fit / SearchIntent v2.
2. Make every seeded Development test immediately repeatable in the Simulator.
3. Diagnose and eliminate the recurrent page jumping/ejection while a user is reading.
4. Replace the noisy/childish Development and Tests presentation with a calmer service-oriented UX informed by Diia and comparable public-service/mobile guidance.
5. Make test execution pleasant and results worth reading without inventing new psychological claims.

## Retake correction

The old demo seeded the 12 saved test results only 1–12 days in the past while the product uses a calendar-month retake rule. Consequently some/all seeded tests were still locked.

Cycle 0033 seeds the 12 demo completions `78 + 3*n` days in the past. The production retake rule is not weakened; only demo evidence dates are changed. Chromium verifies that the Tests catalog exposes **12/12 `Повторить`** actions and that a seeded 20-question test can actually be completed and saved again.

## Page-jump root cause and fix

Root cause in the Simulator:
- `SimulationEngine.tick()` advanced every second;
- every 5 seconds the engine emitted `engine_tick`;
- the global subscriber performed a full `render()`;
- `renderScreen()` reset `#appViewport.scrollTop` to zero;
- incoming-message events could also trigger a full rerender.

Therefore a person reading a long result could be thrown to the top without any user navigation.

Cycle 0033 changes the render contract:
- background tick updates/persists state without full current-screen rerender;
- non-current incoming messages update nav/workbench only;
- same-route state updates preserve scroll, active control value, selection and focus;
- scroll resets only on an actual route change/back where a new screen is intended;
- browser runtime verification is a mandatory cycle gate.

Chromium evidence:
- scroll after background tick: `500 → 500`;
- scroll after forced incoming message: `500 → 500`;
- People search value/focus survives background tick;
- no page errors / no console errors.

## Service UX redesign

Authority class: `PRODUCT_DONOR / UX_VISUAL`, never scientific scoring authority.

Research record: `docs/research/product/DEVELOPMENT_SERVICE_UX_DONORS_V1.md`.

Adopted patterns:
- stable five-tab root navigation;
- service catalog instead of noisy decorative card grid;
- concise service row: icon → name/benefit → current state → next action;
- fewer badges, pills and ornamental boxes;
- stronger typographic hierarchy and whitespace;
- one question per test screen with clear progress and four large answer choices;
- result is a readable report first; methodology/provenance remains secondary;
- actions/status are visible without searching through the page.

Development now presents current modules as service rows. Tests explicitly show old completion date and `Повторить`. Test results now expose a readable sequence: result, interpretation, observed characteristics, contribution to the overall profile, next observations, history and retake.

## Quality Fit / SearchIntent v2

Versioned contracts:
- SearchIntent: `quality-fit-search-intent-v2`;
- catalog: `quality-fit-catalog-v2`;
- scoring: `quality-fit-directional-v2`.

Direction: `SEARCHER_A_TO_CANDIDATE_B`.

Rules:
- only requirements explicitly selected by the searching user participate;
- role labels do not silently inject required personality qualities;
- hard requirements and preferences remain distinct;
- missing candidate evidence is `INSUFFICIENT_DATA`, never zero;
- hard requirement failure affects eligibility and is not hidden inside an averaged score;
- QF is not a Q28 Compatibility metric and does not change PC/IC/VC/CC/LC/PT/EN/NU/AS, Trust, Account Rating or Hospitality Reputation;
- explanations never expose raw hidden latent coordinates.

The existing 112-entry Quality Fit catalog remains the mapping authority. Cycle 0033 does not invent new trait weights.

## Backend/API/DB

New endpoints:
- `GET /v1/quality-fit/spec`;
- `GET /v1/quality-fit/catalog/{locale}`;
- `POST /v1/quality-fit/evaluations`;
- `GET /v1/quality-fit/evaluations/{global_id}`;
- `GET /v1/quality-fit/evaluations/{global_id}/{evaluation_id}`.

Migration `0018_quality_fit_search_intent_v2.sql`:
- extends `search_requests` with structured requirements + version;
- adds only `quality_fit_evaluations`.

Evaluations are versioned and idempotent for the same frozen intent/evidence/scoring version.

## Current source contract

- 141 OpenAPI paths;
- 160 HTTP operations;
- 59 DB tables;
- 21 Android AppRoutes;
- 200 deterministic synthetic candidates;
- persistence schema 18.

SimulationEngine full operation probe: **160/160 PASS / 0 failures**.

## Browser runtime gate

`scripts/check_cycle0033_html_runtime.py` is added because parser/`node --check` cannot prove real interaction behavior.

It verifies in real Chromium:
- page and console errors = 0;
- Development → Tests opens;
- 12/12 saved tests are repeatable;
- scroll remains stable through tick and incoming-message events;
- a seeded test is completed to `Ваш результат`;
- input value/focus survive background tick;
- candidate → Quality Fit opens;
- embedded route probe reports `160/160 fail:0`.

## Android boundary

Android source remains unchanged in cycle 0033. Compose/APK is not used for owner visual acceptance. The standalone HTML is the current visual candidate.

## Visual acceptance

Owner VA remains **PENDING**. Do not mark `VA=PASS` until explicit owner acceptance.

## Next cycle

`0034 — Unified Multi-method Compatibility Service + persistence` after cycle 0033 owner corrections/package gate.
