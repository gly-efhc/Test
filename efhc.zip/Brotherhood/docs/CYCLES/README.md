# Brotherhood CYCLES

## Current authority

- Parent/outcome plan: `BROTHERHOOD_CYCLES_0024_0100.md` + `BROTHERHOOD_ROADMAP_0024_0100.md`.
- Active execution decomposition: `BROTHERHOOD_CYCLES_0101_0200.md` + `BROTHERHOOD_ROADMAP_0101_0200.md`.
- Assigned executable microcycles: `0101–0150` (50).
- Owner reserve: `0151–0200` (50).
- Last implemented product cycle: `0034`.
- Next planning item: `0111 — Questionnaire Bank Inventory Freeze v1.3`.

## Governing rule

One executable cycle = one narrow verifiable goal + one deterministic DEVELOPMENT package. Parent outcomes `0034–0100` are not directly executable after the owner decomposition of 2026-08-16.

If a neighboring defect is found during a cycle, record it for another microcycle instead of expanding the current patch.
