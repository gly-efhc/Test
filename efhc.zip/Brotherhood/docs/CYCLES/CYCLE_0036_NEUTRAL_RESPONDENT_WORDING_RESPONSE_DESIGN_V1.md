# Cycle 0036 — Neutral Respondent Wording & Response Design v1

Status: **SOURCE/HTML IMPLEMENTED · LOCAL REGRESSION PASS · CHROMIUM PASS · OWNER VA PENDING**  
Date: 2026-08-17

## Цель
Снизить очевидность измеряемого полюса для респондента, не меняя scientific scoring semantics и не ослабляя Secure Test Administration Runtime.

## Вход
- `scientific-questionnaire-bank-v1.2` и immutable inventory 0111 как историческая контрольная точка состава 197 items;
- secure administration 0034;
- human-readable result feedback 0035;
- active Source SSOT/CANON.

## Реализованный результат
- новый active wording successor: `scientific-questionnaire-bank-v1.3`;
- instrument: `text-situational-neutral-v1`; scoring остаётся `scientific-questionnaire-v1`;
- **180 situational items** получили respondent-neutral behavioral A/B wording без публичных названий внутренних полюсов;
- **17 `DIRECT_PUBLIC_DOMAIN` anchors** остаются отдельным классом и не маскируются под forced-choice;
- A/B сторона situational item определяется из уже сохранённого opaque item token и поэтому случайна между сессиями и стабильна при resume;
- при BA presentation сервер делает обратное отображение `canonical_answer = 5 - presented_answer`, поэтому существующее scoring meaning не меняется;
- `comprehension_flag` сохраняется в `response_meta` вместе с `wording_version` и `side_order`;
- публичный item contract остаётся только `item_token/prompt/answer_labels/position/total`; construct, polarity, keys и полный банк наружу не возвращаются.

## Persistence/API
Новая DB migration не требуется: metadata помещается в существующий `response_meta` JSON. Количество OpenAPI paths/operations и таблиц не увеличивается.

## Standalone HTML
Active candidate: `BROTHERHOOD_UI_SIMULATOR_v0_5_52.html`. Он зеркалирует neutral wording, stable A/B resume, comprehension flag и server-authoritative canonical answer mapping. Owner visual acceptance остаётся `PENDING`; Android mirror в этом цикле не выполнялся по HTML-first CANON.

## Научная граница
Cycle 0036 является wording/response-design изменением. Он **не доказывает** reliability, factor validity, measurement invariance, DIF/fairness validity, diagnostic validity или устойчивость к deliberate impression management. Behavioral desirability review — проектная проверка формулировок, не эмпирическая валидация шкалы.

## Не изменялось
Construct definitions, scoring weights/directions, polarity, psychometric validation, retake policy, Associations, Compatibility, Trust, Quality Fit, Android runtime. Historical 0111 inventory snapshot не переписывался.

## Следующий цикл
`0037 — Retake, Alternate Order & Practice-Effect Runtime`.

CI: NOT_RUN_BY_OWNER_ORDER
