# Brotherhood — полный план циклов 0001–0100

Status: **PARENT LONG-RANGE LEDGER — direct execution decomposed into 0101–0150**

## ACTIVE PROGRAM UPDATE — 2026-08-16 / owner single-module replan
- Current detailed assigned cycles: `docs/CYCLES/BROTHERHOOD_CYCLES_0024_0100.md`.
- Current detailed roadmap: `docs/CYCLES/BROTHERHOOD_ROADMAP_0024_0100.md`.
- Implemented evidence `0024–0033` remains unchanged.
- Planned semantics `0034–0073` from the former roadmap are superseded before implementation.
- `0034–0100` remain assigned as parent outcomes, but direct implementation is superseded by execution microcycles `0101–0150`.
- Owner rule now strengthened: **one executable microcycle = one narrow verifiable objective + one package**.
- Immediate next planning item: `0111 — Questionnaire Bank Inventory Freeze v1.3`.

## Главный принцип
Один цикл = один законченный продуктовый, исследовательский или инфраструктурный модуль с собственным exit gate. Нельзя «заодно» переделывать соседние психологические системы, социальные функции или scoring layers. Каждый модуль проходит source/method contract → backend/DB → routes → SimulationEngine → mobile HTML → real Chromium E2E → regression → deterministic package.

> **CURRENT AUTHORITY:** parent outcomes — `BROTHERHOOD_CYCLES_0024_0100.md`; execution — `BROTHERHOOD_CYCLES_0101_0200.md`. Older tables below are predecessor/history only.

## Текущий статус
- Последний source/HTML implemented cycle: `0033`.
- Следующий planning item: `0111 Questionnaire Bank Inventory Freeze v1.3`.
- Parent outcomes remain assigned through `0100`; executable microcycles are assigned through `0150`; `0151–0200` is owner reserve.
- Former `0074–0100 reserve` designation is superseded by owner instruction dated 2026-08-16.

## Назначенные циклы 0001–0030
| Cycle | Status | Major result | Scope summary | APK gate |
|---|---|---|---|---|
| 0001 | COMPLETED | Фундамент, аудит и управление проектом | Source stabilization, workflow, AI/KERNEL/MEMORY/HANDOFF/guards. | — |
| 0002 | CHECKPOINT_PENDING | Полностью видимый Android UX | Positive test result UX, localization, adaptive UI; source milestone, APK/device acceptance pending. | APK CHECKPOINT A |
| 0003 | ACTIVE | Real backend / PostgreSQL / auth / sync | FastAPI, PostgreSQL, sessions/providers, global_id ownership, live E2E remains pending. | — |
| 0004 | PLANNED | Compatibility Research Registry & governance | Source-to-claim, evidence states, metric contracts, research Kernel route. | — |
| 0005 | PLANNED | Psychological construct architecture | Big Five/IPIP, HEXACO candidates, IPC, relational constructs, licensing/translation map. | — |
| 0006 | PLANNED | Visual stimulus scientific redesign | Audit 600 tasks, confounds, asset/stimulus manifest, KEEP/REWORK/CONTROL/REJECT. | Conditional |
| 0007 | PLANNED | Reference calibration protocol | Reference batteries, consent/cohorts, RU/UK/EN equivalence, power/precision. | — |
| 0008 | PLANNED | Pilot instrumentation & data quality | Stimulus/position/latency/render logs, bias/missingness/device QA. | Conditional |
| 0009 | PLANNED | Psychometric calibration v1 | Measurement model candidates, test-retest, construct validity, locked holdout. | — |
| 0010 | PLANNED | Psychological Compatibility Engine v1 | Role-aware similarity/complementarity/asymmetry/conditional pair model. | Conditional |
| 0011 | PLANNED | Friend Compatibility outcome model | Exposure, reciprocity, relationship quality, 30/90/180-day outcomes. | — |
| 0012 | PLANNED | Interests Compatibility | Social/hobby + vocational interest model and baselines. | — |
| 0013 | PLANNED | Values Compatibility | Schwartz/circular value research, pair conflict/alignment model. | — |
| 0014 | PLANNED | Communication Compatibility | Disclosure/responsiveness, autonomy, agency/communion, conflict/repair. | — |
| 0015 | PLANNED | Lifestyle Compatibility | Hard constraints + soft preferences + sensitive-data policy. | — |
| 0016 | PLANNED | Brotherhood Personality Type | Soft empirical type memberships; no hard dichotomy boxes. | — |
| 0017 | PLANNED | Enneagram Compatibility | Evidence-aware optional typological engine. | — |
| 0018 | PLANNED | Numerology Compatibility | Versioned deterministic traditional methodology. | — |
| 0019 | PLANNED | Astrology/Zodiac Compatibility | Basic zodiac / future synastry separated and evidence-labeled. | — |
| 0020 | PLANNED | Quality Fit v2 | Directional search-request fit by role/qualities/requirements. | Conditional |
| 0021 | PLANNED | Trust + Data Coverage | Operational trust, appeals, per-metric coverage/recency. | — |
| 0022 | PLANNED | Compatibility data/API platform | Metric/model registries, score history, preferences, manifests, auditability. | — |
| 0023 | PLANNED | Compatibility service UI — Diia model | Role selector, metric checkboxes, detail pages, Overall arithmetic mean, QF/TR separate. | APK CHECKPOINT B |
| 0024 | PLANNED | Person resume/profile — early VK depth | Serious resume profile, skills/interests/goals/groups, privacy-safe compatibility entry. | Conditional |
| 0025 | PLANNED | Discovery / Search Requests | Role requests, filters, recommended cards/swipes only in discovery, direct message. | APK CHECKPOINT C |
| 0026 | PLANNED | Telegram-class communication | Direct/group chats, delivery/retry, reply/reactions/edit/delete, attachments/security. | APK CHECKPOINT D |
| 0027 | PLANNED | Communities / business club | Local/interest/business/project/mutual-aid groups, roles, events, moderation. | — |
| 0028 | PLANNED | Longitudinal outcome platform | Exposure chain, 30/90/180-day outcomes, consented research exports. | — |
| 0029 | PLANNED | Validation / fairness / replication | Locked holdout, language/subgroup checks, baselines, replication, rollback. | Conditional |
| 0030 | PLANNED | Full investor simulation + production RC | Full release-parity backend/tables/routes/metrics/UI simulation, security/privacy/device/RC gates. | APK/AAB FINAL CHECKPOINT E |

## Подробный план 0004–0030
Полный scope, required artifacts, exit gates и regression boundaries: `docs/CYCLES/BROTHERHOOD_ROADMAP_0004_0030.md`.

## Фазы
1. `0004–0009`: scientific foundation & measurement.
2. `0010–0019`: independent compatibility engines.
3. `0020–0022`: Quality Fit / Trust / data platform.
4. `0023–0027`: VK + Telegram + Diia product integration.
5. `0028–0029`: longitudinal validation / fairness / replication.
6. `0030`: full release-parity investor simulation + production RC.

## APK checkpoints
- `0002`: **APK CHECKPOINT A** — pending historical checkpoint.
- `0023`: **APK CHECKPOINT B** — Compatibility service UI.
- `0025`: **APK CHECKPOINT C** — Discovery/Search.
- `0026`: **APK CHECKPOINT D** — communication.
- `0030`: **APK/AAB FINAL CHECKPOINT E** — RC/final.
- Research/model-only cycles do not force APK unless Android renderer/data capture changes or owner explicitly requests it.

## Historical reserve marker (SUPERSEDED 2026-08-16)
Former plan: `0074–0100 = UNUSED_RESERVE`. Owner has now explicitly assigned `0034–0100`; this marker is history only.


### Cycle 0016 completion note
Communication Compatibility now has an independent research-only v1 architecture with pre-exposure input/construct/pair-feature registries, transparent `CC-R0`, role/directional/nonlinear challengers, explicit missingness/coverage, 13-locale validation and exposure-time longitudinal outcome provenance. Post-contact actual reply latency, reciprocity, conflict and repair remain process/outcome evidence and cannot leak backward into historical CC predictors. Scientific registry `162->172`; claim ledger `111->123`; original owner-authorized source snapshot remains exactly 60. Android/backend/database/protected 100x6 and production scoring remain unchanged. Next: `0017 — Lifestyle Compatibility Engine`.


## Hospitality roadmap insertion — cycle 0019
The owner reassigned 0019–0022 to Hospitality and later inserted Product Recovery 0023–0028. On 2026-08-16 the active future program was re-sequenced through cycle 0100 under the one-cycle-one-module rule. Canonical current table: `BROTHERHOOD_CYCLES_0024_0100.md`; older tables remain predecessor/history.


### Cycle 0020 completion note
Active replacement roadmap records `0020 — Hospitality Foundation + Backend Lifecycle` as COMPLETED and `0021 — Hospitality Verified Stay / Reviews / Trust + Android UX` as NEXT_PLANNED. Backend/database Hospitality implementation is present behind a fail-closed feature flag; protected `100×6` and Android are unchanged. Real PostgreSQL migration execution and external runtime gates remain unclaimed.
