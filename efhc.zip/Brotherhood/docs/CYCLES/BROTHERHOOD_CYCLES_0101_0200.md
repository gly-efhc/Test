# Brotherhood — execution decomposition/reference 0101–0200

> **OWNER SEQUENTIAL-ORDER OVERRIDE — 2026-08-17:** this ledger is no longer the active execution authority. Active work proceeds by ascending parent cycle IDs in 0024–0100; next executable cycle is `0037`. `0101–0110` remain satisfied/reference decomposition of implemented 0034. `0111` remains a completed out-of-order historical artifact. `0112–0150` remain planning/decomposition reference only and must not execute unless the owner explicitly reactivates this numbering. `0151–0200` remains reserve/reference.

Status: **REFERENCE / DECOMPOSITION — NOT ACTIVE EXECUTION AUTHORITY**

## 1. Исполнительная модель

- Parent cycles `0034`–`0036` are implemented; active execution now continues with `0037` and then ascending parent IDs.
- The `0034–0100` parent ledger is again the **active executable sequence** under the 2026-08-17 owner override.
- `0101–0110` remain satisfied/reference decomposition of 0034. Cycle **0111 — Questionnaire Bank Inventory Freeze v1.3** remains valid completed out-of-order evidence.
- `0112–0150` are retained as **planning/decomposition reference**, not active execution cycles. Their scope may inform a parent cycle only when the owner explicitly maps it.
- `0151–0200` remains **OWNER RESERVE / REFERENCE**.
- No reference microcycle may override the ascending parent-cycle route without a later direct owner instruction.

## 2. Жёсткие ограничения размера цикла

Каждый `0101–0150` обязан соблюдать все условия одновременно:

1. **Одна цель.** Нельзя «заодно» реализовать соседний пункт.
2. **Один основной слой изменения.** Если цикл backend-security — он не переписывает UX/науку; если UX — он не меняет scoring.
3. **Минимальная DB mutation.** Новая таблица/миграция только если без неё невозможно выполнить одну цель цикла.
4. **Никаких скрытых algorithm changes.** Новая формула = отдельная version и отдельный цикл.
5. **Отдельный негативный тест.** Каждый security/scientific boundary должен иметь тест, доказывающий, что запрещённый путь действительно закрыт.
6. **Директорский выход.** В конце: что изменилось для продукта, какой риск закрыт, фактический PASS/FAIL, что специально не делалось.
7. **Package gate обязателен для каждого закрытого цикла.** Нельзя накапливать несколько незапакованных циклов.
8. **Если во время цикла найден соседний дефект — не чинить его молча.** Записать в следующий свободный microcycle/reserve или отдельный owner-approved hotfix.

## 3. Связь с родительским планом 0034–0100

`0034–0100` теперь являются картой крупных результатов. Этот файл является **исполнительной декомпозицией** тех частей, которые ранее оказались слишком широкими. Нумерация 0101+ выбрана владельцем намеренно, чтобы не переписывать исторические идентификаторы 0034–0100.

## Фаза A — Безопасность тестовой администрации (0101–0110)

### 0101 — Public Test Catalog Redaction v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Закрыть первую и самую простую утечку: обычный клиент не должен получать полный банк заданий, construct mapping, polarity или scoring metadata через каталог/definition API.

**Точный scope:**
- Убрать respondent-internal поля из public catalog/definition DTO.
- Оставить только название приложения, назначение, ориентировочную длительность, статус доступности, историю/retake metadata, но не секреты измерения.
- Ввести отдельный private server DTO для внутреннего банка; public и private схемы не должны быть одним объектом с фильтрацией на UI.
- Добавить негативные API-тесты: `items`, `construct_ids`, `polarity`, `scoring_key`, `source_claim_ids` отсутствуют в публичном ответе.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `public_catalog_request_count`
- `redacted_field_guard_pass`
- `definition_response_size_bytes`

**Definition of Done:** Public API 12/12 test-apps не раскрывает ни одного поля банка/ключей; старый клиент получает совместимый безопасный metadata-response.

**Запрещено в этом цикле:** Не создавать sessions, не менять scoring, не менять формулировки вопросов, не трогать retake.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0102 — Test Session Creation & Ownership v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Создать только серверную сущность тестовой сессии и её владение пользователем.

**Точный scope:**
- POST start создаёт opaque session token/ID, фиксирует owner/global_id, test_app_id, instrument_version и состояние STARTED.
- Сессия не содержит public item bank в ответе.
- Повторный start при активной сессии работает по однозначному contract: resume-existing либо explicit new-attempt.
- Добавить минимальную persistence migration только для session header, без ответов/score.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `sessions_started`
- `duplicate_start_count`
- `owner_mismatch_denied`

**Definition of Done:** Можно создать и прочитать только свою активную session header; чужая session недоступна; никаких вопросов ещё не выдаётся.

**Запрещено в этом цикле:** Не выдавать item, не сохранять ответ, не рассчитывать результат.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0103 — Single-Item Presentation Contract v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Выдавать из приватного банка ровно один текущий respondent-facing item на активную session.

**Точный scope:**
- GET/POST next-item возвращает только respondent text и opaque presentation token.
- Не возвращать canonical item_id, construct, polarity, source IDs, correct/preferred side или будущие items.
- Presentation сохраняет ordinal и server presented_at.
- До ответа нельзя запросить следующий item или список оставшихся заданий.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `items_presented`
- `preview_attempt_denied`
- `presentation_latency_server_ms`

**Definition of Done:** В Chromium/API одновременно доступен только один вопрос; попытка предварительного просмотра банка блокируется.

**Запрещено в этом цикле:** Не принимать ответы и не выполнять scoring.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0104 — Immutable Response Submission v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Добавить только приём одного ответа на выданный presentation token.

**Точный scope:**
- Ответ привязывается к конкретной presentation записи.
- Повторная отправка того же ответа идемпотентна; изменение уже принятого ответа после фиксации запрещено.
- Сохранять response_at и response_latency_ms из server timestamps, client timing только как дополнительное поле.
- После принятия состояние presentation становится ANSWERED.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `responses_accepted`
- `duplicate_idempotent`
- `response_mutation_denied`
- `response_latency_ms`

**Definition of Done:** Один presentation → один неизменяемый ответ; невозможно переписать предыдущий ответ через обычный API.

**Запрещено в этом цикле:** Не выдавать следующий item автоматически; не считать итог.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0105 — Session Sequential Progression v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Соединить presentation и response в строгую последовательность «ответил → можно получить следующий».

**Точный scope:**
- State machine STARTED/IN_PROGRESS/READY_TO_COMPLETE.
- Ordinal растёт только после accepted response.
- Нельзя пропустить ordinal, отправить ответ на будущий token или завершить с пропусками.
- Количество answered/remaining можно показывать без раскрытия структуры банка.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `answered_count`
- `remaining_count`
- `out_of_order_denied`

**Definition of Done:** 12 тестов можно пройти от первого до последнего вопроса последовательно без раскрытия будущих items.

**Запрещено в этом цикле:** Не добавлять resume и scoring finalization.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0106 — Session Resume & Recovery v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Сделать безопасное продолжение прерванного теста.

**Точный scope:**
- После reload/reopen сервер возвращает только session status и текущий незавершённый presentation либо создаёт следующий по state machine.
- Не выдавать уже отвеченные тексты/ключи списком, если это не нужно пользователю.
- Фиксировать interruption_count и last_activity_at.
- Добавить expiry policy contract без реализации сложных retention правил.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `resume_count`
- `interruption_count`
- `resume_success_rate`

**Definition of Done:** Chromium: начать тест → выйти → открыть снова → продолжить с правильного места; ответы не теряются и не редактируются.

**Запрещено в этом цикле:** Не считать итог и не менять retake.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0107 — Server-Authoritative Test Finalization v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Добавить отдельный финальный серверный переход после ответа на последний item.

**Точный scope:**
- Finalize разрешён только READY_TO_COMPLETE.
- Scoring читает private bank + persisted responses; клиент не передаёт готовые scores.
- Результат сохраняется immutable с instrument/scoring version и response fingerprint.
- Повторный finalize идемпотентен и возвращает тот же result ID.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `finalizations`
- `idempotent_finalizations`
- `scoring_version`
- `response_fingerprint`

**Definition of Done:** Полный результат невозможно создать без завершённой server session; одинаковая session даёт один immutable result.

**Запрещено в этом цикле:** Не выключать legacy endpoints — это следующий цикл.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0108 — Legacy Direct-Score Shutdown v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Закрыть старые обходные пути, позволяющие клиенту прислать ответы/готовый результат без secure session.

**Точный scope:**
- Legacy `/score` и прямой client result write получают explicit deprecated/410 contract либо internal-only auth.
- Frontend/Simulator не используют legacy scoring.
- Добавить negative tests на подмену result payload.
- Документировать migration path для старого клиента.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `legacy_score_calls_denied`
- `direct_result_write_denied`

**Definition of Done:** Ни один public route не создаёт Psychological Test Result вне secure finalized session.

**Запрещено в этом цикле:** Не удалять route исторически без compatibility contract; не трогать item wording.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0109 — Deterministic Private Item Order v1

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Добавить приватный воспроизводимый порядок items без возможности предсказать его на клиенте.

**Точный scope:**
- Server создаёт private order_seed и frozen item order при старте.
- Seed не возвращается публично.
- Одинаковая сохранённая session воспроизводит order после restart.
- Ввести policy против фиксированного одинакового порядка для всех пользователей.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `order_seed_version`
- `order_collision_rate`
- `resume_order_parity`

**Definition of Done:** Persistence reload подтверждает тот же private порядок; клиент видит только текущий ordinal/total.

**Запрещено в этом цикле:** Не внедрять desirability balancing/A-B side randomization — научный цикл позже.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0110 — Secure Test Administration Chromium Acceptance

**Родительская цель:** `0034 Secure Test Administration`.

**Единственная цель цикла.** Только интеграционная приёмка уже реализованных 0101–0109 без добавления новой функциональности.

**Точный scope:**
- Пройти 12/12 apps в реальном Chromium.
- Проверить reload/resume, чужую session, preview attempt, replay response, legacy score bypass.
- Проверить 0 page/console errors и route parity.
- Зафиксировать директорский security evidence report.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `apps_e2e_pass`
- `browser_errors`
- `security_negative_cases_pass`

**Definition of Done:** 12/12 secure lifecycle PASS; все отрицательные сценарии PASS; package gate чистый.

**Запрещено в этом цикле:** Запрещены новые features. Любой найденный функциональный дефект возвращается в отдельный microcycle.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

## Фаза B — Научный аудит банка и нейтральные формулировки (0111–0120)

### 0111 — Questionnaire Bank Inventory Freeze v1.3

**Родительская цель:** `0035 Questionnaire Scientific Audit`.

**Единственная цель цикла.** Создать неизменяемый инвентарь всех 197 активных items перед научной ревизией.

**Точный scope:**
- Зафиксировать item ID/version/test-app/system/construct/source linkage без изменения scoring.
- Проверить 197/197 cardinality и отсутствие orphan items.
- Сформировать audit ledger с полями status/reviewer/evidence.
- Старый v1.2 сохраняется read-only.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `items_total`
- `orphan_items`
- `duplicate_ids`

**Definition of Done:** 197/197 items имеют audit row; никаких научных исправлений ещё не внесено.

**Запрещено в этом цикле:** Не менять polarity, wording или weights.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0112 — Questionnaire Source Trace Completeness Audit

**Родительская цель:** `0035 Questionnaire Scientific Audit`.

**Единственная цель цикла.** Проверить только трассировку item → construct → scientific source/claim.

**Точный scope:**
- Для каждого item проверить существование source claim и authority class.
- Отделить scientific authority от UX/technical donors.
- Пометить items с недостаточной трассировкой как EVIDENCE_GAP.
- Не заменять источник догадкой модели.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `source_trace_complete`
- `evidence_gap_count`
- `wrong_authority_class_count`

**Definition of Done:** 197/197 имеют однозначный source-trace status; список gaps оформлен отдельно.

**Запрещено в этом цикле:** Не переписывать item и не менять scoring.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0113 — Polarity & Reverse-Key Audit

**Родительская цель:** `0035 Questionnaire Scientific Audit`.

**Единственная цель цикла.** Проверить только математическое направление каждого item относительно заявленного construct.

**Точный scope:**
- Сопоставить high/low pole, reverse_key и итоговую нормализацию.
- Программно найти конфликтующие orientations внутри одного construct.
- Каждая аномалия требует evidence note.
- Не менять текст пользователя.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `polarity_checked`
- `orientation_conflicts`
- `reverse_key_conflicts`

**Definition of Done:** Все 197 items имеют проверенный intended polarity; список доказуемых дефектов закрыт или явно pending.

**Запрещено в этом цикле:** Не менять формулировки и factor structure.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0114 — Stress Tolerance Scoring Correction v1.3

**Родительская цель:** `0035 Questionnaire Scientific Audit`.

**Единственная цель цикла.** Исправить только уже доказанную orientation-ошибку stress_tolerance отдельной versioned scoring revision.

**Точный scope:**
- Изменить только конкретные ошибочные ключи, подтверждённые 0113.
- Новая версия scoring/bank; старые результаты сохраняют старую provenance.
- Regression доказывает отсутствие изменений других constructs.
- Документировать expected score delta на synthetic fixtures.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `corrected_items_count`
- `non_target_construct_delta`
- `version_migration_count`

**Definition of Done:** Только доказанные stress_tolerance items меняют направление; остальные score fixtures byte/semantic parity.

**Запрещено в этом цикле:** Не использовать цикл для иных «заодно замеченных» ошибок.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0115 — Duplicate & Redundancy Audit

**Родительская цель:** `0035 Questionnaire Scientific Audit`.

**Единственная цель цикла.** Проверить повторяемость содержания items без изменения банка.

**Точный scope:**
- Text/semantic duplicate scan внутри и между test-apps.
- Выделить intentional repeated signals vs accidental duplicates.
- Создать redundancy ledger и рекомендации.
- Ничего не удалять автоматически.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `exact_duplicates`
- `semantic_near_duplicates`
- `intentional_repeats`

**Definition of Done:** Для каждой найденной пары есть статус KEEP/REVIEW; runtime не меняется.

**Запрещено в этом цикле:** Не удалять items и не переписывать wording.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0116 — Social Desirability Exposure Audit

**Родительская цель:** `0036 Neutral Respondent Wording`.

**Единственная цель цикла.** Оценить, насколько respondent-facing варианты сами подсказывают «хороший» образ.

**Точный scope:**
- Проверить названия полюсов в ответах, морально окрашенные слова, очевидно желательные варианты.
- Отдельно оценить 17 anchor items и 180 situational items.
- Сформировать desirability exposure severity.
- Не переписывать текст в этом цикле.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `high_exposure_items`
- `medium_exposure_items`
- `anchor_exposure_items`

**Definition of Done:** 197/197 получают exposure status; есть точный список для rewriting.

**Запрещено в этом цикле:** Не менять scoring и не заявлять faking detection.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0117 — Neutral Wording Rewrite — Test Apps 1–4

**Родительская цель:** `0036 Neutral Respondent Wording`.

**Единственная цель цикла.** Переписать respondent-facing формулировки только первых четырёх test-apps.

**Точный scope:**
- Сохранить construct/scoring semantics.
- Убрать названия черт и очевидные моральные оценки.
- Ввести wording_version и reviewer note.
- Проверить язык на естественность и одинаковую желательность сторон.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `items_rewritten`
- `construct_semantic_drift_flags`
- `review_pass`

**Definition of Done:** Apps 1–4 проходят content review и browser reading review; остальные apps не меняются.

**Запрещено в этом цикле:** Не затрагивать apps 5–12.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0118 — Neutral Wording Rewrite — Test Apps 5–8

**Родительская цель:** `0036 Neutral Respondent Wording`.

**Единственная цель цикла.** Переписать respondent-facing формулировки только test-apps 5–8.

**Точный scope:**
- Те же правила, что 0117.
- Сравнить desirability balance до/после.
- Сохранить internal scoring keys скрытыми.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `items_rewritten`
- `desirability_balance_review`
- `semantic_drift_flags`

**Definition of Done:** Apps 5–8 готовы; 1–4 остаются неизменными после 0117; 9–12 не трогаются.

**Запрещено в этом цикле:** Не менять scoring.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0119 — Neutral Wording Rewrite — Test Apps 9–12

**Родительская цель:** `0036 Neutral Respondent Wording`.

**Единственная цель цикла.** Переписать respondent-facing формулировки только test-apps 9–12.

**Точный scope:**
- Те же правила, что 0117–0118.
- Финализировать respondent wording bank version.
- Сохранить provenance каждой правки.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `items_rewritten`
- `full_bank_wording_version`
- `semantic_drift_flags`

**Definition of Done:** Все 12 apps имеют нейтральный respondent wording; scoring semantics не изменены кроме отдельно versioned 0114.

**Запрещено в этом цикле:** Не добавлять новые constructs/items.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0120 — Questionnaire Respondent UX Acceptance

**Родительская цель:** `0036 Neutral Respondent Wording`.

**Единственная цель цикла.** Только пользовательская приёмка переписанного банка без новой научной логики.

**Точный scope:**
- Mobile-first Chromium review 12 apps.
- Проверить читаемость, длину, отсутствие technical IDs/construct names.
- Проверить один вопрос на экран и предсказуемую навигацию.
- Сформировать список только UX-дефектов.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `apps_reviewed`
- `technical_leak_count`
- `wording_overflow_count`
- `browser_errors`

**Definition of Done:** 12/12 apps readable, 0 technical leaks, 0 blocker overflow; package evidence сохранён.

**Запрещено в этом цикле:** Не менять scientific scoring.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

## Фаза C — Повторные прохождения и качество ответов (0121–0130)

### 0121 — Demo vs Production Retake Policy Separation

**Родительская цель:** `0037 Retake & Practice Effects`.

**Единственная цель цикла.** Разделить demo-retake и production-retake как два явных policy contract.

**Точный scope:**
- Demo seed всегда позволяет повторить тест немедленно.
- Production policy сохраняет утверждённый cooldown.
- Policy определяется environment/mode, не датами «магически» в UI.
- Добавить policy endpoint/metadata.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `demo_retake_allowed`
- `production_retake_blocked_when_due`
- `policy_version`

**Definition of Done:** Demo 12/12 повторяемы; production fixture правильно блокирует ранний retake.

**Запрещено в этом цикле:** Не анализировать practice effect.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0122 — Retake Attempt History Immutability

**Родительская цель:** `0037 Retake & Practice Effects`.

**Единственная цель цикла.** Сделать каждое повторное прохождение отдельным immutable attempt.

**Точный scope:**
- Attempt_no и previous_attempt_id.
- Не перезаписывать старый result.
- История сортируется по завершению и version.
- Повторное чтение старого результата использует его старую scoring provenance.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `attempt_count`
- `history_replay_pass`
- `result_overwrite_denied`

**Definition of Done:** Два прохождения создают два независимых snapshots; старый результат не меняется.

**Запрещено в этом цикле:** Не интерпретировать delta.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0123 — Alternate Order Generation v1

**Родительская цель:** `0037 Retake & Practice Effects`.

**Единственная цель цикла.** Разнообразить порядок items между попытками без изменения содержимого.

**Точный scope:**
- Новый private order seed per attempt.
- Ограничения, чтобы связанные/контрольные items не нарушали метод contract.
- Order сохраняется для воспроизводимости.
- Не делать новые alternate-form items.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `unique_order_rate`
- `order_constraint_violations`
- `replay_parity`

**Definition of Done:** Повторная попытка получает другой допустимый порядок и воспроизводится после reload.

**Запрещено в этом цикле:** Не менять wording/scoring.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0124 — Practice-Effect Metrics v1

**Родительская цель:** `0037 Retake & Practice Effects`.

**Единственная цель цикла.** Собирать только описательные признаки возможного эффекта повторного прохождения.

**Точный scope:**
- days_since_previous, total_time_delta, score_delta, response_change_rate.
- Не трактовать score_delta как изменение личности.
- Сохранять instrument/scoring version для сопоставимости.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `days_since_previous`
- `score_delta`
- `response_change_rate`
- `completion_time_delta`

**Definition of Done:** Research export содержит корректные retest metrics с non-causal disclaimer.

**Запрещено в этом цикле:** Не менять production score.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0125 — Server Item Latency Metrics v1

**Родительская цель:** `0038 Response Quality`.

**Единственная цель цикла.** Стандартизировать server-authoritative latency на уровне item.

**Точный scope:**
- presented_at/response_at из backend.
- Client high-resolution timer хранить отдельно и маркировать как client telemetry.
- Обработать background/visibility interruptions.
- Версионировать timing policy.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `server_latency_ms`
- `client_latency_ms`
- `visibility_interruption_ms`

**Definition of Done:** Latency воспроизводимо считается и не зависит от доверия к одному client timestamp.

**Запрещено в этом цикле:** Не выводить пользователю «слишком быстро отвечаете».

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0126 — Missingness & Interruption Metrics v1

**Родительская цель:** `0038 Response Quality`.

**Единственная цель цикла.** Собирать только пропуски/прерывания как research signals.

**Точный scope:**
- session interruption, expired presentation, abandoned attempt, missing optional response.
- Сохранять denominator.
- Не превращать missing в ноль или плохую черту.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `abandonment_rate`
- `interruption_rate`
- `missing_rate`

**Definition of Done:** Research dataset различает completed/abandoned/interrupted без скрытого штрафа.

**Запрещено в этом цикле:** Не рассчитывать faking.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0127 — Low-Effort Response Pattern Metrics v1

**Родительская цель:** `0038 Response Quality`.

**Единственная цель цикла.** Добавить простые descriptive признаки low-effort patterns.

**Точный scope:**
- very-fast fraction, repeated-option runs, minimal variance where applicable.
- Thresholds versioned и research-only.
- Не выдавать обвинения пользователю.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `very_fast_rate`
- `long_run_rate`
- `response_variance`

**Definition of Done:** Feature calculation deterministic; production scores unchanged.

**Запрещено в этом цикле:** Не создавать единый «fraud score».

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0128 — Within-Session Inconsistency Features v1

**Родительская цель:** `0038 Response Quality`.

**Единственная цель цикла.** Добавить только статистические признаки внутренней несогласованности.

**Точный scope:**
- Использовать только заранее определённые comparable/reverse item pairs.
- Не сравнивать случайные вопросы.
- Сохранять pair denominator и confidence.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `comparable_pair_count`
- `inconsistency_rate`
- `insufficient_pair_count`

**Definition of Done:** Inconsistency features формируются только при достаточном числе сопоставимых пар.

**Запрещено в этом цикле:** Не снижать Compatibility/Trust.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0129 — Response Quality Research Report v1

**Родительская цель:** `0038 Response Quality`.

**Единственная цель цикла.** Собрать отдельный внутренний research report из 0125–0128.

**Точный scope:**
- Отдельные компоненты без скрытого composite penalty.
- Показывать data coverage/confidence.
- Export для psychometric review.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `quality_feature_coverage`
- `report_version`

**Definition of Done:** Internal report воспроизводим, не виден обычному пользователю и не изменяет score.

**Запрещено в этом цикле:** Не создавать user-facing ярлыки.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0130 — Response Quality Non-Penalty Production Guard

**Родительская цель:** `0038 Response Quality`.

**Единственная цель цикла.** Закрепить архитектурный запрет на скрытое влияние response-quality features.

**Точный scope:**
- Architecture tests против использования features в Q28/Trust/QF/Rating.
- Promotion допускается только будущим versioned scientific decision.
- Документировать allowed uses: QA, research, stratification.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `forbidden_dependency_count`
- `guard_pass`

**Definition of Done:** 0 production scorers зависят от response-quality research features.

**Запрещено в этом цикле:** Не добавлять новые features.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

## Фаза D — Психометрика и критерии научного продвижения (0131–0140)

### 0131 — Classical Reliability Data Contract v1

**Родительская цель:** `0039 Classical Psychometrics`.

**Единственная цель цикла.** Создать только формат данных/экспорта для reliability анализа.

**Точный scope:**
- Anonymous respondent×item matrix с version/cohort/locale.
- Missingness и retest attempts не смешиваются.
- Не исполнять R psych ещё.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `rows_exported`
- `items_exported`
- `cohort_version`

**Definition of Done:** Экспорт стабилен и пригоден для psych service; никаких reliability чисел ещё нет.

**Запрещено в этом цикле:** Не запускать alpha/omega.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0132 — Reliability Service — Alpha/Omega v1

**Родительская цель:** `0039 Classical Psychometrics`.

**Единственная цель цикла.** Рассчитать базовую внутреннюю согласованность отдельным research service.

**Точный scope:**
- Использовать psych 2.6.5 в изолированном analytics environment согласно license record.
- Alpha/omega с CI где поддерживается.
- Отдельно по system/construct/cohort/locale при достаточном N.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `alpha`
- `omega`
- `sample_n`
- `ci`

**Definition of Done:** Версионированный reliability report; при недостаточном N — INSUFFICIENT_DATA.

**Запрещено в этом цикле:** Не менять product scoring.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0133 — Item-Total & Scale Health Diagnostics v1

**Родительская цель:** `0039 Classical Psychometrics`.

**Единственная цель цикла.** Добавить только item-total/scale diagnostics.

**Точный scope:**
- Corrected item-total correlations.
- Alpha-if-item-deleted как diagnostic, не автоматическое удаление.
- Flag проблемных items для review.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `item_total_r`
- `alpha_if_deleted`
- `flagged_item_count`

**Definition of Done:** Получен diagnostic ledger; ни один item автоматически не удалён.

**Запрещено в этом цикле:** Не выполнять factor analysis.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0134 — Dimensionality Exploration v1

**Родительская цель:** `0040 Factor Structure`.

**Единственная цель цикла.** Провести exploratory dimensionality отдельно от IRT.

**Точный scope:**
- Parallel analysis/appropriate exploratory factor methods из разрешённого research tooling.
- Отдельно по достаточным cohorts.
- Сохранять model settings и random seed.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `suggested_factor_count`
- `sample_n`
- `analysis_version`

**Definition of Done:** Получен reproducible exploration report; production construct model не меняется автоматически.

**Запрещено в этом цикле:** Не подтверждать final model.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0135 — Factor Loading Stability Review v1

**Родительская цель:** `0040 Factor Structure`.

**Единственная цель цикла.** Оценить стабильность loadings/структуры на независимых split/cohorts.

**Точный scope:**
- Train/holdout или resampling policy.
- Сопоставить intended constructs и empirical loadings.
- Flag cross-loading/weak items.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `loading_stability`
- `cross_loading_count`
- `weak_loading_count`

**Definition of Done:** Есть evidence ledger для construct review; никаких тихих remap.

**Запрещено в этом цикле:** Не менять item-to-construct mapping.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0136 — IRT Input & Model Selection Contract v1

**Родительская цель:** `0041 IRT Calibration`.

**Единственная цель цикла.** Подготовить только IRT-ready contract и правила выбора модели.

**Точный scope:**
- Тип response model по item format.
- Указать Rasch/1PL/2PL/graded response candidates.
- Power/sample adequacy gate.
- Не запускать калибровку при недостаточном N.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `irt_ready_items`
- `model_candidate`
- `sample_adequacy`

**Definition of Done:** Для каждой шкалы определён допустимый model family либо INSUFFICIENT_DATA.

**Запрещено в этом цикле:** Не вычислять item parameters.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0137 — IRT Calibration — Baseline Model v1

**Родительская цель:** `0041 IRT Calibration`.

**Единственная цель цикла.** Выполнить первую одну выбранную IRT модель на подходящих данных.

**Точный scope:**
- mirt как изолированный research service.
- Сохранять item parameters, SE, convergence, fit.
- Не смешивать разные language groups без justification.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `convergence`
- `item_parameters`
- `model_fit`
- `sample_n`

**Definition of Done:** Одна model family успешно калибрована либо корректно отклонена; production score unchanged.

**Запрещено в этом цикле:** Не делать DIF.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0138 — Item & Test Information v1

**Родительская цель:** `0041 IRT Calibration`.

**Единственная цель цикла.** Рассчитать информационность только для уже успешно откалиброванной IRT модели.

**Точный scope:**
- Item information curves/test information.
- Показать диапазоны theta с низкой информацией.
- Выдать research recommendations.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `item_information`
- `test_information`
- `low_information_ranges`

**Definition of Done:** Research report показывает где тест измеряет хорошо/плохо; никаких автоматических item deletions.

**Запрещено в этом цикле:** Не делать adaptive testing.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0139 — DIF / Multiple-Group Analysis v1

**Родительская цель:** `0042 DIF & Fairness`.

**Единственная цель цикла.** Проверить differential item functioning на одной заранее выбранной группировке за цикл.

**Точный scope:**
- Одна grouping dimension per run/version.
- Minimum N gate.
- Flag DIF, effect magnitude, uncertainty.
- Не объявлять bias без substantive review.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `dif_items`
- `effect_size`
- `group_n`

**Definition of Done:** DIF report воспроизводим; flagged items идут в review, product score unchanged.

**Запрещено в этом цикле:** Не объединять все демографические группы сразу.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0140 — Psychometric Promotion Gate v1

**Родительская цель:** `0043 Scientific Promotion`.

**Единственная цель цикла.** Создать governance gate: когда research evidence разрешает новую production scoring version.

**Точный scope:**
- Требования reliability/dimensionality/IRT/DIF/documentation.
- Explicit owner/scientific approval.
- Rollback и version coexistence.
- No auto-learning.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `promotion_decision`
- `evidence_bundle_version`
- `rollback_ready`

**Definition of Done:** Без заполненного promotion record новый scoring не может стать production-active.

**Запрещено в этом цикле:** Не менять scoring в этом цикле.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

## Фаза E — Ассоциативный модуль: нормы → анализ → продукт (0141–0150)

### 0141 — Word Association User Flow v2 — UX Only

**Родительская цель:** `0052 Word Association`.

**Единственная цель цикла.** Переделать только пользовательский flow Word Association без нового анализа.

**Точный scope:**
- Простой русский respondent instruction.
- Один cue → одно поле ответа → понятный progress.
- Убрать method IDs, hashes, латинский technical jargon.
- Не показывать интерпретации до завершения.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `completion_rate_demo`
- `technical_leak_count`
- `browser_errors`

**Definition of Done:** Chromium: пользователь понимает задание без пояснений разработчика; 0 technical leaks.

**Запрещено в этом цикле:** Не добавлять нормы/семантический анализ.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0142 — Word Association Raw Event Contract v2

**Родительская цель:** `0052 Word Association`.

**Единственная цель цикла.** Уточнить только event capture для будущего анализа.

**Точный scope:**
- cue version, presented_at, first_input_at, submit_at, edits, clears, skip, response text.
- Server/client timing separation.
- Privacy classification raw vs derived.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `latency_ms`
- `edit_count`
- `skip`
- `response_length`

**Definition of Done:** Raw event snapshot воспроизводим и пригоден для норм/процессного анализа.

**Запрещено в этом цикле:** Не интерпретировать содержание.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0143 — УрРАС VPS Import v1

**Родительская цель:** `0053 УрРАС`.

**Единственная цель цикла.** Импортировать только УрРАС в отдельный provenance-preserving normative store.

**Точный scope:**
- Сохранить source/version/import hash.
- Индексы stimulus→responses и response→stimuli.
- Нормализовать текст без потери оригинала.
- Валидация counts/duplicates/encoding.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `stimulus_count`
- `response_pair_count`
- `import_reject_count`
- `source_hash`

**Definition of Done:** УрРАС загружается в VPS store и проходит deterministic re-import parity.

**Запрещено в этом цикле:** Не объединять с ЕВРАС/РАС.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0144 — ЕВРАС VPS Import v1

**Родительская цель:** `0054 ЕВРАС`.

**Единственная цель цикла.** Импортировать только ЕВРАС в отдельный normative namespace.

**Точный scope:**
- Те же provenance/integrity требования, что 0143.
- Сохранить прямой и обратный словарь где доступен.
- Не смешивать counts с УрРАС.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `stimulus_count`
- `response_pair_count`
- `source_hash`

**Definition of Done:** ЕВРАС импортируется и независимо запрашивается.

**Запрещено в этом цикле:** Не объединять корпуса.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0145 — РАС VPS Import v1

**Родительская цель:** `0055 РАС`.

**Единственная цель цикла.** Импортировать только РАС в отдельный normative namespace.

**Точный scope:**
- Provenance, version, encoding, duplicate policy.
- Сохранить оригинальные lexical forms.
- Ввести import audit report.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `stimulus_count`
- `response_pair_count`
- `source_hash`

**Definition of Done:** РАС импортируется независимо и проходит integrity checks.

**Запрещено в этом цикле:** Не делать unified score.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0146 — Unified Association Norms Query Service v1

**Родительская цель:** `0056 Unified Norms`.

**Единственная цель цикла.** Создать единый API поиска по трём независимым корпусам без их скрытого усреднения.

**Точный scope:**
- Запрос stimulus/response возвращает per-source counts/frequencies.
- Источник всегда виден в provenance.
- Если источники расходятся — отдавать отдельно.
- Подготовить место для будущих Brotherhood norms.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `sources_available`
- `per_source_frequency`
- `coverage`

**Definition of Done:** Один запрос даёт сопоставимые, но раздельные УрРАС/ЕВРАС/РАС evidence.

**Запрещено в этом цикле:** Не строить психологическую интерпретацию.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0147 — Association Normative Features v1

**Родительская цель:** `0057 Association Norm Features`.

**Единственная цель цикла.** Рассчитать только нормативные признаки реакции.

**Точный scope:**
- Cue-response frequency, conditional probability/strength, rank, rarity/typicality с явной формулой.
- Per-source и optional pooled research view с versioned weighting policy.
- Missing norm = INSUFFICIENT_DATA.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `frequency`
- `rank`
- `rarity`
- `association_strength`
- `norm_coverage`

**Definition of Done:** Для ответа доступны reproducible normative features и provenance.

**Запрещено в этом цикле:** Не делать semantic/psychological interpretation.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0148 — Association Semantic & Content Features v1

**Родительская цель:** `0058 Content Analysis`.

**Единственная цель цикла.** Добавить только содержательные derived features поверх текста ответа.

**Точный scope:**
- Нормализация/лемматизация как versioned technical layer.
- Semantic relation categories только с описанным method contract.
- Emotion/social/topic tags как hypotheses, не диагноз.
- Сохранять confidence/provenance.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `semantic_relation`
- `topic_tags`
- `affect_tags`
- `confidence`

**Definition of Done:** Для ответа есть bounded content feature set; пользовательский результат не содержит клинических утверждений.

**Запрещено в этом цикле:** Не смешивать process features.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0149 — Association Process + Context Hypothesis Graph v1

**Родительская цель:** `0059-0060 Association Analysis`.

**Единственная цель цикла.** Соединить normative/content evidence с latency/edit/repetition/chain context в versioned hypothesis graph.

**Точный scope:**
- Каждая hypothesis хранит contributing features и rule/version.
- До 1000 детерминированных комбинаций на ответ допускаются как internal research capacity.
- Ranking отделён от diagnosis; uncertainty обязательна.
- Public UI получает только небольшой отобранный набор понятных выводов.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `hypothesis_count`
- `evidence_edge_count`
- `uncertainty`
- `public_summary_count`

**Definition of Done:** Один ответ может породить богатый traceable analysis graph; 0 unsupported diagnosis claims.

**Запрещено в этом цикле:** Не менять Compatibility/Trust.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

### 0150 — Association Analysis v2 Product Acceptance

**Родительская цель:** `0061-0062 Association Product`.

**Единственная цель цикла.** Только интеграционная приёмка ассоциативного модуля 0141–0149.

**Точный scope:**
- Полный flow cue→response→history→normative evidence→public readable summary.
- Chromium mobile-first.
- Проверка больших norm stores через VPS adapter.
- Проверка privacy/raw-event separation и deterministic replay.

**Данные/метрики, которые разрешено добавить в этом цикле:**
- `completion_e2e`
- `norm_lookup_success`
- `analysis_replay_pass`
- `browser_errors`

**Definition of Done:** End-to-end Association v2 PASS без technical clutter и без unsupported clinical claims.

**Запрещено в этом цикле:** Запрещены новые аналитические методы; найденные проблемы получают отдельный цикл 0151+ после owner allocation.

**Обязательный финальный gate:** Operator Kernel → cycle ecosystem → JSON → targeted tests → protected regression → persistence reload (если есть DB) → SimulationEngine parity (если менялся contract) → real Chromium/mobile smoke (если есть UI) → manifest/file-map parity → deterministic DEVELOPMENT package.

## 4. Резерв 0151–0200

Циклы `0151–0200` **не назначены**. Их нельзя заполнять автоматически. Они предназначены для следующей owner-декомпозиции: expert psychology/psychiatry packs, Q48/Q49, social product, hospitality, release hardening либо дефекты, найденные в 0101–0150.

## 5. Следующий исполняемый цикл

**0101 — Public Test Catalog Redaction v1.**

До его упаковки нельзя начинать 0102.
