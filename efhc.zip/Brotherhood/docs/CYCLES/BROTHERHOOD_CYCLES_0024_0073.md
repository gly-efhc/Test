# Brotherhood — active cycles 0024–0073

Status: **ACTIVE ASSIGNED PROGRAM — 50 cycles**  
Activated: `2026-08-11 / cycle 0024 governance synchronization`

Canonical detailed roadmap: `BROTHERHOOD_ROADMAP_0024_0073.md`.

## Program invariants
- Progress is stage-based: `R → S → B → SIM → H → VA → A → CI → E2E → PQ`; no flat `COMPLETED` shortcut.
- User-facing features follow `backend/domain → routes → Simulation Engine → routes/read models → HTML → owner VA → Android mirror → CI/APK → live E2E`.
- Source classes remain independent under `BROTHERHOOD_SOURCE_AUTHORITY_CANON.md`.
- Different psychological systems are separate modules and may expose their own compatibility `0–100%`; they are not silently blended with Numerology/Enneagram/Astrology/Trust/Quality Fit. Cycle 0028 materializes seven scientific test systems v1 now; cycles 0043–0053 are v2 hardening/expansion, not a launch prerequisite.
- Psychological calibration is internal and immediate: canonical scientific sources → claim/construct contract → scientific questionnaire bank → deterministic scoring/coverage → result/compatibility/report. Future outcome cohorts may harden a later version but are not a multi-year launch gate.
- Missing evidence is never fabricated as `0%`.
- Progressive disclosure moves complexity; it does not delete functions.

## Cycle ledger
| Cycle | Phase | Current status | Major result |
|---|---|---|---|
| 0024 | Functional/UI Recovery | SOURCE_IMPLEMENTED / GOVERNANCE_SYNC_COMPLETE / VA_PENDING | Psychological Report Persistence + Server Compatibility + Recovery Simulation Contract |
| 0025 | Functional/UI Recovery | HTML_IMPLEMENTED / ROUTE_BACKED_SIMULATION / VA_PENDING | UI Recovery A: My Profile → People → Candidate → Compatibility → Tests/Psychology |
| 0026 | Functional/UI Recovery | SOURCE_HTML_IMPLEMENTED / ROUTE_BACKED_SIMULATION / VA_PENDING | UI Recovery B: Chat → Groups → Search Requests |
| 0027 | Functional/UI Recovery | SOURCE_HTML_IMPLEMENTED / ROOT_IA / 12_TEST_APPS / VA_PENDING | Root IA + Development Hub: Profile → People → Chats → Groups → Development; 12 standalone Tests apps over 197 items/7 internal systems; Numerology/Zodiac standalone v1 flows |
| 0028 | Functional/UI Recovery | SCIENTIFIC_QUESTIONNAIRE_V1_2_SOURCE_HTML_IMPLEMENTED / VA_PENDING | Legacy generated visual bank removed. Active product: 7 scientific systems / 197 source-claim-traced questionnaire items / ≥3 signals per construct / server-authoritative scoring / report + independent compatibility. Active HTML for cycle 0028 scientific baseline remains historical v0_5_41; cycle 0027 integrated acceptance candidate is v0_5_42. |
| 0029 | Multi-method Psychology | SOURCE_HTML_IMPLEMENTED / 3_ASSOCIATIVE_IMPLICIT_METHODS / Q48 / VA_PENDING | Associative & Implicit Measurement Systems v1: Jung Word Association → Freud Free Association → IAT/RT + Reverse Friendship Pattern Discovery v1 |
| 0030 | Development Apps | SOURCE_HTML_IMPLEMENTED / NUMEROLOGY_STANDALONE_VNEXT_EXPANDED_V3 / Q49_PLAN / VA_PENDING | Numerology reading v3: transparent calculations, 97-record catalog, complete date chart, calendar peak dates, frozen NU pair inputs + Friendship Reflection Survey roadmap |
| 0031 | Development Apps | SOURCE_HTML_IMPLEMENTED / AS_ZODIAC_BASIC_V1 / VA_PENDING | Zodiac standalone vNext: persisted profile/history, 12-sign catalog, transparent basic method, independent AS 0–100% pair comparison/history; Android Development root mirror still gated by owner VA |
| 0032 | Development Apps | SOURCE_HTML_IMPLEMENTED / ENNEAGRAM_STANDALONE / DEVELOPMENT_FULL_DEMO_V1 / VA_PENDING | Enneagram 18-item optional app + immutable history + independent EN + full active Development simulator demo |
| 0033 | Matching/Product | SOURCE_HTML_IMPLEMENTED / QUALITY_FIT_SEARCH_INTENT_V2 / STABLE_SERVICE_UX / CHROMIUM_E2E_PASS / VA_PENDING | Directional Quality Fit from explicit SearchIntent + persistent evaluation history + 12/12 demo retake + non-jumping service-first Development/Tests/results UI |
| 0034 | Matching/Product | PLANNED / SEQUENCED | Unified Multi-method Compatibility Service + reproducible persistence |
| 0035 | Matching/Product | PLANNED / SEQUENCED | Compatibility Page + Metric/Method Detail IA |
| 0036 | Trust/Behavior | PLANNED / SEQUENCED | Trust v2 + observed-behavior evidence boundaries |
| 0037 | Independent Model Productization | PLANNED / SEQUENCED | Release-Parity Simulation Engine v2 |
| 0038 | Evidence/Release Candidate I | PLANNED / SEQUENCED | Post-Release Outcome Data Capture & Recalibration Runtime |
| 0039 | Evidence/Release Candidate I | PLANNED / SEQUENCED | Fairness / Privacy / Ethics / Explainability |
| 0040 | Evidence/Release Candidate I | PLANNED / SEQUENCED | 13-Locale Controlled Pilot |
| 0041 | Evidence/Release Candidate I | PLANNED / SEQUENCED | Integrated Investor / Release Candidate 1 |
| 0042 | Test Platform v2 | PLANNED / SEQUENCED | Source Registry v2 + Owner Source-Map Patch Consolidation |
| 0043 | Test Platform v2 | PLANNED / SEQUENCED | Test System v2 Architecture hardening beyond cycle-0028 v1 |
| 0044 | Test Platform v2 | PLANNED / SEQUENCED | Associative & Implicit v2 hardening / additional instruments |
| 0045 | Test Platform v2 | PLANNED / SEQUENCED | Trait Dimensions v2 hardening/expanded instrument |
| 0046 | Test Platform v2 | PLANNED / SEQUENCED | Interpersonal / Relationship Style v2 hardening/expanded instrument |
| 0047 | Test Platform v2 | PLANNED / SEQUENCED | Communication + Conflict v2 hardening/expanded instrument |
| 0048 | Test Platform v2 | PLANNED / SEQUENCED | Trust/Support/Boundaries v2 hardening/expanded instrument |
| 0049 | Test Platform v2 | PLANNED / SEQUENCED | Decisions/Risk/Work Style v2 hardening/expanded instrument |
| 0050 | Test Platform v2 | PLANNED / SEQUENCED | Social Energy/Group Role v2 hardening/expanded instrument |
| 0051 | Test Platform v2 | PLANNED / SEQUENCED | Adaptability/Uncertainty v2 hardening/expanded instrument |
| 0052 | Test Platform v2 | PLANNED / SEQUENCED | Test Orchestrator / Progress / History / Retake v2 |
| 0053 | Test Platform v2 | PLANNED / SEQUENCED | Psychological Profile / Report v2 + Modular Psychological Compatibility |
| 0054 | Profile/Social Network | PLANNED / SEQUENCED | My Profile / Digital Resume v2 |
| 0055 | Profile/Social Network | PLANNED / SEQUENCED | Identity / Verification / Privacy Controls |
| 0056 | Profile/Social Network | PLANNED / SEQUENCED | People Discovery / Ranking v2 |
| 0057 | Profile/Social Network | PLANNED / SEQUENCED | Search Requests Marketplace of Intent |
| 0058 | Profile/Social Network | PLANNED / SEQUENCED | Candidate Deep Profile v2 |
| 0059 | Profile/Social Network | PLANNED / SEQUENCED | Groups / Communities v2 |
| 0060 | Profile/Social Network | PLANNED / SEQUENCED | Projects / Skills / Team Formation |
| 0061 | Profile/Social Network | PLANNED / SEQUENCED | Notifications / Activity / Relationship History |
| 0062 | Communication/Real-world Interaction | PLANNED / SEQUENCED | Direct Chat v2 |
| 0063 | Communication/Real-world Interaction | PLANNED / SEQUENCED | Group Chat / Media / Moderation |
| 0064 | Communication/Real-world Interaction | PLANNED / SEQUENCED | Verified Interactions / Trust / Appeals Runtime v3 |
| 0065 | Communication/Real-world Interaction | PLANNED / SEQUENCED | Hospitality Host/Guest Experience v2 |
| 0066 | Communication/Real-world Interaction | PLANNED / SEQUENCED | Hospitality Verification / Reviews / Reputation / Safety |
| 0067 | Communication/Real-world Interaction | PLANNED / SEQUENCED | Services / Mutual Aid / Offline Handoff |
| 0068 | Release Engineering | PLANNED / SEQUENCED | 13-Locale Product & Measurement QA |
| 0069 | Release Engineering | PLANNED / SEQUENCED | Accessibility / Performance / Responsive Quality |
| 0070 | Release Engineering | PLANNED / SEQUENCED | Offline / Sync / Conflict / Recovery |
| 0071 | Release Engineering | PLANNED / SEQUENCED | Security / Privacy / Abuse / Moderation Release Audit |
| 0072 | Release Engineering | PLANNED / SEQUENCED | Full Release-Parity Simulation + Live E2E Rehearsal |
| 0073 | Release Engineering | PLANNED / SEQUENCED | Release Candidate 2 / Production Qualification |

## Reserve
`0074–0100 = UNUSED_RESERVE` until explicit owner assignment.

## Detail rule
Every cycle's exact implementation scope, required artifacts and exit gate are defined in `BROTHERHOOD_ROADMAP_0024_0073.md`; the status registry records evidence actually achieved, not planned.
