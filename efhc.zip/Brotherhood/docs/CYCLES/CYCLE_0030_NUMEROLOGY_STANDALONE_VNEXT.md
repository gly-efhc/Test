# Cycle 0030 — Numerology Standalone Application vNext + expanded calculation/data layer + Q49 roadmap

Status: **SOURCE_HTML_IMPLEMENTED / NUMEROLOGY_READING_V3 / ROUTE_BACKED_SIMULATION / SIM_PASS / VA_PENDING**  
Date: 2026-08-13  
Original cycle input HEAD: `Brotherhood_v0_5_69.zip`  
Same-cycle expansion input: `Brotherhood_v0_5_70.zip`  
Target DEVELOPMENT HEAD: `Brotherhood_v0_5_71.zip`

## Owner objective

Keep cycle 0030 open and expand `Развитие → Нумерология` before visual acceptance. The application must expose more of the calculations and active normalized data already supported by Brotherhood sources/CANON, without inventing a new numerology school, changing Q28 semantics, or mirroring into Android before owner VA.

## Active methodological boundary

- Reading contract: `numerology-reading-v3`.
- Knowledge contract: `numerology-knowledge-v1`.
- Pair compatibility: `vedic-numerology-runtime-v1`.
- `NU` remains an independent Q28 metric `0–100%`.
- Name-derived Soul/Expression values remain descriptive only and are excluded from date-based NU compatibility.
- No fixed cross-metric “Numerology 5%” semantics exist.
- The same-cycle expansion does **not** introduce personal-year/month/day, Dasa, horoscope periods or another unapproved tradition: those calculations are not established by the active Brotherhood Numerology contract.

## Expanded personal reading v3

The immutable reading now includes:

- Life Path;
- date-derived Soul, Destiny and Maturity;
- ruler/planet metadata for Soul, Destiny and Maturity from the existing Vedic engine mapping;
- human-readable date-number meanings;
- deterministic arithmetic trace for Life Path, Soul, Destiny, Maturity and all four Pinnacles;
- optional name-derived Soul/Expression trace, explicitly marked descriptive-only;
- complete date-digit inventory for positions `1..9`, including zero-count/missing positions;
- existing special birth-chart configurations;
- four already-defined Pinnacle numbers and ages;
- exact calendar birthday corresponding to each already-defined Pinnacle age;
- source-backed Life Path/name/birth-chart/Pinnacle interpretation blocks;
- versioned immutable snapshot hash and history/reread.

For a fixed input and fixed calculation/knowledge version, the domain result remains deterministic. Re-saving the same canonical input remains idempotent by the existing persistence pattern.

## Source-backed data catalog

The active normalized `numerology-knowledge-v1` corpus is productized through read-only API/UI catalog routes. It contains exactly **97 records** across five groups:

- `life_paths` — 11;
- `soul_numbers` — 11;
- `outer_numbers` — 12;
- `birth_chart` — 52;
- `pyramid_peaks` — 11.

New routes:

- `GET /v1/numerology/catalog/{locale}`;
- `GET /v1/numerology/catalog/{locale}/{group_id}/{key}`.

The catalog exposes the existing normalized knowledge; it does not create additional scoring weights.

## Independent NU pair comparison

The compatibility formula is unchanged from `vedic-numerology-runtime-v1`:

- Soul relation — 40%;
- Destiny relation — 35%;
- cross Soul↔Destiny relation — 15%;
- date composite relation — 10%.

These weights exist **inside NU only**. Selected Overall remains the arithmetic mean of selected available Q28 metrics.

Cycle 0030 expansion adds explanation/provenance inside each saved pair comparison:

- frozen Soul/Destiny inputs for both members of the stable pair;
- ruler for each compared number;
- directed/symmetric relation details;
- relation code `SAME / FRIENDLY / NEUTRAL / CONTRASTING`;
- component score and internal NU weight;
- strongest component and optional tension component;
- immutable comparison history/reread.

No psychological, Trust, Account Rating, Hospitality Reputation or Quality Fit score is changed by Numerology.

## Persistence / DB

Existing cycle-0030 migration remains sufficient:

`database/migrations/0015_numerology_vnext.sql`

Tables remain:

- `numerology_readings`;
- `numerology_pair_comparisons`.

No new migration/table is required for reading v3 because the expanded structured payload is stored in the existing versioned immutable snapshot/document fields. Persistence schema remains **15**.

## Public Numerology API

1. `GET /v1/numerology/spec`
2. `GET /v1/numerology/catalog/{locale}`
3. `GET /v1/numerology/catalog/{locale}/{group_id}/{key}`
4. `POST /v1/numerology/readings`
5. `GET /v1/numerology/readings/{global_id}`
6. `GET /v1/numerology/readings/{global_id}/latest`
7. `GET /v1/numerology/readings/{global_id}/{reading_id}`
8. `POST /v1/numerology/compatibility`
9. `GET /v1/numerology/compatibility/{global_id}/history`

## HTML / Simulation

Active standalone acceptance candidate: `BROTHERHOOD_UI_SIMULATOR_v0_5_45.html`.

`Развитие → Нумерология` now provides:

- Numerology home and saved current profile;
- **Профиль** — date numbers, rulers, meanings, Life Path and optional descriptive name blocks;
- **Расчёт** — formulas and reduction chains for every calculated indicator in reading v3;
- **Пики** — four existing peak numbers, calculated ages and exact calendar dates;
- **Карта даты** — complete 1–9 inventory including missing positions and special configurations;
- **Справочник** — all 97 normalized records in five source-backed groups with detail pages;
- **История** — immutable readings and reread;
- **Сравнение** — independent NU 0–100%, frozen pair inputs, ruler/relation details and comparison history.

The frontend consumes the same route contract through `BackendSimulator → SimulationEngine → route responses`. The UI does not establish an alternative Numerology business truth.

Current source/simulation contract:

- **117 OpenAPI paths**;
- **136 HTTP operations**;
- **54 migration-defined DB tables**;
- **21 Android AppRoutes**;
- **200 deterministic synthetic candidates**;
- persistence schema **15**.

Local SimulationEngine route probe: **136/136 PASS / 0 failures / 54 tables**.

## Q49 — Friendship Reflection Surveys

The Q49 design from the first 0030 pass remains active and unchanged in product boundary. Contract:

`docs/research/outcomes/FRIENDSHIP_REFLECTION_SURVEYS_V1.md`

It preserves randomized/stratified invitation sampling, denominator, cooldown/consent, independent A/B responses, linkage to Q48 frozen pre-friendship/exposure data, bilateral agreement/disagreement and retrospective-bias controls. Q49 remains research evidence only and does not directly mutate production scoring. Runtime hardening remains scheduled for 0038.

## Verification state

Completed during the expanded same-cycle pass:

- Operator Kernel `validate-config`: PASS;
- targeted Numerology backend tests: **11/11 PASS**;
- full backend regression: **99/99 PASS**;
- architecture regression: **275/275 PASS**;
- focused 0024/0028/0030 + Numerology/UI guard set: **49/49 PASS**;
- HTML parser: PASS; active HTML byte parity: PASS for 3 copies; external asset references: **0**;
- inline JavaScript syntax: PASS for both script blocks;
- source contract regeneration: **117 / 136 / 54 / 21**;
- SimulationEngine operation probe: **136/136 PASS / 0 failures**;
- persistence reload: schema15 reading/comparison history restored;
- catalog runtime probe: **97 records / 5 groups**;
- reading v3 runtime probe: calculation trace + 9-position inventory + calendar peak dates + rulers present;
- pair runtime probe: 4 components with frozen inputs and relation details present;
- Android source delta vs v69 and v70: **0 added / 0 changed / 0 removed**.

Final package verification is performed only after current SSOT/manifest/handoff updates and final `refresh-map`.

## Stage state

- R: PASS
- S: PASS
- B: PASS
- H: PASS
- VA: **PENDING**
- A: NOT_STARTED_BY_DESIGN
- CI: NOT_RUN
- E2E: NOT_RUN

## Explicitly not run / not claimed

- owner visual acceptance: PENDING;
- Android Compose mirror: NOT_STARTED;
- APK/AAB as a visual-review mechanism: NOT_RUN by HTML-first canon;
- GitHub CI/APK: NOT_RUN;
- migration `0015` against live PostgreSQL: NOT_RUN;
- device/live E2E: NOT_RUN.

## Next after owner acceptance/corrections

`0031 — Zodiac standalone application vNext`.
