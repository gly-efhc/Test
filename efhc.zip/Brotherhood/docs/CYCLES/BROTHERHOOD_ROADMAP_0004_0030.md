# Brotherhood — Development & Research Roadmap 0004–0030

Status: **SUPERSEDED / RESTRUCTURED BY OWNER CYCLE-0004 DIRECTIVE**  
Approved direction at creation: owner request 2026-08-09. Current replacement: `BROTHERHOOD_ROADMAP_0004_0031.md`.  
Current active product cycle remains `0003`; this roadmap begins after/alongside owner-authorized transition to `0004`.

> Historical predecessor retained for auditability. Its 0004–0030 sequencing is no longer active where it differs from the 28-cycle owner roadmap 0004–0031.

## Принцип
27 крупных циклов. Научная методология строится до production claims; docs/research cycles не получают APK без runtime/UI necessity. Runtime protected mechanics не изменяются под видом research documentation.

| Cycle | Status | Result | Scope | Exit gate | APK |
|---|---|---|---|---|---|
| 0004 | PLANNED | Compatibility Research Registry & scientific governance | Закрыть source-to-claim, evidence statuses, metric contracts, privacy/claim policy; принять эту документальную базу как обязательный research anchor. | Документы согласованы; no runtime change. | НЕТ |
| 0005 | PLANNED | Psychological construct architecture | Пересобрать construct map: Big Five/IPIP, HEXACO candidates, agency/communion, attachment/communication; удалить логические дубли и moral labels. | Construct map + reference instrument plan + licensing verdict. | НЕТ |
| 0006 | PLANNED | Visual stimulus scientific redesign | Аудит всех 600 tasks: paradigm, construct hypothesis, cueing, visual confounds, counterbalancing, asset provenance. | 600/600 stimulus manifest + reject/rework list. | Только если renderer менялся |
| 0007 | PLANNED | Reference calibration protocol | Сформировать research batteries, consent, cohort protocol, power/precision plan, RU/UK/EN translation/invariance protocol. | Independent protocol review PASS. | НЕТ |
| 0008 | PLANNED | Pilot instrumentation & data-quality | Логи stimulus_id/option/position/latency; entropy/position/missingness dashboards; no trait auto-mutation. | Technical pilot gates PASS. | Если Android data capture changed |
| 0009 | PLANNED | Psychometric calibration v1 | Fit exploratory/confirmatory/IRT/forced-choice candidate models; remove weak stimuli; locked validation split. | PC measurement model v1 = PILOT_CALIBRATED or stays HYPOTHESIS. | НЕТ |
| 0010 | PLANNED | Psychological Compatibility Engine v1 | Role-aware similarity/complementarity/asymmetry rules; no universal distance; explanation/privacy layer. | PC v1 tests + research manifest; old weighted hybrid not used for PC. | APK checkpoint research UI if visible |
| 0011 | PLANNED | Friend Compatibility outcome model | Friendship quality, autonomy support, disclosure, reciprocity, conflict/repair, persistence outcomes; baseline vs learned model. | Friend context model + outcome schema. | НЕТ |
| 0012 | PLANNED | Interests Compatibility | Hobby overlap + intensity + joint-activity intent; vocational/domain-interest contour for work/business. | IC v1 + transparent baseline + validation plan. | НЕТ |
| 0013 | PLANNED | Values Compatibility | Schwartz circular value representation; conflict/adjacency logic; private value profile and dyad explanation. | VC v1 research implementation. | НЕТ |
| 0014 | PLANNED | Communication Compatibility | Agency/communion, disclosure, support, response tempo, conflict/repair, autonomy need. | CC v1 + dyadic validation protocol. | НЕТ |
| 0015 | PLANNED | Lifestyle Compatibility | Constraint/preference model: schedule, location, meeting frequency, activities and optional disclosed habits. | LC v1 + sensitive-data policy. | НЕТ |
| 0016 | PLANNED | Brotherhood Personality Type | Soft type memberships over continuous traits; no hard MBTI-like dichotomies; versioned type compatibility. | PT v1 = TYPOLOGICAL_EXPERIMENTAL. | НЕТ |
| 0017 | PLANNED | Enneagram compatibility | Evidence-aware Enneagram layer; theory-derived matrix labeled experimental; no feed into PC. | EN v1 + limitations disclosure. | НЕТ |
| 0018 | PLANNED | Numerology compatibility | Audit current Vedic implementation; formalize date-based tradition/version; separate self-analysis and pair compatibility. | NU v1 deterministic spec + tests. | НЕТ |
| 0019 | PLANNED | Astrology/Zodiac compatibility | Separate basic zodiac and future synastry; explicit alternative evidence status; deterministic versioning. | AS v1 spec + negative-evidence disclosure. | НЕТ |
| 0020 | PLANNED | Quality Fit v2 | Directional user-authored qualities; role context; person-job/group/organization principles; no role-injected desired traits. | QF v2 API/model + temporal guard. | APK if search UI changed |
| 0021 | PLANNED | Trust + Coverage architecture | Separate Trust, verification/incidents/appeals; Data Coverage/recency per metric; no cross-score weighting. | TR/DC contracts + UI policy. | НЕТ |
| 0022 | PLANNED | Compatibility data/API platform | Metric registry/version tables, pair scores/history, preference checkboxes, model manifests, research status, auditability. | DB/API migrations + privacy tests. | НЕТ |
| 0023 | PLANNED | Compatibility service UI — Diia model | One compatibility page, grouped checkboxes, unweighted mean, detail pages, role selector, QF/Trust separate, stable bottom nav. | Route-backed Android + HTML parity. | APK CHECKPOINT B |
| 0024 | PLANNED | Person resume/profile — early VK depth | Resume-like candidate profile: photo, activities, interests, skills, public verification, groups; no latent disclosure. | Owner visual acceptance. | НЕТ unless Android changed significantly |
| 0025 | PLANNED | Discovery/search requests | Serious people marketplace: filters, role request, recommended candidate cards/swipes only in discovery, direct messaging. | E2E search request → candidate → compatibility → message. | APK CHECKPOINT C |
| 0026 | PLANNED | Telegram-class communication integration | Direct/group chats, delivery/retry, reply/reactions/edit/delete, attachments, moderation, E2EE hardening roadmap. | Message E2E + offline recovery. | APK CHECKPOINT D |
| 0027 | PLANNED | Communities/business club | Interest/local/business/project/mutual-aid groups, events, roles/moderation; candidate/community bridge. | Community lifecycle E2E. | НЕТ |
| 0028 | PLANNED | Longitudinal outcome platform | 30/90/180-day friend/business/team/mentor outcomes; consent, temporal integrity, research exports. | Outcome pipeline + privacy review + baseline reports. | НЕТ |
| 0029 | PLANNED | Model validation/fairness/replication | Locked holdout, cross-language invariance, subgroup fairness, incremental validity, external replication plan, rollback. | Independent verifier verdict per metric. | APK only if model/UI changes |
| 0030 | PLANNED | Full investor simulation + production RC | Release-parity backend/tables/routes/metrics/UI simulation; no simplified mocks; release docs, security/privacy, device matrix, staged rollout plan. | Investor demo = full product parity; RC gates and frozen model manifests. | APK/AAB FINAL CHECKPOINT E |

## Фазы
- `0004–0009` — scientific foundation & measurement.
- `0010–0019` — independent compatibility engines.
- `0020–0022` — Quality Fit/Trust/data platform.
- `0023–0027` — VK+Telegram+Diia product integration.
- `0028–0029` — longitudinal validation/fairness/replication.
- `0030` — full investor simulation + production RC.

`0031–0100` remains reserve after this plan.

## Detailed cycle cards

Each cycle is a major product/research result, not a micro-edit. Documentation/test/report work required to close a cycle is part of the cycle itself.

### 0004 — Compatibility Research Registry & scientific governance
**Key work:**
- Принять source-to-claim реестр как обязательный anchor.
- Зафиксировать evidence states и claim vocabulary.
- Утвердить contract каждой независимой metric и overall arithmetic rule.
- Связать research route с Kernel/boundaries.
**Required artifacts:** `compatibility/INDEX`, `source registry`, `metric registry/contract`, `evidence policy`.
**Exit gate:** Документация согласована; protected runtime unchanged.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0005 — Psychological construct architecture
**Key work:**
- Построить construct dictionary без моральных ярлыков.
- Сопоставить Big Five/IPIP, HEXACO candidates, IPC, relational constructs.
- Найти дубли/коллинеарность и constructs without intended-use evidence.
- Сформировать licensing/translation decision table.
**Required artifacts:** `CONSTRUCT_MAP`, `REFERENCE_INSTRUMENT_PLAN`, `LICENSE_MATRIX`.
**Exit gate:** Каждый construct имеет определение, source, intended use, validation route.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0006 — Visual stimulus scientific redesign
**Key work:**
- Аудит 600 задач без изменения production до approval.
- Классифицировать paradigm/confounds/cueing.
- Собрать immutable asset/stimulus manifest.
- Создать KEEP/REWORK/CONTROL/REJECT research verdict.
**Required artifacts:** `STIMULUS_MANIFEST`, `ASSET_PROVENANCE`, `VISUAL_QA_REPORT`.
**Exit gate:** 600/600 tasks mapped and reviewer gaps recorded.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0007 — Reference calibration protocol
**Key work:**
- Выбрать reference scales по constructs.
- Подготовить consent, cohort and data dictionary.
- Спроектировать RU/UK/EN equivalence.
- Сделать precision/power/simulation plan.
**Required artifacts:** `CALIBRATION_PROTOCOL`, `CONSENT_PACK`, `POWER_PLAN`, `TRANSLATION_PROTOCOL`.
**Exit gate:** Independent protocol review before collecting decisive data.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0008 — Pilot instrumentation & data-quality
**Key work:**
- Логировать stimulus/version/position/latency/render metadata.
- Проверить position bias, entropy, missingness, device effects.
- Ввести research cohort flags and withdrawal.
- Запретить auto-mutation production loadings.
**Required artifacts:** `EVENT_SCHEMA`, `PILOT_QA_DASHBOARD`, `DATA_QUALITY_REPORT`.
**Exit gate:** Technical pilot produces complete reproducible events.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0009 — Psychometric calibration v1
**Key work:**
- Сравнить scoring/IRT/regularized candidate models.
- Проверить convergent/discriminant/test-retest.
- Зафиксировать locked holdout.
- Маркировать weak/confounded stimuli.
**Required artifacts:** `MEASUREMENT_MODEL_V1`, `VALIDATION_REPORT`, `STIMULUS_DISPOSITION`.
**Exit gate:** Model reaches PILOT_CALIBRATED or remains HYPOTHESIS; no forced PASS.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0010 — Psychological Compatibility Engine v1
**Key work:**
- Определить pair relations SIMILARITY/COMPLEMENTARITY/ASYMMETRIC/CONDITIONAL.
- Разделить role contexts.
- Сравнить с pure similarity baseline.
- Создать privacy-safe explanations.
**Required artifacts:** `PC_MODEL_SPEC`, `PAIR_FEATURE_REGISTRY`, `PC_VALIDATION_PLAN`.
**Exit gate:** PC versioned and testable; legacy hybrid not treated as validation.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0011 — Friend Compatibility outcome model
**Key work:**
- Определить exposure→reciprocity→quality→persistence outcomes.
- Ввести 30/90/180-day follow-up.
- Разделить user-reported and behavioral evidence.
- Контролировать opportunity/exposure bias.
**Required artifacts:** `FRIEND_OUTCOME_SCHEMA`, `SURVEY_PROTOCOL`, `BASELINE_MODEL`.
**Exit gate:** Prospective friendship outcome definitions frozen.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0012 — Interests Compatibility
**Key work:**
- Создать social/hobby taxonomy.
- Создать vocational/domain contour.
- Реализовать transparent overlap baseline.
- Спроектировать learned role-aware validation.
**Required artifacts:** `INTEREST_TAXONOMY`, `IC_BASELINE_SPEC`, `IC_VALIDATION_REPORT`.
**Exit gate:** IC v1 auditable and role-aware.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0013 — Values Compatibility
**Key work:**
- Построить value construct map.
- Исследовать circular/adjacency/conflict pair features.
- Калибровать indirect values stimuli.
- Проверить cross-language structure.
**Required artifacts:** `VALUE_MODEL`, `VC_PAIR_SPEC`, `VC_VALIDATION_REPORT`.
**Exit gate:** VC v1 evidence status explicitly assigned.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0014 — Communication Compatibility
**Key work:**
- Формализовать responsiveness/disclosure/autonomy/agency/conflict constructs.
- Разделить assessment and consented outcome data.
- Создать dyadic satisfaction protocol.
- Проверить incremental value over PC.
**Required artifacts:** `CC_CONSTRUCT_MAP`, `CC_MODEL_SPEC`, `DYADIC_PROTOCOL`.
**Exit gate:** CC has measurable inputs/outcomes without raw-chat surveillance.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0015 — Lifestyle Compatibility
**Key work:**
- Разделить hard constraints and soft preferences.
- Ввести privacy classification sensitive fields.
- Создать role-specific feasibility logic.
- Проверить incremental value over location.
**Required artifacts:** `LC_SCHEMA`, `CONSTRAINT_ENGINE_SPEC`, `SENSITIVE_DATA_POLICY`.
**Exit gate:** LC transparent and non-psychological.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0016 — Brotherhood Personality Type
**Key work:**
- Исследовать latent profile/cluster stability.
- Создать soft memberships instead of hard boxes.
- Разработать type descriptions as UX projection.
- Проверить incremental compatibility value over PC.
**Required artifacts:** `TYPE_MODEL`, `SOFT_MEMBERSHIP_SPEC`, `PT_PAIR_MATRIX`.
**Exit gate:** PT remains experimental unless data support it.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0017 — Enneagram compatibility
**Key work:**
- Audit instrument/typology assumptions.
- Separate primary type from wings/secondary claims.
- Create optional pair matrix.
- Validate user utility and dyadic signal.
**Required artifacts:** `EN_METHOD_VERSION`, `EN_LIMITATIONS`, `EN_PAIR_SPEC`.
**Exit gate:** Clearly labeled typological/experimental.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0018 — Numerology compatibility
**Key work:**
- Audit existing Vedic/date engine.
- Name exact tradition/version.
- Separate name/date/self-analysis/pair contours.
- Create deterministic pair tests and explanations.
**Required artifacts:** `NU_TRADITION_SPEC`, `NU_PAIR_TABLE`, `NU_REPRO_TESTS`.
**Exit gate:** Same inputs/version produce same result; no psychometric claim.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0019 — Astrology/Zodiac compatibility
**Key work:**
- Separate basic zodiac from future synastry.
- Document calendar/timezone/ephemeris rules.
- Store negative scientific evidence disclosure.
- Create deterministic alternative score.
**Required artifacts:** `AS_BASIC_SPEC`, `AS_EVIDENCE_NOTICE`, `AS_REPRO_TESTS`.
**Exit gate:** Alternative method is transparent and isolated.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0020 — Quality Fit v2
**Key work:**
- Version search_request and desired-quality vectors.
- Separate must-have/soft priorities.
- Build directional candidate evidence matching.
- Validate role-specific outcomes and temporal integrity.
**Required artifacts:** `QF_V2_SPEC`, `SEARCH_REQUEST_SCHEMA`, `QF_VALIDATION`.
**Exit gate:** QF is directional, separate from Overall.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0021 — Trust + Coverage architecture
**Key work:**
- Define Trust operational evidence and appeals.
- Prohibit psychometric morality score.
- Define per-metric Coverage/reliability/recency.
- Design UI separation.
**Required artifacts:** `TRUST_CONTRACT`, `COVERAGE_CONTRACT`, `APPEAL_POLICY`.
**Exit gate:** TR/DC never silently weight Compatibility.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0022 — Compatibility data/API platform
**Key work:**
- Design metric/model/version registry tables.
- Store pair snapshots and checkbox selections.
- Expose API for overview/detail/history.
- Add audit/privacy/retention boundaries.
**Required artifacts:** `DB_MIGRATION_PLAN`, `OPENAPI_CONTRACT`, `AUDIT_SCHEMA`.
**Exit gate:** Data/API platform supports independent metrics reproducibly.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0023 — Compatibility service UI — Diia model
**Key work:**
- Build one service overview page.
- Group metrics by evidence family.
- Implement role selector and checkboxes.
- Implement detail page per metric + QF/TR separate.
**Required artifacts:** `ANDROID_UI`, `HTML_PARITY`, `VISUAL_QA`.
**Exit gate:** Stable nav, light/dark parity, owner acceptance, APK checkpoint.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0024 — Person resume/profile — early VK depth
**Key work:**
- Deep public resume.
- Skills/interests/goals/communities.
- Compatibility entrypoint without latent disclosure.
- Serious male-club visual language.
**Required artifacts:** `PROFILE_IA`, `RESUME_FIELDS`, `PRIVACY_MATRIX`.
**Exit gate:** Candidate page supports serious search, not shallow dating.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0025 — Discovery/search requests
**Key work:**
- Role-aware search requests.
- Filters and recommended candidates.
- Swipe only inside recommendations.
- E2E search→resume→compatibility→message.
**Required artifacts:** `DISCOVERY_ENGINE`, `SEARCH_REQUEST_UI`, `E2E_TESTS`.
**Exit gate:** APK checkpoint with live/product-parity route flow.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0026 — Telegram-class communication
**Key work:**
- Direct/group delivery lifecycle.
- Outbox/retry/receipts.
- Reply/reactions/edit/delete/attachments.
- Security/E2EE/moderation hardening.
**Required artifacts:** `CHAT_RUNTIME`, `DELIVERY_TESTS`, `SECURITY_REVIEW`.
**Exit gate:** Message E2E and offline recovery pass.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0027 — Communities/business club
**Key work:**
- Interest/local/business/project/mutual-aid groups.
- Owner/admin/member roles.
- Events/projects/member discovery.
- Moderation/appeals/audit.
**Required artifacts:** `COMMUNITY_MODEL`, `ROLE_POLICY`, `COMMUNITY_E2E`.
**Exit gate:** Communities connect people and practical collaboration.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0028 — Longitudinal outcome platform
**Key work:**
- Collect exposure and relationship outcome chain.
- 30/90/180 follow-ups.
- Pseudonymous research exports.
- Protect against feedback/selection bias.
**Required artifacts:** `OUTCOME_PIPELINE`, `RESEARCH_EXPORT`, `RETENTION_POLICY`.
**Exit gate:** Prospective outcomes reproducible and consented.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0029 — Model validation/fairness/replication
**Key work:**
- Run locked holdout by metric.
- Cross-language/subgroup checks.
- Compare simple baselines.
- Independent verifier + replication/rollback decision.
**Required artifacts:** `VALIDATION_PACK`, `FAIRNESS_REPORT`, `REPLICATION_PLAN`.
**Exit gate:** Each metric gets honest verdict; failures remain failures.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.

### 0030 — Full investor simulation + production RC
**Key work:**
- Full release-parity HTML simulation.
- Backend/tables/routes/metric states parity.
- Security/privacy/device matrix.
- Frozen model manifests + staged rollout/rollback.
**Required artifacts:** `INVESTOR_DEMO`, `RELEASE_ARCHIVE`, `RC_VERIFICATION`.
**Exit gate:** No simplified mock; final APK/AAB checkpoint only after all critical gates.
**Regression boundary:** protected assessment/runtime mechanics are not changed unless this cycle explicitly reaches an owner-authorized implementation task and the protected-mechanics gate is updated by evidence, never merely to satisfy a test.
