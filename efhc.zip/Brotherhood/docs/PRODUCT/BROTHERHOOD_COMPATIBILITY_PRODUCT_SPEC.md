# Brotherhood Compatibility — Product Specification

Status: **ACTIVE OWNER-CANON PRODUCT SPEC**

## 1. Purpose
Compatibility помогает пользователю сравнить конкретную пару по независимым системам. Нет одной универсальной «истины о совместимости».

## 2. Metric groups
### Scientific / empirical research track
- `psychology`
- `interests`
- `values`
- `communication`
- `lifestyle`

### Typological track
- `personality_type`
- `enneagram`

### Traditional / alternative track
- `numerology`
- `astrology`

## 3. Score contract
Каждый engine возвращает собственный **точный вычисленный результат текущей утверждённой версии алгоритма** в диапазоне `0..100%`. Для одинаковых `model_version + role_context + input_snapshot` детерминированный алгоритм обязан воспроизводить то же значение. При утверждённом обновлении алгоритма новая версия может дать другой точный результат `0..100%`.

В обычном пользовательском интерфейсе результат показывается прямо как Compatibility `%`, без повторяющихся оговорок «не доказано». Технически этот процент не обязан означать статистическую вероятность будущего события (`P(success)`), если отдельная probability-calibration модель специально не установила такую семантику.

## 4. Overall
Пользователь выбирает метрики галочками. При одной выбранной доступной метрике Overall совпадает с её score. При `N>1`: `Overall = sum(selected_available_scores) / N`.

Запрещены hidden inter-metric weights, включая legacy `psychology 50%`, `numerology 5%`, `zodiac small weight` и любые аналоги. Evidence/coverage могут отображаться отдельно, но не превращаются скрыто в cross-metric multiplier.

## 5. Role context
`role_context` отвечает «для чего сравниваем». Одна и та же Psychology metric может иметь разные validated role-specific pair models для friend/business_partner/worker_team/mentor/project_partner/activity_partner.

## 6. Quality Fit and Trust
Quality Fit — асимметричен и строится относительно SearchIntent. Trust — operational reliability/verification indicator. Ни один из них не входит автоматически в Overall Compatibility.

## 7. Missing data
Недостаточный data coverage не заменяется score `0`. Engine возвращает `INSUFFICIENT_DATA`/coverage metadata. Aggregator считает среднее только по выбранным метрикам с допустимым результатом и явно показывает фактическое число методов.

## 8. Explanations
Допустимы pair-level explanations («стили принятия решений могут хорошо дополнять друг друга»). Запрещено раскрывать raw latent profile/скрытый personality type кандидата.

## 9. Evidence labeling
Metric result обязан иметь method/model version и evidence status. Scientific, typological и traditional systems визуально/текстово не маскируют различия evidence class.

## 10. Runtime status at cycle 0004
Это target spec. Текущий Android legacy aggregate подтверждён как implementation gap и не изменяется в документационном цикле.
