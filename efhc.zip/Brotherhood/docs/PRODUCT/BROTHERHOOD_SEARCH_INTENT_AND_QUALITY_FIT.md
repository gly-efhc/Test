# Brotherhood SearchIntent & Quality Fit

Status: **ACTIVE PRODUCT BOUNDARY**

## 1. SearchIntent
SearchIntent — versioned запрос одного пользователя к типу человека для конкретной роли. Он может содержать role, desired qualities, constraints, preferences, location/activity requirements и публично объяснимые criteria.

## 2. Quality Fit
`QF(searcher → candidate, intent)` отвечает: насколько candidate соответствует текущему SearchIntent. Поэтому результат принципиально асимметричен.

## 3. Separation from Compatibility
Compatibility сравнивает пару по конкретной системе. Quality Fit сравнивает candidate с желаемым вектором/ограничениями searcher. QF не включается в simple-mean Overall Compatibility без нового прямого owner decision.

## 4. Private data boundary
Quality Fit может использовать разрешённые private measurements кандидата, но explanation не раскрывает raw latent coordinates, hidden personality type или sensitive inference.

## 5. Constraints vs preferences
Hard constraints должны обрабатываться отдельно от soft preferences, чтобы «не соответствует обязательному условию» не маскировалось средним score.

## 6. Validation
До outcome validation Brotherhood-specific mappings `desired quality → latent feature` и coefficients имеют статус `HYPOTHESIS/REQUIRES_VALIDATION`. Production activation требует versioned model, tests, privacy review and owner/release approval.

## 7. Cycle 0033 active runtime contract

Implemented version set:
- SearchIntent contract: `quality-fit-search-intent-v2`;
- catalog: `quality-fit-catalog-v2`;
- directional scorer: `quality-fit-directional-v2`;
- direction: `SEARCHER_A_TO_CANDIDATE_B`.

Only explicit user-selected requirements participate. A role name never injects hidden default personality requirements. Each requirement is either `preference` or `hard`; hard requirements retain their own pass/fail eligibility semantics. Candidate evidence missing for a requested quality remains `INSUFFICIENT_DATA` and is excluded from score arithmetic rather than converted to zero.

The v2 runtime stores intent/evidence fingerprints, confidence, availability, eligibility, per-requirement breakdown, missing keys and explanation so a saved evaluation can be audited and reread. Quality Fit remains separate from Q28 Compatibility, Trust, Account Rating and Hospitality Reputation.
