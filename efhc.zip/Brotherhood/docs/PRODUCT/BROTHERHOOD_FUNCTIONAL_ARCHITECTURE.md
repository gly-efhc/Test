# Brotherhood — функциональная архитектура

Status: **ACTIVE PRODUCT ARCHITECTURE / DOCUMENTATION-ONLY TARGET**

## 1. Functional domains
1. Identity & Auth — provider identity → `global_id`, session/security boundary.
2. Public Resume — мужской профиль-резюме, навыки, цели, интересы, проекты, privacy controls.
3. Tests & Measurement — защищённый indirect visual assessment, результаты, retest/version history.
4. Private Latent Profile — закрытые versioned measurements; не публичный label.
5. SearchIntent — роль, желаемые качества, обязательные/предпочтительные ограничения.
6. Compatibility Registry — независимые metric engines и их evidence/model versions.
7. Quality Fit — асимметричное соответствие SearchIntent.
8. Trust — identity/reliability/moderation evidence; отдельный от Compatibility.
9. Discovery — фильтры, recommended candidates, карточки/swipes только внутри discovery.
10. Messaging — прямые и групповые коммуникации.
11. Communities — клубы, проекты, взаимопомощь, events, moderation.
12. Research Platform & Longitudinal Outcomes — versioned score/exposure snapshots, explicit feedback, side-specific relationship statuses, opt-in outcomes, causal evaluation datasets and reviewed model governance.
13. Simulation — full contract mirror для investor-facing HTML.

## 2. Core decision flow
`Public resume + selected Compatibility metrics + Quality Fit + Trust → user decision → direct communication`.

Ни один из трёх вычисляемых контуров не является моральным рейтингом человека.

## 3. Compatibility service contract
Каждый metric engine принимает pair identity/context + разрешённые private measurements и возвращает versioned result: `metric_id`, `role_context`, `score_0_100`, `coverage`, `data_freshness`, `evidence_status`, `model_version`, `explanation_policy_version`.

`Overall` вычисляется только на presentation/service aggregation layer как среднее выбранных доступных metric scores; отсутствующие метрики не подставляются как нули.

## 4. Separation rules
- Quality Fit не является Compatibility metric.
- Trust не является Compatibility metric.
- Data Coverage/Confidence не является Compatibility metric.
- Scientific evidence class не является score multiplier.
- Numerology/Astrology не входят автоматически в Psychology.

## 5. Role context
Минимальный registry: `friend`, `business_partner`, `worker_team`, `mentor`, `project_partner`, `activity_partner`. Одна метрика может иметь разные role-specific модели/критерии; это не скрытые cross-metric weights.

## 6. Research lifecycle
`source → claim → construct → reference measure → hypothesis → cohort → validation → candidate model → approval → production version`.

Любая Brotherhood-specific pair relation до validation: `HYPOTHESIS / REQUIRES_VALIDATION`.

## 7. Persistence target (future implementation)
Будущая backend/database архитектура должна хранить model manifests, metric results, user-selected preferences, role context, coverage/freshness, validation runs и opt-in longitudinal outcomes. Cycle 0004 не создаёт migrations и не меняет runtime schema.

## 8. Simulation parity
Simulation обязана зеркалировать те же сущности, маршруты, состояния и scoring contract, которые существуют в production runtime конкретной версии. Запрещён отдельный упрощённый demo-scoring.

## 9. Q35 research data flow
`pre-exposure input snapshot → exact metric/model scores → recommendation policy/rank → actual exposure → explicit action → interaction opportunity → voluntary status/outcome → versioned research dataset → candidate model → locked validation → owner/release approval`.

Future implementation must preserve this chain so model-generated exposure is not mistaken for random observation. Raw private message semantics are not a default research input. Relationship statuses are multi-label/side-specific; mutual confirmation requires two explicit reports.
