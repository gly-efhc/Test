# Brotherhood Information Architecture

Status: **ACTIVE TARGET IA — OWNER Q45**.

## Level 0 — Auth
Provider authentication and session recovery.

## Level 1 — Root navigation
Exactly five root destinations in this order:
1. `Профиль`;
2. `Люди`;
3. `Чаты`;
4. `Группы`;
5. `Развитие`.

The former authenticated `Home/Главная` root is superseded.

## Level 2 — Root-domain applications
### Профиль
Own digital resume/public representation, edit/privacy actions, reputation summaries and links to private self-knowledge. Pair Compatibility requires a second person and is absent from self-profile.

### Люди
Discovery, filters, Search Requests, candidate resume, independent Compatibility, Quality Fit, Trust summary and direct message transition.

### Чаты
Direct/group conversation list and Telegram-class messaging actions.

### Группы
Communities, group membership, projects/interests/events and group communication.

### Развитие
Diia-style service catalog. Primary standalone applications:
- `Тесты`;
- `Нумерология`;
- `Зодиак`.

Every Development card opens a complete feature application rather than a teaser route. See `BROTHERHOOD_DEVELOPMENT_HUB_CANON.md`.

## Level 3 — Development application flows
### Tests
Catalog → system → instructions → execution/resume → result → history/reread → Psychological Profile → Psychological Report. Future associative/implicit instruments appear inside this app as independent methods.

### Numerology
Personal profile → dates/cycles → characteristics/components → comparison → numerological compatibility → history/version.

### Zodiac
Personal zodiac profile → characteristics/context → comparison → zodiac compatibility → history/version where supported.

## Level 4 — Detail routes
Compatibility metrics, test constructs/results, numerology components and zodiac details each receive dedicated detail routes. Technical/research admin surfaces never leak into ordinary navigation.

## Stable-shell rule
Authenticated nested routes preserve the five root destinations unless a deliberately immersive execution flow has predictable Back behavior.

## Back behavior
System Back restores previous route/state/scroll where feasible; it does not arbitrarily throw the user to an obsolete Home route.
