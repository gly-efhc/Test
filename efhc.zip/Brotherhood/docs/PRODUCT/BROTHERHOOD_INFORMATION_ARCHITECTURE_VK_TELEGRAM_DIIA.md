# Brotherhood — Information Architecture: VK + Telegram + Diia principles

Status: **ACTIVE IA PRINCIPLES**

## 1. Используемые принципы, не чужой продукт
Brotherhood не копирует VK, Telegram или Diia. Разрешено использовать только высокоуровневые UX/IA-принципы.

## 2. Early-VK principle — person-centered depth
Кандидат — не фотография и не одноразовая swipe-card. Его canonical destination — содержательный профиль-резюме: биография, профессиональная роль, навыки, проекты, интересы, сообщества, связи и добровольно публичные достижения.

## 3. Telegram principle — communication immediacy
Из discovery/profile/compatibility detail должен существовать короткий путь к прямому сообщению. Mutual Match не является prerequisite.

## 4. Diia principle — service modularity
Сложные вычисления представляются как спокойные самостоятельные сервисы: отдельные строки Psychology, Interests, Values, Communication, Lifestyle, Personality Type, Enneagram, Numerology, Astrology; отдельные блоки Quality Fit и Trust; ясный role selector.

## 5. Brotherhood principle — private multidimensional identity
Пользователь получает полезные позитивные результаты собственных тестов, но скрытые latent coordinates/типы кандидата не раскрываются. Система объясняет совместимость на безопасном уровне pair interaction, а не раскрытием частного профиля другого человека.

## 6. Home
Только четыре главных действия: Поиск людей, Сообщения, Тесты, Поисковые запросы. Остальные функции входят через эти домены или профиль/настройки.

## 7. Compatibility information architecture
Candidate header → role context → optional Overall → grouped metric rows → Quality Fit → Trust → message action. Каждая metric row открывает detail page с score, concise interpretation, coverage/freshness, methodology/evidence status и version history where relevant.

## 8. Boundaries
Dating-like cards/swipes допустимы только внутри recommendation discovery. Романтический dating framing запрещён. Большая фотография не заменяет profile resume.
