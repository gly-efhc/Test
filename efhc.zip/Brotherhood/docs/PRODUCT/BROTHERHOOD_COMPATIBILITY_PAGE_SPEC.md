# Brotherhood — Compatibility Page Product Specification

Status: **TARGET UX SPEC**.

## Header
Back, candidate photo/name/age-city-profession summary, optional message shortcut.

## Role selector
`Сравниваем как: Друг / Бизнес-партнёр / Работник / Наставник / Проектный партнёр / ...`
Changing role refreshes only metrics with role-specific model while preserving selections where supported.

## Overall card
Shows arithmetic mean and exact count of selected available metrics. If none selected: “Выберите методики”. Overall is visually secondary to individual metrics.

## Metric groups
### Научные/эмпирические методики
PC, IC, VC, CC, LC.

### Типологии
PT, EN.

### Альтернативные
NU, AS.

Each row:
`[checkbox] icon/name | score or unavailable | coverage/freshness | >`.

## Separate blocks
- `Соответствие вашему запросу (QF)`;
- `Trust`;
- `Достаточность данных` where needed.

They are not checkboxes for Overall.

## Metric detail template
- metric name;
- pair + role context;
- 0..100 score;
- verbal band without deterministic labels;
- 3–5 dyad-level reasons;
- coverage + freshness;
- method family/evidence status;
- “Как рассчитывается”;
- “Научная база / ограничения”;
- model version/history if useful.

## Privacy
Never reveal candidate raw trait values, test responses, hidden type, diagnostic labels or sensitive research features.

## Diia-inspired principle
One clean service page -> one detail page per method -> technical detail only on demand. No single screen should expose the research cockpit.
