# Brotherhood — VK + Telegram + Diia Hybrid Product Architecture

Status: **ACTIVE UX/PRODUCT REFERENCE ARCHITECTURE**.

## Reference rule
References provide patterns, not data, branding or blind code copying.

## 1. VK contribution — person depth
Use the early social-network idea that a person profile is a meaningful page, not a shallow dating tile:
- resume-like identity;
- biography/activity;
- interests;
- profession/skills;
- communities;
- social context;
- direct path to communication.

Brotherhood adds privacy boundaries: hidden psychometric profile never becomes a public questionnaire dump.

## 2. Telegram contribution — communication
- immediate message without match gate;
- direct/group chat;
- low-friction compose/reply;
- clear delivery states;
- media/attachment architecture;
- chat is the natural continuation of candidate discovery.

## 3. Diia contribution — service discipline
The official Diia Android open-source project is modularized into feature areas such as home, publicservice, documents, notifications, menu, search and others, and describes the product goal as interaction in a few clicks. Brotherhood uses this **information architecture principle**:
- each complex domain is a service;
- short routes;
- stable shell;
- detail screen on demand;
- no giant dashboard exposing every control at once.

## 4. Brotherhood synthesis
```text
Profile
  -> own resume / edit / privacy / reputation
People
  -> search + Search Requests -> Candidate -> Compatibility -> Message
Chats
  -> direct / group communication
Groups
  -> communities / projects / members / group chats
Development
  -> Tests
      -> test -> result -> history -> Psychological Profile/Report
  -> Numerology
      -> profile -> dates/cycles -> characteristics -> comparison/compatibility
  -> Zodiac
      -> profile -> characteristics -> comparison/compatibility
```

`Development` replaces the former Home root and uses Diia-style service discipline: catalog → standalone feature flow → summary → details → deep details.

## 5. Compatibility as a Diia-like service
The Compatibility page must feel like a collection of clear service cards/rows, not a scientific cockpit. Groups: empirical-development, typology, alternative. QF/Trust are separate blocks.

## 6. Visual direction
Modern, serious, masculine, restrained. Large candidate photo is allowed, but resume information and practical context must compete with image prominence. Light/dark themes receive equal design quality.

## 7. Anti-patterns
- dating-only swipe shell as the entire app;
- Development as a wall of analytics;
- technical research terms on every public screen;
- disappearing bottom navigation;
- dozens of unrelated CTAs per screen;
- copying reference-app data/content.
