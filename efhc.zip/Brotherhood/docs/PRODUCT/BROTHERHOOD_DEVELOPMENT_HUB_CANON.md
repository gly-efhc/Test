# Brotherhood Development Hub Canon

Status: **ACTIVE OWNER CANON — 2026-08-13**

## Root navigation
The authenticated root shell has exactly five primary destinations, in this order:

1. `Профиль`
2. `Люди`
3. `Чаты`
4. `Группы`
5. `Развитие`

The former authenticated `Главная/Home` root destination is superseded. `Развитие` takes its root-navigation slot.

## Meaning of each root destination
### Профиль
The user's own social/professional page and digital resume: identity, bio, work, skills, projects, interests, goals, reputation summaries and compact links into private self-knowledge products. It must closely match what another person sees, plus owner-only edit/privacy actions. Pair Compatibility never appears without a second person.

### Люди
Discovery/search of people and search-intent flows: search, filters, recommendations, candidate pages, independent compatibility, Quality Fit and direct transition to communication.

### Чаты
Direct and group conversations with Telegram-class interaction mechanics. This is communication, not a second people-search surface.

### Группы
Communities, groups, projects and shared-interest contexts with membership and group communication.

### Развитие
A Diia-style service catalog for self-development/self-knowledge modules. It is not an analytics dashboard. Every card opens a **standalone feature application** with its own navigation, actions, state, history and results.

Primary Development applications are:
- `Тесты`;
- `Нумерология`;
- `Зодиак`.

Additional independent modules may be added only when productized (for example Enneagram or future associative/implicit instruments). They do not become root tabs.

## Standalone-app rule
Each Development module must be usable end-to-end, not as a teaser card.

### Tests app
User-facing product layer: **12 standalone thematic test apps** over the current **197 scientific questionnaire items / 7 internal metric systems**. The user sees understandable test topics; the metric layer remains internal and versioned. Every active questionnaire item belongs to exactly one user-facing app.

Minimum product flow:
`catalog → test system → instructions → execution/resume → scoring → result → history → reread result → Psychological Profile → Psychological Report`.

Each user-facing test keeps its own saved result/history. Its dimensions update the parent scientific system; the 7 internal systems keep independent compatibility `0–100%` where common supported constructs exist.

### Numerology app
Minimum product flow:
`input/current birth data → personal numerology profile → dates/cycles → characteristics → component details → pair comparison → numerological compatibility → history/version`.

Numerology remains independent from psychology and Trust.

### Zodiac app
Minimum product flow:
`birth data → zodiac profile → characteristics → date/context views where supported → pair comparison → zodiac compatibility → history/version`.

Zodiac/astrology remains independently labeled and is not psychological evidence.

**Cycle 0031 implementation:** `AS_ZODIAC_BASIC_V1` is source/HTML implemented with immutable birth-date-derived readings/history, a 12-sign catalog, transparent basic sign/group rules, and persisted independent AS pair comparison/history. Full natal/synastry mechanics are not active. Owner VA remains pending; therefore Android still has the pre-Q45 root HOME mirror and has not yet received the `Развитие` Compose tab.

## Diia donor rule
Brotherhood borrows the service-architecture principle: simple catalog → one feature flow → summary → details → deep details, with reusable top/body/bottom shells and predictable Back behavior. Brotherhood does not copy Diia branding, assets or state/business data.

## Progressive disclosure
Complexity is moved into detail routes; it is not deleted. Root screens remain calm, while every standalone module retains full capability behind its own navigation.


### Current Tests v1 catalog
1. Большая пятёрка
2. Самодисциплина
3. Гибкость и любознательность
4. Стиль отношений
5. Общение
6. Конфликт и эмпатия
7. Доверие и границы
8. Решения и риск
9. Работа и проекты
10. Роль в группе
11. Стресс и неопределённость
12. Адаптивность и энергия

The catalog is a product partition, not twelve unrelated scientific theories. Source/scoring authority remains the unified scientific questionnaire bank and the parent scientific-system mapping.

## Cycle 0033 service-first presentation

The active standalone Development demo uses a calm service catalog. Each current module is a full app, but the hub itself should expose only enough information to answer: what is this, what state is it in, and what can I do next. Dense decorative badges/cards are not a requirement and should not obscure navigation.

For Tests specifically:
- show all 12 apps as scannable service rows;
- surface completion state/date and retake availability directly;
- one question per execution screen;
- keep progress visible without technical scoring information;
- result reading prioritizes interpretation and useful next observations over raw model/provenance details;
- saved result/history/retake remain first-class functionality;
- background simulation events must not reset current reading scroll/focus.

This presentation rule does not change the scientific questionnaire bank, scoring or compatibility contracts.
