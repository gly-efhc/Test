# Brotherhood — Project Description 2026

Status: **ACTIVE PRODUCT DESCRIPTION**.

## 1. Product identity
Brotherhood is a male-only 18+ social/business club and people marketplace for finding male friends, business/project partners, workers/specialists, mentors, teams, activity partners and mutual-aid contacts.

It is not a romantic dating product. Dating-like interaction patterns (large candidate cards, swipe, match percentages) are used only where they make candidate discovery efficient.

## 2. Core differentiation
Brotherhood combines:
1. deep resume-like person profiles;
2. direct Telegram-class communication;
3. service-oriented Diia-like information architecture;
4. private longitudinal psychological/behavioral profile;
5. independent compatibility metrics selected by the user;
6. directional Quality Fit to the user’s explicit search request;
7. Trust and Data Coverage as separate reliability signals;
8. communities and practical collaboration;
9. role-specific people search: friend, business/project partner, worker/team, mentor and activity contexts;
10. Hospitality & Stays as infrastructure for trusted real-world meetings and verified interactions, not a lodging marketplace.

## 3. User value loop
```text
join -> create public profile/resume -> use app normally
     -> voluntarily complete useful/free assessments
     -> private profile becomes richer
     -> create search request / browse recommendations
     -> choose compatibility metrics
     -> inspect candidate + QF + Trust
     -> message immediately
     -> optionally coordinate real-world interaction / Hospitality stay
     -> verified interaction evidence where both sides confirm the event
     -> voluntary relationship/collaboration outcomes
     -> with consent, outcomes improve future validated models
```

## 4. Root navigation and Development
Owner Q45 supersedes the former authenticated Home. The root shell is exactly `Профиль → Люди → Чаты → Группы → Развитие`. Profile is the first/default authenticated page. Search Requests belong under People.

`Развитие` is a calm Diia-style service catalog. Its primary standalone applications are `Тесты`, `Нумерология`, `Зодиак`; each opens a complete feature flow with state, actions, details, history and results.

## 5. Candidate concept
Candidate page is closer to a serious early-VK resume than a dating card:
photo, name, age where public, city, occupation/activity, skills, interests, goals, groups, verification, public experience, selected compatibility results, QF and Trust. Hidden psychological traits are not disclosed.

## 6. Compatibility philosophy
No universal “truth score”. Every method has an independent 0..100 index. User chooses checkboxes. Optional Overall is the simple arithmetic mean of selected available metrics. Individual scores remain primary.

## 7. Research philosophy
Brotherhood uses a multi-method psychological architecture. The active conscious/situational baseline is seven scientific questionnaire systems / 197 items. Associative/implicit methods (free association, word association, IAT/reaction-time) are a separate high-priority lane, while observed behavior/outcomes form a later evidence channel from launch-day provenance. No single method is treated as the whole person. Numerology/astrology remain independent optional systems and are clearly labeled.


## 8. Hospitality and real-world relationships
Hospitality & Stays extends Brotherhood from people discovery into trusted offline coordination. A member may volunteer as a host, publish safe conditions/availability and admission requirements, and another member may request a stay through the existing People/Profile/E2EE-chat architecture. Exact arrival data remains private until acceptance; a completed calendar lifecycle is not itself proof of a physical visit. Bilateral confirmation may create a versioned verified `hospitality_stay` interaction, while blind reviews and moderation/appeal due process contribute to a separate Hospitality Reputation/Trust evidence layer.

Product meaning: Hospitality is not scored as a hidden Compatibility bonus and a verified stay is not automatically labeled friendship. Its value is that Brotherhood can support the progression `discover -> understand -> communicate -> meet -> optionally confirm a real interaction -> continue a relationship`, including international/cross-city connections.

## 9. Research Platform differentiation
Brotherhood can evaluate future algorithms against privacy-safe, consented longitudinal outcomes rather than treating clicks or message counts as final success. Hospitality adds a particularly informative real-world interaction event to that research chain, while historical recommendation/model/exposure provenance remains frozen and production models never auto-learn from outcomes.

## 10. Product style
- VK: person-centered profile/resume, groups and social graph depth;
- Telegram: immediate communication and lightweight messaging flows;
- Diia: clear service modules, minimal route friction and disciplined hierarchy;
- Brotherhood: matching/research engine and male club identity.

## 11. Investor demo
Demo HTML must simulate full release behavior, not a reduced mock. Research status labels remain honest even in investor presentation.
