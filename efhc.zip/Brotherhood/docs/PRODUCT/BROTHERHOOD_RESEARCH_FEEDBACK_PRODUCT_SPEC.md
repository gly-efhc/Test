# Brotherhood Research Feedback Product Spec

Status: **PRODUCT/RESEARCH SPEC — Cycle 0014 / IMPLEMENTATION NOT YET AUTHORIZED**

## Goal
Turn Brotherhood into a useful social product **and** a privacy-governed research base that can measure whether versioned compatibility/search algorithms are associated with later real outcomes.

## Candidate-page feedback primitives
Future UI may expose small, non-coercive actions after a recommendation or interaction:
- `Подходит / Интересно` (`INTERESTED`)
- `Возможно` (`MAYBE`)
- `Не подходит сейчас` (`NOT_RELEVANT_NOW`)
- structured reason selector (optional)
- `Написать`
- `Сохранить`
- `Обновить статус отношений`

Negative feedback must not morally downgrade a candidate and must remain contextual to viewer + role + time.

## Relationship status center
Each user may privately declare relationship statuses with another user. Statuses are multi-label and side-specific. Suggested product groups:
- connection: acquaintance / chatting;
- friendship: friend / close_friend;
- activities: activity_partner;
- projects/business: project_partner / business_partner;
- mentoring: mentor / mentee;
- work: worker_team;
- lifecycle: ended_contact.

Mutual confirmation is separate metadata, never assumed.

## Outcome prompts
Prompting is event/window based, rate-limited and skippable. Candidate windows for research design: `7/30/90/180/365 days`; exact production cadence remains configurable and requires UX review.

Possible structured questions:
- still interacting?
- would connect again?
- relationship/status changed?
- met or did a shared activity? (optional)
- project/partnership started? active? completed? (role-specific)
- expectations matched?
- overall relationship/project quality (versioned response scale)
- if ended, optional structured reason;
- `not enough interaction to judge`.

## Research transparency
Research participation is explicit. The app should explain that feedback helps evaluate and improve future versions of matching algorithms. Product functionality must not depend on granting optional research consent unless a function genuinely requires the data.

## No message-content default
The research platform may use structural communication signals under the relevant consent/purpose, but it does not read/analyze private message text by default.

## Data model requirement for future implementation
Every evaluable recommendation must make it possible to reconstruct:
`what the model knew → what it scored → what was shown → what the user did → what happened later`.

Historical snapshots are immutable research provenance. Recomputing an old pair with a new model creates a new evaluation record; it does not overwrite the old one.

## Implementation sequence
1. event/status contract review;
2. privacy/consent review;
3. backend/PostgreSQL schema cycle;
4. API + idempotency;
5. 13-locale UI strings/native QA;
6. release-parity simulation;
7. controlled pilot;
8. research analysis pipeline;
9. candidate model validation;
10. owner-approved production promotion.
