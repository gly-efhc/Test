# Brotherhood — описание проекта

Status: **ACTIVE PRODUCT DESCRIPTION**  
Owner-canon basis: Q02, Q23, Q26, Q28; cycle `0004` documentation foundation.

## 1. Сущность продукта
Brotherhood — мужская социально-деловая сеть и people marketplace для мужчин 18+. Продукт предназначен для поиска друзей, общения, бизнес- и проектных партнёров, специалистов, участников команд, наставников/учеников, партнёров по хобби/спорту/путешествиям, взаимопомощи, клубов и сообществ.

Brotherhood **не является романтическим dating-приложением**. Романтический женский контур не входит в продуктовый scope.

## 2. Продуктовая формула
`ранний VK + Telegram + Diia + Brotherhood identity` означает только заимствование общих UX/IA-принципов:
- ранний VK: человек и содержательный профиль-резюме как центр системы;
- Telegram: быстрый переход от найденного человека к прямому сообщению;
- Diia: спокойная сервисная модульность и дисциплина информации;
- Brotherhood: скрытый многомерный профиль, необязательные непрямые тесты, независимые Compatibility Engines, Quality Fit, Trust, SearchIntent и people marketplace.

Копирование чужих данных, брендинга, ассетов или бизнес-логики запрещено.

## 3. Корневая навигация
Owner Q45 отменяет прежнюю authenticated Home как корневую страницу. Пять корневых разделов идут строго так:
1. Профиль.
2. Люди.
3. Чаты.
4. Группы.
5. Развитие.

`Развитие` — спокойный Diia-подобный каталог самостоятельных приложений: `Тесты`, `Нумерология`, `Зодиак`. Поисковые запросы входят в раздел `Люди`. Candidate cards/swipes допустимы только внутри рекомендованного поиска.

## 4. Профиль и общение
Публичный профиль — серьёзное мужское резюме/анкета: биография, цели, компетенции, интересы, проекты, навыки, сообщества и добровольно раскрываемые факты. Приватный latent profile не раскрывается другому пользователю.

Прямое сообщение разрешено без Mutual Match.

## 5. Три независимых контура принятия решения
- **Compatibility**: как два конкретных человека сочетаются по отдельной выбранной системе.
- **Quality Fit**: насколько кандидат соответствует SearchIntent конкретного ищущего пользователя; асимметричен.
- **Trust**: надёжность/верификация/поведенческая история; не является совместимостью.

Эти контуры не усредняются друг с другом.

## 6. Compatibility canon
Каждая compatibility-метрика имеет самостоятельный score `0..100`. Пользователь сам выбирает метрики галочками. Если выбрано более одной доступной метрики, `Overall` — только простое арифметическое среднее выбранных scores. Скрытые межметрические веса запрещены.

Научно-эмпирические, типологические и традиционные/альтернативные системы могут сосуществовать, но обязаны иметь честный evidence status и не выдавать один тип доказательств за другой.

## 7. Тесты и многометодная психология
Тесты необязательны, но являются важным исследовательским и пользовательским контуром. Активная conscious/situational линия — 7 научных систем / 197 заданий. Удалённая ветка 100×6/600 не является runtime authority.

Следующий приоритет — независимые ассоциативные/имплицитные методы: Jung Word Association, Freud Free Association, IAT/reaction-time. После запуска отдельно накапливается observed-behavior/outcome provenance. Ни один канал не подменяет остальные и не смешивается скрытыми весами.

## 8. Simulation
Investor HTML — release-parity simulation, а не mockup: реальные контракты → Backend Simulator → Simulation Engine → полный frontend mirror. Fixture — синтетические данные настоящего контракта, но не упрощённая бизнес-логика.

## 9. Research-to-production boundary
Научные источники и outcomes создают evidence для анализа. Они **не меняют production model автоматически**. Разрешённая цепочка: `outcomes → research analysis → human/scientific review → versioned candidate model → validation → owner/release approval → production`.

## 10. Research platform — Q35
Brotherhood дополнительно является исследовательской базой. При добровольном research participation продукт может связывать **исторический versioned Compatibility/Quality Fit/Trust snapshot** с фактом реального показа кандидата, явной обратной связью, side-specific relationship statuses и последующими longitudinal outcomes. Рекомендательная политика/rank/exposure являются частью provenance. `No exposure/no click/no reply` не равны отрицательной совместимости. Любое улучшение алгоритма проходит research dataset → validation → review → owner/release approval; production не обучается скрыто в реальном времени.

Canonical anchor: `../../CANON/BROTHERHOOD_RESEARCH_PLATFORM_CANON.md`.

## 11. Cycle 0004 boundary
Этот документ фиксирует целевую продуктовую модель. Cycle 0004 не меняет Android/backend/database runtime, protected test mechanics, scoring или UI. Подтверждённый legacy weighted aggregate в runtime остаётся migration gap до отдельного implementation cycle.
