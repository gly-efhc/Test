# Brotherhood Trust Boundary

Status: **ACTIVE PRODUCT BOUNDARY**

## 1. Definition
Trust — отдельный operational signal о надёжности/верификации/поведенческой истории. Он не является оценкой личности, психологической совместимости или моральной ценности человека.

## 2. Candidate evidence families
Будущая методология может исследовать: verified identity, account integrity, fulfilled commitments where explicitly recorded, moderation outcomes with appeals, confirmed abuse/security events, interaction reliability signals with consent and anti-gaming controls.

## 3. Forbidden fusion
Trust не усредняется с Psychology, Interests, Values, Numerology, Astrology или Quality Fit. Trust не является скрытым multiplier общего Compatibility.

## 4. Due process / fairness
Нужны provenance события, temporal validity, appeal/correction path, anti-brigading, protection against proxy discrimination, clear retention/deletion policy and separation of allegation from confirmed evidence.

## 5. Privacy
Нельзя превращать private message content или скрыто наблюдаемое поведение в моральный рейтинг без отдельной правовой/ethical basis и явной policy. Research outcomes не должны автоматически менять Trust.

## 6. Status
Cycle 0004 фиксирует границу и research questions. Новая runtime formula не вводится.
