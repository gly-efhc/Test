# Brotherhood Compatibility System

Status: **ACTIVE PRODUCT/METHOD ARCHITECTURE**.

## 1. Independent compatibility metrics
### Empirical-development group
- `PC` Psychology Compatibility;
- `IC` Interests Compatibility;
- `VC` Values Compatibility;
- `CC` Communication Compatibility;
- `LC` Lifestyle Compatibility.

### Typology group
- `PT` Brotherhood Personality Type Compatibility;
- `EN` Enneagram Compatibility.

### Alternative group
- `NU` Numerology Compatibility;
- `AS` Astrology/Zodiac Compatibility.

Each returns its **own independent 0..100 index** and has its own evidence status, model version, role support and Data Coverage.

## 2. User checkbox rule
The user chooses the methods he personally wants to compare. There is no default scientific monopoly and no hidden cross-metric weight.

## 3. Overall
`Overall = arithmetic mean(selected available compatibility metrics)`.

Overall is only convenience. Individual metric scores are the primary information.

## 4. Separate signals
### QF Quality Fit
Directional answer: “how well does this candidate meet *my* current search requirements?” Not part of Overall.

### TR Trust
Operational/verification/reliability signal. Not a personality score and not part of Overall.

### DC Data Coverage
Completeness/reliability/recency of evidence for a specific metric. Not part of Overall.

## 5. Role context
Before comparing, the user selects or inherits context: friend, business partner, worker/team, mentor, project partner, etc. Metric engines can use different role-specific models.

## 6. Compatibility page architecture
One service page groups metrics by evidence family, displays checkbox, score, coverage and detail navigation. Tapping a metric opens a dedicated page with score, safe explanation, data freshness, method/evidence status and “how calculated” documentation.

## 7. Privacy
The candidate’s hidden latent traits, type coordinates and raw test responses are never disclosed. Explanations are pair-level, e.g. “Ваши стили принятия решений хорошо сочетаются”.

## 8. Scientific honesty
`87%` is a normalized Brotherhood index under a named metric/model version, not “87% probability that you become friends”.

## 9. Runtime migration note
Current Android legacy `HybridCompatibilityEngine.kt` still contains fixed cross-layer weights. It is a known implementation gap and must be migrated only in a separately authorized runtime cycle after tests/specs are ready.
