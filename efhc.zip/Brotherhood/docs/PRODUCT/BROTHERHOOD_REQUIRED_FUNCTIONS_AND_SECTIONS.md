# Brotherhood — Required Functions & Sections

Status: **ACTIVE TARGET FUNCTION MAP**.

## Root authenticated shell
Persistent root navigation / stable route shell. Owner Q45 fixes the order exactly as `Профиль → Люди → Чаты → Группы → Развитие`; nested authenticated screens preserve the shell unless an immersive flow has predictable Back behavior.

## Development
Diia-style catalog of standalone applications. Primary modules: Tests, Numerology, Zodiac. Each module is end-to-end, not a teaser card.

## People / Discovery
- recommended candidates;
- resume list/card modes;
- filters;
- role context;
- saved/skip/undo;
- candidate detail;
- swipe only inside recommendation flow;
- immediate direct message;
- compatibility entrypoint.

## Search Requests
User defines whom he seeks and why:
friend, business partner, worker, mentor, project participant, activity/mutual aid etc. Request stores desired qualities, skills, interests, geography and priorities. QF is calculated directionally.

## Candidate Resume
- photo + public identity;
- city/languages;
- occupation/business/skills;
- goals and what he seeks;
- interests/activities;
- groups/communities;
- verification/public trust elements;
- selected compatibility metrics;
- separate QF, Trust, Coverage;
- message button.

## Compatibility service
One Diia-like service page:
- candidate header;
- role selector;
- grouped metric checkboxes;
- individual 0..100 results;
- Overall simple mean for selected metrics;
- detail page per metric;
- evidence-family badge;
- coverage/recency;
- QF/TR separate;
- no raw latent disclosure.

## Tests
- active conscious/situational catalog: seven scientific systems / 197 items;
- execution/resume;
- meaningful per-system result;
- history/reread;
- retake policy;
- Psychological Profile and Psychological Report;
- next high-priority independent methods: Jung Word Association, Freud Free Association, IAT/reaction-time;
- method provenance remains explicit; no hidden averaging between questionnaire and implicit channels;
- private longitudinal profile updates only through versioned approved scoring models.

## Messages
Telegram-class direct/group chat roadmap: delivery states, retry/outbox, reply, reactions, edit/delete, attachments, moderation/block/report, encryption/security architecture.

## Communities
Interest/local/business/project/mutual-aid groups, roles, events/activities, moderation, links from candidate profiles.

## Profile / Me
First/default authenticated page. Public resume + private self-analysis links + settings/privacy + verification. Tests/results/history live inside the Development→Tests application; Search Requests live inside People.

## Trust & Safety
Verification, block/report, incident provenance, appeals, anti-abuse, privacy export/delete/retention, research consent/withdrawal.

## Research administration (not public profile)
Stimulus/model registry, cohorts, validation runs, source-to-claim, model release status, longitudinal outcomes and audit logs. Strict authorization boundary.

## Investor standalone demo
Full stateful backend/frontend/simulation parity of these sections; no simplified substitutes for core mechanics.
