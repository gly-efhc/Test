# Brotherhood project canon v0.5.11

1. Product name is always `Brotherhood`.
2. Canonical source is unpacked code in GitHub.
3. Test APK may be built from `Brotherhood.zip`; issued archives always have top directory `Brotherhood/`.
4. Canonical identity is `global_id`, displayed as ten digits (`0000000001` ...).
5. Product is for men 18+ seeking platonic male friendship.
6. Compatibility is multi-layered and explainable; Trust is separate.
7. Vedic numerology is mathematics from birth dates, not a test.
8. Direct chats use Brotherhood E2EE v1; group chats are server-moderatable encrypted-at-rest.
9. Client is offline-first; shared state goes Android → Vercel backend → Neon.
10. Brand master is `brand/BR_logo_master.svg`, black `#000000` + gold `#ECAF21`.
11. Discovery includes Quick Discovery, persistent filters, profile visibility and passport city mode.
12. Third-party sandbox code is incorporated only when licensing and stack fit are explicitly verified; otherwise only architecture/UX concepts are used.


## Android Development signing canon

- Canonical Development APKs use one permanent Brotherhood Development signing certificate.
- Canonical Development CI fails closed if signing secrets or the expected public certificate fingerprint are missing.
- No ephemeral GitHub debug certificate is published as a canonical Brotherhood Development APK.
- Development signing is never used for Production release APK/AAB.
- `applicationId` remains `org.federationofavatars.brotherhood`.
- v0.5.11 uses `versionCode = 16`.
