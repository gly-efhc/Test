# ADR-0002 — Hidden visual profile and user-authored Quality Fit

> **STATUS NOTE (Cycle 0004, 2026-08-09): HISTORICAL VERSION / SUPERSEDED FOR CURRENT COMPATIBILITY AGGREGATION.** Fixed 15-layer/inter-metric weights and Vedic 5% statements below are preserved as historical scope evidence; current target canon is `docs/CANON/BROTHERHOOD_COMPATIBILITY_CANON.md` (independent scores + simple mean of user-selected metrics). Other historical mechanics statements remain evidence unless separately superseded.


Status: ACCEPTED
Date: 2026-08-01

## Decision
Replace direct socially desirable psychological questions with an indirect visual/associative assessment architecture and add a separate Quality Fit system driven only by qualities explicitly selected by the searching user.

## Why
Direct morality/quality questions are easy to game and conflict with Brotherhood's goal. Brotherhood needs to distinguish context-dependent human styles rather than label people as good/bad. A strict separation is also required between Compatibility, Trust, Account Completeness and the new request-specific Quality Fit.

## Consequences
- 100×6 bank is retained but task representation and scoring are replaced.
- latent coordinates are private algorithm data;
- public output is positively framed;
- both poles of a trait can be desirable in different roles;
- role selection is not permission to invent desired qualities;
- legacy direct-question results cannot feed the new model;
- visual loadings require empirical validation and are versioned;
- candidate ranking can optionally prioritize Quality Fit when the user has selected qualities.

## Non-decisions
- no change to the canonical 15 Compatibility weights;
- no change to Vedic 5%;
- no change to Trust logic;
- no clinical-diagnostic claim;
- no automatic production reweighting from outcome models.
