# ADR — Overall Compatibility Uses Simple Mean

Status: **ACCEPTED — OWNER Q28**

## Decision
For selected available compatibility metric scores, optional Overall is their unweighted arithmetic mean. No hidden inter-metric weights.

## Details
One selected metric → same score. Multiple selected metrics → `sum/n`. Missing/insufficient metric is not zero and must be disclosed as unavailable. Evidence class/confidence are shown separately, not used as hidden weights.

## Non-goal
Overall is not a scientific latent scale and not probability of relationship success.
