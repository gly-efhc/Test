# ADR — Modular Compatibility Engines

Status: **ACCEPTED — OWNER Q28**

## Decision
Replace target conceptual architecture of one fixed weighted hybrid Compatibility with a registry of independent user-selectable metric engines, each returning its own `0..100` result.

## Rationale
Different methodologies answer different questions and have different evidence status. Keeping them independent preserves interpretability and user control.

## Consequences
Quality Fit, Trust and Coverage remain separate. Runtime legacy weighted aggregate is a migration gap; this ADR does not authorize cycle-0004 runtime changes. Historical weighted docs are preserved as superseded history.
