# ADR — Release-Parity Simulation

Status: **ACCEPTED — OWNER Q23/Q26**

## Decision
Investor HTML uses full product contracts through Backend Simulator → Simulation Engine → Frontend mirror. It is not a mockup and cannot invent simplified scoring.

## Consequences
Synthetic fixture data are allowed only as instances of real contracts. Any UX/runtime/simulation cycle must maintain state/lifecycle/error/loading/offline parity. Documentation-only cycle 0004 does not regenerate HTML.
