# ADR — Compatibility vs Quality Fit vs Trust

Status: **ACCEPTED**

## Decision
Maintain three separate product entities:
- Compatibility: pair fit under a selected methodology;
- Quality Fit: directional fit to one user's SearchIntent;
- Trust: operational reliability/verification/history signal.

## Consequence
No automatic averaging or hidden multiplication among them. UI may colocate them on a candidate decision page but labels and contracts remain distinct.
