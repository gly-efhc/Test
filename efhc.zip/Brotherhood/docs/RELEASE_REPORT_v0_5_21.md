# Brotherhood v0.5.21 — corrective release report

## Scope
Cycle 0002 only: missing TextAlign import and exact regression guard.

## Changed
- `ServiceScreens.kt`: added Compose TextAlign import.
- app/API release metadata: 0.5.21 / 26.
- cycle status and anti-cycle-bloat accounting.

## Unchanged
- universal workflow;
- product algorithms;
- visual model;
- Compatibility, Trust, Quality Fit and Vedic weights;
- signing and applicationId.

## Status
LOCAL_PASS; EXACT_HEAD_GITHUB_CI_PENDING.
