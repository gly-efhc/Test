# Brotherhood v0.5.12 — development release report

## Scope
Functional source release. `applicationId`, Production signing, master-logo geometry and Android permission canon are unchanged.

## Implemented
- longitudinal `friendship_outcomes` collection and internal analysis API;
- shadow `Friendship Expectations` predictor from existing `f065` + `f071–f080`, without changing the canonical 100% production weights;
- review-only standardized logistic-regression calibration tool; Vedic Numerology stays fixed at 5%;
- situational paired/shuffled presentation of the existing 100 tests / 600 questions; Brotherhood-32 and Enneagram runs are also shuffled and shown through neutral situational blocks while scoring remains unchanged;
- profile avatar import through the Android system picker, app-private persistence and bounded backend synchronization;
- Brotherhood brand mark and differentiated feature icons in the main UI without redrawing the master SVG;
- Vedic compatibility vector kept strictly date-based: `[soul, destiny, maturity]`; name number remains descriptive only;
- known `apksigner` and `aapt` parser regressions removed from the source workflow.

## Local qualification
- backend pytest: **28/28 PASS**;
- Python syntax / JSON / Android XML checks: **PASS**;
- pure Kotlin core compile + smoke: **PASS** (`100 tests`, `600 questions`, Friendship Expectations `100` for equal expectations / `0` for opposite expectations);
- calibration synthetic smoke: **PASS**; output remains review-only, candidate weights sum to 100%, numerology remains 5%;
- signing/private-key static scan: **PASS**;
- no new broad media/storage or package-install permission: **PASS**;
- GitHub workflow YAML parse, all shell `run:` blocks via `bash -n`, AAPT and apksigner regression parsers: **PASS**;
- full local Android Gradle build: **BLOCKED_BY_ENVIRONMENT** because the sandbox lacks `gradle-wrapper.jar` and cannot reach GitHub to obtain it. Per project canon this is not classified as an Android source failure and was not retried indefinitely.

## GitHub qualification still required
The current v0.5.12 source changes require the existing GitHub Android qualification:

`testDebugUnitTest → compileDebugKotlin → assembleDebug → APK → signature → signer mode → metadata → SHA-256 → artifact upload`

Required final marker:

`ANDROID_CI_APK_ARTIFACT_PASS`
