# CURRENT STATE — Brotherhood

Updated: 2026-08-17

## OWNER SEQUENTIAL-ORDER OVERRIDE — ACTIVE CURRENT TRUTH
- Owner order dated 2026-08-17 restores ascending executable parent-cycle IDs.
- Cycles `0034`–`0036` are implemented. The next executable cycle is `0037 — Retake, Alternate Order & Practice-Effect Runtime`.
- Cycle `0111 — Questionnaire Bank Inventory Freeze v1.3` remains valid completed historical evidence from the former microcycle sequence: 197/197 active items inventoried exactly once; no scientific/scoring/runtime changes were made there.
- `0101–0110` remain satisfied/reference decomposition of 0034. `0112–0150` are no longer active execution IDs and must not be treated as NEXT unless the owner explicitly reactivates microcycle numbering.
- Cycle 0034 secure administration and cycle 0035 human-readable result feedback remain intact. Cycle 0036 adds only respondent wording/response-design behavior and keeps scientific scoring semantics unchanged.
- Current runtime contract remains `145 paths / 164 operations / 60 DB tables / 21 Android AppRoutes / schema19`.
- CI tests are explicitly prohibited by owner and were not run.

## Active development truth
- Input DEVELOPMENT package for cycle 0036: `Brotherhood_v0_5_81.zip`.
- Target DEVELOPMENT package: `Brotherhood_v0_5_82.zip` after local/package verification.
- Android source milestone remains `v0.5.35 / versionCode 40`; Android delta is zero.
- Active HTML candidate is `BROTHERHOOD_UI_SIMULATOR_v0_5_52.html`; cycle 0036 changes the respondent test flow and owner VA remains `PENDING`.
- Owner sequential order: cycles 0034–0036 are implemented; next executable cycle is 0037.

## Root IA
Authenticated root navigation remains exactly `Профиль → Люди → Чаты → Группы → Развитие`. The standalone Simulator now explicitly activates `DEVELOPMENT_FULL_DEMO_V1`: Tests 12/12, Associative/Implicit 3/3, Numerology, Zodiac and Enneagram all have immediately viewable saved demo state and route-backed app flows. Root default remains `Профиль`; Development is a fully active demo tab, not a placeholder.

## Measurement authority
### Conscious/situational questionnaire
- 12 user-facing test apps;
- 7 internal scientific systems;
- 197 active items;
- minimum 3 independent signals per construct/system;
- server-authoritative deterministic scoring and independent system compatibility.

### Associative/implicit — cycle 0029 implemented v1
- `WORD_ASSOCIATION_V1`: 24 standardized Brotherhood cues; first response + latency/process features;
- `ASSOCIATIVE_FREE_CHAIN_V1`: 8 seeds × 5 transitions; transition latency/process features; no universal symbolic dictionary;
- `IMPLICIT_ASSOCIATION_RT_V1`: 48 trials, 32 critical; D-type latency/error scoring;
- all three have public result/history and separate method compatibility `0–100%`; raw events are private/internal.

### Numerology — cycle 0030 standalone vNext
- self-reading contract: `numerology-reading-v3`;
- interpretation knowledge: `numerology-knowledge-v1`, canonical 13 locales;
- pair metric: `vedic-numerology-runtime-v1` / independent `NU 0–100%`;
- personal reading includes Life Path, Vedic date Soul/Destiny/Maturity, ruler metadata, transparent arithmetic trace, complete 1–9 birth-chart inventory, special configurations and four Pinnacle peak ages with exact calendar dates;
- source-backed read-only catalog exposes 97 normalized records across Life Path, name Soul, name Expression, birth-chart and Pinnacle groups;
- optional Latin-name Soul/Expression numbers are descriptive only and excluded from NU compatibility;
- personal readings and pair comparisons are persistent/versioned/history-readable;
- internal NU component weights are 40/35/15/10; there is no fixed 5% cross-metric Numerology weight under Q28.


### Zodiac — cycle 0031 standalone vNext
- active method: `AS_ZODIAC_BASIC_V1`;
- personal snapshot: `zodiac-basic-reading-v1`; 12-sign catalog: `zodiac-basic-catalog-v1`; pair metric: `zodiac-runtime-v1` / independent `AS 0–100%`;
- birth-date month/day sign boundaries and the existing sign/group Q28 rule remain unchanged; standalone and Q28 AS now share one backend scorer;
- immutable/idempotent personal readings plus history/latest/by-id and persistent pair comparison/history with frozen sign snapshots;
- compatibility rules remain same sign 86, same group 90, supported Fire↔Air or Earth↔Water 84, all other supported pairs 66; exhaustive parity covers all 144 ordered sign pairs;
- AS is traditional/alternative and opt-in, not psychological/psychometric evidence, Trust, Quality Fit or a probability of relationship success; `ASTRO-001` remains a negative controlled scientific boundary;
- natal chart, houses, aspects, Moon, Ascendant and synastry are not active; `AS_SYNASTRY_V1` remains future-only.


### Enneagram — cycle 0032 standalone optional app
- active method: `EN_BROTHERHOOD_CORE_PROFILE_V1`; instrument `enneagram-core-profile-18-v1`; reading `enneagram-reading-v1`; catalog `enneagram-type-catalog-v1`; pair metric `enneagram-existing-runtime-v1` / independent `EN 0–100%`;
- current Brotherhood local instrument = 18 deterministic visual items, exactly 2 per each of 9 types; hidden scoring keys are never returned by the public instrument;
- type/wing selection and pair formula are retained from existing Android/Q28 runtime; standalone and Q28 EN share one scorer;
- immutable/idempotent readings plus history/latest/by-id and persistent pair history with frozen type/wing inputs;
- `ENNEA-001` reports mixed reliability/validity evidence, therefore this module is typological/experimental, not validated psychometrics, diagnosis, Trust, Quality Fit or relationship-success probability;
- no additional type-personality claims were invented; the type catalog exposes only existing labels and neighboring wings.

### Quality Fit / SearchIntent — cycle 0033 v2
- SearchIntent contract `quality-fit-search-intent-v2`; catalog `quality-fit-catalog-v2`; scorer `quality-fit-directional-v2`; direction `SEARCHER_A_TO_CANDIDATE_B`.
- Only explicit user-selected requirements participate; role labels do not inject hidden required traits.
- Hard requirements and preferences remain separate; missing candidate evidence is `INSUFFICIENT_DATA`, never zero.
- Persisted evaluations freeze intent/evidence fingerprints, availability, eligibility, confidence, per-requirement breakdown and explanation.
- Quality Fit is directional and separate from Compatibility, Trust, Account Rating and Hospitality Reputation.

### Cycle 0033 simulator UX stability
- All 12 seeded test results are old enough for the unchanged calendar-month retake gate; Chromium verifies 12/12 `Повторить` and actual completion of a seeded test.
- Background 5-second engine ticks no longer full-rerender the current screen; non-current incoming messages do not rerender current content. Same-route updates preserve scroll/focus/value.
- Real Chromium evidence: scroll `500→500` after tick and forced incoming event; input value/focus retained; 0 page/console errors.
- Development/Tests/results use a service-first, less decorative hierarchy recorded in `docs/research/product/DEVELOPMENT_SERVICE_UX_DONORS_V1.md`. Donor sources are UX/product authority only.

### Reverse friendship research — owner Q48
`Reverse Friendship Pattern Discovery v1` is source implemented. It freezes pre-friendship/exposure features and compares mutually confirmed friendships with sufficiently exposed comparison pairs to identify enriched/depleted similarity, difference/complementarity and method-level patterns. Findings are descriptive evidence/hypotheses and never auto-change production weights.

### Friendship Reflection Surveys — owner Q49
Planned research mechanism: after verified real meetings, mutual friendship confirmation or selected research sampling, invite both sides independently to report why the friendship formed. Future analysis joins those explanations to the frozen Q48 pre-friendship snapshot. Dedicated Q49 runtime target is `0068`; Q48 hardening is `0069`; verified real-world meeting infrastructure is planned separately in the later social-runtime program; lifecycle E2E remains a later release gate. Survey responses never directly change Trust/Compatibility/Rating/Quality Fit.

## Source authority
- sole Source SSOT: `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json`;
- canonical sources: 225;
- scientific sources: 194;
- structured claims: 158;
- active source registries: 1.

## Current simulation authority
- 145 OpenAPI paths;
- 164 HTTP operations;
- 60 migration-defined DB tables;
- 21 Android AppRoutes;
- 200 deterministic synthetic candidates;
- 12 questionnaire test apps / 197 questionnaire items;
- 3 associative/implicit instruments;
- standalone Numerology vNext readings/history/comparisons;
- standalone Zodiac vNext readings/catalog/history/comparisons;
- standalone Enneagram 18-item instrument/readings/type catalog/history/EN comparisons;
- `DEVELOPMENT_FULL_DEMO_V1`: 12/12 Tests + 3/3 associative methods + saved NU/AS/EN reading/comparison demo state;
- seeded reverse-friendship friend/comparison observations;
- state schema 19;
- local runtime probe: 164/164 operations, 0 failures.
- cycle0034 local regression: targeted backend 5/5 PASS; full backend 127/127 PASS; architecture/current-product 299/299 PASS; Chromium secure-flow PASS with 0 page/console errors. CI was not run by owner order.

## Cycle reality in active roadmap
- Cycle `0027` Root IA + Development Hub is **source/HTML implemented**, owner VA pending; it was not skipped or reverted.
- Cycle `0028` Scientific Questionnaire v1.2 is source/HTML implemented, owner VA pending.
- Materially source/HTML implemented through cycle `0036`. Secure administration remains intact; 0035 adds human-readable result feedback and 0036 adds respondent-neutral situational wording without changing scoring semantics.
- Microcycles `0101–0110` are marked satisfied by this owner-authorized direct implementation; they must not be re-run as duplicate product patches. Cycle `0111` is preserved as completed out-of-order evidence. `0112+` is reference-only under the current owner sequence.
- Unified Multi-method Compatibility remains **deferred to `0078`** in the parent/outcome roadmap; cycle 0034 does not change Compatibility weights or semantics.

## Browser-runtime contract
- v47 was not runtime-valid despite parser/JS syntax PASS; v48 fixed cross-script scope and missing-screen defects.
- cycle0033 v49 adds background scroll/focus stability and guaranteed retakeable Development demo state.
- cycle0034 v50 adds secure test-session browser acceptance; cycle0035 v51 adds human result feedback; cycle0036 v52 adds neutral situational wording, stable per-session A/B presentation and comprehension flag while retaining server-authoritative canonical scoring.
- `scripts/check_cycle0036_html_runtime.py` executes real Chromium locally and verifies the full `164/164` SimulationEngine route probe; static parser/`node --check` remain necessary but insufficient. CI is not part of this cycle by owner order.

## Immediate next work
1. Owner reviews `BROTHERHOOD_UI_SIMULATOR_v0_5_52.html`; VA remains pending.
2. Preserve Secure Test Administration invariants as hard regression guards.
3. Do not re-execute microcycles 0101–0110: their decomposed requirements are satisfied by owner-authorized cycle 0034.
4. Cycle `0111 — Questionnaire Bank Inventory Freeze v1.3` remains completed historical evidence; current owner routing does not continue at 0112. Next executable cycle is `0037 — Retake, Alternate Order & Practice-Effect Runtime`.
5. No CI execution unless owner explicitly changes the current prohibition.

Active questionnaire bank: `scientific-questionnaire-bank-v1.3`; instrument `text-situational-neutral-v1`; scoring remains `scientific-questionnaire-v1`.

Owner visual acceptance: `VA=PENDING`. Compose mirror and CI/APK remain gated.

## Cycle 0036 neutral respondent wording
- Active bank successor: `scientific-questionnaire-bank-v1.3`; item IDs/count remain 197 and scoring remains `scientific-questionnaire-v1`.
- 180 situational items expose respondent-neutral behavioral A/B alternatives rather than internal pole names; 17 `DIRECT_PUBLIC_DOMAIN` anchors remain separate.
- A/B side order is derived from the persisted opaque item token, so it varies across sessions and is stable on resume/reload. BA presentation is remapped server-side to the canonical answer before scoring.
- `comprehension_flag`, `wording_version` and `side_order` are stored in existing `response_meta`; no DB migration is required.
- Public secure item shape remains `item_token/prompt/answer_labels/position/total`; construct, polarity, scoring keys and full bank remain private.
- Scientific boundary: this wording review is not reliability/factor/invariance/DIF/diagnostic/faking-detection validation.
- Android source remains unchanged pending owner visual acceptance under HTML-first CANON.
- Local cycle0036 regression: backend `134/134` PASS; architecture `313/313` PASS; Chromium protected 0034/0035/0036 flows PASS with `164/164` route probe and 0 page/console errors.

## Cycle 0035 result feedback correction
- Cycle 0035 historical HTML: `tools/visual_checks/BROTHERHOOD_UI_SIMULATOR_v0_5_51.html`; active cycle0036 HTML is `tools/visual_checks/BROTHERHOOD_UI_SIMULATOR_v0_5_52.html`.
- Result feedback route: `GET /v1/test-app-results/{global_id}/{result_id}/feedback`.
- Normal result UI contains human behavioural feedback only; technical provenance remains outside the user surface.
- CI: `NOT_RUN_BY_OWNER_ORDER`.
