# Архитектура MVP

## Контуры

1. **Identity** — аккаунт, профиль, возраст, город, верификация.
2. **Discovery** — поиск друзей по целям, интересам, совместимости и географии.
3. **Assessments** — 4 локальных теста, SQLite-хранилище результатов и API синхронизации.
4. **Communities** — клубы по интересам и отдельный business-контур.
5. **Trust & Safety** — отзывы, подтверждённые взаимодействия, жалобы, модерация, апелляции.
6. **Messaging** — source-implemented direct/group conversations: direct E2EE contract, group server encryption, reply/edit/delete/reactions/attachments/typing/read states, block/report and membership.
7. **Search Requests** — самостоятельные сохраняемые намерения поиска людей/партнёров/команд; явные фильтры не являются скрытыми весами Compatibility.

## География

Публичный профиль хранит выбранный город и, при согласии пользователя, приблизительную дистанцию. Точные координаты не публикуются. Android-клиент запрашивает только `ACCESS_COARSE_LOCATION` и только во время активного использования. Фоновая геолокация отсутствует.

Рекомендуемая production-модель:

- справочник `countries`;
- справочник `regions`;
- справочник `cities` с координатами центра;
- в профиле — `city_id`;
- временные координаты используются для определения ближайшего города и затем удаляются;
- расстояние между пользователями рассчитывается сервером и округляется.

## Сообщества

Обычные и деловые сообщества используют общую базовую сущность, но имеют разные правила:

- `INTEREST`: спорт, футбол, автомобили, туризм, технологии и т. д.;
- `BUSINESS`: предпринимательство, поиск команды, партнёров, проектов, отраслевые клубы.

Дружеский рейтинг не заменяет проверку контрагента. Для бизнеса нужен отдельный деловой показатель, основанный на подтверждённых проектах и нарушениях деловых договорённостей.

## Репутация

Публичный балл изменяют только подтверждённые модерацией события. Жалоба имеет состояния:

`PENDING → UNDER_REVIEW → CONFIRMED | REJECTED → APPEALED → FINAL`

До подтверждения жалоба не видна публично и не снижает рейтинг.

## Hospitality backend — cycle 0020

Hospitality is an integrated Brotherhood social module, not a parallel lodging marketplace. Ownership uses existing `global_id`; discovery reuses `/v1/people`; direct communication reuses canonical E2EE conversations; user blocks and Trust/moderation tables remain authoritative.

Backend source contracts in cycle 0020:

- `hospitality_host_profiles`, `hospitality_availability`, `stay_requests`, structured request events, confirmation/review/restriction foundation tables;
- fail-closed `HOSPITALITY_ENABLED`;
- AES-256-GCM application encryption for exact location and per-accepted-request arrival snapshot;
- backend-authoritative Account Rating / completed-test / block / restriction / date / capacity eligibility;
- idempotent request creation and optimistic request versioning;
- transactional PostgreSQL acceptance path with `FOR UPDATE` capacity recheck;
- participant-only accepted-arrival endpoint plus privacy-safe access audit;
- server lifecycle tick for 48h pending expiry and timezone-aware completion.

`completed` is a calendar lifecycle state, not evidence that a physical stay occurred. Verified-stay evidence, blind review publication, Hospitality Reputation/Trust orchestration and Android Hospitality UX remain cycle 0021.

## Messaging и Search Requests — cycle 0026

Cycle 0026 не реконструирует существующий Chat backend. Канонический social communication contract сохраняет direct/group conversation boundaries, direct E2EE, group server encryption, reply/edit/delete/reactions/attachments/typing/read, block/report и member management. HTML-клиент получает route response через SimulationEngine; для direct E2EE серверный response не становится plaintext-хранилищем, а demo client projection моделирует локальную расшифровку.

Search Requests получили first-class persistence (`search_requests`, migration `0012`) и API create/list/detail/update/archive. Они хранят явные пользовательские требования: роль, качества, географию, минимальные Trust/Compatibility gates и explicit flags. Эти параметры не создают скрытого inter-metric weighting.

Communities используют отдельный membership contract read/join/leave поверх существующего `community_members`.

## Production-переход

- PostgreSQL + Alembic;
- Redis для очередей и rate limit;
- S3-совместимое хранилище;
- OIDC/JWT и refresh-token rotation;
- отдельный moderation service;
- WebSocket/FCM;
- аудит административных действий;
- шифрование чувствительных доказательств;
- резервное копирование и retention policy.


## Offline-first тестирование

Тестовый движок находится в Android-клиенте и не зависит от сети. Результат сначала записывается в приватную SQLite-базу `brotherhood_local.db`. Серверный API `/v1/assessment-results` предусмотрен для последующей синхронизации между устройствами. В production сервер должен повторно проверять версию теста и расчёт, а не безусловно доверять значениям клиента.

Самооценочный тест на искренность не изменяет рейтинг доверия. Репутационные санкции допускаются только по подтверждённым событиям и решениям модерации.


## Scientific Test Systems v1 — cycle 0028

Cycle 0028 adds a first-class psychological test-system layer above the existing versioned visual assessment item bank. Backend module `app.psychological_test_systems` owns seven system definitions, research source anchors, aggregate scoring, coverage/status and independent pair-compatibility calculation. Public API exposes definitions/results/compatibility but excludes private raw trait-coordinate maps.

The runtime path is `assessment-results → scientific system engine → API routes → BackendSimulator/SimulationEngine → HTML Tests/Profile/Compatibility/Report`. Psychological Report v2 consumes the same system results and source trace; it does not invent an HTML-only interpretation.

`research-calibration-v1` is the current internal product calibration derived from canonical scientific source/construct/measurement contracts. Future outcomes can support a separately versioned model after explicit review, but no automatic-learning edge exists.
