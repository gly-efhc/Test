# Brotherhood project canon v0.5.8

## Product

- Men 18+ only.
- Platonic male friendship; not romantic dating.
- Goal: improve the probability of finding durable, compatible and trustworthy friends.
- 100 friendship tests / 600 questions.
- Separate self-analysis area so the application remains useful without actively searching for friends.

## Compatibility

Every candidate exposes independent scores for tests, interests, character, values, lifestyle, friendship goals, communication, conflict repair, business/mutual aid, social format, Brotherhood-32, Enneagram, zodiac, Vedic numerology and geography, followed by base and personalized total compatibility.

Trust/reputation is separate.

Vedic numerology is a mathematical birth-date layer. It is not a test, requires no questionnaire and does not contribute to the 100-test completion rating. The friendship compatibility score for this layer is calculated from the two birth dates only. Any optional name-number display is separate descriptive numerology and is excluded from Vedic friendship compatibility.

## Identity

`global_id` is the canonical owner identifier: `0000000001`, `0000000002`, … up to `9999999999`. Google, Telegram, Facebook and future providers are access identities only.

## Runtime

`Android APK → HTTPS → Vercel core backend → Neon PostgreSQL`.

The APK contains as much deterministic logic and static data as practical: tests, compatibility engines, numerology, zodiac, Brotherhood-32, self-analysis, localization and offline cache. Secrets/database credentials stay server-side.

## Chat

- Direct chats: E2EE v1, device keys, TOFU identity pinning and human-verifiable fingerprints.
- Groups: deliberately non-secret, server-moderatable, encrypted at rest.
- Text/media/replies/reactions/edit/delete/typing/receipts/offline retry are part of the chat core.
- Direct chat safety includes block/unblock and private moderated reports.
- Group owners can add/remove members after group creation.
- Push-token registration is implemented; actual closed-app delivery requires external FCM credentials.
- Background push requires external FCM project credentials.
- E2EE v1 is not marketed as Signal/Telegram-equivalent until independent audit and multi-device hardening.

## Android delivery

- application id remains `org.federationofavatars.brotherhood`;
- `versionCode` increases every release;
- stable private signing key is required for APK updates over an installed test build;
- GitHub Actions can emit debug APK always and stable signed release APK/AAB when signing secrets are present;
- Play builds use Play App Signing and Play In-App Updates.

## Archive canon

- source: `Brotherhood_v0_5_8.zip`;
- full GitHub package: `Brotherhood_GitHub_Canonical_v0_5_8.zip`;
- top directory inside every archive: `Brotherhood/`;
- canonical source: unpacked GitHub code;
- test APK: GitHub workflow unpacks repository-root `Brotherhood.zip` and builds it.
