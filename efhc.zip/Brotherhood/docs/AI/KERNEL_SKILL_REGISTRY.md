# Brotherhood Kernel Skill Registry

Machine registry: `ops/operator_kernel/config/skills.yaml`.

Safe local skills are `model_or_user`: route resolution, local scoped verification, file-map refresh, DEVELOPMENT packaging and RELEASE packaging. They remain constrained by route boundaries.

External side-effect skills are `user_only`: push, merge, publish/release, deploy, production migration, DNS change, external messaging, production secret/permission change and on-chain actions. A keyword in a prompt or file is not authorization.

Every skill contract declares trigger keywords/routes, required reads, allowed/forbidden writes, risk class, invocation policy, validation and output schema. If a skill would exceed current route scope, resolve a composite route or ask for authorization rather than expanding scope silently.
