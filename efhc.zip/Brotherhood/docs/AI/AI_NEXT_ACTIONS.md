# AI next actions

1. **Cycle 0009 — Psychological Compatibility Engine v1 Research Spec:** build role-context candidate models from the validated construct/measurement architecture; do not activate production scoring or modify protected 100×6 mechanics without separate owner authorization.
2. Use the exact canonical locale set `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id` in every new test-adaptation/calibration artifact. Keep structural locale support, semantic/native translation QA and psychometric equivalence as separate states.
3. Preserve owner Home canon: exactly `Поиск людей`, `Сообщения`, `Тесты`, `Поисковые запросы`; Results remain inside Tests.
4. Keep `Compatibility`, `Quality Fit` and platform `Trust` separate and never disclose private latent/personality classifications.
5. Do not promote external correlations/effect sizes into Brotherhood coefficients. Candidate models require intended-use validation, holdout/external replication, 13-locale invariance/DIF review and owner/release approval.
6. Frozen GitHub workflow, master logo and protected mechanics remain unchanged unless explicitly authorized.
7. APK/device and backend/PostgreSQL/provider status remain below PASS until corresponding external evidence exists.
8. Full 13-locale standalone investor HTML parity remains `REQUIRES_PARITY_UPDATE`; never substitute a partial/mock language implementation for release-parity simulation.
9. Before every archive/release/demo package run `scripts/verify_protected_product_mechanics.py` and the route-scoped validation matrix.
