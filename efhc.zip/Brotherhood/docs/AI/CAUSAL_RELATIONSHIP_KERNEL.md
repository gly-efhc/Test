# Brotherhood Causal Relationship Kernel

Status: ACTIVE OPERATOR ANCHOR
Purpose: prevent semantic drift between tests, hidden inference, user intent, Compatibility, Trust and public presentation.

## A. Primary search causal chain

```text
USER
  -> selects role/context
  -> selects desired qualities + optional importance
  -> SearchIntent

QUALITY CATALOG
  -> simple quality: one target coordinate
  OR
  -> composite quality: several target coordinates + internal weights
  -> versioned QualityDefinition

CANDIDATE
  -> completes indirect visual/associative tasks
  -> choices
  -> hidden multi-trait loadings
  -> distributed evidence
  -> private LatentProfile + confidence

SearchIntent + QualityDefinition + candidate LatentProfile
  -> per-target coordinate distances
  -> per-quality simple/composite fit
  -> user-importance-weighted Quality Fit
  -> ranking for THIS user's request
  -> public positive matched-quality labels
```

Role does not inject target qualities. The user-authored quality list is the target.

## B. Visual inference causal chain

```text
visual/associative task
  -> user chooses an intuitively closer composition
  -> choice contributes small hidden loadings to multiple coordinates
  -> the same coordinate is sampled again in distant/different tasks
  -> aggregation + internal consistency/confidence
  -> private latent coordinate
```

One choice is weak evidence. Repeated distributed evidence is the model input.

## C. Public projection chain

```text
private latent profile
  -> context-neutral positive pole mapping
  -> strongest supported positive resources
  -> public strengths
```

The public layer never emits raw latent scores, negative labels or “bad person” classifications.

## D. Canonical Compatibility chain — separate system

```text
15 canonical layers
  -> fixed base weights totaling 100%
  -> baseTotal
  -> existing user-goal personalization rules (where already canonical)
  -> personalizedTotal
```

Quality Fit is NOT a 16th compatibility layer and does not change these weights.

## E. Numerology chain — separate system

```text
birth date A + birth date B
  -> soul/destiny/cross/dateComposite
  -> Vedic friendship compatibility
  -> 5% canonical Compatibility layer
```

Name-derived number -> descriptive self-analysis only.
There is NO edge: `name number -> friendship compatibility`.
Numerology is NOT part of 100/600 psychological tests.

## F. Trust chain — separate system

```text
verified interactions + confirmed moderation incidents
  -> Trust Score
```

Complaint alone -> private moderation record.
There is NO edge: `raw complaint -> public reputation penalty`.

## G. Account Completeness chain — separate system

```text
unique completed current-model tests -> up to 50%
completed profile sections -> up to 50%
```

There is NO edge: `Account Completeness -> personality quality`.

## H. Outcome-calibration chain

```text
user-authored role/context + desired qualities + importance
  -> frozen SearchIntent snapshot at connection time
private visual-latent-v2 candidate profile
  -> frozen Quality Fit score + confidence + quality model version
connection
  -> only pre-match calibration attempts are eligible for outcome analysis
  -> controlled 30d/90d outcome + message-count observation
  -> offline observational validation / calibration report
  -> reviewed proposal
  -> explicit versioned model change only if approved
```

This makes `request -> measured fit -> later outcome` testable while preserving the distinction between association and causation. There is NO edge: `outcome regression -> automatic production reweighting`. Outcome data is internal analytics and never a public reputation source.


## I. Calibration-consent causal chain

```text
user explicitly opts in
  -> versioned calibration consent + cohort
  -> future visual item traces may be retained in separate private calibration storage
  -> aggregate personality profile remains in normal profile storage

user does not opt in
  -> aggregate profile may still operate normally
  -> raw item-level calibration trace is not retained server-side

user withdraws
  -> retained raw calibration attempts for that user are deleted
  -> aggregate profile remains available for normal Brotherhood functionality
```

Calibration consent changes research-data retention only. It does not change matching scores, Compatibility, Trust, Account Completeness or public profile content.


## I.1 Controlled-pilot enrollment chain

```text
closed pilot configuration
  -> current consent + explicit acknowledgement
  -> supported locale + total/locale capacity
  -> plaintext invitation used once in HTTPS request
  -> SHA-256 validation + digest redemption
  -> active cohort/wave enrollment
```

The plaintext invite has no storage edge. Withdrawal bypasses enrollment gates and deletes raw attempts. A prior cohort/wave enrollment is not an enrollment edge into a new cohort/wave.

## I.2 Composition-calibration chain

```text
scene + paradigm + versioned seed
  -> non-scoring composition_variant 0..7
  -> identical background recipe for all four choices
  -> private trace
  -> composition-distribution diagnostics
  -> review candidate only
```

There is no edge from composition variant to latent loading, personality verdict or public label.

## J. Localization causal chain

```text
user selects locale in carousel
  -> AppLanguage.tag + direction
  -> complete locale pack validation
  -> whole-app UI/domain presentation
  -> Quality Fit labels / assessment instructions / self-analysis / numerology / status text
  -> built-in city/demo labels use locale-specific presentation while stable search/storage values remain unchanged
```

Language changes presentation, not hidden scoring semantics. A locale with incomplete required keys or numerology coverage is not activated. There is NO edge: `locale -> different latent scoring`.

## K. Forbidden causal edges

1. `low/high latent value -> bad person` — FORBIDDEN.
2. `single visual choice -> diagnosis/moral conclusion` — FORBIDDEN.
3. `raw latent coordinates -> public UI/person DTO/public assessment GET` — FORBIDDEN.
4. `role selection -> implicit/default desired qualities` — FORBIDDEN.
5. `selected qualities -> mutation of canonical Compatibility weights` — FORBIDDEN.
6. `selected qualities -> Trust Score` — FORBIDDEN.
7. `selected qualities -> Account Completeness` — FORBIDDEN.
8. `complaint -> reputation penalty without confirmed moderation incident` — FORBIDDEN.
9. `name number -> friendship compatibility` — FORBIDDEN.
10. `numerology -> psychological-test count` — FORBIDDEN.
11. `legacy direct-question result -> visual-latent-v2 profile` — FORBIDDEN.
12. `internal consistency signal -> public negative warning` — FORBIDDEN.
13. `theory-informed visual loading -> claim of validated psychological fact` — FORBIDDEN until validated.
14. `composite quality -> universal personality verdict` — FORBIDDEN; it is only a fit template for a user-selected request.
15. `search role -> composite quality preset` — FORBIDDEN unless the user explicitly selected that quality.
16. `30d/90d outcome -> public moral/reputation label` — FORBIDDEN.
17. `observational outcome association -> causal psychological claim` — FORBIDDEN without appropriate validation.
18. `outcome analysis -> silent production model mutation` — FORBIDDEN.
19. `language change -> only navigation labels while domain/test/numerology text stays old` — FORBIDDEN.
20. `locale -> different psychological/compatibility scoring semantics` — FORBIDDEN.
21. `incomplete locale pack -> visible language carousel option` — FORBIDDEN.
22. `visual item response trace -> public user/profile API` — FORBIDDEN.
23. `calibration correlation -> automatic production loading change` — FORBIDDEN.
24. `locale change -> rewrite canonical city/search/storage value` — FORBIDDEN.
25. `locale change -> silently machine-translate arbitrary user-authored content` — FORBIDDEN.
26. `no calibration opt-in -> retained raw item-level calibration attempt` — FORBIDDEN.
27. `calibration withdrawal -> retain that user's raw calibration attempts` — FORBIDDEN.
28. `post-match assessment -> predictor/explanation of an earlier match outcome` — FORBIDDEN (temporal leakage).
29. `presentation slot / response latency -> public honesty/deception label` — FORBIDDEN.

30. `plaintext pilot invite -> offline queue / preferences / database / logs` — FORBIDDEN.

31. `redeemed invite digest -> second participant enrollment` — FORBIDDEN.

32. `old cohort/wave enrollment -> automatic enrollment in a new cohort/wave` — FORBIDDEN.

33. `pilot disabled/full -> block withdrawal or raw-data deletion` — FORBIDDEN.

34. `composition_variant -> latent score/personality conclusion` — FORBIDDEN.

35. `different composition per answer option -> psychological scoring` — FORBIDDEN because it confounds visual form with choice loadings.

## L. Required invariants

- 100 psychological/behavioral tests, 600 indirect tasks.
- No visible target-construct names during assessment.
- No universal bad-trait scalar.
- Both trait poles have context-positive meaning.
- Quality Fit exists only when the user selected qualities; empty request must not silently inject defaults.
- A composite quality must be computed from its declared internal target coordinates; no single coordinate may impersonate a multi-construct quality.
- Server/public DTOs expose only safe outputs.
- Old direct-question scores are quarantined from the new latent model.

## Positive-result causal chain — v0.5.20

Allowed:

```text
completed visual block
→ private latent profile update
→ public-safe positive projection
→ visible strength/context/progress
→ motivation to continue
```

Forbidden:

```text
completed block
✕→ counter-only result with no user value

retake
✕→ duplicate +0.5% Account Completeness

private latent diagnostics
✕→ public result screen

positive wording
✕→ alteration/falsification of hidden matching coordinates
```

## Cycle 0004 modular compatibility anchor
Canonical research map: `docs/research/compatibility/CAUSAL_MODEL.md`. Compatibility metrics are independent 0..100 engines; optional Overall is a simple unweighted mean of selected available scores. Quality Fit and Trust are separate causal branches. Longitudinal outcomes enter a reviewed research loop only and never auto-mutate production. Any `stimulus→trait` or Brotherhood-specific pair relation remains HYPOTHESIS until validation.

36. `versioned/improvable psychological model -> immutable person essence` — FORBIDDEN. Q33 protects research/model humility.
37. `PC(role) -> probability of relationship/work success` — FORBIDDEN unless a separately calibrated probability model for that declared outcome is explicitly validated and owner-approved.

## M. Q34 exact algorithmic-score chain
Allowed:
```text
model_version + role_context + input_snapshot
  -> approved deterministic/versioned algorithm
  -> exact score_0_100 for that version
  -> direct product presentation
```
Also allowed:
```text
new evidence -> reviewed/validated candidate model -> owner/release approval -> new model_version -> recalculated exact score_0_100
```
There is no contradiction between a versioned/improvable scientific model and an exact current algorithmic result. Research labels such as `HYPOTHESIS` or `REQUIRES_VALIDATION` are governance metadata and do not automatically become repetitive user-facing warnings.

## Q35 research-platform causal chain

Allowed:
`pre-exposure profile/intent → versioned scores → recommendation policy/rank → real exposure → action → interaction opportunity → voluntary status/outcome → research dataset → reviewed candidate model → locked validation → owner/release approval → next production version`.

Forbidden edges:
- `not exposed → negative preference`;
- `no click → incompatibility`;
- `no reply → incompatibility`;
- `relationship ended → bad person / automatically bad initial score`;
- `post-exposure outcome → feature for the same historical prediction` (temporal leakage);
- `click/status/outcome → automatic production coefficient update`;
- `raw private message semantics → research score by default`.

The recommendation algorithm is a cause of exposure and therefore part of the research provenance, not an invisible background process.


## Values Compatibility causal chain — Cycle 0015 hardening (v0.5.45)

Status: **ACTIVE RESEARCH CAUSAL GUARD / NO PRODUCTION ACTIVATION**

Allowed chain:

`voluntary value source / approved assessment`
→ `raw/scored profile + instrument/locale provenance`
→ `versioned scoring adapter / centering`
→ `explicit comparable representation + normalization_id + coverage`
→ `VC model + role/direction + component outputs`
→ `exact decision-time VC score OR INSUFFICIENT/NOT_COMPARABLE`
→ `recommendation eligibility/rank/policy`
→ `actual exposure/impression`
→ `user action`
→ `interaction opportunity`
→ `voluntary status / longitudinal outcome`
→ `versioned research dataset`
→ `offline baseline/challenger analysis`
→ `locked/temporal validation + fairness/privacy review`
→ `human/scientific review + owner/release approval`
→ `new version only`.

Historical `VC-R0` stores its simplex engineering representation and remains reproducible. Current `VC-R0.1` uses explicit centered-priority provenance. Neither is represented as a formula supplied by Schwartz or as an outcome probability.

Forbidden shortcuts:
- `raw rating → silent simplex normalization → claim “canonical Schwartz score”`;
- `missing/withheld value → zero`;
- `perceived similarity → actual profile similarity`;
- `team/venture/leader evidence → unqualified dyadic coefficient`;
- `one difference/distance score → proof that exact equality maximizes outcome`;
- `current score → overwrite historical exposure-time score`;
- `not shown / no click / no reply without opportunity / ended contact → automatic negative label`;
- `value profile → moral worth / competence / reliability`;
- `Values → Psychology / Interests / Quality Fit / Trust`;
- `outcome/click/status → automatic production model mutation`.

`VC-R2-RSA` may test congruence, absolute-level and asymmetry hypotheses offline. Statistical evidence from a challenger does not become a production `0..100` mapping until a separately versioned mapping is validated and approved.


## Q35/0015 Values Compatibility causal extension

Allowed research chain:
```text
versioned values instrument/input source
  -> declared scoring adapter
  -> centered relative-priority profile + ranks + coverage/freshness
  -> VC model/version + role/direction
  -> exact VC score or explicit non-score state
  -> recommendation policy/rank
  -> real exposure
  -> action / interaction opportunity
  -> side-specific voluntary relationship status/outcome
  -> versioned offline research dataset
  -> challenger analysis + locked validation
  -> scientific/privacy/fairness review
  -> owner/release approval
  -> new production model version (only if separately authorized)
```

Values-specific forbidden edges:
- `PVQ/PVQ-RR centered scores -> force non-negative sum-to-one probability vector` — FORBIDDEN as a convenience reinterpretation of the measurement model.
- `value similarity -> universal better relationship` — FORBIDDEN; role/value-family/nonlinear hypotheses require evidence.
- `value priority -> moral worth / Trust / verified reliability / competence` — FORBIDDEN.
- `team/organization value effect -> dyadic VC coefficient` — FORBIDDEN without level-appropriate evidence.
- `post-relationship/current value profile -> overwrite historical pre-exposure predictor` — FORBIDDEN; selection and socialization must remain distinguishable.
- `not shown/no click/no reply/ended contact -> VC negative label` — FORBIDDEN.
- `Values outcome data -> automatic active-model update` — FORBIDDEN.


## Communication Compatibility causal chain — cycle 0016

Allowed research chain:

```text
pre-exposure explicit/structured communication preference snapshots A+B
  + declared role
  + model/input/locale versions
  -> CC-R0 or versioned challenger
  -> exact score_at_exposure + coverage
  -> actual recommendation exposure/rank
  -> discovery/action opportunity
  -> consented structural communication process / voluntary feedback
  -> relationship status + 7/30/90/180/365 outcomes
  -> offline research dataset
  -> scientific/causal/validation review
  -> owner-approved future model version only
```

Post-contact communication processes have common causes besides CC, including opportunity/delivery, availability/workload, channel, prior tie, relationship stage, SearchIntent, rank, geography/time-zone and unobserved context. Therefore:

- `no reply -> incompatibility` is FORBIDDEN without opportunity/delivery/window evidence;
- `conflict -> incompatibility` is FORBIDDEN;
- `actual fast reply -> high historical CC` is FORBIDDEN;
- `post-contact disclosure/reciprocity/repair -> earlier predictor feature` is FORBIDDEN (temporal leakage);
- `locale/nationality -> assumed directness/cadence/disclosure preference` is FORBIDDEN;
- `private chat content -> hidden CC trait` is FORBIDDEN by default; deeper content analysis requires separate owner-authorized cycle and explicit purpose/consent/retention review;
- `CC outcome association -> silent production coefficient update` is FORBIDDEN.

Historical CC/model/input/exposure provenance is immutable. Current recomputation cannot impersonate the score actually shown/used at an earlier decision.


## Cycle 0017 — Lifestyle causal guards
- `raw distance -> incompatibility` is forbidden. Distance acts through opportunity/meeting feasibility and is conditioned by remote mode and mobility tolerance.
- `current distance/schedule -> historical score_at_exposure` is forbidden. Freeze derived distance, timezone, availability and season/calendar context at exposure.
- `post-contact sleep/activity/habit convergence -> pre-contact similarity` is forbidden; selection/socialization are separate causal paths.
- `matching smoking/alcohol use -> higher compatibility` is forbidden in LC-R0; habits are optional directional boundary checks only.
- `same family status -> higher compatibility` is forbidden; only voluntary practical life-capacity/availability constraints may enter LC.
- `locale/country -> lifestyle preference` inference is forbidden.
- SearchIntent/QF candidate requirements are eligibility/asymmetric-fit inputs and cannot be silently recycled as LC pair features.
- `not shown / no opportunity / no meeting -> incompatibility` is forbidden without exposure/opportunity/observation-window provenance.
- Production outcomes cannot automatically mutate LC. Research chain remains frozen snapshot -> outcome -> offline candidate -> validation/review -> owner-approved version.

## Cycle 0018 — Personality-Type causal guards
- `hard Brotherhood-32 code == natural class` is forbidden; code/title is an interpretation layer over versioned continuous axes.
- `same hard type -> compatible` is forbidden as a universal rule. `PTC-R0` similarity is a transparent comparator, not causal truth.
- `current runtime 15% bondStyle durability term -> validated scientific coefficient` is forbidden; cycle 0018 leaves runtime unchanged and does not import that coefficient into PTC-R0.
- perceived similarity, actual pre-exposure similarity and post-contact relationship perception are distinct causal variables.
- current reassessed axes/memberships cannot impersonate the historical profile used at exposure.
- relationship-driven convergence/divergence cannot be back-filled into the pre-exposure predictor.
- PT remains separate from Psychology, Enneagram, Quality Fit and Trust; outcomes cannot silently double-count those systems.
- locale/language/nationality cannot be used as a proxy for type membership.
- production outcomes cannot automatically mutate PTC; Q35 offline candidate→validation/review→owner-approved version pipeline remains mandatory.

## Cycle 0021 — Hospitality verified-stay causal guards
- `completed -> physical stay occurred` is FORBIDDEN. `completed` is calendar lifecycle only.
- `bilateral stay_occurred confirmation -> verified hospitality_stay evidence` is allowed only under the versioned Hospitality verification contract and exactly-once request provenance.
- `no_show/dispute allegation -> automatic negative Trust/reputation` is FORBIDDEN; allegation must enter Trust incident/evidence/moderation/appeal due process.
- `verified hospitality_stay -> friendship` is FORBIDDEN. A verified stay is a high-information real-world interaction event, not a relationship-status label.
- `Hospitality Reputation -> Compatibility` and `Hospitality Reputation -> Account Rating` are FORBIDDEN implicit edges; the domains remain separately versioned.
- `blind review score -> Psychology/Compatibility trait` is FORBIDDEN. Reviews are hospitality/reputation evidence only.
- `post-stay relationship status -> historical prediction feature` is FORBIDDEN. Any later friendship/project/business status is an outcome linked to the frozen historical exposure/prediction snapshot.
- exact address, exact coordinates, arrival contact, private review feedback and E2EE message plaintext are forbidden research/export features by default.
- production scoring cannot auto-learn from requests, accepts, verified stays, reviews or later relationship outcomes; Q35 offline analysis/validation/review/owner approval remains mandatory.

## Cycle 0022 — Hospitality longitudinal / exposure causality guards
- `no Hospitality request -> incompatibility` is FORBIDDEN. Travel intent, opportunity, dates, capacity and exposure determine whether a request was even possible.
- `host rejection / request expiry / cancellation -> incompatibility` is FORBIDDEN without reason/opportunity provenance; these remain process states, not automatic labels.
- `verified hospitality_stay -> historical model caused the meeting` is FORBIDDEN. Recommendation/exposure, pre-existing relationship, travel purpose, geography, seasonality and host availability are candidate confounders.
- `post-stay friendship/project/business status -> proof of Hospitality or Compatibility causal effect` is FORBIDDEN without an approved causal design.
- `current Compatibility/QF/Trust -> exposure-time Compatibility/QF/Trust` back-fill is FORBIDDEN; use the frozen decision-time versions/scores/coverage/rank/policy snapshot.
- exact address, exact coordinates, arrival instructions/contact, private review feedback and E2EE plaintext cannot enter default Hospitality research datasets.
- no-survey-response is missingness, not failure; `NOT_ENOUGH_INTERACTION_TO_JUDGE` remains an explicit valid outcome.
- Hospitality outcomes may inform offline candidate-model research only through Q35 review/validation/owner-approval; production auto-learning remains forbidden.
