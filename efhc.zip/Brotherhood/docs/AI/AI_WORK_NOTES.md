# AI work notes

## 2026-08-01 — ecosystem restoration

- The v0.5.20 package already contained a substantial Operator Kernel ecosystem: CANON, SSOT, NORM, routes, capsules, hooks, agents, skills, healer guards and temporary memory.
- Missing critical element: canonical numbered cycles directory and 0001–0100 roadmap.
- User explicitly requires cycle-based planning and persistent AI work rules/notes.
- Decision: restore documentation/governance only; do not change runtime or version.
- Current CI evidence after v0.5.20: run `83283873357` fails on missing `TextAlign` import; this is assigned to cycle 0002.
- Universal workflow remains frozen and must not be edited for that source error.

## 2026-08-01 — cycle 0002 local implementation
- Added missing TextAlign import proven by run 83283873357.
- Universal workflow hash was preserved.
- Added import regression guard.
- Clarified that 0001–0100 are reserved slots, not 100 mandatory cycles.
- Current committed work is only active 0002 and conditional 0003.

## 2026-08-01 — full chat/source audit and compact cycle correction
- User rejected the 100-microcycle interpretation and per-fix APK cadence.
- Confirmed that v0.5.20 UX changes were source-only and never reached a successful user APK because compile failed; v0.5.21 has not yet passed milestone device acceptance.
- Replaced the over-segmented roadmap with 10 large cycles covering the entire path to production.
- Defined APK checkpoints only at cycles 0002, 0004, 0006, optional 0008 and final 0010.
- Added evidence-level vocabulary SOURCE_ONLY/LOCAL_PASS/APK_VISIBLE/LIVE_E2E/PRODUCTION_QUALIFIED.

## 2026-08-08 — cycle 0002 evidence audit and source milestone v0.5.22
- Exact baseline `Brotherhood_v0_5_21(1).zip` SHA-256 matched `9212a38098b1dc785d85f668677008cce0d509ea72c7d9cd89daf2e2e3be603e`.
- Startup ZIP audit: CRC/top-root/path traversal/symlink/nested-archive/cache/secrets checks passed; `.env.example` contained templates only.
- Operator Kernel routed the request through i18n/localization + Android UI + psychological results + cycle planning; `.github` remained outside write scope.
- Audit found real PARTIAL gaps on Home/Profile/Self-analysis, People CTA layout, Groups information hierarchy, unconditional manual-install notice and several localized runtime error fallbacks.
- Patched only those gaps and retained existing architecture, stores, matching models and navigation.
- Embedded supplied `APK_SOURCE_MAP_v002` under `docs/research/source_map/` as research-only evidence and documented its authority boundary.
- Runtime changes justify `v0.5.22 / versionCode 27`; workflow remains byte-identical.
- 78 architecture/targeted tests PASS; JSON/XML/YAML and cycle-ecosystem guards PASS.
- Local Gradle compile remains unproven because wrapper JAR download is blocked by the container network; GitHub checkpoint A is required.



## 2026-08-08 — cycle 0003 source milestone v0.5.23
- Operator Kernel route: auth_security + backend_api + database + android_ui_feature + cycle_planning.
- Replaced Android hardcoded runtime auth with encrypted session/refresh flow and restart `global_id` restoration.
- Added server-verified Google, Telegram OIDC/PKCE, email OTP and passkey flows; preserved old internal endpoints for compatibility.
- Universal workflow remained byte-identical.
- Local combined backend+architecture result: 139 PASS.
- `LIVE_E2E` not claimed: no real DB/deployment/provider credentials were available in this execution environment.

## 2026-08-08 — GitHub run 84786542178 corrective
- First real failed step: Gradle Kotlin DSL script compilation in `android/app/build.gradle.kts`.
- Confirmed errors: line 13 `Unresolved reference: net`; line 55 `Unresolved reference: it` was cascading because `telegramAppCallback` type resolution failed.
- Root cause: fully qualified `java.net.URI(...)` collided with the Gradle Kotlin DSL `java` accessor namespace.
- Minimal fix: use Gradle's supported `uri(telegramAppCallbackUri.get())` API; workflow and version remain unchanged.
- Added regression guard in `tests/architecture/test_cycle_0003_backend_auth_sync.py`; targeted result 14/14 PASS.
- Exact GitHub rerun is still required before claiming Gradle/Android compile PASS; later build stages were not reached in the supplied run.

## 2026-08-08 — canonical PNG logo replacement

Owner supplied a 1536×1536 image and explicitly ordered it to become the logo everywhere and the permanent visual reference. Binary signature proved the uploaded bytes were JPEG/JFIF despite the `.png` transport filename. The byte-exact upload is preserved under `brand/source_provenance/` (SHA-256 `22272c9dfbd9710447857011f6e8a7ccad4a501b8941ab1a61ead24516a8eba8`); the same decoded RGB pixels are preserved losslessly as canonical `brand/logo_brotherhood.png` (SHA-256 `47657ba1a1f9dd99cb9b275ea485b8bfdf3a5ac19de33f5187934eaf3b573e19`). Updated active Android in-app/launcher/splash resources, created maintained HTML visual-check page, archived old BR SVG under `brand/history/`, and created active brand canon. No model/auth/workflow semantics changed.

## 2026-08-08 — GitHub runs 84790063345 / 84792124384 and standalone HTML corrective
- Both supplied runs reached `:app:compileDebugKotlin` and failed on the same real source defect: `BrotherhoodApp.kt` referenced `ApiConfig` without importing the existing `network.ApiConfig` object. Run 84790063345 reported lines 309/321; run 84792124384 reported lines 308/320 after source line movement.
- Minimal fix: added `import org.federationofavatars.brotherhood.network.ApiConfig`. No workflow change and no version bump.
- The `Unable to strip libandroidx.graphics.path.so` line in run 84792124384 is a non-fatal packaging warning; the actual failed task is Kotlin compilation.
- Standalone logo-preview failure was independently confirmed: the exported HTML used a relative `../../brand/logo_brotherhood.png` path that only exists inside the repository tree.
- Preview is now self-contained: a 512×512 lossless PNG derivative is embedded once in CSS; all 15 logo surfaces use that embedded resource; there are no scripts or external image paths. Canonical `brand/logo_brotherhood.png` remains byte-identical.
- Regression evidence after patch: backend + architecture 145 PASS; JSON 50 PASS; XML 15 PASS; frozen workflow SHA unchanged.

## 2026-08-08 — Android install investigation + logo placement correction v0.5.25
- Owner reports green CI but Android installation/unarchival failure; exact green log/artifact and Android Package Installer message were not supplied in this turn, so device-side root cause is not promoted to fact.
- Source comparison v0.5.23→v0.5.24: AndroidManifest SHA is identical; applicationId/minSdk/targetSdk unchanged; dependency graph unchanged; major Android delta is logo/launcher resources plus versionCode 29.
- Supplied earlier CI logs explicitly show Development signing secrets absent and `NON_CANONICAL_DEBUG`; this is the strongest confirmed update-install risk when an older Brotherhood package remains installed.
- Owner screenshot proved the HTML/layout model was not a faithful visual target. Corrected in-app logo windows to 128dp Auth / 48dp TopAppBar with no extra Compose clipping; adaptive icon to 66dp safe artwork in 108dp layer.
- Canonical 1536×1536 logo master remains byte-identical; Android runtime derivative reduced to 512×512 for bounded resource/decode cost.

## 2026-08-08 — known-good v0.5.19 → v0.5.27 regression audit
- Owner identified v0.5.19/versionCode 24 as the last confirmed working Android baseline and explicitly excluded signing/update warning from the investigation.
- Compared v0.5.19, v0.5.21, v0.5.22, v0.5.23 and v0.5.24 Android trees. v0.5.19→v0.5.22 retains the same dependency class; v0.5.23 is the first major package/auth delta.
- v0.5.23 adds Credential Manager (`credentials`, `credentials-play-services-auth`), Google ID, AndroidCredentialGateway, SessionStore, AuthRemoteRepository, `singleTask` and Telegram callback intent filter. It also introduces the CI-observed native `libandroidx.graphics.path.so` packaging warning. The warning is non-fatal and is not asserted as root cause.
- v0.5.27 moves Credential Manager from 1.7.0-alpha03 to stable 1.6.0 and removes invalid App-Link verification from the custom `brotherhood://` callback while preserving all auth routes.
- Owner screenshot independently disproved the previous PNG preview/layout model. Old SVG occupied a smaller glyph inside 96dp Auth / 38dp TopAppBar total containers; the new PNG is already complete framed artwork. v0.5.27 restores those total footprints as the PNG size, removes SVG-style nesting, and uses full adaptive foreground layer.
- Status: source regression localized and bounded patch applied; exact install root cause remains NOT_CONFIRMED until v0.5.27 device test or PackageInstaller/adb code.


## 2026-08-09 — square-only Brotherhood logo correction v0.5.27
- Owner explicitly declared the Brotherhood logo strictly square and ordered all logo-specific circular areas/variants removed.
- In-app placement stays unchanged from the accepted arrangement: Auth 96dp square, TopAppBar 38dp square, `ContentScale.Fit`, no logo clip mask.
- Removed `android:roundIcon`, `ic_launcher_round*`, adaptive launcher XML, monochrome/themed logo derivative.
- Added square launcher PNG density assets: 48/72/96/144/192 px.
- Android 12+ system splash uses an invisible drawable because the platform splash icon is circularly masked; first Compose surface shows the square logo.
- Added `scripts/verify_square_logo_apk.py` and `docs/HANDOFF/LOGO_SQUARE_APK_DEVICE_CHECK.md`. Source checks are LOCAL_PASS; exact APK/device screenshots are required for APK_VISIBLE.

## 2026-08-09 — v0.5.27 device UX evidence → v0.5.28 recovery
- Owner installed exact v0.5.27 APK through SAI. Installation therefore moved from uncertain PackageInstaller diagnosis to user-device PASS for that artifact.
- Owner device findings: Home is severely overloaded; information hierarchy is unclear; completed test results are not discoverable; Android system Back does not restore the previous Brotherhood screen.
- Source audit confirmed the causes: DashboardScreen rendered a long sequence of duplicated feature/profile cards; test results had no dedicated route; BrotherhoodApp had no Compose BackHandler and MainViewModel stored only one current route without history.
- v0.5.28 applies a bounded UX patch without deleting functions: simplified welcome Home, dedicated results route, and navigation history.
- Diia reference used: HomeScreenTab/ServiceScreen explicitly route Android Back into UI events and keep top/body/bottom containers distinct. Reference only; no code copied.


## 2026-08-09 — v0.5.28 full offline demo recovery
- Owner reported that the reduced v0.5.28 HTML did not satisfy the required demo workflow and supplied `FRONTEND_v066.html` as the structural reference.
- Active demo was rebuilt as a full standalone stateful Brotherhood workbench: live phone preview + technical route/state controls, inline CSS/JS/PNG, zero external network assets.
- Browser smoke verified Home → People → Candidate → Chat, message send, Tests → six answers → Results, Settings and demo persona switching. Desktop and 390×844 mobile layouts were visually inspected in headless Chromium via in-memory HTML loading.
- Active HTML demo contains multiple synthetic identities; Android runtime account/demo-profile data is unchanged by this maintenance.
- `Глава Федерации` removed from active Brotherhood demo UI.
- Existing Android routes/functions were not removed; workflow unchanged.

## 2026-08-09 — v0.5.29 owner UX correction

Owner clarified that `FRONTEND_v066.html` was supplied only as an example of demo-workbench organization, not as a data donor. Audit confirmed v0.5.28 had real backend repositories plus fixture/ViewModel fallback, but no dedicated stateful Android simulation engine. It also confirmed bottom navigation was nested inside Home and disappeared on overlay routes.

v0.5.29 introduces root persistent navigation, a dedicated Android DEBUG `DemoBackendSimulator → DemoSimulationEngine`, a semantic light palette, and a full standalone BackendSimulator → SimulationEngine → frontend mirror. No EFHC business data from the reference HTML was copied.

## 2026-08-09 — v0.5.30 product/Kernel integration

Owner confirmed male-only business/social club, four-action Home and candidate-only dating-like discovery mechanics. Universal Operator Kernel v002 integrated with runtime-primary routes, hooks, six agent roles, skills/risk/memory/rules/capsules/tests and separate DEVELOPMENT/RELEASE packaging. Local Android source changed only in the Home hierarchy/version metadata; full Gradle/APK remains GitHub pending.

## 2026-08-09 — cycle 0004 Compatibility Research Foundation
- Started from the real uploaded DEVELOPMENT content after SHA-256 comparison of both supplied ZIPs; the two input ZIPs were byte-identical, while internal manifest/KERNEL identify runtime `v0.5.31 / versionCode 36`.
- Ran Operator Kernel startup and route-scoped audit. Primary research scope is compatibility research/model + cycle planning; Android/backend/database/protected test mechanics remain read-only.
- Confirmed two handoff suspicions were already repaired in HEAD: `PROJECT_MANIFEST.json` already referenced `Brotherhood_v0_5_31.zip`, and `KERNEL.md` already prohibited fixed cross-metric weights. Did not re-edit facts that were already correct.
- Confirmed remaining drift: legacy weighted aggregate persists in Android `HybridCompatibilityEngine.kt`/localized runtime wording and protected historical documentation. Runtime/protected files were not modified; active supersession/replacement documentation records the migration gap.
- Added canonical modular Compatibility/QF/Trust documentation, nine independent metric methodology packages, visual/forced-choice research program, five role-context research programs, source→claim matrix, causal model, evidence crosswalk and current `APK_SOURCE_MAP_v003` while preserving v002 history.
- Expanded compatibility source registry from 40 to 45 sources without replacing its existing detailed evidence taxonomy. Brotherhood-specific mappings stay HYPOTHESIS until calibration/validation.
- Restructured major roadmap to cycles 0004–0031; cycle 0003 remains external LIVE_E2E pending rather than falsely marked complete.
- Documentation revision target is `v0.5.33-docs-cycle0004`; Android versionName/versionCode are intentionally unchanged.


## 2026-08-10 — cycle 0005 Scientific Source Registry & Evidence Taxonomy
- Re-ran Operator Kernel and kept Android/backend/database/protected tests read-only.
- Expanded the compatibility registry from 45 to 60 sources and added 15 verified priority sources across testing standards, forced-choice, friendship, communication/attachment, values, interests/work fit and traditional software provenance.
- Added a 24-claim machine-readable evidence ledger with population/method/effect/limitations, review depth, applicability and rights status. All current entries keep production scoring disabled.
- Separated evidence strength from applicability and from licensing/content reuse. IPIP public-domain use, HEXACO non-academic licensing boundary, EUPL/MIT repository terms and unresolved instrument rights are not collapsed into one evidence grade.
- Added license/use matrix, bibliography, web evidence ledger and prioritized open research questions.
- Recorded that forced-choice/image-based assessment evidence is design-specific and does not validate arbitrary Brotherhood visual loadings; all protected stimulus→trait relations remain hypotheses.
- Runtime/versionCode and protected mechanics remain unchanged. Next research cycle: 0006 Psychological Construct Architecture.

## 2026-08-10 — Cycle 0008 Calibration & Psychometric Validation Protocol
- Owner Q31 sets exact 13-locale scope: `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`; all research/adaptation/calibration uses this set.
- Added intended-use validation, reliability/MTMM/invariance/DIF/sample-size/holdout/promotion protocols and 13-language adaptation matrix.
- Expanded research registry to 73 sources and claim ledger to 29; all claim production-scoring flags remain false.
- Structural 13-locale runtime/i18n activation implemented without protected 100×6/scoring changes; Android metadata `0.5.32 / code37`.
- Full architecture 147 PASS and backend 52 PASS. Android Gradle local execution blocked because wrapper JAR download cannot resolve github.com; no APK/device PASS claimed.
- Full standalone HTML 13-locale parity remains a later explicit parity task; no simplified mock introduced.


## Cycle 0016 work note
Communication Compatibility was kept independent from Psychology/Values/Interests/Lifestyle/Quality Fit/Trust. The baseline uses only versioned pre-exposure preference snapshots; post-contact actual communication is reserved for Research Platform outcome/process evaluation. No Android/backend/database/protected 100x6 change was authorized.
## Cycle 0017 — Lifestyle Compatibility
LC was kept independent from Interests/Communication/Values/Psychology/QF/Trust. Baseline is deterministic constraint-first and uses only pre-exposure practical lifestyle snapshots; hard constraints, soft preferences, missingness and sensitive constraint-only inputs are explicit. Q36 turns the whole `179`-source registry into a unified research synthesis corpus while retaining separate rights/provenance metadata. No Android/backend/database/protected scoring change was authorized.

## Cycle 0022 — Hospitality Release-Parity / Research Outcomes / Security RC
Confirmed HEAD `Brotherhood_v0_5_51.zip`. Activated owner Q37 final product concept. Regenerated investor simulation contract from current source to 80 OpenAPI paths / 93 operations / 47 migration-defined tables / 21 Android AppRoutes. Standalone HTML now mirrors seven Hospitality routes and complete state/verification/blind-review/reputation/research lifecycle; Android DEBUG/offline DemoRepository/BackendSimulator/SimulationEngine and MainViewModel fallback were extended without replacing authenticated production repositories. Added Hospitality historical-exposure→verified-stay→7/30/90/180/365 research contracts, confounders/privacy/no-auto-learning guards. Protected 100×6 unchanged. Browser navigation smoke is administrator-policy blocked; GitHub APK/device/live evidence remains external.

## 2026-08-11 — Product functionality audit
- Audited actual v0.5.54 source path for `AssessmentCatalog → VisualAssessmentFactory → AssessmentScorer → AssessmentLocalStore/backend → LatentProfileEngine → SelfAnalysisEngine → TestResults/SelfAnalysis UI`.
- Verified actual source scaffold: 100 assessments × 6 tasks, four choices, latent scoring, local/backend persistence.
- Verified product gaps: procedural Canvas stimuli remain prototype; test result mostly generic; no monthly retake enforcement; psychoanalysis partial; full psychoreport absent; HTML owner acceptance still open.
- Updated product/cycle governance so new research cannot outrun implementation again.

## 2026-08-11 — cycle 0024 Psychological Report persistence / server Q28 / full simulation
- Continued from DEVELOPMENT HEAD `Brotherhood_v0_5_57.zip` through Operator Kernel.
- Added immutable/idempotent Psychological Report persistence/history, migration 0011, save/latest/history/by-id API and Android network contract without prematurely mirroring unaccepted UI.
- Added server-backed Q28 `PC/IC/VC/CC/LC/PT/EN/NU/AS`, metric preferences, ten current psychological module pair comparators and explicit `INSUFFICIENT_DATA` semantics. Trust/Account Rating remain separate.
- Regenerated source contract to 87 OpenAPI paths / 100 operations / 49 migration-defined tables / 21 Android AppRoutes.
- Expanded standalone full simulator to exactly 200 deterministic synthetic candidates plus current user, 20,100 simulated assessment-result rows, route-backed report history and Q28 data. Frontend fake arithmetic offsets were removed from active Compatibility path.
- Re-verified official `diia-open-source/android-diia` release commit `067c4dc19332c0fdd83b12db2274771494128a50`; recorded feature isolation, reusable shell, explicit Back, top/body/bottom and progressive-flow principles; no donor code/branding/data copied.
- Verification: architecture 276/276 PASS; backend 74/74 PASS; protected mechanics 17/17 PASS; Operator Kernel PASS; JSON 117/117 parse; HTML JS syntax PASS; simulator probe 100/100 operations, 0 failures, 49 tables. Browser visual smoke remains administrator-policy blocked; Android Gradle compile/live DB/GitHub CI/APK/LIVE E2E NOT_RUN.
- Next: cycle 0025 HTML UI Recovery A and owner visual acceptance before Compose visual mirror.

### 2026-08-11 / cycle 0024 governance continuation
Owner-provided BROTHERHOOD_SOURCE_MAP_v004 activated as the unified typed registry. Scientific, UX/visual, product-donor, technical, legal and data classes now have explicit non-leaking authority contracts. Active assigned roadmap is 0024–0073 (50 cycles), reserve 0074–0100. Historical plans retained without deletion.


## 2026-08-11 — Cycle 0026 UI Recovery B
- Search Requests promoted to first-class persisted/API entities; Community membership API added.
- Generated source contract now 90 paths / 108 operations / 50 tables / 21 Android AppRoutes.
- Active HTML v0_5_37 exposes route-backed Chat/Groups/Search Requests; VA pending.
- Existing Chat backend preserved; no Compose/CI/live qualification claimed.

## 2026-08-13 — Roadmap note Q48: reverse friendship pattern discovery
- In addition to forward validation (`did the frozen Brotherhood method predict a later friendship?`), collect reverse evidence after a friendship is mutually confirmed: `what specifically was already similar, different/complementary, or method-consistent in this pair before friendship?`.
- Preserve the predictor snapshot at exposure/pre-friendship time; do not reconstruct it from post-friendship profiles.
- Compare confirmed friend pairs only against pairs with sufficient interaction opportunity/exposure, not against every non-friend pair.
- Analyze similarity, difference/complementarity and method-level features separately; later longitudinal hardening must distinguish selection/homophily from post-friendship convergence/socialization.
- Reverse-pattern output is descriptive/hypothesis evidence and never silently rewrites production scoring. Hardening/denominators/uncertainty/fairness live in cycle 0038.

## 2026-08-13 — Roadmap note Q49: Friendship Reflection Surveys after real meetings/friendship
- In addition to passive/behavioral Q48 reverse analysis, Brotherhood should selectively invite people after verified real meetings and/or mutually confirmed friendship to answer special social-research surveys about **why they became friends**.
- Both sides answer independently; their answers are stored separately and may later produce bilateral agreement/disagreement features.
- The research should compare friends’ retrospective explanations with the frozen pre-friendship/exposure feature snapshot: what they say mattered, what the system measured as similar/different, and where current constructs fail to explain a friendship.
- Candidate blocks: meeting context, why contact continued, top friendship-forming factors, perceived similarity, useful complementarity, trust/safety moments, reciprocity/help, communication/conflict repair, shared values/interests/goals, timing/proximity/life stage, counterfactual “would friendship still form without X?”, and optional open text.
- The survey mechanism is internal research/social polling; it must not directly change Trust, Account Rating, Compatibility or Quality Fit.
- Plan implementation in cycle 0038, 13-locale wording/sampling hardening in 0040, verified-interaction trigger integration in 0064, and lifecycle E2E in 0072. Do not add a new numbered cycle.
- Canonical plan: `docs/research/outcomes/FRIENDSHIP_REFLECTION_SURVEYS_V1.md`.

## 2026-08-13 — Cycle 0030 same-cycle expansion: Numerology reading v3
- Owner requested another pass of cycle 0030 before VA, with additional calculations/data and a broader standalone Numerology section. Work continued from packaged `Brotherhood_v0_5_70.zip`; cycle 0031 was not started.
- Kept active methodology boundaries: no new numerology school, no personal-year/month/day or astrology/Dasa periods without an approved source/method contract; name-derived values remain descriptive-only; independent NU and Q28 arithmetic-mean semantics remain unchanged.
- Upgraded immutable reading payload to `numerology-reading-v3`: deterministic arithmetic/reduction traces, ruler metadata for date Soul/Destiny/Maturity, complete birth-date digit inventory 1..9 including missing positions, and exact calendar dates corresponding to the already-defined four Pinnacle ages.
- Productized the full existing normalized knowledge as a read-only catalog: 97 records total in `life_paths=11`, `soul_numbers=11`, `outer_numbers=12`, `birth_chart=52`, `pyramid_peaks=11`; added catalog index/detail API routes.
- Expanded saved NU comparison records with frozen Soul/Destiny inputs and per-component ruler/relation details. Existing `vedic-numerology-runtime-v1` formula remains Soul 40% / Destiny 35% / cross 15% / date composite 10% inside NU only.
- Expanded standalone HTML to v45 with Profile, Calculation, Peaks, full Date Chart, Catalog, History and Compare surfaces. Frontend remains route-backed through BackendSimulator/SimulationEngine.
- Source contract after expansion: 117 OpenAPI paths / 136 HTTP operations / 54 tables / 21 Android AppRoutes; schema15. SimulationEngine probe 136/136 PASS / 0 failures. Targeted Numerology backend 11/11 PASS; full backend 99/99 PASS; architecture 275/275 PASS.
- Q49 Friendship Reflection Surveys contract/roadmap remains active and research-only; no runtime scoring mutation was added in this pass.
- Owner visual acceptance remains PENDING; no Compose/APK visual mirror was performed.


## 2026-08-13 — Cycle 0031 Zodiac standalone application vNext
- Continued from confirmed DEVELOPMENT HEAD `Brotherhood_v0_5_71.zip`; Operator Kernel validate-config PASS.
- Diagnosed the owner's inactive-Development observation: standalone HTML/CANON already has `Профиль → Люди → Чаты → Группы → Развитие`; Android still has the old `HOME / DISCOVER / MESSAGES / COMMUNITIES / PROFILE` enum and `Главная` label because Compose mirroring is gated by owner VA. No feature flag/backend defect was found, and Android was not silently changed before acceptance.
- Implemented server-authoritative `AS_ZODIAC_BASIC_V1`: `zodiac-basic-reading-v1`, `zodiac-basic-catalog-v1`, existing `zodiac-runtime-v1` pair scorer, immutable readings/history and persisted pair comparison/history. Added migration 0016 with only `zodiac_readings` and `zodiac_pair_comparisons`; schema16.
- Consolidated the existing Q28/Android basic rule into one scorer: same sign 86, same group 90, supported Fire↔Air or Earth↔Water 84, other supported pairs 66. Exhaustive tests cover all 144 ordered sign pairs.
- Kept the scientific/product boundary explicit: AS is traditional/alternative and opt-in; `ASTRO-001` is negative controlled evidence. No natal chart, houses, aspects, Moon, Ascendant or synastry were invented; `AS_SYNASTRY_V1` remains future-only.
- Expanded standalone HTML to v46 with Zodiac Profile / Method / 12 Signs / History / Compare. Development home now reads latest NU/AS summaries through routes.
- Generated source contract: 126 OpenAPI paths / 145 HTTP operations / 56 DB tables / 21 Android AppRoutes. Local SimulationEngine probe 145/145 PASS / 0 failures. Owner VA remains PENDING; no Compose/APK visual mirror performed.
- Pre-package verification finalized: backend 107/107 PASS; architecture/current-product 278/278 PASS; focused Zodiac/Numerology/Q28/0029 38/38 PASS; JSON 127/127; HTML parser and 2/2 JS syntax PASS; external assets 0; nine Zodiac routes 9/9; schema16 persistence reload PASS; adversarial invalid-date/unknown-sign/inactive-synastry boundaries PASS; Android delta vs v71 is 0/0/0.

## 2026-08-13 — Cycle 0032 Enneagram standalone + full Development demo correction
- Continued from confirmed DEVELOPMENT HEAD `Brotherhood_v0_5_72.zip`; Operator Kernel validate-config PASS.
- Owner rejected the previous reduction of the `Развитие` issue to Android mirroring and clarified the required target: the standalone Simulator must itself run a complete Development demo. Cycle 0032 implements this directly as `DEVELOPMENT_FULL_DEMO_V1`, not as an Android/feature-flag workaround.
- Simulator schema17 now bootstraps Tests 12/12, Associative/Implicit 3/3, Numerology reading + NU history, Zodiac reading + AS history, and Enneagram reading + EN history. A `Development demo` workbench action / `ACTIVATE_DEVELOPMENT_DEMO` restores the full scenario. Root default remains `Профиль` per Q45.
- Productized the existing Brotherhood Enneagram runtime only: 18 local visual items (2 per each of 9 types), hidden scoring keys, deterministic type/wing selection and the existing Q28 EN pair formula. No new Enneagram system or type psychology was invented.
- Added server-authoritative `EN_BROTHERHOOD_CORE_PROFILE_V1`, `enneagram-core-profile-18-v1`, immutable `enneagram-reading-v1`, route-backed 9-type catalog, and persisted `enneagram-existing-runtime-v1` pair history. Migration 0017 adds only `enneagram_readings` and `enneagram_pair_comparisons`; schema17.
- `ENNEA-001` remains the scientific boundary: systematic review reports mixed reliability/validity, therefore Enneagram is typological/experimental and never presented as validated psychometrics, diagnosis, Trust, Quality Fit or relationship-success probability.
- Standalone/Q28 EN scorer is shared; exhaustive backend regression covers all 81 ordered main-type pairs with supported wings. Initial Enneagram backend suite 8/8 PASS; Numerology+Zodiac+Enneagram targeted 27/27 PASS.
- Expanded standalone HTML to v47 with Enneagram Home / Method / 18-choice Run / Profile / 9 Types / History / Compare. Development home visibly reports full demo readiness and reads NU/AS/EN current summaries through SimulationEngine routes.
- Generated source contract: 136 OpenAPI paths / 155 HTTP operations / 58 DB tables / 21 Android AppRoutes. Embedded Node SimulationEngine probe 155/155 PASS / 0 failures; full Development bootstrap assertion PASS.
- Owner visual acceptance remains PENDING; no Compose/APK visual mirror performed.

### Cycle 0032 final pre-package regression
- Full backend 115/115 PASS; architecture/current-product 282/282 PASS; protected Development/0028–0032 focused regression 42/42 PASS; JSON 127/127 PASS; Kernel/cycle ecosystem PASS.
- Embedded SimulationEngine remains 155/155 PASS / 0 failures / 58 tables, persistence schema17, `DEVELOPMENT_FULL_DEMO_V1` active.
- Owner VA remains PENDING; Android/Compose source is intentionally unchanged in this HTML-first cycle.

## 2026-08-14 — Cycle 0032 standalone HTML browser-runtime correction
- Owner correctly reported that repeated standalone HTML deliveries were non-working.
- Reproduced in real Chromium: v47 startup `ReferenceError: ZODIAC_SIGN_ORDER is not defined`; after first correction, `testsScreen is not defined`; deeper route smoke exposed additional cross-script symbol scope defects.
- Root cause: first simulator script is an IIFE, while second UI script referenced several non-exported lexical constants/functions; static `node --check` cannot detect this runtime linkage class.
- v48 explicitly exports/imports required symbols, restores `testsScreen()`, restores `initials()`, and completes Numerology workbench route entries.
- Real Chromium gate: 64/64 route screens non-empty, 0 page errors; full Development user-flow smoke PASS. Future HTML delivery must run browser execution before packaging.

## 2026-08-16 — Cycle 0033 Quality Fit / SearchIntent v2 + Development UX stabilization
- Continued from packaged DEVELOPMENT HEAD `Brotherhood_v0_5_74.zip`; Operator Kernel validate-config PASS.
- Owner reported two simulator defects: not all 12 seeded tests could be retaken and long pages repeatedly jumped/ejected while reading. Both were reproduced in code/runtime instead of treated as visual-only feedback.
- Retake root cause: demo results were only 1–12 days old while the active product uses a calendar-month retake gate. Demo completion timestamps now use `78 + 3*n` days in the past. Product retake logic is unchanged. Real Chromium shows 12/12 `Повторить` and successfully completes a seeded 20-question test to a newly saved result.
- Page-jump root cause: every 5-second `engine_tick` emitted to a global subscriber that fully rerendered the current screen; `renderScreen()` reset `scrollTop=0`. Incoming-message state could cause the same class of rerender. Cycle 0033 removes full content render for background tick/non-current incoming events and adds same-route scroll/focus/value preservation. Chromium verifies scroll `500→500` after both tick and incoming-message trigger.
- UX donor research refreshed using current official Diia service/cabinet guidance, Diia open-source reusable UI primitives, Apple HIG navigation/layout/scroll guidance and GOV.UK service/task navigation patterns. These remain UX/product-donor authority only. Development/Tests/results were refactored to calmer service lists, stronger hierarchy, fewer decorative badges/cards, one-question test flow and a readable adult result report.
- Implemented Quality Fit/SearchIntent v2: explicit requirements, hard vs preference, directional SEARCHER_A_TO_CANDIDATE_B, missing evidence = INSUFFICIENT_DATA, no hidden role defaults and no mixing with Q28/Trust/Rating/Hospitality. Existing 112-item QF catalog remains mapping authority.
- Added migration 0018, one new `quality_fit_evaluations` table, structured search-request requirements and five QF API routes. Generated current source contract: 141 paths / 160 operations / 59 tables / 21 Android AppRoutes; schema18.
- Added mandatory real-browser regression `scripts/check_cycle0033_html_runtime.py` and architecture guard `test_cycle0033_quality_fit_stable_service_ux.py`.
- Pre-freeze verification: backend 122/122 PASS; architecture/current-product 291/291 PASS; cycle0033 architecture 6/6 PASS; Chromium runtime PASS with 0 page/console errors and full route probe 160/160 fail:0.
- Owner VA remains PENDING; Android/Compose/APK unchanged and not used for visual acceptance. Next after package/owner corrections: 0034 Unified Multi-method Compatibility Service + persistence.


## 2026-08-16 — OWNER SINGLE-MODULE ROADMAP RESET
- Owner rejected multi-module cycle strategy and ordered detailed decomposition.
- New active future program: `0034–0100`, 67 planned single-module cycles.
- Immediate priority is test integrity/science/UX (`0034–0043`), not Unified Compatibility.
- Owner supplied 289 MB tooling sandbox with 8 source snapshots; inventory/license/capability map stored in `docs/research/tooling/LICENSED_ASSESSMENT_TOOLING_SANDBOX_V1.md`.
- Owner separately confirms official authorization for УрРАС/ЕВРАС/РАС data use and Brotherhood normative construction; governance record created.
- No product/backend/Android/HTML functionality changed by this roadmap package.

## 2026-08-16 — owner execution decomposition 0101–0200
- Owner rejected the still-too-broad execution pattern during attempted cycle0034.
- Unfinished 0034 working changes are not accepted into HEAD.
- Created `BROTHERHOOD_CYCLES_0101_0200.md` and `BROTHERHOOD_ROADMAP_0101_0200.md`.
- Assigned exactly 50 executable microcycles `0101–0150`; reserve `0151–0200`.
- `0034–0100` retained as parent outcome map only.
- Next executable: `0101 Public Test Catalog Redaction v1`; scope explicitly excludes sessions/resume/scoring.


## 2026-08-16 — Cycle 0034 Secure Test Administration Runtime v1
- Owner direct execution override: cycle 0034 implemented as one module; no parallel Tests UX/Associations/psychometrics work.
- Public test definitions redacted: no full items, construct mapping, polarity or scoring keys in ordinary client API.
- Added owner-bound sequential administration sessions with opaque item tokens, server-side finalization, resume and immutable prior responses.
- Legacy direct scoring and client-authored result writes fail closed with HTTP 410.
- Local evidence only: targeted 5/5, backend 127/127, architecture 299/299, Chromium PASS, simulator 163/163 / failures 0 / 60 tables.
- CI is NOT_RUN_BY_OWNER_ORDER and must not be invoked unless the owner explicitly changes that instruction.
- HTML candidate: BROTHERHOOD_UI_SIMULATOR_v0_5_50.html; VA remains PENDING.


## 2026-08-16 — Cycle 0035 secure test human result correction
- Owner rejected technical/methodological wording on test result screens.
- Added server-authoritative respondent-facing feedback for all constructs used by 12 product test-apps.
- Added owner-only immutable-result feedback route; scoring and questionnaire bank unchanged.
- Active HTML moves to v51; historical v50 preserved.
- Current runtime: 145 paths / 164 operations / 60 tables / 21 AppRoutes / schema19.
- CI explicitly not run by owner order.


## 2026-08-16 — Cycle 0111 Questionnaire Bank Inventory Freeze v1.3
- Started from uploaded DEVELOPMENT package `Brotherhood_v0_5_79.zip`; package SHA-256 `415b6808a695fa639d485cf17abe6f3a076537d31816804d9b1f4dd5268e5110`.
- Operator Kernel `validate-config`: PASS 16 routes / 8 hooks / 6 agents / 6 skills.
- HEAD audit confirmed next executable microcycle `0111`; 0101–0110 remain satisfied by owner-direct 0034.
- Active questionnaire authority: `scientific-questionnaire-bank-v1.2`; 197 items / 12 product test apps / 7 systems. Backend and research mirror bank/catalog are byte-identical.
- Created immutable metadata snapshot `QUESTIONNAIRE_BANK_INVENTORY_V1_3.json` plus SHA sidecar and human audit. 197/197 rows; duplicates/orphans/unassigned/multi-assigned/missing construct/scoring direction/source linkage = 0; active legacy visual-bank items = 0.
- Added cycle0111 regression guard with frozen bank/catalog fingerprints and exact reconstructed metadata parity.
- No wording, scoring, polarity, constructs, psychometrics, Associations, Compatibility, Trust, Quality Fit, Android or HTML changes.
- CI: NOT_RUN_BY_OWNER_ORDER.
- Next executable after package closure: `0112 — Questionnaire Source Trace Completeness Audit`.


## 2026-08-17 — owner sequential cycle-order correction
- Owner ordered cycles to be rearranged into numeric order after questioning the 0035→0112 jump.
- Active execution authority returns to ascending parent IDs: 0034/0035 implemented; next = 0036.
- Completed 0111 inventory evidence is preserved and not re-run, but is classified as out-of-order historical execution under the superseded microcycle routing.
- 0112–0150 remain decomposition/reference only unless explicitly reactivated. No scientific audit, wording, scoring, runtime, HTML or Android changes are performed by this governance correction.
- CI: NOT_RUN_BY_OWNER_ORDER.
## 2026-08-17 — Cycle 0036 Neutral Respondent Wording & Response Design v1
- Input HEAD `Brotherhood_v0_5_81.zip` verified SHA-256 `3c4460d935ee41c1a4ba0cbbc1bc1066d93b5dcfdacdf164eaee56cb62880056`; Operator Kernel validate-config PASS 16 routes / 8 hooks / 6 agents / 6 skills.
- Active parent roadmap confirmed cycle0036. Bank advanced wording-only from v1.2 to `scientific-questionnaire-bank-v1.3`, instrument to `text-situational-neutral-v1`; scoring remains `scientific-questionnaire-v1`; item IDs/count remain 197.
- 180 situational items receive respondent-neutral behavioral pairs; 17 direct public-domain anchors remain separate. Secure runtime provides stable per-session AB/BA via opaque token and canonicalizes BA response before scoring. `comprehension_flag` is response metadata.
- Standalone active candidate advanced v51→v52. Local Chromium cycle0036 flow PASS with resume stability, comprehension metadata, completed human result, 0 page/console errors and SimulationEngine 164/164 route probe.
- Android unchanged pending owner VA. No psychometric validity/reliability/factor/invariance/DIF/diagnosis/faking-resistance claim is introduced.
- Next parent cycle after successful final package gate: 0037. CI: NOT_RUN_BY_OWNER_ORDER.

