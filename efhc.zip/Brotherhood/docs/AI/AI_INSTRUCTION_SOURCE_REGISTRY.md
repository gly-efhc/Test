# Brotherhood AI Instruction Source Registry

| Source | Scope | Status | Priority | Conflicts | Action |
|---|---|---|---:|---|---|
| Current explicit user instruction | current task | CANONICAL | 1 | none may override it | obey |
| Owner-confirmed entries in `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md` | product decisions | CANONICAL | 2 | newer owner answer supersedes earlier OPEN/proposal | route-scoped |
| `START_HERE.md` | startup adapter | ACTIVE_ADAPTER | 3 | must stay compact | load first |
| `KERNEL.md` | project dispatcher | CANONICAL | 4 | cannot replace domain CANON | load |
| `AGENTS.md` | Codex/agent startup adapter | ACTIVE_ADAPTER | 4 | must not duplicate/override Kernel | load `START_HERE`/`KERNEL` |
| `docs/CANON/**` | stable project truth | CANONICAL | 5 | resolve through truth hierarchy | route-scoped |
| `docs/SSOT/**` | fast/current state | CANONICAL | 6 | wins over stale reports | route-scoped |
| `docs/NORM/**` / ADR / `docs/AI/rules/**` | contracts/boundaries | CANONICAL | 7 | cannot expand user scope | route-scoped |
| `ops/operator_kernel/config/routes.yaml` | runtime route definitions | CANONICAL_RUNTIME | 8 | human route map is explanatory | runtime-primary |
| `docs/AI/reference/MASTER_PROMPT_KERNEL_UNIVERSAL_v002.md` | Kernel setup specification supplied by owner | REFERENCE / IMPLEMENTATION_SPEC | 9 | never overrides Brotherhood owner CANON | implement applicable capabilities |
| `docs/MEMORY/**` / `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` | shared/pending memory | ACTIVE_ADAPTER | 10 | cannot override CANON | route-scoped |
| current reports/logs | evidence | OPERATIONAL | 11 | facts only within evidence scope | use when relevant |
| historical reports/archives | history/reference | HISTORICAL | 20 | never active truth by age alone | historical route only |
| IDE/AI-specific local instructions not registered here | environment-specific | UNKNOWN | 30 | cannot silently override Kernel | inspect/register before use |

Old Claude/Codex/IDE instructions, if later introduced, act as adapters to `START_HERE`/`KERNEL`; they do not become a second project dispatcher.
