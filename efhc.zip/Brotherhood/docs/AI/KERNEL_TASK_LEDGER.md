# Brotherhood Kernel Task Ledger

| Task ID | Description | Route | Dependencies | Allowed write | Validation | Status | Evidence |
|---|---|---|---|---|---|---|---|
| K030-01 | Capture owner male-only business-club + four-action Home canon | product_discovery_ux | owner Q&A | product CANON/Q&A/UI/demo | product UX tests | VERIFIED_LOCAL | owner Q&A + source assertions |
| K030-02 | Integrate Universal Operator Kernel v002 capabilities | kernel_archive | owner master spec | Kernel/docs/operator/tests | validate-config + behavior/adversarial | VERIFIED_LOCAL | config/test output |
| K030-03 | Separate DEVELOPMENT and RELEASE source archives | release_packaging | K030-02 | package scripts/docs/reports/maps | deterministic package + archive inspection | IN_PROGRESS | package checks pending final map |
| K030-04 | Synchronize full standalone simulation demo | product_discovery_ux | K030-01 | root/tools demo | syntax + route/state/browser smoke | IN_PROGRESS | final smoke pending |
| K030-05 | Android v0.5.30 compile/APK/device verification | ci_android | K030-01 + packaged source | no local workflow mutation | frozen GitHub CI + device | DEFERRED_LIVE_CHECK | GitHub/device evidence required |
| K030-06 | Backend/PostgreSQL/provider LIVE_E2E | backend_api/auth_security/database | deployed environment | live only | provider/DB/runtime evidence | DEFERRED_LIVE_CHECK | real environment required |
