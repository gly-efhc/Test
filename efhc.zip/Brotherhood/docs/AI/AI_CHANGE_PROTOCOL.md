# AI change protocol

## Before edit
1. Resolve route.
2. Read active cycle.
3. Identify required/forbidden write boundaries.
4. Define validation and exit gate before modifying files.
5. Preserve current archive as baseline.

## During edit
1. Change only files required by root cause or active goal.
2. Avoid adjacent refactors.
3. Keep stable identifiers and contracts.
4. Add regression coverage for every confirmed defect.
5. Record decisions that alter future work.

## After edit
1. Run route-specific checks.
2. Run architecture guards.
3. Update cycle registry/status.
4. Promote stable facts to CANON/SSOT/NORM.
5. Move transient notes to work notes or historical report.
6. Refresh file maps.
7. Rebuild manifest.
8. Package deterministically and verify CRC/top folder/parity/hash.
9. Update handoff with exact next safe action.
