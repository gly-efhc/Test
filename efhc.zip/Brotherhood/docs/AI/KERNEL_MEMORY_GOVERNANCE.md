# Brotherhood Kernel Memory Governance

## Five layers

### CANONICAL
`KERNEL.md`, `docs/CANON/**`, `docs/SSOT/**`, `docs/NORM/**`, ADRs and owner-confirmed product Q&A decisions. Stores stable confirmed truth, not work logs.

### PROJECT_SHARED
Reusable verified engineering facts: valid commands, architecture boundaries, known failure patterns, source locations and verified integration notes. No secrets or host-specific credentials.

### LOCAL_PRIVATE
Machine-specific paths, local settings and temporary parameters. Never a source of project canon. Never package secrets, cookies, sessions or signing material.

### OPERATIONAL_PENDING
Primary file: `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`. Contains only the current request, unresolved observations/decisions, changed-file state, validation state, deferred/live checks and next safe action.

### HISTORICAL
Closed reports, previous handoffs, superseded audits/decisions and completed cycles. Historical content is reference-only and cannot override Current HEAD.

## Promotion flow
`observation → OPERATIONAL_PENDING → verification/owner confirmation → CANON/SSOT/NORM/ADR → remove duplicate pending entry → preserve closed trace in historical/current report`.

## Hygiene gate
Before a significant package: scan duplicates, stale facts, unresolved conflicts, uncertainty labels, promotion candidates, secrets/local-private leakage and historical facts masquerading as current truth. Fast-changing version/CI/live values belong in their current SSOT, not duplicated into Kernel prose unless they are a deliberate milestone reference.
