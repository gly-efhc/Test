# Brotherhood Kernel Golden Prompt Set

| Prompt ID | User prompt | Expected primary route | Secondary routes | Validation routes | Forbidden route loss |
|---|---|---|---|---|---|
| GP-01 | «Сделай спокойную главную мужского делового клуба: поиск людей, сообщения, тесты, поисковые запросы» | product_discovery_ux | android_ui_feature may be secondary | — | product canon/privacy |
| GP-02 | «Обнови Kernel, hooks, agents и routes» | kernel_archive | — | kernel_archive | runtime-primary routes |
| GP-03 | «Измени Home, обнови Kernel и подготовь release archive» | product_discovery_ux | kernel_archive | release_packaging + kernel_archive | product + governance + package |
| GP-04 | «Исправь backend auth global_id» | auth_security or backend_api | matching backend/auth route | — | identity/security |
| GP-05 | «По новым GitHub CI-логам исправь APK compile» | ci_android | exact evidenced domain only | ci_android | no unrelated UI rewrite |
| GP-06 | «Сделай романтические знакомства с девушками» | product_discovery_ux | — | — | must surface male-only canon conflict |
| GP-07 | «Посмотри старый архив для справки» | historical_reference | — | — | history cannot become active truth |
| GP-08 | «Неизвестная тема без проектного контекста» | historical_reference | — | — | safe fallback, no full archive read |
