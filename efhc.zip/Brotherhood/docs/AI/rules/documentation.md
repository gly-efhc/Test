---
rule_id: documentation_and_canon
paths: ["docs/**", "README*.md", "CHANGELOG.md", "KERNEL.md", "START_HERE.md", "reports/**"]
routes: ["kernel_archive", "cycle_planning", "historical_reference"]
required_read: ["START_HERE.md", "KERNEL.md"]
constraints: ["owner_answers_append_only", "history_not_active_truth", "mark_unknowns", "do_not_claim_unrun_checks", "do_not_change_runtime_from_docs_route"]
validation: ["path/reference checks", "JSON/YAML parse where applicable", "canon consistency tests"]
---

Every future application-design question/answer is appended to `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md`. Assistant proposals remain labeled until owner confirmation.
