---
rule_id: backend_api
paths: ["backend/app/**", "backend/api/**", "backend/tests/**", "docs/openapi.json", "shared/contracts/**"]
routes: ["backend_api", "auth_security", "psychological_visual_matching"]
required_read: ["docs/SSOT/CURRENT_STATE.md", "docs/AUTH_AND_SESSION_BOUNDARY.md"]
constraints: ["global_id_is_internal_owner", "do_not_disclose_private_latent_profile", "preserve_API_contracts_unless_task_requires_change", "no_live_claim_without_live_evidence"]
validation: ["backend pytest", "OpenAPI parse/contract checks"]
---

Provider subjects stay authentication identities; business ownership uses `global_id`. Local passing tests never substitute for real PostgreSQL/provider/deployment evidence.
