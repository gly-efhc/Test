---
rule_id: release_packaging
paths: ["PROJECT_MANIFEST.json", "README*", "CHANGELOG.md", "scripts/package_source_archive.py", "scripts/package_release_archive.py", "reports/**", "ops/operator_kernel/cache/**"]
routes: ["release_packaging"]
required_read: ["docs/NORM/BROTHERHOOD_RELEASE_ARCHIVE_POLICY.md", "PROJECT_MANIFEST.json"]
constraints: ["development_release_separation", "deterministic_package", "no_secrets", "no_nested_archives", "frozen_workflow_sha", "package_is_not_apk_build_proof"]
validation: ["deterministic source check", "deterministic release check", "CRC/path/symlink/denylist inspection", "hash"]
---

DEVELOPMENT contains full project context; RELEASE contains allowlisted runtime/build/deployment material only. Packaging must never mutate business logic.
