---
rule_id: database_schema
paths: ["database/**", "backend/app/storage.py"]
routes: ["database"]
required_read: ["docs/SSOT/CURRENT_STATE.md"]
constraints: ["preserve_global_id_identity_boundary", "no_destructive_migration_without_explicit_scope", "do_not_invent_live_database_state"]
validation: ["migration/static schema checks", "backend tests", "live DB gate when required"]
---

Schema/migration changes are never implied by a UI/product task. Destructive or production migration requires separate authorization and rollback evidence.
