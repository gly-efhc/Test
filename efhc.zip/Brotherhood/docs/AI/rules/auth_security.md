---
rule_id: auth_security
paths: ["android/app/src/main/java/**/auth/**", "backend/app/**", "docs/AUTH_AND_SESSION_BOUNDARY.md"]
routes: ["auth_security"]
required_read: ["docs/AUTH_AND_SESSION_BOUNDARY.md", "docs/CANON/BROTHERHOOD_PRODUCT_CANON.md"]
constraints: ["global_id_is_internal_owner", "provider_id_login_only", "preserve_session_revocation_and_device_binding", "no_secrets", "live_provider_claim_requires_evidence"]
validation: ["auth/backend tests", "Android architecture guards", "live provider gate when required"]
---

Do not relax guards merely to make a local test pass. Do not store real credentials, keystores or provider secrets in archives/reports.
