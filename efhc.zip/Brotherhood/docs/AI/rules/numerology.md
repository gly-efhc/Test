---
rule_id: numerology_self_analysis
paths: ["backend/app/numerology_vnext.py", "backend/app/data/**/numerology/**", "android/app/src/main/**/numerology/**", "android/app/src/main/assets/numerology/**", "shared/numerology/**"]
routes: ["numerology_self_analysis"]
---
Numerology is a standalone Development application and independent optional Q28 metric `NU=0..100%`.

Active cycle-0030 contracts:
- self reading: `numerology-reading-v3`;
- interpretation knowledge: `numerology-knowledge-v1`;
- pair compatibility: `vedic-numerology-runtime-v1`.

No hidden cross-metric percentage is allowed. Legacy wording that Numerology is a fixed `5%` of Brotherhood compatibility is superseded. The active `40/35/15/10` values are internal NU component weights only.

Birth-date-derived Soul/Destiny inputs drive NU compatibility. Name-derived Soul/Expression values remain descriptive and must not change NU compatibility unless a future explicitly versioned methodology supersedes this rule.

User-visible Numerology must carry traditional/non-psychometric disclosure and remain separate from Psychology, Trust, Account Rating, Hospitality Reputation and Quality Fit.

Canonical locale set: `sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`. Preserve full source-key coverage and source provenance. The shared normalized knowledge and packaged Android mirror must remain version-aligned.

Cycle-0030 v3 reading may expose only source-backed/previously defined calculations: arithmetic trace, date-number rulers, complete 1..9 date inventory, exact calendar dates for the already-defined Pinnacle ages, and the normalized 97-record knowledge catalog. Do not infer personal year/month/day, Dasa/astrology periods or another numerology tradition without an explicitly approved versioned method contract. Pair-history snapshots freeze the date-derived Soul/Destiny inputs and relation details for reproducibility.
