---
rule_id: operator_kernel
paths: ["START_HERE.md", "KERNEL.md", "docs/AI/**", "docs/CANON/**", "docs/SSOT/**", "docs/NORM/**", "docs/healer/**", "ops/operator_kernel/**", "tests/architecture/**"]
routes: ["kernel_archive"]
required_read: ["START_HERE.md", "KERNEL.md", "docs/AI/reference/MASTER_PROMPT_KERNEL_UNIVERSAL_v002.md"]
constraints: ["routes_yaml_runtime_primary", "no_full_archive_startup", "preserve_truth_hierarchy", "maintain_write_boundaries", "verifier_independent", "five_memory_layers"]
validation: ["validate-config", "route behavior tests", "adversarial prompts", "file-map freshness"]
---

Keep Kernel dispatch-capable but compact: enough to know goal, vocabulary, anchors, route, exact reads, boundaries, gates and reporting; never reduce it to a navigation-only file and never turn it into a full project encyclopedia.
