---
rule_id: frontend_public_ui
paths: ["android/app/src/main/java/**", "android/app/src/main/res/**", "BROTHERHOOD_UI_DEMO.html", "tools/visual_checks/**"]
routes: ["product_discovery_ux", "android_ui_feature"]
required_read: ["docs/CANON/BROTHERHOOD_PRODUCT_CANON.md", "docs/CANON/BROTHERHOOD_DISCOVERY_UX_CANON.md"]
constraints: ["preserve_male_only_nonromantic_boundary", "preserve_private_latent_profile", "compatibility_and_quality_fit_separate", "preserve_existing_routes", "reference_structure_not_data"]
validation: ["targeted architecture tests", "standalone HTML syntax/browser smoke when available", "GitHub Android CI after runtime change"]
---

Owner Q45 supersedes the authenticated Home root. Root navigation is fixed as `Профиль → Люди → Чаты → Группы → Развитие`; Development is a Diia-style catalog whose primary standalone apps are Tests, Numerology and Zodiac. Search Requests live under People. Bottom navigation remains persistent on authenticated routed pages. Dating-like swipes/cards belong to recommended candidate discovery, not the entire application shell.
