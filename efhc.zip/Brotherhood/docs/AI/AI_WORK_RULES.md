# AI work rules — Brotherhood

1. Продолжать от current HEAD; не начинать проект заново без доказанной необходимости.
2. Один numbered cycle — крупный продуктовый результат, а не импорт, документ, архив, CI-run или единичный дефект.
3. Технические hotfixes включаются в текущий крупный цикл либо записываются как maintenance note.
4. Использовать уровни доказательства: `SOURCE_ONLY → LOCAL_PASS → APK_VISIBLE → LIVE_E2E → PRODUCTION_QUALIFIED`.
5. Запрещено писать «реализовано/готово» без указания уровня и evidence.
6. Отчёт или README не доказывает runtime. Проверять исходники, tests и соответствующий gate.
7. APK/GitHub build выполняется только когда соответствующий roadmap cycle изменяет Android/runtime либо владелец прямо требует сборку; документационно-научные циклы сами по себе APK не требуют.
8. Исключение для внепланового APK: без compile evidence невозможно безопасно продолжить либо пользователь прямо требует сборку.
9. Universal workflow заморожен; в следующих циклах меняется только `Brotherhood.zip`, если новый лог не докажет дефект workflow.
10. Green build не доказывает backend/PostgreSQL/credentials/store reputation/production readiness.
11. AVG/Play Protect warning не исправляется workflow; обходы защиты запрещены.
12. Preserve canons: male-only non-romantic Brotherhood 18+, `global_id`, separate Trust/Compatibility/Completeness/Quality Fit, independent selectable Compatibility metrics with simple selected-score mean, hidden visual assessment, positive public projection; legacy Vedic 5% cross-metric Overall is superseded target canon and remains only a documented runtime migration gap until explicit implementation.
13. Никогда не раскрывать raw latent coordinates, calibration traces, private warnings или moral labels.
14. После крупного цикла обновлять roadmap/status, decision log, work notes, handoff, manifest/file maps.
15. Unknown facts marked `UNKNOWN`/`NEEDS_REVIEW`; ничего не выдумывать.

16. Все вопросы владельцу, задаваемые для проектирования/создания приложения, и все ответы владельца обязательно дописывать в `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md`. Не заменять дословный owner answer своей интерпретацией; предложения ассистента маркировать отдельно и не повышать до CANON без подтверждения.
