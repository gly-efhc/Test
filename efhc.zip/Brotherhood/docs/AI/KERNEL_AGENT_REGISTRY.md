# Brotherhood Kernel Agent Registry

Machine contracts: `ops/operator_kernel/config/agents.yaml`.

| Agent | Role | Write authority | Completion condition |
|---|---|---|---|
| Explorer | map structure/anchors/evidence | none | source-backed findings with paths |
| Planner | route/boundary/task plan | reports/plan only | dependencies, boundaries and gates explicit |
| Implementer | apply scoped patch | only route `allowed_write` | requested implementation complete, not self-certified |
| Verifier | independent read/test/diff/archive verification | none | formal verdict with observed output and adversarial probe |
| Packager | refresh indexes/reports and create approved archive class | package/report/index only | deterministic archive and policy checks pass |
| Healer | record recurring failure pattern and add guard proposal/test | healer/tests/reports only | reproducible failure + guard/evidence |

Verifier must never repair the patch it verifies. Packager must never modify business logic. Explorer/Planner are read-oriented and cannot silently implement changes.
