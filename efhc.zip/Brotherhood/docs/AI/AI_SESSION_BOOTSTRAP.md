# AI session bootstrap

Read in this order:

1. `START_HERE.md`
2. `KERNEL.md`
3. `docs/CYCLES/CYCLE_STATUS_REGISTRY.md`
4. active/next cycle file
5. `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`
6. `docs/HANDOFF/CURRENT_HANDOFF.md`
7. route resolver output
8. route-scoped CANON/SSOT/NORM/source files

Do not preload the whole archive. Do not continue a cycle whose status or exit gate is unknown.
