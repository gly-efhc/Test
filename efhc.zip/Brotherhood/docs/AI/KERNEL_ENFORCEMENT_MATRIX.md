# Brotherhood Kernel Enforcement Matrix

Purpose: connect important project rules to an executable or auditable enforcement mechanism. A text-only rule that cannot be mechanically checked is explicitly marked `ENFORCEMENT_GAP`.

| Rule | Enforcement type | Trigger | Route | Blocking | Evidence | Failure action |
|---|---|---|---|---|---|---|
| Read `START_HERE.md` and `KERNEL.md` before scoped work | INSTRUCTION + HOOK | session_start | all | yes | startup state | stop edit until startup route loaded |
| Resolve a primary/composite route before edit | HOOK | pre_edit | all | yes | resolver JSON | deny out-of-bound edit |
| Read exact route anchors and target file before editing | INSTRUCTION + HOOK | pre_read/pre_edit | all | yes | route required_read + edit ledger | stop edit |
| Route local edits and surface validation evidence | HOOK + TEST | pre_edit/pre_pack | all | **no — advisory** | route config + changed-file audit | report evidence; do not veto local product edits |
| Keep `routes.yaml` runtime-primary | TEST | pre_pack | kernel_archive | yes | operator behavior test | block package |
| Preserve male-only, non-romantic Brotherhood product boundary | INSTRUCTION + TEST | post_edit/pre_pack | product_discovery_ux | yes | product CANON + UI/demo regression | block package |
| Root IA follows owner Q45: Profile / People / Chats / Groups / Development; Development primary apps = Tests/Numerology/Zodiac | TEST | post_edit/pre_pack | product_discovery_ux/android_ui_feature | yes | Kotlin + HTML assertions after cycle-0027 implementation | advisory until cycle-0027 implementation, then regression |
| Dating-like cards/swipes only in recommended candidate discovery | INSTRUCTION + TEST | post_edit/pre_pack | product_discovery_ux | yes | source/demo assertions | block package |
| Candidate private personality/latent profile is never disclosed | TEST | post_edit/pre_pack | product_discovery_ux/psychological_visual_matching/backend_api | yes | API/UI privacy tests | block package |
| Compatibility and Quality Fit remain separate metrics | TEST | post_edit/pre_pack | product_discovery_ux/compatibility_model | yes | UI/model regression | block package |
| Tests remain indirect and public results remain positive/contextual | TEST | post_edit/pre_pack | psychological_visual_matching | yes | assessment regression | block package |
| Reference projects may contribute structure/UX patterns, not copied project data/assets | INSTRUCTION + review | pre_edit/pre_pack | historical_reference/product_discovery_ux | yes | changed-file/source-provenance review | block package on copied content |
| Preserve existing functions/routes/state/tests unless current task explicitly requires change | INSTRUCTION + TEST | post_edit/pre_pack | all implementation | yes | diff/function composition guard | investigate/regress |
| Frozen Android workflow remains byte-identical unless explicitly authorized and proven defective | TEST | pre_pack | ci_android/release_packaging | yes | SHA-256 | block package |
| Refresh `file_map` only after final edits | HOOK | pre_pack | kernel_archive/release_packaging | yes | generated_at + content digest | block package |
| Independent verifier for 3+ files, Kernel, Android runtime, backend, DB, auth, packaging | SKILL + TEST | verification/release | affected route | yes | verifier report | no PASS verdict |
| Development and Release archives remain separate | HOOK + TEST | pre_pack/post_pack | release_packaging | yes | allowlist/denylist + archive inspection | block release archive |
| External release/push/deploy/migration/DNS/message/on-chain actions are `user_only` | SKILL policy + INSTRUCTION | external action | release/live | yes | authorization record | refuse action |
| Operational memory contains only active unresolved work | TEST + HOOK | pre_compact/pre_pack | kernel_archive | yes | memory hygiene test | clean before package |

## Enforcement gaps

- Installed-device visual behavior remains an `ENFORCEMENT_GAP` locally: it requires exact APK/device evidence.
- Real provider auth/PostgreSQL/deployment behavior remains a live gate; local Kernel cannot truthfully substitute it.
- Subjective visual quality cannot be proven by static tests alone; HTML/browser/device review is required when UI changes.
