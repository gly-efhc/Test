# Brotherhood Operator Kernel route map

Runtime-primary source: `ops/operator_kernel/config/routes.yaml`. This document explains routes; it does not replace machine config.

- `product_discovery_ux` — male-only social/business club UX: calm four-action Home, people marketplace, recommended candidate cards/swipes, SearchIntent/desired qualities, direct chat, private latent-profile boundary.
- `psychological_visual_matching` — indirect 100×6 profiling + Quality Fit; hidden latent data stays internal; Q33/Q34 require versioned/improvable model governance while product outputs remain exact `0..100%` computations of the active approved algorithm version.
- `compatibility_model` — `BROTHERHOOD_COMPATIBILITY_CANON.md` + independent selectable metric engines (0..100 each) + optional unweighted mean; Quality Fit/Trust/Coverage remain separate.
- `compatibility_research` — `docs/research/compatibility/INDEX.md` + active `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.*` + `docs/CANON/BROTHERHOOD_SOURCE_AUTHORITY_CANON.md` → scientific evidence/source→claim plus typed source governance for SCIENTIFIC/UX_VISUAL/PRODUCT_DONOR/TECHNICAL/LEGAL/DATA; runtime implementation is writable under the current owner task; scientific/source authority must remain traceable; active roadmap is 0024–0073.
- `numerology_self_analysis` — date-derived/cultural self-analysis only.
- `android_ui_feature` — Compose/ViewModel/UI feature work.
- `backend_api` — FastAPI/server runtime and API contracts.
- `database` — PostgreSQL/schema/migrations.
- `auth_security` — provider identities, sessions, `global_id`, security boundaries.
- `i18n_localization` — runtime languages/catalogs.
- `ci_android` — GitHub Android build/signature/metadata/artifact chain.
- `release_packaging` — deterministic DEVELOPMENT/RELEASE archive creation/validation only.
- `kernel_archive` — START_HERE/Kernel/routes/hooks/agents/skills/memory/healer/governance.
- `cycle_planning` — numbered roadmap, task/memory/report state.
- `historical_reference` — read-only history/reference fallback.

## Composite routing
A request may have one primary implementation route, one or more secondary domain routes and validation routes. Packaging never grants permission to change business logic. Kernel/governance never grants permission to change product runtime unless a product/runtime route is also resolved.

Resolver output includes: `primary_route`, `secondary_routes`, `validation_routes`, `conflicts`, `task_type`, `risk_level`, aggregated `required_read`/write boundaries, validation/proof/reporting and `required_sequence`.
