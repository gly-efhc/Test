# AI decision log

| ID | Date | Decision | Reason | Consequence |
|---|---|---|---|---|
| D-0001 | 2026-08-01 | Establish cycles 0001–0100 starting from current governance restoration rather than inventing historical cycle mappings. | Earlier releases did not use a reliable canonical cycle number. | No false reconstruction of past work; future sequence is stable. |
| D-0002 | 2026-08-01 | Keep app metadata at v0.5.20/versionCode 25 for cycle 0001. | Documentation-only correction; no runtime change. | Archive hash changes, APK metadata does not. |
| D-0003 | 2026-08-01 | Assign TextAlign source correction to cycle 0002. | Proven by GitHub run 83283873357. | Frozen universal workflow remains unchanged. |
| D-0004 | 2026-08-01 | Treat `docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md` as canonical roadmap and `CYCLE_STATUS_REGISTRY.md` as operational status. | Separates stable numbering from fast-changing state. | Kernel startup must read both. |
| D-0005 | 2026-08-01 | Treat 0001–0100 as reserved capacity, not mandatory work. | User prohibited cycles for cycles. | Only evidence-based ACTIVE/NEXT cycles count as remaining work. |
| D-0006 | 2026-08-01 | Keep universal workflow byte-identical in cycle 0002. | Failure is a proven Kotlin import defect. | Future run replaces only Brotherhood.zip. |


## 2026-08-01 — compact roadmap and milestone-build policy
Decision: only cycles 0001–0010 are assigned. 0011–0100 are unused reserve. Microfix cycles are superseded as planning units. Android APK is built only at declared checkpoints, not after every source/archive change.
Reason: user explicitly requires the full plan in cycles without artificial expansion and reports that discussed features were never visible in a real APK.
| D-0007 | 2026-08-08 | Treat APK Source Map v002 as research-only donor evidence, never as current Brotherhood SSOT. | Its embedded `project_ssot` describes an older NON_CANONICAL_DEBUG APK. | Current truth remains START_HERE/KERNEL/CANON/SSOT/source; no foreign architecture is transplanted. |
| D-0008 | 2026-08-08 | Bump source milestone to `v0.5.22 / versionCode 27`. | Cycle 0002 changes user-visible runtime UX/i18n behavior, not documentation only. | GitHub workflow reads metadata dynamically; YAML remains unchanged. |
| D-0009 | 2026-08-08 | Keep cycle 0002 ACTIVE after source milestone. | Exit gate still requires GitHub Kotlin/APK PASS and real-device screenshots. | Feature source contracts may be `LOCAL_PASS`, but none is promoted to `APK_VISIBLE`. |



## 2026-08-08 — cycle 0003 decisions
- `v0.5.23 / versionCode 28` bump is justified by runtime/API/database/Android auth changes.
- Google Client ID is public runtime configuration delivered by Brotherhood backend; workflow is not modified.
- Telegram OIDC uses HTTPS backend callback + device-bound one-time app ticket instead of assuming BotFather accepts a custom-scheme OIDC redirect.
- Verified-email identity linking is allowed only from server-verified evidence, serialized with transaction advisory locks; ambiguous ownership becomes explicit recovery conflict.
- Passkey production remains gated by real RP origin and Digital Asset Links.
| D-LOGO-PNG-20260808 | 2026-08-08 | Make the exact owner-supplied `brand/logo_brotherhood.png` the active brand SSOT; only mechanical resizing/Android derivatives are allowed. | SVG reproduction was rejected; owner explicitly approved PNG and designated this image as the future reference. | All active runtime/logo routes point to the PNG canon; old BR SVG remains historical only. |

| D-INSTALL-LOGO-20260808 | 2026-08-08 | Do not attribute the Android install failure to logo resources without Package Installer/adb evidence; treat missing permanent Development signing as the strongest confirmed update-risk from supplied CI, while correcting screenshot-proven logo layout independently. | Manifest/package identity are unchanged; prior CI explicitly reports NON_CANONICAL_DEBUG signing. | No workflow change. v0.5.25 adjusts only runtime logo sizing/resources and keeps the master artwork unchanged. |

| D-INSTALL-PNG-V026-20260808 | 2026-08-08 | Treat signing continuity as explicitly excluded by the owner for this incident; use v0.5.19 as KNOWN-GOOD and isolate the first major packaging delta at v0.5.22→v0.5.23. Stabilize Credential Manager on 1.6.0 and remove `autoVerify` from the custom-scheme callback without deleting auth. Correct PNG sizing separately using the old total UI footprints rather than the SVG inner-glyph dimensions. | Direct archive diff and owner screenshot. | v0.5.26/versionCode 31 is an installation-regression diagnostic + PNG-layout runtime patch. Device installation and APK visual acceptance remain external evidence gates. |

### Correction to D-INSTALL-LOGO-20260808
The earlier decision treated NON_CANONICAL_DEBUG signing as the strongest install-risk. The project owner explicitly states that installation/signing continuity is not the issue and orders that warning to be ignored. That hypothesis is therefore retired for this incident. Current investigation is based on exact version diff from known-good v0.5.19.

| D-LOGO-SQUARE-ONLY-20260809 | 2026-08-09 | Brotherhood logo is strictly square. Remove all app-supplied round/adaptive/themed logo variants; retain only square PNG launcher resources and square in-app slots. Do not show the logo on Android 12+ system splash because the platform masks splash icons into a circle. | Direct owner instruction + Android platform splash/adaptive-icon behavior. | Auth/TopAppBar geometry is preserved; launcher package resources become square-only; exact APK + installed-device acceptance required before APK_VISIBLE. |

| D-0004-COMPAT-20260809 | 2026-08-09 | Complete cycle 0004 as documentation/research revision `v0.5.33-docs` while Android remains `v0.5.31/code36`; modular independent Compatibility metrics + simple selected-score mean replace fixed cross-metric weights as target canon. | Owner Q28 + current archive audit. | Runtime legacy weighted aggregate remains explicit future migration gap; protected test mechanics unchanged. |

| D-0005-EVIDENCE-20260810 | 2026-08-10 | Treat source evidence class, claim/model status, review depth, applicability and rights/license status as separate governance axes; no external effect size becomes a Brotherhood scoring coefficient without a later versioned model/validation/owner approval gate. | Cycle 0005 web/source audit + existing evidence policy. | 60-source registry + 24-claim ledger; all current claim-ledger production-scoring permissions remain false; runtime unchanged. |
| D-CYCLE0009-PC-20260810 | 2026-08-10 | Define Psychological Compatibility v1 first as a role-specific dyadic research engine with explicit actor/partner dependence, construct×role relation hypotheses and a versioned 0..100 method-index interface; do not implement production coefficients before validation. | Cycle 0009 scientific review + owner roadmap. | Source registry 82 / claim ledger 36; original 60-source commercial-permission snapshot remains separate; protected runtime/scoring unchanged; next 0010 Friendship Compatibility Science. |


## Cycle 0016 decision — CC temporal boundary
Decision: `CC-R0` may use explicit/structured communication preferences frozen before exposure. Actual reply timing, reciprocity, disclosure, conflict and repair after contact do not retroactively become historical predictor features. Deep semantic analysis of private chats is out of scope and requires a separate owner-authorized consent/privacy cycle.


## 2026-08-10 — Cycle 0017 / Q36 unified scientific evidence corpus
Decision: treat the complete Scientific Source Registry as one research evidence corpus for Brotherhood's own construct/model/test/validation synthesis. The original 60-source commercial-permission snapshot versus post-Q30 sources remains a separate rights/provenance/content-use axis and does not block scientific synthesis. No source becomes a production coefficient automatically; production promotion still requires Brotherhood validation/review and owner release approval.

## 2026-08-11 — Cycle 0022 release-parity decisions
- Q37 exact owner product concept is the top-level active Brotherhood product statement.
- Investor simulation source-contract counts are generated from current OpenAPI/migrations/AppRoute sources; historical 60/70/39/14 counts are not active parity targets.
- Hospitality release parity must exist in both standalone HTML and Android DEBUG/offline simulator, while authenticated production repositories remain authoritative.
- Verified Hospitality stays are high-information real-world interaction events, not friendship labels or hidden Compatibility multipliers.
- Hospitality research joins use frozen exposure-time model/score/coverage/rank/policy provenance, 7/30/90/180/365 voluntary outcomes, privacy exclusions and no automatic production learning.
- Development and GitHub-CI RELEASE archives are separate consecutive artifacts; `Brotherhood.zip` is permitted only as a technical byte-identical CI alias of the release artifact.

## 2026-08-11 — Functional-reality correction: research != implemented product
- Owner reported that Tests, psychoanalysis and psychoreport remain functionally dead despite many research cycles.
- HEAD audit confirmed: protected 100×6 mechanics/scoring/storage exist; current visual bank is procedural source scaffolding; per-test result is largely generic; monthly retake policy is not enforced; `SelfAnalysisEngine` is a shallow positive projection; full dedicated psychological report is absent.
- Governance correction: research-complete cycles are no longer flattened into finished product status. Product evidence gates are tracked independently.
- Roadmap correction: 0023–0028 assigned to Product Recovery; prior Enneagram-and-later tail shifted intact to 0029–0041; reserve begins at 0042.
- No protected 100×6 mechanics were modified by this audit.

| D-CYCLE-SEQUENCE-20260817 | 2026-08-17 | Restore active execution to ascending parent cycle IDs after implemented 0035; next executable cycle is 0036. Keep 0101+ as reference/decomposition only and preserve completed 0111 as out-of-order historical evidence. | Direct owner instruction: ‘Сделай перестановку циклов по порядку.’ | Active routing can no longer jump 0035→0112; 0112+ are not NEXT unless explicitly reactivated. Historical 0111 evidence is not rewritten. |
