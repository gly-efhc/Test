# Canonical memory — active summary

- Brotherhood is a social platform for friendship, communities, mutual aid, projects, professional relationships, travel and trusted offline interaction under the active product CANON.
- `global_id` is canonical domain identity; provider IDs are authentication identities only.
- Own Profile describes the person and never shows self-Compatibility.
- Q28 Compatibility metrics are independent `PC/IC/VC/CC/LC/PT/EN/NU/AS`, each `0..100` when computable. Optional Overall is the unweighted arithmetic mean only of explicitly selected available metrics.
- Trust, Account Rating, Quality Fit, Hospitality Reputation and Compatibility remain separate.
- Active psychological assessment authority is `scientific-questionnaire-bank-v1.3`: 7 independent systems / 197 source-claim-traced items / ≥3 item signals per construct / server-authoritative deterministic scoring; 180 situational items use respondent-neutral behavioral A/B wording while 17 direct public-domain anchors remain separate, with scoring semantics unchanged.
- The former generated visual assessment branch is removed from active runtime and must not be restored as a hidden fallback.
- Distinct psychological systems expose their own pair compatibility `0..100` when common evidence exists; missing evidence is not fabricated as zero.
- Numerology is separate from psychology; independent `NU 0..100` remains a Q28 metric and fixed 5% weighting is superseded.
- Existing authorized scientific corpus is the release baseline. Future outcome data is post-release versioned recalibration evidence, not an initial launch gate.
- HTML-first visual gate: complete simulator → owner visual acceptance → accepted Compose mirror → CI/APK → LIVE E2E.
- Full simulator chain is `backend/domain + DB → routes/source contract → BackendSimulator → SimulationEngine → route responses → frontend`.
- Donor repositories/sources never override active Brotherhood CANON/SSOT/current owner instruction.
