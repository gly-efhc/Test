# Brotherhood shared project memory

- Cycles 0027–0030 are source/runtime/HTML implemented; owner visual acceptance remains pending. Next unimplemented cycle: `0031 — Zodiac standalone application vNext`.
- Root IA remains `Профиль → Люди → Чаты → Группы → Развитие`.
- Active Numerology: `numerology-reading-v3`, `numerology-knowledge-v1`, `vedic-numerology-runtime-v1`; NU is independent `0..100` with internal 40/35/15/10 only.
- Reading v3 exposes transparent arithmetic traces, rulers, all date positions 1–9, exact calendar dates for the existing four Pinnacle ages and a 97-record source-backed knowledge catalog. Name-derived numbers remain descriptive-only.
- Pair comparison snapshots freeze the date-derived inputs and relation/ruler details; no psychological/Trust/Rating/Quality Fit score is changed by NU.
- Current source inventory: 117 OpenAPI paths / 136 operations / 54 DB tables / 21 Android AppRoutes / 200 deterministic candidates; persistence schema15.
- Q48 reverse friendship discovery is source-implemented; Q49 Friendship Reflection Surveys are research-only design with runtime hardening in 0038.
- HTML-first acceptance remains: owner review → accepted visual mirror → Compose mirror → CI/APK → live E2E. Active HTML candidate: `v0_5_45`; VA pending.
