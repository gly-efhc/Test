# Historical memory index

Historical release/cycle evidence is stored in:

- `docs/RELEASE_REPORT_v0_5_*.md`
- `docs/PROJECT_CANON_v0_5_*.md`
- `reports/change_cycle_*.md`
- `reports/generated/INDEPENDENT_VERIFICATION_*.md`
- `reports/historical/**`

History is reference-only and never overrides current CANON, SSOT, cycle status or explicit user instruction.

Current source milestone supersedes version metadata in `docs/PROJECT_CANON_v0_5_21.md`; that file remains historical evidence. Active source milestone canon: `docs/PROJECT_CANON_v0_5_23.md`.



## v0.5.23
Current source milestone for cycle 0003. `v0.5.22` remains the cycle-0002 source milestone and is not rewritten as APK-visible history.

## v0.5.24

Owner-approved brand update: canonical `brand/logo_brotherhood.png` derived losslessly from the decoded pixels of the supplied 1536×1536 image; old BR SVG moved to historical-only storage. Android in-app, launcher, themed icon and splash references updated. Cycle 0003 remains LIVE_E2E PENDING.

## v0.5.25
Superseded maintenance attempt for installation diagnosis and PNG sizing. Its signer-focused diagnosis and 128dp/48dp/66dp sizing are not current.

## v0.5.27
Device-installable historical milestone (owner installed via SAI), but UX-rejected: Home overload, no obvious completed-test results entry, and broken in-app system Back were reported. Superseded by v0.5.28 UX recovery.

Historical implementation note: Known-good v0.5.19 comparison localized the first major packaging/auth delta to v0.5.23; dependency/manifest hardening is applied without deleting auth or changing the frozen workflow. Owner square-only brand correction removes app-supplied round/adaptive/themed logo variants while preserving Auth 96dp and TopAppBar 38dp square placement.


## v0.5.28
Current source milestone. Bounded UX recovery keeps existing capabilities while simplifying the welcome Home, adds a dedicated completed-test Results route and route history/System Back handling. The reduced first HTML preview was superseded in-place by the full offline UX workbench required by the owner: live phone preview, technical route/state controls, full current user-facing route coverage and synthetic demo identities. APK/device acceptance for v0.5.28 is pending.

## v0.5.29
Current source milestone. Owner-directed correction of the app shell and demo architecture: persistent bottom navigation across authenticated nested routes, dedicated Android DEBUG `DemoSimulationEngine`, semantic light-theme parity, and standalone BackendSimulator → SimulationEngine → frontend workbench. GitHub/device acceptance pending.
