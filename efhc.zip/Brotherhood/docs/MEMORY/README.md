# Brotherhood memory layers

- `CANONICAL_MEMORY.md` — stable non-negotiable truths.
- `PROJECT_SHARED_MEMORY.md` — current project-wide shared facts.
- `OPERATIONAL_PENDING.md` — active unresolved work only.
- `HISTORICAL_MEMORY_INDEX.md` — pointers to completed history.

The compatibility adapter `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` mirrors the operational layer for existing Kernel routes.
