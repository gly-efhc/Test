# Numerology knowledge integration — active vNext reference

## Source and permission basis
Source supplied by the user: `Numerology-main.zip`.

SHA-256: `668a114194c0baa3792bee2be0be845aad74a353c239083b07c7fb2007623c9b`

The user explicitly stated that permission has been obtained for all supplied archives. Brotherhood does not import the reference application identity or runtime wholesale. The numerology knowledge/data and deterministic calculation logic are independently represented in Brotherhood with source provenance.

## Source inventory

| Source group | Records | Brotherhood use |
|---|---:|---|
| SoulNumberData | 11 | optional descriptive name Soul Number |
| LifePathNumber | 11 | date-derived Life Path + sections |
| BirthChartData | 52 | date digit map + isolated/missing configurations |
| PyramidPeakData | 11 | four date-derived Pinnacle interpretations |
| OuterNumberData | 12 | optional descriptive name Expression Number |

Exact supplied snapshot: `shared/numerology/source_vietnamese_v1.json`.  
Machine provenance: `shared/numerology/provenance_v1.json`.  
Normalized cross-runtime knowledge: `shared/numerology/numerology_knowledge_v1.json`.  
Android packaged mirror: `android/app/src/main/assets/numerology/numerology_knowledge_v1.json`.

The shared normalized knowledge file and Android packaged mirror must remain byte-equivalent for this version.

## Localization contract
The active normalized knowledge includes the canonical 13 Brotherhood locales:

`sw, ru, en, uk, de, fr, es, it, tr, pl, da, hi, id`.

Structural key coverage does not mean scientific/psychometric validation: numerology is a traditional/cultural interpretive system, not a psychological measurement instrument. Editorial/native-language refinement may continue version-by-version while source provenance remains fixed.

## Standalone Numerology vNext contract
Numerology has no questionnaire. A numerology reading is produced deterministically from explicit inputs and stored as a versioned immutable/idempotent snapshot.

Active calculation contracts:
- `numerology-reading-v3` — immutable self-reading/profile with transparent calculation trace;
- `numerology-knowledge-v1` — interpretation knowledge;
- `vedic-numerology-runtime-v1` — pair compatibility.

Date-derived profile includes:
1. reference Life Path;
2. Brotherhood Vedic date Soul Number;
3. Brotherhood Vedic date Destiny Number;
4. Maturity Number;
5. ruler metadata for Soul/Destiny/Maturity from the existing Vedic mapping;
6. transparent arithmetic/reduction trace for calculated indicators;
7. complete birth-chart inventory for digits `1..9`, including missing positions;
8. matching repeated-digit records and supplied isolated/missing configurations;
9. four Pinnacle numbers with calculated peak ages and exact calendar birthdays corresponding to those ages.

Optional Latin-name Soul/Expression calculations are descriptive self-analysis only. Name changes do not alter date-derived `NU` compatibility.

## Compatibility invariant — Q28 authority
`NU` is an **independent optional top-level metric `0–100%`**. It has no fixed cross-metric percentage and no hidden `5%` contribution to Overall Compatibility.

When a user explicitly selects `NU` together with other available Q28 metrics, the selected Overall follows Q28: unweighted arithmetic mean of the selected available top-level metrics.

Inside the `NU` metric itself, the active traditional component breakdown is:
- Soul pair: 40%;
- Destiny pair: 35%;
- cross Soul↔Destiny relation: 15%;
- date composite: 10%.

These percentages are **internal NU calculation components only**. They are not Brotherhood cross-metric weights.

Missing/withheld birth-date inputs produce unavailable/insufficient NU rather than a fabricated zero.

## Persistence / product behavior
Cycle 0030 adds standalone server-side reading and comparison history. The same-cycle v3 expansion also productizes the existing normalized knowledge as a read-only catalog of exactly **97 records** (`11 + 11 + 12 + 52 + 11`) across the five source groups, without creating new scoring weights:
- `numerology_readings` — versioned personal reading snapshots;
- `numerology_pair_comparisons` — versioned pair comparison snapshots.

Product flow:

`Развитие → Нумерология → профиль → прозрачный расчёт → пики/календарные даты → полная карта даты 1–9 → справочник 97 записей → история → сравнение человека → NU 0–100% + relation/component breakdown`.

User-visible disclosure must identify Numerology as a traditional/cultural interpretive system and must not present it as psychological or psychometric evidence.
