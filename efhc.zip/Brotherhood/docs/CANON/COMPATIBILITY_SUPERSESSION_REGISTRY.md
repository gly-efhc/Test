# Compatibility Supersession Registry

Status: **ACTIVE CANON STATUS MAP — Cycle 0004**

This registry preserves historical documents while preventing stale fixed-weight or removed-test wording from being interpreted as current product canon. Local product implementation is not protected by owner-lock/ask-first mechanics.

## Current controlling anchors
- `docs/CANON/BROTHERHOOD_COMPATIBILITY_CANON.md`
- owner Q28 in `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md`
- `docs/research/compatibility/METRIC_ENGINE_CONTRACT.md`
- ADRs: modular engines + simple mean + Compatibility/QF/Trust separation.

## SUPERSEDED for target Compatibility architecture
The following historical/protected texts may still state `15 layers`, fixed weights, `Vedic 5%`, or “small weight”. Those statements are retained only as history/current-runtime evidence and **do not define the target architecture**:
- `docs/FRIENDSHIP_TEST_SYSTEM.md` — historical document. Its former 100×6 mechanics and fixed-weight Compatibility wording are both superseded for active product implementation.
- `docs/PROJECT_CANON_v0_5_19.md` through versioned `PROJECT_CANON_v0_5_23.md` fixed-weight preservation wording — historical version statements.
- `docs/ADR/ADR-0002_HIDDEN_VISUAL_PROFILE_AND_USER_AUTHORED_QUALITY_FIT.md` compatibility-weight preservation note — historical scope statement only.
- `docs/AUDIT/CHAT_AND_SOURCE_AUDIT_2026_08_01.md`, release reports and cycle-0002 notes — historical evidence of then-current source.
- current Android `HybridCompatibilityEngine.kt` and related localization strings — **CURRENT RUNTIME GAP**, not current target canon.

## Current retained principles
The removed 100×6 bank has no active authority. Privacy of non-public psychological internals and the separation of Quality Fit, Trust, reputation and Compatibility remain active product principles under their current CANON contracts.
