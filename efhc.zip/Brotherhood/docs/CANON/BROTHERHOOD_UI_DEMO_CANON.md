# Brotherhood UI Demo Canon

Status: **ACTIVE CANON**  
Owner directive: 2026-08-09.  
Effective source milestone: **v0.5.35 / versionCode 40** (cycle 0024 runtime-persistence/full-simulation source update).

## Mandatory delivery pair

Every Brotherhood UX/UI iteration must return both:

1. a new complete project archive `Brotherhood.zip`;
2. a complete standalone `BROTHERHOOD_UI_DEMO.html`.

The exact active HTML must also exist inside the archive at:

- `BROTHERHOOD_UI_DEMO.html`;
- `tools/visual_checks/BROTHERHOOD_UI_DEMO.html`;
- the current versioned mirror: `tools/visual_checks/BROTHERHOOD_UI_SIMULATOR_v0_5_45.html`.

These active copies must be byte-identical.

## Reference-source boundary

The owner-provided `FRONTEND_v066.html` is a **structural/workbench reference only**. Brotherhood may reuse the organizational idea of a live phone preview plus a separate technical workbench and explicit simulation controls. It must **not copy EFHC data, balances, Energy/VIP/Activ state, routes, product semantics, identities, business values, texts or runtime assumptions** from that file.

Diia Android is an architecture/UX reference only. It may inform stable screen infrastructure, explicit Back handling, separation of top/body/bottom containers and information hierarchy. Brotherhood must not mechanically copy Diia code or data.

## What “full demo” means

The demo is not a small mock-up, static page collection or independent design fantasy. It is the **full offline stateful UX mirror of the current Brotherhood user-facing application**. It must expose every current user-facing route family, the five main tabs, important nested states, and the actions needed to review the product before another APK cycle.

The demo must follow the owner-mandated round-trip boundary `backend/domain + database → routes/source contract → BackendSimulator → SimulationEngine → route response → frontend`. BackendSimulator mirrors route/data authority; SimulationEngine sits between backend facade and frontend and is the only stateful UI-facing execution boundary. The frontend may not fabricate alternate business answers.

The internal demo layers are:

1. **BackendSimulator** — canonical local demo data/API-like operations.
2. **SimulationEngine** — persistent runtime state, actions, ticks, online/offline state, event/signal propagation and local mutations.
3. **Frontend mirror** — renders engine snapshots and dispatches user actions; it must not own hidden page-local business state.

A collection of constants plus click handlers is not sufficient to claim “simulation engine”.


## Release-parity / quality-versioned assessment boundary

Owner correction 2026-08-11: the former generated `100×6` / `600-task` visual assessment bank is removed from the active product and is not a fallback. The active assessment authority is `SCIENTIFIC_QUESTIONNAIRE_BANK_V1.json`, version `scientific-questionnaire-bank-v1.3`: seven internal scientific questionnaire systems, 197 source/claim-traced items exposed through 12 user-facing standalone test apps, and at least three independent item signals for every construct inside every active system.

The release flow is `canonical source map → claim/construct contract → versioned questionnaire item → server-authoritative scoring → per-system result → Psychological Report → independent per-system compatibility 0–100%`. Direct public-domain items may be adapted where permission exists; Brotherhood-original situational items must retain source/claim provenance and may not be described as literal published items.

The visual simulator must expose the same active questionnaire bank and routes as backend/domain. It must not silently reintroduce `f001…f100`, `visual-latent-v2`, `scene-library-v4`, generated Canvas stimuli, or any 600-task fallback. Future visual/indirect instruments, if developed, are separate versioned instruments and do not replace the current scientific questionnaire baseline without an explicit product version change.

The current generated source-contract inventory is **108 OpenAPI paths / 127 HTTP operations, 52 migration-defined database tables and 21 Android AppRoutes**. `docs/NORM/INVESTOR_SIMULATION_SOURCE_CONTRACT.json` is generated from current source anchors. Silent reduction of an implemented route/table/AppRoute or active scientific questionnaire contract is a functional regression; historical counts are not release authority.


### Cycle 0024–0025 full-data simulation requirement
The active review simulator contains exactly 200 deterministic synthetic candidate personalities plus the current synthetic demo user. Synthetic candidates populate professional/social/goals/interests/values/lifestyle/personality/numerology/zodiac fields and the current assessment result baseline so pair routes can return real simulated contract values. This is review data, not production identity data. Dataset size does not authorize simplifying routes/tables/business semantics.


### Cycle 0029 associative/implicit review boundary
The active simulator additionally exposes `Развитие → Ассоциации и реакции` with three independent method apps: `WORD_ASSOCIATION_V1`, `ASSOCIATIVE_FREE_CHAIN_V1`, and `IMPLICIT_ASSOCIATION_RT_V1`. Raw response/latency/error traces remain private simulation/backend data; public result screens show only derived method features, quality/coverage disclosure and saved history. Reverse Friendship Pattern Discovery is an internal research surface and must not be presented as a user compatibility explanation or causal fact.

## Persistent application shell

For every authenticated user-facing route:

- the five-tab bottom navigation **Профиль / Люди / Чаты / Группы / Развитие** is root-shell infrastructure;
- it must not disappear on Settings, Tests, Results, Chat, candidate/community details, profile models or other nested screens;
- the active tab reflects the parent navigation domain of the current nested route;
- only the unauthenticated Auth route may hide the main bottom navigation;
- Back/history must return through route history rather than exiting or resetting the application unexpectedly.

The same shell rule applies to Android Compose: page-local screens must not independently own the main five-tab navigation.

## Theme parity

Dark, Light and System are first-class themes. Light mode must not be implemented as a superficial background inversion. Both APK and HTML must use semantic tokens for:

- background;
- surface / elevated surface / surface variant;
- primary/accent and on-accent text;
- primary/secondary text;
- outlines/dividers;
- positive/warning/error states;
- selected/unselected navigation states.

Before delivery, Light must be rendered and visually inspected on representative Profile, Development, Tests/Results and Chat states when a browser runtime is available.

## Standalone requirements

The active HTML must:

- work as one file without a web server;
- contain all CSS, JavaScript and images inline;
- have zero external network assets and zero runtime `fetch`/XHR dependencies;
- embed the approved square Brotherhood PNG directly;
- persist demo runtime state locally when browser storage is available;
- expose simulation controls for run/pause, online/offline, reset and deterministic state changes;
- emit an internal demo signal/event after meaningful engine mutations;
- expose all current `AppRoute` families and all five `MainTab` destinations;
- model candidate details, discovery filters, chats, group creation/community state, profile editing, settings, Development Hub, 12 standalone test apps over seven internal scientific systems / 197 active items, saved results/history, Numerology/Zodiac standalone v1 flows, Trust, version/update and auxiliary personality models;
- model Hospitality end-to-end: host settings, availability, eligibility, requests, accept/reject/cancel/completion, participant-only arrival details, bilateral verified stay, blind reviews, restrictions/reputation and the Research Platform historical-exposure/outcome bridge;
- clearly mark simulated operations as DEMO and never imply that they reach the production backend;
- use synthetic identities only; no owner title/private personal data or the phrase `Глава Федерации` may appear in active Brotherhood UI;
- keep completed results directly discoverable inside the standalone `Тесты` application under `Развитие`;
- replace the obsolete welcome Home with the owner-confirmed `Развитие` service catalog; its primary visible applications are `Тесты`, `Нумерология`, `Зодиак`, and each opens a full independent flow.

## Android simulation boundary

Production and simulation are separate:

- **Production:** real backend repositories/services remain the authority when a real session/backend is available.
- **DEBUG/offline:** `DemoSimulationEngine` is the explicit stateful simulation boundary over immutable fixture/catalog data.
- `DemoRepository` is a fixture/catalog source and by itself must not be described as a simulation engine.
- Simulation must never silently replace production backend semantics in a production-qualified build.

The default synthetic DEBUG demo account is `Марк Левченко`. Alternate synthetic HTML personas may exercise other states. None of these identities changes production account data.

## HTML-first visual acceptance gate — owner correction 2026-08-11

For any UI/UX redesign or visual implementation program, the standalone `BROTHERHOOD_UI_DEMO.html` is the owner-facing visual acceptance surface **before** requesting another GitHub APK build. Source/API/route parity, architecture tests and CI compilation are not substitutes for visual acceptance.

Required order for UI work:

1. implement the agreed visual/interaction change in the complete standalone HTML simulator;
2. owner visually reviews the HTML and explicitly accepts the current UI direction;
3. mirror the accepted UI into Android Compose without removing existing functionality;
4. run source/static/architecture checks;
5. only then prepare/request GitHub CI/APK qualification for that accepted UI milestone.

If owner visual acceptance is missing, the state is `VISUAL_ACCEPTANCE_PENDING`; APK/CI may be used only to diagnose an already-requested build or a compile blocker, not as evidence that the UI is complete.

## Required pre-delivery checks

Before delivery:

- HTML parser PASS;
- inline JavaScript syntax PASS;
- zero external runtime asset/network dependencies;
- embedded Brotherhood PNG decodes as a valid PNG;
- active HTML copies are byte-identical;
- standalone HTML returned to the owner is byte-identical to the copy in `Brotherhood.zip`;
- route coverage guard PASS;
- persistent bottom-navigation guard PASS for all authenticated routes;
- browser smoke covers Profile → People → Candidate → Chat → send message, Development → Tests → Result/History, Numerology/Zodiac, Settings, theme switching and persona switching;
- browser smoke confirms bottom navigation remains visible on nested authenticated routes;
- dark and light representative browser renders are visually inspected when browser runtime is available;
- Android architecture guard confirms `DemoSimulationEngine`, root persistent navigation shell and semantic light theme;
- `Глава Федерации` is absent from active HTML and active Android demo-profile/UI data;
- frozen GitHub workflow hash is unchanged unless the owner explicitly authorizes a workflow change.

## Evidence boundary

HTML browser smoke proves only the offline UX demo. Local Android source/architecture tests prove only source structure. GitHub Android build and installed-device screenshots remain required before `APK_VISIBLE` or Android runtime behavior is claimed as verified.


## Scientific Tests acceptance boundary — cycle 0028
The HTML must expose the cycle-0028 seven-system metric layer through the cycle-0027 product catalog of 12 route-backed test apps and Psychological Report v2. Current calibration is `research-calibration-v1` with evidence synthesis `scientific-baseline-synthesis-v1`, derived from the existing canonical scientific corpus. This is the active launch baseline. Even if Brotherhood-specific outcome evidence matures only after 5–7 years, those data are post-release recalibration evidence and are not a prerequisite for v1 launch; they cannot mutate production scoring automatically. Parser/API tests prove technical consistency only; owner visual acceptance remains a distinct gate.
