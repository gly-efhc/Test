# Brotherhood — Internal Scientific Calibration CANON

Status: **ACTIVE OWNER CANON**  
Effective: `2026-08-11 / cycle 0028`  
Authority: owner clarification in cycle 0028.  
Source SSOT: `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json` (225 canonical typed sources).

## 1. Non-deferrable calibration rule

Brotherhood MUST NOT postpone usable psychological calibration for years while waiting for an external longitudinal cohort. The production-capable baseline calibration is performed **inside the Brotherhood computational system now**, using the already collected scientific corpus, active construct architecture and versioned measurement/scoring contracts.

The active baseline is:

`source → claim/construct → measurement mapping → deterministic scoring → normalization/coverage → interpretation → independent pair compatibility → report`

Calibration version: `research-calibration-v1`.

Future real-world observations, pilots and longitudinal outcomes MAY improve later versions, but:
- even if meaningful Brotherhood outcome metrics mature only after 5–7 years, they are not a release prerequisite for v1;
- they MUST NOT silently or automatically mutate production coefficients;
- every later change requires an explicit version, provenance and regression comparison;
- current fixed input + fixed algorithm version MUST return the same numerical result.

## 1a. Launch baseline vs post-release recalibration

The project uses two separate evidence loops and MUST NOT collapse them:

1. **Launch scientific baseline** — the existing canonical research corpus is synthesized now into constructs, test systems, scoring/normalization, coverage, interpretation and compatibility-ready feature schemas. This is sufficient to run the declared v1 model.
2. **Post-release recalibration** — Brotherhood begins preserving versioned model/input/exposure/outcome snapshots from day one. Later real-world evidence may compare the frozen baseline with a challenger and support an explicit new version.

Research labels such as `HYPOTHESIS` or `REQUIRES_VALIDATION` remain valid descriptions of scientific evidence strength, but they do not automatically mean `PRODUCT_BLOCKED`. A product block exists only when a specific CANON/owner gate explicitly says so.

Machine synthesis registry: `docs/research/psychology/SCIENTIFIC_BASELINE_SYNTHESIS_V1.json`.

## 2. Scientific authority boundary

Scientific sources determine what constructs are admissible, how they should be interpreted, which measurement risks must be controlled, and what uncertainty/coverage must be disclosed. They do not automatically donate published effect sizes as hidden Brotherhood weights.

The internal calibration layer makes the Brotherhood computational decisions explicit and versioned. It is a product model grounded in the scientific corpus, not a claim that an external paper directly validated every Brotherhood visual stimulus.

## 3. Active psychological measurement baseline

The former generated `100×6 / 600-task` visual bank is **not active authority and is not a fallback**. The active conscious/situational measurement bank is `scientific-questionnaire-bank-v1.3`:

- 12 user-facing standalone questionnaire test apps;
- 7 internal scientific systems;
- 197 source/claim-traced items;
- minimum three independent item signals per construct/system;
- server-authoritative deterministic scoring.

The seven internal systems remain:
1. `traits_core` — Черты и саморегуляция.
2. `interpersonal_style` — Межличностный стиль.
3. `communication_conflict` — Коммуникация и конфликт.
4. `trust_support_boundaries` — Доверие, поддержка и границы.
5. `decision_work_style` — Решения, риск и рабочий стиль.
6. `social_group_role` — Социальная энергия и роль в группе.
7. `adaptability_uncertainty` — Адаптивность и неопределённость.

Cycle 0029 adds an independent non-self-report/processing lane rather than replacing questionnaire psychology:
- `WORD_ASSOCIATION_V1` — 24 cues;
- `ASSOCIATIVE_FREE_CHAIN_V1` — 8 seed chains × target length 5;
- `IMPLICIT_ASSOCIATION_RT_V1` — 48 trials / 32 critical.

These methods preserve method provenance. Their raw event traces are private, and their results are not silently collapsed into the questionnaire score.

## 4. Independent method/system compatibility

Each questionnaire psychological system may expose its own pair result `0–100%` when both people have common supported constructs. v1 questionnaire method:
- identify common supported constructs;
- per construct similarity = `100 - |A - B|`;
- system compatibility = unweighted arithmetic mean of common similarities;
- no common constructs → `INSUFFICIENT_DATA`, never fabricated `0%`.

Each cycle-0029 associative/implicit method likewise exposes a **separate method-specific** `0–100%` result over common derived features. Timing-quality/error-control features are measurement-quality signals and are not pair-compatibility dimensions.

No questionnaire-system or associative/implicit method score becomes a hidden permanent weight of Q28 Overall. Q28 remains independent `PC/IC/VC/CC/LC/PT/EN/NU/AS` with explicit selected-metric arithmetic mean.

## 5. Coverage, quality and uncertainty

A questionnaire result MUST expose completed items/coverage, supported constructs, model/calibration version and limitations. An associative/implicit result MUST expose method version, completion/quality disclosure and derived features without leaking raw private traces. Missing measurements are missing data, not personality evidence.

## 6. Report rule

`Psychological Profile` is structured current state. `Psychological Report` is a versioned human-readable synthesis. Questionnaire system sections are first-class. Associative/implicit methods may be included as clearly labeled independent method sections only when completed; they must not be presented as clinical diagnosis, mind-reading or universal unconscious truth.

## 7. Privacy and anti-gaming

Exact item→construct keys, raw association chains/events, critical timing traces, hidden action keys and raw scoring traces are private model internals. The user may see purpose, broad construct/method family, source provenance, quality disclosure and final interpretation, but not private keys that would enable deliberate optimization or expose sensitive raw material.

## 8. Epistemic boundary

Brotherhood psychology is a model-based, probabilistic interpretation, not clinical diagnosis and not an immutable statement about a person. This epistemic limitation does not make the computation numerically vague: for a fixed input snapshot and fixed version, the result is deterministic and exact for that model version.
