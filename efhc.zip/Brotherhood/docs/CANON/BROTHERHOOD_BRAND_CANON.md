# Brotherhood brand canon

Status: ACTIVE CANON
Effective source milestone: v0.5.30

## Canonical master

- Canonical filename: `brand/logo_brotherhood.png`.
- Source image: owner upload on 2026-08-08. The uploaded file was JPEG/JFIF by binary signature despite a `.png` transport filename; its decoded 1536×1536 RGB pixels were saved losslessly as the canonical PNG master.
- Canonical PNG SHA-256: `47657ba1a1f9dd99cb9b275ea485b8bfdf3a5ac19de33f5187934eaf3b573e19`.
- Byte-exact owner upload provenance: `brand/source_provenance/logo_brotherhood_owner_upload_2026-08-08.jpg`, SHA-256 `22272c9dfbd9710447857011f6e8a7ccad4a501b8941ab1a61ead24516a8eba8`.
- Raster size: `1536 × 1536`.
- Colour type: RGB, no alpha channel.
- The supplied pixels are the reference artwork for all future Brotherhood logo work.

## Non-negotiable rules

0. The Brotherhood logo is strictly square. Do not add circular, oval, pill, squircle or round-only containers/masks/assets for the logo itself.
1. Do not redraw, reinterpret, regenerate, vectorize or replace the canonical master unless the project owner explicitly supplies/approves a new master.
2. Runtime derivatives may only be resized with preserved 1:1 aspect ratio and high-quality resampling. Round/adaptive/themed logo variants are not permitted.
3. Never crop the hands, gold frame or outer silhouette in ordinary in-app use.
4. Never apply Material tint to the full-colour PNG.
5. The old BR shield/monogram SVG is historical only under `brand/history/` and is not an active source.
6. All active UI/runtime references must resolve to `logo_brotherhood` or an Android derivative generated from this PNG.

## Active derivatives

- `brand/logo_brotherhood_1024.png`
- `brand/logo_brotherhood_512.png`
- `brand/logo_brotherhood_256.png`
- `android/app/src/main/res/drawable-nodpi/logo_brotherhood.png`
- `android/app/src/main/res/drawable/ic_brotherhood_logo.xml` (compatibility alias to the PNG)
- `android/app/src/main/res/mipmap-mdpi/ic_launcher.png` (48×48)
- `android/app/src/main/res/mipmap-hdpi/ic_launcher.png` (72×72)
- `android/app/src/main/res/mipmap-xhdpi/ic_launcher.png` (96×96)
- `android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png` (144×144)
- `android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` (192×192)

## UI sizing canon

- Authentication logo slot: `96dp`, `ContentScale.Fit`, no additional clip mask.
- Main TopAppBar logo slot: `38dp`, `ContentScale.Fit`, no additional clip mask.
- Generic brand mark: square, `ContentScale.Fit`.
- Launcher resources supplied by Brotherhood are square-only PNG bitmaps: mdpi 48×48, hdpi 72×72, xhdpi 96×96, xxhdpi 144×144, xxxhdpi 192×192.
- `android:roundIcon` is forbidden for Brotherhood because the canonical logo is square. No `ic_launcher_round` resource is shipped.
- Brotherhood does not ship an adaptive-icon XML or themed monochrome icon for the canonical logo. A device launcher may still apply its own presentation treatment externally; that is OS/launcher behavior, not a Brotherhood round asset.
- Android 12+ system splash masks app icons to a circular safe region. To avoid presenting a cropped/rounded Brotherhood logo, the system splash intentionally uses no visible logo; the first Compose surface presents the canonical square logo.

## Visual verification

The maintained source-side visual check is:

`tools/visual_checks/logo_brotherhood_preview.html`

It contains the master, square launcher asset samples, authentication placement and the shared TopAppBar placement representing Home / People / Chats / Groups / Profile. Circular/squircle logo previews are forbidden.
