# Brotherhood Research Platform Canon

Status: **ACTIVE OWNER CANON — Q35 / Cycle 0014**

## 1. Product role
Brotherhood is simultaneously:
1. a male 18+ social/business network and people marketplace;
2. a **versioned research platform** for studying how declared preferences, independent Compatibility metrics, Quality Fit, Trust, exposure and interaction conditions relate to real voluntary outcomes.

Research capability is subordinate to user agency, privacy, product usefulness and CANON. It is not permission for hidden moral scoring or unrestricted behavioral surveillance.

## 2. Owner directive
The product shall be able to collect **structured voluntary feedback and longitudinal relationship/project statuses** so Brotherhood can compare the exact score produced by a historical algorithm version with later real-world outcomes and improve future algorithm versions.

Examples include explicit buttons/statuses for acquaintance, ongoing communication, friendship, activity partnership, project partnership, business partnership, mentor/mentee and worker/team relations, plus role-specific outcome feedback.

## 3. Exact-score + research semantics
At time `t0`, Brotherhood stores the exact result shown by the then-active model together with:
`metric_version + role_context + input_snapshot_hash + recommendation_policy_version + exposure context`.

A later relationship outcome never rewrites that historical score. Research may produce a candidate model `vNext`; after review/validation/owner-release approval, `vNext` can calculate a new exact `0..100%` score from its own inputs.

## 4. Mandatory causal chain
`pre-exposure inputs`
→ `versioned metric scores`
→ `recommendation eligibility/ranking`
→ `actual exposure/impression`
→ `user action`
→ `interaction opportunity`
→ `voluntary relationship/project status`
→ `longitudinal outcome`
→ `versioned research dataset`
→ `analysis`
→ `candidate model`
→ `locked validation/holdout`
→ `human/scientific review`
→ `owner/release approval`
→ `new production model version`.

Forbidden shortcut:
`outcome/click/status → automatic production weight mutation`.

## 5. Exposure is first-class data
The system must distinguish:
- candidate was eligible but never shown;
- shown below/above visible rank;
- impression actually occurred;
- profile was opened;
- action was taken.

Therefore:
- `no click ≠ dislike`;
- `no reply ≠ incompatibility`;
- `ended relationship ≠ proof that initial Compatibility was wrong`;
- `high message count ≠ successful relationship`.

The recommendation policy itself changes what data can be observed and must be versioned with the outcome dataset.

## 6. User feedback model
Primary research labels are structured, role-aware and reversible. Optional free text is secondary and **must not** enter NLP/scoring automatically without a separate consent + research protocol.

Multi-label relationship statuses are permitted: e.g. the same dyad can be both `friend` and `project_partner`.

Each participant reports his own state independently. `MUTUAL_CONFIRMED` is created only if both sides explicitly confirm a compatible dyadic status; one person's declaration is never silently attributed to the other.

## 7. Consent/privacy tiers
Research architecture distinguishes at least:
- operational events required to deliver the product;
- research-opt-in events;
- explicit outcome surveys;
- separately consented sensitive research fields.

Research-consent version and purpose must travel with research records. Withdrawal/deletion/export and purpose separation are design requirements for the implementation cycle.

Raw private message content is **not** a default research feature. Structural events such as message initiation/reply/reciprocal-contact may be studied where permitted without reading message semantics.

## 8. Outcome target hierarchy
Primary research must prefer durable role-relevant outcomes over short-term engagement proxies. Clicks/profile opens/messages are process signals, not the final definition of successful compatibility.

Outcome definitions must be preregistered/versioned before model comparison and must include `NOT_ENOUGH_INTERACTION_TO_JUDGE` so missing opportunity is not converted into failure.

## 9. Bias and feedback-loop control
Research datasets must preserve the historical recommendation/exposure policy. When algorithms influence exposure, observational interactions are not treated as random samples of all possible pairs. Evaluation design may use controlled exploration, propensity/counterfactual methods or other reviewed causal designs, but no experiment rate or debiasing coefficient is canon until explicitly specified and validated.

## 10. 13-language rule
All research-facing labels, statuses, survey instruments, consent/explanation text and outcome definitions are designed for exactly:
`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`.

Translated UI availability is distinct from semantic/native QA and cross-locale measurement equivalence.

## 11. No moral rating
Research outcomes may improve matching. They do not create a hidden universal moral score. A failed project, ended friendship or rejected recommendation is contextual evidence, not proof that either person is "bad".

## 12. Implementation boundary for Cycle 0014
Cycle 0014 defines research/product/data contracts only. It does **not** authorize backend/database migrations, hidden telemetry activation, protected test changes or automatic learning in production.


### Lifestyle / LC exposure snapshot extension
Cycle 0017 adds LC-specific provenance: historical LC model/version/score/coverage/hard-conflict state, A/B lifestyle snapshots, derived distance/timezone and calendar/season context at exposure. Later relocation, schedule/life-capacity changes, remote/offline opportunity, meeting/shared-activity events and voluntary lifestyle-fit outcomes are time-indexed research events, never retroactive edits to the predictor. Optional smoking/alcohol/worldview/family-context data are purpose-limited; non-disclosure is not negative evidence.

### Personality-Type / PTC exposure snapshot extension
Cycle 0018 adds PTC-specific historical provenance: freeze the five-axis A/B snapshots, axis/scoring version, prototype registry version, soft-membership transform, all 32 soft interpretation weights, private hard interpretation code, PTC model/version/score/coverage, role, policy/rank and actual exposure. Later reassessment, perceived similarity, relationship-driven convergence/divergence and outcomes are separate time-indexed research records and can never overwrite the predictor that existed at exposure. Candidate raw type/axes/membership remain private by default; no private-chat semantics are required.

### Hospitality verified-stay outcome extension — cycle 0021
Cycle 0021 activates an operational real-world interaction outcome without redefining friendship or Compatibility. `completed` is calendar lifecycle only. A versioned `verified_interactions(interaction_type=hospitality_stay)` record may be created exactly once only after both participants independently confirm `stay_occurred`; `no_show` or `dispute` blocks automatic verification and routes negative allegations through Trust evidence/moderation/appeal processes.

A verified Hospitality stay is a first-class observable interaction event that can later be joined, under purpose/consent rules, to the historical recommendation/exposure snapshot and voluntary relationship-status/7-30-90-180-365 follow-up. It is not itself a friendship label, not a hidden Compatibility multiplier and not permission for automatic production learning.

Research/analytics exports must exclude exact address, exact coordinates, arrival contact, private review feedback and E2EE plaintext. Privacy-safe structured event metadata, coarse city/country context and pseudonymized request/verified-interaction IDs may be used only under the applicable operational/research purpose contract.

### Hospitality integrated longitudinal bridge — cycle 0022
Cycle 0022 closes release-parity design for the join `historical recommendation exposure -> Hospitality process -> bilaterally verified hospitality_stay -> voluntary 7/30/90/180/365 outcomes`. The authoritative detailed contracts are `docs/research/outcomes/HOSPITALITY_LONGITUDINAL_OUTCOME_CONTRACT.md` and `HOSPITALITY_RESEARCH_EVENT_EXTENSION.json`. Exact address/coordinates/arrival contact/private feedback/E2EE plaintext remain outside default research datasets. Request rejection, cancellation, expiration, no survey response and unconfirmed no-show allegations are not incompatibility labels. `verified hospitality_stay != friendship`; production scoring never auto-learns from Hospitality outcomes.


### Reverse friendship pattern discovery — Owner Q48 / cycle 0029
Brotherhood research asks not only whether a historical score predicted a later outcome, but also which **pre-friendship** characteristics were descriptively enriched among pairs that later became mutually confirmed friends.

The canonical comparison is `CONFIRMED_FRIENDSHIP` versus `NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE`, not friendship versus every other possible pair. Historical predictor features, method scores, input fingerprint and exposure policy are frozen at/before relationship formation. Similarity and difference/complementarity features are analyzed separately. Post-friendship convergence/socialization is a later trajectory and must not be used as if it were an original predictor. Reverse-pattern output is hypothesis/evidence only; it never mutates production scoring automatically.

Detailed contract: `docs/research/outcomes/REVERSE_FRIENDSHIP_PATTERN_DISCOVERY_V1.md`.


### Friendship Reflection Surveys — Owner Q49 / cycle 0030 design
Brotherhood may selectively invite both sides of an eligible dyad after verified real-world interaction, mutual friendship confirmation, sustained reciprocal contact or randomized/stratified research sampling to answer **independent** reflection surveys about why they believe the friendship formed or continued. Eligibility does not imply invitation; sampling policy, denominator, cooldown, consent/purpose, trigger version and non-response state must be preserved. One side must not see the other side's answers before the bilateral research window closes.

Q49 joins `frozen pre-friendship snapshot + actual exposure/interactions + friendship outcome + response A + response B`. Derived bilateral agreement/disagreement, reason overlap/asymmetry, similarity/complementarity explanations, turning-point agreement, time-to-friendship and longitudinal explanation stability are research evidence only. Retrospective, survivorship, selection, response, non-response and mutual-confirmation bias must be tracked. Q49 never auto-modifies Compatibility, Trust, Account Rating, Hospitality Reputation or Quality Fit.

Detailed contract: `docs/research/outcomes/FRIENDSHIP_REFLECTION_SURVEYS_V1.md`. Runtime hardening is scheduled for cycle 0068 under the owner single-module replan; cycle 0030 records the design only.
