# Brotherhood — Psychological Matching Canon

Status: ACTIVE CANON

## 1. Purpose
Brotherhood does not rank people from good to bad. It builds a private multidimensional psychological profile and compares people by independent, versioned systems. Results describe tendencies and fit; they are not clinical diagnosis or moral judgement.

## 2. Active scientific assessment authority
The active psychological assessment authority is:

- bank: `scientific-questionnaire-bank-v1.3`;
- scoring: `scientific-questionnaire-v1`;
- instrument: `text-situational-neutral-v1`;
- source SSOT: `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json`;
- systems: 7;
- active items: 197;
- minimum measurement depth: at least 3 independent item signals for every construct inside every system.

The seven systems are:
1. `traits_core` — traits and self-regulation;
2. `interpersonal_style` — interpersonal style;
3. `communication_conflict` — communication and conflict;
4. `trust_support_boundaries` — psychological trust, support and boundaries;
5. `decision_work_style` — decisions, risk and work style;
6. `social_group_role` — social energy and group role;
7. `adaptability_uncertainty` — adaptability and uncertainty.

The former generated visual assessment bank is not part of active runtime, scoring, compatibility, UI, Android assessment catalog or release fallback. Historical reports may describe it only as historical evidence.

## 3. Scientific materialization rule
Scientific sources are product-development inputs, not decorative citations. The required chain is:

`source/claim -> construct -> item specification -> scoring polarity -> construct score -> system result -> psychological report -> pair compatibility`.

Where a source provides reusable/public-domain items with sufficient permission, Brotherhood may adapt them with explicit provenance. Where the source supports a construct or method but not a literal reusable item, Brotherhood creates an original situational item and records that it is a Brotherhood adaptation rather than a copied scientific item.

No single paper directly becomes a hidden production weight. Production scoring is an explicit system-level synthesis of the authorized corpus.

## 4. Measurement design
Active v1 uses two item families:

- permitted direct questionnaire anchors where rights/provenance allow them;
- Brotherhood-original neutral situational bipolar items derived from scientifically supported constructs.

Every active construct within each system has at least three item signals. Redundancy items use a different neutral context and reverse A/B presentation where applicable to reduce simple position-response bias while preserving scoring orientation.

Items must avoid clinical diagnosis, moral labels and fake certainty. Technical source IDs, claim IDs, scoring polarity and internal dimensions are not shown during ordinary test execution.

## 5. Server-authoritative scoring
Answers use a four-point response contract. Each item is normalized to `0..100` according to its versioned polarity. A construct score is the arithmetic mean of its active items. A system score is the arithmetic mean of its available construct scores.

Fixed input + fixed bank/scoring version MUST produce the same deterministic result. Raw response traces are not part of the ordinary public result.

## 6. Psychological profile and report
A completed system must produce a substantive result, not merely “profile updated”. The private product may contain:

- system summary;
- construct dimensions;
- strengths/resources;
- potential growth areas;
- communication/conflict/work/friendship/group-context interpretation where supported;
- coverage and model version;
- scientific evidence bundle/version;
- limitations and incomplete-data disclosure.

`Psychological Profile` is the structured current state. `Psychological Report` is the human-readable synthesis and is stored as an immutable versioned snapshot with history.

## 7. Independent psychological compatibility
Each of the seven systems has its own independent pair compatibility `0..100`. The active v1 method compares common normalized construct scores using unweighted absolute similarity and reports coverage separately. Missing data is `INSUFFICIENT_DATA`, never an invented zero.

An optional aggregate psychological score may be a transparent arithmetic mean of selected available psychological systems. It must not silently mix Trust, Account Rating, Hospitality Reputation, Quality Fit, Numerology, Enneagram or Zodiac.

## 8. Q28 upper-level compatibility
Upper-level compatibility systems remain independent: `PC / IC / VC / CC / LC / PT / EN / NU / AS`. Users select systems explicitly. If more than one selected score is available, the optional overall convenience result is the simple arithmetic mean of selected available scores. No hidden cross-model weights are permitted.

Quality Fit, Trust, Account Rating and Hospitality Reputation remain separate product systems.

## 9. User controls the search target
The user explicitly selects role/context and desired qualities. The algorithm must not inject hidden “required qualities” merely from the role. Quality Fit compares a candidate's private profile with the user's explicit request and does not mutate Compatibility, Trust or Account Rating.

## 10. Hidden/public boundary
Private/internal:
- item-to-construct mapping;
- scoring direction;
- construct coordinates;
- response-quality diagnostics;
- scientific claim/source trace;
- model-development diagnostics.

Public/user-facing:
- understandable test result;
- positive/contextual interpretation;
- coverage/version disclosure;
- pair compatibility for the user and a concrete second person;
- separate Trust/Rating/Quality Fit.

Raw private coordinates must not be exposed in public people/profile DTOs.

## 11. Launch baseline and post-release recalibration
Brotherhood v1 launches from the existing authorized scientific corpus. The launch baseline is `scientific-corpus-baseline-v1`; a future multi-year external cohort is NOT a prerequisite to release.

From the first day of production, the platform may store consented versioned exposure/outcome provenance for later analysis. Mature 5–7 year outcomes may support a reviewed `v2/v3`, but they do not retroactively make v1 nonexistent and they never mutate production scoring automatically. Every scoring change requires a reviewed, explicit versioned release.

## 12. Rights and provenance
Brotherhood may use public-domain, licensed or owner-authorized scientific material within its recorded permission scope. Literal restricted test items or third-party images must not be copied without applicable rights. Original Brotherhood adaptations must be identified as adaptations and not misrepresented as literal published items.

## 13. Visual methods
Visual assessment is not a mandatory foundation of the psychological product. A future visual instrument may be developed only as a separately versioned scientific method with explicit stimulus provenance and its own scoring/validation contract. It cannot silently replace or contaminate the active questionnaire baseline.
