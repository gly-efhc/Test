# Brotherhood Psychology Epistemic & Algorithmic Score Canon

Status: **ACTIVE OWNER CANON — Q33 + Q34 / Cycle 0013**

## 1. Two levels that must never be confused
Brotherhood separates two different questions.

### A. Scientific/model level
Psychological constructs and models are not immutable ground truth about a person. Character and behavior are context-sensitive, measurements are incomplete, latent constructs are model-dependent, and better data or a better validated model may revise an earlier interpretation.

The owner's Q33 wording that psychology is "at the level of philosophy" is retained as an **internal project philosophy for research humility and algorithm design**, not as a requirement to weaken the product result and not as a formal academic reclassification of psychology.

### B. Product/computation level
**Brotherhood returns an exact numeric result of the approved algorithm version.**
For fixed `model_version + role_context + input_snapshot`, the algorithm's `score_0_100` is the exact computed output of that version. Example: `87.00%` means the active Brotherhood algorithm calculated exactly `87.00%` from the declared inputs under that version.

This is the active owner clarification Q34 and supersedes any earlier over-broad wording that called the displayed Brotherhood score itself "inexact".

## 2. Versioned exactness
The following are all simultaneously true:
- current score is exact **relative to the active algorithm, version and input snapshot**;
- the scientific model behind that algorithm can later improve;
- a new approved model version may produce a different exact score for the same pair;
- version history/provenance explains why two historical scores can differ without either calculation being arithmetically wrong.

Canonical chain:

`versioned inputs → approved model version → deterministic/reproducible computation → exact score_0_100 for that version`

then, when research justifies improvement:

`new evidence → reviewed candidate model → validation → owner/release approval → new model_version → new exact score_0_100`

## 3. Public product semantics
The user-facing product may directly show:
- `Психология — 87%`;
- role-specific psychological compatibility `0..100%`;
- current score without repetitive "not proven" warnings on every card/row.

Research-status vocabulary (`HYPOTHESIS`, `REQUIRES_VALIDATION`, candidate model diagnostics) is an internal research/governance mechanism unless a dedicated methodology/details screen intentionally exposes evidence status.

The primary UX must not turn epistemic caution into self-defeating disclaimers around every calculated result.

## 4. What exact score does and does not mean
An exact Brotherhood compatibility score is the exact output of the declared algorithm version. It is **not automatically a frequentist probability of future success** unless a separate outcome-probability model is explicitly calibrated, validated and labeled as such.

Therefore:
- `PC = 87.00%` is a valid exact Brotherhood compatibility result for that algorithm version;
- it need not mean `P(success)=0.87`;
- it does not mean the person has an immutable metaphysical essence measured to 87%;
- it is not a moral score.

## 5. DNA-test analogy recorded from owner
The owner's analogy is canonical for internal understanding: DNA interpretation systems can revise ethnicity/relationship interpretations as reference data and algorithms improve while still returning a definite result under each current method. Brotherhood follows the same versioned-product principle: **a definite current algorithmic result can coexist with future scientific/model improvement**.

The analogy is explanatory only; Brotherhood does not claim psychological Compatibility is biologically equivalent to genetic testing.

## 6. Research objective
Research should make future model versions better by improving:
- construct validity;
- reliability and calibration;
- role-specific predictive usefulness;
- 13-locale comparability;
- fairness;
- longitudinal outcome alignment;
- reproducibility.

These controls determine whether a candidate model may replace the current model. They do not require the public score to be presented as a vague range.

## 7. Coverage, data freshness and version
`coverage`, `data_freshness`, `model_version` and validation provenance remain separate metadata. They support reproducibility, auditing and future improvement. They do not silently alter the displayed score unless the active method contract explicitly defines such behavior.

## 8. Plasticity
A user's underlying profile and pair score may change because:
1. the person changes;
2. new valid observations are collected;
3. a retest updates the profile;
4. the active algorithm/model version changes.

Historical values remain provenance. A changed score is a normal result of versioned science, not proof that the earlier computation was defective.

## 9. Active implementation boundary
Owner Q44 supersedes the former protected-mechanics model. The generated 100×6/600-task visual branch is removed from active product authority. Scientific constructs, items, scoring and compatibility may be implemented and versioned directly from the authorized scientific corpus under the current owner task. Historical results remain provenance; new model versions must identify their version and evidence lineage.

## 10. Governing rule
**Internally: research with humility and improve the model. Externally: calculate and show the exact result of the current approved algorithm version.**
