# Brotherhood discovery and root UX canon

Status: ACTIVE CANON  
Owner decision source: `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md` (Q39, Q45, Q46).

## Product identity
Brotherhood is a male-only 18+ social/business club and people marketplace. It is not a romantic dating product and does not include searching for women. It supports finding male friends, collaborators, specialists/workers, business partners, project teammates, mentors, activity partners and mutual-aid contacts.

## Root navigation and Development
The previous authenticated Home root is superseded by owner Q45. Root navigation is exactly:
1. `Профиль`;
2. `Люди`;
3. `Чаты`;
4. `Группы`;
5. `Развитие`.

`Развитие` is a calm Diia-style service catalog rather than a dashboard. Its primary standalone applications are `Тесты`, `Нумерология` and `Зодиак`. Each module must expose its complete flow, state, details, history and results. Search Requests live inside the People/discovery contour rather than returning as a Home action.

## Search and candidate discovery
The base product language is a modern social/business network: early-VK-style information hierarchy + Telegram-like communication simplicity + Brotherhood's own contemporary visual system. Dating-like mechanics are permitted only in the recommended-candidate contour: large candidate cards, swipe/skip actions and visible matching percentages.

Candidate cards are resume-like, not romantic profiles. Public presentation may include photo/avatar, name, age where permitted, city/distance, online/verification, goals, interests, public skills/experience, Trust and matching metrics. Private latent personality type, hidden character classification, diagnostic dimensions and internal test coordinates are never disclosed.

## Matching outputs
Two outputs are separate:
- `Compatibility` — interpersonal/character compatibility calculated by Brotherhood algorithms.
- `Quality Fit` — how closely the candidate matches the searching user's explicit role/desired-quality request.

Neither is a moral score. A hard, uncompromising person can be weak for one friendship request and excellent for a director/business role.

## Search requests
The user explicitly configures whom he is looking for and which qualities matter. Search request is a first-class product entry point, not a hidden settings form. Filters and search intent may include all owner-approved dimensions, while role/quality choices must not expose the candidate's private latent profile.

## Communication
There is no mandatory mutual Match gate. The user may open a direct chat with a candidate immediately subject to privacy, block/report and moderation boundaries.

## Tests and multi-method psychology
Tests are optional but strategically important and live as a standalone application under `Развитие`. The active conscious/situational baseline is seven scientific questionnaire systems / 197 items. Results can be reread through history and feed the private Psychological Profile/Report.

Owner Q46 expands the program beyond self-report: Freud-derived free association, Jung word association and IAT/reaction-time are independent high-priority associative/implicit instruments; observed behavior/outcomes form a later evidence lane from launch-day provenance. Method-specific results remain separately inspectable and are never silently averaged into one hidden score.

## Reference boundary
Early VK, Telegram, Diia and dating products are UX/architecture references only. Do not copy their user/business data, proprietary assets or product-specific content into Brotherhood.

## Cycle 0033 Quality Fit v2 UI boundary

Quality Fit is shown only relative to an explicit active SearchIntent and is directional `searcher → candidate`. The screen exposes requirement-level status, missing data and hard/preference semantics without revealing private latent coordinates. Search role labels never inject hidden required traits. Quality Fit remains visibly separate from Compatibility and Trust.
