# Brotherhood Source Authority CANON

Status: **ACTIVE**  
Activated: `2026-08-11 / cycle 0024`

## 1. One registry, independent authority classes
Brotherhood uses one unified source map, but sources operate through independent authority classes. A source may be multi-class; every concrete use MUST declare the class under which that use is made. Authority never leaks from one class into another.

## 2. Classes and pipelines
- `SCIENTIFIC`: `source → claim → construct → measurement → scoring contract → validation → runtime`. Defines evidence/construct/measurement/psychometric/validation inputs; cannot define screen design.
- `UX_VISUAL`: `source → UX pattern → IA/component → HTML → owner visual acceptance → Android mirror`. Defines interaction/IA/screen patterns; cannot define psychology/scoring/scientific conclusions.
- `PRODUCT_DONOR`: `source → product pattern → Brotherhood feature contract → routes/state → simulator → UX → implementation`. Defines reusable product mechanics only after Brotherhood semantics are specified; cannot define compatibility science.
- `TECHNICAL`: `source → technical pattern → ADR/contract → security/performance review → implementation`. Defines architecture/state/API/persistence/security patterns; cannot silently redefine product or scientific semantics.
- `LEGAL`: `source → rights/policy claim → legal gate → allowed-use constraints`. Can permit/constrain/block use; does not become scientific or design authority.
- `DATA`: `source → dataset/item bank → rights/quality/privacy → research/measurement input`. Data never automatically creates a production coefficient.

## 3. Leakage guards
1. Scientific source cannot be visual authority.
2. UX/visual source cannot define constructs, psychometric validity, coefficients or scoring weights.
3. Product donor cannot define Psychology/Compatibility science.
4. Technical donor cannot silently change Brotherhood product semantics.
5. Legal authority constrains use but does not supply scientific validity.
6. Data needs rights/quality/privacy/validation gates.
7. Multi-class source use declares one or more explicit authority classes per decision.
8. Use outside registered target modules requires an explicit source-map patch/decision record.
9. Registration alone never mutates runtime.

## 4. Active source SSOT
Machine SSOT: `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.json`.
Human projection: `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.md`.
Scientific evidence is stored inside the same machine SSOT under typed source records (`source_classes` + `scientific_evidence`). The former 189-source parallel registry is superseded and removed; creating a second active source database is forbidden.
Historical maps `APK_SOURCE_MAP_v003/v002` remain preserved but are not current authority.
