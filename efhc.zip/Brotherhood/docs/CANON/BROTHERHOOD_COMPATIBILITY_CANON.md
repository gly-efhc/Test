# Brotherhood Compatibility Canon

Status: **ACTIVE OWNER CANON — Q28 / Cycle 0004**

## Immutable product rules until superseded by owner
1. Нет одной универсальной Compatibility metric.
2. `PC, IC, VC, CC, LC, PT, EN, NU, AS` — независимые engines; каждый выдаёт собственный `0..100`.
3. Пользователь сам выбирает метрики галочками.
4. Optional Overall — convenience-only arithmetic mean выбранных доступных scores.
5. Hidden cross-metric weights запрещены.
6. Quality Fit не является Compatibility metric и не входит в Overall автоматически.
7. Trust не является Compatibility metric и не входит в Overall.
8. Coverage/confidence/evidence class отображаются отдельно и не являются Compatibility score.
9. Роль/context — отдельная ось. Role-specific внутренняя математика metric engine разрешена после methodology/validation; это не cross-metric weighting.
10. Psychology не поглощает Numerology/Astrology/Enneagram.
11. Traditional/alternative engines разрешены как opt-in independent systems с честным evidence status.
12. Public explanation не раскрывает private latent profile кандидата.
13. Текущая visual→latent mapping имеет статус `HYPOTHESIS / REQUIRES_VALIDATION` и не объявляется validated, пока не прошла calibration/validation.
14. Longitudinal outcomes не мутируют production model автоматически.
15. Cycle 0004 не разрешает runtime/scoring/test-mechanics changes.

## Overall formula
Для множества выбранных доступных compatibility scores `S={s1..sn}`, `n>=1`: `Overall = (Σsi)/n`. Если доступных scores нет — Overall отсутствует/INSUFFICIENT_DATA; нули не подставляются.

## Supersession
Все исторические документы/строки, описывающие fixed inter-metric weights, Vedic 5% inside universal overall или 15-layer weighted base/personalized total, являются `SUPERSEDED FOR TARGET ARCHITECTURE`. Они сохраняются как history/runtime evidence до отдельной миграции.

16. Psychology uses versioned/improvable models under `BROTHERHOOD_PSYCHOLOGY_EPISTEMIC_CANON.md`; nevertheless `PC(role)` is exposed as the **exact `0..100%` computation of the active algorithm version/input snapshot**. A later approved version may change the exact score. The score is not automatically an outcome-success probability unless separately calibrated as one.

## Q35 — Research feedback and longitudinal outcomes
17. Brotherhood may collect structured voluntary feedback/status/outcome data to evaluate every independent Compatibility engine against real role-specific outcomes.
18. Every evaluable record preserves the historical `model_version + input_snapshot + role + recommendation_policy + exposure` context.
19. `unseen/no-click/no-reply/ended-contact` are not automatically negative Compatibility labels.
20. Outcome data flows only through versioned research analysis → validation → human/scientific review → owner/release approval → new production version. Automatic live coefficient mutation remains forbidden.
21. Product research labels never collapse Trust, Quality Fit or independent Compatibility engines into one hidden target.

## Q36 — Unified Scientific Evidence Corpus
22. All registered scientific sources form one Brotherhood evidence corpus for model synthesis: constructs, measurement architecture, pair features, causal guards, challenger hypotheses and validation design may synthesize across the complete registry.
23. The original 60-source owner-confirmed commercial-release permission snapshot versus post-Q30 sources is a separate rights/provenance/compliance axis; it is not a scientific-synthesis barrier.
24. Scientific synthesis does not automatically authorize copying/embedding source content and does not automatically convert any published statistic into a Brotherhood production coefficient.

## Cycle 0018 — Personality-Type boundary
25. `PT` remains independent from `PC` and `EN`. Brotherhood-32 hard code/title is an interpretation layer over versioned continuous axes, not the sole internal representation or a claim of natural categorical essence.
26. `PTC-R0` is a transparent research baseline. Similarity/complementarity/asymmetry/neutrality remain versioned, role-specific research questions; no universal same-type benefit is canonized.
27. Existing protected/runtime Brotherhood-32 classifier and compatibility formula remain unchanged until an explicitly authorized implementation cycle.

## Cycle 0032 EN runtime boundary

`EN` remains an independent Q28 metric `0..100%`. The current standalone implementation is `EN_BROTHERHOOD_CORE_PROFILE_V1` / `enneagram-existing-runtime-v1` and shares the existing Brotherhood Enneagram scorer with Q28 rather than defining a parallel formula.

The present formula is an experimental method index based on main type, circular type distance and the existing wing link rule. It is not a probability, psychological diagnosis, Trust signal or Quality Fit signal. Missing Enneagram data is insufficient data, never zero. The `ENNEA-001` mixed reliability/validity boundary must remain visible in methodology surfaces.
