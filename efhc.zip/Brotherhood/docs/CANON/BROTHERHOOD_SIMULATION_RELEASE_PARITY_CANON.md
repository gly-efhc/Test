# Brotherhood Simulation Release-Parity Canon

Status: **ACTIVE OWNER CANON — Q23/Q26**

## Canonical formula
`real product contracts → Backend Simulator → Simulation Engine → full Frontend mirror`.

## Required parity
Simulation mirrors real versioned entities/tables, routes/API contracts, states, lifecycle transitions, Compatibility/Quality Fit/Trust behavior, complete navigation, loading/error/empty/online/offline modes, persistent state and investor-ready scenarios.

Fixture data are synthetic instances of real contracts. Fixtures may not replace business logic with a simpler demo-only formula.

## Protected mechanics
Simulation must mirror the active scientific questionnaire bank and server scoring. The removed 100×6 visual mechanics must not be restored or simulated as active product behavior.

## Artifact separation
DEVELOPMENT retains docs/research/tests/reports/Kernel. RELEASE follows release policy and excludes internal research/AI material when policy says so. UX/runtime/simulation changes require current standalone HTML mirror; documentation-only cycle 0004 does not regenerate HTML.

## Evidence boundary
A local simulation PASS does not imply APK/device/LIVE_E2E/PRODUCTION_QUALIFIED. Each level requires its own evidence.
