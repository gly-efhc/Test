# Brotherhood Localization Canon

Status: **ACTIVE CANON — Q31 / 13-LOCALE**

1. Brotherhood is multilingual by architecture and is designed for exactly the current owner-approved 13-locale product scope: `sw` Kiswahili, `ru` Русский, `en` English, `uk` Українська, `de` Deutsch, `fr` Français, `es` Español, `it` Italiano, `tr` Türkçe, `pl` Polski, `da` Dansk, `hi` हिन्दी, `id` Bahasa Indonesia.
2. Canonical ordered tags: `sw,ru,en,uk,de,fr,es,it,tr,pl,da,hi,id`. Default locale remains `ru` unless the owner changes it separately.
3. Language selection is data-driven; UI must not require enum/`when(language)` proliferation.
4. Changing language changes all application-owned user-facing presentation: navigation, sections, assessment instructions/results, Quality Fit labels, self-analysis, numerology content and bundled reference/demo labels. User-authored content is not silently translated.
5. Runtime language activation is fail-closed on structural coverage: language record + complete message pack + required keys + numerology locale block.
6. **Structural translation coverage is not psychometric equivalence.** Assessment/construct comparability across locales requires the cycle-0008 adaptation, measurement-invariance and DIF gates.
7. Language choice never changes hidden psychological scoring, compatibility mathematics or latent semantics merely because the locale changed. Locale-specific model parameters are allowed only after versioned empirical evidence, review and owner/release approval.
8. Images are not presumed culture-free. Cultural familiarity, symbolism, reading-direction, device rendering, embedded text and option-attractiveness effects must be tested.
9. All current 13 languages are LTR. Direction remains metadata-driven so future RTL additions do not require architecture rewrite.
10. Built-in geography keeps stable canonical storage values and locale-dependent presentation labels.
11. No locale is described as psychometrically validated until its actual evidence gate passes. A `DRAFT_COMPLETE_REQUIRES_NATIVE_QA` translation may be structurally enabled for product localization while assessment equivalence remains `REQUIRES_VALIDATION`.
12. Q31 supersedes active RU/UK/EN-only planning statements. Historical versioned documents remain historical and are not rewritten as if they had always contained 13 locales.
