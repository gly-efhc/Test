# Brotherhood product canon

Status: ACTIVE CANON

## Owner product statement — Q37
The authoritative full product formulation is `docs/PRODUCT/BROTHERHOOD_FINAL_PRODUCT_CONCEPT.md`. It defines Brotherhood as one global social ecosystem for finding people, friendship, communication, partnership, projects, professional connections, travel, real-world interaction and mutual hospitality, with the product goal of turning useful online discovery into durable human connections. This statement does not merge Compatibility, Quality Fit, Account Rating, Trust or Hospitality Reputation.


- Brotherhood is an 18+ male-only social/business club for finding friends, collaborators, workers/specialists, project partners and business partners. Romantic dating and searching for women are outside product scope.
- Owner Q45 supersedes the former Home-root shell. Main authenticated navigation is exactly `Профиль | Люди | Чаты | Группы | Развитие` in that order. `Развитие` is a Diia-style catalog of standalone self-development applications; its primary modules are Tests, Numerology and Zodiac.
- `global_id` is the system owner ID; provider IDs are login identities only.
- Trust Score, Compatibility, Account Completeness and Quality Fit are four separate systems.

- Product structure is a modern social/business network inspired by the information hierarchy of early VK and the communication simplicity of Telegram; reference products are structural/UX references only and are never data donors.
- Dating-like discovery mechanics (large candidate cards, swipe actions, visible percentages) are allowed only inside the recommended-candidate/search contour. They are tools for male professional/social discovery, not romantic dating.
- Candidate presentation is resume-like: photo, identity/context, interests, skills/experience where available, public Trust/verification and two separate matching outputs. Private personality type/latent character profile is never disclosed.
- `Compatibility` means character/interpersonal compatibility. `Quality Fit` means how well a candidate matches the searching user's explicit desired qualities/role request. They must remain separate visible metrics.
- Direct messaging does not require mutual Match. A recommended candidate may be contacted immediately subject to privacy/moderation rules.
- Tests are optional but strategically important: seven scientific questionnaire systems produce meaningful results, a private psychological profile, a versioned psychological report and independent pair compatibility. Results remain discoverable inside Tests and may be retaken only under the product retake policy.
- Each compatibility model is independent and returns its own `0..100` score. The user explicitly selects which models to compare. If more than one model is selected, the optional overall convenience score is the simple arithmetic mean of the selected model scores. There are no hidden cross-model weights. The individual model scores are primary; the overall score is secondary UI convenience.
- Vedic friendship compatibility uses two birth dates only; name-derived numbers are descriptive self-analysis only.
- Vedic/numerology is a cultural/esoteric self-analysis layer, not psychology, not a test and not a Trust signal.
- The active psychological bank is `scientific-questionnaire-bank-v1.3`: **7 systems / 197 items**, with at least three item signals per construct in every system. Numerology is not part of this bank.
- Active items combine permitted direct scientific anchors with Brotherhood-original neutral situational items traced to scientific source/claim bundles. The scientific source supports the construct/method unless the exact item is explicitly identified as reusable source material.
- Detailed construct coordinates, item polarity, source/claim trace and response-quality diagnostics are internal algorithm data; the user receives understandable results and report sections.
- Public psychological interpretation is positive/contextual. Brotherhood has no universal “bad trait” taxonomy; the same trait can be useful for one role/person and unsuitable for another.
- The searching user explicitly chooses the role/context and desired qualities. The algorithm must not impose desired qualities from the role.
- Quality Fit compares a candidate's private latent profile to the user's explicit quality request and does not modify Compatibility, Trust or Account Completeness.
- One candidate may be an excellent fit for one user/role and a weak fit for another without being morally downgraded.
- Removed historical assessment models do not feed the active scientific questionnaire profile or compatibility.
- Active brand SSOT is `docs/CANON/BROTHERHOOD_BRAND_CANON.md`; canonical master is `brand/logo_brotherhood.png`. The master is not redrawn or regenerated without an explicit user task.

Detailed psychological canon: `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md`.
Causal graph and forbidden edges: `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`.

## v0.5.20 positive-result requirement

Every completed psychological block must produce immediate visible positive value: strengths/context/progress/next action. A counter-only completion is a product defect. Retakes refine the internal profile but do not add the same Account Completeness credit twice. Hidden coordinates and diagnostic evidence remain internal.

## Product-discovery Q&A SSOT

The append-only owner question/answer record is `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md`. Every future question asked to the owner for application/product/UX creation and every owner answer must be appended there. Owner answers outrank assistant synthesis. Assistant proposals must be explicitly marked and never silently promoted to canon.

## Compatibility research/documentation canon — 2026-08-09

The master compatibility research base is `docs/research/compatibility/INDEX.md`. Each compatibility metric is an independent versioned `0..100` engine. Scientific/empirical, typological and alternative families remain separate until the user explicitly selects checkboxes. The optional overall score is the unweighted arithmetic mean of selected available metric scores. Quality Fit, Trust and Data Coverage remain separate.

The application information architecture is documented in `docs/PRODUCT/VK_TELEGRAM_DIIA_HYBRID_ARCHITECTURE.md`: early-VK person/resume depth + Telegram direct communication + Diia service clarity + Brotherhood compatibility intelligence.

The scientific program productizes the existing authorized corpus now. `scientific-corpus-baseline-v1` is the release baseline; future longitudinal evidence can harden or revise later versions but is not a launch gate and never changes production scoring automatically.

## Psychology epistemic + exact-score boundary — Q33/Q34
Brotherhood distinguishes model uncertainty from computation accuracy. Psychological models are versioned and improvable; they are not immutable objective essence. At the same time, every active algorithm returns a **precise current `0..100%` score** for its declared version, role and input snapshot, and the UI may present that percentage directly without repetitive "not proven" disclaimers. A later approved algorithm version may legitimately produce another exact score. `score_0_100` is not automatically an outcome probability unless a separate calibrated probability model is explicitly defined. Active owner canon: `BROTHERHOOD_PSYCHOLOGY_EPISTEMIC_CANON.md`.

## Research-platform boundary — Q35
Brotherhood is also a versioned research platform. Structured voluntary recommendation feedback, side-specific/mutual relationship statuses and longitudinal role outcomes may be collected under purpose/consent governance to evaluate historical model versions and improve future versions. The recommendation/exposure policy is part of the data-generating process and must be recorded. No click/status/outcome may automatically mutate production scoring. Canonical details: `BROTHERHOOD_RESEARCH_PLATFORM_CANON.md`.

## Product implementation truth gate — Q39/Q40

Own Profile is a self/resume surface, not a pair-comparison surface. Pair Compatibility exists only when a concrete second person is present (`A ↔ B`). Tests and self-analysis describe the user; Compatibility compares two users.

Research completion, source implementation and product completion are independent states. No research/spec/protocol cycle may be reported as a finished application feature without the required implementation evidence. Major features use the gate chain:

`RESEARCH_COMPLETE → SOURCE_IMPLEMENTED → HTML_VISUALLY_ACCEPTED → ANDROID_MIRRORED → CI_APK_VERIFIED → LIVE_E2E_VERIFIED → PRODUCTION_QUALIFIED` where applicable.

For psychological product work, active authority is the seven-system scientific questionnaire bank plus meaningful result, history/retake policy, aggregate psychological analysis and full private psychological report. Active implementation contract: `docs/PRODUCT/TESTS_PSYCHOANALYSIS_PSYCHOREPORT_PRODUCT_GATE.md`.


## Q41 — assessment quality and module independence
Assessment quality is governed by scientific traceability and versioned product contracts, not by a fixed historical item count. Active v1 has seven independent psychological systems and 197 items; every construct has at least three signals. Future versions may add/revise items using the same source→construct→item→scoring discipline. Distinct psychological systems expose independent `0..100` pair compatibility. Numerology remains separate from psychology as independent `NU 0..100`.

## Q44 — active scientific questionnaire replacement

Direct owner instruction removed the former generated visual assessment branch from active product authority. It must not return as fallback or scoring source. Active authority is `SCIENTIFIC_QUESTIONNAIRE_BANK_V1.json` / `scientific-questionnaire-bank-v1.3`, seven systems and 197 items, server-authoritative scoring, scientific-corpus launch baseline, substantive reports and independent system compatibility. Cycle 0036 adds respondent-neutral behavioral wording for 180 situational items and keeps 17 direct public-domain anchors separate; it does not change scoring semantics or assert new psychometric validity. Historical cycle reports remain historical evidence only.

## Cycle 0032 — Development Full Demo + Enneagram standalone canon

`Развитие` is not considered demo-ready merely because its root tab is visible. The standalone Simulator must be able to present a complete populated demonstration of every currently productized Development module through the common route-backed state path.

Current active demo contract: `DEVELOPMENT_FULL_DEMO_V1`.

It includes immediately viewable persisted/simulated state for:
- Tests — all 12 current user apps;
- Associative & Implicit — all 3 current methods;
- Numerology — reading/history and NU pair comparison/history;
- Zodiac — reading/history and AS pair comparison/history;
- Enneagram — reading/history and EN pair comparison/history.

The root/default screen remains `Профиль`; full demo activation does not change Q45 root IA.

Enneagram is an optional standalone Development app. Active method `EN_BROTHERHOOD_CORE_PROFILE_V1` productizes the existing Brotherhood 18-item visual local profile and existing type/wing runtime. It must remain typological/experimental under the current evidence boundary and must not be silently presented as validated psychometrics or merged into PC, Trust, Account Rating, Hospitality Reputation or Quality Fit.

## Cycle 0033 Development/service UX stability canon

Standalone Development is a service surface, not a decorative gamified dashboard. Current product presentation should prioritize discoverability, stable navigation, readable hierarchy, explicit state/next action and uninterrupted reading. External Diia/Apple/GOV.UK materials are `PRODUCT_DONOR / UX_VISUAL` authority only and never scientific scoring authority.

A background Simulator/backend state update must not unexpectedly reset the user's current route, scroll position or active input. Same-route updates preserve reading context where possible; deliberate route changes may start the new screen at the top. Standalone HTML delivery requires real browser execution in addition to parser/JavaScript syntax checks.
