# Brotherhood v0.5.16 — visual stimulus / first-user calibration release report

Android target: `versionName 0.5.16`, `versionCode 21`, `applicationId org.federationofavatars.brotherhood`.

## Functional scope
- scoring model remains `visual-latent-v2`;
- stimulus provenance upgraded to `scene-library-v3`;
- 100 psychological/behavioural blocks × 6 indirect tasks = 600;
- actual bank coverage: 48 neutral scene archetypes, 16 visual paradigms, 4 deterministic presentation slots;
- 50 private latent coordinates and 112 user-selected contextual qualities retained;
- raw item-level calibration evidence separated from aggregate operational profile storage;
- raw server retention requires explicit `calibration-consent-v1` opt-in; withdrawal purges retained raw attempts;
- trace adds presentation slot, first-selection latency, answer changes and randomized task position;
- separate early-pilot and 30/90-day outcome calibration exports;
- outcome export accepts only pre-match candidate assessments to prevent temporal leakage;
- calibration remains review-only and cannot mutate production automatically.

## Preserved canon
- role does not inject desired qualities;
- no universal bad-trait scalar;
- raw latent data is not public;
- Quality Fit remains separate from Compatibility, Trust and Account Completeness;
- canonical 15 Compatibility layers remain 100%; Vedic numerology remains exactly 5%;
- numerology remains automatic and outside the 100/600 psychological bank;
- data-driven whole-app localization remains RU/UK/EN complete and future-extensible.

## Local verification
- backend + architecture: `89 passed`;
- i18n architecture: `14 passed` after catalog regeneration;
- pure Kotlin core smoke: `100 tests / 600 tasks / 50 traits / 112 qualities / 48 scenes / 16 paradigms / 4 slots` PASS;
- OpenAPI: `0.5.16`, 44 paths;
- JSON/XML/workflow/bash/static Android security: PASS;
- calibration runner `bash -n`: PASS;
- private signing material filename scan: PASS.

## Deferred gates
- real PostgreSQL migration/export execution: environment-deferred;
- full Android/Compose/Gradle/APK qualification: canonical GitHub CI;
- empirical validity: real opt-in Brotherhood data required; no validation claim is made in this release.

Local verdict: `LOCAL_PASS_LIVE_DEFERRED`.
