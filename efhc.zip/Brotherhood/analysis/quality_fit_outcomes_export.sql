-- Internal observational export for validating user-authored Quality Fit against later outcomes.
-- Quality Fit remains separate from canonical Compatibility, Trust and Account Completeness.
SELECT
    connection_id,
    searcher_global_id,
    search_role,
    desired_qualities,
    quality_fit_score,
    quality_fit_confidence,
    quality_model_version,
    matched_at,
    still_active_30d,
    still_active_90d,
    ended_reason,
    messages_exchanged_30d
FROM friendship_outcomes
WHERE quality_fit_score IS NOT NULL
  AND quality_model_version IS NOT NULL
ORDER BY matched_at, connection_id;
