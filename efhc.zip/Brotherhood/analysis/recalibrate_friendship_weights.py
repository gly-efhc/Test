#!/usr/bin/env python3
"""Offline calibration of Brotherhood friendship compatibility weights.

This tool NEVER edits production weights. It fits standardized logistic regression against
90-day friendship activity and emits an evidence report/candidate weights for human review.
Vedic numerology is held at the product-canonical 5% in candidate-weight normalization.
The retired v0.5.12 ID-bound Friendship Expectations shadow predictor is not fitted in visual-latent-v2.
User-authored expectation qualities are validated through the separate Quality Fit outcome pipeline.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

PRODUCTION_LAYERS = [
    "tests", "character", "values", "goals", "interests", "lifestyle",
    "communication", "conflict", "personality", "numerology", "enneagram",
    "zodiac", "geography", "business", "social",
]
DIAGNOSTIC_LAYERS: list[str] = []
ALL_FEATURES = PRODUCTION_LAYERS
CURRENT_WEIGHTS = {
    "tests": 18.0,
    "character": 10.0,
    "values": 10.0,
    "goals": 9.0,
    "interests": 8.0,
    "lifestyle": 7.0,
    "communication": 7.0,
    "conflict": 7.0,
    "personality": 7.0,
    "numerology": 5.0,
    "enneagram": 4.0,
    "zodiac": 3.0,
    "geography": 2.0,
    "business": 2.0,
    "social": 1.0,
}


def load_rows(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        frame = pd.read_csv(path)
        if "layer_scores" in frame.columns:
            expanded = frame["layer_scores"].fillna("{}").map(json.loads).apply(pd.Series)
            frame = pd.concat([frame.drop(columns=["layer_scores"]), expanded], axis=1)
        return frame
    if suffix in {".jsonl", ".ndjson"}:
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
        rows = payload if isinstance(payload, list) else payload.get("outcomes", [])
    normalized: list[dict[str, Any]] = []
    for row in rows:
        flat = dict(row)
        flat.update(row.get("layer_scores") or {})
        normalized.append(flat)
    return pd.DataFrame(normalized)


def candidate_weights(coefficients: dict[str, float]) -> dict[str, float]:
    """Normalize positive evidence across existing production layers, holding numerology at 5%."""
    positive = {name: max(0.0, coefficients.get(name, 0.0)) for name in PRODUCTION_LAYERS if name != "numerology"}
    total = sum(positive.values())
    if total <= 0:
        return CURRENT_WEIGHTS.copy()
    result = {name: round(value / total * 95.0, 2) for name, value in positive.items()}
    result["numerology"] = 5.0
    # Correct rounding drift without touching the fixed numerology weight.
    drift = round(100.0 - sum(result.values()), 2)
    if abs(drift) >= 0.01:
        strongest = max((name for name in result if name != "numerology"), key=result.get)
        result[strongest] = round(result[strongest] + drift, 2)
    return dict(sorted(result.items(), key=lambda item: PRODUCTION_LAYERS.index(item[0])))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="JSON/JSONL/CSV export of friendship_outcomes")
    parser.add_argument("--output", type=Path, default=Path("friendship_weight_report.json"))
    parser.add_argument("--min-samples", type=int, default=50)
    args = parser.parse_args()

    df = load_rows(args.input)
    required = set(ALL_FEATURES + ["still_active_90d"])
    missing = sorted(required - set(df.columns))
    if missing:
        raise SystemExit(f"Missing columns: {', '.join(missing)}")

    df = df[df["still_active_90d"].notna()].copy()
    if len(df) < args.min_samples:
        raise SystemExit(f"Need at least {args.min_samples} labeled 90-day outcomes; got {len(df)}")
    y = df["still_active_90d"].astype(int)
    class_counts = y.value_counts().to_dict()
    if len(class_counts) != 2 or min(class_counts.values()) < 5:
        raise SystemExit(f"Both outcome classes need at least 5 rows; counts={class_counts}")

    X = df[ALL_FEATURES].astype(float).clip(0, 100)
    pipeline = Pipeline([
        ("scale", StandardScaler()),
        ("model", LogisticRegression(max_iter=5000, class_weight="balanced", C=1.0)),
    ])
    pipeline.fit(X, y)
    coef = pipeline.named_steps["model"].coef_[0]
    coefficients = {name: float(value) for name, value in zip(ALL_FEATURES, coef)}

    folds = min(5, min(class_counts.values()))
    auc = None
    if folds >= 2:
        cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=42)
        probability = cross_val_predict(pipeline, X, y, cv=cv, method="predict_proba")[:, 1]
        auc = float(roc_auc_score(y, probability))

    report = {
        "schema_version": "1",
        "target": "still_active_90d",
        "samples": int(len(df)),
        "positive_outcomes": int(y.sum()),
        "negative_outcomes": int((1 - y).sum()),
        "cross_validated_roc_auc": round(auc, 4) if auc is not None else None,
        "standardized_logistic_coefficients": {k: round(v, 6) for k, v in coefficients.items()},
        "current_production_weights": CURRENT_WEIGHTS,
        "candidate_production_weights_for_review": candidate_weights(coefficients),
        "numerology_policy": "fixed at 5% by product canon",
        "automatic_production_update": False,
        "interpretation": (
            "Positive standardized coefficients are associated with 90-day activity in this sample. "
            "They are observational, may be confounded, and must be reviewed before any production reweighting."
        ),
    }
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
