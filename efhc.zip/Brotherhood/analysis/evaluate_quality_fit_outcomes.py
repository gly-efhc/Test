#!/usr/bin/env python3
"""Evaluate Quality Fit against later connection outcomes without modifying production logic.

This is observational validation, not a causal proof and never writes model parameters.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


def load(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == '.csv':
        return pd.read_csv(path)
    if path.suffix.lower() in {'.jsonl', '.ndjson'}:
        rows=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
    else:
        obj=json.loads(path.read_text(encoding='utf-8'))
        rows=obj if isinstance(obj,list) else obj.get('outcomes',[])
    return pd.DataFrame(rows)


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('input', type=Path)
    ap.add_argument('--output', type=Path, default=Path('quality_fit_outcome_report.json'))
    ap.add_argument('--min-samples', type=int, default=50)
    a=ap.parse_args()
    df=load(a.input)
    required={'quality_fit_score','quality_fit_confidence','quality_model_version','still_active_90d'}
    missing=sorted(required-set(df.columns))
    if missing: raise SystemExit('Missing columns: '+', '.join(missing))
    df=df[df.still_active_90d.notna() & df.quality_fit_score.notna()].copy()
    if len(df)<a.min_samples: raise SystemExit(f'Need at least {a.min_samples} labeled outcomes; got {len(df)}')
    y=df.still_active_90d.astype(int)
    counts=y.value_counts().to_dict()
    if len(counts)!=2 or min(counts.values())<5: raise SystemExit(f'Both classes need at least 5 rows; counts={counts}')
    X=df[['quality_fit_score']].astype(float).clip(0,100)
    pipe=Pipeline([('scale',StandardScaler()),('model',LogisticRegression(max_iter=5000,class_weight='balanced'))])
    pipe.fit(X,y)
    folds=min(5,min(counts.values()))
    auc=None
    if folds>=2:
        cv=StratifiedKFold(n_splits=folds,shuffle=True,random_state=42)
        prob=cross_val_predict(pipe,X,y,cv=cv,method='predict_proba')[:,1]
        auc=float(roc_auc_score(y,prob))
    grouped={}
    if 'search_role' in df.columns:
        for role,part in df.groupby(df.search_role.fillna('unknown')):
            grouped[str(role)]={'samples':int(len(part)),'active_90d_rate':round(float(part.still_active_90d.astype(int).mean()),4)}
    report={
        'schema_version':'1',
        'model_versions':sorted(str(x) for x in df.quality_model_version.dropna().unique()),
        'samples':int(len(df)),
        'positive_outcomes':int(y.sum()),
        'negative_outcomes':int((1-y).sum()),
        'quality_fit_standardized_coefficient':round(float(pipe.named_steps['model'].coef_[0][0]),6),
        'cross_validated_roc_auc':round(auc,4) if auc is not None else None,
        'role_summary':grouped,
        'automatic_production_update':False,
        'interpretation':'Observational association only. Review cohorts, calibration and confounding before any model change.'
    }
    a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
