-- Export only rows with a resolved 90-day outcome for offline model calibration.
SELECT
    connection_id,
    matched_at,
    still_active_90d,
    messages_exchanged_30d,
    layer_scores->>'tests' AS tests,
    layer_scores->>'character' AS character,
    layer_scores->>'values' AS values,
    layer_scores->>'goals' AS goals,
    layer_scores->>'interests' AS interests,
    layer_scores->>'lifestyle' AS lifestyle,
    layer_scores->>'communication' AS communication,
    layer_scores->>'conflict' AS conflict,
    layer_scores->>'personality' AS personality,
    layer_scores->>'numerology' AS numerology,
    layer_scores->>'enneagram' AS enneagram,
    layer_scores->>'zodiac' AS zodiac,
    layer_scores->>'geography' AS geography,
    layer_scores->>'business' AS business,
    layer_scores->>'social' AS social
FROM friendship_outcomes
WHERE still_active_90d IS NOT NULL
ORDER BY matched_at, connection_id;
