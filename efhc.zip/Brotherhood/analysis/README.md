# Friendship outcome calibration

`friendship_outcomes` stores a snapshot of compatibility layers at connection time and later 30/90-day outcomes. It is analytics input, not a public reputation table.

The calibration script fits an L2-regularized logistic regression on standardized 0–100 layer scores. It reports coefficients and a **candidate** production weighting for review. It never edits application weights automatically. The product-canonical Vedic numerology weight remains fixed at **5%**.

The old v0.5.12 ID-bound `friendship_expectations` shadow predictor is retired before `visual-latent-v2`; those fixed test IDs no longer represent the former direct-question constructs. Contact/directness/boundary expectations are now user-selectable qualities evaluated through the separate Quality Fit pipeline.

Minimum default dataset: 50 labeled 90-day outcomes, with both active and inactive outcomes represented. Treat 50–100 rows as directional only; stability should be reassessed as the dataset grows and across cohorts/time windows.
## Quality Fit outcome validation

`0004_quality_fit_outcome_context.sql` snapshots the initiating user's explicit role/quality request and the Quality Fit score at connection time. This makes the chain `user-authored request -> Quality Fit -> later 30/90-day outcome` measurable without merging Quality Fit into canonical Compatibility. `evaluate_quality_fit_outcomes.py` reports observational association only and never changes production parameters automatically.

