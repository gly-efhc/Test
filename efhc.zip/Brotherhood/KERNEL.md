# KERNEL — Brotherhood

## 1. Project identity and current HEAD
- Project: **Brotherhood**.
- Domain: male-only 18+ social/business club and people marketplace: friends, collaborators, specialists/workers, project partners, business partners, mentors, activity partners, communities, messaging, self-analysis and private matching.
- Romantic dating/searching for women: **OUT OF SCOPE**.
- Current source milestone: `v0.5.35 / versionCode 40`; cycle 0024 source implements persistent reports, server Q28 and full simulation. Fast-changing values remain authoritative in `PROJECT_MANIFEST.json`.
- Kernel status target for this setup: `ACTIVE_OPERATOR_KERNEL` after independent local verification; APK/device/live status remains separately evidenced.

## 2. Top project goal
Build a serious male social/business network that combines early-VK-like information hierarchy, Telegram-like communication simplicity, modern Brotherhood visual language, private psychometric matching and direct communication — without romantic dating and without disclosing private personality/latent character data.

## 3. Top Kernel goal
The Kernel is the active operational dispatch layer (`active dispatch`). It classifies the request using Brotherhood vocabulary, chooses primary/composite routes, points to exact canonical anchors/files, enforces write/risk boundaries and selects validation/proof/report gates without rereading the whole archive.

## 4. What Kernel is not
Not navigation-only; not a full archive copy; not a replacement for CANON/SSOT/NORM/ADR; not permission for broad refactors; not a historical log; not a secrets store; not a reason to read all files.

## 5. Active truth hierarchy
1. Current explicit owner instruction.
2. Confirmed owner CANON / append-only product Q&A answer.
3. This KERNEL dispatch contract.
4. `docs/CANON/**`.
5. `docs/SSOT/**`.
6. `docs/NORM/**` + ADR + route/path rules.
7. Healer guards.
8. Runtime source/configuration.
9. Tests and CI contracts.
10. Current reports/logs.
11. Historical/reference material.

Conflicts are never silently reconciled. If priority does not resolve a conflict, record `BLOCKED_NEEDS_USER_DECISION`.

## 6. Mandatory startup route
`START_HERE → KERNEL → active task/cycle + operational memory/handoff → instruction registry → keywords/anchors + route map → file_map.summary → resolve route → route capsule/rules → exact canonical anchors → exact target source → validation/proof plan → edit`.

Do not make full source tree, all CANON, all reports/logs, all screenshots or full `file_map.json` mandatory startup reads.

## 7. Project language and glossary
Operator language: Russian. Runtime UI canonical locale scope is exactly 13 languages: `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`. Structural locale availability, linguistic/native QA and psychometric equivalence are separate gates. Canonical terms: `Brotherhood`, `global_id`, `Trust Score`, `Compatibility`, `Quality Fit`, `Account Completeness`, `SearchIntent`, `Brotherhood-32`, `Enneagram`, `Vedic numerology`, `scientific-questionnaire-bank-v1.3`, `Associative/Implicit`, `Development Hub`, `NON_CANONICAL_DEBUG`, `DEVELOPMENT archive`, `RELEASE archive`.

Product terms:
- `Compatibility` = interpersonal/character compatibility.
- `Quality Fit` = fit to the searching user's explicit desired role/qualities.
- Private latent/personality profile = internal matching data; never a candidate public label.
- Dating-like mechanics = candidate-card/swipe UX only, not romantic dating.

## 8. Keywords and triggers
Full table: `docs/AI/PROJECT_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`.
Major groups: product discovery/UX; psychological visual matching/Quality Fit; compatibility science/research; independent compatibility metrics; Android/UI/demo; backend/API; database; auth/security/global_id; numerology/self-analysis; i18n; CI/APK/signing; release/archive; Kernel/governance; cycles; historical/reference.

## 9. Keyword → route → anchor
Runtime-primary definitions: `ops/operator_kernel/config/routes.yaml`.
Human map: `docs/AI/PROJECT_OPERATOR_KERNEL_ROUTE_MAP.md`.
Exact WHERE_FIXED registry: `docs/AI/PROJECT_CANONICAL_ANCHORS.md`.
Composite requests preserve every materially relevant domain plus validation routes.

## 10. Product-discovery and root-IA anchor
`docs/CANON/BROTHERHOOD_DISCOVERY_UX_CANON.md` + `docs/PRODUCT/BROTHERHOOD_DEVELOPMENT_HUB_CANON.md` + product Q&A.
Owner Q45 supersedes the former Home root. Authenticated root navigation is exactly `Профиль → Люди → Чаты → Группы → Развитие`. `Развитие` is a Diia-style catalog of standalone applications, with primary modules `Тесты`, `Нумерология`, `Зодиак`. Search Requests live under People. Dating-like cards/swipes live only in recommended candidate discovery. Direct chat requires no mutual Match. Candidate public UI may show Compatibility + Quality Fit separately but must not expose private psychological coordinates.

## 11. Psychological matching anchor
`docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md` + `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`.
Seven scientific questionnaire systems are the active assessment baseline. The former 100×6/600-task visual bank was explicitly removed by the owner. Public results are contextual; private construct coordinates remain non-public; Quality Fit is separate from Compatibility/Trust/Completeness.


## 11a. Psychology epistemic + algorithmic-score anchor
`docs/CANON/BROTHERHOOD_PSYCHOLOGY_EPISTEMIC_CANON.md` (Q33+Q34). Research models remain versioned/improvable and are not immutable person essence; **the product score itself is an exact computation of the active algorithm version and input snapshot** and is shown directly as `0..100%`. A later approved model version may change the exact score. Do not turn research-status language into repetitive user-facing "not proven" disclaimers. `PC(role)` is not automatically an outcome probability unless a separate probability model is explicitly calibrated.

## 11b. Multilingual psychometric anchor
Canonical locale set: `sw, ru, en, uk, de, fr, es, it, tr, pl, da, hi, id`. Translation/key coverage never implies measurement equivalence. Psychometric claims across locales require versioned adaptation evidence, native/linguistic review, calibration data, invariance/DIF analysis and intended-use validation. The active assessment baseline is `scientific-questionnaire-v1 / text-situational-neutral-v1`. The removed 100×6 visual bank must not be restored. Locale adaptation must preserve item meaning and scoring direction.


## 11c. Product functional-reality gate
Owner corrections Q39/Q40/Q41: research completion is not product implementation. For Tests/Psychoanalysis/Psychoreport and other major features, track `RESEARCH_COMPLETE → SOURCE_IMPLEMENTED → HTML_VISUALLY_ACCEPTED → ANDROID_MIRRORED → CI_APK_VERIFIED → LIVE_E2E_VERIFIED → PRODUCTION_QUALIFIED` where applicable. Own Profile is the user resume/how others see them; pair Compatibility requires an explicit second person. Active product-gap contract: `docs/PRODUCT/TESTS_PSYCHOANALYSIS_PSYCHOREPORT_PRODUCT_GATE.md`.

## 12. Context capsule rule
Use only `ops/operator_kernel/capsules/<route>.json` for the active route. Capsule contains goal, anchors, mandatory files, write boundary, validation, hazards and current pending state — never the full archive.

## 13. Patch permission boundary
Routes are **advisory execution scopes, not local-edit vetoes**. Each route declares `required_read`, `allowed_write`, risk/proof metadata and validation guidance. `forbidden_write` and `ask_before_write` are empty for local project work; route enforcement is non-blocking. Real external side effects (deploy, production data mutation, push/merge, secrets/provider changes) still require the separate authorization appropriate to that external action.
Read the exact target file before editing. No adjacent refactor, dependency bump, signing/CI change, schema migration or business-rule change without a matching route and evidence.

## 14. Action risk and authorization
Norm: `docs/NORM/KERNEL_ACTION_RISK_AND_AUTHORIZATION.md`.
Local scoped edits/tests/packages are reversible inside the current task. Push/merge/publish/deploy/production migration/DNS/external messaging/on-chain/production secrets are external/live actions and require separate explicit authorization. One authorization never becomes blanket permission.

## 15. Forbidden drift
- No romantic dating/searching for women.
- Do not copy data/assets/business content from VK, Telegram, Diia, dating products or the supplied HTML reference; references are structure/UX only.
- Do not disclose candidate private latent/personality/character classification.
- Do not merge Trust, Compatibility, Quality Fit or Account Completeness.
- Do not use provider IDs as business owner IDs; internal owner is `global_id`.
- Do not restore the superseded fixed cross-metric compatibility weights/Vedic 5% aggregate. Owner canon: each metric is independent 0..100; selected overall is a simple unweighted arithmetic mean. Runtime migration is allowed inside the current owner-directed implementation task when it preserves the independent-metric Q28 contract.
- Do not reintroduce direct socially desirable psychological questions.
- Do not let legacy direct-question results feed `visual-latent-v2`.
- Do not change master logo or frozen Android workflow without separately evidenced scope.
- Do not remove/simplify existing functions/routes/state/tests/infrastructure unless the current task explicitly requires it.

## 16. Runtime route resolver
Commands:
- `python ops/operator_kernel/operator_kernel.py resolve "<request>"`
- `python ops/operator_kernel/operator_kernel.py validate-config`
- `python ops/operator_kernel/operator_kernel.py refresh-map`

`routes.yaml` is runtime-primary. Hardcoded Python logic is limited to scoring/aggregation/fallback and cannot silently replace route definitions.

## 17. Enforcement and deterministic hooks
Human matrix: `docs/AI/KERNEL_ENFORCEMENT_MATRIX.md`.
Machine hooks: `ops/operator_kernel/config/hooks.yaml`.
Required lifecycle: `session_start`, `pre_read`, `pre_edit`, `post_edit`, `pre_compact`, `session_resume`, `pre_pack`, `post_pack`.
Critical rules that cannot be mechanically enforced are marked `ENFORCEMENT_GAP` instead of being treated as guaranteed.

## 18. Agents and skills
Agents: Explorer, Planner, Implementer, Verifier, Packager, Healer — machine contracts in `ops/operator_kernel/config/agents.yaml`.
Skills registry: `ops/operator_kernel/config/skills.yaml`.
Safe local resolve/verify/map/package skills are `model_or_user`; external release/push/deploy actions are `user_only`.
Verifier never fixes the implementation it verifies.

## 19. Validation gates and proof gates
Route-scoped syntax/parse/static/unit/integration checks only as relevant. Full Android Gradle/APK qualification remains GitHub CI evidence when not locally authoritative.
Every completion claim needs observable evidence: exact command + exit status/output, changed-file list/diff, test report, schema validation, artifact/hash, screenshot/runtime log when required.
Allowed verdict vocabulary: `PASS`, `PASS_WITH_WARNINGS`, `LOCAL_PASS_LIVE_PENDING`, `PARTIAL_PASS`, `FAIL`, `BLOCKED`, `UNKNOWN`, `NOT_RUN`, `NOT_APPLICABLE`.

## 20. Independent verification
Protocol: `docs/NORM/KERNEL_INDEPENDENT_VERIFICATION_PROTOCOL.md`.
Mandatory for 3+ changed files, Kernel/routes/hooks/agents/skills/canonical layer, Android runtime, backend/API, DB, auth/security or any DEVELOPMENT/RELEASE package. At least one negative/adversarial probe; verifier is read/test/diff/archive-inspect only.

## 21. Memory governance
`CANONICAL` → stable confirmed truth. `PROJECT_SHARED` → verified reusable engineering facts. `LOCAL_PRIVATE` → machine-specific and never release/secrets. `OPERATIONAL_PENDING` → active unresolved work only. `HISTORICAL` → closed history/reference.
Rules: `docs/AI/KERNEL_MEMORY_GOVERNANCE.md`. Active pending: `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`. Handoff: `reports/generated/SESSION_HANDOFF.md`.

## 22. File-map freshness
Run `refresh-map` after all source/doc edits and before package. The final summary stores generation timestamp, count, excluded parts and content digest excluding its two generated map files. Stale map blocks package.

## 23. Development / Release archives
DEVELOPMENT: full project context, docs, tests, reports, Kernel, demo, AI memory. Packaged with `scripts/package_source_archive.py`.
RELEASE: allowlisted runtime/build/deployment source only, no internal reports/demo/AI/tests/secrets. Policy: `docs/NORM/BROTHERHOOD_RELEASE_ARCHIVE_POLICY.md`; packager: `scripts/package_release_archive.py`.
The frozen workflow remains unchanged. A packaged archive is not proof of APK build; GitHub CI/device evidence is separate.

Clean versioned delivery naming (owner Q32): user-facing archives are `Brotherhood_v0_5_NN.zip` only; descriptive suffixes are forbidden unless explicitly requested. DEVELOPMENT/RELEASE class is content/manifest policy, not an automatic filename suffix.

## 24. Healer guards
`docs/healer/**` covers demotion, overload, keyword loss, route staleness, uncontrolled full-read, runtime disconnect, memory pollution, archive mixing and psychological canon drift. Repeated new failures must gain a reproducible guard/test.

## 25. Cycles and reports
Master compatibility canon/index: `docs/CANON/BROTHERHOOD_COMPATIBILITY_CANON.md` + `docs/research/compatibility/INDEX.md`. Evidence classification/source→claim must stay explicit; source provenance current map is `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.md`; authority classes are governed by `docs/CANON/BROTHERHOOD_SOURCE_AUTHORITY_CANON.md`.

Roadmap and active executable authority: `docs/CYCLES/BROTHERHOOD_CYCLES_0024_0100.md` + `docs/CYCLES/BROTHERHOOD_ROADMAP_0024_0100.md`. Owner sequential-order override of 2026-08-17 requires ascending executable cycle IDs: 0034 through 0036 are implemented; next executable cycle is 0037. `docs/CYCLES/BROTHERHOOD_CYCLES_0101_0200.md` + `docs/CYCLES/BROTHERHOOD_ROADMAP_0101_0200.md` are retained as decomposition/reference only; 0101–0110 were satisfied by 0034 and 0111 was executed out of order before this correction, but 0112+ are not active execution IDs unless the owner explicitly reactivates them. Predecessor roadmaps remain retained as history/governance. Roadmap/status: `docs/CYCLES/**`. Every implementation is tied to current cycle/task ledger and produces current report/handoff evidence. History never overrides current HEAD.

## 26. Kernel specification source
Owner-supplied implementation specification is preserved verbatim at `docs/AI/reference/MASTER_PROMPT_KERNEL_UNIVERSAL_v002.md`. It is a `REFERENCE / IMPLEMENTATION_SPEC`: it defines required Kernel capabilities, but current owner instruction and Brotherhood CANON remain higher truth.

## 27. Next safe action
Cycle `0028 — Scientific Questionnaire Systems v1.2` is source/runtime/HTML implemented and remains `VA=PENDING`. The active baseline is 7 systems / 197 items with server-authoritative scoring and per-system compatibility. Owner Q46 makes psychology explicitly multi-method: questionnaire is the conscious/situational lane, while associative/implicit and later observed-behavior data remain separate versioned channels.

Cycles `0027–0030` are source/HTML implemented with owner `VA=PENDING`. Root IA is `Профиль → Люди → Чаты → Группы → Развитие`; Development includes Tests, Associative/Implicit, Numerology and Zodiac. Cycle 0029 implements Jung Word Association, Freud Free Association, IAT/RT and Q48 Reverse Friendship Pattern Discovery v1. Cycle 0030 productizes standalone Numerology vNext with persistent reading/history and independent NU comparison, and records Q49 Friendship Reflection Surveys as a future research-only mechanism. The next implementation cycle is `0031 — Zodiac standalone application`; Enneagram is 0032.

## 23. Research-platform / outcome-feedback anchor
Owner Q35: Brotherhood is also a research platform. Anchor: `docs/CANON/BROTHERHOOD_RESEARCH_PLATFORM_CANON.md` + `docs/research/outcomes/INDEX.md`. Research tasks involving feedback/statuses/outcomes must preserve historical score/model/input/recommendation-policy/exposure snapshots, must not infer negative outcomes from non-exposure, and must never create automatic production-learning edges. Backend/database telemetry implementation requires an explicitly routed implementation cycle.


## Cycle 0017 completion anchor
`0017 — Lifestyle Compatibility Engine` historical note: completed as research/documentation architecture in `v0.5.47-cycle0017`. This historical statement is superseded for current routing by section 27 and `PROJECT_MANIFEST.json`.
