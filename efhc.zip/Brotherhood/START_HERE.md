# START HERE — Brotherhood

1. Project: **Brotherhood**. Fast-changing HEAD/version truth: `PROJECT_MANIFEST.json`.
2. Read `KERNEL.md` — active dispatcher, not an encyclopedia.
3. Read active task/cycle: `docs/CYCLES/CYCLE_STATUS_REGISTRY.md` + active cycle file.
4. Read operational state: `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` + `reports/generated/SESSION_HANDOFF.md`.
5. Truth order: current owner instruction → confirmed CANON → KERNEL → SSOT → NORM/ADR/rules → runtime → tests/CI → current reports → history/reference.
6. Product Q&A SSOT: `docs/PRODUCT/APP_CREATION_QUESTIONS_AND_ANSWERS.md`.
7. Kernel specification source: `docs/AI/reference/MASTER_PROMPT_KERNEL_UNIVERSAL_v002.md` (`REFERENCE / IMPLEMENTATION_SPEC`, never higher than owner CANON).
8. Keywords/anchors: `docs/AI/PROJECT_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md` + `docs/AI/PROJECT_CANONICAL_ANCHORS.md`.
9. Human route map: `docs/AI/PROJECT_OPERATOR_KERNEL_ROUTE_MAP.md`; runtime-primary routes: `ops/operator_kernel/config/routes.yaml`.
10. Startup file index: `ops/operator_kernel/cache/file_map.summary.json`; never preload full `file_map.json` unless the task requires it.
11. Resolve request: `python ops/operator_kernel/operator_kernel.py resolve "<request>"`.
12. Validate Kernel contracts: `python ops/operator_kernel/operator_kernel.py validate-config`.
13. Read only route-scoped CANON/SSOT/NORM/rules/capsule and exact target files before editing.
14. Respect allowed/forbidden/ask-first boundaries and action-risk class.
15. For 3+ changed files, Kernel/routes, backend, DB, auth/security, Android runtime or packaging: independent verifier is mandatory.
16. Before package: validations → reports/memory → final file-map refresh → DEVELOPMENT/RELEASE separation → archive re-open verification.
17. Next safe action comes from active task/handoff, never from an old report.
18. Director plan: `docs/PRODUCT/DIRECTOR_MASTER_PLAN_0034_0100.md`.
19. Licensed assessment/research tooling inventory: `docs/research/tooling/LICENSED_ASSESSMENT_TOOLING_SANDBOX_V1.md`.
20. Association norms owner authorization: `docs/research/associations/OWNER_ASSOCIATION_NORMS_AUTHORIZATION_V1.md`.
21. Active execution authority is the parent cycle sequence in `docs/CYCLES/BROTHERHOOD_CYCLES_0024_0100.md` + `docs/CYCLES/BROTHERHOOD_ROADMAP_0024_0100.md`: owner order requires ascending cycle IDs. Cycles 0034–0036 are implemented; cycle `0111` remains preserved as an out-of-order historical execution artifact; `0101–0200` is reference/decomposition only unless the owner explicitly reactivates it. Next executable cycle = `0037`; research completion is never product completion.

Psychological/Quality Fit work additionally reads `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md` and `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`. It also reads `docs/CANON/BROTHERHOOD_PSYCHOLOGY_EPISTEMIC_CANON.md`: models remain versioned/improvable, while the product exposes the exact `0..100%` computation of the active approved algorithm version for its input snapshot.
Product discovery/UI work additionally reads `docs/CANON/BROTHERHOOD_DISCOVERY_UX_CANON.md` and the append-only product Q&A.

Source authority work additionally reads `docs/CANON/BROTHERHOOD_SOURCE_AUTHORITY_CANON.md` and `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_v004.md`; scientific/UX/product/technical/legal/data authority must never leak across classes.

Research anchor for compatibility/methodology tasks: `docs/research/compatibility/INDEX.md`; use the relevant research/product route and current owner CANON. The removed legacy 600-task/protected-mechanics branch is not an active constraint.

13-locale calibration anchor: `docs/research/validation/INDEX.md` + `docs/CANON/BROTHERHOOD_LOCALIZATION_CANON.md`; exact locale set is `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`, with translation/native QA and psychometric equivalence tracked separately.

Research-feedback/outcome work additionally reads `docs/CANON/BROTHERHOOD_RESEARCH_PLATFORM_CANON.md` and `docs/research/outcomes/INDEX.md`; recommendation exposure/policy provenance is mandatory and automatic production learning is forbidden.
