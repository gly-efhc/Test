## v0.5.70 development — cycle 0030 Numerology standalone vNext + Q49 friendship reflections
- implemented route-backed standalone Numerology vNext in `Развитие`: personal readings, Life Path/Soul/Destiny, birth-chart signals, four Pinnacle peak ages, saved reading history/reread, pair comparison and persistent NU comparison history;
- added `numerology-reading-v2 / numerology-knowledge-v1 / vedic-numerology-runtime-v1` plus migration `0015_numerology_vnext.sql`;
- preserved Q28 semantics: `NU` is independent `0–100%`; no fixed cross-metric 5%; `40/35/15/10` are internal NU components only; name-derived values are descriptive and excluded from NU compatibility;
- added Q49 `Friendship Reflection Surveys` roadmap mechanism for bilateral post-meeting/friendship social-research surveys joined to frozen Q48 pre-friendship snapshots, with no automatic production reweighting;
- full simulator contract: 115 paths / 134 operations / 54 DB tables / 21 Android AppRoutes, route probe 134/134 with 0 failures;
- active HTML candidate advanced to `BROTHERHOOD_UI_SIMULATOR_v0_5_44.html`; owner visual acceptance, Compose mirror, CI/APK, live DB and live E2E remain pending/not run.

## v0.5.69 development — cycle 0029 associative / implicit + reverse friendship research
- implemented `WORD_ASSOCIATION_V1` (24 cues), `ASSOCIATIVE_FREE_CHAIN_V1` (8 seeds × 5 transitions), and `IMPLICIT_ASSOCIATION_RT_V1` (48 trials / 32 critical);
- added private raw-event persistence, public result/history and independent per-method pair compatibility `0–100%`;
- added migration `0014_associative_implicit_friendship_patterns.sql`;
- implemented Q48 `Reverse Friendship Pattern Discovery v1`: pre-friendship/exposure snapshots, sufficiently exposed comparison pairs, separate similarity/difference/method signal analysis, no automatic production reweighting;
- expanded sole Source SSOT to 225 canonical / 194 scientific sources and 158 structured claims with `IAT-GREENWALD-2003`;
- full simulator contract: 108 paths / 127 operations / 52 DB tables / 21 Android AppRoutes, route probe 127/127 with 0 failures;
- active HTML candidate advanced to `BROTHERHOOD_UI_SIMULATOR_v0_5_43.html`; owner visual acceptance, Compose mirror, CI/APK, live DB and live E2E remain pending/not run.


## v0.5.66 development — cycle 0028 methodology expansion
- expanded sole Source SSOT from 217 to 224 canonical sources (193 scientific) and claim ledger from 151 to 157 claims;
- added `PSYCHOLOGICAL_METHODOLOGY_CATALOG_V1`;
- registered Freud, Jung, Greenwald/McGhee/Schwartz, Bessel van der Kolk, Gabor Maté, and Baer/Wolf/Risley methodology lineages;
- identified van der Kolk as the trauma author matching the owner-described principle; recorded the precise product meaning: irreversible event vs modifiable present-day trauma imprints/recovery;
- roadmap cycle 0044 changed from optional visual-instrument research to Associative & Implicit Measurement Systems v1;
- no change to active 7-system / 197-item questionnaire scoring in this patch.
## 2026-08-11 — Cycle 0025 UI Recovery A
- Recovered My Profile → People → Candidate → Compatibility → Tests → Psychological Profile/Report in standalone HTML.
- Core recovery screens now consume SimulationEngine route responses instead of direct people fixtures.
- Active visual candidate advanced to `BROTHERHOOD_UI_SIMULATOR_v0_5_36.html`; historical `v0_5_35` preserved.
- Visual acceptance remains pending; Compose/CI not run.

## v0.5.35 / cycle 0024 — runtime persistence + server Q28 + full simulator — 2026-08-11
- Added immutable Psychological Report persistence/history, safe input fingerprint and four report routes.
- Added Q28 independent Compatibility server contract, metric preferences and ten current psychological module pair metrics with coverage/status/model provenance.
- Added migration 0011 for reports and compatibility preferences.
- Regenerated source contract to 87 OpenAPI paths / 100 operations / 49 DB tables / 21 Android AppRoutes.
- Expanded standalone simulator to 200 deterministic synthetic candidates and route-backed report/compatibility behavior.
- Re-verified official Diia Android release source and recorded reusable architecture/UX donor principles without copying code/branding/data.
- Visual acceptance, accepted Compose mirror, live DB, CI/APK and LIVE E2E remain open gates.

# 0.5.34 — Cycle 0023 functional recovery source milestone

- added product assessment module/result/monthly-retake layer;
- added aggregate Psychological Profile, Psychological Analysis and versioned Psychological Report snapshot source models;
- added Q28 independent compatibility aggregation and per-current-test-module 0–100 comparators;
- productized existing date-based Numerology as independent `NU=0–100`, removing active fixed-5% wording;
- added v0.5.34 full HTML recovery flows for Tests/Psychology/Report/Profile/People/Candidate/Compatibility;
- corrected roadmap to independent `R/S/B/H/VA/A/CI/E2E` evidence stages;
- recorded Q41: quality-led test redesign is allowed; historical 100×6 is a current baseline, not an immutable product requirement;
- no GitHub CI/APK/live qualification claimed.

## v0.5.56 — 2026-08-11 — functional-reality audit / roadmap recovery

- Corrected project truth after owner audit: research completion no longer implies finished product functionality.
- Audited the real Tests → latent profile → self-analysis → report path. 100×6 source mechanics exist; per-test result is partial/generic; monthly retake is not enforced; self-analysis is partial; full psychological report is not implemented.
- Added Q39 Own Profile boundary: Own Profile is the user resume/how others see them; pair Compatibility requires a second person.
- Added Q40 research→product implementation gate and the Tests/Psychoanalysis/Psychoreport product completion contract.
- Replaced active roadmap with 0001–0041: Product Recovery 0023–0028; prior Enneagram-and-later tail preserved at 0029–0041; reserve begins 0042.
- Preserved all owner-locked 100×6 assessment mechanics byte-for-byte.
- No Android/backend/database runtime feature implementation is claimed by this documentation/governance corrective archive.


## v0.5.33 / cycle 0022 UI acceptance correction + CI compiler hotfix
- Reopened the cycle-0022 visual acceptance gate after owner review rejected the current full-product UI as incomplete/overloaded.
- Added explicit HTML-first gate: full simulator → owner acceptance → Android mirror → CI/APK qualification.
- Added factual UI gap audit and implementation matrix; no broad visual redesign is claimed complete by this correction.
- Fixed all three root causes behind the supplied GitHub Kotlin compilation log (87 compiler errors): shared localization helper visibility, explicit `weight` import, explicit `calculateBottomPadding` import.
- Protected 100×6 mechanics and backend/database/domain contracts remain unchanged by the compiler hotfix.
# Changelog

## v0.5.51-cycle0021 — Hospitality Verified Stay / Reviews / Trust + Android UX
- Android runtime source milestone advances to `v0.5.33 / versionCode 38` for user-visible Hospitality runtime.
- Adds bilateral verified-stay evidence, blind reviews with 7-day publication, separate Hospitality Reputation, moderation/restriction/appeal due process.
- Adds Android Hospitality models/repository/ViewModel/routes/screens, My Home, calendar, discovery/eligibility/request/stay/review UX, safe maps, structured chat events, Keystore private arrival store and push/deep-link routing.
- Keeps Compatibility, Account Rating and Trust domains separate; protected `100×6` unchanged.
- Gradle/APK/device, external push delivery, release-parity simulation and live E2E are not claimed.


## v0.5.50-cycle0020 — 2026-08-10
- Implemented Hospitality backend/data foundation behind fail-closed `HOSPITALITY_ENABLED`.
- Added PostgreSQL migration `0009_hospitality.sql` and canonical schema parity for host profiles, availability, stay requests/events, private-access audit, confirmation/review/restriction foundations and indexes.
- Added AES-256-GCM private-location and accepted-arrival snapshots, server-authoritative eligibility, idempotent request creation, canonical direct-chat binding, optimistic request state, transactional capacity recheck and timezone-aware lifecycle tick.
- Added `/v1/hospitality/*` APIs and optional Hospitality filters on existing `/v1/people`; regenerated OpenAPI.
- Added Hospitality backend/security tests; protected `100×6` and Android remain unchanged.
- `completed` is not verified stay; confirmations/reviews/Trust evidence and Android UX remain cycle 0021.
- Real PostgreSQL migration execution, GitHub CI, APK/device and LIVE_E2E are not claimed.

## v0.5.45-cycle0015-hardening — 2026-08-10
- Hardened cycle 0015 Values Compatibility research architecture without production runtime changes.
- Preserved historical `VC-R0`; added explicit scoring-adapter/centering/normalization provenance and transparent `VC-R0.1`.
- Added/qualified `VC-R1-CIRCLE`, `VC-R2-RSA`, `VC-R3-ROLE-DYADIC`, coverage/freshness, role/unit-of-analysis, 13-locale comparability and Q35 longitudinal causal guards.
- Expanded Scientific Source Registry `150→162` and Claim Evidence Ledger `102→111`; the original 60-source owner-authorized snapshot remains exactly scoped to those 60; 0 claims authorize production scoring.
- Protected 100×6 mechanics and Android/backend/database production runtime are outside this cycle scope.


## v0.5.42-cycle0013 — 2026-08-10
- Completed cycle 0013 Mentor / Project Partner Compatibility research package.
- Added Q34 canonical distinction: versioned/improvable psychological model vs exact current algorithmic `0..100%` score.
- Expanded scientific registry 120→132 and claim ledger 70→81.
- Runtime/protected 100×6/scoring unchanged.

## v0.5.40-cycle0011 — Business Partner Compatibility Science (research/documentation)

- Added complete `business_partner` research package: construct/process boundaries, role governance, conflict/repair, outcomes, causal confounds, baselines/validation, longitudinal data and 13-locale plan.
- Expanded Scientific Source Registry `93 → 108` with `BUS-001..BUS-015` and Claim Evidence Ledger `45 → 58` with `CLM-BUS-001..013`; no claim is production-scoring-authorized.
- Preserved PC/QF/Trust/VC/CC/IC/LC boundaries and explicit pair/team/venture level-of-analysis guard.
- Added permanent clean archive naming CANON: `Brotherhood_v0_5_NN.zip` only for new user-facing versioned deliveries.
- No Android/backend/database/protected 100×6/scoring change.


## v0.5.39-cycle0010 — Friendship Compatibility Science (documentation/research)
- Added friendship science master package with formation/maintenance/repair/dissolution, outcome hierarchy, causal/confound plan, male-context boundary and 13-locale validation.
- Expanded research sources 82→93 and claims 36→45; no production scoring authorization.
- Runtime/protected 100×6/Android/backend/database unchanged.
## v0.5.38-cycle0009 — PC v1 research spec + 0005–0008 tail closure

- Closed actionable source/evidence/localization documentation tails from cycles 0005–0008.
- Scientific registry expanded 73→82 and claim ledger 29→36; post-Q30 additions remain citation/research references outside the original 60-source commercial-release permission snapshot.
- Added dyadic Psychological Compatibility Engine v1 research specification, pair-feature registry, role contracts, score-normalization semantics, baseline/challenger ladder, validation/promotion, privacy/explanation and model-manifest schema.
- PC remains an independent 0..100 method index; no universal similarity formula, no cross-metric weights, no Quality Fit/Trust blending and no production activation.
- All 13 locales remain mandatory validation scope; runtime remains v0.5.32 / versionCode 37 because cycle 0009 changes no product runtime.
- Protected 100×6 mechanics/scoring, frozen workflow and master logo remain unchanged.

## v0.5.37-cycle0008 — Calibration & Psychometric Validation Protocol + 13-locale architecture (2026-08-10)
- Runtime source metadata advances to `0.5.32 / versionCode 37` because user-visible localization architecture is expanded to the exact 13-locale canon: `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`.
- Shared/Android locale registries and backend calibration defaults now use the 13-locale set; required runtime-key coverage is structural for enabled packs. Translation/native QA and psychometric equivalence remain separately statused and are not falsely claimed complete.
- Added master calibration/validation suite: intended-use validity, cohort design, reference battery, reliability/test-retest, construct validity/MTMM, invariance, DIF/item bias, sample-size/power/precision, holdout/external replication and model-promotion gates.
- Scientific registry expanded to 73 sources and claim ledger to 29 claims; all production-scoring permissions remain false.
- Protected 100×6 assessment content, hidden/latent mechanics and compatibility scoring remain unchanged.
- Full 13-locale standalone HTML simulation parity was not faked and remains `REQUIRES_PARITY_UPDATE`.
- Cycle 0008 completed; cycle 0009 Psychological Compatibility Engine v1 Research Spec is next.

## v0.5.33-docs — Cycle 0004 Compatibility Research Foundation (2026-08-09)

## v0.5.35-docs-cycle0006 — Psychological Construct Architecture
- Documentation/research only; Android runtime remains `0.5.31 / versionCode 36`.
- Added 23-record PC construct registry, Big Five/HEXACO/IPC overlap controls, reference-battery architecture, construct→source and dyadic relation matrices.
- Added six Brotherhood-specific latent hypotheses, all `HYPOTHESIS / REQUIRES_VALIDATION`; no production coefficients or protected visual→latent mechanics changed.
- Recorded owner-confirmed official permission for all 60 active-registry sources and `NON_COMMERCIAL` Brotherhood status, without changing scientific evidence/validation gates.
- Cycle 0006 completed; cycle 0007 Visual Stimulus Scientific Program is next.
- Added canonical modular Compatibility product/canon/ADR base; independent PC/IC/VC/CC/LC/PT/EN/NU/AS scores and selected-score arithmetic Overall.
- Added expanded per-metric methodologies, visual assessment research program, role research, source→claim/evidence crosswalk and causal model.
- Added current source provenance map v003 while preserving v002 historical/stale mapping unchanged.
- Restructured roadmap to 0004–0031; cycle 0004 complete, 0005 next; cycle 0003 LIVE_E2E remains external pending.
- Android/backend/database/protected 100×6 mechanics, frozen workflow and master logo not modified.

# Changelog

## 0.5.32-docs — compatibility science/documentation foundation

- Android runtime remains `0.5.31 / versionCode 36`; this is a DEVELOPMENT archive/documentation revision only.
- Added `docs/research/compatibility/` master research base with 40 curated standards/official references/meta-analyses/systematic reviews/primary studies/negative evidence/UX references.
- Added independent methodology documents for Psychology, Interests, Values, Communication, Lifestyle, Brotherhood Personality Type, Enneagram, Numerology and Astrology; Quality Fit, Trust/Coverage and overall arithmetic aggregation are documented separately.
- Added source-to-claim/evidence policy, metric contract/registry, causal model, role contexts, visual-assessment research program, stimulus/material pipeline, psychometric validation, statistical plan, ethics/privacy and longitudinal outcome program.
- Added VK + Telegram + Diia product/UX architecture and Compatibility service-page specification.
- Replaced the compact 0001–0010 roadmap with an owner-requested 27-cycle program `0004–0030`; `0031–0100` is reserve.
- Added `compatibility_research` Operator Kernel route and corrected the stale `compatibility_model` route from fixed cross-model weights to independent selectable metric engines.
- Protected product mechanics remain hash-pinned and unchanged; the legacy runtime `HybridCompatibilityEngine` is documented as a future migration gap, not silently changed.

## 0.5.31 — critical restoration: release-parity tests + protected mechanics guard

- Forensic diff established that the real Android psychological assessment core and source-map/research anchors remained byte-identical to the owner-approved v0.5.27 baseline; the critical regression was in the standalone HTML demo, which had substituted primitive text choices and an independent fake score.
- Removed the simplified HTML assessment path and restored release-parity 100×6 indirect visual series with the protected `visual-latent-v2` / `scene-library-v4` generator, 50 latent traits, 112 public-safe qualities, 48 scenes, 16 paradigms, 8 composition recipes, hidden scoring/profile aggregation and positive result projection.
- Added `PROTECTED_PRODUCT_MECHANICS_MANIFEST.json`, blocking verifier, packager integration, route boundaries, healer guard and architecture tests. UI/design/demo routes cannot touch protected test/source-map mechanics.
- Owner canon now explicitly defines the HTML as an investor-facing release simulation; simulation never authorizes a simplified substitute.
- No protected assessment/scoring/source-map file changed in this recovery.
- Android version metadata advances to `0.5.31 / versionCode 36`; exact Android compile/APK/device remains frozen GitHub CI/device evidence.


## 0.5.30 — male business-club product canon + Operator Kernel v002 integration

- Fixed the owner product boundary: Brotherhood is a male-only 18+ social/business club and people marketplace; romantic dating/searching for women is out of scope. Dating-like large candidate cards/swipes remain only inside recommended discovery.
- Replaced the overloaded authenticated Home with the owner-selected four primary actions: People search, Messages, Tests, Search requests. Test Results remain inside Tests.
- Added a first-class discovery/search-request canon with separate `Compatibility` and `Quality Fit`; private latent/personality classifications remain non-public.
- Integrated the owner-supplied Universal Operator Kernel v002 requirements into START_HERE/KERNEL, runtime routes, deterministic hooks, six-role agent registry, skill policy, risk/authorization, five-layer memory governance, path-scoped rules, context capsules and behavior/adversarial tests.
- Added deterministic separate DEVELOPMENT and RELEASE source packaging. RELEASE uses an allowlist and excludes internal AI memory/reports/tests/demo/secrets.
- Standalone `BROTHERHOOD_UI_DEMO.html` remains a full offline stateful `BackendSimulator → SimulationEngine → frontend` workbench and mirrors the new four-action Home/search-request model.
- Version advanced to `0.5.30 / versionCode 35` because Android Home runtime and current API/version metadata changed. Exact Android compile/APK/device acceptance remains GitHub/device evidence.
- Frozen universal GitHub workflow and canonical logo master remain unchanged.

## 0.5.29 — persistent app shell, real DEBUG simulation boundary, theme parity

- Fixed the confirmed navigation-shell defect: the five-tab bottom navigation is now owned by the authenticated root `Scaffold` and therefore remains present on nested pages such as Settings, Tests, Results, Chat and profile/model screens. Auth remains the only route without the main bottom navigation.
- Added `DemoBackendSimulator → DemoSimulationEngine` as an explicit DEBUG/offline backend-façade + stateful boundary. Production keeps real backend repositories; DEBUG fallback now routes demo people, communities, Trust and chat mutations through the engine instead of page-local fixture shortcuts.
- Reworked the Material light palette into a coherent warm neutral light scheme with explicit surface/on-surface/outline/status tokens.
- Rebuilt `BROTHERHOOD_UI_DEMO.html` around three explicit layers: local `BackendSimulator` → persistent `SimulationEngine` → frontend mirror. The engine persists state in localStorage, emits domain events, supports run/pause/network/reset/offline-like ticks, and drives chats, groups, test progress/results, profile/settings and route state.
- HTML bottom navigation is physically outside dynamic page content and remains visible across every authenticated route. Light and dark modes share semantic tokens and were browser-render smoke-tested.
- The owner-supplied `FRONTEND_v066.html` was used only as a structural workbench reference (phone preview + separate technical area + simulation controls). No EFHC data, balances, Energy/VIP/Activ state, routes or business semantics were copied.
- Default DEBUG demo profile is the synthetic `Марк Левченко`; production account data is unaffected.
- Frozen universal GitHub workflow is unchanged. APK/device acceptance for v0.5.29 remains pending.


## 0.5.28 — Full offline UX workbench maintenance

- Replaced the reduced/script-free UX preview with a full stateful standalone `BROTHERHOOD_UI_DEMO.html` modeled on the owner-provided workbench pattern: live phone preview plus technical route/state controls.
- Demo covers all current user-facing Brotherhood route families and key nested flows, including authentication, discovery/filtering/candidate details, chats/group creation, communities, profile/edit/settings, Services, self-analysis, 100 test series, six-step assessment, completed results, Trust, Brotherhood-32, Enneagram, Zodiac, Numerology, calibration and update/version state.
- Added synthetic demo personas (`Марк Левченко`, `Илья Демченко`, `Сергей Кравец`) and realistic synthetic discovery identities; no owner title/private identity is used.
- Removed `Глава Федерации` from the active Brotherhood demo UI. Synthetic identities exist only in the offline demo; Android runtime identity/account semantics are unchanged.
- Demo remains one offline file: inline CSS/JS/PNG, no external assets and no runtime fetch/XHR. Browser hash/history is used for Back behavior.
- Android product features/routes were not removed. Frozen universal GitHub workflow remains unchanged.

## 0.5.28 — UX recovery: welcome home, visible test results, Android Back history

- HTML demo corrective: replaced the previous JavaScript/History-API demo runtime with a script-free native hash-anchor demo baseline after the owner reported the delivered HTML did not work.
- Active standalone demo is now `tools/visual_checks/BROTHERHOOD_UI_DEMO.html`; versioned `BROTHERHOOD_UI_DEMO_v0_5_28.html` is byte-identical.
- Full demo now covers Home, People/candidate/filters, Chats/chat, Groups/community, Profile/edit/settings, Services, Self-analysis, Tests, six test steps, Results and Trust.
- Added active delivery canon: every UX iteration returns both the complete project archive and a complete standalone HTML demo; the exact demo is also embedded inside the archive.
- Owner device evidence: v0.5.27 was installable through SAI, but the runtime UI was reported as severely overloaded and difficult to understand.
- Home was reduced to a welcome message plus three primary actions: Find friends, Continue tests, My results; all lower-frequency capabilities remain reachable through All Brotherhood features and the existing bottom navigation.
- Added dedicated `TEST_RESULTS` route showing core-model summaries and completed visual-series `label`/`summary` only; hidden latent dimensions/raw scores remain internal.
- Added an explicit `View results` entry at the top of the Tests screen.
- Added lightweight navigation history and Compose `BackHandler`, so Android system Back returns to the previous Brotherhood route/tab instead of exiting from every overlay.
- Added self-contained HTML UX demo for v0.5.28; after owner feedback the active baseline was corrected to native hash-anchor navigation with no JavaScript dependency.
- Diia Android was used only as a UX/navigation architecture reference: explicit BackHandler event routing and separate top/body/bottom screen structure; no Diia source was copied into Brotherhood.
- Runtime change: version `0.5.28 / versionCode 33`. Frozen universal workflow is unchanged.

## 0.5.27 — known-good regression isolation + PNG-specific layout

- Compared owner-confirmed known-good `v0.5.19 / versionCode 24` against v0.5.21, v0.5.22, v0.5.23, v0.5.24 and current Android source. Package identity, min/target SDK and core toolchain stayed stable; the first major package/auth delta is v0.5.23.
- Replaced `androidx.credentials` / `credentials-play-services-auth` `1.7.0-alpha03` with stable `1.6.0`; Google/passkey auth source remains enabled.
- Removed `android:autoVerify` from the custom `brotherhood://telegram-login/callback` intent filter; callback/deep-link handling remains.
- Treat the `libandroidx.graphics.path.so` strip line as a non-fatal packaging warning, not an established installation root cause.
- Corrected PNG-specific UI geometry from owner screenshot evidence. The new complete framed PNG no longer inherits SVG inner-glyph sizing: Auth uses a 96dp total PNG slot, TopAppBar uses 38dp, `ContentScale.Fit`, no extra clipping.
- Owner correction: Brotherhood logo is strictly square. Removed `android:roundIcon`, all `ic_launcher_round` resources, adaptive-icon XML and themed monochrome derivative; package now ships square launcher PNGs only (48/72/96/144/192 px).
- Android 12+ system splash is intentionally logo-free because the platform masks splash icons into a circular safe region; the first Compose surface shows the true square logo.
- Version bumped to `0.5.27 / versionCode 32` because runtime resources/layout and Android dependency/manifest packaging changed. Universal workflow and canonical 1536×1536 logo master remain unchanged.
- Device installation result remains an external gate; no cause is declared final without the v0.5.27 APK test or PackageInstaller/adb status.


## 0.5.25 — install diagnostic + logo layout correction

- Investigated the owner-reported Android installation failure against v0.5.23/v0.5.24 source. `AndroidManifest.xml` is byte-identical, applicationId/minSdk/targetSdk are unchanged, and no new permissions/dependencies were introduced by v0.5.24.
- The strongest confirmed install-risk in the supplied CI evidence remains `NON_CANONICAL_DEBUG` signing: permanent Development signing secrets were absent, so update continuity with an already installed Brotherhood APK is not guaranteed. Exact Package Installer text/adb result is still required before declaring the device-side root cause.
- Corrected logo placement from owner screenshot evidence: removed redundant Compose clipping around the canonical PNG, increased Auth artwork to 128dp and TopAppBar artwork to 48dp, and aligned adaptive launcher artwork to the guaranteed 66dp safe zone inside the 108dp layer.
- Reduced only the Android runtime bitmap derivative to 512×512; the 1536×1536 canonical master and its SHA-256 remain unchanged.
- Updated the standalone HTML visual check to model the actual v0.5.25 dimensions and distinguish in-app rendering from launcher masking.
- Universal workflow, permissions, matching, auth semantics and canonical logo master remain unchanged.

## 0.5.24 — Owner-approved canonical PNG logo

- Replaced the active BR SVG/monogram artwork with the owner-approved `brand/logo_brotherhood.png` master (1536×1536 RGB, SHA-256 `47657ba1a1f9dd99cb9b275ea485b8bfdf3a5ac19de33f5187934eaf3b573e19`), losslessly encoded from the decoded pixels of the supplied JPEG/JFIF transport file.
- Updated authentication, shared TopAppBar, generic brand mark, adaptive launcher, Android 13 themed icon and Android 12+ splash to derivatives of the same PNG.
- Full-colour Compose rendering now uses `Image` + `ContentScale.Fit`; no Material tint and no crop. Auth logo is 104dp; TopAppBar logo is 40dp.
- Old BR master SVG moved to `brand/history/` and is no longer an active brand source.
- Added `docs/CANON/BROTHERHOOD_BRAND_CANON.md` and `tools/visual_checks/logo_brotherhood_preview.html` for future visual regression.
- No matching weights, psychological model, Trust semantics, auth semantics, API routes, workflow or Android permissions changed.


## 0.5.23 — Cycle 0003 source milestone
- CI corrective for run `84786542178`: replaced ambiguous `java.net.URI(...)` in Gradle Kotlin DSL with the supported Gradle `uri(...)` API; no workflow/version/runtime-feature change.
- Added deploy-ready public FastAPI auth/session boundaries over the existing backend and PostgreSQL architecture.
- Added rotating opaque access/refresh sessions, revocation, device binding, email OTP, passkey registration/authentication and server settings persistence.
- Added Google ID-token server verification; Android retrieves the public Google Client ID at runtime from Brotherhood backend, so universal CI stays frozen.
- Added Telegram OIDC Authorization Code + PKCE with registered HTTPS backend callback and short-lived one-time completion ticket bound to the initiating Android device.
- Added migration `0008_auth_sessions_provider_passkeys.sql` for session/auth/passkey/OIDC/settings state.
- Android now persists encrypted session material via Android Keystore and restores `global_id` across restart.
- Evidence: local backend/architecture tests PASS; real deployment/PostgreSQL/provider credentials and Android E2E remain pending and are not claimed as LIVE_E2E.

## 0.5.22 — Cycle 0002 source milestone

- completed the source-side Android UX/results/i18n corrections for cycle 0002 without rebuilding the application architecture;
- added visible positive-profile value on Home, Profile and Self-analysis, preserving private latent scoring;
- improved People and Groups actions for narrow screens and made manual Development APK installation guidance unconditional;
- localized runtime error fallbacks for RU/UK/EN without leaking raw exception messages;
- embedded the research-only APK source map under `docs/research/source_map/` and documented its bounded use;
- kept `android-build.yml` byte-identical and deferred APK visibility proof to the milestone GitHub/device checkpoint.

## 0.5.21 — TextAlign corrective and cycle-scope discipline

- fixed missing Compose `TextAlign` import proven by GitHub run 83283873357;
- added architecture regression guard;
- preserved byte-identical universal workflow;
- clarified cycle registry: unused 0004–0100 slots are RESERVED, not mandatory work.

## 0.5.13 — 2026-07-31

### Complete numerology knowledge integration
- functional Android/source release;
- no `applicationId`, signing-policy, master-logo, Trust/Compatibility/Completeness separation or permission change;
- the canonical 100 psychological/behavioral tests / 600 questions remain intact and separate from numerology; numerology has no questionnaire.

# Brotherhood v0.5.12

- Added longitudinal `friendship_outcomes` for 30/90-day friendship calibration; this data is internal analytics and not public reputation.
- Added a shadow `Friendship Expectations` predictor from existing f065 + f071–f080; the canonical 15 production weights remain unchanged and Vedic Numerology remains 5%.
- Added offline logistic-regression calibration tooling that produces review-only candidate weights and never rewrites production weights automatically.
- Converted the 100 × 6 assessment presentation into paired, shuffled situational prompts and hides construct titles until completion to reduce answer gaming.
- Added bounded profile avatar import: app-private local storage, resize/compress, ≤512 KiB backend synchronization, no broad storage/media permission.
- Placed the canonical Brotherhood mark in the Home identity card and differentiated core feature icons without modifying the master SVG.
- Preserved Trust, Compatibility and Account Completeness as separate systems.
- Repaired known apksigner/aapt parser regressions in the unpacked-source workflow.
- Version: `versionCode 17`, `versionName 0.5.12`.


## 0.5.12 — 2026-07-31

### Outcome-calibrated friendship matching, veiled assessments and avatar
- current production compatibility weights remain 100% total: 18/10/10/9/8/7/7/7/7/5/4/3/2/2/1;
- numerology remains exactly 5%;
- Friendship Expectations is diagnostic only pending longitudinal evidence;
- new outcome and avatar migrations are additive (`0002`, `0003`);
- no change to `applicationId`, master logo geometry, production signing or permission canon.

## 0.5.11 — 2026-07-31

### Canonical BR logo + discovery/privacy upgrade
- встроен канонический логотип Brotherhood из пользовательского SVG: master SVG + 512/1024 PNG, adaptive launcher foreground, Android 13 monochrome icon и Android 12+ splash;
- сохранены точные бренд-цвета: `#000000` и `#ECAF21`; UI больше не перекрашивает логотип Material tint-ом;
- проведён аудит 10 предоставленных dating/friendship/numerology песочниц; AGPL/no-license код не копируется, MIT/CC0 проекты используются как архитектурные и UX-ориентиры;
- добавлен Quick Discovery deck: один кандидат за раз, skip, undo skip, просмотр подробной совместимости и запрос дружбы;
- добавлены persistent discovery filters: verified-only, online-only, shared-interest requirement, min Trust, min compatibility, hide requested;
- добавлены режимы видимости профиля `discoverable / connections / private` с синхронизацией на backend;
- явно оформлен Passport mode через город поиска, не меняющий домашний город пользователя;
- профиль дополнен статистикой запросов, чатов и групп;
- Android `versionCode = 15`, `versionName = 0.5.11`; backend/API defaults = 0.5.11.


## 0.5.9 — 2026-07-31

### Discoverability / navigation / Brotherhood naming
- подтверждено по CI SHA, что APK-6 был собран из v0.5.8; отсутствие функций на экране было UX-проблемой, а не старым APK;
- название приложения во всех локалях изменено на `Brotherhood`;
- добавлена отдельная главная панель с прямым доступом к чатам, 15 слоям совместимости, самоанализу, 100 тестам, Trust, Brotherhood-32, эннеаграмме, зодиаку и ведической нумерологии;
- нижняя навигация упрощена до `Главная / Люди / Чаты / Группы / Профиль`;
- чаты стали first-class вкладкой и получили badge непрочитанных сообщений;
- Tests и Trust вынесены в самостоятельные overlay-экраны с явной кнопкой назад;
- последняя выбранная вкладка сохраняется в `SettingsStore`;
- принципы Diia Open Source изучены как архитектурный ориентир: компактная bottom navigation, badges, accessibility semantics, модульные auth/i18n/queue/crypto packages; EUPL-код напрямую не копируется;
- Android `versionCode = 14`, `versionName = 0.5.9`; backend version defaults = 0.5.9.

## 0.5.8 — 2026-07-31

### Multi-layer compatibility, self-analysis, Chat Core and Android updates
- совместимость разделена на независимые слои: тесты, интересы, характер, ценности, образ жизни, цели дружбы, общение, конфликты, бизнес/взаимопомощь, социальный формат, Brotherhood-32, эннеаграмма, зодиак, ведическая нумерология и география;
- добавлены базовая и персонализированная итоговая совместимость; Trust Score остаётся отдельным показателем;
- ведическая нумерология закреплена как математический расчёт без тестов; дружеская совместимость этого слоя рассчитывается только из двух дат рождения, число имени исключено из compatibility score;
- добавлен раздел самоанализа по пройденным тестам и профильным моделям;
- личный чат переведён на Brotherhood Private Chat E2EE v1 с Android Keystore, signed prekey, ECDH, HKDF ratchet, AES-GCM, TOFU pinning и fingerprints;
- групповые чаты остаются не секретными и серверно модерируемыми, но шифруются при хранении;
- чат получил replies, reactions, typing, edit events, sender delete, per-user delivery/read receipts, offline outbox, фото/аудио/видео/файлы и системную запись голосовых заметок;
- закрыты safety/group tails: block/unblock, закрытая жалоба в Trust moderation, управление составом группы владельцем, encrypted push-token registration hook;
- добавлен стабильный signing-контур: при наличии GitHub Secrets CI собирает подписанный release APK и AAB;
- Play In-App Updates добавлен для Play-установок, sideload update использует version manifest и стабильную подпись;
- добавлен заменяемый logo slot и выровнены основные action/navigation controls;
- Android `versionCode = 13`, `versionName = 0.5.8`; backend API = 0.5.8.

## 0.5.7 — 2026-07-31

### GitHub APK build unit-test / Brotherhood-32 scoring fix
- разобран `logs_83032884747.zip`: ZIP, распаковка, JDK 17, Gradle, Android SDK 36 и production Kotlin compile прошли успешно;
- единственное падение: `Personality32EngineTest.identical_profiles_have_maximum_compatibility`;
- исправлена семантическая инверсия `bondStyle`: шкала идёт от стабильной/вовлечённой связи (0) к адаптивной/независимой (100), поэтому устойчивость теперь рассчитывается как `100 - bondStyle`;
- тест максимальной совместимости привязан к полностью стабильной связи;
- добавлен regression-test, подтверждающий, что одинаковые независимые профили не получают такой же long-term friendship fit, как одинаковые устойчивые профили;
- Android `versionCode = 12`, `versionName = 0.5.7`;
- workflow менять не требуется.

## 0.5.6 — 2026-07-31

### GitHub APK build compile fix
- исправлен единственный Kotlin compiler error из GitHub Actions run `logs_83021345746.zip`;
- устранён JVM `Platform declaration clash` в `MainViewModel`: Compose-state свойство `language` генерировало setter `setLanguage(AppLanguage)`, который конфликтовал с ручной функцией того же имени;
- публичный обработчик переименован в `changeLanguage(AppLanguage)`, обновлены оба вызова в `BrotherhoodApp.kt`;
- `SettingsStore.setLanguage(...)` сохранён без изменений, поскольку находится в другом классе и JVM-конфликта не создаёт;
- проведён статический аудит аналогичных getter/setter method clashes по всем Kotlin-файлам — дополнительных конфликтов не найдено;
- Android `versionCode` повышен до 11, `versionName` до 0.5.6;
- workflow менять не требуется: CI снова подтвердил корректную распаковку ZIP, JDK 17, Gradle и Android SDK 36 до стадии `:app:compileDebugKotlin`.

# Changelog

## 0.5.30 — male business-club product canon + Operator Kernel v002 integration

- Fixed the owner product boundary: Brotherhood is a male-only 18+ social/business club and people marketplace; romantic dating/searching for women is out of scope. Dating-like large candidate cards/swipes remain only inside recommended discovery.
- Replaced the overloaded authenticated Home with the owner-selected four primary actions: People search, Messages, Tests, Search requests. Test Results remain inside Tests.
- Added a first-class discovery/search-request canon with separate `Compatibility` and `Quality Fit`; private latent/personality classifications remain non-public.
- Integrated the owner-supplied Universal Operator Kernel v002 requirements into START_HERE/KERNEL, runtime routes, deterministic hooks, six-role agent registry, skill policy, risk/authorization, five-layer memory governance, path-scoped rules, context capsules and behavior/adversarial tests.
- Added deterministic separate DEVELOPMENT and RELEASE source packaging. RELEASE uses an allowlist and excludes internal AI memory/reports/tests/demo/secrets.
- Standalone `BROTHERHOOD_UI_DEMO.html` remains a full offline stateful `BackendSimulator → SimulationEngine → frontend` workbench and mirrors the new four-action Home/search-request model.
- Version advanced to `0.5.30 / versionCode 35` because Android Home runtime and current API/version metadata changed. Exact Android compile/APK/device acceptance remains GitHub/device evidence.
- Frozen universal GitHub workflow and canonical logo master remain unchanged.

## 0.5.3 — 2026-07-31

- проанализированы `Песочница.xz`, SberID SDK archive и Flutter idle template;
- добавлен лицензионный фильтр: MIT-паттерны допустимы, GPLv3/Sber AT-NC-SA код не включён;
- backend получил реальный runtime repository для Neon/PostgreSQL;
- `DATABASE_URL` автоматически переключает storage с test-memory на PostgreSQL;
- добавлены server-side profiles, users search, communities, assessment results, trust incidents и messages;
- приватные trust descriptions и сообщения шифруются на PostgreSQL через отдельные Vercel secrets;
- добавлены server-side app sessions с hash токена и проверка `session → global_id`;
- internal identity/session endpoints защищаются `INTERNAL_AUTH_SECRET` в production;
- добавлен provider readiness registry для Google/Telegram/Facebook;
- Android получил RemoteDataRepository поверх Vercel API;
- DemoRepository ограничен debug fallback;
- pending mutations получили retry/flush после восстановления сети;
- добавлены профильные API endpoints и offline queue для sync профиля;
- версия Android/API обновлена до 0.5.3.

## 0.5.2 — 2026-07-31

- зафиксирован канон имён архивов и верхнего каталога `Brotherhood/`;
- добавлен полный реестр Brotherhood-32 из 32 уникальных типов;
- добавлен Service Hub со всеми модулями совместимости;
- добавлен экран сообщений и offline outbox UI;
- редактирование профиля заменено с placeholder на рабочую форму;
- профиль сохраняется локально;
- расширена SQLite-схема кеша, pending mutations, recent entities, sync metadata и message outbox;
- добавлены canonical requirements и provider registry;
- усилено разделение APK / Vercel backend / Neon;
- добавлены тесты 32 типов, `global_id` и ведической нумерологии;
- версия Android и API обновлена до 0.5.2.

### Дополнительная квалификация v0.5.3

- Brotherhood-32 получил отдельный встроенный 20-вопросный профиль вместо заранее заполненного demo-результата;
- эннеаграмма получила отдельный 18-вопросный встроенный профиль;
- дата рождения стала редактируемой с ограничением 18+;
- зодиак и ведическая нумерология автоматически пересчитываются после изменения даты/латинского имени;
- core personality profile и каждый завершённый тест синхронизируются через offline queue → Vercel → Neon;
- сервер отдаёт чистый `friendship_test_score`, число общих тестов и risk flags, а полный гибридный итог рассчитывается локально в APK;
- удалены персональные demo-данные из исходного кода;
- материалы Песочницы используются только как лицензируемые архитектурные/UI-ориентиры; GPL и ограниченные SDK напрямую не встраиваются.

## 0.5.24 — CI corrective for runs 84790063345 / 84792124384 and standalone logo preview

- Fixed the only Android compilation error proven by both supplied GitHub runs: `BrotherhoodApp.kt` used `ApiConfig` without importing `org.federationofavatars.brotherhood.network.ApiConfig`.
- The frozen universal workflow remains byte-identical; no version bump was made because this is a compile corrective for the already-declared v0.5.24 runtime.
- Reworked `tools/visual_checks/logo_brotherhood_preview.html` into a self-contained single file. It no longer references `../../brand/logo_brotherhood.png`; one lossless 512×512 PNG derivative of the unchanged canonical 1536×1536 master is embedded directly in CSS as a data URI.
- The preview has no JavaScript dependency and no external image/file references, so it can be opened independently from the source tree.

## v0.5.36-docs-cycle0007
- Completed cycle 0007 Visual Stimulus Scientific Program (documentation/research only).
- Added visual runtime research snapshot, primitive/composition registries, hypothesis schema and expanded validation/fairness/latency/holdout protocols.
- Updated the 60-source rights context to owner-confirmed commercial-release permission; current product positioning is social.
- No Android/backend/database/UI/scoring/protected-test mechanics changed.

## v0.5.41-cycle0012
- Completed Worker / Team Fit Science research package.
- Registry 108→120 sources; claim ledger 58→70; no production scoring promotion.
- Added Q33 Psychology Epistemic Canon: psychological outputs are model estimates, not exact/deterministic truths.
- Preserved runtime v0.5.32/versionCode37 and protected 100×6 mechanics.

## v0.5.43-cycle0014
- Completed Interests Compatibility Engine v1 research specification and transparent IC-R0 baseline.
- Added Q35 Research Platform Canon and exposure→feedback→relationship-status→longitudinal-outcome architecture.
- Added 9 post-Q30 research references (registry 132→141) and 11 claims (81→92), with zero automatic production coefficient promotion.
- Preserved 13-locale research scope and Q34 exact versioned score semantics.
- No Android/backend/database/protected 100×6 runtime changes.


## v0.5.44-cycle0015
- Completed cycle 0015 Values Compatibility Engine research architecture.
- Expanded source registry 141→150 and claim ledger 92→102.
- Added transparent research-only VC-R0 baseline and 13-locale/outcome validation contracts; runtime unchanged.


## v0.5.46-cycle0016 — Communication Compatibility research
- Completed research-only Cycle 0016.
- Added CC-R0 pre-exposure preference comparator, 14-construct/pair-feature/challenger registries, 13-locale and longitudinal research contracts.
- Source Registry 162→172; Claim Ledger 111→123; production-scoring promotions 0.
- Runtime/backend/database/protected 100×6 unchanged by scope.

## v0.5.47-cycle0017 — Lifestyle Compatibility research
- Completed research-only Cycle 0017.
- Added deterministic `LC-R0` with separate hard-constraint handling, soft preference score, coverage and `INSUFFICIENT_DATA` semantics; missing data is never converted to zero.
- Added Lifestyle input/construct/pair-feature/challenger registries, 13-locale adaptation plan, Research Platform exposure snapshot and longitudinal validation contracts.
- Added owner Q36: all registered scientific sources are synthesized as one evidence corpus while rights/provenance remain separate metadata; scientific evidence does not become a production coefficient automatically.
- Source Registry 172→179; Claim Ledger 123→137; production-scoring promotions remain 0.
- Runtime/backend/database/protected 100×6 mechanics unchanged by scope.

## v0.5.48-cycle0018 — Personality-Type Compatibility research
- Completed research-only Cycle 0018 over existing Brotherhood-32 contracts.
- Added continuous-first `PTC-R0`, soft membership across the existing 32 interpretation prototypes, pair-feature/challenger registries, Research Platform exposure snapshot and longitudinal validation plan.
- Expanded Q36 Scientific Evidence Corpus `179 -> 189` and Claim Ledger `137 -> 151`; production scoring promotions remain zero.
- Exact 13-locale architecture defined; existing RU/UK/EN type-title runtime registry remains unchanged and 10 additional title locales require native QA before activation.
- Android/backend/database/shared/protected `100×6` runtime/scoring intentionally unchanged.

## 2026-08-11 — cycle 0024 continuation: source map v004 + roadmap 0024–0073
- Activated 217-source unified typed source map with six independent authority classes and no-leakage CANON.
- Consolidated the former 189-source scientific registry into the 217-source typed v004 map (189/189 matched, 0 missing/ambiguous), migrated evidence/governance metadata, and removed the duplicate active registry. Historical v003/v002 maps remain provenance only.
- Added/activated 50-cycle program 0024–0073; reserve moved to 0074–0100.
- Synchronized cycle guard/tests, Kernel/SSOT/handoff/manifest.
- Fixed short-keyword Kernel routing collision (`ci` substring vs scientific/technical source-map queries).
- No new CI/APK/live migration/Compose visual mirror claimed.


## 2026-08-11 — cycle 0026 UI Recovery B
- Preserved the existing Chat backend as authority; did not reconstruct or delete messaging mechanics.
- Added first-class Search Requests models/repositories/migration 0012/API create-list-detail-update-archive.
- Added Community membership read/join/leave API.
- Regenerated source contract to 90 OpenAPI paths / 108 HTTP operations / 50 DB tables / 21 Android AppRoutes.
- Upgraded route-backed HTML Chat with reply/edit/delete/reactions/attachments/typing/read/block/report/direct-group behavior.
- Upgraded route-backed Groups/Communities and persistent Search Requests flows.
- Preserved cycle-0025 HTML `v0_5_36` as historical evidence; active candidate becomes `v0_5_37`.
- Final local regression: 368/368 PASS; focused cycle/protected/backend set: 52/52 PASS; Simulation Engine probe: 108/108 operations, 0 failures.
- No owner visual acceptance, Compose mirror, GitHub CI/APK, live PostgreSQL migration or LIVE E2E claimed.

## 2026-08-11 — cycle 0028 scientific test systems / HTML acceptance candidate
- Materialized seven independent research-traceable psychological test systems v1 over the current versioned 100×6 visual item bank.
- Added `research-calibration-v1`: internal scientific-corpus calibration now; future cohorts are optional reviewed hardening, not a multi-year release gate.
- Added test-system backend/API + independent pair compatibility and refreshed Simulation Engine source contract to 94 paths / 112 operations / 50 tables / 21 Android AppRoutes.
- Upgraded Psychological Report to scientific-system v2 synthesis with source trace, coverage and history.
- Added HTML candidate `BROTHERHOOD_UI_SIMULATOR_v0_5_38.html`; VA remains pending, Android/CI intentionally not run.
- Cycle 0027 remains planned/uncompleted; 0043–0053 are reclassified as Test Platform v2 hardening/expansion.


## v0.5.63 DEVELOPMENT — cycle 0028 Q43 scientific-baseline continuation
- Corrected calibration logic: existing scientific corpus is the launch baseline; future Brotherhood outcomes are post-release versioned recalibration evidence, not a pre-launch dependency.
- Added `scientific-baseline-synthesis-v1` systematizing seven psychological test systems against the unified source/claim corpus.
- Added stable compatibility feature schemas and post-release recalibration data contract.
- Enriched psychological-test-system API metadata without exposing private trait coordinates.
- Advanced standalone HTML acceptance candidate to `BROTHERHOOD_UI_SIMULATOR_v0_5_39.html`; Compose/CI remain blocked on owner VA.


## v0.5.64 DEVELOPMENT — cycle 0028 stimulus provenance / test UX correction
- Confirmed by source audit that `scene-library-v4` visuals are Brotherhood procedural/generated prototype stimuli, not images copied from scientific studies.
- Fixed test answer-selection jump: answer changes patch selected-state/navigation controls in place instead of rebuilding the entire HTML screen and resetting scroll.
- Removed source IDs, model/calibration internals, Simulation Engine terminology and report hashes from normal respondent-facing test execution UX.
- Added `SCIENTIFIC_STIMULUS_PROVENANCE_CONTRACT_V1.md` and item-level provenance audit.
- Added first scientific content materialization bank `SCIENTIFIC_VISUAL_ITEM_CONCEPTS_V1.json`: 20 Mini-IPIP-derived content anchors, 16 concept-ready, 1 non-clinical review, 3 sensitive visual adaptations blocked, 0 release visual assets yet.
- Enriched `VIS-FC-IMG-001` source metadata: Hilliard et al. supports an item-development/measurement method, not literal authority for Brotherhood to reuse third-party study images.
- Active HTML becomes `BROTHERHOOD_UI_SIMULATOR_v0_5_40.html`; test VA is `BLOCKED_STIMULUS_PROVENANCE`, Compose/CI remain NOT_RUN.

## v0.5.65 DEVELOPMENT — cycle 0028 scientific questionnaire v1.2 productization
- Removed the former generated 100×6/600-task visual assessment branch from active product/runtime authority and removed its local owner-lock/protected-hash/control-veto layer.
- Replaced the active assessment product with seven scientific questionnaire systems / 197 items / 64 construct-system pairs / minimum three independent signals per construct-system pair.
- Corrected Mini-IPIP broad-factor mapping, construct-specific scenario wording and item-level source/claim semantics; active item trace uses 37 source IDs and 73 structured claims from the single 217-source SSOT.
- Removed visual forced-choice research sources from active text-questionnaire scoring evidence; that research remains a separate non-active scientific branch.
- Preserved deterministic server-authoritative scoring, per-system results, Psychological Profile/Report and seven independent psychological compatibility scores `0–100%`.
- Fixed standalone Simulation Engine route-domain handling for `/v1/scientific-assessments*` and restored the generic SHA-256 helper required by immutable Psychological Report fingerprints.
- Current source/simulation contract: 97 OpenAPI paths / 115 operations / 50 DB tables / 21 Android AppRoutes / 200 candidates; runtime probe 115/115 operations PASS.
- Operator Kernel local edit enforcement is advisory/non-blocking; external live side effects remain separately authorized.
- Active HTML becomes `BROTHERHOOD_UI_SIMULATOR_v0_5_41.html`; owner VA remains PENDING. Android Gradle/CI/APK/live E2E are NOT_RUN.


## v0.5.67 planning synchronization — 2026-08-13
- Owner Q45 supersedes authenticated Home root with `Профиль → Люди → Чаты → Группы → Развитие`.
- Added `BROTHERHOOD_DEVELOPMENT_HUB_CANON.md`: Tests/Numerology/Zodiac are standalone Development applications with full flows.
- Owner Q46 establishes multi-method psychology: questionnaire baseline + high-priority associative/implicit lane + launch-day observed-behavior/outcome provenance.
- Added `TESTS_AND_DATA_COLLECTION_ROADMAP_V2.md`.
- Reprioritized cycle 0029 to Associative & Implicit Measurement Systems v1; Enneagram moves to 0032.
- Updated cycle 0027 to Root IA + Development Hub; Search Requests move under People while Trust/Hospitality remain contextual flows.
- No runtime/HTML/Android/backend/DB implementation in this planning-only patch; next implementation cycle is 0027.

## v0.5.68-development — Cycle 0027
- Implemented Q45 root IA and Development Hub in HTML simulator.
- Added Q47 modular self-development product model.
- Added 12 standalone test apps over 197 scientific items / 7 internal systems.
- Added `/v1/test-apps*` backend contracts and parent-system aggregation.
- Added standalone Numerology/Zodiac v1 Development flows.
- Simulation source contract: 100 paths / 118 operations / 50 tables / 21 Android AppRoutes.
- Android mirror/CI not run; owner HTML VA pending.
- Re-verified `SRC-001 Mentalys Android App` at revision `2146bebf5c9c936246adee914d17ee2366a5f3ac`; adopted questionnaire/history UX patterns only, not scoring authority.
