# Third-party source review

Brotherhood v0.5.7 не содержит прямых копий исходного кода из предоставленных сторонних проектов.

Для архитектурного и UI-анализа использовались:

- Mark42 — MIT License, copyright (c) 2022 Artur Stambultsian.
- TelegramUI — MIT License, copyright (c) 2024 XeleneStudio.
- fastapi-telegram-mini-app — MIT License, copyright (c) 2024 zytfo.

MyTonWallet (GPLv3) и SberID SDK (Sber Public License AT-NC-SA) были рассмотрены, но их исходный код в Brotherhood не включён.

## v0.5.10 sandbox review

The following user-provided projects were reviewed as references: Alovoa, Humbble, Complete Dating App, Pegava Dating App, Tinder Clone, Tinder React Native, Tindev, DostiPak, Android Java Dating App and Numerology.

No source files, images, fonts or other copyrighted assets from those archives are copied into Brotherhood v0.5.10. MIT/CC0 projects informed independently reimplemented UX/architecture patterns. AGPL and no-license projects are reference-only. See `docs/SANDBOX_SOURCE_AUDIT_v0_5_10.md`.


## v0.5.13 Numerology data integration

The user-supplied `Numerology-main.zip` was used as the authorized source for the requested numerology characteristics and calculation reference. The user explicitly stated that permission has been obtained for all supplied archives.

Brotherhood v0.5.13 does not import that project's React Native runtime, package dependencies, images, fonts, application identity or build system. The supplied numerology records are preserved for provenance in `shared/numerology/source_vietnamese_v1.json`; Brotherhood uses an independently structured RU/UK/EN runtime knowledge asset and Kotlin implementation.

## v0.5.14 personality/work-style research foundations

Brotherhood v0.5.14 uses independently implemented hidden visual/associative tasks. It does not copy proprietary questionnaire item banks.

- International Personality Item Pool (IPIP): used as a public-domain construct/reliability research reference. IPIP states that its items and scales are in the public domain. Brotherhood does not expose the IPIP direct self-report format as its canonical assessment UX.
- O*NET® 30.3 Database / Work Styles: construct-level occupational work-style information informed the Brotherhood user-selectable business/leadership quality vocabulary. O*NET 30.3 Database content is CC BY 4.0.

Attribution: This project includes adapted construct-level information informed by the O*NET 30.3 Database by the U.S. Department of Labor, Employment and Training Administration (USDOL/ETA), used under CC BY 4.0. O*NET® is a trademark of USDOL/ETA. Brotherhood modifications have not been approved, endorsed or tested by USDOL/ETA.
