package org.federationofavatars.brotherhood

import java.time.LocalDate
import org.federationofavatars.brotherhood.domain.NumerologyReadingEngine
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NumerologyReadingEngineTest {
    @Test
    fun reading_is_derived_from_birth_date_and_keeps_name_numbers_descriptive() {
        val date = LocalDate.of(1991, 2, 14)
        val canonical = VedicNumerologyEngine.calculate(date, "ALEX MORGAN")
        val reading = NumerologyReadingEngine.calculate(date, "ALEX MORGAN", canonical)

        assertEquals(canonical.soulNumber, reading.dateSoulNumber)
        assertEquals(canonical.destinyNumber, reading.dateDestinyNumber)
        assertEquals(canonical.maturityNumber, reading.dateMaturityNumber)
        assertTrue(reading.lifePathNumber in setOf(1,2,3,4,5,6,7,8,9,10,11,22))
        assertTrue(reading.birthChart.isNotEmpty())
        assertEquals(4, reading.pinnacles.size)
        assertTrue(reading.nameSoulNumber != null)
        assertTrue(reading.expressionNumber != null)
    }

    @Test
    fun chart_keys_are_capped_to_available_reference_records() {
        assertEquals("11111", NumerologyReadingEngine.chartKey(1, 7))
        assertEquals("4444", NumerologyReadingEngine.chartKey(4, 8))
        assertEquals("999999", NumerologyReadingEngine.chartKey(9, 9))
    }

    @Test
    fun missing_and_isolated_rules_are_deterministic() {
        val counts = (1..9).associateWith { 0 }.toMutableMap().apply { this[1] = 1 }
        val keys = NumerologyReadingEngine.isolatedAndMissingKeys(counts)
        assertTrue("1CL" in keys)
        assertTrue("Not7" in keys)
        assertTrue("Not9" in keys)
    }

    @Test
    fun optional_name_does_not_change_birth_date_reading() {
        val date = LocalDate.of(1990, 1, 1)
        val a = NumerologyReadingEngine.calculate(date, "FIRST NAME")
        val b = NumerologyReadingEngine.calculate(date, "DIFFERENT NAME")
        assertEquals(a.lifePathNumber, b.lifePathNumber)
        assertEquals(a.birthChart, b.birthChart)
        assertEquals(a.pinnacles, b.pinnacles)
        assertFalse(a.nameSoulNumber == null && b.nameSoulNumber == null)
    }

    @Test
    fun pinnacle_ages_follow_the_supplied_reference_formula() {
        // Supplied reference uses first peak age = 36 - lifePath, then +9 years per peak.
        val date = LocalDate.of(2000, 1, 3) // 03-01-2000 => life path 6
        val reading = NumerologyReadingEngine.calculate(date, null)
        assertEquals(listOf(30, 39, 48, 57), reading.pinnacles.map { it.reachedAtAge })
    }

    @Test
    fun master_22_uses_the_same_reference_peak_age_formula_without_special_override() {
        val masterDate = (1..31).asSequence().flatMap { day ->
            (1..12).asSequence().mapNotNull { month ->
                runCatching { LocalDate.of(1980, month, day) }.getOrNull()
            }
        }.firstOrNull { NumerologyReadingEngine.referenceLifePath(it) == 22 }
            ?: error("Test fixture with life path 22 not found")
        val reading = NumerologyReadingEngine.calculate(masterDate, null)
        assertEquals(14, reading.pinnacles.first().reachedAtAge)
    }

    @Test
    fun missing_digits_are_exposed_for_the_generic_source_absence_characteristic() {
        val reading = NumerologyReadingEngine.calculate(LocalDate.of(2000, 1, 1), null)
        assertEquals(listOf(3, 4, 5, 6, 7, 8, 9), reading.missingBirthChartDigits)
    }
}
