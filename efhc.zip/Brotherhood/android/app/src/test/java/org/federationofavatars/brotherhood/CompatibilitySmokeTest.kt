package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.DemoRepository
import org.junit.Assert.assertTrue
import org.junit.Test

class CompatibilitySmokeTest {
    @Test
    fun demoCompatibilityIsWithinRange() {
        assertTrue(DemoRepository.people.all { it.compatibility in 0..100 })
    }
}
