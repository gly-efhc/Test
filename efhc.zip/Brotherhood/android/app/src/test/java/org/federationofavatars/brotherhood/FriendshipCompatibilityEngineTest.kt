package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.domain.FriendshipCompatibilityEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FriendshipCompatibilityEngineTest {
    @Test
    fun commonTestsDriveCompatibilityAndConfidence() {
        val mine = AssessmentCatalog.assessments.associate { it.id to 85 }
        val other = AssessmentCatalog.assessments.associate { it.id to 82 }
        val result = FriendshipCompatibilityEngine.calculate(mine, other, 70, 90)
        assertTrue(result.commonTests == AssessmentCatalog.REQUIRED_TEST_COUNT)
        assertTrue(result.confidence == 100)
        assertTrue(result.score >= 80)
    }

    @Test
    fun retiredFriendshipExpectationsDiagnosticRemainsInactive() {
        val equal = FriendshipCompatibilityEngine.calculate(
            mapOf("traits_core" to 80, "communication_conflict" to 70, "social_group_role" to 90),
            mapOf("traits_core" to 80, "communication_conflict" to 70, "social_group_role" to 90),
            0,
            0
        )
        assertEquals(0, equal.friendshipExpectationsScore)

        val opposite = FriendshipCompatibilityEngine.calculate(
            mapOf("traits_core" to 100, "communication_conflict" to 100, "social_group_role" to 100),
            mapOf("traits_core" to 0, "communication_conflict" to 0, "social_group_role" to 0),
            100,
            100
        )
        assertEquals(0, opposite.friendshipExpectationsScore)
    }

    @Test
    fun lowSimilarityDoesNotCreateMoralRiskFlags() {
        val result = FriendshipCompatibilityEngine.calculate(
            mapOf("traits_core" to 90, "communication_conflict" to 90),
            mapOf("traits_core" to 20, "communication_conflict" to 25),
            100,
            100
        )
        assertTrue(result.riskFlags.isEmpty())
        assertTrue(result.score in 0..100)
        assertTrue(result.score == result.testsScore)
    }
}
