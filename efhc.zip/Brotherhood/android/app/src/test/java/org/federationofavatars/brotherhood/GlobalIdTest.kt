package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.model.GlobalId
import org.junit.Assert.assertEquals
import org.junit.Test

class GlobalIdTest {
    @Test
    fun global_id_is_always_ten_digits() {
        assertEquals("0000000001", GlobalId(1).display)
        assertEquals("9999999999", GlobalId(9_999_999_999).display)
    }
}
