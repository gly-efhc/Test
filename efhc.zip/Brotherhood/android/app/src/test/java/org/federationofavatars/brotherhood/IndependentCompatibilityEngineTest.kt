package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.domain.CompatibilityMetricId
import org.federationofavatars.brotherhood.domain.IndependentCompatibilityEngine
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IndependentCompatibilityEngineTest {
    private fun breakdown() = CompatibilityBreakdown(
        total = 1, baseTotal = 2, friendshipTests = 90, interests = 80, character = 70,
        values = 60, lifestyle = 50, friendshipGoals = 40, communication = 30, conflict = 20,
        business = 10, socialFormat = 15, personality32 = 70, enneagram = 65, zodiac = 55,
        numerology = 75, geography = 45, friendshipExpectations = 0, reputation = 99, confidence = 88,
    )

    @Test
    fun q28_exposes_nine_independent_metrics_and_uses_simple_mean() {
        val result = IndependentCompatibilityEngine.fromBreakdown(breakdown())
        assertEquals(9, result.metrics.size)
        assertTrue(result.metrics.all { it.score in 0..100 })
        assertEquals((90 + 80 + 60 + 30 + 50 + 70 + 65 + 75 + 55) / 9.0, result.metrics.map { it.score }.average(), 0.001)
        assertEquals(64, result.overall)
        assertFalse(result.metrics.any { it.score == 99 }) // Trust/reputation is not a compatibility metric.
    }

    @Test
    fun selected_metrics_are_averaged_without_hidden_weights() {
        val base = IndependentCompatibilityEngine.fromBreakdown(breakdown())
        val selected = IndependentCompatibilityEngine.withSelection(base, setOf(CompatibilityMetricId.NU, CompatibilityMetricId.IC))
        assertEquals(setOf(CompatibilityMetricId.NU, CompatibilityMetricId.IC), selected.selected)
        assertEquals(78, selected.overall) // round((75 + 80) / 2)
    }
}
