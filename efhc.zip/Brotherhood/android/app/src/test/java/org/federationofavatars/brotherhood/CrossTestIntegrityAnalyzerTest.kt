package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.domain.CrossTestIntegrityAnalyzer
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.DimensionScore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CrossTestIntegrityAnalyzerTest {
    private fun result(id: String, score: Int) = AssessmentResult(
        assessmentId = id,
        startedAtEpochMs = 1L,
        totalScore = score,
        riskScore = 0,
        label = "test",
        summary = "test summary",
        dimensions = listOf(DimensionScore("shared_trait", "shared_trait", score)),
        answerConsistency = 100,
        idealizedSelfPresentation = 0,
    )

    @Test
    fun contradictionsAcrossRelatedTestsReduceInternalConsistencyWithoutMoralRisk() {
        val analysis = CrossTestIntegrityAnalyzer.analyze(
            mapOf(
                "traits_core" to result("traits_core", 95),
                "interpersonal_style" to result("interpersonal_style", 20),
                "communication_conflict" to result("communication_conflict", 90),
                "trust_support_boundaries" to result("trust_support_boundaries", 25),
            )
        )

        assertEquals(0, analysis.riskScore)
        assertTrue(analysis.consistencyScore < 50)
        assertEquals(1, analysis.evaluatedPairs)
        assertTrue(analysis.confidence > 0)
        assertTrue(analysis.flags.isEmpty())
    }
}
