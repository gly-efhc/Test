package org.federationofavatars.brotherhood.network

import android.content.Context
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.OffsetDateTime
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.HospitalityArrivalDetails
import org.federationofavatars.brotherhood.model.HospitalityAvailability
import org.federationofavatars.brotherhood.model.HospitalityAvailabilityMode
import org.federationofavatars.brotherhood.model.HospitalityAvailabilityState
import org.federationofavatars.brotherhood.model.HospitalityEligibility
import org.federationofavatars.brotherhood.model.HospitalityEvent
import org.federationofavatars.brotherhood.model.HospitalityHostDetails
import org.federationofavatars.brotherhood.model.HospitalityHostProfile
import org.federationofavatars.brotherhood.model.HospitalityHostPublicSummary
import org.federationofavatars.brotherhood.model.HospitalityPrivateLocation
import org.federationofavatars.brotherhood.model.HospitalityPublicReview
import org.federationofavatars.brotherhood.model.HospitalityReputation
import org.federationofavatars.brotherhood.model.HospitalityReviewState
import org.federationofavatars.brotherhood.model.HospitalitySleepingCondition
import org.federationofavatars.brotherhood.model.HospitalityVerification
import org.federationofavatars.brotherhood.model.StayConfirmationValue
import org.federationofavatars.brotherhood.model.StayRequest
import org.federationofavatars.brotherhood.model.StayRequestStatus
import org.json.JSONArray
import org.json.JSONObject

/**
 * Network adapter for Hospitality. Exact arrival data is fetched only from the participant-only
 * endpoint and is never cached here. Persisting it is delegated to HospitalitySecureStore.
 */
class HospitalityRemoteRepository(context: Context) {
    private val api: BrotherhoodApi = VercelApiClient(ApiConfig.baseUrl)

    suspend fun myHostProfile(token: String): HospitalityHostProfile = parseHostProfile(api.get("v1/hospitality/profile", token))

    suspend fun saveHostProfile(profile: HospitalityHostProfile, token: String): HospitalityHostProfile {
        val location = requireNotNull(profile.privateLocation) { "Private location is required for host settings" }
        val body = JSONObject().apply {
            put("is_hosting_active", profile.isHostingActive)
            put("max_guests", profile.maxGuests)
            put("max_days", profile.maxDays)
            if (profile.cityId.matches(Regex("^[0-9a-fA-F-]{36}$"))) put("city_id", profile.cityId)
            profile.cityValue?.takeIf(String::isNotBlank)?.let { put("city_value", it) }
            put("public_area_text", profile.publicAreaText)
            put("timezone_name", profile.timezoneName)
            put("sleeping_condition", profile.sleepingCondition.wire)
            put("house_rules", JSONArray(profile.houseRules))
            put("min_required_rating", profile.minRequiredRating)
            put("required_completed_tests", JSONArray(profile.requiredCompletedTests))
            put("availability_mode", profile.availabilityMode.wire)
            put("private_location", JSONObject().apply {
                put("exact_address", location.exactAddress)
                put("arrival_instructions", location.arrivalInstructions)
                location.exactLat?.let { put("exact_lat", it) }
                location.exactLon?.let { put("exact_lon", it) }
                put("arrival_contact", location.arrivalContact)
            })
        }
        return parseHostProfile(api.put("v1/hospitality/profile", body.toString(), token))
    }

    suspend fun availability(token: String): List<HospitalityAvailability> = parseAvailabilityList(api.get("v1/hospitality/availability", token))

    suspend fun saveAvailability(
        dateFrom: String,
        dateTo: String,
        state: HospitalityAvailabilityState,
        capacityOverride: Int?,
        token: String,
    ): HospitalityAvailability {
        val body = JSONObject().apply {
            put("date_from", dateFrom)
            put("date_to", dateTo)
            put("availability_state", state.wire)
            capacityOverride?.let { put("capacity_override", it) }
        }
        return parseAvailability(JSONObject(api.put("v1/hospitality/availability", body.toString(), token)))
    }

    suspend fun deleteAvailability(id: String, token: String) { api.delete("v1/hospitality/availability/$id", token) }

    suspend fun hostDetails(hostId: GlobalId, token: String): HospitalityHostDetails {
        val root = JSONObject(api.get("v1/hospitality/hosts/${hostId.value}", token))
        return HospitalityHostDetails(
            host = parsePublicHost(root.getJSONObject("host")),
            eligibility = root.optJSONObject("eligibility")?.let(::parseEligibility),
        )
    }

    suspend fun eligibility(hostId: GlobalId, checkIn: String, checkOut: String, guests: Int, token: String): HospitalityEligibility {
        val path = "v1/hospitality/hosts/${hostId.value}/eligibility?check_in_date=${enc(checkIn)}&check_out_date=${enc(checkOut)}&guests_count=$guests"
        return parseEligibility(JSONObject(api.get(path, token)))
    }

    suspend fun requests(direction: String = "all", status: String? = null, token: String): List<StayRequest> {
        val path = buildString {
            append("v1/hospitality/requests?direction=").append(enc(direction))
            status?.takeIf(String::isNotBlank)?.let { append("&status=").append(enc(it)) }
        }
        return parseRequests(api.get(path, token))
    }

    suspend fun request(requestId: String, token: String): StayRequest = parseRequest(JSONObject(api.get("v1/hospitality/requests/$requestId", token)))

    suspend fun createRequest(hostId: GlobalId, checkIn: String, checkOut: String, guests: Int, token: String): StayRequest {
        val body = JSONObject().apply {
            put("host_global_id", hostId.value)
            put("check_in_date", checkIn)
            put("check_out_date", checkOut)
            put("guests_count", guests)
        }
        return parseRequest(JSONObject(api.post("v1/hospitality/requests", body.toString(), token)))
    }

    suspend fun act(requestId: String, action: String, expectedVersion: Int, reason: String?, token: String): StayRequest {
        val body = JSONObject().apply {
            put("action", action)
            put("expected_version", expectedVersion)
            put("reason", reason)
        }
        return parseRequest(JSONObject(api.patch("v1/hospitality/requests/$requestId/status", body.toString(), token)))
    }

    suspend fun arrivalDetails(requestId: String, token: String): HospitalityArrivalDetails {
        val root = JSONObject(api.get("v1/hospitality/requests/$requestId/arrival-details", token))
        return HospitalityArrivalDetails(
            requestId = root.getString("request_id"),
            exactAddress = root.getString("exact_address"),
            arrivalInstructions = root.optString("arrival_instructions"),
            exactLat = root.optNullableDouble("exact_lat"),
            exactLon = root.optNullableDouble("exact_lon"),
            arrivalContact = root.optString("arrival_contact"),
            privateAccessExpiresAt = root.getString("private_access_expires_at"),
        )
    }

    suspend fun conversationEvents(conversationId: String, token: String): List<HospitalityEvent> {
        val arr = JSONArray(api.get("v1/hospitality/conversations/${enc(conversationId)}/events", token))
        return buildList {
            for (i in 0 until arr.length()) {
                val row = arr.getJSONObject(i)
                val payload = row.optJSONObject("public_payload") ?: JSONObject()
                val safe = buildMap<String, String> { for (key in payload.keys()) put(key, payload.optString(key)) }
                val createdAt = row.getString("created_at")
                add(HospitalityEvent(
                    eventId = row.getString("event_id"),
                    requestId = row.getString("request_id"),
                    conversationId = row.get("conversation_id").toString(),
                    actorGlobalId = row.optGlobalId("actor_global_id"),
                    eventType = row.getString("event_type"),
                    publicPayload = safe,
                    createdAt = createdAt,
                    createdAtEpochMs = epochMs(createdAt),
                ))
            }
        }
    }

    suspend fun confirm(requestId: String, value: StayConfirmationValue, token: String): HospitalityVerification {
        val root = JSONObject(api.post(
            "v1/hospitality/requests/$requestId/confirmation",
            JSONObject().put("confirmation", value.wire).toString(), token,
        ))
        return parseVerification(root)
    }

    suspend fun verification(requestId: String, token: String): HospitalityVerification =
        parseVerification(JSONObject(api.get("v1/hospitality/requests/$requestId/verification", token)))

    suspend fun reviewState(requestId: String, token: String): HospitalityReviewState {
        val root = JSONObject(api.get("v1/hospitality/requests/$requestId/review-state", token))
        return HospitalityReviewState(
            requestId = root.getString("request_id"), canSubmit = root.getBoolean("can_submit"),
            ownSubmitted = root.getBoolean("own_submitted"), ownPublished = root.getBoolean("own_published"),
            reviewDeadlineAt = root.optNullableString("review_deadline_at"), publishedReviewCount = root.optInt("published_review_count"),
        )
    }

    suspend fun submitReview(
        requestId: String, adequacy: Int, rules: Int, descriptionAccuracy: Int,
        reviewText: String?, privateFeedback: String?, token: String,
    ): HospitalityReviewState {
        val body = JSONObject().apply {
            put("adequacy", adequacy); put("rules_compliance", rules); put("description_accuracy", descriptionAccuracy)
            put("review_text", reviewText); put("private_feedback", privateFeedback)
        }
        api.post("v1/hospitality/requests/$requestId/reviews", body.toString(), token)
        return reviewState(requestId, token)
    }

    suspend fun publicReviews(globalId: GlobalId, token: String): List<HospitalityPublicReview> {
        val arr = JSONArray(api.get("v1/users/${globalId.value}/hospitality-reviews", token))
        return buildList {
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                add(HospitalityPublicReview(
                    reviewId = r.getString("review_id"), requestId = r.getString("request_id"),
                    authorGlobalId = GlobalId(r.getLong("author_global_id")), targetGlobalId = GlobalId(r.getLong("target_global_id")),
                    adequacy = r.getInt("adequacy"), rulesCompliance = r.getInt("rules_compliance"),
                    descriptionAccuracy = r.getInt("description_accuracy"), reviewScore = r.getDouble("review_score"),
                    reviewText = r.optNullableString("review_text"), submittedAt = r.getString("submitted_at"), publishedAt = r.getString("published_at"),
                ))
            }
        }
    }

    suspend fun reputation(globalId: GlobalId, token: String): HospitalityReputation {
        val r = JSONObject(api.get("v1/hospitality/reputation/${globalId.value}", token))
        return HospitalityReputation(
            globalId = GlobalId(r.getLong("global_id")), verifiedStaysAsHost = r.getInt("verified_stays_as_host"),
            verifiedStaysAsGuest = r.getInt("verified_stays_as_guest"), publishedReviews = r.getInt("published_reviews"),
            averageHostReview = r.optNullableDouble("average_host_review"), averageGuestReview = r.optNullableDouble("average_guest_review"),
            activeRestriction = r.optBoolean("active_restriction"), policyVersion = r.optString("policy_version", "hospitality-reputation-v1"),
        )
    }

    private fun parseHostProfile(json: String): HospitalityHostProfile {
        val r = JSONObject(json)
        return HospitalityHostProfile(
            hostGlobalId = r.optGlobalId("host_global_id"), isHostingActive = r.getBoolean("is_hosting_active"),
            maxGuests = r.getInt("max_guests"), maxDays = r.getInt("max_days"), cityId = r.optString("city_id"),
            cityValue = r.optNullableString("city_value"), publicAreaText = r.optNullableString("public_area_text"), timezoneName = r.getString("timezone_name"),
            sleepingCondition = sleeping(r.getString("sleeping_condition")), houseRules = r.optStringList("house_rules"),
            minRequiredRating = r.optDouble("min_required_rating", 0.0), requiredCompletedTests = r.optStringList("required_completed_tests"),
            availabilityMode = if (r.optString("availability_mode") == "calendar") HospitalityAvailabilityMode.CALENDAR else HospitalityAvailabilityMode.ALWAYS,
            privateLocation = r.optJSONObject("private_location")?.let { p -> HospitalityPrivateLocation(
                exactAddress = p.optString("exact_address"), arrivalInstructions = p.optString("arrival_instructions"),
                exactLat = p.optNullableDouble("exact_lat"), exactLon = p.optNullableDouble("exact_lon"), arrivalContact = p.optString("arrival_contact"),
            ) },
        )
    }

    private fun parsePublicHost(r: JSONObject) = HospitalityHostPublicSummary(
        hostGlobalId = GlobalId(r.getLong("host_global_id")), isHostingActive = r.getBoolean("is_hosting_active"),
        cityId = r.getString("city_id"), publicAreaText = r.optNullableString("public_area_text"),
        sleepingCondition = sleeping(r.getString("sleeping_condition")), maxGuests = r.getInt("max_guests"), maxDays = r.getInt("max_days"),
        houseRules = r.optStringList("house_rules"), minRequiredRating = r.getDouble("min_required_rating"),
        requiredCompletedTests = r.optStringList("required_completed_tests"),
        availabilityMode = if (r.optString("availability_mode") == "calendar") HospitalityAvailabilityMode.CALENDAR else HospitalityAvailabilityMode.ALWAYS,
    )

    private fun parseEligibility(r: JSONObject): HospitalityEligibility {
        val reasons = r.optJSONArray("reasons") ?: JSONArray()
        return HospitalityEligibility(
            eligible = r.getBoolean("eligible"), reasons = buildList { for (i in 0 until reasons.length()) add(reasons.getJSONObject(i).optString("code")) },
            accountRating = r.optDouble("account_rating"), minRequiredRating = r.optDouble("min_required_rating"),
            missingRequiredTests = r.optStringList("missing_required_tests"), dateAvailable = r.optBoolean("date_available"),
            capacityAvailable = r.optBoolean("capacity_available"), effectiveCapacity = r.optNullableInt("effective_capacity"),
            occupiedCapacity = r.optInt("occupied_capacity"), stayDays = r.optInt("stay_days", 1),
        )
    }

    private fun parseAvailabilityList(json: String): List<HospitalityAvailability> {
        val arr = JSONArray(json)
        return buildList { for (i in 0 until arr.length()) add(parseAvailability(arr.getJSONObject(i))) }
    }
    private fun parseAvailability(r: JSONObject) = HospitalityAvailability(
        availabilityId = r.getString("availability_id"), dateFrom = r.getString("date_from"), dateTo = r.getString("date_to"),
        state = if (r.getString("availability_state") == "unavailable") HospitalityAvailabilityState.UNAVAILABLE else HospitalityAvailabilityState.AVAILABLE,
        capacityOverride = r.optNullableInt("capacity_override"),
    )

    private fun parseRequests(json: String): List<StayRequest> {
        val arr = JSONArray(json)
        return buildList { for (i in 0 until arr.length()) add(parseRequest(arr.getJSONObject(i))) }
    }
    private fun parseRequest(r: JSONObject) = StayRequest(
        requestId = r.getString("request_id"), guestGlobalId = GlobalId(r.getLong("guest_global_id")), hostGlobalId = GlobalId(r.getLong("host_global_id")),
        checkInDate = r.getString("check_in_date"), checkOutDate = r.getString("check_out_date"), guestsCount = r.getInt("guests_count"),
        status = StayRequestStatus.entries.firstOrNull { it.wire == r.getString("status") } ?: StayRequestStatus.PENDING,
        responseDueAt = r.getString("response_due_at"), conversationId = r.get("conversation_id").toString(), version = r.getInt("version"),
        createdAt = r.getString("created_at"), updatedAt = r.getString("updated_at"), completedAt = r.optNullableString("completed_at"),
        reviewDeadlineAt = r.optNullableString("review_deadline_at"),
    )

    private fun parseVerification(r: JSONObject) = HospitalityVerification(
        requestId = r.getString("request_id"), verified = r.getBoolean("verified"), interactionId = r.optNullableString("interaction_id"),
        hostConfirmed = r.optBoolean("host_confirmed"), guestConfirmed = r.optBoolean("guest_confirmed"), blockedBy = r.optNullableString("blocked_by"),
    )

    private fun sleeping(wire: String) = HospitalitySleepingCondition.entries.firstOrNull { it.wire == wire } ?: HospitalitySleepingCondition.SOFA
    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
    private fun epochMs(value: String): Long = runCatching { OffsetDateTime.parse(value).toInstant().toEpochMilli() }.getOrDefault(0L)
}

private fun JSONObject.optStringList(key: String): List<String> {
    val arr = optJSONArray(key) ?: return emptyList()
    return buildList { for (i in 0 until arr.length()) add(arr.optString(i)) }
}
private fun JSONObject.optNullableString(key: String): String? = if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
private fun JSONObject.optNullableDouble(key: String): Double? = if (!has(key) || isNull(key)) null else optDouble(key)
private fun JSONObject.optNullableInt(key: String): Int? = if (!has(key) || isNull(key)) null else optInt(key)
private fun JSONObject.optGlobalId(key: String): GlobalId? = if (!has(key) || isNull(key)) null else runCatching { GlobalId(getLong(key)) }.getOrNull()
