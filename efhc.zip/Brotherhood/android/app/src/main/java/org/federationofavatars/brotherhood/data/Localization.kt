package org.federationofavatars.brotherhood.data

import android.content.Context
import org.federationofavatars.brotherhood.model.AppLanguage
import org.json.JSONObject

/**
 * Data-driven localization registry.
 *
 * RU/UK/EN source triplets remain a readable safety net, while all 13 active locales are loaded
 * from assets/i18n without adding a new enum member or branching across the application.
 */
class LanguageCatalog(context: Context) {
    private val appContext = context.applicationContext
    private val manifest: JSONObject = JSONObject(readAsset("i18n/languages.json"))
    val defaultTag: String = manifest.optString("default", "ru")
    private val requiredKeys: Set<String> by lazy {
        val root = JSONObject(readAsset("i18n/required_keys.json"))
        val rows = root.optJSONArray("required_keys")
        buildSet {
            if (rows != null) for (index in 0 until rows.length()) add(rows.getString(index))
        }
    }
    private val numerologyLocales: Set<String> by lazy {
        val root = JSONObject(readAsset("numerology/numerology_knowledge_v1.json"))
        val locales = root.getJSONObject("locales")
        buildSet { for (key in locales.keys()) add(key) }
    }
    val languages: List<AppLanguage> = buildList {
        val rows = manifest.getJSONArray("languages")
        for (index in 0 until rows.length()) {
            val row = rows.getJSONObject(index)
            if (!row.optBoolean("enabled", true)) continue
            val tag = row.getString("tag")
            val pack = loadPack(tag)
            if (!requiredKeys.all(pack::containsKey) || tag !in numerologyLocales) continue
            add(
                AppLanguage(
                    tag = tag,
                    nativeName = row.getString("native_name"),
                    direction = row.optString("direction", "ltr"),
                    translations = pack,
                )
            )
        }
    }

    fun language(tag: String?): AppLanguage =
        languages.firstOrNull { it.tag.equals(tag, ignoreCase = true) }
            ?: languages.firstOrNull { it.tag == defaultTag }
            ?: AppLanguage.RU

    private fun loadPack(tag: String): Map<String, String> = runCatching {
        val root = JSONObject(readAsset("i18n/$tag.json"))
        val messages = root.optJSONObject("messages") ?: JSONObject()
        buildMap {
            for (key in messages.keys()) put(key, messages.getString(key))
        }
    }.getOrDefault(emptyMap())

    private fun readAsset(path: String): String = appContext.assets.open(path).bufferedReader().use { it.readText() }
}

/**
 * Static RU/UK/EN source triplets stay readable in source. For every additional active locale
 * the English fallback text is the stable translation-memory lookup key.
 */
fun AppLanguage.pick(ru: String, uk: String, en: String): String = when (tag.lowercase()) {
    "ru" -> translations[en] ?: ru
    "uk" -> translations[en] ?: uk
    "en" -> translations[en] ?: en
    else -> translations[en] ?: en
}

fun AppLanguage.format(
    key: String,
    ru: String,
    uk: String,
    en: String,
    args: Map<String, String> = emptyMap(),
): String {
    val base = when (tag.lowercase()) {
        "ru" -> translations[key] ?: ru
        "uk" -> translations[key] ?: uk
        "en" -> translations[key] ?: en
        else -> translations[key] ?: translations[en] ?: en
    }
    return args.entries.fold(base) { acc, (name, value) -> acc.replace("{$name}", value) }
}
