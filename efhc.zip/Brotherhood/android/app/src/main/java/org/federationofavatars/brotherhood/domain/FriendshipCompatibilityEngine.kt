package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.FriendshipCompatibilityResult

object FriendshipCompatibilityEngine {
    fun calculate(
        myScores: Map<String, Int>,
        candidateScores: Map<String, Int>,
        sharedInterestPercent: Int,
        trustScore: Int
    ): FriendshipCompatibilityResult {
        val commonIds = myScores.keys.intersect(candidateScores.keys).filter { AssessmentCatalog.byId(it) != null }
        if (commonIds.isEmpty()) {
            return FriendshipCompatibilityResult(
                score = 0,
                testsScore = 0,
                commonTests = 0,
                confidence = 10,
                riskFlags = emptyList(),
                explanation = "Предварительный результат: общих психологических блоков пока нет.",
                categoryScores = emptyMap(),
                friendshipExpectationsScore = 0,
            )
        }

        val similarities = commonIds.associateWith { id ->
            100 - abs(myScores.getValue(id).coerceIn(0, 100) - candidateScores.getValue(id).coerceIn(0, 100))
        }
        val testsScore = similarities.values.average().roundToInt().coerceIn(0, 100)
        val categoryScores = commonIds.groupBy { AssessmentCatalog.byId(it)!!.kind.name.lowercase() }.mapValues { (_, ids) ->
            ids.map { similarities.getValue(it) }.average().roundToInt().coerceIn(0, 100)
        }
        return FriendshipCompatibilityResult(
            score = testsScore,
            testsScore = testsScore,
            commonTests = commonIds.size,
            confidence = (commonIds.size * 100 / AssessmentCatalog.REQUIRED_TEST_COUNT).coerceIn(10, 100),
            riskFlags = emptyList(),
            explanation = "Психологический слой сравнивает нормализованные результаты научных тестовых систем. Он не делит людей на хороших и плохих; Trust, нумерология и остальные слои рассчитываются отдельно.",
            categoryScores = categoryScores,
            friendshipExpectationsScore = 0, // retired v0.5.12 ID-bound diagnostic; user-authored qualities now cover expectations
        )
    }
}
