package org.federationofavatars.brotherhood.network

import org.federationofavatars.brotherhood.BuildConfig

/** Public API endpoint only. Database credentials must never be embedded in the APK. */
object ApiConfig {
    val baseUrl: String = BuildConfig.API_BASE_URL.trimEnd('/')
    val isConfigured: Boolean = baseUrl.startsWith("https://") && !baseUrl.contains("example.invalid")
}
