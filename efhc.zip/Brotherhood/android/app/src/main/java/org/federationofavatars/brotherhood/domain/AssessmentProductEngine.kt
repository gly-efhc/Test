package org.federationofavatars.brotherhood.domain

import java.time.Instant
import java.time.ZoneOffset
import kotlin.math.abs
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentKind
import org.federationofavatars.brotherhood.model.AssessmentResult

data class AssessmentModuleProgress(
    val kind: AssessmentKind,
    val title: String,
    val description: String,
    val completed: Int,
    val total: Int,
) {
    val progressPercent: Int get() = if (total == 0) 0 else (completed * 100 / total).coerceIn(0, 100)
}

data class PublicAssessmentResult(
    val assessmentId: String,
    val title: String,
    val moduleTitle: String,
    val summary: String,
    val characteristics: List<String>,
    val growthAreas: List<String>,
    val usefulContexts: List<String>,
    val completedAtEpochMs: Long,
    val modelVersion: String,
    val stimulusVersion: String,
    val inputCoveragePercent: Int,
)

/**
 * Product layer around the current assessment bank.
 *
 * It deliberately does not expose raw latent coordinates. The current owner directive permits a
 * future redesign of the assessment bank itself, but this recovery engine keeps the present source
 * mechanics intact while turning its existing results into a usable product flow.
 */
object AssessmentProductEngine {
    private val traitByKey = LatentTraitCatalog.traits.associateBy { it.key }

    fun modules(
        definitions: List<AssessmentDefinition>,
        completed: Map<String, AssessmentResult>,
        language: AppLanguage,
    ): List<AssessmentModuleProgress> = AssessmentKind.entries.map { kind ->
        val rows = definitions.filter { it.kind == kind }
        val done = rows.count { it.id in completed }
        AssessmentModuleProgress(
            kind = kind,
            title = moduleTitle(kind, language),
            description = moduleDescription(kind, language),
            completed = done,
            total = rows.size,
        )
    }

    fun moduleTitle(kind: AssessmentKind, language: AppLanguage): String = when (kind) {
        AssessmentKind.TRAITS_CORE -> language.pick("Черты и саморегуляция", "Риси та саморегуляція", "Traits & self-regulation")
        AssessmentKind.INTERPERSONAL_STYLE -> language.pick("Межличностный стиль", "Міжособистісний стиль", "Interpersonal style")
        AssessmentKind.COMMUNICATION_CONFLICT -> language.pick("Коммуникация и конфликт", "Комунікація та конфлікт", "Communication & conflict")
        AssessmentKind.TRUST_SUPPORT_BOUNDARIES -> language.pick("Доверие, поддержка и границы", "Довіра, підтримка та межі", "Trust, support & boundaries")
        AssessmentKind.DECISION_WORK_STYLE -> language.pick("Решения, риск и рабочий стиль", "Рішення, ризик і робочий стиль", "Decision, risk & work style")
        AssessmentKind.SOCIAL_GROUP_ROLE -> language.pick("Социальная энергия и роль в группе", "Соціальна енергія та роль у групі", "Social energy & group role")
        AssessmentKind.ADAPTABILITY_UNCERTAINTY -> language.pick("Адаптивность и неопределённость", "Адаптивність і невизначеність", "Adaptability & uncertainty")
    }


    fun moduleDescription(kind: AssessmentKind, language: AppLanguage): String = when (kind) {
        AssessmentKind.TRAITS_CORE -> language.pick("Устойчивые тенденции, организация поведения и саморегуляция.", "Стійкі тенденції, організація поведінки та саморегуляція.", "Stable tendencies, behavior organization and self-regulation.")
        AssessmentKind.INTERPERSONAL_STYLE -> language.pick("Автономия, агентность, кооперация и границы во взаимодействии.", "Автономія, агентність, кооперація та межі у взаємодії.", "Autonomy, agency, cooperation and boundaries in interaction.")
        AssessmentKind.COMMUNICATION_CONFLICT -> language.pick("Прямота, такт, ритм контакта и работа с разногласиями.", "Прямота, такт, ритм контакту та робота з розбіжностями.", "Directness, tact, contact rhythm and disagreement handling.")
        AssessmentKind.TRUST_SUPPORT_BOUNDARIES -> language.pick("Психологическое доверие, взаимность, поддержка и уважение автономии.", "Психологічна довіра, взаємність, підтримка та повага автономії.", "Psychological trust, reciprocity, support and autonomy.")
        AssessmentKind.DECISION_WORK_STYLE -> language.pick("Планирование, решения, риск, исполнение и сотрудничество.", "Планування, рішення, ризик, виконання та співпраця.", "Planning, decisions, risk, execution and collaboration.")
        AssessmentKind.SOCIAL_GROUP_ROLE -> language.pick("Групповая вовлечённость, лидерство, кооперация и инициатива.", "Групова залученість, лідерство, кооперація та ініціатива.", "Group engagement, leadership, cooperation and initiative.")
        AssessmentKind.ADAPTABILITY_UNCERTAINTY -> language.pick("Гибкость, устойчивость и поведение при изменении условий.", "Гнучкість, стійкість і поведінка за зміни умов.", "Flexibility, resilience and behavior under changing conditions.")
    }


    fun publicResult(
        definition: AssessmentDefinition,
        result: AssessmentResult,
        language: AppLanguage,
    ): PublicAssessmentResult {
        val interpreted = result.dimensions
            .mapNotNull { score -> traitByKey[score.id]?.let { definition -> score to definition } }
            .sortedByDescending { (score, _) -> abs(score.score - 50) }

        val characteristics = interpreted.take(4).map { (score, trait) ->
            when {
                score.score >= 67 -> trait.highPositive.get(language)
                score.score <= 33 -> trait.lowPositive.get(language)
                else -> trait.balancedPositive.get(language)
            }
        }.distinct()

        val growth = interpreted
            .filter { (score, _) -> abs(score.score - 50) >= 18 }
            .take(3)
            .map { (_, trait) -> trait.balancedPositive.get(language) }
            .filterNot(characteristics::contains)
            .distinct()

        val module = moduleTitle(definition.kind, language)
        val number = definition.id.removePrefix("f").toIntOrNull()?.toString() ?: definition.id
        val summary = language.pick(
            "Серия завершена. Она уточнила ваш текущий профиль в модуле «$module». Результат описывает тенденции текущей версии модели, а не неизменную характеристику человека.",
            "Серію завершено. Вона уточнила ваш поточний профіль у модулі «$module». Результат описує тенденції поточної версії моделі, а не незмінну характеристику людини.",
            "Series completed. It refined your current profile in the “$module” module. The result describes tendencies of the current model version, not an immutable property of a person.",
        )
        return PublicAssessmentResult(
            assessmentId = result.assessmentId,
            title = language.pick("Результат серии №$number", "Результат серії №$number", "Series #$number result"),
            moduleTitle = module,
            summary = summary,
            characteristics = characteristics.ifEmpty {
                listOf(language.pick("Профиль в этом модуле стал точнее", "Профіль у цьому модулі став точнішим", "Your profile in this module is now more precise"))
            },
            growthAreas = growth,
            usefulContexts = usefulContexts(definition.kind, language),
            completedAtEpochMs = result.completedAtEpochMs,
            modelVersion = result.modelVersion,
            stimulusVersion = result.stimulusVersion,
            inputCoveragePercent = 100,
        )
    }

    /** Canonical retake cadence from owner Q15: once per month. Calendar month is evaluated in UTC. */
    fun retakeAvailableAtEpochMs(result: AssessmentResult): Long =
        Instant.ofEpochMilli(result.completedAtEpochMs)
            .atZone(ZoneOffset.UTC)
            .plusMonths(1)
            .toInstant()
            .toEpochMilli()

    fun canRetake(result: AssessmentResult, nowEpochMs: Long = System.currentTimeMillis()): Boolean =
        nowEpochMs >= retakeAvailableAtEpochMs(result)

    private fun usefulContexts(kind: AssessmentKind, language: AppLanguage): List<String> = when (kind) {
        AssessmentKind.COMMUNICATION_CONFLICT, AssessmentKind.TRUST_SUPPORT_BOUNDARIES, AssessmentKind.INTERPERSONAL_STYLE -> listOf(language.pick("Дружба","Дружба","Friendship"), language.pick("Общение","Спілкування","Communication"), language.pick("Команда","Команда","Team"))
        AssessmentKind.DECISION_WORK_STYLE, AssessmentKind.SOCIAL_GROUP_ROLE -> listOf(language.pick("Проекты","Проєкти","Projects"), language.pick("Работа","Робота","Work"), language.pick("Партнёрство","Партнерство","Partnership"))
        else -> listOf(language.pick("Дружба","Дружба","Friendship"), language.pick("Совместные дела","Спільні справи","Shared activities"), language.pick("Команда","Команда","Team"))
    }

}
