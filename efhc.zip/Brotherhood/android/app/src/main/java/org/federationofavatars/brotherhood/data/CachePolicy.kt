package org.federationofavatars.brotherhood.data

/** Canonical offline-first cache windows for Brotherhood v0.5.7. */
object CachePolicy {
    const val PROFILE_TTL_MS = 24L * 60 * 60 * 1000
    const val PEOPLE_SEARCH_TTL_MS = 30L * 60 * 1000
    const val COMMUNITIES_TTL_MS = 60L * 60 * 1000
    const val TRUST_SUMMARY_TTL_MS = 15L * 60 * 1000
    const val STATIC_CATALOG_TTL_MS = 30L * 24 * 60 * 60 * 1000
    const val STALE_WHILE_REVALIDATE_MS = 7L * 24 * 60 * 60 * 1000
    const val MAX_PENDING_MUTATION_ATTEMPTS = 12
}
