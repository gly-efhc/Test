package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.IntegrityScreeningResult

/** Internal-only consistency signal. It must never be rendered as a negative judgement of a user. */
object CrossTestIntegrityAnalyzer {
    fun analyze(results: Map<String, AssessmentResult>): IntegrityScreeningResult {
        if (results.size < 2) return IntegrityScreeningResult(0, 0, 0, 0, "internal", emptyList())
        val grouped = results.values.flatMap { result -> result.dimensions.map { it.id to it.score } }.groupBy({ it.first }, { it.second })
        val comparable = grouped.values.filter { it.size >= 2 }
        val dispersion = comparable.map { scores ->
            val mean = scores.average()
            scores.map { abs(it - mean) }.average()
        }
        val consistency = if (dispersion.isEmpty()) 50 else (100.0 - dispersion.average() * 2.0).roundToInt().coerceIn(0, 100)
        val confidence = (comparable.size * 8).coerceIn(0, 100)
        return IntegrityScreeningResult(
            riskScore = 0,
            consistencyScore = consistency,
            evaluatedPairs = comparable.size,
            confidence = confidence,
            label = "internal",
            flags = emptyList(),
        )
    }
}
