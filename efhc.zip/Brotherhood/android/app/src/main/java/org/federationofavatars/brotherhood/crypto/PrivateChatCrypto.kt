package org.federationofavatars.brotherhood.crypto

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import org.federationofavatars.brotherhood.model.ChatAttachmentKind
import org.federationofavatars.brotherhood.model.DeviceKeyBundle
import org.federationofavatars.brotherhood.model.EncryptedAttachmentPayload
import org.federationofavatars.brotherhood.model.EncryptedDirectPayload
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.PendingChatAttachment
import org.json.JSONObject

/**
 * Brotherhood Private Chat E2EE v1.
 *
 * - EC P-256 identity and signed prekey are generated on-device.
 * - The server receives public keys only.
 * - First-contact session secret is established by ephemeral ECDH against the recipient prekey.
 * - Each direction has an independent HMAC-SHA256 hash ratchet.
 * - Message and attachment content is AES-256-GCM encrypted before leaving Android.
 * - Session/private key material is wrapped by an AES key held in Android Keystore.
 *
 * This is an application E2EE protocol built from standard primitives. It is intentionally versioned
 * and must receive an independent cryptographic audit before being represented as equivalent to a
 * mature externally audited protocol such as Telegram Secret Chats or Signal Double Ratchet.
 */
class PrivateChatCrypto(context: Context, private val myGlobalId: GlobalId) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("brotherhood_e2ee_v1", Context.MODE_PRIVATE)
    private val random = SecureRandom()
    private val box = LocalSecretBox()

    data class LocalBundle(
        val deviceId: String,
        val identityPublicB64: String,
        val prekeyId: String,
        val prekeyPublicB64: String,
        val prekeySignatureB64: String,
    )

    private data class SessionState(
        val peerGlobalId: Long,
        var sendChain: ByteArray,
        var receiveChain: ByteArray,
        var sendCounter: Int,
        var receiveCounter: Int,
        val keyId: String,
    )

    fun localPublicBundle(): LocalBundle {
        ensureIdentityMaterial()
        return LocalBundle(
            deviceId = prefs.getString("device_id", null)!!,
            identityPublicB64 = prefs.getString("identity_public", null)!!,
            prekeyId = prefs.getString("prekey_id", null)!!,
            prekeyPublicB64 = prefs.getString("prekey_public", null)!!,
            prekeySignatureB64 = prefs.getString("prekey_signature", null)!!,
        )
    }

    fun fingerprint(): String {
        val bytes = b64d(localPublicBundle().identityPublicB64)
        return MessageDigest.getInstance("SHA-256").digest(bytes)
            .take(16).joinToString(":") { "%02X".format(it) }
    }

    fun verifyPeerBundle(bundle: DeviceKeyBundle): Boolean = runCatching {
        val identityPublic = decodePublic(bundle.identityPublicKeyB64)
        val signature = Signature.getInstance("SHA256withECDSA")
        signature.initVerify(identityPublic)
        signature.update(b64d(bundle.prekeyPublicKeyB64))
        signature.verify(b64d(bundle.prekeySignatureB64))
    }.getOrDefault(false)

    /**
     * Trust-on-first-use identity pinning. The server may distribute public keys, but after the first
     * successful contact it cannot silently replace a peer identity key without the Android client
     * stopping the session and asking the users to re-verify fingerprints.
     */
    fun verifyAndPinPeer(bundle: DeviceKeyBundle): Boolean {
        if (!verifyPeerBundle(bundle)) return false
        val key = "peer_identity:${bundle.globalId.value}"
        val pinned = prefs.getString(key, null)
        if (pinned == null) {
            prefs.edit().putString(key, bundle.identityPublicKeyB64).apply()
            return true
        }
        return MessageDigest.isEqual(b64d(pinned), b64d(bundle.identityPublicKeyB64))
    }

    fun peerFingerprint(bundle: DeviceKeyBundle): String = MessageDigest.getInstance("SHA-256")
        .digest(b64d(bundle.identityPublicKeyB64)).take(16).joinToString(":") { "%02X".format(it) }

    fun encrypt(
        conversationId: String,
        peer: DeviceKeyBundle,
        plaintext: String,
        attachments: List<PendingChatAttachment> = emptyList(),
    ): EncryptedDirectPayload {
        require(verifyAndPinPeer(peer)) { "Peer E2EE identity changed or prekey signature is invalid" }
        var state = loadSession(conversationId)
        var ephemeralPublic: String? = null
        var recipientPrekeyId: String? = null
        if (state == null) {
            val ephemeral = generateEcPair()
            val shared = ecdh(ephemeral.private, decodePublic(peer.prekeyPublicKeyB64))
            val root = hkdf(shared, "Brotherhood-E2EE-v1|$conversationId".toByteArray(), 32)
            state = SessionState(
                peerGlobalId = peer.globalId.value,
                sendChain = hkdf(root, "sender:${myGlobalId.value}".toByteArray(), 32),
                receiveChain = hkdf(root, "sender:${peer.globalId.value}".toByteArray(), 32),
                sendCounter = 0,
                receiveCounter = 0,
                keyId = "e2ee1-${sha256Short(root)}",
            )
            ephemeralPublic = b64(ephemeral.public.encoded)
            recipientPrekeyId = peer.prekeyId
        }
        require(state.peerGlobalId == peer.globalId.value) { "Conversation peer mismatch" }

        val counter = state.sendCounter
        val messageKey = hmac(state.sendChain, "message-key".toByteArray())
        val nextChain = hmac(state.sendChain, "chain-step".toByteArray())
        val aad = aad(conversationId, counter, myGlobalId.value)
        val encrypted = aesGcmEncrypt(messageKey, plaintext.toByteArray(StandardCharsets.UTF_8), aad)
        rememberMessageKey(conversationId, myGlobalId.value, counter, messageKey)

        val encryptedAttachments = attachments.map { attachment ->
            val attachmentKey = hmac(messageKey, "attachment:${attachment.clientAttachmentId}".toByteArray())
            val encryptedAttachment = aesGcmEncrypt(attachmentKey, attachment.bytes, aad)
            EncryptedAttachmentPayload(
                clientAttachmentId = attachment.clientAttachmentId,
                kind = attachment.kind,
                mimeType = attachment.mimeType,
                fileName = attachment.fileName,
                byteSize = encryptedAttachment.second.size,
                dataB64 = b64(encryptedAttachment.second),
                nonceB64 = b64(encryptedAttachment.first),
            )
        }

        state.sendChain = nextChain
        state.sendCounter += 1
        saveSession(conversationId, state)
        return EncryptedDirectPayload(
            ciphertextB64 = b64(encrypted.second),
            nonceB64 = b64(encrypted.first),
            keyId = state.keyId,
            ratchetCounter = counter,
            senderEphemeralPublicKeyB64 = ephemeralPublic,
            recipientPrekeyId = recipientPrekeyId,
            attachments = encryptedAttachments,
        )
    }

    fun decrypt(
        conversationId: String,
        senderGlobalId: GlobalId,
        ciphertextB64: String,
        nonceB64: String,
        counter: Int,
        senderEphemeralPublicKeyB64: String?,
        recipientPrekeyId: String?,
    ): String {
        val cachedBeforeSession = loadMessageKey(conversationId, senderGlobalId.value, counter)
        if (cachedBeforeSession != null) {
            val plain = aesGcmDecrypt(cachedBeforeSession, b64d(nonceB64), b64d(ciphertextB64), aad(conversationId, counter, senderGlobalId.value))
            return plain.toString(StandardCharsets.UTF_8)
        }
        var state = loadSession(conversationId)
        if (state == null) {
            require(!senderEphemeralPublicKeyB64.isNullOrBlank()) { "Missing E2EE session bootstrap" }
            ensureIdentityMaterial()
            val ownPrekeyId = prefs.getString("prekey_id", null)!!
            require(recipientPrekeyId == ownPrekeyId) { "Message targets an unknown prekey" }
            val prekeyPrivate = decodePrivate(box.openString(prefs.getString("prekey_private", null)!!))
            val shared = ecdh(prekeyPrivate, decodePublic(senderEphemeralPublicKeyB64))
            val root = hkdf(shared, "Brotherhood-E2EE-v1|$conversationId".toByteArray(), 32)
            state = SessionState(
                peerGlobalId = senderGlobalId.value,
                sendChain = hkdf(root, "sender:${myGlobalId.value}".toByteArray(), 32),
                receiveChain = hkdf(root, "sender:${senderGlobalId.value}".toByteArray(), 32),
                sendCounter = 0,
                receiveCounter = 0,
                keyId = "e2ee1-${sha256Short(root)}",
            )
        }
        require(state.peerGlobalId == senderGlobalId.value) { "Conversation peer mismatch" }

        val cached = loadMessageKey(conversationId, senderGlobalId.value, counter)
        val messageKey: ByteArray
        if (cached != null) {
            messageKey = cached
        } else {
            require(counter >= state.receiveCounter) { "Old ratchet key is unavailable on this device" }
            require(counter - state.receiveCounter <= 200) { "Ratchet jump is too large" }
            while (state.receiveCounter < counter) {
                state.receiveChain = hmac(state.receiveChain, "chain-step".toByteArray())
                state.receiveCounter += 1
            }
            messageKey = hmac(state.receiveChain, "message-key".toByteArray())
            rememberMessageKey(conversationId, senderGlobalId.value, counter, messageKey)
            state.receiveChain = hmac(state.receiveChain, "chain-step".toByteArray())
            state.receiveCounter = counter + 1
            saveSession(conversationId, state)
        }
        val plain = aesGcmDecrypt(messageKey, b64d(nonceB64), b64d(ciphertextB64), aad(conversationId, counter, senderGlobalId.value))
        return plain.toString(StandardCharsets.UTF_8)
    }

    fun decryptAttachment(
        conversationId: String,
        senderGlobalId: GlobalId,
        counter: Int,
        clientAttachmentId: String,
        nonceB64: String,
        ciphertextB64: String,
    ): ByteArray {
        val messageKey = loadMessageKey(conversationId, senderGlobalId.value, counter)
            ?: error("Message key is not available; decrypt the parent message first")
        val attachmentKey = hmac(messageKey, "attachment:$clientAttachmentId".toByteArray())
        return aesGcmDecrypt(attachmentKey, b64d(nonceB64), b64d(ciphertextB64), aad(conversationId, counter, senderGlobalId.value))
    }

    private fun ensureIdentityMaterial() {
        if (prefs.contains("identity_public") && prefs.contains("prekey_public")) return
        val identity = generateEcPair()
        val prekey = generateEcPair()
        val signature = Signature.getInstance("SHA256withECDSA").run {
            initSign(identity.private, random)
            update(prekey.public.encoded)
            sign()
        }
        val deviceId = "android-${randomBytes(12).joinToString("") { "%02x".format(it) }}"
        val prekeyId = "pk-${randomBytes(8).joinToString("") { "%02x".format(it) }}"
        prefs.edit()
            .putString("device_id", deviceId)
            .putString("identity_public", b64(identity.public.encoded))
            .putString("identity_private", box.sealString(b64(identity.private.encoded)))
            .putString("prekey_id", prekeyId)
            .putString("prekey_public", b64(prekey.public.encoded))
            .putString("prekey_private", box.sealString(b64(prekey.private.encoded)))
            .putString("prekey_signature", b64(signature))
            .apply()
    }

    private fun loadSession(conversationId: String): SessionState? {
        val sealed = prefs.getString("session:$conversationId", null) ?: return null
        val json = JSONObject(box.openString(sealed))
        return SessionState(
            peerGlobalId = json.getLong("peer"),
            sendChain = b64d(json.getString("send")),
            receiveChain = b64d(json.getString("recv")),
            sendCounter = json.getInt("sendCounter"),
            receiveCounter = json.getInt("recvCounter"),
            keyId = json.getString("keyId"),
        )
    }

    private fun saveSession(conversationId: String, state: SessionState) {
        val json = JSONObject()
            .put("peer", state.peerGlobalId)
            .put("send", b64(state.sendChain))
            .put("recv", b64(state.receiveChain))
            .put("sendCounter", state.sendCounter)
            .put("recvCounter", state.receiveCounter)
            .put("keyId", state.keyId)
        prefs.edit().putString("session:$conversationId", box.sealString(json.toString())).apply()
    }

    private fun rememberMessageKey(conversationId: String, senderGlobalId: Long, counter: Int, key: ByteArray) {
        prefs.edit().putString("mk:$conversationId:$senderGlobalId:$counter", box.sealString(b64(key))).apply()
    }

    private fun loadMessageKey(conversationId: String, senderGlobalId: Long, counter: Int): ByteArray? =
        prefs.getString("mk:$conversationId:$senderGlobalId:$counter", null)?.let { b64d(box.openString(it)) }

    private fun generateEcPair(): KeyPair = KeyPairGenerator.getInstance("EC").run {
        initialize(ECGenParameterSpec("secp256r1"), random)
        generateKeyPair()
    }

    private fun decodePublic(encoded: String): PublicKey = KeyFactory.getInstance("EC")
        .generatePublic(X509EncodedKeySpec(b64d(encoded)))

    private fun decodePrivate(encodedB64: String): PrivateKey = KeyFactory.getInstance("EC")
        .generatePrivate(PKCS8EncodedKeySpec(b64d(encodedB64)))

    private fun ecdh(privateKey: PrivateKey, publicKey: PublicKey): ByteArray = KeyAgreement.getInstance("ECDH").run {
        init(privateKey)
        doPhase(publicKey, true)
        generateSecret()
    }

    private fun hkdf(ikm: ByteArray, info: ByteArray, length: Int): ByteArray {
        val salt = ByteArray(32)
        val prk = hmacWithKey(salt, ikm)
        var previous = ByteArray(0)
        val output = ArrayList<Byte>()
        var counter = 1
        while (output.size < length) {
            val input = previous + info + byteArrayOf(counter.toByte())
            previous = hmacWithKey(prk, input)
            output.addAll(previous.toList())
            counter++
        }
        return output.take(length).toByteArray()
    }

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray = hmacWithKey(key, data)

    private fun hmacWithKey(key: ByteArray, data: ByteArray): ByteArray = Mac.getInstance("HmacSHA256").run {
        init(SecretKeySpec(key, "HmacSHA256"))
        doFinal(data)
    }

    private fun aesGcmEncrypt(key: ByteArray, plaintext: ByteArray, aad: ByteArray): Pair<ByteArray, ByteArray> {
        val nonce = randomBytes(12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        cipher.updateAAD(aad)
        return nonce to cipher.doFinal(plaintext)
    }

    private fun aesGcmDecrypt(key: ByteArray, nonce: ByteArray, ciphertext: ByteArray, aad: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        cipher.updateAAD(aad)
        return cipher.doFinal(ciphertext)
    }

    private fun aad(conversationId: String, counter: Int, sender: Long): ByteArray =
        "$conversationId|$counter|$sender|Brotherhood-E2EE-v1".toByteArray(StandardCharsets.UTF_8)

    private fun randomBytes(size: Int) = ByteArray(size).also(random::nextBytes)
    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
    private fun b64d(value: String) = Base64.decode(value, Base64.NO_WRAP)
    private fun sha256Short(value: ByteArray) = MessageDigest.getInstance("SHA-256").digest(value).take(6).joinToString("") { "%02x".format(it) }

    private inner class LocalSecretBox {
        private val alias = "brotherhood_local_secret_v1"

        private fun key(): SecretKey {
            val store = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            (store.getKey(alias, null) as? SecretKey)?.let { return it }
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            generator.init(
                KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            return generator.generateKey()
        }

        fun sealString(value: String): String {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
            return b64(cipher.iv + encrypted)
        }

        fun openString(value: String): String {
            val all = b64d(value)
            require(all.size > 12) { "Invalid local secret" }
            val nonce = all.copyOfRange(0, 12)
            val encrypted = all.copyOfRange(12, all.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
            return cipher.doFinal(encrypted).toString(StandardCharsets.UTF_8)
        }
    }
}
