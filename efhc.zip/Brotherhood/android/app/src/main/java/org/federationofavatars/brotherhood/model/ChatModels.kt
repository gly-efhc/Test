package org.federationofavatars.brotherhood.model

enum class ConversationKind { DIRECT, GROUP, COMMUNITY }
enum class ChatEncryptionMode { E2EE, SERVER }
enum class ChatAttachmentKind { IMAGE, AUDIO, VIDEO, FILE }

data class DeviceKeyBundle(
    val globalId: GlobalId,
    val deviceId: String,
    val identityPublicKeyB64: String,
    val prekeyId: String,
    val prekeyPublicKeyB64: String,
    val prekeySignatureB64: String,
    val createdAtEpochMs: Long = 0,
)

data class GroupMember(
    val globalId: GlobalId,
    val role: String,
)

data class ConversationSummaryModel(
    val id: String,
    val kind: ConversationKind,
    val title: String,
    val peerGlobalId: GlobalId?,
    val memberCount: Int,
    val encryptionMode: ChatEncryptionMode,
    val lastMessagePreview: String,
    val lastMessageAtEpochMs: Long?,
    val unreadCount: Int,
)

data class ChatAttachment(
    val id: String,
    val clientAttachmentId: String,
    val kind: ChatAttachmentKind,
    val mimeType: String,
    val fileName: String,
    val byteSize: Int,
    val nonceB64: String? = null,
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderGlobalId: GlobalId,
    val clientMessageId: String,
    val messageType: String,
    val encryptionMode: ChatEncryptionMode,
    val body: String?,
    val ciphertextB64: String?,
    val nonceB64: String?,
    val keyId: String?,
    val ratchetCounter: Int?,
    val senderEphemeralPublicKeyB64: String?,
    val recipientPrekeyId: String?,
    val replyToMessageId: String? = null,
    val attachments: List<ChatAttachment>,
    val status: String,
    val createdAtEpochMs: Long,
    val editedAtEpochMs: Long? = null,
    val reactions: Map<String, Int> = emptyMap(),
    val deliveredCount: Int = 0,
    val readCount: Int = 0,
    val decryptedBody: String? = body,
)

data class PendingChatAttachment(
    val clientAttachmentId: String,
    val kind: ChatAttachmentKind,
    val mimeType: String,
    val fileName: String,
    val bytes: ByteArray,
)

data class EncryptedAttachmentPayload(
    val clientAttachmentId: String,
    val kind: ChatAttachmentKind,
    val mimeType: String,
    val fileName: String,
    val byteSize: Int,
    val dataB64: String,
    val nonceB64: String,
)

data class EncryptedDirectPayload(
    val ciphertextB64: String,
    val nonceB64: String,
    val keyId: String,
    val ratchetCounter: Int,
    val senderEphemeralPublicKeyB64: String?,
    val recipientPrekeyId: String?,
    val attachments: List<EncryptedAttachmentPayload>,
)

data class AppUpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val minSupportedVersionCode: Int,
    val playUrl: String?,
    val testDownloadUrl: String?,
    val releaseNotes: String,
) {
    fun isNewerThan(currentVersionCode: Int): Boolean = versionCode > currentVersionCode
    fun isRequiredFor(currentVersionCode: Int): Boolean = currentVersionCode < minSupportedVersionCode
}
