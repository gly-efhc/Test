package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.LatentProfile
import org.federationofavatars.brotherhood.model.PositiveAssessmentReveal

/** Public-safe projection. Raw coordinates and low-fit interpretations stay private. */
object PositiveProfileProjector {
    fun topQualities(profile: LatentProfile, language: AppLanguage, limit: Int = 6): List<String> {
        if (profile.traits.isEmpty()) return emptyList()
        val ranked = LatentTraitCatalog.qualities.mapNotNull { quality ->
            val rows = quality.targets.mapNotNull targetRows@ { target ->
                val trait = profile.traits[target.traitKey] ?: return@targetRows null
                val closeness = 100 - abs(trait.score - target.targetScore)
                Triple(closeness, target.weight, trait.evidence)
            }
            if (rows.isEmpty()) return@mapNotNull null
            val weight = rows.sumOf { it.second }.coerceAtLeast(1)
            val closeness = (rows.sumOf { it.first * it.second }.toDouble() / weight).roundToInt()
            val evidence = (rows.sumOf { it.third * it.second }.toDouble() / weight).roundToInt()
            Triple(quality.label.get(language), closeness, evidence)
        }.sortedWith(compareByDescending<Triple<String, Int, Int>> { it.second }.thenByDescending { it.third })

        val confident = ranked.filter { it.second >= 58 }
        return (confident.ifEmpty { ranked })
            .map { it.first }
            .distinct()
            .take(limit)
    }

    fun reveal(
        assessmentId: String,
        before: LatentProfile,
        after: LatentProfile,
        language: AppLanguage,
        completedTests: Int,
        isRetake: Boolean,
    ): PositiveAssessmentReveal {
        val beforeLabels = topQualities(before, language, 12).toSet()
        val afterLabels = topQualities(after, language, 12)
        val newlyRevealed = afterLabels.filterNot(beforeLabels::contains).take(3)
        val display = (newlyRevealed.ifEmpty { afterLabels.take(3) }).ifEmpty {
            listOf(language.pick("Профиль становится точнее", "Профіль стає точнішим", "Your profile is becoming more precise"))
        }
        val isNew = !isRetake && newlyRevealed.isNotEmpty()
        val summary = when {
            isNew -> language.pick(
                "Новый научный тест уточнил выраженные особенности вашего стиля. Результат используется для психологического профиля и совместимости.",
                "Новий науковий тест уточнив виражені особливості вашого стилю. Результат використовується для психологічного профілю та сумісності.",
                "This scientific test refined the expressed features of your style. The result is used for the psychological profile and compatibility.",
            )
            isRetake -> language.pick(
                "Ваш профиль уточнён. Повторное прохождение не увеличивает рейтинг аккаунта повторно, но делает внутренний подбор стабильнее.",
                "Ваш профіль уточнено. Повторне проходження не збільшує рейтинг акаунта вдруге, але робить внутрішній добір стабільнішим.",
                "Your profile has been refined. A retake does not add account points again, but it makes internal matching more stable.",
            )
            else -> language.pick(
                "Тест добавил новые данные и уточнил психологический профиль.",
                "Тест додав нові дані та уточнив психологічний профіль.",
                "The test added new evidence and refined the psychological profile.",
            )
        }
        return PositiveAssessmentReveal(
            assessmentId = assessmentId,
            qualityLabels = display,
            summary = summary,
            usefulContexts = listOf(
                language.pick("Дружба", "Дружба", "Friendship"),
                language.pick("Командная работа", "Командна робота", "Teamwork"),
                language.pick("Совместные проекты", "Спільні проєкти", "Shared projects"),
            ),
            isNewDiscovery = isNew,
            completedTests = completedTests.coerceIn(0, org.federationofavatars.brotherhood.data.AssessmentCatalog.REQUIRED_TEST_COUNT),
            profileCoveragePercent = after.confidence.coerceIn(0, 100),
            accountDeltaPercent = if (isRetake) 0.0 else org.federationofavatars.brotherhood.data.AssessmentCatalog.ACCOUNT_POINTS_PER_TEST,
        )
    }

    fun history(results: Collection<AssessmentResult>, language: AppLanguage, limit: Int = 12): List<PositiveAssessmentReveal> {
        val ordered = results.sortedBy(AssessmentResult::completedAtEpochMs)
        val accumulated = linkedMapOf<String, AssessmentResult>()
        val output = mutableListOf<PositiveAssessmentReveal>()
        ordered.forEach { result ->
            val before = LatentProfileEngine.build(accumulated.values)
            accumulated[result.assessmentId] = result
            val after = LatentProfileEngine.build(accumulated.values)
            output += reveal(result.assessmentId, before, after, language, accumulated.size, false)
        }
        return output.takeLast(limit).reversed()
    }
}
