package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.AccountRatingBreakdown

object AccountRatingCalculator {
    const val PROFILE_SECTION_COUNT = 10
    const val PROFILE_POINTS_PER_SECTION = 5.0

    fun calculate(completedProfileSections: Int, completedAssessmentIds: Set<String>): AccountRatingBreakdown {
        val profileDone = completedProfileSections.coerceIn(0, PROFILE_SECTION_COUNT)
        val validTests = completedAssessmentIds.intersect(AssessmentCatalog.assessments.map { it.id }.toSet())
        val testDone = validTests.size.coerceAtMost(AssessmentCatalog.REQUIRED_TEST_COUNT)
        val profilePoints = profileDone * PROFILE_POINTS_PER_SECTION
        val testPoints = testDone * AssessmentCatalog.ACCOUNT_POINTS_PER_TEST
        return AccountRatingBreakdown(
            total = (profilePoints + testPoints).coerceIn(0.0, 100.0),
            profilePoints = profilePoints,
            testPoints = testPoints,
            completedProfileSections = profileDone,
            totalProfileSections = PROFILE_SECTION_COUNT,
            completedTests = testDone,
            totalTests = AssessmentCatalog.REQUIRED_TEST_COUNT
        )
    }
}
