package org.federationofavatars.brotherhood.domain

import java.time.Instant
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.LatentProfile
import org.federationofavatars.brotherhood.model.UserProfile

data class PsychologicalDimensionView(
    val key: String,
    val title: String,
    val interpretation: String,
    val score: Int,
    val evidence: Int,
)

data class PsychologicalProfileView(
    val version: String,
    val completedAssessments: Int,
    val coveragePercent: Int,
    val dimensions: List<PsychologicalDimensionView>,
    val strengths: List<String>,
    val growthAreas: List<String>,
    val incompleteData: List<String>,
)

data class PsychologicalAnalysisSection(
    val key: String,
    val title: String,
    val body: String,
)

data class PsychologicalAnalysisView(
    val version: String,
    val summary: String,
    val sections: List<PsychologicalAnalysisSection>,
    val strengths: List<String>,
    val growthAreas: List<String>,
    val limitations: List<String>,
)

data class PsychologicalReportSnapshot(
    val reportVersion: String,
    val modelVersion: String,
    val createdAtEpochMs: Long,
    val completedAssessmentIds: List<String>,
    val coveragePercent: Int,
    val summary: String,
    val sections: List<PsychologicalAnalysisSection>,
    val strengths: List<String>,
    val growthAreas: List<String>,
    val limitations: List<String>,
)

/**
 * Deterministic public psychological product projection over the active latent assessment profile.
 *
 * No clinical diagnosis is produced. Raw latent coordinates remain internal; the public view uses
 * the already-approved positive/balanced trait vocabulary. The same fixed input and model version
 * produce the same profile/analysis text. Report creation time is metadata only.
 */
object PsychologicalProductEngine {
    const val PROFILE_VERSION = "psychological-profile-v1"
    const val ANALYSIS_VERSION = "psychological-analysis-v1"
    const val REPORT_VERSION = "psychological-report-v1"

    private val traitByKey = LatentTraitCatalog.byKey

    private val communicationKeys = setOf("directness", "tact", "social_energy", "contact_intensity", "response_urgency", "vulnerability_comfort")
    private val conflictKeys = setOf("conflict_engagement", "forgiveness", "self_control", "assertiveness", "boundary_respect", "fairness")
    private val trustKeys = setOf("trust_openness", "confidentiality", "reciprocity", "support_availability", "empathy", "boundary_respect")
    private val decisionKeys = setOf("decisiveness", "planning", "risk_tolerance", "ambiguity_tolerance", "cautiousness", "independence")
    private val groupKeys = setOf("group_orientation", "leadership_orientation", "cooperation", "competitiveness", "initiative", "social_energy")
    private val workKeys = setOf("dependability", "planning", "perseverance", "attention_to_detail", "initiative", "innovation", "achievement_orientation", "adaptability")
    private val friendshipKeys = setOf("reciprocity", "support_availability", "empathy", "contact_intensity", "boundary_respect", "forgiveness", "vulnerability_comfort")
    private val stressKeys = setOf("stress_tolerance", "ambiguity_tolerance", "self_control", "adaptability", "optimism")

    fun profile(results: Map<String, AssessmentResult>, language: AppLanguage): PsychologicalProfileView {
        val latent = LatentProfileEngine.build(results.values)
        val dimensions = latent.traits.values
            .mapNotNull { score ->
                val definition = traitByKey[score.key] ?: return@mapNotNull null
                PsychologicalDimensionView(
                    key = score.key,
                    title = publicTitle(score.key, language),
                    interpretation = when {
                        score.score >= 67 -> definition.highPositive.get(language)
                        score.score <= 33 -> definition.lowPositive.get(language)
                        else -> definition.balancedPositive.get(language)
                    },
                    score = score.score,
                    evidence = score.evidence,
                )
            }
            .sortedWith(compareByDescending<PsychologicalDimensionView> { kotlin.math.abs(it.score - 50) }.thenByDescending { it.evidence })

        val strengths = dimensions.take(8).map { it.interpretation }.distinct()
        val growth = dimensions
            .filter { kotlin.math.abs(it.score - 50) >= 20 }
            .take(5)
            .mapNotNull { row -> traitByKey[row.key]?.balancedPositive?.get(language) }
            .filterNot(strengths::contains)
            .distinct()
        val incomplete = buildList {
            if (results.size < 20) add(language.pick("Пока пройдено меньше 20 визуальных серий; профиль имеет ограниченное покрытие.", "Поки пройдено менше 20 візуальних серій; профіль має обмежене покриття.", "Fewer than 20 visual series are completed; profile coverage is limited."))
            if (latent.confidence < 60) add(language.pick("Нужны дополнительные серии для устойчивой интерпретации части характеристик.", "Потрібні додаткові серії для стійкої інтерпретації частини характеристик.", "Additional series are needed for stable interpretation of some characteristics."))
        }
        return PsychologicalProfileView(
            version = PROFILE_VERSION,
            completedAssessments = results.size,
            coveragePercent = latent.confidence,
            dimensions = dimensions,
            strengths = strengths,
            growthAreas = growth,
            incompleteData = incomplete,
        )
    }

    fun analysis(user: UserProfile, results: Map<String, AssessmentResult>, language: AppLanguage): PsychologicalAnalysisView {
        val profile = profile(results, language)
        val latent = LatentProfileEngine.build(results.values)
        val summary = if (profile.dimensions.isEmpty()) {
            language.pick("Данных психологических тестов пока недостаточно для содержательного анализа.", "Даних психологічних тестів поки недостатньо для змістовного аналізу.", "There is not yet enough psychological assessment data for a meaningful analysis.")
        } else {
            val focus = profile.strengths.take(3).joinToString(", ")
            language.pick(
                "Текущая версия модели наиболее уверенно описывает такие тенденции: $focus. Это вероятностная интерпретация результатов, а не диагноз и не неизменное определение личности.",
                "Поточна версія моделі найупевненіше описує такі тенденції: $focus. Це ймовірнісна інтерпретація результатів, а не діагноз і не незмінне визначення особистості.",
                "The current model most confidently describes these tendencies: $focus. This is a probabilistic interpretation, not a diagnosis or an immutable definition of personality.",
            )
        }
        val sections = listOf(
            section("overview", language.pick("Общая характеристика", "Загальна характеристика", "Overview"), latent, profile.dimensions.map { it.key }.toSet(), language),
            section("communication", language.pick("Стиль общения", "Стиль спілкування", "Communication style"), latent, communicationKeys, language),
            section("conflict", language.pick("Поведение в конфликте", "Поведінка в конфлікті", "Conflict style"), latent, conflictKeys, language),
            section("decisions", language.pick("Принятие решений", "Прийняття рішень", "Decision-making"), latent, decisionKeys, language),
            section("trust", language.pick("Отношение к доверию", "Ставлення до довіри", "Trust tendencies"), latent, trustKeys, language),
            section("social", language.pick("Социальная энергия и роль в группе", "Соціальна енергія та роль у групі", "Social energy & group role"), latent, groupKeys, language),
            section("work", language.pick("Работа и проекты", "Робота та проєкти", "Work & projects"), latent, workKeys, language),
            section("friendship", language.pick("Дружба", "Дружба", "Friendship"), latent, friendshipKeys, language),
            section("stress", language.pick("Стресс и неопределённость", "Стрес і невизначеність", "Stress & uncertainty"), latent, stressKeys, language),
        ).filter { it.body.isNotBlank() }

        val limitations = buildList {
            addAll(profile.incompleteData)
            add(language.pick("Trust, Account Rating, Hospitality Reputation и Compatibility не являются частями психологического профиля.", "Trust, Account Rating, Hospitality Reputation і Compatibility не є частинами психологічного профілю.", "Trust, Account Rating, Hospitality Reputation and Compatibility are not parts of the psychological profile."))
            add(language.pick("Brotherhood-32, Enneagram, нумерология и зодиак хранятся как отдельные модели и не подменяют этот анализ.", "Brotherhood-32, Enneagram, нумерологія та зодіак зберігаються як окремі моделі й не підміняють цей аналіз.", "Brotherhood-32, Enneagram, numerology and zodiac remain separate models and do not replace this analysis."))
        }
        return PsychologicalAnalysisView(
            version = ANALYSIS_VERSION,
            summary = summary,
            sections = sections,
            strengths = profile.strengths,
            growthAreas = profile.growthAreas,
            limitations = limitations,
        )
    }

    fun report(
        user: UserProfile,
        results: Map<String, AssessmentResult>,
        language: AppLanguage,
        createdAtEpochMs: Long = System.currentTimeMillis(),
    ): PsychologicalReportSnapshot {
        val analysis = analysis(user, results, language)
        val activeModel = results.values.map { it.modelVersion }.distinct().sorted().joinToString("+").ifBlank { "NO_ASSESSMENT_MODEL" }
        return PsychologicalReportSnapshot(
            reportVersion = REPORT_VERSION,
            modelVersion = activeModel,
            createdAtEpochMs = createdAtEpochMs,
            completedAssessmentIds = results.keys.sorted(),
            coveragePercent = profile(results, language).coveragePercent,
            summary = analysis.summary,
            sections = analysis.sections,
            strengths = analysis.strengths,
            growthAreas = analysis.growthAreas,
            limitations = analysis.limitations,
        )
    }

    private fun section(titleKey: String, title: String, profile: LatentProfile, keys: Set<String>, language: AppLanguage): PsychologicalAnalysisSection {
        val rows = profile.traits.values
            .filter { it.key in keys }
            .sortedWith(compareByDescending<org.federationofavatars.brotherhood.model.LatentTraitScore> { kotlin.math.abs(it.score - 50) }.thenByDescending { it.evidence })
            .take(4)
            .mapNotNull { score ->
                val definition = traitByKey[score.key] ?: return@mapNotNull null
                when {
                    score.score >= 67 -> definition.highPositive.get(language)
                    score.score <= 33 -> definition.lowPositive.get(language)
                    else -> definition.balancedPositive.get(language)
                }
            }
            .distinct()
        return PsychologicalAnalysisSection(titleKey, title, rows.joinToString("; "))
    }

    private fun publicTitle(key: String, language: AppLanguage): String = key
        .replace('_', ' ')
        .split(' ')
        .joinToString(" ") { it.replaceFirstChar { ch -> ch.titlecase() } }
}
