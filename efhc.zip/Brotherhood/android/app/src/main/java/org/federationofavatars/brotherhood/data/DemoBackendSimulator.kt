package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.ChatEncryptionMode
import org.federationofavatars.brotherhood.model.ChatMessage
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.HospitalityArrivalDetails
import org.federationofavatars.brotherhood.model.HospitalityAvailability
import org.federationofavatars.brotherhood.model.HospitalityEvent
import org.federationofavatars.brotherhood.model.HospitalityHostDetails
import org.federationofavatars.brotherhood.model.HospitalityHostProfile
import org.federationofavatars.brotherhood.model.HospitalityReputation
import org.federationofavatars.brotherhood.model.HospitalityReviewState
import org.federationofavatars.brotherhood.model.HospitalityVerification
import org.federationofavatars.brotherhood.model.StayRequest
import org.federationofavatars.brotherhood.model.TrustEvent
import org.federationofavatars.brotherhood.model.UserProfile

/**
 * Local DEBUG backend façade.
 *
 * This class exposes deterministic backend-like read responses for the offline APK demo. It is not
 * used as a production transport and it never replaces the real FastAPI repositories. Mutable
 * runtime behavior belongs to [DemoSimulationEngine]; [DemoRepository] remains fixture/catalog data.
 */
class DemoBackendSimulator {
    val profile: UserProfile get() = DemoRepository.profile
    val trustEvents: List<TrustEvent> get() = DemoRepository.trustEvents

    fun people(language: AppLanguage): List<FriendCandidate> = DemoRepository.peopleFor(language)

    fun communities(language: AppLanguage): List<Community> = DemoRepository.communitiesFor(language)

    fun hospitalityHostProfile(): HospitalityHostProfile = DemoRepository.hospitalityHostProfile
    fun hospitalityHostDetails(hostGlobalId: GlobalId): HospitalityHostDetails? =
        DemoRepository.hospitalityHostOleg.takeIf { it.host.hostGlobalId == hostGlobalId }
    fun hospitalityAvailability(): List<HospitalityAvailability> = DemoRepository.hospitalityAvailability
    fun hospitalityRequests(): List<StayRequest> = DemoRepository.hospitalityRequests
    fun hospitalityArrivalDetails(requestId: String): HospitalityArrivalDetails? =
        DemoRepository.hospitalityArrivalDetails.takeIf { it.requestId == requestId }
    fun hospitalityVerification(requestId: String): HospitalityVerification? =
        DemoRepository.hospitalityVerification.takeIf { it.requestId == requestId }
    fun hospitalityReviewState(requestId: String): HospitalityReviewState? =
        DemoRepository.hospitalityReviewState.takeIf { it.requestId == requestId }
    fun hospitalityReputation(globalId: GlobalId): HospitalityReputation =
        DemoRepository.hospitalityReputation.copy(globalId = globalId)
    fun hospitalityEvents(conversationId: String): List<HospitalityEvent> =
        DemoRepository.hospitalityEvents.filter { it.conversationId == conversationId }

    fun initialMessages(language: AppLanguage): Map<String, List<ChatMessage>> {
        val now = System.currentTimeMillis()
        return linkedMapOf(
            directId(2L) to listOf(
                fixedMessage(
                    id = "demo-m1",
                    conversationId = directId(2L),
                    sender = GlobalId(2),
                    text = language.pick(
                        "Привет. Увидел совпадение по футболу и бизнесу.",
                        "Привіт. Побачив збіг за футболом і бізнесом.",
                        "Hi. I noticed we match on football and business.",
                    ),
                    createdAt = now - 3_600_000,
                    encryptionMode = ChatEncryptionMode.E2EE,
                ),
                fixedMessage(
                    id = "demo-m2",
                    conversationId = directId(2L),
                    sender = profile.globalId,
                    text = language.pick(
                        "Привет! Да, можно начать с короткой встречи на выходных.",
                        "Привіт! Так, можемо почати з короткої зустрічі на вихідних.",
                        "Hi! Yes, we can start with a short meetup this weekend.",
                    ),
                    createdAt = now - 3_300_000,
                    encryptionMode = ChatEncryptionMode.E2EE,
                ),
            ),
            directId(4L) to listOf(
                fixedMessage(
                    id = "demo-m3",
                    conversationId = directId(4L),
                    sender = GlobalId(4),
                    text = language.pick(
                        "Если будешь во Львове — покажу хороший маршрут по городу.",
                        "Якщо будеш у Львові — покажу гарний маршрут містом.",
                        "If you are in Lviv, I can show you a good route through the city.",
                    ),
                    createdAt = now - 7_200_000,
                    encryptionMode = ChatEncryptionMode.E2EE,
                ),
            ),
            "demo-group-1" to listOf(
                fixedMessage(
                    id = "demo-g1",
                    conversationId = "demo-group-1",
                    sender = GlobalId(7),
                    text = language.pick(
                        "Собрал идеи по совместному волонтёрскому проекту.",
                        "Зібрав ідеї щодо спільного волонтерського проєкту.",
                        "I collected ideas for a shared volunteer project.",
                    ),
                    createdAt = now - 5_400_000,
                    encryptionMode = ChatEncryptionMode.SERVER,
                ),
                fixedMessage(
                    id = "demo-g2",
                    conversationId = "demo-group-1",
                    sender = profile.globalId,
                    text = language.pick(
                        "Отлично. Давайте сначала определим роли и ближайший шаг.",
                        "Чудово. Спочатку визначмо ролі та найближчий крок.",
                        "Great. Let's define roles and the next step first.",
                    ),
                    createdAt = now - 5_100_000,
                    encryptionMode = ChatEncryptionMode.SERVER,
                ),
            ),
        )
    }

    private fun directId(peerId: Long): String = "demo-direct-$peerId"

    private fun fixedMessage(
        id: String,
        conversationId: String,
        sender: GlobalId,
        text: String,
        createdAt: Long,
        encryptionMode: ChatEncryptionMode,
    ) = ChatMessage(
        id = id,
        conversationId = conversationId,
        senderGlobalId = sender,
        clientMessageId = id,
        messageType = "text",
        encryptionMode = encryptionMode,
        body = text,
        ciphertextB64 = null,
        nonceB64 = null,
        keyId = null,
        ratchetCounter = null,
        senderEphemeralPublicKeyB64 = null,
        recipientPrekeyId = null,
        attachments = emptyList(),
        status = "delivered",
        createdAtEpochMs = createdAt,
        decryptedBody = text,
        deliveredCount = 1,
        readCount = if (sender == profile.globalId) 1 else 0,
    )
}
