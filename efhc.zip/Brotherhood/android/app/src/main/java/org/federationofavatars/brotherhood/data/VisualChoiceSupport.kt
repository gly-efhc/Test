package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.model.VisualAssessmentChoice
import org.federationofavatars.brotherhood.model.VisualParadigm
import org.federationofavatars.brotherhood.model.VisualSceneArchetype

/** Generic visual ordering helper retained only for non-assessment descriptive modules. */
object VisualChoiceSupport {
    fun presentedChoices(choices: List<VisualAssessmentChoice>, seed: Int): List<VisualAssessmentChoice> {
        val shift = kotlin.math.abs(seed * 31 + 17) % 4
        val ids = List(4) { ((it + shift) % 4) + 1 }.let { if (((seed ushr 2) and 1) == 0) it else it.reversed() }
        val byId = choices.associateBy(VisualAssessmentChoice::id)
        return ids.mapNotNull { byId[it.toString()] }
    }

    fun compositionVariant(scene: VisualSceneArchetype, paradigm: VisualParadigm, seed: Int): Int {
        var mixed = seed xor (scene.ordinal * -1640531527) xor (paradigm.ordinal * -2048144789)
        mixed = mixed xor (mixed ushr 16)
        mixed *= 2146121005
        mixed = mixed xor (mixed ushr 15)
        mixed *= -2073254261
        mixed = mixed xor (mixed ushr 16)
        return (mixed and Int.MAX_VALUE) % 8
    }
}
