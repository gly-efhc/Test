package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.model.LatentProfile
import org.federationofavatars.brotherhood.model.LatentTraitScore

/** Deterministic demo-only profiles. Production matching uses stored hidden assessment dimensions. */
object DemoLatentProfileFactory {
    fun fromSeed(seed: Int): LatentProfile {
        val traits = LatentTraitCatalog.traits.associate { trait ->
            val h = abs((trait.key.hashCode() * 31L + seed * 7919L).toInt())
            val score = 15 + (h % 71)
            trait.key to LatentTraitScore(trait.key, score, 5)
        }
        return LatentProfile(traits, 72)
    }
}
