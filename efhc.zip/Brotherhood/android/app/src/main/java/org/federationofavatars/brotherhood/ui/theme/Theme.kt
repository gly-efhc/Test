package org.federationofavatars.brotherhood.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.federationofavatars.brotherhood.model.AppThemeMode

private val BrotherhoodDark = darkColorScheme(
    primary = Color(0xFFE5B95C),
    onPrimary = Color(0xFF201800),
    primaryContainer = Color(0xFF3B2E0C),
    onPrimaryContainer = Color(0xFFFFE6AE),
    secondary = Color(0xFF8EB9FF),
    onSecondary = Color(0xFF002B5D),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF2F2F4),
    surface = Color(0xFF0B0C0F),
    onSurface = Color(0xFFF2F2F4),
    surfaceVariant = Color(0xFF17191E),
    onSurfaceVariant = Color(0xFFC5C7CE),
    outline = Color(0xFF4A4D55),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

private val BrotherhoodLight = lightColorScheme(
    primary = Color(0xFF7A5700),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE7A3),
    onPrimaryContainer = Color(0xFF251A00),
    secondary = Color(0xFF315B86),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD7E9FF),
    onSecondaryContainer = Color(0xFF0B2A47),
    tertiary = Color(0xFF59633B),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFFFFCF5),
    onBackground = Color(0xFF1E1B16),
    surface = Color(0xFFFFFCF5),
    onSurface = Color(0xFF1E1B16),
    surfaceVariant = Color(0xFFF0ECE2),
    onSurfaceVariant = Color(0xFF4D4941),
    outline = Color(0xFF7E786D),
    outlineVariant = Color(0xFFD2C8B8),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
)


private val BrotherhoodShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun BrotherhoodTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) BrotherhoodDark else BrotherhoodLight,
        typography = Typography(),
        shapes = BrotherhoodShapes,
        content = content
    )
}
