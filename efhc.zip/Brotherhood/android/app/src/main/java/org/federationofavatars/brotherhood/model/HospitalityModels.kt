package org.federationofavatars.brotherhood.model

/** Public/participant-safe Hospitality contracts. Hidden assessment data is intentionally absent. */
enum class HospitalitySleepingCondition(val wire: String) {
    PRIVATE_ROOM("private_room"), SHARED_ROOM("shared_room"), SOFA("sofa"), ENTIRE_SPACE("entire_space")
}

enum class HospitalityAvailabilityMode(val wire: String) { ALWAYS("always"), CALENDAR("calendar") }
enum class HospitalityAvailabilityState(val wire: String) { AVAILABLE("available"), UNAVAILABLE("unavailable") }
enum class StayRequestStatus(val wire: String) {
    PENDING("pending"), ACCEPTED("accepted"), REJECTED("rejected"), CANCELLED_BY_GUEST("cancelled_by_guest"),
    CANCELLED_BY_HOST("cancelled_by_host"), COMPLETED("completed"), EXPIRED("expired")
}
enum class StayConfirmationValue(val wire: String) { STAY_OCCURRED("stay_occurred"), NO_SHOW("no_show"), DISPUTE("dispute") }

data class HospitalityPrivateLocation(
    val exactAddress: String,
    val arrivalInstructions: String = "",
    val exactLat: Double? = null,
    val exactLon: Double? = null,
    val arrivalContact: String = "",
)

data class HospitalityHostProfile(
    val hostGlobalId: GlobalId?,
    val isHostingActive: Boolean,
    val maxGuests: Int,
    val maxDays: Int,
    val cityId: String,
    val cityValue: String? = null,
    val publicAreaText: String?,
    val timezoneName: String,
    val sleepingCondition: HospitalitySleepingCondition,
    val houseRules: List<String>,
    val minRequiredRating: Double,
    val requiredCompletedTests: List<String>,
    val availabilityMode: HospitalityAvailabilityMode,
    val privateLocation: HospitalityPrivateLocation? = null,
)

data class HospitalityHostPublicSummary(
    val hostGlobalId: GlobalId,
    val isHostingActive: Boolean,
    val cityId: String,
    val publicAreaText: String?,
    val sleepingCondition: HospitalitySleepingCondition,
    val maxGuests: Int,
    val maxDays: Int,
    val houseRules: List<String>,
    val minRequiredRating: Double,
    val requiredCompletedTests: List<String>,
    val availabilityMode: HospitalityAvailabilityMode,
)

data class HospitalityEligibility(
    val eligible: Boolean,
    val reasons: List<String>,
    val accountRating: Double,
    val minRequiredRating: Double,
    val missingRequiredTests: List<String>,
    val dateAvailable: Boolean,
    val capacityAvailable: Boolean,
    val effectiveCapacity: Int?,
    val occupiedCapacity: Int,
    val stayDays: Int,
)

data class HospitalityAvailability(
    val availabilityId: String,
    val dateFrom: String,
    val dateTo: String,
    val state: HospitalityAvailabilityState,
    val capacityOverride: Int?,
)

data class StayRequest(
    val requestId: String,
    val guestGlobalId: GlobalId,
    val hostGlobalId: GlobalId,
    val checkInDate: String,
    val checkOutDate: String,
    val guestsCount: Int,
    val status: StayRequestStatus,
    val responseDueAt: String,
    val conversationId: String,
    val version: Int,
    val createdAt: String,
    val updatedAt: String,
    val completedAt: String? = null,
    val reviewDeadlineAt: String? = null,
)

data class HospitalityArrivalDetails(
    val requestId: String,
    val exactAddress: String,
    val arrivalInstructions: String,
    val exactLat: Double?,
    val exactLon: Double?,
    val arrivalContact: String,
    val privateAccessExpiresAt: String,
)

data class HospitalityEvent(
    val eventId: String,
    val requestId: String,
    val conversationId: String,
    val actorGlobalId: GlobalId?,
    val eventType: String,
    val publicPayload: Map<String, String>,
    val createdAt: String,
    val createdAtEpochMs: Long,
)

data class HospitalityVerification(
    val requestId: String,
    val verified: Boolean,
    val interactionId: String?,
    val hostConfirmed: Boolean,
    val guestConfirmed: Boolean,
    val blockedBy: String?,
)

data class HospitalityReviewState(
    val requestId: String,
    val canSubmit: Boolean,
    val ownSubmitted: Boolean,
    val ownPublished: Boolean,
    val reviewDeadlineAt: String?,
    val publishedReviewCount: Int,
)

data class HospitalityPublicReview(
    val reviewId: String,
    val requestId: String,
    val authorGlobalId: GlobalId,
    val targetGlobalId: GlobalId,
    val adequacy: Int,
    val rulesCompliance: Int,
    val descriptionAccuracy: Int,
    val reviewScore: Double,
    val reviewText: String?,
    val submittedAt: String,
    val publishedAt: String,
)

data class HospitalityReputation(
    val globalId: GlobalId,
    val verifiedStaysAsHost: Int,
    val verifiedStaysAsGuest: Int,
    val publishedReviews: Int,
    val averageHostReview: Double?,
    val averageGuestReview: Double?,
    val activeRestriction: Boolean,
    val policyVersion: String,
)

data class HospitalityHostDetails(
    val host: HospitalityHostPublicSummary,
    val eligibility: HospitalityEligibility?,
)

sealed interface HospitalityTimelineItem {
    val epochMs: Long
    data class Message(val value: ChatMessage) : HospitalityTimelineItem { override val epochMs: Long = value.createdAtEpochMs }
    data class Event(val value: HospitalityEvent) : HospitalityTimelineItem { override val epochMs: Long = value.createdAtEpochMs }
}
