package org.federationofavatars.brotherhood.auth

import android.app.Activity
import android.util.Base64
import androidx.credentials.CreatePublicKeyCredentialRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetPublicKeyCredentialOption
import androidx.credentials.PublicKeyCredential
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import java.security.SecureRandom

/** Native Android credential acquisition. Verification always happens on Brotherhood backend. */
object AndroidCredentialGateway {
    data class GoogleCredential(val idToken: String, val nonce: String)

    suspend fun google(activity: Activity, serverClientId: String): GoogleCredential {
        require(serverClientId.isNotBlank()) { "Google server client ID is not configured" }
        val nonce = secureNonce()
        val option = GetSignInWithGoogleOption.Builder(serverClientId)
            .setNonce(nonce)
            .build()
        val result = CredentialManager.create(activity).getCredential(
            context = activity,
            request = GetCredentialRequest.Builder().addCredentialOption(option).build(),
        )
        val credential = result.credential
        require(credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            "Unexpected Google credential type"
        }
        return GoogleCredential(GoogleIdTokenCredential.createFrom(credential.data).idToken, nonce)
    }

    suspend fun authenticatePasskey(activity: Activity, optionsJson: String): String {
        val result = CredentialManager.create(activity).getCredential(
            context = activity,
            request = GetCredentialRequest.Builder()
                .addCredentialOption(GetPublicKeyCredentialOption(optionsJson))
                .build(),
        )
        val credential = result.credential as? PublicKeyCredential
            ?: error("Unexpected passkey credential type")
        return credential.authenticationResponseJson
    }

    suspend fun createPasskey(activity: Activity, optionsJson: String): String {
        val result = CredentialManager.create(activity).createCredential(
            context = activity,
            request = CreatePublicKeyCredentialRequest(optionsJson),
        )
        val credential = result as? androidx.credentials.CreatePublicKeyCredentialResponse
            ?: error("Unexpected passkey registration result")
        return credential.registrationResponseJson
    }

    private fun secureNonce(): String {
        val bytes = ByteArray(32).also(SecureRandom()::nextBytes)
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}
