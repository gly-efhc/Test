package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.AssessmentKind

data class AssessmentModuleCompatibility(
    val kind: AssessmentKind,
    val score: Int,
    val commonAssessments: Int,
    val totalAssessments: Int,
) {
    val coveragePercent: Int get() = if (totalAssessments == 0) 0 else (commonAssessments * 100 / totalAssessments).coerceIn(0, 100)
}

/** Independent 0..100 compatibility for each current visual-assessment module. */
object AssessmentModuleCompatibilityEngine {
    fun calculate(myScores: Map<String, Int>, peerScores: Map<String, Int>): List<AssessmentModuleCompatibility> =
        AssessmentKind.entries.map { kind ->
            val ids = AssessmentCatalog.assessments.filter { it.kind == kind }.map { it.id }
            val common = ids.filter { it in myScores && it in peerScores }
            val score = if (common.isEmpty()) 0 else common.map { id ->
                100 - kotlin.math.abs(myScores.getValue(id).coerceIn(0, 100) - peerScores.getValue(id).coerceIn(0, 100))
            }.average().toInt().coerceIn(0, 100)
            AssessmentModuleCompatibility(kind, score, common.size, ids.size)
        }
}
