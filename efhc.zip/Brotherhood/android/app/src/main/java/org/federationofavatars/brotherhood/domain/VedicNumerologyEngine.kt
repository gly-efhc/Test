package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.data.pick

import java.time.LocalDate
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.VedicNumerologyProfile

data class VedicCompatibilityBreakdown(
    val total: Int,
    val soul: Int,
    val destiny: Int,
    val cross: Int,
    val dateComposite: Int,
    val strongestLink: String,
    val tension: String?,
)

/**
 * Vedic numerology layer used as a cultural/esoteric compatibility model, not as psychology.
 * Number rulers follow the common Navagraha mapping: 1 Sun, 2 Moon, 3 Jupiter, 4 Rahu,
 * 5 Mercury, 6 Venus, 7 Ketu, 8 Saturn, 9 Mars.
 *
 * Compatibility uses a transparent internal matrix inspired by traditional planetary friendship
 * relationships, symmetrised for friendship matching. Under active Q28 it is an independent
 * 0..100 compatibility metric; it is never mixed into Trust Score.
 */
object VedicNumerologyEngine {
    private val chaldean = mapOf(
        'A' to 1, 'I' to 1, 'J' to 1, 'Q' to 1, 'Y' to 1,
        'B' to 2, 'K' to 2, 'R' to 2,
        'C' to 3, 'G' to 3, 'L' to 3, 'S' to 3,
        'D' to 4, 'M' to 4, 'T' to 4,
        'E' to 5, 'H' to 5, 'N' to 5, 'X' to 5,
        'U' to 6, 'V' to 6, 'W' to 6,
        'O' to 7, 'Z' to 7,
        'F' to 8, 'P' to 8
    )

    private val rulers = mapOf(
        1 to "Sun", 2 to "Moon", 3 to "Jupiter", 4 to "Rahu", 5 to "Mercury",
        6 to "Venus", 7 to "Ketu", 8 to "Saturn", 9 to "Mars"
    )

    // Directed natural-relationship scores. Pair score is the mean of both directions so the
    // friendship result does not depend on which user is evaluated first.
    private val friends = mapOf(
        1 to setOf(2, 3, 9),
        2 to setOf(1, 5),
        3 to setOf(1, 2, 9),
        4 to setOf(5, 6, 8),
        5 to setOf(1, 6),
        6 to setOf(5, 8),
        7 to setOf(3, 9),
        8 to setOf(5, 6),
        9 to setOf(1, 2, 3),
    )
    private val enemies = mapOf(
        1 to setOf(6, 8, 4),
        2 to setOf(4, 7),
        3 to setOf(5, 6),
        4 to setOf(1, 2, 9),
        5 to setOf(2),
        6 to setOf(1, 2),
        7 to setOf(1, 2),
        8 to setOf(1, 2, 9),
        9 to setOf(5, 8),
    )

    fun calculate(date: LocalDate, latinName: String?): VedicNumerologyProfile {
        val soul = digitalRoot(date.dayOfMonth)
        val destiny = digitalRoot(date.dayOfMonth + date.monthValue + date.year.toString().sumOf { it.digitToInt() })
        val name = latinName
            ?.uppercase()
            ?.mapNotNull(chaldean::get)
            ?.takeIf { it.isNotEmpty() }
            ?.sum()
            ?.let(::digitalRoot)
        // Vedic date profile stays mathematical and date-based. Name numerology is retained only
        // as an optional separate descriptive field and never enters Vedic compatibility.
        val maturity = digitalRoot(destiny + soul)
        return VedicNumerologyProfile(
            soulNumber = soul,
            destinyNumber = destiny,
            nameNumber = name,
            maturityNumber = maturity,
            compatibilityVector = listOf(soul, destiny, maturity)
        )
    }

    fun compatibility(first: VedicNumerologyProfile, second: VedicNumerologyProfile): Int =
        compatibilityBreakdown(first, second).total

    fun compatibilityBreakdown(first: VedicNumerologyProfile, second: VedicNumerologyProfile): VedicCompatibilityBreakdown {
        val soul = pairScore(first.soulNumber, second.soulNumber)
        val destiny = pairScore(first.destinyNumber, second.destinyNumber)
        val cross = (pairScore(first.soulNumber, second.destinyNumber) + pairScore(first.destinyNumber, second.soulNumber)) / 2
        val dateComposite = pairScore(
            digitalRoot(first.soulNumber + first.destinyNumber),
            digitalRoot(second.soulNumber + second.destinyNumber),
        )
        // Compatibility is derived ONLY from birth-date numbers. No questionnaire and no name score.
        val total = (soul * .40 + destiny * .35 + cross * .15 + dateComposite * .10).toInt().coerceIn(25, 100)
        val components = listOf("душа" to soul, "судьба" to destiny, "перекрёстная связь" to cross, "композит даты" to dateComposite)
        val strongest = components.maxBy { it.second }
        val weakest = components.minBy { it.second }
        return VedicCompatibilityBreakdown(
            total = total,
            soul = soul,
            destiny = destiny,
            cross = cross,
            dateComposite = dateComposite,
            strongestLink = "${strongest.first}: ${strongest.second}%",
            tension = if (weakest.second < 50) "${weakest.first}: ${weakest.second}%" else null,
        )
    }

    fun ruler(number: Int): String = rulers[number] ?: "Unknown"

    fun compatibilitySummary(first: VedicNumerologyProfile, second: VedicNumerologyProfile, language: AppLanguage): String {
        val b = compatibilityBreakdown(first, second)
        val strongest = listOf(
            localized(language, "число души", "число душі", "soul number") to b.soul,
            localized(language, "число судьбы", "число долі", "destiny number") to b.destiny,
            localized(language, "перекрёстная связь", "перехресний зв'язок", "cross-link") to b.cross,
            localized(language, "композит даты", "композит дати", "birth-date composite") to b.dateComposite,
        ).maxBy { it.second }
        return language.pick(
            "Общий ведический слой ${b.total}%. Наиболее выраженная связка — ${strongest.first} (${strongest.second}%). Этот культурный/эзотерический слой используется только как отдельная часть совместимости и не влияет на Trust Score.",
            "Загальний ведичний шар ${b.total}%. Найвиразніша зв'язка — ${strongest.first} (${strongest.second}%). Цей культурний/езотеричний шар використовується лише як окрема частина сумісності та не впливає на Trust Score.",
            "Overall Vedic layer ${b.total}%. Most pronounced link: ${strongest.first} (${strongest.second}%). This cultural/esoteric layer is used only as a separate compatibility component and never affects Trust Score.",
        )
    }

    fun numberPairDescription(first: Int, second: Int, language: AppLanguage): String {
        val score = pairScore(first, second)
        val relation = when {
            first == second -> localized(language, "одинаковая энергия", "однакова енергія", "same-energy pairing")
            score >= 80 -> localized(language, "дружественная связь", "дружній зв'язок", "friendly pairing")
            score < 50 -> localized(language, "контрастная динамика", "контрастна динаміка", "contrasting dynamic")
            else -> localized(language, "нейтральная связь", "нейтральний зв'язок", "neutral pairing")
        }
        return language.pick(
            "$first (${ruler(first)}) ↔ $second (${ruler(second)}): $relation, $score%.",
            "$first (${ruler(first)}) ↔ $second (${ruler(second)}): $relation, $score%.",
            "$first (${ruler(first)}) ↔ $second (${ruler(second)}): $relation, $score%.",
        )
    }

    fun numberDescription(number: Int, language: AppLanguage): String {
        val texts = when (number) {
            1 -> Triple("инициатива, самостоятельность, лидерский импульс", "ініціатива, самостійність, лідерський імпульс", "initiative, independence and leadership drive")
            2 -> Triple("чувствительность, дипломатия, умение поддерживать связь", "чутливість, дипломатія, уміння підтримувати зв'язок", "sensitivity, diplomacy and relationship maintenance")
            3 -> Triple("обучение, смысл, наставничество и оптимизм", "навчання, сенс, наставництво та оптимізм", "learning, meaning, mentoring and optimism")
            4 -> Triple("нестандартность, амбиция, стремление ломать привычные рамки", "нестандартність, амбіція, прагнення ламати звичні рамки", "unconventional thinking, ambition and boundary-breaking")
            5 -> Triple("коммуникация, гибкость, интеллект и обмен информацией", "комунікація, гнучкість, інтелект та обмін інформацією", "communication, flexibility, intellect and information exchange")
            6 -> Triple("отношения, гармония, эстетика, забота и комфорт", "стосунки, гармонія, естетика, турбота та комфорт", "relationships, harmony, aesthetics, care and comfort")
            7 -> Triple("внутренний поиск, наблюдательность, независимость и интуитивность", "внутрішній пошук, спостережливість, незалежність та інтуїтивність", "inner search, observation, independence and intuition")
            8 -> Triple("дисциплина, ответственность, выносливость и долгий горизонт", "дисципліна, відповідальність, витривалість та довгий горизонт", "discipline, responsibility, endurance and long-term focus")
            9 -> Triple("воля, действие, защита, прямота и соревновательная энергия", "воля, дія, захист, прямота та змагальна енергія", "will, action, protection, directness and competitive energy")
            else -> Triple("не определено", "не визначено", "not defined")
        }
        return language.pick(texts.first, texts.second, texts.third)
    }

    private fun pairScore(first: Int, second: Int): Int {
        if (first == second) return 94
        val a = directed(first, second)
        val b = directed(second, first)
        return ((a + b) / 2).coerceIn(30, 92)
    }

    private fun directed(from: Int, to: Int): Int = when {
        friends[from]?.contains(to) == true -> 88
        enemies[from]?.contains(to) == true -> 38
        else -> 64
    }

    private fun localized(language: AppLanguage, ru: String, uk: String, en: String): String = language.pick(ru, uk, en)

    private fun digitalRoot(number: Int): Int {
        require(number >= 0)
        if (number == 0) return 0
        var current = number
        while (current > 9) current = current.toString().sumOf { it.digitToInt() }
        return current
    }
}
