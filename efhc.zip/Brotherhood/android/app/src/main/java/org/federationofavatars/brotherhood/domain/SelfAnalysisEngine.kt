package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.data.pick

import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.UserProfile

data class SelfInsight(
    val title: String,
    val text: String,
    val score: Int? = null,
    val kind: InsightKind = InsightKind.INFO,
)

enum class InsightKind { STRENGTH, GROWTH, INFO, CAUTION }

data class SelfAnalysisReport(
    val completedTests: Int,
    val confidence: Int,
    val strengths: List<SelfInsight>,
    val growthAreas: List<SelfInsight>,
    val profileInsights: List<SelfInsight>,
    val caveats: List<SelfInsight>,
)

/**
 * Public-safe self-analysis projection.
 * Hidden latent coordinates, low-fit poles, consistency signals and diagnostic flags stay private.
 * There are no universal "bad traits" in Brotherhood; public text emphasizes useful strengths.
 */
object SelfAnalysisEngine {
    fun build(profile: UserProfile, results: Map<String, AssessmentResult>, language: AppLanguage): SelfAnalysisReport {
        val latent = LatentProfileEngine.build(results.values)
        val positive = PositiveProfileProjector.topQualities(latent, language, limit = 8)
        val strengths = positive.map { quality ->
            SelfInsight(
                title = quality,
                text = localized(
                    language,
                    "Это одна из выраженных сторон вашего текущего профиля. Её ценность зависит от роли, задачи и сочетания с качествами другого человека.",
                    "Це одна з виражених сторін вашого поточного профілю. Її цінність залежить від ролі, завдання та поєднання з якостями іншої людини.",
                    "This is one of the stronger sides of your current profile. Its value depends on the role, task and combination with another person's qualities."
                ),
                kind = InsightKind.STRENGTH,
            )
        }

        val p = profile.personality32
        val personalityText = localized(
            language,
            "${p.title(language)} (${p.code}). Brotherhood-32 используется как дополнительный описательный слой профиля.",
            "${p.title(language)} (${p.code}). Brotherhood-32 використовується як додатковий описовий шар профілю.",
            "${p.title(language)} (${p.code}). Brotherhood-32 is used as an additional descriptive profile layer."
        )
        val n = profile.numerology
        val numerologyText = localized(
            language,
            "Число души ${n.soulNumber}; число судьбы ${n.destinyNumber}. Нумерология рассчитывается автоматически по дате рождения, не является психологическим тестом и имеет отдельную совместимость 0–100%.",
            "Число душі ${n.soulNumber}; число долі ${n.destinyNumber}. Нумерологія обчислюється автоматично за датою народження, не є психологічним тестом і має окрему сумісність 0–100%.",
            "Soul number ${n.soulNumber}; destiny number ${n.destinyNumber}. Numerology is calculated automatically from birth date, is not a psychological test, and has its own independent 0–100% compatibility."
        )
        val enneagramText = localized(
            language,
            "Тип ${profile.enneagram.type}${profile.enneagram.wing?.let { "w$it" } ?: ""} — ${profile.enneagram.title(language)}. Описательный слой, не клинический диагноз.",
            "Тип ${profile.enneagram.type}${profile.enneagram.wing?.let { "w$it" } ?: ""} — ${profile.enneagram.title(language)}. Описовий шар, не клінічний діагноз.",
            "Type ${profile.enneagram.type}${profile.enneagram.wing?.let { "w$it" } ?: ""} — ${profile.enneagram.title(language)}. Descriptive layer, not a clinical diagnosis."
        )
        val zodiacText = localized(
            language,
            "${profile.zodiac.symbol} ${profile.zodiac.label(language)}. Дополнительный культурный слой с отдельной совместимостью 0–100%.",
            "${profile.zodiac.symbol} ${profile.zodiac.label(language)}. Додатковий культурний шар з окремою сумісністю 0–100%.",
            "${profile.zodiac.symbol} ${profile.zodiac.label(language)}. An additional cultural layer with its own independent 0–100% compatibility."
        )

        val caveats = if (results.size < 20) listOf(
            SelfInsight(
                localized(language, "Профиль развивается", "Профіль розвивається", "Profile is developing"),
                localized(
                    language,
                    "Каждая новая визуальная серия делает подбор точнее; внутренние технические выводы при этом остаются скрытыми.",
                    "Кожна нова візуальна серія робить добір точнішим; внутрішні технічні висновки при цьому залишаються прихованими.",
                    "Each additional visual series makes matching more precise while internal technical inferences remain hidden."
                ),
                kind = InsightKind.INFO,
            )
        ) else emptyList()

        val psychological = PsychologicalProductEngine.profile(results, language)
        val growthAreas = psychological.growthAreas.map { area ->
            SelfInsight(
                title = area,
                text = localized(
                    language,
                    "Это не диагноз и не отрицательная характеристика, а контекст, где текущая модель предполагает полезность осознанной практики и дополнительных данных.",
                    "Це не діагноз і не негативна характеристика, а контекст, де поточна модель припускає користь усвідомленої практики та додаткових даних.",
                    "This is not a diagnosis or a negative label; it is a context where the current model suggests that deliberate practice and additional data may be useful."
                ),
                kind = InsightKind.GROWTH,
            )
        }

        return SelfAnalysisReport(
            completedTests = results.size,
            confidence = latent.confidence,
            strengths = strengths,
            growthAreas = growthAreas,
            profileInsights = listOf(
                SelfInsight("Brotherhood-32", personalityText),
                SelfInsight(localized(language, "Эннеаграмма", "Еннеаграма", "Enneagram"), enneagramText),
                SelfInsight(localized(language, "Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), numerologyText),
                SelfInsight(localized(language, "Зодиак", "Зодіак", "Zodiac"), zodiacText),
            ),
            caveats = caveats,
        )
    }

    private fun localized(language: AppLanguage, ru: String, uk: String, en: String): String = language.pick(ru, uk, en)
}
