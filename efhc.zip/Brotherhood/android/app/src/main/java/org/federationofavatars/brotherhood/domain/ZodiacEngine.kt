package org.federationofavatars.brotherhood.domain

import java.time.LocalDate
import org.federationofavatars.brotherhood.model.ZodiacSign

object ZodiacEngine {
    fun sign(date: LocalDate): ZodiacSign {
        val md = date.monthValue * 100 + date.dayOfMonth
        return when (md) {
            in 321..419 -> ZodiacSign.ARIES
            in 420..520 -> ZodiacSign.TAURUS
            in 521..620 -> ZodiacSign.GEMINI
            in 621..722 -> ZodiacSign.CANCER
            in 723..822 -> ZodiacSign.LEO
            in 823..922 -> ZodiacSign.VIRGO
            in 923..1022 -> ZodiacSign.LIBRA
            in 1023..1121 -> ZodiacSign.SCORPIO
            in 1122..1221 -> ZodiacSign.SAGITTARIUS
            in 1222..1231, in 101..119 -> ZodiacSign.CAPRICORN
            in 120..218 -> ZodiacSign.AQUARIUS
            else -> ZodiacSign.PISCES
        }
    }

    fun compatibility(first: ZodiacSign, second: ZodiacSign): Int {
        val elements = mapOf(
            ZodiacSign.ARIES to 0, ZodiacSign.LEO to 0, ZodiacSign.SAGITTARIUS to 0,
            ZodiacSign.TAURUS to 1, ZodiacSign.VIRGO to 1, ZodiacSign.CAPRICORN to 1,
            ZodiacSign.GEMINI to 2, ZodiacSign.LIBRA to 2, ZodiacSign.AQUARIUS to 2,
            ZodiacSign.CANCER to 3, ZodiacSign.SCORPIO to 3, ZodiacSign.PISCES to 3
        )
        val a = elements.getValue(first)
        val b = elements.getValue(second)
        return when {
            first == second -> 86
            a == b -> 90
            setOf(a, b) == setOf(0, 2) -> 84
            setOf(a, b) == setOf(1, 3) -> 84
            else -> 66
        }
    }
}
