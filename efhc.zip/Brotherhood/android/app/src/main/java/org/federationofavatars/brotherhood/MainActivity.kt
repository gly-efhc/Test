package org.federationofavatars.brotherhood

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import org.federationofavatars.brotherhood.ui.BrotherhoodApp
import org.federationofavatars.brotherhood.ui.MainViewModel
import org.federationofavatars.brotherhood.ui.theme.BrotherhoodTheme

class MainActivity : ComponentActivity() {
    private lateinit var appUpdateManager: AppUpdateManager
    private val mainViewModel: MainViewModel by viewModels()

    private val updateLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { /* Google Play owns the update UI; cancellation is intentionally non-fatal. */ }

    private val installListener = InstallStateUpdatedListener { state ->
        if (state.installStatus() == InstallStatus.DOWNLOADED) {
            // Flexible update has already been verified by Google Play. Completing here keeps the
            // app on one predictable version without requesting package-install permissions.
            appUpdateManager.completeUpdate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        appUpdateManager = AppUpdateManagerFactory.create(this)
        appUpdateManager.registerListener(installListener)
        requestPlayUpdateIfAvailable()

        setContent {
            BrotherhoodTheme(themeMode = mainViewModel.themeMode) {
                BrotherhoodApp(mainViewModel)
            }
        }
        handleAppIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAppIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        requestPlayUpdateIfAvailable()
    }

    override fun onDestroy() {
        appUpdateManager.unregisterListener(installListener)
        super.onDestroy()
    }

    private fun handleAppIntent(intent: Intent?) {
        val requestId = intent?.getStringExtra("hospitality_request_id")
        val eventType = intent?.getStringExtra("hospitality_event_type")
        if (!requestId.isNullOrBlank() || !eventType.isNullOrBlank()) {
            mainViewModel.handleHospitalityPush(eventType, requestId)
            return
        }
        val uri = intent?.data ?: return
        if (uri.host.equals("hospitality", ignoreCase = true)) {
            val pathRequestId = uri.pathSegments.firstOrNull { it.isNotBlank() && it != "request" }
            mainViewModel.handleHospitalityPush(uri.getQueryParameter("event"), pathRequestId)
            return
        }
        mainViewModel.completeTelegramOidcCallback(uri)
    }

    private fun requestPlayUpdateIfAvailable() {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            when {
                info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                    info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE) -> {
                    appUpdateManager.startUpdateFlowForResult(
                        info,
                        updateLauncher,
                        AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build(),
                    )
                }
                info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS &&
                    info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE) -> {
                    appUpdateManager.startUpdateFlowForResult(
                        info,
                        updateLauncher,
                        AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build(),
                    )
                }
            }
        }
    }
}
