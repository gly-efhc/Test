package org.federationofavatars.brotherhood.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.time.OffsetDateTime
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.federationofavatars.brotherhood.model.HospitalityArrivalDetails
import org.json.JSONObject

/**
 * Encrypted, expiry-bound local store for accepted-stay arrival details.
 * Plaintext exact address/coordinates/contact are never written to SharedPreferences.
 */
class HospitalitySecureStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("hospitality_secure_v1", Context.MODE_PRIVATE)
    private val alias = "brotherhood_hospitality_arrival_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    fun put(details: HospitalityArrivalDetails) {
        val payload = JSONObject().apply {
            put("request_id", details.requestId)
            put("exact_address", details.exactAddress)
            put("arrival_instructions", details.arrivalInstructions)
            details.exactLat?.let { put("exact_lat", it) }
            details.exactLon?.let { put("exact_lon", it) }
            put("arrival_contact", details.arrivalContact)
            put("private_access_expires_at", details.privateAccessExpiresAt)
        }.toString().toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val ciphertext = cipher.doFinal(payload)
        prefs.edit()
            .putString("${details.requestId}:nonce", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("${details.requestId}:ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString("${details.requestId}:expires", details.privateAccessExpiresAt)
            .apply()
    }

    fun get(requestId: String): HospitalityArrivalDetails? {
        val expires = prefs.getString("$requestId:expires", null) ?: return null
        val expired = runCatching { OffsetDateTime.parse(expires).isBefore(OffsetDateTime.now()) }.getOrDefault(true)
        if (expired) { remove(requestId); return null }
        val nonce = prefs.getString("$requestId:nonce", null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        val ciphertext = prefs.getString("$requestId:ciphertext", null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
            val root = JSONObject(cipher.doFinal(ciphertext).toString(Charsets.UTF_8))
            HospitalityArrivalDetails(
                requestId = root.getString("request_id"),
                exactAddress = root.getString("exact_address"),
                arrivalInstructions = root.optString("arrival_instructions"),
                exactLat = if (root.has("exact_lat") && !root.isNull("exact_lat")) root.getDouble("exact_lat") else null,
                exactLon = if (root.has("exact_lon") && !root.isNull("exact_lon")) root.getDouble("exact_lon") else null,
                arrivalContact = root.optString("arrival_contact"),
                privateAccessExpiresAt = root.getString("private_access_expires_at"),
            )
        }.getOrNull()
    }

    fun remove(requestId: String) {
        prefs.edit().remove("$requestId:nonce").remove("$requestId:ciphertext").remove("$requestId:expires").apply()
    }

    fun purgeExpired() {
        val requestIds = prefs.all.keys.mapNotNull { it.substringBefore(':').takeIf(String::isNotBlank) }.toSet()
        requestIds.forEach { get(it) }
    }

    private fun key(): SecretKey {
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
