package org.federationofavatars.brotherhood.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Reviews
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.federationofavatars.brotherhood.model.HospitalityAvailabilityMode
import org.federationofavatars.brotherhood.model.HospitalitySleepingCondition
import org.federationofavatars.brotherhood.model.StayConfirmationValue
import org.federationofavatars.brotherhood.model.StayRequest
import org.federationofavatars.brotherhood.model.StayRequestStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityHomeScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    LaunchedEffect(Unit) { viewModel.refreshHospitalityHome() }
    val profile = viewModel.hospitalityHostProfile
    val reputation = viewModel.hospitalityReputation
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(viewModel.t("Гостеприимство", "Гостинність", "Hospitality"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } },
                actions = { IconButton(onClick = viewModel::refreshHospitalityHome) { Icon(Icons.Default.Refresh, null) } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(viewModel.t("Мой дом", "Мій дім", "My home"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text(
                            if (profile?.isHostingActive == true) viewModel.t("Вы принимаете гостей", "Ви приймаєте гостей", "You are hosting guests")
                            else viewModel.t("Приём гостей выключен", "Прийом гостей вимкнено", "Hosting is off")
                        )
                        Button(onClick = viewModel::openHospitalityHostSettings, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Home, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Настройки дома", "Налаштування дому", "Host settings"))
                        }
                        OutlinedButton(onClick = viewModel::openHospitalityAvailability, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Календарь доступности", "Календар доступності", "Availability calendar"))
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(viewModel.t("Подтверждённая репутация гостеприимства", "Підтверджена репутація гостинності", "Verified hospitality reputation"), fontWeight = FontWeight.Bold)
                        Text(viewModel.t("Как хост: ${reputation?.verifiedStaysAsHost ?: 0}", "Як хост: ${reputation?.verifiedStaysAsHost ?: 0}", "As host: ${reputation?.verifiedStaysAsHost ?: 0}"))
                        Text(viewModel.t("Как гость: ${reputation?.verifiedStaysAsGuest ?: 0}", "Як гість: ${reputation?.verifiedStaysAsGuest ?: 0}", "As guest: ${reputation?.verifiedStaysAsGuest ?: 0}"))
                        Text(viewModel.t("Опубликованных отзывов: ${reputation?.publishedReviews ?: 0}", "Опублікованих відгуків: ${reputation?.publishedReviews ?: 0}", "Published reviews: ${reputation?.publishedReviews ?: 0}"))
                        if (reputation?.activeRestriction == true) Text(viewModel.t("Действует ограничение Hospitality", "Діє обмеження Hospitality", "A Hospitality restriction is active"), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
            item {
                Button(onClick = viewModel::openHospitalityRequests, modifier = Modifier.fillMaxWidth()) {
                    Text(viewModel.t("Мои заявки и визиты", "Мої заявки та візити", "My requests and stays"))
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(viewModel.t("Приватность адреса", "Приватність адреси", "Address privacy"), fontWeight = FontWeight.Bold)
                        Text(viewModel.t(
                            "Точный адрес и координаты открываются только участникам принятой заявки и хранятся на устройстве только в защищённом виде.",
                            "Точна адреса й координати відкриваються лише учасникам прийнятої заявки та зберігаються на пристрої тільки в захищеному вигляді.",
                            "Exact address and coordinates are revealed only to accepted-stay participants and are stored on-device only in protected form.",
                        ))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityHostSettingsScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    LaunchedEffect(Unit) { viewModel.refreshHospitalityHostProfile() }
    val current = viewModel.hospitalityHostProfile
    var active by remember(current) { mutableStateOf(current?.isHostingActive ?: false) }
    var publicArea by remember(current) { mutableStateOf(current?.publicAreaText.orEmpty()) }
    var exactAddress by remember(current) { mutableStateOf(current?.privateLocation?.exactAddress.orEmpty()) }
    var instructions by remember(current) { mutableStateOf(current?.privateLocation?.arrivalInstructions.orEmpty()) }
    var contact by remember(current) { mutableStateOf(current?.privateLocation?.arrivalContact.orEmpty()) }
    var maxGuests by remember(current) { mutableStateOf((current?.maxGuests ?: 1).toString()) }
    var maxDays by remember(current) { mutableStateOf((current?.maxDays ?: 7).toString()) }
    var minRating by remember(current) { mutableStateOf((current?.minRequiredRating ?: 0.0).toInt().toString()) }
    var rules by remember(current) { mutableStateOf(current?.houseRules?.joinToString("\n").orEmpty()) }
    var requiredTests by remember(current) { mutableStateOf(current?.requiredCompletedTests?.joinToString(",").orEmpty()) }
    var sleeping by remember(current) { mutableStateOf(current?.sleepingCondition ?: HospitalitySleepingCondition.SOFA) }
    var calendarMode by remember(current) { mutableStateOf(current?.availabilityMode == HospitalityAvailabilityMode.CALENDAR) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Мой дом", "Мій дім", "My home")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) },
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(viewModel.t("Готов принимать гостей", "Готовий приймати гостей", "Ready to host"), Modifier.weight(1f), fontWeight = FontWeight.Bold); Switch(active, { active = it }) } }
            item { Text(viewModel.t("Город: ${viewModel.cityLabel(viewModel.selectedCity)}", "Місто: ${viewModel.cityLabel(viewModel.selectedCity)}", "City: ${viewModel.cityLabel(viewModel.selectedCity)}")) }
            item { CitySelector(viewModel) }
            item { OutlinedTextField(publicArea, { publicArea = it.take(240) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Район / публичная зона", "Район / публічна зона", "Area / public location")) }) }
            item { OutlinedTextField(exactAddress, { exactAddress = it.take(500) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Точный адрес — приватно", "Точна адреса — приватно", "Exact address — private")) }) }
            item { OutlinedTextField(instructions, { instructions = it.take(1500) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Инструкции прибытия", "Інструкції прибуття", "Arrival instructions")) }, minLines = 2) }
            item { OutlinedTextField(contact, { contact = it.take(240) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Контакт для прибытия", "Контакт для прибуття", "Arrival contact")) }) }
            item {
                Text(viewModel.t("Спальное место", "Спальне місце", "Sleeping condition"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HospitalitySleepingCondition.entries.forEach { item -> FilterChip(selected = sleeping == item, onClick = { sleeping = item }, label = { Text(item.wire.replace('_', ' ')) }) }
                }
            }
            item { NumberField(viewModel.t("Максимум гостей", "Максимум гостей", "Max guests"), maxGuests) { maxGuests = it } }
            item { NumberField(viewModel.t("Максимум дней", "Максимум днів", "Max days"), maxDays) { maxDays = it } }
            item { NumberField(viewModel.t("Минимальный Account Rating", "Мінімальний Account Rating", "Minimum Account Rating"), minRating) { minRating = it } }
            item { OutlinedTextField(requiredTests, { requiredTests = it.take(600) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Обязательные научные системы", "Обов’язкові наукові системи", "Required scientific systems")) }, supportingText = { Text(viewModel.t("Через запятую. Хранятся только коды завершения.", "Через кому. Зберігаються лише коди завершення.", "Comma-separated completion codes only.")) }) }
            item { OutlinedTextField(rules, { rules = it.take(8000) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Правила дома", "Правила дому", "House rules")) }, minLines = 3) }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(calendarMode, { calendarMode = it }); Text(viewModel.t("Использовать календарь доступности", "Використовувати календар доступності", "Use availability calendar")) } }
            item {
                Button(
                    onClick = {
                        val tests = requiredTests.split(',').map(String::trim).filter { it.matches(Regex("f\\d{3}")) }
                        viewModel.saveHospitalityHostProfile(
                            active, publicArea, exactAddress, instructions, contact, sleeping,
                            maxGuests.toIntOrNull() ?: 1, maxDays.toIntOrNull() ?: 7, minRating.toDoubleOrNull() ?: 0.0,
                            tests, rules.lines(), if (calendarMode) HospitalityAvailabilityMode.CALENDAR else HospitalityAvailabilityMode.ALWAYS,
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(viewModel.t("Сохранить", "Зберегти", "Save")) }
            }
        }
    }
}

@Composable
private fun CitySelector(viewModel: MainViewModel) {
    LazyColumn(Modifier.fillMaxWidth().height(96.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        items(viewModel.cities.take(30)) { city ->
            Text(
                viewModel.cityLabel(city),
                modifier = Modifier.fillMaxWidth().clickable { viewModel.selectCity(city) }.padding(vertical = 6.dp),
                fontWeight = if (city == viewModel.selectedCity) FontWeight.Bold else FontWeight.Normal,
            )
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, { onChange(it.filter(Char::isDigit).take(3)) }, Modifier.fillMaxWidth(), label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityAvailabilityScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    LaunchedEffect(Unit) { viewModel.refreshHospitalityAvailability() }
    var from by remember { mutableStateOf("") }
    var to by remember { mutableStateOf("") }
    var capacity by remember { mutableStateOf("") }
    var available by remember { mutableStateOf(true) }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Календарь", "Календар", "Availability")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) },
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(viewModel.t("Интервалы [дата начала, дата окончания)", "Інтервали [дата початку, дата завершення)", "Intervals [start date, end date)"), fontWeight = FontWeight.Bold) }
            item { OutlinedTextField(from, { from = it.take(10) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Дата начала YYYY-MM-DD", "Дата початку YYYY-MM-DD", "Start date YYYY-MM-DD")) }) }
            item { OutlinedTextField(to, { to = it.take(10) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Выезд YYYY-MM-DD", "Виїзд YYYY-MM-DD", "Check-out YYYY-MM-DD")) }) }
            item { NumberField(viewModel.t("Capacity override (необязательно)", "Capacity override (необов'язково)", "Capacity override (optional)"), capacity) { capacity = it } }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(available, { available = it }); Text(if (available) viewModel.t("Доступно", "Доступно", "Available") else viewModel.t("Недоступно", "Недоступно", "Unavailable")) } }
            item { Button(onClick = { viewModel.addHospitalityAvailability(from, to, available, capacity.toIntOrNull()) }, modifier = Modifier.fillMaxWidth()) { Text(viewModel.t("Добавить интервал", "Додати інтервал", "Add interval")) } }
            items(viewModel.hospitalityAvailability, key = { it.availabilityId }) { row ->
                Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("${row.dateFrom} → ${row.dateTo}", fontWeight = FontWeight.Bold); Text(row.state.wire + (row.capacityOverride?.let { " · $it" } ?: "")) }; TextButton(onClick = { viewModel.deleteHospitalityAvailability(row.availabilityId) }) { Text(viewModel.t("Удалить", "Видалити", "Delete")) } } }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityRequestsScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    LaunchedEffect(Unit) { viewModel.refreshHospitalityRequests() }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Заявки и визиты", "Заявки та візити", "Requests & stays")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) },
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(viewModel.hospitalityRequests, key = { it.requestId }) { request -> RequestCard(viewModel, request) }
            if (viewModel.hospitalityRequests.isEmpty()) item { Text(viewModel.t("Заявок пока нет", "Заявок поки немає", "No requests yet")) }
        }
    }
}

@Composable
private fun RequestCard(viewModel: MainViewModel, request: StayRequest) {
    val incoming = request.hostGlobalId == viewModel.profile.globalId
    Card(Modifier.fillMaxWidth().clickable { viewModel.openHospitalityRequest(request) }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(if (incoming) viewModel.t("Входящий запрос", "Вхідний запит", "Incoming request") else viewModel.t("Исходящий запрос", "Вихідний запит", "Outgoing request"), fontWeight = FontWeight.Bold)
            Text("${request.checkInDate} → ${request.checkOutDate} · ${request.guestsCount}")
            Text(request.status.wire.uppercase(), color = MaterialTheme.colorScheme.primary)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityRequestDetailScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val request = viewModel.selectedStayRequest ?: return
    val incoming = request.hostGlobalId == viewModel.profile.globalId
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Запрос на проживание", "Запит на проживання", "Stay request")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) },
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("${request.checkInDate} → ${request.checkOutDate}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
            item { Text(viewModel.t("Гостей: ${request.guestsCount}", "Гостей: ${request.guestsCount}", "Guests: ${request.guestsCount}")) }
            item { Text(viewModel.t("Статус: ${request.status.wire}", "Статус: ${request.status.wire}", "Status: ${request.status.wire}"), fontWeight = FontWeight.Bold) }
            if (request.status == StayRequestStatus.PENDING && incoming) item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { viewModel.actOnHospitalityRequest("accept") }) { Text(viewModel.t("Принять", "Прийняти", "Accept")) }; OutlinedButton(onClick = { viewModel.actOnHospitalityRequest("reject") }) { Text(viewModel.t("Отклонить", "Відхилити", "Reject")) } } }
            if (request.status == StayRequestStatus.PENDING && !incoming) item { OutlinedButton(onClick = { viewModel.actOnHospitalityRequest("cancel_guest") }, modifier = Modifier.fillMaxWidth()) { Text(viewModel.t("Отменить заявку", "Скасувати заявку", "Cancel request")) } }
            if (request.status == StayRequestStatus.ACCEPTED) {
                item { Button(onClick = viewModel::openHospitalityStayDetails, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Map, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Данные прибытия", "Дані прибуття", "Arrival details")) } }
                if (incoming) item { OutlinedButton(onClick = { viewModel.actOnHospitalityRequest("cancel_host") }, modifier = Modifier.fillMaxWidth()) { Text(viewModel.t("Отменить принятый визит", "Скасувати прийнятий візит", "Cancel accepted stay")) } }
            }
            if (request.status == StayRequestStatus.COMPLETED) {
                item { CompletedStayEvidence(viewModel) }
                item { Button(onClick = viewModel::openHospitalityReview, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Reviews, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Оставить слепой отзыв", "Залишити сліпий відгук", "Leave blind review")) } }
            }
            item {
                OutlinedButton(onClick = {
                    val conv = viewModel.conversations.firstOrNull { it.id == request.conversationId }
                    if (conv != null) viewModel.openConversation(conv) else viewModel.openMessages()
                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Открыть чат", "Відкрити чат", "Open chat")) }
            }
        }
    }
}

@Composable
private fun CompletedStayEvidence(viewModel: MainViewModel) {
    val verification = viewModel.hospitalityVerification
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Shield, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Подтверждение фактического визита", "Підтвердження фактичного візиту", "Verify the actual stay"), fontWeight = FontWeight.Bold) }
            Text(if (verification?.verified == true) viewModel.t("Визит подтверждён обеими сторонами", "Візит підтверджено обома сторонами", "Stay verified by both participants") else viewModel.t("Календарное завершение само по себе не доказывает физическую встречу.", "Календарне завершення саме по собі не доводить фізичну зустріч.", "Calendar completion alone does not prove a physical stay."))
            if (verification?.verified != true) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { viewModel.confirmHospitalityStay(StayConfirmationValue.STAY_OCCURRED) }) { Text(viewModel.t("Визит состоялся", "Візит відбувся", "Stay occurred")) }
                    TextButton(onClick = { viewModel.confirmHospitalityStay(StayConfirmationValue.NO_SHOW) }) { Text(viewModel.t("Неявка", "Неявка", "No-show")) }
                    TextButton(onClick = { viewModel.confirmHospitalityStay(StayConfirmationValue.DISPUTE) }) { Text(viewModel.t("Спор", "Спір", "Dispute")) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityStayDetailsScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    LaunchedEffect(Unit) { viewModel.loadHospitalityArrivalDetails() }
    val details = viewModel.hospitalityArrivalDetails
    Scaffold(snackbarHost = { SnackbarHost(snackbar) }, topBar = { TopAppBar(title = { Text(viewModel.t("Данные прибытия", "Дані прибуття", "Arrival details")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (details == null) item { Text(viewModel.t("Приватные данные недоступны или загружаются", "Приватні дані недоступні або завантажуються", "Private details are unavailable or loading")) }
            else {
                item { Text(details.exactAddress, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
                if (details.arrivalInstructions.isNotBlank()) item { Text(details.arrivalInstructions) }
                if (details.arrivalContact.isNotBlank()) item { Text(viewModel.t("Контакт: ${details.arrivalContact}", "Контакт: ${details.arrivalContact}", "Contact: ${details.arrivalContact}")) }
                item { Button(onClick = viewModel::openHospitalityMap, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Map, null); Spacer(Modifier.width(8.dp)); Text(viewModel.t("Открыть точку на карте", "Відкрити точку на карті", "Open map")) } }
                item { Text(viewModel.t("Доступ действует до ${details.privateAccessExpiresAt}", "Доступ діє до ${details.privateAccessExpiresAt}", "Access valid until ${details.privateAccessExpiresAt}"), style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HospitalityReviewScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    var adequacy by remember { mutableStateOf("5") }
    var rules by remember { mutableStateOf("5") }
    var accuracy by remember { mutableStateOf("5") }
    var publicText by remember { mutableStateOf("") }
    var privateText by remember { mutableStateOf("") }
    val state = viewModel.hospitalityReviewState
    Scaffold(snackbarHost = { SnackbarHost(snackbar) }, topBar = { TopAppBar(title = { Text(viewModel.t("Слепой отзыв", "Сліпий відгук", "Blind review")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(viewModel.t("Ваш отзыв не раскрывается второй стороне до её ответа или окончания 7-дневного окна.", "Ваш відгук не розкривається другій стороні до її відповіді або завершення 7-денного вікна.", "Your review stays hidden from the other participant until they submit theirs or the 7-day window closes.")) }
            item { NumberField(viewModel.t("Адекватность 1–5", "Адекватність 1–5", "Adequacy 1–5"), adequacy) { adequacy = it.take(1) } }
            item { NumberField(viewModel.t("Соблюдение правил 1–5", "Дотримання правил 1–5", "Rules compliance 1–5"), rules) { rules = it.take(1) } }
            item { NumberField(viewModel.t("Соответствие описанию 1–5", "Відповідність опису 1–5", "Description accuracy 1–5"), accuracy) { accuracy = it.take(1) } }
            item { OutlinedTextField(publicText, { publicText = it.take(4000) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Публичный отзыв", "Публічний відгук", "Public review")) }, minLines = 3) }
            item { OutlinedTextField(privateText, { privateText = it.take(4000) }, Modifier.fillMaxWidth(), label = { Text(viewModel.t("Закрытая обратная связь модерации", "Закритий зворотний зв'язок модерації", "Private moderation feedback")) }, minLines = 2) }
            item { Button(enabled = state?.canSubmit != false, onClick = { viewModel.submitHospitalityReview((adequacy.toIntOrNull() ?: 5).coerceIn(1,5), (rules.toIntOrNull() ?: 5).coerceIn(1,5), (accuracy.toIntOrNull() ?: 5).coerceIn(1,5), publicText.ifBlank { null }, privateText.ifBlank { null }) }, modifier = Modifier.fillMaxWidth()) { Text(if (state?.ownSubmitted == true) viewModel.t("Обновить до публикации", "Оновити до публікації", "Update before publication") else viewModel.t("Отправить отзыв", "Надіслати відгук", "Submit review")) } }
            item { HorizontalDivider() }
            item { Text(viewModel.t("Опубликовано отзывов по этому визиту: ${state?.publishedReviewCount ?: 0}", "Опубліковано відгуків за цим візитом: ${state?.publishedReviewCount ?: 0}", "Published reviews for this stay: ${state?.publishedReviewCount ?: 0}")) }
        }
    }
}
