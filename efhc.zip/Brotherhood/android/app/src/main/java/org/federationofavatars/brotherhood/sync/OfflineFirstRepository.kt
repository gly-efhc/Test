package org.federationofavatars.brotherhood.sync

import org.federationofavatars.brotherhood.data.BrotherhoodCacheStore
import org.federationofavatars.brotherhood.network.BrotherhoodApi

class OfflineFirstRepository(
    private val cache: BrotherhoodCacheStore,
    private val api: BrotherhoodApi
) {
    suspend fun cachedThenNetwork(cacheKey: String, path: String, token: String, ttlMs: Long): String {
        val cached = cache.get(cacheKey, allowStale = true)
        return runCatching {
            api.get(path, token).also { cache.put(cacheKey, it, ttlMs, entityType = path.substringBefore("/", "api")) }
        }.getOrElse { cached ?: throw it }
    }

    suspend fun writeOrQueue(operation: String, path: String, json: String, token: String): Boolean {
        return runCatching {
            when (operation.uppercase()) {
                "PUT", "PUT_PROFILE", "PUT_PERSONALITY", "PUT_ASSESSMENT", "PUT_CALIBRATION_CONSENT" -> api.put(path, json, token)
                else -> api.post(path, json, token)
            }
            true
        }.getOrElse {
            cache.enqueueMutation(operation, json, path = path, dedupeKey = "$operation:$path")
            false
        }
    }


    suspend fun flushPending(token: String): Int {
        var sent = 0
        for (mutation in cache.pendingMutations()) {
            val result = runCatching {
                when (mutation.operation.uppercase()) {
                    "PUT", "PUT_PROFILE", "PUT_PERSONALITY", "PUT_ASSESSMENT", "PUT_CALIBRATION_CONSENT" -> api.put(mutation.path, mutation.payload, token)
                    else -> api.post(mutation.path, mutation.payload, token)
                }
            }
            if (result.isSuccess) {
                cache.markMutationSuccess(mutation.id)
                sent += 1
            } else {
                cache.markMutationFailure(mutation.id, result.exceptionOrNull()?.message ?: "sync_error")
            }
        }
        if (sent > 0) cache.markSuccessfulSync()
        return sent
    }
}
