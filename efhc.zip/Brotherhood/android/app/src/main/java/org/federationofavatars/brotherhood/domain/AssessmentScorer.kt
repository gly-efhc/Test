package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentModelVersions
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.DimensionScore

/** Server-equivalent deterministic scorer for the active scientific questionnaire v1. */
object AssessmentScorer {
    fun score(
        definition: AssessmentDefinition,
        answers: Map<String, Int>,
        responseLatencyMs: Map<String, Long> = emptyMap(),
        selectionChanges: Map<String, Int> = emptyMap(),
        questionPositions: Map<String, Int> = emptyMap(),
        startedAtEpochMs: Long = System.currentTimeMillis(),
    ): AssessmentResult {
        require(definition.questions.all { answers[it.id] in 1..4 }) { "Every scientific assessment item requires an answer 1..4" }
        val evidence = linkedMapOf<String, MutableList<Int>>()
        definition.questions.forEach { question ->
            val selected = question.choices[answers.getValue(question.id) - 1]
            selected.latentLoadings.forEach { (construct, loading) -> evidence.getOrPut(construct) { mutableListOf() }.add(loading) }
        }
        val dimensions = evidence.map { (construct, loadings) ->
            val mean = loadings.average().coerceIn(-2.0, 2.0)
            DimensionScore(construct, construct, (50.0 + mean * 25.0).roundToInt().coerceIn(0, 100))
        }.sortedBy { it.id }
        val total = dimensions.map { it.score }.average().takeUnless(Double::isNaN)?.roundToInt()?.coerceIn(0,100) ?: 50
        val consistency = internalCoherence(definition, answers)
        return AssessmentResult(
            assessmentId=definition.id,modelVersion=AssessmentModelVersions.ACTIVE,stimulusVersion=AssessmentCatalog.INSTRUMENT_VERSION,
            startedAtEpochMs=startedAtEpochMs,totalScore=total,riskScore=0,label="Профиль направления обновлён",
            summary="Завершён научно-трассируемый тест «${definition.title}».",dimensions=dimensions,answerConsistency=consistency,responseTrace=emptyList(),idealizedSelfPresentation=0
        )
    }
    private fun internalCoherence(definition: AssessmentDefinition, answers: Map<String, Int>): Int {
        val values=mutableMapOf<String,MutableList<Int>>()
        definition.questions.forEach { q -> q.choices[answers.getValue(q.id)-1].latentLoadings.forEach { (k,v)->values.getOrPut(k){mutableListOf()}.add(v) } }
        val d=values.values.mapNotNull { rows -> if(rows.size<2)null else { val m=rows.average(); rows.map { abs(it-m) }.average() } }
        return if(d.isEmpty()) 100 else (100-d.average()/4.0*100).roundToInt().coerceIn(0,100)
    }
}
