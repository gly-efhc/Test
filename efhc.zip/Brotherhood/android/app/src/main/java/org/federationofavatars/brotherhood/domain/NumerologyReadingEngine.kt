package org.federationofavatars.brotherhood.domain

import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class NumerologyPinnacle(
    val index: Int,
    val number: Int,
    val reachedAtAge: Int,
)

data class BirthChartCharacteristic(
    val key: String,
    val digit: Int?,
    val count: Int,
    val special: Boolean = false,
)

data class NumerologyReading(
    /** Separate reference/self-analysis life-path calculation; not used by Vedic friendship compatibility. */
    val lifePathNumber: Int,
    /** Existing canonical date-based soul number used by the Vedic profile. */
    val dateSoulNumber: Int,
    val dateDestinyNumber: Int,
    val dateMaturityNumber: Int,
    /** Optional source-model name-vowel number; descriptive only. */
    val nameSoulNumber: Int?,
    /** Optional source-model consonant expression number; descriptive only. */
    val expressionNumber: Int?,
    val birthChart: List<BirthChartCharacteristic>,
    val missingBirthChartDigits: List<Int>,
    val specialBirthChartKeys: List<String>,
    val pinnacles: List<NumerologyPinnacle>,
)

/**
 * Extended self-analysis derived from the user-supplied Numerology reference material.
 *
 * This object is deliberately separated from [VedicNumerologyEngine]. The production friendship
 * compatibility score remains date-based only, but active Q28 exposes it as its own independent
 * 0..100 metric. Name-derived numbers here are descriptive profile material only and never enter compatibility.
 */
object NumerologyReadingEngine {
    private val pythagorean = mapOf(
        'A' to 1, 'B' to 2, 'C' to 3, 'D' to 4, 'E' to 5, 'F' to 6, 'G' to 7, 'H' to 8, 'I' to 9,
        'J' to 1, 'K' to 2, 'L' to 3, 'M' to 4, 'N' to 5, 'O' to 6, 'P' to 7, 'Q' to 8, 'R' to 9,
        'S' to 1, 'T' to 2, 'U' to 3, 'V' to 4, 'W' to 5, 'X' to 6, 'Y' to 7, 'Z' to 8,
    )
    private val vowels = setOf('A', 'E', 'I', 'O', 'U', 'Y')

    fun calculate(
        date: LocalDate,
        latinName: String?,
        canonical: org.federationofavatars.brotherhood.model.VedicNumerologyProfile =
            VedicNumerologyEngine.calculate(date, latinName),
    ): NumerologyReading {
        val lifePath = referenceLifePath(date)
        val counts = birthChartCounts(date)
        val normal = counts.entries
            .filter { it.value > 0 }
            .sortedBy { it.key }
            .map { (digit, count) ->
                val key = chartKey(digit, count)
                BirthChartCharacteristic(key = key, digit = digit, count = count)
            }
        val special = isolatedAndMissingKeys(counts)
        val nameNumbers = nameNumbers(latinName)
        val firstPeakAge = (36 - lifePath).coerceAtLeast(0)
        val peakNumbers = pinnacleNumbers(date)
        return NumerologyReading(
            lifePathNumber = lifePath,
            dateSoulNumber = canonical.soulNumber,
            dateDestinyNumber = canonical.destinyNumber,
            dateMaturityNumber = canonical.maturityNumber,
            nameSoulNumber = nameNumbers.first,
            expressionNumber = nameNumbers.second,
            birthChart = normal,
            missingBirthChartDigits = counts.filterValues { it == 0 }.keys.sorted(),
            specialBirthChartKeys = special,
            pinnacles = peakNumbers.mapIndexed { index, number ->
                NumerologyPinnacle(index = index + 1, number = number, reachedAtAge = firstPeakAge + index * 9)
            },
        )
    }

    fun referenceLifePath(date: LocalDate): Int {
        val digits = date.format(DateTimeFormatter.ofPattern("ddMMyyyy"))
        return reduceKeepingMasters(digits.sumOf { it.digitToInt() }, setOf(10, 11, 22))
    }

    fun birthChartCounts(date: LocalDate): Map<Int, Int> {
        val digits = date.format(DateTimeFormatter.ofPattern("ddMMyyyy"))
        return (1..9).associateWith { digit -> digits.count { it.digitToInt() == digit } }
    }

    fun chartKey(digit: Int, count: Int): String {
        require(digit in 1..9)
        require(count > 0)
        val max = when (digit) {
            4 -> 4
            9 -> 6
            else -> 5
        }
        return digit.toString().repeat(count.coerceAtMost(max))
    }

    fun isolatedAndMissingKeys(counts: Map<Int, Int>): List<String> {
        fun present(n: Int) = (counts[n] ?: 0) > 0
        val result = mutableListOf<String>()
        // Reproduces the reference chart-isolation relationships without importing its runtime.
        if (!present(5)) {
            if (present(1) && !present(2) && !present(4)) result += "1CL"
            if (present(3) && !present(2) && !present(6)) result += "3CL"
            if (present(7) && !present(4) && !present(8)) result += "7CL"
            if (present(9) && !present(6) && !present(8)) result += "9CL"
        }
        if (!present(7)) result += "Not7"
        if (!present(9)) result += "Not9"
        return result
    }

    fun pinnacleNumbers(date: LocalDate): List<Int> {
        val left = digitalRoot(date.monthValue)
        val middle = digitalRoot(date.dayOfMonth)
        val right = digitalRoot(date.year.toString().sumOf { it.digitToInt() })
        val first = digitalRoot(left + middle)
        val second = digitalRoot(middle + right)
        val third = reduceKeepingMasters(first + second, setOf(10, 11))
        val fourth = reduceKeepingMasters(left + right, setOf(10, 11))
        return listOf(first, second, third, fourth)
    }

    fun nameNumbers(latinName: String?): Pair<Int?, Int?> {
        val letters = latinName.orEmpty().uppercase().filter { it in 'A'..'Z' }
        if (letters.isBlank()) return null to null
        val soulValues = letters.filter { it in vowels }.mapNotNull(pythagorean::get)
        val outerValues = letters.filter { it !in vowels }.mapNotNull(pythagorean::get)
        val soul = soulValues.takeIf { it.isNotEmpty() }?.sum()?.let {
            reduceKeepingMasters(it, setOf(1, 10, 11))
        }
        val outer = outerValues.takeIf { it.isNotEmpty() }?.sum()?.let {
            reduceKeepingMasters(it, setOf(1, 10, 11, 22))
        }
        return soul to outer
    }

    private fun reduceKeepingMasters(number: Int, masters: Set<Int>): Int {
        require(number >= 0)
        var current = number
        while (current > 9 && current !in masters) {
            current = current.toString().sumOf { it.digitToInt() }
        }
        return current
    }

    private fun digitalRoot(number: Int): Int {
        if (number == 0) return 0
        var current = number
        while (current > 9) current = current.toString().sumOf { it.digitToInt() }
        return current
    }
}
