package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.DesiredQuality
import org.federationofavatars.brotherhood.model.SearchIntent
import org.federationofavatars.brotherhood.model.SearchRole

data class LocalizedTraitText(val ru: String, val uk: String, val en: String) {
    fun get(language: AppLanguage): String = language.pick(ru, uk, en)
}

data class LatentTraitDefinition(
    val key: String,
    val highPositive: LocalizedTraitText,
    val lowPositive: LocalizedTraitText,
    val balancedPositive: LocalizedTraitText,
    val researchAnchors: List<String>,
)

data class QualityTraitTarget(
    val traitKey: String,
    val targetScore: Int,
    val weight: Int = 1,
) {
    init {
        require(targetScore in 0..100)
        require(weight in 1..5)
    }
}

data class SearchQualityDefinition(
    val key: String,
    val targets: List<QualityTraitTarget>,
    val label: LocalizedTraitText,
    val group: String,
) {
    init { require(targets.isNotEmpty()) }
}

/**
 * Brotherhood latent ontology v1.
 *
 * The catalog intentionally contains no "bad" pole. Both ends receive a contextually positive
 * description. Raw coordinates are internal matching data and must not be shown to users.
 * Research anchors name construct families only; restricted third-party questionnaire items are
 * not copied into Brotherhood.
 */
object LatentTraitCatalog {
    private fun t(key: String, highRu: String, lowRu: String, balancedRu: String, highEn: String, lowEn: String, balancedEn: String, anchors: List<String>) =
        LatentTraitDefinition(
            key,
            LocalizedTraitText(highRu, highRu, highEn),
            LocalizedTraitText(lowRu, lowRu, lowEn),
            LocalizedTraitText(balancedRu, balancedRu, balancedEn),
            anchors,
        )

    val traits: List<LatentTraitDefinition> = listOf(
        t("dependability", "Надёжность и последовательность", "Гибкость при изменении договорённостей", "Баланс надёжности и гибкости", "Dependability and consistency", "Flexibility when plans change", "Balanced dependability and flexibility", listOf("O*NET Work Styles", "Big Five conscientiousness")),
        t("integrity_sincerity", "Искренность и принципиальность", "Практичность и стратегичность", "Баланс принципов и прагматизма", "Sincerity and principled conduct", "Pragmatic strategic style", "Balanced principles and pragmatism", listOf("HEXACO Honesty-Humility", "O*NET Integrity")),
        t("confidentiality", "Дискретность и сохранение доверенного", "Открытость и свободный обмен информацией", "Контекстное чувство приватности", "Discretion and confidentiality", "Open information-sharing style", "Context-sensitive privacy", listOf("friendship boundaries")),
        t("reciprocity", "Взаимность и обмен поддержкой", "Независимость от взаимного обмена", "Баланс взаимности и автономии", "Reciprocity and mutual support", "Independence from reciprocal exchange", "Balanced reciprocity and autonomy", listOf("friendship reciprocity")),
        t("support_availability", "Высокая готовность быть рядом", "Уважение к самостоятельному решению проблем", "Баланс присутствия и самостоятельности", "High availability for support", "Respect for independent coping", "Balanced support and autonomy", listOf("friendship support research")),
        t("empathy", "Эмпатичность и чувствительность к состоянию других", "Эмоциональная сдержанность и объективность", "Баланс эмпатии и объективности", "Empathic attunement", "Emotional reserve and objectivity", "Balanced empathy and objectivity", listOf("O*NET Empathy", "HEXACO Emotionality")),
        t("directness", "Прямота и ясность", "Дипломатичность и осторожность формулировок", "Баланс прямоты и дипломатии", "Directness and clarity", "Diplomatic communication", "Balanced directness and diplomacy", listOf("interpersonal communication")),
        t("tact", "Такт и бережная подача", "Жёсткая предметность", "Баланс такта и предметности", "Tactful delivery", "Hard-edged task focus", "Balanced tact and task focus", listOf("interpersonal communication")),
        t("forgiveness", "Готовность восстанавливать отношения", "Долгая память на нарушения границ", "Избирательное восстановление доверия", "Readiness to repair relationships", "Strong memory for boundary violations", "Selective trust repair", listOf("friendship conflict repair")),
        t("boundary_respect", "Уважение автономии и границ", "Высокая вовлечённость и близость", "Баланс близости и границ", "Respect for autonomy and boundaries", "High interpersonal involvement", "Balanced closeness and boundaries", listOf("friendship boundaries")),
        t("autonomy", "Самостоятельность", "Ориентация на совместные решения", "Баланс самостоятельности и совместности", "Autonomy", "Collaborative decision orientation", "Balanced autonomy and collaboration", listOf("interpersonal agency")),
        t("social_energy", "Социальная энергия", "Комфорт в камерном общении", "Гибкий социальный ритм", "Social energy", "Comfort with low-stimulation interaction", "Flexible social rhythm", listOf("Big Five extraversion", "HEXACO Extraversion")),
        t("contact_intensity", "Потребность в частом контакте", "Комфорт с редким, но содержательным контактом", "Умеренная частота контакта", "Preference for frequent contact", "Comfort with infrequent but meaningful contact", "Moderate contact frequency", listOf("friendship expectations")),
        t("response_urgency", "Быстрая реакция на сообщения", "Неспешный асинхронный стиль", "Контекстная скорость ответа", "Fast response style", "Asynchronous unhurried style", "Context-sensitive response pace", listOf("friendship expectations")),
        t("spontaneity", "Спонтанность и лёгкость на подъём", "Предсказуемость и подготовка", "Баланс спонтанности и планирования", "Spontaneity", "Predictability and preparation", "Balanced spontaneity and planning", listOf("Big Five openness", "friendship expectations")),
        t("planning", "Планирование и структурирование", "Импровизация и адаптация по ходу", "Гибкое планирование", "Planning and structure", "Improvisation in motion", "Flexible planning", listOf("O*NET Attention to Detail", "Big Five conscientiousness")),
        t("conflict_engagement", "Готовность обсуждать напряжение прямо", "Способность дать конфликту остыть", "Гибкий стиль разрешения конфликтов", "Direct conflict engagement", "Ability to let conflict cool", "Flexible conflict style", listOf("friendship conflict research")),
        t("self_control", "Самоконтроль под давлением", "Эмоциональная выразительность", "Баланс контроля и выразительности", "Self-control under pressure", "Emotional expressiveness", "Balanced control and expression", listOf("O*NET Self-Control")),
        t("status_independence", "Независимость от статуса и иерархии", "Чуткость к статусу и структуре влияния", "Контекстное чувство иерархии", "Status independence", "Sensitivity to status and influence", "Context-sensitive hierarchy awareness", listOf("HEXACO Honesty-Humility")),
        t("competitiveness", "Соревновательность и стремление выигрывать", "Кооперативность без стремления доминировать", "Баланс соревнования и сотрудничества", "Competitive drive", "Non-dominating cooperation", "Balanced competition and cooperation", listOf("organizational psychology")),
        t("fairness", "Ориентация на справедливый обмен", "Гибкость в распределении ресурсов", "Контекстная справедливость", "Fair exchange orientation", "Flexible resource allocation", "Context-sensitive fairness", listOf("organizational justice", "friendship reciprocity")),
        t("trust_openness", "Готовность быстро давать доверие", "Осторожное накопление доверия", "Постепенное доверие", "Fast trust openness", "Cautious trust-building", "Gradual trust-building", listOf("interpersonal trust")),
        t("vulnerability_comfort", "Комфорт с эмоциональной открытостью", "Сдержанная приватность переживаний", "Избирательная открытость", "Comfort with vulnerability", "Private emotional style", "Selective openness", listOf("friendship intimacy")),
        t("humor_tolerance", "Широкая терпимость к острому юмору", "Бережные границы юмора", "Контекстное чувство юмора", "Broad tolerance for edgy humour", "Protective humour boundaries", "Context-sensitive humour", listOf("friendship expectations")),
        t("group_orientation", "Командность и групповая вовлечённость", "Индивидуальная независимость", "Баланс группы и индивидуальности", "Group orientation", "Individual independence", "Balanced group and individual orientation", listOf("social orientation", "interpersonal communion")),
        t("independence", "Независимость суждений", "Открытость к групповому согласованию", "Баланс самостоятельности и согласования", "Independent judgment", "Group-consensus orientation", "Balanced independence and consensus", listOf("interpersonal agency")),
        t("optimism", "Оптимизм и позитивный настрой", "Реалистичная настороженность", "Сбалансированный реализм", "Optimism", "Realistic vigilance", "Balanced realism", listOf("O*NET Optimism")),
        t("emotional_intensity", "Эмоциональная насыщенность", "Эмоциональная стабильность и ровность", "Умеренная эмоциональная интенсивность", "Emotional intensity", "Emotional steadiness", "Moderate emotional intensity", listOf("HEXACO Emotionality")),
        t("risk_tolerance", "Смелость в неопределённости", "Осторожность и защита от риска", "Взвешенный риск", "Risk tolerance", "Risk caution", "Measured risk-taking", listOf("O*NET Cautiousness")),
        t("decisiveness", "Решительность и скорость выбора", "Взвешенность и дополнительная проверка", "Баланс скорости и проверки", "Decisiveness", "Deliberation and verification", "Balanced speed and verification", listOf("leadership research")),
        t("assertiveness", "Напористость и способность отстаивать позицию", "Мягкость и ненавязчивость", "Уверенная гибкость", "Assertiveness", "Gentle non-imposing style", "Flexible assertiveness", listOf("Big Five extraversion/assertiveness")),
        t("leadership_orientation", "Лидерская направленность", "Комфорт в роли сильного исполнителя", "Гибкость роли лидер/исполнитель", "Leadership orientation", "Strong contributor orientation", "Flexible leader/contributor role", listOf("O*NET Leadership Orientation")),
        t("adaptability", "Адаптивность к изменениям", "Стабильность и верность проверенному порядку", "Баланс адаптации и устойчивости", "Adaptability", "Stability and preference for proven routines", "Balanced adaptability and stability", listOf("O*NET Adaptability")),
        t("perseverance", "Настойчивость и доведение до результата", "Готовность вовремя менять направление", "Баланс настойчивости и переключения", "Perseverance", "Readiness to change direction", "Balanced persistence and switching", listOf("O*NET Perseverance")),
        t("attention_to_detail", "Внимание к деталям", "Фокус на общей картине", "Баланс деталей и целого", "Attention to detail", "Big-picture focus", "Balanced detail and big-picture focus", listOf("O*NET Attention to Detail")),
        t("cautiousness", "Осторожность и проверка последствий", "Скорость и готовность действовать до полной ясности", "Взвешенная осторожность", "Cautiousness", "Fast action before full certainty", "Measured caution", listOf("O*NET Cautiousness")),
        t("cooperation", "Кооперативность", "Сильная индивидуальная ответственность", "Баланс сотрудничества и личной ответственности", "Cooperation", "Strong individual responsibility", "Balanced cooperation and ownership", listOf("O*NET Cooperation")),
        t("initiative", "Инициативность", "Дисциплинированное следование заданной рамке", "Баланс инициативы и исполнения", "Initiative", "Disciplined execution within a defined frame", "Balanced initiative and execution", listOf("O*NET Initiative")),
        t("innovation", "Изобретательность и поиск новых подходов", "Опора на проверенные решения", "Баланс инноваций и проверенных практик", "Innovation", "Preference for proven solutions", "Balanced innovation and proven practice", listOf("O*NET Innovation")),
        t("intellectual_curiosity", "Интеллектуальная любознательность", "Практическая концентрация на необходимом", "Баланс исследования и практичности", "Intellectual curiosity", "Practical focus on what is needed", "Balanced curiosity and practicality", listOf("O*NET Intellectual Curiosity", "Big Five openness")),
        t("achievement_orientation", "Высокая ориентация на достижения", "Ориентация на устойчивый темп без гонки", "Баланс амбиции и устойчивости", "Achievement orientation", "Sustainable pace without constant competition", "Balanced ambition and sustainability", listOf("O*NET Achievement Orientation")),
        t("stress_tolerance", "Устойчивость в стрессовой среде", "Чувствительность к перегрузке и раннее снижение нагрузки", "Осознанное управление нагрузкой", "Stress tolerance", "Sensitivity to overload and early load reduction", "Aware load management", listOf("O*NET Stress Tolerance")),
        t("ambiguity_tolerance", "Комфорт в неопределённости", "Потребность в ясности и правилах", "Баланс неопределённости и структуры", "Tolerance for ambiguity", "Preference for clarity and rules", "Balanced ambiguity and structure", listOf("O*NET Tolerance for Ambiguity")),
        t("self_confidence", "Уверенность в своих решениях", "Склонность перепроверять себя и учитывать обратную связь", "Уверенность с открытостью к корректировке", "Self-confidence", "Self-checking and feedback sensitivity", "Confident openness to correction", listOf("O*NET Self-Confidence")),
        t("humility", "Скромность и отсутствие потребности подчёркивать статус", "Яркая самопрезентация", "Уверенная, но умеренная самопрезентация", "Humility", "Strong self-presentation", "Confident but measured self-presentation", listOf("O*NET Humility", "HEXACO Honesty-Humility")),
        t("family_orientation", "Высокая ориентация на семью и близкий круг", "Высокая автономность социальных сфер", "Баланс семьи и внешних связей", "Family orientation", "High autonomy between social spheres", "Balanced family and external ties", listOf("friendship context")),
        t("money_discipline", "Финансовая дисциплина", "Гибкость в денежных договорённостях", "Контекстная финансовая дисциплина", "Financial discipline", "Flexibility in money arrangements", "Context-sensitive financial discipline", listOf("business partnership context")),
        t("time_discipline", "Пунктуальность и уважение времени", "Гибкость времени и событийный ритм", "Баланс пунктуальности и гибкости", "Time discipline", "Flexible event-driven time style", "Balanced punctuality and flexibility", listOf("O*NET Dependability")),
        t("resource_generosity", "Щедрость ресурсами и помощью", "Бережное управление личными ресурсами", "Баланс щедрости и ресурсных границ", "Resource generosity", "Protective resource management", "Balanced generosity and resource boundaries", listOf("friendship reciprocity")),
        t("rule_orientation", "Последовательность правил и стандартов", "Ситуативная гибкость правил", "Баланс правил и исключений", "Rule orientation", "Situational rule flexibility", "Balanced rules and exceptions", listOf("O*NET Conscientious and Rule Oriented")),
    )

    val byKey: Map<String, LatentTraitDefinition> = traits.associateBy { it.key }

    private fun qt(trait: String, target: Int, weight: Int = 1) = QualityTraitTarget(trait, target, weight)

    private fun q(key: String, trait: String, target: Int, ru: String, uk: String, en: String, group: String) =
        SearchQualityDefinition(key, listOf(qt(trait, target)), LocalizedTraitText(ru, uk, en), group)

    private fun qc(
        key: String,
        targets: List<QualityTraitTarget>,
        ru: String,
        uk: String,
        en: String,
        group: String,
    ) = SearchQualityDefinition(key, targets, LocalizedTraitText(ru, uk, en), group)

    val qualities: List<SearchQualityDefinition> = listOf(
        q("reliable", "dependability", 85, "Надёжный", "Надійний", "Reliable", "friendship"),
        q("principled", "integrity_sincerity", 85, "Принципиальный", "Принциповий", "Principled", "character"),
        q("discreet", "confidentiality", 85, "Умеет хранить доверенное", "Уміє зберігати довірене", "Discreet", "friendship"),
        q("reciprocal", "reciprocity", 85, "Взаимный", "Взаємний", "Reciprocal", "friendship"),
        q("supportive", "support_availability", 85, "Готов поддержать", "Готовий підтримати", "Supportive", "friendship"),
        q("empathetic", "empathy", 85, "Эмпатичный", "Емпатичний", "Empathetic", "character"),
        q("objective", "empathy", 25, "Объективный и эмоционально сдержанный", "Об'єктивний та емоційно стриманий", "Objective and emotionally reserved", "character"),
        q("direct", "directness", 85, "Прямой", "Прямий", "Direct", "communication"),
        q("diplomatic", "directness", 25, "Дипломатичный", "Дипломатичний", "Diplomatic", "communication"),
        q("tactful", "tact", 85, "Тактичный", "Тактовний", "Tactful", "communication"),
        q("forgiving", "forgiveness", 80, "Готов восстанавливать отношения", "Готовий відновлювати стосунки", "Repair-oriented", "friendship"),
        q("boundaries", "boundary_respect", 85, "Уважает личные границы", "Поважає особисті межі", "Respects boundaries", "friendship"),
        q("independent", "autonomy", 85, "Самостоятельный", "Самостійний", "Autonomous", "character"),
        q("collaborative_decisions", "autonomy", 25, "Любит совместные решения", "Любить спільні рішення", "Collaborative decision-maker", "character"),
        q("social", "social_energy", 85, "Общительный", "Товариський", "Socially energetic", "communication"),
        q("calm_social", "social_energy", 25, "Комфортный в спокойном общении", "Комфортний у спокійному спілкуванні", "Comfortable in low-key interaction", "communication"),
        q("frequent_contact", "contact_intensity", 85, "Любит частое общение", "Любить часте спілкування", "Prefers frequent contact", "friendship"),
        q("low_maintenance", "contact_intensity", 25, "Комфортен с редким контактом", "Комфортний з рідким контактом", "Low-maintenance contact style", "friendship"),
        q("fast_response", "response_urgency", 85, "Быстро отвечает", "Швидко відповідає", "Fast responder", "communication"),
        q("spontaneous", "spontaneity", 85, "Лёгкий на подъём", "Легкий на підйом", "Spontaneous", "lifestyle"),
        q("planner", "planning", 85, "Организованный и планирующий", "Організований та плановий", "Planner", "lifestyle"),
        q("conflict_direct", "conflict_engagement", 85, "Не избегает сложных разговоров", "Не уникає складних розмов", "Engages difficult conversations", "friendship"),
        q("cool_down", "conflict_engagement", 25, "Умеет дать конфликту остыть", "Уміє дати конфлікту охолонути", "Lets conflict cool before resolving", "friendship"),
        q("self_controlled", "self_control", 85, "Самоконтроль", "Самоконтроль", "Self-controlled", "character"),
        q("status_independent", "status_independence", 85, "Не зависит от статуса", "Не залежить від статусу", "Status-independent", "character"),
        q("competitive", "competitiveness", 85, "Соревновательный", "Змагальний", "Competitive", "business"),
        q("cooperative", "competitiveness", 25, "Несоревновательный командный стиль", "Незмагальний командний стиль", "Non-competitive team style", "business"),
        q("fair", "fairness", 85, "Справедливый", "Справедливий", "Fair", "character"),
        q("trusting", "trust_openness", 80, "Быстро открывает доверие", "Швидко відкриває довіру", "Quick to trust", "friendship"),
        q("careful_trust", "trust_openness", 25, "Осторожно наращивает доверие", "Обережно нарощує довіру", "Builds trust cautiously", "friendship"),
        q("emotionally_open", "vulnerability_comfort", 80, "Эмоционально открытый", "Емоційно відкритий", "Emotionally open", "friendship"),
        q("private", "vulnerability_comfort", 25, "Сдержанный и приватный", "Стриманий та приватний", "Private and reserved", "friendship"),
        q("edgy_humor", "humor_tolerance", 85, "Любит острый юмор", "Любить гострий гумор", "Comfortable with edgy humour", "friendship"),
        q("gentle_humor", "humor_tolerance", 25, "Предпочитает бережный юмор", "Віддає перевагу делікатному гумору", "Prefers gentle humour", "friendship"),
        q("team_oriented", "group_orientation", 85, "Командный", "Командний", "Team-oriented", "business"),
        q("independent_judgment", "independence", 85, "Независимое мнение", "Незалежна думка", "Independent judgment", "character"),
        q("optimistic", "optimism", 85, "Оптимистичный", "Оптимістичний", "Optimistic", "character"),
        q("realistic_vigilance", "optimism", 25, "Реалистично осторожный", "Реалістично обережний", "Realistically vigilant", "character"),
        q("emotionally_intense", "emotional_intensity", 85, "Эмоционально насыщенный", "Емоційно насичений", "Emotionally intense", "character"),
        q("emotionally_steady", "emotional_intensity", 25, "Эмоционально ровный", "Емоційно рівний", "Emotionally steady", "character"),
        q("risk_taker", "risk_tolerance", 85, "Смелый в риске", "Сміливий у ризику", "Risk-tolerant", "business"),
        q("cautious", "risk_tolerance", 25, "Осторожный", "Обережний", "Cautious", "business"),
        q("decisive", "decisiveness", 85, "Решительный", "Рішучий", "Decisive", "leadership"),
        q("deliberate", "decisiveness", 25, "Взвешенный", "Виважений", "Deliberate", "leadership"),
        q("assertive", "assertiveness", 85, "Напористый", "Наполегливий", "Assertive", "leadership"),
        q("soft_style", "assertiveness", 25, "Мягкий стиль", "М'який стиль", "Gentle style", "leadership"),
        q("leader", "leadership_orientation", 85, "Лидерский", "Лідерський", "Leadership-oriented", "leadership"),
        q("strong_contributor", "leadership_orientation", 25, "Сильный исполнитель", "Сильний виконавець", "Strong contributor", "leadership"),
        q("adaptable", "adaptability", 85, "Адаптивный", "Адаптивний", "Adaptable", "business"),
        q("stable_routine", "adaptability", 25, "Стабильный и последовательный", "Стабільний та послідовний", "Stable and routine-oriented", "business"),
        q("persistent", "perseverance", 85, "Настойчивый", "Наполегливий", "Persistent", "business"),
        q("detail_oriented", "attention_to_detail", 85, "Внимательный к деталям", "Уважний до деталей", "Detail-oriented", "business"),
        q("big_picture", "attention_to_detail", 25, "Видит общую картину", "Бачить загальну картину", "Big-picture focused", "business"),
        q("cooperative_work", "cooperation", 85, "Кооперативный", "Кооперативний", "Cooperative", "business"),
        q("initiative", "initiative", 85, "Инициативный", "Ініціативний", "Initiative-taking", "business"),
        q("innovative", "innovation", 85, "Изобретательный", "Винахідливий", "Innovative", "business"),
        q("proven_methods", "innovation", 25, "Опирается на проверенные решения", "Спирається на перевірені рішення", "Prefers proven methods", "business"),
        q("curious", "intellectual_curiosity", 85, "Любознательный", "Допитливий", "Intellectually curious", "character"),
        q("achievement", "achievement_orientation", 85, "Ориентирован на результат", "Орієнтований на результат", "Achievement-oriented", "business"),
        q("stress_resilient", "stress_tolerance", 85, "Стрессоустойчивый", "Стресостійкий", "Stress-tolerant", "leadership"),
        q("ambiguity_comfort", "ambiguity_tolerance", 85, "Комфортен в неопределённости", "Комфортний у невизначеності", "Comfortable with ambiguity", "business"),
        q("needs_clarity", "ambiguity_tolerance", 25, "Любит ясные правила", "Любить чіткі правила", "Prefers clear rules", "business"),
        q("self_confident", "self_confidence", 85, "Уверенный в себе", "Впевнений у собі", "Self-confident", "leadership"),
        q("humble", "humility", 85, "Скромный", "Скромний", "Humble", "character"),
        q("strong_presentation", "humility", 25, "Ярко презентует себя", "Яскраво презентує себе", "Strong self-presentation", "character"),
        q("family_oriented", "family_orientation", 85, "Семейно ориентированный", "Сімейно орієнтований", "Family-oriented", "lifestyle"),
        q("financially_disciplined", "money_discipline", 85, "Финансово дисциплинированный", "Фінансово дисциплінований", "Financially disciplined", "business"),
        q("punctual", "time_discipline", 85, "Пунктуальный", "Пунктуальний", "Punctual", "business"),
        q("generous", "resource_generosity", 85, "Щедрый ресурсами и помощью", "Щедрий ресурсами та допомогою", "Generous with resources and help", "friendship"),
        q("resource_boundaries", "resource_generosity", 25, "Бережно держит ресурсные границы", "Дбайливо тримає ресурсні межі", "Protective of resource boundaries", "friendship"),
        q("rule_consistent", "rule_orientation", 85, "Последователен в правилах", "Послідовний у правилах", "Rule-consistent", "leadership"),
        q("rule_flexible", "rule_orientation", 25, "Гибок к исключениям", "Гнучкий до винятків", "Flexible with exceptions", "leadership"),
        qc("demanding", listOf(qt("achievement_orientation", 85, 3), qt("rule_orientation", 80, 2), qt("assertiveness", 75, 2), qt("dependability", 80, 2)), "Требовательный", "Вимогливий", "Demanding", "leadership"),
        qc("disciplined", listOf(qt("dependability", 85, 3), qt("planning", 85, 2), qt("time_discipline", 85, 2), qt("self_control", 80, 2), qt("rule_orientation", 80, 1)), "Дисциплинированный", "Дисциплінований", "Disciplined", "leadership"),
        qc("firm_decisions", listOf(qt("assertiveness", 85, 3), qt("conflict_engagement", 80, 2), qt("rule_orientation", 75, 2), qt("directness", 80, 1)), "Твёрдый в решениях", "Твердий у рішеннях", "Firm in decisions", "leadership"),
        qc("uncompromising_principles", listOf(qt("integrity_sincerity", 85, 3), qt("rule_orientation", 90, 3), qt("assertiveness", 85, 2), qt("conflict_engagement", 80, 2)), "Бескомпромиссный в принципиальных вопросах", "Безкомпромісний у принципових питаннях", "Uncompromising on principles", "leadership"),
        qc("crisis_leader", listOf(qt("stress_tolerance", 90, 3), qt("decisiveness", 85, 3), qt("self_control", 85, 2), qt("assertiveness", 75, 1)), "Сильный в кризисе", "Сильний у кризі", "Strong in crisis", "leadership"),
        qc("diplomatic_leader", listOf(qt("directness", 25, 2), qt("tact", 90, 3), qt("self_control", 80, 2), qt("cooperation", 80, 2)), "Дипломатичный руководитель", "Дипломатичний керівник", "Diplomatic leader", "leadership"),
        qc("strategic", listOf(qt("planning", 80, 2), qt("attention_to_detail", 30, 2), qt("ambiguity_tolerance", 75, 2), qt("intellectual_curiosity", 75, 1)), "Стратегический", "Стратегічний", "Strategic", "business"),
        qc("operational", listOf(qt("dependability", 85, 3), qt("attention_to_detail", 85, 3), qt("planning", 85, 2), qt("time_discipline", 80, 2)), "Сильный в операционной работе", "Сильний в операційній роботі", "Operationally strong", "business"),
        qc("entrepreneurial", listOf(qt("initiative", 90, 3), qt("innovation", 85, 2), qt("risk_tolerance", 75, 2), qt("achievement_orientation", 85, 3)), "Предпринимательский", "Підприємницький", "Entrepreneurial", "business"),
        qc("consensus_builder", listOf(qt("cooperation", 90, 3), qt("tact", 85, 2), qt("group_orientation", 80, 2), qt("conflict_engagement", 60, 1)), "Умеет объединять людей", "Уміє об'єднувати людей", "Consensus builder", "leadership"),
        qc("persuasive", listOf(qt("assertiveness", 75, 2), qt("social_energy", 80, 2), qt("directness", 70, 1), qt("self_confidence", 80, 2)), "Убедительный", "Переконливий", "Persuasive", "communication"),
        qc("execution_focused", listOf(qt("achievement_orientation", 90, 3), qt("dependability", 85, 3), qt("perseverance", 85, 2), qt("planning", 75, 1)), "Ориентирован на исполнение", "Орієнтований на виконання", "Execution-focused", "business"),
        qc("accountable", listOf(qt("dependability", 88, 3), qt("integrity_sincerity", 82, 2), qt("achievement_orientation", 82, 2)), "Берёт ответственность", "Бере відповідальність", "Accountable", "business"),
        qc("transparent", listOf(qt("directness", 78, 2), qt("integrity_sincerity", 85, 3), qt("trust_openness", 65, 1)), "Прозрачный в договорённостях", "Прозорий у домовленостях", "Transparent in agreements", "communication"),
        qc("confidential_partner", listOf(qt("confidentiality", 92, 3), qt("integrity_sincerity", 82, 2), qt("boundary_respect", 82, 2)), "Надёжно хранит конфиденциальность", "Надійно зберігає конфіденційність", "Confidential partner", "business"),
        qc("resilient", listOf(qt("stress_tolerance", 88, 3), qt("self_control", 82, 2), qt("optimism", 70, 1), qt("perseverance", 80, 2)), "Устойчивый к нагрузке", "Стійкий до навантаження", "Resilient", "character"),
        qc("change_driver", listOf(qt("adaptability", 88, 2), qt("initiative", 90, 3), qt("innovation", 84, 2), qt("assertiveness", 72, 1)), "Драйвер изменений", "Рушій змін", "Change driver", "leadership"),
        qc("process_builder", listOf(qt("planning", 90, 3), qt("rule_orientation", 80, 2), qt("attention_to_detail", 85, 2), qt("dependability", 85, 2)), "Умеет выстраивать процессы", "Уміє вибудовувати процеси", "Process builder", "business"),
        qc("relationship_builder", listOf(qt("empathy", 82, 2), qt("social_energy", 76, 1), qt("reciprocity", 84, 2), qt("tact", 85, 2)), "Умеет строить отношения", "Уміє будувати стосунки", "Relationship builder", "communication"),
        qc("calm_under_pressure", listOf(qt("stress_tolerance", 92, 3), qt("self_control", 90, 3), qt("emotional_intensity", 30, 2), qt("decisiveness", 72, 1)), "Спокоен под давлением", "Спокійний під тиском", "Calm under pressure", "leadership"),
        qc("autonomous_operator", listOf(qt("autonomy", 88, 2), qt("initiative", 88, 3), qt("dependability", 84, 2), qt("planning", 72, 1)), "Самостоятельный исполнитель", "Самостійний виконавець", "Autonomous operator", "business"),
        qc("cautious_steward", listOf(qt("risk_tolerance", 22, 2), qt("money_discipline", 90, 3), qt("cautiousness", 88, 2), qt("planning", 82, 2)), "Осторожный распорядитель ресурсов", "Обережний розпорядник ресурсів", "Cautious steward", "business"),
        qc("bold_builder", listOf(qt("risk_tolerance", 78, 2), qt("initiative", 90, 3), qt("achievement_orientation", 88, 2), qt("innovation", 82, 2)), "Смелый созидатель", "Сміливий творець", "Bold builder", "business"),
        qc("detail_guardian", listOf(qt("attention_to_detail", 92, 3), qt("rule_orientation", 82, 2), qt("fairness", 80, 1), qt("dependability", 84, 2)), "Хранитель качества и деталей", "Охоронець якості та деталей", "Detail guardian", "business"),
        qc("fast_decider", listOf(qt("decisiveness", 92, 3), qt("response_urgency", 82, 2), qt("assertiveness", 78, 2), qt("self_confidence", 76, 1)), "Быстро принимает решения", "Швидко ухвалює рішення", "Fast decision-maker", "leadership"),
        qc("reflective_decider", listOf(qt("decisiveness", 28, 2), qt("cautiousness", 88, 3), qt("planning", 84, 2), qt("attention_to_detail", 78, 1)), "Вдумчиво принимает решения", "Вдумливо ухвалює рішення", "Reflective decision-maker", "leadership"),
        qc("loyal_companion", listOf(qt("dependability", 88, 3), qt("confidentiality", 86, 2), qt("reciprocity", 84, 2), qt("support_availability", 84, 2)), "Преданный товарищ", "Відданий товариш", "Loyal companion", "friendship"),
        qc("emotionally_warm", listOf(qt("empathy", 88, 3), qt("emotional_intensity", 72, 1), qt("support_availability", 86, 2), qt("vulnerability_comfort", 72, 1)), "Эмоционально тёплый", "Емоційно теплий", "Emotionally warm", "friendship"),
        qc("emotionally_grounded", listOf(qt("self_control", 90, 3), qt("stress_tolerance", 88, 3), qt("emotional_intensity", 28, 2), qt("optimism", 62, 1)), "Эмоционально устойчивый", "Емоційно стійкий", "Emotionally grounded", "character"),
        qc("constructive_challenger", listOf(qt("directness", 84, 2), qt("conflict_engagement", 82, 2), qt("fairness", 84, 2), qt("tact", 66, 1)), "Конструктивно оспаривает решения", "Конструктивно оскаржує рішення", "Constructive challenger", "business"),
        qc("rule_enforcer", listOf(qt("rule_orientation", 92, 3), qt("assertiveness", 82, 2), qt("dependability", 84, 2), qt("fairness", 78, 1)), "Последовательно обеспечивает правила", "Послідовно забезпечує правила", "Consistent rule enforcer", "leadership"),
        qc("flexible_negotiator", listOf(qt("tact", 90, 3), qt("adaptability", 86, 2), qt("cooperation", 86, 2), qt("rule_orientation", 38, 1)), "Гибкий переговорщик", "Гнучкий переговорник", "Flexible negotiator", "communication"),
        qc("resource_steward", listOf(qt("money_discipline", 90, 3), qt("planning", 84, 2), qt("resource_generosity", 35, 1), qt("cautiousness", 82, 2)), "Рационально управляет ресурсами", "Раціонально керує ресурсами", "Resource steward", "business"),
        qc("generous_mentor", listOf(qt("support_availability", 88, 2), qt("resource_generosity", 85, 2), qt("empathy", 84, 2), qt("leadership_orientation", 74, 1)), "Щедрый наставник", "Щедрий наставник", "Generous mentor", "leadership"),
        qc("delegating_leader", listOf(qt("leadership_orientation", 86, 2), qt("autonomy", 80, 2), qt("cooperation", 82, 2), qt("planning", 78, 1)), "Умеет делегировать", "Уміє делегувати", "Delegating leader", "leadership"),
        qc("hands_on_leader", listOf(qt("leadership_orientation", 84, 2), qt("attention_to_detail", 86, 2), qt("support_availability", 78, 1), qt("achievement_orientation", 82, 2)), "Вовлечённый руководитель", "Залучений керівник", "Hands-on leader", "leadership"),
        qc("patient_paced", listOf(qt("response_urgency", 25, 2), qt("self_control", 84, 2), qt("cautiousness", 78, 2), qt("tact", 74, 1)), "Терпеливый и неспешный", "Терплячий і неквапливий", "Patient-paced", "character"),
        qc("fast_paced", listOf(qt("response_urgency", 88, 2), qt("initiative", 88, 2), qt("decisiveness", 82, 2), qt("achievement_orientation", 80, 1)), "Высокий темп действий", "Високий темп дій", "Fast-paced", "business"),
        qc("systems_thinker", listOf(qt("planning", 84, 2), qt("intellectual_curiosity", 84, 2), qt("attention_to_detail", 62, 1), qt("ambiguity_tolerance", 76, 2)), "Системно мыслит", "Системно мислить", "Systems thinker", "business"),
        qc("independent_expert", listOf(qt("independence", 90, 3), qt("intellectual_curiosity", 82, 2), qt("self_confidence", 78, 1), qt("status_independence", 84, 2)), "Независимый экспертный стиль", "Незалежний експертний стиль", "Independent expert", "business"),
    )

    val qualityByKey = qualities.associateBy { it.key }

    fun defaultIntent(): SearchIntent = SearchIntent(role = SearchRole.FRIEND, qualities = emptyList())
}
