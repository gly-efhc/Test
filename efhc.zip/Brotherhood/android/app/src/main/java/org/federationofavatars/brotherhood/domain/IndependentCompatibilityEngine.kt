package org.federationofavatars.brotherhood.domain

import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown

enum class CompatibilityMetricId { PC, IC, VC, CC, LC, PT, EN, NU, AS }

data class IndependentCompatibilityMetric(
    val id: CompatibilityMetricId,
    val score: Int,
    /** Input/data coverage, not scientific validity and not part of the score. */
    val coverage: Int,
    val implementationStatus: String,
) {
    init {
        require(score in 0..100)
        require(coverage in 0..100)
    }
}

data class IndependentCompatibilitySet(
    val metrics: List<IndependentCompatibilityMetric>,
    val selected: Set<CompatibilityMetricId>,
    val overall: Int?,
) {
    fun score(id: CompatibilityMetricId): Int? = metrics.firstOrNull { it.id == id }?.score
}

/**
 * Canonical Q28 aggregation adapter.
 *
 * It does not rewrite the legacy HybridCompatibilityEngine so historical code remains available.
 * Instead, it promotes each existing runtime layer to an independent 0..100 metric and computes
 * only an optional unweighted arithmetic mean of the selected metrics.
 */
object IndependentCompatibilityEngine {
    val defaultSelected: Set<CompatibilityMetricId> = CompatibilityMetricId.entries.toSet()

    fun fromBreakdown(
        breakdown: CompatibilityBreakdown,
        selected: Set<CompatibilityMetricId> = defaultSelected,
    ): IndependentCompatibilitySet {
        val metrics = listOf(
            metric(CompatibilityMetricId.PC, breakdown.friendshipTests, breakdown.confidence, "CURRENT_PSYCHOLOGY_RUNTIME"),
            metric(CompatibilityMetricId.IC, breakdown.interests, 100, "EXPLICIT_PROFILE_RUNTIME"),
            metric(CompatibilityMetricId.VC, breakdown.values, 100, "EXPLICIT_PROFILE_RUNTIME"),
            metric(CompatibilityMetricId.CC, breakdown.communication, breakdown.confidence, "CURRENT_PSYCHOLOGY_RUNTIME"),
            metric(CompatibilityMetricId.LC, breakdown.lifestyle, 100, "EXPLICIT_PROFILE_RUNTIME"),
            metric(CompatibilityMetricId.PT, breakdown.personality32, 100, "BROTHERHOOD32_RUNTIME"),
            metric(CompatibilityMetricId.EN, breakdown.enneagram, 100, "ENNEAGRAM_RUNTIME"),
            metric(CompatibilityMetricId.NU, breakdown.numerology, 100, "VEDIC_NUMEROLOGY_RUNTIME"),
            metric(CompatibilityMetricId.AS, breakdown.zodiac, 100, "ZODIAC_RUNTIME"),
        )
        val available = metrics.filter { it.id in selected }
        val overall = available.takeIf { it.isNotEmpty() }?.map { it.score }?.average()?.roundToInt()?.coerceIn(0, 100)
        return IndependentCompatibilitySet(metrics = metrics, selected = selected.intersect(metrics.map { it.id }.toSet()), overall = overall)
    }

    fun withSelection(set: IndependentCompatibilitySet, selected: Set<CompatibilityMetricId>): IndependentCompatibilitySet {
        val available = set.metrics.filter { it.id in selected }
        return set.copy(
            selected = selected.intersect(set.metrics.map { it.id }.toSet()),
            overall = available.takeIf { it.isNotEmpty() }?.map { it.score }?.average()?.roundToInt()?.coerceIn(0, 100),
        )
    }

    private fun metric(id: CompatibilityMetricId, score: Int, coverage: Int, status: String) =
        IndependentCompatibilityMetric(id, score.coerceIn(0, 100), coverage.coerceIn(0, 100), status)
}
