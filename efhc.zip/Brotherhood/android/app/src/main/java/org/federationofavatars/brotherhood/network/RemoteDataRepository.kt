package org.federationofavatars.brotherhood.network

import android.content.Context
import android.util.Base64
import org.federationofavatars.brotherhood.data.BrotherhoodCacheStore
import org.federationofavatars.brotherhood.data.CachePolicy
import org.federationofavatars.brotherhood.domain.Personality32Engine
import org.federationofavatars.brotherhood.domain.CompatibilityMetricId
import org.federationofavatars.brotherhood.domain.PsychologicalReportSnapshot
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.SearchRole
import org.federationofavatars.brotherhood.model.DesiredQuality
import org.federationofavatars.brotherhood.model.DiscoveryPreferences
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.CalibrationPilotInfo
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.EnneagramProfile
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.Personality32Profile
import org.federationofavatars.brotherhood.model.ProfileVisibility
import org.federationofavatars.brotherhood.model.SearchIntent
import org.federationofavatars.brotherhood.model.UserProfile
import org.federationofavatars.brotherhood.model.VedicNumerologyProfile
import org.federationofavatars.brotherhood.model.ZodiacSign
import org.federationofavatars.brotherhood.sync.OfflineFirstRepository
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/**
 * Production data source. Shared state goes only through the Vercel backend.
 * Neon credentials never exist in the APK.
 */
data class RemoteUserSettings(
    val locale: String,
    val theme: AppThemeMode,
    val profileVisibility: ProfileVisibility,
    val discovery: DiscoveryPreferences,
    val searchIntent: SearchIntent,
)


data class RemoteIndependentCompatibilityMetric(
    val id: CompatibilityMetricId,
    val score: Int?,
    val coverage: Int,
    val status: String,
    val modelVersion: String,
    val evidenceOrigin: String,
)

data class RemoteAssessmentModuleCompatibility(
    val moduleId: String,
    val score: Int?,
    val coverage: Int,
    val commonAssessments: Int,
    val totalAssessments: Int,
    val status: String,
)

data class RemoteIndependentCompatibility(
    val contractVersion: String,
    val requesterGlobalId: GlobalId,
    val candidateGlobalId: GlobalId,
    val selectedMetrics: Set<CompatibilityMetricId>,
    val metrics: List<RemoteIndependentCompatibilityMetric>,
    val psychologicalModules: List<RemoteAssessmentModuleCompatibility>,
    val overall: Int?,
    val overallStatus: String,
    val incompleteSelectedMetrics: Set<CompatibilityMetricId>,
    val trustScore: Int?,
)

data class RemotePsychologicalReportHistoryItem(
    val reportId: String,
    val reportVersion: String,
    val modelVersion: String,
    val createdAtEpochMs: Long,
    val inputSnapshotHash: String,
    val coveragePercent: Int,
    val completedAssessmentCount: Int,
)

class RemoteDataRepository(context: Context) {
    private val cache = BrotherhoodCacheStore(context.applicationContext)
    private val api = VercelApiClient(ApiConfig.baseUrl)
    private val offline = OfflineFirstRepository(cache, api)

    suspend fun people(
        city: String, radiusKm: Int, requester: GlobalId, token: String, intent: SearchIntent, language: AppLanguage,
        hospitalityOnly: Boolean = false,
    ): List<FriendCandidate> {
        val encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8.toString())
        val encodedRole = URLEncoder.encode(intent.role.name.lowercase(), StandardCharsets.UTF_8.toString())
        val qualityPayload = intent.qualities.joinToString(",") { "${it.key}:${it.importance}" }
        val encodedQualities = URLEncoder.encode(qualityPayload, StandardCharsets.UTF_8.toString())
        val hospitalityFilter = if (hospitalityOnly) "&can_host=true" else ""
        val path = "v1/people?city=$encodedCity&radius_km=$radiusKm&requester_global_id=${requester.value}&role=$encodedRole&qualities=$encodedQualities&locale=${language.tag}$hospitalityFilter"
        val json = offline.cachedThenNetwork(
            cacheKey = "people:$city:$radiusKm:${requester.value}:${intent.role.name}:$qualityPayload:${language.tag}:hospitality=$hospitalityOnly",
            path = path,
            token = token,
            ttlMs = CachePolicy.PEOPLE_SEARCH_TTL_MS,
        )
        val array = JSONArray(json)
        return buildList {
            for (index in 0 until array.length()) add(parsePerson(array.getJSONObject(index)))
        }
    }

    suspend fun communities(city: String, kind: CommunityKind, token: String, language: AppLanguage): List<Community> {
        val encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8.toString())
        val path = "v1/communities?city=$encodedCity&kind=${kind.name.lowercase()}&locale=${language.tag}"
        val json = offline.cachedThenNetwork(
            cacheKey = "communities:$city:${kind.name}:${language.tag}",
            path = path,
            token = token,
            ttlMs = CachePolicy.COMMUNITIES_TTL_MS,
        )
        val array = JSONArray(json)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    Community(
                        id = item.getString("id"),
                        title = item.getString("title"),
                        category = item.getString("category"),
                        city = item.optString("city", city),
                        members = item.optInt("members", 0),
                        kind = runCatching { CommunityKind.valueOf(item.optString("kind", "interest").uppercase()) }.getOrDefault(kind),
                        online = item.optBoolean("online", false),
                        description = item.optString("description", ""),
                        verifiedOnly = item.optBoolean("verified_only", false),
                    )
                )
            }
        }
    }

    suspend fun syncSettings(
        globalId: GlobalId,
        language: AppLanguage,
        theme: AppThemeMode,
        visibility: ProfileVisibility,
        discovery: DiscoveryPreferences,
        searchIntent: SearchIntent,
        token: String,
    ): Boolean {
        val preferences = JSONObject().apply {
            put("verified_only", discovery.verifiedOnly)
            put("online_only", discovery.onlineOnly)
            put("require_shared_interests", discovery.requireSharedInterests)
            put("hide_requested", discovery.hideRequested)
            put("min_trust", discovery.minTrust)
            put("min_compatibility", discovery.minCompatibility)
            put("search_role", searchIntent.role.name.lowercase())
            put("qualities", JSONArray().apply { searchIntent.qualities.forEach { put(JSONObject().put("key", it.key).put("importance", it.importance)) } })
        }
        val body = JSONObject()
            .put("locale", language.tag)
            .put("theme", theme.name.lowercase())
            .put("profile_visibility", visibility.name.lowercase())
            .put("preferences", preferences)
            .toString()
        return offline.writeOrQueue("PUT_SETTINGS", "v1/settings/${globalId.value}", body, token)
    }

    suspend fun loadSettings(globalId: GlobalId, token: String): RemoteUserSettings? {
        val raw = runCatching { api.get("v1/settings/${globalId.value}", token) }.getOrNull() ?: return null
        if (raw.isBlank()) return null
        val item = JSONObject(raw)
        val prefs = item.optJSONObject("preferences") ?: JSONObject()
        val qualities = prefs.optJSONArray("qualities") ?: JSONArray()
        val intentQualities = buildList {
            for (index in 0 until qualities.length()) {
                val quality = qualities.optJSONObject(index) ?: continue
                val key = quality.optString("key").trim()
                if (key.isNotEmpty()) add(DesiredQuality(key, quality.optInt("importance", 3).coerceIn(1, 5)))
            }
        }
        return RemoteUserSettings(
            locale = item.optString("locale", "ru"),
            theme = runCatching { AppThemeMode.valueOf(item.optString("theme", "system").uppercase()) }.getOrDefault(AppThemeMode.SYSTEM),
            profileVisibility = runCatching { ProfileVisibility.valueOf(item.optString("profile_visibility", "discoverable").uppercase()) }.getOrDefault(ProfileVisibility.DISCOVERABLE),
            discovery = DiscoveryPreferences(
                verifiedOnly = prefs.optBoolean("verified_only", false),
                onlineOnly = prefs.optBoolean("online_only", false),
                requireSharedInterests = prefs.optBoolean("require_shared_interests", false),
                hideRequested = prefs.optBoolean("hide_requested", false),
                minTrust = prefs.optInt("min_trust", 0).coerceIn(0, 100),
                minCompatibility = prefs.optInt("min_compatibility", 0).coerceIn(0, 100),
            ),
            searchIntent = SearchIntent(
                role = runCatching { SearchRole.valueOf(prefs.optString("search_role", "friend").uppercase()) }.getOrDefault(SearchRole.FRIEND),
                qualities = intentQualities,
            ),
        )
    }

    suspend fun syncProfile(profile: UserProfile, language: AppLanguage, token: String, visibility: ProfileVisibility = ProfileVisibility.DISCOVERABLE): Boolean {
        val body = JSONObject().apply {
            put("display_name", profile.name)
            put("birth_date", profile.birthDate.toString())
            put("latin_name", profile.latinName)
            put("city", profile.city)
            put("country_code", "ZZ")
            put("about", profile.description)
            put("friendship_goals", JSONArray(profile.goals))
            put("interests", JSONArray(profile.interests))
            put("values", JSONArray(profile.values))
            put("lifestyle", JSONArray(profile.lifestyle))
            put("boundaries", JSONObject())
            put("visibility", visibility.name.lowercase())
            put("completed_profile_sections", profile.completedProfileSections)
            put("locale", language.tag)
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_PROFILE",
            path = "v1/profiles/${profile.globalId.value}",
            json = body,
            token = token,
        )
    }

    suspend fun syncAvatar(globalId: GlobalId, jpegBytes: ByteArray, token: String): Boolean {
        require(jpegBytes.isNotEmpty() && jpegBytes.size <= 512_000) { "Avatar must be 1..512000 bytes" }
        val sha256 = MessageDigest.getInstance("SHA-256").digest(jpegBytes).joinToString("") { "%02x".format(it) }
        val body = JSONObject().apply {
            put("content_type", "image/jpeg")
            put("data_base64", Base64.encodeToString(jpegBytes, Base64.NO_WRAP))
            put("sha256", sha256)
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT",
            path = "v1/profiles/${globalId.value}/avatar",
            json = body,
            token = token,
        )
    }

    suspend fun syncPersonalityProfile(profile: UserProfile, token: String): Boolean {
        val p = profile.personality32
        val n = profile.numerology
        val body = JSONObject().apply {
            put("brotherhood32_code", p.code)
            put("brotherhood32_scores", JSONObject().apply {
                put("title", p.titleEn)
                put("social_energy", p.socialEnergy)
                put("perception", p.perception)
                put("decision_style", p.decisionStyle)
                put("life_rhythm", p.lifeRhythm)
                put("bond_style", p.bondStyle)
            })
            put("enneagram_type", profile.enneagram.type)
            if (profile.enneagram.wing == null) put("enneagram_wing", JSONObject.NULL) else put("enneagram_wing", profile.enneagram.wing)
            put("zodiac_sign", profile.zodiac.name)
            put("vedic_numerology", JSONObject().apply {
                put("soul_number", n.soulNumber)
                put("destiny_number", n.destinyNumber)
                if (n.nameNumber == null) put("name_number", JSONObject.NULL) else put("name_number", n.nameNumber)
                put("maturity_number", n.maturityNumber)
                put("compatibility_vector", JSONArray(n.compatibilityVector))
            })
            put("model_version", "0.5.20")
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_PERSONALITY",
            path = "v1/personality-profile/${profile.globalId.value}",
            json = body,
            token = token,
        )
    }

    suspend fun syncAssessmentResult(globalId: GlobalId, result: AssessmentResult, token: String, instrumentLocale: String, includePrivateTrace: Boolean): Boolean {
        val dimensions = JSONArray().apply {
            result.dimensions.forEach { dimension ->
                put(JSONObject().apply {
                    put("id", dimension.id)
                    put("title", dimension.title)
                    put("score", dimension.score)
                })
            }
        }
        val responseTrace = JSONArray().apply {
            if (includePrivateTrace) result.responseTrace.forEach { row ->
                put(JSONObject().apply {
                    put("question_id", row.questionId)
                    put("choice_id", row.choiceId)
                    put("paradigm", row.paradigm)
                    put("scene_archetype", row.sceneArchetype)
                    put("stimulus_version", row.stimulusVersion)
                    put("visual_seed", row.visualSeed)
                    put("composition_variant", row.compositionVariant)
                    put("intensity", row.intensity)
                    put("spacing", row.spacing)
                    put("order", row.order)
                    put("asymmetry", row.asymmetry)
                    put("direction", row.direction)
                    put("presentation_slot", row.presentationSlot)
                    put("response_latency_ms", row.responseLatencyMs)
                    put("selection_changes", row.selectionChanges)
                    put("question_position", row.questionPosition)
                })
            }
        }
        val body = JSONObject().apply {
            put("global_id", globalId.value)
            put("assessment_id", result.assessmentId)
            put("scoring_version", result.modelVersion)
            put("stimulus_version", result.stimulusVersion)
            put("instrument_locale", instrumentLocale)
            put("started_at_epoch_ms", result.startedAtEpochMs)
            put("total_score", result.totalScore)
            put("risk_score", result.riskScore)
            put("answer_consistency", result.answerConsistency)
            put("idealized_self_presentation", result.idealizedSelfPresentation)
            put("label", result.label)
            put("summary", result.summary)
            put("dimensions", dimensions)
            put("response_trace", responseTrace)
            put("completed_at_epoch_ms", result.completedAtEpochMs)
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_ASSESSMENT",
            path = "v1/assessment-results",
            json = body,
            token = token,
        )
    }

    suspend fun syncCompatibilityMetricPreferences(
        globalId: GlobalId, selected: Set<CompatibilityMetricId>, token: String,
    ): Boolean {
        require(selected.isNotEmpty())
        val body = JSONObject().apply {
            put("global_id", globalId.value)
            put("selected_metrics", JSONArray().apply { CompatibilityMetricId.entries.filter(selected::contains).forEach { put(it.name) } })
            put("contract_version", "independent-compatibility-v1")
        }.toString()
        return offline.writeOrQueue("PUT_COMPATIBILITY_PREFERENCES", "v1/compatibility/preferences", body, token)
    }

    suspend fun loadCompatibilityMetricPreferences(globalId: GlobalId, token: String): Set<CompatibilityMetricId> {
        val raw = api.get("v1/compatibility/preferences/${globalId.value}", token)
        val array = JSONObject(raw).optJSONArray("selected_metrics") ?: JSONArray()
        return buildSet {
            for (index in 0 until array.length()) {
                runCatching { CompatibilityMetricId.valueOf(array.getString(index)) }.getOrNull()?.let(::add)
            }
        }.ifEmpty { CompatibilityMetricId.entries.toSet() }
    }

    suspend fun independentCompatibility(
        requester: GlobalId, candidate: GlobalId, selected: Set<CompatibilityMetricId>?, token: String,
    ): RemoteIndependentCompatibility {
        val body = JSONObject().apply {
            put("requester_global_id", requester.value)
            put("candidate_global_id", candidate.value)
            if (selected == null) put("selected_metrics", JSONObject.NULL) else {
                put("selected_metrics", JSONArray().apply { CompatibilityMetricId.entries.filter(selected::contains).forEach { put(it.name) } })
            }
        }.toString()
        val root = JSONObject(api.post("v1/compatibility/independent", body, token))
        fun metricIds(name: String): Set<CompatibilityMetricId> {
            val array = root.optJSONArray(name) ?: JSONArray()
            return buildSet { for (index in 0 until array.length()) runCatching { CompatibilityMetricId.valueOf(array.getString(index)) }.getOrNull()?.let(::add) }
        }
        val metricArray = root.optJSONArray("metrics") ?: JSONArray()
        val metrics = buildList {
            for (index in 0 until metricArray.length()) {
                val item = metricArray.getJSONObject(index)
                val id = runCatching { CompatibilityMetricId.valueOf(item.getString("id")) }.getOrNull() ?: continue
                add(RemoteIndependentCompatibilityMetric(
                    id=id, score=if (item.isNull("score")) null else item.optInt("score").coerceIn(0,100),
                    coverage=item.optInt("coverage",0).coerceIn(0,100), status=item.optString("status","INSUFFICIENT_DATA"),
                    modelVersion=item.optString("model_version","unknown"), evidenceOrigin=item.optString("evidence_origin","unknown"),
                ))
            }
        }
        val moduleArray = root.optJSONArray("psychological_modules") ?: JSONArray()
        val modules = buildList {
            for (index in 0 until moduleArray.length()) {
                val item=moduleArray.getJSONObject(index)
                add(RemoteAssessmentModuleCompatibility(
                    moduleId=item.optString("module_id"), score=if(item.isNull("score")) null else item.optInt("score").coerceIn(0,100),
                    coverage=item.optInt("coverage",0).coerceIn(0,100), commonAssessments=item.optInt("common_assessments",0),
                    totalAssessments=item.optInt("total_assessments",10), status=item.optString("status","INSUFFICIENT_DATA"),
                ))
            }
        }
        return RemoteIndependentCompatibility(
            contractVersion=root.optString("contract_version","independent-compatibility-v1"),
            requesterGlobalId=requester,candidateGlobalId=candidate,selectedMetrics=metricIds("selected_metrics"),metrics=metrics,
            psychologicalModules=modules,overall=if(root.isNull("overall")) null else root.optInt("overall").coerceIn(0,100),
            overallStatus=root.optString("overall_status","INSUFFICIENT_DATA"),incompleteSelectedMetrics=metricIds("incomplete_selected_metrics"),
            trustScore=if(root.isNull("trust_score")) null else root.optInt("trust_score").coerceIn(0,100),
        )
    }

    suspend fun syncPsychologicalReport(
        globalId: GlobalId, report: PsychologicalReportSnapshot, results: Map<String, AssessmentResult>, token: String,
    ): String? {
        val orderedResults = report.completedAssessmentIds.mapNotNull(results::get)
        require(orderedResults.size == report.completedAssessmentIds.size) { "Report input snapshot must contain every completed assessment" }
        val inputSnapshot = JSONArray().apply {
            orderedResults.forEach { result ->
                put(JSONObject().apply {
                    put("assessment_id", result.assessmentId)
                    put("result_id", result.id)
                    put("scoring_version", result.modelVersion)
                    put("stimulus_version", result.stimulusVersion)
                    put("total_score", result.totalScore)
                    put("answer_consistency", result.answerConsistency)
                    put("dimensions", JSONArray().apply { result.dimensions.forEach { dimension -> put(JSONObject().put("id",dimension.id).put("title",dimension.title).put("score",dimension.score)) } })
                    put("completed_at_epoch_ms", result.completedAtEpochMs)
                })
            }
        }
        val body=JSONObject().apply {
            put("global_id",globalId.value); put("report_version",report.reportVersion); put("model_version",report.modelVersion)
            put("created_at_epoch_ms",report.createdAtEpochMs); put("input_snapshot",inputSnapshot); put("completed_assessment_ids",JSONArray(report.completedAssessmentIds))
            put("coverage_percent",report.coveragePercent); put("summary",report.summary)
            put("sections",JSONArray().apply { report.sections.forEach { section -> put(JSONObject().put("key",section.key).put("title",section.title).put("body",section.body)) } })
            put("strengths",JSONArray(report.strengths)); put("growth_areas",JSONArray(report.growthAreas)); put("limitations",JSONArray(report.limitations))
        }.toString()
        val raw=api.put("v1/psychological-reports",body,token)
        return JSONObject(raw).optString("report_id").takeIf(String::isNotBlank)
    }

    suspend fun psychologicalReportHistory(globalId: GlobalId, token: String): List<RemotePsychologicalReportHistoryItem> {
        val array=JSONArray(api.get("v1/psychological-reports/${globalId.value}/history",token))
        return buildList {
            for(index in 0 until array.length()) { val item=array.getJSONObject(index); add(RemotePsychologicalReportHistoryItem(
                reportId=item.getString("report_id"),reportVersion=item.getString("report_version"),modelVersion=item.getString("model_version"),
                createdAtEpochMs=item.getLong("created_at_epoch_ms"),inputSnapshotHash=item.getString("input_snapshot_hash"),
                coveragePercent=item.getInt("coverage_percent"),completedAssessmentCount=item.getInt("completed_assessment_count"),
            )) }
        }
    }

    suspend fun calibrationPilotStatus(token: String): CalibrationPilotInfo {
        val item = JSONObject(api.get("v1/calibration-pilot/status", token))
        val locales = item.optJSONArray("accepted_locales") ?: JSONArray()
        val localeRemainingJson = item.optJSONObject("locale_remaining") ?: JSONObject()
        val localeRemaining = buildMap {
            val keys = localeRemainingJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                put(key, localeRemainingJson.optInt(key, 0))
            }
        }
        return CalibrationPilotInfo(
            mode = item.optString("mode", "disabled"),
            cohortId = item.optString("cohort_id", ""),
            pilotWave = item.optString("pilot_wave", ""),
            consentVersion = item.optString("consent_version", "calibration-consent-v2"),
            modelVersion = item.optString("model_version", "scientific-questionnaire-v1"),
            stimulusVersion = item.optString("stimulus_version", "text-situational-v1"),
            acceptedLocales = buildSet { for (index in 0 until locales.length()) add(locales.optString(index)) },
            capacityTotal = item.optInt("capacity_total", 0),
            capacityUsed = item.optInt("capacity_used", 0),
            capacityRemaining = item.optInt("capacity_remaining", 0),
            localeRemaining = localeRemaining,
            inviteRequired = item.optBoolean("invite_required", true),
        )
    }

    suspend fun calibrationConsent(globalId: GlobalId, token: String): Boolean? {
        val raw = api.get("v1/calibration-consent/${globalId.value}", token)
        if (raw.isBlank() || raw == "null") return null
        return JSONObject(raw).optBoolean("opt_in", false)
    }

    /** Join requests are online-only so the one-time invite code is never written to the offline queue. */
    suspend fun joinCalibrationPilot(globalId: GlobalId, instrumentLocale: String, inviteCode: String, token: String): Boolean {
        val body = JSONObject().apply {
            put("global_id", globalId.value)
            put("opt_in", true)
            put("consent_version", "calibration-consent-v2")
            put("instrument_locale", instrumentLocale)
            put("eligibility_ack", true)
            put("invite_code", inviteCode.trim())
        }.toString()
        val response = api.put("v1/calibration-consent", body, token)
        return JSONObject(response).optBoolean("opt_in", false)
    }

    /** Withdrawal is safe to queue: it contains no invite secret and deletes server-side raw attempts. */
    suspend fun leaveCalibrationPilot(globalId: GlobalId, instrumentLocale: String, token: String): Boolean {
        val body = JSONObject().apply {
            put("global_id", globalId.value)
            put("opt_in", false)
            put("consent_version", "calibration-consent-v2")
            put("instrument_locale", instrumentLocale)
            put("eligibility_ack", false)
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_CALIBRATION_CONSENT",
            path = "v1/calibration-consent",
            json = body,
            token = token,
        )
    }

    suspend fun flushPending(token: String): Int = offline.flushPending(token)

    fun close() = cache.close()

    private fun parsePerson(item: JSONObject): FriendCandidate {
        val globalId = GlobalId(item.getLong("global_id"))
        val personalityJson = item.optJSONObject("personality32")
        val personalityCode = personalityJson?.optString("code", "RPLSG") ?: "RPLSG"
        val canonicalPersonality = Personality32Engine.allCanonicalProfiles()
            .firstOrNull { it.code == personalityCode }
        val personality = Personality32Profile(
            code = personalityCode,
            // Titles are canonical client-side i18n data keyed by the stable code. A server-rendered
            // title may be in the request locale and must never be copied into all language slots.
            titleRu = canonicalPersonality?.titleRu ?: "Профиль формируется",
            titleUk = canonicalPersonality?.titleUk ?: "Профіль формується",
            titleEn = canonicalPersonality?.titleEn ?: "Profile forming",
            socialEnergy = personalityJson?.optInt("social_energy", 50) ?: 50,
            perception = personalityJson?.optInt("perception", 50) ?: 50,
            decisionStyle = personalityJson?.optInt("decision_style", 50) ?: 50,
            lifeRhythm = personalityJson?.optInt("life_rhythm", 50) ?: 50,
            bondStyle = personalityJson?.optInt("bond_style", 50) ?: 50,
        )
        val enneagramType = item.optInt("enneagram_type", 6).coerceIn(1, 9)
        val numerologyJson = item.optJSONObject("numerology")
        val soul = numerologyJson?.optInt("soul_number", 1)?.coerceIn(1, 9) ?: 1
        val destiny = numerologyJson?.optInt("destiny_number", 1)?.coerceIn(1, 9) ?: 1
        val nameNumber = numerologyJson?.let { json -> if (json.has("name_number") && !json.isNull("name_number")) json.optInt("name_number").coerceIn(1, 9) else null }
        val maturity = numerologyJson?.optInt("maturity_number", destiny)?.coerceIn(1, 9) ?: destiny
        val zodiac = runCatching { ZodiacSign.valueOf(item.optString("zodiac", "ARIES")) }.getOrDefault(ZodiacSign.ARIES)
        return FriendCandidate(
            globalId = globalId,
            name = item.getString("name"),
            age = item.optInt("age", 18).coerceAtLeast(18),
            city = item.optString("city", ""),
            distanceKm = item.optInt("distance_km", 0).coerceAtLeast(0),
            compatibility = item.optInt("compatibility", 0).coerceIn(0, 100),
            trustScore = item.optInt("trust_score", 70).coerceIn(0, 100),
            accountRating = item.optInt("account_rating", 0).coerceIn(0, 100),
            interests = item.optJSONArray("interests").toStringList(),
            goals = item.optJSONArray("goals").toStringList(),
            values = item.optJSONArray("values").toStringList(),
            lifestyle = item.optJSONArray("lifestyle").toStringList(),
            explanation = item.optString("explanation", ""),
            assessmentProfileSeed = globalId.value.toInt(),
            personality32 = personality,
            enneagram = EnneagramProfile(
                type = enneagramType,
                wing = null,
                score = 50,
                titleRu = "Эннеатип $enneagramType",
                titleUk = "Еннеатип $enneagramType",
                titleEn = "Enneatype $enneagramType",
            ),
            zodiac = zodiac,
            numerology = VedicNumerologyProfile(
                soulNumber = soul,
                destinyNumber = destiny,
                nameNumber = nameNumber,
                maturityNumber = maturity,
                compatibilityVector = listOf(soul, destiny, maturity),
            ),
            friendshipTestScore = item.optInt("friendship_test_score", 0).coerceIn(0, 100),
            commonTestCount = item.optInt("common_tests", 0).coerceIn(0, 100),
            testCategoryScores = item.optJSONObject("test_category_scores").toIntMap(),
            verified = true,
            online = false,
            serverBacked = true,
            friendshipExpectationsScore = item.optInt("friendship_expectations_score", 0).coerceIn(0, 100),
            qualityFit = item.optInt("quality_fit", 0).coerceIn(0, 100),
            positiveQualities = item.optJSONArray("positive_qualities").toStringList(),
        )
    }

    private fun JSONObject?.toIntMap(): Map<String, Int> {
        if (this == null) return emptyMap()
        return buildMap {
            val keys = keys()
            while (keys.hasNext()) {
                val key = keys.next()
                put(key, optInt(key, 0).coerceIn(0, 100))
            }
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (index in 0 until length()) add(optString(index))
        }.filter(String::isNotBlank)
    }
}
