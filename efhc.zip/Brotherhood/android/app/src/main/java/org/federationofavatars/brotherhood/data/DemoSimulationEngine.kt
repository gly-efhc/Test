package org.federationofavatars.brotherhood.data

import java.time.Instant
import java.time.LocalDate
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.ChatEncryptionMode
import org.federationofavatars.brotherhood.model.ChatMessage
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.ConversationKind
import org.federationofavatars.brotherhood.model.ConversationSummaryModel
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.HospitalityArrivalDetails
import org.federationofavatars.brotherhood.model.HospitalityAvailability
import org.federationofavatars.brotherhood.model.HospitalityAvailabilityState
import org.federationofavatars.brotherhood.model.HospitalityEligibility
import org.federationofavatars.brotherhood.model.HospitalityEvent
import org.federationofavatars.brotherhood.model.HospitalityHostDetails
import org.federationofavatars.brotherhood.model.HospitalityHostProfile
import org.federationofavatars.brotherhood.model.HospitalityReputation
import org.federationofavatars.brotherhood.model.HospitalityReviewState
import org.federationofavatars.brotherhood.model.HospitalityVerification
import org.federationofavatars.brotherhood.model.StayConfirmationValue
import org.federationofavatars.brotherhood.model.StayRequest
import org.federationofavatars.brotherhood.model.StayRequestStatus
import org.federationofavatars.brotherhood.model.TrustEvent
import org.federationofavatars.brotherhood.model.UserProfile

/**
 * Stateful DEBUG-only simulation boundary.
 *
 * Production data continues to come from the real backend repositories. MainViewModel may use this
 * engine only when BuildConfig.DEBUG is true and no authenticated backend session is available.
 * The engine deliberately owns demo runtime state (conversations/messages/block state) while
 * DemoRepository remains immutable fixture/catalog data.
 */
class DemoSimulationEngine(
    private val backend: DemoBackendSimulator = DemoBackendSimulator(),
) {
    private val messageStore = linkedMapOf<String, MutableList<ChatMessage>>()
    private val blockedPeers = mutableSetOf<Long>()
    private var nextMessageSequence = 1000L
    private var nextGroupSequence = 1L

    private var nextHospitalitySequence = 1L
    private var demoHospitalityHostProfile = backend.hospitalityHostProfile()
    private val demoHospitalityAvailability = backend.hospitalityAvailability().toMutableList()
    private val demoHospitalityRequests = backend.hospitalityRequests().associateBy { it.requestId }.toMutableMap()
    private val demoHospitalityEvents = backend.hospitalityRequests()
        .flatMap { backend.hospitalityEvents(it.conversationId) }.toMutableList()
    private val demoHospitalityVerification = mutableMapOf<String, HospitalityVerification>().apply {
        backend.hospitalityRequests().forEach { request -> backend.hospitalityVerification(request.requestId)?.let { put(request.requestId, it) } }
    }
    private val demoHospitalityReviewState = mutableMapOf<String, HospitalityReviewState>().apply {
        backend.hospitalityRequests().forEach { request -> backend.hospitalityReviewState(request.requestId)?.let { put(request.requestId, it) } }
    }

    val profile: UserProfile get() = backend.profile
    val trustEvents: List<TrustEvent> get() = backend.trustEvents

    fun people(language: AppLanguage): List<FriendCandidate> = backend.people(language)

    fun communities(language: AppLanguage): List<Community> = backend.communities(language)

    // Cycle 0022 DEBUG simulation mirrors Hospitality lifecycle without replacing production repositories.
    fun hospitalityHostProfile(): HospitalityHostProfile = demoHospitalityHostProfile

    fun saveHospitalityHostProfile(value: HospitalityHostProfile): HospitalityHostProfile {
        demoHospitalityHostProfile = value.copy(hostGlobalId = profile.globalId)
        return demoHospitalityHostProfile
    }

    fun hospitalityHostDetails(hostGlobalId: GlobalId): HospitalityHostDetails? = backend.hospitalityHostDetails(hostGlobalId)

    fun hospitalityAvailability(): List<HospitalityAvailability> = demoHospitalityAvailability.toList()

    fun saveHospitalityAvailability(
        dateFrom: String,
        dateTo: String,
        available: Boolean,
        capacity: Int?,
    ): HospitalityAvailability {
        val item = HospitalityAvailability(
            availabilityId = "demo-availability-${nextHospitalitySequence++}",
            dateFrom = dateFrom,
            dateTo = dateTo,
            state = if (available) HospitalityAvailabilityState.AVAILABLE else HospitalityAvailabilityState.UNAVAILABLE,
            capacityOverride = capacity,
        )
        demoHospitalityAvailability += item
        return item
    }

    fun deleteHospitalityAvailability(id: String) {
        demoHospitalityAvailability.removeAll { it.availabilityId == id }
    }

    fun hospitalityRequests(): List<StayRequest> = demoHospitalityRequests.values.sortedByDescending { it.createdAt }

    fun hospitalityRequest(requestId: String): StayRequest? = demoHospitalityRequests[requestId]

    fun hospitalityEligibility(hostGlobalId: GlobalId, checkIn: String, checkOut: String, guests: Int): HospitalityEligibility? {
        val details = hospitalityHostDetails(hostGlobalId) ?: return null
        val days = runCatching { java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(checkIn), LocalDate.parse(checkOut)).toInt() }.getOrDefault(0)
        val host = details.host
        val capacityOk = guests in 1..host.maxGuests
        val datesOk = days in 1..host.maxDays
        val ratingOk = profile.trustScore.toDouble() >= host.minRequiredRating
        return (details.eligibility ?: HospitalityEligibility(
            eligible = false, reasons = emptyList(), accountRating = profile.trustScore.toDouble(), minRequiredRating = host.minRequiredRating,
            missingRequiredTests = emptyList(), dateAvailable = true, capacityAvailable = capacityOk, effectiveCapacity = host.maxGuests,
            occupiedCapacity = 0, stayDays = days,
        )).copy(
            eligible = capacityOk && datesOk && ratingOk,
            reasons = buildList {
                if (!capacityOk) add("HOSPITALITY_TOO_MANY_GUESTS")
                if (!datesOk) add("HOSPITALITY_DATES_INVALID")
                if (!ratingOk) add("HOSPITALITY_RATING_TOO_LOW")
            },
            dateAvailable = datesOk,
            capacityAvailable = capacityOk,
            effectiveCapacity = host.maxGuests,
            stayDays = days,
        )
    }

    fun createHospitalityRequest(hostGlobalId: GlobalId, checkIn: String, checkOut: String, guests: Int): StayRequest {
        require(hospitalityEligibility(hostGlobalId, checkIn, checkOut, guests)?.eligible == true)
        val now = Instant.now().toString()
        val request = StayRequest(
            requestId = "demo-stay-${nextHospitalitySequence++}",
            guestGlobalId = profile.globalId,
            hostGlobalId = hostGlobalId,
            checkInDate = checkIn,
            checkOutDate = checkOut,
            guestsCount = guests,
            status = StayRequestStatus.PENDING,
            responseDueAt = Instant.now().plusSeconds(48 * 3600).toString(),
            conversationId = directId(hostGlobalId.value),
            version = 1,
            createdAt = now,
            updatedAt = now,
        )
        demoHospitalityRequests[request.requestId] = request
        addHospitalityEvent(request, "request_created", profile.globalId)
        return request
    }

    fun actOnHospitalityRequest(requestId: String, action: String): StayRequest? {
        val current = demoHospitalityRequests[requestId] ?: return null
        val nextStatus = when (action) {
            "accept" -> if (current.status == StayRequestStatus.PENDING) StayRequestStatus.ACCEPTED else current.status
            "reject" -> if (current.status == StayRequestStatus.PENDING) StayRequestStatus.REJECTED else current.status
            "cancel_guest" -> if (current.status in setOf(StayRequestStatus.PENDING, StayRequestStatus.ACCEPTED)) StayRequestStatus.CANCELLED_BY_GUEST else current.status
            "cancel_host" -> if (current.status in setOf(StayRequestStatus.PENDING, StayRequestStatus.ACCEPTED)) StayRequestStatus.CANCELLED_BY_HOST else current.status
            "complete" -> if (current.status == StayRequestStatus.ACCEPTED) StayRequestStatus.COMPLETED else current.status
            else -> current.status
        }
        if (nextStatus == current.status) return current
        val now = Instant.now().toString()
        val updated = current.copy(
            status = nextStatus,
            version = current.version + 1,
            updatedAt = now,
            completedAt = if (nextStatus == StayRequestStatus.COMPLETED) now else current.completedAt,
            reviewDeadlineAt = if (nextStatus == StayRequestStatus.COMPLETED) Instant.now().plusSeconds(7 * 24 * 3600).toString() else current.reviewDeadlineAt,
        )
        demoHospitalityRequests[requestId] = updated
        addHospitalityEvent(updated, "request_${nextStatus.wire}", profile.globalId)
        if (nextStatus == StayRequestStatus.COMPLETED) {
            demoHospitalityReviewState[requestId] = HospitalityReviewState(
                requestId = requestId, canSubmit = true, ownSubmitted = false, ownPublished = false,
                reviewDeadlineAt = updated.reviewDeadlineAt, publishedReviewCount = 0,
            )
        }
        return updated
    }

    fun hospitalityArrivalDetails(requestId: String): HospitalityArrivalDetails? {
        val request = demoHospitalityRequests[requestId] ?: return null
        if (request.status != StayRequestStatus.ACCEPTED) return null
        return backend.hospitalityArrivalDetails(requestId) ?: HospitalityArrivalDetails(
            requestId = requestId,
            exactAddress = "DEMO: participant-only accepted address",
            arrivalInstructions = "DEMO: coordinate arrival in the E2EE chat",
            exactLat = 49.8397,
            exactLon = 24.0297,
            arrivalContact = "DEMO participant-only contact",
            privateAccessExpiresAt = Instant.now().plusSeconds(14 * 24 * 3600).toString(),
        )
    }

    fun hospitalityVerification(requestId: String): HospitalityVerification? = demoHospitalityVerification[requestId]

    fun confirmHospitalityStay(requestId: String, value: StayConfirmationValue): HospitalityVerification? {
        val request = demoHospitalityRequests[requestId] ?: return null
        if (request.status != StayRequestStatus.COMPLETED) return null
        val blocked = when (value) {
            StayConfirmationValue.NO_SHOW -> "no_show"
            StayConfirmationValue.DISPUTE -> "dispute"
            StayConfirmationValue.STAY_OCCURRED -> null
        }
        val verification = HospitalityVerification(
            requestId = requestId,
            verified = value == StayConfirmationValue.STAY_OCCURRED,
            interactionId = if (value == StayConfirmationValue.STAY_OCCURRED) "demo-verified-$requestId" else null,
            hostConfirmed = value == StayConfirmationValue.STAY_OCCURRED,
            guestConfirmed = value == StayConfirmationValue.STAY_OCCURRED,
            blockedBy = blocked,
        )
        demoHospitalityVerification[requestId] = verification
        if (verification.verified) addHospitalityEvent(request, "stay_verified", profile.globalId)
        return verification
    }

    fun hospitalityReviewState(requestId: String): HospitalityReviewState? = demoHospitalityReviewState[requestId]

    fun submitHospitalityReview(requestId: String): HospitalityReviewState? {
        val current = demoHospitalityReviewState[requestId] ?: return null
        val updated = current.copy(ownSubmitted = true, ownPublished = false)
        demoHospitalityReviewState[requestId] = updated
        demoHospitalityRequests[requestId]?.let { addHospitalityEvent(it, "review_submitted_blind", profile.globalId) }
        return updated
    }

    fun hospitalityReputation(globalId: GlobalId): HospitalityReputation {
        val verified = demoHospitalityVerification.values.count { it.verified }
        val base = backend.hospitalityReputation(globalId)
        return base.copy(verifiedStaysAsHost = base.verifiedStaysAsHost + verified)
    }

    fun hospitalityEvents(conversationId: String): List<HospitalityEvent> =
        demoHospitalityEvents.filter { it.conversationId == conversationId }.sortedBy { it.createdAtEpochMs }

    private fun addHospitalityEvent(request: StayRequest, type: String, actor: GlobalId?) {
        val now = System.currentTimeMillis()
        demoHospitalityEvents += HospitalityEvent(
            eventId = "demo-event-${nextHospitalitySequence++}", requestId = request.requestId,
            conversationId = request.conversationId, actorGlobalId = actor, eventType = type,
            publicPayload = mapOf("status" to request.status.wire), createdAt = Instant.now().toString(), createdAtEpochMs = now,
        )
    }

    fun conversations(language: AppLanguage): List<ConversationSummaryModel> {
        ensureSeeded(language)
        val seeded = mutableListOf(
            directConversation(2L, language),
            directConversation(4L, language),
            ConversationSummaryModel(
                id = "demo-group-1",
                kind = ConversationKind.GROUP,
                title = language.pick("Совместные проекты", "Спільні проєкти", "Shared projects"),
                peerGlobalId = null,
                memberCount = 5,
                encryptionMode = ChatEncryptionMode.SERVER,
                lastMessagePreview = latestPreview("demo-group-1", language),
                lastMessageAtEpochMs = messageStore["demo-group-1"]?.lastOrNull()?.createdAtEpochMs,
                unreadCount = 1,
            )
        )
        return seeded.sortedByDescending { it.lastMessageAtEpochMs ?: 0L }
    }

    fun openDirect(candidate: FriendCandidate, language: AppLanguage): ConversationSummaryModel {
        ensureSeeded(language)
        val id = directId(candidate.globalId.value)
        if (messageStore[id] == null) {
            messageStore[id] = mutableListOf(
                demoMessage(
                    conversationId = id,
                    sender = candidate.globalId,
                    text = language.pick(
                        "Привет! Вижу много общих интересов. Рад познакомиться.",
                        "Привіт! Бачу багато спільних інтересів. Радий познайомитися.",
                        "Hi! I see we share a lot of interests. Glad to meet you.",
                    ),
                    offsetMs = -120_000,
                    encryptionMode = ChatEncryptionMode.E2EE,
                )
            )
        }
        return directConversation(candidate.globalId.value, language)
    }

    fun messages(conversationId: String, language: AppLanguage): List<ChatMessage> {
        ensureSeeded(language)
        return messageStore[conversationId].orEmpty().toList()
    }

    fun sendMessage(
        conversation: ConversationSummaryModel,
        sender: GlobalId,
        text: String,
        language: AppLanguage,
    ): List<ChatMessage> {
        ensureSeeded(language)
        val list = messageStore.getOrPut(conversation.id) { mutableListOf() }
        list += demoMessage(
            conversationId = conversation.id,
            sender = sender,
            text = text,
            offsetMs = 0,
            encryptionMode = conversation.encryptionMode,
        )
        return list.toList()
    }

    fun editMessage(conversationId: String, messageId: String, text: String, language: AppLanguage): List<ChatMessage> {
        ensureSeeded(language)
        val list = messageStore[conversationId] ?: return emptyList()
        val index = list.indexOfFirst { it.id == messageId }
        if (index >= 0) {
            val old = list[index]
            list[index] = old.copy(body = text, decryptedBody = text, editedAtEpochMs = System.currentTimeMillis())
        }
        return list.toList()
    }

    fun toggleReaction(conversationId: String, messageId: String, emoji: String, language: AppLanguage): List<ChatMessage> {
        ensureSeeded(language)
        val list = messageStore[conversationId] ?: return emptyList()
        val index = list.indexOfFirst { it.id == messageId }
        if (index >= 0) {
            val old = list[index]
            val reactions = old.reactions.toMutableMap()
            val next = (reactions[emoji] ?: 0) + 1
            reactions[emoji] = next
            list[index] = old.copy(reactions = reactions)
        }
        return list.toList()
    }

    fun deleteMessage(conversationId: String, messageId: String, language: AppLanguage): List<ChatMessage> {
        ensureSeeded(language)
        val list = messageStore[conversationId] ?: return emptyList()
        list.removeAll { it.id == messageId }
        return list.toList()
    }

    fun createGroup(title: String, members: List<GlobalId>, language: AppLanguage): ConversationSummaryModel {
        ensureSeeded(language)
        val id = "demo-created-group-${nextGroupSequence++}"
        messageStore[id] = mutableListOf(
            demoMessage(
                conversationId = id,
                sender = profile.globalId,
                text = language.pick("Группа создана в demo-режиме.", "Групу створено в demo-режимі.", "Group created in demo mode."),
                offsetMs = 0,
                encryptionMode = ChatEncryptionMode.SERVER,
            )
        )
        return ConversationSummaryModel(
            id = id,
            kind = ConversationKind.GROUP,
            title = title,
            peerGlobalId = null,
            memberCount = (members.distinct().size + 1).coerceAtLeast(1),
            encryptionMode = ChatEncryptionMode.SERVER,
            lastMessagePreview = latestPreview(id, language),
            lastMessageAtEpochMs = messageStore[id]?.lastOrNull()?.createdAtEpochMs,
            unreadCount = 0,
        )
    }

    fun setPeerBlocked(peer: GlobalId, blocked: Boolean): Boolean {
        if (blocked) blockedPeers += peer.value else blockedPeers -= peer.value
        return peer.value in blockedPeers
    }

    fun peerBlocked(peer: GlobalId): Boolean = peer.value in blockedPeers

    private fun ensureSeeded(language: AppLanguage) {
        if (messageStore.isNotEmpty()) return
        backend.initialMessages(language).forEach { (conversationId, messages) ->
            messageStore[conversationId] = messages.toMutableList()
        }
    }

    private fun directConversation(peerId: Long, language: AppLanguage): ConversationSummaryModel {
        val person = people(language).firstOrNull { it.globalId.value == peerId }
        val id = directId(peerId)
        return ConversationSummaryModel(
            id = id,
            kind = ConversationKind.DIRECT,
            title = person?.name ?: peerId.toString(),
            peerGlobalId = GlobalId(peerId),
            memberCount = 2,
            encryptionMode = ChatEncryptionMode.E2EE,
            lastMessagePreview = latestPreview(id, language),
            lastMessageAtEpochMs = messageStore[id]?.lastOrNull()?.createdAtEpochMs,
            unreadCount = if (peerId == 2L) 1 else 0,
        )
    }

    private fun latestPreview(conversationId: String, language: AppLanguage): String =
        messageStore[conversationId]?.lastOrNull()?.decryptedBody
            ?: language.pick("Нет сообщений", "Немає повідомлень", "No messages")

    private fun directId(peerId: Long): String = "demo-direct-$peerId"

    private fun demoMessage(
        conversationId: String,
        sender: GlobalId,
        text: String,
        offsetMs: Long,
        encryptionMode: ChatEncryptionMode,
    ): ChatMessage {
        val id = "demo-${nextMessageSequence++}"
        return ChatMessage(
            id = id,
            conversationId = conversationId,
            senderGlobalId = sender,
            clientMessageId = id,
            messageType = "text",
            encryptionMode = encryptionMode,
            body = text,
            ciphertextB64 = null,
            nonceB64 = null,
            keyId = null,
            ratchetCounter = null,
            senderEphemeralPublicKeyB64 = null,
            recipientPrekeyId = null,
            attachments = emptyList(),
            status = "delivered",
            createdAtEpochMs = System.currentTimeMillis() + offsetMs,
            decryptedBody = text,
            deliveredCount = 1,
            readCount = if (sender == profile.globalId) 1 else 0,
        )
    }
}
