package org.federationofavatars.brotherhood.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.time.LocalDate
import java.time.Period
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.federationofavatars.brotherhood.BuildConfig
import org.federationofavatars.brotherhood.auth.SessionStore
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.AssessmentLocalStore
import org.federationofavatars.brotherhood.data.CoreProfileCatalog
import org.federationofavatars.brotherhood.data.CoreProfileQuestion
import org.federationofavatars.brotherhood.data.CityCatalog
import org.federationofavatars.brotherhood.data.DemoRepository
import org.federationofavatars.brotherhood.data.DemoSimulationEngine
import org.federationofavatars.brotherhood.data.SettingsStore
import org.federationofavatars.brotherhood.data.ProfileAvatarStore
import org.federationofavatars.brotherhood.data.ProfileLocalStore
import org.federationofavatars.brotherhood.data.NumerologyKnowledgeCatalog
import org.federationofavatars.brotherhood.data.NumerologyKnowledgeEntry
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.data.LanguageCatalog
import org.federationofavatars.brotherhood.data.format
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.data.NumerologyLifePathEntry
import org.federationofavatars.brotherhood.domain.AccountRatingCalculator
import org.federationofavatars.brotherhood.domain.AssessmentScorer
import org.federationofavatars.brotherhood.domain.AssessmentProductEngine
import org.federationofavatars.brotherhood.domain.AssessmentModuleCompatibility
import org.federationofavatars.brotherhood.domain.AssessmentModuleCompatibilityEngine
import org.federationofavatars.brotherhood.domain.AssessmentModuleProgress
import org.federationofavatars.brotherhood.domain.PublicAssessmentResult
import org.federationofavatars.brotherhood.domain.FriendshipCompatibilityEngine
import org.federationofavatars.brotherhood.domain.HybridCompatibilityEngine
import org.federationofavatars.brotherhood.domain.IndependentCompatibilityEngine
import org.federationofavatars.brotherhood.domain.IndependentCompatibilitySet
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.domain.NumerologyReading
import org.federationofavatars.brotherhood.domain.NumerologyReadingEngine
import org.federationofavatars.brotherhood.domain.SelfAnalysisEngine
import org.federationofavatars.brotherhood.domain.DemoLatentProfileFactory
import org.federationofavatars.brotherhood.domain.LatentProfileEngine
import org.federationofavatars.brotherhood.domain.PositiveProfileProjector
import org.federationofavatars.brotherhood.domain.PsychologicalProductEngine
import org.federationofavatars.brotherhood.domain.PsychologicalProfileView
import org.federationofavatars.brotherhood.domain.PsychologicalAnalysisView
import org.federationofavatars.brotherhood.domain.PsychologicalReportSnapshot
import org.federationofavatars.brotherhood.domain.QualityMatchingEngine
import org.federationofavatars.brotherhood.crypto.PrivateChatCrypto
import org.federationofavatars.brotherhood.domain.ZodiacEngine
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppRoute
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentQuestion
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CalibrationPilotInfo
import org.federationofavatars.brotherhood.model.AppUpdateInfo
import org.federationofavatars.brotherhood.model.ChatEncryptionMode
import org.federationofavatars.brotherhood.model.ChatMessage
import org.federationofavatars.brotherhood.model.ChatAttachment
import org.federationofavatars.brotherhood.model.ConversationKind
import org.federationofavatars.brotherhood.model.ConversationSummaryModel
import org.federationofavatars.brotherhood.model.PendingChatAttachment
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.DiscoveryPreferences
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.GroupMember
import org.federationofavatars.brotherhood.model.HospitalityArrivalDetails
import org.federationofavatars.brotherhood.model.HospitalityAvailability
import org.federationofavatars.brotherhood.model.HospitalityAvailabilityMode
import org.federationofavatars.brotherhood.model.HospitalityAvailabilityState
import org.federationofavatars.brotherhood.model.HospitalityEligibility
import org.federationofavatars.brotherhood.model.HospitalityEvent
import org.federationofavatars.brotherhood.model.HospitalityHostDetails
import org.federationofavatars.brotherhood.model.HospitalityHostProfile
import org.federationofavatars.brotherhood.model.HospitalityPrivateLocation
import org.federationofavatars.brotherhood.model.HospitalityReputation
import org.federationofavatars.brotherhood.model.HospitalityReviewState
import org.federationofavatars.brotherhood.model.HospitalitySleepingCondition
import org.federationofavatars.brotherhood.model.HospitalityTimelineItem
import org.federationofavatars.brotherhood.model.HospitalityVerification
import org.federationofavatars.brotherhood.model.StayConfirmationValue
import org.federationofavatars.brotherhood.model.StayRequest
import org.federationofavatars.brotherhood.model.StayRequestStatus
import org.federationofavatars.brotherhood.model.MainTab
import org.federationofavatars.brotherhood.model.ProfileVisibility
import org.federationofavatars.brotherhood.model.PositiveAssessmentReveal
import org.federationofavatars.brotherhood.model.DesiredQuality
import org.federationofavatars.brotherhood.model.SearchIntent
import org.federationofavatars.brotherhood.model.SearchRole
import org.federationofavatars.brotherhood.network.ApiConfig
import org.federationofavatars.brotherhood.network.AuthRemoteRepository
import org.federationofavatars.brotherhood.network.RemoteDataRepository
import org.federationofavatars.brotherhood.network.ChatRemoteRepository
import org.federationofavatars.brotherhood.network.HospitalityRemoteRepository
import org.federationofavatars.brotherhood.security.HospitalitySecureStore

private data class NavigationSnapshot(val route: AppRoute, val tab: MainTab)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val assessmentStore = AssessmentLocalStore(application)
    private val settingsStore = SettingsStore(application)
    private val languageCatalog = LanguageCatalog(application)
    private val cityCatalog = CityCatalog(application)
    private val profileStore = ProfileLocalStore(application)
    private val avatarStore = ProfileAvatarStore(application)
    private val numerologyKnowledge = NumerologyKnowledgeCatalog(application)
    private val sessionStore = SessionStore(application)
    private val authRepository = AuthRemoteRepository(application)
    private val demoEngine = DemoSimulationEngine()
    private var activeSession by mutableStateOf(sessionStore.load())
    private val initialProfile = profileStore.load(if (BuildConfig.DEBUG) demoEngine.profile else DemoRepository.profile).let { local ->
        activeSession?.let { local.copy(globalId = it.globalId) } ?: local
    }
    private val remoteRepository = RemoteDataRepository(application)
    private val chatRepository = ChatRemoteRepository(application)
    private val hospitalityRepository = HospitalityRemoteRepository(application)
    private val hospitalitySecureStore = HospitalitySecureStore(application)
    private val privateChatCrypto by lazy { PrivateChatCrypto(application, profile.globalId) }
    private val sessionAccessToken: String get() = activeSession?.accessToken.orEmpty()

    var route by mutableStateOf(if (activeSession?.accessUsable == true) AppRoute.HOME else AppRoute.AUTH)
        private set
    var selectedTab by mutableStateOf(settingsStore.mainTab())
        private set
    private val navigationHistory = ArrayDeque<NavigationSnapshot>()
    var canNavigateBack by mutableStateOf(false)
        private set
    var language by mutableStateOf(languageCatalog.language(settingsStore.languageTag()))
        private set
    var themeMode by mutableStateOf(settingsStore.theme())
        private set
    var calibrationOptIn by mutableStateOf(settingsStore.calibrationOptIn())
        private set
    var calibrationPilotInfo by mutableStateOf<CalibrationPilotInfo?>(null)
        private set
    var calibrationPilotBusy by mutableStateOf(false)
        private set
    var authProvider by mutableStateOf(activeSession?.provider)
        private set
    var authBusy by mutableStateOf(false)
        private set
    var emailCodeRequestedFor by mutableStateOf<String?>(null)
        private set
    var selectedCity by mutableStateOf(initialProfile.city)
        private set
    var radiusKm by mutableIntStateOf(25)
        private set
    var discoveryPreferences by mutableStateOf(settingsStore.discoveryPreferences())
        private set
    var searchIntent by mutableStateOf(settingsStore.searchIntent())
        private set
    var profileVisibility by mutableStateOf(settingsStore.profileVisibility())
        private set
    var skippedCandidateIds by mutableStateOf(settingsStore.skippedCandidates())
        private set
    var lastSkippedCandidateId by mutableStateOf<Long?>(null)
        private set
    var communityKind by mutableStateOf(CommunityKind.INTEREST)
        private set
    var locationStatus by mutableStateOf<String?>(null)
        private set
    var selectedCandidateId by mutableStateOf<Long?>(null)
        private set
    var selectedCommunityId by mutableStateOf<String?>(null)
        private set
    var joinedCommunityIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var connectionRequests by mutableStateOf<Set<Long>>(emptySet())
        private set
    var uiMessage by mutableStateOf<String?>(null)
        private set

    var remotePeople by mutableStateOf<List<FriendCandidate>>(emptyList())
        private set
    var remoteCommunities by mutableStateOf<List<Community>>(emptyList())
        private set
    var remoteLoading by mutableStateOf(false)
        private set
    var remoteStatus by mutableStateOf<String?>(null)
        private set

    var hospitalityOnly by mutableStateOf(false)
        private set
    var hospitalityBusy by mutableStateOf(false)
        private set
    var hospitalityHostProfile by mutableStateOf<HospitalityHostProfile?>(null)
        private set
    var hospitalityAvailability by mutableStateOf<List<HospitalityAvailability>>(emptyList())
        private set
    var hospitalityRequests by mutableStateOf<List<StayRequest>>(emptyList())
        private set
    var selectedStayRequest by mutableStateOf<StayRequest?>(null)
        private set
    var hospitalityEligibility by mutableStateOf<HospitalityEligibility?>(null)
        private set
    var candidateHospitality by mutableStateOf<HospitalityHostDetails?>(null)
        private set
    var hospitalityReputation by mutableStateOf<HospitalityReputation?>(null)
        private set
    var candidateHospitalityReputation by mutableStateOf<HospitalityReputation?>(null)
        private set
    var hospitalityVerification by mutableStateOf<HospitalityVerification?>(null)
        private set
    var hospitalityReviewState by mutableStateOf<HospitalityReviewState?>(null)
        private set
    var hospitalityArrivalDetails by mutableStateOf<HospitalityArrivalDetails?>(null)
        private set
    var hospitalityEvents by mutableStateOf<List<HospitalityEvent>>(emptyList())
        private set

    var conversations by mutableStateOf<List<ConversationSummaryModel>>(emptyList())
        private set
    var activeConversation by mutableStateOf<ConversationSummaryModel?>(null)
        private set
    var chatMessages by mutableStateOf<List<ChatMessage>>(emptyList())
        private set
    var chatLoading by mutableStateOf(false)
        private set
    var chatSecurityFingerprint by mutableStateOf<String?>(null)
        private set
    var peerChatFingerprint by mutableStateOf<String?>(null)
        private set
    var appUpdateInfo by mutableStateOf<AppUpdateInfo?>(null)
        private set
    var replyToMessage by mutableStateOf<ChatMessage?>(null)
        private set
    var editingMessage by mutableStateOf<ChatMessage?>(null)
        private set
    var typingGlobalIds by mutableStateOf<List<GlobalId>>(emptyList())
        private set
    var activePeerBlockedByMe by mutableStateOf(false)
        private set
    var activeGroupMembers by mutableStateOf<List<GroupMember>>(emptyList())
        private set

    val chatTimeline: List<HospitalityTimelineItem>
        get() = (chatMessages.map { HospitalityTimelineItem.Message(it) } + hospitalityEvents.map { HospitalityTimelineItem.Event(it) })
            .sortedBy(HospitalityTimelineItem::epochMs)

    private var typingStopJob: Job? = null
    private var typingActiveSent = false

    var activeAssessmentId by mutableStateOf<String?>(null)
        private set
    var currentQuestionIndex by mutableIntStateOf(0)
        private set
    var assessmentAnswers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    private var assessmentQuestionOrder by mutableStateOf<List<String>>(emptyList())
    private var assessmentStartedAtEpochMs: Long = 0L
    private var assessmentQuestionShownAtEpochMs: Long = 0L
    private var assessmentResponseLatencyMs by mutableStateOf<Map<String, Long>>(emptyMap())
    private var assessmentAnswerChanges by mutableStateOf<Map<String, Int>>(emptyMap())
    var currentResult by mutableStateOf<AssessmentResult?>(null)
        private set
    var currentPositiveReveal by mutableStateOf<PositiveAssessmentReveal?>(null)
        private set
    var completedResults by mutableStateOf(assessmentStore.loadAll())
        private set

    var activeCoreModule by mutableStateOf<String?>(null)
        private set
    var coreQuestionIndex by mutableIntStateOf(0)
        private set
    var coreAnswers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    private var coreQuestionOrder by mutableStateOf<List<String>>(emptyList())

    val supportedLanguages: List<AppLanguage> get() = languageCatalog.languages
    val cities: List<String> get() = cityCatalog.values
    val assessmentDefinitions: List<AssessmentDefinition>
        get() = AssessmentCatalog.assessments

    /** User-facing product grouping over the current assessment bank. */
    val assessmentModules: List<AssessmentModuleProgress>
        get() = AssessmentProductEngine.modules(assessmentDefinitions, completedResults, language)

    fun publicAssessmentResult(result: AssessmentResult): PublicAssessmentResult? {
        val definition = AssessmentCatalog.byId(result.assessmentId) ?: return null
        return AssessmentProductEngine.publicResult(definition, result, language)
    }

    fun canRetakeAssessment(id: String, nowEpochMs: Long = System.currentTimeMillis()): Boolean {
        val result = completedResults[id] ?: return true
        return AssessmentProductEngine.canRetake(result, nowEpochMs)
    }

    fun retakeAvailableAtEpochMs(id: String): Long? =
        completedResults[id]?.let(AssessmentProductEngine::retakeAvailableAtEpochMs)
    val trustEvents get() = if (BuildConfig.DEBUG) demoEngine.trustEvents else emptyList()
    val searchQualityDefinitions get() = LatentTraitCatalog.qualities
    val searchRoles get() = SearchRole.entries
    var profile by mutableStateOf(initialProfile)
        private set

    init {
        val restored = activeSession
        if (ApiConfig.isConfigured && restored != null && !restored.accessUsable && restored.refreshUsable) {
            viewModelScope.launch {
                runCatching { authRepository.refresh(requireNotNull(restored.refreshToken)) }
                    .onSuccess(::acceptSession)
                    .onFailure { activeSession = null; sessionStore.clear(); resetNavigation(AppRoute.AUTH) }
            }
        }
    }

    val accountRating
        get() = AccountRatingCalculator.calculate(profile.completedProfileSections, completedResults.keys)

    val selfAnalysis
        get() = SelfAnalysisEngine.build(profile, completedResults, language)

    val psychologicalProfile: PsychologicalProfileView
        get() = PsychologicalProductEngine.profile(completedResults, language)

    val psychologicalAnalysis: PsychologicalAnalysisView
        get() = PsychologicalProductEngine.analysis(profile, completedResults, language)

    val psychologicalReport: PsychologicalReportSnapshot
        get() = PsychologicalProductEngine.report(profile, completedResults, language)

    val numerologyReading: NumerologyReading
        get() = NumerologyReadingEngine.calculate(profile.birthDate, profile.latinName, profile.numerology)

    fun numerologyEntry(section: String, key: String): NumerologyKnowledgeEntry? =
        numerologyKnowledge.entry(section, key, language)

    fun numerologyLifePath(number: Int): NumerologyLifePathEntry? =
        numerologyKnowledge.lifePath(number, language)

    private val myAssessmentScores: Map<String, Int>
        get() = completedResults.mapValues { it.value.totalScore }

    private val myLatentProfile
        get() = LatentProfileEngine.build(completedResults.values)

    val myPositiveQualities: List<String>
        get() = PositiveProfileProjector.topQualities(myLatentProfile, language)

    val positiveDiscoveryHistory: List<PositiveAssessmentReveal>
        get() = PositiveProfileProjector.history(completedResults.values, language)

    val nextRecommendedAssessment: AssessmentDefinition?
        get() = assessmentDefinitions.firstOrNull { it.id !in completedResults }

    val candidates: List<FriendCandidate>
        get() {
            val source = if (remotePeople.isNotEmpty()) remotePeople else if (BuildConfig.DEBUG) demoEngine.people(language) else emptyList()
            return source.filter {
                it.city == selectedCity && it.distanceKm <= radiusKm &&
                    (!hospitalityOnly || !BuildConfig.DEBUG || demoEngine.hospitalityHostDetails(it.globalId) != null)
            }.map { candidate ->
                val withCompatibility = if (candidate.serverBacked) {
                    val hybrid = HybridCompatibilityEngine.calculate(
                        me = profile,
                        candidate = candidate,
                        friendshipTests = candidate.friendshipTestScore,
                        sharedTestCount = candidate.commonTestCount
                    )
                    candidate.copy(compatibility = IndependentCompatibilityEngine.fromBreakdown(hybrid).overall ?: hybrid.total)
                } else {
                    val candidateScores = AssessmentCatalog.assessments.associate { definition ->
                        definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id)
                    }
                    val testResult = FriendshipCompatibilityEngine.calculate(
                        myScores = myAssessmentScores,
                        candidateScores = candidateScores,
                        sharedInterestPercent = overlap(profile.interests, candidate.interests),
                        trustScore = candidate.trustScore
                    )
                    val hybrid = HybridCompatibilityEngine.calculate(
                        me = profile,
                        candidate = candidate,
                        friendshipTests = testResult.testsScore,
                        sharedTestCount = testResult.commonTests,
                        testCategoryScores = testResult.categoryScores,
                    )
                    candidate.copy(compatibility = IndependentCompatibilityEngine.fromBreakdown(hybrid).overall ?: hybrid.total)
                }

                if (withCompatibility.serverBacked) {
                    // Production server returns only public-safe qualityFit/positiveQualities; raw latent vectors never cross this DTO.
                    withCompatibility
                } else {
                    val hiddenProfile = DemoLatentProfileFactory.fromSeed(withCompatibility.assessmentProfileSeed)
                    val fit = QualityMatchingEngine.calculate(searchIntent, hiddenProfile, language)
                    withCompatibility.copy(
                        qualityFit = fit.score,
                        positiveQualities = PositiveProfileProjector.topQualities(hiddenProfile, language)
                    )
                }
            }.filter { candidate ->
                candidate.globalId.value !in skippedCandidateIds &&
                    (!discoveryPreferences.verifiedOnly || candidate.verified) &&
                    (!discoveryPreferences.onlineOnly || candidate.online) &&
                    candidate.trustScore >= discoveryPreferences.minTrust &&
                    candidate.compatibility >= discoveryPreferences.minCompatibility &&
                    (!discoveryPreferences.requireSharedInterests || overlap(profile.interests, candidate.interests) > 0) &&
                    (!discoveryPreferences.hideRequested || candidate.globalId.value !in connectionRequests)
            }.sortedWith(
                if (searchIntent.qualities.isNotEmpty()) compareByDescending<FriendCandidate> { it.qualityFit }.thenByDescending { it.compatibility }
                else compareByDescending(FriendCandidate::compatibility)
            )
        }

    val selectedCandidate: FriendCandidate?
        get() = selectedCandidateId?.let { id -> candidates.firstOrNull { it.globalId.value == id } ?: if (BuildConfig.DEBUG) demoEngine.people(language).firstOrNull { it.globalId.value == id } else null }

    fun compatibility(candidate: FriendCandidate): CompatibilityBreakdown {
        if (candidate.serverBacked) {
            val localBreakdown = HybridCompatibilityEngine.calculate(
                profile, candidate, candidate.friendshipTestScore, candidate.commonTestCount
            )
            return localBreakdown
        }
        val candidateScores = AssessmentCatalog.assessments.associate { definition ->
            definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id)
        }
        val testResult = FriendshipCompatibilityEngine.calculate(
            myScores = myAssessmentScores,
            candidateScores = candidateScores,
            sharedInterestPercent = overlap(profile.interests, candidate.interests),
            trustScore = candidate.trustScore
        )
        return HybridCompatibilityEngine.calculate(
            profile, candidate, testResult.testsScore, testResult.commonTests, testResult.categoryScores
        )
    }

    /** Q28 canonical view: each system is independent 0..100; overall is only a simple mean. */
    fun independentCompatibility(candidate: FriendCandidate): IndependentCompatibilitySet =
        IndependentCompatibilityEngine.fromBreakdown(compatibility(candidate))

    fun assessmentModuleCompatibility(candidate: FriendCandidate): List<AssessmentModuleCompatibility> {
        if (candidate.serverBacked) return emptyList() // server DTO does not yet expose module-safe scores
        val candidateScores = AssessmentCatalog.assessments.associate { definition ->
            definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id)
        }
        return AssessmentModuleCompatibilityEngine.calculate(myAssessmentScores, candidateScores)
    }

    val communities: List<Community>
        get() {
            val source = if (remoteCommunities.isNotEmpty()) remoteCommunities else if (BuildConfig.DEBUG) demoEngine.communities(language) else emptyList()
            return source.filter {
                it.kind == communityKind && (it.city == selectedCity || it.online)
            }.map { it.copy(joined = it.id in joinedCommunityIds) }
        }

    val selectedCommunity: Community?
        get() = selectedCommunityId?.let { id -> communities.firstOrNull { it.id == id } ?: if (BuildConfig.DEBUG) demoEngine.communities(language).firstOrNull { it.id == id }?.copy(joined = id in joinedCommunityIds) else null }

    val activeAssessment: AssessmentDefinition?
        get() = activeAssessmentId?.let(AssessmentCatalog::byId)

    val currentQuestion: AssessmentQuestion?
        get() {
            val definition = activeAssessment ?: return null
            val id = assessmentQuestionOrder.getOrNull(currentQuestionIndex) ?: return definition.questions.getOrNull(currentQuestionIndex)
            return definition.questions.firstOrNull { it.id == id }
        }

    private val rawCoreQuestions: List<CoreProfileQuestion>
        get() = when (activeCoreModule) {
            "p32" -> CoreProfileCatalog.personality32Questions
            "enneagram" -> CoreProfileCatalog.enneagramQuestions
            else -> emptyList()
        }

    val coreQuestions: List<CoreProfileQuestion>
        get() {
            val source = rawCoreQuestions
            if (source.isEmpty() || coreQuestionOrder.isEmpty()) return source
            val byId = source.associateBy(CoreProfileQuestion::id)
            return coreQuestionOrder.mapNotNull(byId::get)
        }

    val currentCoreQuestion: CoreProfileQuestion?
        get() = coreQuestions.getOrNull(coreQuestionIndex)

    val canFinishCoreAssessment: Boolean
        get() = coreQuestions.isNotEmpty() && coreQuestions.all { coreAnswers[it.id] in 1..4 }

    val canFinishAssessment: Boolean
        get() = activeAssessment?.questions?.all { assessmentAnswers[it.id] in 1..4 } == true

    private fun updateBackAvailability() {
        canNavigateBack = navigationHistory.isNotEmpty()
    }

    private fun resetNavigation(target: AppRoute) {
        navigationHistory.clear()
        route = target
        updateBackAvailability()
    }

    private fun navigateTo(target: AppRoute) {
        if (route == target) return
        navigationHistory.addLast(NavigationSnapshot(route, selectedTab))
        while (navigationHistory.size > 32) navigationHistory.removeFirst()
        route = target
        updateBackAvailability()
    }

    fun navigateBack(): Boolean {
        if (navigationHistory.isEmpty()) return false
        val previous = navigationHistory.removeLast()
        activeConversation = null
        chatMessages = emptyList()
        route = previous.route
        selectedTab = previous.tab
        settingsStore.setMainTab(selectedTab)
        updateBackAvailability()
        return true
    }

    fun signIn(provider: AuthProvider) {
        if (!ApiConfig.isConfigured) {
            if (BuildConfig.DEBUG) {
                authProvider = provider
                settingsStore.setOnboardingComplete(true)
                resetNavigation(AppRoute.HOME)
                uiMessage = language.pick(
                    "Локальный demo-режим: backend URL не настроен.",
                    "Локальний demo-режим: backend URL не налаштовано.",
                    "Local demo mode: backend URL is not configured.",
                )
                return
            }
            uiMessage = language.pick(
                "Безопасный backend URL не настроен.",
                "Безпечний backend URL не налаштовано.",
                "Secure backend URL is not configured.",
            )
            return
        }
        when (provider) {
            AuthProvider.EMAIL -> emailCodeRequestedFor = ""
            AuthProvider.GOOGLE, AuthProvider.TELEGRAM, AuthProvider.PASSKEY -> Unit // Native credential/browser UI is launched by AuthScreen.
            AuthProvider.FACEBOOK -> uiMessage = language.pick(
                "Facebook credential acquisition требует конфигурации приложения провайдера; серверная проверка готова.",
                "Отримання Facebook credential потребує конфігурації застосунку провайдера; серверна перевірка готова.",
                "Facebook credential acquisition requires provider app configuration; server verification is ready.",
            )
        }
    }

    suspend fun googleServerClientId(): String = authRepository.googleClientId()

    suspend fun telegramAuthorizationUrl(): String = authRepository.beginTelegramOidc()

    fun completeTelegramOidcCallback(uri: Uri) {
        if (!ApiConfig.isConfigured) return
        val expected = runCatching { Uri.parse(BuildConfig.TELEGRAM_APP_CALLBACK_URI) }.getOrNull() ?: return
        val sameEndpoint = uri.scheme?.equals(expected.scheme, ignoreCase = true) == true &&
            uri.host?.equals(expected.host, ignoreCase = true) == true &&
            uri.path.orEmpty() == expected.path.orEmpty()
        if (!sameEndpoint) return
        val providerError = uri.getQueryParameter("error")
        val ticket = uri.getQueryParameter("ticket")
        if (!providerError.isNullOrBlank() || ticket.isNullOrBlank()) {
            uiMessage = language.pick(
                "Telegram-вход отменён или отклонён.",
                "Telegram-вхід скасовано або відхилено.",
                "Telegram sign-in was canceled or rejected.",
            )
            return
        }
        viewModelScope.launch {
            authBusy = true
            runCatching { authRepository.finishTelegramOidc(ticket) }
                .onSuccess(::acceptSession)
                .onFailure { uiMessage = localizedAuthFailure() }
            authBusy = false
        }
    }

    fun completeProviderCredential(provider: AuthProvider, credential: String, nonce: String? = null) {
        if (!ApiConfig.isConfigured || credential.isBlank()) return
        viewModelScope.launch {
            authBusy = true
            runCatching { authRepository.exchangeProviderCredential(provider, credential, nonce) }
                .onSuccess(::acceptSession)
                .onFailure { uiMessage = localizedAuthFailure() }
            authBusy = false
        }
    }

    fun requestEmailCode(email: String) {
        if (!ApiConfig.isConfigured || email.isBlank()) return
        viewModelScope.launch {
            authBusy = true
            runCatching { authRepository.requestEmailCode(email, language.tag) }
                .onSuccess { emailCodeRequestedFor = email.trim() }
                .onFailure { uiMessage = localizedAuthFailure() }
            authBusy = false
        }
    }

    fun verifyEmailCode(code: String) {
        val email = emailCodeRequestedFor?.takeIf(String::isNotBlank) ?: return
        viewModelScope.launch {
            authBusy = true
            runCatching { authRepository.verifyEmailCode(email, code) }
                .onSuccess { emailCodeRequestedFor = null; acceptSession(it) }
                .onFailure { uiMessage = localizedAuthFailure() }
            authBusy = false
        }
    }

    fun cancelEmailAuth() { emailCodeRequestedFor = null }

    fun finishPasskeyAuthentication(challengeId: String, credentialJson: String) {
        viewModelScope.launch {
            authBusy = true
            runCatching { authRepository.finishPasskeyAuthentication(challengeId, credentialJson) }
                .onSuccess(::acceptSession)
                .onFailure { uiMessage = localizedAuthFailure() }
            authBusy = false
        }
    }

    suspend fun passkeyAuthenticationOptions(): Pair<String, String> = authRepository.passkeyAuthenticationOptions()

    suspend fun passkeyRegistrationOptions(): Pair<String, String> {
        val token = sessionAccessToken
        require(token.isNotBlank()) { "Authenticated session required" }
        return authRepository.passkeyRegistrationOptions(token)
    }

    fun finishPasskeyRegistration(challengeId: String, credentialJson: String) {
        val token = sessionAccessToken
        if (token.isBlank()) return
        viewModelScope.launch {
            authBusy = true
            runCatching { authRepository.finishPasskeyRegistration(token, challengeId, credentialJson) }
                .onSuccess { uiMessage = language.pick("Passkey добавлен", "Passkey додано", "Passkey added") }
                .onFailure { uiMessage = localizedAuthFailure() }
            authBusy = false
        }
    }

    val hasAuthenticatedSession: Boolean get() = activeSession?.accessUsable == true

    private fun acceptSession(session: SessionStore.StoredSession) {
        sessionStore.save(session)
        activeSession = session
        authProvider = session.provider
        if (profile.globalId != session.globalId) {
            profile = profile.copy(globalId = session.globalId)
            profileStore.save(profile)
        }
        settingsStore.setOnboardingComplete(true)
        resetNavigation(AppRoute.HOME)
        restoreRemoteSettingsOrUploadLocal()
        refreshRemoteData()
    }

    private fun restoreRemoteSettingsOrUploadLocal() {
        val token = sessionAccessToken
        if (!ApiConfig.isConfigured || token.isBlank()) return
        viewModelScope.launch {
            val server = remoteRepository.loadSettings(profile.globalId, token)
            if (server == null) {
                syncUserSettings()
                return@launch
            }
            language = languageCatalog.language(server.locale)
            themeMode = server.theme
            profileVisibility = server.profileVisibility
            discoveryPreferences = server.discovery
            searchIntent = server.searchIntent
            settingsStore.setLanguage(language)
            settingsStore.setTheme(themeMode)
            settingsStore.setProfileVisibility(profileVisibility)
            settingsStore.setDiscoveryPreferences(discoveryPreferences)
            settingsStore.setSearchIntent(searchIntent)
        }
    }

    private fun syncUserSettings() {
        val token = sessionAccessToken
        if (!ApiConfig.isConfigured || token.isBlank()) return
        viewModelScope.launch {
            runCatching {
                remoteRepository.syncSettings(
                    profile.globalId, language, themeMode, profileVisibility, discoveryPreferences, searchIntent, token
                )
            }
        }
    }

    private fun localizedAuthFailure(): String = language.pick(
        "Не удалось подтвердить вход. Проверьте подключение и настройки провайдера.",
        "Не вдалося підтвердити вхід. Перевірте підключення та налаштування провайдера.",
        "Sign-in could not be verified. Check the connection and provider configuration.",
    )

    fun signOut() {
        val token = sessionAccessToken
        activeSession = null
        sessionStore.clear()
        authProvider = null
        resetNavigation(AppRoute.AUTH)
        if (ApiConfig.isConfigured && token.isNotBlank()) {
            viewModelScope.launch { runCatching { authRepository.logout(token) } }
        }
    }

    fun selectTab(tab: MainTab) {
        if (route == AppRoute.HOME && selectedTab != tab) {
            navigationHistory.addLast(NavigationSnapshot(route, selectedTab))
            while (navigationHistory.size > 32) navigationHistory.removeFirst()
        } else if (route != AppRoute.HOME) {
            navigationHistory.addLast(NavigationSnapshot(route, selectedTab))
            while (navigationHistory.size > 32) navigationHistory.removeFirst()
        }
        selectedTab = tab
        settingsStore.setMainTab(tab)
        route = AppRoute.HOME
        updateBackAvailability()
    }
    fun cityLabel(city: String): String = cityCatalog.label(city, language)

    fun selectCity(city: String) {
        selectedCity = city
        locationStatus = language.format(
            "city.selected",
            "Город выбран: {city}",
            "Місто обрано: {city}",
            "City selected: {city}",
            mapOf("city" to cityLabel(city)),
        )
        refreshRemoteData()
    }
    fun setRadius(value: Int) { radiusKm = value; refreshRemoteData() }
    fun openDiscoveryFilters() { navigateTo(AppRoute.DISCOVERY_FILTERS) }
    fun updateDiscoveryPreferences(value: DiscoveryPreferences) {
        discoveryPreferences = value.copy(
            minTrust = value.minTrust.coerceIn(0, 100),
            minCompatibility = value.minCompatibility.coerceIn(0, 100),
        )
        settingsStore.setDiscoveryPreferences(discoveryPreferences)
        syncUserSettings()
    }
    fun setSearchRole(role: SearchRole) {
        searchIntent = searchIntent.copy(role = role)
        settingsStore.setSearchIntent(searchIntent)
        syncUserSettings()
    }

    fun toggleDesiredQuality(key: String) {
        if (LatentTraitCatalog.qualityByKey[key] == null) return
        val current = searchIntent.qualities.associateBy { it.key }.toMutableMap()
        if (key in current) current.remove(key) else current[key] = DesiredQuality(key, 3)
        searchIntent = searchIntent.copy(qualities = current.values.sortedBy { it.key })
        settingsStore.setSearchIntent(searchIntent)
        syncUserSettings()
    }

    fun setDesiredQualityImportance(key: String, importance: Int) {
        if (LatentTraitCatalog.qualityByKey[key] == null) return
        val updated = searchIntent.qualities.map { if (it.key == key) it.copy(importance = importance.coerceIn(1, 5)) else it }
        searchIntent = searchIntent.copy(qualities = updated)
        settingsStore.setSearchIntent(searchIntent)
        syncUserSettings()
    }

    fun clearDesiredQualities() {
        searchIntent = searchIntent.copy(qualities = emptyList())
        settingsStore.setSearchIntent(searchIntent)
        syncUserSettings()
    }
    fun changeProfileVisibility(value: ProfileVisibility) {
        profileVisibility = value
        settingsStore.setProfileVisibility(value)
        syncUserSettings()
        syncSharedProfile()
    }

    private fun syncSharedProfile() {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            val sent = runCatching {
                remoteRepository.syncProfile(profile, language, sessionAccessToken, profileVisibility)
            }.getOrDefault(false)
            remoteStatus = if (sent) "profile_visibility_synced" else "profile_visibility_queued"
        }
    }
    fun skipCandidate(candidate: FriendCandidate) {
        lastSkippedCandidateId = candidate.globalId.value
        skippedCandidateIds = skippedCandidateIds + candidate.globalId.value
        settingsStore.setSkippedCandidates(skippedCandidateIds)
    }
    fun undoLastSkip() {
        val id = lastSkippedCandidateId ?: return
        skippedCandidateIds = skippedCandidateIds - id
        settingsStore.setSkippedCandidates(skippedCandidateIds)
        lastSkippedCandidateId = null
    }
    fun resetSkippedCandidates() {
        skippedCandidateIds = emptySet()
        lastSkippedCandidateId = null
        settingsStore.setSkippedCandidates(emptySet())
    }
    fun selectCommunityKind(kind: CommunityKind) { communityKind = kind; refreshRemoteData() }
    fun reportLocationFailure() { locationStatus = language.pick("Не удалось определить город. Выберите его вручную.", "Не вдалося визначити місто. Оберіть його вручну.", "Could not determine the city. Choose it manually.") }
    fun openSettings() { navigateTo(AppRoute.SETTINGS); checkForUpdates() }
    fun openServices() { navigateTo(AppRoute.SERVICES) }
    fun openMessages() { navigateTo(AppRoute.MESSAGES); refreshConversations() }
    fun openSelfAnalysis() { navigateTo(AppRoute.SELF_ANALYSIS) }
    fun openTests() { navigateTo(AppRoute.TESTS) }
    fun openTestResults() { navigateTo(AppRoute.TEST_RESULTS) }
    fun openTrust() { navigateTo(AppRoute.TRUST) }
    fun openHospitalityHome() { navigateTo(AppRoute.HOSPITALITY_HOME); refreshHospitalityHome() }
    fun openHospitalityHostSettings() { navigateTo(AppRoute.HOSPITALITY_HOST_SETTINGS); refreshHospitalityHostProfile() }
    fun openHospitalityAvailability() { navigateTo(AppRoute.HOSPITALITY_AVAILABILITY); refreshHospitalityAvailability() }
    fun openHospitalityRequests() { navigateTo(AppRoute.HOSPITALITY_REQUESTS); refreshHospitalityRequests() }
    fun setHospitalityOnly(enabled: Boolean) { hospitalityOnly = enabled; refreshRemoteData() }

    fun openBusinessCommunities() { communityKind = CommunityKind.BUSINESS; selectTab(MainTab.COMMUNITIES) }
    fun closeOverlay() {
        activeConversation = null
        chatMessages = emptyList()
        hospitalityEvents = emptyList()
        if (!navigateBack()) resetNavigation(AppRoute.HOME)
    }
    fun editProfile() { navigateTo(AppRoute.EDIT_PROFILE) }

    fun openCandidate(candidate: FriendCandidate) {
        selectedCandidateId = candidate.globalId.value
        candidateHospitality = null
        candidateHospitalityReputation = null
        hospitalityEligibility = null
        navigateTo(AppRoute.CANDIDATE)
        if (sessionAccessToken.isNotBlank()) viewModelScope.launch {
            candidateHospitality = runCatching { hospitalityRepository.hostDetails(candidate.globalId, sessionAccessToken) }.getOrNull()
            candidateHospitalityReputation = runCatching { hospitalityRepository.reputation(candidate.globalId, sessionAccessToken) }.getOrNull()
        } else if (BuildConfig.DEBUG) {
            candidateHospitality = demoEngine.hospitalityHostDetails(candidate.globalId)
            candidateHospitalityReputation = candidateHospitality?.let { demoEngine.hospitalityReputation(candidate.globalId) }
        }
    }

    fun requestConnection(candidate: FriendCandidate) {
        connectionRequests = connectionRequests + candidate.globalId.value
    }

    fun showMessage(message: String) { uiMessage = message }
    fun consumeMessage() { uiMessage = null }

    fun openCommunity(community: Community) {
        selectedCommunityId = community.id
        navigateTo(AppRoute.COMMUNITY)
    }

    fun toggleCommunityMembership(community: Community) {
        joinedCommunityIds = if (community.id in joinedCommunityIds) joinedCommunityIds - community.id else joinedCommunityIds + community.id
    }

    fun refreshConversations() {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                conversations = demoEngine.conversations(language)
                remoteStatus = "debug_simulation"
            }
            return
        }
        viewModelScope.launch {
            chatLoading = true
            runCatching {
                val local = privateChatCrypto.localPublicBundle()
                chatRepository.registerDeviceKey(profile.globalId, local, sessionAccessToken)
                chatSecurityFingerprint = privateChatCrypto.fingerprint()
                chatRepository.flushOutbox(sessionAccessToken)
                conversations = chatRepository.conversations(sessionAccessToken)
            }.onFailure { remoteStatus = "chat_offline" }
            chatLoading = false
        }
    }

    fun openDirectChat(candidate: FriendCandidate) {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                activeConversation = demoEngine.openDirect(candidate, language)
                activePeerBlockedByMe = demoEngine.peerBlocked(candidate.globalId)
                chatMessages = demoEngine.messages(requireNotNull(activeConversation).id, language)
                hospitalityEvents = demoEngine.hospitalityEvents(requireNotNull(activeConversation).id)
                activeGroupMembers = emptyList()
                navigateTo(AppRoute.CHAT)
            }
            return
        }
        viewModelScope.launch {
            chatLoading = true
            runCatching {
                val local = privateChatCrypto.localPublicBundle()
                chatRepository.registerDeviceKey(profile.globalId, local, sessionAccessToken)
                chatSecurityFingerprint = privateChatCrypto.fingerprint()
                val conversation = chatRepository.openDirect(candidate.globalId, sessionAccessToken)
                activePeerBlockedByMe = chatRepository.peerBlockedByMe(candidate.globalId, sessionAccessToken)
                val peerKey = chatRepository.peerDeviceKeys(candidate.globalId, sessionAccessToken).firstOrNull()
                peerChatFingerprint = peerKey?.takeIf(privateChatCrypto::verifyAndPinPeer)?.let(privateChatCrypto::peerFingerprint)
                activeConversation = conversation
                navigateTo(AppRoute.CHAT)
                activeGroupMembers = emptyList()
                refreshActiveChat()
            }.onFailure { uiMessage = language.pick("Не удалось открыть защищённый чат", "Не вдалося відкрити захищений чат", "Could not open the secure chat") }
            chatLoading = false
        }
    }

    fun openConversation(conversation: ConversationSummaryModel) {
        activeConversation = conversation
        replyToMessage = null
        editingMessage = null
        typingGlobalIds = emptyList()
        peerChatFingerprint = null
        activePeerBlockedByMe = false
        activeGroupMembers = emptyList()
        navigateTo(AppRoute.CHAT)
        if (sessionAccessToken.isBlank() && BuildConfig.DEBUG) {
            chatMessages = demoEngine.messages(conversation.id, language)
            hospitalityEvents = demoEngine.hospitalityEvents(conversation.id)
            conversation.peerGlobalId?.let { activePeerBlockedByMe = demoEngine.peerBlocked(it) }
            return
        }
        if (conversation.kind == ConversationKind.GROUP && sessionAccessToken.isNotBlank()) {
            refreshActiveGroupMembers()
        }
        if (conversation.encryptionMode == ChatEncryptionMode.E2EE && conversation.peerGlobalId != null && sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                activePeerBlockedByMe = runCatching { chatRepository.peerBlockedByMe(conversation.peerGlobalId, sessionAccessToken) }.getOrDefault(false)
                val peerKey = runCatching { chatRepository.peerDeviceKeys(conversation.peerGlobalId, sessionAccessToken).firstOrNull() }.getOrNull()
                peerChatFingerprint = peerKey?.takeIf(privateChatCrypto::verifyAndPinPeer)?.let(privateChatCrypto::peerFingerprint)
            }
        }
        refreshActiveChat()
    }

    fun createGroupChat(title: String, members: List<GlobalId>) {
        if (title.isBlank()) return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                val conversation = demoEngine.createGroup(title.trim(), members, language)
                conversations = (listOf(conversation) + demoEngine.conversations(language) + conversations).distinctBy { it.id }
                activeConversation = conversation
                chatMessages = demoEngine.messages(conversation.id, language)
                navigateTo(AppRoute.CHAT)
            }
            return
        }
        viewModelScope.launch {
            runCatching {
                val conversation = chatRepository.createGroup(title.trim(), members, sessionAccessToken)
                conversations = (listOf(conversation) + conversations).distinctBy { it.id }
                activeConversation = conversation
                navigateTo(AppRoute.CHAT)
                activeGroupMembers = emptyList()
                refreshActiveGroupMembers()
                refreshActiveChat()
            }.onFailure { uiMessage = language.pick("Не удалось создать группу", "Не вдалося створити групу", "Could not create the group") }
        }
    }

    fun refreshActiveGroupMembers() {
        val conversation = activeConversation ?: return
        if (conversation.kind != ConversationKind.GROUP || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.groupMembers(conversation.id, sessionAccessToken) }
                .onSuccess { activeGroupMembers = it }
        }
    }

    fun addActiveGroupMember(member: GlobalId) {
        val conversation = activeConversation ?: return
        if (conversation.kind != ConversationKind.GROUP || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.addGroupMember(conversation.id, member, sessionAccessToken) }
                .onSuccess { activeGroupMembers = it; refreshConversations() }
                .onFailure { uiMessage = language.pick("Не удалось добавить участника", "Не вдалося додати учасника", "Could not add the member") }
        }
    }

    fun removeActiveGroupMember(member: GlobalId) {
        val conversation = activeConversation ?: return
        if (conversation.kind != ConversationKind.GROUP || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.removeGroupMember(conversation.id, member, sessionAccessToken) }
                .onSuccess { activeGroupMembers = it; refreshConversations() }
                .onFailure { uiMessage = language.pick("Не удалось удалить участника", "Не вдалося видалити учасника", "Could not remove the member") }
        }
    }

    fun refreshActiveChat() {
        val conversation = activeConversation ?: return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) chatMessages = demoEngine.messages(conversation.id, language)
            return
        }
        viewModelScope.launch {
            runCatching {
                val raw = chatRepository.messages(conversation.id, sessionAccessToken)
                val decrypted = if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                    raw.map { message ->
                        if (message.ciphertextB64 == null || message.nonceB64 == null || message.ratchetCounter == null) message
                        else runCatching {
                            message.copy(decryptedBody = privateChatCrypto.decrypt(
                                conversationId = conversation.id,
                                senderGlobalId = message.senderGlobalId,
                                ciphertextB64 = message.ciphertextB64,
                                nonceB64 = message.nonceB64,
                                counter = message.ratchetCounter,
                                senderEphemeralPublicKeyB64 = message.senderEphemeralPublicKeyB64,
                                recipientPrekeyId = message.recipientPrekeyId,
                            ))
                        }.getOrElse { message.copy(decryptedBody = language.pick("🔒 Не удалось расшифровать на этом устройстве", "🔒 Не вдалося розшифрувати на цьому пристрої", "🔒 Could not decrypt on this device")) }
                    }
                } else raw
                chatMessages = foldEditEvents(decrypted)
                hospitalityEvents = if (conversation.kind == ConversationKind.DIRECT) {
                    runCatching { hospitalityRepository.conversationEvents(conversation.id, sessionAccessToken) }.getOrDefault(emptyList())
                } else emptyList()
                typingGlobalIds = runCatching { chatRepository.typingUsers(conversation.id, sessionAccessToken) }.getOrDefault(emptyList())
                chatMessages.lastOrNull()?.let { chatRepository.markRead(conversation.id, it.id, sessionAccessToken) }
            }.onFailure { remoteStatus = "chat_cached_or_offline" }
        }
    }

    private fun foldEditEvents(messages: List<ChatMessage>): List<ChatMessage> {
        val visible = mutableListOf<ChatMessage>()
        messages.sortedBy { it.createdAtEpochMs }.forEach { message ->
            if (message.status == "deleted") {
                return@forEach
            }
            if (message.messageType == "edit" && message.replyToMessageId != null) {
                val index = visible.indexOfFirst { it.id == message.replyToMessageId }
                if (index >= 0) {
                    val original = visible[index]
                    visible[index] = original.copy(
                        body = message.body ?: original.body,
                        decryptedBody = message.decryptedBody ?: message.body ?: original.decryptedBody,
                        editedAtEpochMs = message.editedAtEpochMs ?: message.createdAtEpochMs,
                    )
                }
            } else {
                visible += message
            }
        }
        return visible
    }

    fun openAttachment(message: ChatMessage, attachment: ChatAttachment) {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching {
                val (mode, payload) = chatRepository.attachmentData(attachment.id, sessionAccessToken)
                val bytes = if (mode == ChatEncryptionMode.E2EE) {
                    val counter = requireNotNull(message.ratchetCounter) { "Missing E2EE message counter" }
                    val nonce = requireNotNull(attachment.nonceB64) { "Missing E2EE attachment nonce" }
                    privateChatCrypto.decryptAttachment(
                        conversationId = message.conversationId,
                        senderGlobalId = message.senderGlobalId,
                        counter = counter,
                        clientAttachmentId = attachment.clientAttachmentId,
                        nonceB64 = nonce,
                        ciphertextB64 = android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP),
                    )
                } else payload
                val safeName = attachment.fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "attachment" }
                val directory = File(getApplication<Application>().cacheDir, "chat-attachments").apply { mkdirs() }
                val file = File(directory, "${attachment.id.take(8)}-$safeName")
                file.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(
                    getApplication(),
                    "${BuildConfig.APPLICATION_ID}.files",
                    file,
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, attachment.mimeType)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(intent)
            }.onFailure { error ->
                uiMessage = language.format(
                    "attachment.open_failed",
                    "Не удалось открыть вложение: {error}",
                    "Не вдалося відкрити вкладення: {error}",
                    "Could not open attachment: {error}",
                    mapOf("error" to language.pick("ошибка", "помилка", "error")),
                )
            }
        }
    }

    fun replyTo(message: ChatMessage) {
        if (message.messageType == "edit") return
        editingMessage = null
        replyToMessage = message
    }

    fun clearReply() { replyToMessage = null }

    fun startEditing(message: ChatMessage) {
        if (message.senderGlobalId != profile.globalId || message.attachments.isNotEmpty()) return
        replyToMessage = null
        editingMessage = message
    }

    fun cancelEditing() { editingMessage = null }

    fun onChatDraftChanged(hasText: Boolean) {
        val conversation = activeConversation ?: return
        if (sessionAccessToken.isBlank()) return
        typingStopJob?.cancel()
        if (!hasText) {
            if (typingActiveSent) {
                typingActiveSent = false
                viewModelScope.launch { runCatching { chatRepository.setTyping(conversation.id, false, sessionAccessToken) } }
            }
            return
        }
        if (!typingActiveSent) {
            typingActiveSent = true
            viewModelScope.launch { runCatching { chatRepository.setTyping(conversation.id, true, sessionAccessToken) } }
        }
        typingStopJob = viewModelScope.launch {
            delay(2_500)
            typingActiveSent = false
            runCatching { chatRepository.setTyping(conversation.id, false, sessionAccessToken) }
        }
    }

    fun sendChatMessage(text: String, attachments: List<PendingChatAttachment> = emptyList()) {
        val conversation = activeConversation ?: return
        val editing = editingMessage
        if (editing != null) {
            if (text.isBlank()) return
            editChatMessage(editing, text)
            return
        }
        if (text.isBlank() && attachments.isEmpty()) return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG && attachments.isEmpty()) {
                chatMessages = demoEngine.sendMessage(conversation, profile.globalId, text, language)
                replyToMessage = null
                conversations = demoEngine.conversations(language)
            }
            return
        }
        val clientMessageId = "android-${profile.globalId.value}-${System.currentTimeMillis()}"
        val replyId = replyToMessage?.id
        onChatDraftChanged(false)
        viewModelScope.launch {
            runCatching {
                if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                    val peer = conversation.peerGlobalId ?: error("Direct chat peer is missing")
                    val peerKey = chatRepository.peerDeviceKeys(peer, sessionAccessToken).firstOrNull()
                        ?: error("У собеседника ещё нет ключа E2EE. Он должен хотя бы один раз открыть Brotherhood.")
                    val encrypted = privateChatCrypto.encrypt(conversation.id, peerKey, text, attachments)
                    chatRepository.sendDirect(conversation.id, clientMessageId, encrypted, sessionAccessToken, replyToMessageId = replyId)
                } else {
                    chatRepository.sendGroup(conversation.id, clientMessageId, text, attachments, sessionAccessToken, replyToMessageId = replyId)
                }
                replyToMessage = null
                refreshActiveChat()
                refreshConversations()
            }.onFailure {
                uiMessage = language.pick(
                    "Сообщение сохранено в очереди. Отправка повторится при появлении сети.",
                    "Повідомлення збережено в черзі. Надсилання повториться після появи мережі.",
                    "Message queued. Sending will retry when the network returns.",
                )
            }
        }
    }

    private fun editChatMessage(message: ChatMessage, text: String) {
        val conversation = activeConversation ?: return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                chatMessages = demoEngine.editMessage(conversation.id, message.id, text, language)
                editingMessage = null
                conversations = demoEngine.conversations(language)
            }
            return
        }
        onChatDraftChanged(false)
        viewModelScope.launch {
            runCatching {
                if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                    val peer = conversation.peerGlobalId ?: error("Direct chat peer is missing")
                    val peerKey = chatRepository.peerDeviceKeys(peer, sessionAccessToken).firstOrNull()
                        ?: error("Peer E2EE key is unavailable")
                    // Edit is a new chronological encrypted event, not in-place ciphertext replacement.
                    val encrypted = privateChatCrypto.encrypt(conversation.id, peerKey, text, emptyList())
                    chatRepository.editDirect(message.id, encrypted, sessionAccessToken)
                } else {
                    chatRepository.editGroup(message.id, text, sessionAccessToken)
                }
                editingMessage = null
                refreshActiveChat()
                refreshConversations()
            }.onFailure { uiMessage = language.pick("Не удалось отредактировать сообщение", "Не вдалося відредагувати повідомлення", "Could not edit the message") }
        }
    }

    fun toggleReaction(message: ChatMessage, emoji: String) {
        if (sessionAccessToken.isBlank()) {
            val conversation = activeConversation
            if (BuildConfig.DEBUG && conversation != null) {
                chatMessages = demoEngine.toggleReaction(conversation.id, message.id, emoji, language)
            }
            return
        }
        viewModelScope.launch {
            runCatching { chatRepository.toggleReaction(message.id, emoji, sessionAccessToken) }
                .onSuccess { refreshActiveChat() }
                .onFailure { uiMessage = language.pick("Не удалось поставить реакцию", "Не вдалося додати реакцію", "Could not add the reaction") }
        }
    }

    fun deleteMessage(message: ChatMessage) {
        if (message.senderGlobalId != profile.globalId) return
        if (sessionAccessToken.isBlank()) {
            val conversation = activeConversation
            if (BuildConfig.DEBUG && conversation != null) {
                chatMessages = demoEngine.deleteMessage(conversation.id, message.id, language)
                if (replyToMessage?.id == message.id) replyToMessage = null
                if (editingMessage?.id == message.id) editingMessage = null
                conversations = demoEngine.conversations(language)
            }
            return
        }
        viewModelScope.launch {
            runCatching { chatRepository.deleteMessage(message.id, sessionAccessToken) }
                .onSuccess {
                    if (replyToMessage?.id == message.id) replyToMessage = null
                    if (editingMessage?.id == message.id) editingMessage = null
                    refreshActiveChat()
                    refreshConversations()
                }
                .onFailure { uiMessage = language.pick("Не удалось удалить сообщение", "Не вдалося видалити повідомлення", "Could not delete the message") }
        }
    }

    fun toggleActivePeerBlock() {
        val peer = activeConversation?.peerGlobalId ?: return
        val target = !activePeerBlockedByMe
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                activePeerBlockedByMe = demoEngine.setPeerBlocked(peer, target)
                uiMessage = if (activePeerBlockedByMe) language.pick("Пользователь заблокирован в demo-режиме.", "Користувача заблоковано в demo-режимі.", "User blocked in demo mode.") else language.pick("Пользователь разблокирован.", "Користувача розблоковано.", "User unblocked.")
            }
            return
        }
        viewModelScope.launch {
            runCatching { chatRepository.setPeerBlocked(peer, target, sessionAccessToken) }
                .onSuccess { blocked ->
                    activePeerBlockedByMe = blocked
                    uiMessage = if (blocked) language.pick(
                        "Пользователь заблокирован. Новые личные сообщения между вами запрещены.",
                        "Користувача заблоковано. Нові особисті повідомлення між вами заборонені.",
                        "User blocked. New direct messages between you are disabled.",
                    ) else language.pick("Пользователь разблокирован.", "Користувача розблоковано.", "User unblocked.")
                    refreshConversations()
                }
                .onFailure { uiMessage = language.pick("Не удалось изменить блокировку", "Не вдалося змінити блокування", "Could not change the block status") }
        }
    }

    fun reportActivePeer(description: String) {
        val peer = activeConversation?.peerGlobalId ?: return
        if (description.trim().length < 20) return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) uiMessage = language.pick("Жалоба сохранена только в demo-симуляции.", "Скаргу збережено лише в demo-симуляції.", "Report stored only in demo simulation.")
            return
        }
        viewModelScope.launch {
            runCatching { chatRepository.reportPeer(profile.globalId, peer, description.trim(), sessionAccessToken) }
                .onSuccess {
                    uiMessage = language.pick(
                        "Жалоба отправлена в закрытую модерацию. До решения она не снижает публичный рейтинг.",
                        "Скаргу передано на закриту модерацію. До рішення вона не знижує публічний рейтинг.",
                        "Report submitted for private moderation. It does not reduce the public score before a decision.",
                    )
                }
                .onFailure { uiMessage = language.pick("Не удалось отправить жалобу", "Не вдалося надіслати скаргу", "Could not send report") }
        }
    }

    fun checkForUpdates() {
        viewModelScope.launch {
            appUpdateInfo = runCatching { chatRepository.updateInfo("") }.getOrNull()
        }
    }

    fun changeLanguage(value: AppLanguage) {
        if (language.tag.equals(value.tag, ignoreCase = true)) return
        language = value
        settingsStore.setLanguage(value)
        syncUserSettings()
        // Server-rendered positive quality labels are locale-specific; reload them immediately.
        if (route != AppRoute.AUTH) refreshRemoteData()
    }

    fun setTheme(value: AppThemeMode) {
        themeMode = value
        settingsStore.setTheme(value)
        syncUserSettings()
    }

    fun joinCalibrationPilot(inviteCode: String, eligibilityAck: Boolean) {
        if (calibrationPilotBusy) return
        val info = calibrationPilotInfo
        if (!eligibilityAck) {
            uiMessage = language.pick(
                "Подтвердите условия controlled pilot",
                "Підтвердьте умови controlled pilot",
                "Acknowledge the controlled-pilot conditions",
            )
            return
        }
        if (info?.inviteRequired == true && inviteCode.isBlank()) {
            uiMessage = language.pick(
                "Введите код приглашения пилота",
                "Введіть код запрошення пілоту",
                "Enter the pilot invitation code",
            )
            return
        }
        if (sessionAccessToken.isBlank()) {
            uiMessage = language.pick(
                "Для вступления в пилот требуется подключение к серверу",
                "Для вступу до пілоту потрібне підключення до сервера",
                "Joining the pilot requires a server connection",
            )
            return
        }
        viewModelScope.launch {
            calibrationPilotBusy = true
            runCatching {
                remoteRepository.joinCalibrationPilot(profile.globalId, language.tag, inviteCode, sessionAccessToken)
            }.onSuccess { accepted ->
                if (accepted) {
                    calibrationOptIn = true
                    settingsStore.setCalibrationOptIn(true)
                    remoteStatus = "calibration_pilot_joined"
                    uiMessage = language.pick(
                        "Участие в закрытом пилоте включено",
                        "Участь у закритому пілоті увімкнено",
                        "Controlled-pilot participation enabled",
                    )
                }
            }.onFailure { error ->
                val raw = error.message.orEmpty()
                uiMessage = when {
                    "invalid_invite" in raw -> language.pick("Код приглашения недействителен", "Код запрошення недійсний", "Invitation code is invalid")
                    "pilot_full" in raw -> language.pick("Набор в пилот завершён", "Набір до пілоту завершено", "The pilot cohort is full")
                    "locale_quota_full" in raw -> language.pick("Квота для выбранного языка заполнена", "Квоту для вибраної мови заповнено", "The quota for this language is full")
                    "pilot_disabled" in raw -> language.pick("Пилот сейчас закрыт", "Пілот зараз закрито", "The pilot is currently disabled")
                    else -> language.pick("Не удалось вступить в пилот", "Не вдалося вступити до пілоту", "Could not join the pilot")
                }
            }
            calibrationPilotInfo = runCatching { remoteRepository.calibrationPilotStatus(sessionAccessToken) }.getOrNull() ?: calibrationPilotInfo
            calibrationPilotBusy = false
        }
    }

    fun leaveCalibrationPilot() {
        if (calibrationPilotBusy) return
        calibrationOptIn = false
        settingsStore.setCalibrationOptIn(false)
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            calibrationPilotBusy = true
            val sent = runCatching {
                remoteRepository.leaveCalibrationPilot(profile.globalId, language.tag, sessionAccessToken)
            }.getOrDefault(false)
            remoteStatus = if (sent) "calibration_pilot_left" else "calibration_withdrawal_queued"
            uiMessage = language.pick(
                "Участие прекращено; сырые калибровочные данные будут удалены",
                "Участь припинено; сирі калібрувальні дані буде видалено",
                "Participation ended; raw calibration data will be deleted",
            )
            calibrationPilotInfo = runCatching { remoteRepository.calibrationPilotStatus(sessionAccessToken) }.getOrNull() ?: calibrationPilotInfo
            calibrationPilotBusy = false
        }
    }

    fun updateProfile(
        name: String,
        description: String,
        city: String,
        birthDate: LocalDate,
        latinName: String,
        goals: List<String>,
        interests: List<String>,
        values: List<String>,
        lifestyle: List<String>
    ) {
        val normalizedLatinName = latinName.trim().uppercase().ifBlank { profile.latinName }
        profile = profile.copy(
            name = name.trim().ifBlank { profile.name },
            age = Period.between(birthDate, LocalDate.now()).years.coerceAtLeast(18),
            description = description.trim(),
            city = city.trim().ifBlank { profile.city },
            birthDate = birthDate,
            latinName = normalizedLatinName,
            goals = goals.filter(String::isNotBlank).map(String::trim).distinct(),
            interests = interests.filter(String::isNotBlank).map(String::trim).distinct(),
            values = values.filter(String::isNotBlank).map(String::trim).distinct(),
            lifestyle = lifestyle.filter(String::isNotBlank).map(String::trim).distinct(),
            completedProfileSections = 10,
            zodiac = ZodiacEngine.sign(birthDate),
            numerology = VedicNumerologyEngine.calculate(birthDate, normalizedLatinName)
        )
        selectedCity = profile.city
        profileStore.save(profile)
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val profileSent = runCatching { remoteRepository.syncProfile(profile, language, sessionAccessToken, profileVisibility) }.getOrDefault(false)
                val personalitySent = runCatching { remoteRepository.syncPersonalityProfile(profile, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (profileSent && personalitySent) "profile_synced" else "profile_queued"
            }
        }
    }

    fun importAvatar(uri: Uri) {
        viewModelScope.launch {
            runCatching { avatarStore.import(uri, profile.globalId) }
                .onSuccess { path ->
                    profile = profile.copy(avatarLocalPath = path)
                    profileStore.save(profile)
                    val bytes = avatarStore.bytes(path)
                    if (bytes != null && sessionAccessToken.isNotBlank()) {
                        val synced = runCatching { remoteRepository.syncAvatar(profile.globalId, bytes, sessionAccessToken) }.getOrDefault(false)
                        remoteStatus = if (synced) "avatar_synced" else "avatar_queued"
                    }
                    uiMessage = language.pick("Аватар сохранён", "Аватар збережено", "Avatar saved")
                }
                .onFailure { uiMessage = it.message ?: language.pick("Не удалось загрузить аватар", "Не вдалося завантажити аватар", "Could not load avatar") }
        }
    }

    fun refreshRemoteData() {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            remoteLoading = true
            runCatching { remoteRepository.flushPending(sessionAccessToken) }
            val peopleResult = runCatching { remoteRepository.people(selectedCity, radiusKm, profile.globalId, sessionAccessToken, searchIntent, language, hospitalityOnly = hospitalityOnly) }
            val communityResult = runCatching { remoteRepository.communities(selectedCity, communityKind, sessionAccessToken, language) }
            val pilotResult = runCatching { remoteRepository.calibrationPilotStatus(sessionAccessToken) }
            val consentResult = runCatching { remoteRepository.calibrationConsent(profile.globalId, sessionAccessToken) }
            peopleResult.getOrNull()?.let { remotePeople = it }
            communityResult.getOrNull()?.let { remoteCommunities = it }
            pilotResult.getOrNull()?.let { calibrationPilotInfo = it }
            consentResult.getOrNull()?.let { active ->
                calibrationOptIn = active
                settingsStore.setCalibrationOptIn(active)
            }
            remoteStatus = when {
                peopleResult.isSuccess || communityResult.isSuccess -> "online_or_cached"
                BuildConfig.DEBUG -> "debug_demo_fallback"
                else -> "offline_no_cache"
            }
            remoteLoading = false
        }
    }

    fun refreshHospitalityHome() {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                hospitalityBusy = false
                hospitalityHostProfile = demoEngine.hospitalityHostProfile()
                hospitalityRequests = demoEngine.hospitalityRequests()
                hospitalityReputation = demoEngine.hospitalityReputation(profile.globalId)
                hospitalitySecureStore.purgeExpired()
            }
            return
        }
        viewModelScope.launch {
            hospitalityBusy = true
            hospitalityHostProfile = runCatching { hospitalityRepository.myHostProfile(sessionAccessToken) }.getOrNull()
            hospitalityRequests = runCatching { hospitalityRepository.requests(token = sessionAccessToken) }.getOrDefault(emptyList())
            hospitalityReputation = runCatching { hospitalityRepository.reputation(profile.globalId, sessionAccessToken) }.getOrNull()
            hospitalitySecureStore.purgeExpired()
            hospitalityBusy = false
        }
    }

    fun refreshHospitalityHostProfile() {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) hospitalityHostProfile = demoEngine.hospitalityHostProfile()
            return
        }
        viewModelScope.launch { hospitalityHostProfile = runCatching { hospitalityRepository.myHostProfile(sessionAccessToken) }.getOrNull() }
    }

    fun saveHospitalityHostProfile(
        active: Boolean,
        publicArea: String,
        exactAddress: String,
        arrivalInstructions: String,
        arrivalContact: String,
        sleepingCondition: HospitalitySleepingCondition,
        maxGuests: Int,
        maxDays: Int,
        minRating: Double,
        requiredTests: List<String>,
        rules: List<String>,
        availabilityMode: HospitalityAvailabilityMode,
    ) {
        val current = hospitalityHostProfile
        val payload = HospitalityHostProfile(
            hostGlobalId = current?.hostGlobalId,
            isHostingActive = active,
            maxGuests = maxGuests.coerceAtLeast(1),
            maxDays = maxDays.coerceAtLeast(1),
            cityId = current?.cityId.orEmpty(),
            cityValue = selectedCity,
            publicAreaText = publicArea.trim().ifBlank { null },
            timezoneName = java.util.TimeZone.getDefault().id,
            sleepingCondition = sleepingCondition,
            houseRules = rules.map(String::trim).filter(String::isNotBlank).distinct().take(40),
            minRequiredRating = minRating.coerceIn(0.0, 100.0),
            requiredCompletedTests = requiredTests.distinct(),
            availabilityMode = availabilityMode,
            privateLocation = HospitalityPrivateLocation(
                exactAddress = exactAddress.trim(), arrivalInstructions = arrivalInstructions.trim(), arrivalContact = arrivalContact.trim(),
            ),
        )
        if (active && payload.privateLocation?.exactAddress.isNullOrBlank()) {
            uiMessage = language.pick("Для включения приема гостей укажите точный адрес", "Для ввімкнення прийому гостей вкажіть точну адресу", "Enter the exact address before enabling hosting")
            return
        }
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                hospitalityHostProfile = demoEngine.saveHospitalityHostProfile(payload)
                uiMessage = language.pick("Настройки гостеприимства сохранены в demo", "Налаштування гостинності збережено в demo", "Hospitality settings saved in demo")
            }
            return
        }
        viewModelScope.launch {
            hospitalityBusy = true
            runCatching { hospitalityRepository.saveHostProfile(payload, sessionAccessToken) }
                .onSuccess { hospitalityHostProfile = it; uiMessage = language.pick("Настройки гостеприимства сохранены", "Налаштування гостинності збережено", "Hospitality settings saved") }
                .onFailure { uiMessage = it.message ?: language.pick("Не удалось сохранить", "Не вдалося зберегти", "Could not save") }
            hospitalityBusy = false
        }
    }

    fun refreshHospitalityAvailability() {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) hospitalityAvailability = demoEngine.hospitalityAvailability()
            return
        }
        viewModelScope.launch { hospitalityAvailability = runCatching { hospitalityRepository.availability(sessionAccessToken) }.getOrDefault(emptyList()) }
    }

    fun addHospitalityAvailability(dateFrom: String, dateTo: String, available: Boolean, capacity: Int?) {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                demoEngine.saveHospitalityAvailability(dateFrom, dateTo, available, capacity)
                hospitalityAvailability = demoEngine.hospitalityAvailability()
            }
            return
        }
        viewModelScope.launch {
            runCatching { hospitalityRepository.saveAvailability(
                dateFrom, dateTo,
                if (available) HospitalityAvailabilityState.AVAILABLE else HospitalityAvailabilityState.UNAVAILABLE,
                capacity, sessionAccessToken,
            ) }.onSuccess { refreshHospitalityAvailability() }.onFailure { uiMessage = it.message }
        }
    }

    fun deleteHospitalityAvailability(id: String) {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                demoEngine.deleteHospitalityAvailability(id)
                hospitalityAvailability = demoEngine.hospitalityAvailability()
            }
            return
        }
        viewModelScope.launch { runCatching { hospitalityRepository.deleteAvailability(id, sessionAccessToken) }.onSuccess { refreshHospitalityAvailability() } }
    }

    fun refreshHospitalityRequests() {
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) hospitalityRequests = demoEngine.hospitalityRequests()
            return
        }
        viewModelScope.launch { hospitalityRequests = runCatching { hospitalityRepository.requests(token = sessionAccessToken) }.getOrDefault(emptyList()) }
    }

    fun evaluateCandidateHospitality(checkIn: String, checkOut: String, guests: Int) {
        val candidate = selectedCandidate ?: return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) hospitalityEligibility = demoEngine.hospitalityEligibility(candidate.globalId, checkIn, checkOut, guests)
            return
        }
        viewModelScope.launch {
            hospitalityEligibility = runCatching { hospitalityRepository.eligibility(candidate.globalId, checkIn, checkOut, guests, sessionAccessToken) }
                .onFailure { uiMessage = it.message }.getOrNull()
        }
    }

    fun createHospitalityRequest(checkIn: String, checkOut: String, guests: Int, message: String) {
        val candidate = selectedCandidate ?: return
        if (hospitalityEligibility?.eligible != true) {
            uiMessage = language.pick("Сначала проверьте условия хоста", "Спочатку перевірте умови хоста", "Check host eligibility first")
            return
        }
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                runCatching { demoEngine.createHospitalityRequest(candidate.globalId, checkIn, checkOut, guests) }
                    .onSuccess { request ->
                        selectedStayRequest = request
                        hospitalityRequests = demoEngine.hospitalityRequests()
                        val conversation = demoEngine.openDirect(candidate, language)
                        activeConversation = conversation
                        if (message.isNotBlank()) chatMessages = demoEngine.sendMessage(conversation, profile.globalId, message, language)
                        hospitalityEvents = demoEngine.hospitalityEvents(conversation.id)
                        openHospitalityRequest(request)
                    }
                    .onFailure { uiMessage = it.message }
            }
            return
        }
        viewModelScope.launch {
            hospitalityBusy = true
            runCatching { hospitalityRepository.createRequest(candidate.globalId, checkIn, checkOut, guests, sessionAccessToken) }
                .onSuccess { request ->
                    selectedStayRequest = request
                    hospitalityRequests = (hospitalityRequests + request).distinctBy { it.requestId }
                    // Request text stays in the existing E2EE direct chat rather than StayRequest storage.
                    runCatching {
                        val conversation = chatRepository.openDirect(candidate.globalId, sessionAccessToken)
                        activeConversation = conversation
                        if (message.isNotBlank() && conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                            val peerKey = chatRepository.peerDeviceKeys(candidate.globalId, sessionAccessToken).firstOrNull()
                            if (peerKey != null) {
                                val encrypted = privateChatCrypto.encrypt(conversation.id, peerKey, message, emptyList())
                                chatRepository.sendDirect(
                                    conversation.id,
                                    "hospitality-${request.requestId}",
                                    encrypted,
                                    sessionAccessToken,
                                )
                            }
                        }
                    }
                    uiMessage = language.pick("Запрос на проживание отправлен", "Запит на проживання надіслано", "Stay request sent")
                    openHospitalityRequest(request)
                }.onFailure { uiMessage = it.message ?: language.pick("Не удалось отправить запрос", "Не вдалося надіслати запит", "Could not send request") }
            hospitalityBusy = false
        }
    }

    fun openHospitalityRequest(request: StayRequest) {
        selectedStayRequest = request
        hospitalityVerification = null
        hospitalityReviewState = null
        hospitalityArrivalDetails = if (request.status == StayRequestStatus.ACCEPTED) hospitalitySecureStore.get(request.requestId) else null
        navigateTo(AppRoute.HOSPITALITY_REQUEST_DETAIL)
        if (sessionAccessToken.isNotBlank()) viewModelScope.launch {
            selectedStayRequest = runCatching { hospitalityRepository.request(request.requestId, sessionAccessToken) }.getOrDefault(request)
            if (selectedStayRequest?.status == StayRequestStatus.COMPLETED) {
                hospitalityVerification = runCatching { hospitalityRepository.verification(request.requestId, sessionAccessToken) }.getOrNull()
                hospitalityReviewState = runCatching { hospitalityRepository.reviewState(request.requestId, sessionAccessToken) }.getOrNull()
            }
        } else if (BuildConfig.DEBUG) {
            selectedStayRequest = demoEngine.hospitalityRequest(request.requestId) ?: request
            if (selectedStayRequest?.status == StayRequestStatus.COMPLETED) {
                hospitalityVerification = demoEngine.hospitalityVerification(request.requestId)
                hospitalityReviewState = demoEngine.hospitalityReviewState(request.requestId)
            }
        }
    }

    fun actOnHospitalityRequest(action: String) {
        val request = selectedStayRequest ?: return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                demoEngine.actOnHospitalityRequest(request.requestId, action)?.let { updated ->
                    selectedStayRequest = updated
                    hospitalityRequests = demoEngine.hospitalityRequests()
                    if (updated.status == StayRequestStatus.ACCEPTED) loadHospitalityArrivalDetails()
                }
            }
            return
        }
        viewModelScope.launch {
            runCatching { hospitalityRepository.act(request.requestId, action, request.version, null, sessionAccessToken) }
                .onSuccess { updated ->
                    selectedStayRequest = updated
                    hospitalityRequests = hospitalityRequests.map { if (it.requestId == updated.requestId) updated else it }
                    if (updated.status == StayRequestStatus.ACCEPTED) loadHospitalityArrivalDetails()
                }.onFailure { uiMessage = it.message }
        }
    }

    fun loadHospitalityArrivalDetails() {
        val request = selectedStayRequest ?: return
        if (request.status != StayRequestStatus.ACCEPTED) return
        hospitalitySecureStore.get(request.requestId)?.let { hospitalityArrivalDetails = it; return }
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) demoEngine.hospitalityArrivalDetails(request.requestId)?.let { details ->
                hospitalitySecureStore.put(details)
                hospitalityArrivalDetails = details
            }
            return
        }
        viewModelScope.launch {
            runCatching { hospitalityRepository.arrivalDetails(request.requestId, sessionAccessToken) }
                .onSuccess { details -> hospitalitySecureStore.put(details); hospitalityArrivalDetails = details }
                .onFailure { uiMessage = it.message }
        }
    }

    fun openHospitalityMap() {
        val details = hospitalityArrivalDetails ?: return
        val uri = when {
            details.exactLat != null && details.exactLon != null -> Uri.parse("geo:${details.exactLat},${details.exactLon}?q=${details.exactLat},${details.exactLon}")
            details.exactAddress.isNotBlank() -> Uri.parse("geo:0,0?q=${Uri.encode(details.exactAddress)}")
            else -> return
        }
        getApplication<Application>().startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openPublicHospitalityMap() {
        val area = candidateHospitality?.host?.publicAreaText ?: selectedCandidate?.city ?: return
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(area)}")
        getApplication<Application>().startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun confirmHospitalityStay(value: StayConfirmationValue) {
        val request = selectedStayRequest ?: return
        if (request.status != StayRequestStatus.COMPLETED) return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                hospitalityVerification = demoEngine.confirmHospitalityStay(request.requestId, value)
                hospitalityReputation = demoEngine.hospitalityReputation(profile.globalId)
            }
            return
        }
        viewModelScope.launch {
            hospitalityVerification = runCatching { hospitalityRepository.confirm(request.requestId, value, sessionAccessToken) }
                .onFailure { uiMessage = it.message }.getOrNull()
            hospitalityReputation = runCatching { hospitalityRepository.reputation(profile.globalId, sessionAccessToken) }.getOrNull()
        }
    }

    fun submitHospitalityReview(adequacy: Int, rules: Int, accuracy: Int, publicText: String?, privateFeedback: String?) {
        val request = selectedStayRequest ?: return
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                hospitalityReviewState = demoEngine.submitHospitalityReview(request.requestId)
                hospitalityReputation = demoEngine.hospitalityReputation(profile.globalId)
            }
            return
        }
        viewModelScope.launch {
            hospitalityReviewState = runCatching { hospitalityRepository.submitReview(
                request.requestId, adequacy, rules, accuracy, publicText, privateFeedback, sessionAccessToken,
            ) }.onFailure { uiMessage = it.message }.getOrNull()
            hospitalityReputation = runCatching { hospitalityRepository.reputation(profile.globalId, sessionAccessToken) }.getOrNull()
        }
    }

    fun openHospitalityReview() { if (selectedStayRequest != null) navigateTo(AppRoute.HOSPITALITY_REVIEW) }
    fun openHospitalityStayDetails() { loadHospitalityArrivalDetails(); navigateTo(AppRoute.HOSPITALITY_STAY_DETAILS) }

    fun handleHospitalityPush(eventType: String?, requestId: String?) {
        if (eventType.isNullOrBlank()) return
        if (requestId.isNullOrBlank()) { openHospitalityHome(); return }
        if (sessionAccessToken.isBlank()) {
            if (BuildConfig.DEBUG) demoEngine.hospitalityRequest(requestId)?.let(::openHospitalityRequest) ?: openHospitalityHome()
            else openHospitalityHome()
            return
        }
        viewModelScope.launch {
            runCatching { hospitalityRepository.request(requestId, sessionAccessToken) }
                .onSuccess(::openHospitalityRequest)
                .onFailure { openHospitalityHome() }
        }
    }

    fun startCoreAssessment(module: String) {
        require(module == "p32" || module == "enneagram")
        activeCoreModule = module
        coreQuestionOrder = rawCoreQuestions.shuffled().map(CoreProfileQuestion::id)
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun selectCoreAnswer(value: Int) {
        require(value in 1..4)
        val question = currentCoreQuestion ?: return
        coreAnswers = coreAnswers + (question.id to value)
    }

    fun previousCoreQuestion() { if (coreQuestionIndex > 0) coreQuestionIndex -= 1 }

    fun nextCoreQuestion() {
        val question = currentCoreQuestion ?: return
        if (coreAnswers[question.id] !in 1..4) return
        if (coreQuestionIndex < coreQuestions.lastIndex) coreQuestionIndex += 1
    }

    fun finishCoreAssessment() {
        if (!canFinishCoreAssessment) return
        profile = when (activeCoreModule) {
            "p32" -> profile.copy(personality32 = CoreProfileCatalog.scorePersonality32(coreAnswers))
            "enneagram" -> profile.copy(enneagram = CoreProfileCatalog.scoreEnneagram(coreAnswers))
            else -> profile
        }
        profileStore.save(profile)
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val sent = runCatching { remoteRepository.syncPersonalityProfile(profile, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (sent) "personality_synced" else "personality_queued"
            }
        }
        activeCoreModule = null
        coreQuestionOrder = emptyList()
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun closeCoreAssessment() {
        activeCoreModule = null
        coreQuestionOrder = emptyList()
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun startAssessment(id: String) {
        val definition = requireNotNull(AssessmentCatalog.byId(id)) { "Неизвестный тест: $id" }
        val previousResult = completedResults[id]
        if (previousResult != null && !AssessmentProductEngine.canRetake(previousResult)) {
            uiMessage = language.pick(
                "Повторное прохождение доступно через месяц после предыдущего результата.",
                "Повторне проходження доступне через місяць після попереднього результату.",
                "Retake is available one month after the previous result.",
            )
            return
        }
        activeAssessmentId = id
        assessmentQuestionOrder = definition.questions.shuffled().map(AssessmentQuestion::id)
        currentQuestionIndex = 0
        assessmentAnswers = emptyMap()
        assessmentResponseLatencyMs = emptyMap()
        assessmentAnswerChanges = emptyMap()
        assessmentStartedAtEpochMs = System.currentTimeMillis()
        assessmentQuestionShownAtEpochMs = assessmentStartedAtEpochMs
        currentResult = null
        currentPositiveReveal = null
    }

    fun selectAssessmentAnswer(value: Int) {
        require(value in 1..4)
        val question = currentQuestion ?: return
        val previous = assessmentAnswers[question.id]
        if (previous == null) {
            assessmentResponseLatencyMs = assessmentResponseLatencyMs +
                (question.id to (System.currentTimeMillis() - assessmentQuestionShownAtEpochMs).coerceAtLeast(0L))
        } else if (previous != value) {
            assessmentAnswerChanges = assessmentAnswerChanges +
                (question.id to ((assessmentAnswerChanges[question.id] ?: 0) + 1))
        }
        assessmentAnswers = assessmentAnswers + (question.id to value)
    }

    fun previousAssessmentQuestion() {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex -= 1
            assessmentQuestionShownAtEpochMs = System.currentTimeMillis()
        }
    }

    fun nextAssessmentQuestion() {
        val definition = activeAssessment ?: return
        val question = currentQuestion ?: return
        if (assessmentAnswers[question.id] !in 1..4) return
        if (currentQuestionIndex < definition.questions.lastIndex) {
            currentQuestionIndex += 1
            assessmentQuestionShownAtEpochMs = System.currentTimeMillis()
        }
    }

    fun finishAssessment() {
        val definition = activeAssessment ?: return
        if (!canFinishAssessment) return
        val wasCompleted = completedResults.containsKey(definition.id)
        val beforeProfile = LatentProfileEngine.build(completedResults.values)
        val questionPositions = assessmentQuestionOrder.mapIndexed { index, id -> id to (index + 1) }.toMap()
        val result = AssessmentScorer.score(
            definition = definition,
            answers = assessmentAnswers,
            responseLatencyMs = assessmentResponseLatencyMs,
            selectionChanges = assessmentAnswerChanges,
            questionPositions = questionPositions,
            startedAtEpochMs = assessmentStartedAtEpochMs,
        )
        assessmentStore.save(result)
        completedResults = completedResults + (definition.id to result)
        currentResult = result
        val afterProfile = LatentProfileEngine.build(completedResults.values)
        currentPositiveReveal = PositiveProfileProjector.reveal(
            assessmentId = definition.id,
            before = beforeProfile,
            after = afterProfile,
            language = language,
            completedTests = completedResults.size,
            isRetake = wasCompleted,
        )
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val sent = runCatching { remoteRepository.syncAssessmentResult(profile.globalId, result, sessionAccessToken, language.tag, calibrationOptIn) }.getOrDefault(false)
                remoteStatus = if (sent) "assessment_synced" else "assessment_queued"
                if (sent) refreshRemoteData()
            }
        }
    }

    fun closeAssessment() {
        activeAssessmentId = null
        currentQuestionIndex = 0
        assessmentQuestionOrder = emptyList()
        assessmentAnswers = emptyMap()
        assessmentResponseLatencyMs = emptyMap()
        assessmentAnswerChanges = emptyMap()
        assessmentStartedAtEpochMs = 0L
        assessmentQuestionShownAtEpochMs = 0L
        currentResult = null
        currentPositiveReveal = null
    }

    fun continueWithNextAssessment() {
        closeAssessment()
        nextRecommendedAssessment?.let { startAssessment(it.id) }
    }

    fun openProfileFromAssessment() {
        closeAssessment()
        selectTab(MainTab.PROFILE)
    }

    fun assessmentProgress(definition: AssessmentDefinition): Int {
        if (completedResults.containsKey(definition.id)) return 100
        if (activeAssessmentId != definition.id || definition.questions.isEmpty()) return 0
        return (assessmentAnswers.size * 100 / definition.questions.size).coerceIn(0, 100)
    }

    private fun overlap(first: List<String>, second: List<String>): Int {
        val a = first.map(String::lowercase).toSet()
        val b = second.map(String::lowercase).toSet()
        return a.intersect(b).size * 100 / (a + b).size.coerceAtLeast(1)
    }

    private fun demoCandidateScore(seed: Int, id: String): Int {
        val hash = id.fold(seed * 31) { acc, char -> acc * 33 + char.code }
        return 45 + abs(hash % 51)
    }

    override fun onCleared() {
        assessmentStore.close()
        remoteRepository.close()
        super.onCleared()
    }
}
