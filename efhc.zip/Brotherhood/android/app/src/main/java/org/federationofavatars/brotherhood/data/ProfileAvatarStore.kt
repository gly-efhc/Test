package org.federationofavatars.brotherhood.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.federationofavatars.brotherhood.model.GlobalId

/**
 * Imports a user-selected image into app-private storage. No broad media/storage permission is needed.
 * Images are bounded before persistence and backend synchronization.
 */
class ProfileAvatarStore(context: Context) {
    private val appContext = context.applicationContext
    private val directory = File(appContext.filesDir, "profile-avatar").apply { mkdirs() }

    suspend fun import(uri: Uri, globalId: GlobalId): String = withContext(Dispatchers.IO) {
        val original = appContext.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream)
            ?: error("Не удалось прочитать выбранное изображение")
        val maxSide = maxOf(original.width, original.height).coerceAtLeast(1)
        val scale = minOf(1.0, 768.0 / maxSide.toDouble())
        val width = (original.width * scale).toInt().coerceAtLeast(1)
        val height = (original.height * scale).toInt().coerceAtLeast(1)
        val bitmap = if (width == original.width && height == original.height) original
        else Bitmap.createScaledBitmap(original, width, height, true).also { if (it !== original) original.recycle() }

        val encoded = encodeBoundedJpeg(bitmap)
        bitmap.recycle()
        val target = File(directory, "avatar-${globalId.display}.jpg")
        val temporary = File(directory, "${target.name}.tmp")
        temporary.writeBytes(encoded)
        check(temporary.length() in 1..MAX_AVATAR_BYTES.toLong()) { "Аватар превышает допустимый размер" }
        if (target.exists() && !target.delete()) error("Не удалось заменить предыдущий аватар")
        check(temporary.renameTo(target)) { "Не удалось сохранить аватар" }
        target.absolutePath
    }

    fun bytes(path: String?): ByteArray? {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.isFile || file.parentFile?.canonicalFile != directory.canonicalFile) return null
        return file.readBytes().takeIf { it.size in 1..MAX_AVATAR_BYTES }
    }

    private fun encodeBoundedJpeg(bitmap: Bitmap): ByteArray {
        for (quality in listOf(90, 84, 76, 68, 60)) {
            val out = ByteArrayOutputStream()
            if (bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)) {
                val bytes = out.toByteArray()
                if (bytes.size <= MAX_AVATAR_BYTES) return bytes
            }
        }
        error("Изображение не удалось безопасно уменьшить до 512 КиБ")
    }

    companion object {
        const val MAX_AVATAR_BYTES = 512_000
    }
}
