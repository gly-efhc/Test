package org.federationofavatars.brotherhood.model

object AssessmentModelVersions {
    const val SCIENTIFIC_QUESTIONNAIRE_V1 = "scientific-questionnaire-v1"
    const val ACTIVE = SCIENTIFIC_QUESTIONNAIRE_V1
}

enum class AssessmentKind(val title: String) {
    TRAITS_CORE("Черты и саморегуляция"),
    INTERPERSONAL_STYLE("Межличностный стиль"),
    COMMUNICATION_CONFLICT("Коммуникация и конфликт"),
    TRUST_SUPPORT_BOUNDARIES("Доверие, поддержка и границы"),
    DECISION_WORK_STYLE("Решения, риск и рабочий стиль"),
    SOCIAL_GROUP_ROLE("Социальная энергия и роль в группе"),
    ADAPTABILITY_UNCERTAINTY("Адаптивность и неопределённость")
}


/** Retained for wire/backward compatibility. Active scientific questionnaire systems use SIMILARITY semantics. */
enum class CompatibilityMode { SIMILARITY, HIGH_IS_GOOD }


enum class VisualSceneArchetype {
    TEAM_TABLE,
    CROSSROADS,
    BRIDGE,
    RESOURCE_SPLIT,
    QUEUE,
    WORKSPACE,
    CRISIS_ROOM,
    CAMP,
    CIRCLE,
    TWO_GROUPS,
    OPEN_DOOR,
    CLOSED_DOOR,
    PATHS,
    NETWORK_HUB,
    HANDOFF,
    SHARED_TASK,
    OBSERVER,
    FRONT_LINE,
    BACK_STAGE,
    EMPTY_SEAT,
    RULE_BOARD,
    CLOCKWORK,
    TOOLBOX,
    UNKNOWN_TERRAIN,
    PAIR_WALK,
    MEETING_POINT,
    SHARED_SHELTER,
    MAP_ROOM,
    WORKBENCH,
    TOWER,
    GATE,
    DETOUR,
    RIVER_CROSSING,
    SIGNAL_POINT,
    MARKET_STALL,
    NEGOTIATION_TABLE,
    CHECKPOINT,
    STAIRCASE,
    SPLIT_PATH,
    COMMON_GROUND,
    ROTATING_LEAD,
    SUPPLY_LINE,
    QUIET_ROOM,
    PUBLIC_SQUARE,
    DEADLINE_BOARD,
    NEW_PROJECT,
    REVIEW_CIRCLE,
    PARALLEL_TASKS,
}

enum class VisualParadigm {
    GROUP_DISTANCE,
    NETWORK,
    PATH,
    BALANCE,
    RHYTHM,
    STRUCTURE,
    BOUNDARY,
    RESOURCE,
    CHANGE,
    FOCUS,
    DIRECTION,
    AMBIGUITY,
    CLUSTER,
    EXCHANGE,
    PRIORITY,
    FLOW,
}

data class VisualChoiceLayout(
    val intensity: Int,
    val spacing: Int,
    val order: Int,
    val asymmetry: Int,
    val direction: Int,
) {
    init {
        require(intensity in 0..3)
        require(spacing in 0..3)
        require(order in 0..3)
        require(asymmetry in 0..3)
        require(direction in 0..3)
    }
}

data class VisualAssessmentChoice(
    val id: String,
    val label: String = "",
    val layout: VisualChoiceLayout,
    /** Sparse hidden loadings. Never render or expose these values in the user UI/API. */
    val latentLoadings: Map<String, Int>,
) {
    init { require(latentLoadings.values.all { it in -2..2 }) }
}

data class AssessmentQuestion(
    val id: String,
    val prompt: String = "",
    val paradigm: VisualParadigm,
    val sceneArchetype: VisualSceneArchetype,
    val stimulusVersion: String,
    val visualSeed: Int,
    /** Non-scoring deterministic scene composition recipe, 0..7. */
    val compositionVariant: Int,
    val choices: List<VisualAssessmentChoice>,
) {
    init {
        require(compositionVariant in 0..7)
        require(choices.size == 4)
    }
}

data class AssessmentDefinition(
    val id: String,
    /** Internal construct title. UI must not display it before or after completion. */
    val title: String,
    val subtitle: String,
    val description: String,
    val estimatedMinutes: Int,
    val kind: AssessmentKind,
    val required: Boolean,
    val compatibilityMode: CompatibilityMode = CompatibilityMode.SIMILARITY,
    /** Deprecated moral-risk marker. Must remain false in visual assessment v2. */
    val safetyCritical: Boolean = false,
    val accountWeightPercent: Double = 0.5,
    val dimensionTitles: Map<String, String>,
    val questions: List<AssessmentQuestion>
)

data class DimensionScore(
    val id: String,
    val title: String,
    val score: Int
)

data class AssessmentResponseTrace(
    val questionId: String,
    val choiceId: String,
    val paradigm: String,
    val sceneArchetype: String,
    val stimulusVersion: String,
    val visualSeed: Int,
    /** Non-scoring composition recipe used to test visual-form effects. */
    val compositionVariant: Int,
    val intensity: Int,
    val spacing: Int,
    val order: Int,
    val asymmetry: Int,
    val direction: Int,
    /** 1..4 screen position after the deterministic hidden permutation. */
    val presentationSlot: Int,
    /** First-selection latency for this task; calibration-only and never public. */
    val responseLatencyMs: Long,
    /** Number of times the answer was changed before completion. */
    val selectionChanges: Int,
    /** 1..6 position of this task in the randomized series order. */
    val questionPosition: Int,
)

data class AssessmentResult(
    val assessmentId: String,
    /** Assessment/scoring model provenance. Only the ACTIVE visual model may feed latent matching. */
    val modelVersion: String = AssessmentModelVersions.ACTIVE,
    /** Exact stimulus generator version required to reconstruct item-level calibration evidence. */
    val stimulusVersion: String = "text-situational-v1",
    /** When this six-task series was opened; needed only for calibration timing diagnostics. */
    val startedAtEpochMs: Long,
    /** Internal neutral profile coordinate, not a moral quality score. */
    val totalScore: Int,
    /** Legacy field retained for API compatibility. Visual assessment v2 always writes 0. */
    val riskScore: Int,
    /** Positive user-facing label only. */
    val label: String,
    /** Positive user-facing summary only. */
    val summary: String,
    /** Hidden latent dimensions. Do not render directly to users. */
    val dimensions: List<DimensionScore>,
    /** Internal algorithm signal. */
    val answerConsistency: Int,
    /** Internal item-level calibration evidence. Never expose through public profile/person endpoints. */
    val responseTrace: List<AssessmentResponseTrace> = emptyList(),
    /** Legacy field. Visual indirect tasks do not calculate social-desirability score. */
    val idealizedSelfPresentation: Int,
    val completedAtEpochMs: Long = System.currentTimeMillis()
)

data class AccountRatingBreakdown(
    val total: Double,
    val profilePoints: Double,
    val testPoints: Double,
    val completedProfileSections: Int,
    val totalProfileSections: Int,
    val completedTests: Int,
    val totalTests: Int
)

data class FriendshipCompatibilityResult(
    val score: Int,
    val testsScore: Int,
    val commonTests: Int,
    val confidence: Int,
    /** Internal diagnostics only; public UI must not display. */
    val riskFlags: List<String>,
    val explanation: String,
    val categoryScores: Map<String, Int> = emptyMap(),
    val friendshipExpectationsScore: Int = 0
)

data class IntegrityScreeningResult(
    val riskScore: Int,
    val consistencyScore: Int,
    val evaluatedPairs: Int,
    val confidence: Int,
    val label: String,
    val flags: List<String>
)
