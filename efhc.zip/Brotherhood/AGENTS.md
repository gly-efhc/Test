# Brotherhood AI adapter

1. Read `START_HERE.md`, then `KERNEL.md`.
2. Resolve the user request through `ops/operator_kernel/config/routes.yaml` using `python ops/operator_kernel/operator_kernel.py resolve "<request>"`.
3. Load only route-scoped anchors/rules/capsules and exact target files.
4. Respect allowed/forbidden/ask-first boundaries and action-risk authorization.
5. Do not treat historical/reference files as Current HEAD.
6. Use independent verification when mandated by Kernel.
7. Before packaging, update current memory/reports and refresh file-map last.
8. DEVELOPMENT and RELEASE archives are separate classes. External side effects remain user-only.
