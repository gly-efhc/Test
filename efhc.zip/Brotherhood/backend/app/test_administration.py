from __future__ import annotations

from random import SystemRandom
from time import time
from uuid import UUID, uuid4

from .models import (
    TestAdministrationAnswerSubmit,
    TestAdministrationItemPublic,
    TestAdministrationSessionPublic,
    TestAdministrationSessionRecord,
)
from .repository import (
    active_test_administration_session,
    get_test_administration_session,
    save_test_administration_session,
)
from .scientific_assessment_bank import BANK_VERSION, INSTRUMENT_VERSION, ITEM_BY_ID, SCORING_VERSION
from .respondent_wording import canonical_answer, respondent_answer_labels, respondent_prompt, side_order, wording_version
from .test_apps import APP_BY_ID

ADMINISTRATION_VERSION = "secure-test-administration-v2-neutral-wording"
_rng = SystemRandom()


class TestAdministrationError(RuntimeError):
    def __init__(self, code: str, message: str, http_status: int = 400):
        super().__init__(message)
        self.code = code
        self.http_status = http_status


def _now_ms() -> int:
    return int(time() * 1000)


def _validate_versions(record: TestAdministrationSessionRecord) -> None:
    current = (ADMINISTRATION_VERSION, BANK_VERSION, SCORING_VERSION, INSTRUMENT_VERSION)
    frozen = (
        record.administration_version,
        record.bank_version,
        record.scoring_version,
        record.instrument_version,
    )
    if frozen != current:
        raise TestAdministrationError(
            "SESSION_VERSION_EXPIRED",
            "The saved administration session belongs to an older instrument version and cannot continue.",
            409,
        )


def _current_item(record: TestAdministrationSessionRecord) -> TestAdministrationItemPublic | None:
    if record.status != "IN_PROGRESS" or record.current_index >= len(record.item_order):
        return None
    item_id = record.item_order[record.current_index]
    item = ITEM_BY_ID[item_id]
    item_token = record.item_tokens[item_id]
    return TestAdministrationItemPublic(
        item_token=UUID(item_token),
        prompt=respondent_prompt(item),
        answer_labels=respondent_answer_labels(item, item_token),
        position=record.current_index + 1,
        total=len(record.item_order),
    )


def public_session(record: TestAdministrationSessionRecord) -> TestAdministrationSessionPublic:
    position = min(record.current_index + 1, len(record.item_order))
    return TestAdministrationSessionPublic(
        session_id=record.session_id,
        app_id=record.app_id,
        status=record.status,
        position=position,
        item_count=len(record.item_order),
        current_item=_current_item(record),
        started_at_epoch_ms=record.started_at_epoch_ms,
        updated_at_epoch_ms=record.updated_at_epoch_ms,
        completed_at_epoch_ms=record.completed_at_epoch_ms,
        result_id=record.result_id,
    )


def start_or_resume(*, global_id: int, app_id: str, instrument_locale: str) -> TestAdministrationSessionRecord:
    if app_id not in APP_BY_ID:
        raise TestAdministrationError("TEST_APP_NOT_FOUND", "test app not found", 404)
    existing = active_test_administration_session(global_id, app_id)
    if existing is not None:
        _validate_versions(existing)
        return existing

    item_order = list(APP_BY_ID[app_id]["item_ids"])
    _rng.shuffle(item_order)
    item_tokens = {item_id: str(uuid4()) for item_id in item_order}
    now_ms = _now_ms()
    record = TestAdministrationSessionRecord(
        session_id=uuid4(),
        global_id=global_id,
        app_id=app_id,
        instrument_locale=instrument_locale,
        administration_version=ADMINISTRATION_VERSION,
        bank_version=BANK_VERSION,
        scoring_version=SCORING_VERSION,
        instrument_version=INSTRUMENT_VERSION,
        status="IN_PROGRESS",
        item_order=item_order,
        item_tokens=item_tokens,
        responses={},
        response_meta={},
        current_index=0,
        started_at_epoch_ms=now_ms,
        updated_at_epoch_ms=now_ms,
    )
    return save_test_administration_session(record)


def owned_session(*, session_id: UUID, global_id: int) -> TestAdministrationSessionRecord:
    record = get_test_administration_session(session_id)
    if record is None:
        raise TestAdministrationError("SESSION_NOT_FOUND", "test administration session not found", 404)
    if record.global_id != global_id:
        raise TestAdministrationError("SESSION_OWNER_MISMATCH", "test administration session belongs to another user", 403)
    _validate_versions(record)
    return record


def submit_answer(
    *,
    record: TestAdministrationSessionRecord,
    payload: TestAdministrationAnswerSubmit,
) -> TestAdministrationSessionRecord:
    _validate_versions(record)
    if record.status != "IN_PROGRESS":
        raise TestAdministrationError("SESSION_COMPLETED", "test administration session is already completed", 409)
    if record.current_index >= len(record.item_order):
        raise TestAdministrationError("SESSION_STATE_INVALID", "test administration session has no current item", 409)

    item_id = record.item_order[record.current_index]
    expected_token = record.item_tokens[item_id]
    if str(payload.item_token) != expected_token:
        raise TestAdministrationError("ITEM_TOKEN_MISMATCH", "answer token does not match the current item", 409)
    if item_id in record.responses:
        raise TestAdministrationError("ANSWER_IMMUTABLE", "the current answer has already been recorded", 409)

    item = ITEM_BY_ID[item_id]
    item_token = record.item_tokens[item_id]
    responses = dict(record.responses)
    responses[item_id] = canonical_answer(item, item_token, payload.answer)
    response_meta = dict(record.response_meta)
    response_meta[item_id] = {
        "response_latency_ms": payload.response_latency_ms,
        "selection_changes": payload.selection_changes,
        "position": record.current_index + 1,
        "wording_version": wording_version(item),
        "side_order": side_order(item, item_token),
        "comprehension_flag": payload.comprehension_flag,
    }
    now_ms = _now_ms()
    updated = record.model_copy(
        update={
            "responses": responses,
            "response_meta": response_meta,
            "current_index": record.current_index + 1,
            "updated_at_epoch_ms": now_ms,
        }
    )
    return save_test_administration_session(updated)


def mark_completed(record: TestAdministrationSessionRecord, *, result_id: str, completed_at_epoch_ms: int) -> TestAdministrationSessionRecord:
    if record.current_index != len(record.item_order) or len(record.responses) != len(record.item_order):
        raise TestAdministrationError("SESSION_INCOMPLETE", "cannot finalize an incomplete test administration session", 409)
    completed = record.model_copy(
        update={
            "status": "COMPLETED",
            "completed_at_epoch_ms": completed_at_epoch_ms,
            "updated_at_epoch_ms": completed_at_epoch_ms,
            "result_id": result_id,
        }
    )
    return save_test_administration_session(completed)
