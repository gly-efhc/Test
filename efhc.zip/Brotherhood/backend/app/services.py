from math import floor
from .models import (
    AccountRatingRequest,
    AccountRatingResponse,
    CompatibilityRequest,
    CompatibilityResponse,
    IncidentStatus,
    TrustSummary,
)
from .storage import BASE_TRUST, INCIDENTS, VERIFIED_INTERACTIONS
from .assessment_registry import (
    PROFILE_SECTION_CODES,
    SIMILARITY_TEST_IDS,
    VALID_TEST_IDS,
    TEST_KIND_BY_ID,
    TEST_KIND_ORDER,
    TEST_POINTS_PER_TEST,
    PRODUCT_TEST_IDS,
    SYSTEM_IDS,
)


def trust_summary(global_id: int) -> TrustSummary:
    related = [item for item in INCIDENTS if item.subject_global_id == global_id]
    confirmed = [item for item in related if item.status == IncidentStatus.CONFIRMED]
    pending = [item for item in related if item.status in {IncidentStatus.PENDING, IncidentStatus.UNDER_REVIEW, IncidentStatus.APPEALED}]
    score = max(0, min(100, BASE_TRUST.get(global_id, 70) + sum(item.score_impact for item in confirmed)))
    return TrustSummary(
        global_id=global_id,
        global_id_display=f"{global_id:010d}",
        score=score,
        verified_interactions=VERIFIED_INTERACTIONS.get(global_id, 0),
        confirmed_incidents=len(confirmed),
        pending_incidents=len(pending),
    )


def account_rating(payload: AccountRatingRequest) -> AccountRatingResponse:
    valid_profile_sections = set(payload.completed_profile_section_codes) & PROFILE_SECTION_CODES
    valid_completed = set(payload.completed_test_ids) & VALID_TEST_IDS
    profile_points = len(valid_profile_sections) * 5.0
    product_completed = valid_completed & set(PRODUCT_TEST_IDS)
    legacy_completed = valid_completed & set(SYSTEM_IDS)
    if product_completed:
        test_points = len(product_completed) * (50.0 / len(PRODUCT_TEST_IDS))
    else:
        test_points = len(legacy_completed) * (50.0 / len(SYSTEM_IDS))
    return AccountRatingResponse(
        total=min(100.0, profile_points + test_points),
        profile_points=profile_points,
        test_points=test_points,
        completed_profile_sections=len(valid_profile_sections),
        completed_tests=len(valid_completed),
    )


def _compat_contribution(test_id: str, mine: int, other: int) -> float:
    # Scientific questionnaire constructs use neutral similarity semantics; no moral HIGH_IS_GOOD axis.
    return float(100 - abs(mine - other))


def compatibility(payload: CompatibilityRequest) -> CompatibilityResponse:
    common = (set(payload.my_scores) & set(payload.candidate_scores) & VALID_TEST_IDS)
    if not common:
        return CompatibilityResponse(
            score=0, tests_score=0, common_tests=0, confidence=10,
            category_scores={kind: 0 for kind in TEST_KIND_ORDER},
        )

    weighted = 0.0
    total_weight = 0.0
    by_kind: dict[str, list[tuple[float, float]]] = {kind: [] for kind in TEST_KIND_ORDER}
    for test_id in common:
        mine = max(0, min(100, payload.my_scores[test_id]))
        other = max(0, min(100, payload.candidate_scores[test_id]))
        contribution = _compat_contribution(test_id, mine, other)
        weight = 1.0
        weighted += contribution * weight
        total_weight += weight
        kind = TEST_KIND_BY_ID[test_id]
        by_kind[kind].append((contribution, weight))

    tests_score = round(weighted / total_weight)

    category_scores: dict[str, int] = {}
    for kind, rows in by_kind.items():
        if not rows:
            category_scores[kind] = 0
            continue
        kind_weight = sum(weight for _, weight in rows)
        category_scores[kind] = max(0, min(100, round(sum(score * weight for score, weight in rows) / kind_weight)))

    # The server intentionally returns the pure test layer only. Interests, trust, personality,
    # numerology and the final multi-layer total are calculated by the APK so weights remain
    # transparent and can evolve without exposing raw private answers.
    return CompatibilityResponse(
        score=max(0, min(100, tests_score)),
        tests_score=max(0, min(100, tests_score)),
        common_tests=len(common),
        confidence=max(10, min(100, floor(len(common) * 100 / len(VALID_TEST_IDS)))),
        category_scores=category_scores,
    )
