"""Brotherhood public quality vocabulary and private quality-fit math.

No quality is morally negative. A user explicitly chooses desired qualities; the server
only measures fit against hidden latent coordinates already stored from visual tasks.
Raw latent coordinates are never returned in Person DTOs.
"""

from __future__ import annotations

from collections import defaultdict

from app.localization import normalize_locale, translate

QUALITY_CATALOG = {
    'reliable': {"targets": [{"trait": 'dependability', "target": 85, "weight": 1}], "ru": 'Надёжный', "uk": 'Надійний', "en": 'Reliable', "group": 'friendship'},
    'principled': {"targets": [{"trait": 'integrity_sincerity', "target": 85, "weight": 1}], "ru": 'Принципиальный', "uk": 'Принциповий', "en": 'Principled', "group": 'character'},
    'discreet': {"targets": [{"trait": 'confidentiality', "target": 85, "weight": 1}], "ru": 'Умеет хранить доверенное', "uk": 'Уміє зберігати довірене', "en": 'Discreet', "group": 'friendship'},
    'reciprocal': {"targets": [{"trait": 'reciprocity', "target": 85, "weight": 1}], "ru": 'Взаимный', "uk": 'Взаємний', "en": 'Reciprocal', "group": 'friendship'},
    'supportive': {"targets": [{"trait": 'support_availability', "target": 85, "weight": 1}], "ru": 'Готов поддержать', "uk": 'Готовий підтримати', "en": 'Supportive', "group": 'friendship'},
    'empathetic': {"targets": [{"trait": 'empathy', "target": 85, "weight": 1}], "ru": 'Эмпатичный', "uk": 'Емпатичний', "en": 'Empathetic', "group": 'character'},
    'objective': {"targets": [{"trait": 'empathy', "target": 25, "weight": 1}], "ru": 'Объективный и эмоционально сдержанный', "uk": "Об'єктивний та емоційно стриманий", "en": 'Objective and emotionally reserved', "group": 'character'},
    'direct': {"targets": [{"trait": 'directness', "target": 85, "weight": 1}], "ru": 'Прямой', "uk": 'Прямий', "en": 'Direct', "group": 'communication'},
    'diplomatic': {"targets": [{"trait": 'directness', "target": 25, "weight": 1}], "ru": 'Дипломатичный', "uk": 'Дипломатичний', "en": 'Diplomatic', "group": 'communication'},
    'tactful': {"targets": [{"trait": 'tact', "target": 85, "weight": 1}], "ru": 'Тактичный', "uk": 'Тактовний', "en": 'Tactful', "group": 'communication'},
    'forgiving': {"targets": [{"trait": 'forgiveness', "target": 80, "weight": 1}], "ru": 'Готов восстанавливать отношения', "uk": 'Готовий відновлювати стосунки', "en": 'Repair-oriented', "group": 'friendship'},
    'boundaries': {"targets": [{"trait": 'boundary_respect', "target": 85, "weight": 1}], "ru": 'Уважает личные границы', "uk": 'Поважає особисті межі', "en": 'Respects boundaries', "group": 'friendship'},
    'independent': {"targets": [{"trait": 'autonomy', "target": 85, "weight": 1}], "ru": 'Самостоятельный', "uk": 'Самостійний', "en": 'Autonomous', "group": 'character'},
    'collaborative_decisions': {"targets": [{"trait": 'autonomy', "target": 25, "weight": 1}], "ru": 'Любит совместные решения', "uk": 'Любить спільні рішення', "en": 'Collaborative decision-maker', "group": 'character'},
    'social': {"targets": [{"trait": 'social_energy', "target": 85, "weight": 1}], "ru": 'Общительный', "uk": 'Товариський', "en": 'Socially energetic', "group": 'communication'},
    'calm_social': {"targets": [{"trait": 'social_energy', "target": 25, "weight": 1}], "ru": 'Комфортный в спокойном общении', "uk": 'Комфортний у спокійному спілкуванні', "en": 'Comfortable in low-key interaction', "group": 'communication'},
    'frequent_contact': {"targets": [{"trait": 'contact_intensity', "target": 85, "weight": 1}], "ru": 'Любит частое общение', "uk": 'Любить часте спілкування', "en": 'Prefers frequent contact', "group": 'friendship'},
    'low_maintenance': {"targets": [{"trait": 'contact_intensity', "target": 25, "weight": 1}], "ru": 'Комфортен с редким контактом', "uk": 'Комфортний з рідким контактом', "en": 'Low-maintenance contact style', "group": 'friendship'},
    'fast_response': {"targets": [{"trait": 'response_urgency', "target": 85, "weight": 1}], "ru": 'Быстро отвечает', "uk": 'Швидко відповідає', "en": 'Fast responder', "group": 'communication'},
    'spontaneous': {"targets": [{"trait": 'spontaneity', "target": 85, "weight": 1}], "ru": 'Лёгкий на подъём', "uk": 'Легкий на підйом', "en": 'Spontaneous', "group": 'lifestyle'},
    'planner': {"targets": [{"trait": 'planning', "target": 85, "weight": 1}], "ru": 'Организованный и планирующий', "uk": 'Організований та плановий', "en": 'Planner', "group": 'lifestyle'},
    'conflict_direct': {"targets": [{"trait": 'conflict_engagement', "target": 85, "weight": 1}], "ru": 'Не избегает сложных разговоров', "uk": 'Не уникає складних розмов', "en": 'Engages difficult conversations', "group": 'friendship'},
    'cool_down': {"targets": [{"trait": 'conflict_engagement', "target": 25, "weight": 1}], "ru": 'Умеет дать конфликту остыть', "uk": 'Уміє дати конфлікту охолонути', "en": 'Lets conflict cool before resolving', "group": 'friendship'},
    'self_controlled': {"targets": [{"trait": 'self_control', "target": 85, "weight": 1}], "ru": 'Самоконтроль', "uk": 'Самоконтроль', "en": 'Self-controlled', "group": 'character'},
    'status_independent': {"targets": [{"trait": 'status_independence', "target": 85, "weight": 1}], "ru": 'Не зависит от статуса', "uk": 'Не залежить від статусу', "en": 'Status-independent', "group": 'character'},
    'competitive': {"targets": [{"trait": 'competitiveness', "target": 85, "weight": 1}], "ru": 'Соревновательный', "uk": 'Змагальний', "en": 'Competitive', "group": 'business'},
    'cooperative': {"targets": [{"trait": 'competitiveness', "target": 25, "weight": 1}], "ru": 'Несоревновательный командный стиль', "uk": 'Незмагальний командний стиль', "en": 'Non-competitive team style', "group": 'business'},
    'fair': {"targets": [{"trait": 'fairness', "target": 85, "weight": 1}], "ru": 'Справедливый', "uk": 'Справедливий', "en": 'Fair', "group": 'character'},
    'trusting': {"targets": [{"trait": 'trust_openness', "target": 80, "weight": 1}], "ru": 'Быстро открывает доверие', "uk": 'Швидко відкриває довіру', "en": 'Quick to trust', "group": 'friendship'},
    'careful_trust': {"targets": [{"trait": 'trust_openness', "target": 25, "weight": 1}], "ru": 'Осторожно наращивает доверие', "uk": 'Обережно нарощує довіру', "en": 'Builds trust cautiously', "group": 'friendship'},
    'emotionally_open': {"targets": [{"trait": 'vulnerability_comfort', "target": 80, "weight": 1}], "ru": 'Эмоционально открытый', "uk": 'Емоційно відкритий', "en": 'Emotionally open', "group": 'friendship'},
    'private': {"targets": [{"trait": 'vulnerability_comfort', "target": 25, "weight": 1}], "ru": 'Сдержанный и приватный', "uk": 'Стриманий та приватний', "en": 'Private and reserved', "group": 'friendship'},
    'edgy_humor': {"targets": [{"trait": 'humor_tolerance', "target": 85, "weight": 1}], "ru": 'Любит острый юмор', "uk": 'Любить гострий гумор', "en": 'Comfortable with edgy humour', "group": 'friendship'},
    'gentle_humor': {"targets": [{"trait": 'humor_tolerance', "target": 25, "weight": 1}], "ru": 'Предпочитает бережный юмор', "uk": 'Віддає перевагу делікатному гумору', "en": 'Prefers gentle humour', "group": 'friendship'},
    'team_oriented': {"targets": [{"trait": 'group_orientation', "target": 85, "weight": 1}], "ru": 'Командный', "uk": 'Командний', "en": 'Team-oriented', "group": 'business'},
    'independent_judgment': {"targets": [{"trait": 'independence', "target": 85, "weight": 1}], "ru": 'Независимое мнение', "uk": 'Незалежна думка', "en": 'Independent judgment', "group": 'character'},
    'optimistic': {"targets": [{"trait": 'optimism', "target": 85, "weight": 1}], "ru": 'Оптимистичный', "uk": 'Оптимістичний', "en": 'Optimistic', "group": 'character'},
    'realistic_vigilance': {"targets": [{"trait": 'optimism', "target": 25, "weight": 1}], "ru": 'Реалистично осторожный', "uk": 'Реалістично обережний', "en": 'Realistically vigilant', "group": 'character'},
    'emotionally_intense': {"targets": [{"trait": 'emotional_intensity', "target": 85, "weight": 1}], "ru": 'Эмоционально насыщенный', "uk": 'Емоційно насичений', "en": 'Emotionally intense', "group": 'character'},
    'emotionally_steady': {"targets": [{"trait": 'emotional_intensity', "target": 25, "weight": 1}], "ru": 'Эмоционально ровный', "uk": 'Емоційно рівний', "en": 'Emotionally steady', "group": 'character'},
    'risk_taker': {"targets": [{"trait": 'risk_tolerance', "target": 85, "weight": 1}], "ru": 'Смелый в риске', "uk": 'Сміливий у ризику', "en": 'Risk-tolerant', "group": 'business'},
    'cautious': {"targets": [{"trait": 'risk_tolerance', "target": 25, "weight": 1}], "ru": 'Осторожный', "uk": 'Обережний', "en": 'Cautious', "group": 'business'},
    'decisive': {"targets": [{"trait": 'decisiveness', "target": 85, "weight": 1}], "ru": 'Решительный', "uk": 'Рішучий', "en": 'Decisive', "group": 'leadership'},
    'deliberate': {"targets": [{"trait": 'decisiveness', "target": 25, "weight": 1}], "ru": 'Взвешенный', "uk": 'Виважений', "en": 'Deliberate', "group": 'leadership'},
    'assertive': {"targets": [{"trait": 'assertiveness', "target": 85, "weight": 1}], "ru": 'Напористый', "uk": 'Наполегливий', "en": 'Assertive', "group": 'leadership'},
    'soft_style': {"targets": [{"trait": 'assertiveness', "target": 25, "weight": 1}], "ru": 'Мягкий стиль', "uk": "М'який стиль", "en": 'Gentle style', "group": 'leadership'},
    'leader': {"targets": [{"trait": 'leadership_orientation', "target": 85, "weight": 1}], "ru": 'Лидерский', "uk": 'Лідерський', "en": 'Leadership-oriented', "group": 'leadership'},
    'strong_contributor': {"targets": [{"trait": 'leadership_orientation', "target": 25, "weight": 1}], "ru": 'Сильный исполнитель', "uk": 'Сильний виконавець', "en": 'Strong contributor', "group": 'leadership'},
    'adaptable': {"targets": [{"trait": 'adaptability', "target": 85, "weight": 1}], "ru": 'Адаптивный', "uk": 'Адаптивний', "en": 'Adaptable', "group": 'business'},
    'stable_routine': {"targets": [{"trait": 'adaptability', "target": 25, "weight": 1}], "ru": 'Стабильный и последовательный', "uk": 'Стабільний та послідовний', "en": 'Stable and routine-oriented', "group": 'business'},
    'persistent': {"targets": [{"trait": 'perseverance', "target": 85, "weight": 1}], "ru": 'Настойчивый', "uk": 'Наполегливий', "en": 'Persistent', "group": 'business'},
    'detail_oriented': {"targets": [{"trait": 'attention_to_detail', "target": 85, "weight": 1}], "ru": 'Внимательный к деталям', "uk": 'Уважний до деталей', "en": 'Detail-oriented', "group": 'business'},
    'big_picture': {"targets": [{"trait": 'attention_to_detail', "target": 25, "weight": 1}], "ru": 'Видит общую картину', "uk": 'Бачить загальну картину', "en": 'Big-picture focused', "group": 'business'},
    'cooperative_work': {"targets": [{"trait": 'cooperation', "target": 85, "weight": 1}], "ru": 'Кооперативный', "uk": 'Кооперативний', "en": 'Cooperative', "group": 'business'},
    'initiative': {"targets": [{"trait": 'initiative', "target": 85, "weight": 1}], "ru": 'Инициативный', "uk": 'Ініціативний', "en": 'Initiative-taking', "group": 'business'},
    'innovative': {"targets": [{"trait": 'innovation', "target": 85, "weight": 1}], "ru": 'Изобретательный', "uk": 'Винахідливий', "en": 'Innovative', "group": 'business'},
    'proven_methods': {"targets": [{"trait": 'innovation', "target": 25, "weight": 1}], "ru": 'Опирается на проверенные решения', "uk": 'Спирається на перевірені рішення', "en": 'Prefers proven methods', "group": 'business'},
    'curious': {"targets": [{"trait": 'intellectual_curiosity', "target": 85, "weight": 1}], "ru": 'Любознательный', "uk": 'Допитливий', "en": 'Intellectually curious', "group": 'character'},
    'achievement': {"targets": [{"trait": 'achievement_orientation', "target": 85, "weight": 1}], "ru": 'Ориентирован на результат', "uk": 'Орієнтований на результат', "en": 'Achievement-oriented', "group": 'business'},
    'stress_resilient': {"targets": [{"trait": 'stress_tolerance', "target": 85, "weight": 1}], "ru": 'Стрессоустойчивый', "uk": 'Стресостійкий', "en": 'Stress-tolerant', "group": 'leadership'},
    'ambiguity_comfort': {"targets": [{"trait": 'ambiguity_tolerance', "target": 85, "weight": 1}], "ru": 'Комфортен в неопределённости', "uk": 'Комфортний у невизначеності', "en": 'Comfortable with ambiguity', "group": 'business'},
    'needs_clarity': {"targets": [{"trait": 'ambiguity_tolerance', "target": 25, "weight": 1}], "ru": 'Любит ясные правила', "uk": 'Любить чіткі правила', "en": 'Prefers clear rules', "group": 'business'},
    'self_confident': {"targets": [{"trait": 'self_confidence', "target": 85, "weight": 1}], "ru": 'Уверенный в себе', "uk": 'Впевнений у собі', "en": 'Self-confident', "group": 'leadership'},
    'humble': {"targets": [{"trait": 'humility', "target": 85, "weight": 1}], "ru": 'Скромный', "uk": 'Скромний', "en": 'Humble', "group": 'character'},
    'strong_presentation': {"targets": [{"trait": 'humility', "target": 25, "weight": 1}], "ru": 'Ярко презентует себя', "uk": 'Яскраво презентує себе', "en": 'Strong self-presentation', "group": 'character'},
    'family_oriented': {"targets": [{"trait": 'family_orientation', "target": 85, "weight": 1}], "ru": 'Семейно ориентированный', "uk": 'Сімейно орієнтований', "en": 'Family-oriented', "group": 'lifestyle'},
    'financially_disciplined': {"targets": [{"trait": 'money_discipline', "target": 85, "weight": 1}], "ru": 'Финансово дисциплинированный', "uk": 'Фінансово дисциплінований', "en": 'Financially disciplined', "group": 'business'},
    'punctual': {"targets": [{"trait": 'time_discipline', "target": 85, "weight": 1}], "ru": 'Пунктуальный', "uk": 'Пунктуальний', "en": 'Punctual', "group": 'business'},
    'generous': {"targets": [{"trait": 'resource_generosity', "target": 85, "weight": 1}], "ru": 'Щедрый ресурсами и помощью', "uk": 'Щедрий ресурсами та допомогою', "en": 'Generous with resources and help', "group": 'friendship'},
    'resource_boundaries': {"targets": [{"trait": 'resource_generosity', "target": 25, "weight": 1}], "ru": 'Бережно держит ресурсные границы', "uk": 'Дбайливо тримає ресурсні межі', "en": 'Protective of resource boundaries', "group": 'friendship'},
    'rule_consistent': {"targets": [{"trait": 'rule_orientation', "target": 85, "weight": 1}], "ru": 'Последователен в правилах', "uk": 'Послідовний у правилах', "en": 'Rule-consistent', "group": 'leadership'},
    'rule_flexible': {"targets": [{"trait": 'rule_orientation', "target": 25, "weight": 1}], "ru": 'Гибок к исключениям', "uk": 'Гнучкий до винятків', "en": 'Flexible with exceptions', "group": 'leadership'},
    'demanding': {"targets": [{"trait": 'achievement_orientation', "target": 85, "weight": 3}, {"trait": 'rule_orientation', "target": 80, "weight": 2}, {"trait": 'assertiveness', "target": 75, "weight": 2}, {"trait": 'dependability', "target": 80, "weight": 2}], "ru": 'Требовательный', "uk": 'Вимогливий', "en": 'Demanding', "group": 'leadership'},
    'disciplined': {"targets": [{"trait": 'dependability', "target": 85, "weight": 3}, {"trait": 'planning', "target": 85, "weight": 2}, {"trait": 'time_discipline', "target": 85, "weight": 2}, {"trait": 'self_control', "target": 80, "weight": 2}, {"trait": 'rule_orientation', "target": 80, "weight": 1}], "ru": 'Дисциплинированный', "uk": 'Дисциплінований', "en": 'Disciplined', "group": 'leadership'},
    'firm_decisions': {"targets": [{"trait": 'assertiveness', "target": 85, "weight": 3}, {"trait": 'conflict_engagement', "target": 80, "weight": 2}, {"trait": 'rule_orientation', "target": 75, "weight": 2}, {"trait": 'directness', "target": 80, "weight": 1}], "ru": 'Твёрдый в решениях', "uk": 'Твердий у рішеннях', "en": 'Firm in decisions', "group": 'leadership'},
    'uncompromising_principles': {"targets": [{"trait": 'integrity_sincerity', "target": 85, "weight": 3}, {"trait": 'rule_orientation', "target": 90, "weight": 3}, {"trait": 'assertiveness', "target": 85, "weight": 2}, {"trait": 'conflict_engagement', "target": 80, "weight": 2}], "ru": 'Бескомпромиссный в принципиальных вопросах', "uk": 'Безкомпромісний у принципових питаннях', "en": 'Uncompromising on principles', "group": 'leadership'},
    'crisis_leader': {"targets": [{"trait": 'stress_tolerance', "target": 90, "weight": 3}, {"trait": 'decisiveness', "target": 85, "weight": 3}, {"trait": 'self_control', "target": 85, "weight": 2}, {"trait": 'assertiveness', "target": 75, "weight": 1}], "ru": 'Сильный в кризисе', "uk": 'Сильний у кризі', "en": 'Strong in crisis', "group": 'leadership'},
    'diplomatic_leader': {"targets": [{"trait": 'directness', "target": 25, "weight": 2}, {"trait": 'tact', "target": 90, "weight": 3}, {"trait": 'self_control', "target": 80, "weight": 2}, {"trait": 'cooperation', "target": 80, "weight": 2}], "ru": 'Дипломатичный руководитель', "uk": 'Дипломатичний керівник', "en": 'Diplomatic leader', "group": 'leadership'},
    'strategic': {"targets": [{"trait": 'planning', "target": 80, "weight": 2}, {"trait": 'attention_to_detail', "target": 30, "weight": 2}, {"trait": 'ambiguity_tolerance', "target": 75, "weight": 2}, {"trait": 'intellectual_curiosity', "target": 75, "weight": 1}], "ru": 'Стратегический', "uk": 'Стратегічний', "en": 'Strategic', "group": 'business'},
    'operational': {"targets": [{"trait": 'dependability', "target": 85, "weight": 3}, {"trait": 'attention_to_detail', "target": 85, "weight": 3}, {"trait": 'planning', "target": 85, "weight": 2}, {"trait": 'time_discipline', "target": 80, "weight": 2}], "ru": 'Сильный в операционной работе', "uk": 'Сильний в операційній роботі', "en": 'Operationally strong', "group": 'business'},
    'entrepreneurial': {"targets": [{"trait": 'initiative', "target": 90, "weight": 3}, {"trait": 'innovation', "target": 85, "weight": 2}, {"trait": 'risk_tolerance', "target": 75, "weight": 2}, {"trait": 'achievement_orientation', "target": 85, "weight": 3}], "ru": 'Предпринимательский', "uk": 'Підприємницький', "en": 'Entrepreneurial', "group": 'business'},
    'consensus_builder': {"targets": [{"trait": 'cooperation', "target": 90, "weight": 3}, {"trait": 'tact', "target": 85, "weight": 2}, {"trait": 'group_orientation', "target": 80, "weight": 2}, {"trait": 'conflict_engagement', "target": 60, "weight": 1}], "ru": 'Умеет объединять людей', "uk": "Уміє об'єднувати людей", "en": 'Consensus builder', "group": 'leadership'},
    'persuasive': {"targets": [{"trait": 'assertiveness', "target": 75, "weight": 2}, {"trait": 'social_energy', "target": 80, "weight": 2}, {"trait": 'directness', "target": 70, "weight": 1}, {"trait": 'self_confidence', "target": 80, "weight": 2}], "ru": 'Убедительный', "uk": 'Переконливий', "en": 'Persuasive', "group": 'communication'},
    'execution_focused': {"targets": [{"trait": 'achievement_orientation', "target": 90, "weight": 3}, {"trait": 'dependability', "target": 85, "weight": 3}, {"trait": 'perseverance', "target": 85, "weight": 2}, {"trait": 'planning', "target": 75, "weight": 1}], "ru": 'Ориентирован на исполнение', "uk": 'Орієнтований на виконання', "en": 'Execution-focused', "group": 'business'},
}

QUALITY_CATALOG.update({
    'accountable': {'targets': [{'trait': 'dependability', 'target': 88, 'weight': 3}, {'trait': 'integrity_sincerity', 'target': 82, 'weight': 2}, {'trait': 'achievement_orientation', 'target': 82, 'weight': 2}], 'ru': 'Берёт ответственность', 'uk': 'Бере відповідальність', 'en': 'Accountable', 'group': 'business'},
    'transparent': {'targets': [{'trait': 'directness', 'target': 78, 'weight': 2}, {'trait': 'integrity_sincerity', 'target': 85, 'weight': 3}, {'trait': 'trust_openness', 'target': 65, 'weight': 1}], 'ru': 'Прозрачный в договорённостях', 'uk': 'Прозорий у домовленостях', 'en': 'Transparent in agreements', 'group': 'communication'},
    'confidential_partner': {'targets': [{'trait': 'confidentiality', 'target': 92, 'weight': 3}, {'trait': 'integrity_sincerity', 'target': 82, 'weight': 2}, {'trait': 'boundary_respect', 'target': 82, 'weight': 2}], 'ru': 'Надёжно хранит конфиденциальность', 'uk': 'Надійно зберігає конфіденційність', 'en': 'Confidential partner', 'group': 'business'},
    'resilient': {'targets': [{'trait': 'stress_tolerance', 'target': 88, 'weight': 3}, {'trait': 'self_control', 'target': 82, 'weight': 2}, {'trait': 'optimism', 'target': 70, 'weight': 1}, {'trait': 'perseverance', 'target': 80, 'weight': 2}], 'ru': 'Устойчивый к нагрузке', 'uk': 'Стійкий до навантаження', 'en': 'Resilient', 'group': 'character'},
    'change_driver': {'targets': [{'trait': 'adaptability', 'target': 88, 'weight': 2}, {'trait': 'initiative', 'target': 90, 'weight': 3}, {'trait': 'innovation', 'target': 84, 'weight': 2}, {'trait': 'assertiveness', 'target': 72, 'weight': 1}], 'ru': 'Драйвер изменений', 'uk': 'Рушій змін', 'en': 'Change driver', 'group': 'leadership'},
    'process_builder': {'targets': [{'trait': 'planning', 'target': 90, 'weight': 3}, {'trait': 'rule_orientation', 'target': 80, 'weight': 2}, {'trait': 'attention_to_detail', 'target': 85, 'weight': 2}, {'trait': 'dependability', 'target': 85, 'weight': 2}], 'ru': 'Умеет выстраивать процессы', 'uk': 'Уміє вибудовувати процеси', 'en': 'Process builder', 'group': 'business'},
    'relationship_builder': {'targets': [{'trait': 'empathy', 'target': 82, 'weight': 2}, {'trait': 'social_energy', 'target': 76, 'weight': 1}, {'trait': 'reciprocity', 'target': 84, 'weight': 2}, {'trait': 'tact', 'target': 85, 'weight': 2}], 'ru': 'Умеет строить отношения', 'uk': 'Уміє будувати стосунки', 'en': 'Relationship builder', 'group': 'communication'},
    'calm_under_pressure': {'targets': [{'trait': 'stress_tolerance', 'target': 92, 'weight': 3}, {'trait': 'self_control', 'target': 90, 'weight': 3}, {'trait': 'emotional_intensity', 'target': 30, 'weight': 2}, {'trait': 'decisiveness', 'target': 72, 'weight': 1}], 'ru': 'Спокоен под давлением', 'uk': 'Спокійний під тиском', 'en': 'Calm under pressure', 'group': 'leadership'},
    'autonomous_operator': {'targets': [{'trait': 'autonomy', 'target': 88, 'weight': 2}, {'trait': 'initiative', 'target': 88, 'weight': 3}, {'trait': 'dependability', 'target': 84, 'weight': 2}, {'trait': 'planning', 'target': 72, 'weight': 1}], 'ru': 'Самостоятельный исполнитель', 'uk': 'Самостійний виконавець', 'en': 'Autonomous operator', 'group': 'business'},
    'cautious_steward': {'targets': [{'trait': 'risk_tolerance', 'target': 22, 'weight': 2}, {'trait': 'money_discipline', 'target': 90, 'weight': 3}, {'trait': 'cautiousness', 'target': 88, 'weight': 2}, {'trait': 'planning', 'target': 82, 'weight': 2}], 'ru': 'Осторожный распорядитель ресурсов', 'uk': 'Обережний розпорядник ресурсів', 'en': 'Cautious steward', 'group': 'business'},
    'bold_builder': {'targets': [{'trait': 'risk_tolerance', 'target': 78, 'weight': 2}, {'trait': 'initiative', 'target': 90, 'weight': 3}, {'trait': 'achievement_orientation', 'target': 88, 'weight': 2}, {'trait': 'innovation', 'target': 82, 'weight': 2}], 'ru': 'Смелый созидатель', 'uk': 'Сміливий творець', 'en': 'Bold builder', 'group': 'business'},
    'detail_guardian': {'targets': [{'trait': 'attention_to_detail', 'target': 92, 'weight': 3}, {'trait': 'rule_orientation', 'target': 82, 'weight': 2}, {'trait': 'fairness', 'target': 80, 'weight': 1}, {'trait': 'dependability', 'target': 84, 'weight': 2}], 'ru': 'Хранитель качества и деталей', 'uk': 'Охоронець якості та деталей', 'en': 'Detail guardian', 'group': 'business'},
    'fast_decider': {'targets': [{'trait': 'decisiveness', 'target': 92, 'weight': 3}, {'trait': 'response_urgency', 'target': 82, 'weight': 2}, {'trait': 'assertiveness', 'target': 78, 'weight': 2}, {'trait': 'self_confidence', 'target': 76, 'weight': 1}], 'ru': 'Быстро принимает решения', 'uk': 'Швидко ухвалює рішення', 'en': 'Fast decision-maker', 'group': 'leadership'},
    'reflective_decider': {'targets': [{'trait': 'decisiveness', 'target': 28, 'weight': 2}, {'trait': 'cautiousness', 'target': 88, 'weight': 3}, {'trait': 'planning', 'target': 84, 'weight': 2}, {'trait': 'attention_to_detail', 'target': 78, 'weight': 1}], 'ru': 'Вдумчиво принимает решения', 'uk': 'Вдумливо ухвалює рішення', 'en': 'Reflective decision-maker', 'group': 'leadership'},
    'loyal_companion': {'targets': [{'trait': 'dependability', 'target': 88, 'weight': 3}, {'trait': 'confidentiality', 'target': 86, 'weight': 2}, {'trait': 'reciprocity', 'target': 84, 'weight': 2}, {'trait': 'support_availability', 'target': 84, 'weight': 2}], 'ru': 'Преданный товарищ', 'uk': 'Відданий товариш', 'en': 'Loyal companion', 'group': 'friendship'},
    'emotionally_warm': {'targets': [{'trait': 'empathy', 'target': 88, 'weight': 3}, {'trait': 'emotional_intensity', 'target': 72, 'weight': 1}, {'trait': 'support_availability', 'target': 86, 'weight': 2}, {'trait': 'vulnerability_comfort', 'target': 72, 'weight': 1}], 'ru': 'Эмоционально тёплый', 'uk': 'Емоційно теплий', 'en': 'Emotionally warm', 'group': 'friendship'},
    'emotionally_grounded': {'targets': [{'trait': 'self_control', 'target': 90, 'weight': 3}, {'trait': 'stress_tolerance', 'target': 88, 'weight': 3}, {'trait': 'emotional_intensity', 'target': 28, 'weight': 2}, {'trait': 'optimism', 'target': 62, 'weight': 1}], 'ru': 'Эмоционально устойчивый', 'uk': 'Емоційно стійкий', 'en': 'Emotionally grounded', 'group': 'character'},
    'constructive_challenger': {'targets': [{'trait': 'directness', 'target': 84, 'weight': 2}, {'trait': 'conflict_engagement', 'target': 82, 'weight': 2}, {'trait': 'fairness', 'target': 84, 'weight': 2}, {'trait': 'tact', 'target': 66, 'weight': 1}], 'ru': 'Конструктивно оспаривает решения', 'uk': 'Конструктивно оскаржує рішення', 'en': 'Constructive challenger', 'group': 'business'},
    'rule_enforcer': {'targets': [{'trait': 'rule_orientation', 'target': 92, 'weight': 3}, {'trait': 'assertiveness', 'target': 82, 'weight': 2}, {'trait': 'dependability', 'target': 84, 'weight': 2}, {'trait': 'fairness', 'target': 78, 'weight': 1}], 'ru': 'Последовательно обеспечивает правила', 'uk': 'Послідовно забезпечує правила', 'en': 'Consistent rule enforcer', 'group': 'leadership'},
    'flexible_negotiator': {'targets': [{'trait': 'tact', 'target': 90, 'weight': 3}, {'trait': 'adaptability', 'target': 86, 'weight': 2}, {'trait': 'cooperation', 'target': 86, 'weight': 2}, {'trait': 'rule_orientation', 'target': 38, 'weight': 1}], 'ru': 'Гибкий переговорщик', 'uk': 'Гнучкий переговорник', 'en': 'Flexible negotiator', 'group': 'communication'},
    'resource_steward': {'targets': [{'trait': 'money_discipline', 'target': 90, 'weight': 3}, {'trait': 'planning', 'target': 84, 'weight': 2}, {'trait': 'resource_generosity', 'target': 35, 'weight': 1}, {'trait': 'cautiousness', 'target': 82, 'weight': 2}], 'ru': 'Рационально управляет ресурсами', 'uk': 'Раціонально керує ресурсами', 'en': 'Resource steward', 'group': 'business'},
    'generous_mentor': {'targets': [{'trait': 'support_availability', 'target': 88, 'weight': 2}, {'trait': 'resource_generosity', 'target': 85, 'weight': 2}, {'trait': 'empathy', 'target': 84, 'weight': 2}, {'trait': 'leadership_orientation', 'target': 74, 'weight': 1}], 'ru': 'Щедрый наставник', 'uk': 'Щедрий наставник', 'en': 'Generous mentor', 'group': 'leadership'},
    'delegating_leader': {'targets': [{'trait': 'leadership_orientation', 'target': 86, 'weight': 2}, {'trait': 'autonomy', 'target': 80, 'weight': 2}, {'trait': 'cooperation', 'target': 82, 'weight': 2}, {'trait': 'planning', 'target': 78, 'weight': 1}], 'ru': 'Умеет делегировать', 'uk': 'Уміє делегувати', 'en': 'Delegating leader', 'group': 'leadership'},
    'hands_on_leader': {'targets': [{'trait': 'leadership_orientation', 'target': 84, 'weight': 2}, {'trait': 'attention_to_detail', 'target': 86, 'weight': 2}, {'trait': 'support_availability', 'target': 78, 'weight': 1}, {'trait': 'achievement_orientation', 'target': 82, 'weight': 2}], 'ru': 'Вовлечённый руководитель', 'uk': 'Залучений керівник', 'en': 'Hands-on leader', 'group': 'leadership'},
    'patient_paced': {'targets': [{'trait': 'response_urgency', 'target': 25, 'weight': 2}, {'trait': 'self_control', 'target': 84, 'weight': 2}, {'trait': 'cautiousness', 'target': 78, 'weight': 2}, {'trait': 'tact', 'target': 74, 'weight': 1}], 'ru': 'Терпеливый и неспешный', 'uk': 'Терплячий і неквапливий', 'en': 'Patient-paced', 'group': 'character'},
    'fast_paced': {'targets': [{'trait': 'response_urgency', 'target': 88, 'weight': 2}, {'trait': 'initiative', 'target': 88, 'weight': 2}, {'trait': 'decisiveness', 'target': 82, 'weight': 2}, {'trait': 'achievement_orientation', 'target': 80, 'weight': 1}], 'ru': 'Высокий темп действий', 'uk': 'Високий темп дій', 'en': 'Fast-paced', 'group': 'business'},
    'systems_thinker': {'targets': [{'trait': 'planning', 'target': 84, 'weight': 2}, {'trait': 'intellectual_curiosity', 'target': 84, 'weight': 2}, {'trait': 'attention_to_detail', 'target': 62, 'weight': 1}, {'trait': 'ambiguity_tolerance', 'target': 76, 'weight': 2}], 'ru': 'Системно мыслит', 'uk': 'Системно мислить', 'en': 'Systems thinker', 'group': 'business'},
    'independent_expert': {'targets': [{'trait': 'independence', 'target': 90, 'weight': 3}, {'trait': 'intellectual_curiosity', 'target': 82, 'weight': 2}, {'trait': 'self_confidence', 'target': 78, 'weight': 1}, {'trait': 'status_independence', 'target': 84, 'weight': 2}], 'ru': 'Независимый экспертный стиль', 'uk': 'Незалежний експертний стиль', 'en': 'Independent expert', 'group': 'business'},
})


def aggregate_latent(score_documents: list[dict]) -> tuple[dict[str, int], int]:
    buckets: dict[str, list[tuple[int, float]]] = defaultdict(list)
    for doc in score_documents:
        consistency = int(doc.get("answer_consistency", 50) or 50)
        weight = 0.35 + max(0, min(100, consistency)) / 100.0 * 0.65
        for dim in doc.get("dimensions", []) or []:
            key = str(dim.get("id", "")).strip()
            score = dim.get("score")
            if key and isinstance(score, int):
                buckets[key].append((max(0, min(100, score)), weight))
    traits: dict[str, int] = {}
    for key, rows in buckets.items():
        denominator = sum(weight for _, weight in rows) or 1.0
        traits[key] = round(sum(score * weight for score, weight in rows) / denominator)
    coverage = min(100, len(score_documents))
    evidence = 0 if not buckets else round(sum(min(6, len(rows)) / 6 for rows in buckets.values()) / len(buckets) * 100)
    confidence = round(coverage * 0.7 + evidence * 0.3)
    return traits, max(0, min(100, confidence))


def parse_desired_qualities(raw: list[str]) -> list[tuple[str, int]]:
    result: list[tuple[str, int]] = []
    seen: set[str] = set()
    for item in raw:
        parts = item.split(":", 1)
        key = parts[0].strip()
        if key not in QUALITY_CATALOG or key in seen:
            continue
        importance = 3
        if len(parts) == 2:
            try:
                importance = max(1, min(5, int(parts[1])))
            except ValueError:
                importance = 3
        result.append((key, importance))
        seen.add(key)
    return result


def _quality_fit_row(q: dict, traits: dict[str, int]) -> tuple[int, int] | None:
    rows: list[tuple[int, int]] = []
    declared_weight = 0
    present_weight = 0
    for target in q.get("targets", []):
        weight = max(1, min(5, int(target.get("weight", 1))))
        declared_weight += weight
        trait_key = str(target.get("trait", ""))
        if trait_key not in traits:
            continue
        target_score = max(0, min(100, int(target.get("target", 50))))
        rows.append((max(0, 100 - abs(traits[trait_key] - target_score)), weight))
        present_weight += weight
    if not rows:
        return None
    denominator = present_weight or 1
    fit = round(sum(value * weight for value, weight in rows) / denominator)
    coverage = round(present_weight / max(1, declared_weight) * 100)
    return max(0, min(100, fit)), max(0, min(100, coverage))


def quality_fit(desired: list[tuple[str, int]], traits: dict[str, int], confidence: int, locale: str) -> tuple[int, int, list[str]]:
    rows: list[tuple[int, int, str]] = []
    lang = normalize_locale(locale)
    coverage_values: list[int] = []
    for key, importance in desired:
        q = QUALITY_CATALOG.get(key)
        if not q:
            continue
        row = _quality_fit_row(q, traits)
        if row is None:
            continue
        fit, coverage = row
        rows.append((fit, importance, translate(lang, f"quality.{key}", fallback=str(q.get(lang, q.get("en", key))))))
        coverage_values.append(coverage)
    if not rows:
        return 0, 0, []
    denom = sum(importance for _, importance, _ in rows) or 1
    score = round(sum(fit * importance for fit, importance, _ in rows) / denom)
    catalog_coverage = round(sum(coverage_values) / len(coverage_values)) if coverage_values else 0
    fit_confidence = round(confidence * 0.8 + catalog_coverage * 0.2)
    matched = [label for fit, _, label in sorted(rows, reverse=True) if fit >= 60]
    return max(0, min(100, score)), max(0, min(100, fit_confidence)), matched[:6]


def positive_projection(traits: dict[str, int], locale: str, limit: int = 6) -> list[str]:
    lang = normalize_locale(locale)
    rows = []
    for q in QUALITY_CATALOG.values():
        row = _quality_fit_row(q, traits)
        if row is None:
            continue
        closeness, _ = row
        key = str(q.get("key", ""))
        if not key:
            key = next((catalog_key for catalog_key, candidate in QUALITY_CATALOG.items() if candidate is q), "")
        rows.append((closeness, translate(lang, f"quality.{key}", fallback=str(q.get(lang, q.get("en", key))))))
    result: list[str] = []
    for _, label in sorted(rows, reverse=True):
        if label not in result:
            result.append(label)
        if len(result) >= limit:
            break
    return result
