from __future__ import annotations
import json
from collections import defaultdict
from pathlib import Path
from .models import AssessmentDimensionResult, AssessmentResultUpsert
from .scientific_assessment_bank import BANK_VERSION, SCORING_VERSION, INSTRUMENT_VERSION, ITEM_BY_ID, ANSWER_TO_SCORE

DATA_PATH=Path(__file__).with_name('data')/'development_test_apps_v1.json'
CATALOG=json.loads(DATA_PATH.read_text(encoding='utf-8'))
APPS=tuple(CATALOG['apps'])
APP_BY_ID={row['app_id']:row for row in APPS}
APP_IDS=tuple(APP_BY_ID)
APP_IDS_BY_SYSTEM={sid:tuple(row['app_id'] for row in APPS if row['system_id']==sid) for sid in sorted({r['system_id'] for r in APPS})}


def public_catalog():
    return [{k:row[k] for k in ('app_id','title','subtitle','icon','system_id','item_count','estimated_minutes','status')} | {'catalog_version':CATALOG['version'],'bank_version':BANK_VERSION} for row in APPS]


def public_definition(app_id:str):
    app=APP_BY_ID[app_id]
    return {**{k:app[k] for k in ('app_id','title','subtitle','icon','system_id','item_count','estimated_minutes','status')},'catalog_version':CATALOG['version'],'bank_version':BANK_VERSION,'scoring_version':SCORING_VERSION,'instrument_version':INSTRUMENT_VERSION,'items_public':False}


def _score(item,answer:int)->int:
    raw=ANSWER_TO_SCORE[answer]
    return raw if int(item['scoring_direction'])>0 else 100-raw


def score_to_upsert(*,global_id:int,app_id:str,responses:dict[str,int],instrument_locale:str,started_at_epoch_ms:int,completed_at_epoch_ms:int)->AssessmentResultUpsert:
    if app_id not in APP_BY_ID: raise KeyError(app_id)
    app=APP_BY_ID[app_id]; expected=set(app['item_ids'])
    if set(responses)!=expected:
        missing=sorted(expected-set(responses)); extra=sorted(set(responses)-expected)
        raise ValueError(f'responses must match test app item bank; missing={missing[:5]} extra={extra[:5]}')
    if any(v not in {1,2,3,4} for v in responses.values()): raise ValueError('every answer must be 1..4')
    by=defaultdict(list)
    for item_id in app['item_ids']:
        item=ITEM_BY_ID[item_id]; by[item['construct_id']].append(_score(item,responses[item_id]))
    dims=[AssessmentDimensionResult(id=k,title=k,score=round(sum(v)/len(v))) for k,v in sorted(by.items())]
    dispersions=[]
    for vals in by.values():
        if len(vals)>1:
            center=sum(vals)/len(vals); dispersions.append(sum(abs(x-center) for x in vals)/len(vals))
    consistency=100 if not dispersions else max(0,min(100,round(100-sum(dispersions)/len(dispersions))))
    total=round(sum(d.score for d in dims)/len(dims)) if dims else 50
    return AssessmentResultUpsert(global_id=global_id,assessment_id=app_id,scoring_version=SCORING_VERSION,stimulus_version=INSTRUMENT_VERSION,instrument_locale=instrument_locale,started_at_epoch_ms=started_at_epoch_ms,total_score=total,risk_score=0,answer_consistency=consistency,idealized_self_presentation=0,label=app['title'],summary=f'Тест «{app["title"]}» завершён. Результат сохранён и обновил психологический профиль.',dimensions=dims,response_trace=[],completed_at_epoch_ms=completed_at_epoch_ms)
