from __future__ import annotations

import hashlib
import json
from datetime import datetime
from math import floor
from uuid import uuid4

from .models import (
    EnneagramCompatibilityRecord,
    EnneagramInstrumentItem,
    EnneagramInstrumentResponse,
    EnneagramReadingCreate,
    EnneagramReadingRecord,
    EnneagramSpecResponse,
    EnneagramTypeCatalog,
    EnneagramTypeDetail,
    EnneagramVisualChoice,
)

METHOD_ID = "EN_BROTHERHOOD_CORE_PROFILE_V1"
INSTRUMENT_VERSION = "enneagram-core-profile-18-v1"
CALCULATION_VERSION = "enneagram-reading-v1"
COMPATIBILITY_VERSION = "enneagram-existing-runtime-v1"
CATALOG_VERSION = "enneagram-type-catalog-v1"
SOURCE_IDS = ["ENNEA-001"]
SUPPORTED_LOCALES = ["sw", "ru", "en", "uk", "de", "fr", "es", "it", "tr", "pl", "da", "hi", "id"]
EVIDENCE_STATUS = "TYPOLOGICAL_EXPERIMENTAL_REQUIRES_VALIDATION"
DISCLOSURE = (
    "Enneagram is an optional typological/experimental method with mixed reliability/validity evidence. "
    "The Brotherhood EN score is an independent method index, not validated psychometric science, Trust, "
    "Quality Fit, diagnosis, or a probability of friendship/relationship success."
)

TYPE_LABELS = {
    1: {"ru": "Реформатор", "uk": "Реформатор", "en": "Reformer"},
    2: {"ru": "Помощник", "uk": "Помічник", "en": "Helper"},
    3: {"ru": "Достигатель", "uk": "Досягач", "en": "Achiever"},
    4: {"ru": "Индивидуалист", "uk": "Індивідуаліст", "en": "Individualist"},
    5: {"ru": "Исследователь", "uk": "Дослідник", "en": "Investigator"},
    6: {"ru": "Лоялист", "uk": "Лояліст", "en": "Loyalist"},
    7: {"ru": "Энтузиаст", "uk": "Ентузіаст", "en": "Enthusiast"},
    8: {"ru": "Защитник", "uk": "Захисник", "en": "Challenger"},
    9: {"ru": "Миротворец", "uk": "Миротворець", "en": "Peacemaker"},
}

PARADIGMS = [
    "GROUP_DISTANCE", "NETWORK", "PATH", "BALANCE", "RHYTHM", "STRUCTURE", "BOUNDARY", "RESOURCE",
    "CHANGE", "FOCUS", "DIRECTION", "AMBIGUITY", "CLUSTER", "EXCHANGE", "PRIORITY", "FLOW",
]
SCENE_ARCHETYPES = [
    "TEAM_TABLE", "CROSSROADS", "BRIDGE", "RESOURCE_SPLIT", "QUEUE", "WORKSPACE", "CRISIS_ROOM", "CAMP",
    "CIRCLE", "TWO_GROUPS", "OPEN_DOOR", "CLOSED_DOOR", "PATHS", "NETWORK_HUB", "HANDOFF", "SHARED_TASK",
    "OBSERVER", "FRONT_LINE", "BACK_STAGE", "EMPTY_SEAT", "RULE_BOARD", "CLOCKWORK", "TOOLBOX", "UNKNOWN_TERRAIN",
    "PAIR_WALK", "MEETING_POINT", "SHARED_SHELTER", "MAP_ROOM", "WORKBENCH", "TOWER", "GATE", "DETOUR",
    "RIVER_CROSSING", "SIGNAL_POINT", "MARKET_STALL", "NEGOTIATION_TABLE", "CHECKPOINT", "STAIRCASE", "SPLIT_PATH",
    "COMMON_GROUND", "ROTATING_LEAD", "SUPPLY_LINE", "QUIET_ROOM", "PUBLIC_SQUARE", "DEADLINE_BOARD", "NEW_PROJECT",
    "REVIEW_CIRCLE", "PARALLEL_TASKS",
]


def _locale_key(locale: str) -> str:
    key = (locale or "ru").split("-")[0].lower()
    return key if key in SUPPORTED_LOCALES else "en"


def _label(type_id: int, locale: str) -> str:
    labels = TYPE_LABELS[type_id]
    return labels.get(_locale_key(locale), labels["en"])


def _left(type_id: int) -> int:
    return 9 if type_id == 1 else type_id - 1


def _right(type_id: int) -> int:
    return 1 if type_id == 9 else type_id + 1


def type_detail(type_id: int, locale: str = "ru") -> EnneagramTypeDetail | None:
    if type_id not in TYPE_LABELS:
        return None
    return EnneagramTypeDetail(
        type_id=type_id,
        label=_label(type_id, locale),
        locale=_locale_key(locale),
        left_wing=_left(type_id),
        right_wing=_right(type_id),
        evidence_status=EVIDENCE_STATUS,
        disclosure="Traditional type label retained from the existing Brotherhood Enneagram runtime; no extra personality claims added.",
    )


def type_catalog(locale: str = "ru") -> EnneagramTypeCatalog:
    key = _locale_key(locale)
    return EnneagramTypeCatalog(
        catalog_version=CATALOG_VERSION,
        locale=key,
        type_count=9,
        types=[type_detail(type_id, key) for type_id in range(1, 10)],
        disclosure=DISCLOSURE,
    )


def _question_rows() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    sequence = 0
    for type_id in range(1, 10):
        for local in range(2):
            sequence += 1
            seed = 1000 + type_id * 31 + local * 7
            rotation = abs(seed) % 4
            loadings = [2, 1, -1, -2]
            choices = []
            for visual_index in range(4):
                choices.append(
                    {
                        "choice_id": str(visual_index + 1),
                        "intensity": abs(seed + visual_index * 3) % 4,
                        "spacing": abs(seed // 3 + visual_index * 5) % 4,
                        "order": abs(seed // 5 + visual_index * 7) % 4,
                        "asymmetry": abs(seed // 7 + visual_index * 11) % 4,
                        "direction": abs(seed // 11 + visual_index * 13) % 4,
                        "_loading": loadings[(visual_index + rotation) % 4],
                    }
                )
            rows.append(
                {
                    "item_id": f"en_{type_id}_{local + 1}",
                    "sequence": sequence,
                    "type_id": type_id,
                    "paradigm": PARADIGMS[abs(seed) % len(PARADIGMS)],
                    "scene_archetype": SCENE_ARCHETYPES[abs(seed * 3 + 17) % len(SCENE_ARCHETYPES)],
                    "choices": choices,
                }
            )
    return rows


QUESTION_ROWS = _question_rows()
QUESTION_BY_ID = {str(row["item_id"]): row for row in QUESTION_ROWS}


def public_instrument() -> EnneagramInstrumentResponse:
    return EnneagramInstrumentResponse(
        instrument_version=INSTRUMENT_VERSION,
        method_id=METHOD_ID,
        evidence_status=EVIDENCE_STATUS,
        item_count=len(QUESTION_ROWS),
        items=[
            EnneagramInstrumentItem(
                item_id=str(row["item_id"]),
                sequence=int(row["sequence"]),
                paradigm=str(row["paradigm"]),
                scene_archetype=str(row["scene_archetype"]),
                choices=[EnneagramVisualChoice(**{k: v for k, v in choice.items() if not k.startswith("_")}) for choice in row["choices"]],
            )
            for row in QUESTION_ROWS
        ],
        response_policy="Choose one of four visual compositions for every item. Hidden scoring keys are never exposed in the public instrument.",
        disclosure=DISCLOSURE,
    )


def _round_half_up(value: float) -> int:
    return floor(value + 0.5)


def score_answers(answers: dict[str, int]) -> tuple[int, int, int, dict[str, int]]:
    if set(answers) != set(QUESTION_BY_ID):
        raise ValueError("enneagram answers must contain the exact 18-item instrument set")
    scores: dict[int, int] = {}
    for type_id in range(1, 10):
        loadings: list[int] = []
        for row in QUESTION_ROWS:
            if int(row["type_id"]) != type_id:
                continue
            choice_number = answers[str(row["item_id"])]
            if choice_number not in {1, 2, 3, 4}:
                raise ValueError("enneagram answers must be integers 1..4")
            choice = row["choices"][choice_number - 1]
            loadings.append(int(choice["_loading"]))
        score = _round_half_up(50 + (sum(loadings) / len(loadings)) * 25)
        scores[type_id] = max(0, min(100, score))
    type_id = max(range(1, 10), key=lambda value: scores[value])
    left, right = _left(type_id), _right(type_id)
    wing = left if scores[left] >= scores[right] else right
    return type_id, wing, scores[type_id], {str(key): value for key, value in scores.items()}


def _answers_hash(payload: EnneagramReadingCreate) -> str:
    raw = json.dumps(
        {
            "answers": {key: payload.answers[key] for key in sorted(payload.answers)},
            "instrument_version": INSTRUMENT_VERSION,
            "calculation_version": CALCULATION_VERSION,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_reading(payload: EnneagramReadingCreate, *, created_at: datetime) -> EnneagramReadingRecord:
    type_id, wing, confidence, scores = score_answers(payload.answers)
    return EnneagramReadingRecord(
        reading_id=uuid4(),
        global_id=payload.global_id,
        global_id_display=str(payload.global_id).zfill(10),
        locale=_locale_key(payload.locale),
        method_id=METHOD_ID,
        instrument_version=INSTRUMENT_VERSION,
        calculation_version=CALCULATION_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        catalog_version=CATALOG_VERSION,
        type_id=type_id,
        wing=wing,
        confidence=confidence,
        type_label=_label(type_id, payload.locale),
        type_scores=scores,
        answers_snapshot_hash=_answers_hash(payload),
        evidence_status=EVIDENCE_STATUS,
        disclosure=DISCLOSURE,
        created_at=created_at,
    )


def compatibility_score(first_type: int | None, first_wing: int | None, second_type: int | None, second_wing: int | None) -> int | None:
    if first_type not in TYPE_LABELS or second_type not in TYPE_LABELS:
        return None
    if first_type == second_type:
        return 88
    distance = abs(int(first_type) - int(second_type))
    distance = min(distance, 9 - distance)
    wing_bonus = 10 if first_wing == second_type or second_wing == first_type else 0
    return max(35, min(95, 82 - distance * 6 + wing_bonus))


def build_compatibility(
    first_global_id: int,
    second_global_id: int,
    first_type: int,
    first_wing: int,
    second_type: int,
    second_wing: int,
    *,
    locale: str = "ru",
    created_at: datetime,
) -> EnneagramCompatibilityRecord:
    if first_global_id > second_global_id:
        first_global_id, second_global_id = second_global_id, first_global_id
        first_type, second_type = second_type, first_type
        first_wing, second_wing = second_wing, first_wing
    score = compatibility_score(first_type, first_wing, second_type, second_wing)
    if score is None:
        raise ValueError("enneagram compatibility requires two supported type inputs")
    if first_type == second_type:
        distance = 0
        wing_bonus = 0
        relation_code = "SAME_TYPE"
        explanation = "Совпадает основной тип; применяется существующее правило Brotherhood Enneagram runtime."
    else:
        distance = min(abs(first_type - second_type), 9 - abs(first_type - second_type))
        wing_bonus = 10 if first_wing == second_type or second_wing == first_type else 0
        relation_code = "WING_LINK" if wing_bonus else "CIRCULAR_TYPE_DISTANCE"
        explanation = (
            "Есть связь через крыло; базовый индекс использует круговую дистанцию типов и существующий wing bonus."
            if wing_bonus
            else "Базовый индекс использует существующую круговую дистанцию между типами без дополнительного wing bonus."
        )
    left = type_detail(first_type, locale)
    right = type_detail(second_type, locale)
    assert left is not None and right is not None
    return EnneagramCompatibilityRecord(
        comparison_id=uuid4(),
        first_global_id=first_global_id,
        second_global_id=second_global_id,
        score=score,
        first_type=left,
        first_wing=first_wing,
        second_type=right,
        second_wing=second_wing,
        circular_type_distance=distance,
        wing_bonus=wing_bonus,
        relation_code=relation_code,
        explanation=explanation,
        method_id=METHOD_ID,
        instrument_version=INSTRUMENT_VERSION,
        calculation_version=CALCULATION_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        evidence_status=EVIDENCE_STATUS,
        disclosure=DISCLOSURE,
        created_at=created_at,
    )


def public_spec() -> EnneagramSpecResponse:
    return EnneagramSpecResponse(
        method_id=METHOD_ID,
        instrument_version=INSTRUMENT_VERSION,
        calculation_version=CALCULATION_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        catalog_version=CATALOG_VERSION,
        source_ids=SOURCE_IDS,
        evidence_status=EVIDENCE_STATUS,
        item_count=len(QUESTION_ROWS),
        type_count=9,
        supported_locales=SUPPORTED_LOCALES,
        compatibility_input_policy="Latest versioned Enneagram reading when available; existing explicit type/wing profile may be used as fallback. Missing type data returns insufficient/409 rather than fabricated score.",
        compatibility_rule="Existing Brotherhood runtime: same type=88; otherwise 82 - 6*circular_distance + optional 10 wing link, clamped 35..95.",
        scientific_boundary="ENNEA-001 reports mixed reliability/validity. This module is typological/experimental and is not promoted as validated psychometrics.",
        disclosure=DISCLOSURE,
    )
