from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Iterable

from .models import AssessmentDimensionResult, AssessmentResultUpsert

DATA_PATH = Path(__file__).with_name("data") / "scientific_questionnaire_bank_v1.json"
BANK = json.loads(DATA_PATH.read_text(encoding="utf-8"))
SCORING_VERSION = str(BANK["scoring_version"])
INSTRUMENT_VERSION = str(BANK["instrument_version"])
BANK_VERSION = str(BANK["version"])
SYSTEMS = tuple(BANK["systems"])
SYSTEM_BY_ID = {row["system_id"]: row for row in SYSTEMS}
ITEMS = tuple(BANK["items"])
ITEM_BY_ID = {row["item_id"]: row for row in ITEMS}
ITEMS_BY_SYSTEM = {sid: tuple(row for row in ITEMS if row["system_id"] == sid) for sid in SYSTEM_BY_ID}

ANSWER_MIN = 1
ANSWER_MAX = 4
ANSWER_TO_SCORE = {1: 0, 2: 33, 3: 67, 4: 100}


def public_catalog() -> list[dict]:
    return [
        {
            "system_id": system["system_id"],
            "title": system["title"],
            "subtitle": system["subtitle"],
            "item_count": system["item_count"],
            "construct_count": len(system["construct_ids"]),
            "bank_version": BANK_VERSION,
            "scoring_version": SCORING_VERSION,
            "instrument_version": INSTRUMENT_VERSION,
        }
        for system in SYSTEMS
    ]


def public_definition(system_id: str) -> dict:
    system = SYSTEM_BY_ID[system_id]
    return {
        "system_id": system_id,
        "title": system["title"],
        "subtitle": system["subtitle"],
        "item_count": len(ITEMS_BY_SYSTEM[system_id]),
        "bank_version": BANK_VERSION,
        "scoring_version": SCORING_VERSION,
        "instrument_version": INSTRUMENT_VERSION,
        "items_public": False,
    }


def _normalised_item_score(item: dict, answer: int) -> int:
    raw = ANSWER_TO_SCORE[answer]
    return raw if int(item["scoring_direction"]) > 0 else 100 - raw


def _construct_scores(system_id: str, responses: dict[str, int]) -> tuple[list[AssessmentDimensionResult], int]:
    rows = ITEMS_BY_SYSTEM[system_id]
    by_construct: dict[str, list[int]] = defaultdict(list)
    for item in rows:
        answer = responses[item["item_id"]]
        by_construct[item["construct_id"]].append(_normalised_item_score(item, answer))
    dimensions = [
        AssessmentDimensionResult(id=construct, title=construct, score=round(sum(values) / len(values)))
        for construct, values in sorted(by_construct.items())
    ]
    # Internal consistency is intentionally modest: agreement of repeated signals for the same construct.
    dispersions: list[float] = []
    for values in by_construct.values():
        if len(values) > 1:
            center = sum(values) / len(values)
            dispersions.append(sum(abs(v - center) for v in values) / len(values))
    consistency = 100 if not dispersions else max(0, min(100, round(100 - sum(dispersions) / len(dispersions))))
    return dimensions, consistency


def validate_responses(system_id: str, responses: dict[str, int]) -> None:
    expected = {row["item_id"] for row in ITEMS_BY_SYSTEM[system_id]}
    if set(responses) != expected:
        missing = sorted(expected - set(responses))
        extra = sorted(set(responses) - expected)
        raise ValueError(f"responses must match active item bank; missing={missing[:5]} extra={extra[:5]}")
    if any(value not in range(ANSWER_MIN, ANSWER_MAX + 1) for value in responses.values()):
        raise ValueError("every answer must be 1..4")


def score_to_upsert(*, global_id: int, system_id: str, responses: dict[str, int], instrument_locale: str, started_at_epoch_ms: int, completed_at_epoch_ms: int) -> AssessmentResultUpsert:
    if system_id not in SYSTEM_BY_ID:
        raise KeyError(system_id)
    validate_responses(system_id, responses)
    system = SYSTEM_BY_ID[system_id]
    dimensions, consistency = _construct_scores(system_id, responses)
    total = round(sum(row.score for row in dimensions) / len(dimensions)) if dimensions else 50
    return AssessmentResultUpsert(
        global_id=global_id,
        assessment_id=system_id,
        scoring_version=SCORING_VERSION,
        stimulus_version=INSTRUMENT_VERSION,
        instrument_locale=instrument_locale,
        started_at_epoch_ms=started_at_epoch_ms,
        total_score=total,
        risk_score=0,
        answer_consistency=consistency,
        idealized_self_presentation=0,
        label="Профиль направления обновлён",
        summary=f"Завершён тест «{system['title']}». Результаты рассчитаны по научно-трассируемому item bank v1.",
        dimensions=dimensions,
        response_trace=[],
        completed_at_epoch_ms=completed_at_epoch_ms,
    )


def compatibility(system_id: str, left_dimensions: Iterable[AssessmentDimensionResult], right_dimensions: Iterable[AssessmentDimensionResult]) -> dict:
    left = {row.id: row.score for row in left_dimensions}
    right = {row.id: row.score for row in right_dimensions}
    common = sorted(set(left) & set(right))
    score = None if not common else round(sum(100 - abs(left[key] - right[key]) for key in common) / len(common))
    expected = set(SYSTEM_BY_ID[system_id]["construct_ids"])
    coverage = 0 if not expected else round(len(set(common) & expected) * 100 / len(expected))
    return {"score": score, "common_constructs": len(common), "coverage": coverage}
