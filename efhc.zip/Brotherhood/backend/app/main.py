from fastapi import Depends, FastAPI, Header, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
import os
from datetime import date
from uuid import UUID
from urllib.parse import urlencode, urlsplit, urlunsplit

from .localization import city_values, localized_city_options, normalize_locale, public_language_catalog, supported_locale_tags
from .models import (
    AuthProvider,
    AccountRatingRequest,
    AccountRatingResponse,
    AssessmentPublicReceipt,
    AssessmentResultRecord,
    AssessmentResultUpsert,
    ScientificAssessmentCatalogItem,
    ScientificAssessmentDefinitionPublic,
    ScientificAssessmentSubmit,
    TestAppCatalogItem,
    TestAppDefinitionPublic,
    TestAdministrationStart,
    TestAdministrationAnswerSubmit,
    TestAdministrationSessionPublic,
    TestResultFeedbackPublic,
    CalibrationConsentRecord,
    CalibrationConsentUpsert,
    CalibrationPilotStatus,
    CompatibilityRequest,
    CompatibilityResponse,
    CompatibilityMetricId,
    CompatibilityMetricPreferencesRecord,
    CompatibilityMetricPreferencesUpsert,
    IndependentCompatibilityRequest,
    IndependentCompatibilityResponse,
    PsychologicalReportHistoryItem,
    PsychologicalTestSystemDefinition,
    PsychologicalTestSystemResult,
    PsychologicalTestSystemCompatibility,
    PsychologicalReportRecord,
    PsychologicalReportUpsert,
    FriendshipOutcomeRecord,
    FriendshipOutcomeUpsert,
    AssociativeInstrumentCatalogItem,
    AssociativeInstrumentDefinitionPublic,
    AssociativeMeasurementSubmit,
    AssociativeMeasurementResultPublic,
    AssociativeCompatibilityRequest,
    AssociativeCompatibilityResponse,
    FriendshipPatternObservationUpsert,
    FriendshipPatternObservationRecord,
    FriendshipPatternAnalysisResponse,
    NumerologyReadingCreate,
    NumerologyReadingRecord,
    NumerologyCompatibilityRequest,
    NumerologyCompatibilityRecord,
    NumerologyCatalogIndex,
    NumerologyCatalogEntry,
    NumerologySpecResponse,
    ZodiacReadingCreate,
    ZodiacReadingRecord,
    ZodiacCompatibilityRequest,
    ZodiacCompatibilityRecord,
    ZodiacCatalogIndex,
    ZodiacSignDetail,
    ZodiacSpecResponse,
    EnneagramReadingCreate,
    EnneagramReadingRecord,
    EnneagramCompatibilityRequest,
    EnneagramCompatibilityRecord,
    EnneagramInstrumentResponse,
    EnneagramTypeCatalog,
    EnneagramTypeDetail,
    EnneagramSpecResponse,
    Community,
    CommunityCreate,
    CommunityKind,
    CommunityMembershipStatus,
    SearchRequestCreate,
    SearchRequestRecord,
    SearchRequestUpdate,
    QualityFitEvaluationRequest,
    QualityFitEvaluationRecord,
    QualityFitCatalogResponse,
    QualityFitSpecResponse,
    IdentityResolveRequest,
    IdentityResolveResponse,
    Person,
    PersonalityProfileRecord,
    PersonalityProfileUpsert,
    ProfileAvatarRecord,
    ProfileAvatarUpsert,
    ProfileRecord,
    ProfileUpsert,
    TrustIncident,
    TrustIncidentCreate,
    TrustSummary,
    MessageCreate,
    MessageRecord,
    AppVersionManifest, AttachmentPayload, ChatMessageCreate, ChatMessageEdit, ChatMessageRecord, ConversationSummary, ConversationMemberRecord, DeviceKeyRecord, DeviceKeyUpsert, DirectConversationCreate, GroupConversationCreate, ReadReceiptRequest, MessageReactionRequest, MessageReactionRecord, TypingRequest, TypingStatus, UserBlockRequest, UserBlockStatus, ChatReportCreate, PushTokenUpsert,
    SessionIssueRequest,
    SessionIssueResponse,
    ProviderCredentialExchange,
    SessionRefreshRequest,
    SessionStatusResponse,
    EmailCodeRequest,
    EmailCodeVerifyRequest,
    EmailCodeAccepted,
    GoogleAuthConfigResponse,
    TelegramOidcBeginRequest,
    TelegramOidcBeginResponse,
    TelegramOidcFinishRequest,
    PasskeyOptionsResponse,
    PasskeyRegistrationFinish,
    PasskeyAuthenticationFinish,
    UserSettingsUpsert,
    UserSettingsRecord,
    HostDetailsResponse, HostProfileOwnerRecord, HostProfileUpsert, HospitalityAvailabilityRecord,
    HospitalityAvailabilityUpsert, HospitalityEligibilityResponse, HospitalityArrivalDetails, HospitalityTickResult,
    StayRequestCreate, StayRequestRecord, StayRequestStatusAction,
    StayConfirmationUpsert, StayReviewUpsert, StayReviewRecord, HospitalityStayVerificationSummary,
    HospitalityReviewState, HospitalityPublicReview, HospitalityReputationSummary, HospitalityIncidentCreate,
    HospitalityRequestEventRecord, HospitalityRestrictionRecord, TrustModerationDecisionCreate,
    TrustModerationResult, TrustAppealCreate, TrustAppealRecord,
)
from .services import account_rating, compatibility
from .independent_compatibility import CANONICAL_METRIC_ORDER, calculate_independent_compatibility
from .scientific_assessment_bank import (
    public_catalog as scientific_assessment_catalog,
    public_definition as scientific_assessment_definition,
    score_to_upsert as score_scientific_assessment,
    SYSTEM_BY_ID as SCIENTIFIC_ASSESSMENT_SYSTEMS,
    ITEMS as SCIENTIFIC_ASSESSMENT_ITEMS,
    BANK_VERSION as SCIENTIFIC_BANK_VERSION,
    SCORING_VERSION as SCIENTIFIC_SCORING_VERSION,
    INSTRUMENT_VERSION as SCIENTIFIC_INSTRUMENT_VERSION,
)
from .psychological_test_systems import BY_ID as PSYCHOLOGICAL_TEST_SYSTEMS_BY_ID, public_catalog as psychological_test_system_catalog, all_system_results as psychological_test_system_results, system_compatibility as psychological_test_system_compatibility
from .test_apps import public_catalog as test_app_catalog, public_definition as test_app_definition, score_to_upsert as score_test_app, APP_BY_ID as TEST_APPS, APP_IDS as TEST_APP_IDS
from .test_administration import (
    TestAdministrationError,
    start_or_resume as start_or_resume_test_session,
    owned_session as owned_test_session,
    submit_answer as submit_test_session_answer,
    mark_completed as mark_test_session_completed,
    public_session as public_test_session,
)
from .associative_implicit import public_catalog as associative_catalog, public_definition as associative_definition, score_to_upsert as score_associative_measurement, compatibility as associative_method_compatibility, BY_ID as ASSOCIATIVE_INSTRUMENTS
from .friendship_pattern_research import analyze as analyze_friendship_patterns
from .numerology_vnext import (
    public_spec as numerology_public_spec,
    catalog_index as numerology_catalog_index,
    catalog_entry as numerology_catalog_entry,
    build_reading as build_numerology_reading,
    build_compatibility as build_numerology_compatibility,
    vedic_date_numbers,
)
from .zodiac_vnext import (
    public_spec as zodiac_public_spec,
    catalog_index as zodiac_catalog_index,
    sign_detail as zodiac_sign_detail,
    sign_for_date as zodiac_sign_for_date,
    build_reading as build_zodiac_reading,
    build_compatibility as build_zodiac_compatibility,
)
from .enneagram_vnext import (
    public_spec as enneagram_public_spec,
    public_instrument as enneagram_public_instrument,
    type_catalog as enneagram_type_catalog,
    type_detail as enneagram_type_detail,
    build_reading as build_enneagram_reading,
    build_compatibility as build_enneagram_compatibility,
)
from .quality_matching import positive_projection
from .test_result_feedback import build_test_result_feedback
from .database import database_health
from .auth_security import consume_login_ticket, issue_login_ticket, issue_session, refresh_session, revoke_access_session, require_authenticated_session, require_internal_secret, require_owner, session_global_id
from .provider_config import provider_readiness
from .provider_auth import begin_telegram_oidc, exchange_telegram_oidc_code, request_email_code, telegram_app_callback_uri, verify_email_code, verify_provider_credential
from .passkey_auth import authentication_options as passkey_authentication_options, finish_authentication as finish_passkey_authentication, finish_registration as finish_passkey_registration, registration_options as passkey_registration_options
from .calibration_pilot import PilotEnrollmentError
from .quality_fit_v2 import (
    build_evaluation as build_quality_fit_evaluation,
    catalog as quality_fit_catalog_v2,
    requirements_from_legacy,
    spec as quality_fit_spec_v2,
)
from .repository import (
    assessment_results_for_user,
    get_compatibility_metric_preferences,
    get_psychological_report,
    latest_psychological_report,
    psychological_report_history,
    upsert_compatibility_metric_preferences,
    upsert_psychological_report,
    calibration_consent_for_user,
    calibration_pilot_status,
    friendship_outcomes_for_analysis,
    upsert_associative_result,
    associative_results_for_user,
    latest_associative_result,
    associative_raw_result,
    upsert_friendship_pattern_observation,
    friendship_pattern_observations_for_analysis,
    save_numerology_reading,
    numerology_readings_for_user,
    get_numerology_reading,
    latest_numerology_reading,
    save_numerology_comparison,
    numerology_comparison_history,
    save_zodiac_reading,
    zodiac_readings_for_user,
    get_zodiac_reading,
    latest_zodiac_reading,
    save_zodiac_comparison,
    zodiac_comparison_history,
    save_enneagram_reading,
    enneagram_readings_for_user,
    get_enneagram_reading,
    latest_enneagram_reading,
    save_enneagram_comparison,
    enneagram_comparison_history,
    create_community,
    set_community_membership,
    community_membership,
    create_search_request,
    list_search_requests,
    get_search_request,
    update_search_request,
    archive_search_request,
    save_quality_fit_evaluation,
    quality_fit_evaluation_history,
    get_quality_fit_evaluation,
    create_incident,
    create_message,
    get_personality_profile,
    get_profile,
    list_communities,
    list_people,
    messages_for_user,
    app_version_manifest, attachment_payload, chat_messages, conversations_for_user, conversation_members, add_group_member, remove_group_member, create_chat_message, create_group_conversation, device_keys_for_user, mark_chat_read, open_direct_conversation, upsert_device_key, edit_chat_message, toggle_message_reaction, delete_chat_message, set_typing, typing_users, set_user_block, is_user_blocked, has_user_block, upsert_push_token,
    moderate_incident,
    moderate_incident_with_decision,
    create_appeal,
    production_storage_ready,
    resolve_identity,
    storage_mode,
    trust_summary,
    upsert_personality_profile,
    upsert_assessment_result,
    upsert_calibration_consent,
    upsert_friendship_outcome,
    upsert_profile,
    upsert_profile_avatar,
    upsert_user_settings,
    get_user_settings,
    has_user_block,
    IdentityLinkConflict,
)
from .hospitality import (
    HospitalityError, create_stay_request, delete_host_availability, evaluate_hospitality_eligibility,
    get_arrival_details, get_host_details, get_owner_host_profile, get_stay_request, hospitality_discovery_summary,
    hospitality_enabled, hospitality_tick, list_host_availability, list_stay_requests, require_hospitality_enabled,
    update_stay_request_status, upsert_host_availability, upsert_host_profile,
    submit_stay_confirmation, get_stay_verification, submit_stay_review, get_review_state,
    list_public_hospitality_reviews, hospitality_reputation, create_hospitality_incident,
    list_conversation_events, apply_hospitality_restriction_from_confirmed_incident,
)


app = FastAPI(
    title="Brotherhood API",
    version="0.5.35",
    description="Offline-first platform for male friendship compatibility, communities, global identity and moderated trust reputation.",
)

allowed_origins = [
    item.strip()
    for item in os.getenv("BROTHERHOOD_ALLOWED_ORIGINS", "http://localhost,http://127.0.0.1").split(",")
    if item.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CITIES = list(city_values())


@app.get("/health")
def health() -> dict[str, str | bool]:
    return {"status": "ok", "service": "brotherhood-api", "version": "0.5.35", "storage": storage_mode(), "production_ready": production_storage_ready()}


@app.get("/v1/config")
def public_config() -> dict[str, object]:
    return {
        "version": "0.5.35",
        "audience": "men_18_plus",
        "relationship_scope": "platonic_male_friendship",
        "locales": list(supported_locale_tags()),
        "languages": public_language_catalog(),
        "themes": ["system", "light", "black"],
        "auth_providers": ["google", "telegram", "facebook", "email", "passkey"],
        "future_auth_providers": ["apple", "microsoft", "phone"],
        "personality_model": {"name": "Brotherhood-32", "type_count": 32},
        "hospitality": {"enabled": hospitality_enabled(), "contract": "hospitality-profile-v1", "free_stays_only": True},
        "tests": {"count": len(SCIENTIFIC_ASSESSMENT_SYSTEMS), "task_count": len(SCIENTIFIC_ASSESSMENT_ITEMS), "question_count": len(SCIENTIFIC_ASSESSMENT_ITEMS), "format": "scientific_questionnaire_v1", "bank_version": SCIENTIFIC_BANK_VERSION, "scoring_version": SCIENTIFIC_SCORING_VERSION, "instrument_version": SCIENTIFIC_INSTRUMENT_VERSION, "numerology_is_test": False},
        "associative_implicit": {"enabled": True, "method_count": len(ASSOCIATIVE_INSTRUMENTS), "methods": list(ASSOCIATIVE_INSTRUMENTS.keys()), "result_history": True, "pair_compatibility_separate": True, "raw_events_public": False},
        "friendship_pattern_research": {"enabled": True, "contract": "reverse-friendship-pattern-discovery-v1", "requires_pre_friendship_snapshot": True, "comparison_group": "NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE", "automatic_production_reweighting": False},
        "compatibility_contract": {
            "version": "independent-compatibility-v1",
            "metrics": ["PC", "IC", "VC", "CC", "LC", "PT", "EN", "NU", "AS"],
            "aggregation": "UNWEIGHTED_ARITHMETIC_MEAN_OF_SELECTED_AVAILABLE_METRICS",
            "trust_separate": True,
            "account_rating_separate": True,
            "quality_fit_separate": True,
            "psychological_modules": ["loyalty", "integrity", "reliability", "conflict", "boundaries", "support", "competition", "communication", "mutual_aid", "lifestyle"],
        },
        "compatibility_layers_legacy": ["tests", "interests", "character", "values", "lifestyle", "friendship_goals", "communication", "conflict", "business", "social_format", "brotherhood32", "enneagram", "zodiac", "vedic_numerology", "geography"],
        "diagnostic_predictors": [],
        "quality_matching": {"contract_version": "quality-fit-search-intent-v2", "catalog_version": "quality-fit-catalog-v2", "quality_count": 112, "assessment_model": "scientific-questionnaire-v1", "directional": True, "hard_requirements": True, "user_selects_role": True, "user_selects_qualities": True, "role_injects_defaults": False, "separate_from_compatibility": True, "separate_from_trust": True, "raw_latent_profile_public": False},
        "weight_calibration": {"source": "friendship_outcomes", "target": "still_active_90d", "automatic_production_reweighting": False},
        "vedic_numerology": {"is_test": False, "compatibility_source": "birth_dates_only"},
        "chat": {"direct": "e2ee", "groups": "server_encrypted", "features": ["media", "reply", "reactions", "edit", "delete", "typing", "receipts", "block", "report", "group_member_management", "offline_retry"]},
        "global_id_format": "0000000001",
        "database_access": "vercel_backend_only"
    }


@app.get("/health/database")
def health_database() -> dict[str, str | bool]:
    return database_health()


@app.get("/health/storage")
def health_storage() -> dict[str, str | bool]:
    return {"mode": storage_mode(), "production_ready": production_storage_ready()}


@app.post("/internal/identity/resolve", response_model=IdentityResolveResponse)
def identity_resolve(
    payload: IdentityResolveRequest,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> IdentityResolveResponse:
    """Called only after a provider credential has been verified server-side."""
    require_internal_secret(internal_auth)
    return resolve_identity(payload)


@app.post("/internal/sessions/issue", response_model=SessionIssueResponse)
def session_issue(
    payload: SessionIssueRequest,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> SessionIssueResponse:
    """Bridge used by verified Google/Telegram/Facebook adapters to issue an app session."""
    require_internal_secret(internal_auth)
    return issue_session(payload.global_id, payload.provider, device_id=payload.device_id)


@app.get("/v1/auth/providers")
def auth_providers() -> list[dict[str, object]]:
    return provider_readiness()


@app.get("/v1/auth/google/config", response_model=GoogleAuthConfigResponse)
def auth_google_config() -> GoogleAuthConfigResponse:
    client_id = os.getenv("GOOGLE_CLIENT_ID", "").strip()
    if not client_id:
        raise HTTPException(status_code=503, detail="Google authentication is not configured")
    return GoogleAuthConfigResponse(client_id=client_id)


@app.post("/v1/auth/provider/exchange", response_model=SessionIssueResponse)
def auth_provider_exchange(payload: ProviderCredentialExchange) -> SessionIssueResponse:
    if payload.tenant != "default":
        raise HTTPException(status_code=400, detail="Public provider authentication uses the default identity tenant")
    verified = verify_provider_credential(payload)
    try:
        resolved = resolve_identity(
            IdentityResolveRequest(provider=verified.provider, provider_subject=verified.subject, tenant="default"),
            email_normalized=verified.email.lower() if verified.email and verified.email_verified else None,
        )
    except IdentityLinkConflict as exc:
        raise HTTPException(status_code=409, detail="Verified identity requires explicit account recovery") from exc
    return issue_session(resolved.global_id, verified.provider, device_id=payload.device_id)


@app.post("/v1/auth/telegram/begin", response_model=TelegramOidcBeginResponse)
def auth_telegram_begin(payload: TelegramOidcBeginRequest) -> TelegramOidcBeginResponse:
    return TelegramOidcBeginResponse(authorization_url=begin_telegram_oidc(payload.device_id))


def _callback_url(base: str, **params: str) -> str:
    parsed = urlsplit(base)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(params), ""))


@app.get("/v1/auth/telegram/callback", response_class=RedirectResponse)
def auth_telegram_callback(
    code: str | None = Query(default=None, min_length=8, max_length=4096),
    state: str | None = Query(default=None, min_length=16, max_length=512),
    error: str | None = Query(default=None, max_length=256),
) -> RedirectResponse:
    app_callback = telegram_app_callback_uri()
    if error or not code or not state:
        return RedirectResponse(_callback_url(app_callback, error="authorization_failed"), status_code=302)
    try:
        verified = exchange_telegram_oidc_code(TelegramOidcFinishRequest(code=code, state=state))
        resolved = resolve_identity(
            IdentityResolveRequest(provider=verified.provider, provider_subject=verified.subject, tenant="default"),
        )
        if not verified.initiating_device_id:
            raise HTTPException(status_code=401, detail="Telegram login has no initiating device binding")
        ticket = issue_login_ticket(resolved.global_id, AuthProvider.TELEGRAM, verified.initiating_device_id)
    except (HTTPException, IdentityLinkConflict):
        return RedirectResponse(_callback_url(app_callback, error="authorization_failed"), status_code=302)
    return RedirectResponse(_callback_url(app_callback, ticket=ticket), status_code=302)


@app.post("/v1/auth/telegram/finish", response_model=SessionIssueResponse)
def auth_telegram_finish(payload: TelegramOidcFinishRequest) -> SessionIssueResponse:
    if payload.ticket:
        resolved_ticket = consume_login_ticket(payload.ticket, payload.device_id)
        if resolved_ticket is None or resolved_ticket[1] is not AuthProvider.TELEGRAM:
            raise HTTPException(status_code=401, detail="Invalid or expired Telegram login ticket")
        return issue_session(resolved_ticket[0], AuthProvider.TELEGRAM, device_id=payload.device_id)

    # Compatibility path for source clients that complete code/state directly on the server.
    verified = exchange_telegram_oidc_code(payload)
    try:
        resolved = resolve_identity(
            IdentityResolveRequest(provider=verified.provider, provider_subject=verified.subject, tenant="default"),
        )
    except IdentityLinkConflict as exc:
        raise HTTPException(status_code=409, detail="Verified identity requires explicit account recovery") from exc
    return issue_session(resolved.global_id, AuthProvider.TELEGRAM, device_id=payload.device_id)


@app.post("/v1/auth/email/request-code", response_model=EmailCodeAccepted, status_code=202)
def auth_email_request_code(payload: EmailCodeRequest) -> EmailCodeAccepted:
    request_email_code(payload)
    return EmailCodeAccepted()


@app.post("/v1/auth/email/verify", response_model=SessionIssueResponse)
def auth_email_verify(payload: EmailCodeVerifyRequest) -> SessionIssueResponse:
    email = verify_email_code(payload)
    try:
        resolved = resolve_identity(
            IdentityResolveRequest(provider=AuthProvider.EMAIL, provider_subject=email, tenant="default"),
            email_normalized=email,
        )
    except IdentityLinkConflict as exc:
        raise HTTPException(status_code=409, detail="Verified identity requires explicit account recovery") from exc
    return issue_session(resolved.global_id, AuthProvider.EMAIL, device_id=payload.device_id)


@app.post("/v1/auth/refresh", response_model=SessionIssueResponse)
def auth_refresh(payload: SessionRefreshRequest) -> SessionIssueResponse:
    session = refresh_session(payload.refresh_token, device_id=payload.device_id)
    if session is None:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")
    return session


@app.get("/v1/auth/session", response_model=SessionStatusResponse)
def auth_session(session: SessionStatusResponse = Depends(require_authenticated_session)) -> SessionStatusResponse:
    return session


@app.post("/v1/auth/logout", status_code=204)
def auth_logout(authorization: str | None = Header(default=None, alias="Authorization")) -> Response:
    revoke_access_session(authorization)
    return Response(status_code=204)


@app.post("/v1/auth/passkey/registration/options", response_model=PasskeyOptionsResponse)
def auth_passkey_registration_options(session: SessionStatusResponse = Depends(require_authenticated_session)) -> PasskeyOptionsResponse:
    return passkey_registration_options(session.global_id)


@app.post("/v1/auth/passkey/registration/finish", status_code=204)
def auth_passkey_registration_finish(
    payload: PasskeyRegistrationFinish,
    session: SessionStatusResponse = Depends(require_authenticated_session),
) -> Response:
    finish_passkey_registration(session.global_id, payload)
    return Response(status_code=204)


@app.post("/v1/auth/passkey/authentication/options", response_model=PasskeyOptionsResponse)
def auth_passkey_authentication_options() -> PasskeyOptionsResponse:
    return passkey_authentication_options()


@app.post("/v1/auth/passkey/authentication/finish", response_model=SessionIssueResponse)
def auth_passkey_authentication_finish(payload: PasskeyAuthenticationFinish) -> SessionIssueResponse:
    return finish_passkey_authentication(payload)


@app.put("/v1/settings/{global_id}", response_model=UserSettingsRecord)
def save_user_settings(
    global_id: int,
    payload: UserSettingsUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> UserSettingsRecord:
    require_owner(authenticated_global_id, global_id)
    return upsert_user_settings(global_id, payload)


@app.get("/v1/settings/{global_id}", response_model=UserSettingsRecord)
def read_user_settings(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> UserSettingsRecord:
    require_owner(authenticated_global_id, global_id)
    item = get_user_settings(global_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Settings not found")
    return item


@app.get("/v1/cities", response_model=list[str], deprecated=True)
def cities(q: str | None = None) -> list[str]:
    """Legacy canonical city values. New clients should use /v1/city-options."""
    if not q:
        return CITIES
    query = q.casefold()
    return [city for city in CITIES if query in city.casefold()]


@app.get("/v1/city-options", response_model=list[dict[str, str]])
def city_options(
    q: str | None = None,
    locale: str = Query(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$"),
) -> list[dict[str, str]]:
    """Localized presentation labels paired with stable search/storage values."""
    return localized_city_options(normalize_locale(locale), q)


@app.get("/v1/people", response_model=list[Person])
def people(
    city: str,
    radius_km: int = Query(default=25, ge=1, le=500),
    requester_global_id: int | None = Query(default=None, ge=1, le=9_999_999_999),
    role: str = Query(default="friend", max_length=40),
    qualities: str = Query(default="", max_length=2400),
    locale: str = Query(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$"),
    can_host: bool = Query(default=False),
    hospitality_city_id: UUID | None = Query(default=None),
    stay_check_in: date | None = Query(default=None),
    stay_check_out: date | None = Query(default=None),
    stay_guests: int | None = Query(default=None, ge=1, le=100),
    sleeping_condition: str | None = Query(default=None, pattern=r"^(private_room|shared_room|sofa|entire_space)$"),
    eligible_only: bool = Query(default=False),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[Person]:
    if authenticated_global_id is not None:
        if requester_global_id is not None and requester_global_id != authenticated_global_id:
            raise HTTPException(status_code=403, detail="requester_global_id does not match authenticated session")
        requester_global_id = authenticated_global_id
    desired = [item for item in qualities.split(",") if item][:100]
    people_rows = list_people(city, radius_km, requester_global_id, desired_qualities=desired, locale=normalize_locale(locale))

    hospitality_filter_requested = any([can_host, hospitality_city_id is not None, stay_check_in is not None, stay_check_out is not None, stay_guests is not None, sleeping_condition is not None, eligible_only])
    if not hospitality_filter_requested:
        return people_rows
    if requester_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required for Hospitality discovery")
    if not hospitality_enabled():
        raise HTTPException(status_code=404, detail={"code": "HOSPITALITY_DISABLED", "message": "Hospitality feature is disabled"})
    if any(value is not None for value in (stay_check_in, stay_check_out, stay_guests)) and not all(value is not None for value in (stay_check_in, stay_check_out, stay_guests)):
        raise HTTPException(status_code=400, detail={"code": "HOSPITALITY_DATES_INVALID", "message": "stay_check_in, stay_check_out and stay_guests must be supplied together"})
    if eligible_only and requester_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required for eligible_only")

    filtered: list[Person] = []
    for person in people_rows:
        try:
            summary = hospitality_discovery_summary(
                requester_global_id, person.global_id, hospitality_city_id=hospitality_city_id, sleeping_condition=sleeping_condition,
                check_in_date=stay_check_in, check_out_date=stay_check_out, guests_count=stay_guests,
            )
        except HospitalityError as exc:
            raise HTTPException(status_code=exc.status_code, detail=exc.as_detail()) from exc
        if summary is None:
            continue
        if eligible_only and (summary.eligibility is None or not summary.eligibility.eligible):
            continue
        filtered.append(person.model_copy(update={"hospitality": summary}))
    return filtered




def _hospitality_http_error(exc: HospitalityError) -> HTTPException:
    return HTTPException(status_code=exc.status_code, detail=exc.as_detail())


def _hospitality_actor(authenticated_global_id: int | None) -> int:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    return authenticated_global_id


@app.get("/v1/hospitality/profile", response_model=HostProfileOwnerRecord)
def hospitality_profile_get(authenticated_global_id: int | None = Depends(session_global_id)) -> HostProfileOwnerRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        value = get_owner_host_profile(actor)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc
    if value is None:
        raise HTTPException(status_code=404, detail={"code": "HOSPITALITY_PROFILE_NOT_FOUND", "message": "Host profile not found"})
    return value


@app.put("/v1/hospitality/profile", response_model=HostProfileOwnerRecord)
def hospitality_profile_put(payload: HostProfileUpsert, authenticated_global_id: int | None = Depends(session_global_id)) -> HostProfileOwnerRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return upsert_host_profile(actor, payload)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/availability", response_model=list[HospitalityAvailabilityRecord])
def hospitality_availability_get(authenticated_global_id: int | None = Depends(session_global_id)) -> list[HospitalityAvailabilityRecord]:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return list_host_availability(actor)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.put("/v1/hospitality/availability", response_model=HospitalityAvailabilityRecord)
def hospitality_availability_put(
    payload: HospitalityAvailabilityUpsert,
    availability_id: UUID | None = Query(default=None),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> HospitalityAvailabilityRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return upsert_host_availability(actor, payload, availability_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.delete("/v1/hospitality/availability/{availability_id}", status_code=204)
def hospitality_availability_delete(
    availability_id: UUID,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> Response:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        deleted = delete_host_availability(actor, availability_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc
    if not deleted:
        raise HTTPException(status_code=404, detail={"code": "HOSPITALITY_AVAILABILITY_NOT_FOUND", "message": "Availability record not found"})
    return Response(status_code=204)


@app.get("/v1/hospitality/hosts/{host_global_id}", response_model=HostDetailsResponse)
def hospitality_host_details(
    host_global_id: int,
    check_in_date: date | None = Query(default=None),
    check_out_date: date | None = Query(default=None),
    guests_count: int | None = Query(default=None, ge=1, le=100),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> HostDetailsResponse:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return get_host_details(actor, host_global_id, check_in_date=check_in_date, check_out_date=check_out_date, guests_count=guests_count)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/hosts/{host_global_id}/eligibility", response_model=HospitalityEligibilityResponse)
def hospitality_eligibility(
    host_global_id: int,
    check_in_date: date,
    check_out_date: date,
    guests_count: int = Query(ge=1, le=100),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> HospitalityEligibilityResponse:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return evaluate_hospitality_eligibility(actor, host_global_id, check_in_date, check_out_date, guests_count)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.post("/v1/hospitality/requests", response_model=StayRequestRecord, status_code=201)
def hospitality_request_create(
    payload: StayRequestCreate,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> StayRequestRecord:
    actor = _hospitality_actor(authenticated_global_id)
    if idempotency_key is None:
        raise HTTPException(status_code=400, detail={"code": "HOSPITALITY_IDEMPOTENCY_KEY_INVALID", "message": "Idempotency-Key is required"})
    try:
        return create_stay_request(actor, payload, idempotency_key=idempotency_key)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/requests", response_model=list[StayRequestRecord])
def hospitality_requests_list(
    direction: str = Query(default="all", pattern=r"^(incoming|outgoing|all)$"),
    status: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[StayRequestRecord]:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return list_stay_requests(actor, direction=direction, status=status, limit=limit, offset=offset)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/requests/{request_id}", response_model=StayRequestRecord)
def hospitality_request_detail(request_id: UUID, authenticated_global_id: int | None = Depends(session_global_id)) -> StayRequestRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        value = get_stay_request(actor, request_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc
    if value is None:
        raise HTTPException(status_code=404, detail={"code": "HOSPITALITY_REQUEST_NOT_FOUND", "message": "Stay request not found"})
    return value


@app.get("/v1/hospitality/requests/{request_id}/arrival-details", response_model=HospitalityArrivalDetails)
def hospitality_arrival_details(request_id: UUID, authenticated_global_id: int | None = Depends(session_global_id)) -> HospitalityArrivalDetails:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return get_arrival_details(actor, request_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.patch("/v1/hospitality/requests/{request_id}/status", response_model=StayRequestRecord)
def hospitality_request_status(
    request_id: UUID,
    payload: StayRequestStatusAction,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> StayRequestRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return update_stay_request_status(actor, request_id, payload)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/conversations/{conversation_id}/events", response_model=list[HospitalityRequestEventRecord])
def hospitality_conversation_events(
    conversation_id: str, authenticated_global_id: int | None = Depends(session_global_id),
) -> list[HospitalityRequestEventRecord]:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return list_conversation_events(actor, conversation_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.post("/v1/hospitality/requests/{request_id}/confirmation", response_model=HospitalityStayVerificationSummary)
def hospitality_confirmation(
    request_id: UUID, payload: StayConfirmationUpsert, authenticated_global_id: int | None = Depends(session_global_id),
) -> HospitalityStayVerificationSummary:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return submit_stay_confirmation(actor, request_id, payload)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/requests/{request_id}/verification", response_model=HospitalityStayVerificationSummary)
def hospitality_verification(
    request_id: UUID, authenticated_global_id: int | None = Depends(session_global_id),
) -> HospitalityStayVerificationSummary:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return get_stay_verification(actor, request_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.post("/v1/hospitality/requests/{request_id}/reviews", response_model=StayReviewRecord)
def hospitality_review_submit(
    request_id: UUID, payload: StayReviewUpsert, authenticated_global_id: int | None = Depends(session_global_id),
) -> StayReviewRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return submit_stay_review(actor, request_id, payload)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/requests/{request_id}/review-state", response_model=HospitalityReviewState)
def hospitality_review_state(
    request_id: UUID, authenticated_global_id: int | None = Depends(session_global_id),
) -> HospitalityReviewState:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return get_review_state(actor, request_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/users/{global_id}/hospitality-reviews", response_model=list[HospitalityPublicReview])
def hospitality_public_reviews(global_id: int, limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0)) -> list[HospitalityPublicReview]:
    try:
        return list_public_hospitality_reviews(global_id, limit=limit, offset=offset)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/hospitality/reputation/{global_id}", response_model=HospitalityReputationSummary)
def hospitality_reputation_summary(global_id: int) -> HospitalityReputationSummary:
    try:
        return hospitality_reputation(global_id)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.post("/v1/hospitality/requests/{request_id}/incident", response_model=TrustIncident, status_code=201)
def hospitality_incident(
    request_id: UUID, payload: HospitalityIncidentCreate, authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustIncident:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        return create_hospitality_incident(actor, request_id, payload)
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.post("/internal/hospitality/tick", response_model=HospitalityTickResult)
def hospitality_internal_tick(
    internal_secret: str | None = Header(default=None, alias="X-Internal-Secret"),
) -> HospitalityTickResult:
    require_internal_secret(internal_secret)
    try:
        return hospitality_tick()
    except HospitalityError as exc:
        raise _hospitality_http_error(exc) from exc


@app.get("/v1/communities", response_model=list[Community])
def communities(
    city: str,
    kind: CommunityKind,
    locale: str = Query(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$"),
) -> list[Community]:
    return list_communities(city, kind, normalize_locale(locale))


@app.post("/v1/communities", response_model=Community, status_code=201)
def add_community(
    payload: CommunityCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> Community:
    require_owner(authenticated_global_id, payload.owner_global_id)
    return create_community(payload)


@app.get("/v1/communities/{community_id}/membership", response_model=CommunityMembershipStatus)
def read_community_membership(
    community_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CommunityMembershipStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return community_membership(community_id, authenticated_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.put("/v1/communities/{community_id}/membership", response_model=CommunityMembershipStatus)
def join_community(
    community_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CommunityMembershipStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return set_community_membership(community_id, authenticated_global_id, True)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.delete("/v1/communities/{community_id}/membership", response_model=CommunityMembershipStatus)
def leave_community(
    community_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CommunityMembershipStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return set_community_membership(community_id, authenticated_global_id, False)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/v1/search-requests", response_model=SearchRequestRecord, status_code=201)
def add_search_request(
    payload: SearchRequestCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> SearchRequestRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return create_search_request(authenticated_global_id, payload)


@app.get("/v1/search-requests", response_model=list[SearchRequestRecord])
def read_search_requests(
    include_archived: bool = False,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[SearchRequestRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return list_search_requests(authenticated_global_id, include_archived)


@app.get("/v1/search-requests/{request_id}", response_model=SearchRequestRecord)
def read_search_request(
    request_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> SearchRequestRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    result = get_search_request(authenticated_global_id, request_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Поисковый запрос не найден")
    return result


@app.put("/v1/search-requests/{request_id}", response_model=SearchRequestRecord)
def save_search_request(
    request_id: str,
    payload: SearchRequestUpdate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> SearchRequestRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    result = update_search_request(authenticated_global_id, request_id, payload)
    if result is None:
        raise HTTPException(status_code=404, detail="Поисковый запрос не найден")
    return result


@app.delete("/v1/search-requests/{request_id}", status_code=204)
def delete_search_request(
    request_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
):
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    if not archive_search_request(authenticated_global_id, request_id):
        raise HTTPException(status_code=404, detail="Поисковый запрос не найден")
    return Response(status_code=204)


@app.get("/v1/quality-fit/spec", response_model=QualityFitSpecResponse)
def read_quality_fit_spec() -> QualityFitSpecResponse:
    return quality_fit_spec_v2()


@app.get("/v1/quality-fit/catalog/{locale}", response_model=QualityFitCatalogResponse)
def read_quality_fit_catalog(locale: str) -> QualityFitCatalogResponse:
    return quality_fit_catalog_v2(locale)


@app.post("/v1/quality-fit/evaluations", response_model=QualityFitEvaluationRecord)
def evaluate_quality_fit(
    payload: QualityFitEvaluationRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> QualityFitEvaluationRecord:
    require_owner(authenticated_global_id, payload.searcher_global_id)
    requirements = payload.requirements
    if payload.search_request_id is not None and not requirements:
        request = get_search_request(payload.searcher_global_id, str(payload.search_request_id))
        if request is None:
            raise HTTPException(status_code=404, detail="search request not found")
        requirements = request.requirements or requirements_from_legacy(request.desired_qualities)
    from datetime import datetime, timezone
    row = build_quality_fit_evaluation(
        payload, assessment_results_for_user(payload.candidate_global_id),
        requirements=requirements, created_at=datetime.now(timezone.utc),
    )
    return save_quality_fit_evaluation(row) if payload.persist_history else row


@app.get("/v1/quality-fit/evaluations/{global_id}", response_model=list[QualityFitEvaluationRecord])
def read_quality_fit_history(
    global_id: int, authenticated_global_id: int | None = Depends(session_global_id),
) -> list[QualityFitEvaluationRecord]:
    require_owner(authenticated_global_id, global_id)
    return quality_fit_evaluation_history(global_id)


@app.get("/v1/quality-fit/evaluations/{global_id}/{evaluation_id}", response_model=QualityFitEvaluationRecord)
def read_quality_fit_evaluation(
    global_id: int, evaluation_id: UUID, authenticated_global_id: int | None = Depends(session_global_id),
) -> QualityFitEvaluationRecord:
    require_owner(authenticated_global_id, global_id)
    row = get_quality_fit_evaluation(global_id, evaluation_id)
    if row is None:
        raise HTTPException(status_code=404, detail="quality fit evaluation not found")
    return row


@app.post("/v1/trust/incidents", response_model=TrustIncident, status_code=201)
def add_incident(
    payload: TrustIncidentCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustIncident:
    require_owner(authenticated_global_id, payload.reporter_global_id)
    if payload.reporter_global_id == payload.subject_global_id:
        raise HTTPException(status_code=400, detail="Нельзя подать жалобу на самого себя")
    return create_incident(payload)


@app.post("/v1/trust/incidents/{incident_id}/moderate", response_model=TrustIncident)
def moderate(
    incident_id: str,
    confirmed: bool,
    internal_secret: str | None = Header(default=None, alias="X-Internal-Secret"),
) -> TrustIncident:
    # Compatibility endpoint retained, but moderation is privileged: production must never expose
    # a user-callable path that can confirm an allegation or mutate Trust evidence.
    require_internal_secret(internal_secret)
    incident = moderate_incident(incident_id, confirmed)
    if incident is None:
        raise HTTPException(status_code=404, detail="Инцидент не найден")
    return incident


@app.post("/v1/trust/incidents/{incident_id}/appeals", response_model=TrustAppealRecord, status_code=201)
def appeal_trust_incident(
    incident_id: str, payload: TrustAppealCreate, authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustAppealRecord:
    actor = _hospitality_actor(authenticated_global_id)
    try:
        result = create_appeal(incident_id, actor, payload.grounds)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    if result is None:
        raise HTTPException(status_code=404, detail="Инцидент не найден")
    return result


@app.post("/internal/trust/incidents/{incident_id}/decision", response_model=TrustModerationResult)
def internal_trust_decision(
    incident_id: str, payload: TrustModerationDecisionCreate,
    internal_secret: str | None = Header(default=None, alias="X-Internal-Secret"),
) -> TrustModerationResult:
    require_internal_secret(internal_secret)
    result = moderate_incident_with_decision(incident_id, payload.moderator_global_id, payload.confirmed, payload.rationale)
    if result is None:
        raise HTTPException(status_code=404, detail="Инцидент не найден")
    incident, decision = result
    restriction = None
    if payload.hospitality_restriction_scope is not None:
        if not payload.confirmed:
            raise HTTPException(status_code=409, detail="Hospitality restriction requires a confirmed moderation decision")
        reason = payload.hospitality_restriction_reason_code or "CONFIRMED_HOSPITALITY_INCIDENT"
        try:
            restriction = apply_hospitality_restriction_from_confirmed_incident(
                incident_id, payload.hospitality_restriction_scope, reason, payload.hospitality_restriction_ends_at
            )
        except HospitalityError as exc:
            raise _hospitality_http_error(exc) from exc
    return TrustModerationResult(incident=incident, decision=decision, hospitality_restriction=restriction)


@app.get("/v1/trust/{global_id}", response_model=TrustSummary)
def get_trust(global_id: int) -> TrustSummary:
    return trust_summary(global_id)


@app.put("/v1/profiles/{global_id}", response_model=ProfileRecord)
def save_profile(
    global_id: int,
    payload: ProfileUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileRecord:
    require_owner(authenticated_global_id, global_id)
    if global_id < 1 or global_id > 9_999_999_999:
        raise HTTPException(status_code=400, detail="Некорректный global_id")
    return upsert_profile(global_id, payload)


@app.put("/v1/profiles/{global_id}/avatar", response_model=ProfileAvatarRecord)
def save_profile_avatar(
    global_id: int,
    payload: ProfileAvatarUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileAvatarRecord:
    require_owner(authenticated_global_id, global_id)
    try:
        return upsert_profile_avatar(global_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/v1/profiles/{global_id}", response_model=ProfileRecord)
def read_profile(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileRecord:
    require_owner(authenticated_global_id, global_id)
    profile = get_profile(global_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="Профиль не найден")
    return profile


@app.put("/v1/personality-profile/{global_id}", response_model=PersonalityProfileRecord)
def save_personality_profile(
    global_id: int,
    payload: PersonalityProfileUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PersonalityProfileRecord:
    require_owner(authenticated_global_id, global_id)
    return upsert_personality_profile(global_id, payload)


@app.get("/v1/personality-profile/{global_id}", response_model=PersonalityProfileRecord)
def read_personality_profile(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PersonalityProfileRecord:
    require_owner(authenticated_global_id, global_id)
    profile = get_personality_profile(global_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="Профиль личности не найден")
    return profile


def _assessment_receipt(item: AssessmentResultRecord, *, is_retake: bool = False) -> AssessmentPublicReceipt:
    traits = {row.id: row.score for row in item.dimensions}
    qualities = positive_projection(traits, item.instrument_locale, limit=3)
    locale = normalize_locale(item.instrument_locale)
    titles = {
        "ru": "Профиль стал точнее",
        "uk": "Профіль став точнішим",
        "en": "Your profile is more precise",
    }
    summaries = {
        "ru": "Результат научного теста сохранён и используется для психологического профиля и совместимости.",
        "uk": "Результат наукового тесту збережено й використовується для психологічного профілю та сумісності.",
        "en": "The scientific test result is stored and used for the psychological profile and compatibility.",
    }
    return AssessmentPublicReceipt(
        id=item.id,
        global_id=item.global_id,
        assessment_id=item.assessment_id,
        model_version=item.scoring_version,
        completed_at_epoch_ms=item.completed_at_epoch_ms,
        positive_qualities=qualities,
        status="profile_refined" if is_retake else "positive_discovery_saved",
        result_title=(
            {"ru": "Профиль уточнён", "uk": "Профіль уточнено", "en": "Your profile has been refined"}.get(locale, "Your profile has been refined")
            if is_retake else titles.get(locale, titles["en"])
        ),
        result_summary=summaries.get(locale, summaries["en"]),
        account_delta_percent=0.0 if is_retake else (50.0 / 7.0),
    )



@app.put("/v1/calibration-consent", response_model=CalibrationConsentRecord)
def set_calibration_consent(
    payload: CalibrationConsentUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CalibrationConsentRecord:
    require_owner(authenticated_global_id, payload.global_id)
    try:
        return upsert_calibration_consent(payload)
    except PilotEnrollmentError as exc:
        raise HTTPException(status_code=exc.http_status, detail={"code": exc.code, "message": str(exc)}) from exc


@app.get("/v1/calibration-pilot/status", response_model=CalibrationPilotStatus)
def get_calibration_pilot_status() -> CalibrationPilotStatus:
    # Aggregate capacity only; no participant identifiers, invite hashes or raw traces are exposed.
    return calibration_pilot_status()


@app.get("/v1/calibration-consent/{global_id}", response_model=CalibrationConsentRecord | None)
def get_calibration_consent(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CalibrationConsentRecord | None:
    require_owner(authenticated_global_id, global_id)
    return calibration_consent_for_user(global_id)

@app.get("/v1/test-apps", response_model=list[TestAppCatalogItem])
def read_test_app_catalog() -> list[TestAppCatalogItem]:
    return [TestAppCatalogItem(**row) for row in test_app_catalog()]


@app.get("/v1/test-apps/{app_id}", response_model=TestAppDefinitionPublic)
def read_test_app_definition(app_id: str) -> TestAppDefinitionPublic:
    if app_id not in TEST_APPS:
        raise HTTPException(status_code=404, detail="test app not found")
    return TestAppDefinitionPublic(**test_app_definition(app_id))


@app.post("/v1/test-apps/{app_id}/sessions", response_model=TestAdministrationSessionPublic)
def start_test_app_session(
    app_id: str,
    payload: TestAdministrationStart,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TestAdministrationSessionPublic:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    if authenticated_global_id != payload.global_id:
        raise HTTPException(status_code=403, detail="global_id does not belong to authenticated session")
    try:
        record = start_or_resume_test_session(
            global_id=payload.global_id, app_id=app_id, instrument_locale=payload.instrument_locale
        )
    except TestAdministrationError as exc:
        raise HTTPException(status_code=exc.http_status, detail={"code": exc.code, "message": str(exc)}) from exc
    return public_test_session(record)


@app.get("/v1/test-app-sessions/{session_id}", response_model=TestAdministrationSessionPublic)
def read_test_app_session(
    session_id: UUID,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TestAdministrationSessionPublic:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return public_test_session(owned_test_session(session_id=session_id, global_id=authenticated_global_id))
    except TestAdministrationError as exc:
        raise HTTPException(status_code=exc.http_status, detail={"code": exc.code, "message": str(exc)}) from exc


@app.post("/v1/test-app-sessions/{session_id}/answers", response_model=TestAdministrationSessionPublic)
def answer_test_app_session(
    session_id: UUID,
    payload: TestAdministrationAnswerSubmit,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TestAdministrationSessionPublic:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        record = owned_test_session(session_id=session_id, global_id=authenticated_global_id)
        record = submit_test_session_answer(record=record, payload=payload)
        if record.current_index == len(record.item_order):
            row = score_test_app(
                global_id=record.global_id,
                app_id=record.app_id,
                responses=record.responses,
                instrument_locale=record.instrument_locale,
                started_at_epoch_ms=record.started_at_epoch_ms,
                completed_at_epoch_ms=record.updated_at_epoch_ms,
            )
            saved = upsert_assessment_result(row)
            record = mark_test_session_completed(
                record, result_id=saved.id, completed_at_epoch_ms=record.updated_at_epoch_ms
            )
        return public_test_session(record)
    except TestAdministrationError as exc:
        raise HTTPException(status_code=exc.http_status, detail={"code": exc.code, "message": str(exc)}) from exc


@app.post("/v1/test-apps/{app_id}/score", response_model=AssessmentPublicReceipt, deprecated=True)
def score_test_app_route(
    app_id: str,
    payload: ScientificAssessmentSubmit,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssessmentPublicReceipt:
    raise HTTPException(status_code=410, detail={"code": "DIRECT_SCORING_DISABLED", "message": "Use secure test administration sessions."})


@app.get("/v1/scientific-assessments", response_model=list[ScientificAssessmentCatalogItem])
def read_scientific_assessment_catalog() -> list[ScientificAssessmentCatalogItem]:
    return [ScientificAssessmentCatalogItem(**row) for row in scientific_assessment_catalog()]


@app.get("/v1/scientific-assessments/{system_id}", response_model=ScientificAssessmentDefinitionPublic)
def read_scientific_assessment_definition(system_id: str) -> ScientificAssessmentDefinitionPublic:
    if system_id not in SCIENTIFIC_ASSESSMENT_SYSTEMS:
        raise HTTPException(status_code=404, detail="scientific assessment system not found")
    return ScientificAssessmentDefinitionPublic(**scientific_assessment_definition(system_id))


@app.post("/v1/scientific-assessments/{system_id}/score", response_model=AssessmentPublicReceipt, deprecated=True)
def score_scientific_assessment_route(
    system_id: str,
    payload: ScientificAssessmentSubmit,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssessmentPublicReceipt:
    raise HTTPException(status_code=410, detail={"code": "DIRECT_SCORING_DISABLED", "message": "Scientific scoring is available only through secure product test administration sessions."})


@app.put("/v1/assessment-results", response_model=AssessmentPublicReceipt, deprecated=True)
def save_assessment_result(
    payload: AssessmentResultUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssessmentPublicReceipt:
    raise HTTPException(status_code=410, detail={"code": "CLIENT_RESULT_WRITE_DISABLED", "message": "Assessment results are server-authoritative and cannot be written by clients."})




@app.get("/v1/test-app-results/{global_id}/{result_id}/feedback", response_model=TestResultFeedbackPublic)
def read_test_app_result_feedback(
    global_id: int,
    result_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TestResultFeedbackPublic:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    if authenticated_global_id != global_id:
        raise HTTPException(status_code=403, detail="global_id does not belong to authenticated session")
    row = next((item for item in assessment_results_for_user(global_id) if item.id == result_id), None)
    if row is None:
        raise HTTPException(status_code=404, detail="test result not found")
    if row.assessment_id not in TEST_APPS:
        raise HTTPException(status_code=404, detail="test result does not belong to a product test app")
    return TestResultFeedbackPublic(**build_test_result_feedback(row))

@app.get("/v1/assessment-results/{global_id}", response_model=list[AssessmentPublicReceipt])
def get_assessment_results(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[AssessmentPublicReceipt]:
    require_owner(authenticated_global_id, global_id)
    return [_assessment_receipt(item) for item in assessment_results_for_user(global_id)]


@app.get("/internal/assessment-results/{global_id}", response_model=list[AssessmentResultRecord])
def get_internal_assessment_results(
    global_id: int,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> list[AssessmentResultRecord]:
    require_internal_secret(internal_auth)
    return assessment_results_for_user(global_id)


@app.put("/internal/friendship-outcomes", response_model=FriendshipOutcomeRecord)
def save_friendship_outcome(
    payload: FriendshipOutcomeUpsert,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> FriendshipOutcomeRecord:
    require_internal_secret(internal_auth)
    try:
        return upsert_friendship_outcome(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/internal/friendship-outcomes", response_model=list[FriendshipOutcomeRecord])
def export_friendship_outcomes(
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> list[FriendshipOutcomeRecord]:
    require_internal_secret(internal_auth)
    return friendship_outcomes_for_analysis()



@app.get("/v1/numerology/spec", response_model=NumerologySpecResponse)
def read_numerology_spec() -> NumerologySpecResponse:
    return numerology_public_spec()


@app.get("/v1/numerology/catalog/{locale}", response_model=NumerologyCatalogIndex)
def read_numerology_catalog(locale: str) -> NumerologyCatalogIndex:
    return numerology_catalog_index(locale)


@app.get("/v1/numerology/catalog/{locale}/{group_id}/{key}", response_model=NumerologyCatalogEntry)
def read_numerology_catalog_entry(locale: str, group_id: str, key: str) -> NumerologyCatalogEntry:
    row = numerology_catalog_entry(locale, group_id, key)
    if row is None:
        raise HTTPException(status_code=404, detail="numerology catalog entry not found")
    return row


@app.post("/v1/numerology/readings", response_model=NumerologyReadingRecord)
def create_numerology_reading(
    payload: NumerologyReadingCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> NumerologyReadingRecord:
    require_owner(authenticated_global_id, payload.global_id)
    from datetime import datetime, timezone
    record = build_numerology_reading(payload, created_at=datetime.now(timezone.utc))
    return save_numerology_reading(record)


@app.get("/v1/numerology/readings/{global_id}", response_model=list[NumerologyReadingRecord])
def read_numerology_history(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[NumerologyReadingRecord]:
    require_owner(authenticated_global_id, global_id)
    return numerology_readings_for_user(global_id)


@app.get("/v1/numerology/readings/{global_id}/latest", response_model=NumerologyReadingRecord)
def read_latest_numerology_reading(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> NumerologyReadingRecord:
    require_owner(authenticated_global_id, global_id)
    row = latest_numerology_reading(global_id)
    if row is None:
        raise HTTPException(status_code=404, detail="numerology reading not found")
    return row


@app.get("/v1/numerology/readings/{global_id}/{reading_id}", response_model=NumerologyReadingRecord)
def read_numerology_reading(
    global_id: int,
    reading_id: UUID,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> NumerologyReadingRecord:
    require_owner(authenticated_global_id, global_id)
    row = get_numerology_reading(global_id, reading_id)
    if row is None:
        raise HTTPException(status_code=404, detail="numerology reading not found")
    return row


def _numerology_pair_input(global_id: int) -> tuple[int, int] | None:
    latest = latest_numerology_reading(global_id)
    if latest is not None:
        return latest.date_soul_number, latest.date_destiny_number
    personality = get_personality_profile(global_id)
    if personality is not None:
        data = personality.vedic_numerology or {}
        soul = data.get("soul_number", data.get("soulNumber"))
        destiny = data.get("destiny_number", data.get("destinyNumber"))
        if isinstance(soul, int) and isinstance(destiny, int) and 1 <= soul <= 9 and 1 <= destiny <= 9:
            return soul, destiny
    profile = get_profile(global_id)
    if profile is not None:
        soul, destiny, _ = vedic_date_numbers(profile.birth_date)
        return soul, destiny
    return None


@app.post("/v1/numerology/compatibility", response_model=NumerologyCompatibilityRecord)
def compare_numerology(
    payload: NumerologyCompatibilityRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> NumerologyCompatibilityRecord:
    require_owner(authenticated_global_id, payload.first_global_id)
    first = _numerology_pair_input(payload.first_global_id)
    second = _numerology_pair_input(payload.second_global_id)
    if first is None or second is None:
        raise HTTPException(status_code=409, detail="numerology compatibility requires birth-date-derived inputs for both users")
    from datetime import datetime, timezone
    row = build_numerology_compatibility(
        payload.first_global_id, payload.second_global_id, first, second, created_at=datetime.now(timezone.utc)
    )
    return save_numerology_comparison(row) if payload.persist_history else row


@app.get("/v1/numerology/compatibility/{global_id}/history", response_model=list[NumerologyCompatibilityRecord])
def read_numerology_comparison_history(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[NumerologyCompatibilityRecord]:
    require_owner(authenticated_global_id, global_id)
    return numerology_comparison_history(global_id)


@app.get("/v1/zodiac/spec", response_model=ZodiacSpecResponse)
def read_zodiac_spec() -> ZodiacSpecResponse:
    return zodiac_public_spec()


@app.get("/v1/zodiac/catalog/{locale}", response_model=ZodiacCatalogIndex)
def read_zodiac_catalog(locale: str) -> ZodiacCatalogIndex:
    return zodiac_catalog_index(locale)


@app.get("/v1/zodiac/catalog/{locale}/{sign_id}", response_model=ZodiacSignDetail)
def read_zodiac_catalog_entry(locale: str, sign_id: str) -> ZodiacSignDetail:
    row = zodiac_sign_detail(sign_id, locale)
    if row is None:
        raise HTTPException(status_code=404, detail="zodiac sign not found")
    return row


@app.post("/v1/zodiac/readings", response_model=ZodiacReadingRecord)
def create_zodiac_reading(
    payload: ZodiacReadingCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ZodiacReadingRecord:
    require_owner(authenticated_global_id, payload.global_id)
    from datetime import datetime, timezone
    record = build_zodiac_reading(payload, created_at=datetime.now(timezone.utc))
    return save_zodiac_reading(record)


@app.get("/v1/zodiac/readings/{global_id}", response_model=list[ZodiacReadingRecord])
def read_zodiac_history(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ZodiacReadingRecord]:
    require_owner(authenticated_global_id, global_id)
    return zodiac_readings_for_user(global_id)


@app.get("/v1/zodiac/readings/{global_id}/latest", response_model=ZodiacReadingRecord)
def read_latest_zodiac_reading(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ZodiacReadingRecord:
    require_owner(authenticated_global_id, global_id)
    row = latest_zodiac_reading(global_id)
    if row is None:
        raise HTTPException(status_code=404, detail="zodiac reading not found")
    return row


@app.get("/v1/zodiac/readings/{global_id}/{reading_id}", response_model=ZodiacReadingRecord)
def read_zodiac_reading(
    global_id: int,
    reading_id: UUID,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ZodiacReadingRecord:
    require_owner(authenticated_global_id, global_id)
    row = get_zodiac_reading(global_id, reading_id)
    if row is None:
        raise HTTPException(status_code=404, detail="zodiac reading not found")
    return row


def _zodiac_pair_input(global_id: int) -> str | None:
    latest = latest_zodiac_reading(global_id)
    if latest is not None:
        return latest.sign.sign_id
    personality = get_personality_profile(global_id)
    if personality is not None and personality.zodiac_sign:
        candidate = str(personality.zodiac_sign).upper()
        if zodiac_sign_detail(candidate, "en") is not None:
            return candidate
    profile = get_profile(global_id)
    if profile is not None:
        return zodiac_sign_for_date(profile.birth_date)
    return None


@app.post("/v1/zodiac/compatibility", response_model=ZodiacCompatibilityRecord)
def compare_zodiac(
    payload: ZodiacCompatibilityRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ZodiacCompatibilityRecord:
    require_owner(authenticated_global_id, payload.first_global_id)
    first = _zodiac_pair_input(payload.first_global_id)
    second = _zodiac_pair_input(payload.second_global_id)
    if first is None or second is None:
        raise HTTPException(status_code=409, detail="zodiac compatibility requires birth-date-derived Zodiac inputs for both users")
    from datetime import datetime, timezone
    row = build_zodiac_compatibility(
        payload.first_global_id, payload.second_global_id, first, second,
        locale=payload.locale, created_at=datetime.now(timezone.utc),
    )
    return save_zodiac_comparison(row) if payload.persist_history else row


@app.get("/v1/zodiac/compatibility/{global_id}/history", response_model=list[ZodiacCompatibilityRecord])
def read_zodiac_comparison_history(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ZodiacCompatibilityRecord]:
    require_owner(authenticated_global_id, global_id)
    return zodiac_comparison_history(global_id)


def _enneagram_pair_input(global_id: int) -> tuple[int, int] | None:
    latest = latest_enneagram_reading(global_id)
    if latest is not None:
        return latest.type_id, latest.wing
    profile = get_personality_profile(global_id)
    if profile is None or profile.enneagram_type is None or profile.enneagram_wing is None:
        return None
    return profile.enneagram_type, profile.enneagram_wing


@app.get("/v1/enneagram/spec", response_model=EnneagramSpecResponse)
def read_enneagram_spec() -> EnneagramSpecResponse:
    return enneagram_public_spec()


@app.get("/v1/enneagram/instrument", response_model=EnneagramInstrumentResponse)
def read_enneagram_instrument() -> EnneagramInstrumentResponse:
    return enneagram_public_instrument()


@app.get("/v1/enneagram/types/{locale}", response_model=EnneagramTypeCatalog)
def read_enneagram_type_catalog(locale: str) -> EnneagramTypeCatalog:
    return enneagram_type_catalog(locale)


@app.get("/v1/enneagram/types/{locale}/{type_id}", response_model=EnneagramTypeDetail)
def read_enneagram_type_detail(locale: str, type_id: int) -> EnneagramTypeDetail:
    row = enneagram_type_detail(type_id, locale)
    if row is None:
        raise HTTPException(status_code=404, detail="enneagram type not found")
    return row


@app.post("/v1/enneagram/readings", response_model=EnneagramReadingRecord)
def create_enneagram_reading(
    payload: EnneagramReadingCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> EnneagramReadingRecord:
    require_owner(authenticated_global_id, payload.global_id)
    from datetime import datetime, timezone
    try:
        row = build_enneagram_reading(payload, created_at=datetime.now(timezone.utc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    saved = save_enneagram_reading(row)
    current = get_personality_profile(payload.global_id)
    if current is not None:
        upsert_personality_profile(
            payload.global_id,
            PersonalityProfileUpsert(
                brotherhood32_code=current.brotherhood32_code,
                brotherhood32_scores=current.brotherhood32_scores,
                enneagram_type=saved.type_id,
                enneagram_wing=saved.wing,
                zodiac_sign=current.zodiac_sign,
                vedic_numerology=current.vedic_numerology,
            )
        )
    return saved


@app.get("/v1/enneagram/readings/{global_id}", response_model=list[EnneagramReadingRecord])
def read_enneagram_history(
    global_id: int, authenticated_global_id: int | None = Depends(session_global_id),
) -> list[EnneagramReadingRecord]:
    require_owner(authenticated_global_id, global_id)
    return enneagram_readings_for_user(global_id)


@app.get("/v1/enneagram/readings/{global_id}/latest", response_model=EnneagramReadingRecord | None)
def read_latest_enneagram_reading(
    global_id: int, authenticated_global_id: int | None = Depends(session_global_id),
) -> EnneagramReadingRecord | None:
    require_owner(authenticated_global_id, global_id)
    return latest_enneagram_reading(global_id)


@app.get("/v1/enneagram/readings/{global_id}/{reading_id}", response_model=EnneagramReadingRecord)
def read_enneagram_reading(
    global_id: int, reading_id: UUID, authenticated_global_id: int | None = Depends(session_global_id),
) -> EnneagramReadingRecord:
    require_owner(authenticated_global_id, global_id)
    row = get_enneagram_reading(global_id, reading_id)
    if row is None:
        raise HTTPException(status_code=404, detail="enneagram reading not found")
    return row


@app.post("/v1/enneagram/compatibility", response_model=EnneagramCompatibilityRecord)
def compare_enneagram(
    payload: EnneagramCompatibilityRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> EnneagramCompatibilityRecord:
    require_owner(authenticated_global_id, payload.first_global_id)
    first = _enneagram_pair_input(payload.first_global_id)
    second = _enneagram_pair_input(payload.second_global_id)
    if first is None or second is None:
        raise HTTPException(status_code=409, detail="enneagram compatibility requires type/wing inputs for both users")
    from datetime import datetime, timezone
    row = build_enneagram_compatibility(
        payload.first_global_id, payload.second_global_id, first[0], first[1], second[0], second[1],
        locale=payload.locale, created_at=datetime.now(timezone.utc),
    )
    return save_enneagram_comparison(row) if payload.persist_history else row


@app.get("/v1/enneagram/compatibility/{global_id}/history", response_model=list[EnneagramCompatibilityRecord])
def read_enneagram_comparison_history(
    global_id: int, authenticated_global_id: int | None = Depends(session_global_id),
) -> list[EnneagramCompatibilityRecord]:
    require_owner(authenticated_global_id, global_id)
    return enneagram_comparison_history(global_id)


@app.get("/v1/associative-instruments", response_model=list[AssociativeInstrumentCatalogItem])
def read_associative_instrument_catalog() -> list[AssociativeInstrumentCatalogItem]:
    return [AssociativeInstrumentCatalogItem(**row) for row in associative_catalog()]


@app.get("/v1/associative-instruments/{method_id}", response_model=AssociativeInstrumentDefinitionPublic)
def read_associative_instrument_definition(method_id: str) -> AssociativeInstrumentDefinitionPublic:
    if method_id not in ASSOCIATIVE_INSTRUMENTS:
        raise HTTPException(status_code=404, detail="associative instrument not found")
    return AssociativeInstrumentDefinitionPublic(**associative_definition(method_id))


@app.post("/v1/associative-instruments/{method_id}/score", response_model=AssociativeMeasurementResultPublic)
def score_associative_instrument(
    method_id: str,
    payload: AssociativeMeasurementSubmit,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssociativeMeasurementResultPublic:
    require_owner(authenticated_global_id, payload.global_id)
    if method_id not in ASSOCIATIVE_INSTRUMENTS:
        raise HTTPException(status_code=404, detail="associative instrument not found")
    try:
        row=score_associative_measurement(
            global_id=payload.global_id,method_id=method_id,events=payload.events,
            instrument_locale=payload.instrument_locale,started_at_epoch_ms=payload.started_at_epoch_ms,
            completed_at_epoch_ms=payload.completed_at_epoch_ms,
        )
    except (ValueError,KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return upsert_associative_result(row)


@app.get("/v1/associative-results/{global_id}", response_model=list[AssociativeMeasurementResultPublic])
def read_associative_results(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[AssociativeMeasurementResultPublic]:
    require_owner(authenticated_global_id, global_id)
    return associative_results_for_user(global_id)


@app.post("/v1/associative-compatibility", response_model=AssociativeCompatibilityResponse)
def read_associative_compatibility(
    payload: AssociativeCompatibilityRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssociativeCompatibilityResponse:
    require_owner(authenticated_global_id, payload.first_global_id)
    if payload.first_global_id == payload.second_global_id:
        raise HTTPException(status_code=400, detail="associative compatibility requires two different users")
    if payload.method_id not in ASSOCIATIVE_INSTRUMENTS:
        raise HTTPException(status_code=404, detail="associative instrument not found")
    left=latest_associative_result(payload.first_global_id,payload.method_id)
    right=latest_associative_result(payload.second_global_id,payload.method_id)
    if left is None or right is None:
        return AssociativeCompatibilityResponse(method_id=payload.method_id,score=None,coverage=0,feature_scores={})
    return AssociativeCompatibilityResponse(**associative_method_compatibility(payload.method_id,left.public_features,right.public_features))


@app.get("/internal/associative-results/{result_id}/raw")
def read_internal_associative_raw_result(
    result_id: str,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> dict[str, object]:
    require_internal_secret(internal_auth)
    rows=associative_raw_result(result_id)
    if rows is None:
        raise HTTPException(status_code=404, detail="associative result not found")
    return {"result_id":result_id,"raw_events":rows}


@app.put("/internal/research/friendship-pattern-observations", response_model=FriendshipPatternObservationRecord)
def save_friendship_pattern_observation(
    payload: FriendshipPatternObservationUpsert,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> FriendshipPatternObservationRecord:
    require_internal_secret(internal_auth)
    return upsert_friendship_pattern_observation(payload)


@app.get("/internal/research/friendship-pattern-observations", response_model=list[FriendshipPatternObservationRecord])
def export_friendship_pattern_observations(
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> list[FriendshipPatternObservationRecord]:
    require_internal_secret(internal_auth)
    return friendship_pattern_observations_for_analysis()


@app.get("/internal/research/friendship-pattern-analysis", response_model=FriendshipPatternAnalysisResponse)
def read_friendship_pattern_analysis(
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> FriendshipPatternAnalysisResponse:
    require_internal_secret(internal_auth)
    return analyze_friendship_patterns(friendship_pattern_observations_for_analysis())


@app.post("/v1/account-rating", response_model=AccountRatingResponse)
def calculate_account_rating(payload: AccountRatingRequest) -> AccountRatingResponse:
    return account_rating(payload)


@app.get("/v1/psychological-test-systems", response_model=list[PsychologicalTestSystemDefinition])
def read_psychological_test_system_catalog() -> list[PsychologicalTestSystemDefinition]:
    return [PsychologicalTestSystemDefinition(**row) for row in psychological_test_system_catalog()]


@app.get("/v1/psychological-test-systems/{global_id}", response_model=list[PsychologicalTestSystemResult])
def read_psychological_test_system_results(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[PsychologicalTestSystemResult]:
    require_owner(authenticated_global_id, global_id)
    return [PsychologicalTestSystemResult(**row) for row in psychological_test_system_results(assessment_results_for_user(global_id))]


@app.get("/v1/psychological-test-systems/{global_id}/{system_id}", response_model=PsychologicalTestSystemResult)
def read_psychological_test_system_result(
    global_id: int,
    system_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PsychologicalTestSystemResult:
    require_owner(authenticated_global_id, global_id)
    spec = PSYCHOLOGICAL_TEST_SYSTEMS_BY_ID.get(system_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="Неизвестная психологическая тестовая система")
    row = next(item for item in psychological_test_system_results(assessment_results_for_user(global_id)) if item["system_id"] == system_id)
    return PsychologicalTestSystemResult(**row)


@app.get("/v1/psychological-test-systems/compatibility/{requester_global_id}/{candidate_global_id}", response_model=list[PsychologicalTestSystemCompatibility])
def read_psychological_test_system_compatibility(
    requester_global_id: int,
    candidate_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[PsychologicalTestSystemCompatibility]:
    require_owner(authenticated_global_id, requester_global_id)
    if requester_global_id == candidate_global_id:
        raise HTTPException(status_code=400, detail="compatibility requires two different users")
    left = assessment_results_for_user(requester_global_id)
    right = assessment_results_for_user(candidate_global_id)
    return [PsychologicalTestSystemCompatibility(**psychological_test_system_compatibility(spec, left, right)) for spec in PSYCHOLOGICAL_TEST_SYSTEMS_BY_ID.values()]


@app.put("/v1/psychological-reports", response_model=PsychologicalReportRecord)
def save_psychological_report(
    payload: PsychologicalReportUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PsychologicalReportRecord:
    require_owner(authenticated_global_id, payload.global_id)
    stored = {item.id: item for item in assessment_results_for_user(payload.global_id)}
    for snapshot in payload.input_snapshot:
        source = stored.get(snapshot.result_id)
        if source is None or source.assessment_id != snapshot.assessment_id or source.scoring_version != snapshot.scoring_version:
            raise HTTPException(status_code=409, detail="psychological report input snapshot does not match stored assessment results")
        expected = [row.model_dump() for row in source.dimensions]
        actual = [row.model_dump() for row in snapshot.dimensions]
        if source.total_score != snapshot.total_score or source.answer_consistency != snapshot.answer_consistency or expected != actual:
            raise HTTPException(status_code=409, detail="psychological report input snapshot differs from stored assessment scores")
    return upsert_psychological_report(payload)


@app.get("/v1/psychological-reports/{global_id}/latest", response_model=PsychologicalReportRecord)
def read_latest_psychological_report(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PsychologicalReportRecord:
    require_owner(authenticated_global_id, global_id)
    report = latest_psychological_report(global_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Психологический отчёт не найден")
    return report


@app.get("/v1/psychological-reports/{global_id}/history", response_model=list[PsychologicalReportHistoryItem])
def read_psychological_report_history(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[PsychologicalReportHistoryItem]:
    require_owner(authenticated_global_id, global_id)
    return psychological_report_history(global_id)


@app.get("/v1/psychological-reports/{global_id}/{report_id}", response_model=PsychologicalReportRecord)
def read_psychological_report(
    global_id: int,
    report_id: UUID,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PsychologicalReportRecord:
    require_owner(authenticated_global_id, global_id)
    report = get_psychological_report(global_id, report_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Психологический отчёт не найден")
    return report


@app.put("/v1/compatibility/preferences", response_model=CompatibilityMetricPreferencesRecord)
def save_compatibility_preferences(
    payload: CompatibilityMetricPreferencesUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CompatibilityMetricPreferencesRecord:
    require_owner(authenticated_global_id, payload.global_id)
    return upsert_compatibility_metric_preferences(payload)


@app.get("/v1/compatibility/preferences/{global_id}", response_model=CompatibilityMetricPreferencesRecord)
def read_compatibility_preferences(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CompatibilityMetricPreferencesRecord:
    require_owner(authenticated_global_id, global_id)
    record = get_compatibility_metric_preferences(global_id)
    if record is None:
        record = upsert_compatibility_metric_preferences(CompatibilityMetricPreferencesUpsert(
            global_id=global_id, selected_metrics=CANONICAL_METRIC_ORDER
        ))
    return record


@app.post("/v1/compatibility/independent", response_model=IndependentCompatibilityResponse)
def calculate_independent_server_compatibility(
    payload: IndependentCompatibilityRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> IndependentCompatibilityResponse:
    require_owner(authenticated_global_id, payload.requester_global_id)
    if has_user_block(payload.requester_global_id, payload.candidate_global_id):
        raise HTTPException(status_code=403, detail="Compatibility недоступна для заблокированной пары")
    requester_profile = get_profile(payload.requester_global_id)
    candidate_profile = get_profile(payload.candidate_global_id)
    if candidate_profile is not None and candidate_profile.visibility != "discoverable":
        raise HTTPException(status_code=403, detail="Профиль кандидата недоступен для расчёта Compatibility")
    preference = get_compatibility_metric_preferences(payload.requester_global_id)
    selected = payload.selected_metrics or (preference.selected_metrics if preference else CANONICAL_METRIC_ORDER)
    response = calculate_independent_compatibility(
        requester_global_id=payload.requester_global_id,
        candidate_global_id=payload.candidate_global_id,
        requester_profile=requester_profile,
        candidate_profile=candidate_profile,
        requester_personality=get_personality_profile(payload.requester_global_id),
        candidate_personality=get_personality_profile(payload.candidate_global_id),
        requester_assessments=assessment_results_for_user(payload.requester_global_id),
        candidate_assessments=assessment_results_for_user(payload.candidate_global_id),
        selected_metrics=selected,
    )
    return response.model_copy(update={"trust_score": trust_summary(payload.candidate_global_id).score})


@app.post("/v1/compatibility", response_model=CompatibilityResponse)
def calculate_compatibility(payload: CompatibilityRequest) -> CompatibilityResponse:
    return compatibility(payload)


@app.post("/v1/messages", response_model=MessageRecord, status_code=201)
def send_message(
    payload: MessageCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> MessageRecord:
    require_owner(authenticated_global_id, payload.sender_global_id)
    if payload.sender_global_id == payload.recipient_global_id:
        raise HTTPException(status_code=400, detail="Нельзя отправить сообщение самому себе")
    return create_message(payload)


@app.get("/v1/messages/{global_id}", response_model=list[MessageRecord])
def list_messages(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[MessageRecord]:
    require_owner(authenticated_global_id, global_id)
    return messages_for_user(global_id)


# ---- Chat Core v0.5.9 -------------------------------------------------------------

@app.get("/v1/app/version", response_model=AppVersionManifest)
def app_version() -> AppVersionManifest:
    return app_version_manifest()


@app.put("/v1/e2ee/device-key", response_model=DeviceKeyRecord)
def register_device_key(
    payload: DeviceKeyUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> DeviceKeyRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return upsert_device_key(authenticated_global_id, payload)


@app.get("/v1/e2ee/device-keys/{global_id}", response_model=list[DeviceKeyRecord])
def read_device_keys(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[DeviceKeyRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return device_keys_for_user(global_id)


@app.post("/v1/conversations/direct", response_model=ConversationSummary, status_code=201)
def create_direct_chat(
    payload: DirectConversationCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ConversationSummary:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return open_direct_conversation(authenticated_global_id, payload.peer_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/v1/conversations/group", response_model=ConversationSummary, status_code=201)
def create_group_chat(
    payload: GroupConversationCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ConversationSummary:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return create_group_conversation(authenticated_global_id, payload)


@app.put("/v1/users/{subject_global_id}/block", response_model=UserBlockStatus)
def block_user(
    subject_global_id: int,
    payload: UserBlockRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> UserBlockStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        blocked = set_user_block(authenticated_global_id, subject_global_id, payload.blocked)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return UserBlockStatus(subject_global_id=subject_global_id, blocked=blocked)


@app.get("/v1/users/{subject_global_id}/block", response_model=UserBlockStatus)
def block_status(
    subject_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> UserBlockStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return UserBlockStatus(subject_global_id=subject_global_id, blocked=has_user_block(authenticated_global_id, subject_global_id))


@app.post("/v1/chat/report/{subject_global_id}", response_model=TrustIncident, status_code=201)
def report_chat_user(
    subject_global_id: int,
    payload: ChatReportCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustIncident:
    from datetime import date
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    if authenticated_global_id == subject_global_id:
        raise HTTPException(status_code=400, detail="Нельзя подать жалобу на самого себя")
    return create_incident(TrustIncidentCreate(
        reporter_global_id=authenticated_global_id,
        subject_global_id=subject_global_id,
        category=payload.category,
        occurred_at=date.today().isoformat(),
        description=payload.description,
        evidence_refs=payload.evidence_refs,
    ))


@app.put("/v1/push/token")
def register_push_token(
    payload: PushTokenUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> dict[str, bool]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return {"ok": upsert_push_token(authenticated_global_id, payload)}


@app.get("/v1/conversations", response_model=list[ConversationSummary])
def list_chat_conversations(
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationSummary]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return conversations_for_user(authenticated_global_id)


@app.get("/v1/conversations/{conversation_id}/members", response_model=list[ConversationMemberRecord])
def list_conversation_members(
    conversation_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationMemberRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return conversation_members(conversation_id, authenticated_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.put("/v1/conversations/{conversation_id}/members/{member_global_id}", response_model=list[ConversationMemberRecord])
def add_conversation_member(
    conversation_id: str,
    member_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationMemberRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return add_group_member(conversation_id, authenticated_global_id, member_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@app.delete("/v1/conversations/{conversation_id}/members/{member_global_id}", response_model=list[ConversationMemberRecord])
def remove_conversation_member(
    conversation_id: str,
    member_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationMemberRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return remove_group_member(conversation_id, authenticated_global_id, member_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@app.get("/v1/conversations/{conversation_id}/messages", response_model=list[ChatMessageRecord])
def list_chat_messages(
    conversation_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ChatMessageRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return chat_messages(conversation_id, authenticated_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/v1/conversations/{conversation_id}/messages", response_model=ChatMessageRecord, status_code=201)
def send_chat_message(
    conversation_id: str,
    payload: ChatMessageCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ChatMessageRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return create_chat_message(conversation_id, authenticated_global_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/v1/chat/attachments/{attachment_id}", response_model=AttachmentPayload)
def get_chat_attachment(
    attachment_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AttachmentPayload:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    payload = attachment_payload(attachment_id, authenticated_global_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="Вложение не найдено")
    return payload




@app.put("/v1/messages/{message_id}", response_model=ChatMessageRecord)
def edit_message(
    message_id: str,
    payload: ChatMessageEdit,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ChatMessageRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return edit_chat_message(message_id, authenticated_global_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.put("/v1/messages/{message_id}/reaction", response_model=list[MessageReactionRecord])
def react_to_message(
    message_id: str,
    payload: MessageReactionRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[MessageReactionRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return toggle_message_reaction(message_id, authenticated_global_id, payload.emoji)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.delete("/v1/messages/{message_id}", status_code=204)
def delete_message(
    message_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
):
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    if not delete_chat_message(message_id, authenticated_global_id):
        raise HTTPException(status_code=403, detail="Only the sender can delete this message")
    return None


@app.put("/v1/conversations/{conversation_id}/typing")
def update_typing(
    conversation_id: str,
    payload: TypingRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
):
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        set_typing(conversation_id, authenticated_global_id, payload.typing)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"ok": True}


@app.get("/v1/conversations/{conversation_id}/typing", response_model=TypingStatus)
def get_typing(
    conversation_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TypingStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return TypingStatus(global_ids=typing_users(conversation_id, authenticated_global_id))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.put("/v1/conversations/{conversation_id}/read")
def mark_conversation_read(
    conversation_id: str,
    payload: ReadReceiptRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> dict[str, bool]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    if not mark_chat_read(conversation_id, authenticated_global_id, payload.message_id):
        raise HTTPException(status_code=404, detail="Сообщение или чат не найден")
    return {"ok": True}

