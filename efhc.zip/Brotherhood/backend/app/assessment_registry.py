# Active Brotherhood scientific assessment registry.
# 12 user-facing test apps form the product layer; 7 system ids remain accepted for backward/API compatibility.
from .test_apps import APP_IDS, APP_BY_ID

SYSTEM_IDS = (
    "traits_core", "interpersonal_style", "communication_conflict",
    "trust_support_boundaries", "decision_work_style", "social_group_role",
    "adaptability_uncertainty",
)
PRODUCT_TEST_IDS = tuple(APP_IDS)
VALID_TEST_IDS = set(PRODUCT_TEST_IDS) | set(SYSTEM_IDS)
SIMILARITY_TEST_IDS = set(VALID_TEST_IDS)
SAFETY_CRITICAL_TEST_IDS: set[str] = set()
PROFILE_SECTION_CODES = {"identity", "photo", "city", "about", "friendship_goals", "interests", "boundaries", "communication", "availability", "verification"}
TEST_KIND_ORDER = list(SYSTEM_IDS)
TEST_KIND_BY_ID = {system_id: system_id for system_id in SYSTEM_IDS} | {app_id: APP_BY_ID[app_id]["system_id"] for app_id in PRODUCT_TEST_IDS}
FRIENDSHIP_EXPECTATION_TEST_IDS: set[str] = set()
TEST_POINTS_PER_TEST = 50.0 / len(PRODUCT_TEST_IDS)
