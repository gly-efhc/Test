from __future__ import annotations

from uuid import UUID

WORDING_VERSION = "respondent-neutral-v1"
DIRECT_ANCHOR_WORDING_VERSION = "public-domain-anchor-ru-v1"
SITUATIONAL_ITEM_TYPES = {
    "SITUATIONAL_FORCED_CONTINUUM",
    "SITUATIONAL_CONSTRUCT_REDUNDANCY",
    "SITUATIONAL_CONSTRUCT_TRIANGULATION",
}


def is_situational(item: dict) -> bool:
    return str(item.get("item_type")) in SITUATIONAL_ITEM_TYPES


def side_order(item: dict, item_token: str | UUID) -> str:
    """Return the stable per-session presentation order without storing a scoring key client-side.

    Test-administration item tokens are random UUIDs already persisted by Cycle 0034. Their low bit is
    therefore a stable random bit across resume/reload while remaining opaque to the respondent.
    Direct public-domain anchors are not bipolar and are never flipped.
    """
    if not is_situational(item):
        return "NA"
    return "BA" if UUID(str(item_token)).int & 1 else "AB"


def canonical_answer(item: dict, item_token: str | UUID, presented_answer: int) -> int:
    if presented_answer not in (1, 2, 3, 4):
        raise ValueError("presented_answer must be 1..4")
    return 5 - presented_answer if side_order(item, item_token) == "BA" else presented_answer


def _situational_labels(item: dict) -> list[str]:
    first = str(item["respondent_option_a_ru"])
    second = str(item["respondent_option_b_ru"])
    return [
        f"Точно ближе: {first}",
        f"Скорее ближе: {first}",
        f"Скорее ближе: {second}",
        f"Точно ближе: {second}",
    ]


def respondent_prompt(item: dict) -> str:
    return str(item.get("respondent_prompt_ru") or item["prompt_ru"])


def respondent_answer_labels(item: dict, item_token: str | UUID) -> list[str]:
    if not is_situational(item):
        return list(item["answer_labels_ru"])
    labels = _situational_labels(item)
    return list(reversed(labels)) if side_order(item, item_token) == "BA" else labels


def wording_version(item: dict) -> str:
    return str(item.get("wording_version") or (WORDING_VERSION if is_situational(item) else DIRECT_ANCHOR_WORDING_VERSION))
