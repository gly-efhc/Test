from __future__ import annotations

import hashlib
import json
from datetime import date
from pathlib import Path
from uuid import uuid4

from .models import (
    NumerologyBirthChartSignal,
    NumerologyCalculationTrace,
    NumerologyCatalogEntry,
    NumerologyCatalogGroup,
    NumerologyCatalogIndex,
    NumerologyCompatibilityComponent,
    NumerologyCompatibilityRecord,
    NumerologyNumberDetail,
    NumerologyPairRelation,
    NumerologyPinnacleCycle,
    NumerologyReadingCreate,
    NumerologyReadingRecord,
    NumerologySpecResponse,
    NumerologyTextBlock,
)

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE_PATH = ROOT / "shared" / "numerology" / "numerology_knowledge_v1.json"
SOURCE_PATH = ROOT / "shared" / "numerology" / "source_vietnamese_v1.json"

# v3 expands the immutable reading payload with transparent arithmetic traces,
# a complete 1..9 date-digit inventory and exact calendar dates for the already-defined peaks.
# It does not change the active NU compatibility formula.
CALCULATION_VERSION = "numerology-reading-v3"
KNOWLEDGE_VERSION = "numerology-knowledge-v1"
COMPATIBILITY_VERSION = "vedic-numerology-runtime-v1"
DISCLOSURE = (
    "Traditional/cultural interpretive system. Numerology is not a psychological or psychometric measure, "
    "and its compatibility score remains an independent optional metric."
)

PYTHAGOREAN = {
    **{c: n for c, n in zip("ABCDEFGHI", range(1, 10))},
    **{c: n for c, n in zip("JKLMNOPQR", range(1, 10))},
    **{c: n for c, n in zip("STUVWXYZ", range(1, 9))},
}
VOWELS = set("AEIOUY")
RULERS = {1: "Sun", 2: "Moon", 3: "Jupiter", 4: "Rahu", 5: "Mercury", 6: "Venus", 7: "Ketu", 8: "Saturn", 9: "Mars"}
FRIENDS = {
    1: {2, 3, 9}, 2: {1, 5}, 3: {1, 2, 9}, 4: {5, 6, 8}, 5: {1, 6},
    6: {5, 8}, 7: {3, 9}, 8: {5, 6}, 9: {1, 2, 3},
}
ENEMIES = {
    1: {6, 8, 4}, 2: {4, 7}, 3: {5, 6}, 4: {1, 2, 9}, 5: {2},
    6: {1, 2}, 7: {1, 2}, 8: {1, 2, 9}, 9: {5, 8},
}
DATE_MEANINGS = {
    "ru": {
        1: "инициатива, самостоятельность, лидерский импульс",
        2: "чувствительность, дипломатия, умение поддерживать связь",
        3: "обучение, смысл, наставничество и оптимизм",
        4: "нестандартность, амбиция, стремление ломать привычные рамки",
        5: "коммуникация, гибкость, интеллект и обмен информацией",
        6: "отношения, гармония, эстетика, забота и комфорт",
        7: "внутренний поиск, наблюдательность, независимость и интуитивность",
        8: "дисциплина, ответственность, выносливость и долгий горизонт",
        9: "воля, действие, защита, прямота и соревновательная энергия",
    },
    "uk": {
        1: "ініціатива, самостійність, лідерський імпульс",
        2: "чутливість, дипломатія, уміння підтримувати зв'язок",
        3: "навчання, сенс, наставництво та оптимізм",
        4: "нестандартність, амбіція, прагнення ламати звичні рамки",
        5: "комунікація, гнучкість, інтелект та обмін інформацією",
        6: "стосунки, гармонія, естетика, турбота та комфорт",
        7: "внутрішній пошук, спостережливість, незалежність та інтуїтивність",
        8: "дисципліна, відповідальність, витривалість та довгий горизонт",
        9: "воля, дія, захист, прямота та змагальна енергія",
    },
    "en": {
        1: "initiative, independence and leadership drive",
        2: "sensitivity, diplomacy and relationship maintenance",
        3: "learning, meaning, mentoring and optimism",
        4: "unconventional thinking, ambition and boundary-breaking",
        5: "communication, flexibility, intellect and information exchange",
        6: "relationships, harmony, aesthetics, care and comfort",
        7: "inner search, observation, independence and intuition",
        8: "discipline, responsibility, endurance and long-term focus",
        9: "will, action, protection, directness and competitive energy",
    },
}
GROUP_TITLES = {
    "ru": {
        "life_paths": "Жизненный путь",
        "soul_numbers": "Числа души имени",
        "outer_numbers": "Числа выражения имени",
        "birth_chart": "Карта даты",
        "pyramid_peaks": "Пики по возрасту",
    },
    "uk": {
        "life_paths": "Життєвий шлях",
        "soul_numbers": "Числа душі імені",
        "outer_numbers": "Числа вираження імені",
        "birth_chart": "Карта дати",
        "pyramid_peaks": "Піки за віком",
    },
    "en": {
        "life_paths": "Life Path",
        "soul_numbers": "Name Soul Numbers",
        "outer_numbers": "Name Expression Numbers",
        "birth_chart": "Birth-date chart",
        "pyramid_peaks": "Age pinnacles",
    },
}
CATALOG_GROUP_ORDER = ("life_paths", "soul_numbers", "outer_numbers", "birth_chart", "pyramid_peaks")


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


KNOWLEDGE = _load_json(KNOWLEDGE_PATH)
SOURCE = _load_json(SOURCE_PATH)


def _locale_key(locale: str) -> str:
    key = (locale or "ru").split("-")[0].lower()
    return key if key in KNOWLEDGE["locales"] else "en"


def _digital_root(number: int) -> int:
    if number == 0:
        return 0
    current = abs(int(number))
    while current > 9:
        current = sum(int(ch) for ch in str(current))
    return current


def _reduce_keep(number: int, masters: set[int]) -> int:
    current = abs(int(number))
    while current > 9 and current not in masters:
        current = sum(int(ch) for ch in str(current))
    return current


def _reduction_steps(number: int, masters: set[int] | None = None) -> list[int]:
    masters = masters or set()
    current = abs(int(number))
    steps = [current]
    while current > 9 and current not in masters:
        current = sum(int(ch) for ch in str(current))
        steps.append(current)
    return steps


def life_path_number(value: date) -> int:
    digits = value.strftime("%d%m%Y")
    return _reduce_keep(sum(int(ch) for ch in digits), {10, 11, 22})


def vedic_date_numbers(value: date) -> tuple[int, int, int]:
    soul = _digital_root(value.day)
    destiny = _digital_root(value.day + value.month + sum(int(ch) for ch in str(value.year)))
    maturity = _digital_root(soul + destiny)
    return soul, destiny, maturity


def birth_chart_counts(value: date) -> dict[int, int]:
    digits = value.strftime("%d%m%Y")
    return {digit: digits.count(str(digit)) for digit in range(1, 10)}


def chart_key(digit: int, count: int) -> str:
    maximum = 4 if digit == 4 else 6 if digit == 9 else 5
    return str(digit) * min(count, maximum)


def special_birth_chart_keys(counts: dict[int, int]) -> list[str]:
    present = lambda n: counts.get(n, 0) > 0
    result: list[str] = []
    if not present(5):
        if present(1) and not present(2) and not present(4): result.append("1CL")
        if present(3) and not present(2) and not present(6): result.append("3CL")
        if present(7) and not present(4) and not present(8): result.append("7CL")
        if present(9) and not present(6) and not present(8): result.append("9CL")
    if not present(7): result.append("Not7")
    if not present(9): result.append("Not9")
    return result


def pinnacle_numbers(value: date) -> list[int]:
    left = _digital_root(value.month)
    middle = _digital_root(value.day)
    right = _digital_root(sum(int(ch) for ch in str(value.year)))
    first = _digital_root(left + middle)
    second = _digital_root(middle + right)
    third = _reduce_keep(first + second, {10, 11})
    fourth = _reduce_keep(left + right, {10, 11})
    return [first, second, third, fourth]


def _date_at_age(value: date, age: int) -> date:
    target_year = value.year + age
    try:
        return value.replace(year=target_year)
    except ValueError:
        # Deterministic calendar projection for 29-Feb births in a non-leap target year.
        return date(target_year, 2, 28)


def name_numbers(latin_name: str | None) -> tuple[int | None, int | None]:
    letters = "".join(ch for ch in (latin_name or "").upper() if "A" <= ch <= "Z")
    if not letters:
        return None, None
    soul_values = [PYTHAGOREAN[ch] for ch in letters if ch in VOWELS and ch in PYTHAGOREAN]
    outer_values = [PYTHAGOREAN[ch] for ch in letters if ch not in VOWELS and ch in PYTHAGOREAN]
    soul = _reduce_keep(sum(soul_values), {1, 10, 11}) if soul_values else None
    expression = _reduce_keep(sum(outer_values), {1, 10, 11, 22}) if outer_values else None
    return soul, expression


def _text_block(row: dict) -> NumerologyTextBlock:
    return NumerologyTextBlock(title=str(row.get("title", "")), body=str(row.get("body", row.get("describe", ""))))


def _knowledge_entry(locale: str, group: str, key: str) -> dict | None:
    return KNOWLEDGE["locales"].get(_locale_key(locale), {}).get(group, {}).get(str(key))


def _date_profile_blocks(locale: str, soul: int, destiny: int, maturity: int) -> list[NumerologyTextBlock]:
    key = _locale_key(locale)
    text_locale = key if key in DATE_MEANINGS else "en"
    titles = {
        "ru": ("Число души", "Число судьбы", "Число зрелости"),
        "uk": ("Число душі", "Число долі", "Число зрілості"),
        "en": ("Soul number", "Destiny number", "Maturity number"),
    }.get(text_locale, ("Soul number", "Destiny number", "Maturity number"))
    meanings = DATE_MEANINGS[text_locale]
    return [
        NumerologyTextBlock(title=f"{titles[0]} {soul}", body=meanings[soul]),
        NumerologyTextBlock(title=f"{titles[1]} {destiny}", body=meanings[destiny]),
        NumerologyTextBlock(title=f"{titles[2]} {maturity}", body=meanings[maturity]),
    ]


def _date_number_details(locale: str, soul: int, destiny: int, maturity: int) -> list[NumerologyNumberDetail]:
    key = _locale_key(locale)
    text_locale = key if key in DATE_MEANINGS else "en"
    meanings = DATE_MEANINGS[text_locale]
    titles = {
        "ru": {"soul": "Число души", "destiny": "Число судьбы", "maturity": "Число зрелости"},
        "uk": {"soul": "Число душі", "destiny": "Число долі", "maturity": "Число зрілості"},
        "en": {"soul": "Soul number", "destiny": "Destiny number", "maturity": "Maturity number"},
    }.get(text_locale, {"soul": "Soul number", "destiny": "Destiny number", "maturity": "Maturity number"})
    values = (("soul", soul), ("destiny", destiny), ("maturity", maturity))
    return [
        NumerologyNumberDetail(role_id=role, title=titles[role], number=number, ruler=RULERS[number], meaning=meanings[number])
        for role, number in values
    ]


def _calculation_trace(value: date, latin_name: str | None) -> list[NumerologyCalculationTrace]:
    date_digits = [int(ch) for ch in value.strftime("%d%m%Y")]
    year_digits = [int(ch) for ch in str(value.year)]
    life_sum = sum(date_digits)
    soul_sum = value.day
    destiny_sum = value.day + value.month + sum(year_digits)
    soul = _digital_root(soul_sum)
    destiny = _digital_root(destiny_sum)
    maturity_sum = soul + destiny
    left = _digital_root(value.month)
    middle = _digital_root(value.day)
    right = _digital_root(sum(year_digits))
    peaks = pinnacle_numbers(value)
    traces = [
        NumerologyCalculationTrace(
            calculation_id="life_path", title="Life Path",
            formula=f"digits({value.strftime('%d%m%Y')}) = {' + '.join(map(str, date_digits))} = {life_sum}",
            reduction_steps=_reduction_steps(life_sum, {10, 11, 22}), result=life_path_number(value),
        ),
        NumerologyCalculationTrace(
            calculation_id="date_soul", title="Date Soul",
            formula=f"day {value.day}", reduction_steps=_reduction_steps(soul_sum), result=soul,
        ),
        NumerologyCalculationTrace(
            calculation_id="date_destiny", title="Date Destiny",
            formula=f"day {value.day} + month {value.month} + year digits ({' + '.join(map(str, year_digits))}) = {destiny_sum}",
            reduction_steps=_reduction_steps(destiny_sum), result=destiny,
        ),
        NumerologyCalculationTrace(
            calculation_id="date_maturity", title="Date Maturity",
            formula=f"soul {soul} + destiny {destiny} = {maturity_sum}",
            reduction_steps=_reduction_steps(maturity_sum), result=_digital_root(maturity_sum),
        ),
        NumerologyCalculationTrace(
            calculation_id="pinnacle_1", title="Pinnacle 1",
            formula=f"month root {left} + day root {middle} = {left + middle}",
            reduction_steps=_reduction_steps(left + middle), result=peaks[0],
        ),
        NumerologyCalculationTrace(
            calculation_id="pinnacle_2", title="Pinnacle 2",
            formula=f"day root {middle} + year root {right} = {middle + right}",
            reduction_steps=_reduction_steps(middle + right), result=peaks[1],
        ),
        NumerologyCalculationTrace(
            calculation_id="pinnacle_3", title="Pinnacle 3",
            formula=f"pinnacle 1 {peaks[0]} + pinnacle 2 {peaks[1]} = {peaks[0] + peaks[1]}",
            reduction_steps=_reduction_steps(peaks[0] + peaks[1], {10, 11}), result=peaks[2],
        ),
        NumerologyCalculationTrace(
            calculation_id="pinnacle_4", title="Pinnacle 4",
            formula=f"month root {left} + year root {right} = {left + right}",
            reduction_steps=_reduction_steps(left + right, {10, 11}), result=peaks[3],
        ),
    ]
    letters = "".join(ch for ch in (latin_name or "").upper() if "A" <= ch <= "Z")
    if letters:
        soul_values = [PYTHAGOREAN[ch] for ch in letters if ch in VOWELS]
        outer_values = [PYTHAGOREAN[ch] for ch in letters if ch not in VOWELS]
        if soul_values:
            total = sum(soul_values)
            traces.append(NumerologyCalculationTrace(
                calculation_id="name_soul", title="Name Soul (descriptive only)",
                formula=f"vowels {','.join(ch for ch in letters if ch in VOWELS)} -> {' + '.join(map(str, soul_values))} = {total}",
                reduction_steps=_reduction_steps(total, {1, 10, 11}), result=_reduce_keep(total, {1, 10, 11}),
            ))
        if outer_values:
            total = sum(outer_values)
            traces.append(NumerologyCalculationTrace(
                calculation_id="name_expression", title="Name Expression (descriptive only)",
                formula=f"consonants {','.join(ch for ch in letters if ch not in VOWELS)} -> {' + '.join(map(str, outer_values))} = {total}",
                reduction_steps=_reduction_steps(total, {1, 10, 11, 22}), result=_reduce_keep(total, {1, 10, 11, 22}),
            ))
    return traces


def build_reading(payload: NumerologyReadingCreate, *, created_at) -> NumerologyReadingRecord:
    locale = _locale_key(payload.locale)
    life_path = life_path_number(payload.birth_date)
    soul, destiny, maturity = vedic_date_numbers(payload.birth_date)
    counts = birth_chart_counts(payload.birth_date)
    name_soul, expression = name_numbers(payload.latin_name)

    life_entry = _knowledge_entry(locale, "life_paths", str(life_path))
    life_sections = [_text_block(row) for row in (life_entry or {}).get("sections", [])]

    chart_rows: list[NumerologyBirthChartSignal] = []
    inventory_rows: list[NumerologyBirthChartSignal] = []
    missing_entry = _knowledge_entry(locale, "birth_chart", "NONE") or {"title": "Missing digit", "body": ""}
    for digit, count in counts.items():
        if count > 0:
            key = chart_key(digit, count)
            entry = _knowledge_entry(locale, "birth_chart", key) or {"title": f"{digit} × {count}", "body": ""}
            row = NumerologyBirthChartSignal(
                key=key, digit=digit, count=count, title=str(entry.get("title", key)), body=str(entry.get("body", "")), special=False,
            )
            chart_rows.append(row)
            inventory_rows.append(row)
        else:
            inventory_rows.append(NumerologyBirthChartSignal(
                key="NONE", digit=digit, count=0,
                title=f"{missing_entry.get('title', 'Missing digit')} · {digit}", body=str(missing_entry.get("body", "")), special=False,
            ))

    special_rows: list[NumerologyBirthChartSignal] = []
    for key in special_birth_chart_keys(counts):
        entry = _knowledge_entry(locale, "birth_chart", key) or {"title": key, "body": ""}
        special_rows.append(NumerologyBirthChartSignal(
            key=key, digit=None, count=0, title=str(entry.get("title", key)), body=str(entry.get("body", "")), special=True,
        ))

    first_peak_age = max(0, 36 - life_path)
    peaks: list[NumerologyPinnacleCycle] = []
    for idx, number in enumerate(pinnacle_numbers(payload.birth_date), start=1):
        reached_at_age = first_peak_age + (idx - 1) * 9
        entry = _knowledge_entry(locale, "pyramid_peaks", str(number)) or {"title": f"Peak {number}", "body": ""}
        peaks.append(NumerologyPinnacleCycle(
            index=idx, number=number, reached_at_age=reached_at_age,
            reached_at_date=_date_at_age(payload.birth_date, reached_at_age),
            title=str(entry.get("title", f"Peak {number}")), body=str(entry.get("body", "")),
        ))

    name_profile: list[NumerologyTextBlock] = []
    if name_soul is not None:
        entry = _knowledge_entry(locale, "soul_numbers", str(name_soul))
        if entry:
            name_profile.append(_text_block(entry))
    if expression is not None:
        entry = _knowledge_entry(locale, "outer_numbers", str(expression))
        if entry:
            name_profile.append(_text_block(entry))

    canonical_input = {
        "birth_date": payload.birth_date.isoformat(),
        "latin_name": (payload.latin_name or "").strip().upper(),
        "locale": locale,
        "calculation_version": CALCULATION_VERSION,
        "knowledge_version": KNOWLEDGE_VERSION,
    }
    snapshot_hash = hashlib.sha256(json.dumps(canonical_input, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return NumerologyReadingRecord(
        reading_id=uuid4(), global_id=payload.global_id, global_id_display=f"{payload.global_id:010d}",
        birth_date=payload.birth_date, locale=locale, calculation_version=CALCULATION_VERSION,
        knowledge_version=KNOWLEDGE_VERSION, compatibility_version=COMPATIBILITY_VERSION,
        life_path_number=life_path, date_soul_number=soul, date_destiny_number=destiny,
        date_maturity_number=maturity, name_soul_number=name_soul, expression_number=expression,
        date_profile=_date_profile_blocks(locale, soul, destiny, maturity),
        date_number_details=_date_number_details(locale, soul, destiny, maturity),
        calculation_trace=_calculation_trace(payload.birth_date, payload.latin_name),
        life_path_sections=life_sections,
        birth_chart=chart_rows, birth_chart_inventory=inventory_rows,
        missing_birth_chart_digits=[d for d, c in counts.items() if c == 0],
        special_birth_chart_signals=special_rows, pinnacles=peaks, name_profile=name_profile,
        disclosure=DISCLOSURE, input_snapshot_hash=snapshot_hash, created_at=created_at,
    )


def _directed_pair(first: int, second: int) -> int:
    if second in FRIENDS.get(first, set()): return 88
    if second in ENEMIES.get(first, set()): return 38
    return 64


def pair_score(first: int, second: int) -> int:
    if first == second:
        return 94
    return max(30, min(92, (_directed_pair(first, second) + _directed_pair(second, first)) // 2))


def _relation_code(first: int, second: int, score: int) -> str:
    if first == second:
        return "SAME"
    if score >= 80:
        return "FRIENDLY"
    if score < 50:
        return "CONTRASTING"
    return "NEUTRAL"


def _pair_relation(first: int, second: int) -> NumerologyPairRelation:
    score = pair_score(first, second)
    return NumerologyPairRelation(
        first_number=first, second_number=second,
        first_ruler=RULERS[first], second_ruler=RULERS[second],
        relation_code=_relation_code(first, second, score), score=score,
    )


def compatibility_components(first_soul: int, first_destiny: int, second_soul: int, second_destiny: int) -> tuple[int, list[NumerologyCompatibilityComponent]]:
    soul_relation = _pair_relation(first_soul, second_soul)
    destiny_relation = _pair_relation(first_destiny, second_destiny)
    cross_relations = [_pair_relation(first_soul, second_destiny), _pair_relation(first_destiny, second_soul)]
    first_composite = _digital_root(first_soul + first_destiny)
    second_composite = _digital_root(second_soul + second_destiny)
    date_relation = _pair_relation(first_composite, second_composite)

    soul = soul_relation.score
    destiny = destiny_relation.score
    cross = sum(row.score for row in cross_relations) // len(cross_relations)
    date_composite = date_relation.score
    values = [
        ("soul", "Число души", soul, 0.40, f"{first_soul} ({RULERS[first_soul]}) ↔ {second_soul} ({RULERS[second_soul]})", [soul_relation]),
        ("destiny", "Число судьбы", destiny, 0.35, f"{first_destiny} ({RULERS[first_destiny]}) ↔ {second_destiny} ({RULERS[second_destiny]})", [destiny_relation]),
        ("cross", "Перекрёстная связь дат", cross, 0.15, "Две симметричные связи: душа A↔судьба B и судьба A↔душа B.", cross_relations),
        ("date_composite", "Композит даты", date_composite, 0.10, f"Цифровые корни основных чисел даты: {first_composite} ↔ {second_composite}.", [date_relation]),
    ]
    components = [
        NumerologyCompatibilityComponent(component_id=i, title=t, score=s, internal_weight=w, explanation=e, relations=relations)
        for i, t, s, w, e, relations in values
    ]
    total = max(25, min(100, int(soul * .40 + destiny * .35 + cross * .15 + date_composite * .10)))
    return total, components


def build_compatibility(first_global_id: int, second_global_id: int, first: tuple[int, int], second: tuple[int, int], *, created_at) -> NumerologyCompatibilityRecord:
    first_id, second_id = sorted((first_global_id, second_global_id))
    # Scores are symmetric, but keep date-number snapshots attached to the sorted stable pair IDs.
    if first_id != first_global_id:
        first, second = second, first
    total, components = compatibility_components(first[0], first[1], second[0], second[1])
    strongest = max(components, key=lambda row: row.score)
    weakest = min(components, key=lambda row: row.score)
    return NumerologyCompatibilityRecord(
        comparison_id=uuid4(), first_global_id=first_id, second_global_id=second_id, score=total,
        components=components, strongest_component_id=strongest.component_id,
        tension_component_id=weakest.component_id if weakest.score < 50 else None,
        first_date_numbers={"soul": first[0], "destiny": first[1]},
        second_date_numbers={"soul": second[0], "destiny": second[1]},
        calculation_version=CALCULATION_VERSION, compatibility_version=COMPATIBILITY_VERSION,
        evidence_origin="birth-date-derived Vedic numerology numbers only; name-derived numbers excluded",
        disclosure=DISCLOSURE, created_at=created_at,
    )


def _natural_key(value: str) -> tuple[int, str]:
    return (int(value), "") if value.isdigit() else (10_000, value.casefold())


def catalog_index(locale: str) -> NumerologyCatalogIndex:
    key = _locale_key(locale)
    groups: list[NumerologyCatalogGroup] = []
    titles = GROUP_TITLES.get(key, GROUP_TITLES["en"])
    total = 0
    locale_data = KNOWLEDGE["locales"][key]
    for group_id in CATALOG_GROUP_ORDER:
        keys = sorted(locale_data.get(group_id, {}).keys(), key=_natural_key)
        total += len(keys)
        groups.append(NumerologyCatalogGroup(
            group_id=group_id, title=titles.get(group_id, group_id), record_count=len(keys), keys=keys,
        ))
    return NumerologyCatalogIndex(
        knowledge_version=KNOWLEDGE_VERSION, locale=key, source_record_count=total,
        groups=groups, disclosure=DISCLOSURE,
    )


def catalog_entry(locale: str, group_id: str, key: str) -> NumerologyCatalogEntry | None:
    locale_key = _locale_key(locale)
    if group_id not in CATALOG_GROUP_ORDER:
        return None
    row = KNOWLEDGE["locales"][locale_key].get(group_id, {}).get(str(key))
    if row is None:
        return None
    sections = [_text_block(item) for item in row.get("sections", [])]
    return NumerologyCatalogEntry(
        knowledge_version=KNOWLEDGE_VERSION, locale=locale_key, group_id=group_id, key=str(key),
        title=str(row.get("title", f"{group_id} {key}")), body=str(row.get("body", "")),
        sections=sections, disclosure=DISCLOSURE,
    )


def public_spec() -> NumerologySpecResponse:
    index = catalog_index("en")
    return NumerologySpecResponse(
        calculation_version=CALCULATION_VERSION, knowledge_version=KNOWLEDGE_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        tradition="date-derived Vedic compatibility + supplied reference numerology self-analysis",
        source_archive=SOURCE["source_archive"], source_archive_sha256=SOURCE["source_archive_sha256"],
        source_language=SOURCE["source_language"], supported_locales=sorted(KNOWLEDGE["locales"].keys()),
        date_derived_fields=[
            "life_path", "soul", "destiny", "maturity", "rulers", "calculation_trace",
            "birth_chart", "birth_chart_inventory", "pinnacle_cycles", "pinnacle_calendar_dates",
        ],
        descriptive_name_fields=["name_soul_number", "expression_number"],
        compatibility_components={"soul": .40, "destiny": .35, "cross": .15, "date_composite": .10},
        compatibility_input_policy="Birth-date-derived soul/destiny numbers only. Name-derived values are descriptive and never enter NU compatibility.",
        source_record_count=index.source_record_count,
        catalog_groups=[row.group_id for row in index.groups],
        disclosure=DISCLOSURE,
    )
