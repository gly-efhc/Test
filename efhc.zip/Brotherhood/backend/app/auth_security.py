from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

from fastapi import Header, HTTPException

from .database import connection
from .models import AuthProvider, SessionIssueResponse, SessionStatusResponse
from .repository import storage_mode


@dataclass
class _MemoryLoginTicket:
    global_id: int
    provider: AuthProvider
    device_id: str
    expires_at: datetime


@dataclass
class _MemorySession:
    session_id: UUID
    global_id: int
    provider: AuthProvider
    access_token: str
    refresh_token: str | None
    expires_at: datetime
    refresh_expires_at: datetime | None
    device_id: str | None
    revoked: bool = False


# Stable development session retained only for memory/test runtime compatibility.
_DEBUG_SESSION = _MemorySession(
    session_id=UUID("00000000-0000-0000-0000-000000000001"),
    global_id=1,
    provider=AuthProvider.EMAIL,
    access_token="debug-local-session",
    refresh_token=None,
    expires_at=datetime.max.replace(tzinfo=timezone.utc),
    refresh_expires_at=None,
    device_id="debug-memory-runtime",
)
_MEMORY_BY_ACCESS: dict[str, _MemorySession] = {_DEBUG_SESSION.access_token: _DEBUG_SESSION}
_MEMORY_BY_REFRESH: dict[str, _MemorySession] = {}
_MEMORY_LOGIN_TICKETS: dict[bytes, _MemoryLoginTicket] = {}


def _token_hash(token: str) -> bytes:
    return hashlib.sha256(token.encode("utf-8")).digest()


def _internal_secret() -> str:
    return os.getenv("INTERNAL_AUTH_SECRET", "").strip()


def require_internal_secret(provided: str | None) -> None:
    # Local memory mode is explicitly a test/development runtime.
    if storage_mode() == "memory":
        return
    expected = _internal_secret()
    if not expected:
        raise HTTPException(status_code=503, detail="INTERNAL_AUTH_SECRET is not configured")
    if not provided or not hmac.compare_digest(provided, expected):
        raise HTTPException(status_code=403, detail="Forbidden")


def issue_session(
    global_id: int,
    provider: AuthProvider,
    *,
    device_id: str | None = None,
    access_ttl_minutes: int = 60,
    refresh_ttl_days: int = 30,
) -> SessionIssueResponse:
    access_token = secrets.token_urlsafe(32)
    refresh_token = secrets.token_urlsafe(48)
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(minutes=access_ttl_minutes)
    refresh_expires_at = now + timedelta(days=refresh_ttl_days)
    session_id = uuid4()

    if storage_mode() == "memory":
        row = _MemorySession(
            session_id=session_id,
            global_id=global_id,
            provider=provider,
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
            refresh_expires_at=refresh_expires_at,
            device_id=device_id,
        )
        _MEMORY_BY_ACCESS[access_token] = row
        _MEMORY_BY_REFRESH[refresh_token] = row
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO auth_sessions(
                        session_id, global_id, provider, token_hash, refresh_token_hash,
                        expires_at, refresh_expires_at, device_id, last_used_at
                    ) VALUES(%s,%s,%s::auth_provider,%s,%s,%s,%s,%s,now())
                    """,
                    (
                        session_id,
                        global_id,
                        provider.value,
                        _token_hash(access_token),
                        _token_hash(refresh_token),
                        expires_at,
                        refresh_expires_at,
                        device_id,
                    ),
                )
            conn.commit()

    return SessionIssueResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        global_id=global_id,
        global_id_display=f"{global_id:010d}",
        provider=provider,
        session_id=session_id,
        expires_at=expires_at,
        refresh_expires_at=refresh_expires_at,
    )


def issue_login_ticket(global_id: int, provider: AuthProvider, device_id: str, *, ttl_seconds: int = 120) -> str:
    ticket = secrets.token_urlsafe(32)
    ticket_hash = _token_hash(ticket)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
    if storage_mode() == "memory":
        _MEMORY_LOGIN_TICKETS[ticket_hash] = _MemoryLoginTicket(global_id=global_id, provider=provider, device_id=device_id, expires_at=expires_at)
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO auth_login_tickets(ticket_hash,global_id,provider,device_id,expires_at)
                    VALUES(%s,%s,%s::auth_provider,%s,%s)
                    """,
                    (ticket_hash, global_id, provider.value, device_id, expires_at),
                )
            conn.commit()
    return ticket


def consume_login_ticket(ticket: str, device_id: str | None) -> tuple[int, AuthProvider] | None:
    ticket_hash = _token_hash(ticket)
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        row = _MEMORY_LOGIN_TICKETS.get(ticket_hash)
        if not row or row.expires_at <= now:
            _MEMORY_LOGIN_TICKETS.pop(ticket_hash, None)
            return None
        if not device_id or not hmac.compare_digest(device_id, row.device_id):
            return None
        _MEMORY_LOGIN_TICKETS.pop(ticket_hash, None)
        return row.global_id, row.provider
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT t.ticket_id,t.global_id,t.provider,t.device_id
                FROM auth_login_tickets t
                JOIN users u ON u.global_id=t.global_id
                WHERE t.ticket_hash=%s AND t.consumed_at IS NULL AND t.expires_at>now()
                  AND u.status='active'
                LIMIT 1 FOR UPDATE OF t
                """,
                (ticket_hash,),
            )
            row = cur.fetchone()
            if not row:
                return None
            if not device_id or not hmac.compare_digest(device_id, str(row[3])):
                return None
            cur.execute("UPDATE auth_login_tickets SET consumed_at=now() WHERE ticket_id=%s", (row[0],))
        conn.commit()
    return int(row[1]), AuthProvider(str(row[2]))


def _memory_access(token: str) -> _MemorySession | None:
    row = _MEMORY_BY_ACCESS.get(token)
    if not row or row.revoked or row.expires_at <= datetime.now(timezone.utc):
        return None
    return row


def resolve_session(authorization: str | None) -> int | None:
    row = resolve_session_status(authorization)
    return row.global_id if row else None


def resolve_session_status(authorization: str | None) -> SessionStatusResponse | None:
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        return None

    if storage_mode() == "memory":
        row = _memory_access(token)
        if not row:
            return None
        return SessionStatusResponse(
            authenticated=True,
            global_id=row.global_id,
            global_id_display=f"{row.global_id:010d}",
            provider=row.provider,
            session_id=row.session_id,
            expires_at=row.expires_at,
        )

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT s.session_id, s.global_id, s.provider, s.expires_at
                FROM auth_sessions s
                JOIN users u ON u.global_id=s.global_id
                WHERE s.token_hash=%s
                  AND s.revoked_at IS NULL
                  AND s.expires_at > now()
                  AND u.status='active'
                ORDER BY s.created_at DESC
                LIMIT 1
                """,
                (_token_hash(token),),
            )
            row = cur.fetchone()
            if not row:
                return None
            cur.execute("UPDATE auth_sessions SET last_used_at=now() WHERE session_id=%s", (row[0],))
        conn.commit()
    return SessionStatusResponse(
        authenticated=True,
        session_id=row[0],
        global_id=int(row[1]),
        global_id_display=f"{int(row[1]):010d}",
        provider=AuthProvider(str(row[2])),
        expires_at=row[3],
    )


def refresh_session(refresh_token: str, *, device_id: str | None = None) -> SessionIssueResponse | None:
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        old = _MEMORY_BY_REFRESH.get(refresh_token)
        if not old or old.revoked or not old.refresh_expires_at or old.refresh_expires_at <= now:
            return None
        if device_id and old.device_id and not hmac.compare_digest(device_id, old.device_id):
            return None
        old.revoked = True
        _MEMORY_BY_ACCESS.pop(old.access_token, None)
        if old.refresh_token:
            _MEMORY_BY_REFRESH.pop(old.refresh_token, None)
        return issue_session(old.global_id, old.provider, device_id=device_id or old.device_id)

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT s.session_id, s.global_id, s.provider, s.device_id
                FROM auth_sessions s
                JOIN users u ON u.global_id=s.global_id
                WHERE s.refresh_token_hash=%s
                  AND s.revoked_at IS NULL
                  AND s.refresh_expires_at > now()
                  AND u.status='active'
                LIMIT 1
                FOR UPDATE OF s
                """,
                (_token_hash(refresh_token),),
            )
            row = cur.fetchone()
            if not row:
                return None
            if device_id and row[3] and not hmac.compare_digest(device_id, str(row[3])):
                return None
            cur.execute("UPDATE auth_sessions SET revoked_at=now(), last_used_at=now() WHERE session_id=%s", (row[0],))
        conn.commit()
    return issue_session(int(row[1]), AuthProvider(str(row[2])), device_id=device_id or row[3])


def revoke_access_session(authorization: str | None) -> bool:
    if not authorization or not authorization.startswith("Bearer "):
        return False
    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        return False
    if storage_mode() == "memory":
        row = _MEMORY_BY_ACCESS.get(token)
        if not row:
            return False
        row.revoked = True
        _MEMORY_BY_ACCESS.pop(token, None)
        if row.refresh_token:
            _MEMORY_BY_REFRESH.pop(row.refresh_token, None)
        return True
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE auth_sessions SET revoked_at=COALESCE(revoked_at, now()) WHERE token_hash=%s RETURNING session_id",
                (_token_hash(token),),
            )
            changed = cur.fetchone() is not None
        conn.commit()
    return changed


def session_global_id(authorization: str | None = Header(default=None, alias="Authorization")) -> int | None:
    value = resolve_session(authorization)
    if storage_mode() == "postgres" and value is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    return value


def require_authenticated_session(authorization: str | None = Header(default=None, alias="Authorization")) -> SessionStatusResponse:
    value = resolve_session_status(authorization)
    if value is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    return value


def require_owner(session_id: int | None, claimed_global_id: int) -> None:
    if storage_mode() == "postgres" and session_id != claimed_global_id:
        raise HTTPException(status_code=403, detail="global_id does not belong to authenticated session")
