from __future__ import annotations

from math import floor
from typing import Iterable

from .assessment_registry import TEST_KIND_BY_ID, TEST_KIND_ORDER, VALID_TEST_IDS
from .zodiac_vnext import compatibility_score as zodiac_basic_compatibility_score
from .enneagram_vnext import compatibility_score as enneagram_runtime_compatibility_score
from .models import (
    AssessmentModuleCompatibilityMetric,
    AssessmentResultRecord,
    CompatibilityMetricId,
    CompatibilityMetricStatus,
    IndependentCompatibilityMetric,
    IndependentCompatibilityResponse,
    Person,
    PersonalityProfileRecord,
    ProfileRecord,
)

CONTRACT_VERSION = "independent-compatibility-v1"
CANONICAL_METRIC_ORDER = list(CompatibilityMetricId)


def _round_half_up(value: float) -> int:
    """Match Kotlin roundToInt semantics for non-negative compatibility scores."""
    return floor(value + 0.5)


def _metric(
    metric_id: CompatibilityMetricId,
    score: int | None,
    *,
    coverage: int,
    evidence_count: int,
    model_version: str,
    evidence_origin: str,
) -> IndependentCompatibilityMetric:
    available = score is not None
    return IndependentCompatibilityMetric(
        id=metric_id,
        score=None if score is None else max(0, min(100, int(score))),
        coverage=max(0, min(100, int(coverage))),
        evidence_count=max(0, int(evidence_count)),
        model_version=model_version,
        status=CompatibilityMetricStatus.AVAILABLE if available else CompatibilityMetricStatus.INSUFFICIENT_DATA,
        evidence_origin=evidence_origin,
    )


def _score_map(results: Iterable[AssessmentResultRecord]) -> dict[str, int]:
    return {
        row.assessment_id: max(0, min(100, row.total_score))
        for row in results
        if row.assessment_id in VALID_TEST_IDS and row.scoring_version == "scientific-questionnaire-v1"
    }


def _assessment_scores(
    first: Iterable[AssessmentResultRecord], second: Iterable[AssessmentResultRecord]
) -> tuple[IndependentCompatibilityMetric, list[AssessmentModuleCompatibilityMetric], dict[str, int | None]]:
    mine = _score_map(first)
    other = _score_map(second)
    common = sorted(set(mine) & set(other))
    overall = None if not common else _round_half_up(sum(100 - abs(mine[test_id] - other[test_id]) for test_id in common) / len(common))
    pc = _metric(
        CompatibilityMetricId.PC,
        overall,
        coverage=floor(len(common) * 100 / len(VALID_TEST_IDS)),
        evidence_count=len(common),
        model_version="scientific-questionnaire-v1",
        evidence_origin="assessment_results/common_scientific_systems",
    )
    module_scores: list[AssessmentModuleCompatibilityMetric] = []
    by_kind_score: dict[str, int | None] = {}
    for kind in TEST_KIND_ORDER:
        ids = [test_id for test_id, test_kind in TEST_KIND_BY_ID.items() if test_kind == kind]
        module_common = [test_id for test_id in ids if test_id in mine and test_id in other]
        score = None if not module_common else _round_half_up(
            sum(100 - abs(mine[test_id] - other[test_id]) for test_id in module_common) / len(module_common)
        )
        by_kind_score[kind] = score
        module_scores.append(
            AssessmentModuleCompatibilityMetric(
                module_id=kind,
                score=score,
                common_assessments=len(module_common),
                total_assessments=len(ids),
                coverage=floor(len(module_common) * 100 / len(ids)),
                status=CompatibilityMetricStatus.AVAILABLE if score is not None else CompatibilityMetricStatus.INSUFFICIENT_DATA,
                model_version="scientific-questionnaire-v1",
            )
        )
    return pc, module_scores, by_kind_score


def _normalised(values: list[str]) -> set[str]:
    return {value.strip().casefold() for value in values if value and value.strip()}


def _jaccard(first: list[str], second: list[str]) -> tuple[int | None, int, int]:
    a = _normalised(first)
    b = _normalised(second)
    if not a or not b:
        return None, 0, 0
    union = a | b
    intersection = a & b
    return floor(len(intersection) * 100 / len(union)), 100, len(union)


def _axis_value(scores: dict[str, int | str], *keys: str) -> int | None:
    for key in keys:
        value = scores.get(key)
        if isinstance(value, int):
            return max(0, min(100, value))
        if isinstance(value, str) and value.isdigit():
            return max(0, min(100, int(value)))
    return None


def _personality32_score(first: PersonalityProfileRecord | None, second: PersonalityProfileRecord | None) -> int | None:
    if first is None or second is None:
        return None
    aliases = [
        ("social_energy", "socialEnergy"),
        ("perception",),
        ("decision_style", "decisionStyle"),
        ("life_rhythm", "lifeRhythm"),
        ("bond_style", "bondStyle"),
    ]
    a = [_axis_value(first.brotherhood32_scores, *keys) for keys in aliases]
    b = [_axis_value(second.brotherhood32_scores, *keys) for keys in aliases]
    if any(value is None for value in a + b):
        return None
    aa = [int(value) for value in a if value is not None]
    bb = [int(value) for value in b if value is not None]
    average_similarity = 100.0 - sum(abs(x - y) for x, y in zip(aa, bb)) / 5.0
    durability_floor = 100 - max(aa[4], bb[4])
    return max(0, min(100, int(average_similarity * 0.85 + durability_floor * 0.15)))


def _enneagram_score(first: PersonalityProfileRecord | None, second: PersonalityProfileRecord | None) -> int | None:
    if first is None or second is None:
        return None
    return enneagram_runtime_compatibility_score(
        first.enneagram_type, first.enneagram_wing, second.enneagram_type, second.enneagram_wing
    )


def _vedic_number(data: dict[str, int | list[int] | None], snake: str, camel: str) -> int | None:
    value = data.get(snake, data.get(camel))
    return value if isinstance(value, int) and 1 <= value <= 9 else None


_VEDIC_FRIENDS = {
    1: {2, 3, 9}, 2: {1, 5}, 3: {1, 2, 9}, 4: {5, 6, 8}, 5: {1, 6},
    6: {5, 8}, 7: {3, 9}, 8: {5, 6}, 9: {1, 2, 3},
}
_VEDIC_ENEMIES = {
    1: {6, 8, 4}, 2: {4, 7}, 3: {5, 6}, 4: {1, 2, 9}, 5: {2},
    6: {1, 2}, 7: {1, 2}, 8: {1, 2, 9}, 9: {5, 8},
}


def _directed_vedic(first: int, second: int) -> int:
    if second in _VEDIC_FRIENDS.get(first, set()):
        return 88
    if second in _VEDIC_ENEMIES.get(first, set()):
        return 38
    return 64


def _vedic_pair(first: int, second: int) -> int:
    if first == second:
        return 94
    return max(30, min(92, (_directed_vedic(first, second) + _directed_vedic(second, first)) // 2))


def _digital_root(number: int) -> int:
    if number == 0:
        return 0
    while number > 9:
        number = sum(int(ch) for ch in str(number))
    return number


def _numerology_score(first: PersonalityProfileRecord | None, second: PersonalityProfileRecord | None) -> int | None:
    if first is None or second is None:
        return None
    a_soul = _vedic_number(first.vedic_numerology, "soul_number", "soulNumber")
    a_destiny = _vedic_number(first.vedic_numerology, "destiny_number", "destinyNumber")
    b_soul = _vedic_number(second.vedic_numerology, "soul_number", "soulNumber")
    b_destiny = _vedic_number(second.vedic_numerology, "destiny_number", "destinyNumber")
    if None in {a_soul, a_destiny, b_soul, b_destiny}:
        return None
    assert a_soul is not None and a_destiny is not None and b_soul is not None and b_destiny is not None
    soul = _vedic_pair(a_soul, b_soul)
    destiny = _vedic_pair(a_destiny, b_destiny)
    cross = (_vedic_pair(a_soul, b_destiny) + _vedic_pair(a_destiny, b_soul)) // 2
    date_composite = _vedic_pair(_digital_root(a_soul + a_destiny), _digital_root(b_soul + b_destiny))
    return max(25, min(100, int(soul * .40 + destiny * .35 + cross * .15 + date_composite * .10)))


def _zodiac_score(first: PersonalityProfileRecord | None, second: PersonalityProfileRecord | None) -> int | None:
    if first is None or second is None:
        return None
    return zodiac_basic_compatibility_score(first.zodiac_sign, second.zodiac_sign)


def calculate_independent_compatibility(
    requester_global_id: int,
    candidate_global_id: int,
    requester_profile: ProfileRecord | None,
    candidate_profile: ProfileRecord | None,
    requester_personality: PersonalityProfileRecord | None,
    candidate_personality: PersonalityProfileRecord | None,
    requester_assessments: list[AssessmentResultRecord],
    candidate_assessments: list[AssessmentResultRecord],
    selected_metrics: list[CompatibilityMetricId],
    candidate_person: Person | None = None,
) -> IndependentCompatibilityResponse:
    pc, psychological_modules, category_scores = _assessment_scores(requester_assessments, candidate_assessments)

    interests = _jaccard(requester_profile.interests, candidate_profile.interests) if requester_profile and candidate_profile else (None, 0, 0)
    values = _jaccard(requester_profile.values, candidate_profile.values) if requester_profile and candidate_profile else (None, 0, 0)
    lifestyle = _jaccard(requester_profile.lifestyle, candidate_profile.lifestyle) if requester_profile and candidate_profile else (None, 0, 0)
    communication_score = category_scores.get("communication_conflict")
    communication_module = next(row for row in psychological_modules if row.module_id == "communication_conflict")
    personality_score = _personality32_score(requester_personality, candidate_personality)
    enneagram_score = _enneagram_score(requester_personality, candidate_personality)
    numerology_score = _numerology_score(requester_personality, candidate_personality)
    zodiac_score = _zodiac_score(requester_personality, candidate_personality)

    personality_model = (
        f"{requester_personality.model_version}+{candidate_personality.model_version}"
        if requester_personality and candidate_personality else "brotherhood32-runtime"
    )
    metrics = [
        pc,
        _metric(CompatibilityMetricId.IC, interests[0], coverage=interests[1], evidence_count=interests[2], model_version="explicit-profile-jaccard-v1", evidence_origin="profiles/interests"),
        _metric(CompatibilityMetricId.VC, values[0], coverage=values[1], evidence_count=values[2], model_version="explicit-profile-jaccard-v1", evidence_origin="profiles/values"),
        _metric(CompatibilityMetricId.CC, communication_score, coverage=communication_module.coverage, evidence_count=communication_module.common_assessments, model_version="scientific-questionnaire-v1/communication_conflict", evidence_origin="assessment_results/communication_conflict"),
        _metric(CompatibilityMetricId.LC, lifestyle[0], coverage=lifestyle[1], evidence_count=lifestyle[2], model_version="explicit-profile-jaccard-v1", evidence_origin="profiles/lifestyle"),
        _metric(CompatibilityMetricId.PT, personality_score, coverage=100 if personality_score is not None else 0, evidence_count=5 if personality_score is not None else 0, model_version=personality_model, evidence_origin="personality_profiles/brotherhood32_scores"),
        _metric(CompatibilityMetricId.EN, enneagram_score, coverage=100 if enneagram_score is not None else 0, evidence_count=2 if enneagram_score is not None else 0, model_version="enneagram-existing-runtime-v1", evidence_origin="personality_profiles/enneagram_type_wing"),
        _metric(CompatibilityMetricId.NU, numerology_score, coverage=100 if numerology_score is not None else 0, evidence_count=4 if numerology_score is not None else 0, model_version="vedic-numerology-runtime-v1", evidence_origin="personality_profiles/vedic_numerology/birth_date_numbers"),
        _metric(CompatibilityMetricId.AS, zodiac_score, coverage=100 if zodiac_score is not None else 0, evidence_count=2 if zodiac_score is not None else 0, model_version="zodiac-runtime-v1", evidence_origin="personality_profiles/zodiac_sign"),
    ]

    selected = [metric for metric in CANONICAL_METRIC_ORDER if metric in selected_metrics]
    by_id = {metric.id: metric for metric in metrics}
    incomplete = [metric_id for metric_id in selected if by_id[metric_id].score is None]
    if selected and not incomplete:
        overall = _round_half_up(sum(int(by_id[metric_id].score) for metric_id in selected if by_id[metric_id].score is not None) / len(selected))
        overall_status = CompatibilityMetricStatus.AVAILABLE
    else:
        overall = None
        overall_status = CompatibilityMetricStatus.INSUFFICIENT_DATA

    return IndependentCompatibilityResponse(
        requester_global_id=requester_global_id,
        candidate_global_id=candidate_global_id,
        selected_metrics=selected,
        metrics=metrics,
        psychological_modules=psychological_modules,
        overall=overall,
        overall_status=overall_status,
        incomplete_selected_metrics=incomplete,
        trust_score=candidate_person.trust_score if candidate_person else None,
        account_rating=candidate_person.account_rating if candidate_person else None,
    )
