from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .models import AssessmentResultRecord
from .test_apps import APP_IDS_BY_SYSTEM

CALIBRATION_VERSION = "scientific-corpus-baseline-v1"
MODEL_VERSION = "psychological-test-systems-v1"
EVIDENCE_BUNDLE_VERSION = "scientific-baseline-synthesis-v1"
RELEASE_BASELINE_STATUS = "ACTIVE_SCIENTIFIC_BASELINE"
RECALIBRATION_POLICY = "POST_RELEASE_VERSIONED_RECALIBRATION_ONLY"

@dataclass(frozen=True)
class SystemSpec:
    system_id: str
    title: str
    subtitle: str
    trait_keys: tuple[str, ...]
    source_ids: tuple[str, ...]
    construct_note: str



SYSTEMS: tuple[SystemSpec, ...] = (
    SystemSpec(
        "traits_core", "Черты и саморегуляция", "Базовые устойчивые тенденции, организация поведения и самоконтроль.",
        ("social_energy","agreeableness_orientation","conscientiousness_orientation","emotional_stability","openness_intellect","dependability","planning","stress_tolerance","intellectual_curiosity","integrity_sincerity","self_control","adaptability","attention_to_detail","perseverance","humility"),
        ("IPIP-001","IPIP-002","HEXACO-001","HEXACO-002","WORK-010","VIS-FC-001","VIS-FC-IMG-001"),
        "Big Five/IPIP + HEXACO reference families; Brotherhood keeps its indirect visual measurement as a separate versioned model.",
    ),
    SystemSpec(
        "interpersonal_style", "Межличностный стиль", "Автономия, агентность, кооперация, близость и границы во взаимодействии.",
        ("assertiveness","autonomy","group_orientation","cooperation","leadership_orientation","status_independence","boundary_respect"),
        ("IPC-001","IPC-002","IPC-003","ATTACH-001","COMM-001"),
        "Interpersonal Circumplex agency/communion plus relationship-support boundaries; no clinical attachment labels.",
    ),
    SystemSpec(
        "communication_conflict", "Коммуникация и конфликт", "Прямота, такт, ритм контакта, работа с разногласиями и восстановление контакта.",
        ("directness","tact","conflict_engagement","forgiveness","response_urgency","contact_intensity","vulnerability_comfort","empathy","self_control"),
        ("COMM-001","COMM-002","COMM-003","COMM-004","COMM-005","COMM-007","FRIEND-016","FRIEND-020"),
        "Communication responsiveness/self-disclosure and conflict-process/repair literature; process tendencies are interpreted contextually.",
    ),
    SystemSpec(
        "trust_support_boundaries", "Доверие, поддержка и границы", "Психологическая открытость к доверию, взаимность, поддержка и уважение автономии.",
        ("trust_openness","confidentiality","reciprocity","support_availability","empathy","boundary_respect","fairness","vulnerability_comfort"),
        ("TRUST-001","TRUST-002","COMM-006","COMM-008","ATTACH-001","FRIEND-003"),
        "Psychological trust/cooperation is separate from platform Trust reputation; support and boundary constructs remain non-moral.",
    ),
    SystemSpec(
        "decision_work_style", "Решения, риск и рабочий стиль", "Планирование, темп решений, риск, исполнение и практическое сотрудничество.",
        ("decisiveness","planning","risk_tolerance","cautiousness","attention_to_detail","achievement_orientation","initiative","perseverance","time_discipline","innovation"),
        ("BUS-010","FIT-001","FIT-002","FIT-003","TEAM-001","WORK-005","WORK-009","WORK-010"),
        "Risk is treated as domain-sensitive; work/team evidence anchors constructs but does not become an automated employment verdict.",
    ),
    SystemSpec(
        "social_group_role", "Социальная энергия и роль в группе", "Групповая вовлечённость, лидерство, кооперация, соревнование и инициативность.",
        ("social_energy","group_orientation","leadership_orientation","cooperation","competitiveness","initiative","status_independence"),
        ("TEAM-001","WORK-005","WORK-009","BUS-005","BUS-006","PP-001","PP-003","PP-004"),
        "Team/social-role sources inform construct selection; role effectiveness is not inferred from a single personality pole.",
    ),
    SystemSpec(
        "adaptability_uncertainty", "Адаптивность и неопределённость", "Как модель описывает гибкость, устойчивость, неопределённость и изменение условий.",
        ("stress_tolerance","ambiguity_tolerance","self_control","adaptability","optimism","cautiousness","perseverance","spontaneity"),
        ("IPIP-001","IPIP-002","HEXACO-001","HEXACO-002","WORK-005","FIT-003","STD-APA-001","STD-COSMIN-001"),
        "Non-clinical adaptation/uncertainty style. The system never diagnoses stress disorders or mental health conditions.",
    ),
)

BY_ID = {s.system_id: s for s in SYSTEMS}


def _weighted_traits(results: Iterable[AssessmentResultRecord], system_id: str, trait_keys: set[str]):
    rows: dict[str, list[tuple[int, float]]] = {k: [] for k in trait_keys}
    completed = False
    for result in results:
        accepted_ids = set(APP_IDS_BY_SYSTEM.get(system_id, ())) | {system_id}
        if result.assessment_id not in accepted_ids or result.scoring_version != "scientific-questionnaire-v1":
            continue
        completed = True
        weight = 0.35 + max(0, min(100, result.answer_consistency)) / 100.0 * 0.65
        for dim in result.dimensions:
            if dim.id in rows:
                rows[dim.id].append((dim.score, weight))
    traits: dict[str, dict[str, int]] = {}
    for key, values in rows.items():
        if not values:
            continue
        denom = sum(w for _, w in values) or 1.0
        score = round(sum(score * w for score, w in values) / denom)
        traits[key] = {"score": max(0, min(100, score)), "evidence": len(values)}
    return completed, traits


def _positive_label(key: str, score: int) -> str:
    labels = {
        "dependability": ("гибкость в договорённостях", "надёжность и последовательность"),
        "integrity_sincerity": ("прагматичная стратегичность", "искренность и принципиальность"),
        "self_control": ("эмоциональная выразительность", "самоконтроль под давлением"),
        "planning": ("импровизация", "планирование и структура"),
        "adaptability": ("устойчивость привычного порядка", "адаптивность к изменениям"),
        "attention_to_detail": ("фокус на общей картине", "внимание к деталям"),
        "perseverance": ("гибкое переключение", "настойчивость"),
        "social_energy": ("комфорт в камерном общении", "социальная энергия"),
        "intellectual_curiosity": ("практическая конкретность", "интеллектуальная любознательность"),
        "humility": ("уверенная самопрезентация", "скромность"),
        "agreeableness_orientation": ("жёсткая предметность", "доброжелательная ориентация на других"),
        "conscientiousness_orientation": ("гибкость и действие по ситуации", "организованность и последовательность"),
        "emotional_stability": ("повышенная эмоциональная реактивность", "эмоциональная устойчивость"),
        "openness_intellect": ("фокус на конкретном и знакомом", "открытость идеям и воображению"),
        "assertiveness": ("мягкий ненавязчивый стиль", "уверенная инициативность"),
        "autonomy": ("ориентация на совместные решения", "самостоятельность"),
        "group_orientation": ("индивидуальная независимость", "командная вовлечённость"),
        "cooperation": ("самостоятельная конкуренция", "кооперация"),
        "leadership_orientation": ("сильная исполнительская роль", "лидерская ориентация"),
        "status_independence": ("чувствительность к иерархии", "независимость от статуса"),
        "boundary_respect": ("высокая вовлечённость", "уважение личных границ"),
        "directness": ("дипломатичность", "прямота и ясность"),
        "tact": ("жёсткая предметность", "такт"),
        "conflict_engagement": ("умение дать конфликту остыть", "готовность обсуждать напряжение"),
        "forgiveness": ("сильная память на нарушения", "готовность восстанавливать отношения"),
        "response_urgency": ("асинхронный ритм", "быстрая реакция"),
        "contact_intensity": ("редкий содержательный контакт", "частый контакт"),
        "vulnerability_comfort": ("сдержанная приватность", "эмоциональная открытость"),
        "empathy": ("эмоциональная объективность", "эмпатическая чувствительность"),
        "trust_openness": ("осторожное накопление доверия", "быстрая открытость доверию"),
        "confidentiality": ("свободный обмен информацией", "дискретность"),
        "reciprocity": ("автономность от обмена", "взаимность"),
        "support_availability": ("поддержка самостоятельности", "готовность быть рядом"),
        "fairness": ("гибкое распределение ресурсов", "ориентация на справедливый обмен"),
        "decisiveness": ("взвешенная пауза", "решительность"),
        "risk_tolerance": ("осторожное управление риском", "готовность к риску"),
        "cautiousness": ("быстрое действие", "осторожность"),
        "achievement_orientation": ("процессная ориентация", "ориентация на результат"),
        "initiative": ("реактивный стиль", "инициативность"),
        "time_discipline": ("гибкое отношение ко времени", "временная дисциплина"),
        "innovation": ("опора на проверенное", "ориентация на новое"),
        "competitiveness": ("кооперация без доминирования", "соревновательность"),
        "stress_tolerance": ("бережное снижение нагрузки", "устойчивость под нагрузкой"),
        "ambiguity_tolerance": ("потребность в определённости", "терпимость к неопределённости"),
        "optimism": ("реалистичная осторожность", "оптимистическая ориентация"),
        "spontaneity": ("подготовленность", "спонтанность"),
    }
    low, high = labels.get(key, (key.replace('_',' '), key.replace('_',' ')))
    if score >= 60:
        return high
    if score <= 40:
        return low
    return f"гибкий баланс: {low} ↔ {high}"


def system_result(spec: SystemSpec, results: Iterable[AssessmentResultRecord]) -> dict:
    completed, traits = _weighted_traits(results, spec.system_id, set(spec.trait_keys))
    series_coverage = 100 if completed else 0
    construct_coverage = round(len(traits) * 100 / len(spec.trait_keys)) if spec.trait_keys else 0
    coverage = construct_coverage if completed else 0
    strongest = sorted(traits.items(), key=lambda kv: abs(kv[1]["score"] - 50), reverse=True)
    characteristics = [_positive_label(k, v["score"]) for k, v in strongest[:5]]
    growth = [f"Расширять поведенческий диапазон вокруг: {_positive_label(k, 50)}" for k, v in strongest if abs(v["score"]-50) >= 22][:3]
    if not completed:
        summary = "Тест ещё не пройден."
        status = "NOT_STARTED"
    else:
        focus = ", ".join(characteristics[:3]) if characteristics else "пока без устойчиво выделившихся тенденций"
        summary = f"На текущей научной батарее наиболее заметны: {focus}. Результат относится к версии scientific-questionnaire-v1."
        status = "PROFILE_READY"
    return {
        "system_id": spec.system_id, "title": spec.title, "subtitle": spec.subtitle,
        "model_version": MODEL_VERSION, "calibration_version": CALIBRATION_VERSION,
        "calibration_basis": "SCIENTIFIC_CORPUS_RELEASE_BASELINE",
        "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION,
        "release_baseline_status": RELEASE_BASELINE_STATUS,
        "future_recalibration_policy": RECALIBRATION_POLICY,
        "compatibility_ready": bool(traits) and construct_coverage >= 60,
        "status": status, "completed_series": 1 if completed else 0, "total_series": 1,
        "coverage_percent": max(0, min(100, coverage)),
        "series_coverage_percent": series_coverage,
        "construct_coverage_percent": max(0, min(100, construct_coverage)),
        "characteristics": characteristics, "growth_areas": growth, "summary": summary,
        "source_ids": list(spec.source_ids), "construct_note": spec.construct_note,
        "private_trait_scores": {k: v["score"] for k, v in traits.items()},
        "private_trait_evidence": {k: v["evidence"] for k, v in traits.items()},
    }


def all_system_results(results: Iterable[AssessmentResultRecord]) -> list[dict]:
    rows = list(results)
    return [system_result(spec, rows) for spec in SYSTEMS]


def system_compatibility(spec: SystemSpec, left: Iterable[AssessmentResultRecord], right: Iterable[AssessmentResultRecord]) -> dict:
    a = system_result(spec, left)
    b = system_result(spec, right)
    common = sorted(set(a["private_trait_scores"]) & set(b["private_trait_scores"]))
    if not common:
        return {"system_id": spec.system_id, "score": None, "coverage": 0, "status": "INSUFFICIENT_DATA", "common_constructs": 0, "model_version": MODEL_VERSION, "calibration_version": CALIBRATION_VERSION, "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION, "future_recalibration_policy": RECALIBRATION_POLICY, "method": "UNWEIGHTED_CONSTRUCT_SIMILARITY_SCIENTIFIC_QUESTIONNAIRE_V1"}
    similarities = [100 - abs(a["private_trait_scores"][k] - b["private_trait_scores"][k]) for k in common]
    coverage = round(len(common) * 100 / len(spec.trait_keys))
    return {"system_id": spec.system_id, "score": round(sum(similarities)/len(similarities)), "coverage": coverage, "status": "AVAILABLE", "common_constructs": len(common), "model_version": MODEL_VERSION, "calibration_version": CALIBRATION_VERSION, "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION, "future_recalibration_policy": RECALIBRATION_POLICY, "method": "UNWEIGHTED_CONSTRUCT_SIMILARITY_SCIENTIFIC_QUESTIONNAIRE_V1"}


def public_catalog() -> list[dict]:
    return [{
        "system_id": s.system_id,
        "title": s.title,
        "subtitle": s.subtitle,
        "total_series": 1,
        "source_ids": list(s.source_ids),
        "assessment_ids": [s.system_id],
        "construct_note": s.construct_note,
        "model_version": MODEL_VERSION,
        "calibration_version": CALIBRATION_VERSION,
        "calibration_basis": "SCIENTIFIC_CORPUS_RELEASE_BASELINE",
        "evidence_bundle_id": f"{s.system_id}-evidence-v1",
        "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION,
        "release_baseline_status": RELEASE_BASELINE_STATUS,
        "future_recalibration_policy": RECALIBRATION_POLICY,
        "compatibility_feature_ids": list(s.trait_keys),
    } for s in SYSTEMS]
