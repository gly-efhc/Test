from __future__ import annotations

import hashlib
import json
from datetime import datetime
from uuid import uuid4

from .models import (
    AssessmentResultRecord,
    QualityFitAvailability,
    QualityFitCatalogItem,
    QualityFitCatalogResponse,
    QualityFitEvaluationRecord,
    QualityFitEvaluationRequest,
    QualityFitRequirementResult,
    QualityFitSpecResponse,
    QualityRequirementKind,
    SearchIntentRequirement,
)
from .quality_matching import QUALITY_CATALOG, _quality_fit_row, aggregate_latent

CONTRACT_VERSION = "quality-fit-search-intent-v2"
CATALOG_VERSION = "quality-fit-catalog-v2"
SCORING_VERSION = "quality-fit-directional-v2"
SUPPORTED_LOCALES = ["sw", "ru", "en", "uk", "de", "fr", "es", "it", "tr", "pl", "da", "hi", "id"]


def _locale_key(locale: str) -> str:
    key = (locale or "ru").split("-", 1)[0].lower()
    return key if key in SUPPORTED_LOCALES else "en"


def _label(quality_key: str, locale: str) -> str:
    row = QUALITY_CATALOG.get(quality_key) or {}
    lang = _locale_key(locale)
    return str(row.get(lang) or row.get("en") or quality_key)


def spec() -> QualityFitSpecResponse:
    return QualityFitSpecResponse(
        contract_version=CONTRACT_VERSION,
        catalog_version=CATALOG_VERSION,
        scoring_version=SCORING_VERSION,
        directionality="SEARCHER_A_TO_CANDIDATE_B",
        role_injects_defaults=False,
        quality_count=len(QUALITY_CATALOG),
        hard_requirements_supported=True,
        missing_data_policy="Missing candidate measurement stays INSUFFICIENT_DATA; it is never converted to zero.",
        separation_rules=[
            "Quality Fit is separate from Compatibility.",
            "Quality Fit is separate from Trust, Account Rating and Hospitality Reputation.",
            "Role context never injects desired qualities automatically.",
            "Only explicitly selected requirements participate in the directional score.",
        ],
    )


def catalog(locale: str = "ru") -> QualityFitCatalogResponse:
    lang = _locale_key(locale)
    rows = [
        QualityFitCatalogItem(
            quality_key=key,
            label=_label(key, lang),
            group=str(row.get("group") or "other"),
            target_count=max(1, len(row.get("targets") or [])),
        )
        for key, row in QUALITY_CATALOG.items()
    ]
    rows.sort(key=lambda item: (item.group, item.label.casefold(), item.quality_key))
    return QualityFitCatalogResponse(
        catalog_version=CATALOG_VERSION,
        locale=lang,
        quality_count=len(rows),
        groups=sorted({item.group for item in rows}),
        qualities=rows,
    )


def normalize_requirements(requirements: list[SearchIntentRequirement]) -> list[SearchIntentRequirement]:
    result: list[SearchIntentRequirement] = []
    seen: set[str] = set()
    for item in requirements:
        key = item.quality_key.strip()
        if key not in QUALITY_CATALOG or key in seen:
            continue
        seen.add(key)
        result.append(item.model_copy(update={"quality_key": key}))
    return result


def requirements_from_legacy(desired_qualities: list[str]) -> list[SearchIntentRequirement]:
    result: list[SearchIntentRequirement] = []
    seen: set[str] = set()
    for raw in desired_qualities:
        key, _, importance_raw = str(raw).partition(":")
        key = key.strip()
        if key not in QUALITY_CATALOG or key in seen:
            continue
        seen.add(key)
        try:
            importance = max(1, min(5, int(importance_raw or "3")))
        except ValueError:
            importance = 3
        result.append(SearchIntentRequirement(quality_key=key, importance=importance))
    return result


def _intent_hash(payload: QualityFitEvaluationRequest, requirements: list[SearchIntentRequirement]) -> str:
    body = {
        "role_context": payload.role_context.strip(),
        "search_request_id": str(payload.search_request_id) if payload.search_request_id else None,
        "requirements": [item.model_dump(mode="json") for item in requirements],
        "contract_version": CONTRACT_VERSION,
        "catalog_version": CATALOG_VERSION,
        "scoring_version": SCORING_VERSION,
    }
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _evidence_hash(rows: list[AssessmentResultRecord]) -> str:
    body = [
        {
            "assessment_id": row.assessment_id,
            "scoring_version": row.scoring_version,
            "completed_at_epoch_ms": row.completed_at_epoch_ms,
            "answer_consistency": row.answer_consistency,
            "dimensions": sorted(
                [{"id": dim.id, "score": dim.score} for dim in row.dimensions],
                key=lambda item: item["id"],
            ),
        }
        for row in sorted(rows, key=lambda item: (item.assessment_id, item.completed_at_epoch_ms))
    ]
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _result_for_requirement(item: SearchIntentRequirement, traits: dict[str, int], locale: str) -> QualityFitRequirementResult:
    row = QUALITY_CATALOG[item.quality_key]
    measured = _quality_fit_row(row, traits)
    label = _label(item.quality_key, locale)
    if measured is None:
        return QualityFitRequirementResult(
            quality_key=item.quality_key,
            label=label,
            kind=item.kind,
            importance=item.importance,
            minimum_score=item.minimum_score,
            score=None,
            coverage_percent=0,
            status="INSUFFICIENT_DATA",
            explanation="Для этого требования у кандидата пока недостаточно измерительных данных.",
        )
    score, coverage = measured
    if item.kind == QualityRequirementKind.HARD:
        passed = score >= item.minimum_score
        status = "MET" if passed else "NOT_MET"
        explanation = (
            f"Обязательное условие выполнено: {score}% ≥ {item.minimum_score}%."
            if passed else f"Обязательное условие не выполнено: {score}% < {item.minimum_score}%."
        )
    else:
        status = "MATCH" if score >= 70 else ("PARTIAL" if score >= 50 else "LOW_FIT")
        explanation = f"Предпочтение: соответствие {score}% при покрытии данных {coverage}%."
    return QualityFitRequirementResult(
        quality_key=item.quality_key,
        label=label,
        kind=item.kind,
        importance=item.importance,
        minimum_score=item.minimum_score,
        score=score,
        coverage_percent=coverage,
        status=status,
        explanation=explanation,
    )


def build_evaluation(
    payload: QualityFitEvaluationRequest,
    candidate_results: list[AssessmentResultRecord],
    *,
    created_at: datetime,
    requirements: list[SearchIntentRequirement] | None = None,
) -> QualityFitEvaluationRecord:
    normalized = normalize_requirements(requirements if requirements is not None else payload.requirements)
    traits, evidence_confidence = aggregate_latent([row.model_dump(mode="json") for row in candidate_results])
    rows = [_result_for_requirement(item, traits, payload.locale) for item in normalized]
    available = [row for row in rows if row.score is not None]
    missing = [row.quality_key for row in rows if row.score is None]
    hard_available = [row for row in available if row.kind == QualityRequirementKind.HARD]
    hard_failed = [row for row in hard_available if row.status == "NOT_MET"]
    hard_missing = [row for row in rows if row.kind == QualityRequirementKind.HARD and row.score is None]

    if available:
        denom = sum(max(1, row.importance) for row in available)
        score = round(sum(int(row.score or 0) * max(1, row.importance) for row in available) / max(1, denom))
        mean_coverage = round(sum(row.coverage_percent for row in available) / len(available))
        confidence = round(evidence_confidence * 0.75 + mean_coverage * 0.25)
    else:
        score = None
        confidence = 0

    if not normalized or not available:
        availability = QualityFitAvailability.INSUFFICIENT_DATA
    elif hard_failed:
        availability = QualityFitAvailability.HARD_REQUIREMENT_NOT_MET
    elif missing:
        availability = QualityFitAvailability.PARTIAL
    else:
        availability = QualityFitAvailability.AVAILABLE

    eligible = not hard_failed and not hard_missing
    if not normalized:
        explanation = "Quality Fit не рассчитан: пользователь не выбрал ни одного требования."
    elif not available:
        explanation = "Quality Fit не рассчитан: по выбранным требованиям недостаточно данных кандидата."
    elif hard_failed:
        explanation = f"Направленный Quality Fit {score}%, но {len(hard_failed)} обязательное условие не выполнено."
    elif hard_missing:
        explanation = f"Направленный Quality Fit {score}%, но обязательное условие нельзя проверить из-за отсутствующих данных."
    elif missing:
        explanation = f"Направленный Quality Fit {score}% рассчитан по доступным требованиям; {len(missing)} требований имеют недостаточно данных."
    else:
        explanation = f"Направленный Quality Fit A→B: {score}% по {len(available)} явно выбранным требованиям."

    return QualityFitEvaluationRecord(
        evaluation_id=uuid4(),
        searcher_global_id=payload.searcher_global_id,
        candidate_global_id=payload.candidate_global_id,
        search_request_id=payload.search_request_id,
        role_context=payload.role_context.strip(),
        contract_version=CONTRACT_VERSION,
        catalog_version=CATALOG_VERSION,
        scoring_version=SCORING_VERSION,
        intent_snapshot_hash=_intent_hash(payload, normalized),
        candidate_evidence_hash=_evidence_hash(candidate_results),
        score=score,
        confidence=max(0, min(100, confidence)),
        availability=availability,
        eligible=eligible,
        requirement_results=rows,
        missing_quality_keys=missing,
        explanation=explanation,
        created_at=created_at,
    )
