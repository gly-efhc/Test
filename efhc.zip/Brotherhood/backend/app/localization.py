"""Data-driven localization registry shared by backend-facing Brotherhood surfaces.

Enabled locales come from shared/locales/supported.json. Locale packs are data, not code:
adding a future language must not require editing matching algorithms or API branches.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]
LOCALE_ROOT = PROJECT_ROOT / "shared" / "locales"
SUPPORTED_PATH = LOCALE_ROOT / "supported.json"
PACK_ROOT = LOCALE_ROOT / "packs"
CITIES_PATH = LOCALE_ROOT / "cities.json"
LANGUAGE_TAG_RE = re.compile(r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")


@lru_cache(maxsize=1)
def locale_registry() -> dict[str, Any]:
    data = json.loads(SUPPORTED_PATH.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError("shared/locales/supported.json must be an object")
    return data


def default_locale() -> str:
    return str(locale_registry().get("default", "ru"))


def language_records() -> list[dict[str, Any]]:
    rows = locale_registry().get("languages", [])
    return [dict(item) for item in rows if isinstance(item, dict) and item.get("enabled") is True]


def supported_locale_tags() -> tuple[str, ...]:
    return tuple(str(item["tag"]) for item in language_records() if item.get("tag"))


def is_valid_language_tag(value: str) -> bool:
    return bool(LANGUAGE_TAG_RE.fullmatch(value))


def normalize_locale(value: str | None) -> str:
    """Return an enabled exact/base locale, otherwise the configured default.

    This is intentionally data-driven. Future locale activation is performed by adding a
    complete pack and enabling it in supported.json; matching code does not change.
    """
    if not value:
        return default_locale()
    candidate = value.strip()
    enabled = supported_locale_tags()
    if candidate in enabled:
        return candidate
    lower_map = {item.lower(): item for item in enabled}
    if candidate.lower() in lower_map:
        return lower_map[candidate.lower()]
    base = candidate.split("-", 1)[0].lower()
    if base in lower_map:
        return lower_map[base]
    return default_locale()


@lru_cache(maxsize=128)
def locale_messages(locale: str) -> dict[str, str]:
    tag = normalize_locale(locale)
    path = PACK_ROOT / f"{tag}.json"
    if not path.exists():
        if tag != default_locale():
            return locale_messages(default_locale())
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    messages = data.get("messages", {}) if isinstance(data, dict) else {}
    return {str(k): str(v) for k, v in messages.items()}


def translate(locale: str, key: str, *, fallback: str = "", **values: object) -> str:
    tag = normalize_locale(locale)
    text = locale_messages(tag).get(key)
    if text is None and tag != "en" and "en" in supported_locale_tags():
        text = locale_messages("en").get(key)
    if text is None:
        text = fallback or key
    try:
        return text.format(**values)
    except (KeyError, ValueError):
        return text



@lru_cache(maxsize=1)
def city_records() -> list[dict[str, str]]:
    data = json.loads(CITIES_PATH.read_text(encoding="utf-8"))
    rows = data.get("cities", []) if isinstance(data, dict) else []
    return [
        {str(k): str(v) for k, v in item.items()}
        for item in rows
        if isinstance(item, dict) and item.get("id") and item.get("value")
    ]


def city_values(*, include_online: bool = False) -> tuple[str, ...]:
    return tuple(
        item["value"]
        for item in city_records()
        if include_online or item.get("id") != "online"
    )


def localized_city_options(locale: str, query: str | None = None) -> list[dict[str, str]]:
    tag = normalize_locale(locale)
    q = query.casefold().strip() if query else ""
    result: list[dict[str, str]] = []
    for item in city_records():
        if item.get("id") == "online":
            continue
        label = translate(tag, f"city.name.{item['id']}", fallback=item.get(tag, item.get("en", item["value"])))
        if q and q not in label.casefold() and q not in item["value"].casefold():
            continue
        result.append({"id": item["id"], "value": item["value"], "label": label})
    return result

def public_language_catalog() -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for row in language_records():
        result.append(
            {
                "tag": str(row["tag"]),
                "native_name": str(row.get("native_name", row["tag"])),
                "direction": str(row.get("direction", "ltr")),
            }
        )
    return result
