from __future__ import annotations

import hashlib
import json
from datetime import date
from pathlib import Path
from uuid import uuid4

from .models import (
    ZodiacCatalogIndex,
    ZodiacCompatibilityRecord,
    ZodiacReadingCreate,
    ZodiacReadingRecord,
    ZodiacSignDetail,
    ZodiacSpecResponse,
)

ROOT = Path(__file__).resolve().parents[2]
LOCALE_PACKS = ROOT / "shared" / "locales" / "packs"

CALCULATION_VERSION = "zodiac-basic-reading-v1"
CATALOG_VERSION = "zodiac-basic-catalog-v1"
COMPATIBILITY_VERSION = "zodiac-runtime-v1"
METHOD_ID = "AS_ZODIAC_BASIC_V1"
SOURCE_IDS = ["ASTRO-001", "ALT-VEDASTRO-001"]
SUPPORTED_LOCALES = ["sw", "ru", "en", "uk", "de", "fr", "es", "it", "tr", "pl", "da", "hi", "id"]
DISCLOSURE = (
    "Traditional/alternative Zodiac method. This AS score is an independent optional index, not psychological evidence, "
    "not Trust/Quality Fit, and not a probability of friendship or relationship success."
)

# Exact sign boundaries already implemented by Brotherhood's ZodiacEngine and standalone v1.
SIGN_ORDER = [
    "ARIES", "TAURUS", "GEMINI", "CANCER", "LEO", "VIRGO",
    "LIBRA", "SCORPIO", "SAGITTARIUS", "CAPRICORN", "AQUARIUS", "PISCES",
]
SIGN_SYMBOLS = {
    "ARIES": "♈", "TAURUS": "♉", "GEMINI": "♊", "CANCER": "♋",
    "LEO": "♌", "VIRGO": "♍", "LIBRA": "♎", "SCORPIO": "♏",
    "SAGITTARIUS": "♐", "CAPRICORN": "♑", "AQUARIUS": "♒", "PISCES": "♓",
}
SIGN_ENGLISH_LABELS = {
    "ARIES": "Aries", "TAURUS": "Taurus", "GEMINI": "Gemini", "CANCER": "Cancer",
    "LEO": "Leo", "VIRGO": "Virgo", "LIBRA": "Libra", "SCORPIO": "Scorpio",
    "SAGITTARIUS": "Sagittarius", "CAPRICORN": "Capricorn", "AQUARIUS": "Aquarius", "PISCES": "Pisces",
}
SIGN_PERIODS = {
    "ARIES": ("03-21", "04-19"),
    "TAURUS": ("04-20", "05-20"),
    "GEMINI": ("05-21", "06-20"),
    "CANCER": ("06-21", "07-22"),
    "LEO": ("07-23", "08-22"),
    "VIRGO": ("08-23", "09-22"),
    "LIBRA": ("09-23", "10-22"),
    "SCORPIO": ("10-23", "11-21"),
    "SAGITTARIUS": ("11-22", "12-21"),
    "CAPRICORN": ("12-22", "01-19"),
    "AQUARIUS": ("01-20", "02-18"),
    "PISCES": ("02-19", "03-20"),
}

# These four groups are not a new scoring system: they are named product metadata for the
# exact group partition already used in Android ZodiacEngine and backend Q28 AS runtime.
SIGN_GROUPS = {
    "ARIES": "FIRE", "LEO": "FIRE", "SAGITTARIUS": "FIRE",
    "TAURUS": "EARTH", "VIRGO": "EARTH", "CAPRICORN": "EARTH",
    "GEMINI": "AIR", "LIBRA": "AIR", "AQUARIUS": "AIR",
    "CANCER": "WATER", "SCORPIO": "WATER", "PISCES": "WATER",
}
GROUP_LABEL_RU = {"FIRE": "Огонь", "EARTH": "Земля", "AIR": "Воздух", "WATER": "Вода"}
GROUP_LABEL_EN = {"FIRE": "Fire", "EARTH": "Earth", "AIR": "Air", "WATER": "Water"}
GROUP_LABEL_UK = {"FIRE": "Вогонь", "EARTH": "Земля", "AIR": "Повітря", "WATER": "Вода"}

# Existing v1 product copy moved from frontend into the source contract. It is intentionally
# labelled traditional/product copy and is not represented as scientific personality evidence.
CHARACTERISTICS_RU = {
    "ARIES": ["инициатива", "прямота", "быстрый старт"],
    "TAURUS": ["устойчивость", "практичность", "последовательность"],
    "GEMINI": ["контактность", "любознательность", "гибкость"],
    "CANCER": ["забота", "чувствительность", "привязанность"],
    "LEO": ["выраженность", "щедрость", "самопрезентация"],
    "VIRGO": ["внимание к деталям", "порядок", "практичность"],
    "LIBRA": ["баланс", "дипломатичность", "партнёрство"],
    "SCORPIO": ["интенсивность", "глубина", "настойчивость"],
    "SAGITTARIUS": ["исследование", "свобода", "широкий горизонт"],
    "CAPRICORN": ["цели", "ответственность", "дисциплина"],
    "AQUARIUS": ["независимость", "идеи", "новаторство"],
    "PISCES": ["воображение", "эмпатия", "восприимчивость"],
}


def _locale_key(locale: str) -> str:
    key = (locale or "ru").split("-")[0].lower()
    return key if key in SUPPORTED_LOCALES else "en"


def _locale_pack(locale: str) -> dict[str, str]:
    key = _locale_key(locale)
    path = LOCALE_PACKS / f"{key}.json"
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return dict(data.get("messages", data.get("translations", data)))


def _sign_label(sign_id: str, locale: str) -> str:
    english = SIGN_ENGLISH_LABELS[sign_id]
    return str(_locale_pack(locale).get(english, english))


def _group_label(group_id: str, locale: str) -> str:
    key = _locale_key(locale)
    if key == "ru":
        return GROUP_LABEL_RU[group_id]
    if key == "uk":
        return GROUP_LABEL_UK[group_id]
    return GROUP_LABEL_EN[group_id]


def sign_for_date(value: date) -> str:
    md = value.month * 100 + value.day
    if 321 <= md <= 419:
        return "ARIES"
    if 420 <= md <= 520:
        return "TAURUS"
    if 521 <= md <= 620:
        return "GEMINI"
    if 621 <= md <= 722:
        return "CANCER"
    if 723 <= md <= 822:
        return "LEO"
    if 823 <= md <= 922:
        return "VIRGO"
    if 923 <= md <= 1022:
        return "LIBRA"
    if 1023 <= md <= 1121:
        return "SCORPIO"
    if 1122 <= md <= 1221:
        return "SAGITTARIUS"
    if md >= 1222 or md <= 119:
        return "CAPRICORN"
    if 120 <= md <= 218:
        return "AQUARIUS"
    return "PISCES"


def sign_detail(sign_id: str, locale: str = "ru") -> ZodiacSignDetail | None:
    key = str(sign_id or "").upper()
    if key not in SIGN_ORDER:
        return None
    start, end = SIGN_PERIODS[key]
    group_id = SIGN_GROUPS[key]
    return ZodiacSignDetail(
        sign_id=key,
        symbol=SIGN_SYMBOLS[key],
        label=_sign_label(key, locale),
        locale=_locale_key(locale),
        period_start=start,
        period_end=end,
        wraps_year=(key == "CAPRICORN"),
        group_id=group_id,
        group_label=_group_label(group_id, locale),
        characteristics=list(CHARACTERISTICS_RU[key]),
        characteristics_locale="ru",
        evidence_status="TRADITIONAL_ALTERNATIVE_PRODUCT_COPY",
        product_copy_origin="Brotherhood standalone Zodiac v1 characteristics; not scientific personality evidence",
    )


def catalog_index(locale: str = "ru") -> ZodiacCatalogIndex:
    key = _locale_key(locale)
    return ZodiacCatalogIndex(
        catalog_version=CATALOG_VERSION,
        locale=key,
        sign_count=len(SIGN_ORDER),
        signs=[sign_detail(sign_id, key) for sign_id in SIGN_ORDER],
        disclosure=DISCLOSURE,
    )


def _relation_code(first_sign: str, second_sign: str) -> str:
    a = first_sign.upper()
    b = second_sign.upper()
    if a == b:
        return "SAME_SIGN"
    ga = SIGN_GROUPS[a]
    gb = SIGN_GROUPS[b]
    if ga == gb:
        return "SAME_ELEMENT_GROUP"
    if {ga, gb} in ({"FIRE", "AIR"}, {"EARTH", "WATER"}):
        return "SUPPORTED_CROSS_ELEMENT_GROUP"
    return "OTHER_ELEMENT_PAIR"


def compatibility_score(first_sign: str | None, second_sign: str | None) -> int | None:
    a = str(first_sign or "").upper()
    b = str(second_sign or "").upper()
    if a not in SIGN_GROUPS or b not in SIGN_GROUPS:
        return None
    relation = _relation_code(a, b)
    return {
        "SAME_SIGN": 86,
        "SAME_ELEMENT_GROUP": 90,
        "SUPPORTED_CROSS_ELEMENT_GROUP": 84,
        "OTHER_ELEMENT_PAIR": 66,
    }[relation]


def _input_hash(payload: ZodiacReadingCreate) -> str:
    raw = json.dumps(
        {
            "birth_date": payload.birth_date.isoformat(),
            "calculation_version": CALCULATION_VERSION,
            "catalog_version": CATALOG_VERSION,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_reading(payload: ZodiacReadingCreate, *, created_at) -> ZodiacReadingRecord:
    sign_id = sign_for_date(payload.birth_date)
    detail = sign_detail(sign_id, payload.locale)
    assert detail is not None
    md = payload.birth_date.month * 100 + payload.birth_date.day
    return ZodiacReadingRecord(
        reading_id=uuid4(),
        global_id=payload.global_id,
        global_id_display=str(payload.global_id).zfill(10),
        birth_date=payload.birth_date,
        locale=_locale_key(payload.locale),
        calculation_version=CALCULATION_VERSION,
        catalog_version=CATALOG_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        method_id=METHOD_ID,
        sign=detail,
        month_day_code=md,
        boundary_rule=f"{detail.period_start}..{detail.period_end}" + (" (year wrap)" if detail.wraps_year else ""),
        input_snapshot_hash=_input_hash(payload),
        disclosure=DISCLOSURE,
        created_at=created_at,
    )


def build_compatibility(
    first_global_id: int,
    second_global_id: int,
    first_sign: str,
    second_sign: str,
    *,
    locale: str = "ru",
    created_at,
) -> ZodiacCompatibilityRecord:
    first_id, second_id = sorted((first_global_id, second_global_id))
    if first_id != first_global_id:
        first_sign, second_sign = second_sign, first_sign
    a = str(first_sign).upper()
    b = str(second_sign).upper()
    score = compatibility_score(a, b)
    if score is None:
        raise ValueError("zodiac compatibility requires two supported Zodiac signs")
    relation = _relation_code(a, b)
    left = sign_detail(a, locale)
    right = sign_detail(b, locale)
    assert left is not None and right is not None
    explanations = {
        "SAME_SIGN": "Одинаковый знак: применяется существующее базовое правило Zodiac runtime.",
        "SAME_ELEMENT_GROUP": "Знаки находятся в одной группе существующего базового Zodiac runtime.",
        "SUPPORTED_CROSS_ELEMENT_GROUP": "Пара групп входит в существующую cross-group связь базового Zodiac runtime.",
        "OTHER_ELEMENT_PAIR": "Пара знаков попадает в базовое правило остальных сочетаний Zodiac runtime.",
    }
    return ZodiacCompatibilityRecord(
        comparison_id=uuid4(),
        first_global_id=first_id,
        second_global_id=second_id,
        score=score,
        first_sign=left,
        second_sign=right,
        relation_code=relation,
        explanation=explanations[relation],
        calculation_version=CALCULATION_VERSION,
        catalog_version=CATALOG_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        method_id=METHOD_ID,
        evidence_origin="existing Brotherhood ZodiacEngine/Q28 AS sign-group rule; birth-date sign snapshots frozen in comparison history",
        disclosure=DISCLOSURE,
        created_at=created_at,
    )


def public_spec() -> ZodiacSpecResponse:
    return ZodiacSpecResponse(
        calculation_version=CALCULATION_VERSION,
        catalog_version=CATALOG_VERSION,
        compatibility_version=COMPATIBILITY_VERSION,
        method_id=METHOD_ID,
        source_ids=SOURCE_IDS,
        supported_locales=SUPPORTED_LOCALES,
        sign_count=len(SIGN_ORDER),
        compatibility_rules={
            "SAME_SIGN": 86,
            "SAME_ELEMENT_GROUP": 90,
            "SUPPORTED_CROSS_ELEMENT_GROUP": 84,
            "OTHER_ELEMENT_PAIR": 66,
        },
        compatibility_input_policy="Birth-date-derived basic Zodiac sign only. No natal chart, houses, aspects, Moon, Ascendant or synastry are active in this version.",
        scientific_boundary="ASTRO-001 is negative controlled evidence; AS remains a traditional/alternative opt-in metric and is not psychometric evidence.",
        future_method_boundary="AS_SYNASTRY_V1 is not active and requires a separate exact methodology, astronomical inputs/provenance, privacy review and owner/release approval.",
        disclosure=DISCLOSURE,
    )
