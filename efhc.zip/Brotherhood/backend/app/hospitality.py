from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from threading import RLock
from typing import Any, Iterable
from uuid import UUID, NAMESPACE_URL, uuid4, uuid5
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .assessment_registry import VALID_TEST_IDS
from .database import connection
from .models import (
    HostDetailsResponse,
    HostProfileOwnerRecord,
    HostProfileUpsert,
    HostPublicSummary,
    HospitalityArrivalDetails,
    HospitalityAvailabilityMode,
    HospitalityAvailabilityRecord,
    HospitalityAvailabilityState,
    HospitalityAvailabilityUpsert,
    HospitalityDiscoverySummary,
    HospitalityEligibilityReason,
    HospitalityEligibilityResponse,
    HospitalityRequestEventRecord,
    HospitalityTickResult,
    HospitalityStayVerificationSummary,
    HospitalityReviewState,
    HospitalityPublicReview,
    HospitalityIncidentCreate,
    HospitalityReputationSummary,
    HospitalityRestrictionRecord,
    StayConfirmationRecord,
    StayConfirmationUpsert,
    StayReviewRecord,
    StayReviewUpsert,
    TrustIncident,
    TrustIncidentCreate,
    StayRequestAction,
    StayRequestCreate,
    StayRequestRecord,
    StayRequestStatus,
    StayRequestStatusAction,
)
from .repository import gid, open_direct_conversation, storage_mode, create_incident
from . import storage as memory


HOSPITALITY_PROFILE_CONTRACT = "hospitality-profile-v1"
HOSPITALITY_ELIGIBILITY_CONTRACT = "hospitality-eligibility-v1"
HOSPITALITY_REQUEST_STATE_CONTRACT = "hospitality-request-state-v1"
HOSPITALITY_PRIVATE_PAYLOAD_CONTRACT = "hospitality-private-payload-v1"
HOSPITALITY_STAY_VERIFICATION_CONTRACT = "hospitality-stay-v1"
HOSPITALITY_REVIEW_CONTRACT = "hospitality-review-v1"
HOSPITALITY_REPUTATION_POLICY = "hospitality-reputation-v1"


class HospitalityError(RuntimeError):
    def __init__(self, code: str, message: str, *, status_code: int = 422, details: dict[str, object] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}

    def as_detail(self) -> dict[str, object]:
        return {"code": self.code, "message": self.message, **self.details}


def hospitality_enabled() -> bool:
    return os.getenv("HOSPITALITY_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def require_hospitality_enabled() -> None:
    if not hospitality_enabled():
        raise HospitalityError("HOSPITALITY_DISABLED", "Hospitality feature is disabled", status_code=404)


def _pending_ttl_hours() -> int:
    raw = int(os.getenv("HOSPITALITY_PENDING_TTL_HOURS", "48"))
    if raw <= 0 or raw > 24 * 30:
        raise RuntimeError("HOSPITALITY_PENDING_TTL_HOURS must be between 1 and 720")
    return raw


def _review_window_days() -> int:
    raw = int(os.getenv("HOSPITALITY_REVIEW_WINDOW_DAYS", "7"))
    if raw <= 0 or raw > 90:
        raise RuntimeError("HOSPITALITY_REVIEW_WINDOW_DAYS must be between 1 and 90")
    return raw


def _active_key_version() -> int:
    raw = int(os.getenv("HOSPITALITY_PRIVATE_KEY_ACTIVE_VERSION", "1"))
    if raw <= 0 or raw > 32767:
        raise RuntimeError("HOSPITALITY_PRIVATE_KEY_ACTIVE_VERSION must be a positive smallint")
    return raw


def _key_for_version(version: int) -> bytes:
    encoded = os.getenv(f"HOSPITALITY_PRIVATE_KEY_V{version}_B64", "").strip()
    if not encoded:
        raise RuntimeError(f"HOSPITALITY_PRIVATE_KEY_V{version}_B64 is required")
    try:
        key = base64.b64decode(encoded, validate=True)
    except Exception as exc:  # noqa: BLE001 - normalize environment errors
        raise RuntimeError(f"HOSPITALITY_PRIVATE_KEY_V{version}_B64 is not valid base64") from exc
    if len(key) != 32:
        raise RuntimeError(f"HOSPITALITY_PRIVATE_KEY_V{version}_B64 must decode to exactly 32 bytes")
    return key


def _encrypt_payload(payload: dict[str, object], *, aad: bytes, key_version: int | None = None) -> tuple[bytes, bytes, int]:
    version = key_version if key_version is not None else _active_key_version()
    key = _key_for_version(version)
    nonce = os.urandom(12)
    plaintext = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, aad)
    return ciphertext, nonce, version


def _decrypt_payload(ciphertext: bytes, nonce: bytes, version: int, *, aad: bytes) -> dict[str, object]:
    key = _key_for_version(version)
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, aad)
    value = json.loads(plaintext.decode("utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("Hospitality private payload must decode to an object")
    return value


def _validate_timezone(name: str) -> ZoneInfo:
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise HospitalityError("HOSPITALITY_TIMEZONE_INVALID", "Unknown IANA timezone", details={"timezone_name": name}) from exc


def _completion_due(check_out_date: date, timezone_name: str) -> datetime:
    zone = _validate_timezone(timezone_name)
    local_due = datetime.combine(check_out_date + timedelta(days=1), time.min, tzinfo=zone)
    return local_due.astimezone(timezone.utc)


def _date_range(check_in: date, check_out: date) -> list[date]:
    return [check_in + timedelta(days=offset) for offset in range((check_out - check_in).days)]


def _interval_overlaps(first_start: date, first_end: date, second_start: date, second_end: date) -> bool:
    return first_start < second_end and second_start < first_end


def _validate_required_tests(values: Iterable[str]) -> None:
    unknown = sorted(set(values) - set(VALID_TEST_IDS))
    if unknown:
        raise HospitalityError(
            "HOSPITALITY_REQUIRED_TESTS_INVALID",
            "Unknown assessment code in required_completed_tests",
            status_code=400,
            details={"tests": unknown},
        )


@dataclass
class _HostStored:
    host_global_id: int
    is_hosting_active: bool
    max_guests: int
    max_days: int
    city_id: UUID
    public_area_text: str | None
    timezone_name: str
    sleeping_condition: str
    house_rules: list[str]
    min_required_rating: float
    required_completed_tests: list[str]
    availability_mode: str
    private_location_ciphertext: bytes
    private_location_nonce: bytes
    private_location_key_version: int
    created_at: datetime
    updated_at: datetime


@dataclass
class _AvailabilityStored:
    availability_id: UUID
    host_global_id: int
    date_from: date
    date_to: date
    availability_state: str
    capacity_override: int | None
    created_at: datetime
    updated_at: datetime


@dataclass
class _RequestStored:
    request_id: UUID
    guest_global_id: int
    host_global_id: int
    check_in_date: date
    check_out_date: date
    guests_count: int
    status: str
    response_due_at: datetime
    conversation_id: str
    eligibility_snapshot: dict[str, object]
    create_idempotency_key: str
    rejection_reason: str | None
    cancellation_reason: str | None
    accepted_at: datetime | None
    completed_at: datetime | None
    arrival_details_ciphertext: bytes | None
    arrival_details_nonce: bytes | None
    arrival_details_key_version: int | None
    private_access_expires_at: datetime | None
    review_deadline_at: datetime | None
    version: int
    created_at: datetime
    updated_at: datetime


@dataclass
class _ReviewStored:
    review_id: UUID
    request_id: UUID
    author_global_id: int
    target_global_id: int
    adequacy: int
    rules_compliance: int
    description_accuracy: int
    review_score: float
    review_contract_version: str
    review_text: str | None
    private_feedback_ciphertext: bytes | None
    private_feedback_nonce: bytes | None
    private_feedback_key_version: int | None
    submitted_at: datetime
    published_at: datetime | None
    moderated_at: datetime | None



_MEMORY_HOSTS: dict[int, _HostStored] = {}
_MEMORY_AVAILABILITY: dict[UUID, _AvailabilityStored] = {}
_MEMORY_REQUESTS: dict[UUID, _RequestStored] = {}
_MEMORY_IDEMPOTENCY: dict[tuple[int, str], UUID] = {}
_MEMORY_EVENTS: list[HospitalityRequestEventRecord] = []
_MEMORY_PRIVATE_ACCESS_AUDIT: list[dict[str, object]] = []
_MEMORY_RESTRICTIONS: list[dict[str, object]] = []
_MEMORY_CONFIRMATIONS: dict[tuple[UUID, int], StayConfirmationRecord] = {}
_MEMORY_REVIEWS: dict[tuple[UUID, int], _ReviewStored] = {}
_MEMORY_VERIFIED_STAYS: dict[UUID, UUID] = {}
_MEMORY_LOCK = RLock()


def reset_memory_hospitality() -> None:
    with _MEMORY_LOCK:
        _MEMORY_HOSTS.clear()
        _MEMORY_AVAILABILITY.clear()
        _MEMORY_REQUESTS.clear()
        _MEMORY_IDEMPOTENCY.clear()
        _MEMORY_EVENTS.clear()
        _MEMORY_PRIVATE_ACCESS_AUDIT.clear()
        _MEMORY_RESTRICTIONS.clear()
        _MEMORY_CONFIRMATIONS.clear()
        _MEMORY_REVIEWS.clear()
        _MEMORY_VERIFIED_STAYS.clear()


def _host_aad(host_global_id: int, key_version: int) -> bytes:
    return f"{HOSPITALITY_PRIVATE_PAYLOAD_CONTRACT}:host:{host_global_id}:key:{key_version}".encode("utf-8")


def _request_aad(request_id: UUID, key_version: int) -> bytes:
    return f"{HOSPITALITY_PRIVATE_PAYLOAD_CONTRACT}:request:{request_id}:key:{key_version}".encode("utf-8")


def _review_aad(request_id: UUID, author_global_id: int, key_version: int) -> bytes:
    return f"{HOSPITALITY_PRIVATE_PAYLOAD_CONTRACT}:review:{request_id}:author:{author_global_id}:key:{key_version}".encode("utf-8")


def _encrypt_host_location(host_global_id: int, payload: dict[str, object]) -> tuple[bytes, bytes, int]:
    version = _active_key_version()
    # The AAD includes the key version so ciphertext cannot be silently moved between owners/versions.
    return _encrypt_payload(payload, aad=_host_aad(host_global_id, version), key_version=version)


def _decrypt_host_location(row: _HostStored | dict[str, Any]) -> dict[str, object]:
    host_global_id = int(row.host_global_id if isinstance(row, _HostStored) else row["host_global_id"])
    version = int(row.private_location_key_version if isinstance(row, _HostStored) else row["private_location_key_version"])
    ciphertext = row.private_location_ciphertext if isinstance(row, _HostStored) else row["private_location_ciphertext"]
    nonce = row.private_location_nonce if isinstance(row, _HostStored) else row["private_location_nonce"]
    return _decrypt_payload(bytes(ciphertext), bytes(nonce), version, aad=_host_aad(host_global_id, version))


def _encrypt_arrival_snapshot(request_id: UUID, payload: dict[str, object]) -> tuple[bytes, bytes, int]:
    version = _active_key_version()
    return _encrypt_payload(payload, aad=_request_aad(request_id, version), key_version=version)


def _decrypt_arrival_snapshot(request_id: UUID, ciphertext: bytes, nonce: bytes, version: int) -> dict[str, object]:
    return _decrypt_payload(ciphertext, nonce, version, aad=_request_aad(request_id, version))


def _encrypt_private_feedback(request_id: UUID, author_global_id: int, value: str) -> tuple[bytes, bytes, int]:
    version = _active_key_version()
    return _encrypt_payload({"private_feedback": value}, aad=_review_aad(request_id, author_global_id, version), key_version=version)


def _host_public(row: _HostStored | dict[str, Any]) -> HostPublicSummary:
    get = (lambda key: getattr(row, key)) if isinstance(row, _HostStored) else (lambda key: row[key])
    return HostPublicSummary(
        host_global_id=int(get("host_global_id")),
        host_global_id_display=gid(int(get("host_global_id"))),
        is_hosting_active=bool(get("is_hosting_active")),
        city_id=get("city_id"),
        public_area_text=get("public_area_text"),
        sleeping_condition=str(get("sleeping_condition")),
        max_guests=int(get("max_guests")),
        max_days=int(get("max_days")),
        house_rules=list(get("house_rules")),
        min_required_rating=float(get("min_required_rating")),
        required_completed_tests=list(get("required_completed_tests")),
        availability_mode=str(get("availability_mode")),
    )


def _host_owner(row: _HostStored | dict[str, Any]) -> HostProfileOwnerRecord:
    get = (lambda key: getattr(row, key)) if isinstance(row, _HostStored) else (lambda key: row[key])
    private = _decrypt_host_location(row)
    return HostProfileOwnerRecord(
        host_global_id=int(get("host_global_id")),
        host_global_id_display=gid(int(get("host_global_id"))),
        is_hosting_active=bool(get("is_hosting_active")),
        max_guests=int(get("max_guests")),
        max_days=int(get("max_days")),
        city_id=get("city_id"),
        public_area_text=get("public_area_text"),
        timezone_name=str(get("timezone_name")),
        sleeping_condition=str(get("sleeping_condition")),
        house_rules=list(get("house_rules")),
        min_required_rating=float(get("min_required_rating")),
        required_completed_tests=list(get("required_completed_tests")),
        availability_mode=str(get("availability_mode")),
        private_location=private,
        created_at=get("created_at"),
        updated_at=get("updated_at"),
    )


def _request_record(row: _RequestStored | dict[str, Any]) -> StayRequestRecord:
    get = (lambda key: getattr(row, key)) if isinstance(row, _RequestStored) else (lambda key: row[key])
    return StayRequestRecord(
        request_id=get("request_id"),
        guest_global_id=int(get("guest_global_id")),
        host_global_id=int(get("host_global_id")),
        check_in_date=get("check_in_date"),
        check_out_date=get("check_out_date"),
        guests_count=int(get("guests_count")),
        status=str(get("status")),
        response_due_at=get("response_due_at"),
        conversation_id=get("conversation_id"),
        eligibility_snapshot=dict(get("eligibility_snapshot")),
        rejection_reason=get("rejection_reason"),
        cancellation_reason=get("cancellation_reason"),
        accepted_at=get("accepted_at"),
        completed_at=get("completed_at"),
        private_access_expires_at=get("private_access_expires_at"),
        review_deadline_at=get("review_deadline_at"),
        version=int(get("version")),
        created_at=get("created_at"),
        updated_at=get("updated_at"),
    )


def _memory_account_rating(global_id: int) -> float:
    profile = memory.PROFILES.get(global_id)
    profile_sections = int(getattr(profile, "completed_profile_sections", 0) if profile is not None else 0)
    completed = {
        assessment_id
        for (stored_global_id, assessment_id), item in memory.ASSESSMENT_RESULTS.items()
        if stored_global_id == global_id and item.scoring_version == "scientific-questionnaire-v1" and assessment_id in VALID_TEST_IDS
    }
    return min(100.0, min(50.0, profile_sections * 5.0) + min(50.0, len(completed) * 0.5))


def _memory_completed_tests(global_id: int) -> set[str]:
    return {
        assessment_id
        for (stored_global_id, assessment_id), item in memory.ASSESSMENT_RESULTS.items()
        if stored_global_id == global_id and item.scoring_version == "scientific-questionnaire-v1" and assessment_id in VALID_TEST_IDS
    }


def _memory_active_restriction(global_id: int, scope: str, now: datetime) -> bool:
    return any(
        int(item["global_id"]) == global_id
        and str(item["scope"]) in {scope, "all"}
        and item["starts_at"] <= now
        and (item["ends_at"] is None or item["ends_at"] > now)
        for item in _MEMORY_RESTRICTIONS
    )


def _memory_privacy_allows(guest_global_id: int, host_global_id: int) -> bool:
    profile = memory.PROFILES.get(host_global_id)
    if profile is None:
        return True
    visibility = getattr(profile, "visibility", "discoverable")
    if visibility == "discoverable":
        return True
    # Memory runtime has no full connection relation fixture; private/non-discoverable hosts remain hidden.
    return False


def _postgres_privacy_allows(cur, guest_global_id: int, host_global_id: int) -> bool:
    cur.execute("SELECT visibility FROM profiles WHERE global_id=%s", (host_global_id,))
    row = cur.fetchone()
    if row is None or str(row[0]) == "discoverable":
        return True
    cur.execute(
        """
        SELECT 1 FROM connections
        WHERE first_global_id=LEAST(%s,%s) AND second_global_id=GREATEST(%s,%s) AND status='accepted'
        LIMIT 1
        """,
        (guest_global_id, host_global_id, guest_global_id, host_global_id),
    )
    return cur.fetchone() is not None


def _availability_capacity(
    host: _HostStored | dict[str, Any],
    availability_rows: Iterable[_AvailabilityStored | dict[str, Any]],
    accepted_rows: Iterable[_RequestStored | dict[str, Any]],
    check_in: date,
    check_out: date,
    requested_guests: int,
) -> tuple[bool, bool, int, int]:
    get_host = (lambda key: getattr(host, key)) if isinstance(host, _HostStored) else (lambda key: host[key])
    base_capacity = int(get_host("max_guests"))
    mode = str(get_host("availability_mode"))
    days = _date_range(check_in, check_out)
    if not days:
        return False, False, base_capacity, 0

    date_available = True
    capacity_available = True
    min_capacity = base_capacity
    max_occupied = 0

    def attr(row, key):
        return getattr(row, key) if isinstance(row, (_AvailabilityStored, _RequestStored)) else row[key]

    rows = list(availability_rows)
    accepted = list(accepted_rows)
    for day in days:
        matching = [row for row in rows if attr(row, "date_from") <= day < attr(row, "date_to")]
        if any(str(attr(row, "availability_state")) == HospitalityAvailabilityState.UNAVAILABLE.value for row in matching):
            date_available = False
        available_rows = [row for row in matching if str(attr(row, "availability_state")) == HospitalityAvailabilityState.AVAILABLE.value]
        if mode == HospitalityAvailabilityMode.CALENDAR.value and not available_rows:
            date_available = False

        overrides = [int(attr(row, "capacity_override")) for row in available_rows if attr(row, "capacity_override") is not None]
        day_capacity = min([base_capacity, *overrides]) if overrides else base_capacity
        min_capacity = min(min_capacity, day_capacity)
        occupied = sum(
            int(attr(row, "guests_count"))
            for row in accepted
            if str(attr(row, "status")) == StayRequestStatus.ACCEPTED.value
            and attr(row, "check_in_date") <= day < attr(row, "check_out_date")
        )
        max_occupied = max(max_occupied, occupied)
        if occupied + requested_guests > day_capacity:
            capacity_available = False

    return date_available, capacity_available, min_capacity, max_occupied


def _eligibility_snapshot(response: HospitalityEligibilityResponse, payload: StayRequestCreate) -> dict[str, object]:
    return {
        "contract_version": response.contract_version,
        "guest_account_rating": response.account_rating,
        "host_min_required_rating": response.min_required_rating,
        "required_tests": [],  # overwritten by create after loading host to retain immutable admission terms
        "completed_required_tests": [],
        "missing_tests": list(response.missing_required_tests),
        "guest_count": payload.guests_count,
        "effective_capacity": response.effective_capacity,
        "occupied_capacity": response.occupied_capacity,
        "stay_days": response.stay_days,
        "evaluated_at": datetime.now(timezone.utc).isoformat(),
        # Compatibility and Quality Fit stay independent. The request may carry safe summaries later,
        # but Hospitality never recalculates or weights them inside eligibility.
        "compatibility_summary": {},
        "quality_fit_summary": {},
    }


def _resolve_host_city_id(payload: HostProfileUpsert) -> UUID:
    if payload.city_id is not None:
        return payload.city_id
    city_value = (payload.city_value or "").strip()
    if not city_value:
        raise HospitalityError("HOSPITALITY_CITY_NOT_FOUND", "city_id or city_value is required", status_code=400)
    if storage_mode() == "memory":
        return uuid5(NAMESPACE_URL, f"brotherhood:city:ZZ::{city_value}")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO cities(country_code, region_name, name) VALUES('ZZ','',%s)
                ON CONFLICT(country_code, region_name, name) DO UPDATE SET name=EXCLUDED.name
                RETURNING city_id
                """,
                (city_value,),
            )
            city_id = cur.fetchone()[0]
        conn.commit()
    return city_id


def upsert_host_profile(host_global_id: int, payload: HostProfileUpsert) -> HostProfileOwnerRecord:
    require_hospitality_enabled()
    _validate_required_tests(payload.required_completed_tests)
    payload = payload.model_copy(update={"city_id": _resolve_host_city_id(payload)})
    _validate_timezone(payload.timezone_name)
    ciphertext, nonce, key_version = _encrypt_host_location(host_global_id, payload.private_location.model_dump())
    now = datetime.now(timezone.utc)

    if storage_mode() == "memory":
        with _MEMORY_LOCK:
            existing = _MEMORY_HOSTS.get(host_global_id)
            row = _HostStored(
                host_global_id=host_global_id,
                is_hosting_active=payload.is_hosting_active,
                max_guests=payload.max_guests,
                max_days=payload.max_days,
                city_id=payload.city_id,
                public_area_text=payload.public_area_text,
                timezone_name=payload.timezone_name,
                sleeping_condition=payload.sleeping_condition.value,
                house_rules=list(payload.house_rules),
                min_required_rating=float(payload.min_required_rating),
                required_completed_tests=list(payload.required_completed_tests),
                availability_mode=payload.availability_mode.value,
                private_location_ciphertext=ciphertext,
                private_location_nonce=nonce,
                private_location_key_version=key_version,
                created_at=existing.created_at if existing else now,
                updated_at=now,
            )
            _MEMORY_HOSTS[host_global_id] = row
            if not payload.is_hosting_active:
                for request in _MEMORY_REQUESTS.values():
                    if request.host_global_id == host_global_id and request.status == StayRequestStatus.PENDING.value:
                        request.status = StayRequestStatus.REJECTED.value
                        request.rejection_reason = "HOST_DISABLED_HOSTING"
                        request.version += 1
                        request.updated_at = now
                        _append_memory_event(request, host_global_id, "request_rejected", {"reason_code": "HOST_DISABLED_HOSTING"})
            return _host_owner(row)

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM users WHERE global_id=%s", (host_global_id,))
            if cur.fetchone() is None:
                raise HospitalityError("HOSPITALITY_USER_NOT_FOUND", "Host account does not exist", status_code=404)
            cur.execute("SELECT 1 FROM cities WHERE city_id=%s", (payload.city_id,))
            if cur.fetchone() is None:
                raise HospitalityError("HOSPITALITY_CITY_NOT_FOUND", "Unknown city_id", status_code=400)
            cur.execute(
                """
                INSERT INTO hospitality_host_profiles(
                    host_global_id,is_hosting_active,max_guests,max_days,city_id,public_area_text,timezone_name,
                    sleeping_condition,house_rules,min_required_rating,required_completed_tests,availability_mode,
                    private_location_ciphertext,private_location_nonce,private_location_key_version
                ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s,%s,%s,%s)
                ON CONFLICT(host_global_id) DO UPDATE SET
                    is_hosting_active=EXCLUDED.is_hosting_active,max_guests=EXCLUDED.max_guests,max_days=EXCLUDED.max_days,
                    city_id=EXCLUDED.city_id,public_area_text=EXCLUDED.public_area_text,timezone_name=EXCLUDED.timezone_name,
                    sleeping_condition=EXCLUDED.sleeping_condition,house_rules=EXCLUDED.house_rules,
                    min_required_rating=EXCLUDED.min_required_rating,required_completed_tests=EXCLUDED.required_completed_tests,
                    availability_mode=EXCLUDED.availability_mode,private_location_ciphertext=EXCLUDED.private_location_ciphertext,
                    private_location_nonce=EXCLUDED.private_location_nonce,private_location_key_version=EXCLUDED.private_location_key_version,
                    updated_at=now()
                RETURNING created_at,updated_at
                """,
                (
                    host_global_id, payload.is_hosting_active, payload.max_guests, payload.max_days, payload.city_id,
                    payload.public_area_text, payload.timezone_name, payload.sleeping_condition.value,
                    json.dumps(payload.house_rules, ensure_ascii=False), float(payload.min_required_rating),
                    list(payload.required_completed_tests), payload.availability_mode.value, ciphertext, nonce, key_version,
                ),
            )
            timestamps = cur.fetchone()
            if not payload.is_hosting_active:
                cur.execute(
                    """
                    UPDATE stay_requests SET status='rejected', rejection_reason='HOST_DISABLED_HOSTING',
                        version=version+1, updated_at=now()
                    WHERE host_global_id=%s AND status='pending'
                    RETURNING request_id,conversation_id
                    """,
                    (host_global_id,),
                )
                for request_id, conversation_id in cur.fetchall():
                    cur.execute(
                        "INSERT INTO hospitality_request_events(request_id,conversation_id,actor_global_id,event_type,public_payload) VALUES(%s,%s,%s,'request_rejected',%s::jsonb)",
                        (request_id, conversation_id, host_global_id, json.dumps({"reason_code": "HOST_DISABLED_HOSTING"})),
                    )
        conn.commit()
    # Construct from submitted payload; ciphertext is decrypted only for owner response.
    return HostProfileOwnerRecord(
        host_global_id=host_global_id,
        host_global_id_display=gid(host_global_id),
        created_at=timestamps[0], updated_at=timestamps[1], **payload.model_dump(),
    )


def get_owner_host_profile(host_global_id: int) -> HostProfileOwnerRecord | None:
    require_hospitality_enabled()
    if storage_mode() == "memory":
        row = _MEMORY_HOSTS.get(host_global_id)
        return _host_owner(row) if row else None
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT host_global_id,is_hosting_active,max_guests,max_days,city_id,public_area_text,timezone_name,
                       sleeping_condition,house_rules,min_required_rating,required_completed_tests,availability_mode,
                       private_location_ciphertext,private_location_nonce,private_location_key_version,created_at,updated_at
                FROM hospitality_host_profiles WHERE host_global_id=%s
                """,
                (host_global_id,),
            )
            row = cur.fetchone()
    if not row:
        return None
    keys = ["host_global_id","is_hosting_active","max_guests","max_days","city_id","public_area_text","timezone_name",
            "sleeping_condition","house_rules","min_required_rating","required_completed_tests","availability_mode",
            "private_location_ciphertext","private_location_nonce","private_location_key_version","created_at","updated_at"]
    return _host_owner(dict(zip(keys, row)))


def _get_public_host(host_global_id: int, *, require_active: bool = True) -> HostPublicSummary | None:
    if storage_mode() == "memory":
        row = _MEMORY_HOSTS.get(host_global_id)
        if row is None or (require_active and not row.is_hosting_active):
            return None
        return _host_public(row)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT host_global_id,is_hosting_active,max_guests,max_days,city_id,public_area_text,sleeping_condition,
                       house_rules,min_required_rating,required_completed_tests,availability_mode
                FROM hospitality_host_profiles
                WHERE host_global_id=%s AND (%s=false OR is_hosting_active=true)
                """,
                (host_global_id, require_active),
            )
            row = cur.fetchone()
    if not row:
        return None
    keys = ["host_global_id","is_hosting_active","max_guests","max_days","city_id","public_area_text","sleeping_condition",
            "house_rules","min_required_rating","required_completed_tests","availability_mode"]
    return _host_public(dict(zip(keys, row)))


def _host_visible_to_requester(requester_global_id: int, host_global_id: int) -> bool:
    if requester_global_id == host_global_id:
        return True
    if storage_mode() == "memory":
        if (requester_global_id, host_global_id) in memory.USER_BLOCKS or (host_global_id, requester_global_id) in memory.USER_BLOCKS:
            return False
        return _memory_privacy_allows(requester_global_id, host_global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM user_blocks WHERE (blocker_global_id=%s AND blocked_global_id=%s) OR (blocker_global_id=%s AND blocked_global_id=%s) LIMIT 1",
                (requester_global_id, host_global_id, host_global_id, requester_global_id),
            )
            if cur.fetchone() is not None:
                return False
            return _postgres_privacy_allows(cur, requester_global_id, host_global_id)


def get_host_details(
    requester_global_id: int,
    host_global_id: int,
    *,
    check_in_date: date | None = None,
    check_out_date: date | None = None,
    guests_count: int | None = None,
) -> HostDetailsResponse:
    require_hospitality_enabled()
    host = _get_public_host(host_global_id)
    if host is None or not _host_visible_to_requester(requester_global_id, host_global_id):
        raise HospitalityError("HOSPITALITY_HOST_INACTIVE", "Host is not active or not visible", status_code=404)
    eligibility = None
    supplied = [check_in_date is not None, check_out_date is not None, guests_count is not None]
    if any(supplied) and not all(supplied):
        raise HospitalityError("HOSPITALITY_DATES_INVALID", "check_in_date, check_out_date and guests_count must be supplied together", status_code=400)
    if all(supplied):
        eligibility = evaluate_hospitality_eligibility(
            requester_global_id, host_global_id, check_in_date, check_out_date, int(guests_count)
        )
    return HostDetailsResponse(host=host, eligibility=eligibility)


def list_host_availability(host_global_id: int) -> list[HospitalityAvailabilityRecord]:
    require_hospitality_enabled()
    if storage_mode() == "memory":
        return [
            HospitalityAvailabilityRecord(
                availability_id=row.availability_id, host_global_id=row.host_global_id,
                date_from=row.date_from, date_to=row.date_to, availability_state=row.availability_state,
                capacity_override=row.capacity_override, created_at=row.created_at, updated_at=row.updated_at,
            )
            for row in sorted(_MEMORY_AVAILABILITY.values(), key=lambda item: (item.date_from, str(item.availability_id)))
            if row.host_global_id == host_global_id
        ]
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT availability_id,host_global_id,date_from,date_to,availability_state,capacity_override,created_at,updated_at
                FROM hospitality_availability WHERE host_global_id=%s ORDER BY date_from,availability_id
                """,
                (host_global_id,),
            )
            rows = cur.fetchall()
    return [HospitalityAvailabilityRecord(
        availability_id=row[0], host_global_id=int(row[1]), date_from=row[2], date_to=row[3],
        availability_state=str(row[4]), capacity_override=row[5], created_at=row[6], updated_at=row[7],
    ) for row in rows]


def upsert_host_availability(host_global_id: int, payload: HospitalityAvailabilityUpsert, availability_id: UUID | None = None) -> HospitalityAvailabilityRecord:
    require_hospitality_enabled()
    now = datetime.now(timezone.utc)
    availability_id = availability_id or uuid4()
    if storage_mode() == "memory":
        if host_global_id not in _MEMORY_HOSTS:
            raise HospitalityError("HOSPITALITY_HOST_INACTIVE", "Host profile not found", status_code=404)
        with _MEMORY_LOCK:
            existing = _MEMORY_AVAILABILITY.get(availability_id)
            if existing and existing.host_global_id != host_global_id:
                raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Availability record belongs to another host", status_code=403)
            row = _AvailabilityStored(
                availability_id=availability_id, host_global_id=host_global_id, date_from=payload.date_from,
                date_to=payload.date_to, availability_state=payload.availability_state.value,
                capacity_override=payload.capacity_override, created_at=existing.created_at if existing else now, updated_at=now,
            )
            _MEMORY_AVAILABILITY[availability_id] = row
            return HospitalityAvailabilityRecord(**row.__dict__)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM hospitality_host_profiles WHERE host_global_id=%s", (host_global_id,))
            if cur.fetchone() is None:
                raise HospitalityError("HOSPITALITY_HOST_INACTIVE", "Host profile not found", status_code=404)
            cur.execute(
                """
                INSERT INTO hospitality_availability(availability_id,host_global_id,date_from,date_to,availability_state,capacity_override)
                VALUES(%s,%s,%s,%s,%s,%s)
                ON CONFLICT(availability_id) DO UPDATE SET
                    date_from=EXCLUDED.date_from,date_to=EXCLUDED.date_to,availability_state=EXCLUDED.availability_state,
                    capacity_override=EXCLUDED.capacity_override,updated_at=now()
                WHERE hospitality_availability.host_global_id=EXCLUDED.host_global_id
                RETURNING availability_id,host_global_id,date_from,date_to,availability_state,capacity_override,created_at,updated_at
                """,
                (availability_id, host_global_id, payload.date_from, payload.date_to, payload.availability_state.value, payload.capacity_override),
            )
            row = cur.fetchone()
            if row is None:
                raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Availability record belongs to another host", status_code=403)
        conn.commit()
    return HospitalityAvailabilityRecord(
        availability_id=row[0], host_global_id=int(row[1]), date_from=row[2], date_to=row[3],
        availability_state=str(row[4]), capacity_override=row[5], created_at=row[6], updated_at=row[7],
    )


def delete_host_availability(host_global_id: int, availability_id: UUID) -> bool:
    require_hospitality_enabled()
    if storage_mode() == "memory":
        with _MEMORY_LOCK:
            row = _MEMORY_AVAILABILITY.get(availability_id)
            if row is None:
                return False
            if row.host_global_id != host_global_id:
                raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Availability record belongs to another host", status_code=403)
            del _MEMORY_AVAILABILITY[availability_id]
            return True
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM hospitality_availability WHERE availability_id=%s AND host_global_id=%s RETURNING availability_id", (availability_id, host_global_id))
            deleted = cur.fetchone() is not None
        conn.commit()
    return deleted


def _memory_eligibility(guest_global_id: int, host_global_id: int, check_in: date, check_out: date, guests_count: int) -> HospitalityEligibilityResponse:
    now = datetime.now(timezone.utc)
    host = _MEMORY_HOSTS.get(host_global_id)
    if host is None or not host.is_hosting_active:
        raise HospitalityError("HOSPITALITY_HOST_INACTIVE", "Host is not active or not found", status_code=404)
    if check_out <= check_in:
        raise HospitalityError("HOSPITALITY_DATES_INVALID", "check_out_date must be after check_in_date", status_code=400)
    stay_days = (check_out - check_in).days
    rating = _memory_account_rating(guest_global_id)
    completed = _memory_completed_tests(guest_global_id)
    missing = sorted(set(host.required_completed_tests) - completed)
    availability = [row for row in _MEMORY_AVAILABILITY.values() if row.host_global_id == host_global_id and _interval_overlaps(row.date_from,row.date_to,check_in,check_out)]
    accepted = [row for row in _MEMORY_REQUESTS.values() if row.host_global_id == host_global_id and row.status == StayRequestStatus.ACCEPTED.value and _interval_overlaps(row.check_in_date,row.check_out_date,check_in,check_out)]
    date_available, capacity_available, effective_capacity, occupied = _availability_capacity(host, availability, accepted, check_in, check_out, guests_count)
    blocked = (guest_global_id, host_global_id) in memory.USER_BLOCKS or (host_global_id, guest_global_id) in memory.USER_BLOCKS
    guest_restricted = _memory_active_restriction(guest_global_id, "guest", now)
    host_restricted = _memory_active_restriction(host_global_id, "host", now)
    privacy_ok = _memory_privacy_allows(guest_global_id, host_global_id)
    reasons: list[HospitalityEligibilityReason] = []
    local_today = now.astimezone(_validate_timezone(host.timezone_name)).date()
    if check_in < local_today:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_DATES_INVALID", required=str(local_today), actual=str(check_in)))
    if guest_global_id == host_global_id:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_SELF_REQUEST_FORBIDDEN"))
    if blocked:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_BLOCKED_RELATIONSHIP"))
    if guest_restricted or host_restricted:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_RESTRICTED"))
    if rating < host.min_required_rating:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_RATING_TOO_LOW", required=host.min_required_rating, actual=rating))
    if missing:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_REQUIRED_TESTS_MISSING", tests=missing))
    if guests_count > effective_capacity:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_TOO_MANY_GUESTS", required=effective_capacity, actual=guests_count))
    if stay_days > host.max_days:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_STAY_TOO_LONG", required=host.max_days, actual=stay_days))
    if not date_available:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_DATES_UNAVAILABLE"))
    if date_available and not capacity_available:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_CAPACITY_UNAVAILABLE"))
    if not privacy_ok:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_PRIVACY_RESTRICTED"))
    return HospitalityEligibilityResponse(
        eligible=not reasons, reasons=reasons, account_rating=rating, min_required_rating=host.min_required_rating,
        missing_required_tests=missing, date_available=date_available, capacity_available=capacity_available,
        effective_capacity=effective_capacity, occupied_capacity=occupied, stay_days=stay_days,
    )


def _postgres_eligibility(cur, guest_global_id: int, host_global_id: int, check_in: date, check_out: date, guests_count: int, *, host_for_update: bool = False) -> tuple[HospitalityEligibilityResponse, dict[str, Any]]:
    if check_out <= check_in:
        raise HospitalityError("HOSPITALITY_DATES_INVALID", "check_out_date must be after check_in_date", status_code=400)
    lock = " FOR UPDATE" if host_for_update else ""
    cur.execute(
        f"""
        SELECT host_global_id,is_hosting_active,max_guests,max_days,city_id,public_area_text,timezone_name,sleeping_condition,
               house_rules,min_required_rating,required_completed_tests,availability_mode,private_location_ciphertext,
               private_location_nonce,private_location_key_version,created_at,updated_at
        FROM hospitality_host_profiles WHERE host_global_id=%s{lock}
        """,
        (host_global_id,),
    )
    row = cur.fetchone()
    if row is None or not bool(row[1]):
        raise HospitalityError("HOSPITALITY_HOST_INACTIVE", "Host is not active or not found", status_code=404)
    keys = ["host_global_id","is_hosting_active","max_guests","max_days","city_id","public_area_text","timezone_name","sleeping_condition",
            "house_rules","min_required_rating","required_completed_tests","availability_mode","private_location_ciphertext",
            "private_location_nonce","private_location_key_version","created_at","updated_at"]
    host = dict(zip(keys, row))
    stay_days = (check_out - check_in).days
    cur.execute("SELECT COALESCE(total_rating,0) FROM account_ratings WHERE global_id=%s", (guest_global_id,))
    rating_row = cur.fetchone()
    rating = float(rating_row[0]) if rating_row else 0.0
    cur.execute("SELECT DISTINCT assessment_code FROM assessment_results WHERE global_id=%s AND assessment_version=%s", (guest_global_id, "scientific-questionnaire-v1"))
    completed = {str(item[0]) for item in cur.fetchall()}
    missing = sorted(set(host["required_completed_tests"] or []) - completed)
    cur.execute(
        """
        SELECT availability_id,host_global_id,date_from,date_to,availability_state,capacity_override,created_at,updated_at
        FROM hospitality_availability WHERE host_global_id=%s AND date_from<%s AND date_to>%s
        """,
        (host_global_id, check_out, check_in),
    )
    availability = [dict(zip(["availability_id","host_global_id","date_from","date_to","availability_state","capacity_override","created_at","updated_at"], r)) for r in cur.fetchall()]
    cur.execute(
        """
        SELECT request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status
        FROM stay_requests WHERE host_global_id=%s AND status='accepted' AND check_in_date<%s AND check_out_date>%s
        """,
        (host_global_id, check_out, check_in),
    )
    accepted = [dict(zip(["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status"], r)) for r in cur.fetchall()]
    date_available, capacity_available, effective_capacity, occupied = _availability_capacity(host, availability, accepted, check_in, check_out, guests_count)
    cur.execute(
        "SELECT 1 FROM user_blocks WHERE (blocker_global_id=%s AND blocked_global_id=%s) OR (blocker_global_id=%s AND blocked_global_id=%s) LIMIT 1",
        (guest_global_id, host_global_id, host_global_id, guest_global_id),
    )
    blocked = cur.fetchone() is not None
    now = datetime.now(timezone.utc)
    cur.execute(
        """
        SELECT scope FROM hospitality_restrictions
        WHERE global_id=%s AND scope IN ('guest','all') AND starts_at<=%s AND (ends_at IS NULL OR ends_at>%s)
        LIMIT 1
        """,
        (guest_global_id, now, now),
    )
    guest_restricted = cur.fetchone() is not None
    cur.execute(
        """
        SELECT scope FROM hospitality_restrictions
        WHERE global_id=%s AND scope IN ('host','all') AND starts_at<=%s AND (ends_at IS NULL OR ends_at>%s)
        LIMIT 1
        """,
        (host_global_id, now, now),
    )
    host_restricted = cur.fetchone() is not None
    privacy_ok = _postgres_privacy_allows(cur, guest_global_id, host_global_id)
    reasons: list[HospitalityEligibilityReason] = []
    local_today = now.astimezone(_validate_timezone(str(host["timezone_name"]))).date()
    if check_in < local_today:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_DATES_INVALID", required=str(local_today), actual=str(check_in)))
    if guest_global_id == host_global_id:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_SELF_REQUEST_FORBIDDEN"))
    if blocked:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_BLOCKED_RELATIONSHIP"))
    if guest_restricted or host_restricted:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_RESTRICTED"))
    if rating < float(host["min_required_rating"]):
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_RATING_TOO_LOW", required=float(host["min_required_rating"]), actual=rating))
    if missing:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_REQUIRED_TESTS_MISSING", tests=missing))
    if guests_count > effective_capacity:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_TOO_MANY_GUESTS", required=effective_capacity, actual=guests_count))
    if stay_days > int(host["max_days"]):
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_STAY_TOO_LONG", required=int(host["max_days"]), actual=stay_days))
    if not date_available:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_DATES_UNAVAILABLE"))
    if date_available and not capacity_available:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_CAPACITY_UNAVAILABLE"))
    if not privacy_ok:
        reasons.append(HospitalityEligibilityReason(code="HOSPITALITY_PRIVACY_RESTRICTED"))
    response = HospitalityEligibilityResponse(
        eligible=not reasons, reasons=reasons, account_rating=rating, min_required_rating=float(host["min_required_rating"]),
        missing_required_tests=missing, date_available=date_available, capacity_available=capacity_available,
        effective_capacity=effective_capacity, occupied_capacity=occupied, stay_days=stay_days,
    )
    return response, host


def evaluate_hospitality_eligibility(guest_global_id: int, host_global_id: int, check_in_date: date, check_out_date: date, guests_count: int) -> HospitalityEligibilityResponse:
    require_hospitality_enabled()
    if guests_count <= 0:
        raise HospitalityError("HOSPITALITY_TOO_MANY_GUESTS", "guests_count must be positive", status_code=400)
    if storage_mode() == "memory":
        return _memory_eligibility(guest_global_id, host_global_id, check_in_date, check_out_date, guests_count)
    with connection() as conn:
        with conn.cursor() as cur:
            response, _ = _postgres_eligibility(cur, guest_global_id, host_global_id, check_in_date, check_out_date, guests_count)
    return response


def _append_memory_event(request: _RequestStored, actor_global_id: int | None, event_type: str, payload: dict[str, object]) -> None:
    _MEMORY_EVENTS.append(HospitalityRequestEventRecord(
        event_id=uuid4(), request_id=request.request_id, conversation_id=request.conversation_id,
        actor_global_id=actor_global_id, event_type=event_type, public_payload=payload, created_at=datetime.now(timezone.utc),
    ))


def _safe_event_payload(request: StayRequestCreate | _RequestStored) -> dict[str, object]:
    return {
        "check_in_date": str(request.check_in_date),
        "check_out_date": str(request.check_out_date),
        "guests_count": int(request.guests_count),
    }


def create_stay_request(guest_global_id: int, payload: StayRequestCreate, *, idempotency_key: str) -> StayRequestRecord:
    require_hospitality_enabled()
    key = idempotency_key.strip()
    if len(key) < 8 or len(key) > 120:
        raise HospitalityError("HOSPITALITY_IDEMPOTENCY_KEY_INVALID", "Idempotency-Key must contain 8..120 characters", status_code=400)

    if storage_mode() == "memory":
        with _MEMORY_LOCK:
            existing_id = _MEMORY_IDEMPOTENCY.get((guest_global_id, key))
            if existing_id is not None:
                return _request_record(_MEMORY_REQUESTS[existing_id])
            eligibility = _memory_eligibility(guest_global_id, payload.host_global_id, payload.check_in_date, payload.check_out_date, payload.guests_count)
            if not eligibility.eligible:
                first = eligibility.reasons[0]
                raise HospitalityError(first.code, "Hospitality eligibility failed", details={"eligibility": eligibility.model_dump(mode="json")})
            host = _MEMORY_HOSTS[payload.host_global_id]
            conversation = open_direct_conversation(guest_global_id, payload.host_global_id)
            now = datetime.now(timezone.utc)
            snapshot = _eligibility_snapshot(eligibility, payload)
            completed = _memory_completed_tests(guest_global_id)
            snapshot["required_tests"] = list(host.required_completed_tests)
            snapshot["completed_required_tests"] = sorted(set(host.required_completed_tests) & completed)
            snapshot["max_guests"] = host.max_guests
            snapshot["max_days"] = host.max_days
            request = _RequestStored(
                request_id=uuid4(), guest_global_id=guest_global_id, host_global_id=payload.host_global_id,
                check_in_date=payload.check_in_date, check_out_date=payload.check_out_date, guests_count=payload.guests_count,
                status=StayRequestStatus.PENDING.value, response_due_at=now + timedelta(hours=_pending_ttl_hours()),
                conversation_id=conversation.id, eligibility_snapshot=snapshot, create_idempotency_key=key,
                rejection_reason=None, cancellation_reason=None, accepted_at=None, completed_at=None,
                arrival_details_ciphertext=None, arrival_details_nonce=None, arrival_details_key_version=None,
                private_access_expires_at=None, review_deadline_at=None, version=1, created_at=now, updated_at=now,
            )
            _MEMORY_REQUESTS[request.request_id] = request
            _MEMORY_IDEMPOTENCY[(guest_global_id, key)] = request.request_id
            _append_memory_event(request, guest_global_id, "request_created", _safe_event_payload(request))
            return _request_record(request)

    request_id = uuid4()
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT request_id FROM stay_requests WHERE guest_global_id=%s AND create_idempotency_key=%s", (guest_global_id, key))
            existing = cur.fetchone()
            if existing:
                conn.rollback()
                record = get_stay_request(guest_global_id, existing[0])
                if record is None:
                    raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Existing request is not visible", status_code=403)
                return record
            eligibility, host = _postgres_eligibility(cur, guest_global_id, payload.host_global_id, payload.check_in_date, payload.check_out_date, payload.guests_count)
            if not eligibility.eligible:
                first = eligibility.reasons[0]
                raise HospitalityError(first.code, "Hospitality eligibility failed", details={"eligibility": eligibility.model_dump(mode="json")})
            # Use the existing canonical conversation service. Direct chat content remains E2EE and is not copied into stay_requests.
        conn.rollback()
    conversation = open_direct_conversation(guest_global_id, payload.host_global_id)
    now = datetime.now(timezone.utc)
    with connection() as conn:
        with conn.cursor() as cur:
            # Re-evaluate before insert because the direct-chat transaction occurred separately.
            eligibility, host = _postgres_eligibility(cur, guest_global_id, payload.host_global_id, payload.check_in_date, payload.check_out_date, payload.guests_count)
            if not eligibility.eligible:
                first = eligibility.reasons[0]
                raise HospitalityError(first.code, "Hospitality eligibility changed before request creation", details={"eligibility": eligibility.model_dump(mode="json")})
            cur.execute("SELECT DISTINCT assessment_code FROM assessment_results WHERE global_id=%s AND assessment_code=ANY(%s)", (guest_global_id, list(host["required_completed_tests"] or [])))
            completed_required = sorted(str(row[0]) for row in cur.fetchall())
            snapshot = _eligibility_snapshot(eligibility, payload)
            snapshot["required_tests"] = list(host["required_completed_tests"] or [])
            snapshot["completed_required_tests"] = completed_required
            snapshot["max_guests"] = int(host["max_guests"])
            snapshot["max_days"] = int(host["max_days"])
            try:
                cur.execute(
                    """
                    INSERT INTO stay_requests(
                        request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status,response_due_at,
                        conversation_id,eligibility_snapshot,create_idempotency_key
                    ) VALUES(%s,%s,%s,%s,%s,%s,'pending',%s,%s,%s::jsonb,%s)
                    RETURNING request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status,response_due_at,
                              conversation_id,eligibility_snapshot,rejection_reason,cancellation_reason,accepted_at,completed_at,
                              private_access_expires_at,review_deadline_at,version,created_at,updated_at
                    """,
                    (request_id, guest_global_id, payload.host_global_id, payload.check_in_date, payload.check_out_date,
                     payload.guests_count, now + timedelta(hours=_pending_ttl_hours()), UUID(str(conversation.id)), json.dumps(snapshot), key),
                )
            except Exception as exc:  # unique idempotency race; fetch stable result when possible
                conn.rollback()
                with connection() as lookup_conn:
                    with lookup_conn.cursor() as lookup_cur:
                        lookup_cur.execute("SELECT request_id FROM stay_requests WHERE guest_global_id=%s AND create_idempotency_key=%s", (guest_global_id, key))
                        raced = lookup_cur.fetchone()
                if raced:
                    record = get_stay_request(guest_global_id, raced[0])
                    if record is not None:
                        return record
                raise exc
            row = cur.fetchone()
            cur.execute(
                "INSERT INTO hospitality_request_events(request_id,conversation_id,actor_global_id,event_type,public_payload) VALUES(%s,%s,%s,'request_created',%s::jsonb)",
                (request_id, UUID(str(conversation.id)), guest_global_id, json.dumps(_safe_event_payload(payload))),
            )
        conn.commit()
    keys = ["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status","response_due_at",
            "conversation_id","eligibility_snapshot","rejection_reason","cancellation_reason","accepted_at","completed_at",
            "private_access_expires_at","review_deadline_at","version","created_at","updated_at"]
    return _request_record(dict(zip(keys, row)))


def list_stay_requests(global_id: int, *, direction: str = "all", status: str | None = None, limit: int = 100, offset: int = 0) -> list[StayRequestRecord]:
    require_hospitality_enabled()
    if direction not in {"incoming", "outgoing", "all"}:
        raise HospitalityError("HOSPITALITY_DIRECTION_INVALID", "direction must be incoming, outgoing or all", status_code=400)
    if status is not None and status not in {item.value for item in StayRequestStatus}:
        raise HospitalityError("HOSPITALITY_STATUS_INVALID", "Unknown stay request status", status_code=400)
    if storage_mode() == "memory":
        rows = []
        for row in _MEMORY_REQUESTS.values():
            if direction == "incoming" and row.host_global_id != global_id:
                continue
            if direction == "outgoing" and row.guest_global_id != global_id:
                continue
            if direction == "all" and global_id not in {row.guest_global_id, row.host_global_id}:
                continue
            if status is not None and row.status != status:
                continue
            rows.append(row)
        rows.sort(key=lambda item: (item.created_at, str(item.request_id)), reverse=True)
        return [_request_record(row) for row in rows[offset:offset+limit]]
    clauses: list[str] = []
    params: list[object] = []
    if direction == "incoming":
        clauses.append("host_global_id=%s"); params.append(global_id)
    elif direction == "outgoing":
        clauses.append("guest_global_id=%s"); params.append(global_id)
    else:
        clauses.append("(guest_global_id=%s OR host_global_id=%s)"); params.extend([global_id,global_id])
    if status is not None:
        clauses.append("status=%s"); params.append(status)
    params.extend([limit,offset])
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status,response_due_at,
                       conversation_id,eligibility_snapshot,rejection_reason,cancellation_reason,accepted_at,completed_at,
                       private_access_expires_at,review_deadline_at,version,created_at,updated_at
                FROM stay_requests WHERE {' AND '.join(clauses)} ORDER BY created_at DESC,request_id DESC LIMIT %s OFFSET %s
                """, tuple(params)
            )
            rows = cur.fetchall()
    keys = ["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status","response_due_at",
            "conversation_id","eligibility_snapshot","rejection_reason","cancellation_reason","accepted_at","completed_at",
            "private_access_expires_at","review_deadline_at","version","created_at","updated_at"]
    return [_request_record(dict(zip(keys,row))) for row in rows]


def get_stay_request(global_id: int, request_id: UUID) -> StayRequestRecord | None:
    require_hospitality_enabled()
    if storage_mode() == "memory":
        row = _MEMORY_REQUESTS.get(request_id)
        if row is None:
            return None
        if global_id not in {row.guest_global_id,row.host_global_id}:
            raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Request is visible only to participants", status_code=403)
        return _request_record(row)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status,response_due_at,
                       conversation_id,eligibility_snapshot,rejection_reason,cancellation_reason,accepted_at,completed_at,
                       private_access_expires_at,review_deadline_at,version,created_at,updated_at
                FROM stay_requests WHERE request_id=%s
                """, (request_id,)
            )
            row=cur.fetchone()
    if row is None:
        return None
    if global_id not in {int(row[1]),int(row[2])}:
        raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Request is visible only to participants", status_code=403)
    keys = ["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status","response_due_at",
            "conversation_id","eligibility_snapshot","rejection_reason","cancellation_reason","accepted_at","completed_at",
            "private_access_expires_at","review_deadline_at","version","created_at","updated_at"]
    return _request_record(dict(zip(keys,row)))


def _memory_recheck_accept(request: _RequestStored, host: _HostStored) -> None:
    now = datetime.now(timezone.utc)
    if (request.guest_global_id,request.host_global_id) in memory.USER_BLOCKS or (request.host_global_id,request.guest_global_id) in memory.USER_BLOCKS:
        raise HospitalityError("HOSPITALITY_BLOCKED_RELATIONSHIP", "Relationship is blocked")
    if _memory_active_restriction(request.guest_global_id,"guest",now) or _memory_active_restriction(request.host_global_id,"host",now):
        raise HospitalityError("HOSPITALITY_RESTRICTED", "Hospitality restriction is active")
    availability = [row for row in _MEMORY_AVAILABILITY.values() if row.host_global_id == host.host_global_id and _interval_overlaps(row.date_from,row.date_to,request.check_in_date,request.check_out_date)]
    accepted = [row for row in _MEMORY_REQUESTS.values() if row.host_global_id == host.host_global_id and row.status == StayRequestStatus.ACCEPTED.value and row.request_id != request.request_id and _interval_overlaps(row.check_in_date,row.check_out_date,request.check_in_date,request.check_out_date)]
    date_ok, capacity_ok, _, _ = _availability_capacity(host,availability,accepted,request.check_in_date,request.check_out_date,request.guests_count)
    if not date_ok:
        raise HospitalityError("HOSPITALITY_DATES_UNAVAILABLE", "Dates are no longer available", status_code=409)
    if not capacity_ok:
        raise HospitalityError("HOSPITALITY_CAPACITY_CHANGED", "Capacity changed before acceptance", status_code=409)


def update_stay_request_status(actor_global_id: int, request_id: UUID, payload: StayRequestStatusAction) -> StayRequestRecord:
    require_hospitality_enabled()
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        with _MEMORY_LOCK:
            request = _MEMORY_REQUESTS.get(request_id)
            if request is None:
                raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND", "Stay request not found", status_code=404)
            if request.version != payload.expected_version:
                raise HospitalityError("HOSPITALITY_VERSION_CONFLICT", "Stay request version changed", status_code=409, details={"current_version":request.version})
            if request.status in {StayRequestStatus.REJECTED.value,StayRequestStatus.CANCELLED_BY_GUEST.value,StayRequestStatus.CANCELLED_BY_HOST.value,StayRequestStatus.COMPLETED.value,StayRequestStatus.EXPIRED.value}:
                raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Terminal stay request cannot transition", status_code=409)
            event_type: str
            public_payload: dict[str,object] = {}
            if payload.action == StayRequestAction.ACCEPT:
                if actor_global_id != request.host_global_id or request.status != StayRequestStatus.PENDING.value:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Only host may accept a pending request", status_code=409)
                if request.response_due_at <= now:
                    request.status=StayRequestStatus.EXPIRED.value; request.version+=1; request.updated_at=now
                    _append_memory_event(request,None,"request_expired",{})
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Expired request cannot be accepted", status_code=409)
                host=_MEMORY_HOSTS.get(request.host_global_id)
                if host is None or not host.is_hosting_active:
                    raise HospitalityError("HOSPITALITY_HOST_INACTIVE", "Host is no longer active", status_code=409)
                _memory_recheck_accept(request,host)
                private=_decrypt_host_location(host)
                ciphertext,nonce,key_version=_encrypt_arrival_snapshot(request.request_id,private)
                request.status=StayRequestStatus.ACCEPTED.value; request.accepted_at=now
                request.arrival_details_ciphertext=ciphertext; request.arrival_details_nonce=nonce; request.arrival_details_key_version=key_version
                request.private_access_expires_at=_completion_due(request.check_out_date,host.timezone_name)
                event_type="request_accepted"
            elif payload.action == StayRequestAction.REJECT:
                if actor_global_id != request.host_global_id or request.status != StayRequestStatus.PENDING.value:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Only host may reject a pending request", status_code=409)
                request.status=StayRequestStatus.REJECTED.value; request.rejection_reason=payload.reason; event_type="request_rejected"
            elif payload.action == StayRequestAction.CANCEL_GUEST:
                if actor_global_id != request.guest_global_id or request.status not in {StayRequestStatus.PENDING.value,StayRequestStatus.ACCEPTED.value}:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Guest cannot cancel this request", status_code=409)
                if request.status == StayRequestStatus.ACCEPTED.value:
                    host=_MEMORY_HOSTS[request.host_global_id]; local_today=now.astimezone(_validate_timezone(host.timezone_name)).date()
                    if local_today >= request.check_in_date:
                        raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Guest cancellation is closed at check-in", status_code=409)
                request.status=StayRequestStatus.CANCELLED_BY_GUEST.value; request.cancellation_reason=payload.reason; request.private_access_expires_at=now; event_type="request_cancelled_by_guest"
            elif payload.action == StayRequestAction.CANCEL_HOST:
                if actor_global_id != request.host_global_id or request.status != StayRequestStatus.ACCEPTED.value:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Host may cancel only an accepted request", status_code=409)
                request.status=StayRequestStatus.CANCELLED_BY_HOST.value; request.cancellation_reason=payload.reason; request.private_access_expires_at=now; event_type="request_cancelled_by_host"
            else:
                raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Unsupported action", status_code=409)
            request.version+=1; request.updated_at=now
            if payload.reason: public_payload["reason_present"]=True
            _append_memory_event(request,actor_global_id,event_type,public_payload)
            return _request_record(request)

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status,response_due_at,
                       conversation_id,eligibility_snapshot,rejection_reason,cancellation_reason,accepted_at,completed_at,
                       arrival_details_ciphertext,arrival_details_nonce,arrival_details_key_version,private_access_expires_at,
                       review_deadline_at,version,created_at,updated_at
                FROM stay_requests WHERE request_id=%s FOR UPDATE
                """, (request_id,)
            )
            row=cur.fetchone()
            if row is None:
                raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND", "Stay request not found", status_code=404)
            keys=["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status","response_due_at",
                  "conversation_id","eligibility_snapshot","rejection_reason","cancellation_reason","accepted_at","completed_at",
                  "arrival_details_ciphertext","arrival_details_nonce","arrival_details_key_version","private_access_expires_at",
                  "review_deadline_at","version","created_at","updated_at"]
            request=dict(zip(keys,row))
            if int(request["version"]) != payload.expected_version:
                raise HospitalityError("HOSPITALITY_VERSION_CONFLICT", "Stay request version changed", status_code=409, details={"current_version":int(request["version"])})
            if str(request["status"]) in {StayRequestStatus.REJECTED.value,StayRequestStatus.CANCELLED_BY_GUEST.value,StayRequestStatus.CANCELLED_BY_HOST.value,StayRequestStatus.COMPLETED.value,StayRequestStatus.EXPIRED.value}:
                raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Terminal stay request cannot transition", status_code=409)
            event_type: str
            if payload.action == StayRequestAction.ACCEPT:
                if actor_global_id != int(request["host_global_id"]) or str(request["status"]) != StayRequestStatus.PENDING.value:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Only host may accept a pending request", status_code=409)
                if request["response_due_at"] <= now:
                    cur.execute("UPDATE stay_requests SET status='expired',version=version+1,updated_at=now() WHERE request_id=%s",(request_id,))
                    cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,event_type) VALUES(%s,%s,'request_expired')",(request_id,request["conversation_id"]))
                    conn.commit()
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Expired request cannot be accepted", status_code=409)
                # Locks HostProfile and rechecks current block/restriction/date/capacity without changing admission snapshot.
                _, host = _postgres_eligibility(cur,int(request["guest_global_id"]),int(request["host_global_id"]),request["check_in_date"],request["check_out_date"],int(request["guests_count"]),host_for_update=True)
                # Admission rating/tests are historical snapshot terms; acceptance must recheck operational gates only.
                cur.execute("SELECT 1 FROM user_blocks WHERE (blocker_global_id=%s AND blocked_global_id=%s) OR (blocker_global_id=%s AND blocked_global_id=%s) LIMIT 1",
                            (request["guest_global_id"],request["host_global_id"],request["host_global_id"],request["guest_global_id"]))
                if cur.fetchone(): raise HospitalityError("HOSPITALITY_BLOCKED_RELATIONSHIP","Relationship is blocked",status_code=409)
                cur.execute(
                    """SELECT 1 FROM hospitality_restrictions
                       WHERE ((global_id=%s AND scope IN ('guest','all')) OR (global_id=%s AND scope IN ('host','all')))
                         AND starts_at<=%s AND (ends_at IS NULL OR ends_at>%s) LIMIT 1""",
                    (request["guest_global_id"], request["host_global_id"], now, now),
                )
                if cur.fetchone(): raise HospitalityError("HOSPITALITY_RESTRICTED","Hospitality restriction is active",status_code=409)
                cur.execute("SELECT availability_id,host_global_id,date_from,date_to,availability_state,capacity_override,created_at,updated_at FROM hospitality_availability WHERE host_global_id=%s AND date_from<%s AND date_to>%s",
                            (request["host_global_id"],request["check_out_date"],request["check_in_date"]))
                av=[dict(zip(["availability_id","host_global_id","date_from","date_to","availability_state","capacity_override","created_at","updated_at"],r)) for r in cur.fetchall()]
                cur.execute("SELECT request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status FROM stay_requests WHERE host_global_id=%s AND status='accepted' AND request_id<>%s AND check_in_date<%s AND check_out_date>%s FOR UPDATE",
                            (request["host_global_id"],request_id,request["check_out_date"],request["check_in_date"]))
                accepted=[dict(zip(["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status"],r)) for r in cur.fetchall()]
                date_ok,capacity_ok,_,_=_availability_capacity(host,av,accepted,request["check_in_date"],request["check_out_date"],int(request["guests_count"]))
                if not date_ok: raise HospitalityError("HOSPITALITY_DATES_UNAVAILABLE","Dates are no longer available",status_code=409)
                if not capacity_ok: raise HospitalityError("HOSPITALITY_CAPACITY_CHANGED","Capacity changed before acceptance",status_code=409)
                private=_decrypt_host_location(host)
                ciphertext,nonce,key_version=_encrypt_arrival_snapshot(request_id,private)
                expiry=_completion_due(request["check_out_date"],str(host["timezone_name"]))
                cur.execute("""
                    UPDATE stay_requests SET status='accepted',accepted_at=now(),arrival_details_ciphertext=%s,arrival_details_nonce=%s,
                        arrival_details_key_version=%s,private_access_expires_at=%s,version=version+1,updated_at=now()
                    WHERE request_id=%s
                """,(ciphertext,nonce,key_version,expiry,request_id))
                event_type="request_accepted"
            elif payload.action == StayRequestAction.REJECT:
                if actor_global_id != int(request["host_global_id"]) or str(request["status"]) != StayRequestStatus.PENDING.value:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION","Only host may reject a pending request",status_code=409)
                cur.execute("UPDATE stay_requests SET status='rejected',rejection_reason=%s,version=version+1,updated_at=now() WHERE request_id=%s",(payload.reason,request_id)); event_type="request_rejected"
            elif payload.action == StayRequestAction.CANCEL_GUEST:
                if actor_global_id != int(request["guest_global_id"]) or str(request["status"]) not in {StayRequestStatus.PENDING.value,StayRequestStatus.ACCEPTED.value}:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION","Guest cannot cancel this request",status_code=409)
                if str(request["status"]) == StayRequestStatus.ACCEPTED.value:
                    cur.execute("SELECT timezone_name FROM hospitality_host_profiles WHERE host_global_id=%s",(request["host_global_id"],)); tz=str(cur.fetchone()[0])
                    if now.astimezone(_validate_timezone(tz)).date() >= request["check_in_date"]:
                        raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION","Guest cancellation is closed at check-in",status_code=409)
                cur.execute("UPDATE stay_requests SET status='cancelled_by_guest',cancellation_reason=%s,private_access_expires_at=LEAST(COALESCE(private_access_expires_at,%s),%s),version=version+1,updated_at=now() WHERE request_id=%s",(payload.reason,now,now,request_id)); event_type="request_cancelled_by_guest"
            elif payload.action == StayRequestAction.CANCEL_HOST:
                if actor_global_id != int(request["host_global_id"]) or str(request["status"]) != StayRequestStatus.ACCEPTED.value:
                    raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION","Host may cancel only an accepted request",status_code=409)
                cur.execute("UPDATE stay_requests SET status='cancelled_by_host',cancellation_reason=%s,private_access_expires_at=LEAST(COALESCE(private_access_expires_at,%s),%s),version=version+1,updated_at=now() WHERE request_id=%s",(payload.reason,now,now,request_id)); event_type="request_cancelled_by_host"
            else:
                raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION","Unsupported action",status_code=409)
            cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,actor_global_id,event_type,public_payload) VALUES(%s,%s,%s,%s,%s::jsonb)",
                        (request_id,request["conversation_id"],actor_global_id,event_type,json.dumps({"reason_present": bool(payload.reason)})))
            cur.execute("""
                SELECT request_id,guest_global_id,host_global_id,check_in_date,check_out_date,guests_count,status,response_due_at,
                       conversation_id,eligibility_snapshot,rejection_reason,cancellation_reason,accepted_at,completed_at,
                       private_access_expires_at,review_deadline_at,version,created_at,updated_at FROM stay_requests WHERE request_id=%s
            """,(request_id,)); updated=cur.fetchone()
        conn.commit()
    record_keys=["request_id","guest_global_id","host_global_id","check_in_date","check_out_date","guests_count","status","response_due_at",
                 "conversation_id","eligibility_snapshot","rejection_reason","cancellation_reason","accepted_at","completed_at",
                 "private_access_expires_at","review_deadline_at","version","created_at","updated_at"]
    return _request_record(dict(zip(record_keys,updated)))


def _audit_private_access(request_id: UUID, viewer_global_id: int, granted: bool) -> None:
    if storage_mode() == "memory":
        _MEMORY_PRIVATE_ACCESS_AUDIT.append({
            "audit_id": uuid4(), "request_id": request_id, "viewer_global_id": viewer_global_id,
            "granted": granted, "created_at": datetime.now(timezone.utc),
        })
        return
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO hospitality_private_access_audit(request_id,viewer_global_id,granted) VALUES(%s,%s,%s)",
                (request_id, viewer_global_id, granted),
            )
        conn.commit()


def get_arrival_details(global_id: int, request_id: UUID) -> HospitalityArrivalDetails:
    require_hospitality_enabled()
    now=datetime.now(timezone.utc)
    if storage_mode()=="memory":
        request=_MEMORY_REQUESTS.get(request_id)
        if request is None:
            raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND","Stay request not found",status_code=404)
        if global_id not in {request.guest_global_id,request.host_global_id}:
            _audit_private_access(request_id, global_id, False)
            raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT","Arrival details are participant-only",status_code=403)
        if (request.guest_global_id, request.host_global_id) in memory.USER_BLOCKS or (request.host_global_id, request.guest_global_id) in memory.USER_BLOCKS:
            _audit_private_access(request_id, global_id, False)
            raise HospitalityError("HOSPITALITY_BLOCKED_RELATIONSHIP","Arrival access is disabled after a user block",status_code=403)
        if request.status != StayRequestStatus.ACCEPTED.value or not request.private_access_expires_at or request.private_access_expires_at <= now:
            _audit_private_access(request_id, global_id, False)
            raise HospitalityError("HOSPITALITY_PRIVATE_DETAILS_NOT_AVAILABLE","Arrival details are not available",status_code=403)
        if request.arrival_details_ciphertext is None or request.arrival_details_nonce is None or request.arrival_details_key_version is None:
            _audit_private_access(request_id, global_id, False)
            raise HospitalityError("HOSPITALITY_PRIVATE_DETAILS_NOT_AVAILABLE","Arrival snapshot is missing",status_code=403)
        value=_decrypt_arrival_snapshot(request_id,request.arrival_details_ciphertext,request.arrival_details_nonce,request.arrival_details_key_version)
        _audit_private_access(request_id, global_id, True)
        return HospitalityArrivalDetails(request_id=request_id,private_access_expires_at=request.private_access_expires_at,**value)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT guest_global_id,host_global_id,status,arrival_details_ciphertext,arrival_details_nonce,arrival_details_key_version,private_access_expires_at FROM stay_requests WHERE request_id=%s",(request_id,)); row=cur.fetchone()
            blocked=False
            if row is not None:
                cur.execute(
                    "SELECT 1 FROM user_blocks WHERE (blocker_global_id=%s AND blocked_global_id=%s) OR (blocker_global_id=%s AND blocked_global_id=%s) LIMIT 1",
                    (row[0], row[1], row[1], row[0]),
                )
                blocked=cur.fetchone() is not None
    if row is None:
        raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND","Stay request not found",status_code=404)
    if global_id not in {int(row[0]),int(row[1])}:
        _audit_private_access(request_id, global_id, False)
        raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT","Arrival details are participant-only",status_code=403)
    if blocked:
        _audit_private_access(request_id, global_id, False)
        raise HospitalityError("HOSPITALITY_BLOCKED_RELATIONSHIP","Arrival access is disabled after a user block",status_code=403)
    if str(row[2])!=StayRequestStatus.ACCEPTED.value or row[6] is None or row[6] <= now or row[3] is None or row[4] is None or row[5] is None:
        _audit_private_access(request_id, global_id, False)
        raise HospitalityError("HOSPITALITY_PRIVATE_DETAILS_NOT_AVAILABLE","Arrival details are not available",status_code=403)
    value=_decrypt_arrival_snapshot(request_id,bytes(row[3]),bytes(row[4]),int(row[5]))
    _audit_private_access(request_id, global_id, True)
    return HospitalityArrivalDetails(request_id=request_id,private_access_expires_at=row[6],**value)



def _request_participants(request_id: UUID) -> tuple[int, int, str, datetime | None, datetime | None]:
    if storage_mode() == "memory":
        request = _MEMORY_REQUESTS.get(request_id)
        if request is None:
            raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND", "Stay request not found", status_code=404)
        return request.guest_global_id, request.host_global_id, request.status, request.completed_at, request.review_deadline_at
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT guest_global_id,host_global_id,status,completed_at,review_deadline_at FROM stay_requests WHERE request_id=%s",
                (request_id,),
            )
            row = cur.fetchone()
    if row is None:
        raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND", "Stay request not found", status_code=404)
    return int(row[0]), int(row[1]), str(row[2]), row[3], row[4]


def _assert_request_participant(global_id: int, request_id: UUID) -> tuple[int, int, str, datetime | None, datetime | None]:
    values = _request_participants(request_id)
    if global_id not in {values[0], values[1]}:
        raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Stay request is participant-only", status_code=403)
    return values


def list_conversation_events(global_id: int, conversation_id: UUID | str) -> list[HospitalityRequestEventRecord]:
    """Return structured Hospitality lifecycle cards only to canonical conversation members.

    These events intentionally contain only safe request metadata; direct-chat text remains in the
    existing E2EE channel and is never copied here.
    """
    require_hospitality_enabled()
    cid = str(conversation_id)
    if storage_mode() == "memory":
        meta = memory.CHAT_CONVERSATIONS.get(cid)
        if meta is None or global_id not in meta["members"]:
            raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Conversation is not visible", status_code=403)
        return sorted([item for item in _MEMORY_EVENTS if str(item.conversation_id) == cid], key=lambda item: item.created_at)
    try:
        cid_uuid = UUID(cid)
    except ValueError as exc:
        raise HospitalityError("HOSPITALITY_CONVERSATION_INVALID", "Invalid conversation id", status_code=400) from exc
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM conversation_members WHERE conversation_id=%s AND global_id=%s", (cid_uuid, global_id))
            if cur.fetchone() is None:
                raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Conversation is not visible", status_code=403)
            cur.execute(
                """
                SELECT event_id,request_id,conversation_id,actor_global_id,event_type,public_payload,created_at
                FROM hospitality_request_events
                WHERE conversation_id=%s
                ORDER BY created_at,event_id
                """,
                (cid_uuid,),
            )
            rows = cur.fetchall()
    return [HospitalityRequestEventRecord(
        event_id=row[0], request_id=row[1], conversation_id=row[2], actor_global_id=row[3],
        event_type=row[4], public_payload=row[5] if isinstance(row[5], dict) else json.loads(row[5]), created_at=row[6],
    ) for row in rows]


def _memory_verification_summary(request: _RequestStored) -> HospitalityStayVerificationSummary:
    host_value = _MEMORY_CONFIRMATIONS.get((request.request_id, request.host_global_id))
    guest_value = _MEMORY_CONFIRMATIONS.get((request.request_id, request.guest_global_id))
    blocked_by = None
    for row in (host_value, guest_value):
        if row and row.confirmation.value in {"no_show", "dispute"}:
            blocked_by = row.confirmation.value
            break
    verified = False
    interaction_id = _MEMORY_VERIFIED_STAYS.get(request.request_id)
    if blocked_by is None and host_value and guest_value and host_value.confirmation.value == "stay_occurred" and guest_value.confirmation.value == "stay_occurred" and request.status == StayRequestStatus.COMPLETED.value:
        if interaction_id is None:
            interaction_id = uuid4()
            _MEMORY_VERIFIED_STAYS[request.request_id] = interaction_id
            memory.VERIFIED_INTERACTIONS[request.host_global_id] = memory.VERIFIED_INTERACTIONS.get(request.host_global_id, 0) + 1
            memory.VERIFIED_INTERACTIONS[request.guest_global_id] = memory.VERIFIED_INTERACTIONS.get(request.guest_global_id, 0) + 1
        verified = True
    return HospitalityStayVerificationSummary(
        request_id=request.request_id, verified=verified, interaction_id=interaction_id,
        host_confirmed=bool(host_value and host_value.confirmation.value == "stay_occurred"),
        guest_confirmed=bool(guest_value and guest_value.confirmation.value == "stay_occurred"),
        blocked_by=blocked_by,
    )


def submit_stay_confirmation(global_id: int, request_id: UUID, payload: StayConfirmationUpsert) -> HospitalityStayVerificationSummary:
    require_hospitality_enabled()
    if storage_mode() == "memory":
        with _MEMORY_LOCK:
            request = _MEMORY_REQUESTS.get(request_id)
            if request is None:
                raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND", "Stay request not found", status_code=404)
            if global_id not in {request.guest_global_id, request.host_global_id}:
                raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Stay confirmation is participant-only", status_code=403)
            if request.status != StayRequestStatus.COMPLETED.value:
                raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Stay can be confirmed only after completed", status_code=409)
            key = (request_id, global_id)
            existing = _MEMORY_CONFIRMATIONS.get(key)
            if existing is not None:
                if existing.confirmation != payload.confirmation:
                    raise HospitalityError("HOSPITALITY_CONFIRMATION_CONFLICT", "Confirmation is immutable after submission", status_code=409)
                return _memory_verification_summary(request)
            _MEMORY_CONFIRMATIONS[key] = StayConfirmationRecord(
                request_id=request_id, global_id=global_id, confirmation=payload.confirmation, created_at=datetime.now(timezone.utc)
            )
            return _memory_verification_summary(request)

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT guest_global_id,host_global_id,status,completed_at FROM stay_requests WHERE request_id=%s FOR UPDATE",
                (request_id,),
            )
            request = cur.fetchone()
            if request is None:
                raise HospitalityError("HOSPITALITY_REQUEST_NOT_FOUND", "Stay request not found", status_code=404)
            guest_id, host_id, status, completed_at = int(request[0]), int(request[1]), str(request[2]), request[3]
            if global_id not in {guest_id, host_id}:
                raise HospitalityError("HOSPITALITY_NOT_PARTICIPANT", "Stay confirmation is participant-only", status_code=403)
            if status != StayRequestStatus.COMPLETED.value:
                raise HospitalityError("HOSPITALITY_INVALID_STATE_TRANSITION", "Stay can be confirmed only after completed", status_code=409)
            cur.execute("SELECT confirmation FROM hospitality_stay_confirmations WHERE request_id=%s AND global_id=%s", (request_id, global_id))
            existing = cur.fetchone()
            if existing is not None and str(existing[0]) != payload.confirmation.value:
                raise HospitalityError("HOSPITALITY_CONFIRMATION_CONFLICT", "Confirmation is immutable after submission", status_code=409)
            if existing is None:
                cur.execute(
                    "INSERT INTO hospitality_stay_confirmations(request_id,global_id,confirmation) VALUES(%s,%s,%s)",
                    (request_id, global_id, payload.confirmation.value),
                )
            cur.execute("SELECT global_id,confirmation FROM hospitality_stay_confirmations WHERE request_id=%s", (request_id,))
            confirmations = {int(gid_value): str(value) for gid_value, value in cur.fetchall()}
            blocked_by = next((confirmations.get(gid_value) for gid_value in (host_id, guest_id) if confirmations.get(gid_value) in {"no_show", "dispute"}), None)
            host_confirmed = confirmations.get(host_id) == "stay_occurred"
            guest_confirmed = confirmations.get(guest_id) == "stay_occurred"
            cur.execute(
                "SELECT interaction_id FROM verified_interactions WHERE interaction_type='hospitality_stay' AND verification_data->>'request_id'=%s LIMIT 1",
                (str(request_id),),
            )
            interaction = cur.fetchone()
            verified = interaction is not None
            interaction_id = interaction[0] if interaction else None
            if blocked_by is None and host_confirmed and guest_confirmed and not verified:
                first, second = sorted((guest_id, host_id))
                verification = {
                    "request_id": str(request_id), "verification_contract": HOSPITALITY_STAY_VERIFICATION_CONTRACT,
                    "host_confirmed": True, "guest_confirmed": True,
                    "completed_at": completed_at.isoformat() if completed_at else None,
                }
                cur.execute(
                    """
                    INSERT INTO verified_interactions(first_global_id,second_global_id,interaction_type,verification_data)
                    VALUES(%s,%s,'hospitality_stay',%s::jsonb)
                    ON CONFLICT DO NOTHING
                    RETURNING interaction_id
                    """,
                    (first, second, json.dumps(verification)),
                )
                created = cur.fetchone()
                if created:
                    interaction_id = created[0]
                else:
                    cur.execute(
                        "SELECT interaction_id FROM verified_interactions WHERE interaction_type='hospitality_stay' AND verification_data->>'request_id'=%s LIMIT 1",
                        (str(request_id),),
                    )
                    row = cur.fetchone()
                    interaction_id = row[0] if row else None
                verified = interaction_id is not None
        conn.commit()
    return HospitalityStayVerificationSummary(
        request_id=request_id, verified=verified, interaction_id=interaction_id,
        host_confirmed=host_confirmed, guest_confirmed=guest_confirmed, blocked_by=blocked_by,
    )


def get_stay_verification(global_id: int, request_id: UUID) -> HospitalityStayVerificationSummary:
    require_hospitality_enabled()
    guest_id, host_id, _, _, _ = _assert_request_participant(global_id, request_id)
    if storage_mode() == "memory":
        return _memory_verification_summary(_MEMORY_REQUESTS[request_id])
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT global_id,confirmation FROM hospitality_stay_confirmations WHERE request_id=%s", (request_id,))
            confirmations = {int(gid_value): str(value) for gid_value, value in cur.fetchall()}
            cur.execute(
                "SELECT interaction_id FROM verified_interactions WHERE interaction_type='hospitality_stay' AND verification_data->>'request_id'=%s LIMIT 1",
                (str(request_id),),
            )
            row = cur.fetchone()
    blocked_by = next((confirmations.get(gid_value) for gid_value in (host_id, guest_id) if confirmations.get(gid_value) in {"no_show", "dispute"}), None)
    return HospitalityStayVerificationSummary(
        request_id=request_id, verified=row is not None, interaction_id=row[0] if row else None,
        host_confirmed=confirmations.get(host_id) == "stay_occurred",
        guest_confirmed=confirmations.get(guest_id) == "stay_occurred",
        blocked_by=blocked_by,
    )


def _review_score(payload: StayReviewUpsert) -> float:
    average = (payload.adequacy + payload.rules_compliance + payload.description_accuracy) / 3.0
    return round(((average - 1.0) / 4.0) * 100.0, 2)


def _review_record(row: _ReviewStored, private_feedback: str | None = None) -> StayReviewRecord:
    return StayReviewRecord(
        review_id=row.review_id, request_id=row.request_id, author_global_id=row.author_global_id,
        target_global_id=row.target_global_id, adequacy=row.adequacy, rules_compliance=row.rules_compliance,
        description_accuracy=row.description_accuracy, review_score=row.review_score,
        review_contract_version=row.review_contract_version, review_text=row.review_text,
        private_feedback=private_feedback, submitted_at=row.submitted_at, published_at=row.published_at, moderated_at=row.moderated_at,
    )


def _public_review_from_values(values: dict[str, Any]) -> HospitalityPublicReview:
    return HospitalityPublicReview(
        review_id=values["review_id"], request_id=values["request_id"], author_global_id=int(values["author_global_id"]),
        target_global_id=int(values["target_global_id"]), adequacy=int(values["adequacy"]),
        rules_compliance=int(values["rules_compliance"]), description_accuracy=int(values["description_accuracy"]),
        review_score=float(values["review_score"]), review_contract_version=str(values["review_contract_version"]),
        review_text=values.get("review_text"), submitted_at=values["submitted_at"], published_at=values["published_at"],
    )


def submit_stay_review(global_id: int, request_id: UUID, payload: StayReviewUpsert) -> StayReviewRecord:
    require_hospitality_enabled()
    now = datetime.now(timezone.utc)
    guest_id, host_id, status, _, deadline = _assert_request_participant(global_id, request_id)
    if status != StayRequestStatus.COMPLETED.value or deadline is None or now > deadline:
        raise HospitalityError("HOSPITALITY_REVIEW_NOT_OPEN", "Review window is not open", status_code=409)
    target_id = host_id if global_id == guest_id else guest_id
    score = _review_score(payload)
    ciphertext = nonce = None
    key_version = None
    private_feedback = payload.private_feedback.strip() if payload.private_feedback else None
    if private_feedback:
        ciphertext, nonce, key_version = _encrypt_private_feedback(request_id, global_id, private_feedback)

    if storage_mode() == "memory":
        with _MEMORY_LOCK:
            key = (request_id, global_id)
            existing = _MEMORY_REVIEWS.get(key)
            if existing and existing.published_at is not None:
                raise HospitalityError("HOSPITALITY_REVIEW_ALREADY_SUBMITTED", "Published review is immutable", status_code=409)
            submitted_at = existing.submitted_at if existing else now
            stored = _ReviewStored(
                review_id=existing.review_id if existing else uuid4(), request_id=request_id,
                author_global_id=global_id, target_global_id=target_id,
                adequacy=payload.adequacy, rules_compliance=payload.rules_compliance,
                description_accuracy=payload.description_accuracy, review_score=score,
                review_contract_version=HOSPITALITY_REVIEW_CONTRACT, review_text=payload.review_text,
                private_feedback_ciphertext=ciphertext, private_feedback_nonce=nonce, private_feedback_key_version=key_version,
                submitted_at=submitted_at, published_at=None, moderated_at=None,
            )
            _MEMORY_REVIEWS[key] = stored
            peer = _MEMORY_REVIEWS.get((request_id, target_id))
            if peer is not None and peer.published_at is None:
                for review in (stored, peer):
                    review.published_at = now
                request = _MEMORY_REQUESTS[request_id]
                if not any(item.request_id == request_id and item.event_type == "reviews_published" for item in _MEMORY_EVENTS):
                    _append_memory_event(request, None, "reviews_published", {"publication_rule": "both_submitted"})
            return _review_record(stored, private_feedback=private_feedback)

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT review_id,published_at,submitted_at FROM stay_reviews WHERE request_id=%s AND author_global_id=%s FOR UPDATE", (request_id, global_id))
            existing = cur.fetchone()
            if existing and existing[1] is not None:
                raise HospitalityError("HOSPITALITY_REVIEW_ALREADY_SUBMITTED", "Published review is immutable", status_code=409)
            if existing:
                review_id, _, submitted_at = existing
                cur.execute(
                    """
                    UPDATE stay_reviews SET target_global_id=%s,adequacy=%s,rules_compliance=%s,description_accuracy=%s,
                        review_score=%s,review_contract_version=%s,review_text=%s,private_feedback_ciphertext=%s,
                        private_feedback_nonce=%s,private_feedback_key_version=%s
                    WHERE review_id=%s
                    """,
                    (target_id,payload.adequacy,payload.rules_compliance,payload.description_accuracy,score,HOSPITALITY_REVIEW_CONTRACT,
                     payload.review_text,ciphertext,nonce,key_version,review_id),
                )
            else:
                review_id = uuid4(); submitted_at = now
                cur.execute(
                    """
                    INSERT INTO stay_reviews(review_id,request_id,author_global_id,target_global_id,adequacy,rules_compliance,
                        description_accuracy,review_score,review_contract_version,review_text,private_feedback_ciphertext,
                        private_feedback_nonce,private_feedback_key_version,submitted_at)
                    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    """,
                    (review_id,request_id,global_id,target_id,payload.adequacy,payload.rules_compliance,payload.description_accuracy,
                     score,HOSPITALITY_REVIEW_CONTRACT,payload.review_text,ciphertext,nonce,key_version,submitted_at),
                )
            cur.execute("SELECT count(*) FROM stay_reviews WHERE request_id=%s", (request_id,))
            both_submitted = int(cur.fetchone()[0]) >= 2
            published_at = None
            if both_submitted:
                cur.execute("UPDATE stay_reviews SET published_at=COALESCE(published_at,%s) WHERE request_id=%s RETURNING review_id,published_at", (now,request_id))
                rows = cur.fetchall()
                published_at = next((r[1] for r in rows if r[0] == review_id), now)
                cur.execute("SELECT 1 FROM hospitality_request_events WHERE request_id=%s AND event_type='reviews_published' LIMIT 1", (request_id,))
                if cur.fetchone() is None:
                    cur.execute("SELECT conversation_id FROM stay_requests WHERE request_id=%s", (request_id,)); cid=cur.fetchone()[0]
                    cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,event_type,public_payload) VALUES(%s,%s,'reviews_published',%s::jsonb)", (request_id,cid,json.dumps({"publication_rule":"both_submitted"})))
        conn.commit()
    return StayReviewRecord(
        review_id=review_id, request_id=request_id, author_global_id=global_id, target_global_id=target_id,
        adequacy=payload.adequacy, rules_compliance=payload.rules_compliance, description_accuracy=payload.description_accuracy,
        review_score=score, review_contract_version=HOSPITALITY_REVIEW_CONTRACT, review_text=payload.review_text,
        private_feedback=private_feedback, submitted_at=submitted_at, published_at=published_at, moderated_at=None,
    )


def get_review_state(global_id: int, request_id: UUID) -> HospitalityReviewState:
    require_hospitality_enabled()
    _, _, status, _, deadline = _assert_request_participant(global_id, request_id)
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        own = _MEMORY_REVIEWS.get((request_id, global_id))
        published_count = sum(1 for (rid, _), item in _MEMORY_REVIEWS.items() if rid == request_id and item.published_at is not None)
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT published_at FROM stay_reviews WHERE request_id=%s AND author_global_id=%s", (request_id, global_id))
                row = cur.fetchone(); own = row
                cur.execute("SELECT count(*) FROM stay_reviews WHERE request_id=%s AND published_at IS NOT NULL", (request_id,))
                published_count = int(cur.fetchone()[0])
        # Do not reveal whether the peer submitted an unpublished review.
    own_submitted = own is not None
    own_published = bool(own and (own.published_at if isinstance(own, _ReviewStored) else own[0]) is not None)
    return HospitalityReviewState(
        request_id=request_id, can_submit=status == StayRequestStatus.COMPLETED.value and deadline is not None and now <= deadline and not own_published,
        own_submitted=own_submitted, own_published=own_published, review_deadline_at=deadline,
        published_review_count=published_count,
    )


def list_public_hospitality_reviews(target_global_id: int, *, limit: int = 100, offset: int = 0) -> list[HospitalityPublicReview]:
    require_hospitality_enabled()
    if storage_mode() == "memory":
        rows = [item for item in _MEMORY_REVIEWS.values() if item.target_global_id == target_global_id and item.published_at is not None]
        rows.sort(key=lambda item: item.published_at or item.submitted_at, reverse=True)
        return [_public_review_from_values(item.__dict__) for item in rows[offset:offset+limit]]
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT review_id,request_id,author_global_id,target_global_id,adequacy,rules_compliance,description_accuracy,
                       review_score,review_contract_version,review_text,submitted_at,published_at
                FROM stay_reviews WHERE target_global_id=%s AND published_at IS NOT NULL
                ORDER BY published_at DESC LIMIT %s OFFSET %s
                """,
                (target_global_id, limit, offset),
            )
            rows = cur.fetchall()
    keys=["review_id","request_id","author_global_id","target_global_id","adequacy","rules_compliance","description_accuracy","review_score","review_contract_version","review_text","submitted_at","published_at"]
    return [_public_review_from_values(dict(zip(keys,row))) for row in rows]


def hospitality_reputation(global_id: int) -> HospitalityReputationSummary:
    require_hospitality_enabled()
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        verified_request_ids = set(_MEMORY_VERIFIED_STAYS)
        as_host = sum(1 for rid in verified_request_ids if _MEMORY_REQUESTS.get(rid) and _MEMORY_REQUESTS[rid].host_global_id == global_id)
        as_guest = sum(1 for rid in verified_request_ids if _MEMORY_REQUESTS.get(rid) and _MEMORY_REQUESTS[rid].guest_global_id == global_id)
        published = [item for item in _MEMORY_REVIEWS.values() if item.target_global_id == global_id and item.published_at is not None]
        host_scores = [item.review_score for item in published if _MEMORY_REQUESTS[item.request_id].host_global_id == global_id]
        guest_scores = [item.review_score for item in published if _MEMORY_REQUESTS[item.request_id].guest_global_id == global_id]
        active = _memory_active_restriction(global_id, "guest", now) or _memory_active_restriction(global_id, "host", now)
        return HospitalityReputationSummary(
            global_id=global_id, global_id_display=gid(global_id), verified_stays_as_host=as_host, verified_stays_as_guest=as_guest,
            published_reviews=len(published), average_host_review=round(sum(host_scores)/len(host_scores),2) if host_scores else None,
            average_guest_review=round(sum(guest_scores)/len(guest_scores),2) if guest_scores else None,
            active_restriction=active, policy_version=HOSPITALITY_REPUTATION_POLICY,
        )
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                  count(*) FILTER (WHERE sr.host_global_id=%s),
                  count(*) FILTER (WHERE sr.guest_global_id=%s)
                FROM verified_interactions vi
                JOIN stay_requests sr ON sr.request_id::text=vi.verification_data->>'request_id'
                WHERE vi.interaction_type='hospitality_stay' AND (sr.host_global_id=%s OR sr.guest_global_id=%s)
                """,
                (global_id,global_id,global_id,global_id),
            )
            as_host, as_guest = cur.fetchone()
            cur.execute(
                """
                SELECT count(*),
                  avg(r.review_score) FILTER (WHERE sr.host_global_id=%s),
                  avg(r.review_score) FILTER (WHERE sr.guest_global_id=%s)
                FROM stay_reviews r JOIN stay_requests sr ON sr.request_id=r.request_id
                WHERE r.target_global_id=%s AND r.published_at IS NOT NULL
                """,
                (global_id,global_id,global_id),
            )
            count_reviews, host_avg, guest_avg = cur.fetchone()
            cur.execute("SELECT 1 FROM hospitality_restrictions WHERE global_id=%s AND starts_at<=%s AND (ends_at IS NULL OR ends_at>%s) LIMIT 1", (global_id,now,now))
            active = cur.fetchone() is not None
    return HospitalityReputationSummary(
        global_id=global_id, global_id_display=gid(global_id), verified_stays_as_host=int(as_host or 0), verified_stays_as_guest=int(as_guest or 0),
        published_reviews=int(count_reviews or 0), average_host_review=round(float(host_avg),2) if host_avg is not None else None,
        average_guest_review=round(float(guest_avg),2) if guest_avg is not None else None, active_restriction=active,
        policy_version=HOSPITALITY_REPUTATION_POLICY,
    )


def create_hospitality_incident(global_id: int, request_id: UUID, payload: HospitalityIncidentCreate) -> TrustIncident:
    require_hospitality_enabled()
    guest_id, host_id, _, _, _ = _assert_request_participant(global_id, request_id)
    subject = host_id if global_id == guest_id else guest_id
    refs = [f"hospitality_request:{request_id}"] + [value for value in payload.evidence_refs if value != f"hospitality_request:{request_id}"]
    return create_incident(TrustIncidentCreate(
        reporter_global_id=global_id, subject_global_id=subject,
        category=f"hospitality:{payload.reason_code.lower()}", occurred_at=datetime.now(timezone.utc).isoformat(),
        description=payload.description, evidence_refs=refs,
    ))


def apply_hospitality_restriction_from_confirmed_incident(incident_id: str, scope: str, reason_code: str, ends_at: datetime | None) -> HospitalityRestrictionRecord:
    require_hospitality_enabled()
    if scope not in {"guest", "host", "all"}:
        raise HospitalityError("HOSPITALITY_RESTRICTION_SCOPE_INVALID", "Invalid restriction scope", status_code=400)
    now = datetime.now(timezone.utc)
    if ends_at is not None and ends_at <= now:
        raise HospitalityError("HOSPITALITY_RESTRICTION_END_INVALID", "Restriction end must be in the future", status_code=400)
    if storage_mode() == "memory":
        incident = next((item for item in memory.INCIDENTS if item.id == incident_id), None)
        if incident is None:
            raise HospitalityError("HOSPITALITY_INCIDENT_NOT_FOUND", "Trust incident not found", status_code=404)
        if incident.status.value != "confirmed":
            raise HospitalityError("HOSPITALITY_RESTRICTION_REQUIRES_CONFIRMED_DECISION", "Restriction requires confirmed moderation decision", status_code=409)
        if not any(item.incident_id == incident_id and item.decision.value == "confirmed" for item in memory.MODERATION_DECISIONS):
            raise HospitalityError("HOSPITALITY_RESTRICTION_REQUIRES_CONFIRMED_DECISION", "Restriction requires moderation decision evidence", status_code=409)
        existing = next((item for item in _MEMORY_RESTRICTIONS if item["source_incident_id"] == incident_id and item["scope"] == scope), None)
        if existing:
            return HospitalityRestrictionRecord(**existing)
        record = {
            "restriction_id": uuid4(), "global_id": incident.subject_global_id, "scope": scope,
            "source_incident_id": UUID(incident_id) if _looks_like_uuid(incident_id) else uuid4(),
            "reason_code": reason_code, "starts_at": now, "ends_at": ends_at, "created_at": now,
            "source_incident_ref": incident_id,
        }
        _MEMORY_RESTRICTIONS.append(record)
        # model source_incident_id must be UUID; memory incidents use debug strings so a stable local UUID is enough for DTO.
        return HospitalityRestrictionRecord(**{k:v for k,v in record.items() if k != "source_incident_ref"})
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT subject_global_id,status::text FROM trust_incidents WHERE incident_id=%s", (incident_id,))
            row = cur.fetchone()
            if row is None:
                raise HospitalityError("HOSPITALITY_INCIDENT_NOT_FOUND", "Trust incident not found", status_code=404)
            if str(row[1]) != "confirmed":
                raise HospitalityError("HOSPITALITY_RESTRICTION_REQUIRES_CONFIRMED_DECISION", "Restriction requires confirmed moderation decision", status_code=409)
            cur.execute("SELECT 1 FROM moderation_decisions WHERE incident_id=%s AND decision='confirmed'::incident_status LIMIT 1", (incident_id,))
            if cur.fetchone() is None:
                raise HospitalityError("HOSPITALITY_RESTRICTION_REQUIRES_CONFIRMED_DECISION", "Restriction requires moderation decision evidence", status_code=409)
            cur.execute("SELECT restriction_id,global_id,scope,source_incident_id,reason_code,starts_at,ends_at,created_at FROM hospitality_restrictions WHERE source_incident_id=%s AND scope=%s", (incident_id,scope))
            existing = cur.fetchone()
            if existing:
                keys=["restriction_id","global_id","scope","source_incident_id","reason_code","starts_at","ends_at","created_at"]
                return HospitalityRestrictionRecord(**dict(zip(keys,existing)))
            cur.execute(
                """
                INSERT INTO hospitality_restrictions(global_id,scope,source_incident_id,reason_code,starts_at,ends_at)
                VALUES(%s,%s,%s,%s,%s,%s)
                RETURNING restriction_id,global_id,scope,source_incident_id,reason_code,starts_at,ends_at,created_at
                """,
                (int(row[0]),scope,incident_id,reason_code,now,ends_at),
            )
            created = cur.fetchone()
        conn.commit()
    keys=["restriction_id","global_id","scope","source_incident_id","reason_code","starts_at","ends_at","created_at"]
    return HospitalityRestrictionRecord(**dict(zip(keys,created)))


def _looks_like_uuid(value: str) -> bool:
    try:
        UUID(value)
        return True
    except (ValueError, TypeError):
        return False


def hospitality_tick(now: datetime | None = None) -> HospitalityTickResult:
    require_hospitality_enabled()
    current=(now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    expired=0; completed=0; reviews_opened=0; reviews_published=0; restrictions_expired=0
    if storage_mode()=="memory":
        with _MEMORY_LOCK:
            for request in _MEMORY_REQUESTS.values():
                if request.status==StayRequestStatus.PENDING.value and request.response_due_at <= current:
                    request.status=StayRequestStatus.EXPIRED.value; request.version+=1; request.updated_at=current; expired+=1
                    _append_memory_event(request,None,"request_expired",{})
                elif request.status==StayRequestStatus.ACCEPTED.value and request.private_access_expires_at and request.private_access_expires_at <= current:
                    request.status=StayRequestStatus.COMPLETED.value; request.completed_at=current; request.review_deadline_at=current+timedelta(days=_review_window_days()); request.version+=1; request.updated_at=current; completed+=1; reviews_opened+=1
                    _append_memory_event(request,None,"stay_completed",{})
                    _append_memory_event(request,None,"reviews_opened",{"review_deadline_at":request.review_deadline_at.isoformat()})
            request_ids_due = {
                rid for (rid, _), review in _MEMORY_REVIEWS.items()
                if review.published_at is None and _MEMORY_REQUESTS.get(rid) is not None
                and _MEMORY_REQUESTS[rid].review_deadline_at is not None
                and _MEMORY_REQUESTS[rid].review_deadline_at <= current
            }
            for rid in request_ids_due:
                changed = 0
                for (review_request_id, _), review in _MEMORY_REVIEWS.items():
                    if review_request_id == rid and review.published_at is None:
                        review.published_at = current
                        changed += 1
                if changed:
                    reviews_published += changed
                    request = _MEMORY_REQUESTS[rid]
                    if not any(item.request_id == rid and item.event_type == "reviews_published" for item in _MEMORY_EVENTS):
                        _append_memory_event(request,None,"reviews_published",{"publication_rule":"deadline"})
            restrictions_expired = sum(1 for item in _MEMORY_RESTRICTIONS if item["ends_at"] is not None and item["ends_at"] <= current)
        return HospitalityTickResult(
            expired_requests=expired,completed_requests=completed,restrictions_expired=restrictions_expired,
            reviews_opened=reviews_opened,reviews_published=reviews_published,
        )
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("UPDATE stay_requests SET status='expired',version=version+1,updated_at=%s WHERE status='pending' AND response_due_at<=%s RETURNING request_id,conversation_id",(current,current))
            for rid,cid in cur.fetchall():
                expired+=1; cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,event_type,created_at) VALUES(%s,%s,'request_expired',%s)",(rid,cid,current))
            cur.execute("UPDATE stay_requests SET status='completed',completed_at=%s,review_deadline_at=%s,version=version+1,updated_at=%s WHERE status='accepted' AND private_access_expires_at<=%s RETURNING request_id,conversation_id,review_deadline_at",
                        (current,current+timedelta(days=_review_window_days()),current,current))
            for rid,cid,deadline in cur.fetchall():
                completed+=1; reviews_opened+=1
                cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,event_type,created_at) VALUES(%s,%s,'stay_completed',%s)",(rid,cid,current))
                cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,event_type,public_payload,created_at) VALUES(%s,%s,'reviews_opened',%s::jsonb,%s)",(rid,cid,json.dumps({"review_deadline_at":deadline.isoformat()}),current))
            cur.execute(
                """
                SELECT DISTINCT r.request_id,sr.conversation_id
                FROM stay_reviews r JOIN stay_requests sr ON sr.request_id=r.request_id
                WHERE r.published_at IS NULL AND sr.review_deadline_at IS NOT NULL AND sr.review_deadline_at<=%s
                FOR UPDATE OF sr
                """,
                (current,),
            )
            due = cur.fetchall()
            for rid,cid in due:
                cur.execute("UPDATE stay_reviews SET published_at=%s WHERE request_id=%s AND published_at IS NULL RETURNING review_id", (current,rid))
                changed = len(cur.fetchall())
                if changed:
                    reviews_published += changed
                    cur.execute("SELECT 1 FROM hospitality_request_events WHERE request_id=%s AND event_type='reviews_published' LIMIT 1", (rid,))
                    if cur.fetchone() is None:
                        cur.execute("INSERT INTO hospitality_request_events(request_id,conversation_id,event_type,public_payload,created_at) VALUES(%s,%s,'reviews_published',%s::jsonb,%s)", (rid,cid,json.dumps({"publication_rule":"deadline"}),current))
            cur.execute("SELECT count(*) FROM hospitality_restrictions WHERE ends_at IS NOT NULL AND ends_at<=%s", (current,))
            restrictions_expired = int(cur.fetchone()[0])
        conn.commit()
    return HospitalityTickResult(
        expired_requests=expired,completed_requests=completed,restrictions_expired=restrictions_expired,
        reviews_opened=reviews_opened,reviews_published=reviews_published,
    )


def hospitality_discovery_summary(
    requester_global_id: int | None,
    host_global_id: int,
    *,
    hospitality_city_id: UUID | None = None,
    sleeping_condition: str | None = None,
    check_in_date: date | None = None,
    check_out_date: date | None = None,
    guests_count: int | None = None,
) -> HospitalityDiscoverySummary | None:
    if not hospitality_enabled():
        return None
    host=_get_public_host(host_global_id)
    if host is None: return None
    if requester_global_id is not None and not _host_visible_to_requester(requester_global_id, host_global_id): return None
    if hospitality_city_id is not None and host.city_id != hospitality_city_id: return None
    if sleeping_condition is not None and host.sleeping_condition.value != sleeping_condition: return None
    eligibility=None
    if requester_global_id is not None and check_in_date is not None and check_out_date is not None and guests_count is not None:
        try:
            eligibility=evaluate_hospitality_eligibility(requester_global_id,host_global_id,check_in_date,check_out_date,guests_count)
        except HospitalityError as exc:
            if exc.code == "HOSPITALITY_HOST_INACTIVE": return None
            raise
    return HospitalityDiscoverySummary(host=host,eligibility=eligibility)
