from __future__ import annotations

from collections import defaultdict
from statistics import mean
from typing import Iterable

from .models import FriendshipPatternAnalysisResponse, FriendshipPatternObservationRecord, FriendshipPatternSignal

ANALYSIS_VERSION = "reverse-friendship-pattern-v1"


def analyze(observations: Iterable[FriendshipPatternObservationRecord]) -> FriendshipPatternAnalysisResponse:
    rows=list(observations)
    friends=[row for row in rows if row.outcome_status=="CONFIRMED_FRIENDSHIP" and row.confirmed_by_both]
    comparisons=[row for row in rows if row.outcome_status=="NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE"]
    buckets: dict[tuple[str,str], dict[str,list[int]]] = defaultdict(lambda:{"friend":[],"comparison":[]})
    for family, attr in (("similarity","similarity_features"),("difference","difference_features"),("method","method_scores")):
        for row in friends:
            for key,val in getattr(row,attr).items(): buckets[(family,key)]["friend"].append(int(val))
        for row in comparisons:
            for key,val in getattr(row,attr).items(): buckets[(family,key)]["comparison"].append(int(val))
    signals=[]
    for (family,key),vals in buckets.items():
        if not vals["friend"] or not vals["comparison"]: continue
        fm=mean(vals["friend"]); cm=mean(vals["comparison"]); delta=fm-cm
        if family=="difference":
            direction="higher_difference_among_friends" if delta>0 else "lower_difference_among_friends"
        else:
            direction="higher_among_friends" if delta>0 else "lower_among_friends"
        signals.append(FriendshipPatternSignal(
            feature_id=key,feature_family=family,friend_mean=round(fm,2),comparison_mean=round(cm,2),
            delta_points=round(delta,2),absolute_signal_points=round(abs(delta),2),
            friend_n=len(vals["friend"]),comparison_n=len(vals["comparison"]),observed_direction=direction,
        ))
    signals.sort(key=lambda row:(-row.absolute_signal_points,row.feature_family,row.feature_id))
    return FriendshipPatternAnalysisResponse(
        analysis_version=ANALYSIS_VERSION,
        confirmed_friendship_pairs=len(friends),comparison_pairs=len(comparisons),top_patterns=signals[:30],
        note="Descriptive reverse-pattern evidence only: observed enrichment/depletion among confirmed friendships versus sufficiently exposed comparison pairs. It is not causal attribution and never changes production scoring automatically. Pre-friendship snapshots are required to reduce selection-vs-convergence leakage.",
    )
