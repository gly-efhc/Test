from __future__ import annotations

import hashlib
import json
import math
import statistics
from pathlib import Path
from typing import Iterable

from .models import (
    AssociativeEventSubmit,
    AssociativeMeasurementResultUpsert,
)

DATA_PATH = Path(__file__).resolve().parent / "data" / "associative_implicit_instruments_v1.json"
CATALOG = json.loads(DATA_PATH.read_text(encoding="utf-8"))
CATALOG_VERSION = CATALOG["catalog_version"]
INSTRUMENTS = CATALOG["instruments"]
BY_ID = {row["method_id"]: row for row in INSTRUMENTS}


def public_catalog() -> list[dict]:
    rows = []
    for item in INSTRUMENTS:
        rows.append({
            "method_id": item["method_id"],
            "title": item["title"],
            "subtitle": item["subtitle"],
            "method_family": item["method_family"],
            "instrument_version": item["instrument_version"],
            "scoring_version": item["scoring_version"],
            "estimated_minutes": item["estimated_minutes"],
            "source_ids": item["source_ids"],
            "result_scope": item["result_scope"],
        })
    return rows


def public_definition(method_id: str) -> dict:
    item = BY_ID[method_id]
    if method_id == "IMPLICIT_ASSOCIATION_RT_V1":
        stimuli = _iat_public_trials(item)
    else:
        stimuli = item["stimuli"]
    return {
        **public_catalog()[list(BY_ID).index(method_id)],
        "stimuli": stimuli,
        "instructions": _instructions(method_id),
    }


def _instructions(method_id: str) -> list[str]:
    if method_id == "WORD_ASSOCIATION_V1":
        return [
            "Пишите первое слово или короткую фразу, которая приходит в голову.",
            "Не ищите правильный ответ и не возвращайтесь к уже завершённым словам.",
            "Brotherhood учитывает ответ и время реакции, но не ставит диагноз по отдельному слову.",
        ]
    if method_id == "ASSOCIATIVE_FREE_CHAIN_V1":
        return [
            "Начните с показанного слова и продолжите цепочку пятью первыми возникающими ассоциациями.",
            "Не объясняйте и не редактируйте цепочку ради красивого результата.",
            "Интерпретация описывает процесс и повторяющиеся темы без универсального словаря символов.",
        ]
    return [
        "Нажимайте левую или правую сторону как можно быстрее, сохраняя точность.",
        "Категории меняются между блоками — сначала прочитайте подписи.",
        "Результат показывает относительный автоматический ассоциативный баланс, а не скрытую истину о человеке.",
    ]


def _iat_public_trials(item: dict) -> list[dict]:
    category_words: dict[str, list[str]] = {
        item["target_a"]["id"]: item["target_a"]["items"],
        item["target_b"]["id"]: item["target_b"]["items"],
        item["attribute_a"]["id"]: item["attribute_a"]["items"],
        item["attribute_b"]["id"]: item["attribute_b"]["items"],
    }
    rows: list[dict] = []
    for block in item["practice_blocks"] + item["critical_blocks"]:
        cats = block["left"] + block["right"]
        for idx in range(block["trial_count"]):
            cat = cats[idx % len(cats)]
            words = category_words[cat]
            word = words[(idx // len(cats)) % len(words)]
            expected = "left" if cat in block["left"] else "right"
            rows.append({
                "stimulus_id": f'{block["block_id"]}_{idx+1:02d}',
                "block_id": block["block_id"],
                "word": word,
                "category_id": cat,
                "left_categories": block["left"],
                "right_categories": block["right"],
                "expected_action": expected,
                "practice": block in item["practice_blocks"],
            })
    return rows


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> int:
    return int(round(max(low, min(high, value))))


def _median(values: Iterable[int]) -> float:
    vals = [int(x) for x in values if x is not None and int(x) >= 0]
    return float(statistics.median(vals)) if vals else 0.0


def _pace_score(median_ms: float) -> int:
    # Process metric only: 1s or faster -> 100; 7s or slower -> 0.
    return _clamp(100.0 - ((median_ms - 1000.0) / 6000.0) * 100.0)


def _normalize_text(value: str | None) -> str:
    return " ".join((value or "").casefold().strip().split())


def _score_word_association(events: list[AssociativeEventSubmit]) -> tuple[dict[str, int], dict, str]:
    usable = [e for e in events if e.stimulus_id.startswith("wa_")]
    responses = [_normalize_text(e.response_text) for e in usable]
    nonempty = [r for r in responses if r]
    latencies = [e.latency_ms for e in usable if not e.omission and e.response_text]
    edits = sum(e.edit_count for e in usable)
    unique = len(set(nonempty))
    repeats = max(0, len(nonempty) - unique)
    n = max(1, len(usable))
    nonempty_n = max(1, len(nonempty))
    median_ms = _median(latencies)
    features = {
        "response_flow": _clamp(len(nonempty) * 100 / n),
        "spontaneous_pace": _pace_score(median_ms),
        "first_response_stability": _clamp(100 - edits * 100 / n),
        "lexical_variety": _clamp(unique * 100 / nonempty_n),
        "repetition_control": _clamp(100 - repeats * 100 / nonempty_n),
    }
    details = {"median_latency_ms": round(median_ms), "responses_completed": len(nonempty), "stimulus_count": len(usable), "edit_count": edits, "repeat_count": repeats}
    summary = f"Ответы: {len(nonempty)}/{len(usable)}. Медиана первой реакции: {round(median_ms/100)/10:.1f} с. Повторы: {repeats}."
    return features, details, summary


def _score_free_chain(events: list[AssociativeEventSubmit]) -> tuple[dict[str, int], dict, str]:
    usable = [e for e in events if e.stimulus_id.startswith("fa_")]
    responses = [_normalize_text(e.response_text) for e in usable]
    nonempty = [r for r in responses if r]
    latencies = [e.latency_ms for e in usable if e.response_text and not e.omission]
    unique = len(set(nonempty))
    repeats = max(0, len(nonempty) - unique)
    expected = max(1, len(usable))
    median_ms = _median(latencies)
    features = {
        "chain_completion": _clamp(len(nonempty) * 100 / expected),
        "flow_pace": _pace_score(median_ms),
        "lexical_variety": _clamp(unique * 100 / max(1, len(nonempty))),
        "repetition_control": _clamp(100 - repeats * 100 / max(1, len(nonempty))),
        "revision_stability": _clamp(100 - sum(e.edit_count for e in usable) * 100 / expected),
    }
    details = {"median_transition_ms": round(median_ms), "chain_entries": len(nonempty), "expected_entries": expected, "repeat_count": repeats}
    summary = f"Заполнено {len(nonempty)}/{expected} переходов. Медиана перехода: {round(median_ms/100)/10:.1f} с. Уникальных реакций: {unique}."
    return features, details, summary


def _iat_expected_map() -> dict[tuple[str, str], str]:
    definition = public_definition("IMPLICIT_ASSOCIATION_RT_V1")
    return {(x["block_id"], x["stimulus_id"]): x["expected_action"] for x in definition["stimuli"]}


def _iat_d_score(events: list[AssociativeEventSubmit]) -> tuple[float, dict]:
    expected = _iat_expected_map()
    critical = [e for e in events if e.block_id in {"iat_compatible", "iat_incompatible"}]
    valid = [e for e in critical if 250 <= e.latency_ms <= 10000 and (e.block_id, e.stimulus_id) in expected]
    if not valid:
        return 0.0, {"valid_trials": 0, "error_rate": 1.0, "median_latency_ms": 0}
    adjusted: list[tuple[str, float, bool]] = []
    errors = 0
    for e in valid:
        is_error = (e.action or "") != expected[(e.block_id, e.stimulus_id)]
        errors += int(is_error)
        latency = float(e.latency_ms + (600 if is_error else 0))
        adjusted.append((e.block_id or "", latency, is_error))
    comp = [x[1] for x in adjusted if x[0] == "iat_compatible"]
    incomp = [x[1] for x in adjusted if x[0] == "iat_incompatible"]
    if not comp or not incomp:
        return 0.0, {"valid_trials": len(valid), "error_rate": errors / len(valid), "median_latency_ms": round(_median([e.latency_ms for e in valid]))}
    pooled = statistics.pstdev(comp + incomp)
    d = 0.0 if pooled < 1e-9 else (statistics.mean(incomp) - statistics.mean(comp)) / pooled
    d = max(-2.0, min(2.0, d))
    return d, {"valid_trials": len(valid), "error_rate": errors / len(valid), "median_latency_ms": round(_median([e.latency_ms for e in valid])), "compatible_mean_ms": round(statistics.mean(comp)), "incompatible_mean_ms": round(statistics.mean(incomp))}


def _score_iat(events: list[AssociativeEventSubmit]) -> tuple[dict[str, int], dict, str]:
    d, details = _iat_d_score(events)
    balance = _clamp(50 + d * 25)
    error_rate = float(details.get("error_rate", 1.0))
    valid = int(details.get("valid_trials", 0))
    features = {
        "cooperation_association_balance": balance,
        "timing_quality": _clamp(valid * 100 / 32),
        "error_control": _clamp((1.0 - error_rate) * 100),
        "response_pace": _pace_score(float(details.get("median_latency_ms", 0))),
    }
    details = {**details, "d_score": round(d, 4)}
    if balance >= 57:
        label = "Более быстрая относительная связка: сотрудничество + приятное"
    elif balance <= 43:
        label = "Более быстрая относительная связка: соперничество + приятное"
    else:
        label = "Выраженного относительного перекоса в этой сессии не видно"
    summary = f"{label}. Валидных критических проб: {valid}/32; ошибок: {round(error_rate*100)}%."
    return features, details, summary


def score_to_upsert(*, global_id: int, method_id: str, events: list[AssociativeEventSubmit], instrument_locale: str, started_at_epoch_ms: int, completed_at_epoch_ms: int) -> AssociativeMeasurementResultUpsert:
    spec = BY_ID[method_id]
    if method_id == "WORD_ASSOCIATION_V1":
        features, details, summary = _score_word_association(events)
    elif method_id == "ASSOCIATIVE_FREE_CHAIN_V1":
        features, details, summary = _score_free_chain(events)
    elif method_id == "IMPLICIT_ASSOCIATION_RT_V1":
        features, details, summary = _score_iat(events)
    else:
        raise KeyError(method_id)
    payload = [e.model_dump(mode="json") for e in events]
    fingerprint = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    return AssociativeMeasurementResultUpsert(
        global_id=global_id,
        method_id=method_id,
        instrument_version=spec["instrument_version"],
        scoring_version=spec["scoring_version"],
        instrument_locale=instrument_locale,
        started_at_epoch_ms=started_at_epoch_ms,
        completed_at_epoch_ms=completed_at_epoch_ms,
        input_snapshot_hash=fingerprint,
        public_features=features,
        derived_details=details,
        result_title=spec["title"],
        result_summary=summary,
        raw_events=events,
    )


def compatibility(method_id: str, left_features: dict[str, int], right_features: dict[str, int]) -> dict:
    common = sorted(set(left_features) & set(right_features))
    # Quality-only fields are retained in own results but do not define pair similarity.
    common = [key for key in common if key not in {"timing_quality", "error_control"}]
    if not common:
        return {"method_id": method_id, "score": None, "coverage": 0, "feature_scores": {}}
    feature_scores = {key: _clamp(100 - abs(int(left_features[key]) - int(right_features[key]))) for key in common}
    return {
        "method_id": method_id,
        "score": round(sum(feature_scores.values()) / len(feature_scores)),
        "coverage": 100,
        "feature_scores": feature_scores,
    }
