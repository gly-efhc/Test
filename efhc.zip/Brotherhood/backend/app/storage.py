from datetime import datetime, timezone
from threading import Lock
from uuid import uuid4
from .quality_matching import aggregate_latent, parse_desired_qualities, positive_projection, quality_fit
from .localization import translate
from .calibration_pilot import PilotConfig, PilotEnrollmentError, validated_invite_digest
from .models import (
    AssessmentResultRecord,
    AssessmentResultUpsert,
    TestAdministrationSessionRecord,
    CalibrationConsentRecord,
    CalibrationConsentUpsert,
    CompatibilityMetricPreferencesRecord,
    CompatibilityMetricPreferencesUpsert,
    PsychologicalReportHistoryItem,
    PsychologicalReportRecord,
    PsychologicalReportUpsert,
    FriendshipOutcomeRecord,
    FriendshipOutcomeUpsert,
    AssociativeMeasurementResultUpsert,
    AssociativeMeasurementResultPublic,
    FriendshipPatternObservationUpsert,
    FriendshipPatternObservationRecord,
    AuthProvider,
    Community,
    CommunityCreate,
    CommunityKind,
    CommunityMembershipStatus,
    SearchRequestCreate,
    SearchRequestRecord,
    SearchRequestStatus,
    SearchRequestUpdate,
    IdentityResolveRequest,
    IdentityResolveResponse,
    UserSettingsRecord,
    UserSettingsUpsert,
    IncidentStatus,
    NumerologyProfile,
    Person,
    ProfileAvatarRecord,
    Personality32,
    TrustIncident,
    TrustIncidentCreate,
    TrustModerationDecisionRecord,
    TrustAppealRecord,
    MessageCreate,
    MessageRecord,
    AppVersionManifest, AttachmentPayload, ChatAttachmentRecord, ChatMessageCreate, ChatMessageEdit, ChatMessageRecord,
    ConversationSummary, ConversationType, DeviceKeyRecord, DeviceKeyUpsert, DirectConversationCreate,
    EncryptionMode, GroupConversationCreate, ReadReceiptRequest, MessageReactionRecord, PushTokenUpsert, ConversationMemberRecord,
)


def gid(value: int) -> str:
    if value < 1 or value > 9_999_999_999:
        raise ValueError("global_id outside canonical range")
    return f"{value:010d}"


PEOPLE = [
    Person(
        global_id=2, global_id_display=gid(2), name="Андрей", age=36, city="Киев", distance_km=4,
        compatibility=91, trust_score=94, account_rating=86,
        interests=["Футбол", "Автомобили", "Бизнес"], values=["Верность", "Справедливость"],
        lifestyle=["Активный отдых", "Встречи по выходным"],
        personality32=Personality32(code="EPLSG", title="Верный организатор", social_energy=72, perception=38, decision_style=42, life_rhythm=34, bond_style=28),
        enneagram_type=6, zodiac="LEO",
        numerology=NumerologyProfile(soul_number=6, destiny_number=6, name_number=1, maturity_number=7),
        explanation="Совпадают ценности верности, прямой стиль общения и интерес к совместным проектам."
    ),
    Person(
        global_id=3, global_id_display=gid(3), name="Максим", age=40, city="Киев", distance_km=12,
        compatibility=84, trust_score=88, account_rating=72,
        interests=["Спорт", "Путешествия", "Технологии"], values=["Свобода", "Развитие"],
        lifestyle=["Путешествия", "Онлайн-общение"],
        personality32=Personality32(code="EVLFA", title="Свободный изобретатель", social_energy=58, perception=68, decision_style=35, life_rhythm=70, bond_style=55),
        enneagram_type=7, zodiac="AQUARIUS",
        numerology=NumerologyProfile(soul_number=7, destiny_number=6, name_number=8, maturity_number=5),
        explanation="Высокая совместимость по активности, развитию и личным границам."
    ),
    Person(
        global_id=4, global_id_display=gid(4), name="Олег", age=34, city="Львов", distance_km=3,
        compatibility=79, trust_score=96, account_rating=91,
        interests=["Книги", "Футбол", "Взаимопомощь"], values=["Верность", "Вера", "Справедливость"],
        lifestyle=["Спокойный отдых", "Регулярное общение"],
        personality32=Personality32(code="RVHSG", title="Верный советник", social_energy=34, perception=62, decision_style=78, life_rhythm=28, bond_style=22),
        enneagram_type=2, zodiac="SAGITTARIUS",
        numerology=NumerologyProfile(soul_number=6, destiny_number=2, name_number=4, maturity_number=6),
        explanation="Сильное совпадение ценностей и надёжности."
    ),
]

COMMUNITIES = [
    Community(id="c1", title="Футбол по выходным", category="Футбол", city="Киев", members=128,
              kind=CommunityKind.INTEREST, online=False, description="Матчи, команды и совместные просмотры.", verified_only=True),
    Community(id="c2", title="Автомобили и путешествия", category="Автомобили", city="Киев", members=315,
              kind=CommunityKind.INTEREST, online=True, description="Маршруты, обслуживание и взаимопомощь."),
    Community(id="c3", title="Предприниматели Украины", category="Предпринимательство", city="Онлайн", members=524,
              kind=CommunityKind.BUSINESS, online=True, description="Опыт, партнёрства и проверка гипотез.", verified_only=True),
]
COMMUNITY_MEMBERSHIPS: set[tuple[str, int]] = {("c2", 1)}
SEARCH_REQUESTS: dict[str, SearchRequestRecord] = {}



_DEMO_PERSON_CONTENT = {
    2: {"interests": ["Football", "Cars", "Business"], "values": ["Loyalty", "Fairness"], "lifestyle": ["Active leisure", "Weekend meetups"], "explanation": "Compatibility is calculated across all canonical layers separately from Trust Score."},
    3: {"interests": ["Sports", "Travel", "Technology"], "values": ["Freedom", "Growth"], "lifestyle": ["Travel", "Online communication"], "explanation": "Compatibility is calculated across all canonical layers separately from Trust Score."},
    4: {"interests": ["Books", "Football", "Mutual aid"], "values": ["Loyalty", "Faith", "Fairness"], "lifestyle": ["Quiet leisure", "Regular communication"], "explanation": "Compatibility is calculated across all canonical layers separately from Trust Score."},
}

_DEMO_COMMUNITY_CONTENT = {
    "c1": ("Weekend football", "Football", "Matches, teams and watching games together."),
    "c2": ("Cars and travel", "Cars", "Routes, maintenance and mutual aid on the road."),
    "c3": ("Entrepreneurs of Ukraine", "Entrepreneurship", "Experience, partnerships and hypothesis testing."),
}


def _localize_demo_person(person: Person, locale: str) -> Person:
    content = _DEMO_PERSON_CONTENT.get(person.global_id)
    if not content:
        return person
    return person.model_copy(update={
        "interests": [translate(locale, value, fallback=value) for value in content["interests"]],
        "values": [translate(locale, value, fallback=value) for value in content["values"]],
        "lifestyle": [translate(locale, value, fallback=value) for value in content["lifestyle"]],
        "explanation": translate(locale, content["explanation"], fallback=content["explanation"]),
    })


def _localize_demo_community(group: Community, locale: str) -> Community:
    content = _DEMO_COMMUNITY_CONTENT.get(group.id)
    if not content:
        return group
    title, category, description = content
    return group.model_copy(update={
        "title": translate(locale, title, fallback=title),
        "category": translate(locale, category, fallback=category),
        "description": translate(locale, description, fallback=description),
    })

INCIDENTS: list[TrustIncident] = []
MODERATION_DECISIONS: list[TrustModerationDecisionRecord] = []
APPEALS: list[TrustAppealRecord] = []
BASE_TRUST = {1: 92, 2: 94, 3: 88, 4: 96}
VERIFIED_INTERACTIONS = {1: 12, 2: 18, 3: 9, 4: 24}

# The executable MVP uses in-memory identity allocation. PostgreSQL uses an IDENTITY sequence.
VERIFIED_EMAIL_GLOBAL_IDS: dict[str, int] = {"demo@brotherhood.local": 1}

IDENTITIES: dict[tuple[str, str, str], int] = {
    (AuthProvider.EMAIL.value, "default", "demo@brotherhood.local"): 1,
    (AuthProvider.GOOGLE.value, "default", "demo-google-2"): 2,
    (AuthProvider.TELEGRAM.value, "default", "demo-telegram-3"): 3,
    (AuthProvider.FACEBOOK.value, "default", "demo-facebook-4"): 4,
}
_identity_lock = Lock()
_next_global_id = 5


def resolve_identity(payload: IdentityResolveRequest, *, email_normalized: str | None = None) -> IdentityResolveResponse:
    global _next_global_id
    key = (payload.provider.value, payload.tenant, payload.provider_subject)
    verified_email = email_normalized.strip().casefold() if email_normalized else None
    with _identity_lock:
        existing = IDENTITIES.get(key)
        if existing is not None:
            if verified_email:
                linked = VERIFIED_EMAIL_GLOBAL_IDS.get(verified_email)
                if linked is not None and linked != existing:
                    raise ValueError("verified email maps to a different global_id")
                VERIFIED_EMAIL_GLOBAL_IDS[verified_email] = existing
            return IdentityResolveResponse(global_id=existing, global_id_display=gid(existing), created=False)
        linked_global_id = VERIFIED_EMAIL_GLOBAL_IDS.get(verified_email) if verified_email else None
        if linked_global_id is None:
            linked_global_id = _next_global_id
            _next_global_id += 1
            BASE_TRUST.setdefault(linked_global_id, 70)
            VERIFIED_INTERACTIONS.setdefault(linked_global_id, 0)
        IDENTITIES[key] = linked_global_id
        if verified_email:
            VERIFIED_EMAIL_GLOBAL_IDS[verified_email] = linked_global_id
        return IdentityResolveResponse(global_id=linked_global_id, global_id_display=gid(linked_global_id), created=True)


def create_community(payload: CommunityCreate) -> Community:
    data = payload.model_dump(exclude={"owner_global_id"})
    community = Community(id=f"c-{uuid4().hex[:10]}", members=1, **data)
    COMMUNITIES.append(community)
    return community


def set_community_membership(community_id: str, global_id: int, joined: bool) -> CommunityMembershipStatus:
    index = next((i for i, item in enumerate(COMMUNITIES) if item.id == community_id), None)
    if index is None:
        raise ValueError("community not found")
    key = (community_id, global_id)
    already = key in COMMUNITY_MEMBERSHIPS
    if joined and not already:
        COMMUNITY_MEMBERSHIPS.add(key)
        COMMUNITIES[index] = COMMUNITIES[index].model_copy(update={"members": COMMUNITIES[index].members + 1})
    elif not joined and already:
        COMMUNITY_MEMBERSHIPS.discard(key)
        COMMUNITIES[index] = COMMUNITIES[index].model_copy(update={"members": max(0, COMMUNITIES[index].members - 1)})
    return CommunityMembershipStatus(community_id=community_id, global_id=global_id, joined=joined)


def community_membership(community_id: str, global_id: int) -> CommunityMembershipStatus:
    if not any(item.id == community_id for item in COMMUNITIES):
        raise ValueError("community not found")
    return CommunityMembershipStatus(community_id=community_id, global_id=global_id, joined=(community_id, global_id) in COMMUNITY_MEMBERSHIPS)


def create_search_request(owner_global_id: int, payload: SearchRequestCreate) -> SearchRequestRecord:
    from datetime import datetime, timezone
    stamp = datetime.now(timezone.utc)
    record = SearchRequestRecord(
        request_id=uuid4(), owner_global_id=owner_global_id, status=SearchRequestStatus.ACTIVE,
        created_at=stamp, updated_at=stamp, **payload.model_dump()
    )
    SEARCH_REQUESTS[str(record.request_id)] = record
    return record


def list_search_requests(owner_global_id: int, include_archived: bool = False) -> list[SearchRequestRecord]:
    rows = [item for item in SEARCH_REQUESTS.values() if item.owner_global_id == owner_global_id]
    if not include_archived:
        rows = [item for item in rows if item.status != SearchRequestStatus.ARCHIVED]
    return sorted(rows, key=lambda item: item.updated_at, reverse=True)


def get_search_request(owner_global_id: int, request_id: str) -> SearchRequestRecord | None:
    item = SEARCH_REQUESTS.get(request_id)
    return item if item and item.owner_global_id == owner_global_id else None


def update_search_request(owner_global_id: int, request_id: str, payload: SearchRequestUpdate) -> SearchRequestRecord | None:
    from datetime import datetime, timezone
    current = get_search_request(owner_global_id, request_id)
    if current is None:
        return None
    changes = payload.model_dump(exclude_unset=True)
    changes["updated_at"] = datetime.now(timezone.utc)
    updated = current.model_copy(update=changes)
    SEARCH_REQUESTS[request_id] = updated
    return updated


def archive_search_request(owner_global_id: int, request_id: str) -> bool:
    from datetime import datetime, timezone
    current = get_search_request(owner_global_id, request_id)
    if current is None:
        return False
    SEARCH_REQUESTS[request_id] = current.model_copy(update={
        "status": SearchRequestStatus.ARCHIVED, "updated_at": datetime.now(timezone.utc)
    })
    return True


def create_incident(payload: TrustIncidentCreate) -> TrustIncident:
    incident = TrustIncident(id=f"i-{uuid4().hex[:10]}", **payload.model_dump())
    INCIDENTS.append(incident)
    return incident


def moderate_incident(incident_id: str, confirmed: bool) -> TrustIncident | None:
    for index, incident in enumerate(INCIDENTS):
        if incident.id == incident_id:
            updated = incident.model_copy(update={
                "status": IncidentStatus.CONFIRMED if confirmed else IncidentStatus.REJECTED,
                "score_impact": -12 if confirmed else 0,
            })
            INCIDENTS[index] = updated
            return updated
    return None


def moderate_incident_with_decision(incident_id: str, moderator_global_id: int, confirmed: bool, rationale: str) -> tuple[TrustIncident, TrustModerationDecisionRecord] | None:
    updated = moderate_incident(incident_id, confirmed)
    if updated is None:
        return None
    from datetime import datetime, timezone
    record = TrustModerationDecisionRecord(
        decision_id=uuid4(),
        incident_id=incident_id,
        moderator_global_id=moderator_global_id,
        decision=IncidentStatus.CONFIRMED if confirmed else IncidentStatus.REJECTED,
        rationale=rationale,
        created_at=datetime.now(timezone.utc),
    )
    MODERATION_DECISIONS.append(record)
    return updated, record


def create_appeal(incident_id: str, appellant_global_id: int, grounds: str) -> TrustAppealRecord | None:
    from datetime import datetime, timezone
    for index, incident in enumerate(INCIDENTS):
        if incident.id != incident_id:
            continue
        if incident.subject_global_id != appellant_global_id:
            raise PermissionError("appeal is allowed only for the incident subject")
        if incident.status not in {IncidentStatus.CONFIRMED, IncidentStatus.FINAL}:
            raise ValueError("only confirmed/final incidents can be appealed")
        if any(item.incident_id == incident_id and item.appellant_global_id == appellant_global_id and item.status == "pending" for item in APPEALS):
            return next(item for item in APPEALS if item.incident_id == incident_id and item.appellant_global_id == appellant_global_id and item.status == "pending")
        record = TrustAppealRecord(
            appeal_id=uuid4(), incident_id=incident_id, appellant_global_id=appellant_global_id, grounds=grounds,
            status="pending", created_at=datetime.now(timezone.utc),
        )
        APPEALS.append(record)
        INCIDENTS[index] = incident.model_copy(update={"status": IncidentStatus.APPEALED})
        return record
    return None



PROFILE_AVATARS: dict[int, tuple[str, bytes, str, object]] = {}

def upsert_profile_avatar(global_id: int, content_type: str, data: bytes, sha256: str) -> ProfileAvatarRecord:
    from datetime import datetime, timezone
    updated_at = datetime.now(timezone.utc)
    PROFILE_AVATARS[global_id] = (content_type, data, sha256, updated_at)
    return ProfileAvatarRecord(global_id=global_id, content_type=content_type, sha256=sha256, byte_size=len(data), updated_at=updated_at)


CALIBRATION_CONSENTS: dict[int, CalibrationConsentRecord] = {}
CALIBRATION_ATTEMPTS: list[dict[str, object]] = []
CALIBRATION_INVITE_REDEMPTIONS: dict[str, int] = {}
_calibration_lock = Lock()


def _memory_pilot_locale(value: str, config: PilotConfig) -> str:
    normalized = value.strip().lower().replace("_", "-")
    if normalized in config.accepted_locales:
        return normalized
    base = normalized.split("-", 1)[0]
    if base in config.accepted_locales:
        return base
    raise PilotEnrollmentError("unsupported_locale", "instrument locale is not enabled for this pilot", 400)


def calibration_pilot_counts(cohort_id: str, wave_id: str) -> tuple[int, dict[str, int]]:
    counts: dict[str, int] = {}
    for row in CALIBRATION_CONSENTS.values():
        if row.opt_in and row.enrollment_state == "active" and row.cohort_id == cohort_id and row.pilot_wave == wave_id:
            counts[row.instrument_locale] = counts.get(row.instrument_locale, 0) + 1
    return sum(counts.values()), counts


def upsert_calibration_consent(payload: CalibrationConsentUpsert, config: PilotConfig) -> CalibrationConsentRecord:
    from datetime import datetime, timezone
    requested_locale = payload.instrument_locale.strip().lower().replace("_", "-").split("-", 1)[0]
    with _calibration_lock:
        existing = CALIBRATION_CONSENTS.get(payload.global_id)
        locale = _memory_pilot_locale(payload.instrument_locale, config) if payload.opt_in else (existing.instrument_locale if existing else requested_locale)
        existing_active = bool(existing and existing.opt_in and existing.enrollment_state == "active")
        existing_active_current = bool(
            existing_active and existing and existing.cohort_id == config.cohort_id and existing.pilot_wave == config.wave_id
        )
        if payload.opt_in:
            if config.mode == "disabled":
                raise PilotEnrollmentError("pilot_disabled", "controlled calibration pilot is disabled", 403)
            if not payload.eligibility_ack:
                raise PilotEnrollmentError("eligibility_ack_required", "pilot conditions must be acknowledged", 400)
            if payload.consent_version != config.consent_version:
                raise PilotEnrollmentError("consent_version_mismatch", "pilot consent version is not current", 409)
            digest = None
            if config.requires_invite and not existing_active_current:
                digest = validated_invite_digest(payload.invite_code, config)
                if digest is None:
                    raise PilotEnrollmentError("invalid_invite", "valid controlled-pilot invite code is required", 403)
                if digest in CALIBRATION_INVITE_REDEMPTIONS:
                    raise PilotEnrollmentError("invite_already_used", "controlled-pilot invite code was already redeemed", 409)
            total_used, locale_counts = calibration_pilot_counts(config.cohort_id, config.wave_id)
            old_locale = existing.instrument_locale if existing_active_current and existing else None
            if not existing_active_current and total_used >= config.max_participants:
                raise PilotEnrollmentError("pilot_full", "controlled calibration pilot capacity is full", 409)
            locale_used = locale_counts.get(locale, 0)
            if not (existing_active_current and old_locale == locale) and locale_used >= config.locale_limits.get(locale, 0):
                raise PilotEnrollmentError("locale_quota_full", "controlled pilot locale quota is full", 409)
            if digest is not None:
                CALIBRATION_INVITE_REDEMPTIONS[digest] = payload.global_id
            record = CalibrationConsentRecord(
                global_id=payload.global_id,opt_in=True,consent_version=config.consent_version,cohort_id=config.cohort_id,
                instrument_locale=locale,enrollment_state="active",pilot_wave=config.wave_id,updated_at=datetime.now(timezone.utc),
            )
        else:
            record = CalibrationConsentRecord(
                global_id=payload.global_id,opt_in=False,consent_version=config.consent_version,cohort_id=config.cohort_id,
                instrument_locale=locale,enrollment_state="withdrawn",pilot_wave=config.wave_id,updated_at=datetime.now(timezone.utc),
            )
        CALIBRATION_CONSENTS[payload.global_id] = record
        if not payload.opt_in:
            CALIBRATION_ATTEMPTS[:] = [row for row in CALIBRATION_ATTEMPTS if row.get("global_id") != payload.global_id]
        return record


def calibration_consent_for_user(global_id: int) -> CalibrationConsentRecord | None:
    return CALIBRATION_CONSENTS.get(global_id)


def calibration_opted_in(global_id: int) -> bool:
    row = CALIBRATION_CONSENTS.get(global_id)
    return bool(row and row.opt_in)


ASSESSMENT_RESULTS: dict[tuple[int, str], AssessmentResultRecord] = {}


def upsert_assessment_result(payload: AssessmentResultUpsert) -> AssessmentResultRecord:
    key = (payload.global_id, payload.assessment_id)
    existing = ASSESSMENT_RESULTS.get(key)
    consent = CALIBRATION_CONSENTS.get(payload.global_id)
    if consent and consent.opt_in and consent.enrollment_state == "active" and consent.instrument_locale == payload.instrument_locale:
        duplicate = any(
            row.get("global_id") == payload.global_id
            and row.get("assessment_id") == payload.assessment_id
            and row.get("scoring_version") == payload.scoring_version
            and row.get("completed_at_epoch_ms") == payload.completed_at_epoch_ms
            for row in CALIBRATION_ATTEMPTS
        )
        if not duplicate:
            CALIBRATION_ATTEMPTS.append({
                "attempt_id": f"ca-{uuid4().hex[:12]}",
                "global_id": payload.global_id,
                "assessment_id": payload.assessment_id,
                "scoring_version": payload.scoring_version,
                "stimulus_version": payload.stimulus_version,
                "instrument_locale": payload.instrument_locale,
                "cohort_id": consent.cohort_id,
                "consent_version": consent.consent_version,
                "started_at_epoch_ms": payload.started_at_epoch_ms,
                "completed_at_epoch_ms": payload.completed_at_epoch_ms,
                "answer_consistency": payload.answer_consistency,
                "dimensions": [row.model_dump() for row in payload.dimensions],
                "response_trace": [row.model_dump() for row in payload.response_trace],
            })
    safe = payload.model_dump()
    safe["response_trace"] = []
    record = AssessmentResultRecord(
        id=existing.id if existing else f"ar-{uuid4().hex[:10]}",
        **safe,
    )
    ASSESSMENT_RESULTS[key] = record
    return record


def assessment_results_for_user(global_id: int) -> list[AssessmentResultRecord]:
    return [
        item
        for (stored_global_id, _), item in ASSESSMENT_RESULTS.items()
        if stored_global_id == global_id and item.scoring_version == "scientific-questionnaire-v1"
    ]


PSYCHOLOGICAL_REPORTS: dict[int, list[PsychologicalReportRecord]] = {}
COMPATIBILITY_METRIC_PREFERENCES: dict[int, CompatibilityMetricPreferencesRecord] = {}


def upsert_psychological_report(payload: PsychologicalReportUpsert, input_snapshot_hash: str) -> PsychologicalReportRecord:
    from datetime import datetime, timezone
    rows=PSYCHOLOGICAL_REPORTS.setdefault(payload.global_id,[])
    existing=next((row for row in rows if row.report_version == payload.report_version and row.input_snapshot_hash == input_snapshot_hash),None)
    if existing is not None:
        return existing
    record=PsychologicalReportRecord(
        report_id=uuid4(),input_snapshot_hash=input_snapshot_hash,persisted_at=datetime.now(timezone.utc),**payload.model_dump()
    )
    rows.append(record)
    return record


def psychological_report_history(global_id: int) -> list[PsychologicalReportHistoryItem]:
    rows=sorted(PSYCHOLOGICAL_REPORTS.get(global_id,[]),key=lambda row:(row.created_at_epoch_ms,row.persisted_at),reverse=True)
    return [PsychologicalReportHistoryItem(
        report_id=row.report_id,global_id=row.global_id,report_version=row.report_version,model_version=row.model_version,
        created_at_epoch_ms=row.created_at_epoch_ms,input_snapshot_hash=row.input_snapshot_hash,coverage_percent=row.coverage_percent,
        completed_assessment_count=len(row.input_snapshot),persisted_at=row.persisted_at,
    ) for row in rows]


def get_psychological_report(global_id: int, report_id):
    return next((row for row in PSYCHOLOGICAL_REPORTS.get(global_id,[]) if row.report_id == report_id),None)


def latest_psychological_report(global_id: int):
    history=psychological_report_history(global_id)
    return None if not history else get_psychological_report(global_id,history[0].report_id)


def upsert_compatibility_metric_preferences(payload: CompatibilityMetricPreferencesUpsert) -> CompatibilityMetricPreferencesRecord:
    from datetime import datetime, timezone
    record=CompatibilityMetricPreferencesRecord(
        global_id_display=gid(payload.global_id),updated_at=datetime.now(timezone.utc),**payload.model_dump()
    )
    COMPATIBILITY_METRIC_PREFERENCES[payload.global_id]=record
    return record


def get_compatibility_metric_preferences(global_id: int) -> CompatibilityMetricPreferencesRecord | None:
    return COMPATIBILITY_METRIC_PREFERENCES.get(global_id)



ASSOCIATIVE_RESULTS: dict[str, tuple[AssociativeMeasurementResultPublic, list[dict]]] = {}


def upsert_associative_result(payload: AssociativeMeasurementResultUpsert) -> AssociativeMeasurementResultPublic:
    existing = next((row for row, _raw in ASSOCIATIVE_RESULTS.values() if row.global_id == payload.global_id and row.method_id == payload.method_id and row.input_snapshot_hash == payload.input_snapshot_hash), None)
    if existing:
        return existing
    now = datetime.now(timezone.utc)
    result_id = str(uuid4())
    public = AssociativeMeasurementResultPublic(
        result_id=result_id,
        global_id=payload.global_id,
        method_id=payload.method_id,
        instrument_version=payload.instrument_version,
        scoring_version=payload.scoring_version,
        instrument_locale=payload.instrument_locale,
        completed_at_epoch_ms=payload.completed_at_epoch_ms,
        input_snapshot_hash=payload.input_snapshot_hash,
        public_features=dict(payload.public_features),
        derived_details=dict(payload.derived_details),
        result_title=payload.result_title,
        result_summary=payload.result_summary,
        created_at=now,
    )
    ASSOCIATIVE_RESULTS[result_id] = (public, [event.model_dump(mode="json") for event in payload.raw_events])
    return public


def associative_results_for_user(global_id: int) -> list[AssociativeMeasurementResultPublic]:
    rows = [row for row, _raw in ASSOCIATIVE_RESULTS.values() if row.global_id == global_id]
    return sorted(rows, key=lambda row: (row.completed_at_epoch_ms, row.result_id), reverse=True)


def latest_associative_result(global_id: int, method_id: str) -> AssociativeMeasurementResultPublic | None:
    rows = [row for row in associative_results_for_user(global_id) if row.method_id == method_id]
    return rows[0] if rows else None


def associative_raw_result(result_id: str) -> list[dict] | None:
    value = ASSOCIATIVE_RESULTS.get(result_id)
    return None if value is None else list(value[1])


FRIENDSHIP_PATTERN_OBSERVATIONS: dict[str, FriendshipPatternObservationRecord] = {}


def upsert_friendship_pattern_observation(payload: FriendshipPatternObservationUpsert) -> FriendshipPatternObservationRecord:
    first, second = sorted((payload.first_global_id, payload.second_global_id))
    canonical = payload.model_copy(update={"first_global_id": first, "second_global_id": second})
    row = FriendshipPatternObservationRecord(**canonical.model_dump(), created_at=datetime.now(timezone.utc))
    FRIENDSHIP_PATTERN_OBSERVATIONS[payload.observation_id] = row
    return row


def friendship_pattern_observations_for_analysis() -> list[FriendshipPatternObservationRecord]:
    return sorted(FRIENDSHIP_PATTERN_OBSERVATIONS.values(), key=lambda row: (row.snapshot_at, row.observation_id))


FRIENDSHIP_OUTCOMES: dict[str, FriendshipOutcomeRecord] = {}

def upsert_friendship_outcome(payload: FriendshipOutcomeUpsert) -> FriendshipOutcomeRecord:
    from datetime import datetime, timezone
    first_global_id, second_global_id = sorted((payload.first_global_id, payload.second_global_id))
    if first_global_id == second_global_id:
        raise ValueError("friendship outcome requires two different users")
    if payload.searcher_global_id is not None and payload.searcher_global_id not in {first_global_id, second_global_id}:
        raise ValueError("searcher_global_id must belong to the connection pair")
    record = FriendshipOutcomeRecord(
        **payload.model_copy(update={
            "first_global_id": first_global_id,
            "second_global_id": second_global_id,
        }).model_dump(),
        updated_at=datetime.now(timezone.utc),
    )
    FRIENDSHIP_OUTCOMES[payload.connection_id] = record
    return record

def friendship_outcomes_for_analysis() -> list[FriendshipOutcomeRecord]:
    return sorted(FRIENDSHIP_OUTCOMES.values(), key=lambda item: (item.matched_at, item.connection_id))


MESSAGES: list[MessageRecord] = []


def create_message(payload: MessageCreate) -> MessageRecord:
    if payload.sender_global_id == payload.recipient_global_id:
        raise ValueError("sender and recipient must differ")
    existing = next((item for item in MESSAGES if item.client_message_id == payload.client_message_id), None)
    if existing is not None:
        return existing
    record = MessageRecord(id=f"msg-{uuid4().hex[:12]}", status="sent", **payload.model_dump())
    MESSAGES.append(record)
    return record


def messages_for_user(global_id: int) -> list[MessageRecord]:
    return [
        item for item in MESSAGES
        if item.sender_global_id == global_id or item.recipient_global_id == global_id
    ]

# In-memory compatibility backend is retained only for local tests and offline development.
# Production automatically uses PostgreSQL when DATABASE_URL is configured.

USER_SETTINGS: dict[int, UserSettingsRecord] = {}

def upsert_user_settings(global_id: int, payload: UserSettingsUpsert) -> UserSettingsRecord:
    from datetime import datetime, timezone
    record = UserSettingsRecord(
        global_id=global_id,
        global_id_display=gid(global_id),
        updated_at=datetime.now(timezone.utc),
        **payload.model_dump(),
    )
    USER_SETTINGS[global_id] = record
    return record

def get_user_settings(global_id: int) -> UserSettingsRecord | None:
    return USER_SETTINGS.get(global_id)

PROFILES: dict[int, object] = {}


def upsert_profile(global_id: int, payload):
    from .models import ProfileRecord
    record = ProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())
    PROFILES[global_id] = record
    return record


def get_profile(global_id: int):
    return PROFILES.get(global_id)


def list_people(
    city: str,
    radius_km: int,
    requester_global_id: int | None = None,
    desired_qualities: list[str] | None = None,
    locale: str = "ru",
) -> list[Person]:
    desired = parse_desired_qualities(desired_qualities or [])
    result: list[Person] = []
    for person in PEOPLE:
        if person.city != city or person.distance_km > radius_km or person.global_id == requester_global_id:
            continue
        docs = [
            item.model_dump(mode="json")
            for (gid_value, _), item in ASSESSMENT_RESULTS.items()
            if gid_value == person.global_id and item.scoring_version == "scientific-questionnaire-v1"
        ]
        traits, confidence = aggregate_latent(docs)
        fit_score, fit_confidence, matched = quality_fit(desired, traits, confidence, locale)
        positive = positive_projection(traits, locale)
        localized = _localize_demo_person(person, locale)
        result.append(localized.model_copy(update={
            "quality_fit": fit_score,
            "quality_fit_confidence": fit_confidence,
            "positive_qualities": positive if positive else matched,
        }))
    return result


def list_communities(city: str, kind: CommunityKind, locale: str = "ru") -> list[Community]:
    return [
        _localize_demo_community(group, locale)
        for group in COMMUNITIES
        if group.kind == kind and (group.city == city or group.online)
    ]


def trust_summary(global_id: int):
    from .models import TrustSummary
    related = [item for item in INCIDENTS if item.subject_global_id == global_id]
    confirmed = [item for item in related if item.status == IncidentStatus.CONFIRMED]
    pending = [item for item in related if item.status in {IncidentStatus.PENDING, IncidentStatus.UNDER_REVIEW, IncidentStatus.APPEALED}]
    score = max(0, min(100, BASE_TRUST.get(global_id, 70) + sum(item.score_impact for item in confirmed)))
    return TrustSummary(
        global_id=global_id,
        global_id_display=gid(global_id),
        score=score,
        verified_interactions=VERIFIED_INTERACTIONS.get(global_id, 0),
        confirmed_incidents=len(confirmed),
        pending_incidents=len(pending),
    )

PERSONALITY_PROFILES: dict[int, object] = {}


# v0.5.12 chat runtime for local tests/offline backend development.
DEVICE_KEYS: dict[tuple[int, str], DeviceKeyRecord] = {}
CHAT_CONVERSATIONS: dict[str, dict] = {}
CHAT_MESSAGES: dict[str, list[ChatMessageRecord]] = {}
CHAT_ATTACHMENT_DATA: dict[str, AttachmentPayload] = {}
CHAT_REACTIONS: dict[str, list[MessageReactionRecord]] = {}
CHAT_TYPING: dict[str, dict[int, int]] = {}
CHAT_RECEIPTS: dict[str, dict[int, dict[str, bool]]] = {}
USER_BLOCKS: set[tuple[int, int]] = set()
PUSH_TOKENS: dict[tuple[int, str, str], str] = {}

def upsert_device_key(global_id: int, payload: DeviceKeyUpsert) -> DeviceKeyRecord:
    import time
    record = DeviceKeyRecord(
        global_id=global_id, global_id_display=gid(global_id),
        created_at_epoch_ms=int(time.time() * 1000), **payload.model_dump()
    )
    DEVICE_KEYS[(global_id, payload.device_id)] = record
    return record

def device_keys_for_user(global_id: int) -> list[DeviceKeyRecord]:
    return [r for (gid_value, _), r in DEVICE_KEYS.items() if gid_value == global_id]

def has_user_block(owner_global_id: int, subject_global_id: int) -> bool:
    return (owner_global_id, subject_global_id) in USER_BLOCKS

def is_user_blocked(first_global_id: int, second_global_id: int) -> bool:
    return has_user_block(first_global_id, second_global_id) or has_user_block(second_global_id, first_global_id)

def set_user_block(owner_global_id: int, subject_global_id: int, blocked: bool) -> bool:
    if owner_global_id == subject_global_id:
        raise ValueError("cannot block yourself")
    key = (owner_global_id, subject_global_id)
    if blocked:
        USER_BLOCKS.add(key)
    else:
        USER_BLOCKS.discard(key)
    return blocked

def upsert_push_token(global_id: int, payload: PushTokenUpsert) -> bool:
    PUSH_TOKENS[(global_id, payload.device_id, payload.provider)] = payload.token
    return True

def open_direct_conversation(owner_global_id: int, peer_global_id: int) -> ConversationSummary:
    if owner_global_id == peer_global_id:
        raise ValueError("direct chat requires another user")
    if is_user_blocked(owner_global_id, peer_global_id):
        raise ValueError("direct chat is blocked between these users")
    pair = frozenset({owner_global_id, peer_global_id})
    for cid, meta in CHAT_CONVERSATIONS.items():
        if meta["type"] == ConversationType.DIRECT and meta["members"] == pair:
            return _conversation_summary(cid, owner_global_id)
    cid = f"conv-{uuid4().hex[:16]}"
    CHAT_CONVERSATIONS[cid] = {
        "type": ConversationType.DIRECT, "members": pair, "title": "", "owner": owner_global_id,
    }
    CHAT_MESSAGES[cid] = []
    return _conversation_summary(cid, owner_global_id)

def create_group_conversation(owner_global_id: int, payload: GroupConversationCreate) -> ConversationSummary:
    members = set(payload.member_global_ids) | {owner_global_id}
    cid = f"grp-{uuid4().hex[:16]}"
    CHAT_CONVERSATIONS[cid] = {
        "type": ConversationType.GROUP, "members": frozenset(members), "title": payload.title, "owner": owner_global_id,
    }
    CHAT_MESSAGES[cid] = []
    return _conversation_summary(cid, owner_global_id)

def _conversation_summary(conversation_id: str, viewer_global_id: int) -> ConversationSummary:
    meta = CHAT_CONVERSATIONS[conversation_id]
    messages = CHAT_MESSAGES.get(conversation_id, [])
    last = messages[-1] if messages else None
    peer = next((x for x in meta["members"] if x != viewer_global_id), None) if meta["type"] == ConversationType.DIRECT else None
    title = meta["title"] or (f"global_id {gid(peer)}" if peer else "Чат")
    preview = "🔒 E2EE" if last and last.encryption_mode == EncryptionMode.E2EE else ((last.body or "📎 Медиа") if last else "")
    return ConversationSummary(
        id=conversation_id, conversation_type=meta["type"], title=title, peer_global_id=peer,
        member_count=len(meta["members"]), encryption_mode=EncryptionMode.E2EE if meta["type"] == ConversationType.DIRECT else EncryptionMode.SERVER,
        last_message_preview=preview[:160], last_message_at_epoch_ms=last.created_at_epoch_ms if last else None, unread_count=0,
    )

def conversations_for_user(global_id: int) -> list[ConversationSummary]:
    result = [_conversation_summary(cid, global_id) for cid, meta in CHAT_CONVERSATIONS.items() if global_id in meta["members"]]
    return sorted(result, key=lambda c: c.last_message_at_epoch_ms or 0, reverse=True)

def conversation_members(conversation_id: str, viewer_global_id: int) -> list[ConversationMemberRecord]:
    meta = CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or viewer_global_id not in meta["members"]:
        raise ValueError("conversation not found or user is not a member")
    return [
        ConversationMemberRecord(global_id=value, global_id_display=gid(value), role="owner" if value == meta["owner"] else "member")
        for value in sorted(meta["members"])
    ]

def add_group_member(conversation_id: str, owner_global_id: int, member_global_id: int) -> list[ConversationMemberRecord]:
    meta = CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or meta["type"] != ConversationType.GROUP:
        raise ValueError("group not found")
    if meta["owner"] != owner_global_id:
        raise ValueError("only group owner can add members")
    members = set(meta["members"])
    members.add(member_global_id)
    meta["members"] = frozenset(members)
    return conversation_members(conversation_id, owner_global_id)

def remove_group_member(conversation_id: str, owner_global_id: int, member_global_id: int) -> list[ConversationMemberRecord]:
    meta = CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or meta["type"] != ConversationType.GROUP:
        raise ValueError("group not found")
    if meta["owner"] != owner_global_id:
        raise ValueError("only group owner can remove members")
    if member_global_id == owner_global_id:
        raise ValueError("group owner cannot remove himself")
    members = set(meta["members"])
    members.discard(member_global_id)
    meta["members"] = frozenset(members)
    return conversation_members(conversation_id, owner_global_id)

def create_chat_message(conversation_id: str, sender_global_id: int, payload: ChatMessageCreate) -> ChatMessageRecord:
    meta = CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or sender_global_id not in meta["members"]:
        raise ValueError("conversation not found or sender is not a member")
    expected = EncryptionMode.E2EE if meta["type"] == ConversationType.DIRECT else EncryptionMode.SERVER
    if meta["type"] == ConversationType.DIRECT:
        peer = next((member for member in meta["members"] if member != sender_global_id), None)
        if peer is not None and is_user_blocked(sender_global_id, peer):
            raise ValueError("direct chat is blocked between these users")
    if payload.encryption_mode != expected:
        raise ValueError("invalid encryption mode for conversation")
    if payload.message_type == "edit":
        raise ValueError("edit messages must use the edit endpoint")
    if payload.reply_to_message_id is not None and not any(m.id == payload.reply_to_message_id for m in CHAT_MESSAGES.get(conversation_id, [])):
        raise ValueError("reply target is not in this conversation")
    if expected == EncryptionMode.E2EE and (payload.body is not None or not payload.ciphertext_b64 or not payload.nonce_b64):
        raise ValueError("direct messages must contain ciphertext only")
    if expected == EncryptionMode.SERVER and not (payload.body or payload.attachments):
        raise ValueError("group messages require text or attachment")
    existing = next((m for m in CHAT_MESSAGES.get(conversation_id, []) if m.client_message_id == payload.client_message_id and m.sender_global_id == sender_global_id), None)
    if existing:
        return existing
    attachments=[]
    for item in payload.attachments:
        aid=f"att-{uuid4().hex[:16]}"
        rec=ChatAttachmentRecord(id=aid, client_attachment_id=item.client_attachment_id, kind=item.kind, mime_type=item.mime_type, file_name=item.file_name, byte_size=item.byte_size, nonce_b64=item.nonce_b64)
        CHAT_ATTACHMENT_DATA[aid]=AttachmentPayload(attachment=rec, encryption_mode=expected, data_b64=item.data_b64)
        attachments.append(rec)
    record = ChatMessageRecord(
        id=f"msg-{uuid4().hex[:16]}", conversation_id=conversation_id, sender_global_id=sender_global_id,
        client_message_id=payload.client_message_id, message_type=payload.message_type, encryption_mode=payload.encryption_mode,
        body=payload.body, ciphertext_b64=payload.ciphertext_b64, nonce_b64=payload.nonce_b64, key_id=payload.key_id,
        ratchet_counter=payload.ratchet_counter, sender_ephemeral_public_key_b64=payload.sender_ephemeral_public_key_b64,
        recipient_prekey_id=payload.recipient_prekey_id, reply_to_message_id=payload.reply_to_message_id, attachments=attachments,
        status="sent", created_at_epoch_ms=payload.created_at_epoch_ms,
    )
    CHAT_MESSAGES.setdefault(conversation_id, []).append(record)
    return record

def chat_messages(conversation_id: str, global_id: int) -> list[ChatMessageRecord]:
    meta=CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or global_id not in meta["members"]:
        raise ValueError("conversation not found or user is not a member")
    result = []
    for message in CHAT_MESSAGES.get(conversation_id, []):
        if message.sender_global_id != global_id:
            receipt = CHAT_RECEIPTS.setdefault(message.id, {}).setdefault(global_id, {"delivered": False, "read": False})
            receipt["delivered"] = True
        counts: dict[str, int] = {}
        for reaction in CHAT_REACTIONS.get(message.id, []):
            counts[reaction.emoji] = counts.get(reaction.emoji, 0) + 1
        receipts = CHAT_RECEIPTS.get(message.id, {})
        result.append(message.model_copy(update={
            "reactions": counts,
            "delivered_count": sum(1 for value in receipts.values() if value.get("delivered")),
            "read_count": sum(1 for value in receipts.values() if value.get("read")),
        }))
    return result

def attachment_payload(attachment_id: str, global_id: int) -> AttachmentPayload | None:
    payload=CHAT_ATTACHMENT_DATA.get(attachment_id)
    if payload is None:
        return None
    # Memory mode uses globally unique attachment ids; membership is validated by message lookup in production.
    return payload

def mark_chat_read(conversation_id: str, global_id: int, message_id: str) -> bool:
    meta=CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or global_id not in meta["members"]:
        return False
    for idx, msg in enumerate(CHAT_MESSAGES.get(conversation_id, [])):
        if msg.id == message_id:
            if msg.sender_global_id != global_id:
                receipt = CHAT_RECEIPTS.setdefault(msg.id, {}).setdefault(global_id, {"delivered": False, "read": False})
                receipt["delivered"] = True
                receipt["read"] = True
            CHAT_MESSAGES[conversation_id][idx]=msg.model_copy(update={"status":"read"})
            return True
    return False

def edit_chat_message(message_id: str, global_id: int, payload: ChatMessageEdit) -> ChatMessageRecord:
    # Edits are represented as chronological edit events. This is important for E2EE:
    # replacing old ciphertext in-place would reorder ratchet counters relative to created_at.
    original = None
    conversation_id = None
    for cid, messages in CHAT_MESSAGES.items():
        for msg in messages:
            if msg.id == message_id:
                original = msg
                conversation_id = cid
                break
        if original is not None:
            break
    if original is None or conversation_id is None:
        raise ValueError("message not found")
    if original.sender_global_id != global_id:
        raise ValueError("only the sender can edit this message")
    if original.status == "deleted":
        raise ValueError("deleted message cannot be edited")
    if original.encryption_mode != payload.encryption_mode:
        raise ValueError("encryption mode cannot change")
    if payload.encryption_mode == EncryptionMode.E2EE and (payload.body is not None or not payload.ciphertext_b64 or not payload.nonce_b64):
        raise ValueError("E2EE edit must contain ciphertext only")
    if payload.encryption_mode == EncryptionMode.SERVER and payload.body is None:
        raise ValueError("group edit requires body")
    event = ChatMessageRecord(
        id=f"msg-{uuid4().hex[:16]}", conversation_id=conversation_id, sender_global_id=global_id,
        client_message_id=f"edit-{uuid4().hex[:16]}", message_type="edit", encryption_mode=payload.encryption_mode,
        body=payload.body if payload.encryption_mode == EncryptionMode.SERVER else None,
        ciphertext_b64=payload.ciphertext_b64, nonce_b64=payload.nonce_b64, key_id=payload.key_id,
        ratchet_counter=payload.ratchet_counter, sender_ephemeral_public_key_b64=payload.sender_ephemeral_public_key_b64,
        recipient_prekey_id=payload.recipient_prekey_id, reply_to_message_id=message_id, attachments=[],
        status="sent", created_at_epoch_ms=payload.edited_at_epoch_ms, edited_at_epoch_ms=payload.edited_at_epoch_ms,
    )
    CHAT_MESSAGES.setdefault(conversation_id, []).append(event)
    return event


def toggle_message_reaction(message_id: str, global_id: int, emoji: str) -> list[MessageReactionRecord]:
    allowed = {"👍", "🤝", "❤️", "🔥", "👏", "😂"}
    if emoji not in allowed:
        raise ValueError("unsupported reaction")
    found = None
    for cid, messages in CHAT_MESSAGES.items():
        if any(m.id == message_id for m in messages):
            if global_id not in CHAT_CONVERSATIONS[cid]["members"]:
                raise ValueError("user is not a member")
            found = cid
            break
    if found is None:
        raise ValueError("message not found")
    current = CHAT_REACTIONS.setdefault(message_id, [])
    existing = next((r for r in current if r.global_id == global_id and r.emoji == emoji), None)
    if existing:
        CHAT_REACTIONS[message_id] = [r for r in current if not (r.global_id == global_id and r.emoji == emoji)]
    else:
        CHAT_REACTIONS[message_id].append(MessageReactionRecord(message_id=message_id, global_id=global_id, emoji=emoji))
    return list(CHAT_REACTIONS[message_id])

def delete_chat_message(message_id: str, global_id: int) -> bool:
    for cid, messages in CHAT_MESSAGES.items():
        for idx, msg in enumerate(messages):
            if msg.id == message_id:
                if msg.sender_global_id != global_id:
                    return False
                for attachment in msg.attachments:
                    CHAT_ATTACHMENT_DATA.pop(attachment.id, None)
                CHAT_REACTIONS.pop(message_id, None)
                CHAT_RECEIPTS.pop(message_id, None)
                # Keep the E2EE envelope as a tombstone so ratchet/bootstrap history stays traversable.
                messages[idx] = msg.model_copy(update={
                    "body": None,
                    "attachments": [],
                    "status": "deleted",
                    "reactions": {},
                })
                return True
    return False

def set_typing(conversation_id: str, global_id: int, typing: bool) -> bool:
    import time
    meta = CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or global_id not in meta["members"]:
        return False
    values = CHAT_TYPING.setdefault(conversation_id, {})
    if typing:
        values[global_id] = int(time.time() * 1000) + 8000
    else:
        values.pop(global_id, None)
    return True

def typing_users(conversation_id: str, global_id: int) -> list[int]:
    import time
    meta = CHAT_CONVERSATIONS.get(conversation_id)
    if not meta or global_id not in meta["members"]:
        raise ValueError("conversation not found or user is not a member")
    now = int(time.time() * 1000)
    values = CHAT_TYPING.setdefault(conversation_id, {})
    for gid_value, expiry in list(values.items()):
        if expiry <= now:
            values.pop(gid_value, None)
    return [gid_value for gid_value in values if gid_value != global_id]

def app_version_manifest() -> AppVersionManifest:
    return AppVersionManifest(
        version_code=38, version_name="0.5.33", min_supported_version_code=16,
        play_url=None, test_download_url=None,
        release_notes="Hidden visual psychological profile and user-authored Quality Fit with positive contextual interpretation.",
    )

# Cycle 0030 numerology vNext local persistence. Production uses repository/PostgreSQL.
NUMEROLOGY_READINGS: dict[str, object] = {}
NUMEROLOGY_COMPARISONS: dict[str, object] = {}


def save_numerology_reading(record):
    existing = next((row for row in NUMEROLOGY_READINGS.values() if row.global_id == record.global_id and row.input_snapshot_hash == record.input_snapshot_hash and row.calculation_version == record.calculation_version and row.knowledge_version == record.knowledge_version), None)
    if existing is not None:
        return existing
    NUMEROLOGY_READINGS[str(record.reading_id)] = record
    return record


def numerology_readings_for_user(global_id: int):
    rows = [row for row in NUMEROLOGY_READINGS.values() if row.global_id == global_id]
    return sorted(rows, key=lambda row: (row.created_at, str(row.reading_id)), reverse=True)


def get_numerology_reading(global_id: int, reading_id):
    row = NUMEROLOGY_READINGS.get(str(reading_id))
    return row if row is not None and row.global_id == global_id else None


def save_numerology_comparison(record):
    NUMEROLOGY_COMPARISONS[str(record.comparison_id)] = record
    return record


def numerology_comparison_history(global_id: int):
    rows = [row for row in NUMEROLOGY_COMPARISONS.values() if global_id in {row.first_global_id, row.second_global_id}]
    return sorted(rows, key=lambda row: (row.created_at, str(row.comparison_id)), reverse=True)


# Cycle 0031 Zodiac vNext local persistence. Production uses repository/PostgreSQL.
ZODIAC_READINGS: dict[str, object] = {}
ZODIAC_COMPARISONS: dict[str, object] = {}


def save_zodiac_reading(record):
    existing = next((row for row in ZODIAC_READINGS.values() if row.global_id == record.global_id and row.input_snapshot_hash == record.input_snapshot_hash and row.calculation_version == record.calculation_version and row.catalog_version == record.catalog_version), None)
    if existing is not None:
        return existing
    ZODIAC_READINGS[str(record.reading_id)] = record
    return record


def zodiac_readings_for_user(global_id: int):
    rows = [row for row in ZODIAC_READINGS.values() if row.global_id == global_id]
    return sorted(rows, key=lambda row: (row.created_at, str(row.reading_id)), reverse=True)


def get_zodiac_reading(global_id: int, reading_id):
    row = ZODIAC_READINGS.get(str(reading_id))
    return row if row is not None and row.global_id == global_id else None


def save_zodiac_comparison(record):
    ZODIAC_COMPARISONS[str(record.comparison_id)] = record
    return record


def zodiac_comparison_history(global_id: int):
    rows = [row for row in ZODIAC_COMPARISONS.values() if global_id in {row.first_global_id, row.second_global_id}]
    return sorted(rows, key=lambda row: (row.created_at, str(row.comparison_id)), reverse=True)


# Cycle 0032 Enneagram vNext local persistence. Production uses repository/PostgreSQL.
ENNEAGRAM_READINGS: dict[str, object] = {}
ENNEAGRAM_COMPARISONS: dict[str, object] = {}


def save_enneagram_reading(record):
    existing = next((row for row in ENNEAGRAM_READINGS.values() if row.global_id == record.global_id and row.answers_snapshot_hash == record.answers_snapshot_hash and row.instrument_version == record.instrument_version and row.calculation_version == record.calculation_version), None)
    if existing is not None:
        return existing
    ENNEAGRAM_READINGS[str(record.reading_id)] = record
    return record


def enneagram_readings_for_user(global_id: int):
    rows = [row for row in ENNEAGRAM_READINGS.values() if row.global_id == global_id]
    return sorted(rows, key=lambda row: (row.created_at, str(row.reading_id)), reverse=True)


def get_enneagram_reading(global_id: int, reading_id):
    row = ENNEAGRAM_READINGS.get(str(reading_id))
    return row if row is not None and row.global_id == global_id else None


def save_enneagram_comparison(record):
    ENNEAGRAM_COMPARISONS[str(record.comparison_id)] = record
    return record


def enneagram_comparison_history(global_id: int):
    rows = [row for row in ENNEAGRAM_COMPARISONS.values() if global_id in {row.first_global_id, row.second_global_id}]
    return sorted(rows, key=lambda row: (row.created_at, str(row.comparison_id)), reverse=True)


# Cycle 0033 Quality Fit / SearchIntent v2 local persistence. Production uses repository/PostgreSQL.
QUALITY_FIT_EVALUATIONS: dict[str, object] = {}


def save_quality_fit_evaluation(record):
    existing = next((row for row in QUALITY_FIT_EVALUATIONS.values()
                     if row.searcher_global_id == record.searcher_global_id
                     and row.candidate_global_id == record.candidate_global_id
                     and row.intent_snapshot_hash == record.intent_snapshot_hash
                     and row.candidate_evidence_hash == record.candidate_evidence_hash
                     and row.scoring_version == record.scoring_version), None)
    if existing is not None:
        return existing
    QUALITY_FIT_EVALUATIONS[str(record.evaluation_id)] = record
    return record


def quality_fit_evaluation_history(global_id: int):
    rows = [row for row in QUALITY_FIT_EVALUATIONS.values() if row.searcher_global_id == global_id]
    return sorted(rows, key=lambda row: (row.created_at, str(row.evaluation_id)), reverse=True)


def get_quality_fit_evaluation(global_id: int, evaluation_id):
    row = QUALITY_FIT_EVALUATIONS.get(str(evaluation_id))
    return row if row is not None and row.searcher_global_id == global_id else None


# Cycle 0034 Secure Test Administration Runtime local persistence.
ASSESSMENT_ADMIN_SESSIONS: dict[str, TestAdministrationSessionRecord] = {}


def save_test_administration_session(record: TestAdministrationSessionRecord) -> TestAdministrationSessionRecord:
    ASSESSMENT_ADMIN_SESSIONS[str(record.session_id)] = record
    return record


def get_test_administration_session(session_id) -> TestAdministrationSessionRecord | None:
    return ASSESSMENT_ADMIN_SESSIONS.get(str(session_id))


def active_test_administration_session(global_id: int, app_id: str) -> TestAdministrationSessionRecord | None:
    rows = [
        row for row in ASSESSMENT_ADMIN_SESSIONS.values()
        if row.global_id == global_id and row.app_id == app_id and row.status == "IN_PROGRESS"
    ]
    if not rows:
        return None
    return sorted(rows, key=lambda row: (row.updated_at_epoch_ms, str(row.session_id)), reverse=True)[0]
