from enum import StrEnum
from typing import Annotated, Any
from datetime import date, datetime
from uuid import UUID
from pydantic import BaseModel, Field, field_validator, model_validator

GlobalId = Annotated[int, Field(ge=1, le=9_999_999_999)]


class AuthProvider(StrEnum):
    GOOGLE = "google"
    TELEGRAM = "telegram"
    FACEBOOK = "facebook"
    EMAIL = "email"
    PASSKEY = "passkey"
    APPLE = "apple"
    MICROSOFT = "microsoft"
    PHONE = "phone"


class SessionIssueRequest(BaseModel):
    global_id: GlobalId
    provider: AuthProvider
    device_id: str | None = Field(default=None, min_length=8, max_length=160)


class SessionIssueResponse(BaseModel):
    access_token: str
    refresh_token: str | None = None
    token_type: str = "bearer"
    global_id: GlobalId
    global_id_display: str
    provider: AuthProvider | None = None
    session_id: UUID | None = None
    expires_at: datetime
    refresh_expires_at: datetime | None = None


class ProviderCredentialExchange(BaseModel):
    provider: AuthProvider
    credential: str = Field(min_length=16, max_length=20000)
    nonce: str | None = Field(default=None, min_length=8, max_length=512)
    tenant: str = Field(default="default", min_length=1, max_length=80)
    device_id: str | None = Field(default=None, min_length=8, max_length=160)


class SessionRefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=32, max_length=512)
    device_id: str | None = Field(default=None, min_length=8, max_length=160)


class SessionStatusResponse(BaseModel):
    authenticated: bool
    global_id: GlobalId
    global_id_display: str
    provider: AuthProvider
    session_id: UUID | None = None
    expires_at: datetime | None = None


class EmailCodeRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    locale: str = Field(default="en", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")


class EmailCodeVerifyRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    code: str = Field(pattern=r"^[0-9]{6}$")
    device_id: str | None = Field(default=None, min_length=8, max_length=160)


class EmailCodeAccepted(BaseModel):
    accepted: bool = True
    expires_in_seconds: int = 600


class GoogleAuthConfigResponse(BaseModel):
    client_id: str = Field(min_length=1, max_length=512)


class TelegramOidcBeginRequest(BaseModel):
    device_id: str = Field(min_length=8, max_length=160)


class TelegramOidcBeginResponse(BaseModel):
    authorization_url: str
    expires_in_seconds: int = 300


class TelegramOidcFinishRequest(BaseModel):
    # Android uses a one-time server-issued ticket after the HTTPS OIDC callback.
    # code/state remain accepted for compatibility with the source-only direct exchange path.
    ticket: str | None = Field(default=None, min_length=16, max_length=512)
    code: str | None = Field(default=None, min_length=8, max_length=4096)
    state: str | None = Field(default=None, min_length=16, max_length=512)
    device_id: str | None = Field(default=None, min_length=8, max_length=160)


class PasskeyOptionsResponse(BaseModel):
    challenge_id: UUID
    options_json: str


class PasskeyRegistrationFinish(BaseModel):
    challenge_id: UUID
    credential_json: str = Field(min_length=32, max_length=50000)


class PasskeyAuthenticationFinish(BaseModel):
    challenge_id: UUID
    credential_json: str = Field(min_length=32, max_length=50000)
    device_id: str | None = Field(default=None, min_length=8, max_length=160)


class UserSettingsUpsert(BaseModel):
    locale: str = Field(pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    theme: str = Field(pattern=r"^(system|light|dark)$")
    profile_visibility: str = Field(pattern=r"^(discoverable|connections|private)$")
    preferences: dict[str, object] = {}


class UserSettingsRecord(UserSettingsUpsert):
    global_id: GlobalId
    global_id_display: str
    updated_at: datetime


class CommunityKind(StrEnum):
    INTEREST = "interest"
    BUSINESS = "business"


class IncidentStatus(StrEnum):
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    APPEALED = "appealed"
    FINAL = "final"


class ProfileUpsert(BaseModel):
    display_name: str = Field(min_length=1, max_length=120)
    birth_date: date
    latin_name: str | None = Field(default=None, max_length=160)
    city: str = Field(min_length=1, max_length=120)
    country_code: str = Field(default="ZZ", pattern=r"^[A-Za-z]{2}$")
    region_name: str | None = Field(default=None, max_length=120)
    about: str = Field(default="", max_length=4000)
    friendship_goals: list[str] = []
    interests: list[str] = []
    values: list[str] = []
    lifestyle: list[str] = []
    boundaries: dict[str, object] = {}
    visibility: str = Field(default="discoverable", pattern=r"^(discoverable|connections|private)$")
    completed_profile_sections: int = Field(default=0, ge=0, le=10)
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")


class ProfileRecord(ProfileUpsert):
    global_id: GlobalId
    global_id_display: str

    @field_validator("global_id_display")
    @classmethod
    def validate_profile_display(cls, value: str) -> str:
        if len(value) != 10 or not value.isdigit() or value == "0000000000":
            raise ValueError("global_id_display must contain exactly 10 digits and cannot be zero")
        return value


class ProfileAvatarUpsert(BaseModel):
    content_type: str = Field(pattern=r"^image/(jpeg|png|webp)$")
    data_base64: str = Field(min_length=16, max_length=800_000)
    sha256: str = Field(pattern=r"^[0-9a-fA-F]{64}$")


class ProfileAvatarRecord(BaseModel):
    global_id: GlobalId
    content_type: str
    sha256: str
    byte_size: int = Field(gt=0, le=512_000)
    updated_at: datetime


class PersonalityProfileUpsert(BaseModel):
    brotherhood32_code: str = Field(pattern=r"^[ER][PV][LH][SF][GA]$")
    brotherhood32_scores: dict[str, int | str]
    enneagram_type: int | None = Field(default=None, ge=1, le=9)
    enneagram_wing: int | None = Field(default=None, ge=1, le=9)
    zodiac_sign: str | None = Field(default=None, max_length=32)
    vedic_numerology: dict[str, int | list[int] | None] = {}
    model_version: str = "0.5.20"


class PersonalityProfileRecord(PersonalityProfileUpsert):
    global_id: GlobalId
    global_id_display: str


class Personality32(BaseModel):
    code: str = Field(pattern=r"^[ER][PV][LH][SF][GA]$")
    title: str
    social_energy: int = Field(ge=0, le=100)
    perception: int = Field(ge=0, le=100)
    decision_style: int = Field(ge=0, le=100)
    life_rhythm: int = Field(ge=0, le=100)
    bond_style: int = Field(ge=0, le=100)


class NumerologyProfile(BaseModel):
    soul_number: int = Field(ge=1, le=9)
    destiny_number: int = Field(ge=1, le=9)
    name_number: int | None = Field(default=None, ge=1, le=9)
    maturity_number: int = Field(ge=1, le=9)


class NumerologyReadingCreate(BaseModel):
    global_id: GlobalId
    birth_date: date
    latin_name: str | None = Field(default=None, max_length=160)
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")


class NumerologyTextBlock(BaseModel):
    title: str
    body: str


class NumerologyCalculationTrace(BaseModel):
    calculation_id: str
    title: str
    formula: str
    reduction_steps: list[int] = Field(default_factory=list)
    result: int = Field(ge=0, le=9999)


class NumerologyNumberDetail(BaseModel):
    role_id: str
    title: str
    number: int = Field(ge=1, le=9)
    ruler: str
    meaning: str


class NumerologyBirthChartSignal(BaseModel):
    key: str
    digit: int | None = Field(default=None, ge=1, le=9)
    count: int = Field(default=0, ge=0, le=9)
    title: str
    body: str
    special: bool = False


class NumerologyPinnacleCycle(BaseModel):
    index: int = Field(ge=1, le=4)
    number: int = Field(ge=1, le=11)
    reached_at_age: int = Field(ge=0, le=150)
    reached_at_date: date | None = None
    title: str
    body: str


class NumerologyReadingRecord(BaseModel):
    reading_id: UUID
    global_id: GlobalId
    global_id_display: str
    birth_date: date
    locale: str
    calculation_version: str
    knowledge_version: str
    compatibility_version: str
    life_path_number: int = Field(ge=1, le=22)
    date_soul_number: int = Field(ge=1, le=9)
    date_destiny_number: int = Field(ge=1, le=9)
    date_maturity_number: int = Field(ge=1, le=9)
    name_soul_number: int | None = Field(default=None, ge=1, le=11)
    expression_number: int | None = Field(default=None, ge=1, le=22)
    date_profile: list[NumerologyTextBlock] = Field(default_factory=list)
    date_number_details: list[NumerologyNumberDetail] = Field(default_factory=list)
    calculation_trace: list[NumerologyCalculationTrace] = Field(default_factory=list)
    life_path_sections: list[NumerologyTextBlock] = Field(default_factory=list)
    birth_chart: list[NumerologyBirthChartSignal] = Field(default_factory=list)
    birth_chart_inventory: list[NumerologyBirthChartSignal] = Field(default_factory=list)
    missing_birth_chart_digits: list[int] = Field(default_factory=list)
    special_birth_chart_signals: list[NumerologyBirthChartSignal] = Field(default_factory=list)
    pinnacles: list[NumerologyPinnacleCycle] = Field(default_factory=list)
    name_profile: list[NumerologyTextBlock] = Field(default_factory=list)
    disclosure: str
    input_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    created_at: datetime


class NumerologyCompatibilityRequest(BaseModel):
    first_global_id: GlobalId
    second_global_id: GlobalId
    persist_history: bool = True

    @model_validator(mode="after")
    def validate_distinct_users(self):
        if self.first_global_id == self.second_global_id:
            raise ValueError("numerology compatibility requires two different users")
        return self


class NumerologyPairRelation(BaseModel):
    first_number: int = Field(ge=1, le=9)
    second_number: int = Field(ge=1, le=9)
    first_ruler: str
    second_ruler: str
    relation_code: str
    score: int = Field(ge=0, le=100)


class NumerologyCompatibilityComponent(BaseModel):
    component_id: str
    title: str
    score: int = Field(ge=0, le=100)
    internal_weight: float = Field(ge=0.0, le=1.0)
    explanation: str
    relations: list[NumerologyPairRelation] = Field(default_factory=list)


class NumerologyCompatibilityRecord(BaseModel):
    comparison_id: UUID
    first_global_id: GlobalId
    second_global_id: GlobalId
    score: int = Field(ge=0, le=100)
    components: list[NumerologyCompatibilityComponent]
    strongest_component_id: str
    tension_component_id: str | None = None
    first_date_numbers: dict[str, int] = Field(default_factory=dict)
    second_date_numbers: dict[str, int] = Field(default_factory=dict)
    calculation_version: str
    compatibility_version: str
    evidence_origin: str
    disclosure: str
    created_at: datetime


class NumerologyCatalogGroup(BaseModel):
    group_id: str
    title: str
    record_count: int = Field(ge=0)
    keys: list[str] = Field(default_factory=list)


class NumerologyCatalogIndex(BaseModel):
    knowledge_version: str
    locale: str
    source_record_count: int = Field(ge=0)
    groups: list[NumerologyCatalogGroup] = Field(default_factory=list)
    disclosure: str


class NumerologyCatalogEntry(BaseModel):
    knowledge_version: str
    locale: str
    group_id: str
    key: str
    title: str
    body: str = ""
    sections: list[NumerologyTextBlock] = Field(default_factory=list)
    disclosure: str


class NumerologySpecResponse(BaseModel):
    calculation_version: str
    knowledge_version: str
    compatibility_version: str
    tradition: str
    source_archive: str
    source_archive_sha256: str
    source_language: str
    supported_locales: list[str]
    date_derived_fields: list[str]
    descriptive_name_fields: list[str]
    compatibility_components: dict[str, float]
    compatibility_input_policy: str
    source_record_count: int = Field(default=0, ge=0)
    catalog_groups: list[str] = Field(default_factory=list)
    disclosure: str


class ZodiacSignDetail(BaseModel):
    sign_id: str
    symbol: str
    label: str
    locale: str
    period_start: str = Field(pattern=r"^\d{2}-\d{2}$")
    period_end: str = Field(pattern=r"^\d{2}-\d{2}$")
    wraps_year: bool = False
    group_id: str
    group_label: str
    characteristics: list[str] = Field(default_factory=list)
    characteristics_locale: str = "ru"
    evidence_status: str
    product_copy_origin: str


class ZodiacCatalogIndex(BaseModel):
    catalog_version: str
    locale: str
    sign_count: int = Field(ge=0)
    signs: list[ZodiacSignDetail] = Field(default_factory=list)
    disclosure: str


class ZodiacReadingCreate(BaseModel):
    global_id: GlobalId
    birth_date: date
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")


class ZodiacReadingRecord(BaseModel):
    reading_id: UUID
    global_id: GlobalId
    global_id_display: str
    birth_date: date
    locale: str
    calculation_version: str
    catalog_version: str
    compatibility_version: str
    method_id: str
    sign: ZodiacSignDetail
    month_day_code: int = Field(ge=101, le=1231)
    boundary_rule: str
    input_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    disclosure: str
    created_at: datetime


class ZodiacCompatibilityRequest(BaseModel):
    first_global_id: GlobalId
    second_global_id: GlobalId
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    persist_history: bool = True

    @model_validator(mode="after")
    def validate_distinct_users(self):
        if self.first_global_id == self.second_global_id:
            raise ValueError("zodiac compatibility requires two different users")
        return self


class ZodiacCompatibilityRecord(BaseModel):
    comparison_id: UUID
    first_global_id: GlobalId
    second_global_id: GlobalId
    score: int = Field(ge=0, le=100)
    first_sign: ZodiacSignDetail
    second_sign: ZodiacSignDetail
    relation_code: str
    explanation: str
    calculation_version: str
    catalog_version: str
    compatibility_version: str
    method_id: str
    evidence_origin: str
    disclosure: str
    created_at: datetime


class ZodiacSpecResponse(BaseModel):
    calculation_version: str
    catalog_version: str
    compatibility_version: str
    method_id: str
    source_ids: list[str]
    supported_locales: list[str]
    sign_count: int = Field(ge=0)
    compatibility_rules: dict[str, int]
    compatibility_input_policy: str
    scientific_boundary: str
    future_method_boundary: str
    disclosure: str


class EnneagramVisualChoice(BaseModel):
    choice_id: str
    intensity: int = Field(ge=0, le=3)
    spacing: int = Field(ge=0, le=3)
    order: int = Field(ge=0, le=3)
    asymmetry: int = Field(ge=0, le=3)
    direction: int = Field(ge=0, le=3)


class EnneagramInstrumentItem(BaseModel):
    item_id: str
    sequence: int = Field(ge=1)
    paradigm: str
    scene_archetype: str
    choices: list[EnneagramVisualChoice]


class EnneagramInstrumentResponse(BaseModel):
    instrument_version: str
    method_id: str
    evidence_status: str
    item_count: int = Field(ge=0)
    items: list[EnneagramInstrumentItem]
    response_policy: str
    disclosure: str


class EnneagramTypeDetail(BaseModel):
    type_id: int = Field(ge=1, le=9)
    label: str
    locale: str
    left_wing: int = Field(ge=1, le=9)
    right_wing: int = Field(ge=1, le=9)
    evidence_status: str
    disclosure: str


class EnneagramTypeCatalog(BaseModel):
    catalog_version: str
    locale: str
    type_count: int = Field(ge=0)
    types: list[EnneagramTypeDetail]
    disclosure: str


class EnneagramReadingCreate(BaseModel):
    global_id: GlobalId
    answers: dict[str, int]
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")

    @model_validator(mode="after")
    def validate_answers(self):
        if len(self.answers) != 18:
            raise ValueError("enneagram instrument requires exactly 18 answers")
        if any(value not in {1, 2, 3, 4} for value in self.answers.values()):
            raise ValueError("enneagram answers must be integers 1..4")
        return self


class EnneagramReadingRecord(BaseModel):
    reading_id: UUID
    global_id: GlobalId
    global_id_display: str
    locale: str
    method_id: str
    instrument_version: str
    calculation_version: str
    compatibility_version: str
    catalog_version: str
    type_id: int = Field(ge=1, le=9)
    wing: int = Field(ge=1, le=9)
    confidence: int = Field(ge=0, le=100)
    type_label: str
    type_scores: dict[str, int]
    answers_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    evidence_status: str
    disclosure: str
    created_at: datetime


class EnneagramCompatibilityRequest(BaseModel):
    first_global_id: GlobalId
    second_global_id: GlobalId
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    persist_history: bool = True

    @model_validator(mode="after")
    def validate_distinct_users(self):
        if self.first_global_id == self.second_global_id:
            raise ValueError("enneagram compatibility requires two different users")
        return self


class EnneagramCompatibilityRecord(BaseModel):
    comparison_id: UUID
    first_global_id: GlobalId
    second_global_id: GlobalId
    score: int = Field(ge=0, le=100)
    first_type: EnneagramTypeDetail
    first_wing: int = Field(ge=1, le=9)
    second_type: EnneagramTypeDetail
    second_wing: int = Field(ge=1, le=9)
    circular_type_distance: int = Field(ge=0, le=4)
    wing_bonus: int = Field(ge=0, le=10)
    relation_code: str
    explanation: str
    method_id: str
    instrument_version: str
    calculation_version: str
    compatibility_version: str
    evidence_status: str
    disclosure: str
    created_at: datetime


class EnneagramSpecResponse(BaseModel):
    method_id: str
    instrument_version: str
    calculation_version: str
    compatibility_version: str
    catalog_version: str
    source_ids: list[str]
    evidence_status: str
    item_count: int = Field(ge=0)
    type_count: int = Field(ge=0)
    supported_locales: list[str]
    compatibility_input_policy: str
    compatibility_rule: str
    scientific_boundary: str
    disclosure: str


class HospitalitySleepingCondition(StrEnum):
    PRIVATE_ROOM = "private_room"
    SHARED_ROOM = "shared_room"
    SOFA = "sofa"
    ENTIRE_SPACE = "entire_space"


class HospitalityAvailabilityMode(StrEnum):
    ALWAYS = "always"
    CALENDAR = "calendar"


class HospitalityAvailabilityState(StrEnum):
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"


class StayRequestStatus(StrEnum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    CANCELLED_BY_GUEST = "cancelled_by_guest"
    CANCELLED_BY_HOST = "cancelled_by_host"
    COMPLETED = "completed"
    EXPIRED = "expired"


class StayRequestAction(StrEnum):
    ACCEPT = "accept"
    REJECT = "reject"
    CANCEL_GUEST = "cancel_guest"
    CANCEL_HOST = "cancel_host"


class StayConfirmationValue(StrEnum):
    STAY_OCCURRED = "stay_occurred"
    NO_SHOW = "no_show"
    DISPUTE = "dispute"


class HospitalityPrivateLocation(BaseModel):
    exact_address: str = Field(min_length=3, max_length=500)
    arrival_instructions: str = Field(default="", max_length=4000)
    exact_lat: float | None = Field(default=None, ge=-90, le=90)
    exact_lon: float | None = Field(default=None, ge=-180, le=180)
    arrival_contact: str = Field(default="", max_length=500)


class HostProfileUpsert(BaseModel):
    is_hosting_active: bool = False
    max_guests: int = Field(ge=1, le=100)
    max_days: int = Field(ge=1, le=365)
    # Existing callers may send canonical city_id. Android may send the existing profile/search
    # city value and let the backend resolve it to the canonical cities.city_id.
    city_id: UUID | None = None
    city_value: str | None = Field(default=None, min_length=1, max_length=200)
    public_area_text: str | None = Field(default=None, max_length=240)
    timezone_name: str = Field(min_length=1, max_length=120)
    sleeping_condition: HospitalitySleepingCondition
    house_rules: list[str] = Field(default_factory=list, max_length=40)
    min_required_rating: float = Field(default=0.0, ge=0.0, le=100.0)
    required_completed_tests: list[str] = Field(default_factory=list, max_length=100)
    availability_mode: HospitalityAvailabilityMode = HospitalityAvailabilityMode.ALWAYS
    private_location: HospitalityPrivateLocation

    @model_validator(mode="after")
    def validate_city_reference(self):
        if self.city_id is None and not (self.city_value or "").strip():
            raise ValueError("city_id or city_value is required")
        return self

    @field_validator("required_completed_tests")
    @classmethod
    def validate_required_tests(cls, values: list[str]) -> list[str]:
        cleaned: list[str] = []
        seen: set[str] = set()
        from .assessment_registry import VALID_TEST_IDS
        for value in values:
            if value not in VALID_TEST_IDS:
                raise ValueError("required_completed_tests must contain active scientific assessment system ids")
            if value not in seen:
                seen.add(value)
                cleaned.append(value)
        return cleaned

    @field_validator("house_rules")
    @classmethod
    def validate_house_rules(cls, values: list[str]) -> list[str]:
        cleaned: list[str] = []
        for value in values:
            item = value.strip()
            if not item:
                continue
            if len(item) > 500:
                raise ValueError("each house rule must be at most 500 characters")
            cleaned.append(item)
        if len(cleaned) > 40:
            raise ValueError("house_rules supports at most 40 items")
        return cleaned


class HostProfileOwnerRecord(HostProfileUpsert):
    host_global_id: GlobalId
    host_global_id_display: str
    created_at: datetime
    updated_at: datetime


class HostPublicSummary(BaseModel):
    host_global_id: GlobalId
    host_global_id_display: str
    is_hosting_active: bool
    city_id: UUID
    public_area_text: str | None = None
    sleeping_condition: HospitalitySleepingCondition
    max_guests: int = Field(ge=1)
    max_days: int = Field(ge=1)
    house_rules: list[str] = Field(default_factory=list)
    min_required_rating: float = Field(ge=0.0, le=100.0)
    required_completed_tests: list[str] = Field(default_factory=list)
    availability_mode: HospitalityAvailabilityMode


class HospitalityAvailabilityUpsert(BaseModel):
    date_from: date
    date_to: date
    availability_state: HospitalityAvailabilityState
    capacity_override: int | None = Field(default=None, ge=1, le=100)

    @model_validator(mode="after")
    def validate_interval(self):
        if self.date_to <= self.date_from:
            raise ValueError("date_to must be after date_from")
        return self


class HospitalityAvailabilityRecord(HospitalityAvailabilityUpsert):
    availability_id: UUID
    host_global_id: GlobalId
    created_at: datetime
    updated_at: datetime


class HospitalityEligibilityReason(BaseModel):
    code: str
    required: float | int | str | list[str] | None = None
    actual: float | int | str | list[str] | None = None
    tests: list[str] | None = None


class HospitalityEligibilityResponse(BaseModel):
    eligible: bool
    contract_version: str = "hospitality-eligibility-v1"
    reasons: list[HospitalityEligibilityReason] = Field(default_factory=list)
    account_rating: float = Field(ge=0.0, le=100.0)
    min_required_rating: float = Field(ge=0.0, le=100.0)
    missing_required_tests: list[str] = Field(default_factory=list)
    date_available: bool
    capacity_available: bool
    effective_capacity: int | None = None
    occupied_capacity: int = Field(default=0, ge=0)
    stay_days: int = Field(ge=1)


class HostDetailsResponse(BaseModel):
    host: HostPublicSummary
    eligibility: HospitalityEligibilityResponse | None = None


class HospitalityDiscoverySummary(BaseModel):
    host: HostPublicSummary
    eligibility: HospitalityEligibilityResponse | None = None


class StayRequestCreate(BaseModel):
    host_global_id: GlobalId
    check_in_date: date
    check_out_date: date
    guests_count: int = Field(ge=1, le=100)

    @model_validator(mode="after")
    def validate_dates(self):
        if self.check_out_date <= self.check_in_date:
            raise ValueError("check_out_date must be after check_in_date")
        return self


class StayRequestStatusAction(BaseModel):
    action: StayRequestAction
    reason: str | None = Field(default=None, max_length=1000)
    expected_version: int = Field(ge=1)


class StayRequestRecord(BaseModel):
    request_id: UUID
    guest_global_id: GlobalId
    host_global_id: GlobalId
    check_in_date: date
    check_out_date: date
    guests_count: int = Field(ge=1)
    status: StayRequestStatus
    response_due_at: datetime
    conversation_id: UUID | str
    eligibility_snapshot: dict[str, object]
    rejection_reason: str | None = None
    cancellation_reason: str | None = None
    accepted_at: datetime | None = None
    completed_at: datetime | None = None
    private_access_expires_at: datetime | None = None
    review_deadline_at: datetime | None = None
    version: int = Field(ge=1)
    created_at: datetime
    updated_at: datetime


class HospitalityArrivalDetails(BaseModel):
    request_id: UUID
    exact_address: str
    arrival_instructions: str = ""
    exact_lat: float | None = None
    exact_lon: float | None = None
    arrival_contact: str = ""
    private_access_expires_at: datetime


class HospitalityRequestEventRecord(BaseModel):
    event_id: UUID
    request_id: UUID
    conversation_id: UUID | str
    actor_global_id: GlobalId | None = None
    event_type: str
    public_payload: dict[str, object] = Field(default_factory=dict)
    created_at: datetime


class StayConfirmationUpsert(BaseModel):
    confirmation: StayConfirmationValue


class StayConfirmationRecord(BaseModel):
    request_id: UUID
    global_id: GlobalId
    confirmation: StayConfirmationValue
    created_at: datetime


class HospitalityPrivateAccessAuditRecord(BaseModel):
    audit_id: UUID
    request_id: UUID
    viewer_global_id: GlobalId
    granted: bool
    created_at: datetime


class StayReviewUpsert(BaseModel):
    adequacy: int = Field(ge=1, le=5)
    rules_compliance: int = Field(ge=1, le=5)
    description_accuracy: int = Field(ge=1, le=5)
    review_text: str | None = Field(default=None, max_length=4000)
    private_feedback: str | None = Field(default=None, max_length=4000)


class StayReviewRecord(StayReviewUpsert):
    review_id: UUID
    request_id: UUID
    author_global_id: GlobalId
    target_global_id: GlobalId
    review_score: float = Field(ge=0.0, le=100.0)
    review_contract_version: str
    submitted_at: datetime
    published_at: datetime | None = None
    moderated_at: datetime | None = None


class HospitalityRestrictionRecord(BaseModel):
    restriction_id: UUID
    global_id: GlobalId
    scope: str = Field(pattern=r"^(guest|host|all)$")
    source_incident_id: UUID
    reason_code: str
    starts_at: datetime
    ends_at: datetime | None = None
    created_at: datetime


class HospitalityReputationSummary(BaseModel):
    global_id: GlobalId
    global_id_display: str
    verified_stays_as_host: int = Field(ge=0)
    verified_stays_as_guest: int = Field(ge=0)
    published_reviews: int = Field(ge=0)
    average_host_review: float | None = Field(default=None, ge=0.0, le=100.0)
    average_guest_review: float | None = Field(default=None, ge=0.0, le=100.0)
    active_restriction: bool
    policy_version: str = "hospitality-reputation-v1"


class HospitalityStayVerificationSummary(BaseModel):
    request_id: UUID
    verified: bool
    interaction_id: UUID | None = None
    contract_version: str = "hospitality-stay-v1"
    host_confirmed: bool = False
    guest_confirmed: bool = False
    blocked_by: str | None = None


class HospitalityReviewState(BaseModel):
    request_id: UUID
    can_submit: bool
    own_submitted: bool
    own_published: bool
    review_deadline_at: datetime | None = None
    published_review_count: int = Field(default=0, ge=0, le=2)


class HospitalityPublicReview(BaseModel):
    review_id: UUID
    request_id: UUID
    author_global_id: GlobalId
    target_global_id: GlobalId
    adequacy: int = Field(ge=1, le=5)
    rules_compliance: int = Field(ge=1, le=5)
    description_accuracy: int = Field(ge=1, le=5)
    review_score: float = Field(ge=0.0, le=100.0)
    review_contract_version: str
    review_text: str | None = None
    submitted_at: datetime
    published_at: datetime


class HospitalityIncidentCreate(BaseModel):
    reason_code: str = Field(min_length=2, max_length=120, pattern=r"^[A-Z0-9_:-]+$")
    description: str = Field(min_length=20, max_length=4000)
    evidence_refs: list[str] = Field(default_factory=list, max_length=20)


class TrustModerationDecisionCreate(BaseModel):
    moderator_global_id: GlobalId
    confirmed: bool
    rationale: str = Field(min_length=10, max_length=4000)
    hospitality_restriction_scope: str | None = Field(default=None, pattern=r"^(guest|host|all)$")
    hospitality_restriction_reason_code: str | None = Field(default=None, min_length=2, max_length=120)
    hospitality_restriction_ends_at: datetime | None = None


class TrustModerationDecisionRecord(BaseModel):
    decision_id: UUID
    incident_id: str
    moderator_global_id: GlobalId
    decision: IncidentStatus
    rationale: str
    created_at: datetime


class TrustAppealCreate(BaseModel):
    grounds: str = Field(min_length=20, max_length=4000)


class TrustAppealRecord(BaseModel):
    appeal_id: UUID
    incident_id: str
    appellant_global_id: GlobalId
    grounds: str
    status: str = Field(pattern=r"^(pending|accepted|rejected)$")
    created_at: datetime


class HospitalityTickResult(BaseModel):
    expired_requests: int = Field(ge=0)
    completed_requests: int = Field(ge=0)
    restrictions_expired: int = Field(ge=0)
    reviews_opened: int = Field(ge=0)
    reviews_published: int = Field(default=0, ge=0)


class Person(BaseModel):
    global_id: GlobalId
    global_id_display: str
    name: str
    age: int = Field(ge=18)
    city: str
    distance_km: int = Field(ge=0)
    compatibility: int = Field(ge=0, le=100)
    trust_score: int = Field(ge=0, le=100)
    account_rating: int = Field(ge=0, le=100)
    interests: list[str]
    goals: list[str] = []
    values: list[str] = []
    lifestyle: list[str] = []
    personality32: Personality32 | None = None
    enneagram_type: int | None = Field(default=None, ge=1, le=9)
    zodiac: str | None = None
    numerology: NumerologyProfile | None = None
    hospitality: HospitalityDiscoverySummary | None = None
    friendship_test_score: int = Field(default=0, ge=0, le=100)
    common_tests: int = Field(default=0, ge=0, le=100)
    test_category_scores: dict[str, int] = {}
    quality_fit: int = Field(default=0, ge=0, le=100)
    quality_fit_confidence: int = Field(default=0, ge=0, le=100)
    positive_qualities: list[str] = Field(default_factory=list)
    explanation: str

    @field_validator("global_id_display")
    @classmethod
    def validate_display(cls, value: str) -> str:
        if len(value) != 10 or not value.isdigit() or value == "0000000000":
            raise ValueError("global_id_display must contain exactly 10 digits and cannot be zero")
        return value


class Community(BaseModel):
    id: str
    title: str
    category: str
    city: str
    members: int = Field(ge=0)
    kind: CommunityKind
    online: bool = False
    description: str
    verified_only: bool = False


class CommunityCreate(BaseModel):
    owner_global_id: GlobalId
    title: str = Field(min_length=3, max_length=100)
    category: str = Field(min_length=2, max_length=60)
    city: str
    kind: CommunityKind
    online: bool = False
    description: str = Field(min_length=10, max_length=1000)
    verified_only: bool = False


class CommunityMembershipStatus(BaseModel):
    community_id: str
    global_id: GlobalId
    joined: bool


class QualityRequirementKind(StrEnum):
    PREFERENCE = "preference"
    HARD = "hard"


class QualityFitAvailability(StrEnum):
    AVAILABLE = "AVAILABLE"
    PARTIAL = "PARTIAL"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    HARD_REQUIREMENT_NOT_MET = "HARD_REQUIREMENT_NOT_MET"


class SearchIntentRequirement(BaseModel):
    quality_key: str = Field(min_length=2, max_length=80)
    importance: int = Field(default=3, ge=1, le=5)
    kind: QualityRequirementKind = QualityRequirementKind.PREFERENCE
    minimum_score: int = Field(default=70, ge=0, le=100)


class QualityFitRequirementResult(BaseModel):
    quality_key: str
    label: str
    kind: QualityRequirementKind
    importance: int = Field(ge=1, le=5)
    minimum_score: int = Field(ge=0, le=100)
    score: int | None = Field(default=None, ge=0, le=100)
    coverage_percent: int = Field(default=0, ge=0, le=100)
    status: str
    explanation: str


class QualityFitSpecResponse(BaseModel):
    contract_version: str
    catalog_version: str
    scoring_version: str
    directionality: str
    role_injects_defaults: bool = False
    quality_count: int
    hard_requirements_supported: bool = True
    missing_data_policy: str
    separation_rules: list[str]


class QualityFitCatalogItem(BaseModel):
    quality_key: str
    label: str
    group: str
    target_count: int = Field(ge=1)


class QualityFitCatalogResponse(BaseModel):
    catalog_version: str
    locale: str
    quality_count: int
    groups: list[str]
    qualities: list[QualityFitCatalogItem]


class QualityFitEvaluationRequest(BaseModel):
    searcher_global_id: GlobalId
    candidate_global_id: GlobalId
    search_request_id: UUID | None = None
    role_context: str = Field(min_length=2, max_length=80)
    requirements: list[SearchIntentRequirement] = Field(default_factory=list, max_length=24)
    locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    persist_history: bool = True


class QualityFitEvaluationRecord(BaseModel):
    evaluation_id: UUID
    searcher_global_id: GlobalId
    candidate_global_id: GlobalId
    search_request_id: UUID | None = None
    role_context: str
    direction: str = "A_TO_B"
    contract_version: str
    catalog_version: str
    scoring_version: str
    intent_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    candidate_evidence_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    score: int | None = Field(default=None, ge=0, le=100)
    confidence: int = Field(default=0, ge=0, le=100)
    availability: QualityFitAvailability
    eligible: bool
    requirement_results: list[QualityFitRequirementResult]
    missing_quality_keys: list[str] = Field(default_factory=list)
    explanation: str
    created_at: datetime


class SearchRequestStatus(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"
    ARCHIVED = "archived"


class SearchRequestCreate(BaseModel):
    title: str = Field(min_length=3, max_length=120)
    role: str = Field(min_length=2, max_length=80)
    desired_qualities: list[str] = Field(default_factory=list, max_length=24)
    requirements: list[SearchIntentRequirement] = Field(default_factory=list, max_length=24)
    quality_fit_version: str = Field(default="quality-fit-search-intent-v2", min_length=3, max_length=100)
    city: str | None = Field(default=None, max_length=120)
    radius_km: int = Field(default=25, ge=5, le=500)
    min_trust: int = Field(default=0, ge=0, le=100)
    min_compatibility: int = Field(default=0, ge=0, le=100)
    online_only: bool = False
    verified_only: bool = False
    hospitality_only: bool = False
    notes: str | None = Field(default=None, max_length=1000)


class SearchRequestUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=120)
    role: str | None = Field(default=None, min_length=2, max_length=80)
    desired_qualities: list[str] | None = Field(default=None, max_length=24)
    requirements: list[SearchIntentRequirement] | None = Field(default=None, max_length=24)
    quality_fit_version: str | None = Field(default=None, min_length=3, max_length=100)
    city: str | None = Field(default=None, max_length=120)
    radius_km: int | None = Field(default=None, ge=5, le=500)
    min_trust: int | None = Field(default=None, ge=0, le=100)
    min_compatibility: int | None = Field(default=None, ge=0, le=100)
    online_only: bool | None = None
    verified_only: bool | None = None
    hospitality_only: bool | None = None
    notes: str | None = Field(default=None, max_length=1000)
    status: SearchRequestStatus | None = None


class SearchRequestRecord(SearchRequestCreate):
    request_id: UUID
    owner_global_id: GlobalId
    status: SearchRequestStatus = SearchRequestStatus.ACTIVE
    created_at: datetime
    updated_at: datetime


class IdentityResolveRequest(BaseModel):
    provider: AuthProvider
    provider_subject: str = Field(min_length=1, max_length=300)
    tenant: str = Field(default="default", min_length=1, max_length=80)


class IdentityResolveResponse(BaseModel):
    global_id: GlobalId
    global_id_display: str
    created: bool


class TrustIncidentCreate(BaseModel):
    reporter_global_id: GlobalId
    subject_global_id: GlobalId
    category: str
    occurred_at: str
    description: str = Field(min_length=20, max_length=4000)
    evidence_refs: list[str] = []


class TrustIncident(BaseModel):
    id: str
    reporter_global_id: GlobalId
    subject_global_id: GlobalId
    category: str
    occurred_at: str
    description: str
    evidence_refs: list[str]
    status: IncidentStatus = IncidentStatus.PENDING
    score_impact: int = 0


class TrustModerationResult(BaseModel):
    incident: TrustIncident
    decision: TrustModerationDecisionRecord
    hospitality_restriction: HospitalityRestrictionRecord | None = None


class TrustSummary(BaseModel):
    global_id: GlobalId
    global_id_display: str
    score: int = Field(ge=0, le=100)
    verified_interactions: int
    confirmed_incidents: int
    pending_incidents: int


class AssessmentDimensionResult(BaseModel):
    id: str
    title: str
    score: int = Field(ge=0, le=100)




class AssessmentResponseTrace(BaseModel):
    question_id: str = Field(pattern=r"^f\d{3}q[1-6]$")
    choice_id: str = Field(pattern=r"^[1-4]$")
    paradigm: str = Field(min_length=2, max_length=40)
    scene_archetype: str = Field(min_length=2, max_length=40)
    stimulus_version: str = Field(min_length=3, max_length=80)
    visual_seed: int
    composition_variant: int = Field(ge=0, le=7)
    intensity: int = Field(ge=0, le=3)
    spacing: int = Field(ge=0, le=3)
    order: int = Field(ge=0, le=3)
    asymmetry: int = Field(ge=0, le=3)
    direction: int = Field(ge=0, le=3)
    presentation_slot: int = Field(ge=1, le=4)
    response_latency_ms: int = Field(ge=0, le=600_000)
    selection_changes: int = Field(ge=0, le=20)
    question_position: int = Field(ge=1, le=6)


class AssessmentResultUpsert(BaseModel):
    global_id: GlobalId
    assessment_id: str = Field(pattern=r"^(?:f\d{3}|[a-z][a-z0-9_]{2,63})$")
    scoring_version: str = "scientific-questionnaire-v1"
    stimulus_version: str = Field(default="text-situational-neutral-v1", min_length=3, max_length=80)
    instrument_locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    started_at_epoch_ms: int = Field(gt=0)
    total_score: int = Field(ge=0, le=100)
    risk_score: int = Field(default=0, ge=0, le=100)
    answer_consistency: int = Field(ge=0, le=100)
    idealized_self_presentation: int = Field(ge=0, le=100)
    label: str = Field(min_length=2, max_length=200)
    summary: str = Field(min_length=10, max_length=2000)
    dimensions: list[AssessmentDimensionResult]
    response_trace: list[AssessmentResponseTrace] = Field(default_factory=list, max_length=6)
    completed_at_epoch_ms: int = Field(gt=0)

    @field_validator("response_trace")
    @classmethod
    def validate_response_trace_size(cls, value: list[AssessmentResponseTrace]) -> list[AssessmentResponseTrace]:
        if len(value) not in {0, 6}:
            raise ValueError("legacy response_trace must be empty or contain exactly six rows")
        return value


class AssessmentResultRecord(AssessmentResultUpsert):
    # Raw item-level trace is intentionally removed from the active profile store. It exists only
    # in the separate opt-in calibration-attempt store.
    response_trace: list[AssessmentResponseTrace] = []
    id: str


class CalibrationConsentUpsert(BaseModel):
    global_id: GlobalId
    opt_in: bool
    consent_version: str = Field(default="calibration-consent-v2", min_length=3, max_length=80)
    instrument_locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    eligibility_ack: bool = False
    invite_code: str | None = Field(default=None, min_length=4, max_length=128)


class CalibrationConsentRecord(BaseModel):
    global_id: GlobalId
    opt_in: bool
    consent_version: str
    cohort_id: str
    instrument_locale: str
    enrollment_state: str
    pilot_wave: str
    updated_at: datetime


class CalibrationPilotStatus(BaseModel):
    mode: str
    cohort_id: str
    pilot_wave: str
    consent_version: str
    model_version: str
    stimulus_version: str
    accepted_locales: list[str]
    capacity_total: int
    capacity_used: int
    capacity_remaining: int
    locale_remaining: dict[str, int]
    invite_required: bool
    raw_trace_private: bool = True
    withdrawal_deletes_raw_attempts: bool = True
    automatic_production_mutation: bool = False


class ScientificAssessmentCatalogItem(BaseModel):
    system_id: str
    title: str
    subtitle: str
    item_count: int = Field(ge=1, le=200)
    construct_count: int = Field(ge=1, le=100)
    bank_version: str
    scoring_version: str
    instrument_version: str


class ScientificAssessmentItemPublic(BaseModel):
    item_id: str
    prompt: str
    answer_labels: list[str]


class ScientificAssessmentDefinitionPublic(BaseModel):
    system_id: str
    title: str
    subtitle: str
    item_count: int = Field(ge=1, le=200)
    bank_version: str
    scoring_version: str
    instrument_version: str
    items_public: bool = False


class TestAppCatalogItem(BaseModel):
    app_id: str
    title: str
    subtitle: str
    icon: str
    system_id: str
    item_count: int = Field(ge=1, le=100)
    estimated_minutes: int = Field(ge=1, le=60)
    status: str
    catalog_version: str
    bank_version: str


class TestAppDefinitionPublic(BaseModel):
    app_id: str
    title: str
    subtitle: str
    icon: str
    system_id: str
    item_count: int = Field(ge=1, le=100)
    estimated_minutes: int = Field(ge=1, le=60)
    status: str
    catalog_version: str
    bank_version: str
    scoring_version: str
    instrument_version: str
    items_public: bool = False


class ScientificAssessmentSubmit(BaseModel):
    global_id: GlobalId
    responses: dict[str, int]
    instrument_locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    started_at_epoch_ms: int = Field(gt=0)
    completed_at_epoch_ms: int = Field(gt=0)

    @field_validator("responses")
    @classmethod
    def validate_answers(cls, value: dict[str, int]) -> dict[str, int]:
        if not value:
            raise ValueError("responses cannot be empty")
        if any(answer not in {1, 2, 3, 4} for answer in value.values()):
            raise ValueError("scientific assessment answers must be 1..4")
        return value


class AssessmentPublicReceipt(BaseModel):
    id: str
    global_id: GlobalId
    assessment_id: str
    model_version: str
    completed_at_epoch_ms: int
    status: str = "profile_updated"
    positive_qualities: list[str] = Field(default_factory=list)
    result_title: str = "profile_updated"
    result_summary: str = "profile_updated"
    account_delta_percent: float = Field(default=0.0, ge=0, le=50.0)


class TestResultFeedbackPublic(BaseModel):
    result_id: str = Field(min_length=1, max_length=120)
    app_id: str = Field(min_length=2, max_length=80)
    title: str = Field(min_length=2, max_length=200)
    headline: str = Field(min_length=2, max_length=300)
    lead: str = Field(min_length=10, max_length=3000)
    expressed: list[str] = Field(default_factory=list, max_length=6)
    balance: list[str] = Field(default_factory=list, max_length=6)
    closing: str = Field(min_length=10, max_length=1200)
    completed_at_epoch_ms: int = Field(gt=0)


class TestAdministrationStart(BaseModel):
    global_id: GlobalId
    instrument_locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")


class TestAdministrationAnswerSubmit(BaseModel):
    item_token: UUID
    answer: int = Field(ge=1, le=4)
    response_latency_ms: int = Field(default=0, ge=0, le=600_000)
    selection_changes: int = Field(default=0, ge=0, le=20)
    comprehension_flag: bool = False


class TestAdministrationItemPublic(BaseModel):
    item_token: UUID
    prompt: str = Field(min_length=2, max_length=2000)
    answer_labels: list[str] = Field(min_length=2, max_length=8)
    position: int = Field(ge=1, le=200)
    total: int = Field(ge=1, le=200)


class TestAdministrationSessionPublic(BaseModel):
    session_id: UUID
    app_id: str
    status: str = Field(pattern=r"^(?:IN_PROGRESS|COMPLETED)$")
    position: int = Field(ge=1, le=200)
    item_count: int = Field(ge=1, le=200)
    current_item: TestAdministrationItemPublic | None = None
    started_at_epoch_ms: int = Field(gt=0)
    updated_at_epoch_ms: int = Field(gt=0)
    completed_at_epoch_ms: int | None = None
    result_id: str | None = None


class TestAdministrationSessionRecord(BaseModel):
    session_id: UUID
    global_id: GlobalId
    app_id: str
    instrument_locale: str
    administration_version: str
    bank_version: str
    scoring_version: str
    instrument_version: str
    status: str = Field(pattern=r"^(?:IN_PROGRESS|COMPLETED)$")
    item_order: list[str] = Field(min_length=1, max_length=200)
    item_tokens: dict[str, str]
    responses: dict[str, int] = Field(default_factory=dict)
    response_meta: dict[str, dict] = Field(default_factory=dict)
    current_index: int = Field(default=0, ge=0, le=200)
    started_at_epoch_ms: int = Field(gt=0)
    updated_at_epoch_ms: int = Field(gt=0)
    completed_at_epoch_ms: int | None = None
    result_id: str | None = None



class AssociativeInstrumentCatalogItem(BaseModel):
    method_id: str
    title: str
    subtitle: str
    method_family: str
    instrument_version: str
    scoring_version: str
    estimated_minutes: int = Field(ge=1, le=60)
    source_ids: list[str]
    result_scope: str


class AssociativeInstrumentDefinitionPublic(AssociativeInstrumentCatalogItem):
    stimuli: list[dict[str, Any]]
    instructions: list[str]


class AssociativeEventSubmit(BaseModel):
    stimulus_id: str = Field(min_length=2, max_length=120)
    block_id: str | None = Field(default=None, max_length=120)
    response_text: str | None = Field(default=None, max_length=500)
    action: str | None = Field(default=None, pattern=r"^(left|right)$")
    latency_ms: int = Field(ge=0, le=120_000)
    edit_count: int = Field(default=0, ge=0, le=100)
    omission: bool = False
    error: bool = False
    sequence_index: int = Field(ge=0, le=1000)
    timing_quality: str = Field(default="ok", pattern=r"^(ok|backgrounded|timer_coarse|unknown)$")


class AssociativeMeasurementSubmit(BaseModel):
    global_id: GlobalId
    events: list[AssociativeEventSubmit] = Field(min_length=1, max_length=300)
    instrument_locale: str = Field(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")
    started_at_epoch_ms: int = Field(gt=0)
    completed_at_epoch_ms: int = Field(gt=0)


class AssociativeMeasurementResultUpsert(BaseModel):
    global_id: GlobalId
    method_id: str
    instrument_version: str
    scoring_version: str
    instrument_locale: str
    started_at_epoch_ms: int = Field(gt=0)
    completed_at_epoch_ms: int = Field(gt=0)
    input_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    public_features: dict[str, int]
    derived_details: dict[str, Any]
    result_title: str
    result_summary: str
    raw_events: list[AssociativeEventSubmit]

    @field_validator("public_features")
    @classmethod
    def validate_public_features(cls, value: dict[str, int]) -> dict[str, int]:
        if not value or any(score < 0 or score > 100 for score in value.values()):
            raise ValueError("public associative features must be in 0..100")
        return value


class AssociativeMeasurementResultPublic(BaseModel):
    result_id: str
    global_id: GlobalId
    method_id: str
    instrument_version: str
    scoring_version: str
    instrument_locale: str
    completed_at_epoch_ms: int
    input_snapshot_hash: str
    public_features: dict[str, int]
    derived_details: dict[str, Any]
    result_title: str
    result_summary: str
    created_at: datetime


class AssociativeCompatibilityRequest(BaseModel):
    first_global_id: GlobalId
    second_global_id: GlobalId
    method_id: str


class AssociativeCompatibilityResponse(BaseModel):
    method_id: str
    score: int | None = Field(default=None, ge=0, le=100)
    coverage: int = Field(ge=0, le=100)
    feature_scores: dict[str, int]


class AccountRatingRequest(BaseModel):
    completed_profile_section_codes: list[str]
    completed_test_ids: list[str]


class AccountRatingResponse(BaseModel):
    total: float = Field(ge=0, le=100)
    profile_points: float = Field(ge=0, le=50)
    test_points: float = Field(ge=0, le=50)
    completed_profile_sections: int
    completed_tests: int


class CompatibilityRequest(BaseModel):
    my_scores: dict[str, int]
    candidate_scores: dict[str, int]
    shared_interest_percent: int = Field(ge=0, le=100)
    trust_score: int = Field(ge=0, le=100)


class CompatibilityResponse(BaseModel):
    score: int = Field(ge=0, le=100)
    tests_score: int = Field(ge=0, le=100)
    common_tests: int
    confidence: int = Field(ge=0, le=100)
    category_scores: dict[str, int] = {}


class CompatibilityMetricId(StrEnum):
    PC = "PC"
    IC = "IC"
    VC = "VC"
    CC = "CC"
    LC = "LC"
    PT = "PT"
    EN = "EN"
    NU = "NU"
    AS = "AS"


class CompatibilityMetricStatus(StrEnum):
    AVAILABLE = "AVAILABLE"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"


class IndependentCompatibilityRequest(BaseModel):
    requester_global_id: GlobalId
    candidate_global_id: GlobalId
    selected_metrics: list[CompatibilityMetricId] | None = None

    @model_validator(mode="after")
    def validate_pair(self):
        if self.requester_global_id == self.candidate_global_id:
            raise ValueError("compatibility requires two different users")
        if self.selected_metrics is not None:
            if not self.selected_metrics:
                raise ValueError("selected_metrics cannot be empty when provided")
            if len(set(self.selected_metrics)) != len(self.selected_metrics):
                raise ValueError("selected_metrics must not contain duplicates")
        return self


class IndependentCompatibilityMetric(BaseModel):
    id: CompatibilityMetricId
    score: int | None = Field(default=None, ge=0, le=100)
    coverage: int = Field(ge=0, le=100)
    evidence_count: int = Field(default=0, ge=0)
    model_version: str = Field(min_length=1, max_length=120)
    status: CompatibilityMetricStatus
    evidence_origin: str = Field(min_length=1, max_length=160)


class AssessmentModuleCompatibilityMetric(BaseModel):
    module_id: str
    score: int | None = Field(default=None, ge=0, le=100)
    common_assessments: int = Field(ge=0, le=100)
    total_assessments: int = Field(ge=1, le=100)
    coverage: int = Field(ge=0, le=100)
    status: CompatibilityMetricStatus
    model_version: str = "scientific-questionnaire-v1"


class IndependentCompatibilityResponse(BaseModel):
    contract_version: str = "independent-compatibility-v1"
    requester_global_id: GlobalId
    candidate_global_id: GlobalId
    selected_metrics: list[CompatibilityMetricId]
    metrics: list[IndependentCompatibilityMetric]
    psychological_modules: list[AssessmentModuleCompatibilityMetric]
    overall: int | None = Field(default=None, ge=0, le=100)
    overall_status: CompatibilityMetricStatus
    aggregation: str = "UNWEIGHTED_ARITHMETIC_MEAN_OF_SELECTED_AVAILABLE_METRICS"
    incomplete_selected_metrics: list[CompatibilityMetricId] = Field(default_factory=list)
    trust_score: int | None = Field(default=None, ge=0, le=100)
    account_rating: int | None = Field(default=None, ge=0, le=100)
    separate_signals_note: str = "Trust, Account Rating and Quality Fit are separate from Compatibility."


class CompatibilityMetricPreferencesUpsert(BaseModel):
    global_id: GlobalId
    selected_metrics: list[CompatibilityMetricId]
    contract_version: str = "independent-compatibility-v1"

    @field_validator("selected_metrics")
    @classmethod
    def validate_selected_metrics(cls, value: list[CompatibilityMetricId]) -> list[CompatibilityMetricId]:
        if not value:
            raise ValueError("selected_metrics cannot be empty")
        if len(set(value)) != len(value):
            raise ValueError("selected_metrics must not contain duplicates")
        canonical = list(CompatibilityMetricId)
        return [metric for metric in canonical if metric in value]


class CompatibilityMetricPreferencesRecord(CompatibilityMetricPreferencesUpsert):
    global_id_display: str
    updated_at: datetime


class PsychologicalTestSystemDefinition(BaseModel):
    system_id: str
    title: str
    subtitle: str
    total_series: int = Field(ge=1, le=100)
    source_ids: list[str]
    assessment_ids: list[str]
    construct_note: str
    model_version: str
    calibration_version: str
    calibration_basis: str
    evidence_bundle_id: str
    evidence_bundle_version: str
    release_baseline_status: str
    future_recalibration_policy: str
    compatibility_feature_ids: list[str]


class PsychologicalTestSystemResult(BaseModel):
    system_id: str
    title: str
    subtitle: str
    model_version: str
    calibration_version: str
    calibration_basis: str
    evidence_bundle_version: str
    release_baseline_status: str
    future_recalibration_policy: str
    compatibility_ready: bool
    status: str
    completed_series: int = Field(ge=0, le=100)
    total_series: int = Field(ge=1, le=100)
    coverage_percent: int = Field(ge=0, le=100)
    series_coverage_percent: int = Field(ge=0, le=100)
    construct_coverage_percent: int = Field(ge=0, le=100)
    characteristics: list[str] = Field(default_factory=list)
    growth_areas: list[str] = Field(default_factory=list)
    summary: str
    source_ids: list[str]
    construct_note: str
    private_trait_scores: dict[str, int] = Field(exclude=True, default_factory=dict)
    private_trait_evidence: dict[str, int] = Field(exclude=True, default_factory=dict)


class PsychologicalTestSystemCompatibility(BaseModel):
    system_id: str
    score: int | None = Field(default=None, ge=0, le=100)
    coverage: int = Field(ge=0, le=100)
    status: str
    common_constructs: int = Field(ge=0)
    model_version: str
    calibration_version: str
    evidence_bundle_version: str
    future_recalibration_policy: str
    method: str


class PsychologicalReportInputAssessment(BaseModel):
    assessment_id: str = Field(pattern=r"^(?:f\d{3}|[a-z][a-z0-9_]{2,63})$")
    result_id: str = Field(min_length=1, max_length=120)
    scoring_version: str = Field(min_length=1, max_length=120)
    stimulus_version: str = Field(min_length=1, max_length=120)
    total_score: int = Field(ge=0, le=100)
    answer_consistency: int = Field(ge=0, le=100)
    dimensions: list[AssessmentDimensionResult]
    completed_at_epoch_ms: int = Field(gt=0)


class PsychologicalReportSection(BaseModel):
    key: str = Field(min_length=1, max_length=80)
    title: str = Field(min_length=1, max_length=240)
    body: str = Field(max_length=12000)


class PsychologicalReportUpsert(BaseModel):
    global_id: GlobalId
    report_version: str = Field(min_length=3, max_length=120)
    model_version: str = Field(min_length=1, max_length=500)
    created_at_epoch_ms: int = Field(gt=0)
    input_snapshot: list[PsychologicalReportInputAssessment]
    completed_assessment_ids: list[str]
    coverage_percent: int = Field(ge=0, le=100)
    summary: str = Field(max_length=12000)
    sections: list[PsychologicalReportSection]
    strengths: list[str] = Field(default_factory=list, max_length=100)
    growth_areas: list[str] = Field(default_factory=list, max_length=100)
    limitations: list[str] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def validate_snapshot(self):
        snapshot_ids = [item.assessment_id for item in self.input_snapshot]
        if len(set(snapshot_ids)) != len(snapshot_ids):
            raise ValueError("input_snapshot contains duplicate assessment_id")
        if sorted(snapshot_ids) != sorted(self.completed_assessment_ids):
            raise ValueError("completed_assessment_ids must match input_snapshot assessment ids")
        return self


class PsychologicalReportRecord(PsychologicalReportUpsert):
    report_id: UUID
    input_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    persisted_at: datetime


class PsychologicalReportHistoryItem(BaseModel):
    report_id: UUID
    global_id: GlobalId
    report_version: str
    model_version: str
    created_at_epoch_ms: int
    input_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    coverage_percent: int = Field(ge=0, le=100)
    completed_assessment_count: int = Field(ge=0, le=100)
    persisted_at: datetime


class FriendshipOutcomeUpsert(BaseModel):
    connection_id: str = Field(min_length=8, max_length=80)
    first_global_id: GlobalId
    second_global_id: GlobalId
    matched_at: datetime
    layer_scores: dict[str, int]
    searcher_global_id: GlobalId | None = None
    search_role: str | None = Field(default=None, pattern=r"^(friend|close_friend|business_partner|director|project_teammate|mentor|activity_partner|custom)$")
    desired_qualities: dict[str, int] = {}
    quality_fit_score: int | None = Field(default=None, ge=0, le=100)
    quality_fit_confidence: int | None = Field(default=None, ge=0, le=100)
    quality_model_version: str | None = Field(default=None, max_length=64)
    still_active_30d: bool | None = None
    still_active_90d: bool | None = None
    ended_reason: str | None = Field(default=None, pattern=r"^(block|report|silent_fade|mutual_end|other)$")
    messages_exchanged_30d: int | None = Field(default=None, ge=0)

    @field_validator("desired_qualities")
    @classmethod
    def validate_desired_qualities(cls, value: dict[str, int]) -> dict[str, int]:
        if len(value) > 40:
            raise ValueError("desired_qualities supports at most 40 selected qualities")
        invalid = {key: importance for key, importance in value.items() if not key or importance < 1 or importance > 5}
        if invalid:
            raise ValueError("desired quality importance must be in 1..5")
        return value

    @field_validator("layer_scores")
    @classmethod
    def validate_layer_scores(cls, value: dict[str, int]) -> dict[str, int]:
        if not value:
            raise ValueError("layer_scores cannot be empty")
        invalid = {key: score for key, score in value.items() if score < 0 or score > 100}
        if invalid:
            raise ValueError("layer_scores must be in 0..100")
        return value


class FriendshipOutcomeRecord(FriendshipOutcomeUpsert):
    updated_at: datetime



class FriendshipPatternObservationUpsert(BaseModel):
    observation_id: str = Field(min_length=8, max_length=100)
    first_global_id: GlobalId
    second_global_id: GlobalId
    snapshot_at: datetime
    exposure_policy_version: str = Field(min_length=2, max_length=100)
    predictor_snapshot_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    similarity_features: dict[str, int]
    difference_features: dict[str, int] = {}
    method_scores: dict[str, int] = {}
    outcome_status: str = Field(pattern=r"^(CONFIRMED_FRIENDSHIP|ACTIVE_RELATIONSHIP|NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE|INSUFFICIENT_INTERACTION)$")
    confirmed_by_both: bool = False
    observation_window_days: int = Field(ge=1, le=3650)

    @field_validator("similarity_features", "difference_features", "method_scores")
    @classmethod
    def validate_pattern_features(cls, value: dict[str, int]) -> dict[str, int]:
        if any(score < 0 or score > 100 for score in value.values()):
            raise ValueError("friendship pattern features must be in 0..100")
        return value

    @model_validator(mode="after")
    def validate_pair(self):
        if self.first_global_id == self.second_global_id:
            raise ValueError("friendship pattern observation requires two different users")
        if self.outcome_status == "CONFIRMED_FRIENDSHIP" and not self.confirmed_by_both:
            raise ValueError("confirmed friendship requires bilateral confirmation")
        return self


class FriendshipPatternObservationRecord(FriendshipPatternObservationUpsert):
    created_at: datetime


class FriendshipPatternSignal(BaseModel):
    feature_id: str
    feature_family: str
    friend_mean: float
    comparison_mean: float
    delta_points: float
    absolute_signal_points: float
    friend_n: int
    comparison_n: int
    observed_direction: str


class FriendshipPatternAnalysisResponse(BaseModel):
    analysis_version: str
    confirmed_friendship_pairs: int
    comparison_pairs: int
    top_patterns: list[FriendshipPatternSignal]
    note: str


class MessageCreate(BaseModel):
    # Compatibility endpoint retained for pre-v0.5.9 clients. New direct chats use ChatMessageCreate.
    sender_global_id: GlobalId
    recipient_global_id: GlobalId
    client_message_id: str = Field(min_length=8, max_length=120)
    body: str = Field(min_length=1, max_length=4000)
    created_at_epoch_ms: int = Field(gt=0)


class MessageRecord(MessageCreate):
    id: str
    status: str = Field(pattern=r"^(queued|sent|delivered|read)$")


class ConversationType(StrEnum):
    DIRECT = "direct"
    GROUP = "group"
    COMMUNITY = "community"


class EncryptionMode(StrEnum):
    E2EE = "e2ee"
    SERVER = "server"


class AttachmentKind(StrEnum):
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    FILE = "file"


class DeviceKeyUpsert(BaseModel):
    device_id: str = Field(min_length=8, max_length=120)
    identity_public_key_b64: str = Field(min_length=32, max_length=4096)
    prekey_id: str = Field(min_length=4, max_length=120)
    prekey_public_key_b64: str = Field(min_length=32, max_length=4096)
    prekey_signature_b64: str = Field(min_length=16, max_length=4096)


class DeviceKeyRecord(DeviceKeyUpsert):
    global_id: GlobalId
    global_id_display: str
    created_at_epoch_ms: int


class DirectConversationCreate(BaseModel):
    peer_global_id: GlobalId


class GroupConversationCreate(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    member_global_ids: list[GlobalId] = []


class ConversationSummary(BaseModel):
    id: str
    conversation_type: ConversationType
    title: str
    peer_global_id: GlobalId | None = None
    member_count: int = Field(ge=1)
    encryption_mode: EncryptionMode
    last_message_preview: str = ""
    last_message_at_epoch_ms: int | None = None
    unread_count: int = Field(default=0, ge=0)


class ConversationMemberRecord(BaseModel):
    global_id: GlobalId
    global_id_display: str
    role: str = Field(pattern=r"^(owner|admin|member)$")


class ChatAttachmentInput(BaseModel):
    client_attachment_id: str = Field(min_length=8, max_length=120)
    kind: AttachmentKind
    mime_type: str = Field(min_length=3, max_length=120)
    file_name: str = Field(min_length=1, max_length=255)
    byte_size: int = Field(gt=0, le=4_000_000)
    data_b64: str = Field(min_length=8)
    nonce_b64: str | None = Field(default=None, max_length=256)


class ChatAttachmentRecord(BaseModel):
    id: str
    client_attachment_id: str
    kind: AttachmentKind
    mime_type: str
    file_name: str
    byte_size: int
    nonce_b64: str | None = None


class ChatMessageCreate(BaseModel):
    client_message_id: str = Field(min_length=8, max_length=120)
    message_type: str = Field(default="text", pattern=r"^(text|media|system|edit)$")
    encryption_mode: EncryptionMode
    body: str | None = Field(default=None, max_length=4000)
    ciphertext_b64: str | None = Field(default=None, max_length=100_000)
    nonce_b64: str | None = Field(default=None, max_length=256)
    key_id: str | None = Field(default=None, max_length=120)
    ratchet_counter: int | None = Field(default=None, ge=0)
    sender_ephemeral_public_key_b64: str | None = Field(default=None, max_length=4096)
    recipient_prekey_id: str | None = Field(default=None, max_length=120)
    reply_to_message_id: str | None = None
    attachments: list[ChatAttachmentInput] = []
    created_at_epoch_ms: int = Field(gt=0)


class ChatMessageEdit(BaseModel):
    encryption_mode: EncryptionMode
    body: str | None = Field(default=None, max_length=4000)
    ciphertext_b64: str | None = Field(default=None, max_length=100_000)
    nonce_b64: str | None = Field(default=None, max_length=256)
    key_id: str | None = Field(default=None, max_length=120)
    ratchet_counter: int | None = Field(default=None, ge=0)
    sender_ephemeral_public_key_b64: str | None = Field(default=None, max_length=4096)
    recipient_prekey_id: str | None = Field(default=None, max_length=120)
    edited_at_epoch_ms: int = Field(gt=0)


class MessageReactionRequest(BaseModel):
    emoji: str = Field(min_length=1, max_length=16)


class MessageReactionRecord(BaseModel):
    message_id: str
    global_id: GlobalId
    emoji: str


class TypingRequest(BaseModel):
    typing: bool = True


class TypingStatus(BaseModel):
    global_ids: list[GlobalId] = []


class UserBlockRequest(BaseModel):
    blocked: bool = True


class UserBlockStatus(BaseModel):
    subject_global_id: GlobalId
    blocked: bool


class ChatReportCreate(BaseModel):
    category: str = Field(default="chat_abuse", min_length=3, max_length=80)
    description: str = Field(min_length=20, max_length=4000)
    evidence_refs: list[str] = []


class PushTokenUpsert(BaseModel):
    device_id: str = Field(min_length=8, max_length=120)
    provider: str = Field(default="fcm", pattern=r"^(fcm)$")
    token: str = Field(min_length=16, max_length=4096)


class ChatMessageRecord(BaseModel):
    id: str
    conversation_id: str
    sender_global_id: GlobalId
    client_message_id: str
    message_type: str
    encryption_mode: EncryptionMode
    body: str | None = None
    ciphertext_b64: str | None = None
    nonce_b64: str | None = None
    key_id: str | None = None
    ratchet_counter: int | None = None
    sender_ephemeral_public_key_b64: str | None = None
    recipient_prekey_id: str | None = None
    reply_to_message_id: str | None = None
    attachments: list[ChatAttachmentRecord] = []
    status: str = Field(pattern=r"^(queued|sent|delivered|read|deleted)$")
    created_at_epoch_ms: int
    edited_at_epoch_ms: int | None = None
    reactions: dict[str, int] = {}
    delivered_count: int = Field(default=0, ge=0)
    read_count: int = Field(default=0, ge=0)


class AttachmentPayload(BaseModel):
    attachment: ChatAttachmentRecord
    encryption_mode: EncryptionMode
    data_b64: str


class ReadReceiptRequest(BaseModel):
    message_id: str


class AppVersionManifest(BaseModel):
    version_code: int = Field(ge=1)
    version_name: str
    min_supported_version_code: int = Field(ge=1)
    play_url: str | None = None
    test_download_url: str | None = None
    release_notes: str = ""
