from app.test_apps import APPS, APP_BY_ID, public_definition, score_to_upsert
from app.scientific_assessment_bank import ITEMS
from app.psychological_test_systems import BY_ID, system_result


def test_product_test_apps_partition_full_scientific_bank_once():
    assigned=[item_id for app in APPS for item_id in app['item_ids']]
    assert len(APPS)==12
    assert len(assigned)==197
    assert len(set(assigned))==197
    assert set(assigned)=={row['item_id'] for row in ITEMS}


def test_every_test_app_is_standalone_and_scoreable():
    for idx, app in enumerate(APPS):
        d=public_definition(app['app_id'])
        assert d['item_count']==len(app['item_ids'])>=12
        assert d['items_public'] is False and 'items' not in d and 'construct_ids' not in d
        responses={item_id:1+((i+idx)%4) for i,item_id in enumerate(app['item_ids'])}
        result=score_to_upsert(global_id=1,app_id=app['app_id'],responses=responses,instrument_locale='ru',started_at_epoch_ms=1_700_000_000_000,completed_at_epoch_ms=1_700_000_100_000)
        assert result.assessment_id==app['app_id']
        assert result.dimensions
        assert result.response_trace==[]


def test_app_results_feed_parent_scientific_system():
    app=APP_BY_ID['big_five']
    d=public_definition(app['app_id'])
    assert d['items_public'] is False and 'items' not in d
    responses={item_id:4 for item_id in app['item_ids']}
    result=score_to_upsert(global_id=1,app_id=app['app_id'],responses=responses,instrument_locale='ru',started_at_epoch_ms=1_700_000_000_000,completed_at_epoch_ms=1_700_000_100_000).model_copy(update={'id':'r1'})
    profile=system_result(BY_ID['traits_core'],[result])
    assert profile['status']=='PROFILE_READY'
    assert profile['construct_coverage_percent']>0
