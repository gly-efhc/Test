from app.quality_matching import aggregate_latent, parse_desired_qualities, positive_projection, quality_fit


def test_user_selected_quality_matches_hidden_trait_without_rewriting_role() -> None:
    docs = [
        {
            "answer_consistency": 90,
            "dimensions": [
                {"id": "leadership_orientation", "score": 88},
                {"id": "risk_tolerance", "score": 75},
            ],
        },
        {
            "answer_consistency": 80,
            "dimensions": [{"id": "leadership_orientation", "score": 82}],
        },
    ]
    traits, confidence = aggregate_latent(docs)
    desired = parse_desired_qualities(["leader:5", "cautious:2", "unknown:5"])
    score, fit_confidence, matched = quality_fit(desired, traits, confidence, "ru")
    assert 0 <= score <= 100
    assert fit_confidence > 0
    assert "Лидерский" in matched


def test_opposite_poles_are_both_publicly_positive() -> None:
    assert "decisive" in parse_desired_qualities(["decisive"])[0][0]
    assert "deliberate" in parse_desired_qualities(["deliberate"])[0][0]
    projection = positive_projection({"decisiveness": 22, "risk_tolerance": 20}, "ru")
    assert projection
    assert all("плох" not in item.lower() for item in projection)


def test_composite_demanding_quality_uses_multiple_coordinates() -> None:
    traits = {
        "achievement_orientation": 88,
        "rule_orientation": 82,
        "assertiveness": 78,
        "dependability": 84,
    }
    desired = parse_desired_qualities(["demanding:5"])
    score, confidence, matched = quality_fit(desired, traits, 90, "ru")
    assert score >= 90
    assert confidence >= 80
    assert "Требовательный" in matched

def test_role_never_injects_quality_catalog_defaults() -> None:
    # The quality engine has no role argument; only explicit desired qualities reach scoring.
    score, confidence, matched = quality_fit([], {"leadership_orientation": 100}, 100, "ru")
    assert (score, confidence, matched) == (0, 0, [])
