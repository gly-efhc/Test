from uuid import UUID

from app.models import TestAdministrationAnswerSubmit as AdminAnswerSubmit, TestAdministrationSessionRecord as AdminSessionRecord
from app.respondent_wording import canonical_answer, respondent_answer_labels, side_order
from app.scientific_assessment_bank import BANK, ITEM_BY_ID
from app.test_administration import submit_answer


def test_bank_v13_has_180_neutral_situational_items_and_17_separate_anchors() -> None:
    assert BANK["version"] == "scientific-questionnaire-bank-v1.3"
    assert BANK["instrument_version"] == "text-situational-neutral-v1"
    assert BANK["scoring_version"] == "scientific-questionnaire-v1"
    situational = [row for row in BANK["items"] if row["item_type"] != "DIRECT_PUBLIC_DOMAIN"]
    anchors = [row for row in BANK["items"] if row["item_type"] == "DIRECT_PUBLIC_DOMAIN"]
    assert len(situational) == 180
    assert len(anchors) == 17
    for row in situational:
        assert row["wording_version"] == "respondent-neutral-v1"
        assert row["respondent_pole_names_exposed"] is False
        assert row["desirability_balance_review"] == "PASS_BEHAVIORAL_PAIR_REVIEW_V1"
        assert row["pole_a_ru"] not in row["respondent_option_a_ru"]
        assert row["pole_b_ru"] not in row["respondent_option_b_ru"]
    assert all(row["respondent_design_role"] == "DIRECT_PUBLIC_DOMAIN_ANCHOR" for row in anchors)
    assert all(row["side_randomization"] == "NOT_APPLICABLE" for row in anchors)


def test_situational_side_order_is_stable_and_answer_mapping_preserves_canonical_scoring() -> None:
    item = ITEM_BY_ID["TRAITS_CORE-01"]
    even = UUID("00000000-0000-0000-0000-000000000002")
    odd = UUID("00000000-0000-0000-0000-000000000003")
    assert side_order(item, even) == "AB"
    assert side_order(item, odd) == "BA"
    labels_ab = respondent_answer_labels(item, even)
    labels_ba = respondent_answer_labels(item, odd)
    assert labels_ba == list(reversed(labels_ab))
    assert canonical_answer(item, even, 1) == 1
    assert canonical_answer(item, odd, 1) == 4
    assert canonical_answer(item, odd, 4) == 1
    assert item["pole_a_ru"] not in " ".join(labels_ab)
    assert item["pole_b_ru"] not in " ".join(labels_ab)


def test_direct_anchor_is_not_side_randomized() -> None:
    item = ITEM_BY_ID["MIPIP-E-01"]
    token = UUID("00000000-0000-0000-0000-000000000003")
    assert side_order(item, token) == "NA"
    assert respondent_answer_labels(item, token) == item["answer_labels_ru"]
    assert canonical_answer(item, token, 2) == 2


def test_response_meta_records_wording_side_and_comprehension_without_changing_public_shape() -> None:
    item_id = "TRAITS_CORE-01"
    token = "00000000-0000-0000-0000-000000000003"
    record = AdminSessionRecord(
        session_id=UUID("10000000-0000-0000-0000-000000000001"),
        global_id=1,
        app_id="big_five",
        instrument_locale="ru",
        administration_version="secure-test-administration-v2-neutral-wording",
        bank_version="scientific-questionnaire-bank-v1.3",
        scoring_version="scientific-questionnaire-v1",
        instrument_version="text-situational-neutral-v1",
        status="IN_PROGRESS",
        item_order=[item_id],
        item_tokens={item_id: token},
        responses={},
        response_meta={},
        current_index=0,
        started_at_epoch_ms=1,
        updated_at_epoch_ms=1,
    )
    updated = submit_answer(
        record=record,
        payload=AdminAnswerSubmit(
            item_token=UUID(token), answer=1, response_latency_ms=900, selection_changes=1, comprehension_flag=True
        ),
    )
    assert updated.responses[item_id] == 4
    assert updated.response_meta[item_id] == {
        "response_latency_ms": 900,
        "selection_changes": 1,
        "position": 1,
        "wording_version": "respondent-neutral-v1",
        "side_order": "BA",
        "comprehension_flag": True,
    }
