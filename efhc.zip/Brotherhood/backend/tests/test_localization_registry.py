from app.localization import supported_locale_tags, public_language_catalog
from app.calibration_pilot import pilot_config

EXPECTED=("sw","ru","en","uk","de","fr","es","it","tr","pl","da","hi","id")


def test_supported_locales_match_owner_q31():
    assert supported_locale_tags() == EXPECTED
    assert tuple(row["tag"] for row in public_language_catalog()) == EXPECTED


def test_calibration_pilot_default_locales_follow_shared_registry(monkeypatch):
    monkeypatch.delenv("BROTHERHOOD_CALIBRATION_LOCALES", raising=False)
    monkeypatch.delenv("BROTHERHOOD_CALIBRATION_LOCALE_LIMITS", raising=False)
    monkeypatch.delenv("BROTHERHOOD_CALIBRATION_MAX_PARTICIPANTS", raising=False)
    monkeypatch.setenv("BROTHERHOOD_CALIBRATION_DEFAULT_LOCALE_LIMIT", "6")
    cfg=pilot_config()
    assert cfg.accepted_locales == EXPECTED
    assert cfg.max_participants == 78
    assert cfg.locale_limits == {tag:6 for tag in EXPECTED}
