from fastapi.testclient import TestClient
import base64
import hashlib
import os
from app.main import app
from app.storage import (
    ASSESSMENT_RESULTS, INCIDENTS, IDENTITIES, MESSAGES, CHAT_CONVERSATIONS, CHAT_MESSAGES,
    CHAT_ATTACHMENT_DATA, DEVICE_KEYS, USER_BLOCKS, PUSH_TOKENS, FRIENDSHIP_OUTCOMES, PROFILE_AVATARS,
    CALIBRATION_CONSENTS, CALIBRATION_ATTEMPTS, CALIBRATION_INVITE_REDEMPTIONS,
    PSYCHOLOGICAL_REPORTS, COMPATIBILITY_METRIC_PREFERENCES,
)

client = TestClient(app)
PILOT_INVITE = "BROTHERHOOD-PILOT-TEST-001"


def setup_function() -> None:
    os.environ["BROTHERHOOD_CALIBRATION_PILOT_MODE"] = "closed"
    os.environ["BROTHERHOOD_CALIBRATION_INVITE_SHA256"] = hashlib.sha256(PILOT_INVITE.encode("utf-8")).hexdigest()
    os.environ["BROTHERHOOD_CALIBRATION_MAX_PARTICIPANTS"] = "9"
    os.environ["BROTHERHOOD_CALIBRATION_DEFAULT_LOCALE_LIMIT"] = "3"
    os.environ["BROTHERHOOD_CALIBRATION_LOCALES"] = "ru,uk,en"
    INCIDENTS.clear()
    ASSESSMENT_RESULTS.clear()
    MESSAGES.clear()
    CHAT_CONVERSATIONS.clear()
    CHAT_MESSAGES.clear()
    CHAT_ATTACHMENT_DATA.clear()
    DEVICE_KEYS.clear()
    USER_BLOCKS.clear()
    PUSH_TOKENS.clear()
    FRIENDSHIP_OUTCOMES.clear()
    PROFILE_AVATARS.clear()
    CALIBRATION_CONSENTS.clear()
    CALIBRATION_ATTEMPTS.clear()
    CALIBRATION_INVITE_REDEMPTIONS.clear()
    PSYCHOLOGICAL_REPORTS.clear()
    COMPATIBILITY_METRIC_PREFERENCES.clear()




def test_health() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["version"] == "0.5.35"


def test_people_are_filtered_by_city_and_radius() -> None:
    response = client.get("/v1/people", params={"city": "Киев", "radius_km": 10})
    assert response.status_code == 200
    body = response.json()
    assert [item["global_id_display"] for item in body] == ["0000000002"]
    assert body[0]["personality32"]["code"] == "EPLSG"


def test_identity_resolver_is_stable_and_allocates_global_id() -> None:
    payload = {"provider": "telegram", "tenant": "default", "provider_subject": "new-user-123"}
    first = client.post("/internal/identity/resolve", json=payload)
    second = client.post("/internal/identity/resolve", json=payload)
    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()["global_id"] == second.json()["global_id"]
    assert len(first.json()["global_id_display"]) == 10
    assert first.json()["created"] is True
    assert second.json()["created"] is False


def test_business_communities_include_online_groups() -> None:
    response = client.get("/v1/communities", params={"city": "Киев", "kind": "business"})
    assert response.status_code == 200
    assert any(item["kind"] == "business" for item in response.json())


def test_pending_incident_does_not_reduce_public_score() -> None:
    before = client.get("/v1/trust/2").json()["score"]
    created = client.post("/v1/trust/incidents", json={
        "reporter_global_id": 1,
        "subject_global_id": 2,
        "category": "breach_of_agreement",
        "occurred_at": "2026-07-30",
        "description": "Пользователь нарушил заранее принятую существенную договорённость.",
        "evidence_refs": ["evidence-private-1"]
    })
    assert created.status_code == 201
    after = client.get("/v1/trust/2").json()
    assert after["score"] == before
    assert after["pending_incidents"] == 1
    assert after["global_id_display"] == "0000000002"


def test_confirmed_incident_reduces_score() -> None:
    created = client.post("/v1/trust/incidents", json={
        "reporter_global_id": 1,
        "subject_global_id": 2,
        "category": "privacy_breach",
        "occurred_at": "2026-07-30",
        "description": "Конфиденциальная информация была передана третьему лицу без согласия.",
        "evidence_refs": ["evidence-private-2"]
    }).json()
    moderated = client.post(f"/v1/trust/incidents/{created['id']}/moderate", params={"confirmed": True})
    assert moderated.status_code == 200
    summary = client.get("/v1/trust/2").json()
    assert summary["score"] == 82
    assert summary["confirmed_incidents"] == 1







def test_role_alone_does_not_inject_quality_targets() -> None:
    response = client.get("/v1/people", params={"city": "Киев", "radius_km": 10, "role": "director", "qualities": ""})
    assert response.status_code == 200
    assert response.json()[0]["quality_fit"] == 0





def test_withdrawal_is_unconditional_when_pilot_disabled_and_locale_configuration_changes() -> None:
    joined = client.put("/v1/calibration-consent", json={
        "global_id": 4, "opt_in": True, "instrument_locale": "en", "eligibility_ack": True,
        "invite_code": PILOT_INVITE, "consent_version": "calibration-consent-v2",
    })
    assert joined.status_code == 200
    os.environ["BROTHERHOOD_CALIBRATION_PILOT_MODE"] = "disabled"
    os.environ["BROTHERHOOD_CALIBRATION_LOCALES"] = "ru,uk"
    withdrawal = client.put("/v1/calibration-consent", json={
        "global_id": 4, "opt_in": False, "instrument_locale": "zz",
        "consent_version": "calibration-consent-v2",
    })
    assert withdrawal.status_code == 200
    assert withdrawal.json()["enrollment_state"] == "withdrawn"











def test_retired_friendship_expectations_shadow_is_not_public() -> None:
    response = client.post("/v1/compatibility", json={
        "my_scores": {"f065": 80, "f071": 70},
        "candidate_scores": {"f065": 80, "f071": 70},
        "shared_interest_percent": 0,
        "trust_score": 0,
    })
    assert response.status_code == 200
    assert "friendship_expectations_score" not in response.json()


def test_database_health_without_configuration(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    response = client.get("/health/database")
    assert response.status_code == 200
    assert response.json() == {"configured": False, "status": "not_configured"}




def test_message_is_idempotent_by_client_message_id() -> None:
    payload = {
        "sender_global_id": 1,
        "recipient_global_id": 2,
        "client_message_id": "local-message-0001",
        "body": "Привет. Предлагаю сыграть в футбол в субботу.",
        "created_at_epoch_ms": 1785450000000
    }
    first = client.post("/v1/messages", json=payload)
    second = client.post("/v1/messages", json=payload)
    assert first.status_code == 201
    assert second.status_code == 201
    assert first.json()["id"] == second.json()["id"]
    listed = client.get("/v1/messages/1")
    assert len(listed.json()) == 1


def test_profile_roundtrip_in_memory_storage() -> None:
    payload = {
        "display_name": "Тестовый пользователь",
        "birth_date": "1986-04-13",
        "latin_name": "ALEX MORGAN",
        "city": "Киев",
        "country_code": "UA",
        "about": "Ищу настоящую мужскую дружбу и надёжных товарищей.",
        "friendship_goals": ["Близкий друг"],
        "interests": ["Футбол", "Бизнес"],
        "values": ["Верность", "Честность"],
        "lifestyle": ["Активный отдых"],
        "boundaries": {"privacy": "high"},
        "visibility": "discoverable",
        "completed_profile_sections": 10,
        "locale": "ru"
    }
    saved = client.put("/v1/profiles/1", json=payload)
    assert saved.status_code == 200
    assert saved.json()["global_id_display"] == "0000000001"
    read = client.get("/v1/profiles/1")
    assert read.status_code == 200
    assert read.json()["interests"] == ["Футбол", "Бизнес"]


def test_storage_health_defaults_to_memory_without_database() -> None:
    response = client.get("/health/storage")
    assert response.status_code == 200
    assert response.json()["mode"] in {"memory", "postgres"}


def test_personality_profile_roundtrip_in_memory_storage() -> None:
    payload = {
        "brotherhood32_code": "EVHFA",
        "brotherhood32_scores": {
            "title": "Adaptive Mentor",
            "social_energy": 72,
            "perception": 67,
            "decision_style": 81,
            "life_rhythm": 64,
            "bond_style": 58,
        },
        "enneagram_type": 8,
        "enneagram_wing": 7,
        "zodiac_sign": "ARIES",
        "vedic_numerology": {
            "soul_number": 4,
            "destiny_number": 5,
            "name_number": 8,
            "maturity_number": 9,
            "compatibility_vector": [4, 5, 9],
        },
        "model_version": "0.5.12",
    }
    saved = client.put("/v1/personality-profile/1", json=payload)
    assert saved.status_code == 200
    assert saved.json()["global_id_display"] == "0000000001"
    assert saved.json()["brotherhood32_code"] == "EVHFA"

    read = client.get("/v1/personality-profile/1")
    assert read.status_code == 200
    assert read.json()["vedic_numerology"]["soul_number"] == 4



def test_profile_avatar_upload_is_bounded_and_hash_verified() -> None:
    data = b"\xff\xd8\xff" + b"brotherhood-avatar-test"
    payload = {
        "content_type": "image/jpeg",
        "data_base64": base64.b64encode(data).decode("ascii"),
        "sha256": hashlib.sha256(data).hexdigest(),
    }
    response = client.put("/v1/profiles/1/avatar", json=payload, headers=_auth_headers())
    assert response.status_code == 200
    assert response.json()["byte_size"] == len(data)
    assert response.json()["sha256"] == payload["sha256"]

    bad = dict(payload, sha256="0" * 64)
    rejected = client.put("/v1/profiles/1/avatar", json=bad, headers=_auth_headers())
    assert rejected.status_code == 400

def test_session_issue_creates_owner_bound_bearer_token_in_memory() -> None:
    response = client.post("/internal/sessions/issue", json={"global_id": 1, "provider": "telegram"})
    assert response.status_code == 200
    body = response.json()
    assert body["global_id_display"] == "0000000001"
    assert body["token_type"] == "bearer"
    assert len(body["access_token"]) >= 32

    profile = client.get("/v1/profiles/1", headers={"Authorization": f"Bearer {body['access_token']}"})
    # Memory mode intentionally does not require auth, but issued tokens still resolve correctly.
    assert profile.status_code in {200, 404}


def _auth_headers() -> dict[str, str]:
    return {"Authorization": "Bearer debug-local-session"}


def test_chat_device_key_and_direct_e2ee_never_send_plaintext() -> None:
    key_payload = {
        "device_id": "android-device-0001",
        "identity_public_key_b64": "QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo=" * 2,
        "prekey_id": "prekey-0001",
        "prekey_public_key_b64": "QkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWjA=" * 2,
        "prekey_signature_b64": "U0lHTkFUVVJFREFUQQ==" * 2,
    }
    saved = client.put("/v1/e2ee/device-key", json=key_payload, headers=_auth_headers())
    assert saved.status_code == 200
    assert saved.json()["global_id_display"] == "0000000001"

    conversation = client.post("/v1/conversations/direct", json={"peer_global_id": 2}, headers=_auth_headers())
    assert conversation.status_code == 201
    assert conversation.json()["encryption_mode"] == "e2ee"
    cid = conversation.json()["id"]

    sent = client.post(f"/v1/conversations/{cid}/messages", headers=_auth_headers(), json={
        "client_message_id": "e2ee-local-message-0001",
        "message_type": "text",
        "encryption_mode": "e2ee",
        "body": None,
        "ciphertext_b64": "Y2lwaGVydGV4dA==",
        "nonce_b64": "bm9uY2UxMjM0NTY=",
        "key_id": "session-1",
        "ratchet_counter": 0,
        "sender_ephemeral_public_key_b64": "RVBITUJFUkFMUFVCS0VZ",
        "recipient_prekey_id": "peer-prekey",
        "attachments": [],
        "created_at_epoch_ms": 1785450000000,
    })
    assert sent.status_code == 201
    assert sent.json()["body"] is None
    assert sent.json()["ciphertext_b64"] == "Y2lwaGVydGV4dA=="

    history = client.get(f"/v1/conversations/{cid}/messages", headers=_auth_headers())
    assert history.status_code == 200
    assert history.json()[0]["body"] is None


def test_group_chat_supports_text_and_media_attachment() -> None:
    group = client.post("/v1/conversations/group", headers=_auth_headers(), json={
        "title": "Футбол Киев", "member_global_ids": [2, 3]
    })
    assert group.status_code == 201
    assert group.json()["encryption_mode"] == "server"
    cid = group.json()["id"]
    sent = client.post(f"/v1/conversations/{cid}/messages", headers=_auth_headers(), json={
        "client_message_id": "group-local-message-0001",
        "message_type": "media",
        "encryption_mode": "server",
        "body": "Фото с матча",
        "attachments": [{
            "client_attachment_id": "attachment-local-001",
            "kind": "image",
            "mime_type": "image/jpeg",
            "file_name": "match.jpg",
            "byte_size": 5,
            "data_b64": "aGVsbG8=",
        }],
        "created_at_epoch_ms": 1785450000001,
    })
    assert sent.status_code == 201
    assert sent.json()["body"] == "Фото с матча"
    assert sent.json()["attachments"][0]["kind"] == "image"
    attachment_id = sent.json()["attachments"][0]["id"]
    payload = client.get(f"/v1/chat/attachments/{attachment_id}", headers=_auth_headers())
    assert payload.status_code == 200
    assert payload.json()["data_b64"] == "aGVsbG8="


def test_app_version_manifest_is_available() -> None:
    response = client.get("/v1/app/version")
    assert response.status_code == 200
    assert response.json()["version_code"] == 38
    assert response.json()["version_name"] == "0.5.33"


def test_chat_reply_reaction_typing_edit_and_delete_flow() -> None:
    group = client.post("/v1/conversations/group", headers=_auth_headers(), json={
        "title": "Chat interaction test", "member_global_ids": [2]
    })
    assert group.status_code == 201
    cid = group.json()["id"]

    first = client.post(f"/v1/conversations/{cid}/messages", headers=_auth_headers(), json={
        "client_message_id": "interaction-message-0001",
        "message_type": "text",
        "encryption_mode": "server",
        "body": "Первоначальный текст",
        "attachments": [],
        "created_at_epoch_ms": 1785451000000,
    })
    assert first.status_code == 201
    first_id = first.json()["id"]

    reply = client.post(f"/v1/conversations/{cid}/messages", headers=_auth_headers(), json={
        "client_message_id": "interaction-message-0002",
        "message_type": "text",
        "encryption_mode": "server",
        "body": "Ответ",
        "reply_to_message_id": first_id,
        "attachments": [],
        "created_at_epoch_ms": 1785451000100,
    })
    assert reply.status_code == 201
    assert reply.json()["reply_to_message_id"] == first_id

    reaction = client.put(f"/v1/messages/{first_id}/reaction", headers=_auth_headers(), json={"emoji": "🤝"})
    assert reaction.status_code == 200
    assert reaction.json()[0]["emoji"] == "🤝"

    edit = client.put(f"/v1/messages/{first_id}", headers=_auth_headers(), json={
        "encryption_mode": "server",
        "body": "Исправленный текст",
        "edited_at_epoch_ms": 1785451000200,
    })
    assert edit.status_code == 200
    assert edit.json()["message_type"] == "edit"
    assert edit.json()["reply_to_message_id"] == first_id
    assert edit.json()["body"] == "Исправленный текст"

    session2 = client.post("/internal/sessions/issue", json={"global_id": 2, "provider": "telegram"})
    assert session2.status_code == 200
    headers2 = {"Authorization": f"Bearer {session2.json()['access_token']}"}
    typing = client.put(f"/v1/conversations/{cid}/typing", headers=headers2, json={"typing": True})
    assert typing.status_code == 200
    status = client.get(f"/v1/conversations/{cid}/typing", headers=_auth_headers())
    assert status.status_code == 200
    assert 2 in status.json()["global_ids"]

    deleted = client.delete(f"/v1/messages/{first_id}", headers=_auth_headers())
    assert deleted.status_code == 204
    history = client.get(f"/v1/conversations/{cid}/messages", headers=_auth_headers())
    assert history.status_code == 200
    tombstone = next(item for item in history.json() if item["id"] == first_id)
    assert tombstone["status"] == "deleted"
    assert tombstone["body"] is None


def test_direct_chat_block_and_report_safety_flow() -> None:
    conversation = client.post("/v1/conversations/direct", json={"peer_global_id": 2}, headers=_auth_headers())
    assert conversation.status_code == 201

    report = client.post("/v1/chat/report/2", headers=_auth_headers(), json={
        "category": "chat_abuse",
        "description": "Пользователь неоднократно нарушал границы общения в личном чате.",
        "evidence_refs": ["chat-message-reference-1"],
    })
    assert report.status_code == 201
    assert report.json()["subject_global_id"] == 2
    assert report.json()["status"] == "pending"

    blocked = client.put("/v1/users/2/block", headers=_auth_headers(), json={"blocked": True})
    assert blocked.status_code == 200
    assert blocked.json() == {"subject_global_id": 2, "blocked": True}

    status = client.get("/v1/users/2/block", headers=_auth_headers())
    assert status.status_code == 200
    assert status.json()["blocked"] is True

    refused = client.post("/v1/conversations/direct", json={"peer_global_id": 2}, headers=_auth_headers())
    assert refused.status_code == 400

    unblocked = client.put("/v1/users/2/block", headers=_auth_headers(), json={"blocked": False})
    assert unblocked.status_code == 200
    assert unblocked.json()["blocked"] is False


def test_push_token_registration_hook_is_available_in_memory() -> None:
    response = client.put("/v1/push/token", headers=_auth_headers(), json={
        "device_id": "android-device-0001",
        "provider": "fcm",
        "token": "fcm-test-token-00000000000000000001",
    })
    assert response.status_code == 200
    assert response.json() == {"ok": True}


def test_group_owner_can_manage_members() -> None:
    group = client.post("/v1/conversations/group", headers=_auth_headers(), json={
        "title": "Managed group", "member_global_ids": [2]
    })
    assert group.status_code == 201
    cid = group.json()["id"]

    listed = client.get(f"/v1/conversations/{cid}/members", headers=_auth_headers())
    assert listed.status_code == 200
    assert {item["global_id"] for item in listed.json()} == {1, 2}

    added = client.put(f"/v1/conversations/{cid}/members/3", headers=_auth_headers())
    assert added.status_code == 200
    assert {item["global_id"] for item in added.json()} == {1, 2, 3}

    removed = client.delete(f"/v1/conversations/{cid}/members/2", headers=_auth_headers())
    assert removed.status_code == 200
    assert {item["global_id"] for item in removed.json()} == {1, 3}


def test_friendship_outcomes_are_internal_and_canonicalize_pair_order(monkeypatch) -> None:
    monkeypatch.setenv("INTERNAL_AUTH_SECRET", "test-internal-secret")
    payload = {
        "connection_id": "connection-0001",
        "first_global_id": 3,
        "second_global_id": 1,
        "matched_at": "2026-07-01T12:00:00Z",
        "layer_scores": {"tests": 82, "values": 91, "communication": 74},
        "searcher_global_id": 3,
        "search_role": "director",
        "desired_qualities": {"demanding": 5, "disciplined": 4},
        "quality_fit_score": 92,
        "quality_fit_confidence": 81,
        "quality_model_version": "quality-fit-catalog-v2",
        "still_active_30d": True,
        "still_active_90d": None,
        "ended_reason": None,
        "messages_exchanged_30d": 143,
    }
    # Memory mode is explicitly a local/test runtime and bypasses the internal secret.
    # PostgreSQL mode requires X-Internal-Auth via require_internal_secret().
    headers = {"X-Internal-Auth": "test-internal-secret"}
    saved = client.put("/internal/friendship-outcomes", json=payload, headers=headers)
    assert saved.status_code == 200
    assert saved.json()["first_global_id"] == 1
    assert saved.json()["second_global_id"] == 3
    exported = client.get("/internal/friendship-outcomes", headers=headers)
    assert exported.status_code == 200
    row = exported.json()[0]
    assert row["layer_scores"]["communication"] == 74
    assert row["searcher_global_id"] == 3
    assert row["search_role"] == "director"
    assert row["desired_qualities"] == {"demanding": 5, "disciplined": 4}
    assert row["quality_fit_score"] == 92
    assert row["quality_model_version"] == "quality-fit-catalog-v2"


def test_friendship_outcome_rejects_searcher_outside_pair(monkeypatch) -> None:
    monkeypatch.setenv("INTERNAL_AUTH_SECRET", "test-internal-secret")
    response = client.put("/internal/friendship-outcomes", headers={"X-Internal-Auth": "test-internal-secret"}, json={
        "connection_id": "connection-searcher-outside",
        "first_global_id": 1,
        "second_global_id": 2,
        "searcher_global_id": 3,
        "search_role": "friend",
        "matched_at": "2026-07-01T12:00:00Z",
        "layer_scores": {"tests": 50},
    })
    assert response.status_code == 400
    assert "connection pair" in response.json()["detail"]


def test_friendship_outcome_rejects_self_pair(monkeypatch) -> None:
    monkeypatch.setenv("INTERNAL_AUTH_SECRET", "test-internal-secret")
    response = client.put("/internal/friendship-outcomes", headers={"X-Internal-Auth": "test-internal-secret"}, json={
        "connection_id": "connection-self",
        "first_global_id": 2,
        "second_global_id": 2,
        "matched_at": "2026-07-01T12:00:00Z",
        "layer_scores": {"tests": 50},
    })
    assert response.status_code == 400


def test_localized_city_options_preserve_canonical_search_value() -> None:
    uk = client.get("/v1/city-options", params={"locale": "uk"})
    en = client.get("/v1/city-options", params={"locale": "en"})
    assert uk.status_code == 200
    assert en.status_code == 200
    uk_kyiv = next(item for item in uk.json() if item["id"] == "kyiv")
    en_kyiv = next(item for item in en.json() if item["id"] == "kyiv")
    assert uk_kyiv == {"id": "kyiv", "value": "Киев", "label": "Київ"}
    assert en_kyiv == {"id": "kyiv", "value": "Киев", "label": "Kyiv"}
    # Stable value continues to work with the existing people search contract.
    response = client.get("/v1/people", params={"city": en_kyiv["value"], "radius_km": 10, "locale": "en"})
    assert response.status_code == 200
    assert response.json()[0]["global_id_display"] == "0000000002"


def _complete_secure_test_app(app_id: str = "big_five", global_id: int = 1, offset: int = 0):
    headers = {"Authorization": "Bearer debug-local-session"}
    started = client.post(
        f"/v1/test-apps/{app_id}/sessions",
        headers=headers,
        json={"global_id": global_id, "instrument_locale": "ru"},
    )
    assert started.status_code == 200, started.text
    session = started.json()
    while session["status"] == "IN_PROGRESS":
        current = session["current_item"]
        answer = 1 + ((session["position"] - 1 + offset) % 4)
        response = client.post(
            f"/v1/test-app-sessions/{session['session_id']}/answers",
            headers=headers,
            json={
                "item_token": current["item_token"],
                "answer": answer,
                "response_latency_ms": 900 + session["position"],
                "selection_changes": 0,
            },
        )
        assert response.status_code == 200, response.text
        session = response.json()
    return session


def test_scientific_questionnaire_catalog_has_seven_systems_and_197_items() -> None:
    catalog = client.get("/v1/scientific-assessments")
    assert catalog.status_code == 200
    rows = catalog.json()
    assert len(rows) == 7
    assert sum(row["item_count"] for row in rows) == 197
    assert {row["scoring_version"] for row in rows} == {"scientific-questionnaire-v1"}
    assert {row["instrument_version"] for row in rows} == {"text-situational-neutral-v1"}


def test_scientific_assessment_is_server_scored_persisted_and_public_safe() -> None:
    completed = _complete_secure_test_app("big_five")
    assert completed["status"] == "COMPLETED"
    assert completed["result_id"]
    listed = client.get("/v1/assessment-results/1")
    assert listed.status_code == 200
    assert [row["assessment_id"] for row in listed.json()] == ["big_five"]
    # Public receipts do not expose item answers or hidden construct dimensions.
    assert "dimensions" not in listed.json()[0]
    stored = ASSESSMENT_RESULTS[(1, "big_five")]
    assert stored.scoring_version == "scientific-questionnaire-v1"
    assert stored.response_trace == []
    assert stored.dimensions


def test_removed_legacy_visual_assessment_cannot_be_written() -> None:
    response = client.put("/v1/assessment-results", json={
        "global_id": 1, "assessment_id": "f001", "scoring_version": "legacy-model",
        "stimulus_version": "legacy-instrument", "instrument_locale": "ru",
        "started_at_epoch_ms": 1785449990000, "total_score": 50, "risk_score": 0,
        "answer_consistency": 80, "idealized_self_presentation": 0,
        "label": "legacy", "summary": "This removed legacy assessment must not be active.",
        "dimensions": [{"id": "legacy", "title": "legacy", "score": 50}],
        "response_trace": [], "completed_at_epoch_ms": 1785450000000,
    })
    assert response.status_code == 410


def test_account_rating_is_fifty_fifty_for_seven_scientific_systems() -> None:
    systems = [row["system_id"] for row in client.get("/v1/scientific-assessments").json()]
    response = client.post("/v1/account-rating", json={
        "completed_profile_section_codes": [
            "identity", "photo", "city", "about", "friendship_goals",
            "interests", "boundaries", "communication", "availability", "verification"
        ],
        "completed_test_ids": systems,
    })
    assert response.status_code == 200
    assert response.json()["profile_points"] == 50.0
    assert response.json()["test_points"] == 50.0
    assert response.json()["completed_tests"] == 7
    assert response.json()["total"] == 100.0


def test_duplicate_and_unknown_scientific_tests_do_not_increase_rating() -> None:
    response = client.post("/v1/account-rating", json={
        "completed_profile_section_codes": ["identity", "city", "identity", "unknown"],
        "completed_test_ids": ["traits_core", "traits_core", "unknown"],
    })
    assert response.status_code == 200
    assert response.json()["completed_tests"] == 1
    assert 7.0 < response.json()["test_points"] < 7.2


def test_scientific_compatibility_uses_independent_system_scores() -> None:
    response = client.post("/v1/compatibility", json={
        "my_scores": {"traits_core": 90, "communication_conflict": 90},
        "candidate_scores": {"traits_core": 20, "communication_conflict": 25},
        "shared_interest_percent": 100,
        "trust_score": 100,
    })
    assert response.status_code == 200
    body = response.json()
    assert body["common_tests"] == 2
    assert 0 <= body["tests_score"] <= 100
    assert "risk_flags" not in body


def test_public_config_exposes_scientific_questionnaire_product_model() -> None:
    response = client.get("/v1/config")
    assert response.status_code == 200
    body = response.json()
    assert body["personality_model"]["type_count"] == 32
    assert body["tests"]["count"] == 7
    assert body["tests"]["task_count"] == 197
    assert body["tests"]["question_count"] == 197
    assert body["tests"]["scoring_version"] == "scientific-questionnaire-v1"
    assert body["quality_matching"]["assessment_model"] == "scientific-questionnaire-v1"


def test_q28_returns_seven_independent_psychological_systems() -> None:
    saved = client.put("/v1/compatibility/preferences", json={
        "global_id": 1, "selected_metrics": ["PC", "NU", "IC"],
    })
    assert saved.status_code == 200
    response = client.post("/v1/compatibility/independent", json={
        "requester_global_id": 1, "candidate_global_id": 2, "selected_metrics": ["PC", "IC", "NU"],
    })
    assert response.status_code == 200
    body = response.json()
    assert [row["id"] for row in body["metrics"]] == ["PC", "IC", "VC", "CC", "LC", "PT", "EN", "NU", "AS"]
    assert len(body["psychological_modules"]) == 7
    assert {row["module_id"] for row in body["psychological_modules"]} == {
        "traits_core", "interpersonal_style", "communication_conflict", "trust_support_boundaries",
        "decision_work_style", "social_group_role", "adaptability_uncertainty"
    }
