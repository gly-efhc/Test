from __future__ import annotations

import base64
import os
from datetime import datetime, timedelta, timezone
from uuid import UUID

from fastapi.testclient import TestClient

from app.hospitality import _MEMORY_REQUESTS, reset_memory_hospitality
from app.main import app
from app.storage import (
    APPEALS,
    ASSESSMENT_RESULTS,
    CHAT_CONVERSATIONS,
    CHAT_MESSAGES,
    INCIDENTS,
    MODERATION_DECISIONS,
    PROFILES,
    USER_BLOCKS,
    VERIFIED_INTERACTIONS,
)

client = TestClient(app)
TEST_KEY = base64.b64encode(b"hospitality-cycle-0021-key-12345"[:32]).decode("ascii")
CITY_ID = "11111111-1111-1111-1111-111111111111"


def setup_function() -> None:
    os.environ["BROTHERHOOD_STORAGE_MODE"] = "memory"
    os.environ["HOSPITALITY_ENABLED"] = "true"
    os.environ["HOSPITALITY_PRIVATE_KEY_ACTIVE_VERSION"] = "1"
    os.environ["HOSPITALITY_PRIVATE_KEY_V1_B64"] = TEST_KEY
    os.environ["HOSPITALITY_PENDING_TTL_HOURS"] = "48"
    os.environ["HOSPITALITY_REVIEW_WINDOW_DAYS"] = "7"
    reset_memory_hospitality()
    ASSESSMENT_RESULTS.clear(); PROFILES.clear(); CHAT_CONVERSATIONS.clear(); CHAT_MESSAGES.clear(); USER_BLOCKS.clear()
    INCIDENTS.clear(); MODERATION_DECISIONS.clear(); APPEALS.clear()


def _headers(global_id: int) -> dict[str, str]:
    if global_id == 1:
        return {"Authorization": "Bearer debug-local-session"}
    response = client.post("/internal/sessions/issue", json={"global_id": global_id, "provider": "telegram"})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def _host() -> None:
    response = client.put("/v1/hospitality/profile", headers=_headers(1), json={
        "is_hosting_active": True,
        "max_guests": 2,
        "max_days": 7,
        "city_id": CITY_ID,
        "public_area_text": "Central district",
        "timezone_name": "Europe/Kyiv",
        "sleeping_condition": "private_room",
        "house_rules": ["Respect quiet hours"],
        "min_required_rating": 0,
        "required_completed_tests": [],
        "availability_mode": "always",
        "private_location": {
            "exact_address": "Private Test Street 10",
            "arrival_instructions": "Call on arrival",
            "exact_lat": 50.4501,
            "exact_lon": 30.5234,
            "arrival_contact": "@private-host",
        },
    })
    assert response.status_code == 200, response.text


def _complete_request(guest_id: int = 2, key: str = "cycle0021-request-0001") -> dict:
    _host()
    created = client.post(
        "/v1/hospitality/requests",
        headers={**_headers(guest_id), "Idempotency-Key": key},
        json={"host_global_id": 1, "check_in_date": "2026-09-10", "check_out_date": "2026-09-13", "guests_count": 1},
    )
    assert created.status_code == 201, created.text
    item = created.json()
    accepted = client.patch(
        f"/v1/hospitality/requests/{item['request_id']}/status",
        headers=_headers(1), json={"action": "accept", "expected_version": item["version"]},
    )
    assert accepted.status_code == 200, accepted.text
    row = _MEMORY_REQUESTS[UUID(item["request_id"])]
    row.private_access_expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)
    tick = client.post("/internal/hospitality/tick")
    assert tick.status_code == 200
    assert _MEMORY_REQUESTS[UUID(item["request_id"])].status == "completed"
    return client.get(f"/v1/hospitality/requests/{item['request_id']}", headers=_headers(guest_id)).json()


def test_bilateral_confirmation_creates_exactly_one_verified_hospitality_interaction() -> None:
    request = _complete_request()
    rid = request["request_id"]
    before_host = VERIFIED_INTERACTIONS.get(1, 0)
    before_guest = VERIFIED_INTERACTIONS.get(2, 0)

    first = client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(1), json={"confirmation": "stay_occurred"})
    assert first.status_code == 200
    assert first.json()["verified"] is False
    second = client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(2), json={"confirmation": "stay_occurred"})
    assert second.status_code == 200
    assert second.json()["verified"] is True
    interaction_id = second.json()["interaction_id"]

    replay = client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(2), json={"confirmation": "stay_occurred"})
    assert replay.status_code == 200
    assert replay.json()["interaction_id"] == interaction_id
    assert VERIFIED_INTERACTIONS[1] == before_host + 1
    assert VERIFIED_INTERACTIONS[2] == before_guest + 1


def test_no_show_or_dispute_blocks_auto_verified_stay() -> None:
    request = _complete_request(key="cycle0021-request-0002")
    rid = request["request_id"]
    assert client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(1), json={"confirmation": "stay_occurred"}).status_code == 200
    result = client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(2), json={"confirmation": "no_show"})
    assert result.status_code == 200
    assert result.json()["verified"] is False
    assert result.json()["blocked_by"] == "no_show"


def test_blind_reviews_hide_first_submission_then_publish_both_without_private_feedback() -> None:
    request = _complete_request(key="cycle0021-request-0003")
    rid = request["request_id"]
    first = client.post(f"/v1/hospitality/requests/{rid}/reviews", headers=_headers(1), json={
        "adequacy": 5, "rules_compliance": 4, "description_accuracy": 5,
        "review_text": "Good guest", "private_feedback": "moderation-only note",
    })
    assert first.status_code == 200
    assert first.json()["published_at"] is None
    public_before = client.get("/v1/users/2/hospitality-reviews")
    assert public_before.status_code == 200 and public_before.json() == []
    peer_state = client.get(f"/v1/hospitality/requests/{rid}/review-state", headers=_headers(2)).json()
    assert peer_state["own_submitted"] is False
    assert peer_state["published_review_count"] == 0

    second = client.post(f"/v1/hospitality/requests/{rid}/reviews", headers=_headers(2), json={
        "adequacy": 5, "rules_compliance": 5, "description_accuracy": 5,
        "review_text": "Accurate host description", "private_feedback": "private host feedback",
    })
    assert second.status_code == 200 and second.json()["published_at"] is not None
    host_reviews = client.get("/v1/users/1/hospitality-reviews").json()
    guest_reviews = client.get("/v1/users/2/hospitality-reviews").json()
    assert len(host_reviews) == 1 and len(guest_reviews) == 1
    assert "private_feedback" not in host_reviews[0]
    assert "private_feedback" not in guest_reviews[0]
    assert "moderation-only note" not in str(guest_reviews)


def test_single_review_publishes_only_after_deadline_tick() -> None:
    request = _complete_request(key="cycle0021-request-0004")
    rid = request["request_id"]
    saved = client.post(f"/v1/hospitality/requests/{rid}/reviews", headers=_headers(1), json={
        "adequacy": 4, "rules_compliance": 4, "description_accuracy": 4, "review_text": "Solid visit"
    })
    assert saved.status_code == 200 and saved.json()["published_at"] is None
    _MEMORY_REQUESTS[UUID(rid)].review_deadline_at = datetime.now(timezone.utc) - timedelta(seconds=1)
    tick = client.post("/internal/hospitality/tick")
    assert tick.status_code == 200 and tick.json()["reviews_published"] == 1
    public = client.get("/v1/users/2/hospitality-reviews").json()
    assert len(public) == 1


def test_hospitality_reputation_is_separate_and_counts_verified_stay_and_published_review() -> None:
    request = _complete_request(key="cycle0021-request-0005")
    rid = request["request_id"]
    client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(1), json={"confirmation": "stay_occurred"})
    client.post(f"/v1/hospitality/requests/{rid}/confirmation", headers=_headers(2), json={"confirmation": "stay_occurred"})
    client.post(f"/v1/hospitality/requests/{rid}/reviews", headers=_headers(1), json={"adequacy": 5,"rules_compliance": 5,"description_accuracy": 5})
    client.post(f"/v1/hospitality/requests/{rid}/reviews", headers=_headers(2), json={"adequacy": 4,"rules_compliance": 4,"description_accuracy": 4})
    host = client.get("/v1/hospitality/reputation/1").json()
    guest = client.get("/v1/hospitality/reputation/2").json()
    assert host["verified_stays_as_host"] == 1 and host["published_reviews"] == 1
    assert guest["verified_stays_as_guest"] == 1 and guest["published_reviews"] == 1
    assert "compatibility" not in host and "account_rating" not in host


def test_hospitality_incident_restriction_requires_confirmed_moderation_and_subject_can_appeal() -> None:
    request = _complete_request(key="cycle0021-request-0006")
    rid = request["request_id"]
    incident = client.post(f"/v1/hospitality/requests/{rid}/incident", headers=_headers(1), json={
        "reason_code": "NO_SHOW", "description": "Guest did not arrive and the host is asking for a moderation review.", "evidence_refs": []
    })
    assert incident.status_code == 201
    iid = incident.json()["id"]
    before = client.get("/v1/hospitality/reputation/2").json()
    assert before["active_restriction"] is False

    decision = client.post(f"/internal/trust/incidents/{iid}/decision", json={
        "moderator_global_id": 3, "confirmed": True, "rationale": "Evidence reviewed and incident confirmed.",
        "hospitality_restriction_scope": "guest", "hospitality_restriction_reason_code": "CONFIRMED_NO_SHOW"
    })
    assert decision.status_code == 200, decision.text
    assert decision.json()["hospitality_restriction"]["global_id"] == 2
    after = client.get("/v1/hospitality/reputation/2").json()
    assert after["active_restriction"] is True

    appeal = client.post(f"/v1/trust/incidents/{iid}/appeals", headers=_headers(2), json={
        "grounds": "I dispute the moderation conclusion and request review of the submitted evidence."
    })
    assert appeal.status_code == 201
    assert appeal.json()["status"] == "pending"


def test_structured_conversation_events_are_participant_only_and_never_include_private_location() -> None:
    request = _complete_request(key="cycle0021-request-0007")
    cid = request["conversation_id"]
    participant = client.get(f"/v1/hospitality/conversations/{cid}/events", headers=_headers(2))
    assert participant.status_code == 200
    assert any(row["event_type"] == "request_created" for row in participant.json())
    assert "exact_address" not in participant.text
    assert "arrival_contact" not in participant.text
    outsider = client.get(f"/v1/hospitality/conversations/{cid}/events", headers=_headers(3))
    assert outsider.status_code == 403


def test_host_profile_can_resolve_existing_city_value_to_canonical_city_id() -> None:
    payload = {
        "is_hosting_active": False,
        "max_guests": 1,
        "max_days": 3,
        "city_value": "Киев",
        "public_area_text": "Central district",
        "timezone_name": "Europe/Kyiv",
        "sleeping_condition": "sofa",
        "house_rules": [],
        "min_required_rating": 0,
        "required_completed_tests": [],
        "availability_mode": "always",
        "private_location": {"exact_address": "Private value-resolved address"},
    }
    response = client.put("/v1/hospitality/profile", headers=_headers(1), json=payload)
    assert response.status_code == 200, response.text
    assert UUID(response.json()["city_id"])
