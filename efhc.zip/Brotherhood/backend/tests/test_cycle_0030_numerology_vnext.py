from datetime import date, datetime, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from app.main import app
from app.models import NumerologyReadingCreate, PersonalityProfileUpsert
from app.numerology_vnext import build_reading, compatibility_components, public_spec
from app.independent_compatibility import _numerology_score
from app.storage import NUMEROLOGY_COMPARISONS, NUMEROLOGY_READINGS, PERSONALITY_PROFILES

client = TestClient(app)


def setup_function() -> None:
    NUMEROLOGY_READINGS.clear()
    NUMEROLOGY_COMPARISONS.clear()
    PERSONALITY_PROFILES.clear()


def test_deterministic_reference_vector_1990_02_14() -> None:
    row = build_reading(
        NumerologyReadingCreate(global_id=1, birth_date=date(1990, 2, 14), latin_name="MARK TEST", locale="ru"),
        created_at=datetime(2026, 8, 13, tzinfo=timezone.utc),
    )
    assert (row.life_path_number, row.date_soul_number, row.date_destiny_number, row.date_maturity_number) == (8, 5, 8, 4)
    assert (row.name_soul_number, row.expression_number) == (6, 2)
    assert [(x.index, x.number, x.reached_at_age) for x in row.pinnacles] == [
        (1, 7, 28), (2, 6, 37), (3, 4, 46), (4, 3, 55),
    ]
    assert [x.key for x in row.birth_chart] == ["11", "2", "4", "99"]
    assert row.missing_birth_chart_digits == [3, 5, 6, 7, 8]
    assert [x.key for x in row.special_birth_chart_signals] == ["9CL", "Not7"]


def test_spec_has_independent_nu_and_no_hidden_cross_metric_weight() -> None:
    spec = public_spec()
    assert spec.compatibility_components == {"soul": 0.40, "destiny": 0.35, "cross": 0.15, "date_composite": 0.10}
    assert "Name-derived" in spec.compatibility_input_policy
    assert "independent optional metric" in spec.disclosure


def test_pair_component_formula_is_deterministic() -> None:
    total, components = compatibility_components(5, 8, 6, 6)
    assert total == 85
    assert sum(row.internal_weight for row in components) == 1.0
    assert [row.component_id for row in components] == ["soul", "destiny", "cross", "date_composite"]


def test_api_reading_is_idempotent_and_history_is_re_readable() -> None:
    payload = {"global_id": 1, "birth_date": "1990-02-14", "latin_name": "MARK TEST", "locale": "ru"}
    first = client.post("/v1/numerology/readings", json=payload)
    second = client.post("/v1/numerology/readings", json=payload)
    assert first.status_code == 200 == second.status_code
    assert first.json()["reading_id"] == second.json()["reading_id"]
    history = client.get("/v1/numerology/readings/1")
    assert history.status_code == 200
    assert len(history.json()) == 1
    latest = client.get("/v1/numerology/readings/1/latest")
    assert latest.status_code == 200
    assert latest.json()["reading_id"] == first.json()["reading_id"]
    detail = client.get(f"/v1/numerology/readings/1/{first.json()['reading_id']}")
    assert detail.status_code == 200
    assert detail.json()["life_path_number"] == 8
    assert len(detail.json()["life_path_sections"]) == 5


def test_api_pair_compatibility_uses_date_numbers_and_persists_history() -> None:
    for gid, birth in [(1, "1990-02-14"), (2, "1988-06-24")]:
        response = client.post("/v1/numerology/readings", json={"global_id": gid, "birth_date": birth, "locale": "ru"})
        assert response.status_code == 200
    result = client.post("/v1/numerology/compatibility", json={"first_global_id": 1, "second_global_id": 2})
    assert result.status_code == 200
    body = result.json()
    assert 0 <= body["score"] <= 100
    assert len(body["components"]) == 4
    assert body["evidence_origin"].startswith("birth-date-derived")
    history = client.get("/v1/numerology/compatibility/1/history")
    assert history.status_code == 200
    assert history.json()[0]["comparison_id"] == body["comparison_id"]


def test_name_change_does_not_change_date_compatibility_inputs() -> None:
    a = build_reading(NumerologyReadingCreate(global_id=1, birth_date=date(1990,2,14), latin_name="ALPHA", locale="ru"), created_at=datetime.now(timezone.utc))
    b = build_reading(NumerologyReadingCreate(global_id=1, birth_date=date(1990,2,14), latin_name="OMEGA DIFFERENT", locale="ru"), created_at=datetime.now(timezone.utc))
    assert (a.date_soul_number, a.date_destiny_number) == (b.date_soul_number, b.date_destiny_number)
    assert a.input_snapshot_hash != b.input_snapshot_hash


def test_vnext_nu_total_matches_existing_q28_runtime_formula() -> None:
    total, _ = compatibility_components(5, 8, 6, 6)
    first = SimpleNamespace(vedic_numerology={"soul_number": 5, "destiny_number": 8})
    second = SimpleNamespace(vedic_numerology={"soul_number": 6, "destiny_number": 6})
    assert total == _numerology_score(first, second)


def test_v3_expands_trace_calendar_and_complete_digit_inventory_without_new_nu_formula() -> None:
    row = build_reading(
        NumerologyReadingCreate(global_id=1, birth_date=date(1990, 2, 14), latin_name="MARK TEST", locale="ru"),
        created_at=datetime(2026, 8, 13, tzinfo=timezone.utc),
    )
    assert row.calculation_version == "numerology-reading-v3"
    assert len(row.birth_chart_inventory) == 9
    assert [x.digit for x in row.birth_chart_inventory] == list(range(1, 10))
    assert {x.digit for x in row.birth_chart_inventory if x.count == 0} == {3, 5, 6, 7, 8}
    assert all(x.key == "NONE" for x in row.birth_chart_inventory if x.count == 0)
    assert [x.reached_at_date.isoformat() for x in row.pinnacles] == [
        "2018-02-14", "2027-02-14", "2036-02-14", "2045-02-14",
    ]
    trace = {x.calculation_id: x for x in row.calculation_trace}
    assert trace["life_path"].reduction_steps == [26, 8]
    assert trace["date_soul"].reduction_steps == [14, 5]
    assert trace["date_destiny"].reduction_steps == [35, 8]
    assert trace["date_maturity"].reduction_steps == [13, 4]
    assert trace["pinnacle_3"].result == 4
    assert trace["name_soul"].result == 6
    assert trace["name_expression"].result == 2
    assert [(x.role_id, x.number, x.ruler) for x in row.date_number_details] == [
        ("soul", 5, "Mercury"), ("destiny", 8, "Saturn"), ("maturity", 4, "Rahu"),
    ]


def test_catalog_exposes_all_normalized_source_records_and_detail() -> None:
    index = client.get("/v1/numerology/catalog/ru")
    assert index.status_code == 200
    body = index.json()
    assert body["knowledge_version"] == "numerology-knowledge-v1"
    assert body["source_record_count"] == 97
    assert {x["group_id"] for x in body["groups"]} == {
        "life_paths", "soul_numbers", "outer_numbers", "birth_chart", "pyramid_peaks",
    }
    life = client.get("/v1/numerology/catalog/ru/life_paths/8")
    assert life.status_code == 200
    assert life.json()["title"] == "Жизненный путь 8"
    assert len(life.json()["sections"]) == 5
    missing = client.get("/v1/numerology/catalog/ru/birth_chart/NONE")
    assert missing.status_code == 200
    assert "отсутств" in missing.json()["title"].lower()
    assert client.get("/v1/numerology/catalog/ru/not_a_group/1").status_code == 404


def test_spec_reports_expanded_source_backed_data_surface() -> None:
    spec = public_spec()
    assert spec.calculation_version == "numerology-reading-v3"
    assert spec.source_record_count == 97
    assert spec.catalog_groups == ["life_paths", "soul_numbers", "outer_numbers", "birth_chart", "pyramid_peaks"]
    assert "calculation_trace" in spec.date_derived_fields
    assert "pinnacle_calendar_dates" in spec.date_derived_fields
    assert spec.compatibility_components == {"soul": 0.40, "destiny": 0.35, "cross": 0.15, "date_composite": 0.10}


def test_pair_history_freezes_date_number_inputs_and_relation_details() -> None:
    for gid, birth in [(1, "1990-02-14"), (2, "1988-06-24")]:
        assert client.post("/v1/numerology/readings", json={"global_id": gid, "birth_date": birth, "locale": "ru"}).status_code == 200
    result = client.post("/v1/numerology/compatibility", json={"first_global_id": 1, "second_global_id": 2})
    assert result.status_code == 200
    body = result.json()
    assert body["first_date_numbers"] == {"soul": 5, "destiny": 8}
    assert body["second_date_numbers"] == {"soul": 6, "destiny": 2}
    assert all(component["relations"] for component in body["components"])
    assert len(next(x for x in body["components"] if x["component_id"] == "cross")["relations"]) == 2
    assert {r["relation_code"] for c in body["components"] for r in c["relations"]} <= {"SAME", "FRIENDLY", "NEUTRAL", "CONTRASTING"}
