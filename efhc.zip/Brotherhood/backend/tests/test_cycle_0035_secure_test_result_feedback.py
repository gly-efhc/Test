from fastapi.testclient import TestClient

from app.main import app
from app.auth_security import issue_session
from app.models import AuthProvider
from app.storage import ASSESSMENT_ADMIN_SESSIONS, ASSESSMENT_RESULTS

client = TestClient(app)
AUTH = {"Authorization": "Bearer debug-local-session"}

BANNED_USER_COPY = (
    "Измерительный слой",
    "Что полезно наблюдать дальше",
    "Проверять, как",
    "scientific-questionnaire",
    "coverage",
    "model_version",
    "source_ids",
    "construct",
    "calibration",
)


def setup_function() -> None:
    ASSESSMENT_ADMIN_SESSIONS.clear()
    ASSESSMENT_RESULTS.clear()


def _complete(app_id: str, offset: int = 0) -> tuple[dict, dict]:
    session = client.post(
        f"/v1/test-apps/{app_id}/sessions",
        headers=AUTH,
        json={"global_id": 1, "instrument_locale": "ru"},
    ).json()
    while session["status"] == "IN_PROGRESS":
        item = session["current_item"]
        response = client.post(
            f"/v1/test-app-sessions/{session['session_id']}/answers",
            headers=AUTH,
            json={
                "item_token": item["item_token"],
                "answer": 1 + ((item["position"] + offset) % 4),
                "response_latency_ms": 900 + item["position"],
            },
        )
        assert response.status_code == 200, response.text
        session = response.json()
    feedback = client.get(
        f"/v1/test-app-results/1/{session['result_id']}/feedback", headers=AUTH
    )
    assert feedback.status_code == 200, feedback.text
    return session, feedback.json()


def test_feedback_is_human_readable_and_contains_no_internal_method_copy() -> None:
    _, feedback = _complete("curiosity_flexibility")
    assert feedback["title"] == "Гибкость и любознательность"
    assert feedback["headline"]
    assert len(feedback["lead"]) > 40
    assert len(feedback["expressed"]) >= 1
    assert len(feedback["balance"]) >= 1
    public_text = " ".join(
        [feedback["title"], feedback["headline"], feedback["lead"], *feedback["expressed"], *feedback["balance"], feedback["closing"]]
    )
    for banned in BANNED_USER_COPY:
        assert banned.lower() not in public_text.lower()


def test_all_twelve_product_tests_have_readable_feedback() -> None:
    catalog = client.get("/v1/test-apps").json()
    assert len(catalog) == 12
    for index, row in enumerate(catalog):
        _, feedback = _complete(row["app_id"], index)
        assert feedback["app_id"] == row["app_id"]
        assert feedback["title"] == row["title"]
        assert feedback["headline"]
        assert feedback["expressed"]
        assert feedback["balance"]
        assert "следующего прохождения" in feedback["closing"]


def test_feedback_is_owner_only_and_derived_from_immutable_saved_result() -> None:
    session, feedback = _complete("work_projects")
    other = issue_session(2, AuthProvider.EMAIL)
    forbidden = client.get(
        f"/v1/test-app-results/1/{session['result_id']}/feedback",
        headers={"Authorization": f"Bearer {other.access_token}"},
    )
    assert forbidden.status_code == 403
    missing = client.get("/v1/test-app-results/1/does-not-exist/feedback", headers=AUTH)
    assert missing.status_code == 404
    again = client.get(f"/v1/test-app-results/1/{session['result_id']}/feedback", headers=AUTH)
    assert again.status_code == 200
    assert again.json() == feedback
