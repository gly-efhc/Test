from fastapi.testclient import TestClient

from app.main import app
from app.storage import SEARCH_REQUESTS, COMMUNITY_MEMBERSHIPS

client = TestClient(app)
AUTH = {"Authorization": "Bearer debug-local-session"}


def setup_function() -> None:
    SEARCH_REQUESTS.clear()
    COMMUNITY_MEMBERSHIPS.discard(("c1", 1))


def test_search_request_crud_and_archive_are_owner_bound() -> None:
    payload = {
        "title": "Ищу партнёра для продукта",
        "role": "Партнёр по проекту",
        "desired_qualities": ["Надёжность", "Инициативность"],
        "city": "Киев",
        "radius_km": 50,
        "min_trust": 70,
        "min_compatibility": 65,
        "online_only": False,
        "verified_only": True,
        "hospitality_only": False,
        "notes": "B2B SaaS и исследовательские продукты",
    }
    created = client.post("/v1/search-requests", json=payload, headers=AUTH)
    assert created.status_code == 201
    body = created.json()
    assert body["owner_global_id"] == 1
    assert body["status"] == "active"
    request_id = body["request_id"]

    listed = client.get("/v1/search-requests", headers=AUTH)
    assert listed.status_code == 200
    assert [item["request_id"] for item in listed.json()] == [request_id]

    updated = client.put(
        f"/v1/search-requests/{request_id}",
        json={"min_trust": 80, "status": "paused"},
        headers=AUTH,
    )
    assert updated.status_code == 200
    assert updated.json()["min_trust"] == 80
    assert updated.json()["status"] == "paused"

    archived = client.delete(f"/v1/search-requests/{request_id}", headers=AUTH)
    assert archived.status_code == 204
    assert client.get("/v1/search-requests", headers=AUTH).json() == []
    with_archive = client.get("/v1/search-requests", params={"include_archived": True}, headers=AUTH)
    assert with_archive.status_code == 200
    assert with_archive.json()[0]["status"] == "archived"


def test_community_membership_join_and_leave_roundtrip() -> None:
    initial = client.get("/v1/communities/c1/membership", headers=AUTH)
    assert initial.status_code == 200
    assert initial.json()["joined"] is False

    joined = client.put("/v1/communities/c1/membership", headers=AUTH)
    assert joined.status_code == 200
    assert joined.json() == {"community_id": "c1", "global_id": 1, "joined": True}

    left = client.delete("/v1/communities/c1/membership", headers=AUTH)
    assert left.status_code == 200
    assert left.json()["joined"] is False
