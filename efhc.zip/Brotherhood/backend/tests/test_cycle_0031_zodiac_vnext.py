from datetime import date, datetime, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from app.main import app
from app.models import ZodiacReadingCreate
from app.zodiac_vnext import (
    SIGN_ORDER,
    build_reading,
    catalog_index,
    compatibility_score,
    public_spec,
    sign_for_date,
)
from app.independent_compatibility import _zodiac_score
from app.storage import ZODIAC_COMPARISONS, ZODIAC_READINGS, PERSONALITY_PROFILES

client = TestClient(app)


def setup_function() -> None:
    ZODIAC_READINGS.clear()
    ZODIAC_COMPARISONS.clear()
    PERSONALITY_PROFILES.clear()


def test_sign_boundaries_match_existing_brotherhood_runtime() -> None:
    vectors = {
        date(1990, 3, 20): "PISCES",
        date(1990, 3, 21): "ARIES",
        date(1990, 4, 19): "ARIES",
        date(1990, 4, 20): "TAURUS",
        date(1990, 6, 21): "CANCER",
        date(1990, 9, 23): "LIBRA",
        date(1990, 12, 21): "SAGITTARIUS",
        date(1990, 12, 22): "CAPRICORN",
        date(1990, 1, 19): "CAPRICORN",
        date(1990, 1, 20): "AQUARIUS",
        date(1992, 2, 29): "PISCES",
    }
    assert {value: sign_for_date(value) for value in vectors} == vectors


def test_catalog_has_exact_12_signs_and_existing_v1_characteristics() -> None:
    index = catalog_index("ru")
    assert index.sign_count == 12
    assert [row.sign_id for row in index.signs] == SIGN_ORDER
    aries = next(row for row in index.signs if row.sign_id == "ARIES")
    assert (aries.period_start, aries.period_end, aries.group_id) == ("03-21", "04-19", "FIRE")
    assert aries.characteristics == ["инициатива", "прямота", "быстрый старт"]
    assert aries.characteristics_locale == "ru"
    assert aries.evidence_status == "TRADITIONAL_ALTERNATIVE_PRODUCT_COPY"


def test_spec_preserves_basic_zodiac_boundary_and_no_synastry_claim() -> None:
    spec = public_spec()
    assert spec.method_id == "AS_ZODIAC_BASIC_V1"
    assert spec.compatibility_version == "zodiac-runtime-v1"
    assert spec.sign_count == 12
    assert spec.compatibility_rules == {
        "SAME_SIGN": 86,
        "SAME_ELEMENT_GROUP": 90,
        "SUPPORTED_CROSS_ELEMENT_GROUP": 84,
        "OTHER_ELEMENT_PAIR": 66,
    }
    assert "No natal chart" in spec.compatibility_input_policy
    assert "AS_SYNASTRY_V1 is not active" in spec.future_method_boundary
    assert "not psychometric evidence" in spec.scientific_boundary


def test_new_standalone_score_is_exact_q28_as_runtime_parity_for_all_sign_pairs() -> None:
    for first in SIGN_ORDER:
        for second in SIGN_ORDER:
            expected = compatibility_score(first, second)
            actual = _zodiac_score(SimpleNamespace(zodiac_sign=first), SimpleNamespace(zodiac_sign=second))
            assert actual == expected


def test_reading_is_deterministic_idempotent_and_re_readable() -> None:
    payload = {"global_id": 1, "birth_date": "1990-02-14", "locale": "ru"}
    first = client.post("/v1/zodiac/readings", json=payload)
    second = client.post("/v1/zodiac/readings", json=payload)
    assert first.status_code == 200 == second.status_code
    assert first.json()["reading_id"] == second.json()["reading_id"]
    body = first.json()
    assert body["sign"]["sign_id"] == "AQUARIUS"
    assert body["month_day_code"] == 214
    assert body["calculation_version"] == "zodiac-basic-reading-v1"
    assert len(body["input_snapshot_hash"]) == 64

    history = client.get("/v1/zodiac/readings/1")
    latest = client.get("/v1/zodiac/readings/1/latest")
    detail = client.get(f"/v1/zodiac/readings/1/{body['reading_id']}")
    assert history.status_code == latest.status_code == detail.status_code == 200
    assert len(history.json()) == 1
    assert latest.json()["reading_id"] == body["reading_id"]
    assert detail.json()["sign"]["sign_id"] == "AQUARIUS"


def test_pair_comparison_freezes_signs_and_persists_history() -> None:
    assert client.post("/v1/zodiac/readings", json={"global_id": 1, "birth_date": "1990-02-14", "locale": "ru"}).status_code == 200
    assert client.post("/v1/zodiac/readings", json={"global_id": 2, "birth_date": "1988-08-10", "locale": "ru"}).status_code == 200
    response = client.post("/v1/zodiac/compatibility", json={"first_global_id": 1, "second_global_id": 2, "locale": "ru"})
    assert response.status_code == 200
    body = response.json()
    assert body["first_sign"]["sign_id"] == "AQUARIUS"
    assert body["second_sign"]["sign_id"] == "LEO"
    assert body["relation_code"] == "SUPPORTED_CROSS_ELEMENT_GROUP"
    assert body["score"] == 84
    assert body["compatibility_version"] == "zodiac-runtime-v1"
    history = client.get("/v1/zodiac/compatibility/1/history")
    assert history.status_code == 200
    assert history.json()[0]["comparison_id"] == body["comparison_id"]


def test_catalog_routes_and_unknown_sign() -> None:
    index = client.get("/v1/zodiac/catalog/ru")
    assert index.status_code == 200
    assert index.json()["sign_count"] == 12
    detail = client.get("/v1/zodiac/catalog/ru/AQUARIUS")
    assert detail.status_code == 200
    assert detail.json()["label"] == "Водолей"
    assert client.get("/v1/zodiac/catalog/ru/NOT_A_SIGN").status_code == 404


def test_different_birth_date_creates_new_immutable_snapshot() -> None:
    a = build_reading(
        ZodiacReadingCreate(global_id=1, birth_date=date(1990, 2, 14), locale="ru"),
        created_at=datetime(2026, 8, 13, tzinfo=timezone.utc),
    )
    b = build_reading(
        ZodiacReadingCreate(global_id=1, birth_date=date(1990, 3, 21), locale="ru"),
        created_at=datetime(2026, 8, 13, tzinfo=timezone.utc),
    )
    assert a.input_snapshot_hash != b.input_snapshot_hash
    assert a.sign.sign_id == "AQUARIUS"
    assert b.sign.sign_id == "ARIES"
