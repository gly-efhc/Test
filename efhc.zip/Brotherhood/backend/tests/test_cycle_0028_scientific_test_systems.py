from app.scientific_assessment_bank import BANK, SYSTEMS as BANK_SYSTEMS, ITEMS, score_to_upsert, compatibility
from app.psychological_test_systems import SYSTEMS, all_system_results, system_compatibility


def _responses(system_id: str, offset: int = 0) -> dict[str, int]:
    rows = [row for row in ITEMS if row["system_id"] == system_id]
    return {row["item_id"]: 1 + ((idx + offset) % 4) for idx, row in enumerate(rows)}


def _record(global_id: int, system_id: str, offset: int = 0):
    return score_to_upsert(
        global_id=global_id,
        system_id=system_id,
        responses=_responses(system_id, offset),
        instrument_locale="ru",
        started_at_epoch_ms=1785449990000 + offset,
        completed_at_epoch_ms=1785450000000 + offset,
    )


def test_catalog_has_seven_scientific_systems_and_197_items():
    assert len(BANK_SYSTEMS) == 7
    assert len(SYSTEMS) == 7
    assert len(ITEMS) == 197
    assert BANK["status"] == "ACTIVE_RELEASE_BASELINE"
    assert BANK["rules"]["server_authoritative_scoring"] is True
    assert all(spec.system_id in {row["system_id"] for row in BANK_SYSTEMS} for spec in SYSTEMS)


def test_every_item_belongs_to_one_system_and_has_construct_scoring_and_sources():
    system_ids = {row["system_id"] for row in BANK_SYSTEMS}
    assert len({row["item_id"] for row in ITEMS}) == 197
    for row in ITEMS:
        assert row["system_id"] in system_ids
        assert row["construct_id"]
        assert row["scoring_direction"] in {-1, 1}
        assert row["source_ids"]
        assert row["claim_ids"]
        assert len(row["answer_labels_ru"]) == 4


def test_results_are_deterministic_on_scientific_corpus_baseline():
    rows = [_record(1, "traits_core")]
    first = all_system_results(rows)
    second = all_system_results(rows)
    assert first == second
    core = next(x for x in first if x["system_id"] == "traits_core")
    assert core["calibration_version"] == "scientific-corpus-baseline-v1"
    assert core["calibration_basis"] == "SCIENTIFIC_CORPUS_RELEASE_BASELINE"
    assert core["status"] == "PROFILE_READY"
    assert core["coverage_percent"] >= 70


def test_system_compatibility_is_independent_zero_to_100_and_missing_is_not_zero():
    spec = next(x for x in SYSTEMS if x.system_id == "traits_core")
    a = [_record(1, "traits_core", 0)]
    b = [_record(2, "traits_core", 1)]
    score = system_compatibility(spec, a, b)
    assert score["status"] == "AVAILABLE"
    assert 0 <= score["score"] <= 100
    missing = system_compatibility(spec, a, [])
    assert missing["status"] == "INSUFFICIENT_DATA"
    assert missing["score"] is None


def test_low_level_questionnaire_compatibility_uses_construct_similarity():
    left = _record(1, "communication_conflict", 0)
    right = _record(2, "communication_conflict", 2)
    row = compatibility("communication_conflict", left.dimensions, right.dimensions)
    assert row["common_constructs"] > 0
    assert 0 <= row["score"] <= 100
    assert 0 < row["coverage"] <= 100


def test_future_recalibration_is_versioned_and_not_a_launch_gate():
    spec = next(x for x in SYSTEMS if x.system_id == "traits_core")
    row = system_compatibility(spec, [_record(1, "traits_core", 0)], [_record(2, "traits_core", 1)])
    assert row["calibration_version"] == "scientific-corpus-baseline-v1"
    assert row["evidence_bundle_version"] == "scientific-baseline-synthesis-v1"
    assert row["future_recalibration_policy"] == "POST_RELEASE_VERSIONED_RECALIBRATION_ONLY"
    assert row["score"] is not None


def test_every_construct_has_at_least_three_independent_item_signals():
    from collections import Counter
    counts = Counter((row["system_id"], row["construct_id"]) for row in ITEMS)
    for system in BANK_SYSTEMS:
        for construct_id in system["construct_ids"]:
            assert counts[(system["system_id"], construct_id)] >= 3
        assert system["minimum_items_per_construct"] >= 3
    assert BANK["measurement_depth"]["pairs_below_minimum"] == 0


def test_direct_mini_ipip_anchors_keep_broad_factor_semantics():
    expected = {
        "MIPIP-A": "agreeableness_orientation",
        "MIPIP-C": "conscientiousness_orientation",
        "MIPIP-N": "emotional_stability",
        "MIPIP-O": "openness_intellect",
        "MIPIP-E": "social_energy",
    }
    for prefix, construct_id in expected.items():
        rows = [row for row in ITEMS if row["item_id"].startswith(prefix)]
        assert rows, prefix
        assert {row["construct_id"] for row in rows} == {construct_id}
        if prefix != "MIPIP-E":
            assert {row.get("mapping_note") for row in rows} == {"BROAD_FACTOR_ANCHOR_NOT_NARROW_FACET_CLAIM"}

