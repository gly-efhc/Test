from datetime import datetime, timezone

from fastapi.testclient import TestClient

from app.main import app
from app.models import AssessmentDimensionResult, AssessmentResultUpsert, SearchRequestCreate
from app.quality_fit_v2 import build_evaluation, catalog, spec
from app.storage import ASSESSMENT_RESULTS, QUALITY_FIT_EVALUATIONS, SEARCH_REQUESTS, create_search_request, upsert_assessment_result

client = TestClient(app)


def setup_function() -> None:
    ASSESSMENT_RESULTS.clear()
    QUALITY_FIT_EVALUATIONS.clear()
    SEARCH_REQUESTS.clear()


def seed_candidate(global_id: int = 2, *, dependability: int = 88, directness: int = 78, empathy: int = 32) -> None:
    upsert_assessment_result(
        AssessmentResultUpsert(
            global_id=global_id,
            assessment_id="big_five",
            scoring_version="scientific-questionnaire-v1",
            stimulus_version="text-situational-v1",
            instrument_locale="ru",
            started_at_epoch_ms=1_700_000_000_000,
            total_score=72,
            risk_score=0,
            answer_consistency=92,
            idealized_self_presentation=0,
            label="Большая пятёрка",
            summary="Демонстрационный научный результат для Quality Fit v2.",
            dimensions=[
                AssessmentDimensionResult(id="dependability", title="dependability", score=dependability),
                AssessmentDimensionResult(id="directness", title="directness", score=directness),
                AssessmentDimensionResult(id="empathy", title="empathy", score=empathy),
            ],
            completed_at_epoch_ms=1_700_000_060_000,
        )
    )


def test_spec_and_catalog_preserve_directional_separation_and_no_role_defaults() -> None:
    s = spec()
    assert s.contract_version == "quality-fit-search-intent-v2"
    assert s.directionality == "SEARCHER_A_TO_CANDIDATE_B"
    assert s.role_injects_defaults is False
    assert s.quality_count == 112
    assert any("Compatibility" in row for row in s.separation_rules)
    assert any("Trust" in row for row in s.separation_rules)
    c = catalog("ru")
    assert c.quality_count == 112
    assert len(c.qualities) == 112
    assert {"friendship", "character", "communication", "business"} <= set(c.groups)


def test_directional_score_uses_only_explicit_requirements_and_missing_data_is_not_zero() -> None:
    seed_candidate()
    body = {
        "searcher_global_id": 1,
        "candidate_global_id": 2,
        "role_context": "Друг",
        "requirements": [
            {"quality_key": "reliable", "importance": 5, "kind": "preference", "minimum_score": 70},
            {"quality_key": "direct", "importance": 3, "kind": "preference", "minimum_score": 70},
            {"quality_key": "resource_steward", "importance": 1, "kind": "preference", "minimum_score": 70},
        ],
    }
    r = client.post("/v1/quality-fit/evaluations", json=body)
    assert r.status_code == 200
    data = r.json()
    assert data["direction"] == "A_TO_B"
    assert data["score"] is not None and 0 <= data["score"] <= 100
    assert data["availability"] == "PARTIAL"
    missing = next(row for row in data["requirement_results"] if row["quality_key"] == "resource_steward")
    assert missing["score"] is None
    assert missing["status"] == "INSUFFICIENT_DATA"
    assert "resource_steward" in data["missing_quality_keys"]


def test_hard_requirement_controls_eligibility_without_becoming_hidden_cross_metric_weight() -> None:
    seed_candidate(dependability=35)
    r = client.post(
        "/v1/quality-fit/evaluations",
        json={
            "searcher_global_id": 1,
            "candidate_global_id": 2,
            "role_context": "Друг",
            "requirements": [
                {"quality_key": "reliable", "importance": 5, "kind": "hard", "minimum_score": 80},
                {"quality_key": "direct", "importance": 2, "kind": "preference", "minimum_score": 70},
            ],
        },
    )
    assert r.status_code == 200
    data = r.json()
    assert data["availability"] == "HARD_REQUIREMENT_NOT_MET"
    assert data["eligible"] is False
    assert data["score"] is not None
    hard = next(row for row in data["requirement_results"] if row["quality_key"] == "reliable")
    assert hard["status"] == "NOT_MET"


def test_empty_explicit_requirement_set_returns_insufficient_data_not_default_role_profile() -> None:
    seed_candidate()
    r = client.post(
        "/v1/quality-fit/evaluations",
        json={"searcher_global_id": 1, "candidate_global_id": 2, "role_context": "Партнёр", "requirements": []},
    )
    assert r.status_code == 200
    data = r.json()
    assert data["score"] is None
    assert data["availability"] == "INSUFFICIENT_DATA"
    assert data["requirement_results"] == []


def test_same_intent_and_same_candidate_evidence_is_idempotent_and_history_is_re_readable() -> None:
    seed_candidate()
    payload = {
        "searcher_global_id": 1,
        "candidate_global_id": 2,
        "role_context": "Друг",
        "requirements": [{"quality_key": "reliable", "importance": 5, "kind": "preference", "minimum_score": 70}],
    }
    first = client.post("/v1/quality-fit/evaluations", json=payload)
    second = client.post("/v1/quality-fit/evaluations", json=payload)
    assert first.status_code == second.status_code == 200
    assert first.json()["evaluation_id"] == second.json()["evaluation_id"]
    history = client.get("/v1/quality-fit/evaluations/1")
    assert history.status_code == 200
    assert len(history.json()) == 1
    detail = client.get(f"/v1/quality-fit/evaluations/1/{first.json()['evaluation_id']}")
    assert detail.status_code == 200
    assert detail.json()["intent_snapshot_hash"] == first.json()["intent_snapshot_hash"]


def test_changed_candidate_evidence_creates_new_snapshot_for_same_intent() -> None:
    seed_candidate(dependability=88)
    payload = {
        "searcher_global_id": 1,
        "candidate_global_id": 2,
        "role_context": "Друг",
        "requirements": [{"quality_key": "reliable", "importance": 5, "kind": "preference", "minimum_score": 70}],
    }
    first = client.post("/v1/quality-fit/evaluations", json=payload).json()
    ASSESSMENT_RESULTS.clear()
    seed_candidate(dependability=45)
    second = client.post("/v1/quality-fit/evaluations", json=payload).json()
    assert first["intent_snapshot_hash"] == second["intent_snapshot_hash"]
    assert first["candidate_evidence_hash"] != second["candidate_evidence_hash"]
    assert first["evaluation_id"] != second["evaluation_id"]


def test_search_request_v2_accepts_structured_hard_and_preference_requirements_without_role_injection() -> None:
    record = create_search_request(
        1,
        SearchRequestCreate(
            title="Друг для спорта",
            role="Друг",
            desired_qualities=[],
            requirements=[
                {"quality_key": "reliable", "importance": 5, "kind": "hard", "minimum_score": 75},
                {"quality_key": "social", "importance": 3, "kind": "preference", "minimum_score": 70},
            ],
            city="Киев",
            radius_km=25,
        ),
    )
    data = record.model_dump(mode="json")
    assert data["quality_fit_version"] == "quality-fit-search-intent-v2"
    assert len(data["requirements"]) == 2
    assert data["requirements"][0]["kind"] == "hard"
