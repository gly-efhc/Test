from fastapi.testclient import TestClient

from app.auth_security import issue_session
from app.main import app
from app.models import AuthProvider
from app.storage import ASSESSMENT_ADMIN_SESSIONS, ASSESSMENT_RESULTS

client = TestClient(app)
AUTH = {"Authorization": "Bearer debug-local-session"}


def setup_function() -> None:
    ASSESSMENT_ADMIN_SESSIONS.clear()
    ASSESSMENT_RESULTS.clear()


def _start(app_id: str = "big_five"):
    return client.post(
        f"/v1/test-apps/{app_id}/sessions",
        headers=AUTH,
        json={"global_id": 1, "instrument_locale": "ru"},
    )


def test_public_catalog_and_definitions_do_not_expose_item_bank_construct_mapping_or_keys() -> None:
    catalog = client.get("/v1/test-apps").json()
    assert len(catalog) == 12
    assert all("construct_ids" not in row for row in catalog)
    definition = client.get("/v1/test-apps/big_five").json()
    assert definition["items_public"] is False
    assert "items" not in definition
    assert "construct_ids" not in definition

    scientific = client.get("/v1/scientific-assessments/traits_core").json()
    assert scientific["items_public"] is False
    assert "items" not in scientific


def test_legacy_client_scoring_and_result_write_are_fail_closed() -> None:
    direct = client.post(
        "/v1/test-apps/big_five/score",
        headers=AUTH,
        json={
            "global_id": 1,
            "responses": {"fake": 4},
            "instrument_locale": "ru",
            "started_at_epoch_ms": 1700000000000,
            "completed_at_epoch_ms": 1700000060000,
        },
    )
    assert direct.status_code == 410
    assert direct.json()["detail"]["code"] == "DIRECT_SCORING_DISABLED"

    scientific = client.post(
        "/v1/scientific-assessments/traits_core/score",
        headers=AUTH,
        json={
            "global_id": 1,
            "responses": {"fake": 4},
            "instrument_locale": "ru",
            "started_at_epoch_ms": 1700000000000,
            "completed_at_epoch_ms": 1700000060000,
        },
    )
    assert scientific.status_code == 410

    write = client.put(
        "/v1/assessment-results",
        headers=AUTH,
        json={
            "global_id": 1,
            "assessment_id": "big_five",
            "scoring_version": "scientific-questionnaire-v1",
            "stimulus_version": "text-situational-v1",
            "instrument_locale": "ru",
            "started_at_epoch_ms": 1700000000000,
            "total_score": 100,
            "risk_score": 0,
            "answer_consistency": 100,
            "idealized_self_presentation": 0,
            "label": "forged result",
            "summary": "forged result must never be accepted by the public API",
            "dimensions": [{"id": "x", "title": "x", "score": 100}],
            "completed_at_epoch_ms": 1700000060000,
        },
    )
    assert write.status_code == 410
    assert write.json()["detail"]["code"] == "CLIENT_RESULT_WRITE_DISABLED"


def test_session_is_owner_bound_opaque_sequential_and_resumable() -> None:
    assert client.post(
        "/v1/test-apps/big_five/sessions",
        json={"global_id": 1, "instrument_locale": "ru"},
    ).status_code == 401

    other = issue_session(2, AuthProvider.EMAIL)
    wrong_owner = client.post(
        "/v1/test-apps/big_five/sessions",
        headers={"Authorization": f"Bearer {other.access_token}"},
        json={"global_id": 1, "instrument_locale": "ru"},
    )
    assert wrong_owner.status_code == 403

    started = _start()
    assert started.status_code == 200, started.text
    first = started.json()
    assert first["status"] == "IN_PROGRESS"
    assert first["position"] == 1
    assert first["item_count"] == 20
    assert set(first["current_item"]) == {"item_token", "prompt", "answer_labels", "position", "total"}
    assert "item_id" not in first["current_item"]
    assert "construct_id" not in first["current_item"]

    resumed = _start().json()
    assert resumed["session_id"] == first["session_id"]
    assert resumed["current_item"]["item_token"] == first["current_item"]["item_token"]

    wrong_token = client.post(
        f"/v1/test-app-sessions/{first['session_id']}/answers",
        headers=AUTH,
        json={"item_token": "00000000-0000-0000-0000-000000000001", "answer": 2},
    )
    assert wrong_token.status_code == 409
    assert wrong_token.json()["detail"]["code"] == "ITEM_TOKEN_MISMATCH"

    answered = client.post(
        f"/v1/test-app-sessions/{first['session_id']}/answers",
        headers=AUTH,
        json={"item_token": first["current_item"]["item_token"], "answer": 2, "response_latency_ms": 850},
    )
    assert answered.status_code == 200, answered.text
    second = answered.json()
    assert second["position"] == 2
    assert second["current_item"]["item_token"] != first["current_item"]["item_token"]

    replay = client.post(
        f"/v1/test-app-sessions/{first['session_id']}/answers",
        headers=AUTH,
        json={"item_token": first["current_item"]["item_token"], "answer": 4},
    )
    assert replay.status_code == 409

    forbidden = client.get(
        f"/v1/test-app-sessions/{first['session_id']}",
        headers={"Authorization": f"Bearer {other.access_token}"},
    )
    assert forbidden.status_code == 403


def test_all_twelve_product_tests_complete_only_through_secure_sessions() -> None:
    catalog = client.get("/v1/test-apps").json()
    assert len(catalog) == 12
    for app_index, app_row in enumerate(catalog):
        started = _start(app_row["app_id"])
        assert started.status_code == 200, (app_row["app_id"], started.text)
        session = started.json()
        seen_tokens = set()
        while session["status"] == "IN_PROGRESS":
            item = session["current_item"]
            assert item is not None
            assert item["item_token"] not in seen_tokens
            seen_tokens.add(item["item_token"])
            response = client.post(
                f"/v1/test-app-sessions/{session['session_id']}/answers",
                headers=AUTH,
                json={
                    "item_token": item["item_token"],
                    "answer": 1 + ((item["position"] + app_index) % 4),
                    "response_latency_ms": 700 + item["position"],
                    "selection_changes": 0,
                },
            )
            assert response.status_code == 200, (app_row["app_id"], response.text)
            session = response.json()
        assert session["status"] == "COMPLETED"
        assert session["current_item"] is None
        assert session["result_id"]
        assert len(seen_tokens) == app_row["item_count"]

    history = client.get("/v1/assessment-results/1", headers=AUTH)
    assert history.status_code == 200
    assert {row["assessment_id"] for row in history.json()} >= {row["app_id"] for row in catalog}


def test_completed_session_does_not_reopen_and_new_start_creates_new_session() -> None:
    session = _start("self_regulation").json()
    first_id = session["session_id"]
    while session["status"] == "IN_PROGRESS":
        item = session["current_item"]
        session = client.post(
            f"/v1/test-app-sessions/{session['session_id']}/answers",
            headers=AUTH,
            json={"item_token": item["item_token"], "answer": 3},
        ).json()
    assert session["status"] == "COMPLETED"

    completed_get = client.get(f"/v1/test-app-sessions/{first_id}", headers=AUTH)
    assert completed_get.status_code == 200
    assert completed_get.json()["status"] == "COMPLETED"

    new_session = _start("self_regulation")
    assert new_session.status_code == 200
    assert new_session.json()["session_id"] != first_id
    assert new_session.json()["position"] == 1
