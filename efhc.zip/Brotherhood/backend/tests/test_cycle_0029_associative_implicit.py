from fastapi.testclient import TestClient
from app.main import app
from app.associative_implicit import public_definition, score_to_upsert, compatibility
from app.models import AssociativeEventSubmit
from app.storage import ASSOCIATIVE_RESULTS, FRIENDSHIP_PATTERN_OBSERVATIONS

client=TestClient(app)
AUTH={"Authorization":"Bearer debug-local-session"}
INTERNAL={"X-Internal-Auth":"debug"}


def setup_function():
    ASSOCIATIVE_RESULTS.clear(); FRIENDSHIP_PATTERN_OBSERVATIONS.clear()


def _word_events():
    d=public_definition("WORD_ASSOCIATION_V1")
    return [AssociativeEventSubmit(stimulus_id=x["stimulus_id"],response_text=f"ответ-{i}",latency_ms=900+i*30,edit_count=0,sequence_index=i) for i,x in enumerate(d["stimuli"])]


def _free_events():
    d=public_definition("ASSOCIATIVE_FREE_CHAIN_V1")
    rows=[]; idx=0
    for seed in d["stimuli"]:
        for j in range(5):
            rows.append(AssociativeEventSubmit(stimulus_id=seed["stimulus_id"],response_text=f"{seed['cue']}-{j}",latency_ms=1100+j*120,edit_count=0,sequence_index=idx)); idx+=1
    return rows


def _iat_events(offset=0):
    d=public_definition("IMPLICIT_ASSOCIATION_RT_V1")
    rows=[]
    for i,x in enumerate(d["stimuli"]):
        # Make compatible critical block faster than incompatible to produce positive D.
        base=650 if x["block_id"]=="iat_compatible" else 980 if x["block_id"]=="iat_incompatible" else 750
        rows.append(AssociativeEventSubmit(stimulus_id=x["stimulus_id"],block_id=x["block_id"],action=x["expected_action"],latency_ms=base+(i%4)*20+offset,sequence_index=i))
    return rows


def test_catalog_definitions_are_complete_and_distinct():
    word=public_definition("WORD_ASSOCIATION_V1")
    free=public_definition("ASSOCIATIVE_FREE_CHAIN_V1")
    iat=public_definition("IMPLICIT_ASSOCIATION_RT_V1")
    assert len(word["stimuli"])==24
    assert len(free["stimuli"])==8
    assert len(iat["stimuli"])==48
    assert sum(1 for x in iat["stimuli"] if not x["practice"])==32


def test_each_method_scores_deterministically_without_symbolic_dictionary():
    word=score_to_upsert(global_id=1,method_id="WORD_ASSOCIATION_V1",events=_word_events(),instrument_locale="ru",started_at_epoch_ms=1000,completed_at_epoch_ms=2000)
    free=score_to_upsert(global_id=1,method_id="ASSOCIATIVE_FREE_CHAIN_V1",events=_free_events(),instrument_locale="ru",started_at_epoch_ms=1000,completed_at_epoch_ms=3000)
    iat=score_to_upsert(global_id=1,method_id="IMPLICIT_ASSOCIATION_RT_V1",events=_iat_events(),instrument_locale="ru",started_at_epoch_ms=1000,completed_at_epoch_ms=4000)
    assert word.public_features["response_flow"]==100
    assert free.public_features["chain_completion"]==100
    assert iat.public_features["cooperation_association_balance"]>50
    assert "d_score" in iat.derived_details
    assert "травм" not in word.result_summary.lower()


def test_api_persists_history_and_method_specific_compatibility():
    def post(gid,offset):
        events=[e.model_dump(mode="json") for e in _iat_events(offset)]
        r=client.post("/v1/associative-instruments/IMPLICIT_ASSOCIATION_RT_V1/score",headers=AUTH,json={"global_id":gid,"events":events,"instrument_locale":"ru","started_at_epoch_ms":1000,"completed_at_epoch_ms":5000+offset})
        assert r.status_code==200, r.text
    post(1,0); post(2,80)
    history=client.get("/v1/associative-results/1",headers=AUTH)
    assert history.status_code==200 and len(history.json())==1
    comp=client.post("/v1/associative-compatibility",headers=AUTH,json={"first_global_id":1,"second_global_id":2,"method_id":"IMPLICIT_ASSOCIATION_RT_V1"})
    assert comp.status_code==200
    assert 0 <= comp.json()["score"] <= 100
    assert comp.json()["method_id"]=="IMPLICIT_ASSOCIATION_RT_V1"


def test_reverse_friendship_pattern_analysis_is_descriptive_and_uses_exposed_controls(monkeypatch):
    monkeypatch.setenv("INTERNAL_AUTH_SECRET","debug")
    base={"snapshot_at":"2026-08-13T10:00:00Z","exposure_policy_version":"policy-v1","predictor_snapshot_hash":"a"*64,"difference_features":{"age_gap":10},"method_scores":{"PC_QUESTIONNAIRE":80},"observation_window_days":90}
    rows=[
      {**base,"observation_id":"obs-friend-0001","first_global_id":1,"second_global_id":2,"similarity_features":{"values":92,"interests":85},"outcome_status":"CONFIRMED_FRIENDSHIP","confirmed_by_both":True},
      {**base,"observation_id":"obs-friend-0002","first_global_id":3,"second_global_id":4,"similarity_features":{"values":88,"interests":81},"outcome_status":"CONFIRMED_FRIENDSHIP","confirmed_by_both":True},
      {**base,"observation_id":"obs-control-001","first_global_id":1,"second_global_id":3,"similarity_features":{"values":55,"interests":60},"outcome_status":"NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE","confirmed_by_both":False},
      {**base,"observation_id":"obs-control-002","first_global_id":2,"second_global_id":4,"similarity_features":{"values":58,"interests":62},"outcome_status":"NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE","confirmed_by_both":False},
    ]
    for row in rows:
        r=client.put("/internal/research/friendship-pattern-observations",headers=INTERNAL,json=row); assert r.status_code==200,r.text
    a=client.get("/internal/research/friendship-pattern-analysis",headers=INTERNAL); assert a.status_code==200,a.text
    body=a.json(); assert body["confirmed_friendship_pairs"]==2 and body["comparison_pairs"]==2
    values=next(x for x in body["top_patterns"] if x["feature_id"]=="values")
    assert values["delta_points"]>25
    assert "not causal" in body["note"].lower()
