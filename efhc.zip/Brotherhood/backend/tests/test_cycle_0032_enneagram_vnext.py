from datetime import datetime, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from app.enneagram_vnext import (
    build_reading,
    compatibility_score,
    public_instrument,
    public_spec,
    score_answers,
    type_catalog,
)
from app.independent_compatibility import _enneagram_score
from app.main import app
from app.models import EnneagramReadingCreate
from app.storage import ENNEAGRAM_COMPARISONS, ENNEAGRAM_READINGS, PERSONALITY_PROFILES

client = TestClient(app)


def setup_function() -> None:
    ENNEAGRAM_READINGS.clear()
    ENNEAGRAM_COMPARISONS.clear()
    PERSONALITY_PROFILES.clear()


def demo_answers(offset: int = 0) -> dict[str, int]:
    instrument = public_instrument()
    return {item.item_id: 1 + ((item.sequence - 1 + offset) % 4) for item in instrument.items}


def test_instrument_exactly_mirrors_existing_18_item_local_profile_shape_without_exposing_loadings() -> None:
    instrument = public_instrument()
    assert instrument.instrument_version == "enneagram-core-profile-18-v1"
    assert instrument.item_count == 18
    assert [item.item_id for item in instrument.items] == [f"en_{t}_{i}" for t in range(1, 10) for i in (1, 2)]
    assert all(len(item.choices) == 4 for item in instrument.items)
    public = instrument.model_dump(mode="json")
    assert "loading" not in str(public).lower()
    first = instrument.items[0]
    assert first.paradigm == "RESOURCE"
    assert first.scene_archetype == "SPLIT_PATH"
    assert first.choices[0].model_dump() == {
        "choice_id": "1", "intensity": 3, "spacing": 3, "order": 2, "asymmetry": 3, "direction": 1,
    }


def test_scoring_is_deterministic_and_uses_existing_type_and_wing_selection() -> None:
    answers = demo_answers(0)
    first = score_answers(answers)
    second = score_answers(answers)
    assert first == second
    type_id, wing, confidence, scores = first
    assert type_id in range(1, 10)
    assert wing in {9 if type_id == 1 else type_id - 1, 1 if type_id == 9 else type_id + 1}
    assert confidence == scores[str(type_id)]
    assert len(scores) == 9
    assert all(0 <= value <= 100 for value in scores.values())


def test_spec_and_catalog_keep_typological_experimental_boundary() -> None:
    spec = public_spec()
    assert spec.method_id == "EN_BROTHERHOOD_CORE_PROFILE_V1"
    assert spec.compatibility_version == "enneagram-existing-runtime-v1"
    assert spec.source_ids == ["ENNEA-001"]
    assert spec.item_count == 18
    assert spec.type_count == 9
    assert "mixed reliability/validity" in spec.disclosure
    catalog = type_catalog("ru")
    assert catalog.type_count == 9
    assert [(row.type_id, row.label) for row in catalog.types] == [
        (1, "Реформатор"), (2, "Помощник"), (3, "Достигатель"), (4, "Индивидуалист"),
        (5, "Исследователь"), (6, "Лоялист"), (7, "Энтузиаст"), (8, "Защитник"), (9, "Миротворец"),
    ]


def test_standalone_compatibility_exactly_matches_existing_q28_en_runtime_for_all_type_wing_inputs() -> None:
    for first_type in range(1, 10):
        for second_type in range(1, 10):
            first_wing = 9 if first_type == 1 else first_type - 1
            second_wing = 1 if second_type == 9 else second_type + 1
            expected = compatibility_score(first_type, first_wing, second_type, second_wing)
            actual = _enneagram_score(
                SimpleNamespace(enneagram_type=first_type, enneagram_wing=first_wing),
                SimpleNamespace(enneagram_type=second_type, enneagram_wing=second_wing),
            )
            assert actual == expected


def test_reading_is_immutable_idempotent_and_re_readable() -> None:
    payload = {"global_id": 1, "answers": demo_answers(0), "locale": "ru"}
    first = client.post("/v1/enneagram/readings", json=payload)
    second = client.post("/v1/enneagram/readings", json=payload)
    assert first.status_code == 200 == second.status_code
    assert first.json()["reading_id"] == second.json()["reading_id"]
    body = first.json()
    assert body["method_id"] == "EN_BROTHERHOOD_CORE_PROFILE_V1"
    assert body["instrument_version"] == "enneagram-core-profile-18-v1"
    assert body["type_id"] in range(1, 10)
    assert len(body["answers_snapshot_hash"]) == 64
    assert len(body["type_scores"]) == 9
    history = client.get("/v1/enneagram/readings/1")
    latest = client.get("/v1/enneagram/readings/1/latest")
    detail = client.get(f"/v1/enneagram/readings/1/{body['reading_id']}")
    assert history.status_code == latest.status_code == detail.status_code == 200
    assert len(history.json()) == 1
    assert latest.json()["reading_id"] == body["reading_id"]
    assert detail.json()["type_id"] == body["type_id"]


def test_different_answer_snapshot_creates_new_reading() -> None:
    a = build_reading(
        EnneagramReadingCreate(global_id=1, answers=demo_answers(0), locale="ru"),
        created_at=datetime(2026, 8, 13, tzinfo=timezone.utc),
    )
    b = build_reading(
        EnneagramReadingCreate(global_id=1, answers=demo_answers(1), locale="ru"),
        created_at=datetime(2026, 8, 13, tzinfo=timezone.utc),
    )
    assert a.answers_snapshot_hash != b.answers_snapshot_hash


def test_pair_comparison_uses_latest_readings_and_persists_frozen_type_wing_history() -> None:
    assert client.post("/v1/enneagram/readings", json={"global_id": 1, "answers": demo_answers(0), "locale": "ru"}).status_code == 200
    assert client.post("/v1/enneagram/readings", json={"global_id": 2, "answers": demo_answers(1), "locale": "ru"}).status_code == 200
    response = client.post("/v1/enneagram/compatibility", json={"first_global_id": 1, "second_global_id": 2, "locale": "ru"})
    assert response.status_code == 200
    body = response.json()
    assert 0 <= body["score"] <= 100
    assert body["first_type"]["type_id"] in range(1, 10)
    assert body["second_type"]["type_id"] in range(1, 10)
    assert body["relation_code"] in {"SAME_TYPE", "WING_LINK", "CIRCULAR_TYPE_DISTANCE"}
    assert body["compatibility_version"] == "enneagram-existing-runtime-v1"
    history = client.get("/v1/enneagram/compatibility/1/history")
    assert history.status_code == 200
    assert history.json()[0]["comparison_id"] == body["comparison_id"]


def test_route_validation_and_missing_data_boundaries() -> None:
    instrument = public_instrument()
    bad_answers = {item.item_id: 1 for item in instrument.items[:-1]}
    assert client.post("/v1/enneagram/readings", json={"global_id": 1, "answers": bad_answers}).status_code == 422
    assert client.get("/v1/enneagram/types/ru/10").status_code == 404
    assert client.post("/v1/enneagram/compatibility", json={"first_global_id": 1, "second_global_id": 2}).status_code == 409
