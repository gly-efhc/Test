from __future__ import annotations

import base64
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import UUID

from fastapi.testclient import TestClient

from app.hospitality import (
    _MEMORY_HOSTS,
    _MEMORY_REQUESTS,
    _MEMORY_PRIVATE_ACCESS_AUDIT,
    reset_memory_hospitality,
)
from app.main import app
from app.storage import (
    ASSESSMENT_RESULTS,
    CHAT_CONVERSATIONS,
    CHAT_MESSAGES,
    PROFILES,
    USER_BLOCKS,
    VERIFIED_INTERACTIONS,
)

client = TestClient(app)
TEST_KEY = base64.b64encode(b"hospitality-cycle-0020-key-12345"[:32]).decode("ascii")
CITY_ID = "11111111-1111-1111-1111-111111111111"


def setup_function() -> None:
    os.environ["BROTHERHOOD_STORAGE_MODE"] = "memory"
    os.environ["HOSPITALITY_ENABLED"] = "true"
    os.environ["HOSPITALITY_PRIVATE_KEY_ACTIVE_VERSION"] = "1"
    os.environ["HOSPITALITY_PRIVATE_KEY_V1_B64"] = TEST_KEY
    os.environ["HOSPITALITY_PENDING_TTL_HOURS"] = "48"
    os.environ["HOSPITALITY_REVIEW_WINDOW_DAYS"] = "7"
    reset_memory_hospitality()
    ASSESSMENT_RESULTS.clear()
    PROFILES.clear()
    CHAT_CONVERSATIONS.clear()
    CHAT_MESSAGES.clear()
    USER_BLOCKS.clear()


def _headers_for(global_id: int) -> dict[str, str]:
    if global_id == 1:
        return {"Authorization": "Bearer debug-local-session"}
    response = client.post("/internal/sessions/issue", json={"global_id": global_id, "provider": "telegram"})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def _host_payload(**changes):
    value = {
        "is_hosting_active": True,
        "max_guests": 2,
        "max_days": 7,
        "city_id": CITY_ID,
        "public_area_text": "Central district",
        "timezone_name": "Europe/Kyiv",
        "sleeping_condition": "private_room",
        "house_rules": ["Respect quiet hours"],
        "min_required_rating": 0,
        "required_completed_tests": [],
        "availability_mode": "always",
        "private_location": {
            "exact_address": "Private Test Street 10",
            "arrival_instructions": "Call on arrival",
            "exact_lat": 50.4501,
            "exact_lon": 30.5234,
            "arrival_contact": "@private-host",
        },
    }
    value.update(changes)
    return value


def _create_host(global_id: int = 1, **changes) -> dict:
    response = client.put("/v1/hospitality/profile", json=_host_payload(**changes), headers=_headers_for(global_id))
    assert response.status_code == 200, response.text
    return response.json()


def _create_request(guest_id: int = 2, host_id: int = 1, *, key: str = "hospitality-request-0001", guests: int = 1) -> dict:
    response = client.post(
        "/v1/hospitality/requests",
        json={"host_global_id": host_id, "check_in_date": "2026-09-10", "check_out_date": "2026-09-13", "guests_count": guests},
        headers={**_headers_for(guest_id), "Idempotency-Key": key},
    )
    assert response.status_code == 201, response.text
    return response.json()


def test_feature_flag_is_fail_closed() -> None:
    os.environ["HOSPITALITY_ENABLED"] = "false"
    response = client.get("/v1/hospitality/profile", headers=_headers_for(1))
    assert response.status_code == 404
    assert response.json()["detail"]["code"] == "HOSPITALITY_DISABLED"
    assert client.get("/v1/config").json()["hospitality"]["enabled"] is False


def test_host_private_location_is_encrypted_and_public_contract_never_returns_it() -> None:
    owner = _create_host()
    assert owner["private_location"]["exact_address"] == "Private Test Street 10"
    stored = _MEMORY_HOSTS[1]
    assert b"Private Test Street 10" not in stored.private_location_ciphertext
    assert len(stored.private_location_nonce) == 12
    public = client.get("/v1/hospitality/hosts/1", headers=_headers_for(2))
    assert public.status_code == 200
    text = public.text
    assert "exact_address" not in text
    assert "exact_lat" not in text
    assert "arrival_contact" not in text


def test_eligibility_reports_rating_and_required_test_failures_without_private_assessment_data() -> None:
    _create_host(min_required_rating=85, required_completed_tests=["traits_core"])
    response = client.get(
        "/v1/hospitality/hosts/1/eligibility",
        params={"check_in_date": "2026-09-10", "check_out_date": "2026-09-13", "guests_count": 1},
        headers=_headers_for(2),
    )
    assert response.status_code == 200
    body = response.json()
    assert body["eligible"] is False
    codes = {row["code"] for row in body["reasons"]}
    assert "HOSPITALITY_RATING_TOO_LOW" in codes
    assert "HOSPITALITY_REQUIRED_TESTS_MISSING" in codes
    assert body["missing_required_tests"] == ["traits_core"]
    assert "raw" not in response.text.lower()
    assert "latent" not in response.text.lower()


def test_calendar_mode_requires_explicit_available_interval_and_unavailable_overrides() -> None:
    _create_host(availability_mode="calendar")
    guest_headers = _headers_for(2)
    params = {"check_in_date": "2026-09-10", "check_out_date": "2026-09-13", "guests_count": 1}
    assert client.get("/v1/hospitality/hosts/1/eligibility", params=params, headers=guest_headers).json()["date_available"] is False
    available = client.put(
        "/v1/hospitality/availability",
        json={"date_from": "2026-09-10", "date_to": "2026-09-14", "availability_state": "available", "capacity_override": 2},
        headers=_headers_for(1),
    )
    assert available.status_code == 200
    assert client.get("/v1/hospitality/hosts/1/eligibility", params=params, headers=guest_headers).json()["eligible"] is True
    unavailable = client.put(
        "/v1/hospitality/availability",
        json={"date_from": "2026-09-11", "date_to": "2026-09-12", "availability_state": "unavailable"},
        headers=_headers_for(1),
    )
    assert unavailable.status_code == 200
    body = client.get("/v1/hospitality/hosts/1/eligibility", params=params, headers=guest_headers).json()
    assert body["date_available"] is False
    assert any(row["code"] == "HOSPITALITY_DATES_UNAVAILABLE" for row in body["reasons"])


def test_request_creation_is_idempotent_and_reuses_canonical_direct_conversation() -> None:
    _create_host()
    first = _create_request()
    second = _create_request()
    assert first["request_id"] == second["request_id"]
    assert first["conversation_id"] == second["conversation_id"]
    assert len(CHAT_CONVERSATIONS) == 1
    snapshot = first["eligibility_snapshot"]
    assert snapshot["contract_version"] == "hospitality-eligibility-v1"
    assert snapshot["compatibility_summary"] == {}
    assert snapshot["quality_fit_summary"] == {}
    assert "exact_address" not in str(snapshot)


def test_arrival_details_are_denied_before_acceptance_then_available_only_to_participants() -> None:
    _create_host()
    request = _create_request()
    request_id = request["request_id"]
    guest_headers = _headers_for(2)
    before = client.get(f"/v1/hospitality/requests/{request_id}/arrival-details", headers=guest_headers)
    assert before.status_code == 403
    accepted = client.patch(
        f"/v1/hospitality/requests/{request_id}/status",
        json={"action": "accept", "expected_version": request["version"], "reason": None},
        headers=_headers_for(1),
    )
    assert accepted.status_code == 200
    assert accepted.json()["status"] == "accepted"
    details = client.get(f"/v1/hospitality/requests/{request_id}/arrival-details", headers=guest_headers)
    assert details.status_code == 200
    assert details.json()["exact_address"] == "Private Test Street 10"
    # Acceptance-time snapshot is immutable: later host edits do not rewrite an accepted visit address.
    changed = _host_payload(private_location={
        "exact_address": "Changed Host Address 99", "arrival_instructions": "New",
        "exact_lat": 50.5, "exact_lon": 30.6, "arrival_contact": "@new-host",
    })
    assert client.put("/v1/hospitality/profile", json=changed, headers=_headers_for(1)).status_code == 200
    preserved = client.get(f"/v1/hospitality/requests/{request_id}/arrival-details", headers=guest_headers)
    assert preserved.status_code == 200
    assert preserved.json()["exact_address"] == "Private Test Street 10"
    third = client.get(f"/v1/hospitality/requests/{request_id}/arrival-details", headers=_headers_for(3))
    assert third.status_code == 403
    detail = client.get(f"/v1/hospitality/requests/{request_id}", headers=_headers_for(3))
    assert detail.status_code == 403
    # A later block revokes new private-address access even for accepted participants.
    assert client.put("/v1/users/1/block", json={"blocked": True}, headers=guest_headers).status_code == 200
    blocked = client.get(f"/v1/hospitality/requests/{request_id}/arrival-details", headers=guest_headers)
    assert blocked.status_code == 403
    assert blocked.json()["detail"]["code"] == "HOSPITALITY_BLOCKED_RELATIONSHIP"
    assert any(row["viewer_global_id"] == 2 and row["granted"] is True for row in _MEMORY_PRIVATE_ACCESS_AUDIT)
    assert any(row["viewer_global_id"] == 3 and row["granted"] is False for row in _MEMORY_PRIVATE_ACCESS_AUDIT)
    assert any(row["viewer_global_id"] == 2 and row["granted"] is False for row in _MEMORY_PRIVATE_ACCESS_AUDIT)
    assert all("exact_address" not in row for row in _MEMORY_PRIVATE_ACCESS_AUDIT)


def test_atomic_capacity_recheck_rejects_second_accept_when_last_slot_is_taken() -> None:
    _create_host(max_guests=1)
    first = _create_request(guest_id=2, key="capacity-request-0001")
    second = _create_request(guest_id=3, key="capacity-request-0002")
    accepted = client.patch(
        f"/v1/hospitality/requests/{first['request_id']}/status",
        json={"action": "accept", "expected_version": 1}, headers=_headers_for(1),
    )
    assert accepted.status_code == 200
    rejected = client.patch(
        f"/v1/hospitality/requests/{second['request_id']}/status",
        json={"action": "accept", "expected_version": 1}, headers=_headers_for(1),
    )
    assert rejected.status_code == 409
    assert rejected.json()["detail"]["code"] == "HOSPITALITY_CAPACITY_CHANGED"


def test_block_is_hard_eligibility_gate_and_direct_post_cannot_bypass_it() -> None:
    _create_host()
    blocked = client.put("/v1/users/1/block", json={"blocked": True}, headers=_headers_for(2))
    assert blocked.status_code == 200
    eligibility = client.get(
        "/v1/hospitality/hosts/1/eligibility",
        params={"check_in_date": "2026-09-10", "check_out_date": "2026-09-13", "guests_count": 1},
        headers=_headers_for(2),
    )
    assert any(row["code"] == "HOSPITALITY_BLOCKED_RELATIONSHIP" for row in eligibility.json()["reasons"])
    created = client.post(
        "/v1/hospitality/requests",
        json={"host_global_id": 1, "check_in_date": "2026-09-10", "check_out_date": "2026-09-13", "guests_count": 1},
        headers={**_headers_for(2), "Idempotency-Key": "blocked-request-0001"},
    )
    assert created.status_code == 422
    assert created.json()["detail"]["code"] == "HOSPITALITY_BLOCKED_RELATIONSHIP"


def test_tick_expires_pending_and_completes_accepted_without_auto_verified_stay() -> None:
    _create_host()
    pending = _create_request(guest_id=2, key="tick-pending-0001")
    pending_row = _MEMORY_REQUESTS[UUID(pending["request_id"])]
    pending_row.response_due_at = datetime.now(timezone.utc) - timedelta(seconds=1)

    accepted = _create_request(guest_id=3, key="tick-accepted-0002")
    accept_response = client.patch(
        f"/v1/hospitality/requests/{accepted['request_id']}/status",
        json={"action": "accept", "expected_version": 1}, headers=_headers_for(1),
    )
    assert accept_response.status_code == 200
    accepted_row = _MEMORY_REQUESTS[UUID(accepted["request_id"])]
    accepted_row.private_access_expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)
    verified_before = dict(VERIFIED_INTERACTIONS)

    tick = client.post("/internal/hospitality/tick")
    assert tick.status_code == 200
    assert tick.json()["expired_requests"] == 1
    assert tick.json()["completed_requests"] == 1
    assert _MEMORY_REQUESTS[UUID(pending["request_id"])].status == "expired"
    completed_row = _MEMORY_REQUESTS[UUID(accepted["request_id"])]
    assert completed_row.status == "completed"
    assert completed_row.review_deadline_at is not None
    assert VERIFIED_INTERACTIONS == verified_before


def test_disabling_host_rejects_pending_but_does_not_silently_cancel_accepted() -> None:
    _create_host()
    pending = _create_request(guest_id=2, key="disable-pending-0001")
    accepted = _create_request(guest_id=3, key="disable-accepted-0002")
    response = client.patch(
        f"/v1/hospitality/requests/{accepted['request_id']}/status",
        json={"action": "accept", "expected_version": 1}, headers=_headers_for(1),
    )
    assert response.status_code == 200
    disabled = _host_payload(is_hosting_active=False)
    saved = client.put("/v1/hospitality/profile", json=disabled, headers=_headers_for(1))
    assert saved.status_code == 200
    assert _MEMORY_REQUESTS[UUID(pending["request_id"])].status == "rejected"
    assert _MEMORY_REQUESTS[UUID(pending["request_id"])].rejection_reason == "HOST_DISABLED_HOSTING"
    assert _MEMORY_REQUESTS[UUID(accepted["request_id"])].status == "accepted"


def test_people_hospitality_filter_reuses_existing_people_catalog() -> None:
    _create_host(global_id=2)
    response = client.get(
        "/v1/people",
        params={"city": "Киев", "radius_km": 10, "can_host": True, "hospitality_city_id": CITY_ID},
        headers=_headers_for(1),
    )
    assert response.status_code == 200
    body = response.json()
    assert [row["global_id"] for row in body] == [2]
    assert body[0]["hospitality"]["host"]["is_hosting_active"] is True
    assert "private_location" not in str(body[0]["hospitality"])


def test_migration_and_canonical_schema_have_no_plaintext_exact_location_columns() -> None:
    root = Path(__file__).resolve().parents[2]
    migration = (root / "database/migrations/0009_hospitality.sql").read_text(encoding="utf-8")
    schema = (root / "backend/schema.sql").read_text(encoding="utf-8")
    assert "private_location_ciphertext bytea NOT NULL" in migration
    assert "arrival_details_ciphertext bytea" in migration
    assert "exact_address text" not in migration
    assert "exact_lat" not in migration
    assert "exact_lon" not in migration
    assert "arrival_contact text" not in migration
    assert "CREATE TABLE IF NOT EXISTS hospitality_host_profiles" in schema
    assert "CREATE TABLE IF NOT EXISTS stay_requests" in schema
    assert "CREATE TABLE IF NOT EXISTS hospitality_private_access_audit" in schema
    verified_section = schema.split("CREATE TABLE IF NOT EXISTS verified_interactions", 1)[1].split("CREATE TABLE IF NOT EXISTS friendship_compatibility_snapshots", 1)[0]
    assert "searcher_global_id" not in verified_section
