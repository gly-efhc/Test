-- Brotherhood v0.5.7 canonical PostgreSQL / Neon schema.
-- global_id is the sole domain owner identifier. External providers are access identities only.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN
    CREATE TYPE auth_provider AS ENUM ('google', 'telegram', 'facebook', 'email', 'passkey', 'apple', 'microsoft', 'phone');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
    CREATE TYPE community_kind AS ENUM ('interest', 'business');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
    CREATE TYPE incident_status AS ENUM ('pending', 'under_review', 'confirmed', 'rejected', 'appealed', 'final');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS users (
    global_id bigint GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999) PRIMARY KEY,
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'deleted')),
    created_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz,
    CHECK (global_id <> 0)
);

CREATE OR REPLACE FUNCTION global_id_display(value bigint)
RETURNS text LANGUAGE sql IMMUTABLE STRICT AS $$
    SELECT lpad(value::text, 10, '0')
$$;

-- Maps Neon Auth / Better Auth user IDs to canonical global_id.
CREATE TABLE IF NOT EXISTS auth_links (
    auth_user_id text PRIMARY KEY,
    global_id bigint NOT NULL UNIQUE REFERENCES users(global_id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_identities (
    identity_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    provider auth_provider NOT NULL,
    tenant text NOT NULL DEFAULT 'default',
    provider_subject text NOT NULL,
    email_normalized text,
    phone_e164 text,
    verified_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (provider, tenant, provider_subject)
);
CREATE INDEX IF NOT EXISTS user_identities_global_id_idx ON user_identities(global_id);

CREATE TABLE IF NOT EXISTS auth_sessions (
    session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    provider auth_provider NOT NULL,
    token_hash bytea NOT NULL,
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_sessions_global_active_idx ON auth_sessions(global_id, expires_at) WHERE revoked_at IS NULL;

CREATE TABLE IF NOT EXISTS cities (
    city_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    country_code char(2) NOT NULL,
    region_name text,
    name text NOT NULL,
    center_lat numeric(9,6),
    center_lon numeric(9,6),
    UNIQUE (country_code, region_name, name)
);

CREATE TABLE IF NOT EXISTS profiles (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    display_name text NOT NULL,
    birth_date date NOT NULL,
    latin_name text,
    city_id uuid REFERENCES cities(city_id),
    about text,
    friendship_goals jsonb NOT NULL DEFAULT '[]'::jsonb,
    interests jsonb NOT NULL DEFAULT '[]'::jsonb,
    values_profile jsonb NOT NULL DEFAULT '[]'::jsonb,
    lifestyle_profile jsonb NOT NULL DEFAULT '[]'::jsonb,
    boundaries jsonb NOT NULL DEFAULT '{}'::jsonb,
    visibility text NOT NULL DEFAULT 'discoverable' CHECK (visibility IN ('discoverable', 'connections', 'private')),
    completed_profile_sections smallint NOT NULL DEFAULT 0 CHECK (completed_profile_sections BETWEEN 0 AND 10),
    locale text NOT NULL DEFAULT 'ru' CHECK (locale ~ '^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$'),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS profiles_city_visibility_idx ON profiles(city_id, visibility);

CREATE TABLE IF NOT EXISTS profile_avatars (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    content_type text NOT NULL CHECK (content_type IN ('image/jpeg','image/png','image/webp')),
    image_bytes bytea NOT NULL CHECK (octet_length(image_bytes) BETWEEN 1 AND 512000),
    sha256 char(64) NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS personality_profiles (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    brotherhood32_code char(5) CHECK (brotherhood32_code ~ '^[ER][PV][LH][SF][GA]$'),
    brotherhood32_scores jsonb NOT NULL DEFAULT '{}'::jsonb,
    enneagram_type smallint CHECK (enneagram_type BETWEEN 1 AND 9),
    enneagram_wing smallint CHECK (enneagram_wing BETWEEN 1 AND 9),
    zodiac_sign text,
    vedic_numerology jsonb NOT NULL DEFAULT '{}'::jsonb,
    model_version text NOT NULL DEFAULT '0.5.7',
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assessment_results (
    result_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    assessment_code text NOT NULL CHECK (assessment_code ~ '^f[0-9]{3}$'),
    assessment_version text NOT NULL,
    scores jsonb NOT NULL,
    answer_consistency smallint CHECK (answer_consistency BETWEEN 0 AND 100),
    idealized_self_presentation smallint CHECK (idealized_self_presentation BETWEEN 0 AND 100),
    visibility text NOT NULL DEFAULT 'private' CHECK (visibility IN ('private', 'compatibility', 'public')),
    completed_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (global_id, assessment_code, assessment_version)
);
CREATE INDEX IF NOT EXISTS assessment_results_global_id_idx ON assessment_results(global_id);

CREATE TABLE IF NOT EXISTS communities (
    community_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_global_id bigint NOT NULL REFERENCES users(global_id),
    kind community_kind NOT NULL,
    title text NOT NULL,
    category text NOT NULL,
    city_id uuid REFERENCES cities(city_id),
    is_online boolean NOT NULL DEFAULT false,
    verified_only boolean NOT NULL DEFAULT false,
    description text NOT NULL,
    rules text,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS communities_kind_city_idx ON communities(kind, city_id);

CREATE TABLE IF NOT EXISTS community_members (
    community_id uuid NOT NULL REFERENCES communities(community_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    role text NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'moderator', 'member')),
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'muted', 'removed', 'left')),
    joined_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (community_id, global_id)
);

CREATE TABLE IF NOT EXISTS connections (
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'blocked', 'ended')),
    requested_by bigint NOT NULL REFERENCES users(global_id),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (first_global_id, second_global_id),
    CHECK (first_global_id < second_global_id),
    CHECK (requested_by IN (first_global_id, second_global_id))
);

CREATE TABLE IF NOT EXISTS verified_interactions (
    interaction_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    first_global_id bigint NOT NULL REFERENCES users(global_id),
    second_global_id bigint NOT NULL REFERENCES users(global_id),
    interaction_type text NOT NULL,
    verification_data jsonb NOT NULL DEFAULT '{}'::jsonb,
    verified_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id)
);

CREATE TABLE IF NOT EXISTS friendship_compatibility_snapshots (
    snapshot_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    common_test_count smallint NOT NULL CHECK (common_test_count BETWEEN 0 AND 100),
    breakdown jsonb NOT NULL,
    final_score smallint NOT NULL CHECK (final_score BETWEEN 0 AND 100),
    confidence smallint NOT NULL CHECK (confidence BETWEEN 0 AND 100),
    calculated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id)
);

CREATE TABLE IF NOT EXISTS trust_incidents (
    incident_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_global_id bigint NOT NULL REFERENCES users(global_id),
    subject_global_id bigint NOT NULL REFERENCES users(global_id),
    category text NOT NULL,
    occurred_at timestamptz NOT NULL,
    description_ciphertext bytea NOT NULL,
    status incident_status NOT NULL DEFAULT 'pending',
    score_impact smallint NOT NULL DEFAULT 0 CHECK (score_impact BETWEEN -100 AND 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (reporter_global_id <> subject_global_id)
);
CREATE INDEX IF NOT EXISTS trust_incidents_subject_status_idx ON trust_incidents(subject_global_id, status);

CREATE TABLE IF NOT EXISTS incident_evidence (
    evidence_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id uuid NOT NULL REFERENCES trust_incidents(incident_id) ON DELETE CASCADE,
    storage_key text NOT NULL,
    content_hash text NOT NULL,
    encrypted_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS moderation_decisions (
    decision_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id uuid NOT NULL REFERENCES trust_incidents(incident_id) ON DELETE CASCADE,
    moderator_global_id bigint NOT NULL REFERENCES users(global_id),
    decision incident_status NOT NULL,
    rationale text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS appeals (
    appeal_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id uuid NOT NULL REFERENCES trust_incidents(incident_id) ON DELETE CASCADE,
    appellant_global_id bigint NOT NULL REFERENCES users(global_id),
    grounds text NOT NULL,
    status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
    created_at timestamptz NOT NULL DEFAULT now()
);

-- Chat Core v0.5.8. Direct chats are E2EE: Vercel/Neon store only ciphertext and public key material.
-- Group/community chats use server-side encryption so moderation and multi-member history remain available.
CREATE TABLE IF NOT EXISTS device_keys (
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    device_id text NOT NULL,
    identity_public_key_b64 text NOT NULL,
    prekey_id text NOT NULL,
    prekey_public_key_b64 text NOT NULL,
    prekey_signature_b64 text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    revoked_at timestamptz,
    PRIMARY KEY (global_id, device_id)
);
CREATE INDEX IF NOT EXISTS device_keys_active_idx ON device_keys(global_id, updated_at DESC) WHERE revoked_at IS NULL;

CREATE TABLE IF NOT EXISTS conversations (
    conversation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_type text NOT NULL DEFAULT 'direct' CHECK (conversation_type IN ('direct', 'group', 'community')),
    title text,
    owner_global_id bigint REFERENCES users(global_id),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS conversation_members (
    conversation_id uuid NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    role text NOT NULL DEFAULT 'member' CHECK (role IN ('owner','admin','member')),
    joined_at timestamptz NOT NULL DEFAULT now(),
    last_read_message_id uuid,
    muted_until timestamptz,
    PRIMARY KEY (conversation_id, global_id)
);
CREATE INDEX IF NOT EXISTS conversation_members_global_idx ON conversation_members(global_id, conversation_id);

CREATE TABLE IF NOT EXISTS messages (
    message_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id uuid NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    sender_global_id bigint NOT NULL REFERENCES users(global_id),
    client_message_id text NOT NULL,
    message_type text NOT NULL DEFAULT 'text' CHECK (message_type IN ('text','media','system','edit')),
    encryption_mode text NOT NULL DEFAULT 'server' CHECK (encryption_mode IN ('e2ee','server')),
    -- group/community plaintext is encrypted at rest with MESSAGE_ENCRYPTION_KEY
    body_ciphertext bytea,
    -- direct chat ciphertext is created on Android; server cannot decrypt it
    e2ee_ciphertext bytea,
    e2ee_nonce bytea,
    key_id text,
    ratchet_counter bigint,
    sender_ephemeral_public_key_b64 text,
    recipient_prekey_id text,
    reply_to_message_id uuid REFERENCES messages(message_id) ON DELETE SET NULL,
    status text NOT NULL DEFAULT 'sent' CHECK (status IN ('queued', 'sent', 'delivered', 'read', 'deleted')),
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at timestamptz,
    deleted_at timestamptz,
    UNIQUE (sender_global_id, client_message_id),
    CHECK (
      (encryption_mode='e2ee' AND e2ee_ciphertext IS NOT NULL AND e2ee_nonce IS NOT NULL AND body_ciphertext IS NULL)
      OR
      (encryption_mode='server' AND e2ee_ciphertext IS NULL)
    )
);
CREATE INDEX IF NOT EXISTS messages_conversation_created_idx ON messages(conversation_id, created_at DESC);

CREATE TABLE IF NOT EXISTS message_attachments (
    attachment_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id uuid NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    client_attachment_id text NOT NULL,
    kind text NOT NULL CHECK (kind IN ('image','audio','video','file')),
    mime_type text NOT NULL,
    file_name text NOT NULL,
    byte_size bigint NOT NULL CHECK (byte_size > 0 AND byte_size <= 4000000),
    encryption_mode text NOT NULL CHECK (encryption_mode IN ('e2ee','server')),
    data_ciphertext bytea NOT NULL,
    nonce_b64 text,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE(message_id, client_attachment_id)
);
CREATE INDEX IF NOT EXISTS message_attachments_message_idx ON message_attachments(message_id, created_at);

CREATE TABLE IF NOT EXISTS message_reactions (
    message_id uuid NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    emoji text NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 16),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(message_id, global_id, emoji)
);
CREATE INDEX IF NOT EXISTS message_reactions_message_idx ON message_reactions(message_id, created_at);

CREATE TABLE IF NOT EXISTS conversation_typing (
    conversation_id uuid NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    expires_at timestamptz NOT NULL,
    PRIMARY KEY(conversation_id, global_id)
);
CREATE INDEX IF NOT EXISTS conversation_typing_expires_idx ON conversation_typing(expires_at);

CREATE TABLE IF NOT EXISTS message_receipts (
    message_id uuid NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    delivered_at timestamptz,
    read_at timestamptz,
    PRIMARY KEY(message_id, global_id)
);

CREATE TABLE IF NOT EXISTS user_blocks (
    blocker_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    blocked_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(blocker_global_id, blocked_global_id),
    CHECK (blocker_global_id <> blocked_global_id)
);
CREATE INDEX IF NOT EXISTS user_blocks_blocked_idx ON user_blocks(blocked_global_id, created_at);

CREATE TABLE IF NOT EXISTS push_tokens (
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    device_id text NOT NULL,
    provider text NOT NULL DEFAULT 'fcm',
    token_ciphertext bytea NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(global_id, device_id, provider)
);

CREATE TABLE IF NOT EXISTS device_sync_state (
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    device_id text NOT NULL,
    last_sync_cursor text,
    last_successful_sync_at timestamptz,
    app_version text,
    locale text,
    PRIMARY KEY (global_id, device_id)
);

-- Longitudinal compatibility outcomes for internal statistical calibration only.

CREATE TABLE IF NOT EXISTS friendship_outcomes (
    connection_id text PRIMARY KEY,
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    matched_at timestamptz NOT NULL,
    layer_scores jsonb NOT NULL CHECK (jsonb_typeof(layer_scores) = 'object'),
    searcher_global_id bigint REFERENCES users(global_id) ON DELETE SET NULL,
    search_role text CHECK (search_role IS NULL OR search_role IN ('friend','close_friend','business_partner','director','project_teammate','mentor','activity_partner','custom')),
    desired_qualities jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(desired_qualities) = 'object'),
    quality_fit_score smallint CHECK (quality_fit_score IS NULL OR quality_fit_score BETWEEN 0 AND 100),
    quality_fit_confidence smallint CHECK (quality_fit_confidence IS NULL OR quality_fit_confidence BETWEEN 0 AND 100),
    quality_model_version text,
    still_active_30d boolean,
    still_active_90d boolean,
    ended_reason text CHECK (ended_reason IS NULL OR ended_reason IN ('block','report','silent_fade','mutual_end','other')),
    messages_exchanged_30d integer CHECK (messages_exchanged_30d IS NULL OR messages_exchanged_30d >= 0),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id)
);
CREATE INDEX IF NOT EXISTS friendship_outcomes_90d_idx
    ON friendship_outcomes(still_active_90d, matched_at)
    WHERE still_active_90d IS NOT NULL;
CREATE INDEX IF NOT EXISTS friendship_outcomes_pair_idx
    ON friendship_outcomes(first_global_id, second_global_id, matched_at DESC);
CREATE INDEX IF NOT EXISTS friendship_outcomes_quality_fit_90d_idx
    ON friendship_outcomes(quality_model_version, still_active_90d, quality_fit_score)
    WHERE quality_fit_score IS NOT NULL AND still_active_90d IS NOT NULL;

-- Server-side canonical account rating: 50 profile points + 50 test points.
CREATE OR REPLACE VIEW account_ratings AS
SELECT
    u.global_id,
    global_id_display(u.global_id) AS global_id_display,
    LEAST(50.0, COALESCE(p.completed_profile_sections, 0) * 5.0) AS profile_points,
    LEAST(50.0, COUNT(DISTINCT ar.assessment_code) FILTER (WHERE ar.assessment_version='scientific-questionnaire-v1' AND ar.assessment_code IN ('traits_core','interpersonal_style','communication_conflict','trust_support_boundaries','decision_work_style','social_group_role','adaptability_uncertainty')) * (50.0/7.0)) AS test_points,
    LEAST(100.0,
        COALESCE(p.completed_profile_sections, 0) * 5.0 +
        COUNT(DISTINCT ar.assessment_code) FILTER (WHERE ar.assessment_version='scientific-questionnaire-v1' AND ar.assessment_code IN ('traits_core','interpersonal_style','communication_conflict','trust_support_boundaries','decision_work_style','social_group_role','adaptability_uncertainty')) * (50.0/7.0)
    ) AS total_rating
FROM users u
LEFT JOIN profiles p ON p.global_id = u.global_id
LEFT JOIN assessment_results ar ON ar.global_id = u.global_id
GROUP BY u.global_id, p.completed_profile_sections;

-- Cycle 0003 production auth/session hardening.
ALTER TABLE auth_sessions
    ADD COLUMN IF NOT EXISTS refresh_token_hash bytea,
    ADD COLUMN IF NOT EXISTS refresh_expires_at timestamptz,
    ADD COLUMN IF NOT EXISTS device_id text,
    ADD COLUMN IF NOT EXISTS last_used_at timestamptz;
CREATE UNIQUE INDEX IF NOT EXISTS auth_sessions_refresh_token_hash_idx ON auth_sessions(refresh_token_hash) WHERE refresh_token_hash IS NOT NULL;

CREATE TABLE IF NOT EXISTS auth_email_challenges (
    challenge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email_normalized text NOT NULL,
    code_hash bytea NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    attempts smallint NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 10),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_email_challenges_lookup_idx ON auth_email_challenges(email_normalized, expires_at DESC) WHERE consumed_at IS NULL;

CREATE TABLE IF NOT EXISTS passkey_credentials (
    credential_id bytea PRIMARY KEY,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    public_key bytea NOT NULL,
    sign_count bigint NOT NULL DEFAULT 0 CHECK (sign_count >= 0),
    transports jsonb NOT NULL DEFAULT '[]'::jsonb,
    device_type text,
    backed_up boolean NOT NULL DEFAULT false,
    revoked_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_used_at timestamptz
);
CREATE INDEX IF NOT EXISTS passkey_credentials_global_id_idx ON passkey_credentials(global_id);

CREATE TABLE IF NOT EXISTS passkey_challenges (
    challenge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint REFERENCES users(global_id) ON DELETE CASCADE,
    kind text NOT NULL CHECK (kind IN ('registration', 'authentication')),
    challenge bytea NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS passkey_challenges_active_idx ON passkey_challenges(kind, expires_at) WHERE consumed_at IS NULL;

CREATE TABLE IF NOT EXISTS user_settings (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    locale text NOT NULL DEFAULT 'ru',
    theme text NOT NULL DEFAULT 'system' CHECK (theme IN ('system','light','dark')),
    profile_visibility text NOT NULL DEFAULT 'discoverable' CHECK (profile_visibility IN ('discoverable','connections','private')),
    preferences jsonb NOT NULL DEFAULT '{}'::jsonb,
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS auth_oidc_challenges (
    challenge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    provider auth_provider NOT NULL,
    state_hash bytea NOT NULL UNIQUE,
    code_verifier text NOT NULL,
    nonce text NOT NULL,
    redirect_uri text NOT NULL,
    device_id text NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_oidc_challenges_active_idx
    ON auth_oidc_challenges(provider, expires_at)
    WHERE consumed_at IS NULL;

CREATE INDEX IF NOT EXISTS user_identities_verified_email_idx
    ON user_identities(email_normalized, global_id)
    WHERE email_normalized IS NOT NULL AND verified_at IS NOT NULL;


CREATE TABLE IF NOT EXISTS auth_login_tickets (
    ticket_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_hash BYTEA NOT NULL UNIQUE,
    global_id BIGINT NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    provider auth_provider NOT NULL,
    device_id TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_login_tickets_active_idx ON auth_login_tickets(expires_at) WHERE consumed_at IS NULL;


-- Cycle 0020 Hospitality foundation / backend lifecycle.
-- Brotherhood cycle 0020: Hospitality foundation and backend lifecycle.
-- Hospitality reuses canonical global_id, conversations, user_blocks, trust_incidents and account_ratings.
-- Exact arrival/location data is stored only as application-level AEAD ciphertext.

CREATE TABLE IF NOT EXISTS hospitality_host_profiles (
    host_global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    is_hosting_active boolean NOT NULL DEFAULT false,
    max_guests smallint NOT NULL CHECK (max_guests > 0),
    max_days smallint NOT NULL CHECK (max_days > 0),
    city_id uuid NOT NULL REFERENCES cities(city_id),
    public_area_text text,
    timezone_name text NOT NULL,
    sleeping_condition text NOT NULL CHECK (sleeping_condition IN ('private_room','shared_room','sofa','entire_space')),
    house_rules jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(house_rules) = 'array'),
    min_required_rating numeric(5,2) NOT NULL DEFAULT 0 CHECK (min_required_rating BETWEEN 0 AND 100),
    required_completed_tests text[] NOT NULL DEFAULT '{}',
    availability_mode text NOT NULL DEFAULT 'always' CHECK (availability_mode IN ('always','calendar')),
    private_location_ciphertext bytea NOT NULL,
    private_location_nonce bytea NOT NULL,
    private_location_key_version smallint NOT NULL CHECK (private_location_key_version > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hospitality_host_active_city_idx
    ON hospitality_host_profiles(city_id, is_hosting_active);

CREATE TABLE IF NOT EXISTS hospitality_availability (
    availability_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    host_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    date_from date NOT NULL,
    date_to date NOT NULL,
    availability_state text NOT NULL CHECK (availability_state IN ('available','unavailable')),
    capacity_override smallint CHECK (capacity_override IS NULL OR capacity_override > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (date_to > date_from)
);
CREATE INDEX IF NOT EXISTS hospitality_availability_host_dates_idx
    ON hospitality_availability(host_global_id, date_from, date_to);

CREATE TABLE IF NOT EXISTS stay_requests (
    request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    guest_global_id bigint NOT NULL REFERENCES users(global_id),
    host_global_id bigint NOT NULL REFERENCES users(global_id),
    check_in_date date NOT NULL,
    check_out_date date NOT NULL,
    guests_count smallint NOT NULL CHECK (guests_count > 0),
    status text NOT NULL DEFAULT 'pending' CHECK (status IN (
        'pending','accepted','rejected','cancelled_by_guest','cancelled_by_host','completed','expired'
    )),
    response_due_at timestamptz NOT NULL,
    conversation_id uuid REFERENCES conversations(conversation_id),
    eligibility_snapshot jsonb NOT NULL CHECK (jsonb_typeof(eligibility_snapshot) = 'object'),
    create_idempotency_key text NOT NULL,
    rejection_reason text,
    cancellation_reason text,
    accepted_at timestamptz,
    completed_at timestamptz,
    arrival_details_ciphertext bytea,
    arrival_details_nonce bytea,
    arrival_details_key_version smallint,
    private_access_expires_at timestamptz,
    review_deadline_at timestamptz,
    version integer NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (guest_global_id <> host_global_id),
    CHECK (check_out_date > check_in_date),
    UNIQUE (guest_global_id, create_idempotency_key)
);
CREATE INDEX IF NOT EXISTS stay_requests_host_status_dates_idx
    ON stay_requests(host_global_id, status, check_in_date, check_out_date);
CREATE INDEX IF NOT EXISTS stay_requests_guest_status_dates_idx
    ON stay_requests(guest_global_id, status, check_in_date, check_out_date);
CREATE INDEX IF NOT EXISTS stay_requests_pending_due_idx
    ON stay_requests(response_due_at) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS stay_requests_completed_review_idx
    ON stay_requests(review_deadline_at) WHERE status = 'completed';

CREATE TABLE IF NOT EXISTS hospitality_request_events (
    event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    conversation_id uuid NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    actor_global_id bigint REFERENCES users(global_id),
    event_type text NOT NULL CHECK (event_type IN (
        'request_created','request_accepted','request_rejected','request_cancelled_by_guest',
        'request_cancelled_by_host','request_expired','stay_completed','reviews_opened',
        'reviews_published','hospitality_restriction_applied'
    )),
    public_payload jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(public_payload) = 'object'),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hospitality_request_events_request_idx
    ON hospitality_request_events(request_id, created_at);

CREATE TABLE IF NOT EXISTS hospitality_private_access_audit (
    audit_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    viewer_global_id bigint NOT NULL REFERENCES users(global_id),
    granted boolean NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hospitality_private_access_audit_request_idx
    ON hospitality_private_access_audit(request_id, created_at);

CREATE TABLE IF NOT EXISTS hospitality_stay_confirmations (
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id),
    confirmation text NOT NULL CHECK (confirmation IN ('stay_occurred','no_show','dispute')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (request_id, global_id)
);

CREATE TABLE IF NOT EXISTS stay_reviews (
    review_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    author_global_id bigint NOT NULL REFERENCES users(global_id),
    target_global_id bigint NOT NULL REFERENCES users(global_id),
    adequacy smallint NOT NULL CHECK (adequacy BETWEEN 1 AND 5),
    rules_compliance smallint NOT NULL CHECK (rules_compliance BETWEEN 1 AND 5),
    description_accuracy smallint NOT NULL CHECK (description_accuracy BETWEEN 1 AND 5),
    review_score numeric(5,2) NOT NULL CHECK (review_score BETWEEN 0 AND 100),
    review_contract_version text NOT NULL,
    review_text text,
    private_feedback_ciphertext bytea,
    private_feedback_nonce bytea,
    private_feedback_key_version smallint,
    submitted_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz,
    moderated_at timestamptz,
    UNIQUE (request_id, author_global_id),
    CHECK (author_global_id <> target_global_id)
);
CREATE INDEX IF NOT EXISTS stay_reviews_target_published_idx
    ON stay_reviews(target_global_id, published_at);

CREATE TABLE IF NOT EXISTS hospitality_restrictions (
    restriction_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id),
    scope text NOT NULL CHECK (scope IN ('guest','host','all')),
    source_incident_id uuid NOT NULL REFERENCES trust_incidents(incident_id),
    reason_code text NOT NULL,
    starts_at timestamptz NOT NULL,
    ends_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (ends_at IS NULL OR ends_at > starts_at)
);
CREATE INDEX IF NOT EXISTS hospitality_restrictions_active_idx
    ON hospitality_restrictions(global_id, starts_at, ends_at);
-- Brotherhood cycle 0021: Hospitality verified-stay/review due-process hardening.
-- Does not alter owner-locked assessment or Compatibility semantics.

CREATE UNIQUE INDEX IF NOT EXISTS verified_interactions_hospitality_request_uidx
ON verified_interactions ((verification_data->>'request_id'))
WHERE interaction_type = 'hospitality_stay' AND verification_data ? 'request_id';

CREATE UNIQUE INDEX IF NOT EXISTS appeals_incident_appellant_pending_uidx
ON appeals (incident_id, appellant_global_id)
WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS moderation_decisions_incident_created_idx
ON moderation_decisions (incident_id, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS hospitality_restrictions_incident_scope_uidx
ON hospitality_restrictions (source_incident_id, scope);

-- Cycle 0024: immutable Psychological Report history + Q28 compatibility selection persistence.
-- Exact mirror of database/migrations/0011_psychological_reports_independent_compatibility.sql.
-- Raw visual response traces are intentionally excluded from psychological_reports.input_snapshot.
CREATE TABLE IF NOT EXISTS psychological_reports (
    report_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    report_version text NOT NULL,
    model_version text NOT NULL,
    generated_at timestamptz NOT NULL,
    input_snapshot_hash char(64) NOT NULL CHECK (input_snapshot_hash ~ '^[0-9a-f]{64}$'),
    input_snapshot jsonb NOT NULL CHECK (jsonb_typeof(input_snapshot) = 'array'),
    coverage_percent smallint NOT NULL CHECK (coverage_percent BETWEEN 0 AND 100),
    report_document jsonb NOT NULL CHECK (jsonb_typeof(report_document) = 'object'),
    persisted_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (global_id, report_version, input_snapshot_hash)
);
CREATE INDEX IF NOT EXISTS psychological_reports_global_generated_idx
    ON psychological_reports(global_id, generated_at DESC, persisted_at DESC);

CREATE TABLE IF NOT EXISTS compatibility_metric_preferences (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    contract_version text NOT NULL DEFAULT 'independent-compatibility-v1',
    selected_metrics jsonb NOT NULL CHECK (jsonb_typeof(selected_metrics) = 'array'),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Cycle 0026: first-class persistent Search Requests.
-- Search requests are explicit user intent and Quality Fit inputs; they never expose private latent traits.
CREATE TABLE IF NOT EXISTS search_requests (
    search_request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 120),
    role text NOT NULL CHECK (char_length(role) BETWEEN 2 AND 80),
    desired_qualities jsonb NOT NULL DEFAULT '[]'::jsonb,
    city text,
    radius_km smallint NOT NULL DEFAULT 25 CHECK (radius_km BETWEEN 5 AND 500),
    min_trust smallint NOT NULL DEFAULT 0 CHECK (min_trust BETWEEN 0 AND 100),
    min_compatibility smallint NOT NULL DEFAULT 0 CHECK (min_compatibility BETWEEN 0 AND 100),
    online_only boolean NOT NULL DEFAULT false,
    verified_only boolean NOT NULL DEFAULT false,
    hospitality_only boolean NOT NULL DEFAULT false,
    notes text CHECK (notes IS NULL OR char_length(notes) <= 1000),
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','archived')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (jsonb_typeof(desired_qualities) = 'array')
);
CREATE INDEX IF NOT EXISTS search_requests_owner_status_updated_idx
    ON search_requests(owner_global_id, status, updated_at DESC);


-- Cycle 0033: Quality Fit / SearchIntent v2.
ALTER TABLE search_requests
    ADD COLUMN IF NOT EXISTS requirements jsonb NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS quality_fit_version text NOT NULL DEFAULT 'quality-fit-search-intent-v2';

CREATE TABLE IF NOT EXISTS quality_fit_evaluations (
    evaluation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    searcher_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    candidate_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    search_request_id uuid REFERENCES search_requests(search_request_id) ON DELETE SET NULL,
    role_context text NOT NULL CHECK (char_length(role_context) BETWEEN 2 AND 80),
    contract_version text NOT NULL,
    catalog_version text NOT NULL,
    scoring_version text NOT NULL,
    intent_snapshot_hash char(64) NOT NULL CHECK (intent_snapshot_hash ~ '^[0-9a-f]{64}$'),
    candidate_evidence_hash char(64) NOT NULL CHECK (candidate_evidence_hash ~ '^[0-9a-f]{64}$'),
    score smallint CHECK (score IS NULL OR score BETWEEN 0 AND 100),
    confidence smallint NOT NULL CHECK (confidence BETWEEN 0 AND 100),
    availability text NOT NULL CHECK (availability IN ('AVAILABLE','PARTIAL','INSUFFICIENT_DATA','HARD_REQUIREMENT_NOT_MET')),
    eligible boolean NOT NULL,
    evaluation_payload jsonb NOT NULL CHECK (jsonb_typeof(evaluation_payload) = 'object'),
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (searcher_global_id <> candidate_global_id),
    UNIQUE (searcher_global_id,candidate_global_id,intent_snapshot_hash,candidate_evidence_hash,scoring_version)
);
CREATE INDEX IF NOT EXISTS quality_fit_evaluations_searcher_created_idx ON quality_fit_evaluations(searcher_global_id, created_at DESC);
CREATE INDEX IF NOT EXISTS quality_fit_evaluations_candidate_created_idx ON quality_fit_evaluations(candidate_global_id, created_at DESC);
