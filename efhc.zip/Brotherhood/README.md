# Current development authority — cycle 0030

> Current DEVELOPMENT target: `Brotherhood_v0_5_70.zip`, cycle 0030 source/backend/Simulation/HTML implemented, owner visual acceptance pending. Root IA is `Профиль → Люди → Чаты → Группы → Развитие`. Active psychology is 12 user-facing tests / 7 scientific systems / 197 questionnaire items plus associative/implicit methods; the historical 100×6 visual bank and former blocking-protection model described deeper in this README are superseded and are not active product authority. Current simulator contract: 114 OpenAPI paths / 133 HTTP operations / 54 DB tables / 21 Android AppRoutes.

# Brotherhood v0.5.32 runtime / v0.5.40-cycle0011

> Revision **v0.5.40-cycle0011**: Business Partner Compatibility Science completed as research/documentation work; Android runtime remains **v0.5.32 / versionCode 37** and protected 100×6 mechanics/scoring remain unchanged. User-facing archive naming now follows clean sequential `Brotherhood_v0_5_NN.zip` CANON.

> Critical recovery: the actual APK assessment core is hash-identical to the approved v0.5.27 baseline. The regression was the standalone demo replacing release visual assessments with primitive text choices/fake scoring. v0.5.31 restores release-parity visual assessment simulation and adds a blocking protected-mechanics hash guard.

> v0.5.31 restoration/protected-mechanics milestone: Brotherhood is a male-only 18+ social/business club and people marketplace. Authenticated Home is calm and exposes four primary actions: `Поиск людей`, `Сообщения`, `Тесты`, `Поисковые запросы`. Dating-like candidate cards/swipes are confined to recommended discovery. DEBUG/offline data passes through `DemoBackendSimulator → DemoSimulationEngine`; the standalone workbench mirrors `BackendSimulator → SimulationEngine → frontend`.

Мужское Android-приложение 18+ для поиска друзей, деловых и проектных партнёров, специалистов/работников, наставников и людей для совместной деятельности. Романтические знакомства и поиск девушек не входят в продукт; скрытые психометрические данные используются алгоритмами подбора и не публикуются как тип личности кандидата.

## Cycle 0002 source milestone v0.5.23

- Home/Profile/Self-analysis показывают накопленный положительный профиль, последнее открытие, следующий шаг, полезные контексты и историю без раскрытия latent scoring.
- People сохраняет раздельные Compatibility/Quality Fit и получает читаемые narrow-screen CTA; Groups быстрее показывают тип, формат и действие.
- Language selector остаётся data-driven и теперь использует канонический набор 13 locales (`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`); исправленные runtime-error paths не падают в скрытый русский fallback и не показывают raw exception text.
- Settings всегда честно объясняет manual Development APK install; controlled pilot остаётся сворачиваемым.
- Source milestone имеет только source/local evidence до GitHub checkpoint A и реального APK screenshot acceptance.

## Канон UX-демо

Каждая UX/UI-итерация выдаётся парой: новый полный `Brotherhood.zip` + отдельный полностью автономный `BROTHERHOOD_UI_DEMO.html`. Активная копия demo обязательно находится и внутри архива по пути `tools/visual_checks/BROTHERHOOD_UI_DEMO.html`. Активный demo — один автономный HTML с inline CSS/JavaScript/PNG, нулевыми внешними ресурсами, live phone preview, технической рабочей областью и полной stateful-цепочкой `BackendSimulator → SimulationEngine → frontend mirror`. Нижняя пяти-вкладочная панель обязана оставаться частью корневого shell на всех аутентифицированных маршрутах. Dark/light должны быть полноценными семантическими темами, а не инверсией отдельных блоков.

## Канон архивов

- Текущий DEVELOPMENT source/archive revision: `Brotherhood_v0_5_40.zip` (Android runtime `v0.5.32 / code37`).
- Последний runtime/build release-source archive остаётся `Brotherhood_v0_5_31_RELEASE.zip` до следующего runtime change.
- Полный GitHub-пакет: `Brotherhood.zip`.
- Внутри любого выдаваемого ZIP верхняя папка всегда `Brotherhood/`.
- Канонический источник: распакованный код в GitHub.
- Единственный универсальный GitHub workflow распаковывает `Brotherhood.zip`, извлекает фактическую версию и собирает APK без изменения YAML между релизами.


## Бренд, профиль и поиск v0.5.20

- канонический логотип Brotherhood — PNG-эталон `brand/logo_brotherhood.png` (1536×1536, SHA-256 `47657ba1a1f9dd99cb9b275ea485b8bfdf3a5ac19de33f5187934eaf3b573e19`);
- логотип строго квадратный: Auth 96dp и TopAppBar 38dp без clip; приложение поставляет только квадратные launcher PNG-ресурсы, без `roundIcon`, adaptive-mask и themed monochrome; Android 12+ system splash не показывает логотип, чтобы системная круглая маска не обрезала квадратный эталон;
- вкладка «Люди» получила Quick Discovery: один кандидат за раз, пропуск, возврат последнего пропуска, подробная совместимость и запрос дружбы;
- добавлены реальные фильтры: verified-only, online-only, общий интерес, минимальный Trust, минимальная совместимость и скрытие уже запрошенных профилей;
- профиль может быть `discoverable`, `connections` или `private`; режим синхронизируется с backend;
- поиск другого города используется как Passport mode без изменения домашнего города профиля;
- в профиле добавлена статистика запросов, чатов и групп.

## Продукт

## Текущая навигация и Home v0.5.31

Нижняя навигация: **Главная / Люди / Чаты / Группы / Профиль**. Она принадлежит корневому authenticated shell и не исчезает на вложенных страницах. Home намеренно не дублирует весь каталог функций и содержит четыре основных входа: **Поиск людей / Сообщения / Тесты / Поисковые запросы**. Результаты находятся внутри раздела `Тесты`. Остальные возможности доступны через профиль/соответствующие маршруты, не перегружая стартовую страницу.

Название приложения во всех локалях и Android launcher label: **Brotherhood**.


- только мужчины 18+;
- друзья, деловые/проектные партнёры, специалисты/работники, наставники и совместная деятельность;
- романтические знакомства и поиск девушек исключены;
- 100 психологических/поведенческих тестов / 600 непрямых визуально-ассоциативных заданий;
- Brotherhood-32: 32 типа личности по пяти осям;
- характер, образ жизни, ценности;
- эннеаграмма;
- зодиак;
- ведическая нумерология;
- скрытые cross-checks согласованности профиля только для алгоритмов;
- Trust Center;
- сообщества: футбол, спорт, автомобили, путешествия, технологии, бизнес и другие;
- география по городам;
- языки управляются единым data-driven registry; активный locale scope — 13 языков `sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`; structural key coverage включён для всех 13, а semantic/native QA и psychometric equivalence отслеживаются отдельными gates;
- светлая, чёрная и системная темы;
- `global_id`: `0000000001`, `0000000002`, …


## Совместимость — текущий канон

Brotherhood использует независимые metric engines: Psychology, Interests, Values, Communication, Lifestyle, Brotherhood Personality Type, Enneagram, Numerology, Astrology/Zodiac. Каждая метрика даёт свой `0..100`; пользователь выбирает галочки. Если выбрано несколько доступных метрик, optional overall = простое арифметическое среднее без межметрических весов.

`Quality Fit` отвечает на другой вопрос — насколько кандидат соответствует явному запросу пользователя. `Trust` и `Data Coverage` также отдельны и не входят в среднее. Научно-эмпирические, типологические и альтернативные модели маркируются раздельно.

Целевая научная база: `docs/research/compatibility/INDEX.md`. Текущий Android `HybridCompatibilityEngine.kt` ещё содержит legacy fixed-weight aggregate и является **known implementation gap**; он не объявляется соответствующим новому канону до отдельного implementation cycle.

### Научная программа

Visual assessment bank остаётся 100×6, но visual→latent связи являются гипотезами до собственной калибровки Brotherhood. Требуются reference calibration, psychometric validation, 13-locale invariance/DIF (`sw/ru/en/uk/de/fr/es/it/tr/pl/da/hi/id`), holdout/replication, dyadic and longitudinal outcomes. Freud/psychodynamic theory — historical motivation for indirectness, не scoring key.

### Скрытая визуально-ассоциативная психология v0.5.20

- активная модель: `visual-latent-v2`, stimulus provenance: `scene-library-v4`;
- библиотека содержит 48 нейтральных сценовых архетипов, 16 визуальных парадигм и 8 неоцениваемых композиционных вариантов;
- банк остаётся ровно 100 психологических/поведенческих тестов × 6 = 600 заданий;
- прямые вопросы о верности, честности, лидерстве, поддержке и других очевидных качествах удалены из канонического банка;
- пользователь выбирает между изображениями/композициями и не видит, какие латентные координаты измеряются;
- один выбор не является диагнозом: качества строятся из распределённых сигналов по множеству заданий;
- оба полюса каждой координаты имеют допустимую контекстную интерпретацию — универсально плохих качеств нет;
- старые direct-question результаты сохраняются только как история и не входят в `visual-latent-v2`;
- raw latent coordinates, cross-checks, response trace и consistency signals не выдаются обычным public API;
- приватный item-level response trace сохраняет точный stimulus/choice только для внутренней эмпирической калибровки и не меняет production-loadings автоматически.

### Quality Fit — подбор по качествам пользователя

Каталог v0.5.20 содержит 112 выбираемых качеств с legacy source-семантикой RU/UK/EN; это защищённый продуктовый каталог и не является доказательством трёхъязычного ограничения приложения. Полная 13-locale семантическая адаптация этого protected content остаётся отдельным явно отслеживаемым localization tail до разрешённого product-content цикла. Пользователь сам выбирает роль (друг, бизнес-партнёр, директор, участник проекта и т. п.) и нужные качества. Роль не добавляет скрытые default-качества. Новый Quality Fit сравнивает выбранные качества с приватным латентным профилем кандидата и остаётся отдельным от Compatibility, Trust и Account Completeness. Публично показываются только положительно сформулированные сильные стороны и соответствие запросу.

Controlled calibration pilot: сырые item-level traces сохраняются на сервере только при явном opt-in, отдельно от рабочего агрегированного профиля; withdrawal удаляет сырые попытки. `scene-library-v4` фиксирует presentation slot, latency, answer changes и question position для диагностики position/order bias. Outcome-анализ использует только pre-match assessments и никогда не меняет production-модель автоматически.

### Аватар

Пользователь может выбрать изображение через системный picker. APK копирует его в app-private storage, уменьшает до 768 px по длинной стороне, кодирует в bounded JPEG ≤512 KiB и синхронизирует через Vercel backend. Широкое разрешение на чтение медиатеки не добавляется.

## Чаты v0.5.20

- личные: E2EE v1, fingerprints и TOFU pinning;
- группы: не секретные, доступные серверной модерации, encrypted-at-rest;
- текст, фото, аудио, видео, файлы, голос через системный recorder;
- reply, reactions, typing, edit, delete, delivered/read receipts;
- блокировка/разблокировка и закрытая жалоба на собеседника;
- управление участниками группы владельцем;
- offline outbox/retry;
- серверный hook для FCM push-токенов (реальная доставка требует внешних Firebase credentials).

E2EE v1 использует стандартные криптографические примитивы, но является собственным протоколом Brotherhood и не заявляется эквивалентом Signal/Telegram Secret Chats до независимого аудита и multi-device hardening.

## Самоанализ

Раздел «Познание себя» объединяет пройденные тесты, сильные стороны, индивидуальные стили, Brotherhood-32, Enneagram, Zodiac и Vedic Numerology, чтобы приложение было полезно и вне активного поиска друзей.

## Рейтинг аккаунта

- 50% — 10 заполненных разделов профиля × 5%;
- 50% — 100 уникальных тестов × 0,5%.

Рейтинг заполненности не равен Trust Score. Ответы влияют на совместимость, подтверждённое поведение — на репутацию.


## Локализация v0.5.20

- один runtime-язык управляет навигацией, разделами, настройками, качествами поиска, визуальными сериями, результатами, Brotherhood-32, Enneagram, Zodiac, Vedic Numerology и серверными локализованными поверхностями;
- выбор языка реализован каруселью на входе и в настройках;
- `shared/locales/supported.json` — единый registry, Android использует его зеркальную копию;
- язык активируется только при полном coverage обязательных ключей и наличии нумерологического locale-блока;
- направление интерфейса (`ltr` / `rtl`) задаётся метаданными языка, поэтому будущие RTL-языки не требуют переписывания навигации;
- добавление нового языка не меняет Compatibility, Quality Fit или психологический scoring.
- встроенные города имеют стабильное search/storage значение и локализованное отображаемое название (`Киев` / `Київ` / `Kyiv`); пользовательские тексты и произвольные географические строки язык интерфейса не переписывает;
- текущий activation gate содержит 713 обязательных runtime-ключей; неполный language-pack не появляется в карусели.

## Runtime v0.5.20

### Android

В APK находятся:

- тесты и расчётные движки;
- Brotherhood-32 / Enneagram / Zodiac / Vedic Numerology;
- локальный профиль и настройки;
- SQLite cache;
- stale-while-revalidate;
- pending mutations;
- автоматический retry/flush очереди после восстановления сети;
- remote repository для пользователей и сообществ через Vercel API;
- demo-данные разрешены только в debug-сборке как тестовый fallback.

### Backend

```text
Android APK
    ↓ HTTPS + app session
Vercel FastAPI
    ↓
Neon PostgreSQL
```

При наличии `DATABASE_URL` backend автоматически использует PostgreSQL/Neon. In-memory storage оставлен только для unit tests и локальной разработки.

Реализованы server-side:

- последовательная выдача `global_id`;
- profiles;
- assessment results;
- communities;
- trust incidents;
- encrypted private trust description;
- personal direct chats: Android-side E2EE ciphertext only;
- group chats: server-visible for moderation, encrypted at rest;
- replies, reactions, typing, editing, sender deletion and delivery/read receipts;
- auth session hash;
- owner checks по session → global_id;
- internal identity/session bridge для provider adapters.

APK никогда не содержит `DATABASE_URL`, `TRUST_ENCRYPTION_KEY`, `MESSAGE_ENCRYPTION_KEY` или provider secrets.

## Авторизация

UI и каноническая identity-модель готовы для:

- Google;
- Telegram;
- Facebook;
- email;
- Passkey;
- будущих Apple / Microsoft / phone.

Для production Google/Telegram/Facebook требуются реальные Client/App IDs, redirect URLs и secrets в Vercel. Debug APK сохраняет тестовый вход для проверки интерфейса; release не должен создавать фиктивную provider identity.

Подробности: `docs/AUTH_AND_SESSION_BOUNDARY.md`.

## Материалы Песочницы

Проверены предоставленные источники. В проект перенесены только совместимые архитектурные решения; GPL/некоммерческие SDK и чужие изображения/шрифты не включаются.

Подробности: `docs/SANDBOX_SOURCE_INTEGRATION_v0_5_3.md`.

## GitHub Actions

- `.github/workflows/android-build.yml` — единственный универсальный Android workflow: проверяет `Brotherhood.zip`, извлекает фактическую версию, запускает тесты/сборку, валидирует APK и публикует artifact. После утверждения не меняется между релизами.

## Backend tests

```bash
cd backend
pip install -r requirements.txt
pytest -q
```

## Обновление внутреннего Brotherhood.zip

```bash
python scripts/package_source_archive.py --write Brotherhood.zip
python scripts/package_source_archive.py --check Brotherhood.zip
sha256sum Brotherhood.zip > Brotherhood.zip.sha256
```

Подробный канон: `docs/PROJECT_CANON_v0_5_4.md`.


Cycle 0004 Compatibility Research Foundation: COMPLETED (docs/research only).

Research revision: `v0.5.40-cycle0011` — Business Partner Compatibility Science complete. Runtime remains `v0.5.32 / versionCode 37`; protected 100×6 mechanics/scoring remain unchanged. Canonical locale architecture remains exactly 13 languages. Scientific registry = 108 sources; claim ledger = 58 claims; the original 60-source commercial-permission snapshot remains separate from 48 later citation/research additions. User-facing archive name: `Brotherhood_v0_5_40.zip`.


## Research milestone — Cycle 0010 Friendship Compatibility Science
Friendship role science now has a versioned formation/maintenance/dissolution model, outcome hierarchy, causal/confound plan, male-context boundary, privacy-safe longitudinal data contract and full 13-locale validation scope. Scientific Source Registry: 93; claim ledger: 45. No production scoring was promoted.

## Cycle 0012 — Worker / Team Fit Science
Research package: `docs/research/roles/worker_team/INDEX.md`. Psychology epistemic owner canon: `docs/CANON/BROTHERHOOD_PSYCHOLOGY_EPISTEMIC_CANON.md`. Runtime remains v0.5.32/code37; protected 100×6/scoring unchanged.


## Current compatibility research status
Cycle 0013 completed Mentor / Project Partner Compatibility. Q34 exact-score semantics are active: each approved model version returns a precise `0..100%` result for its inputs; later validated versions may change that precise result. Research/model uncertainty is handled in governance and versioning rather than repetitive user-facing disclaimers.

## Cycle 0014 — Interests Compatibility + Research Platform
Research-only IC v1/IC-R0 specifications are now canonical under `docs/research/compatibility/interests/`. Q35 adds `docs/CANON/BROTHERHOOD_RESEARCH_PLATFORM_CANON.md` and `docs/research/outcomes/`: Brotherhood can later collect explicit feedback, side-specific relationship statuses and longitudinal outcomes while preserving recommendation/exposure provenance. No backend/database telemetry or production auto-learning was activated in this cycle. Scientific registry = 141 sources; claim ledger = 92 claims. Runtime remains `v0.5.32 / versionCode 37`.


## Research milestone — Cycle 0015
Values Compatibility Engine is complete/hardened as research architecture: refined 19-value taxonomy, frozen historical `VC-R0`, explicit scoring/normalization/coverage policy, current transparent `VC-R0.1`, circular/RSA/role-specific challenger registry, exact 13-locale comparability plan and Q35 longitudinal outcome interface. Registry = 162 sources; claim ledger = 111; no Values production scoring is activated. Runtime remains `v0.5.32 / versionCode 37`.


### Cycle 0016 — Communication Compatibility
Research-only CC architecture is in `docs/research/compatibility/communication/`; current comparator `CC-R0` is not production active. Next major research cycle: `0017 — Lifestyle Compatibility Engine`.
