-- Brotherhood v0.5.17: controlled first-user calibration cohort.
-- Invite codes are validated against SHA-256 digests from runtime secrets and are never stored.

ALTER TABLE calibration_consents
    ADD COLUMN IF NOT EXISTS instrument_locale text NOT NULL DEFAULT 'ru',
    ADD COLUMN IF NOT EXISTS enrollment_state text NOT NULL DEFAULT 'withdrawn',
    ADD COLUMN IF NOT EXISTS pilot_wave text NOT NULL DEFAULT 'wave-1';

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'calibration_consents_enrollment_state_check'
    ) THEN
        ALTER TABLE calibration_consents
            ADD CONSTRAINT calibration_consents_enrollment_state_check
            CHECK (enrollment_state IN ('active', 'withdrawn'));
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS calibration_consents_cohort_locale_idx
    ON calibration_consents(cohort_id, pilot_wave, instrument_locale, opt_in);

-- Only the SHA-256 digest is retained to enforce one-use invitations. Plaintext codes never enter DB.
CREATE TABLE IF NOT EXISTS calibration_pilot_invite_redemptions (
    invite_sha256 text PRIMARY KEY CHECK (invite_sha256 ~ '^[0-9a-f]{64}$'),
    global_id bigint NOT NULL CHECK (global_id BETWEEN 1 AND 9999999999),
    cohort_id text NOT NULL,
    pilot_wave text NOT NULL,
    redeemed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS calibration_pilot_invite_redemptions_participant_idx
    ON calibration_pilot_invite_redemptions(global_id, cohort_id, pilot_wave);
