-- Cycle 0034: Secure Test Administration Runtime v1.
-- Keeps private item order, opaque per-item tokens and responses server-side.
CREATE TABLE IF NOT EXISTS assessment_administration_sessions (
    session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    assessment_id text NOT NULL,
    instrument_locale text NOT NULL,
    administration_version text NOT NULL,
    bank_version text NOT NULL,
    scoring_version text NOT NULL,
    instrument_version text NOT NULL,
    status text NOT NULL CHECK (status IN ('IN_PROGRESS','COMPLETED')),
    item_order jsonb NOT NULL CHECK (jsonb_typeof(item_order) = 'array'),
    item_tokens jsonb NOT NULL CHECK (jsonb_typeof(item_tokens) = 'object'),
    responses jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(responses) = 'object'),
    response_meta jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(response_meta) = 'object'),
    current_index integer NOT NULL DEFAULT 0 CHECK (current_index >= 0),
    started_at_epoch_ms bigint NOT NULL CHECK (started_at_epoch_ms > 0),
    updated_at_epoch_ms bigint NOT NULL CHECK (updated_at_epoch_ms > 0),
    completed_at_epoch_ms bigint,
    result_id text,
    session_payload jsonb NOT NULL CHECK (jsonb_typeof(session_payload) = 'object'),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assessment_admin_user_app_active_idx
    ON assessment_administration_sessions(global_id, assessment_id, updated_at DESC)
    WHERE status='IN_PROGRESS';
