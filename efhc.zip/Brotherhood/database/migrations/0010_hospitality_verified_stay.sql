-- Brotherhood cycle 0021: Hospitality verified-stay/review due-process hardening.
-- Does not alter owner-locked assessment or Compatibility semantics.

CREATE UNIQUE INDEX IF NOT EXISTS verified_interactions_hospitality_request_uidx
ON verified_interactions ((verification_data->>'request_id'))
WHERE interaction_type = 'hospitality_stay' AND verification_data ? 'request_id';

CREATE UNIQUE INDEX IF NOT EXISTS appeals_incident_appellant_pending_uidx
ON appeals (incident_id, appellant_global_id)
WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS moderation_decisions_incident_created_idx
ON moderation_decisions (incident_id, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS hospitality_restrictions_incident_scope_uidx
ON hospitality_restrictions (source_incident_id, scope);
