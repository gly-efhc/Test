-- Cycle 0032: standalone optional Enneagram application persistence.
-- EN remains independent, typological/experimental and does not alter PC/Trust/QF automatically.

CREATE TABLE IF NOT EXISTS enneagram_readings (
    reading_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    locale text NOT NULL,
    method_id text NOT NULL,
    instrument_version text NOT NULL,
    calculation_version text NOT NULL,
    compatibility_version text NOT NULL,
    catalog_version text NOT NULL,
    answers_snapshot_hash char(64) NOT NULL CHECK (answers_snapshot_hash ~ '^[0-9a-f]{64}$'),
    reading_payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS enneagram_readings_global_history_idx
    ON enneagram_readings(global_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS enneagram_readings_idempotent_snapshot_idx
    ON enneagram_readings(global_id, answers_snapshot_hash, instrument_version, calculation_version);

CREATE TABLE IF NOT EXISTS enneagram_pair_comparisons (
    comparison_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    compatibility_version text NOT NULL,
    score smallint NOT NULL CHECK (score BETWEEN 0 AND 100),
    comparison_payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id)
);
CREATE INDEX IF NOT EXISTS enneagram_pair_history_first_idx
    ON enneagram_pair_comparisons(first_global_id, created_at DESC);
CREATE INDEX IF NOT EXISTS enneagram_pair_history_second_idx
    ON enneagram_pair_comparisons(second_global_id, created_at DESC);
