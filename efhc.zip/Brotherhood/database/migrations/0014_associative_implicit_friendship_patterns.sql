-- Cycle 0029: associative/implicit measurement persistence + reverse friendship pattern research snapshots.
-- Raw association events are private measurement data. Reverse-pattern observations are descriptive research evidence;
-- they never mutate production matching automatically.

CREATE TABLE IF NOT EXISTS associative_measurement_results (
    result_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    method_id text NOT NULL CHECK (method_id IN ('WORD_ASSOCIATION_V1','ASSOCIATIVE_FREE_CHAIN_V1','IMPLICIT_ASSOCIATION_RT_V1')),
    instrument_version text NOT NULL,
    scoring_version text NOT NULL,
    instrument_locale text NOT NULL,
    started_at_epoch_ms bigint NOT NULL CHECK (started_at_epoch_ms > 0),
    completed_at_epoch_ms bigint NOT NULL CHECK (completed_at_epoch_ms >= started_at_epoch_ms),
    input_snapshot_hash char(64) NOT NULL CHECK (input_snapshot_hash ~ '^[0-9a-f]{64}$'),
    public_features jsonb NOT NULL CHECK (jsonb_typeof(public_features)='object'),
    derived_details jsonb NOT NULL CHECK (jsonb_typeof(derived_details)='object'),
    result_title text NOT NULL,
    result_summary text NOT NULL,
    raw_events jsonb NOT NULL CHECK (jsonb_typeof(raw_events)='array'),
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE(global_id,method_id,input_snapshot_hash)
);
CREATE INDEX IF NOT EXISTS associative_measurement_results_user_method_idx
    ON associative_measurement_results(global_id,method_id,completed_at_epoch_ms DESC);

CREATE TABLE IF NOT EXISTS friendship_pattern_observations (
    observation_id text PRIMARY KEY,
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    snapshot_at timestamptz NOT NULL,
    exposure_policy_version text NOT NULL,
    predictor_snapshot_hash char(64) NOT NULL CHECK (predictor_snapshot_hash ~ '^[0-9a-f]{64}$'),
    similarity_features jsonb NOT NULL CHECK (jsonb_typeof(similarity_features)='object'),
    difference_features jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(difference_features)='object'),
    method_scores jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(method_scores)='object'),
    outcome_status text NOT NULL CHECK (outcome_status IN ('CONFIRMED_FRIENDSHIP','ACTIVE_RELATIONSHIP','NOT_FRIENDSHIP_AFTER_SUFFICIENT_EXPOSURE','INSUFFICIENT_INTERACTION')),
    confirmed_by_both boolean NOT NULL DEFAULT false,
    observation_window_days integer NOT NULL CHECK (observation_window_days BETWEEN 1 AND 3650),
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id),
    CHECK (outcome_status <> 'CONFIRMED_FRIENDSHIP' OR confirmed_by_both)
);
CREATE INDEX IF NOT EXISTS friendship_pattern_observations_outcome_idx
    ON friendship_pattern_observations(outcome_status,snapshot_at);
