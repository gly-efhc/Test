-- Brotherhood cycle 0020: Hospitality foundation and backend lifecycle.
-- Hospitality reuses canonical global_id, conversations, user_blocks, trust_incidents and account_ratings.
-- Exact arrival/location data is stored only as application-level AEAD ciphertext.

CREATE TABLE IF NOT EXISTS hospitality_host_profiles (
    host_global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    is_hosting_active boolean NOT NULL DEFAULT false,
    max_guests smallint NOT NULL CHECK (max_guests > 0),
    max_days smallint NOT NULL CHECK (max_days > 0),
    city_id uuid NOT NULL REFERENCES cities(city_id),
    public_area_text text,
    timezone_name text NOT NULL,
    sleeping_condition text NOT NULL CHECK (sleeping_condition IN ('private_room','shared_room','sofa','entire_space')),
    house_rules jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(house_rules) = 'array'),
    min_required_rating numeric(5,2) NOT NULL DEFAULT 0 CHECK (min_required_rating BETWEEN 0 AND 100),
    required_completed_tests text[] NOT NULL DEFAULT '{}',
    availability_mode text NOT NULL DEFAULT 'always' CHECK (availability_mode IN ('always','calendar')),
    private_location_ciphertext bytea NOT NULL,
    private_location_nonce bytea NOT NULL,
    private_location_key_version smallint NOT NULL CHECK (private_location_key_version > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hospitality_host_active_city_idx
    ON hospitality_host_profiles(city_id, is_hosting_active);

CREATE TABLE IF NOT EXISTS hospitality_availability (
    availability_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    host_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    date_from date NOT NULL,
    date_to date NOT NULL,
    availability_state text NOT NULL CHECK (availability_state IN ('available','unavailable')),
    capacity_override smallint CHECK (capacity_override IS NULL OR capacity_override > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (date_to > date_from)
);
CREATE INDEX IF NOT EXISTS hospitality_availability_host_dates_idx
    ON hospitality_availability(host_global_id, date_from, date_to);

CREATE TABLE IF NOT EXISTS stay_requests (
    request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    guest_global_id bigint NOT NULL REFERENCES users(global_id),
    host_global_id bigint NOT NULL REFERENCES users(global_id),
    check_in_date date NOT NULL,
    check_out_date date NOT NULL,
    guests_count smallint NOT NULL CHECK (guests_count > 0),
    status text NOT NULL DEFAULT 'pending' CHECK (status IN (
        'pending','accepted','rejected','cancelled_by_guest','cancelled_by_host','completed','expired'
    )),
    response_due_at timestamptz NOT NULL,
    conversation_id uuid REFERENCES conversations(conversation_id),
    eligibility_snapshot jsonb NOT NULL CHECK (jsonb_typeof(eligibility_snapshot) = 'object'),
    create_idempotency_key text NOT NULL,
    rejection_reason text,
    cancellation_reason text,
    accepted_at timestamptz,
    completed_at timestamptz,
    arrival_details_ciphertext bytea,
    arrival_details_nonce bytea,
    arrival_details_key_version smallint,
    private_access_expires_at timestamptz,
    review_deadline_at timestamptz,
    version integer NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (guest_global_id <> host_global_id),
    CHECK (check_out_date > check_in_date),
    UNIQUE (guest_global_id, create_idempotency_key)
);
CREATE INDEX IF NOT EXISTS stay_requests_host_status_dates_idx
    ON stay_requests(host_global_id, status, check_in_date, check_out_date);
CREATE INDEX IF NOT EXISTS stay_requests_guest_status_dates_idx
    ON stay_requests(guest_global_id, status, check_in_date, check_out_date);
CREATE INDEX IF NOT EXISTS stay_requests_pending_due_idx
    ON stay_requests(response_due_at) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS stay_requests_completed_review_idx
    ON stay_requests(review_deadline_at) WHERE status = 'completed';

CREATE TABLE IF NOT EXISTS hospitality_request_events (
    event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    conversation_id uuid NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    actor_global_id bigint REFERENCES users(global_id),
    event_type text NOT NULL CHECK (event_type IN (
        'request_created','request_accepted','request_rejected','request_cancelled_by_guest',
        'request_cancelled_by_host','request_expired','stay_completed','reviews_opened',
        'reviews_published','hospitality_restriction_applied'
    )),
    public_payload jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(public_payload) = 'object'),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hospitality_request_events_request_idx
    ON hospitality_request_events(request_id, created_at);

CREATE TABLE IF NOT EXISTS hospitality_private_access_audit (
    audit_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    viewer_global_id bigint NOT NULL REFERENCES users(global_id),
    granted boolean NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hospitality_private_access_audit_request_idx
    ON hospitality_private_access_audit(request_id, created_at);

CREATE TABLE IF NOT EXISTS hospitality_stay_confirmations (
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    global_id bigint NOT NULL REFERENCES users(global_id),
    confirmation text NOT NULL CHECK (confirmation IN ('stay_occurred','no_show','dispute')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (request_id, global_id)
);

CREATE TABLE IF NOT EXISTS stay_reviews (
    review_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id uuid NOT NULL REFERENCES stay_requests(request_id) ON DELETE CASCADE,
    author_global_id bigint NOT NULL REFERENCES users(global_id),
    target_global_id bigint NOT NULL REFERENCES users(global_id),
    adequacy smallint NOT NULL CHECK (adequacy BETWEEN 1 AND 5),
    rules_compliance smallint NOT NULL CHECK (rules_compliance BETWEEN 1 AND 5),
    description_accuracy smallint NOT NULL CHECK (description_accuracy BETWEEN 1 AND 5),
    review_score numeric(5,2) NOT NULL CHECK (review_score BETWEEN 0 AND 100),
    review_contract_version text NOT NULL,
    review_text text,
    private_feedback_ciphertext bytea,
    private_feedback_nonce bytea,
    private_feedback_key_version smallint,
    submitted_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz,
    moderated_at timestamptz,
    UNIQUE (request_id, author_global_id),
    CHECK (author_global_id <> target_global_id)
);
CREATE INDEX IF NOT EXISTS stay_reviews_target_published_idx
    ON stay_reviews(target_global_id, published_at);

CREATE TABLE IF NOT EXISTS hospitality_restrictions (
    restriction_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id),
    scope text NOT NULL CHECK (scope IN ('guest','host','all')),
    source_incident_id uuid NOT NULL REFERENCES trust_incidents(incident_id),
    reason_code text NOT NULL,
    starts_at timestamptz NOT NULL,
    ends_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (ends_at IS NULL OR ends_at > starts_at)
);
CREATE INDEX IF NOT EXISTS hospitality_restrictions_active_idx
    ON hospitality_restrictions(global_id, starts_at, ends_at);
