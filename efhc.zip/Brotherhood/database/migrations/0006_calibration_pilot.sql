-- Brotherhood v0.5.16: opt-in empirical calibration pilot.
-- Raw item-level traces are separated from the active personality profile store.
-- Withdrawing consent deletes raw calibration attempts but keeps the user's aggregate profile.

CREATE TABLE IF NOT EXISTS calibration_consents (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    opt_in boolean NOT NULL DEFAULT false,
    consent_version text NOT NULL,
    cohort_id text NOT NULL,
    consented_at timestamptz,
    withdrawn_at timestamptz,
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assessment_calibration_attempts (
    attempt_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    assessment_code text NOT NULL,
    assessment_version text NOT NULL,
    stimulus_version text NOT NULL,
    instrument_locale text NOT NULL,
    cohort_id text NOT NULL,
    consent_version text NOT NULL,
    started_at timestamptz NOT NULL,
    completed_at timestamptz NOT NULL,
    answer_consistency smallint NOT NULL CHECK (answer_consistency BETWEEN 0 AND 100),
    dimensions jsonb NOT NULL CHECK (jsonb_typeof(dimensions) = 'array'),
    response_trace jsonb NOT NULL CHECK (jsonb_typeof(response_trace) = 'array'),
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (completed_at >= started_at),
    UNIQUE(global_id, assessment_code, assessment_version, completed_at)
);

CREATE INDEX IF NOT EXISTS assessment_calibration_attempts_model_idx
    ON assessment_calibration_attempts(assessment_version, stimulus_version, cohort_id, completed_at DESC);
CREATE INDEX IF NOT EXISTS assessment_calibration_attempts_locale_idx
    ON assessment_calibration_attempts(instrument_locale, assessment_code, completed_at DESC);

COMMENT ON TABLE assessment_calibration_attempts IS
    'Private opt-in empirical calibration data. Never expose through public people/profile/assessment APIs.';
