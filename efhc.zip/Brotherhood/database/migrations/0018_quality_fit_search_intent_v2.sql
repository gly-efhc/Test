-- Cycle 0033: Quality Fit / SearchIntent v2.
-- Quality Fit is directional A->B and remains separate from Compatibility, Trust, Account Rating and Hospitality Reputation.
ALTER TABLE search_requests
    ADD COLUMN IF NOT EXISTS requirements jsonb NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS quality_fit_version text NOT NULL DEFAULT 'quality-fit-search-intent-v2';

ALTER TABLE search_requests
    DROP CONSTRAINT IF EXISTS search_requests_requirements_object_check;
ALTER TABLE search_requests
    ADD CONSTRAINT search_requests_requirements_array_check CHECK (jsonb_typeof(requirements) = 'array');

CREATE TABLE IF NOT EXISTS quality_fit_evaluations (
    evaluation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    searcher_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    candidate_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    search_request_id uuid REFERENCES search_requests(search_request_id) ON DELETE SET NULL,
    role_context text NOT NULL CHECK (char_length(role_context) BETWEEN 2 AND 80),
    contract_version text NOT NULL,
    catalog_version text NOT NULL,
    scoring_version text NOT NULL,
    intent_snapshot_hash char(64) NOT NULL CHECK (intent_snapshot_hash ~ '^[0-9a-f]{64}$'),
    candidate_evidence_hash char(64) NOT NULL CHECK (candidate_evidence_hash ~ '^[0-9a-f]{64}$'),
    score smallint CHECK (score IS NULL OR score BETWEEN 0 AND 100),
    confidence smallint NOT NULL CHECK (confidence BETWEEN 0 AND 100),
    availability text NOT NULL CHECK (availability IN ('AVAILABLE','PARTIAL','INSUFFICIENT_DATA','HARD_REQUIREMENT_NOT_MET')),
    eligible boolean NOT NULL,
    evaluation_payload jsonb NOT NULL CHECK (jsonb_typeof(evaluation_payload) = 'object'),
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (searcher_global_id <> candidate_global_id),
    UNIQUE (searcher_global_id,candidate_global_id,intent_snapshot_hash,candidate_evidence_hash,scoring_version)
);

CREATE INDEX IF NOT EXISTS quality_fit_evaluations_searcher_created_idx
    ON quality_fit_evaluations(searcher_global_id, created_at DESC);
CREATE INDEX IF NOT EXISTS quality_fit_evaluations_candidate_created_idx
    ON quality_fit_evaluations(candidate_global_id, created_at DESC);
