-- Brotherhood v0.5.12 bounded profile avatar storage.
-- The Android client resizes/compresses before upload; server enforces <= 512 KiB.
CREATE TABLE IF NOT EXISTS profile_avatars (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    content_type text NOT NULL CHECK (content_type IN ('image/jpeg','image/png','image/webp')),
    image_bytes bytea NOT NULL CHECK (octet_length(image_bytes) BETWEEN 1 AND 512000),
    sha256 char(64) NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    updated_at timestamptz NOT NULL DEFAULT now()
);
