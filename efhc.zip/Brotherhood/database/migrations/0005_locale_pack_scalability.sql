-- Brotherhood v0.5.15: language tags are data-driven and future-extensible.
-- Active languages are controlled by shared/locales/supported.json; the database only validates syntax.
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_locale_check;
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_locale_format_check;
ALTER TABLE profiles
    ADD CONSTRAINT profiles_locale_format_check
    CHECK (locale ~ '^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$');
