-- Brotherhood cycle 0024: immutable Psychological Report history + Q28 compatibility selection persistence.
-- Research completion is not treated as runtime completion; these tables support real product state.
-- Raw visual response traces are intentionally excluded from psychological_reports.input_snapshot.

CREATE TABLE IF NOT EXISTS psychological_reports (
    report_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    report_version text NOT NULL,
    model_version text NOT NULL,
    generated_at timestamptz NOT NULL,
    input_snapshot_hash char(64) NOT NULL CHECK (input_snapshot_hash ~ '^[0-9a-f]{64}$'),
    input_snapshot jsonb NOT NULL CHECK (jsonb_typeof(input_snapshot) = 'array'),
    coverage_percent smallint NOT NULL CHECK (coverage_percent BETWEEN 0 AND 100),
    report_document jsonb NOT NULL CHECK (jsonb_typeof(report_document) = 'object'),
    persisted_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (global_id, report_version, input_snapshot_hash)
);
CREATE INDEX IF NOT EXISTS psychological_reports_global_generated_idx
    ON psychological_reports(global_id, generated_at DESC, persisted_at DESC);

CREATE TABLE IF NOT EXISTS compatibility_metric_preferences (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    contract_version text NOT NULL DEFAULT 'independent-compatibility-v1',
    selected_metrics jsonb NOT NULL CHECK (jsonb_typeof(selected_metrics) = 'array'),
    updated_at timestamptz NOT NULL DEFAULT now()
);
