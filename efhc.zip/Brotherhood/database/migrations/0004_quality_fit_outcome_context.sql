-- Brotherhood v0.5.14: snapshot the user-authored search intent and Quality Fit at connection time.
-- Internal analytics only. This does not alter public reputation, canonical Compatibility, Trust or Account Completeness.

ALTER TABLE friendship_outcomes
    ADD COLUMN IF NOT EXISTS searcher_global_id bigint REFERENCES users(global_id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS search_role text,
    ADD COLUMN IF NOT EXISTS desired_qualities jsonb NOT NULL DEFAULT '{}'::jsonb,
    ADD COLUMN IF NOT EXISTS quality_fit_score smallint,
    ADD COLUMN IF NOT EXISTS quality_fit_confidence smallint,
    ADD COLUMN IF NOT EXISTS quality_model_version text;

ALTER TABLE friendship_outcomes
    DROP CONSTRAINT IF EXISTS friendship_outcomes_search_role_check,
    ADD CONSTRAINT friendship_outcomes_search_role_check
        CHECK (search_role IS NULL OR search_role IN ('friend','close_friend','business_partner','director','project_teammate','mentor','activity_partner','custom')),
    DROP CONSTRAINT IF EXISTS friendship_outcomes_desired_qualities_object_check,
    ADD CONSTRAINT friendship_outcomes_desired_qualities_object_check
        CHECK (jsonb_typeof(desired_qualities) = 'object'),
    DROP CONSTRAINT IF EXISTS friendship_outcomes_quality_fit_score_check,
    ADD CONSTRAINT friendship_outcomes_quality_fit_score_check
        CHECK (quality_fit_score IS NULL OR quality_fit_score BETWEEN 0 AND 100),
    DROP CONSTRAINT IF EXISTS friendship_outcomes_quality_fit_confidence_check,
    ADD CONSTRAINT friendship_outcomes_quality_fit_confidence_check
        CHECK (quality_fit_confidence IS NULL OR quality_fit_confidence BETWEEN 0 AND 100),
    DROP CONSTRAINT IF EXISTS friendship_outcomes_searcher_pair_check,
    ADD CONSTRAINT friendship_outcomes_searcher_pair_check
        CHECK (searcher_global_id IS NULL OR searcher_global_id IN (first_global_id, second_global_id));

CREATE INDEX IF NOT EXISTS friendship_outcomes_quality_fit_90d_idx
    ON friendship_outcomes(quality_model_version, still_active_90d, quality_fit_score)
    WHERE quality_fit_score IS NOT NULL AND still_active_90d IS NOT NULL;
