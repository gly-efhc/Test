-- Cycle 0031: standalone basic Zodiac application persistence.
-- AS remains an independent traditional/alternative metric. This migration does not add natal/synastry data.

CREATE TABLE IF NOT EXISTS zodiac_readings (
    reading_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    birth_date date NOT NULL,
    locale text NOT NULL,
    calculation_version text NOT NULL,
    catalog_version text NOT NULL,
    compatibility_version text NOT NULL,
    input_snapshot_hash char(64) NOT NULL CHECK (input_snapshot_hash ~ '^[0-9a-f]{64}$'),
    reading_payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zodiac_readings_global_history_idx
    ON zodiac_readings(global_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS zodiac_readings_idempotent_snapshot_idx
    ON zodiac_readings(global_id, input_snapshot_hash, calculation_version, catalog_version);

CREATE TABLE IF NOT EXISTS zodiac_pair_comparisons (
    comparison_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    compatibility_version text NOT NULL,
    score smallint NOT NULL CHECK (score BETWEEN 0 AND 100),
    comparison_payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id)
);
CREATE INDEX IF NOT EXISTS zodiac_pair_history_first_idx
    ON zodiac_pair_comparisons(first_global_id, created_at DESC);
CREATE INDEX IF NOT EXISTS zodiac_pair_history_second_idx
    ON zodiac_pair_comparisons(second_global_id, created_at DESC);
