-- Cycle 0026: first-class persistent Search Requests.
-- Search requests are explicit user intent and Quality Fit inputs; they never expose private latent traits.
CREATE TABLE IF NOT EXISTS search_requests (
    search_request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 120),
    role text NOT NULL CHECK (char_length(role) BETWEEN 2 AND 80),
    desired_qualities jsonb NOT NULL DEFAULT '[]'::jsonb,
    city text,
    radius_km smallint NOT NULL DEFAULT 25 CHECK (radius_km BETWEEN 5 AND 500),
    min_trust smallint NOT NULL DEFAULT 0 CHECK (min_trust BETWEEN 0 AND 100),
    min_compatibility smallint NOT NULL DEFAULT 0 CHECK (min_compatibility BETWEEN 0 AND 100),
    online_only boolean NOT NULL DEFAULT false,
    verified_only boolean NOT NULL DEFAULT false,
    hospitality_only boolean NOT NULL DEFAULT false,
    notes text CHECK (notes IS NULL OR char_length(notes) <= 1000),
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','archived')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (jsonb_typeof(desired_qualities) = 'array')
);
CREATE INDEX IF NOT EXISTS search_requests_owner_status_updated_idx
    ON search_requests(owner_global_id, status, updated_at DESC);
