-- Cycle 0028 / Q44: replace removed legacy 100x6 visual assessment bank with seven scientific questionnaire systems.
CREATE OR REPLACE VIEW account_ratings AS
SELECT
    u.global_id,
    global_id_display(u.global_id) AS global_id_display,
    LEAST(50.0, COALESCE(p.completed_profile_sections, 0) * 5.0) AS profile_points,
    LEAST(50.0, COUNT(DISTINCT ar.assessment_code) FILTER (
        WHERE ar.assessment_version='scientific-questionnaire-v1'
          AND ar.assessment_code IN ('traits_core','interpersonal_style','communication_conflict','trust_support_boundaries','decision_work_style','social_group_role','adaptability_uncertainty')
    ) * (50.0/7.0)) AS test_points,
    LEAST(100.0,
        COALESCE(p.completed_profile_sections, 0) * 5.0 +
        COUNT(DISTINCT ar.assessment_code) FILTER (
            WHERE ar.assessment_version='scientific-questionnaire-v1'
              AND ar.assessment_code IN ('traits_core','interpersonal_style','communication_conflict','trust_support_boundaries','decision_work_style','social_group_role','adaptability_uncertainty')
        ) * (50.0/7.0)
    ) AS total_rating
FROM users u
LEFT JOIN profiles p ON p.global_id = u.global_id
LEFT JOIN assessment_results ar ON ar.global_id = u.global_id
GROUP BY u.global_id, p.completed_profile_sections;
