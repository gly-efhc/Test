# Database — Neon PostgreSQL

Каноническая схема базы хранится отдельно от Android и применяется к Neon до production-деплоя API.

Порядок миграций текущего HEAD:

1. `migrations/0001_initial.sql`
2. `migrations/0002_friendship_outcomes.sql`
3. `migrations/0003_profile_avatars.sql`
4. `migrations/0004_quality_fit_outcome_context.sql`
5. `migrations/0005_locale_pack_scalability.sql`
6. `migrations/0006_calibration_pilot.sql`
7. `migrations/0007_controlled_pilot_cohort.sql`
8. `migrations/0008_auth_sessions_provider_passkeys.sql`
9. `migrations/0009_hospitality.sql` — Hospitality data/security foundation; старые миграции не редактировать.
10. `migrations/0010_hospitality_runtime.sql` — Hospitality runtime lifecycle/reputation extensions.
11. `migrations/0011_psychological_reports_independent_compatibility.sql` — immutable Psychological Report history + compatibility preferences.
12. `migrations/0012_search_requests.sql` — first-class Search Requests persistence.
13. После настройки Neon Auth/Data API применить `policies/0001_neon_rls.sql` согласно deployment-процедуре проекта.
14. Передать pooled `DATABASE_URL` только в server environment.

`backend/schema.sql` является canonical schema parity snapshot и должен оставаться синхронным с последовательностью migrations. Наличие миграций `0009–0012` в source archive не является доказательством их применения к production PostgreSQL/Neon. Live migration execution требует отдельного фактического результата.

Android APK никогда не получает пароль PostgreSQL, `HOSPITALITY_PRIVATE_KEY_*` и не подключается к Neon напрямую.
