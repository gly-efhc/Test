# Playbook: совместимость код → маршруты → таблицы → миграции

Дата генерации (UTC): 2026-03-01T04:17:26Z

Этот документ — единственная рабочая инструкция, как ремонтировать
маршруты без самострелов и без «миграция=истина».

## Канон истины

- Истина: ORM (backend/app/models/**, Base.metadata) + SSOT CSV в
  docs/ssot_pack.
- Миграция 0001 — производный артефакт. Она подтверждает истину, но не
  расширяет её.
- Схемы БД: efhc_core, efhc_admin (ровно 2).
- Таблицы канона: ровно 31, все в efhc_core.
- Аудиты: INFORMATIONAL. Не влияют на истину.

## Входные SSOT файлы

- docs/ssot_pack/SSOT_ROUTES.csv — реестр маршрутов.
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv — паспорта (read/write +
  evidence).
- docs/ssot_pack/SSOT_TABLES_ORM.csv — истина таблиц (31).
- docs/ssot_pack/SSOT_RAW_SQL_USAGE.csv — где raw SQL встречается.
- backend/migrations/versions/0001_init.py — ORM-only 0001.
- ops/ci_verify_db_objects.py — CI sanity (2 схемы + 31 таблица).

## Как чинить один маршрут (строго по шагам)

### Шаг 1. Найти маршрут в реестре
1) Открой SSOT_ROUTES.csv, найди method+path.
2) Открой SSOT_ROUTE_TABLE_MAP.csv и посмотри:
   - read_tables / write_tables
   - evidence (file:line)

Если passport пустой или NEED_TRACE → переходи к шагу 2.

### Шаг 2. Сделать таблицы доказуемыми (если NEED_TRACE/DYNAMIC_SQL)
Цель: чтобы по коду было видно таблицу.
Разрешённые доказательства:
- явная fq-строка efhc_core.<table> / efhc_admin.<table>
- ORM запрос select(Model) / query(Model)

Запрещено:
- «вроде бы сервис это делает» без file:line
- raw SQL на таблицы вне ORM-31

### Шаг 3. Привести handler к канону
- Handler должен вызывать 1 сервисный метод.
- Write операции:
  - атомарность (UPDATE..WHERE status=..)
  - commit() обязателен
  - статусы/constraints только по моделям

### Шаг 4. Синхронизировать SSOT
Обновить:
- SSOT_ROUTE_TABLE_MAP.csv (read/write + evidence)
- SSOT_RAW_SQL_USAGE.csv (только ORM-31)
- при необходимости SSOT_TABLES_ORM.csv (count=31)

### Шаг 5. Миграции и тесты
- 0001 не дополнять «extra таблицами».
- CI sanity должен проверять 2 схемы + 31 таблицу.
- Истина по падениям: только logs_*.zip GitHub Actions.

## Правило “без потери файлов”
Новый ver-ZIP обязан содержать все пути из предыдущего (кроме мусора:
__pycache__, *.pyc, node_modules, .next, caches).

