# BANK CANON SHORT

Короткий жёсткий канон банкового контура EFHC.

## Истина

- центральный банк: `BANK_EFHC`
- банковый ключ баланса: `EFHC_MAIN`
- банк может уходить в минус
- пользовательские балансы в минус уходить не могут

## Направления проводок

- `user credit ⇒ bank debit`
- `user debit ⇒ bank credit`

Других смыслов у проводок нет.

## Границы балансов

- внешнее пополнение EFHC идёт только в `main_balance`
- вывод возможен только из `main_balance`
- `bonus_balance` тратится на всё, кроме вывода
- prize EFHC: `BANK_EFHC(main) → user bonus`

## Критические таблицы

- `efhc_core.bank_balance`
- `efhc_core.efhc_transfers_log`
- `efhc_core.withdraw_requests`
- `efhc_admin.admin_action_log`

## Недопустимо

- ручной SQL-апдейт денег вне сервисного контура
- смешение `main` и `bonus` в выводе
- обход idempotency для денежных POST
