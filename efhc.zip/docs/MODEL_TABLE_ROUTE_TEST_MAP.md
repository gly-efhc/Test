# MODEL → TABLE → ROUTE → TEST MAP

Критическая карта соответствия для быстрых аудитов.

- таблицы SSOT: **38**
- маршруты SSOT: **92**
- test files: **72**

## bank

- model file: `backend/app/models/bank_balance_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/admin/bank/balance`
  - `/admin/bank/mint`
  - `/admin/bank/burn`
- tests:
  - `tests/architecture/test_api_finance_canon.py`
  - `tests/architecture/test_financial_integrity.py`
  - `tests/test_economics_transactions.py`
  - `tests/architecture/test_bank_runtime_invariants.py`

## withdraw

- model file: `backend/app/models/withdraw_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/withdraw/request`
  - `/withdraw/{request_id}`
  - `/withdraw/{request_id}/cancel`
  - `/admin/withdrawals/{request_id}/approve`
  - `/admin/withdrawals/{request_id}/reject`
- tests:
  - `tests/test_withdraw_state_machine.py`
  - `tests/test_concurrency_withdraw_double.py`
  - `tests/test_concurrency_exchange_withdraw.py`
  - `tests/architecture/test_withdraw_runtime_invariants.py`

## exchange

- model file: `backend/app/models/exchange_routes.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/exchange/preview/{tg_id}`
  - `/exchange/convert/{tg_id}`
  - `/exchange/history/{tg_id}`
- tests:
  - `tests/architecture/test_exchange_mirror_and_locks.py`
  - `tests/efhc_backend/unit/test_exchange.py`
  - `tests/test_concurrency_exchange_all.py`

## panels

- model file: `backend/app/models/panels_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/panels/{tg_id}/summary`
  - `/panels/{tg_id}/active`
  - `/panels/{tg_id}/archive`
  - `/panels/buy/{tg_id}`
- tests:
  - `tests/test_panels_180_days.py`
  - `tests/test_panels_ssot_backend.py`
  - `tests/test_panels_idempotent_create.py`

## lotteries

- model file: `backend/app/models/lotteries_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/api/lotteries`
  - `/api/lotteries/{lotteries_id}/buy`
  - `/admin/lotteries/history`
- tests:
  - `tests/efhc_backend/unit/test_prizes_autocycle_ssot.py`
  - `tests/efhc_backend/unit/test_prizes_smoke.py`
  - `tests/test_no_banned_lotteries_terms.py`

## referrals

- model file: `backend/app/models/referral_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/referrals/counters`
  - `/referrals/active`
  - `/referrals/inactive`
  - `/api/admin/referrals/summary`
- tests:
  - `tests/architecture/test_api_finance_canon.py`
  - `tests/efhc_backend/unit/test_finance_spend_rules.py`

## ranks

- model file: `backend/app/models/ranks_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/ranks/top`
  - `/ranks/my-plus-top`
- tests:
  - `tests/architecture/test_no_banned_rank_terms.py`
  - `tests/architecture/test_forbidden_identifiers_repo.py`

## wallets

- model file: `backend/app/models/wallets_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/wallets/me`
  - `/wallets/connect`
  - `/wallets/{wallet_id}/make-primary`
- tests:
  - `tests/test_wallets_connect_hardening.py`
  - `tests/test_wallets_tonconnect_semantics_guard.py`

## shop

- model file: `backend/app/models/shop_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/shop/catalog`
  - `/shop/purchase-efhc`
  - `/shop/order-external`
  - `/shop/orders`
- tests:
  - `tests/efhc_backend/unit/test_shop_items.py`
  - `tests/efhc_backend/unit/test_orders.py`
  - `tests/architecture/test_deposit_packages_contract.py`

## tasks

- model file: `backend/app/models/tasks_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/tasks/catalog`
  - `/tasks/my/{tg_id}`
  - `/tasks/claim/{tg_id}`
  - `/api/admin/tasks`
- tests:
  - `tests/test_per_sec_constants_settings.py`
  - `tests/test_build_sanity.py`
