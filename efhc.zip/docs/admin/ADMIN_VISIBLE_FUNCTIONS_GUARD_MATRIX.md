<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX

Status: active static evidence matrix for Admin surfaces.

## Purpose

This document binds each Admin surface to the visible operator
functions, backend roads, existing SSOT/NORM anchors and active
guards. It is an evidence map, not a new product SSOT.

## Sandbox intake boundary

The user supplied the main sandbox and five extra TMA templates.
They were checked as reference/navigation sources only. No Vue,
Solid, Nuxt, Vanilla, foreign lock file, CI file, wallet/payment
logic or translation source was copied into EFHC runtime.
No wallet/payment logic was copied into EFHC runtime.

## Admin evidence matrix

| Surface | Frontend page | Visible operator functions | Backend roads | Active guard anchors | Boundary |
|---|---|---|---|---|---|
| `/admin` | `frontend/src/pages/admin/index.tsx` | overview KPI cards<br>admin app button grid<br>bank simulator dashboard<br>TON reconcile action<br>UI kit proof panel | GET /admin/docs/history/legacy_artifacts/reports/overview<br>POST /admin/ton/reconcile | tests/architecture/test_admin_interactive_dashboard.py<br>tests/architecture/test_admin_ui_kit_contract.py<br>tests/architecture/test_admin_no_bottom_nav.py | overview only; diagnostics stay outside normal home |
| `/admin/bank` | `frontend/src/pages/admin/bank.tsx` | bank balance<br>ledger snapshot<br>mint with confirmation<br>burn with confirmation<br>flow/chart explanation | GET /admin/bank/balance<br>GET /admin/docs/history/legacy_artifacts/reports/overview<br>GET /admin/logs/transfers<br>POST /admin/bank/mint<br>POST /admin/bank/burn | tests/architecture/test_admin_bank.py<br>tests/architecture/test_admin_bank_road_guard.py<br>tests/frontend/e2e/test_admin_bank_requires_confirmation.py | money mutations require confirmation and Idempotency-Key |
| `/admin/users` | `frontend/src/pages/admin/users.tsx` | user search<br>user detail<br>VIP toggle<br>active toggle<br>wallet reset<br>balance correction via admin transfer | GET /admin/users/search<br>GET /admin/users/{global_id}<br>PATCH /admin/users/{global_id}/vip<br>PATCH /admin/users/{global_id}/active<br>POST /admin/users/{global_id}/wallet/reset<br>POST /admin/transfer | tests/architecture/test_admin_users.py<br>tests/architecture/test_admin_users_variant_a.py<br>tests/architecture/test_admin_routes_guarded.py | global_id remains external route identity |
| `/admin/withdrawals` | `frontend/src/pages/admin/withdrawals.tsx` | withdrawal list<br>approve decision<br>reject decision<br>repair consistency<br>outcome preview<br>TonConnect payout handoff | GET /admin/withdrawals<br>POST /admin/withdrawals/{request_id}/approve<br>POST /admin/withdrawals/{request_id}/reject<br>POST /admin/withdrawals/repair-consistency<br>GET /admin/withdrawals/{request_id}/outcome-preview | tests/architecture/test_admin_withdrawals_mobile_decision.py<br>tests/architecture/test_withdraw_admin_contract.py<br>tests/architecture/test_admin_routes_guarded.py | final statuses are not overwritten |
| `/admin/shop` | `frontend/src/pages/admin/shop.tsx` | orders list<br>items list<br>item upsert<br>item status<br>item delete<br>force fulfill<br>legacy order lookup<br>legacy user orders lookup | GET /admin/shop/orders<br>GET /admin/shop/items<br>POST /admin/shop/items/upsert<br>POST /admin/shop/items/status<br>POST /admin/shop/items/delete<br>POST /admin/shop/orders/{order_id}/force-fulfill<br>GET /admin/shop/order/legacy/{order_id}<br>GET /admin/shop/orders/user/legacy/{global_id} | tests/architecture/test_admin_shop_web3_separation.py<br>tests/architecture/test_hub_shop_admin.py<br>tests/architecture/test_shop_admin_contract_freeze_lock.py | operator actions stay separated from Web3 payment road |
| `/admin/tasks` | `frontend/src/pages/admin/tasks.tsx` | task catalog<br>submissions list<br>moderation<br>refresh statuses<br>task transfer trace | GET /admin/tasks<br>POST /admin/tasks<br>GET /admin/tasks/{task_id}/subs<br>POST /admin/tasks/submissions/{submission_id}/moderate<br>POST /admin/tasks/refresh-statuses<br>GET /admin/logs/transfers?reason=task_bonus | tests/architecture/test_admin_tasks_catalog_ux.py<br>tests/architecture/test_admin_tasks_execution_trace.py | execution trace remains admin-only |
| `/admin/reports` | `frontend/src/pages/admin/reports.tsx` | visual dashboard<br>safe export/download boundary<br>aggregate overview | GET /admin/docs/history/legacy_artifacts/reports/overview | tests/architecture/test_admin_reports_visual_dashboard.py<br>tests/architecture/test_admin_reports_export_download.py<br>tests/architecture/test_admin_reports_overview_metrics.py | read-only aggregate reporting |
| `/admin/diagnostics` | `frontend/src/pages/admin/diagnostics.tsx` | route health strip<br>technical diagnostics panel<br>diagnostic action grid | GET /admin/docs/history/legacy_artifacts/reports/overview<br>GET /admin/shop/items<br>GET /admin/users/search<br>GET /admin/withdrawals<br>GET /admin/hub/links | tests/architecture/test_admin_diagnostics_boundary.py<br>tests/architecture/test_admin_docs_ssot_route_map.py | only diagnostics may show route health labels |
| `/admin/system` | `frontend/src/pages/admin/system.tsx` | system settings shell<br>operator navigation | documented helper surface; no money road | tests/architecture/test_admin_docs_ssot_route_map.py<br>tests/architecture/test_admin_no_bottom_nav.py | system-level navigation only |
| `/admin/logs` | `frontend/src/pages/admin/logs.tsx` | log viewing guidance<br>transfer log road anchor | GET /admin/logs/transfers | tests/architecture/test_admin_docs_ssot_route_map.py<br>tests/architecture/test_admin_routes_guarded.py | read-only logs; no log deletion |
| `/admin/panels` | `frontend/src/pages/admin/panels.tsx` | panel list<br>activate panel<br>deactivate panel<br>route health | GET /admin/panels<br>PATCH /admin/panels/{panel_id}/activate<br>PATCH /admin/panels/{panel_id}/deactivate | tests/architecture/test_admin_panel_limit_counts_only_active.py<br>tests/architecture/test_panels_active_archive_layout.py<br>tests/architecture/test_admin_routes_guarded.py | panel admin actions stay in admin route contour |
| `/admin/referrals` | `frontend/src/pages/admin/referrals.tsx` | referral summary<br>active/inactive counters<br>level/ranking analytics | GET /admin/referrals/summary | tests/architecture/test_backend_admin_referral_wording_sync_lock.py<br>tests/architecture/test_admin_routes_guarded.py | read-only analytics; no manual bonus or inviter reassignment |
| `/admin/ads` | `frontend/src/pages/admin/ads.tsx` | provider list<br>provider refresh<br>route health | GET /admin/ads/providers | tests/architecture/test_admin_docs_ssot_route_map.py<br>tests/architecture/test_admin_routes_guarded.py | non-core helper surface; not release contour |
| `/admin/templates` | `frontend/src/pages/admin/templates.tsx` | template list<br>template update | GET /admin/templates<br>PUT /admin/templates/{key} | tests/architecture/test_admin_docs_ssot_route_map.py<br>tests/architecture/test_admin_routes_guarded.py | content edit only; no economics |
| `/admin/hub` | `frontend/src/pages/admin/hub.tsx -> frontend/src/features/admin/AdminHubPage.tsx` | hub links list<br>create/edit link<br>toggle link<br>reorder links | GET /admin/hub/links<br>POST /admin/hub/links<br>PUT /admin/hub/links/{link_id}<br>POST /admin/hub/links/{link_id}/toggle<br>POST /admin/hub/links/reorder | tests/architecture/test_hub_admin_migration_model_wave_lock.py<br>tests/architecture/test_hub_shop_admin.py<br>tests/architecture/test_admin_routes_guarded.py | navigation management only; no commerce report |
| `/admin/sale-packages` | `frontend/src/pages/admin/sale-packages.tsx -> frontend/src/features/admin/AdminSalePackagesPage.tsx` | package list<br>create package<br>edit package<br>toggle package | GET /admin/sale-packages<br>POST /admin/sale-packages<br>PUT /admin/sale-packages/{package_id}<br>POST /admin/sale-packages/{package_id}/toggle | tests/architecture/test_admin_sale_packages_mutations_wired.py<br>tests/architecture/test_admin_routes_guarded.py | sale package management only |
| `/admin/efhc-deposits` | `frontend/src/pages/admin/efhc-deposits.tsx` | runtime summary<br>manual deposit process<br>reprocess by tx_hash<br>manual force fulfill fallback | GET /admin/efhc-deposits/runtime-summary<br>POST /admin/efhc-deposits/process<br>POST /admin/efhc-deposits/reprocess/{tx_hash}<br>POST /admin/shop/orders/{order_id}/force-fulfill | tests/architecture/test_admin_docs_ssot_route_map.py<br>tests/architecture/test_admin_routes_guarded.py<br>tests/architecture/test_hub_shop_admin.py | operator fallback for deposit watcher road |

## Weak-link repair

The weak link was not a missing route. The weak link was that
Admin route maps, visible operator functions and guard anchors
were spread across several documents and tests. This pass adds
one narrow active architecture guard over the matrix without
changing runtime UI or backend economics.

## Non-claims

- No browser screenshot proof is claimed.
- No live Telegram proof is claimed.
- No real wallet or TonConnect transaction proof is claimed.
- No GitHub CI green is newly claimed by this local pass.
