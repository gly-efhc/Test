# Admin interactive dashboard canon — work pass

## User target

Admin must be an interactive analytics dashboard for the EFHC banking
simulator. It must not be only a static text/control page.

## Required behaviour

- dynamic visualization of financial flows;
- dynamic visualization of user activity;
- filters by game days / simulation steps;
- zoom / scale control;
- clickable chart points;
- instant KPI recalculation without page reload;
- live pulse and scheduled refresh behaviour;
- no debug dump or endpoint proof on the operator surface.

## Implementation decision

The current project has no chart library dependency in `frontend/package.json`.
Therefore work pass implements the first dependency-safe version with SVG and
CSS. This keeps the release build stable while still giving interactive
charts, filters, zoom and live animation.

## Sandbox donor

The visual donor remains `Песочница.xz`:

- dashboard KPI cards;
- interactive chart / area chart patterns;
- section cards;
- data table density;
- wallet-style chart switchers.

## Current source data

The first pass uses `/admin/docs/history/legacy_artifacts/reports/overview` facts/counters:

- bank total EFHC;
- user balances;
- active users;
- panels;
- exchanged kWh;
- transfer counters.

If future backend time-series routes are added, the same dashboard shell can be
wired to real historical game-day buckets without changing the operator UX.
