# ADMIN_DOCS_SSOT_ROUTE_MAP

Version: v169_34 / work pass
Date: 2026-06-01
Status: active admin navigation map, GENERAL/ADMIN operational canon

## Purpose

work pass updates the Admin documentation and SSOT route map after
work pass. The goal is to give the archive a single narrow
navigation surface for Admin pages, backend routes, frontend components
and the strongest related SSOT/NORM documents.

This document is not a new product SSOT. It is a route map that points to
existing SSOT/NORM sources. Permanent product rules remain in SSOT/NORM.

## Input and output

Input HEAD:

`EFHC Bot v169_33 release archive for admin_screenshot_qa_preparation`

Output archive:

`EFHC Bot v169_34 release archive for admin_docs_ssot_route_map`

## Sandbox donor usage

The sandbox was opened and used as an information-architecture donor:

- `ui-main` section cards for grouped route blocks;
- `ui-main` data-table/list-detail pattern for matrix structure;
- Telegram Mini App compact cell/display-row pattern for concise rows.

No Nuxt, Vue, Solid, Vanilla, jQuery runtime or new dependency is copied.

## Admin surface route map

| Surface | Frontend page | Applied components | Backend roads | Canon / SSOT / NORM | Boundary |
|---|---|---|---|---|---|
| `/admin` | `frontend/src/pages/admin/index.tsx` | AdminInteractiveBankDashboard; AdminUiKitAdoptionProofPanel; AdminScreenshotQaPreparationPanel | GET /admin/reports/overview | docs/admin/ADMIN_INTERACTIVE_DASHBOARD_CANON.md; docs/admin/ADMIN_UI_KIT_ADOPTION_PROOF_PASS.md; docs/admin/ADMIN_SCREENSHOT_QA_PREPARATION.md | admin home, overview only; no diagnostics dump |
| `/admin/bank` | `frontend/src/pages/admin/bank.tsx` | AdminBankDashboardRuntime; AdminPromptModal; AdminActionGrid | GET /admin/bank/balance; GET /admin/reports/overview; GET /admin/logs/transfers; POST /admin/bank/mint; POST /admin/bank/burn | docs/SSOT/BANK_CANON.md; docs/admin/ADMIN_INTERACTIVE_OPERATOR_SECTION.md | financial actions require confirmation and idempotency |
| `/admin/users` | `frontend/src/pages/admin/users.tsx` | AdminInteractiveOperatorPanel; AdminListShell; AdminDetailShell | GET /admin/users/search; GET /admin/users/{global_id}; PATCH /vip; PATCH /active; POST /wallet/reset; POST /admin/transfer | docs/SSOT/SYSTEM_LOCK_global_id.md; docs/NORM/ADMIN_RBAC.md; docs/admin/ADMIN_INTERACTIVE_OPERATOR_SECTION.md | global_id is external id; balance correction only through bank road |
| `/admin/withdrawals` | `frontend/src/pages/admin/withdrawals.tsx` | AdminWithdrawalsMobileDecisionPanel; AdminPromptModal | GET /admin/withdrawals; POST /approve; POST /reject; POST /repair-consistency; GET /outcome-preview | docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md; docs/SSOT/WITHDRAW_OUTCOME_SERVICE_SSOT.md; docs/admin/ADMIN_WITHDRAWALS_MOBILE_DECISION_PANEL.md | state-machine decisions; final statuses are not overwritten |
| `/admin/shop` | `frontend/src/pages/admin/shop.tsx` | AdminShopWeb3SeparationPanel; AdminSurfaceTabs | GET /admin/shop/orders; GET /admin/shop/items; POST /items/upsert; POST /items/status; POST /items/delete; POST /orders/{id}/force-fulfill | docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md; docs/SSOT/TON_MEMO_SPEC.md; docs/admin/ADMIN_SHOP_WEB3_SEPARATION_PANEL.md | operator actions separated from Web3 payment road |
| `/admin/tasks` | `frontend/src/pages/admin/tasks.tsx` | AdminTasksCatalogUxPanel; AdminTasksExecutionTracePanel | GET/POST /admin/tasks; GET /subs; POST /submissions/{id}/moderate; GET /admin/logs/transfers?reason=task_bonus | docs/admin/ADMIN_TASKS_CATALOG_UX.md; docs/admin/ADMIN_TASKS_EXECUTION_TRACE_BOUNDARY.md | admin-only trace; public Tasks stays without hidden execution log |
| `/admin/reports` | `frontend/src/pages/admin/reports.tsx` | AdminReportsVisualDashboardPanel; AdminReportsExportDownloadPanel | GET /admin/reports/overview | docs/admin/ADMIN_REPORTS_VISUAL_DASHBOARD.md; docs/admin/ADMIN_REPORTS_EXPORT_DOWNLOAD_BOUNDARY.md | read-only reporting; export allowed only for safe aggregate fields |
| `/admin/diagnostics` | `frontend/src/pages/admin/diagnostics.tsx` | AdminDiagnosticsTechnicalBoundaryPanel; AdminRouteHealthStrip | route health checks over existing admin endpoints | docs/admin/ADMIN_DIAGNOSTICS_TECHNICAL_BOUNDARY.md | technical-only screen; no business action surface |
| `/admin/system` | `frontend/src/pages/admin/system.tsx` | AdminFunctionalPageTemplate | system settings / diagnostics links | docs/GENERAL/ADMIN_PANEL_SPEC.md; docs/NORM/ADMIN_RBAC.md | system-level navigation only in this cycle |
| `/admin/logs` | `frontend/src/pages/admin/logs.tsx` | AdminPage; AdminSectionCard | GET /admin/logs/transfers | docs/NORM/ADMIN_RBAC.md | audit/log read-only surface |
| `/admin/panels` | `frontend/src/pages/admin/panels.tsx` | AdminRouteHealthStrip; AdminPage | GET /admin/panels; PATCH /activate; PATCH /deactivate | docs/SSOT/PANELS_SSOT.md | admin panel activation/deactivation only through admin routes |
| `/admin/referrals` | `frontend/src/pages/admin/referrals.tsx` | AdminListShell; AdminDetailShell | GET /admin/referrals/summary | docs/NORM/REFERRAL_DEEPLINK_BINDING_CANON.md; docs/SSOT/EFHC_CANON.md | read-only referral analytics; no manual payout or reassignment |
| `/admin/ads` | `frontend/src/pages/admin/ads.tsx` | AdminRouteHealthStrip; AdminPage | GET /admin/ads/providers | docs/GENERAL/ADMIN_PANEL_SPEC.md | ads provider diagnostics/control surface |
| `/admin/templates` | `frontend/src/pages/admin/templates.tsx` | AdminPage | GET /admin/templates; PUT /admin/templates/{key} | docs/GENERAL/ADMIN_PANEL_SPEC.md | template content edit, no economics |
| `/admin/hub` | `frontend/src/pages/admin/hub.tsx` | AdminHubPage | GET/POST/PUT /admin/hub/links; POST /toggle; POST /reorder | docs/SSOT/HUB_SSOT.md; docs/GENERAL/ADMIN_PANEL_SPEC.md | navigation layer; not commerce report |
| `/admin/sale-packages` | `frontend/src/pages/admin/sale-packages.tsx` | AdminSalePackagesPage | GET/POST/PUT /admin/sale-packages; POST /toggle | docs/GENERAL/ADMIN_PANEL_SPEC.md | sale package management |
| `/admin/efhc-deposits` | `frontend/src/pages/admin/efhc-deposits.tsx` | AdminListShell; AdminDetailShell; AdminPromptModal | GET /admin/efhc-deposits/runtime-summary; POST /process; POST /reprocess/{tx_hash}; POST /admin/shop/orders/{id}/force-fulfill | docs/SSOT/TON_MEMO_SPEC.md; docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md | operator fallback for automated deposit watcher road |

## Backend admin endpoint inventory

| Route file | Method | Path |
|---|---:|---|
| `admin_ads_routes.py` | GET | `/admin/ads/providers` |
| `admin_logs_routes.py` | GET | `/admin/logs/transfers` |
| `admin_panels_routes.py` | GET | `/admin/panels/` |
| `admin_panels_routes.py` | PATCH | `/admin/panels/{panel_id}/activate` |
| `admin_panels_routes.py` | PATCH | `/admin/panels/{panel_id}/deactivate` |
| `admin_referral_routes.py` | GET | `/admin/referrals/summary` |
| `admin_routes.py` | POST | `/admin/transfer` |
| `admin_routes.py` | GET | `/admin/bank/balance` |
| `admin_routes.py` | POST | `/admin/bank/mint` |
| `admin_routes.py` | POST | `/admin/bank/burn` |
| `admin_routes.py` | POST | `/admin/ton/reconcile` |
| `admin_routes.py` | POST | `/admin/efhc-deposits/process` |
| `admin_routes.py` | GET | `/admin/efhc-deposits/runtime-summary` |
| `admin_routes.py` | POST | `/admin/efhc-deposits/reprocess/{tx_hash}` |
| `admin_routes.py` | GET | `/admin/reports/overview` |
| `admin_sale_packages_routes.py` | GET | `/admin/sale-packages/` |
| `admin_sale_packages_routes.py` | POST | `/admin/sale-packages/` |
| `admin_sale_packages_routes.py` | POST | `/admin/sale-packages/{package_id}/toggle` |
| `admin_sale_packages_routes.py` | PUT | `/admin/sale-packages/{package_id}` |
| `admin_shop_routes.py` | GET | `/admin/shop/orders` |
| `admin_shop_routes.py` | POST | `/admin/shop/orders/{order_id}/force-fulfill` |
| `admin_shop_routes.py` | GET | `/admin/shop/items` |
| `admin_shop_routes.py` | POST | `/admin/shop/items/upsert` |
| `admin_shop_routes.py` | GET | `/admin/shop/order/legacy/{order_id}` |
| `admin_shop_routes.py` | GET | `/admin/shop/orders/user/legacy/{global_id}` |
| `admin_shop_routes.py` | POST | `/admin/shop/items/status` |
| `admin_shop_routes.py` | POST | `/admin/shop/items/set-price` |
| `admin_shop_routes.py` | POST | `/admin/shop/items/delete` |
| `admin_shop_routes.py` | GET | `/admin/hub/links` |
| `admin_shop_routes.py` | POST | `/admin/hub/links` |
| `admin_shop_routes.py` | PUT | `/admin/hub/links/{link_id}` |
| `admin_shop_routes.py` | POST | `/admin/hub/links/{link_id}/toggle` |
| `admin_shop_routes.py` | POST | `/admin/hub/links/reorder` |
| `admin_tasks_routes.py` | POST | `/admin/tasks/` |
| `admin_tasks_routes.py` | GET | `/admin/tasks/` |
| `admin_tasks_routes.py` | GET | `/admin/tasks/{task_id}` |
| `admin_tasks_routes.py` | PATCH | `/admin/tasks/{task_id}` |
| `admin_tasks_routes.py` | DELETE | `/admin/tasks/{task_id}` |
| `admin_tasks_routes.py` | GET | `/admin/tasks/{task_id}/subs` |
| `admin_tasks_routes.py` | POST | `/admin/tasks/refresh-statuses` |
| `admin_tasks_routes.py` | POST | `/admin/tasks/submissions/{submission_id}/moderate` |
| `admin_templates_routes.py` | GET | `/admin/templates` |
| `admin_templates_routes.py` | PUT | `/admin/templates/{key}` |
| `admin_users_routes.py` | GET | `/admin/users/search` |
| `admin_users_routes.py` | GET | `/admin/users/{global_id}` |
| `admin_users_routes.py` | PATCH | `/admin/users/{global_id}/vip` |
| `admin_users_routes.py` | PATCH | `/admin/users/{global_id}/active` |
| `admin_users_routes.py` | POST | `/admin/users/{global_id}/wallet/reset` |
| `admin_withdrawals_routes.py` | POST | `/admin/withdrawals/repair-consistency` |
| `admin_withdrawals_routes.py` | GET | `/admin/withdrawals` |
| `admin_withdrawals_routes.py` | POST | `/admin/withdrawals/{request_id}/approve` |
| `admin_withdrawals_routes.py` | POST | `/admin/withdrawals/{request_id}/reject` |
| `admin_withdrawals_routes.py` | GET | `/admin/withdrawals/{request_id}/outcome-preview` |

## Strong rules

- Admin pages stay behind Admin guard.
- Admin UI is Russian operator UI.
- Admin diagnostics do not return to normal business panels.
- Public UI must not receive Admin route labels, raw payloads or operator
  internals.
- Financial POST actions keep confirmation and `Idempotency-Key` where
  the route mutates money or final status.
- `global_id` remains the external user identifier in routes/services.
- CI/workflow files are manual-control and are not changed in this cycle.

## Maintenance rule

When a future cycle changes an Admin page, Admin component, Admin route or
its related SSOT/NORM source, update this map and
`docs/admin/ADMIN_ROUTES_MAP.md` or explicitly record why the route
map does not change.

## work pass regression proof link

work pass adds the active regression proof layer:

- `docs/admin/ADMIN_REGRESSION_PROOF_PASS.md`;
- `docs/audits/ADMIN_REGRESSION_PROOF_AUDIT_V169_35.md`;
- `reports/generated/admin_regression_proof_v169_35.json`.

Future changes to Admin pages, Admin components, backend Admin routes or
SSOT/NORM anchors must keep this route map and the regression proof matrix in
sync, or explicitly document why a surface is helper/deferred.

