<!-- EFHC_ADMIN_ROUTE_MAP_V2: ACTIVE -->
# ADMIN DOCS SSOT ROUTE MAP — v173.51 candidate

Источник текущего HTTP surface: статически экспортированный `backend/openapi/openapi.json` из HEAD. Документ не является результатом локальной runtime/OpenAPI-регенерации.

Current Admin surface: **66 paths**.

## Admin frontend pages

- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `frontend/src/pages/admin/bonuses.tsx`
- `frontend/src/pages/admin/diagnostics.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/hub.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/sale-packages.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/system.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/templates.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`

## Current Admin HTTP operations

| Method | Path | operationId |
|---|---|---|
| `GET` | `/admin/access` | `admin_access` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint` |
| `GET` | `/admin/bonuses` | `admin_bonus_activity` |
| `GET` | `/admin/efhc-deposits/inbox` | `admin_efhc_deposits_inbox` |
| `GET` | `/admin/efhc-deposits/unmatched` | `admin_efhc_deposits_unmatched` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers` |
| `GET` | `/admin/observability/events` | `admin_observability_events` |
| `GET` | `/admin/observability/health` | `admin_observability_health` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries` |
| `GET` | `/admin/panels/` | `admin_panels_list` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate` |
| `GET` | `/admin/referrals/summary` | `get_summary` |
| `GET` | `/admin/reports/bank` | `reports_bank` |
| `GET` | `/admin/reports/deposits` | `reports_deposits` |
| `GET` | `/admin/reports/overview` | `reports_overview` |
| `GET` | `/admin/reports/panels` | `reports_panels` |
| `GET` | `/admin/reports/users` | `reports_users` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package` |
| `GET` | `/admin/shop/items` | `admin_items` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order` |
| `GET` | `/admin/shop/orders` | `admin_orders` |
| `GET` | `/admin/shop/nft-requests` | `admin_vip_nft_requests` |
| `POST` | `/admin/shop/nft-requests/{order_id}/decision` | `admin_vip_nft_request_decision` |
| `GET` | `/admin/shop/orders/status-counters` | `admin_shop_order_status_counters` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order` |
| `GET` | `/admin/tasks/` | `list_tasks_admin` |
| `POST` | `/admin/tasks/` | `create_task_admin` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin` |
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin` |
| `GET` | `/admin/templates` | `list_templates_admin` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile` |
| `POST` | `/admin/transfer` | `admin_transfer` |
| `GET` | `/admin/users/search` | `admin_users_search` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip` |
| `POST` | `/admin/users/{global_id}/vip/check` | `admin_users_check_vip_nft` |
| `POST` | `/admin/users/vip/check-all` | `admin_users_check_all_vip_nft` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject` |

## Backend Admin operations без найденного прямого frontend caller

Это **не dead/unused code**. Операции остаются защищённой operational/public Admin surface до отдельного решения пользователя.

| Method | Path | Статус |
|---|---|---|
| `GET` | `/admin/observability/events` | `STUBBED_DUPLICATE` — compatibility-заглушка; причина: дублирование `/admin/logs/transfers`; DB-read отключён. |
| `GET` | `/admin/reports/bank` | `UI_CONNECTED` — доменный BANK_EFHC dashboard на `/admin/reports`. |
| `GET` | `/admin/reports/deposits` | `UI_CONNECTED` — доменный deposits dashboard на `/admin/reports`. |
| `GET` | `/admin/reports/panels` | `UI_CONNECTED` — доменный panels dashboard на `/admin/reports`. |
| `GET` | `/admin/reports/users` | `UI_CONNECTED` — доменный users dashboard; ownership join только `global_id`. |
| `GET` | `/admin/reports/withdrawals` | `UI_CONNECTED` — доменный withdrawals dashboard на `/admin/reports`. |
| `POST` | `/admin/shop/items/set-price` | `PRESERVE_COMPATIBILITY` — отдельный UI не нужен; маршрут делегирует canonical Shop Editor model/history. |
| `POST` | `/admin/tasks/` | `UI_CONNECTED` — создание через canonical Admin Tasks Editor. |
| `GET` | `/admin/tasks/{task_id}` | `UI_CONNECTED` — detail-view выбранного задания в Editor. |
| `PATCH` | `/admin/tasks/{task_id}` | `UI_CONNECTED` — полный редактор canonical полей задания. |
| `DELETE` | `/admin/tasks/{task_id}` | `UI_CONNECTED_FAIL_CLOSED` — физическое удаление только без task history; иначе деактивация. |

Отдельная ручная проверка source-linkage исключила ложные срабатывания: Withdraw `repair-consistency`, approve, reject, outcome-preview и Hub update/toggle/reorder подключены через формируемые URL/aliases.


## Решение цикла 1719 — Reports/Observability

Пять специализированных `/admin/reports/*` routes теперь имеют прямое frontend linkage через `AdminDomainReportsDashboardRuntime` на странице `/admin/reports`. Existing observability summary/timeseries dashboard также подключён к этой странице. `GET /admin/observability/events` сохранён как compatibility stub с `disabled_duplicate` и replacement `/admin/logs/transfers`; это сознательная заглушка, а не случайная потеря функции. Подробный канон: `docs/admin/ADMIN_REPORTS_AND_OBSERVABILITY_CANON.md`.

## Бонусы и начисления — решение цикла 1726

Создан active `GET /admin/bonuses` и страница `/admin/bonuses`, которые собирают историю только из действующих источников: `task_bonus_log`, `referral_bonus_ledger` и ручных банковских операций. Денежная запись не дублируется: ручное начисление идёт через существующий `POST /admin/transfer -> BankService.manual_bank_user_transfer`. Legacy `efhc_admin.bonus_awards` не возвращается; `list_bonus_payouts/list_bonus_awards/process_bonus_award/reject_bonus_award` сохраняются только как compatibility boundary и не используются новым UI. Канон: `docs/admin/ADMIN_BONUSES_AND_MANUAL_CREDITS_CANON.md`.

## Delete policy

Отсутствие frontend caller, generated seam use или прямого Python caller не является доказательством безопасного удаления Admin capability. Для удаления требуется отдельное ТЗ и доказательство по Fail-Closed Delete Policy.

Статус документа: **ACTIVE v173.51 candidate**. Runtime verification — следующий exact-head GitHub CI.


## Решение цикла 1720 — Admin Tasks Editor

- `POST/GET/PATCH/DELETE /admin/tasks[/... ]` подключены к `/admin/tasks` через `AdminTasksEditorPanel`.
- Editor управляет canonical полями задания; `performed_count` read-only.
- DELETE fail-closed проверяет submissions, user status, bonus log и completion locks; при истории используется деактивация.
- `/admin/tasks/{task_id}/subs` и moderation сохранены как основа операторского контура.
- `/admin/tasks/refresh-statuses` сохраняется как compatibility route, но UI называет действие «Обслуживание task locks» согласно реальной семантике.
- `/admin/ads` остаётся отдельным контуром рекламных провайдеров и показывает registry/config readiness без раскрытия ENV secrets.
- Подробный канон: `docs/admin/ADMIN_TASKS_EDITOR_CANON.md`.

Статус документа: **ACTIVE v173.44 candidate**. Runtime verification — следующий exact-head GitHub CI.

## Решение Shop Management

- `/admin/shop` — единый Admin Shop Editor для карточек, цен, методов оплаты, статуса, history и Order Control.
- `/admin/shop/orders/status-counters` — `UI_CONNECTED`; глобальные статусы считаются по всей таблице.
- `/admin/shop/orders/{order_id}/force-fulfill` — `UI_CONNECTED_RECOVERY`; owner только `global_id`, EFHC credit только через BANK/idempotency.
- `/admin/shop/order/{order_id}` и `/admin/shop/orders/user/{global_id}` — `UI_CONNECTED`.
- `/shopfront/profile` — `UI_CONNECTED_EXTERNAL_SHOP`; используется внешней `/browser-shop` после signed handoff.
- Physical delete Shop item fail-closed блокируется при order history по реальному SKU.
- Подробный канон: `docs/admin/ADMIN_SHOP_MANAGEMENT_CANON.md`.


## Решение цикла 1724 — TON / Deposits / Recovery

`/admin/efhc-deposits` является единым операторским интерфейсом входящих платежей: общий обзор, список входящих операций, несопоставленные операции, безопасная повторная обработка, сверка за период и отдельно обозначенная аварийная ручная обработка. Видимый UI использует человеческие названия действий и состояний; внутренние TON/status/runtime термины остаются в API и журналах.

`GET /admin/efhc-deposits/inbox` и `GET /admin/efhc-deposits/unmatched` имеют прямое подключение к текущей Admin Deposits page. Historical произвольная смена статуса не восстановлена. Подробнее: `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`.
## Решение цикла 1725 — VIP / NFT / заявки на выдачу

- `/admin/users/{global_id}/vip/check` — `UI_CONNECTED`; человеческое действие «Проверить выбранного пользователя».
- `/admin/users/vip/check-all` — `UI_CONNECTED`; действие «Проверить всех пользователей сейчас».
- `PATCH /admin/users/{global_id}/vip` — `PRESERVE_COMPATIBILITY`; произвольный VIP больше не записывает, выполняет фактическую NFT-проверку.
- `/admin/shop/nft-requests` и `/admin/shop/nft-requests/{order_id}/decision` — `UI_CONNECTED`; единый workflow оплаченной заявки на ручную выдачу VIP NFT.
- `submit_manual_vip_nft_claim(tg_id, ...)` — `REPLACED_BY_CANON / DO_NOT_RESTORE`; создание второй дублирующей Shop-заявки запрещено.
- Admin NFT credential остаётся отдельной authority chain через точные item addresses из `TON_ADMIN_NFT_IDS`; business actor остаётся `global_id`.
- Подробный канон: `docs/admin/ADMIN_VIP_NFT_MANAGEMENT_CANON.md`.

Статус документа: **ACTIVE v173.50 candidate**. Runtime verification — следующий exact-head GitHub CI.

---

# ТЕКУЩЕЕ ДОПОЛНЕНИЕ КАРТЫ ADMIN-МАРШРУТОВ — v175.01 / цикл 1842

- Источник текущего дополнения: checked-in `backend/openapi/openapi.json` после канонической статической генерации.
- Текущая Admin-поверхность: `87` путей / `94` HTTP-операции.
- Admin → «Центр ссылок» сохраняет канонические Hub-ссылки и получает отдельный контур «Чат поддержки».
- Управление контактами поддержки: `GET /admin/hub/support-links`, `POST /admin/hub/support-links`, `POST /admin/hub/support-links/reorder`, `PUT /admin/hub/support-links/{link_id}`, `POST /admin/hub/support-links/{link_id}/toggle`.
- Пользовательское чтение доступных способов связи: `GET /hub/support-links`.
- Backend/API и отдельный блок «Чат поддержки» подготовлены; полноценную визуальную доводку редактора выполняет frontend-команда по решению OWNER.

