<!-- EFHC_ADMIN_ROUTE_MAP_V2: ACTIVE -->
# ADMIN DOCS SSOT ROUTE MAP — v173.43

Источник текущего HTTP surface: статически экспортированный `backend/openapi/openapi.json` из HEAD. Документ не является результатом локальной runtime/OpenAPI-регенерации.

Current Admin surface: **58 paths**.

## Admin frontend pages

- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `frontend/src/pages/admin/diagnostics.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/hub.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/sale-packages.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/system.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/templates.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`

## Current Admin HTTP operations

| Method | Path | operationId |
|---|---|---|
| `GET` | `/admin/access` | `admin_access` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers` |
| `GET` | `/admin/observability/events` | `admin_observability_events` |
| `GET` | `/admin/observability/health` | `admin_observability_health` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries` |
| `GET` | `/admin/panels/` | `admin_panels_list` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate` |
| `GET` | `/admin/referrals/summary` | `get_summary` |
| `GET` | `/admin/reports/bank` | `reports_bank` |
| `GET` | `/admin/reports/deposits` | `reports_deposits` |
| `GET` | `/admin/reports/overview` | `reports_overview` |
| `GET` | `/admin/reports/panels` | `reports_panels` |
| `GET` | `/admin/reports/users` | `reports_users` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package` |
| `GET` | `/admin/shop/items` | `admin_items` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order` |
| `GET` | `/admin/shop/orders` | `admin_orders` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order` |
| `GET` | `/admin/tasks/` | `list_tasks_admin` |
| `POST` | `/admin/tasks/` | `create_task_admin` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin` |
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin` |
| `GET` | `/admin/templates` | `list_templates_admin` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile` |
| `POST` | `/admin/transfer` | `admin_transfer` |
| `GET` | `/admin/users/search` | `admin_users_search` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject` |

## Backend Admin operations без найденного прямого frontend caller

Это **не dead/unused code**. Операции остаются защищённой operational/public Admin surface до отдельного решения пользователя.

| Method | Path | Статус |
|---|---|---|
| `GET` | `/admin/observability/events` | `STUBBED_DUPLICATE` — compatibility-заглушка; причина: дублирование `/admin/logs/transfers`; DB-read отключён. |
| `GET` | `/admin/reports/bank` | `UI_CONNECTED` — доменный BANK_EFHC dashboard на `/admin/reports`. |
| `GET` | `/admin/reports/deposits` | `UI_CONNECTED` — доменный deposits dashboard на `/admin/reports`. |
| `GET` | `/admin/reports/panels` | `UI_CONNECTED` — доменный panels dashboard на `/admin/reports`. |
| `GET` | `/admin/reports/users` | `UI_CONNECTED` — доменный users dashboard; ownership join только `global_id`. |
| `GET` | `/admin/reports/withdrawals` | `UI_CONNECTED` — доменный withdrawals dashboard на `/admin/reports`. |
| `POST` | `/admin/shop/items/set-price` | `PRESERVE_NO_UI_CALLER` — отдельная операционная смена цены; current UI использует другие Shop mutations. |
| `POST` | `/admin/tasks/` | `UI_CONNECTED` — создание через canonical Admin Tasks Editor. |
| `GET` | `/admin/tasks/{task_id}` | `UI_CONNECTED` — detail-view выбранного задания в Editor. |
| `PATCH` | `/admin/tasks/{task_id}` | `UI_CONNECTED` — полный редактор canonical полей задания. |
| `DELETE` | `/admin/tasks/{task_id}` | `UI_CONNECTED_FAIL_CLOSED` — физическое удаление только без task history; иначе деактивация. |

Отдельная ручная проверка source-linkage исключила ложные срабатывания: Withdraw `repair-consistency`, approve, reject, outcome-preview и Hub update/toggle/reorder подключены через формируемые URL/aliases.


## Решение цикла 1719 — Reports/Observability

Пять специализированных `/admin/reports/*` routes теперь имеют прямое frontend linkage через `AdminDomainReportsDashboardRuntime` на странице `/admin/reports`. Existing observability summary/timeseries dashboard также подключён к этой странице. `GET /admin/observability/events` сохранён как compatibility stub с `disabled_duplicate` и replacement `/admin/logs/transfers`; это сознательная заглушка, а не случайная потеря функции. Подробный канон: `docs/admin/ADMIN_REPORTS_AND_OBSERVABILITY_CANON.md`.

## Bonus Awards

Bonus Awards compatibility сохраняется на service/facade/contract уровне. Отдельные Admin HTTP route и frontend page для Bonus Awards отсутствуют; исторический `v171.89` также не подтверждает существование отдельной Bonus page/route. Документы legacy-статуса описывают `efhc_admin.bonus_awards` как неактивный legacy runtime. Поэтому подтверждённый cleanup-дефект — удаление compatibility symbols, а не отключение существовавшей страницы. Создание отдельного UI/API является самостоятельной продуктовой задачей.

## Delete policy

Отсутствие frontend caller, generated seam use или прямого Python caller не является доказательством безопасного удаления Admin capability. Для удаления требуется отдельное ТЗ и доказательство по Fail-Closed Delete Policy.

Статус документа: **ACTIVE v173.43**. Runtime verification — следующий exact-head GitHub CI.


## Решение цикла 1720 — Admin Tasks Editor

- `POST/GET/PATCH/DELETE /admin/tasks[/... ]` подключены к `/admin/tasks` через `AdminTasksEditorPanel`.
- Editor управляет canonical полями задания; `performed_count` read-only.
- DELETE fail-closed проверяет submissions, user status, bonus log и completion locks; при истории используется деактивация.
- `/admin/tasks/{task_id}/subs` и moderation сохранены как основа операторского контура.
- `/admin/tasks/refresh-statuses` сохраняется как compatibility route, но UI называет действие «Обслуживание task locks» согласно реальной семантике.
- `/admin/ads` остаётся отдельным контуром рекламных провайдеров и показывает registry/config readiness без раскрытия ENV secrets.
- Подробный канон: `docs/admin/ADMIN_TASKS_EDITOR_CANON.md`.

Статус документа: **ACTIVE v173.44 candidate**. Runtime verification — следующий exact-head GitHub CI.
