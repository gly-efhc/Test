<!-- EFHC_ADMIN_ROUTE_MAP_V2: ACTIVE -->
# ADMIN DOCS SSOT ROUTE MAP — v173.40 / cycle 1716

Источник текущего HTTP surface: static exported `backend/openapi/openapi.json` из HEAD. Этот документ не является результатом локального runtime/OpenAPI regeneration.

Current Admin surface: **58 paths**.

## Admin frontend pages

- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `frontend/src/pages/admin/diagnostics.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/hub.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/sale-packages.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/system.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/templates.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`

## Current Admin HTTP operations

| Method | Path | operationId |
|---|---|---|
| `GET` | `/admin/access` | `admin_access` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers` |
| `GET` | `/admin/observability/events` | `admin_observability_events` |
| `GET` | `/admin/observability/health` | `admin_observability_health` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries` |
| `GET` | `/admin/panels/` | `admin_panels_list` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate` |
| `GET` | `/admin/referrals/summary` | `get_summary` |
| `GET` | `/admin/reports/bank` | `reports_bank` |
| `GET` | `/admin/reports/deposits` | `reports_deposits` |
| `GET` | `/admin/reports/overview` | `reports_overview` |
| `GET` | `/admin/reports/panels` | `reports_panels` |
| `GET` | `/admin/reports/users` | `reports_users` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package` |
| `GET` | `/admin/shop/items` | `admin_items` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order` |
| `GET` | `/admin/shop/orders` | `admin_orders` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order` |
| `GET` | `/admin/tasks/` | `list_tasks_admin` |
| `POST` | `/admin/tasks/` | `create_task_admin` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin` |
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin` |
| `GET` | `/admin/templates` | `list_templates_admin` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile` |
| `POST` | `/admin/transfer` | `admin_transfer` |
| `GET` | `/admin/users/search` | `admin_users_search` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject` |

## Backend Admin routes with no direct frontend caller found

Эти routes **не считаются dead/unused**. Они остаются protected operational/public Admin surface до отдельного решения пользователя.

| Route | Status |
|---|---|
| `/admin/observability/events` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Operational observability endpoint; no direct frontend caller found in static source audit. |
| `/admin/reports/bank` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Specialized report API; no direct frontend caller found. |
| `/admin/reports/deposits` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Specialized report API; no direct frontend caller found. |
| `/admin/reports/panels` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Specialized report API; no direct frontend caller found. |
| `/admin/reports/users` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Specialized report API; no direct frontend caller found. |
| `/admin/reports/withdrawals` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Specialized report API; no direct frontend caller found. |
| `/admin/shop/items/set-price` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Admin Shop operational endpoint; UI currently uses upsert/status/delete surfaces. |
| `/admin/tasks/{task_id}` | `STATIC_NO_FRONTEND_CALLER_FOUND / PRESERVE` — Item-level task route; no direct frontend caller found in current Admin pages. |

## Bonus Awards

Current Bonus Awards compatibility присутствует на service/facade/contract уровне. Dedicated Admin HTTP route и dedicated frontend page для Bonus Awards отсутствуют; исторический `v171.89` также не подтверждает существование отдельной Bonus page/route. Поэтому это не классифицируется как route regression. Создание UI/API для Bonus Awards — отдельная продуктовая задача.

## Delete policy

Отсутствие frontend caller, generated seam use или прямого Python caller не является доказательством безопасного удаления Admin capability. Для удаления требуется отдельное ТЗ и доказательство по Fail-Closed Delete Policy.

Статус документа: **ACTIVE v173.40**. Runtime verification — следующий exact-head GitHub CI.
