# ADMIN_SCREENSHOT_QA_PREPARATION

Version: v169_33 / work pass
Date: 2026-05-31
Status: active Admin screenshot QA canon

## Purpose

work pass prepares Admin screenshot QA after the UI Kit adoption proof.
It does not claim visual release-readiness by code alone. It defines which
Admin surfaces require manual screenshot proof and adds an operator-facing
QA preparation panel on Admin home.

## HEAD

Input archive:

`EFHC Bot v169_32 release archive for admin_ui_kit_adoption_proof`

Output archive:

`EFHC Bot v169_33 release archive for admin_screenshot_qa_preparation`

## Code entry

New component:

`frontend/src/components/admin/AdminScreenshotQaPreparationPanel.tsx`

Applied screen:

`frontend/src/pages/admin/index.tsx`

## Required screenshot surfaces

work pass prepares manual screenshot proof for:

- `/admin`;
- `/admin/bank` and `/admin/users`;
- `/admin/withdrawals`;
- `/admin/shop`;
- `/admin/tasks`;
- `/admin/reports`;
- `/admin/diagnostics`.

## Required viewports

Minimum viewports:

- mobile width around 390 px;
- Telegram-like narrow viewport;
- desktop/browser viewport;
- empty/error/loading or decision state when changed.

## Sandbox donor usage

The panel adapts donor patterns from the sandbox:

- `ui-main` section cards;
- `ui-main` data table/list-detail pattern;
- `ui-main` chart-area-interactive pattern;
- Telegram Mini App compact cells/display rows.

No Nuxt, Vue, Solid, Vanilla renderer, jQuery runtime or new chart/table
dependency is added.

## Boundaries

The cycle must not:

- change EFHC economics;
- add backend routes;
- change `ci.yml`;
- claim GitHub CI green locally;
- claim browser screenshot proof without real screenshots;
- expose raw payload, endpoint dumps or public Admin internals;
- move Diagnostics back to normal business panels.

## Screenshot QA result rule

work pass prepares the QA matrix and does not claim screenshot proof.
It does not replace the future manual screenshot pass. Future reports may mark screenshot proof complete only
when screenshots or user-provided visual evidence are available.
