<!-- EFHC_ADMIN_SHOP_MANAGEMENT_CANON_V1: ACTIVE -->
# ADMIN SHOP MANAGEMENT CANON

## Назначение

Shop — единый многофункциональный контур управления внешней HTML-витриной EFHC. Он объединяет canonical Shop service, Admin Shop Editor, внешний Browser Shop, подключённый профиль, заказ, оплату, операторский recovery и историю карточек.

Этот документ фиксирует действующее решение пользователя. Локальные application tests/builds/guards для нового HEAD не запускались; квалификация изменений выполняется следующим exact-head GitHub CI.

## Единая модель товарной карточки

Физическая модель `efhc_core.shop_items` не дублируется новыми колонками. Каноническое хранение:

- `sku` — уникальный код карточки;
- `title`, `description`;
- `quantity_efhc` — количество EFHC для пакетов монет;
- `is_active` — runtime-флаг доступности;
- `extra JSONB` — расширяемые свойства карточки.

В `extra` хранятся:

- `item_type` — тип карточки, включая новые типы, создаваемые редактором;
- `status`: `live | hidden | draft`;
- `image_url`;
- `price_efhc`, `price_ton`, `price_usdt`;
- `pay_currencies`;
- `category`, `badge`;
- `action_mode`: `checkout | external_link`;
- `external_url`;
- `delivery_mode`: `bank_credit | manual | external`;
- `sort_order`;
- `history` — сохраняемая история редакторских изменений.

Admin, public catalog и внешний Browser Shop используют одну и ту же модель. Создание отдельной параллельной таблицы товарных карточек запрещено без отдельного решения пользователя.

## Admin Shop Editor

`/admin/shop` является единой операторской страницей Shop. Редактор поддерживает:

- создание новой карточки;
- редактирование существующей карточки;
- название, описание, изображение, категорию и badge;
- произвольный `item_type` без изменения pre-release schema;
- пакеты EFHC с `quantity_efhc`;
- цены и разрешённые методы оплаты;
- режим `checkout` или `external_link`;
- внешний URL для NFT/GetGems и других внешних товаров;
- delivery mode;
- порядок карточек;
- `draft / hidden / live`;
- историю изменений;
- безопасное скрытие/архивирование вместо уничтожения истории.

`POST /admin/shop/items/upsert` — основной mutation contract редактора.

`POST /admin/shop/items/set-price` сохраняется как compatibility API для старых операторских интеграций, но отдельный второй UI редактора цены не создаётся. Он обязан использовать ту же canonical Shop model и сохранять history.

### Ручная цена TON/USDT — OWNER DECISION

Shop не использует ценовой оракул и не вычисляет цену товара через TON/USD, TON/USDT или другой внешний курс. Администратор сам определяет, сколько TON и/или USDT он хочет получить за конкретный товар, и сохраняет эти значения как `price_ton` и `price_usdt`.

Правила:

- `price_ton` и `price_usdt` независимы друг от друга;
- автоматическая конвертация между TON и USDT запрещена;
- если цена для актива не задана, этот способ оплаты для карточки недоступен;
- Payment Intent фиксирует выбранную ручную цену на момент создания;
- изменение цены карточки не меняет уже созданные intent;
- legacy `custom_efhc_amount_d8` не является pricing authority и не влияет на Shop runtime.

## Внешняя HTML Shop

Внешняя витрина — `/browser-shop`. Она предназначена для использования из всех поддерживаемых входов приложения через signed handoff и API.

Canonical связка:

`signed handoff -> server session/profile -> global_id -> Browser Shop catalog/profile/orders/payments`.

`GET /shopfront/profile` является действующим API подключённого профиля внешней витрины и используется Browser Shop. Он может отдавать canonical account context, связанные TON wallets, историю заказов, active payment/payment intents и связанные operational states.

Внешняя витрина поддерживает:

- EFHC coin packages — например 10/50/100/200/300/400/500/1000 EFHC;
- NFT-карточки;
- внешние NFT/GetGems links;
- новые типы карточек, созданные Admin Editor;
- категории, badge, изображения и сортировку;
- checkout-карточки;
- `external_link` карточки без создания ложного payment intent.

## Платёжный и delivery-контур

External Shop сохраняет intent-first flow по active Shop Payments SSOT:

1. сервер фиксирует order/payment intent и цену;
2. payment watcher подтверждает on-chain payment;
3. для EFHC package используется банковское начисление `BANK_EFHC -> USER(global_id)`;
4. NFT/manual/external delivery не маскируется под автоматическое BANK-credit;
5. manual delivery после подтверждения платежа остаётся в операторском состоянии до исполнения;
6. idempotency и tx-hash locks сохраняются.

`global_id` — единственный business owner заказа. `tg_id` не используется как Shop owner.

## Order Control

Admin Shop включает единый Order Control:

- `GET /admin/shop/orders` — список заказов;
- `GET /admin/shop/orders/status-counters` — глобальные счётчики по всей таблице, а не только текущей UI-странице;
- `GET /admin/shop/order/{order_id}` — подробная карточка заказа;
- `GET /admin/shop/orders/user/{global_id}` — заказы canonical аккаунта;
- `POST /admin/shop/orders/{order_id}/force-fulfill` — recovery action.

Force Fulfill не имеет права восстанавливать старое `tg_id` ownership. Для EFHC package он использует `global_id`, BANK и стабильный idempotency key заказа. Для manual/NFT delivery он фиксирует операторское исполнение без ложного банковского начисления. Терминальные reject/cancel states блокируют recovery.

## Fail-closed удаление и история

Карточка с order history физически не удаляется. История определяется по реальному SKU, сохранённому в `shop_orders.extra`, а не по ложному условию `memo == sku`.

Если история есть, оператор должен перевести карточку в `hidden`/`draft`. Это сохраняет финансовый и операционный audit trail.

Редактирование карточки не уничтожает прежний `extra.history`; history расширяется bounded-записями before/after.

## Исторический status utility

Historical `shop_order_status_counters` не считается мусором. Его самостоятельная ценность подтверждена: прежний UI считал статусы только в загруженной странице заказов. Функция восстановлена в canonical Shop service как глобальный status dashboard и экспортирована через `/admin/shop/orders/status-counters`.

## Защитные правила

- Shop-функции 1–8, согласованные пользователем, являются одной capability и не должны разбрасываться по случайным legacy CRUD-модулям.
- Отсутствие отдельной кнопки не разрешает удалить compatibility API.
- `global_id` — единственный owner.
- Release/ops scripts не изменяются Shop-работой.
- Экономические коэффициенты и BANK CANON не меняются этим редактором.
- Статус нового HEAD до GitHub CI: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
