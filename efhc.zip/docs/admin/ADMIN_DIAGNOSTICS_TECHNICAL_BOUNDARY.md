# ADMIN_DIAGNOSTICS_TECHNICAL_BOUNDARY

Дата: 2026-05-31  
Архив: `v169_24`  
Цикл: `1345 — Diagnostics technical-only boundary`

## Цель

`/admin/diagnostics` закрепляется как техническая admin-only поверхность.
Она может показывать route health, endpoint labels, helper-факты,
public/admin boundary review и release evidence hints.

Diagnostics не является бизнес-экраном и не должен содержать денежные,
пользовательские или shop/payment мутации.

## Sandbox donor-source

В work pass архив `Песочница.xz` открыт физически и использован как
visual/architecture donor-source.

Использованные паттерны:

- `ui-main` tabs examples — переключение контуров;
- `ui-main` data-table pattern — selected diagnostic detail;
- `ui-main` chart-area-interactive — кликабельный technical signal;
- MaterialM status cards — компактные статусные карточки.

Прямого копирования зависимостей нет. Новые chart/table libraries не добавлены.

## Новый компонент

`frontend/src/components/admin/AdminDiagnosticsTechnicalBoundaryPanel.tsx`

Он добавляет:

- KPI-карточки technical/admin/public/release контуров;
- фильтр `Admin / Public / Release`;
- фильтр `Сейчас / Дальше / Guard`;
- SVG boundary signal;
- кликабельные diagnostic nodes;
- selected diagnostic detail table;
- явный маркер `data-admin-diagnostics-boundary-cycle="1345"`.

## Граница

Разрешено:

- показывать endpoint labels;
- показывать route health;
- показывать helper/internal facts;
- показывать public UI interactivity roadmap;
- показывать CI manual boundary;
- показывать release evidence separation.

Запрещено:

- запускать бизнес-действия;
- показывать raw payload dump;
- показывать raw SQL;
- выполнять bank/withdraw/shop/task mutations;
- переносить diagnostics на публичные страницы;
- менять CI/workflow файлы из Diagnostics.

## Public UI note

work pass не внедряет public UI интерактивность в код. Он создаёт план
внедрения public UI interactivity и фиксирует, что этот маршрут должен идти
отдельной волной после admin diagnostics boundary.
