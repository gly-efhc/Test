# ADMIN_SANDBOX_VISUAL_REFERENCE

Version: v169_01 / work pass
Date: 2026-05-26
Status: visual donor map for Admin recovery

## User correction

The user explicitly corrected the operator: the sandbox contains fuller admin
cabinet examples with dashboards, interactive charts and interactive schemes.
The Admin UI must not stay a primitive list-only console when the sandbox has
usable visual patterns.

## Sandbox sources inspected

The sandbox was inspected from `Песочница.xz` as an external visual donor, not
as HEAD and not as a direct runtime source.

Useful admin/dashboard sources found:

1. `MaterialM-Tailwind-Nextjs-Free-main/package/src/app/components/dashboard/`
   - `SalesProfit.tsx`
   - `TotalIncome.tsx`
   - `TotalFollowers.tsx`
   - `EarningReports.tsx`
   - `PopularProducts.tsx`

2. `ui-main/apps/v4/app/(app)/examples/dashboard/components/`
   - `chart-area-interactive.tsx`
   - `section-cards.tsx`
   - `data-table.tsx`
   - `site-header.tsx`

3. `ui-main/apps/v4/components/cards/stats.tsx`

## Patterns accepted for EFHC Admin

Accepted patterns:

- KPI cards at the top of an admin section;
- interactive chart controls/toggles;
- chart-like visual bars when adding heavy chart dependencies is not safe;
- section cards with trend/state badges;
- ledger/data table below statistics;
- interactive scheme nodes for explaining system flow;
- mobile-safe stacked layout.

Rejected direct copying:

- direct `react-apexcharts` adoption without dependency review;
- direct `recharts` adoption unless dependency is added and CI passes;
- blind copying of Tailwind/shadcn code that does not exist in EFHC runtime;
- demo data that looks like production data;
- English-only admin labels.

## work pass adoption

work pass applies sandbox admin patterns to `Admin -> Bank`:

- KPI cards for bank statistics;
- interactive chart toggle: Balance / Coverage / Flow;
- CSS-based chart bars without new dependency;
- interactive bank flow scheme;
- ledger table from `/admin/logs/transfers`;
- route diagnostics removed from Bank page;
- operator actions separated from statistics and ledger.

## Next adoption path

Future admin cycles should continue this pattern:

- 1324: stronger Bank confirmations and idempotency proof;
- 1325: Users/Bank proof pass with visual consistency;
- 1326-1330: Withdrawals and Shop admin dashboards;
- 1331-1335: Tasks, Reports and Diagnostics visual separation;
- 1341-1350: shared admin stats strip, action table, mobile proof and visual
  hardening.
