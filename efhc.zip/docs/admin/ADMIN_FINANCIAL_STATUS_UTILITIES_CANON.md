# ADMIN FINANCIAL / STATUS UTILITIES CANON

Статус: **ACTIVE CANON**.

## 1. Назначение

Этот документ фиксирует решения по историческим финансовым и статусным utility-функциям. Полезная семантика сохраняется внутри действующих Admin Reports и dashboards; старые ошибочные архитектурные границы и `tg_id` ownership не возвращаются.

## 2. BANK event counters

Historical `efhc_transfers_recent_total` не восстанавливается как отдельная функция. В современной ledger-модели одна логическая операция содержит пользовательскую и зеркальную банковскую стороны, поэтому подсчёт всей `efhc_transfers_log` смешивал бы стороны события.

Канонический `GET /admin/reports/bank` считает только банковскую сторону:

- `system_entity = BANK_EFHC`;
- `credit_events_in_range`;
- `debit_events_in_range`;
- `total_events_in_range`;
- `credits_in_range`;
- `debits_in_range`;
- `net_flow_in_range`;
- `bank_main_balance`.

Старое имя `efhc_transfers_recent_total` имеет статус **REPLACED / DO_NOT_RESTORE**.

## 3. Canonical Bank Policy contract

Historical `get_admin_bank_config` возвращал только compatibility-константу и не являлся реальной конфигурацией банка. Он имеет статус **REPLACED / DO_NOT_RESTORE**.

`GET /admin/reports/bank` содержит типизированный read-only `policy`:

```text
system_entity = BANK_EFHC
balance_key = EFHC_MAIN
initial_balance = 5000000.00000000
negative_balance_allowed = true
p2p_allowed = false
bank_global_id = null
bank_tg_id = null
user_owner = global_id
```

Этот блок описывает действующий BANK CANON и не создаёт второй источник настроек или новый money-write API.

## 4. Withdraw status counters

Historical `withdraw_status_counters` не восстанавливается отдельным legacy service. Его полезная семантика встроена в `GET /admin/reports/withdrawals`.

DB-wide snapshot по всей `efhc_core.withdraw_requests` содержит:

- `total_count`;
- `pending_count`;
- `paid_count`;
- `rejected_count`;
- `canceled_count`;
- `total_amount_paid_in_range`.

`/admin/withdrawals` использует эти глобальные counters для status dashboard. Операторский список заявок, фильтры, preview, approve/reject и дополнительные derived metrics остаются отдельным operational слоем и не заменяются агрегатным отчётом.

## 5. Shop status counters

`shop_order_status_counters` уже заменён действующим `GET /admin/shop/orders/status-counters` и относится к единому Shop Management. Повторный legacy facade не создаётся.

## 6. Identity / economy boundary

- user owner: только `global_id`;
- банк: `system_entity=BANK_EFHC`, `global_id=NULL`, `tg_id=NULL`;
- баланс банка: только `efhc_core.bank_balance[key=EFHC_MAIN]`;
- P2P запрещён;
- эти reports являются read-only и не изменяют баланс или статус заявок.

## 7. Verification boundary

Локальные application tests, guards, lint/type checks, Alembic и frontend build не запускаются. Следующая квалификация выполняется только exact-head GitHub CI пользователя.
