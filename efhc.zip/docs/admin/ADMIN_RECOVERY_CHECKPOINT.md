# ADMIN_RECOVERY_CHECKPOINT

Status: active checkpoint document
Version: v169_36

## Purpose

This checkpoint closes the Admin route-map and regression-proof line and makes
sure the project is ready to continue into Public UI screenshot QA.

It connects:

- Admin Dashboard;
- Admin UI Kit;
- Admin docs / SSOT route map;
- Admin regression proof;
- archive filename hygiene;
- sandbox element navigation;
- next Public UI QA direction.

## Confirmed state

| Area | Status | Note |
|---|---|---|
| Admin route map | Confirmed | Active map remains `docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`. |
| Admin regression proof | Confirmed | Active proof remains `docs/admin/ADMIN_REGRESSION_PROOF_PASS.md`. |
| Filename hygiene | Confirmed | Product filenames stay semantic; traceability labels stay in cycles/audits/reports. |
| Chat duplicate cleanup | Confirmed | Canonical chats 21 and 22 remain in `docs/NORM/CHATS/`; duplicate branch copies stay removed. |
| Sandbox map | Updated | `map_element.md` is the active root navigation map. |
| External sandbox rule | Locked | Sandbox archives are donor references, not EFHC runtime code. |
| CI/workflow boundary | Preserved | `ci.yml` is not intentionally changed by this checkpoint. |

## Dunder-integrity repair

The previous filename cleanup damaged Python protocol tokens in code and tests.
This checkpoint restores dunder names such as:

- `__future__`;
- `__file__`;
- `__name__`;
- `__main__`;
- `__all__`;
- `__init__`;
- `__repr__`;
- `__dict__`;
- `__import__`;
- `__path__`;
- `__pycache__`.

A dedicated guard now checks that the damaged single-underscore forms do not
return.

## Sandbox intake summary

The active sandbox layer consists of:

- `Песочница.xz` — compact multi-project sandbox with UI, TON, Telegram Mini
  App, backend and testing references;
- `vuejs-template-master.zip` — Telegram Mini App Vue reference;
- `solidjs-template-master.zip` — Telegram Mini App Solid reference;
- `nuxt-telegram-mini-app-main.zip` — Nuxt/Tailwind Telegram Mini App reference;
- `typescript-template-master.zip` — framework-light TypeScript Telegram Mini
  App reference;
- `vanillajs-template-master.zip` — minimal JavaScript Telegram Mini App
  reference.

Only patterns are accepted. Framework migration is rejected.

## Next direction

The next work should prepare Public UI screenshot QA using the refreshed
sandbox element map:

- public Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks;
- Profile / Wallet / History;
- FAQ;
- HUB;
- Browser Shop.

The public layer must not import Admin diagnostics, Admin route internals or raw
operator payloads.
