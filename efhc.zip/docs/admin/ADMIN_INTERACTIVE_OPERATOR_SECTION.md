<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN_INTERACTIVE_OPERATOR_SECTION

Version: v169_06 / work pass
Date: 2026-05-27
Status: active admin implementation canon

## Purpose

work pass moves the Admin UI Kit from foundation into real adoption on
operator screens. The target is not a static dashboard block, but a
reusable interactive admin section for Bank and Users.

## HEAD

Input HEAD:

`EFHC Bot v169_05 release archive for admin_sandbox_ui_kit`

Output archive:

`EFHC Bot v169_06 release archive for admin_operator_interactive_section`

## Sandbox source used directly

The uploaded sandbox archive was opened directly in this cycle:

`Песочница.xz`

It contains `EFHC_SANDBOX_COMPACT_v002` with the relevant roots:

- `01_EXTRACTED_SOURCES/02_ui__main__full_reference/ui-main/apps/v4/app/(app)/examples/dashboard/components/chart-area-interactive.tsx`;
- `01_EXTRACTED_SOURCES/02_ui__main__full_reference/ui-main/apps/v4/app/(app)/examples/dashboard/components/section-cards.tsx`;
- `01_EXTRACTED_SOURCES/02_ui__main__full_reference/ui-main/apps/v4/app/(app)/examples/dashboard/components/data-table.tsx`;
- `01_EXTRACTED_SOURCES/01_pesochnica_core_full/песочница/MaterialM-Tailwind-Nextjs-Free-main/package/src/app/components/dashboard/*`;
- `01_EXTRACTED_SOURCES/01_pesochnica_core_full/песочница/telegram-web-app-shop-main/src/pages/admin/*`.

## Donor patterns adopted

| Sandbox donor pattern | EFHC adaptation |
|---|---|
| Interactive area chart with time window | SVG chart with metric/window filters, zoom and selected point |
| Section KPI cards | `AdminKpiCard` metric group inside operator panel |
| Dashboard data-table | `AdminActionTable` selected-state control rows |
| Dashboard/sidebar operator grouping | Bank and Users flow nodes inside `AdminFlowMapCard` |
| Telegram admin/shop list pattern | Users operator search/list/detail remains separate from sensitive actions |

## New code

New reusable component:

`frontend/src/components/admin/AdminInteractiveOperatorPanel.tsx`

It is used by:

- `frontend/src/pages/admin/bank.tsx`;
- `frontend/src/pages/admin/users.tsx`.

## Interaction requirements

The operator section must provide:

- metric switching;
- 7 / 14 / 30 step window switching;
- zoom control;
- live pulse state;
- clickable chart points;
- flow-node clicks mapped to metrics;
- selected-state rows;
- mobile-readable layout.

## Boundaries

The cycle does not change EFHC economics, backend routes, bank ledger rules
or `global_id` canon. It is a frontend/admin interaction and UI adoption pass.

## Next adoption route

Recommended next cycle:

`1328 — Withdrawals operator decision template on shared UI Kit`

The next step should apply the same UI Kit discipline to withdrawals:
state machine, decision confirmation, safe operator action separation and
no raw endpoint/debug exposure.
