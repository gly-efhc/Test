# ADMIN_SHOP_WEB3_SEPARATION_PANEL

Version: v169_18 / work pass  
Date: 2026-05-29  
Status: active admin canon

## Purpose

work pass returns from CI repair and Operator Kernel work to the planned
Admin Shop line.

The goal is to make `/admin/shop` a mobile-first operator screen that clearly
separates:

- Admin catalog actions: edit, status, archive, delete, order review;
- Web3 payment road: checkout, payment intent, memo and watcher match.

## Code entry

New component:

`frontend/src/components/admin/AdminShopWeb3SeparationPanel.tsx`

Applied page:

`frontend/src/pages/admin/shop.tsx`

## UI Kit usage

The panel uses the shared Admin UI Kit:

- `AdminSectionHeader`;
- `AdminFilterBar`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminConfirmationBlock`;
- `AdminEmptyState`;
- `AdminStatusBadge`.

This keeps Shop Admin consistent with Bank, Users and Withdrawals UI Kit
adoption.

## Sandbox donor patterns

The implementation adapts previously opened Sandbox patterns:

- section cards;
- interactive chart-like area;
- mobile data deck;
- list/detail selection;
- operator flow map;
- MaterialM-style dashboard cards.

No Sandbox source is copied directly. The patterns are adapted to EFHC Bot
code, data and canon.

## Payment boundary

Admin Shop must not become a raw Web3 payment UI.

Allowed in Admin:

- catalog item editing;
- status and archive control;
- force-fulfill operator review;
- order list and selected order visibility;
- Web3 readiness indicators.

Forbidden on normal Admin surface:

- raw endpoint dump;
- editable memo payload;
- user-facing checkout impersonation;
- treating free incoming payment + memo as creditable;
- enabling USDT live checkout before real jetton payload exists.

## SSOT alignment

The panel follows:

- `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md`;
- `docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md`;
- `docs/SSOT/TON_MEMO_SPEC.md`;
- `docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md`.

## Green CI checkpoint

The user supplied `logs_71469302879.zip` and stated that logs are green.
The log was checked and Gate summary confirms all gate steps passed.
work pass records this as a release confidence checkpoint before continuing
planned Shop Admin work.

## Acceptance

work pass is accepted when:

- `/admin/shop` uses `AdminShopWeb3SeparationPanel`;
- the page no longer opens with route diagnostics as the main surface;
- Admin actions and Web3 payment flow are visibly separated;
- mobile-first readability is preserved;
- UI Kit components are actually used;
- documents, report and architecture guard exist;
- CI/workflow files are not changed silently.
