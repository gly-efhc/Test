# ADMIN_AUDIT_FIXES_RECOVERY

Status: ADMIN RECOVERY RECORD
Version: v169_39
Source audit: `docs/history/legacy_artifacts/docs/audits/TZ_FIXES_AUDIT_v169_35.md`

## Admin fixes closed

- `/admin/*` pages no longer render public bottom navigation from `Layout.tsx`.
- `AdminSalePackagesPage.tsx` is no longer read-only-only: create, edit and
  toggle backend routes are wired with `Idempotency-Key`, loading state and
  modal confirmation.
- `AdminPage.tsx` now has a component-level `LayoutContext.isAdmin` guard as a
  second protection layer behind the global route guard.
- Admin EFHC deposit processing now sends frontend idempotency keys for manual
  process and replay paths.
- No-prefix backend route exceptions are documented for `me_routes.py` and
  `system_routes.py`.

## Boundary still active

Sale Packages remains marked outside release-core truth until a future SSOT
promotion decision. The UI now supports controlled operator maintenance, but it
must not silently replace the canonical Shop/Bank economic road.


## Recheck update

The follow-up recheck found and closed two small tails:

- the Sale Packages page no longer shows a stale `read-only` badge after mutation wiring;
- the adjacent EFHC deposit force-fulfillment POST now sends a frontend `Idempotency-Key`.

These changes preserve the existing boundary: Sale Packages stays outside release-core truth until a future SSOT promotion decision.

## Residual test-scope update

The admin smoke E2E scope now includes the previously missing admin pages:

- `/admin/sale-packages`;
- `/admin/efhc-deposits`;
- `/admin/hub`;
- `/admin/referrals`;
- `/admin/templates`;
- `/admin/ads`.

This is a smoke coverage correction only. It does not claim full browser CI
execution in this local pass.

