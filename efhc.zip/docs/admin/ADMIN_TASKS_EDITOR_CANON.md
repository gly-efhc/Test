# ADMIN TASKS EDITOR CANON

Статус: **ACTIVE — рабочий этап Admin Tasks / v173.44 candidate**.

## 1. Назначение

`/admin/tasks` — единая операторская поверхность управления заданиями EFHC.
Она объединяет каталог, создание, просмотр, редактирование, безопасную
деактивацию/удаление, пользовательские submissions, модерацию, банковское
начисление бонуса, execution trace и обслуживание task-completion locks.

## 2. Canonical модель задания

Admin Editor управляет полями:

- `code` — уникальный стабильный код;
- `title`, `description`;
- `type`/API alias `kind`;
- `active`/API alias `is_active`;
- `bonus_efhc` — бонусный EFHCb;
- `price_usd_hint`;
- `limit_per_user`;
- `total_limit`;
- `proof_type`, `proof_hint`;
- `meta`.

`performed_count` является runtime-статистикой и доступен только для чтения.
После появления истории изменение `code` блокируется, чтобы не разорвать
связи со статусами, начислениями и idempotency-locks.

## 3. Безопасное удаление

Основной способ убрать задание из пользовательской выдачи — деактивация.
Физический `DELETE /admin/tasks/{task_id}` разрешён только если отсутствуют
все известные категории истории:

- `task_submissions`;
- `user_tasks_status`;
- `task_bonus_log`;
- `task_complete_lock`.

Если хотя бы одна категория присутствует, backend fail-closed возвращает
`409` с блокирующими счётчиками. История не удаляется каскадно через Admin UI.

## 4. Submissions и модерация

`GET /admin/tasks/{task_id}/subs` остаётся основной очередью пользовательских
заявок. Business owner заявки — `global_id`; `tg_id` допустим только как
nullable Telegram delivery metadata для уведомления.

`POST /admin/tasks/submissions/{submission_id}/moderate` сохраняется как operation path approve/reject.

Approve является одной caller-owned root DB transaction:
`submission FOR UPDATE -> Task total-slot reservation -> bank bonus nocommit -> submission approved/paid/paid_tx_id -> required Admin audit -> notification outbox -> one commit`.

`total_limit` применяется ко всем reward paths одинаково; successful approve атомарно увеличивает `performed_count`. Exhausted task fail-closed не создаёт payout. `paid_tx_id` обязан ссылаться на canonical transfer log `TxResult.created_log_id`.

Reject не создаёт payout, но как state-changing Admin operation также обязан иметь required Admin audit. Внешняя Telegram/network delivery выполняется только после successful DB commit.

## 5. Maintenance

Историческое имя `/admin/tasks/refresh-statuses` сохранено как compatibility
boundary, но операция **не синхронизирует статусы заданий**. Она запускает
`tasks_autorestart.run_once()` и удаляет только старые `credited=true` записи
`task_complete_lock` по `TASKS_LOCK_RETENTION_DAYS`. UI называет действие
«Обслуживание task locks» и показывает retention/result.

## 6. Реклама

Управление рекламными провайдерами не дублируется внутри Tasks Editor.
Отдельная Admin-страница `/admin/ads` показывает реальный registry и
конфигурационную готовность `builtin_timer` и `adsgram`; значения секретных
ENV в браузер не выдаются и из браузера не записываются.

Tasks Editor создаёт задания типа `watch_ad` и сохраняет их canonical task
поля/metadata. Текущий пользовательский Tasks player использует
`builtin_timer`. Backend `/ads/slot` также имеет `adsgram` branch, однако
наличие отдельного Adsgram frontend-player в рабочий этап Admin Tasks не подтверждено.

## 7. Historical evidence

### `crud/admin/admin_tasks_crud.py` из v171.89

Файл не содержал Task CRUD. Он был агрегатором/re-export следующих чужих
Admin capabilities: BANK/transfers, TON inbox, withdrawals и Shop status
utilities. Возвращать его под именем Tasks означало бы восстановить ложную
архитектурную границу. Его функции распределены для последующего решения:
Shop — этап Shop; financial/status — 1723; TON inbox — 1724; Withdraw — 1726.

### `scheduler/jobs/job_tasks_maintenance.py` из v171.89

Файл был пустым bridge-marker: кроме комментария и future import функции
не содержал. Реальное task maintenance тогда и сейчас реализовано через
`tasks_maintenance -> tasks_autorestart.run_once`.

Проверка входящих TON-транзакций по времени — **другой контур**:
`check_ton_inbox` / `job_ton_watcher`. Он обрабатывает новые платежи,
повторно обрабатывает незавершённые записи и периодически вызывает
`reconcile_last_hours`. Поэтому task maintenance и TON watcher не являются
дублями и не должны объединяться.

## 8. Preservation law

Все маршруты Tasks Editor, submissions/moderation, maintenance boundary,
Admin Ads registry и связанные service entrypoints входят в защищённую
application surface. Отсутствие frontend caller не является основанием для
удаления. Любое последующее удаление требует отдельного решения пользователя
и полного Fail-Closed Delete proof.

## 9. Verification status

Код рабочий этап Admin Tasks локально не тестировался и не собирался. Статус изменений:
`PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
