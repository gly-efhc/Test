# Admin routes map — work pass

Purpose: inventory current Admin frontend pages and backend route files.

## Canonical Admin home sections

- Users — `/admin/users`
- Bank — `/admin/bank`
- Withdrawals — `/admin/withdrawals`
- Shop — `/admin/shop`
- Tasks — `/admin/tasks`
- Reports — `/admin/reports`
- Diagnostics — `/admin/diagnostics`
- System — `/admin/system`

## Frontend Admin pages

- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `frontend/src/pages/admin/diagnostics.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/hub.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/sale-packages.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/system.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/templates.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`

## Backend Admin route files

- `backend/app/routes/admin_ads_routes.py`
- `backend/app/routes/admin_logs_routes.py`
- `backend/app/routes/admin_panels_routes.py`
- `backend/app/routes/admin_referral_routes.py`
- `backend/app/routes/admin_routes.py`
- `backend/app/routes/admin_sale_packages_routes.py`
- `backend/app/routes/admin_shop_routes.py`
- `backend/app/routes/admin_tasks_routes.py`
- `backend/app/routes/admin_templates_routes.py`
- `backend/app/routes/admin_users_routes.py`
- `backend/app/routes/admin_withdrawals_routes.py`

## Policy

- No admin route was removed in this cycle.
- Technical diagnostics stay in Diagnostics, not on Admin home.
- Additional pages may exist, but the Admin home canonical grid starts with eight sections.

## work pass update — Admin Users

`/admin/users/search` accepts an empty `q` value for first-load latest-users
mode. The same route also supports `global_id` prefix and username prefix search.
Sensitive user actions remain protected by `Idempotency-Key` where they modify
state.

## v169_01 / work pass — Bank visual and ledger boundary

Admin Bank page now uses these canonical routes:

- `GET /admin/bank/balance` — current bank balance;
- `GET /admin/reports/overview` — bank/users/panels statistics for KPI cards;
- `GET /admin/logs/transfers?limit=12` — ledger snapshot for the bank page;
- `POST /admin/bank/mint` — confirmed mint action with Idempotency-Key;
- `POST /admin/bank/burn` — confirmed burn action with Idempotency-Key.

The Bank page must not show route diagnostics or endpoint proof blocks in the
operator surface. Diagnostics belong to Admin Diagnostics.

## v169_04 / work pass — Admin interactive dashboard

Admin home now contains an interactive banking simulator dashboard powered by
`GET /admin/reports/overview`. The current route remains `/admin`; no new
route was required. The dashboard is a frontend analytical shell over existing
facts/counters and can later be wired to true time-series routes.

## v169_34 / work pass — Admin docs and SSOT route map refresh

work pass adds the current Admin route map:

`docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`

It maps Admin surfaces to frontend pages, applied Admin UI Kit components,
backend roads and strongest SSOT/NORM sources. The map reflects work pass and supersedes stale route inventory fragments that predate the
Admin UI Kit and public UI wave.

Canonical Admin surfaces remain:

- `/admin`;
- `/admin/bank`;
- `/admin/users`;
- `/admin/withdrawals`;
- `/admin/shop`;
- `/admin/tasks`;
- `/admin/reports`;
- `/admin/diagnostics`;
- `/admin/system`.

Additional Admin pages are still part of the inventory:

- `/admin/ads`;
- `/admin/efhc-deposits`;
- `/admin/hub`;
- `/admin/logs`;
- `/admin/panels`;
- `/admin/referrals`;
- `/admin/sale-packages`;
- `/admin/templates`.

Boundary: Diagnostics is the only normal surface that may show route health
and technical labels. Normal operator pages must not show raw endpoint dumps
or public Admin internals.

## v169_35 / work pass — Admin regression proof link

work pass adds `docs/admin/ADMIN_REGRESSION_PROOF_PASS.md` and
`reports/generated/admin_regression_proof_v169_35.json` as the active proof
layer over this legacy route inventory and the refreshed route-map.

This legacy map remains an inventory/reference document. The proof matrix is
the current place for PASS / PASS_WITH_NOTE / DEFERRED / FAIL verdicts.

