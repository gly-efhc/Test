# ADMIN_WITHDRAWALS_MOBILE_DECISION_PANEL

Дата: 2026-05-27  
Цикл: 1328  
Архив: `EFHC Bot v169_07 release archive for withdrawals_mobile_decision_panel`  
Статус: active canon / implementation evidence

## 1. Назначение

work pass переводит `/admin/withdrawals` из прежнего смешанного списка с
диагностическим верхом в mobile-first операторскую decision panel.

Главная задача: сделать Withdrawals рабочей state-machine панелью для
оператора, где на смартфоне сразу видны:

- статусная зона заявки;
- сумма;
- кошелёк;
- выбранный кейс;
- outcome preview;
- путь оператора от заявки до финального результата.

## 2. Ответ пользователя

Пользователь подтвердил:

1. Withdrawals нужно делать как строгую state-machine операторскую панель.
2. Приоритет — `mobile-admin` читаемость.
3. Desktop-admin является дополнительной функцией, а не главным контуром.
4. Песочницу нужно использовать активно как donor-source функций и элементов.
5. Песочница даёт код и пример того, как внедрять множество функций с полной
   адаптацией под EFHC Bot.

## 3. Использованные sandbox-паттерны

Физически открыта `Песочница.xz`.

Корень: `EFHC_SANDBOX_COMPACT_v002`.

Использованы паттерны:

- `ui-main/.../dashboard/components/chart-area-interactive.tsx` —
  интерактивные фильтры и mobile-select подход;
- `ui-main/.../dashboard/components/section-cards.tsx` — KPI/section cards;
- `ui-main/.../dashboard/components/data-table.tsx` — mobile drawer/list/detail
  мышление, выбор строки/карточки, operator row actions;
- MaterialM dashboard cards — плотные dashboard-блоки без raw/debug текста;
- Telegram WebApp admin/shop examples — карточная мобильная поверхность.

Прямого копирования зависимостей `recharts`, `@tanstack/react-table`, `dnd-kit`
и чужого UI registry не выполнено. Паттерны перенесены как EFHC-native React/CSS
слой на текущих зависимостях проекта.

## 4. Реализация

Добавлен компонент:

`frontend/src/components/admin/AdminWithdrawalsMobileDecisionPanel.tsx`

Компонент подключён к:

`frontend/src/pages/admin/withdrawals.tsx`

Новая панель содержит:

- mobile-first section header;
- статусные фильтры `PENDING / PAID / REJECTED / CANCELED / ERROR`;
- VIP/all переключатель;
- preview mode переключатель;
- KPI-карточки;
- state-machine flow map:
  - `Заявка`;
  - `Hold`;
  - `Payout`;
  - `Outcome`;
- mobile decision deck с карточками заявок;
- selected-case action table;
- guard-блок защиты финальных статусов;
- refresh и hold/refund consistency actions.

## 5. Канон state-machine

Операторская интерактивность не меняет экономику withdraw.

Активная дорожка:

`PENDING → PAID / REJECTED / CANCELED`

`ERROR` остаётся exceptional-review контуром.

Финальные статусы не должны перезаписываться случайно.

## 6. Что убрано с верхней admin-поверхности

С `/admin/withdrawals` убран верхний `AdminRouteHealthStrip`.

Диагностика маршрутов не должна быть главным видимым блоком операторского
экрана. Технические route-path сведения должны жить в Diagnostics / audit docs,
а не в нормальной рабочей поверхности администратора.

## 7. Public UI вопрос

Пользователь спросил, возможно ли добавить интерактивности для пользовательского
интерфейса.

Ответ: да, возможно. Но public UI интерактивность должна идти отдельным
маршрутом и не смешиваться с Admin UI.

Зафиксированный будущий маршрут:

`Public UI interactive upgrade wave`

Возможные элементы:

- live energy cards;
- interactive progress rings;
- panel activation preview;
- exchange amount preview;
- animated task progress;
- referrals/ranks filters;
- history filters;
- mobile-first disclosure blocks.

## 8. Запреты

Запрещено:

- превращать Withdrawals в static-only список;
- возвращать route diagnostics на главный операторский экран;
- скрывать pending decision path;
- менять экономику withdraw через UI;
- обходить TonConnect / approve / reject confirm-flow;
- смешивать public UI и admin UI;
- копировать sandbox-зависимости без migration decision.

## 9. Следующий шаг

Следующий логичный цикл:

`1329 — Shop admin actions and Web3 payment separation on UI Kit`

Отдельный будущий маршрут для public UI:

`Public UI interactive upgrade wave` после завершения admin adoption wave или
по прямому назначению пользователя.
