<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN_TASKS_EXECUTION_TRACE_BOUNDARY

Version: v169_21 / work pass  
Date: 2026-05-30  
Status: active admin canon

## Purpose

work pass extends `/admin/tasks` with an admin-only execution trace
boundary.

The goal is to let an operator see sanitized task reward traces without
returning a hidden task execution history to the public user interface.

## Code entry

New component:

`frontend/src/components/admin/AdminTasksExecutionTracePanel.tsx`

Applied page:

`frontend/src/pages/admin/tasks.tsx`

## Data source

The panel uses the existing admin logs route:

`/admin/logs/transfers?reason=task_bonus`

This is an admin-only ledger slice. It does not create a new public Tasks
history surface.

## Boundary

Allowed on Admin Tasks:

- sanitized task bonus trace;
- transfer id;
- global_id as admin operator context;
- amount;
- direction;
- balance type;
- short idempotency-key fingerprint;
- created_at;
- refresh and cursor load action.

Forbidden:

- raw meta dump;
- raw cursor payload display;
- public Tasks execution history;
- direct UI payout bypass;
- changing task reward economics from frontend;
- exposing hidden task execution log on public `/tasks`.

## UI Kit usage

The panel uses:

- `AdminSectionHeader`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminConfirmationBlock`;
- `AdminEmptyState`;
- `AdminErrorState`;
- `AdminStatusBadge`.

## Acceptance

work pass is accepted when:

- `/admin/tasks` imports and renders `AdminTasksExecutionTracePanel`;
- the trace source is `/admin/logs/transfers?reason=task_bonus`;
- idempotency keys are shortened in UI;
- raw `meta` and raw cursor payloads are not displayed;
- public Tasks hidden execution log remains forbidden;
- docs, report and guard exist;
- CI/workflow files are not changed.
