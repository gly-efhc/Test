<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN_DASHBOARD_UI_KIT_CANON

Version: v169_05 / work pass
Date: 2026-05-27
Status: active Admin Dashboard UI Kit canon

## Canon statement

Admin is a Russian operator contour and must develop as an interactive
financial-energy dashboard, not as a static text console.

work pass introduces the first Admin Dashboard UI Kit foundation.
The UI Kit is not decoration. It is a reusable layer for Admin screens
and is connected to the active work pass interactive dashboard.

## Required foundation components

The foundation component file is:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

It exports:

1. `AdminKpiCard`
2. `AdminChartCard`
3. `AdminFlowMapCard`
4. `AdminFilterBar`
5. `AdminActionTable`
6. `AdminStatusBadge`
7. `AdminConfirmationBlock`
8. `AdminEmptyState`
9. `AdminErrorState`
10. `AdminSectionHeader`

## Applied screen

The active applied screen is:

`frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`

It uses the UI Kit for:

- section header;
- metric and game-window filters;
- chart card shell;
- KPI cards;
- flow map;
- selected-step action table;
- overview empty/error states.

## Visual canon

The Admin UI Kit must keep:

- dark Web3/admin surface;
- readable mobile-safe spacing;
- soft glow / glass effects only where readable;
- Russian operator wording;
- business actions separated from diagnostics;
- dangerous actions behind explicit confirmation;
- no endpoint/raw payload/debug dump on normal admin surfaces.

## Interaction canon

Admin dashboard components must support interactive use:

- filter buttons;
- click handlers;
- live refresh / live indicators where relevant;
- chart or chart-like visual blocks;
- selected state;
- empty and error states that do not look like fake success.

## Boundary

The UI Kit must not alter EFHC economic logic.
It must not change:

- `1 EFHC = 1 kWh`;
- panel activation 100 EFHC;
- bank ledger debit/credit canon;
- withdraw final statuses;
- `global_id` as external route/service identifier.

## Dependency boundary

work pass does not perform dependency migration.
Next.js 16 / React 19 / Tailwind CSS v4 are fixed as target canon in
frontend code-standard documents, but actual dependency migration must
be a controlled migration pass with build and lock-file validation.
