# Admin Reports Export / Download Boundary — work pass

## Status

Implemented in `v169_23`.

## Purpose

`/admin/reports` now has a mobile-first export/download boundary for the
existing reports overview snapshot. The export layer is read-only and does
not add backend mutations, CI actions, raw SQL dumps or payment actions.

## Sandbox donor sources

The cycle used the uploaded `Песочница.xz` archive as a donor source.
The relevant patterns were opened and adapted, not copied directly:

- Refine `useExport` examples — export action model and row mapping;
- Refine `ExportButton` examples — simple operator download trigger;
- TMA `downloadFile` reference — mobile download intent pattern;
- previous `ui-main` data-table/list-detail pattern from Reports cycle.

No sandbox dependency was added to EFHC. The implementation uses
browser `Blob`, `URL.createObjectURL`, React state and the shared Admin UI
Kit.

## Files

- `frontend/src/components/admin/AdminReportsExportDownloadPanel.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_admin_reports_export_download.py`

## Allowed export formats

- JSON;
- CSV;
- TXT.

All formats are generated client-side from the already loaded
`/admin/reports/overview` response.

## Sanitized export scope

Allowed data:

- `meta.ok`;
- `meta.ts`;
- `counters.*`;
- `facts.*`;
- optional `notes`.

Forbidden data:

- raw SQL;
- raw API payload dump;
- raw cursor/internal route payload;
- bank ledger mutation;
- task reward mutation;
- withdrawal decision action;
- CI/workflow export or modification.

## Operator boundary

Reports export is an operator convenience surface. It can download a
sanitized snapshot for offline review, but it must not become a business
operation, payment action, ledger action or CI action.

## Mobile-first rule

Mobile readability is primary. The export format chips, scope chips,
notes toggle and download button are touch-sized and stack on narrow
screens.
