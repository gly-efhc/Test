# ADMIN REPORTS И OBSERVABILITY CANON

Статус: **ACTIVE / current**.

## 1. Решение пользователя цикла 1719

Шесть исследованных Admin operations получили окончательные решения:

1. `GET /admin/observability/events` — **STUBBED_DUPLICATE**. Маршрут сохраняется как compatibility boundary, но больше не читает БД и не создаёт вторую ленту событий. Причина заглушки: функциональность дублировала канонический `GET /admin/logs/transfers` и страницу Admin Logs. Заглушка обязана явно сообщать причину отключения и replacement route.
2. `GET /admin/reports/users` — **ACTIVE + UI_CONNECTED**. Полностью подключён к Admin Reports. Связь пользователей и панелей — только по `global_id`.
3. `GET /admin/reports/bank` — **ACTIVE + UI_CONNECTED**. Полностью подключён к Admin Reports. Банк использует только `bank_balance.key=EFHC_MAIN`; отдельный банковский BONUS-счёт запрещён. Ledger-агрегация отчёта считается только по `system_entity=BANK_EFHC`.
4. `GET /admin/reports/panels` — **ACTIVE + UI_CONNECTED**. Полностью подключён к Admin Reports с KPI и реальным временным рядом.
5. `GET /admin/reports/withdrawals` — **ACTIVE + UI_CONNECTED**. Полностью подключён к Admin Reports с KPI и реальным временным рядом.
6. `GET /admin/reports/deposits` — **ACTIVE + UI_CONNECTED**. Полностью подключён к Admin Reports. Основной canonical payment-intent status для ожидания — `PENDING`; подтверждение — `CONFIRMED`; manual-review состояния сохраняются как отдельная operational категория.

Дополнительно существующий `AdminObservabilityTimeseriesDashboardRuntime` подключён к `/admin/reports`. Он использует `GET /admin/observability/summary` и `GET /admin/observability/timeseries` и не создаёт synthetic series.

## 2. Admin Reports UI

Страница `frontend/src/pages/admin/reports.tsx` теперь содержит четыре независимых read-only слоя:

- существующий overview dashboard;
- новый `AdminDomainReportsDashboardRuntime` для пяти доменных отчётов;
- `AdminObservabilityTimeseriesDashboardRuntime` для общих real time-series;
- существующий sanitized export panel.

`AdminDomainReportsDashboardRuntime` одновременно запрашивает пять доменов на общем диапазоне и шаге времени. Поддерживаются диапазоны 24 часа, 7 дней и 30 дней; шаг — час или день.

### Users dashboard

KPI:

- total users;
- new in selected range;
- active today;
- users with panels;
- users with TON wallet.

Временной ряд: создание новых аккаунтов.

Ownership join `users ↔ panels` разрешён только через `global_id`.

### BANK_EFHC dashboard

KPI:

- `bank_main_balance` — единственный `EFHC_MAIN` balance;
- `credits_in_range` — системные BANK_EFHC credit operations;
- `debits_in_range` — системные BANK_EFHC debit operations;
- `net_flow_in_range` — credit минус debit за период;
- `credit_events_in_range` — число bank-side credit событий;
- `debit_events_in_range` — число bank-side debit событий;
- `total_events_in_range` — число bank-side событий за период.

Временной ряд: количество системных BANK_EFHC ledger events.

Тот же ответ содержит read-only Bank Policy: `BANK_EFHC`, `EFHC_MAIN`, начальный баланс `5 000 000`, разрешённый отрицательный банковский баланс, запрет P2P, `bank_global_id=null`, `bank_tg_id=null`, `user_owner=global_id`.

Запрещено считать отдельный `EFHC_BONUS` bank balance.

### Panels dashboard

KPI:

- active panels;
- archived/inactive panels;
- created in selected range;
- average lifetime in days.

Временной ряд: создание панелей.

### Withdrawals dashboard

KPI из DB-wide snapshot всей `withdraw_requests`:

- `total_count`;
- `pending_count`;
- `paid_count`;
- `rejected_count`;
- `canceled_count`;
- сумма `PAID` за выбранный период.

Страница `/admin/withdrawals` использует эти глобальные counters для общего status dashboard; операторский список остаётся отдельным слоем.

Временной ряд: создание заявок на вывод.

### Deposits dashboard

KPI:

- `PENDING` payment intents;
- `CONFIRMED` intents;
- manual-review states;
- error states;
- сумма подтверждённых EFHC за период.

Временной ряд: создание payment intents.

## 3. Заглушка `/admin/observability/events`

Маршрут не удаляется физически из-за Fail-Closed Delete Policy и возможных внешних consumers. Он возвращает compatibility response со статусом `disabled_duplicate`, пустым `items`, объяснением причины и replacement `/admin/logs/transfers`.

В коде route обязателен подробный комментарий, что:

- заглушка установлена прямым решением пользователя в цикле 1719;
- старый endpoint дублировал `efhc_transfers_log` feed;
- каноническая лента уже существует через `/admin/logs/transfers`;
- возвращать DB-read в эту заглушку без нового решения пользователя запрещено.

## 4. Защита release scripts

Release/ops scripts являются защищённым контуром. До завершения code phase запрещено без прямого ТЗ пользователя или конкретного GitHub CI evidence:

- удалять или переименовывать release scripts;
- менять их semantics;
- менять executable mode;
- делать cleanup/reformat только потому, что код кажется legacy;
- создавать RELEASE/MATRIX архивы автоматически.

Финальные release archives будут готовиться после завершения работы с кодом по отдельному решению пользователя.

## 5. Verification boundary

Код цикла 1719 локально не тестируется. Pytest, targeted pytest, guards, Ruff, Mypy, Flake8, Bandit, compileall, Alembic, frontend build и CI не запускаются. Результат подтверждает только следующий exact-head GitHub CI пользователя.
