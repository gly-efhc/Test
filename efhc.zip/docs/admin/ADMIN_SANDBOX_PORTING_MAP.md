# ADMIN_SANDBOX_PORTING_MAP

Version: v169_05 / historical Admin UI Kit donor map
Date: 2026-05-27
Status: active porting map for Admin UI Kit foundation

## HEAD context

This document records the Admin UI Kit donor line that followed the first
interactive Admin home banking simulator dashboard. Numeric work-pass labels are
kept in the report/audit/cycle layers, not in this product map.

## Sandbox availability in HEAD

The original sandbox archive `Песочница.xz` is an external donor source, not a
runtime dependency inside the release ZIP. This map does not claim that sandbox
source code is bundled into EFHC Bot.

The map uses verified sandbox evidence already present in HEAD:

- `docs/frontend/FRONTEND_SANDBOX_REFERENCE.md`;
- `docs/admin/ADMIN_SANDBOX_VISUAL_REFERENCE.md`;
- generated sandbox intake facts under `reports/generated/`.

## Donor pattern sources already verified in archive documents

The active sandbox donor line is based on previously inspected roots:

1. `MaterialM-Tailwind-Nextjs-Free-main/.../components/dashboard/`
   - KPI cards;
   - dashboard statistic blocks;
   - product/list cards;
   - compact chart panels.
2. `ui-main/apps/v4/.../examples/dashboard/components/`
   - interactive area chart pattern;
   - section cards;
   - data table pattern;
   - header/navigation pattern.
3. `ui-main/apps/v4/components/cards/stats.tsx`
   - compact stats card pattern.

## Porting rule

Sandbox code is not copied blindly. Every accepted pattern must be:

1. mapped to an EFHC admin purpose;
2. adapted to the Russian operator contour;
3. kept independent from public user UI;
4. connected to real Admin components;
5. guarded by a test or document check.

## Accepted for Admin UI Kit

| Sandbox pattern | EFHC Admin target | EFHC result |
|---|---|---|
| KPI cards | Admin dashboard metrics | `AdminKpiCard` |
| Interactive chart card | Banking simulator graph | `AdminChartCard` |
| Filter tabs | Metric/window controls | `AdminFilterBar` |
| Flow / node map | Bank / Users / Panels / Exchange | `AdminFlowMapCard` |
| Data table | selected step / action rows | `AdminActionTable` |
| Status badge | live / guard states | `AdminStatusBadge` |
| Confirmation block | dangerous admin actions | `AdminConfirmationBlock` |
| Empty state | no data state | `AdminEmptyState` |
| Error state | overview unavailable | `AdminErrorState` |
| Section title | dashboard headers | `AdminSectionHeader` |

## Rejected patterns

- Direct `react-apexcharts` or `recharts` adoption without dependency pass.
- Direct shadcn/Tailwind copy that assumes unavailable project setup.
- Demo-only dashboard data that looks like production truth.
- Public-user UI patterns inside Admin.
- Static screenshot/dashboard imitation.

## Applied connection

The UI Kit foundation is connected to:

`frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`

The dashboard basis must stay interactive. It must not be replaced with a static
page; reusable Admin UI Kit primitives should wrap and strengthen it.

## Next porting path

Recommended next actions:

- deepen `AdminActionTable` and `AdminConfirmationBlock` inside Bank and
  Withdrawals operator actions;
- build Users and Withdrawals pages on shared UI Kit cards;
- apply UI Kit patterns to Shop and Tasks admin screens;
- keep mobile readability and screenshot QA as a standing check.
