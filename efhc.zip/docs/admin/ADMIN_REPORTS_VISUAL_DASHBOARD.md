# Admin Reports Visual Dashboard — work pass

## Status

Implemented in `v169_22`.

## Purpose

`/admin/reports` is no longer a static counter page or route diagnostic
surface. It is a mobile-first operator dashboard for reading the current
EFHC report snapshot.

## Sandbox donor sources

The cycle used the uploaded `Песочница.xz` archive as a donor source.
The relevant patterns were opened and adapted, not copied directly:

- `ui-main` `chart-area-interactive` — range selector, mobile select logic,
  interactive chart points;
- `ui-main` `section-cards` — compact KPI cards;
- `ui-main` `data-table` — list/detail operator row pattern;
- MaterialM `EarningReports` — report row density and status badges.

No Recharts, DnD, TanStack Table or sandbox dependency was added to EFHC.
The EFHC implementation uses React state, SVG and the shared Admin UI Kit.

## Files

- `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_admin_reports_visual_dashboard.py`

## UI boundary

Allowed on `/admin/reports`:

- overview snapshot from `/admin/reports/overview`;
- KPI cards;
- scope filters: economy, users, panels;
- window filters: 7 / 14 / 30 steps;
- zoom range control;
- clickable chart points;
- read-only operator detail table;
- notes visibility without raw internal dump.

Forbidden:

- route diagnostics at the top of the normal reports page;
- raw SQL dump;
- raw endpoint payload dump;
- backend economic mutation from reports page;
- CI/workflow file changes.

## Operator meaning

Reports is a read-only operator dashboard. It can help the operator see
bank, user, panel and exchange state, but it must not mutate balances,
withdrawals, tasks, shop orders or bank ledger state.

## Mobile-first rule

Mobile readability is primary. Desktop is only an expanded layout.
The page must remain usable as a compact Telegram WebApp admin surface.
