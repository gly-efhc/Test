# ADMIN BONUSES AND MANUAL CREDITS CANON

Статус: **ACTIVE**  
Цикл утверждения: **1726**

## 1. Назначение

Раздел **«Аналитика начислений»** показывает реальные начисления EFHCb из действующих источников в read-only виде. Ручные финансовые операции не выполняются на этой странице.

## 2. Источники истины

Активная история формируется только из:

- `efhc_core.task_bonus_log` — награды за задания;
- `efhc_core.referral_bonus_ledger` — реферальные награды;
- `efhc_core.efhc_transfers_log` — ручные бонусные операции администратора через Банк EFHC.

`efhc_admin.bonus_awards` не является активной денежной таблицей. Старые `list_bonus_awards`, `process_bonus_award`, `reject_bonus_award` и `list_bonus_payouts` сохраняются только как compatibility boundary и не используются новым UI.

## 3. Единственный write-контур находится в Users

Любая ручная корректировка проходит по цепочке:

`Admin UI → POST /admin/transfer → BankService.manual_bank_user_transfer → transactions_service → BANK_EFHC ↔ USER(global_id)`.

Запрещено создавать второй денежный route, отдельную money-логику или вторую write-form для страницы аналитики начислений.

Compatibility entrypoints `credit_bonus_efhc`, `credit_regular_efhc` и `adjust_user_balance_via_bank` сохраняются и делегируют тому же BankService.

## 4. Ручная операция администратора

Ручное начисление или возврат средств выполняется только в `/admin/users` после выбора canonical Global ID. Администратор выбирает направление BANK↔user, целевое назначение EFHCb/EFHCm, сумму и редактируемый комментарий. `/admin/bonuses` только отображает результат таких операций вместе с task/referral history и аналитикой.

Audit metadata обязана содержать администратора, выполнившего ручную операцию (`admin_global_id`), чтобы история могла показывать автора действия.

## 5. Bonus и Withdraw — разные контуры

- EFHCb не выводится.
- Withdraw работает только с EFHCm.
- Bonus history не является очередью заявок на вывод.
- `admin_mark_withdraw_paid` — `REPLACED_BY_CANON`: имя сохраняется для compatibility, но новый UI использует канонический `approve_withdrawal`.

## 6. Человеческий язык

Администратор видит:

- «Основной баланс EFHCm — можно вывести»;
- «Бонусный баланс EFHCb — используется внутри приложения»;
- «Операции пользователя» — переход в `/admin/users`;
- «Аналитика начислений»;
- «За задания», «За рефералов», «Вручную администратором»;
- «Заявки на вывод», «Ожидает решения», «Выплачено», «Отклонено и возвращено»;
- «Что увидит пользователь»;
- «Обновить данные»;
- «Проверить и восстановить состояние».

Технические `MAIN/BONUS`, route names, status codes, pipeline/outcome и названия таблиц остаются внутренними контрактами и не должны быть основными подписями интерфейса.
