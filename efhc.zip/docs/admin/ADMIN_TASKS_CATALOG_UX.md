# ADMIN_TASKS_CATALOG_UX

Version: v169_20 / work pass  
Date: 2026-05-30  
Status: active admin canon

## Purpose

work pass returns to the planned Admin recovery line after the work pass
audit hotfix.

The goal is to turn `/admin/tasks` into a mobile-first operator catalog and
moderation surface instead of a route-diagnostic page.

## Code entry

New component:

`frontend/src/components/admin/AdminTasksCatalogUxPanel.tsx`

Applied page:

`frontend/src/pages/admin/tasks.tsx`

## UI Kit usage

The panel uses the shared Admin UI Kit:

- `AdminSectionHeader`;
- `AdminFilterBar`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminConfirmationBlock`;
- `AdminEmptyState`;
- `AdminErrorState`;
- `AdminStatusBadge`.

## UX decision

The top of `/admin/tasks` is no longer route diagnostics.

The first operator layer is now:

1. task catalog KPI cards;
2. queue filter for `PENDING / APPROVED / REJECTED / ALL`;
3. flow map from task card to proof moderation and reward result;
4. mobile data deck for task selection;
5. moderation status summary;
6. explicit refresh actions.

The detailed moderation list remains below the new panel and keeps the
existing approve/reject behaviour with idempotency keys.

## Boundary

Allowed on normal Tasks Admin surface:

- task catalog selection;
- proof queue filtering;
- proof preview;
- approve/reject moderation;
- manual status sync button;
- operator message after an action.

Forbidden:

- raw route diagnostics as the main surface;
- endpoint dump on the first screen;
- hidden execution log exposed to normal users;
- bypassing backend task moderation rules;
- changing reward economics from frontend.

## Mobile-first rule

Mobile-admin readability is primary. Desktop layout is only an extension.

The component uses a one-column mobile deck under small widths and keeps
button tap targets visible without relying on route diagnostics.

## Acceptance

work pass is accepted when:

- `/admin/tasks` imports and renders `AdminTasksCatalogUxPanel`;
- `AdminRouteHealthStrip` is not used on `/admin/tasks`;
- the shared Admin UI Kit is used for the Tasks catalog layer;
- existing approve/reject moderation remains connected;
- documents, report and architecture guard exist;
- CI/workflow files are not changed silently.
