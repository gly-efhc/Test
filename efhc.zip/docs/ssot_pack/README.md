# SSOT Audit Pack

Этот каталог — канонический пакет артефактов аудита/инвентаризации,
используемый как SSOT-логистика разработки.

Содержимое генерируется из кода/миграций/роутов и должно обновляться
вместе с изменениями схем, моделей, миграций и admin-surface.

Файлы:
- SSOT_TABLES_MIGRATIONS.csv
- SSOT_TABLES_ORM.csv
- SSOT_RAW_SQL_USAGE.csv
- SSOT_ROUTES.csv
- SSOT_ROUTE_TABLE_MAP.csv
- SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md
- SSOT_REFACTOR_PLAN.md
