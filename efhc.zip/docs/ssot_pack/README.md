# SSOT Audit Pack

Этот каталог — канонический пакет артефактов аудита/инвентаризации,
используемый как SSOT-логистика разработки.

Содержимое генерируется из кода/миграций/роутов и должно обновляться
вместе с изменениями схем, моделей, миграций и admin-surface.

Файлы:
- SSOT_TABLES_MIGRATIONS.csv
- SSOT_TABLES_ORM.csv
- SSOT_RAW_SQL_USAGE.csv
- SSOT_ROUTES.csv
- SSOT_ROUTE_TABLE_MAP.csv
- SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md
- SSOT_REFACTOR_PLAN.md

## Canon snapshot (v150_07)

Схемы: efhc_core, efhc_admin.
Таблиц (ORM): 39 (core 33, admin 6).
Маршруты: см. SSOT_ROUTES_NUMBERED.csv (нумерация канонична).
NO_DB обязательные маршруты присутствуют:
- GET /health
- GET /cron/tick
- GET /admin/ads/providers
- GET /nft/has_vip
- GET /skins/catalog

Примечание:
SSOT обновлён для включения efhc_core.unmatched_incoming и
описаний EFHC main/bonus/jetton в TERMS_GLOSSARY.md.
