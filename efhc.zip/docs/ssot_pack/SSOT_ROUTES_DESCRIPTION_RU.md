# SSOT: Маршруты EFHC Bot (описание)

Статус: **SSOT (истина)**. Этот файл объясняет, как описываются маршруты и их связь с таблицами/миграциями.

## 1) Что такое «маршрут» в SSOT
Маршрут — это публичный HTTP surface (METHOD + PATH), реализованный декоратором в `backend/app/routes/**`.

## 2) SSOT-файлы про маршруты
- `SSOT_ROUTES.csv` — реестр всех маршрутов (method/path + file/line).
- `SSOT_ROUTES_NUMBERED.csv` — нумерация маршрутов (для работы «по списку»).
- `SSOT_ROUTE_TABLE_MAP.csv` — какие таблицы читает/пишет каждый маршрут + evidence `file:line`.
- `SSOT_ROUTES_TABLES_MIGRATIONS.csv` — свод «маршрут → таблицы → (создаёт ли 0001)».

## 3) Как доказываются таблицы (evidence)
Таблицу нельзя писать «по ощущениям». Доказательство — только:
- явный SQL `FROM/INSERT/UPDATE schema.table`,
- ORM `select(Model)` / `session.query(Model)`.

В SSOT всегда указываем `evidence_refs=file:line`.

## 4) Экономическое правило (денежно-опасные операции)
Любая операция типа hold/refund/commit (списания/зачисления/логи переводов) должна проходить через `services/transactions_service.py`.
Прямые `UPDATE users.balance` или `INSERT efhc_transfers_log` в обход сервиса — нарушение канона и подлежит удалению/переносу на сервис.

## 5) Канон согласования
Всегда согласуем одновременно:
**код → маршрут → таблица → миграции**.
