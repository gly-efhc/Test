# DIAGNOSTIC: Инвентаризация схем / таблиц / маршрутов

Актуальный SSOT-срез без исторического шума.

## Числа

- схемы: **2** (`efhc_core`, `efhc_admin`)
- ORM-таблицы: **38**
- HTTP-маршруты: **92**
- test files: **74**

## Источники

- `docs/ssot_pack/SSOT_TABLES_ORM.csv`
- `docs/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`
- `tests/**/test_*.py`

## Правило

Этот документ фиксирует только текущий срез. Исторические расхождения
и старые цифры живут в `docs/audits/`.
