# Removed frontend alias page

Removed stale `frontend/src/pages/shop.tsx` alias.
