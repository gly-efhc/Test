# EFHC Bot — техническое описание (RU, SSOT)

EFHC Bot — Telegram WebApp + FastAPI backend + admin surface для
энергетической экономики EFHC.

## Актуальный обзорный срез

- схемы БД: **2** (`efhc_core`, `efhc_admin`)
- ORM-таблицы: **38**
- HTTP-маршруты: **92**
- test files: **81**
- миграции: единая `0001_init.py`

## Назначение проекта

Проект учитывает пользователей, панели, генерацию энергии, обмен
kWh→EFHC, магазин, lotteries, referrals, wallets и admin-контур.

Базовый экономический канон:

- `1 EFHC = 1 kWh` внутри игры;
- `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`;
- вывод только из `main_balance`;
- `bonus_balance` не выводится;
- все деньги идут через банк EFHC.

## Компоненты

1. Telegram Bot и WebApp.
2. Backend API и бизнес-логика.
3. Scheduler / watchers / self-healing.
4. Admin surface и аудит действий.

## Источники истины

- `docs/EFHC_CANON.md`
- `docs/OVERVIEW_SSOT_SYNC.md`
- `docs/ssot_pack/*`
- `backend/migrations/versions/0001_init.py`
- `tests/**/test_*.py`

## Примечание

Исторические аудиты могут описывать старые состояния проекта. Для
старта нового цикла использовать только текущий обзорный SSOT.
