<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## 1217-1218 healer note

Symptom: Tasks page looked like a technical list and buttons could look
broken when disabled.
Treatment: compact earning cards, self-routes, and human disabled-state
explanations.

## v168_23 healer note — work pass

Symptoms:

- profile language control did not match the new one-button dropdown
  canon;
- Browser-Shop pay action created an intent but did not open the wallet
  transaction flow from `tonconnect_tx`;
- reference visual sandbox needed intake without executing foreign code.

Treatment:

- replaced language rail with current-language dropdown button;
- added guard coverage for the dropdown;
- connected Browser-Shop payment to `tonConnectUI.sendTransaction`;
- added reference sandbox intake document.

Remaining risks:

- full wallet-send runtime proof requires real wallet/browser testing;
- desktop browser shell is planned, not implemented in this cycle.

# VISUAL UI HEALER CASE 1195-1230

Status: open Healer case.
Source: visual TZ v002 and visual QA 100 v002 imported on
2026-05-16.

## Disease

Public visual roads expose internal operator/payment diagnostics and
mix three different roads: Direct Deposit, HUB and Browser Shop.

## Symptoms confirmed in current HEAD

- DepositModal still references shop launcher truth and active intent.
- HUB still exposes contour, truth-layer and handoff facts.
- Browser Shop still exposes endpoint, intent, wallet, memo, SKU and
  status concepts in public code.
- browser-shop is still wrapped by the common Layout from _app.
- Direct Deposit backend remains package-oriented and not proven as a
  free amount direct deposit road.

## Treatment plan

- Separate the three roads.
- Move diagnostics to admin/diagnostics.
- Clean public strings and layout.
- Add guards for public forbidden terms, layout boundary, admin fields
  and direct-deposit versus shop-payment split.

## Open status

Partially treated in v168_18 for profile language switching.  Open
until Direct Deposit, HUB and Browser-Shop public visual blockers are
repaired by code and guards.


## v168_18 treatment note

Profile language switching was a confirmed public UX blocker.  Runtime
UI labels now follow the selected profile language, settings persistence
is hydration-gated, and a horizontal language bar replaced the old grid.
This does not close Direct Deposit, HUB or Browser-Shop blockers.

## v168_19 treatment note

Direct Deposit was treated for work pass.

- Public DepositModal no longer uses shop launcher truth.
- GlobalHeader direct deposit button is the canonical `+`.
- Backend has a separate direct wallet-open route without `package_id`.
- Guard evidence was added for modal, header, backend split and locale
  keys.

Remaining disease areas:
- HUB still needs public two-action cleanup proof.
- Browser-Shop still needs layout separation and public diagnostics
  removal.
- Browser screenshot proof and GitHub CI were not run.

## v168_20 treatment note

HUB public diagnostics leakage was treated in work pass.

- Public HUB now renders only two approved actions.
- Diagnostic imports and truth/readiness/status blocks were removed
  from the public page.
- Technical HUB route and truth references were moved to admin
  diagnostics.
- Guard evidence was added for the public HUB boundary.

Remaining disease areas:

- Browser-Shop still needs layout separation.
- Storefront still needs public diagnostics and admin-field cleanup.
- Browser screenshot proof and GitHub CI were not run.

## v168_21 work pass

Repaired Browser-Shop shell boundary.  `/browser-shop` now uses a
dedicated `ShopLayout` instead of the common Mini App `Layout`.  The
storefront top zone contains avatar, EFHC balance and Profile link.

The 100 visual Q/A answers were also written into the main Q/A register
after audit showed they had been imported only into the audit layer.

Remaining Healer tails: storefront product cards, admin fields,
wallet/memo/copy and payment diagnostics still need cleanup.

## Healer note v168_22 work pass

Symptom: Browser-Shop was already outside the common Mini App layout,
but it still behaved like an operator console inside the page body.

Cause: older storefront content mixed public cards with diagnostics,
manual payment details, SKU rows and payment-chain facts.

Treatment:

- public Browser-Shop was rewritten to a clean storefront card grid;
- manual wallet/memo/copy blocks were removed from the public path;
- Browser-Shop payment diagnostics were moved to admin diagnostics;
- guard `test_browser_shop_public_cleanup_guard.py` was
  added.

Residual risk: Pay still needs immediate wallet-open proof in a later
cycle.


## v168_24 work pass healer note

Closed finding:
- Browser-Shop payment did not poll status after wallet-open.

Repair:
- Active intent id is stored after create-intent.
- `/shopfront/intent-status` is polled while pending/checking.
- The UI shows only user-facing status language.

Additional diagnosis:
- Static route inventory found no missing frontend page routes.
- Non-reacting buttons are classified as UX/state-feedback debt unless
  a live browser proof shows a concrete broken handler.

Open healer direction:
- compress public frontend into fewer first-level actions;
- add visible disabled-state reasons;
- replace silent async actions with immediate user feedback;
- add Dragon-style visual shell only as EFHC-branded UI work.

## v168_25 work pass healer note

Symptom:

- FAQ looked untranslated after language switch;
- FAQ page width was not adapted to the bot simulation frame.

Cause:

- hardcoded English helper labels;
- no FAQ-specific compact shell.

Treatment:

- moved helper labels to locale keys;
- added compact FAQ shell CSS;
- added guard coverage.

## work pass healer note

New risk: the assistant may over-compress EFHC and accidentally collapse
canonical pages into a new Dragon-like first-button structure.

Healer rule:

- do not touch the six canonical bottom buttons;
- do not merge Panels or Exchange into another page;
- audit visible functions before removal;
- move operator/debug controls to Admin only after proof;
- ask before deleting uncertain public functions.

New technical path:

- EFHC can gain browser/PWA shell infrastructure;
- Telegram Mini App remains primary;
- browser shell is incomplete until live browser proof exists.
## v168_27 work pass healer note

Targeted remarks were converted into code-level shell corrections and
visible-function triage.  No canonical bottom navigation item was
renamed or moved.  No visible function was deleted before approval.

Remaining risk: live browser/PWA install and click-proof still require
manual browser/device verification outside static guards.


## work pass healer note

Symptom: Energy progress levels leaked into the Ranks page as an open
12-level ladder.\
Root cause: mixed Energy progression and Ranks leaderboard semantics.\
Repair: Ranks was returned to leaderboard semantics; Energy progress now
keeps the visual progress bar without public level-name exposure.\
Guard: `test_energy_ranks_boundary_guard.py`.

## v168_29 healer note — Ranks and page audit

Issue: after removing the Energy ladder from Ranks, the page still needed
compact game-style presentation.

Repair: Ranks now has compact leader cards while preserving leaderboard
meaning.  Panels, Exchange and Tasks were audited without deleting
canonical functions.

Open: Panels compact repair, Exchange compact repair and Tasks card
polish remain active future cycles.

## v168_30 healer note — Panels and Exchange compact repair

Symptoms:
- Panels had too many first-level surfaces and repeated controls.
- Panels frontend still used path `global_id` list routes.
- Exchange helper text occupied primary space even though it was
  secondary explanation.

Repair:
- Added compact Panels shell and self-user list routes.
- Kept hidden compatibility routes for old Panels list paths.
- Added compact Exchange shell and collapsed secondary details.

Risk left:
- Browser click-proof is still not claimed.
- Tasks compact earning module remains open.

## 1225 healer update

Critical symptom: user opened the frontend and saw a blank / white UI.

Healer diagnosis:

- do not rely on tg_id for rendering public app UI;
- do not block SplashScreen on non-critical locale fetch results;
- default first paint must be dark;
- Energy progress must be visible at zero state;
- page-by-page visible elements must be agreed in chat.

Repair added in v168_33 follow-up.
