## 2026-04-08 dead-but-needed modules require revival, not deletion

- Если модуль или компонент выглядит мёртвым по смысловому аудиту, но пользователь подтвердил, что он нужен, следующий шаг — не удаление, а план по подключению, ремонту и повторной интеграции.
- Дубли по таким зонам сначала сравниваются, данные переносятся, пользователю показывается предложение на согласование, и только потом допускается удаление одного из дублей.

## 2026-04-08 archival baskets must be skipped by canon guards

- После переноса старых документов в `artifacts/` guard-тесты не должны читать эту архивную корзину как активный кодовый или документный слой.
- Иначе пользовательское согласованное архивирование начинает ломать CI бан-словами и legacy терминами из исторических файлов.

## 2026-04-08 high-impact historical audit stubs must stay visible

- Даже после зачистки старых audit-файлов несколько high-impact historical docs должны оставаться в `docs/audits/`, если на них завязаны guard-тесты и continuity status-notes.
- Нельзя убирать такие документы из active docs surface, пока test-layer и control-layer ещё требуют их присутствия.

## 2026-04-08 transferred audit backbone

- Economy Healer backbone: bank split-brain, mirror direction drift, idempotency conflict drift, exchange autobegin drift, energy `_begin_tx` recursion, self-healing queue breakage, shop schema/reporting mismatch.
- Release Healer backbone: transient junk in ZIP, nested release ZIP relapse, build-script drift, confusion between transient junk and `artifacts/`.
- Frontend/UX Healer backbone: visual white spots, inconsistent loading/error/empty states, wording drift after canon updates, browser shop / hub residual mismatches.
- Process Healer backbone: false cycle closure, GitHub CI ownership drift, stale cycle-control panel, dependency-precheck drift, keeping unique errors only in old audits/reports.

## 2026-04-08 transferred reports backbone

- Старые reports перенесены из active surface; уникальная память по исправлениям должна сохраняться в Healer, cycle docs и свежих `change_cycle_*`.
- Legacy report naming (`change_report_*`, internal logs, alias sanitation reports и т.п.) больше не должен быть главным носителем решений.

## 2026-04-08 audit debt must move to Healer

- Старые audit-файлы не должны оставаться единственным носителем ошибок проекта.
- Перед будущей зачисткой `docs/audits/` нужно перенести economy, release, self-healing, frontend, cycle-control и process defects в Healer как долговременный memory-layer.
- `_raw` допустим как evidence-архив, но не как место, где живут уникальные ошибки без переноса в Healer.

## 2026-04-08 reports retention debt

- Раздел `reports/` разросся до большого исторического слоя; каноническая память должна остаться в `change_cycle_*`, а переходные/дублирующие форматы нужно разметить на `оставить / artifacts / удалить после согласования`.
- Старые internal logs и legacy report naming не должны сохранять уникальные ошибки мимо Healer.

## 2026-04-08 GitHub CI ownership reminder drift

- GitHub CI прогоны делает пользователь; ИИ не должен путать их со своими локальными вспомогательными проверками и не должен выдавать их за свои проходы.
- Это правило нужно удерживать одновременно в AI docs, циклах и чат-отчётах.

## 2026-04-08 nested release zip relapse

- build script staging captured existing `efhc.zip`, so the next archive packed the previous archive inside itself and almost doubled the release weight.
- Guard rule: before staging, delete `ZIP_OUT` in repo root and exclude it explicitly from rsync packaging.

## 2026-04-08 recursive _begin_tx residual transfer

- После фикса `energy_service` тот же рекурсивный `_begin_tx` оставался живым в `referral_service`, `wallet_binding_service` и `tasks_service`.
- Паттерн должен считаться Healer-хроникой: при отсутствии транзакции `_begin_tx` обязан вызывать `db.begin()`, а не сам себя.

## 2026-04-07 watcher/reporting residual transfer

- legacy helper paths через `shop_orders.item_id` и `shop_items` в watcher/reporting слое — хронический residual drift после смены канона shop_orders.
- сырой слой `docs/audits/_raw` должен переноситься в Healer/artifacts после картирования на активные аудиты.

## 2026-04-07 old GitHub CI log transfer

- Старые GitHub CI log-audits про `0002`, import-order и stale frontend typing/build дрейф должны считаться Healer-хроникой, а не active truth.
- Повторяющиеся `ruff I001`, stale typing/builder drifts и migration-memory conflicts — переносим в Healer даже если они уже встречались в старых логах и аудитах.

- Подмена реального GitHub CI локальными прогонами как будто это одно и то же — хроническая болезнь.
## 2026-04-07 correction wave consolidation

- Ложное закрытие циклов без реального выполнения — хроническая болезнь.
- Закрытие visual/frontend цикла без песочницы пользователя — хроническая болезнь.
- Stale временные тестовые артефакты, ломающие следующие прогоны, — хроническая болезнь.
- Отсутствие dependency-precheck (`pytest`, `ruff`, `compileall`, `mypy`, `bandit`, `sqlalchemy`, `aiosqlite`) перед циклами — хроническая болезнь.
- Старые GitHub CI log-аудиты должны передавать хронические ошибки в Healer, а не бесконечно оставаться в active audit-surface.
- Каждый новый подтверждённый CI/log defect должен в том же цикле сразу быть привязан к существующей Healer-карте или зафиксирован новой записью без отложенного переноса.

# Cycles 250-251 note — 2026-04-02

- Cycles 250-251 cleaned the main AI operator document and marked the prompt layer as reviewed historical material.
- The main AI layer now carries the primary continuity model more cleanly.

# Cycle 249 note — 2026-04-02

- Cycle 249 closed the current root helper-level merge phase as sufficiently cleaned.
- The AI layer now more strictly forbids English names for next cycles and roadmap points in chat.
- The repeated chat-language slip was treated as an AI continuity issue and fixed in the main AI docs.

# Cycle 248 note — 2026-04-02

- Cycle 248 normalized the key AI continuity docs into a more coherent Russian-facing layer.
- The current continuation prompt now reflects the line after cycle 247.
- Mixed-language wording remains acceptable only in secondary AI materials where precision benefits from it.

# Cycle 247 note — 2026-04-02

- Cycle 247 applied a controlled helper-level consolidation to the wallet/TON root cluster.
- The dynamic wallet-connect test pack now shares a testkit, while static SSOT and route guards remain explicit.
- The root merge phase is now close to saturation and may only need a final cleanup review.

# Cycle 246 note — 2026-04-02

- Cycle 246 applied a controlled helper-level consolidation to the root panels tests.
- Explicit scenario guards were preserved; only duplicate reload and seed boilerplate were consolidated.
- The panels cluster is no longer the strongest remaining root merge candidate.

# Cycle 245 note — 2026-04-02

- Cycle 245 applied a controlled helper-level consolidation to the concurrency root tests.
- The local verification also revealed two collection-shape hazards, which were corrected pointwise.
- The main AI doc now explicitly requires asking the user first when something is unclear.

# Cycle 244 note — 2026-04-02

- Cycle 244 fixed the final priority ladder in the main AI doc.
- Drift must now be reported, agreed through Q&A and only then synchronized.
- AI menu now has a START HERE marker for quick entry into the AI layer.

# Cycle 243 note — 2026-04-02

- Cycle 243 added a fast startup/communication protocol for new chats.
- Prompt files are now explicitly treated as secondary archival traces rather than the main continuity carrier.
- SSOT and NORM are explicitly treated as very important instruction-memory layers.

# Cycle 242 note — 2026-04-02

- Cycle 242 structurized the AI layer into index + brain/memory model + current continuation prompt.
- The archive is now explicitly modeled as a complement to the chat and as part of long-term continuity memory.
- `WORK_CYCLES.md` is explicitly treated as both memory and roadmap.

# Cycle 241 note — 2026-04-02

- Cycle 241 aligned the AI layer with the user's framing: AI docs are the working brains/prompt-layer, while logs, Q/A, Healer, registries and reports are the memory layer.
- The planned queue was renumbered so the former 241–242 entries now continue as 242–243.
- Chat-facing cycle naming remains Russian-only.

# Cycle 240 note — 2026-04-02

- Cycle 240 performed an AI continuity sweep after the previous chat audit and controlled test merge wave.
- The AI layer now explicitly records that user-facing cycle descriptions must be sent in Russian.
- Internal AI documents may remain in English or mixed language when this preserves precision and continuity.

# Cycle 239 note — 2026-04-02

- Cycle 239 applied a controlled helper-level merge wave for the payment-intents root tests.
- The refactor initially exposed a collection-time import risk and was corrected pointwise by moving `sqlalchemy` import inside the helper function.
- Explicit scenario tests were preserved; only duplicate setup helpers were consolidated.

# Cycle 238 note — 2026-04-02

- Chat audit confirmed AI-doc drift against the current post-233 continuation state.
- AI active docs were synchronized in cycle 238.
- Tests catalog was rebuilt into active / merge-review / retired sections.

Cycle 237 note: latest CI log `logs_63001257876.zip` is green; no fresh blocker surfaced, so the cycle was used for manual review/clustering of the root integration/concurrency/payment tests instead of speculative code churn.

Cycle 236 note: manual cleanup wave retired stale pre-reorg architecture lock tests that were failing only because they still required removed or relocated docs; active path-sensitive tests were synchronized to the new docs layout, and fresh line72/canon-guard blockers were fixed.

Cycle 235 note: fixed post-install CI blocker from `logs_62998295115.zip`; alembic 0001 sanity was reading `SSOT_TABLES_ORM.csv` from stale pre-reorg path `docs/ssot_pack/...` instead of `docs/SSOT/ssot_pack/...`. Also removed duplicate `__future__` imports and fixed ruff import blocks in two route files.

Cycle 234 note: fixed CI install blocker from `logs_62996991668.zip`; `backend/requirements.txt` contained an uncommented narrative bullet that broke `pip install -r ...` before pytest. Added test-layer audit plan and candidate stale-lock inventory.

Cycle 73 note: froze Hub admin entity design around `hub_links`; admin migration must remove price/order semantics from the future Hub links manager while keeping legacy `/admin/shop` as a temporary alias.

Cycle 69 note: aligned VIP user-facing layer to external GetGems semantics in active runtime FAQ and locale help-texts; Hub no longer suggests buying VIP NFT inside Shop-level wording.

Cycle 68 note: added first backend/frontend Hub EFHC handoff layer; `/hub/efhc-handoff` now issues a signed token and Hub EFHC card opens the external URL only after backend response, with fallback modal when buy-flow URL is not configured.

# HEALER_ATLAS

Cycle 66 note: removed residual Shop/store wording from active Russian runtime FAQ section 13 and wallet answer 5-1; Hub user-facing layer now states only external EFHC flow, external VIP via GetGems and skins as 12-level rewards.

Cycle 64 note: added first route alias wave for `shop -> hub`; new user-facing entry points `/hub` and `/admin/hub` exist, bot menu opens `/hub`, legacy `/shop` alias remains.

Cycle 60 note: added `docs/SSOT/HUB_SSOT.md` as the single source of truth for Hub; cycle journal and Q&A register now reference the document for backend/frontend/admin/FAQ/QA alignment.

Cycle 56 note: Shop → Hub planning answers and future cycle descriptions were synced into the cycle journal/Q&A register; operator rules now explicitly ban justificatory phrasing in user-facing texts.

Version: 1.3.0

Cards total: 76

Cycle 29 note: Healer JSON structure re-normalized; active docs/test catalog counts resynced; active terminology drift removed from current docs layer.

## HEAL-0001 — Line72 violation

- category: `style_guard`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- L=84 > 72
- test_max_line_length_72.py failed

**Where to look**

- backend/**
- frontend/**
- tests/**

**Treatment**

- Перенести длинную строку на несколько строк.
- Для описаний Field использовать description=(...) с
- конкатенацией.

**Verification**

- pytest line72
- ruff/compileall не деградировали

## HEAL-0002 — apiRequest generics missing

- category: `frontend_types`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- Property 'items' does not exist on type '{}'

**Where to look**

- frontend/src/components
- frontend/src/pages

**Treatment**

- Добавить тип ответа и вызывать apiRequest<Resp>(...).

**Verification**

- npm run build
- tsc/next build green

## HEAL-0003 — Props contract drift

- category: `frontend_contract`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- Property 'hint' does not exist on type ...

**Where to look**

- frontend/src/pages
- frontend/src/components

**Treatment**

- Сверить интерфейс props и все вызовы компонента.

**Verification**

- next build
- поиск похожих вызовов

## HEAL-0004 — CI missing pytest

- category: `ci_runner`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- pytest: command not found

**Where to look**

- ci.yml
- .github/workflows/**

**Treatment**

- Добавить pip install pytest и нужные плагины в
- workflow.

**Verification**

- CI step pytest exists
- pytest -q runs from workflow

## HEAL-0005 — Pytest wrong cwd

- category: `ci_runner`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- exit code 5
- no tests ran

**Where to look**

- ci.yml
- Makefile
- scripts

**Treatment**

- Запускать pytest из корня, где лежит tests/.

**Verification**

- CI shows collected tests > 0

## HEAL-0006 — CI dependency gap

- category: `ci_runner`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- ModuleNotFoundError: jwt
- missing pytest-asyncio

**Where to look**

- backend/requirements.txt
- ci.yml

**Treatment**

- Синхронизировать CI install step с requirements и test
- deps.

**Verification**

- missing import errors gone
- pytest collection green

## HEAL-0007 — Broken npm lockfile source

- category: `frontend_build`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- npm ci failed
- package-lock points to mirror

**Where to look**

- frontend/package-lock.json

**Treatment**

- Пересобрать lockfile на публичном registry npmjs.

**Verification**

- npm ci
- lockfile has no vendor/file refs

## HEAL-0008 — Vendor patch bypass

- category: `frontend_build`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- file: dependency
- vendor override in package json

**Where to look**

- frontend/package.json
- frontend/package-lock.json

**Treatment**

- Вернуть нормальные semver зависимости и честный
- lockfile.

**Verification**

- npm ci
- guard bans passes

## HEAL-0009 — Missing symbol import/export

- category: `imports`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ImportError
- cannot import name

**Where to look**

- backend/app/services
- backend/app/models
- facades

**Treatment**

- Сверить реальный экспорт и импорт; фасад держать
- честным.

**Verification**

- pytest collection
- compileall

## HEAL-0010 — Pagination contract missing

- category: `backend_contract`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- Pagination expected
- admin_logging missing pagination

**Where to look**

- backend/app/routes/admin_logging.py

**Treatment**

- Добавить/импортировать Pagination там, где она нужна.

**Verification**

- pytest collection
- admin logs flow tests

## HEAL-0011 — Alembic backend import path

- category: `alembic_imports`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ModuleNotFoundError: backend
- alembic cannot import backend.*

**Where to look**

- backend/migrations/env.py
- backend/migrations/versions

**Treatment**

- Перевести импорты на app.* или migrations.* под
- текущий cwd.
- Не смешивать backend.app.* и app.* в одном контуре.

**Verification**

- alembic upgrade head
- compileall migrations

## HEAL-0012 — Migration env NameError

- category: `alembic_env`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- NameError
- _backend_dir used before define

**Where to look**

- backend/migrations/env.py
- 0001_init.py

**Treatment**

- Определить path helper до first use и перепроверить
- sys.path.

**Verification**

- compileall
- alembic import env

## HEAL-0013 — Settings field missing

- category: `settings`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- parsed_ref_bonus_thresholds missing
- TASK_REWARD_BONUS_EFHC_DEFAULT missing

**Where to look**

- backend/app/core/config_core.py

**Treatment**

- Добавить поле в Settings и sane default по канону.

**Verification**

- compileall
- settings import
- pytest affected flow

## HEAL-0014 — SQLite row lock unsupported

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- FOR UPDATE
- SKIP LOCKED
- sqlite syntax error

**Where to look**

- tests/**
- services using raw SQL locks

**Treatment**

- Не адаптировать доменную логику под SQLite.
- Тесты перевести на Postgres-only профиль.

**Verification**

- pytest on Postgres profile
- no sqlite lock errors

## HEAL-0015 — SQLite SQL function drift

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- now() missing
- ::numeric
- sqlite incompatible SQL

**Where to look**

- tests/**
- services/payment_intents_service.py

**Treatment**

- Убрать SQLite profile из таких тестов или переписать
- tests.

**Verification**

- pytest
- no sqlite sql syntax errors

## HEAL-0016 — TON validator false ban

- category: `wallet_validation`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- invalid TON address
- false ban letters E/e

**Where to look**

- wallet validator
- TON address parsing

**Treatment**

- Перейти на нормальную валидацию формата TON и тесты
- примеров.

**Verification**

- wallet validation tests
- real known address passes

## HEAL-0017 — str vs datetime

- category: `time_types`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- '>' not supported between str and datetime

**Where to look**

- panels services
- scheduler code

**Treatment**

- Нормализовать тип времени до сравнения и на границе
- ввода.

**Verification**

- panel tests
- mypy if typed

## HEAL-0018 — Session already begun

- category: `transactions`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- InvalidRequestError: transaction already begun

**Where to look**

- panel services
- withdraw/exchange services

**Treatment**

- Убрать вложенный begin().
- Держать одну транзакционную границу в сервисе.

**Verification**

- pytest affected flow
- no nested tx error

## HEAL-0019 — Migration smoke NoneType

- category: `migrations`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- NoneType in migration smoke

**Where to look**

- backend/migrations/versions/0001*

**Treatment**

- Сверить helper contract и защитить от None перед
- обращением.

**Verification**

- migration smoke test
- alembic upgrade head

## HEAL-0020 — SQLite schema DDL in tests

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- near SCHEMA syntax error
- sqlite DDL schema

**Where to look**

- tests/**
- migration smoke tests

**Treatment**

- Запускать такие тесты только на Postgres-only профиле.

**Verification**

- pytest on Postgres profile

## HEAL-0021 — Guard binary false positive

- category: `guard`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- guard bans hit png
- binary asset false positive

**Where to look**

- ops/canon_guard.py
- frontend/public/**

**Treatment**

- Исключить binary assets или детектировать mime/binary
- mode.

**Verification**

- guard scan passes on png/jpg

## HEAL-0022 — Guard alias ban hit

- category: `guard`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- bans scan found tg alias
- forbidden substring found

**Where to look**

- frontend/src/**
- backend/**
- ops/canon_rules.yaml

**Treatment**

- Санировать алиасы до канона tg_id without new bypass
- names.

**Verification**

- guard bans passes
- grep on aliases clean

## HEAL-0023 — Idempotency unique race

- category: `idempotency`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- duplicate key
- uq_efhc_transfers_idem_key

**Where to look**

- transactions_service.py
- transfer logs

**Treatment**

- Сделать read-through поиск по ключу до insert.
- Повтор отдавать как idempotent result.

**Verification**

- idempotency tests
- concurrency retry tests

## HEAL-0024 — Exchange/withdraw race

- category: `financial_invariants`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- race in exchange
- withdraw invariants broken

**Where to look**

- withdraw service
- exchange service
- bank ledger

**Treatment**

- Держать атомарные state transitions.
- Использовать row locks и idempotent service path.

**Verification**

- concurrency tests
- ledger invariants hold

## HEAL-0025 — Warnings promoted to fail

- category: `pytest_policy`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- unraisable exception warnings
- deprecated warnings fail

**Where to look**

- pytest.ini
- tests/**
- pydantic generics

**Treatment**

- Исправить источник warning, а не глушить его globally.

**Verification**

- pytest clean warnings

## HEAL-0026 — SSL mode mismatch local Postgres

- category: `alembic_env`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- sslmode require local postgres fail

**Where to look**

- backend/migrations/env.py

**Treatment**

- Добавлять sslmode только для non-local hosts.

**Verification**

- alembic upgrade head local/ci

## HEAL-0027 — Leftover sqlite helper

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- IndentationError _init_sqlite_schema

**Where to look**

- tests/**

**Treatment**

- Удалить/заменить sqlite helper на Postgres fixture
- path.

**Verification**

- compileall tests
- pytest collection

## HEAL-0028 — Broken migration env formatting

- category: `alembic_env`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- compileall env.py failed
- broken indentation

**Where to look**

- backend/migrations/env.py

**Treatment**

- Нормализовать блок search_path injection.
- Проверить quoting и indentation.

**Verification**

- compileall
- bandit B608 context

## HEAL-0029 — models __init__ contaminated

- category: `models_facade`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- models __init__ damaged
- unexpected code in __init__

**Where to look**

- backend/app/models/__init__.py

**Treatment**

- Переписать __init__.py как чистую фасадную re-export
- точку.

**Verification**

- pytest collection
- compileall

## HEAL-0030 — Missing required tables

- category: `db_sanity`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- required tables missing after alembic

**Where to look**

- 0001_init.py
- env.py
- ORM metadata
- SSOT tables

**Treatment**

- Сверить ORM tables, 0001, search_path и sanity list.
- Явно указывать схему там, где нужно.

**Verification**

- alembic upgrade head
- sanity db objects
- tables count

## HEAL-0031 — Duplicate ORM table define

- category: `orm_metadata`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- Table already defined
- duplicate table definition

**Where to look**

- backend/app/models/**
- import graph

**Treatment**

- Унифицировать import path на app.* внутри backend cwd.
- Избегать двойной загрузки app.models и
- backend.app.models.

**Verification**

- alembic import
- pytest collection

## HEAL-0032 — Archive filename too long

- category: `release_artifact`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- unzip file name too long

**Where to look**

- release zip
- docs/healer/**

**Treatment**

- Укорачивать имена артефактов и путей внутри релиза.

**Verification**

- unzip efhc.zip in CI

## HEAL-0033 — Double schema prefix

- category: `db_sanity`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- efhc_core.efhc_core.table

**Where to look**

- 0001_init.py
- sanity helpers

**Treatment**

- Нормализовать имя таблицы перед to_regclass/sanity
- check.

**Verification**

- alembic sanity green

## HEAL-0034 — Incomplete metadata from soft imports

- category: `orm_metadata`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- tables_count_expected got lower count

**Where to look**

- backend/app/models/__init__.py
- metadata load

**Treatment**

- Импортировать все model modules жёстко и единообразно.

**Verification**

- metadata tables count
- alembic sanity

## HEAL-0035 — Config settings export drift

- category: `settings`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- config_core did not export settings

**Where to look**

- backend/app/core/config_core.py

**Treatment**

- Вернуть каноничный export settings из config_core.

**Verification**

- imports from app.core.config_core work

## HEAL-0036 — Index schema kwarg invalid

- category: `orm_sqlalchemy`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- Index() got unexpected kwarg 'schema'

**Where to look**

- backend/app/models/**

**Treatment**

- Убрать schema= из Index(...).
- Схему задавать только на таблице.

**Verification**

- alembic import
- compileall
- pytest collection

## HEAL-0037 — TimestampMixin export missing

- category: `models_facade`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ImportError TimestampMixin absent in app.models

**Where to look**

- backend/app/models/__init__.py
- external_events_models.py

**Treatment**

- Добавить TimestampMixin в фасад и унифицировать import
- path.

**Verification**

- alembic import
- pytest collection

## HEAL-0038 — Migration writes to impl.stdout

- category: `migrations`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- AttributeError impl.stdout

**Where to look**

- 0001_init.py

**Treatment**

- Убрать такой вывод и использовать безопасный logger/op
- context.

**Verification**

- alembic upgrade head

## HEAL-0039 — DDL not committed

- category: `migrations`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- migration prints metadata, but tables absent

**Where to look**

- 0001_init.py
- migration transaction flow

**Treatment**

- Проверить transaction scope и op.execute path для DDL.

**Verification**

- tables exist after upgrade
- sanity green

## HEAL-0040 — Payment intent contract drift

- category: `payments`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- PACKAGE_NOT_FOUND
- ambiguous param types

**Where to look**

- payment_intents_service.py
- payment routes/tests

**Treatment**

- Сверить service, route, tests и SQL path по одному
- канону.

**Verification**

- pytest payment intents
- DB flow tests

## HEAL-0041 — Broken SQL string in tests

- category: `tests_syntax`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- SyntaxError in pytest collection
- broken SQL template

**Where to look**

- tests/**

**Treatment**

- Починить шаблон SQL literal и compileall tests.

**Verification**

- pytest collection
- compileall tests

## HEAL-0042 — React Query provider missing

- category: `frontend_runtime`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- No QueryClient set

**Where to look**

- frontend/src/pages/_app.tsx
- hooks using React Query

**Treatment**

- Поднять QueryClientProvider выше места вызова hook.

**Verification**

- next build
- runtime page render

## HEAL-0043 — Function import drift in tests

- category: `tests_contract`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- append_transfer_extra_info import error

**Where to look**

- tests/**
- services/ledger helpers

**Treatment**

- Синхронизировать тестовый импорт с каноничным именем в
- коде.

**Verification**

- pytest collection
- grep old name clean

## HEAL-0044 — Direction column too short

- category: `db_schema`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- value too long for type varchar(8)
- direction truncation

**Where to look**

- transfer log model
- migration for direction column

**Treatment**

- Расширить длину/constraint под полный набор direction
- values.

**Verification**

- DB migration
- insert/update direction tests

## HEAL-0045 — tg_id vs users.id drift

- category: `identity_canon`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- JOIN u.id = w.tg_id
- WHERE id = :tg_id

**Where to look**

- routes/services/sql joins
- admin lists
- shop lookups

**Treatment**

- Санировать все join/filter path до tg_id only.
- Не вводить алиасы и обходные имена.

**Verification**

- grep suspicious joins
- critical flow tests

## HEAL-0046 — Route/service signature drift

- category: `backend_contract`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- unexpected keyword argument
- missing positional arg

**Where to look**

- backend/app/routes/**
- backend/app/services/**

**Treatment**

- Сверить сигнатуры route и service.
- Убрать лишний arg или добавить его в service только
- если он
- реально
- нужен по логике.

**Verification**

- pytest affected flow
- search similar calls

## HEAL-0047 — ORM/service/route drift

- category: `ssot_sync`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- field missing in model/service
- route points to wrong table

**Where to look**

- models
- services
- routes
- migrations

**Treatment**

- Проверять связку route → service → table → migration
- одним
- циклом.
- Обновлять map docs и tests вместе с кодом.

**Verification**

- targeted tests
- MODEL_TABLE_ROUTE_TEST_MAP sync

## HEAL-0048 — Unsafe raw SQL schema handling

- category: `sql_safety`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- B608
- unsafe search_path sql
- CREATE SCHEMA f-string
- WHERE {' AND '.join(where)}
- AND '.join(where)
- string-built WHERE

**Where to look**

- backend/migrations/env.py
- backend/app/services/admin/**
- backend/app/services/**
- raw SQL helpers

**Treatment**

- Убрать string-built WHERE и raw schema SQL.
- Перевести на безопасный builder или text() с параметрами.
- Сохранить бизнес-смысл и проверки доступа.

**Verification**

- bandit
- compileall
- search_path works

## HEAL-0049 — Documentation table count drift

- category: `docs_ssot`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ORM-таблицы: 38
- Таблицы (ровно 30)
- SSOT docs mismatch

**Where to look**

- docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md
- docs/OVERVIEW_SSOT_SYNC.md
- docs/audits/DIAGNOSTIC_DB_INVENTORY.md
- README.md

**Treatment**

- Синхронизировать `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md` с `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.
- Указать реальные counts: `efhc_core=33`, `efhc_admin=5`, `total=38`.

**Verification**

- Проверить числа 38/33/5 в `README.md`, `docs/OVERVIEW_SSOT_SYNC.md`, `docs/audits/DIAGNOSTIC_DB_INVENTORY.md`, `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md`.

## HEAL-0050 — Lotteries terminology scope drift

- category: `terms_canon`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- draw/draws banned everywhere
- prize draw in locale text
- Lotteries terminology conflict

**Where to look**

- docs/SSOT/TERMS_GLOSSARY.md
- frontend/public/locale/**
- frontend/src/pages/lotteries.tsx

**Treatment**

- Сузить запрет: запрещать `draw/draws` как новые технические и канонические имена домена Lotteries.
- Разрешить естественный English текст про событие розыгрыша, если это не имя сущности, поля, route alias или ключа локализации.

**Verification**

- Проверить `docs/SSOT/TERMS_GLOSSARY.md` и убедиться, что scope запрета больше не противоречит UI/locale смыслу.

## HEAL-0051 — Duplicate dataclass decorator

- category: `backend_runtime`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- @dataclass followed by @dataclass(frozen=True)
- duplicate class decoration

**Where to look**

- backend/app/services/withdraw_service.py

**Treatment**

- Оставить только один декоратор `@dataclass(frozen=True)` для `WithdrawRequestDTO`.

**Verification**

- `python -m compileall backend/app`
- Точечный импорт `withdraw_service.py` не должен ломаться.



## HEAL-0052 — Shop spending order drift

- category: `business_invariant`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- debit_user_bonus_to_bank(
- debit_user_to_bank(
- shop_service manual split debit

**Where to look**

- backend/app/services/shop_service.py
- backend/app/services/transactions_service.py

**Treatment**

- Перевести shop flow на
- spend_user_to_bank_bonus_then_main(...).

**Verification**

- pytest tests/architecture/test_shop_spending_order_canon.py

## HEAL-0053 — Missing two-schema guard test

- category: `guard_coverage`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- missing explicit schemas count == 2 test

**Where to look**

- tests/architecture/*
- docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv

**Treatment**

- Добавить architecture test на schemas == 2.

**Verification**

- pytest tests/architecture/test_schema_count_two.py


## HEAL-0054 — Energy page archive leakage
- Severity: P2
- Zone: green
- Симптом: на странице Energy отображается архивный счётчик панелей.
- Лечение: убрать archived_count с Energy и оставить только active_count + текущую генерацию активных панелей.


## HEAL-0055 — In-memory idempotency TTL cache

- category: `backend_resilience`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- self._ttl_seen
- TTL cache in memory process
- MonetaryIdempotencyMiddleware in-memory duplicate lock

**Where to look**

- backend/app/core/system_locks.py
- backend/app/models/admin_models.py
- tests/core/test_monetary_idempotency_middleware.py

**Treatment**

- Убрать process-local TTL dict из MonetaryIdempotencyMiddleware.
- Перевести TTL duplicate lock на efhc_admin.idempotency_key.
- Держать middleware только как HTTP safeguard поверх DB source of truth.

**Verification**

- В system_locks.py больше нет self._ttl_seen.
- TTL lock идёт через общую таблицу efhc_admin.idempotency_key.
- Тест middleware обновлён под shared-lock helper.


## HEAL-0056 — GlobalHeader status/menu discoverability gap

- category: `frontend_header`
- severity: `P3`
- zone: `green`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- GlobalHeader missing VIP badge
- GlobalHeader missing Activ badge
- profile entry hidden behind avatar only

**Where to look**

- frontend/src/components/GlobalHeader.tsx
- frontend/src/components/ProfileModal.tsx
- frontend/src/components/Layout.tsx
- backend/app/routes/sync_routes.py

**Treatment**

- Добавить в GlobalHeader badges VIP и Activ.
- Добавить явную кнопку Menu, открывающую профиль.
- Отдавать persistent Activ status из backend snapshot.

**Verification**

- Проверить profile.has_activ в sync snapshot.
- Проверить badges VIP/Activ в GlobalHeader и ProfileModal.
- Проверить явную кнопку Menu в GlobalHeader.

## HEAL-0057 — Profile/settings terminology drift

- Symptoms: old split profile wording in user-facing texts.
- Treatment: replace the old wording with `Профиль` / `Профіль` / `Profile` and sync FAQ runtime, FAQ SSOT, locales and docs.
- Casebook: CASE-0057.

## HEAL-0058 — Incomplete Docker local environment

- category: `devops_docker`
- severity: `P2`
- zone: `yellow`
- symptom: compose поднимает только db, frontend не проксирует backend, backend не ждёт БД и миграции.
- treatment: полный stack db/backend/frontend, wait-for-db, alembic, docs.


## HEAL-0059 — Missing tg_id monetary rate limit

- category: `backend_security_rate_limit`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- no rate limiting for monetary operations
- thousands of monetary requests per tg_id
- MonetaryRateLimitMiddleware missing

**Where to look**

- backend/app/core/system_locks.py
- backend/app/main.py
- backend/app/routes/withdraw_routes.py
- backend/app/routes/exchange_routes.py
- backend/app/routes/shop_routes.py
- backend/app/routes/panels_routes.py

**Treatment**

- Добавить MonetaryRateLimitMiddleware для денежных путей.
- Ограничивать частоту запросов по tg_id в общем DB-backed контуре.
- Подключить middleware в backend/app/main.py.

**Verification**

- `python -m compileall backend/app/core/system_locks.py backend/app/main.py`
- `pytest tests/architecture/test_monetary_rate_limit_enabled.py`

## HEAL-0060 — HTTPException leaked into service layer

- Severity: P2
- Zone: yellow
- Symptom: service layer imports/raises `HTTPException`.
- Treatment: use `EFHCError` subclasses in services; map to HTTP in routes/handlers.
- Casebook: `CASE-0060`.

## HEAL-0061 — Opaque retry policy in _run_idempotent

- Severity: P3
- Zone: yellow
- Symptom: retry/read-through/idempotency conflict logic compressed into one broad except block.
- Treatment: extract helpers for idempotency conflict, transient tx error, read-through and conflict mark; keep retries only for unique idempotency_key, deadlock and serialization.
- Casebook: `CASE-0061`.


## HEAL-0062 — Continuation prompt and AL docs drift

- Category: `docs_governance`
- Severity: `P3`
- Zone: `yellow`
- Summary: отсутствие отдельного continuation prompt для нового чата и рассинхрон AL-документов при переходе к новой серии архивов.
- Treatment: создать continuation prompt, синхронизировать AI rules, architectural locks, SSOT index и README.
- Casebook: `CASE-0062`.

## HEAL-0063 — Release ZIP cache contamination and FAQ profile term drift

- Category: `release_hygiene`
- Severity: `P3`
- Zone: `yellow`
- Summary: релизный ZIP содержал кэши, а русский FAQ ещё держал user-facing термин `Профиль/Настройки`.
- Treatment: очистить релиз от `__pycache__`/`*.pyc`/`.pytest_cache`, привести FAQ SSOT и runtime к канону `Профиль`.
- Casebook: `CASE-0063`.


## v157_02 / logs_60244480535
- Circular import around `app.models.Base` caused alembic/pytest failures.
- Fixed by extracting shared ORM base into `backend/app/models/base.py`.
- Also fixed mypy, bandit, frontend type drift and ruff issues confirmed by log `60244480535`.


## CASE-0065 — Tournament-themed user-facing copy sync

- Heal ID: `HEAL-0065`
- Archive: `v157_04`
- Fix: синхронизированы user-facing тексты Турниры / Начать раунд / Стоимость входа / Раунд в locale, runtime FAQ и русском FAQ SSOT.
- Result: `resolved`.


## HEAL-0066 — FAQ section-name wording drift
- category: docs-consistency
- severity: medium
- zone: faq / runtime-faq / ssot
- card_status: active
- treatment_status: fixed
- medical_maturity: confirmed
- confirmation_basis: прямой аудит `frontend/src/data/faq/*`, `docs/SSOT/faq_ssot/**`, `docs/SSOT/ssot_pack/FAQ_SSOT_20_SECTIONS.json`
- root_cause: user-facing название раздела 14 было рассинхронизировано по языкам и слоям FAQ.
- treatment: раздел 14 приведён к канону `Турниры / Турніри / Tournaments`; старые section-name формулировки удалены из FAQ-слоёв.
- verification: поиск по FAQ-слоям на старые section-name термины пустой.
- related_reports: `reports/change_cycle_2026-03-12_v157_05_faq_wording_cleanup.md`


## HEAL-0067 — Residual tournaments wording drift in FAQ and bot UI

- zone: frontend / docs / bot
- severity: medium
- symptom_patterns: `Tournamentsr`, `lotteries`, `розіграш`, `Çekiliş`, bot fallback `Lotteries`
- root_cause: неполная санация пользовательских формулировок сразу в нескольких слоях
- treatment: дочистить locale, runtime FAQ, FAQ SSOT, bot handlers и visible error strings, не трогая технический домен `lotteries_*`
- verification: поиск по user-facing слоям на legacy terms после патча чистый
- related_report: `change_cycle_2026-03-12_v157_06_name_drift_cleanup_and_faq_sync.md`


## HEAL-0068 — Residual user-facing tournaments drift in FAQ SSOT pack

- category: user_facing_copy_drift
- severity: medium
- zone: frontend / docs / faq
- card_status: active
- treatment_status: fixed
- medical_maturity: confirmed
- confirmation_basis: прямой аудит `frontend/src/data/faq/*`, `docs/SSOT/faq_ssot/**`, `docs/SSOT/ssot_pack/FAQ_SSOT_20_SECTIONS.json`, `README.md` + job logs в `logs/canon/`
- root_cause: после `v157_06` дочистка не охватила все многоязычные FAQ/SSOT источники; часть хвостов осталась в markdown/json и агрегированном ssot pack.
- treatment: повторная санация user-facing FAQ/SSOT текстов на 13 языках; `lotteries.cost` приведён к канону `Стоимость входа / Вартість входу / Entry cost`; technical domain `lotteries_*` не переименовывался.
- verification: поиск по FAQ/source слоям на legacy terms пустой; значения в `frontend/public/locale/*.json` проверены JSON-парсером и чисты.
- related_reports: `reports/change_cycle_2026-03-25_v157_07_user_facing_tournaments_reaudit.md`


## HEAL-0069 — Lotteries full-domain decommission required

- category: domain_decommission
- severity: high
- zone: backend / frontend / docs / tests / ops / env
- card_status: resolved
- treatment_status: completed
- medical_maturity: confirmed
- confirmation_basis: прямой аудит HEAD архива; 1977 совпадений по lotteries-related patterns, включая backend routes/services/models/crud, frontend page/locale and SSOT docs.
- root_cause: предыдущие циклы лечили только user-facing wording, но сам технический домен lotteries оставался активным и связанным с API, ORM, docs и runtime.
- treatment: controlled decommission in 20 cycles with import/export audit first, then frontend removal, route removal, services/crud/models removal, docs/SSOT rebuild and final residual search.
- verification: в финале серии поиск по коду и архиву не должен находить active feature references to lotteries outside preserved historical records.
- related_reports: `reports/change_cycle_2026-03-25_v157_08_lotteries_full_domain_audit_cycle_01.md`


### Update 2026-03-25 / Cycle 02
- import/export audit completed
- confirmed coupling across frontend pages, bot routers, public/admin routes, schemas, services, crud, models and SSOT route maps
- next safe step: remove frontend entry points before touching backend route/service layer


### Update 2026-03-25 / Cycle 03
- removed frontend entry points from `frontend/src/pages/panels.tsx`
- removed user-facing navigation from Panels to `/lotteries`
- kept `frontend/src/pages/lotteries.tsx` alive intentionally for staged removal in cycle 05
- local verification: `npm --prefix frontend run build` = OK


### Update 2026-03-25 / Cycle 03
- removed frontend entry points from `frontend/src/pages/panels.tsx`
- removed user-facing navigation from Panels to `/lotteries`
- kept `frontend/src/pages/lotteries.tsx` alive intentionally for staged removal in cycle 05
- local `next build` not confirmed in container: `node_modules` absent, `next` not found


### Follow-up — CASE-0070 (2026-03-25)
- runtime locale keys cleaned after entry-point removal
- runtime FAQ section 14 removed
- FAQ meta labels `14` / `14.1` removed
- general runtime FAQ cross-references cleaned


### Update 2026-03-25 / Cycle 05
- removed `frontend/src/pages/lotteries.tsx`
- removed direct frontend client calls to `/api/lotteries*` by deleting the page module
- kept runtime locale keys `lotteries.*` temporarily as dead data for later API/docs removal cycles


### Update 2026-03-25 / Cycle 06
- removed `backend/app/bot/handlers/lotteries_handlers.py`
- removed `backend/app/bot/handlers/admin/admin_lotteries_handlers.py`
- removed bot dispatcher include/import for lotteries router
- removed admin aggregate include/import for admin lotteries router
- removed `🎟 Лотереи` button from `kb_main_menu()`


### Update 2026-03-25 / Cycle 07
- removed `backend/app/routes/lotteries_routes.py`
- removed `lotteries_routes` from FastAPI route aggregator
- synced route-coupled tests for wallet gate semantics
- synced route-coupled docs `WALLETS_TONCONNECT_SSOT.md` and `API_CONTRACTS.md`

## HEAL-0069 — cycle 08 update

- Removed admin lotteries routes from admin FastAPI layer.
- Removed lotteries exposure from admin facade.
- Kept service/domain removal for later cycles.


## HEAL-0069 — cycle 09 update

- Removed standalone lotteries schema/contract layer.
- Removed admin lotteries schema re-export surface.
- Kept service/CRUD/model removal for later cycles.

- HEAL-0075 / cycle 10: removed lotteries service layer; synced service-coupled tests and stale doc references to deleted service files.


## HEAL-0069 — cycle 11 update

- Removed `backend/app/crud/lotteries_crud.py`.
- Removed `backend/app/crud/admin/admin_lotteries_crud.py`.
- Removed lotteries alias and health-check requirements from `backend/app/crud/__init__.py`.
- Synced decommission guard test for CRUD-layer removal.


## HEAL-0069 — cycle 13 update

- Removed lotteries-specific test files from the archive.
- Reduced generic service/guard tests to non-lotteries scope.
- Synced tests catalog and overview-doc counts after deleting test files.

- 2026-03-25 v157_21: cycle 14 removed lotteries env/config surface (`LOTTERIES_*` example vars, config_core settings block, admin_settings lotteries keys).

## HEAL-0069 — cycle 15 update

- Removed lotteries-only ops guard `check_lotteries_auto_cycle_ssot(...)`.
- Removed lotteries idempotency route patterns from `ops/canon_rules.yaml`.
- Removed scheduler soft-import and default registration for `lotteries_autorestart`.
- Kept non-ops leftovers for later cycles.


## v157_23 / cycle 16
- Rebuilt docs layer and removed active lotteries-domain references from docs/overview/glossary/API descriptions.

## HEAL-0069 — Lotteries domain decommission
- 2026-03-25 v157_24: cycle 17 removed residual structural SSOT traces from `docs/SSOT/ssot_pack` (`SSOT_TABLES_PURPOSE_RU.md`, `SSOT_TABLES_MIGRATIONS.csv`, `SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md`).

- HEAL-0069 / cycle 18: зафиксирована политика historical DB/migration traces; active SSOT/runtime не может возвращать lotteries-domain, historical mentions допустимы только в audit/report/healer/migration history.


## HEAL-0069 — cycle 19 update
- Removed final active residual traces after domain decommission.
- Deleted dead locale keys and stale release logs.
- Cleared remaining lotteries wording from active backend/doc comments and identifiers.


### Update 2026-03-25 / Cycle 20
- final residual grep по active tree дал `FOUND 0` при исключении historical buckets
- контрольные проверки `compileall` и архитектурные `pytest` прошли
- серия decommission завершена, активный lotteries-domain отсутствует
- case status: resolved

- 2026-03-26 v157_29: cycle 21 зафиксировал единый реестр циклов 1–40 и inventory mismatch-классов SSOT/runtime/docs/tests/release artifact; активных lotteries-traces в active tree не подтверждено.

- 2026-03-26 v157_30 cycle 22: FAQ/runtime sync hardened with deterministic SSOT generator and exact-match guard.

- HEAL-0070 / Route surface drift: local route modules embedded `/api` instead of relying on app-level API_PREFIX. Treatment: normalize route modules and add repository guard. Status: treated.

- 2026-03-26 / Cycle 24: admin route surface canonicalized; added admin route module guard; synced docs counts/catalog; line72 tail fixed.

- 2026-03-26 / Cycle 27: resolved route/service/table docs drift — active docs held stale route counts 91/92 while SSOT CSV had 82; synced docs and added `test_ssot_route_count_docs_sync.py`.
- 2026-03-26 / Cycle 28: resolved startup/OpenAPI drift — `api/index.py` ended after env bootstrap and did not export `app`; `backend/openapi/openapi.json` held only 2 stale paths while SSOT route surface had 82. Restored Vercel entry, regenerated OpenAPI from SSOT route registry, added `test_openapi_startup_consistency.py`.

## HEAL-0073 — FAQ banned-term residual in active runtime
- symptom: active EN FAQ still contained запретный user-facing хвост and runtime inherited it.
- root_cause: FAQ ban guard did not scan SSOT/runtime FAQ layers.
- treatment: removed запретный user-facing хвост from EN FAQ, regenerated runtime catalogs, tightened canon rules and added dedicated FAQ ban-term test.
- verification: grep FAQ layers + pytest `test_faq_banned_terms_absent.py`.
- HEAL-0074: route freeze map drift / missing freeze index. Fixed by creating route freeze CSV and markdown synced to SSOT routes.


## HEAL-0075 — idempotency policy audit looked only at local route path
- symptom: architecture guard checked only decorator local path and missed policy drift on full route path `router prefix + local path`.
- root_cause: weak AST audit ignored router prefix and default Depends(...) parsing.
- treatment: rebuilt route idempotency guard to inspect full path and dependency defaults, synced `ops/canon_rules.yaml`, generated `docs/SSOT/ssot_pack/SSOT_IDEMPOTENCY_SURFACE.csv`.
- verification: `pytest -q tests/architecture/test_route_idempotency_policy.py tests/architecture/test_idempotency_surface_docs_sync.py`.

- HEAL-0076 — Response/error canon drift: `HTTPException` handler registration missing + non-canonical object-detail keys in routes. Status: resolved in cycle 34.


## Cycle 36
- Confirmed by `logs_62194714005.zip`: banned tg_id alias terms remained in `docs/SSOT/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json`.
- Treatment: replaced alias mentions with tg_id-only wording, updated migration invariants to 32 tables / 2 schemas / ORM-only 0001, added dedicated guard.

- HEAL-0076: DB diagnostics docs drift — stale totals in `SSOT_DB_SCHEMAS_TABLES.md` and malformed legacy policy tails in DB docs. Treatment: synced all DB diagnostic docs to `SSOT_TABLES_ORM` and added dedicated guard.

- 2026-03-26 / Cycle 38: resolved route-matrix/OpenAPI docs drift — `MODEL_TABLE_ROUTE_TEST_MAP.md` had stale counts and pointed to missing `backend/app/models/exchange_routes.py`; synchronized with SSOT/OpenAPI and added dedicated guard.

- HEAL-0078: release artifact hygiene wave 2 fixed packaging of runtime log artifacts and added dedicated guard.

- HEAL-0080: residual docs-count drift in final route/migration regression pack (`MODEL_TABLE_ROUTE_TEST_MAP.md` kept stale test files count).

## HEAL-0078
- Симптом: перед RU purge wave отсутствовал freeze FAQ totals и runtime-source mapping.
- Лечение: добавлены `docs/FAQ_INVENTORY_FREEZE.md`, `docs/FAQ_INVENTORY_FREEZE.csv`, guard `test_faq_inventory_freeze_sync.py`, RU candidate list wave 1.

- HEAL-0081: FAQ RU wave 2 needs manual confirmation before deleting low-value section 14 questions.

- HEAL-0082: faq section 14 weak-but-non-risk questions require refinement instead of deletion when totals must stay stable.
- cycle 45: faq translations/runtime parity wave 1 — done (v158_22)
- HEAL-0084: cycle 46 confirmed zero new RU direct-risk FAQ candidates after wave 1 and refinement; next FAQ work must target weak and duplicate Q/A.



- HEAL-0085: after direct-risk cleanup, FAQ work must pivot to weak and duplicate RU Q/A review instead of forced deletions.

- HEAL-0079: FAQ weak/duplicate wave 1 review groups must resolve by point refinements or justified merge, never by silent drift.

- HEAL-0086: RU duplicate wave 2 groups must resolve by clearer scenario split, not by silent deletions.

- HEAL-0087: non-RU FAQ parity wave 2 can lag after RU duplicate-resolution cycles; confirm by checking 6 mirrored IDs across 12 languages and runtime catalogs.


- Cycle 52: FAQ RU duplicate audit wave 3 completed as audit_only; confirmed 4 review groups / 8 Q-A, no automatic removals or replacements.

## HEAL-0088 — faq ru duplicate wave 3 may persist after audit without resolution
- Категория: faq_governance
- Severity: P3
- Подтверждение: cycle 53 потребовал разводки 4 duplicate-групп / 8 RU Q/A после audit_only wave 3.
- Лечение: точечно усиливать формулировки, не удаляя Q/A; после правки пересобирать runtime FAQ и переводить review-файл в resolved.


## HEAL-0089
- Name: faq translations/runtime parity wave 3 may stay stale after ru duplicate resolution wave 3
- Status: confirmed and treated in cycle 54.


## HEAL-0090 — faq ru duplicate wave 4 may remain after parity wave 3
- symptom: после cycle 54 в RU FAQ остаются подтверждённые user-facing overlap-кластеры вокруг постоянства Activ и карточек реферальных уровней.
- root_cause: после закрытия предыдущих wave-серий следующий слой пересечений не был ещё вынесен в отдельный audit-lock.
- treatment: cycle 55 создал audit-only файл `docs/archive_removed_elements/FAQ_RU_DUPLICATE_CANDIDATES_WAVE4.md` и guard `test_faq_ru_duplicate_wave4_audit_lock.py` без автоматической правки FAQ.
- verification: прямой аудит RU FAQ markdown/json + targeted pytest guard.


## HEAL-0091 / CASE-0103
- Symptom: after cycle 56 the project had a planned Shop → Hub queue, but
  the unified cycle journal still had a 56–60 gap and the repository did
  not yet have a direct active-surface inventory for the old Shop domain.
- Fix in cycle 57: added `docs/audits/SHOP_HUB_TRANSITION_INVENTORY.md` and
  backfilled cycles 56–60 with descriptions in
  `docs/cycles/WORK_CYCLES.md`.
- Verification: direct audit of active frontend/backend/bot/admin/FAQ/test
  files containing Shop domain traces in HEAD archive `v159_02`.


## HEAL-0092 / CASE-0104
- Symptom: unified cycle journal file name stayed `docs/WORK_CYCLES_01_40.md`
  even after the register already contained cycles 61–100, so the file path
  no longer matched its real scope.
- Fix in cycle 58: renamed the journal to `docs/cycles/WORK_CYCLES.md`, updated
  textual references to the new canonical path, and marked future cycle
  logging to use the range-free file name.
- Verification: direct audit of docs/report/healer references in HEAD archive
  `v159_03`.


## HEAL-0093 / CASE-0105
- Symptom: `docs/cycles/WORK_CYCLES.md` simultaneously contained two different
  56–60 ranges: an obsolete FAQ planned block and the actual Shop → Hub
  preparation block, creating numbering drift inside the unified journal.
- Fix in cycle 59: removed the obsolete duplicate 56–60 FAQ block,
  preserved the actual Shop → Hub sequence, corrected the cycle 58
  wording, and synced the register HEAD/version note.
- Verification: direct audit of `docs/cycles/WORK_CYCLES.md`,
  `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` and appended change report.



## HEAL-0094 / CASE-0106
- Symptom: after `docs/SSOT/HUB_SSOT.md` was added, the repository still lacked
  a quantitative pre-migration baseline proving how wide the active `shop`
  implementation surface remained across frontend, backend, FAQ/runtime,
  docs and tests.
- Fix in cycle 61: added `docs/HUB_PRE_AUDIT_BASELINE.md`, counted active
  `shop` traces by layer, confirmed that implementation-level `hub`
  adoption had not started yet, and kept alias removal blocked.
- Verification: direct archive grep/audit of HEAD `v159_06`, including
  file-name hits, per-layer counts, and confirmed active module map.


## HEAL-0095 / CASE-0107
- Symptom: after `docs/SSOT/HUB_SSOT.md` freeze and the quantitative
  baseline in cycle 61, the repository still lacked a direct
  implementation-alignment audit mapping current active Shop code to
  concrete Hub SSOT MUST / MUST NOT violations and migration waves.
- Fix in cycle 62: added
  `docs/HUB_SSOT_IMPLEMENTATION_ALIGNMENT_AUDIT.md`, confirmed
  frontend/backend/admin/bot/locale mismatch points, documented guard
  insertion points, and kept alias removal blocked until staged
  migration completes.
- Verification: direct audit of HEAD `v159_07`, including
  `frontend/src/pages/shop.tsx`,
  `frontend/src/pages/admin/shop.tsx`,
  `backend/app/routes/shop_routes.py`,
  `backend/app/routes/admin_shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/models/shop_models.py`,
  `backend/app/schemas/shop_schemas.py`,
  and active locale/runtime traces.


## HEAL-0097 / CASE-0108
- Symptom: after the Hub SSOT freeze and implementation audit, the
  repository still exposed `Shop` in primary user-facing labels:
  GlobalHeader button text, locale navigation/title values and FAQ
  section 13 labels.
- Fix in cycle 63: switched the first user-facing naming layer to `Hub`
  without removing technical `shop` aliases, added
  `docs/HUB_UI_NAMING_WAVE1_AUDIT.md`, and locked the change with
  `tests/architecture/test_hub_ui_naming_wave1_lock.py`.
- Verification: direct audit of `frontend/src/components/GlobalHeader.tsx`,
  `frontend/public/locale/*.json`,
  `frontend/src/data/faq/meta.ts`, and
  `frontend/src/data/faq/ru.ts`.

- HEAL-0097 / 2026-03-28: Hub screen refactor wave 1 — user-facing `shop.tsx` переведён в cards-only Hub screen без commerce-layer.

## HEAL-0098 / CASE-0109
- Symptom: after Hub screen refactor and user-facing FAQ cleanup, the
  repository still had no dedicated EFHC handoff architecture boundary;
  Hub could not yet call a backend-issued signed token flow, and the
  old Shop commerce contract remained the only active purchase contour.
- Fix in cycle 67: added
  `docs/HUB_EFHC_HANDOFF_ARCHITECTURE_AUDIT.md`, confirmed that
  `backend/app/routes/shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/schemas/shop_schemas.py`, and
  `backend/app/contracts/shop_contract.py` are still commerce-layer
  files, froze the requirement for signed short-lived one-time handoff
  tokens with `exp` and `jti`, and blocked direct reuse of Shop
  contracts as the future Hub public contract.
- Verification: direct audit of HEAD `v159_12`, including
  `frontend/src/pages/shop.tsx`,
  `backend/app/routes/shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/schemas/shop_schemas.py`,
  `backend/app/contracts/shop_contract.py`,
  and `docs/SSOT/HUB_SSOT.md`.

Cycle 70 note: active skin locale wording no longer sells skins; texts now describe unlocks by account progress and keep the 12-level canon.


## HEAL-0099 / CASE-0110
- Symptom: after the user-facing skin wording cleanup, the active
  model/data/service/API/helper layer still retained a legacy commerce
  bridge for skins.
- Fix in cycle 71: added `docs/SKINS_MODEL_DATA_AUDIT.md`, confirmed the
  active legacy markers `price_efhc`, `purchased_at`,
  `POST /skins/buy/{skin_id}`, `buy_skin(...)`, `skin_purchase`,
  `getShopSkinBgUrl(...)`, and `efhc_shop_skin_changed`, and added
  `tests/architecture/test_skins_model_data_audit_lock.py`.
- Verification: direct audit of HEAD `v159_16`, including
  `backend/app/models/skins_models.py`,
  `backend/app/routes/skins_routes.py`,
  `backend/app/schemas/skins_schemas.py`,
  `backend/app/services/skins_service.py`,
  `backend/app/standards/skins_catalog.py`, and
  `frontend/src/lib/skins.ts`.


## 2026-03-28 — Cycle 75 Hub admin routes/services
- Подтверждён archive-first drift: следующий цикл по HEAD — `75`, не `76`.
- Закрыт backend слой Hub admin manager: list/create/update/toggle/reorder.
- Добавлены новые active endpoints `/admin/hub/links` и технические алиасы `/admin/shop/hub-links`.
- Price/order semantics не переносились в `hub_links`.


## 2026-03-28 — Cycle 76 Hub admin UI wave
- Подтверждено: frontend admin page ещё жила на legacy Shop-orders/set-price semantics.
- `frontend/src/pages/admin/shop.tsx` переведён на Hub Links Manager.
- Active UI вызывает `/admin/hub/links`, create/update/toggle/reorder.
- Из active admin UI убраны order/price fields; `/admin/shop` сохранён как технический route alias.


## HEAL-0100 / CASE-0111
- Symptom: the active Russian runtime FAQ had already moved section 13 to
  `Hub`, while the Russian SSOT export file still kept the old section
  `13. Shop`.
- Fix in cycle 77: added `docs/HUB_FAQ_SECTION_13_RU_DRAFT.md`, froze the
  13-question Russian approval draft, and confirmed the active runtime
  total `233/250`.
- Verification: direct audit of `frontend/src/data/faq/ru.ts`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`, and `docs/cycles/WORK_CYCLES.md`.


## HEAL-0101 / CASE-0112
- Symptom: the prior chat claimed that Russian runtime FAQ had already moved section 13 to `Hub`, but the HEAD archive still keeps active `Shop` traces in `frontend/src/data/faq/catalogs.ts`.
- Fix in cycle 78: added `docs/HUB_FAQ_CROSS_SECTION_DRIFT_AUDIT.md` and froze the real drift map across runtime, SSOT, bot, and locale layers.
- Verification: direct audit of `frontend/src/data/faq/catalogs.ts`, `docs/SSOT/faq_ssot/ru/faq_ru.md`, `docs/SSOT/faq_ssot/ru/faq_ru.json`, `backend/app/bot/handlers/shop_handlers.py`, and `frontend/public/locale/*.json`.


## HEAL-0102 / CASE-0113
- Symptom: the Russian SSOT FAQ still described `Shop` as a user-facing section in navigation answers and in section 13, while the Hub canon required a navigation-layer model.
- Fix in cycle 79: rewrote the Russian SSOT FAQ in `docs/SSOT/faq_ssot/ru/faq_ru.md` and `docs/SSOT/faq_ssot/ru/faq_ru.json`, moved section 13 to `Hub`, described EFHC/VIP as external flows, and fixed related navigation/top-bar answers.
- Verification: direct audit of `docs/SSOT/faq_ssot/ru/faq_ru.md`, `docs/SSOT/faq_ssot/ru/faq_ru.json`, and `docs/cycles/WORK_CYCLES.md`.


## HEAL-0103 / CASE-0114
- Symptom: `frontend/src/data/faq/catalogs.ts` still kept runtime FAQ text behind the rewritten Russian SSOT FAQ.
- Fix in cycle 80: rebuilt runtime FAQ with `ops/scripts/generate_faq_catalogs_from_ssot.py`, then verified exact parity with the generator guard.
- Verification: `pytest -q tests/architecture/test_faq_catalogs_generated_from_ssot.py`, direct audit of the RU runtime chunk, and count check `20 sections / 250 Q/A`.


## 2026-03-28 — Cycle 81 bot help/text Hub drift
- Подтверждено: bot/help слой оставался частично на Shop-терминах, а helper `t()` не совпадал с фактическим способом вызова из хэндлеров.
- Исправлено: `backend/app/bot/texts.py` переведён на backward-compatible helper API и наполнен реальными bot/help ключами.
- Исправлено: `backend/app/bot/handlers/shop_handlers.py` и `backend/app/bot/handlers/admin/admin_shop_handlers.py` теперь описывают `Hub` как primary surface, сохраняя `/shop` и `/admin_shop` как технические алиасы.
- Проверено: `python -m compileall backend/app/bot`.

## HEAL-0104 / CASE-0116
- Symptom: non-Russian SSOT FAQ files still kept active `Shop` wording in section 13 and related top-bar/navigation answers, so multilingual FAQ drifted away from the Hub canon.
- Fix in cycle 82: rewrote the confirmed Hub FAQ surface in all 12 non-Russian languages, regenerated `docs/SSOT/faq_ssot/*/faq_*.md`, rebuilt runtime FAQ via `ops/scripts/generate_faq_catalogs_from_ssot.py`, and confirmed parity with `test_faq_catalogs_generated_from_ssot.py`.
- Verification: direct audit of `docs/SSOT/faq_ssot/*/faq_*.json`, residual grep for `Shop`, runtime rebuild, and generator guard pass.


- 2026-03-28 cycle 83: docs/openapi sync closed; Hub admin surface `/admin/hub/links*` and public handoff `POST /hub/efhc-handoff` added to SSOT/OpenAPI/docs, route count synced to 88.


## HEAL-0105 / CASE-0117
- Symptom: Hub migration no longer had a dedicated regression pack locking the alias `shop -> hub`, the signed EFHC handoff, the external VIP flow, and the ban on prices/internal purchase/skin SKU inside the active Hub UI.
- Fix in cycle 84: added `tests/architecture/test_hub_guards_regression_pack.py` and `docs/HUB_GUARDS_REGRESSION_PACK.md` as a direct post-migration freeze for the active Hub surface.
- Verification: `pytest -q tests/architecture/test_hub_guards_regression_pack.py tests/architecture/test_hub_screen_refactor_lock.py tests/architecture/test_hub_efhc_handoff_implementation_wave1_lock.py tests/architecture/test_hub_vip_getgems_alignment_wave1_lock.py`.


## HEAL-0106 / CASE-0118
- Symptom: after the main Hub migration waves, the repository still contained a broad `shop` footprint, but the traces were mixed across active backend commerce code, temporary aliases, historical audit records, and true cleanup-ready residues.
- Fix in cycle 85: added `docs/LEGACY_SHOP_RESIDUE_AUDIT.md` and classified the remaining `shop` traces into keep-as-commerce, keep-as-alias, keep-as-history, and cleanup-candidates-for-cycle-86 buckets.
- Verification: direct HEAD grep across `backend`, `frontend`, `docs`, and `tests`, plus usage checks for locale keys and active admin/profile surfaces.

## 2026-03-28 — cycle 86
- Подтверждённая проблема: после residue-аудита оставались cleanup-ready user-facing/docs residuals `Shop`, хотя backend commerce domain и compatibility aliases ещё нужны.
- Исправлено: удалены 143 мёртвых locale-ключа `admin.shop_orders_summary`, `desc.shop.*`, `shop.*` из `frontend/public/locale/*.json`; исправлены stale docs wording в `docs/FAQ_COVERAGE_MATRIX.md`, `docs/NORM/ADMIN_RBAC.md`, `docs/GENERAL/specification.md`, `frontend/public/skins/README.txt`.
- Проверено: direct grep по `frontend/public/locale` больше не находит удалённые dead keys; JSON всех locale-файлов валиден.

## HEAL-0107 / CASE-0119
- Symptom: after cleanup wave 1 the transition layer still needed a dedicated pressure test proving that old deep links, bot entry points, and admin aliases keep working without restoring `Shop` as the primary surface.
- Fix in cycle 87: added `tests/architecture/test_hub_alias_pressure_test.py` and `docs/HUB_ALIAS_PRESSURE_TEST.md` to lock `/hub` as primary while preserving `/shop`, `/admin_shop`, and `/admin/shop/hub-links*` as compatibility aliases.
- Verification: `pytest -q tests/architecture/test_hub_alias_pressure_test.py tests/architecture/test_hub_guards_regression_pack.py`.

## HEAL-0108 / CASE-0120
- Symptom: after the alias pressure test the repository still lacked a formal pre-removal design splitting safe `shop` alias deletion away from backend commerce code, compatibility surfaces, and history-only traces.
- Fix in cycle 88: added `docs/HUB_FINAL_ALIAS_REMOVAL_DESIGN.md` and updated `docs/SSOT/HUB_SSOT.md` so alias removal can proceed only by confirmed candidates, preconditions, and wave-based evidence.
- Verification: direct audit of `docs/SSOT/HUB_SSOT.md`, `docs/LEGACY_SHOP_RESIDUE_AUDIT.md`, `docs/HUB_ALIAS_PRESSURE_TEST.md`, and `docs/cycles/WORK_CYCLES.md`.

- Cycle 89: internal alias drift cured by moving active Hub implementation into canonical `hub`-named frontend and bot files while preserving `shop` wrappers for compatibility.

- 2026-03-28 / cycle 90: final commerce cleanup + release stabilization — removed dead `frontend/src/components/ShopGrid.tsx`, aligned active UI doc `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`, renamed canonical admin component export to `AdminHubPage`, preserved `/shop` and `/admin/shop` compatibility aliases, targeted regression pack required.


## HEAL-0109
- Symptom: the archive still carried an unresolved concept gap — cycle 72 planned skin switcher design had never been formally closed, while current code mixed progression canon with a legacy commerce bridge.
- Fix in cycle 91: added `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`, updated `docs/SSOT/HUB_SSOT.md`, and locked the concept with `tests/architecture/test_skin_switcher_concept_closure_lock.py`.
- Verification: direct audit of `frontend/src/lib/skins.ts`, `backend/app/routes/skins_routes.py`, `backend/app/services/skins_service.py`, `backend/app/models/skins_models.py`, `backend/app/schemas/skins_schemas.py`, and targeted pytest pass.


## HEAL-0110
- Symptom: after cycle 91 the archive still lacked a separate runtime/API layer for the skin switcher; active skin state could remain tied to the mixed legacy surface instead of the progression canon.
- Fix in cycle 92: introduced `/skins/switcher` and `/skins/switcher/activate/{skin_id}`, new switcher schema/helper surface, and canonical fallback sync for `active_skin_id`.
- Verification: direct audit of `backend/app/routes/skins_routes.py`, `backend/app/services/skins_service.py`, `backend/app/schemas/skins_schemas.py`, `frontend/src/lib/skins.ts`, targeted pytest, and compileall.


## HEAL-0111
- Symptom: after internal canonicalization the repo still had no precise wave-2 caller map for `/shop` and `/admin/shop`; removal risk remained too high.
- Fix in cycle 93: added `docs/HUB_ALIAS_CALLER_AUDIT_WAVE2.md`, refined cycle 94 targets, and locked the findings with `tests/architecture/test_hub_alias_caller_audit_wave2_lock.py`.
- Verification: direct audit of `frontend/src/pages/admin/index.tsx`, bot handlers, keyboards, and targeted pytest pass.


## HEAL-0112
- Symptom: cycle 93 confirmed that `/admin/shop` still had one internal caller and that two thin bot-wrapper modules remained in the repo despite no longer being the live wiring point.
- Fix in cycle 94: moved the admin internal caller to `/admin/hub` and removed `backend/app/bot/handlers/shop_handlers.py` plus `backend/app/bot/handlers/admin/admin_shop_handlers.py`.
- Verification: direct audit of admin index and bot wiring, targeted pytest, and compileall for `backend/app/bot`.


## HEAL-0113
- Symptom: after cycle 94 the remaining drift lived in the bot entry layer — `/admin` and `/admin_hub` still pointed users to a generic menu instead of a direct Admin Hub WebApp entry.
- Fix in cycle 95: added `kb_admin_entry()`, updated admin handlers, and aligned help texts with `/admin_hub` and `/admin_shop`.
- Verification: direct audit of `backend/app/bot/keyboards.py`, `backend/app/bot/handlers/admin/admin_main_handlers.py`, `backend/app/bot/handlers/admin/admin_hub_handlers.py`, `backend/app/bot/texts.py`, targeted pytest, and compileall.


## HEAL-0114
- Symptom: after cycles 93–95 the HTTP route surface remained stable, but active docs were not fully frozen and still described `/admin/shop` as if it were the current internal admin entry.
- Fix in cycle 96: added `docs/POST_ALIAS_DOCS_OPENAPI_FREEZE.md`, updated `docs/NORM/TESTS_CATALOG.md`, and locked the post-alias freeze with `tests/architecture/test_post_alias_docs_openapi_freeze_lock.py`.
- Verification: direct audit of docs/OpenAPI/admin index and targeted pytest pass.


## HEAL-0115
- Symptom: after cycle 96 the repo still needed semantic hardening so that Hub manager labels would not be confused with commerce-domain Shop reports and stats.
- Fix in cycle 97: added `docs/ADMIN_REPORTING_HUB_HARDENING.md`, clarified reporting/service wording, and locked the split with `tests/architecture/test_admin_reporting_hub_hardening_lock.py`.
- Verification: direct audit of `frontend/src/pages/admin/index.tsx`, `backend/app/services/admin/admin_stats_service.py`, `backend/app/services/reports_service.py`, and targeted pytest pass.

## Cycle 98 — legacy cleanup wave 2
- Symptom: последние active locale/runtime traces оставались shop-named (`admin.shop`, `nav.shop`, `shop.title`, `profile.reason.shop_purchase`).
- Fix: active runtime переведён на `admin.hub`, `nav.hub`, `profile.reason.hub_operation`; compatibility и commerce-domain layer сохранены.

## Cycle 99 — final release audit
- Symptom: финальный release audit вскрыл syntax-ошибку в bot help texts.
- Fix: `backend/app/bot/texts.py` исправлен; compileall подтверждён; OpenAPI snapshot подтверждён прямой проверкой checked-in файла.

## Cycle 100 — release stabilization and handoff
- Symptom closed: итоговая серия 61–100 имела неполный closure layer в плане 91–100 и без финального handoff doc.
- Fix: добавлен final handoff doc, выровнен цикл 92/100 в closure plan, серия закрыта документально.

## Cycle 101 — log-driven fixes and 101–110 plan
- Symptom: post-handoff CI logs showed alembic/document drift and frontend Hub build drift.
- Fix: synced SSOT table inventory with `hub_links`, fixed Hub admin/hub page frontend issues, planned full CI parity as cycle 102.

## Cycle 102 — log remediation wave
- Symptom: fresh CI logs failed on Alembic 0002 duplicate create and ruff import-order drift.
- Fix: migration 0002 split into offline/online branches; ruff surface cleaned.
- Honest state: log blockers are healed, but full parity still reveals non-log docs/FAQ/healer drift.

## Cycle 102 continuation
- User-directed treatment: stop keeping transition aliases after transition end.
- User-directed treatment: make first install effectively single-base migration by squashing hub_links create/seed into 0001.

## Cycle 102 — docs/route-count continuation
- Symptom: after alias/migration fixes the next exposed layer was stale counts and incomplete route freeze inventory.
- Fix: rebuilt freeze inventory to 88 routes and synced overview/docs counters.

## 2026-03-29 — cycle 102 closure
- Подтверждено: полный `pytest -q` на HEAD зелёный: 275 passed, 25 skipped.
- Закрыт cycle 102 как full CI parity wave.
- Сняты legacy alias expectations в tests/docs после фактического sunset `/shop` и `/admin_shop` в active bot/page/help слое.
- Нормализованы `atlas.json` и `casebook.json` под текущий schema guard.
- Синхронизированы FAQ/translation expectations с текущим HEAD.

## 2026-03-29 — cycle 103
- Восстановлен обязательный governance layer для FAQ.
- Добавлены FAQ approval register и approval manifest.
- Зафиксировано, что FAQ waves 79–82 обошли approval gate быстрее, чем он был восстановлен.
- Historical draft section 13 из cycle 77 оформлен как retroactive approval entry `FAQ-APPROVAL-0001`.

## 2026-03-29 — cycle 104
- Проведён прямой FAQ runtime vs SSOT parity audit.
- Подтверждено по 13 языкам: 20 sections, 250 Q/A, section 13 = Hub.
- Прямого parity drift, требующего rewrite в этом же цикле, не найдено.
- Зафиксировано правило пользователя: в текущем цикле делать максимально возможный объём подтверждаемой работы без искусственного переноса на следующий цикл.

## 2026-03-29 — cycle 105
- Generator FAQ runtime now validates approval manifest before rebuild.
- Added hardening for manifest count, entry fields, 20/250 inventory, and section 13 = Hub.
- Runtime `catalogs.ts` rebuilt with generated header and governance source marker.

## 2026-03-29 — cycle 106
- Bot/help layer synced with current FAQ state.
- Added direct `/faq` bot command and FAQ entry keyboard.
- RU/EN help texts now mention current FAQ inventory 20/250.

## 2026-03-29 — Cycle 107
- Case: multilingual FAQ legal wording drift after Hub migration.
- Rule: multilingual FAQ rewrite requires draft + manifest/register entry + explicit approval before SSOT rewrite and runtime rebuild.

## Case 2026-03-30 — latent panel docs drift after approved RU FAQ rewrite

- Symptom: `docs/SSOT/faq_ssot/ru/faq_ru.*` already used approved panel wording `Активация панели`, but `docs/SSOT/PANELS_SSOT.md` and `docs/SSOT/FAQ_SSOT.md` still kept stale phrases `купить панель`, `цена панели`, and `после покупки первой панели`.
- Risk: SSOT/doc layer drift could falsely signal that cycle 126 was unfinished even though the Russian FAQ source was already rewritten.
- Fix in cycle 126: synced `docs/SSOT/PANELS_SSOT.md` and `docs/SSOT/FAQ_SSOT.md` to the approved panel canon without touching runtime or backend route names.
- Verification: direct grep audit of the updated docs confirmed removal of those stale user-facing phrases from the rewritten sections.

- 2026-03-30: Cycle 127 — устранён drift reason-кода панели: backend ещё писал `panel_purchase`, admin overview суммировал только legacy reason, а history runtime учитывал legacy mapping. Канон выровнен на `panel_activation` с backward-compatible чтением исторических записей.

- 2026-03-30: Cycle 128 — active defect не подтверждён; выполнен controlled prep-layer для multilingual panel wording package без runtime rewrite.

- 2026-03-31: Cycle 129 — healed multilingual panel-line drift in SSOT/runtime and fixed `FAQ_APPROVAL_MANIFEST.json` count mismatch that blocked FAQ runtime rebuild.

- 2026-03-31: Cycle 130 — active panel wording drift closed; residual traces reclassified into legacy/non-runtime FAQ layer and internal technical naming layer.

- 2026-03-31: Cycle 131 — backend panel wording drift reclassified as technical naming debt; current compatibility anchors frozen for a later controlled refactor.

- 2026-03-31: Cycles 132-135 — panel wording refactor moved active backend/frontend/API surfaces to activation canon while preserving technical compatibility names and paths.

- 2026-03-31: Cycle 136 — active panels parity confirmed; residual panel drift reclassified from user-facing flow to admin-facing PB5-3 accounting visibility.
- 2026-03-31: Cycles 137-140 — PB5-3 split counters healed in active admin layer; backend dual-read of `panel_purchase` + `panel_activation` preserved while UI switched to approved total/main/bonus labels.

- 2026-03-31: Cycle 141 — isolated stale non-runtime FAQ source `frontend/src/data/faq/ru.ts`; active FAQ source remains generated `catalogs.ts`.
- 2026-03-31: Cycle 142 — converted legacy `faqRuCatalog` file into a compatibility alias to generated runtime data and removed French section-13 `Boutique` drift from FAQ meta.
- 2026-03-31: Cycles 143-144 — backend panel naming cleanup limited to internal docs/comments/examples; compatibility anchors remain frozen.
- 2026-03-31: Cycle 145 — post-panel release audit confirmed cycles 129-145 are reflected in HEAD archive state.

- 2026-03-31: Cycle 146 — removable aliases identified: `etag`, `purchase_panel`, `on_user_first_panel_purchase`; public compatibility surfaces remain frozen.
- 2026-03-31: Cycle 147 — safe internal aliases removed and callers repaired.
- 2026-03-31: Cycle 148 — canonical panels activation route added as `/panels/activate/{tg_id}`; `/panels/buy/{tg_id}` retained as compatibility wrapper.
- 2026-03-31: Cycle 149 — static migration parity audit found no new archive-proven migration defect.
- 2026-03-31: Cycle 150 — post-alias release audit closed series 146-150 on HEAD.

Cycle 152 note: confirmed `/admin/shop/*` no longer has active admin UI or bot callers in HEAD; remaining surface is backend admin compatibility only.
Cycle 151 note: confirmed `/shop/*` no longer has active frontend or bot callers in HEAD; remaining surface is backend compatibility/API only.

Cycle 160 note: closed post-alias release audit for series 146–159; canonical panels route sync, migration readiness audit and alias-freeze boundary are now fixed in release docs.
Cycle 158 note: `/shop/*` and `/admin/shop/*` remain frozen backend compatibility surfaces; no safe contract-preserving deletion was confirmed in this wave.
Cycle 157 note: added new locks for canonical panels activation route in SSOT/OpenAPI/frontend and for migration live-run readiness audit presence.
Cycle 153 note: synced canonical `POST /panels/activate/{tg_id}` into SSOT route registries and exported OpenAPI while keeping compat `POST /panels/buy/{tg_id}`.

Cycle 170 plan note: finish the next series with a full archive-vs-chat-vs-logs parity audit so that unresolved proof gaps are either closed or explicitly frozen.
Cycle 164 plan note: obtain real Alembic proof instead of relying only on structural readiness audit.
Cycle 161 plan note: historical docs now need explicit archival marking because some old audit files describe already-removed alias states.

Cycle 165 note: `/shop/*` and `/admin/shop/*` are now explicitly frozen backend compatibility contracts pending a future canonical contract-migration wave.
Cycle 164 note: live Alembic proof is blocked in this environment because `sqlalchemy` is not installed.
Cycle 162 note: key stale-state docs now carry archival markers and should not be read as active current-state truth.

Cycle 170 note: full archive-vs-chat-vs-logs parity audit closed the current series; fresh logs are still absent, but freeze/proof boundaries are now explicit and test-backed.
Cycle 169 note: added deterministic route inventory markdown regeneration helper to reduce manual route-doc drift.
Cycle 168 note: `POST /panels/buy/{tg_id}` is frozen as a compatibility path while frontend stays on canonical `/panels/activate/{tg_id}`.
Cycle 166 note: `/shop/*` and `/admin/shop/*` freeze moved from decision-only to explicit docs/tests implementation.

Cycle 175 note: active backend/frontend/bot wording drift is now synchronized with Hub/external-flow canon for the current release line and backed by targeted tests.
Cycle 172 note: active locale keys in Hub, wallet and settings were refreshed across all 13 locale files to remove stale buy/purchase wording from active UI paths.

- 2026-03-31: Healer note -> log-driven stabilization wave fixed syntax/doc-count/catalog/archive-lock drift for cycle 176.

- 2026-03-31: Resolved historical blocker: cycle 164 closed after CI proved live Alembic upgrade head.

- 2026-03-31: Multilingual care wave 177-180 -> first active locale sync completed for nav/faq/hub/core titles/common shell.

- 2026-03-31: Manual multilingual treatment 181-182 -> Profile and Wallet wave 1 completed.

- 2026-03-31: Manual multilingual treatment 183-185 -> Panels, Exchange+Energy, Tasks+Referrals wave 1 completed.

- 2026-03-31: Manual multilingual treatment 186-187 -> History+Withdraw and Ranks+Prizes wave 1 completed.

- 2026-03-31: Manual multilingual treatment 188 + audit 189 -> common/balances synced; prizes/tournaments classified as non-confirmed active public section.

- 2026-03-31: Active `prizes/tournaments` tail removed from current code/doc layer; allowed only as historical evidence in reports/work cycles/healer.

- 2026-03-31: Manual treatment 191 -> Hub + FAQ shell wave 2 completed; current page inventory fixed in separate doc.

- 2026-03-31: Manual treatments 193-194 -> admin high-traffic locale sync completed; 195 verified no regression of removed prizes/tournaments tail.

- 2026-03-31: Overview docs treatment 196 completed; pages inventory drift removed, and migration summary was then re-normalized in cycle 197 to strict `0001 only`.

- 2026-03-31: Migration reset treatment 197 completed; active Alembic layer now expected as `0001` only.

- 2026-03-31: Documentation treatment 198 completed; migration canon clarified in-place inside existing docs.

- 2026-03-31: Registry normalization treatment 199 completed; recent append-only notes now reflect `0001 only` canon consistently.

- 2026-03-31: Final docs closeout 200 completed; historical audit files now carry explicit archival markers where needed.

- 2026-03-31: Cycle 201 — в реестр добавлены 15 уточняющих вопросов по полной ревизии документации архива; дальнейшая работа должна идти по полному списку документов с пофайловым согласованием действий `удалить / объединить / актуализировать`.

- 2026-03-31: Cycle 202 — построен полный master-index документации архива; audit-документы и лог-аудиты перенесены в `docs/audits/`, `reports/` оставлен вне текущего ручного обзора.

- 2026-03-31: Cycle 203 — зафиксированы решения пользователя по первой пятёрке документов; выполнено объединение legacy root `ARCHITECTURAL_LOCKS`, перенос `CHANGELOG` в `reports/`, перенос `CODE_OF_CONDUCT` в `artifacts/` и актуализация `CONTRIBUTING`.

- 2026-03-31: Cycle 204 — повторный audit чата и стартовых правил завершён; подготовлен обновлённый полный промт продолжения в новом чате с фиксацией документной фазы и точки продолжения по master-index.

- 2026-04-01: Cycle 205 — документная ревизия продолжена по решениям пользователя: `README.md` актуализирован, `REPORT_COMMANDS.txt` перемещён в `artifacts/misc/`, `SECURITY.md` расширен; дополнительно зафиксировано правило, что `artifacts/` не проверяется в пакетах ревизии как архивная корзина.

- 2026-04-01: Cycle 206 — мягко актуализированы migration/OpenAPI/requirements слои по прямому аудиту HEAD; текущий миграционный канон для первого релиза зафиксирован как `0001 only`, checked-in OpenAPI snapshot оставлен в active слое с обновлённым audit-note, а `backend/requirements.txt` дополнен недостающими зависимостями `PyJWT`, `cryptography` и `PyYAML`, которые используются в текущем архиве.

- 2026-04-01: Cycle 207 — `docker-compose.yml` мягко актуализирован по текущему Docker/archive layer; `docs/ACTIVE_WORDING_GUARDS_WAVE_2026_03_31.md` выведен в `artifacts/docs/`; `docs/GENERAL/ADMIN_PANEL_SPEC.md` объединён с более полным описанием админ-панели; `docs/NORM/ADMIN_RBAC.md` сохранён как active NORM и мягко актуализирован без ослабления ролевого канона.

- 2026-04-01: Cycle 208 — semantic boundary из `docs/ADMIN_REPORTING_HUB_HARDENING.md` интегрирована в `docs/GENERAL/ADMIN_PANEL_SPEC.md`, а сам файл выведен в `artifacts/docs/`; ADR 0001/0002/0003 и `docs/AI/AI_OPERATOR_RULES_EFHC.md` мягко актуализированы по текущему HEAD и текущему prompt-режиму документной фазы.

- 2026-04-01: Cycle 209 — `docs/API_REFERENCE.md` объединён с `docs/NORM/API_CONTRACTS.md` и выведен в `artifacts/docs/`; `docs/AI/AI_RESILIENCE_CANON.md`, `docs/NORM/API_CONTRACTS.md`, `docs/NORM/ARCHITECTURAL_LOCKS.md` и `docs/GENERAL/ARCHITECTURE_DEPENDENCIES_RU.md` актуализированы по текущему HEAD и document-phase rules.

- 2026-04-01: Cycle 210 — три wave/plan документа сведены по смыслу в `docs/cycles/WORK_CYCLES.md` и выведены в `artifacts/docs/`; `docs/GENERAL/ARCHIVE_NAV_INDEX.md` мягко актуализирован; `docs/NORM/TASKS_STANDARD.md` признан достаточно сильным для NORM-слоя и добавлен в `docs/SSOT/SSOT_INDEX.md`.

- 2026-04-01: Cycle 211 — `docs/BACKGROUND_TASKS_STANDARD.md` переименован в `docs/NORM/TASKS_STANDARD.md`; связанные active реестры и индексы синхронизированы с новым путём.

- 2026-04-01: Cycle 212 — `docs/SSOT/BANK_CANON.md` проверен против bank/economy SSOT и добавлен в NORM через `docs/SSOT/SSOT_INDEX.md`; `docs/BOT_PAGES_INVENTORY_2026_03_31.md` перенесён в `docs/audits/`; `docs/BOT_WEBAPP_ENTRYPOINT_STABILIZATION.md`, `docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml` и `docs/CODE_CLEANUP_AND_IMPROVEMENT_10_CYCLES_PLAN.md` выведены из active слоя; в `docs/AI/AI_OPERATOR_RULES_EFHC.md` добавлен обязательный формат `цикл X/Y завершён`.

- 2026-04-01: Cycle 213 — `docs/GENERAL/DOCKER_LOCAL.md` синхронизирован с текущим Docker layer; `docs/SSOT/DTO_INPUT_CANON.md` повышен до NORM через `docs/SSOT/SSOT_INDEX.md`; `docs/SSOT/EFHC_CANON.md` мягко вычищен по подтверждённой точке drift; `docs/SSOT/ENERGY_RULES.md` дополнен явной связью с exchange/available_kwh SSOT; `docs/NORM/ERROR_CODES.md` дополнен кодами `WALLET_REQUIRED` и `HUB_HANDOFF_NOT_CONNECTED`.

- 2026-04-01: Cycle 214 — `EVENTS_MATRIX.md` оставлен как active NORM и получил compat-оговорку для panel technical naming; `EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` дополнен cross-reference слоем; `FAQ_APPROVAL_GOVERNANCE.md` и `FAQ_CODE_GENERATION_HARDENING.md` мягко актуализированы по current HEAD; `FAQ_BOT_HELP_PARITY_WAVE.md` выведен в `artifacts/docs/`.
- 2026-04-01: Cycle 215 — FAQ helper/rewrite/freeze документы убраны из active docs слоя: `FAQ_COVERAGE_MATRIX.md` переведён в `artifacts/docs/`, а `FAQ_EXCHANGE_RU_REWRITE_WAVE1.md`, `FAQ_FORBIDDEN_WORDING_RU_REWRITE_WAVE1.md`, `FAQ_HUB_RU_REWRITE_WAVE1.md` и `FAQ_INVENTORY_FREEZE.csv` переведены в `docs/audits/`.
- 2026-04-01: Cycle 216 — `FAQ_INVENTORY_FREEZE.md` переведён в `docs/audits/`; `FAQ_MULTILINGUAL_LEGAL_WORDING_DRAFT.md`, `FAQ_PANELS_BOT_UI_RU_REWRITE_WAVE1.md`, `FAQ_PANELS_RATES_RU_DRAFT.md` и `FAQ_PANELS_RU_REWRITE_WAVE1.md` выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 217 — `FAQ_REPLACEMENT_LEDGER.md` актуализирован и переведён в `docs/audits/`; `FAQ_SSOT.md` мягко актуализирован; `FAQ_TOPBAR_RU_REWRITE_WAVE1.md`, `FAQ_VIP_RU_REWRITE_WAVE1.md` и `FAQ_WALLET_RU_REWRITE_WAVE1.md` выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 218 — `FRONTEND_ACTIVE_LOCALE_SYNC_2026_03_31.md`, `HUB_ADMIN_ENTITY_DESIGN.md` и `HUB_ADMIN_MIGRATION_MODEL_WAVE.md` переведены в `docs/audits/`; important pressure-test context перенесён в `docs/cycles/WORK_CYCLES.md`; `HUB_ALIAS_PRESSURE_TEST.md` и `HUB_ALIAS_REMOVAL_WAVE2.md` выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 219 — смысл `HUB_CYCLES_91_100_PLAN.md` сведен в `docs/cycles/WORK_CYCLES.md`; `HUB_EFHC_HANDOFF_IMPLEMENTATION_WAVE1.md`, `HUB_FAQ_SECTION_13_RU_DRAFT.md` и `HUB_FINAL_ALIAS_REMOVAL_DESIGN.md` переведены в `docs/audits/`; `HUB_FINAL_ALIAS_REMOVAL_WAVE1.md` выведен в `artifacts/docs/`.
- 2026-04-01: Cycle 220 — смысл `HUB_FINAL_COMMERCE_CLEANUP_RELEASE_STABILIZATION.md` сведен в `docs/cycles/WORK_CYCLES.md`; `HUB_GUARDS_REGRESSION_PACK.md`, `HUB_SERIES_61_100_FINAL_HANDOFF.md` и `I18N_ADMIN_VERIFICATION_2026_03_31.md` переведены в `docs/audits/`; `HUB_SSOT.md` мягко актуализирован.
- 2026-04-01: Cycle 221 — historical i18n wave-docs (`I18N_ADMIN_WAVE1_2026_03_31.md`, `I18N_ADMIN_WAVE2_2026_03_31.md`, `I18N_COMMON_BALANCES_WAVE1_2026_03_31.md`, `I18N_EXCHANGE_ENERGY_WAVE1_2026_03_31.md`, `I18N_HISTORY_WITHDRAW_WAVE1_2026_03_31.md`) выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 222 — historical i18n Hub/matrix/plan/wave документы (`I18N_HUB_FAQ_WAVE2_2026_03_31.md`, `I18N_MISSING_KEY_MATRIX_2026_03_31.md`, `I18N_MISSING_TRANSLATIONS_PLAN_191_195.md`, `I18N_PANELS_WAVE1_2026_03_31.md`, `I18N_PROFILE_WAVE1_2026_03_31.md`) выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 223 — `I18N_SYNC_PLAN_181_190.md`, `I18N_TASKS_REFERRALS_WAVE1_2026_03_31.md`, `I18N_WALLET_WAVE1_2026_03_31.md`, `LEGACY_CLEANUP_WAVE2.md`, `LEGACY_FRONTEND_FAQ_SOURCES_CLEANUP_2026_03_31.md` выведены из active docs слоя в `artifacts/docs/`; исторически важные выводы двух legacy cleanup документов сохранены в `docs/cycles/WORK_CYCLES.md`.
- 2026-04-01: Cycle 224 — historical смысл `LIVE_ALEMBIC_PROOF_BLOCKER_2026_03_31.md` и `LOTTERIES_DECOMMISSION_CYCLES.md` сохранён в `docs/cycles/WORK_CYCLES.md`; master-index очищен от слоя `artifacts/`; `MIGRATION_INVARIANTS_HARDENING.md` актуализирован и переведён в NORM.
- 2026-04-01: Cycle 225 — historical смысл `MIGRATION_RESET_TO_0001_2026_03_31.md`, `OBSERVABILITY_METRICS_PLAN.md` и `OPENAPI_RELEASE_DOCS_FREEZE_2026_03_31.md` сохранён в `docs/cycles/WORK_CYCLES.md`/active docs; `MODEL_TABLE_ROUTE_TEST_MAP.md` актуализирован и переведён в NORM; `MODULES_DEPENDENCIES.md` мягко актуализирован по current HEAD.
- 2026-04-01: Cycle 226 — важный смысл `OVERVIEW_DOCS_REFRESH_2026_03_31.md`, `PANELS_ADMIN_COUNTERS_DESIGN_2026_03_31.md`, `PANELS_API_WORDING_SYNC_2026_03_31.md` сохранён в `docs/cycles/WORK_CYCLES.md`; summary-данные `OVERVIEW_SSOT_SYNC.md` и panels approval package absorbed by active NORM/SSOT docs; standalone files выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 227 — важный panels compatibility смысл absorbed by `docs/SSOT/PANELS_SSOT.md` and `docs/cycles/WORK_CYCLES.md`; standalone panels draft/sync/freeze docs выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 228 — panels/project/release pack cleaned; historical notes absorbed by `docs/cycles/WORK_CYCLES.md`, `README.md`, `docs/GENERAL/architecture.md`; `QUESTIONS_AND_ANSWERS_REGISTER.md` and `RANKS_RULES.md` promoted to NORM.
- 2026-04-01: Cycle 229 — referral canon and routes/migrations playbook promoted to NORM; release hygiene and old repair plan absorbed into `docs/cycles/WORK_CYCLES.md`; `ROUTE_INVENTORY_FREEZE.md` left pending separate decision as a freeze snapshot rather than current live inventory.

## Cycle 331
- Ручная log-fix wave по logs_63144383921.
- Лечённые симптомы: flake8 F821, ruff import ordering, frontend TS nullability, frontend line72, stale FAQ guard expectations.
- Ограничение лечения: partial local proof из-за environment drift (sqlalchemy/bandit unavailable).

## Cycle 332
- Manual log-fix continuation from logs_63146798186.
- Main treated symptoms: mypy undefined name, frontend type error.
- Residual symptom: ruff/import drift wave in multiple tests remains active.

## Cycle 333
- Manual continuation of ruff/import drift wave.
- Result: targeted ruff subset now clean.
- Next evidence source must be a fresh CI log.

## Cycle 334
- Manual pytest-gate wave.
- Symptom: async panel tests were collected as unsupported coroutine tests.
- Treatment: async-marking restored for four panel tests.
- Next evidence source: fresh CI log.

## Cycle 335
- Green CI proof recorded from logs_63150433402.zip.
- Healer wave 331-334 considered factually closed by fresh CI proof.

## Cycle 336
- Control-rule treatment for delayed documentation.
- Symptom: archive build could happen before current-cycle docs were fully synced, causing visible gaps until the next cycle.
- Treatment: docs-before-build rule added to AI/startup/memory/register layers.
- Required future discipline: update documents first, then build release ZIP.

## Cycles 337-345
- Treated critical control breach: user withdraw list no longer triggers repair or money mutations.
- Treated exchange contract breach: explicit `amount_kwh` now maps to partial exchange instead of silent exchange-all.
- Treated startup drift: `.env` loads before `app.main`, and `create_app()` now delegates to canonical `main.app`.
- Treated USDT live risk by disabling pseudo-payload flow until real jetton transfer exists.
- Remaining open item: cycle 346 for real jetton transfer or stronger deferred-state guards.

## Cycle 346
- Honest deferred-state closure for USDT.
- Symptom: USDT had been disabled at tx assembly, but could still leak through earlier hub/shop/catalog layers.
- Treatment: added earlier guard rejections and marked live checkout TON-only until real TEP-74 payload support exists.

## Cycle 347
- Curated donor sandbox folder added to HEAD.
- Symptom treated: future donor work risked scattering across many unrelated
  sandboxes.
- Treatment: 10 prioritized sources were copied into `песочница/` and ranked.
- Main donor fixed: `sdk-main`.


## Cycle 348
- Donor audit and canon synchronization for EFHC jetton.
- Symptom treated: the project needed a clean pre-implementation map for real USDT jetton transfer, and the user requested the EFHC jetton to be fixed in canon instead of living only in config.
- Treatment: canonical EFHC jetton master address and decimals were synchronized from config into SSOT; a donor transfer map was created from curated sandboxes with `sdk-main` fixed as the primary donor.
- Honest boundary: no real USDT jetton transfer live implementation was claimed in this cycle.

## Cycles 349-354
- Pre-implementation donor integration package for real USDT jetton transfer.
- Symptom treated: after sandbox curation, the project still lacked a narrow donor extraction, adapter plan, backend alignment map, guard-test package and explicit live gates.
- Treatment: created six linked docs covering donor surface, frontend adapter plan, recipient/payload/fee decisions, backend intent/watcher alignment, test package and live gating.
- Honest boundary: the project remains in TON-only live mode until these gates are passed by a future implementation wave.

## Cycles 355-370 current pass
- Implementation wave started carefully from safe frontend foundations.
- Symptom treated: the project had transfer plans and donor maps, but still lacked real local EFHC-owned helper files to begin the adapter series.
- Treatment: added `frontend/src/lib/ton/units.ts`, `payload.ts`, `policy.ts` and barrel export `index.ts`; kept live USDT disabled and avoided fake completion claims for SDK-backed builder work.
- Verification: targeted TypeScript compilation for the new files passed.

## Cycles 356-370 current pass
- Dependency manifest wave was applied carefully at the repository level.
- Symptom treated: the future jetton builder needed declared dependencies and a bit more local policy/config scaffolding, but the environment still lacked install-proof.
- Treatment: updated frontend package manifests for `@ton/core`, `@ton/ton`, `@ton-community/assets-sdk`; added `constants.ts` and `recipient.ts`; kept honest note that npm install is blocked by E401 in this environment.
- Verification: targeted TypeScript compilation for local helper files passed.

## Cycles 358-370 current pass
- Added a local plan-level transfer layer after the dependency manifest wave.
- Symptom treated: helper files existed, but there was still no single normalized object describing a future USDT transfer operation before the real SDK-backed builder step.
- Treatment: added `tx.ts` and `usdt-transfer-plan.ts`; the plan layer now normalizes payload, amount, recipient, fee and sender fields before any future TEP-74 body serialization.
- Verification: targeted TypeScript compilation for `src/lib/ton/*.ts` passed.

## Cycles 358-370 backend intent enrichment pass
- Backend transport contract was enriched before the real builder step.
- Symptom treated: the future frontend builder path still lacked structured optional metadata in intent/status responses.
- Treatment: added `build_transport_meta(...)` and extended backend schemas with optional transport fields; frontend local types were aligned.
- Verification: compileall for changed backend Python files passed.

## Cycles 358-370 SDK-backed builder pass
- An unverified builder/adaptor layer was written after the helper and contract waves.
- Symptom treated: the project still lacked actual source files for sender wallet resolution, transfer body creation and TonConnect tx assembly.
- Treatment: added `jetton-transfer-builder.ts` and `usdt-transfer.ts`; kept an explicit honest boundary that only syntax-level proof exists so far.
- Verification: TypeScript transpileModule for the two new files reported no diagnostics.

## Current pass — browser-shop transport integration
- Browser-shop received a local helper that translates backend transport metadata into a builder-ready transfer plan.
- Symptom treated: transport metadata existed, but there was still no dedicated integration helper between browser-shop intent responses and the local transfer-plan/builder layers.
- Treatment: added `browser-shop-intent.ts` and transport metadata preview in `BrowserShopPage.tsx`.
- Verification: targeted local TypeScript proof passed; syntax-level transpile proof for the page passed.

## Current pass — readiness and tx normalization
- Browser-shop received an honest readiness/preview layer.
- Symptom treated: the page could show raw intent data, but could not explicitly tell whether the future USDT builder path had enough metadata to proceed.
- Treatment: added `tonconnect-normalize.ts`, `usdt-readiness.ts`, and page-level preview of normalized tx and missing transport fields.
- Verification: targeted local TypeScript proof passed; syntax-level transpile proof for the page passed.

## 2026-04-03 — runtime gate state integration
- Снята ещё одна причина UI drift: readiness preview и feature-gate состояние больше не размазаны по странице, а сведены в отдельный runtime-state helper.
- Guard: BrowserShopPage не должен сам вычислять блокировки USDT checkout ad-hoc; для этого теперь есть `browser-shop-usdt-runtime.ts`.
- Жёсткая граница сохранена: disabled/live distinction по USDT нельзя стирать даже при росте локального preview слоя.

## 2026-04-03 — server-truth USDT mode integration
- Убрана ещё одна точка drift: режим USDT больше не должен жить только в frontend helper.
- Guard: source of truth для `disabled/preview/staged/live` должен приходить с сервера и дублироваться во frontend только как отображение/guard, а не как самостоятельное решение страницы.
- Ограничение сохранено: наличие server mode не означает runtime-proof send path.

## 2026-04-03 — watcher transport split + command summary integration
- Guard: watcher mode split должен жить отдельным transport layer, а не быть размазан по `watcher_service.py` ad-hoc ветками.
- Guard: runtime command summary во frontend должен оставаться отдельным слоем поверх runtime state.
- Контроль циклов обновлён: 365 и 367 переведены из чистого pending в partial.

## 2026-04-03 — watcher validation hardening
- Guard: watcher не должен пытаться подтверждать payment intent по неподдержанному jetton transport path как будто это TON/USDT.
- Guard: `unknown_jetton` и `efhc_jetton` для payment intents должны блокироваться явно и уходить в manual path.
- Контроль циклов обновлён: 366 переведён из чистого pending в partial.

## 2026-04-03 — log-fix wave: repo hygiene + mypy/ruff
- Guard: donor-store `песочница/` не должен ломать product repo-wide canon tests, потому что это не live product code.
- Guard: frontend helper files должны использовать только canonical `tg_id`, без alias `tg-id alias`.
- Guard: generated frontend artifacts (`tsbuildinfo`, caches) не должны попадать в релизный архив.

## 2026-04-03 — tg-id alias doc cleanup + blocker registry
- Guard: даже журналы и отчёты не должны возвращать запрещённые alias-формы вокруг `tg_id`.
- Guard: нельзя помечать 356, 358–364, 368–370 как done, пока не закрыты их реальные proof/blocker-условия.

- 2026-04-03 / cycle 368 continued: watcher hardening now covered by process-level tests for short-circuit and native TON intent branches; keep extending beyond helper-only checks before marking 368 done.

- 2026-04-03 / cycle 368 expanded: process-level watcher coverage now includes confirm-failure -> pending_manual and native TON intent path. Keep 368 partial until wider backend/watcher suite is complete.

- 2026-04-03 / log 63240230827: fixed watcher-service schema drift (`ton_inbox_logs.utime` absent in current schema) and cleaned remaining tg-id alias wording in `WORK_CYCLES.md`. Local re-proof: mypy 0, ruff 0, targeted pytest 16 passed / 3 skipped.

- 2026-04-03 / log 63241331034: fixed asyncpg ambiguous parameter issue in watcher ton_inbox_logs upsert (`status` text vs varchar) by casting insert status and literalizing final-status comparisons. Local proof package back to green on targeted tests/ruff/mypy.

- 2026-04-03: sandbox expanded with `ton-access-main` and `ton-crypto-master` to support TON stack simplification and dependency-path cleanup.

- 2026-04-03: one-pass blocker attack removed `@ton-community/assets-sdk`; active runtime path now depends only on `@tonconnect/ui-react`, `@ton/core`, `@ton/ton`. Remaining blocker is install access to remaining TON tarballs.

- 2026-04-03: sandbox expanded with `ton-core-main` and `ton-main` to support local TON runtime integration without relying only on npm install.

- 2026-04-03: blocker chain reduced again. Active frontend path now uses local sandbox sources for `@ton/core`, `@ton/ton`, and `@ton/crypto`; remaining npm blocker moved to TonConnect UI packages.

- 2026-04-03: sandbox index refreshed. `sdk-main` locked as the main donor for TonConnect UI; local TON source donors and endpoint donors are now separated explicitly.
- 2026-04-03: case update — main frontend blocker narrowed and partially solved. npm install/runtime package barrier removed by localizing TON core + TonConnect dependencies; remaining issue is local donor TypeScript compatibility under Next build/type-check.
- 2026-04-03: sandbox enlarged with secondary donor/reference archives from the new batch; no change to the main blocker diagnosis.
- 2026-04-03: sandbox enlarged again with second-batch UI/reference donors; no change to the core blocker diagnosis.
- 2026-04-03: build/type blocker narrowed again. TonConnect local compat + npm ci remain green; residual blocker sits in isolatedModules/export-type friction inside local sdk/protocol donor sources.
- 2026-04-03: local donor build blocker narrowed again. Protocol entrypoint friction partly patched; current top stop is `sdk/src/models/index.ts` export-type compatibility under Next isolatedModules.
- 2026-04-03: deeper build-blocker audit confirms the current top stop is `sdk/src/models/index.ts`; install barrier remains solved.
- 2026-04-03: current blocker audit — donor-source build stop moved to `sdk/src/models/index.ts`; separate environment registry instability observed on repeated `npm ci` (`@twa-dev/types`, `@tanstack/query-core`).
- 2026-04-03: plan locked. Current work order changed from scattered cycle pressure to stable-environment strategy: one TON runtime path -> browser polyfills -> runtime checks -> USDT logic.

- 2026-04-04: Problem narrowed to runtime artifact delivery, not project business logic. Added donor batch and strategy lock for TON/TonConnect.

- 2026-04-04 / runtime path drift: do not claim TON/TonConnect published runtime path until `frontend/tsconfig.json` aliases are checked directly. This pass removed raw donor aliases for `@ton/core`, `@ton/ton`, `@ton/crypto`, and `@tonconnect/sdk`; remaining blocker moved to npm mirror E401, not isolatedModules over donor sources.

- 2026-04-04 / sandbox cleanup rule: category overlap is not enough for removal. Only move a sandbox donor into artifacts when a direct logical duplicate is confirmed by structure and purpose, as in `demo-dapp-with-react-ui-master` vs `sdk-main/apps/demo-dapp-with-react-ui`.

- 2026-04-04 / cycle-queue guard: historical `WORK_CYCLES` snapshots may preserve old front edges. After the runtime-path shift, do not keep saying the next cycle is `368`; the active queue returns to `358-364` first, then `365-370`.

- 2026-04-04: new guard lesson — do not “fix” VIP external verification by removing the external storefront from backend/admin. The repo location does not redefine the flow as in-Telegram sale. Fix only Telegram-side wording, norms and guards.

- 2026-04-04: new cycle-audit lesson — do not keep unfinished queues frozen in an old technical narrative after the user clarifies product topology. Preserve cycle numbers, but rebase unfinished cycle meaning to the current agreed direction.

- 2026-04-04: common-shell lesson — when a compat layer returns a fake hardcoded state like `useIsConnectionRestored() = false`, treat it as a real product-path defect, not as a harmless stub. Guard it at architecture level.

- 2026-04-05: повторно зафиксирована Healer-болезнь AI-layer — попытка
  вынести active cycle queue / plan в новый отдельный документ вместо
  ведения единственного канонического журнала
  `docs/cycles/WORK_CYCLES.md`.
  Новый жёсткий запрет закреплён в `docs/AI/AI_OPERATOR_RULES_EFHC.md`
  и `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`:
  нельзя создавать cycle-plan / cycle-status / cycle-register /
  wave-plan документы для active cycles.
