# HEALER_OPERATOR_KERNEL_KEYWORD_LOSS_GUARD

Status: ACTIVE PREVENTIVE GUARD.
Archive: `v171.63`.

## Failure patterns

- frontend task classified only as generic screenshots;
- bottom-navigation task classified as generic visual work;
- TonConnect/TonProof task classified as generic wallet;
- live Telegram task classified as frontend-only;
- Kernel restoration classified as docs-only or full audit;
- archive task loses development/release boundary;
- Active/VIP language task misses i18n route.

## Treatment

1. Restore the missing EFHC keyword group.
2. Add classifier example and behavior test.
3. Add/update route in YAML.
4. Update keyword and route maps.
5. Confirm classification output before patching.

## Independent evidence

`test_operator_kernel_keywords_anchors_v171_62.py` and `test_operator_kernel_routes_runtime_v171_62.py`.
