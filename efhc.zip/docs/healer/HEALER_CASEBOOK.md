## 2026-04-08 archival baskets must be skipped by canon guards

- После переноса старых документов в `artifacts/` guard-тесты не должны читать эту архивную корзину как активный кодовый или документный слой.
- Иначе пользовательское согласованное архивирование начинает ломать CI бан-словами и legacy терминами из исторических файлов.

## 2026-04-08 high-impact historical audit stubs must stay visible

- Даже после зачистки старых audit-файлов несколько high-impact historical docs должны оставаться в `docs/audits/`, если на них завязаны guard-тесты и continuity status-notes.
- Нельзя убирать такие документы из active docs surface, пока test-layer и control-layer ещё требуют их присутствия.

## 2026-04-08 transferred audit backbone

- Economy Healer backbone: bank split-brain, mirror direction drift, idempotency conflict drift, exchange autobegin drift, energy `_begin_tx` recursion, self-healing queue breakage, shop schema/reporting mismatch.
- Release Healer backbone: transient junk in ZIP, nested release ZIP relapse, build-script drift, confusion between transient junk and `artifacts/`.
- Frontend/UX Healer backbone: visual white spots, inconsistent loading/error/empty states, wording drift after canon updates, browser shop / hub residual mismatches.
- Process Healer backbone: false cycle closure, GitHub CI ownership drift, stale cycle-control panel, dependency-precheck drift, keeping unique errors only in old audits/reports.

## 2026-04-08 transferred reports backbone

- Старые reports перенесены из active surface; уникальная память по исправлениям должна сохраняться в Healer, cycle docs и свежих `change_cycle_*`.
- Legacy report naming (`change_report_*`, internal logs, alias sanitation reports и т.п.) больше не должен быть главным носителем решений.

## 2026-04-08 audit debt must move to Healer

- Старые audit-файлы не должны оставаться единственным носителем ошибок проекта.
- Перед будущей зачисткой `docs/audits/` нужно перенести economy, release, self-healing, frontend, cycle-control и process defects в Healer как долговременный memory-layer.
- `_raw` допустим как evidence-архив, но не как место, где живут уникальные ошибки без переноса в Healer.

## 2026-04-08 reports retention debt

- Раздел `reports/` разросся до большого исторического слоя; каноническая память должна остаться в `change_cycle_*`, а переходные/дублирующие форматы нужно разметить на `оставить / artifacts / удалить после согласования`.
- Старые internal logs и legacy report naming не должны сохранять уникальные ошибки мимо Healer.

## 2026-04-08 GitHub CI ownership reminder drift

- GitHub CI прогоны делает пользователь; ИИ не должен путать их со своими локальными вспомогательными проверками и не должен выдавать их за свои проходы.
- Это правило нужно удерживать одновременно в AI docs, циклах и чат-отчётах.

## 2026-04-08 nested release zip relapse

- build script staging captured existing `efhc.zip`, so the next archive packed the previous archive inside itself and almost doubled the release weight.
- Guard rule: before staging, delete `ZIP_OUT` in repo root and exclude it explicitly from rsync packaging.

## 2026-04-08 recursive _begin_tx residual transfer

- После фикса `energy_service` тот же рекурсивный `_begin_tx` оставался живым в `referral_service`, `wallet_binding_service` и `tasks_service`.
- Паттерн должен считаться Healer-хроникой: при отсутствии транзакции `_begin_tx` обязан вызывать `db.begin()`, а не сам себя.

## 2026-04-07 watcher/reporting residual transfer

- legacy helper paths через `shop_orders.item_id` и `shop_items` в watcher/reporting слое — хронический residual drift после смены канона shop_orders.
- сырой слой `docs/audits/_raw` должен переноситься в Healer/artifacts после картирования на активные аудиты.

## 2026-04-07 old GitHub CI log transfer

- Старые GitHub CI log-audits про `0002`, import-order и stale frontend typing/build дрейф должны считаться Healer-хроникой, а не active truth.
- Повторяющиеся `ruff I001`, stale typing/builder drifts и migration-memory conflicts — переносим в Healer даже если они уже встречались в старых логах и аудитах.

- Подмена реального GitHub CI локальными прогонами как будто это одно и то же — хроническая болезнь.
## 2026-04-07 correction wave consolidation

- Ложное закрытие циклов без реального выполнения — хроническая болезнь.
- Закрытие visual/frontend цикла без песочницы пользователя — хроническая болезнь.
- Stale временные тестовые артефакты, ломающие следующие прогоны, — хроническая болезнь.
- Отсутствие dependency-precheck (`pytest`, `ruff`, `compileall`, `mypy`, `bandit`, `sqlalchemy`, `aiosqlite`) перед циклами — хроническая болезнь.
- Старые GitHub CI log-аудиты должны передавать хронические ошибки в Healer, а не бесконечно оставаться в active audit-surface.

# Cycles 250-251 note — 2026-04-02

- Cycles 250-251 cleaned the main AI operator document and marked the prompt layer as reviewed historical material.
- The main AI layer now carries the primary continuity model more cleanly.

# Cycle 249 note — 2026-04-02

- Cycle 249 closed the current root helper-level merge phase as sufficiently cleaned.
- The AI layer now more strictly forbids English names for next cycles and roadmap points in chat.
- The repeated chat-language slip was treated as an AI continuity issue and fixed in the main AI docs.

# Cycle 248 note — 2026-04-02

- Cycle 248 normalized the key AI continuity docs into a more coherent Russian-facing layer.
- The current continuation prompt now reflects the line after cycle 247.
- Mixed-language wording remains acceptable only in secondary AI materials where precision benefits from it.

# Cycle 247 note — 2026-04-02

- Cycle 247 applied a controlled helper-level consolidation to the wallet/TON root cluster.
- The dynamic wallet-connect test pack now shares a testkit, while static SSOT and route guards remain explicit.
- The root merge phase is now close to saturation and may only need a final cleanup review.

# Cycle 246 note — 2026-04-02

- Cycle 246 applied a controlled helper-level consolidation to the root panels tests.
- Explicit scenario guards were preserved; only duplicate reload and seed boilerplate were consolidated.
- The panels cluster is no longer the strongest remaining root merge candidate.

# Cycle 245 note — 2026-04-02

- Cycle 245 applied a controlled helper-level consolidation to the concurrency root tests.
- The local verification also revealed two collection-shape hazards, which were corrected pointwise.
- The main AI doc now explicitly requires asking the user first when something is unclear.

# Cycle 244 note — 2026-04-02

- Cycle 244 fixed the final priority ladder in the main AI doc.
- Drift must now be reported, agreed through Q&A and only then synchronized.
- AI menu now has a START HERE marker for quick entry into the AI layer.

# Cycle 243 note — 2026-04-02

- Cycle 243 added a fast startup/communication protocol for new chats.
- Prompt files are now explicitly treated as secondary archival traces rather than the main continuity carrier.
- SSOT and NORM are explicitly treated as very important instruction-memory layers.

# Cycle 242 note — 2026-04-02

- Cycle 242 structurized the AI layer into index + brain/memory model + current continuation prompt.
- The archive is now explicitly modeled as a complement to the chat and as part of long-term continuity memory.
- `WORK_CYCLES.md` is explicitly treated as both memory and roadmap.

# Cycle 241 note — 2026-04-02

- Cycle 241 aligned the AI layer with the user's framing: AI docs are the working brains/prompt-layer, while logs, Q/A, Healer, registries and reports are the memory layer.
- The planned queue was renumbered so the former 241–242 entries now continue as 242–243.
- Chat-facing cycle naming remains Russian-only.

# Cycle 240 note — 2026-04-02

- Cycle 240 performed an AI continuity sweep after the previous chat audit and controlled test merge wave.
- The AI layer now explicitly records that user-facing cycle descriptions must be sent in Russian.
- Internal AI documents may remain in English or mixed language when this preserves precision and continuity.

# Cycle 239 note — 2026-04-02

- Cycle 239 applied a controlled helper-level merge wave for the payment-intents root tests.
- The refactor initially exposed a collection-time import risk and was corrected pointwise by moving `sqlalchemy` import inside the helper function.
- Explicit scenario tests were preserved; only duplicate setup helpers were consolidated.

# Cycle 238 note — 2026-04-02

- Chat audit confirmed AI-doc drift against the current post-233 continuation state.
- AI active docs were synchronized in cycle 238.
- Tests catalog was rebuilt into active / merge-review / retired sections.

Cycle 237 note: no new failure required repair; with CI green, the cycle was spent on classifying the root integration/concurrency/payment tests for the next cleanup wave.

Cycle 236 note: pytest finally exposed a large stale-test tail from the pre-reorg documentation structure; the cleanup was done manually and pointwise, with active guards preserved and current paths re-synced.

Cycle 235 note: post-install CI reached alembic and exposed stale SSOT path usage in `0001_init.py`; migration sanity path was repaired and style-blocking duplicate imports were removed from two route modules.

Cycle 234 note: latest CI logs failed before pytest because `backend/requirements.txt` had a narrative bullet line outside comment syntax; requirements parse was repaired and test-inventory cleanup planning started.

Cycle 73 note: Hub admin entity design frozen around `hub_links` and explicit exclusions of price/order semantics.

# HEALER_CASEBOOK

Version: 1.2.0

Cases total: 53

Cycle 26 note: `logs_62063388182.zip` closed by restoring Healer JSON structure and syncing active FAQ/runtime after residual lotteries-tail audit.

## CASE-0001 — Line72 violation

- heal_id: `HEAL-0001`
- archive_version: `v151_34+`
- action_priority: `observe`

Симптом: L=84 > 72

**Applied fix**

- Перенести длинную строку на несколько строк.
- Для описаний Field использовать description=(...) с
- конкатенацией.

**Verification**

- pytest line72
- ruff/compileall не деградировали

## CASE-0002 — apiRequest generics missing

- heal_id: `HEAL-0002`
- archive_version: `AA-local`
- action_priority: `observe`

Симптом: Property 'items' does not exist on type '{}'

**Applied fix**

- Добавить тип ответа и вызывать apiRequest<Resp>(...).

**Verification**

- npm run build
- tsc/next build green

## CASE-0003 — Props contract drift

- heal_id: `HEAL-0003`
- archive_version: `AA-local`
- action_priority: `observe`

Симптом: Property 'hint' does not exist on type ...

**Applied fix**

- Сверить интерфейс props и все вызовы компонента.

**Verification**

- next build
- поиск похожих вызовов

## CASE-0004 — CI missing pytest

- heal_id: `HEAL-0004`
- archive_version: `legacy-ci`
- action_priority: `observe`

Симптом: pytest: command not found

**Applied fix**

- Добавить pip install pytest и нужные плагины в
- workflow.

**Verification**

- CI step pytest exists
- pytest -q runs from workflow

## CASE-0005 — Pytest wrong cwd

- heal_id: `HEAL-0005`
- archive_version: `legacy-ci`
- action_priority: `observe`

Симптом: exit code 5

**Applied fix**

- Запускать pytest из корня, где лежит tests/.

**Verification**

- CI shows collected tests > 0

## CASE-0006 — CI dependency gap

- heal_id: `HEAL-0006`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: ModuleNotFoundError: jwt

**Applied fix**

- Синхронизировать CI install step с requirements и test
- deps.

**Verification**

- missing import errors gone
- pytest collection green

## CASE-0007 — Broken npm lockfile source

- heal_id: `HEAL-0007`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: npm ci failed

**Applied fix**

- Пересобрать lockfile на публичном registry npmjs.

**Verification**

- npm ci
- lockfile has no vendor/file refs

## CASE-0008 — Vendor patch bypass

- heal_id: `HEAL-0008`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: file: dependency

**Applied fix**

- Вернуть нормальные semver зависимости и честный
- lockfile.

**Verification**

- npm ci
- guard bans passes

## CASE-0009 — Missing symbol import/export

- heal_id: `HEAL-0009`
- archive_version: `legacy-ci`
- action_priority: `planned`

Симптом: ImportError

**Applied fix**

- Сверить реальный экспорт и импорт; фасад держать
- честным.

**Verification**

- pytest collection
- compileall

## CASE-0010 — Pagination contract missing

- heal_id: `HEAL-0010`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: Pagination expected

**Applied fix**

- Добавить/импортировать Pagination там, где она нужна.

**Verification**

- pytest collection
- admin logs flow tests

## CASE-0011 — Alembic backend import path

- heal_id: `HEAL-0011`
- archive_version: `legacy-ci`
- action_priority: `planned`

Симптом: ModuleNotFoundError: backend

**Applied fix**

- Перевести импорты на app.* или migrations.* под
- текущий cwd.
- Не смешивать backend.app.* и app.* в одном контуре.

**Verification**

- alembic upgrade head
- compileall migrations

## CASE-0012 — Migration env NameError

- heal_id: `HEAL-0012`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: NameError

**Applied fix**

- Определить path helper до first use и перепроверить
- sys.path.

**Verification**

- compileall
- alembic import env

## CASE-0013 — Settings field missing

- heal_id: `HEAL-0013`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: parsed_ref_bonus_thresholds missing

**Applied fix**

- Добавить поле в Settings и sane default по канону.

**Verification**

- compileall
- settings import
- pytest affected flow

## CASE-0014 — SQLite row lock unsupported

- heal_id: `HEAL-0014`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: FOR UPDATE

**Applied fix**

- Не адаптировать доменную логику под SQLite.
- Тесты перевести на Postgres-only профиль.

**Verification**

- pytest on Postgres profile
- no sqlite lock errors

## CASE-0015 — SQLite SQL function drift

- heal_id: `HEAL-0015`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: now() missing

**Applied fix**

- Убрать SQLite profile из таких тестов или переписать
- tests.

**Verification**

- pytest
- no sqlite sql syntax errors

## CASE-0016 — TON validator false ban

- heal_id: `HEAL-0016`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: invalid TON address

**Applied fix**

- Перейти на нормальную валидацию формата TON и тесты
- примеров.

**Verification**

- wallet validation tests
- real known address passes

## CASE-0017 — str vs datetime

- heal_id: `HEAL-0017`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: '>' not supported between str and datetime

**Applied fix**

- Нормализовать тип времени до сравнения и на границе
- ввода.

**Verification**

- panel tests
- mypy if typed

## CASE-0018 — Session already begun

- heal_id: `HEAL-0018`
- archive_version: `legacy-runtime`
- action_priority: `immediate`

Симптом: InvalidRequestError: transaction already begun

**Applied fix**

- Убрать вложенный begin().
- Держать одну транзакционную границу в сервисе.

**Verification**

- pytest affected flow
- no nested tx error

## CASE-0019 — Migration smoke NoneType

- heal_id: `HEAL-0019`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: NoneType in migration smoke

**Applied fix**

- Сверить helper contract и защитить от None перед
- обращением.

**Verification**

- migration smoke test
- alembic upgrade head

## CASE-0020 — SQLite schema DDL in tests

- heal_id: `HEAL-0020`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: near SCHEMA syntax error

**Applied fix**

- Запускать такие тесты только на Postgres-only профиле.

**Verification**

- pytest on Postgres profile

## CASE-0021 — Guard binary false positive

- heal_id: `HEAL-0021`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: guard bans hit png

**Applied fix**

- Исключить binary assets или детектировать mime/binary
- mode.

**Verification**

- guard scan passes on png/jpg

## CASE-0022 — Guard alias ban hit

- heal_id: `HEAL-0022`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: bans scan found tg alias

**Applied fix**

- Санировать алиасы до канона tg_id without new bypass
- names.

**Verification**

- guard bans passes
- grep on aliases clean

## CASE-0023 — Idempotency unique race

- heal_id: `HEAL-0023`
- archive_version: `legacy-runtime`
- action_priority: `immediate`

Симптом: duplicate key

**Applied fix**

- Сделать read-through поиск по ключу до insert.
- Повтор отдавать как idempotent result.

**Verification**

- idempotency tests
- concurrency retry tests

## CASE-0024 — Exchange/withdraw race

- heal_id: `HEAL-0024`
- archive_version: `legacy-runtime`
- action_priority: `immediate`

Симптом: race in exchange

**Applied fix**

- Держать атомарные state transitions.
- Использовать row locks и idempotent service path.

**Verification**

- concurrency tests
- ledger invariants hold

## CASE-0025 — Warnings promoted to fail

- heal_id: `HEAL-0025`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: unraisable exception warnings

**Applied fix**

- Исправить источник warning, а не глушить его globally.

**Verification**

- pytest clean warnings

## CASE-0026 — SSL mode mismatch local Postgres

- heal_id: `HEAL-0026`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: sslmode require local postgres fail

**Applied fix**

- Добавлять sslmode только для non-local hosts.

**Verification**

- alembic upgrade head local/ci

## CASE-0027 — Leftover sqlite helper

- heal_id: `HEAL-0027`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: IndentationError _init_sqlite_schema

**Applied fix**

- Удалить/заменить sqlite helper на Postgres fixture
- path.

**Verification**

- compileall tests
- pytest collection

## CASE-0028 — Broken migration env formatting

- heal_id: `HEAL-0028`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: compileall env.py failed

**Applied fix**

- Нормализовать блок search_path injection.
- Проверить quoting и indentation.

**Verification**

- compileall
- bandit B608 context

## CASE-0029 — models __init__ contaminated

- heal_id: `HEAL-0029`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: models __init__ damaged

**Applied fix**

- Переписать __init__.py как чистую фасадную re-export
- точку.

**Verification**

- pytest collection
- compileall

## CASE-0030 — Missing required tables

- heal_id: `HEAL-0030`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: required tables missing after alembic

**Applied fix**

- Сверить ORM tables, 0001, search_path и sanity list.
- Явно указывать схему там, где нужно.

**Verification**

- alembic upgrade head
- sanity db objects
- tables count

## CASE-0031 — Duplicate ORM table define

- heal_id: `HEAL-0031`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: Table already defined

**Applied fix**

- Унифицировать import path на app.* внутри backend cwd.
- Избегать двойной загрузки app.models и
- backend.app.models.

**Verification**

- alembic import
- pytest collection

## CASE-0032 — Archive filename too long

- heal_id: `HEAL-0032`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: unzip file name too long

**Applied fix**

- Укорачивать имена артефактов и путей внутри релиза.

**Verification**

- unzip efhc.zip in CI

## CASE-0033 — Double schema prefix

- heal_id: `HEAL-0033`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: efhc_core.efhc_core.table

**Applied fix**

- Нормализовать имя таблицы перед to_regclass/sanity
- check.

**Verification**

- alembic sanity green

## CASE-0034 — Incomplete metadata from soft imports

- heal_id: `HEAL-0034`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: tables_count_expected got lower count

**Applied fix**

- Импортировать все model modules жёстко и единообразно.

**Verification**

- metadata tables count
- alembic sanity

## CASE-0035 — Config settings export drift

- heal_id: `HEAL-0035`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: config_core did not export settings

**Applied fix**

- Вернуть каноничный export settings из config_core.

**Verification**

- imports from app.core.config_core work

## CASE-0036 — Index schema kwarg invalid

- heal_id: `HEAL-0036`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: Index() got unexpected kwarg 'schema'

**Applied fix**

- Убрать schema= из Index(...).
- Схему задавать только на таблице.

**Verification**

- alembic import
- compileall
- pytest collection

## CASE-0037 — TimestampMixin export missing

- heal_id: `HEAL-0037`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: ImportError TimestampMixin absent in app.models

**Applied fix**

- Добавить TimestampMixin в фасад и унифицировать import
- path.

**Verification**

- alembic import
- pytest collection

## CASE-0038 — Migration writes to impl.stdout

- heal_id: `HEAL-0038`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: AttributeError impl.stdout

**Applied fix**

- Убрать такой вывод и использовать безопасный logger/op
- context.

**Verification**

- alembic upgrade head

## CASE-0039 — DDL not committed

- heal_id: `HEAL-0039`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: migration prints metadata, but tables absent

**Applied fix**

- Проверить transaction scope и op.execute path для DDL.

**Verification**

- tables exist after upgrade
- sanity green

## CASE-0040 — Payment intent contract drift

- heal_id: `HEAL-0040`
- archive_version: `healer-canon`
- action_priority: `immediate`

Симптом: PACKAGE_NOT_FOUND

**Applied fix**

- Сверить service, route, tests и SQL path по одному
- канону.

**Verification**

- pytest payment intents
- DB flow tests

## CASE-0041 — Broken SQL string in tests

- heal_id: `HEAL-0041`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: SyntaxError in pytest collection

**Applied fix**

- Починить шаблон SQL literal и compileall tests.

**Verification**

- pytest collection
- compileall tests

## CASE-0042 — React Query provider missing

- heal_id: `HEAL-0042`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: No QueryClient set

**Applied fix**

- Поднять QueryClientProvider выше места вызова hook.

**Verification**

- next build
- runtime page render

## CASE-0043 — Function import drift in tests

- heal_id: `HEAL-0043`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: append_transfer_extra_info import error

**Applied fix**

- Синхронизировать тестовый импорт с каноничным именем в
- коде.

**Verification**

- pytest collection
- grep old name clean

## CASE-0044 — Direction column too short

- heal_id: `HEAL-0044`
- archive_version: `healer-canon`
- action_priority: `immediate`

Симптом: value too long for type varchar(8)

**Applied fix**

- Расширить длину/constraint под полный набор direction
- values.

**Verification**

- DB migration
- insert/update direction tests

## CASE-0045 — tg_id vs users.id drift

- heal_id: `HEAL-0045`
- archive_version: `healer-canon`
- action_priority: `immediate`

Симптом: JOIN u.id = w.tg_id

**Applied fix**

- Санировать все join/filter path до tg_id only.
- Не вводить алиасы и обходные имена.

**Verification**

- grep suspicious joins
- critical flow tests

## CASE-0046 — Route/service signature drift

- heal_id: `HEAL-0046`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: unexpected keyword argument

**Applied fix**

- Сверить сигнатуры route и service.
- Убрать лишний arg или добавить его в service только
- если он
- реально
- нужен по логике.

**Verification**

- pytest affected flow
- search similar calls

## CASE-0047 — ORM/service/route drift

- heal_id: `HEAL-0047`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: field missing in model/service

**Applied fix**

- Проверять связку route → service → table → migration
- одним
- циклом.
- Обновлять map docs и tests вместе с кодом.

**Verification**

- targeted tests
- MODEL_TABLE_ROUTE_TEST_MAP sync

## CASE-0048 — Unsafe raw SQL schema handling

- heal_id: `HEAL-0048`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: B608

**Applied fix**

- Убрать string-built WHERE и raw schema SQL.
- Перевести на безопасный builder или text() с параметрами.
- Сохранить бизнес-смысл и проверки доступа.

**Verification**

- bandit
- compileall
- search_path works

## CASE-0049 — Documentation table count drift

- heal_id: `HEAL-0049`
- archive_version: `v156_15`
- action_priority: `planned`

Симптом: `SSOT_DB_SCHEMAS_TABLES.md`: 30 vs overview docs: 38

**Applied fix**

- Синхронизирован `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md` по CSV.

**Verification**

- Ручная сверка чисел 38/33/5.

## CASE-0050 — Lotteries terminology scope drift

- heal_id: `HEAL-0050`
- archive_version: `v156_15`
- action_priority: `planned`

Симптом: Blanket ban `draw/draws` conflicted with natural English UI meaning.

**Applied fix**

- Обновлён scope запрета в `docs/SSOT/TERMS_GLOSSARY.md`.

**Verification**

- Проверена согласованность terms и текущего UI-смысла.

## CASE-0051 — Duplicate dataclass decorator

- heal_id: `HEAL-0051`
- archive_version: `v156_15`
- action_priority: `planned`

Симптом: `WithdrawRequestDTO` had duplicate dataclass decoration.

**Applied fix**

- Удалён лишний `@dataclass`; сохранён `@dataclass(frozen=True)`.

**Verification**

- `python -m compileall backend/app`



## CASE-0052 — Shop spending order drift

- heal_id: `HEAL-0052`
- archive_version: `v156_16`
- action_priority: `planned`

Симптом: purchase_with_efhc used manual debit split bonus/main.

**Applied fix**

- Replaced manual debit split with
- spend_user_to_bank_bonus_then_main(...).

**Verification**

- pytest tests/architecture/test_shop_spending_order_canon.py

## CASE-0053 — Missing two-schema guard test

- heal_id: `HEAL-0053`
- archive_version: `v156_16`
- action_priority: `observe`

Симптом: no explicit architecture test for efhc_core/efhc_admin only.

**Applied fix**

- Added direct schema-count guard based on ORM SSOT CSV.

**Verification**

- pytest tests/architecture/test_schema_count_two.py


## CASE-0054 — Energy page archive leakage
- HEAL-ID: HEAL-0054
- Статус: fixed
- Симптом: Energy page смешивала active и archive представление панелей.
- Исправление: archived_count удалён с Energy; оставлены только active_count и generation active panels.


## CASE-0055 — DB-backed MonetaryIdempotency TTL lock

- heal_id: `HEAL-0055`
- archive_version: `v156_19`
- action_priority: `planned`

Симптом: MonetaryIdempotencyMiddleware держал TTL duplicate barrier в памяти процесса.

**Applied fix**

- Удалён self._ttl_seen из middleware.
- Добавлен atomic DB-backed TTL lock через efhc_admin.idempotency_key.
- Тест обновлён под shared lock helper.

**Verification**

- `python -m compileall backend/app/core/system_locks.py tests/core/test_monetary_idempotency_middleware.py`


## CASE-0056 — GlobalHeader menu and user-status badges

- heal_id: `HEAL-0056`
- archive_version: `v156_20`
- action_priority: `planned`

Симптом: header скрывал вход в профиль только за аватаром и не показывал статусы VIP/Activ.

**Applied fix**

- Added profile.has_activ to sync snapshot.
- Added VIP and Activ badges to GlobalHeader and ProfileModal.
- Added explicit Menu button in GlobalHeader.
- Renamed visible profile UI labels to Menu.

**Verification**

- `python -m compileall backend/app/routes/sync_routes.py`
- `grep profile.has_activ frontend/src/hooks/useSnapshot.ts frontend/src/components/Layout.tsx frontend/src/components/GlobalHeader.tsx frontend/src/components/ProfileModal.tsx`

## CASE-0057 — Global rename from split profile wording to profile

- Heal ID: HEAL-0057
- Result: old split profile wording removed from user-facing archive texts.
- Verification: repo grep on old wording returned zero matches.

## CASE-0058 — Docker local environment upgraded

- archive: `v156_22`
- result: добавлен практический локальный Docker-стенд для db, backend и frontend.


## CASE-0059 — DB-backed tg_id monetary rate limiting middleware

- Heal ID: HEAL-0059
- Archive: `v156_23`
- Result: monetary routes now have shared tg_id-based rate limiting in runtime.

**Applied fix**

- Added MonetaryRateLimitMiddleware for monetary paths.
- Implemented DB-backed slot acquisition by tg_id and scope path.
- Enabled middleware in backend/app/main.py.
- Added architecture guard for middleware wiring.

## CASE-0060 — Replaced HTTPException in service layer

- Heal ID: `HEAL-0060`
- Result: lotteries/tasks services now use domain errors instead of `HTTPException`.

## CASE-0061 — Refactored _run_idempotent retry policy helpers

- Heal ID: `HEAL-0061`
- Archive: `v156_25`
- Result: `_run_idempotent` became easier to audit without reducing monetary safety.

**Applied fix**

- Added `_is_idempotency_conflict(exc)`.
- Added `_is_transient_tx_error(exc)`.
- Added `_read_through_existing_tx(...)`.
- Added `_mark_idempotency_conflict(...)`.
- Preserved retries only for unique idempotency_key, deadlock and serialization.


## CASE-0062 — Prepared v157 continuation prompt and synced AL docs

- Heal ID: `HEAL-0062`
- Archive: `v157_00`
- Fix: создан `docs/AI/CONTINUE_NEW_CHAT_V157_PROMPT.md`, обновлены AL-документы и записи цикла.
- Result: `resolved`.

## CASE-0063 — Cleaned release ZIP and restored canonical Profile term

- Heal ID: `HEAL-0063`
- Archive: `v157_01`
- Fix: удалены кэши из релизной упаковки, русский FAQ SSOT и runtime приведены к канону `Профиль`.
- Result: `resolved`.


## v157_02 / logs_60244480535
- Circular import around `app.models.Base` caused alembic/pytest failures.
- Fixed by extracting shared ORM base into `backend/app/models/base.py`.
- Also fixed mypy, bandit, frontend type drift and ruff issues confirmed by log `60244480535`.


## CASE-0064 — Residual CI tails after v157_02

- Heal ID: `HEAL-0064`
- Archive: `v157_03`
- Fix: восстановлены missing imports в `lotteries_routes.py`,
  устранены line72-хвосты, санированы offending logs, casebook
  доведён по `confirmation_basis`.
- Result: `resolved`.


## CASE-0065 — Tournament-themed user-facing copy sync

- Heal ID: `HEAL-0065`
- Archive: `v157_04`
- Fix: синхронизированы user-facing тексты Турниры / Начать раунд / Стоимость входа / Раунд в locale, runtime FAQ и русском FAQ SSOT.
- Result: `resolved`.


## CASE-0066 — FAQ section-name wording drift
- heal_id: HEAL-0066
- status: fixed
- archive_version: v157_05
- symptom_excerpt: В FAQ сохранялись смешанные названия раздела 14 (`Lotteries`, `Розіграші`, `Lotterien`, `Loteries`, `Lotterie`, `Loterie`, `Lotterier`, `Çekilişler`).
- applied_fix: Во всех FAQ-слоях раздел 14 приведён к `Турниры / Турніри / Tournaments`.
- confirmation_basis: прямой аудит файлов FAQ и нулевой остаток по поиску старых section-name терминов.
- result: fixed


## CASE-0067 — Residual tournaments wording drift cleanup

- heal_id: HEAL-0067
- archive_version: v157_06
- symptom_excerpt: в user-facing слоях после v157_05 ещё оставались `Tournamentsr`, `lotteries`, `розіграш`, `Çekiliş` и bot fallback `Lotteries`
- applied_fix: выполнена дочистка locale, runtime FAQ, FAQ SSOT, bot handlers и visible error message
- forbidden_fix: не переименовывать технический домен `lotteries_*` в рамках текстовой чистки
- verification_done: поиск по user-facing слоям на legacy terms чистый
- result: остались только технические комментарии и доменные имена


## CASE-0068 — Residual user-facing tournaments drift in FAQ SSOT pack

- heal_id: HEAL-0068
- archive_version: v157_07
- symptom_excerpt: после `v157_06` в runtime FAQ, FAQ SSOT, `FAQ_SSOT_20_SECTIONS.json` и `README.md` ещё оставались legacy terms о lotteries/розыгрышах.
- applied_fix: выполнена повторная дочистка `frontend/src/data/faq/*`, `docs/SSOT/faq_ssot/**`, `docs/SSOT/ssot_pack/FAQ_SSOT_20_SECTIONS.json`, а в locale values приведён `lotteries.cost` к канону.
- forbidden_fix: technical domain `lotteries_*` не переименовывался.
- verification_done: поиск по user-facing FAQ/source files пустой; JSON locale values валидны и без legacy terms.
- result: fixed


## CASE-0069 — Lotteries full-domain removal baseline

- heal_id: HEAL-0069
- archive_version: v157_08
- symptom_excerpt: пользователь потребовал удалить из кода и архива весь lotteries domain; прямой аудит HEAD подтвердил 1977 совпадений с высокой концентрацией в backend routes/services/models/crud, frontend page/locale и SSOT docs.
- applied_fix: выполнен baseline audit и создан 20-cycle decommission map.
- forbidden_fix: не делать массовое удаление вслепую без карты импортов, API/ORM/docs связей и без явной фиксации исторических записей.
- verification_done: подтверждены основные зоны и файлы высокой плотности; серия decommission открыта.
- result: pending removal


## CASE-0069A — Coupling audit extension

- date: 2026-03-25
- cycle: 02
- symptom_excerpt: lotteries подтверждён как связанная подсистема с frontend entry points, bot handlers, public/admin routes, schemas, services, crud, models и SSOT docs.
- applied_fix: выполнен аудит связей и зафиксирован безопасный порядок staged removal.
- next_step: cycle 03 — удалить frontend entry points и navigation hooks.


## CASE-0069B — Frontend entry points removal

- date: 2026-03-25
- cycle: 03
- symptom_excerpt: основной пользовательский вход в lotteries-domain сохранялся в `frontend/src/pages/panels.tsx` через button redirect и CTA-link на `/lotteries`.
- applied_fix: удалены user-facing переходы и CTA-card из Panels; сама страница `frontend/src/pages/lotteries.tsx` оставлена до отдельного цикла удаления страницы.
- verification_done: `npm --prefix frontend run build` — OK.
- next_step: cycle 04 — убрать runtime locale keys и FAQ bindings, cycle 05 — удалить саму frontend page.


## CASE-0069B — Frontend entry points removal

- date: 2026-03-25
- cycle: 03
- symptom_excerpt: основной пользовательский вход в lotteries-domain сохранялся в `frontend/src/pages/panels.tsx` через button redirect и CTA-link на `/lotteries`.
- applied_fix: удалены user-facing переходы и CTA-card из Panels; сама страница `frontend/src/pages/lotteries.tsx` оставлена до отдельного цикла удаления страницы.
- verification_done: поиск по `frontend/src/pages/panels.tsx` на `lotteries`, `/lotteries`, `lotteries_hint`, `open_lotteries`, `nav.lotteries` — пустой.
- environment_note: локальная `next build` не подтверждена в этой среде, потому что отсутствуют установленные frontend dependencies.
- next_step: cycle 04 — убрать runtime locale keys и FAQ bindings, cycle 05 — удалить саму frontend page.


## CASE-0070 — lotteries runtime locale / FAQ bindings drift

- heal_id: `HEAL-0069`
- archive_version: `v157_11`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Removed dead Panels locale keys from all runtime locale JSON files.
- Removed runtime FAQ section 14 in `ru.ts` and `catalogs.ts`.
- Removed runtime FAQ meta labels `14` / `14.1`.
- Cleaned remaining runtime FAQ tournament references in general answers.

**Verification**
- grep on removed locale keys
- grep on runtime FAQ section/meta
- JSON reload of locale files


## CASE-0071 — lotteries frontend page removal

- heal_id: `HEAL-0069`
- archive_version: `v157_12`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `frontend/src/pages/lotteries.tsx`.
- Removed direct frontend client calls to `/api/lotteries*` by removing the page module.

**Verification**
- file absence check for `frontend/src/pages/lotteries.tsx`
- grep on `frontend/src/**` for `/api/lotteries`


## CASE-0072 — lotteries bot-visible handlers removal

- heal_id: `HEAL-0069`
- archive_version: `v157_13`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/bot/handlers/lotteries_handlers.py`.
- Deleted `backend/app/bot/handlers/admin/admin_lotteries_handlers.py`.
- Removed lotteries router import/include from `backend/app/bot/bot.py`.
- Removed admin lotteries router import/include from `backend/app/bot/handlers/admin_handlers.py`.
- Removed `🎟 Лотереи` button from `backend/app/bot/keyboards.py`.

**Verification**
- grep on bot layer for `lotteries_handlers`, `admin_lotteries_handlers`, `lotteries_router`, `/lotteries`, `🎟 Лотереи`
- `pytest -q tests/architecture/test_frontend_page_shell_coverage.py`


## CASE-0073 — lotteries public API routes removal

- heal_id: `HEAL-0069`
- archive_version: `v157_14`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/routes/lotteries_routes.py`.
- Removed `lotteries_routes` from `backend/app/routes/__init__.py`.
- Synced route-coupled tests and docs for removed public lotteries endpoints.

**Verification**
- file absence check for `backend/app/routes/lotteries_routes.py`
- grep on `backend/app/routes/**` for `lotteries_routes` and `/api/lotteries`
- `python -m compileall backend/app/routes`

## CASE-0069 — 2026-03-25 — cycle 08

- Removed admin lotteries routes and related facade exposure.
- Synced admin contract surface and SSOT route maps.


## CASE-0074 — lotteries schema/contract layer removal

- heal_id: `HEAL-0069`
- archive_version: `v157_16`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/contracts/lotteries_contract.py`.
- Deleted `backend/app/schemas/lotteries_schemas.py`.
- Deleted `backend/app/schemas/admin/admin_lotteries_schemas.py`.
- Removed `AdminLotteriesOut` / `AdminLotteriesUpsertIn` from admin schema surface and re-export wrappers.

**Verification**
- `python -m compileall backend/app/schemas backend/app/contracts`
- grep on exact leftovers `AdminLotteriesOut|AdminLotteriesUpsertIn|lotteries_schemas.py|lotteries_contract.py|admin_lotteries_schemas.py`


## CASE-0075 — lotteries service layer removal

- Deleted `backend/app/services/lotteries_service.py`.
- Deleted `backend/app/services/admin/admin_lotteries_service.py`.
- Synced direct tests that referenced removed service files.
- Removed stale SSOT/doc references to deleted service paths.

Verification:
- file absence checks for both deleted service files
- `python -m compileall backend/app/services backend/app/services/admin`
- `pytest -q tests/efhc_backend/unit/test_prizes_autocycle_ssot.py tests/efhc_backend/unit/test_prizes_smoke.py tests/architecture/test_services_no_http_exception.py`


## CASE-0076 — lotteries CRUD layer removal

- heal_id: `HEAL-0069`
- archive_version: `v157_18`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/crud/lotteries_crud.py`.
- Deleted `backend/app/crud/admin/admin_lotteries_crud.py`.
- Removed lotteries alias and CRUD health-check requirements from `backend/app/crud/__init__.py`.
- Synced decommission guard test to assert CRUD-layer removal.

**Verification**
- file absence checks for both deleted CRUD files
- `python -m compileall backend/app/crud backend/app/crud/admin`
- `pytest -q tests/efhc_backend/unit/test_prizes_autocycle_ssot.py`


## CASE-0077 — lotteries tests/fixtures removal

- heal_id: `HEAL-0069`
- archive_version: `v157_20`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted lotteries-specific test files.
- Reduced generic architecture guards/tests to non-lotteries scope.
- Synced `docs/NORM/TESTS_CATALOG.md` and overview-doc counts.

**Verification**
- `pytest -q tests/architecture/test_services_no_http_exception.py tests/architecture/test_great_canon_guard.py tests/architecture/test_docs_ssot_sync.py`
- `python -m compileall tests/architecture`

- 2026-03-25 v157_21: cycle 14 removed lotteries env/config surface (`LOTTERIES_*` example vars, config_core settings block, admin_settings lotteries keys).

## CASE-0078 — lotteries ops guards/checks removal

- heal_id: `HEAL-0069`
- archive_version: `v157_22`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted lotteries-only canon guard `check_lotteries_auto_cycle_ssot(...)`.
- Deleted lotteries-only idempotency path patterns from `ops/canon_rules.yaml`.
- Deleted scheduler soft-import and registration for `lotteries_autorestart`.

**Verification**
- `python -m compileall ops backend/app/services`
- grep absence checks for `check_lotteries_auto_cycle_ssot`, `LOTTERIES_SCHEDULER_FORBIDDEN`, `LOTTERIES_SERVICE_MISSING`, `lotteries_autorestart`


## v157_23 / cycle 16
- Rebuilt docs layer and removed active lotteries-domain references from docs/overview/glossary/API descriptions.

## CASE-0079 — lotteries SSOT structural residue
- symptom_excerpt: после демонтажа route/model/service слоя в `docs/SSOT/ssot_pack` всё ещё оставались активные lotteries rows/sections в `SSOT_TABLES_PURPOSE_RU.md`, `SSOT_TABLES_MIGRATIONS.csv`, `SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md`.
- applied_fix: удалены lotteries sections/rows/bullets из трёх SSOT-файлов, документ циклов и reports обновлены.
- verification_done: точный grep по `docs/SSOT/ssot_pack` на lotteries-термины пустой; `pytest -q tests/architecture/test_docs_ssot_sync.py`.

## CASE-0080 — lotteries legacy DB / migration policy
- symptom_excerpt: после снятия active lotteries-domain оставались только historical mentions в reports/healer/audits и требовалось зафиксировать, что это не active SSOT.
- applied_fix: в DB/SSOT canon docs добавлена политика historical traces; новые drop-migrations без DB/CI/audit подтверждения запрещены в этой серии.
- verification_done: active DB SSOT docs сохраняют только две схемы; прямой аудит не подтверждает active lotteries-trace в `backend/migrations/**` и DB SSOT слое.


## CASE-0081 — lotteries final residual traces
- heal_id: `HEAL-0069`
- archive_version: `v157_26`
- confirmation_basis: `direct_file_audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted dead frontend locale keys `lotteries.*`.
- Removed active backend/doc comments and descriptions that still mentioned lotteries-domain.
- Renamed `LotteriesClosedError` to `ParticipationClosedError`.
- Removed active admin DTO field `lotteries_id`.
- Removed `logs/` from release archive as stale artifact.

**Verification**
- residual grep across active tree excluding historical buckets
- `python -m compileall backend/app ops`
- locale JSON validation


## CASE-0069R — Final closure

- date: 2026-03-25
- cycle: 20
- symptom_excerpt: требовалось подтвердить, что после staged decommission в active tree не осталось lotteries-domain, а historical mentions сохранены только как история лечения и аудита.
- applied_fix: выполнен финальный residual grep по active tree, завершены контрольные compile/test проверки, серия decommission закрыта.
- verification_done: `FOUND 0` по active tree; `python -m compileall backend/app ops tests/architecture`; `pytest -q tests/architecture/test_docs_ssot_sync.py tests/architecture/test_great_canon_guard.py tests/architecture/test_services_no_http_exception.py`.
- result: resolved

## CASE-0082 — runtime drift inventory / unified cycles register
- date: 2026-03-26
- cycle: 21
- archive_version: v157_29
- symptom_excerpt: после закрытия lotteries decommission оставался разрозненный учёт следующих рабочих серий и не было единого inventory mismatch-классов между SSOT, runtime, docs, tests и release artifact.
- applied_fix: создан единый документ циклов 1–40 и отдельный runtime drift inventory с контрольными числами и точками проверки.
- verification_done: inventory собран по active tree; контрольные архитектурные pytest-проверки проходят.
- result: resolved

- 2026-03-26 v157_30 cycle 22: FAQ/runtime sync hardened with deterministic SSOT generator and exact-match guard.

- CASE-0070: fixed route-surface drift (`/api` embedded in local route prefixes/paths), added `test_route_prefixes_no_embedded_api.py`, verified compileall + architecture tests.

- 2026-03-26 / Cycle 24: admin route surface canonicalized; added admin route module guard; synced docs counts/catalog; line72 tail fixed.

## CASE-0083 — route/service/table docs count drift
- date: 2026-03-26
- cycle: 27
- archive_version: v158_04
- symptom_excerpt: active docs for SSOT routes still reported 91/92 routes while canonical CSV registry contained 82 routes after route cleanups.
- applied_fix: synced active docs counts and added architecture guard `test_ssot_route_count_docs_sync.py`.
- verification_done: `docs/SSOT/ssot_pack/SSOT_ROUTES.csv` row count = 82; targeted pytest guard passes.
- result: resolved
## 2026-03-26 — cycle 28 — startup/OpenAPI consistency
- symptom_excerpt: `api/index.py` stopped after env bootstrap and exported no `app`; `backend/openapi/openapi.json` contained only `/health` and `/api/cron/tick` while SSOT route registry contained 82 active paths.
- confirmed_root_cause: stale/truncated Vercel entry file and stale exported OpenAPI artifact not synchronized with SSOT route surface.
- fix: restored `api/index.py` import/export contract, regenerated `backend/openapi/openapi.json` from `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`, added `tests/architecture/test_openapi_startup_consistency.py`.
- CASE-0086: route inventory freeze added for active route surface; fresh CI failure in the same cycle was limited to `ruff` import order in the FAQ guard test and was fixed before freeze verification.


## CASE-0087 — idempotency surface full-path audit
- date: 2026-03-26
- cycle: 33
- archive_version: v158_10
- symptom_excerpt: route idempotency guard missed drift because it parsed only local route strings without router prefixes and did not inspect Depends defaults.
- applied_fix: rebuilt guard, synced canon regex to active routes, corrected stale SSOT path `/admin/referrals/reassign`, added CSV/markdown audit artifacts.
- verification_done: targeted architecture pytest passes; generated idempotency surface docs match CSV counts.
- result: resolved

- CASE-0088 — Cycle 34 fixed response/error canon drift by registering `setup_exception_handlers(app)` and normalizing object-detail payload keys in `payment_intents_routes.py` and `wallets_routes.py`.


## Cycle 36
- Confirmed by `logs_62194714005.zip`: banned tg_id alias terms remained in `docs/SSOT/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json`.
- Treatment: replaced alias mentions with tg_id-only wording, updated migration invariants to 32 tables / 2 schemas / ORM-only 0001, added dedicated guard.

- CASE-0088: cycle 37 removed stale DB totals 38/33 and repaired malformed legacy policy paragraphs in active DB docs.

## 2026-03-26 — cycle 38 — route matrix/OpenAPI docs sync
- symptom_excerpt: `MODEL_TABLE_ROUTE_TEST_MAP.md` kept stale counts and referenced missing `backend/app/models/exchange_routes.py`.
- confirmed_root_cause: route matrix markdown was not synchronized after recent route/OpenAPI/test-file growth.
- fix: updated counts to current SSOT/OpenAPI values, replaced missing model file reference, added `tests/architecture/test_openapi_docs_route_matrix_sync.py`.

- CASE-0090: cycle 39 removed `.local_artifacts/`, `logs/` and `*.log` from release ZIP packaging surface.

- CASE-0092 / HEAL-0080: final regression pack of cycles 31–40 caught stale `test files` count in `MODEL_TABLE_ROUTE_TEST_MAP.md`; corrected from 111 to 112 and series closed.

## CASE-0090
- Сценарий: нужно начать FAQ purge без точного freeze и без RU candidate count.
- Решение: сначала фиксировать inventory и список прямых risk-кандидатов, потом запускать purge wave.

- CASE-0093: RU FAQ review wave 2 created a manual confirmation list instead of auto-deleting section 14 candidates.

- CASE-0094: cycle 44 replaced five weak section-14 Q/A with more practical WebApp guidance while keeping totals stable.
- cycle 45: faq translations/runtime parity wave 1 — done (v158_22)
- CASE-0096: cycle 46 ran a zero-candidate audit for RU direct-risk FAQ wave 2 and confirmed no new removals were needed.



- CASE-0097: cycle 47 created RU weak/duplicate manual-review list with 5 groups / 7 Q/A and no automatic FAQ edits.

- CASE-0091: Section 14 weak/duplicate groups resolved by strengthening 8 Q/A while keeping 17-item section stable.

- CASE-0098: cycle 50 resolved RU duplicate wave 2 by refining 6 Q/A across sections 3, 8 and 16 with totals unchanged.

- CASE-0099 / HEAL-0087: cycle 51 synced 6 RU duplicate-resolution FAQ IDs across 12 non-RU languages and regenerated runtime catalogs.


- Cycle 52 case: duplicate audit wave 3 required audit_only lock instead of silent FAQ mutation.

## CASE-0100 — cycle 53 resolved 4 duplicate groups in RU FAQ wave 3
- Архив: v158_30
- База подтверждения: direct audit of `docs/SSOT/faq_ssot/ru/faq_ru.md` and `faq_ru.json`.
- Действия: усилены 8 RU Q/A, regenerated runtime FAQ catalogs, review file marked resolved.


## CASE-0101
- Archive: v158_31
- Heal: HEAL-0089
- Title: cycle 54 synced non-RU FAQ layers for 8 mirrored ids after RU duplicate resolution wave 3.

## CASE-0109
- Archive: v159_13
- Heal: HEAL-0098
- Title: cycle 67 froze the EFHC handoff architecture boundary for Hub.
- Confirmation basis: direct audit of `frontend/src/pages/shop.tsx`,
  `backend/app/routes/shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/schemas/shop_schemas.py`,
  `backend/app/contracts/shop_contract.py`, and `docs/SSOT/HUB_SSOT.md`.
- Treatment history:
  - added `docs/HUB_EFHC_HANDOFF_ARCHITECTURE_AUDIT.md`
  - froze signed short-lived one-time token requirements
  - blocked direct reuse of Shop commerce contracts as the future Hub
    public contract


Cycle 69 note: active runtime aggregate FAQ and locale help-text kept stale VIP-in-Shop wording after Hub card had already moved to external GetGems; fixed without changing ownership-check logic.


## CASE-0110
- Archive: v159_16
- Heal: HEAL-0099
- Title: cycle 70 removed residual commerce wording from active skin locale layer.
- Confirmation basis: direct audit of `frontend/public/locale/*.json`
  and `frontend/src/lib/skins.ts`; targeted pytest lock.
- Treatment history:
  - rewrote active skin locale keys in all 13 languages
  - removed "Shop skins" wording from frontend skin helper
  - locked the 12-level progression theme canon


## HEAL-0099 / CASE-0110
- Symptom: after the user-facing skin wording cleanup, the active
  model/data/service/API/helper layer still retained a legacy commerce
  bridge for skins.
- Fix in cycle 71: added `docs/SKINS_MODEL_DATA_AUDIT.md`, confirmed the
  active legacy markers `price_efhc`, `purchased_at`,
  `POST /skins/buy/{skin_id}`, `buy_skin(...)`, `skin_purchase`,
  `getShopSkinBgUrl(...)`, and `efhc_shop_skin_changed`, and added
  `tests/architecture/test_skins_model_data_audit_lock.py`.
- Verification: direct audit of HEAD `v159_16`, including
  `backend/app/models/skins_models.py`,
  `backend/app/routes/skins_routes.py`,
  `backend/app/schemas/skins_schemas.py`,
  `backend/app/services/skins_service.py`,
  `backend/app/standards/skins_catalog.py`, and
  `frontend/src/lib/skins.ts`.


## 2026-03-28 — Cycle 75 Hub admin routes/services
- Подтверждён archive-first drift: следующий цикл по HEAD — `75`, не `76`.
- Закрыт backend слой Hub admin manager: list/create/update/toggle/reorder.
- Добавлены новые active endpoints `/admin/hub/links` и технические алиасы `/admin/shop/hub-links`.
- Price/order semantics не переносились в `hub_links`.


## 2026-03-28 — Cycle 76 Hub admin UI wave
- Подтверждено: frontend admin page ещё жила на legacy Shop-orders/set-price semantics.
- `frontend/src/pages/admin/shop.tsx` переведён на Hub Links Manager.
- Active UI вызывает `/admin/hub/links`, create/update/toggle/reorder.
- Из active admin UI убраны order/price fields; `/admin/shop` сохранён как технический route alias.


## CASE-0111
- Archive: v160_02
- Heal: HEAL-0100
- Title: cycle 77 froze the Russian Hub FAQ section 13 draft because the
  active runtime had already moved ahead of the SSOT export.
- Confirmation basis: direct audit of `frontend/src/data/faq/ru.ts`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`, and `docs/cycles/WORK_CYCLES.md`.
- Treatment history:
  - confirmed archive-first drift between runtime and SSOT FAQ section 13
  - added `docs/HUB_FAQ_SECTION_13_RU_DRAFT.md`
  - froze the 13-question approval list for the Russian Hub section


## CASE-0112
- Archive: v160_03
- Heal: HEAL-0101
- Title: cycle 78 corrected the false FAQ runtime assumption and froze the real Shop→Hub drift map.
- Confirmation basis: direct audit of `frontend/src/data/faq/catalogs.ts`, `docs/SSOT/faq_ssot/ru/faq_ru.md`, `docs/SSOT/faq_ssot/ru/faq_ru.json`, `backend/app/bot/handlers/shop_handlers.py`, and `frontend/public/locale/*.json`.
- Treatment history:
  - rejected the prior unconfirmed statement about `frontend/src/data/faq/ru.ts`
  - confirmed active `Shop` traces in runtime/SSOT/bot/locale layers
  - added `docs/HUB_FAQ_CROSS_SECTION_DRIFT_AUDIT.md`


## CASE-0113
- Archive: v160_04
- Heal: HEAL-0102
- Title: cycle 79 rewrote the Russian SSOT FAQ from Shop semantics to Hub canon.
- Confirmation basis: direct audit of `docs/SSOT/faq_ssot/ru/faq_ru.md`, `docs/SSOT/faq_ssot/ru/faq_ru.json`, and `docs/cycles/WORK_CYCLES.md`.
- Treatment history:
  - replaced user-facing `Shop` mentions in RU SSOT navigation answers
  - rewrote section 13 from `Shop` to `Hub`
  - fixed EFHC/VIP wording to external flows and skins to progression rewards


## CASE-0114
- Archive: v160_05
- Heal: HEAL-0103
- Title: cycle 80 rebuilt runtime FAQ from SSOT and closed the Russian runtime drift.
- Confirmation basis: generator run `ops/scripts/generate_faq_catalogs_from_ssot.py`, guard `test_faq_catalogs_generated_from_ssot.py`, and direct audit of `frontend/src/data/faq/catalogs.ts`.
- Treatment history:
  - rebuilt `frontend/src/data/faq/catalogs.ts` from `docs/SSOT/faq_ssot/*/faq_*.json`
  - confirmed Russian runtime section `13. Hub` and `250/250` parity
  - confirmed no `Shop` residuals inside the RU runtime chunk


## CASE-0115
- Archive: v160_06
- Heal: HEAL-0104
- Title: cycle 81 synchronized the bot help/text layer with Hub and fixed the text helper call contract.
- Confirmation basis: direct audit of `backend/app/bot/texts.py`, `backend/app/bot/handlers/shop_handlers.py`, `backend/app/bot/handlers/admin/admin_shop_handlers.py`, and `python -m compileall backend/app/bot`.
- Treatment history:
  - replaced Shop-facing bot/help strings with Hub-facing text
  - preserved `/shop` and `/admin_shop` as technical aliases
  - made `t()` compatible with both old and new call styles

## CASE-0116
- Archive: v160_07
- Heal: HEAL-0104
- Title: cycle 82 synchronized multilingual SSOT FAQ with the Hub canon and rebuilt runtime parity.
- Confirmation basis: direct audit of `docs/SSOT/faq_ssot/*/faq_*.json` and `docs/SSOT/faq_ssot/*/faq_*.md`, residual grep for `Shop`, generator run `ops/scripts/generate_faq_catalogs_from_ssot.py`, and guard `test_faq_catalogs_generated_from_ssot.py`.
- Treatment history:
  - replaced active Shop-facing section 13/top-bar/navigation FAQ wording in all 12 non-Russian languages
  - regenerated markdown SSOT exports from the updated JSON files
  - rebuilt `frontend/src/data/faq/catalogs.ts` from SSOT and verified generator parity


- 2026-03-28 cycle 83: docs/openapi sync closed; Hub admin surface `/admin/hub/links*` and public handoff `POST /hub/efhc-handoff` added to SSOT/OpenAPI/docs, route count synced to 88.


## CASE-0117
- Archive: v160_09
- Heal: HEAL-0105
- Title: cycle 84 locked the active Hub surface with a dedicated regression pack.
- Confirmation basis: direct audit of `frontend/src/pages/shop.tsx`, `frontend/src/pages/hub.tsx`, `frontend/src/pages/admin/hub.tsx`, `frontend/src/components/GlobalHeader.tsx`, `backend/app/routes/hub_routes.py`, `backend/app/bot/keyboards.py`, `backend/app/bot/texts.py`, and pytest pass of the Hub regression pack.
- Treatment history:
  - added a dedicated guard for the alias `shop -> hub`
  - locked the ban on prices, TonConnect, internal purchase, and skin SKU in active Hub UI
  - locked signed external EFHC handoff and external VIP GetGems flow


## HEAL-0106 / CASE-0118
- Symptom: after the main Hub migration waves, the repository still contained a broad `shop` footprint, but the traces were mixed across active backend commerce code, temporary aliases, historical audit records, and true cleanup-ready residues.
- Fix in cycle 85: added `docs/LEGACY_SHOP_RESIDUE_AUDIT.md` and classified the remaining `shop` traces into keep-as-commerce, keep-as-alias, keep-as-history, and cleanup-candidates-for-cycle-86 buckets.
- Verification: direct HEAD grep across `backend`, `frontend`, `docs`, and `tests`, plus usage checks for locale keys and active admin/profile surfaces.

## 2026-03-28 — cycle 86
- Подтверждённая проблема: после residue-аудита оставались cleanup-ready user-facing/docs residuals `Shop`, хотя backend commerce domain и compatibility aliases ещё нужны.
- Исправлено: удалены 143 мёртвых locale-ключа `admin.shop_orders_summary`, `desc.shop.*`, `shop.*` из `frontend/public/locale/*.json`; исправлены stale docs wording в `docs/FAQ_COVERAGE_MATRIX.md`, `docs/NORM/ADMIN_RBAC.md`, `docs/GENERAL/specification.md`, `frontend/public/skins/README.txt`.
- Проверено: direct grep по `frontend/public/locale` больше не находит удалённые dead keys; JSON всех locale-файлов валиден.

## CASE-0119
- Archive: v160_12
- Heal: HEAL-0107
- Title: cycle 87 locked the transition layer under alias pressure.
- Confirmation basis: direct audit of `frontend/src/pages/hub.tsx`, `frontend/src/pages/shop.tsx`, `frontend/src/pages/admin/hub.tsx`, `backend/app/bot/handlers/shop_handlers.py`, `backend/app/bot/handlers/admin/admin_shop_handlers.py`, `backend/app/routes/admin_shop_routes.py`, locale files, and pytest pass of the alias pressure test.
- Treatment history:
  - locked `/hub` as the primary user-facing surface
  - kept `/shop` and `/admin_shop` as compatibility aliases
  - kept `/admin/shop/hub-links*` aligned with `/admin/hub/links*`

## CASE-0120
- Archive: v160_13
- Heal: HEAL-0108
- Title: cycle 88 formalized the safe alias removal design before any real `shop` alias deletion.
- Confirmation basis: direct audit of `docs/SSOT/HUB_SSOT.md`, `docs/LEGACY_SHOP_RESIDUE_AUDIT.md`, `docs/HUB_ALIAS_PRESSURE_TEST.md`, and `docs/cycles/WORK_CYCLES.md`.
- Treatment history:
  - separated alias-removal candidates from backend commerce domain
  - fixed explicit preconditions before cycle 89
  - documented wave-by-wave removal policy and evidence checks

- Cycle 89 case: safe wave-1 alias removal executed as internal canonicalization only; public `/shop` and `/admin/shop` compatibility preserved, live implementation moved into `hub` files.

- 2026-03-28 / cycle 90: final commerce cleanup + release stabilization — removed dead `frontend/src/components/ShopGrid.tsx`, aligned active UI doc `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`, renamed canonical admin component export to `AdminHubPage`, preserved `/shop` and `/admin/shop` compatibility aliases, targeted regression pack required.


## CASE-0121
- Archive: v160_16
- Heal: HEAL-0109
- Title: cycle 91 closed the postponed skin switcher concept as a separate SSOT layer.
- Confirmation basis: direct audit of skin runtime/helper/model/service/route files and new concept document `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`.
- Treatment history:
  - separated skin switcher from Hub
  - separated switcher from legacy commerce-domain
  - fixed cumulative unlock rule and `active_skin_id` fallback policy
  - marked old cycle 72 as resolved later by cycle 91


## CASE-0122
- Archive: v160_17
- Heal: HEAL-0110
- Title: cycle 92 added the first separate runtime/API layer for the skin switcher.
- Confirmation basis: direct audit of new `/skins/switcher*` endpoints, schema/helper surface, and active-skin synchronization logic against the progression canon.
- Treatment history:
  - added dedicated switcher endpoints
  - added `current_level`, `available_skin_ids`, `active_skin_id`, `items[]`
  - kept legacy `/skins/buy` bridge untouched
  - synchronized `active_skin_id` with highest unlocked fallback


## CASE-0123
- Archive: v160_18
- Heal: HEAL-0111
- Title: cycle 93 mapped real alias callers before wave-2 removal.
- Confirmation basis: direct audit of wrapper pages, bot alias commands, keyboard deep links, admin index, and current router wiring.
- Treatment history:
  - confirmed `/shop` and `/admin_shop` as active bot aliases
  - confirmed `/admin/shop` as the only internal admin caller
  - confirmed no current keyboard deep link to `/shop`
  - moved thin wrapper modules into cleanup candidates for cycle 94


## CASE-0124
- Archive: v160_19
- Heal: HEAL-0112
- Title: cycle 94 removed the confirmed thin alias residue without touching external compatibility surfaces.
- Confirmation basis: direct audit of `frontend/src/pages/admin/index.tsx`, live bot routers, deleted wrapper modules, and targeted pytest pass.
- Treatment history:
  - moved internal admin link from `/admin/shop` to `/admin/hub`
  - removed `shop_handlers.py`
  - removed `admin_shop_handlers.py`
  - preserved `/shop`, `/admin_shop`, page aliases, and backend commerce `/shop/*`


## CASE-0125
- Archive: v160_20
- Heal: HEAL-0113
- Title: cycle 95 stabilized bot and WebApp admin entrypoints around Admin Hub.
- Confirmation basis: direct audit of bot keyboards, admin handlers, help texts, and targeted pytest pass.
- Treatment history:
  - added `kb_admin_entry()`
  - pointed `/admin` and `/admin_hub` directly to `/admin/hub`
  - listed `/admin_hub` and `/admin_shop` explicitly in help texts


## CASE-0126
- Archive: v160_21
- Heal: HEAL-0114
- Title: cycle 96 froze docs and OpenAPI after alias waves without changing the HTTP surface.
- Confirmation basis: direct audit of `docs/NORM/TESTS_CATALOG.md`, `docs/POST_ALIAS_DOCS_OPENAPI_FREEZE.md`, `frontend/src/pages/admin/index.tsx`, and `backend/openapi/openapi.json`.
- Treatment history:
  - documented `/admin/hub` as the current internal admin entry
  - preserved `/shop` and `/admin_shop` as compatibility aliases
  - confirmed OpenAPI route stability
  - removed stale active docs wording


## CASE-0127
- Archive: v160_22
- Heal: HEAL-0115
- Title: cycle 97 hardened the semantic split between Hub admin manager and commerce reporting.
- Confirmation basis: direct audit of admin index labels, admin stats service, reports service, and new hardening document.
- Treatment history:
  - fixed explicit `hub_links` vs `shop_orders` separation
  - kept Hub manager and commerce reporting as different admin domains
  - added an architecture lock for the split

## Cycle 98 — legacy cleanup wave 2
- Case: финальная выборочная зачистка stale locale/runtime traces после alias waves и reporting hardening.
- Outcome: active runtime больше не зависит от shop-named locale keys; остались только подтверждённые compatibility/history traces.

## Cycle 99 — final release audit
- Case: финальный релизный аудит серии Hub выявил и устранил syntax-ошибку в `backend/app/bot/texts.py`.
- Outcome: release gates подтверждены по compileall, checked-in OpenAPI snapshot, guard-pack и clean FLAT ZIP.

## Cycle 100 — release stabilization and handoff
- Case: финальная стабилизация серии Hub 61–100 завершена handoff-документом и closure-фиксацией.
- Outcome: серия закрыта, итоговое состояние и ограничения среды зафиксированы явно.

## Cycle 101 — log-driven fixes and 101–110 plan
- Case: first post-handoff cycle switched from series closure to fresh CI-log remediation.
- Outcome: log-driven defects addressed and a new governance/parity roadmap 101–110 created.

## Cycle 102 — full CI parity wave (partial)
- Case: log-driven remediation for `logs_62451337893.zip`.
- Outcome: original log blockers fixed; cycle remains open because local full pytest exposed additional non-log drift.

## Cycle 102 continuation
- Case extension: user required alias sunset after transition end and squash of 0002 into 0001 for first install path.

## Cycle 102 — docs/route-count continuation
- Case: full parity continued with counts/freeze repair after previous log and alias waves.
- Outcome: docs/route-count cluster healed; full pytest residual reduced to 27 failures.

## 2026-03-29 — cycle 102 closure
- Подтверждено: полный `pytest -q` на HEAD зелёный: 275 passed, 25 skipped.
- Закрыт cycle 102 как full CI parity wave.
- Сняты legacy alias expectations в tests/docs после фактического sunset `/shop` и `/admin_shop` в active bot/page/help слое.
- Нормализованы `atlas.json` и `casebook.json` под текущий schema guard.
- Синхронизированы FAQ/translation expectations с текущим HEAD.

## 2026-03-29 — cycle 103
- Восстановлен обязательный governance layer для FAQ.
- Добавлены FAQ approval register и approval manifest.
- Зафиксировано, что FAQ waves 79–82 обошли approval gate быстрее, чем он был восстановлен.
- Historical draft section 13 из cycle 77 оформлен как retroactive approval entry `FAQ-APPROVAL-0001`.

## 2026-03-29 — cycle 104
- Проведён прямой FAQ runtime vs SSOT parity audit.
- Подтверждено по 13 языкам: 20 sections, 250 Q/A, section 13 = Hub.
- Прямого parity drift, требующего rewrite в этом же цикле, не найдено.
- Зафиксировано правило пользователя: в текущем цикле делать максимально возможный объём подтверждаемой работы без искусственного переноса на следующий цикл.

## 2026-03-29 — cycle 105
- Generator FAQ runtime now validates approval manifest before rebuild.
- Added hardening for manifest count, entry fields, 20/250 inventory, and section 13 = Hub.
- Runtime `catalogs.ts` rebuilt with generated header and governance source marker.

## 2026-03-29 — cycle 106
- Bot/help layer synced with current FAQ state.
- Added direct `/faq` bot command and FAQ entry keyboard.
- RU/EN help texts now mention current FAQ inventory 20/250.

## 2026-03-29 — Cycle 107
- Archive: `v160_36`
- Issue: multilingual FAQ legal wording residuals in Hub-related answers.
- Action: audit completed; no rewrite without approval; FAQ-APPROVAL-0002 created as draft.

## 2026-03-30 — Cycle 126 — latent panel docs drift after approved RU FAQ rewrite

- Symptom excerpt: после ранее утверждённого русского rewrite панели `docs/SSOT/faq_ssot/ru/faq_ru.*` уже содержали `Активация панели`, но `docs/SSOT/PANELS_SSOT.md` и `docs/SSOT/FAQ_SSOT.md` сохраняли stale user-facing wording `купить панель`, `цена панели` и `после покупки первой панели`.
- Applied fix: синхронизированы `docs/SSOT/PANELS_SSOT.md` и `docs/SSOT/FAQ_SSOT.md` с approved panel canon без runtime rebuild.
- Confirmation basis: direct audit and residual grep of `docs/SSOT/PANELS_SSOT.md`, `docs/SSOT/FAQ_SSOT.md`, `docs/SSOT/faq_ssot/ru/faq_ru.md`, and `docs/SSOT/faq_ssot/ru/faq_ru.json`.

- 2026-03-30: Cycle 127 — symptom: утверждённый code/log canon требовал `panel_activation`, но HEAD всё ещё содержал `reason="panel_purchase"` и admin aggregation только по legacy reason. Fix: backend write-path переведён на `panel_activation`, admin/report и history mapping стали dual-read для legacy + new reason.

- 2026-03-30: Cycle 128 — case note: собран draft-only multilingual package по panel-line; symptom массового runtime drift не лечился в этом cycle, а только подготовлен к следующей controlled rewrite wave.

- 2026-03-31: Cycle 129 — symptom: multilingual FAQ still contained panel commerce wording and runtime rebuild was blocked by `FAQ_APPROVAL_MANIFEST.json` count drift (`entries_total` != len(entries)). Fix: panel-line rewritten in 12 languages, manifest count corrected, runtime `catalogs.ts` rebuilt from SSOT.

- 2026-03-31: Cycle 130 — symptom: after cycle 129, small residual panel-commerce traces still lived in active SSOT/runtime (RU/UK Activ answer, EN/PL/DA/ID panel wording). Fix: active SSOT cleaned, `catalogs.ts` rebuilt, residual set reduced to legacy/non-runtime and technical layers only.

- 2026-03-31: Cycle 131 — backend audit note: `/panels/buy/{tg_id}`, `buy_panel`, `purchase_panel`, `on_user_first_panel_purchase` and related comments remain as compatibility anchors of the current release line; refactor must be separated from active user-facing cleanup.

- 2026-03-31: Cycles 132-135 — safe panel wording refactor: route summary/docstrings/frontend local naming/API docs switched to activation wording; compatibility anchors `/panels/buy`, `buy_panel`, `purchase_panel`, `on_user_first_panel_purchase`, `panels.buy_*` intentionally retained.

- 2026-03-31: Cycle 136 — parity note: active panels backend/frontend flow already matched activation canon; the only remaining active drift was the admin overview spend block without PB5-3 split visibility.
- 2026-03-31: Cycles 137-140 — symptom: admin overview exposed only one ambiguous panel spend fact although ledger data already contained main/bonus split. Fix: backend overview query extended to total/main/bonus, admin home and admin reports switched to approved PB5-3 labels and order.

- 2026-03-31: Cycle 141 — symptom: archive still contained a separate stale Russian FAQ tree in `frontend/src/data/faq/ru.ts` even though active runtime used generated `catalogs.ts`. Fix path prepared through compatibility aliasing.
- 2026-03-31: Cycle 142 — fix applied: `frontend/src/data/faq/ru.ts` now aliases generated `faqCatalogByLang.ru`; stale standalone tree removed. Additional cleanup: `frontend/src/data/faq/meta.ts` no longer exposes French section 13 as `Boutique`.
- 2026-03-31: Cycles 143-144 — audit/refactor note: internal panel naming cleanup was limited to comments/docstrings/examples in backend; route path `/panels/buy` and aliases `purchase_panel` / `on_user_first_panel_purchase` remain preserved compatibility anchors.
- 2026-03-31: Cycle 145 — release audit note: panel series 129-145 is now directly traceable in code/docs/archive state without hidden FAQ rewrites.

- 2026-03-31: Cycle 146 — symptom: archive still contained internal aliases that no longer had a necessary compatibility role. Audit isolated `etag`, `purchase_panel`, and `on_user_first_panel_purchase` as removable.
- 2026-03-31: Cycle 147 — fix: removed the three safe aliases and repaired direct callers/tests to canonical names `make_etag` and `on_user_first_panel_activation`.
- 2026-03-31: Cycle 148 — route repair: backend previously exposed only compatibility panel activation path `/panels/buy/{tg_id}`. Fix: canonical `POST /panels/activate/{tg_id}` added and frontend switched to it, while `/buy` stayed as wrapper.
- 2026-03-31: Cycle 149 — migration note: direct archive audit of `0001_init.py` and `0002_create_hub_links.py` found no new active migration gap; this is a static conclusion, not a live DB run.
- 2026-03-31: Cycle 150 — release audit note: archive, cycles register, alias docs and panel route docs are now aligned for series 146-150.


Cycle 151/152 note: direct audit of HEAD v161_10 confirmed that public `/shop/*` and admin `/admin/shop/*` no longer have active frontend/bot callers; they remain backend compatibility surfaces pending future contract-migration waves.


Cycle 153–160 note: direct audit of HEAD v161_11 confirmed canonical panels activation route drift in SSOT/OpenAPI, refreshed route inventories to 89 active routes, added new architecture locks, and closed `/shop/*` + `/admin/shop/*` removal as hard-freeze rather than unsafe contract deletion.


Cycle 161 planning note: post-160 archive audit shows the remaining work is centered on proof gaps (live migrations, fresh logs) and compatibility-contract decisions rather than hidden runtime breakage.


Cycle 161–165 note: current remaining work shifted from alias-caller cleanup to archival marking, migration proof readiness, and explicit contract decisions for backend commerce compatibility routes.


Cycle 166–170 note: current post-160 series now has explicit freeze implementation for shop/admin contracts, explicit freeze for panels compat path, deterministic route-doc regeneration helper, and a closed archive-vs-chat-vs-logs parity audit.


Cycle 171–175 note: direct audit confirmed an active wording drift rather than a historical-only drift; locale keys used by Hub/wallet/settings and one live backend docstring were synchronized and then locked by tests.

- 2026-03-31: Case 176 closed after fixing route helper syntax, docs counters, tests catalog, historical compatibility docs/files and outdated locks.

- 2026-03-31: Historical blocker case 164 closed on the basis of CI log proof from logs_62803948808.zip.

- 2026-03-31: Case 177-180 closed after 13-language audit and first translation sync wave.

- 2026-03-31: Case 181-182 closed after manual high-traffic translations for Profile and Wallet layers.

- 2026-03-31: Case 183-185 closed after manual high-traffic translations for Panels, Exchange+Energy and Tasks+Referrals layers.

- 2026-03-31: Case 186-187 closed after manual high-traffic translations for History+Withdraw and Ranks+Prizes layers.

- 2026-03-31: Case 188-189 closed after common/balances sync and full prizes/tournaments audit.

- 2026-03-31: Case closeout — `prizes/tournaments` decommission tail removed from active archive layers.

- 2026-03-31: Case note — high-traffic `hub.*` and `faq.*` shell drift removed manually across non-RU/non-EN locales.

- 2026-03-31: Case note — remaining public i18n debt no longer dominates; current long-tail shifted to admin locale namespace and first two manual admin waves are completed.

- 2026-03-31: Case note — overview layer fixed current pages inventory; migration wording затем был отдельно дожат в cycle 197 до strict `0001 only`.

- 2026-03-31: Case note — unexpected 0002 file in HEAD removed; migration canon reset to single-base 0001.

- 2026-03-31: Case note — cycle 198 used point updates in existing canon docs instead of spinning up another standalone migration memo.

- 2026-03-31: Case note — cycle 199 normalized recent registry/report tails without spawning extra canon docs.

- 2026-03-31: Case note — cycle 200 finished archive-docs closeout by clarifying historical vs active truth in existing docs.

- 2026-03-31: Cycle 201 — в реестр добавлены 15 уточняющих вопросов по полной ревизии документации архива; дальнейшая работа должна идти по полному списку документов с пофайловым согласованием действий `удалить / объединить / актуализировать`.

- 2026-03-31: Cycle 202 — построен полный master-index документации архива; audit-документы и лог-аудиты перенесены в `docs/audits/`, `reports/` оставлен вне текущего ручного обзора.

- 2026-03-31: Cycle 203 — зафиксированы решения пользователя по первой пятёрке документов; выполнено объединение legacy root `ARCHITECTURAL_LOCKS`, перенос `CHANGELOG` в `reports/`, перенос `CODE_OF_CONDUCT` в `artifacts/` и актуализация `CONTRIBUTING`.

- 2026-03-31: Cycle 204 — повторный audit чата и стартовых правил завершён; подготовлен обновлённый полный промт продолжения в новом чате с фиксацией документной фазы и точки продолжения по master-index.

- 2026-04-01: Cycle 205 — документная ревизия продолжена по решениям пользователя: `README.md` актуализирован, `REPORT_COMMANDS.txt` перемещён в `artifacts/misc/`, `SECURITY.md` расширен; дополнительно зафиксировано правило, что `artifacts/` не проверяется в пакетах ревизии как архивная корзина.

- 2026-04-01: Cycle 206 — мягко актуализированы migration/OpenAPI/requirements слои по прямому аудиту HEAD; текущий миграционный канон для первого релиза зафиксирован как `0001 only`, checked-in OpenAPI snapshot оставлен в active слое с обновлённым audit-note, а `backend/requirements.txt` дополнен недостающими зависимостями `PyJWT`, `cryptography` и `PyYAML`, которые используются в текущем архиве.

- 2026-04-01: Cycle 207 — `docker-compose.yml` мягко актуализирован по текущему Docker/archive layer; `docs/ACTIVE_WORDING_GUARDS_WAVE_2026_03_31.md` выведен в `artifacts/docs/`; `docs/GENERAL/ADMIN_PANEL_SPEC.md` объединён с более полным описанием админ-панели; `docs/NORM/ADMIN_RBAC.md` сохранён как active NORM и мягко актуализирован без ослабления ролевого канона.

- 2026-04-01: Cycle 208 — semantic boundary из `docs/ADMIN_REPORTING_HUB_HARDENING.md` интегрирована в `docs/GENERAL/ADMIN_PANEL_SPEC.md`, а сам файл выведен в `artifacts/docs/`; ADR 0001/0002/0003 и `docs/AI/AI_OPERATOR_RULES_EFHC.md` мягко актуализированы по текущему HEAD и текущему prompt-режиму документной фазы.

- 2026-04-01: Cycle 209 — `docs/API_REFERENCE.md` объединён с `docs/NORM/API_CONTRACTS.md` и выведен в `artifacts/docs/`; `docs/AI/AI_RESILIENCE_CANON.md`, `docs/NORM/API_CONTRACTS.md`, `docs/NORM/ARCHITECTURAL_LOCKS.md` и `docs/GENERAL/ARCHITECTURE_DEPENDENCIES_RU.md` актуализированы по текущему HEAD и document-phase rules.

- 2026-04-01: Cycle 210 — три wave/plan документа сведены по смыслу в `docs/cycles/WORK_CYCLES.md` и выведены в `artifacts/docs/`; `docs/GENERAL/ARCHIVE_NAV_INDEX.md` мягко актуализирован; `docs/NORM/TASKS_STANDARD.md` признан достаточно сильным для NORM-слоя и добавлен в `docs/SSOT/SSOT_INDEX.md`.

- 2026-04-01: Cycle 211 — `docs/BACKGROUND_TASKS_STANDARD.md` переименован в `docs/NORM/TASKS_STANDARD.md`; связанные active реестры и индексы синхронизированы с новым путём.

- 2026-04-01: Cycle 212 — `docs/SSOT/BANK_CANON.md` проверен против bank/economy SSOT и добавлен в NORM через `docs/SSOT/SSOT_INDEX.md`; `docs/BOT_PAGES_INVENTORY_2026_03_31.md` перенесён в `docs/audits/`; `docs/BOT_WEBAPP_ENTRYPOINT_STABILIZATION.md`, `docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml` и `docs/CODE_CLEANUP_AND_IMPROVEMENT_10_CYCLES_PLAN.md` выведены из active слоя; в `docs/AI/AI_OPERATOR_RULES_EFHC.md` добавлен обязательный формат `цикл X/Y завершён`.

- 2026-04-01: Cycle 213 — `docs/GENERAL/DOCKER_LOCAL.md` синхронизирован с текущим Docker layer; `docs/SSOT/DTO_INPUT_CANON.md` повышен до NORM через `docs/SSOT/SSOT_INDEX.md`; `docs/SSOT/EFHC_CANON.md` мягко вычищен по подтверждённой точке drift; `docs/SSOT/ENERGY_RULES.md` дополнен явной связью с exchange/available_kwh SSOT; `docs/NORM/ERROR_CODES.md` дополнен кодами `WALLET_REQUIRED` и `HUB_HANDOFF_NOT_CONNECTED`.

- 2026-04-01: Cycle 214 — `EVENTS_MATRIX.md` оставлен как active NORM и получил compat-оговорку для panel technical naming; `EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` дополнен cross-reference слоем; `FAQ_APPROVAL_GOVERNANCE.md` и `FAQ_CODE_GENERATION_HARDENING.md` мягко актуализированы по current HEAD; `FAQ_BOT_HELP_PARITY_WAVE.md` выведен в `artifacts/docs/`.
- 2026-04-01: Cycle 215 — FAQ helper/rewrite/freeze документы убраны из active docs слоя: `FAQ_COVERAGE_MATRIX.md` переведён в `artifacts/docs/`, а `FAQ_EXCHANGE_RU_REWRITE_WAVE1.md`, `FAQ_FORBIDDEN_WORDING_RU_REWRITE_WAVE1.md`, `FAQ_HUB_RU_REWRITE_WAVE1.md` и `FAQ_INVENTORY_FREEZE.csv` переведены в `docs/audits/`.
- 2026-04-01: Cycle 216 — `FAQ_INVENTORY_FREEZE.md` переведён в `docs/audits/`; `FAQ_MULTILINGUAL_LEGAL_WORDING_DRAFT.md`, `FAQ_PANELS_BOT_UI_RU_REWRITE_WAVE1.md`, `FAQ_PANELS_RATES_RU_DRAFT.md` и `FAQ_PANELS_RU_REWRITE_WAVE1.md` выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 217 — `FAQ_REPLACEMENT_LEDGER.md` актуализирован и переведён в `docs/audits/`; `FAQ_SSOT.md` мягко актуализирован; `FAQ_TOPBAR_RU_REWRITE_WAVE1.md`, `FAQ_VIP_RU_REWRITE_WAVE1.md` и `FAQ_WALLET_RU_REWRITE_WAVE1.md` выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 218 — `FRONTEND_ACTIVE_LOCALE_SYNC_2026_03_31.md`, `HUB_ADMIN_ENTITY_DESIGN.md` и `HUB_ADMIN_MIGRATION_MODEL_WAVE.md` переведены в `docs/audits/`; important pressure-test context перенесён в `docs/cycles/WORK_CYCLES.md`; `HUB_ALIAS_PRESSURE_TEST.md` и `HUB_ALIAS_REMOVAL_WAVE2.md` выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 219 — смысл `HUB_CYCLES_91_100_PLAN.md` сведен в `docs/cycles/WORK_CYCLES.md`; `HUB_EFHC_HANDOFF_IMPLEMENTATION_WAVE1.md`, `HUB_FAQ_SECTION_13_RU_DRAFT.md` и `HUB_FINAL_ALIAS_REMOVAL_DESIGN.md` переведены в `docs/audits/`; `HUB_FINAL_ALIAS_REMOVAL_WAVE1.md` выведен в `artifacts/docs/`.
- 2026-04-01: Cycle 220 — смысл `HUB_FINAL_COMMERCE_CLEANUP_RELEASE_STABILIZATION.md` сведен в `docs/cycles/WORK_CYCLES.md`; `HUB_GUARDS_REGRESSION_PACK.md`, `HUB_SERIES_61_100_FINAL_HANDOFF.md` и `I18N_ADMIN_VERIFICATION_2026_03_31.md` переведены в `docs/audits/`; `HUB_SSOT.md` мягко актуализирован.
- 2026-04-01: Cycle 221 — historical i18n wave-docs (`I18N_ADMIN_WAVE1_2026_03_31.md`, `I18N_ADMIN_WAVE2_2026_03_31.md`, `I18N_COMMON_BALANCES_WAVE1_2026_03_31.md`, `I18N_EXCHANGE_ENERGY_WAVE1_2026_03_31.md`, `I18N_HISTORY_WITHDRAW_WAVE1_2026_03_31.md`) выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 222 — historical i18n Hub/matrix/plan/wave документы (`I18N_HUB_FAQ_WAVE2_2026_03_31.md`, `I18N_MISSING_KEY_MATRIX_2026_03_31.md`, `I18N_MISSING_TRANSLATIONS_PLAN_191_195.md`, `I18N_PANELS_WAVE1_2026_03_31.md`, `I18N_PROFILE_WAVE1_2026_03_31.md`) выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 223 — `I18N_SYNC_PLAN_181_190.md`, `I18N_TASKS_REFERRALS_WAVE1_2026_03_31.md`, `I18N_WALLET_WAVE1_2026_03_31.md`, `LEGACY_CLEANUP_WAVE2.md`, `LEGACY_FRONTEND_FAQ_SOURCES_CLEANUP_2026_03_31.md` выведены из active docs слоя в `artifacts/docs/`; исторически важные выводы двух legacy cleanup документов сохранены в `docs/cycles/WORK_CYCLES.md`.
- 2026-04-01: Cycle 224 — historical смысл `LIVE_ALEMBIC_PROOF_BLOCKER_2026_03_31.md` и `LOTTERIES_DECOMMISSION_CYCLES.md` сохранён в `docs/cycles/WORK_CYCLES.md`; master-index очищен от слоя `artifacts/`; `MIGRATION_INVARIANTS_HARDENING.md` актуализирован и переведён в NORM.
- 2026-04-01: Cycle 225 — historical смысл `MIGRATION_RESET_TO_0001_2026_03_31.md`, `OBSERVABILITY_METRICS_PLAN.md` и `OPENAPI_RELEASE_DOCS_FREEZE_2026_03_31.md` сохранён в `docs/cycles/WORK_CYCLES.md`/active docs; `MODEL_TABLE_ROUTE_TEST_MAP.md` актуализирован и переведён в NORM; `MODULES_DEPENDENCIES.md` мягко актуализирован по current HEAD.
- 2026-04-01: Cycle 226 — важный смысл `OVERVIEW_DOCS_REFRESH_2026_03_31.md`, `PANELS_ADMIN_COUNTERS_DESIGN_2026_03_31.md`, `PANELS_API_WORDING_SYNC_2026_03_31.md` сохранён в `docs/cycles/WORK_CYCLES.md`; summary-данные `OVERVIEW_SSOT_SYNC.md` и panels approval package absorbed by active NORM/SSOT docs; standalone files выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 227 — важный panels compatibility смысл absorbed by `docs/SSOT/PANELS_SSOT.md` and `docs/cycles/WORK_CYCLES.md`; standalone panels draft/sync/freeze docs выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 228 — panels/project/release pack cleaned; historical notes absorbed by `docs/cycles/WORK_CYCLES.md`, `README.md`, `docs/GENERAL/architecture.md`; `QUESTIONS_AND_ANSWERS_REGISTER.md` and `RANKS_RULES.md` promoted to NORM.
- 2026-04-01: Cycle 229 — referral canon and routes/migrations playbook promoted to NORM; release hygiene and old repair plan absorbed into `docs/cycles/WORK_CYCLES.md`; `ROUTE_INVENTORY_FREEZE.md` left pending separate decision as a freeze snapshot rather than current live inventory.

## Cycle 331 case note
- Case: свежий CI-log показал mixed wave: flake8, ruff, bandit, npm build, pytest.
- Treatment: manual targeted edits without mass refactor.
- Result: subset verification improved; waiting for fresh CI proof for full closure.

## Cycle 332 case note
- Fresh CI after cycle 331 exposed second-order drift: duplicate/import-order issues in tests after manual header edits.
- Treatment remained manual and partial; further wave required.

## Cycle 333 case note
- Second-order ruff drift after cycle 332 was closed on targeted subset.
- Fresh CI log required for the next factual blocker set.

## Cycle 334 case note
- Gate summary isolated pytest as the only failing step.
- Root cause narrowed to async-marking drift in panel tests after previous cleanup wave.
- Manual treatment applied; new CI proof required.

## Cycle 335 case note
- Fresh CI proof finally closed the log-fix wave 331-334.
- This is a factual green state, not an assumed one.

- 2026-04-05: повторно зафиксирована Healer-болезнь AI-layer — попытка
  вынести active cycle queue / plan в новый отдельный документ вместо
  ведения единственного канонического журнала
  `docs/cycles/WORK_CYCLES.md`.
  Новый жёсткий запрет закреплён в `docs/AI/AI_OPERATOR_RULES_EFHC.md`
  и `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`:
  нельзя создавать cycle-plan / cycle-status / cycle-register /
  wave-plan документы для active cycles.
