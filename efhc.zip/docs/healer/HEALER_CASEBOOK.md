<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CASE-0138 — PostgreSQL reconciliation gate цикла 1599

Связанная карточка: `HEAL-0125`.

Среда не предоставила PostgreSQL URL, сервер или драйвер. Read-only
шлюз вернул `БЛОКИРОВАНО_СРЕДОЙ` и не выполнил ни одного запроса к
базе.

Historical backfill, read switch и утверждение нулевого финансового
расхождения запрещены до реального доказательства.

# CASE-0135 — v171.92 immutable UserId value boundary

Linked card: `HEAL-0122`.

The approved system/provider separation was implemented as immutable
value objects in the isolated identity package. Explicit conversion
helpers reject raw/provider/wallet substitutions. A 481-file semantic
manifest proves that ORM, migrations, routes, services, schemas and
frontend ownership did not change.

Treatment status: locally confirmed; fresh exact-HEAD CI and real
PostgreSQL/frontend/live proof remain open.

---

## Current case update — v171.65

- Direct user decision: checks impossible before release must not indefinitely block development.
- Cycle 1573 local scope: complete.
- External proof: `DEFERRED_POST_RELEASE_BY_USER`, still unverified.
- Cycle 1574: allowed and active for local RC audit.
- Guard remains fail-closed against false live/release claims.

---

# CASE-0124 — v171.61 route-backed frontend source recovery

Linked card: `HEAL-0115`.

Confirmed source regression was repaired against the trusted v171.47/v171.50/v171.52 direction. Settings is now a compact gear inside Profile only; the bottom game navigation remains exactly six items. The new browser harness requires a running application and `page.goto()`.

Treatment status: partial — source/guards repaired, production build/typecheck and fresh application PNG still require an environment with installable frontend dependencies.

---

# CASE-0123 — v171.60 governance entrypoint recovery

Linked card: `HEAL-0114`.

Confirmed: startup-order duplication, Kernel history accumulation, persistent-sandbox assumption, CI prohibition drift and manual-HTML application-proof substitution.

Treatment (historical, partially superseded): single START_HERE and provenance guards remain valid. The phrase `navigation-only Kernel` was invalidated by the user-directed v171.62 full Operator Kernel restoration and must not be reused as active treatment. Runtime visual revalidation remains open.

---

## HEAL-0113 / CASE-0122 — SUPERSEDED / INVALID APPLICATION-PROOF CLAIM

- Date: 2026-07-23.
- Source changes retained: ProfileModal mounting and balance numeral normalization.
- Invalidated claim: 13 PNG were not route-backed application proof; the generator used manual HTML / `page.set_content`.
- Superseded by: `HEAL-0114 / CASE-0123`.
- Status: historical trace only; do not cite as frontend proof.
---

## HEAL-0112 / CASE-0121 — v171.57 live contour evidence gate follow-up

- Date: 2026-07-23.
- Archive treatment: `v171.57`.
- Cycle: `1573`, still active and not complete.
- Confirmation: no live Telegram, real TonConnect, real TonProof or real transaction evidence was present in the workspace.
- Treatment: add `ops/release/live_contour_gate.py` and `tests/architecture/test_live_contour_gate.py` to keep the cycle fail-closed until factual external proof exists.
- Generated evidence: `docs/history/legacy_artifacts/reports/generated/cycle_1573_live_contour_gate_v171_57.json`.
- Status: `BLOCKED_MISSING_LIVE_EVIDENCE`; no cycle 1574 advancement.
---

## HEAL-0112 / CASE-0121 — critical delivery protocol breach

- Date: 2026-07-22.
- Archive treatment: `v171.55`.
- Severity: `P0`; treatment status: confirmed; maturity: fully protocolized.
- Confirmation: direct user escalation plus repository audit of stale HEAD,
  invalid screenshot provenance and premature cycle advancement.
- Treatment: add a mandatory fail-closed state machine and executable archive
  delivery gate.
- Guard: `tests/healer/test_critical_delivery_protocol.py`.
- Final permission: only a PASS receipt may grant `USER_DELIVERY_ALLOWED`.
- Forbidden: narrative bypass, synthetic app screenshots, cycle advancement
  without live proof and non-clickable artifact delivery.

## HEAL-1524 — withdrawals runtime test isolation repair

- Cycle: current fresh CI repair.
- Severity: CI red / test isolation defect.
- Status: locally treated; fresh CI rerun required for output archive.
- Symptom: `logs_74379950976.zip` showed two pytest failures in
  `test_admin_withdrawals_list_runtime.py` caused by duplicate empty
  `users.ton_wallet` values under `uq_users_ton_wallet`.
- Treatment: DB-backed withdrawals runtime test helpers now insert `NULL`
  for absent legacy wallet values.
- Guard: `tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py`.
- Forbidden action: do not restore empty-string wallet fixtures for users who
  have no legacy `users.ton_wallet` value.

## 2026-06-16 — v170.99 P0 admin withdrawals list regression fix

- Finding: `P0-ADMIN-WITHDRAWALS-LIST-ALWAYS-EMPTY`.
- Symptom: `GET /admin/withdrawals` could return an empty queue because
  `list_withdrawals()` depended on absent legacy `bonus_awards`.
- Treatment: remove the legacy guard from live `withdraw_requests` list
  flow; keep the guard only in legacy bonus-award methods.
- Tests: service runtime, route runtime, AST guard scope and previous repair
  regression guard added.
- Release remains fail-closed until fresh CI, live Telegram and real
  TonConnect proof are supplied.

## 2026-06-05 — v170.22 CI rerun CI rerun log repair

- Source logs: `logs_72627437860.zip`.
- Failing gates were read first: ruff and pytest.
- Treatment: repair ruff import ordering in admin bank / transactions
  service files and add the required historical status note to
  `ROUTE_INVENTORY_FREEZE.md`.
- Guard impact: `tests/architecture/test_ci_log_repair_guards.py` added.
- No runtime economy, migration, CI/workflow or lock-file change.
- Release-ready remains forbidden until fresh CI and release audit proof.

## 2026-06-05 — v170.20 step 1444 linkage repeat audit + HEALER tail reconciliation

- Local repeat audit for active linkage findings `F-001…F-008` produced `status=ok` and `blockers=[]`.
- New report: `docs/history/legacy_artifacts/reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`.
- New guard: `tests/architecture/test_linkage_repeat_audit_healer_tail.py`.
- HEALER loader tail repaired: `ops/healer/loader.py` now normalizes historical compact atlas/casebook entries into the strict dataclass boundary.
- `ops/healer/run_once.py` now accepts both explicit `atlas_version`/`casebook_version` and compact `version` keys.
- `F-006` remains live FastAPI proof pending; release-ready is still forbidden without external proof gates.

## 2026-06-05 — v170.19 step 1443 full linkage guard tail

- `F-007` is locally guarded: critical API-driven UI surfaces now have static loading/error/empty state checks.
- `F-008` is locally guarded: frontend API calls are checked against backend routes and OpenAPI through the full linkage scanner.
- New scanner: `ops/linkage/build_full_linkage_report.py`.
- New report: `docs/history/legacy_artifacts/reports/generated/full_linkage_report_v170_19.json`.
- Remaining HEALER tail is not hidden: repeat linkage audit, fresh CI/log proof and release audit are still required before release-ready language.

## 2026-06-05 — v170.17 step admin-wallet-reset audit/HEALER tail routing

- `F-005` admin wallet reset semantic mismatch is locally repaired: reset now clears legacy `users.ton_wallet` and deactivates canonical `wallet_bindings`.
- Remaining linkage tails are not hidden:
  - `F-006` OpenAPI incomplete/stale routes → OpenAPI gate.
  - `F-007` critical UI loading/error/empty-state guard tail → full linkage guard pass.
  - `F-008` frontend API call → backend route guard tail → full linkage guard pass.
- HEALER/fresh-proof tails remain visible: repeat linkage audit, fresh CI/log proof and release audit are still required before release-ready language.
- Next bounded tail repair slots: OpenAPI gate OpenAPI gate, full linkage tests, repeat audit + HEALER reconciliation, CI/log proof if logs are supplied.

## 2026-06-04 — v169.96 CI log-repair casebook update

- Source: supplied CI logs after the FSM split.
- Treatment: replace raw FSM background task spawning with `create_logged_task()`, clean non-exception numbered wording, and refresh stale HEAL-0055 metadata.
- Guard impact: existing architecture guards remain active; no guard was weakened.

## 2026-06-04 — v169.93 HEAL-0055 retention / P0 cross-guard casebook update

- repair pass codified long-retention DB idempotency for deposits and fingerprint mismatch detection.
- repair pass added `test_p0_cross_guard_consolidation.py` as an additive regression layer across repaired P0 backend invariants.

## 2026-06-04 — v169.89 HEAL-0023 / HEAL-0018 casebook update

- `HEAL-0023`: source/guard repair in repair pass. Explicit `IDEMPOTENCY_CONFLICT:<key>` now routes through the shared idempotency conflict detector.
- `HEAL-0018`: repair pass created a transaction-boundary map before runtime repair. Runtime rewrite remains repair pass.

## 2026-06-03 i18n reaudit residuals must become manual language cycles

- v169.54 reaudit closed C1-C4 but left a large public translation tail: UK 62 keys and wave-3 languages about 152-154 public keys per language.
- This must not be solved by bulk-copying English or automated mass fill. Remaining translation work is a manual Healer lane: verified Russian meaning -> target language -> placeholder/parity guard.
- Formula strings such as `1 kWh = 1 EFHC` must be allowlisted as formulas, not translated prose.
- User-facing `game task` wording is not prohibited. It can be rewritten only as a tone/readability choice; ordinary game wording is allowed, while gambling, loto, betting and random financial meaning remain forbidden.
- Audit scripts that fail because a report scaffold is missing should have stable evidence reports before being used as gates.

## 2026-04-08 dead-but-needed modules require revival, not deletion

- Если модуль или компонент выглядит мёртвым по смысловому аудиту, но
  пользователь подтвердил, что он нужен, следующий шаг — не удаление, а
  план по подключению, ремонту и повторной интеграции.
- Дубли по таким зонам сначала сравниваются, данные переносятся,
  пользователю показывается предложение на согласование, и только потом
  допускается удаление одного из дублей.

## 2026-04-08 archival baskets must be skipped by canon guards

- После переноса старых документов в `artifacts/` guard-тесты не должны
  читать эту архивную корзину как активный кодовый или документный слой.
- Иначе пользовательское согласованное архивирование начинает ломать CI
  бан-словами и legacy терминами из исторических файлов.

## 2026-04-08 high-impact historical audit stubs must stay visible

- Даже после зачистки старых audit-файлов несколько high-impact
  historical docs должны оставаться в `docs/history/legacy_artifacts/docs/audits/`, если на них
  завязаны guard-тесты и continuity status-notes.
- Нельзя убирать такие документы из active docs surface, пока test-layer
  и control-layer ещё требуют их присутствия.

## 2026-04-08 transferred audit backbone

- Economy Healer backbone: bank split-brain, mirror direction drift,
  idempotency conflict drift, exchange autobegin drift, energy
  `_begin_tx` recursion, self-healing queue breakage, shop
  schema/reporting mismatch.
- Release Healer backbone: transient junk in ZIP, nested release ZIP
  relapse, build-script drift, confusion between transient junk and
  `artifacts/`.
- Frontend/UX Healer backbone: visual white spots, inconsistent
  loading/error/empty states, wording drift after canon updates, browser
  shop / hub residual mismatches.
- Process Healer backbone: false cycle closure, GitHub CI ownership
  drift, stale cycle-control panel, dependency-precheck drift, keeping
  unique errors only in old audits/reports.

## 2026-04-08 transferred reports backbone

- Старые reports перенесены из active surface; уникальная память по
  исправлениям должна сохраняться в Healer, cycle docs и свежих
  `change_cycle_*`.
- Legacy report naming (`change_report_*`, internal logs, alias
  sanitation reports и т.п.) больше не должен быть главным носителем
  решений.

## 2026-04-08 audit debt must move to Healer

- Старые audit-файлы не должны оставаться единственным носителем ошибок
  проекта.
- Перед будущей зачисткой `docs/history/legacy_artifacts/docs/audits/` нужно перенести economy,
  release, self-healing, frontend, cycle-control и process defects в
  Healer как долговременный memory-layer.
- `_raw` допустим как evidence-архив, но не как место, где живут
  уникальные ошибки без переноса в Healer.

## 2026-04-08 reports retention debt

- Раздел `docs/history/legacy_artifacts/reports/` разросся до большого исторического слоя;
  каноническая память должна остаться в `change_cycle_*`, а
  переходные/дублирующие форматы нужно разметить на `оставить /
  artifacts / удалить после согласования`.
- Старые internal logs и legacy report naming не должны сохранять
  уникальные ошибки мимо Healer.

## 2026-04-08 GitHub CI ownership reminder drift

- GitHub CI прогоны делает пользователь; ИИ не должен путать их со
  своими локальными вспомогательными проверками и не должен выдавать их
  за свои проходы.
- Это правило нужно удерживать одновременно в AI docs, циклах и
  чат-отчётах.

## 2026-04-08 nested release zip relapse

- build script staging captured existing `efhc.zip`, so the next archive
  packed the previous archive inside itself and almost doubled the
  release weight.
- Guard rule: before staging, delete `ZIP_OUT` in repo root and exclude
  it explicitly from rsync packaging.

## 2026-04-08 recursive _begin_tx residual transfer

- После фикса `energy_service` тот же рекурсивный `_begin_tx` оставался
  живым в `referral_service`, `wallet_binding_service` и
  `tasks_service`.
- Паттерн должен считаться Healer-хроникой: при отсутствии транзакции
  `_begin_tx` обязан вызывать `db.begin()`, а не сам себя.

## 2026-04-07 watcher/reporting residual transfer

- legacy helper paths через `shop_orders.item_id` и `shop_items` в
  watcher/reporting слое — хронический residual drift после смены канона
  shop_orders.
- сырой слой `docs/history/legacy_artifacts/docs/audits/_raw` должен переноситься в Healer/artifacts
  после картирования на активные аудиты.

## 2026-04-07 old GitHub CI log transfer

- Старые GitHub CI log-audits про `0002`, import-order и stale frontend
  typing/build дрейф должны считаться Healer-хроникой, а не active
  truth.
- Повторяющиеся `ruff I001`, stale typing/builder drifts и
  migration-memory conflicts — переносим в Healer даже если они уже
  встречались в старых логах и аудитах.

- Подмена реального GitHub CI локальными прогонами как будто это одно и
  то же — хроническая болезнь.
## 2026-04-07 correction wave consolidation

- Ложное закрытие циклов без реального выполнения — хроническая болезнь.
- Закрытие visual/frontend цикла без песочницы пользователя —
  хроническая болезнь.
- Stale временные тестовые артефакты, ломающие следующие прогоны, —
  хроническая болезнь.
- Отсутствие dependency-precheck (`pytest`, `ruff`, `compileall`,
  `mypy`, `bandit`, `sqlalchemy`, `aiosqlite`) перед циклами —
  хроническая болезнь.
- Старые GitHub CI log-аудиты должны передавать хронические ошибки в
  Healer, а не бесконечно оставаться в active audit-surface.
- Каждый новый подтверждённый CI/log defect должен в том же цикле сразу
  быть привязан к существующей Healer-карте или зафиксирован новой
  записью без отложенного переноса.
- Рецидив AI-layer: попытка подменять пользовательский GitHub CI
  локальным почти-CI прогоном запрещена и должна считаться процессной
  болезнью.
- Рецидив AI-layer: отсутствие вопросов при реальной неясности запрещено
  и должно считаться процессной болезнью.
- CI-файлы правятся только в чате по прямому поручению пользователя;
  самовольное изменение CI внутри архива запрещено.

# Cycles 250-251 note — 2026-04-02

- Cycles 250-251 cleaned the main AI operator document and marked the
  prompt layer as reviewed historical material.
- The main AI layer now carries the primary continuity model more
  cleanly.

# Cycle 249 note — 2026-04-02

- Cycle 249 closed the current root helper-level merge phase as
  sufficiently cleaned.
- The AI layer now more strictly forbids English names for next cycles
  and roadmap points in chat.
- The repeated chat-language slip was treated as an AI continuity issue
  and fixed in the main AI docs.

# Cycle 248 note — 2026-04-02

- Cycle 248 normalized the key AI continuity docs into a more coherent
  Russian-facing layer.
- The current continuation prompt now reflects the line after cycle 247.
- Mixed-language wording remains acceptable only in secondary AI
  materials where precision benefits from it.

# Cycle 247 note — 2026-04-02

- Cycle 247 applied a controlled helper-level consolidation to the
  wallet/TON root cluster.
- The dynamic wallet-connect test pack now shares a testkit, while
  static SSOT and route guards remain explicit.
- The root merge phase is now close to saturation and may only need a
  final cleanup review.

# Cycle 246 note — 2026-04-02

- Cycle 246 applied a controlled helper-level consolidation to the root
  panels tests.
- Explicit scenario guards were preserved; only duplicate reload and
  seed boilerplate were consolidated.
- The panels cluster is no longer the strongest remaining root merge
  candidate.

# Cycle 245 note — 2026-04-02

- Cycle 245 applied a controlled helper-level consolidation to the
  concurrency root tests.
- The local verification also revealed two collection-shape hazards,
  which were corrected pointwise.
- The main AI doc now explicitly requires asking the user first when
  something is unclear.

# Cycle 244 note — 2026-04-02

- Cycle 244 fixed the final priority ladder in the main AI doc.
- Drift must now be reported, agreed through Q&A and only then
  synchronized.
- AI menu now has a START HERE marker for quick entry into the AI layer.

# Cycle 243 note — 2026-04-02

- Cycle 243 added a fast startup/communication protocol for new chats.
- Prompt files are now explicitly treated as secondary archival traces
  rather than the main continuity carrier.
- SSOT and NORM are explicitly treated as very important
  instruction-memory layers.

# Cycle 242 note — 2026-04-02

- Cycle 242 structurized the AI layer into index + brain/memory model +
  current continuation prompt.
- The archive is now explicitly modeled as a complement to the chat and
  as part of long-term continuity memory.
- `WORK_CYCLES.md` is explicitly treated as both memory and roadmap.

# Cycle 241 note — 2026-04-02

- Cycle 241 aligned the AI layer with the user's framing: AI docs are
  the working brains/prompt-layer, while logs, Q/A, Healer, registries
  and reports are the memory layer.
- The planned queue was renumbered so the former 241–242 entries now
  continue as 242–243.
- Chat-facing cycle naming remains Russian-only.

# Cycle 240 note — 2026-04-02

- Cycle 240 performed an AI continuity sweep after the previous chat
  audit and controlled test merge wave.
- The AI layer now explicitly records that user-facing cycle
  descriptions must be sent in Russian.
- Internal AI documents may remain in English or mixed language when
  this preserves precision and continuity.

# Cycle 239 note — 2026-04-02

- Cycle 239 applied a controlled helper-level merge wave for the
  payment-intents root tests.
- The refactor initially exposed a collection-time import risk and was
  corrected pointwise by moving `sqlalchemy` import inside the helper
  function.
- Explicit scenario tests were preserved; only duplicate setup helpers
  were consolidated.

# Cycle 238 note — 2026-04-02

- Chat audit confirmed AI-doc drift against the current post-233
  continuation state.
- AI active docs were synchronized in cycle 238.
- Tests catalog was rebuilt into active / merge-review / retired
  sections.

Cycle 237 note: no new failure required repair; with CI green, the cycle
was spent on classifying the root integration/concurrency/payment tests
for the next cleanup wave.

Cycle 236 note: pytest finally exposed a large stale-test tail from the
pre-reorg documentation structure; the cleanup was done manually and
pointwise, with active guards preserved and current paths re-synced.

Cycle 235 note: post-install CI reached alembic and exposed stale SSOT
path usage in `0001_init.py`; migration sanity path was repaired and
style-blocking duplicate imports were removed from two route modules.

Cycle 234 note: latest CI logs failed before pytest because
`backend/requirements.txt` had a narrative bullet line outside comment
syntax; requirements parse was repaired and test-inventory cleanup
planning started.

Cycle 73 note: Hub admin entity design frozen around `hub_links` and
explicit exclusions of price/order semantics.

# HEALER_CASEBOOK

Version: 1.2.0

Cases total: 53

Cycle 26 note: `logs_62063388182.zip` closed by restoring Healer JSON
structure and syncing active FAQ/runtime after residual lotteries-tail
audit.

## CASE-0001 — Line72 violation

- heal_id: `HEAL-0001`
- archive_version: `v151_34+`
- action_priority: `observe`

Симптом: L=84 > 72

**Applied fix**

- Перенести длинную строку на несколько строк.
- Для описаний Field использовать description=(...) с
- конкатенацией.

**Verification**

- pytest line72
- ruff/compileall не деградировали

## CASE-0002 — apiRequest generics missing

- heal_id: `HEAL-0002`
- archive_version: `AA-local`
- action_priority: `observe`

Симптом: Property 'items' does not exist on type '{}'

**Applied fix**

- Добавить тип ответа и вызывать apiRequest<Resp>(...).

**Verification**

- npm run build
- tsc/next build green

## CASE-0003 — Props contract drift

- heal_id: `HEAL-0003`
- archive_version: `AA-local`
- action_priority: `observe`

Симптом: Property 'hint' does not exist on type ...

**Applied fix**

- Сверить интерфейс props и все вызовы компонента.

**Verification**

- next build
- поиск похожих вызовов

## CASE-0004 — CI missing pytest

- heal_id: `HEAL-0004`
- archive_version: `legacy-ci`
- action_priority: `observe`

Симптом: pytest: command not found

**Applied fix**

- Добавить pip install pytest и нужные плагины в
- workflow.

**Verification**

- CI step pytest exists
- pytest -q runs from workflow

## CASE-0005 — Pytest wrong cwd

- heal_id: `HEAL-0005`
- archive_version: `legacy-ci`
- action_priority: `observe`

Симптом: exit code 5

**Applied fix**

- Запускать pytest из корня, где лежит tests/.

**Verification**

- CI shows collected tests > 0

## CASE-0006 — CI dependency gap

- heal_id: `HEAL-0006`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: ModuleNotFoundError: jwt

**Applied fix**

- Синхронизировать CI install step с requirements и test
- deps.

**Verification**

- missing import errors gone
- pytest collection green

## CASE-0007 — Broken npm lockfile source

- heal_id: `HEAL-0007`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: npm ci failed

**Applied fix**

- Пересобрать lockfile на публичном registry npmjs.

**Verification**

- npm ci
- lockfile has no vendor/file refs

## CASE-0008 — Vendor patch bypass

- heal_id: `HEAL-0008`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: file: dependency

**Applied fix**

- Вернуть нормальные semver зависимости и честный
- lockfile.

**Verification**

- npm ci
- guard bans passes

## CASE-0009 — Missing symbol import/export

- heal_id: `HEAL-0009`
- archive_version: `legacy-ci`
- action_priority: `planned`

Симптом: ImportError

**Applied fix**

- Сверить реальный экспорт и импорт; фасад держать
- честным.

**Verification**

- pytest collection
- compileall

## CASE-0010 — Pagination contract missing

- heal_id: `HEAL-0010`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: Pagination expected

**Applied fix**

- Добавить/импортировать Pagination там, где она нужна.

**Verification**

- pytest collection
- admin logs flow tests

## CASE-0011 — Alembic backend import path

- heal_id: `HEAL-0011`
- archive_version: `legacy-ci`
- action_priority: `planned`

Симптом: ModuleNotFoundError: backend

**Applied fix**

- Перевести импорты на app.* или migrations.* под
- текущий cwd.
- Не смешивать backend.app.* и app.* в одном контуре.

**Verification**

- alembic upgrade head
- compileall migrations

## CASE-0012 — Migration env NameError

- heal_id: `HEAL-0012`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: NameError

**Applied fix**

- Определить path helper до first use и перепроверить
- sys.path.

**Verification**

- compileall
- alembic import env

## CASE-0013 — Settings field missing

- heal_id: `HEAL-0013`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: parsed_ref_bonus_thresholds missing

**Applied fix**

- Добавить поле в Settings и sane default по канону.

**Verification**

- compileall
- settings import
- pytest affected flow

## CASE-0014 — SQLite row lock unsupported

- heal_id: `HEAL-0014`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: FOR UPDATE

**Applied fix**

- Не адаптировать доменную логику под SQLite.
- Тесты перевести на Postgres-only профиль.

**Verification**

- pytest on Postgres profile
- no sqlite lock errors

## CASE-0015 — SQLite SQL function drift

- heal_id: `HEAL-0015`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: now() missing

**Applied fix**

- Убрать SQLite profile из таких тестов или переписать
- tests.

**Verification**

- pytest
- no sqlite sql syntax errors

## CASE-0016 — TON validator false ban

- heal_id: `HEAL-0016`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: invalid TON address

**Applied fix**

- Перейти на нормальную валидацию формата TON и тесты
- примеров.

**Verification**

- wallet validation tests
- real known address passes

## CASE-0017 — str vs datetime

- heal_id: `HEAL-0017`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: '>' not supported between str and datetime

**Applied fix**

- Нормализовать тип времени до сравнения и на границе
- ввода.

**Verification**

- panel tests
- mypy if typed

## CASE-0018 — Session already begun

- heal_id: `HEAL-0018`
- archive_version: `legacy-runtime`
- action_priority: `immediate`

Симптом: InvalidRequestError: transaction already begun

**Applied fix**

- Убрать вложенный begin().
- Держать одну транзакционную границу в сервисе.

**Verification**

- pytest affected flow
- no nested tx error

## CASE-0019 — Migration smoke NoneType

- heal_id: `HEAL-0019`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: NoneType in migration smoke

**Applied fix**

- Сверить helper contract и защитить от None перед
- обращением.

**Verification**

- migration smoke test
- alembic upgrade head

## CASE-0020 — SQLite schema DDL in tests

- heal_id: `HEAL-0020`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: near SCHEMA syntax error

**Applied fix**

- Запускать такие тесты только на Postgres-only профиле.

**Verification**

- pytest on Postgres profile

## CASE-0021 — Guard binary false positive

- heal_id: `HEAL-0021`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: guard bans hit png

**Applied fix**

- Исключить binary assets или детектировать mime/binary
- mode.

**Verification**

- guard scan passes on png/jpg

## CASE-0022 — Guard alias ban hit

- heal_id: `HEAL-0022`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: bans scan found tg alias

**Applied fix**

- Санировать алиасы до канона tg_id without new bypass
- names.

**Verification**

- guard bans passes
- grep on aliases clean

## CASE-0023 — Idempotency unique race

- heal_id: `HEAL-0023`
- archive_version: `legacy-runtime`
- action_priority: `immediate`

Симптом: duplicate key

**Applied fix**

- Сделать read-through поиск по ключу до insert.
- Повтор отдавать как idempotent result.

**Verification**

- idempotency tests
- concurrency retry tests

## CASE-0024 — Exchange/withdraw race

- heal_id: `HEAL-0024`
- archive_version: `legacy-runtime`
- action_priority: `immediate`

Симптом: race in exchange

**Applied fix**

- Держать атомарные state transitions.
- Использовать row locks и idempotent service path.

**Verification**

- concurrency tests
- ledger invariants hold

## CASE-0025 — Warnings promoted to fail

- heal_id: `HEAL-0025`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: unraisable exception warnings

**Applied fix**

- Исправить источник warning, а не глушить его globally.

**Verification**

- pytest clean warnings

## CASE-0026 — SSL mode mismatch local Postgres

- heal_id: `HEAL-0026`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: sslmode require local postgres fail

**Applied fix**

- Добавлять sslmode только для non-local hosts.

**Verification**

- alembic upgrade head local/ci

## CASE-0027 — Leftover sqlite helper

- heal_id: `HEAL-0027`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: IndentationError __init__sqlite_schema

**Applied fix**

- Удалить/заменить sqlite helper на Postgres fixture
- path.

**Verification**

- compileall tests
- pytest collection

## CASE-0028 — Broken migration env formatting

- heal_id: `HEAL-0028`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: compileall env.py failed

**Applied fix**

- Нормализовать блок search_path injection.
- Проверить quoting и indentation.

**Verification**

- compileall
- bandit B608 context

## CASE-0029 — models __init__ contaminated

- heal_id: `HEAL-0029`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: models __init__ damaged

**Applied fix**

- Переписать init.py как чистую фасадную re-export
- точку.

**Verification**

- pytest collection
- compileall

## CASE-0030 — Missing required tables

- heal_id: `HEAL-0030`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: required tables missing after alembic

**Applied fix**

- Сверить ORM tables, 0001, search_path и sanity list.
- Явно указывать схему там, где нужно.

**Verification**

- alembic upgrade head
- sanity db objects
- tables count

## CASE-0031 — Duplicate ORM table define

- heal_id: `HEAL-0031`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: Table already defined

**Applied fix**

- Унифицировать import path на app.* внутри backend cwd.
- Избегать двойной загрузки app.models и
- backend.app.models.

**Verification**

- alembic import
- pytest collection

## CASE-0032 — Archive filename too long

- heal_id: `HEAL-0032`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: unzip file name too long

**Applied fix**

- Укорачивать имена артефактов и путей внутри релиза.

**Verification**

- unzip efhc.zip in CI

## CASE-0033 — Double schema prefix

- heal_id: `HEAL-0033`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: efhc_core.efhc_core.table

**Applied fix**

- Нормализовать имя таблицы перед to_regclass/sanity
- check.

**Verification**

- alembic sanity green

## CASE-0034 — Incomplete metadata from soft imports

- heal_id: `HEAL-0034`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: tables_count_expected got lower count

**Applied fix**

- Импортировать все model modules жёстко и единообразно.

**Verification**

- metadata tables count
- alembic sanity

## CASE-0035 — Config settings export drift

- heal_id: `HEAL-0035`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: config_core did not export settings

**Applied fix**

- Вернуть каноничный export settings из config_core.

**Verification**

- imports from app.core.config_core work

## CASE-0036 — Index schema kwarg invalid

- heal_id: `HEAL-0036`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: Index() got unexpected kwarg 'schema'

**Applied fix**

- Убрать schema= из Index(...).
- Схему задавать только на таблице.

**Verification**

- alembic import
- compileall
- pytest collection

## CASE-0037 — TimestampMixin export missing

- heal_id: `HEAL-0037`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: ImportError TimestampMixin absent in app.models

**Applied fix**

- Добавить TimestampMixin в фасад и унифицировать import
- path.

**Verification**

- alembic import
- pytest collection

## CASE-0038 — Migration writes to impl.stdout

- heal_id: `HEAL-0038`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: AttributeError impl.stdout

**Applied fix**

- Убрать такой вывод и использовать безопасный logger/op
- context.

**Verification**

- alembic upgrade head

## CASE-0039 — DDL not committed

- heal_id: `HEAL-0039`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: migration prints metadata, but tables absent

**Applied fix**

- Проверить transaction scope и op.execute path для DDL.

**Verification**

- tables exist after upgrade
- sanity green

## CASE-0040 — Payment intent contract drift

- heal_id: `HEAL-0040`
- archive_version: `healer-canon`
- action_priority: `immediate`

Симптом: PACKAGE_NOT_FOUND

**Applied fix**

- Сверить service, route, tests и SQL path по одному
- канону.

**Verification**

- pytest payment intents
- DB flow tests

## CASE-0041 — Broken SQL string in tests

- heal_id: `HEAL-0041`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: SyntaxError in pytest collection

**Applied fix**

- Починить шаблон SQL literal и compileall tests.

**Verification**

- pytest collection
- compileall tests

## CASE-0042 — React Query provider missing

- heal_id: `HEAL-0042`
- archive_version: `healer-canon`
- action_priority: `observe`

Симптом: No QueryClient set

**Applied fix**

- Поднять QueryClientProvider выше места вызова hook.

**Verification**

- next build
- runtime page render

## CASE-0043 — Function import drift in tests

- heal_id: `HEAL-0043`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: append_transfer_extra_info import error

**Applied fix**

- Синхронизировать тестовый импорт с каноничным именем в
- коде.

**Verification**

- pytest collection
- grep old name clean

## CASE-0044 — Direction column too short

- heal_id: `HEAL-0044`
- archive_version: `healer-canon`
- action_priority: `immediate`

Симптом: value too long for type varchar(8)

**Applied fix**

- Расширить длину/constraint под полный набор direction
- values.

**Verification**

- DB migration
- insert/update direction tests

## CASE-0045 — global_id vs users.id drift

- heal_id: `HEAL-0045`
- archive_version: `healer-canon`
- action_priority: `immediate`

Симптом: JOIN u.id = w.tg_id

**Applied fix**

- Санировать все join/filter path до tg_id only.
- Не вводить алиасы и обходные имена.

**Verification**

- grep suspicious joins
- critical flow tests



### v169_87 / repair pass treatment

Applied to `backend/app/crud/referrals_crud.py::admin_top_inviters()`: replaced all confirmed `*_global_id == User.id` joins with `*_global_id == User.global_id` and exposed `inviter_global_id` as the aggregate identity. Guard added: `tests/architecture/test_heal0045_global_id_identity_canon.py`.

## CASE-0046 — Route/service signature drift

- heal_id: `HEAL-0046`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: unexpected keyword argument

**Applied fix**

- Сверить сигнатуры route и service.
- Убрать лишний arg или добавить его в service только
- если он
- реально
- нужен по логике.

**Verification**

- pytest affected flow
- search similar calls

## CASE-0047 — ORM/service/route drift

- heal_id: `HEAL-0047`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: field missing in model/service

**Applied fix**

- Проверять связку route → service → table → migration
- одним
- циклом.
- Обновлять map docs и tests вместе с кодом.

**Verification**

- targeted tests
- MODEL_TABLE_ROUTE_TEST_MAP sync

## CASE-0048 — Unsafe raw SQL schema handling

- heal_id: `HEAL-0048`
- archive_version: `healer-canon`
- action_priority: `planned`

Симптом: B608

**Applied fix**

- Убрать string-built WHERE и raw schema SQL.
- Перевести на безопасный builder или text() с параметрами.
- Сохранить бизнес-смысл и проверки доступа.

**Verification**

- bandit
- compileall
- search_path works

## CASE-0049 — Documentation table count drift

- heal_id: `HEAL-0049`
- archive_version: `v156_15`
- action_priority: `planned`

Симптом: `SSOT_DB_SCHEMAS_TABLES.md`: 30 vs overview docs: 38

**Applied fix**

- Синхронизирован `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md` по CSV.

**Verification**

- Ручная сверка чисел 38/33/5.

## CASE-0050 — Lotteries terminology scope drift

- heal_id: `HEAL-0050`
- archive_version: `v156_15`
- action_priority: `planned`

Симптом: Blanket ban `draw/draws` conflicted with natural English UI
meaning.

**Applied fix**

- Обновлён scope запрета в `docs/SSOT/PROJECT_GLOSSARY.md`.

**Verification**

- Проверена согласованность terms и текущего UI-смысла.

## CASE-0051 — Duplicate dataclass decorator

- heal_id: `HEAL-0051`
- archive_version: `v156_15`
- action_priority: `planned`

Симптом: `WithdrawRequestDTO` had duplicate dataclass decoration.

**Applied fix**

- Удалён лишний `@dataclass`; сохранён `@dataclass(frozen=True)`.

**Verification**

- `python -m compileall backend/app`



## CASE-0052 — Shop spending order drift

- heal_id: `HEAL-0052`
- archive_version: `v156_16`
- action_priority: `planned`

Симптом: purchase_with_efhc used manual debit split bonus/main.

**Applied fix**

- Replaced manual debit split with
- spend_user_to_bank_bonus_then_main(...).

**Verification**

- pytest tests/architecture/test_shop_spending_order_canon.py

## CASE-0053 — Missing two-schema guard test

- heal_id: `HEAL-0053`
- archive_version: `v156_16`
- action_priority: `observe`

Симптом: no explicit architecture test for efhc_core/efhc_admin only.

**Applied fix**

- Added direct schema-count guard based on ORM SSOT CSV.

**Verification**

- pytest tests/architecture/test__schema__count_two.py


## CASE-0054 — Energy page archive leakage
- HEAL-ID: HEAL-0054
- Статус: fixed
- Симптом: Energy page смешивала active и archive представление панелей.
- Исправление: archived_count удалён с Energy; оставлены только
  active_count и generation active panels.


## CASE-0055 — DB-backed MonetaryIdempotency TTL lock

- heal_id: `HEAL-0055`
- archive_version: `v156_19`
- action_priority: `planned`

Симптом: MonetaryIdempotencyMiddleware держал TTL duplicate barrier в
памяти процесса.

**Applied fix**

- Удалён self._ttl_seen из middleware.
- Добавлен atomic DB-backed TTL lock через efhc_admin.idempotency_key.
- Тест обновлён под shared lock helper.

**Verification**

- `python -m compileall backend/app/core/system_locks.py
  tests/core/test_monetary_idempotency_middleware.py`


## CASE-0056 — GlobalHeader menu and user-status badges

- heal_id: `HEAL-0056`
- archive_version: `v156_20`
- action_priority: `planned`

Симптом: header скрывал вход в профиль только за аватаром и не показывал
статусы VIP/Activ.

**Applied fix**

- Added profile.has_activ to sync snapshot.
- Added VIP and Activ badges to GlobalHeader and ProfileModal.
- Added explicit Menu button in GlobalHeader.
- Renamed visible profile UI labels to Menu.

**Verification**

- `python -m compileall backend/app/routes/sync_routes.py`
- `grep profile.has_activ frontend/src/hooks/useSnapshot.ts
  frontend/src/components/Layout.tsx
  frontend/src/components/GlobalHeader.tsx
  frontend/src/components/ProfileModal.tsx`

## CASE-0057 — Global rename from split profile wording to profile

- Heal ID: HEAL-0057
- Result: old split profile wording removed from user-facing archive
  texts.
- Verification: repo grep on old wording returned zero matches.

## CASE-0058 — Docker local environment upgraded

- archive: `v156_22`
- result: добавлен практический локальный Docker-стенд для db, backend и
  frontend.


## CASE-0059 — DB-backed tg_id monetary rate limiting middleware

- Heal ID: HEAL-0059
- Archive: `v156_23`
- Result: monetary routes now have shared tg_id-based rate limiting in
  runtime.

**Applied fix**

- Added MonetaryRateLimitMiddleware for monetary paths.
- Implemented DB-backed slot acquisition by tg_id and scope path.
- Enabled middleware in backend/app/main.py.
- Added architecture guard for middleware wiring.

## CASE-0060 — Replaced HTTPException in service layer

- Heal ID: `HEAL-0060`
- Result: lotteries/tasks services now use domain errors instead of
  `HTTPException`.

## CASE-0061 — Refactored _run_idempotent retry policy helpers

- Heal ID: `HEAL-0061`
- Archive: `v156_25`
- Result: `_run_idempotent` became easier to audit without reducing
  monetary safety.

**Applied fix**

- Added `_is_idempotency_conflict(exc)`.
- Added `_is_transient_tx_error(exc)`.
- Added `_read_through_existing_tx(...)`.
- Added `_mark_idempotency_conflict(...)`.
- Preserved retries only for unique idempotency_key, deadlock and
  serialization.


## CASE-0062 — Prepared v157 continuation prompt and synced AL docs

- Heal ID: `HEAL-0062`
- Archive: `v157_00`
- Fix: создан `docs/AI/CONTINUE_NEW_CHAT_V157_PROMPT.md`, обновлены
  AL-документы и записи цикла.
- Result: `resolved`.

## CASE-0063 — Cleaned release ZIP and restored canonical Profile term

- Heal ID: `HEAL-0063`
- Archive: `v157_01`
- Fix: удалены кэши из релизной упаковки, русский FAQ SSOT и runtime
  приведены к канону `Профиль`.
- Result: `resolved`.


## v157_02 / logs_60244480535
- Circular import around `app.models.Base` caused alembic/pytest
  failures.
- Fixed by extracting shared ORM base into `backend/app/models/base.py`.
- Also fixed mypy, bandit, frontend type drift and ruff issues confirmed
  by log `60244480535`.


## CASE-0064 — Residual CI tails after v157_02

- Heal ID: `HEAL-0064`
- Archive: `v157_03`
- Fix: восстановлены missing imports в `lotteries_routes.py`,
  устранены line72-хвосты, санированы offending logs, casebook
  доведён по `confirmation_basis`.
- Result: `resolved`.


## CASE-0065 — Tournament-themed user-facing copy sync

- Heal ID: `HEAL-0065`
- Archive: `v157_04`
- Fix: синхронизированы user-facing тексты Турниры / Начать раунд /
  Стоимость входа / Раунд в locale, runtime FAQ и русском FAQ SSOT.
- Result: `resolved`.


## CASE-0066 — FAQ section-name wording drift
- heal_id: HEAL-0066
- status: fixed
- archive_version: v157_05
- symptom_excerpt: В FAQ сохранялись смешанные названия раздела 14
  (`Lotteries`, `Розіграші`, `Lotterien`, `Loteries`, `Lotterie`,
  `Loterie`, `Lotterier`, `Çekilişler`).
- applied_fix: Во всех FAQ-слоях раздел 14 приведён к `Турниры / Турніри
  / Tournaments`.
- confirmation_basis: прямой аудит файлов FAQ и нулевой остаток по
  поиску старых section-name терминов.
- result: fixed


## CASE-0067 — Residual tournaments wording drift cleanup

- heal_id: HEAL-0067
- archive_version: v157_06
- symptom_excerpt: в user-facing слоях после v157_05 ещё оставались
  `Tournamentsr`, `lotteries`, `розіграш`, `Çekiliş` и bot fallback
  `Lotteries`
- applied_fix: выполнена дочистка locale, runtime FAQ, FAQ SSOT, bot
  handlers и visible error message
- forbidden_fix: не переименовывать технический домен `lotteries_*` в
  рамках текстовой чистки
- verification_done: поиск по user-facing слоям на legacy terms чистый
- result: остались только технические комментарии и доменные имена


## CASE-0068 — Residual user-facing tournaments drift in FAQ SSOT pack

- heal_id: HEAL-0068
- archive_version: v157_07
- symptom_excerpt: после `v157_06` в runtime FAQ, FAQ SSOT,
  `FAQ_SSOT_20_SECTIONS.json` и `README.md` ещё оставались legacy terms
  о lotteries/розыгрышах.
- applied_fix: выполнена повторная дочистка `frontend/src/data/faq/*`,
  `docs/SSOT/faq_ssot/**`,
  `docs/SSOT/ssot_pack/FAQ_SSOT_20_SECTIONS.json`, а в locale values
  приведён `lotteries.cost` к канону.
- forbidden_fix: technical domain `lotteries_*` не переименовывался.
- verification_done: поиск по user-facing FAQ/source files пустой; JSON
  locale values валидны и без legacy terms.
- result: fixed


## CASE-0069 — Lotteries full-domain removal baseline

- heal_id: HEAL-0069
- archive_version: v157_08
- symptom_excerpt: пользователь потребовал удалить из кода и архива весь
  lotteries domain; прямой аудит HEAD подтвердил 1977 совпадений с
  высокой концентрацией в backend routes/services/models/crud, frontend
  page/locale и SSOT docs.
- applied_fix: выполнен baseline audit и создан 20-cycle decommission
  map.
- forbidden_fix: не делать массовое удаление вслепую без карты импортов,
  API/ORM/docs связей и без явной фиксации исторических записей.
- verification_done: подтверждены основные зоны и файлы высокой
  плотности; серия decommission открыта.
- result: pending removal


## CASE-0069A — Coupling audit extension

- date: 2026-03-25
- cycle: 02
- symptom_excerpt: lotteries подтверждён как связанная подсистема с
  frontend entry points, bot handlers, public/admin routes, schemas,
  services, crud, models и SSOT docs.
- applied_fix: выполнен аудит связей и зафиксирован безопасный порядок
  staged removal.
- next_step: cycle 03 — удалить frontend entry points и navigation
  hooks.


## CASE-0069B — Frontend entry points removal

- date: 2026-03-25
- cycle: 03
- symptom_excerpt: основной пользовательский вход в lotteries-domain
  сохранялся в `frontend/src/pages/panels.tsx` через button redirect и
  CTA-link на `/lotteries`.
- applied_fix: удалены user-facing переходы и CTA-card из Panels; сама
  страница `frontend/src/pages/lotteries.tsx` оставлена до отдельного
  цикла удаления страницы.
- verification_done: `npm --prefix frontend run build` — OK.
- next_step: cycle 04 — убрать runtime locale keys и FAQ bindings, cycle
  05 — удалить саму frontend page.


## CASE-0069B — Frontend entry points removal

- date: 2026-03-25
- cycle: 03
- symptom_excerpt: основной пользовательский вход в lotteries-domain
  сохранялся в `frontend/src/pages/panels.tsx` через button redirect и
  CTA-link на `/lotteries`.
- applied_fix: удалены user-facing переходы и CTA-card из Panels; сама
  страница `frontend/src/pages/lotteries.tsx` оставлена до отдельного
  цикла удаления страницы.
- verification_done: поиск по `frontend/src/pages/panels.tsx` на
  `lotteries`, `/lotteries`, `lotteries_hint`, `open_lotteries`,
  `nav.lotteries` — пустой.
- environment_note: локальная `next build` не подтверждена в этой среде,
  потому что отсутствуют установленные frontend dependencies.
- next_step: cycle 04 — убрать runtime locale keys и FAQ bindings, cycle
  05 — удалить саму frontend page.


## CASE-0070 — lotteries runtime locale / FAQ bindings drift

- heal_id: `HEAL-0069`
- archive_version: `v157_11`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Removed dead Panels locale keys from all runtime locale JSON files.
- Removed runtime FAQ section 14 in `ru.ts` and `catalogs.ts`.
- Removed runtime FAQ meta labels `14` / `14.1`.
- Cleaned remaining runtime FAQ tournament references in general
  answers.

**Verification**
- grep on removed locale keys
- grep on runtime FAQ section/meta
- JSON reload of locale files


## CASE-0071 — lotteries frontend page removal

- heal_id: `HEAL-0069`
- archive_version: `v157_12`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `frontend/src/pages/lotteries.tsx`.
- Removed direct frontend client calls to `/api/lotteries*` by removing
  the page module.

**Verification**
- file absence check for `frontend/src/pages/lotteries.tsx`
- grep on `frontend/src/**` for `/api/lotteries`


## CASE-0072 — lotteries bot-visible handlers removal

- heal_id: `HEAL-0069`
- archive_version: `v157_13`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/bot/handlers/lotteries_handlers.py`.
- Deleted `backend/app/bot/handlers/admin/admin_lotteries_handlers.py`.
- Removed lotteries router import/include from `backend/app/bot/bot.py`.
- Removed admin lotteries router import/include from
  `backend/app/bot/handlers/admin_handlers.py`.
- Removed `🎟 Лотереи` button from `backend/app/bot/keyboards.py`.

**Verification**
- grep on bot layer for `lotteries_handlers`,
  `admin_lotteries_handlers`, `lotteries_router`, `/lotteries`, `🎟
  Лотереи`
- `pytest -q tests/architecture/test_frontend_page_shell_coverage.py`


## CASE-0073 — lotteries public API routes removal

- heal_id: `HEAL-0069`
- archive_version: `v157_14`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/routes/lotteries_routes.py`.
- Removed `lotteries_routes` from `backend/app/routes/init.py`.
- Synced route-coupled tests and docs for removed public lotteries
  endpoints.

**Verification**
- file absence check for `backend/app/routes/lotteries_routes.py`
- grep on `backend/app/routes/**` for `lotteries_routes` and
  `/api/lotteries`
- `python -m compileall backend/app/routes`

## CASE-0069 — 2026-03-25 — cycle 08

- Removed admin lotteries routes and related facade exposure.
- Synced admin contract surface and SSOT route maps.


## CASE-0074 — lotteries schema/contract layer removal

- heal_id: `HEAL-0069`
- archive_version: `v157_16`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/contracts/lotteries_contract.py`.
- Deleted `backend/app/schemas/lotteries_schemas.py`.
- Deleted `backend/app/schemas/admin/admin_lotteries_schemas.py`.
- Removed `AdminLotteriesOut` / `AdminLotteriesUpsertIn` from admin
  schema surface and re-export wrappers.

**Verification**
- `python -m compileall backend/app/schemas backend/app/contracts`
- grep on exact leftovers
  schema group:
  `AdminLotteriesOut|AdminLotteriesUpsertIn|`
  `lotteries_schemas.py|lotteries_contract.py|`
  `admin_lotteries_schemas.py`


## CASE-0075 — lotteries service layer removal

- Deleted `backend/app/services/lotteries_service.py`.
- Deleted `backend/app/services/admin/admin_lotteries_service.py`.
- Synced direct tests that referenced removed service files.
- Removed stale SSOT/doc references to deleted service paths.

Verification:
- file absence checks for both deleted service files
- `python -m compileall backend/app/services backend/app/services/admin`
- `pytest -q tests/efhc_backend/unit/test_prizes_autocycle_ssot.py
  tests/efhc_backend/unit/test_prizes_smoke.py
  tests/architecture/test_services_no_http_exception.py`


## CASE-0076 — lotteries CRUD layer removal

- heal_id: `HEAL-0069`
- archive_version: `v157_18`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted `backend/app/crud/lotteries_crud.py`.
- Deleted `backend/app/crud/admin/admin_lotteries_crud.py`.
- Removed lotteries alias and CRUD health-check requirements from
  `backend/app/crud/init.py`.
- Synced decommission guard test to assert CRUD-layer removal.

**Verification**
- file absence checks for both deleted CRUD files
- `python -m compileall backend/app/crud backend/app/crud/admin`
- `pytest -q tests/efhc_backend/unit/test_prizes_autocycle_ssot.py`


## CASE-0077 — lotteries tests/fixtures removal

- heal_id: `HEAL-0069`
- archive_version: `v157_20`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted lotteries-specific test files.
- Reduced generic architecture guards/tests to non-lotteries scope.
- Synced `docs/history/legacy_artifacts/docs/NORM/TESTS_CATALOG.md` and overview-doc counts.

**Verification**
- `pytest -q tests/architecture/test_services_no_http_exception.py
  tests/architecture/test_great_canon_guard.py
  tests/architecture/test_docs_ssot_sync.py`
- `python -m compileall tests/architecture`

- 2026-03-25 v157_21: cycle 14 removed lotteries env/config surface
  (`LOTTERIES_*` example vars, config_core settings block,
  admin_settings lotteries keys).

## CASE-0078 — lotteries ops guards/checks removal

- heal_id: `HEAL-0069`
- archive_version: `v157_22`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted lotteries-only canon guard
  `check_lotteries_auto_cycle_ssot(...)`.
- Deleted lotteries-only idempotency path patterns from
  `ops/canon_rules.yaml`.
- Deleted scheduler soft-import and registration for
  `lotteries_autorestart`.

**Verification**
- `python -m compileall ops backend/app/services`
- grep absence checks for `check_lotteries_auto_cycle_ssot`,
  `LOTTERIES_SCHEDULER_FORBIDDEN`, `LOTTERIES_SERVICE_MISSING`,
  `lotteries_autorestart`


## v157_23 / cycle 16
- Rebuilt docs layer and removed active lotteries-domain references from
  docs/overview/glossary/API descriptions.

## CASE-0079 — lotteries SSOT structural residue
- symptom_excerpt: после демонтажа route/model/service слоя в
  `docs/SSOT/ssot_pack` всё ещё оставались активные lotteries
  rows/sections в `SSOT_TABLES_PURPOSE_RU.md`,
  `SSOT_TABLES_MIGRATIONS.csv`, `SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md`.
- applied_fix: удалены lotteries sections/rows/bullets из трёх
  SSOT-файлов, документ циклов и reports обновлены.
- verification_done: точный grep по `docs/SSOT/ssot_pack` на
  lotteries-термины пустой; `pytest -q
  tests/architecture/test_docs_ssot_sync.py`.

## CASE-0080 — lotteries legacy DB / migration policy
- symptom_excerpt: после снятия active lotteries-domain оставались
  только historical mentions в docs/history/legacy_artifacts/reports/healer/audits и требовалось
  зафиксировать, что это не active SSOT.
- applied_fix: в DB/SSOT canon docs добавлена политика historical
  traces; новые drop-migrations без DB/CI/audit подтверждения запрещены
  в этой серии.
- verification_done: active DB SSOT docs сохраняют только две схемы;
  прямой аудит не подтверждает active lotteries-trace в
  `backend/migrations/**` и DB SSOT слое.


## CASE-0081 — lotteries final residual traces
- heal_id: `HEAL-0069`
- archive_version: `v157_26`
- confirmation_basis: `direct__file__audit`
- result: `confirmed_fixed`

**Applied fix**
- Deleted dead frontend locale keys `lotteries.*`.
- Removed active backend/doc comments and descriptions that still
  mentioned lotteries-domain.
- Renamed `LotteriesClosedError` to `ParticipationClosedError`.
- Removed active admin DTO field `lotteries_id`.
- Removed `logs/` from release archive as stale artifact.

**Verification**
- residual grep across active tree excluding historical buckets
- `python -m compileall backend/app ops`
- locale JSON validation


## CASE-0069R — Final closure

- date: 2026-03-25
- cycle: 20
- symptom_excerpt: требовалось подтвердить, что после staged
  decommission в active tree не осталось lotteries-domain, а historical
  mentions сохранены только как история лечения и аудита.
- applied_fix: выполнен финальный residual grep по active tree,
  завершены контрольные compile/test проверки, серия decommission
  закрыта.
- verification_done: `FOUND 0` по active tree; `python -m compileall
  backend/app ops tests/architecture`; `pytest -q
  tests/architecture/test_docs_ssot_sync.py
  tests/architecture/test_great_canon_guard.py
  tests/architecture/test_services_no_http_exception.py`.
- result: resolved

## CASE-0082 — runtime drift inventory / unified cycles register
- date: 2026-03-26
- cycle: 21
- archive_version: v157_29
- symptom_excerpt: после закрытия lotteries decommission оставался
  разрозненный учёт следующих рабочих серий и не было единого inventory
  mismatch-классов между SSOT, runtime, docs, tests и release artifact.
- applied_fix: создан единый документ циклов 1–40 и отдельный runtime
  drift inventory с контрольными числами и точками проверки.
- verification_done: inventory собран по active tree; контрольные
  архитектурные pytest-проверки проходят.
- result: resolved

- 2026-03-26 v157_30 cycle 22: FAQ/runtime sync hardened with
  deterministic SSOT generator and exact-match guard.

- CASE-0070: fixed route-surface drift (`/api` embedded in local route
  prefixes/paths), added `test_route_prefixes_no_embedded_api.py`,
  verified compileall + architecture tests.

- 2026-03-26 / Cycle 24: admin route surface canonicalized; added admin
  route module guard; synced docs counts/catalog; line72 tail fixed.

## CASE-0083 — route/service/table docs count drift
- date: 2026-03-26
- cycle: 27
- archive_version: v158_04
- symptom_excerpt: active docs for SSOT routes still reported 91/92
  routes while canonical CSV registry contained 82 routes after route
  cleanups.
- applied_fix: synced active docs counts and added architecture guard
  `test_ssot_route_count_docs_sync.py`.
- verification_done: `docs/SSOT/ssot_pack/SSOT_ROUTES.csv` row count =
  82; targeted pytest guard passes.
- result: resolved
## 2026-03-26 — cycle 28 — startup/OpenAPI consistency
- symptom_excerpt: `api/index.py` stopped after env bootstrap and
  exported no `app`; `backend/openapi/openapi.json` contained only
  `/health` and `/api/cron/tick` while SSOT route registry contained 82
  active paths.
- confirmed_root_cause: stale/truncated Vercel entry file and stale
  exported OpenAPI artifact not synchronized with SSOT route surface.
- fix: restored `api/index.py` import/export contract, regenerated
  `backend/openapi/openapi.json` from
  `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`, added
  `tests/architecture/test_openapi_startup_consistency.py`.
- CASE-0086: route inventory freeze added for active route surface;
  fresh CI failure in the same cycle was limited to `ruff` import order
  in the FAQ guard test and was fixed before freeze verification.


## CASE-0087 — idempotency surface full-path audit
- date: 2026-03-26
- cycle: 33
- archive_version: v158_10
- symptom_excerpt: route idempotency guard missed drift because it
  parsed only local route strings without router prefixes and did not
  inspect Depends defaults.
- applied_fix: rebuilt guard, synced canon regex to active routes,
  corrected stale SSOT path `/admin/referrals/reassign`, added
  CSV/markdown audit artifacts.
- verification_done: targeted architecture pytest passes; generated
  idempotency surface docs match CSV counts.
- result: resolved

- CASE-0088 — Cycle 34 fixed response/error canon drift by registering
  `setup_exception_handlers(app)` and normalizing object-detail payload
  keys in `payment_intents_routes.py` and `wallets_routes.py`.


## Cycle 36
- Confirmed by `logs_62194714005.zip`: banned tg_id alias terms remained
  in `docs/SSOT/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json`.
- Treatment: replaced alias mentions with tg_id-only wording, updated
  migration invariants to 32 tables / 2 schemas / ORM-only 0001, added
  dedicated guard.

- CASE-0088: cycle 37 removed stale DB totals 38/33 and repaired
  malformed legacy policy paragraphs in active DB docs.

## 2026-03-26 — cycle 38 — route matrix/OpenAPI docs sync
- symptom_excerpt: `MODEL_TABLE_ROUTE_TEST_MAP.md` kept stale counts and
  referenced missing `backend/app/models/exchange_routes.py`.
- confirmed_root_cause: route matrix markdown was not synchronized after
  recent route/OpenAPI/test-file growth.
- fix: updated counts to current SSOT/OpenAPI values, replaced missing
  model file reference, added
  `tests/architecture/test_openapi_docs_route_matrix_sync.py`.

- CASE-0090: cycle 39 removed `.local_artifacts/`, `logs/` and `*.log`
  from release ZIP packaging surface.

- CASE-0092 / HEAL-0080: final regression pack of cycles 31–40 caught
  stale `test files` count in `MODEL_TABLE_ROUTE_TEST_MAP.md`; corrected
  from 111 to 112 and series closed.

## CASE-0090
- Сценарий: нужно начать FAQ purge без точного freeze и без RU candidate
  count.
- Решение: сначала фиксировать inventory и список прямых
  risk-кандидатов, потом запускать purge wave.

- CASE-0093: RU FAQ review wave 2 created a manual confirmation list
  instead of auto-deleting section 14 candidates.

- CASE-0094: cycle 44 replaced five weak section-14 Q/A with more
  practical WebApp guidance while keeping totals stable.
- cycle 45: faq translations/runtime parity wave 1 — done (v158_22)
- CASE-0096: cycle 46 ran a zero-candidate audit for RU direct-risk FAQ
  wave 2 and confirmed no new removals were needed.



- CASE-0097: cycle 47 created RU weak/duplicate manual-review list with
  5 groups / 7 Q/A and no automatic FAQ edits.

- CASE-0091: Section 14 weak/duplicate groups resolved by strengthening
  8 Q/A while keeping 17-item section stable.

- CASE-0098: cycle 50 resolved RU duplicate wave 2 by refining 6 Q/A
  across sections 3, 8 and 16 with totals unchanged.

- CASE-0099 / HEAL-0087: cycle 51 synced 6 RU duplicate-resolution FAQ
  IDs across 12 non-RU languages and regenerated runtime catalogs.


- Cycle 52 case: duplicate audit wave 3 required audit_only lock instead
  of silent FAQ mutation.

## CASE-0100 — cycle 53 resolved 4 duplicate groups in RU FAQ wave 3
- Архив: v158_30
- База подтверждения: direct audit of `docs/SSOT/faq_ssot/ru/faq_ru.md`
  and `faq_ru.json`.
- Действия: усилены 8 RU Q/A, regenerated runtime FAQ catalogs, review
  file marked resolved.


## CASE-0101
- Archive: v158_31
- Heal: HEAL-0089
- Title: cycle 54 synced non-RU FAQ layers for 8 mirrored ids after RU
  duplicate resolution wave 3.

## CASE-0109
- Archive: v159_13
- Heal: HEAL-0098
- Title: cycle 67 froze the EFHC handoff architecture boundary for Hub.
- Confirmation basis: direct audit of `frontend/src/pages/shop.tsx`,
  `backend/app/routes/shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/schemas/shop_schemas.py`,
  `backend/app/contracts/shop_contract.py`, and `docs/SSOT/HUB_SSOT.md`.
- Treatment history:
  - added `docs/HUB_EFHC_HANDOFF_ARCHITECTURE_AUDIT.md`
  - froze signed short-lived one-time token requirements
  - blocked direct reuse of Shop commerce contracts as the future Hub
    public contract


Cycle 69 note: active runtime aggregate FAQ and locale help-text kept
stale VIP-in-Shop wording after Hub card had already moved to external
GetGems; fixed without changing ownership-check logic.


## CASE-0110
- Archive: v159_16
- Heal: HEAL-0099
- Title: cycle 70 removed residual commerce wording from active skin
  locale layer.
- Confirmation basis: direct audit of `frontend/public/locale/*.json`
  and `frontend/src/lib/skins.ts`; targeted pytest lock.
- Treatment history:
  - rewrote active skin locale keys in all 13 languages
  - removed "Shop skins" wording from frontend skin helper
  - locked the 12-level progression theme canon


## HEAL-0099 / CASE-0110
- Symptom: after the user-facing skin wording cleanup, the active
  model/data/service/API/helper layer still retained a legacy commerce
  bridge for skins.
- Fix in cycle 71: added `docs/SKINS_MODEL_DATA_AUDIT.md`, confirmed the
  active legacy markers `price_efhc`, `purchased_at`,
  `POST /skins/buy/{skin_id}`, `buy_skin(...)`, `skin_purchase`,
  `getShopSkinBgUrl(...)`, and `efhc_shop_skin_changed`, and added
  `tests/architecture/test_skins_model_data_audit_lock.py`.
- Verification: direct audit of HEAD `v159_16`, including
  `backend/app/models/skins_models.py`,
  `backend/app/routes/skins_routes.py`,
  `backend/app/schemas/skins_schemas.py`,
  `backend/app/services/skins_service.py`,
  `backend/app/standards/skins_catalog.py`, and
  `frontend/src/lib/skins.ts`.


## 2026-03-28 — Cycle 75 Hub admin routes/services
- Подтверждён archive-first drift: следующий цикл по HEAD — `75`, не
  `76`.
- Закрыт backend слой Hub admin manager:
  list/create/update/toggle/reorder.
- Добавлены новые active endpoints `/admin/hub/links` и технические
  алиасы `/admin/shop/hub-links`.
- Price/order semantics не переносились в `hub_links`.


## 2026-03-28 — Cycle 76 Hub admin UI wave
- Подтверждено: frontend admin page ещё жила на legacy
  Shop-orders/set-price semantics.
- `frontend/src/pages/admin/shop.tsx` переведён на Hub Links Manager.
- Active UI вызывает `/admin/hub/links`, create/update/toggle/reorder.
- Из active admin UI убраны order/price fields; `/admin/shop` сохранён
  как технический route alias.


## CASE-0111
- Archive: v160_02
- Heal: HEAL-0100
- Title: cycle 77 froze the Russian Hub FAQ section 13 draft because the
  active runtime had already moved ahead of the SSOT export.
- Confirmation basis: direct audit of `frontend/src/data/faq/ru.ts`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`, and `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`.
- Treatment history:
  - confirmed archive-first drift between runtime and SSOT FAQ section
    13
  - added `docs/HUB_FAQ_SECTION_13_RU_DRAFT.md`
  - froze the 13-question approval list for the Russian Hub section


## CASE-0112
- Archive: v160_03
- Heal: HEAL-0101
- Title: cycle 78 corrected the false FAQ runtime assumption and froze
  the real Shop→Hub drift map.
- Confirmation basis: direct audit of
  `frontend/src/data/faq/catalogs.ts`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`,
  `docs/SSOT/faq_ssot/ru/faq_ru.json`,
  `backend/app/bot/handlers/shop_handlers.py`, and
  `frontend/public/locale/*.json`.
- Treatment history:
  - rejected the prior unconfirmed statement about
    `frontend/src/data/faq/ru.ts`
  - confirmed active `Shop` traces in runtime/SSOT/bot/locale layers
  - added `docs/HUB_FAQ_CROSS_SECTION_DRIFT_AUDIT.md`


## CASE-0113
- Archive: v160_04
- Heal: HEAL-0102
- Title: cycle 79 rewrote the Russian SSOT FAQ from Shop semantics to
  Hub canon.
- Confirmation basis: direct audit of `docs/SSOT/faq_ssot/ru/faq_ru.md`,
  `docs/SSOT/faq_ssot/ru/faq_ru.json`, and `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`.
- Treatment history:
  - replaced user-facing `Shop` mentions in RU SSOT navigation answers
  - rewrote section 13 from `Shop` to `Hub`
  - fixed EFHC/VIP wording to external flows and skins to progression
    rewards


## CASE-0114
- Archive: v160_05
- Heal: HEAL-0103
- Title: cycle 80 rebuilt runtime FAQ from SSOT and closed the Russian
  runtime drift.
- Confirmation basis: generator run
  `ops/scripts/generate_faq_catalogs_from_ssot.py`, guard
  `test_faq_catalogs_generated_from_ssot.py`, and direct audit of
  `frontend/src/data/faq/catalogs.ts`.
- Treatment history:
  - rebuilt `frontend/src/data/faq/catalogs.ts` from
    `docs/SSOT/faq_ssot/*/faq_*.json`
  - confirmed Russian runtime section `13. Hub` and `250/250` parity
  - confirmed no `Shop` residuals inside the RU runtime chunk


## CASE-0115
- Archive: v160_06
- Heal: HEAL-0104
- Title: cycle 81 synchronized the bot help/text layer with Hub and
  fixed the text helper call contract.
- Confirmation basis: direct audit of `backend/app/bot/texts.py`,
  `backend/app/bot/handlers/shop_handlers.py`,
  `backend/app/bot/handlers/admin/admin_shop_handlers.py`, and `python
  -m compileall backend/app/bot`.
- Treatment history:
  - replaced Shop-facing bot/help strings with Hub-facing text
  - preserved `/shop` and `/admin_shop` as technical aliases
  - made `t()` compatible with both old and new call styles

## CASE-0116
- Archive: v160_07
- Heal: HEAL-0104
- Title: cycle 82 synchronized multilingual SSOT FAQ with the Hub canon
  and rebuilt runtime parity.
- Confirmation basis: direct audit of `docs/SSOT/faq_ssot/*/faq_*.json`
  and `docs/SSOT/faq_ssot/*/faq_*.md`, residual grep for `Shop`,
  generator run `ops/scripts/generate_faq_catalogs_from_ssot.py`, and
  guard `test_faq_catalogs_generated_from_ssot.py`.
- Treatment history:
  - replaced active Shop-facing section 13/top-bar/navigation FAQ
    wording in all 12 non-Russian languages
  - regenerated markdown SSOT exports from the updated JSON files
  - rebuilt `frontend/src/data/faq/catalogs.ts` from SSOT and verified
    generator parity


- 2026-03-28 cycle 83: docs/openapi sync closed; Hub admin surface
  `/admin/hub/links*` and public handoff `POST /hub/efhc-handoff` added
  to SSOT/OpenAPI/docs, route count synced to 88.


## CASE-0117
- Archive: v160_09
- Heal: HEAL-0105
- Title: cycle 84 locked the active Hub surface with a dedicated
  regression pack.
- Confirmation basis: direct audit of `frontend/src/pages/shop.tsx`,
  `frontend/src/pages/hub.tsx`, `frontend/src/pages/admin/hub.tsx`,
  `frontend/src/components/GlobalHeader.tsx`,
  `backend/app/routes/hub_routes.py`, `backend/app/bot/keyboards.py`,
  `backend/app/bot/texts.py`, and pytest pass of the Hub regression
  pack.
- Treatment history:
  - added a dedicated guard for the alias `shop -> hub`
  - locked the ban on prices, TonConnect, internal purchase, and skin
    SKU in active Hub UI
  - locked signed external EFHC handoff and external VIP GetGems flow


## HEAL-0106 / CASE-0118
- Symptom: after the main Hub migration waves, the repository still
  contained a broad `shop` footprint, but the traces were mixed across
  active backend commerce code, temporary aliases, historical audit
  records, and true cleanup-ready residues.
- Fix in cycle 85: added `docs/LEGACY_SHOP_RESIDUE_AUDIT.md` and
  classified the remaining `shop` traces into keep-as-commerce,
  keep-as-alias, keep-as-history, and cleanup-candidates-for-cycle-86
  buckets.
- Verification: direct HEAD grep across `backend`, `frontend`, `docs`,
  and `tests`, plus usage checks for locale keys and active
  admin/profile surfaces.

## 2026-03-28 — cycle 86
- Подтверждённая проблема: после residue-аудита оставались cleanup-ready
  user-facing/docs residuals `Shop`, хотя backend commerce domain и
  compatibility aliases ещё нужны.
- Исправлено: удалены 143 мёртвых locale-ключа
  `admin.shop_orders_summary`, `desc.shop.*`, `shop.*` из
  `frontend/public/locale/*.json`; исправлены stale docs wording в
  `docs/FAQ_COVERAGE_MATRIX.md`, `docs/NORM/ADMIN_RBAC.md`,
  `docs/GENERAL/specification.md`, `frontend/public/skins/README.txt`.
- Проверено: direct grep по `frontend/public/locale` больше не находит
  удалённые dead keys; JSON всех locale-файлов валиден.

## CASE-SECURITY-REGRESSION
- Archive: v160_12
- Heal: HEAL-0107
- Title: cycle 87 locked the transition layer under alias pressure.
- Confirmation basis: direct audit of `frontend/src/pages/hub.tsx`,
  `frontend/src/pages/shop.tsx`, `frontend/src/pages/admin/hub.tsx`,
  `backend/app/bot/handlers/shop_handlers.py`,
  `backend/app/bot/handlers/admin/admin_shop_handlers.py`,
  `backend/app/routes/admin_shop_routes.py`, locale files, and pytest
  pass of the alias pressure test.
- Treatment history:
  - locked `/hub` as the primary user-facing surface
  - kept `/shop` and `/admin_shop` as compatibility aliases
  - kept `/admin/shop/hub-links*` aligned with `/admin/hub/links*`

## CASE-0120
- Archive: v160_13
- Heal: HEAL-0108
- Title: cycle 88 formalized the safe alias removal design before any
  real `shop` alias deletion.
- Confirmation basis: direct audit of `docs/SSOT/HUB_SSOT.md`,
  `docs/LEGACY_SHOP_RESIDUE_AUDIT.md`,
  `docs/HUB_ALIAS_PRESSURE_TEST.md`, and `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`.
- Treatment history:
  - separated alias-removal candidates from backend commerce domain
  - fixed explicit preconditions before cycle 89
  - documented wave-by-wave removal policy and evidence checks

- Cycle 89 case: safe wave-1 alias removal executed as internal
  canonicalization only; public `/shop` and `/admin/shop` compatibility
  preserved, live implementation moved into `hub` files.

- 2026-03-28 / cycle 90: final commerce cleanup + release stabilization
  — removed dead `frontend/src/components/ShopGrid.tsx`, aligned active
  UI doc `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`, renamed canonical
  admin component export to `AdminHubPage`, preserved `/shop` and
  `/admin/shop` compatibility aliases, targeted regression pack
  required.


## CASE-0121
- Archive: v160_16
- Heal: HEAL-0109
- Title: cycle 91 closed the postponed skin switcher concept as a
  separate SSOT layer.
- Confirmation basis: direct audit of skin
  runtime/helper/model/service/route files and new concept document
  `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`.
- Treatment history:
  - separated skin switcher from Hub
  - separated switcher from legacy commerce-domain
  - fixed cumulative unlock rule and `active_skin_id` fallback policy
  - marked old cycle 72 as resolved later by cycle 91


## CASE-0122
- Archive: v160_17
- Heal: HEAL-0110
- Title: cycle 92 added the first separate runtime/API layer for the
  skin switcher.
- Confirmation basis: direct audit of new `/skins/switcher*` endpoints,
  schema/helper surface, and active-skin synchronization logic against
  the progression canon.
- Treatment history:
  - added dedicated switcher endpoints
  - added `current_level`, `available_skin_ids`, `active_skin_id`,
    `items[]`
  - kept legacy `/skins/buy` bridge untouched
  - synchronized `active_skin_id` with highest unlocked fallback


## CASE-0123
- Archive: v160_18
- Heal: HEAL-0111
- Title: cycle 93 mapped real alias callers before wave-2 removal.
- Confirmation basis: direct audit of wrapper pages, bot alias commands,
  keyboard deep links, admin index, and current router wiring.
- Treatment history:
  - confirmed `/shop` and `/admin_shop` as active bot aliases
  - confirmed `/admin/shop` as the only internal admin caller
  - confirmed no current keyboard deep link to `/shop`
  - moved thin wrapper modules into cleanup candidates for cycle 94


## CASE-0124
- Archive: v160_19
- Heal: HEAL-0112
- Title: cycle 94 removed the confirmed thin alias residue without
  touching external compatibility surfaces.
- Confirmation basis: direct audit of
  `frontend/src/pages/admin/index.tsx`, live bot routers, deleted
  wrapper modules, and targeted pytest pass.
- Treatment history:
  - moved internal admin link from `/admin/shop` to `/admin/hub`
  - removed `shop_handlers.py`
  - removed `admin_shop_handlers.py`
  - preserved `/shop`, `/admin_shop`, page aliases, and backend commerce
    `/shop/*`


## CASE-0125
- Archive: v160_20
- Heal: HEAL-0113
- Title: cycle 95 stabilized bot and WebApp admin entrypoints around
  Admin Hub.
- Confirmation basis: direct audit of bot keyboards, admin handlers,
  help texts, and targeted pytest pass.
- Treatment history:
  - added `kb_admin_entry()`
  - pointed `/admin` and `/admin_hub` directly to `/admin/hub`
  - listed `/admin_hub` and `/admin_shop` explicitly in help texts


## CASE-0126
- Archive: v160_21
- Heal: HEAL-0114
- Title: cycle 96 froze docs and OpenAPI after alias waves without
  changing the HTTP surface.
- Confirmation basis: direct audit of `docs/history/legacy_artifacts/docs/NORM/TESTS_CATALOG.md`,
  `docs/POST_ALIAS_DOCS_OPENAPI_FREEZE.md`,
  `frontend/src/pages/admin/index.tsx`, and
  `backend/openapi/openapi.json`.
- Treatment history:
  - documented `/admin/hub` as the current internal admin entry
  - preserved `/shop` and `/admin_shop` as compatibility aliases
  - confirmed OpenAPI route stability
  - removed stale active docs wording


## CASE-0127
- Archive: v160_22
- Heal: HEAL-0115
- Title: cycle 97 hardened the semantic split between Hub admin manager
  and commerce reporting.
- Confirmation basis: direct audit of admin index labels, admin stats
  service, reports service, and new hardening document.
- Treatment history:
  - fixed explicit `hub_links` vs `shop_orders` separation
  - kept Hub manager and commerce reporting as different admin domains
  - added an architecture lock for the split

## Cycle 98 — legacy cleanup wave 2
- Case: финальная выборочная зачистка stale locale/runtime traces после
  alias waves и reporting hardening.
- Outcome: active runtime больше не зависит от shop-named locale keys;
  остались только подтверждённые compatibility/history traces.

## Cycle 99 — final release audit
- Case: финальный релизный аудит серии Hub выявил и устранил
  syntax-ошибку в `backend/app/bot/texts.py`.
- Outcome: release gates подтверждены по compileall, checked-in OpenAPI
  snapshot, guard-pack и clean FLAT ZIP.

## Cycle 100 — release stabilization and handoff
- Case: финальная стабилизация серии Hub 61–100 завершена
  handoff-документом и closure-фиксацией.
- Outcome: серия закрыта, итоговое состояние и ограничения среды
  зафиксированы явно.

## Cycle 101 — log-driven fixes and 101–110 plan
- Case: first post-handoff cycle switched from series closure to fresh
  CI-log remediation.
- Outcome: log-driven defects addressed and a new governance/parity
  roadmap 101–110 created.

## Cycle 102 — full CI parity wave (partial)
- Case: log-driven remediation for `logs_62451337893.zip`.
- Outcome: original log blockers fixed; cycle remains open because local
  full pytest exposed additional non-log drift.

## Cycle 102 continuation
- Case extension: user required alias sunset after transition end and
  squash of 0002 into 0001 for first install path.

## Cycle 102 — docs/route-count continuation
- Case: full parity continued with counts/freeze repair after previous
  log and alias waves.
- Outcome: docs/route-count cluster healed; full pytest residual reduced
  to 27 failures.

## 2026-03-29 — cycle 102 closure
- Подтверждено: полный `pytest -q` на HEAD зелёный: 275 passed, 25
  skipped.
- Закрыт cycle 102 как full CI parity wave.
- Сняты legacy alias expectations в tests/docs после фактического sunset
  `/shop` и `/admin_shop` в active bot/page/help слое.
- Нормализованы `atlas.json` и `casebook.json` под текущий schema guard.
- Синхронизированы FAQ/translation expectations с текущим HEAD.

## 2026-03-29 — cycle 103
- Восстановлен обязательный governance layer для FAQ.
- Добавлены FAQ approval register и approval manifest.
- Зафиксировано, что FAQ waves 79–82 обошли approval gate быстрее, чем
  он был восстановлен.
- Historical draft section 13 из cycle 77 оформлен как retroactive
  approval entry `FAQ-APPROVAL-0001`.

## 2026-03-29 — cycle 104
- Проведён прямой FAQ runtime vs SSOT parity audit.
- Подтверждено по 13 языкам: 20 sections, 250 Q/A, section 13 = Hub.
- Прямого parity drift, требующего rewrite в этом же цикле, не найдено.
- Зафиксировано правило пользователя: в текущем цикле делать максимально
  возможный объём подтверждаемой работы без искусственного переноса на
  следующий цикл.

## 2026-03-29 — cycle 105
- Generator FAQ runtime now validates approval manifest before rebuild.
- Added hardening for manifest count, entry fields, 20/250 inventory,
  and section 13 = Hub.
- Runtime `catalogs.ts` rebuilt with generated header and governance
  source marker.

## 2026-03-29 — cycle 106
- Bot/help layer synced with current FAQ state.
- Added direct `/faq` bot command and FAQ entry keyboard.
- RU/EN help texts now mention current FAQ inventory 20/250.

## 2026-03-29 — Cycle 107
- Archive: `v160_36`
- Issue: multilingual FAQ legal wording residuals in Hub-related
  answers.
- Action: audit completed; no rewrite without approval;
  FAQ-APPROVAL-0002 created as draft.

## 2026-03-30 — Cycle 126 — latent panel docs drift after approved RU
FAQ rewrite

- Symptom excerpt: после ранее утверждённого русского rewrite панели
  `docs/SSOT/faq_ssot/ru/faq_ru.*` уже содержали `Активация панели`, но
  `docs/SSOT/PANELS_SSOT.md` и `docs/SSOT/FAQ_SSOT.md` сохраняли stale
  user-facing wording `купить панель`, `цена панели` и `после покупки
  первой панели`.
- Applied fix: синхронизированы `docs/SSOT/PANELS_SSOT.md` и
  `docs/SSOT/FAQ_SSOT.md` с approved panel canon без runtime rebuild.
- Confirmation basis: direct audit and residual grep of
  `docs/SSOT/PANELS_SSOT.md`, `docs/SSOT/FAQ_SSOT.md`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`, and
  `docs/SSOT/faq_ssot/ru/faq_ru.json`.

- 2026-03-30: Cycle 127 — symptom: утверждённый code/log canon требовал
  `panel_activation`, но HEAD всё ещё содержал `reason="panel_purchase"`
  и admin aggregation только по legacy reason. Fix: backend write-path
  переведён на `panel_activation`, admin/report и history mapping стали
  dual-read для legacy + new reason.

- 2026-03-30: Cycle 128 — case note: собран draft-only multilingual
  package по panel-line; symptom массового runtime drift не лечился в
  этом cycle, а только подготовлен к следующей controlled rewrite wave.

- 2026-03-31: Cycle 129 — symptom: multilingual FAQ still contained
  panel commerce wording and runtime rebuild was blocked by
  `FAQ_APPROVAL_MANIFEST.json` count drift (`entries_total` !=
  len(entries)). Fix: panel-line rewritten in 12 languages, manifest
  count corrected, runtime `catalogs.ts` rebuilt from SSOT.

- 2026-03-31: Cycle 130 — symptom: after cycle 129, small residual
  panel-commerce traces still lived in active SSOT/runtime (RU/UK Activ
  answer, EN/PL/DA/ID panel wording). Fix: active SSOT cleaned,
  `catalogs.ts` rebuilt, residual set reduced to legacy/non-runtime and
  technical layers only.

- 2026-03-31: Cycle 131 — backend audit note: `/panels/buy/{global_id}`,
  `buy_panel`, `purchase_panel`, `on_user_first_panel_purchase` and
  related comments remain as compatibility anchors of the current
  release line; refactor must be separated from active user-facing
  cleanup.

- 2026-03-31: Cycles 132-135 — safe panel wording refactor: route
  summary/docstrings/frontend local naming/API docs switched to
  activation wording; compatibility anchors `/panels/buy`, `buy_panel`,
  `purchase_panel`, `on_user_first_panel_purchase`, `panels.buy_*`
  intentionally retained.

- 2026-03-31: Cycle 136 — parity note: active panels backend/frontend
  flow already matched activation canon; the only remaining active drift
  was the admin overview spend block without PB5-3 split visibility.
- 2026-03-31: Cycles 137-140 — symptom: admin overview exposed only one
  ambiguous panel spend fact although ledger data already contained
  main/bonus split. Fix: backend overview query extended to
  total/main/bonus, admin home and admin reports switched to approved
  PB5-3 labels and order.

- 2026-03-31: Cycle 141 — symptom: archive still contained a separate
  stale Russian FAQ tree in `frontend/src/data/faq/ru.ts` even though
  active runtime used generated `catalogs.ts`. Fix path prepared through
  compatibility aliasing.
- 2026-03-31: Cycle 142 — fix applied: `frontend/src/data/faq/ru.ts` now
  aliases generated `faqCatalogByLang.ru`; stale standalone tree
  removed. Additional cleanup: `frontend/src/data/faq/meta.ts` no longer
  exposes French section 13 as `Boutique`.
- 2026-03-31: Cycles 143-144 — audit/refactor note: internal panel
  naming cleanup was limited to comments/docstrings/examples in backend;
  route path `/panels/buy` and aliases `purchase_panel` /
  `on_user_first_panel_purchase` remain preserved compatibility anchors.
- 2026-03-31: Cycle 145 — release audit note: panel series 129-145 is
  now directly traceable in code/docs/archive state without hidden FAQ
  rewrites.

- 2026-03-31: Cycle 146 — symptom: archive still contained internal
  aliases that no longer had a necessary compatibility role. Audit
  isolated `etag`, `purchase_panel`, and `on_user_first_panel_purchase`
  as removable.
- 2026-03-31: Cycle 147 — fix: removed the three safe aliases and
  repaired direct callers/tests to canonical names `make_etag` and
  `on_user_first_panel_activation`.
- 2026-03-31: Cycle 148 — route repair: backend previously exposed only
  compatibility panel activation path `/panels/buy/{global_id}`. Fix:
  canonical `POST /panels/activate/{global_id}` added and frontend switched
  to it, while `/buy` stayed as wrapper.
- 2026-03-31: Cycle 149 — migration note: direct archive audit of
  `0001_init.py` and `0002_create_hub_links.py` found no new active
  migration gap; this is a static conclusion, not a live DB run.
- 2026-03-31: Cycle 150 — release audit note: archive, cycles register,
  alias docs and panel route docs are now aligned for series 146-150.


Cycle 151/152 note: direct audit of HEAD v161_10 confirmed that public
`/shop/*` and admin `/admin/shop/*` no longer have active frontend/bot
callers; they remain backend compatibility surfaces pending future
contract-migration waves.


Cycle 153–160 note: direct audit of HEAD v161_11 confirmed canonical
panels activation route drift in SSOT/OpenAPI, refreshed route
inventories to 89 active routes, added new architecture locks, and
closed `/shop/*` + `/admin/shop/*` removal as hard-freeze rather than
unsafe contract deletion.


Cycle 161 planning note: post-160 archive audit shows the remaining work
is centered on proof gaps (live migrations, fresh logs) and
compatibility-contract decisions rather than hidden runtime breakage.


Cycle 161–165 note: current remaining work shifted from alias-caller
cleanup to archival marking, migration proof readiness, and explicit
contract decisions for backend commerce compatibility routes.


Cycle 166–170 note: current post-160 series now has explicit freeze
implementation for shop/admin contracts, explicit freeze for panels
compat path, deterministic route-doc regeneration helper, and a closed
archive-vs-chat-vs-logs parity audit.


Cycle 171–175 note: direct audit confirmed an active wording drift
rather than a historical-only drift; locale keys used by
Hub/wallet/settings and one live backend docstring were synchronized and
then locked by tests.

- 2026-03-31: Case 176 closed after fixing route helper syntax, docs
  counters, tests catalog, historical compatibility docs/files and
  outdated locks.

- 2026-03-31: Historical blocker case 164 closed on the basis of CI log
  proof from logs_62803948808.zip.

- 2026-03-31: Case 177-180 closed after 13-language audit and first
  translation sync wave.

- 2026-03-31: Case 181-182 closed after manual high-traffic translations
  for Profile and Wallet layers.

- 2026-03-31: Case 183-185 closed after manual high-traffic translations
  for Panels, Exchange+Energy and Tasks+Referrals layers.

- 2026-03-31: Case 186-187 closed after manual high-traffic translations
  for History+Withdraw and Ranks+Prizes layers.

- 2026-03-31: Case 188-189 closed after common/balances sync and full
  prizes/tournaments audit.

- 2026-03-31: Case closeout — `prizes/tournaments` decommission tail
  removed from active archive layers.

- 2026-03-31: Case note — high-traffic `hub.*` and `faq.*` shell drift
  removed manually across non-RU/non-EN locales.

- 2026-03-31: Case note — remaining public i18n debt no longer
  dominates; current long-tail shifted to admin locale namespace and
  first two manual admin waves are completed.

- 2026-03-31: Case note — overview layer fixed current pages inventory;
  migration wording затем был отдельно дожат в cycle 197 до strict `0001
  only`.

- 2026-03-31: Case note — unexpected 0002 file in HEAD removed;
  migration canon reset to single-base 0001.

- 2026-03-31: Case note — cycle 198 used point updates in existing canon
  docs instead of spinning up another standalone migration memo.

- 2026-03-31: Case note — cycle 199 normalized recent registry/report
  tails without spawning extra canon docs.

- 2026-03-31: Case note — cycle 200 finished archive-docs closeout by
  clarifying historical vs active truth in existing docs.

- 2026-03-31: Cycle 201 — в реестр добавлены 15 уточняющих вопросов по
  полной ревизии документации архива; дальнейшая работа должна идти по
  полному списку документов с пофайловым согласованием действий `удалить
  / объединить / актуализировать`.

- 2026-03-31: Cycle 202 — построен полный master-index документации
  архива; audit-документы и лог-аудиты перенесены в `docs/history/legacy_artifacts/docs/audits/`,
  `docs/history/legacy_artifacts/reports/` оставлен вне текущего ручного обзора.

- 2026-03-31: Cycle 203 — зафиксированы решения пользователя по первой
  пятёрке документов; выполнено объединение legacy root
  `ARCHITECTURAL_LOCKS`, перенос `CHANGELOG` в `docs/history/legacy_artifacts/reports/`, перенос
  `CODE_OF_CONDUCT` в `artifacts/` и актуализация `CONTRIBUTING`.

- 2026-03-31: Cycle 204 — повторный audit чата и стартовых правил
  завершён; подготовлен обновлённый полный промт продолжения в новом
  чате с фиксацией документной фазы и точки продолжения по master-index.

- 2026-04-01: Cycle 205 — документная ревизия продолжена по решениям
  пользователя: `README.md` актуализирован, `REPORT_COMMANDS.txt`
  перемещён в `artifacts/misc/`, `SECURITY.md` расширен; дополнительно
  зафиксировано правило, что `artifacts/` не проверяется в пакетах
  ревизии как архивная корзина.

- 2026-04-01: Cycle 206 — мягко актуализированы
  migration/OpenAPI/requirements слои по прямому аудиту HEAD; текущий
  миграционный канон для первого релиза зафиксирован как `0001 only`,
  checked-in OpenAPI snapshot оставлен в active слое с обновлённым
  audit-note, а `backend/requirements.txt` дополнен недостающими
  зависимостями `PyJWT`, `cryptography` и `PyYAML`, которые используются
  в текущем архиве.

- 2026-04-01: Cycle 207 — `docker-compose.yml` мягко актуализирован по
  текущему Docker/archive layer;
  `docs/ACTIVE_WORDING_GUARDS_WAVE_2026_03_31.md` выведен в
  `artifacts/docs/`; `docs/GENERAL/ADMIN_PANEL_SPEC.md` объединён с
  более полным описанием админ-панели; `docs/NORM/ADMIN_RBAC.md`
  сохранён как active NORM и мягко актуализирован без ослабления
  ролевого канона.

- 2026-04-01: Cycle 208 — semantic boundary из
  `docs/ADMIN_REPORTING_HUB_HARDENING.md` интегрирована в
  `docs/GENERAL/ADMIN_PANEL_SPEC.md`, а сам файл выведен в
  `artifacts/docs/`; ADR 0001/0002/0003 и
  `docs/AI/AI_OPERATOR_RULES_EFHC.md` мягко актуализированы по текущему
  HEAD и текущему prompt-режиму документной фазы.

- 2026-04-01: Cycle 209 — `docs/API_REFERENCE.md` объединён с
  `docs/NORM/API_CONTRACTS.md` и выведен в `artifacts/docs/`;
  `docs/AI/AI_RESILIENCE_CANON.md`, `docs/NORM/API_CONTRACTS.md`,
  `docs/NORM/ARCHITECTURAL_LOCKS.md` и
  `docs/GENERAL/ARCHITECTURE_DEPENDENCIES_RU.md` актуализированы по
  текущему HEAD и document-phase rules.

- 2026-04-01: Cycle 210 — три wave/plan документа сведены по смыслу в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md` и выведены в `artifacts/docs/`;
  `docs/GENERAL/ARCHIVE_NAV_INDEX.md` мягко актуализирован;
  `docs/NORM/TASKS_STANDARD.md` признан достаточно сильным для NORM-слоя
  и добавлен в `docs/SSOT/SSOT_INDEX.md`.

- 2026-04-01: Cycle 211 — `docs/BACKGROUND_TASKS_STANDARD.md`
  переименован в `docs/NORM/TASKS_STANDARD.md`; связанные active реестры
  и индексы синхронизированы с новым путём.

- 2026-04-01: Cycle 212 — `docs/SSOT/BANK_CANON.md` проверен против
  bank/economy SSOT и добавлен в NORM через `docs/SSOT/SSOT_INDEX.md`;
  `docs/BOT_PAGES_INVENTORY_2026_03_31.md` перенесён в `docs/history/legacy_artifacts/docs/audits/`;
  `docs/BOT_WEBAPP_ENTRYPOINT_STABILIZATION.md`,
  `docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml` и
  `docs/CODE_CLEANUP_AND_IMPROVEMENT_10_CYCLES_PLAN.md` выведены из
  active слоя; в `docs/AI/AI_OPERATOR_RULES_EFHC.md` добавлен
  обязательный формат `цикл X/Y завершён`.

- 2026-04-01: Cycle 213 — `docs/GENERAL/DOCKER_LOCAL.md` синхронизирован
  с текущим Docker layer; `docs/SSOT/DTO_INPUT_CANON.md` повышен до NORM
  через `docs/SSOT/SSOT_INDEX.md`; `docs/SSOT/EFHC_CANON.md` мягко
  вычищен по подтверждённой точке drift; `docs/SSOT/ENERGY_RULES.md`
  дополнен явной связью с exchange/available_kwh SSOT;
  `docs/NORM/ERROR_CODES.md` дополнен кодами `WALLET_REQUIRED` и
  `HUB_HANDOFF_NOT_CONNECTED`.

- 2026-04-01: Cycle 214 — `EVENTS_MATRIX.md` оставлен как active NORM и
  получил compat-оговорку для panel technical naming;
  `EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` дополнен cross-reference слоем;
  `FAQ_APPROVAL_GOVERNANCE.md` и `FAQ_CODE_GENERATION_HARDENING.md`
  мягко актуализированы по current HEAD; `FAQ_BOT_HELP_PARITY_WAVE.md`
  выведен в `artifacts/docs/`.
- 2026-04-01: Cycle 215 — FAQ helper/rewrite/freeze документы убраны из
  active docs слоя: `FAQ_COVERAGE_MATRIX.md` переведён в
  `artifacts/docs/`, а `FAQ_EXCHANGE_RU_REWRITE_WAVE1.md`,
  `FAQ_FORBIDDEN_WORDING_RU_REWRITE_WAVE1.md`,
  `FAQ_HUB_RU_REWRITE_WAVE1.md` и `FAQ_INVENTORY_FREEZE.csv` переведены
  в `docs/history/legacy_artifacts/docs/audits/`.
- 2026-04-01: Cycle 216 — `FAQ_INVENTORY_FREEZE.md` переведён в
  `docs/history/legacy_artifacts/docs/audits/`; `FAQ_MULTILINGUAL_LEGAL_WORDING_DRAFT.md`,
  `FAQ_PANELS_BOT_UI_RU_REWRITE_WAVE1.md`,
  `FAQ_PANELS_RATES_RU_DRAFT.md` и `FAQ_PANELS_RU_REWRITE_WAVE1.md`
  выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 217 — `FAQ_REPLACEMENT_LEDGER.md` актуализирован и
  переведён в `docs/history/legacy_artifacts/docs/audits/`; `FAQ_SSOT.md` мягко актуализирован;
  `FAQ_TOPBAR_RU_REWRITE_WAVE1.md`, `FAQ_VIP_RU_REWRITE_WAVE1.md` и
  `FAQ_WALLET_RU_REWRITE_WAVE1.md` выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 218 — `FRONTEND_ACTIVE_LOCALE_SYNC_2026_03_31.md`,
  `HUB_ADMIN_ENTITY_DESIGN.md` и `HUB_ADMIN_MIGRATION_MODEL_WAVE.md`
  переведены в `docs/history/legacy_artifacts/docs/audits/`; important pressure-test context перенесён
  в `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`; `HUB_ALIAS_PRESSURE_TEST.md` и
  `HUB_ALIAS_REMOVAL_WAVE2.md` выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 219 — смысл `HUB_CYCLES_91_100_PLAN.md` сведен в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`;
  `HUB_EFHC_HANDOFF_IMPLEMENTATION_WAVE1.md`,
  `HUB_FAQ_SECTION_13_RU_DRAFT.md` и `HUB_FINAL_ALIAS_REMOVAL_DESIGN.md`
  переведены в `docs/history/legacy_artifacts/docs/audits/`; `HUB_FINAL_ALIAS_REMOVAL_WAVE1.md`
  выведен в `artifacts/docs/`.
- 2026-04-01: Cycle 220 — смысл
  `HUB_FINAL_COMMERCE_CLEANUP_RELEASE_STABILIZATION.md` сведен в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`; `HUB_GUARDS_REGRESSION_PACK.md`,
  `HUB_SERIES_61_100_FINAL_HANDOFF.md` и
  `I18N_ADMIN_VERIFICATION_2026_03_31.md` переведены в `docs/history/legacy_artifacts/docs/audits/`;
  `HUB_SSOT.md` мягко актуализирован.
- 2026-04-01: Cycle 221 — historical i18n wave-docs
  (`I18N_ADMIN_WAVE1_2026_03_31.md`, `I18N_ADMIN_WAVE2_2026_03_31.md`,
  `I18N_COMMON_BALANCES_WAVE1_2026_03_31.md`,
  `I18N_EXCHANGE_ENERGY_WAVE1_2026_03_31.md`,
  `I18N_HISTORY_WITHDRAW_WAVE1_2026_03_31.md`) выведены из active docs
  слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 222 — historical i18n Hub/matrix/plan/wave документы
  (`I18N_HUB_FAQ_WAVE2_2026_03_31.md`,
  `I18N_MISSING_KEY_MATRIX_2026_03_31.md`,
  `I18N_MISSING_TRANSLATIONS_PLAN_191_195.md`,
  `I18N_PANELS_WAVE1_2026_03_31.md`, `I18N_PROFILE_WAVE1_2026_03_31.md`)
  выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Cycle 223 — `I18N_SYNC_PLAN_181_190.md`,
  `I18N_TASKS_REFERRALS_WAVE1_2026_03_31.md`,
  `I18N_WALLET_WAVE1_2026_03_31.md`, `LEGACY_CLEANUP_WAVE2.md`,
  `LEGACY_FRONTEND_FAQ_SOURCES_CLEANUP_2026_03_31.md` выведены из active
  docs слоя в `artifacts/docs/`; исторически важные выводы двух legacy
  cleanup документов сохранены в `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`.
- 2026-04-01: Cycle 224 — historical смысл
  `LIVE_ALEMBIC_PROOF_BLOCKER_2026_03_31.md` и
  `LOTTERIES_DECOMMISSION_CYCLES.md` сохранён в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`; master-index очищен от слоя
  `artifacts/`; `MIGRATION_INVARIANTS_HARDENING.md` актуализирован и
  переведён в NORM.
- 2026-04-01: Cycle 225 — historical смысл
  `MIGRATION_RESET_TO_0001_2026_03_31.md`,
  `OBSERVABILITY_METRICS_PLAN.md` и
  `OPENAPI_RELEASE_DOCS_FREEZE_2026_03_31.md` сохранён в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`/active docs;
  `MODEL_TABLE_ROUTE_TEST_MAP.md` актуализирован и переведён в NORM;
  `MODULES_DEPENDENCIES.md` мягко актуализирован по current HEAD.
- 2026-04-01: Cycle 226 — важный смысл
  `OVERVIEW_DOCS_REFRESH_2026_03_31.md`,
  `PANELS_ADMIN_COUNTERS_DESIGN_2026_03_31.md`,
  `PANELS_API_WORDING_SYNC_2026_03_31.md` сохранён в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`; summary-данные `OVERVIEW_SSOT_SYNC.md` и
  panels approval package absorbed by active NORM/SSOT docs; standalone
  files выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 227 — важный panels compatibility смысл absorbed by
  `docs/SSOT/PANELS_SSOT.md` and `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`;
  standalone panels draft/sync/freeze docs выведены в `artifacts/docs/`.
- 2026-04-01: Cycle 228 — panels/project/release pack cleaned;
  historical notes absorbed by `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`,
  `README.md`, `docs/GENERAL/architecture.md`;
  `QUESTIONS_AND_ANSWERS_REGISTER.md` and `RANKS_RULES.md` promoted to
  NORM.
- 2026-04-01: Cycle 229 — referral canon and routes/migrations playbook
  promoted to NORM; release hygiene and old repair plan absorbed into
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`; `ROUTE_INVENTORY_FREEZE.md` left pending
  separate decision as a freeze snapshot rather than current live
  inventory.

## work pass case note
- Case: свежий CI-log показал mixed wave: flake8, ruff, bandit, npm
  build, pytest.
- Treatment: manual targeted edits without mass refactor.
- Result: subset verification improved; waiting for fresh CI proof for
  full closure.

## work pass case note
- Fresh CI after work pass exposed second-order drift:
  duplicate/import-order issues in tests after manual header edits.
- Treatment remained manual and partial; further wave required.

## work pass case note
- Second-order ruff drift after work pass was closed on targeted subset.
- Fresh CI log required for the next factual blocker set.

## work pass case note
- Gate summary isolated pytest as the only failing step.
- Root cause narrowed to async-marking drift in panel tests after
  previous cleanup wave.
- Manual treatment applied; new CI proof required.

## work pass case note
- Fresh CI proof finally closed the log-fix wave 331-334.
- This is a factual green state, not an assumed one.

- 2026-04-05: повторно зафиксирована Healer-болезнь AI-layer — попытка
  вынести active cycle queue / plan в новый отдельный документ вместо
  ведения единственного канонического журнала
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`.
  Новый жёсткий запрет закреплён в `docs/AI/AI_OPERATOR_RULES_EFHC.md`
  и `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`:
  нельзя создавать cycle-plan / cycle-status / cycle-register /
  wave-plan документы для active cycles.


## 2026-04-08 — case: release blockers wave 1
- Symptom: withdraw cancel was present in UI/API expectations but broken
  at
  runtime by a route/service signature mismatch.
- Treatment: align signatures, keep replay-safe repeated cancel
  semantics, add a
  dedicated `/withdraw` journey, and de-live `sale-packages` from the
  main admin
  release surface.
- Evidence: current HEAD contains service fix, new `/withdraw` page,
  exchange /
  profile entrypoints, and sale-packages removed from main admin index.


## 2026-04-08 — case: release hardening wave 2
- Symptom: even after de-living `sale-packages` in frontend, backend
  mutating
  routes still created a false writable surface; operator-sensitive
  actions also
  remained too close to one-click execution.
- Treatment: switch `sale-packages` mutating routes to explicit `409`
  non-release
  mode and add confirmation steps with context blocks in withdrawals and
  bank.


## 2026-04-08 — case: operator workflow wave 3
- Symptom: EFHC deposit processing still lived as a raw action on admin
  index,
  while referrals manual actions lacked an explicit effect-preview
  layer.
- Treatment: build a dedicated `/admin/efhc-deposits` workflow and add
  preview /
  reason safeguards to referral manual actions.


## 2026-04-08 — case: deposit status wave 4
- Symptom: Mini App deposit created a payment intent and sent TonConnect
  transaction, but the modal still left the user without a closed
  status/result loop.
- Treatment: add intent status block, restore the last active intent on
  reopen, and block duplicate active intent creation.
- Evidence: current HEAD deposit modal now polls owner-only
  `/payment-intents/{intent_id}` and keeps the user inside a visible
  deposit-status path.


## 2026-04-08 — case: external shop prep wave 5
- Symptom: browser-shop was alive as MVP storefront, but the release
  framing and storefront-intent UX were still too weak to describe it as
  a full external shop release.
- Treatment: strengthen release framing, add step-by-step guidance,
  restore the last storefront intent on repeat entry, and block
  duplicate active intent creation.
- Evidence: current HEAD browser-shop page now keeps a clearer
  handoff/wallet/intent/status path and stays honest about its MVP
  release stage.


## 2026-04-08 — case: external shop release wave 6
- Symptom: browser-shop architecture and release stage could still be
  misunderstood as a fully separate frontend app or as a fully finished
  release storefront.
- Treatment: record an explicit release matrix, strengthen storefront
  shell/readiness UI, add payment-detail warnings, and expose a visible
  terminal return path.
- Evidence: current HEAD now states the shared backend/admin truth model
  more clearly and improves the payment/result path in the browser-shop
  surface.


## 2026-04-08 — case: shopfront access module wave 7
- Symptom: external storefront access flow still lived mostly inside hub
  semantics and did not yet look like a dedicated bot-entry + separate
  internet page model.
- Treatment: add a dedicated `/shopfront/*` route namespace, a
  Telegram-side `/shop` entry module, and document the correct
  signed-access architecture.
- Evidence: current HEAD now separates shopfront
  access/bootstrap/catalog/create-intent/status routes and provides a
  direct bot-side entry for opening the external storefront.


## 2026-04-08 — case: storefront wallet preload wave 8
- Symptom: external storefront entry already knew Telegram identity, but
  bootstrap still exposed mostly only a single active wallet address
  instead of the full linked-wallet context.
- Treatment: expand bootstrap schema with wallet preload and render
  linked wallets directly in the storefront shell.
- Evidence: current HEAD storefront bootstrap now returns wallet
  bindings and the browser-shop page displays them immediately after
  access.


## 2026-04-08 — case: web portal future entry wave 9
- Symptom: the separate external page was already technically useful,
  but still framed too narrowly as a storefront instead of a
  future-capable portal surface.
- Treatment: expand the bootstrap contract and portal shell so the page
  can honestly evolve toward full web entry later.
- Evidence: current HEAD now exposes access mode, available modules and
  future game-entry state in the external portal bootstrap/UI.


## 2026-04-08 — case: independent user id optional track
- Symptom: future autonomy from Telegram suggested an internal
  `user_id`, but the immediate need became ambiguous once the user
  clarified that the site may still continue logging in through Telegram
  external binding.
- Treatment: open a 20-cycle plan as an optional migration track instead
  of forcing it into the current must-fix queue.
- Evidence: current HEAD records the full 551-570 plan while explicitly
  marking it as optional, not immediate.


## 2026-04-08 — case: web profile wave 10
- Symptom: the portal/storefront already existed, but users still lacked
  a dedicated standalone web profile surface with Telegram-linked
  identity, wallets and purchases.
- Treatment: add `/shopfront/profile`, a dedicated `/web-profile` page
  and a direct portal entry into that profile.
- Evidence: current HEAD now provides a separate web profile page backed
  by the same Telegram-linked truth-layer.


## 2026-04-08 — case: web portal visual wave 11
- Symptom: the external entry, portal and web profile were already
  functional, but still looked too much like separate technical screens.
- Treatment: add hero framing and compact summary blocks to create a
  more unified external product surface.
- Evidence: current HEAD entry, portal and profile now share a clearer
  and more polished visual rhythm.


## 2026-04-08 — case: frontend stitching wave 13
- Symptom: even after portal/profile/web waves, the external surfaces
  still felt too parallel and insufficiently stitched together.
- Treatment: add clearer cross-navigation, explicit usage wording and
  route-ownership notes.
- Evidence: current HEAD portal and web profile now point to each other
  more directly and explain their roles more clearly.

## 2026-04-08 portal/profile localization drift wave

- External portal surfaces must use `useT()` and locale dictionaries
  instead of direct hardcoded wording.
- Sandbox/donor code may be inspected, but portal/frontend waves must
  not blindly transplant external code into HEAD.

## 2026-04-08 admin module-state truth wave

- Admin surfaces that are helper or draft must say so visually;
  otherwise they create a false-ready operator illusion.
- Sandbox must remain a donor/reference layer; importing external
  admin/shop patterns blindly into HEAD is prohibited.

## 2026-04-08 sandbox donor primitives wave

- Sandbox is most useful as a donor of reusable surface primitives (hero
  sections, badge grouping, page rhythm), not as a source of blind
  application imports.
- Shared portal/profile/storefront visual grammar should be extracted
  into EFHC-native components before any future broad web/admin
  redesign.

## 2026-04-08 admin foundation donor stage

- For the upcoming full admin-panel work, sandbox donors are valuable
  mainly for shell hierarchy, KPI cards and data-heavy admin
  composition.
- Full foreign dashboard stacks must not be transplanted blindly; EFHC
  needs its own admin shell primitives first.

## 2026-04-08 admin home grouping wave

- A future full admin panel should not stay a flat list of modules; it
  needs grouped finance / people / system sections and KPI-first
  overview surfaces.
- Horizon-style dashboard composition and Refine-style resource grouping
  can be translated into EFHC-native primitives without importing
  foreign stacks.

## 2026-04-08 admin financial data blocks wave

- A future full admin panel must spread its shell into financial
  operator pages, not stay concentrated only on admin home.
- Bank and withdrawals are the first priority pages for KPI/data-block
  hardening because they are sensitive and statistics-heavy.

- 2026-04-08 — admin panel surfaces wave 19: users/docs/history/legacy_artifacts/reports/logs aligned
  with new dashboard shell; next expansion block 631-640 planned from
  sandbox donor audit.

- 2026-04-08 — admin panel expansion wave 20: reusable admin shells and
  segmented dashboard grammar introduced for next-stage
  settings/statistics growth.

- 2026-04-08 — admin/shop usability wave 21: reusable admin shells
  expanded and browser shop moved to searchable/filterable product-card
  workflow.

- 2026-04-08 — admin/shop usability wave 22: reports analytics slice
  improved, admin shop clarified, browser shop moved to
  searchable/filterable product-card flow.

- 2026-04-08 — admin shop editor wave 23: product-card selection,
  dual-price editor shell, visibility control and preview stage
  introduced.

- 2026-04-08 — admin shop editor wave 24: catalog selection, dual-price
  editor and preview stage added through admin panel.

- 2026-04-08 — admin operator tails wave 25: stats, emission, correction
  and logs surfaces strengthened after explicit chat-tail audit.

## 2026-04-09 — case: admin shop status inventory wave 29
- Symptom: admin shop could edit and create cards, but had no separate
  status action, weak inventory control and no honest archive semantics.
- Treatment: add dedicated status route, map archive to `draft`, add
  status counters, filters, sort modes and quick status actions in the
  editor.
- Evidence: current HEAD now allows `live/hidden/draft` changes without
  full content rewrite and surfaces status inventory directly in
  `/admin/shop`.

- 2026-04-09 — log healing wave: removed stale shop alias, fixed admin
  shop idempotency drift, restored browser-shop MVP lock texts, fixed
  admin TSX blockers.

- 2026-04-09 — Healer case: chronic Next.js downgrade drift. Rule: no
  downgrade below 14.2.35 in frontend package.json/package-lock; guard
  test added.

## 2026-04-11 — case: work pass residual CI tail
- Symptom: after the first 850 pass, fresh logs still showed mixed
  residual defects across reconciliation, typing, generated admin seam
  types and Alembic bootstrap import pressure.
- Treatment: continue the same 850 tail, fix the deterministic code
  defects, and keep final closure gated by a new GitHub CI run from the
  user.
- Evidence: current HEAD now aligns reconciliation guard reasons,
  removes the Bandit pass-through branch, repairs the watcher/wallet
  result bridge, fixes the referral seam alias and tightens 0001 model
  import behavior.

## 2026-04-11 — case: work pass compatibility/doc-sync tail
- Symptom: after the first residual log-fix wave, fresh CI still exposed
  compatibility regressions in watcher parsing, legacy shop confirm path
  and derived doc inventories.
- Treatment: continue the same active cycle, restore compatibility
  bridges, resync derived SSOT docs, and keep final closure gated by
  fresh GitHub CI.
- Evidence: current HEAD now restores watcher guard markers, accepts
  legacy USDT substring payload parsing, supports legacy
  empty-order-extra confirm flow, and aligns migration/route inventory
  docs with current SSOT counts.
## 2026-04-11 — work pass logo canon and audit metadata tail
- Runtime logo defects were healed by replacing derivative PNG work with
  a single approved SVG source of truth plus deterministic PNG
  regeneration.
- Route inventory freeze drift can be structural even when counts are
  correct: empty metadata cells and missing status note are enough to
  break the audit guard layer.

## 2026-04-11 — work pass archive-diff and canon-sync tail
- A user-approved canon answer converted the 35-vs-36 table dispute into
  an ordinary stale guard fix.
- Silent deletion claims must always be checked by archive diff, not by
  impression.

## 2026-04-11 — case: work pass watcher/shop compat and line72 scope
tail
- Symptom: fresh CI still reported `amount_guard` failure, USDT watcher
  confirmations fell into `pending_manual`, and `/admin/shop` used an
  outdated idempotency helper signature.
- Treatment: restore correct reconciliation guard flow, add a
  backward-compatible watcher fallback for older
  `_confirm_payment_intent` call shapes, fix the admin shop call site
  and keep reducing line72 without pretending the cycle is closed.
- Evidence: current HEAD removes the `amount_guard` use-before-def
  regression, preserves the required watcher marker string, fixes the
  admin shop idempotency call and lowers the line72 residual count from
  115 to 102 in a local recount.

## 2026-04-11 — case: work pass glossary and transport-env tail
- Symptom: fresh CI still showed watcher USDT transport drift, admin
  shop type drift on category pills, and the glossary was still missing
  many approved control/payment/frontend terms.
- Treatment: teach transport env resolution to fall back to runtime
  settings, align the admin shop call site with the current
  category-pills contract, and extend the glossary only with the
  explicitly approved terms.
- Evidence: current HEAD now resolves watcher transport config through
  env-or-settings, uses `activeId/onSelect` in `/admin/shop`, and
  contains the approved new glossary block with English and Russian
  paired forms.

## 2026-04-11 — case: work pass line72 front-slice tail
- Symptom: after the glossary and transport fixes, fresh CI still
  concentrated the line72 failures inside
  `audit_final_release_gate.py` and `frontend/src/features/**`, and
  `/admin/shop` exposed another small UI prop drift on `Button`.
- Treatment: clear the heaviest confirmed line72 files first, remove the
  unsupported UI prop, and keep the remaining tail mapped honestly
  instead of pretending the cycle is closed.
- Evidence: current HEAD reduces the local line72 residual count from 92
  to 66 and removes the confirmed `/admin/shop` button-prop blocker.

- 2026-04-11 — Case: core cycle/process terms were misinterpreted too
  loosely by the assistant. Treatment: replace glossary text with exact
  user definitions and treat future meaning drift as a continuity
  defect.

- 2026-04-11 — Case: line72 tail migrated after prior frontend cleanup.
  Treatment: follow the fresh GitHub CI list, clear backend/ops/exchange
  leftovers in one blitz pass, keep work pass open until new CI proof.

- 2026-04-11 — Case: user tightened the test-edit process. Treatment: AI
  docs now forbid test changes without a separate iteration and 5
  clarifying questions per test.

- 2026-04-11 — Case: the user clarified the test-edit boundary.
  Treatment: AI docs now separate logic-changing test rewrites from
  allowed technical fixture/data compatibility fixes.

- 2026-04-11 — Case: frontend local task catalog type missed `id`, but
  the page and backend schema already relied on it. Treatment: align
  local page type with backend schema instead of rewriting page logic.

- 2026-04-11 — Case: after fixing `TaskCatalogItem.id`, the next local
  page type tail surfaced in the same file. Treatment: add optional
  `next_available_at` without changing the task flow logic.

- 2026-04-11 — Case: after code/runtime tails were cleared, CI stopped
  only on import-order hygiene. Treatment: normalize imports, remove
  unused watcher alias and avoid `E402` in the blitz runner by using
  local imports after `sys.path` bootstrap.

## 2026-04-11 — work pass ruff tail regression repair
- Import-hygiene repairs in watcher-facing modules must be checked
  against both lint expectations and source-marker tests before closure;
  compatibility aliases removed as "unused" may still be part of the
  project canon.

## 2026-04-11 — work pass `_RE_INTENT` source-marker repair
- Lint auto-fixes can silently collapse alias-based compatibility
  markers; when tests assert literal source markers, preserve them as
  explicit assignments in the module body.

## 2026-04-11 — work pass consolidated system-errors register
- Reconciliation drift repeated as a defect family, not a one-off bug:
  guard reason swaps and amount-path regressions can recur when
  confirm-path code is tightened without replaying the exact CI tails.
- Watcher drift proved multi-layered: transport parsing, legacy
  monkeypatch signatures, source-marker assertions and credit bridge
  aliases all belong to one canon-sensitive subsystem and must be healed
  together.
- Frontend failures during 850 were mostly schema/type synchronization
  defects, not product logic defects; this family should be treated as
  contract drift between page-local types, generated seams and backend
  schemas.
- line72 and `ruff` tails were not cosmetic noise: they repeatedly
  masked fresh residuals and even created regressions when hygiene
  cleanup removed canon markers.
- Test-layer failures during 850 split into two classes: allowed
  technical fixture/setup compatibility fixes and separately governed
  logic-changing rewrites. This distinction is now part of the healer
  memory and AI rules.
- Document drift during 850 was a systemic disease: stale counts, stale
  route inventories, missing metadata and loose glossary meanings must
  be treated as first-class sync defects alongside code errors.
- Archive hygiene is also a healer concern: nested ZIP artifacts and
  silent-removal suspicion require explicit archive diff and clean
  rebuild discipline.

## 2026-04-11 — work pass sterile closure
- Fresh GitHub CI evidence showed all gates green; work pass is now
  recorded as closed, and any future defect belongs to a new range or a
  separately justified continuity tail.

## 2026-04-11 — post-850 audit transition
- After sterile closure of work pass, the next work block is driven by
  release-readiness audit findings rather than CI breakage. The primary
  targets are truthful withdraw completion semantics, hub/storefront E2E
  closure, unified wallet/deposit UX and explicit helper/draft
  separation.

## 2026-04-11 — work pass audit-answers sync
- The new release-hardening block starts with a corrected truth model:
  admin withdraw proof is defined by the Send action in the wallet, not
  by pretending the operator can control the later blockchain delivery
  path.

## 2026-04-11 — admin tasks split-strength clarification
- Admin tasks was misread as a weak module in general. The stronger and
  more exact reading is: backend task administration is already
  substantial, but the current admin UI still presents only a helper
  shell. The healing direction is operator-surface restoration, not
  domain demotion.

## 2026-04-11 — work pass withdraw send-proof implementation
- The withdraw action-chain has moved from pure doctrine into
  implementation: the approve path and wallet path now transmit explicit
  wallet-send proof metadata so the system can record what the operator
  actually did at payout time.

- 2026-04-11 v166_65: Money-Center UX fragmentation was reduced by
  linking wallet, balances, latest withdraw status and history in one
  profile surface; admin tasks operator paralysis was reduced by
  replacing helper-only shell with submissions moderation surface.

- 2026-04-11 v166_66: Money-Center continuity was deepened on
  `/withdraw`; moderation safety improved by replacing bare proof links
  with an expanded proof card for each submission.

- 2026-04-11 v166_67: closed-loop Money-Center healing added a
  deterministic return from `/withdraw` back into profile financial
  context, removing a trust-breaking dead-end after success actions.

- 2026-04-11 v166_68: moderation black-box risk reduced by storing
  moderator notes, adding fallback templates and exposing a global
  templates truth-layer for admin-managed responses.

- 2026-04-16 v166_69_70: work pass advanced — added
  `/hub/shop-truth`, surfaced active-intent resume semantics, and
  removed blind storefront entry behaviour from Hub/browser-shop.


## BROWSER_SHOP_PENDING_BADGE_OVERCONFIDENCE
- Symptom: storefront showed a raw pending-like status without
  explaining whether payment was seen, waiting for network, manual
  review or terminal retry state.
- Fix: backend `flow_truth` now exposes lifecycle stage, terminal
  marker, next step and watcher/order evidence; storefront and
  web-profile render it.


- 2026-04-16 v166_73_74: Web-profile account-center drift was reduced by
  surfacing recent intent history and Telegram withdraw shortcuts;
  DepositModal duplicate-state risk was reduced by converting it into a
  thin launcher over the existing Hub/browser-shop truth-path.


## 2026-04-16 — CI repair bundle after v166_73_74
- Trigger: fresh GitHub logs after the account-center / deposit-launcher
  pass.
- Symptoms: `F821 settings`, storefront build failure on missing
  `flow_truth` in generated seam, stale migration-count audit docs, and
  banned rank-substring leaks in active memory docs.
- Treatment: restore `get_settings()` use inside the hub route, sync
  generated TypeScript seam to backend schema, refresh migration-count
  docs to 37 tables, and neutralize forbidden legacy substrings in
  current memory/docs.
- Result: local lint, mypy, Next build and targeted architecture tests
  passed on the repaired HEAD.

## 2026-04-16 case — release-truth and generated-seam drift

- Симптомы: stale route-canon тест, stale schema-count heading, TS build
  failure from validator declaration order, line72 tails after UX copy
  hardening.
- Правильное лечение: не латать по одному месту, а синхронно обновлять
  tests + generated validators + docs headers + user-facing copy.

## 2026-04-16 case — QA matrix and glossary sync
- Symptom: release-truth terms and acceptance logic had already
  entered the live product contour, but docs/AI memory still lagged.
- Treatment: write the acceptance matrix, derive the operator
  checklist from it, and sync the glossary into active AI docs.

- 2026-04-16 — Forbidden-substring drift in active AI docs can trigger
  canon guards through innocent English words; preferred treatment is
  wording repair, not broad test weakening.


- 2026-04-16 — work pass: fixed frontend validator declaration-order
  drift and materialized forbidden words / narrow exceptions policy into
  SSOT to stop semantic drift in AI/docs/runtime wording layers.
- 2026-04-16 v166_86 work pass web-profile hardening and CI fix

- 2026-04-16: work pass follow-up — keep ProfileModal compact; do
  not grow a second heavy cabinet. Shared copy-layer must land before
  broad UI string migration.

## 2026-04-16 — launcher entry drift
- Symptom: top-up entry points started to diverge by surface.
- Cause: each surface was tempted to open browser-shop its own way.
- Cure: shared launcher helper + one truth-path + no new local business
  logic.

- 2026-04-16 v166_91_92: case — launcher unification hid an assertion
  string from a canon test; repair kept shared launcher logic while
  restoring explicit route visibility and line72 compliance.

- 2026-04-16 — Case: AI/docs drift after 880. Treatment: refresh AI
  prompt-layer under the closed 871-880 contour, add future-block
  preface for 893-900, and sync strategic SSOT/TZ into
  cycles/docs/history/legacy_artifacts/reports/Q&A/glossary instead of leaving them isolated.


## 2026-04-16 — Case note
- Copy pass confirmed that the largest remaining trust-sensitive gap is
  locale-aware moderation outcome wording for users.

- 2026-04-16 / work pass: multilingual moderation path moved to
  locale-aware `system_templates` with backend language selection;
  Russian-only backend moderation prefixes are no longer canonical.


## 2026-04-16 — Case: stray 0002 outcome migration violated 0001-only
canon
- Symptom: active HEAD contained
  `backend/migrations/versions/0002_withdraw_outcome_service.py` and
  some guards/docs began to describe it as acceptable.
- User ruling: merge the outcome migration meaning into `0001`, remove
  `0002` as a dangerous object, keep only `0001` until release, and fix
  the whole package without rewriting project history.
- Action: `0002_withdraw_outcome_service.py` removed from active HEAD;
  `0001_init.py` now asserts the outcome tables directly; active
  tests/docs/SSOT/cycle notes were re-synced to strict `0001-only`.
- Guard meaning: if a future pre-release change tempts a new `0002+`,
  the correct path is an in-place `0001` update, not a second numbered
  migration.


## 2026-04-24 — case: RU localization value drift

- Symptom: `ru.json` had structurally present keys whose values still
  showed English copy, including admin actions, ranks, referrals, wallet
  and task confirmation microcopy.
- Treatment: repair the explicit audit examples and a bounded RU
  admin/operator/user-visible tail without changing the English default
  locale or starting a broad machine-translation wave.
- Guard: add `ops/i18n/audit_ru_locale_value_quality.py` for critical RU
  identical-to-EN regression checks.
- Evidence: the guard runs locally and the named critical audit examples
  no longer equal the English values.

## CASE-L10N-001 — Manual localization scope compression

Date: 2026-04-24

Problem:
- Full localization repair was initially compressed into an overbroad
  closure claim.

Correction:
- Work redistributed into cycles `983-1020+`.
- work pass: live localization source inventory.
- work pass: English baseline and terminology lock.

Guard:
- Do not disable, hide, downgrade or fallback-mask locales.
- Do not use machine translation.
- Do not close a language without manual review evidence.

## CASE-ARCH-001 — Release ZIP stored without compression

Date: 2026-04-24

Problem:
- The v167_55 archive was structurally valid but packed without useful
  compression, making the artifact look much larger than the project.

Correction:
- Treat archive compression as a release hygiene guard.
- Future release ZIPs must be packed with deflate and checked for
  payload
  versus compressed-size ratio.

Guard:
- Do not deliver a new archive if compressed size equals uncompressed
  size
  for ordinary text/code project files.
- Do not embed sandbox/reference ZIPs into release artifacts.


## CASE-L10N-002 — Ukrainian locale fallback and Russian-tail repair

Date: 2026-04-24

Problem:
- Ukrainian locale had full key parity but still contained English
  fallback
  values and a small Russian-tail segment.
- Nested `admin` and `common` objects also retained English values.

Correction:
- work pass manually repaired `frontend/public/locale/uk.json`.
- Added `ops/i18n/audit_uk_locale_value_quality.py`.
- The guard checks recursive identical-to-English values and obvious
  Russian
  tail markers.

Guard:
- Do not treat key parity as translation readiness.
- Check nested locale objects as well as flattened keys.
- Preserve only explicit product/protocol/language-name tokens.

## CASE-L10N-003 — German locale fallback and Russian-tail repair

Date: 2026-04-24

Problem:
- German locale had full key parity but still contained broad English
  fallback
  values and a smaller Russian-tail segment.
- Nested `admin` and `common` objects were part of the issue, so
  flat-only
  checks were insufficient.

Correction:
- work pass manually repaired `frontend/public/locale/de.json`.
- Added `ops/i18n/audit_de_locale_value_quality.py`.
- The guard checks recursive identical-to-English values and Cyrillic
  tails.

Guard:
- Do not treat key parity as translation readiness.
- Do not hide English fallback by accepting broad identical values.
- Preserve only explicit product/protocol/short UI/language-name tokens.

## CASE-L10N-004 — French locale fallback and Russian-tail repair

Date: 2026-04-24

Problem:
- `fr.json` had full key parity but still contained broad English
  fallback
  values and a Russian-tail segment in admin/report/log copy.
- Nested `admin` and `common` objects required recursive review, not
  only
  flat key review.

Correction:
- work pass manually repaired French values in `fr.json`.
- Added `ops/i18n/audit_fr_locale_value_quality.py`.
- The guard checks recursive identical-to-English values and Cyrillic
  tails.

Guard:
- Do not treat key parity as translation readiness.
- Accepted identical values must be explicit
  product/protocol/shared-spelling
  tokens only.
- No machine translation, no locale disabling and no fallback masking.

## 2026-04-24 — HEAL-I18N-ES-991

work pass closed the Spanish manual locale pass.

Symptoms:
- Spanish locale had broad English fallback tails;
- Spanish admin/report/log copy had Russian-tail fragments;
- key parity existed, but value quality was not complete.

Treatment:
- manually repaired `frontend/public/locale/es.json`;
- added `ops/i18n/audit_es_locale_value_quality.py`;
- documented accepted identical Spanish tokens explicitly;
- updated cycle/report/audit control layer.

Guard:
- `python3 -S ops/i18n/audit_es_locale_value_quality.py`

Status:
- Spanish JSON bundle closed to current guard level;
- multilingual release is not yet declared complete.


## 2026-04-24 — HEAL-I18N-IT-992 — Italian fallback tails

work pass closed the Italian manual locale pass.

Problem:
- `frontend/public/locale/it.json` had broad English fallback clusters
  and inherited Russian admin/report/log tails despite full key parity.

Treatment:
- manually repaired Italian values in admin/operator, player-facing
  portal, profile, wallet, exchange, panels, ranks, referrals, shop,
  tasks and withdraw copy;
- added `ops/i18n/audit_it_locale_value_quality.py`;
- preserved only explicit technical, brand and language-name identical
  tokens.

Prevention:
- future Italian changes must pass the Italian value-quality guard;
- the accepted-identical set must not grow silently.

Status: treated in v167_61, work pass.

# work pass note — 2026-04-24

Polish locale still contained English fallback and Cyrillic tails after
the earlier language inventory. The treatment was a manual Polish pass,
plus a narrow value-quality guard for `pl.json`. No machine translation
and no locale disabling were used.

## 2026-04-24 work pass Turkish localization fallback repair

- Turkish locale had broad English fallback clusters and inherited
  Cyrillic tails.
- Treatment: manual Turkish value repair plus
  `audit_tr_locale_value_quality.py`.
- Guard rule: Turkish locale may keep only intentional product/protocol
  tokens and language names identical to English.

## 2026-04-24 work pass Danish localization fallback repair

- Danish locale had broad English fallback clusters and inherited
  Cyrillic tails.
- Treatment: manual Danish value repair plus
  `audit_da_locale_value_quality.py`.
- Guard rule: Danish locale may keep only intentional product/protocol
  tokens,
  short technical tokens and language names identical to English.
- Status: treated in v167_64, work pass.

## 2026-04-24 work pass Hindi localization fallback repair

- Hindi locale had broad English fallback clusters and inherited
  Cyrillic tails.
- Treatment: manual Hindi value repair plus
  `audit_hi_locale_value_quality.py`.
- Guard rule: Hindi locale may keep only intentional product/protocol
  tokens,
  short technical tokens and language names identical to English.
- Status: treated in v167_65, work pass.


## HEAL-I18N-ID-997 — Indonesian locale fallback repair

Status: treated in v167_66.

Symptom: `id.json` had broad identical-to-English fallback clusters and
inherited Cyrillic admin/report/log tails.

Treatment: manual Indonesian localization pass, explicit accepted-token
guard and cycle/report/audit evidence.

Prevention: keep `ops/i18n/audit_id_locale_value_quality.py` in the
local
check layer and do not mark Indonesian localization as closed without
the
guard evidence.

## HEAL-I18N-SW-998 — Swahili locale fallback repair

- Date: 2026-04-24
- Status: treated in v167_67
- Guard: `ops/i18n/audit_sw_locale_value_quality.py`
- Rule: Swahili locale must not keep broad English fallback clusters or
  Cyrillic tails outside approved language names.
- Treatment: manual Swahili localization pass, explicit accepted-token
  guard and cycle/report/audit evidence.

## HEAL-I18N-PARITY-999 — all-locale structural drift

- Date: 2026-04-24
- Status: treated in v167_68
- Guard: `ops/i18n/audit__all__locale_parity.py`
- Symptom: Spanish locale had an extra key `admin.active` that did not
  exist in the English baseline or other locale bundles.
- Treatment: removed the Spanish-only extra key and added an all-locale
  key / placeholder parity guard.
- Prevention: every future locale change must pass all-locale parity and
  the relevant value-quality guard before release packaging.

## HEAL-LOC-1000 — Admin/operator hardcoded copy tail

Severity: medium/high
work pass

Symptom:
Locale bundles can pass while admin/operator TSX files still contain
visible English action labels or mixed helper copy.

Root cause:
The i18n repair wave fixed JSON bundles first, but screen-level
hardcoded
admin copy needed its own matrix.

Treatment:
work pass corrected critical admin/operator copy and added
`ops/i18n/audit_admin_operator_surface.py`.

Prevention:
Run the admin/operator surface guard after future admin UI changes and
keep admin/operator surfaces Russian-first by default.

## HEAL-CI-1001 — CI log repair after localization guard wave

- Date: 2026-04-24
- Status: treated in v167_70
- Source: `logs_66112978187.zip`
- Symptom: fresh GitHub CI failed after localization cycles on ruff
  B905,
  line72, stale cycle-control markers, generated admin bank type drift,
  banned legacy rank substring, panel `Number(` usage, payment evidence
  marker drift and raw locale key drift.
- Root cause: manual localization and guard additions changed runtime/UI
  markers and source files without a final CI-log repair gate.
- Treatment: work pass repaired the confirmed failures, stabilized
  locale
  coverage/parity guards and restored canonical runtime-sync evidence
  markers.
- Prevention: after broad localization/manual copy passes, run the
  CI-log
  repair gate before claiming the next planned localization cycle.

## HEAL-CI-1002 — CI follow-up after work pass repair

- Date: 2026-04-24
- Status: treated in v167_71
- Source: `logs_66117671778.zip`
- Symptom: GitHub CI still failed after v167_70 on pytest legacy-word
  guards
  and frontend build module resolution.
- Root cause: the cycle file contained a banned legacy rank substring
  inside
  ordinary English wording, and admin pages imported a localized
  component
  identifier `TelegramСтатусBadge` instead of `TelegramStatusBadge`.
- Treatment: reworded the cycle file and restored the canonical
  component
  import/name.
- Prevention: do not localize component identifiers or file paths; avoid
  words
  that contain banned legacy rank substrings even in documentation.

## HEAL-LOC-1002 — Player-facing Cyrillic hardcoded tail

- Date: 2026-04-24
- Status: treated in v167_71
- Guard: `ops/i18n/audit_player_surface_matrix.py`
- Symptom: selected player-facing TSX surfaces still had visible
  Cyrillic
  helper copy after locale bundle repair.
- Root cause: locale JSON repair does not automatically cover hardcoded
  TSX
  player surfaces.
- Treatment: removed visible Cyrillic copy from selected player surfaces
  and
  shared player UI defaults.
- Prevention: run the player-surface matrix guard before claiming
  player-facing
  screen-level localization progress.

## HEAL-CI-1003 — localized technical identifiers broke frontend build

- Date: 2026-04-24
- Status: treated in v167_72
- Source: `logs_66122753408.zip`
- Symptom: GitHub CI failed on pytest wallet-gate marker and frontend
  build
  module resolution for a localized admin chart identifier.
- Root cause: localization crossed into TypeScript identifiers/import
  paths,
  and player-facing Cyrillic cleanup removed the existing `Пополнить`
  wallet-gate test marker.
- Treatment: restored `Пополнить`, restored `AdminCharts`, restored
  English
  technical identifiers in affected admin TSX files, and documented the
  narrow wallet-gate exception in the player-surface guard.
- Prevention: never localize code identifiers, generated type names,
  component
  names, import paths or file names during language repair.

## HEAL-I18N-BOT-001 — backend bot text-source island

Date: 2026-04-24
work pass
Severity: medium

Symptom:
The frontend locale bundles were manually repaired, while
`backend/app/bot/texts.py` still acted as a separate two-language text
source.

Treatment:
The bot text source was synchronized to the 13 active locale codes and
a dedicated parity guard was added.

Guard:
`ops/i18n/audit_bot_texts_parity.py`

Residual:
Runtime language selection is not claimed by this treatment. It remains
a separate product/runtime decision if required.

## 2026-04-25 localization scope compression guard

- Defect: AI attempted to describe work pass as RU/EN-focused while the
  user assigned bot localization work that must cover all 13 languages.
- Treatment: AI-layer and language canon now require full 13-language
  coverage for bot translation/localization passes unless the user
  explicitly narrows the scope.
- Prevention: any future RU/EN-only closure of a localization cycle is
  process drift and must be recorded instead of being treated as done.
- Related work pass.

## HEAL-I18N-NOTIFY-1007 — notification/template fallback tails

Date: 2026-04-25
Status: treated in v167_75
Severity: P1

Problem:
Shop order Telegram notifications were player-visible but still used
Russian-only copy. Withdraw outcome promo fallback covered only a small
language subset.

Treatment:
work pass added 13-language shop notification buckets, language
resolution from order/user metadata, English fallback for unknown player
locale and 13-language withdraw promo fallbacks.

Guard:
`ops/i18n/audit_notification_template_repair.py`

## HEAL-I18N-FRONTEND-1008 — hardcoded frontend copy tail

Date: 2026-04-25
Status: inventoried in v167_75
Severity: P1

Problem:
Frontend TS/TSX surfaces still need screen-level hardcoded copy
migration
after locale bundle repair.

Treatment:
work pass added a hardcoded-string inventory guard and an audit report.
Repair remains explicitly assigned to work pass.

Guard:
`ops/i18n/audit_frontend_hardcoded_strings.py`

## HEAL-I18N-FRONTEND-1009 — money-path hardcoded copy tail

Status: treated in v167_76

Symptom:
Money-path frontend screens still had player-visible hardcoded English
copy after the inventory pass.

Root cause:
Several Withdraw, Exchange, Panels and shared widget strings were kept
inside TSX files instead of locale bundles.

Treatment:
work pass moved the highest-impact money-path copy to locale-backed
keys across all 13 active languages and refined the hardcoded-string
audit guard to ignore i18n key literals.

Prevention:
Continue work pass for the remaining candidates and keep locale parity
checks active for every new key.

## HEAL-I18N-FRONTEND-1010 — shortcut hardcoded copy tail

Status: treated in v167_77.

ProfileModal, RanksTable and ReferralsTabs still had high-visibility
direct
English copy after the work pass money-path repair. work pass moved
the
confirmed shortcut copy to locale-backed keys across all 13 active
bundles.

## HEAL-I18N-PLACEHOLDER-1012 — interpolation drift risk

Status: guarded in v167_77.

Manual translation can drop interpolation tokens. work pass added a
local
Node guard that compares placeholder token sets in every locale against
the
English baseline. The local run found 0 placeholder mismatches.

## HEAL-I18N-IDENTICAL-1013 — fallback-equivalent translation residue

Status: baseline measured in v167_77.

work pass added a local identical-to-English review guard. The current
baseline intentionally remains non-green with 1243 findings, which means
the
remaining localization proof cycles must not claim full release
readiness yet.

## Healer cards — v167_78 language proof and extension

### HEAL-L10N-1015 — static proof confused with browser proof

- Severity: medium.
- Symptom: reports can sound like visual proof even when only code and
  locale checks were run.
- Treatment: work pass now explains static proof versus browser proof
  and lists the screens for later human browser checking.
- Prevention: never claim browser proof without a human visual pass.

### HEAL-L10N-1022 — false closure risk at range boundary

- Severity: high.
- Symptom: localization range could be closed while a measured language
  tail still exists.
- Treatment: work pass closes the proof range but extends language work
  to 1040 without claiming final release readiness.
- Prevention: residual language tails must be routed into a bounded next
  range, not hidden.

### HEAL-L10N-1024 — identical-to-English signal too coarse

- Severity: medium.
- Symptom: the guard had a total count and sample but not enough summary
  data for manual repair planning.
- Treatment: work pass adds `by_lang` and `by_prefix` summaries.
- Prevention: future language repair passes must use distribution data
  before editing translations.

## Healer cards — v167_79 language triage and archive repair

### HEAL-ARCH-001-R — archive compression recurrence

Status: treated in v167_79.

Symptom:
The v167_78 artifact was about 14 MB while nearby artifacts were about
4.8 MB.

Root cause:
The archive was packaged in stored/no-compression mode. The payload did
not justify the size jump.

Treatment:
The next artifact is rebuilt with explicit deflate compression. The
report records the size check before delivery.

Prevention:
Archive size jumps must be checked against Healer before delivery.

### HEAL-L10N-1025 — identical-to-English tail explanation

Status: documented in v167_79.

Symptom:
The phrase `identical-to-English tail` can be unclear for the user and
can sound like a normal translation error instead of a measured residual
queue.

Treatment:
work pass adds a plain-language explanation and separates approved
technical tokens from real English leftovers.

Prevention:
Future reports must explain measured language tails in user-readable
terms and must not hide them under release-ready wording.

### HEAL-ARCH-002 — slow unpack / timeout risk

Status: treated in v167_79.

Symptom:
The oversized v167_78 artifact caused slow extraction and timeout risk
in
sandbox work. This made normal HEAD startup less reliable.

Root cause:
Archive packaging used stored/no-compression mode and produced an
unexpected size jump. Slow unpack time is therefore a release artifact
symptom, not only a local inconvenience.

Treatment:
The problem is recorded as a recurring Healer class. Future archive
passes must check size, compression method and extraction viability
before delivery.

Prevention:
Before delivery, compare artifact size with previous HEAD, avoid stored
ZIP mode, run `unzip -tq`, and treat slow unpack as a systematic release
hygiene signal.


### HEAL-L10N-1039 — persistent identical-to-English tail

- category: `localization_guard`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `active`
- medical_maturity: `partially_protocolized`
- action_priority: `treat`

**Symptoms**

- Non-English locale keys exist, but values remain identical to English.
- The UI can look structurally complete while still showing fallback
  copy.
- The tail can return after new locale keys are added.

**Treatment**

- Keep `ops/i18n/audit_identical_to_english.js` active.
- Use `ops/i18n/identical_to_english_allowlist.json` only for short
  protocol/product identifiers.
- Repair long user-visible sentences manually by language and screen.

**Verification**

- Re-run the identical-to-English guard after each locale repair.
- Record remaining counts by language and prefix.
- Do not call localization release-ready while unreviewed tails remain.

2026-04-26 follow-up:
- User ordered the residual findings to be reduced from 794 to 0.
- The work pass addendum repaired remaining exact-English values across
  affected non-English locale bundles.
- Local helper result: `identical_findings: 0`.
- The Healer class remains active as a regression guard; any future
  non-zero result is a recurrence.


## HEALER-L10N-ADMIN-RU-ONLY

Severity: high.

Problem:
The assistant previously mixed the user multilingual contour with the
admin/operator contour and treated admin localization as if it belonged
to
mandatory all-locale coverage.

Root cause:
Process drift and insufficient iteration before applying localization
rules.

Treatment:
Admin panel is fixed as Russian operator contour. admin.* in non-ru
locale
is not a blocker. user-facing use of admin.* is a blocker.

Prevention guard:
Admin ru-only guard and no-admin-leak guard must be used in active
release
scope.

## HEALER-L10N-FORBIDDEN-GAMING-CONTOUR

Severity: blocker.

Problem:
Old removed-domain gaming copy can return through i18n, FAQ, functions,
routes, tests, templates or stale copy.

Root cause:
Legacy residue and unsafe silent normalization of old vocabulary.

Treatment:
Do not replace the old removed contour with another product term without
user approval. If active code/function/route/model/key residue is found,
prepare a deletion risk map and ask the user in Russian.

Prevention guard:
Smart forbidden contour guard checks active release scope and excludes
historical reports, audits, logs, Healer and old cycle records.

## 2026-04-26 forbidden contour active blocker approval rule

- Active forbidden-contour findings in code, routes, models, functions,
  runtime messages or locale keys must not be physically deleted or
  renamed
  without a Russian iteration and user approval.
- work pass found `ParticipationClosedError` / `Round is closed.` in
  `backend/app/core/errors_core.py`; this is recorded as an approval
  blocker,
  not silently changed.
- Proposed treatment: replace the message/docstring with neutral
  participation wording while preserving `participation_closed` error
  code.

### 2026-04-26 — v167_84 follow-up: active round artifact removal

User approved removal of active `Round / раунд` residue after v167_83.
Treatment applied:
- removed unused `ParticipationClosedError` from active backend errors;
- replaced energy-service technical `rounds` with neutral processing
  `passes / проходы` while preserving stable energy generation;
- repaired active FAQ and panel/referral wording;
- active forbidden-contour guard result: `forbidden_findings: 0`.

Boundary:
- historical reports, audits, Healer records and logs were not
  rewritten;
- suspicious `reward/win/prize` findings remain contextual and require
  Russian iteration if a future pass changes them.


### 2026-04-26 — corrective note: game != gambling

- The assistant over-cleaned the active FAQ by treating `игровой` as if
  it
  were automatically forbidden.
- Correct canon: EFHC Bot may be described as a game / gaming project /
  gameplay.
- Forbidden contour is limited to gambling, loto, draw-prize, tournament
  financial competition, betting and random-win semantics.
- Treatment: restore active FAQ from the previous valid version and keep
  guards focused on the forbidden financial contour instead of the word
  `игровой` itself.
- Prevention: when the assistant sees `игра / игровой`, it must evaluate
  context and ask a Russian iteration if there is any doubt.


### 2026-04-26 — FAQ panel activation drift across all locales

- After the bounded English FAQ correction, a wider all-locale FAQ pass
  confirmed that panel wording must stay on the activation canon in
  every active FAQ language.
- Treatment: normalize section 7 panel wording in active FAQ files and
  in `frontend/src/data/faq/catalogs.ts` so the user sees activation
  wording, not panel purchase/price wording.
- Boundary: suspicious `reward / prize / win` contexts remain
  manual-review territory and must not be auto-rewritten.


- Follow-up 2026-04-26: для language/canon проблем дополнительно
  закреплена граница между игрой и азартным контуром; слово «игровой» не
  должно чиститься автоматически.

- 2026-04-26: work pass — active user-facing canon changed from
  `reward / награда` to `bonus / accrual` logic; `reward` is no longer
  canonical in active FAQ/locale values, while historical documents
  remain untouched.

- Follow-up 2026-04-26: neutral alias transition for legacy `reward*`
  names added; no immediate destructive removal of compatibility names
  is allowed until all paths are verified.

- Case follow-up v167_92: green-log confirmation allowed removal of
  public `reward*` aliases; deeper runtime/DB rename still requires a
  separate risk map.


## 2026-04-27 — H-ALIAS-TRACE-1120

Severity: medium

Symptom:
- Public alias cleanup had removed the main active reward aliases, but
  small
  residual traces remained in frontend copy helpers and locale
  placeholders.
- Tasks service also contained a duplicated SQL `UPDATE` line in the
  lock
  finalization statement.

Treatment:
- Replaced public `{{reward}}` task/ad bonus placeholder with
  `{{bonus}}`
  across active locale bundles and frontend code.
- Removed frontend `taskReward` copy alias and `Task reward` source
  phrase.
- Kept technical DB/runtime reward names where compatibility still
  requires
  them.
- Repaired duplicated task lock SQL update statement.

Prevention:
- Alias removals must remain compatibility-checked across backend,
  frontend, routes, admin, i18n, FAQ, migrations and reports.
- Technical DB/runtime names must not be removed until a separate risk
  map
  proves the path is safe.


## 2026-04-27 ads slot SQL missing FROM + alias cleanup boundary

- Finding: `/ads/slot` had a SQL query selecting task fields without
  `FROM {SCHEMA}.tasks`, which could break ad slot issuance at runtime.
- Treatment: add the missing `FROM` clause and keep canonical response
  field
  `bonus_efhc`.
- Prevention: alias cleanup must include route/runtime sanity checks,
  not only
  text search.
- Boundary: technical `reward*` DB/runtime names are compatibility
  contracts
  until a migration-safe plan exists; do not mass-rename them.


## 2026-04-27 portal English-first drift + reward bridge closeout

- Finding: `ShopEntryPage` still had hardcoded Russian explanatory text
  in an
  active player-facing portal surface, and the active task service
  entrypoint
  name still leaned on legacy `claim_task_reward()`.
- Treatment: switch the active route/service bridge to bonus-first
  naming,
  keep compatibility wrappers for legacy reward names, and replace the
  portal
  hardcoded block with locale keys.
- Prevention: after public alias cleanup, always check route/service
  entrypoint
  names and player-facing portal copy before declaring the contour
  release-ready.


## 2026-04-27 line72 + bandit log-driven release blockers

- Finding: fresh GitHub logs confirmed one `line72` failure class and
  one
  `bandit` finding in `/ads/slot`.
- Treatment: wrap the exact long lines, shorten active guard JSON
  strings and
  replace the raw ads SQL text with ORM `select(Task...)`.
- Prevention: fresh log imports must drive only confirmed blocker
  repair,
  not speculative refactors.


## 2026-04-27 pre-release task schema drift and reward-log table rename

- Finding: the active tasks runtime still depended on helper tables and
  field assumptions that were not promoted into ORM/`0001`, while the
  product
  had not launched yet.
- Treatment: move helper tables into first-class ORM metadata, extend
  `0001`
  sanity for the task contour, rename `task_rewards_log` to
  `task_bonus_log`, and align service SQL with the real `tasks` schema.
- Prevention: before release, any active route/service table must exist
  in
  ORM, `0001`, SSOT table maps and Healer notes at the same time.

- v167_98: closed pre-release task column drift (`reward_bonus_efhc` /
  `reward_amount_efhc` -> `bonus_efhc` / `bonus_amount_efhc`) and fixed
  `TaskSubmission.user_global_id` CRUD drift before launch.

- admin task duplicated submissions path drift: route used
  `/admin/tasks/tasks/{task_id}/subs` while SSOT/frontend canon expected
  `/admin/tasks/{task_id}/subs`; repaired pre-release in work pass.
- task can_claim paid-flag drift: `/tasks/my/{global_id}` ignored submission
  `paid` and could show claimability incorrectly; repaired by selecting
  the real paid flag in work pass.

- hidden hub browser-shop helper-route drift: `/hub/browser-shop-*`
  physically existed as compatibility transport routes while the public
  shop/browser contour already moved to `/shopfront/*`; repaired
  pre-release by freezing them as internal helper routes with
  `include_in_schema=False` instead of exposing duplicate public roads.
- task payload reward-echo drift: task/admin service payloads still
  emitted legacy `reward_*` echoes after the schema/runtime became
  bonus-first; repaired in work pass by keeping bonus-first
  outputs and leaving only bounded input compatibility aliases.

- v168_01: tail-zero bonus-first sweep removed remaining active
  `reward*` bridges from task service payloads, schemas and ORM helper
  properties; left only bounded `VerifiedAdEvent.reward_bonus_efhc`
  property alias inside ads provider compatibility layer.


## CASE-0055 repair pass follow-up — deposit-cache proof lane

- version: `v169_86`
- cycle: `1404`
- user decision: no process-local `_ttl_seen`/memory TTL cache may be the source of truth for duplicate deposit protection.
- current code check: `system_locks.py` already routes TTL duplicate locks through `IdempotencyKey` / `efhc_admin.idempotency_key`.
- remaining work: repair pass must add proof/guards for no `_ttl_seen` regression and long-retention deposit/payment idempotency records.



### v169_88 / repair pass casebook update

- `CASE-0040`: package intent contract repaired. `package_id` is nullable only for custom/package-less intents; fake `0` package sentinel is forbidden; existing DBs drop `NOT NULL` through Alembic 0001.
- `CASE-0044`: transfer direction width proof added. Existing DBs widen `efhc_transfers_log.direction` to `varchar(24)` and sanity checks enforce the width.

## CASE-0018 repair pass follow-up — transaction-boundary runtime repair

- version: `v169_90`
- cycles: `1409-1410`
- applied: `transactions_service._tx_context()` now owns commit/rollback without
  hidden `begin_nested()` fallback.
- applied: `exchange_service` closes read-only preflight autobegin before money
  service entry.
- residual: `withdraw_service` remains routed to `HEAL-0024` / repair pass.

## v169.91 — HEAL-0024 primary withdraw atomicity

repair pass repaired the primary withdraw create/hold/mark race by moving request row creation, no-commit balance hold, transfer audit meta and `hold_done=TRUE` into one service-owned transaction boundary. Operator Kernel refresh/version validation was added as a controlled optimization.


## CASE — v169.92 HEAL-0055 deposit DB idempotency

repair pass applied DB-backed deposit idempotency and Kernel Start Core hardening. The old risk of process-local deposit duplicate cache is guarded by service-level `IdempotencyKey` usage and a source guard.

## CASE-0056 — FSM states.py split

- Version: `v169_95`.
- Cycles: `1417-1420`.
- Root cause: single responsibility drift in `backend/app/bot/states.py`.
- Treatment: new `backend/app/bot/fsm/` modules plus compatibility facade.
- Regression guard: `tests/architecture/test_fsm_states_split_facade.py`.

## CASE — economic risk repair

Root cause:

- spend read-through checked only the `:main` key, which is absent for
  all-bonus spends;
- admin manual debit passed kwargs that are not part of canonical debit
  function signatures.

Treatment:

- read-through now checks both `:main` and `:bonus` spend keys;
- nonexistent admin debit kwargs were removed;
- active architecture guards were added.

## CASE — economic risk panel atomicity repair

Root cause:

- panel activation used a committed spend before creating panel records;
- replay payload lookup read only the `:main` log and could miss all-bonus
  activation data stored under `:bonus`.

Treatment:

- added nocommit spend helper for higher-level atomic flows;
- moved panel activation spend, panel row creation and audit merge into one
  transaction;
- updated architecture guards for atomicity and all-bonus replay payload lookup.


## CASE — economic risk withdraw/exchange atomicity repair

Archive: `EFHC_Bot_v169_99_cycle_1424_withdraw_exchange_atomicity_repair.zip`.

Confirmed problem:

- `cancel_withdraw` and `admin_reject_withdraw` used split commits between
  final status and refund;
- exchange helpers performed idempotency read-through before the lock/retry
  section.

Treatment applied:

- added nocommit MAIN refund helper;
- cancel/reject status, refund transfer and `refund_done=TRUE` now share one
  transaction;
- exchange idempotency proof moved inside the lock/retry loop;
- direct exchange calls close preflight/autobegin state at entry.

Proof:

- `tests/architecture/test_economic_risk_guards.py` updated with withdraw and
  exchange guards.


## CASE — economic cleanup and reconciliation hardening

Archive: `EFHC_Bot_v170_00_cycle_1425_economic_cleanup_reconciliation.zip`.

Confirmed problem:

- `exchange_all` rejected zero-amount path wrote a false financial debit log;
- `withdraw_service.py` duplicated transaction-context logic;
- legacy strict kWh check used stored `available_kwh`;
- bonus-credit metadata was not persisted;
- reconciliation invariant `INV-08` needed explicit guard coverage.

Treatment applied:

- no financial transfer log for rejected zero-amount exchange;
- canonical transaction context imported into withdraw service;
- strict kWh check switched to SSOT calculation;
- bonus credit passes meta to `_run_idempotent`;
- `tests/architecture/test_economic_risk_guards.py` extended with cleanup and
  reconciliation guards.

## CASE — panel dead transaction-context cleanup

Archive: `EFHC_Bot_v170_01_cycle_1426_panel_dead_tx_context_cleanup.zip`.

Confirmed problem:

- v170.00 economic re-audit found `NEW-001`, a dead local `_tx_context` in
  `panels_service.py` using `db.begin_nested()`.

Treatment:

- removed the dead helper;
- updated panel service atomicity wording;
- added `test_panels_service_no_local_tx_context`;
- updated cycle, testing, Q&A, healer and kernel navigation documents.

Result:

- `NEW-001` is closed locally.
- The economic re-audit condition is satisfied, without claiming full release
  readiness.

## CASE — CI log repair after economic cleanup

Archive: `EFHC_Bot_v170_02_cycle_1427_ci_log_repair.zip`.

Log input: `logs_72342361356.zip`.

Confirmed problem:

- CI failed on ruff import order, line72, dunder integrity and Healer atlas
  schema guards.

Treatment:

- sorted `withdraw_service.py` imports;
- wrapped `panels_service.py` long lines;
- renamed new economic helper/test identifiers to dunder-safe spelling;
- completed missing Healer card fields and fixed the invalid enum value.

Result:

- targeted log-failure guard pack passes locally;
- economic behavior remains unchanged;
- no release-ready or GitHub CI green claim is made by this local cycle.

## CASE — security audit truth reconciliation

Archive: `EFHC_Bot_v170_03_cycle_1428_security_audit_reconciliation_plan.zip`.

Audit input: `P0_SECURITY_AUDIT_V170_01.md`.

Confirmed problem:

- audit title and actual inspected HEAD diverged;
- wallet binding canon and production entrypoint truth required decisions;
- P0 security blockers remained active and had to be planned without a false
  release-safe claim.

Treatment:

- archived the audit under `docs/history/legacy_artifacts/docs/audits/`;
- recorded `v170.02` as factual HEAD for the security repair line;
- answered Q1-Q3 in Q&A and security canon documents;
- planned cycles `1431`;
- added `test_security_audit_reconciliation_plan.py`.

Result:

- truth drift is closed as a planning/documentation issue;
- P0 blockers remain visible and are not claimed fixed;
- next safe step is the dedicated P0 security repair cycle.

## CASE-0116 — P0 security wallet proof and cron secret repair

- Archive: `v170.04`.
- Heal: `HEAL-0104`.
- Treatment: mandatory TonConnect proof for wallet binding, verified wallet gate,
  single-use proof payload marker, and prod/stage cron secret fail-fast.
- Release status: repeat security audit pending.

## CASE-0116 — Security P2 replay / OPSEC / legacy-header repair

- Heal ID: HEAL-0104.
- Archive version: v170.05.
- Confirmation basis: active P0 security audit P2 findings and the local security P2
  repair.
- Treatment history: strict Telegram `auth_date`, redaction aliases, no legacy
  frontend/admin headers.


## CASE-SECURITY-REGRESSION — the security regression pass security regression hardening

- HEAL: HEAL-0107
- Archive version: v170.06
- Root cause: after security P0/P2 local repairs, repeat-audit guard coverage
  was not yet locked for admin route auth, ownership routes, prod docs/CORS and
  webhook dedupe-after-secret ordering.
- Treatment: added `test_security_regression_hardening.py` and changed
  Telegram webhook route to call dedupe registration after secret validation.
- Status: locally treated; repeat audit pending.

## CASE-SECURITY-MINOR-1434 — security minor findings repair

- HEAL: HEAL-0108
- Archive version: v170.09
- Root cause: repeat security audit v170.08 left non-P0 findings around ads
  callback test mode, monetary rate-limit prefixes and production env template
  OPSEC.
- Treatment: added `ADS_TEST_MODE` prod/stage fail-fast, added `/deposit` and
  `/payment-intents` to monetary middleware defaults and replaced real-looking
  TON addresses in `env.prod.example` with placeholders.
- Status: locally treated; fresh CI/audit proof pending.

## v170.18 / step 1442 — OpenAPI contract gate tail

- `F-006` checked-in OpenAPI drift repaired locally by rebuilding snapshot from backend route source.
- Static contract gate added: `tests/architecture/test_openapi_rebuild_strict_contract_gate.py`.
- Guard report: `docs/history/legacy_artifacts/reports/generated/openapi_strict_contract_gate_v170_18.json` → `status=ok`.
- Live FastAPI `app.openapi()` proof remains unclaimed in local tool environment because `sqlalchemy` is missing.
- Remaining healer tails: `F-007` UI loading/error/empty-state guards, full linkage architecture matrix/reporting and repeat audit.

## Work pass 1445 — CI/log repair and old BNB/source skin cleanup

- HEAL-0111 / CASE-0120 added for `logs_72623328892.zip` repair.
- Root causes: ruff import order, mypy bank typing, stale guards, Kernel marker, line72, route inventory count, Healer schema tail, wallet test isolation and old PNG skin.
- Old source skin removed: `frontend/public/skins/1.png`.
- Active runtime skin remains: `frontend/public/skins/1.webp`.
- No tests were deleted or disabled.

## 2026-07-25 — v171.77 first-panel referral wiring regression

A full green v171.76 GitHub run did not protect the first-panel referral
business event. The only bonus test invoked the referral hook directly, while
`panels_service.activate_panel()` never called it. Repair connected the hook
inside the panel-owned transaction, introduced a no-commit BONUS bank helper,
made failures fail closed, and added full-flow/replay/rollback guards.

## 2026-07-25 — v171.78 immutable referral first-creation boundary

The v171.77 panel hook fix did not yet protect who was allowed to create a
player. Profile and money code could create a missing user before referral
onboarding, producing an irreversible false 0 user. Treatment established one
player-creation entrypoint, removed all late public/Admin mutation roads,
removed monetary level payouts and retained only the one-time `0.1 EFHC`
direct-referral first-panel reward. PostgreSQL and release guards now prove the
business flow rather than only source shape.

## 2026-07-25 — v171.78 dependency-light referral reward call guard

The PostgreSQL tests remain the authoritative business-flow proof, but they can
be unavailable locally. A second executable test now invokes the real reward
helper with controlled seams and protects its call signature, recipient,
amount and idempotency key without replacing the database test.


## CASE-0129 — exact-HEAD release evidence gate accepted stale CI

- Heal: `HEAL-0116`.
- Archive: v171.85.
- Cycle: 1588.
- Confirmed symptom: the local release gate could use fixed v171.67/v171.69
  evidence while evaluating a later HEAD and overstate readiness.
- Confirmed cause: no runtime-derived current version and no mandatory
  `source_head == current_head` comparison.
- Treatment: current version derives from release policy; CI intake discovery is
  dynamic; only exact-head green evidence is accepted; stale evidence is
  retained only as rejected history; missing exact-head evidence returns a
  fail-closed candidate status.
- Regression proof: `test_provider_independent_release_portability.py` covers
  current-version derivation, stale evidence rejection and exact-head matching.
- External remainder: fresh exact-HEAD GitHub CI and deployment/live gates.


# HEAL-0117 / CASE-0130 — duplicate activation and paper integration proof v171.86

- Cycle: 1589.
- Severity: P0 financial-proof integrity / concurrency-maintenance risk.
- Root cause: two owners of the same activation transition and tests that could
  pass without exercising the full production attribution path.
- Treatment: locked CRUD single owner, explicit `activated_now`, real onboarding
  E2E tests, ten-referral Lvl 1 runtime proof, and zero-skip JUnit enforcement.
- Prohibited workaround: restoring inline activation SQL, replacing runtime
  tests with AST/string assertions, or allowing CI skips to count as green.
- Proof boundary: locally validated; exact v171.86 GitHub CI required.

## CASE-0131 — fresh v171.86 development CI exposed runtime defects

- Heal: `HEAL-0118`.
- Cycle: 1590.
- Symptom: 13 PostgreSQL tests and four Ruff checks failed while the
  separate release profile remained green.
- Cause: ambiguous bind types, one stale test expectation and a row-lock
  policy that rejected rather than serialized a legitimate request.
- Repair: explicit types, correct 100 EFHC balance truth and blocking
  same-user `FOR UPDATE`.
- Prevention: exact runtime and packaged-release guards plus fresh CI.

## CASE-0132 — PostgreSQL planner-name false failure and page inventory drift

- Cycle: 1591.
- Input: release run `82110466270` green; development run
  `82109237157` failed one integration assertion.
- Trigger: PostgreSQL selected a valid index-backed plan whose panel index
  name differed from the one hardcoded in the test.
- Root cause: the test asserted planner implementation detail rather than the
  required indexed-access invariant.
- Parallel finding: the project had no single active inventory covering all
  34 physical pages; four routes were absent even from the intended current
  completeness layer.
- Repair: parse JSON plan nodes, accept the canonical panel-index set, add
  complete route/source inventories and enforce documentation/visual-proof
  parity.
- Browser boundary: exact local proof was deferred after npm registry 503.
  A separate automatic non-blocking GitHub workflow now runs the real
  34-route by 3-viewport Chromium cycle and uploads JSON/PNG evidence.

## CASE-0133 — green CI concealed split Activ semantics

- Heal: `HEAL-0120`.
- Archive/cycle: `v171.89 / 1592`.
- Trigger: user audit specification after exact v171.88 CI passed.
- Confirmed symptom: deleting all panel rows would make public referral
  counters/list and Admin user detail report inactive, while
  `admin_summary` still reported active.
- Cause: current panel existence and the one-time activation event were
  both used as technical definitions.
- Repair: one activation flag in runtime, documentation and schemas;
  legacy Admin query removed; one destructive multi-consumer DB test.
- External remainder: fresh exact v171.89 PostgreSQL CI with zero skips.
## CASE-0136 — Cycle 1596 external UserId contract

The API contract now rejects int, TelegramId, zero and Unicode digits,
stores nominal UserId and serializes ten ASCII digits. No active route,
DTO, ORM or ownership read was switched.

\n## CASE-0137 — users.user_id EXPAND needs revision 0001\n\nCycle 1597 found that changing only `0001_init.py` would prove clean\ninstallation but would not upgrade an existing database at revision\n`0001`. The project therefore moved to a linear `0001 -> 0002` chain.\nRevision `0002` is nullable, idempotent, does not backfill and does not\nchange runtime ownership or financial data.\n
