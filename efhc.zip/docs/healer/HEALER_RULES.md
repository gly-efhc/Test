# HEALER RULES

## Роль

Healer работает как врач одного пациента — проекта EFHC.
Доктором является ChatGPT, работающий с кодом проекта.

## Обязательные правила

- новую болезнь записывать сразу в Healer;
- любой новый подтверждённый CI/log дефект немедленно маппить на Healer в том же цикле;
- карточка болезни может существовать без лечения;
- для такой карточки ставить `treatment_status: pending`;
- после нахождения лечения обновлять карту болезни и casebook;
- история лечения хранится в `casebook.json` и
  `docs/healer/HEALER_CASEBOOK.md`.

## Запрещено

- подменять Healer временными аудитами;
- считать `docs/history/legacy_artifacts/reports/` каноничной памятью дефектов;
- развивать legacy registry как основной реестр;
- выдумывать болезни и лечение без подтверждения.


## Клинический минимум зрелой карточки

Для зрелой карты болезни обязательны:
- `card_status`;
- `treatment_status`;
- `medical_maturity`;
- `confirmation_basis`;
- `forbidden_actions`;
- `prevention`;
- `first_seen`;
- `last_seen`;
- `times_seen`;
- `casebook_refs`.

## Дополнительные классы болезней

- documentation drift
- terms scope drift
- runtime declaration drift
## Critical delivery disease rule

A protocol-complete delivery breach is always P0 and immediate. It must use
`HEAL-0112 / CASE-0121` and the executable gate in
`ops/healer/check_critical_delivery_protocol.py`.

The agent must enter `BLOCKED_PROTOCOL` when HEAD, cycle status, screenshot
provenance, archive integrity, Healer triple-write or delivery receipt is
invalid. Narrative explanations cannot override the blocked state.

