<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# HEAL-0126 / CASE-0139 — закрытие фундамента без ложного доказательства

- Цикл: `1600`.
- Версия: `v171.97`.
- Риск: локальное закрытие диапазона может ошибочно разрешить backfill
  либо скрыть недоступность реальной PostgreSQL.
- Исправление: машинный шлюз закрытия, точный handoff, сохранённые
  блокировки backfill/read switch и отложенный GitHub CI.
- Статус: локальный фундамент закрыт; PostgreSQL proof обязателен.

# HEAL-0125 / CASE-0138 — PostgreSQL reconciliation gate

- Цикл: `1599`.
- Версия: `v171.96`.
- Причина: реальная PostgreSQL недоступна, поэтому коллизии и
финансовая сверка не могут считаться доказанными.
- Исправление: read-only environment preflight, reconciliation gate,
финансовый допуск `0.00000000` и fail-closed запрет historical
backfill.
- Guard: PostgreSQL gate, patch-boundary и русскоязычный guard.
- Статус: подтверждено; backfill остаётся запрещённым.

# HEALER_CAPSULE

## UserId LEGACY alias/backfill recurrence protection — v171.95

- Symptom: a compatibility alias switches `User.id` to `user_id`
  before backfill, or a preparation harness executes database writes.
- Root cause: alias lifecycle and backfill execution were not separated.
- Fix: bounded `User.legacy_runtime_id -> User.id`, inactive future alias,
  pure deterministic planner and render-only guarded SQL.
- Forbidden regression: derive `user_id` from `global_id`/wallet or execute
  backfill before real PostgreSQL reconciliation.
- Guards: `HEAL-0124`, `CASE-0137`, alias boundary and harness tests.

Status: ACTIVE SHORT HEALER ENTRY.
Archive: `v171.95`.

---

# HEALER_CAPSULE

## UserId API numeric-coercion recurrence protection — v171.93

- Symptom: API/OpenAPI can expose a system ID as integer or silently
  accept provider/raw numeric values, losing leading zeroes.
- Root cause: the value object alone does not define FastAPI/Pydantic
  serialization and schema behavior.
- Fix: isolated `PydanticUserId`, `ApiExternalUserId`, strict envelopes,
  string-only schema tests and API patch boundary.
- Forbidden regression: active route/DTO wiring before assigned switch.

Status: ACTIVE SHORT HEALER ENTRY.
Archive: `v171.93`.

---

## Retained prior project record

## HEAL-0121 / CASE-0134 — UserId guard compatibility

The provider-independent doctrine exposed stale quality guards that
rejected the canonical `user_id` name, cycle-numbered implementation
files, an overlong flat hash manifest and stale release version strings.
The repair preserves or strengthens every gate: only `user_id` and
`tg_id` are canonical, aliases remain forbidden, all 485 hashes remain
verified, and version parity is executable. No runtime owner or schema
changed.

# HEALER_CAPSULE

## UserId alias weakness recurrence protection — v171.92

- Symptom: a static `NewType` contract still behaves as a plain integer at runtime and can be formatted without proving that a system-ID boundary was crossed.
- Root cause: cycle 1594 established names and negative scans but did not yet provide a runtime nominal value object.
- Treatment: frozen/slotted `UserId` and `TelegramId`, strict database/external boundary functions, raw integer rejection at output boundaries and zero imports outside the isolated identity package.
- Guard: `ops/identity/check_user_id_value_type_boundary.py` plus `tests/efhc_backend/identity/test_user_id_types.py` and `tests/architecture/test_user_id_value_type_adoption.py`.
- Forbidden regression: importing `UserId` into ORM/routes/services before the assigned adoption/read-switch cycle.

Status: ACTIVE SHORT HEALER ENTRY.
Archive: `v171.92`.

Use this file during ordinary startup. Do not full-read Atlas/Casebook unless the task route is a regression/Healer audit.

Active Operator Kernel protections:

- `HEALER_OPERATOR_KERNEL_DRIFT_GUARD.md`;
- `HEALER_OPERATOR_KERNEL_DEMOTION_GUARD.md`;
- `HEALER_OPERATOR_KERNEL_KEYWORD_LOSS_GUARD.md`.

Current incident: v171.61 active Kernel role was reduced to navigation-only and that state was protected by governance guards. Treatment: restore full dispatch role, YAML-primary runtime routing, EFHC keyword classification, summary-map startup and behavior tests. Independent proof is required from tests; this capsule cannot self-certify cure.

## Wallet provider recurrence protection — v171.66

- Application features must depend on `WalletProvider`, not directly on TonConnect or an unpublished native API.
- Provider-specific SDK/API mapping belongs only in its adapter.
- A bridge appearing after initial render must trigger adapter re-evaluation.
- Unavailable Telegram/native adapters fail closed and cannot fabricate address, proof, signature, transaction or settlement.
- Guard: `tests/architecture/test_wallet_provider_adapter_layer.py`.

## Dual development/release CI recurrence protection — v171.74

- A release-profile source file is linted by development CI and copied into the release archive; therefore one defect can fail both archive contours.
- PostgreSQL resource contexts must satisfy Ruff `SIM117` without weakening database assertions.
- FastAPI route collections may contain internal marker objects without `path`; route guards must ignore only those markers and continue enforcing the exact required path set.
- Release metadata `source_head` must be derived from the requested release version, not a stale hardcoded archive name.
- Release pytest must work from the release root without an external `PYTHONPATH` wrapper.
- The release builder must support direct CLI invocation and package-module invocation without external path preparation.
- Semantic version `v171.74` must map to archive token `v171_74`; ENV image tags remain dotted semantic versions, while ZIP filenames use underscores.
- Guards: `ops/release/ci_profile/test_release_archive_contract.py`, `tests/architecture/test_operator_kernel_routes.py`, Ruff, and the minimal release CI profile.
- Fresh exact-HEAD GitHub CI remains required; local success cannot certify it.

## FastAPI route-tree recurrence protection — v171.77

- Do not assume every object in `app.routes` has `.path`.
- FastAPI 0.137+ route inventories must use the supported
  `fastapi.routing.iter_route_contexts()` API.
- Older supported FastAPI versions use the guarded recursive compatibility
  collector in `app.release.route_validation`.
- Hidden production routes remain mandatory; OpenAPI is not a complete route
  inventory.
- Guard: `ops/release/ci_profile/test_release_archive_contract.py`.

## First-panel referral wiring recurrence protection — v171.77

- Symptom: panel debit and panel rows committed, but the inviter reward and
  `referral_links.activated_at` were never produced.
- Root cause: `on_user_first_panel_activation()` was tested only as an isolated
  function and had no runtime caller in `panels_service.activate_panel()`.
- Deeper risk: using the ordinary committing bank helper inside the panel
  transaction would prematurely commit the higher-level state machine.
- Treatment: wire the hook after panel creation and before transaction exit;
  use `credit_user_bonus_from_bank_nocommit`; propagate reward failures so the
  whole first activation rolls back.
- Guards: `test_first_panel_referral_wiring_guard.py`,
  `test_first_panel_referral_activation_runtime.py`, and the standalone release
  archive contract.
- Forbidden proof: a direct unit call to the referral hook is not evidence that
  panel activation invokes it.

## Referral first-creation recurrence protection — v171.78

- Referral ownership is fixed only with the first PostgreSQL player row.
- Valid invite creates the player and direct link in one transaction.
- No invite creates a permanent 0 user and no referral reward.
- Existing players cannot be attached, reattached or reassigned.
- Invalid invite creates no player.
- Profile and money services cannot implicitly create players.
- Public bind/attach and Admin referral mutations are prohibited.
- A direct invitee's first panel pays `0.1 EFHCb` to the inviter.
- Active direct-referral thresholds 10 / 100 / 1000 / 3000 / 10000 pay
  automatic one-time level rewards 1 / 10 / 100 / 300 / 1000 EFHCb.
- Unit and level rewards stay in the same first-panel transaction and use
  separate idempotency keys.
- Guards: single-entrypoint architecture scan, PostgreSQL onboarding and
  activation tests, and standalone release acceptance.

## Referral level reward restoration — v171.79

- v171.78 removed automatic monetary level rewards without direct permission.
- Root cause: per-referral activation reward and level milestone rewards were
  incorrectly treated as the same economic mechanism.
- Restored thresholds: `10→1`, `100→10`, `1000→100`, `3000→300`,
  `10000→1000 EFHCb`.
- Manual Admin payouts remain prohibited; restoration is automatic runtime
  behavior only.
- Guards: level contract, five-credit dependency-light test, PostgreSQL
  integration and packaged release acceptance.

## Referrals page product-contract protection — v171.80

- The public Referrals route must keep next-Lvl progress, referral-link sharing,
  inline Active/Inactive segmented lists and explicit `Lvl 0–5`.
- Level economics come from backend stats, not duplicated frontend constants.
- Lvl 1 cumulative truth is `10 × 0.1 + 1 = 2 EFHCb`; `1.1 EFHCb` is only the
  incremental tenth-referral event, not the total earned by the threshold.
- Guards: `test_referrals_page_canon_v171_80.py`,
  `test_referrals_progress_bonus.py`, PostgreSQL cumulative reward integration
  and standalone release acceptance.

## Referral EFHCb hidden-subtotal protection — v171.82

- Symptom: Lvl 5 displayed direct rewards `1 000`, current Lvl reward `1 000`
  and total `2 411` without exposing accumulated earlier Lvl rewards `411`.
- Root cause: the API had `cumulative_level_bonus`, but the public page did not
  render it; generic `EFHC` labels also hid the bonus-balance asset.
- Treatment: all referral payments are explicitly `EFHCb`; API and UI expose
  `1 000` direct + `1 411` cumulative Lvl = `2 411 EFHCb`.
- Guards: `test_referral_bonus_cycle_efhcb_v171_82.py`, page/locale guards,
  PostgreSQL reward integration and standalone release acceptance.

## CI Admin seam and panel replay recurrence protection — v171.82

- Generated Admin withdrawal validators must be rebuilt from the generator and
  stay aligned with backend/OpenAPI fields, including the outcome-preview
  parser. A manual generated-file-only patch is forbidden.
- A repeated panel activation request with the same idempotency key must resolve
  the original result before checking the caller's current balance or current
  panel limit.
- Replay evidence must match the original Telegram user and quantity and must
  contain the original panel identifiers; otherwise the request fails closed.
- Version literals, Ruff and the executable-source line limit are delivery
  gates, not optional cleanup.
- Guards: `test_ci_v171_82_admin_and_panel_replay.py`, PostgreSQL panel replay,
  frontend typecheck/build, version-sync and max-line tests.

## Shared development/release Ruff import-order recurrence — v171.83

- Symptom: both archives passed all runtime, database, test and frontend
  gates but failed delivery on the same two Ruff `I001` findings.
- Cause: shared production files kept SQLAlchemy imports in a position
  inconsistent with the repository Ruff/isort classification.
- Treatment: place the SQLAlchemy imports after the app-service import
  blocks exactly as required by Ruff.
- Guard: `tests/architecture/test_ci_v171_83_ruff_import_order.py` plus
  the mandatory Ruff gate in both archive CI profiles.
- No functional code or canonical economics changed.


## Referral TG-ID/API/integration recurrence protection — v171.84

- LEGACY runtime still uses Telegram `tg_id` for current referral,
  panel and financial ownership; this is compatibility state only.
  New architecture uses `UserId` and must never mix it with `tg_id`.
- Active/Inactive SQL must filter inside `WHERE` before `ORDER BY` and use a
  stable `(invited_at, invitee_tg_id)` cursor.
- Archived panels preserve permanent referral activation.
- User routes are self-only; deprecated compatibility routes return `403` for
  foreign TG IDs and include `X-EFHC-Deprecated-Route`.
- Admin totals include direct and Lvl reward reasons.
- Reward idempotency is re-read after row locks so concurrent threshold
  crossings do not roll back a valid panel on a late unique conflict.
- Real PostgreSQL runtime/API tests are mandatory and separate from static AST
  guards.
- Invalid supplied referral codes remain fail-closed without creating a user.
- Guards: `tests/integration/test_referral_runtime.py`,
  `tests/integration/test_referral_api.py`,
  `tests/test_referral_static_contract.py`, and release acceptance.


## Exact-HEAD release evidence recurrence protection — v171.86

- Incident: the active local pre-release gate hardcoded historical v171.67 CI
  intake and v171.69 repair evidence, so a later HEAD could be overstated as
  locally complete without fresh exact-HEAD proof.
- Root cause: evidence selection was version-literal-driven and did not require
  equality between evidence `source_head` and the active development HEAD.
- Treatment: derive the current archive from `release_config/UPDATE_POLICY.json`,
  discover CI intake reports dynamically, accept only exact `source_head`
  matches, report historical evidence as rejected and fail closed as
  `LOCAL_RELEASE_CANDIDATE` when exact-HEAD CI is absent.
- Guard: `tests/architecture/test_provider_independent_release_portability.py`.
- Prohibited workaround: relabeling, copying or aliasing an older green CI report
  as proof for the current archive.


## Referral activation/test-depth recurrence protection — v171.86

- Incident: activation was implemented both in CRUD and as inline service SQL;
  selected integration tests bypassed production onboarding, and an
  arithmetic-only function was labelled as integration proof.
- Treatment: one locked CRUD transition returns `activated_now`; the service
  rewards only the transition owner; critical tests use real onboarding and
  panel purchase; GitHub JUnit requires 25 collected and zero skipped tests.
- Guards: `tests/integration/test_referral_runtime.py`,
  `tests/architecture/test_referral_runtime_depth_guard.py`, and
  `ops/ci_checks/assert_pytest_junit.py`.
- Fresh exact-HEAD GitHub CI remains required.

## HEAL-0118 / CASE-0131 — fresh CI PostgreSQL and lock repair v171.87

- Cycle: 1590.
- Severity: P0 financial concurrency and CI delivery blocker.
- Evidence: release run `82060386826` green; development run
  `82058627460` failed Ruff and PostgreSQL integration.
- Root causes: untyped asyncpg binds, stale panel-balance expectation,
  and `FOR UPDATE SKIP LOCKED` on a user monetary row.
- Treatment: explicit PostgreSQL casts, blocking `FOR UPDATE`, corrected
  canonical balance assertion and exact Ruff cleanup.
- Guards: runtime-depth, static referral and packaged release contracts.
- Prohibited workaround: skipping integration tests, weakening Ruff or
  restoring `SKIP LOCKED` for same-user monetary operations.
- Proof boundary: fresh exact v171.87 GitHub CI required.

## HEAL-0119 / CASE-0132 — plan assertion and frontend route inventory

- Cycle: 1591.
- Development CI used a valid PostgreSQL indexed plan but failed because the
  test required one exact panel index name.
- The test now parses JSON plan nodes and accepts the canonical panel index
  set without permitting a sequential-scan regression.
- One active inventory now covers all 34 physical routes in the screen
  registry, source map and visual manifest.
- Real local all-pages Chromium proof is prepared but not claimed: local
  `npm ci` was blocked by registry HTTP 503.
- The automatic non-blocking `frontend-visual-evidence` workflow runs the
  34-route by 3-viewport cycle without making PNG a blocking Canon input.
- Fresh exact v171.88 GitHub CI remains required.
## HEAL-0120 / CASE-0133 — Activ status split truth v171.89

- Cycle: 1592.
- Evidence: exact v171.88 development and release CI are green; the
  defect was exposed by semantic audit rather than a failing gate.
- Symptom: public counters/lists and Admin user detail could remove an
  already activated referral after physical panel deletion, while Admin
  referral summary kept the user active.
- Root cause: `panels` rows and `referral_links.activated_at` were both
  treated as status sources, reinforced by ambiguous Kernel wording.
- Treatment: every runtime consumer reads the permanent Activ activation
  flag; `panels_count` is display-only; legacy Admin `ref_links` SQL is
  replaced with canonical `ReferralLink` ORM queries.
- Guard: one destructive PostgreSQL test checks counters, public list,
  Admin summary and Admin user detail after all invitee panels are
  deleted. GitHub requires 25 integration tests and zero skips.
- Prohibited workaround: deriving Activ from `EXISTS(panels)`, active
  panel count or `panels_count`, or replacing the PostgreSQL test with a
  source-text assertion.
- Proof boundary: local structural guards pass; fresh exact v171.89 CI
  is required.
## Identity canon drift recurrence protection — v171.91

- Historical runtime documents defined `global_id` as the EFHC owner.
- The active doctrine separates `UserId` and `TelegramId`.
- Old runtime truth remains LEGACY compatibility, not target canon.
- New domain `tg_id` use or count growth fails the V2 guard.
- Telegram-specific files require an explicit allowlist entry.
- Direct and indirect provider/system conversions are forbidden.
- Wallet addresses and provider subjects cannot become `UserId`.
- Cycle 1594 hash-locks schema and ownership runtime while adding only
  side-effect-free identity type contracts.
- Guards: `ops/identity/check_tg_id_domain_boundary.py` and
  `ops/identity/check_user_id_contract_patch_boundary.py`.
- Schema work requires a later exact route and reconciliation gate.
\n- HEAL-0124 / CASE-0137: schema changes after a stamped `0001` require a\n  new linear revision. Cycle 1597 uses `0002` for nullable user_id EXPAND.\n
