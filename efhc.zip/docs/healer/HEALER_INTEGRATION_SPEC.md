# HEALER INTEGRATION SPEC

Healer на текущем этапе — автономный внутренний реестр проекта EFHC.

В релизном архиве он состоит из:

- `ops/healer/`
- `docs/healer/`
- `atlas.json`
- `casebook.json`
- `HEALER_ATLAS.md`

Healer не обязан зависеть от:
- GitHub Actions logs;
- `reports/`;
- временных аудитов;
- внешнего error-registry.
