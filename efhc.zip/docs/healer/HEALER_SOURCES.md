# HEALER SOURCES

Каноничные источники Healer внутри релиза:

- `atlas.json`
- `casebook.json`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- профильные SSOT-документы проекта

Legacy источник для ретро-сверки:

- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
  (read-only legacy snapshot)
