# HEALER WORKFLOW

1. Найти симптом в коде, архиве или аудите пользователя.
2. Сверить симптом с документацией проекта.
3. Проверить исключения.
4. Подтвердить болезнь.
5. Сразу записать карту болезни в `atlas.json`.
6. Если лечение уже найдено — занести его в карту и casebook.
7. Если лечение ещё не найдено — оставить
   `treatment_status: pending`.
8. Когда лечение найдено позже — обновить `casebook.json` и
   `docs/healer/HEALER_CASEBOOK.md`.


## Запись в три места

После подтверждения болезни доктор обязан:
1. обновить `atlas.json`;
2. обновить `casebook.json`;
3. сделать запись в `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`;
4. сделать запись цикла в `docs/history/legacy_artifacts/reports/`.

## Правило аудита документации

Сначала сверять обзорные документы с `docs/SSOT/ssot_pack/*`,
потом обновлять Healer, реестр и reports.
## Critical delivery algorithm

For archive/handoff work, after the normal Healer write:

1. synchronize all current HEAD documents;
2. classify screenshots as `fresh`, `inherited` or `none`;
3. build the main and optional screenshot archives;
4. run `ops/healer/check_critical_delivery_protocol.py`;
5. on failure set `BLOCKED_PROTOCOL` and stop delivery;
6. only a PASS receipt grants `USER_DELIVERY_ALLOWED`;
7. the final response must use clickable artifact links and show requested
   screenshots with their true provenance.

