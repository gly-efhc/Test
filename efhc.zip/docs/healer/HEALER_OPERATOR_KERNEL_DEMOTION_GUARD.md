# HEALER_OPERATOR_KERNEL_DEMOTION_GUARD

Status: ACTIVE PREVENTIVE GUARD.
Archive: `v171.63`.

## Failure patterns

- KERNEL described as navigation only;
- project keywords removed;
- canonical anchors or route map removed;
- proof/patch boundaries removed;
- full archive reading replaces route-backed reading;
- a line-count limit is used to force loss of operational content.

## Treatment

1. Restore active Kernel role as full dispatch layer.
2. Restore keywords, anchors, route summaries and boundaries.
3. Preserve full historical Kernel separately.
4. Replace regression guards that enforce demotion.
5. Mark release blocked until behavior tests pass.

## Independent evidence

`test_operator_kernel_full_restore_v171_62.py` and governance entrypoint guard.
