# HEALER_OPERATOR_KERNEL_DRIFT_GUARD

Status: ACTIVE PREVENTIVE GUARD.
Archive: `v171.63`.

## Incident pattern

Kernel behavior drifts away from its SSOT while files and reports still claim Operator Kernel is active.

## Root-cause indicators

- YAML route changes do not change runtime behavior;
- hardcoded Python routes become primary truth;
- context capsule returns only a reading list;
- machine indexes are treated as full-read documents;
- targeted task becomes broad archive reading.

## Treatment

1. Restore YAML-primary route resolution.
2. Restore bounded context excerpts and exact file sets.
3. Add behavior tests with temporary YAML changes.
4. Refresh machine map and summary.
5. Block release claims until guards pass.

## Independent evidence

`tests/architecture/test_operator_kernel_routes_runtime_v171_62.py` and exact local test logs.
