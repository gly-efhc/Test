# Каталог тестов EFHC Bot (SSOT)

Этот документ — единый индекс всех тестов в репозитории. Нумерация **общая** по всем группам.

## Правило внесения новых тестов (MUST)

- Любой новый файл теста (`tests/**/test_*.py`) **обязан** быть добавлен в этот документ.

- Для каждого теста: 3 строки описания по шаблону ниже (без воды).

- Если тест касается запретов/сканов — обязательно указать, какие файлы исключены (логи/артефакты) и почему.


**Шаблон 3 строк:**

1) Что проверяет.
2) Где/как ломается (типичная причина).
3) Зачем это важно для канона.


---


## A) Architecture Guards (repo-wide канон)

1. `tests/architecture/test_api_finance_canon.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

2. `tests/architecture/test_deposit_packages_contract.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

3. `tests/architecture/test_exchange_mirror_and_locks.py`
   Exchange: механика обмена/зеркальность/аудит/правила списаний.
   Центральная финансовая логика, ошибки тут = потери.

4. `tests/architecture/test_financial_integrity.py`
   Артефакт/упаковка: FLAT-zip, структура проекта, целостность.
   CI должен распаковывать и запускать проект одинаково.

5. `tests/architecture/test_forbidden_identifiers_repo.py`
   Запреты repo-wide: недопустимые идентификаторы/термины.
   Предотвращает возврат алиасов/запрещённых слов и ‘грязные’ правки.

6. `tests/architecture/test_frontend_tabs_canon.py`
   Frontend guards: требования к Telegram API и запреты по UI-SSOT.
   Чтобы фронт не ломал канон чисел/идентификаторов/инициализации.

7. `tests/architecture/test_great_canon_guard.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

8. `tests/architecture/test_max_line_length_72.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

9. `tests/architecture/test_migrations_numbering_canon.py`
   Канон чисел: Decimal(scale=8) + ROUND_DOWN, запрет float/Number.
   Финансовая точность и воспроизводимость расчётов.

10. `tests/architecture/test_no_available_kwh_direct_debit.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

11. `tests/architecture/test_no_banned_rank_terms.py`
   Запреты repo-wide: недопустимые идентификаторы/термины.
   Предотвращает возврат алиасов/запрещённых слов и ‘грязные’ правки.

12. `tests/architecture/test_no_tg_id_aliases_repo.py`
   Канон идентификатора: только tg_id, без алиасов.
   Единый идентификатор = совместимость API/БД/логов/SSOT.

13. `tests/architecture/test_no_total_generated_kwh_decrement.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

14. `tests/architecture/test_panels_no_local_numeric_casts.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

15. `tests/architecture/test_repo_file_integrity_manifest.py`
   Артефакт/упаковка: FLAT-zip, структура проекта, целостность.
   CI должен распаковывать и запускать проект одинаково.


## D) Root / Integration (сквозные проверки)

16. `tests/test_build_sanity.py`
   Санити CI-цепочки: базовые проверки импорта/guard/компиляции.
   Быстро ловит поломки сборки до глубоких тестов.

17. `tests/test_canon_guard_negative.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

18. `tests/test_concurrency_exchange_all.py`
   Конкурентность/гонки: двойные запросы и атомарность переходов.
   Защита от двойных списаний/двойного approve и рассинхронизаций.

19. `tests/test_concurrency_exchange_withdraw.py`
   Конкурентность/гонки: двойные запросы и атомарность переходов.
   Защита от двойных списаний/двойного approve и рассинхронизаций.

20. `tests/test_concurrency_withdraw_double.py`
   Конкурентность/гонки: двойные запросы и атомарность переходов.
   Защита от двойных списаний/двойного approve и рассинхронизаций.

21. `tests/test_exchange_audit_fields_complete.py`
   Exchange: механика обмена/зеркальность/аудит/правила списаний.
   Центральная финансовая логика, ошибки тут = потери.

22. `tests/test_frontend_telegram_api_guard.py`
   Frontend guards: требования к Telegram API и запреты по UI-SSOT.
   Чтобы фронт не ломал канон чисел/идентификаторов/инициализации.

23. `tests/test_gen_rate_vip_switch.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

24. `tests/test_migrations_upgrade_head.py`
   Миграции: Alembic upgrade head на Postgres и правила миграций.
   Гарантирует, что продовый путь БД проходит в CI.

25. `tests/test_no_banned_identifiers.py`
   Запреты repo-wide: недопустимые идентификаторы/термины.
   Предотвращает возврат алиасов/запрещённых слов и ‘грязные’ правки.

26. `tests/test_no_banned_lotteries_terms.py`
   Запреты repo-wide: недопустимые идентификаторы/термины.
   Предотвращает возврат алиасов/запрещённых слов и ‘грязные’ правки.

27. `tests/test_no_placeholders.py`
   Запрет заглушек: TODO/FIXME/PLACEHOLDER и подобные маркеры.
   Не допускает ‘недоделано’ в релизной ветке.

28. `tests/test_panels_180_days.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

29. `tests/test_panels_active_archive.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

30. `tests/test_panels_global_id.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

31. `tests/test_panels_idempotent_create.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

32. `tests/test_panels_ssot_backend.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

33. `tests/test_panels_uses_canon_formatter.py`
   Panels SSOT: жизненный цикл, идемпотентность, правила сроков.
   Критично для генерации/покупок/архивации и отчётности.

34. `tests/test_payment_intent_status_owner_only.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

35. `tests/test_payment_intents_ab_ssot.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

36. `tests/test_payment_intents_lifecycle_double_payments.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

37. `tests/test_payment_intents_payload_unique.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

38. `tests/test_payment_intents_usdt_tx_and_confirm.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

39. `tests/test_per_sec_constants_settings.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

40. `tests/test_per_sec_literals_guard.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

41. `tests/test_tonconnect_wallets_ssot.py`
   Wallets/TonConnect: семантика подключения и hardening-валидации.
   Безопасность кошельков и корректный учёт привязок.

42. `tests/test_total_generated_kwh_append_only.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

43. `tests/test_ui_ssot_no_float_number.py`
   Канон чисел: Decimal(scale=8) + ROUND_DOWN, запрет float/Number.
   Финансовая точность и воспроизводимость расчётов.

44. `tests/test_unmatched_incoming_recording.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

45. `tests/test_utcnow_ssot.py`
   Канон времени: только tz-aware UTC (server_now_utc), без naive.
   Убирает расхождения по времени и ошибки расчётов/аудита.

46. `tests/test_wallets_connect_hardening.py`
   Wallets/TonConnect: семантика подключения и hardening-валидации.
   Безопасность кошельков и корректный учёт привязок.

47. `tests/test_wallets_tonconnect_semantics_guard.py`
   Wallets/TonConnect: семантика подключения и hardening-валидации.
   Безопасность кошельков и корректный учёт привязок.

48. `tests/test_withdraw_state_machine.py`
   Withdraw state machine: статусы, переходы, финальные состояния.
   Нельзя ‘перепрыгивать’ статусы и терять аудит.


## B) Core (ядро/математика/идемпотентность)

49. `tests/core/test_core_math_econ.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

50. `tests/core/test_monetary_idempotency_middleware.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.


## C) Backend Unit (модульные SSOT-тесты)

51. `tests/efhc_backend/unit/test_cursor_codec_ssot.py`
   Cursor SSOT: кодек/версия/обратимость/стабильность пагинации.
   Пагинация должна быть воспроизводимой и совместимой.

52. `tests/efhc_backend/unit/test_exchange.py`
   Exchange: механика обмена/зеркальность/аудит/правила списаний.
   Центральная финансовая логика, ошибки тут = потери.

53. `tests/efhc_backend/unit/test_finance_spend_rules.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

54. `tests/efhc_backend/unit/test_no_legacy_words.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

55. `tests/efhc_backend/unit/test_orders.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

56. `tests/efhc_backend/unit/test_prizes_autocycle_ssot.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

57. `tests/efhc_backend/unit/test_prizes_smoke.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

58. `tests/efhc_backend/unit/test_shop_items.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

59. `tests/efhc_backend/unit/test_ssot_idempotency.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

60. `tests/efhc_backend/unit/test_ssot_tg_only.py`
   Канон идентификатора: только tg_id, без алиасов.
   Единый идентификатор = совместимость API/БД/логов/SSOT.

61. `tests/efhc_backend/unit/test_telegram_init_data.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.

62. `tests/efhc_backend/unit/test_transactions.py`
   SSOT/инварианты проекта
   Ловит регрессии, которые ломают канон/экономику/CI.


63. `tests/architecture/test_artifact_full_build_required.py`
   Гарантирует, что артефакт проекта содержит полный SSOT‑пакет (docs + реестр).
   Ловит «урезанные» сборки, где исчезают документы или журнал ошибок.
   Важно: запрещает исключать файлы из артефакта без разрешения пользователя.
