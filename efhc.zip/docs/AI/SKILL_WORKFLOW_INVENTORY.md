# SKILL WORKFLOW INVENTORY — ACTIVE

Этот документ отражает только текущий рабочий inventory. Historical tools/audits не участвуют в Kernel routing.

| Path | Class | Purpose |
|---|---|---|
| `START_HERE.md` | `ROUTER` | single active entry point |
| `KERNEL.md` | `PERMANENT_PROCESS_LAW` | single active Kernel contract |
| `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md` | `ROUTING` | single active documentation navigator |
| `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md` | `PERMANENT_PROCESS_LAW` | current OWNER/AI process law |
| `docs/AI/FRONTEND_READING_ORDER.md` | `ROUTING` | minimal reading order |
| `docs/AI/FRONTEND_ARCHIVE_LAWS.md` | `PERMANENT_PROCESS_LAW` | current archive law |
| `ELEMENT_AUTHORITY_POLICY.md` | `AUTHORITY` | current EAM ownership policy |
| `ELEMENT_AUTHORITY_MATRIX.json` (absent; awaiting OWNER replacement) | `RETIRED` | Do not treat obsolete matrix as authority; reconstruct only after OWNER provides new matrix. |
| `ops/operator_kernel/run.py` | `ROUTER` | Kernel executable |
| `ops/operator_kernel/skill_runtime.py` | `TOOL` | Skill resolver/runtime |
| `tools/build_eam_registry.py` | `TOOL` | current registry maintenance only |
| `tools/check_eam_registry.py` | `GUARD` | current registry integrity only |
| `ops/release/check_frontend_archive_scope.py` | `GUARD` | archive scope verification |
| `ops/reports/check_frontend_reports_scope.py` | `GUARD` | report scope verification |
| `frontend/scripts/verify-production-assets.mjs` | `GUARD` | release asset verification when routed |
