# Topic Reading Routes — EFHC Bot

Status: ACTIVE COMPATIBILITY ROUTE GUIDE.
Archive: `v171.67`.

Operator Kernel is a mandatory part of startup navigation. Machine routing uses `ops/operator_kernel/cache/file_map.json` and `ops/operator_kernel/config/routes.yaml`.
Canonical runtime routes: `ops/operator_kernel/config/routes.yaml`.

This document is a human-readable companion only. It does not define startup order and does not override YAML.

## Common entry

```text
START_HERE + KERNEL
→ file_map.summary.json
→ classifier/resolver
→ exact route
→ exact source and tests
```

Full `file_map.json` is machine-only. Full Healer history, reports, audits and cycles are read only through explicit forensic/regression routes.

## Main route families

- Frontend/visual: Visual Public UI NORM, visual contract, screen registry, affected route/component/tests and real `page.goto()` proof.
- Six-button navigation: fixed order/routes/icons/locales/responsive guards.
- Telegram/TonConnect/TonProof/transactions: wallet/withdraw SSOT and exact frontend/backend proof tests; live evidence remains external.
- I18N: Russian semantic source, language/localization SSOT/NORM, affected locale files and visual proof when output changes.
- CI/logs: exact fresh log and failing files; targeted then bounded validation; local runs are not GitHub CI.
- Healer/regression: `HEALER_CAPSULE.md` first, then only linked cases/evidence.
- Governance/archive: archive-law chain, active SSOT index, Architectural Locks, current change report and archive hygiene.

For exact file lists, use `routes.yaml` and `EFHC_OPERATOR_KERNEL_ROUTE_MAP.md`.

Authority: `docs/AI/AI_ARCHIVE_LAWS.md` and its active lock remain mandatory.

## Public UI screenshot QA preparation

- `PUBLIC_UI_NEXT_RANGE_EXTENSION_CHECKPOINT.md` routes through
  `public_range_extension_checkpoint`.
- `PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md` routes through the real
  route-backed visual proof workflow.

Public UI screenshot QA covers the real routes `/withdraw` and `/ads`.
