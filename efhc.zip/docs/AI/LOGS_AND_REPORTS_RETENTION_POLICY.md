# EFHC Logs, Reports, Audits and Cycles Reading Policy

Status: ACTIVE AI EXECUTION POLICY.
Archive: `v171.67`.

This file fixes how logs, reports, audits and cycle history are loaded without overloading the active context.

## Storage rule

Reports, audits and cycles remain in the main development archive until the user orders a separate history archive. They are preserved as history/evidence and do not create CANON, SSOT or NORM.

## Default reading limit

Without an explicit historical request, read no more than the latest two entries from each relevant historical layer:

- latest two task-relevant reports;
- latest two task-relevant audit records;
- latest two cycle records;
- latest two relevant log records only when logs are supplied or routed.

“Latest” is determined by the active index and semantic archive/cycle sequence, not by filesystem modification time alone.
The report/audit/cycle index may be read first to identify those two entries.

## Older history

Any entry older than the latest two is opened only when:

- the user explicitly asks for history, comparison or a specific old record;
- a forensic/regression route requires it;
- an active Healer case points to it;
- a current failure repeats a known old failure class;
- cycle reconciliation cannot be completed from the latest two entries.

## Forbidden default loading

Do not load by default:

- the full `docs/history/legacy_artifacts/reports/` tree;
- the full `docs/history/legacy_artifacts/docs/audits/` tree;
- the full `docs/history/legacy_artifacts/docs/cycles/` tree;
- all historical logs;
- old continuation prompts or temporary plans.

## Integrity and CI truth

Historical records are not silently rewritten. Create a corrective report or explicit superseding note.
Only a user-provided fresh exact-HEAD GitHub log can confirm GitHub CI green. Local checks are `LOCAL_AUX_CHECK_ONLY`.
