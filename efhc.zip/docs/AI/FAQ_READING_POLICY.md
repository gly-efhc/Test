# EFHC FAQ Reading Policy

This file fixes the default FAQ reading rule for EFHC Bot.

## Canonical default

RU is the mandatory canonical FAQ reading language for normal startup.

Reasons:

- the admin/operator contour is Russian-first;
- the user works with the assistant in Russian;
- key project decisions and cycle summaries are written in Russian;
- one canonical language reduces repeated semantic noise;
- forbidden wording and panel activation canon are easier to control.

## Other languages

All other FAQ languages remain in the archive.
They must not be deleted or downgraded.

They are translation and QA layers, loaded only for:

1. multilingual audit;
2. release multilingual QA;
3. translation repair;
4. user-facing locale task;
5. direct comparison with RU canon.

## catalogs.ts policy

`frontend/src/data/faq/catalogs.ts` is not part of default reading.
It is loaded only for FAQ, i18n, build or release QA tasks.

## Evidence rule

The assistant may not make factual claims about a non-RU FAQ language
unless that language file was actually read in the current task.

## No deletion rule

The optimization changes reading order only.
It does not remove the 13-language localization commitment.

## Semantic alignment rule

For FAQ repair tasks, RU FAQ is the default canonical reading language, but it
must be checked against `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` and FAQ
approval records when a regression is suspected. If RU and EN differ, EN is a
translation layer, not a stronger source of truth. If Q/A shows that RU itself
regressed, do not rewrite blindly; create a semantic alignment audit and mark
the item as needing canon decision.

## FAQ semantic gate rule

For FAQ work after semantic repair, do not continue visual/TMA/TonConnect work until
FAQ semantic alignment is confirmed. Read `QUESTIONS_AND_ANSWERS_REGISTER.md`,
`FAQ_APPROVAL_MANIFEST.json`, `FAQ_APPROVAL_REGISTER.md`, `FAQ_SSOT.md`, Russian
FAQ, and the changed FAQ language files before claiming semantic approval.

If RU FAQ and EN FAQ diverge, treat EN as a translation layer. If RU FAQ and Q/A
diverge, treat the item as a semantic gate issue rather than guessing.


## Russian source translation rule

All FAQ translations must be made from the verified Russian meaning. English FAQ is a translation layer, not the semantic authority, whenever Russian FAQ/SSOT and Q/A provide a verified meaning.

Forbidden: translating Russian FAQ from English, using stale English text to override Russian Q/A meaning, or marking a non-Russian FAQ language semantic-approved when it was translated from an unverified English drift.
