# EFHC Reading Entrypoint

Status: ACTIVE COMPATIBILITY POINTER.

Operator Kernel is a mandatory part of start-core navigation.
Kernel preload (MANDATORY): use the compact summary and exact route.
Archive: `v171.70`.
Delivery cycle: `cycle 1578`.

Operator Kernel is mandatory startup navigation. The single canonical startup order is `START_HERE.md`; this file is a compatibility pointer.
It must not define an alternative order.

Current state: the v171.70 clean-first-boot release candidate is
locally complete. Empty-database migration, exact 44-table validation,
idempotent system seed, strict routes, scheduler and one-command deploy
are prepared. Docker/VPS, Telegram, wallet, transaction and second-
provider recovery proof remain deferred and unverified.

Load `START_HERE.md`, then `KERNEL.md`, read the compact
`ops/operator_kernel/cache/file_map.summary.json`, then resolve the
exact route through `ops/operator_kernel/config/routes.yaml`. Do not
full-read the archive when an exact route exists.

Authority remains `docs/AI/AI_ARCHIVE_LAWS.md` and its active lock.

The full `ops/operator_kernel/cache/file_map.json` remains a machine artifact and must not be loaded during ordinary startup.
