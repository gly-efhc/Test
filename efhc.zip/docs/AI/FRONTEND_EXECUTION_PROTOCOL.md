# EFHC Frontend Execution Protocol — continuity after Cycle0432 reports normalization

## Актуальное решение OWNER — 25 октября 2026 года

**OWNER / актуальный приоритет:** после каждого завершённого материального блока обязательны один номерной отчёт и полный ZIP-SAVEPOINT с двумя HTML, независимо от готовности CI. Тесты разрешено чинить без ослабления; зависимости обновляются только вверх. DigitalOcean разрешён для изолированной инженерной работы до прямого запрета. GitHub применяется по текущему OWNER scope. Один полный заключительный тестовый прогон выполняется после основной серии исправлений; адресные проверки допустимы. `PARTIAL` остаётся честным статусом. См. `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`.


Status: active procedural protocol after completion of `FRONTEND_ADMIN_CYCLE_0432` number-first reports/cycles migration and reporting-canon hardening.

## 1. Authority

This protocol does not replace project authority. The authoritative order remains:
1. exact physical/repository HEAD and immutable release artifacts;
2. project SSOT/CANON/NORM and OWNER instructions;
3. immutable numbered reports and exact-head CI evidence;
4. `PROJECT_GUARDIAN_STATE.json` only as a derived, non-authoritative continuity/cache checkpoint.

If derived state conflicts with physical evidence or SSOT, derived state is invalid and must be rebuilt, not defended.

## 2. Minimal session recovery

At the start of work on the active scope read only:
1. exact `main` HEAD;
2. `START_HERE.md`;
3. `PROJECT_GUARDIAN_STATE.json`;
4. only the specific authority/source files required by the next bounded action.

Do not rebuild the full project context from old reports, old workflow logs or ChatGPT memory when the derived checkpoint is valid.

## 3. Invalidation instead of repetition

When `PROJECT_GUARDIAN_STATE.json.checkpoint_source_head` differs from current `main`, compare the intervening commits once. Re-run or re-read evidence only for checks whose inputs changed.

Default invalidation map:
- docs/report/state-only change → no product checks invalidated; reports integrity only when numbered reports changed;
- frontend package/lock change → npm audit, typecheck, regression, build, performance budgets;
- frontend source/CSS change → typecheck, regression, build, performance budgets;
- backend Python typing-only change → mypy for affected scope + targeted tests; EFHC CODE changed-file verification;
- API/OpenAPI/routes/database change → schema/release parity + OpenAPI parity + targeted tests;
- final closure → one full exact-head qualification regardless of previous targeted PASS evidence.

A PASS remains valid until an input relevant to that check changes. Old logs must not be reread merely to reconfirm a stored PASS.

## 4. Bounded corrective execution

Every current/planned cycle record has one Cycle ID (`NNNN`) and Status, Objective, Scope, Protected / Out of scope, Required work, Qualification / DONE, Closure. Canonical template: `docs/NORM/FRONTEND_CYCLE_TIMEBOX_CANON.md`; records: existing active roadmap/cycle documents. Ranges are prose group references only, never cycle identifiers or shared status entries. `0452+` denotes a future lane; exact cycles/scope require OWNER. Historical completed reports remain immutable. No additional governance/check layer.


Each work block has one coherent objective and may contain several related tasks. One final numbered report summarizes the finished block/cycle or a genuinely independent completed iteration, after the set of work is complete. Group 5–10 related tasks in one report; small fixes, checks, commits, pauses and timeboxes never create separate reports. Multiple reports within a MAIN-cycle require genuinely independent completed blocks. Recover all missed tasks in one consolidated recovery report with factual block/cycle/Git provenance, without retrospective reports per microtask. Report, cycle and physical-release sequences are independent. Prefer the smallest unprotected blocker that can be closed without changing protected semantics.

Report navigation is non-blocking during active work: stale README/pointers/manifest metadata is repaired as `REPORT_NAVIGATION_DRIFT` inside the same iteration; strict numbered-report integrity is enforced at closure.

For each work block:
1. take the next blocker from `PROJECT_GUARDIAN_STATE.json`;
2. inspect only its required source/authority;
3. make the minimum patch;
4. run only invalidated targeted checks;
5. accumulate results of all related tasks and necessary evidence/file inventory for the final report, without reporting after each small fix;
6. update derived continuity state only when materially required;
7. after each completed material work block, create one mandatory consolidated immutable numbered report and advance manifest numbering, even when the current status is PARTIAL. Always materialize a full physical ZIP + matching HTML/SHOP SAVEPOINT when material state changes; report/cycle/release numbers remain independent;
8. stop without starting the next cycle.

Do not launch another broad audit when a blocker already has sufficient evidence.

## 5. Tool roles

Only this OWNER-approved plugin stack may be used: **EFHC CODE, PostHog, Linear, Notion, Context7, DigitalOcean, Railway, Atlassian, GitHub**. Any other plugin requires prior OWNER approval.

- **EFHC CODE** — governance/orchestration/report/release/verification routing for the bounded cycle.
- **GitHub** — repository source/history/CI authority; bounded sync only, never interactive file-by-file workspace.
- **Linear** — primary work-state metadata: issues/projects/cycles/blockers/approvals; no code/log duplication.
- **Railway** — runtime/deploy services, environments, logs, metrics, variables, domains and deployment state; no workflow/source authority.
- **PostHog** — product analytics/telemetry, flags, experiments, errors/session replay/surveys; no source/work-backlog authority.
- **Context7** — current library/framework/SDK/API/CLI documentation used before technology-specific implementation/debugging; no project authority.
- **Notion** — durable long-form project knowledge when explicitly useful; no source/history/CI or primary backlog authority.
- **DigitalOcean** — persistent remote SSH engineering environment when local workspace is insufficient; no source/deploy authority.
- **Atlassian** — reserve-only Jira/Confluence/Bitbucket/Loom/internal knowledge branch, activated only by OWNER; never a parallel implementation backlog while Linear is primary.

Causality: `OWNER → EFHC CODE → local workspace`; optional evidence branches flow through the relevant approved plugin, then return to the same bounded cycle/report. Repository verification flows `local → GitHub → CI evidence`. Runtime evidence flows through Railway; product-behavior evidence through PostHog.

## 6. Immutable process laws

- Persistent `_import/` is an OWNER-protected transfer boundary. It remains present in workspace, GitHub repository and full physical release. Primary repository transport is the complete `FRONTEND_vNNN.zip` uploaded by OWNER into `_import/`; the sync workflow mirrors the repository to that release, removes only the transport ZIP after success, and must preserve `_import/README.md`. Imported payloads are staging only and never become runtime authority.
- Physical Frontend archive ceiling is 19 MiB (19,922,944 bytes).

- Operator Kernel startup is single-invocation per chat/session; a failed/closed invocation is not rerun automatically.
- `FRONTEND_ADMIN_CYCLE_0431`, `0432` and `0433` are DONE. Cycle0434 establishes dynamic non-blocking report navigation and the OWNER-approved nine-plugin control plane. Cycle0435 is DONE; Cycle0436 is DONE; Cycle0437 is DONE; Cycle0438 is DONE after OWNER-authorized technical reconciliation. Cycle0439 remains OWNER ASSIGNED / NOT STARTED.
- Admin remains FROZEN.
- Theme03 remains OWNER-FROZEN / IMMUTABLE.
- TON/wallet/financial semantics remain protected.
- Existing report contents are immutable; one final report covers a completed work block/cycle, including several related tasks. Separate reports require genuinely independent completed blocks/iterations, not microtasks or timeboxes. Missed reporting is recovered in one consolidated report. The single machine authority is `reports/FRONTEND_REPORT_MANIFEST.json`; no parallel numbering CSV.
- Existing physical `FRONTEND_vNNN` checkpoints are immutable once issued.
- Material release changes are packaged only as the next physical `FRONTEND_vNNN` lineage with matching root HTML/SHOP identity.

## 7. Closure condition

For **VERIFIED / COMPLETE** all required exact-HEAD gates must truly PASS and blockers be closed/classified. For **SAVEPOINT / PARTIAL** unresolved diagnostics and missing remote CI are explicitly recorded, but a physical checkpoint is still mandatory after material changes. In both cases final archive integrity checks VERSION, CRC, duplicate entries, archive ceiling, ENV, persistent `_import/` and matching HTML. STOP if physical integrity fails; do not withhold an otherwise sound SAVEPOINT solely because product CI is unavailable.

Historical Cycle0429 is not retroactively closed. Its remaining mandatory convergence/reproducibility work is scheduled across OWNER-assigned Cycles0435–0444. Each future cycle closes only its bounded scope with the required exact-head evidence and physical release discipline.

Reports/process Cycles0432–0434 and the Global Themes lane starting at Cycle0451 remain separate scopes and do not absorb Cycle0429 residual blockers. Cycle0445, Cycle0446, Cycle0447, Cycle0448, Cycle0449 and Cycle0450 each remain OWNER RESERVED / NOT STARTED.

This protocol exists specifically to prevent repeated context reconstruction, repeated log reading and checks that are not invalidated by changed inputs.
