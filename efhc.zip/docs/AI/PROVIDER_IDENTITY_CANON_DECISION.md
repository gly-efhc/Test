<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# AI decision — provider identity canon

Статус: `APPROVED / MUST IMPLEMENT NEXT CYCLE`.

- Business owner: `global_id` only.
- Telegram boundary: `tg_id` only; remove `tg_provider_id` and `telegram_provider_id`.
- TON boundary: `ton_address`.
- Google boundary: `google_id`.
- Apple boundary: `apple_id`.
- Facebook boundary: `fb_id`.
- Discord boundary: `discord_id`.
- GitHub boundary: `github_id`.
- Universal identity key: `provider + subject → global_id`.
- One `global_id` may have multiple provider identities.
- One provider identity must never map to multiple `global_id` values.
- After resolution, business services accept only `global_id`.

The next cycle must implement this canon across runtime, schema, API, tests, guards and alias cleanup without re-opening the naming decision.
