<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# AI decision — provider identity canon

Статус: `APPROVED / ACTIVE` — TON subject уточнён пользователем 2026-08-08.

- Business owner: `global_id` only.
- Telegram boundary: `tg_id` only; remove `tg_provider_id` and `telegram_provider_id`.
- TON boundary: `ton_wallet_id`.
- Google boundary: `google_id`.
- Apple boundary: `apple_id`.
- Facebook boundary: `fb_id`.
- Discord boundary: `discord_id`.
- GitHub boundary: `github_id`.
- Universal identity key: `provider + subject → global_id`.
- One `global_id` may have multiple provider identities.
- One provider identity must never map to multiple `global_id` values.
- After resolution, business services accept only `global_id`.

Канон реализуется во всех active слоях. `ton_wallet_id` содержит адрес TON-кошелька; отдельного числового TON provider ID нет.
