# AI decision — provider identity canon

Статус: `APPROVED / MUST IMPLEMENT NEXT CYCLE`.

- Business owner: `global_id` only.
- Telegram boundary: `tg_id` only; remove `tg_provider_id` and `telegram_provider_id`.
- TON boundary: `ton_address`.
- Google boundary: `google_id`.
- Apple boundary: `apple_id`.
- Facebook boundary: `fb_id`.
- Discord boundary: `discord_id`.
- GitHub boundary: `github_id`.
- Universal identity key: `provider + subject → global_id`.
- One `global_id` may have multiple provider identities.
- One provider identity must never map to multiple `global_id` values.
- After resolution, business services accept only `global_id`.

The next cycle must implement this canon across runtime, schema, API, tests, guards and alias cleanup without re-opening the naming decision.
