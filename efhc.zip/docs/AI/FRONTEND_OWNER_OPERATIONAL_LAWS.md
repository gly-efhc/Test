# FRONTEND OWNER OPERATIONAL LAWS — ACTIVE

Назначение: единственный текущий процессный контракт AI для EFHC Frontend. История не является рабочим authority.

1. Последний физический `FRONTEND_vNNN.zip` — единственный рабочий HEAD. Прямое решение OWNER выше любого документа.
2. Старт работы: `START_HERE.md` → однократный read-only startup Kernel → `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md` → только выданный route. Для последующей OWNER-итерации допускается 1 штатный task-specific Kernel и при необходимости 1 обоснованный повтор; **максимум 2 запуска за итерацию и 8 за MAIN-cycle суммарно**, включая FAIL-CLOSED; не создавать фиктивные итерации ради обхода.
3. `CANON/SSOT/NORM/AI` содержат только актуальные данные. История допускается только в `reports/cycles/` и `reports/` и читается лишь по прямой задаче аудита/регресса.
4. Scope закрыт: файл, тест, guard или задача вне Kernel whitelist запрещены без прямого OWNER-разрешения. `Finding != Work`.
5. Kernel обязан выдать `GOAL`, `ALLOWED_READ`, `ALLOWED_WRITE`, `ALLOWED_CHECKS`, `FORBIDDEN`, `STOP_CONDITION`, `EXPECTED_OUTPUT`. **OWNER Cycle0511/iteration02:** максимум **8 запусков Kernel за цикл и 2 за итерацию**; каждый FAIL-CLOSED учитывается в обоих счётчиках. Третий в одной итерации или девятый в цикле запрещён. Новый цикл/итерация без прямого OWNER scope не открывается. `FAIL-CLOSED` и file whitelist обязательны. Стартовый read-only bootstrap выполняется отдельно по однократному intake-контракту. История Cycle0509 (2/2) неизменна.
6. Проверки не накапливаются. Повторять проверку можно только после изменения проверяемого source либо по прямой команде OWNER.
7. Regression reference — последняя версия, прямо признанная OWNER хорошей, плюс ближайшие изменения после неё. Historical test/guard не запускается по умолчанию.
8. Если failing check уже воспроизводится на baseline, это `BASELINE/OUT_OF_SCOPE`; он не расширяет текущую работу.
9. Product↔standalone parity проверяется только если текущий scope затрагивает обе поверхности.
10. Admin имеет **только визуальную заморозку** (дизайн, стили, геометрия, утверждённый внешний вид). Исправление подтверждённых ошибок Admin source/logic/API/typing/lint/security/test — приоритет и не блокируется визуальной заморозкой при наличии текущей OWNER-задачи. Изменение визуального решения требует отдельного согласования; защищённые финансовые/identity/TON/ENV контракты сохраняются. См. `docs/SSOT/ADMIN_FREEZE_CANON.md`.
11. Backend/main, deploy, commit/push, установка dependencies и реальные payment/on-chain действия запрещены без прямого OWNER-разрешения.
12. Нельзя ослаблять lint/type/security/test configuration или переписывать историю ради PASS.
13. Финансовая точность: external business D2; internal accounting D8; TON/GRAM D9; USDT D6.
14. Рабочие архивы/HTML именуются только `FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`; префиксы/суффиксы запрещены.
15. `Артефакты` физически находятся вне project root и никогда не индексируются Kernel/active documentation.
16. Сообщение OWNER немедленно прерывает длинную рабочую цепочку: сначала ответ, затем продолжение только если требуется.
17. **OWNER CHAT CLOSURE.** Closure обязан быть коротким и человеческим: ID+статус, `Сделано: ...`, physical release если обязателен, `Следующий цикл: ...`. Сами два смысловых вопроса как заголовки/boilerplate печатать запрещено. При отсутствии утверждённого плана называется только следующий последовательный номер без выдуманного scope. Technical dump, numbered-report replay/link и service artifacts в обычный чат запрещены.

18. **REPORT AUTHORITY / NON-BLOCKING NAVIGATION.** `docs/NORM/EFHC_REPORTING_RULES_TZ.md` + `docs/NORM/FRONTEND_REPORT_STANDARD.md` + `reports/rules/00002__rules_dynamic_reports_navigation_nonblocking_work.md` управляют будущей отчётностью. Historical completed reports immutable. Во время активной итерации stale report pointers/README/manifest metadata = `REPORT_NAVIGATION_DRIFT`: исправляется динамически и не блокирует уже OWNER-authorized work. Строгая physical+manifest sequence является closure gate. Hard stop только при ambiguous/colliding physical identity, historical data-loss/corruption risk или неразрешимом authority conflict. Перед closure допускается ровно один bounded preflight и не более одной корректировки; recursive validators/retry loops запрещены.

19. Report, MAIN-cycle и physical-release numbering независимы. Один OWNER-authorized cycle может содержать несколько bounded итераций, несколько immutable reports и несколько physical checkpoints. Отдельный report нужен только для реально самостоятельного завершённого блока/итерации; связанные задачи одного цикла собираются в один итоговый report после завершения набора работ. Мелкие fixes/commits/timebox не создают reports. Новый MAIN-cycle не расходуется автоматически на каждую итерацию. Material state, для которого release law требует checkpoint, не считается физически закреплённым до выпуска следующего `FRONTEND_vNNN.zip` с matching HTML/Shop. Следующий cycle не стартует автоматически.

20. Канонический Frontend timebox — **15–20 минут на bounded итерацию**. Один OWNER-authorized cycle может состоять из нескольких рабочих отрезков; timebox не является основанием для нового report. 5–10 связанных задач внутри цикла фиксируются одним итоговым report после завершения рабочего блока. Scope организуется bounded без автоматического открытия нового cycle. Temporary/service files классифицируются как `DELETE_DIRECT / REQUIRED_EVIDENCE / REVIEW`; только конечные release artifacts выдаются OWNER без отдельного запроса.

21. Нельзя задерживать требуемый physical checkpoint необязательным QA. Physical release создаётся независимо от report/cycle numbering; один cycle может иметь несколько releases. Если текущий material state требует checkpoint, он закрепляется matching `FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`.

22. В обычном cycle запрещены повторный полный аудит, соседний refactor «для порядка», несколько одинаковых archive/manifest checks и чтение всей истории без прямой причины.
23. Roadmap/source provenance is typed: an existing physical path may be read as source; an OWNER/provenance label is metadata and never becomes a filesystem requirement merely because it appears in `Source`; a token that is path-like and missing remains fail-closed. Multi-source declarations preserve this rule per source token.
24. Целевая reports-архитектура: `reports/numbered/` = итоговые numbered reports законченных рабочих блоков, `reports/cycles/` = cycle documents, `reports/rules/` = numbered rules. Historical contents immutable; OWNER-authorized migration может менять path/number identity с anti-loss proof. Reports — не журнал каждой мелкой операции. Один report объединяет все задачи законченного блока/цикла; несколько reports допустимы только для реально самостоятельных завершённых блоков/итераций. Пропущенная запись нескольких задач восстанавливается одним сводным report по фактической истории, без размножения reports на микрозадачи; уже завершённые reports сохраняются.

25. **LOCAL-FIRST GITHUB SYNC.** Основная разработка выполняется в одном локальном workspace текущего чата. GitHub нельзя использовать как интерактивную файловую систему для постоянного чтения/микроопераций. Закон: локальные bounded изменения → один логический repository sync → GitHub CI/tests → чтение только необходимого evidence → продолжение локально.
26. **PERSISTENT FULL-RELEASE IMPORT BOUNDARY.** `_import/` — постоянная OWNER-protected папка local workspace, GitHub repository и physical release. Автоматическое удаление `_import/` запрещено. Основной repository-update transport = полный immutable `FRONTEND_vNNN.zip`, который OWNER загружает в `_import/`. Workflow обязан зеркально синхронизировать repository с полным архивом и после PASS удалить только transport ZIP, сохранив `_import/README.md`. Patch-only transport не является основным механизмом. `_import/` не является runtime/source authority.
27. **ARCHIVE CEILING.** Текущий OWNER ceiling full physical Frontend archive = **19 MiB = 19,922,944 bytes**. Снижение размера не является самостоятельной целью и не разрешает удалять `demo/`, reports, chats, evidence или protected/current authority.

28. **PLUGIN WHITELIST.** Единственный разрешённый внешний plugin stack: `EFHC CODE`, `PostHog`, `Linear`, `Notion`, `Context7`, `DigitalOcean`, `Railway`, `Atlassian`, `GitHub`. Их роли и причинно-следственные связи определяет `docs/AI/EFHC_AVAILABLE_PLUGINS_AND_SKILLS.md`. Любой другой plugin запрещён к поиску/подключению/использованию как working dependency без прямого OWNER approval.
29. **PLUGIN AUTHORITY BOUNDARIES.** EFHC CODE = governance/orchestration; GitHub = source/history/CI; Linear = primary work-state; Railway = runtime/deploy; PostHog = product telemetry/analytics; Context7 = current external technical docs; Notion = durable knowledge; DigitalOcean = remote engineering execution environment; Atlassian = reserve-only enterprise branch. Atlassian не создаёт параллельный Jira backlog рядом с Linear. Evidence из plugins возвращается в bounded cycle; ни один plugin не переопределяет OWNER/physical HEAD/SSOT/CANON/NORM.
30. **NEW PLUGIN APPROVAL GATE.** Если whitelist недостаточен, сначала формулируется отсутствующая capability и причина, затем OWNER согласует конкретный новый plugin. До согласования plugin expansion запрещён.

31. **VERSION CONFLICT — UPGRADE-ONLY / НИКАКОГО ПОНИЖЕНИЯ (прямое решение OWNER).** Если возникает конфликт версий одного и того же компонента между CI, production/runtime, SDK, зависимостями, lock-файлами, локальным окружением, контрактами или физическим архивом, согласование и исправление **ВСЕГДА** выполняются в направлении более новой версии. Понижение запрещено даже временно, ради совместимости, обхода ошибок, упрощения CI или прохождения тестов. Подтверди обе реальные версии из файлов/выводов, определи более новую, адаптируй устаревшую часть и её зависимости к более новой версии в пределах прямого OWNER scope. Нельзя молча изменять утверждённые pins/lockfiles и protected contours: если обновление требует дополнительного scope или технически недоступно — `BLOCKED`, сообщение OWNER и запрос конкретного разрешения; не откатывайся на старую версию. Это правило относится к **разрешению реальных конфликтов** и не является командой обновлять всё до `latest` или выполнять внешние операции без OWNER-разрешения.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Постоянное прямое правило OWNER: ни один ENV-файл проекта нельзя удалять без прямого решения OWNER.** Это включает `.env`, `.env.*`, production/development/local profiles, templates/examples, recovery copies и будущие ENV-файлы. Удаление+создание замены, потеря исходного пути при migration/refactor/cleanup/release/update и объявление файла legacy не являются разрешением. `.gitignore`, security concern и наличие defaults также не разрешают удаление.

Cycle0447 прямо разрешает восстанавливать отсутствующие подтверждённые несекретные settings и исправлять их конфликт с OWNER canon в существующей ENV-архитектуре. Существующие значения сохраняются без основания для изменения; секреты не менять, не публиковать и не угадывать. **Application configuration values, numeric settings, public URLs and public blockchain addresses are NOT project secrets.** **EFHC Bank address is public canonical project data and must not be deleted.**

Публичный SSOT: `TON_MAIN_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW` — EFHC Bank / Банк EFHC. Payment receiver не должен создавать другой project-wallet canon. Изменения Cycle0447 выполняются commit/PR, без physical release по прямой OWNER-команде. Существующая fail-closed защита physical mirror остаётся действующей; нового approval/governance-слоя нет. Простой Git deletion guard проверяет потерю ENV-файла, без контроля количества ключей.

Подтверждённая несекретная configuration восстановлена из текущего кода/public profiles/templates. Исторический incident неизвестных утраченных runtime/secret values остаётся `RECOVERY_REQUIRED`: они не объявляются восстановленными. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; physical mirror policy: `release_config/ENV_OWNER_PROTECTION.json`; единственный secret-free ENV canon: `docs/SSOT/ENV_PROTECTION_SSOT.md`.



## GLOBAL THEME MATERIALIZATION LAW — OWNER Q&A 2026-10-14…15

**Cycle0454 supersession:** the reset/materialization rules below are historical Cycle0452 compatibility behavior. For canonical v17 Color Theme state, color selection MUST NOT rewrite `interface_variants`, PB, EI or page/card form IDs. `color_theme_id` is color authority; `interface_variants` is independent design authority. Legacy `global_theme_id/theme_overrides` remain temporary rollback/runtime mirrors only.

- Global Theme selection is a top-level materialization/reset event for theme-linked defaults. Local element customization is allowed after the global selection, but a later Global Theme change re-applies that theme's linked defaults.
- **Cycle0455 current law:** Color Theme changes chroma only and never resets `PB`, `RP`, `EI` or any page/form design ID. Energy `PB` and Referrals `RP` persist independently but share the same 35-slot universal progress-design library. `PB-01..PB-23` retain authored geometry/effects; color-only `PB-24..PB-35` are losslessly quarantined as compatibility aliases to the `PB-01` baseline. Every Energy/Referrals fill is clipped inside its track. `EI-07`, `PB-01`, `RP-01` are common initial Energy defaults only for unset state. Theme09/CT-09 is `#58C7B4`.
- Brand-owned semantics are not theme substitution targets. In particular, Referrals social-share logos keep stable brand colours in every theme and interaction state; theme ownership is limited to the container form/material.
- Shared controls must not receive a one-theme private design unless OWNER explicitly authorizes it. `Ranks → Обновить / Найти меня` are a shared action family; Theme03 must match the same component-state design used by the other themes.

- OWNER architecture direction 2026-10-15: after Cycle0452 migrate to `Color Theme × Universal Design`. Color Theme changes chroma only and preserves selected forms; 10 unique colors replace 13 coupled color/theme identities; current Theme03 design set is the common initial baseline and all other authored designs remain universal. See `docs/frontend/FRONTEND_COLOR_THEME_DESIGN_DECOUPLING_ROADMAP.md`.



## PERSISTENT STATE SPLIT LAW — Cycle0454

- Canonical settings schema = v17. `color_theme_id` stores CT-01..CT-10 and owns color identity only.
- `interface_variants` is the single complete authority for user-selected forms/design IDs. It survives every Color Theme change unchanged.
- Migration from v16/earlier must reproduce the exact legacy effective design once (`stored variants → selected legacy theme set → selected legacy override`) and persist that result as independent `interface_variants`.
- Deterministic color migration is 01→CT-01, 02→CT-02, 03/11/12→CT-03, 04→CT-04, 05→CT-05, 06/10→CT-06, 07→CT-07, 08→CT-08, 09→CT-09, 13→CT-10. Duplicate color identity never deletes design provenance.
- Existing `global_theme_id` and `theme_overrides` are compatibility mirrors for rollback/read compatibility and the still-visible 13-slot projection. They are not v17 design authority.
- Browser/Telegram settings write v17 plus a current v16 rollback payload; standalone writes V041 plus V040 rollback payload.
- Visible selector remains transitional 13-slot until Cycle0459. Chroma-only rendering separation begins Cycle0455.

## COLOR THEME × UNIVERSAL DESIGN LAW — OWNER 2026-10-15 / Cycle0453

- Target architecture is `COLOR_THEME × INDEPENDENT_DESIGN_SELECTIONS`.
- Color Theme names describe colour only. The canonical target catalog contains 10 colours; legacy names that describe layout/character are design provenance, not Color Theme names.
- Color Theme changes chroma only. It does not reset or materialize selected page/element forms after the compatibility migration is implemented.
- The current Theme03 design set is the common initial/default set only when no user selection exists. Theme03 frozen implementation remains reference/protected source and is not rewritten to perform the migration.
- Every existing USER/Shop design variant is preserved and becomes independent of colour unless separately classified as protected semantic/Admin state. Color deduplication does not authorize design deletion.
- Legacy Theme03/11/12 share one Violet Color Theme but retain separate designs. Legacy Theme06/10 share one Graphite Color Theme but retain separate designs.
- Adding a new colour adds one new Color Theme palette and automatically enables the whole universal design library. Per-colour cloning of design variants is forbidden.
- Cycle0455 shadow law: ordinary shadow/elevation is one neutral Theme03-derived canon (`0 14px 34px rgba(0,0,0,.26)`) for every Color Theme and universal design. Glow is separate: DESIGN owns presence/form/intensity; COLOR owns hue.
- Current TON Connect SDK authority is exact `@tonconnect/sdk 5.0.0`; `4.0.2` is historical provenance only and must not appear as a current acceptance baseline.
- Ordinary decorative chroma = COLOR. Form/geometry/composition = DESIGN. Meaning-bearing financial/status/error/warning/accessibility colours = SEMANTIC. External service/provider identity = BRAND.
- Cycle0453 is SSOT/census only. Current 13-theme runtime remains transitional until Cycle0454 establishes backward-compatible state separation and later cycles migrate the UI.
- Canonical Cycle0453 authorities: `frontend/src/design-system/color-theme-registry.json`, `frontend/src/design-system/universal-design-registry.json`, `frontend/src/design-system/legacy-global-theme-decoupling-map.json`, `frontend/src/design-system/theme-ownership-classification.json`, `docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json`.

- **Cycle0455 regression-recovery law (OWNER 2026-10-15):** target `COLOR ≠ DESIGN` is retained, but the broad v685 `color-theme-shared-contract.css` implementation is rejected. A COLOR layer must never seize authored DESIGN background/surface/layout/radius/material through root/global `--tg-*` replacement or broad late `!important`. Current recovery restores the v684 authored visual baseline while retaining safe state/PB-RP35/clipping/TON5 changes. Any future chroma/shadow adapter requires rendered parity over every affected design family before physical release.

## Cycle0464 OWNER-approved Kernel clarification/retry protocol (2026-10-18)

После нового ответа OWNER допускается дополнительный уточняющий Kernel вызов при необходимости, с фактической причиной и явным affected-file whitelist. Повтор после fail-closed возможен при прямом OWNER разрешении на retry или новой точной OWNER-коррекции причинного scope; не делать автоматические бесконечные повторения и не обходить fail-closed. Cycle0464: единственный разрешённый retry исправил неверный `task_class=implementation` → `project_cycle` и завершился PASS.

## OWNER Cycle0464 visual correction — действующий цветовой закон

- Для всех пользовательских Color Themes CT01–CT10 подписи «Заработано за всё время · EFHCb» и «Остаток EFHC бонус · EFHCb» остаются белыми; числовые значения не перекрашиваются. Требование прямо распространяется на CT03, без изменения геометрии или material freeze.
- Кнопка «Мои панели» имеет прозрачную подложку с 2–3% оттенка текущей CT; чужой `--tg-secondary-bg` не является источником её непрозрачного фона.
- Надпись кнопки Ranks «Загрузить ещё» — белая, рамка тематическая, фон почти прозрачный 3%; KG не меняет chroma.
- Каждый экземпляр ярлыка Energy во всех EG-вариантах берёт chroma только из `color_theme_id`, а не из legacy/theme/design.
- CT10: текущий цветовой accent — Muted Gold `#C5A15A` (197,161,90). Legacy Theme13 `#FFD400` сохраняется лишь как историческое происхождение; не использовать его как активный accent CT10.
- Не вводить широкие CSS-repaint selectors. Менять только конкретные декоративные chroma-потребители, сохраняя независимые дизайн-геометрию и material topology, semantic status/brand и защищённые Admin/Shop.
