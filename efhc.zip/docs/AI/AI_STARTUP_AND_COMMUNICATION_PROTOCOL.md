# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# AI Startup and Communication Protocol

Status: ACTIVE AI PROTOCOL.
Archive: `v171.67`.

## Startup

Use only `START_HERE.md`. Begin from the latest canonical ZIP, unpack once, read START_HERE and KERNEL fully, then resolve the smallest exact route through YAML and the short file-map summary.

The sandbox is temporary. Full file map, Healer history, reports, audits, cycles and broad runtime trees are not default preload.

## Communication

- Report material findings and blockers promptly in Russian.
- Use bounded timeouts; stop and preserve the exact boundary when a command hangs.
- Do not repeat questions already answered by the user/archive.
- Ask only when an unresolved choice changes CANON, SSOT, NORM, economy, auth, migrations, security or user-approved product meaning.
- Do not hide decisions only inside documents.

## Verification and delivery

Run the relevant route-selected test/guard package before packaging. Local checks are `LOCAL_AUX_CHECK_ONLY`, not GitHub CI. Frontend proof requires the real application and `page.goto()`; PNG is delivered separately from the main archive.

Every changed pass creates a sequential development archive. Release-ready remains fail-closed until exact external evidence exists.

## Archive numbering

Archive suffixes run from `00` through `99`. After `vN_99`, use
`v(N+1)_00`; `vN_100` and every three-digit minor suffix are forbidden.

## Guard compatibility contracts

Before first release, migration `0002+` requires direct user approval.
Переписывать migration history ради green test запрещено.
Ослаблять, удалять, скрывать или исключать тесты ради green status запрещено.
Перед сборкой каждого архива обязателен прогон релевантного test/guard пакета
