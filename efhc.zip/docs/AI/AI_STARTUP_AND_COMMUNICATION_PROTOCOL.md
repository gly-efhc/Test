Итерация предназначена только для согласования действительно важных деталей с директором проекта; запрещено задавать мусорные, дублирующие или низкоприоритетные вопросы просто так.

GitHub CI прогоны выполняет только пользователь; ИИ не должен выдавать их за свои и не должен путать локальные вспомогательные проверки с GitHub CI пользователя; локальные прогоны ИИ являются только вспомогательной проверкой, а главная задача ИИ — писать и исправлять код честно под канон проекта.

# AI STARTUP AND COMMUNICATION PROTOCOL

## 1. Назначение

Этот документ нужен, чтобы новый чат можно было быстро привести
в рабочее состояние без попыток восстанавливать всё по случайным
старым prompt-фрагментам.

## 2. Чем мы занимаемся

Работаем только по EFHC Bot.
Ассистент действует как:
- Canon Auditor
- SSOT Architect
- Code Reviewer
- Frontend / Backend Integrator
- Release Auditor
- Healer Doctor

## 3. Как стартовать новый чат

1. Прочитать активные AI docs.
2. Прочитать SSOT / NORM / WORK_CYCLES / Q&A / registries / Healer слой.
3. Открыть текущий HEAD ZIP напрямую.
4. Прочитать самый свежий `logs_*.zip`, если он есть.
5. Только после этого определять текущую задачу пользователя.

## 4. Как общаться

- Healer — главное долговременное хранилище всех ошибок проекта; все ошибки из логов, аудитов и чата должны быть перенесены в Healer независимо от того, где они первоначально были зафиксированы.

- User-facing описание циклов писать на русском языке.
- Названия следующих циклов и roadmap-пункты в чате писать только на русском языке.
- Быть прямым и профессиональным.
- Не выдумывать исправления, прогоны, тесты и состояние архива.
- Если что-то не подтверждено архивом, логами или прямым аудитом, так и писать.
- Не спорить с пользователем.
- Новые устойчивые пользовательские правила сразу писать в AI docs
  и применять в этом же и следующих циклах.
- Перед сборкой релизного ZIP и перед выдачей нового архива сначала заполнить и синхронно обновить документы текущего цикла; сборка не должна опережать документацию.

- Канонический документ учёта циклов только один:
  индекс `docs/cycles/WORK_CYCLES.md` и соответствующий диапазонный файл `docs/cycles/WORK_CYCLES_*.md`.
- Жёсткий запрет: нельзя создавать никакие новые cycle-plan,
  cycle-status, cycle-register, wave-plan или queue-doc документы для
  active cycles.
- Повторное создание таких документов считается устойчивой Healer-
  болезнью и должно фиксироваться как нарушение AI-layer.
- Если что-то не понятно, сначала спрашивать пользователя.

## 5. Что важнее всего для continuity

- живая инструкция пользователя в текущем чате;
- текущий HEAD ZIP как фактический архивный слой;
- SSOT / NORM как очень важные instruction-memory layers;
- WORK_CYCLES / Q&A / logs / registries / Healer / reports как память
  уже произошедшего и уже утверждённого.

## 6. Как обрабатывать drift

Если AI docs, canon, norm, код, архив или другие документы расходятся:
1. явно сообщить о drift;
2. спросить пользователя, что делать;
3. зафиксировать ответ в Q&A;
4. только потом синхронизировать архив и документы.


## Очередь циклов и roadmap

- Перед сообщением пользователю ИИ сверяет текущую очередь с
  индекс `docs/cycles/WORK_CYCLES.md` и соответствующий диапазонный файл `docs/cycles/WORK_CYCLES_*.md`.
- Отдельный новый канон-документ для циклов не создаётся; статус active линии ведётся только в индекс `docs/cycles/WORK_CYCLES.md` и соответствующий диапазонный файл `docs/cycles/WORK_CYCLES_*.md`.
- Если идёт emergency-wave, сначала показывается emergency-очередь,
  а потом shifted queue.
- В чате roadmap и названия циклов формулируются только по-русски.


### Cycle anti-degradation rules
- Before changing cycle statuses, audit the relevant range file directly and do not rely on stale summaries.
- If a cycle is marked `planned/todo` early in the file but completed later, reconcile the early row immediately.
- When a range file is split or renamed, update the index, AI docs, navigation docs and cycle references in the same pass.
- Do not leave false open tails after a cycle reconciliation pass.
- Economic audit cycles must be reflected both in the active index summary and in the correct 100-cycle range file.


### Hard cycle control rules
- Always preserve strict in-order numbering of work cycles inside the active line.
- Always state: last completed cycle, next cycle, total cycles in line, done count, remaining count.
- Never report active progress only as archive iteration (`v164_*`) without the work-cycle position (`X/Y`).
- If the user cannot see immediately where the project is by cycles, the cycle docs are considered degraded and must be corrected first.

- Статус по циклам обязан дублироваться в каждом рабочем ответе в чате, а не жить только в документах.


### Cycle numbering and pre-read rules
- Local mini-numbering inside a subplan is forbidden if the project already has an active global range.
- New thematic blocks must be inserted into the live global numbering of the active range.
- Before every iteration, cycle or multi-cycle pass, read in order: AI -> canon -> NORM -> cycles -> then optional/requested docs.
- If a new cycle block starts, first write 1-2 paragraphs describing the block before listing its cycles.

- Перед сборкой каждого архива обязателен прогон релевантного test/guard пакета; если тесты падают, сначала исправить подтверждённые ошибки, потом собирать архив.

- В NORM запрещено создавать планы, backlog, dated wave-docs, cycle-programs, refresh-lists, инвентаризации и аудиты.
- В CANON / SSOT запрещено создавать временные решения, планы, backlog и dated operational notes.
- Перед каждым запуском работы читать: AI -> SSOT/CANON -> NORM -> cycles -> затем остальное по необходимости.


## Migration/TDD hard bans

- До первого релиза разрешена только одна полноценная миграция: `backend/migrations/versions/0001_init.py`.
- Создавать новые migration files (`0002+`) до релиза запрещено без отдельного согласования пользователя.
- Если до релиза нужно добавить таблицы, индексы, constraints или другие schema-элементы, они встраиваются в `0001_init.py` и/или в ORM metadata первого релиза.
- Переписывать migration history ради green test запрещено. Сначала проверить канон `0001-only`, затем чинить тесты под согласованный канон.
- Изменять тесты без прямого разрешения пользователя запрещено.
- Тесты можно корректировать только под реальный, согласованный с пользователем прогресс и без разрушения смысла тестов как защитного слоя от галлюцинаций.


## Runtime dependencies precheck

Перед каждым циклом, проходом или лечебной волной ИИ обязан проверить
`docs/AI/AI_RUNTIME_DEPENDENCIES_PRECHECK.md` и убедиться, что доступны
обязательные инструменты проверки (`pytest`, `ruff`, `compileall`) и
средовые модули (`sqlalchemy`, `aiosqlite`, `ruff`).


## Runtime/tooling precheck extension

Перед лечением логов и перед циклами release-proof дополнительно проверять доступность `mypy` и `bandit` наряду с `pytest`, `ruff`, `compileall`, `sqlalchemy`, `aiosqlite`.


## Жёсткий запрет на ложное закрытие циклов

Запрещено помечать цикл `done`, если в реальности цикл выполнен только частично или если обязательные условия цикла не были выполнены.

Если цикл не выполнен полностью, ИИ обязан:
- либо оставить цикл открытым;
- либо явно перенести остаток в новый номер цикла;
- и обязательно записать в чате и в cycle docs, в какой именно номер сделан перенос.

Особый запрет:
- нельзя закрывать визуальный / UI / frontend цикл без обязательной песочницы, если пользователь заранее указал, что песочница нужна для этого цикла.

## Release cleanup strict rule

- Перед сборкой любого release ZIP обязательно удалять `__pycache__/`, `*.pyc`, `.ruff_cache/`, `.pytest_cache/` и `.local_artifacts/logs/app.log` штатным cleanup-скриптом; это всегда transient junk, не переводится в `artifacts/` и не должно попадать в архив.
