# EFHC Context Capsule Protocol

Status: ACTIVE AI PROTOCOL.
Archive: `v171.67`.

## Purpose

A context capsule is a bounded task packet generated from the active Kernel route. It replaces repeated broad reading.

## Required content

- user request and archive name;
- primary and secondary task classifications;
- configured routes and YAML-primary status;
- current cycle/release boundary;
- exact canonical anchors and required reads;
- exact source/test/report targets;
- allowed writes and restrictions;
- bounded relevant excerpts;
- targeted validation;
- proof and archive boundary.

## Limits

Use the budgets in `docs/AI/READING_BUDGET.md`. Deduplicate files shared by multiple routes. A capsule is not proof that every referenced file was semantically verified; exact relied-upon source files must still be opened before factual claims or edits.
