# EFHC — разрешённый plugin stack

Статус: **OWNER-APPROVED / ACTIVE / CYCLE0434**.

Этот документ является единственным current plugin catalog для EFHC Frontend. Для работы разрешены только девять перечисленных ниже плагинов. Любой другой plugin/app/connector считается неразрешённым до отдельного решения OWNER.

## 1. Разрешённые плагины

| Плагин | Когда использовать | Где использовать | Роль / граница authority |
|---|---|---|---|
| **EFHC CODE** | При каждом bounded project-cycle: scope/governance, freezes, report/release discipline, review и маршрутизация verification | Над локальным workspace и проектными authority | Project Guardian/orchestrator. Не хранит source и не заменяет GitHub CI. |
| **PostHog** | Когда задача требует product analytics, funnels/retention, telemetry, feature flags, experiments, error tracking, session replay, surveys или product dashboards | Product-observability слой | Analytics/product telemetry. Не является source/history/work-backlog authority. Read-first; production-impacting writes только по OWNER scope. |
| **Linear** | Для issues/projects/cycles/blockers/approvals и текущего work-state | Основной work-management control plane | Work-state metadata. Не хранить в нём code/CI logs; не создавать параллельный Jira backlog. |
| **Notion** | Когда OWNER требуется долговечная, возвращаемая/совместно используемая документация: PRD, tech spec, architecture/reference docs | Knowledge/documentation слой | Durable knowledge only. Не source/history/CI и не основной backlog. |
| **Context7** | Перед реализацией/отладкой, когда важны актуальные API, library/framework/SDK/CLI/cloud docs | Documentation lookup для конкретной технологии | Current external technical documentation. Не project authority; полученные сведения применяются только в текущем OWNER scope. |
| **DigitalOcean** | Только когда локального workspace недостаточно и нужен persistent remote Linux/SSH engineering workspace | Временная/долгоживущая remote engineering console | Execution environment, не source/deploy authority. Provision/cost/mutations — только по прямому OWNER scope. |
| **Railway** | Для runtime/deploy: services, environments, variables, domains, databases/storage, deployments, logs, metrics, traces, runtime incidents | EFHC runtime/deployment control plane | Runtime/deploy authority. Не project backlog и не repository authority. Destructive/deploy mutations — только по прямой OWNER команде. |
| **Atlassian** | Только при явной OWNER-активации для Jira/Confluence/Bitbucket/Loom/internal knowledge или enterprise coordination | Reserve enterprise knowledge/work layer | **Reserve-only**. Нельзя вести второй implementation backlog параллельно Linear. |
| **GitHub** | Для bounded source/history sync, commits/branches/PR, Actions/CI, exact-HEAD verification и artifacts | Repository control plane | Source/history/CI authority под OWNER/SSOT/CANON/NORM. Не использовать как интерактивную файловую систему. |

## 2. Причинно-следственная схема

`OWNER request → EFHC CODE governance/scope → local workspace`

Далее подключается только нужная ветвь:

- `technology/API uncertainty → Context7 → bounded local implementation`;
- `work-state → Linear`;
- `durable project knowledge explicitly needed → Notion`;
- `bounded repository sync → GitHub → repository-native CI/exact-HEAD evidence`;
- `runtime/deploy task → Railway → deployment/logs/metrics evidence`;
- `product-behavior/telemetry task → PostHog → analytics evidence`;
- `persistent remote shell explicitly needed → DigitalOcean → engineering execution → changes return to local/GitHub bounded flow`;
- `explicit OWNER enterprise/Jira/Confluence task → Atlassian reserve branch`; Atlassian не создаёт второй backlog рядом с Linear.

Любое evidence из внешнего плагина возвращается в текущий bounded cycle через **EFHC CODE** и numbered report. Ни один plugin не имеет права переопределять OWNER, physical HEAD, SSOT/CANON/NORM или protected product contracts.

## 3. EFHC CODE internal Skills

Внутренние Skills `efhc-code-fresh` являются составными частями одного разрешённого плагина **EFHC CODE**, а не отдельными plugins. Активные роли включают governance/context/cycle/report/review/security и repository-native CI routing (`ci-supervisor`, `ci-failure-triage`, `regression-validation`, `release-regression`, `github-verification-routing`), а также `linear-control-plane` и reserve-only `atlassian-control-plane`.

## 4. OWNER approval gate для новых плагинов

Если возможностей этих девяти плагинов недостаточно:

1. остановить plugin expansion;
2. точно назвать недостающую capability;
3. объяснить, почему её нельзя закрыть текущими девятью;
4. предложить конкретный новый plugin только как кандидат;
5. получить прямое OWNER-согласование;
6. только после согласования подключать/использовать и обновлять этот catalog/Kernel/index.

Запрещено самостоятельно искать, устанавливать, подключать, рекомендовать как рабочий dependency или создавать причинно-следственные связи с любым plugin вне whitelist.
