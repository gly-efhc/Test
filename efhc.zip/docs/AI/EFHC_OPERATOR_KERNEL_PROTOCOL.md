<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# EFHC Operator Kernel Protocol

Status: ACTIVE AI PROTOCOL.
Archive: `v171.67`.

## Purpose

Operator Kernel is the active operational dispatch layer of EFHC Bot. It maps project language to the smallest safe route and prevents broad archive reading, canonical drift and unsupported proof claims.

It is not merely navigation and not a duplicate encyclopedia. Full product meaning remains in CANON/SSOT/NORM; Kernel stores explicit anchors, routes, permissions and proof boundaries.

## Runtime pipeline

```text
canonical archive
→ START_HERE
→ detailed KERNEL
→ EFHC-specific/compound classification
→ routes.yaml primary runtime config
→ route resolver
→ short file-map summary + machine lookup
→ deduplicated bounded context capsule
→ exact patch
→ route-selected validation
→ proof/report
→ next sequential archive
```

## Mandatory properties

- `routes.yaml` is primary route truth; Python hardcoded routes are fallback only.
- Classifier recognizes frontend, six-button navigation, Telegram/TonConnect/TonProof, i18n, CI/logs, archive, Kernel repair and control-document optimization language.
- Compound requests use a dedicated compound route or expose secondary task types; a generic token such as `EFHC` cannot override the central request.
- `file_map.json` is machine-only; `file_map.summary.json` is the startup map.
- Context capsules contain bounded excerpts and deduplicate files shared by routes.
- Full Healer/history reading requires an explicit route.
- Frontend work requires real route-backed screenshot proof.
- Local checks remain `LOCAL_AUX_CHECK_ONLY`.
- Release claims require fresh exact-HEAD external evidence.
- Every changed pass ends with a sequential development archive.
- CI/workflow files are manual-control files and remain outside an ordinary repair route.

## Consolidated standard

Patch, permission, validation, anti-demotion and completion rules are defined once in `docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md`.

## Forbidden demotion/drift

Regressions include: navigation-only Kernel; removed keywords/anchors; dead YAML; broad default reading; duplicate active control rules; generic-word misclassification; visual work accepted without real proof; or mixed development/release boundaries.

Authority: `docs/AI/AI_ARCHIVE_LAWS.md` and its active lock remain mandatory.
