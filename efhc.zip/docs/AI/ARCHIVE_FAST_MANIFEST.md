# EFHC Archive Fast Manifest

Status: ACTIVE POINTER.
Archive: `v171.67`.
Cycle: `1574 — ACTIVE / LOCAL RELEASE-CANDIDATE AUDIT`.

Start with `START_HERE.md`, `KERNEL.md`, `routes.yaml` and `file_map.summary.json`.

Current pass:

- cycle 1573 local code/test scope is closed;
- live Telegram, real TonConnect, TonProof and real transaction proof remain unverified;
- by direct user decision those checks are `DEFERRED_POST_RELEASE_BY_USER`;
- cycle 1574 local release-candidate audit is now active;
- no UI/runtime/economic code changed in this transition;
- output remains a development snapshot, not a release archive.
