# FRONTEND READING ORDER — ACTIVE

1. `START_HERE.md`.
2. Operator Kernel — один запуск на итерацию по умолчанию; при необходимости второй; **общий предел 2 за итерацию и 8 за MAIN-cycle** с учётом FAIL-CLOSED. Третий в одной итерации и девятый в цикле запрещены. Новая итерация — только по прямой OWNER-команде. См. `KERNEL.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md` — найти документы, разрешённые Kernel route.
4. Прочитать только `ALLOWED_READ`.
5. Менять только `ALLOWED_WRITE`; запускать только `ALLOWED_CHECKS`.
6. `reports/`, старые cycles и любые исторические документы не читать без прямой задачи OWNER на аудит/регресс.
7. После `STOP_CONDITION` остановиться и отчитаться.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

