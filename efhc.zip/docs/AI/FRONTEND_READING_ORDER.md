# FRONTEND READING ORDER — ACTIVE

## Актуальное решение OWNER — 25 октября 2026 года

**OWNER (актуально):** применять `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md` до выбора маршрута. Разрешены исправление тестов без ослабления assertions, upgrade-only обновление зависимостей и изолированная DigitalOcean-среда. GitHub/remote CI — только по актуальному OWNER scope. Каждый законченный материальный блок завершается обязательным numbered report и полным ZIP-SAVEPOINT + два HTML, включая `PARTIAL`.


1. `START_HERE.md`.
2. Operator Kernel — один запуск на итерацию по умолчанию; при необходимости второй; **общий предел 2 за итерацию и 8 за MAIN-cycle** с учётом FAIL-CLOSED. Третий в одной итерации и девятый в цикле запрещены. Новая итерация — только по прямой OWNER-команде. См. `KERNEL.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md` — найти документы, разрешённые Kernel route.
4. Прочитать только `ALLOWED_READ`.
5. Менять только `ALLOWED_WRITE`; запускать только `ALLOWED_CHECKS`.
6. `reports/`, старые cycles и любые исторические документы не читать без прямой задачи OWNER на аудит/регресс.
7. После `STOP_CONDITION` остановиться и отчитаться.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

## OWNER — физический архив как единственная идентичность запуска Kernel (25.10.2026)

- **Единственный источник исходной версии:** `VERSION` внутри **последнего явно выбранного OWNER-архива** `FRONTEND_vNNN.zip`. Его имя обязано совпадать с внутренней версией; CRC, дубли, пути и исходные артефакты проверяются строго. Нельзя выбирать максимальную версию автоматически или искать старый каталог как HEAD.
- Запуск: `python ops/operator_kernel/run.py --root /workspace --archive /path/FRONTEND_vNNN.zip --clean-extract --json` **только для пустого** `/workspace`; для уже распакованного и изменённого workspace — та же команда **без** `--clean-extract`, с полным перечнем разрешённых `--affected-file`. Допускается `--archive-prefix FRONTEND_vNNN --archive-directory /path` только при точном имени.
- После старта сравниваются побайтово пути исходного ZIP и текущего дерева: **добавления, изменения и удаления допустимы только в перечисленном OWNER whitelist**, иначе FAIL-CLOSED. ENV и `_import/` не являются исключением из сравнения. Разрешённый выпуск следующей версии возможен лишь с явным `VERSION` в whitelist и парой matching HTML; исходный архив не меняется.
- Заголовки, `START_HERE.md`, `KERNEL.md`, `README.md`, roadmap и другие human-readable страницы **не являются версионными authority**. Устаревшие текущие указатели фиксируются предупреждением и исправляются при ближайшем разрешённом выпуске, не вызывая ложного FAIL-CLOSED. **Заголовки без дублирующих номеров**; история выпусков и report provenance сохраняются.
- Номер отчёта определяется `reports/FRONTEND_REPORT_MANIFEST.json`, отдельные текущие указатели в документах не обязательны; каждый законченный материальный блок получает новый numbered report. Next MAIN-cycle не стартует автоматически.
- Реальное нарушение целостности ZIP, неверный `VERSION`, несанкционированные файловые изменения или защищённые потери по-прежнему дают FAIL-CLOSED. Лимиты вызовов Kernel сохраняются.
