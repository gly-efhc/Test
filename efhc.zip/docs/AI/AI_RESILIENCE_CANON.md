# AI RESILIENCE AND SELF-HEALING CANON

Документ фиксирует принципы устойчивости EFHC Bot.

## Базовые механизмы

- guarded transitions;
- idempotency для денежных и статусных POST;
- audit trail;
- soft-fallback вместо тихого молчания;
- self-healing для фоновых задач и пересборок снапшотов;
- обязательная синхронизация overview/docs слоя с SSOT.

## Что это значит на практике

- система предпочитает безопасный отказ скрытому повреждению данных;
- фоновые задачи обязаны логировать исключения и не терять следы
  инцидента;
- критические переходы статусов имеют атомарные условия;
- повторный вызов не должен плодить деньги, панели и выводы;
- обзорные документы должны совпадать с текущим HEAD и SSOT.

## Связанные active-источники

- `docs/SSOT/EFHC_CANON.md`
- `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`
- `docs/SSOT/BANK_CANON.md`
- `docs/NORM/ARCHITECTURAL_LOCKS.md`
- `docs/AI/AI_OPERATOR_RULES_EFHC.md`
- `ops/canon_guard.py`

## Канонический смысл self-healing

Self-healing в EFHC Bot не означает скрытые symptom patches.
Он означает управляемое восстановление через общий канон:
- SSOT;
- guard/tests;
- audit trail;
- детерминированные recovery steps.

Если проблема требует ручного вмешательства, система должна оставить
проверяемый след, а не «проглотить» исключение.

## Операторская устойчивость при log-driven ремонте

- Если свежий CI-log подтверждает зелёный проход, resilience не означает
  выдумывание новых поломок ради активности.
- Если автоматическая массовая правка может повредить канону,
  предпочтителен
  ручной и точечный repair mode.
- Self-healing документации и тестов обязан оставлять проверяемый след
  в:
  - `docs/cycles/WORK_CYCLES_1601-1700.md`
  - `docs/history/legacy_artifacts/reports/change_cycle_*.md`
  - Healer / error registry слое.
- Устойчивость тестового слоя означает не накопление historical locks, а
  поддержание актуального набора active guards под текущий HEAD.

## Continuity resilience between chat and archive

- The archive complements the chat instead of trying to replace it.
- Resilient continuation means reading the current HEAD and memory-layer
  together with the live user instruction from the current chat.
- When these layers drift, the assistant must report the drift and
  update the
  AI layer rather than silently mixing old and new continuation states.

## Русскоязычная итерация и запрет самовольного канона

- Все вопросы пользователю по EFHC Bot задаются на русском языке.
- Если используется английский или технический термин, он должен быть
  объяснён простыми словами рядом с вопросом.
- Если ассистент не уверен в каноне, переводе, удалении, Healer, SSOT,
  NORM, админке или release guard, он обязан остановиться и задать
  русскоязычную итерацию с пояснением.
- Запрещена молчаливая нормализация: ассистент не имеет права сам
  объявлять новый термин допустимым или заменять старый запрещённый
  смысл без ответа пользователя.
- Ошибка ассистента не становится каноном. Источник канона — текущие
  решения пользователя, SSOT, NORM и обязательные AI-документы.
