<!-- EFHC_GLOBAL_IDENTITY_CANON_V2 -->
> **Действующий identity-канон EFHC.** `global_id` — главный
> персональный идентификатор и единственный внутренний account/business
> owner. `tg_id` — только Telegram provider subject. Обязательная
> цепочка: `provider + subject → global_id → business runtime`.
> Внешний `global_id` — string ровно из 10 ASCII-цифр;
> `0000000000` запрещён; numeric coercion запрещён.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# Маршрут цикла 1611

| Keyword / trigger | Task type | Route | Must read | Validation | Запреты |
|---|---|---|---|---|---|
| cycle 1611; user_identities; PG-0 test package; Alembic 0003 | `user_identities_postgresql_package` | `user_identities_postgresql_package` | Global Identity Auth SSOT; migration norm; cycle 1610; accelerated roadmap | ORM/DDL parity; provider subject uniqueness; `mock` forbidden; no data writes; CI immutable; PG-0 not executed | no PostgreSQL install/run, no CI workflow changes, no resolver runtime, backfill, session, ownership или finance |

# Маршрут цикла 1610

| Keyword / trigger | Task type | Route | Must read | Validation | Запреты |
|---|---|---|---|---|---|
| cycle 1610; AuthContext contracts; resolver interfaces; security/redaction skeleton | `auth_context_contracts_foundation` | `auth_context_contracts_foundation` | Global Identity Auth SSOT; migration norm; cycle 1609 provider registry; accelerated roadmap | AuthContext only from GlobalId + VerifiedIdentity; endpoint excludes provider subject/session; resolver is interface only; recursive redaction; Alembic `0002` | no DDL, resolver runtime, account/session issue, login switch, ownership, finance или GitHub CI |

# Маршрут цикла 1609

| Keyword / trigger | Task type | Route | Must read | Validation | Запреты |
|---|---|---|---|---|---|
| cycle 1609; AuthProvider; VerifiedIdentity; provider registry foundation | `auth_provider_registry_foundation` | `auth_provider_registry_foundation` | Global Identity Auth SSOT; migration norm; cycle 1608 registry; accelerated roadmap | exact ASCII provider; fail closed; mock only CI; no domain imports; Alembic `0002` | no DDL, resolver, sessions, login switch, ownership, finance или GitHub CI |

# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# CURRENT IDENTITY ROUTE — v171.95

`cycle 1598`, `LEGACY alias`, `migration harness` and `future backfill`
resolve to `user_id_legacy_alias_harness`. The route forbids database
execution and runtime read switch.

## Retained identity route — v171.94

`historical users.user_id expand`, `historical Alembic 0002`, `PostgreSQL dry-run` route to
`user_id_expand_migration`. The route forbids backfill and read switch.

# EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS

Status: ACTIVE AI ROUTING MAP.
Archive: `v171.93`.

| Keyword / trigger | Task type | Route | Where fixed | Must read | Validation | Notes |
|---|---|---|---|---|---|---|
| cycle 1596; External API/Pydantic UserId contract; PydanticUserId; OpenAPI string user_id | `user_id_api_contract` | `user_id_api_contract` | User Identity Auth SSOT; API Contracts NORM | API contract module; 483-file boundary | Pydantic/OpenAPI tests; no route/DTO switch | no schema or ownership switch |
| cycle 1595; Backend UserId value type; immutable UserId; contract adoption preparation | `user_id_value_type_adoption` | `user_id_value_type_adoption` | User Identity Auth SSOT; Identity Migration NORM | identity types; 481-file boundary | nominal type tests; no runtime import; semantic lock | no schema, AuthContext, DTO or owner switch |
| cycle 1594; UserId contract; negative identity guards; type foundation | `user_id_contract_foundation` | `user_id_contract_foundation` | `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`; `docs/NORM/GLOBAL_IDENTITY_MIGRATION_NORM.md` | UserId types; V2 baseline; patch boundary | strict type tests; semantic mix negatives; hash lock | no schema, AuthContext or ownership switch |
| user_id; global_id to user_id; modular auth; identity resolver; AuthContext; TON Proof login | `user_id_identity_migration` | `user_id_identity_migration` | `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`; `docs/NORM/GLOBAL_IDENTITY_MIGRATION_NORM.md` | identity audit; user model; deps; TON proof; wallet bindings | boundary guard; audit matrix; reconciliation baseline; targeted tests | no Big Bang or financial mutation |
| frontend; visual; UI; UX; screenshots; скриншоты; balance panel; Active; VIP; Telegram viewport; overflow; route-backed; page.goto | `frontend_visual_route_backed_work` | `frontend_visual_route_backed_recovery` | `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`; `docs/frontend/FRONTEND_VISUAL_CONTRACT.md`; `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`; `docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md` | affected route/component; current visual report/script | typecheck/build when available; real `page.goto`; HTTP/route/app-root/errors/overflow; PNG | screenshots in chat and companion archive when required |
| bottom nav; нижние кнопки; нижняя панель; 6 canonical buttons; Energy; Panels; Exchange; Tasks; Referrals; Ranks | `canonical_bottom_navigation_guard` | `frontend_canonical_navigation_guard` | `docs/NORM/ARCHITECTURAL_LOCKS.md`; frontend visual contracts | bottom navigation component/routes/locales/guards | six order/routes/icons/active states; 360/390/430/768; locale proof | no rename/remove/reorder/replace without direct instruction |
| Native-wallet adapter; WalletProvider; Wallet in Telegram; Telegram Wallet Adapter; Native Gram Wallet | `wallet_provider_adapter_work` | `wallet_provider_adapter_layer` | `docs/SSOT/WALLET_PROVIDER_SSOT.md`; `docs/NORM/WALLET_PROVIDER_ADAPTER_NORM.md`; `docs/SSOT/WALLETS_TONCONNECT_SSOT.md` | provider/adapter layer; Layout; deposit; Browser Shop; admin payout; profile | adapter architecture guard; TonConnect/TonProof regression; Kernel route; typecheck when available | unknown API is fail-closed; no invented live proof |
| provider-independent release; OVHcloud; Vercel; Neon; Docker Compose; new VPS; backup restore; pg_dump pg_restore; cycles 1574-1578 | `provider_independent_release_portability` | `provider_independent_release_portability` | provider deployment SSOT; provider release NORM; portability and go-live runbooks | production Dockerfiles, Compose, Caddy, release scripts, gates | portability gate; release secret scan; backup/restore guards; local 99 gate; ZIP integrity | provider is hosting only; external deployment proof remains fail-closed |
| Telegram; Telegram Mini App; WebApp; live Telegram; TonConnect; TonProof; wallet; transaction; transaction contour; connect wallet; real TON; Jetton; live proof | `live_telegram_tonconnect_tonproof_transaction_gate` | `cycle_1573_live_telegram_transaction_contours` | `docs/SSOT/WALLETS_TONCONNECT_SSOT.md`; `docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md`; `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`; `docs/NORM/WITHDRAW_FLOW_NORM.md`; `docs/NORM/WITHDRAW_AUDIT_CANON.md` | exact wallet/TON frontend/backend/tests and current boundary report | targeted backend tests; frontend wallet flow; TonProof envelope; transaction logs; explicit live-unverified statement | never invent signature/tx hash/live proof |
| cycle 1574; local release-candidate audit; идти дальше; deferred post-release | `cycle_1574_local_release_candidate_audit` | `cycle_1574_local_release_candidate_audit` | release-readiness plan; release proof status; Kernel | exact current audit inputs and affected source/tests | bounded local audit; targeted repairs; ZIP integrity; explicit external non-claims | do not repeat impossible external checks without new capability/evidence |
| i18n; 13 languages; локализация; Active; Activ; VIP; English unchanged; gray inactive; translation; hardcoded text | `frontend_i18n_guarded_work` | `i18n_public_surface_guard` | `docs/NORM/LOCALIZATION_WORKFLOW_NORM.md`; `docs/SSOT/LANGUAGE_CANON_SSOT.md`; `docs/frontend/I18N_*.md` | affected locale files/components/audit | hardcoded scan; locale diff; typecheck/build; visual proof | translation cannot change product semantics |
| logs; логи; green logs; GitHub CI; pytest; ruff; mypy; bandit; compileall; frontend build; npm; typecheck | `ci_logs_repair_or_verification` | `ci_log_exact_failure_repair` | AI Archive Laws; execution/validation norms | supplied exact logs; failing source/test; CI config only if authorized | targeted repair then bounded wider check | local check = `LOCAL_AUX_CHECK_ONLY`; no fresh GitHub claim without log |
| archive; архив; new zip; следующий архив; development archive; release archive; screenshots archive; sequential number; v171.64; v171.65 | `archive_build_and_release_boundary` | `archive_numbering_and_release_gate` | Kernel archive boundary; archive/handoff norms | current HEAD/version/report/hygiene script | ZIP integrity; SHA-256; no junk/nested ZIP/secrets; exact file count | development and release archives are separate |
| kernel; Operator Kernel; routes.yaml; route_resolver; task_classifier; file_map; context capsule; anchors; keywords; navigation only; full detailed kernel; v171.47; v171.62; v171.63 | `operator_kernel_full_restore` | `operator_kernel_full_restore_from_v171_47` | preserved v171.47 Kernel; Kernel SSOT; restoration NORM; Kernel protocol/standards | exact restore route files and behavior tests | compileall; route behavior; classifier behavior; map refresh; governance guards | Kernel cannot be demoted again |

| cycle 1573 close; route-backed visual; live TonProof; last cycle; последний цикл в этом чате | `cycle_1573_close_visual_live_proof` | `cycle_1573_close_route_backed_visual_live_ton_proof` | visual NORM/contracts; wallet/TonConnect SSOT; live contour gate; Kernel standard | exact visual proof script, live gate, targeted TON tests, current reports | dependency preflight; route-backed proof; fail-closed live gate; archive hygiene | compound primary route; external evidence cannot be invented |
| optimize Kernel; SSOT; CANON; AI; удалить дубли; объединить; противоречия; сократить названия; размеры документов | `control_docs_optimization` | `control_docs_optimization` | Kernel SSOT/standard/protocol; AI docs index; SSOT index; Architectural Locks | active control docs, duplicate hashes, references, filename inventory | contradiction scan; duplicate scan; behavior tests; before/after size report | unresolved product truth must be asked, not guessed |

## Canonical classifier examples

```text
"Сделай скриншоты нижних 6 кнопок и проверь канон"
→ canonical_bottom_navigation_guard

"Продолжаем live Telegram TonConnect TonProof transaction contours"
→ live_telegram_tonconnect_tonproof_transaction_gate

"Сделай Native-wallet adapter: WalletProvider, Wallet in Telegram и Native Gram Wallet"
→ wallet_provider_adapter_work

"Восстанови полный подробный kernel из v171.47"
→ operator_kernel_full_restore

"Active и VIP должны быть на английском во всех языках"
→ frontend_i18n_guarded_work

"Подготовь циклы 1574-1578 и независимый от OVHcloud Docker release"
→ provider_independent_release_portability
```

| update.sh; обновление архивом; обновлять архивами; полный release archive; rollback.sh; atomic switch | `release_archive_update` | `release_archive_update` | `release_config/UPDATE_POLICY.json`; `release_docs/UPDATE.md`; provider release NORM | update/rollback/extractor/builder | SHA-256; internal manifest; version order; migration class; atomic switch; rollback guards | full archives only; no file-by-file overwrite |
