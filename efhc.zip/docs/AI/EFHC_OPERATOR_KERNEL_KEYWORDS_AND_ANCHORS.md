<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC OPERATOR KERNEL — CURRENT KEYWORDS AND ANCHORS

Статус: **ACTIVE / v173.13 / cycle 1693**.

| Trigger | Route | Required anchors | Result |
|---|---|---|---|
| `global_id`, identity, provider mapping | `global_id_canonicalization` | `GLOBAL_IDENTITY_SSOT`, runtime NORM, identity registry | `provider + subject → global_id → business runtime` |
| `tg_id`, Telegram ingress/delivery | `identity_semantic_registry` | V5 provider-boundary baseline, global owner guard | provider metadata only; owner use forbidden |
| OpenAPI, DTO, frontend seam | `global_id_api_contract` | API contract and seam generators | external `global_id` is a 10-digit string |
| logs, GitHub CI, pytest, Ruff, Mypy, frontend build | `ci_log_exact_failure_repair` | supplied exact logs | causal repair; no readiness claim without new CI |
| tests, archive tests | `active_test_surface` | test manifest and active test guard | old tests remain historical and are not collected |
| release, ZIP, MATRIX | `archive_numbering_and_release_gate` | current state and release policy | CRC, SHA-256, flat RELEASE, byte identity |

Retired triggers `user_id_expand_migration`, `dual_write`,
`shadow_read`, `financial_read_switch` and historical reconciliation do
not resolve to active routes. Their evidence is available only in
`АРТЕФАКТЫ/`.
