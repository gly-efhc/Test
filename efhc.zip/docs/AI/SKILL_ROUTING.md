# SKILL ROUTING

Status: **ACTIVE PERMANENT AI/PROCESS DOCUMENTATION**.

## Route

Kernel validates `skills/registry.json`, validates every registered Skill manifest, verifies dependencies, and fails closed on invalid paths, missing dependencies or dependency cycles.

When task signals are supplied, routing considers structured task class, affected domain, required output and request text. Keyword triggers are only hints and cannot override a conflicting structured task class.

## Selection

Selection is deterministic for the same project state and same task signals. The runtime records:

- task class;
- selected Skill;
- selection reason;
- dependency execution order;
- required authority classes;
- required permissions;
- declared tools;
- minimal relevant context.

Automatic discovery considers only `ACTIVE` Skills. Experimental use requires explicit policy.

## Permissions

Resolution may describe required permissions without executing the Skill. When a granted-permission set is supplied for execution, missing required capability causes fail-closed resolution.

## Dynamic authority

Manifests use authority classes and symbolic context keys rather than release-specific paths. Kernel maps those symbols to the current Physical HEAD, current OWNER decision, active SSOT/CANON, current cycle/report and affected files.

## Composite routing

Composite Skills reference child Skill IDs. Dependency graph expansion and topological ordering are performed by runtime; child workflows are not duplicated into the composite manifest.

## Execution input contract

Routing and execution validation are distinct. During planning, Kernel exposes the union of `required_inputs` for the selected Skill dependency graph without requiring runtime values to be present. When execution supplies an explicit `provided_inputs` set, every declared required input must be present or resolution fails closed.

This preserves low-friction planning while making the transition to execution explicit and auditable.

## Symbolic context integrity

Every required or optional symbolic context key declared by a Skill manifest must be known to the Skill runtime. Broken symbolic context references fail closed during registry/manifest validation. Required context that is known but cannot be resolved from current Kernel state also fails closed before execution planning is returned.

## Kernel purity

Loading Skill Architecture must not mutate a clean Physical HEAD. Operator Kernel disables Python bytecode writes before importing the Skill runtime so that a normal startup check cannot create `__pycache__` and invalidate manifest scope.

## Phase 2 release routes

Formal task classes now include `release_assets`, `reports_integrity`, `archive_scope` and `release_certify`. Structured output signals can resolve these routes directly.

`workflow.release.certify` is the reusable composite release route. It composes release asset preparation, report integrity, archive scope, packaging and exact-final integrity verification rather than restating their procedures.

## Node-level minimal context

The route diagnostic includes `context_plan` keyed by Skill ID. Each node receives only its own declared required/optional context and history policy. The graph-wide `context_keys` union remains available for observability, but it is not permission to preload all union context for every node.
