# FRONTEND ARCHIVE LAWS — ACTIVE

## Актуальное решение OWNER — 25 октября 2026 года

**OWNER 25.10.2026 / SAVEPOINT:** полная физическая тройка (`FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`) обязательна для каждого материального сохранения, **не только для RELEASE/FULL PASS**. Рабочую среду можно продолжать, исходный архив остаётся неизменным. Проверка целостности ZIP, ENV/_import и HTML parity обязательна для каждого SAVEPOINT. `SAVEPOINT / PARTIAL` не выдавать за `VERIFIED / COMPLETE`. Номер отчёта и номер версии независимы; каждый завершённый материальный блок обязательно получает новый номерной отчёт. Подробный канон: `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`.


1. Physical HEAD — последний подтверждённый `FRONTEND_vNNN.zip`; `VERSION`, matching `FRONTEND_vNNN.html` и `SHOP_vNNN.html` должны соответствовать ему.
2. В active project хранятся только актуальные source/config, CANON/SSOT/NORM/AI, roadmap, cycles и reports. Дублирующие/устаревшие governance документы запрещены.
3. История решений хранится только в `reports/cycles/` и `reports/`; она не является default authority.
4. `Артефакты` находятся физически вне project root. Архив не должен содержать папку `Артефакты` и не должен ссылаться на неё как на runtime authority.
5. Admin frozen **только визуально**. Точечные исправления подтверждённых дефектов Admin source/API/backend/runtime/lint/tests разрешены в текущем OWNER scope и приоритетны; внешний вид не менять. Реализация visual lock/functional repair — `docs/SSOT/ADMIN_FREEZE_CANON.md`.
6. Active tests — только текущие non-versioned contracts. Versioned historical regression tests не входят в default suite.
7. Финансовые, wallet/session, API/backend и on-chain contracts нельзя менять через documentation/tooling cleanup.
8. Рабочие имена: `FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`; другие префиксы/суффиксы запрещены.
9. Release integrity: корректный ZIP, CRC, соответствующий VERSION и размер не выше 19 MiB (19,922,944 bytes). Дополнительные gates выполняются только если разрешены текущим Kernel route.

10. Каждый требуемый material physical checkpoint выдаёт ровно три matching current artifacts: `FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`. Physical release numbering независимо от report/cycle numbering; один cycle может иметь несколько checkpoints, а отдельная report iteration не обязана создавать release при отсутствии material state change. Служебные reports/CANON/tests отдельно в чат не прикладываются без прямого запроса OWNER.

11. `_import/` — OWNER-PROTECTED persistent transfer boundary. Папка обязана существовать в full-repository workspace и physical release; автоматическое удаление запрещено. Update payloads внутри неё не являются runtime/source authority. Nested ZIP допустим только внутри `_import/`.

12. **OWNER 2026-10-18 — AUDIT SIDE-CAR EXCLUSION.** Массовые диагностические реестры, CSS-кандидаты, скриншоты и прочие разовые исследовательские приложения допускаются по текущему разрешению OWNER, но выдаются отдельно в чате **вне physical Frontend ZIP**. Архив не используется как хранилище таких sidecars без отдельного прямого разрешения OWNER. Исторические numbered reports и обязательные project CANON/SSOT/NORM/working evidence сохраняются; их нельзя автоматически классифицировать как мусор по названию или размеру.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Постоянное прямое правило OWNER: ни один ENV-файл проекта нельзя удалять без прямого решения OWNER.** Это включает `.env`, `.env.*`, production/development/local profiles, templates/examples, recovery copies и будущие ENV-файлы. Удаление+создание замены, потеря исходного пути при migration/refactor/cleanup/release/update и объявление файла legacy не являются разрешением. `.gitignore`, security concern и наличие defaults также не разрешают удаление.

Cycle0447 прямо разрешает восстанавливать отсутствующие подтверждённые несекретные settings и исправлять их конфликт с OWNER canon в существующей ENV-архитектуре. Существующие значения сохраняются без основания для изменения; секреты не менять, не публиковать и не угадывать. **Application configuration values, numeric settings, public URLs and public blockchain addresses are NOT project secrets.** **EFHC Bank address is public canonical project data and must not be deleted.**

Публичный SSOT: `TON_MAIN_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW` — EFHC Bank / Банк EFHC. Payment receiver не должен создавать другой project-wallet canon. Изменения Cycle0447 выполняются commit/PR, без physical release по прямой OWNER-команде. Существующая fail-closed защита physical mirror остаётся действующей; нового approval/governance-слоя нет. Простой Git deletion guard проверяет потерю ENV-файла, без контроля количества ключей.

Подтверждённая несекретная configuration восстановлена из текущего кода/public profiles/templates. Исторический incident неизвестных утраченных runtime/secret values остаётся `RECOVERY_REQUIRED`: они не объявляются восстановленными. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; physical mirror policy: `release_config/ENV_OWNER_PROTECTION.json`; единственный secret-free ENV canon: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

## OWNER — физический архив как единственная идентичность запуска Kernel (25.10.2026)

- **Единственный источник исходной версии:** `VERSION` внутри **последнего явно выбранного OWNER-архива** `FRONTEND_vNNN.zip`. Его имя обязано совпадать с внутренней версией; CRC, дубли, пути и исходные артефакты проверяются строго. Нельзя выбирать максимальную версию автоматически или искать старый каталог как HEAD.
- Запуск: `python ops/operator_kernel/run.py --root /workspace --archive /path/FRONTEND_vNNN.zip --clean-extract --json` **только для пустого** `/workspace`; для уже распакованного и изменённого workspace — та же команда **без** `--clean-extract`, с полным перечнем разрешённых `--affected-file`. Допускается `--archive-prefix FRONTEND_vNNN --archive-directory /path` только при точном имени.
- После старта сравниваются побайтово пути исходного ZIP и текущего дерева: **добавления, изменения и удаления допустимы только в перечисленном OWNER whitelist**, иначе FAIL-CLOSED. ENV и `_import/` не являются исключением из сравнения. Разрешённый выпуск следующей версии возможен лишь с явным `VERSION` в whitelist и парой matching HTML; исходный архив не меняется.
- Заголовки, `START_HERE.md`, `KERNEL.md`, `README.md`, roadmap и другие human-readable страницы **не являются версионными authority**. Устаревшие текущие указатели фиксируются предупреждением и исправляются при ближайшем разрешённом выпуске, не вызывая ложного FAIL-CLOSED. **Заголовки без дублирующих номеров**; история выпусков и report provenance сохраняются.
- Номер отчёта определяется `reports/FRONTEND_REPORT_MANIFEST.json`, отдельные текущие указатели в документах не обязательны; каждый законченный материальный блок получает новый numbered report. Next MAIN-cycle не стартует автоматически.
- Реальное нарушение целостности ZIP, неверный `VERSION`, несанкционированные файловые изменения или защищённые потери по-прежнему дают FAIL-CLOSED. Лимиты вызовов Kernel сохраняются.
