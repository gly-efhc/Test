# EFHC Archive Synaptic Links

Status: ACTIVE ASSOCIATION MAP.
Archive: `v171.67`.

Operator Kernel is a mandatory part of startup navigation. Machine routing uses `ops/operator_kernel/cache/file_map.json` and `ops/operator_kernel/config/routes.yaml`.

Start with `START_HERE.md` and `KERNEL.md`. Use `file_map.summary.json` for orientation and query full `file_map.json` only programmatically.

- process law → AI Archive Laws lock chain;
- stable product meaning → active CANON/SSOT;
- mandatory application → active NORM/Architectural Locks;
- execution behavior → active AI protocols and Kernel standard;
- recurring defect → Healer capsule → exact case/guard;
- current work → current cycle + latest relevant report/log;
- file navigation → routes.yaml + resolver + machine lookup.

Frontend chain: `route → component → service/query → backend seam → SSOT/NORM → tests → real page.goto evidence`.

Financial chain: `CANON/SSOT → route → service → model/migration → idempotency/atomicity guards → operator UI → factual external evidence`.
