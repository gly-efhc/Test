# EFHC Reading Budget

Status: ACTIVE AI CONTROL.
Archive: `v171.67`.

## Goal

Kernel must reduce context, not justify broad reading. Budgets are ceilings, not targets.

## Normal startup

- Target: 8k–20k tokens.
- Hard ceiling: 30k tokens.
- Contents: START_HERE, active Kernel, archive-law lock chain, compact SSOT/NORM indexes, Kernel standard, keyword map and `file_map.summary.json`.

## Focused task route

- Target: 15k–50k tokens.
- Hard ceiling: 80k tokens.
- Read only exact anchors, source files, tests and no more than the latest two relevant evidence/history entries per layer unless an explicit forensic route requires older records.

## Compound task route

- Target: 35k–90k tokens.
- Hard ceiling: 120k tokens.
- Decompose into primary/secondary routes and remove duplicated reads before building the capsule.

## Heavy forensic audit

Allowed only by explicit user request. It may exceed the normal budget, but must be split into bounded batches with receipts. Full machine maps, Healer history, audits, reports, cycles, frontend/backend/tests are never universal preload.

## Capsule limits

- quick answer: 5k–15k tokens;
- focused patch: 15k–45k tokens;
- CI/log repair: 20k–60k tokens;
- frontend/TON compound work: 35k–90k tokens.

If a route exceeds its ceiling, the resolver must narrow or split the task instead of loading the archive broadly.
