# AI Runtime Dependencies Precheck

Status: ACTIVE AI CONTROL.
Archive: `v171.67`.

Local execution is allowed when required by the selected route, but it is never called GitHub CI.

## Precheck

Before a validation lane, check only the tools that lane needs:

- Python lanes: `pytest`, `compileall`, and where relevant `ruff`, `mypy`, `bandit`;
- backend runtime: required Python modules such as `sqlalchemy`/`aiosqlite`;
- frontend lane: package lock, `node_modules` or registry availability, Node/npm, Chromium/Playwright;
- live lane: operator-supplied evidence paths only; never secrets.

## Bounded execution

- targeted checks first;
- broad build/regression only when relevant;
- explicit timeout and captured stdout/stderr;
- one confirmed external-download attempt, then `BLOCKED_EXTERNAL`;
- no automatic loop after a hang.

Missing dependencies are an environment boundary, not a code success or failure. Continue independent safe work and package an honest development snapshot when possible.

Before archive build, remove `__pycache__`, `*.pyc`, `.ruff_cache`, `.pytest_cache`, `.next`, `node_modules`, temporary logs and nested ZIPs.
