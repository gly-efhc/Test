# CURRENT HEAD — v174.53 / цикл 1795 / CI `87522913463` + Test Authority / Anti-Stale

- GitHub CI `87522913463` проверил exact `v174.52`: SHA-256 `f06ccd41922f753debecf32196815994eb3bc845ed06d9dfa20d6a9959901de0`, checkout `c55f6b0a9478df58b6c2bc40115a282d56fd7913`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install и frontend build. RED: Ruff `4`, Mypy `1`, pytest `4 failed / 1738 passed / 22 skipped / 1 warning`.
- Подтверждённые причины: четыре Ruff import-order diagnostics; один Mypy return-type diagnostic в ADS scheduler adapter; один stale hardcoded Admin seam count; один реальный compatibility regression, породивший три pytest failure — `wallets_service._confirm_payment_intent()` не пропускал canonical `external_amount_atomic/external_decimals`.
- Runtime repair ограничен compatibility facade и не меняет финансовую модель: atomic TON/USDT, external EFHC D2, ledger, replay/time barrier, Shop pricing и Oracle/FX prohibition сохранены.
- OWNER DECISION: действует `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`. Тест не является SSOT; authority: OWNER DECISION → CANON/SSOT/NORM → runtime invariant → guard/test. Stale expectation обновляется или удаляется в той же итерации; правильный runtime запрещено откатывать только ради stale implementation test.
- Удалены brittle exact-count locks для mutable test/API surface; behavioural/parity/security/financial invariants сохранены. Structural anti-stale guard включён в test-suite integrity.
- Frozen `0001` не меняется; `0002+` не создаются. Последний exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.53` требует fresh exact-head GitHub CI.
- Immutable report `02371`; следующий `02372`; canonical handoff `EFHC_Bot_v174_53.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.52 / цикл 1795 / CI `87512306629` remediation

- GitHub CI `87512306629` проверил exact `v174.51`: SHA-256 `79d07b081fb73060f1ecd85b0cec61b4800912ade2f865fb7bb2968abfbb0e11`, checkout `1d022dfba994e4f09d35ffdf7f177823abb0b379`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic и npm install. RED: Ruff `6`, Mypy `7`, frontend build `1` TypeScript error, pytest `20 failed / 1722 passed / 22 skipped / 1 warning`.
- Подтверждённые причины сгруппированы: release executable-mode defect; generated frontend/admin seam drift; source lint/type diagnostics; stale qualification expectations после owner-approved Financial Audit №3; history/directory/hash manifest drift.
- Исправления не меняют Shop economics, asset-native TON/USDT settlement, external EFHC D2, withdrawal `Оплатить → Оплачено`, NFT paid gate, Admin audit, ADS reconciliation, P0 temporal barrier или canonical ledger reporting. Oracle/FX не восстанавливаются.
- Frozen `0001` не меняется; `0002+` не создаются. Public source surface остаётся `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`; новые routes в этом цикле не добавлялись.
- Последний подтверждённый exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.52` требует собственного fresh exact-head GitHub CI.
- Immutable report `02370`; следующий `02371`; canonical handoff `EFHC_Bot_v174_52.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.51 / цикл 1794 / Financial Audit №3 remediation

- GitHub CI `87472108257` проверил exact `v174.50`: SHA-256 `ec735a9a631fde9c6275d62b19cdc5b15d53c0b5daca9d3fb85066699df46cc3`, checkout `22d9a9a7b95e42c4980c3019bea6fa53d99807e3`; все recorded gates GREEN, pytest `1729 passed / 22 skipped / 1 warning`. `v174.50` теперь **EXACT-HEAD GREEN**.
- Цикл 1794 исполняет direct owner-approved Financial Audit №3: FIN-01/03/04/05/06/07/08/09 подтверждены source и исправлены; FIN-10 остаётся закрытым, Oracle/FX не восстанавливаются.
- External TON/USDT отделены от EFHC D8 и фиксируются/settle в asset-native atomic units; внешний EFHC deposit/withdraw использует D2 ROUND_DOWN → internal D8.
- Withdrawal разделён на payout evidence и explicit `Оплачено`; NFT unpaid approval запрещён; Shop force-fulfill имеет required Admin audit; zero-price fail-closed; ADS reward reconciliation и canonical ledger reporting добавлены.
- P0 порядок settlement: trusted time → 180-day barrier → replay/idempotency → mutation → ledger. Frozen `0001` неизменён, `0002+` отсутствуют.
- Static public surface после двух новых explicit withdrawal actions: `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`. Live proof — следующий GitHub CI.
- Immutable report `02369`; следующий `02370`; canonical handoff `EFHC_Bot_v174_51.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.50 / цикл 1793 / CI `87405882481` qualification repair

- GitHub CI `87405882481` проверил exact `v174.49`: SHA-256 `efefa2727537f5e81d7e6a8fc679f79ade495bb08e82497d09d71625c6fd2768`, checkout `b69ed98e13c7995343429df2975fe2e893ada297`. SHA payload полностью совпадает с предоставленным физическим HEAD.
- GREEN: Development HEAD SHA-256, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic upgrade, npm install и frontend build. RED только pytest: `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая первопричина — drift русскоязычной инженерной документации: active guard обнаружил `14` новых англоязычных narrative-строк (`6` в `KERNEL.md`, `8` в `START_HERE.md`). Это корректный fail-closed qualification guard, а не stale test и не runtime defect.
- Исправлены только эти `14` строк. Baseline и сам test не изменялись; backend/frontend runtime, Shop pricing, financial SSOT, schema и transaction ownership не откатывались.
- Последний подтверждённый exact-head GREEN остаётся `v174.47` / CI `87290901436`. `v174.50` GREEN не считается до fresh exact-head GitHub CI.
- Immutable report `02368`; следующий `02369`; canonical handoff `EFHC_Bot_v174_50.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.49 / цикл 1793 CI qualification repair

- Run `87290901436` полностью квалифицировал exact `v174.47`: SHA-256 `587c43298864805e7339ce6f88c8f7e284660c59a50449433a5811009b21b698`, checkout `cf3aea612813ce3cf43fe9b64d0ecfcdf35a4976`, все recorded gate exits `0`. `v174.47` = **EXACT-HEAD GREEN**.
- Более новый run `87386543243` проверил exact `v174.48`: SHA-256 `607da2ba1f2643266d2e62eb070790a1f8b3d2e5c3bbd46c31c44208ef22d826`, checkout `6760c21915d6cd605c7e461e99485b043a0fd980`; все recorded gates GREEN, кроме pytest `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — brittle Shop architecture guard: после подтверждения всех runtime invariants он требовал буквальную форму `"ручную цену"`, тогда как active NORM уже фиксирует `администратор независимо задаёт` `price_ton`/`price_usdt` и manual price runtime authority.
- Исправлен только guard: он проверяет канонический смысл, а не падежный литерал. Shop runtime/NORM, owner pricing decision, frozen `0001`, FAQ и FRONTEND_v146 не откатываются.
- Локальные project tests/build/CI не запускались. Immutable report `02367`; следующий `02368`; canonical handoff `EFHC_Bot_v174_49.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.48 / цикл 1793 OWNER DECISION: ручные цены Shop TON/USDT

- **OWNER DECISION:** Shop не использует ценовой оракул, внешний FX-курс или автоматическую конвертацию TON/USDT. Администратор вручную задаёт `price_ton` и/или `price_usdt` для каждой товарной карточки.
- Удалена special-case ветка `CUSTOM_EFHC`: больше нет автоматического курса `0.3 USDT = 1 EFHC` и блокировки TON из-за отсутствия oracle. Любой checkout SKU проходит общий catalog/order flow и использует только сохранённую цену карточки.
- Legacy поле `custom_efhc_amount_d8` оставлено только для обратной совместимости payload и игнорируется Shop runtime; pricing authority оно не является.
- Payment Intent фиксирует выбранную ручную цену на TTL; изменение карточки влияет только на новые intent. Exchange и другие финансовые контуры не меняются.
- Frozen `0001`, отсутствие `0002+`, FAQ standalone authority и visual/UX/text FRONTEND_v146 сохраняются. Локальные project tests/build/CI не запускались.
- Immutable report `02366`; следующий `02367`; canonical handoff `EFHC_Bot_v174_48.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.47 / цикл 1793 CI qualification repair

- Exact GitHub CI `87288059313` проверил `v174.46` SHA-256 `fda32d417d20663ff5c19d9b414d6d6eefe3de06514a13525f661e499b4e8f32`, checkout `64c11a5dba3a081b9aeef4ec59158435e8a10cdb`. Все recorded gates GREEN, кроме pytest: `1 failed / 1727 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — устаревший baseline русскоязычной инженерной политики для `CONTINUE_IN_NEW_CHAT.md`: файл содержит `53` неизменяемых исторических англоязычных snapshot-фрагмента при разрешённом historical count `36`.
- Исторические handoff-фрагменты не переписываются. Baseline повышен строго `36 → 53`; любой следующий новый англоязычный prose-фрагмент остаётся fail-closed нарушением.
- Runtime/backend/frontend/DB не менялись. Frozen `0001`, отсутствие `0002+`, FAQ standalone authority, FRONTEND_v146 и deep-remediation contracts сохранены.
- Immutable report `02365`; следующий `02366`; canonical handoff `EFHC_Bot_v174_47.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.46 / цикл 1793 CI qualification repair

- Exact GitHub CI `87285361835` проверил `v174.45` SHA-256 `3cc9d0a7a3f274b2eaedb89a85a081587a4aad6571a452ead758de24ff8bc75e`, checkout `b527ac44347a7714c3ac927bed6826a4c284218f`.
- GREEN: Development HEAD SHA, Flake8 critical/full, Mypy, Bandit, compileall, PostgreSQL/Alembic, npm install и frontend build. RED: Ruff `1×I001`, pytest `17 failed / 1711 passed / 22 skipped / 1 warning`.
- Подтверждённый runtime defect: Panels после canonical financial SSOT migration всё ещё использовал удалённый `transactions_service.SpendBreakdown`; теперь `SpendBreakdown/split_bonus_then_main` импортируются напрямую из `app.standards.finance_rules`.
- Qualification repair: financial SSOT guard проверяет AST contract, Shop guard требует безопасный `CAST(:extra AS jsonb)`, Ruff import-order исправлен.
- Deep backend remediation не откатывается; frozen `0001`, отсутствие `0002+`, FAQ standalone authority и FRONTEND_v146 сохраняются.
- Immutable report `02364`; следующий `02365`; canonical handoff `EFHC_Bot_v174_46.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

## OWNER LOCK v174.45 / цикл 1793 — exact CI qualification repair

- Supplied CI `87278222904` является единственным execution evidence этой итерации; исправлять только его подтверждённые причины.
- Deep remediation `v174.44` не откатывать: tests адаптируются к current DB-session/security/export contracts, если они stale.
- Missing import и PostgreSQL JSONB bind syntax являются real source defects и исправляются в runtime; schema/FAQ/frontend authority не меняются.
- Локальная project qualification запрещена; следующий verdict даёт fresh exact-head GitHub CI для `EFHC_Bot_v174_45.zip`.

## OWNER LOCK v174.44 / цикл 1792 — глубокое исправление backend ownership

- Прямой owner scope: исправить каждый подтверждённый exact source дефект DEF-01…18 из Deep Backend Remediation Spec; потенциальные риски не выдавать за доказанные инциденты.
- Root commit/rollback принадлежит владельцу application use-case; CRUD/composable services используют flush/savepoint. Scheduler cancellation всегда пробрасывается выше.
- Runtime financial spend использует одну canonical реализацию; tests обязаны проверять тот же symbol.
- Существующий CRUD по 52 таблицам, frozen `0001`, standalone FAQ и authority FRONTEND_v146 сохраняются.
- Локальная project qualification не выполняется; следующий authority — exact-head GitHub CI для `EFHC_Bot_v174_44.zip`.

## OWNER LOCK v174.37 / cycle 1789 — CI guards and FAQ packaging boundary

- Exact CI `86988434882` tested `v174.36`; only three pytest qualification guards remain red. Approved FRONTEND_v146 is not rolled back.
- Tests may track functional/current contracts, not freeze superseded visual/text literals.
- Runtime frontend prebuild is SSOT-independent; release packaging still invokes the FAQ SSOT generator before staging under the existing approved release model.
- Candidate `v174.37` requires next exact-head CI. Canonical handoff: `EFHC_Bot_v174_37.zip` only.

## OWNER LOCK v174.36 / cycle 1788 — approved patch vs tests

- Owner подтвердил: FRONTEND_v146 patch является authority для frontend visual/UX/text/functions; test, требующий старый UI, корректируется/удаляется, если не защищает реальный invariant.
- Реальные backend/security/financial invariants не ослабляются; stale literal/count/hash/route expectation обновляется до current authority с сохранением fail-closed смысла.
- При одновременно доказанном runtime defect и stale test исправляются оба, но runtime меняется только по независимому evidence.
- CI `86966635485` является evidence предыдущего `v174.35`, не квалификацией нового `v174.36`.
- Canonical handoff: `EFHC_Bot_v174_36.zip`; дополнительные owner-facing sidecar files и archive suffixes запрещены.

# CURRENT AI OPERATOR CONTROL — v174.35 / цикл 1788

- Startup authority: `START_HERE.md` → `KERNEL.md`; direct owner decision opens cycle `1788` for FRONTEND_v146 integration.
- Physical HEAD remains `v174.35`; integrated frontend authority is `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146`.
- Backend/CANON remains authority for API/data/security/identity/economy/financial semantics. Supplied patch is source input only and is deleted after merge.
- Latest available exact-head GREEN remains `v174.33` / CI `86661926957`; candidate `v174.35` is not GREEN until its own exact-head CI.
- CI failures may be claimed/repaired only from actual supplied logs. Current handoff has no CI-log artifact; `QA-2026-08-18-CI1788-P01` remains PENDING.
- Full local tests/build/CI are not run by owner order; static verification only.

> **Historical boundary:** lower control snapshots are historical and do not override this current block.

# CURRENT AI OPERATOR CONTROL — v174.34 / цикл 1787

- Startup authority: `START_HERE.md` → `KERNEL.md`; exact-green parent `v174.33`, GitHub CI `86661926957`.
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` — append-only owner Q/A authority. Новый вопрос владельцу сначала фиксируется `PENDING`; при owner recovery order или coverage gap проверяются все доступные numbered `docs/chats/*`. Inference отсутствующего ответа запрещён.
- Recovery dispositions: доказанная пара → recovered/answered; вопрос без ответа → `UNRESOLVED`; generic answer без исходного вопроса → `CONTEXT_INCOMPLETE`. Более поздний active CANON/direct owner decision имеет приоритет над history.
- Current `v174.34` — document-only candidate; production backend/frontend/OpenAPI/schema/financial semantics не меняются. Следующий verifier — exact-head GitHub CI.

> **Historical boundary:** нижележащие cycle/status snapshots являются историческими и не переопределяют этот current control block.

# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# AI Operator Rules — EFHC Bot

Status: ACTIVE AI CONTROL DOCUMENT.
Archive: `v171.67`.

## 1. Entry and priority

The only startup order is `START_HERE.md`. `KERNEL.md` is the active full dispatch layer, not navigation-only.

Priority: current user instruction → latest canonical archive/runtime → AI Archive Laws → active CANON/SSOT → active NORM/locks → active AI execution rules → fresh evidence → Healer/cycles/reports → history.

## 2. Archive-first execution

```text
latest canonical ZIP
→ integrity check and one unpack
→ START_HERE + KERNEL
→ classifier/resolver/YAML route
→ exact anchors/source/tests
→ bounded patch and validation
→ new sequential development ZIP
```

The sandbox is temporary. Historical archives are forensic references only.

## 3. Source layers

- CANON: approved product meaning.
- SSOT: one current source of truth per domain.
- NORM: mandatory application procedure.
- AI: execution, reading and communication rules.
- Healer: confirmed defect memory and recurrence guards.
- Reports/cycles/logs: evidence/history, never silent product truth.

Duplicate active truth sources are consolidated. Transient status and cycle reports do not belong in active SSOT/NORM.

## 4. Reading discipline

Use `file_map.summary.json` and machine lookup. Do not full-read `file_map.json`, full Healer, reports, audits, cycles or broad runtime trees unless an explicit route requires them. For ordinary familiarization, read only the latest two relevant reports, audits and cycle records per layer. Follow `READING_BUDGET.md` and build a bounded context capsule.

## 5. CI and tests

CI, pytest, build, typecheck, lint and browser tests are allowed when required by the route. Use timeouts and stop after a confirmed hang/external dependency block. The GitHub CI job is capped at 10 minutes; do not raise it above 10 minutes without direct user instruction. Never call local execution GitHub CI.

A failing protection test is repaired or replaced with documented equal/stronger coverage; it is not hidden, skipped, archived or excluded to obtain green status. CI/workflow files require direct scope or an exact confirmed CI repair.


## 5A. AI operational brain and temporary memory

`docs/AI/` is the current operational brain of the AI. It must remain concise, current and route-oriented rather than accumulate history.

- Keep unresolved/near-term items in `AI_TEMPORARY_MEMORY_PENDING.md`.
- Move user-approved decisions to the proper CANON / SSOT / NORM.
- Remove promoted decisions from active temporary memory.
- Preserve an old snapshot under `docs/history/` only when continuity requires it; do not default-read it.

## 6. Screenshots

Frontend visual work requires the real running application, `page.goto()`, route/app-root confirmation, error/overflow checks and fresh PNG. Manual HTML, `page.set_content`, synthetic/mock imitation and inherited PNG do not prove the current application.

PNG is local user evidence and belongs in a separate companion archive, not the development ZIP.

## 7. High-risk locks

Economy, money, wallet ownership, TON, TonConnect, TonProof, withdraw, auth, idempotency, transactions and DB truth require exact routes, CANON/SSOT/NORM anchors and targeted guards.

Before first release, migration `0002+` requires direct user approval. Rewriting migration history for green tests is forbidden.

The six canonical bottom buttons cannot be renamed, removed, reordered or rerouted without direct user instruction.

## 8. Communication and questions

Report findings/blockers in Russian. Execute all compatible safe work without repetitive questions. Ask only when an unresolved choice changes CANON, SSOT, NORM, economy, auth, migrations, security or product meaning. Do not hide a decision only in the archive.

## 9. Cycles, archives and claims

Cycle 1573 local scope is complete and its external live checks are `DEFERRED_POST_RELEASE_BY_USER` by direct user decision. A development cycle may advance when all available local checks are complete and an objectively unavailable external check is explicitly deferred. The missing evidence remains unverified and must stay in the release/post-release checklist. Every changed pass ends with a development archive. Release-ready claims still require exact evidence.

Never claim GitHub CI, live Telegram, real TonConnect signature, TonProof, transaction hash or production readiness without exact evidence.

## 10. Delivery checklist

- one startup order and one active Kernel role;
- no duplicate active truth sources;
- exact diff and targeted checks recorded;
- file maps refreshed last;
- no nested ZIP, screenshots, node_modules, `.next`, caches, logs or secrets in main archive;
- SHA-256, size, file count and ZIP integrity reported;
- remaining external boundary stated honestly.

Authority: `docs/AI/AI_ARCHIVE_LAWS.md` and its active lock remain mandatory.

## 11. Compatibility rules protected by active guards

Archive numbering uses two-digit minor suffixes from `00` through `99`.
After `vN_99`, the next archive is `v(N+1)_00`; `vN_100` and any
three-digit minor suffix are forbidden.

Healer — главное долговременное хранилище всех ошибок проекта.
Only confirmed incidents are promoted there with a root cause and an
independent recurrence guard.

CI files are manual-control files. CI/workflow files are manual-control
files and may be changed only inside a directly authorized or exact
log-repair scope.

Архив и итоговый отчёт передаются пользователю в чат после завершения
изменённого прохода. Перед сборкой каждого архива обязателен прогон
релевантного test/guard пакета.

Переписывать migration history ради green test запрещено.

Russian is the mandatory semantic source language. English and the other
locales are translation layers from the verified Russian source meaning.

Все будущие cycles в серии `docs/cycles/WORK_CYCLES_0001-0100.md`,
`docs/cycles/WORK_CYCLES_0101-0200.md`, `0201-0300` и далее регистрируются в соответствующем диапазоне
и индексируются из активного cycle register.

## 12. Literal guard contracts

Сначала итог и обязательные файлы передаются пользователю в чат; затем
архивная документация фиксирует тот же результат.

Ослаблять, удалять, скрывать или исключать тесты ради green status запрещено.

Перед сборкой каждого архива обязателен прогон релевантного test/guard пакета

Все будущие cycles в серии `docs/cycles/WORK_CYCLES_0001-0100.md`, `docs/cycles/WORK_CYCLES_0101-0200.md`, `0201-0300` и далее

Правило chat-first: сначала результат и обязательные файлы передаются
пользователю в чате, затем тот же итог фиксируется в архиве.
