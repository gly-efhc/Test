# CURRENT HEAD — v174.47 / цикл 1793 CI qualification repair

- Exact GitHub CI `87288059313` проверил `v174.46` SHA-256 `fda32d417d20663ff5c19d9b414d6d6eefe3de06514a13525f661e499b4e8f32`, checkout `64c11a5dba3a081b9aeef4ec59158435e8a10cdb`. Все recorded gates GREEN, кроме pytest: `1 failed / 1727 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — устаревший baseline русскоязычной инженерной политики для `CONTINUE_IN_NEW_CHAT.md`: файл содержит `53` неизменяемых исторических англоязычных snapshot-фрагмента при разрешённом historical count `36`.
- Исторические handoff-фрагменты не переписываются. Baseline повышен строго `36 → 53`; любой следующий новый англоязычный prose-фрагмент остаётся fail-closed нарушением.
- Runtime/backend/frontend/DB не менялись. Frozen `0001`, отсутствие `0002+`, FAQ standalone authority, FRONTEND_v146 и deep-remediation contracts сохранены.
- Immutable report `02365`; следующий `02366`; canonical handoff `EFHC_Bot_v174_47.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.46 / цикл 1793 CI qualification repair

- Exact GitHub CI `87285361835` проверил `v174.45` SHA-256 `3cc9d0a7a3f274b2eaedb89a85a081587a4aad6571a452ead758de24ff8bc75e`, checkout `b527ac44347a7714c3ac927bed6826a4c284218f`.
- GREEN: Development HEAD SHA, Flake8 critical/full, Mypy, Bandit, compileall, PostgreSQL/Alembic, npm install и frontend build. RED: Ruff `1×I001`, pytest `17 failed / 1711 passed / 22 skipped / 1 warning`.
- Подтверждённый runtime defect: Panels после canonical financial SSOT migration всё ещё использовал удалённый `transactions_service.SpendBreakdown`; теперь `SpendBreakdown/split_bonus_then_main` импортируются напрямую из `app.standards.finance_rules`.
- Qualification repair: financial SSOT guard проверяет AST contract, Shop guard требует безопасный `CAST(:extra AS jsonb)`, Ruff import-order исправлен.
- Deep backend remediation не откатывается; frozen `0001`, отсутствие `0002+`, FAQ standalone authority и FRONTEND_v146 сохраняются.
- Immutable report `02364`; следующий `02365`; canonical handoff `EFHC_Bot_v174_46.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

## OWNER LOCK v174.45 / цикл 1793 — exact CI qualification repair

- Supplied CI `87278222904` является единственным execution evidence этой итерации; исправлять только его подтверждённые причины.
- Deep remediation `v174.44` не откатывать: tests адаптируются к current DB-session/security/export contracts, если они stale.
- Missing import и PostgreSQL JSONB bind syntax являются real source defects и исправляются в runtime; schema/FAQ/frontend authority не меняются.
- Локальная project qualification запрещена; следующий verdict даёт fresh exact-head GitHub CI для `EFHC_Bot_v174_45.zip`.

## OWNER LOCK v174.44 / цикл 1792 — глубокое исправление backend ownership

- Прямой owner scope: исправить каждый подтверждённый exact source дефект DEF-01…18 из Deep Backend Remediation Spec; потенциальные риски не выдавать за доказанные инциденты.
- Root commit/rollback принадлежит владельцу application use-case; CRUD/composable services используют flush/savepoint. Scheduler cancellation всегда пробрасывается выше.
- Runtime financial spend использует одну canonical реализацию; tests обязаны проверять тот же symbol.
- Существующий CRUD по 52 таблицам, frozen `0001`, standalone FAQ и authority FRONTEND_v146 сохраняются.
- Локальная project qualification не выполняется; следующий authority — exact-head GitHub CI для `EFHC_Bot_v174_44.zip`.

## OWNER LOCK v174.37 / cycle 1789 — CI guards and FAQ packaging boundary

- Exact CI `86988434882` tested `v174.36`; only three pytest qualification guards remain red. Approved FRONTEND_v146 is not rolled back.
- Tests may track functional/current contracts, not freeze superseded visual/text literals.
- Runtime frontend prebuild is SSOT-independent; release packaging still invokes the FAQ SSOT generator before staging under the existing approved release model.
- Candidate `v174.37` requires next exact-head CI. Canonical handoff: `EFHC_Bot_v174_37.zip` only.

## OWNER LOCK v174.36 / cycle 1788 — approved patch vs tests

- Owner подтвердил: FRONTEND_v146 patch является authority для frontend visual/UX/text/functions; test, требующий старый UI, корректируется/удаляется, если не защищает реальный invariant.
- Реальные backend/security/financial invariants не ослабляются; stale literal/count/hash/route expectation обновляется до current authority с сохранением fail-closed смысла.
- При одновременно доказанном runtime defect и stale test исправляются оба, но runtime меняется только по независимому evidence.
- CI `86966635485` является evidence предыдущего `v174.35`, не квалификацией нового `v174.36`.
- Canonical handoff: `EFHC_Bot_v174_36.zip`; дополнительные owner-facing sidecar files и archive suffixes запрещены.

# CURRENT AI OPERATOR CONTROL — v174.35 / цикл 1788

- Startup authority: `START_HERE.md` → `KERNEL.md`; direct owner decision opens cycle `1788` for FRONTEND_v146 integration.
- Physical HEAD remains `v174.35`; integrated frontend authority is `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146`.
- Backend/CANON remains authority for API/data/security/identity/economy/financial semantics. Supplied patch is source input only and is deleted after merge.
- Latest available exact-head GREEN remains `v174.33` / CI `86661926957`; candidate `v174.35` is not GREEN until its own exact-head CI.
- CI failures may be claimed/repaired only from actual supplied logs. Current handoff has no CI-log artifact; `QA-2026-08-18-CI1788-P01` remains PENDING.
- Full local tests/build/CI are not run by owner order; static verification only.

> **Historical boundary:** lower control snapshots are historical and do not override this current block.

# CURRENT AI OPERATOR CONTROL — v174.34 / цикл 1787

- Startup authority: `START_HERE.md` → `KERNEL.md`; exact-green parent `v174.33`, GitHub CI `86661926957`.
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` — append-only owner Q/A authority. Новый вопрос владельцу сначала фиксируется `PENDING`; при owner recovery order или coverage gap проверяются все доступные numbered `docs/chats/*`. Inference отсутствующего ответа запрещён.
- Recovery dispositions: доказанная пара → recovered/answered; вопрос без ответа → `UNRESOLVED`; generic answer без исходного вопроса → `CONTEXT_INCOMPLETE`. Более поздний active CANON/direct owner decision имеет приоритет над history.
- Current `v174.34` — document-only candidate; production backend/frontend/OpenAPI/schema/financial semantics не меняются. Следующий verifier — exact-head GitHub CI.

> **Historical boundary:** нижележащие cycle/status snapshots являются историческими и не переопределяют этот current control block.

# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# AI Operator Rules — EFHC Bot

Status: ACTIVE AI CONTROL DOCUMENT.
Archive: `v171.67`.

## 1. Entry and priority

The only startup order is `START_HERE.md`. `KERNEL.md` is the active full dispatch layer, not navigation-only.

Priority: current user instruction → latest canonical archive/runtime → AI Archive Laws → active CANON/SSOT → active NORM/locks → active AI execution rules → fresh evidence → Healer/cycles/reports → history.

## 2. Archive-first execution

```text
latest canonical ZIP
→ integrity check and one unpack
→ START_HERE + KERNEL
→ classifier/resolver/YAML route
→ exact anchors/source/tests
→ bounded patch and validation
→ new sequential development ZIP
```

The sandbox is temporary. Historical archives are forensic references only.

## 3. Source layers

- CANON: approved product meaning.
- SSOT: one current source of truth per domain.
- NORM: mandatory application procedure.
- AI: execution, reading and communication rules.
- Healer: confirmed defect memory and recurrence guards.
- Reports/cycles/logs: evidence/history, never silent product truth.

Duplicate active truth sources are consolidated. Transient status and cycle reports do not belong in active SSOT/NORM.

## 4. Reading discipline

Use `file_map.summary.json` and machine lookup. Do not full-read `file_map.json`, full Healer, reports, audits, cycles or broad runtime trees unless an explicit route requires them. For ordinary familiarization, read only the latest two relevant reports, audits and cycle records per layer. Follow `READING_BUDGET.md` and build a bounded context capsule.

## 5. CI and tests

CI, pytest, build, typecheck, lint and browser tests are allowed when required by the route. Use timeouts and stop after a confirmed hang/external dependency block. The GitHub CI job is capped at 10 minutes; do not raise it above 10 minutes without direct user instruction. Never call local execution GitHub CI.

A failing protection test is repaired or replaced with documented equal/stronger coverage; it is not hidden, skipped, archived or excluded to obtain green status. CI/workflow files require direct scope or an exact confirmed CI repair.


## 5A. AI operational brain and temporary memory

`docs/AI/` is the current operational brain of the AI. It must remain concise, current and route-oriented rather than accumulate history.

- Keep unresolved/near-term items in `AI_TEMPORARY_MEMORY_PENDING.md`.
- Move user-approved decisions to the proper CANON / SSOT / NORM.
- Remove promoted decisions from active temporary memory.
- Preserve an old snapshot under `docs/history/` only when continuity requires it; do not default-read it.

## 6. Screenshots

Frontend visual work requires the real running application, `page.goto()`, route/app-root confirmation, error/overflow checks and fresh PNG. Manual HTML, `page.set_content`, synthetic/mock imitation and inherited PNG do not prove the current application.

PNG is local user evidence and belongs in a separate companion archive, not the development ZIP.

## 7. High-risk locks

Economy, money, wallet ownership, TON, TonConnect, TonProof, withdraw, auth, idempotency, transactions and DB truth require exact routes, CANON/SSOT/NORM anchors and targeted guards.

Before first release, migration `0002+` requires direct user approval. Rewriting migration history for green tests is forbidden.

The six canonical bottom buttons cannot be renamed, removed, reordered or rerouted without direct user instruction.

## 8. Communication and questions

Report findings/blockers in Russian. Execute all compatible safe work without repetitive questions. Ask only when an unresolved choice changes CANON, SSOT, NORM, economy, auth, migrations, security or product meaning. Do not hide a decision only in the archive.

## 9. Cycles, archives and claims

Cycle 1573 local scope is complete and its external live checks are `DEFERRED_POST_RELEASE_BY_USER` by direct user decision. A development cycle may advance when all available local checks are complete and an objectively unavailable external check is explicitly deferred. The missing evidence remains unverified and must stay in the release/post-release checklist. Every changed pass ends with a development archive. Release-ready claims still require exact evidence.

Never claim GitHub CI, live Telegram, real TonConnect signature, TonProof, transaction hash or production readiness without exact evidence.

## 10. Delivery checklist

- one startup order and one active Kernel role;
- no duplicate active truth sources;
- exact diff and targeted checks recorded;
- file maps refreshed last;
- no nested ZIP, screenshots, node_modules, `.next`, caches, logs or secrets in main archive;
- SHA-256, size, file count and ZIP integrity reported;
- remaining external boundary stated honestly.

Authority: `docs/AI/AI_ARCHIVE_LAWS.md` and its active lock remain mandatory.

## 11. Compatibility rules protected by active guards

Archive numbering uses two-digit minor suffixes from `00` through `99`.
After `vN_99`, the next archive is `v(N+1)_00`; `vN_100` and any
three-digit minor suffix are forbidden.

Healer — главное долговременное хранилище всех ошибок проекта.
Only confirmed incidents are promoted there with a root cause and an
independent recurrence guard.

CI files are manual-control files. CI/workflow files are manual-control
files and may be changed only inside a directly authorized or exact
log-repair scope.

Архив и итоговый отчёт передаются пользователю в чат после завершения
изменённого прохода. Перед сборкой каждого архива обязателен прогон
релевантного test/guard пакета.

Переписывать migration history ради green test запрещено.

Russian is the mandatory semantic source language. English and the other
locales are translation layers from the verified Russian source meaning.

Все будущие cycles в серии `docs/cycles/WORK_CYCLES_0001-0100.md`,
`docs/cycles/WORK_CYCLES_0101-0200.md`, `0201-0300` и далее регистрируются в соответствующем диапазоне
и индексируются из активного cycle register.

## 12. Literal guard contracts

Сначала итог и обязательные файлы передаются пользователю в чат; затем
архивная документация фиксирует тот же результат.

Ослаблять, удалять, скрывать или исключать тесты ради green status запрещено.

Перед сборкой каждого архива обязателен прогон релевантного test/guard пакета

Все будущие cycles в серии `docs/cycles/WORK_CYCLES_0001-0100.md`, `docs/cycles/WORK_CYCLES_0101-0200.md`, `0201-0300` и далее

Правило chat-first: сначала результат и обязательные файлы передаются
пользователю в чате, затем тот же итог фиксируется в архиве.
