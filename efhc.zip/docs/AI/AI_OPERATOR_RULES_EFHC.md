# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# AI Operator Rules — EFHC Bot

Status: ACTIVE AI CONTROL DOCUMENT.
Archive: `v171.67`.

## 1. Entry and priority

The only startup order is `START_HERE.md`. `KERNEL.md` is the active full dispatch layer, not navigation-only.

Priority: current user instruction → latest canonical archive/runtime → AI Archive Laws → active CANON/SSOT → active NORM/locks → active AI execution rules → fresh evidence → Healer/cycles/reports → history.

## 2. Archive-first execution

```text
latest canonical ZIP
→ integrity check and one unpack
→ START_HERE + KERNEL
→ classifier/resolver/YAML route
→ exact anchors/source/tests
→ bounded patch and validation
→ new sequential development ZIP
```

The sandbox is temporary. Historical archives are forensic references only.

## 3. Source layers

- CANON: approved product meaning.
- SSOT: one current source of truth per domain.
- NORM: mandatory application procedure.
- AI: execution, reading and communication rules.
- Healer: confirmed defect memory and recurrence guards.
- Reports/cycles/logs: evidence/history, never silent product truth.

Duplicate active truth sources are consolidated. Transient status and cycle reports do not belong in active SSOT/NORM.

## 4. Reading discipline

Use `file_map.summary.json` and machine lookup. Do not full-read `file_map.json`, full Healer, reports, audits, cycles or broad runtime trees unless an explicit route requires them. For ordinary familiarization, read only the latest two relevant reports, audits and cycle records per layer. Follow `READING_BUDGET.md` and build a bounded context capsule.

## 5. CI and tests

CI, pytest, build, typecheck, lint and browser tests are allowed when required by the route. Use timeouts and stop after a confirmed hang/external dependency block. The GitHub CI job is capped at 10 minutes; do not raise it above 10 minutes without direct user instruction. Never call local execution GitHub CI.

A failing protection test is repaired or replaced with documented equal/stronger coverage; it is not hidden, skipped, archived or excluded to obtain green status. CI/workflow files require direct scope or an exact confirmed CI repair.


## 5A. AI operational brain and temporary memory

`docs/AI/` is the current operational brain of the AI. It must remain concise, current and route-oriented rather than accumulate history.

- Keep unresolved/near-term items in `AI_TEMPORARY_MEMORY_PENDING.md`.
- Move user-approved decisions to the proper CANON / SSOT / NORM.
- Remove promoted decisions from active temporary memory.
- Preserve an old snapshot under `docs/history/` only when continuity requires it; do not default-read it.

## 6. Screenshots

Frontend visual work requires the real running application, `page.goto()`, route/app-root confirmation, error/overflow checks and fresh PNG. Manual HTML, `page.set_content`, synthetic/mock imitation and inherited PNG do not prove the current application.

PNG is local user evidence and belongs in a separate companion archive, not the development ZIP.

## 7. High-risk locks

Economy, money, wallet ownership, TON, TonConnect, TonProof, withdraw, auth, idempotency, transactions and DB truth require exact routes, CANON/SSOT/NORM anchors and targeted guards.

Before first release, migration `0002+` requires direct user approval. Rewriting migration history for green tests is forbidden.

The six canonical bottom buttons cannot be renamed, removed, reordered or rerouted without direct user instruction.

## 8. Communication and questions

Report findings/blockers in Russian. Execute all compatible safe work without repetitive questions. Ask only when an unresolved choice changes CANON, SSOT, NORM, economy, auth, migrations, security or product meaning. Do not hide a decision only in the archive.

## 9. Cycles, archives and claims

Cycle 1573 local scope is complete and its external live checks are `DEFERRED_POST_RELEASE_BY_USER` by direct user decision. A development cycle may advance when all available local checks are complete and an objectively unavailable external check is explicitly deferred. The missing evidence remains unverified and must stay in the release/post-release checklist. Every changed pass ends with a development archive. Release-ready claims still require exact evidence.

Never claim GitHub CI, live Telegram, real TonConnect signature, TonProof, transaction hash or production readiness without exact evidence.

## 10. Delivery checklist

- one startup order and one active Kernel role;
- no duplicate active truth sources;
- exact diff and targeted checks recorded;
- file maps refreshed last;
- no nested ZIP, screenshots, node_modules, `.next`, caches, logs or secrets in main archive;
- SHA-256, size, file count and ZIP integrity reported;
- remaining external boundary stated honestly.

Authority: `docs/AI/AI_ARCHIVE_LAWS.md` and its active lock remain mandatory.

## 11. Compatibility rules protected by active guards

Archive numbering uses two-digit minor suffixes from `00` through `99`.
After `vN_99`, the next archive is `v(N+1)_00`; `vN_100` and any
three-digit minor suffix are forbidden.

Healer — главное долговременное хранилище всех ошибок проекта.
Only confirmed incidents are promoted there with a root cause and an
independent recurrence guard.

CI files are manual-control files. CI/workflow files are manual-control
files and may be changed only inside a directly authorized or exact
log-repair scope.

Архив и итоговый отчёт передаются пользователю в чат после завершения
изменённого прохода. Перед сборкой каждого архива обязателен прогон
релевантного test/guard пакета.

Переписывать migration history ради green test запрещено.

Russian is the mandatory semantic source language. English and the other
locales are translation layers from the verified Russian source meaning.

Все будущие cycles в серии `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_0-100.md`,
`101-200`, `201-300` и далее регистрируются в соответствующем диапазоне
и индексируются из активного cycle register.

## 12. Literal guard contracts

Сначала итог и обязательные файлы передаются пользователю в чат; затем
архивная документация фиксирует тот же результат.

Ослаблять, удалять, скрывать или исключать тесты ради green status запрещено.

Перед сборкой каждого архива обязателен прогон релевантного test/guard пакета

Все будущие cycles в серии `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_0-100.md`, `101-200`, `201-300` и далее

Правило chat-first: сначала результат и обязательные файлы передаются
пользователю в чате, затем тот же итог фиксируется в архиве.
