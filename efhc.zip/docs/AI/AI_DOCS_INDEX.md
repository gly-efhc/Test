<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Актуальная AI-навигация v173.02

Текущая оперативная память: `AI_TEMPORARY_MEMORY_PENDING.md`.
Текущий release SSOT: `docs/SSOT/CURRENT_RELEASE_STATE.md`.
Current cycle evidence is resolved through `reports/current/CURRENT_CYCLE_REPORT.md` and `reports/numbered/`; historical 1685 bytes are external evidence, not active authority.

---

# Утверждённый канон провайдеров — 2026-08-05

```text
Telegram → tg_id
TON      → ton_wallet_id
Google   → google_id
Apple    → apple_id
Facebook → fb_id
Discord  → discord_id
GitHub   → github_id
provider + subject → global_id
```

`global_id` — единственный business owner. Один `global_id` может иметь несколько provider identities. После identity resolution весь business runtime использует только `global_id`.

SSOT: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
Причинность: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
NORM: `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`.
Следующий цикл: реализация канона в runtime, ORM, API, migration, tests и guards.

---

# EFHC AI Documents Index

Status: ACTIVE INDEX.
Archive: `v171.67`.
Entry: `START_HERE.md`.

This index lists active AI/control documents only. Cycle history belongs in `docs/cycles/`, immutable reports in `reports/numbered/`, current audits in `docs/audits/`; superseded bytes and legacy prompts exist only in the external `ARTIFACTS_HISTORY` ZIP and are never startup truth.

## Mandatory startup AI chain

1. `AI_ARCHIVE_LAWS.md` and lock;
2. `AI_OPERATOR_RULES_EFHC.md`;
3. `AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`;
4. `EFHC_OPERATOR_KERNEL_PROTOCOL.md`;
5. `EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`;
6. `READING_BUDGET.md`;
7. `EFHC_CONTEXT_CAPSULE_PROTOCOL.md`.

## Active routing and navigation

- `EFHC_OPERATOR_KERNEL_ROUTE_MAP.md` — domain anchors;
- `TOPIC_READING_ROUTES.md` — compatibility route guide;
- `READING_ENTRYPOINT.md` — compatibility pointer to START_HERE;
- `ARCHIVE_FAST_MANIFEST.md` — current compact boundary;
- `ARCHIVE_SYNAPTIC_LINKS.md` — cross-layer associations;
- `ARCHIVE_FAST_MANIFEST.md` and `file_map.summary.json` must not replace exact source reading.

## Active execution controls

- `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md` — обязательный identity naming canon;
- `AI_DOCUMENT_LAYERS_CANON.md`;
- `AI_PROCESS_DRIFT_MANDATORY_READING.md`;
- `AI_RUNTIME_DEPENDENCIES_PRECHECK.md`;
- `AI_RESILIENCE_CANON.md`;
- `AI_AGENT_SKILLS_EFHC_ADAPTER.md`;
- `FAQ_READING_POLICY.md`;
- `LOGS_AND_REPORTS_RETENTION_POLICY.md`.

## Operational memory and historical references

- `AI_TEMPORARY_MEMORY_PENDING.md` — bounded active operational memory for unresolved/near-term items only; approved decisions are promoted to CANON/SSOT/NORM and removed;
- `PRESERVED_OPERATOR_KERNEL_v171_47_FULL.md` — forensic reference only;
- `docs/history/legacy_artifacts/docs/history/AI_TEMPORARY_MEMORY_SNAPSHOT_PRE_v171_64.md` — historical snapshot, never default-read;
- `docs/history/legacy_artifacts/docs/history/LEGACY_CONTINUE_PROMPTS.md` — merged historical prompts, never startup truth.

## Compatibility route anchors

These names remain searchable route pointers; their historical content is
not part of the mandatory startup read:

- `PUBLIC_UI_NEXT_RANGE_EXTENSION_CHECKPOINT.md`;
- `PUBLIC_UI_REGRESSION_PROOF_PASS.md`;
- `PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md`;
- `ADMIN_RECOVERY_CHECKPOINT.md`;
- `ADMIN_REGRESSION_PROOF_PASS.md`;
- `PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`.

Language route: Russian is the semantic source; English and the remaining
locales are translation layers from that verified source.

Historical route evidence pointers:

- `public_ui_regression_proof_v169_40.json`;
- `admin_regression_proof_v169_35.json`;
- `docs/history/legacy_artifacts/map_element.md`.

## Active cycle range compatibility

Active range: `1351-1375`.
