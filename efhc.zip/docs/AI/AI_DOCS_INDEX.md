# START HERE — AI MENU

Этот файл — быстрый вход в AI-layer.
С него нужно начинать, когда в новом чате требуется быстро понять,
как устроены AI-документы, что из них активно, что является памятью,
а что уже стало вторичным историческим слоем.

## Активный AI brain / instruction layer

- `docs/AI/AI_OPERATOR_RULES_EFHC.md`
  - главный операторский канон: archive-first работа, формат циклов,
    guarded repair mode, устойчивые пользовательские правила.
- `docs/AI/AI_BRAIN_MEMORY_MODEL.md`
  - модель `чат / HEAD / AI-мозги / память`.
- `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`
  - быстрый старт нового чата и протокол общения.
- `docs/AI/AI_RESILIENCE_CANON.md`
  - устойчивость, self-healing и log-driven repair logic.
- `docs/AI/AI_RUNTIME_DEPENDENCIES_PRECHECK.md`
  - обязательный precheck проверочных инструментов и средовых модулей
    перед каждым циклом.
- `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`
  - временный AI-слой для короткоживущих элементов, которые ещё требуют
    последующей актуализации или переноса в основные документы.

## Справочно-инструкционный слой

Это очень важные рабочие слои памяти и инструкции:
- `docs/SSOT/*`
- `docs/NORM/*`
- `docs/cycles/WORK_CYCLES.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `HEALER_ATLAS.md`
- `docs/healer/*`
- `reports/change_cycle_*.md`

`docs/SSOT/*` и `docs/NORM/*` — особенно важны для работы.
Они одновременно являются:
- инструкционным слоем по поведению EFHC Bot;
- слоем памяти о каноне, инвариантах и утверждённых правилах.

## Исторический / вторичный prompt-layer

Prompt-файлы вторичны и не должны быть главным носителем continuity,
если тот же смысл уже перенесён в основные AI-документы.

Исторические / вторичные prompt-файлы:
- `docs/AI/CONTINUE_NEW_CHAT_V157_PROMPT.md`
- `docs/AI/CONTINUE_NEW_CHAT_V162_PROMPT.md`
- `docs/AI/CONTINUE_NEW_CHAT_V162_02_PROMPT.md`
- `docs/AI/CONTINUE_NEW_CHAT_V163_04_PROMPT.md`
- `docs/AI/CONTINUE_NEW_CHAT_V163_08_PROMPT.md`

Они должны оставаться только как архивный след,
пока их смысл полностью не извлечён в основной AI-layer.

## Быстрый маршрут старта

1. `docs/AI/AI_DOCS_INDEX.md`
2. `docs/AI/AI_OPERATOR_RULES_EFHC.md`
3. `docs/AI/AI_BRAIN_MEMORY_MODEL.md`
4. `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`
5. `docs/AI/AI_RESILIENCE_CANON.md`
6. затем canon / norm / WORK_CYCLES / Q&A / registries / reports / HEAD.

Главное понимание должно жить в основных AI docs,
а не быть спрятанным только в prompt-файлах.

## Статус prompt-layer после review

- Исторические prompt-файлы уже не являются главным carrier of continuity.
- Их смысл в большой степени извлечён в основной AI-layer.
- Следующая cleanup wave по prompt-layer возможна только после отдельного
  согласования с пользователем и без потери continuity.

- `docs/AI/AI_RUNTIME_DEPENDENCIES_PRECHECK.md`
  - обязательный precheck инструментов и средовых модулей перед каждым циклом, включая `pytest`, `ruff`, `compileall`, `mypy`, `bandit`, `sqlalchemy`, `aiosqlite`.
