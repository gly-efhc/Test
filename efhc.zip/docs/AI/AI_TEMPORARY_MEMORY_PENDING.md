Status: ACTIVE OPERATIONAL MEMORY / SHORT-LIVED.
Archive: `v173.00`.
Cycle: `1683`.

Текущая задача: окончательная Global ID / Provider Identity миграция.

- `global_id` — единственный business owner.
- `tg_id` разрешён только на доказанных Telegram boundaries.
- Payment Intents, withdrawals и direct EFHC deposits переведены.
- Forced test cutover: 742 заменено, 254 Telegram-specific сохранено.
- Текущий actionable/review-остаток матрицы: 2170.
- Следующий цикл: 1684.
- Осталось семь циклов текущего плана: 1684–1690.
- Обязателен exact-head GitHub CI v173.00.

No unresolved governance items remain.
