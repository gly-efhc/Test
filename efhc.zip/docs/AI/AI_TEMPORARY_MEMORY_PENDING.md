# CURRENT PENDING STATE — v171.95

Cycle 1598 prepared the LEGACY alias and future backfill harness. Next
work must use `EFHC_Bot_v171_95.zip`. No backfill has executed and no
domain or financial read has switched.

## Retained pending state — v171.94

- Fresh exact-HEAD development/release GitHub CI is required.
- PostgreSQL online upgrade and reconciliation remain required.
- TON login is designed but not enabled in this EXPAND stage.

# AI TEMPORARY MEMORY — PENDING

Status: ACTIVE OPERATIONAL MEMORY / SHORT-LIVED.
Archive: `v171.93`.
Cycle: `1596`.

Pending external proof:

1. Fresh exact-HEAD development and release GitHub CI for v171.93.
2. All 25 PostgreSQL integration tests with zero skips.
3. Frontend typecheck/build and 102 real Chromium route checks.
4. Real deployment, rollback, restore, Telegram and TON proof.

Cycle 1596 prepares the isolated Pydantic/OpenAPI UserId contract. It
contains no schema, route, DTO ownership or financial migration.

---

## Retained prior project record

# AI TEMPORARY MEMORY — PENDING

Status: ACTIVE OPERATIONAL MEMORY / SHORT-LIVED.
Archive: `v171.92`.
Cycle: `1595`.

No unresolved governance items remain.

Pending external proof:

1. Run fresh exact-HEAD GitHub CI for development and release v171.92.
2. Execute all 25 PostgreSQL integration tests with zero skips.
3. Run the separate `frontend-visual-evidence` workflow for the retained
   34-route visual inventory at 360, 390 and 430 px.
4. Perform Docker clean deploy, repeat deploy, update, rollback and
   restore.
5. Complete live Telegram, TonConnect, TonProof and settlement proof.

Both supplied exact v171.88 CI contours are green. The Activ audit found
semantic drift not detected by that suite: several consumers used
current panel rows instead of the permanent activation flag. v171.90
repairs runtime and adds a destructive PostgreSQL regression test.

Cycle 1595 replaces nominal aliases with immutable UserId/TelegramId
value objects, adds explicit DB/external boundaries and a 481-file
semantic no-schema/no-ownership patch lock. Production code outside the
identity package does not import the new types. No Alembic revision or
runtime owner switch exists.
