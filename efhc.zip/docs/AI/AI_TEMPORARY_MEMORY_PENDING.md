<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

Status: ACTIVE OPERATIONAL MEMORY / SHORT-LIVED.
Archive: `v173.02`.
Cycle: `1685`.

Текущая задача: окончательная Global ID / Provider Identity миграция.

- `global_id` — единственный business owner.
- CI v173.01 был отменён на 94% из-за referral PostgreSQL lock cascade.
- Причина цикла 1684: повреждающий codemod и рассинхрон referral tests/runtime.
- Referral schema/runtime/frontend/tests переведены на `global_id`.
- Test AST-guard: business-selector нарушений `0`.
- `tg_id` разрешён только на доказанных Telegram/provider boundaries.
- Actionable/review-остаток матрицы: `1764`.
- Следующий цикл: 1686.
- Осталось пять циклов текущего плана: 1686–1690.
- Обязателен exact-head GitHub CI v173.02.

Неразрешённых governance-вопросов нет.


## Global identity document canon v173.06

- `global_id` — главный персональный идентификатор и единственный business owner.
- `tg_id` — только Telegram provider subject.
- Исторические документы восстановлены из v171.89; active SSOT/NORM исправлены.
- Guard: `python ops/identity/check_document_identity_canon.py`.
