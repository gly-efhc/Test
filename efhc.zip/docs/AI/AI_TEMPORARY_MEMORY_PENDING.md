# AI TEMPORARY MEMORY PENDING

Purpose: temporary alignment layer for short-lived but operationally important
facts that still need later consolidation into stable AI docs, canon, norm,
WORK_CYCLES, Q&A or reports.

## Rules

- Do not store permanent canon here if it already belongs in stable AI docs.
- Use this file for transitional memory that affects near-term cycles.
- After consolidation, move or remove items instead of duplicating them forever.

## Current pending items

### Frontend shell simplification (2026-04-04)

- WebApp and browser flow must be treated as one frontend shell, not as two separate products.
- Telegram is an embedded/context layer and handoff surface, not a reason to fork the TON/TonConnect/runtime stack.
- Checkout, TonConnect, TON runtime, and EFHC-owned `frontend/src/lib/ton/*` logic should stay unified across embedded Telegram entry and direct browser entry.

### Browser Shop / VIP / payment semantics

- Browser-shop MVP uses the model: one selected card or one custom amount = one
  checkout = one payment intent = one operation.
- The external Shop product surface is unified on one page and should include:
  package cards, one custom EFHC card, and EFHC VIP NFT cards.
- Hub inside Telegram remains a link/handoff screen only. Purchases stay in the
  external browser sector.
- Direct browser entry is allowed, but final confirmation requires Telegram
  linking and return to the same unfinished checkout state.
- Browser web-session is short-lived and scoped to the current checkout.
- If a Telegram-linked user already has a bound wallet in the bot, the external
  Shop should reuse that binding instead of forcing a repeated wallet-linking
  step.
- Memo-based reconciliation is the primary matching mechanism for incoming TON /
  USDT payments in MVP.
- Checkout must expose enough data for the bot/backend to verify payment and
  perform ledger postings from the bank to the user account.
- Expired or abandoned intents should remain in backend history, but must not
  pollute the visible profile history in the bot.
- Unified user-facing history in the bot stays simple: successful browser-shop
  purchase is shown as a normal incoming EFHC top-up.

### VIP semantics confirmed from archive and chat

- VIP cards/NFT are not an activation flow inside the shop; they are checked by the bot and stay a separate external/verification contour.
- VIP status itself is checked automatically by the bot.
- EFHC VIP NFT is not auto-issued after payment; instead a manual issue request
  is created in the admin area.
- Old shop logic already supports NFT VIP as a distinct item type and uses a
  manual-pending-paid order status for that flow.

### Custom and package pricing

- Custom purchase input is entered in EFHC only.
- Current base custom rate: 0.3 USDT = 1 EFHC.
- TON amount is an oracle-based floating equivalent of the USDT sum and must be
  fixed inside the intent for its TTL.
- Package cards use separately assigned manual prices.
- Minimum threshold for custom purchase: 10 EFHC.
- Quantities and calculations remain canonically compatible with 8 decimals,
  even if UI displays them in a simplified way.


### Final canon after iteration #10

- Browser-shop MVP canon: one storefront, one checkout pattern, one status
  screen, no cart, one selected product = one operation.
- Telegram linking must be mandatory before final confirmation, but the page
  should prefer automatic linking by handoff key whenever possible.
- The browser page should expose top-level controls for Telegram sync and
  wallet sync when auto-binding by key is not available.
- Economic canon reminder: user-facing wording may say incoming/outgoing for
  convenience, but real accounting logic remains debit/credit postings between
  the user and the bank.


### Operator note from current chat

- The assistant must continue writing all important chat details into temporary
  AI memory during the browser-shop planning and build-out, not only after full
  implementation cycles.

### Pricing and card-model details

- Browser-shop pricing layer must be described in detail in Russian.
- Package cards may use manually assigned prices that are independent from the
  base custom rate.
- Custom purchase uses the base rate only and starts from EFHC quantity input.
- TON amount is always the oracle-based equivalent of the current USDT total
  and is frozen inside the intent until TTL expiry.
- Product page should remain compact enough for approximately 30-50 total
  positions without introducing a cart model.
- Page-top sync controls must exist for Telegram and wallet synchronization if
  auto-binding by key is unavailable.


### Checkout / status planning details

- Unified checkout must be described as a single pattern for package cards,
  custom EFHC purchase and VIP NFT cards.
- Final checkout payload shown to the user must always include enough data for
  payment verification: payment address, memo, amount, TTL and current status.
- Status screen is its own required page/state and should differentiate text for
  EFHC-credit flows and VIP manual-issue flows.
- Documentation updates must stay in sync across AI / SSOT / NORM / GENERAL as
  cycles progress.


### Intent / memo contract details

- Browser-shop intent contract must stay strictly single-operation: one product
  or one custom amount -> one draft checkout -> one linked checkout -> one
  payment intent.
- Payment intent is created only after Telegram linking is confirmed.
- Draft checkout state may exist before linking but must not become a payment
  intent yet.
- Memo must be unique per operation and serve as the primary reconciliation key
  together with the configured receiving address and asset context.
- Intent must freeze the pricing snapshot needed for payment verification until
  TTL expiry.


### Verified memo immutability

- Current code audit confirms that client payload for external shop order does
  not include a memo field.
- `ShopOrderExternalIn` currently exposes only `sku`, `quantity` and
  `pay_method`.
- External order memo is generated server-side by `_build_memo_for_external()`.
- Route-level order flow then overwrites returned payment data with intent
  payload generated by the payment-intent layer.
- User must not be allowed to edit or replace memo in the browser-shop UI.
- Server remains the sole source of truth for memo generation.


### Anti-fraud watcher rules

- Memo alone must never grant credit.
- A payment may be credited only if there is a site-created authorized intent or
  equivalent server-side purchase signal created before the on-chain transfer.
- Watcher must ignore arbitrary incoming payments with copied/guessed memo if
  they do not match the full expected payment profile.
- Required match set for crediting:
  - existing authorized pending intent
  - correct receiving address context
  - correct asset type
  - exact expected memo
  - amount matching the frozen expected amount under the accepted rules
  - non-expired / still valid intent state
- Unmatched or underpaid memo-bearing transfers must be treated as foreign /
  unsolicited payments and must not create user credit automatically.


### Browser-shop UI/UX and return-to-bot details

- Browser-shop should look visually separate from the Telegram WebApp even
  though it lives inside the same repository.
- Storefront must stay compact, readable and single-page without cart
  complexity.
- One-card -> one-operation flow must stay visually obvious to the user.
- Status screen must clearly separate waiting, confirmed, credited/manual issue
  and expired/error outcomes.
- Return-to-bot action should stay simple: open the bot, without overcomplicated
  deep-link routing.


### MVP validation gate

- Before code-start, Hub + browser-shop must be validated as one connected MVP
  contour, not as isolated documentation fragments.
- Validation checklist must cover: Hub handoff, direct browser entry, Telegram
  linking, wallet reuse, storefront, checkout, status screen, intent contract,
  immutable memo, anti-fraud watcher rules, business logic by item type,
  user-facing history, simple return-to-bot.
- After validation, the next step is code-start, not a return to generic
  ideation, unless a new ambiguity is discovered.


### Aftercare / cleanup details before code-start

- Browser-shop code-start should not inherit unresolved placeholder texts or
  vague user messages from the planning phase.
- Aftercare for the MVP line means cleaning transitional wording, temporary
  guidance text and any ambiguous helper states around checkout/status/linking.
- Cleanup must preserve canon, NORM and audit history while removing needless
  ambiguity from user-facing strings and planning leftovers.


### Storefront code-start details

- Browser-shop now has its first real storefront-code layer, not only shell text.
- Storefront cards are loaded from backend catalog data instead of remaining
  purely static placeholders.
- Custom EFHC card still exists as a separate first-class storefront card and
  remains outside the shared catalog feed for now.
- Checkout actions are still intentionally disabled until the next cycles build
  real checkout/status/linking behavior.


### Checkout shell code-start details

- Browser-shop now has a user-clickable checkout shell instead of disabled card
  buttons only.
- Custom EFHC card opens its own checkout state with quantity input.
- Catalog-backed cards open a checkout summary with asset switch and memo/TTL
  preview.
- Status screen now exists as a separate interactive shell block, even before
  real intent/linking wiring is implemented.


### Linking and wallet-reuse code-start details

- Browser-shop bootstrap now distinguishes not only guest vs handoff-bound
  entry, but also whether an active wallet binding already exists.
- Wallet reuse is now represented in the backend bootstrap contract rather than
  being only a planning promise.
- UI sync buttons should reflect actual state: Telegram sync disabled when
  already linked, wallet sync disabled when an active wallet is already reused.


### Intent creation code-start details

- Browser-shop now has its first real intent-creation route instead of a pure
  planning shell.
- Current code-start path requires a valid handoff token and an already active
  wallet binding before intent creation is allowed.
- Intent creation reuses existing shop external order logic and payment-intent
  service instead of introducing a parallel purchase path.
- The frontend now surfaces returned memo, amount, destination wallet and order
  identifier after intent creation.


### Watcher-side matching code-start details

- Browser-shop now has its first token-based intent-status polling path.
- The external shop can ask backend for intent status using the same handoff
  identity context instead of relying on open guest polling.
- This is the first real bridge between browser-shop UI and watcher-side intent
  state, even though full business-result finishing is still in the next cycle.


### Business-finish code-start details

- Browser-shop status shell now has user-facing result text that differs for
  EFHC credit flows and VIP manual-issue flows.
- Browser-shop bootstrap can now expose a simple bot-open URL when BOT_USERNAME
  is configured in environment.
- User-facing finish now includes a simple return-to-bot action instead of only
  technical status data.


### Telegram sync action code-start details

- Browser-shop bootstrap now may expose a dedicated Telegram sync URL if
  `BOT_USERNAME` is configured.
- Telegram sync is now a real UI action for guest browser entry instead of only
  a disabled placeholder.
- Current sync action is intentionally simple: open the bot via a sync start
  link, without pretending that full automatic return-state restoration is
  already solved in code.


### Batch progress for cycles 272-276

- Wallet sync action now mirrors Telegram sync with its own practical bot-entry
  link when configured.
- Custom EFHC card now has a live USDT preview based on the base rate, while TON
  preview remains intentionally deferred to the intent-freeze stage.
- Checkout creation now enforces basic guards before intent creation:
  Telegram sync required, wallet sync required, and custom minimum threshold.
- Storefront cards now have clearer badge-like product cues for EFHC packages
  and VIP NFT entries.
- Status polling now refreshes real backend state and maps CONFIRMED/SENT into
  user-facing shell states.


### Batch progress for cycles 277-280

- Anti-fraud integration guards now explicitly block invalid pay methods, non-1
  quantities, inactive/missing storefront SKUs and unsupported pay-method/item
  combinations before browser-shop intent creation.
- `CUSTOM_EFHC` intent creation is now honestly blocked until a dedicated backend
  pricing/order flow is wired, instead of pretending the current catalog-based
  intent path already supports it.
- Admin sale-packages now has its first MVP UI in admin frontend: list, create
  and toggle active state.
- Release readiness is still not green: frontend build proof and live end-to-end
  browser-shop payment proof are still absent in this cycle.


### Batch progress for cycles 281-284

- Dedicated backend flow now exists for `CUSTOM_EFHC` intent creation.
- Current custom EFHC MVP truthfully supports `USDT` only; custom TON remains
  blocked until oracle-based pricing is wired.
- Custom intent creation now freezes the base-rate pricing snapshot at intent
  creation time and stores it in the normal `deposit_efhc` intent path.
- Browser-shop now persists checkout draft state locally and restores it after
  returning from Telegram sync or wallet sync.
- Current restore behavior is browser-state restoration, not yet a stronger
  server-verified return-state protocol.


### Batch progress for cycles 285-290

- Admin sale-packages management is now richer: list/create/edit/toggle.
- Browser-shop visible wording is cleaner and less shell-like for the user.
- Browser-shop now has browser-side draft restore for sync returns and that route/state
  path was verified in the current archive.
- Frontend `npm ci` and `npm run build` were both completed successfully in this pass after
  fixing real TypeScript breakages.
- Release gate v2 is stronger than before but still not fully green because live on-chain
  end-to-end payment proof is still absent and custom TON remains blocked.
- Remarks audit: HEAL-0010 pagination-missing issue is not confirmed as current; `Pagination`
  exists in `admin_logging.py` and is imported/exported.


### Batch progress for cycles 291-300

- HEAL-0018 received a first targeted code treatment in `withdraw_service.py` via
  nested-aware transaction context.
- HEAL-0016 TON validator wave now reuses TonConnect parser semantics in wallet
  normalization and withdraw-address validation.
- A regression test file for realistic TON addresses was added, but truthful test
  execution was blocked in this pass by missing importable SQLAlchemy in the local
  test environment.
- HEAL-0010 pagination-missing issue was checked again and still does not confirm as
  a current live bug.
- Skins/VIP healer items remain audited but not falsely declared closed.
- Browser-shop release gate v3 is stronger but still not fully green.


### Batch progress for cycles 301-310

- `Session already begun` wave received targeted continuation in energy/referral/tasks/wallet-binding services via nested-aware `_begin_tx(db)` helpers.
- This remains a targeted healer treatment, not a universal claim that every transaction-boundary issue in the whole project is now gone.
- Current line72 snapshot for Python tests in this pass: 243 violations above 72 chars.
- Release gate v4 remains non-green mainly because live payment proof and broader healer cleanup are still missing.


### Emergency backend line72 correction

- User clarified that the main urgent question is line72 in backend.
- Direct measurement in current HEAD showed 10 backend Python line72 violations before the emergency fix.
- After targeted wrapping in backend files, current backend line72 snapshot in this pass is 0 violations.
- Tests still remain non-green for line72 in this pass: 151 violations after formatter-assisted reduction.


### Emergency degradation memory — 2026-04-02

- Main urgent user concern is line72 in backend.
- Backend line72 was measured directly and reduced from 10 violations to 0.
- Tests line72 remains non-green: 151 violations in the current slice.
- Long package waves previously degraded because final control checks were not
  always re-run before moving to the next queue.
- Confirmed process degradations from archive history:
  - backend line72 drift;
  - tests line72 drift;
  - delayed final verification layer;
  - queue continuity slip in chat;
  - English roadmap leakage in chat;
  - delayed synchronous update of AI/NORM/GENERAL/registries in some waves.
- Existing planned queue after 311 must be pushed further until anti-degradation
  cycles are completed.


### Cycle 312 completion result — tests line72 emergency wave

- tests line72 was reduced from 151 to 0 in the current slice.
- `python -m compileall tests` passes after syntax repairs in the touched tests.
- Current archive audit still does not prove that most special control tests
  vanished; the stronger conclusion is that many controls still exist, but the
  mandatory final verification layer was not rerun consistently enough.


### Recovered legacy controls from v157 archive

- old archive contained a stricter compact control model that must remain alive
  in the current AI layer;
- especially important restored controls: logs-first CI truth, no green claims
  without fresh logs, no ZIP without real changes, mandatory reports/registries
  after confirmed cycles, tg_id only, 2 DB schemas, bank/withdraw/economic
  canon, periodic docs-vs-code sync, and CI runner reproducibility controls.


### Cycle 314 continuity enforcement

- Queue continuity and Russian-only roadmap are now treated as first-class
  control rules rather than stylistic preferences.
- Any future emergency-wave must explicitly insert new cycles and shift the old
  queue forward instead of silently jumping over it.


### Cycles 315-317 emergency enforcement

- Synchronous update of AI/NORM/GENERAL/registries is now a hard control rule.
- Archive audit still shows that many guard tests exist; the real weakness was
  final verification rerun discipline.
- Postgres-only policy for row-lock / SQL-function sensitive tests is now
  explicitly recorded.


### Russian-only chat enforcement reminder

- User-facing cycle descriptions must remain fully Russian.
- Any recurrence of English cycle wording in chat is treated as a control
  degradation, not as a cosmetic slip.


### Cycles 321-330 release-wave reminder

- Live payment proof cannot be claimed without a real on-chain payment event and
  captured evidence.
- In the absence of a live payment event, release-wave cycles must remain honest
  and operate through preparation, verification, gates and consolidated risk
  audits.

## Cycle 331 manual log-fix wave
- Источник истины по блоку: logs_63144383921.zip.
- Нельзя считать логовый пакет закрытым только по compileall; нужен свежий subset-proof или новый CI-log.
- В этой среде часть локальных pytest/bandit доказательств ограничена отсутствием установленных инструментов (sqlalchemy/bandit).

## Cycle 332 manual log-fix wave
- Источник: logs_63146798186.zip.
- Исправлены вручную новые блокеры после cycle 331:
  - mypy undefined name safe_payment_intents_table;
  - frontend build type error в BrowserShopPage className;
  - stale/duplicate import headers в ряде тестов вскрыли новую ruff-wave.
- Текущий остаток после ручного пакета: 26 ruff/import ошибок в tests + payment_intents_service scope cleanup still needs fresh ruff proof.

## Cycle 333 manual ruff-wave closure
- Продолжение logs_63146798186.zip.
- Добита остаточная ruff/import волна по целевому пакету test files и payment_intents_service.
- Подтверждено: ruff по целевому пакету файлов проходит.
- Ограничение: это не означает автоматически зелёный полный CI; нужен новый лог после архива.

## Cycle 334 manual pytest gate fix
- Источник: logs_63148944432.zip.
- Gate summary показал: после cycle 333 все шаги зелёные, кроме pytest.
- Подтверждённая причина pytest fail: у panel tests исчез async-marking, поэтому CI видел async def без поддержки.
- Bandit warnings по nosec не были gate-fail в этом логе.

## Cycle 335 green CI proof
- Источник: logs_63150433402.zip.
- Подтверждено по 24_Gate summary.txt: все gate steps прошли с exit=0.
- Это первый подтверждённый зелёный CI после логовых волн 331-334.
- Подтверждены: alembic, bandit, compileall, flake8, mypy, npm build, pytest, ruff.

## Cycle 336 docs-before-build rule
- Новое контрольное правило пользователя: документы текущего цикла должны быть заполнены до сборки релизного ZIP, а не догоняться следующим циклом.
- Перед выдачей архива обязательно сначала синхронно обновить AI / SSOT / NORM / GENERAL, WORK_CYCLES, Q&A, Healer и reports, и только потом собирать ZIP.

## Cycles 337-345 pending carry-forward
- User `GET /withdraw/list` is now read-only; withdraw repair moved out of the user read path and into admin-only execution.
- `/exchange/convert/{tg_id}` now preserves the `amount_kwh` contract: omitted amount = full exchange, explicit amount = partial exchange.
- `api/index.py` now loads `.env` before importing `app.main`.
- `backend/app/__init__.py` now delegates `create_app()` to the canonical `app.main.app`.
- USDT live checkout path is temporarily disabled until a real jetton transfer payload exists.
- Cycle 346 remains open for real jetton transfer implementation or a stronger deferred-state package.

## Cycle 346 deferred-state closure
- Cycle 346 closed via a stronger deferred-state package instead of a fake real-jetton claim.
- USDT is now blocked earlier in hub/shop/payment-intents/catalog layers, not only at final tx assembly.
- Honest live state: TON-only checkout until a real TEP-74 jetton payload can be generated and proven.

## Cycle 347 sandbox curation
- A new local folder `песочница/` was created in HEAD.
- It contains 10 curated donor sources for future cycles: sdk-main,
  reactjs-template, nextjs-template, demo-telegram-bot, pytonconnect,
  telegram-web-app-shop, telebook, react-telegram-web-app,
  tma-starter-kit, fastapi-telegram-mini-app.
- Main donor priority for real USDT jetton transfer: `sdk-main`.


## Cycle 348 donor audit + EFHC jetton canon
- Пользователь потребовал продолжить работу и добавить в канон его EFHC jetton.
- Подтверждено по current HEAD: `EFHC_JETTON_MASTER_ADDRESS` уже имеет живое значение `EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw` в config-layer.
- Это значение зафиксировано в каноне как внешний EFHC jetton (`EFHCj`) с decimals d8.
- Выполнен только аудит и карта переноса доноров; live implementation real USDT jetton transfer в этом цикле не заявлялась.
- Главный документ текущей подготовительной фазы: `docs/GENERAL/USDT_REAL_JETTON_DONOR_AUDIT_AND_TRANSFER_MAP.md`.

## Cycles 349-354 donor integration prep
- Пользователь потребовал продолжить циклы 349-354 аккуратно, вручную и без спешки, с оперативным заполнением документов и логов.
- В этой волне выполнен подготовительный audit package без ложного заявления о live USDT implementation.
- Зафиксированы отдельные документы по donor surface (`sdk-main`), frontend adapter plan, recipient/payload/fee decisions, backend intent/watcher alignment, guard-test package и live gating.
- Главный текущий вывод: `sdk-main` даёт минимально достаточный donor surface через `TransferUsdt.tsx` + units helpers + SDK dependency set; остальная песочница остаётся reference-only.

## Cycles 355-370 implementation wave progress
- Пользователь потребовал продолжить циклы 355-370 аккуратно, вручную и без спешки, с оперативным заполнением документов и логов.
- В этом проходе закрыта безопасная стартовая часть implementation wave без ложного включения USDT live.
- Подготовлены и добавлены frontend foundation files:
  - `frontend/src/lib/ton/units.ts`
  - `frontend/src/lib/ton/payload.ts`
  - `frontend/src/lib/ton/policy.ts`
  - `frontend/src/lib/ton/index.ts`
- Локально подтверждено: targeted TypeScript check по `src/lib/ton/*.ts` проходит.
- Ограничение: полный frontend build-proof и dependency install wave не заявлялись в этой среде.

## Cycles 356-370 current pass
- Проведена dependency manifest wave во frontend: `frontend/package.json` и `frontend/package-lock.json` обновлены под `@ton/core`, `@ton/ton`, `@ton-community/assets-sdk`.
- Честное ограничение: `npm install` в этой среде упирается в `E401 Incorrect or missing password`, поэтому node_modules/install-proof и full build-proof не заявляются.
- Добавлены дополнительные safe helper files:
  - `frontend/src/lib/ton/constants.ts`
  - `frontend/src/lib/ton/recipient.ts`
- Локально подтверждено: targeted `tsc` по `src/lib/ton/*.ts` проходит и после расширения helper-layer.

## Cycles 358-370 current pass
- Продолжена implementation wave после dependency manifest pass.
- Добавлены новые files:
  - `frontend/src/lib/ton/tx.ts`
  - `frontend/src/lib/ton/usdt-transfer-plan.ts`
- `usdt-transfer-plan.ts` не строит TEP-74 body сам, но уже нормализует:
  - asset/decimals,
  - canonical payload,
  - recipient policy,
  - fee policy,
  - query_id,
  - sender/response addresses.
- Локально подтверждено: targeted `tsc` по `src/lib/ton/*.ts` проходит и после этих файлов.
- Честная граница: real SDK-backed builder cycle всё ещё не заявляется завершённым.

## Cycles 358-370 backend intent enrichment pass
- Продолжена implementation wave по safe path без ложного USDT live enable.
- Backend слой enriched optional transport metadata в intent/status responses:
  - `tonconnect_transport_kind`
  - `jetton_master_address`
  - `jetton_decimals`
  - `forward_payload_text`
  - `fee_message_ton_amount`
  - `forward_ton_amount`
  - `recipient_strategy`
- Изменены:
  - `backend/app/services/payment_intents_service.py`
  - `backend/app/schemas/hub_schemas.py`
  - `backend/app/schemas/deposit_schemas.py`
  - `backend/app/schemas/payment_intents_schemas.py`
  - frontend local types in `BrowserShopPage.tsx`
- Локально подтверждено: compileall по изменённым backend Python-файлам проходит.

## Cycles 358-370 SDK-backed builder pass
- Написан unverified implementation слой для будущего real jetton transfer:
  - `frontend/src/lib/ton/jetton-transfer-builder.ts`
  - `frontend/src/lib/ton/usdt-transfer.ts`
- Builder-layer содержит:
  - sender jetton wallet resolution;
  - balance read attempt;
  - forward payload cell build;
  - jetton transfer body build;
  - TonConnect tx assembly;
  - high-level `buildUsdtTransfer(...)` adapter.
- Честная граница: из-за отсутствия установленного TON SDK в среде это unverified implementation pass, не runtime-proof.
- Локально подтверждено только syntax-level proof через TypeScript transpileModule; module-resolution/runtime proof не заявляется.

## Cycles ongoing — browser-shop transport integration pass
- Добавлен `frontend/src/lib/ton/browser-shop-intent.ts`.
- Новый helper умеет читать transport metadata из browser-shop intent и собирать builder-ready USDT transfer plan без смешения UI и blockchain policy.
- `BrowserShopPage.tsx` теперь безопасно показывает transport metadata preview, если backend уже отдаёт эти optional поля.
- Локально подтверждено:
  - targeted `tsc` по pure local TON files, включая `browser-shop-intent.ts`, проходит;
  - syntax-level transpile proof по `BrowserShopPage.tsx` проходит.

## Current pass — readiness and tx normalization
- Добавлены:
  - `frontend/src/lib/ton/tonconnect-normalize.ts`
  - `frontend/src/lib/ton/usdt-readiness.ts`
- BrowserShopPage теперь умеет:
  - нормализовать raw `tonconnect_tx` в локальный `TonConnectTx` preview;
  - честно показывать readiness будущего USDT builder path;
  - выводить список недостающих transport metadata полей.
- Локально подтверждено:
  - targeted `tsc` по pure local TON files проходит;
  - syntax-level transpile proof по `BrowserShopPage.tsx` проходит.

## Current pass — runtime gate state integration
- Добавлены:
  - `frontend/src/lib/ton/feature-gates.ts`
  - `frontend/src/lib/ton/browser-shop-usdt-runtime.ts`
- BrowserShopPage теперь умеет показывать:
  - `runtime mode`;
  - `USDT runtime status`;
  - `preview-ready`;
  - `checkout-ready`;
  - `blocking reasons`.
- Локально подтверждено:
  - targeted `tsc` по pure local TON files проходит;
  - syntax-level transpile proof по `BrowserShopPage.tsx` проходит.
- Честная граница: live USDT state остаётся disabled; runtime proof builder/adaptor слоя по-прежнему не заявляется.

## Current pass — server-truth USDT mode integration
- Backend truth-point добавлен: `usdt_checkout_mode` теперь проходит через browser-shop bootstrap и payment-intent transport contracts.
- Frontend gate/state helper теперь учитывает server mode.
- BrowserShopPage показывает серверный режим отдельно от локального runtime summary.
- Локально подтверждено: compileall backend; targeted tsc по pure local TON files; transpile proof страницы.
- Жёсткая граница сохраняется: live USDT mode всё ещё `disabled`.

## Current pass — watcher transport split + command summary integration
- Добавлен `frontend/src/lib/ton/browser-shop-usdt-command.ts`.
- Добавлен `backend/app/services/watcher_transport.py`.
- `watcher_service.py` теперь опирается на transport decision layer для разделения `native_ton / efhc_jetton / jetton_transfer`.
- Подтверждено: `3 passed` для `tests/architecture/test_watcher_transport_modes.py`.

## Current pass — watcher validation hardening
- `watcher_transport.py` теперь различает `unknown_jetton`.
- Добавлена `validate_payment_intent_transport(...)`.
- `watcher_service.py` теперь переводит unsupported transport cases в `pending_manual` с записью в `unmatched_incoming`.
- Подтверждено: `6 passed` для `tests/architecture/test_watcher_transport_modes.py`.

## Current pass — log-fix wave: repo hygiene + mypy/ruff
- Исправлен подтверждённый mypy issue в `transactions_service.TxResult`.
- Удалён `frontend/tsconfig.tsbuildinfo`.
- `песочница` исключена из repo-wide guard tests как donor-store.
- `tg-id alias` заменён на `tg_id` во frontend TON helper files.
- Добавлен SSOT lock comment в `exchange_service.py`.
- Локально подтверждено: mypy success, ruff success, 15/15 локально на пакете упавших CI tests.

## Current pass — tg-id alias doc cleanup + blocker registry
- Исправлен свежий log fail: `test_no_tg_id_aliases_repo` теперь проходит.
- Документы и реестры очищены от alias-формы `tg-id alias` / прежних упоминаний.
- В `WORK_CYCLES.md` зафиксирован честный список причин, почему ещё не закрыты 356, 358–364, 368–370.

- 2026-04-03: Cycle 368 advanced again: added process-level watcher tests for already_final, foreign wallet skip, native TON intent path, plus retained unknown/usdt jetton intent checks. Local proof: 11 passed across watcher transport/process test package.

- 2026-04-03: Cycle 368 advanced again: watcher process-level tests now cover unknown jetton block, USDT confirm D6 path, already_final short-circuit, foreign wallet skip, native TON intent path, and confirm-failure->pending_manual branches. Local proof: watcher suite 13 passed; payment-intent USDT suite 2 passed, 3 skipped.

- 2026-04-03: New log `logs_63240230827.zip` fixed locally. Resolved: watcher_service schema drift on ton_inbox_logs.utime, repo docs alias in WORK_CYCLES, and ruff import order in watcher process tests. Local proof: mypy backend/app success; ruff backend/api/ops/tests success; targeted pytest package 16 passed, 3 skipped.

- 2026-04-03: New log `logs_63241331034.zip` fixed locally. Removed asyncpg ambiguous parameter issue in watcher upsert by casting status and replacing parameterized status comparisons with literal final-status checks. Local proof: targeted pytest package 16 passed / 3 skipped; ruff success; mypy success.

- 2026-04-03: Added `ton-access-main` and `ton-crypto-master` into `песочница/` as TON donor/reference archives for simplifying the runtime dependency path.

- 2026-04-03: one-pass blocker attack: removed `@ton-community/assets-sdk` from active runtime path and rewrote jetton builder to low-level `@ton/core` + `@ton/ton` only. Then rechecked npm install blocker.

- 2026-04-03: added `ton-core-main` and `ton-main` into `песочница/` as local source donors for the minimal TON runtime path.

- 2026-04-03: major blocker attack continued. Removed `@ton/core` and `@ton/ton` from npm dependency path, mapped them to local sandbox sources via `tsconfig.json`, regenerated lockfile, and re-checked npm. Result: old TON/package blocker moved forward; current npm E401 now hits `@tonconnect/ui-react` / `@tonconnect/ui` (and dev install previously also hit `@types/node`).

- 2026-04-03: audited sandbox for TonConnect UI. Main donor is `sdk-main`; local source donors for runtime path are `ton-core-main`, `ton-main`, `ton-crypto-master`; `ton-access-main` remains endpoint reference only.
- 2026-04-03: breakthrough on main frontend blocker. TonConnect UI npm package removed from active dependency path; local compat layer added on top of sdk-main source donors. `npm ci` now passes. Remaining blocker moved from install-layer to type/build proof in local donor sources.
- 2026-04-03: sandbox audit refreshed again. Newly uploaded archives added to `песочница/` only as secondary reference-pool; main blocker donors unchanged.
- 2026-04-03: second missing-batch audit completed; 5 new UI/reference archives added to `песочница/`. Main blocker donors unchanged.
- 2026-04-03: main install blocker stays resolved. Additional pass pushed Next build deeper by patching local sdk/protocol donor-source typing; current residual blocker is isolatedModules/export-type compatibility inside local TonConnect donor sources.
- 2026-04-03: continued build/type attack on local `sdk-main` donors. Next build now reaches deeper local `sdk` export surfaces after protocol fixes and local type shims. Residual blocker moved from protocol entrypoint to `sdk/src/models/index.ts`.
- 2026-04-03: deep audit pass on cycles 358–359. `npm ci` still green; `next build` pushed deeper again. Current top stop moved from protocol entrypoint to `sdk/src/models/index.ts`, confirming the blocker is now localized inside donor-source type exports.
- 2026-04-03: extended sandbox attack on 358–359. Build moved from `sdk/src/index.ts` to `sdk/src/models/index.ts`. Re-run of `npm ci` later in the same session regressed with registry 401 on unrelated packages (`@twa-dev/types`, `@tanstack/query-core`), which looks like an environment/auth fluctuation rather than the old TON blocker.
- 2026-04-03: strategic plan fixed in docs. New order: (1) unify one TON runtime path, (2) add browser polyfill layer, (3) only then return to full USDT runtime logic. Work started: `frontend/src/polyfills.ts` added and imported first in `_app.tsx`; `buffer` added to frontend deps.

- 2026-04-04: Added missing TON/TonConnect donors to sandbox and locked a simpler official runtime strategy: published TON runtime packages + Tonkeeper-compatible TonConnect UI/SDK path.

- 2026-04-04: clarified project rule — the external storefront may live in the same backend/admin repository, but remains an external storefront. Telegram-side EFHC/VIP handoff must not be treated or worded as an in-app sale flow.

- 2026-04-04: unfinished queue rebased. Preserve cycle numbers 358-370, but treat them under the common direction: one external storefront, one frontend shell, Telegram as handoff/context only, shared runtime path, EFHC top-up split from VIP verification.

- 2026-04-04: common-shell advance pack landed. TonConnect compat restore state no longer stays hardcoded false; guard pack now protects one provider, external EFHC handoff split, and unified storefront norm sync.
