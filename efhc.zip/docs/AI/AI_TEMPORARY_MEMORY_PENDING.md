Status: ACTIVE OPERATIONAL MEMORY / SHORT-LIVED.
Archive: `v173.01`.
Cycle: `1684`.

Текущая задача: окончательная Global ID / Provider Identity миграция.

- `global_id` — единственный business owner.
- Transactions, ledger, balances и wallets переведены в цикле 1684.
- Test AST-guard: business-selector нарушений `0`.
- `tg_id` разрешён только на доказанных Telegram/provider boundaries.
- Actionable/review-остаток матрицы: `2019`.
- Следующий цикл: 1685.
- Осталось шесть циклов текущего плана: 1685–1690.
- Обязателен exact-head GitHub CI v173.01.

Неразрешённых governance-вопросов нет.
