Status: ACTIVE OPERATIONAL MEMORY / SHORT-LIVED.
Archive: `v173.02`.
Cycle: `1685`.

Текущая задача: окончательная Global ID / Provider Identity миграция.

- `global_id` — единственный business owner.
- CI v173.01 был отменён на 94% из-за referral PostgreSQL lock cascade.
- Причина цикла 1684: повреждающий codemod и рассинхрон referral tests/runtime.
- Referral schema/runtime/frontend/tests переведены на `global_id`.
- Test AST-guard: business-selector нарушений `0`.
- `tg_id` разрешён только на доказанных Telegram/provider boundaries.
- Actionable/review-остаток матрицы: `1764`.
- Следующий цикл: 1686.
- Осталось пять циклов текущего плана: 1686–1690.
- Обязателен exact-head GitHub CI v173.02.

Неразрешённых governance-вопросов нет.
