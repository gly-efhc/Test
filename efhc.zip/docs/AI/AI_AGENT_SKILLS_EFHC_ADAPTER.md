# AI Agent Skills EFHC Adapter

## Purpose

Agent Skills are installed in EFHC Bot as a controlled AI/KERNEL/GATE layer.
They strengthen the existing archive-first workflow and do not replace it.

The target working loop is:

```text
request
→ read AI / SSOT / NORM / HEAD
→ classify risk
→ choose skill or lightweight route
→ specify / plan only as needed
→ implement a bounded slice
→ verify with targeted tests and guards
→ update reports / Healer / registry / Kernel
→ package a clean archive
```

## Priority order

1. Live user instruction in the current chat.
2. Current HEAD archive.
3. `docs/AI/AI_ARCHIVE_LAWS.md`.
4. `docs/AI/AI_OPERATOR_RULES_EFHC.md`.
5. `docs/SSOT/SSOT_INDEX.md` and product SSOT documents.
6. `docs/NORM/*` and architecture locks.
7. This adapter document.
8. Root `AGENTS.md`, `CLAUDE.md`, commands, personas and skills.
9. Upstream Agent Skills reference material.

Agent Skills cannot lower or bypass stronger EFHC rules.

## Threshold model

### P0 — skill and gate required

Use skill workflow and EFHC gates for money, balances, Bank to User movement,
withdraw, TON, TonConnect, wallet binding, payment intents, idempotency, auth,
Telegram InitData, admin permissions, DB schema, ORM, Alembic, migrations,
public API contract, generated seams, public frontend API access, public copy,
security, env, secrets and release decisions.

### P1 — skill required by default

Use skill workflow for public pages/components, React Query hooks, service API,
i18n, visual proof harnesses, OpenAPI docs, scheduler/background tasks,
reports, Healer and registry changes.

### P2 — lightweight route allowed

Formatting, index sync, internal-doc spelling, pure renames and comments may use
a lightweight route. Even P2 work must not weaken tests, guards, docs or locks.

## Skill mapping

- Spec and new change design: `spec-driven-development`.
- Plan or decomposition: `planning-and-task-breakdown`.
- Bounded implementation: `incremental-implementation`.
- Tests and guard proof: `test-driven-development`.
- Log repair: `debugging-and-error-recovery`.
- Review: `code-review-and-quality`.
- Auth, TON, wallet, admin, env and secrets: `security-and-hardening`.
- API, DTO, OpenAPI and generated seams: `api-and-interface-design`.
- Player-facing UI, public-copy firewall and React Query: `frontend-ui-engineering`.
- Legacy and migration work: `deprecation-and-migration`.
- CI work: `ci-cd-and-automation`, with EFHC CI-boundary rules.
- Documentation and ADRs: `documentation-and-adrs`.
- Reports, request IDs and audit trail: `observability-and-instrumentation`.
- Measure-first performance work: `performance-optimization`.
- Visual/runtime proof: `browser-testing-with-devtools`.
- External libraries and standards: `source-driven-development`.
- High-risk or irreversible decisions: `doubt-driven-development`.
- Context capsules: `context-engineering`.
- Safe simplification only: `code-simplification`.
- Go/no-go review: `shipping-and-launch`.

## Command mapping

`/spec` creates or updates EFHC-approved documents such as `docs/audits/tz_v*.md`
or stable AI/NORM documents. It does not create root `SPEC.md` by default.

`/plan` produces a chat plan or updates approved cycle/report documents. It does
not create `tasks/plan.md` by default.

`/build` implements one bounded repair slice, then runs targeted checks and
updates reports, Healer and registry when the change is confirmed.

`/test` chooses relevant targeted checks and clearly separates local checks,
GitHub CI and live proof.

`/review` checks code quality, architecture locks, SSOT/NORM compliance, money,
auth, API, public UI, i18n and test weakening.

`/ship` is a no-go/go review only. Without fresh GitHub CI and required live
proof, the maximum honest verdict is locally prepared, not production-ready.

## Hard prohibitions

- Do not modify CI without explicit user request.
- Do not claim GitHub CI green from local checks.
- Do not claim release-ready or production-ready without evidence.
- Do not create `0002+` migrations before release without explicit approval.
- Do not weaken tests, guards or public-copy/public-API gates.
- Do not change money/auth/TON/withdraw/migration logic without high-risk gate.
- Do not create temporary NORM plans where a stable rule or report is required.
- Do not use upstream Agent Skills as product SSOT.

## Validation discipline

Every non-trivial change must end with the narrowest meaningful evidence:
scanner, architecture guard, targeted pytest, typecheck, compileall, report, or
uploaded CI log. Missing live proof must be stated as not performed.
