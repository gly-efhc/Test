<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC OPERATOR KERNEL — CURRENT ROUTE MAP

Статус: **ACTIVE / v173.12 / cycle 1692**.

| Domain | Route | Current sources | Mandatory guards |
|---|---|---|---|
| global identity | `global_id_canonicalization` | `GLOBAL_IDENTITY_SSOT`, `GLOBAL_IDENTITY_RUNTIME_NORM`, `check_global_id_canon.py` | `business_owner_tg_id = 0`, one `0001`, no numeric external `global_id` |
| provider boundary | `identity_semantic_registry` | `identity_registry.py`, `identity_registry_v2.json`, `check_tg_id_domain_boundary.py` | exact per-file provider allowlist, no new/increased surface |
| API contract | `global_id_api_contract` | Pydantic/OpenAPI/frontend seam generators | string `^[0-9]{10}$`, no provider owner |
| CI log repair | `ci_log_exact_failure_repair` | supplied exact logs and current source | repair causes, targeted checks, `EXACT_HEAD_CI_REQUIRED` |
| release archive | `archive_numbering_and_release_gate` | release builder, portability and ZIP guards | flat root, no artifacts/tests in RELEASE, byte-identical MATRIX copies |
| active tests | `active_test_surface` | `check_active_test_surface.py`, test archive manifest | archived tests not collected, business calls require `global_id` |

Routes for `user_id` expand, migration `0002/0003`, dual-write,
shadow validation, reconciliation and read-switch are historical. Their
sources are stored under `АРТЕФАКТЫ/Код/` and are not Operator Kernel
routes.
