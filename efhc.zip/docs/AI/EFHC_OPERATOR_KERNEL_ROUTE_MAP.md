<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# Блокировка цикла 1611

`user_identities` является provider-neutral EXPAND storage. Revision
`0003` создаёт таблицу и constraints без backfill, runtime resolver,
account/session issue, ownership switch или financial writes. Реальный
PostgreSQL run и `PG-0 PASS` в среде чата не выполняются; существующие
CI workflows неизменяемы.

| Domain | Route | Runtime files | Main guards |
|---|---|---|---|
| user_identities_postgresql_package | `user_identities_postgresql_package` | `identity_models.py`, `0003_user_identities_expand.py`, `pg0_user_identities_preflight.py` | EXPAND only, ORM/DDL parity, immutable CI hashes, PG-0 prepared/not executed |

# Блокировка цикла 1610

`AuthContext` является provider-neutral внутренним контрактом и
формируется только из nominal `GlobalId` и `VerifiedIdentity`.
`IdentityResolver` в цикле 1610 существует только как fail-closed
interface/result contract без БД и account resolution. Endpoint response
не раскрывает provider subject или session reference, а redaction skeleton
маскирует credentials до последующей runtime-интеграции. Legacy
`app.deps.AuthContext` и действующие routes не переключаются.

| Domain | Route | Runtime files | Main guards |
|---|---|---|---|
| auth_context_contracts_foundation | `auth_context_contracts_foundation` | `auth_context.py`, `resolver_contracts.py`, `auth_redaction.py` | sealed construction, no provider owner, no domain imports, endpoint minimization, diagnostic redaction, Alembic `0002` |

# Блокировка цикла 1609

`AuthProvider` и `VerifiedIdentity` являются provider-neutral
контрактами. Provider registry работает fail closed, Telegram не
является root provider, а `global_id` остаётся единственным account
owner. До последующих циклов запрещены DDL, account resolution,
sessions, backfill, read switch и financial ownership switch.

# CURRENT ROUTE MAP ADDENDUM — v171.95

| Domain | Route | Runtime files | Main guards |
|---|---|---|---|
| user_id_legacy_alias_harness | `user_id_legacy_alias_harness` | `legacy_alias.py`, `user_id_backfill.py`, `User.legacy_runtime_id` | alias boundary, global_id boundary, backfill harness tests |

## Retained route map addendum — v171.94

Identity schema EXPAND uses exact route `user_id_expand_migration`.

# EFHC_OPERATOR_KERNEL_ROUTE_MAP

Status: ACTIVE ROUTE MAP.
Archive: `v171.93`.

| Domain | Canon / SSOT / NORM | Runtime files | Tests | Reports |
|---|---|---|---|---|
| user_id_api_contract | User Identity Auth SSOT; API Contracts NORM | `backend/app/identity/api_contract.py`; API boundary guard | `test_user_id_api_contract_preparation.py`; API contract tests | cycle-1596 OpenAPI and archive evidence |
| user_id_value_type_adoption | User Identity Auth SSOT; Identity Migration NORM | `backend/app/identity/types.py`; value-type boundary guard | `test_user_id_value_type_adoption.py`; UserId unit/annotation tests | cycle-1595 boundary and archive reports |
| user_id_contract_foundation | User Identity Auth SSOT; Identity Migration NORM | `backend/app/identity/types.py`; `ops/identity/**` | `test_user_id_contract_foundation.py`; UserId unit tests; LEGACY compatibility tests | V2 boundary, patch lock and cycle-1594 reports |
| user_identity_migration | User Identity Auth SSOT; Identity Migration NORM | current legacy identity runtime and later auth core | later auth, migration and PostgreSQL suites | identity audit, backfill and reconciliation reports |
| startup | `START_HERE.md`; AI Archive Laws chain; Kernel Standard | `route_resolver.py`; `file_map.summary.json` | governance entrypoint and Kernel restore guards | startup receipt |
| operator_kernel | Kernel SSOT; Kernel Protocol; restoration NORM; preserved v171.47 reference | `ops/operator_kernel/**`; `routes.yaml` | `test_operator_kernel_*` | `operator_kernel_full_restore_v171_62.json`; current v171.64 governance sync report |
| cycle_1573_close | visual contracts; Wallet/TonConnect SSOT; Kernel Standard | visual proof script; live contour gate; targeted TON tests | compound routing, visual provenance, live fail-closed gate | `visual_proof_v171_63.json`; `live_gate_v171_63.json` |
| cycle_1574_local_rc_audit | release-readiness master plan; release proof status; Kernel | audit/test/report surfaces selected by exact findings | targeted local audit guards; archive integrity; truthful deferred-boundary checks | current cycle 1574 audit report |
| release_archive_update | provider deployment SSOT; provider release NORM; update policy and runbook | `update.sh`; `rollback.sh`; safe extractor; release builder | `test_release_v171_72_archive_update.py`; portability gate | update state/history and release receipts |
| provider_independent_release | provider deployment SSOT; provider release NORM; portability and go-live runbooks | production Dockerfiles; release Compose; Caddy; release scripts and gates | `test_provider_independent_release_portability.py` | provider portability, local 99 and release archive receipts |
| control_docs | Kernel SSOT/Standard/Protocol; AI/SSOT indexes; Architectural Locks | classifier/resolver/capsule; active docs | compaction, duplicate, contradiction, filename and route behavior guards | `control_docs_audit_v171_63.json` |
| frontend_visual | Visual Public UI NORM; Frontend Visual Contract; Screen Registry; Screenshot QA | affected `frontend/src/**`; route-backed audit script | visual/component/e2e guards | route-backed visual audit |
| bottom_navigation | Architectural Lock: fixed six tabs; visual contract | bottom-nav component, route declarations, locales, styles | six-button order/route/i18n/responsive guards | visual browser report |
| i18n | Language Canon SSOT; Localization Workflow NORM; I18N docs | locales/i18n/components | hardcoded scan, locale diff, typecheck | i18n audit reports |
| telegram_webapp | Telegram WebApp SSOT; shell architecture/polish | Telegram library, layout, app shell | shell/safe-area/back-button tests | Telegram boundary report |
| wallet_provider | Wallet Provider SSOT; Wallet Provider Adapter NORM; Wallets TonConnect SSOT | `frontend/src/lib/wallet-provider/**`; app shell; wallet money-flow consumers | `test_wallet_provider_adapter_layer.py`; TonConnect/TonProof regression tests | `wallet_provider_native_adapter_v171_66.json` |
| tonconnect | Wallets TonConnect SSOT | TonConnect frontend/backend services/routes | wallet connection/session tests | wallet proof boundary report |
| tonproof | Wallets TonConnect SSOT; Ton memo spec | proof envelope verification/binding code | proof challenge/envelope/replay tests | TonProof boundary report |
| transactions | Exchange/Withdraw mechanics; payment flow norms | transaction wrappers, intents, services | idempotency/atomicity/status tests | transaction contour logs/report |
| wallet | Wallet identity and TonConnect SSOT | wallet components/services/routes/models | wallet ownership/session tests | wallet reports |
| withdraw | Withdraw Admin TonConnect SSOT; Withdraw Flow NORM; Withdraw Audit Canon | withdraw API/service/UI/admin | withdraw create/cancel/status/operator tests | withdraw reports |
| exchange | Exchange/Withdraw mechanics SSOT | exchange page/service/backend | exchange invariant tests | exchange reports |
| panels | Panels SSOT | panels page/service/backend | panel economics/status tests | panels reports |
| tasks | Tasks execution/public boundary locks | tasks page/service/backend | reward/idempotency/public-surface tests | tasks reports |
| referrals | referral SSOT/current product anchors | referrals page/service/backend | referral economics/navigation tests | referral reports |
| ranks | rank/language product anchors | ranks page/service/backend | rank requirement/progress tests | rank reports |
| admin | Admin UI kit and permission locks | admin pages/components/routes/services | admin permission/interaction/audit tests | admin reports |
| screenshots | Screenshot QA; real-route proof boundary | route-backed Playwright/Chromium scripts | provenance/page.goto/schema guards | browser JSON + companion ZIP |
| ci_logs | AI Archive Laws; execution/validation norms | failing code/test; CI files only when authorized | targeted then bounded regression | supplied/fresh logs only |
| healer | Healer capsule; exact routed guards/cases | healer docs/index tools | recurrence guards | incident report |
| archive_build | archive numbering/hygiene boundary | build/hygiene scripts | ZIP hygiene/integrity checks | change report |
| release_build | release proof status; deploy/rollback norms | release scripts/templates | exact-HEAD CI/live proof gates | release evidence report |
| development_archive | Kernel archive boundary | current source tree | targeted validation + hygiene | development handoff |
