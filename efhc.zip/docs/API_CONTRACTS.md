# API_CONTRACTS (EFHC) — Контракты routes ↔ services

Статус: NORM (исполняемые контрактные требования).
Якорь SSOT: docs/SSOT_INDEX.md

Цель:
- Зафиксировать контракт между HTTP-роутами и сервисами.
- Убрать зависимость от чатов: вход/выход/ошибки/идемпотентность/права.

Правила контракта (общие):
- Канон пользователя: только tg_id.
- Пагинация списков: next_cursor + limit.
  - encode_cursor/decode_cursor — кодирование/декодирование
    курсора без раскрытия внутренних ключей.
  - CursorPage: items + next_cursor (или null).
- Формат ошибок: единый объект (см. docs/EFHC_CANON.md).
- Денежные/энергетические величины: Decimal, округление вниз.
- Идемпотентность обязательна для операций, меняющих баланс.

Нотация:
- Auth: USER / ADMIN.
- Idem: REQUIRED / OPTIONAL / FORBIDDEN.
- Headers: обязательные заголовки.

---

## 1) System

### GET /system/health
Auth: USER (безопасно и публично) | Idem: FORBIDDEN
Вход: нет
Выход: {"status": "ok"}
Ошибки: 500

---

## 2) Me / User

### GET /user/{tg_id}/me
Auth: USER | Idem: FORBIDDEN
Вход:
- Path: tg_id (int)
Выход (минимум):
- tg_id
- balances (EFHC)
- flags (vip/nft)
Ошибки:
- 404 USER_NOT_FOUND
- 401 UNAUTHORIZED

### POST /sync/user/{tg_id}
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key: <random-idempotency-key>
Вход:
- Path: tg_id (int)
- Body: профильные поля синхронизации (SSOT в schemas)
Выход:
- актуальное состояние пользователя
Ошибки:
- 409 IDEMPOTENCY_CONFLICT
- 422 VALIDATION_ERROR

---

## 3) Energy / Panels

### POST /panels/{tg_id}/buy
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: tg_id
- Body: {"panel_type": "...", "quantity": int}
Выход:
- purchase_id
- new_balance
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 409 IDEMPOTENCY_CONFLICT

### GET /energy/{tg_id}/state
Auth: USER | Idem: FORBIDDEN
Вход: Path tg_id
Выход:
- gen_per_sec
- total_generated
- updated_at
Ошибки:
- 404 USER_NOT_FOUND

---

## 4) Shop

### GET /shop/items
Auth: USER | Idem: FORBIDDEN
Вход: нет
Выход:
- items[]
  - item_id
  - title
  - price
  - availability
Ошибки: 500

### POST /shop/{tg_id}/purchase
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: tg_id
- Body: {"item_id": str, "quantity": int}
Выход:
- order_id
- status
- payment (если требуется)
Ошибки:
- 400 ITEM_NOT_AVAILABLE
- 409 IDEMPOTENCY_CONFLICT

---

## 5) Withdrawals

### POST /withdraw/{tg_id}/request
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: tg_id
- Body:
  - amount (Decimal)
  - payout_wallet (str)
Выход:
- withdraw_id
- status (PENDING)
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 422 VALIDATION_ERROR
- 409 IDEMPOTENCY_CONFLICT

### GET /withdraw/{tg_id}/history
Auth: USER | Idem: FORBIDDEN
Вход: Path tg_id
Выход:
- withdrawals[]
Ошибки: 404 USER_NOT_FOUND

---

## 6) Prizes / lotteries module

Терминология UI/Docs: использовать "prizes".
Кодовая подсистема: lotteries.

### GET /lotteries
Auth: USER | Idem: FORBIDDEN
Вход: нет
Выход:
- events[]
  - id
  - title
  - ticket_price
  - status
Ошибки: 500

### POST /lotteries/{event_id}/buy
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: event_id
- Body: {"tg_id": int, "tickets": int}
Выход:
- purchase_id
- new_balance
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 404 EVENT_NOT_FOUND
- 409 IDEMPOTENCY_CONFLICT

---

## 7) Admin

### GET /admin/stats
Auth: ADMIN | Idem: FORBIDDEN
Вход: нет
Выход:
- users_count
- bank_balance
- withdrawals_pending
- last_events[]
Ошибки:
- 403 FORBIDDEN

### POST /admin/withdrawals/{withdraw_id}/set_status
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: withdraw_id
- Body: {"status": "PAID|REJECTED|ERROR", "comment": str}
Выход:
- withdraw_id
- new_status
- audit_log_id
Ошибки:
- 404 WITHDRAW_NOT_FOUND
- 409 IDEMPOTENCY_CONFLICT

### POST /admin/bank/adjust
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Body:
  - amount (Decimal)
  - reason (enum)
  - details (object)
Выход:
- operation_id
- bank_balance
Ошибки:
- 422 VALIDATION_ERROR
- 409 IDEMPOTENCY_CONFLICT

---

## 8) Ошибки и идемпотентность

### Идемпотентность
- Любой endpoint с Idem: REQUIRED обязан:
  - принимать Idempotency-Key
  - возвращать тот же результат при повторе
  - возвращать 409 при конфликте разных тел под один ключ

### Ошибка
Единый формат ошибки определяется в docs/EFHC_CANON.md.
