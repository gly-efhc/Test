# CI test execution repair and browser build handoff — v169.66

Status: source/static repair source/static repair record.

## What changed

This pass fixed three log-driven blockers from `logs_72103768470.zip`:

1. pytest mass-skip root cause;
2. Alembic ORM metadata schema drift;
3. Next `/app` prerendering crash.

## Test execution rule

The `tests/frontend/e2e/conftest.py` hook may skip browser E2E tests when `EFHC_RUN_E2E` is not set, but it must never skip architecture, unit, backend, migration or i18n guards outside `tests/frontend/e2e/`.

A future CI log containing a summary like `1121 skipped` with `exit_pytest=0` is a blocker. It means tests were not executed meaningfully even if the pytest process returned zero.

## Browser/build handoff

The `/app` route is now a Telegram deep-link alias to the public Energy page. The global shell lives in `_app.tsx`. This keeps Next.js page semantics correct:

- `_app.tsx` receives `Component` and `pageProps`;
- `/app` route does not;
- therefore `/app` must not duplicate the custom app shell.

## Verification status

Checked locally: Python compileall, ruff full, mypy on backend/app, frontend typecheck, Alembic offline SQL generation, and targeted architecture tests.

Not claimed: not GitHub CI green, not release-ready, not screenshot proof, not full local `npm run build` success.
