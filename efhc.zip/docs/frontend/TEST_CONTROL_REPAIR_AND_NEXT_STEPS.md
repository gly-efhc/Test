# Test control repair and next steps

This document records the corrected process after the v169.67 incident.

## Correct process

1. Do not hide failing tests.
2. Fix source or update the guard when the architecture intentionally moved.
3. If tests are consolidated, keep one-to-one old-test to replacement-invariant
   mapping in `docs/testing/TEST_GUARD_MANIFEST.json`.
4. Do not put `test_*.py` files into archived folders excluded from pytest.
5. Use `scripts/ci/check_test_suite_integrity.py` as a hard CI guard.

## Mandatory iteration questions when tests fail

1. Is the test guarding a still-active canon or an intentionally superseded
   architecture?
2. If superseded, what active file or guard now protects the same invariant?
3. Is consolidation safe, and where is the replacement mapping recorded?

## Current required next work

The active test suite is restored. The next cycles must repair failures by
separate domains instead of reducing the test suite count.
