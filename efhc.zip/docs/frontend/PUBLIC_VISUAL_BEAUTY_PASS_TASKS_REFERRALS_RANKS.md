# PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS

Status: STATIC VISUAL POLISH APPLIED.
Scope: public Tasks, Referrals and Ranks surfaces.

## Boundary

NO SCREENSHOTS CLAIMED. This pass changes source-level visual hierarchy and
adds guards. It does not claim browser screenshot evidence, live Playwright
execution, GitHub CI green or final release readiness.

## Purpose

The public Tasks, Referrals and Ranks pages already had static public proof and
screenshot-harness preparation. This pass improves the human visual layer for
engagement-heavy surfaces before real screenshot capture:

- clearer earning-card hierarchy;
- visible status/reward/action rails on task cards;
- stronger invite/copy/share card structure;
- clearer ranking filters, podium and show-me cards;
- better focus-visible states for touch/keyboard navigation;
- mobile readability at 390px;
- reduced-motion safety for progress and card transitions.

## Sandbox intake

`docs/history/legacy_artifacts/map_element.md` and sandbox archives were used as reference navigation only.
Approved reference families:

- TelegramUI / Mark42: cells, badges, list sections, status chips and active
  interaction rhythm;
- Telebook: compact list hierarchy and mobile spacing;
- TypeScript / Vanilla TMA templates: viewport/safe-area assumptions;
- Nuxt Telegram Mini App: test-organization ideas only.

No Vue, Solid, Nuxt, Vanilla, foreign lock files, foreign CI files, bot runtime
or financial/TON transaction logic were imported into EFHC Bot.

## Code changes

| Surface | Files | Visual change | Boundary |
|---|---|---|---|
| Tasks | `frontend/src/pages/tasks.tsx`, `frontend/src/components/public/PublicEngagementPreview.tsx`, `frontend/src/styles/globals.css` | shell marker, visual engagement rail, ready/locked task-card classes, reward/status chips, focus polish | public-only; no task economics change |
| Referrals | `frontend/src/pages/referrals.tsx`, `frontend/src/components/public/PublicEngagementPreview.tsx`, `frontend/src/styles/globals.css` | shell marker, invite card polish, copy/share rail, share-grid touch targets | public-only; no admin identity or raw internals |
| Ranks | `frontend/src/pages/ranks.tsx`, `frontend/src/components/public/PublicEngagementPreview.tsx`, `frontend/src/styles/globals.css` | shell marker, filter/me card polish, podium rail marker, leader-card highlight | public-only; no rank formula change |

## Invariants preserved

- Task bonuses and claim logic are unchanged.
- Referral bonus semantics remain unchanged.
- Ranks keep the existing `kWh` / `Referrals` filters and show-me behavior.
- No backend route, service, model, migration or economic road was changed.
- No admin diagnostics, execution traces or raw operator internals were added to
  public UI.

## Acceptance criteria

- Tasks, Referrals and Ranks expose
  `data-public-visual-beauty="tasks-referrals-ranks"`.
- The shared `PublicEngagementPreview` exposes the same visual pass marker and
  has a compact visual rail.
- Tasks cards expose ready/locked/ad/claim classes and a status/reward/action
  visual rail.
- Referrals invite card exposes copy/share visual rail and share-grid polish.
- Ranks expose filter/me/podium visual markers and leader-card rows.
- `globals.css` contains shared chip, focus, mobile and reduced-motion rules.
- Generated manifest states `STATIC_VISUAL_POLISH_NO_SCREENSHOT_CLAIM`.

## Next step

Proceed to Profile / Wallet / History / FAQ visual trust pass. Real browser
screenshots remain a separate evidence action controlled by the screenshot
harness.
