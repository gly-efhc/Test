# PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS

Status: HARNESS READY — NO SCREENSHOTS CLAIMED
Version: v169_42
Date: 2026-06-01

## Purpose

This pass creates the browser screenshot evidence harness and capture manifest
for the public EFHC Bot UI. It converts the static proof from
`PUBLIC_UI_REGRESSION_PROOF_PASS.md` into a controlled browser-evidence plan.

This document does **not** claim that screenshots were captured, that Playwright
ran against live `localhost:3000`, or that GitHub CI is green. It only defines
what must be captured, where the evidence must be stored, and how later cycles
may use the evidence.

## Source documents read

1. `docs/AI/AI_DOCS_INDEX.md`
2. `docs/AI/TOPIC_READING_ROUTES.md`
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`
4. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md`
5. `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`
6. `docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md`
7. `docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md`
8. `docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md`
9. `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`
10. `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
11. `docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md`
12. `docs/history/legacy_artifacts/map_element.md`

## Evidence status

Current status: `HARNESS_READY_NO_SCREENSHOTS_CAPTURED`.

Allowed claim now:

- capture matrix exists;
- E2E capture script exists;
- output path convention exists;
- architecture guard prevents fake screenshot proof.

Forbidden claim now:

- screenshot proof complete;
- browser visual verdict complete;
- GitHub CI green;
- Playwright live run passed.

## Device / shell matrix

| Device id | Label | Viewport | Theme | Locale | Shell |
|---|---|---:|---|---|---|
| `mobile_tma_dark_ru` | Mobile TMA dark RU | 390x844 | dark | ru | telegram_webapp_mock |
| `mobile_tma_light_en` | Mobile TMA light EN | 390x844 | light | en | telegram_webapp_mock |
| `desktop_pwa_dark_en` | Desktop PWA dark EN | 1280x800 | dark | en | browser_pwa |

## Public screenshot capture manifest

Manifest file:

`docs/history/legacy_artifacts/reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`

Default evidence directory:

`docs/history/legacy_artifacts/reports/screenshots/public_ui/`

Environment controls:

- `EFHC_RUN_E2E=1` enables browser E2E collection;
- `EFHC_CAPTURE_SCREENSHOTS=1` allows screenshot file writes;
- `EFHC_E2E_BASE_URL` overrides `http://localhost:3000`;
- `EFHC_SCREENSHOT_OUTPUT_DIR` overrides `docs/history/legacy_artifacts/reports/screenshots/public_ui`.

## Route matrix

| Surface | Route | Frontend page | Slug | Priority | Expected evidence files |
|---|---|---|---|---|---|
| Energy | `/` | `frontend/src/pages/index.tsx` | `energy` | P0 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/energy/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/energy/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/energy/desktop_pwa_dark_en.png` |
| Panels | `/panels` | `frontend/src/pages/panels.tsx` | `panels` | P0 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/panels/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/panels/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/panels/desktop_pwa_dark_en.png` |
| Exchange | `/exchange` | `frontend/src/pages/exchange.tsx` | `exchange` | P0 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/exchange/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/exchange/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/exchange/desktop_pwa_dark_en.png` |
| Tasks | `/tasks` | `frontend/src/pages/tasks.tsx` | `tasks` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/tasks/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/tasks/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/tasks/desktop_pwa_dark_en.png` |
| Referrals | `/referrals` | `frontend/src/pages/referrals.tsx` | `referrals` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals/desktop_pwa_dark_en.png` |
| Active referrals | `/referrals/active` | `frontend/src/pages/referrals/active.tsx` | `referrals-active` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals-active/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals-active/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals-active/desktop_pwa_dark_en.png` |
| Inactive referrals | `/referrals/inactive` | `frontend/src/pages/referrals/inactive.tsx` | `referrals-inactive` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals-inactive/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals-inactive/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/referrals-inactive/desktop_pwa_dark_en.png` |
| Ranks | `/ranks` | `frontend/src/pages/ranks.tsx` | `ranks` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/ranks/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/ranks/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/ranks/desktop_pwa_dark_en.png` |
| Profile | `/web-profile` | `frontend/src/pages/web-profile.tsx` | `web-profile` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/web-profile/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/web-profile/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/web-profile/desktop_pwa_dark_en.png` |
| FAQ | `/faq` | `frontend/src/pages/faq.tsx` | `faq` | P1 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/faq/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/faq/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/faq/desktop_pwa_dark_en.png` |
| HUB | `/hub` | `frontend/src/pages/hub.tsx` | `hub` | P0 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/hub/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/hub/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/hub/desktop_pwa_dark_en.png` |
| Browser Shop | `/browser-shop` | `frontend/src/pages/browser-shop.tsx` | `browser-shop` | P0 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/browser-shop/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/browser-shop/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/browser-shop/desktop_pwa_dark_en.png` |
| Withdraw | `/withdraw` | `frontend/src/pages/withdraw.tsx` | `withdraw` | P0 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/withdraw/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/withdraw/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/withdraw/desktop_pwa_dark_en.png` |
| Ads | `/ads` | `frontend/src/pages/ads.tsx` | `ads` | P2 | `docs/history/legacy_artifacts/reports/screenshots/public_ui/ads/mobile_tma_dark_ru.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/ads/mobile_tma_light_en.png`, `docs/history/legacy_artifacts/reports/screenshots/public_ui/ads/desktop_pwa_dark_en.png` |

## Capture procedure

1. Start frontend against the target backend or Docker stack.
2. Set `EFHC_RUN_E2E=1`.
3. Set `EFHC_CAPTURE_SCREENSHOTS=1` only when the operator intentionally wants
   screenshot files written.
4. Run the screenshot capture test:

```bash
pytest tests/frontend/e2e/test_public_screenshot_capture_manifest.py -q
```

5. Review generated PNG evidence under `docs/history/legacy_artifacts/reports/screenshots/public_ui/` or the
   custom `EFHC_SCREENSHOT_OUTPUT_DIR`.
6. Do not mark 1365+ visual passes as evidence-backed unless the screenshots or
   user-provided CI artifacts are available.

## Visual non-regression checks per screenshot

Each captured route must be checked for:

- non-empty body;
- no white blank screen;
- no raw JSON payload or debug dump;
- no public/admin UI mixing;
- no `.efhc-admin-shell` on public routes;
- no black text on dark background in primary content;
- bottom navigation present on public routes where expected;
- Telegram safe-area not cutting bottom CTAs;
- localized error strings where applicable.

## Sandbox usage

`docs/history/legacy_artifacts/map_element.md` remains the navigation layer for sandbox references.

Allowed use:

- TypeScript/Vanilla templates for TMA shell assumptions;
- Nuxt template for test organization ideas;
- TelegramUI/Telebook references for visual element naming;
- TonConnect demos as UX reference only.

Forbidden use:

- migrank EFHC Bot to Vue/Solid/Nuxt/Vanilla;
- importing sandbox runtime code directly;
- changing EFHC economics from screenshot work;
- changing `ci.yml` without explicit user approval.

## Handoff to next visual beauty pass

The next visual pass may begin beauty work on Energy, Panels and Exchange. It must
continue to distinguish between:

- source-level readiness;
- browser screenshot evidence;
- human visual verdict;
- GitHub CI result.
