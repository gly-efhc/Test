# FAQ semantic alignment repair

## Status

Work pass: `1371 — corrective FAQ semantic alignment repair`.
Archive target: `v169_50`.
Base archive: `v169_49`.

This pass corrects the limitation of the previous FAQ wave-3 repair: the
previous pass repaired identical-to-English FAQ tails, but some translations
were aligned to EN wording rather than to the approved RU/Q&A meaning.

## User rule applied

If RU FAQ and EN FAQ differ in meaning, do not automatically trust either layer.
First check `docs/GENERAL/CURRENT_DECISIONS.md` and FAQ approval
records. RU/FAQ-SSOT is the preferred semantic anchor only after the Q/A layer
does not show it as a regression.

## Documents read / anchors

- `docs/GENERAL/CURRENT_DECISIONS.md`;
- `docs/SSOT/FAQ_SSOT.md`;
- `docs/AI/FAQ_READING_POLICY.md`;
- `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`;
- `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md`;
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md`;
- `docs/frontend/FAQ_WAVE3_TRANSLATION_STATUS_REPAIR.md`;
- `docs/history/legacy_artifacts/reports/generated/faq_wave3_translation_repair_v169_49.json`;
- `docs/history/legacy_artifacts/map_element.md`.

## Semantic alignment scope

Reviewed changed FAQ items from the previous 1371 pass:

`42`, `45`, `54`, `156`, `159-172`, `232`, `233-238`, `239`, `246`.

Corrected semantic drift items:

`42`, `45`, `162-172`.

## Key correction examples

### Item 45 — Wallet/account linking

The previous wave-3 translation followed stale EN wording about what the wallet
is needed for besides withdrawals. Q/A and RU FAQ anchor the approved meaning:
the same wallet must not be linked to two accounts at the same time.

Corrective action:

- EN was brought to the RU/Q&A meaning.
- Wave-3 translations were brought to the same meaning.

### Items 162-172 — Navigation and rules

The previous wave-3 translations were too close to EN wording where EN was more
summary-like than RU. Q/A requires section 14 to remain useful, adult and
practical, not weak or watery. These items were re-aligned to the RU navigation
logic: Profile / Wallet / History split, top bar, correct section choice,
refresh/recheck flow and avoiding random interface actions.

### Item 42 — Wallet wording

The previous EN/wave translations used deposit-like wording. Q/A user-facing
wording forbids investment-toxic `deposit` semantics and prefers top-up /
replenishment wording. The item now uses top-up/replenishment equivalents.

## Files updated

- `docs/SSOT/faq_ssot/en/faq_en.json` and `.md`;
- `docs/SSOT/faq_ssot/uk/faq_uk.json` and `.md`;
- `docs/SSOT/faq_ssot/de/faq_de.json` and `.md`;
- `docs/SSOT/faq_ssot/fr/faq_fr.json` and `.md`;
- `docs/SSOT/faq_ssot/es/faq_es.json` and `.md`;
- `docs/SSOT/faq_ssot/it/faq_it.json` and `.md`;
- `docs/SSOT/faq_ssot/tr/faq_tr.json` and `.md`;
- `docs/SSOT/faq_ssot/pl/faq_pl.json` and `.md`;
- `docs/SSOT/faq_ssot/da/faq_da.json` and `.md`;
- `docs/SSOT/faq_ssot/hi/faq_hi.json` and `.md`;
- `docs/SSOT/faq_ssot/id/faq_id.json` and `.md`;
- `docs/SSOT/faq_ssot/sw/faq_sw.json` and `.md`;
- `frontend/src/data/faq/catalogs.ts` regenerated from SSOT.

RU FAQ was not rewritten in this pass.

## Boundary

This pass does not claim human linguistic certification. It claims only static
semantic alignment of the repaired FAQ wave against Q/A and RU/SSOT anchors.

Sandbox archives are not translation sources. `docs/history/legacy_artifacts/map_element.md` remains
navigation/context only.
