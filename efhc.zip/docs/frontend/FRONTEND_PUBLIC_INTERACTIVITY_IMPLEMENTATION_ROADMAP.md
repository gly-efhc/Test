# FRONTEND_PUBLIC_INTERACTIVITY_IMPLEMENTATION_ROADMAP

Дата: 2026-05-31
Статус: implementation roadmap
Связано с: work pass

## 1. Решение

Пользовательскую интерактивность внедрять отдельной public-wave, не смешивая
её с Admin UI.

## 2. Волны внедрения

### Wave 1 — Energy / Panels / Exchange

Цель: максимальный UX-эффект при минимальном экономическом риске.

Порядок:

1. `Public Energy interactive overview` — DONE in work pass.
2. `Public Panels activation preview` — DONE in work pass.
3. `Public Exchange interactive preview` — DONE in work pass.

Паттерны:

- mobile section cards;
- progress ring / progress bar;
- compact fact rows;
- MainButton intent только для подтверждаемых safe actions;
- haptic feedback only on safe tap / success / warning;
- no raw payload.

### Wave 2 — Tasks / Referrals / Ranks

Цель: игровая вовлечённость.

Паттерны:

- task progress cards;
- reward preview;
- referral progress to next milestone;
- focused self-card in Ranks;
- filter chips.

Запрет:

- не показывать hidden execution log;
- не показывать admin moderation trace.

### Wave 3 — Profile / Wallet / History

Цель: доверие и понятность.

Паттерны:

- timeline cards;
- wallet status cards;
- DisplayData facts;
- FAQ handoff;
- empty/error/retry states.

## 3. Что брать из новых песочниц

Брать:

- Telegram theme/viewport/safe-area integration ideas;
- BackButton route watcher concept;
- MainButton state pattern;
- haptic wrappers;
- compact cells and display-data rows;
- ErrorBoundary retry pattern.

Не брать:

- Nuxt/Vue/Solid runtimes;
- jQuery renderer;
- Vite routing model;
- старые Tailwind config patterns;
- external chart/table dependency.

## 4. Public UI hard boundary

Public UI может быть интерактивным, но не должен показывать:

- admin route labels;
- diagnostics strips;
- endpoint names;
- raw API payloads;
- cursor payloads;
- operator internals;
- hidden task execution logs.

## 5. Следующий шаг

После work pass безопасный следующий шаг:

`1347 — Public Energy interactive overview`

Он должен начать implementation, а не только документацию.

## 6. work pass update

Wave 2 started in work pass.

Done:

- `/tasks` received public engagement preview;
- `/referrals` received active/total/progress engagement preview;
- `/ranks` received position/score/focus engagement preview;
- hidden execution log remains forbidden in public UI;
- admin moderation trace remains admin-only.

Next implementation step:

`1351 — Public Profile / Wallet / History trust layer`

### Wave 3 completion — Profile / Wallet / History

`Public Profile / Wallet / History trust layer` — DONE in work pass.

Added component:

`frontend/src/components/public/PublicProfileTrustLayer.tsx`

Purpose: mobile-first Web-Profile trust summary with safe tabs for profile,
wallet and history. It respects `hide_balances` and hands off to existing
Wallet / History / FAQ tabs without exposing admin diagnostics or raw payloads.
