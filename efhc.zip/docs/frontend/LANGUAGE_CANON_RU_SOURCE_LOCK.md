# Language canon RU source lock

Status: ACTIVE.

This document records the v169_52 language-canon correction pass.

## Decision

Russian is the semantic source language for EFHC Bot translations.

All non-Russian locale files, FAQ translations, bot text translations and
player-facing wording translations must follow verified Russian meaning.
English is not a semantic source when Russian Q/A / FAQ / SSOT canon exists.

## Source order

1. Direct user decisions and `docs/GENERAL/CURRENT_DECISIONS.md`.
2. FAQ approval layer and approval records.
3. Russian FAQ / Russian SSOT when aligned with Q/A.
4. English as translation and technical fallback layer.
5. Other languages as translation QA layers.

## Forbidden regression

Forbidden:

- translating Russian text from English;
- letting stale English FAQ override Russian Q/A meaning;
- treating English-identical RU locale values as completed Russian translation;
- using sandbox English UI labels as source text for EFHC Russian UI/FAQ;
- continuing release readiness while Russian source-canon drift is unreviewed.

## Runtime fallback distinction

The runtime player-facing fallback may use English for missing or failed locale
loading. This prevents users of DE/FR/HI/etc. from seeing unexpected Russian.
That fallback is a technical safety behavior only. It does not make English the
source of truth and does not count as completed translation.

## Current repair

The pass repaired current RU public-locale English-source drift in the
`portal.browser_shop`, `portal.shop_entry` and `public_engagement` domains.
Protected tokens such as `TON`, `FAQ`, `Hub`, `VIP`, `Telegram ID`, language
names and units may remain identical by design.
