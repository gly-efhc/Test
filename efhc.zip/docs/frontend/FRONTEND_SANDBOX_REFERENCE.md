# FRONTEND_SANDBOX_REFERENCE

Version: v168_87 / work pass  
Date: 2026-05-22  
Source file: `Песочница.xz`

## Status

`Песочница.xz` is a visual and technical donor for EFHC Bot frontend
work. It is not HEAD, not a release source, and not a functional canon.
Russian note: это визуальный донор, не HEAD.

Current HEAD remains the latest EFHC release ZIP accepted in chat.
Current accepted HEAD is tracked through `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`. The active sandbox navigation document is `docs/history/legacy_artifacts/map_element.md`.

## Sandbox verification

The uploaded sandbox is an xz-compressed tar archive.
It was unpacked separately outside the release tree.

Verified manifest facts from `00_INDEX/BUILD_MANIFEST.json`:

- build name: `EFHC_SANDBOX_COMPACT_v002_FINAL`;
- files: `29407`;
- directories: `8118`;
- logical bytes: `274249952`;
- nested archive files remaining: `0`;
- full index: `00_INDEX/ARCHIVE_FULL_INDEX.csv`.

The sandbox is intentionally not copied into the EFHC release archive.
Reason: it is heavy visual/reference material, not runtime code.

## How to use it

Use the sandbox for inspiration and comparison only:

1. button proportions;
2. card spacing;
3. shop/product image layout;
4. Telegram Mini App shell details;
5. PWA/browser layout ideas;
6. dashboard/admin information density;
7. empty/loading/payment illustration patterns;
8. TON/Web3 integration examples;
9. mobile-first component behavior;
10. visual rhythm and hierarchy.

## Priority areas to inspect

The most useful roots for future frontend cycles are:

- `Mark42-master` — Telegram-style primitives, cells, avatars, sections;
- `TelegramUI-main` — Telegram UI component patterns;
- `tma.js-master` — Telegram Mini App SDK patterns;
- `telegram-web-app-shop-main` — shop/WebApp buying pattern;
- `crypto-clicker-miniapp-main` — game/clicker WebApp pattern;
- `idle-game-master` — game loop and earning UI inspiration;
- `MaterialM-Tailwind-Nextjs-Free-main` — cards, product images,
  dashboards, empty states;
- `horizon-ui-chakra-nextjs-main` — admin dashboard composition;
- `refine-main` — admin/data UI architecture examples;
- `ui-main` — general component and design system references.

## Hard boundary

Do not blindly copy sandbox code into EFHC Bot.
Before any adoption:

1. compare with EFHC canon;
2. adapt to EFHC visual tokens;
3. keep the six bottom navigation items unchanged;
4. keep user-facing pages free of debug/proof text;
5. keep Exchange as only `kWh -> EFHC`;
6. keep Wallet, History, Shop, Admin and Diagnostics separated;
7. add a guard for every adopted visual/function pattern.

## Current operational effect

Sandbox intake is now routed through `docs/history/legacy_artifacts/map_element.md` and
`docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md`. The sandbox still
does not redesign a surface by itself; every adopted pattern must be rewritten
as EFHC-native React/Tailwind code and guarded against public/admin/economic
boundary drift.

Future visual work should use this file together with the root map before
changing buttons, cards, images, wallet handoff, Admin or Shop surfaces.

## v169_01 admin visual correction

The user explicitly instructed that the sandbox must be used for Admin cabinet
inspiration, including interactive charts, interactive schemes, dashboard
cards and richer operator layouts.

work pass inspected admin/dashboard donor files from:

- `MaterialM-Tailwind-Nextjs-Free-main/package/src/app/components/dashboard/`
- `ui-main/apps/v4/app/(app)/examples/dashboard/components/`

Adopted pattern for EFHC:

- visual KPI cards;
- interactive chart toggle;
- CSS chart bars without new dependencies;
- bank flow scheme;
- ledger table;
- safe operator actions separated from statistics.

The dedicated reference is:

`docs/admin/ADMIN_SANDBOX_VISUAL_REFERENCE.md`


## Additional uploaded template sandboxes

The following extra Telegram Mini App templates are available as reference-only
donors and are mapped in `docs/history/legacy_artifacts/map_element.md`:

- `vuejs-template-master.zip`;
- `solidjs-template-master.zip`;
- `nuxt-telegram-mini-app-main.zip`;
- `typescript-template-master.zip`;
- `vanillajs-template-master.zip`.

They may inform shell, launch params, theme params, BackButton, TonConnect
manifest and navigation behavior. They must not cause framework migration.
