# Frontend source canon freeze 1268

Статус: completed control freeze.
Дата: 2026-05-20.
Версия архива: v168_68.
Цикл: 1268.

## Что зафиксировано

Главный источник правды для восстановления frontend теперь не старый PDF
и не текущий случайный кодовый снимок, а ответы пользователя в чате и
living frontend canon.

## Обязательные источники

- `docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md`
- `docs/frontend/FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md`
- `docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md`
- `docs/GENERAL/CURRENT_DECISIONS.md`
- `docs/history/legacy_artifacts/docs/NORM/CHAT_TRANSCRIPT.md`

## Исторический слой

Старые первоисточники сохранены только как MD-слой первоначального
замысла. PDF-файлы не должны храниться в рабочем архиве и не являются
постоянным каноном.

## Правило спора

Если старый источник, текущий код и ответ пользователя спорят между
собой, действует ответ пользователя. Если спор всё ещё неясен,
ассистент обязан спросить пользователя в чате простым русским языком.
