<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# FRONTEND DO NOT TOUCH

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## 1. Core rule

Visual cleanup must not remove functions, hide business data or
change backend meaning. Frontend shell work is not permission to
rewrite the product.

## 2. Protected public routes

Do not delete, rename or move without direct chat approval:

- `/`;
- `/panels`;
- `/exchange`;
- `/tasks`;
- `/referrals`;
- `/referrals/active`;
- `/referrals/inactive`;
- `/ranks`;
- `/faq`;
- `/web-profile`;
- `/hub`;
- `/browser-shop`;
- `/withdraw`;
- `/ads`.

## 3. Protected bottom navigation

Bottom navigation is exactly: Energy, Panels, Exchange, Tasks,
Referrals and Ranks. Do not add FAQ, Admin, HUB, Shop or Profile. Do
not rename or reorder.

## 4. Protected admin routes

- `/admin`;
- `/admin/users`;
- `/admin/bank`;
- `/admin/withdrawals`;
- `/admin/shop`;
- `/admin/tasks`;
- `/admin/reports`;
- `/admin/referrals`;
- `/admin/panels`;
- `/admin/diagnostics`;
- `/admin/logs`;
- `/admin/hub`;
- `/admin/templates`;
- `/admin/efhc-deposits`;
- `/admin/ads`;
- `/admin/sale-packages`;

If a route looks unclear, audit its purpose. Move its visual entry
into Diagnostics or secondary admin structure only after proof and
chat approval.

## 5. Protected data

- generated kWh;
- available kWh;
- EFHC main balance;
- EFHC bonus balance;
- EFHC total balance;
- active panels;
- base generation rate;
- effective generation rate;
- panel activation value 100 EFHC;
- exchange rule 1 kWh = 1 EFHC inside the game;
- withdraw only from main balance;
- task rewards;
- referral state;
- rank state;
- wallet connection state;
- payment status;
- language selection state.

## 6. Protected product decisions

- EFHC is a full WebApp/PWA, not Telegram-only UI.
- Missing Telegram `tg_id` must not create blank UI.
- Profile is `/web-profile`, not overlay.
- FAQ is compact vertical tree, not category pills.
- Admin is Russian operator console, not debug dump.
- Browser-Shop is a separate shop shell without bottom nav.
- HUB is minimal: Пополнить EFHC and EFHC VIP NFT.
- All questions and approvals happen in chat, not hidden archive.

## 7. Forbidden public UI

- proof/debug/status technical text;
- raw API paths;
- raw payloads;
- route diagnostics;
- intent ids;
- wallet memo internals;
- raw JSON;
- internal state codes;
- `EFHC Player` as final user identity;
- browser/PWA proof wording;
- `своя оболочка` or developer wording;
- raw i18n keys.

## 8. Forbidden visual moves

- black text on dark background;
- horizontal scroll at smartphone width;
- hiding balances under compact UI;
- hiding base rate or available kWh;
- random new buttons on Energy;
- heavy FAQ category grids;
- admin diagnostics before section launcher;
- moving admin into bottom nav;
- replacing user functions with proof cards.

## 9. Protected engineering boundaries

- Do not change backend for visual-only task unless required and
  explained.
- Do not change migrations for UI polish.
- Do not change tests to fake green.
- Do not remove files while optimizing reading or packaging.
- Do not use `docker compose down -v` as normal advice.

## 10. Regression triggers

Any of these must stop the visual pass and create a blocker report:
white screen, missing bottom nav, missing Energy hero, raw i18n key,
public debug text, hidden balance, broken route click or unreadable
contrast.

## v168_61 no-repeat-question rule

Do not ask the user about a frontend element before checking the page
source documents.  The page description files are present.  Asking a
question that is already answered there is a process failure.

Protected decisions:

- no new Energy large logo without chat approval;
- FAQ full section list first, vertical expansion on action;
- Profile FAQ is a button to full FAQ;
- Wallet list and common financial history are separate functions;
- Admin home is section buttons/cards;
- Admin functional pages contain their own stats/graphs and actions;
- Browser-Shop uses large Web3 product/NFT cards;
- Ranks uses vertical player cards;
- HUB has two equal aligned buttons unless chat approves a third.


## v168_64 recovered function canon

Read before changing frontend functions:
`docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md`.

Original PDF files are not retained and are not permanent canon. The MD
historical intent layer is only a comparison source. User Q/A answers are
canonical. Restore lost functions only after explicit Q/A confirmation.
