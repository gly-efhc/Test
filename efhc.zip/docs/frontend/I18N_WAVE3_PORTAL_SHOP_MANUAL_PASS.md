# I18N wave-3 portal/shop manual pass

Status: COMPLETE for the current narrow domain pass.
Date: 2026-06-03.
Archive target: v169.59.
Cycle: manual portal/shop pass.

## Scope

This pass covers the public Browser Shop / Shop Entry translation tail for the
wave-3 languages:

- `de`
- `fr`
- `hi`
- `sw`
- `tr`
- `pl`
- `da`
- `it`
- `es`
- `id`

The pass focuses on:

- `portal.browser_shop.*` user-visible payment, catalog, storefront and wallet
  handoff wording;
- `portal.shop_entry.*` external shop entry flow wording.

This pass does not claim full locale completion. The remaining wave-3 public UI
translation backlog continues in later cycles by domain.

## Source rule

Translations were produced from verified Russian meaning and checked against the
current English runtime layer only for UI fit and placeholder consistency.
English strings and sandbox labels were not used as semantic sources.

## Sandbox/map usage

`docs/history/legacy_artifacts/map_element.md` and the sandbox archives were used only as UI stress/navigation
references for long shop cards, payment state badges, storefront labels and
mobile wrapping. No donor runtime code, framework code, wallet/payment logic,
CI/lock files or template labels were imported.

## Controlled exact-value exceptions

`TON` remains intentionally identical where it is the protocol/token label. The
new guard reads `ops/i18n/identical_to_english_allowlist.json` and permits only
explicit exact-value exceptions.

## Guard

- `ops/i18n/audit_wave3_portal_shop_locale_quality.py`
- `tests/architecture/test_wave3_portal_shop_manual_translation.py`

Expected guard result:

```text
OK: wave-3 portal/shop locale quality checked.
Languages: 10
Domain keys: 123
Unexpected English-identical values: 0
Cyrillic tails: 0
```

## Non-claims

This pass does not claim:

- human linguistic certification;
- full locale completion;
- browser screenshot proof;
- GitHub CI green;
- release readiness.
