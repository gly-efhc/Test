# TonConnect / Wallet UX proof and range closure

Status: DONE as static/source proof and range-closure checkpoint.
Date: 2026-06-02
Archive target: `v169_54`
Base archive: `v169_53_telegram_mini_app_shell_polish`

## Purpose

This document closes the active `1351-1375` Admin/Public extension range. The
last pass does not introduce new wallet runtime behavior. It verifies and
indexes the current TonConnect / Wallet UX path, then freezes cycles `1376+`
until the user supplies a new audit in chat.

## Range closure decision

- `1375` is the last cycle of the current range.
- `1376+` must not be invented or continued from internal momentum.
- The next range starts only after a new audit/task is supplied by the user in chat.
- No release-ready, GitHub CI green, real Telegram client pass, real browser
  screenshot pass, or live wallet transaction verdict is claimed by this local cycle.

## Wallet UX static proof matrix

| Area | Source path | Evidence | Verdict |
|---|---|---|---|
| TonConnect provider | `frontend/src/pages/app.tsx` | Uses `/api/tonconnect-manifest`, TMA return URL, theme and language sync. | PASS_STATIC |
| TonConnect helper | `frontend/src/lib/tonconnect.ts` | Language/theme mapping, proof-payload preparation, proof envelope submit, bind wallet, wallet list, restore and disconnect helpers. | PASS_STATIC |
| Wallet profile UI | `frontend/src/components/profile/ProfileWalletSection.tsx` and wallet subcomponents | Connect state, proof state, linked-wallet count, primary wallet, empty/error states and disconnect action are surfaced through i18n. | PASS_STATIC |
| Deposit wallet handoff | `frontend/src/components/DepositModal.tsx` | Uses Telegram `openLink` or `window.open(..., _blank, noopener,noreferrer)`; no `window.location.assign`. | PASS_STATIC |
| Browser Shop TonConnect tx | `frontend/src/features/browser-shop/BrowserShopPage.tsx` and `browserShopTonTx.ts` | Creates server intent, normalizes `tonconnect_tx`, calls `tonConnectUI.sendTransaction`, then enters checking state. | PASS_STATIC |
| Wallet / payment SSOT | `docs/SSOT/WALLETS_TONCONNECT_SSOT.md`, `docs/SSOT/TON_MEMO_SPEC.md`, `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md` | WalletGate, TonConnect manifest, payment intents, canonical payload and no auto-credit unmatched incoming remain documented. | PASS_STATIC |
| Telegram shell interaction | `docs/frontend/TELEGRAM_MINI_APP_SHELL_POLISH.md` | BackButton and modal ownership rules are documented; TonConnect modal keeps MainButton ownership separate. | PASS_STATIC |

## Boundaries

This pass intentionally does not modify:

- backend routes or services;
- database models or migrations;
- EFHC economics;
- wallet/ledger/withdraw semantics;
- TonConnect transaction payload semantics;
- CI/workflow files;
- sandbox runtime frameworks.

## Sandbox usage

`docs/history/legacy_artifacts/map_element.md` and sandbox archives are used only as reference/navigation
layers. Allowed reference patterns: Telegram viewport, BackButton, shell spacing,
TonConnect UX structure, list/card hierarchy and E2E organization ideas.

Forbidden transfer: Vue/Solid/Nuxt/Vanilla runtime, donor wallet/payment logic,
foreign lock files, CI files, environment assumptions, unapproved TON/Jetton
transaction logic.

## Post-range gate for 1376+

Before any `1376+` cycle starts, the new chat/audit must state the next target.
The first task of the next range must read:

1. this document;
2. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES.md`;
3. `docs/AI/AI_DOCS_INDEX.md`;
4. `docs/AI/TOPIC_READING_ROUTES.md`;
5. `docs/history/legacy_artifacts/map_element.md`;
6. the new audit supplied by the user.

## Non-claims

- No real TonConnect wallet connection was executed here.
- No real TON/USDT/EFHC transaction was executed here.
- No real Telegram client was used here.
- No browser screenshots were captured here.
- No GitHub CI green status is claimed here.
- No release-ready verdict is claimed here.
