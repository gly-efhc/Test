# PUBLIC_VISUAL_TRUST_PASS_PROFILE_WALLET_HISTORY_FAQ

Status: STATIC VISUAL TRUST POLISH APPLIED.
Scope: public Profile, Wallet, History and FAQ surfaces.

## Boundary

NO SCREENSHOTS CLAIMED. This pass changes source-level visual hierarchy and
adds guards. It does not claim browser screenshot evidence, live Playwright
execution, GitHub CI green or final release readiness.

## Purpose

The Profile / Wallet / History / FAQ lane is the account-trust part of the
public EFHC Bot UI. This pass improves the human visual layer for trust-heavy
surfaces before real screenshot capture:

- clearer profile trust rail across Profile, Wallet, History and FAQ;
- stronger wallet connection / primary wallet / Ton Proof status chips;
- clearer history balance/filter/withdraw timeline rails;
- FAQ search/tree trust rail with vertical tree preserved;
- focus-visible support for keyboard/touch accessibility;
- mobile readability at 390px;
- reduced-motion safety.

## Sandbox intake

`docs/history/legacy_artifacts/map_element.md` and sandbox archives were used as reference sources only.
Useful reference patterns:

- TelegramUI / Mark42: cells, chips, status badges, focus states;
- Telebook: compact list hierarchy and trust-oriented page sections;
- TypeScript / Vanilla TMA templates: safe-area and viewport assumptions;
- Nuxt Telegram Mini App: test organization ideas.

No Vue, Solid, Nuxt, Vanilla runtime, lock file, CI file, wallet/payment logic
or foreign business logic was imported.

## Surfaces

| Surface | Route / component | Visual trust changes | Boundary |
|---|---|---|---|
| Profile | `/web-profile`, `WebProfilePage.tsx`, `PublicProfileTrustLayer.tsx` | Trust rail, visual chips, profile/wallet/history flow, public-only markers | Public-only, no admin diagnostics |
| Wallet | `ProfileWalletSection.tsx` | Connect/primary/Ton Proof rail, trust section marker | Wallet UI only, no transaction logic change |
| History | `ProfileHistorySection.tsx` | Balance/filter/withdraw rail, timeline trust marker | Read-only history UX, no ledger logic change |
| FAQ | `/faq`, `FaqVerticalTree.tsx` | Search/tree trust rail, vertical tree marker | FAQ content/navigation only |

## Explicit non-changes

- No backend routes changed.
- No backend services changed.
- No balances, ledger, exchange, withdraw, wallet or TonConnect transaction logic changed.
- No admin page changed.
- No `ci.yml` change.
- No screenshot/browser verdict claimed.

## Acceptance checklist for future browser capture

When browser screenshots are actually captured, verify:

1. `/web-profile` shows trust rail without raw payload/debug blocks.
2. Wallet tab clearly shows connection/primary/Ton Proof state.
3. History tab clearly separates balances, filters and withdraw requests.
4. FAQ route remains a vertical tree, not horizontal pill chaos.
5. 390px viewport does not clip chips or key CTA buttons.
6. Focus-visible outline is present for tab/tree controls.
7. Public UI does not import or render admin diagnostics.
