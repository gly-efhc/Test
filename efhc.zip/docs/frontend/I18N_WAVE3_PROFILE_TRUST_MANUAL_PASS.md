# I18N wave-3 profile/public-profile-trust manual pass

Status: COMPLETE for the current narrow domain pass.
Date: 2026-06-03.
Archive target: v169.60.
Cycle: manual profile/trust pass.

## Scope

This pass covers the public account/profile translation tail for the wave-3
languages:

- `de`
- `fr`
- `hi`
- `sw`
- `tr`
- `pl`
- `da`
- `it`
- `es`
- `id`

The pass focuses on:

- `profile.*` user-visible account, wallet, history and state wording;
- `public_profile_trust.*` account trust rail, wallet/history summary and
  clean-public-surface wording.

This pass does not claim full locale completion. The remaining wave-3 public UI
translation backlog continues in later cycles by domain.

## Source rule

Translations were produced manually from verified Russian meaning and checked
against the current English runtime layer only for UI fit and placeholder/key
consistency. English strings and sandbox labels were not used as semantic
sources.

## Sandbox/map usage

`docs/history/legacy_artifacts/map_element.md` and the sandbox archives were used only as UI stress/navigation
references for account cards, wallet rows, trust rails, long labels and mobile
wrapping. No donor runtime code, framework code, wallet/payment logic, CI/lock
files or template labels were imported.

## Controlled exact-value exceptions

The guard intentionally excludes explicit exact values and approved key prefixes
from `ops/i18n/identical_to_english_allowlist.json`, including protocol tokens,
`profile.lang.*` native language names and `profile.reason.*` reason labels.
These are not part of the current profile/trust translation debt.

## Guard

- `ops/i18n/audit_wave3_profile_trust_locale_quality.py`
- `tests/architecture/test_wave3_profile_trust_manual_translation.py`

Expected guard result:

```text
OK: wave-3 profile/trust locale quality checked.
Languages: 10
Domain keys: 152
Unexpected English-identical values: 0
Cyrillic tails: 0
```

## Non-claims

This pass does not claim:

- human linguistic certification;
- full locale completion;
- browser screenshot proof;
- GitHub CI green;
- release readiness.
