<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# DASHBOARD SCREENSHOT PROOF PREPARATION

Status: `SCREENSHOT_PREPARATION_READY_NO_CAPTURE`

Archive target: `v170.30`

## Purpose

This document prepares screenshot proof for the Dashboard Visual
Direction Plan before the dashboard visual work range begins.

It does not claim that browser screenshots were captured. It defines the
route matrix, viewport matrix, locale matrix, evidence directories and
acceptance gates that later dashboard work must use.

## Source documents

- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`;
- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md`;
- `docs/admin/ADMIN_SCREENSHOT_QA_PREPARATION.md`;
- `docs/history/legacy_artifacts/map_element.md`.

## Evidence status

Allowed claim now:

- screenshot proof preparation exists;
- public and admin route matrix exists;
- viewport and locale matrix exists;
- evidence directory convention exists;
- green CI logs were recorded for the supplied input log run.

Forbidden claim now:

- browser screenshot proof complete;
- visual release-ready;
- live Telegram client proof;
- real TonConnect proof;
- GitHub CI proof for newly created local archive `v170.30`.

## Evidence directories

Default public output:

`docs/history/legacy_artifacts/reports/screenshots/public_ui/`

Default admin output:

`docs/history/legacy_artifacts/reports/screenshots/admin_ui/`

Default dashboard visual output:

`docs/history/legacy_artifacts/reports/screenshots/dashboard_visual/`

Only real browser captures may create `.png` evidence files. Placeholder
`.gitkeep` files do not count as screenshot proof.

## Required viewports

| ID | Size | Use |
|---|---:|---|
| `mobile_320` | 320x568 | narrow mobile overflow |
| `mobile_360` | 360x640 | small Android |
| `mobile_375` | 375x667 | compact mobile |
| `mobile_390` | 390x844 | Telegram-like mobile |
| `mobile_414` | 414x896 | large mobile |
| `mobile_430` | 430x932 | tall mobile |
| `tablet_768` | 768x1024 | tablet portrait |
| `tablet_1024` | 1024x768 | tablet landscape |
| `desktop_1366` | 1366x768 | operator desktop |
| `desktop_1920` | 1920x1080 | wide desktop |

## Required locales

`ru`, `en`, `uk`, `de`, `fr`, `es`, `it`, `tr`, `pl`, `da`, `hi`, `id`, `sw`.

## Public route matrix

| Surface | Route | Priority |
|---|---|---|
| Energy | `/` | P0 |
| Panels | `/panels` | P0 |
| Exchange | `/exchange` | P0 |
| Tasks | `/tasks` | P1 |
| Referrals | `/referrals` | P1 |
| Active referrals | `/referrals/active` | P1 |
| Inactive referrals | `/referrals/inactive` | P1 |
| Ranks | `/ranks` | P1 |
| Web Profile | `/web-profile` | P1 |
| FAQ | `/faq` | P1 |
| HUB | `/hub` | P0 |
| Browser Shop | `/browser-shop` | P0 |
| Withdraw | `/withdraw` | P0 |
| Ads | `/ads` | P2 |

## Admin route matrix

| Surface | Route | Priority |
|---|---|---|
| Admin overview | `/admin` | P0 |
| Admin bank | `/admin/bank` | P0 |
| Admin users | `/admin/users` | P1 |
| Admin withdrawals | `/admin/withdrawals` | P0 |
| Admin shop | `/admin/shop` | P0 |
| Admin tasks | `/admin/tasks` | P1 |
| Admin reports | `/admin/reports` | P0 |
| Admin diagnostics | `/admin/diagnostics` | P1 |
| Admin system | `/admin/system` | P1 |
| Admin logs | `/admin/logs` | P1 |
| Admin panels | `/admin/panels` | P1 |
| Admin sale packages | `/admin/sale-packages` | P1 |
| Admin deposits | `/admin/efhc-deposits` | P0 |
| Admin hub | `/admin/hub` | P0 |
| Admin referrals | `/admin/referrals` | P1 |
| Admin templates | `/admin/templates` | P2 |
| Admin ads | `/admin/ads` | P2 |

## Dashboard direction screenshots

The dashboard visual work range must use screenshot proof after
meaningful visual runtime changes.

Minimum dashboard surfaces:

- Energy dashboard;
- Panels portfolio dashboard;
- Ranks dashboard;
- Tasks dashboard;
- Referrals dashboard;
- Exchange support widgets;
- Web Profile account dashboard;
- Admin overview dashboard;
- Admin reports dashboard;
- Admin bank dashboard;
- Admin deposits dashboard;
- Admin withdrawals dashboard;
- Admin system dashboard;
- Admin logs/events dashboard.

## Acceptance checks per screenshot

Each real screenshot must be reviewed for:

- no blank white screen;
- no horizontal scroll at mobile widths;
- no raw JSON/debug payload;
- no public/admin UI mixing;
- no raw `global_id` on public surfaces;
- no hidden main CTA;
- no text overflow on long locales;
- bottom navigation does not cover content;
- status is understandable without color alone;
- loading, empty, error and stale states are readable.

## Capture command convention

Future runtime capture should use explicit environment gates:

```bash
EFHC_RUN_E2E=1 EFHC_CAPTURE_SCREENSHOTS=1 EFHC_E2E_BASE_URL=http://localhost:3000 pytest tests/frontend/e2e/test_public_screenshot_capture_manifest.py -q
```

Admin screenshot capture must use a separate authenticated/admin-safe
harness. Do not fake admin screenshots with public anonymous state.

## Grafana and Sandbox usage

Grafana gives visual discipline only: panel chrome, grid, toolbar,
time range, refresh, variables, status cards and inspector patterns.

Песочница gives prototype/navigation reference only.

Forbidden:

- copying Grafana runtime code;
- copying sandbox runtime code;
- copying lock files or CI files;
- adding heavy chart dependencies without a dedicated audit dedicated audit pass;
- showing synthetic dashboard data as real analytics.

## Handoff to dashboard visual kernel

The next Dashboard Visual Kernel pass can start after reading this
document, `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`, `docs/history/legacy_artifacts/map_element.md`,
Kernel and screenshot harness documents before runtime changes.
