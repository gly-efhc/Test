# FRONTEND_ADMIN_UI_KIT_FOUNDATION

Version: v169_05 / work pass
Date: 2026-05-27
Status: active frontend foundation document

## Purpose

This document fixes the Admin UI Kit foundation introduced in work pass.
The goal is to turn Admin into a reusable interactive dashboard system.

## Code entry

Foundation component file:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

Current first applied consumer:

`frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`

## Component set

- `AdminKpiCard` — compact KPI/stat card.
- `AdminChartCard` — chart shell for SVG/CSS dashboard graphs.
- `AdminFlowMapCard` — operator flow nodes and clickable flow map.
- `AdminFilterBar` — grouped filters for metric/window controls.
- `AdminActionTable` — compact rows for selected actions or details.
- `AdminStatusBadge` — short state badge.
- `AdminConfirmationBlock` — confirmation state for risky actions.
- `AdminEmptyState` — no-data state.
- `AdminErrorState` — error/unavailable state.
- `AdminSectionHeader` — dashboard section header.

## Styling entry

Shared styles are in:

`frontend/src/styles/globals.css`

Class namespace:

`efhc-admin-ui-*`

## Current application

work pass connects the UI Kit to the work pass dashboard. The result:

- work pass remains active;
- dashboard is still interactive;
- UI Kit primitives are real code, not only documentation;
- sandbox patterns are mapped before adoption;
- no new chart dependency is introduced.

## Next application targets

Recommended next Admin pages:

1. `/admin/bank`
2. `/admin/users`
3. `/admin/withdrawals`
4. `/admin/shop`
5. `/admin/tasks`
6. `/admin/reports`

## Acceptance rule

A future Admin UI Kit component is accepted only if:

- it is used by a real Admin page or dashboard component;
- it keeps Russian operator wording;
- it has an empty/error state when needed;
- it does not expose raw endpoint payloads;
- it does not change EFHC economic logic.

## work pass adoption

work pass adds the first deeper adoption layer:

`frontend/src/components/admin/AdminInteractiveOperatorPanel.tsx`

Applied consumers:

- `/admin/bank` via `frontend/src/pages/admin/bank.tsx`;
- `/admin/users` via `frontend/src/pages/admin/users.tsx`.

The section uses the work pass UI Kit and direct sandbox donor patterns:
interactive chart, section cards, dashboard data table, flow nodes and
mobile-safe admin grouping. This is still frontend/admin work only; it does
not migrate dependencies and does not change EFHC economics.

## work pass adoption: Withdrawals mobile decision panel

`AdminWithdrawalsMobileDecisionPanel` is the next Admin UI Kit adoption layer.
It applies UI Kit components to `/admin/withdrawals` with mobile-first priority:

- `AdminSectionHeader`;
- `AdminFilterBar`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminConfirmationBlock`;
- `AdminEmptyState`.

The page now treats withdrawals as an operator state-machine:

`PENDING → PAID / REJECTED / CANCELED`

`ERROR` remains the exceptional review lane.

Desktop is supported by responsive CSS, but mobile-admin readability is the
primary target.

## work pass adoption: Shop / Web3 separation panel

`AdminShopWeb3SeparationPanel` applies the Admin UI Kit to `/admin/shop`.

The panel separates:

- Admin catalog actions: edit, status, archive, delete, order review;
- Web3 user payment road: checkout, payment intent, memo, watcher match;
- TON-ready lane from USDT planned lane.

Mobile-admin readability remains primary. Desktop layout is responsive and
secondary.

## work pass — AdminTasksCatalogUxPanel

Component:

`frontend/src/components/admin/AdminTasksCatalogUxPanel.tsx`

Consumer:

- `/admin/tasks` via `frontend/src/pages/admin/tasks.tsx`.

Role:

Mobile-first operator catalog and moderation queue layer for Admin Tasks.

UI Kit primitives used:

- `AdminSectionHeader`;
- `AdminFilterBar`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminEmptyState`;
- `AdminErrorState`;
- `AdminStatusBadge`;
- `AdminConfirmationBlock`.

Boundary:

The component organizes task catalog and moderation visibility only. It must not
change rewards, backend moderation rules or CI/workflow files.

## work pass adoption: Tasks execution trace boundary

`AdminTasksExecutionTracePanel` applies the Admin UI Kit to the trace layer of
`/admin/tasks`.

The panel shows a sanitized admin-only `task_bonus` ledger slice through
`/admin/logs/transfers?reason=task_bonus`.

UI Kit primitives used:

- `AdminSectionHeader`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminEmptyState`;
- `AdminErrorState`;
- `AdminStatusBadge`;
- `AdminConfirmationBlock`.

Boundary:

The panel must not expose raw meta, raw cursor payloads or public task
execution history. It is Admin-only operator visibility.

## work pass adoption — Admin Reports

`AdminReportsVisualDashboardPanel` applies the shared Admin UI Kit to
`/admin/reports`.

It uses:

- `AdminSectionHeader`;
- `AdminFilterBar`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminEmptyState`;
- `AdminErrorState`;
- `AdminStatusBadge`.

The component adapts Sandbox dashboard/report patterns while keeping EFHC
reports read-only.

## work pass — Reports export/download usage

`AdminReportsExportDownloadPanel` applies the shared Admin UI Kit to a
read-only export boundary on `/admin/reports`:

- `AdminSectionHeader` for operator context;
- `AdminChartCard` for format/scope controls;
- `AdminFlowMapCard` for export flow;
- `AdminActionTable` for sanitized preview;
- `AdminStatusBadge` and `AdminEmptyState` for status boundaries.

The component keeps mobile-first touch controls and does not add backend
mutation routes or new dependencies.

## work pass — Diagnostics technical-only boundary

`AdminDiagnosticsTechnicalBoundaryPanel` applies the shared Admin UI Kit to
`/admin/diagnostics`.

The panel is intentionally technical-only: it can show route health, boundary
signals and public/admin separation, but it must not execute business actions.

## work pass adoption proof pass

work pass adds a visible proof-pass component:

`frontend/src/components/admin/AdminUiKitAdoptionProofPanel.tsx`

It is rendered on Admin home and documents the adoption chain across:

- Bank / Users;
- Withdrawals;
- Shop / Web3;
- Tasks;
- Reports;
- Diagnostics.

The proof panel uses the shared Admin Dashboard UI Kit primitives and records
sandbox donor-source patterns without copying foreign runtime stacks.

## work pass screenshot QA adoption

The Admin UI Kit is now used for screenshot QA preparation through
`AdminScreenshotQaPreparationPanel`. This extends the proof pass from
work pass into a manual visual QA route.

## work pass route-map proof

Admin UI Kit adoption is now mapped in
`docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`. The map links applied
Admin components to pages, backend roads and SSOT/NORM anchors.
