# FRONTEND CHANGE REPORT TEMPLATE

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## Cycle title

- Archive HEAD:
- New archive:
- Screen or visual layer:
- Date:

## 1. Control documents checked

- `FRONTEND_VISUAL_CONTRACT.md`;
- `FRONTEND_SHELL_ARCHITECTURE.md`;
- `FRONTEND_SCREEN_REGISTRY.md`;
- `FRONTEND_COMPONENT_REGISTRY.md`;
- `FRONTEND_VISUAL_ELEMENTS_REGISTRY.md`;
- `FRONTEND_DO_NOT_TOUCH.md`;
- `FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md`;
- `FRONTEND_SCREENSHOT_QA_PROTOCOL.md`;
- `FRONTEND_REFERENCE_INTERPRETATION.md`.

## 2. Screen or layer selected

Name one screen or one visual layer. Do not rewrite the whole
frontend unless the user explicitly approved a shell-wide pass.

## 3. What was broken

Record visible defects: hierarchy, density, contrast, lost data,
wrong buttons, technical garbage, route confusion, language drift
and mismatch with user approval.

## 4. Screen plan before code

- Screen purpose.
- Main visual block.
- Mandatory elements.
- Forbidden elements.
- Components touched.
- Data preserved.
- Acceptance criteria.
- What is not touched.

## 5. What changed

List user-visible changes and the reason for each change. Separate
code, styles, docs and tests.

## 6. Files changed

List all changed files. Include docs, reports and generated control
files.

## 7. Components touched

List shell, page, card, button, modal, chart, route and state
components.

## 8. What was not touched

Record protected routes, backend, migrations, tests, CI, economic
logic and business invariants.

## 9. Checks performed

List route checker, TypeScript, build, compileall, runtime smoke,
screenshot QA or archive proof. Do not call local checks GitHub CI.

## 10. Remaining defects

Record remaining defects honestly. Do not claim full readiness
without live proof.

## 11. User questions

If screen composition is unclear, ask human questions in chat. Do
not hide unresolved choices inside the archive.

## 12. Next recommended screen

Name the next screen or visual layer and explain why.

## 13. Release archive proof

State ZIP name, ZIP test result, FLAT status and excluded build
artifacts.

## v168_61 required source section

Every visual change report must include:

```text
Page-description sources read:
- ...

Existing user decisions applied:
- ...

No-repeat-question check:
- confirmed / failed
```

If the operator asked about an element that is already documented, the
report must record it as a process error and correct the frontend docs.
