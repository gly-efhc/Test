# FRONTEND_PUBLIC_EXCHANGE_INTERACTIVE_PREVIEW

Дата: 2026-05-31
Статус: active public UI canon
Цикл: 1349
Архив: EFHC Bot v169_28 release archive for public_exchange_interactive_preview

## 1. Решение

`/exchange` получил public-only interactive preview слой перед основной формой
обмена.

Новый компонент:

`frontend/src/components/public/PublicExchangeInteractivePreview.tsx`

Подключение:

`frontend/src/pages/exchange.tsx`

## 2. Что делает preview

Preview показывает:

- доступные kWh;
- максимальную сумму обмена;
- курс `1 kWh = 1 EFHC`;
- ожидаемое получение EFHC;
- текущий main balance как пользовательский факт;
- readiness state preview route;
- safe CTA, который фокусирует основную форму обмена.

## 3. Что запрещено

Preview не должен:

- добавлять обратный обмен;
- менять backend route;
- обходить confirmation;
- добавлять quick buttons 25/50/100;
- показывать admin diagnostics;
- показывать raw payload;
- показывать endpoint labels;
- менять экономику `kWh -> EFHC 1:1`.

## 4. Sandbox donor-source

Использованы только паттерны:

- DisplayData rows;
- Telegram Mini App section/cell surface;
- haptic safe tap;
- MainButton intent как UX-идея, без прямого TMA mutation;
- mobile-first facts deck.

Nuxt/Vue/Solid/Vanilla/jQuery runtimes не переносились.

## 5. Acceptance

- `PublicExchangeInteractivePreview` существует.
- `/exchange` использует компонент.
- Все 13 locale JSON содержат новые ключи `exchange.interactive_*`.
- Admin layer не импортируется в public component.
- `ci.yml` не изменяется.
