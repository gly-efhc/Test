# FRONTEND_PACKAGE_LOCK_REGISTRY_CANON

Version: v169_12
work pass
Date: 2026-05-27
Status: active guard rule

## Purpose

Frontend lockfiles must be portable outside the local assistant runtime
and must not contain internal package registry URLs.

## Active rule

`frontend/package-lock.json` must not contain any of these markers:

- `applied-caas-gateway`;
- `internal.api.openai`;
- `artifactory`.

The allowed canonical registry for generated `resolved` package URLs is:

```text
https://registry.npmjs.org/
```

## Why this matters

The CI workflow checks the frontend lockfile before `npm ci`. If internal
registry URLs are committed, CI fails before dependency installation and
before `npm run build` can run.

## Relation to frontend runtime standard

This policy does not change the implemented frontend standard:

- Next.js 16.2.6;
- React 19.2.6;
- React DOM 19.2.6;
- Tailwind CSS v4.3;
- Tailwind v4 CSS-first `@theme` in `globals.css`.

## Guard

`tests/architecture/test_ci_logs_71012972623_repair.py`
checks that the lockfile has no forbidden registry markers and that the
Tailwind v4 migration remains intact.
