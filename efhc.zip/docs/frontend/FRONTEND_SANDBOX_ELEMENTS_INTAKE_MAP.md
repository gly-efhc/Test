# FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP

Status: active reference map
Version: v169_37

## Purpose

This document converts `docs/history/legacy_artifacts/map_element.md` into an operational EFHC frontend intake
map. It defines which sandbox elements may inspire EFHC UI work and which parts
must remain outside the runtime.

## Hard rule

Sandbox archives are external donor references. EFHC Bot stays on the current
frontend canon:

- Next.js 16.2.6;
- React 19.2.6;
- React DOM 19.2.6;
- Tailwind CSS 4.3.0.

Do not migrate EFHC to Vue, Solid, Nuxt or Vanilla runtime stacks.
Only patterns are accepted. Framework migration is rejected.

## Source intake matrix

| Source | Useful elements | EFHC target | Forbidden transfer |
|---|---|---|---|
| `Песочница.xz` | TelegramUI, Mark42, MaterialM, Telebook, TonConnect, TON SDK, backend/bot references | Admin UI, public UI, wallet UX, test patterns | Direct vendor/runtime import |
| `vuejs-template-master.zip` | init, BackButton, theme params, launch params, TonConnect manifest | Telegram shell behavior in React equivalent | Vue runtime/composables |
| `solidjs-template-master.zip` | compact route map, init, mockEnv, TonConnect page structure | shell routing ideas | Solid runtime |
| `nuxt-telegram-mini-app-main.zip` | Button, Cell, Content, Hero, Nav, Section, Telegram composable ideas | public screen sections and utility concepts | Nuxt runtime |
| `typescript-template-master.zip` | initNavigator, initTonConnectUI, WalletProvider, TonConnectButton | framework-light shell/wallet flow ideas | jQuery/runtime copy |
| `vanillajs-template-master.zip` | minimal initTonConnect and plain JS navigation ideas | lowest-level behavior reference | dist copy into EFHC |

## Public UI adoption queue

| EFHC surface | Sandbox patterns to inspect | Guard required |
|---|---|---|
| Energy | TelegramUI Progress, Skeleton, Card; Telebook Amount/DataOverview | first screen and no-debug guard |
| Panels | TelegramUI TabsList/SegmentedControl, Card, Section | public/admin separation guard |
| Exchange | TonConnect neutral UI, Amount/Input, warning cards | kWh→EFHC-only economics guard |
| Tasks | Card/List/Badge/Skeleton | no raw execution trace in public UI |
| Referrals | AvatarStack, Badge, Share/Copy affordances | no admin identity leak |
| Ranks | List, Avatar, Progress, Placeholder | no internal level catalog |
| Profile / Wallet / History | TonConnect button, wallet card, activity list | no raw transaction payload dump |
| FAQ | Accordion, Section, Search, Placeholder | locale and tree-layout guard |
| HUB / Browser Shop | product card, order status, wallet handoff | no memo/payload public diagnostics |
| Withdraw | form cards, status cells, confirmation affordance | no double-submit or raw error guard |
| Ads | task/ad cards, reward modals, loading/empty states | no execution trace leak |

## Admin adoption queue

| Admin surface | Sandbox patterns to inspect | Guard required |
|---|---|---|
| `/admin` | MaterialM dashboard cards, TelegramUI sections, Telebook overview | no diagnostics dump on home |
| `/admin/bank` | KPI cards, flow maps, confirmation blocks | idempotency / confirmation guard |
| `/admin/users` | data table, filters, status badges | public identity boundary guard |
| `/admin/withdrawals` | decision cards, fixed footer, modal confirmation | final status and idempotency guard |
| `/admin/shop` | order cards, product lists, fulfillment panels | Web3 separation guard |
| `/admin/tasks` | catalog cards, moderation panels, trace boundary | execution trace admin-only guard |
| `/admin/reports` | charts, export panel, aggregate cards | read-only report guard |
| `/admin/diagnostics` | technical health strips and logs | diagnostics-only boundary guard |

## Acceptance procedure

1. Pick one EFHC surface.
2. Select a sandbox pattern from `docs/history/legacy_artifacts/map_element.md`.
3. Rewrite it as EFHC React/Tailwind code.
4. Connect it to an existing page/component/backend/SSOT chain.
5. Add or update a guard.
6. Do not claim proof until the actual EFHC files were checked.

## Rejection list

- framework migration;
- copying demo business logic;
- copying wallet transaction forms without EFHC security review;
- copying private-key, seed, mnemonic or secret-handling patterns;
- exposing raw Telegram init data, wallet payloads, endpoint dumps or operator
  internals in public UI;
- changing EFHC economics through a visual component.


## Audit fixes intake update

During v169_37, sandbox references were used as non-runtime guidance for:

- E2E smoke-test structure and Telegram Mini App fallback assumptions;
- admin action/modal ergonomics for Sale Packages create/edit/toggle;
- PWA/offline shell behaviour;
- wallet opening behaviour that preserves Telegram/back-button context.

No sandbox framework migration was performed.


## Public screenshot QA preparation intake

For the active public UI screenshot QA preparation line, use `docs/history/legacy_artifacts/map_element.md` as the root sandbox navigation document. The accepted intake pattern is:

1. select one public EFHC surface;
2. inspect the matching sandbox component class;
3. translate the pattern into existing EFHC React/Tailwind conventions;
4. keep public/admin boundaries intact;
5. add a guard before claiming proof.

Priority public surfaces for this intake are Energy, Panels, Exchange, Tasks, Referrals, Active Referrals, Inactive Referrals, Ranks, Profile/Wallet/History, FAQ, HUB, Browser Shop, Withdraw and Ads.

## v169_39 residual audit intake update

The residual audit pass expands the testing-oriented sandbox intake:

- use Telegram Mini App template tests as reference for interaction-level route mocks;
- use PWA shell examples only as conceptual guidance for offline fallback readability;
- keep all route smoke matrices explicit so public and admin surfaces cannot silently
  disappear from E2E coverage.

No sandbox runtime, framework code, lock files or CI files are imported.


## v169_40 public regression proof use

During the public regression proof pass, sandbox navigation was used only to classify visual and UX
pattern families for public surfaces: Telegram cards/sections/skeletons, shop
product cards, mobile shell controls, TonConnect handoff assumptions and
multilingual/offline fallback patterns. No sandbox runtime, framework migration,
foreign CI, lock file or wallet transaction logic was imported.


## v169_42 screenshot evidence harness intake

The screenshot evidence pass uses sandbox archives only as naming, viewport and shell-behavior
references for browser evidence:

- TypeScript and Vanilla TMA templates: launch/theme/viewport assumptions;
- Nuxt Telegram mini app: test organization ideas;
- TelegramUI / Telebook: visual primitive labels for screenshot review;
- TonConnect demos: wallet handoff UX references only.

No sandbox runtime is imported into EFHC Bot.


## v169_43 — Energy / Panels / Exchange visual polish

| EFHC surface | Sandbox reference family | Adopted pattern | Not adopted |
|---|---|---|---|
| Energy | TelegramUI / Mark42 cards and chips | visual rail, active chips, focus polish | foreign runtime code |
| Panels | Telebook sections and Telegram card hierarchy | ready/locked state classes, compact chips | economic changes |
| Exchange | TonConnect handoff UX references and Telegram cells | ready/loading state classes and CTA depth | wallet transaction logic |

This update remains reference-only. No Vue/Solid/Nuxt/Vanilla runtime, lock file,
CI file or payment logic was imported into EFHC Bot.


## Tasks / Referrals / Ranks visual pass reference use

For this visual pass the sandbox was used as a reference-only map:

| EFHC surface | Reference family | Adopted pattern | Rejected |
|---|---|---|---|
| Tasks | TelegramUI / Mark42 / idle-game visual references | status/reward chips, ready/locked classes, compact earning-card rail | task economy or external game runtime |
| Referrals | Telegram share/cell patterns and Telebook list rhythm | invite card, copy/share rail, larger touch targets | admin identity or raw referral internals |
| Ranks | TelegramUI list/badge patterns and Telebook rank layout | filter/me card polish, podium rail, leader-card highlight | static 12-level catalog or rank formula changes |

No runtime framework migration or direct donor-code import is authorized.

## HUB / Browser Shop / Withdraw / Ads visual trust reference use

For this visual trust pass the sandbox was used as a reference-only map:

| EFHC surface | Reference family | Adopted pattern | Rejected |
|---|---|---|---|
| HUB | TelegramUI / Mark42 action cards and chips | two-action trust rail, stronger focus states | new HUB actions or admin diagnostics |
| Browser Shop | telegram-web-app-shop, Telebook, TonConnect UX demos | product hierarchy, token/catalog/payment/receipt rail | foreign payment logic, raw payload UI |
| Withdraw | Telebook compact list rhythm and Telegram status chips | wallet/amount/request/outcome rail, request/history card polish | withdraw economics, ledger or idempotency changes |
| Ads | compatibility-route patterns | legacy-link explanation and safe Tasks redirect card | standalone Ads player or hidden debug surface |

No runtime framework migration, donor payment code, lock file, CI file or TON transaction logic is authorized.


## Range closure sandbox note

Sandbox archives remain reference-only after the closed Admin/Public range. For any future wallet/TonConnect task, first require a new user-provided audit in chat, then use `docs/history/legacy_artifacts/map_element.md` to pick specific reference patterns. Do not import sandbox runtime frameworks or donor transaction logic.
