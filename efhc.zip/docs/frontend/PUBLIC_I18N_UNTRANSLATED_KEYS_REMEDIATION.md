# Public i18n untranslated keys remediation

## Status

Work pass: `1370 — Public i18n untranslated keys remediation`.
Archive target: `v169_48`.
Source audit: `docs/history/legacy_artifacts/docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md` and `docs/history/legacy_artifacts/reports/generated/i18n_audit_summary_v169_45.json`.

## Scope

This pass follows the critical repair pass and targets the most visible public untranslated tail:

- user-facing error and confirmation messages;
- wallet state and wallet error messages;
- Browser Shop / portal payment warnings and wallet-open errors;
- Exchange validation and confirmation text;
- History filters and load errors;
- Energy action labels used on the public home surface;
- Panels interactive activation labels;
- Profile trust layer labels;
- Tasks / Referrals / Ranks public engagement labels;
- FAQ counts summary.

## Non-goals

- This pass does not claim full human translation completion for every remaining public key.
- This pass does not translate the long FAQ wave-3 identical-English answer set; that is reserved for the next FAQ-focused pass.
- This pass does not change admin Russian-first policy.
- This pass does not change EFHC economics, backend routes, wallet/TonConnect logic or CI workflow files.

## Remediated key set

Priority keys remediated in the 12 non-English locale bundles:

```text
browser.auth_needed
energy.activate_panel_action
energy.activate_panel_note
energy.available_kwh_chip
energy.balance_chip
energy.exchange_action
energy.exchangeable_chip
energy.interactive_overview
energy.interactive_panels
energy.interactive_exchange
energy.interactive_live
energy.interactive_title
energy.next_action
energy.open_action
energy.public_interactivity_safe_note
exchange.amount_hint
exchange.amount_invalid_detail
exchange.amount_over_available
exchange.confirm_exchange_title
exchange.confirm_exchange_detail
exchange.confirmation_ready_detail
exchange.open_wallet
exchange.preview_unavailable_detail
exchange.preview_unavailable_title
exchange.result_hint_title
exchange.result_hint_detail
exchange.interactive_available
exchange.interactive_available_hint
exchange.interactive_confirm
exchange.interactive_confirm_hint
exchange.interactive_form_cta
exchange.interactive_live
exchange.interactive_loading
exchange.interactive_max_amount
exchange.interactive_preview
exchange.interactive_preview_hint
exchange.interactive_ready
exchange.interactive_safe_note
exchange.interactive_title
exchange.full_withdraw_screen
history.load_error
history.filter_all
history.filter_bonuses
history.filter_exchange
history.filter_panels
history.filter_purchases
history.filter_withdraw
wallet.error_title
wallet.error_body
wallet.linked_wallets_count
wallet.state_backend_error
wallet.state_connected
wallet.state_not_connected
wallet.state_pending_proof
wallet.state_bound
portal.browser_shop.active_intent
portal.browser_shop.active_intent_error
portal.browser_shop.intent_create_failed
portal.browser_shop.intent_order_label
portal.browser_shop.memo_label
portal.browser_shop.payment_details_title
portal.browser_shop.payment_details_detail
portal.browser_shop.payment_method_detail
portal.browser_shop.payment_warning_title
portal.browser_shop.payment_warning_detail
portal.browser_shop.wallet_open_failed
portal.browser_shop.payment_done_title
portal.browser_shop.payment_error_title
portal.browser_shop.ton_contour_title
portal.browser_shop.ton_contour_detail
portal.browser_shop.wallet_label
public_profile_trust.title
public_profile_trust.kicker
public_profile_trust.detail
public_profile_trust.cta_wallet
public_profile_trust.cta_history
public_profile_trust.cta_faq
public_profile_trust.wallet_connected
public_profile_trust.wallet_not_connected
public_profile_trust.safe_badge
tasks.error_title
tasks.empty_title
tasks.button_claimed
tasks.button_unavailable
tasks.status_available
tasks.status_claimed
referrals.bonus_rule_title
referrals.bonus_rule_active
ranks.filter_referrals
ranks.filters_title
ranks.referrals
faq.counts_summary
```

## Remaining public identical-to-English count in tracked prefixes

The counts below are post-remediation counts for tracked public prefixes only. Some values remain intentionally identical because they are brand terms, short units, canonical English product terms, or scheduled for the FAQ/wave translation pass.

| Language | Remaining tracked identical values |
|---|---:|
| `ru` | 9 |
| `uk` | 11 |
| `de` | 115 |
| `fr` | 116 |
| `es` | 114 |
| `it` | 115 |
| `tr` | 111 |
| `pl` | 113 |
| `da` | 113 |
| `hi` | 114 |
| `id` | 113 |
| `sw` | 114 |


## Acceptance criteria

- Critical error/confirmation/payment/wallet keys are no longer English-identical in non-English bundles.
- Placeholder tokens remain preserved, including `{count}`, `{id}`, `{{bonus}}`, `{{link}}`, `{sections}`, `{subsections}`, `{items}`.
- Key parity remains exact across all 13 frontend locale files.
- Player-facing fallback remains English-first after the previous critical repair.
- Remaining untranslated tail is documented honestly and routed to the next translation pass.

## Next work

Next cycle: `1371 — FAQ wave-3 translation and status repair`.

Primary goal: repair the FAQ wave-3 identical-English answers and status metadata without disturbing generated FAQ parity.
