# I18N wave-3 public engagement manual pass

Status: COMPLETE for the current narrow domain pass.
Date: 2026-06-03.
Archive target: v169.58.
Cycle: manual public-engagement pass.

## Scope

This pass covers only the `public_engagement.*` public UI domain for the wave-3
languages:

- `de`
- `fr`
- `hi`
- `sw`
- `tr`
- `pl`
- `da`
- `it`
- `es`
- `id`

The pass does not claim full locale completion. The remaining wave-3 public UI
translation backlog continues in later cycles by domain.

## Source rule

Translations were produced from verified Russian meaning and checked against the
current English runtime layer only for UI fit and placeholder consistency.
English fallback and sandbox labels are not semantic sources.

Relevant source anchors:

- `docs/SSOT/LANGUAGE_CANON_SSOT.md`;
- `docs/NORM/LOCALIZATION_WORKFLOW_NORM.md`;
- `docs/frontend/I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`;
- `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_manual i18n range_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`;
- `docs/history/legacy_artifacts/map_element.md` only as UI stress/navigation context.

## Result

The pass updated 43 `public_engagement.*` keys across 10 languages, for 430
manual locale values.

Covered UI groups:

- rank focus cards;
- referral growth cards;
- public engagement tabs;
- task flow preview cards.

## Guard

Added:

- `ops/i18n/audit_wave3_public_engagement_locale_quality.py`;
- `tests/architecture/test_wave3_public_engagement_manual_translation.py`.

The guard checks that wave-3 `public_engagement.*` values are no longer identical
to English and that no Cyrillic tail remains inside that domain.

## Remaining work

Next regular pass: manual pass — wave-3 portal/shop manual translation pass.

Future passes must stay manual and domain-scoped. Do not bulk-fill the residual
locale backlog.
