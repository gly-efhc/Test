# Frontend visual token and shell lock

Статус: completed control lock.
Дата: 2026-05-20.
Версия архива: v168_68.
Цикл: 1270.

## Цель

Перед code pass закрепить визуальную основу, чтобы новые правки не
создавали белый экран, чёрный текст на тёмном фоне, разные кнопки HUB
или хаотичные карточки.

## Базовые токены

- Первый экран всегда тёмный.
- Карточки читаемые, с достаточным контрастом.
- Кнопки одного уровня должны иметь одинаковую высоту.
- HUB использует две равные кнопки.
- Progress bar видим на игровых progress-поверхностях.
- Phone viewport не должен иметь горизонтальный скролл.
- Public UI не показывает debug, proof, endpoint, payload и raw status.

## Shell components

- `FrontendShellRoot`
- `FrontendShellMain`
- `FrontendPageContainer`
- `GamePageShell`
- `GameHero`
- `GameStat`
- `GameSection`
- `GameNotice`
- `GameStatusPill`

## Guard-смысл

CSS и компонентный слой должны служить канону страниц, а не создавать
новые функции или скрывать обязательные данные.
