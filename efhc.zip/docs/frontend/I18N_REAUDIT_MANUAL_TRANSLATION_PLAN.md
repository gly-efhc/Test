# I18N reaudit manual translation plan

Status: ACTIVE after v169.54 reaudit.
Date: 2026-06-03

## Rule

All remaining translation work is manual. The project must not bulk-copy English
strings into non-English locales to reduce counters. English fallback is a
runtime safety net only; it is not a finished translation.

## Source order

1. Direct user decisions and `docs/GENERAL/CURRENT_DECISIONS.md`.
2. FAQ approval layer.
3. Verified Russian FAQ/SSOT when it does not contradict Q/A.
4. EN and other locales only as translation layers.

Sandbox archives and template labels are not translation sources.

## Current residuals from reaudit

- UK: manual pass completed the public manual pass; residual UK value-quality guard now reports 0 unexpected identical values and 0 Russian-tail markers.
- Wave-3 languages DE/FR/HI/SW/TR/PL/DA/IT/ES/ID: `public_engagement.*` is complete in manual pass; remaining domains continue manually.
- `1 kWh = 1 EFHC` is a formula and belongs in the identical-to-English allowlist.
- `tasks.earning_kicker` and `tasks.demo_daily_detail` were converted away from game framing in the current controlled micro-edit.
- Audit script runnable preconditions are restored by stable audit scaffold documents.

## Manual pass discipline

Each language pass must record:

- exact domain and key list;
- Russian meaning used as source;
- changed locale file;
- placeholder parity result;
- identical-to-English delta;
- any terms intentionally kept as brands or formulas.


## manual pass UK pass note

The Ukrainian pass was performed manually from the Russian meaning. It did not use sandbox English labels as translation source and did not close or modify the DE/FR/HI/SW/TR/PL/DA/IT/ES/ID wave-3 backlog.

Protected exact values remain identical only when they are formulas or protocol tokens approved in `ops/i18n/identical_to_english_allowlist.json`.


## manual pass wave-3 public engagement note

The DE/FR/HI/SW/TR/PL/DA/IT/ES/ID `public_engagement.*` domain was translated manually from verified Russian meaning. This closes only the narrow public engagement domain and does not claim full locale completion.

Next planned manual domain pass: portal/shop (`portal.*`, Browser Shop and shop entry text).


## v169.59 / manual pass portal-shop note

Wave-3 `portal.browser_shop.*` and `portal.shop_entry.*` are complete for
DE/FR/HI/SW/TR/PL/DA/IT/ES/ID at static-source level. The pass translated 340
manual values from verified Russian meaning. The new guard reports 0 unexpected
English-identical values and 0 Cyrillic tails for the guarded portal/shop scope.

Remaining wave-3 work should continue by narrow manual domains. The next planned
area is profile and public profile trust wording.


## v169.60 / manual pass profile-trust note

Wave-3 `profile.*` and `public_profile_trust.*` guarded account/trust keys are
complete for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID at static-source level. The pass reviewed 1520 guarded values and updated 430 values from verified Russian meaning. The new
guard reports 0 unexpected English-identical values and 0 Cyrillic tails for the
guarded profile/trust scope.

Remaining wave-3 work should continue by narrow manual domains. The next planned
area is panels/tasks/history wording.


## v169.61 / manual pass panels-tasks-history note

Wave-3 `panels.*`, `tasks.*` and `history.*` guarded public UI keys are complete
for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID at static-source level. The pass checked 1330
guarded values and updated 410 values from verified Russian meaning. The new
guard reports 0 unexpected English-identical values and 0 Cyrillic tails for the
guarded panels/tasks/history scope.

Remaining wave-3 work should continue by narrow manual domains. The next planned
area is hub/energy/wallet/ranks/referrals tail wording.


## v169.62 update — wave-3 hub/energy/wallet/ranks/referrals tail

manual pass closed the guarded wave-3 tail for `hub.*`, `energy.*`, `wallet.*`,
`ranks.*` and `referrals.*` in DE/FR/HI/SW/TR/PL/DA/IT/ES/ID. The pass was
manual and Russian-source. Sandbox labels were not used as translation sources.

Next recommended step: consolidate the remaining public i18n coverage and run a
remaining-tail audit before selecting any further manual translation lane.


## v169.63 / manual pass consolidation note

manual pass consolidated manual pass range and added a cross-locale static/source
guard for the remaining public-locale tail:

- `ops/i18n/audit_i18n_manual_coverage_consolidation.py`.

The guard checks all non-English runtime locale bundles after excluding admin
operator-only keys, protocol/brand/formula exact values, approved key prefixes
and key-specific universal UI abbreviations. It reports 0 unexpected
English-identical values and 0 wave-3 Cyrillic tails.

Two remaining Hindi English-tail strings were corrected manually:

- `browser_login.badge`;
- `exchange.receive_label`.

This remains static/source coverage. It is not human linguistic certification.


## v169.64 browser text stress readiness addendum

manual pass does not add translations. It converts the completed manual translation passes into a screenshot-readiness matrix for later browser capture. The matrix is planning-only and must not be treated as screenshot proof, visual verdict, release readiness or human linguistic certification.

## v169.65 range closure

The 1376–1385 manual i18n repair lane is closed at static/source level. Human linguistic certification and browser screenshot evidence are not claimed.
