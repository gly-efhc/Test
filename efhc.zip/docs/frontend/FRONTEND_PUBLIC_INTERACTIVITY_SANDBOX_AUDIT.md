# FRONTEND_PUBLIC_INTERACTIVITY_SANDBOX_AUDIT

Дата: 2026-05-31
Статус: donor-source audit / no runtime import
Связано с: work pass

## 1. Цель

Проверить старую `Песочница.xz` и новые Telegram Mini App шаблоны на
полезные public UI компоненты для EFHC Bot.

Архивы-доноры:

- `Песочница.xz`;
- `typescript-template-master.zip`;
- `nuxt-telegram-mini-app-main.zip`;
- `vanillajs-template-master.zip`;
- `vuejs-template-master.zip`;
- `solidjs-template-master.zip`.

## 2. Что нам нужно

Нужно переносить не фреймворки, а паттерны:

- Telegram Theme / Viewport CSS vars;
- BackButton helper;
- MainButton intent pattern;
- Haptic feedback wrapper;
- mobile section / cell layout;
- DisplayData rows для компактных фактов;
- ErrorBoundary / retry surface;
- progress / counter / filter chips;
- safe-area bottom spacing.

## 3. Что не переносить

Не нужно переносить:

- Nuxt runtime;
- Vue runtime;
- Solid runtime;
- jQuery view layer из TypeScript template;
- Vanilla build setup;
- старые Tailwind config-файлы;
- router/runtime стеки, не совместимые с Next.js 16;
- новые внешние зависимости без отдельного migration pass.

## 4. Оценка новых шаблонов

### TypeScript template

Полезно:

- `initComponents` как reference для связки MiniApp / theme / viewport;
- TonConnect init flow как reference;
- LaunchParams / ThemeParams pages как diagnostic reference.

Не переносить:

- jQuery page renderer;
- Vite routing model.

### Nuxt Telegram Mini App

Полезно:

- `useTelegramWebApp` как composable reference;
- BackButton / MainButton / Haptic helpers;
- Hero / Section / Cell / Progress / Button patterns;
- ErrorBoundary pattern;
- theme color showcase.

Не переносить:

- Nuxt, Vue components, server api shape.

### Vanilla JS template

Полезно:

- simplest bootstrap and browser fallback reference;
- low-dependency mental model.

Не переносить:

- raw DOM renderer as EFHC runtime layer.

### Vue template

Полезно:

- `AppDisplayData` compact facts layout;
- BackButton route watcher idea;
- TonConnect button shape as reference.

Не переносить:

- Vue plugin/runtime.

### Solid template

Полезно:

- reactive ThemeParams display concept;
- route fallback concept.

Не переносить:

- Solid router/runtime.

## 5. EFHC already has partial equivalents

В EFHC Bot уже есть:

- `frontend/src/lib/telegram.ts`;
- Telegram CSS vars;
- haptic helpers;
- BackButton / MainButton helpers;
- `ErrorBoundary`;
- live Energy progress;
- shared UI components.

Поэтому следующий шаг не импортировать чужой код, а оформить public UI kit
поверх уже существующих EFHC primitives.

## 6. Рекомендация

Да, из новой песочницы нам нужно взять:

1. Public `Section / Cell / DisplayData` style для мобильных экранов.
2. Telegram MainButton intent pattern для Exchange / Panels.
3. Haptic feedback policy для safe public actions.
4. ErrorBoundary retry microcopy.
5. Theme / Viewport / safe-area checklist.

Не нужно брать:

- новые framework runtimes;
- route engines;
- dependency stacks;
- admin/debug demo pages.

## 7. Первый кодовый цикл

Рекомендованный следующий public UI code-cycle:

`1347 — Public Energy interactive overview`

В нём использовать:

- mobile section cards;
- live kWh card;
- compact facts cells;
- haptic tap на safe navigation;
- no admin/debug/internal labels.
