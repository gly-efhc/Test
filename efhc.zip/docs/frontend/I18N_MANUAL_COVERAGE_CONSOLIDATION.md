# I18N manual coverage consolidation — manual pass

Status: static/source consolidation pass.  
Version: v169.63.  
Cycle: manual consolidation pass.

## Purpose

This document consolidates the public-locale manual translation work completed
from manual pass range after the v169.54 i18n reaudit. It does not introduce a
new translation lane and does not claim human linguistic certification.

## Source discipline

Translations remain governed by the Russian-source language canon:

1. direct user decisions and `docs/GENERAL/CURRENT_DECISIONS.md`;
2. FAQ approval layer;
3. verified Russian FAQ/SSOT when aligned with Q/A;
4. English and other locale bundles only as translation layers.

Sandbox archives and `docs/history/legacy_artifacts/map_element.md` remain navigation/reference layers only.
They are not translation sources and do not authorize runtime/framework import.

## Consolidated manual passes

- 1377: UK public manual tail pass;
- 1378: wave-3 `public_engagement.*` pass;
- 1379: wave-3 `portal.browser_shop.*` and `portal.shop_entry.*` pass;
- 1380: wave-3 `profile.*` and `public_profile_trust.*` pass;
- 1381: wave-3 `panels.*`, `tasks.*` and `history.*` pass;
- 1382: wave-3 `hub.*`, `energy.*`, `wallet.*`, `ranks.*` and `referrals.*` tail pass.

## manual pass action

manual pass adds a consolidation guard:

- `ops/i18n/audit_i18n_manual_coverage_consolidation.py`.

The guard checks all runtime locale bundles against English after excluding:

- admin/operator-only keys, which are covered by separate admin localization
  guards;
- approved protocol/brand/formula exact values from
  `ops/i18n/identical_to_english_allowlist.json`;
- approved key prefixes such as `profile.lang.*` and `profile.reason.*`;
- key-specific universal UI abbreviations: `FAQ`, `d`, `h`, `m` only on their
  exact keys.

The key-specific abbreviation exceptions are intentionally not added to the
shared exact-value allowlist because single-letter values are too broad for a
global exact-value exemption.

## Manual micro-fix

The consolidation scan found two real Hindi English-tail strings:

- `browser_login.badge`;
- `exchange.receive_label`.

Both were translated manually in `frontend/public/locale/hi.json`.

## Non-claims

This pass does not claim:

- human linguistic certification;
- GitHub CI green;
- release readiness;
- browser screenshots;
- live Telegram client proof;
- live TonConnect/wallet transaction proof.
