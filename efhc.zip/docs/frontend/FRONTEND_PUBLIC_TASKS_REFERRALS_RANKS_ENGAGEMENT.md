# FRONTEND_PUBLIC_TASKS_REFERRALS_RANKS_ENGAGEMENT

Дата: 2026-05-31
Статус: active public UI canon
Цикл: 1350
Архив: v169_29

## 1. Назначение

work pass внедряет второй слой пользовательской интерактивности:
Tasks, Referrals и Ranks.

Цель: повысить игровую вовлечённость без смешения public UI с Admin.

## 2. Добавленный компонент

`frontend/src/components/public/PublicEngagementPreview.tsx`

Компонент используется на трёх public-страницах:

- `/tasks`;
- `/referrals`;
- `/ranks`.

## 3. Что разрешено

Разрешено показывать:

- progress по публичному пути;
- task catalog / ready counters;
- referral active / total counters;
- rank position / score;
- safe CTA к существующему действию;
- DisplayData-style facts;
- mobile-first tabs;
- haptic feedback on safe tap.

## 4. Что запрещено

Запрещено показывать:

- hidden task execution log;
- admin moderation trace;
- route diagnostics;
- raw API payload;
- raw cursor payload;
- endpoint names;
- operator internals;
- любые admin controls.

## 5. Использование Песочницы

Использованы donor patterns:

- `Песочница.xz` mobile cards and section discipline;
- Telegram Mini App template DisplayData rows;
- compact cell patterns;
- haptic tap pattern;
- mobile progress and filter ideas.

Runtime frameworks из песочницы не переносились.

## 6. Экономические инварианты

work pass не меняет экономику EFHC:

- task bonus flow остаётся существующим;
- referral bonus rule не меняется;
- ranks filters остаются `kWh` и `Referrals`;
- hidden execution history не появляется в public UI.
