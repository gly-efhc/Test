# I18N process correction — off-queue pass

Status: ACTIVE CORRECTION / v169.56 off-queue.

This document records the out-of-order correction requested after manual pass.
It does not consume the planned 1377 UK manual translation pass.

## Scope

The pass corrects the i18n audit process before further manual translation work:

1. `ops/i18n/audit_frontend_hardcoded_strings.py` must run on a clean checkout.
   Historical work-pass report validation is now available only through
   `--strict`.
2. `ops/i18n/audit_notifications_templates_inventory.py` must run on a clean
   checkout. Historical inventory report validation is now available only
   through `--strict`.
3. `1 kWh = 1 EFHC` is an exact protected formula, not translatable prose. It is
   allowed in `ops/i18n/identical_to_english_allowlist.json` with the rate-formula
   rationale.
4. The fallback chain must remain English-first for missing player-facing locale
   values: `dict[k] -> embedded EN -> humanized key`. The Russian argument in
   `tFromDicts` is compatibility-only and must remain ignored.
5. The two previous public EN task strings with `game task` wording were
   corrected to neutral earning/task wording as a tone choice, not as a
   ban on the word game:
   `tasks.earning_kicker = Earning tasks` and
   `tasks.demo_daily_detail = Daily earning task shown even outside Telegram.`

## Game wording decision

`docs/SSOT/GAME_VS_GAMBLING_BOUNDARY_SSOT.md` allows the game layer itself, but
for player-facing localization a neutral earning/action wording can be
preferred when it is clearer. This is a product-tone decision, not a
forbidden-word rule. The word `game` remains allowed when it describes
ordinary gameplay and does not create gambling, loto, betting or random
financial meaning.

No ban exists on `game task` as a phrase. Any future rewrite must check
meaning and tone, not delete the word automatically.

## Translation boundary

No bulk translation is authorized by this pass. Remaining public untranslated
keys must be translated manually from verified Russian meaning, one language or
one tightly scoped domain at a time.
