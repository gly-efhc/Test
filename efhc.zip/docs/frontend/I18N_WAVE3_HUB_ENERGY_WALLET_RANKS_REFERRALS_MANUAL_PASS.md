# I18N wave-3 hub/energy/wallet/ranks/referrals manual pass

Status: DONE in v169.62 / manual pass.

## Scope

This pass closes the guarded wave-3 public UI translation tail for:

- `hub.*`;
- `energy.*`;
- `wallet.*`;
- `ranks.*`;
- `referrals.*`.

Languages:

- `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.

## Source rule

All changed values were written manually from verified Russian meaning and the
active EFHC i18n canon. English runtime fallback and sandbox/template labels were
not used as semantic translation sources.

## Manual update summary

- Guarded domain keys after formula/brand/protocol allowlist exclusions: 176.
- Values checked by the guard: 1760.
- Values updated directly in this pass: 200.
- Domains: hub, energy, wallet, ranks, referrals.
- Protected formulas and tokens remain governed by `ops/i18n/identical_to_english_allowlist.json`.

## Result

`ops/i18n/audit_wave3_hub_energy_wallet_ranks_referrals_locale_quality.py` reports:

- unexpected English-identical values: 0;
- Cyrillic tails: 0.

## Sandbox boundary

`docs/history/legacy_artifacts/map_element.md` and sandbox archives were used only for UI stress context around
hub cards, energy hints, wallet status rows, rank/referral rows and mobile text
wrapping. They were not used as translation sources and no donor runtime code,
wallet/payment logic, lock files or CI files were imported.

## Non-claims

This is a static/source-level i18n pass. It does not claim human linguistic
certification, browser screenshots, GitHub CI green, Telegram client proof,
wallet transaction proof or release readiness.
