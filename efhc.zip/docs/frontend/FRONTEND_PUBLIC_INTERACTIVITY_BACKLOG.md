# FRONTEND_PUBLIC_INTERACTIVITY_BACKLOG

Дата: 2026-05-27  
Статус: backlog / user question answer  
Связано с work pass

## 1. Вопрос

Пользователь спросил:

> Возможно добавить интерактивности для пользовательского интерфейса?

## 2. Ответ

Да. Public UI может получить интерактивность, но это должен быть отдельный
контролируемый маршрут. Нельзя смешивать публичный игровой интерфейс и Admin
operator UI.

## 3. Разрешённые направления public UI интерактивности

Можно развивать:

1. Energy:
   - live kWh pulse;
   - интерактивный progress-ring;
   - раскрытие деталей генерации;
   - mobile-first мини-график.
2. Panels:
   - preview активации панели;
   - статусная карточка активных/архивных панелей;
   - безопасный сценарий `Активации панели 100 EFHC`.
3. Exchange:
   - amount preview;
   - Max / reset;
   - понятный расчёт `1 kWh = 1 EFHC`.
4. Tasks:
   - прогресс заданий;
   - статус выполнения;
   - reward preview.
5. Referrals / Ranks:
   - фильтры;
   - focused self-card;
   - progress to next level.
6. History:
   - фильтры событий;
   - компактная timeline.

## 4. Запреты

Public UI нельзя развивать через:

- admin-only components;
- operator diagnostics;
- route/debug labels;
- raw payload;
- публичный показ `admin.*` ключей;
- изменение экономических инвариантов;
- скрытие обязательных балансов, курса и статусов.

## 5. Sandbox usage

Песочница может использоваться как donor-source для public UI, но только через
адаптацию под EFHC functions:

- карточки;
- filters;
- mobile drawer/list patterns;
- status blocks;
- confirmation blocks;
- empty/error states;
- charts where они не требуют случайного dependency upgrade.

## 6. Рекомендованный будущий цикл

`Public UI interactive upgrade wave — Energy / Panels / Exchange mobile-first`

Этот маршрут можно назначить отдельно после admin adoption wave либо раньше по
прямой команде пользователя.

## 7. work pass implementation plan

work pass added:

`docs/frontend/FRONTEND_PUBLIC_INTERACTIVITY_IMPLEMENTATION_PLAN.md`

The recommended public UI order is:

1. Public Energy interactive overview;
2. Public Panels activation preview;
3. Public Exchange interactive preview;
4. Public Tasks / Referrals / Ranks engagement;
5. Public History / Profile trust layer.

Public UI interactivity remains separate from Admin operator dashboards.
