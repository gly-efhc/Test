
# PWA install policy lock — work pass

Status: active frontend recovery control.
Archive version: v168_72.
Date: 2026-05-20.

## Purpose

work pass locks the browser/PWA installation rule for EFHC Bot.
The application must be installable through the browser or operating
system controls, not through a custom EFHC button inside the public UI.

## User canon

- Installation uses the browser/system install control.
- No separate EFHC install button is added without later chat approval.
- Telegram WebApp and browser/PWA open the same EFHC application surface.
- Browser/PWA login may show a demo-preview, but must not invent a fake
  account.
- A missing Telegram session must never result in a white screen.

## Allowed

- `manifest.webmanifest`.
- `sw.js` as a shell/service-worker file.
- browser or OS install controls shown by the user agent.
- a short text hint in documentation or future UI, if approved in chat.

## Forbidden in public UI

- custom `Install app` button;
- custom `Install EFHC` button;
- `beforeinstallprompt` handler used to force an in-app install flow;
- `appinstalled` analytics/control flow presented to the user;
- any fake install banner that looks like an EFHC feature.

## Current implementation result

The scan found no active custom frontend install button.  The manifest
and service worker remain present as infrastructure.  No frontend screen
was changed in this cycle.

## Guard

`tests/architecture/test_pwa_install_policy_guard.py` verifies that
public frontend sources do not add custom install button handlers or
button labels.

## Next cycle

work pass starts the Energy canonical composition pass.
