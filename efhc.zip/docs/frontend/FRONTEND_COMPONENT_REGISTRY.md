<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Current GlobalHeader component — v171.52

- `GlobalHeader`: active shared public header.
- Profile, FAQ, Wallet, Direct Deposit and HUB actions remain preserved.
- Exact balance remains one canonical value, rendered with separate whole/fraction spans only for visual hierarchy; no rounding or truncation is introduced.
- Header Activ/VIP use the local text-only `HeaderStatus` presentation.
- Inactive states are gray; both active states use the same gold glow.
- Responsive proof targets: 360 and 390 px.

---


# Current component registry update — account surfaces

- `WebProfilePage`: active routed account shell.
- `ProfileWalletSection`: active wallet list and wallet actions.
- `ProfileHistorySection`: active balance and withdrawal history.
- `FaqVerticalTree`: active full FAQ presentation.
- `WebProfileAccountDashboard`: retained legacy, not mounted.
- `PublicProfileTrustLayer`: retained legacy, not mounted.
- Replacement mapping:
  `FRONTEND_PROFILE_LEGACY_SURFACE_REPLACEMENT_MAPPING.md`.

---

# Current Referrals, Ranks and navigation components — v171.33

- `referrals.tsx`: active statistics, copy/share and segments surface.
- `ReferralListPage.tsx`: active/inactive paged lists.
- `useReferrals.ts` and `referrals.service.ts`: typed server state.
- `ranks.tsx`: personal card and vertical TOP-100.
- `useRanks.ts` and `ranks.service.ts`: typed leaderboard server state.
- `EfhcCoin.tsx`: universal energy SVG.
- `AppNavIcon.tsx`: one six-icon bottom-navigation system.
- Historical referral/ranks dashboards remain inactive legacy references.

---

# Current Tasks and modal components — v171.32

- `tasks.tsx`: one active operational catalogue.
- `useTasks.ts`: catalog/state queries and claim/ad mutations with invalidation.
- `tasks.service.ts`: Zod-validated task and advertising DTO boundary.
- `Modal.tsx`: body portal above fixed navigation.
- Historical Tasks dashboard/engagement components are inactive legacy.

---

# Current Panels and Exchange components — v171.31

- `frontend/src/pages/panels.tsx`: active query-driven Panels screen.
- `usePanelsList`: paged active/archive server state.
- `usePanelsSummary`: count and capacity summary state.
- `usePanelActivation`: idempotent activation and invalidation.
- `frontend/src/pages/exchange.tsx`: active query-driven Exchange screen.
- `useExchangePreview`: authoritative visible preview.
- `useExchangeConvert`: conversion mutation and preview/snapshot invalidation.
- Generated DTOs and validators are the boundary before view rendering.

---

# Current shell components — v171.30

- `BrowserLoginDemo`: compact browser-mode notice only.
- `Layout`: protected English visual navigation labels plus localized
  `aria-label` and `title` values.
- `FrontendShell`: localized content span, busy state and visual spinner.
- `LiveEnergyHeroAndProgress`: validated initial progress and exact zero.

No duplicate browser Energy component is active.

---

# Current Energy components — v171.38

## LiveEnergyHeroAndProgress

- File: `frontend/src/pages/index.tsx`.
- Status: single active public Energy component.
- Inputs: validated `SyncSnapshot`, canonical level table and translated
  Energy labels.
- Responsibilities: generated kWh, exact progress, current named level,
  active panels, effective rate and available kWh.

## Legacy Energy components

- `EnergyMvpSummary`: inactive legacy reference; Wallet and Exchange controls
  are forbidden on the active Energy route.
- `EnergyDashboardRuntime`: inactive legacy reference.
- `PublicEnergyInteractiveOverview`: replacement complete; retained until the
  documented deletion gate is satisfied.
- Mapping: `FRONTEND_ENERGY_MVP_REPLACEMENT_MAPPING.md`.

---

# FRONTEND COMPONENT REGISTRY

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## Registry rule

A component may be visually improved only inside its role. A visual
pass must not change business meaning, hide mandatory data or add
random functions.

## Root and shell components

### Layout

- Used in: main public pages.
- Visual role: header, context and protected bottom nav.
- Inputs: snapshot and runtime context.
- States: loading, fallback, logged user, guest user.
- May change: spacing, active state clarity.
- Forbidden: six nav labels/order and debug visibility.

### GlobalHeader

- Used in: public shell.
- Visual role: profile, balance, deposit, wallet and FAQ entries.
- Inputs: context, labels, actions.
- States: normal, loading, admin user.
- May change: visual structure and contrast.
- Forbidden: Deposit / Wallet / HUB actions without proof.

### FrontendShellRoot

- Used in: shop and future shell-controlled pages.
- Visual role: root dark background.
- Inputs: children and class names.
- States: normal.
- May change: tokens and safe area.
- Forbidden: business logic.

### FrontendShellFrame

- Used in: desktop/browser framing.
- Visual role: centered max-width frame.
- Inputs: children.
- States: normal.
- May change: width within contract.
- Forbidden: horizontal overflow.

### FrontendShellMain

- Used in: shop and standalone pages.
- Visual role: main content area.
- Inputs: children.
- States: normal.
- May change: spacing.
- Forbidden: accidental bottom nav.

### FrontendPageContainer

- Used in: controlled pages.
- Visual role: vertical rhythm.
- Inputs: children.
- States: normal.
- May change: spacing and max width.
- Forbidden: page-specific business decisions.

### ShopLayout

- Used in: Browser-Shop.
- Visual role: separate storefront shell.
- Inputs: children and shop header data.
- States: loading, error, normal.
- May change: storefront polish.
- Forbidden: public bottom nav.

### Modal

- Used in: mobile bottom-sheet layer.
- Visual role: temporary focused action.
- Inputs: open, title, children.
- States: open, closed.
- May change: visual sheet polish.
- Forbidden: Profile as main surface.

## Game UI components

### GamePageShell

- Used in: public game pages.
- Visual role: game page container.
- Inputs: title, subtitle, actions, children.
- States: normal, loading.
- May change: density and polish.
- Forbidden: replacing bottom nav.

### GameHero

- Used in: page hero blocks.
- Visual role: main visual center.
- Inputs: title, value, subtitle, children.
- States: normal, loading.
- May change: typography and layout.
- Forbidden: long help/debug text.

### GameStatsGrid

- Used in: summary blocks.
- Visual role: responsive stat group.
- Inputs: stat children.
- States: normal.
- May change: columns by viewport.
- Forbidden: hiding mandatory stats.

### GameStat

- Used in: stat grids.
- Visual role: one number / one label.
- Inputs: label, value, note.
- States: normal, empty.
- May change: number styling.
- Forbidden: combining unrelated facts.

### GameActionCard

- Used in: approved actions.
- Visual role: clear action card.
- Inputs: title, detail, href/action.
- States: normal, disabled, loading.
- May change: hierarchy.
- Forbidden: unapproved Energy actions.

### GameDetails

- Used in: secondary data.
- Visual role: detail containment.
- Inputs: title and content.
- States: open/closed where approved.
- May change: density.
- Forbidden: hiding balances or base rate.

### GameNotice

- Used in: short notices.
- Visual role: human message.
- Inputs: title, detail, tone.
- States: info, warning, error.
- May change: tone and spacing.
- Forbidden: technical proof text public.

### GameStatusPill

- Used in: statuses.
- Visual role: compact human state.
- Inputs: label, tone.
- States: normal.
- May change: shape and tone.
- Forbidden: raw backend codes.

### EnergyGauge

- Used in: Energy.
- Visual role: visual energy/progress indicator.
- Inputs: value and progress.
- States: 0 to full.
- May change: animation/polish.
- Forbidden: fake decorative progress.

## Admin components

### AdminPage

- Used in: admin root.
- Visual role: operator page wrapper.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminHeroPanel

- Used in: admin root.
- Visual role: operator context hero.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminStatCard

- Used in: admin dashboards.
- Visual role: KPI metric.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminAppButtonGrid

- Used in: admin root.
- Visual role: large app launcher grid.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminActionGrid

- Used in: admin modules.
- Visual role: action grouping.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminCharts

- Used in: admin dashboard.
- Visual role: graphical indicators.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminTable

- Used in: admin lists.
- Visual role: structured operator table.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminRouteHealthStrip

- Used in: diagnostics.
- Visual role: route health summary.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminDetailShell

- Used in: admin detail pages.
- Visual role: details layout.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminListShell

- Used in: admin list pages.
- Visual role: list layout.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminPromptModal

- Used in: admin actions.
- Visual role: confirm / prompt layer.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminSurfaceTabs

- Used in: admin modules.
- Visual role: operator tabs.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminSectionCard

- Used in: admin modules.
- Visual role: section grouping.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

### AdminSettingsCard

- Used in: admin settings.
- Visual role: settings grouping.
- Inputs: module-specific data.
- States: normal, loading, empty, error where applicable.
- May change: layout, labels, spacing and hierarchy.
- Forbidden: player-facing styling that reduces operator clarity.

## FAQ components

### FaqVerticalTree

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqHeader

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqSearchBar

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqQuestionItem

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqSectionList

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqSubsectionList

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqNoResultsState

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqBreadcrumbHeader

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqKeywordTags

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqPopularQuestions

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqQuickLinks

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqRelatedQuestions

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

### FaqAccordionList

- Used in: FAQ shell.
- Visual role: compact knowledge navigation or answer display.
- Inputs: localized FAQ catalog, navigation state or search state.
- States: normal, open, closed, empty or search result.
- May change: compactness and containment.
- Forbidden: making pills/grid the main FAQ model.

## Profile and wallet components

### WebProfilePage

- Used in: `/web-profile`.
- Visual role: profile page root.
- Inputs: profile, wallet or history data.
- States: guest, connected, empty, loading, error.
- May change: layout and human labels.
- Forbidden: raw wallet codes and overlay regression.

### ProfileWalletSection

- Used in: `/web-profile`.
- Visual role: real wallets and wallet state-map.
- Inputs: profile, wallet or history data.
- States: guest, connected, empty, loading, error.
- May change: layout and human labels.
- Forbidden: raw wallet codes and overlay regression.

### ProfileHistorySection

- Used in: `/web-profile`.
- Visual role: balance and withdraw history.
- Inputs: profile, wallet or history data.
- States: guest, connected, empty, loading, error.
- May change: layout and human labels.
- Forbidden: raw wallet codes and overlay regression.

### ProfileFaqSection

- Used in: `/web-profile`.
- Visual role: FAQ access from profile.
- Inputs: profile, wallet or history data.
- States: guest, connected, empty, loading, error.
- May change: layout and human labels.
- Forbidden: raw wallet codes and overlay regression.

### useWalletsMe

- Used in: `/web-profile`.
- Visual role: wallet data hook.
- Inputs: profile, wallet or history data.
- States: guest, connected, empty, loading, error.
- May change: layout and human labels.
- Forbidden: raw wallet codes and overlay regression.

## Base UI components

### Button

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### Card

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### Badge

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### EfhcButton

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### EfhcCard

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### EfhcStatus

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### EmptyState

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### Skeleton

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### SurfaceFactsStrip

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

### LevelSkinBadge

- Used in: shared UI.
- Visual role: base reusable element.
- Inputs: component-specific props.
- States: normal and component-specific states.
- May change: tokens and consistency.
- Forbidden: page-specific hidden business logic.

## v168_61 component clarifications

### FAQProfileButton

- Used in: Profile FAQ tab.
- Visual role: opens the full `/faq` page.
- Forbidden: embedding a second heavy FAQ copy inside Profile.

### WalletListPage

- Used in: wallet function page or wallet tab.
- Visual role: list connected wallets and connection state.
- Forbidden: mixing all account financial history into wallet list.

### AccountFinanceHistoryPage

- Used in: common history route/action.
- Visual role: one account-wide financial history of all movements.
- Forbidden: splitting history into confusing wallet-only fragments.

### AdminSectionLauncherCard

- Used in: Admin home.
- Visual role: equal operator section button/card.
- Forbidden: placing every graph on Admin home.

### AdminFunctionalSectionPage

- Used in: Users, Bank, Withdrawals, Shop, Tasks, Reports,
  Diagnostics and System pages.
- Visual role: statistics or graph at top, actions below.
- Forbidden: turning a functional section into a debug dump.

### Web3ProductImageCard

- Used in: Browser-Shop.
- Visual role: large NFT/product image, title, description, price and
  Pay action.
- Forbidden: raw wallet, memo, endpoint, SKU or debug fields.

### RankPlayerCard

- Used in: Ranks.
- Visual role: vertical player card with position, name and energy.
- Forbidden: table-first redesign unless user approves it in chat.

### EqualHubActionButton

- Used in: HUB.
- Visual role: two equal-size aligned actions.
- Forbidden: uneven card/button sizes and a third action without chat
  approval.

## 2026-05-27 — Admin Dashboard UI Kit registry

Registered Admin UI Kit foundation components:

- `AdminKpiCard`
- `AdminChartCard`
- `AdminFlowMapCard`
- `AdminFilterBar`
- `AdminActionTable`
- `AdminStatusBadge`
- `AdminConfirmationBlock`
- `AdminEmptyState`
- `AdminErrorState`
- `AdminSectionHeader`

Code location:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

## work pass — AdminInteractiveOperatorPanel

Component:

`frontend/src/components/admin/AdminInteractiveOperatorPanel.tsx`

Role:

Reusable interactive section for real Admin operator pages.

Current consumers:

- `frontend/src/pages/admin/bank.tsx`;
- `frontend/src/pages/admin/users.tsx`.

Visual/interaction pattern:

- metric filter;
- 7 / 14 / 30 step window;
- zoom control;
- live pulse;
- clickable SVG points;
- flow-node metric switching;
- selected state table.

Boundary:

It may organize operator UI but must not change backend economics, bank ledger
canon, withdraw statuses or `global_id` canon.

### AdminWithdrawalsMobileDecisionPanel — work pass — Used in: `/admin/withdrawals`.
- Visual role: mobile-first operator decision center for withdrawal cases.
- Inputs: withdrawal list, selected case, status filter, VIP filter,
  preview mode, preview result, repair/loading state, callbacks.
- States: empty lane, selected case, pending payout, final outcome, repair note.
- Sandbox donors: `chart-area-interactive.tsx`, `section-cards.tsx`,
  `data-table.tsx`, MaterialM dashboard cards.
- Forbidden: backend economic mutation, direct status overwrite, public UI use,
  route debug strip on the main operator surface.

### AdminRouteGuardState — work pass — Location: `frontend/src/pages/app.tsx`.
- Role: global client-side guard for `/admin` and `/admin/*` routes.
- Marker: `data-admin-client-route-guard="1329"`.
- Boundary: UI/UX guard only; backend `require_admin` remains mandatory for all admin APIs.


## 2026-05-27 — work pass frontend standard actualization

Target frontend standard for all future frontend work:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

Current package dependencies may still reflect the pre-migration line.
That is technical debt, not target canon. Use
`docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN.md`
for the controlled migration route.

## 2026-05-27 — work pass component runtime standard

All frontend components now target React 19.2.6 and Next.js 16.2.6.
Component work must stay compatible with the migrated TypeScript and
Tailwind v4 runtime.

## 2026-05-27 — work pass Tailwind config removal

Tailwind CSS v4.3 is now CSS-first only in HEAD. The active project theme
source is `frontend/src/styles/globals.css` via `@theme` and the PostCSS
adapter is `@tailwindcss/postcss`. `frontend/tailwind.config.js` has been
removed and must not be recreated for ordinary UI work.

## work pass — AdminTasksCatalogUxPanel

Component:

`frontend/src/components/admin/AdminTasksCatalogUxPanel.tsx`

Consumer:

- `/admin/tasks` via `frontend/src/pages/admin/tasks.tsx`.

Role:

Mobile-first operator catalog and moderation queue layer for Admin Tasks.

UI Kit primitives used:

- `AdminSectionHeader`;
- `AdminFilterBar`;
- `AdminKpiCard`;
- `AdminFlowMapCard`;
- `AdminChartCard`;
- `AdminActionTable`;
- `AdminEmptyState`;
- `AdminErrorState`;
- `AdminStatusBadge`;
- `AdminConfirmationBlock`.

Boundary:

The component organizes task catalog and moderation visibility only. It must not
change rewards, backend moderation rules or CI/workflow files.

## AdminTasksExecutionTracePanel — work pass

Path:

`frontend/src/components/admin/AdminTasksExecutionTracePanel.tsx`

Purpose:

Admin-only sanitized trace boundary for Tasks reward execution.

Applied screen:

`frontend/src/pages/admin/tasks.tsx`

Data source:

`/admin/logs/transfers?reason=task_bonus`

Boundary:

No raw meta dump, no raw cursor payload display, no public hidden execution
history.

## work pass — AdminReportsVisualDashboardPanel

- File: `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`
- Used by: `frontend/src/pages/admin/reports.tsx`
- Purpose: mobile-first Reports dashboard with filters, SVG trend, zoom,
  clickable points and operator detail table.
- Boundary: read-only; no economic mutation.

## work pass — AdminReportsExportDownloadPanel

- File: `frontend/src/components/admin/AdminReportsExportDownloadPanel.tsx`
- Surface: `/admin/reports`
- Purpose: sanitized JSON/CSV/TXT report snapshot export.
- Boundary: read-only, client-side download, no backend mutation.

## work pass — `frontend/src/components/admin/AdminDiagnosticsTechnicalBoundaryPanel.tsx` —
  mobile-first diagnostics technical-only panel for `/admin/diagnostics`.

## Planned public UI primitives from work pass

Future public UI components should be built from EFHC primitives and inspired
by sandbox donor patterns:

- public mobile section;
- public action cell;
- public display-data facts row;
- public progress block;
- public safe MainButton intent block;
- public haptic action wrapper;
- public error/retry state.

Do not import Nuxt, Vue, Solid, Vanilla or jQuery runtime layers.


## work pass — PublicEnergyInteractiveOverview

- File: `frontend/src/components/public/PublicEnergyInteractiveOverview.tsx`
- Surface: public Energy page `frontend/src/pages/index.tsx`
- Purpose: mobile-first interactive overview with tabs, DisplayData-style
  facts, safe haptic tap and CTA to Panels/Exchange.
- Boundary: no admin diagnostics, no raw payload, no economic calculation on
  frontend.


## work pass — PublicPanelsActivationPreview

`frontend/src/components/public/PublicPanelsActivationPreview.tsx` is the
public-only mobile-first preview layer for panel activation. It uses
DisplayData-style rows, safe haptic taps and an activation progress ring.


## PublicExchangeInteractivePreview
- Path: frontend/src/components/public/PublicExchangeInteractivePreview.tsx
- work pass — Purpose: public mobile-first exchange preview without admin internals.

## work pass — PublicEngagementPreview

- Component: `frontend/src/components/public/PublicEngagementPreview.tsx`
- Surfaces: `/tasks`, `/referrals`, `/ranks`
- Purpose: mobile-first public engagement preview.
- Boundary: no admin diagnostics, no hidden task execution log.

## work pass — PublicProfileTrustLayer

- Component: `frontend/src/components/public/PublicProfileTrustLayer.tsx`
- Surface: `/web-profile`
- Purpose: mobile-first profile / wallet / history trust summary.
- Boundary: public-only; no admin diagnostics, raw payload or hidden execution
  log.

### AdminUiKitAdoptionProofPanel

Path: `frontend/src/components/admin/AdminUiKitAdoptionProofPanel.tsx`.

Role: Admin-home proof panel that shows where the shared Admin Dashboard UI
Kit is actively adopted. It is Admin-only, uses shared UI Kit primitives and
must not be used in public UI.

## work pass Admin screenshot QA component

- `AdminScreenshotQaPreparationPanel` — Admin-only screenshot QA matrix on
  `/admin`, using shared Admin UI Kit primitives.
- work pass: Admin docs route map records current Admin UI Kit component adoption.


## work pass — AdminBankDashboardRuntime

`frontend/src/components/admin/AdminBankDashboardRuntime.tsx`

Read-only Admin Bank dashboard component added in the Admin Bank dashboard upgrade. It shows
raw + derived snapshot bank metrics, flow map, ledger activity and bank
safety boundaries without write actions.

## Current HUB and Direct Deposit components

- `HubPage`: two-action navigation surface.
- `DepositModal`: amount and watcher reconciliation surface.
- `useHubEfhcHandoff`: EFHC handoff mutation.
- `useDirectDepositOpen`: wallet-open mutation.
- `useDirectDepositStatus`: financial-history reconciliation query.
