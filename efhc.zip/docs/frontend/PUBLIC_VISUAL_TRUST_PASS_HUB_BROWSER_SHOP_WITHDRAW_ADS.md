# Public visual trust pass — HUB / Browser Shop / Withdraw / Ads

Status: DONE as static/source visual trust polish.

## Purpose

This pass improves the public trust and clarity layer for the money/commerce edge
surfaces:

- `/hub`;
- `/browser-shop`;
- `/withdraw`;
- `/ads` compatibility alias.

The pass is visual/source-level only. It does not claim browser screenshots,
GitHub CI green, release readiness or live Playwright proof.

## Boundaries

Do not change:

- EFHC economics;
- bank ledger semantics;
- withdraw request/cancel semantics;
- Browser Shop payment intent semantics;
- TON/TonConnect transaction logic;
- admin pages;
- CI workflow files.

Sandbox archives and `docs/history/legacy_artifacts/map_element.md` are reference-only. Vue, Solid, Nuxt,
Vanilla or foreign runtime code must not be imported into EFHC Bot.

## Surfaces and source changes

| Surface | Files | Visual trust additions |
|---|---|---|
| HUB | `frontend/src/features/hub/HubPage.tsx` | trust shell marker, `data-public-surface="hub"`, action trust rail, action card focus layer |
| Browser Shop | `frontend/src/features/browser-shop/BrowserShopPage.tsx` | trust shell marker, `data-public-surface="browser-shop"`, token/catalog/payment/receipt rail, product grid trust styling |
| Withdraw | `frontend/src/pages/withdraw.tsx` | trust shell marker, `data-public-surface="withdraw"`, wallet/amount/request/outcome rail, metric/request/history card polish |
| Ads | `frontend/src/pages/ads.tsx` | trust shell marker, `data-public-surface="ads"`, compatibility rail that explains legacy link → Tasks redirect |
| Shared CSS | `frontend/src/styles/globals.css` | rail/chip styling, focus-visible, mobile 390px constraints, reduced-motion safety |

## Public markers

The pass adds the following source markers:

- `data-public-visual-trust="hub-browser-shop-withdraw-ads"`;
- `data-public-surface="hub"`;
- `data-public-surface="browser-shop"`;
- `data-public-surface="withdraw"`;
- `data-public-surface="ads"`;
- `efhc-hub-trust-rail`;
- `efhc-browser-shop-trust-rail`;
- `efhc-withdraw-trust-rail`;
- `efhc-ads-trust-rail`.

## Human-facing intent

### HUB

HUB now explains the two permitted operator/user actions as a compact trust
flow: EFHC top-up, VIP NFT and external handoff. The action grid remains two
buttons only.

### Browser Shop

Browser Shop now shows a trust rail for token, catalog, TON handoff and receipt
state. Product cards receive stronger hierarchy and focus feedback without
showing raw wallet payloads or endpoint internals.

### Withdraw

Withdraw now exposes a clear flow: wallet → amount → requests → outcome. The
metric, request and history cards are more readable and easier to tap on mobile.
The actual withdraw mechanics remain unchanged.

### Ads

`/ads` remains a compatibility alias to `/tasks`. The page now communicates the
safe redirect path instead of looking like a broken standalone ad page.

## Acceptance checklist

- HUB keeps exactly the two canonical public actions.
- Browser Shop keeps no bottom public menu and no raw payload/endpoint dump.
- Withdraw keeps confirmation/idempotency semantics and does not bypass wallet
  connection checks.
- Ads remains a compatibility redirect to Tasks.
- All four surfaces have visible source markers for future screenshot/evidence
  checks.
- Public visual polish does not import admin components.
- CSS includes mobile and reduced-motion protections.

## Non-claims

This pass does not claim:

- actual PNG screenshots;
- real browser visual verdict;
- frontend typecheck/build success;
- full backend pytest success;
- GitHub CI green;
- release readiness.
