# FRONTEND_PUBLIC_ENERGY_INTERACTIVE_OVERVIEW

Дата: 2026-05-31
Статус: implemented
Архив: v169_26
Цикл: 1347 — Public Energy interactive overview

## 1. Цель

Начать кодовую волну интерактивности пользовательских страниц с главного
Energy screen. Цель — сделать первый экран более живым и mobile-first, но не
менять экономику EFHC и не переносить admin/operator-паттерны в public UI.

## 2. Что добавлено

Добавлен компонент:

`frontend/src/components/public/PublicEnergyInteractiveOverview.tsx`

Подключён в:

`frontend/src/pages/index.tsx`

Компонент добавляет:

- интерактивные вкладки `Overview / Panels / Exchange`;
- mobile-first facts rows в стиле DisplayData;
- safe haptic tap wrapper;
- компактный SVG flow между Energy, Panels и Exchange;
- selected-state detail block;
- safe CTA на `/panels` или `/exchange`;
- hide-balances совместимость.

## 3. Donor-source

Использованы sandbox-паттерны:

- старая `Песочница.xz`: mobile cards / interactive chart / section-card
  discipline;
- `typescript-template-master.zip`: DisplayData rows;
- `nuxt-telegram-mini-app-main.zip`: Telegram Mini App sections/cells;
- `vanillajs-template-master.zip`: compact display-data examples;
- `vuejs-template-master.zip`: BackButton/component surface ideas;
- `solidjs-template-master.zip`: DisplayData component pattern.

В EFHC перенесены только идеи. Runtime Nuxt/Vue/Solid/Vanilla/jQuery не
переносился.

## 4. Public UI boundary

Разрешено:

- показывать user facts из snapshot;
- делать tabs, selected-state, haptic tap, safe CTA;
- показывать компактные значения kWh / EFHC;
- учитывать `hide_balances`.

Запрещено:

- показывать admin route labels;
- показывать diagnostics strips;
- показывать endpoint names;
- показывать raw API payload;
- показывать cursor payload;
- менять экономический расчёт на frontend;
- делать скрытые admin actions.

## 5. Экономические инварианты

Не изменены:

- `1 EFHC = 1 kWh`;
- `kWh -> EFHC` только через Exchange;
- активация панели остаётся действием `/panels`;
- frontend не рассчитывает экономику, а показывает snapshot;
- current-user roads сохраняются.

## 6. Следующий public UI шаг

Следующий безопасный public cycle:

`1348 — Public Panels activation preview`
