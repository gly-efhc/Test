# FAQ wave-3 translation and status repair

## Status

Work pass: `1371 — FAQ wave-3 translation and status repair`.
Archive target: `v169_49`.
Source audit: `docs/history/legacy_artifacts/docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md` and `docs/history/legacy_artifacts/reports/generated/i18n_audit_summary_v169_45.json`.

## Scope

This pass repairs the FAQ-specific language quality tail identified after the v169.45 localization audit:

- 21 FAQ answers that were identical to English in wave-3 languages;
- non-rank FAQ questions that remained identical to English;
- Hindi and Swahili referral-level question labels that were still English;
- `TRANSLATION_STATUS.md` language-quality status after repair;
- generated frontend FAQ catalog sync from SSOT JSON.

Wave-3 languages repaired in this pass:

`de`, `fr`, `es`, `it`, `tr`, `pl`, `da`, `hi`, `id`, `sw`.

## Repaired FAQ item numbers

The repaired global item numbers are:

`42`, `45`, `54`, `156`, `159-172`, `232`, `239`, `246`.

Additionally, Hindi and Swahili question labels for referral levels were repaired for:

`233-238`.

## Post-repair result

After repair:

- every FAQ language still has 20 sections and 250 Q&A items;
- no non-English language has FAQ answers identical to English;
- remaining identical FAQ questions are restricted to items `221-232`, the canonical level names such as `Eco Initiate`, `Solar Sprout`, `Guardian of Earth`;
- `frontend/src/data/faq/catalogs.ts` was regenerated from SSOT JSON.

## Boundary

This pass does not change runtime routing, backend logic, EFHC economics, wallet/TonConnect logic, admin Russian-first policy, CI workflow files or sandbox runtime code.

This pass is a translation-quality repair. It does not claim full human linguistic certification. It does close the specific FAQ wave-3 identical-English tail from the audit.
