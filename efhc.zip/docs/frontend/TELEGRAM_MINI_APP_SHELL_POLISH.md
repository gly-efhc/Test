# Telegram Mini App shell polish

Status: DONE as source/static shell polish. Browser Telegram client proof is not claimed.

## Scope

This pass continues the v169 public lane after the Russian source language canon lock. It improves the Telegram Mini App shell without changing EFHC economics, backend roads, wallet transaction semantics, admin UI or CI workflows.

Surfaces and files:

- `frontend/src/lib/telegram.ts` — Telegram WebApp shell helpers.
- `frontend/src/components/Layout.tsx` — app shell, safe-area, route BackButton behavior.
- `frontend/src/styles/globals.css` — shell CSS for viewport/safe-area/theme polish.
- `docs/history/legacy_artifacts/map_element.md` — sandbox reference navigation.

## Implemented shell controls

### Viewport and safe-area

`applyTelegramCssVars()` now marks whether the runtime is Telegram or browser/PWA and exposes additional Telegram safe-area variables:

- `data-tma-shell="telegram|browser"`;
- `data-tg-platform` when Telegram provides a platform string;
- `data-tg-viewport-state="expanded|compact"` when Telegram provides `isExpanded`;
- `--tg-content-safe-top` / `--tg-content-safe-bottom`;
- `--tg-device-safe-top` / `--tg-device-safe-bottom`.

The existing `--efhc-safe-top` and `--efhc-safe-bottom` remain the canonical combined safe-area variables used by the UI.

### Theme sync

The Telegram theme token bridge remains best-effort and does not overwrite EFHC design tokens. It keeps Telegram chrome colors aligned through the existing app theme flow while preserving the EFHC dark/gold/TON visual canon.

### BackButton behavior

The Telegram BackButton now has a route-level public shell behavior:

- root route `/` does not show route BackButton;
- admin routes do not use public BackButton behavior;
- Deposit modal still owns BackButton while open;
- TonConnect modal state suppresses route-level BackButton;
- public non-root routes use BackButton to go browser-history back or return to `/`.

### Browser/PWA fallback

When Telegram WebApp is not present, the shell remains browser-safe through `data-tma-shell="browser"`, `100dvh` support and existing Browser/PWA fallbacks.

## Sandbox usage

Sandbox archives were used only as reference/navigation:

- TypeScript and Vanilla Telegram Mini App templates: viewport/theme/BackButton assumptions;
- Nuxt Telegram Mini App template: test organization and TMA shell ideas;
- TelegramUI / Telebook / Mark42: shell rhythm and compact mobile thinking;
- TonConnect demos: modal/shell separation idea only.

No Vue/Solid/Nuxt/Vanilla runtime, lockfile, CI or payment logic was imported.

## Explicit non-claims

This pass does not claim:

- real Telegram client run;
- real browser screenshot verdict;
- real Playwright execution against localhost;
- GitHub CI green;
- release readiness.
