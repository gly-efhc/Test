<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / SUPERSEDED EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# FRONTEND_PUBLIC_INTERACTIVITY_IMPLEMENTATION_PLAN

Дата: 2026-05-31  
Статус: implementation plan / not applied to public pages yet  
Связано с: work pass

## 1. Цель

Пользовательский интерфейс EFHC Bot можно и нужно усиливать интерактивностью.
Но public UI должен развиваться отдельно от Admin UI, без operator diagnostics,
raw payload, admin route labels и backend internals.

Цель волны: сделать пользовательские страницы более живыми, понятными и
mobile-first, не меняя экономические инварианты EFHC.

## 2. Главные инварианты

Нельзя менять:

- `1 EFHC = 1 kWh`;
- `kWh → EFHC` только 1:1;
- withdraw только из `main_balance`;
- panel activation: `Активации панели 100 EFHC`;
- bonus spend before main spend;
- отсутствие публичных admin/debug/internal labels;
- current-user roads вместо global_id/user_id path/query.

## 3. Sandbox donor-source

Песочница используется как donor-source для UX-паттернов:

- cards;
- tabs;
- mobile drawers;
- progress blocks;
- compact data decks;
- safe confirmation blocks;
- empty/error states;
- interactive charts без нового dependency upgrade.

Не переносить вслепую:

- admin-only tables;
- debug panels;
- raw payload viewers;
- external dependency stack без отдельного migration pass;
- charts, которые требуют нового runtime package.

## 4. Варианты внедрения

### Вариант A — минимальная mobile-first волна

Страницы:

1. `Energy`
2. `Panels`
3. `Exchange`

Что добавить:

- live kWh pulse;
- progress-ring / progress-bar;
- panel activation preview;
- exchange amount preview;
- Max / reset;
- compact explanation cards.

Риск низкий. Лучший вариант для первого public UI цикла.

### Вариант B — игровая вовлечённость

Страницы:

1. `Tasks`
2. `Referrals`
3. `Ranks`

Что добавить:

- task progress cards;
- reward preview;
- referral progress to next level;
- focused self-card;
- mobile filter chips.

Риск средний: важно не раскрыть скрытый execution log.

### Вариант C — история и доверие

Страницы:

1. `History`
2. `Wallet`
3. `Profile`

Что добавить:

- compact timeline;
- event filters;
- wallet status cards;
- FAQ handoff cards;
- empty/error states.

Риск низкий, но эффект вовлечения ниже, чем у Energy/Panels/Exchange.

## 5. Рекомендованный порядок

### Cycle P1 — Public Energy interactive overview

- live kWh pulse;
- available kWh visual card;
- panel count card;
- exchange hint card;
- no admin/debug data.

### Cycle P2 — Public Panels activation preview

- activation preview for `100 EFHC`;
- active/archive cards;
- countdown mobile readability;
- confirmation block before activation.

### Cycle P3 — Public Exchange interactive preview

- amount input polish;
- live preview;
- Max/reset;
- invariant text: `1 kWh = 1 EFHC`;
- no wallet/withdraw mix.

### Cycle P4 — Public Tasks/Referrals/Ranks engagement

- task reward preview;
- referral progress;
- self-card in ranks;
- filter chips.

### Cycle P5 — Public History/Profile trust layer

- timeline filters;
- wallet status;
- FAQ handoff;
- empty/error states.

## 6. Acceptance criteria

Каждый public UI interactive cycle должен иметь:

- отдельный frontend component;
- mobile-first CSS;
- no admin/debug/internal labels;
- no raw payload;
- no economic mutation beyond existing routes;
- docs/frontend canon update;
- architecture guard;
- change report;
- Operator Kernel route/cache update.

## 7. Вывод

Рекомендованный старт: `Public Energy interactive overview`, затем Panels и
Exchange. Это даст самый заметный UX-эффект без риска смешения Admin/Public.

## 8. work pass sandbox component audit update

work pass added a dedicated sandbox audit:

`docs/frontend/FRONTEND_PUBLIC_INTERACTIVITY_SANDBOX_AUDIT.md`

Additional donor archives were checked:

- TypeScript Telegram template;
- Nuxt Telegram Mini App template;
- Vanilla JS Telegram template;
- Vue Telegram template;
- Solid Telegram template.

Conclusion: EFHC should adopt Telegram Mini App UX patterns, not foreign
framework runtimes. The first implementation cycle should be
`1347 — Public Energy interactive overview`.
