<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# v171.52 GlobalHeader acceptance addendum

- Exact balance text is fully visible at 360 and 390 px.
- Whole and fractional parts may have different font size but must preserve the exact concatenated value.
- Balance value does not use ellipsis or `truncate`.
- Profile and balance top blocks start and end on the same visual line.
- Activ and VIP are always visible.
- Inactive states are gray text without container styling.
- Active Activ and VIP use the same gold text glow only.
- Four non-admin header actions remain present and evenly sized.
- No horizontal viewport overflow.
- Current proof is an isolated Chromium render; the user owns the next full GitHub run.

---


# FRONTEND SCREEN ACCEPTANCE CHECKLIST

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## Global checklist for every screen

- Opens without error.
- No white screen.
- No eternal loading.
- Dark background applied.
- Text contrast is readable.
- No horizontal scroll at 390 px.
- Main purpose visible in first screen area.
- Mandatory data is visible.
- Buttons have human labels.
- Disabled buttons explain reason if needed.
- Loading state is visible.
- Empty state is human.
- Error state is human.
- No raw route, payload, JSON or intent id.
- No raw i18n keys.
- Browser/PWA fallback works without `global_id`.
- Desktop view expands without becoming another product.

## / — Energy

- Check: на 390px виден смысл Energy без горизонтального скролла.
- Check: progress-bar виден даже при 0%.
- Check: нет технических надписей.
- Must show: generated kWh.
- Must show: available kWh.
- Must show: общий progress-bar.
- Must show: активные панели.
- Must show: base rate.
- Must show: effective generation rate.
- Must show: EFHC balance.
- Must show: действия Panels и Exchange.
- Must show: читаемый fallback без Telegram tg_id.
- Must not show: HUB / Wallet / Profile / Admin / FAQ cards без
  согласования.
- Must not show: proof/debug/runtime wording.
- Must not show: скрытие балансов.
- Must not show: скрытие ставки генерации.
- Must not show: пустой экран без global_id.

## /panels — Panels

- Check: пользователь понимает сколько стоит активация.
- Check: заблокированное действие объясняет причину.
- Must show: activation value 100 EFHC.
- Must show: active panels count.
- Must show: balance reason.
- Must show: activation button.
- Must show: active/archive switch.
- Must not show: скрывать цену активации.
- Must not show: ломать panel=100 canon.
- Must not show: возвращать global_id path dependency.
- Must not show: технический backend dump.

## /exchange — Exchange

- Check: обмен выглядит как игровое действие, не debug-form.
- Must show: available kWh.
- Must show: 1 kWh = 1 EFHC.
- Must show: exchange action.
- Must show: human result state.
- Must not show: прятать available kWh.
- Must not show: смешивать withdraw, wallet и exchange.
- Must not show: сырой backend error.
- Must not show: технические truth-layer labels.

## /tasks — Tasks

- Check: понятно что сделать и что получить.
- Check: кнопка не выглядит сломанной при блокировке.
- Check: экран выглядит как earning-модуль, а не журнал операций.
- Must show: task title.
- Must show: reward.
- Must show: compact status if useful.
- Must show: primary action.
- Must show: human blocked reason when needed.
- Must show: ad/task flow if enabled.
- Must not show: удалять earning logic.
- Must not show: скрывать reward.
- Must not show: технический disabled reason.
- Must not show: public task history/log/debug/idempotency text.
- Status v168_91 / work pass: hidden task execution log boundary completed; backend double-claim protection remains internal.
- Status v168_89 / work pass: completed for list-card boundary.

## /referrals — Referrals

- Check: активные и неактивные дороги понятны.
- Check: fallback без global_id не даёт белый экран.
- Must show: invite link/action.
- Must show: referral count.
- Must show: active/inactive.
- Must show: bonus state.
- Must not show: удалять child routes без согласования.
- Must not show: прятать referral state.
- Must not show: сырой global_id error.

## /ranks — Ranks

- Check: Ranks = leaderboard, не Energy progress.
- Check: публичная личность не техническая.
- Must show: current rank.
- Must show: top list.
- Must show: generated energy.
- Must show: human guest naming.
- Must not show: показывать 12 Energy levels как Ranks каталог.
- Must not show: browser-player label.
- Must not show: сырой rank debug.

## /web-profile — Profile / Wallet

- Check: Profile не зависает как overlay.
- Check: Wallet использует реальные компоненты и человеческие
  статусы.
- Must show: Гость EFHC fallback.
- Must show: level/status.
- Must show: Wallet state-map.
- Must show: wallet list.
- Must show: balance history.
- Must show: withdraw history.
- Must show: FAQ tab.
- Must show: language dropdown.
- Must not show: overlay profile as main surface.
- Must not show: EFHC Player final label.
- Must not show: своя оболочка.
- Must not show: browser proof.
- Must not show: PWA proof.
- Must not show: raw wallet state codes.

## /faq — FAQ

- Check: компактно помещается на смартфоне.
- Check: нет ширинного перелома и визуального перегруза.
- Must show: все разделы видны сразу.
- Must show: все подразделы видны сразу.
- Must show: vertical tree.
- Must show: long text containment.
- Must show: Profile entry.
- Must show: selected language support.
- Must not show: category pills as main model.
- Must not show: horizontal category rail.
- Must not show: heavy quick cards.
- Must not show: text overflow outside shell.

## /hub — HUB

- Check: видно только два действия.
- Check: нет технической кухни.
- Must show: Пополнить EFHC.
- Must show: EFHC VIP NFT.
- Must not show: diagnostics.
- Must not show: runtime text.
- Must not show: independent shell copy.
- Must not show: admin content.
- Must not show: proof text.
- Must not show: long descriptions.

## /browser-shop — Browser-Shop

- Check: выглядит как магазин, не как transaction console.
- Must show: product title.
- Must show: description.
- Must show: price.
- Must show: pay action.
- Must show: localized status.
- Must show: human error/loading.
- Must not show: public bottom nav.
- Must not show: raw TonConnect payload.
- Must not show: wallet/memo/copy.
- Must not show: debug.
- Must not show: raw pending/checking/done/error labels.

## /withdraw — Withdraw

- Check: withdraw не смешивается с exchange.
- Must show: main balance source.
- Must show: amount.
- Must show: wallet target.
- Must show: request status.
- Must show: human outcome.
- Must not show: bonus balance withdraw.
- Must not show: hidden final status.
- Must not show: technical tx dump in public UI.

## /ads — Ads

- Check: нет смешения user task и admin management.
- Must show: purpose.
- Must show: reward if task-linked.
- Must show: safe labels.
- Must not show: admin ad tools publicly.
- Must not show: removing earning logic silently.

## Admin checklist

### /admin

- Purpose visible: главный операторский dashboard и app launcher.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/users

- Purpose visible: пользователи, поиск, карточки и статусы.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/bank

- Purpose visible: банк, mint/burn/transfer и баланс банка.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/withdrawals

- Purpose visible: операторская обработка выводов.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/shop

- Purpose visible: управление товарами и платежами магазина.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/tasks

- Purpose visible: управление заданиями, proof-заявками и наградами.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug or route diagnostics as the main screen.
- `AdminTasksCatalogUxPanel` is visible before the detailed queue.
- Queue filter supports `PENDING / APPROVED / REJECTED / ALL`.
- Approve/reject moderation remains idempotent.
- Route is reachable from appropriate admin layer.

### /admin/reports

- Purpose visible: отчёты и release/operator evidence.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/referrals

- Purpose visible: реферальные данные и контроль.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/panels

- Purpose visible: панели и энергетические активации.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/diagnostics

- Purpose visible: диагностика, route health и proof data.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/logs

- Purpose visible: логи оператора.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/hub

- Purpose visible: служебный контур HUB.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/templates

- Purpose visible: шаблоны.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/efhc-deposits

- Purpose visible: EFHC deposits операторский модуль.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/ads

- Purpose visible: управление рекламой.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

### /admin/sale-packages

- Purpose visible: sale packages final/admin status.
- Russian operator labels.
- No public-game bottom nav.
- No raw debug as the main screen.
- Diagnostics are separated unless this is Diagnostics/Logs.
- Route is reachable from appropriate admin layer.

## Release checklist

- Route checker passed.
- TypeScript check passed where possible.
- Screenshot QA done for changed screen.
- Change report written.
- Remaining defects recorded honestly.
- ZIP is FLAT and `unzip -t` passes.

## v168_61 source-read checklist

Before a page is accepted or modified, verify:

- page description source files were read;
- the proposed element exists in those files or was approved in chat;
- no repeated question is asked for an already documented element;
- FAQ shows all sections first and expands vertically;
- HUB buttons are equal size and aligned;
- Browser-Shop product images are large enough for Web3 storefront;
- Ranks uses vertical player cards;
- Admin home is a launcher, while graphs/actions live in sections.


## v168_85 — Exchange acceptance addendum

To accept the Exchange screen after work pass, verify:

- the amount input is labelled;
- comma input is normalized for decimal entry;
- amount precision does not exceed 8 decimal places;
- Max fills the available kWh amount;
- the preview row says how much EFHC the user receives;
- an amount above available kWh is blocked with a simple user message;
- the screen still contains no withdraw, wallet, transfer or VIP blocks.
## v168_86 — Exchange History light-link acceptance addendum

To accept the Exchange screen after work pass, verify:

- the History entry is visible but visually light;
- the History entry is not a full-width heavy card;
- the link opens common account History;
- no History table, filters or rows are rendered on `/exchange`;
- Wallet, Withdraw, transfer and VIP blocks remain absent.

## v168_87 — Exchange route-contract acceptance addendum

To accept the Exchange screen after work pass, verify:

- `/exchange` has the route-contract proof marker;
- frontend uses generated Exchange seams;
- no `global_id` query/path is built on the screen;
- backend exchange routes depend on current-user context;
- no transfer, Wallet or Withdraw road is exposed from Exchange;
- sandbox donor is documented but not copied into release runtime.


## v168_90 / work pass — Tasks ads action acceptance

- `/tasks` keeps the earning-card layout from work pass.
- `Watch ad` opens the ad flow directly, without an extra pre-warning confirmation.
- The ad slot request does not append `global_id` or `user_id` to the public URL.
- User-facing error feedback is shown only when the ad action fails.
- Guard: `tests/architecture/test_tasks_ads_action.py`.


## v168_92 work pass acceptance

- Tasks contains no public task history/log/debug blocks.
- Referrals invite block has copy and share actions.
- Referrals stats/list calls use current-user backend routes.
- Referral rows do not expose global_id as visible fallback.

## v168_93 work pass update

- Referrals: visible progress/levels/achievements card and `+0.1 EFHCbb` bonus wording in rules/progress only.
- Ranks: vertical cards, username/neutral fallback only, filters exactly kWh/Referrals, Show me focused-neighbor action, no public global_id/query routes.

## v168_94 work pass — acceptance checklist

- [x] Profile shows VIP and Active status permanently, not only when active.
- [x] Inactive status is muted/grey instead of hidden.
- [x] Profile FAQ is a button to `/faq`, not an embedded mini FAQ.
- [x] Wallet tab is only wallet list/management.
- [x] Wallet errors do not expose raw payloads.
- [x] History has filters: All, Purchases, Exchange, Withdraw, Bonuses,
      Panels.
- [x] History relies on existing real endpoints and does not invent fake rows.
- [x] FAQ is a compact vertical tree without horizontal pills.
- [x] Guard added: `test_profile_wallet_history_faq.py`.


## v168_95 work pass update

- HUB: exactly two public buttons only — Top up EFHC and EFHC VIP NFT.
- HUB: VIP NFT is an external link policy, not a heavy NFT panel.
- Browser-Shop: separate Web3 shop page with large product cards.
- Browser-Shop: TON payment road remains active and human-readable.
- Browser-Shop: USDT is audited but not shown as ready in public UI.
- Admin: home starts with eight canonical sections.
- Admin: functional pages follow stats/actions/table structure.
- Admin: route map is stored in `docs/admin/ADMIN_ROUTES_MAP.md`.

## v169_21 work pass update

- [x] Admin Tasks has a sanitized execution trace boundary.
- [x] Trace uses admin logs `reason=task_bonus`.
- [x] Raw meta is not displayed on the trace panel.
- [x] Raw cursor payload is not displayed on the trace panel.
- [x] Public Tasks execution history remains forbidden.

## `/admin/reports` acceptance — work pass — Opens as a mobile-first operator dashboard;
- shows KPI cards and overview snapshot state;
- supports scope and report-window filters;
- supports zoom and clickable chart points;
- keeps reports read-only;
- does not show route diagnostics on the normal top surface.

## work pass — `/admin/reports` export acceptance

- Export controls are visible below the reports visual dashboard.
- JSON / CSV / TXT formats are selectable.
- Export scope is limited to overview, counters or facts.
- Download is disabled until an overview snapshot exists.
- No raw route diagnostics or mutation action appears on reports.

## work pass `/admin/diagnostics`

- Diagnostics screen has a technical-only boundary panel.
- Route/endpoint labels stay inside Diagnostics.
- No business mutation button is added.
- Public UI interactivity is documented as a separate plan.

## Public UI interactivity acceptance addendum — work pass

For future public interactive pages verify:

- no admin route labels;
- no diagnostics strip;
- no raw payload dump;
- no hidden task execution log;
- no backend economic change from frontend-only UI;
- Telegram haptic is optional and safe;
- MainButton is only used for clear user intent;
- reduced-motion remains respected.


## work pass — Public Energy acceptance checklist

- Energy page keeps 390px mobile proof.
- Public interactivity does not include AdminRouteHealthStrip.
- Hide-balances mode masks financial/user amounts.
- Haptic tap is optional and controlled by user settings.
- No backend economics are calculated in the component.


## work pass acceptance — Public Panels preview

- `/panels` shows the public activation preview.
- Preview shows 100 EFHC progress and balance facts.
- No Admin diagnostics or raw API payload are visible.
- Activation still uses the existing confirmation flow.


## /exchange work pass acceptance
- Public preview visible above the conversion form.
- No admin diagnostics or raw payload.
- No reverse exchange.
- Existing confirmation flow preserved.

## work pass acceptance checklist

- `/tasks` shows engagement preview without hidden execution log.
- `/referrals` shows active/total/progress preview.
- `/ranks` shows position/score/focus preview.
- No admin diagnostics are visible in public UI.
- Existing backend actions are reused.

## work pass — Web-Profile trust acceptance

- Public trust layer is visible on `/web-profile`.
- It respects `hide_balances`.
- Wallet CTA opens the Wallet tab.
- History CTA opens the History tab.
- FAQ CTA opens the FAQ tab / full FAQ handoff.
- No admin diagnostics, raw payload or hidden execution log appears.

## work pass Admin UI Kit proof acceptance

- Admin home renders `AdminUiKitAdoptionProofPanel`.
- The proof panel is Admin-only.
- It uses shared Admin UI Kit primitives.
- It documents sandbox donor-source usage.
- It does not expose public UI internals or raw backend payloads.

## work pass Admin screenshot QA acceptance

For Admin surfaces changed in work pass, acceptance requires mobile
readability, no raw payload, no public Admin internals, no Diagnostics on
business panels, and manual screenshot proof before visual release claims.
- work pass: Admin screenshot QA surfaces are cross-linked to the Admin route map.
