<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# FRONTEND VISUAL CONTRACT

Status: living control document. Internal version: v168_62.
Scope: EFHC Bot / EFHC WebApp / PWA / Telegram Mini App.

## 1. Purpose

This file is the main visual contract of the EFHC frontend shell. It
converts user phrases such as "красиво", "как референс", "большой
логотип", "всё плохо" and "нормальная оболочка" into specific UI and
UX criteria.

Frontend is not repaired by random code. Visual work starts with the
contract, shell architecture, registries, screen plan, acceptance
checklist, screenshot QA and only then code.

## 2. Source basis

- Current branch 21 instructions from chat.
- Restored chat branches 10, 13, 18, 19 and 20.
- Q&A register and chat transcript separation rule.
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`.
- `Песочница.xz` as structure donor, not brand donor.
- Dragon / Web3-Shop references as visual direction only.
- Frontend code actually present in the current HEAD.

## Page-description source hierarchy v168_62

Ancient page-description source hierarchy is the active rule here.

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.
Later corrective page-description source includes `docs/history/legacy_artifacts/docs/audits/VISIBLE_FUNCTIONS_TRIAGE_TABLE.md`, but it is not the ancient baseline source.


## 3. Product identity

EFHC is a game-like energy WebApp and PWA. It must open in Telegram
WebApp, normal browser and installed PWA. The same first screen and
same core functions must exist everywhere.

Telegram data may improve personalization, but lack of Telegram
`global_id` must never create a blank screen, empty Energy page, missing
progress bar, hidden bottom navigation or eternal loading.

## 4. General style

- Primary mood: dark Web3 energy shell with soft blue depth and EFHC
  gold or energy accents.
- The app must feel like a controlled energy simulation, not a debug
  dashboard.
- Every page has a visual center: energy, activation, exchange,
  task, referral, rank, wallet, shop or operator action.
- Every screen needs hierarchy: header, hero or console block,
  primary actions, details and secondary data.
- Decorative elements must serve meaning. Random gradients,
  excessive cards and visual noise are forbidden.

## 5. Translation of user language into UI criteria

When the user says "красиво", the criteria are composition,
hierarchy, density, readable mobile numbers, consistent cards, no
technical garbage and no hidden business functions.

When the user says "как референс", transfer composition, density,
app-grid logic, progress bars, card rhythm and action clarity. Do
not copy donor brand, routes, names or economics.

When the user says "всё плохо", treat it as a blocker diagnosis
request. Check white screen, theme, first screen, progress, visible
data, route clicks, language, contrast and technical garbage.

## 6. Color system

- Background: dark controlled surface with browser and Telegram
  fallback.
- Main surface: dark translucent card with readable border.
- Text: light primary text on dark surfaces.
- Muted text: approved muted token, never black on dark.
- Accent: EFHC gold and energy blue where they carry meaning.
- Error: visible and human, not panic-red unless destructive.
- Forbidden: hardcoded black on dark and color-only meaning.

## 7. Typography

- Hero title is short and dominant.
- Numbers must be readable on a 390 px smartphone viewport.
- Long explanation belongs in details, FAQ or admin help blocks.
- Public UI must not show raw route names, payloads, intent ids,
  internal state codes or proof wording.
- Admin UI is Russian by default and uses operator wording.

## 8. Spacing and density

- Mobile first. Main target is smartphone viewport around 390 px.
- First screen must not be inflated by decorative blocks.
- Cards are tight but breathable.
- No horizontal scroll is allowed.
- Bottom navigation needs safe-area padding and clear active state.
- Desktop is an expanded shell, not a different product.

## 9. Brand and logo

- EFHC logo / coin mark is the approved brand center.
- Large logo is correct on loading/presentation surfaces where it
  already exists by canon.
- Energy must not receive a new large logo unless chat approves it.
- Energy may use the mark, but the main object is energy/kWh.
- Admin uses brand support, while operator function is primary.

## 10. Cards

Every card has one role. A stat card shows one metric. An action
card triggers one action. A diagnostic card stays in Admin
Diagnostics. Mixing public actions and debug proof in one card is
forbidden.

Required card fields where applicable: title, primary value, short
detail, status, action area and loading/disabled state.

## 11. Buttons

- Primary: one main action per section.
- Secondary: useful but not dominant.
- Ghost: navigation or low-priority action.
- Danger: destructive operator action only.
- Disabled: visible with a human reason.
- Loading: clear progress state, not silent freeze.

## 12. Progress and status

Progress bars are used for Energy progress, rank progress, task
progress, payment checking and admin analytic indicators. A progress
bar must have visible track, visible fill and nearby number or
label.

Payment labels must be localized for all supported languages. Public
raw labels such as `pending`, `checking`, `done` and `error` are
forbidden.

## 13. FAQ contract

FAQ must be useful and compact. The complete list of sections is
visible immediately. The user opens the needed section and it
expands vertically. Answers stay inside the app frame. FAQ is not
a heavy category-pills playground. Function is more important than
decorative visual tricks.

## 14. Admin contract

Admin is a Russian operator console. The root screen starts with
large section buttons or cards. Each functional section opens as
its own page with statistics or graph at the top and functional
actions below. Diagnostics, logs, raw route proof and developer
data belong to Diagnostics, not to the visual center of Admin home.

## 15. Browser-Shop contract

Browser-Shop is a separate Web3 storefront. It must not use public
public bottom navigation. Public view shows large NFT/product images,
products, price, pay action and human payment state only. Raw
TonConnect payload, memo, wallet, debug and endpoint data are
forbidden.

## 16. Browser / Telegram / PWA parity

- Same core application everywhere.
- Installation only through system browser/PWA button unless the
  user approves another surface.
- Browser fallback shows a real interface with safe zero values.
- Telegram data is not a condition for rendering public screens.

## 17. Visual blocker definition

A visual blocker exists when the screen is white, blank, unreadable,
wider than mobile viewport, missing mandatory data, hiding actions,
showing technical text, using raw i18n keys or depending on `global_id`
to render.

## 18. Code rule

One visual cycle changes one screen or one visual layer. Before
code, record the screen purpose, mandatory elements, forbidden
elements, data, components and acceptance criteria. No mass rewrite
without proof.

## v168_61 applied user clarifications

These answers are now part of the visual contract:

- Do not invent extra Energy elements that are not in the page
  description documents.
- The existing loading logo and approved background image are enough.
  Do not introduce a new large Energy logo without a separate chat
  decision.
- FAQ shows the complete list of sections on the screen.  The user
  opens the required section and it expands vertically.  Function is
  more important than decorative design.
- Profile FAQ is a button that opens the full `/faq` page.
- Wallet page is a list of connected wallets.  Financial history is
  one common account history and opens as a separate functional page.
- Admin home is a page of buttons or section cards.  Each Admin
  functional section opens as a full page with graph/statistics at the
  top and actions below.
- Admin home does not need graphs for every module.  Graphs live on
  the relevant functional section pages.
- Browser-Shop must look like a Web3 shop with large NFT/product
  images, in the direction of the Dragon-style reference.
- Ranks uses vertical player cards.
- HUB remains two actions unless a third action is approved in chat.
  HUB buttons must be equal in size and aligned; descriptions must be
  aligned as well.


## v168_62 correction: no micro-questions over existing page canon

The operator must not ask the user about micro-elements that are already
present in the old page-description sources. The correct behaviour is:
read old page source, compare with later direct chat answer, write the
resolved screen plan, then code. Asking whether to add or move elements
that do not exist in the page description is a process failure.


## v168_64 recovered function canon

Read before changing frontend functions:
`docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md`.

Original PDF files are not retained and are not permanent canon. The MD
historical intent layer is only a comparison source. User Q/A answers are
canonical. Restore lost functions only after explicit Q/A confirmation.

## 2026-05-27 — Admin UI Kit visual contract

Admin dashboard visuals must now use the shared Admin UI Kit foundation
when a reusable operator pattern exists. The first foundation file is:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

The current first applied consumer is:

`frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`

Admin remains dark Web3/operator UI, Russian-first, mobile-readable and
interactive. Static screenshot dashboards are forbidden.



## 2026-05-27 — work pass frontend standard actualization

Target frontend standard for all future frontend work:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

Current package dependencies may still reflect the pre-migration line.
That is technical debt, not target canon. Use
`docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN.md`
for the controlled migration route.

## 2026-05-27 — work pass visual runtime standard

Visual work now runs on Tailwind CSS v4.3 and must use CSS-first theme
tokens from `frontend/src/styles/globals.css`. New visual code must not
depend on Tailwind v3-only configuration patterns.

## 2026-05-27 — work pass Tailwind config removal

Tailwind CSS v4.3 is now CSS-first only in HEAD. The active project theme
source is `frontend/src/styles/globals.css` via `@theme` and the PostCSS
adapter is `@tailwindcss/postcss`. `frontend/tailwind.config.js` has been
removed and must not be recreated for ordinary UI work.
