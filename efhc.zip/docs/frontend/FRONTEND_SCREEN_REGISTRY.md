<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Current GlobalHeader surface — v171.52

The shared header keeps a long exact balance visible at 360 px and aligns Profile and balance to the same top-row height. The exact numeric value is visually split into whole and fractional spans without changing its text. Activ and VIP are permanently visible as text: gray when inactive and identically gold-glowing when active, without pill containers. Profile, FAQ, Wallet, direct EFHC deposit and HUB behavior are unchanged.

Fresh evidence is registered in `docs/history/legacy_artifacts/reports/generated/header_component_browser_proof_v171_52.json` and the separate `EFHC_Bot_v171_52_Screenshots.zip` companion. The Profile route was not changed; its existing mobile/tablet baselines remain in the same companion archive.

---


# Current funding, Withdraw and Energy surfaces — v171.36

- Global Header `+`: direct EFHC jetton deposit only.
- HUB `Пополнение`: external Browser Shop purchase for TON/GRAM or USDT.
- `/withdraw`: React Query create, cancel, status and history surface.
- `/`: exact Energy progress and eight-decimal generation rates.
- Screenshots:
  `docs/history/legacy_artifacts/reports/screenshots/direct_deposit_withdraw_energy_1561/`.

---

# Current screen registry update — Profile and FAQ

- `/web-profile`: one profile hero, one tab navigation and one active content
  surface.
- Active tabs: Profile, Wallet, History and FAQ launcher.
- `/faq`: full vertical FAQ tree with search.
- Responsive proof: `360x800`, `390x844`, `430x932`, `768x1024`.
- Language proof: Profile and FAQ in all thirteen canonical languages.
- Historical account dashboard and public trust layer remain source-only and
  are not mounted by the route.

---

# Current Referrals and Ranks runtime — v171.33

`/referrals` uses one operational statistics, referral-link/share, Lvl
progress/scale and inline segmented Active/Inactive list surface.
`/referrals/active` and `/referrals/inactive` remain compatible paged referral
service. `/ranks` uses personal generated kWh and a vertical TOP-100 without
an Energy-level catalogue or competing dashboard.

The global header displays `EFHC` without `Total`. The balance mark is a
universal energy SVG, and the six protected bottom-navigation entries use one
consistent icon family.

---

# Current Tasks runtime — v171.32

`/tasks` renders one operational catalogue backed by `useTasksCatalog`,
`useMyTasks`, `useClaimTask`, `useBuiltinAdSlot` and
`useFinishBuiltinTimerAd`. The page has explicit loading, empty, recoverable
error, available, waiting and claimed states. `/ads` remains an alias.

The Tasks dashboard and public engagement preview are inactive legacy
components with replacement mapping. No backend execution logs or internal
idempotency data appear in the public screen.

Global public typography uses an Arial-like sans-serif stack and compact
mobile sizing. Panels and Exchange economic values are protected against
unintended two-line wrapping at 390 px.

---

# Current Panels and Exchange runtime — v171.31

## Panels

`/panels` uses one server-state model: `usePanelsList`,
`usePanelsSummary` and `usePanelActivation`. Activation is validated,
idempotent and followed by list, summary and snapshot invalidation.

## Exchange

`/exchange` uses `useExchangePreview` and `useExchangeConvert`. The visible
preview is query-owned and refetched after a successful conversion.

Both screens passed interaction proof at `390x844`. Economic values and
business rules were not changed.

---

# Current shell and Energy runtime — v171.30

All protected public routes use the same shell contract. Browser mode shows a
compact notice above the real page rather than a duplicate screen. Energy
starts from the validated snapshot, renders exact zero honestly and keeps one
contextual next action. The public browser matrix passed for twelve routes and
all thirteen canonical languages at `390x844`.

---

# Current Energy public state — v171.38

Route `/` uses `LiveEnergyHeroAndProgress` as the single active Energy
surface. It shows generated kWh, exact progress, the current canonical level
name, active panels, effective generation rate and available kWh. Wallet
balances and Exchange actions are not rendered on Energy. Loading, recoverable
error, browser preview and content states remain separate.
`EnergyMvpSummary`, `EnergyDashboardRuntime` and
`PublicEnergyInteractiveOverview` are inactive legacy references; see the
replacement mapping.

---

# FRONTEND SCREEN REGISTRY

## Complete physical route inventory — v171.88

This inventory is the active completeness layer. Detailed sections and
historical records below remain authoritative for page-specific meaning,
but no physical page may be absent from this list.

- `/` — public; канонический экран Energy.
  Source: `frontend/src/pages/index.tsx`.
  Required visual marker: `.efhc-energy-page`.
- `/app` — public; Telegram/WebApp alias канонического Energy.
  Source: `frontend/src/pages/app.tsx`.
  Required visual marker: `.efhc-energy-page`.
- `/panels` — public; активация и состояние солнечных панелей.
  Source: `frontend/src/pages/panels.tsx`.
  Required visual marker: `.efhc-panels-shell`.
- `/exchange` — public; обмен EFHC по серверному preview/convert контракту.
  Source: `frontend/src/pages/exchange.tsx`.
  Required visual marker: `.efhc-exchange-shell`.
- `/tasks` — public; каталог и выполнение пользовательских заданий.
  Source: `frontend/src/pages/tasks.tsx`.
  Required visual marker: `.efhc-tasks-shell`.
- `/ads` — public; alias пользовательского Tasks/ads-контура.
  Source: `frontend/src/pages/ads.tsx`.
  Required visual marker: `.efhc-tasks-shell`.
- `/referrals` — public; реферальная статистика, ссылка, Lvl и встроенные списки.
  Source: `frontend/src/pages/referrals.tsx`.
  Required visual marker: `.efhc-referrals-shell`.
- `/referrals/active` — public; совместимый список Active direct referrals.
  Source: `frontend/src/pages/referrals/active.tsx`.
  Required visual marker: `[data-referrals-active-inactive-boundary]`.
- `/referrals/inactive` — public; совместимый список Inactive direct referrals.
  Source: `frontend/src/pages/referrals/inactive.tsx`.
  Required visual marker: `[data-referrals-active-inactive-boundary]`.
- `/ranks` — public; личный ранг и вертикальный TOP-100.
  Source: `frontend/src/pages/ranks.tsx`.
  Required visual marker: `.efhc-ranks-shell`.
- `/web-profile` — public; профиль, Wallet, History и FAQ entry.
  Source: `frontend/src/pages/web-profile.tsx`.
  Required visual marker: `.efhc-profile-page`.
- `/faq` — public; полное вертикальное FAQ-дерево с поиском.
  Source: `frontend/src/pages/faq.tsx`.
  Required visual marker: `.efhc-faq-shell`.
- `/hub` — public; навигационный HUB без marketplace-подмены.
  Source: `frontend/src/pages/hub.tsx`.
  Required visual marker: `.efhc-hub-page`.
- `/browser-shop` — public; внешняя витрина покупки через TON/GRAM или USDT.
  Source: `frontend/src/pages/browser-shop.tsx`.
  Required visual marker: `[data-public-surface='browser-shop']`.
- `/withdraw` — public; создание, отмена, статус и история вывода.
  Source: `frontend/src/pages/withdraw.tsx`.
  Required visual marker: `.efhc-withdraw-trust-shell`.
- `/admin` — admin; главная защищённая поверхность Admin.
  Source: `frontend/src/pages/admin.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/users` — admin; операторское управление пользователями.
  Source: `frontend/src/pages/admin/users.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/bank` — admin; банковский ledger и системные балансы.
  Source: `frontend/src/pages/admin/bank.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/withdrawals` — admin; операторская очередь выводов.
  Source: `frontend/src/pages/admin/withdrawals.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/shop` — admin; управление товарами Browser Shop.
  Source: `frontend/src/pages/admin/shop.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/tasks` — admin; управление заданиями.
  Source: `frontend/src/pages/admin/tasks.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/reports` — admin; операторские отчёты.
  Source: `frontend/src/pages/admin/reports.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/referrals` — admin; реферальная аналитика Admin.
  Source: `frontend/src/pages/admin/referrals.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/panels` — admin; операторский контур панелей.
  Source: `frontend/src/pages/admin/panels.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/diagnostics` — admin; диагностика runtime и связей.
  Source: `frontend/src/pages/admin/diagnostics.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/system` — admin; системное здоровье и служебные статусы.
  Source: `frontend/src/pages/admin/system.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/logs` — admin; безопасный просмотр операторских журналов.
  Source: `frontend/src/pages/admin/logs.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/hub` — admin; управление HUB-конфигурацией.
  Source: `frontend/src/pages/admin/hub.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/templates` — admin; управление шаблонами.
  Source: `frontend/src/pages/admin/templates.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/efhc-deposits` — admin; операторский контур EFHC deposits.
  Source: `frontend/src/pages/admin/efhc-deposits.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/ads` — admin; управление рекламными слотами.
  Source: `frontend/src/pages/admin/ads.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/admin/sale-packages` — admin; управление пакетами продажи.
  Source: `frontend/src/pages/admin/sale-packages.tsx`.
  Required visual marker: `.efhc-admin-shell`.
- `/404` — system; безопасное состояние route not found.
  Source: `frontend/src/pages/404.tsx`.
  Required visual marker: `main`.
- `/500` — system; безопасное состояние server error.
  Source: `frontend/src/pages/500.tsx`.
  Required visual marker: `[data-public-surface='safe-error']`.

Status: living control document. Internal version: v168_62.

## Page-description source hierarchy v168_62

Ancient page-description source hierarchy is the active rule here.

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.
Later corrective page-description source includes `docs/history/legacy_artifacts/docs/audits/VISIBLE_FUNCTIONS_TRIAGE_TABLE.md`, but it is not the ancient baseline source.


## Registry rule

Each screen must have purpose, main visual block, mandatory
elements, forbidden elements, component set, data set and acceptance
rule before visual code starts.

## / — Energy

- Purpose: первый игровой экран энергии, kWh, прогресса и EFHC
  состояния.
- Main visual block: большой hero с kWh, прогрессом и энергетическим
  статусом.
- Mandatory elements:
  - generated kWh
  - available kWh
  - общий progress-bar
  - активные панели
  - base rate
  - effective generation rate
  - EFHC balance
  - действия Panels и Exchange
  - читаемый fallback без Telegram tg_id
  - no extra cards not listed in page-description sources
- Forbidden elements:
  - HUB / Wallet / Profile / Admin / FAQ cards без согласования
  - proof/debug/runtime wording
  - new large Energy logo without chat approval
  - secondary HUB/Profile cards not present in page description
  - скрытие балансов
  - скрытие ставки генерации
  - пустой экран без global_id
- Components:
  - `Layout`
  - `LiveEnergyBlock`
  - `EnergyGauge`
  - `GameHero`
  - `GameStatsGrid`
  - `GameStat`
  - `GameActionCard`
  - `KwhIcon`
- Data required:
  - snapshot energy
  - balances
  - panels
  - generation rates
  - browserFallback state
- Acceptance criteria:
  - на 390px виден смысл Energy без горизонтального скролла
  - progress-bar виден даже при 0%
  - нет технических надписей
- Current status: next code pass must follow existing page
  description docs; no new Energy element questions remain.


## /app — Energy Telegram alias

- Purpose: прямой Telegram/WebApp entrypoint к каноническому Energy.
- Main visual block: тот же Energy runtime, что и на `/`.
- Mandatory elements:
  - полное совпадение функций и данных с `/`
  - canonical Global Header и нижняя навигация
  - безопасная работа Telegram deep-link
- Forbidden elements:
  - отдельная альтернативная Energy-реализация
  - расхождение экономики, компонентов или визуального состояния с `/`
  - redirect-loop или пустой промежуточный экран
- Components:
  - re-export `frontend/src/pages/index.tsx`
- Data required:
  - тот же snapshot и browser fallback, что у `/`
- Acceptance criteria:
  - route-backed proof показывает тот же Energy marker
  - `/app` не имеет горизонтального overflow на 360/390/430 px
- Current status: production alias; обязательная часть полного
  route audit.

## /panels — Panels

- Purpose: активация панелей и статус солнечного контура.
- Main visual block: activation hero плюс active/archive panel
  cards.
- Mandatory elements:
  - activation value 100 EFHC
  - active panels count
  - balance reason
  - activation button
  - active/archive switch
- Forbidden elements:
  - скрывать цену активации
  - ломать panel=100 canon
  - возвращать global_id path dependency
  - технический backend dump
- Components:
  - `GamePageShell`
  - `GameHero`
  - `GameStatsGrid`
  - `PanelsList`
  - `GameDetails`
  - `Button`
- Data required:
  - panel summary
  - balance
  - active panels
  - archive
- Acceptance criteria:
  - пользователь понимает сколько стоит активация
  - заблокированное действие объясняет причину
- Current status: компактный слой есть, нужен screenshot QA.

## /exchange — Exchange

- Purpose: обмен доступных kWh в EFHC main balance.
- Main visual block: converter card с available kWh и результатом
  EFHC.
- Mandatory elements:
  - available kWh
  - 1 kWh = 1 EFHC
  - exchange action
  - human result state
- Forbidden elements:
  - прятать available kWh
  - смешивать withdraw, wallet и exchange
  - сырой backend error
  - технические truth-layer labels
- Components:
  - `GamePageShell`
  - `ExchangePanel`
  - `GameStat`
  - `GameStatusPill`
  - `Button`
- Data required:
  - exchange preview
  - available kWh
- Acceptance criteria:
  - обмен выглядит как игровое действие, не debug-form
  - main balance source понятен
- Current status: нужен следующий visual strengthening pass.

## /tasks — Tasks

- Purpose: earning-модуль заданий и наград.
- Main visual block: reward cards с понятным статусом.
- Mandatory elements:
  - task title
  - reward
  - compact status only for clarity
  - primary action
  - human blocked reason when action is unavailable
  - ad/task flow if enabled
- Forbidden elements:
  - удалять earning logic
  - скрывать reward
  - technical/debug/idempotency text in public UI
  - public task history or backend execution log
- Status v168_89 / work pass:
  - compact task-card markers are present;
  - public technical help block was removed from `/tasks`;
  - earning cards keep title/reward/status/action/help only.
- Status v168_91 / work pass:
  - public task history/log/debug/idempotency surfaces remain hidden;
  - backend double-claim protection remains internal;
  - admin/operator traces remain outside the player-facing Tasks screen.
- Components:
  - `GamePageShell`
  - `GameHero`
  - `task cards`
  - `Badge`
- Data required:
  - task catalog
  - completion state
  - reward state
- Acceptance criteria:
  - понятно что сделать и что получить
  - кнопка не выглядит сломанной при блокировке
- Current status: компактный pass был, требуется visual QA.

## /referrals — Referrals

- Purpose: приглашения, активные/неактивные рефералы и бонусы.
- Main visual block: invite/share, next-Lvl progress, Lvl scale and inline
  referral roster.
- Mandatory elements:
  - invite link, copy and Telegram/social share actions
  - active/inactive segmented tabs on the same route
  - next-Lvl progress bar
  - explicit `Lvl 0–5` threshold/reward scale
  - bonus balance and cumulative referral rewards
- Forbidden elements:
  - удалять child routes без согласования
  - прятать referral state
  - сырой global_id error
- Components:
  - `ReferralRoster`
  - compatible `ReferralListPage` child routes
  - `GameStatsGrid`
  - `GameDetails`
- Data required:
  - referral list
  - counts
  - link/code
- Acceptance criteria:
  - Active/Inactive switch without leaving `/referrals`
  - Lvl 1 shows `10 × 0.1 + 1 = 2 EFHCb` cumulative truth
  - fallback without global_id does not produce a blank screen
- Current status: child routes сохранить до отдельного решения.

## /ranks — Ranks

- Purpose: leaderboard и ранговое положение игрока.
- Main visual block: compact leader cards и current-player summary.
- Mandatory elements:
  - current rank
  - vertical player cards
  - generated energy
  - human guest naming
- Forbidden elements:
  - показывать 12 Energy levels как Ranks каталог
  - browser-player label
  - сырой rank debug
- Components:
  - `RanksTable`
  - `GamePageShell`
  - `rank cards`
  - `Badge`
- Data required:
  - rank summary
  - top list
  - fallback identity
- Acceptance criteria:
  - Ranks = leaderboard, не Energy progress
  - публичная личность не техническая
- Current status: use vertical player cards; do not ask for table
  versus cards again.

## /web-profile — Profile / Wallet

- Purpose: страница профиля, кошельков, истории и FAQ.
- Main visual block: user card + tabs Profile / Wallet / History /
  FAQ.
- Mandatory elements:
  - Гость EFHC fallback
  - level/status
  - Wallet state-map
  - wallet list
  - balance history
  - withdraw history
  - FAQ tab with button to full `/faq`
  - Wallet list of connected wallets
  - separate common financial history page/action
  - language dropdown
- Forbidden elements:
  - overlay profile as main surface
  - EFHC Player final label
  - своя оболочка
  - browser proof
  - PWA proof
  - raw wallet state codes
- Components:
  - `WebProfilePage`
  - `ProfileWalletSection`
  - `ProfileHistorySection`
  - `ProfileFaqSection`
  - `useWalletsMe`
- Data required:
  - profile
  - wallets
  - balances
  - history
  - settings
- Acceptance criteria:
  - Profile не зависает как overlay
  - Wallet использует реальные компоненты и человеческие статусы
- Current status: real-wallet слой есть, нужен финальный layout QA.

## /faq — FAQ

- Purpose: полезная компактная база знаний внутри рамки приложения.
- Main visual block: полный вертикальный список
  sections/subsections, вопросы раскрываются.
- Mandatory elements:
  - все разделы видны сразу
  - все подразделы видны сразу
  - vertical tree
  - long text containment
  - Profile entry
  - selected language support
- Forbidden elements:
  - category pills as main model
  - horizontal category rail
  - heavy quick cards
  - text overflow outside shell
- Components:
  - `FaqVerticalTree`
  - `FaqHeader`
  - `FaqSearchBar`
  - `FaqQuestionItem`
- Data required:
  - localized FAQ catalog
  - ctx.lang
- Acceptance criteria:
  - компактно помещается на смартфоне
  - нет ширинного перелома и визуального перегруза
- Current status: требуется новый compact visual QA.

## /hub — HUB

- Purpose: минимальный переходник к пополнению и VIP NFT.
- Main visual block: две понятные action cards.
- Mandatory elements:
  - Пополнить EFHC
  - EFHC VIP NFT
- Forbidden elements:
  - diagnostics
  - runtime text
  - independent shell copy
  - admin content
  - proof text
  - long descriptions
- Components:
  - `HubPage`
  - `GameActionCard`
  - `GameHero`
- Data required:
  - public labels
  - route links
- Acceptance criteria:
  - видно только два действия
  - нет технической кухни
- Current status: минимальный вид сохранён, не расширять без чата.

## /browser-shop — Browser-Shop

- Purpose: отдельная Web3-витрина и оплата.
- Main visual block: product cards + pay button + human payment
  status.
- Mandatory elements:
  - product title
  - description
  - price
  - pay action
  - localized status
  - human error/loading
- Forbidden elements:
  - public bottom nav
  - raw TonConnect payload
  - wallet/memo/copy
  - debug
  - raw pending/checking/done/error labels
- Components:
  - `ShopLayout`
  - `BrowserShopPage`
  - `GameProductCard`
  - `GameStatusPill`
  - `FrontendShellRoot`
- Data required:
  - catalog
  - bootstrap token
  - payment intent status
- Acceptance criteria:
  - выглядит как магазин, не как transaction console
- Current status: Shop shell есть, product-card polish нужен.

## /withdraw — Withdraw

- Purpose: заявка на вывод только из main balance.
- Main visual block: form/status road.
- Mandatory elements:
  - main balance source
  - amount
  - wallet target
  - request status
  - human outcome
- Forbidden elements:
  - bonus balance withdraw
  - hidden final status
  - technical tx dump in public UI
- Components:
  - `withdraw page components`
  - `status blocks`
  - `Button`
- Data required:
  - main balance
  - wallets
  - withdraw requests
- Acceptance criteria:
  - withdraw не смешивается с exchange
- Current status: позже нужен отдельный controlled visual pass.

## /ads — Ads

- Purpose: публичный рекламный/заданийный entrypoint.
- Main visual block: approved ad/task content.
- Mandatory elements:
  - purpose
  - reward if task-linked
  - safe labels
- Forbidden elements:
  - admin ad tools publicly
  - removing earning logic silently
- Components:
  - `Ads page/components`
  - `AdsBanner`
- Data required:
  - ad catalog/state
- Acceptance criteria:
  - нет смешения user task и admin management
- Current status: требуется отдельный audit later.

## Admin route registry

Admin routes are protected. They may be redesigned, grouped or
visually moved into a clearer operator hierarchy, but they must not
be deleted without direct chat approval.

### /admin

- Purpose: главный операторский dashboard и app launcher.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/users

- Purpose: пользователи, поиск, карточки и статусы.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/bank

- Purpose: банк, mint/burn/transfer и баланс банка.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/withdrawals

- Purpose: операторская обработка выводов.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/shop

- Purpose: управление товарами и платежами магазина.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/tasks

- Purpose: управление заданиями, proof-заявками и наградами.
- Shell: admin operator shell with mobile-first UI Kit catalog.
- Main component: `AdminTasksCatalogUxPanel`.
- Mandatory: task catalog deck, queue filter, moderation flow map, approve /
  reject path and Russian operator labels.
- Forbidden: route diagnostics as the primary UX, public exposure and raw debug
  as the main screen.
- Acceptance: route exists, uses the shared Admin UI Kit and keeps moderation
  actions connected without changing reward economics.

### /admin/reports

- Purpose: отчёты и release/operator evidence.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/referrals

- Purpose: реферальные данные и контроль.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/panels

- Purpose: панели и энергетические активации.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/diagnostics

- Purpose: диагностика, route health и proof data.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.


### /admin/system

- Purpose: состояние backend, database, scheduler и обязательных
  production-контуров.
- Shell: admin diagnostics shell.
- Mandatory: понятные operator labels, отдельные статусы компонентов,
  время проверки и безопасная degraded/error индикация.
- Forbidden: public exposure, секреты, raw stack traces и выдача
  неизвестного состояния за healthy.
- Acceptance: route существует, использует admin shell, не имеет
  горизонтального overflow и остаётся читаемым на 390 px.

### /admin/logs

- Purpose: логи оператора.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/hub

- Purpose: служебный контур HUB.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/templates

- Purpose: шаблоны.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/efhc-deposits

- Purpose: EFHC deposits операторский модуль.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/ads

- Purpose: управление рекламой.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.

### /admin/sale-packages

- Purpose: sale packages final/admin status.
- Shell: admin operator shell or diagnostics shell.
- Mandatory: Russian operator labels and clear section purpose.
- Forbidden: public exposure and raw debug as primary UX.
- Acceptance: route exists, has a clear role and is reachable from
  the correct admin layer.


## System error routes

### /404

- Purpose: безопасно объяснить, что route не найден.
- Mandatory: понятное сообщение и возврат к рабочему пользовательскому
  контуру.
- Forbidden: stack trace, raw Next.js error и технические
  идентификаторы.

### /500

- Purpose: безопасное fallback-состояние при ошибке страницы.
- Mandatory: понятное сообщение, возможность повторить действие или
  вернуться в приложение.
- Forbidden: stack trace, exception text, секреты и бесконечный
  reload.

## Route uncertainty rule

If a route has unclear purpose, do not delete it. First make a
route-purpose audit. Then ask in chat whether to keep it visible,
move it into Diagnostics or mark it as legacy.

## v168_61 unresolved status

No additional questions are required before the next visual code pass.
The next operator must first use the page-description source map above
and only then write a screen plan.


## v168_62 correction: old source anchors by screen

- Energy: read `UI_PAGES_ACHIEVEMENTS_RU.md`, `specification.md` and
  `ENERGY_RULES.md` before any visual decision. Later user correction
  removes unsolicited HUB/Wallet/Profile cards from Energy and forbids a
  new large Energy logo without chat approval.
- Panels: read `PANELS_SSOT.md` section 7 before changing the page.
  It fixes the description block, 2x2 actions and Active/Archive
switched
  list model.
- Exchange/Withdraw: read
  `PAGE_AUDIT_EXCHANGE_WITHDRAW_745_748_2026_04_09.md` and current
  exchange SSOT before visual changes.
- Tasks/Referrals/Ranks: read
  `PAGE_AUDIT_REFERRALS_PANELS_TASKS_RANKS_753_758_2026_04_09.md`,
  `REFERRALS_RULES.md` and `RANKS_RULES.md` before changing these pages.
- Hub/Browser-Shop/Profile: read `HUB_SSOT.md` and
  `PAGE_AUDIT_HUB_BROWSER_SHOP_PROFILE_749_752_2026_04_09.md` before
  changing entry routes or visible blocks.
- Admin: read the admin page-audit group from work pass before
  changing the operator console.


## v168_64 recovered function canon

Read before changing frontend functions:
`docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md`.

Original PDF files are not retained and are not permanent canon. The MD
historical intent layer is only a comparison source. User Q/A answers are
canonical. Restore lost functions only after explicit Q/A confirmation.


## v168_85 — Exchange screen amount polish

Route: `/exchange`.

The Exchange screen is now registered as a one-way conversion screen with
one amount input and one receive preview.  The screen must not become a
wallet, withdrawal, transfer or VIP screen.
## v168_86 — Exchange History link registry note

Route: `/exchange`.

The History entry is registered as secondary navigation only.  The
screen may open common account History through Profile/History, but it
must not render the common History table, filters or operation rows
inside Exchange.

## v168_87 — Exchange route-contract registry note

Route: `/exchange`.

The screen is registered as a current-user conversion screen. It may
call generated seams for preview and conversion, but it must not build
manual `global_id`/`user_id` routes. Transfer, Wallet and Withdraw roads are
outside this screen.


## v168_92 work pass — `/tasks`: proof pass completed.
- `/referrals`: invite block, next-Lvl progress, complete Lvl 1–5 economics and
  inline Active/Inactive segmented lists are mandatory.
- `/referrals/active` and `/referrals/inactive`: compatible username-only public
  rows.

## v168_93 work pass update

- Referrals: visible progress/Lvl 0–5 card, `+0.1 EFHCb` direct reward, one-time
  Lvl rewards and cumulative totals. Lvl 1 must show `10 × 0.1 + 1 = 2 EFHCb`.
- Ranks: vertical cards, username/neutral fallback only, filters exactly kWh/Referrals, Show me focused-neighbor action, no public global_id/query routes.

## v168_94 work pass — screen registry update

- `/web-profile` profile tab: status model proof marker
  `data-profile-status-model="always-visible-1303"`.
- `/web-profile` FAQ tab/profile card: FAQ button-only proof markers
  `data-profile-faq-button-only="1304"` and
  `data-profile-faq-entry="button-1304"`.
- `/web-profile` wallet tab: wallet-list-only proof marker
  `data-wallet-list-boundary="wallet-list-only-1305"`.
- Profile wallet component: safe error microcopy proof marker
  `data-wallet-error-microcopy="safe-1306"`.
- Profile history component: account timeline/data contract proof markers
  `data-history-account-timeline="1307"` and
  `data-history-data-contract="balance-history-withdraw-me-1308"`.
- `/faq`: compact tree/no-pills proof markers
  `data-faq-compact-tree="1309"` and
  `data-faq-no-horizontal-pills="true"`.


## v168_95 work pass update

- HUB: exactly two public buttons only — Top up EFHC and EFHC VIP NFT.
- HUB: VIP NFT is an external link policy, not a heavy NFT panel.
- Browser-Shop: separate Web3 shop page with large product cards.
- Browser-Shop: TON payment road remains active and human-readable.
- Browser-Shop: USDT is audited but not shown as ready in public UI.
- Admin: home starts with eight canonical sections.
- Admin: functional pages follow stats/actions/table structure.
- Admin: route map is stored in `docs/admin/ADMIN_ROUTES_MAP.md`.

## 2026-05-27 — Admin Home screen update

`/admin` keeps the work pass interactive banking simulator dashboard as
its active basis. work pass connects it to the shared Admin UI Kit
foundation.

Required current markers:

- `data-admin-interactive-dashboard="banking-simulator-1325"`;
- UI Kit usage from `AdminDashboardUiKit.tsx`;
- filters, chart card, KPI cards and flow map remain interactive.

## work pass — Admin Bank / Users screen update

`/admin/bank` now includes `AdminInteractiveOperatorPanel` as an interactive
operator section above the existing visual bank panel.

`/admin/users` now includes `AdminInteractiveOperatorPanel` above the table and
selected-user detail flow.

Both screens must remain operator surfaces: Russian wording, no raw payload,
no public UI mixing, sensitive actions separated from safe viewing.

## /admin/withdrawals — work pass update

Purpose: mobile-first operator decision screen for EFHC withdrawal requests.

Main visual block:

- `AdminWithdrawalsMobileDecisionPanel`.

Mandatory elements:

- status lanes: `PENDING`, `PAID`, `REJECTED`, `CANCELED`, `ERROR`;
- VIP/all filter;
- preview mode filter;
- KPI cards;
- state-machine flow map;
- mobile request deck;
- selected-case detail and outcome preview;
- TonConnect payout action;
- approve/reject fallback;
- hold/refund consistency repair.

Forbidden elements:

- route diagnostics as the top operator block;
- raw payload;
- static-only withdrawal list;
- public UI components;
- changing withdraw economics through UI.

Acceptance criteria:

- on a smartphone, operator can choose a status lane, select a request card,
  see amount/address/status and proceed to payout/approve/reject without
  reading a debug route strip.

## work pass — Admin namespace guard

All `/admin` and `/admin/*` screens are now covered by a global client-side route guard in `app.tsx`. Non-admin users must not see admin operator content on direct URL entry; they get a guarded message and redirect to `/`.


## 2026-05-27 — work pass frontend standard actualization

Target frontend standard for all future frontend work:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

Current package dependencies may still reflect the pre-migration line.
That is technical debt, not target canon. Use
`docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN.md`
for the controlled migration route.

## 2026-05-27 — work pass screen runtime update

All screens remain under the existing Pages Router surface, but the runtime
standard is now Next.js 16.2.6 / React 19.2.6 / Tailwind CSS v4.3.
Planned Shop Admin screen work shifted to work pass in work pass and then to work pass in work pass.

## 2026-05-27 — work pass Tailwind config removal

Tailwind CSS v4.3 is now CSS-first only in HEAD. The active project theme
source is `frontend/src/styles/globals.css` via `@theme` and the PostCSS
adapter is `@tailwindcss/postcss`. `frontend/tailwind.config.js` has been
removed and must not be recreated for ordinary UI work.

## 2026-05-30 — work pass Admin Tasks trace update

`/admin/tasks` now includes `AdminTasksExecutionTracePanel`.

The screen has three operator layers:

1. task catalog and queue overview;
2. sanitized task execution trace;
3. detailed moderation list.

The public `/tasks` screen remains without hidden execution history.

## `/admin/reports` — work pass

Screen owner: Admin Reports.

Current surface:

- `AdminReportsVisualDashboardPanel`;
- overview API snapshot;
- read-only operator metrics;
- mobile-first visual dashboard;
- no route diagnostics at the top of the normal screen.

## `/admin/reports` — work pass update

The screen now contains both the work pass visual dashboard and the
work pass export/download panel. Export is operator-only, sanitized and
read-only.

## `/admin/diagnostics` — work pass

`/admin/diagnostics` now starts with a technical-only boundary panel.
It may show diagnostics and route facts, but it must not mutate business state
or leak operator internals into public UI.

## Public UI interactivity wave — planned after work pass

Planned order:

1. `/` Energy interactive overview.
2. `/panels` activation preview.
3. `/exchange` interactive preview.
4. `/tasks`, `/referrals`, `/ranks` engagement layer.
5. `/web-profile`, wallet and history trust layer.


## work pass — Public Energy screen

`/` / Energy now includes `PublicEnergyInteractiveOverview` below the live
hero. The screen remains public-only and mobile-first.

Next public screen planned: `/panels` activation preview.


## `/panels` — work pass

The Panels public screen now includes `PublicPanelsActivationPreview` above
the active/archive list. It keeps the 100 EFHCb activation canon and existing
confirmation/idempotency flow.


## /exchange work pass
Public Exchange now includes PublicExchangeInteractivePreview above ExchangePanel. The canonical conversion form remains unchanged.

## work pass — Public engagement screens

Updated screens:

- `/tasks` — engagement preview before task cards;
- `/referrals` — engagement preview before invite card;
- `/ranks` — engagement preview before rank filters.

## work pass — Web-Profile public trust layer

Screen: `/web-profile`

Added `PublicProfileTrustLayer` above the existing Web-Profile tabs. The
screen remains a clean profile center: Wallet and History details still live in
their existing tabs.

## Admin home — work pass UI Kit proof

Admin home now includes `AdminUiKitAdoptionProofPanel` after the interactive
bank dashboard. The screen can show the adoption chain of the Admin Dashboard
UI Kit without turning Diagnostics or raw route data into the main surface.

## work pass Admin screen registry update

`/admin` now includes an Admin screenshot QA preparation panel. It is
Admin-only and must not be copied to public UI.
- work pass: Admin screen registry is cross-linked through `docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`.


## Admin Bank Dashboard Upgrade

`/admin/bank` now includes `AdminBankDashboardRuntime` as a read-only
Bank dashboard. The previous sandbox-style operator panel is no longer
used on the bank route. Mint/burn confirmation remains separate.

## Current HUB and Direct Deposit surface

- `/hub`: exactly two equal actions.
- Global Header `+`: opens the Direct Deposit modal.
- Direct Deposit states: amount, checking, retry and confirmed.
- Responsive proof: `360`, `390`, `430` and `768` pixel widths.
- Screenshots: `docs/history/legacy_artifacts/reports/screenshots/hub_direct_deposit_1560/`.
