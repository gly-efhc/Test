# FAQ semantic approval gate

Status: ACTIVE
Date: 2026-06-02
Archive target: current archive target
Work pass: FAQ semantic alignment continuation and approval gate

## Purpose

This document freezes the FAQ semantic gate before further TMA/TonConnect/public
release cycles. The previous v169_49 pass repaired translated FAQ tails, and
v169_50 repaired confirmed semantic drift. current archive target performs an additional gate
because the user clarified that all Q/A must be checked against the passed FAQ
iteration and SSOT before release trust is restored.

## User rule

If Russian SSOT and Russian FAQ match the approved Q/A meaning, they are the
canon. All other languages must translate from the Russian canon. SSOT can also
be a regression, so Q/A and direct user decisions must be checked before trusting
SSOT blindly.

## Documents read

- `docs/GENERAL/CURRENT_DECISIONS.md`
- `docs/SSOT/FAQ_SSOT.md`
- `docs/AI/FAQ_READING_POLICY.md`
- `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`
- `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md`
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md`
- `docs/SSOT/faq_ssot/ru/faq_ru.md`
- `docs/SSOT/faq_ssot/en/faq_en.md`
- `docs/frontend/FAQ_SEMANTIC_ALIGNMENT_REPAIR.md`
- `docs/history/legacy_artifacts/reports/generated/faq_semantic_alignment_repair_v169_50.json`
- `docs/history/legacy_artifacts/map_element.md`

## Gate findings

### Confirmed aligned after v169_50

Items 42, 45 and 162-172 were already realigned to the Russian/Q&A meaning.
The FAQ structure stayed stable: 13 languages, 20 sections, 250 Q&A.

### Residual drift found and repaired in current archive target

Two Wallet section items still had stale non-RU wording after the previous
semantic repair:

| Item | RU canon meaning | Residual issue | current archive target action |
|---|---|---|---|
| 48 / 5-7 | what to do if the user wants to use the same wallet in another account | EN/wave translations described changing the primary wallet | all non-RU languages were realigned to the RU/Q&A meaning |
| 51 / 5-10 | where to check which wallet is linked to the account | EN/wave translations described playing without a wallet | all non-RU languages were realigned to the RU/Q&A meaning |

## Semantic rule for future FAQ translation

Translations must be made from the approved Russian Q/A meaning, not from stale
English text. English remains a required language file and a public fallback
language for missing frontend keys, but English FAQ is not allowed to override
approved Russian/Q&A semantics.

## Release status

- FAQ structural parity: PASS.
- FAQ semantic approval gate for audited high-risk drift: PASS.
- Full human linguistic certification: NOT CLAIMED.
- Browser screenshot proof: NOT CLAIMED.
