# PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX

Status: ACTIVE STATIC GUARD MATRIX.

## Purpose

This document locks the public Energy, Panels and Exchange triad after the
fresh CI confirmation in v169.75. The pass does not change EFHC economics,
backend money logic, wallet logic, CI workflow or sandbox runtime. It adds a
single source-level guard matrix for the route, component, backend road and
invariant chain.

## Required reading

This guarded pass was performed after reading the active laws, cycle plan, test guard
manifest, consolidation mapping, filename policy, shell documents and
`docs/history/legacy_artifacts/map_element.md` navigation layer.

## Guard matrix

| Surface | Public route | Page | Public component | Backend road | Protected invariant |
|---|---|---|---|---|---|
| Energy | `/` | `frontend/src/pages/index.tsx` | `frontend/src/components/public/PublicEnergyInteractiveOverview.tsx` | Sync snapshot and panels-summary context | First screen links only to Panels and Exchange; no admin diagnostics; no reverse economy. |
| Panels | `/panels` | `frontend/src/pages/panels.tsx` | `frontend/src/components/public/PublicPanelsActivationPreview.tsx` | `GET /panels/active`, `GET /panels/archive`, `POST /panels/activate` | Activation is 100 EFHC, debit order is bonus first then main, POST has idempotency. |
| Exchange | `/exchange` | `frontend/src/pages/exchange.tsx` | `frontend/src/components/public/PublicExchangeInteractivePreview.tsx` | `GET /exchange/preview`, `POST /exchange/convert` | Exchange remains one-way `kWh → EFHC` at 1:1; POST has idempotency; no withdraw road mixing. |

## Static guard

Active guard:

`tests/architecture/test_public_energy_panels_exchange_guard_matrix.py`

The guard checks:

- the document and generated matrix exist;
- all three public routes are represented;
- each page imports its public component;
- public components expose no-admin data markers;
- Panels keeps activation price, debit order and idempotent POST;
- Exchange keeps generated route constants and one-way exchange wording;
- the generated matrix makes no screenshot, GitHub CI or release claim;
- no sandbox runtime import is claimed or allowed.

## Sandbox boundary

`docs/history/legacy_artifacts/map_element.md` remains a reference/navigation layer only. TelegramUI,
Mark42, Telebook and TMA template ideas may guide public card, chip, safe-area
and touch-state checks. Vue, Solid, Nuxt, Vanilla, foreign lock files, foreign
CI files and wallet/payment logic are not imported into EFHC.

## Non-claims

This pass does not claim:

- GitHub CI green beyond the supplied v169.75 log evidence;
- full local pytest green;
- browser screenshot proof;
- live Telegram client proof;
- real TonConnect or wallet transaction proof;
- release readiness.

## Next cycle

Continue to the next planned visible-functions and admin-route evidence
lane, unless the user supplies fresh failing logs first.
