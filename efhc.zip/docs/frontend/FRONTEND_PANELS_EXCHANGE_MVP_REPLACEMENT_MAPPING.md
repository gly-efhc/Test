# Panels and Exchange MVP replacement mapping

Current repair target: `v171.31`.

This mapping records which historical visual components remain in the
archive and which components are active on the protected public routes.
It prevents a historical preview or dashboard from becoming a second
competing user interface.

## Panels route

Protected route: `/panels`.

Active implementation:

- `frontend/src/pages/panels.tsx`;
- `usePanelsList` and `usePanelsSummary` for server state;
- `usePanelActivation` for the activation mutation;
- one active/archive list;
- one activation card and one activation action;
- live countdown, activation date and deactivation date;
- `panels.service.ts` and generated Zod validators.

Historical components:

- `PanelsPortfolioRuntime` — `INACTIVE_LEGACY_REFERENCE`;
- `PublicPanelsActivationPreview` —
  `DELETE_AFTER_REPLACEMENT`.

The source files are retained in v171.31 for historical evidence and
existing archive references. They are not imported by `/panels`.
Deletion requires a later archive-cleanup cycle that proves all historic
references and guards have durable replacements.

## Exchange route

Protected route: `/exchange`.

Active implementation:

- `frontend/src/pages/exchange.tsx`;
- `useExchangePreview` and `useExchangeConvert`;
- one `ExchangePanel` input and confirmation flow;
- one-way `kWh -> EFHC` conversion at `1:1`;
- one light account-history link;
- `exchange.service.ts` and generated Zod validators.

Historical components:

- `ExchangeDashboardRuntime` — `INACTIVE_LEGACY_REFERENCE`;
- `PublicExchangeInteractivePreview` —
  `DELETE_AFTER_REPLACEMENT`.

The historical source files remain available as reference artifacts but
are not imported by `/exchange`.

## Guard replacement

Historical route-integration assertions are replaced by guards that
require:

- historical components are absent from active page entries;
- exactly one active mutation surface per route;
- React Query invalidation after successful mutation;
- generated DTO validation in the service layer;
- idempotency at the frontend and backend boundaries;
- browser interaction evidence at 390 pixels;
- no change to economics, authentication, database schema or routes.

No user function is deleted. Duplicate presentation layers are removed
from routing after their functions are covered by the active page.
