# CI pytest failure repair and test visibility — v169.70

Current repair cycle did not try to hide failing tests. The uploaded logs showed a real
pytest run with `61 failed, 1063 passed, 8 skipped`.

The previous mass-skip incident is not present in this log. Current work is
normal repair of failing invariants by domain.

## Visibility answer

A CI summary should always expose:

- collect-only count;
- executed passed/failed/skipped count;
- first failing files;
- whether any tests are deselected or skipped by environment flags.

Changing CI workflow requires direct user permission. Until permission is given,
this document records the desired visibility policy without editing CI jobs.
