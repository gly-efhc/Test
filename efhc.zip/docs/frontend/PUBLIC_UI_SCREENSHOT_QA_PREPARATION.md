# PUBLIC_UI_SCREENSHOT_QA_PREPARATION

Status: READY FOR SCREENSHOT CAPTURE
Version: v169_39

## Purpose

This document starts the public UI screenshot QA preparation line after the
Admin route-map, regression proof, recovery checkpoint and audit-fixes passes.

It prepares a manual and automated checklist for public EFHC Bot surfaces. It
does not claim that screenshots were captured or that browser E2E passed in
GitHub CI.

## Required reading

1. `docs/frontend/FRONTEND_VISUAL_CONTRACT.md`
2. `docs/frontend/FRONTEND_SHELL_ARCHITECTURE.md`
3. `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`
4. `docs/frontend/FRONTEND_COMPONENT_REGISTRY.md`
5. `docs/frontend/FRONTEND_VISUAL_ELEMENTS_REGISTRY.md`
6. `docs/frontend/FRONTEND_DO_NOT_TOUCH.md`
7. `docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md`
8. `docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md`
9. `docs/frontend/FRONTEND_REFERENCE_INTERPRETATION.md`
10. `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
11. `docs/history/legacy_artifacts/map_element.md`
12. `docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md`

## Public surfaces under screenshot QA

| Surface | Route | Primary file | QA focus | Sandbox pattern class |
|---|---|---|---|---|
| Energy | `/` | `frontend/src/pages/index.tsx` | first-screen clarity, kWh state, no admin/debug leak | Telegram cards, progress, skeletons |
| Panels | `/panels` | `frontend/src/pages/panels.tsx` | active/archive tabs, activation affordance, no black-on-dark | tabs, sections, fixed actions |
| Exchange | `/exchange` | `frontend/src/pages/exchange.tsx` | kWh -> EFHC only, preview clarity, convert CTA | input, amount preview, warning card |
| Tasks | `/tasks` | `frontend/src/pages/tasks.tsx` | earning cards, ad modal, no execution trace leak | list cards, badges, modal |
| Referrals | `/referrals` | `frontend/src/pages/referrals.tsx` | invite link, copy/share, active/inactive clarity | share buttons, cells, badges |
| Active referrals | `/referrals/active` | `frontend/src/pages/referrals/active.tsx` | active rows, username-only public data, no private identifiers | filtered lists, badges |
| Inactive referrals | `/referrals/inactive` | `frontend/src/pages/referrals/inactive.tsx` | inactive rows, username-only public data, no private identifiers | filtered lists, badges |
| Ranks | `/ranks` | `frontend/src/pages/ranks.tsx` | vertical ranking cards, filters, show-me affordance | list, avatar, progress |
| Profile / Wallet / History | `/web-profile` | `frontend/src/pages/web-profile.tsx` | wallet cards, history filters, no raw payload dumps | wallet provider, activity list |
| FAQ | `/faq` | `frontend/src/pages/faq.tsx` | tree navigation, search, localized empty state | accordion, search, sections |
| HUB | `/hub` | `frontend/src/pages/hub.tsx` | only approved two actions, no diagnostics | action cards, wallet handoff |
| Browser Shop | `/browser-shop` | `frontend/src/pages/browser-shop.tsx` | no bottom menu, clean product cards, no memo/payload diagnostics | shop cards, order state |
| Withdraw | `/withdraw` | `frontend/src/pages/withdraw.tsx` | form clarity, connected wallet state, no raw error, no double-submit ambiguity | form, status cards, confirmation |
| Ads | `/ads` | `frontend/src/pages/ads.tsx` | ad action clarity, no execution trace leak, reward state readability | task/ad cards, modal |


## v169_39 residual audit additions

The v169_39 pass incorporated the residual audit feedback after the v169_37 implementation review:

- `common.session_expired` and `common.load_error` are now required in all 13 locale JSON files;
- E2E interaction smokes must verify actual POST calls for Exchange, HUB deposit handoff and Withdraw request;
- public smoke scope includes `/withdraw`, `/ads`, `/referrals/active` and `/referrals/inactive`;
- admin smoke scope includes `/admin/sale-packages`, `/admin/efhc-deposits`, `/admin/hub`, `/admin/referrals`, `/admin/templates` and `/admin/ads`;
- `offline.html` uses a multilingual fallback line so the PWA offline state remains understandable outside Russian.

## Device / shell matrix

| Mode | Target | Acceptance |
|---|---|---|
| Mobile Telegram-like | 390px width | no horizontal overflow, bottom safe-area correct, TMA back-button assumptions intact |
| Mobile browser/PWA | 390px width | no blank screen, offline fallback available, install shell does not hide content |
| Desktop browser | 1280px width | content remains centered, readable, not stretched into debug grid |
| Dark default | EFHC dark canon | no black text on dark, no white holes, no raw unstyled controls |
| Light mode | supported fallback | text contrast remains readable, cards and buttons keep hierarchy |

## Screenshot checklist per surface

Each surface must be checked for:

- visible non-empty page body;
- no white blank blocks;
- no black text on dark backgrounds;
- no admin navigation or diagnostics;
- no endpoint/raw payload/operator internals;
- no public bottom nav on browser shop special shell if the page has its own shop shell;
- human-readable loading, empty and error states;
- main CTA visible without technical payloads;
- route/component/backend/SSOT connection documented before claiming proof.

## Sandbox guidance

Use sandbox material only as visual and UX reference:

- TelegramUI / Mark42 for cells, cards, section rows, tappable states and skeletons;
- Telebook and telegram-web-app-shop for product/card/order layout ideas;
- TypeScript / Vanilla templates for low-level Telegram Mini App init and TonConnect UX assumptions;
- Nuxt Telegram Mini App for component/test naming ideas;
- MaterialM for dashboard-like cards only where public screen hierarchy benefits.

Do not import sandbox runtime code, framework code, CI files, lock files or
wallet transaction logic into EFHC.

## Output expected from the next proof pass

The next proof pass should create a public regression matrix:

`public page -> components -> backend roads -> SSOT/NORM anchor -> guard -> visual verdict`

The current document is the preparation layer only. v169_39 closes the preparation scope and makes the next pass screenshot-capture ready; no actual screenshot verdict is claimed by this document.


## v169_40 proof-pass handoff

The public regression proof pass created `docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md` as the
static proof layer for the 14 public routes in this preparation document. The
proof connects pages to components, backend roads, SSOT/NORM anchors and guards.
It still does not claim actual screenshot capture or live browser Playwright
execution.
