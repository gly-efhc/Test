# FRONTEND SCREENSHOT QA PROTOCOL

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## 1. Purpose

Visual repair is not complete by code alone. Important screens need
screenshot proof before claiming visual readiness.

## 2. Required screenshots

- Before screenshot when possible.
- After screenshot.
- Mobile viewport around 390 px width.
- Desktop/browser viewport.
- Telegram-like narrow viewport if available.
- Error/empty/loading state when changed.

## 3. Required diagnosis before code

- What screen is selected.
- What user sees now.
- What is visually broken.
- Which mandatory data is missing or hidden.
- Which elements are technical garbage.
- Which actions are confusing or unapproved.
- Which shell should own the screen.

## 4. Required comparison after code

Compare against:

- `FRONTEND_VISUAL_CONTRACT.md`;
- `FRONTEND_SCREEN_REGISTRY.md`;
- `FRONTEND_COMPONENT_REGISTRY.md`;
- `FRONTEND_DO_NOT_TOUCH.md`;
- user approvals from chat.

## 5. Mobile checks

- No horizontal scroll.
- No text cut outside frame.
- Main button is reachable.
- Bottom nav safe-area is not covering content.
- Hero does not consume the whole page without data.
- FAQ text wraps inside frame.

## 6. Desktop checks

- App remains same product.
- Content is centered or framed.
- No over-wide text lines.
- Shop and Admin use their own shells.

## 7. Pass / fail criteria

Pass is allowed only if the changed screen is readable, all
mandatory elements remain visible, forbidden elements are absent and
route clicks work.

Fail must record exact defects. Never call a screen ready if a
visible defect remains.

## 8. Screenshot storage

Screenshots, when produced, should be stored in reports or audits
with route, viewport, date and cycle. They are proof artifacts, not
UI source.

## 9. Current status

As of v168_60, screenshot QA is still not proven for the full
frontend. Future visual code passes must include screenshot proof
where tooling permits it.

## v168_61 screenshot source comparison

Screenshot QA must compare the screen not only with visual taste, but
with the page-description sources.  The screenshot note must answer:

- which source document was used;
- which mandatory elements are visible;
- which forbidden elements are absent;
- whether the screen follows the latest user answers from chat;
- whether any new element was added without approval.

## work pass Admin screenshot QA preparation

Admin screenshot QA is now prepared through
`AdminScreenshotQaPreparationPanel` on Admin home. The panel lists the
minimum Admin screenshots: mobile 390 px, Telegram-like narrow viewport,
desktop viewport and empty/error/decision states. This is preparation, not
a claim that screenshots have already been captured.

## v171.88 complete route-backed visual gate

The required inventory is
`ops/frontend/all_pages_visual_manifest_v171_88.json`.

The canonical pass must use a real running Next.js application and
`page.goto()`. `page.set_content()` and synthetic HTML are forbidden as
visual evidence.

Coverage:

- every public and protected Admin route at 360 x 800, 390 x 844
  and 430 x 932;
- safe `/404` and `/500` states.

For every route record HTTP status, root marker, page errors, filtered
console errors, horizontal overflow, splash state, body length and a
fresh full-page screenshot. A route is not visually verified when the
frontend build or real server cannot be started.


## v171.88 GitHub execution boundary

The full route-backed Chromium cycle runs in
`.github/workflows/frontend-visual.yml`. It is automatic but
non-blocking under the existing rule that PNG evidence must not be a
blocking Canon CI input. The blocking `.github/workflows/canon.yml`
continues to verify source, tests, PostgreSQL integration and the exact
frontend build without storing `docs/history/legacy_artifacts/reports/screenshots`.
