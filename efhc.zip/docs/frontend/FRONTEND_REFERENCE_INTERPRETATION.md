# FRONTEND REFERENCE INTERPRETATION

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## 1. Main rule

References are visual donors, not product replacements. EFHC keeps
its brand, routes, economics, terminology and user flow.

## 2. Current reference sources

- `Песочница.xz` decoded as XZ/TAR donor.
- Dragon reference from restored branch 19 and user files.
- Web3-Shop reference from restored branch 19 and user files.
- Screenshots and live user complaints from branches 19 and 20.

RAR donors were not always fully extractable in the environment.
When code is not fully readable, only visible structure, asset list
and user-approved principles may be used.

## 3. What may be transferred

- Composition.
- Density.
- App-grid logic.
- Large app buttons.
- Dark game shell.
- Compact cards.
- Progress bars.
- Strong action hierarchy.
- Separate storefront shell.
- Admin KPI and chart rhythm.
- Browser/PWA shell idea.

## 4. What must not be transferred

- Donor brand.
- Donor routes.
- Donor logos.
- Donor product promises.
- Donor economics.
- Unrelated functions.
- Decorative tricks without EFHC meaning.
- Any element that hides EFHC balances, panels or kWh.

## 5. Dragon-style interpretation

Dragon-style means compact game application logic: few first-level
buttons, strong visual center, secondary data after click, progress
feedback, browser/PWA opening and visual confidence.

It does not mean deleting EFHC canonical pages or changing bottom
navigation. EFHC still keeps Energy, Panels, Exchange, Tasks,
Referrals and Ranks.

## 6. Web3-Shop interpretation

Web3-Shop reference means separate storefront, product cards, pay
button, human payment status and no technical payment kitchen in
public.

## 7. Admin reference rule

For Admin, reference means operator console: big section tiles, KPI
cards, graphs, clear Russian actions and diagnostics separated from
the main dashboard.

## 8. FAQ reference rule

FAQ is not a reference playground. The approved model is compact
vertical tree with full section/subsection list visible immediately.

## 9. Reference audit output

Every reference pass must produce:

- what we transfer;
- what we do not transfer;
- which EFHC screen is affected;
- which mandatory data stays visible;
- what requires chat approval.

## v168_61 Dragon / Web3 interpretation

For Browser-Shop, the Dragon/Web3 reference means large NFT/product
cards and a clear Pay action.  It does not mean copying the donor brand
or routes.

For Admin, the reference means clear app-style section buttons and a
separate functional page for each module.  Graphs and actions belong to
those module pages, not all to the Admin home.

For public game pages, the reference means compact controlled layout,
progress bars and clear actions, while preserving the EFHC page canon.
