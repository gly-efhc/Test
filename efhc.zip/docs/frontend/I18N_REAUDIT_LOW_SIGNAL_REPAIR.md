# I18N reaudit low-signal repair — v169.83 / repair pass

Status: DONE.
Base HEAD: `v169_82 / repair pass range closure and CI ruff repair`.
Audit source: `docs/history/legacy_artifacts/docs/audits/I18N_REAUDIT_REPORT_V169_82_2026_06_03.md`.

## Purpose

The repeat i18n audit for v169.82 found that the public translation debt is
closed in practice and that the remaining findings are LOW false positives:

1. `faq.title = "FAQ"` is an intentional international acronym.
2. `backend/app/services/panels_service.py` contains a Russian canonical
   service comment: `Цена панели фиксирована: 100 EFHC`.
3. Wave-3 locale quality scripts were not reading the shared identical-value
   allowlist, so they repeated 5-9 allowlist false positives per language.

This pass repairs those false-positive channels only. It does not change player
copy, EFHC economics, runtime framework, Telegram shell behavior, wallet logic,
admin/public boundaries or CI workflow.

## Repairs

### O1 — `FAQ` allowlist

`FAQ` was added to `ops/i18n/identical_to_english_allowlist.json` as an exact
allowed value. This keeps `faq.title = "FAQ"` valid for languages that use the
international acronym. Turkish may still use `SSS`.

### O2 — panels-service comment false positive

`ops/i18n/audit_forbidden_gambling_chance_contour.py` now treats the exact
canonical comment wording `Цена панели фиксирована` as a false positive.

The forbidden guard still blocks prohibited chance-contour
financial-win wording. The normal word `game / игра` remains allowed when it is
not gambling/loto/betting/chance-financial-win semantics.

### O3 — shared allowlist for locale quality scripts

Added:

- `ops/i18n/locale_quality_allowlist.py`

Updated wave-3 quality scripts so intentional identical values are checked
through the shared allowlist:

- `ops/i18n/audit_da_locale_value_quality.py`
- `ops/i18n/audit_de_locale_value_quality.py`
- `ops/i18n/audit_es_locale_value_quality.py`
- `ops/i18n/audit_fr_locale_value_quality.py`
- `ops/i18n/audit_hi_locale_value_quality.py`
- `ops/i18n/audit_id_locale_value_quality.py`
- `ops/i18n/audit_it_locale_value_quality.py`
- `ops/i18n/audit_pl_locale_value_quality.py`
- `ops/i18n/audit_sw_locale_value_quality.py`
- `ops/i18n/audit_tr_locale_value_quality.py`

The RU and UK quality scripts already had allowlist logic and were preserved.

## Guard

Added active architecture guard:

- `tests/architecture/test_i18n_reaudit_low_signal_repair.py`

The guard checks:

- the v169.82 reaudit source is archived;
- `FAQ`, `h`, `d`, `m`, `s` and `1 kWh = 1 EFHC` are allowed exact values;
- wave-3 quality scripts import and use the shared allowlist helper;
- the gambling/chance contour keeps the panels-service comment as an explicit
  false positive;
- the generated repair evidence preserves non-claims.

## Verification

Confirmed locally:

- `python3 -m py_compile` for the new helper, the forbidden contour and all
  locale quality scripts;
- all 12 locale value-quality scripts pass;
- `python3 ops/i18n/audit_forbidden_gambling_chance_contour.py` returns
  `forbidden_findings: 0`;
- targeted architecture tests for fallback, critical i18n repair, reaudit,
  manual coverage, browser text-stress readiness, public untranslated
  remediation and game-vs-gambling wording pass when run individually.

Not claimed:

- no GitHub CI green for v169.83;
- no full local pytest green;
- no full frontend build;
- no browser screenshots;
- no live Telegram client proof;
- no real TonConnect or wallet proof;
- no release-ready verdict.
