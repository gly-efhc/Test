# FRONTEND ENERGY MVP REPLACEMENT MAPPING

Status: `ACTIVE_REPLACEMENT_MAPPING`
Route: `/`
Current version: `v171.38`

## Product decision source

The active Energy page is an Energy status surface, not Wallet and not
Exchange. It must show generated kWh, exact progress, the current canonical
level name, active panels, generation rate and available kWh.

## Replacement matrix

| Existing element | Current decision | Active replacement | Reason |
|---|---|---|---|
| `LiveEnergyHeroAndProgress` | `KEEP_REPAIR` | same component in `pages/index.tsx` | Single coherent Energy status and progress surface. |
| `EnergyMvpSummary` | `INACTIVE_LEGACY_REFERENCE` | `LiveEnergyHeroAndProgress` | Duplicated Wallet balances and Panels/Exchange actions on Energy. |
| `EnergyDashboardRuntime` | `INACTIVE_LEGACY_REFERENCE` | `LiveEnergyHeroAndProgress` | Technical dashboard duplicated Energy truth. |
| `PublicEnergyInteractiveOverview` | `DELETE_AFTER_REPLACEMENT` | `LiveEnergyHeroAndProgress` | Duplicated Energy, Panels and Exchange navigation. |
| hidden level identity | `REPAIR` | `USER_LEVEL_SKINS` + current level line | The canonical current level name must remain visible below progress. |
| manual snapshot type in `useSnapshot` | `REBUILD` | `snapshot.service.ts` Zod DTO + service | Preserves transport → DTO → service → React Query. |

## Deletion gate

Legacy components may be deleted only after historical references and guards
are migrated or explicitly frozen. A visual cleanup may not delete a guarded
product function without a direct user decision.

## Protected invariants

- `1 EFHC = 1 kWh` unchanged.
- Wallet balances belong to Wallet/global header, not Energy cards.
- Exchange actions belong to Exchange, not Energy.
- Current canonical level name remains visible.
- Panel price and debit order unchanged.
- Backend sync endpoint unchanged.
- Database schema and Alembic canon unchanged.
- Protected bottom navigation order unchanged.
- Browser preview remains available without Telegram identity.
