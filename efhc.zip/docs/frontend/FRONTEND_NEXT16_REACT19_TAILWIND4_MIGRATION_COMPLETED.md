# FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_COMPLETED

Version: v169_10 / work pass
Date: 2026-05-27
Status: completed migration record

## Decision

The user ordered a dedicated migration-cycle before returning to the admin
cycle plan. work pass is therefore assigned to the real frontend
runtime migration.

## Implemented runtime standard

- Next.js 16.2.6;
- React 19.2.6;
- React DOM 19.2.6;
- Tailwind CSS v4.3;
- `@tailwindcss/postcss` v4.3.

## Files changed

- `frontend/package.json`;
- `frontend/package-lock.json`;
- `frontend/postcss.config.js`;
- `frontend/src/styles/globals.css`;
- `frontend/tailwind.config.js` was temporarily touched in work pass and
  removed in work pass.
- `frontend/tsconfig.json`.

## Tailwind v4 change

The frontend now uses Tailwind CSS v4 CSS-first configuration:

- old directives `@tailwind base/components/utilities` are removed;
- global CSS starts from `@import "tailwindcss"`;
- EFHC theme tokens are declared through `@theme`;
- `tailwind.config.js` was temporarily retained in work pass, then
  removed in work pass after explicit user approval.

## Scripts

- `dev` now uses `next dev --turbo`;
- `typecheck` runs `tsc --noEmit`;
- `lint` runs `npm run typecheck` because `next lint` is no longer a
  valid script target for this migrated project.

## Verification

Verified locally:

- `npm ci --no-audit --no-fund --progress=false`;
- `npm run typecheck`;
- `npm run lint`;
- `npx tsc --noEmit`;
- `npm run build` reached successful compile on Next.js 16.2.6, then local page-data collection did not complete in this environment
  (`EPIPE`/timeout observed during repeated local attempts).

The `EPIPE` stage is treated as a local environment limitation until CI
confirms or rejects it.

## Cycle plan remap

work pass is now:

`Frontend dependency migration to Next.js 16.2.6 / React 19.2.6 /
Tailwind CSS v4.3`.

The planned Shop Admin cycle shifted to 1332 in work pass and then to 1333 in work pass.

## Superseding cleanup in work pass

work pass removes the temporary legacy marker file
`frontend/tailwind.config.js`. This does not roll back the migration; it
completes the Tailwind v4 CSS-first cleanup. The active theme remains in
`frontend/src/styles/globals.css` via `@theme`.
