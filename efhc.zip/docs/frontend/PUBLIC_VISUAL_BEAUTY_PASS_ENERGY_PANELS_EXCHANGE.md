# PUBLIC_VISUAL_BEAUTY_PASS_ENERGY_PANELS_EXCHANGE

Status: STATIC VISUAL POLISH APPLIED.
Scope: public Energy, Panels and Exchange surfaces.

## Boundary

NO SCREENSHOTS CLAIMED. This pass changes source-level visual hierarchy and
adds guards. It does not claim browser screenshot evidence, live Playwright
execution, GitHub CI green or final release readiness.

## Purpose

The public Energy, Panels and Exchange pages already had static regression
proof and screenshot-harness preparation. This pass improves the human visual
layer before real screenshot capture:

- clearer card hierarchy;
- compact visual rail for touch orientation;
- stronger active-state feedback;
- better keyboard focus visibility;
- mobile readability at 390px;
- reduced-motion safety for animated pulse.

## Sandbox intake

`docs/history/legacy_artifacts/map_element.md` and sandbox archives were used as reference navigation only.
Approved reference families:

- TelegramUI / Mark42: chips, cells, card hierarchy and active-state rhythm;
- Telebook: compact sections and safe mobile spacing;
- TypeScript / Vanilla TMA templates: viewport/safe-area assumptions;
- Nuxt Telegram Mini App: test-organization ideas only.

No Vue, Solid, Nuxt, Vanilla, foreign lock files, foreign CI files or wallet
transaction logic were imported into EFHC Bot.

## Code changes

| Surface | Files | Visual change | Boundary |
|---|---|---|---|
| Energy | `frontend/src/components/public/PublicEnergyInteractiveOverview.tsx`, `frontend/src/styles/globals.css` | active-state class, visual rail, chips, focus polish, motion guard | public-only; no admin imports |
| Panels | `frontend/src/components/public/PublicPanelsActivationPreview.tsx`, `frontend/src/styles/globals.css` | ready/locked state class, visual rail, chips, disabled CTA readability | public-only; no economic change |
| Exchange | `frontend/src/components/public/PublicExchangeInteractivePreview.tsx`, `frontend/src/styles/globals.css` | ready/loading/focus state class, visual rail, chips, CTA depth | public-only; kWh to EFHC only |

## Economic invariants preserved

- `1 EFHC = 1 kWh` unchanged.
- Panel activation price remains `100 EFHC`.
- Exchange direction remains `kWh → EFHC` only.
- No backend route, bank ledger, exchange service, panel service or wallet
  transaction behavior was changed.

## Acceptance criteria

- Energy, Panels and Exchange public components expose
  `data-public-visual-beauty="energy-panels-exchange"`.
- Each component has a visual rail and active visual chips.
- `globals.css` contains shared chip, focus, mobile and reduced-motion rules.
- Components do not import admin code.
- Generated manifest states `STATIC_VISUAL_POLISH_NO_SCREENSHOT_CLAIM`.

## Next step

Proceed to the next public visual pass for Tasks, Referrals and Ranks. Real
browser screenshots remain a separate evidence action controlled by the
screenshot harness.
