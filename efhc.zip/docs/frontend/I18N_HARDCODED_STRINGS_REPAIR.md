# I18N hardcoded strings repair — v169.84

repair pass  
Status: DONE

## Purpose

Repair the v169.83 hardcoded-string audit/TZ findings on public and shared UI
surfaces without changing EFHC economics, route boundaries, runtime framework,
wallet/TonConnect behavior or CI workflows.

## Repair model

- Class-based `ErrorBoundary` receives an optional translator prop instead of
  using hooks.
- Hook-compatible components use `useT()`.
- `_app.tsx` creates a `tFromDicts` translator and passes it into the two
  app-level error boundaries and the public admin-route guard state.
- `SurfaceFactsStrip` no longer has a user-visible English default; all current
  call sites already pass `title`.
- Optional accessibility texts were localized when the change was low risk.

## Required i18n keys added to every locale

```text
ads.title
ads.no_campaigns_title
ads.no_campaigns_detail
ads.open_tasks
admin_guard.checking_title
admin_guard.blocked_title
admin_guard.checking_text
admin_guard.blocked_text
energy.gauge_title
energy.total_label
common.something_went_wrong
common.unexpected_error
common.reload
common.image_placeholder
common.close
```

## Optional keys added to every locale

```text
common.details
common.efhc_balance_aria
common.avatar_alt
```

## Intentionally not added

`common.page_overview` was not added because the source default was removed.
The component now requires callers to pass a title.

## Still documented as exceptions

- `EFHC Storefront` and `EFHC Mini App`: app-level branded crash-boundary
  titles.
- `0.00000000`: numeric precision placeholder.
- `USDT runtime *`: internal status labels.
- EFHC brand spans/badges.
