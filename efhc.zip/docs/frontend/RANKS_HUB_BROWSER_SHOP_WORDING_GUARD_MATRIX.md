# RANKS_HUB_BROWSER_SHOP_WORDING_GUARD_MATRIX

Status: active static wording guard matrix for the current wording pass.

## Purpose

This document locks the planned wording pass for Ranks, Hub and
Browser-Shop. It does not change runtime UI, backend economics, wallet logic,
CI workflows or sandbox runtime. It records a source-level guard over wording
boundaries that were already present in active pages.

## User correction in this pass

The user clarified that the word `game` is not banned. EFHC Bot may be called
a game, game bot or game project when the wording describes ordinary product
play, progress, panels, tasks, referrals, ranks or account development.

The active ban is limited to gambling, loto, betting, tournament-like
financial contests and random financial reward meaning. Therefore this pass
removes the false idea that the ordinary word `game` is a forbidden token.

## Guard matrix

| Surface | Public route | Active file | Wording invariant | Active guard |
|---|---|---|---|---|
| Ranks | `/ranks` | `frontend/src/pages/ranks.tsx` | Public module name stays Ranks; old rank-name module terms stay blocked. Game wording is allowed if it is ordinary progress language. | `tests/architecture/test_no_banned_rank_terms.py`; `tests/architecture/test_game_word_boundary_and_wording.py` |
| Hub | `/hub` | `frontend/src/features/hub/HubPage.tsx` | Hub remains a short bridge with two user actions: top up EFHC and open VIP collection. Diagnostics and operator wording stay out of public Hub. | `tests/architecture/test_hub_public_cleanup_guard.py`; `tests/architecture/test_game_word_boundary_and_wording.py` |
| Browser-Shop | `/browser-shop` | `frontend/src/features/browser-shop/BrowserShopPage.tsx` | Browser-Shop remains a clean storefront handoff. Raw wallet, memo, SKU and diagnostics stay hidden from public UI. | `tests/architecture/test_browser_shop_public_cleanup_guard.py`; `tests/architecture/test_game_word_boundary_and_wording.py` |

## Sandbox boundary

The supplied sandbox and extra Telegram Mini App templates remain reference
and navigation sources only. They may guide card, storefront, shell and touch
state thinking, but no Vue, Solid, Nuxt, Vanilla, foreign lock file, CI file,
wallet/payment logic or translation source is imported.

## Non-claims

This pass does not claim GitHub CI green, full local pytest green, npm build,
browser screenshots, live Telegram proof, real TonConnect proof or release
readiness.
