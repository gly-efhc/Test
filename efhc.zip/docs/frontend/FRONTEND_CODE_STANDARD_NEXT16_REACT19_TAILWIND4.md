# FRONTEND_CODE_STANDARD_NEXT16_REACT19_TAILWIND4

Version: v169_11 / work pass
Date: 2026-05-27
Status: active implemented frontend runtime standard; Tailwind config removed

## Canon

EFHC Bot frontend runtime standard is now implemented as:

- Next.js 16.2.6;
- React 19.2.6;
- React DOM 19.2.6;
- Tailwind CSS v4.3;
- Tailwind CSS v4 PostCSS adapter `@tailwindcss/postcss` v4.3;
- CSS-first Tailwind theme via `@theme` in
  `frontend/src/styles/globals.css`.

This standard is mandatory for future frontend architecture, AI documents,
canon documents, visual work and migration planning.

## Current HEAD fact

As of work pass, `frontend/package.json` and
`frontend/package-lock.json` are migrated to the target dependency line.
The old Next.js 14 / React 18 / Tailwind CSS 3 dependency line is no
longer the active runtime standard.

## Migration status

Completed in work pass:

1. `next` updated to `16.2.6`;
2. `react` updated to `19.2.6`;
3. `react-dom` updated to `19.2.6`;
4. `tailwindcss` updated to `4.3.0`;
5. `@tailwindcss/postcss` added at `4.3.0`;
6. React type packages updated to React 19 line;
7. `postcss.config.js` switched to the Tailwind v4 adapter;
8. `globals.css` switched from old `@tailwind` directives to
   `@import "tailwindcss"` and `@theme`;
9. `tailwind.config.js` explicitly removed in work pass;
10. dev script changed to `next dev --turbo`;
11. `next lint` removed from scripts because it is not a valid Next 16
    script path in this project; `lint` now runs the TypeScript sanity
    check through `npm run typecheck`.

## Rule for new code

New frontend code must target the implemented runtime stack above. Any
future references to Next.js 14, React 18 or Tailwind CSS 3 must be framed
only as historical state before work pass.

## Follow-up rule

The admin cycle plan resumes after this migration-cycle. Planned Shop Admin
work moves to work pass.

## work pass update — no Tailwind config file

The user explicitly approved and ordered deletion of the unnecessary
`frontend/tailwind.config.js` file after the Tailwind v4 migration.

Current rule:

- Tailwind CSS v4 is configured through CSS-first `@theme` only.
- `frontend/src/styles/globals.css` is the active EFHC theme source.
- `frontend/postcss.config.js` uses `@tailwindcss/postcss`.
- `frontend/tailwind.config.js` must not exist in HEAD.
- New UI work must not recreate Tailwind v3-style config drift.

## work pass update — public npm lockfile registry

work pass keeps the implemented frontend runtime standard unchanged:
Next.js 16.2.6, React 19.2.6 and Tailwind CSS v4.3 remain active.

The frontend lockfile must now also satisfy the CI registry hygiene rule:
`frontend/package-lock.json` must not contain internal registry markers
such as `applied-caas-gateway`, `internal.api.openai` or `artifactory`.
Package `resolved` URLs must be portable for normal CI execution.
