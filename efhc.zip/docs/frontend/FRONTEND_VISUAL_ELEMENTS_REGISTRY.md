# GlobalHeader visual elements — v171.52

- top row uses equal-height Profile and balance blocks;
- balance uses a restrained gold-border gradient and separate whole/fraction typography while preserving the exact text;
- inactive Activ/VIP: gray text only;
- active Activ/VIP: the same gold text glow only;
- no status pill, background, border, icon or box highlight in GlobalHeader;
- action row and protected routes remain unchanged;
- measured 360/390 px component proof has no horizontal overflow.

---


# Current visual registry update — account surfaces

- Profile hero: one centered energy mark and identity card.
- Primary tabs: full-width responsive grid.
- Wallet and history cards: bordered mobile surfaces with compact controls.
- History filters: three-column, two-column and one-column responsive grid.
- FAQ: full-width vertical tree with search and outlined sections.
- Bottom navigation remains protected and unchanged.

---

# Current navigation visual element registry

- `EfhcCoinIcon`: universal circle-and-lightning energy mark; active in the
  global balance header and compatible EFHC balance surfaces.
- `AppNavIcon`: original six-kind stroke SVG family for the protected bottom
  navigation.
- Header label: visible `EFHC` only; `Total` is not a visual element.
- Sandbox icon files were inspected only for composition references and were
  not copied into production runtime.

---

# Current Tasks and typography elements — v171.32

- one vertical operational task catalogue;
- reward, human status, availability explanation and one action per card;
- loading, empty, recoverable error and visible success states;
- advertising timer modal above fixed navigation;
- no public debug, raw backend state or duplicate Tasks dashboard;
- Arial-like public font stack;
- compact mobile text scale;
- one-line Panels and Exchange economic values at 390 px;
- focus, modal and bottom-navigation layers remain accessible.

---

# Current Panels and Exchange interaction elements — v171.31

- Panels keeps active/archive controls, activation action and visible list.
- Successful activation adds a visible server panel after refetch.
- Exchange keeps available kWh, amount input, preview and confirmation.
- Successful conversion visibly reduces available kWh after refetch.
- Both routes passed at `390x844` without splash or horizontal overflow.
- Raw technical fields and backend details remain absent from public UI.

---

# Current shell visual elements — v171.30

- compact dark browser notice;
- one routed Energy screen;
- visible English bottom-navigation labels in protected order;
- localized accessible names and titles;
- active navigation indicator that is not color-only;
- focus-visible outline;
- exact zero progress;
- no horizontal overflow at `390x844`;
- reduced-motion handling for shell loading.

---

# Current Energy visual elements — v171.29

- generated-kWh hero remains the visual center;
- progress bar remains visible at zero;
- six secondary metric cards use the shared frontend card primitive;
- status is a human state block, not a technical diagnostic;
- exactly one contextual next-action card is rendered;
- 390px layout uses two metric columns and no horizontal overflow;
- technical Grafana-style runtime dashboard is not routed.

---

# FRONTEND VISUAL ELEMENTS REGISTRY

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## 1. Logo and brand

- EFHC logo / coin mark is the approved brand center.
- Large logo is allowed on presentation, HUB, shop and first
  impression surfaces.
- Admin uses small brand support only; operator clarity is primary.
- Donor logos, donor names and generic crypto symbols must not
  replace EFHC identity.

## 2. Backgrounds

- Public app: dark energy Web3 background.
- Shop: dark storefront background, no public bottom nav.
- Admin: dark operator console or clean dark workspace.
- FAQ/Profile: same app frame, lower decoration density.
- White screen is never a valid background state.

## 3. Hero blocks

- Energy hero: kWh, progress, panels, rate and EFHC state.
- Panels hero: activation value and panel status.
- Exchange hero: available kWh and resulting EFHC.
- Tasks hero: earning focus.
- Ranks hero: leaderboard and user rank.
- Admin hero: operator state, not decoration.

## 4. Cards

Card types:

- energy hero card;
- stat card;
- action card;
- task reward card;
- referral card;
- rank card;
- wallet card;
- product card;
- admin app tile;
- admin KPI card;
- diagnostic card.

Each card has one role. Mixing diagnostics and user actions inside
one card is forbidden.

## 5. Buttons

Button types: primary, secondary, ghost, danger, disabled and
loading.

- Labels are human and localized where public.
- Primary action is visually dominant.
- Disabled action explains why when needed.
- No raw status strings in button text.
- Bottom navigation buttons are protected separately.

## 6. Badges and status pills

Allowed status patterns: human text, tone, shape and optional icon.

Forbidden: public raw codes, wallet raw state, helper labels as main
admin UX and color-only meaning.

## 7. Progress bars

Progress bars are used only for energy progress, rank progress, task
progress, payment checking state and admin analytic indicators.

Required: visible track, visible fill, nearby label or related
number, and no fake decorative progress.

## 8. Tables

Tables belong mostly to admin, reports, wallet/history and detailed
lists. Tables use human labels. Raw JSON must not be rendered as
public or main admin table.

## 9. Charts and graphs

Charts belong to Admin dashboard, reports and future analytic
screens. Admin must have graphical indicators because the user
requested a fuller operator subsection, not only text buttons.

Charts must not replace critical numbers. KPI cards and chart blocks
support each other.

## 10. Menus

Protected bottom menu: Energy, Panels, Exchange, Tasks, Referrals
and Ranks.

Header menu may contain only approved profile, balance, deposit,
wallet or FAQ entries. Admin menu uses large Russian tiles and
secondary diagnostics.

## 11. Language selector

- Profile uses one button with the current language.
- Click opens language dropdown.
- Selecting a language updates runtime UI dictionary.
- Lower bottom nav remains English by canon.
- Raw i18n keys are visual blockers.

## 12. NFT / image / media blocks

NFT and media blocks are allowed where they are product content: VIP
NFT, shop products, rank art or future visual assets. They must not
replace required numbers or actions.

## 13. Modals and bottom sheets

Bottom-sheet modal is allowed for focused actions such as deposit.
It needs close control, safe height, readable title and no double
overlay. Profile is not a modal.

## 14. Forms

Forms must have labels, human validation, disabled/loading state and
clear result. Money forms must not hide source balance or final
status.

## 15. Empty / loading / error blocks

- Empty: explain absence and next action.
- Loading: visible and finite.
- Error: human explanation and retry path.
- Technical details move to Admin Diagnostics.

## 16. Technical elements

Allowed technical elements are confined to Admin Diagnostics,
reports and audit files. Public UI and Admin home must not be built
around technical proof.

## v168_61 fixed visual element decisions

- Energy uses the existing loading logo/background canon.  Do not add a
  new large Energy logo unless chat approves it.
- FAQ displays all section names immediately and expands the selected
  section vertically.
- Profile FAQ is a button to `/faq`.
- Wallet visual element is a connected-wallet list.
- Common financial history is a separate functional page/action.
- Admin root uses equal section cards/buttons.  Graphs belong to each
  functional section page.
- Browser-Shop product visual is a large Web3 NFT/product image card.
- Ranks visual is a vertical player card.
- HUB buttons are equal in size, aligned and limited to two actions by
  default.

## 2026-05-27 — Admin visual elements from UI Kit

New Admin visual element namespace:

`efhc-admin-ui-*`

Elements:

- KPI card;
- chart card;
- filter bar;
- flow map node;
- action table row;
- status badge;
- confirmation block;
- empty state;
- error state;
- section header.

## work pass — Interactive admin operator section

New visual element: interactive operator panel.

Allowed in Admin only:

- SVG chart card;
- metric filter bar;
- game/operator window filter;
- zoom range;
- KPI metric card group;
- flow node map;
- selected-state action table.

Forbidden:

- public-user placement without separate approval;
- fake success state;
- raw endpoint/debug payload on normal Admin surface;
- changing economic meaning through visual labels.

## work pass — Withdrawals mobile decision deck

New admin visual element: mobile decision deck for withdrawals.

Properties:

- finger-sized request cards;
- selected-card state;
- status badge;
- amount emphasis;
- short wallet address;
- state-machine flow map;
- selected-case action table;
- repair/refresh action row.

This element belongs only to Admin operator UI. It is not a public user-facing
component.

## work pass — Admin access guard visual element

- Element: `admin-route-guard`.
- Purpose: mobile-safe blocked/checking state for direct `/admin/*` entry.
- Required data marker: `data-admin-client-route-guard="1329"`.
- Style: dark Web3 card, compact, readable on mobile.


## 2026-05-27 — work pass frontend standard actualization

Target frontend standard for all future frontend work:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

Current package dependencies may still reflect the pre-migration line.
That is technical debt, not target canon. Use
`docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN.md`
for the controlled migration route.

## 2026-05-27 — work pass Tailwind v4 visual elements

Theme tokens are now declared through Tailwind CSS v4 `@theme` in global
CSS. Existing EFHC custom classes remain valid, but new visual elements
should prefer the migrated token layer.

## 2026-05-27 — work pass Tailwind config removal

Tailwind CSS v4.3 is now CSS-first only in HEAD. The active project theme
source is `frontend/src/styles/globals.css` via `@theme` and the PostCSS
adapter is `@tailwindcss/postcss`. `frontend/tailwind.config.js` has been
removed and must not be recreated for ordinary UI work.

## work pass — Tasks catalog mobile deck

New visual element: mobile-first task catalog deck for Admin Tasks.

Properties:

- task card selection;
- active/inactive status badge;
- queue status filter;
- moderation flow map;
- status chart-like bars;
- explicit refresh actions.

This element belongs to Admin operator UI only.

## work pass — Tasks execution trace deck

New visual element: sanitized task execution trace deck for Admin Tasks.

Properties:

- task_bonus ledger KPI cards;
- execution flow map;
- mobile trace cards;
- shortened idempotency-key fingerprint;
- explicit trace refresh and load-more actions;
- admin-only visibility boundary.

## work pass — Reports visual elements

- Mobile KPI grid for report counters and facts;
- scope filter: economy / users / panels;
- report window filter: 7 / 14 / 30 steps;
- SVG chart with clickable points;
- zoom control;
- list/detail metric deck;
- operator detail table.

## work pass — Reports export controls

- format chips: JSON / CSV / TXT;
- scope chips: overview / counters / facts;
- notes toggle;
- touch-sized download button;
- sanitized preview table.

## work pass Diagnostics visuals

- diagnostics KPI cards;
- Admin/Public/Release filter chips;
- technical boundary SVG signal;
- clickable diagnostic nodes;
- selected diagnostic detail table.

## Public UI interactive elements — work pass

Planned elements:

- live kWh card;
- mobile section cards;
- compact DisplayData facts;
- progress bars / rings;
- Telegram BackButton policy;
- Telegram MainButton intent policy;
- haptic feedback policy;
- error/retry state.

Admin diagnostics and raw payload patterns are forbidden in public UI.


## work pass — Public Energy interactive elements

Added public-only visual primitives on Energy:

- interactive tabs for Overview / Panels / Exchange;
- SVG user energy flow;
- DisplayData-style facts rows;
- safe CTA block;
- optional haptic tap wrapper.

These primitives are separate from Admin UI Kit.


## work pass — Public Panels interactive elements

- Activation progress ring to 100 EFHC.
- Activation / Active / Archive tabs.
- DisplayData-style facts rows.
- Active panel preview deck.
- Safe activation CTA connected to existing confirmed flow.


## work pass visual elements
- Public Exchange tabs: Available / Preview / Confirm.
- DisplayData rows for available kWh, max amount, receive preview and main balance.
- SVG exchange flow and progress meter.

## work pass — Public engagement visual elements

Added:

- public engagement card;
- three-tab mobile preview;
- progress bar;
- SVG three-step flow;
- compact metric cells;
- safe CTA.

## work pass — Public profile trust visual elements

- mobile trust section;
- DisplayData-style profile, wallet and history rows;
- SVG flow: profile -> wallet -> history;
- safe badges for VIP / Active;
- haptic safe tab switching.

## work pass Admin UI Kit proof visual

The Admin UI Kit proof panel uses sandbox-inspired section cards,
chart-like adoption bars and list/detail rows. These patterns are adapted to
EFHC Admin and do not add external chart/table dependencies.

## work pass visual element

Admin screenshot QA matrix: KPI cards, viewport filter, screenshot target
bars, flow map and selected detail table. Donor patterns come from the
sandbox UI cards, data-table and Telegram compact cells.
- work pass: Admin route-map docs use sandbox section-card and list/detail donor patterns.
