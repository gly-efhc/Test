<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Current page-element matrix update — Profile and FAQ

| Route | Active elements | Responsive proof |
|---|---|---|
| `/web-profile` | hero, tabs, profile settings, wallet, both histories | 360, 390, 430, 768 px |
| `/faq` | header, search, vertical sections and answers | 390 px plus 13 languages |

No duplicate account dashboard is mounted above the active tab content.

---

# Current Referrals and Ranks page element matrix

| Surface | Required current elements |
|---|---|
| Referrals | statistics, referral link, copy, share, level progress, active/inactive actions |
| Ranks | my rank, generated kWh, vertical player cards, TOP-100, refresh, find-me |
| Global header | universal energy mark, `EFHC` label, numeric balance, no `Total` |
| Bottom navigation | Energy, Panels, Exchange, Tasks, Referrals, Ranks with six consistent SVG icons |

---

# Tasks and typography matrix — v171.32

| Route/layer | Required result | State |
|---|---|---|
| `/tasks` | one catalog with loading/empty/error/data | active |
| custom task | protected claim and visible refetch | browser proof passed |
| ad task | slot, timer, callback and visible refetch | browser proof passed |
| `/ads` | compatibility redirect to `/tasks` | active |
| Panels/Exchange | compact Arial-like one-line values | browser proof passed |
| modal | action above fixed navigation | browser proof passed |

---

# Panels and Exchange page-element matrix — v171.31

| Route | Required interaction | Current state |
|---|---|---|
| `/panels` | active/archive list and summary | query-owned |
| `/panels` | activate for `100 EFHC` | browser proof passed |
| `/panels` | idempotency and visible refetch | passed |
| `/exchange` | available kWh and preview | query-owned |
| `/exchange` | convert at `1 kWh = 1 EFHC` | browser proof passed |
| `/exchange` | idempotency and balance refetch | passed |
| both | real PostgreSQL atomicity | CI/the database reliability stage required |

---

# Shell and Energy element matrix — v171.30

| Layer | Required result | State |
|---|---|---|
| browser notice | compact notice, no duplicate mock screen | active |
| document locale | selected locale in `html lang` | active |
| bottom navigation | protected order and English visual labels | active |
| navigation a11y | localized label, title and active state | active |
| Energy first paint | validated snapshot, no synthetic zero | active |
| zero progress | exact zero, no fake minimum | active |
| public proof | twelve routes, thirteen languages, 390 px | passed |
| admin proof | isolated action and screenshot matrix | open |

---

# Current Energy page-element matrix — v171.29

| Layer | Active element | State |
|---|---|---|
| hero | generated kWh, progress, remaining, available kWh, effective rate, active panels, VIP status | active |
| summary | main, bonus and total EFHC; base and effective rates; active state | active |
| action | one contextual Panels or Exchange action | active |
| loading | human loading state | active |
| recoverable failure | human error plus refresh | active |
| browser mode | visible demo snapshot label and next step | active |
| technical dashboard | `EnergyDashboardRuntime` | inactive legacy |
| duplicate tabbed overview | `PublicEnergyInteractiveOverview` | inactive replacement |

---

# Матрица обязательных элементов frontend

Статус: living control document.
Дата: 2026-05-20.
Версия архива: v168_68.
Циклы: 1268-1270.

## 1. Назначение

Документ фиксирует, что должно быть и чего не должно быть на
каждом экране. Это защита от повторной потери функций через
красивую, но неправильную визуальную переработку.

## 2. Иерархия источников

- latest user chat answers
- FRONTEND_FUNCTION_RECOVERY_CANON.md
- FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md
- ancient page-source docs
- current code snapshot

## Energy

Назначение: main generation screen.

Маршруты:
- /

Примечание active-route sync:
`/` является единственным active Energy route. `/energy` не имеет
страницы в `frontend/src/pages/` и не считается active route.

Обязательно:
- generated kWh as visual center
- available kWh
- progress bar
- kWh per second for active panels
- VIP status label when active
- top header balance boundary

Запрещено:
- HUB card
- Wallet/Profile card
- Tasks card
- Shop card
- Ranks card
- Referrals card
- main balance as visual center
- bonus balance as visual center
- 12-level catalog
- technical proof text

Guard-смысл:
- Energy must not become dashboard trash
- no white screen in browser mode

## Panels

Назначение: panel activation and active/archive panels.

Маршруты:
- /panels

Обязательно:
- active panels first
- activate panel button
- 100 EFHC activation cost
- bonus first then main balance spending
- active/archive switch controls
- activation date
- deactivation date
- days hours minutes until deactivation
- runtime countdown
- total generation rate in hero

Запрещено:
- panel age instead of remaining time
- daily generation per panel
- VIP block on panels page
- global_id visible to user
- hidden activation price

Guard-смысл:
- countdown is a blocker
- panel seconds feed generation seconds

## Exchange

Назначение: convert generated kWh to EFHC.

Маршруты:
- /exchange

Обязательно:
- 1 kWh = 1 EFHC
- kWh to EFHC only
- Max button
- available kWh input boundary
- small link to common History if needed
- no Wallet/Withdraw block on Exchange

Запрещено:
- user to user transfer
- recipient input
- send EFHC button
- VIP/NFT block
- extra quick actions overload
- Wallet/Withdraw card or drawer

Guard-смысл:
- transfer ban is hard canon

## Tasks

Назначение: earning bonus actions and ad tasks.

Маршруты:
- /tasks

Обязательно:
- task list in compact card-like rows
- task title
- reward EFHC
- visible primary action button
- ad group when ad tasks exist
- watch ad button opens the ad flow immediately
- no extra confirmation gate before opening ads
- no public global_id/user_id query in ad slot call
- human blocked reason only when needed
- hidden backend/admin execution evidence only outside public UI

Запрещено:
- public task completion history
- public backend execution log
- public idempotency/debug explanation
- 100 Bonus EFHC to panel conversion
- large progress block
- overloaded status dashboard
- extra pre-ad warning modal

Guard-смысл:
- Tasks is an earning module, not a log/history/debug screen.
- Status v168_91 / work pass: public execution history/log boundary is completed.
- Guard: `test_tasks_hidden_execution_log.py`.
- Backend double-claim protection may exist, but it is not rendered as public UI.
- `test_tasks_ads_action.py` protects the direct ads action boundary.

Status v168_89 / work pass: list-card earning boundary completed.
Status v168_90 / work pass: ad button direct-open boundary completed.

## Referrals

Назначение: invite users and track active referral bonuses.

Маршруты:
- /referrals

Обязательно:
- referral link as main element
- copy link button
- share button
- active referrals list
- inactive referrals list
- username only
- Active status after first panel forever
- +0.1 EFHCbb for active referral
- referral progress bar
- six referral levels

Запрещено:
- visible global_id
- bonus for inactive referral
- hiding active/inactive reason

Guard-смысл:
- Active status is referral bonus source

## Ranks

Назначение: leaderboards by kWh and referrals.

Маршруты:
- /ranks

Обязательно:
- vertical player cards
- kWh filter
- Referrals filter
- current user pinned card
- show me in ranking action
- competitors above and below user
- username only

Запрещено:
- 12 Energy levels catalog
- global_id visible to user
- motivation block without approval

Guard-смысл:
- Ranks is leaderboard, not Energy achievements catalog

## Profile

Назначение: account profile page, not overlay.

Маршруты:
- /web-profile

Обязательно:
- username or guest name
- level
- VIP status indicator always visible
- Active status indicator always visible
- FAQ button to full FAQ

Запрещено:
- overlay profile as primary route
- EFHC Player technical label
- browser ready proof text
- PWA technical badge

Guard-смысл:
- Profile route is a page

## Wallet

Назначение: connected wallet list and binding controls.

Маршруты:
- /web-profile

Обязательно:
- connected wallets list
- wallet binding controls

Запрещено:
- large technical wallet state map
- account History button inside Wallet
- debug wallet payloads

Guard-смысл:
- History is account layer, not wallet layer

## History

Назначение: common account financial history.

Маршруты:
- /web-profile

Обязательно:
- all account financial movements
- filters: all purchases exchange withdraw bonuses panels
- purchases
- exchange
- withdraw
- bonuses
- panels

Запрещено:
- wallet-only history
- hidden financial movements

Guard-смысл:
- History belongs to account

## FAQ

Назначение: functional help tree.

Маршруты:
- /faq

Обязательно:
- full section list visible at once
- vertical tree
- vertical reveal
- mobile containment

Запрещено:
- horizontal pills
- category quick card grid
- text overflow outside app frame

Guard-смысл:
- functionality over decorative design

## HUB

Назначение: minimal handoff hub.

Маршруты:
- /hub

Обязательно:
- two equal buttons
- Deposit EFHC action
- EFHC VIP NFT link
- same button size and aligned descriptions

Запрещено:
- third item without chat approval
- technical diagnostics
- truth layer
- Browser-Shop block
- FAQ block

Guard-смысл:
- HUB button alignment is visual canon

## Browser-Shop

Назначение: standalone Web3 storefront.

Маршруты:
- /browser-shop

Обязательно:
- separate web page
- large product or NFT-like cards
- TON EFHC purchase
- USDT return after clarified payment-road
- EFHC VIP NFT text link to GetGems/site
- human payment statuses

Запрещено:
- bottom nav
- wallet memo copy manual blocks
- debug payloads
- endpoint text
- bonus packages without separate approval

Guard-смысл:
- Shop is Web3 storefront, not debug screen

## Admin

Назначение: operator section dashboard.

Маршруты:
- /admin

Обязательно:
- main page with section cards
- Users section
- Bank section
- Withdrawals section
- Shop section
- Tasks section
- Reports section
- Diagnostics section
- System section if route exists
- per-function graph or statistics at top
- actions and tables below

Запрещено:
- debug dump on main admin page
- Lotteries return
- NFT panel return without clarification
- public game design where operator console is needed

Guard-смысл:
- diagnostics only in Diagnostics

## BrowserLogin

Назначение: login page instead of white screen.

Маршруты:
- browser entry

Обязательно:
- dark login page
- Telegram login action
- demo-preview Energy allowed
- no white screen

Запрещено:
- blank page
- endless loading
- fake account as real data

Guard-смысл:
- demo is allowed but must not replace real account

## 3. Следствие для code pass

Перед изменением экрана нужно открыть этот документ и проверить,
что правка не удаляет обязательный элемент и не возвращает
запрещённый элемент.


## v168_85 — Exchange amount/preview boundary

Exchange must show:

- available kWh;
- amount input labelled as kWh;
- Max button;
- fixed rate `1 kWh = 1 EFHC`;
- receive preview in EFHC;
- convert action;
- small History access only as secondary navigation.

Exchange must not show:

- user-to-user transfer;
- withdraw block;
- wallet block;
- VIP block;
- percentage quick-action overload;
- technical/debug labels.
## v168_86 — Exchange History link light boundary

Exchange must keep History access only as secondary navigation.

Exchange must show:

- a small account History hint;
- one light History link;
- no History table inside Exchange;
- no History filters inside Exchange.

Exchange must not show:

- a full account History surface;
- purchase/withdraw/bonus/panel history rows;
- Wallet or Withdraw controls;
- heavy card-like History action overload.

## v168_87 — Exchange route-contract boundary

Exchange must keep:

- generated current-user API seams;
- `/exchange/preview` for preview;
- `/exchange/convert` for conversion;
- fixed `1 kWh = 1 EFHC` direction;
- no explicit user path in the public frontend.

Exchange must not show or build:

- `global_id` query strings;
- `user_id` path strings;
- user-to-user transfer;
- Wallet controls;
- Withdraw controls;
- heavy History surface.


## v168_92 work pass — Tasks proof marker is mandatory.
- Referrals invite block must show link/copy/share as the main surface.
- Referrals active/inactive rows must show username or neutral fallback, not global_id.

## v168_93 work pass update

- Referrals: visible progress/levels/achievements card and `+0.1 EFHCbb` bonus wording in rules/progress only.
- Ranks: vertical cards, username/neutral fallback only, filters exactly kWh/Referrals, Show me focused-neighbor action, no public global_id/query routes.

## v168_94 work pass — Profile / Wallet / History / FAQ matrix update

Profile:

Required:
- username / user-visible identity;
- level;
- VIP badge always visible with active/inactive visual state;
- Active badge always visible with active/inactive visual state;
- clean button to full `/faq`.

Forbidden:
- embedded mini FAQ inside Web-Profile;
- public technical readiness labels;
- numeric Telegram id as the central visible identity.

Wallet:

Required:
- connected wallet list;
- connect/manage/remove/primary wallet actions;
- short human error microcopy if wallet loading fails.

Forbidden:
- general balance dashboard;
- account history;
- withdraw status block;
- raw wallet error payload.

History:

Required:
- account-level timeline;
- filters: All, Purchases, Exchange, Withdraw, Bonuses, Panels;
- balance history and withdraw request history through existing data
  contracts.

Forbidden:
- wallet-specific history framing;
- fake history rows;
- `global_id` query routes.

FAQ:

Required:
- compact vertical tree;
- all sections visible as a list;
- vertical section/subsection/question expansion.

Forbidden:
- horizontal pill navigation;
- full `openAll` expansion by default;
- decorative quick-card grid replacing the useful tree.


## v168_95 work pass update

- HUB: exactly two public buttons only — Top up EFHC and EFHC VIP NFT.
- HUB: VIP NFT is an external link policy, not a heavy NFT panel.
- Browser-Shop: separate Web3 shop page with large product cards.
- Browser-Shop: TON payment road remains active and human-readable.
- Browser-Shop: USDT is audited but not shown as ready in public UI.
- Admin: home starts with eight canonical sections.
- Admin: functional pages follow stats/actions/table structure.
- Admin: route map is stored in `docs/admin/ADMIN_ROUTES_MAP.md`.

## HUB and Direct Deposit element matrix

| Surface | Element | State |
|---|---|---|
| HUB | EFHC top-up card | active |
| HUB | EFHC VIP NFT card | active |
| Deposit | TON amount input | active |
| Deposit | Open-wallet action | active |
| Deposit | Watcher checking state | active |
| Deposit | Confirmed-credit state | active |
