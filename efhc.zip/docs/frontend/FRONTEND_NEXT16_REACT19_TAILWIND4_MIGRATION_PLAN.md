# FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN

Version: v169_09 / work pass
Date: 2026-05-27
Status: active migration plan

## Decision

The project target is fixed as:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

work pass does not change runtime frontend dependencies. It fixes
CI-log errors and actualizes documents. The real dependency migration
must be performed in a separate migration pass.

## Why migration is separate

A dependency jump from Next.js 14 / React 18 / Tailwind CSS 3 to the
target standard can change build, RSC, TypeScript, CSS and runtime
behaviour. It must not be mixed with admin UI development or log repair.

## Required migration pass

Minimum scope:

1. update `frontend/package.json`;
2. regenerate `frontend/package-lock.json`;
3. convert Tailwind to v4 CSS-first theme;
4. review old Tailwind config;
5. update dev script toward `next dev --turbo`;
6. run `npm ci`;
7. run `npx tsc --noEmit`;
8. run `npm run build`;
9. add dependency-standard guard;
10. add migration change report.

## Current status

- Documentation canon: active.
- Runtime dependencies: still old line until migration.
- Next admin cycle should not silently upgrade dependencies unless
  explicitly assigned as migration cycle.


## 2026-05-27 — Superseded by completed work pass

This plan is now executed by work pass. The active completion record is:

`docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_COMPLETED.md`.

Runtime dependencies are no longer only a target; they are implemented in
`frontend/package.json` and `frontend/package-lock.json`.
