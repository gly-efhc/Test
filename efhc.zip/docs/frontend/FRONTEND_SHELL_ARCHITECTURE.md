<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# FRONTEND SHELL ARCHITECTURE

Status: living control document. Internal version: v168_62.


## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.

## 1. Purpose

This document fixes the application shell before page code work.
Every page must belong to a known shell type. New layout code must
not be invented ad hoc when an existing shell layer can be used.

## 2. Shell types

EFHC uses six shell types:

1. public game shell;
2. profile / wallet shell;
3. FAQ shell;
4. browser shop shell;
5. admin operator shell;
6. admin diagnostics shell.

All shells share visual tokens, safe areas, readable text, vertical
scroll only and browser/PWA fallback behavior.

## 3. Public game shell

Routes: `/`, `/panels`, `/exchange`, `/tasks`, `/referrals`,
`/ranks`.

- Root: dark game app field.
- Header: approved public actions only.
- Hero: one semantic center per page.
- Primary actions: visible, not hidden under random compact UI.
- Details: below hero, scrollable vertically.
- Bottom navigation: protected six buttons.

The public game shell must never depend on Telegram `tg_id` to
render the basic screen.

## 4. Canonical bottom navigation

The bottom menu is protected:

1. Energy;
2. Panels;
3. Exchange;
4. Tasks;
5. Referrals;
6. Ranks.

FAQ, Admin, HUB, Shop and Profile are not bottom navigation items.
Settings is not a game route or bottom-navigation item. It is available only inside the Profile tab of `/web-profile`.
The active state must be visible without relying only on color.

## 5. Header

Public header may show only approved route actions: profile entry,
balance chip, deposit entry, wallet entry when relevant and FAQ
entry in approved context.

Header must not show runtime proof, browser proof, route
diagnostics, payload data, developer labels or independent-shell
explanations.

## 6. Profile / Wallet shell

Route: `/web-profile`.

- Real page, not overlay.
- Clear back or exit behavior.
- User card.
- Tabs: Profile, Wallet, History, FAQ.
- FAQ tab contains a button to the full `/faq` page.
- Language selector as one current-language button with dropdown.
- Wallet section is a list of connected wallets.
- Financial history is one common account-history page opened by
  a separate functional button.
- Human history and withdrawal labels.

Legacy `ProfileModal` is a regression risk and must not become the
main Profile surface again without direct approval.

## 7. FAQ shell

Route: `/faq`.

- Compact page header.
- Optional search only if it does not dominate.
- Vertical section tree.
- Subsections visible by default.
- Question rows expandable vertically.
- Answers contained inside the frame.

Forbidden patterns: category pills as the main model, horizontal
category rail, heavy quick-card grid and text escaping the frame.

## 8. Browser-Shop shell

Route: `/browser-shop`.

- Separate shop root.
- No public bottom navigation.
- Product cards.
- One pay action per product.
- Human localized payment status.
- Hidden TonConnect payload and memo internals.

Browser-Shop may share tokens with game shell but must feel like a
storefront, not an internal payment console.

## 9. Admin operator shell

Route: `/admin` and admin modules.

- Russian by default.
- Operator dashboard first.
- Large app tiles for sections.
- Admin home is a launcher, not a full analytics dump.
- Each functional section page has its own statistics or graph at
  the top and functional actions below.
- Diagnostics separated.
- Tables and forms use human labels.

Admin home is not a debug dump. It must answer: where do I click and
what is the state of the system?

## 10. Admin diagnostics shell

Routes: `/admin/diagnostics`, `/admin/logs` and service sublayers.

- Technical data allowed.
- Route proof allowed.
- Logs allowed.
- Raw statuses translated or grouped where possible.
- Must never leak into public UI or dominate Admin home.

## 11. Modal layer

Modal is a bottom-sheet style layer for mobile. It must have clear
close action, no double overlay, safe viewport height and no
background scroll trap. Profile must not be implemented as the main
overlay surface.

## 12. Toast / notification layer

Toasts are short human messages. They must not show endpoint paths,
JSON payloads, intent ids or stack traces.

## 13. Loading states

- Use skeletons or human loading copy.
- Loading must not hide the whole app forever.
- Dictionary or Telegram loading failure must fall back to visible
  UI.

## 14. Error states

- Public errors are human and short.
- Technical detail is moved to Admin Diagnostics or report layer.
- The user must understand whether to retry, wait or change input.

## 15. Empty states

Empty state is not a technical failure. It explains that there are
no panels, no tasks, no referrals, no history or no wallet yet, and
shows the next useful action when approved.

## 16. Current shell debt

- `Layout`, `GameShell` and `FrontendShell` coexist.
- Some legacy profile/modal components remain as regression risk.
- Admin root still needs full operator-console controlled pass.
- Screenshot QA is required before claiming visual readiness.

## 17. Page-description source rule v168_61

Before changing shell composition, read the page-description sources
listed in `FRONTEND_VISUAL_CONTRACT.md`.  The operator must not ask the
user again about elements that are already fixed there.

## 2026-05-27 — Target frontend technology standard

The target frontend standard for future EFHC Bot migration is:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

The current older dependency line remains a HEAD fact only. Migration to
this standard requires a separate controlled migration pass with lock-file,
build and guard validation.



## 2026-05-27 — work pass frontend standard actualization

Target frontend standard for all future frontend work:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

Current package dependencies may still reflect the pre-migration line.
That is technical debt, not target canon. Use
`docs/frontend/FRONTEND_NEXT16_REACT19_TAILWIND4_MIGRATION_PLAN.md`
for the controlled migration route.

## 2026-05-27 — work pass implemented frontend runtime migration

The shell now targets the implemented runtime line:

- Next.js 16.2.6;
- React 19.2.6;
- React DOM 19.2.6;
- Tailwind CSS v4.3;
- Tailwind v4 PostCSS adapter.

The shell keeps the Pages Router architecture but must be treated as a
Next.js 16 runtime. Development starts through `next dev --turbo`.
Tailwind project tokens are configured in `globals.css` through `@theme`.

## 2026-05-27 — work pass Tailwind config removal

Tailwind CSS v4.3 is now CSS-first only in HEAD. The active project theme
source is `frontend/src/styles/globals.css` via `@theme` and the PostCSS
adapter is `@tailwindcss/postcss`. `frontend/tailwind.config.js` has been
removed and must not be recreated for ordinary UI work.

## 17. Telegram Mini App shell polish lock

The public shell must support Telegram Mini App, Browser and PWA modes without forcing Telegram-only rendering.

Current TMA shell requirements:

- expose runtime shell markers through the root HTML/data layer;
- keep combined safe-area tokens `--efhc-safe-top` and `--efhc-safe-bottom` as the UI-facing tokens;
- handle Telegram viewport changes by refreshing CSS vars;
- keep root `/` without public route BackButton;
- keep `/admin/*` outside public BackButton behavior;
- allow public non-root routes to use BackButton as a route-back/home affordance;
- preserve Deposit/TonConnect modal BackButton ownership;
- never import sandbox runtime frameworks into EFHC.

This shell layer is source/static polish only until a real Telegram client or Playwright screenshot run provides evidence.

## v169.75 — fresh CI shell verification note

The supplied CI log `logs_72181359058.zip` verified the current shell
state after the previous pytest repair. The log showed successful pytest
execution and successful Next.js 16.2.6 production build.

The build route table confirmed the protected split:

- `/_app` is the Next Pages Router shell layer;
- `/app` is a public deep-link alias route;
- `/api/tonconnect-manifest` remains dynamic;
- admin pages and public pages are built as separate page surfaces.

This note is evidence bookkeeping only. It does not claim browser
screenshots, live Telegram client proof, release readiness or real wallet
transaction proof.

