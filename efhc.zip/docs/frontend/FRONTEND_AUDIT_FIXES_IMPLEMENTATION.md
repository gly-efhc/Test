# FRONTEND_AUDIT_FIXES_IMPLEMENTATION

Status: ACTIVE IMPLEMENTATION RECORD
Version: v169_39
Source audit: `docs/history/legacy_artifacts/docs/audits/TZ_FIXES_AUDIT_v169_35.md`

## Scope

This document records the implementation pass for the uploaded audit fix
package. The public UI QA plan was moved forward by direct user instruction.
Detailed work-pass numbering is kept in `docs/history/legacy_artifacts/docs/cycles/` and `docs/history/legacy_artifacts/reports/`, not in
this frontend product document.

## HIGH fixes

| Fix | Status | Files |
|---|---|---|
| FIX-01 admin bottom nav boundary | DONE | `frontend/src/components/Layout.tsx`, `tests/architecture/test_admin_no_bottom_nav.py` |
| FIX-02 E2E smoke scaffold | DONE + RESIDUAL CLOSED | `tests/frontend/e2e/*.py`, `tests/architecture/test_frontend_e2e_scope_guard.py` |
| FIX-03 Sale Packages mutations | DONE | `frontend/src/features/admin/AdminSalePackagesPage.tsx`, `tests/architecture/test_admin_sale_packages_mutations_wired.py` |

## MEDIUM fixes

| Fix | Status | Files |
|---|---|---|
| FIX-04 EFHC deposits idempotency | DONE | `frontend/src/pages/admin/efhc-deposits.tsx`, `tests/architecture/test_api_finance_canon.py` |
| FIX-05 public 401/403 error states | DONE + LOCALIZED | `frontend/src/lib/publicError.ts`, public pages, `frontend/public/locale/*.json`, `tests/architecture/test_public_pages_error_state_guard.py` |
| FIX-06 component-level AdminPage guard | DONE | `frontend/src/components/admin/AdminPage.tsx`, `tests/architecture/test_audit_repair_security_admin_guard.py` |
| FIX-07 PWA offline fallback | DONE | `frontend/public/sw.js`, `frontend/public/offline.html`, `tests/architecture/test_pwa_offline_fallback_guard.py` |

## LOW fixes

| Fix | Status | Files |
|---|---|---|
| FIX-08 DepositModal wallet open | DONE | `frontend/src/components/DepositModal.tsx`, `tests/architecture/test_deposit_wallet_open_guard.py` |
| FIX-09 TonConnect fallback note | DONE | `frontend/public/tonconnect-manifest.json`, `docs/SSOT/WALLETS_TONCONNECT_SSOT.md`, `tests/architecture/test_tonconnect_frontend_wallet_binding.py` |
| FIX-10 no-prefix routers documented | DONE | `backend/app/routes/me_routes.py`, `backend/app/routes/system_routes.py`, `docs/NORM/API_CONTRACTS.md`, `tests/architecture/test_no_prefix_routers_documented.py` |

## Sandbox use

`docs/history/legacy_artifacts/map_element.md` and `docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md`
were used as navigation references only. The E2E and UX fixes borrow testing and
Telegram Mini App safety patterns conceptually, without importing Vue, Solid,
Nuxt or Vanilla runtime into the EFHC frontend.


## Recheck pass update

A follow-up static recheck was completed before starting Public UI screenshot QA preparation. It confirmed the ten uploaded audit fixes and closed two minor tails:

- stale Sale Packages `read-only` UI wording was replaced with `mutation-wired`;
- EFHC deposits force-fulfillment POST now carries a frontend idempotency key.

No frontend framework migration was performed. Sandbox archives remain reference-only.

## Residual audit closure update

A second follow-up review found three residual defects after the first
implementation pass. They are now closed:

- `common.session_expired` and `common.load_error` exist in all 13 locale JSON
  files, preventing English fallback text on non-English public error states;
- Exchange, HUB deposit and Withdraw E2E smoke tests now perform actual user
  interactions and assert that the expected POST request is fired;
- public/admin E2E smoke route matrices now include the missing canonical pages.

`frontend/public/offline.html` also now contains a multilingual fallback line so
the offline PWA state is understandable beyond Russian.

