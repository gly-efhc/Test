# FRONTEND_PUBLIC_PANELS_ACTIVATION_PREVIEW

Дата: 2026-05-31
Статус: implemented
Архив: v169_27
Цикл: 1348 — Public Panels activation preview

## 1. Цель

Продолжить public UI interactivity wave после Energy overview и сделать
страницу Panels более понятной для мобильного пользователя перед активацией.

Цикл не меняет экономику EFHC и не переносит Admin/Diagnostics в public UI.

## 2. Что добавлено

Добавлен компонент:

`frontend/src/components/public/PublicPanelsActivationPreview.tsx`

Подключён в:

`frontend/src/pages/panels.tsx`

Компонент добавляет:

- вкладки `Activation / Active / Archive`;
- прогресс до порога `100 EFHC`;
- DisplayData-style строки баланса;
- safe haptic tap wrapper;
- SVG flow баланса, активации и панели;
- preview ближайших активных панелей;
- безопасную кнопку активации через существующий `activatePanel` flow.

## 3. Donor-source

Использованы sandbox-паттерны:

- старая `Песочница.xz`: mobile cards / interactive chart discipline;
- `typescript-template-master.zip`: DisplayData rows;
- `nuxt-telegram-mini-app-main.zip`: TgSection / TgCell идеи;
- `vanillajs-template-master.zip`: compact facts examples;
- `vuejs-template-master.zip`: component surface ideas;
- `solidjs-template-master.zip`: DisplayData component pattern.

Перенесены только UX-паттерны. Runtime Nuxt/Vue/Solid/Vanilla/jQuery не
переносился.

## 4. Public UI boundary

Разрешено:

- показывать прогресс к 100 EFHC;
- показывать main / bonus / total activation balance;
- показывать active/archive summary;
- показывать preview ближайших активных панелей;
- запускать существующий подтверждаемый `activatePanel` flow.

Запрещено:

- показывать admin route labels;
- показывать diagnostics strips;
- показывать endpoint names;
- показывать raw API payload;
- менять расчёт активации на frontend;
- обходить confirm/idempotency flow.

## 5. Экономические инварианты

Не изменены:

- активация панели стоит `100 EFHC`;
- списание идёт bonus first, main second;
- frontend не создаёт новый экономический путь;
- `activatePanel` использует прежний POST `/panels/activate`;
- подтверждение покупки сохраняется.

## 6. Следующий шаг

Следующий public UI cycle:

`1349 — Public Exchange interactive preview`
