# Current source map update — Profile and FAQ

- `/web-profile` -> `features/profile/WebProfilePage.tsx`.
- Wallet -> `components/profile/ProfileWalletSection.tsx`.
- History -> `components/profile/ProfileHistorySection.tsx`.
- Service -> `services/profile.service.ts`.
- Queries -> `queries/useProfile.ts`.
- `/faq` -> `pages/faq.tsx` and `components/faq/FaqVerticalTree.tsx`.
- Responsive styles -> `styles/globals.css`.

---

# Current Referrals and Ranks page source map

| Route | Active page | Query | Service | Backend |
|---|---|---|---|---|
| `/referrals` | `pages/referrals.tsx` | `useReferralStats` | `referrals.service.ts` | referral stats and bind routes |
| `/referrals/active` | `ReferralListPage` | `useReferralList` | `referrals.service.ts` | active referral route |
| `/referrals/inactive` | `ReferralListPage` | `useReferralList` | `referrals.service.ts` | inactive referral route |
| `/ranks` | `pages/ranks.tsx` | `useMyRankWithTop`, `useRankTopPages` | `ranks.service.ts` | my-plus-top and top routes |

Historical referral and ranks dashboard components are inactive references.

---

# Current Tasks source map — v171.32

- page: `frontend/src/pages/tasks.tsx`;
- alias: `frontend/src/pages/ads.tsx`;
- query: `frontend/src/queries/useTasks.ts`;
- service/validators: `frontend/src/services/tasks.service.ts`;
- backend route: `backend/app/routes/tasks_routes.py`;
- business service: `backend/app/services/tasks_service.py`;
- advertising route/service: `backend/app/routes/ads_routes.py` and Tasks
  reward helpers;
- evidence: `docs/history/legacy_artifacts/reports/generated/tasks_ads_linkage_v171_32.json`.

---

# Current Panels and Exchange source map — v171.31

## Panels

- page: `frontend/src/pages/panels.tsx`;
- queries: `frontend/src/queries/usePanels.ts`;
- service: `frontend/src/services/panels.service.ts`;
- DTOs: `frontend/src/lib/api/generated/economicUserSeams.ts`;
- validators:
  `frontend/src/lib/api/generated/economicUserSeamValidators.ts`;
- backend route: `backend/app/routes/panels_routes.py`;
- business service: `backend/app/services/panels_service.py`.

## Exchange

- page: `frontend/src/pages/exchange.tsx`;
- queries: `frontend/src/queries/useExchange.ts`;
- service: `frontend/src/services/exchange.service.ts`;
- DTOs and validators: generated economic user seams;
- backend route: `backend/app/routes/exchange_routes.py`;
- business service: `backend/app/services/exchange_service.py`.

Linkage evidence:
`docs/history/legacy_artifacts/reports/generated/panels_exchange_linkage_v171_31.json`.

---

# Current shell source map — v171.30

- route shell: `frontend/src/components/Layout.tsx`;
- shell primitives: `frontend/src/components/shell/FrontendShell.tsx`;
- browser notice: `frontend/src/components/BrowserLoginDemo.tsx`;
- Energy runtime: `frontend/src/pages/index.tsx`;
- document locale: `frontend/src/pages/_app.tsx`;
- styles: `frontend/src/styles/globals.css`;
- public proof: `ops/frontend/public_visual_runtime_proof.py`;
- language canon: `docs/SSOT/LANGUAGE_CANON_SSOT.md`;
- cycle guard:
  `tests/architecture/test_shell_language_browser_contract.py`.

---

# Current Energy source map — v171.29

- route entry: `frontend/src/pages/index.tsx`;
- active view: `LiveEnergyHeroAndProgress` inside `frontend/src/pages/index.tsx`;
- snapshot schema/service: `frontend/src/services/snapshot.service.ts`;
- query hook: `frontend/src/hooks/useSnapshot.ts`;
- query keys: `frontend/src/queries/queryKeys.ts`;
- browser snapshot: `frontend/src/lib/browserFallback.ts`;
- backend route/model: `backend/app/routes/sync_routes.py`;
- shell: `frontend/src/components/Layout.tsx` and
  `frontend/src/components/shell/FrontendShell.tsx`;
- replacement mapping: `FRONTEND_ENERGY_MVP_REPLACEMENT_MAPPING.md`.

---

# FRONTEND PAGE SOURCE MAP

## Exact physical page source inventory — v171.88

This list is generated from the same physical Next.js page boundary as
`ops/frontend/all_pages_visual_manifest_v171_88.json`.

- `/` -> `frontend/src/pages/index.tsx`.
  Class: `public`. Visual marker: `.efhc-energy-page`.
- `/app` -> `frontend/src/pages/app.tsx`.
  Class: `public`. Visual marker: `.efhc-energy-page`.
- `/panels` -> `frontend/src/pages/panels.tsx`.
  Class: `public`. Visual marker: `.efhc-panels-shell`.
- `/exchange` -> `frontend/src/pages/exchange.tsx`.
  Class: `public`. Visual marker: `.efhc-exchange-shell`.
- `/tasks` -> `frontend/src/pages/tasks.tsx`.
  Class: `public`. Visual marker: `.efhc-tasks-shell`.
- `/ads` -> `frontend/src/pages/ads.tsx`.
  Class: `public`. Visual marker: `.efhc-tasks-shell`.
- `/referrals` -> `frontend/src/pages/referrals.tsx`.
  Class: `public`. Visual marker: `.efhc-referrals-shell`.
- `/referrals/active` -> `frontend/src/pages/referrals/active.tsx`.
  Class: `public`. Visual marker: `[data-referrals-active-inactive-boundary]`.
- `/referrals/inactive` -> `frontend/src/pages/referrals/inactive.tsx`.
  Class: `public`. Visual marker: `[data-referrals-active-inactive-boundary]`.
- `/ranks` -> `frontend/src/pages/ranks.tsx`.
  Class: `public`. Visual marker: `.efhc-ranks-shell`.
- `/web-profile` -> `frontend/src/pages/web-profile.tsx`.
  Class: `public`. Visual marker: `.efhc-profile-page`.
- `/faq` -> `frontend/src/pages/faq.tsx`.
  Class: `public`. Visual marker: `.efhc-faq-shell`.
- `/hub` -> `frontend/src/pages/hub.tsx`.
  Class: `public`. Visual marker: `.efhc-hub-page`.
- `/browser-shop` -> `frontend/src/pages/browser-shop.tsx`.
  Class: `public`. Visual marker: `[data-public-surface='browser-shop']`.
- `/withdraw` -> `frontend/src/pages/withdraw.tsx`.
  Class: `public`. Visual marker: `.efhc-withdraw-trust-shell`.
- `/admin` -> `frontend/src/pages/admin.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/users` -> `frontend/src/pages/admin/users.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/bank` -> `frontend/src/pages/admin/bank.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/withdrawals` -> `frontend/src/pages/admin/withdrawals.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/shop` -> `frontend/src/pages/admin/shop.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/tasks` -> `frontend/src/pages/admin/tasks.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/reports` -> `frontend/src/pages/admin/reports.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/referrals` -> `frontend/src/pages/admin/referrals.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/panels` -> `frontend/src/pages/admin/panels.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/diagnostics` -> `frontend/src/pages/admin/diagnostics.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/system` -> `frontend/src/pages/admin/system.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/logs` -> `frontend/src/pages/admin/logs.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/hub` -> `frontend/src/pages/admin/hub.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/templates` -> `frontend/src/pages/admin/templates.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/efhc-deposits` -> `frontend/src/pages/admin/efhc-deposits.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/ads` -> `frontend/src/pages/admin/ads.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/admin/sale-packages` -> `frontend/src/pages/admin/sale-packages.tsx`.
  Class: `admin`. Visual marker: `.efhc-admin-shell`.
- `/404` -> `frontend/src/pages/404.tsx`.
  Class: `system`. Visual marker: `main`.
- `/500` -> `frontend/src/pages/500.tsx`.
  Class: `system`. Visual marker: `[data-public-surface='safe-error']`.

Status: living control document. Internal version: v168_62.
Scope: source hierarchy for page descriptions and frontend decisions.


## Current complete route source map — v171.88

The complete production page inventory is machine-readable in
`ops/frontend/all_pages_visual_manifest_v171_88.json`.

Newly reconciled routes:

- `/app` -> `frontend/src/pages/app.tsx`; canonical alias that
  re-exports
  the Energy page from `frontend/src/pages/index.tsx`.
- `/admin/system` -> `frontend/src/pages/admin/system.tsx`; protected
  operator health surface using the shared Admin shell.
- `/404` -> `frontend/src/pages/404.tsx`; safe not-found state.
- `/500` -> `frontend/src/pages/500.tsx`; safe server-error state.

Every physical production page must be present in the screen registry,
the source map and the machine visual manifest. New routes may not rely
only on a Next.js build listing as documentation.

## Ancient page-description source hierarchy v168_62

The primary page-description layer is not the recent v168_52-v168_61
visual audit layer. The operator must first inspect the older baseline
sources that were created near the beginning of the archive:

1. `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`;
2. `docs/GENERAL/specification.md`;
3. `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md`;
4. `docs/SSOT/ENERGY_RULES.md`;
5. `docs/SSOT/PANELS_SSOT.md`;
6. `docs/SSOT/HUB_SSOT.md`;
7. `docs/NORM/RANKS_RULES.md`;
8. `docs/NORM/REFERRALS_RULES.md`.

Then the operator reads the early visual/page audit sources from
2026-04-04 to 2026-04-09 and only after that reads later corrective
chat-agreement files such as `CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

The v168_60-v168_61 mistake was treating recent audit files as the
oldest page-description sources. Future frontend work must not repeat
that mistake. Questions are allowed only after these ancient sources are
checked and the missing point is still genuinely unresolved.

Detailed map: `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`.


## Purpose

This document fixes the v168_60-v168_61 process failure. The operator
looked at recent visual audits first and treated already decided screen
elements as open questions. The correct search target is older: the
early
page-description layer that existed near the beginning of the archive.

## Rule

Before asking the user about any screen element, the operator must read
both:

1. ancient baseline page-description sources;
2. later corrective chat/agreement sources.

If an element is already described there, the operator must not ask it
again as if it were unknown. The operator may only ask when the ancient
source and later user decision conflict, or when no source exists.

## Ancient baseline page-description sources

These are the first sources to inspect for the original page model:

- `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md` — original map of WebApp
  pages, admin pages, global header, bottom navigation and Energy
  achievement/progress layer.
- `docs/GENERAL/specification.md` — derived early project
  specification with UI canon, header, bottom navigation and Energy
  live-generation rules.
- `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_0-100.md` — early cycle history for page,
  FAQ, Hub, shop, skins, navigation and first route/page refactors.
- `docs/SSOT/ENERGY_RULES.md` — Energy calculation and display truth:
  client shows backend snapshot, no client-side economic invention.
- `docs/SSOT/PANELS_SSOT.md` — strict Panels page structure:
  description block, 2x2 actions, Active/Archive and one switched list.
- `docs/SSOT/HUB_SSOT.md` — Hub is navigation only, not marketplace,
  not payment flow and not diagnostic surface.
- `docs/NORM/RANKS_RULES.md` — Ranks is `me + TOP-100`, not an Energy
  level catalog.
- `docs/NORM/REFERRALS_RULES.md` — referral active status and bank-paid
  bonus canon.

## Early visual and page-audit sources

Read these after the baseline sources when visual meaning is needed:

- `docs/history/legacy_artifacts/docs/audits/FRONTEND_VISUAL_WHITE_SPOTS_AUDIT_2026_04_04.md`.
- `docs/history/legacy_artifacts/docs/audits/FRONTEND_STRICT_AUDIT_HEALING_CHECKLIST_2026_04_07.md`.
- `docs/history/legacy_artifacts/docs/audits/FRONTEND_SANDBOX_VISUAL_ACTUALIZATION_2026_04_07.md`.
- `docs/history/legacy_artifacts/docs/audits/FRONTEND_REPAIR_PLAN_581_610_2026_04_08.md`.
- `docs/history/legacy_artifacts/docs/audits/WEB_PORTAL_VISUAL_WAVE_576_580_2026_04_08.md`.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_EXCHANGE_WITHDRAW_745_748_2026_04_09.md`.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_HUB_BROWSER_SHOP_PROFILE_749_752_2026_04_09.md
  `.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_REFERRALS_PANELS_TASKS_RANKS_753_758_2026_04_0
  9.md`.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_ADMIN_USERS_BANK_WITHDRAWALS_LOGS_REPORTS_759_
  763_2026_04_09.md`.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_ADMIN_HUB_SUPPORT_CLUSTER_764_767_2026_04_09.m
  d`.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_ADMIN_HELPER_NAV_AND_BUTTONS_768_772_2026_04_0
  9.md`.
- `docs/history/legacy_artifacts/docs/audits/PAGE_AUDIT_ALIAS_AND_WRAPPER_SURFACES_773_774_2026_04_09.
  md`.

## Later corrective sources

Later sources may override the old baseline when they contain a direct
user correction:

- `docs/history/legacy_artifacts/docs/NORM/CHAT_TRANSCRIPT.md`.
- `docs/GENERAL/CURRENT_DECISIONS.md`.
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`.
- `docs/history/legacy_artifacts/docs/NORM/CHAT_BRANCHES/18.md`.
- `docs/history/legacy_artifacts/docs/NORM/CHAT_BRANCHES/19.md`.
- `docs/history/legacy_artifacts/docs/NORM/CHAT_BRANCHES/20.md`.
- `docs/history/legacy_artifacts/docs/audits/FRONTEND_VISIBLE_ELEMENTS_CHAT_AGREEMENT.md`.
- `docs/history/legacy_artifacts/docs/audits/CHAT_VISIBLE_FRONTEND_AGREEMENT.md`.

## Priority rule

Priority is:

1. latest direct user answer in chat;
2. current SSOT/NORM rule;
3. ancient baseline page-description source;
4. later audit interpretation;
5. code snapshot.

The code snapshot does not create product canon by itself. It only shows
what currently exists.

## Confirmed correction from branch 21

The user clarified that the true page descriptions were ancient, near
the
beginning of the archive, not the recent v168_52-v168_61 audit files.
The v168_61 answer listed recent documents and therefore missed the
intended source layer.

## Resulting operator obligation

Any future frontend pass must state which ancient page source was read
before changing or questioning a page. If no ancient source covers the
screen, that absence must be written explicitly.

## v168_63 original PDF sources

A new historical source layer was added at:
`docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/`.

This layer has higher historical value than late audit summaries, but it
must not automatically override the current user-approved canon. Before
asking about page composition or restoring elements, compare:

1. original PDF source;
2. current frontend documents;
3. latest chat decisions;
4. current code state.

The 100-question sheet is the required approval gate for restoring old
page elements.

## v168_63 original PDF sources

A new historical source layer was added at:
`docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/`.

This layer has higher historical value than late audit summaries, but it
must not automatically override the current user-approved canon. Before
asking about page composition or restoring elements, compare:

1. original PDF source;
2. current frontend documents;
3. latest chat decisions;
4. current code state.

The 100-question sheet is the required approval gate for restoring old
page elements.



## v168_64 recovered function canon

Read before changing frontend functions:
`docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md`.

Original PDF files are not retained and are not permanent canon. The MD
historical intent layer is only a comparison source. User Q/A answers are
canonical. Restore lost functions only after explicit Q/A confirmation.
