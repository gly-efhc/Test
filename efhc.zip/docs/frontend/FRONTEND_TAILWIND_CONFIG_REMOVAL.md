# FRONTEND_TAILWIND_CONFIG_REMOVAL

Version: v169_11 / work pass
Date: 2026-05-27
Status: active cleanup canon

## Decision

The user explicitly ordered removal of the unnecessary Tailwind legacy
configuration file after the completed migration to:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

## Implemented change

`frontend/tailwind.config.js` is deleted from HEAD.

The active Tailwind setup is now:

- `frontend/postcss.config.js` with `@tailwindcss/postcss`;
- `frontend/src/styles/globals.css` with `@import "tailwindcss"`;
- EFHC design tokens in the `@theme` block.

## Guard rule

`frontend/tailwind.config.js` must not exist in HEAD. The project must not recreate it by default.
A future cycle may reintroduce it only with a documented Tailwind v4
compatibility reason and an explicit user-approved task.

## Cycle remap

work pass is assigned to Tailwind config removal and documentation
actualization.

The planned Admin Shop cycle shifts to:

`1333 — Shop admin actions and Web3 payment separation on UI Kit`.
