# Profile legacy surface replacement mapping

Status: active replacement mapping for the current public profile release.

## Decision

The canonical `/web-profile` route uses one profile hero, one primary tab
navigation and one active content surface at a time:

- Profile;
- Wallet;
- History with withdrawal history;
- FAQ launcher.

The following historical visual components remain in the archive for audit and
possible later reuse, but are not mounted by the public route:

- `WebProfileAccountDashboard.tsx`;
- `PublicProfileTrustLayer.tsx`.

## Root cause

Mounting both historical components above the real tab content produced three
competing account interfaces, excessive page height and visually narrow cards
on mobile screens.

## Replacement

- account identity: `efhc-profile-hero`;
- navigation: `efhc-profile-tabs`;
- profile data and settings: active Profile tab;
- wallet list and actions: `ProfileWalletSection`;
- account and withdrawal history: `ProfileHistorySection`;
- full FAQ: `/faq` through the FAQ tab launcher.

No public route, wallet action, history endpoint, localization language or
economic rule was removed.
