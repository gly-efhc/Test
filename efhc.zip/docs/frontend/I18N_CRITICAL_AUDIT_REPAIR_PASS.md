# I18N_CRITICAL_AUDIT_REPAIR_PASS

Status: active repair completed for critical audit blockers.
Source audit: `docs/history/legacy_artifacts/docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md`.
Source summary: `docs/history/legacy_artifacts/reports/generated/i18n_audit_summary_v169_45.json`.

## Scope

This pass repairs the critical localization defects found in the v169.45 audit
while keeping EFHC runtime, economics, backend routes, admin Russian-first canon
and visual work intact.

## Fixed critical findings

| Audit ID | Finding | Repair |
|---|---|---|
| C1 | Player-facing fallback chain used Russian before English | `frontend/src/lib/i18n.ts` now falls back to embedded English for missing player keys. `ru[k]` and `embeddedRu[k]` are not used in `tFromDicts()` fallback. |
| C2 | Hindi `wallet.linked_wallets_count` lost `{count}` | Hindi value now keeps `{count}`. |
| C3 | Hindi `withdraw.request_number` lost `{id}` | Hindi value now keeps `{id}`. |
| C4 | 5 public keys were empty in all 13 languages | The five keys now have non-empty values in all 13 locale files. |

## Additional audited repairs

- `frontend/src/pages/app.tsx` admin route guard fallback messages are now
  English in the main app shell instead of hardcoded Russian.
- `frontend/src/components/ShopLayout.tsx` no longer uses the hardcoded Russian
  fallback `Профиль`.
- Layout description fallback now delegates through `tFromDicts()` instead of
  forcing `ruDict` for missing description keys.
- `ops/i18n/audit_bot_texts_parity.py` now uses
  `importlib.util.spec_from_file_location` instead of the broken
  `spec_from__file__location` token.
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` no longer claims all languages are
  fully quality-complete. It now distinguishes structural parity from
  translation-quality status.

## Locale keys filled in all 13 languages

- `energy.hub_action`
- `energy.hub_action_note`
- `energy.profile_wallet_action`
- `energy.profile_wallet_note`
- `profile.independent_shell_badge`

## Guard coverage

`tests/architecture/test_i18n_critical_contract.py` checks:

- English-first player fallback chain;
- non-empty values for the five critical keys in all locale files;
- Hindi placeholder preservation for `{count}` and `{id}`;
- locale key parity after repair;
- absence of hardcoded Russian public-shell fallbacks identified by the audit;
- presence of the imported audit source and generated repair evidence.

## Boundary

This pass does not claim full translation completion for all 13 languages.
The audit still reports a public untranslated tail and FAQ identical-to-English
items. Those are planned for the next i18n repair passes.

## Next language repair work

1. Public UI untranslated key remediation for DE/FR/ES/IT/TR/PL/DA/HI/ID/SW and
   UK where needed.
2. Critical error/confirmation copy pass for wallet, shop, exchange, history and
   withdraw surfaces.
3. FAQ wave-3 translation repair for identical English answers/questions and
   `TRANSLATION_STATUS.md` refresh.
