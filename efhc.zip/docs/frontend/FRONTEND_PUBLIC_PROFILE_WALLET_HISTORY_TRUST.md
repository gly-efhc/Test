# FRONTEND_PUBLIC_PROFILE_WALLET_HISTORY_TRUST

Дата: 2026-05-31
Статус: active public UI canon
Цикл: 1351
Архив: v169_30

## 1. Назначение

work pass завершает первую public UI interactivity wave через Web-Profile:
профиль, кошелёк и история получают единый mobile-first trust layer.

Цель: дать пользователю быстрый понятный обзор аккаунта без открытия admin
контуров, route diagnostics, raw payload или скрытых execution logs.

## 2. Добавленный компонент

`frontend/src/components/public/PublicProfileTrustLayer.tsx`

Компонент подключён в:

`frontend/src/features/profile/WebProfilePage.tsx`

## 3. Разрешённые данные

Разрешено показывать:

- username;
- level;
- VIP / Active status;
- total / main / bonus balances с учётом hide_balances;
- количество кошельков;
- connected / not connected wallet state;
- primary wallet в сокращённом виде;
- количество history records;
- количество withdraw requests;
- latest withdraw status;
- safe CTA к вкладкам Wallet / History / FAQ.

## 4. Запрещено

Запрещено показывать:

- admin diagnostics;
- admin route labels;
- raw API payload;
- raw TON proof payload;
- hidden task execution log;
- operator internals;
- endpoint names;
- mutation controls за пределами существующих safe tabs.

## 5. Использование Песочницы

Использованы donor patterns:

- `Песочница.xz` profile/cards/section дисциплина;
- Telegram Mini App template DisplayData rows;
- compact cell pattern;
- safe haptic tap;
- mobile section layout.

Runtime frameworks из песочницы не переносились.

## 6. Экономические инварианты

work pass не меняет экономику EFHC:

- balances читаются из существующего profile snapshot;
- wallet actions остаются в существующей Wallet tab;
- history actions остаются в существующей History tab;
- withdraw route не меняется;
- backend routes не добавлялись.
