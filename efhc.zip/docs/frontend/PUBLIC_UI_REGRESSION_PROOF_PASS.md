# PUBLIC_UI_REGRESSION_PROOF_PASS

Status: STATIC REGRESSION PROOF COMPLETE
Version: v169_40
Date: 2026-06-01

## Purpose

This document closes the public UI regression proof pass after
`docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`.

The proof connects public surfaces to their frontend pages, visible component
families, backend roads, SSOT/NORM anchors and guards. It is a static and
local architecture proof. It does **not** claim that real screenshots were
captured, that Playwright ran against live `localhost:3000`, or that GitHub CI
is green.

## Required reading performed

- `docs/AI/AI_DOCS_INDEX.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- active cycle index documents
- `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`
- `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`
- `docs/frontend/FRONTEND_COMPONENT_REGISTRY.md`
- `docs/frontend/FRONTEND_VISUAL_ELEMENTS_REGISTRY.md`
- `docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md`
- `docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md`
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
- `docs/history/legacy_artifacts/map_element.md`
- selected public page/component/backend route files

## Regression proof matrix

| Surface | Route | Frontend page | Components | Backend roads | SSOT/NORM anchor | Guard | Regression verdict |
|---|---|---|---|---|---|---|---|
| Energy | `/` | `frontend/src/pages/index.tsx` | LayoutContext, KwhIcon, GameActionCard, EnergyGauge/GameHero family via shell registries | `POST /sync`, `GET /user/me/panels-summary via Layout snapshot context` | `docs/SSOT/ENERGY_RULES.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/architecture/test_public_ui_qa_preparation_complete.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS_WITH_NOTE |
| Panels | `/panels` | `frontend/src/pages/panels.tsx` | Card, Button, Badge, Skeleton, EmptyState, LayoutContext | `GET /user/me/panels-summary`, `GET /panels/active`, `GET /panels/archive`, `POST /panels/activate` | `docs/SSOT/PANELS_SSOT.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| Exchange | `/exchange` | `frontend/src/pages/exchange.tsx` | ExchangePanel, PublicExchangeInteractivePreview, TelegramEmptyState, LayoutContext | `GET /exchange/preview`, `POST /exchange/convert`, `GET /exchange/history` | `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_exchange_convert_flow.py`, `tests/architecture/test_frontend_e2e_scope_guard.py` | STATIC_PROOF_PASS |
| Tasks | `/tasks` | `frontend/src/pages/tasks.tsx` | Card, Button, Badge, Modal, AdsBanner, PublicEngagementPreview, GameHero, GamePageShell | `GET /tasks/catalog`, `GET /tasks/my`, `POST /tasks/claim`, `GET /ads/slot`, `POST /ads/callback/{provider}` | `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| Referrals | `/referrals` | `frontend/src/pages/referrals.tsx` | ReferralsTabs, PublicEngagementPreview, EmptyState, Card, Button, Badge | `GET /referrals/stats/me`, `GET /referrals/counters`, `GET /referrals/active/me`, `GET /referrals/inactive/me` | `docs/NORM/REFERRALS_RULES.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| Active referrals | `/referrals/active` | `frontend/src/pages/referrals/active.tsx` | ReferralListPage, ReferralsTabs, EmptyState | `GET /referrals/active/me`, `GET /referrals/stats/me` | `docs/NORM/REFERRALS_RULES.md`, `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| Inactive referrals | `/referrals/inactive` | `frontend/src/pages/referrals/inactive.tsx` | ReferralListPage, ReferralsTabs, EmptyState | `GET /referrals/inactive/me`, `GET /referrals/stats/me` | `docs/NORM/REFERRALS_RULES.md`, `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| Ranks | `/ranks` | `frontend/src/pages/ranks.tsx` | Card, Button, Badge, Skeleton, EmptyState, PublicEngagementPreview | `GET /ranks/my-plus-top/me`, `GET /ranks/top/me`, `GET /ranks/referrals/my-plus-top/me`, `GET /ranks/referrals/top/me` | `docs/NORM/RANKS_RULES.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| Profile / Wallet / History | `/web-profile` | `frontend/src/pages/web-profile.tsx` | WebProfilePage, ProfileWalletSection, ProfileHistorySection, PublicProfileTrustLayer, LayoutContext | `GET /wallets/me`, `GET /wallets/me/history`, `GET /user/settings`, `GET /panels/self-summary` | `docs/SSOT/WALLETS_TONCONNECT_SSOT.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS_WITH_NOTE |
| FAQ | `/faq` | `frontend/src/pages/faq.tsx` | FaqHeader, FaqSearchBar, FaqNoResultsState, FaqVerticalTree, Card | `static FAQ catalog; no runtime backend road required` | `docs/SSOT/FAQ_SSOT.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS |
| HUB | `/hub` | `frontend/src/pages/hub.tsx` | HubPage, Modal, Deposit/EFHC handoff action cards | `POST /hub/efhc-handoff`, `GET /hub/shop-truth`, `GET /hub/browser-shop-bootstrap` | `docs/SSOT/HUB_SSOT.md`, `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_hub_deposit_button.py` | STATIC_PROOF_PASS |
| Browser Shop | `/browser-shop` | `frontend/src/pages/browser-shop.tsx` | BrowserShopPage, ShopLayout, TonConnectUI, product/order cards | `GET /shopfront/bootstrap`, `GET /shopfront/catalog`, `POST /shopfront/create-intent`, `GET /shopfront/intent-status`, `GET /hub/shop-truth` | `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md`, `docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md`, `docs/NORM/UNIFIED_EXTERNAL_STOREFRONT_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS_WITH_NOTE |
| Withdraw | `/withdraw` | `frontend/src/pages/withdraw.tsx` | Button, SurfaceFactsStrip, Card, EmptyState, TelegramStatusBadge, TelegramInfoBlock, LayoutContext | `GET /withdraw/list`, `POST /withdraw/request`, `POST /withdraw/{request_id}/cancel`, `GET /withdraw/{request_id}`, `GET /wallets/me` | `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`, `docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md`, `docs/SSOT/WITHDRAW_OUTCOME_SERVICE_SSOT.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_withdraw_request_flow.py` | STATIC_PROOF_PASS |
| Ads | `/ads` | `frontend/src/pages/ads.tsx` | Button, Card, Tasks compatibility redirect shell | `GET /ads/slot`, `POST /ads/callback/{provider}`, `/tasks canonical earning route` | `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | `tests/architecture/test_public_ui_regression_proof.py`, `tests/frontend/e2e/test_smoke_public_pages.py` | STATIC_PROOF_PASS_WITH_NOTE |

## Public boundary checks

- Public routes remain outside `frontend/src/pages/admin/*`.
- Admin diagnostics/debug surfaces are not listed as public surfaces.
- `/browser-shop` remains a special shop shell and must not receive the public
  public bottom nav.
- `/ads` remains a compatibility/public earning route, not an operator trace
  screen.
- Error handling after the v169_39 residual fixes uses localized
  `common.session_expired` and `common.load_error` keys in all 13 locale files.
- E2E interaction smoke files now prove intended POST calls under
  `EFHC_RUN_E2E=1`, but the browser run was not executed locally.

## Sandbox usage

`docs/history/legacy_artifacts/map_element.md` and the sandbox archives were used as reference navigation for
Telegram Mini App shell, TonConnect, card/list/control, loading/skeleton,
shop-card and mobile touch patterns. No Vue/Solid/Nuxt/Vanilla runtime code,
CI configuration, lock file, or foreign wallet transaction logic was imported
into EFHC.

## Verdict semantics

- `STATIC_PROOF_PASS`: page, component family, backend road, SSOT/NORM anchor
  and guard are present in the archive.
- `STATIC_PROOF_PASS_WITH_NOTE`: the surface is present and anchored, but the
  proof has an explicit caveat such as delegated feature component, alias route,
  catalog-only route, or runtime/browser behavior not executed locally.
- `FAIL`: confirmed regression in the current archive. No `FAIL` surfaces were
  found in this static proof pass.

## Next required work

The next range extension checkpoint should decide
whether the next active range focuses on real browser screenshot capture,
public beauty/visual strengthening, Telegram Mini App shell polish, or deeper
TonConnect/Wallet UX.
