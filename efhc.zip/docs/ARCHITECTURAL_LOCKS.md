# Architectural Locks

Статус: NORM (нормативный документ разработки). Якорь SSOT:
docs/SSOT_INDEX.md

Назначение:
- Этот документ фиксирует архитектурные запреты и ограничения
  разработки.
- Продуктовые нормы (термины, экономика, банк, выводы, TON) живут в
docs/EFHC_CANON.md и docs/TERMS_GLOSSARY.md.

Приоритет и конфликты:
- Источник приоритета документов: docs/SSOT_INDEX.md.
- Если DERIVED-документ (architecture/specification и т.п.) конфликтует
  с
NORM, он подлежит обновлению.
- Если код конфликтует с NORM, это дефект: требуется правка кода или
  NORM
через осмысленное изменение и тесты.

Инструменты контроля:
- ops/canon_rules.yaml и ops/canon_guard.py реализуют проверки канона,
но не заменяют SSOT_INDEX и NORM-документы.

---

## LOCK: runtime logs location

Правило:
- Все runtime-логи проекта пишутся только в `reports/`.
- Запрещено создавать log/session/strict файлы и каталоги
  вне `reports/`.


## LOCK: tg_id only in public runtime surfaces

Правило:
- В runtime-коде, API, логах, событиях и схемах допускается только
  tg_id.
- Запрещены любые алиасы внешнего идентификатора пользователя.

Разрешено:
- Внутренний PK БД может называться user_pk/row_id, но он не должен
утекать наружу и не должен подменять tg_id.

Админ-контур:
- allowlist/авторизация админа: только по tg_id (Settings/ENV).
- public row_id запрещён везде, включая admin.

---

## LOCK: UI navbar fixed (6 tabs, order)

Запрещено менять состав и порядок нижней навигации.

Канон (ровно 6 вкладок, фиксированный порядок): 1) Energy 2) Panels 3)
Exchange 4) Tasks 5) Referrals 6) Ranks

Любые изменения допускаются только через обновление NORM/SSOT и guard.

---

## LOCK: UI labels always English

Запрещено локализовать кнопки/лейблы/названия вкладок/уровней.

Канон:
- UI labels (tabs/buttons/field labels) — всегда EN.
- Levels / ranks names — всегда EN.
- Выбор языка влияет только на descriptions/описания.

---

## LOCK: Profile/Settings entrypoint + SSOT settings list

Канон входа: Profile/Settings открывается по нажатию на аватар в левом
верхнем углу.

SSOT список настроек (утверждён): 1) Telegram display name (RO) 2)
Username (RO) 3) VIP badge (RO) 4) Avatar (Telegram default + custom +
reset) 5) Descriptions language (13 langs, EN first) 6) UI sounds
(on/off) 7) Sound volume 8) Sound pack 9) Haptics (on/off) 10) Hide
balances 11) Show decimal detail (still 8 decimals) 12) Reduce motion
13) Confirm before purchase 14) Confirm before withdraw request 15)
Confirm before convert kWh→EFHC 16) Confirm before watch ad 17) In-app
toasts 18) Important alerts only 19) FAQ 20) Support chat 21) Terms 22)
Privacy 23) Reset settings

---

## LOCK: Admin entry via Profile (tg_id allowlist)

Канон:
- Пункт Admin Panel виден только если tg_id входит в allowlist.
- Элемент отображается только внутри Profile/Settings.



## Economy SSOT Locks: Generation & Exchange

SSOT: механика обмена и вывода — см.
docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

SSOT: механика панелей — см. docs/PANELS_SSOT.md


- **Lock: total_generated_kwh is append-only** (never decreases).
- **Lock: exchanged_kwh_total is append-only** (never decreases).
- **Mirror formula (source of truth):**
  `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`
- **EXCHANGE_ALL** MUST:
  - increase `exchanged_kwh_total` by `available_kwh_before`
  - credit EFHC **MAIN** 1:1
  - never mutate `total_generated_kwh`
  - set stored `available_kwh` only as the mirror result.


## Общие логи (reports/)

Подробные логи изменений ведутся только в `reports/`.
`reports/REPORTS_INDEX.md` — каноничный нумерованный реестр
`append-only`: каждая новая запись добавляется строго по порядку
и получает следующий номер без пропусков.
