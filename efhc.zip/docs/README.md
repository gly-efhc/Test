# EFHC — документация единого FRONTEND-архива (v747)

Новый OWNER-канон: тематические разделы [`frontend`](frontend/INDEX.md), [`backend`](backend/INDEX.md), [`shared`](shared/INDEX.md). Полный предметный реестр охватывает в том числе действующие документы по прежним защищённым путям. Их физический перенос требует отдельной миграции всех потребителей, см. [`план`](shared/architecture/PHYSICAL_DOCS_RELOCATION_DEPENDENCY_PLAN_v747.md).

Действующий запуск и нормативный порядок чтения определяются `START_HERE.md`, `KERNEL.md` и [`ACTIVE_DOCUMENTATION_INDEX.md`](SSOT/ACTIVE_DOCUMENTATION_INDEX.md). Предметные индексы не изменяют Kernel whitelist и не присваивают `DRAFT` статус `ACTIVE`.

Решения OWNER: RBAC (admin/support=Moderator), финансы (370/400), FAQ FRONTEND, Панели (новое списание 100 EFHC: EFHCb → EFHCm → kWh→EFHCm→списание; исторический возврат отменён; PostgreSQL-квалификация открыта). См. [`решения`](shared/decisions/OWNER_DECISIONS_v747.md).
