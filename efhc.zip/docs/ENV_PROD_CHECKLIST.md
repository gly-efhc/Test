# EFHC production environment checklist

Use `.env.example` as the complete field template. Production `.env` is
never committed or included in a release archive and must use mode `600`.

## Required groups

- project domains and public URLs;
- standard PostgreSQL credentials and DSNs;
- Telegram bot token, webhook secret and Admin identifiers;
- TON API and approved wallet/Jetton addresses;
- scheduler interval, timeout and concurrency values;
- versioned backend and frontend image tags;
- Docker log size and file-count limits;
- backup directory, retention, encryption and off-site target.

## Container exposure

- backend receives the complete server-side `.env`;
- PostgreSQL receives only database name, user and password;
- Caddy receives only application domain, API domain and ACME email;
- frontend receives only declared public build arguments.

## Final check

No placeholders, secrets in source, production `.env` in archive,
provider-specific mandatory service, unbounded Docker logs or unversioned
application image tags are allowed.
