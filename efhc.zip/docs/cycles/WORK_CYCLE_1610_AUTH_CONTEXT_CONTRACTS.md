# Рабочий цикл 1610 — AuthContext contracts и resolver interfaces

Статус: `ЗАВЕРШЁН ЛОКАЛЬНО`.
Версия: `v172.07`.

## 1. Цель

Создать provider-neutral contracts до появления реального resolver и
DDL. Новый endpoint contract не должен зависеть от `global_id`, а auth
secrets не должны попадать в diagnostics или logging extras.

## 2. Реализованный объём

- immutable `AuthContext` из `GlobalId` и `VerifiedIdentity`;
- безопасный `AuthContextResponse` с `global_id`, `provider`, `roles`;
- `IdentityResolver` Protocol;
- outcomes `resolved`, `not_found`, `conflict`;
- recursive auth diagnostic redaction с depth/item limits;
- расширение общего logging redaction vocabulary;
- JSON contract, exporter и active guard;
- exact Operator Kernel route цикла 1610;
- unit, negative, boundary и architecture tests.

## 3. Инварианты

- `global_id` остаётся единственным account owner;
- `AuthContext` не содержит `global_id` или wallet address;
- raw input не может стать context или resolver input;
- `conflict` не выбирает один из аккаунтов;
- endpoint не раскрывает provider subject или session reference;
- diagnostics маскируют proof, token, initData, nonce и credentials;
- legacy runtime dependencies не переключаются.

## 4. Что запрещено и не выполнялось

- Alembic migration и PostgreSQL DDL/data;
- `user_identities` и реальный database resolver;
- locks, transactional resolve и auto-merge;
- account/session/challenge/roles storage;
- public login endpoint;
- TON Proof или Telegram adapter switch;
- historical backfill, dual-write и read switch;
- domain или financial ownership changes;
- GitHub CI.

## 5. Exit gate

```text
Новый endpoint contract не зависит от global_id.
Secrets не попадают в auth diagnostics.
```

## 6. Результаты тестирования

Fresh exact-HEAD collection содержит `2987` уникальных node ID.
Результат: `2815 PASSED`, `172 SKIPPED`, `0 FAILED`, `0 ERROR`.
Все skips вызваны только отсутствием реального PostgreSQL URL либо
отключённым browser E2E. Каждый node ID учтён ровно один раз в 12
завершённых JUnit-чанках. Защищённые 38 migration/model/financial
файлов совпадают с исходным HEAD по SHA-256.

## 7. Следующий цикл

`1611 — реальный PG-0, migration user_identities и constraints`.
Цикл 1611 нельзя закрыть без реального PostgreSQL proof.
