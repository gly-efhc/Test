# Work cycle 1598 — LEGACY alias and migration harness

Status: `LOCAL_SCOPE_COMPLETE / POSTGRESQL_RECONCILIATION_REQUIRED`.
Source: `EFHC_Bot_v171_94.zip`.
Target: `EFHC_Bot_v171_95.zip`.
Exact route: `user_id_legacy_alias_harness`.

## Implemented

- Added explicit SQLAlchemy synonym
  `User.legacy_runtime_id -> User.id`.
- Registered the future compatibility mapping
  `User.id -> User.user_id` as inactive.
- Added a pure deterministic future-backfill planner.
- Added read-only preflight SQL and guarded future apply SQL.
- Added range, duplicate and planned-collision checks.
- Added fail-closed patch-boundary and regression tests.

## Backfill doctrine

Historical rows with `users.user_id IS NULL` are planned as:

```text
users.user_id = users.id
```

Rows with an already assigned `user_id` are preserved. `global_id`, wallet
address and provider subject never derive the system ID.

## Not performed

- no database connection;
- no backfill execution;
- no new Alembic revision;
- no `NOT NULL` or primary-key switch;
- no AuthContext, route, service, DTO or frontend read switch;
- no financial or domain-owner mutation.

## Alias lifecycle

- created: cycle `1598`;
- future `User.id -> User.user_id` activation: not before cycle `1603`;
- planned compatibility removal: cycle `1698`;
- allowed active scopes: migration harness, reconciliation and tests.

## Exit gate

The cycle is locally complete only when the alias/harness boundary,
`tg_id` boundary, exact migration chain and targeted tests are green.
Real PostgreSQL reconciliation remains a separate required gate.

## Final local evidence

- exact collection: `2808` tests;
- passed: `2636`;
- skipped: `172`;
- failed: `0`;
- errors: `0`;
- PostgreSQL business integration inventory: `25`;
- executed PostgreSQL business tests: `0`;
- reconciliation: `NOT_RUN_DB_UNAVAILABLE`;
- architecture suite: `2384 passed`, `6 skipped`;
- protected runtime files: `479`;
- boundary violations: `0`.

The six architecture skips are retained environment-dependent tests.
The full regression skips are PostgreSQL or browser dependent. No test
was removed, marked xfail or rewritten to hide a runtime failure.

## Next cycle

Cycle `1599` owns real PostgreSQL reconciliation, preflight execution
and controlled preparation for historical backfill. The apply SQL from
this cycle remains disabled until that gate is proven.
