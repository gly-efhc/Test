# Work Cycle 1479 — Exchange Dashboard Support Widgets

**Version:** v170.55  
**Status:** DONE locally  

## Goal

Add lightweight Exchange dashboard support widgets without changing
exchange economy, backend routes, OpenAPI, idempotency or write-flow.

## Completed

- Added `ExchangeDashboardRuntime.tsx`.
- Integrated it into live `/exchange` route.
- Added visual summary for available kWh, exchangeable kWh, expected EFHC
  and main balance.
- Added kWh -> EFHC flow panel.
- Added one-way and no-reverse boundary chips.
- Added preview readiness panel.
- Added history boundary link to account history.
- Added locale keys for all active languages.
- Added architecture guard.

## Boundaries

- Exchange rate remains `1 kWh = 1 EFHC`.
- Reverse exchange remains forbidden.
- Dashboard widgets do not call write APIs.
- Existing `ExchangePanel` keeps protected conversion flow.
- Backend, DB, OpenAPI, dependencies, lock files and CI/workflows changed:
  no.

## Reference use

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Next safe cycle

`1480 — Web Profile / Account Center Dashboard Polish`.
