# Cycle 1565 — complete function linkage matrix

Input HEAD: `EFHC_Bot_v171_40.zip`.

Output target: `EFHC_Bot_v171_41.zip`.

## Scope

- Build a complete public and Admin action inventory.
- Verify UI, React Query, service, DTO, API, business, DB, response and
  invalidation/refetch boundaries.
- Remove remaining direct transport bypasses.
- Rebalance the Global Header.
- Keep the VIP status visible without a crown.
- Produce current browser screenshots.

## Implemented

- Added a shared Admin React Query transport and service boundary.
- Migrated active Admin pages and runtime components from direct transport.
- Added service/query boundaries for Shop launcher, skins, referrals and
  TonConnect.
- Added Profile wallet mutation hooks and cursor-list service ownership.
- Added a reproducible complete linkage generator and fail-closed guard.
- Rebuilt the Global Header into a uniform action grid.
- Removed the VIP crown while preserving the permanent VIP status text.

## Linkage result

- Active actions: `81`.
- Public actions: `38`.
- Admin actions: `43`.
- Complete: `81`.
- Partial: `0`.
- Direct UI transport files: `0`.
- Strict OpenAPI operation count: `132`.

## Browser result

- Header states: inactive VIP, active VIP and narrow mobile.
- Admin routes: `17 / 17`.
- Admin launcher DOM clicks: `12 / 12`.
- Horizontal overflow: `0` in the controlled proof.

## Non-claims

This cycle does not claim real production PostgreSQL mutations, transaction
isolation, fresh GitHub CI, live Telegram or a real TonConnect transaction.
