# Рабочий цикл 1606 — API-контракт global_id

Исходный HEAD: `EFHC_Bot_v172_02.zip`.
Целевой HEAD: `EFHC_Bot_v172_03.zip`.

## Цель

Создать единственный изолированный контракт `global_id` между backend
DTO, Pydantic/OpenAPI schema и frontend DTO без переключения активных
LEGACY routes.

## Реализация

- каноническое wire-поле: `global_id`;
- wire-тип: `string`;
- format: `efhc-global-id`;
- pattern: `^[0-9]{10}$`;
- min/max length: `10`;
- `0000000000` отклоняется runtime-валидацией;
- backend DTO: `GlobalIdRequest`, `GlobalIdResponse`;
- frontend DTO: `GlobalIdRequestDto`, `GlobalIdResponseDto`;
- единый воспроизводимый fixture:
  `contracts/identity/global_id_api_contract_v1.json`;
- fail-closed guard сравнивает backend, OpenAPI fixture и frontend.

## Граница цикла

Действующие routes, schemas, services и CRUD не импортируют новый
контракт. LEGACY envelopes с физическим именем `user_id` сохранены до
назначенного switch-stage. DDL, backfill и ownership не изменялись.

## Остаток

После цикла 1606 остаётся `94` цикла до 1700 включительно. Следующий
цикл: `1607 — Cross-language разделение GlobalId и TelegramId`.

## Итог тестирования

- exact-tree collection: `2899`;
- `PASSED`: `2727`;
- `SKIPPED`: `172`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Пропуски: 95 browser E2E, 72 real PostgreSQL integration,
4 Postgres-only CI и 1 проверка без `DATABASE_URL`. Skip не считается
реальным PostgreSQL или Chromium proof.

Frontend release-assets: PASS, 29 файлов. Полный Next.js build и
performance budgets не выполнены: offline npm cache не содержит `zod`,
а `.next/build-manifest.json` отсутствует.

PostgreSQL reconciliation: `БЛОКИРОВАНО_СРЕДОЙ`; backfill, dual-write,
read switch и financial ownership switch остаются `false`.
