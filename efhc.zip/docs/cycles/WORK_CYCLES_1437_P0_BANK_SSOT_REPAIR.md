# Cycle 1437 — P0 Bank SSOT repair

Status: DONE locally in `v170.13`.
Base HEAD: `EFHC_Bot_v170_12_cycle_1436_user_decisions_doc_update.zip`.

## Goal

Close linkage finding `F-001`: admin bank mint/burn must not depend on tables outside ORM/migration SSOT.

User decision applied:

- do not create a separate `efhc_mint_burn` ledger/table;
- do not create a new ledger for rare admin mint/burn operations;
- use existing official/canonical tables and ledger surfaces only.

## Runtime repair

Changed:

- `backend/app/services/admin/admin_bank_service.py`
- `backend/app/services/transactions_service.py`

Result:

- `/admin/bank/mint` now delegates bank supply change to `transactions_service.mint_bank_efhc()`;
- `/admin/bank/burn` now delegates bank supply change to `transactions_service.burn_bank_efhc()`;
- canonical bank balance remains `efhc_core.bank_balance`;
- canonical idempotency/audit ledger is `efhc_core.efhc_transfers_log`;
- admin action audit remains `efhc_admin.admin_action_log` through `AdminLogger.write()`;
- the runtime dependency on the former separate mint/burn ledger was removed;
- the bank rollback/list helper now reads from `efhc_core.efhc_transfers_log` instead of the former rollback journal.

No migration was added. No new table was created. No EFHC economics were changed.

## Guards / tests

Added:

- `tests/architecture/test_admin_bank_ssot_repair.py`

Protected checks:

- `test_bank_money_routes_use_only_migrated_tables`
- `test_money_routes_have_service_layer`
- `test_no_direct_balance_write_outside_transactions_service`
- `test_admin_bank_mint_burn_are_idempotent`
- `test_admin_bank_mint_burn_have_admin_guard`
- `test_admin_bank_mint_burn_write_audit_log`
- `test_frontend_admin_bank_waits_for_backend_confirmation`

## Local validation performed

Executed locally:

```text
python -m pytest tests/architecture/test_admin_bank_ssot_repair.py -q
# 7 passed

python -m pytest   tests/architecture/test_admin_bank.py   tests/architecture/test_admin_bank_variant_a.py   tests/architecture/test_admin_bank_ssot_repair.py   tests/architecture/test_financial_integrity.py   tests/architecture/test_migration_0001_orm_ssot_sync.py   -q
# 35 passed

python -m py_compile backend/app/services/transactions_service.py backend/app/services/admin/admin_bank_service.py backend/app/routes/admin_routes.py
# passed
```

Additional attempted check:

```text
python -m pytest tests/architecture/test_bank_runtime_invariants.py -q
# 1 skipped; pytest returned status 5 because the file had no runnable test after import-skip in this local environment.
```

Not claimed:

- no GitHub CI green;
- no full pytest green;
- no frontend build green;
- no release-ready;
- no browser screenshots;
- no live Telegram/TonConnect proof.

## Remaining blockers

The archive is still not release-ready because the active linkage audit still has open blockers after F-001:

- `F-002` / cycle 1438: deposit watcher must use canonical `wallet_bindings`;
- `F-003` / cycle 1439: admin reports must use `efhc_core.bank_balance`;
- `F-004` / cycle 1440: Admin Hub canonical route `/admin/hub/*`;
- `F-005` / cycle 1441: admin wallet reset must unbind canonical `wallet_bindings`;
- `F-006` / cycle 1442: OpenAPI rebuild and strict contract gate;
- `F-007/F-008` / cycle 1443+: UI state guards and full linkage architecture tests.

Next safe cycle: `1438 — P0 Deposit watcher wallet SSOT repair`.
