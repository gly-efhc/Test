# Work Cycle 1594 — UserId contract and negative guards

Status: `LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_CI_REQUIRED`.  
Source HEAD: `EFHC_Bot_v171_90.zip`.  
Target HEAD: `EFHC_Bot_v171_91.zip`.  
Exact Operator Kernel route: `user_id_contract_foundation`.

## 1. Completed scope

Cycle 1594 converts the provider-independent identity doctrine into an
executable, side-effect-free contract without changing database schema or
runtime ownership.

Implemented:

- internal `UserId` range `1..9999999999`;
- exact ten-digit external representation;
- separate `TelegramId`, `UserIdDisplay` and `ExternalUserId` types;
- strict parser, formatter and validator;
- rejection of booleans, floats, coercion, signs, whitespace and Unicode
  digits;
- V2 negative identity guard;
- semantic categories and sunset cycles for all legacy `global_id` runtime files;
- exact SHA-256 patch lock for protected schema and ownership files;
- current-doctrine and LEGACY compatibility tests;
- reconciliation V2 report metadata for source and target HEAD.

## 2. Explicit non-scope and patch boundary

Cycle 1594 does not:

- add or change an Alembic revision;
- add `users.user_id` to the ORM;
- modify `users.id` or `users.global_id`;
- change `AuthContext` or FastAPI dependencies;
- switch any domain owner read or write;
- change frontend ownership state;
- change balances, kWh, panels, finance, referrals, ranks or roles.

The patch-boundary manifest protects `485` files under models, migrations,
services, CRUD, routes, schemas and `frontend/src`. Generated cache files are
ignored explicitly and cannot create a false ownership-drift finding.

## 3. Executable type contract

The side-effect-free foundation is located in:

```text
backend/app/identity/__init__.py
backend/app/identity/types.py
```

Exports:

```text
UserId
TelegramId
UserIdDisplay
ExternalUserId
InvalidUserId
validate_user_id()
format_user_id()
parse_user_id()
```

The public notation is `^\d{10}$`. Runtime validation uses the stricter ASCII
implementation `^[0-9]{10}$`, so non-ASCII digit glyphs are rejected.
`0000000000` is forbidden. The module is not wired into ORM, DTO, routes or
domain services in this cycle.

## 4. Negative guard V2

The identity boundary blocks:

- growth of the tracked legacy identifier surface;
- any new `get_current_global_id()` dependency;
- direct and indirect `user_id = global_id` mixing;
- `UserId(global_id)` and provider-derived keyword or mapping values;
- `wallet_address`, `ton_wallet`, `canonical_address` or provider subject used
  as a system identifier;
- equivalent TypeScript assignments.

Final result:

```text
Telegram-specific allowlist files: 21
LEGACY runtime baseline files: 179
Tracked runtime files: 200
Files using get_current_global_id: 20
Semantic identity-mix offenders: 0
Guard result: PASS
```

## 5. Tests and evidence

### Collection

```text
Command: PYTHONPATH=backend python -m pytest --collect-only -q
Exit code: 0
Collected: 2740 unique tests
```

### Full local suite

The exact collection was split into eight non-overlapping node-id segments.
Each segment produced its own JUnit XML and exit-code file.

```text
2740 total
2568 passed
172 skipped
0 failed
0 errors
56.178 s aggregate JUnit time
```

Skip reasons:

```text
95 — EFHC_RUN_E2E=1 is required for browser E2E smoke tests
72 — DATABASE_URL/ASYNC_DATABASE_URL is required for PostgreSQL integration
4  — DATABASE_URL/ASYNC_DATABASE_URL is required for Postgres-only CI
1  — DATABASE_URL is not set
```

Summary:
`reports/generated/cycle_1594_pytest_summary_v171_91.json`.

JUnit:
`reports/junit/cycle_1594_full_chunk_01_v171_91.xml` through
`reports/junit/cycle_1594_full_chunk_08_v171_91.xml`.

### Targeted contract suite

```text
Command: PYTHONPATH=backend python -m pytest -q \
  tests/efhc_backend/identity/test_user_id_types.py \
  tests/architecture/test_user_id_contract_foundation.py \
  tests/architecture/test_identity_architecture_migration_guard.py \
  tests/architecture/test_global_id_access_contracts.py \
  tests/architecture/test_heal0045_global_id_identity_canon.py \
  tests/test_no_banned_identifiers.py
Exit code: 0
43 passed, 0 failed, 0 skipped
```

### PostgreSQL inventory

```text
Command: PYTHONPATH=backend python -m pytest -q -m integration --collect-only
Exit code: 0
25 integration tests collected; 2715 deselected
```

Runtime integration was not claimed:

```text
25 PostgreSQL integration tests skipped: database URL unavailable
3 collection-level skips: aiogram/psycopg unavailable
0 failed, 0 errors
```

### Other local checks

```text
compileall: exit 0
identity audit: exit 0
negative identity guard: exit 0
patch-boundary guard: exit 0
reconciliation: exit 3, NOT_RUN_DB_UNAVAILABLE
npm ci --offline: exit 1, required zod package was not cached
Ruff/Mypy/Bandit: NOT_RUN, executables unavailable
frontend typecheck/build/E2E: NOT_RUN, node_modules unavailable
```

## 6. Reconciliation

No data-changing operation exists in this cycle. The read-only reconciliation
collector returned:

```text
schema: EFHC_IDENTITY_RECONCILIATION_V2
source: EFHC_Bot_v171_90.zip
target: EFHC_Bot_v171_91.zip
status: NOT_RUN_DB_UNAVAILABLE
financial tolerance: 0.00000000
```

No database value is represented as checked locally.

## 7. Rollback

Rollback is source-only:

1. restore exact `v171.90` development and release archives;
2. remove the identity type foundation and V2 guard changes;
3. do not run a database rollback because no migration exists;
4. verify source archive SHA-256 and CRC.

## 8. Next cycle

```text
1595 — Backend UserId value type adoption planning
```

Cycle 1595 may expand unit-level use of the type contract but must not perform
an ORM/schema or domain-ownership switch outside its explicit patch boundary.
