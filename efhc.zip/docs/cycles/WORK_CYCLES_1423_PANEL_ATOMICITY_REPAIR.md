# Work Cycle 1423 — P0 panel activation atomicity repair

Date: 2026-06-04.

HEAD input: `EFHC_Bot_v169_97_cycle_1422_economic_risk_repair.zip`.
HEAD output: `EFHC_Bot_v169_98_cycle_1423_panel_atomicity_repair.zip`.

## Goal

Repair `FIND-001` from the supplied P0 economic audit:

`panels_service.py / activate_panel` committed EFHC spend before creating panel
rows. A crash between the spend commit and the panel creation commit could leave
money debited with no panels created.

## User decision

The user confirmed option `A`:

- add `spend_user_to_bank_bonus_then__main__nocommit`;
- make `panels_service.py` own the single transaction boundary.

The user also pre-confirmed later-cycle decisions:

- `FIND-003`: use one `_tx_context` plus nocommit refund and one commit;
- `FIND-005`: move idempotency check inside lock/retry loop and add entry
  rollback guard.

Those later decisions are recorded, but this cycle repaired only `FIND-001`.

## Read before edit

- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`
- `ops/operator_kernel/config/routes.yaml`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/audits/P0_ECONOMIC_AUDIT_TRANSACTIONS_SERVICE_V169_91.md`
- `docs/cycles/WORK_CYCLES_1422_ECONOMIC_RISK_REPAIR.md`
- `map_element.md`

Kernel preload was available. `routes.yaml.version` remained `1`.

## Repair applied

### 1. Nocommit spend helper

File:

`backend/app/services/transactions_service.py`

Added:

`spend_user_to_bank_bonus_then__main__nocommit`

Purpose:

- perform BONUS→MAIN spend without committing;
- allow a higher-level service to atomically commit/rollback spend plus domain
  object creation;
- preserve read-through idempotency by both `:main` and `:bonus` derived keys.

The existing commit-owning function now delegates to the nocommit helper inside
`transactions_service._tx_context()`.

### 2. Panel activation owns the atomic unit

File:

`backend/app/services/panels_service.py`

`activate_panel` now performs the following inside one transaction:

1. lock user row;
2. check historical negative balance;
3. check active panel limit;
4. calculate bonus/main split;
5. call `spend_user_to_bank_bonus_then__main__nocommit`;
6. create panel rows;
7. merge activation audit payload.

Forbidden old pattern removed:

- spend commit first;
- create panel rows in a later transaction.

### 3. Bonus-only replay payload repair

File:

`backend/app/services/panels_service.py`

`_get_activation_payload_by_idk` now reads and merges payload from both keys:

- `{idempotency_key}:main`
- `{idempotency_key}:bonus`

Reason:

An all-bonus activation may not create a `:main` transfer log. Replay must not
miss `panels_created_ids` and create duplicate panels without a new debit.

## Tests / guards

Updated active guard:

`tests/architecture/test_economic_risk_guards.py`

Protected checks:

- all-bonus spend retry read-through remains protected;
- admin manual debit TypeError guard remains protected;
- panel activation must use nocommit spend inside one transaction;
- activation replay payload must read both `:main` and `:bonus` logs.

## Local checks

Passed targeted checks:

```text
python3 -m pytest -q tests/architecture/test_economic_risk_guards.py
4 passed
```

```text
PYTHONPATH=backend python3 -m pytest -q   tests/architecture/test_archive_filename_hygiene.py   tests/architecture/test_economic_risk_guards.py   tests/architecture/test_heal0018_transaction_boundary_repair.py
16 passed
```

Additional broader targeted pack passed before final archive creation.

## Sandbox / map_element use

`map_element.md` and the uploaded sandbox archives were used only as
reference/navigation context. Runtime code, CI files, lock files, wallet/payment
logic, translations and foreign economy were not imported.

## Not claimed

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full npm build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect/wallet proof.

## Status

`FIND-001` is repaired and guarded.

Remaining economic audit plan:

- cycle `1424`: `FIND-003` withdraw refund split + `FIND-005` exchange TOCTOU;
- cycle `1425`: `FIND-006..010` cleanup and reconciliation hardening.
