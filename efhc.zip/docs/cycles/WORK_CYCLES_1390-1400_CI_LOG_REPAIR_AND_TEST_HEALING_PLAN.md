# WORK_CYCLES_1390-1400 — CI log repair and test healing plan

Status: ACTIVE after the AI archive laws lock.
Base HEAD: `v169_69_ai_archive_laws_kernel_canon_lock`.
Current repair cycle: `1399`.

## Governing law

This range is controlled by `docs/AI/AI_ARCHIVE_LAWS.md`.
Tests are protection for the archive. They must not be deleted, archived,
skipped, xfailed or hidden to make CI look green. If a test fails, the cause
must be healed or escalated through mandatory iteration questions in Russian.

## Cycle map

| Cycle | Purpose | Status |
|---:|---|---|
| 1390 | Read `logs_72130548522.zip`, repair first pytest root causes, strengthen Law 0, repair line-length 72, and perform first mapped consolidation for wave-3 i18n guards. | DONE in v169.71 |
| 1391 | Continue pytest failure healing from fresh logs or remaining domain failures; line-length blocker was closed in 1390. | DONE in v169.73: bootstrap dependency diagnostics guard |
| 1392 | Fresh CI log `logs_72176795654.zip`: repair the eight pytest failures without hiding tests. | DONE in v169.74 |
| 1393 | Fresh CI log `logs_72181359058.zip`: confirm pytest and frontend build after v169.74, then lock shell guard evidence. | DONE in v169.75 |
| 1394 | Public Energy, Panels, Exchange and route guard repair. | DONE in v169.76 |
| 1395 | Visible functions, admin route evidence and report-index repair. | DONE in v169.77 |
| 1396 | Rank wording, legacy words and browser-shop/hub wording guard repair; user correction that `game` is allowed and only gambling/loto/betting/random financial meaning is banned. | DONE in v169.78 |
| 1397 | Fresh CI log `logs_72195040558.zip`: DB lane was green; repair ruff and canon false-positive failures from the wording pass. | DONE in v169.79 |
| 1398 | Test consolidation audit only: identify candidates and exact invariant mapping. No deletion. | DONE in v169.80 |
| 1399 | Direct user-approved mapped consolidation of the four cycle 1398 candidate groups. | DONE in v169.81 |
| 1400 | Fresh CI log `logs_72210640420.zip`: repair ruff shim import order, then close range. | DONE in v169.82 |

## Cycle 1400 range closure — v169.82

Fresh CI logs for `v169_81` were supplied as `logs_72210640420.zip`.
The log showed that pytest, frontend build, DB/Alembic, flake8, mypy,
bandit and compileall gates passed. The only failing gate was ruff.

Observed CI facts:

- pytest: `1130 passed`, `8 skipped`, `1 warning`;
- frontend: `npm ci` and `next build` passed;
- DB/Alembic: `exit_psql_pre=0` and `exit_alembic_upgrade=0`;
- gate blocker: `exit_ruff_full=1`.

Root cause:

- `ops/i18n/audit_forbidden_gaming_contour.py` had an import block
  formatting issue in the compatibility shim.

Repair:

- the shim import block was formatted without changing guard meaning;
- the active guard remains
  `ops/i18n/audit_forbidden_gambling_chance_contour.py`;
- the word `game` remains allowed;
- gambling, loto, betting and random financial reward meaning remain banned.

No test was deleted, archived, skipped, xfailed or hidden. No runtime UI,
backend economics, CI workflow, package lock or sandbox runtime changed.

Progress after cycle 1400:

- total cycles in `1390-1400`: 11;
- completed cycles: 11;
- remaining cycles: 0;
- range status: CLOSED;
- next action: wait for the new audit before opening a new active range.



## Cycle 1399 status

Cycle 1399 is done in `v169_81`. The user approved consolidating all four
groups prepared in cycle 1398. The pass converted 32 old active architecture
test files into support modules and added 4 active consolidated wrappers.
All 154 original test functions remain active as pytest cases.

Progress in this range after 1399:

- total cycles in `1390-1400`: 11;
- completed cycles: 10;
- remaining cycles: 1;
- next planned cycle: 1400 range closure and handoff.

## Cycle 1397 status

Cycle 1397 is done in `v169_79`. Fresh CI logs showed that the
Alembic/Postgres lane was green. The actual failing lanes were ruff and
pytest canon guards.

Root cause: after the game-word correction, active docs, tests and a guard
path used a banned English legacy token. The active forbidden-contour guard
was renamed to a neutral path and active references were updated without
weakening the ban on азартные игры, лотереи, ставки or random financial
reward meaning.

Progress in this range after 1397:

- total cycles in `1390-1400`: 11;
- completed cycles: 8;
- remaining cycles: 3;
- next planned cycle: 1398 audit-only consolidation mapping.


## Cycle 1396 status

Cycle 1396 is done in `v169_78`. It added a source/static wording matrix for
Ranks, Hub and Browser-Shop and corrected the false ban on the word `game`.
The active forbidden contour is gambling, loto, betting, tournament-like
financial contests and random financial reward meaning.

Progress in this range after 1396:

- total cycles in `1390-1400`: 11;
- completed cycles: 7;
- remaining cycles: 4;
- next planned cycle: 1397 if fresh CI has DB/Alembic/Postgres blockers,
  otherwise 1398 audit-only consolidation preparation.

## Current facts from logs

The CI log `logs_72130548522.zip` shows that the test suite is no longer hidden
behind global skip. Pytest executed and reported:

- `61 failed`;
- `1063 passed`;
- `8 skipped`.

The current local collect-only count after this repair state is:

- `1201 tests collected`.

## Cycle 1390 scope

Cycle 1390 heals only the root causes that are clear from the log and from
active tests. It does not weaken tests and does not make consolidation changes.

Healed groups:

- degraded Python dunder/name tokens;
- stale `/document` test expectation after Next `_document.tsx` correction;
- missing static retention/evidence anchors required by old active guards;
- stale energy balance-chip public UI guard expectations;
- historical cycle-marker drift;
- stale filename-hygiene noise in active test names;
- stale master-index active rows that pointed at missing historical files.

Open group:

- line-length 72 remains a large source-formatting blocker. It must be handled
  as a separate cycle because it touches many files and must not be hidden by
  weakening the guard.


## Cycle 1390 update — v169.71

User decisions applied:

- line-length 72 repair allowed and completed;
- CI summary formatting change not allowed yet;
- mapped test consolidation allowed and started only for wave-3 i18n guards;
- Law 0 replaced with the strengthened user-approved text only.

Consolidation was limited to a fully mapped group:

- five old wave-3 i18n test files became support modules;
- one active wrapper invokes all original test functions;
- no test was archived as `test_*.py`;
- no skip, xfail or norecursedirs was added.


## Cycle 1390 repair update — v169.72

User stopped iteration because a forbidden cycle suffix appeared in
`docs/testing/TEST_CONSOLIDATION_MAPPING_1390.md`.

Repair result:

- renamed the file to `docs/testing/TEST_CONSOLIDATION_MAPPING.md`;
- updated all references;
- strengthened filename policy with explicit path size limits;
- added an explicit guard for `docs/testing/` filenames;
- did not touch unrelated tests or CI jobs.

The next cycle remains 1391. It must continue log/domain healing without
filename-regression, test hiding, skip, xfail or archive moves.


## Cycle 1391 update — v169.73

No fresh `logs_*.zip` was supplied in this chat turn. The cycle therefore used
local collection triage from the current HEAD.

Findings:

- ZIP integrity and `testzip` passed.
- `pytest --collect-only` with `PYTHONPATH=backend` did not complete in the
  local sandbox because backend/test bootstrap dependencies were absent:
  `alembic`, `freezegun`, `psycopg`, `sqlalchemy`.
- This is a dependency bootstrap blocker in the local execution environment,
  not a reason to delete, skip, archive or weaken tests.
- Structural guard mode still passed and reported
  `active_architecture=269`.

Repair:

- `scripts/ci/check_test_suite_integrity.py` now checks required bootstrap
  modules before full collect-only and fails with a short root-cause message.
- `tests/architecture/test_test_suite_integrity_repair.py` now protects that
  message and the dependency-install instruction.
- No CI workflow, pytest exclusion, skip, xfail or test archive was added.

Checks:

- targeted protection set: `20 passed`;
- `check_ai_archive_laws_integrity.py`: passed;
- `check_test_suite_integrity.py --no-collect`: passed;
- full collect-only was not claimed because the local sandbox lacks the
  backend/test dependency layer.

Next cycle: `1392` docs/index retention anchors, unless fresh logs are supplied
first.


## Cycle 1392 update — v169.74

Fresh log priority superseded the earlier historical-docs placeholder for
cycle 1392. The log `logs_72176795654.zip` showed that all listed CI gates
except pytest were green, while pytest ended with `8 failed`, `1105 passed`,
`8 skipped`.

The eight failures were repaired by root cause:

1. `test_wave11_idempotency_conflict_requires_read_through` — restored the
   exact idempotency conflict marker protected by the guard.
2. `test_wave13_energy_and_sync_self_healing_guards` — reformatted the SQL
   wrapper so the guard parses the SQL block without swallowing commit code.
3. `test_great_canon_guard` — removed literal forbidden removed-domain terms
   from the i18n guard source by constructing those tokens safely.
4. `test_bot_texts_parity_script_uses_valid_importlib_loader` — replaced the
   package import path with a file loader that avoids Telegram runtime imports.
5. `test__main__registers_routes_with_api_prefix` — changed the stale test
   anchor from whitespace-specific text to semantic route-prefix detection.
6. `test_operator_kernel_has_range_closure_route` — restored the contiguous
   generated-report path anchor in the operator route resolver.
7. `test_cycle_1377_uk_quality_guard_uses_global_exact_allowlist` — preserved
   the exact allowlist-call anchor while staying inside line-length policy.
8. `test_shop_service_catalog_marks_usdt_disabled` — restored a canonical
   contiguous USDT disabled-reason marker through a shared constant.

No consolidation was performed in cycle 1392. No active test was deleted,
archived, skipped, xfailed or removed from collection.

Verification performed locally:

- 63 targeted architecture/policy tests passed;
- `python3 -m compileall backend/app ops tests/architecture -q` passed;
- AI archive laws integrity guard passed;
- structural test-suite guard passed in `--no-collect` mode;
- bot text parity, Ukrainian value quality and forbidden-gaming guards passed.

Full pytest green and GitHub CI green are not claimed until the repaired
archive is executed in CI or in a local environment with all backend/test
requirements installed.

## Cycle 1393 update — v169.75

Fresh log priority was applied again. The supplied log
`logs_72181359058.zip` showed no failing gate after the v169.74 repair.

Observed CI facts from the log:

- gate summary: all gate steps passed;
- pytest: `1113 passed`, `8 skipped`, `1 warning`;
- frontend: `npm ci` completed and `next build` completed;
- Next.js build route table included public routes, admin routes,
  `/app`, `/_app`, `/api/tonconnect-manifest` and `/_document`
  was not exposed as a public page.

Cycle 1393 therefore did not perform code repair. It updated cycle, shell,
SSOT and test-control documents to record the verified state.

Local targeted verification performed for the shell lane:

- 48 targeted architecture/frontend shell tests passed.

No active test was deleted, archived, skipped, xfailed or hidden. No CI
workflow, package lock, EFHC economics, wallet logic or sandbox runtime was
changed.

Open non-blocking note from the log: `npm ci` printed audit warnings for
5 vulnerabilities. The CI gate did not fail on that warning. Treat package
changes as a separate dependency-security cycle only after audit, not as a
blind `npm audit fix --force` step.

Next cycle: `1394`, unless fresh failing logs are supplied first.
## Cycle 1394 update — v169.76

No fresh failing log archive was supplied for this cycle. The user explicitly
confirmed continuing strictly by the 1394-1400 plan.

Cycle 1394 therefore performed a public Energy/Panels/Exchange guard pass:

- added `docs/frontend/PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md`;
- added `reports/generated/public_energy_panels_exchange_guard_matrix_v169_76.json`;
- added `tests/architecture/test_public_energy_panels_exchange_guard_matrix.py`;
- registered the guard in `docs/testing/TEST_GUARD_MANIFEST.md/json`;
- recorded that no test consolidation was performed.

Protected chain: public route → public component → backend road → EFHC
economic invariant → active architecture guard.

No code path changed EFHC economics, wallet logic, CI workflow or sandbox
runtime. No test was deleted, archived, skipped, xfailed or hidden.

Local targeted verification for the public triad guard lane passed. Full local
pytest green is not claimed in this sandbox.

Next cycle: `1395`, unless fresh failing logs are supplied first.


## Cycle 1395 closure note

Cycle 1395 closed the Admin visible function evidence gap by adding one
active guard matrix over Admin route, visible function, backend road and guard
anchors. It also imported `25.md` into `docs/NORM/CHATS/` and recorded the
new sandbox input as reference-only. No runtime UI, backend economics, tests or
CI workflows were weakened.


## Cycle 1398 status

Cycle 1398 is done in `v169_80`. It is an audit-only mapping pass.
No active tests were changed, moved, deleted, archived, skipped,
xfailed or consolidated.

Prepared map:

- `docs/testing/TEST_CONSOLIDATION_AUDIT_ONLY_MAP.md`;
- `reports/generated/test_consolidation_audit_only_map_v169_80.json`.

Mapped future candidate groups:

1. docs/cycles and cycle-marker guards;
2. public visual evidence guards;
3. PWA / shell / document guards;
4. route / evidence existence guards.

Progress in this range after 1398:

- total cycles in `1390-1400`: 11;
- completed cycles: 9;
- remaining cycles: 2;
- next planned cycle: 1399 optional actual consolidation only after
  direct user approval.
