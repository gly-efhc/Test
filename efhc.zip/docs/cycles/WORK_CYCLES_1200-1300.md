
## v168_50 cycle 1266 note

Cycle 1266 restores FAQ access and repairs route/button tails after
the public UI rollback.  FAQ remains a page at `/faq` and is now visible
from the global header and from the `/web-profile` FAQ tab.  The six
canonical bottom buttons are unchanged.  `/admin/logs` is added because
admin surfaces already linked to it.  Shared `Button` now has a safe
`href` mode so navigation buttons no longer need unsafe Link-wrapped
Button nesting.  Docker SSL/runtime fixes from v168_48 and the public
UI rollback from v168_49 remain preserved.


## v168_49 cycle 1265 note

Cycle 1265 is a repair rollback of public UI mistakes while keeping
Docker fixes from v168_48.  HUB no longer renders technical runtime
text.  Energy no longer has unsanctioned HUB or Wallet/Profile action
cards and returns to the canon: energy, kWh, progress, panels, base
rate, generation speed, EFHC balance and available kWh.  Header balance
is visible again.  Public Profile no longer shows browser/PWA/internal
shell labels.  A local smoke test script was added for PC runtime
checks.

## v168_45 cycle 1261 note

The user pasted a Docker build log where backend completed and the
frontend image stopped at `RUN npm ci`.  The fragment has no final npm
error line, so the failure is classified as a frontend dependency
installation blocker/hang or low-visibility Docker install step.

Cycle 1261 hardens `ops/docker/Dockerfile.frontend`: npm registry is
explicit, audit/fund/progress noise is disabled, fetch retries are set,
and a static guard protects these Docker build flags.  Docker runtime
proof remains pending because Docker is not available in the assistant
environment.

## v168_44 cycles 1251-1260 note

Fresh log `logs_69555566503.zip` is green: all gate exit files are
zero, pytest reports 538 passed, npm build is green in GitHub CI and
backend security/static checks passed.  The pass therefore worked on
remaining visual and audit tails instead of log failures.

Closed cycle notes:

- 1251: Panels page uses compact list containment and GameDetails for
  activation context and per-panel technical details.
- 1252: Exchange page keeps the amount selector visible and moves
  advanced proof/withdraw detail into GameDetails drawers.
- 1253: Tasks page keeps active earning cards visible and moves the
  long help text into a compact GameDetails drawer.
- 1254: Referrals page keeps invite/share primary and moves system and
  level detail into compact drawers.
- 1255: Ranks page keeps the user card and podium visible, with the
  full table and extended leaderboard in drawers.
- 1256: Existing clean empty states are preserved and protected as the
  public fallback for inactive modules.
- 1257: Public loading/error states remain non-technical and use safe
  labels instead of raw exception text.
- 1258: All canonical route entry points remain intact.
- 1259: Added a static guard for GameDetails usage, route preservation
  and dependency warning tail closure.
- 1260: Documented compact proof and remaining proof boundary.

## v168_43 cycles 1246-1250 note

Cycles 1246-1250 are closed as a log-driven repair and Energy first
screen polish block.  The fresh log `logs_69510727201.zip` had three
pytest failures.  The pass fixed WebProfile payment/outcome surface
markers, split internal helper routes out of public OpenAPI SSOT,
refreshed OpenAPI from SSOT and added compact Energy first-screen chips
and bridge actions.

Closed cycle notes:

- 1246: EFHC balance chip added to Energy first screen.
- 1247: HUB bridge action added as a clean public card.
- 1248: Profile/Wallet compact entry added.
- 1249: the six-button bottom menu remains canonical and unchanged.
- 1250: first-screen public action count guard added.

## v168_23 cycle 1206 note

Cycle 1206 continues the public visual repair program.

Closed findings:

- language selector now matches the user's one-button dropdown canon;
- store pay button now uses the backend TonConnect transaction payload
  internally and opens the wallet transaction flow through TonConnect.

New planning input:

- Dragon/Web3 reference sandboxes are accepted as visual references for
  future browser shell, buttons, progress bars and game-like surfaces.
  They are not accepted as code donors.

# WORK CYCLES 1200-1300

Status: new visual repair range container.
Created during v168_17 after imported visual audit v002.

This document replaces the older generic 1201-1300 direction for the
active visual repair program. It does not close any future cycle.

## Activation rule

- Cycle 1200 is a bridge verdict, not automatic range closeout.
- Cycles 1201-1230 continue the visual blocker repair program.
- Cycles 1231-1300 remain future stabilization, proof and release
  evidence work after the main visual road repairs.
- If code repair proves a different order is safer, the cycle plan may
  be remapped in a new report. The reason must be explicit.

## 1200 bridge

- 1200: corrected bridge verdict for 1176-1200. Do not claim release
  readiness if visual blockers from the imported audit are still open.

## v168_19 remap after 1198-1199

Cycles 1198-1199 repaired the Direct Deposit modal and backend
wallet-open contract ahead of the older 1201-1203 plan items. The
remaining 1201-1203 items are therefore not repeated as new code tasks;
they become verification, browser check and evidence tasks for Direct
Deposit. HUB and Browser-Shop cleanup remain open.

## 1201-1230 active visual repair program
- 1201: Verify Direct Deposit backend contract in browser/runtime
  context and confirm receiver settings are present in deployment.
- 1202: Verify Direct Deposit frontend wallet-open integration by
  browser or Telegram WebApp run; no raw wallet/memo/copy UI allowed.
- 1203: Extend Direct Deposit guard evidence if browser screenshots or
  runtime route export expose any remaining public leakage.
- 1204: Clean HUB public screen to two actions only. Preserve VIP URL
  and language rules.
- 1205: Move HUB diagnostic blocks to admin diagnostics or admin
  components with one operator entry.
- 1206: Add HUB guard proving exactly two public actions and no
  forbidden technical terms.
- 1207: Create ShopLayout or route-based layout exception for
  browser-shop. Remove Mini App bottom navigation and GlobalHeader from
  storefront.
- 1208: Create storefront top area with avatar, balance and Profile
  button, using public names only.
- 1209: Clean storefront product cards. Show title, EFHC quantity,
  price, description and Pay only.
- 1210: Remove SKU, code, item_type, status, endpoint, intent id, order
  id and internal category from public storefront cards.
- 1211: Remove public custom amount, search and filters for first-stage
  storefront unless backed by approved active product design.
- 1212: Wire product Pay button to create payment and open TON wallet
  immediately with amount and memo embedded.
- 1213: Add simple wallet-open failure UX: Ne udalos otkryt koshelek.
  Poprobuyte snova.
- 1214: Ensure opened-but-unpaid wallet flow does not show pressure or
  technical duplicate prompts.
- 1215: Clean public payment status language: waiting, checking,
  completed and error as human messages.
- 1216: Move Browser-Shop payment diagnostics to admin diagnostics and
  backend/operator logs.
- 1217: Expand admin/diagnostics with HUB, Shop, Deposit, endpoint
  health, status and payment chain diagnostics.
- 1218: Keep admin/shop card management intact and verify active public
  cards come from admin catalog.
- 1219: Add public UI forbidden-term guard across HUB, DepositModal and
  BrowserShopPage user strings.
- 1220: Add public card field guard proving no admin fields are rendered
  in storefront cards.
- 1221: Add layout guard proving browser-shop does not use Mini App
  Layout or bottom nav.
- 1222: Add wallet-flow guard proving tonconnect_tx is internal and not
  rendered as public text.
- 1223: Add route/contract guard proving Direct Deposit is not package
  purchase and storefront remains product purchase.
- 1224: Frontend/backend call matrix enforcement for visual roads after
  component cleanup.
- 1225: Contract tests repair for repaired visual roads and previously
  repaired economic roads.
- 1226: Smoke test HUB path: Home to HUB to storefront and VIP link
  without diagnostics.
- 1227: Smoke test Direct Deposit path: plus to clean modal to
  wallet-open attempt and simple failure handling.
- 1228: Smoke test storefront path: product card to Pay to wallet-open
  attempt and profile/history outcome contract.
- 1229: Update SSOT, API contracts, road matrix, Healer and reports
  after visual road repairs.
- 1230: Visual release evidence audit. Separate proven repairs,
  remaining blockers and not-release-ready claims.

## 1231-1240 visual hardening
- 1231: Run screenshot or browser-based audit for HUB, Deposit and
  Storefront.
- 1232: Check Telegram browser and normal browser storefront entry.
- 1233: Validate responsive layout against Telegram Mini App
  constraints.
- 1234: Check Russian user copy as meaning canon.
- 1235: Check non-Russian fallback without exposing technical terms.
- 1236: Check profile history naming and completed payment visibility.
- 1237: Check active payment card copy and duplicate prevention.
- 1238: Check admin diagnostics contains moved technical data.
- 1239: Check admin/shop retains card management with admin-only fields.
- 1240: Update visual blocker registry after browser checks.

## 1241-1260 contract and smoke proof
- 1241: contract, smoke or guard proof wave 1241.
- 1242: contract, smoke or guard proof wave 1242.
- 1243: contract, smoke or guard proof wave 1243.
- 1244: contract, smoke or guard proof wave 1244.
- 1245: contract, smoke or guard proof wave 1245.
- 1246: contract, smoke or guard proof wave 1246.
- 1247: contract, smoke or guard proof wave 1247.
- 1248: contract, smoke or guard proof wave 1248.
- 1249: contract, smoke or guard proof wave 1249.
- 1250: contract, smoke or guard proof wave 1250.
- 1251: contract, smoke or guard proof wave 1251.
- 1252: contract, smoke or guard proof wave 1252.
- 1253: contract, smoke or guard proof wave 1253.
- 1254: contract, smoke or guard proof wave 1254.
- 1255: contract, smoke or guard proof wave 1255.
- 1256: contract, smoke or guard proof wave 1256.
- 1257: contract, smoke or guard proof wave 1257.
- 1258: contract, smoke or guard proof wave 1258.
- 1259: contract, smoke or guard proof wave 1259.
- 1260: contract, smoke or guard proof wave 1260.

## 1261-1280 road registry and SSOT proof
- 1261: route, SSOT, NORM, Healer or report sync wave 1261.
- 1262: route, SSOT, NORM, Healer or report sync wave 1262.
- 1263: route, SSOT, NORM, Healer or report sync wave 1263.
- 1264: route, SSOT, NORM, Healer or report sync wave 1264.
- 1265: route, SSOT, NORM, Healer or report sync wave 1265.
- 1266: route, SSOT, NORM, Healer or report sync wave 1266.
- 1267: route, SSOT, NORM, Healer or report sync wave 1267.
- 1268: route, SSOT, NORM, Healer or report sync wave 1268.
- 1269: route, SSOT, NORM, Healer or report sync wave 1269.
- 1270: route, SSOT, NORM, Healer or report sync wave 1270.
- 1271: route, SSOT, NORM, Healer or report sync wave 1271.
- 1272: route, SSOT, NORM, Healer or report sync wave 1272.
- 1273: route, SSOT, NORM, Healer or report sync wave 1273.
- 1274: route, SSOT, NORM, Healer or report sync wave 1274.
- 1275: route, SSOT, NORM, Healer or report sync wave 1275.
- 1276: route, SSOT, NORM, Healer or report sync wave 1276.
- 1277: route, SSOT, NORM, Healer or report sync wave 1277.
- 1278: route, SSOT, NORM, Healer or report sync wave 1278.
- 1279: route, SSOT, NORM, Healer or report sync wave 1279.
- 1280: route, SSOT, NORM, Healer or report sync wave 1280.

## 1281-1300 release evidence closeout
- 1281: final blocker, archive, report or range evidence wave 1281.
- 1282: final blocker, archive, report or range evidence wave 1282.
- 1283: final blocker, archive, report or range evidence wave 1283.
- 1284: final blocker, archive, report or range evidence wave 1284.
- 1285: final blocker, archive, report or range evidence wave 1285.
- 1286: final blocker, archive, report or range evidence wave 1286.
- 1287: final blocker, archive, report or range evidence wave 1287.
- 1288: final blocker, archive, report or range evidence wave 1288.
- 1289: final blocker, archive, report or range evidence wave 1289.
- 1290: final blocker, archive, report or range evidence wave 1290.
- 1291: final blocker, archive, report or range evidence wave 1291.
- 1292: final blocker, archive, report or range evidence wave 1292.
- 1293: final blocker, archive, report or range evidence wave 1293.
- 1294: final blocker, archive, report or range evidence wave 1294.
- 1295: final blocker, archive, report or range evidence wave 1295.
- 1296: final blocker, archive, report or range evidence wave 1296.
- 1297: final blocker, archive, report or range evidence wave 1297.
- 1298: final blocker, archive, report or range evidence wave 1298.
- 1299: final blocker, archive, report or range evidence wave 1299.
- 1300: final blocker, archive, report or range evidence wave 1300.

## Non-claim rule

Planning text in this file is not release readiness. A cycle is only
complete after real change, focused check and report evidence.

## v168_20 remap after cycles 1200-1201

Cycle 1200 completed the bridge verdict without false release readiness.
Cycle 1201 was remapped from verification-only work to a real code fix:
public HUB cleanup.  This was safe because the visual audit identifies
HUB diagnostics leakage as a blocker, while Direct Deposit already had
source-level code and guard proof from cycles 1198-1199.

### Updated near-term order

- 1202: Browser-Shop layout separation: storefront must not use the
  common Mini App Layout, GlobalHeader or bottom navigation.
- 1203: Storefront top zone: avatar, balance and Profile button.
- 1204: Clean storefront product cards and hide admin fields.
- 1205: Remove public wallet/memo/copy and payment diagnostics from
  Browser-Shop.
- 1206: Add forbidden-term and layout guards for Browser-Shop.
- 1207: Wire Pay button to wallet-open without rendering raw
  `tonconnect_tx`.
- 1208: Expand admin diagnostics for moved Browser-Shop details.
- 1209: Add smoke/guard proof for HUB and storefront paths.
- 1210: Sync SSOT/NORM/reports after Browser-Shop repair wave.

Older numbers after 1210 remain valid as stabilization and proof waves,
but the immediate priority is Browser-Shop cleanup.

## v168_21 remap after cycles 1202-1203

Cycles 1202-1203 are complete for their specific findings:
Browser-Shop now has a route-based dedicated `ShopLayout`, and the
storefront top zone shows avatar, EFHC balance and Profile link.  The
main Q/A register now contains all 100 visual answers.

Remaining immediate blockers:

- clean storefront product cards;
- hide SKU/code/item_type/status and technical IDs;
- remove public wallet/memo/copy blocks;
- move Browser-Shop payment diagnostics to admin diagnostics;
- connect Pay to wallet-open without rendering raw `tonconnect_tx`.

## v168_22 storefront cleanup status

Cycle 1204 removed public storefront operator noise and technical card
fields.

Cycle 1205 removed manual wallet/memo/copy/payment diagnostics from the
public Browser-Shop page and moved the technical review surface to
admin diagnostics.

The next active work is not a release verdict.  It is Pay-button wallet
opening and proof that the wallet instruction remains internal.


## v168_24 update after cycle 1207

Cycle 1207 completed a focused payment-status and route-diagnosis pass.

- Browser-Shop now keeps `activeIntentId` after creating a payment.
- Pending/checking payments poll `/shopfront/intent-status`.
- Payment status maps to human states only: checking, completed or
  error.
- The generated status validator now keeps optional `flow_truth`.
- A static route inventory found no missing page routes for current
  frontend `href`, `router.push` and `window.location.assign` links.

This does not prove every button in a live browser.  It proves that the
current issue is not a global missing-page-route failure.  The remaining
problem is UX architecture: too many first-level actions, Telegram-only
runtime dependencies, disabled states without enough explanation and
async actions without immediate user feedback.

## Dragon-style extension plan

The Dragon-style visual and functional-compression program is recorded
in:

`docs/cycles/WORK_CYCLES_1231-1350_DRAGON_VISUAL_FUNCTIONS_PLAN.md`.

It is visual/UX work only.  It must not copy Dragon branding or assets,
and it must not remove EFHC functions.

## v168_25 update after cycle 1208

Cycle 1208 repaired the FAQ frontend layer.

The user clarified that the six bottom navigation buttons are canonical.
They must not be renamed, reordered, removed, or collapsed.

Future compression must happen inside canonical pages:

- remove artifact functions only after audit;
- move operator/admin functions to admin;
- keep game pages visually equal for normal users and admins;
- approve visible function fate through Q/A.

FAQ-specific result:

- localized quick labels;
- compact Mini App shell;
- bot-width overflow protection;
- architecture guard added.

## v168_26 update

Cycle 1209 added browser/PWA shell foundation and visible function
inventory.  The 1209-1230 detailed plan is corrected to keep all six
canonical buttons and to compress only subsections unless a later Q/A
approves deeper changes.

## v168_38 update after cycle 1226-1228 Energy repair

Cycle 1226-1228 now has a real Energy first-screen code repair.

Confirmed in chat:

- Profile remains a route page, not an overlay.
- Energy follows a Dragon-like first-screen structure, but with EFHC
  branding and EFHC routes.

Implemented:

- stronger Energy hero;
- live central kWh resource number;
- visible progress strip;
- active panels and generation-rate chips;
- first-screen action cards for Panels and Exchange;
- duplicate pre-page skin hero removed from Layout.

This is not a 99 percent frontend verdict.  The next planned step is the
shared EFHC Game UI Kit for all canonical pages.

## v168_39 update after cycles 1229-1230

Cycles 1229-1230 were updated and closed as a first shared visual pass.

Cycle 1229:

- added shared EFHC Game UI Kit component layer;
- moved Panels, Exchange, Tasks, Referrals and Ranks to the shared game
  page/hero/stat pattern;
- kept the six canonical bottom navigation labels unchanged.

Cycle 1230:

- localized Profile / Wallet / History tabs across all locale files;
- restored Admin entry for admin accounts;
- hid raw public technical errors from user-facing pages;
- added a dynamic TonConnect manifest endpoint for browser/Cloudflare
  mode;
- reduced flicker sources in splash and Telegram MainButton handling;
- polished the bottom navigation into a stronger dark/gold game bar.

This is still not a 99 percent frontend verdict.  The next visual wave
must continue from the shared kit into deeper card polish, Wallet flow,
Shop/HUB proof and live browser/Docker verification.

## v168_40 cycle update: 1231-1232

### 1231: live check and FAQ containment

- Previous Cloudflare tunnel was checked and returned `502 Bad Gateway`.
- No live visual success is claimed from that tunnel.
- FAQ overflow blocker was fixed by adding strict containment and
  wrapping rules to the FAQ shell.
- Long FAQ section names, answers, breadcrumbs and category pills must
  stay inside the application frame.

### 1232: Wallet / HUB / Browser-Shop Game UI Kit pass

- Wallet and History inside `/web-profile` now use shared Game UI Kit
  stat and notice primitives.
- HUB now uses Game UI Kit hero, action cards and notice blocks.
- Browser-Shop now uses Game UI Kit hero, notices, sections and product
  cards.
- Browser-Shop no longer displays raw public exception details in the
  storefront error state.

### Status after v168_40

- Cycles 1226-1228: base launch, independent shell and Energy first
  screen foundation.
- Cycles 1229-1230: first EFHC Game UI Kit wave and public blocker
  cleanup.
- Cycles 1231-1232: FAQ containment plus Wallet / HUB / Browser-Shop
  Game UI Kit extension.

Next focus: live deployment proof and then deeper Wallet state-map,
HUB handoff proof and Browser-Shop checkout proof.

## Cycles 1233-1235 — Wallet state-map + TonConnect proof UI

- 1233: done — WebProfile Wallet state-map added for six public states:
  connected, not connected, pending proof, wallet error, backend error,
  and bound.
- 1234: done — TonConnect manifest CORS and proof UI foundation kept
  aligned with WalletGate/TonConnect SSOT.
- 1235: done — `logs_69492808512.zip` failures triaged and repaired:
  TypeScript nullable URL, undefined `processing_ik`, route policy,
  OpenAPI/SSOT drift, stale guards, and artifact hygiene.

## v168_42 cycles 1236-1245 note

Closed in this pass:

- 1236: started EFHC status-chip polish for Wallet and Shop states.
- 1237: made Wallet state-map more visual through GameStatusPill.
- 1238: added Browser-Shop runtime state signal in the hero area.
- 1239: repaired fresh log pack `logs_69501935339.zip` findings.
- 1240: re-synced DB and route SSOT drift from current CSV truth.
- 1241: restored HUB pending/disabled public state coverage.
- 1242: restored VIP NFT external collection wording canon.
- 1243: restored Browser-Shop TON-only MVP guard boundary.
- 1244: restored pre-archive test rule in AI startup documents.
- 1245: passed local TypeScript no-emit proof after frontend changes.

Remaining for 1246-1250:

- live proof after a working tunnel;
- deeper Wallet / HUB / Browser-Shop visual polish;
- final screenshot-based browser verification.

## v168_46 cycle 1262: Docker known-good rollback

- User reported Docker stopped working and that v168_37 was
  the last working version.
- The provided Docker log showed backend build success and frontend stop
  at `RUN npm ci`.
- Root cause: the release branch moved away from the v168_37 frontend
  dependency baseline during npm-audit cleanup and Dockerfile npm-ci
  hardening.
- Repair: restore `frontend/package.json`, `frontend/package-lock.json`
  and `ops/docker/Dockerfile.frontend` from v168_37.
- Application code is not rolled back.
- Dependency security cleanup is postponed to a separate Docker-proven
  upgrade cycle.

## v168_47 cycle 1263: Docker history runtime fix

- User provided Docker history after v168_46.
- Earlier npm-ci-only diagnosis was incomplete.
- The history shows containers reaching runtime and backend health checks
  returning `200 OK`.
- The real runtime blocker is asyncpg receiving unsupported `sslmode`
  from the async `DATABASE_URL`.
- Repair: strip `sslmode` from asyncpg DSN and map SSL-required modes to
  asyncpg `ssl=True`.
- Local Docker async DB URLs no longer include `?sslmode=disable`.
- v168_37 frontend dependency baseline remains preserved from v168_46.


## v168_48 cycle 1264: Docker sync SSL mode fix

- User provided the next Docker output from v168_47.
- Backend and frontend images build, but `docker compose up` fails at
  backend startup.
- Confirmed runtime blocker: Alembic / psycopg2 requires SSL against
  local Docker Postgres.
- Root cause: `backend/migrations/env.py` auto-added
  `sslmode=require` for host `db` when the sync URL did not include
  an explicit sslmode.
- Repair: Docker `PSYCOPG_URL` now uses `sslmode=disable`.
- Repair: Alembic no longer forces SSL for local/dev/ci/test or
  Docker local hosts `db` and `postgres`.
- Async `DATABASE_URL` remains clean asyncpg without psycopg
  sslmode.


## v168_51 — FAQ / tunnel / routes / admin correction

- FAQ must be a vertical section/subsection/question tree, not a pill or
  quick-button interface.
- Profile must keep a visible FAQ entry.
- Cloudflare quick tunnel failure is diagnosed separately from EFHC
  runtime: local frontend and Docker-to-host frontend may work while
  `POST https://api.trycloudflare.com/tunnel` fails externally.
- Admin root must move toward clear app-button launcher cards, not a
  mixed technical proof page.
- Route targets must be checked with `ops/local/check_frontend_routes.py`.
