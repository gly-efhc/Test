# Утверждённый план EFHC — циклы 1640–1665

## Статус

Полностью утверждено пользователем 2026-08-04. Этот документ является
операционным планом. Последующие изменения порядка требуют прямой команды
пользователя.

## Процессный канон

- Один цикл — один основной контур.
- Не смешивать identity, visual, Admin UX и CI repair.
- Работать через Kernel Delta Protocol: current Kernel → evidence → первый
  causal defect → минимальный patch → targeted gate → exact-head gate.
- Каждый цикл закрывается отчётом:
  `результат → причина → исправление → влияние → проверки → открытые хвосты
  → следующий шаг → три архива`.
- В пользовательской Admin запрещён технический release/CI/evidence мусор;
  подробности хранятся в MATRIX_TECHNICAL.

## 1640–1650 — полный global_id cutover

### 1640 — write-side foundation qualification

- locked financial write owner resolver;
- один selector: `global_id` либо `global_id`;
- canonical `global_id` result;
- TON-only owner;
- idempotency audit;
- exact-head PostgreSQL/main CI qualification.

### 1641 — transactions/ledger canonical owner

- все credit/debit functions;
- `_ensure_user_locked`;
- ledger ownership по `global_id`;
- selector equivalence;
- TON-only financial path;
- compatibility read-through idempotency;
- защита от двойного начисления.

### 1642 — Panels, Withdrawals, Payment Intents

- сервисы и связанные owner queries;
- отсутствие обязательного `require_legacy_global_id()`;
- concurrency и equivalence tests.

### 1643 — Referral и idempotency normalization

- `REF_ACT_UNIT`;
- `REF_LVL`;
- exchange request key;
- новые keys по `global_id`;
- старые keys читаются;
- исторические ledger records не переименовываются.

### 1644 — Tasks, Ranks, Wallets

- task completion/ad reward/listing;
- rank/leaderboard;
- wallet credit/list/active-wallet;
- provider-neutral snapshot не менять без необходимости.

### 1645 — callers, achievements, cutover preparation

- routes, bot handlers, admin routes, scheduler;
- achievements `global_id`;
- API contracts;
- отдельная migration для изменяемого `legacy_authoritative`;
- production cutover не выполнять без прямой команды.

### 1646 — удаление runtime legacy aliases

- `*_by_global_id` owner aliases;
- `require_legacy_global_id()` из бизнес-path;
- fallback service signatures;
- canonical owner нельзя преобразовывать обратно в provider ID.

## 1647–1671 — 25 партий полного identity cutover

### 1647 — партия 1/25: Transactions и ledger — публичные signatures/callers

- целевой объём: 250 семантически связанных замен;
- контур: credit/debit, locked owner, ledger DTO и tests;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1648 — партия 2/25: Transactions — SQL/ORM compatibility

- целевой объём: 250 семантически связанных замен;
- контур: physical read-through, bind aliases, idempotency history;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1649 — партия 3/25: Panels

- целевой объём: 250 семантически связанных замен;
- контур: activation, ownership, scheduler, admin callers;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1650 — партия 4/25: Withdrawals

- целевой объём: 250 семантически связанных замен;
- контур: hold/refund, bank mirror, admin operations;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1651 — партия 5/25: Payment Intents

- целевой объём: 250 семантически связанных замен;
- контур: create/status/confirm, historical keys and payload parser;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1652 — партия 6/25: Referrals core

- целевой объём: 250 семантически связанных замен;
- контур: registration, links, rewards, self-referral guards;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1653 — партия 7/25: Referral routes and tests

- целевой объём: 250 семантически связанных замен;
- контур: API/frontend contracts, fixtures, integration paths;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1654 — партия 8/25: Tasks

- целевой объём: 250 семантически связанных замен;
- контур: catalog, completion, ad rewards, logs, handlers;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1655 — партия 9/25: Ranks and leaderboard

- целевой объём: 250 семантически связанных замен;
- контур: rank ownership, snapshots, routes and tests;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1656 — партия 10/25: Wallets and TON ownership

- целевой объём: 250 семантически связанных замен;
- контур: wallet lists, active wallet, proof boundary;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1657 — партия 11/25: Exchange and deposits

- целевой объём: 250 семантически связанных замен;
- контур: exchange requests, deposit ownership, reconciliation;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1658 — партия 12/25: Shop and orders

- целевой объём: 250 семантически связанных замен;
- контур: orders, balances, notifications, admin contracts;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1659 — партия 13/25: Achievements and outcomes

- целевой объём: 250 семантически связанных замен;
- контур: user progress, awards, snapshots;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1660 — партия 14/25: Admin financial services

- целевой объём: 250 семантически связанных замен;
- контур: users, panels, withdrawals, bank operations;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1661 — партия 15/25: Admin nonfinancial services

- целевой объём: 250 семантически связанных замен;
- контур: tasks, referrals, ranks, support searches;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1662 — партия 16/25: Routes and Pydantic contracts

- целевой объём: 250 семантически связанных замен;
- контур: self routes, DTO names, ambiguity guards;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1663 — партия 17/25: Frontend contracts

- целевой объём: 250 семантически связанных замен;
- контур: TypeScript types, requests, fixtures, browser/Telegram parity;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1664 — партия 18/25: Bot handlers and scheduler

- целевой объём: 250 семантически связанных замен;
- контур: provider boundary then canonical owner runtime;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1665 — партия 19/25: Workers, scripts and operator gates

- целевой объём: 250 семантически связанных замен;
- контур: jobs, reconciliation tools, architecture guards;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1666 — партия 20/25: ORM and physical schema preparation

- целевой объём: 250 семантически связанных замен;
- контур: column inventory, FK/index/constraint migration plan;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1667 — партия 21/25: Physical schema migration

- целевой объём: 250 семантически связанных замен;
- контур: provider columns, owner columns, backfill and rollback;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1668 — партия 22/25: Tests, fixtures and mocks

- целевой объём: 250 семантически связанных замен;
- контур: canonical selectors, provider-explicit naming, dead fixtures;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1669 — партия 23/25: SSOT/NORM/CANON cleanup

- целевой объём: 250 семантически связанных замен;
- контур: active documentation and release contracts;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1670 — партия 24/25: Alias-layer removal preparation

- целевой объём: 250 семантически связанных замен;
- контур: zero callers, ambiguity proof, compatibility expiry;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1671 — партия 25/25: Final alias removal and zero-token gate

- целевой объём: 250 семантически связанных замен;
- контур: remove compatibility layer, full exact-head qualification;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

## Сдвинутый прежний план

Все ранее запланированные работы, начинавшиеся с цикла 1647, сдвинуты на 25 циклов:

- прежние 1647–1650 → новые 1672–1675: integration matrix, technical qualification и cutover candidate;
- прежние 1651–1653 → новые 1676–1678: Public visual recovery;
- прежние 1654–1660 → новые 1679–1685: Admin Support Center;
- прежние 1661–1665 → новые 1686–1690: screenshot canon и итоговая qualification.

Production cutover, public visual, Admin redesign и screenshot workflow не смешиваются с партиями identity migration и выполняются только после завершения 25 партий.
