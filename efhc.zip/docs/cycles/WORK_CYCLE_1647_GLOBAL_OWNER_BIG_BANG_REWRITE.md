# Цикл 1647 — Global Owner Big-Bang Rewrite

## Фаза A — v172.65

- полный inventory всех `global_id`;
- boundary contract;
- массовая замена business runtime на `global_id`;
- alias-harness старого keyword;
- `telegram_provider_id` как явное имя provider fact;
- compile и structural cleanup;
- без функциональной квалификации.

Exit:

`GLOBAL_OWNER_BULK_REWRITE_READY_FOR_TEST_REPAIR`

## Фаза B — следующий пакет

- полный PostgreSQL CI;
- полный pytest;
- Ruff, Flake8, Mypy, Bandit;
- исправление signatures, SQL, fixtures, mocks и historical read-through;
- подтверждение Telegram и TON-only equivalence;
- подтверждение idempotency и concurrency.

Exit:

`GLOBAL_OWNER_BULK_REWRITE_TESTS_PASS`

## Фаза C — после PASS

- удалить `global_owner_alias.py`;
- удалить `User.tg_id`, `User.telegram_id` и иные synonyms;
- физически переименовать provider columns при подтверждённой миграции;
- удалить deprecated routes и fixtures;
- удалить historical compatibility registry после отдельного gate.

Exit:

`GLOBAL_ID_ONLY_BUSINESS_RUNTIME_AND_ALIASES_REMOVED`
