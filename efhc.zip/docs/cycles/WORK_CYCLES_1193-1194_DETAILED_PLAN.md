# WORK CYCLES 1193-1194 DETAILED PLAN

## Shared purpose

The goal of this pass is to repair audit findings, not to create a
paper-only status.  Cycle 1193 closes a false UI route in the panels
summary flow.  Cycle 1194 bounds helper/internal roads so they no longer
look like public release roads.

## Cycle 1193: false UI road repair

Problem:
- the panels UI still called `/panels/${global_id}/summary`;
- the canonical self route already existed as
  `GET /user/me/panels-summary`;
- keeping both active roads preserved a false UI and route drift risk.

Repair:
1. move the panels UI to `GET /user/me/panels-summary`;
2. remove active backend `GET /panels/{global_id}/summary`;
3. remove the stale path from OpenAPI and route SSOT maps;
4. add a guard and architecture test.

Done criteria:
- frontend uses the self route;
- backend no longer exposes the stale tg-id summary route;
- OpenAPI no longer exposes the stale path;
- guard 1193 returns `status: ok`.

## Cycle 1194: helper/internal boundary repair

Problem:
- `/cron/tick` and `/tg/webhook` are runtime infrastructure roads;
- they looked like normal public schema roads;
- helper/internal roads must not be confused with user-facing roads.

Repair:
1. keep the runtime routes active;
2. hide them from OpenAPI via `include_in_schema=False`;
3. keep their secret checks in active code;
4. mark them internal in SSOT route maps;
5. add a guard and architecture test.

Done criteria:
- the runtime routes remain in code;
- OpenAPI does not expose them;
- SSOT marks them as internal;
- guard 1194 returns `status: ok`.
