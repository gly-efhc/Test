# Рабочий цикл 1607 — Cross-language разделение GlobalId и TelegramId

Исходный HEAD: `EFHC_Bot_v172_03.zip`.
Целевой HEAD: `EFHC_Bot_v172_04.zip`.

## Цель

Согласовать nominal/branded типы backend/frontend и запретить прямое
либо косвенное смешение системного `GlobalId` с Telegram provider ID.

## Выполнено

1. Backend диапазон `TelegramId` ограничен positive safe integer.
2. Добавлен Pydantic-ready `ExternalTelegramId`.
3. Frontend получил branded number `TelegramId` и provider parser.
4. Telegram WebApp `user.id` проходит `telegramIdFromProvider`.
5. Добавлен воспроизводимый cross-language fixture.
6. Добавлен AST/TypeScript fail-closed guard.
7. Добавлены runtime, compile-time и negative causal tests.
8. Roadmap сокращён с 94 плановых слотов до 25 обязательных циклов.

## Неподвижная область

Alembic head `0002`; active routes, historical backfill, dual-write,
read switch, financial ownership и экономические формулы не менялись.

## Следующий цикл

`1608 — semantic allowlist и compatibility registry`.
## Финальная приёмка

- exact-tree: `2909` тестов;
- PASSED: `2737`;
- SKIPPED: `172`;
- FAILED/ERRORS: `0/0`;
- PostgreSQL: `БЛОКИРОВАНО_СРЕДОЙ`;
- release mirror: `753/753`;
- обязательных циклов осталось: `25`.
