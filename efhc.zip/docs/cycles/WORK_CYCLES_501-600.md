# WORK CYCLES 501-600

Этот файл открыт как следующий диапазон после закрытия блока `471-500`.

Смысл диапазона:
1. продолжать только подтверждённые log-driven и audit-driven исправления;
2. не подменять пользовательский GitHub CI локальными псевдо-прогонами;
3. фиксировать все новые подтверждённые дефекты в Healer в том же цикле;
4. вести следующие рабочие блоки только в пределах диапазона `501-600`.

- Done: 80/100
- Remaining: 20/100
- Last completed cycle: 600/600
- Next cycle: 601/600
- Block status: active

## Placeholder for future blocks

Следующие блоки и циклы этого диапазона будут добавляться сюда по мере запуска
новых задач.

## Cycles 501-505 — Audit tails short wave

Этот блок открыт после закрытия диапазона `471-500`.

Смысл блока:
1. собрать реальные хвосты из active audit-layer;
2. зафиксировать короткий план из пяти циклов на их доведение;
3. не выдавать residual warnings за code failures;
4. закрепить user-facing формат `Уточняющая итерация:` в AI-layer.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 505/505
- Next cycle: 506/600
- Block status: done

- 501/505 — done — собран `AUDIT_TAILS_ANALYSIS_2026_04_08.md` со списком всех текущих audit residuals.
- 502/505 — done — в AI docs закреплён user-facing формат `Уточняющая итерация:` для реально сложных и неоднозначных мест.
- 503/505 — done — собран `ORDERS_OVERLAP_COMPARE_MATRIX_2026_04_08.md` по policy-sensitive overlap вокруг `orders_service.py`.
- 504/505 — done — собран `FRONTEND_DEPENDENCY_WAVE_PREP_2026_04_08.md` по warning на `next@14.2.5` как отдельной dependency wave.
- 505/505 — done — собран `CI_RESIDUAL_HANDLING_NOTE_2026_04_08.md` по chat-only handling GitHub Actions Node 20 warning и создан `AUDIT_TAILS_5_CYCLES_PLAN_2026_04_08.md`.


## Cycles 506-510 — Release blockers wave 1

Этот блок открыт по двум новым релизным аудитам v165.

Смысл блока:
1. убрать прямой runtime break в withdraw cancel;
2. собрать отдельный пользовательский путь `/withdraw`;
3. перестать выдавать `sale-packages` за боевой SSOT-модуль;
4. синхронизировать cycle/report/audit слой после первой blocker-wave.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 510/510
- Next cycle: 511/600
- Block status: done

- 506/510 — done — выровнен контракт `withdraw cancel`: route/service теперь принимают один и тот же набор аргументов; повторная отмена возвращает консистентный outcome без runtime TypeError.
- 507/510 — done — добавлена отдельная страница `frontend/src/pages/withdraw.tsx` с create/list/detail контуром.
- 508/510 — done — добавлены явные входы в `/withdraw` из `exchange` и profile history.
- 509/510 — done — `sale-packages` убраны из основной admin index карты и переведены во frontend в internal draft / read-only surface.
- 510/510 — done — собраны `RELEASE_AUDITS_COMPARATIVE_AGAINST_HEAD_2026_04_08.md`, `RELEASE_REMEDIATION_PLAN_506_530_2026_04_08.md` и change report этой волны.


## Cycles 511-515 — Release hardening wave 2

Этот блок продолжает два новых релизных аудита после снятия прямого cancel
blocker.

Смысл блока:
1. довести `sale-packages` до бинарного статуса not-SSOT / non-release;
2. закрепить правило подробных cycle docs как memory/control layer;
3. усилить operator UX в withdrawals и bank.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 515/515
- Next cycle: 516/600
- Block status: done

- 511/515 — done — оба новых PDF-аудита добавлены в `docs/audits/`, а mutating routes `admin_sale_packages_routes.py` переведены в `409 non-release` режим.
- 512/515 — done — в AI docs закреплено правило: cycle docs должны вестись подробно, потому что это память, направление и внечатовое хранилище пути.
- 513/515 — done — `frontend/src/pages/admin/withdrawals.tsx` усилен confirm-step с context block перед approve/reject.
- 514/515 — done — `frontend/src/pages/admin/bank.tsx` усилен confirm-step с preview текущего и ожидаемого bank balance.
- 515/515 — done — собран `RELEASE_HARDENING_WAVE_511_515_2026_04_08.md`, синхронизированы cycle/report/Healer слои этой волны.


## Cycles 516-520 — Operator workflow wave 3

Этот блок продолжает operator hardening после волн 511-515.

Смысл блока:
1. вынести EFHC deposit processing из сырой кнопки в отдельный workflow;
2. усилить referral manual actions preview/reason layer;
3. синхронизировать новый operator path в docs и reports.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 520/520
- Next cycle: 521/600
- Block status: done

- 516/520 — done — создана страница `frontend/src/pages/admin/efhc-deposits.tsx` как отдельный workflow ручной обработки внешних EFHC-депозитов.
- 517/520 — done — `frontend/src/pages/admin/index.tsx` очищен от сырой deposit-кнопки; EFHC deposits теперь живёт как отдельный admin module entry.
- 518/520 — done — `frontend/src/pages/admin/referrals.tsx` получил effect preview для manual bonus.
- 519/520 — done — `frontend/src/pages/admin/referrals.tsx` получил reason + effect preview для reassign.
- 520/520 — done — собран `OPERATOR_WORKFLOW_WAVE_516_520_2026_04_08.md`, синхронизированы cycle/report/Healer слои этой волны.


## Cycles 521-525 — Deposit status wave 4

Этот блок продолжает remediation после волн 516-520.

Смысл блока:
1. закрыть Mini App deposit result/status gap;
2. дать пользователю повторный вход в незавершённый deposit intent;
3. снизить риск duplicate intent creation в активном money-flow;
4. синхронизировать control/docs слой после user-flow hardening.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 525/525
- Next cycle: 526/600
- Block status: done

- 521/525 — done — `frontend/src/components/DepositModal.tsx` получил status block для текущего deposit intent с polling owner-only `/payment-intents/{intent_id}`.
- 522/525 — done — добавлено восстановление последнего deposit intent через `sessionStorage`, чтобы пользователь видел незавершённый сценарий после повторного входа в modal.
- 523/525 — done — добавлена защита от повторного создания нового deposit intent, пока текущий имеет статус `PENDING` или `SENT`.
- 524/525 — done — добавлен явный сброс terminal intent state после `CONFIRMED/EXPIRED/CANCELED`.
- 525/525 — done — собран `DEPOSIT_STATUS_WAVE_521_525_2026_04_08.md`, синхронизированы cycle/report/Healer слои этой волны.


## Cycles 526-530 — External shop prep wave 5

Этот блок начинает подготовку внешней shop-страницы к отдельному release-grade блоку 531-540.

Смысл блока:
1. честно закрепить текущую MVP-рамку внешней витрины;
2. усилить browser-shop UX без большого рефакторинга;
3. добавить repeat-entry и anti-duplicate protection для storefront intent path;
4. подготовить cycle-layer и release-plan для блока 531-540.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 530/530
- Next cycle: 531/600
- Block status: done

- 526/530 — done — `BrowserShopPage` получил честную release-рамку: текущий статус витрины явно показан как MVP external storefront, а не полный релизный shop.
- 527/530 — done — в `BrowserShopPage` добавлен step-by-step блок user path и усилены next-step тексты вокруг handoff / wallet sync / intent flow.
- 528/530 — done — добавлено восстановление последнего browser-shop intent через `sessionStorage` и фоновой polling status после повторного входа.
- 529/530 — done — добавлена защита от duplicate browser-shop intent creation при активных статусах `PENDING` / `SENT` и явный cleanup terminal intent state.
- 530/530 — done — собран `EXTERNAL_SHOP_RELEASE_PLAN_531_540_2026_04_08.md`, синхронизированы cycle/report/Healer слои и открыт следующий блок 531-540 как реалистичный план доведения внешнего storefront до release-grade состояния.

## Cycles 531-540 — External shop release plan

Этот блок открыт как следующий реалистичный контур доведения внешней shop-страницы до релизного смысла.

Смысл блока:
1. не обещать полный новый commerce-core;
2. довести текущий browser-shop storefront до release-grade user/admin truth-layer;
3. закрыть route/UX/SSOT clarity и собрать proof of readiness.

- Done: 10/10
- Remaining: 0/10
- Last completed cycle: 540/540
- Next cycle: 541/600
- Block status: done

- 531/540 — done — собран `EXTERNAL_SHOP_RELEASE_MATRIX_2026_04_08.md` с точной картой frontend surfaces, routes, services, tables и admin truth-layer.
- 532/540 — done — `BrowserShopPage` получил stronger shell/readiness summary с явным storefront mode и общей backend payment truth рамкой.
- 533/540 — done — усилен storefront next-step / return-path слой, включая terminal return CTA в Telegram.
- 534/540 — done — доведены payment details warnings: страница теперь явно предупреждает не менять сумму / кошелёк / memo вручную.
- 535/540 — done — собран `EXTERNAL_SHOP_RELEASE_EVIDENCE_CHECKLIST_2026_04_08.md`, синхронизированы cycle/report/Healer слои этой волны.
- 536/540 — done — оформлена правильная access-модель отдельной интернет-страницы в `EXTERNAL_SHOP_ACCESS_MODEL_2026_04_08.md`.
- 537/540 — done — добавлен dedicated backend namespace `/shopfront/*` как модуль storefront access/bootstrap/catalog/create-intent/status.
- 538/540 — done — добавлен Telegram-side entry module `/shop` для открытия внешнего storefront по signed access key.
- 539/540 — done — собран `ADMIN_STOREFRONT_TRUTH_SYNC_NOTE_2026_04_08.md` по общему truth-layer между storefront и admin.
- 540/540 — done — собран `EXTERNAL_SHOP_REAUDIT_SLICE_2026_04_08.md` и зафиксирован текущий slice-вердикт по modular storefront access model.


## Cycles 541-545 — Storefront wallet preload wave 8

Этот блок реализует согласованную модель storefront login + wallet preload.

Смысл блока:
1. после Telegram-входа storefront должен сразу видеть связанные кошельки;
2. wallet truth-layer остаётся общим backend truth;
3. storefront получает wallet preload через bootstrap, а не строит его локально.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 545/545
- Next cycle: 546/600
- Block status: done

- 541/545 — done — `BrowserShopBootstrapOut` расширен полем `wallets` для storefront wallet preload.
- 542/545 — done — `hub` / `shopfront` bootstrap возвращают список связанных кошельков для handoff-bound entry.
- 543/545 — done — `BrowserShopPage` получил wallet preload block с отображением связанных кошельков и активного статуса.
- 544/545 — done — собран `STOREFRONT_WALLET_PRELOAD_WAVE_541_545_2026_04_08.md` с фиксацией согласованной модели.
- 545/545 — done — синхронизированы cycle/report/Healer слои этой волны.


## Cycles 546-550 — Web portal future entry wave 9

Этот блок переводит внешнюю страницу из режима узкой витрины в режим web portal surface.

Смысл блока:
1. страница должна уже сейчас выглядеть как полноценный внешний портал;
2. при этом нельзя выдавать её за уже готовую независимую web-игру;
3. нужно заложить честную модель будущего полного входа в игру.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 550/550
- Next cycle: 551/600
- Block status: done

- 546/550 — done — расширен bootstrap contract полями `access_mode`, `future_game_entry_enabled`, `available_modules`.
- 547/550 — done — внешняя страница переведена в framing `EFHC Web Portal`, а не только narrow browser-shop storefront.
- 548/550 — done — portal shell теперь показывает доступные модули и current/future entry state.
- 549/550 — done — собран `WEB_PORTAL_FUTURE_GAME_ENTRY_PLAN_546_550_2026_04_08.md` с фиксацией будущей модели полного web entry.
- 550/550 — done — синхронизированы cycle/report/Healer слои этой волны.


## Cycles 551-570 — Independent user ID optional plan

Этот блок открыт как **опциональный** migration-track, а не как срочный must-fix.

Смысл блока:
1. подготовить независимый `user_id` только если продукт захочет жить вне Telegram;
2. не ломать текущий `tg_id`-контур, если сайт продолжит логиниться через Telegram external binding;
3. держать план автономии как отдельный future track.

- Done: 0/20
- Remaining: 20/20
- Last completed cycle: none
- Next cycle: 551/600
- Block status: planned

- 551/570 — planned — release-architecture note for optional `user_id` layer.
- 552/570 — planned — identity-link mapping layer design.
- 553/570 — planned — profile/balance/progress ownership design on `user_id`.
- 554/570 — planned — impact map of tables/routes/services currently dominated by `global_id`.
- 555/570 — planned — migration/risk note for what must not break.
- 556/570 — planned — additive schema strategy for internal `user_id`.
- 557/570 — planned — `telegram -> user_id` identity-link model.
- 558/570 — planned — backfill strategy for existing users.
- 559/570 — planned — `global_id -> user_id` resolver bootstrap.
- 560/570 — planned — guard/tests note for dual-ID drift prevention.
- 561/570 — planned — shared user resolver service design.
- 562/570 — planned — new web/storefront scenarios on `user_id`-compatible resolution.
- 563/570 — planned — wallet ownership compatibility path.
- 564/570 — planned — payment/storefront ownership compatibility path.
- 565/570 — planned — admin lookup note for `user_id` + linked ids.
- 566/570 — planned — web auth plan over `user_id`.
- 567/570 — planned — standalone web session model.
- 568/570 — planned — future account-link flow for Telegram/web/wallet/email/passkey.
- 569/570 — planned — portal/game entry contract on `user_id`.
- 570/570 — planned — narrow re-audit and next implementation block opening.


## Cycles 571-575 — Web profile wave 10

Этот блок реализует отдельный web profile для пользователей с Telegram-привязкой.

Смысл блока:
1. дать отдельную внешнюю страницу профиля;
2. показывать `global_id`, кошельки и покупки на web profile surface;
3. использовать тот же signed access key и общий backend truth-layer.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 575/575
- Next cycle: 576/600
- Block status: done

- 571/575 — done — расширен backend `/shopfront/*` новым route `GET /shopfront/profile`.
- 572/575 — done — добавлена отдельная страница `frontend/src/pages/web-profile.tsx`.
- 573/575 — done — реализован `WebProfilePage` с загрузкой профиля по signed Telegram access key.
- 574/575 — done — web profile показывает связанные кошельки и историю покупок.
- 575/575 — done — собран `WEB_PROFILE_WAVE_571_575_2026_04_08.md`, синхронизированы cycle/report/Healer слои этой волны.


## Cycles 576-580 — Web portal visual wave 11

Этот блок усиливает визуальное качество внешнего контура без смены логики.

Смысл блока:
1. сделать внешнюю страницу визуально более продуктовой;
2. выровнять внешний вид shop entry / portal / web profile;
3. не трогать truth-layer и access model ради косметики.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 580/580
- Next cycle: 581/600
- Block status: done

- 576/580 — done — `ShopEntryPage` получил hero block и summary cards.
- 577/580 — done — `BrowserShopPage` получил hero block и portal summary cards.
- 578/580 — done — `WebProfilePage` получил hero block и account summary cards.
- 579/580 — done — внешний контур выровнен по visual framing как единый product surface.
- 580/580 — done — собран `WEB_PORTAL_VISUAL_WAVE_576_580_2026_04_08.md`, синхронизированы cycle/report/Healer слои.


## Cycles 581-585 — Frontend repair wave 12

Этот блок открыт по двум новым PDF-аудитам фронтенда.

Смысл блока:
1. добавить новые PDF-аудиты в active archive layer;
2. сравнить их с текущим HEAD после последних web waves;
3. открыть большой ремонтный блок 581-610;
4. начать первую repair-wave по user-flow stitching и discoverability.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 585/585
- Next cycle: 586/600
- Block status: done

- 581/585 — done — оба новых PDF-аудита добавлены в `docs/audits/`.
- 582/585 — done — собран `FRONTEND_AUDITS_COMPARATIVE_AGAINST_HEAD_2026_04_08.md`.
- 583/585 — done — собран `FRONTEND_REPAIR_PLAN_581_610_2026_04_08.md` по двум новым аудитам.
- 584/585 — done — открыт `docs/cycles/WORK_CYCLES_601-700.md` как следующий диапазон.
- 585/585 — done — синхронизированы cycle/report/control слои и открыт active block 581-610.


## Cycles 586-590 — Frontend stitching wave 13

Этот блок запускает первую реальную repair-wave после двух новых PDF-аудитов.

Смысл блока:
1. снизить friction между portal, web profile и Telegram entry;
2. сделать route ownership более явным;
3. усилить discoverability внешних surfaces без смены backend truth-layer.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 590/590
- Next cycle: 591/600
- Block status: done

- 586/590 — done — `WebProfilePage` получил action-links обратно в portal и Telegram.
- 587/590 — done — `BrowserShopPage` получил более явный route-ownership / usage block и cross-navigation.
- 588/590 — done — собран `FRONTEND_ROUTE_OWNERSHIP_MATRIX_2026_04_08.md`.
- 589/590 — done — собран `FRONTEND_TERMINOLOGY_NOTE_2026_04_08.md`.
- 590/590 — done — синхронизированы cycle/report/control слои этой stitching-wave.


## Cycles 591-600 — Frontend localization wave 14

Этот блок закрывает первую прицельную localization-wave после новых frontend-audits.

Смысл блока:
1. убрать raw string leakage из самых заметных внешних web surfaces;
2. перевести portal / shop entry / web profile на единый `useT()` путь;
3. добавить недостающие locale-ключи в активный locale-layer;
4. использовать песочницу только как donor/reference, без слепого переноса кода.

- Done: 10/10
- Remaining: 0/10
- Last completed cycle: 600/600
- Next cycle: 601/600
- Block status: done

- 591/600 — done — `ShopEntryPage` переведён с raw user-facing strings на `useT()`.
- 592/600 — done — `BrowserShopPage` переведён на `useT()` для portal/storefront/status copy.
- 593/600 — done — `WebProfilePage` переведён на `useT()` и починен missing `Button` import.
- 594/600 — done — добавлены locale-ключи для portal/shop/profile slice во все `frontend/public/locale/*.json`.
- 595/600 — done — очищены оставшиеся raw labels в portal/profile slice (`TON only`, wallet badges и т.п.).
- 596/600 — done — собран `FRONTEND_LOCALIZATION_WAVE_591_600_2026_04_08.md`.
- 597/600 — done — собран `FRONTEND_SANDBOX_REVIEW_NOTE_2026_04_08.md`.
- 598/600 — done — цикл зафиксировал правило: sandbox = donor/reference, не источник слепого копирования в HEAD.
- 599/600 — done — синхронизированы cycle/report/control документы после localization-wave.
- 600/600 — done — собран новый архив wave 14 и обновлён HEAD.
