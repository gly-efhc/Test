# Cycle 1529 — Fresh CI Evidence Intake / Red-log Repair

## Status

`DONE_LOCALLY_AFTER_RED_LOG_REPAIR`.

## Input

- HEAD: `EFHC_Bot_v171_03_cycle_1528_kernel_map_compaction_test_consolidation.zip`.
- Log: `logs_74445426759.zip`.

## Output target

`EFHC_Bot_v171_04_cycle_1529_fresh_ci_log_repair_kernel_anchor_restore.zip`.

## Log verdict

The log was red at pytest gate only.

Passed in the uploaded log:

- ruff;
- mypy;
- bandit;
- compileall;
- Alembic upgrade head;
- npm ci;
- frontend build.

Failed in the uploaded log:

- pytest: `24 failed, 1933 passed, 8 skipped, 2 warnings`.

## Root cause

The compact Kernel pass in cycle 1528 removed historical navigation anchors
from `KERNEL.md`, while legacy architecture guards still required those exact
anchors in the root Kernel.

## Repair

- Restored compact compatibility anchors in `KERNEL.md`.
- Added current cycle 1529 navigation to `map_element.md`.
- Added route compatibility comments to `routes.yaml`.
- Added this cycle norm, report and guard.
- Updated work-cycle docs, release proof status, reports index and test guard
  manifest.

## Local replay

Targeted replay of all logged Kernel-anchor pytest failures passed locally:

`25 passed`.

The extra count is intentional: one affected file had two navigation tests
that protect the same cycle surface.

## Boundary

Runtime, money-flow, wallet-flow, withdraw logic, TonConnect behavior,
frontend runtime and EFHC economy were not changed.

## Non-claims

GitHub CI green for output archive, full pytest green, full frontend build
green, live Telegram proof, real TonConnect proof and release-ready are not
claimed.

## Next safe cycle

`1530 — Fresh CI Rerun Confirmation / Remaining Guard Drift Intake`.
