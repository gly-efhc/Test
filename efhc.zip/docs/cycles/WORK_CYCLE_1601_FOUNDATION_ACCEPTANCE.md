# Рабочий цикл 1601 — открытие диапазона и приёмка фундамента

Исходный HEAD: `EFHC_Bot_v171_97.zip`.
Нулевая точка: `EFHC_Bot_v171_89.zip`.
Целевой HEAD: `EFHC_Bot_v171_98.zip`.

## Цель

Независимо принять фундамент циклов 1593–1600, подтвердить отсутствие
скрытого backfill/read switch/financial ownership switch и сформировать
воспроизводимый вход для диапазона 1601–1700.

## Независимая приёмка архивов

- baseline SHA-256:
  `21babdb44702b76afd81ddb3664a4dc0637fd478a33b5874259225773cba71dd`;
- baseline ZIP entries: `4808`;
- Current HEAD SHA-256:
  `da48b887bb0a55f2749ef95df88fde67665b8ef542a760f5e2e92b9f2e075232`;
- Current HEAD ZIP entries: `5535`;
- CRC: пройден;
- path traversal: не обнаружен;
- symlink и специальные файлы: не обнаружены.

## Независимый diff v171.89 → v171.97

- файлов baseline: `4569`;
- файлов Current HEAD: `5274`;
- добавлено: `705`;
- изменено: `75`;
- удалено: `0`;
- неизменено: `4494`.

Runtime-изменения ограничены EXPAND-фундаментом `users.user_id`,
identity helper-модулями и документирующими комментариями. Изменений
экономических формул и финансового ownership не обнаружено.

## Выявленный дефект

`audit_global_id_usage.py`, `render_identity_audit_russian.py` и
`postgresql_environment_preflight.py` формировали новые результаты с
жёстко заданными provenance-метаданными старых циклов. Фактические
метрики пересчитывались, но report мог ошибочно называться доказательством
`v171.95/1598` либо `1599`.

## Исправление

- exact `source_head`, `baseline_head` и `cycle` передаются явно;
- пустой HEAD и неположительный цикл отклоняются;
- добавлены причинные положительные и отрицательные тесты;
- runtime, БД и экономика не изменялись.

## PostgreSQL

Среда заблокирована: нет PostgreSQL URL, синхронного драйвера, `psql`,
PostgreSQL Server, Docker и Podman. Реальная reconciliation не
выполнена. Historical backfill и read switch запрещены.

## Следующий цикл

`1602 — независимый reconciliation baseline`.

## Применимость guards

Исторические patch-boundary циклов 1595–1596 не применяются к текущему
HEAD как вечный запрет. Их manifests сохранены неизменными для проверки
исторических target-head. Current HEAD контролируют активные EXPAND,
LEGACY alias, reconciliation, domain boundary и closure guards.
