
## v168_49 correction note

The previous Dragon-style compression went too far on the public first
screen.  The approved boundary is now restored: visual polish may
improve surfaces, but it must not add new Energy action entries or hide
core balances without chat approval.  HUB and Wallet/Profile entries are
not first-screen Energy actions.

## v168_44 cycles 1251-1260 note

Fresh log `logs_69555566503.zip` is green: all gate exit files are
zero, pytest reports 538 passed, npm build is green in GitHub CI and
backend security/static checks passed.  The pass therefore worked on
remaining visual and audit tails instead of log failures.

Closed cycle notes:

- 1251: Panels page uses compact list containment and GameDetails for
  activation context and per-panel technical details.
- 1252: Exchange page keeps the amount selector visible and moves
  advanced proof/withdraw detail into GameDetails drawers.
- 1253: Tasks page keeps active earning cards visible and moves the
  long help text into a compact GameDetails drawer.
- 1254: Referrals page keeps invite/share primary and moves system and
  level detail into compact drawers.
- 1255: Ranks page keeps the user card and podium visible, with the
  full table and extended leaderboard in drawers.
- 1256: Existing clean empty states are preserved and protected as the
  public fallback for inactive modules.
- 1257: Public loading/error states remain non-technical and use safe
  labels instead of raw exception text.
- 1258: All canonical route entry points remain intact.
- 1259: Added a static guard for GameDetails usage, route preservation
  and dependency warning tail closure.
- 1260: Documented compact proof and remaining proof boundary.

## v168_43 implementation note — cycles 1246-1250

The 1246-1250 part of the Dragon-style plan is implemented in EFHC
branding, not by copying Dragon assets.  Energy now has compact resource
chips for EFHC and kWh, a HUB bridge card, a Wallet/Profile card and an
action-count guard.  The canonical bottom menu is preserved.

# WORK CYCLES 1231-1350 — Dragon-style visual functions plan
Status: planned after reference sandbox intake cycle 1206.
Scope: visual and UX restructuring only. All EFHC functions,
economy, balances, bank ledger and backend roads remain EFHC.

## Purpose

Implement a Dragon-like compact game shell for EFHC without
copying the external brand.  EFHC keeps its identity: energy,
panels, kWh, EFHC, ranks, green economy and wallet safety.

## 1231-1240 reference intake and design tokens

- 1231: Document final Dragon reference UI principles for EFHC.
- 1232: Create EFHC visual token map for cards, glow, badges and bars.
- 1233: Define compact first-screen information hierarchy.
- 1234: Define progressive disclosure rules for all large pages.
- 1235: Map Dragon-style progress bars to EFHC energy progress.
- 1236: Map Dragon-style resource chips to EFHC, kWh and panels.
- 1237: Define icon and asset replacement plan using EFHC branding.
- 1238: Define mobile and desktop browser frame constraints.
- 1239: Create visual regression checklist for Dragon-style migration.
- 1240: Update Healer with risks of copying reference brand too closely.

## 1241-1260 compact home and first buttons

- 1241: Build compact EFHC game home skeleton behind existing route.
- 1242: Compress first-screen actions to a small visible action set.
- 1243: Move secondary actions into expandable cards or drawers.
- 1244: Add energy progress bar with kWh and active panels summary.
- 1245: Add rank/progress card with compact next-level signal.
- 1246: Add EFHC balance chip without exposing technical payment data.
- 1247: Add HUB card as one clean bridge action.
- 1248: Add Profile/Wallet entry as a compact card or chip.
- 1249: Keep existing bottom menu while testing compressed home.
- 1250: Add guard for maximum first-level public action count.
- 1251: Compress Panels page into summary plus expandable details.
- 1252: Compress Exchange page into amount selector plus
  advanced drawer.
- 1253: Compress Tasks page into active tasks and expandable archive.
- 1254: Compress Referrals page into invite card plus expandable stats.
- 1255: Compress Ranks page into progress ladder and details drawer.
- 1256: Add consistent empty states for inactive modules.
- 1257: Add compact error and loading states across user pages.
- 1258: Check all compressed pages keep existing route entry points.
- 1259: Add static guard for no hidden feature deletion.
- 1260: Document compact home proof and remaining blockers.

## 1261-1280 desktop/browser game shell

- 1261: Define browser desktop entry strategy for EFHC game shell.
- 1262: Add desktop-safe shell without Telegram-only hard dependency.
- 1263: Add centered PC game frame and responsive max width.
- 1264: Separate Telegram Mini App chrome from browser chrome.
- 1265: Add safe fallback for missing Telegram init data.
- 1266: Add browser route for read-only or limited game launch mode.
- 1267: Add auth/token requirement notes for money actions in browser.
- 1268: Add disabled-state explanations for browser-only
  unavailable actions.
- 1269: Ensure Direct Deposit still requires safe wallet flow.
- 1270: Ensure Browser-Shop remains separate from core game shell.
- 1271: Add desktop shell smoke guard for key routes.
- 1272: Add route audit for Telegram-only buttons in browser mode.
- 1273: Add visual tokens for desktop background and game frame.
- 1274: Add desktop profile entry and language dropdown access.
- 1275: Add desktop state banner for Telegram connection status.
- 1276: Add operator diagnostics for browser-shell launch state.
- 1277: Add docs for PC launch limitations and allowed actions.
- 1278: Run TypeScript proof for desktop shell paths.
- 1279: Run route proof for shell entry pages.
- 1280: Document desktop shell status without claiming full release.

## 1281-1300 interaction compression and button repair

- 1281: Inventory all public buttons and their handlers.
- 1282: Classify buttons as primary, secondary, hidden or admin-only.
- 1283: Add visible feedback for async buttons before API completion.
- 1284: Add disabled-state reason copy for wallet/token/TG requirements.
- 1285: Replace silent no-op patterns with visible user feedback.
- 1286: Audit MainButton Telegram handlers versus visible buttons.
- 1287: Move duplicate profile shortcuts into one compact
  profile surface.
- 1288: Move duplicate payment shortcuts into Wallet/Profile or HUB.
- 1289: Guard against public admin/debug controls outside admin.
- 1290: Guard against route buttons pointing to missing pages.
- 1291: Add click-flow static map for main pages.
- 1292: Add frontend call matrix for compact pages.
- 1293: Fix confirmed non-reactive buttons by route or feedback.
- 1294: Document which actions are intentionally disabled by state.
- 1295: Add compact toasts for common button outcomes.
- 1296: Add mobile tap target and spacing consistency check.
- 1297: Add keyboard/browser accessibility for desktop shell controls.
- 1298: Update visual NORM with compressed interaction rules.
- 1299: Update Healer with remaining interaction blockers.
- 1300: Create verdict for compression wave 1281-1300.

## 1301-1325 EFHC visual polish wave

- 1301: Introduce EFHC energy-card style across main pages.
- 1302: Introduce consistent progress-bar component for energy/rank.
- 1303: Introduce resource-chip component for EFHC, kWh and panels.
- 1304: Introduce action-card component for first-level actions.
- 1305: Introduce drawer component for secondary details.
- 1306: Migrate HUB visuals to match compact action-card style.
- 1307: Migrate Direct Deposit visuals to compact safe-payment style.
- 1308: Migrate Browser-Shop cards to EFHC storefront style.
- 1309: Migrate Profile top zone to compact account style.
- 1310: Migrate Wallet section to compact security style.
- 1311: Migrate History section to compact operation timeline.
- 1312: Migrate Panels page to energy-machine style.
- 1313: Migrate Exchange page to simple converter style.
- 1314: Migrate Tasks page to reward-card style.
- 1315: Migrate Referrals page to invite-growth style.
- 1316: Migrate Ranks page to ladder/progress style.
- 1317: Add consistent skeleton loading UI.
- 1318: Add consistent empty states for no panels/tasks/referrals.
- 1319: Add error cards with one recovery action.
- 1320: Add language dropdown consistency in desktop and mobile shells.
- 1321: Add visual guard for no technical words in compact UI.
- 1322: Add screenshot checklist for compact home and storefront.
- 1323: Update docs with final component naming.
- 1324: Update reports with polish wave evidence.
- 1325: Create polish wave verdict without CI green claim.

## 1326-1350 release evidence and hardening

- 1326: Run static guard pack for public visual blockers.
- 1327: Run static guard pack for compact button routes.
- 1328: Run TypeScript proof for compact shell changes.
- 1329: Run focused tests for payment and profile language roads.
- 1330: Regenerate frontend call matrix for compact pages.
- 1331: Regenerate route registry evidence.
- 1332: Update ROAD_INTEGRITY_MATRIX for visual shell routes.
- 1333: Update API_CONTRACTS only where contracts changed.
- 1334: Update VISUAL_FRONTEND_PUBLIC_UI_NORM.
- 1335: Update TESTS_CATALOG with all Dragon-style guards.
- 1336: Update Q/A register with approved iteration answers.
- 1337: Update Healer with closed and open visual blockers.
- 1338: Update reports index and change reports.
- 1339: Check ZIP hygiene and junk exclusion.
- 1340: Check no external Dragon brand assets entered EFHC archive.
- 1341: Check no EFHC economic routes were changed by visual work.
- 1342: Check admin diagnostics still contains moved technical data.
- 1343: Check public UI has no endpoint/debug/truth-layer leaks.
- 1344: Check browser shell has fallback for missing Telegram runtime.
- 1345: Check desktop route opens without Telegram-only crash.
- 1346: Check Browser-Shop remains separate external storefront.
- 1347: Prepare final visual evidence audit.
- 1348: Prepare corrected range verdict for 1231-1350.
- 1349: List not-proven items requiring user browser/CI proof.
- 1350: Issue final Dragon-style visual integration verdict.

## Non-goals

- Do not copy Dragon brand, names or copyrighted assets.
- Do not remove EFHC functions during visual compression.
- Do not change bank ledger or EFHC economic canon.
- Do not claim GitHub CI green without user logs.

## v168_25 clarification

The Dragon-style program is visual only.

Canonical EFHC navigation remains:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

The first screen remains the Energy/progress/generation screen.
It is not a first-action button screen.

Future Dragon-style work must adapt:

- game cards;
- progress bars;
- compact subsections;
- desktop browser shell;
- Web3-like storefront path through HUB.

It must not rename or collapse canonical EFHC pages.

## v168_26 correction after user answers

The Dragon-style program must not replace EFHC navigation.
The six bottom buttons remain canonical.
Energy remains the first screen.

Dragon-style migration is now defined as:

- visual tokens;
- compact cards;
- progress bars;
- resource chips;
- browser/PWA shell;
- Web3-style Browser-Shop through HUB;
- no route/name/function removal without separate approval.

Full Dragon code was not fully readable in the current sandbox because
RAR text extraction needs an external backend.  The visible file
list and assets still support the browser-app conclusion.
It is a web bundle with Telegram integration plus install/PWA-style
resources.


## Correction from cycle 1211

Dragon-style implementation means visual compression, game feedback,
progressive disclosure and browser/PWA shell behavior.  It does not mean
renaming EFHC sections, merging canonical pages or exposing hidden
Energy progression levels in Ranks.

Future Dragon-style cycles must respect:

- Energy remains Energy;
- Panels remains Panels;
- Exchange remains Exchange;
- Tasks remains Tasks;
- Referrals remains Referrals;
- Ranks remains Ranks;
- approvals are made in chat first.

## v168_29 WebApp/PWA target

Long-range Dragon-style work must produce an EFHC web application that
opens both inside Telegram and directly in a normal browser.  Browser
installation is handled by the system browser install prompt through the
PWA manifest/service-worker layer.

Do not add a separate fake install button unless the user approves it in
chat.

## v168_40 implementation sync

Cycles 1231-1232 are now actual code cycles, not only plan text.

### Cycle 1231 result

- Attempted public tunnel live-check.
- Result: `502 Bad Gateway`; no live proof claimed.
- FAQ overflow blocker fixed with application-frame containment.

### Cycle 1232 result

- Wallet route page continued into EFHC Game UI Kit style.
- HUB rebuilt with Game UI Kit primitives.
- Browser-Shop rebuilt with Game UI Kit storefront primitives.
- Public raw storefront error text hidden.

### Remaining visual road

- 1233-1235: Wallet state-map and TonConnect proof UI.
- 1236-1238: Browser-Shop checkout state proof.
- 1239-1240: HUB handoff proof and Admin diagnostics split.
- 1241-1260: live browser/Docker proof waves.

## 1233-1235 Wallet/TonConnect runtime state layer

Status: done as v168_41 foundation.

- Wallet state-map is now visible in `/web-profile`.
- TonConnect proof UI has explicit public states.
- Browser-Shop and HUB remain on Game UI Kit path.
- Next step is live runtime proof and then deeper visual polish.

## v168_42 execution update

The 1236-1245 slice was executed as a combined log-repair and visual
polish pass.

- Resource/status chip direction was started with `GameStatusPill`.
- Wallet state-map now has compact visual state rows.
- Browser-Shop hero now exposes a clean runtime state pill.
- HUB keeps pending/disabled state coverage while staying a bridge.
- Browser-Shop TON-only MVP boundary was restored after guard drift.
- Route and DB SSOT documents were re-synced to current CSV truth.

Cycles 1246-1250 remain open for live visual proof and deeper polish.
