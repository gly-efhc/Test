# LEGACY PATH — roadmap user_id

Статус: `SUPERSEDED / COMPATIBILITY POINTER`.

Активный roadmap:

`docs/cycles/WORK_CYCLES_1601-1700_GLOBAL_ID_MODULAR_AUTH_PLAN.md`

Предыдущая версия сохранена:

`docs/history/identity/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN_PRE_GLOBAL_ID_v171_98.md`

Физическое имя `users.user_id` сохраняется до controlled rename, но
главный идентификатор единого аккаунта называется `global_id`.
