# EFHC — ЦИКЛЫ 1601–1700
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `EFHC_WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Статус перехода к диапазону 1601–1700

Циклы `1593–1600` локально закрыты в `EFHC_Bot_v171_97.zip`.
Сформированы аудит, guards, типы `UserId`/`TelegramId`, внешний
API-контракт, nullable EXPAND `users.user_id`, LEGACY alias,
backfill harness и PostgreSQL reconciliation gate.

Реальная PostgreSQL-сверка не выполнена. Historical backfill и
runtime read switch запрещены. Следующий цикл — `1601`; следующая
изменённая версия — `v171.98`.

---

## Источник: `WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Расширение плана до 1640 — v172.51

Новая последовательность:

- `1634` — чаты, Q/A и public UI foundation;
- `1635` — corrective public/admin visual parity;
- `1636` — ядро AccountRegistrationService;
- `1637` — Telegram Bot через единый центр;
- `1638` — provider-neutral referral ingress;
- `1639` — Telegram WebApp и TON через единый центр;
- `1640` — global_id business ownership closure.

Подробности: `WORK_CYCLES_1636-1640_ACCOUNT_REGISTRATION_CENTER.md`.

```text
CYCLE_1635_CORRECTIVE_IMPLEMENTED
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_NOT_STARTED
CYCLE_1640_NOT_STARTED
```

---

# Current roadmap gate — corrective v172.39

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI exact v172.38 прошёл весь Chromium и все остальные gates,
кроме одного archive filename hygiene test. v172.39 исправляет только
этот finding. Cycle `1631` может начаться лишь после полного exact-head
PASS v172.39. Cycle `1632` не начат.

---

# Current roadmap gate — corrective v172.38

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI exact v172.37 выявил шесть pytest findings и `51` admin
marker failures. v172.38 исправляет только эти findings. Cycle `1631`
может начаться лишь в следующем пакете после полного exact-head PASS
v172.38. Cycle `1632` не начат.

---

# Current roadmap gate — corrective v172.37

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI v172.36 не закрыл exit gate `1630`: общий Chromium audit дал
`51` admin marker failures. v172.37 исправляет только identity bootstrap
guard. Cycle `1631` может стать v172.38 только после полного fresh PASS
v172.37. Cycle `1632` не начат.

---

# Current roadmap gate — corrective v172.36

```text
CYCLE_1630_CROSS_PROVIDER_SESSION_CHROMIUM_PROOF_PASS
CYCLE_1630_ROUTE_BACKED_VISUAL_CI_FAILED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
```

Fresh CI v172.35 не закрыл полный exit gate `1630`. Corrective v172.36
устраняет CSP/status/admin-build и stale-contract findings. Цикл `1631`
не начат; его physical rename разрешён только после fresh full PASS.

---

# Текущий статус обязательного плана 1601–1633 — v172.35

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83240274364` на exact v172.34 не закрыл browser exit gate.
Corrective v172.35 исправляет static findings, deterministic Chromium
session proof и сохраняет новый универсальный canonical CI внутри
archive. Cycle `1631` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.34

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83236222987` на exact v172.33 не выявил production blocker,
но exit gate `1630` неполон: wrong integration DB input profile и
skipped Chromium evidence. Corrective v172.34 исправляет harness и
встраивает cross-provider proof в существующий protected visual audit.
Cycle `1631` не начат до двух fresh exact-head CI proofs.

---

# Текущий статус обязательного плана 1601–1633 — v172.32

```text
CYCLE_1628_EXTENDED_DOMAIN_OWNER_EXACT_HEAD_PASS
CYCLE_1628_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_PACKAGE_READY
CYCLE_1629_EXACT_HEAD_CI_REQUIRED
CYCLE_1630_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83181651259` на exact `v172.31` применил real PostgreSQL
`0012`; remaining failures локализованы в negative-test harness,
test cleanup и static/Mypy/Ruff contracts. Cycle `1629` реализован без
schema change: server-side session first для common/admin API,
provider-neutral `/sync/me`, измеряемый legacy Telegram compatibility и
frontend `GlobalId` cache identity. Alembic head остаётся `0012`.
Следующий цикл `1630` не начат до fresh exact-head CI v172.32.

---

# Текущий статус обязательного плана 1601–1633 — v172.31

```text
CYCLE_1627_FINANCIAL_READ_SWITCH_EXACT_HEAD_PASS
CYCLE_1627_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1628_PACKAGE_READY
CYCLE_1628_EXACT_HEAD_CI_REQUIRED
CYCLE_1629_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83164293703` на exact v172.30 квалифицировал `0011` financial
read switch; оставшиеся findings были только simple. Cycle `1628`
реализован в v172.31: remaining Shop/NFT/cosmetics/memo/notifications/
external-event ownership surfaces используют `global_id`; существующий
admin/external schema EXPAND повторно не создаётся. Alembic head `0012`.
Следующий цикл `1629` не начат до fresh exact-head CI v172.31.

---

# Текущий статус обязательного плана 1601–1633 — v172.30

```text
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_EXACT_HEAD_PASS
CYCLE_1627_FINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1627_EXACT_HEAD_CI_REQUIRED
CYCLE_1628_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83151379137` на exact `v172.29` квалифицировал financial
shadow validation. В `v172.30` реализован `0011` financial read switch
с rollback и повторным zero-telemetry/`0.00000000` gate. Следующий цикл
`1628` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.29

```text
CYCLE_1625_POSTGRESQL_0010_PASS
CYCLE_1626_CI_FINDINGS_CORRECTED_IN_V172_29
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_REQUALIFICATION_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83144620488` на exact `v172.28` подтвердил real PostgreSQL
`0010`, но не дал exit proof цикла `1626`: PostgreSQL integration fixture
упал до financial reconciliation gate. `v172.29` — corrective-only.
Следующий цикл `1627` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.28

```text
CYCLE_1625_POSTGRESQL_0010_PASS_CI_FINDINGS_CORRECTED
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_PACKAGE_READY
CYCLE_1626_EXACT_HEAD_CI_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83121417737` на exact `v172.27` подтвердил real PostgreSQL
`0010`. Cycle `1626` реализован как read-only financial shadow validation;
новая migration не создаётся. Следующий цикл: `1627`.
`CYCLE_1627_NOT_STARTED`.

---

# Текущий статус обязательного плана 1601–1633 — v172.27

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83098311619` на exact `v172.26` подтвердил real
PostgreSQL `0009`. Единственный pytest finding был документным и
исправлен. Cycle `1625` реализован в `v172.27`; cycle `1626` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.26

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83093436890` на exact `v172.25` выявил critical PostgreSQL
syntax defect telemetry view migration `0009`. Corrective `v172.26`
исправляет SQL composition и подтверждённые static findings. Цикл
`1625` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.25

```text
CYCLE_1623_POSTGRESQL_0008_PASS_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1624_DUAL_WRITE_SHADOW_TELEMETRY_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83067297122` на exact `v172.24` подтвердил real PostgreSQL
`0008`. Cycle `1624` реализован в `v172.25`; cycle `1625` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.24

```text
CYCLE_1623_CRITICAL_POSTGRESQL_BLOCKER_CONFIRMED
CYCLE_1623_CORRECTIVE_PACKAGE_READY
CYCLE_1623_EXACT_HEAD_CI_REQUIRED
CYCLE_1624_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83053365488` на exact `v172.23` выявил critical PostgreSQL
blocker migration `0008`: `LOCK TABLE` выполнялся вне real transaction.
Corrective `v172.24` разделяет AUTOCOMMIT schema bootstrap и Alembic
migration connection. Cycle `1624` не начат.

---

# EFHC Bot — ускоренный план Global ID и модульной авторизации 1601–1633

Статус: `ACTIVE_SSOT`.
Диапазон обязательных циклов: `1601–1633`.
Текущий scope: cycle `1625`, пакет `v172.27`.
Текущий статус:

```text
CYCLE_1624_CRITICAL_POSTGRESQL_0009_BLOCKER_CONFIRMED
CYCLE_1624_CORRECTIVE_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий цикл: `1626`, только после fresh exact-HEAD CI qualification
`v172.27`. Financial shadow validation пока не начата.

Фактическое имя файла сохранено как
`WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md`, чтобы не создавать
риск broken references в guards и Operator Kernel. Каноническое содержание и
обязательный диапазон расширены до `1633`.

## 1. Неподвижные правила

1. `global_id` — единственный account owner; provider IDs не являются owner.
2. До цикла `1631` физическая колонка остаётся `users.user_id`.
3. PostgreSQL data gates не объединяются с неподтверждённым read switch.
4. Financial switch отделён от non-financial switch и требует расхождения
   `0.00000000`.
5. Physical rename выполняется только после `fallback/mismatch = 0`.
6. Migration squash запрещён раньше завершения physical rename.
7. CI workflow не изменяется без прямой команды пользователя.
8. Полный regression, PostgreSQL и Chromium выполняются пользователем через
   существующий GitHub CI; локально разрешены только короткие причинные checks.

## 2. Правила ускорения

1. Code line и PostgreSQL data gates разделяются: подготовленный код не
   считается доказанным до реального PostgreSQL и exact-HEAD CI.
2. `PG-0` подтверждает migration и constraints, но не разрешает backfill,
   read switch или ownership switch.
3. Канон `global_id` закреплён с цикла `1602`: `global_id` является account
   owner, а `tg_id` остаётся только Telegram provider ID.
4. Исторические contract markers сохраняются для совместимости guards:

   - Текущий подготовленный цикл после этой редакции: `1611`
   - Статус gate: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED`
   - Следующий цикл после подтверждённого `PG-0 PASS`: `1612`

   Эти три строки являются историческими markers состояния до первого
   реального PostgreSQL run и не описывают текущий статус `v172.10`.
5. Историческая формулировка «Циклы `1633–1700` не являются обязательными»
   больше не является текущим каноном: цикл `1633` обязателен как финальная
   qualification, а циклы `1634–1700` не входят в обязательный диапазон.

### 2.1. Обязательные gates

| Gate | Цикл | Значение |
|---|---:|---|
| `FOUNDATION` | 1608 | Global ID code line, allowlist и compatibility registry закрыты |
| `PG-0` | 1611 | Real PostgreSQL evidence и fresh exact-HEAD static gates |
| `AUTH-CORE` | 1614 | identities/challenges/sessions/roles и resolver доказаны |
| `TON-AUTH` | 1618 | TON Proof login закрыт на PostgreSQL |
| `TELEGRAM-ADAPTER` | 1619 | Telegram проходит через `IdentityResolver` |
| `BACKFILL` | 1623 | Historical mapping и reconciliation = `0.00000000` |
| `DUAL-WRITE` | 1624 | mismatch/fallback telemetry активна |
| `NON-FINANCIAL` | 1625 | non-financial reads переведены |
| `FINANCIAL` | 1627 | financial shadow/read switch доказан |
| `RENAME` | 1631 | physical rename и cleanup доказаны на clone |
| `SQUASH` | 1632 | `PRE_RELEASE_MIGRATION_SQUASH_PASS` |
| `RELEASE` | 1633 | exact-HEAD qualification и production handoff |

## 3. Завершённый фундамент и текущий цикл

| Цикл | Состояние |
|---:|---|
| 1601–1607 | Foundation и cross-language разделение `GlobalId`/`TelegramId` завершены |
| 1608 | Semantic allowlist и compatibility registry завершены |
| 1609 | `AuthProvider`, `VerifiedIdentity` и provider registry завершены |
| 1610 | `AuthContext`, resolver interfaces и redaction skeleton завершены |
| 1611 | **ЗАВЕРШЁН:** exact-HEAD run `82850316409`; PostgreSQL/Alembic/static/pytest/frontend PASS |
| 1612 | **ФУНКЦИОНАЛЬНЫЙ ОБЪЁМ PASS:** resolver/PostgreSQL/static gates прошли; handoff marker исправлен в v172.12 |

Run `82865834601` подтвердил functional/static/PostgreSQL объём цикла `1612`,
но общий exact-HEAD gate упал на одном handoff marker. Исправление включено в
`v172.12`; цикл `1613` подготовлен и требует fresh exact-HEAD CI.




Run `82897904509` на exact HEAD `v172.13` подтвердил PostgreSQL/Alembic
`0004`, Ruff, Mypy, Bandit и frontend. Четыре architecture failures исправлены
в `v172.14`; они не выявили runtime, migration или financial defect.

Run `82909483300` на exact HEAD `v172.14` подтвердил PostgreSQL/Alembic
`0004`, Bandit и frontend. Три Ruff, одна Mypy и четыре architecture
failures исправлены в `v172.15`; они не выявили migration, financial или
PostgreSQL defect.


Run `82923200235` на exact HEAD `v172.15` подтвердил PostgreSQL/Alembic
`0004`, Bandit и frontend. Три Ruff, две Mypy и десять pytest failures
исправлены в `v172.16`. PostgreSQL failure цикла `1616` был вызван
тестовым vector, подписанным не выданным challenge token; runtime DDL и
финансовые контуры дефектов не показали.

Цикл `1617` добавляет migration `0005`, nullable `users.global_id`,
provider-neutral `wallet_bindings.global_id` и transactional flow:
existing identity → тот же `global_id`; verified legacy binding → тот же
account; новый wallet → `users + user_identities + wallet_bindings` одной
транзакцией. Fake `global_id`, auto-merge и session issue запрещены.

### 3.1. Исторические contract rows для guards

| Цикл | Исторический статус |
|---:|---|
| 1609 | `AuthProvider`, `VerifiedIdentity` и provider registry foundation |
| **1609** | **ЗАВЕРШЁН:** `AuthProvider`, `VerifiedIdentity`, provider registry |
| **1611** | Исторический correction package, закрыт run `82850316409` |

## 4. Текущий цикл и оставшиеся обязательные циклы

Цикл `1625` реализован и требует exact-HEAD qualification.
Цикл `1626` не начат.

| Цикл | Интегрированный объём | Exit gate |
|---:|---|---|
| **1612** | **FUNCTIONAL PASS / HANDOFF FIX INCLUDED** — transactional resolver, locks, conflict fail closed | Fresh overall proof объединяется с v172.12 CI |
| **1613** | **REAL PG/ALEMBIC EXECUTED; CORRECTIONS INCLUDED** — `auth_challenges`, `auth_sessions`, `user_roles`, services и FastAPI dependencies | Fresh overall proof объединяется с v172.13 CI |
| **1614** | **POSTGRESQL/STATIC/FRONTEND PASS; 4 DOC CORRECTIONS INCLUDED** — auth-core integration closure | Fresh overall proof объединяется с `v172.14` CI |
| **1615** | **RUNTIME/PG/STATIC/FRONTEND PASS; 8 CI CORRECTIONS INCLUDED** — TON challenge и canonical address | Fresh overall proof объединяется с `v172.15` CI |
| **1616** | **CI ERRORS FIXED IN v172.16** — TON Proof: domain, timestamp, network, state-init, replay, TTL | Fresh exact-HEAD proof объединяется с `v172.16` CI |
| **1617** | **CI ERRORS FIXED IN v172.17** — existing TON identity/binding, TON-only registration и concurrency | PostgreSQL/Alembic proof получен на v172.16; общий gate исправлен |
| **1618** | **EXACT-HEAD CI ERRORS FIXED IN v172.18** — TON auth/session/logout closure и frontend session transport | TON-only login получает hashed session; frontend contract изолирован |
| **1619** | **ЗАВЕРШЁННЫЙ FUNCTIONAL SCOPE** — Telegram initData adapter через `IdentityResolver` и session issue | Telegram provider не owner; повторный вход открывает тот же account |
| **1620** | **SIMPLE CI FINDINGS CORRECTED** — frontend session-first bootstrap, hooks/query keys и provider context skeleton | Новый scope использует session/global_id semantics |
| **1621** | Non-financial EXPAND: panels, energy, referrals, tasks, ranks | `0006`: nullable FK/columns/indexes; fresh CI подтвердил PostgreSQL upgrade, simple findings исправлены |
| **1622** | **POSTGRESQL 0007 PASS / SIMPLE FINDINGS CORRECTED** — financial/admin/external EXPAND | `0007` реально применён fresh CI; ownership switch отсутствует |
| **1623** | **POSTGRESQL 0008 PASS / SIMPLE FINDINGS CORRECTED** — historical backfill/reconciliation | Real PostgreSQL `0008`; integration contract требует `0.00000000` и unresolved rows = 0 |
| **1624** | **POSTGRESQL PASS** — dual-write, shadow telemetry и rollback guards | Real PostgreSQL `0009` подтверждён fresh CI |
| **1625** | **PACKAGE READY** — Non-financial read switch | `0010`; rollback и real PostgreSQL требуют fresh CI |
| **1626** | Financial shadow validation | mismatch/fallback = 0; precision/idempotency unchanged |
| **1627** | Financial read switch и reconciliation closure | Расхождение `0.00000000`; Telegram отсутствует в owner API |
| **1628** | Shop/NFT/cosmetics/memo/admin/notifications/external events migration | Остальные modules используют `global_id`; channel identity отделена |
| **1629** | Общие/admin API, frontend session-first full switch, OpenAPI parity | Telegram и TON sessions видят один account; legacy routes измеряются |
| **1630** | Cross-provider PostgreSQL/API/build/Chromium E2E и закрытие fallback | 0 critical skips; real browser и PostgreSQL evidence exact HEAD |
| **1631** | Physical rename `users.user_id → users.global_id`, FK/index/sequence rename, aliases cleanup, clone upgrade/rollback/restore | fallback/mismatch = 0; cleanup доказан; aliases удалены по registry |
| **1632** | Schema freeze и pre-release migration squash в единый `0001_initial_release_schema.py` | `PRE_RELEASE_MIGRATION_SQUASH_PASS` |
| **1633** | Exact-HEAD CI, release qualification, deployment/rollback/restore/live handoff | `PRODUCTION_RELEASE_READY` только после полного real live proof |

## 5. Самостоятельный migration squash cycle 1632

Цикл `1632` выполняется только после завершения физической схемы цикла `1631`.
Обязательный объём:

1. Зафиксировать окончательную схему первого production release.
2. Доказать отсутствие production-базы, которой нужна старая migration history.
3. Объединить все pre-release migrations в
   `0001_initial_release_schema.py`.
4. Удалить промежуточные pre-release migrations из активной release history.
5. Обновить migration tests, schema invariants, SSOT/NORM и machine contracts.
6. Выполнить clean PostgreSQL qualification через существующий GitHub CI.
7. Доказать отсутствие schema drift и совпадение ORM/migrations/PostgreSQL.

Exit gate:

```text
PRE_RELEASE_MIGRATION_SQUASH_PASS
```

После первого production release `0001_initial_release_schema.py` становится
immutable; последующие изменения выполняются только migrations `0002+`.

## 6. Финальная qualification cycle 1633

`PRODUCTION_RELEASE_READY` разрешён только после fresh exact-HEAD CI,
PostgreSQL qualification, frontend build/typecheck, Chromium E2E,
deployment/rollback/restore, live Telegram, live TON Proof, нулевого
mismatch/fallback и денежного расхождения `0.00000000`.

## 7. Запреты до закрытия 1621

- не начинать cycle `1622` до fresh exact-HEAD CI `v172.21`;
- не выполнять auto-merge при conflict;
- не создавать migration `0007` до доказанной необходимости цикла `1622`;
- не менять DDL `0003`/`0004`/`0005` без доказанного дефекта;
- не выполнять backfill/read switch/ownership switch;
- не менять CI workflow;
- не добавлять tests или `requirements-test.txt` в release archive;
- не объявлять `CYCLE_1621_PASS` до fresh exact-HEAD CI `v172.21`.

---

## Источник: `WORK_CYCLES_1601-1700_ACTUAL_REGISTRY.md`

# Реестр циклов 1601–1700

Реестр построен по фактически присутствующим файлам. Отсутствие отдельного отчёта не объявляется завершением цикла.

| Цикл | Статус | Доказательства |
|---:|---|---|
| 1601 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1601_guard_inventory_v171_98.json`<br>`reports/generated/cycle_1601_changed_files_v171_98.json`<br>`reports/generated/cycle_1601_postgresql_integration_inventory_v171_98.json` |
| 1602 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1602_pytest_summary_v171_99.json`<br>`reports/generated/cycle_1602_changed_files_v171_99.json`<br>`reports/generated/cycle_1602_postgresql_integration_inventory_v171_99.json` |
| 1603 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1603_pytest_summary_v172_00.json`<br>`reports/generated/cycle_1603_changed_files_v172_00.json`<br>`reports/generated/postgresql_environment_preflight_cycle_1603_v172_00.json` |
| 1604 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1604_final_summary_v172_01.json`<br>`reports/generated/cycle_1604_development_release_mirror_v172_01.json`<br>`reports/generated/cycle_1604_release_archive_verification_v172_01.json` |
| 1605 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1605_pytest_summary_v172_02.json`<br>`reports/generated/cycle_1605_final_summary_v172_02.json`<br>`reports/generated/postgresql_reconciliation_cycle_1605_v172_02.sql` |
| 1606 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1606_development_release_mirror_v172_03.json`<br>`reports/generated/cycle_1606_release_archive_verification_v172_03.json`<br>`reports/generated/postgresql_reconciliation_cycle_1606_v172_03.sql` |
| 1607 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1607_development_release_mirror_v172_04.json`<br>`reports/generated/postgresql_reconciliation_cycle_1607_v172_04.json`<br>`reports/generated/cycle_1607_final_summary_v172_04.json` |
| 1608 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1608_changed_files_v172_05.json`<br>`reports/generated/cycle_1608_pytest_summary_v172_05.json`<br>`reports/generated/cycle_1608_final_summary_v172_05.json` |
| 1609 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1609_summary_v172_06.json`<br>`reports/generated/cycle_1609_protected_hashes_v172_06.json`<br>`reports/generated/cycle_1609_pytest_summary_v172_06.json` |
| 1610 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1610_pytest_summary_v172_07.json`<br>`reports/generated/kernel_route_cycle1610_v172_07.json`<br>`reports/generated/cycle_1610_protected_hashes_v172_07.json` |
| 1611 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1611_exact_head_ci_closure_v172_10.json`<br>`reports/generated/cycle_1611_ci_findings_v172_09.json`<br>`reports/generated/cycle_1611_static_fix_causal_verification_v172_10.json` |
| 1612 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1612_ci_findings_run_82865834601_v172_12.json`<br>`reports/generated/cycle_1612_release_archive_verification_v172_11.json`<br>`reports/generated/kernel_route_cycle1612_v172_11.json` |
| 1613 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1613_check_registry_v172_12.json`<br>`reports/generated/cycle_1613_protected_hashes_v172_12.json`<br>`reports/generated/cycle_1613_release_archive_verification_v172_12.json` |
| 1614 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1614_protected_hashes_v172_13.json`<br>`reports/generated/cycle_1614_ci_findings_v172_13.json`<br>`reports/generated/cycle_1614_development_retention_v172_13.json` |
| 1615 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1615_local_checks_v172_14.json`<br>`reports/generated/cycle_1615_check_registry_v172_14.json`<br>`reports/generated/cycle_1615_changed_files_v172_14.json` |
| 1616 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1616_changed_files_v172_15.json`<br>`reports/generated/cycle_1616_summary_v172_15.json`<br>`reports/generated/cycle_1616_ci_findings_v172_15.json` |
| 1617 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1617_check_registry_v172_16.json`<br>`reports/generated/cycle_1617_operator_kernel_route_v172_16.json`<br>`reports/generated/cycle_1617_release_builder_receipt_v172_16.json` |
| 1618 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1618_protected_hashes_v172_17.json`<br>`reports/generated/cycle_1618_summary_v172_17.json`<br>`reports/generated/cycle_1618_ci_log_receipt_v172_17.json` |
| 1619 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1619_local_checks_v172_19.json`<br>`reports/generated/cycle_1619_release_builder_receipt_v172_18.json`<br>`reports/generated/cycle_1619_fresh_ci_findings_v172_19.json` |
| 1620 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1620_protected_hashes_v172_20.json`<br>`reports/generated/cycle_1620_input_ci_findings_v172_19.json`<br>`reports/generated/cycle_1620_changed_files_v172_20.json` |
| 1621 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1621_protected_hashes_v172_21.json`<br>`reports/generated/cycle_1621_check_registry_v172_21.json`<br>`docs/audits/EFHC_v172_21_CYCLE_1621_NONFINANCIAL_EXPAND_REPORT.md` |
| 1622 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1622_summary_v172_22.json`<br>`reports/generated/cycle_1622_fresh_ci_findings_v172_22.json`<br>`docs/audits/EFHC_v172_22_CYCLE_1622_FINANCIAL_ADMIN_EXTERNAL_EXPAND_REPORT.md` |
| 1623 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1623_corrective_summary_v172_24.json`<br>`reports/generated/cycle_1623_summary_v172_23.json`<br>`reports/generated/cycle_1623_corrective_fresh_ci_v172_24.json` |
| 1624 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1624_check_registry_v172_25.json`<br>`reports/generated/cycle_1624_fresh_ci_findings_v172_25.json`<br>`reports/generated/cycle_1624_check_registry_v172_26.json` |
| 1625 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1625_summary_v172_27.json`<br>`reports/generated/cycle_1625_fresh_ci_findings_v172_27.json`<br>`docs/audits/EFHC_v172_27_CYCLE_1625_NONFINANCIAL_READ_SWITCH_REPORT.md` |
| 1626 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1626_summary_v172_29.json`<br>`reports/generated/cycle_1626_fresh_ci_findings_v172_29.json`<br>`reports/generated/cycle_1626_summary_v172_28.json` |
| 1627 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1627_fresh_ci_findings_v172_30.json`<br>`reports/generated/cycle_1627_summary_v172_30.json`<br>`docs/audits/EFHC_v172_30_CYCLE_1627_FINANCIAL_READ_SWITCH_REPORT.md` |
| 1628 | ДОКУМЕНТИРОВАН | `reports/cycle_1628_extended_domain_owner_migration_v172_31.md`<br>`reports/generated/cycle_1628_fresh_ci_findings_v172_31.json`<br>`reports/generated/cycle_1628_summary_v172_31.json` |
| 1629 | ДОКУМЕНТИРОВАН | `reports/cycle_1629_session_first_full_switch_v172_32.md`<br>`reports/generated/cycle_1629_summary_v172_32.json` |
| 1630 | ДОКУМЕНТИРОВАН | `reports/cycle_1630_cross_provider_e2e_fallback_closure_v172_33.md`<br>`reports/cycle_1630_corrective_route_chromium_v172_36.md`<br>`reports/cycle_1630_current_marker_ruff_corrective_v172_40.md` |
| 1631 | ДОКУМЕНТИРОВАН | `reports/cycle_1631_physical_global_id_rename_v172_41.md`<br>`reports/generated/cycle_1631_pre_rename_inventory_v172_41.json`<br>`reports/generated/cycle_1631_post_rename_inventory_v172_41.json` |
| 1632 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1632_pre_release_migration_squash_v172_42.json`<br>`reports/generated/cycle_1632_1633_status_v172_45.json`<br>`reports/generated/cycle_1632_1633_status_v172_44.json` |
| 1633 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-02_v172_46_cycle_1633_release_tail_cleanup.md`<br>`reports/generated/cycle_1632_1633_status_v172_45.json`<br>`reports/generated/cycle_1632_1633_status_v172_44.json` |
| 1634 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1634_chat_qa_public_ui_v172_48.json`<br>`docs/audits/CHAT_40_51_QA_PUBLIC_UI_AUDIT_CYCLE_1634.md`<br>`docs/cycles/WORK_CYCLE_1634_CHAT_QA_PUBLIC_UI_AUDIT.md` |
| 1635 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-02_v172_50_cycle_1635_corrective.md`<br>`reports/change_cycle_2026-08-02_v172_51_cycles_1635_1636.md`<br>`reports/generated/cycle_1635_corrective_v172_50.json` |
| 1636 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-03_v172_52_cycles_1636_1637.md`<br>`reports/change_cycle_2026-08-02_v172_51_cycles_1635_1636.md`<br>`reports/generated/cycles_1636_1637_v172_52.json` |
| 1637 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-03_v172_52_cycles_1636_1637.md`<br>`reports/generated/cycles_1636_1637_v172_52.json` |
| 1638 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1639 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-03_v172_56_cycle_1639_postgresql_fixture_corrective.md` |
| 1640 | ДОКУМЕНТИРОВАН | `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/audits/CYCLE_1640_GLOBAL_ID_IDEMPOTENCY_AUDIT.md`<br>`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_1640-1650_GLOBAL_ID_FULL_CUTOVER.md`<br>`docs/cycles/WORK_CYCLES_1636-1640_ACCOUNT_REGISTRATION_CENTER.md` |
| 1641 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-04_v172_64_cycles_1641_1646_ci_and_alias_cleanup.md`<br>`reports/change_cycle_2026-08-04_v172_60_cycles_1641_1643_ci_and_referral_cutover.md`<br>`reports/change_cycle_2026-08-04_v172_59_cycles_1641_1642_global_owner.md` |
| 1642 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-04_v172_59_cycles_1641_1642_global_owner.md` |
| 1643 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-04_v172_60_cycles_1641_1643_ci_and_referral_cutover.md`<br>`reports/change_cycle_2026-08-04_v172_61_cycles_1643_1644_ci_tasks_ranks_wallets.md` |
| 1644 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-04_v172_61_cycles_1643_1644_ci_tasks_ranks_wallets.md`<br>`reports/change_cycle_2026-08-04_v172_62_cycles_1644_1645_ci_callers_cutover.md` |
| 1645 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-04_v172_63_cycles_1641_1645_ci_correction.md`<br>`reports/change_cycle_2026-08-04_v172_62_cycles_1644_1645_ci_callers_cutover.md` |
| 1646 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-04_v172_64_cycles_1641_1646_ci_and_alias_cleanup.md` |
| 1647 | ДОКУМЕНТИРОВАН | `docs/cycles/WORK_CYCLE_1647_GLOBAL_OWNER_BIG_BANG_REWRITE.md` |
| 1648 | ДОКУМЕНТИРОВАН | `reports/generated/cycle_1648_tg_id_wave_2_v172_70.md` |
| 1649 | ДОКУМЕНТИРОВАН | `reports/generated/tg_id_wave_1649_report.md` |
| 1650 | ДОКУМЕНТИРОВАН | `reports/generated/tg_id_wave_1650_report.md`<br>`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_1640-1650_GLOBAL_ID_FULL_CUTOVER.md` |
| 1651 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_73_cycle_1651_tg_id_wave_5.md` |
| 1652 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_74_cycle_1652_tg_id_wave_6.md` |
| 1653 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_75_cycle_1653_tg_id_wave_7.md`<br>`reports/generated/tg_id_wave_1653_manifest_detailed.json` |
| 1654 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_76_cycle_1654_tg_id_wave_8.md`<br>`reports/generated/tg_id_wave_1654_manifest_detailed.json` |
| 1655 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_77_cycles_1655_1656_tg_id_wave_9.md`<br>`reports/generated/tg_id_wave_1655_1656_manifest_detailed.json` |
| 1656 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_77_cycles_1655_1656_tg_id_wave_9.md`<br>`reports/generated/tg_id_wave_1655_1656_manifest_detailed.json` |
| 1657 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_78_cycle_1657_tg_id_wave_10.md`<br>`reports/generated/tg_id_wave_1657_manifest_detailed.json` |
| 1658 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_79_cycles_1658_1659_tg_id_waves_11_12.md`<br>`reports/generated/tg_id_wave_1658_1659_manifest_detailed.json` |
| 1659 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_79_cycles_1658_1659_tg_id_waves_11_12.md`<br>`reports/generated/tg_id_wave_1658_1659_manifest_detailed.json` |
| 1660 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1661 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1662 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_81_cycles_1662_1663_tg_id_wave.md` |
| 1663 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_81_cycles_1662_1663_tg_id_wave.md` |
| 1664 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_82_cycles_1664_1665_tg_id_wave.md`<br>`reports/generated/tg_id_wave_1664_1665_manifest_detailed.json` |
| 1665 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_82_cycles_1664_1665_tg_id_wave.md`<br>`reports/generated/tg_id_wave_1664_1665_manifest_detailed.json`<br>`docs/cycles/WORK_CYCLES_1640_1665_APPROVED_PLAN.md` |
| 1666 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_83_cycles_1666_1667_tg_id_waves.md`<br>`reports/generated/tg_id_wave_1666_1667_manifest_detailed.json` |
| 1667 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_83_cycles_1666_1667_tg_id_waves.md`<br>`reports/generated/tg_id_wave_1666_1667_manifest_detailed.json` |
| 1668 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_84_cycles_1668_1669_tg_id_waves.md`<br>`reports/generated/tg_id_wave_1668_1669_manifest_detailed.json` |
| 1669 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_84_cycles_1668_1669_tg_id_waves.md`<br>`reports/generated/tg_id_wave_1668_1669_manifest_detailed.json` |
| 1670 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_85_cycle_1670_global_id_tail_audit.md` |
| 1671 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1672 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_88_cycle_1672.md` |
| 1673 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_89_cycle_1673.md` |
| 1674 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1675 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_92_cycle_1675_provider_naming_runtime.md` |
| 1676 | ДОКУМЕНТИРОВАН | `reports/change_cycle_2026-08-05_v172_93_cycle_1676.md`<br>`reports/generated/cycle_1676_ast_duplicate_scan.json` |
| 1677 | ТЕКУЩИЙ | — |
| 1678 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1679 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1680 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1681 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1682 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1683 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1684 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1685 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1686 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1687 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1688 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1689 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1690 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1691 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1692 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1693 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1694 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1695 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1696 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1697 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1698 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1699 | ОТДЕЛЬНЫЙ ОТЧЁТ НЕ НАЙДЕН | — |
| 1700 | ДОКУМЕНТИРОВАН | `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md`<br>`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_1601-1700_GLOBAL_ID_MODULAR_AUTH_PLAN.md`<br>`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/EFHC_WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md` |

---

## Источник: `WORK_CYCLES_1601-1700_GLOBAL_ID_MODULAR_AUTH_PLAN.md`

# Исторический план циклов 1601–1700

Статус: `SUPERSEDED_AFTER_CYCLE_1607`.

Этот план был safety-maximal и резервировал отдельный цикл почти для
каждой таблицы, функции и gate. Он сохранён полностью как исторический
снимок:

`docs/history/identity/WORK_CYCLES_1601-1700_GLOBAL_ID_MODULAR_AUTH_PLAN_PRE_ACCELERATION_v172_03.md`

Текущий обязательный roadmap:

`docs/cycles/WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md`

После цикла 1607 остаётся 25 обязательных циклов `1608–1632`.
Циклы `1633–1700` являются только условным резервом и не выполняются
без отдельной фактической причины.

---

## Источник: `WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# LEGACY PATH — roadmap user_id

Статус: `SUPERSEDED / COMPATIBILITY POINTER`.

Активный roadmap:

`docs/cycles/WORK_CYCLES_1601-1700_GLOBAL_ID_MODULAR_AUTH_PLAN.md`

Предыдущая версия сохранена:

`docs/history/identity/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN_PRE_GLOBAL_ID_v171_98.md`

Физическое имя `users.user_id` сохраняется до controlled rename, но
главный идентификатор единого аккаунта называется `global_id`.

---

## Источник: `WORK_CYCLES_1636-1640_ACCOUNT_REGISTRATION_CENTER.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Циклы 1636–1640 — регистрация и global_id ownership

## Общая цель

Создать один центр регистрации аккаунта для Telegram Bot, Telegram
WebApp, browser/PWA и TON. После этого завершить фактический переход
бизнес-логики на `global_id`.

Основание:

- `docs/NORM/TZ/TZ_account_registration_service.md`;
- `docs/NORM/TZ/TZ_global_id_migration.md`;
- фактический Current HEAD `v172.56`;
- канон первичной неизменяемой реферальной принадлежности.

## Канонические решения

1. Строка `efhc_core.users` для нового аккаунта создаётся только через
   `AccountRegistrationService`.
2. `PostgreSQLIdentityResolver` не переписывается: он продолжает
   определять, существует ли аккаунт или provider identity.
3. Реферальная принадлежность создаётся только в транзакции первого
   создания аккаунта.
4. Неверный или несуществующий реферальный код блокирует создание
   аккаунта. Это сохраняет действующий fail-closed канон.
5. Существующий пользователь никогда не может получить или сменить
   inviter.
6. `tg_id` сохраняется как provider-атрибут и канал уведомлений, но не
   является владельцем бизнес-данных.
7. После цикла 1640 операции пользователя должны работать по
   `global_id` без обязательного Telegram-аккаунта.


## Текущий implementation status v172.56

Циклы `1636–1638` квалифицированы. Цикл `1639` реализован во всех provider
callers. Fresh CI exact `v172.55` подтвердил `3219 passed`, но один
cross-provider qualification fixture нарушал ожидаемый порядок SQLAlchemy
flush: INSERT `ReferralCode` мог уйти до UPDATE нового `users.global_id`.

Corrective `v172.56`:

- не меняет production registration code;
- явно flush-ит UPDATE provider attribute в test fixture;
- сохраняет FK `referral_codes_inviter_global_id_fkey`;
- сохраняет canonical referral ownership через `global_id`;
- не начинает business ownership цикл `1640`.

Текущий gate:

```text
ALL_REGISTRATION_PATHS_USE_SINGLE_CENTER
PROVIDER_NEUTRAL_FIRST_REGISTRATION_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
CYCLE_1640_NOT_STARTED
```

## Цикл 1636 — ядро единой регистрации

Создать `backend/app/identity/account_registration.py`.

В цикл входят:

- `NewAccountRequest`;
- `NewAccountResult`;
- `AccountRegistrationError`;
- транзакционное создание `users`;
- единая нормализация referral start param;
- создание `referral_links` в той же транзакции;
- защита от второго владельца, self-ref и поздней привязки;
- модульные и PostgreSQL-контракты ядра.

Вызовы существующих трёх путей пока не переключаются.

## Цикл 1637 — Telegram Bot через общий центр

Перевести `onboard_user_at_first_creation()` на
`AccountRegistrationService`.

Дополнительно:

- бот-регистрация сразу создаёт `UserIdentity`;
- сохраняется поведение `0 user`;
- invalid code не создаёт пользователя;
- старые referral runtime tests должны пройти без изменения смысла;
- прямой `INSERT INTO efhc_core.users` удаляется из bot onboarding.

## Цикл 1638 — единый referral ingress

Добавить provider-независимую передачу referral start param:

- Telegram WebApp auth API;
- TON auth API;
- browser/PWA first-entry capture;
- хранение до логина только в `sessionStorage`;
- одноразовое потребление после успешной регистрации;
- отсутствие позднего bind для уже существующего аккаунта.

В этом цикле новые provider-пути ещё не создают пользователя через общий
сервис: подготавливается безопасный transport contract.

## Цикл 1639 — Telegram WebApp и TON через общий центр

Перевести:

- `TelegramAuthSessionService`;
- `TonAccountRegistrationService`;

на `AccountRegistrationService`.

Exit gate:

- три прежних независимых пути создания `users` устранены;
- direct creation вне общего сервиса запрещён guard;
- `existing_legacy_account` не создаёт дубликат;
- bot/WebApp/TON дают одинаковую referral row;
- межпровайдерный referral cycle невозможен;
- один provider failure не оставляет частично созданный аккаунт.

## Цикл 1640 — закрытие global_id бизнес-владения

Внутри одного интегрированного цикла выполнить этапы по зависимостям:

1. общий `OwnerKey`/owner resolver;
2. `transactions_service.py`;
3. panels, withdrawals и payment intents;
4. referrals;
5. tasks, ranks и wallets;
6. achievements и оставшиеся таблицы;
7. routes и bot handlers.

Обязательные результаты:

- бизнес-операции принимают `global_id`;
- idempotency строится на одном canonical owner;
- вызов по `global_id` и `global_id` одного аккаунта не создаёт два следа;
- `achievements` получает `global_id` в единой migration `0001`;
- `tg_id` становится nullable provider-атрибутом там, где Telegram не
  обязателен;
- browser/APK/TON пользователь может пользоваться панелями, обменом,
  выводом, заданиями, рангами и кошельками без Telegram;
- старые compatibility-входы удаляются после перевода вызывающих мест.

## Состояние после цикла 1640

Плановый результат:

```text
ONE_ACCOUNT_REGISTRATION_CENTER
GLOBAL_ID_BUSINESS_OWNER
TELEGRAM_OPTIONAL_PROVIDER
NO_LATE_REFERRAL_BIND
CROSS_PROVIDER_REGISTRATION_EQUIVALENCE
```

Циклы 1636–1639 реализованы; цикл 1640 не начат.

---

## Источник: `WORK_CYCLES_1640-1650_GLOBAL_ID_FULL_CUTOVER.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Циклы 1640–1650 — полный cutover бизнес-владения на global_id

Статус: `ACTIVE_PLAN`  
База: `v172.56`, основной exact-head CI PASS.  
Директива пользователя: visual screenshots не блокируют дальнейшую
разработку; visual evidence остаётся отдельной незакрытой задачей и не
подменяет backend/PostgreSQL qualification.

Источник требований:
`docs/NORM/TZ/TZ_global_id_full_cutover.md`.

## Неподвижный результат программы

- `global_id` — единственный business owner и idempotency owner.
- `tg_id` сохраняется только как Telegram provider attribute.
- TON/browser/APK account может выполнять бизнес-операции без Telegram.
- Один релиз готовится заранее; production cutover выполняется одной
  контролируемой транзакцией.
- После cutover удаляются legacy aliases и compatibility tails.

## Цикл 1640 — write-side foundation и idempotency audit

Scope:

1. Добавить `identity/financial_write_switch.py`.
2. Разрешать ровно один selector: `global_id` или `global_id`.
3. Всегда возвращать canonical `global_id`.
4. Блокировать `users` через `FOR UPDATE`.
5. Требовать `dual_write_enabled`.
6. Разрешить TON-only owner (`legacy_global_id=None`).
7. Провести построчный audit idempotency-key construction.
8. Зафиксировать список identifier-coupled keys до изменения ledger path.

Exit:

- write-side resolver покрыт unit/architecture tests;
- read/write используют один singleton control loader;
- idempotency risk register создан;
- application services ещё не переключены массово.

## Цикл 1641 — transactions/ledger canonical owner

Scope:

- перевести core helpers и публичные money functions на owner selector;
- balances lock/update выполнять по `global_id`;
- `efhc_transfers_log.global_id` сделать обязательным canonical owner для
  user-side записей;
- `tg_id` заполнять только при наличии provider attribute;
- нормализовать identifier-coupled idempotency keys с совместимым
  read-through старых ключей;
- доказать одинаковый результат вызова по `global_id` и `global_id`.

## Цикл 1642 — panels, withdrawals, payment intents

Scope:

- panels service;
- withdraw service;
- payment intents service;
- соответствующие routes;
- убрать `owner.require_legacy_global_id()` из этих business paths;
- сохранить финансовые инварианты, rollback и Decimal(30,8).

## Цикл 1643 — referrals, tasks, ranks, wallets

Scope:

- referral ownership/count/reward paths;
- task completion/ad reward/listing;
- ranks user/top reads;
- wallets ownership and bank credit bridge;
- заменить referral idempotency keys, зависящие от `global_id`.

## Цикл 1644 — callers и achievements

Scope:

- все оставшиеся routes;
- Telegram bot handlers;
- admin services/routes;
- scheduler jobs;
- `achievements.global_id` в ORM и canonical `0001`;
- provider-only использование `global_id` отделить от business ownership.

## Цикл 1645 — one-release cutover и rollback

Scope:

- изменить canonical `0001`, чтобы `legacy_authoritative` мог стать FALSE;
- реализовать транзакционный cutover в требуемом порядке;
- реализовать транзакционный rollback;
- подключить и проверять `*_rollback_ready`;
- при необходимости расширить owner consistency triggers;
- добавить pre-cutover readiness gate.

Exit:

- вся business logic заранее работает через `global_id`;
- cutover и rollback выполняются одним действием;
- production switch ещё не считается выполненным без exact qualification.

## Цикл 1646 — удаление legacy aliases

Удалить после завершения 1640–1645:

- service aliases `*_by_tg_id`, если они больше не provider adapters;
- `require_legacy_global_id()` из business routes;
- reverse owner alias `User.user_id`;
- runtime owner aliases `legacy_pk`/`legacy_runtime_id`, если полный audit не
  выявит допустимого system-only использования;
- устаревшие owner DTO/parameters и дублирующие SQL entrypoints.

`tg_id` как Telegram provider attribute не удаляется.

## Цикл 1647 — удаление compatibility tails и защита от возврата

Scope:

- удалить legacy business SQL (`WHERE global_id` в owner operations);
- очистить temporary AI memory и устаревшие current-state docs;
- перенести history/evidence в history;
- добавить static guards, запрещающие возврат global_id ownership;
- проверить отсутствие двусмысленных aliases в OpenAPI, frontend и bot.

## Цикл 1648 — focused qualification

- selector equivalence по каждой мигрированной функции;
- TON-only account без `global_id`;
- idempotency equivalence;
- concurrency/row locking;
- rollback/fail-closed;
- неизменённый `test_referral_runtime.py`.

## Цикл 1649 — full exact-head qualification

- PostgreSQL 16;
- canonical Alembic `0001`;
- полный pytest;
- Flake8/Ruff/Mypy/Bandit/compileall;
- frontend production build;
- migration/control telemetry;
- monetary discrepancy `0.00000000`.

## Цикл 1650 — финальный audit и release package

- полный поиск legacy aliases/tails;
- schema/ORM/routes/services/bot/admin/scheduler consistency;
- archive CRC/SHA and release purity;
- MATRIX_TECHNICAL evidence;
- final status и production cutover runbook.

## Текущий статус

```text
CYCLE_1639_MAIN_CI_PASS
CYCLE_1639_VISUAL_EVIDENCE_DEFERRED_BY_USER
CYCLE_1640_IN_PROGRESS
CYCLE_1641_NOT_STARTED
CYCLE_1642_NOT_STARTED
CYCLE_1643_NOT_STARTED
CYCLE_1644_NOT_STARTED
CYCLE_1645_NOT_STARTED
CYCLE_1646_NOT_STARTED
CYCLE_1647_NOT_STARTED
CYCLE_1648_NOT_STARTED
CYCLE_1649_NOT_STARTED
CYCLE_1650_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

## Источник: `WORK_CYCLES_1640_1665_APPROVED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Утверждённый план EFHC — циклы 1640–1665

## Статус

Полностью утверждено пользователем 2026-08-04. Этот документ является
операционным планом. Последующие изменения порядка требуют прямой команды
пользователя.

## Процессный канон

- Один цикл — один основной контур.
- Не смешивать identity, visual, Admin UX и CI repair.
- Работать через Kernel Delta Protocol: current Kernel → evidence → первый
  causal defect → минимальный patch → targeted gate → exact-head gate.
- Каждый цикл закрывается отчётом:
  `результат → причина → исправление → влияние → проверки → открытые хвосты
  → следующий шаг → три архива`.
- В пользовательской Admin запрещён технический release/CI/evidence мусор;
  подробности хранятся в MATRIX_TECHNICAL.

## 1640–1650 — полный global_id cutover

### 1640 — write-side foundation qualification

- locked financial write owner resolver;
- один selector: `global_id` либо `global_id`;
- canonical `global_id` result;
- TON-only owner;
- idempotency audit;
- exact-head PostgreSQL/main CI qualification.

### 1641 — transactions/ledger canonical owner

- все credit/debit functions;
- `_ensure_user_locked`;
- ledger ownership по `global_id`;
- selector equivalence;
- TON-only financial path;
- compatibility read-through idempotency;
- защита от двойного начисления.

### 1642 — Panels, Withdrawals, Payment Intents

- сервисы и связанные owner queries;
- отсутствие обязательного `require_legacy_global_id()`;
- concurrency и equivalence tests.

### 1643 — Referral и idempotency normalization

- `REF_ACT_UNIT`;
- `REF_LVL`;
- exchange request key;
- новые keys по `global_id`;
- старые keys читаются;
- исторические ledger records не переименовываются.

### 1644 — Tasks, Ranks, Wallets

- task completion/ad reward/listing;
- rank/leaderboard;
- wallet credit/list/active-wallet;
- provider-neutral snapshot не менять без необходимости.

### 1645 — callers, achievements, cutover preparation

- routes, bot handlers, admin routes, scheduler;
- achievements `global_id`;
- API contracts;
- отдельная migration для изменяемого `legacy_authoritative`;
- production cutover не выполнять без прямой команды.

### 1646 — удаление runtime legacy aliases

- `*_by_global_id` owner aliases;
- `require_legacy_global_id()` из бизнес-path;
- fallback service signatures;
- canonical owner нельзя преобразовывать обратно в provider ID.

## 1647–1671 — 25 партий полного identity cutover

### 1647 — партия 1/25: Transactions и ledger — публичные signatures/callers

- целевой объём: 250 семантически связанных замен;
- контур: credit/debit, locked owner, ledger DTO и tests;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1648 — партия 2/25: Transactions — SQL/ORM compatibility

- целевой объём: 250 семантически связанных замен;
- контур: physical read-through, bind aliases, idempotency history;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1649 — партия 3/25: Panels

- целевой объём: 250 семантически связанных замен;
- контур: activation, ownership, scheduler, admin callers;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1650 — партия 4/25: Withdrawals

- целевой объём: 250 семантически связанных замен;
- контур: hold/refund, bank mirror, admin operations;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1651 — партия 5/25: Payment Intents

- целевой объём: 250 семантически связанных замен;
- контур: create/status/confirm, historical keys and payload parser;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1652 — партия 6/25: Referrals core

- целевой объём: 250 семантически связанных замен;
- контур: registration, links, rewards, self-referral guards;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1653 — партия 7/25: Referral routes and tests

- целевой объём: 250 семантически связанных замен;
- контур: API/frontend contracts, fixtures, integration paths;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1654 — партия 8/25: Tasks

- целевой объём: 250 семантически связанных замен;
- контур: catalog, completion, ad rewards, logs, handlers;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1655 — партия 9/25: Ranks and leaderboard

- целевой объём: 250 семантически связанных замен;
- контур: rank ownership, snapshots, routes and tests;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1656 — партия 10/25: Wallets and TON ownership

- целевой объём: 250 семантически связанных замен;
- контур: wallet lists, active wallet, proof boundary;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1657 — партия 11/25: Exchange and deposits

- целевой объём: 250 семантически связанных замен;
- контур: exchange requests, deposit ownership, reconciliation;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1658 — партия 12/25: Shop and orders

- целевой объём: 250 семантически связанных замен;
- контур: orders, balances, notifications, admin contracts;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1659 — партия 13/25: Achievements and outcomes

- целевой объём: 250 семантически связанных замен;
- контур: user progress, awards, snapshots;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1660 — партия 14/25: Admin financial services

- целевой объём: 250 семантически связанных замен;
- контур: users, panels, withdrawals, bank operations;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1661 — партия 15/25: Admin nonfinancial services

- целевой объём: 250 семантически связанных замен;
- контур: tasks, referrals, ranks, support searches;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1662 — партия 16/25: Routes and Pydantic contracts

- целевой объём: 250 семантически связанных замен;
- контур: self routes, DTO names, ambiguity guards;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1663 — партия 17/25: Frontend contracts

- целевой объём: 250 семантически связанных замен;
- контур: TypeScript types, requests, fixtures, browser/Telegram parity;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1664 — партия 18/25: Bot handlers and scheduler

- целевой объём: 250 семантически связанных замен;
- контур: provider boundary then canonical owner runtime;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1665 — партия 19/25: Workers, scripts and operator gates

- целевой объём: 250 семантически связанных замен;
- контур: jobs, reconciliation tools, architecture guards;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1666 — партия 20/25: ORM and physical schema preparation

- целевой объём: 250 семантически связанных замен;
- контур: column inventory, FK/index/constraint migration plan;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1667 — партия 21/25: Physical schema migration

- целевой объём: 250 семантически связанных замен;
- контур: provider columns, owner columns, backfill and rollback;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1668 — партия 22/25: Tests, fixtures and mocks

- целевой объём: 250 семантически связанных замен;
- контур: canonical selectors, provider-explicit naming, dead fixtures;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1669 — партия 23/25: SSOT/NORM/CANON cleanup

- целевой объём: 250 семантически связанных замен;
- контур: active documentation and release contracts;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1670 — партия 24/25: Alias-layer removal preparation

- целевой объём: 250 семантически связанных замен;
- контур: zero callers, ambiguity proof, compatibility expiry;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

### 1671 — партия 25/25: Final alias removal and zero-token gate

- целевой объём: 250 семантически связанных замен;
- контур: remove compatibility layer, full exact-head qualification;
- порядок: пользовательские GitHub CI-логи → исправление всех причин → новая партия;
- одновременно обновляются signatures, callers, DTO, SQL/ORM, tests и guards;
- после партии фиксируются baseline, заменено, осталось и исключённые evidence;
- alias применяется только через единый identity compatibility boundary;
- exact-head PASS обязателен перед удалением compatibility layer.

## Сдвинутый прежний план

Все ранее запланированные работы, начинавшиеся с цикла 1647, сдвинуты на 25 циклов:

- прежние 1647–1650 → новые 1672–1675: integration matrix, technical qualification и cutover candidate;
- прежние 1651–1653 → новые 1676–1678: Public visual recovery;
- прежние 1654–1660 → новые 1679–1685: Admin Support Center;
- прежние 1661–1665 → новые 1686–1690: screenshot canon и итоговая qualification.

Production cutover, public visual, Admin redesign и screenshot workflow не смешиваются с партиями identity migration и выполняются только после завершения 25 партий.

---

## Источник: `WORK_CYCLE_1601_FOUNDATION_ACCEPTANCE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1601 — открытие диапазона и приёмка фундамента

Исходный HEAD: `EFHC_Bot_v171_97.zip`.
Нулевая точка: `EFHC_Bot_v171_89.zip`.
Целевой HEAD: `EFHC_Bot_v171_98.zip`.

## Цель

Независимо принять фундамент циклов 1593–1600, подтвердить отсутствие
скрытого backfill/read switch/financial ownership switch и сформировать
воспроизводимый вход для диапазона 1601–1700.

## Независимая приёмка архивов

- baseline SHA-256:
  `21babdb44702b76afd81ddb3664a4dc0637fd478a33b5874259225773cba71dd`;
- baseline ZIP entries: `4808`;
- Current HEAD SHA-256:
  `da48b887bb0a55f2749ef95df88fde67665b8ef542a760f5e2e92b9f2e075232`;
- Current HEAD ZIP entries: `5535`;
- CRC: пройден;
- path traversal: не обнаружен;
- symlink и специальные файлы: не обнаружены.

## Независимый diff v171.89 → v171.97

- файлов baseline: `4569`;
- файлов Current HEAD: `5274`;
- добавлено: `705`;
- изменено: `75`;
- удалено: `0`;
- неизменено: `4494`.

Runtime-изменения ограничены EXPAND-фундаментом `users.user_id`,
identity helper-модулями и документирующими комментариями. Изменений
экономических формул и финансового ownership не обнаружено.

## Выявленный дефект

`audit_global_id_usage.py`, `render_identity_audit_russian.py` и
`postgresql_environment_preflight.py` формировали новые результаты с
жёстко заданными provenance-метаданными старых циклов. Фактические
метрики пересчитывались, но report мог ошибочно называться доказательством
`v171.95/1598` либо `1599`.

## Исправление

- exact `source_head`, `baseline_head` и `cycle` передаются явно;
- пустой HEAD и неположительный цикл отклоняются;
- добавлены причинные положительные и отрицательные тесты;
- runtime, БД и экономика не изменялись.

## PostgreSQL

Среда заблокирована: нет PostgreSQL URL, синхронного драйвера, `psql`,
PostgreSQL Server, Docker и Podman. Реальная reconciliation не
выполнена. Historical backfill и read switch запрещены.

## Следующий цикл

`1602 — независимый reconciliation baseline`.

## Применимость guards

Исторические patch-boundary циклов 1595–1596 не применяются к текущему
HEAD как вечный запрет. Их manifests сохранены неизменными для проверки
исторических target-head. Current HEAD контролируют активные EXPAND,
LEGACY alias, reconciliation, domain boundary и closure guards.

---

## Источник: `WORK_CYCLE_1602_GLOBAL_ID_CANONICALIZATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1602 — канонизация Global ID

Исходный HEAD: `EFHC_Bot_v171_98.zip`.
Целевой HEAD: `EFHC_Bot_v171_99.zip`.

## Цель

Закрепить `global_id` как единственный главный идентификатор аккаунта
EFHC, не создавая новую физическую колонку и не выполняя backfill,
read switch либо изменение финансового ownership.

## Реализовано

- введены `GlobalId`, `GlobalIdDisplay`, `ExternalGlobalId`,
  `PydanticGlobalId` и строгие helpers;
- `UserId` сохранён только как LEGACY type alias;
- введён `User.global_id = synonym("user_id")`;
- введены `User.legacy_pk = synonym("id")` и
  `User.telegram_id = synonym("tg_id")`;
- физические столбцы `users` не изменены;
- добавлены `GlobalIdRequest/GlobalIdResponse` и OpenAPI format
  `efhc-global-id`;
- активные SSOT/NORM/roadmap переведены на `global_id`;
- прежние identity-документы сохранены в history;
- audit matrix теперь направляет ownership в `global_id`;
- добавлен fail-closed guard против provider/local-PK mixing,
  отдельной колонки, новых неопределённых DTO `user_id`, новых FK на
  `users.id`, удаления aliases и преждевременного switch.

## Не выполнялось

- Alembic revision;
- изменение PostgreSQL DDL;
- historical backfill;
- dual-write, shadow read и runtime read switch;
- изменение балансов, панелей, кошельков, транзакций или экономики;
- создание `user_identities`, AuthContext или TON login;
- GitHub CI.

## PostgreSQL

Preflight заблокирован средой: нет URL, синхронного драйвера,
PostgreSQL Server, `psql`, Docker или Podman. Статус нельзя считать
успешной reconciliation.

## Exit gate

- `global_id` является активным логическим каноном;
- отдельной физической `users.global_id` нет;
- `users.id` остаётся PK;
- `users.user_id` остаётся nullable EXPAND-полем;
- Alembic head остаётся `0002`;
- backfill/read/financial switch равны `false`;
- причинные тесты и exact-HEAD guards проходят.

Следующий цикл: `1603 — Global ID PostgreSQL reconciliation baseline`.

## Проверка

- полный pytest: `2679 passed`, `175 skipped`, `0 failed`, `0 errors`;
- Global ID guards: пройдены;
- Operator Kernel guards: пройдены;
- Python compileall: пройден;
- PostgreSQL preflight: `БЛОКИРОВАНО_СРЕДОЙ`;
- GitHub CI: не запускался.

---

## Источник: `WORK_CYCLE_1603_GLOBAL_ID_POSTGRESQL_RECONCILIATION_BASELINE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1603 — Global ID PostgreSQL reconciliation baseline

Исходный HEAD: `EFHC_Bot_v171_99.zip`.
Целевой HEAD: `EFHC_Bot_v172_00.zip`.

## Цель

Подготовить и выполнить воспроизводимый реальный PostgreSQL gate для
`global_id` до historical backfill и read switch.

## Реализованный контур

- exact provenance передаётся явно и проверяется fail closed;
- canonical `global_id` отображается на physical `users.user_id`;
- отдельная колонка `users.global_id` считается нарушением;
- поддерживаются `psycopg` и `psycopg2`;
- URL нормализуется из sync/async SQLAlchemy-форм;
- один согласованный снимок: `REPEATABLE READ READ ONLY DEFERRABLE`;
- statement timeout 120 секунд, lock timeout 5 секунд;
- транзакция всегда завершается `ROLLBACK`;
- ошибки очищаются от реквизитов подключения;
- SQL-пакет может быть проверен независимо;
- production snapshot отделён от isolated empty-database smoke.

## Метрики

Users, physical `user_id`, legacy `global_id`, planned global_id collisions,
sequence, balances, kWh mirror, panels, transfers, withdrawals, referrals,
wallet bindings, roles, identity table, idempotency, tx hash и legacy
orphan references.

Финансовый допуск: `0.00000000` без округления.

## Фактическое выполнение

Попытка поднять реальную PostgreSQL-среду выполнена. В контейнере нет
PostgreSQL Server/client, Docker/Podman и sync driver. APT не получил
пакеты из-за недоступного DNS/mirror. Поэтому gate завершён честным
статусом `БЛОКИРОВАНО_СРЕДОЙ`; метрики данных не получены.

Это не разрешает historical backfill, dual-write, read switch или
financial ownership switch.

## Следующий цикл

`1604 — Backend GlobalId type finalization`.

---

## Источник: `WORK_CYCLE_1604_BACKEND_GLOBAL_ID_TYPE_FINALIZATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1604 — Backend GlobalId type finalization

Исходный HEAD: `EFHC_Bot_v172_00.zip`.
Целевой HEAD: `EFHC_Bot_v172_01.zip`.

## Цель

Убрать legacy `UserId` из канонического backend production API,
сохранив контролируемую совместимость с физической колонкой
`users.user_id` и историческими инструментами.

## Выполнено

1. `types.py` содержит только `GlobalId` и `TelegramId`.
2. `api_contract.py` содержит только канонические Global ID DTO.
3. `app.identity` не экспортирует legacy type names.
4. LEGACY API перенесён в `app.identity.legacy_user_id`.
5. Backfill harness использует `GlobalId` внутри Python-кода.
6. Добавлены явные database/provider conversion boundaries.
7. Добавлены стабильные коды `global_id.*` и `global_id.*`.
8. Добавлен fail-closed architecture guard и причинные тесты.
9. Operator Kernel получил отдельный маршрут цикла 1604.

## Не изменялось

- Alembic head `0002`;
- физическая колонка `users.user_id`;
- runtime primary key `users.id`;
- balances, kWh, panels и финансовая логика;
- historical backfill, dual-write и read switch;
- AuthContext, sessions, TON Proof и Telegram adapter.

## Следующий цикл

`1605 — Frontend GlobalId string system`.

## Итог тестирования

`2870` собрано, `2698` пройдено, `172` пропущено,
`0` падений, `0` ошибок. PostgreSQL и Chromium skips не являются
доказательством выполнения соответствующих контуров.

---

## Источник: `WORK_CYCLE_1605_FRONTEND_GLOBAL_ID_STRING_SYSTEM.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1605 — Frontend GlobalId string system

Исходный HEAD: `EFHC_Bot_v172_01.zip`.
Целевой HEAD: `EFHC_Bot_v172_02.zip`.

## Цель

Создать канонический frontend-тип `GlobalId`, который сохраняет ведущие
нули и не может использоваться как JavaScript number либо как аргумент
арифметики. Одновременно оптимизировать roadmap по фактическим
архитектурным зависимостям.

## Реализация

- `GlobalId` — branded string;
- wire/display формат — ровно десять ASCII-цифр;
- `0000000000` запрещён;
- создание значения возможно только через `parseGlobalId` либо
  `globalIdFromApi`;
- `globalIdToApi` и `formatGlobalId` не меняют строку;
- стабильные коды ошибок находятся в пространстве
  `global_id.frontend.*`;
- guard запрещает `number`, `bigint`, numeric schema/conversion,
  arithmetic и unsafe casts.

## Граница цикла

Текущие Telegram-specific `tg_id: number` не заменяются механически.
API DTO и OpenAPI-wide migration относятся к циклу 1606. Session-first
frontend switch относится к циклу 1694.

## Оптимизация roadmap

Введены code line и data line, gates `PG-0…PG-4`, возможность безопасно
подготовить циклы 1606–1612 при недоступной БД и жёсткий запрет на
начало цикла 1613 без реального `PG-0 PASS`. Устранена логическая
инверсия между циклами 1679 и 1680 и повторный read switch в 1697.

## Следующий цикл

`1606 — API-контракт global_id`.

## Итог тестирования

- точная collection: `2881`;
- `PASSED`: `2709`;
- `SKIPPED`: `172`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Пропуски: 95 browser E2E, 72 real PostgreSQL integration,
4 Postgres-only CI и 1 проверка без `DATABASE_URL`.

Isolated TypeScript strict typecheck и runtime contract пройдены.
Полный Next.js typecheck/build не выполнен: локальный npm cache не
содержит архив `zod`, поэтому `npm ci --offline` завершился
`ENOTCACHED`. Release-assets проверены: 29 файлов. Performance budgets
не запускались без `.next/build-manifest.json`.

## PostgreSQL

Reconciliation gate повторно завершился кодом блокировки среды.
`historical_backfill`, `dual_write`, `read_switch` и
`financial_ownership_switch` остаются `false`.

---

## Источник: `WORK_CYCLE_1606_GLOBAL_ID_API_CONTRACT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1606 — API-контракт global_id

Исходный HEAD: `EFHC_Bot_v172_02.zip`.
Целевой HEAD: `EFHC_Bot_v172_03.zip`.

## Цель

Создать единственный изолированный контракт `global_id` между backend
DTO, Pydantic/OpenAPI schema и frontend DTO без переключения активных
LEGACY routes.

## Реализация

- каноническое wire-поле: `global_id`;
- wire-тип: `string`;
- format: `efhc-global-id`;
- pattern: `^[0-9]{10}$`;
- min/max length: `10`;
- `0000000000` отклоняется runtime-валидацией;
- backend DTO: `GlobalIdRequest`, `GlobalIdResponse`;
- frontend DTO: `GlobalIdRequestDto`, `GlobalIdResponseDto`;
- единый воспроизводимый fixture:
  `contracts/identity/global_id_api_contract_v1.json`;
- fail-closed guard сравнивает backend, OpenAPI fixture и frontend.

## Граница цикла

Действующие routes, schemas, services и CRUD не импортируют новый
контракт. LEGACY envelopes с физическим именем `user_id` сохранены до
назначенного switch-stage. DDL, backfill и ownership не изменялись.

## Остаток

После цикла 1606 остаётся `94` цикла до 1700 включительно. Следующий
цикл: `1607 — Cross-language разделение GlobalId и TelegramId`.

## Итог тестирования

- exact-tree collection: `2899`;
- `PASSED`: `2727`;
- `SKIPPED`: `172`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Пропуски: 95 browser E2E, 72 real PostgreSQL integration,
4 Postgres-only CI и 1 проверка без `DATABASE_URL`. Skip не считается
реальным PostgreSQL или Chromium proof.

Frontend release-assets: PASS, 29 файлов. Полный Next.js build и
performance budgets не выполнены: offline npm cache не содержит `zod`,
а `.next/build-manifest.json` отсутствует.

PostgreSQL reconciliation: `БЛОКИРОВАНО_СРЕДОЙ`; backfill, dual-write,
read switch и financial ownership switch остаются `false`.

---

## Источник: `WORK_CYCLE_1607_CROSS_LANGUAGE_IDENTITY_SEPARATION.md`

# Рабочий цикл 1607 — Cross-language разделение GlobalId и TelegramId

Исходный HEAD: `EFHC_Bot_v172_03.zip`.
Целевой HEAD: `EFHC_Bot_v172_04.zip`.

## Цель

Согласовать nominal/branded типы backend/frontend и запретить прямое
либо косвенное смешение системного `GlobalId` с Telegram provider ID.

## Выполнено

1. Backend диапазон `TelegramId` ограничен positive safe integer.
2. Добавлен Pydantic-ready `ExternalTelegramId`.
3. Frontend получил branded number `TelegramId` и provider parser.
4. Telegram WebApp `user.id` проходит `telegramIdFromProvider`.
5. Добавлен воспроизводимый cross-language fixture.
6. Добавлен AST/TypeScript fail-closed guard.
7. Добавлены runtime, compile-time и negative causal tests.
8. Roadmap сокращён с 94 плановых слотов до 25 обязательных циклов.

## Неподвижная область

Alembic head `0002`; active routes, historical backfill, dual-write,
read switch, financial ownership и экономические формулы не менялись.

## Следующий цикл

`1608 — semantic allowlist и compatibility registry`.
## Финальная приёмка

- exact-tree: `2909` тестов;
- PASSED: `2737`;
- SKIPPED: `172`;
- FAILED/ERRORS: `0/0`;
- PostgreSQL: `БЛОКИРОВАНО_СРЕДОЙ`;
- release mirror: `753/753`;
- обязательных циклов осталось: `25`.

---

## Источник: `WORK_CYCLE_1608_IDENTITY_COMPATIBILITY_REGISTRY.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1608 — semantic allowlist и compatibility registry

Исходный HEAD: `EFHC_Bot_v172_04.zip`.
Целевой HEAD: `EFHC_Bot_v172_05.zip`.

## Выполнено

Создан единый machine-readable registry, различающий:

- канонический account owner `global_id`;
- физическое LEGACY-имя `users.user_id`;
- локальный primary key `id`;
- Telegram provider ID `tg_id`;
- пять разрешённых compatibility aliases;
- исторические области, не управляющие runtime;
- запрещённые новые DTO, owner/FK и provider-to-global зависимости.

Identity boundary читает active разрешения из registry. Исторический
baseline цикла 1602 сохранён и не переписан под текущий HEAD.

## Size-аудит

Исходный `v172.04` имел 5838 ZIP entries и размер около 25,6 МБ.
Распакованный `reports` занимал около 59 МБ. Причина роста:
исторические XLSX/raw identity matrices, JUnit/XML, pytest collection и
runtime logs. Код, migrations и production assets причиной не были.

Из основного архива перенесено или удалено 812 воспроизводимых файлов;
каждый путь, размер и SHA-256 сохранены в retention manifest.
Поставка переведена на три архива:

1. компактный development Current HEAD;
2. production release;
3. matrix/technical archive со всеми уникальными XLSX, текущим raw
   identity audit, JUnit/logs и подробным индексом перемещений.

## Запреты

Не выполнялись Alembic migration, historical backfill, dual-write,
shadow/read switch, financial ownership switch и изменение экономики.

## Следующий цикл

`1609 — AuthProvider и provider registry foundation`.

---

## Источник: `WORK_CYCLE_1609_AUTH_PROVIDER_REGISTRY_FOUNDATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1609 — фундамент реестра auth providers

Статус: `ЗАВЕРШЁН ЛОКАЛЬНО`.
Версия: `v172.06`.

## 1. Цель

Создать provider-neutral фундамент авторизации без изменения схемы
данных и владельца предметной области. Новый provider должен
подключаться через единый registry, а неизвестный или выключенный
provider обязан завершаться fail closed.

## 2. Реализованный фундамент

### 2.1. AuthProvider

Создан строгий перечислимый тип `AuthProvider` с exact ASCII wire
значениями, закреплёнными действующим identity SSOT. Пустые значения,
неизвестные имена, регистр, пробелы и Unicode confusables отклоняются.
Provider identifier не содержит `global_id` и не является owner.

### 2.2. VerifiedIdentity

Создан неизменяемый `VerifiedIdentity`. Его может создать только
внутренняя factory registry после успешной provider-specific
verification. Объект содержит только provider и проверенный subject.
Он не содержит `global_id`, raw proof, token, Telegram initData,
пользователя, session или сведения для автоматического merge.

`repr` скрывает provider subject. Общий boundary проверяет только
безопасный формат, а нормализация subject остаётся обязанностью
конкретного adapter.

### 2.3. Provider registry

Создан единый `AuthProviderRegistry` с регистрацией adapter factory,
capabilities, состоянием enabled или disabled и признаком test-only.
Registry запрещает повторную регистрацию, конфликт canonical name и
включённый provider без adapter. Lookup неизвестного, отключённого или
неподдерживающего capability provider завершается стабильной ошибкой.

Все девять production providers зарегистрированы как reserved и
`disabled`. Telegram не является обязательным root provider.

### 2.4. Feature flags

Добавлены раздельные настройки `AUTH_PROVIDER_FLAGS` и
`AUTH_PROVIDER_TEST_FLAGS`. Отсутствующий flag означает deny.
Test flags применяются только в `ENV=ci`. Mock provider запрещён в
local, dev, stage и prod, даже если его пытаются включить явно.

### 2.5. Ошибки и mock proof

Создан единый набор безопасных machine error codes с русскими
сообщениями. Сообщения не включают raw credentials, proof, token или
provider subject.

Test-only mock adapter подключается через тот же registry contract и
возвращает `VerifiedIdentity` только после явного test verification.
Он не импортирует domain services, не создаёт account или session и не
обращается к базе данных.

## 3. Operator Kernel

Добавлен exact primary route
`auth_provider_registry_foundation`. Классификатор распознаёт цикл
1609, `AuthProvider`, `VerifiedIdentity` и provider registry. Route
ограничивает изменения identity/auth foundation и прямо запрещает
DDL, backfill, read switch, ownership, finance и GitHub CI.

Устранён дефект исходного HEAD: ранее цикл 1609 попадал в общий
fallback, потому что точный route отсутствовал.

## 4. Release и retention

Release builder приведён к установленному production-составу: tests,
CI profile, test requirements и test tooling больше не пакуются в
release ZIP. Development-side contract и portability gate проверяют
это fail closed.

Retention-policy перенесла 35 оставшихся runtime evidence файлов цикла
1607 из development HEAD в matrix/technical archive с фиксацией пути,
размера и SHA-256. Код, tests, SSOT/NORM и итоговые summaries не
удалялись.

## 5. Что не изменялось

- Alembic revisions и head `0002`;
- PostgreSQL schema и data;
- `users`, domain FK и account ownership;
- historical backfill, dual-write и shadow/read switch;
- `IdentityResolver` и runtime `AuthContext`;
- auth challenges, sessions и roles;
- TON Proof и Telegram login;
- создание пользователей и присвоение `global_id`;
- auto-merge;
- балансы, kWh, панели, транзакции и экономические формулы;
- GitHub Actions и GitHub CI.

## 6. Exit gate

Exit gate выполнен локально:

```text
Mock provider подключается без domain changes.
Unsupported provider завершается fail closed.
```

Реальный PostgreSQL `PG-0` остаётся
`BLOCKED_BY_ENVIRONMENT`. Статус production readiness:

```text
LOCAL_PROVIDER_REGISTRY_READY
PG-0_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## 7. Следующий цикл

Следующий обязательный цикл:

```text
1610 — AuthContext contracts, resolver interfaces и
security/redaction skeleton без DDL
```

После завершения цикла 1609 остаётся 23 обязательных цикла:
`1610–1632`. Команда `запусти тесты CI GitHub` пока не требуется.

---

## Источник: `WORK_CYCLE_1610_AUTH_CONTEXT_CONTRACTS.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1610 — AuthContext contracts и resolver interfaces

Статус: `ЗАВЕРШЁН ЛОКАЛЬНО`.
Версия: `v172.07`.

## 1. Цель

Создать provider-neutral contracts до появления реального resolver и
DDL. Новый endpoint contract не должен зависеть от `global_id`, а auth
secrets не должны попадать в diagnostics или logging extras.

## 2. Реализованный объём

- immutable `AuthContext` из `GlobalId` и `VerifiedIdentity`;
- безопасный `AuthContextResponse` с `global_id`, `provider`, `roles`;
- `IdentityResolver` Protocol;
- outcomes `resolved`, `not_found`, `conflict`;
- recursive auth diagnostic redaction с depth/item limits;
- расширение общего logging redaction vocabulary;
- JSON contract, exporter и active guard;
- exact Operator Kernel route цикла 1610;
- unit, negative, boundary и architecture tests.

## 3. Инварианты

- `global_id` остаётся единственным account owner;
- `AuthContext` не содержит `global_id` или wallet address;
- raw input не может стать context или resolver input;
- `conflict` не выбирает один из аккаунтов;
- endpoint не раскрывает provider subject или session reference;
- diagnostics маскируют proof, token, initData, nonce и credentials;
- legacy runtime dependencies не переключаются.

## 4. Что запрещено и не выполнялось

- Alembic migration и PostgreSQL DDL/data;
- `user_identities` и реальный database resolver;
- locks, transactional resolve и auto-merge;
- account/session/challenge/roles storage;
- public login endpoint;
- TON Proof или Telegram adapter switch;
- historical backfill, dual-write и read switch;
- domain или financial ownership changes;
- GitHub CI.

## 5. Exit gate

```text
Новый endpoint contract не зависит от global_id.
Secrets не попадают в auth diagnostics.
```

## 6. Результаты тестирования

Fresh exact-HEAD collection содержит `2987` уникальных node ID.
Результат: `2815 PASSED`, `172 SKIPPED`, `0 FAILED`, `0 ERROR`.
Все skips вызваны только отсутствием реального PostgreSQL URL либо
отключённым browser E2E. Каждый node ID учтён ровно один раз в 12
завершённых JUnit-чанках. Защищённые 38 migration/model/financial
файлов совпадают с исходным HEAD по SHA-256.

## 7. Следующий цикл

`1611 — реальный PG-0, migration user_identities и constraints`.
Цикл 1611 нельзя закрыть без реального PostgreSQL proof.

---

## Источник: `WORK_CYCLE_1611_USER_IDENTITIES_POSTGRESQL_PACKAGE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1611 — user_identities и PostgreSQL test package

Версия: `v172.08`.

Статус:

```text
PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

## Цель

Подготовить schema EXPAND для provider-neutral identity storage и полный
PostgreSQL test package без установки PostgreSQL в среде чата и без
изменения канонических CI workflow.

## Реализовано

- Alembic revision `0003` после `0002`;
- ORM-модель `UserIdentity`;
- таблица `efhc_core.user_identities`;
- FK `global_id → users.user_id` с `RESTRICT`;
- unique `(provider, provider_tenant, provider_subject)`;
- range, provider, tenant, subject, status и verification constraints;
- partial unique index одной primary identity на account;
- fail-closed downgrade только пустой таблицы;
- read-only `PG-0` preflight;
- architecture, unit и negative tests;
- PostgreSQL integration test для upgrade `0002 → 0003`, constraints,
  financial parity, fail-closed downgrade и re-upgrade;
- offline PostgreSQL SQL render upgrade и downgrade;
- byte-for-byte guard неизменности `ci.yml` и `.github/workflows`;
- exact Operator Kernel route цикла 1611.

## Локальные доказательства

Fresh exact-HEAD collect содержит `3007` уникальных node ID без дублей.
Завершённый regression:

```text
2835 PASSED
172 SKIPPED
0 FAILED
0 ERROR
```

Все `172` skips относятся к PostgreSQL/browser environment gates.
PostgreSQL migration module дополнительно запущен отдельно и
зафиксирован как `1 SKIPPED` на уровне module, поскольку PostgreSQL и
`psycopg` по прямому указанию пользователя не устанавливались.

## Не выполнено

- PostgreSQL не устанавливался и не запускался;
- реальный `PG-0` не выполнен;
- migration не применялась online;
- PostgreSQL integration test не исполнялся;
- GitHub CI не запускался;
- CI workflow не создавались и не изменялись;
- backfill, resolver, account/session и ownership switch отсутствуют.

## Gate

Это не `PG-0 PASS`. Alembic code head равен `0003`, но applied
PostgreSQL head не подтверждён. Цикл 1612 заблокирован до выполнения
подготовленного test package существующим каноническим CI GitHub.

## Следующее действие

```text
Необходимо запустить канонический CI GitHub
```

## Локальная приёмка пакета

```text
2978 unique non-integration node ID
2832 PASSED
146 SKIPPED
0 FAILED
0 ERROR
PostgreSQL integration: NOT RUN
GitHub CI: NOT RUN
```

Offline SQL и static contracts проверены. Реальный PostgreSQL result
отсутствует и не подменён SQLite, mock driver либо offline renderer.

---

## Источник: `WORK_CYCLE_1612_TRANSACTIONAL_IDENTITY_RESOLVER.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1612 — transactional IdentityResolver

Версия: `v172.11`.

Статус:

```text
CYCLE_1611_EXACT_HEAD_PASS
CYCLE_1612_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## 1. Основание начала цикла

Канонический GitHub CI run `82850316409` выполнен на exact HEAD
`EFHC_Bot_v172_10.zip` размером `11 586 325` байт. Все gates прошли:
PostgreSQL preflight, Alembic `0001 → 0002 → 0003`, Ruff, Mypy,
Bandit, compileall, flake8, pytest и frontend build. Pytest:
`2918 passed`, `20 skipped`, `0 failed`, `0 errors`, `1 warning`.

Это закрывает цикл `1611` и разрешает начало цикла `1612`.

## 2. Цель

Реализовать provider-neutral transactional `IdentityResolver`, который
по уже проверенному `VerifiedIdentity` выполняет только lookup связи

```text
(provider, provider_tenant, provider_subject) → global_id
```

и возвращает один из outcomes:

```text
resolved
not_found
conflict
```

Resolver не создаёт account, identity, session или role, не назначает
`global_id`, не выполняет auto-merge и не меняет финансовые данные.

## 3. Реализованный lock protocol

1. Public method открывает собственную `AsyncSession` и транзакцию.
2. Для lookup-key вычисляется стабильный signed BIGINT через BLAKE2b.
3. Выполняется `pg_advisory_xact_lock`, поэтому сериализуется и случай,
   когда строки identity ещё нет.
4. Существующая строка читается через `SELECT ... FOR UPDATE`.
5. Внешний атомарный flow может вызвать `resolve_in_transaction` только
   внутри уже начатой транзакции; resolver не делает commit этой
   транзакции.
6. Raw provider subject не включается в lock key, diagnostics или repr.

## 4. Fail-closed conflicts

Machine-readable conflict codes:

- `multiple_matches`;
- `identity_inactive`;
- `identity_unverified`;
- `invalid_global_id`;
- `provider_not_storable`;
- `subject_not_storable`;
- `storage_conflict`.

При conflict `global_id` всегда равен `None`. Resolver никогда не выбирает
одну из конфликтующих записей и не объединяет аккаунты автоматически.

## 5. PostgreSQL test package

Добавлены реальные PostgreSQL tests:

- existing identity → тот же `global_id` без mutations;
- missing identity → `not_found` без создания user/identity;
- disabled/revoked/unverified → fail-closed conflict;
- шесть concurrent resolves → один детерминированный результат;
- advisory lock действительно блокирует missing-row lookup;
- `resolve_in_transaction` не коммитит caller transaction.

Локально PostgreSQL не запускается. Integration module успешно
собирает `8` PostgreSQL tests. Причинные unit/architecture/retention и
release-contract наборы дали `200 unique passed`. Реальное выполнение этих
PostgreSQL tests и полная static qualification остаются существующему
каноническому GitHub CI на exact HEAD `v172.11`.

## 6. Неизменяемые границы

- Alembic head остаётся `0003`;
- migration `0004` не создаётся;
- DDL и constraints `0003` не меняются;
- runtime routes и legacy `app.deps.AuthContext` не переключаются;
- account/session/challenge/role storage относится к циклу `1613`;
- TON Proof и Telegram adapter не реализуются;
- balances, kWh, panels и financial ownership не меняются;
- CI workflow остаются побайтно неизменными.

## 7. Exit gate

Цикл `1612` закрывается только после fresh exact-HEAD CI, который
подтверждает:

```text
Concurrent resolve детерминирован.
Conflict fail closed.
0 critical failures.
```

До этого цикл `1613` не начинается.

---

## Источник: `WORK_CYCLE_1613_AUTH_RUNTIME_FOUNDATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1613 — auth runtime foundation

Версия: `v172.12`.

Статус:

```text
CYCLE_1612_FUNCTIONAL_POSTGRESQL_STATIC_GATES_PASS
CYCLE_1612_HANDOFF_MARKER_FIX_INCLUDED
CYCLE_1613_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## 1. Основание

GitHub CI run `82865834601` подтвердил functional/static/PostgreSQL объём
цикла `1612`: resolver tests, PostgreSQL preflight, Alembic, Ruff, Mypy,
Bandit и frontend прошли. Общий run упал только на одном handoff marker,
который исправлен в `v172.12`.

## 2. Цель

Создать provider-neutral auth-core storage и services без подключения
provider login flows:

```text
auth_challenges
auth_sessions
user_roles
FastAPI auth dependencies
```

## 3. Storage и migration 0004

Migration `0004` является чистой `EXPAND` migration. Она создаёт три пустые
таблицы и составной FK session → `(identity_id, global_id)`, не создаёт
accounts/identities/sessions с данными и не меняет domain/financial ownership.
Downgrade разрешён только при пустых auth-таблицах.

## 4. Security contracts

- challenge token: high entropy, namespaced SHA-256 в storage, atomic consume;
- session token: high entropy, namespaced SHA-256 в storage, revoke support;
- raw tokens выдаются только один раз и redacted в `repr`;
- session требует active verified identity с тем же `global_id`;
- session issue статически проверяет точное значение `AuthProvider` и
  блокирует identity row до завершения транзакции;
- corrupted provider/global identity завершается fail closed;
- malformed bearer token всегда `401`, а не internal error;
- roles принадлежат только `global_id` и не содержат `global_id`;
- concurrent role grant использует PostgreSQL upsert.

## 5. Test package

Локально выполняются только короткие причинные tests и collection. Реальный
PostgreSQL package содержит `9` tests: schema/constraints, one-time challenge,
concurrent consumption, hashed session, identity/global mismatch, logout,
role revoke и concurrent role grant.

## 6. Release qualification boundary

Release archive проверяется статически без импорта приложения: metadata,
manifest, purity, modes и development/release parity. Импорт FastAPI при
отсутствующем `TON_WALLET_ADDRESS` не выполняется и имеет статус
`BLOCKED_BY_REQUIRED_CONFIGURATION`; фиктивные значения не используются.

## 7. Запреты

В цикле отсутствуют public endpoints, TON Proof, Telegram adapter switch,
account/identity creation, auto-merge, backfill, dual-write, read switch и
financial changes. Цикл `1614` не начинается до fresh exact-HEAD CI.

## 8. Exit gate

```text
One-time challenge.
Hashed session.
Roles по global_id.
Fresh exact-HEAD CI PASS.
```

---

## Источник: `WORK_CYCLE_1614_AUTH_CORE_POSTGRESQL_CLOSURE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1614 — Auth-core PostgreSQL integration closure

Версия пакета: `v172.13`.

## Цель

Закрыть PostgreSQL-доказательства auth-core без расширения runtime scope:

- migration `0004` и её constraints;
- concurrent one-time challenge consumption;
- hashed session и logout/revoke;
- роли, принадлежащие `global_id`;
- concurrent role grant;
- отсутствие critical skip внутри auth-core PostgreSQL module.

## Основание

Run `82888503300` доказал реальный PostgreSQL и Alembic upgrade до
`0004`, но выявил восемь pytest failures, три Ruff и два Bandit findings.
Исправляются только подтверждённые причины.

## Границы

Alembic head остаётся `0004`; migration `0005` отсутствует. Не создаются
public endpoints, TON Proof, Telegram adapter switch, accounts или
identities. Auto-merge, backfill, read switch и финансовые изменения
запрещены.

## Exit gate

```text
0 critical skips в auth-core PostgreSQL scope.
Migrations, concurrency, logout и roles доказаны exact-HEAD CI.
```

До fresh CI допустим только статус:

```text
CYCLE_1614_INTEGRATION_CLOSURE_PACKAGE_READY
EXACT_HEAD_CI_REQUIRED
CYCLE_1615_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

## Источник: `WORK_CYCLE_1615_TON_LOGIN_CHALLENGE_FOUNDATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1615 — TON audit, challenge endpoint и canonical address resolver

Версия пакета: `v172.14`.

## Цель

Подготовить provider-neutral начало TON login без Telegram-зависимости и без
преждевременной реализации cryptographic TON Proof.

## Реализовано

1. Добавлен endpoint:

   ```text
   POST /api/auth/ton/challenge
   ```

2. Endpoint не принимает и не читает `tg_id`, Telegram initData либо текущую
   Telegram session.
3. Challenge создаётся через `AuthChallengeService` и таблицу
   `efhc_core.auth_challenges`:
   - provider: `ton_wallet`;
   - purpose: `ton_wallet.login`;
   - TTL: 600 секунд;
   - raw payload возвращается один раз;
   - PostgreSQL хранит только namespaced SHA-256.
4. Production domain берётся только из configured public URL. Fallback на
   request Host разрешён только в local/dev/ci.
5. Введён `CanonicalTonAddressResolver`. Все допустимые raw/friendly,
   bounceable/non-bounceable, mainnet/testnet, base64/base64url формы дают один
   provider subject:

   ```text
   <workchain>:<64 lowercase hex account_id>
   ```

6. Единый parser подключён к существующему `tonconnect_proof_service`; его
   прежние дублирующие raw/friendly parser functions удалены.
7. Friendly input проверяет tag, точную длину, strict base64 alphabet и
   CRC16-XMODEM. Неявные преобразования `bool/int/object → str` запрещены.

## Разделение существующих контуров

Старый endpoint wallet binding, который выдаёт TonConnect payload для
известного Telegram-пользователя, остаётся legacy compatibility flow. Он не
является новым TON login endpoint и не используется циклом `1615`.

## Не входит в цикл

- signature verification;
- network verification;
- state-init verification;
- replay/concurrent consumption proof;
- account или identity creation;
- session issue;
- TON-only registration;
- Telegram adapter;
- migration `0005`;
- financial changes.

Эти cryptographic checks выполняются в цикле `1616`.

## Exit gate

```text
TON_CHALLENGE_TELEGRAM_INDEPENDENT
TON_ADDRESS_CANONICALIZATION_UNAMBIGUOUS
EXACT_HEAD_CI_REQUIRED
```

## Локальное причинное подтверждение

- четыре конкретных architecture failure run `82897904509`: `4 PASS`;
- новый TON foundation и напрямую связанные regression tests: `39 PASS`;
- статический TON guard: `PASS`;
- Operator Kernel exact primary route: `PASS`, fallback отсутствует;
- `43` protected files и migrations `0001–0004`: без изменений;
- полный regression, PostgreSQL и frontend build оставлены GitHub CI.

---

## Источник: `WORK_CYCLE_1616_TON_PROOF_CRYPTOGRAPHIC_VERIFICATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1616 — cryptographic TON Proof verification

Версия пакета: `v172.15`.

## Цель

Проверить TON wallet identity криптографически и закрыть one-time
challenge, не создавая account, identity или session раньше циклов
`1617–1618`.

## Реализовано

1. Добавлен endpoint:

   ```text
   POST /api/auth/ton/proof
   ```

2. TON Connect v2 message строится как double SHA-256 над:
   - workchain в int32 big-endian;
   - 32-byte account ID;
   - domain length в uint32 little-endian;
   - UTF-8 domain;
   - timestamp в uint64 little-endian;
   - one-time challenge payload.
3. Проверяются:
   - exact configured domain и `lengthBytes`;
   - timestamp age не старше 15 минут;
   - future skew не более 60 секунд;
   - chain `-239` либо `-3` и configured network;
   - bounded Base64 BoC state-init;
   - canonical address из state-init;
   - authoritative Ed25519 public key;
   - совпадение client key с authoritative key;
   - Ed25519 signature.
4. После успешной crypto verification challenge потребляется одним
   PostgreSQL `UPDATE ... RETURNING` по token hash, provider, purpose,
   domain и exact challenge ID.
5. Replay, TTL expiration, wrong challenge ID и concurrent consumption
   завершаются fail closed.
6. Response содержит только verified TON provider subject и не содержит
   `global_id`, session token либо Telegram identity.

## Объединение похожих tests

Однотипные vectors объединены без потери покрытия:

- domain/timestamp/network/key/signature/state-init failures находятся
  в одной параметризованной таблице;
- schema coercion cases находятся в одной параметризованной таблице;
- TonAPI configuration и authoritative-address cases параметризованы;
- PostgreSQL TTL и wrong-ID boundaries объединены одним test function;
- общая генерация Ed25519 vectors вынесена в
  `tests/support/ton_proof_vectors.py`.

## Не входит в цикл

- создание нового account;
- сохранение `user_identities`;
- выдача `auth_sessions`;
- TON-only registration;
- frontend session transport;
- Telegram adapter;
- migration `0005`;
- financial changes.

## Exit gate

```text
TON_PROOF_ALL_VECTORS_PASS
TON_PROOF_CONCURRENT_CONSUMPTION_PASS
EXACT_HEAD_CI_REQUIRED
```

## Локальное причинное подтверждение

- новые cryptographic vectors: `25 PASS`;
- route и подтверждённые CI contracts: `31 PASS`;
- static guard и Operator Kernel route: `4 PASS`;
- PostgreSQL integration module: `3 tests collected`, DB not run;
- Alembic head: `0004`, migration `0005` отсутствует;
- полный pytest, PostgreSQL и frontend build оставлены GitHub CI.

---

## Источник: `WORK_CYCLE_1617_TON_ACCOUNT_REGISTRATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1617 — TON account registration

## Цель

После verified TON Proof детерминированно открыть существующий global
account либо создать новый TON-only account без фиктивного Telegram ID.

## Реализация

1. `PostgreSQLIdentityResolver` удерживает advisory lock по TON identity.
2. Existing active verified identity возвращает тот же `global_id`.
3. Existing active verified legacy wallet binding создаёт identity для того
   же account.
4. Новый wallet создаёт `users`, `user_identities` и `wallet_bindings` одной
   транзакцией.
5. `users.global_id` и `wallet_bindings.global_id` nullable с migration `0005`.
6. Conflict, inactive/unverified binding и legacy drift завершаются fail
   closed. Auto-merge отсутствует.
7. Proof endpoint возвращает `global_id` и account outcome, но не session.

## PostgreSQL evidence package

Подготовлены сценарии existing identity, legacy binding, new TON-only
registration, concurrent registration и unverified binding. Реальная БД
проверяется только каноническим GitHub CI.

## Exit gate

```text
ONE_WALLET_ONE_GLOBAL_ACCOUNT
FAKE_TG_ID_ABSENT
EXACT_HEAD_CI_PASS_REQUIRED
```

---

## Источник: `WORK_CYCLE_1618_TON_AUTH_SESSION_LOGOUT_CLOSURE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1618 — TON auth/session/logout closure

## Цель

После успешного TON Proof атомарно разрешить или создать TON account и
выдать provider-neutral server-side session. Добавить inspection/logout
endpoints и изолированный frontend transport без Telegram зависимости.

## Реализованный backend scope

- `TonAuthSessionService` объединяет account resolution и session issue в
  одной PostgreSQL-транзакции.
- `AuthSessionService.issue_in_transaction` блокирует verified identity и
  сохраняет только namespaced SHA-256 hash token.
- `GET /api/auth/session` возвращает безопасный `AuthContextResponse`.
- `POST /api/auth/logout` атомарно отзывает текущую session.
- TON Proof response возвращает credential один раз с `Cache-Control: no-store`.

## Frontend transport

- credential хранится только в `sessionStorage`;
- `Authorization: Bearer` добавляется централизованно;
- `401` удаляет локальную session fail closed;
- logout очищает local credential даже при сетевой ошибке;
- `global_id` остаётся строкой из десяти ASCII-цифр.

## PostgreSQL evidence package

Подготовлены сценарии нового TON-only login, повторного login, logout и шести
конкурентных login attempts. Реальная БД локально не запускается.

## Запреты

- migration `0006` отсутствует;
- Telegram initData adapter не переключается;
- роли и финансовые данные не меняются;
- auto-merge, backfill и ownership/read switch отсутствуют.

## Exit gate

```text
CYCLE_1618_EXACT_HEAD_CI_PASS
```

---

## Источник: `WORK_CYCLE_1619_TELEGRAM_INIT_DATA_SESSION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1619 — Telegram initData adapter и session issue

## Цель

Создать provider-neutral Telegram login flow, в котором Telegram
является способом подтверждения доступа, а не владельцем account data.

## Реализованный поток

1. `POST /api/auth/telegram/session` получает `X-Telegram-Init-Data`.
2. Канонический Telegram HMAC verifier проверяет подпись.
3. Adapter проверяет строгий raw boundary, TTL и future skew.
4. Результат преобразуется в `VerifiedIdentity(provider=telegram)`.
5. Transactional `IdentityResolver` разрешает существующую identity.
6. При отсутствии identity используется существующий legacy account по
   `tg_id` либо создаётся новый Telegram account и identity.
7. В той же транзакции выдаётся hashed server-side session.
8. Exact initData replay отклоняется через namespaced hash в
   `processed_external_events`.

## Инварианты

- один Telegram provider subject соответствует одному `global_id`;
- повторный вход открывает тот же account;
- `global_id` не становится domain owner;
- `global_id` не вычисляется из `global_id`;
- raw `initData` и raw session token не сохраняются;
- provider subject и `tg_id` отсутствуют в публичном response;
- auto-merge и финансовые mutations отсутствуют;
- legacy Telegram routes не переключаются;
- migration `0006` отсутствует.

## PostgreSQL evidence package

Подготовлено шесть tests: existing identity, legacy account adoption,
new account/session, repeat login, exact replay и concurrent first
login. Реальный PostgreSQL выполняет канонический GitHub CI.

## Exit

```text
Telegram provider не owner.
Повторный вход открывает тот же account.
Session выдаётся атомарно и хранится только как hash.
```

До fresh exact-HEAD CI статус цикла — `PACKAGE_PREPARED`.

---

## Источник: `WORK_CYCLE_1632_PRE_RELEASE_MIGRATION_SQUASH.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1632 — pre-release migration squash

Цикл завершён.

## Результат

- active Alembic lineage содержит только
  `0001_initial_release_schema.py`;
- migration сразу создаёт physical `users.global_id`;
- 38 owner FK направлены на `users(global_id)`;
- sequence, auth/identity runtime и telemetry создаются в `0001`;
- historical revisions `0002–0013` не исполняются и не входят в
  production release;
- старые pre-release базы требуют clean recreate или restore snapshot.

## Подтверждение

Fresh CI `83372708711` успешно применил `0001` на clean PostgreSQL.
Дальнейшая exact-head и live qualification выполняется циклом `1633`.

---

## Источник: `WORK_CYCLE_1633_RELEASE_QUALIFICATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1633 — release qualification и выпуск

## Состояние

Цикл остаётся общей выпускной рамкой. UI-подцикл `1635` не закрыт: в
`v172.51` follow-up corrective и registration core реализованы, но exact-head qualification отсутствует.

## Уже подтверждено

- одна active migration `0001_initial_release_schema.py`;
- physical owner `users.global_id`;
- 48 ORM-таблиц, 49 прикладных и 50 физических;
- 38 owner FK;
- OpenAPI 131/136 и linkage 99/99;
- route-backed Chromium mechanism на 102 checks.

## Текущий пакет

`v172.51` добавляет profile/dock/Energy/Back follow-up и ядро `AccountRegistrationService`.
Скриншоты CI не входят в рабочие архивы.

## Осталось

1. Exact-head GitHub CI `v172.51`.
2. Просмотр новых route-backed PNG exact `v172.51`.
3. Пользовательская visual acceptance цикла `1635`.
4. Циклы `1636–1640` по отдельности.
5. Production deployment smoke.
6. Rollback/restore smoke.
7. Live Telegram/TON/API smoke.

## Выход

```text
CYCLE_1635_VISUAL_ACCEPTED
CYCLE_1633_EXACT_HEAD_PASS
DEPLOYMENT_SMOKE_PASS
ROLLBACK_RESTORE_PASS
LIVE_HANDOFF_PASS
PRODUCTION_RELEASE_READY
```

---

## Источник: `WORK_CYCLE_1634_CHAT_QA_PUBLIC_UI_AUDIT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1634 — чаты, Q/A и публичная визуальная основа

## Цель

Восстановить решения из чатов 40–51, обновить Q/A и исправить
глобальные визуальные несоответствия публичного приложения.

## Выполнено

- чаты 40, 41, 43, 44, 45, 47, 49, 50 и 51 приняты в canonical-папку;
- применено правило приоритета более новой информации;
- актуализированы identity, migration, UI и referral ответы;
- верхний баланс переведён в одну компактную строку;
- введены мягкие публичные кнопки и навигационные состояния;
- Chromium PNG остаются отдельным GitHub artifact.

## Exit gate

- imported chats присутствуют и проиндексированы;
- Q/A содержит текущий physical `global_id` и единый `0001`;
- Global Header содержит `single-line` balance contract;
- public shell содержит `soft-muted-v1` color contract;
- шесть нижних маршрутов не изменены;
- DEV/RELEASE не содержат CI screenshots.

## Следующий цикл

`1635` — анализ новых CI-скриншотов после этой визуальной основы и
точечное исправление отдельных страниц. В этом пакете цикл 1635 не
начат.

---

## Источник: `WORK_CYCLE_1635_PUBLIC_ROUTE_HARMONY.md`

# Цикл 1635 — corrective public/admin visual parity

## Цель

Сделать основной пользовательский интерфейс таким же цельным, спокойным и
профессиональным, как admin reference, не меняя функции, routes, экономику,
backend или database architecture.

## Fresh evidence v172.49

GitHub CI `83387356493` проверил exact `v172.49`. Production build прошёл.
Chromium создал route-backed PNG, но FAQ и HUB дали шесть failures из-за
fixed read-only offline status. Скриншоты также показали gold-heavy public
surfaces, чрезмерную высоту HUB и сырые `**` в FAQ.

## Реализовано в v172.50

- admin-quality slate/blue/teal public design system;
- единые cards, borders, radii, shadows, spacing и typography hierarchy;
- soft primary/secondary/disabled/focus states;
- полный адаптивный однострочный баланс;
- compact Browser Login;
- HUB cards уменьшены без изменения двух действий;
- safe FAQ renderer для bold/paragraph/list;
- inline read-only PWA status без overlap;
- visual gate различает inline status и реальные obstructing overlays;
- admin home очищен до release/business/operator data;
- шесть bottom routes сохранены.

Сравнительная матрица:
`docs/NORM/PUBLIC_UI_ADMIN_PARITY_MATRIX_V172_50.md`.

## Не выполнялось

- backend, migrations, auth, financial runtime и экономика не менялись;
- Скриншоты не копируются в development, release или matrix;
- цикл `1636` не начинался.

## Exit gate

```text
CYCLE_1635_CORRECTIVE_IMPLEMENTED
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_NOT_STARTED
```

Цикл закрывается только после fresh exact-head CI `v172.50`, новых PNG и
визуальной приёмки пользователя.

---

## Follow-up v172.51

Fresh screenshots exact `v172.50` подтвердили общий admin-quality перенос,
но выявили оставшиеся mobile defects:

- `Назад` и `Выход` в профиле находились не в одной строке;
- нижний six-route dock выглядел слишком плоско и примитивно;
- Energy icon не был связан с progress bar;
- Android/PWA Back мог завершить приложение вместо внутреннего перехода.

В `v172.51` реализованы responsive one-row profile actions, premium dock,
layered energy core marker и единый app-contained back-controller.
Маршруты, labels, порядок шести кнопок и экономика не изменены.

Статус остаётся `VISUAL_ACCEPTANCE_REQUIRED` до fresh exact-head PNG.

---

## Источник: `WORK_CYCLE_1647_GLOBAL_OWNER_BIG_BANG_REWRITE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Цикл 1647 — Global Owner Big-Bang Rewrite

## Фаза A — v172.65

- полный inventory всех `global_id`;
- boundary contract;
- массовая замена business runtime на `global_id`;
- alias-harness старого keyword;
- `telegram_provider_id` как явное имя provider fact;
- compile и structural cleanup;
- без функциональной квалификации.

Exit:

`GLOBAL_OWNER_BULK_REWRITE_READY_FOR_TEST_REPAIR`

## Фаза B — следующий пакет

- полный PostgreSQL CI;
- полный pytest;
- Ruff, Flake8, Mypy, Bandit;
- исправление signatures, SQL, fixtures, mocks и historical read-through;
- подтверждение Telegram и TON-only equivalence;
- подтверждение idempotency и concurrency.

Exit:

`GLOBAL_OWNER_BULK_REWRITE_TESTS_PASS`

## Фаза C — после PASS

- удалить `global_owner_alias.py`;
- удалить `User.tg_id`, `User.telegram_id` и иные synonyms;
- физически переименовать provider columns при подтверждённой миграции;
- удалить deprecated routes и fixtures;
- удалить historical compatibility registry после отдельного gate.

Exit:

`GLOBAL_ID_ONLY_BUSINESS_RUNTIME_AND_ALIASES_REMOVED`

---

# ACTIVE PLAN ENTRIES

Источник: `docs/PLANS/WORK_PLAN_1693-1709.md`.

## 1693 — Runtime provider-boundary audit

Scope: 81 текущая scanner review/actionable строка, прежде всего backend/raw SQL.
Закрыть реальные business misuse; отрицательные policy/test строки классифицировать
только по точной семантике.  
**Критерий:** `business_owner_tg_id = 0`, provider baseline <= 106 файлов / 1011
употреблений, без новых surfaces.

## 1694 — Admin ownership finalization

Admin CRUD, actors, filters, bank, withdrawals, reports, DTO и frontend admin.
Owner/actor/search key — `global_id`; provider ID допустим только для delivery.  
**Критерий:** admin business selectors через `tg_id = 0`.

## 1695 — Financial identity keys

Idempotency, reconciliation, locks, cache, ledger, payment intents и withdrawal
keys. Historical read-through отделить от записи новых ключей.  
**Критерий:** новые financial keys строятся только на canonical `global_id`.

## 1696 — Notifications and workers split

Watchers/workers/notifications: account owner `global_id`, Telegram recipient
`tg_id`; delivery resolution выполняется в boundary.  
**Критерий:** background business state не индексируется Telegram ID.

## 1697 — Frontend identity finalization

Остаточные props, query keys, generated seams, admin filters, browser shop,
profile/wallet UI.  
**Критерий:** business frontend использует string `global_id`; Telegram context
остаётся только provider/UI bootstrap.

## 1698 — API/OpenAPI finalization

Business response/path/query schemas, deprecated Telegram ingress, generated
clients/validators.  
**Критерий:** numeric `global_id` schemas = 0; business `tg_id` response fields = 0.

## 1699 — PostgreSQL 0001 proof

Fresh database и upgrade существующей pre-release базы: FK, indexes, unique,
triggers/functions, orphan checks, NOT NULL и отсутствие dual-owner.  
**Критерий:** ORM ↔ 0001 ↔ raw SQL parity; единственный Alembic head.

## 1700 — Test provider allowlist finalization

Построчно уменьшить 507 зарегистрированных test `tg_id` occurrences; удалить
transitional fixtures и оставить provider/schema/negative guards.  
**Критерий:** business-service calls with `tg_id = 0`; без broad allowlist.


---

## Источник: `GLOBAL_OWNER_FINANCIAL_SERVICES_IMPLEMENTATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Реализация canonical owner в финансовых сервисах

## Результат

Транзакционный и доменный write-path переведён на canonical `global_id`.
Временный `global_id` принимается только как provider selector и разрешается
через общий write-side owner boundary.

## Транзакции и ledger

Обновлены основные credit, debit и bonus entrypoints, а также no-commit
варианты. Строка владельца блокируется до денежной мутации. Ledger пишет
`global_id` и nullable `global_id`. Повтор одной операции с другим selector
возвращает существующий результат вместо создания второго начисления.

## Panels

Активация, создание и архивирование используют `global_id`. Panel records
сохраняют canonical owner и необязательный Telegram provider attribute.
Referral callback временно выполняется только для Telegram account и будет
переведён отдельно согласно утверждённому плану.

## Withdrawals

Создание заявки и hold остаются одной атомарной границей. Поиск pending,
обновление `hold_done`, отмена и refund привязаны к `global_id`. Audit meta
содержит canonical owner.

## Payment Intents

Три create-flow используют canonical owner. Для Telegram сохранён прежний
numeric payload token. Для account без Telegram используется формат
`G##########`. Parser распознаёт оба формата. Watcher-подключение нового
owner token остаётся отдельным caller-tail и не объявляется завершённым.

## Схема совместимости

Provider-колонки `global_id` сделаны nullable для transfer log, panels, panel
archive, withdraw requests, deprecated withdrawals и payment intents. Это
EXPAND-совместимость для TON-only account, а не production cutover.

## Идемпотентность

Основные keys не меняются при выборе `global_id` или `global_id`. Read-through
проверяет canonical owner. Исторические keys не переименовывались.
Referral и exchange keys, завязанные на Telegram, остаются в следующих
утверждённых циклах.

## Запрещённые утверждения

Этот пакет не означает полный `global_id` cutover, не переключает
`legacy_authoritative` и не удаляет legacy aliases. Полная квалификация
требует PostgreSQL и unchanged exact-head GitHub CI.

---

# Фактическое выполнение цикла 1694 — v173.14

Статус: **CYCLE 1694 LOCALLY COMPLETE / EXACT_HEAD_CI_REQUIRED**.

## Operator Kernel

Запрос классифицирован как `ci_logs_repair_or_verification`; primary route —
`ci_log_exact_failure_repair`. Required reads ограничены active SSOT/NORM,
admin ownership scope, входным GitHub CI run `84704272282` и точными failing
surfaces.

## Admin ownership finalization

- `admin_stats_service` больше не группирует panels по `tg_id`; owner/output —
  `global_id`.
- Из admin user/deposit business DTO удалён `provider_tg_id` вне delivery
  boundary.
- Новый fail-closed guard фиксирует `active_business_selector_tg_id = 0` и
  `frontend_admin_business_tg_id = 0`.
- Три существующих финансовых historical read-through фрагмента зарегистрированы
  отдельно. Они не считаются active admin owner selectors и переходят только в
  финансовый scope цикла 1695 без изменения порядка плана.
- Общий provider baseline уменьшен `106 files / 1011 occurrences` →
  `103 / 994`; `business_owner_tg_id = 0`, semantic mix offenders = 0.

## Fresh GitHub CI repair

Входной run `84704272282`, commit
`02667638d2b423fbc733a8e32a88b44996a3ba6e`, дал `11 failed / 1449 passed /
22 skipped`; остальные зафиксированные gates были PASS.

Подтверждённые причины:

1. OpenAPI checked-in snapshot содержал runtime `/api` prefix — 6 failures.
2. Archive/history hygiene не был синхронизирован с canonical history paths —
   3 failures.
3. Local release gate использовал старые cycle/CI-receipt paths — 1 failure.
4. Новые report-tooling artifacts нарушали Russian engineering policy —
   1 failure.

Исправления выполнены минимально. Canonical OpenAPI rebuild дал `127 paths /
132 operations`. Targeted повтор затронутых CI-contract modules и новых guards после финальных
правок: `59 passed`. Финальный governance/history pack после release/ledger sync:
`17 passed`.

## History и deletion protection

- Все 36 файлов `АРТЕФАКТЫ/Чаты` перенесены в `docs/chats` без изменения
  зарегистрированных bytes; 33 manifest rows проверены по SHA-256.
- `docs/cycles/` сохраняет ровно 18 диапазонных документов по 100 циклов.
- `reports/numbered/` продолжает immutable cadence.
- Новый architecture guard защищает cycles/reports/chats.
- Отдельный manifest регистрирует 243 стабильных каталога проекта вне
  `АРТЕФАКТЫ`; удаление либо незарегистрированное структурное изменение
  fail-closed ломает test.

## Проверки

- CI-contract/history guards: `54 passed`.
- Admin architecture pack: `45 passed`.
- Admin runtime subset: `2 passed, 2 skipped`.
- Collection-only: `1517 tests collected`.
- Release portability architecture pack после final authority sync: `16 passed`.
- Default output `local_pre_release_gate.py` перенесён из старого `АРТЕФАКТЫ/.../reports/generated` в канонический `reports/generated`; случайно созданный старый output удалён.
- Полный локальный CI/pytest не запускался и не выдаётся за PASS.

## Следующий цикл

`1695 — Financial identity keys`. Осталось 13 циклов: `1695–1707`.

Numbered reports цикла:
- `reports/numbered/reports_02206__cycle_1694_cycle_1694_admin_ownership_ci_history_guards.md`;
- `reports/numbered/reports_02207__cycle_1694_cycle_1694_final_release_gate_authority_sync.md` — финальная фиксация release-gate active-authority sync.

# Фактическое выполнение цикла 1695 — v173.15

Статус: **CYCLE 1695 LOCALLY COMPLETE / EXACT_HEAD_CI_REQUIRED**.

## Operator Kernel

Запрос классифицирован как `ci_logs_repair_or_verification`; primary route —
`ci_log_exact_failure_repair`. Required reads ограничены active identity SSOT/NORM,
financial identity-key scope и входным GitHub CI run `84716817578`.

## Financial identity keys

- Новые monetary rate-limit fingerprints и DB idempotency TTL locks в
  `backend/app/core/system_locks.py` переведены с Telegram provider identity на
  canonical `global_id`; `IdempotencyKey.global_id` теперь записывается для этих
  новых lock rows.
- Telegram initData/state остаются только provider ingress для resolution до
  `global_id`; provider subject не входит в новый lock/fingerprint key.
- Payment reconciliation сначала требует canonical `payment_owner_global_id`;
  provider owner допускается только как historical read-through, когда canonical
  owner отсутствует в старом snapshot.
- Exchange compatibility уже сохраняет legacy key только для historical
  read-through, а для новой операции выбирает canonical `exchange:G<global_id>`.
- Payment intents используют conflict key `(global_id, purpose, idempotency_key)`,
  tx-hash lock пишет `global_id`, withdrawal pending owner проверяется по
  `global_id`.
- Новый fail-closed checker `ops/identity/check_financial_identity_keys.py`
  фиксирует `new_financial_provider_keys = 0`.

## Fresh GitHub CI repair

Входной run `84716817578`, commit
`50c7c6e696263ed006ac7dc7461f3121452c65f7`, подтвердил 7 pytest failures;
остальные canonical gates в предоставленных логах были PASS.

Исправлены все подтверждённые причины:

1. repo/canon guard видел запрещённый legacy identifier literal внутри самого
   admin checker — проверка сохранена, literal разбит без ослабления semantics;
2. `frontend/scripts/budgets.mjs` и admin release marker отставали от package
   version — version metadata синхронизирована на `v173.15`;
3. исторические `docs/chats` ошибочно сканировались semantic/lexical guards —
   `docs/audits`, `docs/cycles`, `docs/chats`, `reports`, `АРТЕФАКТЫ` исключены
   только из исторически несовместимых terminology scanners; structural deletion
   protection сохранён.

По прямому указанию пользователя pytest/полный локальный CI не запускались;
следующая функциональная квалификация — только новым GitHub CI.

## Chats

Побайтно добавлены предоставленные пользователем `52.md`, `53.md`, `54.md`,
`55.md`, `57.md`. Для 53/55 прежний `SOURCE_BYTES_NOT_FOUND` закрыт реальными
source bytes, без реконструкции. В `docs/chats` теперь 34 numbered transcripts.

## Targeted validation

Один финальный allowed pass: Python syntax PASS; financial checker PASS; provider
boundary checker PASS; chat SHA-256/CI-fix static surface PASS. Provider surface:
`103 files / 984 occurrences`, предыдущая `103 / 994`;
`business_owner_tg_id = 0`, semantic mix = 0. После этого повторные локальные
проверки не выполнялись.

## Следующий цикл

`1696 — Notifications and workers split`. Осталось 12 циклов: `1696–1707`.

# Фактическое выполнение цикла 1696 — v173.16

Статус: **CYCLE 1696 LOCALLY COMPLETE / EXACT_HEAD_CI_REQUIRED**.

## Notifications and workers split

- Watcher сохраняет `global_id` как account owner; legacy Telegram memo сначала
  разрешается до canonical owner.
- Shop-order notifications выбирают business rows по `global_id`, затем через
  `resolve_telegram_notification_channel` получают `tg_id` только для Bot API delivery.
- `AdminNotifier.notify_new_withdrawal` переведён с business `tg_id` на `global_id`;
  payload и admin message больше не используют Telegram ID как owner.
- Добавлен fail-closed checker `ops/identity/check_background_identity_split.py`.

## CI repair, относящийся к текущему запросу

GitHub run `84730488240`, `GITHUB_SHA=5fab35302611516bede9c2f0ffb9086f4b2cfb24`:
Bandit подтвердил `B110` в `backend/app/core/system_locks.py`; bare `pass` заменён
на debug logging без изменения downstream 401 semantics.

## Критерий

`background_business_state_tg_id = 0`; Telegram delivery boundary сохранён.
Новый GitHub CI требуется для exact-head подтверждения.

# Фактическое выполнение цикла 1697 — v173.16

Статус: **CYCLE 1697 LOCALLY COMPLETE / EXACT_HEAD_CI_REQUIRED**.

## Frontend identity finalization

- Telegram provider ID больше не прокидывается через generic `<Component>` page props,
  `AdminVisualProofRouter` page props, `LayoutContext`, `ShopLayout` или Energy page.
- В `_app.tsx` provider subject явно назван `telegramProviderId` и остаётся только
  provider/UI bootstrap: Telegram presence, admin UI allowlist и wallet proof boundary.
- Business query keys продолжают использовать string `GlobalId`.
- Provider-specific `tg_id` сохранён только там, где это реальная Telegram/payment
  metadata boundary: generated browser bootstrap, TON memo/direct-deposit protocol,
  provider validators и denylist admin filters.
- Добавлен fail-closed checker `ops/identity/check_frontend_identity_finalization.py`.

## Fresh GitHub CI repair

В том же run подтверждены 4 pytest failures: stale cycle-numbered test filename,
mutable cycle-range SHA expectation и русскоязычный engineering-policy guard.
Исправлены: test переименован тематически; cycle history guard защищает структуру,
а не замораживает hash изменяемого диапазона; новые engineering comments/test names
приведены к русскоязычной политике; historical audits/cycles/reports/chats исключены
из semantic language scanning, при этом structural deletion protection сохранён.

## Критерий

`business_frontend_tg_id_owner = 0`; Telegram context — provider/UI bootstrap only.
Следующий цикл: `1698 — API/OpenAPI finalization`. Осталось 10 циклов: 1698–1707.

# Фактическое выполнение цикла 1698 — v173.17

Статус: **CYCLE 1698 LOCALLY COMPLETE / EXACT_HEAD_CI_REQUIRED**.

## Operator Kernel и GitHub CI

Operator Kernel классифицировал запрос как `ci_logs_repair_or_verification` с primary route
`ci_log_exact_failure_repair`. Required reads были ограничены active identity SSOT/NORM,
API/OpenAPI scope цикла 1698 и GitHub CI run `84735592257`.

В предоставленном run, `GITHUB_SHA=c7879475b13f381435939eba62caa9c6220fdf69`,
подтверждены два причинных кластера: frontend TypeScript не имел `telegramProviderId`
в типе props `Layout` (5 emitted TS errors) и один stale architecture test всё ещё ожидал
`!props.tg_id`. Остальные зафиксированные canonical gates были PASS.

Исправлено минимально: тип `Layout` синхронизирован с уже существующим provider/UI bootstrap
`telegramProviderId`; architecture test проверяет новое имя provider boundary. Полный локальный
pytest и frontend build не запускались; следующая квалификация выполняется новым GitHub CI.

## API/OpenAPI finalization

- OpenAPI: numeric `global_id` schemas = `0`.
- OpenAPI business response fields `tg_id` = `0`.
- Browser Shop generated seam/validator переведён со stale `tg_id: number | null` на optional
  string `global_id` с regex `^[0-9]{10}$`; исправлены и генераторы, и checked-in outputs.
- Deprecated `/sync/user/{tg_id}` явно помечен `deprecated=True` и deprecation headers; route
  выполняет immediate identity resolution и не становится business owner path.
- `ops/identity/check_global_id_api_contract.py` усилен fail-closed проверками numeric schemas,
  response `tg_id`, generated seams и deprecated Telegram ingress.

Критерий цикла 1698 выполнен локально: `numeric_global_id_schemas = 0`,
`business_tg_id_response_fields = 0`.

## Артефакты и history

Исходный корневой `АРТЕФАКТЫ/` содержал 1348 файлов / 15 869 763 bytes. Причина активного
использования: после прежней исторической реорганизации часть machine manifests и guards
сохранила hard-coded зависимости от archive paths.

Перед изменением структуры исходный каталог побайтно сохранён во внешнем архиве
`EFHC_Bot_v173_17_ARTIFACTS_HISTORY.zip`. Затем:

- 958 historical documents → `docs/history/legacy_artifacts`;
- 43 historical code files → `docs/history/code_archive`;
- 330 archived tests/evidence files → `docs/history/test_archive`;
- 18 active machine manifests → `reports/manifests`;
- historical README → `docs/history/ARTIFACTS_LEGACY_README.md`.

Active tooling переведён на canonical paths; корневой `АРТЕФАКТЫ/` удалён.
`docs/history` исключён из semantic policy scanners, но включён в structural directory retention.

## Остаток identity migration

Финальный inventory после исключения immutable `docs/chats`, `docs/cycles`, `docs/history` из
actionable semantics: 3865 токенов всего; 3787 allowed/preserved;
machine actionable/review queue = **78**. Из них `OPEN_CONFIRMED = 0`, `OPEN_REVIEW = 76`,
`REVIEW_REQUIRED = 2`. В `backend/app` и `frontend/src` actionable entries = `0`.
Очередь 78 не объявляется 78 доказанными заменами; она предназначена для построчного burn-down
цикла 1701.

## Targeted validation

Выполнен один bounded pass после завершения code/structure changes: API contract PASS; active-test
surface PASS; changed-Python syntax PASS; history/directory assertions PASS; changed JSON/YAML
parse PASS. Provider-boundary pass сначала выявил только две stale baseline entries уже очищенных
generated-файлов; baseline уменьшен без новых allowlist и повторён только этот checker: PASS,
`97 files / 943 occurrences`, `business_owner_tg_id = 0`, semantic mix = 0. Inventory пересчитан
повторно только после подтверждённого исправления его historical-root classification.

## Следующий цикл

`1699 — PostgreSQL 0001 proof`. Осталось 9 циклов: `1699–1707`.


# Фактическое выполнение цикла 1699 — v173.18

Статус: **CYCLE 1699 IMPLEMENTED / EXISTING PRE-RELEASE DB PROOF REQUIRES NEXT GITHUB CI**.

## Operator Kernel и свежий GitHub CI

Operator Kernel классифицировал запрос как `ci_logs_repair_or_verification` с primary route
`ci_log_exact_failure_repair`; required reads ограничены active identity SSOT/NORM и
`0001_initial_release_schema.py`.

В GitHub run `84741557574` подтверждены 4 pytest failures при зелёных Ruff, mypy, Bandit,
Alembic upgrade head, compileall и frontend build. Исправлены все четыре причины:
active-document guard больше не требует удалённый `docs/history`; Chromium/CI mirror test
синхронизирован с фактическим неизменённым SHA канонических `ci.yml`/`canon.yml`;
protected-directories manifest пересобран после удаления history; test `tg_id` allowlist
пересчитан по текущему active tests.

## PostgreSQL 0001 proof

- Единственный active Alembic head: `0001_initial_release_schema.py`; `0002+` отсутствуют.
- Предоставленный exact-head CI v173.17 доказал clean PostgreSQL path: upgrade base → `0001`,
  48 ORM metadata tables / 49 physical schema tables с `alembic_version`, release sanity PASS.
- `_validate_release_identity_schema` усилен fail-closed проверкой: FK на `users.tg_id` = 0;
  canonical FK на `users.global_id` ожидаются в количестве 39.
- `ops/db/postgres_release_proof.py` актуализирован с revision `0001`, 49 physical tables,
  canonical `global_id` business withdrawal, `reports/generated` и version-neutral proof names.
- Добавлен real-PostgreSQL integration test повторного `0001` поверх representative pre-release
  schema drift: backfill admin `global_id`, удаление legacy owner columns, canonical identity
  runtime control, сохранение балансов и 39 FK. Второй тест проверяет fail-closed orphan provider.
- Эти два новых PostgreSQL integration tests локально не запускались по прямому правилу
  пользователя; их фактический результат должен дать следующий GitHub CI.

## Исправление ошибочного возврата `АРТЕФАКТЫ`

В v173.17 в active HEAD были ошибочно возвращены 956 устаревших документов, 43 historical code
files и 330 archived tests только потому, что старые guards/tooling ссылались на их archive paths.
Ссылки теста не являются основанием считать historical bytes необходимой active authority.

Из active HEAD удалены все возвращённые obsolete docs/code/tests и 15 stale cleanup manifests
v173.09. Сохранены только три current machine manifests: Chats, Cycles и numbered Reports.
`АРТЕФАКТЫ/` и `docs/history/` отсутствуют. Исходные bytes остаются во внешнем
`EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`.

## Identity inventory после очистки history

Current scanner: 2458 token occurrences; 2388 allowed/preserved; actionable/review queue = 70.
`OPEN_REVIEW = 68`, `REVIEW_REQUIRED = 2`, `OPEN_CONFIRMED = 0`.
В `backend/app` и `frontend/src` actionable entries = 0. Эти 70 строк не объявляются 70
доказанными заменами и предназначены для построчного burn-down цикла 1701.
Provider-boundary: 97 tracked runtime files / 943 occurrences, reduction 2;
`business_owner_tg_id = 0`, semantic mix = 0.

## Targeted validation

Без pytest/полного CI: syntax изменённых Python files PASS; PostgreSQL 0001 static contract PASS;
ORM/0001 critical-column guard PASS; active document/test surface PASS; test business-selector
violations = 0; provider boundary PASS; CI mirror SHA unchanged; protected directories exact;
единственный migration head = `0001`.

## Следующий цикл

`1700 — Test provider allowlist finalization`. Осталось 8 циклов: `1700–1707`.

## Дополнение к циклу 1699 — пользовательское решение A по историческому слою

После отдельного решения пользователя подтверждено: в `v173.17` были ошибочно возвращены ровно
**1331 historical copies** — 958 документов, 43 historical code files и 330 archived tests;
дополнительно существовал один legacy README, поэтому весь `docs/history` содержал 1332 файла.
Эти bytes не являются current SSOT/runtime и должны храниться только во внешнем
`EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`.

`docs/history` не возвращён. Active tests/registry/tooling отвязаны от его физического наличия:
новые evidence идут в `reports/generated`, audits — в `docs/audits`, Operator Kernel и control docs
используют current authority. Точечный набор сначала выявил два старых тестовых требования вернуть
`docs/history`; по прямому решению пользователя тесты исправлены и повторены только эти две проверки —
`2 passed`. Полный pytest/CI не запускался.


# Фактическое выполнение цикла 1700 — v173.19

Статус: **CYCLE 1700 IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

## Operator Kernel и GitHub CI

Operator Kernel классифицировал запрос как `ci_logs_repair_or_verification` с primary route
`ci_log_exact_failure_repair`; required reads ограничены active identity SSOT/NORM, test-layer
контрактами и текущим планом 1693–1707.

В предоставленном GitHub run `84788227731`, SHA
`85bce7e15057a1579e9c85e2a58d8ba537390339`, подтверждены три pytest failures. Ruff, mypy,
Bandit, compileall, Alembic upgrade head и frontend production build в предоставленных логах прошли.
Причины трёх failures исправлены: active-test-surface больше не требует externalized archived-test
manifest entries; `docs/testing/TEST_GUARD_MANIFEST.md` снова содержит обязательную ссылку на
`AI_ARCHIVE_LAWS.md`; PostgreSQL contract-test приведён к действующей русскоязычной engineering
policy. Полный локальный pytest/CI/frontend build не запускался.

## Test provider allowlist finalization

Фактический входной active test registry v173.18 содержал `517` зарегистрированных `tg_id`
occurrences; исторический ориентир плана был `507`. Разница подтверждённо возникла из-за
provider/schema proof строк, добавленных в PostgreSQL contract tests цикла 1699, и не является
возвратом business ownership.

Построчно удалены только transitional provider fixtures из трёх admin business-test файлов, где
Telegram provider не участвует в проверяемой семантике. Telegram auth/referral/delivery/schema,
negative guards и подтверждённый historical read-through сохранены. Итоговый registry: `450`
зарегистрированных occurrences, то есть `-67` от фактического входа и `-57` от исторического
ориентира плана. `business-service calls with tg_id = 0`; broad allowlist не добавлялся.

Один причинно связанный targeted architecture pass после завершения test-layer изменений: `8/8 PASS`.
Новые исправления всё равно требуют следующего exact-head GitHub CI.

## Реестр временных файлов

Созданы `reports/manifests/TEMPORARY_FILES_REGISTRY.json`,
`docs/NORM/TEMPORARY_FILES_LIFECYCLE_NORM.md`, `ops/reports/manage_temporary_files.py` и
architecture guard. Алгоритм: scan → classify → preview → delete reproducible junk; промежуточное
evidence сначала архивировать во внешний history ZIP/карантин и проверить целостность;
неоднозначный `REVIEW` всегда требует решения пользователя; после очистки записывается receipt.
Корневой `АРТЕФАКТЫ/` в active HEAD автоматически не создаётся.

## Identity inventory

После исключения только transient Operator Kernel capsule из active identity inventory: `2392` token
occurrences; `2323` allowed/preserved; `69` actionable/review (`OPEN_REVIEW=67`,
`REVIEW_REQUIRED=2`, `OPEN_CONFIRMED=0`). Эти 69 строк не объявляются 69 заменами: их
построчная квалификация относится к циклу 1701. В `backend/app` и `frontend/src` подтверждённых
actionable business-owner строк нет. Provider runtime baseline в цикле 1700 не изменялся.

## Следующий цикл

`1701 — Identity inventory burn-down`. Осталось 7 циклов: `1701–1707`.
