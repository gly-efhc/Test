# Work Cycle 1593 — user identity audit and architecture guard

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.
Archive target: `v171.90`.

## Scope

Cycle 1593 is the renumbered former planning cycle `0`.
It does not change the database schema or runtime ownership.

The completed scope is:

- repeat the `global_id` inventory from the exact v171.89 tree;
- remove local `0-15` labels from project cycle numbering;
- establish `user_id` and `global_id` architecture SSOT;
- add an explicit Telegram-specific allowlist;
- freeze the current legacy identifier surface as a maximum baseline;
- add a CI guard against new domain `global_id` usage;
- add a read-only reconciliation collector;
- add an exact Operator Kernel route for this migration.

## Confirmed inventory

The preliminary audit headline values were reproduced exactly for
their stated scopes:

- `2448` exact `global_id` occurrences in `backend/app`;
- `133` backend files;
- `1498` service occurrences;
- `398` route occurrences;
- `134` CRUD occurrences;
- `116` Telegram bot occurrences;
- `89` ORM model occurrences;
- `32` ORM fields in `29` tables;
- `336` Python functions with tracked parameters;
- `54` `Depends(get_current_global_id)` applications;
- `375` frontend source occurrences in `62` files;
- `712` test occurrences in `107` files;
- `1105` documentation occurrences in `267` files.

The generated line-level matrix classifies each tracked use as:

```text
DOMAIN_OWNER
DOMAIN_ACTOR
AUTH_IDENTITY
TELEGRAM_SPECIFIC
SOURCE_EVENT
LEGACY_COMPATIBILITY
TEST_ONLY
DOCUMENTATION
```

## Preliminary material corrections

The main correction is cycle numbering:

```text
0-15 = macro phases only
1593-1600 = foundation range
1601-1700 = detailed project roadmap
```

The preliminary counts remain useful when their exact scope is kept.
They are not a permission for blind text replacement.

The current physical user model remains:

```text
users.id INTEGER primary key
users.global_id BIGINT unique and not null
```

Cycle 1593 does not pretend that the target `users.user_id` already
exists. That change belongs to cycle 1594.

## Guard behavior

The guard records:

- `21` explicit Telegram-specific files;
- `179` legacy runtime files;
- `20` files using `get_current_global_id()`;
- exact maximum identifier counts for every baseline file.

A count may decrease during migration. Any increase or new file fails.

## Reconciliation boundary

The read-only collector contains the financial and identity queries.
No PostgreSQL URL was available in the local environment, therefore:

```text
status = NOT_RUN_DB_UNAVAILABLE
```

No database values or financial reconciliation are claimed.

## Runtime and schema boundary

Cycle 1593 changes no runtime owner, balance, panel, transaction,
wallet binding, referral, role or migration.

The target `users.user_id BIGINT` column remains deferred. Cycle
1594 intentionally hardens the UserId contract and negative guards
without adding the column.

Next completed cycle:

```text
1594 — UserId contract and negative guards
```
