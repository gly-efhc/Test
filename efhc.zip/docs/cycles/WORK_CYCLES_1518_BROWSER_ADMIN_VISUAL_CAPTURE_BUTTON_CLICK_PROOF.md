# 1518 — Browser/Admin Visual Capture / Button-click Proof Execution

Status: `DONE_LOCALLY_WITH_LOCAL_BROWSER_PROOF`

Archive input: `EFHC_Bot_v170_93_cycle_1517_frontend_buttons_api_i18n_drift_audit.zip`

Expected archive output: `EFHC_Bot_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.zip`

## Why this cycle exists

Cycle 1517 closed static frontend/API/i18n drift. The remaining audit tail was
visual/browser verification. Cycle 1518 performs a factual local browser run for
admin core routes and admin hub navigation links, while keeping strict proof
boundaries.

## Closed / updated locally

- Produced local browser screenshot proof for 7 admin core routes.
- Produced local browser navigation proof for 6 admin hub links.
- Added `ops/frontend/admin_visual_button_click_proof.py` as the reusable local
  proof harness.
- Added system Chromium fallback for local Playwright e2e fixtures.
- Added e2e-only TonConnect restore-disable switch so local proof does not make
  unwanted restore network attempts.
- Hardened admin observability timeseries rendering against missing
  `series.points`.
- Hardened admin users list rendering against array-or-`items` API response
  shapes.
- Added architecture guard for the visual proof report, screenshots, browser
  fallback and honest proof boundaries.

## Local proof summary

- Routes verified: `7 / 7`.
- Admin hub navigations verified: `6 / 6`.
- Screenshots directory: `reports/screenshots/admin_visual_1518/`.
- Generated proof: `reports/generated/browser_admin_visual_button_click_proof_v170_94.json`.

## Proof boundary

Verified locally:

- admin core browser visual proof;
- admin hub navigation browser DOM click proof;
- screenshot artifacts exist and are non-empty;
- targeted architecture guard.

Not claimed:

- exhaustive all-admin click proof;
- GitHub CI green;
- full pytest green;
- full frontend build green;
- live Telegram proof;
- real TonConnect proof;
- release-ready.

## Next safe cycle

`1519 — Fresh CI proof / New Audit Intake Gate`.
