# Cycle 1443 — Full linkage architecture tests and UI state guards

## Status

- Archive after cycle: `EFHC_Bot_v170_19_cycle_1443_full_linkage_architecture_tests.zip`.
- Base archive: `EFHC_Bot_v170_18_cycle_1442_openapi_rebuild_strict_contract_gate.zip`.
- Scope: close `F-007` and `F-008` locally by adding full static
  architecture linkage guards and critical frontend state guards.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- Tests removed: no.
- CI/workflows/lock files changed: no.

## What was repaired

Cycle 1443 adds an active guard layer over the full linkage class:

```text
backend route -> OpenAPI -> frontend API call -> frontend surface state
DB/raw SQL table refs -> canonical service boundary -> tests
```

The new scanner is dependency-light and does not import FastAPI runtime.
It is designed for the local archive environment where runtime dependencies
may be unavailable.

## New scanner

```text
ops/linkage/build_full_linkage_report.py
```

The scanner creates:

```text
reports/generated/full_linkage_report_v170_19.json
```

The report confirms locally:

- OpenAPI strict gate status is `ok`;
- frontend API calls have backend route coverage;
- frontend API calls have OpenAPI coverage;
- admin routes are marked/guarded in the checked-in contract;
- repaired legacy money tables are not referenced by backend runtime code;
- direct balance writes outside the canonical service boundary are absent;
- critical API-driven UI surfaces have loading/error/empty state guards.

## New guard

```text
tests/architecture/test_full_linkage_architecture_and_ui_states.py
```

The guard includes:

- `test_full_linkage_report_is_green`;
- `test_all_frontend_api_calls_have_backend_route`;
- `test_route_schema_contract_frontend_backend_match`;
- `test_admin_routes_are_marked_admin_or_guarded`;
- `test_services_do_not_use_legacy_money_table_refs`;
- `test_no_direct_balance_write_outside_canonical_service`;
- `test_user_object_routes_have_ownership_check`;
- `test_critical_frontend_api_calls_have_loading_error_empty_state`.

## User object route boundary

The only non-admin mutable `global_id` route in the checked-in OpenAPI snapshot is:

```text
POST /sync/user/{global_id}
```

It is accepted by the guard only because `sync_routes.py` contains the
ownership check:

```text
current_global_id: int = Depends(get_current_global_id)
int(global_id) != int(current_global_id)
status_code=403
```

This prevents cross-user sync mutation by path `global_id`.

## Critical UI surfaces covered

The guard covers these API-driven surfaces:

- admin bank;
- admin reports;
- admin deposits;
- admin hub;
- admin users;
- admin shop;
- withdraw;
- tasks;
- referrals;
- exchange.

For each surface the scanner checks static evidence of loading, error and
empty states.

## Validation

Local validation performed:

```text
python -m pytest tests/architecture/test_full_linkage_architecture_and_ui_states.py -q
```

Expected local result:

```text
8 passed
```

Broader local guard pack:

```text
python -m pytest \
  tests/architecture/test_full_linkage_architecture_and_ui_states.py \
  tests/architecture/test_openapi_rebuild_strict_contract_gate.py \
  tests/architecture/test_admin_wallet_reset_semantic_repair.py \
  tests/architecture/test_admin_hub_route_prefix_repair.py \
  tests/architecture/test_admin_reports_bank_ssot_repair.py \
  tests/architecture/test_deposit_watcher_wallet_ssot_repair.py \
  tests/architecture/test_admin_bank_ssot_repair.py \
  tests/architecture/test_archive_filename_hygiene.py \
  tests/architecture/test_operator_kernel_routes.py \
  tests/architecture/test_operator_kernel_config_loading.py -q
```

Expected local result:

```text
63 passed
```

## Remaining tails

Cycle 1443 does not claim release readiness.

Still required:

- cycle 1444 repeat linkage audit and HEALER tail reconciliation;
- cycle 1445 CI/log proof if fresh logs are supplied;
- live FastAPI `app.openapi()` proof in a dependency-complete environment;
- full pytest / frontend build / browser proof only after actual runs.

## Sandbox boundary

Песочница использована только как reference/navigation layer.
Runtime-код не переносился.
