# Cycle 1523 — P0 Admin Withdrawals List Regression Fix

Status: DONE LOCALLY / RELEASE GATE STILL FAIL-CLOSED.
Archive output: `EFHC_Bot_v170_99_cycle_1523_p0_admin_withdrawals_list_regression_fix.zip`.

## Goal

Close `P0-ADMIN-WITHDRAWALS-LIST-ALWAYS-EMPTY` without changing EFHC
economy, withdraw business rules, RBAC, idempotency or payout canon.

## Fixed

- Removed the erroneous `bonus_awards` legacy guard from
  `WithdrawalsService.list_withdrawals()`.
- Preserved legacy guard behavior only in `bonus_awards` functions.
- Added DB-backed runtime tests for the service list behavior.
- Added route-level tests for `GET /admin/withdrawals` and admin access.
- Added AST regression guards against future guard-scope drift.

## Validation boundary

Local architecture tests pass. DB-backed runtime tests are active but skip
in this sandbox without a Postgres test database. Fresh GitHub CI green
for the output archive is not claimed.

## Release status

`P0_WITHDRAWALS_LIST: CLOSED_LOCALLY`.
`RELEASE_READY: NOT_CLAIMED`.
`RELEASE_GATE: FAIL_CLOSED_UNTIL_LIVE_PROOF`.
