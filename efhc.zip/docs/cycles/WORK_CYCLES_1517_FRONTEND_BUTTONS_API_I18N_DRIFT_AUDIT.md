# 1517 — Frontend Buttons / API / i18n Drift Audit

Status: `DONE_LOCALLY`

Archive input: `EFHC_Bot_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.zip`

Expected archive output: `EFHC_Bot_v170_93_cycle_1517_frontend_buttons_api_i18n_drift_audit.zip`

## Why this cycle exists

This cycle closes the frontend buttons/API/i18n audit tail after cycle 1516
DB drift repair. It is a static/local audit-fix cycle. Browser screenshots,
full button-click proof, live Telegram proof, live TonConnect proof and
release-ready are not claimed.

## Closed / updated locally

- Closed `P2-ADMIN-FEATURES-BYPASS-ADMIN-SEAMS`.
- `AdminHubPage` now uses `adminApiRequest()` and `adminPath()` instead of
  raw `apiRequest()` for admin routes.
- `AdminSalePackagesPage` now uses generated admin seam constants and
  `adminPath()` for templated package routes.
- `AdminLogsEventsDashboardRuntime` now uses `ADMIN_LOGS_TRANSFERS_PATH` and
  `adminApiRequest()`.
- `AdminObservabilityTimeseriesDashboardRuntime` now uses `adminApiRequest()`.
- Closed `P2-I18N-NODE-AUDIT-SCRIPTS-BROKEN-DIRNAME` by fixing two Node i18n
  audit scripts to use `__dirname`.
- Added a new architecture guard for admin seam scope, static href sanity and
  i18n Node audit execution.
- Updated stale architecture tests that expected legacy raw admin route strings.
- Applied `npm audit fix --ignore-scripts`; `form-data` is now `4.0.6` in
  `frontend/package-lock.json` and `npm audit --audit-level=high` is clean.

## Proof boundary

Verified locally:

- `ruff check .`
- targeted frontend/API/i18n architecture tests
- i18n locale parity and Node i18n audit scripts
- `npm audit --audit-level=high`
- `npm run typecheck`
- `bandit -r backend/app -q -f txt`
- `compileall backend ops scripts tests`

Not claimed:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- browser screenshots;
- full UI button-click proof;
- live Telegram proof;
- real TonConnect proof;
- release-ready.

## Next safe cycle

`1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.
