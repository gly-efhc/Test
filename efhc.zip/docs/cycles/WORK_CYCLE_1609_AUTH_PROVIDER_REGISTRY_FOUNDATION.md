# Рабочий цикл 1609 — фундамент реестра auth providers

Статус: `ЗАВЕРШЁН ЛОКАЛЬНО`.
Версия: `v172.06`.

## 1. Цель

Создать provider-neutral фундамент авторизации без изменения схемы
данных и владельца предметной области. Новый provider должен
подключаться через единый registry, а неизвестный или выключенный
provider обязан завершаться fail closed.

## 2. Реализованный фундамент

### 2.1. AuthProvider

Создан строгий перечислимый тип `AuthProvider` с exact ASCII wire
значениями, закреплёнными действующим identity SSOT. Пустые значения,
неизвестные имена, регистр, пробелы и Unicode confusables отклоняются.
Provider identifier не содержит `global_id` и не является owner.

### 2.2. VerifiedIdentity

Создан неизменяемый `VerifiedIdentity`. Его может создать только
внутренняя factory registry после успешной provider-specific
verification. Объект содержит только provider и проверенный subject.
Он не содержит `global_id`, raw proof, token, Telegram initData,
пользователя, session или сведения для автоматического merge.

`repr` скрывает provider subject. Общий boundary проверяет только
безопасный формат, а нормализация subject остаётся обязанностью
конкретного adapter.

### 2.3. Provider registry

Создан единый `AuthProviderRegistry` с регистрацией adapter factory,
capabilities, состоянием enabled или disabled и признаком test-only.
Registry запрещает повторную регистрацию, конфликт canonical name и
включённый provider без adapter. Lookup неизвестного, отключённого или
неподдерживающего capability provider завершается стабильной ошибкой.

Все девять production providers зарегистрированы как reserved и
`disabled`. Telegram не является обязательным root provider.

### 2.4. Feature flags

Добавлены раздельные настройки `AUTH_PROVIDER_FLAGS` и
`AUTH_PROVIDER_TEST_FLAGS`. Отсутствующий flag означает deny.
Test flags применяются только в `ENV=ci`. Mock provider запрещён в
local, dev, stage и prod, даже если его пытаются включить явно.

### 2.5. Ошибки и mock proof

Создан единый набор безопасных machine error codes с русскими
сообщениями. Сообщения не включают raw credentials, proof, token или
provider subject.

Test-only mock adapter подключается через тот же registry contract и
возвращает `VerifiedIdentity` только после явного test verification.
Он не импортирует domain services, не создаёт account или session и не
обращается к базе данных.

## 3. Operator Kernel

Добавлен exact primary route
`auth_provider_registry_foundation`. Классификатор распознаёт цикл
1609, `AuthProvider`, `VerifiedIdentity` и provider registry. Route
ограничивает изменения identity/auth foundation и прямо запрещает
DDL, backfill, read switch, ownership, finance и GitHub CI.

Устранён дефект исходного HEAD: ранее цикл 1609 попадал в общий
fallback, потому что точный route отсутствовал.

## 4. Release и retention

Release builder приведён к установленному production-составу: tests,
CI profile, test requirements и test tooling больше не пакуются в
release ZIP. Development-side contract и portability gate проверяют
это fail closed.

Retention-policy перенесла 35 оставшихся runtime evidence файлов цикла
1607 из development HEAD в matrix/technical archive с фиксацией пути,
размера и SHA-256. Код, tests, SSOT/NORM и итоговые summaries не
удалялись.

## 5. Что не изменялось

- Alembic revisions и head `0002`;
- PostgreSQL schema и data;
- `users`, domain FK и account ownership;
- historical backfill, dual-write и shadow/read switch;
- `IdentityResolver` и runtime `AuthContext`;
- auth challenges, sessions и roles;
- TON Proof и Telegram login;
- создание пользователей и присвоение `global_id`;
- auto-merge;
- балансы, kWh, панели, транзакции и экономические формулы;
- GitHub Actions и GitHub CI.

## 6. Exit gate

Exit gate выполнен локально:

```text
Mock provider подключается без domain changes.
Unsupported provider завершается fail closed.
```

Реальный PostgreSQL `PG-0` остаётся
`BLOCKED_BY_ENVIRONMENT`. Статус production readiness:

```text
LOCAL_PROVIDER_REGISTRY_READY
PG-0_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## 7. Следующий цикл

Следующий обязательный цикл:

```text
1610 — AuthContext contracts, resolver interfaces и
security/redaction skeleton без DDL
```

После завершения цикла 1609 остаётся 23 обязательных цикла:
`1610–1632`. Команда `запусти тесты CI GitHub` пока не требуется.
