# Detailed Work Plan — Cycles 1191-1195

This document expands the active road-integrity proof block after
cycle 1190. It does not close future cycles by itself. A cycle is closed
only after its evidence artifact, audit note and report entry exist.

## Scope boundary

The block continues the proof-first approach. No legacy route is deleted
only because it looks old. The goal is to prove roads, classify gaps and
record safe next actions.

## Cycle 1191 — deposit and watcher truth road proof

Goal:
- prove the deposit route, payment intent creation, TonConnect payload,
  watcher confirmation, TON log and internal EFHC credit path;
- record whether the chain has static anchors from route to table.

Expected artifacts:
- `ops/routes/prove_deposit_watcher_road.py`;
- `reports/generated/deposit_watcher_road_proof_1191.json`;
- `docs/audits/DEPOSIT_WATCHER_ROAD_PROOF_1191.md`.

## Cycle 1192 — exchange economic road proof

Goal:
- prove preview, convert, history, service exchange, available kWh
  snapshot, banking calls and migration anchors;
- keep the one-way kWh to EFHC canon visible.

Expected artifacts:
- `ops/routes/prove_exchange_road.py`;
- `reports/generated/exchange_road_proof_1192.json`;
- `docs/audits/EXCHANGE_ROAD_PROOF_1192.md`.

## Cycle 1193 — panels activation road proof

Goal:
- prove summary, active, archive and activation roads;
- verify static anchors for 100 EFHC activation, bonus-first spending,
  panel record creation and metadata-driven migration support.

Expected artifacts:
- `ops/routes/prove_panels_activation_road.py`;
- `reports/generated/panels_activation_road_proof_1193.json`;
- `docs/audits/PANELS_ACTIVATION_ROAD_PROOF_1193.md`.

## Cycle 1194 — shop payment truth road proof

Goal:
- prove shop catalog, external order, Browser-Shop intent creation,
  intent status, reconciliation and order finalization anchors;
- keep runtime contract proof as a future gate.

Expected artifacts:
- `ops/routes/prove_shop_payment_truth_road.py`;
- `reports/generated/shop_payment_truth_road_proof_1194.json`;
- `docs/audits/SHOP_PAYMENT_TRUTH_ROAD_PROOF_1194.md`.

## Cycle 1195 — helper/internal boundary proof

Goal:
- classify helper/internal roads without deleting them;
- keep helper roads separated from player-facing and release-core roads;
- identify the next safe proof gates for 1196-1200.

Expected artifacts:
- `ops/routes/prove_helper_internal_boundary.py`;
- `reports/generated/helper_internal_boundary_1195.json`;
- `docs/audits/HELPER_INTERNAL_BOUNDARY_PROOF_1195.md`.
