# Цикл 1618 — TON auth/session/logout closure

## Цель

После успешного TON Proof атомарно разрешить или создать TON account и
выдать provider-neutral server-side session. Добавить inspection/logout
endpoints и изолированный frontend transport без Telegram зависимости.

## Реализованный backend scope

- `TonAuthSessionService` объединяет account resolution и session issue в
  одной PostgreSQL-транзакции.
- `AuthSessionService.issue_in_transaction` блокирует verified identity и
  сохраняет только namespaced SHA-256 hash token.
- `GET /api/auth/session` возвращает безопасный `AuthContextResponse`.
- `POST /api/auth/logout` атомарно отзывает текущую session.
- TON Proof response возвращает credential один раз с `Cache-Control: no-store`.

## Frontend transport

- credential хранится только в `sessionStorage`;
- `Authorization: Bearer` добавляется централизованно;
- `401` удаляет локальную session fail closed;
- logout очищает local credential даже при сетевой ошибке;
- `global_id` остаётся строкой из десяти ASCII-цифр.

## PostgreSQL evidence package

Подготовлены сценарии нового TON-only login, повторного login, logout и шести
конкурентных login attempts. Реальная БД локально не запускается.

## Запреты

- migration `0006` отсутствует;
- Telegram initData adapter не переключается;
- роли и финансовые данные не меняются;
- auto-merge, backfill и ownership/read switch отсутствуют.

## Exit gate

```text
CYCLE_1618_EXACT_HEAD_CI_PASS
```
