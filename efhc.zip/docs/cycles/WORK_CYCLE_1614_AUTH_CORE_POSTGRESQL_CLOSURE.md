# Рабочий цикл 1614 — Auth-core PostgreSQL integration closure

Версия пакета: `v172.13`.

## Цель

Закрыть PostgreSQL-доказательства auth-core без расширения runtime scope:

- migration `0004` и её constraints;
- concurrent one-time challenge consumption;
- hashed session и logout/revoke;
- роли, принадлежащие `global_id`;
- concurrent role grant;
- отсутствие critical skip внутри auth-core PostgreSQL module.

## Основание

Run `82888503300` доказал реальный PostgreSQL и Alembic upgrade до
`0004`, но выявил восемь pytest failures, три Ruff и два Bandit findings.
Исправляются только подтверждённые причины.

## Границы

Alembic head остаётся `0004`; migration `0005` отсутствует. Не создаются
public endpoints, TON Proof, Telegram adapter switch, accounts или
identities. Auto-merge, backfill, read switch и финансовые изменения
запрещены.

## Exit gate

```text
0 critical skips в auth-core PostgreSQL scope.
Migrations, concurrency, logout и roles доказаны exact-HEAD CI.
```

До fresh CI допустим только статус:

```text
CYCLE_1614_INTEGRATION_CLOSURE_PACKAGE_READY
EXACT_HEAD_CI_REQUIRED
CYCLE_1615_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
