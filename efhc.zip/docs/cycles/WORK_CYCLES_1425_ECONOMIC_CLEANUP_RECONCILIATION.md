# Work cycle 1425 — Economic cleanup and reconciliation hardening

Status: DONE.
Archive output: `EFHC_Bot_v170_00_cycle_1425_economic_cleanup_reconciliation.zip`.
Input HEAD: `EFHC_Bot_v169_99_cycle_1424_withdraw_exchange_atomicity_repair.zip`.

## Goal

Close the remaining P2/P3 findings from the P0 economic audit after P0/P1
money-loss and double-operation risks were repaired in cycles `1422-1424`.

## Scope

Closed findings:

- `FIND-006`: rejected `exchange_all` zero-amount transfer-log direction;
- `FIND-007`: direct exchange function transaction-boundary safety;
- `FIND-008`: duplicate `_tx_context` in `withdraw_service.py`;
- `FIND-009`: legacy strict kWh check using stored `available_kwh` column;
- `FIND-010`: `credit_user_bonus_from_bank` accepting `meta` but not persisting
  it to the transfer log.

Added hardening:

- `INV-08` reconciliation guard reference:
  `SUM(user.main_balance + user.bonus_balance) + bank.balance = const` for
  non-emission operations.

## Repairs

### FIND-006

`exchange__all__available_kwh_to_main` now treats `available_kwh=0` as a
non-financial rejected operation:

- no `efhc_transfers_log` row is written;
- no false `direction="debit"` or `direction="credit"` is used;
- the returned result uses `reason="exchange_rejected_no_kwh"`;
- the audit payload remains in `TxResult.meta`.

### FIND-007

The cycle keeps the direct-call exchange rollback guard introduced in `1424` and
adds explicit guards proving that exchange helpers close autobegin/preflight
state before writing money.

### FIND-008

`withdraw_service.py` imports `_tx_context` from `transactions_service.py` and
no longer owns a local duplicate implementation.

### FIND-009

`exchange_kwh_to_efhc(strict_kwh_check=True)` calculates available kWh from
`total_generated_kwh` and `exchanged_kwh_total`, not from stored
`available_kwh`.

### FIND-010

`credit_user_bonus_from_bank` passes `meta=meta` into `_run_idempotent` so bonus
credit audit metadata persists with the transfer log.

## Updated files

Runtime:

- `backend/app/services/transactions_service.py`
- `backend/app/services/withdraw_service.py`

Tests:

- `tests/architecture/test_economic_risk_guards.py`

Docs / navigation:

- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `map_element.md`
- `ops/operator_kernel/cache/file_map.json`

## Guards

`tests/architecture/test_economic_risk_guards.py` now additionally protects:

- `test_exchange_all_zero_available_log_direction_correct`
- `test_exchange_partial_called_with_open_transaction_safe`
- `test_withdraw_service_no_local_tx_context_copy`
- `test_exchange_kwh_strict_uses_ssot_calculation_not_column`
- `test_credit_bonus_meta_written_to_log`
- `test_reconciliation_sum_invariant_after_all_ops`

## Sandbox use

Песочница использована только как reference/navigation layer. Runtime-код не
переносился.

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, full npm build,
release-ready status, browser screenshots, live Telegram proof or real wallet
proof.
