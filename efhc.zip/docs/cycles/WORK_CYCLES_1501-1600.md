# EFHC — ЦИКЛЫ 1501–1600
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Current range update — v171.73 / cycle 1578

EFHC now supports sequential production updates from complete release archives. The updater verifies both checksum layers, safely stages the target version, executes its own deployment and switches the active symlink only after healthchecks. Compatible application rollback is preserved without implicit database restoration.

Next permitted changed archive after v171.73: `EFHC_Bot_v171_74.zip`.

Historical entries below preserve prior states and do not override the current v171.73 section.

---

# Current range update — v171.70 / cycle 1578

The clean-first-boot release candidate is locally complete. Runtime migrations are document-independent; an empty PostgreSQL instance is prepared through Alembic, exact 44-table validation and idempotent initial data. Docker Compose now orders `db → migrate → backend + scheduler → frontend → proxy`, with one canonical deploy command.

The remaining acceptance boundary requires a Docker-enabled Ubuntu 24.04 VPS: no-cache image build, empty-volume first deploy, repeated deploy, healthchecks, live Telegram/TON and cross-provider restore. None of those external results is claimed locally.

Next permitted changed archive after v171.70: `EFHC_Bot_v171_71.zip`.

Historical entries below preserve prior states and do not override the current v171.70 section.

---

# Current range update — v171.68 / cycle 1578

All locally executable work for cycles 1574–1578 is complete. The provider-independent release candidate includes production Dockerfiles, universal Docker Compose, standard PostgreSQL migrations and recovery, Caddy HTTPS, domain/webhook migration, off-site backup support, a local 99-percent gate and a separate minimal production archive.

The remaining route is live technical deployment and verification. No live VPS, DNS/HTTPS, Telegram client, TonProof, transaction settlement or second-provider restore is claimed.

Next permitted changed archive after v171.68: `EFHC_Bot_v171_69.zip`.

Historical entries below preserve prior states and do not override the current v171.68 section.

---

# Current range update — v171.67 / cycle 1574

The exact failures from `logs_81507543006.zip` were repaired locally. The 58 previously failing pytest nodes pass, the strict 72-character guard has zero violations, the missing Profile settings SVG constants are restored and the three Ruff source defects are corrected.

Cycle 1574 remains active. Fresh exact-HEAD GitHub CI is still required for the authoritative Ruff, PostgreSQL-backed pytest and production Next.js build verdicts. External Telegram/TON proof remains deferred and unverified.

Next permitted archive after v171.67: `EFHC_Bot_v171_68.zip`.

Historical entries below preserve prior states and do not override the current v171.67 section.

---

# Current range update — v171.66 / cycle 1574

The WalletProvider/native-adapter architecture slice of cycle 1574 is locally implemented. TonConnect is now one adapter behind an EFHC-owned contract; Wallet in Telegram and Native Gram Wallet have separate fail-closed adapter boundaries.

Cycle 1574 remains active for remaining local release-candidate audit work. Deferred live Telegram/TonConnect/TonProof/transaction proof remains unverified and cannot be converted into a release-ready claim.

Next permitted archive after v171.66: `EFHC_Bot_v171_67.zip`.

Historical entries below preserve prior states and do not override the current v171.66 section.

---

# Current range update — v171.65 / cycle 1574

Cycle 1573 local scope is complete. Its live Telegram, TonConnect, TonProof and real transaction checks are explicitly `DEFERRED_POST_RELEASE_BY_USER` and remain unverified.

Cycle 1574 is now active for the bounded local release-candidate audit. The audit may continue all locally executable checks and repairs, but it must not convert deferred evidence into a verified or release-ready claim.

Next permitted archive after v171.65: `EFHC_Bot_v171_66.zip`.

Historical entries below preserve prior states and do not override the current v171.65 section.

---

# Current range update — v171.59 / cycle 1573

Cycle 1573 remains active. v171.59 is a corrective development snapshot with fresh browser-captured component/page proof and restored access to the full settings modal.

The release sequence remains unchanged:

- close live Telegram;
- close real TonConnect;
- close real TonProof;
- close real transaction contour;
- only then start cycle 1574 final release-candidate audit.

Next permitted archive after v171.59: `EFHC_Bot_v171_60.zip`.
---

# Current range update — v171.57 / cycle 1573

Cycle 1573 remains active. v171.57 adds a fail-closed live contour evidence gate and records the current blocker: missing factual proof for live Telegram, real TonConnect, real TonProof and real transaction contours.

No cycle 1574 work may start until all four live contours are verified. The next permitted archive after v171.57 is `EFHC_Bot_v171_58.zip`.
---

# Current authoritative range state — v171.56 / cycle 1573 active

- Completed cycles: `72 / 100`.
- Cycle `1572` is complete by green user-run logs.
- Cycle `1573` remains active.
- UI refinement is complete for the current requested header/profile slice, but live proof remains open.
- No cycle advancement is permitted without live Telegram, real TonConnect, real TonProof and real transaction evidence.
- Cycle `1574` has not started.
- Next archive after `v171.56`: `v171.57`.
---

# Authoritative release route after cycle 1562

Current output target: `EFHC_Bot_v171_44.zip`.

| Cycle | Required scenario result | State |
|---:|---|---|
| 1560 | HUB and Direct Deposit | CORRECTED IN 1561 |
| 1561 | Funding repair, Withdraw and Energy proof | DONE LOCALLY; OPERATOR VISUAL OPEN |
| 1562 | Browser Shop checkout and account linking | DONE LOCALLY |
| 1563 | TonConnect restore, TonProof and transaction UX | DONE LOCALLY |
| 1564 | Full Admin Panel MVP | DONE LOCALLY |
| 1565 | Complete UI-to-DB linkage and DTO parity | DONE LOCALLY |
| 1566 | PostgreSQL atomicity, concurrency and restore | DONE LOCALLY |
| 1567 | Security, privacy, legal and abuse hardening | DONE LOCALLY |
| 1568 | Observability, deployment and rollback | DONE LOCALLY |
| 1569 | PWA, Telegram WebView, devices and WCAG | DONE LOCALLY |
| 1570 | Public/admin visual and recovery matrix | done locally |
| 1571 | Full regression and workflow normalization | planned |
| 1572 | Fresh GitHub CI repair until green | planned |
| 1573 | Live Telegram and real transaction proof | planned |
| 1574 | Final 99-percent release-candidate audit | planned |

Current range status after cycle 1568: `68 / 100` done and `32 / 100`
remaining.

---

# Authoritative release route after cycle 1556

The live user instruction makes the release-readiness checklist the
canonical route for the remaining range.

Human plan:
`docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`

Machine plan:
`reports/generated/mvp_release_readiness_master_plan_v171_44.json`

The target is a fail-closed score of at least `99 / 100`, with every
critical checkpoint verified, no open P0 or MVP-blocking P1, fresh green
GitHub CI for the exact release head, live Telegram proof and a real
TonConnect transaction.

| Cycle | Required scenario result | State |
|---:|---|---|
| 1554 | Critical path, typed Energy and canonical shell | DONE |
| 1555 | Shell runtime, 13 languages and public browser proof | DONE |
| 1556 | Panels, Exchange and release-readiness master plan | DONE LOCALLY |
| 1557 | Tasks and Ads-alias complete action flow | DONE LOCALLY |
| 1558 | Referrals deep-link/bind/share and Ranks runtime | DONE LOCALLY |
| 1559 | Profile, Wallet, History, FAQ and language quality | DONE LOCALLY |
| 1560 | HUB and Direct Deposit reconciliation | DONE LOCALLY |
| 1561 | Withdraw user and operator contour | planned |
| 1562 | Browser-Shop TON-only checkout and Telegram linking | planned |
| 1563 | TonConnect manifest, restore, TonProof and transaction UX | planned |
| 1564 | Admin Panel MVP across protected sections | planned |
| 1565 | Full UI-to-DB linkage and OpenAPI/DTO parity | DONE LOCALLY |
| 1566 | PostgreSQL, atomicity, concurrency and backup/restore | DONE LOCALLY |
| 1567 | Security, privacy, legal and abuse hardening | DONE LOCALLY |
| 1568 | Observability, deployment and rollback readiness | DONE LOCALLY |
| 1569 | PWA, Telegram WebView, devices, accessibility, performance | DONE LOCALLY |
| 1570 | Public/admin interaction, visual, load and recovery matrix | done locally |
| 1571 | Full regression and GitHub workflow normalization | planned |
| 1572 | Fresh GitHub CI intake and repair until green | planned |
| 1573 | Live Telegram and real TonConnect/payment proof | planned |
| 1574 | Final 99% release-candidate audit and evidence package | planned |

The route is scenario-driven. Closely related work may be completed in
one cycle when required for a complete user path. Documentation and guards
are evidence, not substitutes for working product behavior.

Current range status after cycle 1560: `60 / 100` done and `40 / 100`
remaining.

---

# Cycle 1553 — DONE

Fresh CI archive and skills log repair completed locally.
Next safe cycle: `1554 — Fresh CI rerun / archive-skills confirmation`.

Status counters after this cycle: done `53 / 100`, left `47 / 100`.

---

## Tail note from cycle 1552

Cycle 1552 produced `v171_27` as a short-named archive purity and naming repair.
The output ZIP is `EFHC_Bot_v171_27.zip`; descriptive cycle/title text belongs inside the
archive documentation and reports.

Range status after 1552: `52 / 100` done, `48 / 100` remaining.

Next safe cycle: `1553 — Fresh CI Rerun / Archive Purity Confirmation`.

---

## Tail note from cycle 1551

Cycle 1551 produced `v171.26` as a local Agent Skills Adapter foundation-fix
archive. It fixed invalid TOML in ship commands, EFHC startup hook test drift,
broken persona links, adapter scanner coverage, public API scanner coverage for
EventSource/WebSocket, hooks fallback path and EFHC plugin metadata.

Range status after 1551: `51 / 100` done, `49 / 100` remaining.

Next safe cycle: `1552 — Fresh CI Rerun / Agent Skills Adapter Fix Follow-up`.

---

## Tail note from cycle 1550

Cycle 1550 produced `v171.25` as a local Agent Skills Adapter foundation
archive. It added EFHC-adapted root entrypoints, skills, commands, personas,
references, optional hooks, adapter docs, scanner and architecture guard. It did
not change runtime economy, wallet, TonConnect, idempotency, withdraw, DB or
money-flow logic.

Range status after 1550: `50 / 100` done, `50 / 100` remaining.

Next safe cycle: `1551 — Fresh CI Rerun / Agent Skills Adapter Follow-up`.

---

## Tail note from cycle 1549

Cycle 1549 produced `v171.24` as a local fresh-CI log repair archive after
`logs_74815399993.zip`. It repaired stale architecture guards caused by the
service/API migration gate: old tests still expected route constants and direct
API markers inside public UI pages instead of service/query seams. It also
renamed new query-seam aliases to canonical `tg_id` spelling. Runtime economy,
wallet, TonConnect, idempotency and withdraw logic were not changed.

Range status after 1549: `49 / 100` done, `51 / 100` remaining.

Next safe cycle: `1550 — Fresh CI Rerun / Service API Gate Confirmation`.

---

## Tail note from cycle 1548

Cycle 1548 produced `v171.23` as a local audit/TZ repair archive for
`tz_v171_20.md`. It implemented a strict public UI direct API migration gate,
added scanner/policy/pytest protection, introduced service/query seams for the
P0 public flows and kept the public copy firewall active. No economy, rates,
balances, wallet, TonConnect, money-flow or withdraw business logic changed.

Range status after 1548: `48 / 100` done, `52 / 100` remaining.

Next safe cycle: `1549 — Fresh CI Rerun / Service API Gate Follow-up`.

---

## Tail note from cycle 1547

Cycle 1547 produced `v171.22` as a local fresh-CI log repair archive after
`logs_74688208405.zip`. It repaired `ruff` style drift and pytest guard/copy
drift around the public-copy firewall, FAQ generated catalog and locale
manual translations. Runtime economy, wallet, TonConnect, idempotency and
withdraw logic were not changed.

Range status after 1547: `47 / 100` done, `53 / 100` remaining.

Next safe cycle: `1548 — Fresh CI Rerun / Visual Proof Runtime Follow-up`.

---

## Tail note from cycle 1546

Cycle 1546 produced `v171.21` as a local audit/TZ repair archive for
visual proof splash timing. The public/admin proof scripts now enforce
minimum `2500ms` settle timing and require `splash_visible:false`. Product UI
and money-flow were not changed. Runtime visual proof was not claimed because
sandbox did not provide a valid running frontend proof pass.

Range status after 1546: `46 / 100` done, `54 / 100` remaining.

Next safe cycle: `1547 — Fresh CI Rerun / Visual Proof Runtime Follow-up`.

---

## Tail note from cycle 1545

Cycle 1545 produced `v171.20` as a local audit/TZ repair archive for
`tz_v171_17_copy_guard.md`. It added a public-copy policy, scanner, pytest
guard, command linkage and documentation. The scanner passed after public
locale/source copy cleanup. DOM/browser visual proof was not performed in
sandbox, so release-ready and visual-ready are not claimed.

Range status after 1545: `45 / 100` done, `55 / 100` remaining.

Next safe cycle: `1546 — Fresh CI Rerun / Public Copy Proof Follow-up`.

---

## Tail note from cycle 1544

Cycle 1544 produced `v171.19` as a local repair archive for fresh
CI log `logs_74672087378.zip`. It closed the exact logged failures from ruff, mypy and
pytest without changing money-flow or economic logic. The main semantic
state after the repair: memo canon remains closed from cycle 1543, i18n
active locale count is now `1465`, and the output still requires fresh CI
rerun plus live Telegram / real TonConnect proof before release claims.

Range status after 1544: `44 / 100` done, `56 / 100` remaining.

Next safe cycle: `1545 — Fresh CI Rerun Confirmation / Live Proof Follow-up`.

---

## Tail note from cycle 1543

Cycle 1543 produced `v171.18` as a local audit/TZ repair archive for
`a_v171_17.md` and `tz_v171_17.md`. It closed the active P0 memo drift by
using `ton_memo.py` as the memo SSOT and making the watcher parse the same
canonical direct deposit memo that `/deposit/direct-open` issues. It also
closed panels activation error copy, webhook defensive commit/rollback, admin
raw error tails and raw-error guard coverage. No economy, rates, balances,
wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1544 — Fresh CI Rerun Confirmation / Live Proof Follow-up`.
Range status after 1543: `43 / 100` done, `57 / 100` remaining.

---

## Tail note from cycle 1542

Cycle 1542 produced `v171.17` as a local fresh-CI rerun guard repair archive
for `logs_74653569841.zip`. The uploaded log was red only on one stale pytest
architecture guard after flake8, ruff, mypy backend/app, bandit, compileall,
Alembic, npm ci and frontend build had passed. No economy, rates, balances,
wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1543 — Fresh CI Rerun Confirmation / Visual Proof Follow-up`.
Range status after 1542: `42 / 100` done, `58 / 100` remaining.

---

## Tail note from cycle 1541

Cycle 1541 produced `v171.16` as a local red-log repair archive for
`logs_74645134614.zip`. The uploaded log was red on `ruff` and `pytest`;
local repairs addressed the exact import-order, stale-guard, i18n, PWA,
line-length and documentation-hygiene failures. No economy, rates, balances,
wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1542 — Fresh CI Rerun Confirmation / Visual Proof Follow-up`.
Range status after 1541: `41 / 100` done, `59 / 100` remaining.

---

## Tail note from cycle 1540

Cycle 1540 produced `v171.15` as a local frontend error-noise cleanup archive using uploaded audit/TZ `v171_12`. All ten P0/P1/P2/P3 findings were repaired locally with code, i18n, route/offline fallback and architecture guards. Chat 36 was added to the canonical chat section. No economy, rates, balances, wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1541 — Fresh CI Frontend Noise Cleanup Confirmation / Visual Proof Follow-up`.
Range status after 1540: `40 / 100` done, `60 / 100` remaining.

---

## Tail note from cycle 1539

Cycle 1539 produced `v171.14` as a local fail-closed proof-gate archive.
No fresh CI log, audit or TZ was provided, so no red-log repair or live-proof
confirmation was possible. The cycle added a guard that prevents false
GitHub-CI/live Telegram/WebApp/TonConnect/release-ready claims and refreshed
the current Kernel/map/reports/manifest/operator-kernel surfaces.

Next safe cycle: `1540 — Fresh CI Evidence Intake / Live Proof Follow-up`.
Range status after 1539: `39 / 100` done, `61 / 100` remaining.

---

# Cycle 1538 completed — Fresh CI Artifact Hygiene Log Repair

Status: `38 / 100` done, `62 / 100` remaining.
Next: `1539 — Fresh CI Green Confirmation / Live Referral Proof Gate`.

---

# Cycle 1537 completed — Referral Persistence Webhook Repair

Status: `37 / 100` done, `63 / 100` remaining.
Next: `1538 — Fresh CI Rerun / Referral Persistence Confirmation`.

---

# Range status after v171.11

- Done: `36 / 100`.
- Remaining: `64 / 100`.
- Next safe cycle: `1537 — Fresh CI Rerun Confirmation / Referral Live Proof Gate`.
- Release gate remains fail-closed until live Telegram and real TonConnect
  proof are provided.

---

# Current range status after cycle 1535

- Done: `35 / 100`.
- Remaining: `65 / 100`.
- Latest output target: `v171_10`.
- Next safe cycle: `1536 — Fresh CI Rerun / Referral Live Proof Gate`.

---

# Current plan update — after cycle 1534

- Current HEAD: `v171.09`.
- Done: `34 / 100`.
- Remaining: `66 / 100`.
- Next safe cycle: `1535 — Fresh CI Rerun Confirmation / Mypy Scope Follow-up`.
- Cycle 1534 repaired fresh CI red-log hygiene drift only.

---

# Current range status update — after cycle 1533

- Current HEAD: `v171.08`.
- Last cycle: `1533 — Scheduler Notify Fix / Admin Facade Cleanup`.
- Done: `33 / 100`.
- Remaining: `67 / 100`.
- Next safe cycle: `1534 — Fresh CI Rerun / Mypy Scheduler-Facade Confirmation`.

Cycle 1533 closed scheduler notify/facade signature drift from the
v171.07 audit while keeping release gate fail-closed.

---

# Current range status update — after cycle 1532

- Current HEAD: `v171.07`.
- Last cycle: `1532 — Fresh CI Rerun / Mypy Scope Follow-up`.
- Done: `32 / 100`.
- Remaining: `68 / 100`.
- Fresh CI log `logs_74475316189.zip` was red and repaired locally.
- Next safe cycle: `1533 — Fresh CI Rerun Confirmation / Live Proof Gate`.

---

# Current range status update — after cycle 1531

- Current HEAD: `v171.06`.
- Last cycle: `1531 — Global Signature Drift Fix`.
- Done: `31 / 100`.
- Remaining: `69 / 100`.
- Next safe cycle: `1532 — Fresh CI Rerun / Mypy Scope Follow-up`.

---

# Current range status update — after cycle 1530

- Current HEAD: `v171.05`.
- Last cycle: `1530 — Fresh CI Rerun Confirmation`.
- Done: `30 / 100`.
- Remaining: `70 / 100`.
- Green GitHub CI evidence is confirmed for input HEAD `v171.04` from
  `logs_74465909794.zip`.
- Output archive `v171.05` is not itself CI-green until a fresh rerun is
  provided for `v171.05`.
- Next safe cycle: `1531 — Live Telegram / Real TonConnect Evidence Intake`.

---

## 1529 — Fresh CI Evidence Intake / Red-log Repair — DONE locally

- Current canonical output lineage: `v171_04`.
- Red log `logs_74445426759.zip` parsed.
- Non-pytest CI gates passed in the uploaded log: ruff, mypy, bandit,
  compileall, Alembic, npm ci and frontend build.
- Pytest failed on stale Kernel-anchor guards after cycle 1528 compaction:
  `24 failed, 1933 passed, 8 skipped, 2 warnings`.
- Compact Kernel compatibility anchors restored.
- Runtime, money-flow, wallet flow, TonConnect behavior, frontend runtime
  and EFHC economy were not changed.
- Output CI green and release-ready are not claimed.

Range status after 1529: `29 / 100` done, `71 / 100` remaining.

Next safe work item: `1530 — Fresh CI Rerun Confirmation / Remaining Guard
Drift Intake`.

## 1528 — Kernel / map_element compaction / test consolidation — DONE locally fail-closed

- Current canonical output lineage: `v171_03`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- Kernel/map_element current navigation was compacted without removing
  historical guard anchors.
- Only chat-docs intake tests were consolidated.
- No high-risk money, idempotency, TG_ID, wallet, withdraw runtime or security
  guards were merged.
- Runtime, money-flow, wallet flow, TonConnect behavior and EFHC economy were
  not changed.

Range status after 1528: `28 / 100` done, `72 / 100` remaining.

Next safe work item: `1529 — Fresh CI Evidence Intake / Red-log Repair`.

## 1527 — Fresh CI evidence intake / chat docs / test consolidation — DONE locally fail-closed

- Current canonical output lineage: `v171_02`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- Added `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/34.md` and `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/35.md`.
- Added proposal-only test guard consolidation candidates.
- No tests were merged, deleted, skipped or xfailed.
- Runtime, money-flow, wallet flow, TonConnect behavior and EFHC economy were
  not changed.

Range status after 1527: `27 / 100` done, `73 / 100` remaining.

Next safe work item: `1528 — Kernel / map_element Compaction Pass`.

## 1526 — Fresh CI / Live Proof Gate Refresh — DONE locally fail-closed

- Current canonical output lineage: `v171_01`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- Current release gate report generated for input `v171.00` and output
  `v171.01`.
- Live Telegram and real TonConnect proof remain blocked without external
  environment evidence.
- P0 withdrawals and wallet NULL fixture guards remain active.
- Runtime, money-flow, withdraw logic, wallet logic, TonConnect behavior and
  EFHC economy were not changed.

Range status after 1526: `26 / 100` done, `74 / 100` remaining.

Next safe work item: `1528 — Kernel / map_element Compaction Pass`.

## 1523 — P0 Admin Withdrawals List Regression Fix — DONE locally

- P0 withdrawals list regression fixed locally.
- `list_withdrawals()` no longer depends on legacy `bonus_awards`.
- Runtime route/service tests and AST guard-scope tests added.
- Release gate remains fail-closed until fresh CI/live proof.

## Tail note from cycle 1522

Cycle 1522 repaired the red fresh CI rerun log `logs_74335271498.zip`
locally. The input log proved green non-pytest gates and a red pytest gate.
The repair closed line72 and stale panels route-evidence drift after generated
seam migration.

Range status after 1522: `22 / 100` done, `78 / 100` remaining.

Next safe work item: `1523 — Fresh CI rerun / external proof evidence intake`.

## Tail note from cycle 1521

Cycle 1521 added a fail-closed external proof gate for live Telegram, real
TonConnect, fresh CI and release readiness. The gate records local proof but
keeps release readiness blocked until external evidence is provided.

Range status after 1521: `21 / 100` done, `79 / 100` remaining.

Next safe work item: `1522 — Fresh CI rerun / external proof evidence intake`.

## Tail note from cycle 1519

Cycle 1519 repaired the red fresh CI log `logs_74249190312.zip` locally.
The output archive still needs a fresh CI rerun before any green CI or
release-safe claim.

Range status after 1519: `19 / 100` done, `81 / 100` remaining.

## Tail note from cycle 1517

Cycle 1517 closed the static Frontend Buttons / API / i18n drift audit tail locally:

- admin features/components are covered by the adminSeams rule;
- raw admin `apiRequest('/admin...')` is forbidden outside generated seams;
- stale guards expecting legacy raw route strings were updated to the new seam canon;
- Node i18n audit scripts run successfully with `__dirname`;
- `npm audit --audit-level=high` is clean after `frontend/package-lock.json` update.

Next safe cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.
Range status after 1517: `17 / 100` done, `83 / 100` remaining.

# WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md

**Project:** EFHC Bot  
**Range:** 1501–1600  
**Status:** ACTIVE RANGE PLAN / BACKLOG FOUNDATION  
**Created in:** cycle 1497 / v170.73  
**Mode:** post-dashboard hardening, evidence, release preparation, controlled backlog

## 0. Purpose

This document opens the next future planning range after dashboard direction
`1455–1496` was closed and audit-follow-up cycle `1497` accepted the verdict
`DIRECTION_COMPLETE_WITH_KNOWN_GAPS`.

The range `1501–1600` must not reopen the completed dashboard direction as an
unbounded visual rewrite. It is a controlled backlog/hardening/release range.

## 1. Active backlog anchors

| Anchor | Priority | Description |
|---|---:|---|
| `ui_kit_component_gap` | P2 | Reusable UI Kit wrappers were consolidated in 1497; future work may migrate inline usages to wrappers gradually. |
| `admin_domain_report_endpoints_backlog` | closed in 1503 | Five read-only admin domain report endpoints added and guarded. |
| `VIS-03` | closed in 1499 | Public withdraw history semantic balance label repair completed. |
| `browser_screenshot_proof` | P2 | Produce actual browser screenshots when environment allows capture. |
| `github_ci_rerun_proof` | P1 | Red rerun from `logs_73728142603.zip` repaired locally in 1505; fresh green rerun still required before any release-safe statement. |
| `release_audit` | P1 | Separate release audit before release-ready claim. |

## 2. First priority cycles

## 1525 — Archive Numbering Rollover Repair — DONE locally

- Canonical rollover repair after the version boundary at `v170_99`.
- Correct output lineage: `v171_00`.
- Added guard against future three-digit minor suffixes.
- Runtime, money-flow, withdraw logic, TonConnect behavior and EFHC
  economy were not changed.
- Release-ready remains not claimed.

### 1501 — Dashboard UI Kit Consolidation QA

Status: `DONE v170.77`.

Closed audit/TZ finding `CYC-1459`: `DashboardPanelAction` now
supports `onClick`, explicit `actionKind` values and contract V2.
No business logic, backend, OpenAPI, money-flow or runtime mutation
behavior was changed.

### 1502 — DASH-01 Orphan AdminInteractiveBankDashboard deletion

Status: `DONE v170.78`.

Closed audit/TZ finding `DASH-01`: the orphan deprecated admin bank
dashboard file was deleted and guarded against reimport or synthetic
`buildSeries` reintroduction.

### 1503 — DASH-02 Admin Domain Report Endpoints Foundation

Status: `DONE v170.79`.

Closed audit/TZ `DASH-02`: implemented five read-only admin
domain report endpoints with `require_admin`, statement timeout,
OpenAPI/seam sync and aggregate-only responses.

### 1504 — DASH-03 Grafana Pattern Map Completion

Status: `DONE v170.80`.

Closed audit/TZ `DASH-03`: completed the Grafana pattern map for Grid
layout, Drill-down and Empty/error states. No runtime, CSS, backend,
OpenAPI, dependency, lock file or money-flow changes.

### 1505 — GitHub CI Rerun Proof

Status: `DONE locally v170.81 with red-log repair`.

The provided GitHub CI rerun log was not green. Cycle 1505 repaired the
concrete ruff/pytest guard failures from `logs_73728142603.zip`, but it
does not claim GitHub CI green for `v170.81`. A fresh rerun is still
required before any release-safe statement.


### 1510 — Wallet Model Replacement Trace

Status: `DONE v170.86`.

Closed the audit-tail question about the deleted
`backend/app/models/wallet_models.py`. The active replacement is
`backend/app/models/wallets_models.py::WalletBinding`, with
`backend/app/lib/ton_address.py::canonicalize_ton_address` as the
canonical address helper.

### Later proof/release cycles

Browser Screenshot Proof Matrix and Release Audit Preparation remain
required before any release-safe statement. GitHub CI must be rerun again
after the 1505 repair archive.

## 3. Planned range map

| Cycle | Theme | Status |
|---:|---|---|
| 1501 | Dashboard UI Kit Consolidation QA / CYC-1459 | done v170.77 |
| 1502 | DASH-01 Orphan AdminInteractiveBankDashboard deletion | done v170.78 |
| 1503 | DASH-02 Admin Domain Report Endpoints Foundation | done v170.79 |
| 1504 | DASH-03 Grafana Pattern Map Completion | done v170.80 |
| 1505 | GitHub CI Rerun Proof | done locally v170.81; red-log repaired, green rerun still required |
| 1506 | PACK-01 Withdraw Canon Clarification | done locally |
| 1507 | PACK-02 Payment Intent Canon | planned |
| 1508 | Admin Dashboard Russian Operator Copy QA | planned |
| 1509 | Dashboard Route Link Drill-down QA | planned |
| 1510 | Dashboard Empty/Error/Stale State Matrix | planned |
| 1511 | Observability Timeseries Query QA | planned |
| 1512 | Admin Logs Safe Projection QA | planned |
| 1513 | Admin Reports Snapshot-to-Domain Bridge Plan | planned |
| 1514 | Bundle Budget CI Guard Proposal | planned |
| 1515 | TMA Mobile Width Screenshot Pass | planned |
| 1516 | Public Profile/Wallet/History UX QA | planned |
| 1517 | Withdraw UI Semantic QA | planned |
| 1518 | Deposits Exception UX QA | planned |
| 1519 | Panels Lifecycle Visual QA | planned |
| 1520 | Ranks/Leaderboard Privacy QA | planned |
| 1521 | Tasks/Referrals Operator QA | planned |
| 1522 | Exchange Dashboard Truth QA | planned |
| 1523 | System Health Incident Copy QA | planned |
| 1524 | Logs/Events Severity Taxonomy QA | planned |
| 1525 | Archive Numbering Rollover Repair | done locally v171.00 |
| 1526 | Fresh CI Rerun / Live Telegram / Real TonConnect Proof | done locally v171.01 |
| 1527 | CI evidence / chat docs / test consolidation proposal | done locally v171.02 |
| 1528 | Kernel / map_element Compaction Pass | done locally v171.03 |
| 1529 | Fresh CI Evidence Intake / Red-log Repair | planned next |
| 1530 | Dependency Audit Rerun | planned |
| 1531 | Security Regression Pass | planned |
| 1532 | Money Invariants Regression Pass | planned |
| 1533 | TG_ID Identity Boundary Reaudit | planned |
| 1534 | Idempotency Boundary Reaudit | planned |
| 1535 | Admin RBAC Surface Review | planned |
| 1536 | Public Raw Identifier Leak Audit | planned |
| 1537 | Locale Placeholder Leak Audit | planned |
| 1538 | Dashboard Accessibility Deep Pass | planned |
| 1539 | Dashboard Overflow Deep Pass | planned |
| 1540 | Dark Theme Visual Consistency QA | planned |
| 1541 | First Paint Asset Reaudit | planned |
| 1542 | Cloud Run Deployment Readiness Notes | planned |
| 1543 | Neon DB Latency Notes | planned |
| 1544 | Release Notes Draft | planned |
| 1545 | User Documentation Sync | planned |
| 1546 | Admin Operator Runbook Sync | planned |
| 1547 | Error Registry Sync | planned |
| 1548 | Healer Atlas Sync | planned |
| 1549 | Casebook Sync | planned |
| 1550 | Mid-range Audit Freeze | planned |
| 1551 | Backlog Triage A | planned |
| 1552 | Backlog Triage B | planned |
| 1553 | Backlog Triage C | planned |
| 1554 | QA Debt Burn-down A | planned |
| 1555 | QA Debt Burn-down B | planned |
| 1556 | QA Debt Burn-down C | planned |
| 1557 | Admin Domain Reports Users | planned |
| 1558 | Admin Domain Reports Bank | planned |
| 1559 | Admin Domain Reports Panels | planned |
| 1560 | Admin Domain Reports Withdrawals | planned |
| 1561 | Admin Domain Reports Deposits | planned |
| 1562 | Reports UI Integration Plan | planned |
| 1563 | Reports UI Integration Pass A | planned |
| 1564 | Reports UI Integration Pass B | planned |
| 1565 | Reports QA Pass | planned |
| 1566 | Screenshot Proof Expansion | planned |
| 1567 | Browser Automation Stabilization | planned |
| 1568 | CI Performance Notes | planned |
| 1569 | Test Runtime Optimization Plan | planned |
| 1570 | Test Runtime Optimization Pass | planned |
| 1571 | Public Dashboard Copy Polish | planned |
| 1572 | Admin Dashboard Copy Polish | planned |
| 1573 | i18n Semantic QA Wave A | planned |
| 1574 | i18n Semantic QA Wave B | planned |
| 1575 | i18n Semantic QA Wave C | planned |
| 1576 | UX Linkage Audit | planned |
| 1577 | Backend ↔ Frontend Linkage Audit | planned |
| 1578 | Migration Drift Audit | planned |
| 1579 | OpenAPI Strict Gate Reaudit | planned |
| 1580 | Security Audit Mini-pass | planned |
| 1581 | Economic Invariants Mini-pass | planned |
| 1582 | Wallet/TonConnect QA | planned |
| 1583 | Deposits/Withdrawals Money Path QA | planned |
| 1584 | Admin Evidence Pack | planned |
| 1585 | Public Evidence Pack | planned |
| 1586 | Release Candidate Checklist | planned |
| 1587 | Referral runtime/API TZ audit | done locally |
| 1588 | Exact-HEAD evidence gate repair | done locally |
| 1589 | Release Candidate Repair C | planned |
| 1590 | Final Green CI Proof | planned |
| 1591 | Final Browser Screenshot Proof | planned |
| 1592 | Final Security Proof | planned |
| 1593 | Final Economic Proof | planned |
| 1594 | Final Linkage Proof | planned |
| 1595 | Final Documentation Proof | planned |
| 1596 | Release Audit | planned |
| 1597 | Release Handoff | planned |
| 1598 | Post-release Watch Plan | planned |
| 1599 | Range Closure Audit | planned |
| 1600 | 1501–1600 Range Closure / Next Range Handoff | planned |

## 4. Non-negotiable rules

- Do not weaken tests.
- Do not hide failing logs.
- Do not claim release-ready without release audit.
- Do not claim browser screenshots without actual browser capture.
- Do not claim GitHub CI green without CI log proof.
- Do not reintroduce synthetic runtime analytics.
- Do not copy runtime code from Grafana or Sandbox.


## Tail note from work item 1498

The public dashboard i18n fallback issue found by CI was repaired before moving
toward the next range. Future i18n work should treat user-facing dashboards as
a 13-language surface and admin dashboards as Russian operator surfaces unless
a dedicated admin i18n effort is opened.


## Tail note from work item 1499

`VIS-03` was closed in v170.75. Future range keeps only regression QA, not the original raw balance-type repair.

## Tail note from cycle 1500

Range `1401–1500` is closed in `v170.76` at `100 / 100`. Dashboard direction
`1455–1496` remains closed/frozen at `42 / 42`. This `1501–1600` plan is now
the next controlled hardening/proof/release-preparation range.

The first safe cycle remains `1501 — Dashboard UI Kit Consolidation QA`.
Cycle `1500` did not claim GitHub CI green, full pytest green, full frontend
build green, release-ready, browser screenshot proof, live Telegram proof or
real TonConnect / wallet proof.


## Tail note from cycle 1501

Audit/TZ `docs/audits/AUDIT_TZ_REPAIR_1501_1504.md` was accepted as
the active repair sequence for cycles `1501–1504`. Cycle 1501 closed
`CYC-1459` only. Remaining audit/TZ findings are intentionally kept
for separate controlled cycles: `DASH-01` in 1502, `DASH-02` in 1503
and `DASH-03` in 1504.

## Tail note from cycle 1503

Cycle 1503 closed `DASH-02`. Cycle 1504 later closed the final
repair item, `DASH-03`.

Chat export `33.md` was added to `docs/NORM/CHATS/` as the canonical
visible chat record for cycles `1486–1499`.


## Tail note from cycle 1504

Cycle 1504 closed `DASH-03`. The audit/TZ repair block `1501–1504`
is closed locally at `4 / 4` done and `0 / 4` remaining. The next
safe cycle is `1505 — GitHub CI Rerun Proof`.


## Tail note from cycle 1505

Cycle 1505 consumed `logs_73728142603.zip`. The log was red: ruff and
pytest failed while mypy, bandit, npm ci and frontend build passed. The
root causes were repaired locally in `v170.81`, but GitHub CI green is
not claimed until a fresh rerun proves it.


## Tail note from cycle 1506

Cycle 1506 was reassigned from generic release-audit preparation to
PACK-01 withdraw canon clarification because a self-contained TZ was
provided. PACK-01 is closed locally in `v170.82` without runtime changes.

The next safe package is `1507 — PACK-02 Payment Intent Canon`. Release
audit preparation remains blocked until current canon/audit packs and a
fresh green CI proof are available.


## Tail note from cycle 1507

Cycle 1507 closed PACK-02 TON Wallet Canon / Admin Payout Canon.
Canonical TON address storage, admin payout non-treasury-access canon and
single active TonConnect wallet binding mechanism are now documented and
protected by tests.

The next safe cycle is `1508 — Payment Intent Canon`.
## 1508 — PACK-02 tails wallet canon cleanup — DONE

Closed remaining wallet canon tails: removed the legacy admin
`crypto_wallets` contour from runtime and added canonical backfill for
existing `wallet_bindings.wallet_address` values.



## Cycle 1509 status

`1509 — PACK-03 Final Cleanup and Consistency` is closed in v170.85.

Closed:

- wallet legacy naming cleanup;
- direct EFHC payment intent canon;
- watcher incoming deposit accounting canon;
- DB drift matrix;
- admin button coverage matrix;
- frontend/API/i18n consistency matrix;
- release proof status.

Remaining after 1509:

- fresh GitHub CI green proof;
- browser screenshot proof;
- release audit before any release-ready claim.


## 1511 — GitHub CI log repair — DONE v170.87

- Repaired `logs_74007805923.zip` failures.
- Input log was red; no GitHub CI green claimed for output archive.
- Next safe cycle: `1512`.

## Tail note from cycle 1512

Cycle 1512 closed two admin money-path P1 findings and added a static
AST guard so unsupported kwargs in admin money calls cannot pass
silently again.

Input log `logs_74012116642.zip` was green for v170.87, but no GitHub
CI green is claimed for v170.88 until a fresh rerun proves it.

## Tail note from cycle 1513

Cycle 1513 repaired the red input CI log root causes and completed the
adminSeams migration. Admin pages now have zero direct raw admin
`apiRequest` calls. The output archive still needs a fresh GitHub CI rerun
before any `CI_GREEN` claim.

Next safe cycle: `1514 — Admin UX QA / Visual Regression / Full Button Click Proof`.

## Tail note from work item 1515

- Cycle 1515 produced `v170.91` as a local proof/preparation archive.
- Fresh GitHub CI green remains `GITHUB_CI_NOT_VERIFIED` until a new log proves it.
- Visual/browser proof remains `VISUAL_NOT_VERIFIED`; the admin button-click matrix is prepared for cycle 1516.
- Next safe cycle: `1516 — Browser/Admin visual capture and button-click execution proof`.
- Range status after 1515: `15 / 100` done, `85 / 100` remaining.

## Tail note from cycle 1516

Cycle 1516 closed the Stage 3 DB drift audit findings locally:

- VIP/NFT TonConnect sync now resolves `wallet_bindings` before legacy `users.ton_wallet`.
- `/v1/me` stale refresh is no longer gated by `users.ton_wallet`.
- NFT/VIP batch discovery includes active wallet bindings and legacy fallback users without duplicate tg_id rows.
- `bonus_awards` is documented as legacy/dead code and guarded.
- `withdraw_requests.amount` precision is aligned to `Numeric(30,8)`.
- Deprecated `withdrawals` constraint drift is documented.

Next safe cycle: `1517 — Frontend Buttons / API / i18n Drift Audit`.
Range status after 1516: `16 / 100` done, `84 / 100` remaining.

## Tail note from cycle 1517

Cycle 1517 closed static frontend/API/i18n drift locally:

- admin components now use generated admin seams instead of direct raw admin `apiRequest` calls;
- Node i18n audit scripts run correctly;
- frontend lock audit is clean for high vulnerabilities;
- browser proof remained pending for cycle 1518.

Next safe cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.
Range status after 1517: `17 / 100` done, `83 / 100` remaining.

## Tail note from cycle 1518

Cycle 1518 completed local browser/admin visual capture and admin hub navigation proof:

- 7 admin core routes captured with screenshots;
- 6 admin hub navigations verified in a local Chromium/Playwright browser context;
- visual proof is local and bounded, not exhaustive all-admin click coverage;
- live Telegram, real TonConnect, GitHub CI and release-ready remain unclaimed.

Next safe cycle: `1519 — Fresh CI proof / New Audit Intake Gate`.
Range status after 1518: `18 / 100` done, `82 / 100` remaining.

## Tail note from cycle 1519

Cycle 1519 repaired the red CI log from `logs_74249190312.zip`.
The exact pytest/frontend gate failures were treated as red-log root
causes and repaired locally. Output GitHub CI green remains unclaimed
until a fresh rerun proves the new archive.

Range status after 1519: `19 / 100` done, `81 / 100` remaining.

## Tail note from cycle 1520

Cycle 1520 closed the frontend i18n and local visual proof tails:

- public missing i18n keys are `0`;
- all 13 locales contain `1434` keys;
- UK Russian-tail markers are `0` on the current guard;
- admin visual runtime guard passed locally for `7 / 7` routes;
- public browser proof passed locally for `11 / 11` routes;
- release/live proof remains outside this cycle.

Next safe cycle: `1521 — Live Telegram / Real TonConnect / Release Readiness Proof`.
Range status after 1520: `20 / 100` done, `80 / 100` remaining.


## Tail note from cycle 1524

Cycle 1524 repaired the red CI log from `logs_74379950976.zip`.
The log showed only two pytest failures, both caused by the cycle 1523
DB-backed withdrawals runtime test helpers using an empty string for absent
`users.ton_wallet`. The helpers now use `NULL`, matching the wallet canon and
avoiding `uq_users_ton_wallet` collisions.

Next safe cycle: `1525 — Archive Numbering Rollover Repair`.
Range status after 1524: `24 / 100` done, `76 / 100` remaining.

## Tail note from cycle 1525

Cycle 1525 repaired archive numbering rollover after the valid `v170_99`
lineage anchor. The canonical output lineage is `v171_00`. A dedicated
architecture guard now rejects non-historical three-digit minor suffixes.

Next safe cycle: `1526 — Fresh CI Rerun / Live Telegram / Real TonConnect Proof`.
Range status after 1525: `25 / 100` done, `75 / 100` remaining.

## Tail note from cycle 1571

Cycle 1571 normalized the active and mirror GitHub workflows and completed
one exact 2508-node local regression inventory. The requested Worker,
checksum, persistence, byte-aware cache, learned prefetch, Web Vitals,
compressed-budget, offline and immutable-catalog optimization package is
closed locally in v171.47.

Fresh GitHub green proof is not inferred from local parity. The next safe
work is cycle 1572: consume the user's fresh rerun log and triage remaining
release blockers without changing the protected economic or payment canon.

## Planning synchronization from v171.49 / active cycle 1572

The canonical tree was restored once into `/mnt/data/efhc_workspace` from the
verified `EFHC_Bot_v171_48.zip`. The factual implementation stop point remains
`v171.47`; `v171.48` repaired transfer and execution boundaries and did not
complete cycle 1572.

Strict remaining sequence:

- **1572 — Fresh GitHub rerun intake and residual blocker repair (ACTIVE).**
  Consume only a newly supplied rerun log, isolate the first substantive root
  cause, repair the bounded contour, run targeted checks and update current-head
  release evidence. Do not run a local copy of full CI by default.
- **1573 — Live Telegram / TonConnect / TonProof / real transaction proof (PLANNED, OPERATOR-DEPENDENT).**
  Execute only with user-controlled environments and credentials. Preserve the
  distinction between direct EFHC jetton deposit and Browser Shop checkout.
- **1574 — Final fail-closed release-candidate audit (PLANNED).**
  Reconcile all current-head P0/P1 findings, release ownership, rollback and
  sign-off evidence. A numeric target does not authorize a release claim.

Range accounting remains cycle-based: `71 / 100` completed; cycle 1572 is
active; cycles 1573–1574 are planned. Archive numbering may advance for honest
planning/documentation snapshots without falsely closing a work cycle.

---

## Источник: `WORK_CYCLES_1501_DASHBOARD_UI_KIT_CONSOLIDATION_QA.md`

# WORK CYCLE 1501 — DASHBOARD UI KIT CONSOLIDATION QA

Status: `DONE_LOCALLY`

Version: `v170.77`

Input HEAD:

`EFHC_Bot_v170_76_cycle_1500_final_range_closure.zip`

Output HEAD:

`EFHC_Bot_v170_77_cycle_1501_dashboard_ui_kit_consolidation_qa.zip`

## Goal

Close the audit/TZ finding `CYC-1459`: `DashboardPanelAction` had
only `href` navigation and no typed callback/action-kind extension.

## Result

`DashboardPanelAction` now supports safe callback actions by type:

- `onClick?: () => void`;
- `actionKind?: DashboardPanelActionKind`;
- action kinds: `nav`, `mutation-safe`, `copy`, `external`;
- contract version: `EFHC_DASHBOARD_CONTRACT_V2`.

Existing fields remain present:

- `href`;
- `disabled`;
- `danger`.

## Boundary

No runtime mutation behavior was added. Parent pages keep guards,
confirmation and idempotency. Dashboard components do not call
`apiRequest` or `mutateAsync` directly.

No backend, OpenAPI, migration, money-flow, economy, dependency, lock
file or CI/workflow change was introduced.

## Audit backlog after this cycle

The audit/TZ for cycles `1501–1504` is archived at:

`docs/audits/AUDIT_TZ_REPAIR_1501_1504.md`

Remaining planned fixes:

- `1502 — DASH-01 Orphan AdminInteractiveBankDashboard deletion`;
- `1503 — DASH-02 Admin domain report endpoints`;
- `1504 — DASH-03 Grafana pattern map completion`.

## Reference layers

Песочница использована только как reference/navigation/prototype layer.
Runtime-код не переносился.

Grafana использована только как visual-pattern/reference layer.
Runtime-код не переносился.

## Evidence

- `docs/NORM/DASHBOARD_UI_KIT_CONSOLIDATION_QA.md`
- `frontend/src/lib/dashboard/componentContract.ts`
- `docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`
- `tests/architecture/test_dashboard_component_contract.py`
- `tests/architecture/test_dashboard_ui_kit_consolidation_qa.py`
- `reports/generated/dashboard_ui_kit_consolidation_qa_v170_77.json`
- `reports/change_cycle_2026-06-12_v170_77_cycle_1501_dashboard_ui_kit_consolidation_qa.md`

## Non-claims

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshot proof;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe cycle

`1502 — DASH-01 Orphan AdminInteractiveBankDashboard deletion`.

---

## Источник: `WORK_CYCLES_1502_DASH_01_ORPHAN_BANK_DASHBOARD_DELETION.md`

# WORK CYCLE 1502 — DASH-01 ORPHAN BANK DASHBOARD DELETION

Status: `DONE_LOCALLY`

Version: `v170.78`

Input HEAD:

`EFHC_Bot_v170_77_cycle_1501_dashboard_ui_kit_consolidation_qa.zip`

Output HEAD:

`EFHC_Bot_v170_78_cycle_1502_dash_01_orphan_bank_dashboard_deletion.zip`

## Goal

Close audit/TZ finding `DASH-01`: delete the orphan deprecated
`AdminInteractiveBankDashboard.tsx` file and prevent reintroduction of
synthetic `buildSeries` admin dashboard trends.

## Result

The orphan file was deleted:

`frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`

No `frontend/src` file imports `AdminInteractiveBankDashboard`.
No admin runtime component contains `buildSeries`.

## Boundary

No backend, OpenAPI, migration, money-flow, economy, dependency, lock
file, CI/workflow or active bank dashboard runtime behavior was
changed.

The active bank dashboard remains:

`frontend/src/components/admin/AdminBankDashboardRuntime.tsx`

## Audit backlog after this cycle

Remaining planned fixes:

- `1503 — DASH-02 Admin Domain Report Endpoints Foundation`;
- `1504 — DASH-03 Grafana Pattern Map Completion`.

## Reference layers

Песочница использована только как reference/navigation/prototype layer.
Runtime-код не переносился.

Grafana использована только как visual-pattern/reference layer.
Runtime-код не переносился.

## Evidence

- `docs/NORM/ORPHAN_BANK_DASHBOARD_DELETION.md`
- `tests/architecture/test_orphan_bank_dashboard_deleted.py`
- `reports/generated/orphan_bank_dashboard_deletion_v170_78.json`
- `reports/change_cycle_2026-06-12_v170_78_cycle_1502_dash_01_orphan_bank_dashboard_deletion.md`

## Non-claims

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshot proof;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe cycle

`1503 — DASH-02 Admin Domain Report Endpoints Foundation`.

---

## Источник: `WORK_CYCLES_1503_DASH_02_ADMIN_DOMAIN_REPORT_ENDPOINTS_FOUNDATION.md`

# WORK CYCLE 1503 — DASH-02 Admin Domain Report Endpoints Foundation

Status: `DONE v170.79`

Input HEAD:
`EFHC_Bot_v170_78_cycle_1502_dash_01_orphan_bank_dashboard_deletion.zip`

Output HEAD:
`EFHC_Bot_v170_79_cycle_1503_admin_domain_report_endpoints_foundation.zip`

## Goal

Close audit/TZ finding `DASH-02` by adding five read-only admin domain
report endpoints for users, bank, panels, withdrawals and deposits.

## Done

- Added `backend/app/routes/admin_reports_routes.py`.
- Registered `admin_reports_routes` in the route aggregator.
- Rebuilt checked-in OpenAPI route-source snapshot.
- Updated generated frontend admin seams.
- Added static architecture guard for the five endpoints.
- Added `33.md` to `docs/NORM/CHATS/` and updated chat indexes.
- Updated Kernel, map, reports and test guard manifests.

## Safety

No Alembic migration, money service, existing write route, dependency,
lock file or CI/workflow was changed.

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, release
ready, browser screenshot proof, live Telegram proof or real wallet
proof.

---

## Источник: `WORK_CYCLES_1504_DASH_03_GRAFANA_PATTERN_MAP_COMPLETION.md`

# WORK CYCLE 1504 — DASH-03 Grafana Pattern Map Completion

Status: `DONE v170.80`

Input HEAD:
`EFHC_Bot_v170_79_cycle_1503_admin_domain_report_endpoints_foundation.zip`

Output HEAD:
`EFHC_Bot_v170_80_cycle_1504_grafana_pattern_map_completion.zip`

## Goal

Close audit/TZ finding `DASH-03` by completing the Grafana visual
pattern map for Grid layout, Drill-down and Empty/error states.

## Done

- Updated `docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md`.
- Added active NORM completion document.
- Added Grafana element analysis for the completion pass.
- Added architecture guard for the three missing patterns.
- Updated audit/TZ status, Kernel, map, reports and test manifests.

## Safety

No runtime component, CSS, backend route, OpenAPI snapshot, migration,
dependency, lock file, CI/workflow, economy or money-flow was changed.

## Result

The audit/TZ repair block `1501–1504` is closed locally. The next safe
cycle is `1505 — GitHub CI Rerun Proof`.

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, full
frontend build green, release-ready, browser screenshot proof, live
Telegram proof or real wallet proof.

---

## Источник: `WORK_CYCLES_1505_GITHUB_CI_RERUN_PROOF.md`

# Cycle 1505 — GitHub CI Rerun Proof

Status: done locally with log repair.
Archive: `v170.81`.
Input archive: `v170.80`.
Log source: `logs_73728142603.zip`.

## Goal

Read the GitHub CI rerun log, repair all factual failures from the log,
and update the archive without making a false green CI claim.

## Result

The input CI rerun was red. The cycle repaired the root causes locally
and prepared the next archive for a new CI rerun.

## Repaired failures

- Ruff `I001` import ordering in
  `tests/architecture/test_orphan_bank_dashboard_deleted.py`.
- Stale admin route module canon missing `admin_reports_routes.py`.
- Stale chat legacy compatibility anchor in `CHATS_INDEX.md`.
- Forbidden frontend artifact `frontend/tsconfig.tsbuildinfo`.
- Stale OpenAPI route-count marker from `125` to `130`.
- Dunder guard false positive for `_main_` in `admin_reports_routes.py`.
- Stale route inventory freeze count in `ROUTE_INVENTORY_FREEZE.md`.

## Non-claims

GitHub CI green is not claimed for `v170.81` until a fresh rerun proves
it. Release-ready is not claimed.

## Progress

- Range `1501–1600`: `5 / 100` done, `95 / 100` remaining.
- Next safe cycle: `1506 — PACK-01 Withdraw Canon Clarification` after PACK-01 TZ was provided.

---

## Источник: `WORK_CYCLES_1506_PACK_01_WITHDRAW_CANON_CLARIFICATION.md`


# Cycle 1506 — PACK-01 Withdraw Canon Clarification

Status: done locally.
Archive: `v170.82`.
Input archive: `v170.81`.
Task source: `docs/audits/EFHC_PACK_01_WITHDRAW_CANON_CORRECTED_TZ.md`.

## Goal

Close PACK-01 by documenting and guarding EFHC Bot V1 withdraw payout
canon without changing business logic.

## Implemented

- Added `docs/NORM/WITHDRAW_FLOW_NORM.md`.
- Added `docs/NORM/WITHDRAW_AUDIT_CANON.md`.
- Added `docs/NORM/AUDIT_RULES.md`.
- Added `docs/NORM/WITHDRAW_CANON_CLARIFICATION.md`.
- Extended `docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md` with V1 canon.
- Added `tests/architecture/test_withdraw_v1_payout_canon.py`.
- Updated Kernel, map, cycle plan, reports and test guard manifest.

## Protected canon

- `PENDING -> PAID` is allowed after approved admin/operator payout.
- `wallet_send_confirmed=true` is valid V1 payout signal.
- `payout_ref` is operational reference, not blockchain proof.
- Mandatory backend watcher proof is not required for every V1 `PAID`.
- Mandatory settlement FSM is not part of V1 withdraw canon.

## Non-changes

No backend business logic, money-flow, economy, OpenAPI, frontend runtime,
CI workflow, dependency, lock file or migration was changed.

## Progress

- Range `1501–1600`: `6 / 100` done, `94 / 100` remaining.
- PACK-01: closed.
- Next safe package: `PACK-02 — Payment Intent Canon`.

---

## Источник: `WORK_CYCLES_1507_PACK_02_TON_WALLET_CANON_ADMIN_PAYOUT.md`

# 1507 — PACK-02 TON Wallet Canon / Admin Payout Canon

## Goal

Close PACK-02 by fixing wallet canonical address storage, documenting
admin payout canon and removing legacy wallet binding runtime drift.

## Completed

- Added dependency-free TON address canonicalization helper.
- Wallet connect now normalizes address to canonical storage format.
- Watcher wallet lookup canonicalizes valid TON address before lookup.
- EFHC deposit wallet fallback canonicalizes valid sender address before
  lookup.
- Deleted legacy memo/bind-request `wallet_binding_service.py` runtime
  file.
- Removed the deleted legacy service from mypy file list.
- Added wallet identity, canonical address, wallet binding, admin payout
  and DB drift docs.
- Added canonical address, single wallet binding and admin payout tests.

## Safety boundaries

- Economy changed: no.
- Withdraw PACK-01 canon changed: no.
- Backend money write-flow changed: no.
- OpenAPI changed: no.
- Migration changed: no.
- CI/workflow/lock files changed: no.
- Grafana runtime copied: no.
- Sandbox runtime copied: no.

## Next

Next safe cycle: `1508 — Payment Intent Canon`.

---

## Источник: `WORK_CYCLES_1508_PACK_02_TAILS_WALLET_CANON_CLEANUP.md`

# Cycle 1508 — PACK-02 tails wallet canon cleanup

## Goal

Close two remaining PACK-02 tails:

1. Remove the active legacy admin wallet contour based on
   `efhc_core.crypto_wallets`.
2. Add an existing-database canonical backfill for old
   `wallet_bindings.wallet_address` values.

## Result

- `backend/app/services/admin/admin_wallets_service.py` was removed.
- `admin_facade.py` no longer imports or delegates to `AdminWalletsService`.
- `crypto_wallets` is marked as removed/deprecated/not active in the DB
  drift matrix.
- `0001_init.py` now contains `_backfill_wallet_bindings_canonical(conn)`.
- New guards protect both the legacy cleanup and canonical backfill.

## Safety

No EFHC economy, withdraw payout canon, admin payout canon, frontend
runtime, CI/workflow or dependency changes were made.

---

## Источник: `WORK_CYCLES_1509_PACK_03_FINAL_CLEANUP_AND_CONSISTENCY.md`

# Work cycle 1509 — PACK-03 Final Cleanup and Consistency

Input HEAD: `v170.84`.

Output HEAD: `v170.85`.

Closed workstreams:

- wallet legacy names cleanup;
- direct EFHC payment intent canon;
- watcher incoming deposit accounting canon;
- full DB drift matrix;
- admin button coverage matrix;
- frontend/API/i18n consistency matrix;
- honest release proof status.

No EFHC economy change.

No PACK-01 / PACK-02 canon regression.

---

## Источник: `WORK_CYCLES_1510_WALLET_MODEL_REPLACEMENT_TRACE.md`

# Work cycle 1510 — Wallet model replacement trace

## Goal

Close the audit tail raised after removing
`backend/app/models/wallet_models.py` by documenting and guarding the exact
active replacement.

## Answer

`backend/app/models/wallet_models.py` is replaced by:

```text
backend/app/models/wallets_models.py::WalletBinding
```

The active wallet runtime uses:

```text
wallets_routes.py → tonconnect_proof_service.py → wallets_service.py
→ wallets_models.py::WalletBinding
→ ton_address.py::canonicalize_ton_address
```

## Changes

- Added `docs/NORM/WALLET_MODEL_REPLACEMENT_TRACE.md`.
- Added `tests/architecture/test_wallet_model_replacement_trace.py`.
- Updated Kernel, map, cycle docs, reports and test guard manifest.

## Boundaries

No EFHC economy changes.
No withdraw canon changes.
No admin payout canon changes.
No legacy wallet runtime restoration.
No CI/workflow/lock file changes.

---

## Источник: `WORK_CYCLES_1511_GITHUB_CI_LOG_REPAIR.md`

# Work cycle 1511 — GitHub CI log repair

## Input

- Input HEAD:
  `EFHC_Bot_v170_86_cycle_1510_wallet_model_replacement_trace.zip`.
- Input log: `logs_74007805923.zip`.

## Goal

Read the CI log first, identify the exact failures and repair root causes
without weakening tests or changing project canons.

## Findings from log

The input log was red.

Failed steps:

- ruff full;
- mypy full;
- pytest;
- gate summary.

Passing steps in the same input log:

- flake8 critical/full;
- bandit;
- compileall;
- alembic upgrade head;
- npm ci;
- frontend build.

## Repairs

- Fixed ruff import ordering in
  `backend/app/services/admin/admin_facade.py`.
- Fixed mypy `no-any-return` in:
  - `backend/app/services/watcher_service.py`;
  - `backend/app/services/wallets_service.py`.
- Updated stale TON address regression test to match PACK-02 canonical
  storage canon.
- Added `docs/NORM/GITHUB_CI_LOG_REPAIR.md`.
- Added `tests/architecture/test_github_ci_log_repair.py`.

## Boundaries

No EFHC economy change.
No PACK-01 withdraw canon change.
No PACK-02 wallet canon change.
No PACK-03 direct EFHC or watcher accounting canon change.
No CI/workflow/lock file change.
No release-ready claim.

---

## Источник: `WORK_CYCLES_1514_ADMIN_UX_QA_VISUAL_REGRESSION_CLICK_PROOF.md`

# Cycle 1514 — Admin UX QA / Visual Regression / Full Button Click Proof

Status: DONE locally in v170.90.

Input HEAD: `EFHC_Bot_v170_89_cycle_1513_fresh_ci_admin_seams_tail_closure.zip`.
Input log: `logs_74028431848.zip`.

## Closed in this cycle

- Repaired red pytest root causes from the input log.
- Added `AdminNotification` ORM model for the `efhc_admin.admin_notifications`
  table used by `AdminNotifier`.
- Fixed outcome delivery JSONB path binding.
- Removed top-level bot import from `tasks_service.py`.
- Updated stale architecture tests for adminSeams strict mode.
- Kept admin raw `apiRequest("/admin...")` usage at zero.
- Preserved P3 orphan route status as documented legacy/internal.

## Proof status

- Local targeted architecture/admin pack: passed.
- Local compileall: passed.
- Local npm typecheck: passed.
- Local frontend build: not claimed as green because the command did not
  return inside the sandbox timeout, although the log reached successful
  route generation.
- Fresh GitHub CI for the output archive: not verified.
- Browser visual/button click proof: not verified.

## Next safe cycle

1515 — Fresh GitHub CI rerun proof for v170.90 / visual proof preparation.

---

## Источник: `WORK_CYCLES_1515_FRESH_CI_RERUN_VISUAL_PREP.md`

# Work cycle 1515 — Fresh GitHub CI rerun proof / Visual proof preparation

## Input

- Input HEAD: `EFHC_Bot_v170_90_cycle_1514_admin_ux_qa_visual_regression_click_proof.zip`.
- Input logs: no new `logs_*.zip` was provided in this cycle.

## Goal

Prepare the next proof pass, re-check the 1514 repaired admin/runtime tails,
run safe local validation, and keep proof claims honest until a fresh GitHub
CI rerun or browser click run is actually available.

## Result

- Added `docs/NORM/FRESH_CI_RERUN_VISUAL_PROOF_PREP.md`.
- Added `tests/architecture/test_fresh_ci_rerun_visual_prep.py`.
- Added generated proof metadata for `v170.91`.
- Prepared the admin visual/button-click matrix for the next browser pass.
- Verified that the 1514 repaired seams and runtime tails remain guarded by
  targeted tests.

## Proof status

- Local targeted pack: passed.
- Full pytest: attempted, timed out without final verdict; green not claimed.
- `ruff`: passed.
- `mypy`: passed.
- `bandit backend/app`: passed with warnings only.
- `compileall`: passed.
- `npm ci`: passed.
- `npm audit --audit-level=high`: passed, 0 vulnerabilities.
- `npm run typecheck`: passed.
- `npm run build`: passed only when constrained with `CIRCLE_NODE_TOTAL=1`.
- Local `frontend/tsconfig.tsbuildinfo` artifact from typecheck was removed before output packaging.

## Not claimed

- Fresh GitHub CI green is not claimed.
- Full pytest green is not claimed.
- Browser screenshots are not claimed.
- Full button-click proof is not claimed.
- Live Telegram proof is not claimed.
- Real TonConnect/wallet proof is not claimed.
- Release-ready is not claimed.

## Boundaries

No EFHC economy, backend money write-flow, OpenAPI, migration, CI/workflow,
dependency or lock-file changes were made.

Песочница использована только как reference/navigation/prototype layer. Runtime-код не переносился.

Grafana использована только как visual-pattern/reference layer. Runtime-код не переносился.

## Progress

- Range `1501–1600`: `15 / 100` done, `85 / 100` remaining.
- Dashboard direction `1455–1496`: closed `42 / 42`.
- Next safe cycle: `1516 — Browser/Admin visual capture and button-click execution proof`.

---

## Источник: `WORK_CYCLES_1516_DB_DRIFT_CLOSURE_VIP_NFT_SYNC_REPAIR.md`

# 1516 — DB Drift Closure / VIP-NFT TonConnect Sync Repair / Legacy Table Cleanup

Status: `DONE_LOCALLY`

Archive input: `EFHC_Bot_v170_91_cycle_1515_fresh_ci_rerun_visual_prep.zip`

Expected archive output: `EFHC_Bot_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.zip`

## Why this cycle exists

User clarified that the DB drift closure audit-fix task must be performed as current cycle `1516`. The previously created `1515` archive remains a local fresh-CI/visual-prep audit/preparation cycle, not the DB drift closure cycle.

## Closed / updated

- Closed `P1-VIP-NFT-SYNC-BROKEN-FOR-TONCONNECT-USERS` locally.
- `NftCheckService.get_wallet_for_user()` resolves active `wallet_bindings` first.
- `users.ton_wallet` remains legacy fallback only.
- `/v1/me` no longer gates stale VIP refresh by `users.ton_wallet`.
- Batch NFT/VIP discovery includes active `wallet_bindings` users and legacy fallback users without duplicates.
- `bonus_awards` is documented as legacy/dead code and guarded/no-op or fail-closed.
- `WithdrawRequest.amount` precision is now `Numeric(30,8)`.
- Existing-schema repair for old `withdraw_requests.amount` precision is added to `0001_init.py`.
- Deprecated `withdrawals` constraint name drift is documented as legacy cosmetic drift.

## New / changed docs

- `docs/NORM/DB_DRIFT_CLOSURE_REPORT.md`
- `docs/NORM/VIP_NFT_TONCONNECT_SYNC_CANON.md`
- `docs/NORM/BONUS_AWARDS_LEGACY_STATUS.md`
- `docs/NORM/WALLETS_TONCONNECT_SSOT.md`
- `docs/NORM/DB_DRIFT_MATRIX.md`

## New guards

- `tests/efhc_backend/nft/test_vip_nft_tonconnect_wallet_binding_sync.py`
- `tests/architecture/test_db_drift_matrix.py`

## Proof boundary

Do not claim:

- GitHub CI green;
- full pytest green unless a full run finishes with green verdict;
- browser screenshots;
- full button-click proof;
- release-ready;
- live Telegram proof;
- real TonConnect/wallet proof.

## Range status

After this cycle:

- `1501–1600`: done `16 / 100`;
- remaining: `84 / 100`;
- next safe cycle: `1517 — Frontend Buttons / API / i18n Drift Audit`.

---

## Источник: `WORK_CYCLES_1517_FRONTEND_BUTTONS_API_I18N_DRIFT_AUDIT.md`

# 1517 — Frontend Buttons / API / i18n Drift Audit

Status: `DONE_LOCALLY`

Archive input: `EFHC_Bot_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.zip`

Expected archive output: `EFHC_Bot_v170_93_cycle_1517_frontend_buttons_api_i18n_drift_audit.zip`

## Why this cycle exists

This cycle closes the frontend buttons/API/i18n audit tail after cycle 1516
DB drift repair. It is a static/local audit-fix cycle. Browser screenshots,
full button-click proof, live Telegram proof, live TonConnect proof and
release-ready are not claimed.

## Closed / updated locally

- Closed `P2-ADMIN-FEATURES-BYPASS-ADMIN-SEAMS`.
- `AdminHubPage` now uses `adminApiRequest()` and `adminPath()` instead of
  raw `apiRequest()` for admin routes.
- `AdminSalePackagesPage` now uses generated admin seam constants and
  `adminPath()` for templated package routes.
- `AdminLogsEventsDashboardRuntime` now uses `ADMIN_LOGS_TRANSFERS_PATH` and
  `adminApiRequest()`.
- `AdminObservabilityTimeseriesDashboardRuntime` now uses `adminApiRequest()`.
- Closed `P2-I18N-NODE-AUDIT-SCRIPTS-BROKEN-DIRNAME` by fixing two Node i18n
  audit scripts to use `__dirname`.
- Added a new architecture guard for admin seam scope, static href sanity and
  i18n Node audit execution.
- Updated stale architecture tests that expected legacy raw admin route strings.
- Applied `npm audit fix --ignore-scripts`; `form-data` is now `4.0.6` in
  `frontend/package-lock.json` and `npm audit --audit-level=high` is clean.

## Proof boundary

Verified locally:

- `ruff check .`
- targeted frontend/API/i18n architecture tests
- i18n locale parity and Node i18n audit scripts
- `npm audit --audit-level=high`
- `npm run typecheck`
- `bandit -r backend/app -q -f txt`
- `compileall backend ops scripts tests`

Not claimed:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- browser screenshots;
- full UI button-click proof;
- live Telegram proof;
- real TonConnect proof;
- release-ready.

## Next safe cycle

`1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.

---

## Источник: `WORK_CYCLES_1518_BROWSER_ADMIN_VISUAL_CAPTURE_BUTTON_CLICK_PROOF.md`

# 1518 — Browser/Admin Visual Capture / Button-click Proof Execution

Status: `DONE_LOCALLY_WITH_LOCAL_BROWSER_PROOF`

Archive input: `EFHC_Bot_v170_93_cycle_1517_frontend_buttons_api_i18n_drift_audit.zip`

Expected archive output: `EFHC_Bot_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.zip`

## Why this cycle exists

Cycle 1517 closed static frontend/API/i18n drift. The remaining audit tail was
visual/browser verification. Cycle 1518 performs a factual local browser run for
admin core routes and admin hub navigation links, while keeping strict proof
boundaries.

## Closed / updated locally

- Produced local browser screenshot proof for 7 admin core routes.
- Produced local browser navigation proof for 6 admin hub links.
- Added `ops/frontend/admin_visual_button_click_proof.py` as the reusable local
  proof harness.
- Added system Chromium fallback for local Playwright e2e fixtures.
- Added e2e-only TonConnect restore-disable switch so local proof does not make
  unwanted restore network attempts.
- Hardened admin observability timeseries rendering against missing
  `series.points`.
- Hardened admin users list rendering against array-or-`items` API response
  shapes.
- Added architecture guard for the visual proof report, screenshots, browser
  fallback and honest proof boundaries.

## Local proof summary

- Routes verified: `7 / 7`.
- Admin hub navigations verified: `6 / 6`.
- Screenshots directory: `reports/screenshots/admin_visual_1518/`.
- Generated proof: `reports/generated/browser_admin_visual_button_click_proof_v170_94.json`.

## Proof boundary

Verified locally:

- admin core browser visual proof;
- admin hub navigation browser DOM click proof;
- screenshot artifacts exist and are non-empty;
- targeted architecture guard.

Not claimed:

- exhaustive all-admin click proof;
- GitHub CI green;
- full pytest green;
- full frontend build green;
- live Telegram proof;
- real TonConnect proof;
- release-ready.

## Next safe cycle

`1519 — Fresh CI proof / New Audit Intake Gate`.

---

## Источник: `WORK_CYCLES_1519_FRESH_CI_LOG_REPAIR.md`

# 1519 — Fresh CI proof / red-log repair

Status: `DONE_LOCALLY_RED_LOG_REPAIRED`

Input archive: `EFHC_Bot_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.zip`

Output archive: `EFHC_Bot_v170_95_cycle_1519_fresh_ci_log_repair.zip`

Input log: `logs_74249190312.zip`.

## What the log showed

The fresh CI log was red.

Green in the input log:

- flake8 critical;
- flake8 full report;
- ruff;
- mypy;
- bandit;
- compileall backend;
- Alembic upgrade head;
- PSQL pre-check.

Failed in the input log:

- pytest: 9 failed;
- frontend gate: forbidden internal registry marker in package lock.

## Repairs

- Removed internal registry marker from `frontend/package-lock.json`.
- Updated stale ORM table count docs from 43 to 44.
- Removed legacy `bonus_awards` guard from normal withdraw list/approve flow.
- Kept `bonus_awards` guard only around legacy bonus-award code paths.
- Reformatted new browser proof code and touched frontend line to satisfy the
  72-character source line guard.
- Removed generation-rate literals from browser proof mock data.
- Restored the Kernel navigation markers while removing numbered work-pass
  labels from root `KERNEL.md`.
- Added architecture guard for this log repair.

## Proof boundary

This is a local red-log repair. GitHub CI green for the output archive is not
claimed until the output archive is rerun by CI.

## Next safe work item

Fresh CI rerun for the output archive, or intake of the next audit package.

---

## Источник: `WORK_CYCLES_1520_FRONTEND_I18N_VISUAL_CLOSURE.md`

# 1520 — Frontend i18n Closure / Public Pages Visual Proof

Status: DONE locally.
Archive target: `v170.96`.

## Result

- Public missing i18n keys: `0`.
- Locale parity: `13 / 13`, `1434` keys each.
- UK locale Russian-tail markers: `0` on the current guard.
- Admin visual runtime guard: `7 / 7` core routes locally passed.
- Public browser proof: `11 / 11` core routes locally passed.
- TonConnect sandbox failed fetch no longer creates a red runtime screen
  during proof runs.
- Production TonConnect behavior remains enabled unless the explicit
  e2e/proof env flag is set.

## Boundaries

GitHub CI green, full pytest green, live Telegram proof, real TonConnect
proof and release-ready are not claimed by this cycle.

---

## Источник: `WORK_CYCLES_1521_LIVE_TELEGRAM_REAL_TONCONNECT_RELEASE_PROOF_GATE.md`

# 1521 — Live Telegram / Real TonConnect / Release Readiness Proof Gate

Status: DONE locally as a fail-closed proof gate.
Archive target: `v170.97`.

## Result

- Local visual/i18n proof reports from `v170.96` are recorded as passed.
- Fresh GitHub CI proof for the output archive is not claimed.
- Live Telegram proof is blocked without external live URL and bot env.
- Real TonConnect proof is blocked without external wallet/live endpoint env.
- Release readiness is explicitly blocked.
- No secrets are recorded in the generated JSON report.

## Files

- `ops/release/release_readiness_proof_gate.py`
- `reports/generated/live_release_readiness_gate_v170_97.json`
- `docs/NORM/LIVE_TELEGRAM_REAL_TONCONNECT_RELEASE_PROOF_GATE.md`
- `tests/architecture/test_live_release_readiness_gate.py`

## Boundaries

This work item does not perform a real Telegram client pass and does not
perform a real TonConnect wallet transaction. Those require external operator
environment and must be handled by the next evidence cycle or by uploaded logs.

---

## Источник: `WORK_CYCLES_1522_FRESH_CI_RERUN_LOG_REPAIR.md`

# 1522 — Fresh CI rerun / external proof evidence intake log repair

Status: DONE locally as red-log repair.
Archive target: `v170.98`.

## Input

- Input HEAD: `v170.97`.
- Input log: `logs_74335271498.zip`.
- Input verdict: red because `pytest` failed.
- Non-pytest CI gates in the uploaded log passed: flake8, ruff, mypy,
  bandit, compileall, Alembic, npm ci and npm build.

## Repairs

- Fixed `line72` violations in `ops/frontend/public_visual_runtime_proof.py`.
- Restored local static evidence for canonical public panel routes without
  returning to raw public money endpoint strings.
- Updated the stale public panels route-evidence guard to generated seam
  canon: `PANELS_ACTIVATE_PATH` is expected, direct
  `apiRequest("/panels/activate"` remains forbidden.

## Proof boundary

- Targeted replay of logged pytest failures passed locally.
- Full local `pytest -q` did not receive a final verdict in sandbox because of
  timeout.
- Fresh GitHub CI green for `v170.98` is not claimed.
- Release readiness is not claimed.

## Next safe work item

`1523 — Fresh CI rerun for v170.98 / external proof evidence intake`.

---

## Источник: `WORK_CYCLES_1523_P0_ADMIN_WITHDRAWALS_LIST_REGRESSION_FIX.md`

# Cycle 1523 — P0 Admin Withdrawals List Regression Fix

Status: DONE LOCALLY / RELEASE GATE STILL FAIL-CLOSED.
Archive output: `EFHC_Bot_v170_99_cycle_1523_p0_admin_withdrawals_list_regression_fix.zip`.

## Goal

Close `P0-ADMIN-WITHDRAWALS-LIST-ALWAYS-EMPTY` without changing EFHC
economy, withdraw business rules, RBAC, idempotency or payout canon.

## Fixed

- Removed the erroneous `bonus_awards` legacy guard from
  `WithdrawalsService.list_withdrawals()`.
- Preserved legacy guard behavior only in `bonus_awards` functions.
- Added DB-backed runtime tests for the service list behavior.
- Added route-level tests for `GET /admin/withdrawals` and admin access.
- Added AST regression guards against future guard-scope drift.

## Validation boundary

Local architecture tests pass. DB-backed runtime tests are active but skip
in this sandbox without a Postgres test database. Fresh GitHub CI green
for the output archive is not claimed.

## Release status

`P0_WITHDRAWALS_LIST: CLOSED_LOCALLY`.
`RELEASE_READY: NOT_CLAIMED`.
`RELEASE_GATE: FAIL_CLOSED_UNTIL_LIVE_PROOF`.

---

## Источник: `WORK_CYCLES_1524_FRESH_CI_WITHDRAWALS_TEST_ISOLATION_REPAIR.md`

# Cycle 1524 — Fresh CI Rerun / Withdrawals Runtime Test Isolation Repair

Input archive: `EFHC_Bot_v170_99_cycle_1523_p0_admin_withdrawals_list_regression_fix.zip`

Output archive: `EFHC_Bot_v171_00_cycle_1524_fresh_ci_withdrawals_test_isolation_repair.zip`

Input log: `logs_74379950976.zip`

## Log verdict

The uploaded CI log for `v170.99` was red.

Passed in the log:

```text
ruff
mypy
bandit
compileall
Alembic upgrade head
npm ci
npm build
```

Failed in the log:

```text
pytest: 2 failed, 1938 passed, 8 skipped, 2 warnings
```

## Root cause

The new cycle 1523 DB-backed runtime test helper inserted absent legacy wallet values as an empty string:

```text
users.ton_wallet = ''
```

The real schema has:

```text
uq_users_ton_wallet
```

Therefore tests that inserted two users without a wallet failed in Postgres with a duplicate empty-string wallet value.

## Fix

Changed the test helpers to insert:

```text
users.ton_wallet = NULL
```

This preserves the wallet canon and does not change runtime money logic.

## Scope

Runtime/service code was not changed in this cycle. The P0 fix from cycle 1523 remains intact. This cycle repairs the test isolation defect exposed by fresh CI.

## Validation

Local targeted checks:

```text
pytest tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py tests/efhc_backend/admin/test_admin_withdrawals_routes_runtime.py tests/architecture/test_bonus_awards_legacy_guard_scope.py tests/architecture/test_withdraw_bonus_awards_regression_guard.py -q
# result: 8 passed, 7 skipped

pytest tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py -q
# result: 3 passed

pytest tests/architecture/test_archive_filename_hygiene.py tests/architecture/test_max_line_length_72.py tests/architecture/test_fresh_ci_rerun_log_repair.py tests/architecture/test_live_release_readiness_gate.py -q
# result: 19 passed
```

Full GitHub CI green for output archive is not claimed without a fresh rerun.

## Release status

```text
RELEASE_GATE: FAIL_CLOSED
PRODUCTION_READY: NOT_CLAIMED
RELEASE_READY: NOT_CLAIMED
LIVE_TELEGRAM: NOT_VERIFIED
REAL_TONCONNECT: NOT_VERIFIED
```

---

## Источник: `WORK_CYCLES_1525_ARCHIVE_NUMBERING_ROLLOVER_REPAIR.md`

# Cycle 1525 — Archive Numbering Rollover Repair

## Status

DONE LOCALLY / CANONICAL REISSUE.

## Input

- Input archive: local output from cycle 1524 with invalid rollover
  numbering.
- Previous valid lineage anchor: `v170_99`.
- Correct canonical output: `v171_00`.

## Problem

The previous local archive used a three-digit minor suffix after `_99`.
This violates the archive numbering canon. After `vN_99`, the next valid
archive is always `v(N+1)_00`.

## Fix

- Reissued the cycle 1524 repair under canonical version `v171_00`.
- Updated Kernel, map, reports, generated metadata and release status.
- Renamed generated reports from the invalid rollover token to
  `v171_00`.
- Added a dedicated architecture guard against future three-digit minor
  suffixes.
- Strengthened `ARCHIVE_NUMBERING_CANON.md` with a current-branch guard
  requirement.

## Non-changes

No business logic, money-flow, withdraw logic, TonConnect behavior,
backend runtime behavior or EFHC economy was changed.

## Validation

Targeted validation must include:

```text
pytest tests/architecture/test_archive_numbering_rollover_guard.py -q
pytest tests/architecture/test_archive_filename_hygiene.py -q
```

## Release boundary

This cycle does not claim GitHub CI green, live Telegram proof, real
TonConnect proof, production-ready or release-ready.

---

## Источник: `WORK_CYCLES_1526_FRESH_CI_LIVE_TONCONNECT_PROOF.md`

# Cycle 1526 — Fresh CI Rerun / Live Telegram / Real TonConnect Proof

Status: `DONE_LOCALLY_FAIL_CLOSED`.

Input HEAD: `EFHC_Bot_v171_00_cycle_1525_archive_numbering_rollover_repair.zip`.

Output archive target:
`EFHC_Bot_v171_01_cycle_1526_fresh_ci_live_tonconnect_proof.zip`.

## Goal

Run the next safe cycle after the archive numbering rollover repair. The
cycle must keep proof boundaries honest for the canonical `v171.00` HEAD:

- no `vN_100+` numbering regression;
- P0 admin withdrawals list fix remains guarded;
- withdrawals runtime fixture isolation remains guarded;
- release gate remains fail-closed without external live proof;
- live Telegram proof is not claimed without live environment evidence;
- real TonConnect proof is not claimed without wallet/live evidence.

## Input log status

No fresh `logs_*.zip` was provided for this cycle. Therefore there was no
red CI log to parse and no GitHub CI green status to claim.

## Local checks executed

```text
python scripts/ci/check_ai_archive_laws_integrity.py
# OK

pytest \
  tests/architecture/test_archive_numbering_rollover_guard.py \
  tests/architecture/test_archive_filename_hygiene.py \
  tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py \
  tests/architecture/test_bonus_awards_legacy_guard_scope.py \
  tests/architecture/test_withdraw_bonus_awards_regression_guard.py \
  tests/architecture/test_live_release_readiness_gate.py \
  tests/architecture/test_current_release_readiness_gate.py \
  tests/architecture/test_max_line_length_72.py \
  -q
# result: passed locally

PYTHONPATH=backend pytest \
  tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py \
  tests/efhc_backend/admin/test_admin_withdrawals_routes_runtime.py \
  -q
# result: 7 skipped locally without Postgres test DB

python -m compileall -q backend ops scripts tests
# passed locally
```

## Release gate result for this cycle

A current fail-closed gate report was generated for:

- input head: `v171.00`;
- output target: `v171.01`;
- cycle: `1526`.

The gate result is:

```text
release_readiness_status = NOT_RELEASE_READY
live_telegram_proof.status = BLOCKED_MISSING_ENV
real_tonconnect_proof.status = BLOCKED_MISSING_ENV
fresh_github_ci_proof.status = NOT_PROVIDED_FOR_V171_00
```

## Reference layers

Sandbox and Grafana reference archives were integrity-checked only. No runtime
code, lock file, CI file, wallet logic, economy, dependency or Grafana code was
copied into EFHC Bot.

## Boundaries

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- browser screenshot proof;
- full button-click proof;
- live Telegram proof;
- real TonConnect proof;
- production-ready or release-ready status.

## Next safe step

Next safe cycle: `1527 — Fresh GitHub CI Evidence Intake / Red-log Repair`.
If a fresh `logs_*.zip` is provided, parse that log first and repair only
factual failures from the log.

---

## Источник: `WORK_CYCLES_1527_CI_EVIDENCE_CHAT_DOCS_TEST_CONSOLIDATION.md`

# 1527 — Fresh GitHub CI evidence intake / chat docs / test consolidation

Status: DONE locally, fail-closed.

## Input HEAD

`EFHC_Bot_v171_01_cycle_1526_fresh_ci_live_tonconnect_proof.zip`

## Output HEAD

`EFHC_Bot_v171_02_cycle_1527_ci_evidence_chat_docs_test_consolidation.zip`

## Scope

- Check fresh CI evidence intake.
- Add chat exports `34.md` and `35.md` to canonical chat docs.
- Update chat index and README.
- Propose safe test guard consolidation candidates.
- Add a guard for the new docs and proof boundaries.

## Logs

No `logs_*.zip` was provided for cycle 1527. No log repair is claimed.

## Runtime boundary

Runtime service code, money-flow, withdraw logic, wallet binding logic,
TonConnect behavior, frontend runtime and EFHC economy were not changed.

## Claims not made

- no GitHub CI green;
- no full pytest green;
- no full frontend build green;
- no live Telegram proof;
- no real TonConnect proof;
- no release-ready claim.

## Next safe cycle

`1528 — Kernel / map_element Compaction Pass`

---

## Источник: `WORK_CYCLES_1528_KERNEL_MAP_COMPACTION_TEST_CONSOLIDATION.md`

# 1528 — Kernel / map_element compaction / test consolidation

Status: DONE locally, fail-closed.

## Input HEAD

`EFHC_Bot_v171_02_cycle_1527_ci_evidence_chat_docs_test_consolidation.zip`

## Output HEAD

`EFHC_Bot_v171_03_cycle_1528_kernel_map_compaction_test_consolidation.zip`

## Scope

- Keep `KERNEL.md` compact and current.
- Add the current compact navigation section to `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
- Preserve historical `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` anchors for guard compatibility.
- Execute the safest consolidation candidate: chat docs intake guards.
- Update docs, reports, manifest and guards.

## Logs

No `logs_*.zip` was provided for cycle 1528. No log repair is claimed.

## Test consolidation

Executed only group 1 from the candidate list:

- removed `tests/architecture/test_chat_24_archive_intake.py`;
- removed `tests/architecture/test_chat_25_archive_intake.py`;
- preserved their checks inside `tests/architecture/test_chat_docs_intake.py`.

## Runtime boundary

Runtime service code, money-flow, withdraw logic, wallet binding logic,
TonConnect behavior, frontend runtime and EFHC economy were not changed.

## Claims not made

- no GitHub CI green;
- no full pytest green;
- no full frontend build green;
- no live Telegram proof;
- no real TonConnect proof;
- no release-ready claim.

## Next safe cycle

`1529 — Fresh CI Evidence Intake / Red-log Repair`

---

## Источник: `WORK_CYCLES_1529_FRESH_CI_LOG_REPAIR_KERNEL_ANCHOR_RESTORE.md`

# Cycle 1529 — Fresh CI Evidence Intake / Red-log Repair

## Status

`DONE_LOCALLY_AFTER_RED_LOG_REPAIR`.

## Input

- HEAD: `EFHC_Bot_v171_03_cycle_1528_kernel_map_compaction_test_consolidation.zip`.
- Log: `logs_74445426759.zip`.

## Output target

`EFHC_Bot_v171_04_cycle_1529_fresh_ci_log_repair_kernel_anchor_restore.zip`.

## Log verdict

The log was red at pytest gate only.

Passed in the uploaded log:

- ruff;
- mypy;
- bandit;
- compileall;
- Alembic upgrade head;
- npm ci;
- frontend build.

Failed in the uploaded log:

- pytest: `24 failed, 1933 passed, 8 skipped, 2 warnings`.

## Root cause

The compact Kernel pass in cycle 1528 removed historical navigation anchors
from `KERNEL.md`, while legacy architecture guards still required those exact
anchors in the root Kernel.

## Repair

- Restored compact compatibility anchors in `KERNEL.md`.
- Added current cycle 1529 navigation to `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
- Added route compatibility comments to `routes.yaml`.
- Added this cycle norm, report and guard.
- Updated work-cycle docs, release proof status, reports index and test guard
  manifest.

## Local replay

Targeted replay of all logged Kernel-anchor pytest failures passed locally:

`25 passed`.

The extra count is intentional: one affected file had two navigation tests
that protect the same cycle surface.

## Boundary

Runtime, money-flow, wallet-flow, withdraw logic, TonConnect behavior,
frontend runtime and EFHC economy were not changed.

## Non-claims

GitHub CI green for output archive, full pytest green, full frontend build
green, live Telegram proof, real TonConnect proof and release-ready are not
claimed.

## Next safe cycle

`1530 — Fresh CI Rerun Confirmation / Remaining Guard Drift Intake`.

---

## Источник: `WORK_CYCLES_1530_FRESH_CI_GREEN_CONFIRMATION.md`

# Cycle 1530 — Fresh CI Rerun Confirmation

## Status

`DONE_LOCALLY_WITH_GREEN_CI_EVIDENCE_FOR_INPUT_HEAD`.

## Input

- HEAD: `EFHC_Bot_v171_04_cycle_1529_fresh_ci_log_repair_kernel_anchor_restore.zip`.
- Log: `logs_74465909794.zip`.

## Output target

`EFHC_Bot_v171_05_cycle_1530_fresh_ci_green_confirmation.zip`.

## Log verdict

The uploaded GitHub CI log is green for input HEAD `v171.04`.

Passed in the uploaded log:

- flake8 critical;
- flake8 full report;
- ruff full report;
- mypy full report;
- bandit full report;
- compileall backend;
- PSQL pre-check;
- Alembic upgrade head;
- pytest;
- npm ci;
- frontend build;
- final gate summary.

Key evidence:

- `ruff`: `All checks passed!`;
- `mypy`: `Success: no issues found in 283 source files`;
- `pytest`: `1962 passed, 8 skipped, 2 warnings in 50.74s`;
- `frontend build`: compiled successfully and generated all static pages;
- gate summary: `OK: all gate steps passed.`

## Repair / intake action

No code defect was found in the green log. This cycle records the green CI
evidence, updates release proof status, Kernel, map, reports index, cycle
plan and test manifest.

## Boundary

Runtime, money-flow, wallet-flow, withdraw logic, TonConnect behavior,
frontend runtime and EFHC economy were not changed.

## Non-claims

- GitHub CI green for output archive `v171.05` is not claimed.
- Live Telegram proof is not claimed.
- Real TonConnect proof is not claimed.
- Release-ready and production-ready are not claimed.

## Next safe cycle

`1531 — Live Telegram / Real TonConnect Evidence Intake`.

---

## Источник: `WORK_CYCLES_1531_GLOBAL_SIGNATURE_DRIFT_FIX.md`

# Cycle 1531 — Global Signature Drift Fix

Input HEAD: `v171.05`.
Output HEAD: `v171.06`.

## Purpose

Apply the global audit/TZ findings against `v171.05` and close the runtime
kwarg/signature mismatch class without changing EFHC economy, money-flow,
wallet binding, withdraw business logic or frontend runtime.

## Closed locally

- `P0-PANELS-PAGINATION-CURSOR-TYPEERROR`
- `P1-SCHEDULER-ARCHIVE-PANELS-DOUBLE-TYPEERROR`
- `P1-BOT-REFERRAL-STATS-TYPEERROR`
- `P1-BOT-RANKS-DOUBLE-BUG-SILENTLY-SWALLOWED`
- `P1-NFT-ROUTES-WALLET-HAS-NFT-TYPEERROR`
- `P2-ADMIN-FORMAT-DECIMAL-KWARG-MISMATCH`
- `P1-MYPY-SCOPE-TOO-NARROW` as staged scope expansion plus architecture
  guard

## Proof boundary

Targeted local tests passed. Full pytest was attempted but timed out in the
sandbox and is not claimed. `ruff`, `mypy` and `bandit` were unavailable
locally. Fresh GitHub CI for output `v171.06` is required.

## Release status

`NOT_RELEASE_READY`. Live Telegram and real TonConnect proof remain missing.

---

## Источник: `WORK_CYCLES_1532_FRESH_CI_MYPY_SCOPE_LOG_REPAIR.md`

# Cycle 1532 — Fresh CI Rerun / Mypy Scope Follow-up

## Input

- Input HEAD: `EFHC_Bot_v171_06_cycle_1531_global_signature_drift_fix.zip`.
- Uploaded log: `logs_74475316189.zip`.

## Result

- Output HEAD: `EFHC_Bot_v171_07_cycle_1532_fresh_ci_mypy_scope_log_repair.zip`.
- Log verdict: red.
- Failed gates: ruff and pytest.
- Mypy full report passed in the uploaded log: `283 source files`.

## Closed locally

1. Ruff `I001` in three cycle 1531 runtime test files.
2. Stale exact-version assertion in the cycle 1529 Kernel-anchor guard.

## No-change boundary

Runtime, backend money-flow, wallet-flow, withdraw logic, TonConnect,
frontend runtime and EFHC economy were not changed.

## Proof boundary

- Output GitHub CI green: not claimed.
- Full pytest green for output: not claimed.
- Frontend build green for output: not claimed.
- Live Telegram proof: not claimed.
- Real TonConnect proof: not claimed.
- Release-ready: not claimed.

## Range status

- `1501–1600`: done `32 / 100`, remaining `68 / 100`.
- Next safe cycle: `1533 — Fresh CI Rerun Confirmation / Live Proof Gate`.

---

## Источник: `WORK_CYCLES_1533_SCHEDULER_NOTIFY_FACADE_FIX.md`

# Work Cycle 1533 — Scheduler Notify Fix / Admin Facade Cleanup

- Input HEAD: `v171.07`.
- Output HEAD: `v171.08`.
- Source audit: `docs/audits/a_v171.07.md`.
- Source TZ: `docs/audits/tz_v171.07.md`.

## Closed

- `P1-WITHDRAWALS-PROCESSOR-DOUBLE-BUG`: CLOSED.
- `P1-REPORTS-DAILY-NOTIFY-GENERIC`: CLOSED.
- `P2-DEAD-CODE-ADMIN-FACADE-APPROVE-WITHDRAW`: CLOSED.
- `P2-DEAD-CODE-ADMIN-FACADE-REJECT-WITHDRAW`: CLOSED.
- `P1-MYPY-SCOPE-STILL-REACTIVE`: STAGED-CLOSED for this cycle.

## Boundaries

No economy, money-flow, wallet-flow, withdraw business logic,
TonConnect or frontend runtime changes were made.

## Validation

- compileall: passed.
- targeted scheduler/facade/signature tests: passed.
- previous critical signature regression pack: passed.
- full pytest: attempted but sandbox timed out, so full pytest green is
  not claimed.
- local ruff/mypy/bandit: not available in sandbox, so green is not
  claimed.

## Next

`1534 — Fresh CI Rerun / Mypy Scheduler-Facade Confirmation`.

---

## Источник: `WORK_CYCLES_1534_FRESH_CI_HYGIENE_LOG_REPAIR.md`

# Cycle 1534 — Fresh CI Rerun / Hygiene Log Repair

Input HEAD: `EFHC_Bot_v171_08_cycle_1533_scheduler_notify_facade_fix.zip`.
Output HEAD: `EFHC_Bot_v171_09_cycle_1534_fresh_ci_hygiene_log_repair.zip`.
Uploaded log: `logs_74538464541.zip`.

## Result

The log was red on ruff and pytest. All logged root causes were repaired
locally without runtime changes.

## Repaired

1. Ruff I001 import ordering in NFT route runtime test.
2. NORM report filename hygiene drift.
3. Root Kernel numbered work-pass text drift.
4. Healer index numbered work-pass text drift.

## Not claimed

- GitHub CI green for output `v171.09`.
- Release-ready.
- Production-ready.
- Live Telegram proof.
- Real TonConnect proof.

---

## Источник: `WORK_CYCLES_1535_REFERRAL_UX_FIX.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Cycle 1535 — Referral Binding / UX Error Handling / Onboarding

HEAD input: `EFHC_Bot_v171_09_cycle_1534_fresh_ci_hygiene_log_repair.zip`.
Output target: `EFHC_Bot_v171_10_cycle_1535_referral_ux_fix.zip`.

Scope:

- close referral deeplink P0 from `a_v171_09.md`;
- close withdraw raw error toast P2;
- close exchange mutation wrong error copy P2;
- add first-run onboarding tour;
- update guards and docs without changing EFHC economics.

Local result:

- `/start ref_<code>` now calls referral attach after `ensure_user`;
- `POST /referrals/bind` binds current authenticated tg_id only;
- WebApp reads `Telegram.WebApp.initDataUnsafe.start_param`;
- withdraw toasts use public-safe messages;
- exchange mutation uses `exchange.exchange_failed`;
- onboarding is implemented as UI-only skippable tour.

Claims not made:

- GitHub CI green for output archive;
- full pytest green;
- frontend build green;
- live Telegram proof;
- real TonConnect proof;
- release-ready or production-ready.

---

## Источник: `WORK_CYCLES_1536_FRESH_CI_REFERRAL_LOG_REPAIR.md`

# Cycle 1536 — Fresh CI Referral Log Repair

## Input

- HEAD: `EFHC_Bot_v171_10_cycle_1535_referral_ux_fix.zip`
- Log: `logs_74569153381.zip`

## Log verdict

Red. Failed gates: ruff, mypy and pytest.

## Closed locally

- Ruff import ordering drift.
- Mypy start payload `no-any-return`.
- I18n manual coverage English fallback drift.
- OpenAPI route-count and frontend/backend route linkage drift.
- Public i18n count guard drift after new onboarding/exchange keys.

## Checks

- `ruff check backend api ops tests`: passed locally.
- Targeted pytest replay for OpenAPI/i18n/referral/frontend guards: passed.
- `python ops/i18n/audit_i18n_manual_coverage_consolidation.py`: passed.
- `python ops/i18n/audit_all_locale_parity.py`: passed.
- `python -m compileall -q backend ops scripts tests`: passed.
- AI Archive Laws integrity: passed.

## Not claimed

- GitHub CI green for output `v171.11`.
- Full pytest green.
- Full mypy green for output `v171.11`.
- Live Telegram proof.
- Real TonConnect proof.
- Release-ready / production-ready.

---

## Источник: `WORK_CYCLES_1537_REFERRAL_PERSISTENCE_WEBHOOK_REPAIR.md`

# Cycle 1537 — Referral Persistence / Telegram Webhook DB DI Repair

## Input

- HEAD: `EFHC_Bot_v171_11_cycle_1536_fresh_ci_referral_log_repair.zip`
- Audit: `docs/audits/a_v171_11.md`
- TZ: `docs/audits/tz_v171_11.md`

## Closed locally

- Referral attach now commits successful inserts and rolls back exceptions.
- Telegram webhook uses `process_update(db=db, payload=payload)`.
- Route persistence proof now executes route functions with transactional
  fake DB instead of source-only inspection.
- Exchange mutation uses operation-specific public fallback.
- WebApp bind session flag is retryable after request failure.

## Checks

- Targeted referral/webhook/frontend guards passed locally.
- `compileall` passed locally.
- Full CI, live Telegram and real TonConnect proof are not claimed.

---

## Источник: `WORK_CYCLES_1538_FRESH_CI_ARTIFACT_HYGIENE_LOG_REPAIR.md`

# Work cycle 1538 — Fresh CI Artifact Hygiene Log Repair

Input: `EFHC_Bot_v171_12_cycle_1537_referral_persistence_webhook_repair.zip`.
Output: `EFHC_Bot_v171_13_cycle_1538_fresh_ci_artifact_hygiene_log_repair.zip`.
Log: `logs_74600883162.zip`.

## Status

DONE locally, fail-closed. The uploaded log was red on `ruff` and
`pytest`; exact failures were repaired locally.

## Fixed

- `ruff I001` in referral bind route persistence runtime test.
- Forbidden transient artifact `frontend/tsconfig.tsbuildinfo`.
- Stale route count markers `130` after current OpenAPI route count `132`.
- Banned literal identity spelling in bot subscription middleware.

## Checks

- Targeted replay: repaired locally.
- Compileall: passed locally.
- AI Archive Laws integrity: passed locally.
- Песочница archive integrity: passed locally.

## Not claimed

GitHub CI green, full pytest green, live Telegram proof, real WebApp
`start_param` proof, real TonConnect proof, release-ready and
production-ready are not claimed for `v171.13`.

## Next

`1539 — Fresh CI Green Confirmation / Live Referral Proof Gate`.

---

## Источник: `WORK_CYCLES_1539_FRESH_CI_LIVE_REFERRAL_PROOF_GATE.md`

# Work cycle 1539 — Fresh CI / Live Referral Proof Gate

Input: `EFHC_Bot_v171_13_cycle_1538_fresh_ci_artifact_hygiene_log_repair.zip`.
Output: `EFHC_Bot_v171_14_cycle_1539_fresh_ci_live_referral_proof_gate.zip`.
New log/audit/TZ input: none.

## Status

DONE locally, fail-closed. This cycle records the absence of new external
proof evidence, refreshes the Operator Kernel documentation surface and adds a
regression guard that prevents false CI/live-proof/release overclaims.

## Work performed

- Verified input HEAD archive integrity before extraction.
- Read the mandatory Kernel, map, AI laws, cycle, guard-manifest, reports and
  healer/error-registry documents.
- Ran AI Archive Laws integrity guard locally.
- Checked the uploaded reference/prototype artifacts as reference material
  only; no runtime code was copied from them.
- Added a cycle 1539 architecture guard for the fail-closed proof boundary.
- Updated Kernel, map, cycle status, release proof status, reports index,
  guard manifest, Healer indexes, error registry and operator-kernel routing.

## Checks

- AI Archive Laws integrity: passed locally.
- Compileall: passed locally.
- Targeted pytest: `19 passed` locally.
- Operator Kernel refresh: passed locally.
- `ruff`, `mypy`, `bandit`: not available in sandbox as commands.
- `npm ci`: passed locally with `0 vulnerabilities`.
- `npm run build`: compiled successfully, then timed out during page-data collection; frontend build green is not claimed.
- Full pytest: attempted with `PYTHONPATH=backend`; timed out at 33% progress without a final verdict, so full pytest green is not claimed.

## Not claimed

GitHub CI green, full pytest green, frontend build green, live Telegram proof,
real WebApp `start_param` proof, real TonConnect proof, release-ready and
production-ready are not claimed for `v171.14`.

## Next

`1540 — Fresh CI Evidence Intake / Live Proof Follow-up`.

---

## Источник: `WORK_CYCLES_1540_FRONTEND_ERROR_NOISE_CLEANUP.md`

# Cycle 1540 — Frontend Error Noise Cleanup / v171.15

Status: DONE locally.

Input HEAD:
`EFHC_Bot_v171_14_cycle_1539_fresh_ci_live_referral_proof_gate.zip`

User-provided inputs:
- `a_v171_12.md`
- `tz_v171_12.md`
- `36.md`

Output planned archive:
`EFHC_Bot_v171_15_cycle_1540_frontend_error_noise_cleanup.zip`

Closed locally:
1. `P0-FRONTEND-RAW-HTTP-ERROR-TRANSPORT`
2. `P0-FRONTEND-ERRORBOUNDARY-RAW-DETAIL`
3. `P1-ADMIN-RAW-BACKEND-MESSAGES`
4. `P1-PUBLIC-SHOPENTRY-RAW-ERROR`
5. `P1-PUBLIC-PROFILE-RAW-MESSAGES`
6. `P2-DUPLICATE-ERROR-AND-STATUS-CHANNELS`
7. `P2-TOAST-LAYER-NO-DEDUPE-A11Y`
8. `P2-ROUTE-OFFLINE-FALLBACKS-INCOMPLETE`
9. `P3-PRODUCTION-CONSOLE-NOISE`
10. `P3-I18N-ERROR-COPY-NOISE`

Checks are recorded in the generated report. No release-ready, production-ready,
live Telegram proof, real TonConnect proof or GitHub CI green claim is made for
this output archive.

---

## Источник: `WORK_CYCLES_1556_PANELS_EXCHANGE_RELEASE_READINESS.md`

# Cycle 1556 — Panels, Exchange and release-readiness route

Status: `DONE LOCALLY / OUTPUT v171.31`.

## Input

- Archive: `EFHC_Bot_v171_30.zip`.
- SHA-256:
  `7ffd094d3bdcf8b1b71a8458ec642e60b917dd22751677941a5a47b0e174cd4e`.
- ZIP: `testzip=None`.
- Records: `4134` (`3911` files, `223` directories).
- Forbidden artifacts: `0`.
- AI Archive Laws integrity: passed before changes.

## Completed scenarios

### Panels

`/panels -> usePanelActivation -> panels service -> Zod DTO ->
POST /api/panels/activate -> PanelsService.activate_panel -> DB boundary ->
query invalidation -> visible new panel`.

The page now uses React Query for list, summary and activation. Responses are
validated before they reach the view. Activation preserves the idempotency
key, invalidates dependent state and displays the new panel after refetch.

### Exchange

`/exchange -> useExchangePreview/useExchangeConvert -> exchange service ->
Zod DTO -> POST /api/exchange/convert -> ExchangeService -> DB boundary ->
query invalidation -> visible balance refresh`.

The page no longer maintains a parallel manual preview state. A conversion of
`10 kWh` sends `10.00000000`, preserves idempotency and changes the visible
available amount from `100` to `90` after refetch.

## Browser interaction evidence

Both scenarios passed in a real Chromium session at `390x844` through the
policy-compatible local proof harness:

- `reports/generated/panels_activation_interaction_proof_v171_31.json`;
- `reports/generated/exchange_convert_interaction_proof_v171_31.json`;
- `reports/screenshots/panels_exchange_1556/`.

The proofs require a non-blank body, hidden splash, no horizontal overflow,
real mutation request, idempotency header and visible post-mutation state.

## Transaction boundary

Local unit proof confirms that route adapters preserve the idempotency key and
normalized amount when entering the atomic business-service boundary.

A real PostgreSQL runtime is not available on the operator host. Therefore
PostgreSQL transaction, locking and concurrency proof remains fail-closed and
is assigned to cycle 1566 and fresh CI.

## Release-readiness master plan

Created:

- `docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`;
- `reports/generated/mvp_release_readiness_master_plan_v171_31.json`;
- `ops/release/mvp_release_readiness_master_gate.py`;
- `tests/architecture/test_mvp_release_readiness_master_plan.py`.

The plan contains twelve domains and exactly 100 evidence points. A 99-percent
release candidate requires at least 99 verified points, all critical points,
fresh CI, live Telegram proof and a real signed TonConnect transaction.

The baseline evidence score is deliberately fail-closed. It is not an estimate
of implemented source-code volume.

## Closed findings

- `C1556-PANELS-REACT-QUERY-LINKAGE`.
- `C1556-EXCHANGE-PAGE-HOOK-BYPASS`.
- `C1556-ECONOMIC-SEAM-GENERATOR-DRIFT`.
- `C1556-DUPLICATE-PANELS-EXCHANGE-SURFACES`.
- `C1556-PANELS-EXCHANGE-BROWSER-INTERACTION-PROOF`.
- `C1556-NEXT-BUILD-PROCESS-BOUNDARY`.
- `C1556-RELEASE-READINESS-MASTER-PLAN`.

## Open evidence findings

- `C1556-POSTGRES-TRANSACTION-PROOF-ENV`: no local PostgreSQL runtime.

## Frontend production build

The standard build command performs a blocking TypeScript check before the
official Next webpack build and verifies required route artifacts. Two
consecutive clean `npm run build` executions exited naturally with code zero.
Each generated all thirty-four Next routes.

## Full regression

One `pytest --collect-only` inventory contained `2379` unique node IDs.
All nodes ran in 24 deterministic batches:

- `2255 passed`;
- `124 skipped` by existing environment gates;
- `0 failed`;
- `0` omitted collected nodes;
- `0` new skips or xfails;
- `0` deleted tests.

The architecture collection separately passed with `2088 passed`,
`7 skipped` and `0 failed`.

## Protected canon

No change was made to:

- `1 EFHC = 1 kWh`;
- panel price `100 EFHC`;
- bonus-first/main-second spending;
- generation or balance formulas;
- idempotency;
- auth or Telegram InitData verification;
- DB schema or Alembic `0001 only`;
- protected routes or navigation.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for `/panels` and `/exchange` only.

Not established:

- real PostgreSQL transaction proof;
- fresh GitHub CI for `v171.31`;
- live Telegram proof;
- real TonConnect proof;
- release-ready or production-ready status.

---

## Источник: `WORK_CYCLES_1557_TASKS_ADS_TYPOGRAPHY.md`

# Cycle 1557 — Tasks, Ads alias and compact typography

Status: `DONE LOCALLY / OUTPUT v171.32`.

## Completed user scenario

`/tasks -> React Query catalogue/state -> action or claim -> validated service
DTO -> backend route -> protected credit boundary -> query invalidation ->
visible claimed state`.

The routed page now exposes one operational catalogue. Historical dashboard
and engagement-preview components remain only as inactive legacy references.
The `/ads` route remains a compatibility alias to `/tasks`.

## Double-credit protection

Custom-task claim locks the submission, returns an idempotent response when
`paid=true`, and does not issue a second credit. The broken post-claim balance
reader was replaced with the existing `get_user_balances_snapshot` service.
Advertising completion remains protected by `task_complete_lock` and the
reward log. `/tasks/my` now merges moderated submissions with automatic
`user_tasks_status`, so refetch shows the credited advertising task.

## Browser interaction evidence

At `390x844`, one custom-task POST and one advertising callback POST were
observed. Each action refetched `/tasks/my`; both cards became `claimed`, no
horizontal overflow appeared, and screenshots were created.

## Typography and modal repair

The public runtime uses `Arial, Helvetica Neue, Helvetica, sans-serif` with a
compact mobile scale. Panels and Exchange statistic values are kept on one
line. Chromium measured `1 kWh = 1 EFHC` at `12.16px`, `nowrap`, and one line.
The shared Modal now renders through a body portal above fixed navigation, so
its confirmation button is not intercepted by the bottom bar.

## Exact evidence boundary

Established: code repair, targeted tests, production build and local Chromium
evidence for Tasks/Ads and the Panels/Exchange typography checks.

Not established: fresh GitHub CI, live Telegram, real TonConnect, real
PostgreSQL concurrency proof, release-ready or production-ready status.

## Final verification

- `npm ci`: passed, `0` vulnerabilities.
- TypeScript: passed.
- Frontend architecture: passed.
- Production build: two consecutive passes, 34 pages each.
- Browser E2E: `2 passed`.
- Exact full regression: `2389` nodes, `2263 passed`, `126 skipped`,
  `0 failed`.
- Release master gate: passed at `15 / 100` verified points.

The skipped nodes are established environment-gated tests. The new browser
tests were executed separately and passed. No explicit `skip` or `xfail`
marker was added by this work scope.

---

## Источник: `WORK_CYCLES_1558_REFERRALS_RANKS_NAVIGATION.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Cycle 1558 — Referrals, Ranks and navigation icon repair

Status: `DONE LOCALLY / OUTPUT v171.33` after final verification.

## Completed user scenarios

Referral path:

`Telegram start_param -> typed bind service -> backend referral protection ->
React Query statistics -> copy/share -> active/inactive referral routes`.

Ranks path:

`/ranks -> typed service -> React Query -> personal generated kWh state ->
vertical TOP-100 leaderboard -> refresh and find-me actions`.

## Referral binding and repeat protection

The bind marker is scoped by both `tg_id` and `start_param`. A pending marker
has a fifteen-second expiry, failed transport or backend error removes the
marker, and only terminal results become `done`. Existing backend checks for
invalid code, unknown code, self-referral and an already assigned parent remain
unchanged.

## Header, energy mark and navigation

The header balance label is now only `EFHC`; the visual word `Total` is not
rendered. The dense legacy coin image is replaced by a neutral energy circle
and lightning SVG. All six protected bottom-navigation entries use one original
stroke-icon system. Sandbox assets were reviewed only as visual references;
no foreign runtime, branding or asset file was copied.

## Browser interaction evidence

At `390x844`, one `start_param` bind POST was observed, the referral link was
copied and shared through the Telegram link API, and route navigation loaded
personal rank, generated kWh and TOP leaderboard data. Refresh caused a second
rank query. The header showed only `EFHC`, the universal energy mark was
present, exactly six navigation icons were rendered, and horizontal overflow
was absent.

## Exact evidence boundary

Established: code repair, typed service/query seams, backend repeat-binding
guards, targeted tests, production build and local Chromium evidence for the
cycle-1558 scope.

Not established: fresh GitHub CI, live Telegram client proof, real TonConnect,
real PostgreSQL concurrency proof, release-ready or production-ready status.

## Final verification

- `npm ci`: passed, `0` vulnerabilities.
- TypeScript: passed.
- Frontend architecture: passed.
- Production build: two consecutive passes, 34 pages each.
- Browser E2E after final build: `1 passed`.
- Exact full regression: `2394` nodes, `2267 passed`,
  `127 skipped`, `0 failed`.
- Release master gate: passed at `19 / 100` verified points.

The skipped nodes are established environment-gated tests. The new browser
test was executed separately and passed. No explicit `skip` or `xfail` marker
was added by this work scope.

---

## Источник: `WORK_CYCLES_1559_PROFILE_WALLET_HISTORY_FAQ.md`

# Work cycle 1559 — Profile, Wallet, History and FAQ

Status: `DONE LOCALLY / OUTPUT v171.34`.

## Input

- Archive: `EFHC_Bot_v171_33.zip`.
- SHA-256:
  `9b959774b20a640d6992ee755e3dece5a85bee1bf02b7abc2ce8ea2cf222323d`.
- ZIP: `testzip=None`.
- Records: `4188` (`3962` files, `226` directories).
- Forbidden artifacts: `0`.

## Completed scenarios

- Profile is a full routed page with one identity hero, one tab navigation
  and one active content surface.
- Wallet list, primary-wallet action and removal action remain connected to
  the existing backend routes.
- General balance history and withdrawal history use typed services,
  React Query infinite queries, refetch and cursor pagination.
- Human labels and safe errors remain in the public surface.
- FAQ remains a full vertical tree and is reachable from Profile.
- The language selector keeps the selected locale through the settings
  storage contour.
- The thirteen canonical locale files retain key parity.

## Visual and responsive result

- `360x800`: narrow Android profile proof.
- `390x844`: wallet and FAQ proof.
- `430x932`: general and withdrawal history proof.
- `768x1024`: tablet profile proof.
- No checked viewport has horizontal overflow.
- The duplicate account dashboard and public trust layer are retained only
  as historical sources and are no longer mounted by `/web-profile`.
- Cards, tabs, filter buttons, borders and spacing use more of the available
  smartphone width without changing unrelated public routes.

## Evidence

- Responsive browser report:
  `reports/generated/profile_wallet_history_faq_responsive_v171_34.json`.
- Thirteen-language browser report:
  `reports/generated/profile_faq_13_languages_v171_34.json`.
- Screenshots:
  `reports/screenshots/profile_wallet_history_faq_1559/`.
- Exact regression: `2399` nodes, `2271 passed`, `128 skipped`,
  `0 failed`.
- Release evidence score: `21 / 100`.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for the current responsive and language scope.

Not established:

- fresh GitHub CI;
- live Telegram client proof;
- real TonConnect proof;
- real PostgreSQL concurrency proof;
- final release audit;
- release-ready or production-ready status.

---

## Источник: `WORK_CYCLES_1560_HUB_DIRECT_DEPOSIT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work cycle 1560 — HUB and Direct Deposit

Status: `DONE LOCALLY / OUTPUT v171.35`.

## Input

- Archive: `EFHC_Bot_v171_34.zip`.
- SHA-256:
  `4b8e99e3db0902276cccbbbe480d1a79569497a80efe26116a6bf85e682990ea`.
- ZIP: `testzip=None`.
- Records: `4248` (`4020` files, `228` directories).
- Forbidden artifacts: `0`.

## Completed scenario

- HUB exposes exactly two equal primary actions.
- EFHC top-up uses a typed handoff service and React Query mutation.
- VIP NFT opens the fixed GetGems URL.
- Global Header `+` opens Direct Deposit without a wallet gate.
- The user enters a positive TON amount.
- The backend generates the canonical memo `EFHC:<tg_id>`.
- The TON wallet URL contains the amount in nanoTON and the memo.
- The modal remains open while reconciliation is checked.
- Watcher credit is recognized through balance history.
- The user sees human checking, retry and confirmed states.
- Raw wallet, memo, intent IDs and payment diagnostics remain hidden.

## Browser evidence

Checked viewports:

- `360x800`;
- `390x844`;
- `430x932`;
- `768x1024`.

Evidence proves:

- two HUB actions;
- one EFHC handoff POST;
- one Direct Deposit open POST;
- `1.25 TON` converted to `1250000000` nanoTON;
- canonical memo included in the wallet URL;
- visible watcher checking and confirmed states;
- confirmed credit `25.00000000 EFHC`;
- no horizontal overflow.

Screenshots:

`reports/screenshots/hub_direct_deposit_1560/`.

Machine evidence:

- `reports/generated/hub_direct_deposit_v171_35.json`;
- `reports/generated/hub_direct_deposit_linkage_v171_35.json`.

## Regression

- Exact inventory: `2403` unique nodes.
- Passed: `2274`.
- Skipped: `129` existing environment-gated nodes.
- Failed: `0`.
- Omitted: `0`.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for HUB and Direct Deposit.

Not established:

- fresh GitHub CI;
- live Telegram client proof;
- a real signed TON transaction;
- final release audit;
- release-ready or production-ready status.

---

## Источник: `WORK_CYCLES_1561_DIRECT_DEPOSIT_WITHDRAW_ENERGY.md`

# Cycle 1561 — funding correction, Withdraw and Energy

Status: `DONE_LOCALLY_WITH_OPERATOR_VISUAL_OPEN`.

## Required correction

The `v171.35` Direct Deposit implementation was incorrect. It accepted
native TON, applied pricing and credited EFHCm. Its former verification
status is revoked.

The active canon is now:

- `Прямое пополнение`: direct EFHC jetton transfer to EFHCm;
- `Пополнение`: HUB opens Browser Shop purchase for TON/GRAM or USDT.

## Completed implementation

- direct EFHC jetton TEP-74 transaction builder;
- backend EFHC master, decimals and memo metadata;
- watcher rejects non-EFHC assets for direct deposit;
- exact EFHCj to EFHCm credit quantity;
- Browser Shop TON/GRAM and USDT methods;
- Withdraw React Query create, cancel, detail, status and history;
- Energy exact progress and eight-decimal generation rates;
- public browser interaction and responsive screenshots.

## Proof boundary

Public visual proof is established. Admin Withdraw code, routes and
operator actions are statically and unit protected, but a new admin
browser screenshot was not obtained on the managed Chromium host.

Fresh CI, live Telegram, real jetton transactions and payout are not
claimed.

---

## Источник: `WORK_CYCLES_1562_BROWSER_SHOP_CHECKOUT.md`

# Cycle 1562 — repeated Browser Shop and guarded visual restoration

Status: `DONE_LOCALLY_WITH_CONTROLLED_BROWSER_PROOF`.

## Input and output

- Input: `EFHC_Bot_v171_37.zip`.
- Output target: `EFHC_Bot_v171_38.zip`.
- This is a corrective repeat of cycle 1562, not cycle 1563.

## Browser Shop

Verified locally:

- TON/GRAM and USDT payment methods;
- Telegram handoff and Web access-key linking;
- return to the same token, SKU and payment method;
- payment-intent creation;
- backend `expires_at` as the TTL source;
- React Query status polling every five seconds;
- polling stops on terminal state;
- active-intent resume, wallet-sync and `flow_truth`;
- compact mobile and tablet checkout surfaces.

## Restored HUB canon

- HUB contains exactly two canonical actions:
  `Пополнение` and `EFHC VIP NFT`;
- `Пополнение` contains no purchase, asset, price or checkout wording before
  the external transition;
- the VIP action opens the official GetGems collection;
- deletion of either guarded function requires a direct user decision.

## Restored Energy canon

Energy contains only:

- generated kWh;
- exact progress;
- current `Lvl N` and canonical level name;
- active panels;
- generation rate;
- available kWh.

It does not render Wallet balances, EFHC action cards or Exchange actions.
The available-kWh unit is not duplicated.

## Navigation

- six equal-width rounded rectangular cells;
- small equal gaps;
- almost full phone width;
- one coherent rounded-outline SVG family;
- route order unchanged.

## Guard contradiction repair

The accepted `v171_36` two-action HUB guards were inverted during `v171_37`
and Energy guards were changed to require wallet/exchange blocks and hide
level names. These changes were unauthorized. The audit and permanent repair
are recorded in:

`docs/audits/RECENT_GUARD_CONTRADICTION_AUDIT_1562.md`.

## Evidence

- architecture inventory: `2125 passed`, `7 skipped`, `0 failed`;
- full regression: `2296 passed`, `135 skipped`, `0 failed`;
- controlled Browser Shop and visual Chromium E2E: `2 passed`;
- seven current screenshots in
  `reports/screenshots/browser_shop_1562_repeat/`;
- two consecutive production builds: `34 / 34` pages;
- live Telegram linking and real payments are not claimed.

## Next cycle

`1563 — TonConnect manifest, restore, TonProof and transaction UX`.

---

## Источник: `WORK_CYCLES_1563_TONCONNECT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Cycle 1563 — TonConnect wallet and transaction UX

Status: `DONE_LOCALLY_WITH_CONTROLLED_BROWSER_PROOF`.

## Input and output

- Input: `EFHC_Bot_v171_38.zip`.
- Output target: `EFHC_Bot_v171_39.zip`.
- The next cycle is not executed in this iteration.

## Manifest

The runtime manifest is served by:

`/api/tonconnect-manifest`

It returns the required `url`, `name` and `iconUrl` fields, CORS `*`
and a short public cache policy. The static JSON file remains fallback-only.
A live production HTTPS domain is not claimed by local proof.

## Wallet restore and connection

The frontend TonConnect compatibility layer now owns reactive wallet state.
It subscribes to connector status changes and distinguishes:

- restore still running;
- restore completed without a wallet;
- restored connected session;
- proof ready;
- connection in progress;
- proof verification;
- connected;
- rejected by the user;
- error.

A restored session does not create a new wallet binding. Existing backend
binding is loaded through `wallets/me` and shown without a second connect POST.

## TonProof

The complete proof envelope is sent to `/wallets/connect`:

- canonical wallet address;
- wallet application;
- payload token;
- public key;
- network;
- timestamp;
- proof domain and length;
- signature;
- payload;
- state init.

The backend re-verifies the signature, domain, network identity, tg_id,
payload token and replay boundary before creating a binding.

## User rejection and transaction UX

Connection rejection and transaction rejection are separate human states.
TonConnect rejection code `300` is handled without showing a generic backend
error. Transaction UX exposes signing, signed, rejected and failed phases.

## Evidence

- controlled wallet Chromium scenario: passed;
- controlled transaction Chromium scenario: passed;
- seven current screenshots in `reports/screenshots/tonconnect_1563/`;
- complete TonProof binding POST: one;
- restored session creates no additional binding POST;
- Ed25519 cryptographic boundary tests: passed;
- manifest runtime report: passed;
- all thirteen locale files contain the same TonConnect phase keys.

## Proof boundary

Local controlled browser proof is not a real wallet signature or a live
network transaction. Those remain external release evidence for cycle 1573.

---

## Источник: `WORK_CYCLES_1564_ADMIN_PANEL_MVP.md`

# Cycle 1564 — Admin Panel MVP

## Result

Cycle 1564 is complete locally with controlled Chromium visual and DOM-click
proof.

## Protected sections

- launcher and overview;
- users;
- tasks;
- advertising;
- panels;
- referrals;
- shop;
- sale packages;
- withdrawals;
- EFHC deposits;
- diagnostics;
- reports;
- system;
- bank;
- HUB links;
- logs;
- templates.

## Visual proof

- 17 of 17 protected admin routes rendered;
- 12 of 12 required launcher actions received a real DOM click;
- no horizontal overflow at 390 x 844;
- no visible runtime-error overlay;
- one screenshot is preserved for every route.

Chromium execution was partitioned because the managed URL blocklist requires a
server-HTML proxy and one long-lived Playwright driver accumulates resources on
heavy admin pages. No route or required action was omitted.

## Public copy repair

A new active-copy guard maps real public translation-key usage to all locale
values and rejects visible implementation language. It is part of the standard
frontend architecture gate.

## Header VIP status

VIP and Active are persistent header statuses. They remain visible when false
and change visual tone when active. The VIP crown is protected by architecture
tests.

## Boundary

Local browser proof uses controlled API responses. Real production admin
mutations, live Telegram, real TonConnect and fresh GitHub CI are not claimed.

---

## Источник: `WORK_CYCLES_1565_COMPLETE_FUNCTION_LINKAGE_MATRIX.md`

# Cycle 1565 — complete function linkage matrix

Input HEAD: `EFHC_Bot_v171_40.zip`.

Output target: `EFHC_Bot_v171_41.zip`.

## Scope

- Build a complete public and Admin action inventory.
- Verify UI, React Query, service, DTO, API, business, DB, response and
  invalidation/refetch boundaries.
- Remove remaining direct transport bypasses.
- Rebalance the Global Header.
- Keep the VIP status visible without a crown.
- Produce current browser screenshots.

## Implemented

- Added a shared Admin React Query transport and service boundary.
- Migrated active Admin pages and runtime components from direct transport.
- Added service/query boundaries for Shop launcher, skins, referrals and
  TonConnect.
- Added Profile wallet mutation hooks and cursor-list service ownership.
- Added a reproducible complete linkage generator and fail-closed guard.
- Rebuilt the Global Header into a uniform action grid.
- Removed the VIP crown while preserving the permanent VIP status text.

## Linkage result

- Active actions: `81`.
- Public actions: `38`.
- Admin actions: `43`.
- Complete: `81`.
- Partial: `0`.
- Direct UI transport files: `0`.
- Strict OpenAPI operation count: `132`.

## Browser result

- Header states: inactive VIP, active VIP and narrow mobile.
- Admin routes: `17 / 17`.
- Admin launcher DOM clicks: `12 / 12`.
- Horizontal overflow: `0` in the controlled proof.

## Non-claims

This cycle does not claim real production PostgreSQL mutations, transaction
isolation, fresh GitHub CI, live Telegram or a real TonConnect transaction.

---

## Источник: `WORK_CYCLES_1574_1578_RELEASE_PREPARATION.md`

# Work cycles 1574–1578 — pre-release completion route

Status: LOCAL SCOPE COMPLETE / LIVE VERIFICATION DEFERRED.
Input HEAD: `EFHC_Bot_v171_68.zip`.
Output HEAD: `EFHC_Bot_v171_69.zip`.

## Cycle 1574 — local release-candidate audit

Local work:

- reconcile the current green CI evidence;
- close the provider-independent deployment requirement;
- add a truthful local 99-percent gate;
- create a minimal production release package;
- keep external live claims fail-closed.

Status after this pass:
`LOCAL_SCOPE_COMPLETE`.

## Cycle 1575 — technical deployment preparation

Local work:

- production Dockerfiles;
- universal Docker Compose;
- Caddy HTTPS proxy;
- standard PostgreSQL;
- server installer, deployment and health verification;
- domain and webhook reconfiguration.

External remainder:
`LIVE_VPS_DEPLOYMENT`.

## Cycle 1576 — Telegram and wallet publication preparation

Local work:

- stable project-domain contract;
- Telegram webhook registration and verification script;
- WalletProvider boundary retained;
- live checklist for Telegram, TonConnect and TonProof.

External remainder:
`LIVE_TELEGRAM_AND_WALLET_PROOF`.

## Cycle 1577 — controlled transaction preparation

Local work:

- backup before financial testing;
- readiness verification;
- restore drill;
- operator checklist for deposit, Browser Shop and withdrawal settlement;
- transaction evidence and anti-double-credit requirements.

External remainder:
`REAL_ONCHAIN_TRANSACTION_AND_SETTLEMENT_PROOF`.

## Cycle 1578 — public release preparation

Local work:

- release archive and checksum;
- deployment and rollback runbooks;
- off-site recovery bundle process;
- cross-provider drill procedure;
- go/no-go checklist and launch observation boundary.

External remainder:

- real second-provider recovery drill;
- DNS switch;
- live Telegram and TON checks;
- controlled public launch observation.

## Current completion semantics

The user directly approved this boundary:

```text
all locally executable work complete
+ portable production archive ready
+ external gates explicitly listed
= LOCAL_PRE_RELEASE_99_PERCENT
```

This does not equal `PRODUCTION_RELEASE_READY`. The remaining one percent
is the real deployment and live verification layer.

## Completion record

- Cycle 1574: `LOCAL_SCOPE_COMPLETE`.
- Cycle 1575: `DEPLOYMENT_PACKAGE_COMPLETE_LIVE_DEPLOYMENT_DEFERRED`.
- Cycle 1576: `LOCAL_TELEGRAM_WALLET_PREPARATION_COMPLETE_LIVE_DEFERRED`.
- Cycle 1577: `LOCAL_TRANSACTION_GUARDS_COMPLETE_REAL_SETTLEMENT_DEFERRED`.
- Cycle 1578: `PUBLIC_RELEASE_PACKAGE_PREPARED_GO_LIVE_DEFERRED`.

Machine evidence: `reports/generated/local_pre_release_99_v171_68.json`.

## v171.69 audited release blocker closure

The first v171.68 release package was not accepted for VPS deployment
because an independent audit found blocking operational defects. v171.69
closes them without claiming live deployment:

- canonical SchedulerService is the only production scheduler;
- all eight jobs are registered strictly;
- scheduler shutdown is bounded and awaited;
- release scripts preserve executable mode 0755;
- database restore is fail-closed;
- PostgreSQL and Caddy do not receive the complete backend environment;
- Docker access setup supports a normal non-root operator;
- release documentation matches the real Compose path;
- Docker logs are bounded;
- updates are backup-first and sequential.

Docker build and real startup remain part of technical deployment.

## v171.70 clean first-boot closure

The second release audit found that the archive still could not prove a
first deployment to a completely empty PostgreSQL volume. v171.70 adds
the missing local production contract:

- migrations no longer depend on `docs/` or SSOT CSV;
- ORM metadata defines the exact 44-table contract;
- `migrate` creates schemas, applies Alembic head, validates the database
  and inserts only idempotent system data;
- `BANK_EFHC` is a reserved service-user ID and is never recreated or
  reset by repeated deployment;
- webhook and TON variables are canonical and preflight-validated;
- rankings match ORM/API structures and support an empty database;
- admin shop/hub routes are mandatory in production;
- TON reconciliation is periodic and persistent;
- Compose uses `db → migrate → backend + scheduler → frontend → proxy`;
- the only documented first-start command is `deploy.sh`.

External acceptance remains a real Docker no-cache build, empty-volume
first start, repeated deployment and live service verification.

## v171.71 production frontend build closure

The third release audit found that the v171.70 VPS build still depended
on development-only FAQ generation and an automatic budget report path.
v171.71 closes those blockers:

- FAQ, locale and PWA files are generated during release packaging;
- the minimal release contains a SHA-256 asset manifest;
- frontend prebuild performs Node-only verification of packaged files;
- Docker build does not require Python, `docs/` or SSOT sources;
- performance budgets are removed from npm `postbuild`;
- the Next.js timeout is configurable and VPS-safe;
- Compose builds the shared backend image consistently;
- preserved PostgreSQL data triggers the update backup path;
- scheduler environment settings are no longer ignored;
- all expected route modules are fail-closed in production.

Real Docker build and deployment acceptance remain external gates.

---

## Источник: `WORK_CYCLES_1579_DUAL_GITHUB_CI_LOG_REPAIR.md`

# Work cycle 1579 — dual GitHub CI log repair

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED.
Input HEAD: `EFHC_Bot_v171_73.zip`.
Output HEAD: `EFHC_Bot_v171_74.zip`.
Release output: `EFHC_Bot_v171_74_RELEASE.zip`.

## Supplied evidence

- Development log: `logs_81724444881.zip`.
- Release log: `logs_81726814646.zip`.

## Root causes

1. Both contours failed Ruff `SIM117` because the release database contract used nested context managers.
2. Release pytest failed before its required-route assertion because FastAPI 0.140 inserted an internal `_IncludedRouter` object without a `path` attribute into `app.routes`.
3. The release builder still embedded a hardcoded v171.73 `source_head`, creating provenance drift for the next archive.
4. The copied root pytest configuration required the external workflow to inject `PYTHONPATH=backend`.
5. Direct execution of `python ops/release/build_release_archive.py` failed because package imports depended on an externally prepared module path.
6. Current release ENV/Compose/update examples remained on v171.73, and dynamic `source_head` initially produced the invalid dotted filename `EFHC_Bot_v171.74.zip`.

## Repair

- combined PostgreSQL connection/cursor contexts;
- added a route-path collector that ignores only pathless framework markers;
- added a regression test for a mixed marker/real-route collection;
- retained the exact mandatory route set;
- modernized the Payment Intent Pydantic schema config to remove the project-owned deprecation warning;
- added a standalone release pytest profile with `pythonpath = backend`;
- derived `RELEASE_METADATA.source_head` from the requested version and made release asset/build CLI version explicit;
- repaired CI-log task classification for the user's Russian wording;
- synchronized active HEAD, handoff and temporary-memory documents;
- made the release builder work both as a package module and as a direct CLI and added a regression guard.
- synchronized v171.74 ENV/image defaults and update examples, normalized semantic versions to underscore archive tokens, and added guards against future naming drift.

## Local validation

- development bounded groups: `2321 passed, 142 skipped, 0 failed`;
- release acceptance without live PostgreSQL: `7 passed, 1 deselected, 0 failed`;
- internal release SHA-256 inventory: `739/739 files`;
- provider-independent release gate: passed during release build.

No tests were deleted, skipped or weakened. No CI workflow was changed. Runtime financial behavior, migrations, UI, navigation, localization and transaction truth were not changed.

---

## Источник: `WORK_CYCLE_1583_REFERRALS_PAGE_LVL_INLINE_TABS.md`

# Cycle 1583 — Referrals page Lvl and inline segments

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED
Input HEAD: `EFHC_Bot_v171_79.zip`
Output HEAD: `EFHC_Bot_v171_80.zip`

## User-required product contract

The `/referrals` page must contain on one route:

1. progress to the next referral Lvl;
2. permanent referral link, copy action and Telegram/social sharing;
3. inline segmented `Active` / `Inactive` lists matching the Panels tab
   interaction pattern;
4. explicit `Lvl 0–5` and the complete threshold/reward scale.

## Economic correction

The tenth active direct referral causes an incremental event of
`0.1 + 1 = 1.1 EFHCb`, but the cumulative total earned by reaching Lvl 1 is:

```text
10 × 0.1 EFHCb + 1 EFHCb = 2 EFHC
```

The backend now exposes the canonical level scale with direct rewards, one-time
Lvl rewards, cumulative Lvl rewards and cumulative total rewards. The frontend
does not own or duplicate this calculation.

## Runtime changes

- Expanded `/referrals/stats/me` with current/next thresholds, unit reward,
  maximum rewarded active referrals and five backend-owned level steps.
- Replaced navigation buttons on `/referrals` with local segmented tabs.
- Embedded paged Active/Inactive lists in the main route.
- Added explicit current `Lvl` and five level cards.
- Preserved compatible `/referrals/active` and `/referrals/inactive` routes.
- Preserved first-creation attribution and all unit/level payout logic.

## Guards

- `tests/architecture/test_referrals_page_canon_v171_80.py`;
- `tests/architecture/test_referrals_progress_bonus.py`;
- `tests/architecture/test_referral_level_bonus_runtime.py`;
- `tests/efhc_backend/referrals/test_referral_level_rewards_integration.py`;
- `ops/release/ci_profile/test_release_archive_contract.py`.

## Proof boundary

Static, API, bounded backend and archive checks are local evidence only. Fresh
GitHub CI, real PostgreSQL execution of integration tests and route-backed
browser screenshots remain separate proof gates.

---

## Источник: `WORK_CYCLE_1584_REFERRAL_EFHCB_FULL_CYCLE_TRUTH.md`

# Cycle 1584 — Referral EFHCb full-cycle truth

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED
Input HEAD: `EFHC_Bot_v171_80.zip`
Output HEAD: `EFHC_Bot_v171_81.zip`

## Direct user correction

All monetary referral rewards belong to the bonus balance and therefore use the
asset notation `EFHCb`, not generic `EFHC`.

The complete cycle is:

```text
10 000 active direct referrals × 0.1 EFHCb = 1 000 EFHCb
Lvl rewards 1 + 10 + 100 + 300 + 1 000 = 1 411 EFHCb
1 000 + 1 411 = 2 411 EFHCb
```

## Root cause

The backend arithmetic already produced `2 411`, but the public Lvl card showed
only the current Lvl reward. At Lvl 5 the screen therefore exposed `1 000` for
direct referrals and `+1 000` for Lvl 5, then jumped to `2 411` without showing
the accumulated earlier Lvl rewards `1 + 10 + 100 + 300 = 411`. Generic `EFHC`
labels also hid that all of these amounts are credited to `bonus_balance`.

## Runtime repair

- Added the canonical asset field `bonus_asset = EFHCb` to referral stats.
- Added explicit full-cycle API fields:
  - `full_cycle_direct_bonus = 1000.00000000`;
  - `full_cycle_level_bonus = 1411.00000000`;
  - `full_cycle_total_bonus = 2411.00000000`.
- Kept backend-owned per-Lvl fields and exposed `cumulative_level_bonus` visibly.
- Referrals UI now shows direct subtotal, current Lvl reward, accumulated Lvl
  rewards and cumulative total, all in EFHCb.
- Added a separate full-cycle summary block.

## Documentation and causal links

Updated the active referral NORM, first-creation canon, runtime proof, FAQ SSOT,
all 13 locale bundles, frontend screen registry, Healer, error registry, Kernel,
START_HERE and new-chat handoff. Historical reports remain historical and do
not override this cycle.

## Guards

- `tests/architecture/test_referral_bonus_cycle_efhcb_v171_81.py`;
- `tests/architecture/test_referral_level_bonus_runtime.py`;
- `tests/architecture/test_referrals_page_canon_v171_80.py`;
- `tests/architecture/test_referrals_progress_bonus.py`;
- `tests/efhc_backend/referrals/test_referral_level_rewards_integration.py`;
- `ops/release/ci_profile/test_release_archive_contract.py`.

## Local validation completed

- Targeted economics/API/frontend/OpenAPI: `22 passed, 2 skipped, 0 failed`.
- Broad referral/FAQ/i18n/OpenAPI architecture set: `308 passed, 0 failed`.
- Kernel/file-map/startup/referral final guards: `86 passed, 0 failed`.
- Canon Guard: PASS.
- OpenAPI strict contract: 129 operations, no missing/dead seams.
- Python compile, JSON validation (772 files) and release shell `bash -n`: PASS.
- Real PostgreSQL, npm production build, Chromium route proof and fresh exact-HEAD GitHub CI remain external gates.

## Proof boundary

Local static, bounded runtime and archive checks do not replace fresh exact-HEAD
GitHub CI, real PostgreSQL integration execution or route-backed browser proof.

---

## Источник: `WORK_CYCLE_1585_CI_LOG_REPAIR_ADMIN_SEAM_PANEL_REPLAY.md`

# Cycle 1585 — CI log repair: Admin seam and panel replay

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED
Input HEAD: `EFHC_Bot_v171_81.zip`
Output HEAD: `EFHC_Bot_v171_82.zip`

## Evidence

Development CI reported four pytest failures, eight Ruff failures and three
frontend TypeScript errors. Release CI reported three Ruff failures and the same
three frontend errors. Mypy, Bandit, Alembic and the release pytest profile were
green in the supplied runs.

## Root causes

1. The Admin withdrawal validator generator omitted fields and the
   outcome-preview parser consumed by the frontend.
2. Panel activation evaluated current balance before resolving a completed
   idempotent request, so exact-balance replay failed after the first debit.
3. Performance-budget version literals, imports, variable names and executable
   source line lengths were not synchronized with the exact CI contracts.

## Repair

- Rebuilt the complete generated Admin withdrawal contract from its generator.
- Moved panel replay read-through before state-dependent balance and limit
  checks; mismatched or incomplete replay evidence fails closed.
- Synchronized active version literals to `v171.82` and repaired exact Ruff and
  line-length failures.
- Added regression guards for both generated-contract completeness and replay
  ordering.

## Unchanged

Referral EFHCb economics, immutable first-creation attribution, panel price,
financial settlement rules, database schema, Alembic head, canonical UI,
six-button navigation and 13 locales were not changed.

## Proof boundary

Targeted local tests and archive checks do not replace fresh exact-HEAD GitHub
CI. Frontend production build and PostgreSQL replay integration must execute in
that CI environment.

---

## Источник: `WORK_CYCLE_1586_CI_RUFF_IMPORT_ORDER_REPAIR.md`

# Work cycle 1586 — CI Ruff import-order repair

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.

## Input

- Development HEAD: `EFHC_Bot_v171_82.zip`.
- Development CI: `logs_81874732041.zip`.
- Release CI: `logs_81877007921.zip`.
- Exact Kernel route: `ci_log_exact_failure_repair`.
- Fallback: not used.

## Root cause

Both archives passed all functional gates. Development completed
`2556 passed, 20 skipped`; release completed `12 passed`. PostgreSQL,
Alembic, Mypy, Bandit, compilation and frontend production build were
green.

Delivery failed only because the same two shared runtime files violated
Ruff `I001` import ordering:

- `backend/app/services/admin/admin_facade.py`;
- `backend/app/services/referral_service.py`.

The SQLAlchemy imports were positioned before app-service imports while
the repository Ruff/isort configuration classifies the resulting block
in the opposite order.

## Repair

The two import blocks now match the exact ordering proposed by Ruff.
No executable statements, schemas, API contracts, database behavior,
frontend behavior or economic rules changed.

A targeted architecture guard protects the two known ordering anchors.
The mandatory Ruff jobs remain the authoritative delivery gate.

## Proof boundary

Local targeted and bounded regression checks must pass. Fresh exact-HEAD
GitHub CI for both `v171.83` archives remains mandatory before any
stronger release status.

---

## Источник: `WORK_CYCLE_1587_REFERRAL_RUNTIME_API_TZ_AUDIT.md`

# WORK CYCLE 1587 — REFERRAL RUNTIME/API TZ AUDIT

Status: LOCAL_SCOPE_COMPLETE / EXTERNAL_VERIFICATION_DEFERRED.
Version: `v171.84`.

## Objective

Audit two referral/release specifications against the exact v171.83 runtime,
repair every confirmed defect, adapt conflicting template requirements to the
active canon, and add real PostgreSQL/API proof.

## Confirmed repairs

- TG-ID-only referral and panel relationships;
- permanent Active status after any first panel, including archived panels;
- PostgreSQL filtering and stable cursor pagination;
- legacy CRUD repair;
- self-only user API security;
- complete Admin referral totals;
- ETag mutation correctness;
- atomic/idempotent concurrent reward hardening;
- stale CRUD health registry removal;
- integration CI and release documentation cleanup.

## Canonical adaptations

- invalid supplied referral code creates no user;
- full development tests remain outside release, minimal acceptance guards stay;
- bank deficit mode remains valid;
- no unnecessary migration or idempotency-key namespace change.

## External boundary

Fresh v171.84 GitHub CI, real PostgreSQL execution, frontend build, Docker clean
deploy/update/rollback and VPS/live gates remain deferred and must not be
reported as completed.

---

## Источник: `WORK_CYCLE_1588_EXACT_HEAD_EVIDENCE_GATE_REPAIR.md`

# WORK CYCLE 1588 — EXACT-HEAD RELEASE EVIDENCE GATE REPAIR

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED.
Version: `v171.85`.

## Objective

Prevent historical CI evidence from closing a current development/release gate.

## Root cause

`ops/release/local_pre_release_gate.py` used fixed v171.67 CI and v171.69 repair
files. Any later archive could therefore inherit a false 99-percent completion
claim without an exact matching GitHub run.

## Repair

- derive current version from `release_config/UPDATE_POLICY.json`;
- derive the exact development archive name from that version;
- accept only green CI intake with matching `source_head`;
- expose older records as historical and rejected;
- return `LOCAL_RELEASE_CANDIDATE` while exact-head CI is absent;
- preserve all external non-claims and `production_release_ready=false`;
- remove the unconditional `99_PERCENT_COMPLETE` claim from generated release metadata and record `LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.

## Patch boundary

Changed only release evidence control, regression guards, version metadata,
control documents and Healer/causal records. No product runtime behavior,
economy, database schema, UI or wallet logic changed.

---

## Источник: `WORK_CYCLE_1589_REFERRAL_ACTIVATION_RUNTIME_TEST_DEPTH.md`

# WORK CYCLE 1589 — REFERRAL ACTIVATION CONSOLIDATION AND RUNTIME TEST DEPTH

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED.
Version: `v171.86`.
Input HEAD: `EFHC_Bot_v171_85.zip`.

## Objective

Execute `TZ_full_referral_consolidation_and_tests.md` against the exact v171.85
runtime, preserving stronger existing PostgreSQL infrastructure while removing
remaining paper-test and duplicate-implementation defects.

## Audit decisions

- The proposed per-TG cleanup fixture was rejected because the current isolated
  CI database plus Alembic and per-test `TRUNCATE ... CASCADE` is stronger; the
  proposed SQL also referenced a nonexistent
  `referral_bonus_ledger.inviter_tg_id` column.
- Existing PostgreSQL tests were retained, but critical paths were strengthened
  where they bypassed production onboarding.
- The DB self-referral constraint and runtime test remain as defence in depth.
- A literal 10 000 sequential purchase load test was not added to the blocking
  10-minute workflow. Runtime proof covers real E2E Lvl 1, all level thresholds,
  the 9 999/10 000/10 001 boundary, concurrency, rollback and idempotency.

## Runtime repair

- `referrals_crud.activate_referral()` is now the single owner of
  `SELECT ... FOR UPDATE` and the `NULL -> activated_at` transition.
- The operation accepts deterministic `activation_dt` and returns
  `ReferralActivationResult(link, activated_now)`.
- `referral_service.on_user_first_panel_activation()` no longer contains a
  duplicate inline update and rewards only the transaction that owns the
  transition.
- The panel lock-order invariant is documented next to the runtime call.
- CRUD health-check naming now states honestly that it verifies symbol presence,
  not production wiring.

## Test/CI repair

- The first-panel reward/replay test now executes real inviter onboarding,
  referral-code creation, invitee onboarding, funding, panel purchase and DB
  assertions.
- Rollback and parallel first-panel tests also use the real attribution path.
- Added deterministic activation-transition proof.
- Added ten-referral E2E proof: `10 × 0.1 + 1 = 2 EFHCb` in real PostgreSQL.
- Removed the arithmetic-only `2 411` function from the integration module;
  full-cycle constants remain protected in dedicated economy/architecture tests.
- GitHub CI writes JUnit evidence and fails unless at least 24 integration tests
  are collected with zero failures, errors or skips.
- Missing DB URLs or SQLAlchemy dependencies fail in CI instead of silently
  skipping the integration suite.

## Unchanged canon

No change to `1 EFHC = 1 kWh`, referral thresholds, 2 411 EFHCb full-cycle
economics, 13 locales, UI, API routes, database schema, Alembic head, 44-table
contract, WalletProvider or production deployment architecture.
## Validation evidence

- deterministic regression inventory: `2667` unique nodes;
- result: `2522 passed`, `145 skipped`, `0 failed`, `0 omitted`;
- targeted final repair pack: `34 passed`;
- PostgreSQL integration inventory: `24` tests;
- local environment result without PostgreSQL: `24 skipped` and not accepted as
  runtime proof;
- simulated GitHub Actions without database variables: fail-closed error;
- Canon Guard, workflow parity and Python compilation: PASS;
- standalone release acceptance: `12 passed, 1 skipped`;
- fresh exact-HEAD GitHub Actions remains mandatory.

---

## Источник: `WORK_CYCLE_1590_FRESH_CI_REFERRAL_POSTGRES_REPAIR.md`

# Work Cycle 1590 — fresh CI referral PostgreSQL repair

Status: `LOCAL_SCOPE_COMPLETE`.
Archive target: `v171.87`.
Route: `ci_log_exact_failure_repair`.
Fallback: `false`.

## Input evidence

- GitHub run `82060386826`: release archive, green.
- GitHub run `82058627460`: development archive, red.
- Development failures: Ruff and PostgreSQL integration.

## Root causes

1. Four exact Ruff import and unused-name findings existed in the new
   integration modules.
2. Integration seed SQL passed untyped values into expressions where
   asyncpg could not infer `timestamptz`, `bigint` or `boolean`.
3. The production referral cursor query passed `None` for the first-page
   cursor without explicit PostgreSQL bind types.
4. One test expected 90 EFHC after a panel purchase although the canonical
   panel price is 100 EFHC and the seeded balance was 100 EFHC.
5. The same-user monetary lock used `FOR UPDATE SKIP LOCKED`, converting a
   valid parallel request into a false missing-user failure.

## Runtime repair

- Added explicit PostgreSQL casts to referral cursor binds.
- Replaced same-user `SKIP LOCKED` with blocking `FOR UPDATE`.
- Preserved idempotency checks inside the serialized transaction.
- Corrected integration seed SQL with explicit bind casts.
- Corrected the balance assertion to `0.00000000`.
- Applied the exact Ruff import and unused-name repairs.

## Regression protection

- Development structural guards require all cursor casts.
- Development guards require blocking monetary row locking.
- Integration tests retain replay, rollback and concurrency coverage.
- Packaged release acceptance protects the same production invariants.

## Proof boundary

Local regression is complete. The supplied release CI is green only for
v171.86. Fresh exact-HEAD GitHub CI is required for v171.87.

---

## Источник: `WORK_CYCLE_1591_CI_PLAN_AND_FRONTEND_AUDIT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work Cycle 1591 — CI plan guard and complete frontend audit

Status: `LOCAL_SCOPE_COMPLETE / BROWSER_PROOF_DEFERRED`.
Archive target: `v171.88`.
Routes: `ci_log_exact_failure_repair` and
`frontend_visual_route_backed_recovery`.
Fallback: `false`.

## Input evidence

- GitHub run `82110466270`: release archive, green.
- GitHub run `82109237157`: development archive, one Pytest failure.
- The development frontend install, typecheck and production build were
  green and listed 33 routes.

## Root cause

The failing PostgreSQL test asserted one exact planner-selected panel
index name. PostgreSQL used another valid indexed plan. This was a
flaky test contract, not a missing database index or runtime query
regression.

## Repair

- Parse PostgreSQL `FORMAT JSON` plan nodes.
- Require a referral index and any canonical `panels.tg_id` index.
- Preserve the `Limit` and index-access performance requirements.
- Add a guard forbidding restoration of the brittle raw string check.

## Frontend audit

- Reconciled all 34 physical page routes.
- Added missing documentation for `/app`, `/admin/system`, `/404` and
  `/500`.
- Added a machine visual manifest for 360, 390 and 430 px.
- Added a real `page.goto()` all-pages Chromium audit harness.
- Added a separate automatic non-blocking GitHub visual-evidence job;
  the blocking Canon job remains free of PNG evidence.
- Added physical-route/documentation/manifest parity guards.
- Preserved the canonical UI, six bottom buttons and page economics.

## Proof boundary

Relevant static frontend and route guards pass. Clean local frontend
installation was blocked by HTTP 503 from the configured package
registry, so exact v171.88 Chromium screenshots were not produced and
are not claimed. Fresh exact-HEAD development/release CI and the separate all-pages
visual-evidence workflow are required. PNG evidence remains outside
blocking Canon CI under the current visual-evidence boundary.

---

## Источник: `WORK_CYCLE_1592_ACTIV_STATUS_CANON_RUNTIME_GUARD.md`

# Work Cycle 1592 — Activ status canon and runtime consolidation

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.
Archive target: `v171.89`.
Routes: `ci_log_exact_failure_repair`,
`activ_status_permanence_runtime_guard` and
`archive_numbering_and_release_gate`.
Fallback: `false`.

## Input evidence

- GitHub run `82129404864`: exact v171.88 development archive, green;
  `2612 passed, 20 skipped` and all quality/build gates passed.
- GitHub run `82130816646`: exact v171.88 release archive, green;
  `13 passed` and all release gates passed.
- User specification: `TZ_activ_status_docs_and_control_test.md`.

## Confirmed runtime defect

The project had multiple technical definitions of one business status:

- `_count_active_referrals()` used `EXISTS` against current panel rows;
- `SQL_LIST_REFERRALS` used `panels_count > 0`;
- Admin user detail joined active panel rows;
- `admin_summary` and referral CRUD correctly used
  `referral_links.activated_at`.

Those definitions happened to agree while panel rows remained present,
but diverged after physical deletion. This contradicted the permanent
Activ event model.

## Repair

- Use `referral_links.activated_at IS NOT NULL` for every Activ consumer.
- Keep `panels_count` only as an informational UI value.
- Remove legacy Admin queries against `{SCHEMA_REF}.ref_links` and active
  panels; use the canonical `ReferralLink` ORM model.
- Synchronize Kernel, NORM, service comments and Pydantic descriptions.
- Increase fail-closed GitHub integration minimum from 24 to 25.
- Add one real PostgreSQL control test that deletes all panels after
  production first-panel activation and checks all public/Admin readers.

## Exploratory ambiguity scan

- Locale files contain only neutral panel-count labels; no locale defines
  Activ from current panel existence.
- Referral FAQ texts describe the first activation trigger and no repeat
  bonus; no correction was required.
- Grafana/dashboard NORM files contain visual/analytics terminology but
  no competing runtime definition of Activ.
- One additional ambiguity was found in Admin users runtime and repaired.

## Proof boundary

Targeted structural guards pass and 25 integration tests are collected.
The complete local exact-tree inventory finished in non-overlapping
bounded groups: `2704/2704`, `2532 passed`, `172 skipped`, `0 failed`,
`0 errors`. The monolithic command reached the sandbox time limit and is
not counted. The sandbox has no PostgreSQL service, so the destructive
integration case is not claimed as executed. Fresh exact v171.89 GitHub
CI is the required runtime proof.

---

## Источник: `WORK_CYCLE_1593_USER_ID_IDENTITY_AUDIT_GUARD.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work Cycle 1593 — user identity audit and architecture guard

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.
Archive target: `v171.90`.

## Scope

Cycle 1593 is the renumbered former planning cycle `0`.
It does not change the database schema or runtime ownership.

The completed scope is:

- repeat the `global_id` inventory from the exact v171.89 tree;
- remove local `0-15` labels from project cycle numbering;
- establish `user_id` and `global_id` architecture SSOT;
- add an explicit Telegram-specific allowlist;
- freeze the current legacy identifier surface as a maximum baseline;
- add a CI guard against new domain `global_id` usage;
- add a read-only reconciliation collector;
- add an exact Operator Kernel route for this migration.

## Confirmed inventory

The preliminary audit headline values were reproduced exactly for
their stated scopes:

- `2448` exact `global_id` occurrences in `backend/app`;
- `133` backend files;
- `1498` service occurrences;
- `398` route occurrences;
- `134` CRUD occurrences;
- `116` Telegram bot occurrences;
- `89` ORM model occurrences;
- `32` ORM fields in `29` tables;
- `336` Python functions with tracked parameters;
- `54` `Depends(get_current_global_id)` applications;
- `375` frontend source occurrences in `62` files;
- `712` test occurrences in `107` files;
- `1105` documentation occurrences in `267` files.

The generated line-level matrix classifies each tracked use as:

```text
DOMAIN_OWNER
DOMAIN_ACTOR
AUTH_IDENTITY
TELEGRAM_SPECIFIC
SOURCE_EVENT
LEGACY_COMPATIBILITY
TEST_ONLY
DOCUMENTATION
```

## Preliminary material corrections

The main correction is cycle numbering:

```text
0-15 = macro phases only
1593-1600 = foundation range
1601-1700 = detailed project roadmap
```

The preliminary counts remain useful when their exact scope is kept.
They are not a permission for blind text replacement.

The current physical user model remains:

```text
users.id INTEGER primary key
users.global_id BIGINT unique and not null
```

Cycle 1593 does not pretend that the target `users.user_id` already
exists. That change belongs to cycle 1594.

## Guard behavior

The guard records:

- `21` explicit Telegram-specific files;
- `179` legacy runtime files;
- `20` files using `get_current_global_id()`;
- exact maximum identifier counts for every baseline file.

A count may decrease during migration. Any increase or new file fails.

## Reconciliation boundary

The read-only collector contains the financial and identity queries.
No PostgreSQL URL was available in the local environment, therefore:

```text
status = NOT_RUN_DB_UNAVAILABLE
```

No database values or financial reconciliation are claimed.

## Runtime and schema boundary

Cycle 1593 changes no runtime owner, balance, panel, transaction,
wallet binding, referral, role or migration.

The target `users.user_id BIGINT` column remains deferred. Cycle
1594 intentionally hardens the UserId contract and negative guards
without adding the column.

Next completed cycle:

```text
1594 — UserId contract and negative guards
```

---

## Источник: `WORK_CYCLE_1594_USER_ID_CONTRACT_GUARDS.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work Cycle 1594 — UserId contract and negative guards

Status: `LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_CI_REQUIRED`.  
Source HEAD: `EFHC_Bot_v171_90.zip`.  
Target HEAD: `EFHC_Bot_v171_91.zip`.  
Exact Operator Kernel route: `user_id_contract_foundation`.

## 1. Completed scope

Cycle 1594 converts the provider-independent identity doctrine into an
executable, side-effect-free contract without changing database schema or
runtime ownership.

Implemented:

- internal `UserId` range `1..9999999999`;
- exact ten-digit external representation;
- separate `TelegramId`, `UserIdDisplay` and `ExternalUserId` types;
- strict parser, formatter and validator;
- rejection of booleans, floats, coercion, signs, whitespace and Unicode
  digits;
- V2 negative identity guard;
- semantic categories and sunset cycles for all legacy `global_id` runtime files;
- exact SHA-256 patch lock for protected schema and ownership files;
- current-doctrine and LEGACY compatibility tests;
- reconciliation V2 report metadata for source and target HEAD.

## 2. Explicit non-scope and patch boundary

Cycle 1594 does not:

- add or change an Alembic revision;
- add `users.user_id` to the ORM;
- modify `users.id` or `users.global_id`;
- change `AuthContext` or FastAPI dependencies;
- switch any domain owner read or write;
- change frontend ownership state;
- change balances, kWh, panels, finance, referrals, ranks or roles.

The patch-boundary manifest protects `485` files under models, migrations,
services, CRUD, routes, schemas and `frontend/src`. Generated cache files are
ignored explicitly and cannot create a false ownership-drift finding.

## 3. Executable type contract

The side-effect-free foundation is located in:

```text
backend/app/identity/__init__.py
backend/app/identity/types.py
```

Exports:

```text
UserId
TelegramId
UserIdDisplay
ExternalUserId
InvalidUserId
validate_user_id()
format_user_id()
parse_user_id()
```

The public notation is `^\d{10}$`. Runtime validation uses the stricter ASCII
implementation `^[0-9]{10}$`, so non-ASCII digit glyphs are rejected.
`0000000000` is forbidden. The module is not wired into ORM, DTO, routes or
domain services in this cycle.

## 4. Negative guard V2

The identity boundary blocks:

- growth of the tracked legacy identifier surface;
- any new `get_current_global_id()` dependency;
- direct and indirect `user_id = global_id` mixing;
- `UserId(global_id)` and provider-derived keyword or mapping values;
- `wallet_address`, `ton_wallet`, `canonical_address` or provider subject used
  as a system identifier;
- equivalent TypeScript assignments.

Final result:

```text
Telegram-specific allowlist files: 21
LEGACY runtime baseline files: 179
Tracked runtime files: 200
Files using get_current_global_id: 20
Semantic identity-mix offenders: 0
Guard result: PASS
```

## 5. Tests and evidence

### Collection

```text
Command: PYTHONPATH=backend python -m pytest --collect-only -q
Exit code: 0
Collected: 2740 unique tests
```

### Full local suite

The exact collection was split into eight non-overlapping node-id segments.
Each segment produced its own JUnit XML and exit-code file.

```text
2740 total
2568 passed
172 skipped
0 failed
0 errors
56.178 s aggregate JUnit time
```

Skip reasons:

```text
95 — EFHC_RUN_E2E=1 is required for browser E2E smoke tests
72 — DATABASE_URL/ASYNC_DATABASE_URL is required for PostgreSQL integration
4  — DATABASE_URL/ASYNC_DATABASE_URL is required for Postgres-only CI
1  — DATABASE_URL is not set
```

Summary:
`reports/generated/cycle_1594_pytest_summary_v171_91.json`.

JUnit:
`reports/junit/cycle_1594_full_chunk_01_v171_91.xml` through
`reports/junit/cycle_1594_full_chunk_08_v171_91.xml`.

### Targeted contract suite

```text
Command: PYTHONPATH=backend python -m pytest -q \
  tests/efhc_backend/identity/test_user_id_types.py \
  tests/architecture/test_user_id_contract_foundation.py \
  tests/architecture/test_identity_architecture_migration_guard.py \
  tests/architecture/test_global_id_access_contracts.py \
  tests/architecture/test_heal0045_global_id_identity_canon.py \
  tests/test_no_banned_identifiers.py
Exit code: 0
43 passed, 0 failed, 0 skipped
```

### PostgreSQL inventory

```text
Command: PYTHONPATH=backend python -m pytest -q -m integration --collect-only
Exit code: 0
25 integration tests collected; 2715 deselected
```

Runtime integration was not claimed:

```text
25 PostgreSQL integration tests skipped: database URL unavailable
3 collection-level skips: aiogram/psycopg unavailable
0 failed, 0 errors
```

### Other local checks

```text
compileall: exit 0
identity audit: exit 0
negative identity guard: exit 0
patch-boundary guard: exit 0
reconciliation: exit 3, NOT_RUN_DB_UNAVAILABLE
npm ci --offline: exit 1, required zod package was not cached
Ruff/Mypy/Bandit: NOT_RUN, executables unavailable
frontend typecheck/build/E2E: NOT_RUN, node_modules unavailable
```

## 6. Reconciliation

No data-changing operation exists in this cycle. The read-only reconciliation
collector returned:

```text
schema: EFHC_IDENTITY_RECONCILIATION_V2
source: EFHC_Bot_v171_90.zip
target: EFHC_Bot_v171_91.zip
status: NOT_RUN_DB_UNAVAILABLE
financial tolerance: 0.00000000
```

No database value is represented as checked locally.

## 7. Rollback

Rollback is source-only:

1. restore exact `v171.90` development and release archives;
2. remove the identity type foundation and V2 guard changes;
3. do not run a database rollback because no migration exists;
4. verify source archive SHA-256 and CRC.

## 8. Next cycle

```text
1595 — Backend UserId value type adoption planning
```

Cycle 1595 may expand unit-level use of the type contract but must not perform
an ORM/schema or domain-ownership switch outside its explicit patch boundary.

---

## Источник: `WORK_CYCLE_1595_USER_ID_VALUE_TYPE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLE 1595 — Backend UserId value type

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.
Source HEAD: `EFHC_Bot_v171_91.zip`.
Target HEAD: `EFHC_Bot_v171_92.zip`.
Exact route: `user_id_value_type_adoption`.
Historical target HEAD: `EFHC_Bot_v171_92.zip`.
Fallback: `false`.

## 1. Purpose

Cycle 1595 converts the cycle-1594 nominal aliases into immutable,
validated backend value objects and proves their unit-level contract.
It does not connect them to ORM ownership, FastAPI authentication,
domain services, DTOs or frontend state.

The approved boundary is:

```text
raw PostgreSQL integer
→ user_id_from_database()
→ UserId
→ format_user_id()
→ UserIdDisplay
```

The reverse external boundary is:

```text
strict ten-ASCII-digit string
→ parse_user_id()
→ UserId
→ user_id_to_database()
→ BIGINT-compatible integer
```

## 2. Implemented types

Authoritative module:

```text
backend/app/identity/types.py
```

Implemented:

- immutable `UserId` value object;
- immutable `TelegramId` value object;
- validated `UserIdDisplay` string subtype;
- strict `ExternalUserId` Pydantic-ready annotation;
- `validate_user_id()`;
- `validate_global_id()`;
- `validate_user_id_display()`;
- `format_user_id()`;
- `parse_user_id()`;
- `user_id_from_database()`;
- `user_id_to_database()`;
- `is_user_id()` and `is_global_id()` type guards.

`UserId` is deliberately not an `int` subclass. A raw integer,
`TelegramId`, provider subject or wallet address cannot silently pass
through formatting or database conversion functions.

## 3. Runtime boundary

Cycle 1595 keeps:

```text
users.id INTEGER primary key
users.global_id BIGINT unique not null
AuthContext.global_id
legacy domain reads by global_id
```

No identity type is imported by runtime code outside
`backend/app/identity/`.

No Alembic migration, ORM field, SQL ownership key, route dependency,
service signature, DTO or frontend owner was changed.

## 4. Active doctrine correction

Three active runtime comments incorrectly stated that `global_id` was the
permanent sole identifier. They now state that it is a `LEGACY runtime`
owner key until the assigned expand/backfill/read-switch cycles.

Only comments/docstrings changed. The protected Python AST remains
identical.

## 5. Negative and patch guards

Cycle guard:

```text
ops/identity/check_user_id_value_type_boundary.py
ops/identity/user_id_value_type_patch_boundary.json
```

The manifest protects `481` files:

- models;
- services;
- CRUD;
- routes;
- schemas;
- FastAPI dependencies;
- Alembic/migration files;
- frontend source.

Python files are protected by AST hashes with docstrings removed.
Non-Python files are protected by exact SHA-256. Therefore comments may
be corrected, while executable semantics cannot change unnoticed.

The guard also rejects:

- any runtime import of `app.identity` outside the identity package;
- any new protected runtime file;
- any protected semantic change;
- active runtime wording that calls `global_id` the permanent sole ID.

## 6. Financial and data invariants

Cycle 1595 performs no database write and no data migration.

It must not change:

- user count or ownership;
- main or bonus balance;
- kWh values;
- panels;
- transactions;
- deposits or withdrawals;
- referrals or rewards;
- wallet bindings;
- roles;
- idempotency and transaction locks.

Allowed financial drift remains `0.00000000`.

## 7. Rollback

Rollback is source-only:

1. restore exact `EFHC_Bot_v171_91.zip` and its release archive;
2. do not run Alembic downgrade;
3. do not restore PostgreSQL because no database change exists;
4. verify source archive SHA-256 and CRC.

## 8. Local verification

```text
2757 collected
2585 passed
172 skipped
0 failed
0 errors
54 targeted tests passed
25 PostgreSQL integration tests collected
```

The 25 PostgreSQL tests were skipped because no DB URL was available.
Ruff, Mypy and Bandit are unavailable locally. Offline `npm ci` failed
because the Zod tarball is absent from the cache, so frontend typecheck,
production build and real route-backed Chromium proof remain unverified.

## 9. Evidence paths

```text
reports/generated/cycle_1595_full_pytest_summary_v171_92.json
reports/generated/user_id_value_type_boundary_v171_92.json
reports/generated/global_id_domain_boundary_v171_92.json
reports/generated/user_identity_reconciliation_v171_92.json
reports/junit/cycle_1595_targeted_v171_92.xml
reports/runtime_logs/cycle_1595_*.txt
```

## 10. Next cycle

```text
1596 — External API/Pydantic UserId contract preparation
```

Cycle 1596 may prepare API schemas and OpenAPI contract tests but must
not switch current domain ownership before the expand/backfill gates.

---

## Источник: `WORK_CYCLE_1596_EXTERNAL_API_USER_ID_CONTRACT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLE 1596 — External API/Pydantic UserId contract

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.
Source HEAD: `EFHC_Bot_v171_92.zip`.
Target HEAD: `EFHC_Bot_v171_93.zip`.
Exact route: `user_id_api_contract`.
Fallback: `false`.

## Purpose

Prepare a strict provider-independent API contract without changing
active API payloads, ORM schema, AuthContext or domain ownership.

## Implemented contract

```text
ApiExternalUserId
PydanticUserId
UserIdRequest
UserIdResponse
```

The contract accepts exactly ten ASCII digits, rejects numeric coercion,
zero, Unicode digits, TelegramId and provider/wallet values, stores a
nominal UserId and emits a string with leading zeroes preserved.

## OpenAPI boundary

Future OpenAPI uses:

```text
type: string
format: efhc-user-id
pattern: ^[0-9]{10}$
minLength: 10
maxLength: 10
```

No integer alternative is allowed.

## Runtime boundary

No active route, existing DTO, ORM model, Alembic revision, SQL owner,
AuthContext, frontend owner or financial value changes in cycle 1596.

## Rollback

Restore exact v171.92 development and release archives. No Alembic
downgrade or PostgreSQL restore is required because no data/schema
change exists.

## Next cycle

`1597 — users.user_id expand migration design and PostgreSQL dry-run`.

## Final local evidence

```text
2781 collected
2609 passed
172 skipped
0 failed
0 errors
34 targeted API/Healer tests passed
25 PostgreSQL integration tests collected but not executed
```

Reconciliation is `NOT_RUN_DB_UNAVAILABLE`. Fresh exact-HEAD GitHub CI,
frontend build, real Chromium and live deployment proof remain open.

---

## Источник: `WORK_CYCLE_1597_USERS_USER_ID_EXPAND.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work cycle 1597 — users.user_id EXPAND

## Input

- Development HEAD: `EFHC_Bot_v171_93.zip`.
- Target HEAD: `EFHC_Bot_v171_94.zip`.
- Exact route: `user_id_expand_migration`.

## Implemented scope

- linear Alembic revision `0002` after `0001`;
- nullable `efhc_core.users.user_id BIGINT`;
- independent sequence `users_user_id_seq`;
- range and unique constraints;
- default allocation for newly created rows;
- PostgreSQL offline fresh/install and existing-schema DDL dry-run;
- exact patch boundary protecting domain ownership and finance.

## Explicit non-scope

- no historical-row backfill;
- no `global_id` nullability change;
- no primary-key switch;
- no AuthContext/routes/services/frontend read switch;
- no TON login activation;
- no financial data mutation.

## TON account decision

A valid future TON Proof may open an existing `user_id` or create a new
`user_id`. Connection without proof is not authentication. A conflict
never triggers automatic merge.

## Exit gate

- migration chain `0001 -> 0002` is valid;
- offline PostgreSQL DDL renders and passes static safety checks;
- model and migration contracts match;
- regression and archive gates are green;
- online PostgreSQL execution remains separately reported if unavailable.

## Final local evidence

- full collection: `2795`;
- full regression: `2623 passed`, `172 skipped`, `0 failed`, `0 errors`;
- PostgreSQL business integration: `25 skipped`, DB unavailable;
- Alembic PostgreSQL offline render: exit `0`;
- online PostgreSQL execution: `NOT_RUN_DB_UNAVAILABLE`;
- semantic domain dependency rows: `2054`;
- ORM `global_id` fields: `32`; service signatures: `336`;
- patch-boundary protected files: `476`; violations: `0`.

---

## Источник: `WORK_CYCLE_1598_USER_ID_LEGACY_ALIAS_HARNESS.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work cycle 1598 — LEGACY alias and migration harness

Status: `LOCAL_SCOPE_COMPLETE / POSTGRESQL_RECONCILIATION_REQUIRED`.
Source: `EFHC_Bot_v171_94.zip`.
Target: `EFHC_Bot_v171_95.zip`.
Exact route: `user_id_legacy_alias_harness`.

## Implemented

- Added explicit SQLAlchemy synonym
  `User.legacy_runtime_id -> User.id`.
- Registered the future compatibility mapping
  `User.id -> User.user_id` as inactive.
- Added a pure deterministic future-backfill planner.
- Added read-only preflight SQL and guarded future apply SQL.
- Added range, duplicate and planned-collision checks.
- Added fail-closed patch-boundary and regression tests.

## Backfill doctrine

Historical rows with `users.user_id IS NULL` are planned as:

```text
users.user_id = users.id
```

Rows with an already assigned `user_id` are preserved. `global_id`, wallet
address and provider subject never derive the system ID.

## Not performed

- no database connection;
- no backfill execution;
- no new Alembic revision;
- no `NOT NULL` or primary-key switch;
- no AuthContext, route, service, DTO or frontend read switch;
- no financial or domain-owner mutation.

## Alias lifecycle

- created: cycle `1598`;
- future `User.id -> User.user_id` activation: not before cycle `1603`;
- planned compatibility removal: cycle `1698`;
- allowed active scopes: migration harness, reconciliation and tests.

## Exit gate

The cycle is locally complete only when the alias/harness boundary,
`tg_id` boundary, exact migration chain and targeted tests are green.
Real PostgreSQL reconciliation remains a separate required gate.

## Final local evidence

- exact collection: `2808` tests;
- passed: `2636`;
- skipped: `172`;
- failed: `0`;
- errors: `0`;
- PostgreSQL business integration inventory: `25`;
- executed PostgreSQL business tests: `0`;
- reconciliation: `NOT_RUN_DB_UNAVAILABLE`;
- architecture suite: `2384 passed`, `6 skipped`;
- protected runtime files: `479`;
- boundary violations: `0`.

The six architecture skips are retained environment-dependent tests.
The full regression skips are PostgreSQL or browser dependent. No test
was removed, marked xfail or rewritten to hide a runtime failure.

## Next cycle

Cycle `1599` owns real PostgreSQL reconciliation, preflight execution
and controlled preparation for historical backfill. The apply SQL from
this cycle remains disabled until that gate is proven.

---

## Источник: `WORK_CYCLE_1599_POSTGRESQL_RECONCILIATION_GATE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1599 — PostgreSQL reconciliation gate

Исходный HEAD: `EFHC_Bot_v171_95.zip`.
Целевой HEAD: `EFHC_Bot_v171_96.zip`.

## Выполнено

- создан read-only PostgreSQL preflight;
- создан reconciliation gate с изоляцией `REPEATABLE READ`, `READ
ONLY`, `DEFERRABLE`;
- создан SQL-доказательный пакет без изменяющих запросов;
- создан patch-boundary на 478 runtime-файлов;
- создана русскоязычная инженерная норма и CI-guard;
- historical backfill и read switch оставлены выключенными.

## Фактический результат среды

PostgreSQL URL, сервер и синхронный драйвер отсутствуют. Docker и
Podman отсутствуют. Внутренний пакетный контур вернул HTTP 503.

Статус: `БЛОКИРОВАНО_СРЕДОЙ`.

Коллизии и финансовое расхождение на реальной базе не измерены.
Заполнение `users.user_id` запрещено.

## GitHub CI

GitHub CI не запускался по указанию пользователя. Основной пакет
изменений ещё не готов к итоговому CI-запуску.

---

## Источник: `WORK_CYCLE_1600_FOUNDATION_RANGE_CLOSURE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Рабочий цикл 1600 — закрытие диапазона 1593–1600

Исходный HEAD: `EFHC_Bot_v171_96.zip`.
Целевой HEAD: `EFHC_Bot_v171_97.zip`.

## Цель

Закрыть фундаментальный диапазон перехода от Telegram-зависимой модели
к каноническому `user_id`, не выдавая недоступную PostgreSQL-сверку за
выполненную и не включая historical backfill либо runtime read switch.

## Итог диапазона

- `1593` — независимый аудит `global_id` и архитектурные guards;
- `1594` — строгий контракт `UserId` и отрицательные guards;
- `1595` — номинальные backend-типы `UserId` и `TelegramId`;
- `1596` — изолированный внешний API/Pydantic-контракт;
- `1597` — nullable `users.user_id BIGINT`, sequence и Alembic `0002`;
- `1598` — явный LEGACY alias и render-only backfill harness;
- `1599` — read-only PostgreSQL reconciliation gate;
- `1600` — локальная приёмка фундамента и handoff в диапазон 1601–1700.

## Непреодолённая внешняя блокировка

Реальная PostgreSQL в доступной среде отсутствует. Поэтому не доказаны
коллизии, orphan-ссылки и финансовое расхождение на фактической базе.
Historical backfill и runtime read switch остаются запрещёнными.

## GitHub CI

GitHub CI не запускается. Основной пакет auth-миграции ещё не готов.
Команда `запусти тесты CI GitHub` должна быть выдана только после
интеграции auth core, TON Proof login, Telegram adapter и необходимых
PostgreSQL-контуров.

## Язык

Новые и изменяемые тесты, отчёты, документы, docstring и авторские
комментарии оформляются на русском языке. Технические идентификаторы и
внешние протоколы не переводятся.

## Следующий этап

Цикл `1601 — открытие диапазона и приёмка фундамента` начинается с
`EFHC_Bot_v171_97.zip`. Следующая изменённая версия — `v171.98`.
