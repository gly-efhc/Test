# Цикл 1632 — pre-release migration squash

Цикл завершён.

## Результат

- active Alembic lineage содержит только
  `0001_initial_release_schema.py`;
- migration сразу создаёт physical `users.global_id`;
- 38 owner FK направлены на `users(global_id)`;
- sequence, auth/identity runtime и telemetry создаются в `0001`;
- historical revisions `0002–0013` не исполняются и не входят в
  production release;
- старые pre-release базы требуют clean recreate или restore snapshot.

## Подтверждение

Fresh CI `83372708711` успешно применил `0001` на clean PostgreSQL.
Дальнейшая exact-head и live qualification выполняется циклом `1633`.
