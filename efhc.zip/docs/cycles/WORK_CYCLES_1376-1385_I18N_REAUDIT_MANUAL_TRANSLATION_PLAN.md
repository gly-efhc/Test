# Work cycles 1376-1385 — i18n reaudit and manual translation plan

Status: ACTIVE PLAN.
Source audit: `docs/audits/I18N_REAUDIT_REPORT_V169_54_2026_06_03.md`.
Start archive: `EFHC_Bot_v169_54_chat_24_loaded.zip`.

## Control rule

All translation work after the v169.54 reaudit is manual. No machine bulk-fill,
no English-to-Russian back-translation, and no sandbox-label copying are allowed.
The semantic source remains verified Russian meaning: direct user decisions,
`docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`, FAQ approval layer and Russian
FAQ/SSOT when aligned with Q/A.

## Audit intake summary

The new reaudit confirms that critical i18n findings C1-C4 are closed:
English-first fallback is restored, Hindi placeholder drift is fixed, empty
locale values are fixed, FAQ identical-answer tail is closed, and
`TRANSLATION_STATUS.md` is no longer a false complete claim.

Open work remains:

- 154 public untranslated keys in DE/FR/HI/SW/TR/PL/DA/IT/ES/ID;
- UK public translation tail: CLOSED in cycle 1377;
- `1 kWh = 1 EFHC` formula allowlist treatment: CLOSED in off-queue v169.56;
- `tasks.earning_kicker` and `tasks.demo_daily_detail` game framing: CLOSED in off-queue v169.56 with neutral earning wording;
- two audit scripts clean-checkout preconditions: CLOSED in off-queue v169.56;
- fallback-chain regression guard: CLOSED in off-queue v169.56 and retained for future runs.

## Planned cycles

| Cycle | Target | Scope | Translation mode |
|---:|---|---|---|
| 1376 | I18N reaudit intake + precondition repair | Import reaudit, update cycle/docs, allowlist formula, remove game framing from two task keys, add fallback guard, restore audit script preconditions. | Manual micro-edit only |
| 1377 | UK public translation pass | DONE in v169.57: UK public tails in `public_engagement`, `profile`, `portal`, `energy`, plus small trust/wallet residuals detected by the quality guard. | Manual Ukrainian |
| 1378 | Wave-3 public engagement pass | DONE in v169.58: DE/FR/HI/SW/TR/PL/DA/IT/ES/ID `public_engagement` keys. | Manual per language |
| 1379 | Wave-3 portal/shop pass | DONE in v169.59: Browser Shop / portal / shop_entry keys. | Manual per language |
| 1380 | Wave-3 profile and trust pass | DONE in v169.60: `profile` + `public_profile_trust` guarded public account/trust keys. | Manual per language |
| 1381 | Wave-3 panels/tasks/history pass | DONE in v169.61: `panels`, `tasks`, `history` guarded public UI keys. | Manual per language |
| 1382 | Wave-3 hub/energy/wallet/ranks/referrals tail | Remaining small domains and identical-to-English triage. | Manual per language |
| 1383 | FAQ/i18n semantic gate rerun | Re-run FAQ and locale semantic guards, update translation status. | Review only |
| 1384 | Browser text stress plan | Prepare screenshot/text-overflow evidence plan only; no screenshot claim unless captured. | Review only |
| 1385 | i18n range closure audit | Static/source closure for the manual language range. | Audit only |

## Non-claims

This plan does not claim full translation completion, human linguistic
certification, GitHub CI green, browser screenshots, live Telegram client proof,
or release readiness.

## Off-queue v169.56 process correction

The user requested an out-of-order correction before regular manual translation
continues. It does not consume 1377. The correction locks the i18n process:

- audit scripts must run in clean checkout by default; `--strict` is used only
  when historical work-pass report validation is intentionally required;
- fallback-chain regression is guarded by `tests/architecture/test_i18n_fallback_is_english.py`;
- `1 kWh = 1 EFHC` is a protected rate formula in the identical-value allowlist;
- `game task` is not a forbidden phrase. Neutral earning/action wording
  was preferred there as tone guidance, while the actual ban remains
  gambling, loto, betting and random financial meaning.

Manual translation order remains unchanged: first UK, then narrow wave-3 domain
passes from verified Russian meaning.


## Cycle 1377 result — v169.57

The UK pass was completed manually from verified Russian meaning. It did not auto-translate wave-3 languages. The pass changed `frontend/public/locale/uk.json` only for Ukrainian text plus the UK quality guard.

Scope closed:

- 79 Ukrainian public-facing values reviewed/translated;
- `public_engagement`: ranks, referrals, tasks and tab labels;
- `profile`: account, wallet and history labels;
- `portal`: browser-shop/shop-entry explanatory text;
- `energy`: interactive hints;
- `public_profile_trust` and `wallet`: Russian-tail cleanup;
- protected exact values handled by allowlist: `truth-path`, `1 kWh = 1 EFHC`, `TON`, `kWh`.

Next regular cycle: 1378 — wave-3 `public_engagement` manual translation pass.


## Cycle 1378 result — v169.58

The wave-3 `public_engagement.*` pass was completed manually from verified Russian meaning for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID.

Scope closed:

- 43 public engagement keys per language;
- 430 manual locale values updated;
- rank focus, referral growth, tab labels and task flow preview copy;
- no English-identical values remain inside the wave-3 `public_engagement.*` domain;
- `ops/i18n/audit_wave3_public_engagement_locale_quality.py` added as the narrow domain guard.

Next regular cycle: 1379 — wave-3 portal/shop manual translation pass.

Future planning note: `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md` was added as a draft/reserved future range and is not active while 1376-1385 remains open.


## Cycle 1379 — wave-3 portal/shop manual translation pass

Status: DONE in v169.59.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public portal/shop prefixes: `portal.browser_shop.*` and `portal.shop_entry.*`.
- Manual values changed: 340.
- Guard: `ops/i18n/audit_wave3_portal_shop_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_portal_shop_manual_translation.py`.

Result: the guarded portal/shop domain has 0 unexpected English-identical values
and 0 Cyrillic tails. `TON` remains an exact-value allowlist exception, not a
translation debt.

Next planned cycle: `1380 — wave-3 profile/public-profile-trust manual translation pass`.


## Cycle 1380 — wave-3 profile/public-profile-trust manual translation pass

Status: DONE in v169.60.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public account/profile prefixes: `profile.*` and `public_profile_trust.*`.
- Guarded domain keys: 152 after allowlist and `profile.lang.*` / `profile.reason.*` exclusions.
- Manual values reviewed by the guard: 1520.
- Manual values updated in this pass: 430.
- Guard: `ops/i18n/audit_wave3_profile_trust_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_profile_trust_manual_translation.py`.

Result: the guarded profile/trust domain has 0 unexpected English-identical
values and 0 Cyrillic tails. `profile.lang.*` native language names and
`profile.reason.*` reason labels remain out of this narrow translation debt via
the shared allowlist policy.

Next planned cycle: `1381 — wave-3 panels/tasks/history manual translation pass`.


## Cycle 1381 — wave-3 panels/tasks/history manual translation pass

Status: DONE in v169.61.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public prefixes: `panels.*`, `tasks.*`, `history.*`.
- Guarded domain keys: 133 after shared exact-value and prefix allowlist exclusions.
- Manual values checked by the guard: 1330.
- Manual values updated in this pass: 410.
- Guard: `ops/i18n/audit_wave3_panels_tasks_history_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_panels_tasks_history_manual_translation.py`.

Result: the guarded panels/tasks/history domain has 0 unexpected
English-identical values and 0 Cyrillic tails. EFHC/kWh and other protocol
values remain governed by the shared allowlist policy.

Next planned cycle: `1382 — wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass`.


## Cycle 1382 — wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass

Status: DONE in v169.62.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public prefixes: `hub.*`, `energy.*`, `wallet.*`, `ranks.*`, `referrals.*`.
- Guarded domain keys: 176 after shared exact-value and prefix allowlist exclusions.
- Manual values checked by the guard: 1760.
- Manual values updated in this pass: 200.
- Guard: `ops/i18n/audit_wave3_hub_energy_wallet_ranks_referrals_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_hub_energy_wallet_ranks_referrals_manual_translation.py`.

Result: the guarded hub/energy/wallet/ranks/referrals tail has 0 unexpected
English-identical values and 0 Cyrillic tails. EFHC/kWh/TonConnect and other
protocol values remain governed by the shared allowlist policy.

Next planned cycle: `1383 — i18n manual coverage consolidation and remaining-tail audit`.


## Cycle 1383 — i18n manual coverage consolidation

Status: DONE in v169.63.

Scope:

- Consolidated manual translation passes 1377-1382.
- Added `ops/i18n/audit_i18n_manual_coverage_consolidation.py` as a cross-locale static/source guard.
- Manually fixed two remaining Hindi English-tail values:
  - `browser_login.badge`;
  - `exchange.receive_label`.
- Confirmed that only controlled protocol/brand/formula values and key-specific UI abbreviations remain identical to English.

Result:

- Languages checked: 12 non-English locale bundles.
- Values checked after exclusions: 11652.
- Unexpected English-identical values: 0.
- Wave-3 Cyrillic tails: 0.
- Human linguistic certification: NOT CLAIMED.

Next planned cycle: `1384 — browser text stress plan / screenshot-readiness planning only`.


## Cycle 1384 — i18n browser text stress / screenshot-readiness planning

Status: DONE in v169.64.

Scope:

- Converted the completed manual translation repair lane into a route × locale × device text-stress readiness matrix.
- Added `ops/i18n/audit_i18n_browser_text_stress_readiness.py`.
- Generated `reports/generated/i18n_browser_text_stress_readiness_v169_64.json`.
- Matrix: 14 public routes, 13 locales, 3 device/shell contexts = 546 planned combinations.
- This is planning-only. No screenshots, browser visual verdict, GitHub CI green, release-ready status or human linguistic certification are claimed.

Next planned cycle: `1385 — i18n range closure and next visual/browser-evidence handoff`.

## 1385 — CI logs repair / i18n range closure

Status: DONE. The manual i18n repair range 1376–1385 is closed at source/static level after the uploaded CI logs repair pass. Browser screenshots remain future evidence work.


## Post-range cycle 1386 — CI logs repair and test-execution correction

Status: DONE in v169.66. This cycle is outside the closed 1376–1385 manual i18n lane and responds to a new user-provided CI log. It repairs the pytest mass-skip root cause, Alembic model metadata schema drift and the Next `/app` prerender blocker.
