# Work Cycle 1424 — Withdraw refund atomicity and exchange TOCTOU repair

Date: 2026-06-04.

HEAD input: `EFHC_Bot_v169_98_cycle_1423_panel_atomicity_repair.zip`.
HEAD output: `EFHC_Bot_v169_99_cycle_1424_withdraw_exchange_atomicity_repair.zip`.

## Goal

Repair the remaining P1 economic audit findings:

- `FIND-003`: `cancel_withdraw` and `admin_reject_withdraw` committed final
  status separately from refund.
- `FIND-005`: exchange helpers performed idempotency read-through before the
  user row lock, leaving a same-key race window.

## User decisions

The user confirmed:

- option `B` for `FIND-003`: one `_tx_context`, nocommit refund and one commit;
- yes for `FIND-005`: move idempotency check inside the lock/retry loop and add
  rollback guard at entry.

## Read before edit

- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`
- `ops/operator_kernel/config/routes.yaml`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/audits/P0_ECONOMIC_AUDIT_TRANSACTIONS_SERVICE_V169_91.md`
- `docs/cycles/WORK_CYCLES_1423_PANEL_ATOMICITY_REPAIR.md`
- `map_element.md`

Kernel preload was available. `routes.yaml.version` remained `1`.

## Repair applied

### 1. Nocommit MAIN refund helper

File:

`backend/app/services/transactions_service.py`

Added:

`credit_user_from_bank_nocommit`

Purpose:

- credit MAIN balance from bank without committing;
- allow withdraw final status, refund transfer log and `refund_done=TRUE` to be
  committed or rolled back together;
- preserve idempotency read-through by refund key.

### 2. Withdraw cancel/reject atomic refund

File:

`backend/app/services/withdraw_service.py`

`cancel_withdraw` and `admin_reject_withdraw` now:

1. enter one `_tx_context`;
2. lock the withdraw request row with `FOR UPDATE`;
3. transition to final status when the row is still `PENDING`;
4. call `credit_user_from_bank_nocommit` for the refund when needed;
5. set `refund_done=TRUE`;
6. rely on one surrounding commit.

The old split-commit pattern was removed from both functions.

### 3. Exchange TOCTOU repair

File:

`backend/app/services/transactions_service.py`

`exchange_partial_available_kwh_to_main` and
`exchange__all__available_kwh_to_main` now:

- close preflight/autobegin state with an entry rollback guard;
- acquire the user row lock first;
- only then check idempotency by `idempotency_key`;
- perform balance and `exchanged_kwh_total` updates only after same-key
  read-through is ruled out under the lock.

This removes the pre-lock idempotency race window.

## Tests / guards

Updated active guard:

`tests/architecture/test_economic_risk_guards.py`

New protected checks:

- `test_withdraw_cancel_and_reject_refund_are_atomic`
- `test_exchange_idempotency_check_inside_lock_retry_loop`

Existing cycle 1422 and 1423 checks remain active.

## Local checks

Targeted economic guard:

```text
PYTHONPATH=backend python3 -m pytest -q tests/architecture/test_economic_risk_guards.py
6 passed
```

Broader architecture pack was run before final archive creation. Results are
recorded in the cycle report.

## Sandbox / map_element use

`map_element.md` and the uploaded sandbox archives were used only as
reference/navigation context. Runtime code, CI files, lock files, wallet/payment
logic, translations and foreign economy were not imported.

## Not claimed

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full npm build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect/wallet proof.

## Status

`FIND-003` and `FIND-005` are repaired and guarded.

Remaining economic audit plan:

- cycle `1425`: `FIND-006..010` cleanup and reconciliation hardening.
