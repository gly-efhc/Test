# WORK CYCLES 1182-1200 FIX PLAN

## Current rule

The goal is not to produce cycles.  The goal is to repair the road-audit
errors.  Cycles only exist to keep the repair order clear and auditable.
Do not split work when one cycle can honestly close several related
findings.

## Cycle 1182

Runtime OpenAPI repair gate.  The helper must try to export the actual
FastAPI OpenAPI schema.  If runtime dependencies are absent, it must
write an explicit blocker instead of claiming release readiness.

## Cycle 1183

Frontend/backend contract repair.  Sensitive generated frontend seams
must be checked against backend route decorators for missing route and
method drift.

## Cycle 1184

ORM versus Alembic 0001 repair.  Expand 0001 critical-column sanity and
add a dependency-free guard proving the critical economic columns are in
ORM and in the 0001 gate.  Do not create pre-release `0002`.

## Cycle 1185

Canonical profile route repair.  Completed as code repair: `/user/me` is
the only active self-profile route and `/user/{global_id}/me` was removed
after consumer checks found no frontend dependency.

## Cycle 1186

Panels-summary orphan repair.  Completed as code repair:
`/user/me/panels-summary` is the active self-route and the old tg-id
path
was removed from active backend code after consumer checks.

## Cycle 1187

Withdraw economic road repair.  Completed as code repair: user list uses
auth as source of truth, legacy `global_id` is only an optional self-check,
admin approve has same-key PAID replay and explicit commit, and a guard
proves hold, refund, outcome and contract anchors.

## Cycle 1188

Deposit and watcher truth repair.  Completed as code repair: the
owner-only payment-intent status route now returns 404 when the service
returns `ok = false`, strips the internal `ok` marker before the public
response model, and a guard verifies watcher, tx hash lock,
reconciliation, exact amount, intent status and flow-truth anchors.

## Cycle 1189

Exchange economic road repair.  Completed as code repair: active
exchange routes are self-routes.  Frontend generated seams no longer
carry path `global_id`.  The stale user exchange preview alias was removed,
and a guard proves exchange economic-road anchors.

## Cycle 1190

Panel activation economic road repair.  Completed as code repair:
activation is a self-route, the buy/path-tg-id aliases were removed,
frontend calls the canonical route, and activation audit meta proves
bonus-first spend details.

## Cycle 1191

Shop and payment truth repair.  Completed as code repair: external shop
order routes now reject incomplete payloads and missing order ids, and
Browser-Shop intent status returns 404 for non-owned or missing intents
while stripping internal service markers from the public schema.

## Cycle 1192

Admin bank action repair.  Completed as code repair: mint and burn now
resolve admin through RBAC by global_id, pass an admin object to the bank
service, commit before success, and return current bank balance.

## Cycle 1193

False UI road repair.  Completed as code repair for panels-summary: the
panels UI now calls the canonical self summary route, and the stale
tg-id summary route was removed from active backend, OpenAPI and route
SSOT maps.

## Cycle 1194

Helper/internal boundary repair.  Completed for cron and Telegram
webhook roads: both routes remain active runtime endpoints, but are
hidden from OpenAPI and marked internal in route SSOT maps.

## Cycle 1195

Visual audit intake and plan remap after the imported visual audit.
Completed in v168_17 as audit import, audit-of-audit, public UI NORM and
1195-1230 repair plan.

## Cycle 1196

Profile language runtime repair.  Completed in v168_18: selected
language now drives the runtime UI dictionary, while Russian stays the
fallback and settings persistence waits for hydration.

## Cycle 1197

Profile language selector and guard repair.  Completed in v168_18: the
selector is now a horizontal language bar and a guard proves dictionary
loading, hydration safety and bottom-menu English canon.

## Cycle 1198

Road registry guard.  Produce a repeatable method/path to handler
map and
fail on duplicate active method/path definitions.

## Cycle 1199

Release readiness evidence audit.  Summarize only proven repairs and
separate blockers from completed fixes.

## Cycle 1200

Corrected range verdict.  Close the range only if the evidence supports
it.  If not, hand off the exact blockers to the next range.

## Visual audit correction after v168_17

Cycle 1195 is remapped to visual audit intake and 1195-1230 planning.
The previous contract-test repair remains required, but the new audit
proves higher priority public UI blockers. Cycle 1200 must be only a
bridge verdict if those blockers are still open.

## v168_19 correction for 1198-1199

The visual audit priority remap is now reflected in real code:

- 1198 fixed the public Direct Deposit modal.
- 1199 added the direct backend wallet-open route.
- Contract-test work remains necessary, but it must follow the repaired
  visual road rather than documenting the old mixed road.
