# WORK CYCLES 401-500

## Cycles 401-405 — Log-driven healing wave 01

Этот блок открыт после закрытия диапазона `391-400`.

Смысл блока:
1. разобрать свежие CI-логи;
2. исправить подтверждённые code/test defects без обхода тестов;
3. закрепить новый active range `401-500` как рабочий диапазон проекта.

- Done: 5/5
- Remaining: 0/5
- Last completed cycle: 405/405
- Next cycle: 406/500
- Block status: deferred until 428-431 close

- 401/405 — done — проведён аудит `logs_63459983461.zip`: подтверждён code/test cluster в `shop_external` confirm path и два падающих runtime tests.
- 402/405 — done — watcher `shop_external` confirm выровнен под реальную `shop_orders` схему: убрана зависимость от несуществующего `item_id`, credit path переведён на `order.type` + `quantity_efhc`.
- 403/405 — done — runtime tests обновлены под каноничную `shop_orders` схему и Postgres-friendly DDL без обхода test logic.
- 404/405 — done — свежий full `PYTHONPATH=backend pytest -q` по HEAD проходит после fix-wave.
- 405/405 — done — cycle docs и reports обновлены, новый active range `401-500` включён в index.

## Cycles 406-407 — Log-driven healing wave 02

Этот блок открыт после закрытия лечебной волны `401-405`.

Смысл блока:
1. разобрать новый логовый пакет `logs_63462428279.zip`;
2. снять оставшийся stale runtime drift в `shop_external` happy-path;
3. подтвердить fix-wave свежим full pytest proof без обхода тестов.

- Done: 2/2
- Remaining: 0/2
- Last completed cycle: 407/407
- Next cycle: 408/500
- Block status: active

- 406/407 — done — проведён аудит `logs_63462428279.zip`: подтверждён один оставшийся runtime failure в `test_watcher_confirm_shop_external_with_order_marks_paid_auto`, вызванный stale `shop_items.item_type`/`extra_json` test-schema drift.
- 407/407 — done — stale runtime test приведён к каноничной `shop_items`/`shop_orders` схеме; после fix-wave подтверждён свежий full `PYTHONPATH=backend pytest -q` → 316 passed, 29 skipped.

## Cycles 408-409 — Log-driven healing wave 03

Этот блок открыт после закрытия лечебной волны `406-407`.

Смысл блока:
1. разобрать новый логовый пакет `logs_63515302723.zip`;
2. снять реальный runtime drift в `watcher_service`, который снова тянул legacy `shop_items.item_id` path;
3. подтвердить fix-wave свежим полным test proof без обхода тестов.

- Done: 2/2
- Remaining: 0/2
- Last completed cycle: 427/429
- Next cycle: 428/500
- Block status: active

- 408/409 — done — проведён аудит `logs_63515302723.zip`: подтверждён один runtime failure в `shop_external` happy-path, вызванный обращением к несуществующему `item_id` в row mapping внутри `watcher_service`.
- 409/409 — done — `watcher_service` выровнен под каноничный путь `shop_orders.type + quantity_efhc`; после fix-wave подтверждён свежий полный `PYTHONPATH=backend pytest -q` → 316 passed, 29 skipped.

## Cycles 410-429 — Full audit import, audit-of-audit, and code healing plan 01

Этот блок открыт после закрытия лечебной волны `408-409`.

Смысл блока:
1. зафиксировать свежие зелёные логи `logs_63523097203.zip` как baseline;
2. импортировать новый жёсткий аудит HEAD-архива в раздел `docs/audits`;
3. провести аудит аудита: разделить уже снятые и ещё живые дефекты по коду;
4. разложить лечение кода в 20 последовательных циклов без обхода тестов.

- Done: 18/20
- Remaining: 2/20
- Last completed cycle: 427/429
- Next cycle: 428/500
- Block status: active

- 410/429 — done — зелёный log baseline `logs_63523097203.zip` зафиксирован и привязан к текущему HEAD.
- 411/429 — done — новый единый жёсткий аудит HEAD-архива импортирован в `docs/audits`, индекс и отчёты обновлены.
- 412/429 — done — проведён audit-of-audit по ECO-001..ECO-008; зелёные логи отделены от ещё живых глубоких дефектов в коде.
- 413/429 — done — exchange paths переведены на `bank_balance` SSOT: реальные движения банка через `users.tg_id = BANK_EFHC` убраны из exchange-функций, BANK_EFHC оставлен только для mirror-log.
- 414/429 — done — spend/panel/shop paths переведены на единый `bank_balance` SSOT через `spend_user_to_bank_bonus_then_main`, без реального обновления банка как `users.tg_id = BANK_EFHC`.
- 415/429 — done — bank mirror в spend path исправлен на `credit`; добавлены guards, подтверждающие инвариант user-debit ↔ bank-credit и отсутствие split-brain в spend-слое.
- 416/429 — done — idempotency write-path ужесточён: silent conflict теперь поднимает `IDEMPOTENCY_CONFLICT`, прямые денежные пути делают rollback и возвращают read-through вместо повторного изменения балансов.
- 417/429 — done — manual `db.begin()` / `BEGIN IMMEDIATE` убраны из exchange-функций; exchange-paths больше не держат прямой autobegin violation в transactions layer.
- 418/429 — done — рекурсивный `_begin_tx` в `energy_service` исправлен: при пустой транзакции открывается `db.begin()`, а не повторный вызов `_begin_tx`.
- 419/429 — done — broken SQL в `sync_routes._enqueue_resync_energy` исправлен: `await db.commit()` вынесен из SQL-строки и выполняется после `execute`.
- 420/429 — done — SQL syntax drift в `shop_service` снят: трейлинг-запятые удалены из обоих `shop_orders` insert paths, добавлен source guard против возврата ошибки.
- 421/429 — done — активные shop order/runtime paths выровнены под каноничную схему `shop_items.sku + quantity_efhc + extra` и `shop_orders.type + quantity_efhc + expected_amount + idempotency_key + extra`; legacy `item_id/payment_method/client_order_id` убраны из create/list/purchase core flows shop_service.
- 422/429 — done — `watcher_service` для `shop_external` теперь сначала атомарно переводит `shop_orders` из `PENDING` в `PAID_AUTO` с `RETURNING`, и только после этого подтверждает `payment_intent`; снят fail-open drift, при котором intent мог подтверждаться без доказанного order-side effect.
- 423/429 — done — введён guard-proof, что в `transactions_service` больше не осталось реальных bank-user update paths через `BANK_EFHC`; `BANK_EFHC` сохраняется только как алиас для mirror-log.
- 424/429 — done — создана документная/аудиторская таблица reconciliation банка и пользователя, а тестовый слой привязан к её инвариантам: `bank_balance` закреплён как единственное SSOT банка.
- 425/429 — done — создана документная/аудиторская база concurrency/idempotency proof и runtime tests выровнены под bank_balance как единственное SSOT банка; повторные вызовы с тем же idempotency-key доказаны без повторного движения балансов.
- 426/429 — done — создан self-healing audit по всем трём зонам: energy generation, snapshot resync и scheduler recovery; добавлены guards и test hygiene fix для временного canon-файла, чтобы full-suite не ломался от leftover test artifact.
- 427/429 — done — подготовлен audit со списком кандидатов на удаление старых GitHub CI log-документов из active audit-surface; deletion пока не выполнен до отдельного согласования пользователя.
- 428/429 — partially_done — backend/document actualization выполнена частично; обязательная frontend/UI часть цикла не выполнена, потому что песочница для визуальных элементов ещё не была получена от пользователя. Остаток перенесён в 428/500 и связан с будущей UI correction wave.
- 429/429 — partially_done — предварительный re-audit выполнен, но финальное закрытие цикла признано преждевременным, потому что 428 не был завершён полностью. Остаток финального re-audit перенесён в 429/500 после закрытия визуальной и документной части.

- 430/500 — planned — провести аудит чата, архива и обновить, дополнить и актуализировать болезни Healer.
- 431/500 — planned — провести аудит архива и предложить список на удаление старых мусорных аудитов.


## Cycles 428-431 — Correction wave for misclosed cycles

Этот блок открыт после обнаружения, что циклы 428 и 429 были закрыты преждевременно.

Смысл блока:
1. восстановить честный статус по циклам 428 и 429;
2. выполнить обязательный перенос незавершённых частей в новые номера;
3. закрыть Healer / archive cleanup циклы, которые пользователь просил выполнить до нового большого блока.

- Done: 4/4
- Remaining: 0/4
- Last completed cycle: 431/500
- Next cycle: none — correction wave closed
- Block status: done

- 428/500 — done — пользовательская песочница получена и visual/frontend actualization выполнена по активным точкам (`admin/tasks`, `AdsBanner`, `ReferralsTabs`, `DepositModal`); создан `FRONTEND_SANDBOX_VISUAL_ACTUALIZATION_2026_04_07.md`. TypeScript proof (`npx tsc --noEmit`) подтверждён, а отдельный frontend build proof вынесен в `446/451`.
- 429/500 — done — выполнен финальный re-audit после реального закрытия 428/500; создан `REAUDIT_AFTER_SANDBOX_428_429_2026_04_07.md`.
- 430/500 — done — проведён аудит чата/архива и хронические ошибки перенесены в Healer / registries как correction wave consolidation.
- 431/500 — done — проведён audit архива и подготовлен список старых мусорных аудитов в формате оставить / перенести в artifacts / удалить после согласования: `AUDIT_ARCHIVE_TRIAGE_2026_04_07.md`.

## Cycles 432-451 — Residual technical healing plan 02

Этот блок открыт сразу после re-audit цикла `429/429`, потому что в коде и продуктовой поверхности ещё остались живые технические дыры.

Смысл блока:
1. дочистить residual legacy shop/read/reporting слой;
2. пройтись по живым фронтенд/UI проблемам из последнего жёсткого аудита;
3. завершить release-purity cleanup после согласованных deletions и re-audit.

- Done: 16/20
- Remaining: 4/20
- Last completed cycle: 449/451
- Next cycle: 450/500
- Block status: active

- 432/451 — done — проведён residual shop read/reporting audit: `RESIDUAL_SHOP_READ_REPORTING_AUDIT_2026_04_07.md`.
- 433/451 — done — `admin_list_orders` переведён с legacy `item_id`/`shop_items` чтения на каноничные поля `shop_orders` + `extra`.
- 434/451 — done — watcher/reporting helper paths partially aligned to canonical shop schema; created `WATCHER_REPORTING_ALIGNMENT_2026_04_07.md`.
- 435/451 — planned — add runtime/reporting tests for cleaned shop read/reporting layer.
- 436/451 — done — findings from the strict audit imported into active healing checklist: `FRONTEND_STRICT_AUDIT_HEALING_CHECKLIST_2026_04_07.md`.
- 437/451 — done — sandbox-assisted visual inconsistency map prepared: `FRONTEND_VISUAL_INCONSISTENCY_MAP_2026_04_07.md`.
- 438/451 — done — priority frontend touchpoint `BrowserShopPage` actualized for loading/error/empty and placeholder drift.
- 439/451 — done — user-facing wording in `BrowserShopPage` aligned to Russian storefront language and Telegram handoff semantics.
- 440/451 — done — подготовлен Healer transfer по старым GitHub CI log-audits: `GITHUB_CI_LOGS_HEALER_TRANSFER_2026_04_07.md`.
- 441/451 — done — подготовлен deletion/triage batch для старых GitHub CI log-аудитов; фактическое удаление остаётся только после согласования пользователя.
- 442/451 — done — найден реальный release-path defect: архивы собирались в обход штатного cleanup/build flow, а `ops/cleanup_artifacts.py` не чистил `.ruff_cache` и `.local_artifacts`; добавлены строгий cleanup-rule в AI docs, staging-based сборка ZIP и guards на cleanup path; параллельно зафиксирован audit слоя `docs/audits/_raw` (`AUDIT_RAW_DEBT_LIST_2026_04_07.md`).
- 443/451 — done — исправлены рекурсивные `_begin_tx` residuals в `referral_service`, `wallet_binding_service` и `tasks_service`; добавлен architecture guard против self-recursive transaction openers.
- 444/451 — done — dependency-precheck актуализирован честно: локально перепроверены `pytest` и `compileall`, а `ruff` / `mypy` / `bandit` / `sqlalchemy` / `aiosqlite` зафиксированы как явные средовые блокеры этой runtime-среды.
- 445/451 — done — добавлен reporting guard на `admin_list_orders`: чтение заказов закреплено за `shop_orders` + `extra` без возврата к legacy `item_id`/`shop_items` join.
- 446/451 — done — вылечен nested-release-zip рецидив: build staging больше не захватывает предыдущий `efhc.zip`; добавлены pre-stage delete и явный rsync-exclude для `ZIP_OUT`.
- 447/451 — done — по `logs_63696356957.zip` вылечены architecture/doc/build drifts: BrowserShop MVP lock актуализирован под текущую TON витрину, cycle/build tests приведены к текущему staging-based release path, line72 violations убраны.
- 448/451 — done — `exchange_all_available_kwh_to_main` получил read-through на `IDEMPOTENCY_CONFLICT`, чтобы concurrency path не падал повторным исключением вместо идемпотентного возврата.
- 449/451 — done — CI log-wave зафиксировал и усилил правило ownership: GitHub CI делает пользователь; AI docs актуализированы, а `test_concurrency_exchange_withdraw.py` переведён на честный canonical setup пользователя перед exchange/withdraw race.
- 450/451 — planned — final residual tech re-audit after the current log-driven wave.
- 451/451 — planned — prepare final truth summary and close block, or honestly open the next residual block if live holes remain.


## Cycles 452-470 — Audit debt transfer and retention wave

Этот блок открыт после честного закрытия residual technical healing plan 02 (`432-451`).

Смысл блока:
1. перестать хранить уникальные ошибки только в старых audit-docs;
2. перевести audit debt в Healer как долговременную память проекта;
3. подготовить retention/cleanup план для `docs/audits/` и `reports/`;
4. оставить в active surface только действительно нужный truth-layer.

- Done: 14/19
- Remaining: 5/19
- Last completed cycle: 465/470
- Next cycle: 466/500
- Block status: active

- 450/451 — done — повторно сверены новый CI log-packet и текущий HEAD: user-owned GitHub CI по-прежнему показывает только pytest-cluster, который уже закрыт циклами 447-449; локальный доступный proof-layer подтверждён без подмены пользовательского CI.
- 451/451 — done — проведён audit-of-audits: определён active audit-surface, назначение `_raw` как evidence-архива и риск хранения уникальных ошибок вне Healer; подготовлен план переноса audit debt на циклы 452-470.
- 452/470 — done — открыт новый блок переноса audit debt в Healer; добавлен backbone-реестр проблем, которые обязаны жить в Healer до будущей зачистки старых audit-файлов.
- 453/470 — done — проведён первичный retention-аудит раздела `reports/`: зафиксирован рост до 725 файлов, разделены канонические `change_cycle_*` и legacy-format/transition reports, подготовлен cleanup plan без немедленного удаления.
- 454/470 — done — fixed new GitHub CI failure in `test_concurrency_exchange_withdraw`: canonical result now allows successful exchange + successful withdraw path (`main_balance=40`, `bank=-40`) in addition to withdraw-raced-out path.
- 455/470 — done — transferred audit backbone into Healer and archived stale top-level audits outside the active truth surface, leaving only important re-audit/proof documents in `docs/audits`.
- 456/470 — done — moved the whole `docs/audits/_raw` evidence layer into `artifacts/docs/audits_raw_archived_2026_04_08/`, with active memory redirected into Healer and active audit docs.
- 457/470 — done — archived old reports into `artifacts/reports_archived_2026_04_08/`, kept only active `change_cycle_2026-04-07*` / `2026-04-08*` plus `REPORTS_INDEX.md`, and rewired report-memory expectations to Healer + cycle docs.
- 458/470 — done — fixed new GitHub CI log wave after the archive cleanup: restored required high-impact historical audit docs into `docs/audits/` and aligned `test_concurrency_exchange_withdraw` with the canonical race outcome.
- 459/470 — done — guard-layer actualized so canon-banned/legacy-word tests skip user-approved archival baskets under `artifacts/`, while active docs and code remain under the strict scan surface.
- 460/470 — done — added new Healer cards for archive-basket guard policy and for the rule that high-impact historical audit stubs must remain visible while control tests depend on them.
- 461/470 — done — user-approved archive basket (`artifacts/docs/audits_archived_2026_04_08/`, `artifacts/docs/audits_raw_archived_2026_04_08/`, `artifacts/reports_archived_2026_04_08/`) removed from HEAD; active docs updated so they no longer point to deleted basket paths.
- 462/470 — done — added `artifacts/` to the terms glossary as the archive basket for temporary retention of deleted objects and then fully cleared the current basket contents by user request, leaving only an empty `artifacts/` directory.
- 463/470 — done — fixed the new GitHub CI ruff-only failure: removed duplicate exclusion items in guard test sets and restored clean `ruff check backend api ops tests`.
- 464/470 — done — added a new Healer card: dead-but-needed modules must be revived, not deleted; duplicate zones must go through compare → transfer → user approval before deletion.
- 465/470 — done — recorded the revival plan for all semantically dead-but-needed files and listed overlap/duplicate candidates requiring future agreement instead of deletion.
- 466/470 — planned — frontend resurrection wave 01: `ExchangePanel`, `ReferralsTabs`.
- 467/470 — planned — frontend resurrection wave 02: `AdminCharts`, `AdminTable`, `AdsBanner`, `RanksTable`.
- 468/470 — planned — backend resurrection wave 01: `admin_tasks_service`, `efhc_deposits_service`.
- 469/470 — planned — backend overlap audit and transfer proposal for `orders_service` vs active shop runtime.
- 470/470 — planned — final re-audit of the revival wave and duplicate decision pack.
