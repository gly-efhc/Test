# Cycle 1431 — Security regression hardening and repeat-audit prep

## Status

`DONE locally / repeat security audit pending`

## Base archive

`EFHC_Bot_v170_05_cycle_1430_security_p2_replay_opsec_repair.zip`

## Goal

Close the regression-hardening layer planned in cycle 1428 after the P0 and P2
security repairs:

- guard every backend `/admin/*` route with backend `require_admin`;
- guard owner-scoped money routes against frontend/user supplied identity drift;
- guard production docs and CORS safety;
- guard Telegram webhook secret-before-dedupe order;
- prepare repeat security audit without claiming release-ready.

## Runtime hardening applied

`backend/app/routes/system_routes.py` no longer registers Telegram webhook dedupe
through a FastAPI dependency before the webhook secret is checked. The route now
verifies `X-Telegram-Bot-Api-Secret-Token` first and only then calls
`register_external_event_after_secret()`.

`backend/app/deps.py` now exposes `register_external_event_after_secret()` as
the canonical helper for secret-protected webhook/callback routes. The old
`external_event_dedupe_dep()` remains available for routes without provider
secret pre-check, but secret-protected routes must not use it before auth.

## Guards added

New active guard file:

`tests/architecture/test_security_regression_hardening.py`

Protected meanings:

1. All backend admin route files must have backend `Depends(require_admin)` for
each route decorator.
2. Owner-scoped payment/deposit/withdraw/wallet routes must use authenticated
Telegram identity and ownership-scoped service calls.
3. Production docs/OpenAPI/Redoc must be configurable to null and prod CORS must
reject wildcard origin with credentials.
4. Telegram webhook dedupe must run only after webhook secret validation.
5. Cycle 1431 documents must remain present.

## Files changed

Runtime:

- `backend/app/deps.py`
- `backend/app/routes/system_routes.py`

Tests:

- `tests/architecture/test_security_regression_hardening.py`

Docs / navigation:

- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/security/P0_SECURITY_REPAIR_CANON.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `map_element.md`
- `ops/operator_kernel/cache/file_map.json`

## Sandbox note

Песочница использована только как reference/navigation layer. Runtime-код,
wallet/payment logic, CI files, lock files, configs, secrets, экономика и
переводы не переносились.

## Non-claims

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe step

Repeat security audit on the new archive or fresh CI logs.
