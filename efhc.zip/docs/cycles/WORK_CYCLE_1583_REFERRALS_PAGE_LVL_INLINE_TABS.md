# Cycle 1583 — Referrals page Lvl and inline segments

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED
Input HEAD: `EFHC_Bot_v171_79.zip`
Output HEAD: `EFHC_Bot_v171_80.zip`

## User-required product contract

The `/referrals` page must contain on one route:

1. progress to the next referral Lvl;
2. permanent referral link, copy action and Telegram/social sharing;
3. inline segmented `Active` / `Inactive` lists matching the Panels tab
   interaction pattern;
4. explicit `Lvl 0–5` and the complete threshold/reward scale.

## Economic correction

The tenth active direct referral causes an incremental event of
`0.1 + 1 = 1.1 EFHCb`, but the cumulative total earned by reaching Lvl 1 is:

```text
10 × 0.1 EFHCb + 1 EFHCb = 2 EFHC
```

The backend now exposes the canonical level scale with direct rewards, one-time
Lvl rewards, cumulative Lvl rewards and cumulative total rewards. The frontend
does not own or duplicate this calculation.

## Runtime changes

- Expanded `/referrals/stats/me` with current/next thresholds, unit reward,
  maximum rewarded active referrals and five backend-owned level steps.
- Replaced navigation buttons on `/referrals` with local segmented tabs.
- Embedded paged Active/Inactive lists in the main route.
- Added explicit current `Lvl` and five level cards.
- Preserved compatible `/referrals/active` and `/referrals/inactive` routes.
- Preserved first-creation attribution and all unit/level payout logic.

## Guards

- `tests/architecture/test_referrals_page_canon_v171_80.py`;
- `tests/architecture/test_referrals_progress_bonus.py`;
- `tests/architecture/test_referral_level_bonus_runtime.py`;
- `tests/efhc_backend/referrals/test_referral_level_rewards_integration.py`;
- `ops/release/ci_profile/test_release_archive_contract.py`.

## Proof boundary

Static, API, bounded backend and archive checks are local evidence only. Fresh
GitHub CI, real PostgreSQL execution of integration tests and route-backed
browser screenshots remain separate proof gates.
