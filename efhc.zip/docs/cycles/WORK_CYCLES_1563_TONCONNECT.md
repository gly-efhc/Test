# Cycle 1563 — TonConnect wallet and transaction UX

Status: `DONE_LOCALLY_WITH_CONTROLLED_BROWSER_PROOF`.

## Input and output

- Input: `EFHC_Bot_v171_38.zip`.
- Output target: `EFHC_Bot_v171_39.zip`.
- The next cycle is not executed in this iteration.

## Manifest

The runtime manifest is served by:

`/api/tonconnect-manifest`

It returns the required `url`, `name` and `iconUrl` fields, CORS `*`
and a short public cache policy. The static JSON file remains fallback-only.
A live production HTTPS domain is not claimed by local proof.

## Wallet restore and connection

The frontend TonConnect compatibility layer now owns reactive wallet state.
It subscribes to connector status changes and distinguishes:

- restore still running;
- restore completed without a wallet;
- restored connected session;
- proof ready;
- connection in progress;
- proof verification;
- connected;
- rejected by the user;
- error.

A restored session does not create a new wallet binding. Existing backend
binding is loaded through `wallets/me` and shown without a second connect POST.

## TonProof

The complete proof envelope is sent to `/wallets/connect`:

- canonical wallet address;
- wallet application;
- payload token;
- public key;
- network;
- timestamp;
- proof domain and length;
- signature;
- payload;
- state init.

The backend re-verifies the signature, domain, network identity, global_id,
payload token and replay boundary before creating a binding.

## User rejection and transaction UX

Connection rejection and transaction rejection are separate human states.
TonConnect rejection code `300` is handled without showing a generic backend
error. Transaction UX exposes signing, signed, rejected and failed phases.

## Evidence

- controlled wallet Chromium scenario: passed;
- controlled transaction Chromium scenario: passed;
- seven current screenshots in `reports/screenshots/tonconnect_1563/`;
- complete TonProof binding POST: one;
- restored session creates no additional binding POST;
- Ed25519 cryptographic boundary tests: passed;
- manifest runtime report: passed;
- all thirteen locale files contain the same TonConnect phase keys.

## Proof boundary

Local controlled browser proof is not a real wallet signature or a live
network transaction. Those remain external release evidence for cycle 1573.
