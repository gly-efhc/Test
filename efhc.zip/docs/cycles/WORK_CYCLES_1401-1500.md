# EFHC — ЦИКЛЫ 1401–1500
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

## Work item 1500 — Final Range Closure / Transition to 1501–1600 — DONE v170.76

Range `1401–1500`: `100 / 100` done, `0 / 100` remaining.

- Final closure document: `docs/NORM/FINAL_RANGE_CLOSURE.md`.
- Cycle note: `docs/cycles/WORK_CYCLES_1500_FINAL_RANGE_CLOSURE.md`.
- Generated report: `reports/generated/final_range_1401_1500_closure_v170_76.json`.
- Change report: `reports/change_cycle_2026-06-11_v170_76_cycle_1500_final_range_closure.md`.
- Guard: `tests/architecture/test_final_range_closure.py`.
- Dashboard direction remains closed/frozen at `42 / 42`.
- Next controlled range: `1501–1600`.
- Next safe cycle: `1501 — Dashboard UI Kit Consolidation QA`.
- No release-ready, GitHub CI green, browser screenshot proof, live Telegram proof or real TonConnect proof is claimed.

## Work item 1499 — VIS-03 Withdraw History Semantic Repair / Final Range Cleanup — DONE v170.75

- Closed VIS-03 public withdraw history semantic label issue.
- Green input logs fixed from `logs_73559592200.zip`: gate summary `OK: all gate steps passed.`
- Overall range progress: `99 / 100` done, `1 / 100` remaining.
- Dashboard direction remains closed at `42 / 42`.

## Work item 1498 — CI Log Repair / Public Dashboard i18n Hardening — DONE v170.74

- `logs_73496341059.zip` repaired.
- Public user dashboard i18n gate restored across 13 active locales.
- Filename hygiene regression from audit follow-up filenames repaired.
- Current range status: `98 / 100` done, `2 / 100` remaining.
- Dashboard direction remains closed at `42 / 42`.

## Cycle 1497 — Dashboard Direction Audit Follow-up / Future Range Foundation — DONE v170.73

- Accepted audit verdict `DIRECTION_COMPLETE_WITH_KNOWN_GAPS`.
- Closed orphan `AdminInteractiveBankDashboard.tsx` synthetic-series risk by marking it `@deprecated ORPHAN DO NOT IMPORT` and removing `buildSeries`.
- Added missing reusable Sim/Admin UI Kit wrappers from dashboard plan §9/§10.
- Created `docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`.
- Froze `admin_domain_report_endpoints_backlog` into future range instead of implementing partial endpoints inside completed dashboard direction.
- Overall range `1401–1500`: `97 / 100` done, `3 / 100` remaining.
- Dashboard direction remains closed: `42 / 42`; cycle 1497 is audit follow-up, not a reopening of the direction.

## Cycle 1496 — Dashboard Direction Handoff / Backlog Freeze — DONE v170.72

- Dashboard direction `1455–1496` closed: `42 / 42` done, `0 / 42` remaining.
- Public user-facing dashboards are fixed as a 13-language UI surface.
- Admin dashboards remain Russian operator surface and are outside the public 13-language claim.
- Remaining dashboard work is frozen into backlog: post-VIS-03 regression QA, optional admin i18n, browser screenshot proof, GitHub CI rerun proof and release audit.
- Overall range `1401–1500`: `96 / 100` done, `4 / 100` remaining.

# Cycle 1494 sync note

`1494 — Accessibility / Localization / Overflow QA` is complete locally in `v170.70`; next safe cycle is `1495 — Final Dashboard Visual Audit / Screenshot Proof`.

Range `1401–1500`: done `94 / 100`, remaining `6 / 100`.

Dashboard direction `1455–1496`: done `40 / 42`, remaining `2 / 42`.

# Cycle 1493 sync note

`1493 — Visual Performance / Bundle Safety` is complete locally in `v170.69`; next safe cycle is `1494 — Accessibility / Localization / Overflow QA`.

Range `1401–1500`: done `93 / 100`, remaining `7 / 100`.

Dashboard direction `1455–1496`: done `39 / 42`, remaining `3 / 42`.

# Cycle 1491 sync note

`1491 — Real Time-Series Backend Contracts` is complete locally in `v170.67`; next safe cycle is `1492 — Synthetic Data Cleanup / Truth Hardening`.

Range `1401–1500`: done `91 / 100`, remaining `9 / 100`.

Dashboard direction `1455–1496`: done `37 / 42`, remaining `5 / 42`.

# Cycle 1490 sync note

`1490 — Admin Logs / Events Dashboard` is complete locally in `v170.66`; next safe cycle is `1491 — Real Time-Series Backend Contracts`.

# Cycle 1488 progress update

`1488 — Admin Tasks / Referrals Dashboard Upgrade` is complete locally in `v170.64`.

Range `1401–1500`: done `88 / 100`, remaining `12 / 100`.

Dashboard direction `1455–1496`: done `34 / 42`, remaining `8 / 42`.

Next safe cycle: `1489 — Admin System Health Dashboard`.

# Cycle 1484 update — Admin Users Dashboard Upgrade

- Completed locally in `v170.60`.
- Next safe cycle: `1485 — Admin Deposits Dashboard Upgrade`.
- Progress 1401–1500: `84 / 100` done, `16 / 100` remain.
- Dashboard progress 1455–1496: `30 / 42` done, `12 / 42` remain.

# Cycle 1479 completion note

`1479 — Exchange Dashboard Support Widgets` is complete locally in
`v170.55`. Next safe dashboard cycle is now
`1481 — Admin Overview Dashboard Upgrade`.

# Cycle 1478 update

`1478 — Referrals Dashboard Upgrade` is complete locally in `v170.54`.
The next safe cycle is now `1479 — Exchange Dashboard Support Widgets`.

# Cycle 1477 update — Tasks Dashboard Upgrade

- Completed locally in `v170.53`.
- Next safe cycle: `1478 — Referrals Dashboard Upgrade`.
- Progress 1401–1500: `77 / 100` done, `23 / 100` remain.


# Cycle 1476 update — Leaderboard Visual System

- `1476 — Leaderboard Visual System` completed locally in `v170.52`.
- Added shared component `LeaderboardVisualSystem.tsx`.
- Ranks runtime now uses shared podium/list visual components.
- No fake runtime rows, public raw `tg_id`, economy or write-flow change.
- Next safe cycle: `1477 — Tasks Dashboard Upgrade`.
- Dashboard direction progress: `22 / 42` done, `20 / 42` remain.
- 1401–1500 progress: `76 / 100` done, `24 / 100` remain.

# Cycle 1475 update — Ranks Dashboard Runtime Port

- `1475 — Ranks Dashboard Runtime Port` completed locally in `v170.51`.
- Next safe cycle: `1476 — Leaderboard Visual System`.
- Dashboard direction progress: `21 / 42` done, `21 / 42` remain.
- 1401–1500 progress: `75 / 100` done, `25 / 100` remain.

# Cycle 1474 sync note

`1474 — Ranks Dashboard Sandbox Prototype` is complete locally in
v170.50. The next safe cycle is `1475 — Ranks Dashboard Runtime Port`.

Dashboard direction remains `1455–1496 / 42 cycles` after the inserted
Dependency Audit Triage cycle.

# Cycle 1473 sync note

`1473 — Panel Cards Deep Polish` is complete locally in v170.49.
The next safe cycle is `1474 — Ranks Dashboard Sandbox Prototype`.

Dashboard direction remains `1455–1496 / 42 cycles` after the inserted
Dependency Audit Triage cycle.

# Cycle 1472 sync note

`1472 — Panels Portfolio Runtime Port` is complete locally in v170.48.
The next safe cycle after v170.48 was `1473 — Panel Cards Deep Polish`.

Dashboard direction remains `1455–1496 / 42 cycles` after the inserted
Dependency Audit Triage cycle.

# Cycle 1465 dashboard toolbar completion note

Cycle `1465 — Dashboard Toolbar Foundation` is done locally in v170.41.
The next dashboard direction step is `1466 — Variables / Filters System`.

# Cycle 1461 status update

`1461 — Admin Dashboard UI Kit Foundation` is done locally in v170.37.

Dashboard direction progress: `16 / 42` cycles done for `1455–1496`.
Next planned dashboard cycle: `1471 — Panels Portfolio Sandbox Prototype`.

# Cycle 1460 completed — Simulation Dashboard UI Kit Foundation

- Added `docs/NORM/SIMULATION_DASHBOARD_UI_KIT_FOUNDATION.md`.
- Added `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- Added dashboard deletion check proving old dashboard files were not
  removed.
- Next dashboard step: `1461 — Admin Dashboard UI Kit Foundation`.

## 1457 — Grafana Visual Pattern Map — DONE locally

- Active map: `docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md`.
- Machine report:
  `reports/generated/grafana_visual_pattern_map_v170_33.json`.
- Grafana patterns mapped to EFHC-owned implementation targets.
- No Grafana runtime code, dependencies, lock files, CI files,
  backend logic, wallet/payment logic or economics copied.
- Next step: `1458 — Dashboard Design Tokens Foundation`.


## 1455 — Dashboard Visual Kernel — DONE locally

- Dashboard Visual Direction Plan started.
- Active kernel: `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
- Next dashboard step: `1456 — Sandbox Dashboard Inventory`.
- Grafana and Песочница remain reference/prototype layers only.
- No runtime code was copied from external references.

## 1454 — Screenshot proof preparation before dashboard direction

Status: DONE locally in `v170.30`.

- Green CI logs from `logs_72687610241.zip` recorded.
- Screenshot proof preparation manifest added for public/admin/dashboard
  surfaces.
- Dashboard direction `1455-1496` remains active and starts next.
- No screenshots are claimed yet; this is preparation only.

## 1446 — CI rerun log repair / v170.22 — DONE locally

- HEAD input: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`.
- Input logs: `logs_72627437860.zip`.
- Scope: read fresh logs first, repair factual CI failures, update docs,
  and keep release-ready wording forbidden until new proof.
- Root cause repaired:
  - ruff `I001` import-order drift in admin bank and transactions service;
  - pytest historical-audit status note failure in `ROUTE_INVENTORY_FREEZE.md`.
- Added guard: `tests/architecture/test_ci_log_repair_guards.py`.
- Added report: `reports/generated/ci_log_repair_v170_22.json`.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Local validation:
  - log-repair guards: `5 passed`;
  - kernel/filename guard subset: `13 passed`;
  - `py_compile` touched backend Python files: passed.
- Not claimed: GitHub CI green, full pytest green, frontend build green,
  live proof gates or release-ready.
- Current progress for `1401-1500`: done `46 / 100`, remaining `54 / 100`.
- Next safe planned cycle: `1447 — fresh CI rerun proof / release-gate
  preparation`, or next log repair if fresh logs fail.

## Cycle 1444 — Linkage repeat audit + HEALER tail reconciliation

Status: DONE locally in `v170.20`.

- Local repeat audit for `F-001…F-008` produced `status=ok`, `blockers=[]`.
- Report: `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`.
- Guard: `tests/architecture/test_linkage_repeat_audit_healer_tail.py`.
- HEALER loader/schema tail reconciled in `ops/healer/loader.py` and `ops/healer/run_once.py`.
- `F-006` remains live FastAPI/CI proof pending; no release-ready claim.
- Next: `1446 — CI rerun log reconciliation or next fresh log repair`.

## Cycle 1441 — Admin wallet reset semantic repair

Status: DONE locally in `v170.17`.

- Repaired `F-005`: admin wallet reset now fully unbinds canonical `efhc_core.wallet_bindings`.
- Legacy `users.ton_wallet` cleanup remains only compatibility cleanup.
- New service helper: `wallets_service.admin_reset_wallet_bindings()`.
- Frontend reset action is not blocked solely by stale legacy `selected.ton_wallet`.
- Guard file: `tests/architecture/test_admin_wallet_reset_semantic_repair.py`.
- Remaining next step: `1442 — OpenAPI rebuild and strict contract gate`.

## Audit/HEALER tail routing after cycle 1441

- `1442`: OpenAPI rebuild and strict contract gate (`F-006`).
- `1443`: Full linkage architecture tests and critical UI state guards (`F-007`, `F-008`).
- `1444`: Repeat linkage audit + HEALER tail reconciliation.
- `1445`: CI/log proof and residual audit-tail closure if fresh logs are supplied.

## Cycle 1440 — Admin Hub route prefix repair

Status: DONE locally in `v170.16`.

- Repaired `F-004`: Admin Hub route prefix drift.
- Runtime Admin Hub routes now live in `backend/app/routes/admin_hub_routes.py`.
- Canonical path `/admin/hub/*` is enforced; Hub router is not nested under `/admin/shop/*`.
- Guard file: `tests/architecture/test_admin_hub_route_prefix_repair.py`.
- Remaining next step: `1441 — Admin wallet reset semantic repair`.

## Cycle 1439 — Admin reports bank table repair

Status: DONE locally in `v170.15`.

- `F-003` repaired: `/admin/reports/overview` now reads canonical `efhc_core.bank_balance` / `EFHC_MAIN`.
- Legacy `efhc_admin.bank_balances` is no longer used by the reports overview route.
- New guard: `tests/architecture/test_admin_reports_bank_ssot_repair.py`.
- Future bank mint/rewrite via migrations is guarded: only genesis seed in `0001_init.py` is allowed.
- Remaining next step: `1440 — Admin Hub route prefix repair`.

## Cycle 1438 — P0 Deposit watcher wallet SSOT repair

Status: DONE locally in `v170.14`.

- `F-002` repaired: deposit watcher wallet lookup now uses canonical `efhc_core.wallet_bindings`.
- Admin replay uses the same `process_incoming_tx()` canonical path as scheduler watcher.
- New guard: `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`.
- Remaining next step: `1439 — Admin reports bank table repair`.

## Cycle 1437 — P0 Bank SSOT repair

Status: DONE locally in `v170.13`.

- `F-001` repaired: admin bank mint/burn now use existing official/canonical tables only.
- No separate mint/burn ledger/table was created.
- New guard: `tests/architecture/test_admin_bank_ssot_repair.py`.
- Remaining next step: `1439 — Admin reports bank table repair`.

## Cycle 1436 — migrations/routes/backend-frontend linkage freeze

Status: DONE. Archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`.

The P0 linkage audit for v170.10 is now an active release blocker. Next planned
repair lane:

- 1437: P0 Bank SSOT repair.
- 1438: P0 Deposit watcher wallet SSOT repair — DONE locally in v170.14.
- 1439: Admin reports bank table repair — DONE locally in v170.15.
- 1440: Admin Hub route prefix repair — DONE locally in v170.16.
- 1441: Admin wallet reset semantic repair — DONE locally in v170.17.
- 1442: OpenAPI rebuild and strict contract gate.
- 1443: Full linkage architecture tests.
- 1444: Linkage repeat audit + HEALER tail reconciliation.
- 1445: CI/log proof and residual audit-tail closure if fresh logs are supplied.

No runtime, test, CI, workflow or lock-file changes were made in cycle 1436.

# Work cycles 1401-1500 — future range planning file

Status: DRAFT / RESERVED FUTURE RANGE.
Created: 2026-06-03.

## Purpose

This file reserves a clean planning surface for future cycles 1401-1500. It is
not the active range and must not override the current 1376-1385 i18n reaudit
manual translation range.

## Activation rule

Cycles 1401-1500 may become active only after:

1. the current active range is closed or explicitly superseded by the user;
2. a fresh audit/task is supplied in chat;
3. the HEAD archive is opened and verified with `testzip=None`;
4. active AI/NORM/SSOT/cycle documents are read;
5. no GitHub CI, screenshot, Telegram client, wallet transaction or release-ready
   claim is made without factual proof.

## Draft lanes

| Range | Draft lane | Notes |
|---:|---|---|
| 1401-1410 | Post-i18n stabilization | Re-run static i18n, FAQ, fallback and public locale quality gates after 1376-1385 closes. |
| 1411-1420 | Browser screenshot evidence | Real screenshot capture may be planned only with factual browser output. Harness-only output remains non-claim. |
| 1421-1430 | Public UI readability and text-overflow correction | Use screenshot evidence and long-string stress data; do not change economics. |
| 1431-1440 | Admin dashboard operator polish | Keep admin/public boundary, Russian operator contour and idempotent money-action confirmations. |
| 1441-1450 | Wallet/TonConnect guarded UX continuation | Static or sandbox-assisted UX only unless real wallet proof is supplied. |
| 1451-1460 | Backend/API observability and log repair | CI/log-driven repairs only from supplied logs; no invented failures. |
| 1461-1470 | Release audit preparation | Separate release audit required; CI green must come from GitHub CI proof. |
| 1471-1480 | Security, privacy and OPSEC review | Data minimization, route exposure, admin isolation and payment safety. |
| 1481-1490 | Documentation consolidation | Remove drift while preserving traceability in cycles/audits/reports. |
| 1491-1500 | Range closure / next-audit handoff | Closure only after factual tests and explicit non-claims are recorded. |

## Sandbox rule

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` and all sandbox archives remain reference/navigation layers.
They may inform UI rhythm, Telegram shell behavior, TonConnect UX structure and
test organization, but they do not authorize runtime framework migration,
foreign lock files, donor CI, donor wallet logic, donor economics or donor
translations.

## Non-claims

This future plan is not a readiness verdict. It does not claim GitHub CI green,
release readiness, screenshots, Telegram client proof or wallet transaction
proof.


## Preservation note after v169.59

This future range remains draft/reserved only. Cycle 1379 did not activate
1401-1500; it only continued the active 1376-1385 i18n manual translation range.


## Preservation note after v169.60

This future range remains draft/reserved only. Cycle 1380 did not activate
1401-1500; it only continued the active 1376-1385 i18n manual translation range.

## Preservation note after v169.61

This future range remains draft/reserved only. Cycle 1381 did not activate
1401-1500; it only continued the active 1376-1385 i18n manual translation range.


## Preservation note after v169.62

This future range remains draft/reserved only. Cycle 1382 did not activate
1401-1500; it only continued the active 1376-1385 i18n manual translation range.

## v169.63 reservation note

This file remains a draft/reserved planning file and does not activate the
1401-1500 range. The active lane after cycle 1383 is still 1376-1385 until the
current i18n/manual-coverage range is closed.


## v169_64 note

The future 1401-1500 reserved range remains inactive. Cycle 1384 only prepares browser text-stress planning for the current 1376-1385 i18n lane and does not activate the future range.

## v169.65 note

The future 1401–1500 file remains reserved/future-only. It is not activated by the 1385 closure.


## Carry-forward note from cycle 1386

Future ranges must preserve the pytest skip-scope invariant: browser E2E opt-in skipping must never mark architecture/unit/backend tests as skipped. Future DB/model work must also guard SQLAlchemy `__table_args__` against cleanup drift.

## v169.82 closure note

The `1390-1400` range is closed in cycle 1400. This document remains a
reserved future range only. It does not activate cycles 1401-1500. The next
active work range must be opened only after the user supplies a new audit or
explicit next-range task.



## v169.83 activation handoff

A fresh repeat i18n audit for v169.82 was supplied on 2026-06-03. Active work
for the range now lives in:

- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`

This original future-range file remains historical reservation context and is
superseded for active cycle tracking.

## v169.85 cycle 1403 note

The active range tracking remains in `WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`, now expanded by direct user command to include P0 backend financial/identity stabilization and FSM split planning. This historical future-range file remains non-authoritative for active execution.


## v169_86 / cycle 1404 active backend/deposit-cache route

The active post-i18n range now includes P0 backend repairs and the HEAL-0055 deposit-cache proof/retention lane. See `docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`.



## v169.87 / cycle 1405 update

Cycle 1405 completed `HEAL-0045` tg_id identity canon repair. The confirmed
`referrals_crud.admin_top_inviters()` drift from Telegram ID to internal
`users.id` was repaired and locked by
`tests/architecture/test_heal0045_tg_id_identity_canon.py`.

Next planned P0 cycle: `1408 — HEAL-0023 idempotency read-through conflict hardening`. Cycles 1406-1407 closed in v169.88 for HEAL-0040 and HEAL-0044.


## v169_89 / cycles 1408-1409 P0 idempotency and transaction-boundary map update

- `HEAL-0023`: explicit `IDEMPOTENCY_CONFLICT` marker is handled by shared read-through conflict detection.
- `HEAL-0018`: transaction-boundary map is recorded; runtime transaction-boundary rewrite remains scheduled for cycle 1410.
- Active plan remaining: 11 cycles (`1410-1420`).
- No sandbox runtime, CI, lock file, wallet/payment donor logic or translations were imported.

## v169_90 / cycles 1409-1410 P0 transaction-boundary repair update

- Cycle 1409 transaction-boundary map remains the repair base.
- Cycle 1410 applied the first HEAL-0018 runtime repair:
  `transactions_service._tx_context()` no longer uses hidden `begin_nested()`
  fallback, and `exchange_service` closes read-only preflight autobegin before
  money-service entry.
- Active plan remaining: 10 cycles (`1411-1420`).
- Next planned P0 cycle: `1411 — HEAL-0024 exchange/withdraw atomicity repair`.

## v169.91 cycles 1410-1411 update

- HEAL-0024 primary withdraw atomicity repaired: request row, hold transfer, audit meta and `hold_done=TRUE` are now in one service-owned transaction boundary.
- Operator Kernel refresh optimization added: `ops/operator_kernel/refresh.sh`; `routes.yaml` versioned as `version: 1` and validated during load.
- Next planned P0 cycle: `1412 — HEAL-0055 deposit-cache DB idempotency proof`.

## v169.92 / cycle 1412 note

Active P0 backend plan progressed through cycle 1412. Remaining focused plan cycles are `1413-1420`; this does not claim full range closure or release readiness.


## v169_95 cycles 1417-1420 update

The active P0 backend/FSM subrange `1404-1420` is closed. FSM implementation
was split into `backend/app/bot/fsm/` modules with `backend/app/bot/states.py`
kept as a compatibility facade. Remaining work in the broader `1401-1500`
range should start from a new audit/log/task rather than continuing the closed
subrange automatically.


## v169.96 / cycle 1421 log-repair note

The closed `1404-1420` backend/FSM subplan was not reopened. Cycle 1421 was a log-first repair from supplied CI logs after the FSM split. Active execution remains task/log/audit driven.

## v169.97 / cycle 1422 active-range note

The active range tracker is still
`WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`.
Cycle 1422 was opened by direct user task from a supplied P0 economic audit and
repaired only the surgical findings `FIND-002` and `FIND-004`.
This historical future-range file remains non-authoritative for active cycle
execution.

## v169.98 / cycle 1423 active-range note

The active range tracker is still
`WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`.
Cycle 1423 was opened by direct user task and repaired `FIND-001` panel
activation atomicity from the P0 economic audit. It did not reopen the closed
`1404-1420` backend/FSM subplan and did not start cycle 1424 automatically.


## v169.99 / cycle 1424 active-range note

The active range tracker is still
`WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`.
Cycle 1424 was opened by direct user task and repaired `FIND-003` withdraw
refund split plus `FIND-005` exchange TOCTOU from the P0 economic audit. It did
not reopen the closed `1404-1420` backend/FSM subplan and did not start cycle
1425 automatically.


## v170.00 / cycle 1425 active-range note

The active range tracker is still
`WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`.
Cycle 1425 was opened by direct user task and closed `FIND-006..010` cleanup
plus reconciliation hardening from the P0 economic audit. It did not reopen the
closed `1404-1420` backend/FSM subplan and did not start any later cycle
automatically.

## v170.01 / cycle 1426 economic re-audit cleanup note

Cycle 1426 was opened by direct user task after the v170.00 economic re-audit
verdict `ECONOMY_SAFE_WITH_MINOR_FINDINGS`. It closed the only new P3 finding:
removed the unused local `panels_service._tx_context` helper that still used
`db.begin_nested()` and added an active guard against reintroduction.

Current broader range progress: done `26 / 100`, remaining `74 / 100`.
Next safe step: release audit, fresh CI log, or new user task.

No GitHub CI green, full pytest green, frontend build, browser screenshot, live
Telegram proof, wallet proof or release-ready status is claimed by this note.

## v170.02 / cycle 1427 active-range note

Cycle 1427 was opened by direct user task with fresh CI logs. It repaired only
logged CI failures after the economic cleanup lane:

- ruff import ordering;
- line72 wrapping;
- Python dunder-token naming hygiene;
- Healer atlas schema/enum drift.

The cycle did not reopen closed economic findings and did not change EFHC
runtime economics. Next safe step is a fresh CI log, release audit or direct
user task.

## v170.03 / cycle 1428 security active-range note

Cycle 1428 was opened by direct user task after a supplied P0 security audit.
It did not perform runtime security repair. It archived the audit, resolved the
`v170.01` versus `v170.02` truth drift, answered the audit questions and planned
security repair cycles `1429-1431`.

Next safe step: cycle `1429` for the two P0 release blockers unless fresh logs
or a different direct user command override the sequence.

No P0 fixed, GitHub CI green, full pytest green, frontend build, browser proof,
live Telegram proof, real wallet proof or release-ready status is claimed by
this note.

## v170.04 / cycle 1429 active-range note

The active range tracker is still
`WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`.
Cycle 1429 was opened by direct user task and repaired the P0 security blockers
planned in cycle 1428: mandatory TonConnect proof for wallet binding and safe
prod/stage `CRON_SECRET` handling for `/cron/tick`.

The cycle does not claim repeat security audit pass or release-ready status.
Next planned security cycle is `1430` for P2 replay, OPSEC and legacy header
cleanup.


## Cycle 1430 update — security P2 replay / OPSEC repair

Cycle 1430 is DONE locally. It closes the P2 layer from the active security
audit: strict Telegram `auth_date`, expanded production secret redaction aliases
and removal of legacy frontend/admin identity headers from runtime/CORS
compatibility layers. Next planned security step is cycle 1431 regression
hardening and repeat-audit preparation.


## Cycle 1431 update — security regression hardening

Cycle 1431 is DONE locally. It adds the repeat-audit preparation guard layer
after security cycles 1429-1430 and repairs Telegram webhook order so the
webhook secret is checked before dedupe registration. Current broader range
progress: done `32 / 100`, remaining `68 / 100`.

No repeat security audit pass, GitHub CI green, full pytest green, frontend
build, browser screenshot, live Telegram proof, real wallet proof or
release-ready status is claimed by this note.


## Cycle 1432 — CI log repair after security hardening

Status: DONE
Archive: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`
Source log: `logs_72432961872.zip`

Closed factual CI failures after cycles `1429–1431`: ruff UP037, Bandit
legacy digest naming, SSOT table-count drift (`43` ORM tables), stale panel/spend
guards, Healer enum drift and wallet proof replay ordering.

## Cycle 1433 update — Operator Kernel First Standard hardening

Cycle 1433 is DONE as docs-only Kernel hardening. It adds
`docs/NORM/EFHC_OPERATOR_KERNEL_FIRST_STANDARD.md` and aligns Kernel entry,
reading entrypoint, protocol, permission/patch/validation standards, routes,
file_map, Q&A, reports and guard manifest. Current broader range progress:
done `33 / 100`, remaining `67 / 100`.

No runtime, security/auth, money-flow, test, CI/workflow or lock-file change is
claimed by this note.


## Cycle 1434 update — security minor findings repair

Cycle 1434 is DONE locally. It closes the remaining v170.08 security audit
minor findings: `ADS_TEST_MODE` prod/stage fail-fast, monetary rate-limit
coverage for `/deposit` and `/payment-intents`, and OPSEC placeholder cleanup in
`env.prod.example`. Current broader range progress: done `34 / 100`, remaining
`66 / 100`.

No GitHub CI green, full pytest green, frontend build, browser screenshot, live
Telegram proof, real wallet proof or release-ready status is claimed by this
note.


## Cycle 1435 update — cold start MVP UX asset optimization

Cycle 1435 is DONE locally. Cold start is not treated as an MVP blocker
when cached shell first, loading/effect and stale-while-revalidate are
preserved. The Energy first-paint bot image now uses
`frontend/public/skins/1.webp` at 197,804 bytes. Current broader range
progress: done `35 / 100`, remaining `65 / 100`.

## Update after cycle 1442

Cycle `1442` is done locally as checked-in OpenAPI/contract repair.

Remaining planned linkage/audit tail:

1. `1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards`.
2. `1444 — Linkage repeat audit + HEALER tail reconciliation`.
3. `1445 — CI/log proof and residual audit-tail closure if fresh logs are supplied`.

Do not claim release-ready until repeat linkage audit and CI/full dependency proof are completed.

## Cycle 1443 — completed locally

- `F-007` and `F-008` local guard layer added.
- New scanner: `ops/linkage/build_full_linkage_report.py`.
- New report: `reports/generated/full_linkage_report_v170_19.json`.
- New guard: `tests/architecture/test_full_linkage_architecture_and_ui_states.py`.
- Next: `1444 — Linkage repeat audit + HEALER tail reconciliation`.


## 1445 — CI log repair + BNB/source skin cleanup / v170.21 — DONE locally

- HEAD input: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`.
- Logs input: `logs_72623328892.zip`.
- Fixed factual CI failures: ruff import-order/E402, mypy Decimal/Optional drift, admin bank road guard drift, admin hub route module guard drift, Kernel fallback marker, line72 tooling violations, route freeze markdown drift, Healer atlas compact schema drift, wallet hardening test state bleed.
- Removed old BNB/source skin: `frontend/public/skins/1.png`.
- Canonical skin asset is now WebP: `frontend/public/skins/1.webp`.
- Added report: `reports/generated/ci_log_repair_v170_21.json`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `45 / 100`, remaining `55 / 100`.
- Next safe planned cycle: `1446 — CI rerun log reconciliation or next fresh log repair`.


## Dashboard visual direction after cycle 1452

Status: ACTIVE DIRECTION.

- Active document: `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Planned dashboard range: `1455–1496`, 42 cycles after dependency audit insertion.
- Cycles `1455–1466`: dashboard kernel, sandbox inventory,
  Grafana pattern map, tokens, component contracts, UI kit foundations,
  panel chrome, progress, mini charts, toolbar and filters.
- Cycles `1467–1479`: user simulation dashboards for Energy, Panels,
  Ranks, leaderboard, Tasks, Referrals, Exchange and Web Profile.
- Cycles `1480–1489`: admin dashboards for overview, reports, bank,
  users, deposits, withdrawals, panels, tasks/referrals, system health
  and logs/events.
- Cycles `1491–1496`: read-only time-series contracts, synthetic data
  cleanup, performance/bundle safety, accessibility/localization QA,
  final screenshot proof and handoff/backlog freeze.

Boundary: Grafana is a visual discipline reference only. EFHC Bot does
not import Grafana runtime code, dependencies, lock files or CI.


### Cycle 1456 status update

Status: `DONE_LOCAL` in `v170.32`.

Inventory document:

`docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md`

Machine report:

`reports/generated/sandbox_dashboard_inventory_v170_32.json`

Cycle 1457 status:

`1457 — Grafana Visual Pattern Map` is DONE locally.

Next dashboard step:

`1458 — Dashboard Design Tokens Foundation`.


### Cycle 1458 status update

Status: `DONE_LOCAL` in `v170.34`.

Active token document:

`docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`

Machine report:

`reports/generated/dashboard_design_tokens_foundation_v170_34.json`

Cycle 1459 status:

`1459 — Dashboard Component Contract` is the next planned dashboard
foundation step.


### Cycle 1459 status update

Status: `DONE_LOCAL` in `v170.35`.

Active component contract:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Runtime type contract:

`frontend/src/lib/dashboard/componentContract.ts`

Machine report:

`reports/generated/dashboard_component_contract_v170_35.json`

Cycle 1460 status:

`1460 — Simulation Dashboard UI Kit Foundation` is the next planned
foundation step.


### Cycle 1462 status update

Status: `DONE_LOCAL` in `v170.38`.

Active panel chrome document:

`docs/NORM/PANEL_CHROME_FOUNDATION.md`

Runtime shared shell:

`frontend/src/components/dashboard/PanelChrome.tsx`

Machine report:

`reports/generated/panel_chrome_foundation_v170_38.json`

Cycle 1463 status:

`1463 — Progress System Foundation` is done locally.
Next planned dashboard foundation step: `1464 — Mini Charts Foundation`.


Cycle 1463 report:

`reports/generated/progress_system_foundation_v170_39.json`


### Cycle 1464 status update

Status: `DONE_LOCAL` in `v170.40`.

Active mini charts document:

`docs/NORM/MINI_CHARTS_FOUNDATION.md`

Runtime mini charts:

`frontend/src/components/dashboard/MiniCharts.tsx`

Machine report:

`reports/generated/mini_charts_foundation_v170_40.json`

Cycle 1465 status:

`1465 — Dashboard Toolbar Foundation` is the next planned foundation
step.


## v170.44 / cycle 1468 dependency audit insertion

User inserted `1468 — Dependency Audit Triage` before Energy Dashboard Runtime Port.

- Old `1468 — Energy Dashboard Runtime Port` is shifted to `1469`.
- Dashboard handoff shifts to `1496`.
- Dashboard direction progress after this cycle: `14 / 42`; remaining `28 / 42`.
- This shift does not change EFHC economics or release-readiness claims.


## v170.45 / cycle 1469 Energy Dashboard Runtime Port

Cycle `1469 — Energy Dashboard Runtime Port` is done locally.

- Runtime Energy dashboard added to live `/` Energy route.
- Old `1469` target is complete; next dashboard step is `1470 — Energy Dashboard Visual QA`.
- Dashboard direction progress after this cycle: `15 / 42`; remaining `27 / 42`.
- Range `1401-1500` progress after this cycle: `69 / 100`; remaining `31 / 100`.


## v170.46 / cycle 1470 Energy Dashboard Visual QA

Cycle `1470 — Energy Dashboard Visual QA` is done locally.

- Runtime Energy dashboard received static visual QA.
- Russian raw/derived labels were localized.
- Mobile overflow hardening was added for long values, rule chips and dashboard labels.
- Browser screenshot proof was attempted but blocked by environment policy; no screenshot proof is claimed.
- Dashboard direction progress after this cycle: `16 / 42`; remaining `26 / 42`.
- Range `1401-1500` progress after this cycle: `70 / 100`; remaining `30 / 100`.
- Next dashboard step: `1471 — Panels Portfolio Sandbox Prototype`.


## v170.47 / cycle 1471 Panels Portfolio Sandbox Prototype

Cycle `1471 — Panels Portfolio Sandbox Prototype` is done locally.

- Sandbox-only Panels Portfolio Dashboard prototype added.
- Runtime `/panels` remains unchanged.
- Prototype truth model is `synthetic_preview`.
- Dashboard direction progress after this cycle: `17 / 42`; remaining `25 / 42`.
- Range `1401-1500` progress after this cycle: `71 / 100`; remaining `29 / 100`.
- Next dashboard step: `1472 — Panels Portfolio Runtime Port`.


## Cycle 1480 completion note

`1480 — Web Profile / Account Center Dashboard Polish` completed locally in
v170.56. Next safe cycle is `1481 — Admin Overview Dashboard Upgrade`.
## Cycle 1481 status update

`1481 — Admin Overview Dashboard Upgrade` completed locally in `v170.57`.
Range progress is now `81 / 100`, remaining `19 / 100`. Dashboard
direction progress is `27 / 42`, remaining `15 / 42`. Next safe cycle:
`1482 — Admin Reports Grafana-like Upgrade`.

## Cycle 1482 completion note

`1482 — Admin Reports Grafana-like Upgrade` was completed locally as
`v170.58`. `/admin/reports` now has a Grafana-like read-only dashboard
surface with toolbar, freshness, display-only filters, panel chrome,
derived snapshot charts and a safe inspector. The old fake trend
generator from a single snapshot was removed. Next safe cycle is
`1483 — Admin Bank Dashboard Upgrade`.

## Cycle 1483 completion note — v170.59

`1483 — Admin Bank Dashboard Upgrade` completed locally.

- `1401–1500`: `83 / 100` done, `17 / 100` remain.
- Dashboard direction: `29 / 42` done, `13 / 42` remain.
- Next safe cycle: `1484 — Admin Users Dashboard Upgrade`.

## Cycle 1486 update — Admin Withdrawals Dashboard Upgrade

- Completed locally in `v170.62`.
- `/admin/withdrawals` has a read-only queue dashboard based on existing
  `GET /admin/withdrawals?status=...` snapshots.
- Guarded pay/approve/reject/repair controls are unchanged.
- No fake time-series, fake handling time or final status overwrite.
- Progress 1401–1500: `86 / 100` done, `14 / 100` remain.
- Dashboard progress 1455–1496: `32 / 42` done, `10 / 42` remain.
- Next safe cycle: `1487 — Admin Panels Dashboard Upgrade`.


## Cycle 1487 update — Admin Panels Dashboard Upgrade

- Completed locally in `v170.63`.
- `/admin/panels` has a read-only lifecycle dashboard based on existing
  `GET /admin/panels` snapshots.
- Guarded activate/deactivate controls are unchanged.
- No fake activation trends, fake panel history, lifecycle rewrite or
  generation logic change.
- 1485 deposits progress-bar coverage UX debt is closed by adding a third
  Pending intents bar.
- Progress 1401–1500: `87 / 100` done, `13 / 100` remain.
- Dashboard progress 1455–1496: `33 / 42` done, `9 / 42` remain.
- Next safe cycle: `1488 — Admin Tasks / Referrals Dashboard Upgrade`.


### 1489 — Admin System Health Dashboard

Status: DONE in v170.65. Read-only health dashboard added to `/admin/system`; next safe cycle is `1490 — Admin Logs / Events Dashboard`.


## Cycle 1492 — DONE v170.68

`1492 — Synthetic Data Cleanup / Truth Hardening` completed. Remaining dashboard cycles: `1493–1496`. Overall range `1401–1500`: done `92 / 100`, remaining `8 / 100`.


## Cycle 1495 — Final Dashboard Visual Audit / Screenshot Proof — DONE v170.71

- Attached log failures from `logs_73325744958.zip` repaired.
- Public dashboard locale key parity across 13 active locales confirmed.
- Dashboard localization placeholder prefixes are blocked by guard.
- Static screenshot matrix prepared; browser screenshot capture is not claimed.
- Overall progress: `1401–1500` = `95 / 100`, remaining `5 / 100`.
- Dashboard progress: `1455–1496` = `41 / 42`, remaining `1 / 42`.
- Next safe cycle: `1496 — Dashboard Direction Handoff / Backlog Freeze`.

---

## Источник: `WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

## 1446 — CI rerun log repair / v170.22 — DONE locally

- HEAD input: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`.
- Input logs: `logs_72627437860.zip`.
- Scope: read fresh logs first, repair factual CI failures, update docs,
  and keep release-ready wording forbidden until new proof.
- Root cause repaired:
  - ruff `I001` import-order drift in admin bank and transactions service;
  - pytest historical-audit status note failure in `ROUTE_INVENTORY_FREEZE.md`.
- Added guard: `tests/architecture/test_ci_log_repair_guards.py`.
- Added report: `reports/generated/ci_log_repair_v170_22.json`.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Local validation:
  - log-repair guards: `5 passed`;
  - kernel/filename guard subset: `13 passed`;
  - `py_compile` touched backend Python files: passed.
- Not claimed: GitHub CI green, full pytest green, frontend build green,
  live proof gates or release-ready.
- Current progress for `1401-1500`: done `46 / 100`, remaining `54 / 100`.
- Next safe planned cycle: `1447 — fresh CI rerun proof / release-gate
  preparation`, or next log repair if fresh logs fail.

## Cycle 1444 — Linkage repeat audit + HEALER tail reconciliation

Status: DONE locally in `v170.20`.

- Local repeat audit for `F-001…F-008` produced `status=ok`, `blockers=[]`.
- Report: `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`.
- Guard: `tests/architecture/test_linkage_repeat_audit_healer_tail.py`.
- HEALER loader/schema tail reconciled in `ops/healer/loader.py` and `ops/healer/run_once.py`.
- `F-006` remains live FastAPI/CI proof pending; no release-ready claim.
- Next: `1446 — CI rerun log reconciliation or next fresh log repair`.

## Cycle 1441 — Admin wallet reset semantic repair

Status: DONE locally in `v170.17`.

- Repaired `F-005`: admin wallet reset now fully unbinds canonical `efhc_core.wallet_bindings`.
- Legacy `users.ton_wallet` cleanup remains only compatibility cleanup.
- New service helper: `wallets_service.admin_reset_wallet_bindings()`.
- Frontend reset action is not blocked solely by stale legacy `selected.ton_wallet`.
- Guard file: `tests/architecture/test_admin_wallet_reset_semantic_repair.py`.
- Remaining next step: `1442 — OpenAPI rebuild and strict contract gate`.

## Audit/HEALER tail routing after cycle 1441

- `1442`: OpenAPI rebuild and strict contract gate (`F-006`).
- `1443`: Full linkage architecture tests and critical UI state guards (`F-007`, `F-008`).
- `1444`: Repeat linkage audit + HEALER tail reconciliation.
- `1445`: CI/log proof and residual audit-tail closure if fresh logs are supplied.

## Cycle 1440 — Admin Hub route prefix repair

Status: DONE locally in `v170.16`.

- Repaired `F-004`: Admin Hub route prefix drift.
- Runtime Admin Hub routes now live in `backend/app/routes/admin_hub_routes.py`.
- Canonical path `/admin/hub/*` is enforced; Hub router is not nested under `/admin/shop/*`.
- Guard file: `tests/architecture/test_admin_hub_route_prefix_repair.py`.
- Remaining next step: `1441 — Admin wallet reset semantic repair`.

## Cycle 1439 — Admin reports bank table repair

Status: DONE locally in `v170.15`.

- `F-003` repaired: `/admin/reports/overview` now reads canonical `efhc_core.bank_balance` / `EFHC_MAIN`.
- Legacy `efhc_admin.bank_balances` is no longer used by the reports overview route.
- New guard: `tests/architecture/test_admin_reports_bank_ssot_repair.py`.
- Future bank mint/rewrite via migrations is guarded: only genesis seed in `0001_init.py` is allowed.
- Remaining next step: `1440 — Admin Hub route prefix repair`.

## Cycle 1438 — P0 Deposit watcher wallet SSOT repair

Status: DONE locally in `v170.14`.

- `F-002` repaired: deposit watcher wallet lookup now uses canonical `efhc_core.wallet_bindings`.
- Admin replay uses the same `process_incoming_tx()` canonical path as scheduler watcher.
- New guard: `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`.
- Remaining next step: `1439 — Admin reports bank table repair`.

## Cycle 1437 — P0 Bank SSOT repair

Status: DONE locally in `v170.13`.

- `F-001` repaired: admin bank mint/burn now use existing official/canonical tables only.
- No separate mint/burn ledger/table was created.
- New guard: `tests/architecture/test_admin_bank_ssot_repair.py`.
- Remaining next step: `1439 — Admin reports bank table repair`.

## Cycle 1436 — migrations/routes/backend-frontend linkage freeze

Status: DONE. Archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`.

The P0 linkage audit for v170.10 is now an active release blocker. Next planned
repair lane:

- 1437: P0 Bank SSOT repair.
- 1438: P0 Deposit watcher wallet SSOT repair — DONE locally in v170.14.
- 1439: Admin reports bank table repair — DONE locally in v170.15.
- 1440: Admin Hub route prefix repair — DONE locally in v170.16.
- 1441: Admin wallet reset semantic repair — DONE locally in v170.17.
- 1442: OpenAPI rebuild and strict contract gate.
- 1443: Full linkage architecture tests.
- 1444: Linkage repeat audit + HEALER tail reconciliation.
- 1445: CI/log proof and residual audit-tail closure if fresh logs are supplied.

No runtime, test, CI, workflow or lock-file changes were made in cycle 1436.

# Work cycles 1401-1500 — post-i18n stabilization

Status: ACTIVE / OPEN after the repeat i18n audit supplied on 2026-06-03.
Activation source: `docs/audits/I18N_REAUDIT_REPORT_V169_82_2026_06_03.md`.

## Activation rule satisfied

The previous range `1390-1400` was closed in v169.82. The user supplied a new
repeat i18n audit for v169.82. Therefore cycle 1401 is allowed to open as an
audit-driven repair cycle.

## Cycle 1401 — DONE

Goal: repair LOW false-positive i18n signals from the repeat audit.

Done in v169.83:

- added `FAQ` to the exact-value allowlist;
- added compact time-unit labels `h`, `d`, `m` to the exact-value allowlist;
- preserved existing `s` allowlist entry;
- added shared helper `ops/i18n/locale_quality_allowlist.py`;
- wired 10 wave-3 locale value-quality scripts to the shared allowlist;
- added exact false-positive phrase `Цена панели фиксирована` to the
  gambling/chance contour;
- archived the repeat audit source inside `docs/audits/`;
- added active regression guard
  `tests/architecture/test_i18n_reaudit_low_signal_repair.py`.

## Current progress

- Range: `1401-1500`.
- Done: `41 / 100`.
- Remaining: `59 / 100`.
- Next: `1442 — OpenAPI rebuild and strict contract gate`.

## Non-claims

This plan does not claim GitHub CI green, full pytest green, frontend build,
screenshots, Telegram client proof, real wallet proof or release readiness.

## Cycle 1402 — DONE

Goal: repair public/shared hardcoded i18n strings found by the v169.83 audit/TZ.

Done in v169.84:

- replaced audited hardcoded copy in `ErrorBoundary.tsx` with i18n keys via an
  optional translator prop for the class component;
- localized public admin-route guard copy in `_app.tsx` through `admin_guard.*`;
- localized AdsBanner, EnergyGauge, Modal close aria and TelegramProductCard
  image placeholder;
- removed the `SurfaceFactsStrip` English default after confirming all call
  sites pass `title`;
- localized optional low-risk accessibility/component strings in GlobalHeader,
  ShopLayout and TelegramProductCard;
- added `tests/architecture/test_i18n_hardcoded_strings_guard.py`.

## Current progress after cycle 1402

- Range: `1401-1500`.
- Done: `41 / 100`.
- Remaining: `59 / 100`.
- Next: `1442 — OpenAPI rebuild and strict contract gate`.

## Cycle 1403 — DONE

Goal: audit and plan P0 / Red Zone backend repairs and the `states.py` split.

Done in v169.85:

- read active AI/NORM/SSOT/testing/cycle documents and `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`;
- checked P0 issues HEAL-0023, HEAL-0024, HEAL-0018, HEAL-0045, HEAL-0040 and HEAL-0044;
- confirmed active defects in HEAL-0045 and HEAL-0040;
- confirmed residual risk lanes for HEAL-0023, HEAL-0024, HEAL-0018 and HEAL-0044;
- checked `backend/app/bot/states.py` and confirmed SRP violation;
- added P0 backend repair plan and FSM split TZ;
- did not change runtime code.

## Current progress after cycle 1403

- Range: `1401-1500`.
- Done: `3 / 100`.
- Remaining: `97 / 100`.
- Next: `1404 — HEAL-0045 tg_id identity canon repair`, unless fresh logs are supplied first.

## Range lane update after cycle 1403

The range is no longer only post-i18n stabilization. By direct user command, it now includes P0 backend financial/identity stabilization and the planned FSM split lane. The original i18n stabilization work remains preserved and closed for cycles 1401-1402.


## v169_86 / cycle 1404 update

Cycle 1404 recorded user decisions for HEAL-0040, HEAL-0024/0018 and FSM split, and added the HEAL-0055 deposit-cache lane. Active repair planning moved to `docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`. Next planned cycle is 1405 — HEAL-0045 tg_id identity canon repair.



## v169.87 / cycle 1405 update

Cycle 1405 completed `HEAL-0045` tg_id identity canon repair. The confirmed
`referrals_crud.admin_top_inviters()` drift from Telegram ID to internal
`users.id` was repaired and locked by
`tests/architecture/test_heal0045_tg_id_identity_canon.py`.

Next planned P0 cycle: `1408 — HEAL-0023 idempotency read-through conflict hardening`. Cycles 1406-1407 closed in v169.88 for HEAL-0040 and HEAL-0044.


## v169_89 / cycles 1408-1409 P0 idempotency and transaction-boundary map update

- `HEAL-0023`: explicit `IDEMPOTENCY_CONFLICT` marker is handled by shared read-through conflict detection.
- `HEAL-0018`: transaction-boundary map is recorded; runtime transaction-boundary rewrite remains scheduled for cycle 1410.
- Active plan remaining: 11 cycles (`1410-1420`).
- No sandbox runtime, CI, lock file, wallet/payment donor logic or translations were imported.

## v169_90 / cycles 1409-1410 P0 transaction-boundary repair update

- Cycle 1409 transaction-boundary map remains the repair base.
- Cycle 1410 applied the first HEAL-0018 runtime repair:
  `transactions_service._tx_context()` no longer uses hidden `begin_nested()`
  fallback, and `exchange_service` closes read-only preflight autobegin before
  money-service entry.
- Active plan remaining: 10 cycles (`1411-1420`).
- Next planned P0 cycle: `1411 — HEAL-0024 exchange/withdraw atomicity repair`.

## v169.91 cycles 1410-1411 update

- HEAL-0024 primary withdraw atomicity repaired: request row, hold transfer, audit meta and `hold_done=TRUE` are now in one service-owned transaction boundary.
- Operator Kernel refresh optimization added: `ops/operator_kernel/refresh.sh`; `routes.yaml` versioned as `version: 1` and validated during load.
- Next planned P0 cycle: `1412 — HEAL-0055 deposit-cache DB idempotency proof`.

## v169.92 / cycle 1412 status

Cycle 1412 is complete. HEAL-0055 deposit duplicate protection now uses long-retention `efhc_admin.idempotency_key` records and Operator Kernel Start Core preload is mandatory. Remaining active plan cycles: `1413-1420`.


## v169_95 cycles 1417-1420 update

The active P0 backend/FSM subrange `1404-1420` is closed. FSM implementation
was split into `backend/app/bot/fsm/` modules with `backend/app/bot/states.py`
kept as a compatibility facade. Remaining work in the broader `1401-1500`
range should start from a new audit/log/task rather than continuing the closed
subrange automatically.


## v169.96 / cycle 1421 CI log repair

- Source logs: `logs_72253479436.zip`.
- Fixed pytest failures after FSM split and HEAL-0055 metadata update.
- The `1404-1420` subplan remains closed.
- Broader `1401-1500` range remains active only by direct user task, fresh logs or new audit.

## v169.97 / cycle 1422 economic risk repair

- Activation source: user supplied P0 economic audit with verdict `P0_ECONOMIC_RISK_FOUND`.
- Cycle 1422 closed the first surgical repair pair:
  - `FIND-002` all-bonus spend idempotency retry/read-through;
  - `FIND-004` admin manual debit TypeError from nonexistent kwargs.
- Active guard added: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `22 / 100`, remaining `78 / 100`.
- Next safe planned cycle: `1423 — FIND-001 panel activation atomicity`, after architecture decision confirmation.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.

## v169.98 / cycle 1423 panel activation atomicity repair

- Activation source: direct user task plus confirmed architecture answer `A` for `FIND-001`.
- Cycle 1423 closed the P0 panel activation atomicity risk:
  - `transactions_service.py` now has `spend_user_to_bank_bonus_then__main__nocommit`;
  - `panels_service.py` owns the single transaction for spend plus panel creation;
  - panel activation replay reads both `:main` and `:bonus` transfer logs.
- Active guard updated: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `23 / 100`, remaining `77 / 100`.
- Next safe planned cycle: `1424 — FIND-003 withdraw refund split + FIND-005 exchange TOCTOU`.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.


## v169.99 / cycle 1424 withdraw/exchange atomicity repair

- Activation source: direct user task plus previously confirmed architecture
  answers for `FIND-003` and `FIND-005`.
- Cycle 1424 closed the remaining P1 economic risks:
  - withdraw cancel/reject final status and refund now share one transaction;
  - exchange idempotency proof moved inside the lock/retry loop;
  - exchange helpers close direct-call preflight/autobegin state at entry.
- Active guard updated: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `24 / 100`, remaining `76 / 100`.
- Next safe planned cycle: `1425 — FIND-006..010 cleanup and reconciliation hardening`.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.


## v170.00 / cycle 1425 economic cleanup and reconciliation hardening

- Activation source: direct user task to continue cycle `1425`.
- Cycle 1425 closed remaining P2/P3 findings from the P0 economic audit:
  - `FIND-006` false zero-amount rejected exchange transfer log;
  - `FIND-007` direct exchange transaction-boundary safety guard;
  - `FIND-008` duplicate withdraw `_tx_context`;
  - `FIND-009` strict kWh check SSOT calculation;
  - `FIND-010` bonus credit audit meta persistence.
- Reconciliation hardening documented for `INV-08`.
- Active guard updated: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `25 / 100`, remaining `75 / 100`.
- The `1422-1425` economic audit repair lane is locally complete. Next safe step: fresh CI log, release audit, or new user task.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.

## v170.01 / cycle 1426 economic re-audit cleanup note

Cycle 1426 was opened by direct user task after the v170.00 economic re-audit
verdict `ECONOMY_SAFE_WITH_MINOR_FINDINGS`. It closed the only new P3 finding:
removed the unused local `panels_service._tx_context` helper that still used
`db.begin_nested()` and added an active guard against reintroduction.

Current broader range progress: done `26 / 100`, remaining `74 / 100`.
Next safe step: release audit, fresh CI log, or new user task.

No GitHub CI green, full pytest green, frontend build, browser screenshot, live
Telegram proof, wallet proof or release-ready status is claimed by this note.

## v170.02 / cycle 1427 CI log repair note

Cycle 1427 was opened by direct user task with `logs_72342361356.zip`.
The log canon was followed: logs were read first, exact failures were mapped,
then root causes were repaired.

Closed log failures:

- ruff `I001` import ordering in `withdraw_service.py`;
- line72 violations in `panels_service.py`;
- degraded `_main_` tokens in new helper/test names;
- Healer atlas schema drift in `atlas.json`.

Current broader range progress: done `27 / 100`, remaining `73 / 100`.
No GitHub CI green, full pytest green, frontend build, browser screenshot,
live Telegram proof, wallet proof or release-ready status is claimed.

## v170.03 / cycle 1428 security audit reconciliation

- Activation source: supplied P0 security audit with verdict
  `P0_RELEASE_BLOCKED`.
- This was a planning/reconciliation cycle, not runtime repair.
- Truth split resolved: the audit title points to `v170.01`, but the audit body
  and current archive line use `v170.02`; follow-up security repair starts from
  the actual latest HEAD.
- Questions answered: TonConnect proof is the production wallet binding canon;
  both backend entrypoints must converge; final verdicts use actual HEAD.
- Next safe planned cycles: `1429-1431`.
- Current progress for `1401-1500`: done `28 / 100`, remaining `72 / 100`.

Non-claims remain: no P0 fixed claim, no GitHub CI green, no full pytest green,
no frontend build, no screenshot proof, no live Telegram proof, no real wallet
proof and no release-ready claim.

## v170.04 / cycle 1429 P0 security repair

Cycle 1429 was opened by direct user task after the security reconciliation
cycle 1428. It repaired the two P0 release blockers locally:

- wallet binding now requires verified TonConnect proof and only verified active
  bindings satisfy wallet gates;
- `/cron/tick` requires a real ENV secret in prod/stage and no longer has a
  working repository-known default secret.

Current broader range progress: done `29 / 100`, remaining `71 / 100`.
Next safe step: cycle `1430` for P2 replay / OPSEC / legacy headers, unless a
fresh CI log, repeat audit or direct user task changes the order.

No repeat security audit pass, GitHub CI green, full pytest green, frontend
build, browser screenshot, live Telegram proof, real wallet proof or
release-ready status is claimed by this note.


## Cycle 1430 update — security P2 replay / OPSEC repair

Cycle 1430 is DONE locally. It closes the P2 layer from the active security
audit: strict Telegram `auth_date`, expanded production secret redaction aliases
and removal of legacy frontend/admin identity headers from runtime/CORS
compatibility layers. Next planned security step is cycle 1431 regression
hardening and repeat-audit preparation.


## Cycle 1431 update — security regression hardening

Cycle 1431 is DONE locally. It adds the repeat-audit preparation guard layer
after security cycles 1429-1430 and repairs Telegram webhook order so the
webhook secret is checked before dedupe registration. Current broader range
progress: done `32 / 100`, remaining `68 / 100`.

No repeat security audit pass, GitHub CI green, full pytest green, frontend
build, browser screenshot, live Telegram proof, real wallet proof or
release-ready status is claimed by this note.


## Cycle 1432 — CI log repair after security hardening

Status: DONE
Archive: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`
Source log: `logs_72432961872.zip`

Closed factual CI failures after cycles `1429–1431`: ruff UP037, Bandit
legacy digest naming, SSOT table-count drift (`43` ORM tables), stale panel/spend
guards, Healer enum drift and wallet proof replay ordering.

## Cycle 1433 update — Operator Kernel First Standard hardening

Cycle 1433 is DONE as docs-only Kernel hardening. It adds
`docs/NORM/EFHC_OPERATOR_KERNEL_FIRST_STANDARD.md` and aligns Kernel entry,
reading entrypoint, protocol, permission/patch/validation standards, routes,
file_map, Q&A, reports and guard manifest. Current broader range progress:
done `33 / 100`, remaining `67 / 100`.

No runtime, security/auth, money-flow, test, CI/workflow or lock-file change is
claimed by this note.


## Cycle 1434 update — security minor findings repair

Cycle 1434 is DONE locally. It closes the remaining v170.08 security audit
minor findings: `ADS_TEST_MODE` prod/stage fail-fast, monetary rate-limit
coverage for `/deposit` and `/payment-intents`, and OPSEC placeholder cleanup in
`env.prod.example`. Current broader range progress: done `34 / 100`, remaining
`66 / 100`.

No GitHub CI green, full pytest green, frontend build, browser screenshot, live
Telegram proof, real wallet proof or release-ready status is claimed by this
note.


## Cycle 1435 update — cold start MVP UX asset optimization

Cycle 1435 is DONE locally. Cold start is not treated as an MVP blocker
when cached shell first, loading/effect and stale-while-revalidate are
preserved. The Energy first-paint bot image now uses
`frontend/public/skins/1.webp` at 197,804 bytes. Current broader range
progress: done `35 / 100`, remaining `65 / 100`.

## v170.18 / cycle 1442 update

Cycle 1442 completed the checked-in OpenAPI rebuild and strict static contract gate.

- `F-006` is repaired locally for the checked-in OpenAPI/route snapshot.
- OpenAPI snapshot now has `116` paths and `121` operations from backend route source.
- New guard: `tests/architecture/test_openapi_rebuild_strict_contract_gate.py`.
- Guard report: `reports/generated/openapi_strict_contract_gate_v170_18.json` with `status=ok`.
- Live FastAPI `app.openapi()` proof is not claimed in the local tool environment because runtime dependency `sqlalchemy` is missing.
- Current progress: `42 / 100` done, `58 / 100` remaining.
- Next planned cycle: `1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards`.

## Cycle 1443 — completed locally

- `F-007` and `F-008` local guard layer added.
- New scanner: `ops/linkage/build_full_linkage_report.py`.
- New report: `reports/generated/full_linkage_report_v170_19.json`.
- New guard: `tests/architecture/test_full_linkage_architecture_and_ui_states.py`.
- Next: `1444 — Linkage repeat audit + HEALER tail reconciliation`.


## 1445 — CI log repair + BNB/source skin cleanup / v170.21 — DONE locally

- HEAD input: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`.
- Logs input: `logs_72623328892.zip`.
- Fixed factual CI failures: ruff import-order/E402, mypy Decimal/Optional drift, admin bank road guard drift, admin hub route module guard drift, Kernel fallback marker, line72 tooling violations, route freeze markdown drift, Healer atlas compact schema drift, wallet hardening test state bleed.
- Removed old BNB/source skin: `frontend/public/skins/1.png`.
- Canonical skin asset is now WebP: `frontend/public/skins/1.webp`.
- Added report: `reports/generated/ci_log_repair_v170_21.json`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `45 / 100`, remaining `55 / 100`.
- Next safe planned cycle: `1446 — CI rerun log reconciliation or next fresh log repair`.

## v170.24 / cycle 1448 update

Cycle 1448 closed two P2 linkage housekeeping findings from the v170.23
full linkage audit. The full linkage report/test now targets
`1448 / v170.24`, and Admin Hub frontend routes use generated
`adminSeams.ts` constants/types instead of raw `/admin/hub/*` API path
literals.

No economy, migration, CI/workflow or lock-file change was made.

---

## Источник: `WORK_CYCLES_1403-1417_P0_BACKEND_AND_FSM_REPAIR_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK_CYCLES_1403-1417 — superseded planning note

Status: SUPERSEDED BY `docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`.  
Superseded in: `v169_86 / cycle 1404`.

Reason: user confirmed the three cycle-1403 iteration decisions and added a deposit-cache/idempotency requirement. The active plan moved repair cycles forward and added HEAL-0055 deposit-cache proof/retention cycles.

The original cycle-1403 audit result remains historically valid, but the active execution map is now 1404-1420.

# WORK_CYCLES_1403-1417 — P0 backend and FSM repair plan

Status: ACTIVE PLAN / CYCLE 1403 DONE.  
Created in: `v169.85 / cycle 1403`.  
Base HEAD: `EFHC_Bot_v169_84_cycle_1402_i18n_hardcoded_strings_repair.zip`.

## Governing rule

P0 money/identity fixes must be done in small controlled cycles. A cycle may repair code only when the root cause is understood. If logs are supplied, logs are read first. If a payment/contract decision is ambiguous, ask the user before changing product behavior.

## Cycle map

| Cycle | Purpose | Status | Notes |
|---:|---|---:|---|
| 1403 | P0 Red Zone audit/TZ and FSM split planning | DONE in v169.85 | Documentation-only audit cycle. No runtime repair. |
| 1404 | HEAL-0045 tg_id identity canon repair | PLANNED | Repair referrals_crud joins/select/grouping to use User.tg_id; add guard for tg_id/User.id drift. |
| 1405 | HEAL-0040 payment_intents contract repair | PLANNED | User decision needed: recommended nullable package_id for custom deposit intents; add ORM/migration/route/test alignment. |
| 1406 | HEAL-0044 schema proof for transfer direction width | PLANNED | Add migration/schema guard proving direction varchar(24) for existing and fresh DB paths. |
| 1407 | HEAL-0023 idempotency read-through conflict hardening | PLANNED | Directly catch IDEMPOTENCY_CONFLICT, preserve read-through, add concurrency/idempotency guard. |
| 1408 | HEAL-0018 transaction boundary map | PLANNED | Audit callers and nested transaction helpers; define service-owned vs route-owned transaction contracts. |
| 1409 | HEAL-0018 transaction boundary repair | PLANNED | Remove unsafe nested workaround where possible; keep explicit savepoint only where documented and tested. |
| 1410 | HEAL-0024 exchange/withdraw atomicity repair | PLANNED | Withdraw create/hold/mark atomic transition or formal two-phase state machine with replay tests; verify exchange lock path. |
| 1411 | P0 cross-guard consolidation without deleting tests | PLANNED | Add source guards for identity/payment/idempotency/transaction/schema invariants; no skip/xfail. |
| 1412 | P0 backend targeted test and log repair | PLANNED | Run targeted backend tests; if logs supplied, logs first; no production-ready claim without CI proof. |
| 1413 | P0 range closure audit | PLANNED | Only after factual checks; produce closure audit/non-claims. |
| 1414 | FSM states.py split import/dependency map | PLANNED | Audit imports of backend.app.bot.states and design compatibility facade. |
| 1415 | FSM dto/backend extraction | PLANNED | Move BotStates/ConversationState/StateBackend/MemoryStateBackend to fsm/dto.py and fsm/backend.py with facade exports. |
| 1416 | FSM manager extraction | PLANNED | Move StateManager/get_state_manager to fsm/manager.py; preserve singleton semantics. |
| 1417 | FSM decorators extraction and regression proof | PLANNED | Move require_state/advance_state/clear_state_after to fsm/decorators.py; compile/import/targeted handler tests. |


## Blocking iteration questions before code repair

1. For HEAL-0040, confirm whether `payment_intents.package_id` may be nullable for custom deposit intents. Recommendation: yes, nullable only for custom/package-less intents.
2. For HEAL-0024 and HEAL-0018, confirm service-boundary repair may adapt route/service transaction ownership where necessary. Recommendation: yes, but only cycle-by-cycle.
3. For FSM split, confirm `backend/app/bot/states.py` should remain a compatibility facade during migration. Recommendation: yes.

## Non-claims

This plan does not claim GitHub CI green, full pytest green, npm build, screenshots, live Telegram proof, real wallet proof or release readiness.

---

## Источник: `WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK_CYCLES_1404-1420 — P0 backend, deposit-cache and FSM repair plan

Status: CLOSED / CYCLES 1404-1420 DONE.  
Created in: `v169_86 / cycle 1404`.  
Base HEAD: `EFHC_Bot_v169_85_cycle_1403_p0_backend_and_fsm_repair_plan.zip`.

## Governing rule

P0 money, identity, payment and deposit-cache fixes must be done in small controlled cycles. If logs are supplied, logs are read first. No test may be deleted, archived, skipped, xfailed or hidden to make the suite green.

## User decisions now locked

1. `HEAL-0040`: custom/package-less deposit intents may use `package_id = NULL`.
2. `HEAL-0024` / `HEAL-0018`: transaction-boundary repair may adapt service/route ownership where required.
3. FSM split: `backend/app/bot/states.py` remains a compatibility facade.
4. Deposit cache: no process-local `_ttl_seen` as source of truth; use `efhc_admin.idempotency_key` with durable/long-retention records for deposit protection.

## Cycle map

| Cycle | Purpose | Status | Notes |
|---:|---|---:|---|
| 1404 | P0 decision/Q&A/Atlas alignment + deposit-cache plan | DONE in v169.86 | Documentation/guard cycle. No runtime repair. |
| 1405 | HEAL-0045 tg_id identity canon repair | DONE in v169.87 | `admin_top_inviters()` now joins `*_tg_id` fields to `User.tg_id`, exposes `inviter_tg_id`, and is locked by `test_heal0045_tg_id_identity_canon.py`. |
| 1406 | HEAL-0040 payment_intents contract repair | DONE in v169.88 | Nullable `package_id` contract implemented for custom/package-less intents; package path keeps `:pid`; fake `0` sentinel removed from shop_external. |
| 1407 | HEAL-0044 schema proof for transfer direction width | DONE in v169.88 | Existing DB repair and sanity proof added for `efhc_transfers_log.direction varchar(24)`. |
| 1408 | HEAL-0023 idempotency read-through conflict hardening | DONE in v169.89 | Explicit `IDEMPOTENCY_CONFLICT` marker is now detected by the shared helper; local branches use `_is_idempotency_conflict(...)`. |
| 1409 | HEAL-0018 transaction boundary map | DONE in v169.89 | Transaction ownership map added. No runtime boundary rewrite in 1409. |
| 1410 | HEAL-0018 transaction boundary repair | DONE in v169.90 | Core `transactions_service` hidden `begin_nested()` fallback removed; `exchange_service` closes read-only preflight autobegin before money-service entry. |
| 1411 | HEAL-0024 exchange/withdraw atomicity repair | DONE in v169.91 | Primary withdraw request path now commits request row, hold transfer, audit meta and hold_done flag in one service-owned boundary; exchange lock path remains protected by existing row-lock guards. |
| 1412 | HEAL-0055 deposit-cache DB idempotency proof | DONE in v169.92 | Deposit processing now uses long-retention `efhc_admin.idempotency_key` records with `scope=deposit:efhc`, `expires_at=NULL` and response read-through; Kernel Start Core was also made mandatory. |
| 1413 | HEAL-0055 long-retention deposit idempotency policy | DONE in v169.93 | Deposit idempotency retention is explicitly `NON_EXPIRING`, `expires_at=None`, and same-key/different-payload replay raises `idempotency_fingerprint_mismatch`. |
| 1414 | P0 cross-guard consolidation without deleting tests | DONE in v169.93 | Added additive cross-guard over identity/payment/schema/idempotency/transaction/withdraw/deposit invariants. No existing guard was deleted or weakened. |
| 1415 | P0 backend targeted test and log repair | DONE in v169.94 | Read `logs_72248746196.zip` first and repaired the exact ruff/pytest failures. |
| 1416 | P0 range closure audit | DONE in v169.94 | Added log repair and range-closure audit with explicit non-claims. |
| 1417 | FSM states.py split import/dependency map | DONE in v169.95 | Kernel route and current imports were checked; facade strategy confirmed. |
| 1418 | FSM dto/backend extraction | DONE in v169.95 | `BotStates`, `ConversationState`, `StateBackend` and `MemoryStateBackend` moved under `backend/app/bot/fsm/`. |
| 1419 | FSM manager extraction | DONE in v169.95 | `StateManager` and `get_state_manager()` moved to `fsm/manager.py`; singleton semantics preserved. |
| 1420 | FSM decorators extraction and regression proof | DONE in v169.95 | Decorators moved to `fsm/decorators.py`; `states.py` remains a compatibility facade and guard was added. |

## Current remaining cycles

After cycle 1420, this active plan has 0 cycles remaining. Range `1404-1420` is closed.

## Non-claims

This plan does not claim GitHub CI green, full pytest green, npm build, screenshots, live Telegram proof, real wallet proof or release readiness.


## Cycle 1412 decision/status update

- `HEAL-0055` deposit-cache proof is now applied at service level.
- `process_efhc_deposit()` records canonical deposit idempotency keys in `efhc_admin.idempotency_key` with `scope=deposit:efhc` and `expires_at=NULL`.
- Completed deposit responses are stored in `response_payload_json` and replayed on duplicate tx-hash processing.
- Operator Kernel is now mandatory in Start Core navigation; `KERNEL.md` was added and `file_map.py --refresh` is available.
- Remaining plan cycles: `1413-1420`.


## Cycle 1413-1414 status update

- `HEAL-0055` deposit idempotency retention is now explicit in code:
  `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"` and
  `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`.
- A repeated deposit key with different watcher payload now raises
  `idempotency_fingerprint_mismatch` instead of silently reusing or crediting.
- Cycle 1414 added `tests/architecture/test_p0_cross_guard_consolidation.py`.
- Remaining plan cycles: `1415-1420`.


## Cycle 1415-1416 status update

- Log archive `logs_72248746196.zip` was read first.
- The failing ruff and pytest gates were repaired by root cause.
- No test was deleted, archived, skipped, xfailed or hidden.
- Remaining plan cycles: `1417-1420`.


## Cycle 1417-1420 status update

- `backend/app/bot/states.py` is now a compatibility facade below 2500 bytes.
- New implementation modules live in `backend/app/bot/fsm/`.
- `backend/app/bot/__init__.py` lazily loads heavy bot runtime exports so FSM imports do not require aiogram at import time.
- Added guard: `tests/architecture/test_fsm_states_split_facade.py`.
- Active plan `1404-1420` is now closed.

---

## Источник: `WORK_CYCLES_1421_CI_LOG_REPAIR.md`

# WORK CYCLE 1421 — CI log repair after FSM split

Status: DONE.
Date: 2026-06-04.
Archive output: `v169_96`.

## Input

- HEAD: `EFHC_Bot_v169_95_cycles_1417_1420_fsm_states_split_range_closure.zip`.
- Logs: `logs_72253479436.zip`.

## Log facts

CI logs were read first. Gate summary showed only pytest failed; flake8, ruff, mypy, bandit, compileall, Alembic and frontend build were green in the supplied logs.

Pytest reported:

- `3 failed, 1173 passed, 8 skipped, 1 warning`.

Failing tests:

1. `test_archive_filename_hygiene.py::test_no_numbered_work_pass_labels_in_non_exception_docs_and_indexes`.
2. `test_no_raw_create_task.py::test_no_raw_asyncio_create_task_outside_helper`.
3. `test_p0_heal_alignment_deposit_cache_docs.py::test_healer_0055_elevated_and_planned`.

## Root causes

- FSM split introduced a raw `asyncio.create_task()` in `backend/app/bot/fsm/manager.py`.
- Some non-exception docs and the `states.py` compatibility facade contained numbered work-pass wording.
- `atlas.json` still contained stale HEAL-0055 wording from before the long-retention repair.

## Repairs

- Replaced raw background task spawning in `backend/app/bot/fsm/manager.py` with `create_logged_task()`.
- Reworded non-exception docs and facade comments to avoid numbered work-pass labels while preserving traceability in allowed cycle/audit/report layers.
- Updated `atlas.json` HEAL-0055 confirmation basis to state that DB-backed deposit idempotency and long-retention policy are already repaired.

## Checks

- Exact failing pytest tests pass locally.
- Ruff and focused architecture checks were run locally after repair.
- No tests were deleted, archived, skipped, xfailed or hidden.

## Status

DONE. The next action is fresh CI/log confirmation or a new audit/task.

---

## Источник: `WORK_CYCLES_1422_ECONOMIC_RISK_REPAIR.md`

# Work Cycle 1422 — P0 economic risk repair

Status: DONE.
HEAD input: `EFHC_Bot_v169_96_cycle_1421_ci_log_repair.zip`.
HEAD output: `EFHC_Bot_v169_97_cycle_1422_economic_risk_repair.zip`.

## Goal

Repair the first surgical findings from the P0 economic audit:

- `FIND-002` — all-bonus spend idempotency read-through;
- `FIND-004` — admin manual debit `TypeError` from nonexistent kwargs.

## Source documents read

- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`
- `ops/operator_kernel/config/routes.yaml`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- active `1401-1500` and `1404-1420` cycle docs
- active backend P0 docs
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/NORM/API_CONTRACTS.md`
- `docs/NORM/ARCHIVE_FILENAME_HYGIENE_POLICY.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/25.md`
- supplied P0 economic audit MD/JSON

## Kernel preload

Kernel preload was performed before repair:

- `routes.yaml.version = 1`
- `file_map.json` was present and readable
- refresh was run after adding new files so navigation cache includes the new
  cycle, backend and test documents

## Sandbox use

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` and sandbox archive metadata were read as reference/navigation
context only.

Песочница использована только как reference/navigation layer. Runtime-код не
переносился.

No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor
logic, donor economics or translations were imported.

## Runtime changes

### `backend/app/services/transactions_service.py`

Changed `spend_user_to_bank_bonus_then_main`:

- added `_find_existing_spend_log()` local helper;
- added `_spend_read_through()` local helper;
- preflight idempotency now checks both `:main` and `:bonus` derived keys;
- conflict handling now also checks both keys;
- all-bonus retry no longer depends on a non-existing `:main` log.

### `backend/app/services/admin/admin_bank_service.py`

Changed `BankService.manual_bank_user_transfer`:

- removed nonexistent `spend_bonus_first` kwarg;
- removed nonexistent `forbid_user_negative` kwarg;
- kept admin debit routed through canonical `transactions_service.py` debit
  functions.

## Tests / guards

Added active guard file:

`tests/architecture/test_economic_risk_guards.py`

It contains:

- `test_spend_all_bonus_idempotency_retry_no_double_debit`
- `test_admin_manual_debit_no_typeerror`


### Guard/document hygiene alignment

The stale HEAL-0018 guard no longer requires a numbered work-pass label inside
`docs/backend/`. It now checks the numbered historical evidence in
`docs/cycles/WORK_CYCLES.md` and keeps backend repair docs clean under the
filename/content hygiene policy.

## What was not changed

- No AI Archive Laws changes.
- No CI/workflow changes.
- No frontend runtime changes.
- No Telegram/TonConnect/wallet logic changes.
- No EFHC economics changes.
- No direct SQL balance writes outside `transactions_service.py`.
- No test deletion, archival, skip, xfail or hiding.

## Checks performed

Targeted local checks passed:

- Python compile for changed code and new guard.
- `python3 scripts/ci/check_ai_archive_laws_integrity.py`
- `PYTHONPATH=backend python3 -m pytest -q tests/architecture/test_economic_risk_guards.py`
- targeted architecture guard pack for filename hygiene, law integrity, FSM,
  raw create task, chat intake and economic source guards.

## Not checked / non-claims

Not claimed:

- GitHub CI green;
- full pytest green;
- full npm build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect / wallet proof.

## Remaining findings

Still open for later cycles:

- `FIND-001` — P0 panel activation atomicity: cycle 1423.
- `FIND-003` — P1 withdraw refund split commit: cycle 1424.
- `FIND-005` — P1 exchange TOCTOU: cycle 1424.
- `FIND-006..010` — P2/P3 cleanup: cycle 1425.

## Next cycle

Next safe cycle: `1423 — panel activation atomicity`, only after confirming the
architecture choice for `FIND-001`.

Recommended answer for `FIND-001`: option `A` — add a nocommit spend variant
and let `panels_service.py` own the atomic transaction boundary.

## Follow-up status after cycle 1423

The recommended option `A` for `FIND-001` was confirmed by the user and applied
in the next cycle. Panel activation atomicity is now guarded in
`tests/architecture/test_economic_risk_guards.py`.

---

## Источник: `WORK_CYCLES_1423_PANEL_ATOMICITY_REPAIR.md`

# Work Cycle 1423 — P0 panel activation atomicity repair

Date: 2026-06-04.

HEAD input: `EFHC_Bot_v169_97_cycle_1422_economic_risk_repair.zip`.
HEAD output: `EFHC_Bot_v169_98_cycle_1423_panel_atomicity_repair.zip`.

## Goal

Repair `FIND-001` from the supplied P0 economic audit:

`panels_service.py / activate_panel` committed EFHC spend before creating panel
rows. A crash between the spend commit and the panel creation commit could leave
money debited with no panels created.

## User decision

The user confirmed option `A`:

- add `spend_user_to_bank_bonus_then__main__nocommit`;
- make `panels_service.py` own the single transaction boundary.

The user also pre-confirmed later-cycle decisions:

- `FIND-003`: use one `_tx_context` plus nocommit refund and one commit;
- `FIND-005`: move idempotency check inside lock/retry loop and add entry
  rollback guard.

Those later decisions are recorded, but this cycle repaired only `FIND-001`.

## Read before edit

- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`
- `ops/operator_kernel/config/routes.yaml`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/audits/P0_ECONOMIC_AUDIT_TRANSACTIONS_SERVICE_V169_91.md`
- `docs/cycles/WORK_CYCLES_1422_ECONOMIC_RISK_REPAIR.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`

Kernel preload was available. `routes.yaml.version` remained `1`.

## Repair applied

### 1. Nocommit spend helper

File:

`backend/app/services/transactions_service.py`

Added:

`spend_user_to_bank_bonus_then__main__nocommit`

Purpose:

- perform BONUS→MAIN spend without committing;
- allow a higher-level service to atomically commit/rollback spend plus domain
  object creation;
- preserve read-through idempotency by both `:main` and `:bonus` derived keys.

The existing commit-owning function now delegates to the nocommit helper inside
`transactions_service._tx_context()`.

### 2. Panel activation owns the atomic unit

File:

`backend/app/services/panels_service.py`

`activate_panel` now performs the following inside one transaction:

1. lock user row;
2. check historical negative balance;
3. check active panel limit;
4. calculate bonus/main split;
5. call `spend_user_to_bank_bonus_then__main__nocommit`;
6. create panel rows;
7. merge activation audit payload.

Forbidden old pattern removed:

- spend commit first;
- create panel rows in a later transaction.

### 3. Bonus-only replay payload repair

File:

`backend/app/services/panels_service.py`

`_get_activation_payload_by_idk` now reads and merges payload from both keys:

- `{idempotency_key}:main`
- `{idempotency_key}:bonus`

Reason:

An all-bonus activation may not create a `:main` transfer log. Replay must not
miss `panels_created_ids` and create duplicate panels without a new debit.

## Tests / guards

Updated active guard:

`tests/architecture/test_economic_risk_guards.py`

Protected checks:

- all-bonus spend retry read-through remains protected;
- admin manual debit TypeError guard remains protected;
- panel activation must use nocommit spend inside one transaction;
- activation replay payload must read both `:main` and `:bonus` logs.

## Local checks

Passed targeted checks:

```text
python3 -m pytest -q tests/architecture/test_economic_risk_guards.py
4 passed
```

```text
PYTHONPATH=backend python3 -m pytest -q   tests/architecture/test_archive_filename_hygiene.py   tests/architecture/test_economic_risk_guards.py   tests/architecture/test_heal0018_transaction_boundary_repair.py
16 passed
```

Additional broader targeted pack passed before final archive creation.

## Sandbox / map_element use

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` and the uploaded sandbox archives were used only as
reference/navigation context. Runtime code, CI files, lock files, wallet/payment
logic, translations and foreign economy were not imported.

## Not claimed

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full npm build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect/wallet proof.

## Status

`FIND-001` is repaired and guarded.

Remaining economic audit plan:

- cycle `1424`: `FIND-003` withdraw refund split + `FIND-005` exchange TOCTOU;
- cycle `1425`: `FIND-006..010` cleanup and reconciliation hardening.

---

## Источник: `WORK_CYCLES_1424_WITHDRAW_EXCHANGE_ATOMICITY_REPAIR.md`

# Work Cycle 1424 — Withdraw refund atomicity and exchange TOCTOU repair

Date: 2026-06-04.

HEAD input: `EFHC_Bot_v169_98_cycle_1423_panel_atomicity_repair.zip`.
HEAD output: `EFHC_Bot_v169_99_cycle_1424_withdraw_exchange_atomicity_repair.zip`.

## Goal

Repair the remaining P1 economic audit findings:

- `FIND-003`: `cancel_withdraw` and `admin_reject_withdraw` committed final
  status separately from refund.
- `FIND-005`: exchange helpers performed idempotency read-through before the
  user row lock, leaving a same-key race window.

## User decisions

The user confirmed:

- option `B` for `FIND-003`: one `_tx_context`, nocommit refund and one commit;
- yes for `FIND-005`: move idempotency check inside the lock/retry loop and add
  rollback guard at entry.

## Read before edit

- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`
- `ops/operator_kernel/config/routes.yaml`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/audits/P0_ECONOMIC_AUDIT_TRANSACTIONS_SERVICE_V169_91.md`
- `docs/cycles/WORK_CYCLES_1423_PANEL_ATOMICITY_REPAIR.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`

Kernel preload was available. `routes.yaml.version` remained `1`.

## Repair applied

### 1. Nocommit MAIN refund helper

File:

`backend/app/services/transactions_service.py`

Added:

`credit_user_from_bank_nocommit`

Purpose:

- credit MAIN balance from bank without committing;
- allow withdraw final status, refund transfer log and `refund_done=TRUE` to be
  committed or rolled back together;
- preserve idempotency read-through by refund key.

### 2. Withdraw cancel/reject atomic refund

File:

`backend/app/services/withdraw_service.py`

`cancel_withdraw` and `admin_reject_withdraw` now:

1. enter one `_tx_context`;
2. lock the withdraw request row with `FOR UPDATE`;
3. transition to final status when the row is still `PENDING`;
4. call `credit_user_from_bank_nocommit` for the refund when needed;
5. set `refund_done=TRUE`;
6. rely on one surrounding commit.

The old split-commit pattern was removed from both functions.

### 3. Exchange TOCTOU repair

File:

`backend/app/services/transactions_service.py`

`exchange_partial_available_kwh_to_main` and
`exchange__all__available_kwh_to_main` now:

- close preflight/autobegin state with an entry rollback guard;
- acquire the user row lock first;
- only then check idempotency by `idempotency_key`;
- perform balance and `exchanged_kwh_total` updates only after same-key
  read-through is ruled out under the lock.

This removes the pre-lock idempotency race window.

## Tests / guards

Updated active guard:

`tests/architecture/test_economic_risk_guards.py`

New protected checks:

- `test_withdraw_cancel_and_reject_refund_are_atomic`
- `test_exchange_idempotency_check_inside_lock_retry_loop`

Existing cycle 1422 and 1423 checks remain active.

## Local checks

Targeted economic guard:

```text
PYTHONPATH=backend python3 -m pytest -q tests/architecture/test_economic_risk_guards.py
6 passed
```

Broader architecture pack was run before final archive creation. Results are
recorded in the cycle report.

## Sandbox / map_element use

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` and the uploaded sandbox archives were used only as
reference/navigation context. Runtime code, CI files, lock files, wallet/payment
logic, translations and foreign economy were not imported.

## Not claimed

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- full npm build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect/wallet proof.

## Status

`FIND-003` and `FIND-005` are repaired and guarded.

Remaining economic audit plan:

- cycle `1425`: `FIND-006..010` cleanup and reconciliation hardening.

---

## Источник: `WORK_CYCLES_1425_ECONOMIC_CLEANUP_RECONCILIATION.md`

# Work cycle 1425 — Economic cleanup and reconciliation hardening

Status: DONE.
Archive output: `EFHC_Bot_v170_00_cycle_1425_economic_cleanup_reconciliation.zip`.
Input HEAD: `EFHC_Bot_v169_99_cycle_1424_withdraw_exchange_atomicity_repair.zip`.

## Goal

Close the remaining P2/P3 findings from the P0 economic audit after P0/P1
money-loss and double-operation risks were repaired in cycles `1422-1424`.

## Scope

Closed findings:

- `FIND-006`: rejected `exchange_all` zero-amount transfer-log direction;
- `FIND-007`: direct exchange function transaction-boundary safety;
- `FIND-008`: duplicate `_tx_context` in `withdraw_service.py`;
- `FIND-009`: legacy strict kWh check using stored `available_kwh` column;
- `FIND-010`: `credit_user_bonus_from_bank` accepting `meta` but not persisting
  it to the transfer log.

Added hardening:

- `INV-08` reconciliation guard reference:
  `SUM(user.main_balance + user.bonus_balance) + bank.balance = const` for
  non-emission operations.

## Repairs

### FIND-006

`exchange__all__available_kwh_to_main` now treats `available_kwh=0` as a
non-financial rejected operation:

- no `efhc_transfers_log` row is written;
- no false `direction="debit"` or `direction="credit"` is used;
- the returned result uses `reason="exchange_rejected_no_kwh"`;
- the audit payload remains in `TxResult.meta`.

### FIND-007

The cycle keeps the direct-call exchange rollback guard introduced in `1424` and
adds explicit guards proving that exchange helpers close autobegin/preflight
state before writing money.

### FIND-008

`withdraw_service.py` imports `_tx_context` from `transactions_service.py` and
no longer owns a local duplicate implementation.

### FIND-009

`exchange_kwh_to_efhc(strict_kwh_check=True)` calculates available kWh from
`total_generated_kwh` and `exchanged_kwh_total`, not from stored
`available_kwh`.

### FIND-010

`credit_user_bonus_from_bank` passes `meta=meta` into `_run_idempotent` so bonus
credit audit metadata persists with the transfer log.

## Updated files

Runtime:

- `backend/app/services/transactions_service.py`
- `backend/app/services/withdraw_service.py`

Tests:

- `tests/architecture/test_economic_risk_guards.py`

Docs / navigation:

- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `ops/operator_kernel/cache/file_map.json`

## Guards

`tests/architecture/test_economic_risk_guards.py` now additionally protects:

- `test_exchange_all_zero_available_log_direction_correct`
- `test_exchange_partial_called_with_open_transaction_safe`
- `test_withdraw_service_no_local_tx_context_copy`
- `test_exchange_kwh_strict_uses_ssot_calculation_not_column`
- `test_credit_bonus_meta_written_to_log`
- `test_reconciliation_sum_invariant_after_all_ops`

## Sandbox use

Песочница использована только как reference/navigation layer. Runtime-код не
переносился.

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, full npm build,
release-ready status, browser screenshots, live Telegram proof or real wallet
proof.

---

## Источник: `WORK_CYCLES_1426_PANEL_DEAD_TX_CONTEXT_CLEANUP.md`

# Cycle 1426 — Panel dead transaction-context cleanup

Status: DONE.
Archive: `EFHC_Bot_v170_01_cycle_1426_panel_dead_tx_context_cleanup.zip`.
Input HEAD: `EFHC_Bot_v170_00_cycle_1425_economic_cleanup_reconciliation.zip`.
Audit source: `docs/audits/P0_ECONOMIC_REAUDIT_V170_00_CYCLE_1425.md`.
Verdict source: `ECONOMY_SAFE_WITH_MINOR_FINDINGS`.

## Goal

Close `NEW-001` from the v170.00 economic re-audit: remove the dead local
`_tx_context` helper in `backend/app/services/panels_service.py` that still used
`db.begin_nested()` and could tempt a future developer to reintroduce the
forbidden HEAL-0018 savepoint fallback pattern.

## Repair

- Removed the unused local `def _tx_context(db: AsyncSession)` from
  `panels_service.py`.
- Preserved the canonical transaction owner for panel activation:
  `bank._tx_context(db)` from `transactions_service.py`.
- Updated the panels service header comment to state the current atomicity
  model: EFHC spend and panel row creation are committed or rolled back
  together.
- Added `test_panels_service_no_local_tx_context` to
  `tests/architecture/test_economic_risk_guards.py`.

## Guard meaning

The guard forbids:

- local `_tx_context` in `panels_service.py`;
- `db.begin_nested()` in `panels_service.py`;
- future panel-service transaction-boundary drift away from
  `bank._tx_context(db)`.

## Sandbox / map_element

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` and the uploaded sandbox archives were used only as a
reference/navigation layer. No Vue/Solid/Nuxt/Vanilla runtime, CI file, lock
file, wallet/payment logic, foreign economy or translation was imported.

## Checks

Targeted local checks:

- `tests/architecture/test_economic_risk_guards.py`
- targeted architecture pack including filename hygiene and P0 economic guards
- `scripts/ci/check_ai_archive_laws_integrity.py`
- ZIP `testzip`

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, frontend build,
release-ready status, screenshots, live Telegram client proof or real
TonConnect/wallet proof.

## Result

`NEW-001` is closed. The economic re-audit condition for removing dead
`panels_service._tx_context` is satisfied locally, but a general release-ready
claim still requires a separate release audit and full external CI/build proof.

---

## Источник: `WORK_CYCLES_1427_CI_LOG_REPAIR.md`

# Work cycle 1427 — CI log repair after economic cleanup

## Status

`DONE`

## HEAD input

`EFHC_Bot_v170_01_cycle_1426_panel_dead_tx_context_cleanup.zip`

## Log input

`logs_72342361356.zip`

## Goal

Repair exact failures from the supplied CI logs without weakening tests,
without hiding guards and without changing EFHC economics.

## Root causes repaired

1. `ruff I001` in `withdraw_service.py` import ordering.
2. `line72` violations in `panels_service.py`.
3. degraded `_main_` tokens in new economic helper/test names.
4. incomplete Healer card schema in `atlas.json`.

## Runtime files changed

- `backend/app/services/withdraw_service.py`
- `backend/app/services/panels_service.py`
- `backend/app/services/transactions_service.py`

## Test files changed

- `tests/architecture/test_economic_risk_guards.py`

## Documentation updated

- `docs/audits/CI_LOG_REPAIR_1427_LOGS_72342361356.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`

## Verification

Local targeted verification:

- CI failure pack from logs: passed locally.
- `tests/architecture/test_economic_risk_guards.py`: passed locally.
- broader targeted architecture/healer pack: passed locally.
- AI Archive Laws integrity: passed locally.
- ZIP integrity: passed locally.

## Non-claims

No GitHub CI green, full pytest green, frontend build green, release-ready,
browser screenshot proof, live Telegram proof or real wallet proof is claimed
by this local cycle.

## Range status

After cycle `1427`, range `1401-1500` progress is:

- done: `27 / 100`;
- remaining: `73 / 100`.

Next safe step: fresh CI log, release audit or direct user task.

---

## Источник: `WORK_CYCLES_1428_SECURITY_AUDIT_RECONCILIATION_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work cycle 1428 — security audit reconciliation and repair plan

## Status

DONE as planning/reconciliation cycle.

## HEAD input

`EFHC_Bot_v170_02_cycle_1427_ci_log_repair.zip`

## Audit input

`docs/audits/P0_SECURITY_AUDIT_V170_01.md`

Verdict from audit: `P0_RELEASE_BLOCKED`.

The audit reports:

- P0: 2;
- P1: 0;
- P2: 3;
- P3: 0;
- inspected backend HTTP routes: 133;
- inspected `/admin/*` routes: 55;
- minimum repair cycles: 3.

## Scope of this cycle

This cycle does not repair runtime security code. It resolves the audit truth
split, records security decisions, archives the audit, updates documents, and
creates the next repair plan.

No wallet, cron, Telegram auth, frontend auth, CORS, CI workflow, lock file,
AI Archive Laws, or EFHC economic runtime change is made here.

## Truth reconciliation

The audit title references `v170.01`, while the audit body states that the
actually inspected archive was `v170.02`. The current working archive is also
`v170.02`.

Decision:

- v170.02 is the factual HEAD for this line;
- the security audit is accepted as applying to `v170.02`;
- `v170.01` in the title is treated as target-label drift;
- all follow-up security repair cycles continue from `v170.02`.

This resolves the truth split without pretending that release is safe.

## Resolved audit questions

### Q1 — canonical wallet binding contour

Answer: canonical production wallet binding is TonConnect proof through the
current wallet routes/service/proof service contour.

Production must not accept naked address-only binding as a wallet ownership
proof. Legacy/memo-style binding may remain only if it is deprecated or upgraded
to the same verified-proof invariant.

### Q2 — production entrypoint

Answer: both entrypoints must have the same security behavior.

The project must not use entrypoint uncertainty to leave weaker CORS/header or
startup behavior in one path. `backend/app/main.py` and
`backend/app/__init__.py:create_app` must converge.

### Q3 — archive version for final verdict

Answer: repair and later verdicts are based on the latest actual HEAD in this
line, starting from `v170.02`. The audit is archived as evidence and the label
mismatch is documented.

## Repair plan after this cycle

### Cycle 1429 — P0 security blockers

Goal: close both release blockers.

Work:

1. Wallet binding proof boundary:
   - reject `/wallets/connect` without verified TonConnect proof;
   - bind proof to current `tg_id`, domain, TTL, nonce/payload token and
     address;
   - reject proof replay;
   - wallet-gated money routes must accept only verified binding.

2. Cron secret control-plane boundary:
   - remove repository-known working default for `CRON_SECRET`;
   - production/stage fail fast on empty/default/placeholder/short secret;
   - `/cron/tick` rejects missing/wrong/default secret;
   - update `env.prod.example` with placeholder-only guidance.

Required tests:

- `/wallets/connect` rejects unverified address-only bind;
- verified proof is required for wallet binding;
- proof replay does not create verified binding;
- wallet-gated money routes reject naked address-only binding;
- `/cron/tick` rejects missing/wrong/default secret in production mode;
- production startup fails on unsafe `CRON_SECRET`.

### Cycle 1430 — P2 replay, OPSEC and legacy headers

Goal: close P2 findings.

Work:

1. Telegram `initData` freshness:
   - `auth_date` is required;
   - missing/non-numeric/expired `auth_date` fails closed.

2. Logging redaction:
   - cover `BOT_TOKEN`, `SECRET_KEY`, `ADMIN_API_KEY`,
     `TELEGRAM_WEBHOOK_SECRET`, `CRON_SECRET` and TON provider aliases.

3. Legacy frontend headers:
   - remove production emission of `X-Telegram-User-Id`;
   - remove production emission of `X-Admin-Id` and `X-Admin-Token`;
   - update user-facing/security docs so frontend guard remains UX-only.

Required tests:

- missing `auth_date` returns unauthorized;
- non-numeric `auth_date` returns unauthorized;
- redactor masks all production secret aliases;
- frontend runtime does not emit legacy auth/admin headers.

### Cycle 1431 — regression hardening and security re-audit prep

Goal: prove that the repair is guarded across the route surface.

Work:

- AST guard: every `/admin/*` route has `Depends(require_admin)`;
- ownership tests for wallet/order/withdraw/payment intent routes;
- production docs/openapi/redoc safety tests;
- production CORS safety tests;
- monetary/auth-sensitive rate-limit coverage tests;
- callback/webhook secret-before-dedupe tests;
- prepare repeat security audit on the new HEAD.

## Test/guard policy

No test may be deleted, skipped, xfailed, hidden, or weakened to make the
security lane pass. The repair must close the root cause, not the symptom.

## Sandbox use

Песочница used only as reference/navigation layer through `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
No sandbox runtime, CI files, lock files, wallet/payment logic, economics,
secrets, configs, or translations were imported.

## Non-claims

This cycle does not claim:

- P0 fixed;
- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect/wallet proof.

---

## Источник: `WORK_CYCLES_1429_P0_SECURITY_REPAIR.md`

# Work cycle 1429 — P0 security repair

## Status

DONE locally; repeat security audit still required before any release-ready
claim.

## HEAD input

`EFHC_Bot_v170_03_cycle_1428_security_audit_reconciliation_plan.zip`

## Audit input

`docs/audits/P0_SECURITY_AUDIT_V170_01.md`

Verdict entering the cycle: `P0_RELEASE_BLOCKED`.

## Goal

Close the two P0 release blockers from the supplied security audit:

1. wallet binding without mandatory TonConnect proof;
2. repository-known/default `CRON_SECRET` for `/cron/tick`.

## Runtime repairs

### Wallet proof boundary

Files changed:

- `backend/app/schemas/wallet_schemas.py`;
- `backend/app/routes/wallets_routes.py`;
- `backend/app/services/wallets_service.py`;
- `backend/app/models/wallets_models.py`;
- `backend/migrations/versions/0001_init.py`.

Changes:

- `/wallets/connect` now requires TonConnect proof fields in the request body;
- the route calls `tonconnect_proof_service.check_proof()` before binding;
- `wallets_service.connect_wallet()` now requires
  `verified_proof_payload_token` and `verified_proof_source`;
- wallet binding rows now store proof markers:
  `proof_verified`, `proof_verified_at`, `proof_payload_hash`,
  `proof_source`;
- `require_wallet_connected()` is backed by `has_active_wallet()`, which now
  accepts only active verified bindings;
- `wallet_proof_token_uses` records single-use proof token hashes and rejects
  replay with a different idempotency key;
- 0001 fresh/create-all and existing-DB repair paths know the new proof columns.

### Cron control-plane boundary

Files changed:

- `backend/app/core/config_core.py`;
- `backend/app/routes/system_routes.py`;
- `env.prod.example`;
- `env.example`.

Changes:

- removed the working default `CRON_SECRET` from settings;
- prod/stage fail fast when `CRON_SECRET` is empty, placeholder, too short or
  equal to the legacy repository-known secret hash;
- `/cron/tick` fails closed in prod/stage when no secret exists;
- local/dev/ci may keep an empty cron secret for development;
- `env.prod.example` now contains only a placeholder cron secret.

## Guards / tests

Added:

- `tests/architecture/test_security_p0_repair_guards.py`.

Protected meanings:

- `/wallets/connect` cannot bind a naked address without proof;
- wallet-gated money routes require verified wallet bindings;
- TonConnect proof replay is blocked by a single-use token marker;
- `CRON_SECRET` has no working default;
- prod/stage startup must fail on unsafe cron secret values;
- `/cron/tick` compares only against the ENV-provided secret.

Updated runtime wallet tests:

- `tests/test_wallets_connect_hardening.py`;
- `tests/wallets_ton_testkit.py`.

## Documents updated

- `docs/security/P0_SECURITY_REPAIR_CANON.md`;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`;
- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`;
- `docs/SSOT/ssot_pack/SSOT_TABLES_PURPOSE_RU.md`;
- `HEALER_ATLAS.md`;
- `docs/healer/HEALER_ATLAS.md`;
- `docs/healer/HEALER_CASEBOOK.md`;
- `atlas.json`;
- `casebook.json`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`;
- `ops/operator_kernel/cache/file_map.json`.

## Sandbox use

Песочница used only as reference/navigation layer through `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
No sandbox runtime, CI files, lock files, wallet/payment donor logic, secrets,
configs, economics or translations were imported.

## Non-claims

This cycle does not claim:

- repeat security audit passed;
- release-ready;
- GitHub CI green;
- full pytest green;
- frontend build green;
- browser screenshots;
- live Telegram proof;
- real wallet proof in a Telegram client.

## Next cycle

`1430` — close P2 replay / OPSEC / legacy header findings.

---

## Источник: `WORK_CYCLES_1430_SECURITY_P2_REPLAY_OPSEC.md`

# Work cycle 1430 — security P2 replay / OPSEC / legacy headers repair

## Status

DONE locally.

## HEAD input

`EFHC_Bot_v170_04_cycle_1429_p0_security_repair.zip`

## Audit input

`docs/audits/P0_SECURITY_AUDIT_V170_01.md`

The active security audit listed three P2 findings after the P0 blockers:

- `P2-01` — Telegram initData did not fail closed on missing or malformed
  `auth_date`;
- `P2-02` — secrets redactor did not cover all production secret aliases;
- `P2-03` — frontend / compat layers still emitted or allowed legacy
  identity/admin headers.

## Scope of this cycle

This cycle repairs only P2 replay/OPSEC/legacy-header findings. It does not
change EFHC economics, wallet proof logic from cycle 1429, CI workflow files,
lock files, AI Archive Laws or production deployment topology.

## Repairs

### Telegram initData freshness

`backend/app/core/security_core.py` now treats `auth_date` as mandatory.
Missing or non-numeric `auth_date` fails closed with 401 before user identity is
accepted.

Added unit coverage in `tests/efhc_backend/unit/test_telegram_init_data.py`:

- missing `auth_date` fails;
- non-numeric `auth_date` fails;
- expired `auth_date` remains rejected.

### Secrets redaction

`backend/app/core/logging_core.py` redaction aliases now cover production
control-plane and provider secrets:

- `BOT_TOKEN` / `TELEGRAM_BOT_TOKEN`;
- `SECRET_KEY`;
- `ADMIN_API_KEY`;
- `TELEGRAM_WEBHOOK_SECRET` / `WEBHOOK_SECRET`;
- `CRON_SECRET` / `SCHED_CRON_SECRET`;
- `TON_API_KEY` / TonCenter aliases;
- database and Supabase aliases.

The redactor also masks assignment-style log fragments such as
`CRON_SECRET=value` and `ADMIN_API_KEY:value`.

### Legacy frontend/admin headers

`frontend/src/lib/api.ts` now sends only `X-Telegram-Init-Data` as the client
Telegram identity source. It no longer falls back to `initDataUnsafe.user.id`,
`X-Telegram-User-Id`, localStorage admin id, `X-Admin-Id` or `X-Admin-Token`.

The admin landing page no longer stores or reads `EFHC_ADMIN_ID` /
`EFHC_ADMIN_TOKEN` and now describes admin access as backend-enforced through
Telegram initData / `require_admin`.

The CORS allow-header lists in both `backend/app/main.py` and the compatibility
entrypoint `backend/app/__init__.py` no longer include legacy identity/admin
headers.

## New active guard

`tests/architecture/test_security_p2_replay_opsec_headers.py`

Protected invariants:

- Telegram initData requires strict `auth_date` freshness;
- redactor covers production secret aliases;
- frontend runtime does not emit legacy auth/admin headers;
- backend CORS compatibility layers do not allow legacy auth/admin headers;
- this cycle's documents exist.

## Sandbox reference use

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` and the uploaded sandbox archives were used only as
reference/navigation context for Telegram Mini App auth surface and wallet/admin
boundary discipline. No Vue/Solid/Nuxt/Vanilla runtime, lock file, CI file,
wallet/payment logic, economics, secrets/configs or translations were imported.

## Non-claims

This local cycle does not claim:

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect / wallet proof.

## Next cycle

`1431 — security regression hardening + repeat audit preparation`.

---

## Источник: `WORK_CYCLES_1431_SECURITY_REGRESSION_HARDENING.md`

# Cycle 1431 — Security regression hardening and repeat-audit prep

## Status

`DONE locally / repeat security audit pending`

## Base archive

`EFHC_Bot_v170_05_cycle_1430_security_p2_replay_opsec_repair.zip`

## Goal

Close the regression-hardening layer planned in cycle 1428 after the P0 and P2
security repairs:

- guard every backend `/admin/*` route with backend `require_admin`;
- guard owner-scoped money routes against frontend/user supplied identity drift;
- guard production docs and CORS safety;
- guard Telegram webhook secret-before-dedupe order;
- prepare repeat security audit without claiming release-ready.

## Runtime hardening applied

`backend/app/routes/system_routes.py` no longer registers Telegram webhook dedupe
through a FastAPI dependency before the webhook secret is checked. The route now
verifies `X-Telegram-Bot-Api-Secret-Token` first and only then calls
`register_external_event_after_secret()`.

`backend/app/deps.py` now exposes `register_external_event_after_secret()` as
the canonical helper for secret-protected webhook/callback routes. The old
`external_event_dedupe_dep()` remains available for routes without provider
secret pre-check, but secret-protected routes must not use it before auth.

## Guards added

New active guard file:

`tests/architecture/test_security_regression_hardening.py`

Protected meanings:

1. All backend admin route files must have backend `Depends(require_admin)` for
each route decorator.
2. Owner-scoped payment/deposit/withdraw/wallet routes must use authenticated
Telegram identity and ownership-scoped service calls.
3. Production docs/OpenAPI/Redoc must be configurable to null and prod CORS must
reject wildcard origin with credentials.
4. Telegram webhook dedupe must run only after webhook secret validation.
5. Cycle 1431 documents must remain present.

## Files changed

Runtime:

- `backend/app/deps.py`
- `backend/app/routes/system_routes.py`

Tests:

- `tests/architecture/test_security_regression_hardening.py`

Docs / navigation:

- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/security/P0_SECURITY_REPAIR_CANON.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `ops/operator_kernel/cache/file_map.json`

## Sandbox note

Песочница использована только как reference/navigation layer. Runtime-код,
wallet/payment logic, CI files, lock files, configs, secrets, экономика и
переводы не переносились.

## Non-claims

This cycle does not claim:

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe step

Repeat security audit on the new archive or fresh CI logs.

---

## Источник: `WORK_CYCLES_1432_CI_LOG_REPAIR.md`

# Work cycle 1432 — CI log repair after security hardening

Status: DONE
HEAD before cycle: `EFHC_Bot_v170_06_cycle_1431_security_regression_hardening.zip`
HEAD after cycle: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`
Log source: `logs_72432961872.zip`

## Goal

Fix factual CI errors from the supplied logs without weakening tests, security
boundaries, economic invariants or AI Archive Laws.

## Fixed errors

- `ruff UP037` in `wallet_schemas.py`.
- `bandit B105` on a legacy cron digest constant name.
- SSOT table-count drift after adding `wallet_proof_token_uses`.
- stale Wave10 spend guard after nocommit spend refactor.
- stale panel activation guard after atomic nocommit panel activation.
- invalid Healer enum value `locally_treated` / maturity `guarded`.
- wallet proof replay test returning `WALLET_CONFLICT` before replay rejection.

## Files changed

Runtime:
- `backend/app/schemas/wallet_schemas.py`
- `backend/app/core/config_core.py`
- `backend/app/services/wallets_service.py`

Tests / guards:
- `tests/architecture/test_security_p0_repair_guards.py`
- `tests/architecture/test_economic_audit_guards.py`
- `tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py`
- `ops/routes/check_panel_activation.py`

Docs / SSOT / Healer:
- active DB SSOT docs and migration diagnostic docs updated to 43 tables;
- `atlas.json`, `casebook.json`, Healer docs updated;
- test guard manifest and Q&A updated.

## Verification

Local targeted checks:
- AI Archive Laws integrity: passed.
- `compileall backend/app`: passed.
- targeted architecture/security/economic/healer pack: passed.

Not claimed:
- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready.

---

## Источник: `WORK_CYCLES_1433_OPERATOR_KERNEL_FIRST_STANDARD_HARDENING.md`

# Cycle 1433 — Operator Kernel First Standard hardening

Status: DONE. Mode: KERNEL HARDENING / DOCS-ONLY / NO RUNTIME LOGIC CHANGE.
Archive output: `EFHC_Bot_v170_08_cycle_1433_operator_kernel_first_standard_hardening.zip`.

## Goal

Strengthen the existing EFHC Operator Kernel with Kernel-first discipline:

- short root Kernel;
- no encyclopedia Kernel;
- active truth hierarchy;
- read-before-edit;
- search-before-claim;
- no fake verification;
- no CANON/SSOT drift;
- permission matrix;
- stable vs dynamic Kernel separation;
- risk-zone routing;
- next-agent entry sequence.

## Created

- `docs/NORM/EFHC_OPERATOR_KERNEL_FIRST_STANDARD.md`.

## Updated

- `KERNEL.md`;
- `docs/AI/READING_ENTRYPOINT.md`;
- `docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md`;
- `docs/NORM/EFHC_OPERATOR_KERNEL_PERMISSION_STANDARD.md`;
- `docs/NORM/EFHC_OPERATOR_KERNEL_PATCH_STANDARD.md`;
- `docs/NORM/EFHC_OPERATOR_KERNEL_VALIDATION_STANDARD.md`;
- `ops/operator_kernel/config/routes.yaml`;
- `ops/operator_kernel/cache/file_map.json`;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`;
- `reports/REPORTS_INDEX.md`;
- `docs/cycles/WORK_CYCLES.md`;
- `docs/AI/TOPIC_READING_ROUTES.md`;
- `docs/AI/ARCHIVE_FAST_MANIFEST.md`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.

## Not changed

- runtime code;
- business logic;
- security/auth logic;
- money-flow logic;
- tests;
- CI/workflows;
- lock files.

## Notes

No new competing root Kernel was created. The existing Operator Kernel was
strengthened by a NORM standard and references from the active entry points.
Dynamic CI/log facts remain in cycles/reports, not in `KERNEL.md`.

Песочница and template archives were used only as reference/navigation context.
No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment logic,
foreign economy, secrets/configs or translations were imported.

---

## Источник: `WORK_CYCLES_1434_SECURITY_MINOR_REPAIR.md`

# Cycle 1434 — Security minor findings repair

Archive: `EFHC_Bot_v170_09_cycle_1434_security_minor_repair.zip`
Base archive: `EFHC_Bot_v170_08_cycle_1433_operator_kernel_first_standard_hardening.zip`
Mode: `SECURITY REPAIR / TARGETED / AUDIT-DRIVEN`
Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_08.md`

## Goal

Close the remaining non-P0 findings from the v170.08 security audit without
changing EFHC economy, wallet proof canon or unrelated runtime behavior.

## Closed findings

### FIND-02 — P1 — ADS_TEST_MODE prod/stage fail-fast

`ADS_TEST_MODE` is now an explicit settings field. Production/stage startup
must fail if it is true. `env.prod.example` records `ADS_TEST_MODE=false`.

### FIND-04 — P1 — monetary rate-limit prefixes

`/deposit` and `/payment-intents` are now included in the default prefixes for
both monetary idempotency and monetary rate-limit middleware paths in
`backend/app/core/system_locks.py`.

### FIND-05 — P2 — env.prod.example operational addresses

Real-looking TON operational addresses in `env.prod.example` were replaced with
placeholders. This is OPSEC housekeeping and not an economy change.

## Files changed

Runtime/config:

- `backend/app/core/config_core.py`
- `backend/app/core/system_locks.py`
- `env.prod.example`

Tests/guards:

- `tests/architecture/test_security_audit_v170_08_minor_repair.py`
- `tests/architecture/test_monetary_rate_limit_enabled.py`

Docs/indexes:

- `docs/audits/P0_SECURITY_AUDIT_V170_08.md`
- `docs/audits/p0_security_audit_v170_08.json`
- `docs/security/P0_SECURITY_REPAIR_CANON.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `reports/REPORTS_INDEX.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`

## Guard requirements

- `test_ads_test_mode_forbidden_in_prod`
- `test_monetary_rate_limit_covers_deposit_and_payment_intents`
- `test_env_prod_example_uses_placeholders_for_ton_addresses`

## Verification

Local targeted verification was executed for the new security minor repair
architecture guards, monetary rate-limit guard, AI Archive Laws integrity,
compileall and ZIP integrity.

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, frontend build
green, browser screenshots, live Telegram proof or real TonConnect proof.

## Sandbox use

Песочница was used only as a reference/navigation layer through `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
No sandbox runtime code, CI files, lock files, wallet/payment logic, configs,
secrets, economy or translations were imported.

---

## Источник: `WORK_CYCLES_1435_COLD_START_UX_ASSET_OPTIMIZATION.md`

# Cycle 1435 — Cold start MVP UX and bot image optimization

Status: DONE locally.
Archive: `EFHC_Bot_v170_10_cycle_1435_cold_start_ux_asset_optimization.zip`.
Base archive: `EFHC_Bot_v170_09_cycle_1434_security_minor_repair.zip`.

## Goal

Record the user decision that Cloud Run / Neon cold start is not an MVP
blocker when EFHC Bot preserves cached shell first, visual loading/effect
and stale-while-revalidate data refresh. Optimize the bot/skin hero image
used on first paint.

## Canon fixed

- Cold start is not an MVP blocker by itself.
- First screen must not wait for the database.
- Alembic migrations must not run on a user request.
- Heavy assets must not load before the visible interface.
- Backend must not be the only source of the initial visual state.
- Cloud Run `min instances = 0` and Neon Free / scale-to-zero are allowed
  for MVP.
- Cloud Scheduler health ping is allowed when operationally needed.
- Stale-while-revalidate is allowed for non-critical visual data.

## Asset optimization

- Source: `frontend/public/skins/1.webp`.
- Optimized runtime asset: `frontend/public/skins/1.webp`.
- Original PNG size: 1,146,051 bytes.
- WebP runtime size: 197,804 bytes.
- Reduction: about 82.7 percent for the first-paint asset.
- Runtime CSS now uses `/skins/1.webp` for `.efhc-energy-stage_image`.

## Files changed

- `docs/NORM/COLD_START_MVP_UX_CANON.md`
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
- `docs/SSOT/PROJECT_ASSET_LINKS.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_FAST_MANIFEST.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- `reports/REPORTS_INDEX.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `frontend/public/skins/README.txt`
- `frontend/public/skins/1.webp`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_cold_start_mvp_ux_asset_guard.py`

## Non-changes

- No backend runtime logic change.
- No business or economy logic change.
- No security/auth/money-flow change.
- No CI/workflow/lock-file change.
- No Alembic or DB migration change.

## Verification

Local targeted checks were run for AI law lock, architecture guard,
operator kernel tests, max line length, compileall and ZIP integrity.
No GitHub CI green, full pytest green, frontend build green, screenshot,
live Telegram proof or real wallet proof is claimed.

---

## Источник: `WORK_CYCLES_1436_MIGRATIONS_ROUTES_LINKAGE_FREEZE.md`

# Cycle 1436 — Migrations / Routes / Backend-Frontend Linkage Freeze

Status: DONE.  
Archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`  
Base archive: `EFHC_Bot_v170_10_cycle_1435_cold_start_ux_asset_optimization.zip`  
Mode: DOCS-ONLY / AUDIT REGISTRATION / NO RUNTIME LOGIC CHANGE.

## Goal

Register the active P0 linkage audit as the current release blocker and create
machine-readable finding index for the next repair cycles.

## Input audit

- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- Verdict: `P0_RELEASE_BLOCKED`

## Registered blockers

- `F-001` P0 — admin bank mint/burn uses non-SSOT tables.
- `F-002` P0 — deposit watcher uses legacy `user_wallets` instead of canonical
  `wallet_bindings`.
- `F-003` P1 — admin reports overview uses wrong bank table.
- `F-004` P1 — Admin Hub route prefix drift.
- `F-005` P1 — admin wallet reset semantic mismatch.
- `F-006` P1 — OpenAPI incomplete/stale.
- `F-007` / `F-008` P2 — frontend/UI/linkage guards missing.

## Created

- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `reports/change_cycle_2026-06-05_v170_11_cycle_1436_migrations_routes_linkage_freeze.md`

## Updated

- `KERNEL.md`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_FAST_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `reports/REPORTS_INDEX.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/cache/file_map.json`

## Not changed

- runtime code;
- backend services/routes/models;
- frontend code;
- tests;
- migrations;
- CI/workflows;
- lock files;
- business logic;
- EFHC economics.

## Next cycles

- `1437` — P0 Bank SSOT repair.
- `1438` — P0 Deposit watcher wallet SSOT repair.
- `1439` — Admin reports bank table repair.
- `1440` — Admin Hub route prefix repair.
- `1441` — Admin wallet reset semantic repair.
- `1442` — OpenAPI rebuild and strict contract gate.
- `1443` — Full linkage architecture tests.

---

## Источник: `WORK_CYCLES_1436_USER_DECISIONS_DOC_UPDATE.md`

# Cycle 1436 — User Decisions Lock / Linkage Repair Answers

Status: DONE.  
Archive: `EFHC_Bot_v170_12_cycle_1436_user_decisions_doc_update.zip`  
Base archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`  
Mode: DOCS-ONLY / USER DECISIONS LOCK / NO RUNTIME LOGIC CHANGE.

## Goal

Update the active linkage audit documents after the user answered the remaining repair questions.

## User decisions

1. `F-001 / cycle 1437`: do not create a separate `efhc_mint_burn` ledger/table. Use only existing official/canonical tables and ledger surfaces.
2. `F-005 / cycle 1441`: admin wallet reset must fully unbind canonical `wallet_bindings`.
3. `F-004 / cycle 1440`: Admin Hub is a separate admin section with canonical path `/admin/hub/*`.
4. Future iteration questions must use the approved simple format: problem, simple question, options, recommendation, short recommended answers.

## Updated documents

- `docs/NORM/ITERATION_QUESTIONS_FORMAT_STANDARD.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `KERNEL.md`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- `reports/REPORTS_INDEX.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/cache/file_map.json`

## No runtime changes

This update does not change runtime code, backend services/routes/models, frontend code, tests, migrations, CI/workflows, lock files, business logic, economy, security/auth logic or money-flow.

## Next safe step

Cycle `1437` — P0 Bank SSOT repair using only existing official/canonical tables.

---

## Источник: `WORK_CYCLES_1437_P0_BANK_SSOT_REPAIR.md`

# Cycle 1437 — P0 Bank SSOT repair

Status: DONE locally in `v170.13`.
Base HEAD: `EFHC_Bot_v170_12_cycle_1436_user_decisions_doc_update.zip`.

## Goal

Close linkage finding `F-001`: admin bank mint/burn must not depend on tables outside ORM/migration SSOT.

User decision applied:

- do not create a separate `efhc_mint_burn` ledger/table;
- do not create a new ledger for rare admin mint/burn operations;
- use existing official/canonical tables and ledger surfaces only.

## Runtime repair

Changed:

- `backend/app/services/admin/admin_bank_service.py`
- `backend/app/services/transactions_service.py`

Result:

- `/admin/bank/mint` now delegates bank supply change to `transactions_service.mint_bank_efhc()`;
- `/admin/bank/burn` now delegates bank supply change to `transactions_service.burn_bank_efhc()`;
- canonical bank balance remains `efhc_core.bank_balance`;
- canonical idempotency/audit ledger is `efhc_core.efhc_transfers_log`;
- admin action audit remains `efhc_admin.admin_action_log` through `AdminLogger.write()`;
- the runtime dependency on the former separate mint/burn ledger was removed;
- the bank rollback/list helper now reads from `efhc_core.efhc_transfers_log` instead of the former rollback journal.

No migration was added. No new table was created. No EFHC economics were changed.

## Guards / tests

Added:

- `tests/architecture/test_admin_bank_ssot_repair.py`

Protected checks:

- `test_bank_money_routes_use_only_migrated_tables`
- `test_money_routes_have_service_layer`
- `test_no_direct_balance_write_outside_transactions_service`
- `test_admin_bank_mint_burn_are_idempotent`
- `test_admin_bank_mint_burn_have_admin_guard`
- `test_admin_bank_mint_burn_write_audit_log`
- `test_frontend_admin_bank_waits_for_backend_confirmation`

## Local validation performed

Executed locally:

```text
python -m pytest tests/architecture/test_admin_bank_ssot_repair.py -q
# 7 passed

python -m pytest   tests/architecture/test_admin_bank.py   tests/architecture/test_admin_bank_variant_a.py   tests/architecture/test_admin_bank_ssot_repair.py   tests/architecture/test_financial_integrity.py   tests/architecture/test_migration_0001_orm_ssot_sync.py   -q
# 35 passed

python -m py_compile backend/app/services/transactions_service.py backend/app/services/admin/admin_bank_service.py backend/app/routes/admin_routes.py
# passed
```

Additional attempted check:

```text
python -m pytest tests/architecture/test_bank_runtime_invariants.py -q
# 1 skipped; pytest returned status 5 because the file had no runnable test after import-skip in this local environment.
```

Not claimed:

- no GitHub CI green;
- no full pytest green;
- no frontend build green;
- no release-ready;
- no browser screenshots;
- no live Telegram/TonConnect proof.

## Remaining blockers

The archive is still not release-ready because the active linkage audit still has open blockers after F-001:

- `F-002` / cycle 1438: deposit watcher must use canonical `wallet_bindings`;
- `F-003` / cycle 1439: admin reports must use `efhc_core.bank_balance`;
- `F-004` / cycle 1440: Admin Hub canonical route `/admin/hub/*`;
- `F-005` / cycle 1441: admin wallet reset must unbind canonical `wallet_bindings`;
- `F-006` / cycle 1442: OpenAPI rebuild and strict contract gate;
- `F-007/F-008` / cycle 1443+: UI state guards and full linkage architecture tests.

Next safe cycle: `1438 — P0 Deposit watcher wallet SSOT repair`.

---

## Источник: `WORK_CYCLES_1438_P0_DEPOSIT_WATCHER_WALLET_SSOT_REPAIR.md`

# Cycle 1438 — P0 Deposit watcher wallet SSOT repair

Status: DONE locally in `v170.14`.
Base HEAD: `EFHC_Bot_v170_13_cycle_1437_p0_bank_ssot_repair.zip`.

## Goal

Close linkage finding `F-002`: deposit watcher and admin replay must use the canonical wallet SSOT `efhc_core.wallet_bindings`, not legacy `efhc_core.user_wallets` or `users.ton_wallet`.

## Runtime repair

Changed:

- `backend/app/services/watcher_service.py`

Result:

- `_find_user_by_wallet()` now reads `efhc_core.wallet_bindings`;
- watcher lookup requires `wallet_address = :wa`;
- only active bindings are accepted: `is_active = TRUE`;
- only verified bindings are accepted: `proof_verified = TRUE`;
- revoked/deactivated/unverified wallet bindings are not used for auto-credit;
- scheduler path and admin replay path stay unified because both call `process_incoming_tx()`;
- no migration was added;
- no new wallet table was created;
- no EFHC economics were changed.

## Admin replay chain

`/admin/efhc-deposits/reprocess/{tx_hash}` continues to call `reprocess_single_tx()`, and `reprocess_single_tx()` reconstructs the logged incoming transaction and sends it back through `process_incoming_tx()`. Therefore admin replay uses the same canonical `wallet_bindings` lookup as the scheduler watcher path.

## Guards / tests

Added:

- `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`

Protected checks:

- `test_deposit_watcher_uses_wallet_bindings_ssot`
- `test_deposit_reprocess_uses_wallet_bindings_ssot`
- `test_wallet_bound_deposit_is_matched_to_user`
- `test_revoked_wallet_binding_is_not_used_for_deposit_credit`
- `test_deposit_payment_intent_chain_complete`
- `test_admin_efhc_deposit_reprocess_has_admin_guard`
- `test_wallet_bindings_model_is_canonical_for_tonconnect`

## Bank start balance answer

The canonical start balance `5000000.00000000 EFHC` lives in two places with different roles:

1. **Physical DB seed / migration truth:** `backend/migrations/versions/0001_init.py` inserts/upserts `efhc_core.bank_balance` with `key='EFHC_MAIN'` and `balance=Decimal('5000000.00000000')`.
2. **Runtime fallback / service initialization:** `backend/app/services/admin/admin_bank_service.py` defines `BANK_INITIAL_TOTAL` with fallback `5000000` and passes it into `transactions_service.ensure_bank_initialized()` / `get_bank_balance()` when the bank row must be initialized by service code.

The active bank balance itself is stored in `efhc_core.bank_balance`, not in `users`, not in `efhc_admin.bank_balances`, and not in a separate mint/burn ledger.

## Local validation performed

Executed locally:

```text
python -m pytest tests/architecture/test_deposit_watcher_wallet_ssot_repair.py -q
# 7 passed

python -m py_compile backend/app/services/watcher_service.py backend/app/routes/admin_routes.py backend/app/services/wallets_service.py backend/app/services/admin/admin_bank_service.py
# passed
```

Additional local checks:

```text
python -m pytest tests/architecture/test_deposit_watcher_wallet_ssot_repair.py tests/architecture/test_admin_bank_ssot_repair.py tests/architecture/test_archive_filename_hygiene.py tests/architecture/test_operator_kernel_routes.py tests/architecture/test_operator_kernel_config_loading.py -q
# 27 passed

grep -RIn "user_wallets" backend/app/services/watcher_service.py
# no runtime hits
```

Not claimed:

- no GitHub CI green;
- no full pytest green;
- no frontend build green;
- no release-ready;
- no browser screenshots;
- no live Telegram/TonConnect proof.

## Remaining blockers

The archive is still not release-ready because the active linkage audit still has open blockers after `F-001` and `F-002`:

- `F-003` / cycle 1439: admin reports must use `efhc_core.bank_balance`;
- `F-004` / cycle 1440: Admin Hub canonical route `/admin/hub/*`;
- `F-005` / cycle 1441: admin wallet reset must unbind canonical `wallet_bindings`;
- `F-006` / cycle 1442: OpenAPI rebuild and strict contract gate;
- `F-007/F-008` / cycle 1443+: UI state guards and full linkage architecture tests.

Next safe cycle: `1439 — Admin reports bank table repair`.

Песочница использована только как reference/navigation layer. Runtime-код не переносился.

---

## Источник: `WORK_CYCLES_1439_ADMIN_REPORTS_BANK_TABLE_REPAIR.md`

# Cycle 1439 — Admin reports bank table repair

Status: DONE locally in `v170.15`.

## Goal

Close `F-003` from `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.

## Root problem

`GET /admin/reports/overview` read bank totals from legacy `efhc_admin.bank_balances` using old columns `balance_key` and `efhc_balance`, while the current canonical bank SSOT is `efhc_core.bank_balance` with `key` and `balance`.

## Runtime repair

Changed `backend/app/routes/admin_routes.py`:

```sql
from efhc_core.bank_balance
where key = 'EFHC_MAIN'
```

The route no longer reads:

```text
efhc_admin.bank_balances
balance_key = 'main'
efhc_balance
```

## User question: future mint through migrations

Answer: yes, the archive can forbid future bank mint/rewrite via migration guard while still allowing the first genesis seed.

Applied rule:

- `0001_init.py` is allowed to seed `5000000.00000000 EFHC` into `efhc_core.bank_balance` as genesis/bootstrap state.
- Any future migration that references `efhc_core.bank_balance`, `bank_balance`, `EFHC_MAIN` or `BANK_INITIAL_TOTAL` is treated as a violation by architecture guard unless explicitly redesigned in a separate approved cycle.
- Runtime mint/burn must use `AdminBankService` and `transactions_service`, not Alembic migrations.

## Files changed

Runtime:

- `backend/app/routes/admin_routes.py`
- `backend/app/services/admin/admin_stats_service.py` comments/log wording only

Tests:

- `tests/architecture/test_admin_reports_bank_ssot_repair.py`

Docs/indexes:

- `KERNEL.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/SSOT/EFHC_CANON.md`
- `docs/SSOT/ssot_pack/SSOT_RAW_SQL_USAGE.csv`
- `docs/SSOT/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`
- `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `reports/REPORTS_INDEX.md`

## Guards

Added:

- `test_admin_reports_overview_uses_bank_balance_ssot`
- `test_admin_reports_overview_response_shape_matches_frontend`
- `test_admin_bank_dashboard_uses_same_bank_total_as_bank_service`
- `test_openapi_admin_reports_overview_schema_matches_runtime`
- `test_future_bank_mint_via_migrations_is_forbidden_except_genesis_seed`

## Local validation

Executed locally:

```text
python -m pytest tests/architecture/test_admin_reports_bank_ssot_repair.py -q
```

Executed targeted compile:

```text
python -m py_compile backend/app/routes/admin_routes.py backend/app/services/admin/admin_stats_service.py
```

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, frontend build green, browser screenshots, live Telegram proof, real TonConnect proof or release-ready status.

## Remaining blockers

- `F-004` Admin Hub route prefix drift.
- `F-005` Admin wallet reset semantic mismatch.
- `F-006` OpenAPI stale/dead routes.
- `F-007` UI loading/error/empty state gaps.
- `F-008` full frontend API call → backend route guard gap.

Next safe step: `1440 — Admin Hub route prefix repair`.

---

## Источник: `WORK_CYCLES_1440_ADMIN_HUB_ROUTE_PREFIX_REPAIR.md`

# Cycle 1440 — Admin Hub route prefix repair

Status: DONE locally in `v170.16`.

## Goal

Close `F-004` from `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.

## Root problem

Admin Hub frontend and OpenAPI expected canonical paths under:

```text
/admin/hub/*
```

But the backend Hub router lived inside `backend/app/routes/admin_shop_routes.py` and was included through the `/admin/shop` router. That created route-prefix drift risk and could expose the accidental runtime shape:

```text
/admin/shop/admin/hub/*
```

## User decision applied

Admin Hub is a separate admin section.

Canonical backend/frontend/OpenAPI path:

```text
/admin/hub/*
```

## Runtime repair

Changed runtime routing:

1. Added dedicated router module:

```text
backend/app/routes/admin_hub_routes.py
```

2. Registered it in:

```text
backend/app/routes/__init__.py
```

3. Removed Hub router nesting from:

```text
backend/app/routes/admin_shop_routes.py
```

4. Kept Shop routes under:

```text
/admin/shop/*
```

5. Kept Admin Hub links manager under:

```text
/admin/hub/links
/admin/hub/links/{link_id}
/admin/hub/links/{link_id}/toggle
/admin/hub/links/reorder
```

## Frontend / OpenAPI alignment

Confirmed frontend already calls canonical Admin Hub paths from:

```text
frontend/src/features/admin/AdminHubPage.tsx
frontend/src/pages/admin/hub.tsx
```

Confirmed existing OpenAPI contract already contains canonical Admin Hub paths:

```text
/admin/hub/links
/admin/hub/links/{link_id}
/admin/hub/links/{link_id}/toggle
/admin/hub/links/reorder
```

Cycle 1440 did not rebuild the full OpenAPI file because cycle 1442 is the dedicated OpenAPI rebuild and strict contract gate. This cycle aligned runtime routing with the existing canonical OpenAPI paths.

## Tests / guards

Added active guard file:

```text
tests/architecture/test_admin_hub_route_prefix_repair.py
```

Protected invariants:

- `test_admin_hub_routes_match_frontend_and_openapi`
- `test_admin_hub_links_list_route_registered`
- `test_admin_hub_links_create_update_archive_routes_registered`
- `test_admin_hub_reorder_route_registered`
- `test_frontend_admin_hub_calls_existing_backend_routes`
- `test_admin_hub_router_is_not_nested_under_admin_shop`
- `test_admin_hub_chain_uses_hub_links_model_and_service`

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_admin_hub_route_prefix_repair.py -q
# 7 passed
```

Targeted Python compile passed for changed backend route files.

## Scope boundaries

No EFHC economy change.
No money-flow change.
No migration change.
No CI/workflow/lock-file change.
No test deletion, archival, skip or xfail.
No direct runtime transfer from Песочница.

Песочница used only as reference/navigation layer.

## Remaining blockers

`P0_RELEASE_BLOCKED` remains until later linkage findings are repaired and repeat linkage audit is performed.

Next safe cycle:

```text
1441 — Admin wallet reset semantic repair
```

---

## Источник: `WORK_CYCLES_1441_ADMIN_WALLET_RESET_SEMANTIC_REPAIR.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Cycle 1441 — Admin wallet reset semantic repair

Status: DONE locally in `v170.17`.

## Goal

Close `F-005` from `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.

## Root problem

The admin action:

```text
POST /admin/users/{tg_id}/wallet/reset
```

cleared only legacy `efhc_core.users.ton_wallet`, while the canonical TonConnect wallet state lives in:

```text
efhc_core.wallet_bindings
```

That meant the operator could see a "wallet reset" action, but an active verified canonical binding could remain usable by wallet-aware services.

## User decision applied

Admin wallet reset means full canonical unbind.

The route must not be legacy-only. It must also deactivate canonical wallet bindings.

## Runtime repair

Changed runtime behavior:

1. `backend/app/services/wallets_service.py`
   - Added `admin_reset_wallet_bindings(db, tg_id=...)`.
   - It deactivates all canonical wallet bindings for the user:

```text
is_active = false
is_primary = false
```

   - It intentionally does not commit; the admin route owns the full transaction boundary.

2. `backend/app/routes/admin_users_routes.py`
   - Keeps legacy cleanup:

```text
users.ton_wallet = NULL
```

   - Calls canonical wallet service:

```text
wallets_service.admin_reset_wallet_bindings(...)
```

   - Writes admin audit log with `wallet_bindings_deactivated=...`.
   - Commits once after legacy cleanup, canonical reset and audit log are all staged.

3. `frontend/src/pages/admin/users.tsx`
   - The reset button no longer depends on legacy `selected.ton_wallet` only.
   - The operator can run reset even when a canonical binding exists but the legacy field is empty.
   - After reset the UI reloads both detail and list.

## Tests / guards

Added active guard file:

```text
tests/architecture/test_admin_wallet_reset_semantic_repair.py
```

Protected invariants:

- `test_admin_wallet_reset_resets_canonical_wallet_bindings`
- `test_admin_wallet_reset_writes_audit_log`
- `test_admin_wallet_reset_requires_admin_guard`
- `test_wallet_reset_reflected_in_profile_wallet_state`
- `test_revoked_wallet_not_used_by_deposit_watcher`
- `test_admin_wallet_reset_service_does_not_commit_inside_helper`
- `test_wallet_bindings_model_remains_canonical`

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_admin_wallet_reset_semantic_repair.py -q
# 7 passed
```

Related linkage/kernel/filename/line72 guard pack passed locally:

```text
python -m pytest   tests/architecture/test_admin_wallet_reset_semantic_repair.py   tests/architecture/test_admin_hub_route_prefix_repair.py   tests/architecture/test_admin_reports_bank_ssot_repair.py   tests/architecture/test_deposit_watcher_wallet_ssot_repair.py   tests/architecture/test_admin_bank_ssot_repair.py   tests/architecture/test_archive_filename_hygiene.py   tests/architecture/test_operator_kernel_routes.py   tests/architecture/test_operator_kernel_config_loading.py -q
# 47 passed
```

Targeted Python compile passed for changed backend route/service files.

## Scope boundaries

No EFHC economy change.
No money-flow change.
No migration change.
No OpenAPI rebuild in this cycle.
No CI/workflow/lock-file change.
No test deletion, archival, skip or xfail.
No direct runtime transfer from Песочница.

Песочница used only as reference/navigation layer.

## Healer / audit tails routed forward

After checking prior audit/HEALER tails, the next bounded cycles are:

```text
1442 — OpenAPI rebuild and strict contract gate
1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards
1444 — Linkage repeat audit + HEALER tail reconciliation
1445 — CI/log proof and residual audit-tail closure if fresh logs are supplied
```

Known tails that must not be hidden:

- `F-006`: OpenAPI incomplete/stale routes.
- `F-007`: UI loading/error/empty-state guard tail.
- `F-008`: frontend API call → backend route guard missing.
- HEALER notes: repeat audit / fresh CI proof remain pending; do not claim release-ready before those gates.

## Remaining blockers

`P0_RELEASE_BLOCKED` remains until `F-006+` are repaired and repeat linkage audit is performed.

Next safe cycle:

```text
1442 — OpenAPI rebuild and strict contract gate
```

---

## Источник: `WORK_CYCLES_1442_OPENAPI_REBUILD_STRICT_CONTRACT_GATE.md`

# Cycle 1442 — OpenAPI rebuild and strict contract gate

Status: DONE locally in `v170.18` with dependency-light static proof.

## Goal

Close the active `F-006` OpenAPI drift finding from:

```text
docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md
```

and seed the contract guard layer for `F-008` without changing EFHC economy or runtime business logic.

## Root problem

The checked-in OpenAPI/route SSOT layer was not a reliable contract gate:

- some route rows were stale or used embedded `/api` prefixes inconsistently;
- hidden compatibility routes could leak into SSOT/OpenAPI;
- visible current routes such as `/tasks/my`, `/tasks/claim`, `/wallets/tonconnect/*`, `/referrals/stats/me`, `/withdraw/list/me`, admin deposit/admin shop routes and other live frontend-call surfaces were not represented consistently;
- generated frontend seam constants and direct `apiRequest(...)` calls were not checked as one contract surface.

## Repair performed

Added dependency-light rebuild tooling:

```text
ops/routes/rebuild_openapi_contract_snapshot.py
```

It parses backend route decorators without importing FastAPI/SQLAlchemy and rebuilds:

```text
docs/SSOT/ssot_pack/SSOT_ROUTES.csv
docs/SSOT/ssot_pack/SSOT_ROUTES_NUMBERED.csv
docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv
backend/openapi/openapi.json
backend/openapi/openapi_manifest.json
reports/generated/openapi_contract_snapshot_v170_18.json
```

The historical command:

```text
ops/openapi/refresh_openapi_from_ssot.py
```

now delegates to the current route-source rebuilder so future operators do not recreate the old stale SSOT-only snapshot.

Added strict dependency-light gate:

```text
ops/routes/check_openapi_strict_contract_gate.py
reports/generated/openapi_strict_contract_gate_v170_18.json
```

The gate checks:

- backend route source → OpenAPI entry;
- OpenAPI → no dead route against the SSOT route surface;
- generated frontend seam constants → OpenAPI;
- direct frontend `apiRequest(...)` calls → backend route;
- direct frontend `apiRequest(...)` calls → OpenAPI;
- admin OpenAPI operations are marked as admin routes;
- monetary routes do not expose `internal_tx`, `efhc_mint_burn` or `efhc_admin.bank_balances`.

## Important boundary

Live FastAPI `app.openapi()` export was attempted through:

```text
ops/routes/export_runtime_openapi.py
```

but the local tool environment lacks runtime dependency `sqlalchemy`.

Therefore this cycle does **not** claim live runtime OpenAPI proof. The checked-in snapshot is rebuilt from backend route source and guarded statically. Live app import proof remains for CI/full environment.

## OpenAPI result

Current checked-in snapshot:

```text
backend/openapi/openapi.json
mode = backend-route-source-derived-snapshot
cycle = 1442
paths = 116
operations = 121
```

Manifest:

```text
backend/openapi/openapi_manifest.json
runtime_live_export = not_claimed_in_this_environment
```

## Guards / tests

Added active guard file:

```text
tests/architecture/test_openapi_rebuild_strict_contract_gate.py
```

Protected invariants:

- `test_openapi_snapshot_was_rebuilt_for_cycle_1442`
- `test_rebuilder_route_count_matches_checked_in_openapi`
- `test_all_backend_routes_have_openapi_entry`
- `test_openapi_has_no_dead_routes`
- `test_all_frontend_api_calls_have_backend_route`
- `test_route_schema_contract_frontend_backend_match`
- `test_admin_routes_are_marked_admin_or_guarded`
- `test_money_routes_do_not_expose_internal_fields`
- `test_openapi_strict_gate_report_is_green`

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_openapi_rebuild_strict_contract_gate.py -q
# 9 passed
```

Related linkage/OpenAPI guard pack passed locally:

```text
python -m pytest \
  tests/architecture/test_openapi_rebuild_strict_contract_gate.py \
  tests/architecture/test_openapi_startup_consistency.py \
  tests/architecture/test_admin_hub_route_prefix_repair.py \
  tests/architecture/test_admin_reports_bank_ssot_repair.py \
  tests/architecture/test_admin_wallet_reset_semantic_repair.py \
  tests/architecture/test_deposit_watcher_wallet_ssot_repair.py \
  tests/architecture/test_admin_bank_ssot_repair.py \
  tests/architecture/test_energy_polish_guard.py -q
# 47 passed
```

## Scope boundaries

No EFHC economy change.
No backend money logic change.
No migration change.
No CI/workflow/lock-file change.
No test deletion, archival, skip or xfail.
No direct runtime transfer from Песочница.

Песочница used only as reference/navigation layer.

## Remaining blockers

`F-006` is repaired locally for the checked-in dependency-light OpenAPI/contract layer, but still requires repeat linkage audit and live/full dependency proof before any release-ready claim.

Remaining next cycle:

```text
1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards
```

Known open tails:

- `F-007`: loading/error/empty state guards for critical UI API calls.
- `F-008`: static frontend API call → backend route guard is seeded here, but full architecture matrix/reporting remains scheduled for cycle 1443.
- Repeat linkage audit and HEALER tail reconciliation remain scheduled for `1444`.

---

## Источник: `WORK_CYCLES_1443_FULL_LINKAGE_ARCHITECTURE_TESTS.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Cycle 1443 — Full linkage architecture tests and UI state guards

## Status

- Archive after cycle: `EFHC_Bot_v170_19_cycle_1443_full_linkage_architecture_tests.zip`.
- Base archive: `EFHC_Bot_v170_18_cycle_1442_openapi_rebuild_strict_contract_gate.zip`.
- Scope: close `F-007` and `F-008` locally by adding full static
  architecture linkage guards and critical frontend state guards.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- Tests removed: no.
- CI/workflows/lock files changed: no.

## What was repaired

Cycle 1443 adds an active guard layer over the full linkage class:

```text
backend route -> OpenAPI -> frontend API call -> frontend surface state
DB/raw SQL table refs -> canonical service boundary -> tests
```

The new scanner is dependency-light and does not import FastAPI runtime.
It is designed for the local archive environment where runtime dependencies
may be unavailable.

## New scanner

```text
ops/linkage/build_full_linkage_report.py
```

The scanner creates:

```text
reports/generated/full_linkage_report_v170_19.json
```

The report confirms locally:

- OpenAPI strict gate status is `ok`;
- frontend API calls have backend route coverage;
- frontend API calls have OpenAPI coverage;
- admin routes are marked/guarded in the checked-in contract;
- repaired legacy money tables are not referenced by backend runtime code;
- direct balance writes outside the canonical service boundary are absent;
- critical API-driven UI surfaces have loading/error/empty state guards.

## New guard

```text
tests/architecture/test_full_linkage_architecture_and_ui_states.py
```

The guard includes:

- `test_full_linkage_report_is_green`;
- `test_all_frontend_api_calls_have_backend_route`;
- `test_route_schema_contract_frontend_backend_match`;
- `test_admin_routes_are_marked_admin_or_guarded`;
- `test_services_do_not_use_legacy_money_table_refs`;
- `test_no_direct_balance_write_outside_canonical_service`;
- `test_user_object_routes_have_ownership_check`;
- `test_critical_frontend_api_calls_have_loading_error_empty_state`.

## User object route boundary

The only non-admin mutable `tg_id` route in the checked-in OpenAPI snapshot is:

```text
POST /sync/user/{tg_id}
```

It is accepted by the guard only because `sync_routes.py` contains the
ownership check:

```text
current_tg_id: int = Depends(get_current_tg_id)
int(tg_id) != int(current_tg_id)
status_code=403
```

This prevents cross-user sync mutation by path `tg_id`.

## Critical UI surfaces covered

The guard covers these API-driven surfaces:

- admin bank;
- admin reports;
- admin deposits;
- admin hub;
- admin users;
- admin shop;
- withdraw;
- tasks;
- referrals;
- exchange.

For each surface the scanner checks static evidence of loading, error and
empty states.

## Validation

Local validation performed:

```text
python -m pytest tests/architecture/test_full_linkage_architecture_and_ui_states.py -q
```

Expected local result:

```text
8 passed
```

Broader local guard pack:

```text
python -m pytest \
  tests/architecture/test_full_linkage_architecture_and_ui_states.py \
  tests/architecture/test_openapi_rebuild_strict_contract_gate.py \
  tests/architecture/test_admin_wallet_reset_semantic_repair.py \
  tests/architecture/test_admin_hub_route_prefix_repair.py \
  tests/architecture/test_admin_reports_bank_ssot_repair.py \
  tests/architecture/test_deposit_watcher_wallet_ssot_repair.py \
  tests/architecture/test_admin_bank_ssot_repair.py \
  tests/architecture/test_archive_filename_hygiene.py \
  tests/architecture/test_operator_kernel_routes.py \
  tests/architecture/test_operator_kernel_config_loading.py -q
```

Expected local result:

```text
63 passed
```

## Remaining tails

Cycle 1443 does not claim release readiness.

Still required:

- cycle 1444 repeat linkage audit and HEALER tail reconciliation;
- cycle 1445 CI/log proof if fresh logs are supplied;
- live FastAPI `app.openapi()` proof in a dependency-complete environment;
- full pytest / frontend build / browser proof only after actual runs.

## Sandbox boundary

Песочница использована только как reference/navigation layer.
Runtime-код не переносился.

---

## Источник: `WORK_CYCLES_1444_LINKAGE_REPEAT_AUDIT_HEALER_TAIL_RECONCILIATION.md`

# Cycle 1444 — Linkage repeat audit + HEALER tail reconciliation

Status: DONE locally in `v170.20`.
Mode: audit/tooling/doc guard cycle. Runtime business logic and EFHC economy were not changed.

## Goal

Re-check the repaired findings from the active migrations/routes/backend-frontend linkage audit and reconcile the remaining HEALER tail before CI/log proof cycles.

## Input HEAD

- `EFHC_Bot_v170_19_cycle_1443_full_linkage_architecture_tests.zip`

## Read / preload

- `KERNEL.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `reports/generated/openapi_strict_contract_gate_v170_18.json`
- `reports/generated/full_linkage_report_v170_19.json`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/cache/file_map.json`

AI Archive Laws lock was checked before editing: SHA-256 and file size match `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`.

## Result

Local repeat audit report:

- `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`
- status: `ok`
- blockers: `[]`

Finding statuses after local repeat audit:

- `F-001`: `REPEAT_AUDIT_PASSED_LOCAL`
- `F-002`: `REPEAT_AUDIT_PASSED_LOCAL`
- `F-003`: `REPEAT_AUDIT_PASSED_LOCAL`
- `F-004`: `REPEAT_AUDIT_PASSED_LOCAL`
- `F-005`: `REPEAT_AUDIT_PASSED_LOCAL`
- `F-006`: `REPEAT_AUDIT_PASSED_LOCAL_STATIC_PENDING_LIVE_FASTAPI_PROOF`
- `F-007`: `REPEAT_AUDIT_PASSED_LOCAL`
- `F-008`: `REPEAT_AUDIT_PASSED_LOCAL`

`F-006` is intentionally not upgraded to full live proof because the local environment still cannot prove live FastAPI `app.openapi()` without installed backend dependencies.

## HEALER tail

During cycle 1444 the HEALER loader tail was found: current `atlas.json` / `casebook.json` contain a schema mix between older compact cards/cases and the strict dataclass loader expected by `ops.healer.loader`.

Repair:

- `ops/healer/loader.py` now keeps the strict dataclass boundary but normalizes older historical cards/cases with safe compatibility defaults.
- `ops/healer/run_once.py` now accepts both `atlas_version`/`casebook_version` and compact `version` keys.
- New repeat audit script validates that the current atlas and casebook load successfully.

This is tooling compatibility repair only. It does not change runtime EFHC logic, wallet logic, admin semantics, economy, migrations, CI/workflows or lock files.

## New / changed files

New:

- `ops/linkage/repeat_linkage_healer_audit.py`
- `tests/architecture/test_linkage_repeat_audit_healer_tail.py`
- `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`
- `docs/cycles/WORK_CYCLES_1444_LINKAGE_REPEAT_AUDIT_HEALER_TAIL_RECONCILIATION.md`
- `reports/change_cycle_2026-06-05_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.md`

Changed:

- `ops/healer/loader.py`
- `ops/healer/run_once.py`
- `KERNEL.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- cycle/docs/report/test manifests / HEALER indexes / Kernel cache

## Validation

Local validation performed:

```text
python -m pytest tests/architecture/test_linkage_repeat_audit_healer_tail.py -q
# 4 passed
```

```text
python -m pytest tests/architecture/test_admin_bank_ssot_repair.py tests/architecture/test_deposit_watcher_wallet_ssot_repair.py tests/architecture/test_admin_reports_bank_ssot_repair.py tests/architecture/test_admin_hub_route_prefix_repair.py tests/architecture/test_admin_wallet_reset_semantic_repair.py tests/architecture/test_openapi_rebuild_strict_contract_gate.py tests/architecture/test_full_linkage_architecture_and_ui_states.py tests/architecture/test_linkage_repeat_audit_healer_tail.py -q
# 54 passed
```

```text
python -m py_compile ops/linkage/repeat_linkage_healer_audit.py ops/healer/loader.py ops/healer/run_once.py
# passed
```

## Not claimed

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- Live FastAPI `app.openapi()` proof.
- Browser screenshots.
- Live Telegram client proof.
- Real TonConnect / wallet proof.
- Release-ready status.

## Next safe step

`1445 — CI/log proof and residual audit-tail closure`, if fresh logs are supplied or a local CI/log proof pack is requested.

Песочница использована только как reference/navigation layer. Runtime-код не переносился.

---

## Источник: `WORK_CYCLES_1445_CI_LOG_REPAIR_BNB_SKIN_CLEANUP.md`

# Cycle 1445 — CI/log proof and residual audit-tail closure

Status: DONE locally

HEAD input: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`

Input logs: `logs_72623328892.zip`

Output archive: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`

## Цель

Разобрать fresh CI logs, исправить фактические ошибки, удалить старый BNB/source skin and update docs/guards.

## Root cause from logs

CI failed on ruff, mypy and pytest. Main causes:

- import-order/E402 drift after previous route/OpenAPI tooling work;
- type drift in bank balance helper and bank transfer log mapping;
- legacy admin bank road guard still expected old mint/burn marker;
- admin route module guard did not include `admin_hub_routes.py`;
- Kernel lacked exact fallback refresh command marker;
- line72 violations existed in new ops tooling scripts;
- banned legacy substring was triggered by English `startup pointer` predecessor wording;
- route freeze markdown count was stale;
- Healer atlas cards had compact schema tails;
- wallet hardening test reused shared Postgres wallet tables;
- old PNG BNB/source skin still existed after WebP first-paint migration.

## Runtime / code changes

- `transactions_service.get_bank_main_balance()` renamed to `get_bank_balance()` to avoid degraded `_main_` token shape.
- `get_bank_balance()` now returns `cast(Decimal, d8(...))` for mypy.
- Admin bank transfer log IDs now use explicit `int | None` typing.
- Import ordering fixed in touched Python modules.
- `ops/openapi/refresh_openapi_from_ssot.py` now uses lazy import inside `main()` to avoid E402.
- Wallet test helper now truncates wallet hardening tables for Postgres test isolation.
- Skin catalog and frontend skin URL now use `.webp`; old `frontend/public/skins/1.png` was removed.

## Guard / docs changes

- Admin bank road guard now protects the new canonical rule: no runtime dependency on `efhc_mint_burn`; mint/burn must go through canonical transaction service.
- Admin route module guard includes `admin_hub_routes.py` with `/admin/hub` and `admin:hub`.
- Kernel docs include exact fallback command: `python ops/operator_kernel/file_map.py --refresh`.
- Route inventory markdown regenerated from current freeze CSV.
- Healer atlas compact tails normalized.
- Cold-start skin guard now requires WebP and absence of old PNG source skin.

## Local validation

See `reports/generated/ci_log_repair_v170_21.json`.

## Not claimed

No GitHub CI green, full pytest green, frontend build green, release-ready, browser screenshots, live Telegram proof or real TonConnect proof is claimed.

## Next safe step

`1446 — CI rerun log reconciliation or next fresh log repair` if new CI logs are supplied.

---

## Источник: `WORK_CYCLES_1446_CI_RERUN_LOG_REPAIR.md`

# Cycle 1446 — CI rerun log repair

Status: DONE locally

HEAD input: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`

Input logs: `logs_72627437860.zip`

Output archive: `EFHC_Bot_v170_22_cycle_1446_ci_rerun_log_repair.zip`

## Цель

Прочитать fresh CI rerun logs, исправить фактические root causes,
обновить Kernel/map/docs/reports и не менять runtime-экономику EFHC.

## Root cause from logs

CI gate summary showed two failing gates:

1. `ruff` failed with `I001` import-order drift in:
   - `backend/app/services/admin/admin_bank_service.py`;
   - `backend/app/services/transactions_service.py`.
2. `pytest` failed in
   `tests/architecture/test_audit_of_audits_status_notes.py`
   because `docs/audits/ROUTE_INVENTORY_FREEZE.md` had no explicit
   `Status note` or `Historical snapshot` marker.

Other logged gates were green in the supplied logs:

- flake8 critical/full;
- mypy;
- bandit;
- compileall backend;
- Alembic upgrade head;
- npm ci;
- frontend `next build`.

These are facts from the supplied logs only. They are not a green claim for
this new archive until CI is rerun on the new ZIP.

## Repair

- Sorted the admin RBAC import in `AdminBankService` according to ruff.
- Moved the idempotency marker comment in `transactions_service.py` out of
  the import block so the import block remains ruff-sortable.
- Added an explicit status note to
  `docs/audits/ROUTE_INVENTORY_FREEZE.md`, marking it as a historical
  route inventory snapshot and pointing to active route/OpenAPI/linkage
  SSOT files.
- Added `tests/architecture/test_ci_log_repair_guards.py` to freeze the
  exact regression repairs from this log cycle.

## Runtime and economics impact

- EFHC economy changed: no.
- Runtime business logic changed: no.
- DB migrations changed: no.
- CI/workflows changed: no.
- Lock files changed: no.
- Tests deleted/disabled/archived/skipped/xfail: no.

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_ci_log_repair_guards.py \
  tests/architecture/test_audit_of_audits_status_notes.py -q
# 5 passed
```

```text
python -m pytest tests/architecture/test_archive_filename_hygiene.py \
  tests/architecture/test_operator_kernel_routes.py \
  tests/architecture/test_operator_kernel_config_loading.py -q
# 13 passed
```

```text
python -m py_compile \
  backend/app/services/admin/admin_bank_service.py \
  backend/app/services/transactions_service.py
# passed
```

Full local pytest was attempted but not counted as green in this sandbox,
because the local environment lacks `sqlalchemy`. The supplied CI logs did
have dependencies installed and showed one pytest failure only; that exact
failure is repaired and guarded here.

## Not claimed

- GitHub CI green for the new archive;
- full pytest green for the new archive;
- frontend build green for the new archive;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next step

Next safe step: `1447 — fresh CI rerun proof / release-gate preparation`,
or another log-repair cycle if new logs show failures.

---

## Источник: `WORK_CYCLES_1447_CHAT_DOCS_INTAKE.md`

# Cycle 1447 — chat docs intake / v170.23

Статус: DONE locally.
Дата: 2026-06-06.

## Цель

Загрузить пользовательские экспорты чатов в официальный раздел
документов чатов EFHC Bot без изменения runtime-кода.

## HEAD input

`EFHC_Bot_v170_22_cycle_1446_ci_rerun_log_repair.zip`

## Добавлено

- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/26.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/27.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/28.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/30.md`

Исходные загруженные файлы:

- `26.md`
- `27.md`
- `28(1).md` → canonical `28.md`
- `30(1).md` → canonical `30.md`

## Обновлено

- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/CHATS_INDEX.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/README.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `reports/REPORTS_INDEX.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`

## Guard

Добавлен активный guard:

- `tests/architecture/test_chat_docs_intake.py`

Он защищает:

- наличие canonical copies `26.md`, `27.md`, `28.md`, `30.md`;
- наличие ссылок на них в `CHATS_INDEX.md`;
- отсутствие дубликатов в `docs/NORM/CHAT_BRANCHES/`.

## Проверки

Локально выполнено:

- ZIP input `testzip=None`;
- `python3 scripts/ci/check_ai_archive_laws_integrity.py`;
- `python3 -m pytest -q tests/architecture/test_chat_docs_intake.py`;
- `python3 -m pytest -q tests/architecture/test_chat_docs_intake.py`
  together with selected kernel/filename guards;
- `python3 -m compileall -q tests/architecture`;
- ZIP output `testzip=None`.

## Не проверено

Не заявляется:

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect/wallet proof.

## Статус диапазона

- Было: `46 / 100`.
- Стало: `47 / 100`.
- Осталось: `53 / 100`.
- Следующий безопасный шаг: fresh CI rerun proof / release-gate
  preparation или следующий log repair при новых `logs_*.zip`.

---

## Источник: `WORK_CYCLES_1448_LINKAGE_MINOR_FINDINGS_REPAIR.md`

# WORK CYCLE 1448 — Linkage minor findings repair

Status: DONE locally  
Archive: `EFHC_Bot_v170_24_cycle_1448_linkage_minor_findings_repair.zip`  
Base HEAD: `EFHC_Bot_v170_23_cycle_1447_chat_docs_intake.zip`

## Input audit

Verdict: `LINKAGE_SAFE_WITH_MINOR_FINDINGS`.

Release was not blocked by the audit:

- `P0: 0`
- `P1: 0`
- `P2: 2`
- `P3: 0`

Findings repaired in this cycle:

- `LNK-01`: full linkage test/report still hardcoded
  `cycle=1443 / v170.19`.
- `LNK-02`: `AdminHubPage.tsx` called `/admin/hub/*` through raw
  `apiRequest` literals instead of the generated admin seam contract.

## Repair scope

This cycle is housekeeping/linkage-only.

Changed:

- generated admin seam source and output for Admin Hub paths/types;
- Admin Hub frontend page path usage;
- strict OpenAPI seam expectation list;
- full linkage report script and guard test;
- cycle, report, test-manifest, Kernel and map documents.

Not changed:

- EFHC economy;
- DB migrations;
- backend business logic;
- CI/workflows;
- lock files;
- wallet/payment semantics.

## LNK-01 repair

`ops/linkage/build_full_linkage_report.py` now produces:

- `cycle = 1448`
- `version = v170.24`
- `reports/generated/full_linkage_report_v170_24.json`

`tests/architecture/test_full_linkage_architecture_and_ui_states.py`
was updated to assert the new cycle/version and the Admin Hub seam
contract status.

Historical report `reports/generated/full_linkage_report_v170_19.json`
remains as the cycle 1443 evidence file.

## LNK-02 repair

Added generated Admin Hub seam constants:

- `ADMIN_HUB_LINKS_PATH`
- `ADMIN_HUB_LINK_CREATE_PATH`
- `ADMIN_HUB_LINK_UPDATE_PATH`
- `ADMIN_HUB_LINK_TOGGLE_PATH`
- `ADMIN_HUB_LINK_REORDER_PATH`

Added generated Admin Hub seam types:

- `AdminHubLink`
- `AdminHubLinkCreateRequest`
- `AdminHubLinkUpdateRequest`
- `AdminHubLinkToggleRequest`
- `AdminHubLinkReorderItem`
- `AdminHubLinkReorderRequest`

`AdminHubPage.tsx` now imports and uses the generated seam constants/types.
Raw `/admin/hub/*` path literals are no longer used as `apiRequest` route
identity.

## Validation

Local targeted validation:

- `python3 ops/linkage/build_full_linkage_report.py` → `status=ok`;
- `tests/architecture/test_full_linkage_architecture_and_ui_states.py` →
  `9 passed`;
- `tests/architecture/test_openapi_rebuild_strict_contract_gate.py` →
  `9 passed`;
- `tests/architecture/test_max_line_length_72.py` → `1 passed`.

Not claimed:

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect/wallet proof.

## Range status

Before cycle: `47 / 100` done.  
After cycle: `48 / 100` done.  
Remaining: `52 / 100`.

Next safe step: fresh CI rerun proof / release-gate preparation, or log
repair if the user provides new `logs_*.zip`.

---

## Источник: `WORK_CYCLES_1449_FRONTEND_VISUAL_I18N_UX_REPAIR.md`

# Cycle 1449 — frontend visual / i18n / buttons / UX repair

Status: DONE locally.
Archive output: `EFHC_Bot_v170_25_cycle_1449_frontend_visual_i18n_ux_repair.zip`.
Input HEAD: `EFHC_Bot_v170_24_cycle_1448_linkage_minor_findings_repair.zip`.

## Inputs

- `docs/audits/P0_FRONTEND_VISUAL_I18N_BUTTONS_UX_AUDIT_V170_24.md`
- `docs/audits/TZ_FRONTEND_VISUAL_I18N_BUTTONS_UX_REPAIR_V170_24.md`

Audit verdict accepted as source for this cycle:
`VISUAL_SAFE_NO_P0_FOUND`, with `8` P1 findings and `2` P2
findings.

## Closed locally

- F-01: Panels countdown now uses real seconds math:
  `86400`, `3600`, `60`.
- F-02: Tasks no longer returns raw public task status values.
- F-03: Ranks no longer uses `browser-player` as runtime fallback.
- F-04: Web Profile balance history uses a shared reason normalizer.
- F-05: Withdraw history/outcome labels use human labels instead of
  raw `reason`, `balance_type` and `outcome_kind`.
- F-06: Withdraw Money-Center return now goes to
  `/web-profile?section=history`.
- F-07: Admin Shop operator labels were Russian-first normalized.
- F-08: Admin Withdrawals and its mobile decision panel use
  Russian operator labels for statuses/outcomes.
- F-09: active Energy route docs now keep `/` as the only active route.

## Deferred

- F-10 screenshot proof is not claimed in this cycle. The archive still
  needs real browser/screenshot runtime capture in a later cycle because
  this local environment did not provide a running browser/TMA proof.

## Safety

- Runtime economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Tests deleted/archived/skipped/xfail: no.
- Песочница used only as reference/navigation layer.

---

## Источник: `WORK_CYCLES_1450_VISUAL_P0_COUNTDOWN_FOLLOWUP_REPAIR.md`

# Cycle 1450 — visual P0 countdown follow-up repair

Status: DONE locally.
Archive output: `EFHC_Bot_v170_26_cycle_1450_visual_p0_countdown_followup_repair.zip`.
Input HEAD: `EFHC_Bot_v170_25_cycle_1449_frontend_visual_i18n_ux_repair.zip`.

## Inputs

- `docs/audits/P0_FRONTEND_VISUAL_I18N_BUTTONS_UX_AUDIT_V170_23.md`
- `reports/generated/frontend_visual_i18n_buttons_ux_audit_v170_23.json`

Input verdict accepted for this follow-up cycle:
`P0_VISUAL_OR_BUTTON_RISK_FOUND`.

## Findings handled

- VIS-01 / P0: Panels countdown guarded with explicit second constants
  and arithmetic assertions. Actual code already used correct math after
  v170.25; cycle 1450 made the proof stronger and prevented `/86` relapse.
- VIS-02 / P1: Admin Withdrawals mobile filter/KPI labels are Russian
  operator labels.
- VIS-03 / P1: Withdraw history uses `balanceTypeLabel(...)` instead of
  raw `main` / `bonus` rendering.
- VIS-04 / P1: Admin Tasks no longer renders `helper`,
  `moderation surface`, `active` or `inactive` as operator badge labels.
- VIS-05 / P2: Nested ghost locale objects `admin` and `common` removed
  from locale JSON files. Flat key parity remains equal across all locales.
- VIS-06 / P2: Countdown tests now include arithmetic assertions for
  `180 * 86400`, day/hour/minute divisors and anti-`/86` relapse.
- VIS-07 / P3: HUB trust-rail now renders only the two canonical spans.

## Safety

- Runtime economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Tests deleted/archived/skipped/xfail: no.
- Песочница used only as reference/navigation layer.
- Browser screenshot proof is not claimed in this local cycle.

---

## Источник: `WORK_CYCLES_1451_CI_LOG_REPAIR.md`

# Cycle 1451 — CI log repair / v170.27

Status: DONE locally.
Date: 2026-06-06.

## Input

- HEAD input:
  `EFHC_Bot_v170_26_cycle_1450_visual_p0_countdown_followup_repair.zip`.
- Logs input: `logs_72682359351.zip`.

## Root causes from logs

1. `ruff I001` import-order drift:
   - `backend/app/services/admin/admin_bank_service.py`;
   - `backend/app/services/transactions_service.py`;
   - `tests/architecture/test_chat_docs_intake.py`.
2. Pytest stale guards:
   - old chat index anchor strings for branches 24 and 25;
   - old Kernel marker `# Operator Kernel` missing;
   - profile history i18n anchor moved behind shared normalizer;
   - canon guard found prohibited terms inside imported chat export `26.md`.
3. Frontend build TypeScript failure:
   - generated `adminSeams.ts` had no exported
     `AdminWithdrawOutcomePreviewResponse` type.

## Repaired

- Restored ruff import ordering.
- Added compatibility chat index anchors without creating branch
  duplicates.
- Restored exact Kernel compatibility marker.
- Added profile history i18n anchors while keeping shared normalizer.
- Reworded imported chat export terms that violated canon guard.
- Added generated admin withdraw preview response types to
  `adminSeams.ts` and its generator.
- Added active regression guard:
  `tests/architecture/test_ci_log_repair_v170_27_guards.py`.

## Safety

- Runtime economy changed: no.
- Backend monetary logic changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- No test was deleted, archived, skipped, xfailed or hidden.

## Local validation

- `ruff check backend api ops tests`: passed.
- `ops/canon_guard.py`: passed.
- `scripts/ci/check_ai_archive_laws_integrity.py`: passed.
- Log failure targeted pytest set: passed.
- Added v170.27 CI log repair guard: passed.
- Wider targeted guard pack: 60 passed.
- `compileall` for `ops`, `scripts`, `tests/architecture`: passed.
- Frontend build retry passed TypeScript and production compilation
  phases, but full build green is not claimed because sandbox page-data
  worker ended with `EPIPE`.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Full frontend build green.
- Release-ready.
- Browser screenshots.
- Live Telegram proof.
- Real TonConnect / wallet proof.

## Next safe step

Fresh CI rerun proof or factual log repair if new `logs_*.zip` exists.

---

## Источник: `WORK_CYCLES_1452_DASHBOARD_VISUAL_DIRECTION_PLAN.md`

# Cycle 1452 — Dashboard Visual Direction Plan / v170.28

## Цель

Зафиксировать активное направление работ для dashboard-визуализации
EFHC Bot и план циклов `1455–1495`.

## Входные файлы

- HEAD: `EFHC_Bot_v170_27_cycle_1451_ci_log_repair.zip`.
- План: `DASHBOARD_VISUAL_PLAN.md`.
- Reference: `grafana-main.zip`.

## Что сделано

- Добавлен активный документ:
  `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Диапазон направления зафиксирован как `1455–1495`, 41 цикл.
- Добавлен завершающий цикл `1495` для handoff/backlog freeze.
- `grafana-main.zip` проверен только как reference archive.
- Прямой перенос Grafana runtime, lock files, CI, зависимостей и
  кода в EFHC Bot не выполнялся.
- Обновлены Kernel, map_element, reports index, testing manifest и
  machine report.

## Граница Grafana

Берём только visual discipline: panel chrome, dashboard shell, toolbar,
time range, refresh, variables, inspector, grid, status cards, mini
charts, empty/error/loading states.

Не берём root runtime Grafana, чужие зависимости, AGPL/root code, lock
files, CI workflows, backend logic или charts как готовый продуктовый
runtime.

## Статус циклов

- До цикла 1452: `51 / 100` сделано, `49 / 100` осталось.
- После цикла 1452: `52 / 100` сделано, `48 / 100` осталось.
- План dashboard-направления: `1455–1495`, 41 цикл.

## Что не менялось

- Экономика EFHC.
- Backend contracts.
- DB migrations.
- CI/workflows/lock files.
- Runtime dashboard implementation.

## Проверки

- ZIP integrity исходного HEAD.
- `grafana-main.zip` testzip.
- AI Archive Laws lock.
- New dashboard direction guard.
- Filename hygiene / line72 selected guards.

## Не заявляется

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- Release-ready.
- Browser screenshots.
- Live Telegram proof.
- Real TonConnect/wallet proof.

---

## Источник: `WORK_CYCLES_1453_CI_LOG_REPAIR_DASHBOARD_PREP.md`

# WORK_CYCLES_1453_CI_LOG_REPAIR_DASHBOARD_PREP

## Cycle

`1453 — CI log repair + Dashboard Visual Direction preparation`

## Input

- HEAD input:
  `EFHC_Bot_v170_28_cycle_1452_dashboard_visual_direction_plan.zip`.
- Logs input: `logs_72685602190.zip`.
- Reference archives: Песочница and `grafana-main.zip`.

## Log root cause

The supplied CI log had one failed gate:

- `pytest` failed with 2 stale guard assertions.

The same log showed these gates passing:

- ruff;
- mypy;
- bandit;
- compileall backend;
- Alembic upgrade;
- npm ci;
- frontend build.

## Repaired failures

1. `tests/architecture/test_ci_log_repair_guards.py` expected the
   admin RBAC import anchor in `admin_bank_service.py`.
   The source import block was restored to the guarded order.
2. `tests/architecture/test_ci_log_repair_v170_27_guards.py` expected
   the legacy Kernel marker `v170.27 / CI log repair`.
   The marker was restored as a compatibility anchor while the active
   HEAD moved to v170.29.

## Dashboard preparation

- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` now contains explicit Grafana reference anchors.
- Grafana remains reference only.
- No Grafana runtime code, dependency, lock file, CI file or backend
  logic was copied.
- Dashboard Visual Direction Plan remains active for `1455–1495`.

## Safety

- Economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Tests deleted/hidden/skipped/xfail: no.

## Local validation

- Targeted CI log guard set: passed locally.
- AI Archive Laws integrity: passed locally.
- Ruff targeted check: passed locally.
- Output ZIP `testzip`: passed locally.

## Not claimed

- GitHub CI green for the new archive.
- Full pytest green for the new archive.
- Release-ready.
- Browser screenshots.
- Live Telegram or real TonConnect proof.

## Next safe step

- `1454 — screenshot proof preparation`, or factual log repair if a
  new `logs_*.zip` is supplied.

---

## Источник: `WORK_CYCLES_1454_SCREENSHOT_PROOF_PREPARATION.md`

# Cycle 1454 — screenshot proof preparation / v170.30

Status: DONE locally.

## Scope

Cycle 1454 reads fresh logs first, records the supplied green CI proof,
and prepares screenshot proof for the Dashboard Visual Direction Plan.

Input HEAD:

`EFHC_Bot_v170_29_cycle_1453_ci_log_repair_dashboard_prep.zip`

Input logs:

`logs_72687610241.zip`

## Green log evidence

The supplied CI logs show all gate steps passed for the input archive.

Confirmed green gates:

- flake8 critical: passed;
- flake8 full report: passed;
- ruff full report: passed;
- mypy full report: passed;
- bandit full report: passed;
- backend compileall: passed;
- Alembic upgrade head: passed;
- pytest: `1306 passed, 8 skipped, 1 warning`;
- npm ci: passed;
- frontend build: passed;
- gate summary: `OK: all gate steps passed.`

This is green proof for the supplied CI log run. It is not a GitHub CI
claim for the newly created `v170.30` archive, because `v170.30` is a
new local archive after docs/test/report updates.

## Screenshot proof preparation

Added the active preparation document:

`docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`

Added machine manifest:

`reports/generated/dashboard_screenshot_proof_manifest_v170_30.json`

The manifest covers:

- 14 public routes;
- 17 admin routes;
- 10 viewport profiles;
- 13 active locales;
- Dashboard Visual Direction Plan cycles `1455-1495`.

## Screenshot status

Current status:

`SCREENSHOT_PREPARATION_READY_NO_CAPTURE`

No browser screenshots are claimed in this cycle. The cycle prepares the
capture matrix, target routes, evidence directories and guardrails only.

## Grafana and Sandbox boundaries

Grafana is used only as a visual-pattern reference.
Песочница is used only as reference/navigation/prototype layer.
No Grafana or sandbox runtime code, dependencies, lock files, CI files,
wallet logic, backend logic or economics were copied.

## Files changed

- `KERNEL.md`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`;
- `docs/NORM/DASHBOARD_VISUAL_PLAN.md`;
- `docs/cycles/WORK_CYCLES.md`;
- `docs/cycles/WORK_CYCLES_1454_SCREENSHOT_PROOF_PREPARATION.md`;
- `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `reports/REPORTS_INDEX.md`;
- `reports/generated/dashboard_screenshot_proof_manifest_v170_30.json`;
- `reports/generated/green_ci_log_proof_v170_30.json`;
- `reports/change_cycle_2026-06-06_v170_30_cycle_1454_screenshot_proof_preparation.md`;
- `tests/architecture/test_dashboard_screenshot_proof_preparation.py`;
- `ops/operator_kernel/cache/file_map.json`.

## Validation

Local validation is targeted because this cycle changes docs, reports and
architecture guards only.

Required local checks:

- AI Archive Laws integrity;
- screenshot preparation guard;
- dashboard direction guard;
- filename hygiene guard;
- line72 guard;
- compileall for architecture tooling;
- ZIP integrity.

## Non-claims

- no release-ready claim;
- no browser screenshot proof claim;
- no live Telegram proof;
- no real TonConnect or wallet proof;
- no claim that the newly created v170.30 archive already has external
  GitHub CI proof.

## Range status

Before cycle 1454: `53 / 100` done.

After cycle 1454: `54 / 100` done.

Remaining in `1401-1500`: `46 / 100`.

Next planned step: `1455 — Dashboard Visual Kernel / направление работ`.

---

## Источник: `WORK_CYCLES_1455_DASHBOARD_VISUAL_KERNEL.md`

# Cycle 1455 — Dashboard Visual Kernel / v170.31

Status: DONE locally.

## Scope

Cycle 1455 starts the Dashboard Visual Direction Plan. It does not
implement dashboard runtime UI. It creates the operational kernel and
navigation layer that the next dashboard cycles must follow.

Input HEAD:

`EFHC_Bot_v170_30_cycle_1454_screenshot_proof_preparation.zip`

## What was read

- `KERNEL.md`;
- `ops/operator_kernel/config/routes.yaml`;
- `ops/operator_kernel/cache/file_map.json`;
- `docs/NORM/DASHBOARD_VISUAL_PLAN.md`;
- `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`;
- Grafana archive reference map;
- Песочница reference archives.

## What was added

- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`;
- `reports/generated/dashboard_visual_kernel_v170_31.json`;
- `reports/change_cycle_2026-06-06_v170_31_cycle_1455_dashboard_visual_kernel.md`;
- `tests/architecture/test_dashboard_visual_kernel.py`.

## What was updated

- `KERNEL.md`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`;
- `docs/NORM/DASHBOARD_VISUAL_PLAN.md`;
- `docs/cycles/WORK_CYCLES.md`;
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `reports/REPORTS_INDEX.md`;
- `ops/operator_kernel/config/routes.yaml`;
- `ops/operator_kernel/cache/file_map.json`.

## Dashboard kernel decisions

- Dashboard Visual Direction Plan is active from cycle `1455`.
- Two layers are canonical: Admin Dashboard Layer and Simulation
  Dashboard Layer.
- Grafana is visual-pattern reference only.
- Песочница is reference/navigation/prototype layer only.
- No runtime code, dependencies, lock files, CI files, backend logic,
  wallet/payment logic or economics were copied from references.
- Next cycle is `1456 — Sandbox Dashboard Inventory`.

## Validation

Local targeted validation:

- ZIP integrity;
- AI Archive Laws integrity;
- dashboard visual kernel guard;
- dashboard direction guard;
- screenshot preparation guard;
- filename hygiene guard;
- line72 guard;
- `ops/canon_guard.py`;
- `compileall` for `ops`, `scripts` and `tests/architecture`.

## Non-claims

- no GitHub CI green claim for `v170.31`;
- no full pytest green claim;
- no frontend build green claim;
- no release-ready claim;
- no browser screenshot proof;
- no live Telegram proof;
- no real TonConnect or wallet proof.

## Range status

Before cycle 1455: `54 / 100` done.

After cycle 1455: `55 / 100` done.

Remaining in `1401-1500`: `45 / 100`.

Next planned step: `1456 — Sandbox Dashboard Inventory`.

---

## Источник: `WORK_CYCLES_1456_SANDBOX_DASHBOARD_INVENTORY.md`

# Cycle 1456 — Sandbox Dashboard Inventory

Status: `DONE_LOCAL`

Archive target: `v170.32`

## Goal

Build the inventory for Dashboard Visual Direction Plan before any
runtime dashboard port.

## Read / checked

- `KERNEL.md`.
- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
- `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`.
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
- `Песочница(1).xz`.
- `grafana-main.zip`.
- Template ZIP archives.

## Done

- Added `docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md`.
- Added machine report
  `reports/generated/sandbox_dashboard_inventory_v170_32.json`.
- Added guard
  `tests/architecture/test_sandbox_dashboard_inventory.py`.
- Updated Kernel, routes, map, work cycles, test manifest and reports
  index.

## Safety

- Runtime code copied from Песочница: no.
- Runtime code copied from Grafana: no.
- Economy changed: no.
- Backend contracts changed: no.
- CI/workflows/lock files changed: no.
- Tests deleted/disabled: no.

## Next

`1457 — Grafana Visual Pattern Map`.

---

## Источник: `WORK_CYCLES_1457_GRAFANA_VISUAL_PATTERN_MAP.md`

# Cycle 1457 — Grafana Visual Pattern Map

Status: `DONE_LOCAL`

Archive target: `EFHC_Bot_v170_33_cycle_1457_grafana_visual_pattern_map.zip`

## Goal

Create a safe Grafana-like visual pattern map for EFHC Bot dashboard
work. This cycle is documentation, mapping and guard work only.

## Inputs read

- `KERNEL.md`.
- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
- `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- `docs/NORM/SANDBOX_DASHBOARD_INVENTORY.md`.
- `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`.
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`.
- `grafana-main.zip` as reference archive.
- `Песочница(1).xz` as reference archive.

## Added

- `docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md`.
- `reports/generated/grafana_visual_pattern_map_v170_33.json`.
- `tests/architecture/test_grafana_visual_pattern_map.py`.

## Main result

Mapped Grafana-like patterns to own EFHC implementation targets:

- PanelChrome → AdminPanelChrome / SimPanelChrome.
- PanelHeader/menu → AdminPanelHeader / AdminPanelActions.
- DashboardGrid → AdminDashboardGrid / SimDashboardGrid.
- DashboardPageProxy → AdminDashboardPage / SimDashboardShell.
- DateTimePickers → AdminTimeRangePicker / SimPeriodSwitch.
- RefreshPicker → AdminRefreshPicker / DashboardFreshnessBadge.
- Variables → AdminVariableBar / DashboardFilterBar.
- Inspector → AdminPanelInspectorDrawer.
- BigValue → AdminStatCard / SimStatCard.
- Sparkline → AdminSparkline / SimMiniSparkline.
- Table → AdminDataTable / AdminCompactTable.
- Legend/status → AdminStatusTimeline / DashboardLegend.

## Safety

Grafana and Песочница remain reference-only layers. Runtime code,
dependencies, lock files, CI files, backend logic, wallet/payment logic
and economics were not copied.

## Validation

Local targeted guards pass for the pattern map, dashboard kernel,
sandbox inventory and screenshot preparation. Full external CI green is
not claimed for the new archive.

## Next step

`1458 — Dashboard Design Tokens Foundation`.

---

## Источник: `WORK_CYCLES_1458_DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`

# Cycle 1458 — Dashboard Design Tokens Foundation

Status: `DONE_LOCAL`

Archive target: `v170.34`

## Goal

Create the EFHC-owned dashboard design token foundation before any
large dashboard runtime port.

## Done

- Added active token document:
  `docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`.
- Added dashboard CSS variables to `frontend/src/styles/globals.css`.
- Added dark-mode and light-mode token values.
- Added primitive dashboard utility classes.
- Updated dashboard navigation docs and Kernel pointers.
- Added machine report and architecture guard.

## Token groups

- Surface tokens.
- Border tokens.
- Text tokens.
- Accent and semantic tokens.
- Radius tokens.
- Spacing tokens.
- Shadow tokens.
- Typography tokens.

## Boundaries

- Grafana was used only as visual-pattern reference.
- Песочница was used only as reference/prototype/navigation layer.
- No runtime code was copied from Grafana or Песочница.
- No backend contract was changed.
- No database migration was changed.
- No economy or money flow was changed.
- No CI, workflow or lock file was changed.

## Checks

Local targeted checks were run for dashboard token guards, dashboard
kernel guards, Grafana pattern guards, filename hygiene, line72,
canon guard, test-suite integrity without collection, ruff and
compileall.

## Not claimed

- GitHub CI green for this archive.
- Full pytest green.
- Frontend build green.
- Release-ready.
- Browser screenshot proof.
- Live Telegram proof.
- Real TonConnect/wallet proof.

## Next step

`1459 — Dashboard Component Contract`.

---

## Источник: `WORK_CYCLES_1459_DASHBOARD_COMPONENT_CONTRACT.md`

# WORK CYCLE 1459 — Dashboard Component Contract

Status: `DONE_LOCAL`

Archive: `EFHC_Bot_v170_35_cycle_1459_dashboard_component_contract.zip`

## Goal

Fix the shared component contract for future dashboard panels before
Simulation and Admin UI kit foundations are expanded.

## What changed

Added active contract document:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Added runtime type contract:

`frontend/src/lib/dashboard/componentContract.ts`

Added machine report:

`reports/generated/dashboard_component_contract_v170_35.json`

Added active guard:

`tests/architecture/test_dashboard_component_contract.py`

## Protected invariants

- Every future dashboard panel must have title, source and state.
- Required states are loading, empty, error, stale and success.
- Data kinds distinguish raw, derived, synthetic preview and real
  time-series data.
- Synthetic preview data must be clearly marked.
- Actions cannot bypass existing money-flow guards.
- Grafana and Песочница remain reference-only sources.

## Boundaries

Runtime economy changed: no.

Backend contracts changed: no.

DB migrations changed: no.

CI/workflows/lock files changed: no.

Grafana runtime copied: no.

Песочница runtime copied: no.

## Local validation

- ZIP integrity and `testzip` for input and output archives.
- AI Archive Laws integrity.
- Dashboard component contract guard.
- Dashboard design tokens and direction guard subset.
- Operator Kernel file map refresh.
- Python compileall for tooling and architecture tests.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- Release-ready.
- Browser screenshot proof.
- Live Telegram proof.
- Real TonConnect/wallet proof.

## Next safe step

`1460 — Simulation Dashboard UI Kit Foundation`.

---

## Источник: `WORK_CYCLES_1460_SIMULATION_DASHBOARD_UI_KIT_FOUNDATION.md`

# Cycle 1460 — Simulation Dashboard UI Kit Foundation

Status: `DONE_LOCALLY`

Archive target: `v170.36`

## Goal

Create the first EFHC-owned Simulation Dashboard UI Kit foundation for
future user-facing Energy, Panels, Ranks, Tasks, Referrals, Exchange and
Web Profile dashboard cycles.

## User questions answered

The user asked whether old dashboards were removed.

Answer: no old dashboard source files were removed. The previous diff
showed ZIP directory entries disappearing, not actual files.

Confirmed preserved files:

- `frontend/src/components/admin/AdminDashboardUiKit.tsx`
- `frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`
- `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`
- `ops/monitoring/grafana/dashboards/backend.json`
- `ops/monitoring/grafana/dashboards/scheduler.json`
- `ops/monitoring/grafana/dashboards/ton_watcher.json`

## Added

- `docs/NORM/SIMULATION_DASHBOARD_UI_KIT_FOUNDATION.md`
- `docs/audits/DASHBOARD_DELETION_CHECK_V170_36.md`
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`
- `reports/generated/simulation_dashboard_ui_kit_foundation_v170_36.json`
- `reports/change_cycle_2026-06-06_v170_36_cycle_1460_simulation_dashboard_ui_kit_foundation.md`
- `tests/architecture/test_simulation_dashboard_ui_kit_foundation.py`

## Updated

- `frontend/src/styles/globals.css`
- `KERNEL.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `docs/NORM/DASHBOARD_VISUAL_PLAN.md`
- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`
- `docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`
- `docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `reports/REPORTS_INDEX.md`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/cache/file_map.json`

## Boundaries

- Economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Grafana runtime code copied: no.
- Sandbox runtime code copied: no.
- Old dashboards deleted: no.

## Verification

Local targeted guards were run. Full GitHub CI green and frontend build
green are not claimed for this archive.

## Next safe step

`1461 — Admin Dashboard UI Kit Foundation`.

---

## Источник: `WORK_CYCLES_1461_ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`

# 1461 — Admin Dashboard UI Kit Foundation / v170.37

Status: `DONE_LOCALLY`

## Goal

Create the first EFHC-owned Admin Dashboard UI Kit foundation and add
an extra Grafana element usage map for future code work.

## Input HEAD

`EFHC_Bot_v170_36_cycle_1460_simulation_dashboard_ui_kit_foundation.zip`

## Added

- `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`
- `docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md`
- `tests/architecture/test_admin_dashboard_ui_kit_foundation.py`
- `reports/generated/admin_dashboard_ui_kit_foundation_v170_37.json`
- `reports/change_cycle_2026-06-06_v170_37_cycle_1461_admin_dashboard_ui_kit_foundation.md`

## Changed

- `frontend/src/components/admin/AdminDashboardUiKit.tsx`
- `frontend/src/styles/globals.css`
- `KERNEL.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- dashboard NORM documents
- cycle plan docs
- testing manifest
- reports index
- operator kernel routes/cache

## Runtime boundary

No economy, backend contract, DB migration, CI, workflow, or lock file
was changed.

## Reference boundary

Песочница and Grafana were used only as reference/navigation/prototype
layers. Runtime code was not copied.

## Next step

`1462 — Panel Chrome / единая оболочка панели`

---

## Источник: `WORK_CYCLES_1462_PANEL_CHROME_FOUNDATION.md`

# WORK CYCLE 1462 — PANEL CHROME FOUNDATION

Status: `DONE_LOCAL`

Archive: `EFHC_Bot_v170_38_cycle_1462_panel_chrome_foundation.zip`

## Goal

Create a shared EFHC-owned panel chrome foundation for Admin Dashboard
Layer and Simulation Dashboard Layer.

## Input HEAD

`EFHC_Bot_v170_37_cycle_1461_admin_dashboard_ui_kit_foundation.zip`

## Work completed

- Added shared `PanelChrome` runtime component.
- Added `SimPanelChrome` wrapper for simulation dashboards.
- Updated `AdminPanelChrome` to use the shared foundation.
- Added shared CSS classes for panel chrome structure.
- Extended Grafana element usage map with detailed panel anchors.
- Updated `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` with the cycle 1462 Grafana analysis.
- Added machine report and active architecture guard.

## Changed runtime files

- `frontend/src/components/dashboard/PanelChrome.tsx`
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`
- `frontend/src/styles/globals.css`

## New documents

- `docs/NORM/PANEL_CHROME_FOUNDATION.md`
- `docs/cycles/WORK_CYCLES_1462_PANEL_CHROME_FOUNDATION.md`
- `reports/generated/panel_chrome_foundation_v170_38.json`
- `reports/change_cycle_2026-06-06_v170_38_cycle_1462_panel_chrome_foundation.md`

## New guard

- `tests/architecture/test_panel_chrome_foundation.py`

## Safety boundaries

- Economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows changed: no.
- Lock files changed: no.
- Grafana runtime copied: no.
- Песочница runtime copied: no.
- Tests deleted, skipped, xfailed or hidden: no.

## Local validation

- ZIP integrity checked.
- AI Archive Laws integrity checked.
- Targeted dashboard guard pack checked.
- Operator Kernel file map refreshed.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- Release-ready.
- Browser screenshot proof.
- Live Telegram proof.
- Real TonConnect / wallet proof.

## Next safe step

`1463 — Progress System Foundation`

---

## Источник: `WORK_CYCLES_1463_PROGRESS_SYSTEM_FOUNDATION.md`

# WORK CYCLE 1463 — PROGRESS SYSTEM FOUNDATION

Status: `DONE_LOCAL`

Archive target: `v170.39`

## Goal

Create the shared Progress System Foundation for Dashboard Visual
Direction without changing EFHC economy, backend contracts, database
schema, CI, lock files or money flows.

## Scope

Added reusable progress primitives for user simulation dashboards and
admin dashboards:

- linear progress;
- segmented progress;
- circular progress;
- countdown progress;
- milestone progress.

## Runtime files

- `frontend/src/components/dashboard/ProgressSystem.tsx`;
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`;
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`;
- `frontend/src/styles/globals.css`.

## Docs and reports

- `docs/NORM/PROGRESS_SYSTEM_FOUNDATION.md`;
- `docs/cycles/WORK_CYCLES_1463_PROGRESS_SYSTEM_FOUNDATION.md`;
- `reports/generated/progress_system_foundation_v170_39.json`;
- `reports/change_cycle_2026-06-06_v170_39_cycle_1463_progress_system_foundation.md`.

## Grafana reference use

Grafana progress/gauge elements were used only as visual reference:

- `BarGauge`;
- `RadialGauge`;
- `BigValue/PercentChange`;
- `StatusHistoryPanel`;
- `StateTimelinePanel`;
- simple `ProgressBar`.

No Grafana runtime code was copied.

## Validation

Targeted local guards protect:

- progress component exports;
- real countdown constants;
- dashboard data-kind markers;
- no Grafana import;
- no sandbox runtime copy;
- docs and map registration.

## Not claimed

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshot proof;
- live Telegram proof;
- real TonConnect/wallet proof.

## Next cycle

`1464 — Mini Charts Foundation`.

---

## Источник: `WORK_CYCLES_1464_MINI_CHARTS_FOUNDATION.md`

# WORK CYCLE 1464 — MINI CHARTS FOUNDATION

Status: `DONE_LOCAL`

Version: `v170.40`

## Goal

Create the EFHC-owned Mini Charts Foundation for Dashboard Visual
Direction Plan. The work adds dependency-light SVG/CSS mini charts for
future Simulation and Admin dashboards.

## Added

- `frontend/src/components/dashboard/MiniCharts.tsx`
- `docs/NORM/MINI_CHARTS_FOUNDATION.md`
- `tests/architecture/test_mini_charts_foundation.py`
- `reports/generated/mini_charts_foundation_v170_40.json`

## Updated

- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`
- `frontend/src/components/admin/AdminDashboardUiKit.tsx`
- `frontend/src/styles/globals.css`
- `docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`
- `KERNEL.md`

## Safety

- No EFHC economy change.
- No backend contract change.
- No DB migration change.
- No CI/workflow or lock-file change.
- No Grafana runtime code copied.
- No Песочница runtime code copied.
- No heavy chart dependency added.

## Validation

Targeted architecture guards were added for mini chart components,
metadata, wrappers, CSS tokens, Grafana map and machine report.

## Next

`1465 — Dashboard Toolbar Foundation`.

---

## Источник: `WORK_CYCLES_1465_DASHBOARD_TOOLBAR_FOUNDATION.md`

# 1465 — Dashboard Toolbar Foundation / v170.41

Status: `DONE_LOCALLY`

## Goal

Create the first EFHC-owned dashboard toolbar foundation for Admin
Dashboard Layer and Simulation Dashboard Layer.

## Done

- Added shared runtime toolbar:
  `frontend/src/components/dashboard/DashboardToolbar.tsx`.
- Added admin wrappers in:
  `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- Added simulation wrappers in:
  `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- Added CSS foundation in:
  `frontend/src/styles/globals.css`.
- Added active NORM document:
  `docs/NORM/DASHBOARD_TOOLBAR_FOUNDATION.md`.
- Added guard:
  `tests/architecture/test_dashboard_toolbar_foundation.py`.
- Updated Grafana usage map and `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` with toolbar anchors.

## Safety boundary

No EFHC economy, backend contract, database migration, CI workflow,
lock file, wallet logic, payment logic or admin write flow was changed.

Grafana and Песочница remain reference/navigation/prototype layers only.

## Next

`1466 — Variables / Filters System`.

---

## Источник: `WORK_CYCLES_1466_VARIABLES_FILTERS_SYSTEM.md`

# 1466 — Variables / Filters System / v170.42

Status: `DONE_LOCALLY`

## Goal

Create the first EFHC-owned dashboard variables / filters foundation for
Admin Dashboard Layer and Simulation Dashboard Layer.

## Done

- Added shared runtime filter system:
  `frontend/src/components/dashboard/DashboardFilters.tsx`.
- Added admin wrappers in:
  `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- Added simulation wrappers in:
  `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- Added CSS foundation in:
  `frontend/src/styles/globals.css`.
- Added active NORM document:
  `docs/NORM/VARIABLES_FILTERS_SYSTEM.md`.
- Added guard:
  `tests/architecture/test_variables_filters_system.py`.
- Updated Grafana usage map and `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` with variables/filter
  anchors.

## Safety boundary

No EFHC economy, backend contract, database migration, CI workflow,
lock file, wallet logic, payment logic or admin write flow was changed.

Filters are read-only display controls. URL query sync is allowed only
for safe display keys and is not business truth.

Grafana and Песочница remain reference/navigation/prototype layers only.

## Next

`1467 — Energy Dashboard Sandbox Prototype`.

---

## Источник: `WORK_CYCLES_1467_ENERGY_DASHBOARD_SANDBOX_PROTOTYPE.md`

# 1467 — Energy Dashboard Sandbox Prototype / v170.43

Status: `DONE_LOCALLY`

## Goal

Create an Energy Dashboard sandbox prototype for the Dashboard Visual Direction.

## Done

- Added active document:
  `docs/NORM/ENERGY_DASHBOARD_SANDBOX_PROTOTYPE.md`.
- Added Grafana element analysis:
  `docs/NORM/ENERGY_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added EFHC-owned prototype component:
  `frontend/src/components/dashboard/EnergyDashboardSandboxPrototype.tsx`.
- Added CSS foundation in:
  `frontend/src/styles/globals.css`.
- Added architecture guard:
  `tests/architecture/test_energy_dashboard_sandbox_prototype.py`.
- Updated navigation:
  `KERNEL.md`, `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`, `routes.yaml`, `file_map.json`.
- Updated dashboard plan/kernel, sandbox inventory and Grafana usage map.

## Safety boundary

The prototype is sandbox-only and uses `synthetic_preview` markers.

No EFHC economy, backend contract, database migration, OpenAPI contract, CI workflow, package dependency, lock file, wallet logic, payment logic or admin write flow was changed.

No Grafana runtime code was copied.

No Песочница runtime code was copied.

## Dependency audit note

Cycle 1466 reported npm audit vulnerabilities after `npm ci`: `5 vulnerabilities`, including `3 moderate` and `2 high`.

This issue was promoted by user decision into cycle `1468 — Dependency Audit Triage`.

## Next

`1468 — Dependency Audit Triage`; after shift, Energy Dashboard Runtime Port moves to `1469`.

---

## Источник: `WORK_CYCLES_1468_DEPENDENCY_AUDIT_TRIAGE.md`

# 1468 — Dependency Audit Triage / v170.44

Status: `DONE_LOCALLY`

## Goal

Repair supplied CI-log failures and close npm dependency audit findings before the Energy Dashboard Runtime Port.

## Input

- HEAD: `EFHC_Bot_v170_43_cycle_1467_energy_dashboard_sandbox_prototype.zip`.
- Logs: `logs_72723974684.zip`.
- User decision: create separate cycle `1468 — Dependency Audit Triage` and shift following dashboard cycles.

## Done

- Read supplied logs first.
- Identified pytest root causes:
  - missing Kernel legacy marker `v170.27 / CI log repair`;
  - forbidden transient artifact `frontend/tsconfig.tsbuildinfo`.
- Restored Kernel compatibility marker.
- Removed `frontend/tsconfig.tsbuildinfo` from release tree.
- Ran npm audit triage.
- Updated controlled dependency boundaries in `frontend/package.json` and `frontend/package-lock.json`.
- Added dependency audit docs and guard.
- Shifted dashboard cycle plan forward by one step.

## Dependency result

```text
npm audit --json: 0 vulnerabilities
```

## Safety boundary

No EFHC economics, backend runtime, database migration, OpenAPI contract, admin write flow, CI workflow, Grafana runtime code or Песочница runtime code was changed.

## Next

`1469 — Energy Dashboard Runtime Port`.


## Artifact cleanup hardening

`ops/cleanup_artifacts.py` now removes nested frontend `node_modules`, `.next`, `.turbo` and `out` artifacts before local guard runs and packaging.

---

## Источник: `WORK_CYCLES_1469_ENERGY_DASHBOARD_RUNTIME_PORT.md`

# WORK CYCLE 1469 — ENERGY DASHBOARD RUNTIME PORT

Status: `DONE_LOCAL`

Archive: `EFHC_Bot_v170_45_cycle_1469_energy_dashboard_runtime_port.zip`

## Goal

Port the Energy Dashboard sandbox prototype into the live Energy route
using runtime snapshot data and without changing EFHC economy or
write-flow.

## Result

Added runtime Energy Dashboard layer:

- `frontend/src/components/dashboard/EnergyDashboardRuntime.tsx`
- route integration in `frontend/src/pages/index.tsx`
- user-facing locale keys in `frontend/public/locale/ru.json`
- user-facing locale keys in `frontend/public/locale/en.json`

The existing live Energy hero and existing public interactive overview
were preserved.

## Truth model

- Runtime data kind: `raw` and `derived`.
- Synthetic preview data in runtime: no.
- Real time-series claim: no.
- Backend write-flow: no.
- Money action added: no.

## Grafana / Песочница

Grafana used only as visual-pattern/reference layer.
Runtime code was not copied.

Песочница used only as reference/navigation/prototype layer.
Runtime code was not copied.

## Boundaries

Changed:

- frontend runtime UI component;
- Energy page integration;
- docs/reports/tests/navigation;
- RU/EN locale keys;
- one UI-kit cleanup: duplicated unit span in `SimHeroEnergyCard`.

Not changed:

- EFHC economy;
- backend routes;
- database migrations;
- OpenAPI;
- CI/workflows;
- package dependencies;
- lock files;
- write/money flows.

## Validation

Local validation must not be overstated as GitHub CI proof.

Validated locally:

- targeted architecture guard for cycle 1469;
- selected dashboard guard pack;
- AI Archive Laws integrity;
- test-suite integrity guard;
- frontend `npm ci`;
- `npm audit --json` with zero vulnerabilities;
- frontend typecheck.

Not claimed:

- GitHub CI green;
- full pytest green;
- full production build green;
- browser screenshots;
- live Telegram proof;
- real TonConnect/wallet proof;
- release-ready.

## Next cycle

`1470 — Energy Dashboard Visual QA`

---

## Источник: `WORK_CYCLES_1470_ENERGY_DASHBOARD_VISUAL_QA.md`

# WORK CYCLE 1470 — ENERGY DASHBOARD VISUAL QA

Status: `DONE_LOCALLY`

Version: `v170.46`

Input HEAD: `v170.45 / Energy Dashboard Runtime Port`

Output HEAD: `v170.46 / Energy Dashboard Visual QA`

## Goal

Run a visual QA pass over the runtime Energy Dashboard and fix safe UI-only issues without changing economy, backend truth, write-flows, dependencies, lock files or CI.

## What changed

- Added active QA document: `docs/NORM/ENERGY_DASHBOARD_VISUAL_QA.md`.
- Added Grafana visual QA analysis: `docs/NORM/ENERGY_DASHBOARD_VISUAL_QA_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added visual QA guard: `tests/architecture/test_energy_dashboard_visual_qa.py`.
- Added generated report: `reports/generated/energy_dashboard_visual_qa_v170_46.json`.
- Added change report: `reports/change_cycle_2026-06-07_v170_46_cycle_1470_energy_dashboard_visual_qa.md`.
- Added runtime visual QA markers to `EnergyDashboardRuntime.tsx`.
- Hardened Energy dashboard CSS against mobile overflow and long localized values.
- Fixed Russian user-facing labels for raw/derived dashboard truth markers.

## Fixed findings

1. Russian labels `raw snapshot` / `derived display` were still English.
2. Runtime Energy dashboard needed stronger anti-overflow CSS for mobile widths and long values.
3. Runtime component needed explicit visual QA markers for future screenshot/test agents.

## Browser proof

Local HTTP proof was available via curl.

Browser screenshot capture was attempted, but Chromium/Playwright was blocked by environment policy:

`net::ERR_BLOCKED_BY_ADMINISTRATOR`

Therefore browser screenshots are not claimed.

## Boundaries

No changes to:

- economy;
- backend;
- DB migrations;
- OpenAPI;
- dependencies;
- lock files;
- CI/workflows;
- TonConnect/wallet logic;
- write-flow;
- money-flow.

## Next safe cycle

`1471 — Panels Portfolio Sandbox Prototype`

---

## Источник: `WORK_CYCLES_1471_PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`

# WORK CYCLE 1471 — PANELS PORTFOLIO SANDBOX PROTOTYPE

Human title: Panels Portfolio Sandbox Prototype

Status: `DONE_LOCAL`

Archive: `v170.47`

Input HEAD: `v170.46 / Energy Dashboard Visual QA`

## Goal

Create a sandbox-only Panels Portfolio Dashboard prototype without changing live `/panels`, backend truth, EFHC economics or panel activation flows.

## Added

- `frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx`;
- `docs/NORM/PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`;
- `docs/NORM/PANELS_PORTFOLIO_SANDBOX_GRAFANA_ELEMENT_ANALYSIS.md`;
- `reports/generated/panels_portfolio_sandbox_prototype_v170_47.json`;
- `reports/change_cycle_2026-06-07_v170_47_cycle_1471_panels_portfolio_sandbox_prototype.md`;
- `tests/architecture/test_panels_portfolio_sandbox_prototype.py`.

## Prototype structure

- portfolio toolbar;
- period filter;
- active/archive state filter;
- total/active/archive/nearest expiry KPI strip;
- generated kWh summary;
- lifecycle segmented progress;
- portfolio trend preview;
- active/archive distribution preview;
- activity strip preview;
- individual panel cards;
- 180-day lifecycle countdown;
- truth/safety boundary panel.

## Boundaries

Changed: docs, tests, CSS, sandbox prototype component and navigation indexes.

Not changed:

- EFHC economics;
- backend routes;
- DB migrations;
- OpenAPI;
- package dependencies;
- lock files;
- CI workflows;
- runtime `/panels` page;
- panel activation logic;
- money/write flows.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime code is not copied.

## Local validation

Targeted validation is recorded in the final chat report and generated machine report.

Not claimed:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe cycle

`1472 — Panels Portfolio Runtime Port`

---

## Источник: `WORK_CYCLES_1472_PANELS_PORTFOLIO_RUNTIME_PORT.md`

# WORK CYCLE 1472 — PANELS PORTFOLIO RUNTIME PORT

Human title: Panels Portfolio Runtime Port

Status: `DONE_LOCAL`

Archive: `v170.48`

Input HEAD: `v170.47 / Panels Portfolio Sandbox Prototype`

## Goal

Port the Panels Portfolio Dashboard idea from sandbox into the live
`/panels` runtime page without changing EFHC economics, backend state,
activation flow or write/money flows.

## Added

- `frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx`;
- `docs/NORM/PANELS_PORTFOLIO_RUNTIME_PORT.md`;
- `docs/NORM/PANELS_PORTFOLIO_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md`;
- `reports/generated/panels_portfolio_runtime_port_v170_48.json`;
- `reports/change_cycle_2026-06-07_v170_48_cycle_1472_panels_portfolio_runtime_port.md`;
- `tests/architecture/test_panels_portfolio_runtime_port.py`.

## Runtime structure

- portfolio toolbar;
- active/archive filter connected to existing tab state;
- raw KPI strip;
- derived loaded-list metrics;
- summary panel;
- mini bar chart from loaded panel snapshots;
- activity strip from loaded active/archive statuses;
- runtime panel cards with countdown and lifecycle progress.

## Truth boundary

Runtime data kind: `raw + derived snapshot`.

No synthetic preview data is used in runtime.

No real time-series is claimed.

Loaded archive count is marked as loaded-list derived data, not total
archive truth.

## Boundaries

Changed: frontend runtime display, docs, tests, CSS, locales and
navigation indexes.

Not changed:

- EFHC economics;
- backend routes;
- DB migrations;
- OpenAPI;
- dependencies;
- lock files;
- CI workflows;
- panel activation price;
- debit order;
- idempotency;
- money/write flows.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Local validation

Targeted validation is recorded in the final chat report and generated
machine report.

Not claimed:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe cycle

`1473 — Panel Cards Deep Polish`

---

## Источник: `WORK_CYCLES_1473_PANEL_CARDS_DEEP_POLISH.md`

# WORK_CYCLES_1473_PANEL_CARDS_DEEP_POLISH.md

**Cycle:** `1473 — Panel Cards Deep Polish`  
**Archive:** `v170.49`  
**Status:** DONE_LOCAL  
**Mode:** UI-only / runtime display / sandbox formula hardening

## Goal

Polish panel cards after Panels Portfolio Runtime Port.
Also apply the user recommendation: synthetic preview numbers must be
internally consistent.

## Completed

- Added runtime panel-card micro-state model.
- Added `expiring_soon`, `newly_active`, `active_cycle`,
  `archived_complete` card states.
- Added accessibility card labels.
- Added explicit kWh and kWh/s display units.
- Formatted runtime card UTC dates.
- Removed duplicate archive lifecycle progress.
- Hardened sandbox formula consistency.
- Removed old hardcoded preview generation rates.
- Added all 13 locale keys for panel-card polish.
- Updated docs, Kernel, map, reports and guards.

## Boundaries

- Economy changed: no.
- Backend changed: no.
- DB migrations changed: no.
- OpenAPI changed: no.
- Dependencies or lock files changed: no.
- Write or money flow changed: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

## Next safe cycle

`1474 — Ranks Dashboard Sandbox Prototype`

---

## Источник: `WORK_CYCLES_1474_RANKS_DASHBOARD_SANDBOX_PROTOTYPE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK_CYCLES_1474_RANKS_DASHBOARD_SANDBOX_PROTOTYPE.md

**Cycle:** `1474 — Ranks Dashboard Sandbox Prototype`  
**Archive:** `v170.50`  
**Status:** DONE_LOCAL  
**Date:** 2026-06-07

## Goal

Create a sandbox-only Ranks dashboard prototype after Panel Cards Deep
Polish.

## Result

Added Ranks dashboard preview component:

```text
frontend/src/components/dashboard/RanksDashboardSandboxPrototype.tsx
```

The prototype includes:

- rank hero;
- my position and score cards;
- visible leaderboard goal;
- leaderboard scope filter;
- podium and near-me cards;
- username-only leaderboard rows;
- position ladder;
- score composition preview;
- synthetic trend preview;
- privacy / truth strip.

## Safety boundaries

Economy changed: no.  
Backend changed: no.  
OpenAPI changed: no.  
Dependencies or lock files changed: no.  
Runtime `/ranks` changed: no.  
Write or money flow changed: no.  
Raw `tg_id` exposed: no.  
Internal 12 Energy levels exposed in Ranks: no.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Checks

Local targeted guards were added in:

```text
tests/architecture/test_ranks_dashboard_sandbox_prototype.py
```

## Next

Next safe cycle:

```text
1475 — Ranks Dashboard Runtime Port
```

---

## Источник: `WORK_CYCLES_1475_RANKS_DASHBOARD_RUNTIME_PORT.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK_CYCLES_1475_RANKS_DASHBOARD_RUNTIME_PORT.md

**Cycle:** `1475 — Ranks Dashboard Runtime Port`  
**Archive:** `v170.51`  
**Status:** DONE_LOCAL  
**Date:** 2026-06-07

## Goal

Port the Ranks Dashboard from sandbox preview into the live `/ranks`
runtime surface without changing backend, economy or write flows.

## Result

Added runtime component:

```text
frontend/src/components/dashboard/RanksDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/ranks.tsx
```

## Key repair

The old fallback that could visually present an unloaded user as `#1`
was removed. The UI now displays a rank position only after backend
truth is loaded. Otherwise it shows `—` / empty or loading state.

## Safety boundaries

Economy changed: no.  
Backend changed: no.  
OpenAPI changed: no.  
Dependencies or lock files changed: no.  
Runtime `/ranks` changed: yes, UI-only read-only dashboard.  
Write or money flow changed: no.  
Raw `tg_id` visible in public UI: no.  
Fake leaderboard rows added: no.  
Internal 12 Energy levels exposed in Ranks: no.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Next

`1476 — Leaderboard Visual System`.

---

## Источник: `WORK_CYCLES_1476_LEADERBOARD_VISUAL_SYSTEM.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK_CYCLES_1476_LEADERBOARD_VISUAL_SYSTEM.md

**Cycle:** `1476 — Leaderboard Visual System`  
**Archive:** `v170.52`  
**Status:** DONE_LOCAL  
**Date:** 2026-06-07

## Goal

Create a shared leaderboard visual layer for Ranks without changing
backend truth, economics or write flows.

## Result

Added:

```text
frontend/src/components/dashboard/LeaderboardVisualSystem.tsx
```

Integrated into:

```text
frontend/src/components/dashboard/RanksDashboardRuntime.tsx
```

## Protected boundaries

Economy changed: no.  
Backend changed: no.  
OpenAPI changed: no.  
Dependencies or lock files changed: no.  
Runtime `/ranks` changed: yes, UI-only read-only visual layer.  
Write or money flow changed: no.  
Raw `tg_id` visible in public UI: no.  
Fake leaderboard rows added: no.  
Internal 12 Energy levels exposed in Ranks: no.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Next

`1477 — Tasks Dashboard Upgrade`.

---

## Источник: `WORK_CYCLES_1477_TASKS_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1477_TASKS_DASHBOARD_UPGRADE.md

**Cycle:** `1477 — Tasks Dashboard Upgrade`  
**Archive:** `v170.53`  
**Status:** DONE_LOCAL

## Goal

Upgrade `/tasks` into a progress-based simulation dashboard without
changing task economics, backend routes, reward values or write flows.

## Result

Created runtime component:

```text
frontend/src/components/dashboard/TasksDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/tasks.tsx
```

## Boundaries

- Existing task claim and ad-view buttons remain the only action layer.
- Dashboard component is UI-only and does not call API directly.
- Public `/tasks` still does not show execution history, backend logs,
  idempotency/debug data or admin traces.
- Rewards are displayed from catalog/status data and are not
  recalculated as economics.

## Checks

Guard:

```text
tests/architecture/test_tasks_dashboard_upgrade.py
```

Next safe cycle:

```text
1478 — Referrals Dashboard Upgrade
```

---

## Источник: `WORK_CYCLES_1478_REFERRALS_DASHBOARD_UPGRADE.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work Cycle 1478 — Referrals Dashboard Upgrade

## Status

`DONE_LOCAL`

## Result

Live `/referrals` now has a runtime dashboard section based on existing
referral stats. It shows total, active, inactive, bonus balance, bonus
summary, progress and privacy/truth boundaries.

## Files

- `frontend/src/components/dashboard/ReferralsDashboardRuntime.tsx`
- `frontend/src/pages/referrals.tsx`
- `docs/NORM/REFERRALS_DASHBOARD_UPGRADE.md`
- `docs/NORM/REFERRALS_DASHBOARD_UPGRADE_GRAFANA_ELEMENT_ANALYSIS.md`
- `reports/generated/referrals_dashboard_upgrade_v170_54.json`
- `tests/architecture/test_referrals_dashboard_upgrade.py`

## Safety

- Backend changed: no.
- OpenAPI changed: no.
- Economy changed: no.
- Dependencies changed: no.
- Lock files changed: no.
- Write-flow changed: no.
- Money-flow changed: no.
- Fake runtime referral history added: no.
- Public raw `tg_id` exposed by dashboard: no.

## Next safe cycle

`1479 — Exchange Dashboard Support Widgets`

---

## Источник: `WORK_CYCLES_1479_EXCHANGE_DASHBOARD_SUPPORT_WIDGETS.md`

# Work Cycle 1479 — Exchange Dashboard Support Widgets

**Version:** v170.55  
**Status:** DONE locally  

## Goal

Add lightweight Exchange dashboard support widgets without changing
exchange economy, backend routes, OpenAPI, idempotency or write-flow.

## Completed

- Added `ExchangeDashboardRuntime.tsx`.
- Integrated it into live `/exchange` route.
- Added visual summary for available kWh, exchangeable kWh, expected EFHC
  and main balance.
- Added kWh -> EFHC flow panel.
- Added one-way and no-reverse boundary chips.
- Added preview readiness panel.
- Added history boundary link to account history.
- Added locale keys for all active languages.
- Added architecture guard.

## Boundaries

- Exchange rate remains `1 kWh = 1 EFHC`.
- Reverse exchange remains forbidden.
- Dashboard widgets do not call write APIs.
- Existing `ExchangePanel` keeps protected conversion flow.
- Backend, DB, OpenAPI, dependencies, lock files and CI/workflows changed:
  no.

## Reference use

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Next safe cycle

`1480 — Web Profile / Account Center Dashboard Polish`.

---

## Источник: `WORK_CYCLES_1480_WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work Cycle 1480 — Web Profile / Account Center Dashboard Polish

**Version:** v170.56  
**Status:** DONE locally

## Goal

Add account dashboard widgets to Web-Profile without changing backend,
wallet/history write flows, economy or dependencies.

## Completed

- Added `WebProfileAccountDashboard.tsx`.
- Integrated it into live `WebProfilePage.tsx`.
- Added Account Center summary widgets.
- Added wallet, history and quick-link panels.
- Added privacy markers for no raw payload and no debug payload.
- Added locale keys for all active languages.
- Added architecture guard.

## Boundaries

- Web-Profile remains a public account center.
- Wallet and history sections remain existing canonical sections.
- Dashboard does not call write APIs.
- Raw `tg_id`, initData, payloads and debug JSON are not shown.
- Backend, DB, OpenAPI, dependencies, lock files and CI/workflows changed: no.

## Reference use

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Next safe cycle

`1481 — Admin Overview Dashboard Upgrade`.

---

## Источник: `WORK_CYCLES_1481_ADMIN_OVERVIEW_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1481_ADMIN_OVERVIEW_DASHBOARD_UPGRADE

**Cycle:** 1481  
**Title:** Admin Overview Dashboard Upgrade  
**Archive:** v170.57  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin` into an operator overview dashboard while preserving all
financial, backend and security invariants.

## Completed

- Added `AdminOverviewDashboardRuntime`.
- Integrated the dashboard into `frontend/src/pages/admin/index.tsx`.
- Added read-only KPI cards, facts, module coverage and quick links.
- Added a truth/safety boundary panel.
- Added CSS for mobile-safe admin overview layout.
- Added NORM, Grafana analysis, generated report and guard.

## Boundaries

Changed:

- admin runtime UI;
- docs;
- reports;
- architecture guard;
- map/kernel navigation.

Not changed:

- EFHC economy;
- backend routes;
- DB migrations;
- OpenAPI;
- dependencies;
- lock files;
- CI/workflows;
- wallet / TonConnect;
- money/write flows.

## Verification

Targeted local verification is recorded in the final chat report.
External CI, full pytest, full frontend build, screenshots, live
Telegram proof and wallet proof are not claimed.

## Next safe cycle

`1482 — Admin Reports Grafana-like Upgrade`

---

## Источник: `WORK_CYCLES_1482_ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE.md`

# WORK_CYCLES_1482_ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE

## Cycle

`1482 — Admin Reports Grafana-like Upgrade`

## Status

`DONE_LOCALLY` in `v170.58`.

## Scope

Upgrade live `/admin/reports` into a Grafana-like read-only reports
surface.

## Files

- `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE.md`
- `docs/NORM/ADMIN_REPORTS_GRAFANA_LIKE_ELEMENT_ANALYSIS.md`
- `reports/generated/admin_reports_grafana_like_upgrade_v170_58.json`
- `tests/architecture/test_admin_reports_grafana_like_upgrade.py`

## Result

- Admin toolbar, freshness and manual refresh added.
- Report scope filter remains display-only.
- Fake trend generation from a single snapshot was removed.
- Derived charts are labelled as snapshot display.
- Safe inspector does not show raw payload or debug JSON.
- Export/download panel remains separate.

## Boundaries

Economy, backend routes, migrations, OpenAPI, dependencies, lock files,
CI/workflows, wallet/TonConnect, money and write flows were not changed.

Grafana and Песочница were used only as reference layers.

## Next safe cycle

`1483 — Admin Bank Dashboard Upgrade`

---

## Источник: `WORK_CYCLES_1483_ADMIN_BANK_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1483_ADMIN_BANK_DASHBOARD_UPGRADE

**Cycle:** 1483  
**Title:** Admin Bank Dashboard Upgrade  
**Archive:** v170.59  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin/bank` into a read-only operator dashboard for EFHC Bank.

## Completed

- Added `AdminBankDashboardRuntime.tsx`.
- Integrated it into `frontend/src/pages/admin/bank.tsx`.
- Added read-only bank KPI cards.
- Added derived snapshot chart display.
- Added canonical bank flow map.
- Added operation safety status.
- Added recent ledger timeline.
- Added bank safety boundary.
- Preserved existing mint/burn confirmation flow separately.

## Safety

No economy, backend, OpenAPI, dependency, lock-file, CI/workflow,
TonConnect, wallet or money/write-flow changes were made.

## Validation

Local targeted guards and frontend typecheck passed. GitHub CI green,
full pytest green, full frontend build green, release-ready, screenshots,
live Telegram proof and real wallet proof are not claimed.

## Next

`1484 — Admin Users Dashboard Upgrade`.

---

## Источник: `WORK_CYCLES_1484_ADMIN_USERS_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1484_ADMIN_USERS_DASHBOARD_UPGRADE

## Cycle

`1484 — Admin Users Dashboard Upgrade`

## Archive

`v170.60`

## Status

DONE LOCALLY

## Goal

Upgrade `/admin/users` into a read-only operator dashboard for the users domain
without changing backend routes, OpenAPI, economy, user actions, wallet reset,
VIP toggle, active toggle, `/admin/transfer` or any money/write flow.

## Implemented

- Added `frontend/src/components/admin/AdminUsersDashboardRuntime.tsx`.
- Integrated it into `frontend/src/pages/admin/users.tsx`.
- Removed the old sandbox-style `AdminInteractiveOperatorPanel` from the users
  route.
- Added read-only KPI cards, segment distribution, balance snapshot, readiness
  strip and operator drill-down boundary.
- Added docs, generated report and architecture guard.

## Truth model

`raw + derived snapshot`

No synthetic admin analytics, fake retention, fake time-series, raw payload,
debug JSON, secrets or dashboard write actions were added.

## Next

`1485 — Admin Deposits Dashboard Upgrade`

---

## Источник: `WORK_CYCLES_1485_ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1485_ADMIN_DEPOSITS_DASHBOARD_UPGRADE

**Cycle:** 1485 — Admin Deposits Dashboard Upgrade  
**Archive:** v170.61  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin/efhc-deposits` into a Grafana-like read-only dashboard
for the EFHC deposit money-path.

## Result

Added:

```text
frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/efhc-deposits.tsx
```

The dashboard shows runtime summary, pipeline counters, automation ratio,
exception backlog ratio, input readiness and operator-order boundary.

## Boundaries

No backend, DB, OpenAPI, dependency, lock-file, CI/workflow, economy,
wallet or money/write-flow change.

Replay, exception processing and force fulfill stay in the existing guarded
controls.

## Checks

Local targeted checks passed. GitHub CI green, full pytest green, full
frontend build green, release-ready, browser screenshots, live Telegram
proof and real wallet proof are not claimed.

## Next

Next safe cycle:

```text
1486 — Admin Withdrawals Dashboard Upgrade
```

---

## Источник: `WORK_CYCLES_1486_ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1486_ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE

**Cycle:** 1486 — Admin Withdrawals Dashboard Upgrade  
**Archive:** v170.62  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin/withdrawals` into a Grafana-like read-only dashboard for
withdrawal queue control, without changing the guarded decision flow.

## Result

Added:

```text
frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/withdrawals.tsx
```

The dashboard shows pending queue, final statuses, operator attention,
VIP share, pending age buckets, average handling only from real timestamps,
recent queue snapshot and the canonical operator order.

## Boundaries

No backend, DB, OpenAPI, dependency, lock-file, CI/workflow, economy,
wallet or money/write-flow change.

Approve, reject, TonConnect payment and consistency repair stay in the
existing guarded controls.

## Checks

Local targeted checks passed. GitHub CI green, full pytest green, full
frontend build green, release-ready, browser screenshots, live Telegram
proof and real wallet proof are not claimed.

## Next

Next safe cycle:

```text
1487 — Admin Panels Dashboard Upgrade
```

---

## Источник: `WORK_CYCLES_1487_ADMIN_PANELS_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1487_ADMIN_PANELS_DASHBOARD_UPGRADE

**Cycle:** 1487 — Admin Panels Dashboard Upgrade  
**Archive:** v170.63  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin/panels` into a Grafana-like read-only dashboard for panel
lifecycle control, without changing the existing guarded activation and
deactivation flow.

## Result

Added:

```text
frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/panels.tsx
```

The dashboard shows active/archive distribution, expiring-soon markers,
missing-expiry attention markers, 180-day lifecycle progress, generated
kWh totals, base generation-rate audit totals, age buckets, recent safe
panel snapshot and the canonical operator order.

## Side repair

Closed the user-reported deposits dashboard UX debt: `pending_intents` is
now represented as a third read-only progress bar in the 1485 Automation
readiness panel, so `Automation credited + Exception backlog + Pending
intents` covers the shared `observedTotal` denominator.

## Boundaries

No backend, DB, OpenAPI, dependency, lock-file, CI/workflow, economy,
generation-rate, panel lifecycle or money/write-flow change.

Panel activate/deactivate actions stay in the existing guarded controls.

## Checks

Local targeted checks passed. GitHub CI green, full pytest green, full
frontend build green, release-ready, browser screenshots, live Telegram
proof and real wallet proof are not claimed.

## Next

Next safe cycle:

```text
1488 — Admin Tasks / Referrals Dashboard Upgrade
```

---

## Источник: `WORK_CYCLES_1488_ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md`

# WORK_CYCLES_1488_ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md

## Статус

DONE locally in `v170.64`.

## Цель

Сделать `/admin/tasks` и `/admin/referrals` read-only dashboard surfaces без изменения guarded moderation/bonus/reassign flows.

## Сделано

- Added `frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx`.
- Integrated `AdminTasksDashboardRuntime` into `/admin/tasks`.
- Integrated `AdminReferralsDashboardRuntime` into `/admin/referrals`.
- Closed `VIS-04` by replacing visible `active/inactive` EN labels with Russian operator labels.
- Added chats `31.md` and `32.md` to `docs/NORM/CHATS/`.
- Updated dashboard docs, map, report index, test guard manifest and kernel navigation.

## Не менялось

- Backend routes/services.
- OpenAPI.
- DB migrations.
- EFHC economy.
- Task moderation write-flow.
- Referral manual bonus/reassign write-flow.
- Dependencies and lock files.
- CI/workflows.

## Проверки

Targeted local checks are recorded in the final chat report for the cycle. External CI green, full pytest green, full frontend build, screenshots, live Telegram and wallet proofs are not claimed.

## Следующий цикл

`1489 — Admin System Health Dashboard`.

---

## Источник: `WORK_CYCLES_1489_ADMIN_SYSTEM_HEALTH_DASHBOARD.md`

# WORK_CYCLES_1489_ADMIN_SYSTEM_HEALTH_DASHBOARD.md

Status: DONE locally. Added AdminSystemHealthDashboardRuntime, integrated `/admin/system`, repaired `logs_72992801401.zip`.

---

## Источник: `WORK_CYCLES_1490_ADMIN_LOGS_EVENTS_DASHBOARD.md`

# WORK_CYCLES_1490_ADMIN_LOGS_EVENTS_DASHBOARD.md

**Status:** DONE locally  
**Archive version:** `v170.66`  
**Cycle:** `1490 — Admin Logs / Events Dashboard`

## Done

- Repaired actual CI log failure from `logs_73159210416.zip`.
- Added `AdminLogsEventsDashboardRuntime`.
- Integrated read-only dashboard into `/admin/logs`.
- Preserved local Docker command helper below the dashboard.
- Updated dashboard/NORM/testing/report navigation.

## Boundaries

- No backend changes.
- No OpenAPI changes.
- No DB migrations.
- No economy changes.
- No dependencies or lockfile dependency boundary changes.
- No dashboard write actions.
- No fake time-series.
- No raw payload/debug JSON/secrets rendering.

## Next safe cycle

`1491 — Real Time-Series Backend Contracts`

---

## Источник: `WORK_CYCLES_1491_REAL_TIME_SERIES_BACKEND_CONTRACTS.md`

# WORK_CYCLES_1491_REAL_TIME_SERIES_BACKEND_CONTRACTS.md

## Cycle 1491 — Real Time-Series Backend Contracts / v170.67

### Цель

Создать admin-only read-only backend contracts для настоящих dashboard
временных рядов и зафиксировать green CI proof из `logs_73205751012.zip`.

### Сделано

- Добавлен route module `backend/app/routes/admin_observability_routes.py`.
- Подключён module `admin_observability_routes` в route registry.
- Добавлены endpoints:
  - `GET /admin/observability/summary`;
  - `GET /admin/observability/timeseries`;
  - `GET /admin/observability/events`;
  - `GET /admin/observability/health`.
- Обновлён checked-in OpenAPI static snapshot.
- Обновлён generated frontend seam `adminSeams.ts`.
- Добавлены NORM docs, Grafana analysis, report JSON и guard.
- Зафиксирован green log proof по `logs_73205751012.zip`.

### Инварианты

- Все новые endpoints read-only.
- Нет POST/PUT/PATCH/DELETE.
- Нет idempotency key creation.
- Нет money-changing service calls.
- Нет fake/synthetic runtime series.
- Нет raw payload/meta/debug JSON/secrets.
- Runtime-код Grafana и Песочницы не переносился.

### Проверки

См. `reports/generated/real_time_series_backend_contracts_v170_67.json`.

### Следующий цикл

`1492 — Synthetic Data Cleanup / Truth Hardening`.

---

## Источник: `WORK_CYCLES_1492_SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md`

# WORK_CYCLES_1492_SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md

**Цикл:** 1492 — Synthetic Data Cleanup / Truth Hardening  
**Версия:** v170.68  
**HEAD input:** `EFHC_Bot_v170_67_cycle_1491_real_time_series_backend_contracts.zip`  
**Output:** `EFHC_Bot_v170_68_cycle_1492_synthetic_data_cleanup_truth_hardening.zip`  
**Статус:** DONE LOCALLY

## Цель

После появления real backend time-series contracts убрать runtime surfaces,
которые строили fake/synthetic history из snapshot, и укрепить различение
`real_timeseries`, `derived snapshot` и `synthetic_preview`.

## Выполнено

- `/admin` переведён со старого `AdminInteractiveBankDashboard` на
  `AdminObservabilityTimeseriesDashboardRuntime`.
- Runtime dashboard теперь использует `GET /admin/observability/summary` и
  `GET /admin/observability/timeseries`.
- `_route_for_reason` получил точный referral match вместо широкого `ref`.
- `efhc_transfer_amount` явно закреплён как `EFHC gross turnover`.
- Добавлены `efhc_credit_amount` и `efhc_debit_amount`.
- Frontend seams обновлены для новых metric literals.
- OpenAPI/SSOT route snapshot пересобран статическим gate.
- Docs, reports, Kernel, map_element и test manifest обновлены.

## Запреты, которые сохранены

- No synthetic runtime series.
- No fake trend from one snapshot.
- No write-flow bypass.
- No idempotency key creation in dashboard.
- No raw payload/debug JSON/secrets display.
- No Grafana runtime code copy.
- No sandbox runtime code copy.
- No economy change.

## Следующий цикл

`1493 — Visual Performance / Bundle Safety`.

---

## Источник: `WORK_CYCLES_1493_VISUAL_PERFORMANCE_BUNDLE_SAFETY.md`

# Cycle 1493 — Visual Performance / Bundle Safety

**Archive:** v170.69  
**Status:** DONE locally  
**Previous safe HEAD:** v170.68 / cycle 1492  
**Next safe cycle:** 1494 — Accessibility / Localization / Overflow QA

## Goal

Protect dashboard visual direction from bundle bloat and heavy runtime
regressions before final QA/audit cycles.

## Done

- Added a lazy boundary for `AdminObservabilityTimeseriesDashboardRuntime` on
  `/admin` using `next/dynamic` with `ssr: false`.
- Added lightweight dashboard lazy placeholder CSS.
- Added NORM documentation for visual performance and bundle safety.
- Added Grafana element analysis for the performance decision.
- Added architecture guard for:
  - lazy admin-heavy panel boundary;
  - no heavy chart dependencies;
  - no Grafana runtime imports;
  - public/TMA route isolation from admin dashboard runtime;
  - docs/report/navigation updates.

## Not changed

- backend routes;
- OpenAPI;
- DB migrations;
- money-flow;
- write-flow;
- EFHC economy;
- dependencies;
- lock files;
- CI/workflows.

## Validation

Targeted local validation is recorded in the final chat report for this cycle.
GitHub CI green is not claimed for the new archive until CI is rerun.

---

## Источник: `WORK_CYCLES_1494_ACCESSIBILITY_LOCALIZATION_OVERFLOW_QA.md`

# Work Cycle 1494 — Accessibility / Localization / Overflow QA

**Archive:** `EFHC_Bot_v170_70_cycle_1494_accessibility_localization_overflow_qa.zip`  
**Input HEAD:** `EFHC_Bot_v170_69_cycle_1493_visual_performance_bundle_safety.zip`  
**Status:** DONE locally

## Goal

Harden the dashboard visual layer for accessibility, localization and overflow safety without changing business logic, backend write-flow, money-flow or EFHC economics.

## Done

- Added shared admin dashboard accessibility markers.
- Added `role="progressbar"` and aria values to dashboard progress bars.
- Added `role="status"` to shared admin dashboard status badges.
- Added KPI aria labels.
- Added CSS overflow hardening for long values, long translations and mobile widths.
- Cleaned Exchange/Profile `raw snapshot` locale placeholder values.
- Localized visible real time-series filter labels into Russian.
- Updated NORM docs, reports, Kernel, map_element and test manifest.

## Not changed

- Backend.
- OpenAPI.
- DB migrations.
- Economy.
- Write-flow.
- Dependencies / lock files.
- CI/workflows.

## Next safe cycle

`1495 — Final Dashboard Visual Audit / Screenshot Proof`.

---

## Источник: `WORK_CYCLES_1495_FINAL_DASHBOARD_VISUAL_AUDIT_SCREENSHOT_PROOF.md`

# Work cycle 1495 — Final Dashboard Visual Audit / Screenshot Proof

**Project:** EFHC Bot  
**Archive version:** v170.71  
**Status:** DONE locally

## Result

Cycle 1495 repaired the attached CI log failures, added final dashboard visual
audit documentation, confirmed public dashboard 13-locale parity, blocked
placeholder localization prefixes for dashboard keys and prepared the final
screenshot matrix without making a false browser-capture claim.

## Safety

No economy, money-flow, write-flow, migration, dependency, lock-file or
CI/workflow change was introduced. Grafana and Песочница remained reference-only.

## Next

1496 — Dashboard Direction Handoff / Backlog Freeze.

---

## Источник: `WORK_CYCLES_1496_DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md`

# WORK_CYCLES_1496_DASHBOARD_DIRECTION_HANDOFF_BACKLOG_FREEZE.md

## Cycle

`1496 — Dashboard Direction Handoff / Backlog Freeze`

## Version

`v170.72`

## Goal

Close the Dashboard Visual Direction, freeze the remaining backlog and add a
public user-dashboard 13-language invariant.

## Scope

- Dashboard direction handoff.
- Public user-dashboard i18n invariant.
- Runtime public dashboard label hardening.
- Documentation, reports, guards and navigation updates.

## Done

- Added handoff norm document.
- Added Grafana/reference analysis for handoff.
- Fixed remaining public dashboard placeholder translations.
- Added locale-driven panel countdown duration labels.
- Removed public runtime Russian fallbacks from mini-chart/progress primitives.
- Replaced visible public dashboard inline source labels with localized label
  props.
- Added architecture guard for dashboard handoff and public 13-language parity.

## Forbidden changes respected

- Economy changed: no.
- Backend write-flow changed: no.
- Money-flow changed: no.
- DB migrations changed: no.
- Dependencies changed: no.
- Lock files changed: no.
- CI/workflows changed: no.
- Grafana runtime copied: no.
- Песочница runtime copied: no.

## Status

- `1401–1500`: `96 / 100` done, `4 / 100` remaining.
- Dashboard direction `1455–1496`: `42 / 42` done, `0 / 42` remaining.

## Next safe work

Post-dashboard work should continue from the frozen backlog or the remaining
`1401–1500` range, not by reopening dashboard direction without a new cycle.

---

## Источник: `WORK_CYCLES_1497_DASHBOARD_DIRECTION_AUDIT_FOLLOWUP.md`

# WORK_CYCLES_1497_DASHBOARD_DIRECTION_AUDIT_FOLLOWUP.md

**Cycle:** 1497 — Dashboard Direction Audit Follow-up / Future Range Foundation  
**Archive version:** v170.73  
**Status:** DONE LOCALLY

## Goal

Close audit findings from dashboard direction `1455–1496`, create the future
cycle range `1501–1600`, and keep the completed dashboard direction safe without
changing economy, write flows, dependencies or CI.

## Completed

- Deprecated and neutralized orphan `AdminInteractiveBankDashboard.tsx`.
- Removed `buildSeries` / synthetic live-series generator from the orphan file.
- Added missing Sim UI Kit wrappers from plan §9.
- Added missing Admin UI Kit wrappers from plan §10.
- Froze admin domain report endpoints into future range backlog.
- Created `docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`.
- Updated Kernel, map_element, dashboard docs, test guard manifest and reports.

## Safety

- No backend write-flow changes.
- No money-flow changes.
- No dependency or lock changes.
- No CI/workflow changes.
- No Grafana or Sandbox runtime code was copied.

---

## Источник: `WORK_CYCLES_1498_CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md`

# WORK_CYCLES_1498_CI_LOG_REPAIR_PUBLIC_DASHBOARD_I18N_HARDENING.md

**Project:** EFHC Bot  
**Version:** v170.74  
**Work item:** 1498  
**Status:** DONE locally  
**Input archive:** `EFHC_Bot_v170_73_cycle_1497_dashboard_direction_audit_followup.zip`  
**Input logs:** `logs_73496341059.zip`

## Goal

Repair all factual CI log failures and keep public dashboard localization
compatible with the 13-language user-interface invariant.

## Done

- Fixed `ruff SIM102` without weakening guard logic.
- Fixed mypy assignment in `admin_observability_routes.py`.
- Removed numbered work-pass labels from non-exception filenames by renaming
  audit follow-up doc/test files.
- Removed numbered work-pass text from root `KERNEL.md`.
- Updated public dashboard locale values across active locale files.
- Confirmed dashboard i18n guards pass for manual consolidation and wave-3
  quality scripts.
- Updated Kernel, map, routes, manifests, reports and active cycle tracking.

## Boundaries

No backend write-flow, money-flow, migration, OpenAPI route set, dependency,
lock file or CI/workflow change was introduced.

## Status counters

- Overall range `1401–1500`: `98 / 100` done, `2 / 100` remaining.
- Dashboard direction `1455–1496`: closed at `42 / 42`.

---

## Источник: `WORK_CYCLES_1499_VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md`

# WORK_CYCLES_1499_VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md

**Project:** EFHC Bot  
**Version:** v170.75  
**Work item:** 1499  
**Status:** DONE locally  
**Input archive:** `EFHC_Bot_v170_74_cycle_1498_ci_log_repair_public_dashboard_i18n_hardening.zip`  
**Input logs:** `logs_73559592200.zip`

## Goal

Close VIS-03 by proving that public withdraw history does not render raw
`balance_type` enum values and preserve green CI log proof from the input line.

## Done

- Fixed the withdraw history row to compute a semantic localized balance label
  before rendering.
- Added public UI guard markers proving the balance type is semantic/localized.
- Added accessibility label for withdraw history rows.
- Added architecture guard for VIS-03.
- Fixed green log proof from `logs_73559592200.zip` into generated report.
- Updated Kernel, map, routes, manifests, reports and cycle counters.

## Boundaries

No backend write-flow, money-flow, economy, migration, OpenAPI route set,
dependency, lock file or CI/workflow change was introduced.

## Status counters

- Overall range `1401–1500`: `99 / 100` done, `1 / 100` remaining.
- Dashboard direction `1455–1496`: closed at `42 / 42`.

---

## Источник: `WORK_CYCLES_1500_FINAL_RANGE_CLOSURE.md`

# WORK_CYCLES_1500_FINAL_RANGE_CLOSURE.md

**Cycle:** `1500 — Final Range Closure / Transition to 1501–1600`  
**Input HEAD:** `EFHC_Bot_v170_75_cycle_1499_vis_03_withdraw_history_semantic_repair.zip`  
**Output HEAD:** `EFHC_Bot_v170_76_cycle_1500_final_range_closure.zip`  
**Status:** `DONE LOCALLY`

## 1. Goal

Close the `1401–1500` range at `100 / 100`, freeze the final state, and prepare
the controlled transition to the already-created `1501–1600` range.

## 2. Work performed

- Verified input ZIP integrity: `testzip = None`.
- Performed mandatory Operator Kernel preload.
- Checked AI Archive Laws lock integrity.
- Read required AI / Kernel / NORM / testing / cycle / dashboard / linkage /
  security / generated report / change report / healer documents.
- Added final closure NORM document.
- Added final closure generated report.
- Added final closure change report.
- Added active architecture guard for cycle `1500`.
- Updated Kernel, route map, cycle trackers, report index and test guard manifest.
- Refreshed Operator Kernel file map after closure files were added.

## 3. Final counters

- `1401–1500`: `100 / 100` done, `0 / 100` remaining.
- Dashboard direction `1455–1496`: `42 / 42` done, `0 / 42` remaining.
- Post-freeze cycles `1497–1499`: done.
- Next range: `1501–1600`.
- Next planned cycle: `1501 — Dashboard UI Kit Consolidation QA`.

## 4. Safety boundaries

No runtime, backend, money-flow, migration, OpenAPI route set, dependency,
lock-file, CI/workflow, wallet, TonConnect, Telegram live-client or release
audit change was made.

## 5. Non-claims

This cycle does not claim GitHub CI green, full pytest green, full frontend
build green, release-ready, browser screenshot proof, live Telegram proof or
real TonConnect / wallet proof.

## 6. Reference-only statement

Песочница использована только как reference/navigation/prototype layer. Runtime-код не переносился.

Grafana использована только как visual-pattern/reference layer. Runtime-код не переносился.
## Filename hygiene note

The final NORM document uses the hygiene-safe name `docs/NORM/FINAL_RANGE_CLOSURE.md`.
The range number remains inside the document body and in allowed cycle/report paths.
This preserves the rule that numbered cycle/range labels are not used in `docs/NORM/`
or `tests/architecture/` filenames.
