# Цикл 1608 — semantic allowlist и compatibility registry

Исходный HEAD: `EFHC_Bot_v172_04.zip`.
Целевой HEAD: `EFHC_Bot_v172_05.zip`.

## Выполнено

Создан единый machine-readable registry, различающий:

- канонический account owner `global_id`;
- физическое LEGACY-имя `users.user_id`;
- локальный primary key `id`;
- Telegram provider ID `tg_id`;
- пять разрешённых compatibility aliases;
- исторические области, не управляющие runtime;
- запрещённые новые DTO, owner/FK и provider-to-global зависимости.

Identity boundary читает active разрешения из registry. Исторический
baseline цикла 1602 сохранён и не переписан под текущий HEAD.

## Size-аудит

Исходный `v172.04` имел 5838 ZIP entries и размер около 25,6 МБ.
Распакованный `reports` занимал около 59 МБ. Причина роста:
исторические XLSX/raw identity matrices, JUnit/XML, pytest collection и
runtime logs. Код, migrations и production assets причиной не были.

Из основного архива перенесено или удалено 812 воспроизводимых файлов;
каждый путь, размер и SHA-256 сохранены в retention manifest.
Поставка переведена на три архива:

1. компактный development Current HEAD;
2. production release;
3. matrix/technical archive со всеми уникальными XLSX, текущим raw
   identity audit, JUnit/logs и подробным индексом перемещений.

## Запреты

Не выполнялись Alembic migration, historical backfill, dual-write,
shadow/read switch, financial ownership switch и изменение экономики.

## Следующий цикл

`1609 — AuthProvider и provider registry foundation`.
