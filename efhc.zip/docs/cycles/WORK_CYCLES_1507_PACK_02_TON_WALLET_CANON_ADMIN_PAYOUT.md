# 1507 — PACK-02 TON Wallet Canon / Admin Payout Canon

## Goal

Close PACK-02 by fixing wallet canonical address storage, documenting
admin payout canon and removing legacy wallet binding runtime drift.

## Completed

- Added dependency-free TON address canonicalization helper.
- Wallet connect now normalizes address to canonical storage format.
- Watcher wallet lookup canonicalizes valid TON address before lookup.
- EFHC deposit wallet fallback canonicalizes valid sender address before
  lookup.
- Deleted legacy memo/bind-request `wallet_binding_service.py` runtime
  file.
- Removed the deleted legacy service from mypy file list.
- Added wallet identity, canonical address, wallet binding, admin payout
  and DB drift docs.
- Added canonical address, single wallet binding and admin payout tests.

## Safety boundaries

- Economy changed: no.
- Withdraw PACK-01 canon changed: no.
- Backend money write-flow changed: no.
- OpenAPI changed: no.
- Migration changed: no.
- CI/workflow/lock files changed: no.
- Grafana runtime copied: no.
- Sandbox runtime copied: no.

## Next

Next safe cycle: `1508 — Payment Intent Canon`.
