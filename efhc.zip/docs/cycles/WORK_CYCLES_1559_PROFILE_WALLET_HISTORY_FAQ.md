# Work cycle 1559 — Profile, Wallet, History and FAQ

Status: `DONE LOCALLY / OUTPUT v171.34`.

## Input

- Archive: `EFHC_Bot_v171_33.zip`.
- SHA-256:
  `9b959774b20a640d6992ee755e3dece5a85bee1bf02b7abc2ce8ea2cf222323d`.
- ZIP: `testzip=None`.
- Records: `4188` (`3962` files, `226` directories).
- Forbidden artifacts: `0`.

## Completed scenarios

- Profile is a full routed page with one identity hero, one tab navigation
  and one active content surface.
- Wallet list, primary-wallet action and removal action remain connected to
  the existing backend routes.
- General balance history and withdrawal history use typed services,
  React Query infinite queries, refetch and cursor pagination.
- Human labels and safe errors remain in the public surface.
- FAQ remains a full vertical tree and is reachable from Profile.
- The language selector keeps the selected locale through the settings
  storage contour.
- The thirteen canonical locale files retain key parity.

## Visual and responsive result

- `360x800`: narrow Android profile proof.
- `390x844`: wallet and FAQ proof.
- `430x932`: general and withdrawal history proof.
- `768x1024`: tablet profile proof.
- No checked viewport has horizontal overflow.
- The duplicate account dashboard and public trust layer are retained only
  as historical sources and are no longer mounted by `/web-profile`.
- Cards, tabs, filter buttons, borders and spacing use more of the available
  smartphone width without changing unrelated public routes.

## Evidence

- Responsive browser report:
  `reports/generated/profile_wallet_history_faq_responsive_v171_34.json`.
- Thirteen-language browser report:
  `reports/generated/profile_faq_13_languages_v171_34.json`.
- Screenshots:
  `reports/screenshots/profile_wallet_history_faq_1559/`.
- Exact regression: `2399` nodes, `2271 passed`, `128 skipped`,
  `0 failed`.
- Release evidence score: `21 / 100`.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for the current responsive and language scope.

Not established:

- fresh GitHub CI;
- live Telegram client proof;
- real TonConnect proof;
- real PostgreSQL concurrency proof;
- final release audit;
- release-ready or production-ready status.
