# Cycle 1442 — OpenAPI rebuild and strict contract gate

Status: DONE locally in `v170.18` with dependency-light static proof.

## Goal

Close the active `F-006` OpenAPI drift finding from:

```text
docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md
```

and seed the contract guard layer for `F-008` without changing EFHC economy or runtime business logic.

## Root problem

The checked-in OpenAPI/route SSOT layer was not a reliable contract gate:

- some route rows were stale or used embedded `/api` prefixes inconsistently;
- hidden compatibility routes could leak into SSOT/OpenAPI;
- visible current routes such as `/tasks/my`, `/tasks/claim`, `/wallets/tonconnect/*`, `/referrals/stats/me`, `/withdraw/list/me`, admin deposit/admin shop routes and other live frontend-call surfaces were not represented consistently;
- generated frontend seam constants and direct `apiRequest(...)` calls were not checked as one contract surface.

## Repair performed

Added dependency-light rebuild tooling:

```text
ops/routes/rebuild_openapi_contract_snapshot.py
```

It parses backend route decorators without importing FastAPI/SQLAlchemy and rebuilds:

```text
docs/SSOT/ssot_pack/SSOT_ROUTES.csv
docs/SSOT/ssot_pack/SSOT_ROUTES_NUMBERED.csv
docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv
backend/openapi/openapi.json
backend/openapi/openapi_manifest.json
reports/generated/openapi_contract_snapshot_v170_18.json
```

The historical command:

```text
ops/openapi/refresh_openapi_from_ssot.py
```

now delegates to the current route-source rebuilder so future operators do not recreate the old stale SSOT-only snapshot.

Added strict dependency-light gate:

```text
ops/routes/check_openapi_strict_contract_gate.py
reports/generated/openapi_strict_contract_gate_v170_18.json
```

The gate checks:

- backend route source → OpenAPI entry;
- OpenAPI → no dead route against the SSOT route surface;
- generated frontend seam constants → OpenAPI;
- direct frontend `apiRequest(...)` calls → backend route;
- direct frontend `apiRequest(...)` calls → OpenAPI;
- admin OpenAPI operations are marked as admin routes;
- monetary routes do not expose `internal_tx`, `efhc_mint_burn` or `efhc_admin.bank_balances`.

## Important boundary

Live FastAPI `app.openapi()` export was attempted through:

```text
ops/routes/export_runtime_openapi.py
```

but the local tool environment lacks runtime dependency `sqlalchemy`.

Therefore this cycle does **not** claim live runtime OpenAPI proof. The checked-in snapshot is rebuilt from backend route source and guarded statically. Live app import proof remains for CI/full environment.

## OpenAPI result

Current checked-in snapshot:

```text
backend/openapi/openapi.json
mode = backend-route-source-derived-snapshot
cycle = 1442
paths = 116
operations = 121
```

Manifest:

```text
backend/openapi/openapi_manifest.json
runtime_live_export = not_claimed_in_this_environment
```

## Guards / tests

Added active guard file:

```text
tests/architecture/test_openapi_rebuild_strict_contract_gate.py
```

Protected invariants:

- `test_openapi_snapshot_was_rebuilt_for_cycle_1442`
- `test_rebuilder_route_count_matches_checked_in_openapi`
- `test_all_backend_routes_have_openapi_entry`
- `test_openapi_has_no_dead_routes`
- `test_all_frontend_api_calls_have_backend_route`
- `test_route_schema_contract_frontend_backend_match`
- `test_admin_routes_are_marked_admin_or_guarded`
- `test_money_routes_do_not_expose_internal_fields`
- `test_openapi_strict_gate_report_is_green`

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_openapi_rebuild_strict_contract_gate.py -q
# 9 passed
```

Related linkage/OpenAPI guard pack passed locally:

```text
python -m pytest \
  tests/architecture/test_openapi_rebuild_strict_contract_gate.py \
  tests/architecture/test_openapi_startup_consistency.py \
  tests/architecture/test_admin_hub_route_prefix_repair.py \
  tests/architecture/test_admin_reports_bank_ssot_repair.py \
  tests/architecture/test_admin_wallet_reset_semantic_repair.py \
  tests/architecture/test_deposit_watcher_wallet_ssot_repair.py \
  tests/architecture/test_admin_bank_ssot_repair.py \
  tests/architecture/test_energy_polish_guard.py -q
# 47 passed
```

## Scope boundaries

No EFHC economy change.
No backend money logic change.
No migration change.
No CI/workflow/lock-file change.
No test deletion, archival, skip or xfail.
No direct runtime transfer from Песочница.

Песочница used only as reference/navigation layer.

## Remaining blockers

`F-006` is repaired locally for the checked-in dependency-light OpenAPI/contract layer, but still requires repeat linkage audit and live/full dependency proof before any release-ready claim.

Remaining next cycle:

```text
1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards
```

Known open tails:

- `F-007`: loading/error/empty state guards for critical UI API calls.
- `F-008`: static frontend API call → backend route guard is seeded here, but full architecture matrix/reporting remains scheduled for cycle 1443.
- Repeat linkage audit and HEALER tail reconciliation remain scheduled for `1444`.
