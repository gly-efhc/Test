# Cycle 1537 — Referral Persistence / Telegram Webhook DB DI Repair

## Input

- HEAD: `EFHC_Bot_v171_11_cycle_1536_fresh_ci_referral_log_repair.zip`
- Audit: `docs/audits/a_v171_11.md`
- TZ: `docs/audits/tz_v171_11.md`

## Closed locally

- Referral attach now commits successful inserts and rolls back exceptions.
- Telegram webhook uses `process_update(db=db, payload=payload)`.
- Route persistence proof now executes route functions with transactional
  fake DB instead of source-only inspection.
- Exchange mutation uses operation-specific public fallback.
- WebApp bind session flag is retryable after request failure.

## Checks

- Targeted referral/webhook/frontend guards passed locally.
- `compileall` passed locally.
- Full CI, live Telegram and real TonConnect proof are not claimed.
