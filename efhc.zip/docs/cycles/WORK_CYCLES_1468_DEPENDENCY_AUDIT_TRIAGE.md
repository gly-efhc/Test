# 1468 — Dependency Audit Triage / v170.44

Status: `DONE_LOCALLY`

## Goal

Repair supplied CI-log failures and close npm dependency audit findings before the Energy Dashboard Runtime Port.

## Input

- HEAD: `EFHC_Bot_v170_43_cycle_1467_energy_dashboard_sandbox_prototype.zip`.
- Logs: `logs_72723974684.zip`.
- User decision: create separate cycle `1468 — Dependency Audit Triage` and shift following dashboard cycles.

## Done

- Read supplied logs first.
- Identified pytest root causes:
  - missing Kernel legacy marker `v170.27 / CI log repair`;
  - forbidden transient artifact `frontend/tsconfig.tsbuildinfo`.
- Restored Kernel compatibility marker.
- Removed `frontend/tsconfig.tsbuildinfo` from release tree.
- Ran npm audit triage.
- Updated controlled dependency boundaries in `frontend/package.json` and `frontend/package-lock.json`.
- Added dependency audit docs and guard.
- Shifted dashboard cycle plan forward by one step.

## Dependency result

```text
npm audit --json: 0 vulnerabilities
```

## Safety boundary

No EFHC economics, backend runtime, database migration, OpenAPI contract, admin write flow, CI workflow, Grafana runtime code or Песочница runtime code was changed.

## Next

`1469 — Energy Dashboard Runtime Port`.


## Artifact cleanup hardening

`ops/cleanup_artifacts.py` now removes nested frontend `node_modules`, `.next`, `.turbo` and `out` artifacts before local guard runs and packaging.
