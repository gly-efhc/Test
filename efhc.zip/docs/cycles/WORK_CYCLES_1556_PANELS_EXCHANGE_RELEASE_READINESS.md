# Cycle 1556 — Panels, Exchange and release-readiness route

Status: `DONE LOCALLY / OUTPUT v171.31`.

## Input

- Archive: `EFHC_Bot_v171_30.zip`.
- SHA-256:
  `7ffd094d3bdcf8b1b71a8458ec642e60b917dd22751677941a5a47b0e174cd4e`.
- ZIP: `testzip=None`.
- Records: `4134` (`3911` files, `223` directories).
- Forbidden artifacts: `0`.
- AI Archive Laws integrity: passed before changes.

## Completed scenarios

### Panels

`/panels -> usePanelActivation -> panels service -> Zod DTO ->
POST /api/panels/activate -> PanelsService.activate_panel -> DB boundary ->
query invalidation -> visible new panel`.

The page now uses React Query for list, summary and activation. Responses are
validated before they reach the view. Activation preserves the idempotency
key, invalidates dependent state and displays the new panel after refetch.

### Exchange

`/exchange -> useExchangePreview/useExchangeConvert -> exchange service ->
Zod DTO -> POST /api/exchange/convert -> ExchangeService -> DB boundary ->
query invalidation -> visible balance refresh`.

The page no longer maintains a parallel manual preview state. A conversion of
`10 kWh` sends `10.00000000`, preserves idempotency and changes the visible
available amount from `100` to `90` after refetch.

## Browser interaction evidence

Both scenarios passed in a real Chromium session at `390x844` through the
policy-compatible local proof harness:

- `reports/generated/panels_activation_interaction_proof_v171_31.json`;
- `reports/generated/exchange_convert_interaction_proof_v171_31.json`;
- `reports/screenshots/panels_exchange_1556/`.

The proofs require a non-blank body, hidden splash, no horizontal overflow,
real mutation request, idempotency header and visible post-mutation state.

## Transaction boundary

Local unit proof confirms that route adapters preserve the idempotency key and
normalized amount when entering the atomic business-service boundary.

A real PostgreSQL runtime is not available on the operator host. Therefore
PostgreSQL transaction, locking and concurrency proof remains fail-closed and
is assigned to cycle 1566 and fresh CI.

## Release-readiness master plan

Created:

- `docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`;
- `reports/generated/mvp_release_readiness_master_plan_v171_31.json`;
- `ops/release/mvp_release_readiness_master_gate.py`;
- `tests/architecture/test_mvp_release_readiness_master_plan.py`.

The plan contains twelve domains and exactly 100 evidence points. A 99-percent
release candidate requires at least 99 verified points, all critical points,
fresh CI, live Telegram proof and a real signed TonConnect transaction.

The baseline evidence score is deliberately fail-closed. It is not an estimate
of implemented source-code volume.

## Closed findings

- `C1556-PANELS-REACT-QUERY-LINKAGE`.
- `C1556-EXCHANGE-PAGE-HOOK-BYPASS`.
- `C1556-ECONOMIC-SEAM-GENERATOR-DRIFT`.
- `C1556-DUPLICATE-PANELS-EXCHANGE-SURFACES`.
- `C1556-PANELS-EXCHANGE-BROWSER-INTERACTION-PROOF`.
- `C1556-NEXT-BUILD-PROCESS-BOUNDARY`.
- `C1556-RELEASE-READINESS-MASTER-PLAN`.

## Open evidence findings

- `C1556-POSTGRES-TRANSACTION-PROOF-ENV`: no local PostgreSQL runtime.

## Frontend production build

The standard build command performs a blocking TypeScript check before the
official Next webpack build and verifies required route artifacts. Two
consecutive clean `npm run build` executions exited naturally with code zero.
Each generated all thirty-four Next routes.

## Full regression

One `pytest --collect-only` inventory contained `2379` unique node IDs.
All nodes ran in 24 deterministic batches:

- `2255 passed`;
- `124 skipped` by existing environment gates;
- `0 failed`;
- `0` omitted collected nodes;
- `0` new skips or xfails;
- `0` deleted tests.

The architecture collection separately passed with `2088 passed`,
`7 skipped` and `0 failed`.

## Protected canon

No change was made to:

- `1 EFHC = 1 kWh`;
- panel price `100 EFHC`;
- bonus-first/main-second spending;
- generation or balance formulas;
- idempotency;
- auth or Telegram InitData verification;
- DB schema or Alembic `0001 only`;
- protected routes or navigation.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for `/panels` and `/exchange` only.

Not established:

- real PostgreSQL transaction proof;
- fresh GitHub CI for `v171.31`;
- live Telegram proof;
- real TonConnect proof;
- release-ready or production-ready status.
