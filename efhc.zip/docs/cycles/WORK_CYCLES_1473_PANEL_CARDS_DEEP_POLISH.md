# WORK_CYCLES_1473_PANEL_CARDS_DEEP_POLISH.md

**Cycle:** `1473 — Panel Cards Deep Polish`  
**Archive:** `v170.49`  
**Status:** DONE_LOCAL  
**Mode:** UI-only / runtime display / sandbox formula hardening

## Goal

Polish panel cards after Panels Portfolio Runtime Port.
Also apply the user recommendation: synthetic preview numbers must be
internally consistent.

## Completed

- Added runtime panel-card micro-state model.
- Added `expiring_soon`, `newly_active`, `active_cycle`,
  `archived_complete` card states.
- Added accessibility card labels.
- Added explicit kWh and kWh/s display units.
- Formatted runtime card UTC dates.
- Removed duplicate archive lifecycle progress.
- Hardened sandbox formula consistency.
- Removed old hardcoded preview generation rates.
- Added all 13 locale keys for panel-card polish.
- Updated docs, Kernel, map, reports and guards.

## Boundaries

- Economy changed: no.
- Backend changed: no.
- DB migrations changed: no.
- OpenAPI changed: no.
- Dependencies or lock files changed: no.
- Write or money flow changed: no.
- Grafana runtime code copied: no.
- Песочница runtime code copied: no.

## Next safe cycle

`1474 — Ranks Dashboard Sandbox Prototype`
