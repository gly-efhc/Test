# Рабочий цикл 1612 — transactional IdentityResolver

Версия: `v172.11`.

Статус:

```text
CYCLE_1611_EXACT_HEAD_PASS
CYCLE_1612_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## 1. Основание начала цикла

Канонический GitHub CI run `82850316409` выполнен на exact HEAD
`EFHC_Bot_v172_10.zip` размером `11 586 325` байт. Все gates прошли:
PostgreSQL preflight, Alembic `0001 → 0002 → 0003`, Ruff, Mypy,
Bandit, compileall, flake8, pytest и frontend build. Pytest:
`2918 passed`, `20 skipped`, `0 failed`, `0 errors`, `1 warning`.

Это закрывает цикл `1611` и разрешает начало цикла `1612`.

## 2. Цель

Реализовать provider-neutral transactional `IdentityResolver`, который
по уже проверенному `VerifiedIdentity` выполняет только lookup связи

```text
(provider, provider_tenant, provider_subject) → global_id
```

и возвращает один из outcomes:

```text
resolved
not_found
conflict
```

Resolver не создаёт account, identity, session или role, не назначает
`global_id`, не выполняет auto-merge и не меняет финансовые данные.

## 3. Реализованный lock protocol

1. Public method открывает собственную `AsyncSession` и транзакцию.
2. Для lookup-key вычисляется стабильный signed BIGINT через BLAKE2b.
3. Выполняется `pg_advisory_xact_lock`, поэтому сериализуется и случай,
   когда строки identity ещё нет.
4. Существующая строка читается через `SELECT ... FOR UPDATE`.
5. Внешний атомарный flow может вызвать `resolve_in_transaction` только
   внутри уже начатой транзакции; resolver не делает commit этой
   транзакции.
6. Raw provider subject не включается в lock key, diagnostics или repr.

## 4. Fail-closed conflicts

Machine-readable conflict codes:

- `multiple_matches`;
- `identity_inactive`;
- `identity_unverified`;
- `invalid_global_id`;
- `provider_not_storable`;
- `subject_not_storable`;
- `storage_conflict`.

При conflict `global_id` всегда равен `None`. Resolver никогда не выбирает
одну из конфликтующих записей и не объединяет аккаунты автоматически.

## 5. PostgreSQL test package

Добавлены реальные PostgreSQL tests:

- existing identity → тот же `global_id` без mutations;
- missing identity → `not_found` без создания user/identity;
- disabled/revoked/unverified → fail-closed conflict;
- шесть concurrent resolves → один детерминированный результат;
- advisory lock действительно блокирует missing-row lookup;
- `resolve_in_transaction` не коммитит caller transaction.

Локально PostgreSQL не запускается. Integration module успешно
собирает `8` PostgreSQL tests. Причинные unit/architecture/retention и
release-contract наборы дали `200 unique passed`. Реальное выполнение этих
PostgreSQL tests и полная static qualification остаются существующему
каноническому GitHub CI на exact HEAD `v172.11`.

## 6. Неизменяемые границы

- Alembic head остаётся `0003`;
- migration `0004` не создаётся;
- DDL и constraints `0003` не меняются;
- runtime routes и legacy `app.deps.AuthContext` не переключаются;
- account/session/challenge/role storage относится к циклу `1613`;
- TON Proof и Telegram adapter не реализуются;
- balances, kWh, panels и financial ownership не меняются;
- CI workflow остаются побайтно неизменными.

## 7. Exit gate

Цикл `1612` закрывается только после fresh exact-HEAD CI, который
подтверждает:

```text
Concurrent resolve детерминирован.
Conflict fail closed.
0 critical failures.
```

До этого цикл `1613` не начинается.
