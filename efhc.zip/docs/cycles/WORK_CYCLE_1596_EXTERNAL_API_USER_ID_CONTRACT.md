# WORK CYCLE 1596 — External API/Pydantic UserId contract

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.
Source HEAD: `EFHC_Bot_v171_92.zip`.
Target HEAD: `EFHC_Bot_v171_93.zip`.
Exact route: `user_id_api_contract`.
Fallback: `false`.

## Purpose

Prepare a strict provider-independent API contract without changing
active API payloads, ORM schema, AuthContext or domain ownership.

## Implemented contract

```text
ApiExternalUserId
PydanticUserId
UserIdRequest
UserIdResponse
```

The contract accepts exactly ten ASCII digits, rejects numeric coercion,
zero, Unicode digits, TelegramId and provider/wallet values, stores a
nominal UserId and emits a string with leading zeroes preserved.

## OpenAPI boundary

Future OpenAPI uses:

```text
type: string
format: efhc-user-id
pattern: ^[0-9]{10}$
minLength: 10
maxLength: 10
```

No integer alternative is allowed.

## Runtime boundary

No active route, existing DTO, ORM model, Alembic revision, SQL owner,
AuthContext, frontend owner or financial value changes in cycle 1596.

## Rollback

Restore exact v171.92 development and release archives. No Alembic
downgrade or PostgreSQL restore is required because no data/schema
change exists.

## Next cycle

`1597 — users.user_id expand migration design and PostgreSQL dry-run`.

## Final local evidence

```text
2781 collected
2609 passed
172 skipped
0 failed
0 errors
34 targeted API/Healer tests passed
25 PostgreSQL integration tests collected but not executed
```

Reconciliation is `NOT_RUN_DB_UNAVAILABLE`. Fresh exact-HEAD GitHub CI,
frontend build, real Chromium and live deployment proof remain open.
