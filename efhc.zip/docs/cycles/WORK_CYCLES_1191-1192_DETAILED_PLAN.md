# WORK CYCLES 1191-1192 DETAILED PLAN

## Purpose

These cycles close the next two road-audit findings without stretching
one defect class across unnecessary extra cycles.

The goal is not to add reports.  The goal is to repair the road from
entrypoint to service, table mutation, status, user or operator surface
and audit proof.

## Cycle 1191: shop and payment truth repair

Scope:
- Browser-Shop and in-app Shop external order road.
- Payment intent creation and status surface.
- Watcher/reconciliation link to shop order.
- User-visible flow truth for paid, pending, manual and error states.

Required fixes:
- Do not return a successful order payload when order or payment data is
  incomplete.
- Do not return success when the external order id is missing.
- Keep payment intent ownership tied to the authenticated global_id.
- Store intent payload, intent id and payment owner in shop order extra.
- Status endpoint must return 404 for missing or non-owned intents.
- Internal service markers such as `ok` must not enter the public
  schema.

Evidence:
- `ops/routes/check_shop_payment_truth.py`.
- `reports/generated/shop_payment_truth_1191.json`.
- `tests/architecture/test_shop_payment_truth_guard.py`.

## Cycle 1192: admin bank action repair

Scope:
- Admin transfer road.
- Admin bank mint road.
- Admin bank burn road.
- Ledger and bank proof returned to the operator surface.

Required fixes:
- Admin money roads must use `global_id`, not internal `users.id`.
- Mint and burn must resolve the admin through RBAC by global_id.
- Mint and burn must pass an admin object to the bank service.
- Mint and burn must commit before returning success.
- Mint and burn must return `current_balance`, not a missing attribute.
- Manual transfer must expose the actual bank main balance from
  TxResult.

Evidence:
- `ops/routes/check_admin_bank_road.py`.
- `reports/generated/admin_bank_road_1192.json`.
- `tests/architecture/test_admin_bank_road_guard.py`.
