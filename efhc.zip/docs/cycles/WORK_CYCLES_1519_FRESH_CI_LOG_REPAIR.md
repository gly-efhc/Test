# 1519 — Fresh CI proof / red-log repair

Status: `DONE_LOCALLY_RED_LOG_REPAIRED`

Input archive: `EFHC_Bot_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.zip`

Output archive: `EFHC_Bot_v170_95_cycle_1519_fresh_ci_log_repair.zip`

Input log: `logs_74249190312.zip`.

## What the log showed

The fresh CI log was red.

Green in the input log:

- flake8 critical;
- flake8 full report;
- ruff;
- mypy;
- bandit;
- compileall backend;
- Alembic upgrade head;
- PSQL pre-check.

Failed in the input log:

- pytest: 9 failed;
- frontend gate: forbidden internal registry marker in package lock.

## Repairs

- Removed internal registry marker from `frontend/package-lock.json`.
- Updated stale ORM table count docs from 43 to 44.
- Removed legacy `bonus_awards` guard from normal withdraw list/approve flow.
- Kept `bonus_awards` guard only around legacy bonus-award code paths.
- Reformatted new browser proof code and touched frontend line to satisfy the
  72-character source line guard.
- Removed generation-rate literals from browser proof mock data.
- Restored the Kernel navigation markers while removing numbered work-pass
  labels from root `KERNEL.md`.
- Added architecture guard for this log repair.

## Proof boundary

This is a local red-log repair. GitHub CI green for the output archive is not
claimed until the output archive is rerun by CI.

## Next safe work item

Fresh CI rerun for the output archive, or intake of the next audit package.
