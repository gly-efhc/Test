# WORK_CYCLES_1487_ADMIN_PANELS_DASHBOARD_UPGRADE

**Cycle:** 1487 — Admin Panels Dashboard Upgrade  
**Archive:** v170.63  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin/panels` into a Grafana-like read-only dashboard for panel
lifecycle control, without changing the existing guarded activation and
deactivation flow.

## Result

Added:

```text
frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/panels.tsx
```

The dashboard shows active/archive distribution, expiring-soon markers,
missing-expiry attention markers, 180-day lifecycle progress, generated
kWh totals, base generation-rate audit totals, age buckets, recent safe
panel snapshot and the canonical operator order.

## Side repair

Closed the user-reported deposits dashboard UX debt: `pending_intents` is
now represented as a third read-only progress bar in the 1485 Automation
readiness panel, so `Automation credited + Exception backlog + Pending
intents` covers the shared `observedTotal` denominator.

## Boundaries

No backend, DB, OpenAPI, dependency, lock-file, CI/workflow, economy,
generation-rate, panel lifecycle or money/write-flow change.

Panel activate/deactivate actions stay in the existing guarded controls.

## Checks

Local targeted checks passed. GitHub CI green, full pytest green, full
frontend build green, release-ready, browser screenshots, live Telegram
proof and real wallet proof are not claimed.

## Next

Next safe cycle:

```text
1488 — Admin Tasks / Referrals Dashboard Upgrade
```
