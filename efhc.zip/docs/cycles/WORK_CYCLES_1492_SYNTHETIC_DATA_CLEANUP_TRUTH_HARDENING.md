# WORK_CYCLES_1492_SYNTHETIC_DATA_CLEANUP_TRUTH_HARDENING.md

**Цикл:** 1492 — Synthetic Data Cleanup / Truth Hardening  
**Версия:** v170.68  
**HEAD input:** `EFHC_Bot_v170_67_cycle_1491_real_time_series_backend_contracts.zip`  
**Output:** `EFHC_Bot_v170_68_cycle_1492_synthetic_data_cleanup_truth_hardening.zip`  
**Статус:** DONE LOCALLY

## Цель

После появления real backend time-series contracts убрать runtime surfaces,
которые строили fake/synthetic history из snapshot, и укрепить различение
`real_timeseries`, `derived snapshot` и `synthetic_preview`.

## Выполнено

- `/admin` переведён со старого `AdminInteractiveBankDashboard` на
  `AdminObservabilityTimeseriesDashboardRuntime`.
- Runtime dashboard теперь использует `GET /admin/observability/summary` и
  `GET /admin/observability/timeseries`.
- `_route_for_reason` получил точный referral match вместо широкого `ref`.
- `efhc_transfer_amount` явно закреплён как `EFHC gross turnover`.
- Добавлены `efhc_credit_amount` и `efhc_debit_amount`.
- Frontend seams обновлены для новых metric literals.
- OpenAPI/SSOT route snapshot пересобран статическим gate.
- Docs, reports, Kernel, map_element и test manifest обновлены.

## Запреты, которые сохранены

- No synthetic runtime series.
- No fake trend from one snapshot.
- No write-flow bypass.
- No idempotency key creation in dashboard.
- No raw payload/debug JSON/secrets display.
- No Grafana runtime code copy.
- No sandbox runtime code copy.
- No economy change.

## Следующий цикл

`1493 — Visual Performance / Bundle Safety`.
