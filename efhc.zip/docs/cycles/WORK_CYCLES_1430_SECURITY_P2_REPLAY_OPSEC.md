# Work cycle 1430 — security P2 replay / OPSEC / legacy headers repair

## Status

DONE locally.

## HEAD input

`EFHC_Bot_v170_04_cycle_1429_p0_security_repair.zip`

## Audit input

`docs/audits/P0_SECURITY_AUDIT_V170_01.md`

The active security audit listed three P2 findings after the P0 blockers:

- `P2-01` — Telegram initData did not fail closed on missing or malformed
  `auth_date`;
- `P2-02` — secrets redactor did not cover all production secret aliases;
- `P2-03` — frontend / compat layers still emitted or allowed legacy
  identity/admin headers.

## Scope of this cycle

This cycle repairs only P2 replay/OPSEC/legacy-header findings. It does not
change EFHC economics, wallet proof logic from cycle 1429, CI workflow files,
lock files, AI Archive Laws or production deployment topology.

## Repairs

### Telegram initData freshness

`backend/app/core/security_core.py` now treats `auth_date` as mandatory.
Missing or non-numeric `auth_date` fails closed with 401 before user identity is
accepted.

Added unit coverage in `tests/efhc_backend/unit/test_telegram_init_data.py`:

- missing `auth_date` fails;
- non-numeric `auth_date` fails;
- expired `auth_date` remains rejected.

### Secrets redaction

`backend/app/core/logging_core.py` redaction aliases now cover production
control-plane and provider secrets:

- `BOT_TOKEN` / `TELEGRAM_BOT_TOKEN`;
- `SECRET_KEY`;
- `ADMIN_API_KEY`;
- `TELEGRAM_WEBHOOK_SECRET` / `WEBHOOK_SECRET`;
- `CRON_SECRET` / `SCHED_CRON_SECRET`;
- `TON_API_KEY` / TonCenter aliases;
- database and Supabase aliases.

The redactor also masks assignment-style log fragments such as
`CRON_SECRET=value` and `ADMIN_API_KEY:value`.

### Legacy frontend/admin headers

`frontend/src/lib/api.ts` now sends only `X-Telegram-Init-Data` as the client
Telegram identity source. It no longer falls back to `initDataUnsafe.user.id`,
`X-Telegram-User-Id`, localStorage admin id, `X-Admin-Id` or `X-Admin-Token`.

The admin landing page no longer stores or reads `EFHC_ADMIN_ID` /
`EFHC_ADMIN_TOKEN` and now describes admin access as backend-enforced through
Telegram initData / `require_admin`.

The CORS allow-header lists in both `backend/app/main.py` and the compatibility
entrypoint `backend/app/__init__.py` no longer include legacy identity/admin
headers.

## New active guard

`tests/architecture/test_security_p2_replay_opsec_headers.py`

Protected invariants:

- Telegram initData requires strict `auth_date` freshness;
- redactor covers production secret aliases;
- frontend runtime does not emit legacy auth/admin headers;
- backend CORS compatibility layers do not allow legacy auth/admin headers;
- this cycle's documents exist.

## Sandbox reference use

`map_element.md` and the uploaded sandbox archives were used only as
reference/navigation context for Telegram Mini App auth surface and wallet/admin
boundary discipline. No Vue/Solid/Nuxt/Vanilla runtime, lock file, CI file,
wallet/payment logic, economics, secrets/configs or translations were imported.

## Non-claims

This local cycle does not claim:

- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect / wallet proof.

## Next cycle

`1431 — security regression hardening + repeat audit preparation`.
