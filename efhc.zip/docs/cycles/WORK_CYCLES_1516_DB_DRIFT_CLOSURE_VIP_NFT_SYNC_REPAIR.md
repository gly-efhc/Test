# 1516 — DB Drift Closure / VIP-NFT TonConnect Sync Repair / Legacy Table Cleanup

Status: `DONE_LOCALLY`

Archive input: `EFHC_Bot_v170_91_cycle_1515_fresh_ci_rerun_visual_prep.zip`

Expected archive output: `EFHC_Bot_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.zip`

## Why this cycle exists

User clarified that the DB drift closure audit-fix task must be performed as current cycle `1516`. The previously created `1515` archive remains a local fresh-CI/visual-prep audit/preparation cycle, not the DB drift closure cycle.

## Closed / updated

- Closed `P1-VIP-NFT-SYNC-BROKEN-FOR-TONCONNECT-USERS` locally.
- `NftCheckService.get_wallet_for_user()` resolves active `wallet_bindings` first.
- `users.ton_wallet` remains legacy fallback only.
- `/v1/me` no longer gates stale VIP refresh by `users.ton_wallet`.
- Batch NFT/VIP discovery includes active `wallet_bindings` users and legacy fallback users without duplicates.
- `bonus_awards` is documented as legacy/dead code and guarded/no-op or fail-closed.
- `WithdrawRequest.amount` precision is now `Numeric(30,8)`.
- Existing-schema repair for old `withdraw_requests.amount` precision is added to `0001_init.py`.
- Deprecated `withdrawals` constraint name drift is documented as legacy cosmetic drift.

## New / changed docs

- `docs/NORM/DB_DRIFT_CLOSURE_REPORT.md`
- `docs/NORM/VIP_NFT_TONCONNECT_SYNC_CANON.md`
- `docs/NORM/BONUS_AWARDS_LEGACY_STATUS.md`
- `docs/NORM/WALLETS_TONCONNECT_SSOT.md`
- `docs/NORM/DB_DRIFT_MATRIX.md`

## New guards

- `tests/efhc_backend/nft/test_vip_nft_tonconnect_wallet_binding_sync.py`
- `tests/architecture/test_db_drift_matrix.py`

## Proof boundary

Do not claim:

- GitHub CI green;
- full pytest green unless a full run finishes with green verdict;
- browser screenshots;
- full button-click proof;
- release-ready;
- live Telegram proof;
- real TonConnect/wallet proof.

## Range status

After this cycle:

- `1501–1600`: done `16 / 100`;
- remaining: `84 / 100`;
- next safe cycle: `1517 — Frontend Buttons / API / i18n Drift Audit`.
