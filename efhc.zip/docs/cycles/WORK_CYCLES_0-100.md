# WORK CYCLES 0-100

Диапазон циклов: 0-100.
Источник: segmented canonical cycle series.

## Циклы 1–20 — decommission lotteries-domain

| № | Статус | Краткий результат |
|---|---|---|
| 1 | done | Baseline audit и карта удаления lotteries-domain. |
| 2 | done | Аудит import/export, router coupling, app registration и entry points. |
| 3 | done | Удалены frontend entry points и навигация на `/lotteries`. |
| 4 | done | Удалены runtime locale keys и FAQ bindings раздела 14. |
| 5 | done | Удалена frontend page `frontend/src/pages/lotteries.tsx` и client calls. |
| 6 | done | Удалены bot-visible handlers lotteries. |
| 7 | done | Удалён public API router lotteries. |
| 8 | done | Удалены admin lotteries routes и facade exposure. |
| 9 | done | Удалены lotteries schemas и contracts. |
| 10 | done | Удалён lotteries service layer. |
| 11 | done | Удалён lotteries CRUD layer. |
| 12 | done | Удалены lotteries ORM models и exports. |
| 13 | done | Удалены lotteries-specific tests и fixtures. |
| 14 | done | Удалён lotteries env/config surface. |
| 15 | done | Удалены lotteries-only guards/checks и scheduler tail. |
| 16 | done | Пересобран docs layer без lotteries-domain. |
| 17 | done | Пересобраны SSOT route/table/model maps без lotteries. |
| 18 | done | Зафиксирована политика historical DB/migration traces. |
| 19 | done | Финальный residual audit active tree: active trace lotteries снят. |
| 20 | done | Финальная верификация и закрытие Healer-case. |

Источник подробной истории: `docs/LOTTERIES_DECOMMISSION_CYCLES.md`.

## Циклы 21–30 — кодовая чистка, исправления, усовершенствование

| № | Статус | Цель | Результат |
|---|---|---|---|
| 21 | done | Инвентаризация runtime drift между SSOT, frontend runtime, docs и tests. | Создан unified cycle register 1–40, составлен `docs/audits/RUNTIME_DRIFT_INVENTORY.md`, зафиксированы mismatch-классы и точки проверки. |
| 22 | done | FAQ/runtime sync hardening. | Добавлены детерминированный генератор `ops/scripts/generate_faq_catalogs_from_ssot.py`, exact-match guard и пересборка `frontend/src/data/faq/catalogs.ts` из `docs/SSOT/faq_ssot/*/faq_*.json`. |
| 23 | done | Route surface cleanup. | Убран embedded `/api` из local route prefixes/paths; добавлен guard `test_route_prefixes_no_embedded_api.py`. |
| 24 | done | Admin route consolidation. | Приведены admin prefixes/tags к канону; добавлен guard `test_admin_route_modules_canon.py`. |
| 25 | done | Check `me` / `user` overlap. | Зафиксированы роли `/api/v1/me`, `/user/me`, `/user/{tg_id}/me`; устранён docs drift; добавлен guard `test_me_user_route_overlap_canon.py`. |
| 26 | done | Finance route canon audit. | Исправлены подтверждённые ошибки из CI-логов: tasks route imports, finance canon guard для shop helper, docs/test catalog counts, repo manifest allowlist после lotteries decommission, Healer JSON structure, терминологический ban-token из TERMS_GLOSSARY, удалены 5 active FAQ residual-tail ответов во FR/PL и пересобран frontend FAQ runtime. |
| 27 | done | Route → service → table sync audit. | Подтверждён docs drift по route counts (82 vs stale 91/92), синхронизированы active SSOT docs и добавлен guard `test_ssot_route_count_docs_sync.py`. |
| 28 | done | OpenAPI/startup consistency. | Подтверждён startup/OpenAPI drift: `api/index.py` не экспортировал `app`, а `backend/openapi/openapi.json` содержал только 2 stale path; Vercel entry восстановлен, OpenAPI пересобран по SSOT route surface и добавлен guard `test_openapi_startup_consistency.py`. |
| 29 | done | Docs/SSOT sync hardening wave 2. | Исправлены ошибки из свежих CI-логов: docs counts/test catalog drift, Healer JSON shape drift, canon terminology drift и ruff SIM102; добавлен FAQ backlog plan. |
| 30 | done | Final regression pack for code series. | Выполнен обязательный пакет регрессионных проверок серии 21–30; удалён активный запретный FAQ-хвост из EN SSOT/runtime, усилен FAQ guard и создан реестр вопросов-ответов. |

## Циклы 31–40 — маршруты, миграции, route/service/table sync

| № | Статус | Цель | Результат |
|---|---|---|---|
| 31 | done | Route inventory freeze. | Добавлен freeze-реестр `SSOT_ROUTE_INVENTORY_FREEZE.csv` и markdown inventory на 82 route entries; service refs извлечены из evidence, добавлен guard `test_route_inventory_freeze_sync.py`. |
| 32 | done | Route naming cleanup wave. | Нормализованы route naming/prefix values в freeze inventory и добавлен guard `test_route_inventory_naming_canon.py`. |
| 33 | done | Idempotency surface audit. | Исправлена слабая route idempotency проверка, синхронизированы policy regex с фактическими active routes, добавлены SSOT idempotency surface CSV/markdown и docs-sync guard. |
| 34 | done | Route response/error canon audit. | Зарегистрирован `HTTPException` handler, добавлен guard на object-detail canon, выровнены route error payloads и docs counts. |
| 35 | done | Migration `0001` vs ORM/SSOT audit. | Подтверждена производность `0001_init.py` от ORM/SSOT, migration docs синхронизированы, добавлен guard `test_migration_0001_orm_ssot_sync.py`. |
| 36 | done | Migration invariants hardening. | Убраны alias-термины из migration plan, закреплены current invariants 32 tables / 2 schemas / ORM-only 0001 и добавлен guard `test_migration_invariants_hardening.py`. |
| 37 | done | DB diagnostics/docs sync. | Синхронизированы DIAGNOSTIC_DB_INVENTORY, SSOT_DB_SCHEMAS_TABLES и DB_SCHEMA с SSOT_TABLES_ORM; добавлен guard `test_db_diagnostics_docs_sync.py`. |
| 38 | done | OpenAPI/docs route matrix sync. | Подтверждён drift в `MODEL_TABLE_ROUTE_TEST_MAP.md`: stale counts, отсутствующий dedicated guard и ссылка на несуществующий `backend/app/models/exchange_routes.py`; route matrix синхронизирован с SSOT/OpenAPI, добавлен guard `test_openapi_docs_route_matrix_sync.py`. |
| 39 | done | Release artifact hygiene wave 2. | Исключены runtime log-артефакты из release ZIP (`.local_artifacts/`, `logs/`, `*.log`), добавлены guard и release hygiene doc, пересобраны counts/docs. |
| 40 | done | Final regression pack for route/migration series. | Прогнан финальный пакет route/migration guards; устранён docs-count drift в MODEL_TABLE_ROUTE_TEST_MAP, синхронизированы журналы и зафиксировано закрытие серии 31–40. |


## Последнее обновление

- Цикл 126 завершён: по прямому аудиту обнаружен latent docs drift — русский FAQ SSOT `docs/SSOT/faq_ssot/ru/faq_ru.*` уже был в каноне активации панели, но `docs/SSOT/PANELS_SSOT.md` и `docs/SSOT/FAQ_SSOT.md` ещё держали stale формулировки `купить панель`, `цена панели`, `после покупки первой панели`; docs sync выполнен, архив подготовлен как v161_01.
- Цикл 24 завершён: нормализованы admin route prefixes/tags, добавлен guard `test_admin_route_modules_canon.py`, синхронизированы docs counts и TESTS_CATALOG, архив серии переведён на v158_01.
- Цикл 25 завершён: self-profile surface зафиксирован, stale `/api/user/profile` удалён из docs, добавлен guard `test_me_user_route_overlap_canon.py`, архив подготовлен как v158_02.
- Цикл 26 завершён: закрыты подтверждённые ошибки из CI-логов, очищен active FAQ residual-tail во FR/PL, пересобран runtime FAQ, архив подготовлен как v158_03.
- Цикл 27 завершён: route/service/table docs drift по counts устранён, active SSOT docs синхронизированы с 82 маршрутами, добавлен guard `test_ssot_route_count_docs_sync.py`.

- Цикл 28 завершён: восстановлен serverless entry `api/index.py`, exported OpenAPI синхронизирован с 82 SSOT routes, добавлен guard `test_openapi_startup_consistency.py`, архив подготовлен как v158_05.
- Цикл 29 завершён: исправлены ошибки из `logs_62138146831.zip`, синхронизированы active docs counts и `TESTS_CATALOG`, восстановлена корректная структура Healer JSON, очищён terminology drift в active docs, добавлен backlog циклов FAQ, архив подготовлен как v158_06.

## Дополнительные циклы FAQ — backlog после 40

| № | Статус | Цель | Результат |
|---|---|---|---|
| 41 | done | FAQ inventory freeze. | Зафиксированы 13 языков × 20 разделов × 250 Q/A; создан freeze и RU direct-risk count = 22 кандидата. |
| 42 | done | FAQ RU purge wave 1. | Закрыт ретроактивно: последующие purge/parity waves 43–55 и zero-candidate audit cycle 46 сняли исходный direct-risk хвост по RU FAQ. |
| 43 | done | FAQ sync wave 1. | Выполнен review wave 2 + manual confirmation list; цикл закрыт по поздней записи в журнале. |
| 44 | done | Section 14 redesign. | FAQ RU refinement wave 2 завершён; цикл закрыт по поздней записи в журнале (v158_21). |
| 45 | done | FAQ translations/runtime parity wave 1. | Section 14 и точечные RU replacement IDs синхронизированы во всех 12 переводах, runtime FAQ пересобран, direct-risk tournament residual в ES удалён, добавлены translation parity guards. |
| 46 | done | FAQ RU purge wave 2. | Выполнен zero-candidate audit по прямым рискованным словам: новых RU direct-risk кандидатов не найдено, удалений и замен Q/A в этом цикле не потребовалось. |
| 47 | done | FAQ translations parity wave 2. | Выполнен weak/duplicate audit wave 1; manual-review list создан, автоматических удалений не было. |
| 48 | done | FAQ weak Q/A audit. | FAQ RU weak/duplicate resolution wave 1 завершён; статус обновлён по поздней записи в журнале. |
| 49 | done | FAQ duplicate Q/A audit. | Подтверждены 3 группы частичных дублей / 6 RU Q/A-кандидатов; автоматических удалений нет. |
| 50 | done | FAQ RU cleanup wave 3. | FAQ RU duplicate resolution wave 2 завершён; статус обновлён по поздней записи в журнале (v158_27). |
| 51 | done | FAQ translations parity wave 3. | FAQ translations/runtime parity wave 2 завершён; статус обновлён по поздней записи в журнале (v158_28). |
| 52 | done | FAQ terminology/adaptation audit. | FAQ RU duplicate audit wave 3 завершён; статус обновлён по поздней записи в журнале. |
| 53 | done | FAQ exact totals lock. | FAQ RU duplicate resolution wave 3 завершён; 4 группы дублей разведены без удаления Q/A, runtime пересобран, totals 20/250 сохранены. |
| 54 | done | FAQ removal archive sync. | Выполнен translations/runtime parity wave 3 для 8 mirrored IDs; runtime каталоги пересобраны, добавлен guard `test_faq_translations_wave3_sync.py`. |
| 55 | done | FAQ RU duplicate audit wave 4. | Выполнен audit_only по русскому FAQ после parity wave 3: подтверждены 2 группы частичных дублей / 9 RU Q/A-кандидатов без автоматических удалений и без изменения runtime. |

- Цикл 30 завершён: выполнен регрессионный пакет серии 21–30, удалён EN FAQ residual с запрещённой механикой, усилен FAQ guard и создан `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`.
- Цикл 31 завершён: зафиксирован freeze route inventory на 82 active маршрута, добавлены `docs/audits/ROUTE_INVENTORY_FREEZE.md`, `docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv` и guard `test_route_inventory_freeze_sync.py`.



- Цикл 33 завершён: idempotency surface переведён на full-path audit, policy regex синхронизированы с active routes, создан `docs/SSOT/ssot_pack/SSOT_IDEMPOTENCY_SURFACE.csv` и добавлен docs-sync guard.

- Цикл 34 завершён: зарегистрирован `HTTPException` handler через `setup_exception_handlers(app)`, добавлен guard `test_route_error_response_canon.py`, приведены object-detail ошибки routes к каноническим ключам `error/message/details`.

- Цикл 35 завершён: исправлены падения `mypy`/`pytest` из `logs_62183880084.zip`, migration docs 0001 синхронизированы с current ORM/SSOT canon, добавлен guard `test_migration_0001_orm_ssot_sync.py`.


- Цикл 36 завершён: исправлено падение из `logs_62194714005.zip` по alias-терминам в `ROUTES_TABLES_MIGRATIONS_PLAN.json`, migration plan приведён к current invariants 32 tables / 2 schemas / ORM-only 0001, добавлен guard `test_migration_invariants_hardening.py`.


- Цикл 37 завершён: DB diagnostic docs приведены к current canon 32 tables / 2 schemas, исправлены stale totals 38/33 и сломанные legacy policy paragraphs, добавлен guard `test_db_diagnostics_docs_sync.py`.

- Цикл 38 завершён: `MODEL_TABLE_ROUTE_TEST_MAP.md` синхронизирован с 82 SSOT routes, 82 OpenAPI operations, 78 OpenAPI paths и актуальным числом test files; ссылка на отсутствующий `backend/app/models/exchange_routes.py` заменена, добавлен guard `test_openapi_docs_route_matrix_sync.py`.


- Цикл 39 завершён: release build script очищен от runtime log-артефактов, добавлен guard `test_release_artifact_hygiene_wave2.py`, создан `docs/RELEASE_ARTIFACT_HYGIENE_WAVE_2.md`, архив подготовлен как v158_16.

- Цикл 31 завершён: freeze route inventory зафиксирован на 82 active routes, добавлен guard `test_route_inventory_freeze_sync.py`, архив подготовлен как v158_08.
- Цикл 32 завершён: route naming cleanup выполнен, freeze inventory приведён к канону router tags, добавлен guard `test_route_inventory_naming_canon.py`, архив подготовлен как v158_09.
- Цикл 33 завершён: idempotency surface audit закрыт, policy guards усилены по full-path и docs sync, архив подготовлен как v158_10.
- Цикл 34 завершён: route response/error canon выровнен, `HTTPException` handler зарегистрирован, архив подготовлен как v158_11.
- Цикл 35 завершён: migration 0001 vs ORM/SSOT audit синхронизирован, архив подготовлен как v158_12.
- Цикл 36 завершён: migration invariants hardening закрепил 32 таблицы / 2 схемы / ORM-only 0001, архив подготовлен как v158_13.
- Цикл 37 завершён: DB diagnostics/docs sync выровнен с SSOT_TABLES_ORM, архив подготовлен как v158_14.
- Цикл 38 завершён: OpenAPI/docs route matrix sync выровнен, архив подготовлен как v158_15.
- Цикл 39 завершён: release artifact hygiene wave 2 исключил runtime log-артефакты, архив подготовлен как v158_16.
- Цикл 40 завершён: финальный regression pack серии 31–40 пройден, MODEL_TABLE_ROUTE_TEST_MAP синхронизирован по 112 test files, серия route/migration 31–40 закрыта.

- cycle 43: faq ru review wave 2 + manual confirmation list — done

- 44. faq ru refinement wave 2 — done (v158_21)
- 45. faq translations/runtime parity wave 1 — done (v158_22)


- Цикл 46 завершён: direct-risk zero-candidate audit по русскому FAQ подтверждил 0 новых кандидатов wave 2; серия прямых risk-слов в RU каноне закрыта, дальнейшие FAQ-циклы переходят к слабым и дублирующим Q/A.


- cycle 47: faq ru weak/duplicate audit wave 1 — done (manual-review list created, no faq deletions).


- Cycle 48: FAQ RU weak/duplicate resolution wave 1 — done.

- Cycle 50: FAQ RU duplicate resolution wave 2 — done (v158_27).

- Cycle 51: FAQ translations/runtime parity wave 2 — done (v158_28).


51. faq translations/runtime parity wave 2 — done
52. faq ru duplicate audit wave 3 — done

53. faq ru duplicate resolution wave 3 — done

- Цикл 53 завершён: 4 группы duplicate wave 3 в русском FAQ разведены по смыслу без удаления Q/A, runtime пересобран, totals 20/250 сохранены.

- Цикл 54 завершён: выполнен FAQ translations/runtime parity wave 3 для 8 mirrored IDs после RU duplicate resolution wave 3; runtime каталоги пересобраны, добавлен guard `test_faq_translations_wave3_sync.py`.


- Цикл 55 завершён: выполнен audit_only по русскому FAQ после translation/runtime parity wave 3; подтверждены 2 review-группы / 9 RU Q/A-кандидатов (`17-3/17-6/17-10` и `19-19..19-24`), создан `docs/archive_removed_elements/FAQ_RU_DUPLICATE_CANDIDATES_WAVE4.md`, добавлен guard `test_faq_ru_duplicate_wave4_audit_lock.py`.



## Циклы 56–60 — FAQ backlog closure + Shop → Hub preparation

| № | Статус | Цель | Описание |
|---|---|---|---|
| 56 | done | Shop → Hub planning sync. | Выполнены direct audit и planning sync: в журнал добавлены циклы 61–90 и резерв 91–100, в Q&A register занесены ответы пользователя 1–30 по переходу Shop → Hub, в AI/operator rules закреплён запрет оправдательных формулировок и правило базового user-facing термина `Hub`. |
| 57 | done | Shop → Hub active surface inventory. | Проведён прямой аудит HEAD-архива и active code surface; создан `docs/audits/SHOP_HUB_TRANSITION_INVENTORY.md` с подтверждённой картой frontend/backend/bot/admin/FAQ/runtime/test слоёв старого домена `Shop`; зафиксировано, что alias removal пока запрещён и migration должна идти staged-путём. |
| 58 | done | Work cycles journal canon rename. | Выполнен прямой audit docs-governance слоя: каноническим путём журнала закреплён `docs/cycles/WORK_CYCLES.md`, обновлены ссылки на новый range-free путь, устранён drift между именем файла и фактическим диапазоном циклов 1–100. |
| 59 | done | Work cycles de-dup and sequence sync. | Выполнен прямой audit журнала циклов: удалён устаревший дублирующий блок planned 56–60 по FAQ, сохранена единая фактическая последовательность 56–60 для Shop → Hub preparation, синхронизированы HEAD/version note и связанные реестры. |
| 60 | done | Hub SSOT freeze. | Добавлен канонический документ `docs/SSOT/HUB_SSOT.md` как единый источник правил Hub; зафиксированы MUST / MUST NOT, handoff flow EFHC, внешний VIP через GetGems, skin canon, alias policy `shop -> hub`, guard/FAQ/admin alignment и обязательность применения документа в backend/frontend/admin/FAQ/QA слоях. |

## Циклы 61–90 — Shop → Hub transition series

Правило ведения реестра:
- Все новые и будущие циклы записываются с отдельным описанием цели,
  объёма и ожидаемого результата.
- Журнал не должен содержать дублирующие диапазоны или повторно
  переиспользованные номера циклов с разным смыслом.
- Канонический путь журнала циклов: `docs/cycles/WORK_CYCLES.md`.
- Единый источник правил Hub: `docs/SSOT/HUB_SSOT.md`.
- Для user-facing слоя базовый термин перехода:
  `Hub`.
- Технический алиас `shop` сохраняется до безопасного завершения полной
  замены функций, маршрутов, миграций и runtime-layer.

| № | Статус | Цель | Описание |
|---|---|---|---|
| 61 | done | Shop → Hub pre-audit. | Выполнен прямой количественный и структурный pre-audit HEAD-архива после `docs/SSOT/HUB_SSOT.md`; добавлен `docs/HUB_PRE_AUDIT_BASELINE.md` с подтверждёнными active `shop` traces по frontend/backend/docs/tests/reports, зафиксировано отсутствие real implementation `hub` traces вне docs и подтверждена staged migration без удаления алиасов. |
| 62 | done | Hub SSOT implementation alignment. | Выполнен полный implementation audit по `docs/SSOT/HUB_SSOT.md`: добавлен `docs/HUB_SSOT_IMPLEMENTATION_ALIGNMENT_AUDIT.md`, подтверждены active нарушения MUST / MUST NOT во frontend/backend/admin/bot/locale слоях, зафиксированы guard insertion points и staged migration sequence без удаления переходного алиаса `shop`. |
| 63 | done | UI naming wave 1. | Замена user-facing названия `Shop` на `Hub` в кнопках, заголовках, карточках, header, help labels, modal titles и навигации без удаления технических алиасов; wave 1 закрыта. |
| 64 | done | Frontend route alias wave. | Добавлены user-facing entry points `frontend/src/pages/hub.tsx` и `frontend/src/pages/admin/hub.tsx`, кнопка `GlobalHeader` переведена на `/hub`, bot main menu теперь ведёт в `/hub`, а `/shop` сохранён как legacy command alias через `backend/app/bot/handlers/shop_handlers.py`. |
| 65 | done | Hub page refactor. | Переделка текущей страницы Shop в отдельную страницу Hub с двумя стартовыми карточками: `Пополнить EFHC` и `Получить VIP NFT`; из user-facing слоя удалены TonConnect, price fields, deposit flow и skin purchase flow. |
| 66 | done | User-facing catalog removal. | Из active user-facing FAQ/runtime слоя удалены остаточные товарные формулировки Shop: раздел 13 русского FAQ переведён на Hub-модель без внутренних покупок, а ссылки на покупку через Shop заменены на фактические Hub/external-flow формулировки. |
| 67 | done | EFHC handoff architecture. | Выполнен прямой архитектурный аудит Hub EFHC handoff: добавлен `docs/HUB_EFHC_HANDOFF_ARCHITECTURE_AUDIT.md`, подтверждено отсутствие отдельного backend handoff endpoint, зафиксированы обязательные token-claims (`exp`, `jti`, signed), separation boundary между Hub и внешним buy-flow и запрещён direct reuse Shop commerce contract как будущего Hub public contract. |
| 68 | done | EFHC handoff implementation wave 1. | Добавлен `POST /hub/efhc-handoff`, `backend/app/routes/hub_routes.py` и `backend/app/schemas/hub_schemas.py`; карточка EFHC в `frontend/src/pages/shop.tsx` теперь вызывает backend handoff endpoint и открывает внешний URL только после ответа сервера, сохраняя fallback modal при отсутствии подключённого buy-flow URL. |
| 69 | done | VIP GetGems alignment. | Подтверждённо переведён VIP user-facing слой к модели внешней ссылки на `https://getgems.io/efhc-nft`: обновлены active runtime FAQ `frontend/src/data/faq/catalogs.ts`, locale help-key `shop.vip_nft_manual` во всех 13 языках и RU wallet answer; удалён магазинный смысл VIP без изменения ownership-check логики. |
| 70 | done | Skins canon refactor wave 1. | Выполнена первая волна user-facing выравнивания канона скинов: переписаны active locale keys во всех 13 языках, удалён магазинный смысл покупки/владения, тексты переведены на модель прогресса и разблокировки, а `frontend/src/lib/skins.ts` синхронизирован с каноном 12 уровней. |
| 71 | done | Skins model/data audit. | Выполнен прямой аудит skin model/data/service/API/helper слоя: подтверждены legacy commerce markers `price_efhc`, `purchased_at`, `POST /skins/buy/{skin_id}`, `buy_skin(...)`, `skin_purchase`, `getShopSkinBgUrl(...)` и `efhc_shop_skin_changed`; user-facing progression canon уже активен, но implementation layer ещё остаётся смешанным и требует дальнейшего разделения. |
| 72 | done | Skin switcher concept. | Concept был отложен в исходной Hub-серии и закрыт позже на новом HEAD через cycle 91: зафиксирован отдельный SSOT switcher-а доступных/активных скинов, отделённый от Hub и legacy commerce bridge. |
| 73 | done | Hub admin entity design. | Выполнен полный аудит чата и HEAD-архива для admin Shop → Hub слоя; добавлен `docs/HUB_ADMIN_ENTITY_DESIGN.md`, зафиксирована сущность `hub_links`, обязательные поля, исключения price/order semantics, seed-карточки `efhc_buy` и `vip_getgems`, а также сохранение legacy `/admin/shop` как временного алиаса до следующих циклов. |
| 74 | done | Hub admin migration/model wave. | Добавлены `backend/app/models/hub_links_models.py`, admin CRUD/service scaffolding и seed-записи `efhc_buy`/`vip_getgems`; итоговый текущий канон: `hub_links` интегрированы в base migration `0001_init.py`, без отдельного active `0002` файла. |
| 75 | done | Hub admin routes/services. | Добавлены list/create/update/toggle/reorder операции для Hub links manager через `/admin/hub/links` с сохранением legacy admin-aliases `/admin/shop/hub-links`; backend теперь отделяет Hub links manager от shop price/order semantics. |
| 76 | done | Hub admin UI wave. | `frontend/src/pages/admin/shop.tsx` переведён на Hub Links Manager: list/create/edit/toggle/reorder работают через `/admin/hub/links*`, user/admin-facing label в меню и на странице теперь `Hub`, а price/order fields удалены из active admin UI при сохранении technical route alias `/admin/shop`. |
| 77 | done | FAQ section 13 draft. | По HEAD подтверждено, что active runtime `frontend/src/data/faq/ru.ts` уже содержит section `13. Hub`, но `docs/SSOT/faq_ssot/ru/faq_ru.md` всё ещё отстаёт на old `13. Shop`; создан `docs/HUB_FAQ_SECTION_13_RU_DRAFT.md` как freeze-пакет русского draft и approval list, total active RU FAQ подтверждён как 233/250. |
| 78 | done | FAQ cross-section drift audit. | Выполнен archive-first аудит `Shop` traces в FAQ/runtime/SSOT/bot/locale слоях; добавлен `docs/HUB_FAQ_CROSS_SECTION_DRIFT_AUDIT.md`, подтверждено, что prior chat drift note о `frontend/src/data/faq/ru.ts` не совпадает с HEAD, а реальные active runtime traces живут в `frontend/src/data/faq/catalogs.ts`; зафиксирован точный scope для cycles 79–81. |
| 79 | done | RU FAQ rewrite wave 1. | Русский SSOT FAQ переведён с `Shop` на `Hub` в канонических user-facing Q/A: обновлены section 13, связанные navigation/top-bar ответы, EFHC/VIP описаны как внешние потоки, а скины зафиксированы как награды прогресса без магазинной модели. |
| 80 | done | Runtime FAQ rebuild. | Runtime FAQ пересобран штатным генератором `ops/scripts/generate_faq_catalogs_from_ssot.py` из актуального SSOT; `frontend/src/data/faq/catalogs.ts` синхронизирован с `docs/SSOT/faq_ssot/*/faq_*.json`, RU runtime section 13 теперь `Hub`, а exact-match guard подтверждает детерминированную сборку. |
| 81 | done | Bot FAQ/help sync. | Bot help/text layer синхронизирован с Hub: `backend/app/bot/texts.py` переведён на backward-compatible helper `t("help")`/`t("ru", "help")`, добавлены реальные help/subscribe/panels/profile/ranks/referrals/exchange texts, `/hub` зафиксирован как primary command, `/shop` и `/admin_shop` сохранены как technical aliases, а bot-facing сообщения переведены с `Shop` на `Hub`. |
| 82 | done | Translations parity wave 1. | Новый смысл Hub и обновлённый section 13 перенесены на все 13 языков SSOT FAQ; `Shop` удалён из active FAQ section 13 и связанных navigation/top-bar ответов, runtime FAQ пересобран из SSOT и подтверждён generator guard. |
| 83 | done | Docs/OpenAPI sync. | README, PROJECT_OVERVIEW_RU, route matrix, SSOT_ROUTES, ROUTE_INVENTORY_FREEZE, OpenAPI snapshot, TERMS/WALLETS/EFHC canon и API contracts синхронизированы с Hub admin surface `/admin/hub/links*` и public handoff `POST /hub/efhc-handoff`; route count updated to 88, а Shop зафиксирован как backend commerce domain и technical alias. |
| 84 | done | Hub guards and regression pack. | Добавлены direct guard-tests и документ `docs/HUB_GUARDS_REGRESSION_PACK.md`: зафиксированы alias `shop -> hub`, запрет цен/внутренних покупок/TonConnect/skin SKU в active Hub UI, signed external handoff `POST /hub/efhc-handoff`, внешний VIP GetGems flow и regression pack на user-facing Hub surface. |
| 85 | done | Legacy shop residue audit. | Выполнен прямой аудит остаточных `shop` traces; добавлен `docs/LEGACY_SHOP_RESIDUE_AUDIT.md`, где слой разделён на backend commerce domain, временные технические алиасы, исторические следы и подтверждённые cleanup-candidates для cycle 86 без ошибочного массового удаления всех `shop`-следов. |
| 86 | done | Legacy cleanup wave 1. | Удалены подтверждённые wave-1 остатки: stale docs wording (`FAQ_COVERAGE_MATRIX`, `ADMIN_RBAC`, `specification`, `skins/README`) и 143 мёртвых locale-ключа `shop.*` / `desc.shop.*` / `admin.shop_orders_summary`; backend commerce и технические алиасы сохранены. |
| 87 | done | Alias pressure test. | Добавлен `tests/architecture/test_hub_alias_pressure_test.py` и документ `docs/HUB_ALIAS_PRESSURE_TEST.md`; подтверждено, что старые deep links, route aliases, bot entry points и admin aliases сохраняют совместимость, но primary user-facing/admin-facing surface остаётся `Hub`. |
| 88 | done | Final alias removal design. | Добавлен `docs/HUB_FINAL_ALIAS_REMOVAL_DESIGN.md`; зафиксированы preconditions, wave-plan и decision rule для безопасного удаления `shop`-алиасов без затрагивания backend commerce domain, history-only traces и неподтверждённых compatibility surfaces. |
| 89 | done | Final alias removal wave 1. | Выполнена безопасная внутренняя канонизация Hub: live implementation перенесён в `hub`-named frontend/bot files, а `shop`-named pages/handlers сохранены как тонкие compatibility wrappers без удаления public `/shop` и `/admin/shop` surfaces. |
| 90 | done | Final commerce cleanup + release stabilization. | Удалён мёртвый legacy-компонент `frontend/src/components/ShopGrid.tsx`, устранён drift активной UI-документации `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`, выровнено canonical naming `AdminHubPage`, а targeted regression/compile pack подтвердил стабильность Hub surface при сохранении `/shop` и `/admin/shop` как compatibility aliases. |

## Плановые циклы 91–100 — резерв расширения

| № | Статус | Цель | Описание |
|---|---|---|---|
| 91 | done | Skin switcher concept closure. | Добавлен `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`: зафиксированы unlock rule от 12-level progression canon, cumulative `available_skin_ids`, правило `active_skin_id`, fallback policy и жёсткое разделение switcher-а от Hub и legacy commerce-domain; cycle 72 закрыт как resolved later by cycle 91. |
| 92 | done | Skin switcher implementation wave 1. | Добавлены отдельные switcher-facing endpoints `/skins/switcher` и `/skins/switcher/activate/{skin_id}`, новые schema/helper surface `current_level` / `available_skin_ids` / `active_skin_id`, а хранение активного скина синхронизировано с 12-level progression canon без удаления legacy `/skins/buy` bridge. |
| 93 | done | Alias caller audit wave 2. | Выполнен прямой аудит alias-callers после internal canonicalization: подтверждены active bot aliases `/shop` и `/admin_shop`, один внутренний admin caller `/admin/shop` в `frontend/src/pages/admin/index.tsx`, отсутствие текущих keyboard/runtime callers к `/shop`, а thin wrapper modules `shop_handlers.py` и `admin_shop_handlers.py` зафиксированы как wave-2 cleanup candidates. |
| 94 | done | Alias removal wave 2. | Внутренний admin caller переведён с `/admin/shop` на `/admin/hub`, удалены thin bot-wrapper modules `shop_handlers.py` и `admin_shop_handlers.py`, а внешние compatibility surfaces `/shop`, `/admin_shop`, `frontend/src/pages/shop.tsx`, `frontend/src/pages/admin/shop.tsx` и backend commerce `/shop/*` сознательно сохранены. |
| 95 | done | Bot/webapp entrypoint stabilization. | Добавлена отдельная admin-entry keyboard `kb_admin_entry()` с прямым входом в `/admin/hub`, admin-команды `/admin` и `/admin_hub` больше не зависят от generic main menu, а help-layer явно перечисляет `/admin_hub` и `/admin_shop` как admin entry aliases. |
| 96 | done | Post-alias docs and OpenAPI freeze. | Добавлен `docs/POST_ALIAS_DOCS_OPENAPI_FREEZE.md`: зафиксировано, что после cycles 93–95 current internal admin entry — `/admin/hub`, bot aliases `/shop` и `/admin_shop` сохранены, а `backend/openapi/openapi.json` остаётся route-stable snapshot без изменений HTTP surface; stale wording убрано из `docs/NORM/TESTS_CATALOG.md`. |
| 97 | done | Admin/reporting Hub hardening. | Зафиксировано semantic hardening-разделение: admin Hub manager остаётся слоем `hub_links` и `/admin/hub/links*`, а `get_shop_stats()` и `shop_sales_summary()` подтверждены как commerce-domain reporting по `shop_orders`/`shop_items`, не как Hub navigation metrics; добавлен `docs/ADMIN_REPORTING_HUB_HARDENING.md`. |
| 98 | done | Legacy cleanup wave 2. | Активный runtime переведён на canonical Hub locale keys (`admin.hub`, `admin.hub_note`, `nav.hub`, `profile.reason.hub_operation`), удалены stale runtime keys `admin.placeholder_shop`, `admin.shop`, `admin.shop_note`, `nav.shop`, `shop.title`, `profile.reason.shop_purchase`; compatibility routes, commerce-domain Shop и history-only traces сохранены. |
| 99 | done | Final release audit. | Проведён прямой final audit архива, bot, frontend, backend, docs, tests, guards, OpenAPI и release ZIP; выявлена и исправлена syntax-ошибка в `backend/app/bot/texts.py`, подтверждены compileall, checked-in OpenAPI snapshot, clean FLAT ZIP и прохождение targeted guard-pack; live FastAPI import в среде не подтверждён из-за отсутствия `sqlalchemy`. |
| 100 | done | Release stabilization and handoff. | Зафиксировано итоговое состояние серии 61–100, создан финальный handoff-документ `docs/HUB_SERIES_61_100_FINAL_HANDOFF.md`, выровнен итоговый план 91–100 и обновлены closure-реестры серии; known limitation по live FastAPI import сохранён как environment note, а не как дефект архива. |


## Плановые циклы 101–110 — post-handoff fixes and FAQ governance

| № | Статус | Цель | Описание |
|---|---|---|---|
