
# План циклов 1301-1400: расширение восстановления frontend

Статус: detailed extension plan.
Дата: 2026-05-21.
Архивная версия: v168_73.

## 1. Назначение

Документ продолжает план 1268-1320 и заранее фиксирует следующие
циклы frontend-восстановления. Он не заменяет текущий план 1268-1320,
а расширяет его до диапазона 1400, чтобы следующие проходы не
превращались в хаотичные визуальные правки.

Главное правило остаётся прежним: сначала смысл страницы и канон
функций, затем структура, затем код, затем guard, затем отчёт.

## 2. Циклы 1301-1320: завершение текущего блока

### 1301 — Ranks show-me focus

Цель: кнопка `Показать меня` должна находить пользователя в рейтинге
и показывать ближайших конкурентов выше и ниже.

Сделать:

- проверить текущий источник позиции пользователя;
- реализовать focus/scroll или безопасный focused subset;
- не показывать `global_id`;
- сохранить вертикальные карточки игроков.

### 1302 — Ranks proof pass

Цель: закрыть Ranks как восстановленный экран.

Сделать:

- проверить фильтры только `kWh` и `Referrals`;
- проверить отсутствие каталога 12 Energy levels;
- проверить current user pinned card;
- добавить guard и отчёт.

### 1303-1310 — Profile, Wallet, History, FAQ

Цель: восстановить профильный контур.

Сделать:

- Profile как отдельная страница `/web-profile`;
- VIP и Active индикаторы всегда видимы;
- Wallet только список подключённых кошельков;
- History как общая история аккаунта;
- FAQ как компактное вертикальное дерево;
- не возвращать Profile overlay как основной путь.

### 1311-1316 — HUB, Browser-Shop, USDT

Цель: восстановить публичные переходы и Web3-витрину.

Сделать:

- HUB строго две равные кнопки;
- VIP NFT как ссылка;
- Browser-Shop как отдельная Web3-страница;
- крупные товарные/NFT-подобные карточки;
- TON payment proof;
- USDT возвращать только после payment-road audit.

### 1317-1320 — Admin recovery start

Цель: вернуть Admin к операторской панели.

Сделать:

- главная Admin как список разделов;
- внутри каждой функции график/статистика сверху;
- действия и таблицы ниже;
- debug только в Diagnostics;
- route inventory перед удалением или переносом.

## 3. Циклы 1321-1330: Panels deep recovery

### 1321 — panel source audit after first UI pass

Проверить, что данные панели реально содержат дату активации, дату
деактивации и источник remaining seconds.

### 1322 — panel countdown contract hardening

Закрепить backend/frontend контракт обратного отсчёта панели без
использования возраста панели как замены.

### 1323 — panel runtime countdown precision

Проверить, что runtime countdown не отстаёт от server/source time и
не уходит в отрицательное значение.

### 1324 — panel generation seconds relation

Проверить связь: панель теряет секунды, а generation получает секунды
в расчёте kWh.

### 1325 — panel archive boundary

Разделить активные и архивные панели без удаления данных и без
потери истории.

### 1326 — panel activation affordability states

Показать простые состояния: можно активировать, не хватает EFHC,
ошибка backend. Не выводить debug.

### 1327 — panel mobile card proof

Проверить мобильную карточку панели на ширину, переносы, кнопки и
обратный отсчёт.

### 1328 — panel admin visibility audit

Проверить, какие данные панели должны быть видны пользователю, а какие
только Admin.

### 1329 — panel tests and guards consolidation

Объединить guards по Panels в устойчивый набор без изменения смысла
экономики.

### 1330 — panel recovery verdict

Дать честный вердикт: что восстановлено, что требует backend/migration,
что не заявляется как готовое.

## 4. Циклы 1331-1340: money and history surfaces

### 1331 — History endpoint map

Составить карту источников History: покупки, обмен, вывод, бонусы,
панели.

### 1332 — History UI minimal shell

Создать общий интерфейс History без перегруза и без wallet-only логики.

### 1333 — History filters

Добавить фильтры `All`, `Purchases`, `Exchange`, `Withdraw`, `Bonuses`,
`Panels`.

### 1334 — Exchange history handoff

На Exchange оставить только ненавязчивую кнопку перехода к History.

### 1335 — Wallet/history boundary guard

Зафиксировать, что Wallet не становится общей финансовой историей.

### 1336 — Withdraw history alignment

Проверить, как выводы отображаются в общей истории аккаунта.

### 1337 — Bonus history alignment

Проверить начисления бонусов и реферальных бонусов в History.

### 1338 — Purchases history alignment

Проверить покупку EFHC, панели, Shop и VIP-ссылки.

### 1339 — History mobile proof

Проверить мобильную читаемость History и отсутствие горизонтального
скролла.

### 1340 — money surfaces verdict

Дать вердикт по money/history layer без fake release-ready.

## 5. Циклы 1341-1350: Browser-Shop and payments

### 1341 — Browser-Shop product model audit

Проверить текущие товары, цены, валюты и public/private поля.

### 1342 — Browser-Shop Web3 visual cards

Перестроить карточки под Web3-витрину с крупным визуальным центром.

### 1343 — TON payment UI proof

Проверить TON-покупку без вывода payload, endpoint, wallet/memo/copy.

### 1344 — USDT payment-road explanation

Дать в чате простое объяснение, что именно нужно проверить перед
возвратом USDT-кнопки.

### 1345 — USDT backend route audit

Проверить backend/watcher/intent поддержку USDT без публичного UI.

### 1346 — USDT storefront decision

Если support подтверждён, вернуть USDT как нормальную кнопку оплаты.
Если нет — зафиксировать blocker.

### 1347 — VIP NFT link proof

Проверить, что VIP NFT остаётся ссылкой, а не тяжёлой NFT-панелью.

### 1348 — bonus packages question pack

Подготовить отдельный пакет вопросов по bonus packages, если их
возвращение всё ещё нужно.

### 1349 — Browser-Shop no-debug guard

Guard против wallet/memo/copy/debug/payload/endpoint в публичной
витрине.

### 1350 — Browser-Shop verdict

Честный вердикт по Shop: TON, USDT, VIP link, blockers.

## 6. Циклы 1351-1360: Admin operator console

### 1351 — Admin route inventory

Составить route map по всем Admin backend/frontend дорогам.

### 1352 — Admin home grid

Главная Admin: крупные карточки разделов без debug dump.

### 1353 — Admin Users page

Users: статистика сверху, список/поиск/действия ниже.

### 1354 — Admin Bank page

Bank: график/статистика банка, mint/burn/transfer/history ниже.

### 1355 — Admin Withdrawals page

Withdrawals: статусы, очереди, approve/reject/cancel без
удаления истории.

### 1356 — Admin Shop page

Shop: товары, платежи, статусы, без смешивания с публичной витриной.

### 1357 — Admin Tasks page

Tasks: задания, награды, ads, защита от double-claim.

### 1358 — Admin Reports page

Reports: отчёты, аудит, change reports, без публичного debug.

### 1359 — Admin Diagnostics page

Diagnostics: технические сведения, logs, probes, route proof.

### 1360 — Admin System page

System: настройки и системные guard-состояния, если route существует.

## 7. Циклы 1361-1370: mobile and visual proof

### 1361 — mobile viewport 390 audit

Проверить все публичные экраны в узком mobile viewport.

### 1362 — desktop/browser audit

Проверить browser/PWA view без Telegram `tg_id`.

### 1363 — Telegram WebApp audit

Проверить Telegram entry, MainButton, BackButton и viewport safe area.

### 1364 — no horizontal scroll guard

Создать guard/QA на отсутствие горизонтального скролла.

### 1365 — contrast guard

Проверить тёмную тему, muted text, disabled text и карточки.

### 1366 — button consistency guard

Проверить одинаковую высоту важных кнопок и HUB-кнопок.

### 1367 — progress bar consistency

Проверить Energy, Referrals и возможные panel/progress bars.

### 1368 — screenshots before/after protocol

Подготовить обязательный screenshot QA протокол для live проверки.

### 1369 — Dragon/Web3 visual alignment audit

Сравнить EFHC с визуальным направлением Dragon без копирования бренда.

### 1370 — visual proof verdict

Дать вердикт по visual layer с перечислением оставшихся дефектов.

## 8. Циклы 1371-1380: runtime and Docker proof

### 1371 — Docker compose smoke

Проверить docker compose без `down -v`.

### 1372 — frontend runtime smoke

Проверить главные public routes в запущенном frontend.

### 1373 — backend health smoke

Проверить `/api/health` и критические API.

### 1374 — browser login smoke

Проверить login/demo page без Telegram.

### 1375 — Telegram return URL audit

Проверить return URL и Telegram entry flow.

### 1376 — service worker smoke

Проверить, что service worker не ломает свежий frontend.

### 1377 — manifest validation

Проверить PWA manifest, icons, start_url, display standalone.

### 1378 — tunnel diagnostic separation

Не смешивать EFHC runtime с Cloudflare quick tunnel errors.

### 1379 — runtime smoke report

Создать отчёт runtime smoke без fake green.

### 1380 — Docker/runtime verdict

Дать честный вердикт по Docker/browser/runtime.

## 9. Циклы 1381-1390: final guards and docs sync

### 1381 — frontend route guard refresh

Обновить route checker под фактические frontend routes.

### 1382 — page element matrix sync

Синхронизировать matrix с фактическим кодом.

### 1383 — component registry sync

Синхронизировать component registry с новыми shell/components.

### 1384 — visual elements registry sync

Синхронизировать visual elements registry.

### 1385 — do-not-touch guard sync

Обновить запреты после code passes.

### 1386 — Q/A and transcript sync

Обновить Q/A register и CHAT_TRANSCRIPT без подмены одного другим.

### 1387 — tests catalog sync

Обновить TESTS_CATALOG и список frontend guards.

### 1388 — reports index sync

Обновить REPORTS_INDEX и generated JSON registry.

### 1389 — Healer frontend regression consolidation

Внести все frontend-регрессии в Healer, если они подтверждены.

### 1390 — document-layer audit

Проверить, что временные документы не попали в SSOT.

## 10. Циклы 1391-1400: release decision preparation

### 1391 — frontend release readiness evidence map

Собрать карту доказательств готовности frontend.

### 1392 — unresolved blockers list

Составить честный список blockers.

### 1393 — user-facing screen checklist

Закрыть checklist по всем публичным экранам.

### 1394 — admin screen checklist

Закрыть checklist по Admin.

### 1395 — payment surfaces checklist

Закрыть checklist по Shop, Exchange, Withdraw, History.

### 1396 — browser/PWA checklist

Закрыть checklist browser/PWA.

### 1397 — Telegram checklist

Закрыть checklist Telegram WebApp.

### 1398 — final visual regression audit

Провести финальный visual regression audit.

### 1399 — release candidate package audit

Проверить ZIP: FLAT, без мусора, без wrapper-folder, без cache.

### 1400 — frontend recovery verdict

Дать итоговый вердикт: готово, частично готово или не готово.
Нельзя писать release-ready без live proof, Docker/runtime proof и
прохождения проверок.
