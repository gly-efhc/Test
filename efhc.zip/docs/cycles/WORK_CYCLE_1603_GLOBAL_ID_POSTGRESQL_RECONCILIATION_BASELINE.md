# Рабочий цикл 1603 — Global ID PostgreSQL reconciliation baseline

Исходный HEAD: `EFHC_Bot_v171_99.zip`.
Целевой HEAD: `EFHC_Bot_v172_00.zip`.

## Цель

Подготовить и выполнить воспроизводимый реальный PostgreSQL gate для
`global_id` до historical backfill и read switch.

## Реализованный контур

- exact provenance передаётся явно и проверяется fail closed;
- canonical `global_id` отображается на physical `users.user_id`;
- отдельная колонка `users.global_id` считается нарушением;
- поддерживаются `psycopg` и `psycopg2`;
- URL нормализуется из sync/async SQLAlchemy-форм;
- один согласованный снимок: `REPEATABLE READ READ ONLY DEFERRABLE`;
- statement timeout 120 секунд, lock timeout 5 секунд;
- транзакция всегда завершается `ROLLBACK`;
- ошибки очищаются от реквизитов подключения;
- SQL-пакет может быть проверен независимо;
- production snapshot отделён от isolated empty-database smoke.

## Метрики

Users, physical `user_id`, legacy `global_id`, planned global_id collisions,
sequence, balances, kWh mirror, panels, transfers, withdrawals, referrals,
wallet bindings, roles, identity table, idempotency, tx hash и legacy
orphan references.

Финансовый допуск: `0.00000000` без округления.

## Фактическое выполнение

Попытка поднять реальную PostgreSQL-среду выполнена. В контейнере нет
PostgreSQL Server/client, Docker/Podman и sync driver. APT не получил
пакеты из-за недоступного DNS/mirror. Поэтому gate завершён честным
статусом `БЛОКИРОВАНО_СРЕДОЙ`; метрики данных не получены.

Это не разрешает historical backfill, dual-write, read switch или
financial ownership switch.

## Следующий цикл

`1604 — Backend GlobalId type finalization`.
