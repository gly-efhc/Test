# Detailed Work Plan — Cycles 1185-1190

This document expands the active road-integrity plan. It does not close
future cycles by itself. A cycle is complete only after the related
source files, generated evidence and report are written.

## Scope boundary

The pass continues the road-integrity proof program opened by the PDF
audit and cycles 1180-1184. It is proof-first work. Legacy routes are
not deleted only because they look old. Every route change needs current
HEAD evidence and consumer proof.

## Cycle 1185 — runtime OpenAPI proof attempt

Goal:
- try to export OpenAPI from the real FastAPI runtime app;
- if runtime dependencies are unavailable in the container working
  environment, write a status artifact instead of guessing;
- keep static route inventory as fallback evidence only.

Expected artifacts:
- `ops/routes/export_runtime_openapi.py`;
- `reports/generated/runtime_openapi_1185_status.json`;
- `docs/audits/ROAD_INTEGRITY_RUNTIME_OPENAPI_1185.md`.

Exit rule:
- runtime OpenAPI is exported, or the blocker is documented honestly.

## Cycle 1186 — frontend caller to backend route matrix

Goal:
- build a static matrix from backend route decorators to frontend path
  strings outside FAQ and catalog exclusions;
- separate source-level evidence from runtime contract proof;
- identify routes and calls that need human review or better parser
  rules.

Expected artifacts:
- `ops/routes/build_frontend_backend_matrix.py`;
- `reports/generated/frontend_backend_matrix_1186.json`;
- `docs/audits/FRONTEND_BACKEND_CALLER_MATRIX_1186.md`.

Exit rule:
- counts are generated and caveats are recorded.

## Cycle 1187 — ORM versus 0001 strategy compare

Goal:
- statically compare ORM table declarations with the current 0001
  migration strategy;
- verify whether 0001 is metadata-driven and imports model modules;
- list important release tables that are or are not anchored in 0001.

Expected artifacts:
- `ops/routes/compare_orm_0001.py`;
- `reports/generated/orm_0001_compare_1187.json`;
- `docs/audits/ORM_0001_SCHEMA_STRATEGY_COMPARE_1187.md`.

Exit rule:
- the metadata strategy is classified without editing migration
  history.

## Cycle 1188 — `/user/me` road consumer proof

Goal:
- prove what exists for `/user/me` and `/user/{global_id}/me`;
- classify whether consumers are proven by static frontend strings;
- avoid removing either route before stronger consumer proof.

Expected artifacts:
- `reports/generated/user_panels_roads_1188_1189.json`;
- `docs/audits/USER_PROFILE_ROAD_CONSUMER_PROOF_1188.md`.

Exit rule:
- duplicate profile roads are classified as current evidence, not
  fixed
  by deletion.

## Cycle 1189 — panels summary road consumer proof

Goal:
- prove what exists for panels summary roads;
- classify missing or unproven consumer state;
- mark the next safe action for panels summary without deleting a
  route.

Expected artifacts:
- `reports/generated/user_panels_roads_1188_1189.json`;
- `docs/audits/PANELS_SUMMARY_ROAD_CONSUMER_PROOF_1189.md`.

Exit rule:
- panels summary road state is documented for follow-up repair.

## Cycle 1190 — withdraw road proof

Goal:
- prove the withdraw create, cancel, admin review and final status
  road;
- check route, service, model, 0001 anchor, statuses and bank ledger
  calls by static evidence;
- record remaining limits that require runtime or DB-backed tests.

Expected artifacts:
- `ops/routes/prove_withdraw_road.py`;
- `reports/generated/withdraw_road_proof_1190.json`;
- `docs/audits/WITHDRAW_ROAD_PROOF_1190.md`.

Exit rule:
- withdraw has a static proof bundle and clear remaining runtime gaps.
