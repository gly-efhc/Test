# Work Cycle 1591 — CI plan guard and complete frontend audit

Status: `LOCAL_SCOPE_COMPLETE / BROWSER_PROOF_DEFERRED`.
Archive target: `v171.88`.
Routes: `ci_log_exact_failure_repair` and
`frontend_visual_route_backed_recovery`.
Fallback: `false`.

## Input evidence

- GitHub run `82110466270`: release archive, green.
- GitHub run `82109237157`: development archive, one Pytest failure.
- The development frontend install, typecheck and production build were
  green and listed 33 routes.

## Root cause

The failing PostgreSQL test asserted one exact planner-selected panel
index name. PostgreSQL used another valid indexed plan. This was a
flaky test contract, not a missing database index or runtime query
regression.

## Repair

- Parse PostgreSQL `FORMAT JSON` plan nodes.
- Require a referral index and any canonical `panels.global_id` index.
- Preserve the `Limit` and index-access performance requirements.
- Add a guard forbidding restoration of the brittle raw string check.

## Frontend audit

- Reconciled all 34 physical page routes.
- Added missing documentation for `/app`, `/admin/system`, `/404` and
  `/500`.
- Added a machine visual manifest for 360, 390 and 430 px.
- Added a real `page.goto()` all-pages Chromium audit harness.
- Added a separate automatic non-blocking GitHub visual-evidence job;
  the blocking Canon job remains free of PNG evidence.
- Added physical-route/documentation/manifest parity guards.
- Preserved the canonical UI, six bottom buttons and page economics.

## Proof boundary

Relevant static frontend and route guards pass. Clean local frontend
installation was blocked by HTTP 503 from the configured package
registry, so exact v171.88 Chromium screenshots were not produced and
are not claimed. Fresh exact-HEAD development/release CI and the separate all-pages
visual-evidence workflow are required. PNG evidence remains outside
blocking Canon CI under the current visual-evidence boundary.
