# Cycle 1446 — CI rerun log repair

Status: DONE locally

HEAD input: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`

Input logs: `logs_72627437860.zip`

Output archive: `EFHC_Bot_v170_22_cycle_1446_ci_rerun_log_repair.zip`

## Цель

Прочитать fresh CI rerun logs, исправить фактические root causes,
обновить Kernel/map/docs/reports и не менять runtime-экономику EFHC.

## Root cause from logs

CI gate summary showed two failing gates:

1. `ruff` failed with `I001` import-order drift in:
   - `backend/app/services/admin/admin_bank_service.py`;
   - `backend/app/services/transactions_service.py`.
2. `pytest` failed in
   `tests/architecture/test_audit_of_audits_status_notes.py`
   because `docs/audits/ROUTE_INVENTORY_FREEZE.md` had no explicit
   `Status note` or `Historical snapshot` marker.

Other logged gates were green in the supplied logs:

- flake8 critical/full;
- mypy;
- bandit;
- compileall backend;
- Alembic upgrade head;
- npm ci;
- frontend `next build`.

These are facts from the supplied logs only. They are not a green claim for
this new archive until CI is rerun on the new ZIP.

## Repair

- Sorted the admin RBAC import in `AdminBankService` according to ruff.
- Moved the idempotency marker comment in `transactions_service.py` out of
  the import block so the import block remains ruff-sortable.
- Added an explicit status note to
  `docs/audits/ROUTE_INVENTORY_FREEZE.md`, marking it as a historical
  route inventory snapshot and pointing to active route/OpenAPI/linkage
  SSOT files.
- Added `tests/architecture/test_ci_log_repair_guards.py` to freeze the
  exact regression repairs from this log cycle.

## Runtime and economics impact

- EFHC economy changed: no.
- Runtime business logic changed: no.
- DB migrations changed: no.
- CI/workflows changed: no.
- Lock files changed: no.
- Tests deleted/disabled/archived/skipped/xfail: no.

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_ci_log_repair_guards.py \
  tests/architecture/test_audit_of_audits_status_notes.py -q
# 5 passed
```

```text
python -m pytest tests/architecture/test_archive_filename_hygiene.py \
  tests/architecture/test_operator_kernel_routes.py \
  tests/architecture/test_operator_kernel_config_loading.py -q
# 13 passed
```

```text
python -m py_compile \
  backend/app/services/admin/admin_bank_service.py \
  backend/app/services/transactions_service.py
# passed
```

Full local pytest was attempted but not counted as green in this sandbox,
because the local environment lacks `sqlalchemy`. The supplied CI logs did
have dependencies installed and showed one pytest failure only; that exact
failure is repaired and guarded here.

## Not claimed

- GitHub CI green for the new archive;
- full pytest green for the new archive;
- frontend build green for the new archive;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next step

Next safe step: `1447 — fresh CI rerun proof / release-gate preparation`,
or another log-repair cycle if new logs show failures.
