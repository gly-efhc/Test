# EFHC — ЦИКЛЫ 1301–1400
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `WORK_CYCLES_1301-1400_FRONTEND_RECOVERY_EXTENSION_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.


# План циклов 1301-1400: расширение восстановления frontend

Статус: detailed extension plan.
Дата: 2026-05-21.
Архивная версия: v168_73.

## 1. Назначение

Документ продолжает план 1268-1320 и заранее фиксирует следующие
циклы frontend-восстановления. Он не заменяет текущий план 1268-1320,
а расширяет его до диапазона 1400, чтобы следующие проходы не
превращались в хаотичные визуальные правки.

Главное правило остаётся прежним: сначала смысл страницы и канон
функций, затем структура, затем код, затем guard, затем отчёт.

## 2. Циклы 1301-1320: завершение текущего блока

### 1301 — Ranks show-me focus

Цель: кнопка `Показать меня` должна находить пользователя в рейтинге
и показывать ближайших конкурентов выше и ниже.

Сделать:

- проверить текущий источник позиции пользователя;
- реализовать focus/scroll или безопасный focused subset;
- не показывать `tg_id`;
- сохранить вертикальные карточки игроков.

### 1302 — Ranks proof pass

Цель: закрыть Ranks как восстановленный экран.

Сделать:

- проверить фильтры только `kWh` и `Referrals`;
- проверить отсутствие каталога 12 Energy levels;
- проверить current user pinned card;
- добавить guard и отчёт.

### 1303-1310 — Profile, Wallet, History, FAQ

Цель: восстановить профильный контур.

Сделать:

- Profile как отдельная страница `/web-profile`;
- VIP и Active индикаторы всегда видимы;
- Wallet только список подключённых кошельков;
- History как общая история аккаунта;
- FAQ как компактное вертикальное дерево;
- не возвращать Profile overlay как основной путь.

### 1311-1316 — HUB, Browser-Shop, USDT

Цель: восстановить публичные переходы и Web3-витрину.

Сделать:

- HUB строго две равные кнопки;
- VIP NFT как ссылка;
- Browser-Shop как отдельная Web3-страница;
- крупные товарные/NFT-подобные карточки;
- TON payment proof;
- USDT возвращать только после payment-road audit.

### 1317-1320 — Admin recovery start

Цель: вернуть Admin к операторской панели.

Сделать:

- главная Admin как список разделов;
- внутри каждой функции график/статистика сверху;
- действия и таблицы ниже;
- debug только в Diagnostics;
- route inventory перед удалением или переносом.

## 3. Циклы 1321-1330: Panels deep recovery

### 1321 — panel source audit after first UI pass

Проверить, что данные панели реально содержат дату активации, дату
деактивации и источник remaining seconds.

### 1322 — panel countdown contract hardening

Закрепить backend/frontend контракт обратного отсчёта панели без
использования возраста панели как замены.

### 1323 — panel runtime countdown precision

Проверить, что runtime countdown не отстаёт от server/source time и
не уходит в отрицательное значение.

### 1324 — panel generation seconds relation

Проверить связь: панель теряет секунды, а generation получает секунды
в расчёте kWh.

### 1325 — panel archive boundary

Разделить активные и архивные панели без удаления данных и без
потери истории.

### 1326 — panel activation affordability states

Показать простые состояния: можно активировать, не хватает EFHC,
ошибка backend. Не выводить debug.

### 1327 — panel mobile card proof

Проверить мобильную карточку панели на ширину, переносы, кнопки и
обратный отсчёт.

### 1328 — panel admin visibility audit

Проверить, какие данные панели должны быть видны пользователю, а какие
только Admin.

### 1329 — panel tests and guards consolidation

Объединить guards по Panels в устойчивый набор без изменения смысла
экономики.

### 1330 — panel recovery verdict

Дать честный вердикт: что восстановлено, что требует backend/migration,
что не заявляется как готовое.

## 4. Циклы 1331-1340: money and history surfaces

### 1331 — History endpoint map

Составить карту источников History: покупки, обмен, вывод, бонусы,
панели.

### 1332 — History UI minimal shell

Создать общий интерфейс History без перегруза и без wallet-only логики.

### 1333 — History filters

Добавить фильтры `All`, `Purchases`, `Exchange`, `Withdraw`, `Bonuses`,
`Panels`.

### 1334 — Exchange history handoff

На Exchange оставить только ненавязчивую кнопку перехода к History.

### 1335 — Wallet/history boundary guard

Зафиксировать, что Wallet не становится общей финансовой историей.

### 1336 — Withdraw history alignment

Проверить, как выводы отображаются в общей истории аккаунта.

### 1337 — Bonus history alignment

Проверить начисления бонусов и реферальных бонусов в History.

### 1338 — Purchases history alignment

Проверить покупку EFHC, панели, Shop и VIP-ссылки.

### 1339 — History mobile proof

Проверить мобильную читаемость History и отсутствие горизонтального
скролла.

### 1340 — money surfaces verdict

Дать вердикт по money/history layer без fake release-ready.

## 5. Циклы 1341-1350: Browser-Shop and payments

### 1341 — Browser-Shop product model audit

Проверить текущие товары, цены, валюты и public/private поля.

### 1342 — Browser-Shop Web3 visual cards

Перестроить карточки под Web3-витрину с крупным визуальным центром.

### 1343 — TON payment UI proof

Проверить TON-покупку без вывода payload, endpoint, wallet/memo/copy.

### 1344 — USDT payment-road explanation

Дать в чате простое объяснение, что именно нужно проверить перед
возвратом USDT-кнопки.

### 1345 — USDT backend route audit

Проверить backend/watcher/intent поддержку USDT без публичного UI.

### 1346 — USDT storefront decision

Если support подтверждён, вернуть USDT как нормальную кнопку оплаты.
Если нет — зафиксировать blocker.

### 1347 — VIP NFT link proof

Проверить, что VIP NFT остаётся ссылкой, а не тяжёлой NFT-панелью.

### 1348 — bonus packages question pack

Подготовить отдельный пакет вопросов по bonus packages, если их
возвращение всё ещё нужно.

### 1349 — Browser-Shop no-debug guard

Guard против wallet/memo/copy/debug/payload/endpoint в публичной
витрине.

### 1350 — Browser-Shop verdict

Честный вердикт по Shop: TON, USDT, VIP link, blockers.

## 6. Циклы 1351-1360: Admin operator console

### 1351 — Admin route inventory

Составить route map по всем Admin backend/frontend дорогам.

### 1352 — Admin home grid

Главная Admin: крупные карточки разделов без debug dump.

### 1353 — Admin Users page

Users: статистика сверху, список/поиск/действия ниже.

### 1354 — Admin Bank page

Bank: график/статистика банка, mint/burn/transfer/history ниже.

### 1355 — Admin Withdrawals page

Withdrawals: статусы, очереди, approve/reject/cancel без
удаления истории.

### 1356 — Admin Shop page

Shop: товары, платежи, статусы, без смешивания с публичной витриной.

### 1357 — Admin Tasks page

Tasks: задания, награды, ads, защита от double-claim.

### 1358 — Admin Reports page

Reports: отчёты, аудит, change reports, без публичного debug.

### 1359 — Admin Diagnostics page

Diagnostics: технические сведения, logs, probes, route proof.

### 1360 — Admin System page

System: настройки и системные guard-состояния, если route существует.

## 7. Циклы 1361-1370: mobile and visual proof

### 1361 — mobile viewport 390 audit

Проверить все публичные экраны в узком mobile viewport.

### 1362 — desktop/browser audit

Проверить browser/PWA view без Telegram `tg_id`.

### 1363 — Telegram WebApp audit

Проверить Telegram entry, MainButton, BackButton и viewport safe area.

### 1364 — no horizontal scroll guard

Создать guard/QA на отсутствие горизонтального скролла.

### 1365 — contrast guard

Проверить тёмную тему, muted text, disabled text и карточки.

### 1366 — button consistency guard

Проверить одинаковую высоту важных кнопок и HUB-кнопок.

### 1367 — progress bar consistency

Проверить Energy, Referrals и возможные panel/progress bars.

### 1368 — screenshots before/after protocol

Подготовить обязательный screenshot QA протокол для live проверки.

### 1369 — Dragon/Web3 visual alignment audit

Сравнить EFHC с визуальным направлением Dragon без копирования бренда.

### 1370 — visual proof verdict

Дать вердикт по visual layer с перечислением оставшихся дефектов.

## 8. Циклы 1371-1380: runtime and Docker proof

### 1371 — Docker compose smoke

Проверить docker compose без `down -v`.

### 1372 — frontend runtime smoke

Проверить главные public routes в запущенном frontend.

### 1373 — backend health smoke

Проверить `/api/health` и критические API.

### 1374 — browser login smoke

Проверить login/demo page без Telegram.

### 1375 — Telegram return URL audit

Проверить return URL и Telegram entry flow.

### 1376 — service worker smoke

Проверить, что service worker не ломает свежий frontend.

### 1377 — manifest validation

Проверить PWA manifest, icons, start_url, display standalone.

### 1378 — tunnel diagnostic separation

Не смешивать EFHC runtime с Cloudflare quick tunnel errors.

### 1379 — runtime smoke report

Создать отчёт runtime smoke без fake green.

### 1380 — Docker/runtime verdict

Дать честный вердикт по Docker/browser/runtime.

## 9. Циклы 1381-1390: final guards and docs sync

### 1381 — frontend route guard refresh

Обновить route checker под фактические frontend routes.

### 1382 — page element matrix sync

Синхронизировать matrix с фактическим кодом.

### 1383 — component registry sync

Синхронизировать component registry с новыми shell/components.

### 1384 — visual elements registry sync

Синхронизировать visual elements registry.

### 1385 — do-not-touch guard sync

Обновить запреты после code passes.

### 1386 — Q/A and transcript sync

Обновить Q/A register и CHAT_TRANSCRIPT без подмены одного другим.

### 1387 — tests catalog sync

Обновить TESTS_CATALOG и список frontend guards.

### 1388 — reports index sync

Обновить REPORTS_INDEX и generated JSON registry.

### 1389 — Healer frontend regression consolidation

Внести все frontend-регрессии в Healer, если они подтверждены.

### 1390 — document-layer audit

Проверить, что временные документы не попали в SSOT.

## 10. Циклы 1391-1400: release decision preparation

### 1391 — frontend release readiness evidence map

Собрать карту доказательств готовности frontend.

### 1392 — unresolved blockers list

Составить честный список blockers.

### 1393 — user-facing screen checklist

Закрыть checklist по всем публичным экранам.

### 1394 — admin screen checklist

Закрыть checklist по Admin.

### 1395 — payment surfaces checklist

Закрыть checklist по Shop, Exchange, Withdraw, History.

### 1396 — browser/PWA checklist

Закрыть checklist browser/PWA.

### 1397 — Telegram checklist

Закрыть checklist Telegram WebApp.

### 1398 — final visual regression audit

Провести финальный visual regression audit.

### 1399 — release candidate package audit

Проверить ZIP: FLAT, без мусора, без wrapper-folder, без cache.

### 1400 — frontend recovery verdict

Дать итоговый вердикт: готово, частично готово или не готово.
Нельзя писать release-ready без live proof, Docker/runtime proof и
прохождения проверок.

---

## Источник: `WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN

Purpose: continue Admin recovery after the 1268-1320 frontend recovery range.

## 1321-1325 — Admin users and bank polish

- 1321: Users page statistics and actions audit. DONE in v168_99.
- 1322: Users table readability and safe operator actions. DONE in v169_00.
- 1323: Bank page statistics and ledger boundary. DONE in v169_01
- 1324: Bank action confirmations and idempotency proof. DONE in v169_03.
- 1325: Admin interactive dashboard for banking simulator. DONE in v169_04.

## 1326-1338 — Admin Dashboard UI Kit, migration and repair wave

- 1326: Admin Sandbox Porting Map and Dashboard UI Kit foundation.
  DONE in v169_05.
- 1327: Admin UI Kit adoption for Bank / Users operator screens.
  DONE in v169_06.
- 1328: Withdrawals operator decision template on shared UI Kit.
  DONE in v169_07.
- 1329: Out-of-plan audit repair for v169_06/v169_07 P0/P1/P2 findings.
  DONE in v169_08.
- 1330: CI logs repair and frontend code standard actualization.
  DONE in v169_09.
- 1331: Frontend dependency migration to Next.js 16.2.6 / React 19.2.6 /
  Tailwind CSS v4.3. DONE in v169_10.
- 1332: Tailwind config removal and frontend docs actualization.
  DONE in v169_11.
- 1333: CI logs 71012972623 repair: test dependency install and public
  npm lockfile registry cleanup. DONE in v169_12.
- 1334: CI logs 71033084031 repair: pytest freezegun install sanity.
  DONE in v169_13.
- 1335: CI logs 71056336346 repair: test dependency bootstrap lock.
  DONE in v169_14.
- 1336: Operator Kernel optimization and archive acceleration.
  DONE in v169_15.
- 1337: CI logs 71060357686 repair: remove freezegun dependency
  from core test. DONE in v169_16.
- 1338: CI logs 71459043999 repair: stale guard and ruff cleanup.
  DONE in v169_17.
- 1339: Shop admin actions and Web3 payment separation on UI Kit. DONE in v169_18.
- Compatibility phrase: 1332: Shop admin actions SHIFTED from 1331, then shifted to 1333, then to 1334.
- Compatibility phrase: 1354: Admin recovery checkpoint report SHIFTED again to 1355.

## 1340-1352 — Tasks, reports, diagnostics and public UI wave

- 1340: Audit hotfix: requirements-dev sync, webhook secret guard and
  Operator Kernel config loading. DONE in v169_19.
- 1341: Admin Tasks catalog UX. DONE in v169_20.
- 1342: Admin Tasks execution trace boundary. DONE in v169_21.
- 1343: Reports dashboard visual pass. DONE in v169_22.
- 1344: Admin Reports export/download boundary. DONE in v169_23.
- 1345: Diagnostics technical-only boundary and public UI interactivity plan.
  DONE in v169_24.
- 1346: Tasks/Reports/Diagnostics proof pass and public UI sandbox audit.
  DONE in v169_25.
- 1347: Public Energy interactive overview. DONE in v169_26.
- 1348: Public Panels activation preview. DONE in v169_27.
- 1349: Public Exchange interactive preview. DONE in v169_28.
- 1350: Public Tasks / Referrals / Ranks engagement. DONE in v169_29.
- 1351: Public Profile / Wallet / History trust layer. DONE in v169_30.
- 1352: Admin UI Kit adoption proof pass. NEXT after public UI wave.

## 1347-1351 — System and route integrity

- 1347: System page real settings audit. SHIFTED after cycle 1340.
- 1348: Admin route inventory reconciliation. SHIFTED after cycle 1340.
- 1349: Missing admin page list. SHIFTED after cycle 1340.
- 1350: No debug on public admin home guard. SHIFTED after cycle 1340.
- 1351: Admin route integrity proof pass. SHIFTED after cycle 1340.

## 1348-1357 — Admin visual recovery hardening

- 1347: Shared admin stats strip. SHIFTED from 1346.
- 1348: Shared admin action table. SHIFTED from 1347.
- 1349: Shared admin empty/error states. SHIFTED from 1348.
- 1350: Admin mobile readability proof. SHIFTED from 1349.
- 1351: Admin Russian operator language guard. SHIFTED from 1350.
- 1352: Admin no raw payload public guard. SHIFTED from 1351.
- 1353: Admin screenshot QA preparation. SHIFTED from 1352.
- 1354: Admin docs and SSOT route map update. SHIFTED from 1353.
- 1355: Admin regression proof pass. SHIFTED from 1354.
- 1356: Admin recovery checkpoint report. SHIFTED from 1355.
- 1357: Admin recovery checkpoint report. SHIFTED from 1356; requires next range extension document.

## Archive numbering correction — 2026-05-26

- Cycle 1322 is canonical `v169_00`, not invalid alias `v168_100`.
- Cycle 1323 is canonical `v169_01`, not invalid alias `v168_101`.
- Emergency audit/guard pass is `v169_02`.

## 2026-05-26 user correction — admin dashboard target

The user clarified that Admin must become an interactive analytics dashboard
for the banking simulator, not a static/simple admin panel. The main Admin
screen must include dynamic visual financial-flow and user-activity analytics,
filters by game days/steps, zoom/scale controls and live refresh behaviour.
Cycle 1325 implements the first code-level home dashboard pass without adding
new chart dependencies.


## 2026-05-27 cycle 1326 remap

The old internal plan `Withdrawals state-machine UI audit` is not active
for cycle 1326. The user reassigned cycle 1326 to:

`Admin Sandbox Porting Map and Dashboard UI Kit foundation`.

This remap keeps the project focused on Admin Dashboard -> Sandbox
Porting Map -> Admin UI Kit -> Interactive Admin System.

## 2026-05-27 — Cycle 1328 completed

Cycle 1328 is completed in `v169_07` as:

`Withdrawals operator decision template on shared UI Kit`.

User answers fixed the priority:

- Withdrawals state-machine panel: yes.
- Mobile-admin readability is the main priority.
- Desktop-admin is additional, not primary.
- Песочница must be actively used as donor-source for functions/elements.
- Public UI interactivity is possible, but must be handled as a separate route
  and not mixed with Admin.

Next planned cycle remains:

`1329 — Shop admin actions and Web3 payment separation on UI Kit`.


## 2026-05-27 — Out-of-plan audit repair remap

User ordered an out-of-plan cycle to fix audit findings from the v169_06 /
cycle 1327 audit. The actual repair is applied on top of current HEAD v169_07.

Cycle remap:

- `1329` becomes `Out-of-plan audit repair for v169_06/v169_07 P0/P1/P2 findings`.
- Previous planned `1329 — Shop admin actions and Web3 payment separation on UI Kit` shifts to `1330`.
- All following admin recovery cycles shift forward by one.
- The final checkpoint moves to `1351` and must be covered by a future range-extension document.

Repair scope: admin route guard, hardcoded admin tg_id removal, configurable
OpenAPI docs URLs, runtime requirements hygiene, legacy admin header cleanup,
reports overview read-only aggregation, migration/dependency policy docs and
architecture guards.


## 2026-05-27 — Cycle 1330 log repair and code standard actualization

User supplied `logs_70999423442.zip`. The only failing gate in that log
was `pytest -q`; frontend build was green in CI under the current
Next.js 14 dependency line.

Cycle remap:

- `1330` becomes `CI logs repair and frontend code standard actualization`.
- Previous planned `1330 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1331`.
- All later admin recovery cycles shift forward by one.
- The final checkpoint moves to `1352`.

Frontend dependency migration status:

- Documentation and canon transition: started and updated.
- Actual `package.json` dependency migration: not started in this cycle.
- Reason: current task was log repair + documentation actualization;
  dependency upgrade requires a controlled migration pass with lockfile,
  Tailwind v4 CSS-first conversion, Next config review and full CI.

Target frontend standard remains mandatory:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3.

## Historical guard compatibility note

Previous cycle 1329 audit-repair guard expected the phrase
`1330: Shop admin actions` after the first out-of-plan remap. Cycle
1330 is now another out-of-plan repair, so active Shop work shifts to
`1331: Shop admin actions and Web3 payment separation on UI Kit`.

Compatibility phrase: `1330: Shop admin actions` was `SHIFTED from 1329`.
Compatibility phrase: `1351: Admin recovery checkpoint report`.


## 2026-05-27 — Cycle 1331 dedicated frontend migration

User ordered a dedicated migration-cycle before returning to the planned Admin
Shop cycle. Therefore cycle 1331 is reassigned to:

`Frontend dependency migration to Next.js 16.2.6 / React 19.2.6 /
Tailwind CSS v4.3`.

Cycle remap:

- `1331` becomes the actual dependency migration-cycle.
- Previous planned `1331 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1332`.
- All later admin recovery cycles shift forward by one.
- The final checkpoint moves to `1353`.

Migration result:

- `frontend/package.json` and `frontend/package-lock.json` now use the
  target dependency line.
- Tailwind CSS is converted to v4 CSS-first `@theme` in global CSS.
- `next dev --turbo` is the dev script.
- `next lint` is removed from scripts and replaced with TypeScript sanity
  because it is not a valid Next 16 project script path here.

Compatibility phrase: `1331: Shop admin actions` is now `SHIFTED from 1330`
and then shifted again to `1332` after cycle 1331 migration.
Compatibility phrase: final checkpoint moves to `1352` before cycle 1331 and
then to `1353` after the migration-cycle.

## 2026-05-27 — Cycle 1332 Tailwind config removal

User ordered removal of the unnecessary Tailwind legacy config file after
the completed migration to Next.js 16.2.6 / React 19.2.6 / Tailwind CSS
v4.3.

Cycle remap:

- `1332` becomes `Tailwind config removal and frontend docs actualization`.
- Previous planned `1332 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1333`.
- All later Admin recovery cycles shift forward by one.
- The final checkpoint moves to `1354`.

Tailwind cleanup result:

- `frontend/tailwind.config.js` is removed from HEAD.
- Tailwind v4 CSS-first `@theme` in `frontend/src/styles/globals.css`
  remains the active theme source.
- `frontend/postcss.config.js` remains the Tailwind v4 PostCSS adapter
  wiring.

Compatibility phrase: `1332: Shop admin actions` is now shifted to
`1333: Shop admin actions and Web3 payment separation on UI Kit`.
Compatibility phrase: final checkpoint moves to `1354` after cycle 1332.


## 2026-05-27 — Cycle 1334 CI logs 71033084031 repair

User supplied `logs_71033084031.zip`. The only failing gate in that log
was `pytest -q`, caused by missing `freezegun` during collection of
`tests/core/test_core_math_econ.py`. Other gates in the log were green:
`npm ci`, `npm build`, `ruff`, `flake8`, `mypy`, `bandit`, `compileall`
and `alembic upgrade head`.

Cycle remap:

- `1334` becomes `CI logs 71033084031 repair: pytest freezegun install sanity`.
- Previous planned `1334 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1335`.
- All later Admin recovery cycles shift forward by one.
- The final checkpoint moves to `1356`.

Repair scope: keep test-only dependency separation, but make CI prove
`requirements-test.txt` exists, install it before pytest and import
`freezegun` before running the full pytest gate.

Compatibility phrase: `1334: Shop admin actions` was active before this
log-repair cycle and is now `SHIFTED to 1335`.
Compatibility phrase: `1355: Admin recovery checkpoint report` was shifted
again to `1356`.
Compatibility phrase: `1353: Admin recovery checkpoint report` was an older
checkpoint after the dedicated frontend migration and is now shifted forward.


## 2026-05-27 — Cycle 1335 CI logs 71056336346 repair

User supplied `logs_71056336346.zip`. The only failing gate in the uploaded
log is pytest collection with `ModuleNotFoundError: No module named
'freezegun'`. Frontend build is green in that log under Next.js 16.2.6.

Cycle remap:

- `1335` becomes `CI logs 71056336346 repair: test dependency bootstrap lock`.
- Previous planned `1335 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1336`.
- The final checkpoint moves from `1356` to `1357`.

Repair canon:

- `requirements-test.txt` is the single pytest dependency bootstrap file.
- CI installs runtime requirements first and test requirements second.
- CI imports pytest/bootstrap dependencies before `pytest -q`.
- Runtime requirements stay clean from `freezegun`.

Compatibility phrase: `1335: Shop admin actions` was active before this
log-repair cycle and is now `SHIFTED to 1336`.
Compatibility phrase: `1356: Admin recovery checkpoint report` is now
`SHIFTED to 1357`.

## 2026-05-29 — Cycle 1336 Operator Kernel optimization

User ordered full archive optimization and acceleration by
`EFHC_BOT_OPERATOR_KERNEL_TZ_v001.md` before returning to the planned Shop
Admin cycle.

Cycle remap:

- `1336` becomes `Operator Kernel optimization and archive acceleration`.
- Previous planned `1336 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1337`.
- The final checkpoint moves from `1357` to `1358`.

Implemented scope:

- `ops/operator_kernel/` local Python MVP;
- file map, task classifier, route resolver and context capsule;
- patch planner, validation router and archive hygiene;
- report, cycle and healer indexes;
- permission, patch and validation NORM documents;
- AI reading documents integrated with the kernel.

Compatibility phrase: `1336: Shop admin actions` was active before this
optimization cycle and is now `SHIFTED to 1337`.
Compatibility phrase: `1357: Admin recovery checkpoint report` is now
`SHIFTED to 1358`.

## 2026-05-29 — Cycle 1337 CI logs 71060357686 repair

User supplied `logs_71060357686.zip`. The only failing gate in the visible
summary was `pytest -q`, caused by `ModuleNotFoundError: No module named
'freezegun'` during collection of `tests/core/test_core_math_econ.py`.

Cycle remap:

- `1337` becomes `CI logs 71060357686 repair: remove freezegun dependency
  from core test`.
- Previous planned `1337 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1338`.
- The final checkpoint moves from `1358` to `1359`.

Repair canon:

- CI/workflow files are manual-control files and were not edited.
- The core economics test no longer imports `freezegun`.
- Deterministic time delta proof uses standard-library UTC datetime values.
- Runtime requirements stay free from `freezegun`.

Compatibility phrase: `1337: Shop admin actions` was active before this
log-repair cycle and is now `SHIFTED to 1338`.
Compatibility phrase: `1358: Admin recovery checkpoint report` is now
`SHIFTED to 1359`.


## 2026-05-29 — Cycle 1338 CI logs 71459043999 repair

User supplied `logs_71459043999.zip`. The final gate summary showed
pytest and ruff failures. Frontend `npm ci` and `npm build` were green
in the uploaded log.

Cycle remap:

- `1338` becomes `CI logs 71459043999 repair: stale guard and ruff
  cleanup`.
- Previous planned `1338 — Shop admin actions and Web3 payment separation
  on UI Kit` shifts to `1339`.
- The final checkpoint moves from `1359` to `1360`.

Repair canon:

- stale guards must be moved to the active canon, not force rollback;
- active frontend standard remains Next.js 16.2.6, React 19.2.6 and
  Tailwind CSS v4.3;
- generated frontend artifacts such as `.tsbuildinfo` are forbidden;
- Operator Kernel caches must skip historical original-source/chat folders;
- CI/workflow files remain manual-control files and were not edited.

Compatibility phrase: `1338: Shop admin actions` was active before this
log-repair cycle and is now `SHIFTED to 1339`.
Compatibility phrase: `1359: Admin recovery checkpoint report` is now
`SHIFTED to 1360`.


## 2026-05-29 — Cycle 1339 green CI checkpoint and Shop Admin completion

User supplied `logs_71469302879.zip` and stated logs are green. The archive
was opened and Gate summary confirmed all gate steps passed. No log repair was
needed.

Cycle 1339 completed the planned Shop Admin task:

`Shop admin actions and Web3 payment separation on UI Kit`.

Result:

- `AdminShopWeb3SeparationPanel` added;
- `/admin/shop` connected to the shared Admin UI Kit;
- admin catalog actions are separated from Web3 payment intent / memo /
  watcher flow;
- CI/workflow files were not changed;
- next active cycle is `1340 — Admin Tasks catalog UX`.

Compatibility phrase: `1339: Shop admin actions and Web3 payment separation on UI Kit. DONE in v169_18.`
Compatibility phrase: `1340: Admin Tasks catalog UX`.


## Cycle 1340 audit hotfix note

Cycle 1340 was inserted as an audit hotfix. Planned Admin Tasks work is shifted to cycle 1341. CI/workflow files were not changed.

## 2026-05-30 — Cycle 1341 — Admin Tasks catalog UX

Cycle 1341 completed the planned Admin Tasks catalog UX work in `v169_20`.

Result:

- `AdminTasksCatalogUxPanel` added;
- `/admin/tasks` connected to the shared Admin UI Kit;
- route diagnostics are removed from the normal top operator surface;
- task catalog, queue filter, flow map and mobile task deck are visible before
  the detailed moderation list;
- approve/reject moderation remains idempotent;
- CI/workflow files were not changed;
- next active cycle is `1342 — Admin Tasks execution trace boundary`.

Compatibility phrase: `1341: Admin Tasks catalog UX. DONE in v169_20.`
Compatibility phrase: `1342: Admin Tasks execution trace boundary`.

## 2026-05-30 — Cycle 1342 — Admin Tasks execution trace boundary

Cycle 1342 completed the Admin Tasks execution trace boundary in `v169_21`.

Result:

- `AdminTasksExecutionTracePanel` added;
- `/admin/tasks` now loads sanitized `task_bonus` transfer traces;
- the trace source is admin-only `/admin/logs/transfers`;
- raw `meta` and raw cursor payloads are not displayed;
- idempotency keys are shortened before rendering;
- public `/tasks` still has no hidden execution history surface;
- CI/workflow files were not changed;
- next active cycle is `1343 — Reports dashboard visual pass`.

Compatibility phrase: `1342: Admin Tasks execution trace boundary. DONE in v169_21.`
Compatibility phrase: `1343: Reports dashboard visual pass`.

## 2026-05-30 — Cycle 1343 — Reports dashboard visual pass

Cycle 1343 completed the Reports dashboard visual pass in `v169_22`.

Result:

- `AdminReportsVisualDashboardPanel` added;
- `/admin/reports` connected to the shared Admin UI Kit;
- the normal top reports surface no longer shows route diagnostics;
- scope filters, report window filters, zoom and clickable chart points were
  added;
- the uploaded `Песочница.xz` archive was opened and used as a donor source
  for interactive chart, section cards, data-table and report-row patterns;
- no backend economic mutation was added to reports;
- CI/workflow files were not changed;
- next active cycle is `1344 — Admin Reports export/download boundary`.

Compatibility phrase: `1343: Reports dashboard visual pass. DONE in v169_22.`
Compatibility phrase: `1344: Admin Reports export/download boundary`.

## 2026-05-31 — Cycle 1344 — Admin Reports export/download boundary

Cycle 1344 completed the Reports export/download boundary in `v169_23`.

Result:

- `AdminReportsExportDownloadPanel` added;
- `/admin/reports` now has visual dashboard plus export surface;
- export formats are JSON, CSV and TXT;
- export scope is sanitized to meta, counters, facts and optional notes;
- export is client-side and uses browser Blob download;
- the uploaded `Песочница.xz` archive was opened and used as a donor source
  for Refine `useExport`, `ExportButton`, TMA download and list/detail
  export patterns;
- no backend mutation, payment action or CI/workflow change was added;
- next active cycle is `1346 — Tasks/Reports/Diagnostics proof pass`.

Compatibility phrase: `1344: Admin Reports export/download boundary. DONE in v169_23.`
Compatibility phrase: `1345: Diagnostics technical-only boundary and public UI interactivity plan`.


## 2026-05-31 — Cycle 1345 Diagnostics technical-only boundary

Cycle 1345 completed in `v169_24`.

Done:

- `/admin/diagnostics` received `AdminDiagnosticsTechnicalBoundaryPanel`;
- Diagnostics remains technical-only and admin-only;
- route health, endpoint labels and helper facts stay inside Diagnostics;
- `Песочница.xz` was opened and used as donor-source for tabs, chart signal,
  status cards and selected detail patterns;
- public UI interactivity variants and implementation order were documented in
  `docs/frontend/FRONTEND_PUBLIC_INTERACTIVITY_IMPLEMENTATION_PLAN.md`;
- `ci.yml` was not changed.

Next active cycle: `1346 — Tasks/Reports/Diagnostics proof pass`.

## 2026-05-31 — Cycle 1346 proof pass and public UI sandbox audit

Cycle 1346 completed in `v169_25`.

Done:

- Tasks / Reports / Diagnostics proof pass documented;
- old `Песочница.xz` and five new Telegram Mini App template archives were
  opened as donor sources;
- public UI interactivity adoption map created;
- useful patterns selected: Theme / Viewport CSS vars, BackButton,
  MainButton intent, Haptic feedback, mobile sections/cells,
  DisplayData rows and ErrorBoundary retry;
- framework runtimes were rejected: Nuxt, Vue, Solid, Vanilla renderer,
  jQuery view layer;
- Operator Kernel now has `public_ui_interactivity` classification and route;
- `ci.yml` was not changed.

Next active cycle: `1347 — Public Energy interactive overview`.

## 2026-05-31 — Cycle 1347 Public Energy interactive overview

Cycle 1347 completed in `v169_26`.

Done:

- `PublicEnergyInteractiveOverview` added;
- `/` received mobile-first public Energy overview;
- tabs, SVG flow, compact facts and safe CTA were added;
- public UI remained free from admin diagnostics and raw payload;
- Песочница was used as donor-source;
- `ci.yml` was not changed.

Compatibility phrase: `1347: Public Energy interactive overview. DONE in v169_26.`

## 2026-05-31 — Cycle 1348 Public Panels activation preview

Cycle 1348 completed in `v169_27`.

Done:

- `PublicPanelsActivationPreview` added;
- `/panels` received activation preview for `100 EFHC`;
- main / bonus / total activation balance facts were added;
- panel activation economics stayed unchanged;
- Песочница was used as donor-source;
- `ci.yml` was not changed.

Compatibility phrase: `1348: Public Panels activation preview. DONE in v169_27.`

## 2026-05-31 — Cycle 1349 Public Exchange interactive preview

Cycle 1349 completed in `v169_28`.

Done:

- `PublicExchangeInteractivePreview` added;
- `/exchange` received interactive preview before the conversion form;
- only `kWh -> EFHC` remained active;
- quick actions and reverse exchange did not return;
- Песочница was used as donor-source;
- `ci.yml` was not changed.

Compatibility phrase: `1349: Public Exchange interactive preview. DONE in v169_28.`

## 2026-05-31 — Cycle 1350 Public Tasks / Referrals / Ranks engagement

Cycle 1350 completed in `v169_29`.

Done:

- `PublicEngagementPreview` added;
- `/tasks`, `/referrals` and `/ranks` now have mobile-first public
  engagement preview surfaces;
- Tasks preview keeps hidden execution history forbidden;
- Referrals preview keeps active/total/level progress visible;
- Ranks preview keeps position, score and focus CTA visible;
- Песочница was used as donor-source for DisplayData, cells, mobile cards
  and safe haptic tap patterns;
- `ci.yml` was not changed.

Compatibility phrase: `1350: Public Tasks / Referrals / Ranks engagement. DONE in v169_29.`
Compatibility phrase: `1351: Public Profile / Wallet / History trust layer.`

## 2026-05-31 — Cycle 1351 Public Profile / Wallet / History trust layer

Cycle 1351 completed in `v169_30`.

Done:

- `PublicProfileTrustLayer` added;
- `/web-profile` received a mobile-first public trust summary;
- profile, wallet and history facts are visible without raw payload;
- backend routes and economics were not changed;
- Песочница was used as donor-source;
- `ci.yml` was not changed.

Compatibility phrase: `1351: Public Profile / Wallet / History trust layer. DONE in v169_30.`

## 2026-05-31 — Cycle 1352 ZIP encoding and wallets CRUD hotfix

Cycle 1352 completed in `v169_31` as an out-of-plan hotfix.

Done:

- two problematic original-source markdown filenames were renamed to ASCII;
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/` keeps exactly
  15 markdown files after Linux extraction;
- `wallets_crud.py` now imports `WalletBinding` from the canonical
  `app.models.wallets_models` module;
- `test_document_retention_guard.py` and cycle 1352 guard protect the fix;
- Песочница was opened as donor-source, but no foreign runtime code was used;
- `ci.yml` was not changed.

Shift:

- planned `1352 — Admin UI Kit adoption proof pass` moved to cycle 1353.

Compatibility phrase: `1352: ZIP encoding and wallets CRUD import hotfix. DONE in v169_31.`
Compatibility phrase: `1353: Admin UI Kit adoption proof pass.`

## 1352-1360 — Extended Admin proof and QA wave

- 1352: ZIP encoding and wallets CRUD import hotfix. DONE in v169_31.
- 1353: Admin UI Kit adoption proof pass. DONE in v169_32.
- 1354: Admin screenshot QA preparation. DONE in v169_33.
- 1355: Admin docs and SSOT route map update. DONE in v169_34.
- 1356: Admin regression proof pass. NEXT.
- 1357: Admin recovery checkpoint report. PLANNED.
- 1358: Public UI screenshot QA preparation. PLANNED.
- 1359: Public UI regression proof pass. PLANNED.
- 1360: Next range extension checkpoint. PLANNED.

Cycle 1353 closes the Admin UI Kit adoption proof pass after the public UI
interactivity wave and after the ZIP encoding hotfix. The previous stale
line `1352: Admin UI Kit adoption proof pass` is superseded by the actual
cycle `1353` because cycle 1352 was reassigned to the P0/P3 hotfix.

## 2026-05-31 — Cycle 1354 Admin screenshot QA preparation

Cycle 1354 completed in `v169_33`. It added the Admin screenshot QA
preparation panel, updated the screenshot QA protocol, and kept CI files
unchanged. The next cycle is `1355 — Admin docs and SSOT route map update`.

## 2026-06-01 — Cycle 1355 Admin docs route map

Cycle 1355 completed in `v169_34`. It added the current Admin docs and
route map after the Admin UI Kit, screenshot QA and public UI waves.
The next cycle is `1356 — Admin regression proof pass`.


## Historical public UI continuation markers

1346: Tasks/Reports/Diagnostics proof pass. DONE in v169_25.
1347: Public Energy interactive overview. NEXT after v169_25.

---

## Источник: `WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md`

# WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN

Purpose: extend work after the original 1321-1350 recovery range.

## Completed

- 1351: Public Profile / Wallet / History trust layer. DONE in v169_30.
- 1352: ZIP encoding and wallets CRUD import hotfix. DONE in v169_31.
- 1353: Admin UI Kit adoption proof pass. DONE in v169_32.
- 1354: Admin screenshot QA preparation. DONE in v169_33.
- 1355: Admin docs and SSOT route map update. DONE in v169_34.
- 1356: Admin regression proof pass. DONE in v169_35.
- 1357: Admin recovery checkpoint report and sandbox map refresh. DONE in v169_36.
- 1358: HIGH audit fixes implementation: admin bottom nav boundary, E2E scaffold, Sale Packages mutations. DONE in v169_37.
- 1359: MEDIUM audit fixes implementation: EFHC deposits idempotency, public error states, AdminPage guard, PWA offline fallback. DONE in v169_37.
- 1360: LOW audit polish: DepositModal wallet open, TonConnect fallback note, no-prefix router docs. DONE in v169_37.

## Active / Next

- 1361: Public UI screenshot QA preparation and residual audit closure. DONE in v169_39.
- 1362: Public UI regression proof pass. DONE in v169_40.
- 1363: Next range extension checkpoint. DONE in v169_41.
- 1364: Public browser screenshot evidence harness and capture manifest. DONE in v169_42 as harness/manifest only; screenshots are not claimed.
- 1365: Public visual beauty pass — Energy, Panels, Exchange. DONE in v169_43 as static/source polish; screenshots are not claimed.
- 1366: Public visual beauty pass — Tasks, Referrals, Ranks. DONE in v169_44 as static/source polish; screenshots are not claimed.
- 1367: Profile / Wallet / History / FAQ visual trust pass. DONE in v169_45 as static/source polish; screenshots are not claimed.
- 1368: HUB / Browser Shop / Withdraw / Ads visual trust pass. DONE in v169_46 as static/source polish; screenshots are not claimed.
- 1369: i18n critical audit repair pass. DONE in v169_47.
- 1370: Public i18n untranslated keys remediation. NEXT.
- 1371: FAQ wave-3 translation and status repair.
- 1372: Telegram Mini App shell polish: viewport, theme, BackButton, safe-area.

## Cycle remap note

By direct user instruction, the original public UI sequence was moved from
1358-1360 to 1361-1363. Cycles 1358-1360 were reassigned to the uploaded
`TZ_FIXES_AUDIT_v169_35.md` correction package.

## Cycle 1353 note

Admin UI Kit proof pass is a frontend/admin proof cycle. It adds a visible
Admin-home proof panel and documents the adoption chain from cycles 1326 to
1345. It does not change CI, backend routes, public UI or EFHC economics.

## Cycle 1354 note

Admin screenshot QA preparation adds a visible Admin-home QA matrix. It
prepares manual screenshots for mobile, Telegram-like, desktop and state
proof without claiming browser screenshot completion. CI files were not
changed.

## Cycle 1355 note

Admin docs and route-map update created
`docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`, refreshed the legacy
Admin routes map and kept CI files unchanged.


## Cycle 1356 note

Admin regression proof pass created
`docs/admin/ADMIN_REGRESSION_PROOF_PASS.md`, audit, generated JSON proof
and architecture guard. It also synchronized `WORK_CYCLES.md` and
`AI_DOCS_INDEX.md` to the active `v169_* / 1350+` phase and moved old
`1176-1230` wording into historical-only context.

## Cycle 1357 note

Admin recovery checkpoint closes the transition after Admin route-map and
regression-proof work. It synchronizes the active cycle/index layer, refreshes
`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` as the navigation map for sandbox references and records that
sandbox archives remain donor references rather than EFHC runtime code.

It also repairs Python dunder-token damage caused by the previous filename
cleanup and adds a guard so `__future__`, `__file__`, `__name__`, `__all__`,
`__init__` and related Python protocol names cannot silently degrade again.

## Cycle 1358 note

HIGH audit fixes implemented the admin/public boundary and sale-package wiring:

- `/admin/*` routes no longer render public bottom navigation;
- `tests/frontend/e2e/` now contains baseline Playwright smoke files;
- `AdminSalePackagesPage.tsx` wires create/edit/toggle calls with
  `Idempotency-Key` and modal confirmation.

## Cycle 1359 note

MEDIUM audit fixes implemented safety and fallback repairs:

- Admin EFHC deposit process/reprocess sends frontend idempotency keys;
- public API 401/403 handling is normalized through `publicApiErrorMessage`;
- `AdminPage.tsx` has component-level `LayoutContext.isAdmin` guard;
- service worker now caches and serves `frontend/public/offline.html`.

## Cycle 1360 note

LOW audit polish implemented final documented fixes:

- `DepositModal.tsx` opens wallet links through Telegram `openLink` or
  `window.open(..., "_blank", "noopener,noreferrer")` instead of replacing
  browser/TMA history;
- static `tonconnect-manifest.json` is marked fallback-only and SSOT says the
  canonical runtime manifest is `/api/tonconnect-manifest`;
- no-prefix `me_routes.py` and `system_routes.py` exceptions are documented in
  code and `docs/NORM/API_CONTRACTS.md`.


## Recheck note before 1361

Before starting public screenshot QA, the audit-fixes implementation was
rechecked. The recheck confirmed FIX-01 through FIX-10 and closed two small
tails: Sale Packages stale `read-only` wording and missing frontend idempotency
on the EFHC deposits force-fulfillment POST.

The active public QA preparation document is:

- `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`.

## Cycle 1361 note

Public UI screenshot QA preparation is complete as a preparation layer in v169_39.
The scope now includes 14 public routes and the related E2E smoke matrix:

- `/`, `/panels`, `/exchange`, `/tasks`, `/referrals`, `/referrals/active`,
  `/referrals/inactive`, `/ranks`, `/web-profile`, `/faq`, `/hub`,
  `/browser-shop`, `/withdraw`, `/ads`;
- 17 admin smoke routes remain covered for boundary regression control.

Residual audit corrections from the v169_37 review were also closed: localized
common error keys, interaction-level POST E2E smokes and multilingual offline
fallback. Actual screenshot capture and public route proof are intentionally left
for 1362.



## Cycle 1362 note

Public UI regression proof pass is complete as a static proof in v169_40.

The proof document is:

- `docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md`.

It maps 14 public surfaces to frontend pages, component families, backend roads,
SSOT/NORM anchors and guards. The pass does not claim actual screenshot capture,
live browser Playwright execution, frontend build or GitHub CI green.

## Cycle 1363 note

Next range extension checkpoint is complete in v169_41. It adds the public
visual extension plan:

- `docs/cycles/WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md`.

The next active work after this checkpoint was 1364 — Public browser screenshot
evidence harness and capture manifest. The checkpoint is documentary and routing
work only: it does not claim browser screenshots, live Playwright execution,
frontend build or GitHub CI green.

## Cycle 1364 note

Public browser screenshot evidence harness is complete in v169_42. It adds:

- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`;
- `tests/frontend/e2e/test_public_screenshot_capture_manifest.py`;
- `tests/architecture/test_public_browser_screenshot_evidence_harness.py`.

The next active work after 1364 was 1365 — Public visual beauty pass: Energy, Panels,
Exchange. No real screenshot evidence, live browser verdict, frontend build or
GitHub CI green is claimed by 1364.


## Cycle 1365 note

Public visual beauty pass for Energy, Panels and Exchange is complete in v169_43.
It adds static/source visual polish and guard coverage for the first public
visual lane. No real screenshot evidence, live browser verdict, frontend build
or GitHub CI green is claimed by 1365.

## Cycle 1366 note

Public visual beauty pass for Tasks, Referrals and Ranks is complete in v169_44.
It adds:

- `docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md`;
- `reports/generated/public_visual_beauty_pass_v169_44.json`;
- `tests/architecture/test_public_visual_beauty_pass_tasks_referrals_ranks.py`.

The next active work after 1366 was 1367 — Profile / Wallet / History / FAQ visual trust pass. No real screenshot evidence, live browser verdict, frontend build or GitHub CI green is claimed by 1366.

## Cycle 1367 note

Profile / Wallet / History / FAQ visual trust pass is complete in v169_45. It adds static/source visual trust polish for account, wallet, history and FAQ surfaces. No real screenshot evidence, live browser verdict, frontend build or GitHub CI green is claimed by 1367.

## Cycle 1368 note

HUB / Browser Shop / Withdraw / Ads visual trust pass is complete in v169_46. It adds:

- `docs/frontend/PUBLIC_VISUAL_TRUST_PASS_HUB_BROWSER_SHOP_WITHDRAW_ADS.md`;
- `reports/generated/public_visual_trust_pass_v169_46.json`;
- `tests/architecture/test_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py`.

The next active work was remapped by user instruction to localization repair. Cycle 1369 is i18n critical audit repair; cycle 1370 is public i18n untranslated keys remediation. No real screenshot evidence, live browser verdict, frontend build or GitHub CI green is claimed by 1368.


## v169_47 / cycle 1369 i18n critical repair

User instruction remapped the next pass from Telegram Mini App shell polish to
localization repair based on the v169.45 i18n audit.

Cycle 1369 repairs:

- C1 English-first player fallback in `frontend/src/lib/i18n.ts`;
- C2/C3 Hindi placeholder drift;
- C4 five empty locale keys across all 13 languages;
- main-shell Russian fallback issues from the audit;
- broken `audit_bot_texts_parity.py`;
- inaccurate flat `complete` labels in `TRANSLATION_STATUS.md`.

The next language work is 1370 public untranslated key remediation and 1371 FAQ
wave-3 translation/status repair. TMA shell polish is moved to 1372 unless a new
user instruction changes the priority.


## Historical next-marker compatibility

1354: Admin screenshot QA preparation. DONE in v169_33.
1355: Admin docs and SSOT route map update. DONE in v169_34.
1356: Admin regression proof pass. NEXT.

---

## Источник: `WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md`

# WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN

Purpose: continue the active v169 public UI lane after the static public
regression proof and range checkpoint.

## Source checkpoint

- 1361: Public UI screenshot QA preparation. DONE in v169_39.
- 1362: Public UI regression proof pass. DONE in v169_40.
- 1363: Next range extension checkpoint. DONE in v169_41.

## Active / Next

- 1364: Public browser screenshot evidence harness and capture manifest. DONE in v169_42 as harness/manifest only; screenshots are not claimed.
- 1365: Public visual beauty pass — Energy, Panels, Exchange. DONE in v169_43 as static/source polish; screenshots are not claimed.
- 1366: Public visual beauty pass — Tasks, Referrals, Ranks. DONE in v169_44 as static/source polish; screenshots are not claimed.
- 1367: Profile / Wallet / History / FAQ visual trust pass. DONE in v169_45 as static/source visual trust polish; screenshots are not claimed.
- 1368: HUB / Browser Shop / Withdraw / Ads visual trust pass. DONE in v169_46 as static/source visual trust polish; screenshots are not claimed.
- 1369: I18N critical audit repair pass. DONE in v169_47.
- 1370: Public i18n untranslated keys remediation. DONE in v169_48 as priority remediation; remaining tail routed to future language/FAQ passes.
- 1371: FAQ wave-3 translation/status repair and semantic alignment repair. DONE across v169_49-v169_50; additional semantic gate continuation in v169_51.
- 1372: FAQ semantic approval gate. DONE in v169_51; TMA/TonConnect work stayed blocked until FAQ semantics were checked.
- 1373: Russian source language canon lock and RU regression audit. DONE in v169_52.
- 1374: Telegram Mini App shell polish — viewport, theme, BackButton, safe-area. DONE in v169_53 as source/static polish; live Telegram client proof is not claimed.
- 1375: TonConnect / Wallet UX proof and range closure / next-audit handoff. DONE in v169_54 as static/source proof; live wallet transaction, Telegram client, browser screenshot, GitHub CI and release-ready verdict are not claimed.

## Lane rules

- Do not import Vue/Solid/Nuxt/Vanilla runtime from sandbox archives.
- Keep Next.js 16.2.6 / React 19.2.6 / Tailwind CSS 4.3.0 as the frontend canon.
- Do not change EFHC economics from visual work.
- Do not expose admin diagnostics to public UI.
- Do not claim screenshot/browser proof without actual evidence.
- Do not claim GitHub CI green unless the user provides GitHub CI proof.
- Keep cycle labels in `docs/cycles/`, `docs/audits/` and `reports/`; keep
  product/frontend/admin filenames semantic.

## 1364 target detail

Public browser screenshot evidence harness should create a clear evidence map
for the 14 public routes:

- `/`, `/panels`, `/exchange`, `/tasks`, `/referrals`, `/referrals/active`,
  `/referrals/inactive`, `/ranks`, `/web-profile`, `/faq`, `/hub`,
  `/browser-shop`, `/withdraw`, `/ads`.

Expected output:

- screenshot evidence manifest;
- browser/device matrix;
- guard that prevents claiming screenshot proof without evidence files or an
  explicit non-claim;
- updated public QA documents.

## 1365-1368 visual focus

The next visual passes should be human-facing, not technical only. Each pass
must improve readability, spacing, hierarchy, empty/loading/error states and
button clarity without changing economic meaning.

## 1369-1371 i18n audit repair focus

The v169.45 i18n audit becomes the active priority before TMA/wallet polish.
Cycle 1369 fixes critical runtime/value blockers. Cycles 1370-1371 should repair
the remaining untranslated public keys and FAQ wave-3 tail.

## 1372-1375 shell/wallet/readiness focus

Telegram Mini App and TonConnect work may use `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` as the reference
navigation map. Any wallet/transaction behavior must pass SSOT/NORM review
before runtime changes.

## 1374-1375 readiness focus

The late range should convert static proof into stronger acceptance evidence:
E2E interactions, boundary screenshots, localization/accessibility checks and a
final readiness checkpoint.


## 1364 completion note

Cycle 1364 created:

- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`;
- `tests/frontend/e2e/test_public_screenshot_capture_manifest.py`;
- `tests/architecture/test_public_browser_screenshot_evidence_harness.py`.

The pass intentionally does not include real screenshots. Actual browser
capture remains controlled by `EFHC_RUN_E2E=1` and `EFHC_CAPTURE_SCREENSHOTS=1`.


## 1365 completion note

Cycle 1365 created source-level visual polish for Energy, Panels and Exchange:

- `docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_ENERGY_PANELS_EXCHANGE.md`;
- `reports/generated/public_visual_beauty_pass_v169_43.json`;
- `tests/architecture/test_public_visual_beauty_pass_energy_panels_exchange.py`.

The pass intentionally does not include real screenshots. Actual browser capture
remains controlled by `EFHC_RUN_E2E=1` and `EFHC_CAPTURE_SCREENSHOTS=1`.


## 1366 completion note

Cycle 1366 created source-level visual polish for Tasks, Referrals and Ranks:

- `docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md`;
- `reports/generated/public_visual_beauty_pass_v169_44.json`;
- `tests/architecture/test_public_visual_beauty_pass_tasks_referrals_ranks.py`.

The pass intentionally does not include real screenshots. Actual browser capture
remains controlled by `EFHC_RUN_E2E=1` and `EFHC_CAPTURE_SCREENSHOTS=1`.

## 1367 completion note

Cycle 1367 created source-level visual trust polish for Profile, Wallet, History and FAQ:

- `docs/frontend/PUBLIC_VISUAL_TRUST_PASS_PROFILE_WALLET_HISTORY_FAQ.md`;
- `reports/generated/public_visual_trust_pass_v169_45.json`;
- `tests/architecture/test_public_visual_trust_pass_profile_wallet_history_faq.py`.

The pass does not claim browser screenshots, live E2E execution, GitHub CI green
or release readiness.


## 1368 completion note

Cycle 1368 created source-level visual trust polish for HUB, Browser Shop, Withdraw and Ads:

- `docs/frontend/PUBLIC_VISUAL_TRUST_PASS_HUB_BROWSER_SHOP_WITHDRAW_ADS.md`;
- `reports/generated/public_visual_trust_pass_v169_46.json`;
- `tests/architecture/test_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py`.

The pass does not claim browser screenshots, live E2E execution, GitHub CI green
or release readiness.


## 1369 completion note

Cycle 1369 repaired the critical i18n audit blockers from the v169.45 audit:

- `frontend/src/lib/i18n.ts` now uses English-first player fallback;
- all 13 locale files have non-empty values for the five previously empty public keys;
- Hindi placeholder drift is repaired for wallet count and withdraw request number;
- public shell hardcoded Russian fallback issues from the audit are repaired;
- `ops/i18n/audit_bot_texts_parity.py` importlib typo is fixed;
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` no longer claims quality-complete status for languages with known FAQ translation tail.

This pass does not claim full translation completion. The remaining public untranslated tail and FAQ wave-3 translation tail are planned for cycles 1370-1371.


## FAQ semantic alignment repair

Before continuing TMA/TonConnect work, cycle 1371 received a corrective semantic alignment pass in v169_50. Changed FAQ translations from v169_49 were checked against Q/A, FAQ approval records and RU/FAQ anchors. The pass corrected EN/wave drift for wallet and Navigation/Rules items.


## 1373 Russian source canon lock

The user explicitly confirmed: if RU FAQ and EN FAQ diverge, RU/FAQ-SSOT is the semantic anchor only after checking Q/A; SSOT itself can regress and must be verified against Q/A. All translations must be from verified Russian meaning. Translating Russian from English is forbidden.

TMA/TonConnect work resumes only after this language-canon lock.


## 1374 completion note

Cycle 1374 completed Telegram Mini App shell polish:

- `docs/frontend/TELEGRAM_MINI_APP_SHELL_POLISH.md`;
- `reports/generated/telegram_mini_app_shell_polish_v169_53.json`;
- `tests/architecture/test_telegram_mini_app_shell_polish.py`.

The pass covers viewport state, Telegram/browser runtime markers, content/device safe-area vars, public route BackButton behavior and TMA shell CSS. It does not claim live Telegram client execution, browser screenshots, GitHub CI green or release readiness.


## 1375 completion note

Cycle 1375 closes the `1351-1375` range. It created:

- `docs/frontend/TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md`;
- `reports/generated/tonconnect_wallet_ux_range_closure_v169_54.json`;
- `tests/architecture/test_tonconnect_wallet_ux_range_closure.py`.

`1376+` is intentionally blocked until a new audit/task is supplied by the user in chat.

Non-claims: no live Telegram client proof, no real TonConnect transaction, no browser screenshot verdict, no GitHub CI green and no release-ready verdict.

---

## Источник: `WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`

# Work cycles 1376-1385 — i18n reaudit and manual translation plan

Status: ACTIVE PLAN.
Source audit: `docs/audits/I18N_REAUDIT_REPORT_V169_54_2026_06_03.md`.
Start archive: `EFHC_Bot_v169_54_chat_24_loaded.zip`.

## Control rule

All translation work after the v169.54 reaudit is manual. No machine bulk-fill,
no English-to-Russian back-translation, and no sandbox-label copying are allowed.
The semantic source remains verified Russian meaning: direct user decisions,
`docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`, FAQ approval layer and Russian
FAQ/SSOT when aligned with Q/A.

## Audit intake summary

The new reaudit confirms that critical i18n findings C1-C4 are closed:
English-first fallback is restored, Hindi placeholder drift is fixed, empty
locale values are fixed, FAQ identical-answer tail is closed, and
`TRANSLATION_STATUS.md` is no longer a false complete claim.

Open work remains:

- 154 public untranslated keys in DE/FR/HI/SW/TR/PL/DA/IT/ES/ID;
- UK public translation tail: CLOSED in cycle 1377;
- `1 kWh = 1 EFHC` formula allowlist treatment: CLOSED in off-queue v169.56;
- `tasks.earning_kicker` and `tasks.demo_daily_detail` game framing: CLOSED in off-queue v169.56 with neutral earning wording;
- two audit scripts clean-checkout preconditions: CLOSED in off-queue v169.56;
- fallback-chain regression guard: CLOSED in off-queue v169.56 and retained for future runs.

## Planned cycles

| Cycle | Target | Scope | Translation mode |
|---:|---|---|---|
| 1376 | I18N reaudit intake + precondition repair | Import reaudit, update cycle/docs, allowlist formula, remove game framing from two task keys, add fallback guard, restore audit script preconditions. | Manual micro-edit only |
| 1377 | UK public translation pass | DONE in v169.57: UK public tails in `public_engagement`, `profile`, `portal`, `energy`, plus small trust/wallet residuals detected by the quality guard. | Manual Ukrainian |
| 1378 | Wave-3 public engagement pass | DONE in v169.58: DE/FR/HI/SW/TR/PL/DA/IT/ES/ID `public_engagement` keys. | Manual per language |
| 1379 | Wave-3 portal/shop pass | DONE in v169.59: Browser Shop / portal / shop_entry keys. | Manual per language |
| 1380 | Wave-3 profile and trust pass | DONE in v169.60: `profile` + `public_profile_trust` guarded public account/trust keys. | Manual per language |
| 1381 | Wave-3 panels/tasks/history pass | DONE in v169.61: `panels`, `tasks`, `history` guarded public UI keys. | Manual per language |
| 1382 | Wave-3 hub/energy/wallet/ranks/referrals tail | Remaining small domains and identical-to-English triage. | Manual per language |
| 1383 | FAQ/i18n semantic gate rerun | Re-run FAQ and locale semantic guards, update translation status. | Review only |
| 1384 | Browser text stress plan | Prepare screenshot/text-overflow evidence plan only; no screenshot claim unless captured. | Review only |
| 1385 | i18n range closure audit | Static/source closure for the manual language range. | Audit only |

## Non-claims

This plan does not claim full translation completion, human linguistic
certification, GitHub CI green, browser screenshots, live Telegram client proof,
or release readiness.

## Off-queue v169.56 process correction

The user requested an out-of-order correction before regular manual translation
continues. It does not consume 1377. The correction locks the i18n process:

- audit scripts must run in clean checkout by default; `--strict` is used only
  when historical work-pass report validation is intentionally required;
- fallback-chain regression is guarded by `tests/architecture/test_i18n_fallback_is_english.py`;
- `1 kWh = 1 EFHC` is a protected rate formula in the identical-value allowlist;
- `game task` is not a forbidden phrase. Neutral earning/action wording
  was preferred there as tone guidance, while the actual ban remains
  gambling, loto, betting and random financial meaning.

Manual translation order remains unchanged: first UK, then narrow wave-3 domain
passes from verified Russian meaning.


## Cycle 1377 result — v169.57

The UK pass was completed manually from verified Russian meaning. It did not auto-translate wave-3 languages. The pass changed `frontend/public/locale/uk.json` only for Ukrainian text plus the UK quality guard.

Scope closed:

- 79 Ukrainian public-facing values reviewed/translated;
- `public_engagement`: ranks, referrals, tasks and tab labels;
- `profile`: account, wallet and history labels;
- `portal`: browser-shop/shop-entry explanatory text;
- `energy`: interactive hints;
- `public_profile_trust` and `wallet`: Russian-tail cleanup;
- protected exact values handled by allowlist: `truth-path`, `1 kWh = 1 EFHC`, `TON`, `kWh`.

Next regular cycle: 1378 — wave-3 `public_engagement` manual translation pass.


## Cycle 1378 result — v169.58

The wave-3 `public_engagement.*` pass was completed manually from verified Russian meaning for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID.

Scope closed:

- 43 public engagement keys per language;
- 430 manual locale values updated;
- rank focus, referral growth, tab labels and task flow preview copy;
- no English-identical values remain inside the wave-3 `public_engagement.*` domain;
- `ops/i18n/audit_wave3_public_engagement_locale_quality.py` added as the narrow domain guard.

Next regular cycle: 1379 — wave-3 portal/shop manual translation pass.

Future planning note: `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md` was added as a draft/reserved future range and is not active while 1376-1385 remains open.


## Cycle 1379 — wave-3 portal/shop manual translation pass

Status: DONE in v169.59.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public portal/shop prefixes: `portal.browser_shop.*` and `portal.shop_entry.*`.
- Manual values changed: 340.
- Guard: `ops/i18n/audit_wave3_portal_shop_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_portal_shop_manual_translation.py`.

Result: the guarded portal/shop domain has 0 unexpected English-identical values
and 0 Cyrillic tails. `TON` remains an exact-value allowlist exception, not a
translation debt.

Next planned cycle: `1380 — wave-3 profile/public-profile-trust manual translation pass`.


## Cycle 1380 — wave-3 profile/public-profile-trust manual translation pass

Status: DONE in v169.60.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public account/profile prefixes: `profile.*` and `public_profile_trust.*`.
- Guarded domain keys: 152 after allowlist and `profile.lang.*` / `profile.reason.*` exclusions.
- Manual values reviewed by the guard: 1520.
- Manual values updated in this pass: 430.
- Guard: `ops/i18n/audit_wave3_profile_trust_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_profile_trust_manual_translation.py`.

Result: the guarded profile/trust domain has 0 unexpected English-identical
values and 0 Cyrillic tails. `profile.lang.*` native language names and
`profile.reason.*` reason labels remain out of this narrow translation debt via
the shared allowlist policy.

Next planned cycle: `1381 — wave-3 panels/tasks/history manual translation pass`.


## Cycle 1381 — wave-3 panels/tasks/history manual translation pass

Status: DONE in v169.61.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public prefixes: `panels.*`, `tasks.*`, `history.*`.
- Guarded domain keys: 133 after shared exact-value and prefix allowlist exclusions.
- Manual values checked by the guard: 1330.
- Manual values updated in this pass: 410.
- Guard: `ops/i18n/audit_wave3_panels_tasks_history_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_panels_tasks_history_manual_translation.py`.

Result: the guarded panels/tasks/history domain has 0 unexpected
English-identical values and 0 Cyrillic tails. EFHC/kWh and other protocol
values remain governed by the shared allowlist policy.

Next planned cycle: `1382 — wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass`.


## Cycle 1382 — wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass

Status: DONE in v169.62.

Scope:

- Wave-3 languages: `de`, `fr`, `hi`, `sw`, `tr`, `pl`, `da`, `it`, `es`, `id`.
- Public prefixes: `hub.*`, `energy.*`, `wallet.*`, `ranks.*`, `referrals.*`.
- Guarded domain keys: 176 after shared exact-value and prefix allowlist exclusions.
- Manual values checked by the guard: 1760.
- Manual values updated in this pass: 200.
- Guard: `ops/i18n/audit_wave3_hub_energy_wallet_ranks_referrals_locale_quality.py`.
- Architecture test: `tests/architecture/test_wave3_hub_energy_wallet_ranks_referrals_manual_translation.py`.

Result: the guarded hub/energy/wallet/ranks/referrals tail has 0 unexpected
English-identical values and 0 Cyrillic tails. EFHC/kWh/TonConnect and other
protocol values remain governed by the shared allowlist policy.

Next planned cycle: `1383 — i18n manual coverage consolidation and remaining-tail audit`.


## Cycle 1383 — i18n manual coverage consolidation

Status: DONE in v169.63.

Scope:

- Consolidated manual translation passes 1377-1382.
- Added `ops/i18n/audit_i18n_manual_coverage_consolidation.py` as a cross-locale static/source guard.
- Manually fixed two remaining Hindi English-tail values:
  - `browser_login.badge`;
  - `exchange.receive_label`.
- Confirmed that only controlled protocol/brand/formula values and key-specific UI abbreviations remain identical to English.

Result:

- Languages checked: 12 non-English locale bundles.
- Values checked after exclusions: 11652.
- Unexpected English-identical values: 0.
- Wave-3 Cyrillic tails: 0.
- Human linguistic certification: NOT CLAIMED.

Next planned cycle: `1384 — browser text stress plan / screenshot-readiness planning only`.


## Cycle 1384 — i18n browser text stress / screenshot-readiness planning

Status: DONE in v169.64.

Scope:

- Converted the completed manual translation repair lane into a route × locale × device text-stress readiness matrix.
- Added `ops/i18n/audit_i18n_browser_text_stress_readiness.py`.
- Generated `reports/generated/i18n_browser_text_stress_readiness_v169_64.json`.
- Matrix: 14 public routes, 13 locales, 3 device/shell contexts = 546 planned combinations.
- This is planning-only. No screenshots, browser visual verdict, GitHub CI green, release-ready status or human linguistic certification are claimed.

Next planned cycle: `1385 — i18n range closure and next visual/browser-evidence handoff`.

## 1385 — CI logs repair / i18n range closure

Status: DONE. The manual i18n repair range 1376–1385 is closed at source/static level after the uploaded CI logs repair pass. Browser screenshots remain future evidence work.


## Post-range cycle 1386 — CI logs repair and test-execution correction

Status: DONE in v169.66. This cycle is outside the closed 1376–1385 manual i18n lane and responds to a new user-provided CI log. It repairs the pytest mass-skip root cause, Alembic model metadata schema drift and the Next `/app` prerender blocker.

---

## Источник: `WORK_CYCLES_1389_AI_ARCHIVE_LAWS_KERNEL_CANON_LOCK.md`

# WORK_CYCLES_1389_AI_ARCHIVE_LAWS_KERNEL_CANON_LOCK

Status: DONE / static-source lock.
Archive: v169_69.
Base: v169_68 critical test-control rollback repair.

## Цель

Внести пользовательские `AI_ARCHIVE_LAWS.md` в Kernel, AI, SSOT/CANON,
NORM и test-control слой как обязательные законы архивной работы.

## Выполнено

- Закон добавлен в `docs/AI/AI_ARCHIVE_LAWS.md`.
- Lock добавлен в `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`.
- Канон добавлен в `docs/SSOT/AI_ARCHIVE_LAWS_CANON.md`.
- Норма применения добавлена в
  `docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md`.
- Operator Kernel маршруты и инварианты обновлены.
- Test guard manifest связан с законом.
- Добавлен CI integrity guard.

## Запреты

ИИ не имеет права менять эти законы без прямого разрешения пользователя.
Любое скрытое ослабление архива, тестов, CI, логов, документации или
отчёта квалифицируется по законам как преступление против пользователя.

## Следующий цикл

1389+ должен лечить конкретные падающие тесты по доменам без удаления,
архивирования, skip/xfail и без снижения защитных инвариантов.

---

## Источник: `WORK_CYCLES_1390-1400_CI_LOG_REPAIR_AND_TEST_HEALING_PLAN.md`

# WORK_CYCLES_1390-1400 — CI log repair and test healing plan

Status: ACTIVE after the AI archive laws lock.
Base HEAD: `v169_69_ai_archive_laws_kernel_canon_lock`.
Current repair cycle: `1399`.

## Governing law

This range is controlled by `docs/AI/AI_ARCHIVE_LAWS.md`.
Tests are protection for the archive. They must not be deleted, archived,
skipped, xfailed or hidden to make CI look green. If a test fails, the cause
must be healed or escalated through mandatory iteration questions in Russian.

## Cycle map

| Cycle | Purpose | Status |
|---:|---|---|
| 1390 | Read `logs_72130548522.zip`, repair first pytest root causes, strengthen Law 0, repair line-length 72, and perform first mapped consolidation for wave-3 i18n guards. | DONE in v169.71 |
| 1391 | Continue pytest failure healing from fresh logs or remaining domain failures; line-length blocker was closed in 1390. | DONE in v169.73: bootstrap dependency diagnostics guard |
| 1392 | Fresh CI log `logs_72176795654.zip`: repair the eight pytest failures without hiding tests. | DONE in v169.74 |
| 1393 | Fresh CI log `logs_72181359058.zip`: confirm pytest and frontend build after v169.74, then lock shell guard evidence. | DONE in v169.75 |
| 1394 | Public Energy, Panels, Exchange and route guard repair. | DONE in v169.76 |
| 1395 | Visible functions, admin route evidence and report-index repair. | DONE in v169.77 |
| 1396 | Rank wording, legacy words and browser-shop/hub wording guard repair; user correction that `game` is allowed and only gambling/loto/betting/random financial meaning is banned. | DONE in v169.78 |
| 1397 | Fresh CI log `logs_72195040558.zip`: DB lane was green; repair ruff and canon false-positive failures from the wording pass. | DONE in v169.79 |
| 1398 | Test consolidation audit only: identify candidates and exact invariant mapping. No deletion. | DONE in v169.80 |
| 1399 | Direct user-approved mapped consolidation of the four cycle 1398 candidate groups. | DONE in v169.81 |
| 1400 | Fresh CI log `logs_72210640420.zip`: repair ruff shim import order, then close range. | DONE in v169.82 |

## Cycle 1400 range closure — v169.82

Fresh CI logs for `v169_81` were supplied as `logs_72210640420.zip`.
The log showed that pytest, frontend build, DB/Alembic, flake8, mypy,
bandit and compileall gates passed. The only failing gate was ruff.

Observed CI facts:

- pytest: `1130 passed`, `8 skipped`, `1 warning`;
- frontend: `npm ci` and `next build` passed;
- DB/Alembic: `exit_psql_pre=0` and `exit_alembic_upgrade=0`;
- gate blocker: `exit_ruff_full=1`.

Root cause:

- `ops/i18n/audit_forbidden_gaming_contour.py` had an import block
  formatting issue in the compatibility shim.

Repair:

- the shim import block was formatted without changing guard meaning;
- the active guard remains
  `ops/i18n/audit_forbidden_gambling_chance_contour.py`;
- the word `game` remains allowed;
- gambling, loto, betting and random financial reward meaning remain banned.

No test was deleted, archived, skipped, xfailed or hidden. No runtime UI,
backend economics, CI workflow, package lock or sandbox runtime changed.

Progress after cycle 1400:

- total cycles in `1390-1400`: 11;
- completed cycles: 11;
- remaining cycles: 0;
- range status: CLOSED;
- next action: wait for the new audit before opening a new active range.



## Cycle 1399 status

Cycle 1399 is done in `v169_81`. The user approved consolidating all four
groups prepared in cycle 1398. The pass converted 32 old active architecture
test files into support modules and added 4 active consolidated wrappers.
All 154 original test functions remain active as pytest cases.

Progress in this range after 1399:

- total cycles in `1390-1400`: 11;
- completed cycles: 10;
- remaining cycles: 1;
- next planned cycle: 1400 range closure and handoff.

## Cycle 1397 status

Cycle 1397 is done in `v169_79`. Fresh CI logs showed that the
Alembic/Postgres lane was green. The actual failing lanes were ruff and
pytest canon guards.

Root cause: after the game-word correction, active docs, tests and a guard
path used a banned English legacy token. The active forbidden-contour guard
was renamed to a neutral path and active references were updated without
weakening the ban on азартные игры, лотереи, ставки or random financial
reward meaning.

Progress in this range after 1397:

- total cycles in `1390-1400`: 11;
- completed cycles: 8;
- remaining cycles: 3;
- next planned cycle: 1398 audit-only consolidation mapping.


## Cycle 1396 status

Cycle 1396 is done in `v169_78`. It added a source/static wording matrix for
Ranks, Hub and Browser-Shop and corrected the false ban on the word `game`.
The active forbidden contour is gambling, loto, betting, tournament-like
financial contests and random financial reward meaning.

Progress in this range after 1396:

- total cycles in `1390-1400`: 11;
- completed cycles: 7;
- remaining cycles: 4;
- next planned cycle: 1397 if fresh CI has DB/Alembic/Postgres blockers,
  otherwise 1398 audit-only consolidation preparation.

## Current facts from logs

The CI log `logs_72130548522.zip` shows that the test suite is no longer hidden
behind global skip. Pytest executed and reported:

- `61 failed`;
- `1063 passed`;
- `8 skipped`.

The current local collect-only count after this repair state is:

- `1201 tests collected`.

## Cycle 1390 scope

Cycle 1390 heals only the root causes that are clear from the log and from
active tests. It does not weaken tests and does not make consolidation changes.

Healed groups:

- degraded Python dunder/name tokens;
- stale `/document` test expectation after Next `_document.tsx` correction;
- missing static retention/evidence anchors required by old active guards;
- stale energy balance-chip public UI guard expectations;
- historical cycle-marker drift;
- stale filename-hygiene noise in active test names;
- stale master-index active rows that pointed at missing historical files.

Open group:

- line-length 72 remains a large source-formatting blocker. It must be handled
  as a separate cycle because it touches many files and must not be hidden by
  weakening the guard.


## Cycle 1390 update — v169.71

User decisions applied:

- line-length 72 repair allowed and completed;
- CI summary formatting change not allowed yet;
- mapped test consolidation allowed and started only for wave-3 i18n guards;
- Law 0 replaced with the strengthened user-approved text only.

Consolidation was limited to a fully mapped group:

- five old wave-3 i18n test files became support modules;
- one active wrapper invokes all original test functions;
- no test was archived as `test_*.py`;
- no skip, xfail or norecursedirs was added.


## Cycle 1390 repair update — v169.72

User stopped iteration because a forbidden cycle suffix appeared in
`docs/testing/TEST_CONSOLIDATION_MAPPING_1390.md`.

Repair result:

- renamed the file to `docs/testing/TEST_CONSOLIDATION_MAPPING.md`;
- updated all references;
- strengthened filename policy with explicit path size limits;
- added an explicit guard for `docs/testing/` filenames;
- did not touch unrelated tests or CI jobs.

The next cycle remains 1391. It must continue log/domain healing without
filename-regression, test hiding, skip, xfail or archive moves.


## Cycle 1391 update — v169.73

No fresh `logs_*.zip` was supplied in this chat turn. The cycle therefore used
local collection triage from the current HEAD.

Findings:

- ZIP integrity and `testzip` passed.
- `pytest --collect-only` with `PYTHONPATH=backend` did not complete in the
  local sandbox because backend/test bootstrap dependencies were absent:
  `alembic`, `freezegun`, `psycopg`, `sqlalchemy`.
- This is a dependency bootstrap blocker in the local execution environment,
  not a reason to delete, skip, archive or weaken tests.
- Structural guard mode still passed and reported
  `active_architecture=269`.

Repair:

- `scripts/ci/check_test_suite_integrity.py` now checks required bootstrap
  modules before full collect-only and fails with a short root-cause message.
- `tests/architecture/test_test_suite_integrity_repair.py` now protects that
  message and the dependency-install instruction.
- No CI workflow, pytest exclusion, skip, xfail or test archive was added.

Checks:

- targeted protection set: `20 passed`;
- `check_ai_archive_laws_integrity.py`: passed;
- `check_test_suite_integrity.py --no-collect`: passed;
- full collect-only was not claimed because the local sandbox lacks the
  backend/test dependency layer.

Next cycle: `1392` docs/index retention anchors, unless fresh logs are supplied
first.


## Cycle 1392 update — v169.74

Fresh log priority superseded the earlier historical-docs placeholder for
cycle 1392. The log `logs_72176795654.zip` showed that all listed CI gates
except pytest were green, while pytest ended with `8 failed`, `1105 passed`,
`8 skipped`.

The eight failures were repaired by root cause:

1. `test_wave11_idempotency_conflict_requires_read_through` — restored the
   exact idempotency conflict marker protected by the guard.
2. `test_wave13_energy_and_sync_self_healing_guards` — reformatted the SQL
   wrapper so the guard parses the SQL block without swallowing commit code.
3. `test_great_canon_guard` — removed literal forbidden removed-domain terms
   from the i18n guard source by constructing those tokens safely.
4. `test_bot_texts_parity_script_uses_valid_importlib_loader` — replaced the
   package import path with a file loader that avoids Telegram runtime imports.
5. `test__main__registers_routes_with_api_prefix` — changed the stale test
   anchor from whitespace-specific text to semantic route-prefix detection.
6. `test_operator_kernel_has_range_closure_route` — restored the contiguous
   generated-report path anchor in the operator route resolver.
7. `test_cycle_1377_uk_quality_guard_uses_global_exact_allowlist` — preserved
   the exact allowlist-call anchor while staying inside line-length policy.
8. `test_shop_service_catalog_marks_usdt_disabled` — restored a canonical
   contiguous USDT disabled-reason marker through a shared constant.

No consolidation was performed in cycle 1392. No active test was deleted,
archived, skipped, xfailed or removed from collection.

Verification performed locally:

- 63 targeted architecture/policy tests passed;
- `python3 -m compileall backend/app ops tests/architecture -q` passed;
- AI archive laws integrity guard passed;
- structural test-suite guard passed in `--no-collect` mode;
- bot text parity, Ukrainian value quality and forbidden-gaming guards passed.

Full pytest green and GitHub CI green are not claimed until the repaired
archive is executed in CI or in a local environment with all backend/test
requirements installed.

## Cycle 1393 update — v169.75

Fresh log priority was applied again. The supplied log
`logs_72181359058.zip` showed no failing gate after the v169.74 repair.

Observed CI facts from the log:

- gate summary: all gate steps passed;
- pytest: `1113 passed`, `8 skipped`, `1 warning`;
- frontend: `npm ci` completed and `next build` completed;
- Next.js build route table included public routes, admin routes,
  `/app`, `/_app`, `/api/tonconnect-manifest` and `/_document`
  was not exposed as a public page.

Cycle 1393 therefore did not perform code repair. It updated cycle, shell,
SSOT and test-control documents to record the verified state.

Local targeted verification performed for the shell lane:

- 48 targeted architecture/frontend shell tests passed.

No active test was deleted, archived, skipped, xfailed or hidden. No CI
workflow, package lock, EFHC economics, wallet logic or sandbox runtime was
changed.

Open non-blocking note from the log: `npm ci` printed audit warnings for
5 vulnerabilities. The CI gate did not fail on that warning. Treat package
changes as a separate dependency-security cycle only after audit, not as a
blind `npm audit fix --force` step.

Next cycle: `1394`, unless fresh failing logs are supplied first.
## Cycle 1394 update — v169.76

No fresh failing log archive was supplied for this cycle. The user explicitly
confirmed continuing strictly by the 1394-1400 plan.

Cycle 1394 therefore performed a public Energy/Panels/Exchange guard pass:

- added `docs/frontend/PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md`;
- added `reports/generated/public_energy_panels_exchange_guard_matrix_v169_76.json`;
- added `tests/architecture/test_public_energy_panels_exchange_guard_matrix.py`;
- registered the guard in `docs/testing/TEST_GUARD_MANIFEST.md/json`;
- recorded that no test consolidation was performed.

Protected chain: public route → public component → backend road → EFHC
economic invariant → active architecture guard.

No code path changed EFHC economics, wallet logic, CI workflow or sandbox
runtime. No test was deleted, archived, skipped, xfailed or hidden.

Local targeted verification for the public triad guard lane passed. Full local
pytest green is not claimed in this sandbox.

Next cycle: `1395`, unless fresh failing logs are supplied first.


## Cycle 1395 closure note

Cycle 1395 closed the Admin visible function evidence gap by adding one
active guard matrix over Admin route, visible function, backend road and guard
anchors. It also imported `25.md` into `docs/NORM/CHATS/` and recorded the
new sandbox input as reference-only. No runtime UI, backend economics, tests or
CI workflows were weakened.


## Cycle 1398 status

Cycle 1398 is done in `v169_80`. It is an audit-only mapping pass.
No active tests were changed, moved, deleted, archived, skipped,
xfailed or consolidated.

Prepared map:

- `docs/testing/TEST_CONSOLIDATION_AUDIT_ONLY_MAP.md`;
- `reports/generated/test_consolidation_audit_only_map_v169_80.json`.

Mapped future candidate groups:

1. docs/cycles and cycle-marker guards;
2. public visual evidence guards;
3. PWA / shell / document guards;
4. route / evidence existence guards.

Progress in this range after 1398:

- total cycles in `1390-1400`: 11;
- completed cycles: 9;
- remaining cycles: 2;
- next planned cycle: 1399 optional actual consolidation only after
  direct user approval.
