# Cycle 1436 — User Decisions Lock / Linkage Repair Answers

Status: DONE.  
Archive: `EFHC_Bot_v170_12_cycle_1436_user_decisions_doc_update.zip`  
Base archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`  
Mode: DOCS-ONLY / USER DECISIONS LOCK / NO RUNTIME LOGIC CHANGE.

## Goal

Update the active linkage audit documents after the user answered the remaining repair questions.

## User decisions

1. `F-001 / cycle 1437`: do not create a separate `efhc_mint_burn` ledger/table. Use only existing official/canonical tables and ledger surfaces.
2. `F-005 / cycle 1441`: admin wallet reset must fully unbind canonical `wallet_bindings`.
3. `F-004 / cycle 1440`: Admin Hub is a separate admin section with canonical path `/admin/hub/*`.
4. Future iteration questions must use the approved simple format: problem, simple question, options, recommendation, short recommended answers.

## Updated documents

- `docs/NORM/ITERATION_QUESTIONS_FORMAT_STANDARD.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `KERNEL.md`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- `reports/REPORTS_INDEX.md`
- `map_element.md`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/cache/file_map.json`

## No runtime changes

This update does not change runtime code, backend services/routes/models, frontend code, tests, migrations, CI/workflows, lock files, business logic, economy, security/auth logic or money-flow.

## Next safe step

Cycle `1437` — P0 Bank SSOT repair using only existing official/canonical tables.
