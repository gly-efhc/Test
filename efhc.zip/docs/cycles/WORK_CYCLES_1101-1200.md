# WORK CYCLES 1101-1200

## Road-audit correction block

The earlier 1180-1200 proof scaffold is not release readiness.  The
corrected cycle meaning is:

- 1180: audit intake, audit-of-audit and road matrix scaffold.
- 1181: compact repair program and static evidence scaffold.
- 1182: runtime OpenAPI repair gate.
- 1183: frontend/backend contract repair.
- 1184: ORM versus Alembic 0001 repair.

Cycles 1185-1200 remain active repair cycles.  They must fix the audit
findings, not merely describe them.

## Cycle 1184 result

The 0001 sanity gate now covers critical economic and user columns.  The
new static guard checks ORM model presence, 0001 gate presence,
metadata-driven migration status and absence of pre-release `0002`.


## Cycle 1185 result

The profile alias `GET /user/{global_id}/me` was removed after consumer
checks.  `GET /user/me` remains the only active self-profile route.

## Cycle 1186 result

The panels-summary road was moved to canonical self route
`GET /user/me/panels-summary`.  The old tg-id panels-summary path was
removed from active backend code after consumer checks.

## Cycle 1187 result

Withdraw economic road was repaired.  User list now resolves the user
from auth and accepts `global_id` only as an optional legacy self-check.
Admin approve now supports PAID same-key idempotent replay and commits
the PAID outcome explicitly before returning success.

## Cycle 1188 result

Deposit and watcher truth road was repaired.  The owner-only payment
intent status route now treats `ok = false` from the service as 404 and
removes the internal `ok` marker before returning the public response.
A guard proves auth, idempotency, watcher, reconciliation, tx hash lock,
exact-amount and flow-truth anchors.

## Cycle 1189 result

Exchange economic road was repaired.  Exchange now uses self routes:
`GET /exchange/preview`, `POST /exchange/convert` and
`GET /exchange/history`.  Old path-tg-id exchange aliases were removed
from active backend code, frontend generated seams, OpenAPI and route
SSOT packs.  The exchange guard proves idempotency, audit anchors,
OpenAPI paths and frontend/backend seam alignment.

## Cycle 1190 result

Panel activation economic road was repaired.  Activation now uses
`POST /panels/activate`.  The old active buy/path-tg-id aliases were
removed.  The activation audit meta now records qty, price, total
amount, bonus spend, main spend and `bonus_first` proof fields.

## Cycle 1191 result

Shop and payment truth road was repaired.  Shop external order routes
now reject incomplete order payloads and missing order ids instead of
returning a weak success response.  Browser-Shop intent status now
returns 404 for missing or non-owned intents and strips the internal
`ok` marker before public response.

## Cycle 1192 result

Admin bank action road was repaired.  Mint and burn now resolve the
admin through RBAC by global_id, pass an admin object to the bank service,
commit before success and return the bank balance from the service
result.  Admin transfer now exposes the TxResult bank main balance.

## Cycle 1193 result

False UI road repair was completed for panels-summary.  The panels UI
now reads summary from `GET /user/me/panels-summary`.  The stale
`GET /panels/{global_id}/summary` route was removed from active backend,
OpenAPI and route SSOT maps after the UI was moved to the canonical
self route.

## Cycle 1194 result

Helper/internal boundary repair was completed for cron and Telegram
webhook roads.  `GET /cron/tick` and `POST /tg/webhook` remain active
runtime endpoints, but are hidden from OpenAPI and marked internal in
route SSOT maps.  Their secret checks remain in active code.


## Cycle 1195 result

Visual audit intake and planning were completed in v168_17.  The visual
audit v002 and 100 answers created a new 1195-1230 repair plan.

## Cycle 1196 result

Profile language runtime was repaired.  The frontend now loads the
selected locale through `loadDict(lang)` for runtime UI labels and uses
Russian as fallback.  Settings persistence is gated by
`settingsHydrated` so defaults do not overwrite stored language before
loading completes.

## Cycle 1197 result

The profile language selector was rebuilt as a horizontal language bar
and protected by `test_profile_language_switch_guard.py`.  Bottom
navigation labels remain the protected English canon.

## v168_19 cycles 1198-1199 update

- 1198: Direct Deposit modal rewritten as a clean wallet-open public
  modal, no shop launcher or diagnostics.
- 1199: Direct Deposit backend split added as
  `POST /deposit/direct-open`, without `package_id` coupling.
- Scope is local code repair plus guard proof. GitHub CI and full
  browser proof were not run.

## Cycle 1200 bridge verdict

Cycle 1200 is a corrected bridge verdict, not a release closeout.
The range 1176-1200 contains real repairs, but full release readiness is
not claimed because imported visual blockers remain open.

Remaining open after 1200:

- Browser-Shop layout separation;
- storefront public diagnostics cleanup;
- public card field cleanup;
- browser screenshot proof;
- GitHub CI proof.
