# EFHC — ЦИКЛЫ 1101–1200
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `WORK_CYCLES_1101-1200.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1101-1200

## Road-audit correction block

The earlier 1180-1200 proof scaffold is not release readiness.  The
corrected cycle meaning is:

- 1180: audit intake, audit-of-audit and road matrix scaffold.
- 1181: compact repair program and static evidence scaffold.
- 1182: runtime OpenAPI repair gate.
- 1183: frontend/backend contract repair.
- 1184: ORM versus Alembic 0001 repair.

Cycles 1185-1200 remain active repair cycles.  They must fix the audit
findings, not merely describe them.

## Cycle 1184 result

The 0001 sanity gate now covers critical economic and user columns.  The
new static guard checks ORM model presence, 0001 gate presence,
metadata-driven migration status and absence of pre-release `0002`.


## Cycle 1185 result

The profile alias `GET /user/{tg_id}/me` was removed after consumer
checks.  `GET /user/me` remains the only active self-profile route.

## Cycle 1186 result

The panels-summary road was moved to canonical self route
`GET /user/me/panels-summary`.  The old tg-id panels-summary path was
removed from active backend code after consumer checks.

## Cycle 1187 result

Withdraw economic road was repaired.  User list now resolves the user
from auth and accepts `tg_id` only as an optional legacy self-check.
Admin approve now supports PAID same-key idempotent replay and commits
the PAID outcome explicitly before returning success.

## Cycle 1188 result

Deposit and watcher truth road was repaired.  The owner-only payment
intent status route now treats `ok = false` from the service as 404 and
removes the internal `ok` marker before returning the public response.
A guard proves auth, idempotency, watcher, reconciliation, tx hash lock,
exact-amount and flow-truth anchors.

## Cycle 1189 result

Exchange economic road was repaired.  Exchange now uses self routes:
`GET /exchange/preview`, `POST /exchange/convert` and
`GET /exchange/history`.  Old path-tg-id exchange aliases were removed
from active backend code, frontend generated seams, OpenAPI and route
SSOT packs.  The exchange guard proves idempotency, audit anchors,
OpenAPI paths and frontend/backend seam alignment.

## Cycle 1190 result

Panel activation economic road was repaired.  Activation now uses
`POST /panels/activate`.  The old active buy/path-tg-id aliases were
removed.  The activation audit meta now records qty, price, total
amount, bonus spend, main spend and `bonus_first` proof fields.

## Cycle 1191 result

Shop and payment truth road was repaired.  Shop external order routes
now reject incomplete order payloads and missing order ids instead of
returning a weak success response.  Browser-Shop intent status now
returns 404 for missing or non-owned intents and strips the internal
`ok` marker before public response.

## Cycle 1192 result

Admin bank action road was repaired.  Mint and burn now resolve the
admin through RBAC by tg_id, pass an admin object to the bank service,
commit before success and return the bank balance from the service
result.  Admin transfer now exposes the TxResult bank main balance.

## Cycle 1193 result

False UI road repair was completed for panels-summary.  The panels UI
now reads summary from `GET /user/me/panels-summary`.  The stale
`GET /panels/{tg_id}/summary` route was removed from active backend,
OpenAPI and route SSOT maps after the UI was moved to the canonical
self route.

## Cycle 1194 result

Helper/internal boundary repair was completed for cron and Telegram
webhook roads.  `GET /cron/tick` and `POST /tg/webhook` remain active
runtime endpoints, but are hidden from OpenAPI and marked internal in
route SSOT maps.  Their secret checks remain in active code.


## Cycle 1195 result

Visual audit intake and planning were completed in v168_17.  The visual
audit v002 and 100 answers created a new 1195-1230 repair plan.

## Cycle 1196 result

Profile language runtime was repaired.  The frontend now loads the
selected locale through `loadDict(lang)` for runtime UI labels and uses
Russian as fallback.  Settings persistence is gated by
`settingsHydrated` so defaults do not overwrite stored language before
loading completes.

## Cycle 1197 result

The profile language selector was rebuilt as a horizontal language bar
and protected by `test_profile_language_switch_guard.py`.  Bottom
navigation labels remain the protected English canon.

## v168_19 cycles 1198-1199 update

- 1198: Direct Deposit modal rewritten as a clean wallet-open public
  modal, no shop launcher or diagnostics.
- 1199: Direct Deposit backend split added as
  `POST /deposit/direct-open`, without `package_id` coupling.
- Scope is local code repair plus guard proof. GitHub CI and full
  browser proof were not run.

## Cycle 1200 bridge verdict

Cycle 1200 is a corrected bridge verdict, not a release closeout.
The range 1176-1200 contains real repairs, but full release readiness is
not claimed because imported visual blockers remain open.

Remaining open after 1200:

- Browser-Shop layout separation;
- storefront public diagnostics cleanup;
- public card field cleanup;
- browser screenshot proof;
- GitHub CI proof.

---

## Источник: `WORK_CYCLES_1182-1200_FIX_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1182-1200 FIX PLAN

## Current rule

The goal is not to produce cycles.  The goal is to repair the road-audit
errors.  Cycles only exist to keep the repair order clear and auditable.
Do not split work when one cycle can honestly close several related
findings.

## Cycle 1182

Runtime OpenAPI repair gate.  The helper must try to export the actual
FastAPI OpenAPI schema.  If runtime dependencies are absent, it must
write an explicit blocker instead of claiming release readiness.

## Cycle 1183

Frontend/backend contract repair.  Sensitive generated frontend seams
must be checked against backend route decorators for missing route and
method drift.

## Cycle 1184

ORM versus Alembic 0001 repair.  Expand 0001 critical-column sanity and
add a dependency-free guard proving the critical economic columns are in
ORM and in the 0001 gate.  Do not create pre-release `0002`.

## Cycle 1185

Canonical profile route repair.  Completed as code repair: `/user/me` is
the only active self-profile route and `/user/{tg_id}/me` was removed
after consumer checks found no frontend dependency.

## Cycle 1186

Panels-summary orphan repair.  Completed as code repair:
`/user/me/panels-summary` is the active self-route and the old tg-id
path
was removed from active backend code after consumer checks.

## Cycle 1187

Withdraw economic road repair.  Completed as code repair: user list uses
auth as source of truth, legacy `tg_id` is only an optional self-check,
admin approve has same-key PAID replay and explicit commit, and a guard
proves hold, refund, outcome and contract anchors.

## Cycle 1188

Deposit and watcher truth repair.  Completed as code repair: the
owner-only payment-intent status route now returns 404 when the service
returns `ok = false`, strips the internal `ok` marker before the public
response model, and a guard verifies watcher, tx hash lock,
reconciliation, exact amount, intent status and flow-truth anchors.

## Cycle 1189

Exchange economic road repair.  Completed as code repair: active
exchange routes are self-routes.  Frontend generated seams no longer
carry path `tg_id`.  The stale user exchange preview alias was removed,
and a guard proves exchange economic-road anchors.

## Cycle 1190

Panel activation economic road repair.  Completed as code repair:
activation is a self-route, the buy/path-tg-id aliases were removed,
frontend calls the canonical route, and activation audit meta proves
bonus-first spend details.

## Cycle 1191

Shop and payment truth repair.  Completed as code repair: external shop
order routes now reject incomplete payloads and missing order ids, and
Browser-Shop intent status returns 404 for non-owned or missing intents
while stripping internal service markers from the public schema.

## Cycle 1192

Admin bank action repair.  Completed as code repair: mint and burn now
resolve admin through RBAC by tg_id, pass an admin object to the bank
service, commit before success, and return current bank balance.

## Cycle 1193

False UI road repair.  Completed as code repair for panels-summary: the
panels UI now calls the canonical self summary route, and the stale
tg-id summary route was removed from active backend, OpenAPI and route
SSOT maps.

## Cycle 1194

Helper/internal boundary repair.  Completed for cron and Telegram
webhook roads: both routes remain active runtime endpoints, but are
hidden from OpenAPI and marked internal in route SSOT maps.

## Cycle 1195

Visual audit intake and plan remap after the imported visual audit.
Completed in v168_17 as audit import, audit-of-audit, public UI NORM and
1195-1230 repair plan.

## Cycle 1196

Profile language runtime repair.  Completed in v168_18: selected
language now drives the runtime UI dictionary, while Russian stays the
fallback and settings persistence waits for hydration.

## Cycle 1197

Profile language selector and guard repair.  Completed in v168_18: the
selector is now a horizontal language bar and a guard proves dictionary
loading, hydration safety and bottom-menu English canon.

## Cycle 1198

Road registry guard.  Produce a repeatable method/path to handler
map and
fail on duplicate active method/path definitions.

## Cycle 1199

Release readiness evidence audit.  Summarize only proven repairs and
separate blockers from completed fixes.

## Cycle 1200

Corrected range verdict.  Close the range only if the evidence supports
it.  If not, hand off the exact blockers to the next range.

## Visual audit correction after v168_17

Cycle 1195 is remapped to visual audit intake and 1195-1230 planning.
The previous contract-test repair remains required, but the new audit
proves higher priority public UI blockers. Cycle 1200 must be only a
bridge verdict if those blockers are still open.

## v168_19 correction for 1198-1199

The visual audit priority remap is now reflected in real code:

- 1198 fixed the public Direct Deposit modal.
- 1199 added the direct backend wallet-open route.
- Contract-test work remains necessary, but it must follow the repaired
  visual road rather than documenting the old mixed road.

---

## Источник: `WORK_CYCLES_1183-1184_DETAILED_PLAN.md`

# WORK CYCLES 1183-1184 DETAILED PLAN

## Scope

This document is a local detailed execution note for cycles 1183-1184.
It does not replace the range file.  It explains why cycle 1183 is not
repeated and how cycle 1184 repairs the audit risk.

## Cycle 1183

Status: already completed in the previous HEAD as frontend/backend
contract guard work.  It must not be counted again in this pass.

## Cycle 1184

Goal: repair the ORM versus Alembic 0001 risk from the road audit.
The audit class is schema drift: services and models may rely on fields
that are not protected by the initial migration sanity gate.

Actions:

1. Keep the pre-release migration canon: only `0001_init.py`.
2. Do not create `0002`.
3. Expand the 0001 sanity gate for critical economic columns.
4. Add a static dependency-free guard for ORM and 0001 gate coverage.
5. Add an architecture test that can run without full FastAPI runtime.
6. Update road integrity documentation and report indexes.

Done means the static guard reports no missing critical model columns,
no missing critical 0001 gate columns, metadata-driven 0001 remains in
place and no pre-release 0002 is present.

---

## Источник: `WORK_CYCLES_1185-1186_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1185-1186 DETAILED PLAN

## Purpose

This pass repairs concrete road-audit findings.  The goal is not to
increase cycle count.  The goal is to remove route ambiguity after a
consumer check and to keep only canonical self-user roads.

## Cycle 1185: profile route alias repair

Audit finding:
- `/user/me` and `/user/{tg_id}/me` created duplicate self-profile
  roads.

Required work:
1. Check backend route decorators.
2. Check frontend source for direct legacy consumers.
3. Check active API contract docs.
4. Check architecture tests and guards.
5. Remove the legacy alias if no real consumer requires it.
6. Keep `/user/me` as the only active self-profile route.
7. Update active docs, guards, tests and generated evidence.

Done condition:
- no active backend route for `/user/{tg_id}/me`;
- no frontend consumer for `/user/{tg_id}/me`;
- no active API contract section for `/user/{tg_id}/me`;
- guard returns `all_required_present: true`.

## Cycle 1186: panels-summary orphan repair

Audit finding:
- `/user/{tg_id}/panels-summary` looked like a tg-id scoped road, while
  the real self-user road should use authenticated current user context.

Required work:
1. Check backend route decorators.
2. Check frontend source for direct legacy consumers.
3. Check active API contract docs.
4. Replace the tg-id route with `/user/me/panels-summary`.
5. Use the canonical auth dependency as the source of current tg_id.
6. Update SSOT route inventory entries and active docs.
7. Add guard and architecture test.

Done condition:
- `/user/me/panels-summary` exists in active backend code;
- `/user/{tg_id}/panels-summary` is absent from active backend code;
- no frontend consumer requires the removed tg-id path;
- guard returns `all_required_present: true`.

---

## Источник: `WORK_CYCLES_1185-1190_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Detailed Work Plan — Cycles 1185-1190

This document expands the active road-integrity plan. It does not close
future cycles by itself. A cycle is complete only after the related
source files, generated evidence and report are written.

## Scope boundary

The pass continues the road-integrity proof program opened by the PDF
audit and cycles 1180-1184. It is proof-first work. Legacy routes are
not deleted only because they look old. Every route change needs current
HEAD evidence and consumer proof.

## Cycle 1185 — runtime OpenAPI proof attempt

Goal:
- try to export OpenAPI from the real FastAPI runtime app;
- if runtime dependencies are unavailable in the container working
  environment, write a status artifact instead of guessing;
- keep static route inventory as fallback evidence only.

Expected artifacts:
- `ops/routes/export_runtime_openapi.py`;
- `reports/generated/runtime_openapi_1185_status.json`;
- `docs/audits/ROAD_INTEGRITY_RUNTIME_OPENAPI_1185.md`.

Exit rule:
- runtime OpenAPI is exported, or the blocker is documented honestly.

## Cycle 1186 — frontend caller to backend route matrix

Goal:
- build a static matrix from backend route decorators to frontend path
  strings outside FAQ and catalog exclusions;
- separate source-level evidence from runtime contract proof;
- identify routes and calls that need human review or better parser
  rules.

Expected artifacts:
- `ops/routes/build_frontend_backend_matrix.py`;
- `reports/generated/frontend_backend_matrix_1186.json`;
- `docs/audits/FRONTEND_BACKEND_CALLER_MATRIX_1186.md`.

Exit rule:
- counts are generated and caveats are recorded.

## Cycle 1187 — ORM versus 0001 strategy compare

Goal:
- statically compare ORM table declarations with the current 0001
  migration strategy;
- verify whether 0001 is metadata-driven and imports model modules;
- list important release tables that are or are not anchored in 0001.

Expected artifacts:
- `ops/routes/compare_orm_0001.py`;
- `reports/generated/orm_0001_compare_1187.json`;
- `docs/audits/ORM_0001_SCHEMA_STRATEGY_COMPARE_1187.md`.

Exit rule:
- the metadata strategy is classified without editing migration
  history.

## Cycle 1188 — `/user/me` road consumer proof

Goal:
- prove what exists for `/user/me` and `/user/{tg_id}/me`;
- classify whether consumers are proven by static frontend strings;
- avoid removing either route before stronger consumer proof.

Expected artifacts:
- `reports/generated/user_panels_roads_1188_1189.json`;
- `docs/audits/USER_PROFILE_ROAD_CONSUMER_PROOF_1188.md`.

Exit rule:
- duplicate profile roads are classified as current evidence, not
  fixed
  by deletion.

## Cycle 1189 — panels summary road consumer proof

Goal:
- prove what exists for panels summary roads;
- classify missing or unproven consumer state;
- mark the next safe action for panels summary without deleting a
  route.

Expected artifacts:
- `reports/generated/user_panels_roads_1188_1189.json`;
- `docs/audits/PANELS_SUMMARY_ROAD_CONSUMER_PROOF_1189.md`.

Exit rule:
- panels summary road state is documented for follow-up repair.

## Cycle 1190 — withdraw road proof

Goal:
- prove the withdraw create, cancel, admin review and final status
  road;
- check route, service, model, 0001 anchor, statuses and bank ledger
  calls by static evidence;
- record remaining limits that require runtime or DB-backed tests.

Expected artifacts:
- `ops/routes/prove_withdraw_road.py`;
- `reports/generated/withdraw_road_proof_1190.json`;
- `docs/audits/WITHDRAW_ROAD_PROOF_1190.md`.

Exit rule:
- withdraw has a static proof bundle and clear remaining runtime gaps.

---

## Источник: `WORK_CYCLES_1186-1187_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1186-1187 DETAILED PLAN

## Purpose

This pass checks the 1186 route-alias tail before moving to withdraw.
The goal is defect repair, not cycle production.

## Cycle 1186 tail check

Checklist:
- prove active backend has `/user/me/panels-summary`;
- prove active backend has no `/{tg_id}/panels-summary` route;
- keep historical audit mentions only as past context;
- do not delete historical reports just to hide old evidence.

Result:
- active alias is removed;
- generated historical files still record the old state;
- no release-wide road readiness is claimed.

## Cycle 1187 withdraw economic road repair

Checklist:
- user create path requires idempotency;
- user list resolves tg_id from auth;
- optional query tg_id is only a legacy self-check;
- user cancel refunds from bank when hold was done;
- admin approve finalizes PAID with explicit commit;
- admin approve supports same-key PAID replay;
- admin reject refunds and commits outcome;
- outcome event and admin log anchors exist;
- NORM API contract matches active routes.

Result:
- code, guard, test, API contract, matrix and report are aligned;
- GitHub CI is still required for final release evidence.

---

## Источник: `WORK_CYCLES_1188_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLE 1188 DETAILED PLAN

## Purpose

Cycle 1188 repairs the deposit and watcher truth road.  The goal is not
just to prove that files exist.  The goal is to make the user-facing
status route fail cleanly and to keep watcher evidence connected to the
payment-intent outcome.

## Context from 1187

Cycle 1187 changed withdraw list semantics.  Before the repair, a user
list route could be read as "show withdrawals for tg_id from query".
After the repair it means "show withdrawals for the authenticated user".
The optional `tg_id` query value remains only as a legacy
self-check.  It must match the authenticated user and cannot select
another account.

## Why that matters

For money roads the user identity must come from auth.  Query or path
values are allowed only as compatibility checks.  This prevents a false
road where a UI parameter looks like it can control another user's
financial data.

## Cycle 1188 checklist

- deposit creation uses auth `tg_id`;
- deposit creation requires connected wallet and idempotency key;
- payment intent payload carries purpose, intent id and owner `tg_id`;
- watcher parses intent payload before legacy memo logic;
- watcher blocks unsupported transport before confirm;
- reconciliation checks exact asset, destination and amount;
- reconciliation locks `tx_hash` before credit;
- reconciliation commits confirmed intent and credit outcome;
- status route is owner-only;
- missing intent returns 404 instead of leaking service sentinel data;
- API contract documents the status route and `flow_truth`.

## Result expected

The cycle may be closed only if code, guard, test, contract, matrix and
report agree on the same deposit/watcher road.

---

## Источник: `WORK_CYCLES_1189-1190_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1189-1190 DETAILED PLAN

## Purpose

This mini-plan repairs two audit findings from the road integrity audit:
exchange economic road drift and panel activation economic road drift.
The goal is not to add more paperwork.  The goal is to reduce duplicate
or unsafe user-facing roads and make each money road use the current
authenticated user as the source of truth.

## Cycle 1189 - exchange economic road repair

Problem:

- exchange routes used path tg_id;
- frontend generated seams also carried path tg_id;
- the user route still contained an old exchange preview alias;
- this looked as if a caller could choose a user by URL.

Fix:

- make `/exchange/preview` the canonical preview route;
- make `/exchange/convert` the canonical conversion route;
- make `/exchange/history` the canonical history route;
- remove `/user/{tg_id}/exchange/preview` from active backend code;
- update frontend generated exchange seams;
- update the exchange page to call the self routes;
- update OpenAPI and route SSOT packs for the active paths;
- add a guard proving old path tg_id exchange aliases are gone.

Release boundary:

This closes only the exchange route drift and evidence guard for the
exchange road.  It does not declare all roads release-ready.

## Cycle 1190 - panel activation economic road repair

Problem:

- panel activation used `/panels/activate/{tg_id}`;
- `/panels/buy/{tg_id}` existed as a compatibility alias;
- the route shape still looked path-selected instead of self-user;
- the activation audit meta did not expose all bonus-first proof fields.

Fix:

- make `/panels/activate` the canonical activation route;
- remove the active `/panels/buy/{tg_id}` compatibility alias;
- update frontend activation call to `/panels/activate`;
- update OpenAPI and route SSOT packs;
- add bonus-first audit meta fields:
  - `qty`;
  - `price_per_panel`;
  - `total_amount`;
  - `spent_bonus`;
  - `spent_main`;
  - `bonus_first`;
- add a guard proving route, frontend, OpenAPI, SSOT and audit anchors.

Release boundary:

This closes only the panel activation route and audit-proof drift.  It
does not declare every panel, frontend or table road release-ready.

---

## Источник: `WORK_CYCLES_1191-1192_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1191-1192 DETAILED PLAN

## Purpose

These cycles close the next two road-audit findings without stretching
one defect class across unnecessary extra cycles.

The goal is not to add reports.  The goal is to repair the road from
entrypoint to service, table mutation, status, user or operator surface
and audit proof.

## Cycle 1191: shop and payment truth repair

Scope:
- Browser-Shop and in-app Shop external order road.
- Payment intent creation and status surface.
- Watcher/reconciliation link to shop order.
- User-visible flow truth for paid, pending, manual and error states.

Required fixes:
- Do not return a successful order payload when order or payment data is
  incomplete.
- Do not return success when the external order id is missing.
- Keep payment intent ownership tied to the authenticated tg_id.
- Store intent payload, intent id and payment owner in shop order extra.
- Status endpoint must return 404 for missing or non-owned intents.
- Internal service markers such as `ok` must not enter the public
  schema.

Evidence:
- `ops/routes/check_shop_payment_truth.py`.
- `reports/generated/shop_payment_truth_1191.json`.
- `tests/architecture/test_shop_payment_truth_guard.py`.

## Cycle 1192: admin bank action repair

Scope:
- Admin transfer road.
- Admin bank mint road.
- Admin bank burn road.
- Ledger and bank proof returned to the operator surface.

Required fixes:
- Admin money roads must use `tg_id`, not internal `users.id`.
- Mint and burn must resolve the admin through RBAC by tg_id.
- Mint and burn must pass an admin object to the bank service.
- Mint and burn must commit before returning success.
- Mint and burn must return `current_balance`, not a missing attribute.
- Manual transfer must expose the actual bank main balance from
  TxResult.

Evidence:
- `ops/routes/check_admin_bank_road.py`.
- `reports/generated/admin_bank_road_1192.json`.
- `tests/architecture/test_admin_bank_road_guard.py`.

---

## Источник: `WORK_CYCLES_1191-1195_DETAILED_PLAN.md`

# Detailed Work Plan — Cycles 1191-1195

This document expands the active road-integrity proof block after
cycle 1190. It does not close future cycles by itself. A cycle is closed
only after its evidence artifact, audit note and report entry exist.

## Scope boundary

The block continues the proof-first approach. No legacy route is deleted
only because it looks old. The goal is to prove roads, classify gaps and
record safe next actions.

## Cycle 1191 — deposit and watcher truth road proof

Goal:
- prove the deposit route, payment intent creation, TonConnect payload,
  watcher confirmation, TON log and internal EFHC credit path;
- record whether the chain has static anchors from route to table.

Expected artifacts:
- `ops/routes/prove_deposit_watcher_road.py`;
- `reports/generated/deposit_watcher_road_proof_1191.json`;
- `docs/audits/DEPOSIT_WATCHER_ROAD_PROOF_1191.md`.

## Cycle 1192 — exchange economic road proof

Goal:
- prove preview, convert, history, service exchange, available kWh
  snapshot, banking calls and migration anchors;
- keep the one-way kWh to EFHC canon visible.

Expected artifacts:
- `ops/routes/prove_exchange_road.py`;
- `reports/generated/exchange_road_proof_1192.json`;
- `docs/audits/EXCHANGE_ROAD_PROOF_1192.md`.

## Cycle 1193 — panels activation road proof

Goal:
- prove summary, active, archive and activation roads;
- verify static anchors for 100 EFHC activation, bonus-first spending,
  panel record creation and metadata-driven migration support.

Expected artifacts:
- `ops/routes/prove_panels_activation_road.py`;
- `reports/generated/panels_activation_road_proof_1193.json`;
- `docs/audits/PANELS_ACTIVATION_ROAD_PROOF_1193.md`.

## Cycle 1194 — shop payment truth road proof

Goal:
- prove shop catalog, external order, Browser-Shop intent creation,
  intent status, reconciliation and order finalization anchors;
- keep runtime contract proof as a future gate.

Expected artifacts:
- `ops/routes/prove_shop_payment_truth_road.py`;
- `reports/generated/shop_payment_truth_road_proof_1194.json`;
- `docs/audits/SHOP_PAYMENT_TRUTH_ROAD_PROOF_1194.md`.

## Cycle 1195 — helper/internal boundary proof

Goal:
- classify helper/internal roads without deleting them;
- keep helper roads separated from player-facing and release-core roads;
- identify the next safe proof gates for 1196-1200.

Expected artifacts:
- `ops/routes/prove_helper_internal_boundary.py`;
- `reports/generated/helper_internal_boundary_1195.json`;
- `docs/audits/HELPER_INTERNAL_BOUNDARY_PROOF_1195.md`.

---

## Источник: `WORK_CYCLES_1193-1194_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1193-1194 DETAILED PLAN

## Shared purpose

The goal of this pass is to repair audit findings, not to create a
paper-only status.  Cycle 1193 closes a false UI route in the panels
summary flow.  Cycle 1194 bounds helper/internal roads so they no longer
look like public release roads.

## Cycle 1193: false UI road repair

Problem:
- the panels UI still called `/panels/${tg_id}/summary`;
- the canonical self route already existed as
  `GET /user/me/panels-summary`;
- keeping both active roads preserved a false UI and route drift risk.

Repair:
1. move the panels UI to `GET /user/me/panels-summary`;
2. remove active backend `GET /panels/{tg_id}/summary`;
3. remove the stale path from OpenAPI and route SSOT maps;
4. add a guard and architecture test.

Done criteria:
- frontend uses the self route;
- backend no longer exposes the stale tg-id summary route;
- OpenAPI no longer exposes the stale path;
- guard 1193 returns `status: ok`.

## Cycle 1194: helper/internal boundary repair

Problem:
- `/cron/tick` and `/tg/webhook` are runtime infrastructure roads;
- they looked like normal public schema roads;
- helper/internal roads must not be confused with user-facing roads.

Repair:
1. keep the runtime routes active;
2. hide them from OpenAPI via `include_in_schema=False`;
3. keep their secret checks in active code;
4. mark them internal in SSOT route maps;
5. add a guard and architecture test.

Done criteria:
- the runtime routes remain in code;
- OpenAPI does not expose them;
- SSOT marks them as internal;
- guard 1194 returns `status: ok`.

---

## Источник: `WORK_CYCLES_1196-1200_DETAILED_PLAN.md`

# WORK CYCLES 1196-1200 DETAILED PLAN

Status: executed in v168_07.

This file records the detailed work plan and completion boundary for
cycles 1196-1200. It continues the road-integrity program opened by the
external road audit and audit-of-audit.

## Cycle 1196 — route registry snapshot

Goal:
- build a static registry of method, path, router file and handler;
- detect duplicate method/path pairs;
- record the result as generated evidence.

Artifacts:
- `ops/routes/build_route_registry.py`
- `reports/generated/route_registry_1196.json`
- `docs/audits/ROUTE_REGISTRY_SNAPSHOT_1196.md`

## Cycle 1197 — schema gate recheck

Goal:
- re-check ORM table anchors;
- confirm that pre-release migration canon still uses `0001`;
- avoid creating `0002`;
- record that field-level proof needs a DB-backed future gate.

Artifacts:
- `ops/routes/check__schema__gate.py`
- `reports/generated/schema_gate_1197.json`
- `docs/audits/SCHEMA_GATE_RECHECK_1197.md`

## Cycle 1198 — false UI road scan

Goal:
- scan frontend path-like strings outside FAQ;
- classify matched and unproven strings;
- avoid editing frontend and FAQ;
- avoid treating navigation strings as deletion proof.

Artifacts:
- `ops/routes/scan_false_ui_roads.py`
- `reports/generated/false_ui_roads_1198.json`
- `docs/audits/FALSE_UI_ROAD_SCAN_1198.md`

## Cycle 1199 — contract test gap map

Goal:
- map tests against sensitive road keywords;
- identify where static anchors exist;
- keep payload and response shape proof as a future focused gate.

Artifacts:
- `ops/routes/map_contract_test_gaps.py`
- `reports/generated/contract_test_gap_map_1199.json`
- `docs/audits/CONTRACT_TEST_GAP_MAP_1199.md`

## Cycle 1200 — range closeout and handoff

Goal:
- close the 1176-1200 road-integrity preparation range;
- synchronize active cycle docs;
- hand off remaining runtime, DB-backed and E2E gates to 1201-1300.

Artifacts:
- `reports/generated/range_1176_1200_closeout.json`
- `docs/audits/ROAD_INTEGRITY_RANGE_CLOSEOUT_1200.md`
