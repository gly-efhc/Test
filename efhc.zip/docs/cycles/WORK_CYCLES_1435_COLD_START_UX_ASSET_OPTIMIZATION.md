# Cycle 1435 — Cold start MVP UX and bot image optimization

Status: DONE locally.
Archive: `EFHC_Bot_v170_10_cycle_1435_cold_start_ux_asset_optimization.zip`.
Base archive: `EFHC_Bot_v170_09_cycle_1434_security_minor_repair.zip`.

## Goal

Record the user decision that Cloud Run / Neon cold start is not an MVP
blocker when EFHC Bot preserves cached shell first, visual loading/effect
and stale-while-revalidate data refresh. Optimize the bot/skin hero image
used on first paint.

## Canon fixed

- Cold start is not an MVP blocker by itself.
- First screen must not wait for the database.
- Alembic migrations must not run on a user request.
- Heavy assets must not load before the visible interface.
- Backend must not be the only source of the initial visual state.
- Cloud Run `min instances = 0` and Neon Free / scale-to-zero are allowed
  for MVP.
- Cloud Scheduler health ping is allowed when operationally needed.
- Stale-while-revalidate is allowed for non-critical visual data.

## Asset optimization

- Source: `frontend/public/skins/1.webp`.
- Optimized runtime asset: `frontend/public/skins/1.webp`.
- Original PNG size: 1,146,051 bytes.
- WebP runtime size: 197,804 bytes.
- Reduction: about 82.7 percent for the first-paint asset.
- Runtime CSS now uses `/skins/1.webp` for `.efhc-energy-stage_image`.

## Files changed

- `docs/NORM/COLD_START_MVP_UX_CANON.md`
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
- `docs/SSOT/PROJECT_ASSET_LINKS.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_FAST_MANIFEST.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- `reports/REPORTS_INDEX.md`
- `map_element.md`
- `frontend/public/skins/README.txt`
- `frontend/public/skins/1.webp`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_cold_start_mvp_ux_asset_guard.py`

## Non-changes

- No backend runtime logic change.
- No business or economy logic change.
- No security/auth/money-flow change.
- No CI/workflow/lock-file change.
- No Alembic or DB migration change.

## Verification

Local targeted checks were run for AI law lock, architecture guard,
operator kernel tests, max line length, compileall and ZIP integrity.
No GitHub CI green, full pytest green, frontend build green, screenshot,
live Telegram proof or real wallet proof is claimed.
