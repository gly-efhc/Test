# WORK CYCLES 1183-1184 DETAILED PLAN

## Scope

This document is a local detailed execution note for cycles 1183-1184.
It does not replace the range file.  It explains why cycle 1183 is not
repeated and how cycle 1184 repairs the audit risk.

## Cycle 1183

Status: already completed in the previous HEAD as frontend/backend
contract guard work.  It must not be counted again in this pass.

## Cycle 1184

Goal: repair the ORM versus Alembic 0001 risk from the road audit.
The audit class is schema drift: services and models may rely on fields
that are not protected by the initial migration sanity gate.

Actions:

1. Keep the pre-release migration canon: only `0001_init.py`.
2. Do not create `0002`.
3. Expand the 0001 sanity gate for critical economic columns.
4. Add a static dependency-free guard for ORM and 0001 gate coverage.
5. Add an architecture test that can run without full FastAPI runtime.
6. Update road integrity documentation and report indexes.

Done means the static guard reports no missing critical model columns,
no missing critical 0001 gate columns, metadata-driven 0001 remains in
place and no pre-release 0002 is present.
