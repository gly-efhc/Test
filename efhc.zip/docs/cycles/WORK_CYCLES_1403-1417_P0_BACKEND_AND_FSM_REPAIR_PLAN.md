# WORK_CYCLES_1403-1417 — superseded planning note

Status: SUPERSEDED BY `docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`.  
Superseded in: `v169_86 / cycle 1404`.

Reason: user confirmed the three cycle-1403 iteration decisions and added a deposit-cache/idempotency requirement. The active plan moved repair cycles forward and added HEAL-0055 deposit-cache proof/retention cycles.

The original cycle-1403 audit result remains historically valid, but the active execution map is now 1404-1420.

# WORK_CYCLES_1403-1417 — P0 backend and FSM repair plan

Status: ACTIVE PLAN / CYCLE 1403 DONE.  
Created in: `v169.85 / cycle 1403`.  
Base HEAD: `EFHC_Bot_v169_84_cycle_1402_i18n_hardcoded_strings_repair.zip`.

## Governing rule

P0 money/identity fixes must be done in small controlled cycles. A cycle may repair code only when the root cause is understood. If logs are supplied, logs are read first. If a payment/contract decision is ambiguous, ask the user before changing product behavior.

## Cycle map

| Cycle | Purpose | Status | Notes |
|---:|---|---:|---|
| 1403 | P0 Red Zone audit/TZ and FSM split planning | DONE in v169.85 | Documentation-only audit cycle. No runtime repair. |
| 1404 | HEAL-0045 global_id identity canon repair | PLANNED | Repair referrals_crud joins/select/grouping to use User.global_id; add guard for global_id/User.id drift. |
| 1405 | HEAL-0040 payment_intents contract repair | PLANNED | User decision needed: recommended nullable package_id for custom deposit intents; add ORM/migration/route/test alignment. |
| 1406 | HEAL-0044 schema proof for transfer direction width | PLANNED | Add migration/schema guard proving direction varchar(24) for existing and fresh DB paths. |
| 1407 | HEAL-0023 idempotency read-through conflict hardening | PLANNED | Directly catch IDEMPOTENCY_CONFLICT, preserve read-through, add concurrency/idempotency guard. |
| 1408 | HEAL-0018 transaction boundary map | PLANNED | Audit callers and nested transaction helpers; define service-owned vs route-owned transaction contracts. |
| 1409 | HEAL-0018 transaction boundary repair | PLANNED | Remove unsafe nested workaround where possible; keep explicit savepoint only where documented and tested. |
| 1410 | HEAL-0024 exchange/withdraw atomicity repair | PLANNED | Withdraw create/hold/mark atomic transition or formal two-phase state machine with replay tests; verify exchange lock path. |
| 1411 | P0 cross-guard consolidation without deleting tests | PLANNED | Add source guards for identity/payment/idempotency/transaction/schema invariants; no skip/xfail. |
| 1412 | P0 backend targeted test and log repair | PLANNED | Run targeted backend tests; if logs supplied, logs first; no production-ready claim without CI proof. |
| 1413 | P0 range closure audit | PLANNED | Only after factual checks; produce closure audit/non-claims. |
| 1414 | FSM states.py split import/dependency map | PLANNED | Audit imports of backend.app.bot.states and design compatibility facade. |
| 1415 | FSM dto/backend extraction | PLANNED | Move BotStates/ConversationState/StateBackend/MemoryStateBackend to fsm/dto.py and fsm/backend.py with facade exports. |
| 1416 | FSM manager extraction | PLANNED | Move StateManager/get_state_manager to fsm/manager.py; preserve singleton semantics. |
| 1417 | FSM decorators extraction and regression proof | PLANNED | Move require_state/advance_state/clear_state_after to fsm/decorators.py; compile/import/targeted handler tests. |


## Blocking iteration questions before code repair

1. For HEAL-0040, confirm whether `payment_intents.package_id` may be nullable for custom deposit intents. Recommendation: yes, nullable only for custom/package-less intents.
2. For HEAL-0024 and HEAL-0018, confirm service-boundary repair may adapt route/service transaction ownership where necessary. Recommendation: yes, but only cycle-by-cycle.
3. For FSM split, confirm `backend/app/bot/states.py` should remain a compatibility facade during migration. Recommendation: yes.

## Non-claims

This plan does not claim GitHub CI green, full pytest green, npm build, screenshots, live Telegram proof, real wallet proof or release readiness.
