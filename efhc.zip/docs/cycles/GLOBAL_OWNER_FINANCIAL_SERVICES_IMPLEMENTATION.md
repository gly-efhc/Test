# Реализация canonical owner в финансовых сервисах

## Результат

Транзакционный и доменный write-path переведён на canonical `global_id`.
Временный `global_id` принимается только как provider selector и разрешается
через общий write-side owner boundary.

## Транзакции и ledger

Обновлены основные credit, debit и bonus entrypoints, а также no-commit
варианты. Строка владельца блокируется до денежной мутации. Ledger пишет
`global_id` и nullable `global_id`. Повтор одной операции с другим selector
возвращает существующий результат вместо создания второго начисления.

## Panels

Активация, создание и архивирование используют `global_id`. Panel records
сохраняют canonical owner и необязательный Telegram provider attribute.
Referral callback временно выполняется только для Telegram account и будет
переведён отдельно согласно утверждённому плану.

## Withdrawals

Создание заявки и hold остаются одной атомарной границей. Поиск pending,
обновление `hold_done`, отмена и refund привязаны к `global_id`. Audit meta
содержит canonical owner.

## Payment Intents

Три create-flow используют canonical owner. Для Telegram сохранён прежний
numeric payload token. Для account без Telegram используется формат
`G##########`. Parser распознаёт оба формата. Watcher-подключение нового
owner token остаётся отдельным caller-tail и не объявляется завершённым.

## Схема совместимости

Provider-колонки `global_id` сделаны nullable для transfer log, panels, panel
archive, withdraw requests, deprecated withdrawals и payment intents. Это
EXPAND-совместимость для TON-only account, а не production cutover.

## Идемпотентность

Основные keys не меняются при выборе `global_id` или `global_id`. Read-through
проверяет canonical owner. Исторические keys не переименовывались.
Referral и exchange keys, завязанные на Telegram, остаются в следующих
утверждённых циклах.

## Запрещённые утверждения

Этот пакет не означает полный `global_id` cutover, не переключает
`legacy_authoritative` и не удаляет legacy aliases. Полная квалификация
требует PostgreSQL и unchanged exact-head GitHub CI.
