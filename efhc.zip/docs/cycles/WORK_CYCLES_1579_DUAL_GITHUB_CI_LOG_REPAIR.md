# Work cycle 1579 — dual GitHub CI log repair

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED.
Input HEAD: `EFHC_Bot_v171_73.zip`.
Output HEAD: `EFHC_Bot_v171_74.zip`.
Release output: `EFHC_Bot_v171_74_RELEASE.zip`.

## Supplied evidence

- Development log: `logs_81724444881.zip`.
- Release log: `logs_81726814646.zip`.

## Root causes

1. Both contours failed Ruff `SIM117` because the release database contract used nested context managers.
2. Release pytest failed before its required-route assertion because FastAPI 0.140 inserted an internal `_IncludedRouter` object without a `path` attribute into `app.routes`.
3. The release builder still embedded a hardcoded v171.73 `source_head`, creating provenance drift for the next archive.
4. The copied root pytest configuration required the external workflow to inject `PYTHONPATH=backend`.
5. Direct execution of `python ops/release/build_release_archive.py` failed because package imports depended on an externally prepared module path.
6. Current release ENV/Compose/update examples remained on v171.73, and dynamic `source_head` initially produced the invalid dotted filename `EFHC_Bot_v171.74.zip`.

## Repair

- combined PostgreSQL connection/cursor contexts;
- added a route-path collector that ignores only pathless framework markers;
- added a regression test for a mixed marker/real-route collection;
- retained the exact mandatory route set;
- modernized the Payment Intent Pydantic schema config to remove the project-owned deprecation warning;
- added a standalone release pytest profile with `pythonpath = backend`;
- derived `RELEASE_METADATA.source_head` from the requested version and made release asset/build CLI version explicit;
- repaired CI-log task classification for the user's Russian wording;
- synchronized active HEAD, handoff and temporary-memory documents;
- made the release builder work both as a package module and as a direct CLI and added a regression guard.
- synchronized v171.74 ENV/image defaults and update examples, normalized semantic versions to underscore archive tokens, and added guards against future naming drift.

## Local validation

- development bounded groups: `2321 passed, 142 skipped, 0 failed`;
- release acceptance without live PostgreSQL: `7 passed, 1 deselected, 0 failed`;
- internal release SHA-256 inventory: `739/739 files`;
- provider-independent release gate: passed during release build.

No tests were deleted, skipped or weakened. No CI workflow was changed. Runtime financial behavior, migrations, UI, navigation, localization and transaction truth were not changed.
