# WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN

Purpose: continue the active v169 public UI lane after the static public
regression proof and range checkpoint.

## Source checkpoint

- 1361: Public UI screenshot QA preparation. DONE in v169_39.
- 1362: Public UI regression proof pass. DONE in v169_40.
- 1363: Next range extension checkpoint. DONE in v169_41.

## Active / Next

- 1364: Public browser screenshot evidence harness and capture manifest. DONE in v169_42 as harness/manifest only; screenshots are not claimed.
- 1365: Public visual beauty pass — Energy, Panels, Exchange. DONE in v169_43 as static/source polish; screenshots are not claimed.
- 1366: Public visual beauty pass — Tasks, Referrals, Ranks. DONE in v169_44 as static/source polish; screenshots are not claimed.
- 1367: Profile / Wallet / History / FAQ visual trust pass. DONE in v169_45 as static/source visual trust polish; screenshots are not claimed.
- 1368: HUB / Browser Shop / Withdraw / Ads visual trust pass. DONE in v169_46 as static/source visual trust polish; screenshots are not claimed.
- 1369: I18N critical audit repair pass. DONE in v169_47.
- 1370: Public i18n untranslated keys remediation. DONE in v169_48 as priority remediation; remaining tail routed to future language/FAQ passes.
- 1371: FAQ wave-3 translation/status repair and semantic alignment repair. DONE across v169_49-v169_50; additional semantic gate continuation in v169_51.
- 1372: FAQ semantic approval gate. DONE in v169_51; TMA/TonConnect work stayed blocked until FAQ semantics were checked.
- 1373: Russian source language canon lock and RU regression audit. DONE in v169_52.
- 1374: Telegram Mini App shell polish — viewport, theme, BackButton, safe-area. DONE in v169_53 as source/static polish; live Telegram client proof is not claimed.
- 1375: TonConnect / Wallet UX proof and range closure / next-audit handoff. DONE in v169_54 as static/source proof; live wallet transaction, Telegram client, browser screenshot, GitHub CI and release-ready verdict are not claimed.

## Lane rules

- Do not import Vue/Solid/Nuxt/Vanilla runtime from sandbox archives.
- Keep Next.js 16.2.6 / React 19.2.6 / Tailwind CSS 4.3.0 as the frontend canon.
- Do not change EFHC economics from visual work.
- Do not expose admin diagnostics to public UI.
- Do not claim screenshot/browser proof without actual evidence.
- Do not claim GitHub CI green unless the user provides GitHub CI proof.
- Keep cycle labels in `docs/cycles/`, `docs/audits/` and `reports/`; keep
  product/frontend/admin filenames semantic.

## 1364 target detail

Public browser screenshot evidence harness should create a clear evidence map
for the 14 public routes:

- `/`, `/panels`, `/exchange`, `/tasks`, `/referrals`, `/referrals/active`,
  `/referrals/inactive`, `/ranks`, `/web-profile`, `/faq`, `/hub`,
  `/browser-shop`, `/withdraw`, `/ads`.

Expected output:

- screenshot evidence manifest;
- browser/device matrix;
- guard that prevents claiming screenshot proof without evidence files or an
  explicit non-claim;
- updated public QA documents.

## 1365-1368 visual focus

The next visual passes should be human-facing, not technical only. Each pass
must improve readability, spacing, hierarchy, empty/loading/error states and
button clarity without changing economic meaning.

## 1369-1371 i18n audit repair focus

The v169.45 i18n audit becomes the active priority before TMA/wallet polish.
Cycle 1369 fixes critical runtime/value blockers. Cycles 1370-1371 should repair
the remaining untranslated public keys and FAQ wave-3 tail.

## 1372-1375 shell/wallet/readiness focus

Telegram Mini App and TonConnect work may use `map_element.md` as the reference
navigation map. Any wallet/transaction behavior must pass SSOT/NORM review
before runtime changes.

## 1374-1375 readiness focus

The late range should convert static proof into stronger acceptance evidence:
E2E interactions, boundary screenshots, localization/accessibility checks and a
final readiness checkpoint.


## 1364 completion note

Cycle 1364 created:

- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`;
- `tests/frontend/e2e/test_public_screenshot_capture_manifest.py`;
- `tests/architecture/test_public_browser_screenshot_evidence_harness.py`.

The pass intentionally does not include real screenshots. Actual browser
capture remains controlled by `EFHC_RUN_E2E=1` and `EFHC_CAPTURE_SCREENSHOTS=1`.


## 1365 completion note

Cycle 1365 created source-level visual polish for Energy, Panels and Exchange:

- `docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_ENERGY_PANELS_EXCHANGE.md`;
- `reports/generated/public_visual_beauty_pass_v169_43.json`;
- `tests/architecture/test_public_visual_beauty_pass_energy_panels_exchange.py`.

The pass intentionally does not include real screenshots. Actual browser capture
remains controlled by `EFHC_RUN_E2E=1` and `EFHC_CAPTURE_SCREENSHOTS=1`.


## 1366 completion note

Cycle 1366 created source-level visual polish for Tasks, Referrals and Ranks:

- `docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md`;
- `reports/generated/public_visual_beauty_pass_v169_44.json`;
- `tests/architecture/test_public_visual_beauty_pass_tasks_referrals_ranks.py`.

The pass intentionally does not include real screenshots. Actual browser capture
remains controlled by `EFHC_RUN_E2E=1` and `EFHC_CAPTURE_SCREENSHOTS=1`.

## 1367 completion note

Cycle 1367 created source-level visual trust polish for Profile, Wallet, History and FAQ:

- `docs/frontend/PUBLIC_VISUAL_TRUST_PASS_PROFILE_WALLET_HISTORY_FAQ.md`;
- `reports/generated/public_visual_trust_pass_v169_45.json`;
- `tests/architecture/test_public_visual_trust_pass_profile_wallet_history_faq.py`.

The pass does not claim browser screenshots, live E2E execution, GitHub CI green
or release readiness.


## 1368 completion note

Cycle 1368 created source-level visual trust polish for HUB, Browser Shop, Withdraw and Ads:

- `docs/frontend/PUBLIC_VISUAL_TRUST_PASS_HUB_BROWSER_SHOP_WITHDRAW_ADS.md`;
- `reports/generated/public_visual_trust_pass_v169_46.json`;
- `tests/architecture/test_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py`.

The pass does not claim browser screenshots, live E2E execution, GitHub CI green
or release readiness.


## 1369 completion note

Cycle 1369 repaired the critical i18n audit blockers from the v169.45 audit:

- `frontend/src/lib/i18n.ts` now uses English-first player fallback;
- all 13 locale files have non-empty values for the five previously empty public keys;
- Hindi placeholder drift is repaired for wallet count and withdraw request number;
- public shell hardcoded Russian fallback issues from the audit are repaired;
- `ops/i18n/audit_bot_texts_parity.py` importlib typo is fixed;
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` no longer claims quality-complete status for languages with known FAQ translation tail.

This pass does not claim full translation completion. The remaining public untranslated tail and FAQ wave-3 translation tail are planned for cycles 1370-1371.


## FAQ semantic alignment repair

Before continuing TMA/TonConnect work, cycle 1371 received a corrective semantic alignment pass in v169_50. Changed FAQ translations from v169_49 were checked against Q/A, FAQ approval records and RU/FAQ anchors. The pass corrected EN/wave drift for wallet and Navigation/Rules items.


## 1373 Russian source canon lock

The user explicitly confirmed: if RU FAQ and EN FAQ diverge, RU/FAQ-SSOT is the semantic anchor only after checking Q/A; SSOT itself can regress and must be verified against Q/A. All translations must be from verified Russian meaning. Translating Russian from English is forbidden.

TMA/TonConnect work resumes only after this language-canon lock.


## 1374 completion note

Cycle 1374 completed Telegram Mini App shell polish:

- `docs/frontend/TELEGRAM_MINI_APP_SHELL_POLISH.md`;
- `reports/generated/telegram_mini_app_shell_polish_v169_53.json`;
- `tests/architecture/test_telegram_mini_app_shell_polish.py`.

The pass covers viewport state, Telegram/browser runtime markers, content/device safe-area vars, public route BackButton behavior and TMA shell CSS. It does not claim live Telegram client execution, browser screenshots, GitHub CI green or release readiness.


## 1375 completion note

Cycle 1375 closes the `1351-1375` range. It created:

- `docs/frontend/TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md`;
- `reports/generated/tonconnect_wallet_ux_range_closure_v169_54.json`;
- `tests/architecture/test_tonconnect_wallet_ux_range_closure.py`.

`1376+` is intentionally blocked until a new audit/task is supplied by the user in chat.

Non-claims: no live Telegram client proof, no real TonConnect transaction, no browser screenshot verdict, no GitHub CI green and no release-ready verdict.
