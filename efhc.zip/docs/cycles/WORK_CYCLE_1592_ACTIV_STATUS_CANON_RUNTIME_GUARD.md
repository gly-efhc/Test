# Work Cycle 1592 — Activ status canon and runtime consolidation

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.
Archive target: `v171.89`.
Routes: `ci_log_exact_failure_repair`,
`activ_status_permanence_runtime_guard` and
`archive_numbering_and_release_gate`.
Fallback: `false`.

## Input evidence

- GitHub run `82129404864`: exact v171.88 development archive, green;
  `2612 passed, 20 skipped` and all quality/build gates passed.
- GitHub run `82130816646`: exact v171.88 release archive, green;
  `13 passed` and all release gates passed.
- User specification: `TZ_activ_status_docs_and_control_test.md`.

## Confirmed runtime defect

The project had multiple technical definitions of one business status:

- `_count_active_referrals()` used `EXISTS` against current panel rows;
- `SQL_LIST_REFERRALS` used `panels_count > 0`;
- Admin user detail joined active panel rows;
- `admin_summary` and referral CRUD correctly used
  `referral_links.activated_at`.

Those definitions happened to agree while panel rows remained present,
but diverged after physical deletion. This contradicted the permanent
Activ event model.

## Repair

- Use `referral_links.activated_at IS NOT NULL` for every Activ consumer.
- Keep `panels_count` only as an informational UI value.
- Remove legacy Admin queries against `{SCHEMA_REF}.ref_links` and active
  panels; use the canonical `ReferralLink` ORM model.
- Synchronize Kernel, NORM, service comments and Pydantic descriptions.
- Increase fail-closed GitHub integration minimum from 24 to 25.
- Add one real PostgreSQL control test that deletes all panels after
  production first-panel activation and checks all public/Admin readers.

## Exploratory ambiguity scan

- Locale files contain only neutral panel-count labels; no locale defines
  Activ from current panel existence.
- Referral FAQ texts describe the first activation trigger and no repeat
  bonus; no correction was required.
- Grafana/dashboard NORM files contain visual/analytics terminology but
  no competing runtime definition of Activ.
- One additional ambiguity was found in Admin users runtime and repaired.

## Proof boundary

Targeted structural guards pass and 25 integration tests are collected.
The complete local exact-tree inventory finished in non-overlapping
bounded groups: `2704/2704`, `2532 passed`, `172 skipped`, `0 failed`,
`0 errors`. The monolithic command reached the sandbox time limit and is
not counted. The sandbox has no PostgreSQL service, so the destructive
integration case is not claimed as executed. Fresh exact v171.89 GitHub
CI is the required runtime proof.
