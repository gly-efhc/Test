# WORK CYCLE 1471 — PANELS PORTFOLIO SANDBOX PROTOTYPE

Human title: Panels Portfolio Sandbox Prototype

Status: `DONE_LOCAL`

Archive: `v170.47`

Input HEAD: `v170.46 / Energy Dashboard Visual QA`

## Goal

Create a sandbox-only Panels Portfolio Dashboard prototype without changing live `/panels`, backend truth, EFHC economics or panel activation flows.

## Added

- `frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx`;
- `docs/NORM/PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`;
- `docs/NORM/PANELS_PORTFOLIO_SANDBOX_GRAFANA_ELEMENT_ANALYSIS.md`;
- `reports/generated/panels_portfolio_sandbox_prototype_v170_47.json`;
- `reports/change_cycle_2026-06-07_v170_47_cycle_1471_panels_portfolio_sandbox_prototype.md`;
- `tests/architecture/test_panels_portfolio_sandbox_prototype.py`.

## Prototype structure

- portfolio toolbar;
- period filter;
- active/archive state filter;
- total/active/archive/nearest expiry KPI strip;
- generated kWh summary;
- lifecycle segmented progress;
- portfolio trend preview;
- active/archive distribution preview;
- activity strip preview;
- individual panel cards;
- 180-day lifecycle countdown;
- truth/safety boundary panel.

## Boundaries

Changed: docs, tests, CSS, sandbox prototype component and navigation indexes.

Not changed:

- EFHC economics;
- backend routes;
- DB migrations;
- OpenAPI;
- package dependencies;
- lock files;
- CI workflows;
- runtime `/panels` page;
- panel activation logic;
- money/write flows.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime code is not copied.

## Local validation

Targeted validation is recorded in the final chat report and generated machine report.

Not claimed:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe cycle

`1472 — Panels Portfolio Runtime Port`
