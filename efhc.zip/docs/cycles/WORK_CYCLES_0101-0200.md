# EFHC — ЦИКЛЫ 0101–0200
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `WORK_CYCLES_101-200.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 101-200

Диапазон циклов: 101-200.
Источник: segmented canonical cycle series.

| 101 | done | Log-driven fixes + series 101–110 planning. | Исправлены подтверждённые log-driven дефекты: alembic sanity drift по `hub_links` в `SSOT_TABLES_ORM.csv`/`SSOT_TABLES_MIGRATIONS.csv`, frontend type/import/haptics errors в Hub admin/Hub page, добавлен log-audit и сформирован новый план 101–110. |
| 102 | done | Full CI parity wave. | Лог-ошибки устранены, `0002` squashed into `0001`, active transition aliases сняты, docs/route-count/freeze cluster синхронизирован до 88 routes; после прямого full pytest осталось 27 падений в FAQ/healer/legacy-test-expectation слоях. |
| 103 | done | FAQ approval governance restore. | Добавлены `docs/GENERAL/FAQ_APPROVAL_GOVERNANCE.md`, `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md`, `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`; зафиксирован обязательный draft → approval → rewrite → rebuild gate, а historical section-13 draft цикла 77 оформлен retroactive entry `FAQ-APPROVAL-0001`. |
| 104 | done | FAQ runtime vs SSOT parity audit. | Добавлен `docs/FAQ_RUNTIME_SSOT_PARITY_AUDIT.md`; подтверждено по 13 языкам, что active SSOT JSON имеет 20 sections / 250 Q&A, section 13 = `Hub`, а текущий runtime `frontend/src/data/faq/catalogs.ts` не показывает прямого parity drift, требующего rewrite в этом же цикле. |
| 105 | done | FAQ code generation hardening. | Generator `ops/scripts/generate_faq_catalogs_from_ssot.py` теперь валидирует `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`, inventory 20/250 по 13 языкам и section 13 = `Hub`; runtime `frontend/src/data/faq/catalogs.ts` пересобран с generated header, добавлен lock `test_faq_code_generation_hardening_lock.py`. |
| 106 | done | FAQ bot/help parity wave. | Добавлены `/faq` bot command, `kb_faq_entry()`, RU/EN help texts и `faq.entry`; bot/help слой теперь явно отражает current FAQ inventory 20/250 и даёт прямой вход в WebApp FAQ. |
| 107 | done | Multilingual FAQ legal wording audit. | Проведён прямой audit 13 FAQ языков; зафиксированы multilingual wording residuals (`navigation layer`, `wallet-based`, `Wallet`), подготовлены draft package и governance entry FAQ-APPROVAL-0002 без rewrite до отдельного пользовательского approval. |
| 108 | done | RU Wallet FAQ approved rewrite wave 1. | Внедрить уже согласованные W1–W3 в русский Wallet FAQ, сохранить 250 Q/A, пересобрать runtime и зафиксировать approval trail. |
| 109 | done | RU VIP NFT approved rewrite wave 1. | Внедрить уже согласованные V1–V5 в русский VIP NFT FAQ, сохранить 250 Q/A, пересобрать runtime, обновить approval trail и зафиксировать final wording по автоматическому VIP-статусу. |
| 110 | done | RU Hub approved rewrite wave 1. | Внедрить уже согласованные H1–H4 в русский Hub FAQ, сохранить 250 Q/A, пересобрать runtime, обновить approval trail и зафиксировать нейтральные формулировки для EFHC и VIP линий в Hub. |


## Плановые циклы 111–120 — post-handoff parity recovery

| № | Статус | Цель | Описание |
|---|---|---|---|
| 111 | done | RU Exchange approved rewrite wave 1. | Внедрить уже согласованные E1, E3, E4 в русский Exchange FAQ, сохранить 250 Q/A, пересобрать runtime, обновить approval trail и зафиксировать нейтральный смысл обмена без слов из ряда «заработать». |
| 112 | done | RU Top bar FAQ audit and draft package. | Провести русский аудит FAQ по верхней панели, выделить слабые и сильные вопросы, согласовать T1–T4 и определить карту замен без роста количества Q/A. |
| 113 | done | RU Top bar approved rewrite wave. | Внедрить уже согласованные T1–T4 в русский FAQ по верхней панели, сохранить 250 Q/A, пересобрать runtime, обновить approval trail и одновременно исправить Hub duplicate slot по прямому указанию пользователя. |
| 114 | done | RU forbidden wording cleanup audit. | Провести русский аудит FAQ на user-facing слова «купить», «покупка», «депозит», «заработать» и другие инвестиционные формулировки; подготовить и согласовать точные нейтральные замены без роста количества Q/A. |
| 115 | done | RU forbidden wording approved rewrite wave. | Внедрить уже согласованные F1–F8 в русский FAQ, сохранить 250 Q/A, пересобрать runtime, обновить approval trail и снять user-facing инвестиционно-токсичные формулировки. |
| 116 | done | RU panels wording inventory audit. | Провести полный русский аудит panel wording в FAQ, bot/help, UI и коде: активация/деактивация/архивные панели, traces `купить`/`покупка`/`цена`, и определить точные точки замены без роста количества Q/A. |
| 117 | done | RU panels FAQ approved rewrite wave 1. | Внедрить уже согласованные P1–P8 в русский panels FAQ, сохранить 250 Q/A, пересобрать runtime, обновить approval trail и снять user-facing слова `купить` и `цена` из panel FAQ. |
| 118 | done | RU panels bot/help and UI draft package wave 1. | Подготовить русский draft-пакет bot/help и frontend UI wording по панели под канон «Активация панели / Деактивация панели / Архивные панели» без массового внедрения в код до отдельного approval. |
| 119 | done | RU panels approved bot/help and UI rewrite wave 1. | Внедрены только однозначно утверждённые RU panel user-facing замены PB1, PB2, PB3, PB4 и PB6 в frontend locale/UI/profile/admin слоях; PB5 оставлен pending до отдельного согласования, approval trail обновлён, count FAQ не менялся. |
| 120 | done | RU FAQ governance parity audit after rewrites. | После волн 108–119 проведён аудит approval trail, лимита 250 Q/A, runtime parity и готовности к panel code-refactor серии 121–136; подтверждено, что русские approved rewrites внедрены по register/manifest, runtime rebuilt, а unresolved replacements явно оставлены pending, без скрытых замен. |


Cycle 102 closure note: full pytest is green on HEAD v160_31 (275 passed, 25 skipped); log fixes, 0002->0001 squash, alias sunset, docs/route recount, FAQ/test/healer parity synced.


Execution rule: в каждом цикле делать максимально возможный объём подтверждаемой работы по текущему HEAD; не переносить на следующий цикл то, что реально можно закрыть в моменте.

Main mini-TZ truth source: `docs/cycles/WORK_CYCLES.md`; дополнительные plan/docs допускаются только как вспомогательные зеркала, но не как второй источник истины.

Collapsed plan-docs 91–130 into `docs/cycles/WORK_CYCLES.md`: separate plan files are removable once their useful residue is transferred here.

| 121 | done | Panels admin/accounting wording audit + docs consolidation audit. | Выполнен прямой audit panel admin wording и документации: подтверждено, что агрегат `panels_total_paid_efhc` применяется в admin overview как общий debit по panel activation reason-коду, не делит EFHCb/EFHCm, panel spend идёт по канону bonus->main; добавлен отчёт по document consolidation с кандидатами на удаление, объединение, обновление и усиление. |
| 122 | done | Docs consolidation decisions + canonical docs wave 1. | Удалён устаревший duplicate `docs/FAQ_CYCLES_108_120_MINI_TZ.md`, добавлены единые документы `docs/SSOT/USER_FACING_WORDING_CANON.md` и `docs/FAQ_REPLACEMENT_LEDGER.md`, а правило `docs/cycles/WORK_CYCLES.md` как единственного main mini-TZ truth source зафиксировано напрямую в журнале. |
| 123 | done | Plan-doc collapse wave 1 + PB5-3 labels canon. | Начато сворачивание plan-docs в `docs/cycles/WORK_CYCLES.md`: удалены устаревшие plan/docs 91–130 как отдельные truth-source files, обновлены `docs/FORBIDDEN_USER_FACING_WORDING_AUDIT.md` и `docs/SSOT/FAQ_SSOT.md`, а PB5-3 labels `EFHCb / EFHCm / EFHC total` зафиксированы как утверждённый admin-facing канон будущего refactor-а. |
| 124 | done | RU panels WebApp UI wording draft wave 1. | Подготовлен прямой draft WebApp/admin UI panel wording: собраны уже утверждённые user-facing labels для `activate_panel`, `subtitle_price_100`, `activate_ok`, `Активировано панелей всего` и profile reason, а также зафиксированы точки применения и будущий PB5-3 split counters block. |
| 125 | done | RU panels approval package consolidation. | Собран единый русский approval package по panel-line: FAQ approvals P1-P8, UI approvals PB1/PB2/PB3/PB4/PB6 и approved PB5-3 labels для будущего admin counters refactor; явно зафиксировано, что backend/admin split counters ещё не внедрены и ждут cycles 137-140. |
| 126 | done | RU panels approved SSOT rewrite wave. | По прямому аудиту подтверждено: `docs/SSOT/faq_ssot/ru/faq_ru.*` уже содержат approved P1-P8, но `docs/SSOT/PANELS_SSOT.md` и `docs/SSOT/FAQ_SSOT.md` ещё хранили stale wording `купить панель` / `цена панели` / `после покупки первой панели`; докслой синхронизирован с каноном `Активация панели / Archive / Activ`, без runtime rebuild. |
| 127 | done | Panel activation reason code sync wave. | По прямому аудиту подтверждено: активный backend ещё писал `reason="panel_purchase"`, admin overview суммировал только `panel_purchase`, а history runtime маппил лишь legacy reason; код и docs синхронизированы на канон `panel_activation`, при этом admin query и history mapping оставлены backward-compatible для исторических записей `panel_purchase`. |
| 128 | done | Multilingual panels wording draft package. | Подготовлен `docs/PANELS_MULTILINGUAL_DRAFT_PACKAGE.md`: зафиксирован draft-only multilingual package по 12 языкам для panel-line на базе утверждённого русского канона, без runtime/locale rewrite и без скрытой FAQ-замены. |
| 129 | done | Multilingual panels approved rewrite and runtime sync. | По прямому аудиту подтверждены stale multilingual panel traces в `docs/SSOT/faq_ssot/*` и runtime; выполнен controlled rewrite panel-line для 12 языков, исправлен `FAQ_APPROVAL_MANIFEST.json` count drift, а `frontend/src/data/faq/catalogs.ts` штатно пересобран из SSOT без скрытой русской FAQ-замены. |
| 130 | done | Panels wording final audit. | Проведён финальный audit active panel wording: дочищены подтверждённые residual traces в `docs/SSOT/faq_ssot/*` и `frontend/src/data/faq/catalogs.ts`, пересобран runtime FAQ и зафиксировано, что дальнейшие остатки относятся уже к legacy/non-runtime FAQ files и technical internal naming слоям. |

| 131 | done | Backend panels terminology audit. | Проведён прямой backend audit: зафиксированы compatibility anchors `/panels/buy/{tg_id}`, `buy_panel`, `purchase_panel`, `on_user_first_panel_purchase` и dual-read `panel_purchase`/`panel_activation`; подтверждено, что текущий drift является technical naming debt и должен лечиться отдельным controlled refactor cycle, а не скрытой ломкой integration surface. |
| 132 | done | Backend panels terminology refactor wave 1. | Без ломки compat surface переведены backend summary/docstrings/details на activation wording: route summary, schema descriptions, service detail и referral comments; при этом `/panels/buy/{tg_id}`, `buy_panel`, `purchase_panel` и compatibility wrapper `on_user_first_panel_purchase` сохранены. |
| 133 | done | Frontend panels terminology audit. | Подтверждено: active UI уже использует canonical labels `activate_panel` / `activate_ok`; drift сидел в local naming/comments `frontend/src/pages/panels.tsx`, тогда как legacy `frontend/src/data/faq/*.ts` остаются отдельным non-runtime follow-up слоем. |
| 134 | done | Frontend panels terminology refactor wave 1. | Active panels page переведён на activation naming без смены compat endpoint: локальная функция `buyPanel` заменена на `activatePanel`, comments переведены на activation canon, а user-facing labels оставлены canonical через существующие locale keys. |
| 135 | done | Panels bot/help and API wording sync. | Синхронизированы route/docstring/API wording по панели: `docs/GENERAL/architecture.md`, `docs/GENERAL/specification.md`, `docs/SSOT/PANELS_SSOT.md`, `docs/NORM/EVENTS_MATRIX.md` и `docs/TZ_ADDENDUM_LOST_FUNCTIONS.md` теперь описывают activation canon при сохранении technical compat names `/panels/buy` и `panels.buy_*`. |
| 136 | done | Panels backend/frontend parity audit. | Проведён прямой parity audit активного panels слоя после cycles 132-135; подтверждено, что user-facing flow уже выровнен на activation canon, а оставшийся drift находится в admin-facing accounting visibility и требует PB5-3 split counters. |


| 137 | done | Panels admin counters design for bonus/main split. | Зафиксирован дизайн PB5-3: source of truth = `efhc_transfers_log`, filters `panel_purchase/panel_activation` + `direction=debit`, split counters = total/main/bonus, порядок рендера в admin facts = EFHC total -> EFHCm -> EFHCb, data migration не требуется. |
| 138 | done | Panels admin counters backend implementation wave 1. | Backend admin overview теперь считает и возвращает `panels_total_paid_efhc`, `panels_total_paid__main__efhc`, `panels_total_paid_bonus_efhc`; исторические reason-коды `panel_purchase` и `panel_activation` включены одновременно, user-facing/runtime panel wording не менялся. |
| 139 | done | Panels admin counters frontend/admin UI sync. | `frontend/src/pages/admin/index.tsx` и `frontend/src/pages/admin/reports.tsx` синхронизированы с PB5-3: старый ambiguous label убран, facts рендерятся в каноническом порядке total/main/bonus, admin reports page теперь показывает structured overview block вместо сырого частичного summary. |
| 140 | done | Panels admin counters parity audit. | Финальный audit подтвердил: active admin-facing слой показывает PB5-3 split counters с approved labels, backend queries dual-read historical + new reason codes, ambiguous panel spend label в active admin overview устранён; follow-up по этой линии не требуется. |


| 141 | done | Legacy frontend FAQ sources audit. | Проведён прямой audit `frontend/src/data/faq/*`: active runtime source подтверждён как `catalogs.ts`, а единственным вводящим в заблуждение legacy FAQ source оказался неиспользуемый `frontend/src/data/faq/ru.ts` со stale panel/Hub traces. |
| 142 | done | Legacy frontend FAQ sources cleanup wave. | `frontend/src/data/faq/ru.ts` переведён в compatibility alias на generated `faqCatalogByLang.ru`, stale standalone FAQ tree удалён; в `frontend/src/data/faq/meta.ts` устранён legacy `Boutique` drift для section 13. |
| 143 | done | Backend internal panel naming audit. | Проведён прямой audit backend internal naming: `/panels/buy`, `buy_panel`, `purchase_panel`, `on_user_first_panel_purchase` и `panel_purchase` подтверждены как compatibility anchors текущей release-line, а безопасная зона refactor-а ограничена internal comments/docstrings/examples. |
| 144 | done | Backend internal panel naming refactor. | Без ломки совместимости внутренняя документация backend переведена на activation canon: referral service comments/docstrings и internal examples больше не описывают первую панель как покупку, while compatibility anchors сохранены без изменения контрактов. |
| 145 | done | Post-panel series release audit. | Финальный release-audit подтвердил: cycles 129-145 отражены в архиве, active FAQ/runtime/admin layers синхронизированы, legacy FAQ source `ru.ts` больше не хранит stale tree, а panel compatibility anchors явно зафиксированы в docs без скрытой ломки контрактов. |


| 146 | done | Alias inventory audit. | Проведён прямой аудит алиасов по HEAD: безопасно удаляемыми подтверждены `app.deps.etag`, `purchase_panel` и `on_user_first_panel_purchase`; публичные compatibility surfaces `/panels/buy`, `/shop/*`, `/admin/shop/*` и historical `panel_purchase` сохранены как ещё не доказанно безопасные к удалению. |
| 147 | done | Safe alias removal wave 1. | Из кода удалены безопасные internal aliases `etag`, `purchase_panel`, `on_user_first_panel_purchase`; роуты и тесты переведены на canonical `make_etag` и `on_user_first_panel_activation` без ломки runtime-поведения. |
| 148 | done | Routes audit and repair wave 1. | Выполнен route audit panel-line: добавлен канонический маршрут `POST /panels/activate/{tg_id}`, frontend Panels переведён на новый путь, а `POST /panels/buy/{tg_id}` сохранён как compatibility wrapper для старых клиентов. |
| 149 | done | Migrations static parity audit. | По текущему канону migration layer должен оставаться single-base `0001_init.py`; отдельный active файл `0002_create_hub_links.py` не допускается, а `hub_links` должны быть интегрированы в `0001`. |
| 150 | done | Post-alias release audit. | Финальный audit подтвердил: safe internal aliases удалены, canonical panels activation route добавлен и задокументирован, compatibility public routes сохранены только там, где их удаление не подтверждено безопасным по архиву. |

## Предложение следующих циклов 151–160

| № | Статус | Цель | Описание |
|---|---|---|---|
| 151 | done | Shop public alias caller audit. | Прямым аудитом подтверждено: активных frontend/bot callers у `/shop/*` больше нет; остаётся только backend compatibility/API surface. |
| 152 | done | Admin shop alias caller audit. | Прямым аудитом подтверждено: активных admin UI/bot callers у `/admin/shop/*` больше нет; остаётся только backend admin compatibility surface. |
| 153 | done | Canonical panels route docs/openapi sync. | SSOT routes, route inventories, route-table-map, OpenAPI snapshot и markdown inventory синхронизированы с новым `POST /panels/activate/{tg_id}` при сохранении compat `POST /panels/buy/{tg_id}`. |
| 154 | done | Dead frontend/admin page sweep. | Прямой аудит подтвердил: `shop.tsx` и `admin/shop.tsx` уже удалены; `hub.tsx` и `admin/hub.tsx` остаются валидными Next entry shims, новых dead pages не найдено. |
| 155 | done | Route-table-map refresh. | Обновлены route inventory freeze, route-table-map, routes-tables-migrations и route-count docs до 89 active routes после добавления canonical panels activation path. |
| 156 | done | Migration live-run readiness audit. | Подтверждена структурная готовность `alembic.ini`/`env.py`/versions и test harness; live `alembic upgrade head` в этой среде не подтверждён из-за отсутствия `sqlalchemy`. |
| 157 | done | Migration/model lock tests wave. | Добавлены locks на canonical panels activation route в SSOT/OpenAPI/frontend и на migration live-run readiness audit/doc presence. |
| 158 | done | Shop/admin alias removal wave 1. | Прямой аудит не подтвердил безопасного contract-preserving удаления `/shop/*` и `/admin/shop/*`; wave закрыта как explicit hard freeze без unsafe route deletion. |
| 159 | done | OpenAPI and release docs freeze. | Зафиксированы OpenAPI, SSOT route registries, route inventory и release docs после sync canonical panels route и alias-freeze boundary. |
| 160 | done | Post-alias series release audit. | Финальный audit серии 146–159 зафиксирован: alias cleanup, caller audits, canonical route sync, migration readiness, locks и release-doc freeze. |


## Предложение следующих циклов 161–170

| № | Статус | Цель | Описание |
|---|---|---|---|
| 161 | done | Historical docs stale-state audit. | Выделены historical docs, которые больше нельзя читать как active truth после cycles 129–160; составлен список на archival marking без переписывания исторических регистров. |
| 162 | done | Historical docs archival marking wave. | В ключевые stale-state docs добавлены явные archival markers, чтобы они не воспринимались как active truth для текущего HEAD. |
| 163 | done | Migration environment bootstrap audit. | Подтверждено, что repo already contains dependency declarations и Alembic inputs; добавлен helper script для локального bootstrap-пруфа, отделена archive-readiness от environment-readiness. |
| 164 | done | Live alembic proof wave. | Свежие CI-логи `logs_62803948808.zip` подтвердили успешный `python -m alembic -c backend/alembic.ini upgrade head` с exit=0; прежний local blocker был ограничением среды аудита, а не дефектом HEAD-архива. |
| 165 | done | Shop/admin contract decision audit. | По фактам принято текущее решение: `/shop/*` и `/admin/shop/*` сохраняются как frozen backend compatibility contracts до отдельной канонической contract-migration wave. |
| 166 | done | Shop/admin contract migration wave 1. | Так как cycle 165 подтвердил freeze, первая волна выполнена как freeze-implementation: добавлены docs/tests, запрещающие скрытую ломку `/shop/*` и `/admin/shop/*` до отдельной canonical contract-migration wave. |
| 167 | done | Panels compat sunset audit. | Прямой audit подтвердил: active frontend уже использует только `POST /panels/activate/{tg_id}`, но archive-only evidence не доказывает отсутствие внешних клиентов для `POST /panels/buy/{tg_id}`; safe removal не подтверждён. |
| 168 | done | Panels compat path migration/freeze. | Для текущей release-line зафиксировано: frontend использует только canonical `/panels/activate/{tg_id}`, а `/panels/buy/{tg_id}` сохраняется как frozen compatibility path до отдельной sunset wave с внешним proof. |
| 169 | done | Route/OpenAPI generation hardening. | Добавлен deterministic helper `ops/routes/regenerate_route_inventory_md.py`, который пересобирает `docs/audits/ROUTE_INVENTORY_FREEZE.md` из freeze CSV и снижает ручной drift в route-doc layer. |
| 170 | done | Full archive-vs-chat-vs-logs parity audit. | Финальный audit новой серии подтвердил: архив отражает cycles 146-169, свежих `logs_*.zip` в HEAD нет, live Alembic proof остаётся blocked, а все freeze/compat boundaries теперь задокументированы без голословных CI-заявлений. |


## Следующие циклы 171–175

| № | Статус | Цель | Описание |
|---|---|---|---|
| 171 | done | Frontend/backend/bot sync audit. | Проведён прямой audit active backend/frontend/bot layers: подтверждён drift в active locale keys Hub/wallet/settings и в live docstring admin referral service. |
| 172 | done | Frontend active locale sync wave. | Активные locale keys `hub.*`, `wallet.*` и `profile.confirm_purchase` синхронизированы с Hub/external-flow canon на всех 13 языках. |
| 173 | done | Backend/bot wording sync wave. | Backend admin referral wording переведён с panel purchase на panel activation; active bot wording дополнительно проверен и признан синхронным канону. |
| 174 | done | Active wording guards wave. | Добавлены tests, которые фиксируют новый active frontend wording layer и backend admin referral wording от регрессий. |
| 175 | done | Full code sync audit closeout. | Зафиксировано закрытие active wording drift в backend/frontend/bot слоях и границы того, что не утверждается в этой волне (live Alembic proof, frozen compatibility contracts). |


## Следующий цикл

| № | Статус | Цель | Описание |
|---|---|---|---|
| 176 | done | Log-driven stabilization wave after logs_62803948808. | Исправлены подтверждённые log-driven дефекты: синтаксис/ruff/flake8/compileall drift в `ops/routes/regenerate_route_inventory_md.py`, stale docs counts and tests catalog, missing historical compatibility files/docs и outdated architecture locks, которые расходились с текущим FAQ/route/archive canon. |


## Следующие циклы 177–200 — multilingual audit, sync and archive docs refresh

| № | Статус | Цель | Описание |
|---|---|---|---|
| 177 | done | 13-language audit of FAQ + active bot locale layer. | Проведён прямой audit всех 13 языков: FAQ везде структурно полон (20 sections / 250 items), а основной переводческий долг сосредоточен в `frontend/public/locale/*.json`. |
| 178 | done | Navigation translation sync wave. | Во всех non-RU/non-EN языках синхронизированы high-traffic `nav.*` labels по active bot sections: Admin, Ads, Dashboard, Energy, Exchange, Hub, Panels, Tournaments, Ranks, Referrals, Tasks. |
| 179 | done | FAQ + Hub shell translation sync wave. | Во всех non-RU/non-EN языках синхронизированы ключевые `faq.*` shell keys и high-traffic `hub.*` titles/descriptions/card titles. |
| 180 | done | Core section titles + common shell translation sync wave. | Во всех non-RU/non-EN языках синхронизированы `wallet/profile/panels/exchange/tasks/referrals/ranks/history` section titles и базовые `common.*` UI shell keys. |
| 181 | done | Profile wave 1. | В ручном постепенном режиме переведены high-traffic `profile.*` keys во всех non-RU/non-EN языках: section/menu/admin/FAQ/interface/language/notifications/privacy/support/theme/confirmations/sound. |
| 182 | done | Wallet wave 1. | В ручном постепенном режиме переведены high-traffic `wallet.*` shell/connect/empty/status keys во всех non-RU/non-EN языках. |
| 183 | done | Panels wave 1. | В ручном постепенном режиме переведены high-traffic `panels.*` titles/tabs/empty states/cta во всех non-RU/non-EN языках. |
| 184 | done | Exchange + Energy wave 1. | В ручном постепенном режиме переведены high-traffic `exchange.*` и `energy.*` public shell keys во всех non-RU/non-EN языках. |
| 185 | done | Tasks + Referrals wave 1. | В ручном постепенном режиме переведены high-traffic `tasks.*` и `referrals.*` keys во всех non-RU/non-EN языках. |
| 186 | done | History + Withdraw wave 1. | В ручном постепенном режиме переведены high-traffic `history.*` и `withdraw.*` shell/status keys во всех non-RU/non-EN языках. |
| 187 | done | Ranks wave 1. | В ручном постепенном режиме переведены high-traffic `ranks.*` keys; последующий audit подтвердил, что `prizes.*` были хвостом decommission-серии и подлежат удалению из active locale/domain. |
| 188 | done | Common + balances parity. | В ручном постепенном режиме переведены high-traffic `common.*` и `balances.*` shell keys во всех non-RU/non-EN языках. |
| 189 | done | Admin public labels audit. | Проведён прямой audit active admin labels; отдельно подтверждено отсутствие active public/admin prizes section и зафиксирован orphan placeholder tail для последующего удаления. |
| 190 | done | Prizes/tournaments tail removal wave. | Проведён полный audit архива по `prizes/tournaments`; удалены orphan admin page, active locale keys, profile reason key, backend admin `prize_claims` contour и актуальные docs/ssot traces этого хвоста. |
| 191 | done | Hub + FAQ wave 2 and pages inventory. | В ручном постепенном режиме синхронизированы high-traffic `hub.*` и `faq.*` shell keys во всех non-RU/non-EN языках, а также зафиксирован полный список текущих страниц бота. |
| 192 | done | Missing-key matrix. | Проведён cross-language audit remaining EN-equal keys; подтверждено, что крупнейший current debt теперь сосредоточен в `admin.*`, а `Hub/VIP/EFHC/FAQ/GetGems` отмечены как canonical exceptions. |
| 193 | done | Admin wave 1. | В ручном постепенном режиме синхронизированы high-traffic `admin.*` shell keys: back/bank/ads/logs/modules/overview/panels/referrals/reports/tasks/users/reason/transfer/set_creds. |
| 194 | done | Admin wave 2. | В ручном постепенном режиме синхронизированы high-traffic operational `admin.*` keys: admin-id/admin-token/auth-note/open-transfer/reconcile/modules-note/placeholders и related prompts. |
| 195 | done | Verification and tails cleanup. | Выполнен verification-pass по locale JSON и планам: prizes/tournaments хвост не вернулся, active debt переопределён под current `admin.*` long-tail, а старые плановые формулировки заменены фактическим состоянием HEAD. |
| 196 | done | Overview docs refresh. | Обзорные документы синхронизированы с current HEAD; позже пользователь уточнил жёсткий миграционный канон single-base `0001`, поэтому migration summary был дополнительно пересмотрен в cycle 197. |
| 197 | done | Migration reset to 0001 and parity refresh. | Удалён `0002_create_hub_links.py`, migration-layer возвращён к канону single-base `0001`, обновлены active docs/SSOT/tests под zero-extra-migrations состояние. |
| 198 | done | Route/model/docs refresh after migration reset. | Выполнены точечные правки existing canon docs: row 74 journal note, Hub migration wave doc и log-audit note выровнены под current canon `0001 only`, без раздувания набора новых документов. |
| 199 | done | Healer/reports normalization. | Нормализованы recent registry/report tails после cycles 190-198: выровнены stale migration notes под канон `0001 only`, а хвост `REPORTS_INDEX` приведён к единому формату ссылок без потери хронологии. |
| 200 | done | Full archive docs closeout. | Existing docs получили финальные archival markers там, где historical/audit files могли быть прочитаны как active truth; серия 177-200 закрыта без раздувания набора новых документов. |


## Следующий цикл

| № | Статус | Цель | Описание |
|---|---|---|---|
