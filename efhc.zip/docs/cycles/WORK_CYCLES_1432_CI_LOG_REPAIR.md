# Work cycle 1432 — CI log repair after security hardening

Status: DONE
HEAD before cycle: `EFHC_Bot_v170_06_cycle_1431_security_regression_hardening.zip`
HEAD after cycle: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`
Log source: `logs_72432961872.zip`

## Goal

Fix factual CI errors from the supplied logs without weakening tests, security
boundaries, economic invariants or AI Archive Laws.

## Fixed errors

- `ruff UP037` in `wallet_schemas.py`.
- `bandit B105` on a legacy cron digest constant name.
- SSOT table-count drift after adding `wallet_proof_token_uses`.
- stale Wave10 spend guard after nocommit spend refactor.
- stale panel activation guard after atomic nocommit panel activation.
- invalid Healer enum value `locally_treated` / maturity `guarded`.
- wallet proof replay test returning `WALLET_CONFLICT` before replay rejection.

## Files changed

Runtime:
- `backend/app/schemas/wallet_schemas.py`
- `backend/app/core/config_core.py`
- `backend/app/services/wallets_service.py`

Tests / guards:
- `tests/architecture/test_security_p0_repair_guards.py`
- `tests/architecture/test_economic_audit_guards.py`
- `tests/architecture/cycle_marker_cases/case_cycle_and_docs_canon.py`
- `ops/routes/check_panel_activation.py`

Docs / SSOT / Healer:
- active DB SSOT docs and migration diagnostic docs updated to 43 tables;
- `atlas.json`, `casebook.json`, Healer docs updated;
- test guard manifest and Q&A updated.

## Verification

Local targeted checks:
- AI Archive Laws integrity: passed.
- `compileall backend/app`: passed.
- targeted architecture/security/economic/healer pack: passed.

Not claimed:
- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready.
