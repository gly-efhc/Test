# Cycle 1535 — Referral Binding / UX Error Handling / Onboarding

HEAD input: `EFHC_Bot_v171_09_cycle_1534_fresh_ci_hygiene_log_repair.zip`.
Output target: `EFHC_Bot_v171_10_cycle_1535_referral_ux_fix.zip`.

Scope:

- close referral deeplink P0 from `a_v171_09.md`;
- close withdraw raw error toast P2;
- close exchange mutation wrong error copy P2;
- add first-run onboarding tour;
- update guards and docs without changing EFHC economics.

Local result:

- `/start ref_<code>` now calls referral attach after `ensure_user`;
- `POST /referrals/bind` binds current authenticated global_id only;
- WebApp reads `Telegram.WebApp.initDataUnsafe.start_param`;
- withdraw toasts use public-safe messages;
- exchange mutation uses `exchange.exchange_failed`;
- onboarding is implemented as UI-only skippable tour.

Claims not made:

- GitHub CI green for output archive;
- full pytest green;
- frontend build green;
- live Telegram proof;
- real TonConnect proof;
- release-ready or production-ready.
