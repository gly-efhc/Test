# Work Cycle 1422 — P0 economic risk repair

Status: DONE.
HEAD input: `EFHC_Bot_v169_96_cycle_1421_ci_log_repair.zip`.
HEAD output: `EFHC_Bot_v169_97_cycle_1422_economic_risk_repair.zip`.

## Goal

Repair the first surgical findings from the P0 economic audit:

- `FIND-002` — all-bonus spend idempotency read-through;
- `FIND-004` — admin manual debit `TypeError` from nonexistent kwargs.

## Source documents read

- `KERNEL.md`
- `ops/operator_kernel/cache/file_map.json`
- `ops/operator_kernel/config/routes.yaml`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md`
- `docs/AI/AI_ARCHIVE_LAWS.md`
- `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- active `1401-1500` and `1404-1420` cycle docs
- active backend P0 docs
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/NORM/API_CONTRACTS.md`
- `docs/NORM/ARCHIVE_FILENAME_HYGIENE_POLICY.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `map_element.md`
- `docs/NORM/CHATS/25.md`
- supplied P0 economic audit MD/JSON

## Kernel preload

Kernel preload was performed before repair:

- `routes.yaml.version = 1`
- `file_map.json` was present and readable
- refresh was run after adding new files so navigation cache includes the new
  cycle, backend and test documents

## Sandbox use

`map_element.md` and sandbox archive metadata were read as reference/navigation
context only.

Песочница использована только как reference/navigation layer. Runtime-код не
переносился.

No Vue/Solid/Nuxt/Vanilla runtime, CI files, lock files, wallet/payment donor
logic, donor economics or translations were imported.

## Runtime changes

### `backend/app/services/transactions_service.py`

Changed `spend_user_to_bank_bonus_then_main`:

- added `_find_existing_spend_log()` local helper;
- added `_spend_read_through()` local helper;
- preflight idempotency now checks both `:main` and `:bonus` derived keys;
- conflict handling now also checks both keys;
- all-bonus retry no longer depends on a non-existing `:main` log.

### `backend/app/services/admin/admin_bank_service.py`

Changed `BankService.manual_bank_user_transfer`:

- removed nonexistent `spend_bonus_first` kwarg;
- removed nonexistent `forbid_user_negative` kwarg;
- kept admin debit routed through canonical `transactions_service.py` debit
  functions.

## Tests / guards

Added active guard file:

`tests/architecture/test_economic_risk_guards.py`

It contains:

- `test_spend_all_bonus_idempotency_retry_no_double_debit`
- `test_admin_manual_debit_no_typeerror`


### Guard/document hygiene alignment

The stale HEAL-0018 guard no longer requires a numbered work-pass label inside
`docs/backend/`. It now checks the numbered historical evidence in
`docs/cycles/WORK_CYCLES.md` and keeps backend repair docs clean under the
filename/content hygiene policy.

## What was not changed

- No AI Archive Laws changes.
- No CI/workflow changes.
- No frontend runtime changes.
- No Telegram/TonConnect/wallet logic changes.
- No EFHC economics changes.
- No direct SQL balance writes outside `transactions_service.py`.
- No test deletion, archival, skip, xfail or hiding.

## Checks performed

Targeted local checks passed:

- Python compile for changed code and new guard.
- `python3 scripts/ci/check_ai_archive_laws_integrity.py`
- `PYTHONPATH=backend python3 -m pytest -q tests/architecture/test_economic_risk_guards.py`
- targeted architecture guard pack for filename hygiene, law integrity, FSM,
  raw create task, chat intake and economic source guards.

## Not checked / non-claims

Not claimed:

- GitHub CI green;
- full pytest green;
- full npm build green;
- release-ready;
- browser screenshots;
- live Telegram client proof;
- real TonConnect / wallet proof.

## Remaining findings

Still open for later cycles:

- `FIND-001` — P0 panel activation atomicity: cycle 1423.
- `FIND-003` — P1 withdraw refund split commit: cycle 1424.
- `FIND-005` — P1 exchange TOCTOU: cycle 1424.
- `FIND-006..010` — P2/P3 cleanup: cycle 1425.

## Next cycle

Next safe cycle: `1423 — panel activation atomicity`, only after confirming the
architecture choice for `FIND-001`.

Recommended answer for `FIND-001`: option `A` — add a nocommit spend variant
and let `panels_service.py` own the atomic transaction boundary.

## Follow-up status after cycle 1423

The recommended option `A` for `FIND-001` was confirmed by the user and applied
in the next cycle. Panel activation atomicity is now guarded in
`tests/architecture/test_economic_risk_guards.py`.
