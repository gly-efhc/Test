# WORK CYCLE 1588 — EXACT-HEAD RELEASE EVIDENCE GATE REPAIR

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED.
Version: `v171.85`.

## Objective

Prevent historical CI evidence from closing a current development/release gate.

## Root cause

`ops/release/local_pre_release_gate.py` used fixed v171.67 CI and v171.69 repair
files. Any later archive could therefore inherit a false 99-percent completion
claim without an exact matching GitHub run.

## Repair

- derive current version from `release_config/UPDATE_POLICY.json`;
- derive the exact development archive name from that version;
- accept only green CI intake with matching `source_head`;
- expose older records as historical and rejected;
- return `LOCAL_RELEASE_CANDIDATE` while exact-head CI is absent;
- preserve all external non-claims and `production_release_ready=false`;
- remove the unconditional `99_PERCENT_COMPLETE` claim from generated release metadata and record `LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.

## Patch boundary

Changed only release evidence control, regression guards, version metadata,
control documents and Healer/causal records. No product runtime behavior,
economy, database schema, UI or wallet logic changed.
