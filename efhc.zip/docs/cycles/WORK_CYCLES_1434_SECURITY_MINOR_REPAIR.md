# Cycle 1434 — Security minor findings repair

Archive: `EFHC_Bot_v170_09_cycle_1434_security_minor_repair.zip`
Base archive: `EFHC_Bot_v170_08_cycle_1433_operator_kernel_first_standard_hardening.zip`
Mode: `SECURITY REPAIR / TARGETED / AUDIT-DRIVEN`
Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_08.md`

## Goal

Close the remaining non-P0 findings from the v170.08 security audit without
changing EFHC economy, wallet proof canon or unrelated runtime behavior.

## Closed findings

### FIND-02 — P1 — ADS_TEST_MODE prod/stage fail-fast

`ADS_TEST_MODE` is now an explicit settings field. Production/stage startup
must fail if it is true. `env.prod.example` records `ADS_TEST_MODE=false`.

### FIND-04 — P1 — monetary rate-limit prefixes

`/deposit` and `/payment-intents` are now included in the default prefixes for
both monetary idempotency and monetary rate-limit middleware paths in
`backend/app/core/system_locks.py`.

### FIND-05 — P2 — env.prod.example operational addresses

Real-looking TON operational addresses in `env.prod.example` were replaced with
placeholders. This is OPSEC housekeeping and not an economy change.

## Files changed

Runtime/config:

- `backend/app/core/config_core.py`
- `backend/app/core/system_locks.py`
- `env.prod.example`

Tests/guards:

- `tests/architecture/test_security_audit_v170_08_minor_repair.py`
- `tests/architecture/test_monetary_rate_limit_enabled.py`

Docs/indexes:

- `docs/audits/P0_SECURITY_AUDIT_V170_08.md`
- `docs/audits/p0_security_audit_v170_08.json`
- `docs/security/P0_SECURITY_REPAIR_CANON.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `reports/REPORTS_INDEX.md`
- `map_element.md`

## Guard requirements

- `test_ads_test_mode_forbidden_in_prod`
- `test_monetary_rate_limit_covers_deposit_and_payment_intents`
- `test_env_prod_example_uses_placeholders_for_ton_addresses`

## Verification

Local targeted verification was executed for the new security minor repair
architecture guards, monetary rate-limit guard, AI Archive Laws integrity,
compileall and ZIP integrity.

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, frontend build
green, browser screenshots, live Telegram proof or real TonConnect proof.

## Sandbox use

Песочница was used only as a reference/navigation layer through `map_element.md`.
No sandbox runtime code, CI files, lock files, wallet/payment logic, configs,
secrets, economy or translations were imported.
