# Cycle 1524 — Fresh CI Rerun / Withdrawals Runtime Test Isolation Repair

Input archive: `EFHC_Bot_v170_99_cycle_1523_p0_admin_withdrawals_list_regression_fix.zip`

Output archive: `EFHC_Bot_v171_00_cycle_1524_fresh_ci_withdrawals_test_isolation_repair.zip`

Input log: `logs_74379950976.zip`

## Log verdict

The uploaded CI log for `v170.99` was red.

Passed in the log:

```text
ruff
mypy
bandit
compileall
Alembic upgrade head
npm ci
npm build
```

Failed in the log:

```text
pytest: 2 failed, 1938 passed, 8 skipped, 2 warnings
```

## Root cause

The new cycle 1523 DB-backed runtime test helper inserted absent legacy wallet values as an empty string:

```text
users.ton_wallet = ''
```

The real schema has:

```text
uq_users_ton_wallet
```

Therefore tests that inserted two users without a wallet failed in Postgres with a duplicate empty-string wallet value.

## Fix

Changed the test helpers to insert:

```text
users.ton_wallet = NULL
```

This preserves the wallet canon and does not change runtime money logic.

## Scope

Runtime/service code was not changed in this cycle. The P0 fix from cycle 1523 remains intact. This cycle repairs the test isolation defect exposed by fresh CI.

## Validation

Local targeted checks:

```text
pytest tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py tests/efhc_backend/admin/test_admin_withdrawals_routes_runtime.py tests/architecture/test_bonus_awards_legacy_guard_scope.py tests/architecture/test_withdraw_bonus_awards_regression_guard.py -q
# result: 8 passed, 7 skipped

pytest tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py -q
# result: 3 passed

pytest tests/architecture/test_archive_filename_hygiene.py tests/architecture/test_max_line_length_72.py tests/architecture/test_fresh_ci_rerun_log_repair.py tests/architecture/test_live_release_readiness_gate.py -q
# result: 19 passed
```

Full GitHub CI green for output archive is not claimed without a fresh rerun.

## Release status

```text
RELEASE_GATE: FAIL_CLOSED
PRODUCTION_READY: NOT_CLAIMED
RELEASE_READY: NOT_CLAIMED
LIVE_TELEGRAM: NOT_VERIFIED
REAL_TONCONNECT: NOT_VERIFIED
```
