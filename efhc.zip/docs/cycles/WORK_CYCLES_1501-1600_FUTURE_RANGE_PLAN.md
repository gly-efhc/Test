# Current range update — v171.73 / cycle 1578

EFHC now supports sequential production updates from complete release archives. The updater verifies both checksum layers, safely stages the target version, executes its own deployment and switches the active symlink only after healthchecks. Compatible application rollback is preserved without implicit database restoration.

Next permitted changed archive after v171.73: `EFHC_Bot_v171_74.zip`.

Historical entries below preserve prior states and do not override the current v171.73 section.

---

# Current range update — v171.70 / cycle 1578

The clean-first-boot release candidate is locally complete. Runtime migrations are document-independent; an empty PostgreSQL instance is prepared through Alembic, exact 44-table validation and idempotent initial data. Docker Compose now orders `db → migrate → backend + scheduler → frontend → proxy`, with one canonical deploy command.

The remaining acceptance boundary requires a Docker-enabled Ubuntu 24.04 VPS: no-cache image build, empty-volume first deploy, repeated deploy, healthchecks, live Telegram/TON and cross-provider restore. None of those external results is claimed locally.

Next permitted changed archive after v171.70: `EFHC_Bot_v171_71.zip`.

Historical entries below preserve prior states and do not override the current v171.70 section.

---

# Current range update — v171.68 / cycle 1578

All locally executable work for cycles 1574–1578 is complete. The provider-independent release candidate includes production Dockerfiles, universal Docker Compose, standard PostgreSQL migrations and recovery, Caddy HTTPS, domain/webhook migration, off-site backup support, a local 99-percent gate and a separate minimal production archive.

The remaining route is live technical deployment and verification. No live VPS, DNS/HTTPS, Telegram client, TonProof, transaction settlement or second-provider restore is claimed.

Next permitted changed archive after v171.68: `EFHC_Bot_v171_69.zip`.

Historical entries below preserve prior states and do not override the current v171.68 section.

---

# Current range update — v171.67 / cycle 1574

The exact failures from `logs_81507543006.zip` were repaired locally. The 58 previously failing pytest nodes pass, the strict 72-character guard has zero violations, the missing Profile settings SVG constants are restored and the three Ruff source defects are corrected.

Cycle 1574 remains active. Fresh exact-HEAD GitHub CI is still required for the authoritative Ruff, PostgreSQL-backed pytest and production Next.js build verdicts. External Telegram/TON proof remains deferred and unverified.

Next permitted archive after v171.67: `EFHC_Bot_v171_68.zip`.

Historical entries below preserve prior states and do not override the current v171.67 section.

---

# Current range update — v171.66 / cycle 1574

The WalletProvider/native-adapter architecture slice of cycle 1574 is locally implemented. TonConnect is now one adapter behind an EFHC-owned contract; Wallet in Telegram and Native Gram Wallet have separate fail-closed adapter boundaries.

Cycle 1574 remains active for remaining local release-candidate audit work. Deferred live Telegram/TonConnect/TonProof/transaction proof remains unverified and cannot be converted into a release-ready claim.

Next permitted archive after v171.66: `EFHC_Bot_v171_67.zip`.

Historical entries below preserve prior states and do not override the current v171.66 section.

---

# Current range update — v171.65 / cycle 1574

Cycle 1573 local scope is complete. Its live Telegram, TonConnect, TonProof and real transaction checks are explicitly `DEFERRED_POST_RELEASE_BY_USER` and remain unverified.

Cycle 1574 is now active for the bounded local release-candidate audit. The audit may continue all locally executable checks and repairs, but it must not convert deferred evidence into a verified or release-ready claim.

Next permitted archive after v171.65: `EFHC_Bot_v171_66.zip`.

Historical entries below preserve prior states and do not override the current v171.65 section.

---

# Current range update — v171.59 / cycle 1573

Cycle 1573 remains active. v171.59 is a corrective development snapshot with fresh browser-captured component/page proof and restored access to the full settings modal.

The release sequence remains unchanged:

- close live Telegram;
- close real TonConnect;
- close real TonProof;
- close real transaction contour;
- only then start cycle 1574 final release-candidate audit.

Next permitted archive after v171.59: `EFHC_Bot_v171_60.zip`.
---

# Current range update — v171.57 / cycle 1573

Cycle 1573 remains active. v171.57 adds a fail-closed live contour evidence gate and records the current blocker: missing factual proof for live Telegram, real TonConnect, real TonProof and real transaction contours.

No cycle 1574 work may start until all four live contours are verified. The next permitted archive after v171.57 is `EFHC_Bot_v171_58.zip`.
---

# Current authoritative range state — v171.56 / cycle 1573 active

- Completed cycles: `72 / 100`.
- Cycle `1572` is complete by green user-run logs.
- Cycle `1573` remains active.
- UI refinement is complete for the current requested header/profile slice, but live proof remains open.
- No cycle advancement is permitted without live Telegram, real TonConnect, real TonProof and real transaction evidence.
- Cycle `1574` has not started.
- Next archive after `v171.56`: `v171.57`.
---

# Authoritative release route after cycle 1562

Current output target: `EFHC_Bot_v171_44.zip`.

| Cycle | Required scenario result | State |
|---:|---|---|
| 1560 | HUB and Direct Deposit | CORRECTED IN 1561 |
| 1561 | Funding repair, Withdraw and Energy proof | DONE LOCALLY; OPERATOR VISUAL OPEN |
| 1562 | Browser Shop checkout and account linking | DONE LOCALLY |
| 1563 | TonConnect restore, TonProof and transaction UX | DONE LOCALLY |
| 1564 | Full Admin Panel MVP | DONE LOCALLY |
| 1565 | Complete UI-to-DB linkage and DTO parity | DONE LOCALLY |
| 1566 | PostgreSQL atomicity, concurrency and restore | DONE LOCALLY |
| 1567 | Security, privacy, legal and abuse hardening | DONE LOCALLY |
| 1568 | Observability, deployment and rollback | DONE LOCALLY |
| 1569 | PWA, Telegram WebView, devices and WCAG | DONE LOCALLY |
| 1570 | Public/admin visual and recovery matrix | done locally |
| 1571 | Full regression and workflow normalization | planned |
| 1572 | Fresh GitHub CI repair until green | planned |
| 1573 | Live Telegram and real transaction proof | planned |
| 1574 | Final 99-percent release-candidate audit | planned |

Current range status after cycle 1568: `68 / 100` done and `32 / 100`
remaining.

---

# Authoritative release route after cycle 1556

The live user instruction makes the release-readiness checklist the
canonical route for the remaining range.

Human plan:
`docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`

Machine plan:
`reports/generated/mvp_release_readiness_master_plan_v171_44.json`

The target is a fail-closed score of at least `99 / 100`, with every
critical checkpoint verified, no open P0 or MVP-blocking P1, fresh green
GitHub CI for the exact release head, live Telegram proof and a real
TonConnect transaction.

| Cycle | Required scenario result | State |
|---:|---|---|
| 1554 | Critical path, typed Energy and canonical shell | DONE |
| 1555 | Shell runtime, 13 languages and public browser proof | DONE |
| 1556 | Panels, Exchange and release-readiness master plan | DONE LOCALLY |
| 1557 | Tasks and Ads-alias complete action flow | DONE LOCALLY |
| 1558 | Referrals deep-link/bind/share and Ranks runtime | DONE LOCALLY |
| 1559 | Profile, Wallet, History, FAQ and language quality | DONE LOCALLY |
| 1560 | HUB and Direct Deposit reconciliation | DONE LOCALLY |
| 1561 | Withdraw user and operator contour | planned |
| 1562 | Browser-Shop TON-only checkout and Telegram linking | planned |
| 1563 | TonConnect manifest, restore, TonProof and transaction UX | planned |
| 1564 | Admin Panel MVP across protected sections | planned |
| 1565 | Full UI-to-DB linkage and OpenAPI/DTO parity | DONE LOCALLY |
| 1566 | PostgreSQL, atomicity, concurrency and backup/restore | DONE LOCALLY |
| 1567 | Security, privacy, legal and abuse hardening | DONE LOCALLY |
| 1568 | Observability, deployment and rollback readiness | DONE LOCALLY |
| 1569 | PWA, Telegram WebView, devices, accessibility, performance | DONE LOCALLY |
| 1570 | Public/admin interaction, visual, load and recovery matrix | done locally |
| 1571 | Full regression and GitHub workflow normalization | planned |
| 1572 | Fresh GitHub CI intake and repair until green | planned |
| 1573 | Live Telegram and real TonConnect/payment proof | planned |
| 1574 | Final 99% release-candidate audit and evidence package | planned |

The route is scenario-driven. Closely related work may be completed in
one cycle when required for a complete user path. Documentation and guards
are evidence, not substitutes for working product behavior.

Current range status after cycle 1560: `60 / 100` done and `40 / 100`
remaining.

---

# Cycle 1553 — DONE

Fresh CI archive and skills log repair completed locally.
Next safe cycle: `1554 — Fresh CI rerun / archive-skills confirmation`.

Status counters after this cycle: done `53 / 100`, left `47 / 100`.

---

## Tail note from cycle 1552

Cycle 1552 produced `v171_27` as a short-named archive purity and naming repair.
The output ZIP is `EFHC_Bot_v171_27.zip`; descriptive cycle/title text belongs inside the
archive documentation and reports.

Range status after 1552: `52 / 100` done, `48 / 100` remaining.

Next safe cycle: `1553 — Fresh CI Rerun / Archive Purity Confirmation`.

---

## Tail note from cycle 1551

Cycle 1551 produced `v171.26` as a local Agent Skills Adapter foundation-fix
archive. It fixed invalid TOML in ship commands, EFHC startup hook test drift,
broken persona links, adapter scanner coverage, public API scanner coverage for
EventSource/WebSocket, hooks fallback path and EFHC plugin metadata.

Range status after 1551: `51 / 100` done, `49 / 100` remaining.

Next safe cycle: `1552 — Fresh CI Rerun / Agent Skills Adapter Fix Follow-up`.

---

## Tail note from cycle 1550

Cycle 1550 produced `v171.25` as a local Agent Skills Adapter foundation
archive. It added EFHC-adapted root entrypoints, skills, commands, personas,
references, optional hooks, adapter docs, scanner and architecture guard. It did
not change runtime economy, wallet, TonConnect, idempotency, withdraw, DB or
money-flow logic.

Range status after 1550: `50 / 100` done, `50 / 100` remaining.

Next safe cycle: `1551 — Fresh CI Rerun / Agent Skills Adapter Follow-up`.

---

## Tail note from cycle 1549

Cycle 1549 produced `v171.24` as a local fresh-CI log repair archive after
`logs_74815399993.zip`. It repaired stale architecture guards caused by the
service/API migration gate: old tests still expected route constants and direct
API markers inside public UI pages instead of service/query seams. It also
renamed new query-seam aliases to canonical `global_id` spelling. Runtime economy,
wallet, TonConnect, idempotency and withdraw logic were not changed.

Range status after 1549: `49 / 100` done, `51 / 100` remaining.

Next safe cycle: `1550 — Fresh CI Rerun / Service API Gate Confirmation`.

---

## Tail note from cycle 1548

Cycle 1548 produced `v171.23` as a local audit/TZ repair archive for
`tz_v171_20.md`. It implemented a strict public UI direct API migration gate,
added scanner/policy/pytest protection, introduced service/query seams for the
P0 public flows and kept the public copy firewall active. No economy, rates,
balances, wallet, TonConnect, money-flow or withdraw business logic changed.

Range status after 1548: `48 / 100` done, `52 / 100` remaining.

Next safe cycle: `1549 — Fresh CI Rerun / Service API Gate Follow-up`.

---

## Tail note from cycle 1547

Cycle 1547 produced `v171.22` as a local fresh-CI log repair archive after
`logs_74688208405.zip`. It repaired `ruff` style drift and pytest guard/copy
drift around the public-copy firewall, FAQ generated catalog and locale
manual translations. Runtime economy, wallet, TonConnect, idempotency and
withdraw logic were not changed.

Range status after 1547: `47 / 100` done, `53 / 100` remaining.

Next safe cycle: `1548 — Fresh CI Rerun / Visual Proof Runtime Follow-up`.

---

## Tail note from cycle 1546

Cycle 1546 produced `v171.21` as a local audit/TZ repair archive for
visual proof splash timing. The public/admin proof scripts now enforce
minimum `2500ms` settle timing and require `splash_visible:false`. Product UI
and money-flow were not changed. Runtime visual proof was not claimed because
sandbox did not provide a valid running frontend proof pass.

Range status after 1546: `46 / 100` done, `54 / 100` remaining.

Next safe cycle: `1547 — Fresh CI Rerun / Visual Proof Runtime Follow-up`.

---

## Tail note from cycle 1545

Cycle 1545 produced `v171.20` as a local audit/TZ repair archive for
`tz_v171_17_copy_guard.md`. It added a public-copy policy, scanner, pytest
guard, command linkage and documentation. The scanner passed after public
locale/source copy cleanup. DOM/browser visual proof was not performed in
sandbox, so release-ready and visual-ready are not claimed.

Range status after 1545: `45 / 100` done, `55 / 100` remaining.

Next safe cycle: `1546 — Fresh CI Rerun / Public Copy Proof Follow-up`.

---

## Tail note from cycle 1544

Cycle 1544 produced `v171.19` as a local repair archive for fresh
CI log `logs_74672087378.zip`. It closed the exact logged failures from ruff, mypy and
pytest without changing money-flow or economic logic. The main semantic
state after the repair: memo canon remains closed from cycle 1543, i18n
active locale count is now `1465`, and the output still requires fresh CI
rerun plus live Telegram / real TonConnect proof before release claims.

Range status after 1544: `44 / 100` done, `56 / 100` remaining.

Next safe cycle: `1545 — Fresh CI Rerun Confirmation / Live Proof Follow-up`.

---

## Tail note from cycle 1543

Cycle 1543 produced `v171.18` as a local audit/TZ repair archive for
`a_v171_17.md` and `tz_v171_17.md`. It closed the active P0 memo drift by
using `ton_memo.py` as the memo SSOT and making the watcher parse the same
canonical direct deposit memo that `/deposit/direct-open` issues. It also
closed panels activation error copy, webhook defensive commit/rollback, admin
raw error tails and raw-error guard coverage. No economy, rates, balances,
wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1544 — Fresh CI Rerun Confirmation / Live Proof Follow-up`.
Range status after 1543: `43 / 100` done, `57 / 100` remaining.

---

## Tail note from cycle 1542

Cycle 1542 produced `v171.17` as a local fresh-CI rerun guard repair archive
for `logs_74653569841.zip`. The uploaded log was red only on one stale pytest
architecture guard after flake8, ruff, mypy backend/app, bandit, compileall,
Alembic, npm ci and frontend build had passed. No economy, rates, balances,
wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1543 — Fresh CI Rerun Confirmation / Visual Proof Follow-up`.
Range status after 1542: `42 / 100` done, `58 / 100` remaining.

---

## Tail note from cycle 1541

Cycle 1541 produced `v171.16` as a local red-log repair archive for
`logs_74645134614.zip`. The uploaded log was red on `ruff` and `pytest`;
local repairs addressed the exact import-order, stale-guard, i18n, PWA,
line-length and documentation-hygiene failures. No economy, rates, balances,
wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1542 — Fresh CI Rerun Confirmation / Visual Proof Follow-up`.
Range status after 1541: `41 / 100` done, `59 / 100` remaining.

---

## Tail note from cycle 1540

Cycle 1540 produced `v171.15` as a local frontend error-noise cleanup archive using uploaded audit/TZ `v171_12`. All ten P0/P1/P2/P3 findings were repaired locally with code, i18n, route/offline fallback and architecture guards. Chat 36 was added to the canonical chat section. No economy, rates, balances, wallet, TonConnect, money-flow or withdraw business logic changed.

Next safe cycle: `1541 — Fresh CI Frontend Noise Cleanup Confirmation / Visual Proof Follow-up`.
Range status after 1540: `40 / 100` done, `60 / 100` remaining.

---

## Tail note from cycle 1539

Cycle 1539 produced `v171.14` as a local fail-closed proof-gate archive.
No fresh CI log, audit or TZ was provided, so no red-log repair or live-proof
confirmation was possible. The cycle added a guard that prevents false
GitHub-CI/live Telegram/WebApp/TonConnect/release-ready claims and refreshed
the current Kernel/map/reports/manifest/operator-kernel surfaces.

Next safe cycle: `1540 — Fresh CI Evidence Intake / Live Proof Follow-up`.
Range status after 1539: `39 / 100` done, `61 / 100` remaining.

---

# Cycle 1538 completed — Fresh CI Artifact Hygiene Log Repair

Status: `38 / 100` done, `62 / 100` remaining.
Next: `1539 — Fresh CI Green Confirmation / Live Referral Proof Gate`.

---

# Cycle 1537 completed — Referral Persistence Webhook Repair

Status: `37 / 100` done, `63 / 100` remaining.
Next: `1538 — Fresh CI Rerun / Referral Persistence Confirmation`.

---

# Range status after v171.11

- Done: `36 / 100`.
- Remaining: `64 / 100`.
- Next safe cycle: `1537 — Fresh CI Rerun Confirmation / Referral Live Proof Gate`.
- Release gate remains fail-closed until live Telegram and real TonConnect
  proof are provided.

---

# Current range status after cycle 1535

- Done: `35 / 100`.
- Remaining: `65 / 100`.
- Latest output target: `v171_10`.
- Next safe cycle: `1536 — Fresh CI Rerun / Referral Live Proof Gate`.

---

# Current plan update — after cycle 1534

- Current HEAD: `v171.09`.
- Done: `34 / 100`.
- Remaining: `66 / 100`.
- Next safe cycle: `1535 — Fresh CI Rerun Confirmation / Mypy Scope Follow-up`.
- Cycle 1534 repaired fresh CI red-log hygiene drift only.

---

# Current range status update — after cycle 1533

- Current HEAD: `v171.08`.
- Last cycle: `1533 — Scheduler Notify Fix / Admin Facade Cleanup`.
- Done: `33 / 100`.
- Remaining: `67 / 100`.
- Next safe cycle: `1534 — Fresh CI Rerun / Mypy Scheduler-Facade Confirmation`.

Cycle 1533 closed scheduler notify/facade signature drift from the
v171.07 audit while keeping release gate fail-closed.

---

# Current range status update — after cycle 1532

- Current HEAD: `v171.07`.
- Last cycle: `1532 — Fresh CI Rerun / Mypy Scope Follow-up`.
- Done: `32 / 100`.
- Remaining: `68 / 100`.
- Fresh CI log `logs_74475316189.zip` was red and repaired locally.
- Next safe cycle: `1533 — Fresh CI Rerun Confirmation / Live Proof Gate`.

---

# Current range status update — after cycle 1531

- Current HEAD: `v171.06`.
- Last cycle: `1531 — Global Signature Drift Fix`.
- Done: `31 / 100`.
- Remaining: `69 / 100`.
- Next safe cycle: `1532 — Fresh CI Rerun / Mypy Scope Follow-up`.

---

# Current range status update — after cycle 1530

- Current HEAD: `v171.05`.
- Last cycle: `1530 — Fresh CI Rerun Confirmation`.
- Done: `30 / 100`.
- Remaining: `70 / 100`.
- Green GitHub CI evidence is confirmed for input HEAD `v171.04` from
  `logs_74465909794.zip`.
- Output archive `v171.05` is not itself CI-green until a fresh rerun is
  provided for `v171.05`.
- Next safe cycle: `1531 — Live Telegram / Real TonConnect Evidence Intake`.

---

## 1529 — Fresh CI Evidence Intake / Red-log Repair — DONE locally

- Current canonical output lineage: `v171_04`.
- Red log `logs_74445426759.zip` parsed.
- Non-pytest CI gates passed in the uploaded log: ruff, mypy, bandit,
  compileall, Alembic, npm ci and frontend build.
- Pytest failed on stale Kernel-anchor guards after cycle 1528 compaction:
  `24 failed, 1933 passed, 8 skipped, 2 warnings`.
- Compact Kernel compatibility anchors restored.
- Runtime, money-flow, wallet flow, TonConnect behavior, frontend runtime
  and EFHC economy were not changed.
- Output CI green and release-ready are not claimed.

Range status after 1529: `29 / 100` done, `71 / 100` remaining.

Next safe work item: `1530 — Fresh CI Rerun Confirmation / Remaining Guard
Drift Intake`.

## 1528 — Kernel / map_element compaction / test consolidation — DONE locally fail-closed

- Current canonical output lineage: `v171_03`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- Kernel/map_element current navigation was compacted without removing
  historical guard anchors.
- Only chat-docs intake tests were consolidated.
- No high-risk money, idempotency, global_id, wallet, withdraw runtime or security
  guards were merged.
- Runtime, money-flow, wallet flow, TonConnect behavior and EFHC economy were
  not changed.

Range status after 1528: `28 / 100` done, `72 / 100` remaining.

Next safe work item: `1529 — Fresh CI Evidence Intake / Red-log Repair`.

## 1527 — Fresh CI evidence intake / chat docs / test consolidation — DONE locally fail-closed

- Current canonical output lineage: `v171_02`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- Added `docs/NORM/CHATS/34.md` and `docs/NORM/CHATS/35.md`.
- Added proposal-only test guard consolidation candidates.
- No tests were merged, deleted, skipped or xfailed.
- Runtime, money-flow, wallet flow, TonConnect behavior and EFHC economy were
  not changed.

Range status after 1527: `27 / 100` done, `73 / 100` remaining.

Next safe work item: `1528 — Kernel / map_element Compaction Pass`.

## 1526 — Fresh CI / Live Proof Gate Refresh — DONE locally fail-closed

- Current canonical output lineage: `v171_01`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- Current release gate report generated for input `v171.00` and output
  `v171.01`.
- Live Telegram and real TonConnect proof remain blocked without external
  environment evidence.
- P0 withdrawals and wallet NULL fixture guards remain active.
- Runtime, money-flow, withdraw logic, wallet logic, TonConnect behavior and
  EFHC economy were not changed.

Range status after 1526: `26 / 100` done, `74 / 100` remaining.

Next safe work item: `1528 — Kernel / map_element Compaction Pass`.

## 1523 — P0 Admin Withdrawals List Regression Fix — DONE locally

- P0 withdrawals list regression fixed locally.
- `list_withdrawals()` no longer depends on legacy `bonus_awards`.
- Runtime route/service tests and AST guard-scope tests added.
- Release gate remains fail-closed until fresh CI/live proof.

## Tail note from cycle 1522

Cycle 1522 repaired the red fresh CI rerun log `logs_74335271498.zip`
locally. The input log proved green non-pytest gates and a red pytest gate.
The repair closed line72 and stale panels route-evidence drift after generated
seam migration.

Range status after 1522: `22 / 100` done, `78 / 100` remaining.

Next safe work item: `1523 — Fresh CI rerun / external proof evidence intake`.

## Tail note from cycle 1521

Cycle 1521 added a fail-closed external proof gate for live Telegram, real
TonConnect, fresh CI and release readiness. The gate records local proof but
keeps release readiness blocked until external evidence is provided.

Range status after 1521: `21 / 100` done, `79 / 100` remaining.

Next safe work item: `1522 — Fresh CI rerun / external proof evidence intake`.

## Tail note from cycle 1519

Cycle 1519 repaired the red fresh CI log `logs_74249190312.zip` locally.
The output archive still needs a fresh CI rerun before any green CI or
release-safe claim.

Range status after 1519: `19 / 100` done, `81 / 100` remaining.

## Tail note from cycle 1517

Cycle 1517 closed the static Frontend Buttons / API / i18n drift audit tail locally:

- admin features/components are covered by the adminSeams rule;
- raw admin `apiRequest('/admin...')` is forbidden outside generated seams;
- stale guards expecting legacy raw route strings were updated to the new seam canon;
- Node i18n audit scripts run successfully with `__dirname`;
- `npm audit --audit-level=high` is clean after `frontend/package-lock.json` update.

Next safe cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.
Range status after 1517: `17 / 100` done, `83 / 100` remaining.

# WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md

**Project:** EFHC Bot  
**Range:** 1501–1600  
**Status:** ACTIVE RANGE PLAN / BACKLOG FOUNDATION  
**Created in:** cycle 1497 / v170.73  
**Mode:** post-dashboard hardening, evidence, release preparation, controlled backlog

## 0. Purpose

This document opens the next future planning range after dashboard direction
`1455–1496` was closed and audit-follow-up cycle `1497` accepted the verdict
`DIRECTION_COMPLETE_WITH_KNOWN_GAPS`.

The range `1501–1600` must not reopen the completed dashboard direction as an
unbounded visual rewrite. It is a controlled backlog/hardening/release range.

## 1. Active backlog anchors

| Anchor | Priority | Description |
|---|---:|---|
| `ui_kit_component_gap` | P2 | Reusable UI Kit wrappers were consolidated in 1497; future work may migrate inline usages to wrappers gradually. |
| `admin_domain_report_endpoints_backlog` | closed in 1503 | Five read-only admin domain report endpoints added and guarded. |
| `VIS-03` | closed in 1499 | Public withdraw history semantic balance label repair completed. |
| `browser_screenshot_proof` | P2 | Produce actual browser screenshots when environment allows capture. |
| `github_ci_rerun_proof` | P1 | Red rerun from `logs_73728142603.zip` repaired locally in 1505; fresh green rerun still required before any release-safe statement. |
| `release_audit` | P1 | Separate release audit before release-ready claim. |

## 2. First priority cycles

## 1525 — Archive Numbering Rollover Repair — DONE locally

- Canonical rollover repair after the version boundary at `v170_99`.
- Correct output lineage: `v171_00`.
- Added guard against future three-digit minor suffixes.
- Runtime, money-flow, withdraw logic, TonConnect behavior and EFHC
  economy were not changed.
- Release-ready remains not claimed.

### 1501 — Dashboard UI Kit Consolidation QA

Status: `DONE v170.77`.

Closed audit/TZ finding `CYC-1459`: `DashboardPanelAction` now
supports `onClick`, explicit `actionKind` values and contract V2.
No business logic, backend, OpenAPI, money-flow or runtime mutation
behavior was changed.

### 1502 — DASH-01 Orphan AdminInteractiveBankDashboard deletion

Status: `DONE v170.78`.

Closed audit/TZ finding `DASH-01`: the orphan deprecated admin bank
dashboard file was deleted and guarded against reimport or synthetic
`buildSeries` reintroduction.

### 1503 — DASH-02 Admin Domain Report Endpoints Foundation

Status: `DONE v170.79`.

Closed audit/TZ `DASH-02`: implemented five read-only admin
domain report endpoints with `require_admin`, statement timeout,
OpenAPI/seam sync and aggregate-only responses.

### 1504 — DASH-03 Grafana Pattern Map Completion

Status: `DONE v170.80`.

Closed audit/TZ `DASH-03`: completed the Grafana pattern map for Grid
layout, Drill-down and Empty/error states. No runtime, CSS, backend,
OpenAPI, dependency, lock file or money-flow changes.

### 1505 — GitHub CI Rerun Proof

Status: `DONE locally v170.81 with red-log repair`.

The provided GitHub CI rerun log was not green. Cycle 1505 repaired the
concrete ruff/pytest guard failures from `logs_73728142603.zip`, but it
does not claim GitHub CI green for `v170.81`. A fresh rerun is still
required before any release-safe statement.


### 1510 — Wallet Model Replacement Trace

Status: `DONE v170.86`.

Closed the audit-tail question about the deleted
`backend/app/models/wallet_models.py`. The active replacement is
`backend/app/models/wallets_models.py::WalletBinding`, with
`backend/app/lib/ton_address.py::canonicalize_ton_address` as the
canonical address helper.

### Later proof/release cycles

Browser Screenshot Proof Matrix and Release Audit Preparation remain
required before any release-safe statement. GitHub CI must be rerun again
after the 1505 repair archive.

## 3. Planned range map

| Cycle | Theme | Status |
|---:|---|---|
| 1501 | Dashboard UI Kit Consolidation QA / CYC-1459 | done v170.77 |
| 1502 | DASH-01 Orphan AdminInteractiveBankDashboard deletion | done v170.78 |
| 1503 | DASH-02 Admin Domain Report Endpoints Foundation | done v170.79 |
| 1504 | DASH-03 Grafana Pattern Map Completion | done v170.80 |
| 1505 | GitHub CI Rerun Proof | done locally v170.81; red-log repaired, green rerun still required |
| 1506 | PACK-01 Withdraw Canon Clarification | done locally |
| 1507 | PACK-02 Payment Intent Canon | planned |
| 1508 | Admin Dashboard Russian Operator Copy QA | planned |
| 1509 | Dashboard Route Link Drill-down QA | planned |
| 1510 | Dashboard Empty/Error/Stale State Matrix | planned |
| 1511 | Observability Timeseries Query QA | planned |
| 1512 | Admin Logs Safe Projection QA | planned |
| 1513 | Admin Reports Snapshot-to-Domain Bridge Plan | planned |
| 1514 | Bundle Budget CI Guard Proposal | planned |
| 1515 | TMA Mobile Width Screenshot Pass | planned |
| 1516 | Public Profile/Wallet/History UX QA | planned |
| 1517 | Withdraw UI Semantic QA | planned |
| 1518 | Deposits Exception UX QA | planned |
| 1519 | Panels Lifecycle Visual QA | planned |
| 1520 | Ranks/Leaderboard Privacy QA | planned |
| 1521 | Tasks/Referrals Operator QA | planned |
| 1522 | Exchange Dashboard Truth QA | planned |
| 1523 | System Health Incident Copy QA | planned |
| 1524 | Logs/Events Severity Taxonomy QA | planned |
| 1525 | Archive Numbering Rollover Repair | done locally v171.00 |
| 1526 | Fresh CI Rerun / Live Telegram / Real TonConnect Proof | done locally v171.01 |
| 1527 | CI evidence / chat docs / test consolidation proposal | done locally v171.02 |
| 1528 | Kernel / map_element Compaction Pass | done locally v171.03 |
| 1529 | Fresh CI Evidence Intake / Red-log Repair | planned next |
| 1530 | Dependency Audit Rerun | planned |
| 1531 | Security Regression Pass | planned |
| 1532 | Money Invariants Regression Pass | planned |
| 1533 | TG_ID Identity Boundary Reaudit | planned |
| 1534 | Idempotency Boundary Reaudit | planned |
| 1535 | Admin RBAC Surface Review | planned |
| 1536 | Public Raw Identifier Leak Audit | planned |
| 1537 | Locale Placeholder Leak Audit | planned |
| 1538 | Dashboard Accessibility Deep Pass | planned |
| 1539 | Dashboard Overflow Deep Pass | planned |
| 1540 | Dark Theme Visual Consistency QA | planned |
| 1541 | First Paint Asset Reaudit | planned |
| 1542 | Cloud Run Deployment Readiness Notes | planned |
| 1543 | Neon DB Latency Notes | planned |
| 1544 | Release Notes Draft | planned |
| 1545 | User Documentation Sync | planned |
| 1546 | Admin Operator Runbook Sync | planned |
| 1547 | Error Registry Sync | planned |
| 1548 | Healer Atlas Sync | planned |
| 1549 | Casebook Sync | planned |
| 1550 | Mid-range Audit Freeze | planned |
| 1551 | Backlog Triage A | planned |
| 1552 | Backlog Triage B | planned |
| 1553 | Backlog Triage C | planned |
| 1554 | QA Debt Burn-down A | planned |
| 1555 | QA Debt Burn-down B | planned |
| 1556 | QA Debt Burn-down C | planned |
| 1557 | Admin Domain Reports Users | planned |
| 1558 | Admin Domain Reports Bank | planned |
| 1559 | Admin Domain Reports Panels | planned |
| 1560 | Admin Domain Reports Withdrawals | planned |
| 1561 | Admin Domain Reports Deposits | planned |
| 1562 | Reports UI Integration Plan | planned |
| 1563 | Reports UI Integration Pass A | planned |
| 1564 | Reports UI Integration Pass B | planned |
| 1565 | Reports QA Pass | planned |
| 1566 | Screenshot Proof Expansion | planned |
| 1567 | Browser Automation Stabilization | planned |
| 1568 | CI Performance Notes | planned |
| 1569 | Test Runtime Optimization Plan | planned |
| 1570 | Test Runtime Optimization Pass | planned |
| 1571 | Public Dashboard Copy Polish | planned |
| 1572 | Admin Dashboard Copy Polish | planned |
| 1573 | i18n Semantic QA Wave A | planned |
| 1574 | i18n Semantic QA Wave B | planned |
| 1575 | i18n Semantic QA Wave C | planned |
| 1576 | UX Linkage Audit | planned |
| 1577 | Backend ↔ Frontend Linkage Audit | planned |
| 1578 | Migration Drift Audit | planned |
| 1579 | OpenAPI Strict Gate Reaudit | planned |
| 1580 | Security Audit Mini-pass | planned |
| 1581 | Economic Invariants Mini-pass | planned |
| 1582 | Wallet/TonConnect QA | planned |
| 1583 | Deposits/Withdrawals Money Path QA | planned |
| 1584 | Admin Evidence Pack | planned |
| 1585 | Public Evidence Pack | planned |
| 1586 | Release Candidate Checklist | planned |
| 1587 | Referral runtime/API TZ audit | done locally |
| 1588 | Exact-HEAD evidence gate repair | done locally |
| 1589 | Release Candidate Repair C | planned |
| 1590 | Final Green CI Proof | planned |
| 1591 | Final Browser Screenshot Proof | planned |
| 1592 | Final Security Proof | planned |
| 1593 | User identity audit and architecture guard | completed in v171.90 |
| 1594 | UserId contract and negative guards | completed locally in v171.91; fresh CI required |
| 1595 | Backend UserId value type | completed locally in v171.92; fresh CI required |
| 1596 | External API/Pydantic UserId contract | completed locally in v171.93; fresh CI required |
| 1597 | users.user_id nullable EXPAND / Alembic 0002 | completed locally in v171.94; online PostgreSQL required |
| 1598 | LEGACY alias and migration harness | completed locally in v171.95; PostgreSQL reconciliation required |
| 1599 | PostgreSQL reconciliation gate | planned |
| 1600 | 1501–1600 Range Closure / Next Range Handoff | planned |

## 4. Non-negotiable rules

- Do not weaken tests.
- Do not hide failing logs.
- Do not claim release-ready without release audit.
- Do not claim browser screenshots without actual browser capture.
- Do not claim GitHub CI green without CI log proof.
- Do not reintroduce synthetic runtime analytics.
- Do not copy runtime code from Grafana or Sandbox.


## Tail note from work item 1498

The public dashboard i18n fallback issue found by CI was repaired before moving
toward the next range. Future i18n work should treat user-facing dashboards as
a 13-language surface and admin dashboards as Russian operator surfaces unless
a dedicated admin i18n effort is opened.


## Tail note from work item 1499

`VIS-03` was closed in v170.75. Future range keeps only regression QA, not the original raw balance-type repair.

## Tail note from cycle 1500

Range `1401–1500` is closed in `v170.76` at `100 / 100`. Dashboard direction
`1455–1496` remains closed/frozen at `42 / 42`. This `1501–1600` plan is now
the next controlled hardening/proof/release-preparation range.

The first safe cycle remains `1501 — Dashboard UI Kit Consolidation QA`.
Cycle `1500` did not claim GitHub CI green, full pytest green, full frontend
build green, release-ready, browser screenshot proof, live Telegram proof or
real TonConnect / wallet proof.


## Tail note from cycle 1501

Audit/TZ `docs/audits/AUDIT_TZ_REPAIR_1501_1504.md` was accepted as
the active repair sequence for cycles `1501–1504`. Cycle 1501 closed
`CYC-1459` only. Remaining audit/TZ findings are intentionally kept
for separate controlled cycles: `DASH-01` in 1502, `DASH-02` in 1503
and `DASH-03` in 1504.

## Tail note from cycle 1503

Cycle 1503 closed `DASH-02`. Cycle 1504 later closed the final
repair item, `DASH-03`.

Chat export `33.md` was added to `docs/NORM/CHATS/` as the canonical
visible chat record for cycles `1486–1499`.


## Tail note from cycle 1504

Cycle 1504 closed `DASH-03`. The audit/TZ repair block `1501–1504`
is closed locally at `4 / 4` done and `0 / 4` remaining. The next
safe cycle is `1505 — GitHub CI Rerun Proof`.


## Tail note from cycle 1505

Cycle 1505 consumed `logs_73728142603.zip`. The log was red: ruff and
pytest failed while mypy, bandit, npm ci and frontend build passed. The
root causes were repaired locally in `v170.81`, but GitHub CI green is
not claimed until a fresh rerun proves it.


## Tail note from cycle 1506

Cycle 1506 was reassigned from generic release-audit preparation to
PACK-01 withdraw canon clarification because a self-contained TZ was
provided. PACK-01 is closed locally in `v170.82` without runtime changes.

The next safe package is `1507 — PACK-02 Payment Intent Canon`. Release
audit preparation remains blocked until current canon/audit packs and a
fresh green CI proof are available.


## Tail note from cycle 1507

Cycle 1507 closed PACK-02 TON Wallet Canon / Admin Payout Canon.
Canonical TON address storage, admin payout non-treasury-access canon and
single active TonConnect wallet binding mechanism are now documented and
protected by tests.

The next safe cycle is `1508 — Payment Intent Canon`.
## 1508 — PACK-02 tails wallet canon cleanup — DONE

Closed remaining wallet canon tails: removed the legacy admin
`crypto_wallets` contour from runtime and added canonical backfill for
existing `wallet_bindings.wallet_address` values.



## Cycle 1509 status

`1509 — PACK-03 Final Cleanup and Consistency` is closed in v170.85.

Closed:

- wallet legacy naming cleanup;
- direct EFHC payment intent canon;
- watcher incoming deposit accounting canon;
- DB drift matrix;
- admin button coverage matrix;
- frontend/API/i18n consistency matrix;
- release proof status.

Remaining after 1509:

- fresh GitHub CI green proof;
- browser screenshot proof;
- release audit before any release-ready claim.


## 1511 — GitHub CI log repair — DONE v170.87

- Repaired `logs_74007805923.zip` failures.
- Input log was red; no GitHub CI green claimed for output archive.
- Next safe cycle: `1512`.

## Tail note from cycle 1512

Cycle 1512 closed two admin money-path P1 findings and added a static
AST guard so unsupported kwargs in admin money calls cannot pass
silently again.

Input log `logs_74012116642.zip` was green for v170.87, but no GitHub
CI green is claimed for v170.88 until a fresh rerun proves it.

## Tail note from cycle 1513

Cycle 1513 repaired the red input CI log root causes and completed the
adminSeams migration. Admin pages now have zero direct raw admin
`apiRequest` calls. The output archive still needs a fresh GitHub CI rerun
before any `CI_GREEN` claim.

Next safe cycle: `1514 — Admin UX QA / Visual Regression / Full Button Click Proof`.

## Tail note from work item 1515

- Cycle 1515 produced `v170.91` as a local proof/preparation archive.
- Fresh GitHub CI green remains `GITHUB_CI_NOT_VERIFIED` until a new log proves it.
- Visual/browser proof remains `VISUAL_NOT_VERIFIED`; the admin button-click matrix is prepared for cycle 1516.
- Next safe cycle: `1516 — Browser/Admin visual capture and button-click execution proof`.
- Range status after 1515: `15 / 100` done, `85 / 100` remaining.

## Tail note from cycle 1516

Cycle 1516 closed the Stage 3 DB drift audit findings locally:

- VIP/NFT TonConnect sync now resolves `wallet_bindings` before legacy `users.ton_wallet`.
- `/v1/me` stale refresh is no longer gated by `users.ton_wallet`.
- NFT/VIP batch discovery includes active wallet bindings and legacy fallback users without duplicate global_id rows.
- `bonus_awards` is documented as legacy/dead code and guarded.
- `withdraw_requests.amount` precision is aligned to `Numeric(30,8)`.
- Deprecated `withdrawals` constraint drift is documented.

Next safe cycle: `1517 — Frontend Buttons / API / i18n Drift Audit`.
Range status after 1516: `16 / 100` done, `84 / 100` remaining.

## Tail note from cycle 1517

Cycle 1517 closed static frontend/API/i18n drift locally:

- admin components now use generated admin seams instead of direct raw admin `apiRequest` calls;
- Node i18n audit scripts run correctly;
- frontend lock audit is clean for high vulnerabilities;
- browser proof remained pending for cycle 1518.

Next safe cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.
Range status after 1517: `17 / 100` done, `83 / 100` remaining.

## Tail note from cycle 1518

Cycle 1518 completed local browser/admin visual capture and admin hub navigation proof:

- 7 admin core routes captured with screenshots;
- 6 admin hub navigations verified in a local Chromium/Playwright browser context;
- visual proof is local and bounded, not exhaustive all-admin click coverage;
- live Telegram, real TonConnect, GitHub CI and release-ready remain unclaimed.

Next safe cycle: `1519 — Fresh CI proof / New Audit Intake Gate`.
Range status after 1518: `18 / 100` done, `82 / 100` remaining.

## Tail note from cycle 1519

Cycle 1519 repaired the red CI log from `logs_74249190312.zip`.
The exact pytest/frontend gate failures were treated as red-log root
causes and repaired locally. Output GitHub CI green remains unclaimed
until a fresh rerun proves the new archive.

Range status after 1519: `19 / 100` done, `81 / 100` remaining.

## Tail note from cycle 1520

Cycle 1520 closed the frontend i18n and local visual proof tails:

- public missing i18n keys are `0`;
- all 13 locales contain `1434` keys;
- UK Russian-tail markers are `0` on the current guard;
- admin visual runtime guard passed locally for `7 / 7` routes;
- public browser proof passed locally for `11 / 11` routes;
- release/live proof remains outside this cycle.

Next safe cycle: `1521 — Live Telegram / Real TonConnect / Release Readiness Proof`.
Range status after 1520: `20 / 100` done, `80 / 100` remaining.


## Tail note from cycle 1524

Cycle 1524 repaired the red CI log from `logs_74379950976.zip`.
The log showed only two pytest failures, both caused by the cycle 1523
DB-backed withdrawals runtime test helpers using an empty string for absent
`users.ton_wallet`. The helpers now use `NULL`, matching the wallet canon and
avoiding `uq_users_ton_wallet` collisions.

Next safe cycle: `1525 — Archive Numbering Rollover Repair`.
Range status after 1524: `24 / 100` done, `76 / 100` remaining.

## Tail note from cycle 1525

Cycle 1525 repaired archive numbering rollover after the valid `v170_99`
lineage anchor. The canonical output lineage is `v171_00`. A dedicated
architecture guard now rejects non-historical three-digit minor suffixes.

Next safe cycle: `1526 — Fresh CI Rerun / Live Telegram / Real TonConnect Proof`.
Range status after 1525: `25 / 100` done, `75 / 100` remaining.

## Tail note from cycle 1571

Cycle 1571 normalized the active and mirror GitHub workflows and completed
one exact 2508-node local regression inventory. The requested Worker,
checksum, persistence, byte-aware cache, learned prefetch, Web Vitals,
compressed-budget, offline and immutable-catalog optimization package is
closed locally in v171.47.

Fresh GitHub green proof is not inferred from local parity. The next safe
work is cycle 1572: consume the user's fresh rerun log and triage remaining
release blockers without changing the protected economic or payment canon.

## Planning synchronization from v171.49 / active cycle 1572

The canonical tree was restored once into `/mnt/data/efhc_workspace` from the
verified `EFHC_Bot_v171_48.zip`. The factual implementation stop point remains
`v171.47`; `v171.48` repaired transfer and execution boundaries and did not
complete cycle 1572.

Strict remaining sequence:

- **1572 — Fresh GitHub rerun intake and residual blocker repair (ACTIVE).**
  Consume only a newly supplied rerun log, isolate the first substantive root
  cause, repair the bounded contour, run targeted checks and update current-head
  release evidence. Do not run a local copy of full CI by default.
- **1573 — Live Telegram / TonConnect / TonProof / real transaction proof (PLANNED, OPERATOR-DEPENDENT).**
  Execute only with user-controlled environments and credentials. Preserve the
  distinction between direct EFHC jetton deposit and Browser Shop checkout.
- **1574 — Final fail-closed release-candidate audit (PLANNED).**
  Reconcile all current-head P0/P1 findings, release ownership, rollback and
  sign-off evidence. A numeric target does not authorize a release claim.

Range accounting remains cycle-based: `71 / 100` completed; cycle 1572 is
active; cycles 1573–1574 are planned. Archive numbering may advance for honest
planning/documentation snapshots without falsely closing a work cycle.
