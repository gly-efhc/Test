# 1466 — Variables / Filters System / v170.42

Status: `DONE_LOCALLY`

## Goal

Create the first EFHC-owned dashboard variables / filters foundation for
Admin Dashboard Layer and Simulation Dashboard Layer.

## Done

- Added shared runtime filter system:
  `frontend/src/components/dashboard/DashboardFilters.tsx`.
- Added admin wrappers in:
  `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- Added simulation wrappers in:
  `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- Added CSS foundation in:
  `frontend/src/styles/globals.css`.
- Added active NORM document:
  `docs/NORM/VARIABLES_FILTERS_SYSTEM.md`.
- Added guard:
  `tests/architecture/test_variables_filters_system.py`.
- Updated Grafana usage map and `map_element.md` with variables/filter
  anchors.

## Safety boundary

No EFHC economy, backend contract, database migration, CI workflow,
lock file, wallet logic, payment logic or admin write flow was changed.

Filters are read-only display controls. URL query sync is allowed only
for safe display keys and is not business truth.

Grafana and Песочница remain reference/navigation/prototype layers only.

## Next

`1467 — Energy Dashboard Sandbox Prototype`.
