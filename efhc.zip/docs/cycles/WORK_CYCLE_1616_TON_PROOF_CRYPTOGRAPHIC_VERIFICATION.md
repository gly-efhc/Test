# Цикл 1616 — cryptographic TON Proof verification

Версия пакета: `v172.15`.

## Цель

Проверить TON wallet identity криптографически и закрыть one-time
challenge, не создавая account, identity или session раньше циклов
`1617–1618`.

## Реализовано

1. Добавлен endpoint:

   ```text
   POST /api/auth/ton/proof
   ```

2. TON Connect v2 message строится как double SHA-256 над:
   - workchain в int32 big-endian;
   - 32-byte account ID;
   - domain length в uint32 little-endian;
   - UTF-8 domain;
   - timestamp в uint64 little-endian;
   - one-time challenge payload.
3. Проверяются:
   - exact configured domain и `lengthBytes`;
   - timestamp age не старше 15 минут;
   - future skew не более 60 секунд;
   - chain `-239` либо `-3` и configured network;
   - bounded Base64 BoC state-init;
   - canonical address из state-init;
   - authoritative Ed25519 public key;
   - совпадение client key с authoritative key;
   - Ed25519 signature.
4. После успешной crypto verification challenge потребляется одним
   PostgreSQL `UPDATE ... RETURNING` по token hash, provider, purpose,
   domain и exact challenge ID.
5. Replay, TTL expiration, wrong challenge ID и concurrent consumption
   завершаются fail closed.
6. Response содержит только verified TON provider subject и не содержит
   `global_id`, session token либо Telegram identity.

## Объединение похожих tests

Однотипные vectors объединены без потери покрытия:

- domain/timestamp/network/key/signature/state-init failures находятся
  в одной параметризованной таблице;
- schema coercion cases находятся в одной параметризованной таблице;
- TonAPI configuration и authoritative-address cases параметризованы;
- PostgreSQL TTL и wrong-ID boundaries объединены одним test function;
- общая генерация Ed25519 vectors вынесена в
  `tests/support/ton_proof_vectors.py`.

## Не входит в цикл

- создание нового account;
- сохранение `user_identities`;
- выдача `auth_sessions`;
- TON-only registration;
- frontend session transport;
- Telegram adapter;
- migration `0005`;
- financial changes.

## Exit gate

```text
TON_PROOF_ALL_VECTORS_PASS
TON_PROOF_CONCURRENT_CONSUMPTION_PASS
EXACT_HEAD_CI_REQUIRED
```

## Локальное причинное подтверждение

- новые cryptographic vectors: `25 PASS`;
- route и подтверждённые CI contracts: `31 PASS`;
- static guard и Operator Kernel route: `4 PASS`;
- PostgreSQL integration module: `3 tests collected`, DB not run;
- Alembic head: `0004`, migration `0005` отсутствует;
- полный pytest, PostgreSQL и frontend build оставлены GitHub CI.
