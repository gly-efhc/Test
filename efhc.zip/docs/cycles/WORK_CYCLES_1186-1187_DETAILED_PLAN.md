# WORK CYCLES 1186-1187 DETAILED PLAN

## Purpose

This pass checks the 1186 route-alias tail before moving to withdraw.
The goal is defect repair, not cycle production.

## Cycle 1186 tail check

Checklist:
- prove active backend has `/user/me/panels-summary`;
- prove active backend has no `/{global_id}/panels-summary` route;
- keep historical audit mentions only as past context;
- do not delete historical reports just to hide old evidence.

Result:
- active alias is removed;
- generated historical files still record the old state;
- no release-wide road readiness is claimed.

## Cycle 1187 withdraw economic road repair

Checklist:
- user create path requires idempotency;
- user list resolves global_id from auth;
- optional query global_id is only a legacy self-check;
- user cancel refunds from bank when hold was done;
- admin approve finalizes PAID with explicit commit;
- admin approve supports same-key PAID replay;
- admin reject refunds and commits outcome;
- outcome event and admin log anchors exist;
- NORM API contract matches active routes.

Result:
- code, guard, test, API contract, matrix and report are aligned;
- GitHub CI is still required for final release evidence.
