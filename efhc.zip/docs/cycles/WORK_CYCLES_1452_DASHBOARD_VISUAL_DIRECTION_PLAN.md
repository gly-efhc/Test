# Cycle 1452 — Dashboard Visual Direction Plan / v170.28

## Цель

Зафиксировать активное направление работ для dashboard-визуализации
EFHC Bot и план циклов `1455–1495`.

## Входные файлы

- HEAD: `EFHC_Bot_v170_27_cycle_1451_ci_log_repair.zip`.
- План: `DASHBOARD_VISUAL_PLAN.md`.
- Reference: `grafana-main.zip`.

## Что сделано

- Добавлен активный документ:
  `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Диапазон направления зафиксирован как `1455–1495`, 41 цикл.
- Добавлен завершающий цикл `1495` для handoff/backlog freeze.
- `grafana-main.zip` проверен только как reference archive.
- Прямой перенос Grafana runtime, lock files, CI, зависимостей и
  кода в EFHC Bot не выполнялся.
- Обновлены Kernel, map_element, reports index, testing manifest и
  machine report.

## Граница Grafana

Берём только visual discipline: panel chrome, dashboard shell, toolbar,
time range, refresh, variables, inspector, grid, status cards, mini
charts, empty/error/loading states.

Не берём root runtime Grafana, чужие зависимости, AGPL/root code, lock
files, CI workflows, backend logic или charts как готовый продуктовый
runtime.

## Статус циклов

- До цикла 1452: `51 / 100` сделано, `49 / 100` осталось.
- После цикла 1452: `52 / 100` сделано, `48 / 100` осталось.
- План dashboard-направления: `1455–1495`, 41 цикл.

## Что не менялось

- Экономика EFHC.
- Backend contracts.
- DB migrations.
- CI/workflows/lock files.
- Runtime dashboard implementation.

## Проверки

- ZIP integrity исходного HEAD.
- `grafana-main.zip` testzip.
- AI Archive Laws lock.
- New dashboard direction guard.
- Filename hygiene / line72 selected guards.

## Не заявляется

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- Release-ready.
- Browser screenshots.
- Live Telegram proof.
- Real TonConnect/wallet proof.
