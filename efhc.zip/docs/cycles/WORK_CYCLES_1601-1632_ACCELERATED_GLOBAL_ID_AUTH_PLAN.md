# Расширение плана до 1640 — v172.51

Новая последовательность:

- `1634` — чаты, Q/A и public UI foundation;
- `1635` — corrective public/admin visual parity;
- `1636` — ядро AccountRegistrationService;
- `1637` — Telegram Bot через единый центр;
- `1638` — provider-neutral referral ingress;
- `1639` — Telegram WebApp и TON через единый центр;
- `1640` — global_id business ownership closure.

Подробности: `WORK_CYCLES_1636-1640_ACCOUNT_REGISTRATION_CENTER.md`.

```text
CYCLE_1635_CORRECTIVE_IMPLEMENTED
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_NOT_STARTED
CYCLE_1640_NOT_STARTED
```

---

# Current roadmap gate — corrective v172.39

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI exact v172.38 прошёл весь Chromium и все остальные gates,
кроме одного archive filename hygiene test. v172.39 исправляет только
этот finding. Cycle `1631` может начаться лишь после полного exact-head
PASS v172.39. Cycle `1632` не начат.

---

# Current roadmap gate — corrective v172.38

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI exact v172.37 выявил шесть pytest findings и `51` admin
marker failures. v172.38 исправляет только эти findings. Cycle `1631`
может начаться лишь в следующем пакете после полного exact-head PASS
v172.38. Cycle `1632` не начат.

---

# Current roadmap gate — corrective v172.37

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI v172.36 не закрыл exit gate `1630`: общий Chromium audit дал
`51` admin marker failures. v172.37 исправляет только identity bootstrap
guard. Cycle `1631` может стать v172.38 только после полного fresh PASS
v172.37. Cycle `1632` не начат.

---

# Current roadmap gate — corrective v172.36

```text
CYCLE_1630_CROSS_PROVIDER_SESSION_CHROMIUM_PROOF_PASS
CYCLE_1630_ROUTE_BACKED_VISUAL_CI_FAILED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
```

Fresh CI v172.35 не закрыл полный exit gate `1630`. Corrective v172.36
устраняет CSP/status/admin-build и stale-contract findings. Цикл `1631`
не начат; его physical rename разрешён только после fresh full PASS.

---

# Текущий статус обязательного плана 1601–1633 — v172.35

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83240274364` на exact v172.34 не закрыл browser exit gate.
Corrective v172.35 исправляет static findings, deterministic Chromium
session proof и сохраняет новый универсальный canonical CI внутри
archive. Cycle `1631` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.34

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83236222987` на exact v172.33 не выявил production blocker,
но exit gate `1630` неполон: wrong integration DB input profile и
skipped Chromium evidence. Corrective v172.34 исправляет harness и
встраивает cross-provider proof в существующий protected visual audit.
Cycle `1631` не начат до двух fresh exact-head CI proofs.

---

# Текущий статус обязательного плана 1601–1633 — v172.32

```text
CYCLE_1628_EXTENDED_DOMAIN_OWNER_EXACT_HEAD_PASS
CYCLE_1628_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_PACKAGE_READY
CYCLE_1629_EXACT_HEAD_CI_REQUIRED
CYCLE_1630_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83181651259` на exact `v172.31` применил real PostgreSQL
`0012`; remaining failures локализованы в negative-test harness,
test cleanup и static/Mypy/Ruff contracts. Cycle `1629` реализован без
schema change: server-side session first для common/admin API,
provider-neutral `/sync/me`, измеряемый legacy Telegram compatibility и
frontend `GlobalId` cache identity. Alembic head остаётся `0012`.
Следующий цикл `1630` не начат до fresh exact-head CI v172.32.

---

# Текущий статус обязательного плана 1601–1633 — v172.31

```text
CYCLE_1627_FINANCIAL_READ_SWITCH_EXACT_HEAD_PASS
CYCLE_1627_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1628_PACKAGE_READY
CYCLE_1628_EXACT_HEAD_CI_REQUIRED
CYCLE_1629_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83164293703` на exact v172.30 квалифицировал `0011` financial
read switch; оставшиеся findings были только simple. Cycle `1628`
реализован в v172.31: remaining Shop/NFT/cosmetics/memo/notifications/
external-event ownership surfaces используют `global_id`; существующий
admin/external schema EXPAND повторно не создаётся. Alembic head `0012`.
Следующий цикл `1629` не начат до fresh exact-head CI v172.31.

---

# Текущий статус обязательного плана 1601–1633 — v172.30

```text
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_EXACT_HEAD_PASS
CYCLE_1627_FINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1627_EXACT_HEAD_CI_REQUIRED
CYCLE_1628_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83151379137` на exact `v172.29` квалифицировал financial
shadow validation. В `v172.30` реализован `0011` financial read switch
с rollback и повторным zero-telemetry/`0.00000000` gate. Следующий цикл
`1628` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.29

```text
CYCLE_1625_POSTGRESQL_0010_PASS
CYCLE_1626_CI_FINDINGS_CORRECTED_IN_V172_29
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_REQUALIFICATION_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83144620488` на exact `v172.28` подтвердил real PostgreSQL
`0010`, но не дал exit proof цикла `1626`: PostgreSQL integration fixture
упал до financial reconciliation gate. `v172.29` — corrective-only.
Следующий цикл `1627` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.28

```text
CYCLE_1625_POSTGRESQL_0010_PASS_CI_FINDINGS_CORRECTED
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_PACKAGE_READY
CYCLE_1626_EXACT_HEAD_CI_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83121417737` на exact `v172.27` подтвердил real PostgreSQL
`0010`. Cycle `1626` реализован как read-only financial shadow validation;
новая migration не создаётся. Следующий цикл: `1627`.
`CYCLE_1627_NOT_STARTED`.

---

# Текущий статус обязательного плана 1601–1633 — v172.27

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83098311619` на exact `v172.26` подтвердил real
PostgreSQL `0009`. Единственный pytest finding был документным и
исправлен. Cycle `1625` реализован в `v172.27`; cycle `1626` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.26

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83093436890` на exact `v172.25` выявил critical PostgreSQL
syntax defect telemetry view migration `0009`. Corrective `v172.26`
исправляет SQL composition и подтверждённые static findings. Цикл
`1625` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.25

```text
CYCLE_1623_POSTGRESQL_0008_PASS_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1624_DUAL_WRITE_SHADOW_TELEMETRY_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83067297122` на exact `v172.24` подтвердил real PostgreSQL
`0008`. Cycle `1624` реализован в `v172.25`; cycle `1625` не начат.

---

# Текущий статус обязательного плана 1601–1633 — v172.24

```text
CYCLE_1623_CRITICAL_POSTGRESQL_BLOCKER_CONFIRMED
CYCLE_1623_CORRECTIVE_PACKAGE_READY
CYCLE_1623_EXACT_HEAD_CI_REQUIRED
CYCLE_1624_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh run `83053365488` на exact `v172.23` выявил critical PostgreSQL
blocker migration `0008`: `LOCK TABLE` выполнялся вне real transaction.
Corrective `v172.24` разделяет AUTOCOMMIT schema bootstrap и Alembic
migration connection. Cycle `1624` не начат.

---

# EFHC Bot — ускоренный план Global ID и модульной авторизации 1601–1633

Статус: `ACTIVE_SSOT`.
Диапазон обязательных циклов: `1601–1633`.
Текущий scope: cycle `1625`, пакет `v172.27`.
Текущий статус:

```text
CYCLE_1624_CRITICAL_POSTGRESQL_0009_BLOCKER_CONFIRMED
CYCLE_1624_CORRECTIVE_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Следующий цикл: `1626`, только после fresh exact-HEAD CI qualification
`v172.27`. Financial shadow validation пока не начата.

Фактическое имя файла сохранено как
`WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md`, чтобы не создавать
риск broken references в guards и Operator Kernel. Каноническое содержание и
обязательный диапазон расширены до `1633`.

## 1. Неподвижные правила

1. `global_id` — единственный account owner; provider IDs не являются owner.
2. До цикла `1631` физическая колонка остаётся `users.user_id`.
3. PostgreSQL data gates не объединяются с неподтверждённым read switch.
4. Financial switch отделён от non-financial switch и требует расхождения
   `0.00000000`.
5. Physical rename выполняется только после `fallback/mismatch = 0`.
6. Migration squash запрещён раньше завершения physical rename.
7. CI workflow не изменяется без прямой команды пользователя.
8. Полный regression, PostgreSQL и Chromium выполняются пользователем через
   существующий GitHub CI; локально разрешены только короткие причинные checks.

## 2. Правила ускорения

1. Code line и PostgreSQL data gates разделяются: подготовленный код не
   считается доказанным до реального PostgreSQL и exact-HEAD CI.
2. `PG-0` подтверждает migration и constraints, но не разрешает backfill,
   read switch или ownership switch.
3. Канон `global_id` закреплён с цикла `1602`: `global_id` является account
   owner, а `tg_id` остаётся только Telegram provider ID.
4. Исторические contract markers сохраняются для совместимости guards:

   - Текущий подготовленный цикл после этой редакции: `1611`
   - Статус gate: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED`
   - Следующий цикл после подтверждённого `PG-0 PASS`: `1612`

   Эти три строки являются историческими markers состояния до первого
   реального PostgreSQL run и не описывают текущий статус `v172.10`.
5. Историческая формулировка «Циклы `1633–1700` не являются обязательными»
   больше не является текущим каноном: цикл `1633` обязателен как финальная
   qualification, а циклы `1634–1700` не входят в обязательный диапазон.

### 2.1. Обязательные gates

| Gate | Цикл | Значение |
|---|---:|---|
| `FOUNDATION` | 1608 | Global ID code line, allowlist и compatibility registry закрыты |
| `PG-0` | 1611 | Real PostgreSQL evidence и fresh exact-HEAD static gates |
| `AUTH-CORE` | 1614 | identities/challenges/sessions/roles и resolver доказаны |
| `TON-AUTH` | 1618 | TON Proof login закрыт на PostgreSQL |
| `TELEGRAM-ADAPTER` | 1619 | Telegram проходит через `IdentityResolver` |
| `BACKFILL` | 1623 | Historical mapping и reconciliation = `0.00000000` |
| `DUAL-WRITE` | 1624 | mismatch/fallback telemetry активна |
| `NON-FINANCIAL` | 1625 | non-financial reads переведены |
| `FINANCIAL` | 1627 | financial shadow/read switch доказан |
| `RENAME` | 1631 | physical rename и cleanup доказаны на clone |
| `SQUASH` | 1632 | `PRE_RELEASE_MIGRATION_SQUASH_PASS` |
| `RELEASE` | 1633 | exact-HEAD qualification и production handoff |

## 3. Завершённый фундамент и текущий цикл

| Цикл | Состояние |
|---:|---|
| 1601–1607 | Foundation и cross-language разделение `GlobalId`/`TelegramId` завершены |
| 1608 | Semantic allowlist и compatibility registry завершены |
| 1609 | `AuthProvider`, `VerifiedIdentity` и provider registry завершены |
| 1610 | `AuthContext`, resolver interfaces и redaction skeleton завершены |
| 1611 | **ЗАВЕРШЁН:** exact-HEAD run `82850316409`; PostgreSQL/Alembic/static/pytest/frontend PASS |
| 1612 | **ФУНКЦИОНАЛЬНЫЙ ОБЪЁМ PASS:** resolver/PostgreSQL/static gates прошли; handoff marker исправлен в v172.12 |

Run `82865834601` подтвердил functional/static/PostgreSQL объём цикла `1612`,
но общий exact-HEAD gate упал на одном handoff marker. Исправление включено в
`v172.12`; цикл `1613` подготовлен и требует fresh exact-HEAD CI.




Run `82897904509` на exact HEAD `v172.13` подтвердил PostgreSQL/Alembic
`0004`, Ruff, Mypy, Bandit и frontend. Четыре architecture failures исправлены
в `v172.14`; они не выявили runtime, migration или financial defect.

Run `82909483300` на exact HEAD `v172.14` подтвердил PostgreSQL/Alembic
`0004`, Bandit и frontend. Три Ruff, одна Mypy и четыре architecture
failures исправлены в `v172.15`; они не выявили migration, financial или
PostgreSQL defect.


Run `82923200235` на exact HEAD `v172.15` подтвердил PostgreSQL/Alembic
`0004`, Bandit и frontend. Три Ruff, две Mypy и десять pytest failures
исправлены в `v172.16`. PostgreSQL failure цикла `1616` был вызван
тестовым vector, подписанным не выданным challenge token; runtime DDL и
финансовые контуры дефектов не показали.

Цикл `1617` добавляет migration `0005`, nullable `users.global_id`,
provider-neutral `wallet_bindings.global_id` и transactional flow:
existing identity → тот же `global_id`; verified legacy binding → тот же
account; новый wallet → `users + user_identities + wallet_bindings` одной
транзакцией. Fake `global_id`, auto-merge и session issue запрещены.

### 3.1. Исторические contract rows для guards

| Цикл | Исторический статус |
|---:|---|
| 1609 | `AuthProvider`, `VerifiedIdentity` и provider registry foundation |
| **1609** | **ЗАВЕРШЁН:** `AuthProvider`, `VerifiedIdentity`, provider registry |
| **1611** | Исторический correction package, закрыт run `82850316409` |

## 4. Текущий цикл и оставшиеся обязательные циклы

Цикл `1625` реализован и требует exact-HEAD qualification.
Цикл `1626` не начат.

| Цикл | Интегрированный объём | Exit gate |
|---:|---|---|
| **1612** | **FUNCTIONAL PASS / HANDOFF FIX INCLUDED** — transactional resolver, locks, conflict fail closed | Fresh overall proof объединяется с v172.12 CI |
| **1613** | **REAL PG/ALEMBIC EXECUTED; CORRECTIONS INCLUDED** — `auth_challenges`, `auth_sessions`, `user_roles`, services и FastAPI dependencies | Fresh overall proof объединяется с v172.13 CI |
| **1614** | **POSTGRESQL/STATIC/FRONTEND PASS; 4 DOC CORRECTIONS INCLUDED** — auth-core integration closure | Fresh overall proof объединяется с `v172.14` CI |
| **1615** | **RUNTIME/PG/STATIC/FRONTEND PASS; 8 CI CORRECTIONS INCLUDED** — TON challenge и canonical address | Fresh overall proof объединяется с `v172.15` CI |
| **1616** | **CI ERRORS FIXED IN v172.16** — TON Proof: domain, timestamp, network, state-init, replay, TTL | Fresh exact-HEAD proof объединяется с `v172.16` CI |
| **1617** | **CI ERRORS FIXED IN v172.17** — existing TON identity/binding, TON-only registration и concurrency | PostgreSQL/Alembic proof получен на v172.16; общий gate исправлен |
| **1618** | **EXACT-HEAD CI ERRORS FIXED IN v172.18** — TON auth/session/logout closure и frontend session transport | TON-only login получает hashed session; frontend contract изолирован |
| **1619** | **ЗАВЕРШЁННЫЙ FUNCTIONAL SCOPE** — Telegram initData adapter через `IdentityResolver` и session issue | Telegram provider не owner; повторный вход открывает тот же account |
| **1620** | **SIMPLE CI FINDINGS CORRECTED** — frontend session-first bootstrap, hooks/query keys и provider context skeleton | Новый scope использует session/global_id semantics |
| **1621** | Non-financial EXPAND: panels, energy, referrals, tasks, ranks | `0006`: nullable FK/columns/indexes; fresh CI подтвердил PostgreSQL upgrade, simple findings исправлены |
| **1622** | **POSTGRESQL 0007 PASS / SIMPLE FINDINGS CORRECTED** — financial/admin/external EXPAND | `0007` реально применён fresh CI; ownership switch отсутствует |
| **1623** | **POSTGRESQL 0008 PASS / SIMPLE FINDINGS CORRECTED** — historical backfill/reconciliation | Real PostgreSQL `0008`; integration contract требует `0.00000000` и unresolved rows = 0 |
| **1624** | **POSTGRESQL PASS** — dual-write, shadow telemetry и rollback guards | Real PostgreSQL `0009` подтверждён fresh CI |
| **1625** | **PACKAGE READY** — Non-financial read switch | `0010`; rollback и real PostgreSQL требуют fresh CI |
| **1626** | Financial shadow validation | mismatch/fallback = 0; precision/idempotency unchanged |
| **1627** | Financial read switch и reconciliation closure | Расхождение `0.00000000`; Telegram отсутствует в owner API |
| **1628** | Shop/NFT/cosmetics/memo/admin/notifications/external events migration | Остальные modules используют `global_id`; channel identity отделена |
| **1629** | Общие/admin API, frontend session-first full switch, OpenAPI parity | Telegram и TON sessions видят один account; legacy routes измеряются |
| **1630** | Cross-provider PostgreSQL/API/build/Chromium E2E и закрытие fallback | 0 critical skips; real browser и PostgreSQL evidence exact HEAD |
| **1631** | Physical rename `users.user_id → users.global_id`, FK/index/sequence rename, aliases cleanup, clone upgrade/rollback/restore | fallback/mismatch = 0; cleanup доказан; aliases удалены по registry |
| **1632** | Schema freeze и pre-release migration squash в единый `0001_initial_release_schema.py` | `PRE_RELEASE_MIGRATION_SQUASH_PASS` |
| **1633** | Exact-HEAD CI, release qualification, deployment/rollback/restore/live handoff | `PRODUCTION_RELEASE_READY` только после полного real live proof |

## 5. Самостоятельный migration squash cycle 1632

Цикл `1632` выполняется только после завершения физической схемы цикла `1631`.
Обязательный объём:

1. Зафиксировать окончательную схему первого production release.
2. Доказать отсутствие production-базы, которой нужна старая migration history.
3. Объединить все pre-release migrations в
   `0001_initial_release_schema.py`.
4. Удалить промежуточные pre-release migrations из активной release history.
5. Обновить migration tests, schema invariants, SSOT/NORM и machine contracts.
6. Выполнить clean PostgreSQL qualification через существующий GitHub CI.
7. Доказать отсутствие schema drift и совпадение ORM/migrations/PostgreSQL.

Exit gate:

```text
PRE_RELEASE_MIGRATION_SQUASH_PASS
```

После первого production release `0001_initial_release_schema.py` становится
immutable; последующие изменения выполняются только migrations `0002+`.

## 6. Финальная qualification cycle 1633

`PRODUCTION_RELEASE_READY` разрешён только после fresh exact-HEAD CI,
PostgreSQL qualification, frontend build/typecheck, Chromium E2E,
deployment/rollback/restore, live Telegram, live TON Proof, нулевого
mismatch/fallback и денежного расхождения `0.00000000`.

## 7. Запреты до закрытия 1621

- не начинать cycle `1622` до fresh exact-HEAD CI `v172.21`;
- не выполнять auto-merge при conflict;
- не создавать migration `0007` до доказанной необходимости цикла `1622`;
- не менять DDL `0003`/`0004`/`0005` без доказанного дефекта;
- не выполнять backfill/read switch/ownership switch;
- не менять CI workflow;
- не добавлять tests или `requirements-test.txt` в release archive;
- не объявлять `CYCLE_1621_PASS` до fresh exact-HEAD CI `v172.21`.
