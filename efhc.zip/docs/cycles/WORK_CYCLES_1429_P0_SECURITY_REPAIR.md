# Work cycle 1429 — P0 security repair

## Status

DONE locally; repeat security audit still required before any release-ready
claim.

## HEAD input

`EFHC_Bot_v170_03_cycle_1428_security_audit_reconciliation_plan.zip`

## Audit input

`docs/audits/P0_SECURITY_AUDIT_V170_01.md`

Verdict entering the cycle: `P0_RELEASE_BLOCKED`.

## Goal

Close the two P0 release blockers from the supplied security audit:

1. wallet binding without mandatory TonConnect proof;
2. repository-known/default `CRON_SECRET` for `/cron/tick`.

## Runtime repairs

### Wallet proof boundary

Files changed:

- `backend/app/schemas/wallet_schemas.py`;
- `backend/app/routes/wallets_routes.py`;
- `backend/app/services/wallets_service.py`;
- `backend/app/models/wallets_models.py`;
- `backend/migrations/versions/0001_initial_release_schema.py`.

Changes:

- `/wallets/connect` now requires TonConnect proof fields in the request body;
- the route calls `tonconnect_proof_service.check_proof()` before binding;
- `wallets_service.connect_wallet()` now requires
  `verified_proof_payload_token` and `verified_proof_source`;
- wallet binding rows now store proof markers:
  `proof_verified`, `proof_verified_at`, `proof_payload_hash`,
  `proof_source`;
- `require_wallet_connected()` is backed by `has_active_wallet()`, which now
  accepts only active verified bindings;
- `wallet_proof_token_uses` records single-use proof token hashes and rejects
  replay with a different idempotency key;
- 0001 fresh/create-all and existing-DB repair paths know the new proof columns.

### Cron control-plane boundary

Files changed:

- `backend/app/core/config_core.py`;
- `backend/app/routes/system_routes.py`;
- `env.prod.example`;
- `env.example`.

Changes:

- removed the working default `CRON_SECRET` from settings;
- prod/stage fail fast when `CRON_SECRET` is empty, placeholder, too short or
  equal to the legacy repository-known secret hash;
- `/cron/tick` fails closed in prod/stage when no secret exists;
- local/dev/ci may keep an empty cron secret for development;
- `env.prod.example` now contains only a placeholder cron secret.

## Guards / tests

Added:

- `tests/architecture/test_security_p0_repair_guards.py`.

Protected meanings:

- `/wallets/connect` cannot bind a naked address without proof;
- wallet-gated money routes require verified wallet bindings;
- TonConnect proof replay is blocked by a single-use token marker;
- `CRON_SECRET` has no working default;
- prod/stage startup must fail on unsafe cron secret values;
- `/cron/tick` compares only against the ENV-provided secret.

Updated runtime wallet tests:

- `tests/test_wallets_connect_hardening.py`;
- `tests/wallets_ton_testkit.py`.

## Documents updated

- `docs/security/P0_SECURITY_REPAIR_CANON.md`;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`;
- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`;
- `docs/SSOT/ssot_pack/SSOT_TABLES_PURPOSE_RU.md`;
- `HEALER_ATLAS.md`;
- `docs/healer/HEALER_ATLAS.md`;
- `docs/healer/HEALER_CASEBOOK.md`;
- `atlas.json`;
- `casebook.json`;
- `map_element.md`;
- `ops/operator_kernel/cache/file_map.json`.

## Sandbox use

Песочница used only as reference/navigation layer through `map_element.md`.
No sandbox runtime, CI files, lock files, wallet/payment donor logic, secrets,
configs, economics or translations were imported.

## Non-claims

This cycle does not claim:

- repeat security audit passed;
- release-ready;
- GitHub CI green;
- full pytest green;
- frontend build green;
- browser screenshots;
- live Telegram proof;
- real wallet proof in a Telegram client.

## Next cycle

`1430` — close P2 replay / OPSEC / legacy header findings.
