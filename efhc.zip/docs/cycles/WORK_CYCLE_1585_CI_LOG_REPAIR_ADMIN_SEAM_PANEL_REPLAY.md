# Cycle 1585 — CI log repair: Admin seam and panel replay

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED
Input HEAD: `EFHC_Bot_v171_81.zip`
Output HEAD: `EFHC_Bot_v171_82.zip`

## Evidence

Development CI reported four pytest failures, eight Ruff failures and three
frontend TypeScript errors. Release CI reported three Ruff failures and the same
three frontend errors. Mypy, Bandit, Alembic and the release pytest profile were
green in the supplied runs.

## Root causes

1. The Admin withdrawal validator generator omitted fields and the
   outcome-preview parser consumed by the frontend.
2. Panel activation evaluated current balance before resolving a completed
   idempotent request, so exact-balance replay failed after the first debit.
3. Performance-budget version literals, imports, variable names and executable
   source line lengths were not synchronized with the exact CI contracts.

## Repair

- Rebuilt the complete generated Admin withdrawal contract from its generator.
- Moved panel replay read-through before state-dependent balance and limit
  checks; mismatched or incomplete replay evidence fails closed.
- Synchronized active version literals to `v171.82` and repaired exact Ruff and
  line-length failures.
- Added regression guards for both generated-contract completeness and replay
  ordering.

## Unchanged

Referral EFHCb economics, immutable first-creation attribution, panel price,
financial settlement rules, database schema, Alembic head, canonical UI,
six-button navigation and 13 locales were not changed.

## Proof boundary

Targeted local tests and archive checks do not replace fresh exact-HEAD GitHub
CI. Frontend production build and PostgreSQL replay integration must execute in
that CI environment.
