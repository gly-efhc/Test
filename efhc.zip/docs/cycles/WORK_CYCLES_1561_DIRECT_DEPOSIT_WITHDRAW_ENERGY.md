# Cycle 1561 — funding correction, Withdraw and Energy

Status: `DONE_LOCALLY_WITH_OPERATOR_VISUAL_OPEN`.

## Required correction

The `v171.35` Direct Deposit implementation was incorrect. It accepted
native TON, applied pricing and credited EFHCm. Its former verification
status is revoked.

The active canon is now:

- `Прямое пополнение`: direct EFHC jetton transfer to EFHCm;
- `Пополнение`: HUB opens Browser Shop purchase for TON/GRAM or USDT.

## Completed implementation

- direct EFHC jetton TEP-74 transaction builder;
- backend EFHC master, decimals and memo metadata;
- watcher rejects non-EFHC assets for direct deposit;
- exact EFHCj to EFHCm credit quantity;
- Browser Shop TON/GRAM and USDT methods;
- Withdraw React Query create, cancel, detail, status and history;
- Energy exact progress and eight-decimal generation rates;
- public browser interaction and responsive screenshots.

## Proof boundary

Public visual proof is established. Admin Withdraw code, routes and
operator actions are statically and unit protected, but a new admin
browser screenshot was not obtained on the managed Chromium host.

Fresh CI, live Telegram, real jetton transactions and payout are not
claimed.
