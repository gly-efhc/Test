## v168_23 detailed plan update

1206 is now a mixed visual repair cycle:

1. Profile language selector correction.
2. Browser-Shop pay button TonConnect transaction flow.
3. Reference visual sandbox intake.

The Dragon/Web3 reference is not a functional donor.  It is a visual
orientation donor only.  EFHC keeps all functions, routes, balances,
economics and canonical buttons.

Detailed next cycles:

- 1207: prove payment status road after wallet send.
- 1208: introduce desktop browser shell plan for standalone PC launch.
- 1209: define EFHC visual token system for bars, cards and buttons.
- 1210: run public UI forbidden-term guard across shop, HUB and deposit.
- 1211: apply first game-like progress bar pass to the main page.
- 1212: apply visual card polish to Panels and Exchange without changing
  business logic.

# WORK CYCLES 1196-1230 DETAILED PLAN

Status: active detailed plan after v168_18.
Created because the user added a direct profile language repair task
inside the visual frontend range.

## Rule

Cycles remain repair containers, not a release-readiness claim.  If a
later audit finds a higher blocker, the order may be remapped, but the
reason must be written in the change report.

## Completed in v168_18

### 1196 — profile language runtime repair

Problem:
- Profile language choice was stored, but the public UI dictionary was
  still loaded from English for runtime labels.
- The app could persist default settings before stored settings were
  loaded.

Repair:
- Load the selected locale dictionary through `loadDict(lang)` for UI
  labels and descriptions.
- Keep Russian as fallback dictionary.
- Add `settingsHydrated` so default settings are not saved before real
  settings load finishes.
- Keep bottom navigation labels locked in English by component-level
  labels.

Evidence:
- `frontend/src/pages/app.tsx`
- `frontend/src/components/Layout.tsx`
- `frontend/src/hooks/useT.ts`

### 1197 — profile language selector guard

Problem:
- The profile used a grid of language pills, while the user requested a
  language bar.
- There was no architecture guard proving that language switching drives
  runtime UI labels.

Repair:
- Replace the profile language grid with a horizontal language bar.
- Add listbox/option semantics and active language state.
- Add CSS for the scrollable language bar.
- Add an architecture guard for dictionary loading, hydration safety,
  language-bar markup and English bottom menu canon.

Evidence:
- `frontend/src/components/ProfileModal.tsx`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_profile_language_switch_guard.py`

## Completed in v168_19

### 1198 — clean Direct Deposit modal

Problem:
- Public Direct Deposit still used shop-launcher truth and could route
  the user into the browser shop.

Repair:
- Rewrote `DepositModal.tsx` as a clean direct deposit modal.
- Changed the GlobalHeader direct deposit action to the canonical `+`.
- Added all active locale keys for the new direct deposit copy.

Evidence:
- `frontend/src/components/DepositModal.tsx`
- `frontend/src/components/GlobalHeader.tsx`
- `tests/architecture/test_direct_deposit_guard.py`

### 1199 — Direct Deposit backend contract

Problem:
- The existing `/deposit/efhc` road expects package purchase input.

Repair:
- Added `POST /deposit/direct-open` for a separate wallet-open road.
- Added `DirectDepositOpenOut`.
- Bound memo to authenticated `global_id` through `build_deposit_memo()`.
- Updated route SSOT CSV layers.

Evidence:
- `backend/app/routes/deposit_routes.py`
- `backend/app/schemas/deposit_schemas.py`
- `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`
- `reports/generated/direct_deposit_repair_1198_1199.json`

## Remaining active cycles

### 1200 — bridge verdict

Goal:
- Write corrected 1176-1200 verdict without release-readiness claim if
  visual blockers remain.

Evidence focus:
- completed fixes versus remaining blockers.

### 1201 — backend direct deposit endpoint finalization

Goal:
- Finalize endpoint/payload contract for direct deposit wallet-open
  flow.

### 1202 — frontend wallet-open direct deposit

Goal:
- Use internal wallet transaction payload without exposing technical
  payload fields to the user.

### 1203 — Direct Deposit public guard

Goal:
- Add guard for forbidden public Direct Deposit elements.

### 1204 — clean HUB public screen

Goal:
- Public HUB shows only HUB title or icon plus two actions:
  `Пополнить EFHC` and `EFHC VIP NFT`.

### 1205 — move HUB diagnostics

Goal:
- Move HUB diagnostics to admin diagnostics or admin components.

### 1206 — HUB public guard

Goal:
- Guard exactly two actions and no public technical terms.

### 1207 — browser-shop layout exception

Goal:
- Remove Mini App GlobalHeader and bottom nav from `/browser-shop`.

### 1208 — storefront top area

Goal:
- Add avatar, balance and Profile button to storefront top area.

### 1209 — storefront product card cleanup

Goal:
- Public product cards show only title, EFHC quantity, price,
  description and `Оплатить`.

### 1210 — remove admin fields from public cards

Goal:
- No SKU, code, item_type, status, internal category, intent id or
  order id in public card rendering.

### 1211 — remove first-stage custom amount/search/filters

Goal:
- Keep first-stage storefront to approved admin-created cards only.

### 1212 — Pay opens wallet immediately

Goal:
- Product `Оплатить` creates payment and opens TON wallet.
- Amount and memo are already embedded.

### 1213 — wallet-open failure copy

Goal:
- Show only a simple user message if wallet opening fails.

### 1214 — opened-but-unpaid wallet state

Goal:
- No pressure, duplicate prompts or technical details when user opens
  wallet and does not pay.

### 1215 — human payment statuses

Goal:
- Public payment statuses use human language only.

### 1216 — move Browser-Shop diagnostics

Goal:
- Remove public payment diagnostics from Browser-Shop and keep them in
  admin/operator layers.

### 1217 — expand admin diagnostics

Goal:
- One operator entry for HUB, Shop, Deposit, endpoint health, status and
  payment chain diagnostics.

### 1218 — protect admin shop source

Goal:
- Keep `/admin/shop` as source for active public product cards.

### 1219 — public forbidden-term guard

Goal:
- Guard public HUB, DepositModal and BrowserShopPage strings.

### 1220 — public card field guard

Goal:
- Guard that admin fields are not rendered in storefront cards.

### 1221 — browser-shop layout guard

Goal:
- Guard that Browser-Shop does not use common Mini App shell.

### 1222 — tonconnect_tx public-render guard

Goal:
- Prove `tonconnect_tx` stays internal and never appears as public text.

### 1223 — route/contract split guard

Goal:
- Direct Deposit and Storefront payment remain separate roads.

### 1224 — frontend/backend visual call matrix

Goal:
- Enforce canonical frontend calls after visual cleanup.

### 1225 — contract tests repair

Goal:
- Restore postponed contract-test work for visual and economic roads.

### 1226 — HUB smoke path

Goal:
- Smoke path: Home -> HUB -> storefront and VIP link.

### 1227 — Direct Deposit smoke path

Goal:
- Smoke path: plus -> clean modal -> wallet-open attempt.

### 1228 — storefront smoke path

Goal:
- Smoke path: card -> Pay -> wallet-open attempt -> profile/history
  contract.

### 1229 — SSOT/NORM/report sync

Goal:
- Update route matrix, SSOT, NORM, Healer and reports after repairs.

### 1230 — visual evidence audit

Goal:
- Separate proven visual repairs, remaining blockers and not-ready
  claims.

## v168_20 detailed status update

### 1200 — bridge verdict completed

Result:
- The bridge verdict explicitly says the range is not release-ready.
- Direct Deposit is repaired, but Browser-Shop and storefront cleanup
  still require code work and proof.

### 1201 — HUB public cleanup completed

Result:
- Public HUB now has exactly two action cards.
- Operator/payment diagnostics no longer render in the public HUB.
- HUB technical references are visible only in admin diagnostics.
- A guard locks the public HUB boundary.

### Next detailed steps

1202 should start Browser-Shop layout separation or, if a browser proof
is available, verify the repaired Direct Deposit and HUB surfaces first.
If no browser runtime is available, continue with source-level cleanup
of Browser-Shop public UI blockers.

## v168_21 remap after cycles 1202-1203

Cycles 1202-1203 are complete for their specific findings:
Browser-Shop now has a route-based dedicated `ShopLayout`, and the
storefront top zone shows avatar, EFHC balance and Profile link.  The
main Q/A register now contains all 100 visual answers.

Remaining immediate blockers:

- clean storefront product cards;
- hide SKU/code/item_type/status and technical IDs;
- remove public wallet/memo/copy blocks;
- move Browser-Shop payment diagnostics to admin diagnostics;
- connect Pay to wallet-open without rendering raw `tonconnect_tx`.

## v168_22 detailed status

1204-1205 repaired Browser-Shop public content after the layout split.
The storefront no longer exposes the old diagnostic blocks or manual
payment fields.  The public card surface is now intentionally minimal.

Next detailed work:

- 1206: add Pay-button wallet-open integration using backend payment
  payload without rendering raw transaction data;
- 1207: add guard for no raw transaction payload in public UI;
- 1208: strengthen admin diagnostics for payment lifecycle review;
- 1209: smoke/guard proof for HUB -> Storefront -> Profile path;
- 1210: SSOT/NORM/report synchronization after storefront repair wave.


## v168_24 detailed status after 1207

1207 is complete for its focused finding:
Browser-Shop payment status is now polled after wallet handoff.

Next detailed direction:

- 1208: strengthen active-payment card and duplicate-payment feedback;
- 1209: add compact button feedback for disabled/tokenless actions;
- 1210: update diagnostics and frontend route/call matrix;
- 1211 onward: start compressing first-level UI surfaces into
  expandable cards and drawers while keeping all functions.

Dragon-style visual functions are planned separately for 1231-1350.

## v168_25 detailed status after 1208

1208 is complete for its focused FAQ finding:

- FAQ UI labels now use selected-language locale keys;
- FAQ remounts when `ctx.lang` changes;
- FAQ uses a compact bot-width shell;
- no canonical bottom menu buttons were changed.

Next focus:

- 1209: visible user-function inventory by page;
- 1210: classify each function as keep, move to admin, or question;
- 1211: begin Wallet subsection visual planning if approved.
