# WORK CYCLES 1189-1190 DETAILED PLAN

## Purpose

This mini-plan repairs two audit findings from the road integrity audit:
exchange economic road drift and panel activation economic road drift.
The goal is not to add more paperwork.  The goal is to reduce duplicate
or unsafe user-facing roads and make each money road use the current
authenticated user as the source of truth.

## Cycle 1189 - exchange economic road repair

Problem:

- exchange routes used path global_id;
- frontend generated seams also carried path global_id;
- the user route still contained an old exchange preview alias;
- this looked as if a caller could choose a user by URL.

Fix:

- make `/exchange/preview` the canonical preview route;
- make `/exchange/convert` the canonical conversion route;
- make `/exchange/history` the canonical history route;
- remove `/user/{global_id}/exchange/preview` from active backend code;
- update frontend generated exchange seams;
- update the exchange page to call the self routes;
- update OpenAPI and route SSOT packs for the active paths;
- add a guard proving old path global_id exchange aliases are gone.

Release boundary:

This closes only the exchange route drift and evidence guard for the
exchange road.  It does not declare all roads release-ready.

## Cycle 1190 - panel activation economic road repair

Problem:

- panel activation used `/panels/activate/{global_id}`;
- `/panels/buy/{global_id}` existed as a compatibility alias;
- the route shape still looked path-selected instead of self-user;
- the activation audit meta did not expose all bonus-first proof fields.

Fix:

- make `/panels/activate` the canonical activation route;
- remove the active `/panels/buy/{global_id}` compatibility alias;
- update frontend activation call to `/panels/activate`;
- update OpenAPI and route SSOT packs;
- add bonus-first audit meta fields:
  - `qty`;
  - `price_per_panel`;
  - `total_amount`;
  - `spent_bonus`;
  - `spent_main`;
  - `bonus_first`;
- add a guard proving route, frontend, OpenAPI, SSOT and audit anchors.

Release boundary:

This closes only the panel activation route and audit-proof drift.  It
does not declare every panel, frontend or table road release-ready.
