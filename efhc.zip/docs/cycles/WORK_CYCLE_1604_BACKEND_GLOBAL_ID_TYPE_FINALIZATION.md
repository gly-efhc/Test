# Рабочий цикл 1604 — Backend GlobalId type finalization

Исходный HEAD: `EFHC_Bot_v172_00.zip`.
Целевой HEAD: `EFHC_Bot_v172_01.zip`.

## Цель

Убрать legacy `UserId` из канонического backend production API,
сохранив контролируемую совместимость с физической колонкой
`users.user_id` и историческими инструментами.

## Выполнено

1. `types.py` содержит только `GlobalId` и `TelegramId`.
2. `api_contract.py` содержит только канонические Global ID DTO.
3. `app.identity` не экспортирует legacy type names.
4. LEGACY API перенесён в `app.identity.legacy_user_id`.
5. Backfill harness использует `GlobalId` внутри Python-кода.
6. Добавлены явные database/provider conversion boundaries.
7. Добавлены стабильные коды `global_id.*` и `global_id.*`.
8. Добавлен fail-closed architecture guard и причинные тесты.
9. Operator Kernel получил отдельный маршрут цикла 1604.

## Не изменялось

- Alembic head `0002`;
- физическая колонка `users.user_id`;
- runtime primary key `users.id`;
- balances, kWh, panels и финансовая логика;
- historical backfill, dual-write и read switch;
- AuthContext, sessions, TON Proof и Telegram adapter.

## Следующий цикл

`1605 — Frontend GlobalId string system`.

## Итог тестирования

`2870` собрано, `2698` пройдено, `172` пропущено,
`0` падений, `0` ошибок. PostgreSQL и Chromium skips не являются
доказательством выполнения соответствующих контуров.
