## v168_23 cycle 1206 update

Cycle 1206 result:

- fixed profile language dropdown UX;
- re-checked the language route: `loadDict(lang)` remains the runtime UI
  dictionary path;
- preserved English bottom navigation canon;
- connected Browser-Shop pay action to internal TonConnect transaction
  sending;
- imported reference sandbox observations into the visual planning
  layer.

Next focus:

- 1207: payment status polling and active payment card proof;
- 1208: browser shell design plan and first PC-friendly route shell;
- 1209: game-like progress bars and button system plan;
- 1210: screenshot/browser proof pass if environment allows it.

# WORK CYCLES 1195-1230 VISUAL FIX PLAN

Status: active plan after visual audit v002.
HEAD at creation: v168_16 cycles 1193-1194.

## Planning verdict

The new visual audit changes the priority for cycle 1195. The old
contract-test repair remains required, but public visual blockers are
now higher priority because current HEAD still exposes diagnostic and
shop-launcher layers in user roads.

Cycles are not closed by this plan. Each cycle needs real code or
guard changes, focused checks, a report and archive verification.

## Cycle list

### Cycle 1195

- Goal: Import visual audit, create audit-of-audit, freeze public UI
  NORM and remap 1195-1230 priorities.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1196

- Goal after v168_18 remap: repair profile language runtime because the
  user explicitly found that languages do not switch.
- Result: selected language now loads the runtime UI dictionary through
  `loadDict(lang)`, and settings persistence waits for hydration.
- Evidence: code change, TypeScript check and guard test.

### Cycle 1197

- Goal after v168_18 remap: make profile language selection a bar and
  guard the fixed behavior.
- Result: profile now has a horizontal language bar; bottom navigation
  remains locked in English; guard test added.
- Evidence: `test_profile_language_switch_guard.py`, targeted
  pytest and TypeScript check.

### Cycle 1198

- Goal: Create clean Direct Deposit modal/window. Remove shop-launcher
  truth, active intent and wallet/memo/copy blocks from public modal.
- Result: completed in v168_19 for the specific public modal finding.
- Evidence: `DepositModal.tsx`, `GlobalHeader.tsx`, locale files and
  `test_direct_deposit_guard.py`.
- Not claimed: browser screenshot proof and GitHub CI.

### Cycle 1199

- Goal: Backend Direct Deposit road design. Prove free amount memo-based
  wallet-open flow without package purchase coupling.
- Result: completed in v168_19 by adding `POST /deposit/direct-open`.
- Evidence: `deposit_routes.py`, `deposit_schemas.py`, SSOT route CSVs
  and `test_direct_deposit_guard.py`.
- Not claimed: runtime OpenAPI export, because local dependency
  `sqlalchemy` was missing.

### Cycle 1200

- Goal: Corrected 1176-1200 bridge verdict. Do not close release range
  if visual blockers remain.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1201

- Goal: Implement or finalize backend direct deposit endpoint and
  payload contract with memo tied to authenticated tg_id.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1202

- Goal: Add Direct Deposit frontend wallet-open integration using
  internal TonConnect payload without exposing tonconnect_tx.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1203

- Goal: Add Direct Deposit guard proving no package cards, shop
  launcher, endpoint, intent, watcher or manual copy blocks in public
  modal.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1204

- Goal: Clean HUB public screen to two actions only. Preserve VIP URL
  and language rules.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1205

- Goal: Move HUB diagnostic blocks to admin diagnostics or admin
  components with one operator entry.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1206

- Goal: Add HUB guard proving exactly two public actions and no
  forbidden technical terms.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1207

- Goal: Create ShopLayout or route-based layout exception for
  browser-shop. Remove Mini App bottom navigation and GlobalHeader from
  storefront.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1208

- Goal: Create storefront top area with avatar, balance and Profile
  button, using public names only.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1209

- Goal: Clean storefront product cards. Show title, EFHC quantity,
  price, description and Pay only.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1210

- Goal: Remove SKU, code, item_type, status, endpoint, intent id, order
  id and internal category from public storefront cards.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1211

- Goal: Remove public custom amount, search and filters for first-stage
  storefront unless backed by approved active product design.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1212

- Goal: Wire product Pay button to create payment and open TON wallet
  immediately with amount and memo embedded.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1213

- Goal: Add simple wallet-open failure UX: Ne udalos otkryt koshelek.
  Poprobuyte snova.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1214

- Goal: Ensure opened-but-unpaid wallet flow does not show pressure or
  technical duplicate prompts.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1215

- Goal: Clean public payment status language: waiting, checking,
  completed and error as human messages.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1216

- Goal: Move Browser-Shop payment diagnostics to admin diagnostics and
  backend/operator logs.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1217

- Goal: Expand admin/diagnostics with HUB, Shop, Deposit, endpoint
  health, status and payment chain diagnostics.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1218

- Goal: Keep admin/shop card management intact and verify active public
  cards come from admin catalog.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1219

- Goal: Add public UI forbidden-term guard across HUB, DepositModal and
  BrowserShopPage user strings.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1220

- Goal: Add public card field guard proving no admin fields are rendered
  in storefront cards.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1221

- Goal: Add layout guard proving browser-shop does not use Mini App
  Layout or bottom nav.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1222

- Goal: Add wallet-flow guard proving tonconnect_tx is internal and not
  rendered as public text.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1223

- Goal: Add route/contract guard proving Direct Deposit is not package
  purchase and storefront remains product purchase.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1224

- Goal: Frontend/backend call matrix enforcement for visual roads after
  component cleanup.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1225

- Goal: Contract tests repair for repaired visual roads and previously
  repaired economic roads.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1226

- Goal: Smoke test HUB path: Home to HUB to storefront and VIP link
  without diagnostics.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1227

- Goal: Smoke test Direct Deposit path: plus to clean modal to
  wallet-open attempt and simple failure handling.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1228

- Goal: Smoke test storefront path: product card to Pay to wallet-open
  attempt and profile/history outcome contract.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1229

- Goal: Update SSOT, API contracts, road matrix, Healer and reports
  after visual road repairs.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1230

- Goal: Visual release evidence audit. Separate proven repairs,
  remaining blockers and not-release-ready claims.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.


## v168_18 detailed plan link

The detailed continuation plan is fixed in:
`docs/cycles/WORK_CYCLES_1196-1230_DETAILED_PLAN.md`.

## v168_20 cycles 1200-1201 update

### Cycle 1200 result

The corrected 1176-1200 bridge verdict was recorded.  It does not close
release readiness.  Visual blockers outside Direct Deposit remain open.

### Cycle 1201 result

The public HUB was cleaned to the approved two-action user screen.
The page now renders only:

- Top up EFHC;
- EFHC VIP NFT.

Technical HUB diagnostics were moved into `/admin/diagnostics`, and a
new architecture guard proves the public HUB boundary.

The older verification-only meaning of 1201 was superseded because the
next highest safe code repair was the public HUB blocker.

## v168_21 remap after cycles 1202-1203

Cycles 1202-1203 are complete for their specific findings:
Browser-Shop now has a route-based dedicated `ShopLayout`, and the
storefront top zone shows avatar, EFHC balance and Profile link.  The
main Q/A register now contains all 100 visual answers.

Remaining immediate blockers:

- clean storefront product cards;
- hide SKU/code/item_type/status and technical IDs;
- remove public wallet/memo/copy blocks;
- move Browser-Shop payment diagnostics to admin diagnostics;
- connect Pay to wallet-open without rendering raw `tonconnect_tx`.

## v168_22 result after cycles 1204-1205

Cycles 1204-1205 are complete for their specific findings.

- Browser-Shop public product cards were cleaned to public-facing
  title, description, price and Pay action.
- SKU, Type, USDT jetton row, wallet, memo, copy buttons and payment
  chain facts were removed from the public storefront.
- Browser-Shop payment diagnostics were moved to `/admin/diagnostics`.

Remaining immediate blockers:

- Pay must open TON wallet immediately with embedded amount and memo;
- raw `tonconnect_tx` must stay internal and never be rendered;
- browser screenshot proof is still absent;
- full GitHub CI proof is still absent.


## v168_24 cycle 1207 result

Cycle 1207 completed the next Browser-Shop payment road proof.

- The public Pay flow keeps an active intent id.
- The page polls `/shopfront/intent-status` while the payment is pending
  or checking.
- Confirmed payment becomes a completed human state.
- Expired or canceled payment becomes a user-facing error state.
- Raw payment internals remain hidden from the public JSX.

A route diagnosis was also added.  Current page-level frontend links are
not globally broken.  The button problem is now classified as UX and
state-feedback debt, not as a global route outage.

### Cycle 1208 completed

FAQ language and layout repair.

Result:

- hardcoded English FAQ quick-link labels moved to locale keys;
- FAQ follows `ctx.lang` and remounts on language change;
- FAQ got a compact bot-width shell for Mini App simulation size;
- locale keys were added to all active language JSON files;
- frontend compression answers were recorded.

Evidence:

- `docs/audits/FAQ_LANGUAGE_LAYOUT_REPAIR_1208.md`;
- `docs/audits/FRONTEND_COMPRESSION_ANSWERS_1208.md`;
- `tests/architecture/test_faq_language_layout_guard.py`.

Not claimed:

- full browser click-proof;
- full rewrite of all historical FAQ answers;
- release readiness of the entire visual frontend.

Additional 1208 diagnosis:

`docs/audits/FRONTEND_BUTTON_ROUTE_DIAGNOSIS_1208.md` records that
static route references are not globally broken.  The likely issue is
state-gated or artifact buttons without clear feedback.

## Cycle 1209 correction

After the user's answers, the plan is corrected:

- first screen remains Energy;
- six bottom buttons stay canonical;
- compression happens inside pages;
- visible functions must be audited before removal;
- Dragon style is visual only;
- Browser-Shop remains the Web3-style page through HUB;
- browser/PWA shell is allowed as a parallel runtime.

Detailed plan is now in:

`docs/cycles/WORK_CYCLES_1209-1230_DETAILED_PLAN.md`.
