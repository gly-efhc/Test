# WORK CYCLE 1188 DETAILED PLAN

## Purpose

Cycle 1188 repairs the deposit and watcher truth road.  The goal is not
just to prove that files exist.  The goal is to make the user-facing
status route fail cleanly and to keep watcher evidence connected to the
payment-intent outcome.

## Context from 1187

Cycle 1187 changed withdraw list semantics.  Before the repair, a user
list route could be read as "show withdrawals for global_id from query".
After the repair it means "show withdrawals for the authenticated user".
The optional `global_id` query value remains only as a legacy
self-check.  It must match the authenticated user and cannot select
another account.

## Why that matters

For money roads the user identity must come from auth.  Query or path
values are allowed only as compatibility checks.  This prevents a false
road where a UI parameter looks like it can control another user's
financial data.

## Cycle 1188 checklist

- deposit creation uses auth `global_id`;
- deposit creation requires connected wallet and idempotency key;
- payment intent payload carries purpose, intent id and owner `global_id`;
- watcher parses intent payload before legacy memo logic;
- watcher blocks unsupported transport before confirm;
- reconciliation checks exact asset, destination and amount;
- reconciliation locks `tx_hash` before credit;
- reconciliation commits confirmed intent and credit outcome;
- status route is owner-only;
- missing intent returns 404 instead of leaking service sentinel data;
- API contract documents the status route and `flow_truth`.

## Result expected

The cycle may be closed only if code, guard, test, contract, matrix and
report agree on the same deposit/watcher road.
