# Циклы 1636–1640 — регистрация и global_id ownership

## Общая цель

Создать один центр регистрации аккаунта для Telegram Bot, Telegram
WebApp, browser/PWA и TON. После этого завершить фактический переход
бизнес-логики на `global_id`.

Основание:

- `docs/NORM/TZ/TZ_account_registration_service.md`;
- `docs/NORM/TZ/TZ_global_id_migration.md`;
- фактический Current HEAD `v172.56`;
- канон первичной неизменяемой реферальной принадлежности.

## Канонические решения

1. Строка `efhc_core.users` для нового аккаунта создаётся только через
   `AccountRegistrationService`.
2. `PostgreSQLIdentityResolver` не переписывается: он продолжает
   определять, существует ли аккаунт или provider identity.
3. Реферальная принадлежность создаётся только в транзакции первого
   создания аккаунта.
4. Неверный или несуществующий реферальный код блокирует создание
   аккаунта. Это сохраняет действующий fail-closed канон.
5. Существующий пользователь никогда не может получить или сменить
   inviter.
6. `tg_id` сохраняется как provider-атрибут и канал уведомлений, но не
   является владельцем бизнес-данных.
7. После цикла 1640 операции пользователя должны работать по
   `global_id` без обязательного Telegram-аккаунта.


## Текущий implementation status v172.56

Циклы `1636–1638` квалифицированы. Цикл `1639` реализован во всех provider
callers. Fresh CI exact `v172.55` подтвердил `3219 passed`, но один
cross-provider qualification fixture нарушал ожидаемый порядок SQLAlchemy
flush: INSERT `ReferralCode` мог уйти до UPDATE нового `users.global_id`.

Corrective `v172.56`:

- не меняет production registration code;
- явно flush-ит UPDATE provider attribute в test fixture;
- сохраняет FK `referral_codes_inviter_global_id_fkey`;
- сохраняет canonical referral ownership через `global_id`;
- не начинает business ownership цикл `1640`.

Текущий gate:

```text
ALL_REGISTRATION_PATHS_USE_SINGLE_CENTER
PROVIDER_NEUTRAL_FIRST_REGISTRATION_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
CYCLE_1640_NOT_STARTED
```

## Цикл 1636 — ядро единой регистрации

Создать `backend/app/identity/account_registration.py`.

В цикл входят:

- `NewAccountRequest`;
- `NewAccountResult`;
- `AccountRegistrationError`;
- транзакционное создание `users`;
- единая нормализация referral start param;
- создание `referral_links` в той же транзакции;
- защита от второго владельца, self-ref и поздней привязки;
- модульные и PostgreSQL-контракты ядра.

Вызовы существующих трёх путей пока не переключаются.

## Цикл 1637 — Telegram Bot через общий центр

Перевести `onboard_user_at_first_creation()` на
`AccountRegistrationService`.

Дополнительно:

- бот-регистрация сразу создаёт `UserIdentity`;
- сохраняется поведение `0 user`;
- invalid code не создаёт пользователя;
- старые referral runtime tests должны пройти без изменения смысла;
- прямой `INSERT INTO efhc_core.users` удаляется из bot onboarding.

## Цикл 1638 — единый referral ingress

Добавить provider-независимую передачу referral start param:

- Telegram WebApp auth API;
- TON auth API;
- browser/PWA first-entry capture;
- хранение до логина только в `sessionStorage`;
- одноразовое потребление после успешной регистрации;
- отсутствие позднего bind для уже существующего аккаунта.

В этом цикле новые provider-пути ещё не создают пользователя через общий
сервис: подготавливается безопасный transport contract.

## Цикл 1639 — Telegram WebApp и TON через общий центр

Перевести:

- `TelegramAuthSessionService`;
- `TonAccountRegistrationService`;

на `AccountRegistrationService`.

Exit gate:

- три прежних независимых пути создания `users` устранены;
- direct creation вне общего сервиса запрещён guard;
- `existing_legacy_account` не создаёт дубликат;
- bot/WebApp/TON дают одинаковую referral row;
- межпровайдерный referral cycle невозможен;
- один provider failure не оставляет частично созданный аккаунт.

## Цикл 1640 — закрытие global_id бизнес-владения

Внутри одного интегрированного цикла выполнить этапы по зависимостям:

1. общий `OwnerKey`/owner resolver;
2. `transactions_service.py`;
3. panels, withdrawals и payment intents;
4. referrals;
5. tasks, ranks и wallets;
6. achievements и оставшиеся таблицы;
7. routes и bot handlers.

Обязательные результаты:

- бизнес-операции принимают `global_id`;
- idempotency строится на одном canonical owner;
- вызов по `global_id` и `global_id` одного аккаунта не создаёт два следа;
- `achievements` получает `global_id` в единой migration `0001`;
- `tg_id` становится nullable provider-атрибутом там, где Telegram не
  обязателен;
- browser/APK/TON пользователь может пользоваться панелями, обменом,
  выводом, заданиями, рангами и кошельками без Telegram;
- старые compatibility-входы удаляются после перевода вызывающих мест.

## Состояние после цикла 1640

Плановый результат:

```text
ONE_ACCOUNT_REGISTRATION_CENTER
GLOBAL_ID_BUSINESS_OWNER
TELEGRAM_OPTIONAL_PROVIDER
NO_LATE_REFERRAL_BIND
CROSS_PROVIDER_REGISTRATION_EQUIVALENCE
```

Циклы 1636–1639 реализованы; цикл 1640 не начат.
