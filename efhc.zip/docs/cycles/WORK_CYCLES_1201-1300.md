# EFHC — ЦИКЛЫ 1201–1300
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.
Исторические записи ниже перенесены без назначения им статуса active authority; active authority определяется текущим WORK_PLAN/SSOT/NORM/CANON.

---

## Источник: `WORK_CYCLES_1195-1230_VISUAL_FIX_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

## v168_23 cycle 1206 update

Cycle 1206 result:

- fixed profile language dropdown UX;
- re-checked the language route: `loadDict(lang)` remains the runtime UI
  dictionary path;
- preserved English bottom navigation canon;
- connected Browser-Shop pay action to internal TonConnect transaction
  sending;
- imported reference sandbox observations into the visual planning
  layer.

Next focus:

- 1207: payment status polling and active payment card proof;
- 1208: browser shell design plan and first PC-friendly route shell;
- 1209: game-like progress bars and button system plan;
- 1210: screenshot/browser proof pass if environment allows it.

# WORK CYCLES 1195-1230 VISUAL FIX PLAN

Status: active plan after visual audit v002.
HEAD at creation: v168_16 cycles 1193-1194.

## Planning verdict

The new visual audit changes the priority for cycle 1195. The old
contract-test repair remains required, but public visual blockers are
now higher priority because current HEAD still exposes diagnostic and
shop-launcher layers in user roads.

Cycles are not closed by this plan. Each cycle needs real code or
guard changes, focused checks, a report and archive verification.

## Cycle list

### Cycle 1195

- Goal: Import visual audit, create audit-of-audit, freeze public UI
  NORM and remap 1195-1230 priorities.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1196

- Goal after v168_18 remap: repair profile language runtime because the
  user explicitly found that languages do not switch.
- Result: selected language now loads the runtime UI dictionary through
  `loadDict(lang)`, and settings persistence waits for hydration.
- Evidence: code change, TypeScript check and guard test.

### Cycle 1197

- Goal after v168_18 remap: make profile language selection a bar and
  guard the fixed behavior.
- Result: profile now has a horizontal language bar; bottom navigation
  remains locked in English; guard test added.
- Evidence: `test_profile_language_switch_guard.py`, targeted
  pytest and TypeScript check.

### Cycle 1198

- Goal: Create clean Direct Deposit modal/window. Remove shop-launcher
  truth, active intent and wallet/memo/copy blocks from public modal.
- Result: completed in v168_19 for the specific public modal finding.
- Evidence: `DepositModal.tsx`, `GlobalHeader.tsx`, locale files and
  `test_direct_deposit_guard.py`.
- Not claimed: browser screenshot proof and GitHub CI.

### Cycle 1199

- Goal: Backend Direct Deposit road design. Prove free amount memo-based
  wallet-open flow without package purchase coupling.
- Result: completed in v168_19 by adding `POST /deposit/direct-open`.
- Evidence: `deposit_routes.py`, `deposit_schemas.py`, SSOT route CSVs
  and `test_direct_deposit_guard.py`.
- Not claimed: runtime OpenAPI export, because local dependency
  `sqlalchemy` was missing.

### Cycle 1200

- Goal: Corrected 1176-1200 bridge verdict. Do not close release range
  if visual blockers remain.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1201

- Goal: Implement or finalize backend direct deposit endpoint and
  payload contract with memo tied to authenticated tg_id.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1202

- Goal: Add Direct Deposit frontend wallet-open integration using
  internal TonConnect payload without exposing tonconnect_tx.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1203

- Goal: Add Direct Deposit guard proving no package cards, shop
  launcher, endpoint, intent, watcher or manual copy blocks in public
  modal.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1204

- Goal: Clean HUB public screen to two actions only. Preserve VIP URL
  and language rules.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1205

- Goal: Move HUB diagnostic blocks to admin diagnostics or admin
  components with one operator entry.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1206

- Goal: Add HUB guard proving exactly two public actions and no
  forbidden technical terms.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1207

- Goal: Create ShopLayout or route-based layout exception for
  browser-shop. Remove Mini App bottom navigation and GlobalHeader from
  storefront.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1208

- Goal: Create storefront top area with avatar, balance and Profile
  button, using public names only.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1209

- Goal: Clean storefront product cards. Show title, EFHC quantity,
  price, description and Pay only.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1210

- Goal: Remove SKU, code, item_type, status, endpoint, intent id, order
  id and internal category from public storefront cards.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1211

- Goal: Remove public custom amount, search and filters for first-stage
  storefront unless backed by approved active product design.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1212

- Goal: Wire product Pay button to create payment and open TON wallet
  immediately with amount and memo embedded.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1213

- Goal: Add simple wallet-open failure UX: Ne udalos otkryt koshelek.
  Poprobuyte snova.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1214

- Goal: Ensure opened-but-unpaid wallet flow does not show pressure or
  technical duplicate prompts.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1215

- Goal: Clean public payment status language: waiting, checking,
  completed and error as human messages.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1216

- Goal: Move Browser-Shop payment diagnostics to admin diagnostics and
  backend/operator logs.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1217

- Goal: Expand admin/diagnostics with HUB, Shop, Deposit, endpoint
  health, status and payment chain diagnostics.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1218

- Goal: Keep admin/shop card management intact and verify active public
  cards come from admin catalog.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1219

- Goal: Add public UI forbidden-term guard across HUB, DepositModal and
  BrowserShopPage user strings.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1220

- Goal: Add public card field guard proving no admin fields are rendered
  in storefront cards.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1221

- Goal: Add layout guard proving browser-shop does not use Mini App
  Layout or bottom nav.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1222

- Goal: Add wallet-flow guard proving tonconnect_tx is internal and not
  rendered as public text.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1223

- Goal: Add route/contract guard proving Direct Deposit is not package
  purchase and storefront remains product purchase.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1224

- Goal: Frontend/backend call matrix enforcement for visual roads after
  component cleanup.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1225

- Goal: Contract tests repair for repaired visual roads and previously
  repaired economic roads.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1226

- Goal: Smoke test HUB path: Home to HUB to storefront and VIP link
  without diagnostics.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1227

- Goal: Smoke test Direct Deposit path: plus to clean modal to
  wallet-open attempt and simple failure handling.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1228

- Goal: Smoke test storefront path: product card to Pay to wallet-open
  attempt and profile/history outcome contract.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1229

- Goal: Update SSOT, API contracts, road matrix, Healer and reports
  after visual road repairs.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.

### Cycle 1230

- Goal: Visual release evidence audit. Separate proven repairs,
  remaining blockers and not-release-ready claims.
- Required evidence: code or guard change, focused local check,
  report entry and archive ZIP verification.
- Not enough: document-only proof unless the cycle is explicitly
  audit intake or planning.


## v168_18 detailed plan link

The detailed continuation plan is fixed in:
`docs/cycles/WORK_CYCLES_1196-1230_DETAILED_PLAN.md`.

## v168_20 cycles 1200-1201 update

### Cycle 1200 result

The corrected 1176-1200 bridge verdict was recorded.  It does not close
release readiness.  Visual blockers outside Direct Deposit remain open.

### Cycle 1201 result

The public HUB was cleaned to the approved two-action user screen.
The page now renders only:

- Top up EFHC;
- EFHC VIP NFT.

Technical HUB diagnostics were moved into `/admin/diagnostics`, and a
new architecture guard proves the public HUB boundary.

The older verification-only meaning of 1201 was superseded because the
next highest safe code repair was the public HUB blocker.

## v168_21 remap after cycles 1202-1203

Cycles 1202-1203 are complete for their specific findings:
Browser-Shop now has a route-based dedicated `ShopLayout`, and the
storefront top zone shows avatar, EFHC balance and Profile link.  The
main Q/A register now contains all 100 visual answers.

Remaining immediate blockers:

- clean storefront product cards;
- hide SKU/code/item_type/status and technical IDs;
- remove public wallet/memo/copy blocks;
- move Browser-Shop payment diagnostics to admin diagnostics;
- connect Pay to wallet-open without rendering raw `tonconnect_tx`.

## v168_22 result after cycles 1204-1205

Cycles 1204-1205 are complete for their specific findings.

- Browser-Shop public product cards were cleaned to public-facing
  title, description, price and Pay action.
- SKU, Type, USDT jetton row, wallet, memo, copy buttons and payment
  chain facts were removed from the public storefront.
- Browser-Shop payment diagnostics were moved to `/admin/diagnostics`.

Remaining immediate blockers:

- Pay must open TON wallet immediately with embedded amount and memo;
- raw `tonconnect_tx` must stay internal and never be rendered;
- browser screenshot proof is still absent;
- full GitHub CI proof is still absent.


## v168_24 cycle 1207 result

Cycle 1207 completed the next Browser-Shop payment road proof.

- The public Pay flow keeps an active intent id.
- The page polls `/shopfront/intent-status` while the payment is pending
  or checking.
- Confirmed payment becomes a completed human state.
- Expired or canceled payment becomes a user-facing error state.
- Raw payment internals remain hidden from the public JSX.

A route diagnosis was also added.  Current page-level frontend links are
not globally broken.  The button problem is now classified as UX and
state-feedback debt, not as a global route outage.

### Cycle 1208 completed

FAQ language and layout repair.

Result:

- hardcoded English FAQ quick-link labels moved to locale keys;
- FAQ follows `ctx.lang` and remounts on language change;
- FAQ got a compact bot-width shell for Mini App simulation size;
- locale keys were added to all active language JSON files;
- frontend compression answers were recorded.

Evidence:

- `docs/audits/FAQ_LANGUAGE_LAYOUT_REPAIR_1208.md`;
- `docs/audits/FRONTEND_COMPRESSION_ANSWERS_1208.md`;
- `tests/architecture/test_faq_language_layout_guard.py`.

Not claimed:

- full browser click-proof;
- full rewrite of all historical FAQ answers;
- release readiness of the entire visual frontend.

Additional 1208 diagnosis:

`docs/audits/FRONTEND_BUTTON_ROUTE_DIAGNOSIS_1208.md` records that
static route references are not globally broken.  The likely issue is
state-gated or artifact buttons without clear feedback.

## Cycle 1209 correction

After the user's answers, the plan is corrected:

- first screen remains Energy;
- six bottom buttons stay canonical;
- compression happens inside pages;
- visible functions must be audited before removal;
- Dragon style is visual only;
- Browser-Shop remains the Web3-style page through HUB;
- browser/PWA shell is allowed as a parallel runtime.

Detailed plan is now in:

`docs/cycles/WORK_CYCLES_1209-1230_DETAILED_PLAN.md`.

---

## Источник: `WORK_CYCLES_1196-1230_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

## v168_23 detailed plan update

1206 is now a mixed visual repair cycle:

1. Profile language selector correction.
2. Browser-Shop pay button TonConnect transaction flow.
3. Reference visual sandbox intake.

The Dragon/Web3 reference is not a functional donor.  It is a visual
orientation donor only.  EFHC keeps all functions, routes, balances,
economics and canonical buttons.

Detailed next cycles:

- 1207: prove payment status road after wallet send.
- 1208: introduce desktop browser shell plan for standalone PC launch.
- 1209: define EFHC visual token system for bars, cards and buttons.
- 1210: run public UI forbidden-term guard across shop, HUB and deposit.
- 1211: apply first game-like progress bar pass to the main page.
- 1212: apply visual card polish to Panels and Exchange without changing
  business logic.

# WORK CYCLES 1196-1230 DETAILED PLAN

Status: active detailed plan after v168_18.
Created because the user added a direct profile language repair task
inside the visual frontend range.

## Rule

Cycles remain repair containers, not a release-readiness claim.  If a
later audit finds a higher blocker, the order may be remapped, but the
reason must be written in the change report.

## Completed in v168_18

### 1196 — profile language runtime repair

Problem:
- Profile language choice was stored, but the public UI dictionary was
  still loaded from English for runtime labels.
- The app could persist default settings before stored settings were
  loaded.

Repair:
- Load the selected locale dictionary through `loadDict(lang)` for UI
  labels and descriptions.
- Keep Russian as fallback dictionary.
- Add `settingsHydrated` so default settings are not saved before real
  settings load finishes.
- Keep bottom navigation labels locked in English by component-level
  labels.

Evidence:
- `frontend/src/pages/app.tsx`
- `frontend/src/components/Layout.tsx`
- `frontend/src/hooks/useT.ts`

### 1197 — profile language selector guard

Problem:
- The profile used a grid of language pills, while the user requested a
  language bar.
- There was no architecture guard proving that language switching drives
  runtime UI labels.

Repair:
- Replace the profile language grid with a horizontal language bar.
- Add listbox/option semantics and active language state.
- Add CSS for the scrollable language bar.
- Add an architecture guard for dictionary loading, hydration safety,
  language-bar markup and English bottom menu canon.

Evidence:
- `frontend/src/components/ProfileModal.tsx`
- `frontend/src/styles/globals.css`
- `tests/architecture/test_profile_language_switch_guard.py`

## Completed in v168_19

### 1198 — clean Direct Deposit modal

Problem:
- Public Direct Deposit still used shop-launcher truth and could route
  the user into the browser shop.

Repair:
- Rewrote `DepositModal.tsx` as a clean direct deposit modal.
- Changed the GlobalHeader direct deposit action to the canonical `+`.
- Added all active locale keys for the new direct deposit copy.

Evidence:
- `frontend/src/components/DepositModal.tsx`
- `frontend/src/components/GlobalHeader.tsx`
- `tests/architecture/test_direct_deposit_guard.py`

### 1199 — Direct Deposit backend contract

Problem:
- The existing `/deposit/efhc` road expects package purchase input.

Repair:
- Added `POST /deposit/direct-open` for a separate wallet-open road.
- Added `DirectDepositOpenOut`.
- Bound memo to authenticated `tg_id` through `build_deposit_memo()`.
- Updated route SSOT CSV layers.

Evidence:
- `backend/app/routes/deposit_routes.py`
- `backend/app/schemas/deposit_schemas.py`
- `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`
- `reports/generated/direct_deposit_repair_1198_1199.json`

## Remaining active cycles

### 1200 — bridge verdict

Goal:
- Write corrected 1176-1200 verdict without release-readiness claim if
  visual blockers remain.

Evidence focus:
- completed fixes versus remaining blockers.

### 1201 — backend direct deposit endpoint finalization

Goal:
- Finalize endpoint/payload contract for direct deposit wallet-open
  flow.

### 1202 — frontend wallet-open direct deposit

Goal:
- Use internal wallet transaction payload without exposing technical
  payload fields to the user.

### 1203 — Direct Deposit public guard

Goal:
- Add guard for forbidden public Direct Deposit elements.

### 1204 — clean HUB public screen

Goal:
- Public HUB shows only HUB title or icon plus two actions:
  `Пополнить EFHC` and `EFHC VIP NFT`.

### 1205 — move HUB diagnostics

Goal:
- Move HUB diagnostics to admin diagnostics or admin components.

### 1206 — HUB public guard

Goal:
- Guard exactly two actions and no public technical terms.

### 1207 — browser-shop layout exception

Goal:
- Remove Mini App GlobalHeader and bottom nav from `/browser-shop`.

### 1208 — storefront top area

Goal:
- Add avatar, balance and Profile button to storefront top area.

### 1209 — storefront product card cleanup

Goal:
- Public product cards show only title, EFHC quantity, price,
  description and `Оплатить`.

### 1210 — remove admin fields from public cards

Goal:
- No SKU, code, item_type, status, internal category, intent id or
  order id in public card rendering.

### 1211 — remove first-stage custom amount/search/filters

Goal:
- Keep first-stage storefront to approved admin-created cards only.

### 1212 — Pay opens wallet immediately

Goal:
- Product `Оплатить` creates payment and opens TON wallet.
- Amount and memo are already embedded.

### 1213 — wallet-open failure copy

Goal:
- Show only a simple user message if wallet opening fails.

### 1214 — opened-but-unpaid wallet state

Goal:
- No pressure, duplicate prompts or technical details when user opens
  wallet and does not pay.

### 1215 — human payment statuses

Goal:
- Public payment statuses use human language only.

### 1216 — move Browser-Shop diagnostics

Goal:
- Remove public payment diagnostics from Browser-Shop and keep them in
  admin/operator layers.

### 1217 — expand admin diagnostics

Goal:
- One operator entry for HUB, Shop, Deposit, endpoint health, status and
  payment chain diagnostics.

### 1218 — protect admin shop source

Goal:
- Keep `/admin/shop` as source for active public product cards.

### 1219 — public forbidden-term guard

Goal:
- Guard public HUB, DepositModal and BrowserShopPage strings.

### 1220 — public card field guard

Goal:
- Guard that admin fields are not rendered in storefront cards.

### 1221 — browser-shop layout guard

Goal:
- Guard that Browser-Shop does not use common Mini App shell.

### 1222 — tonconnect_tx public-render guard

Goal:
- Prove `tonconnect_tx` stays internal and never appears as public text.

### 1223 — route/contract split guard

Goal:
- Direct Deposit and Storefront payment remain separate roads.

### 1224 — frontend/backend visual call matrix

Goal:
- Enforce canonical frontend calls after visual cleanup.

### 1225 — contract tests repair

Goal:
- Restore postponed contract-test work for visual and economic roads.

### 1226 — HUB smoke path

Goal:
- Smoke path: Home -> HUB -> storefront and VIP link.

### 1227 — Direct Deposit smoke path

Goal:
- Smoke path: plus -> clean modal -> wallet-open attempt.

### 1228 — storefront smoke path

Goal:
- Smoke path: card -> Pay -> wallet-open attempt -> profile/history
  contract.

### 1229 — SSOT/NORM/report sync

Goal:
- Update route matrix, SSOT, NORM, Healer and reports after repairs.

### 1230 — visual evidence audit

Goal:
- Separate proven visual repairs, remaining blockers and not-ready
  claims.

## v168_20 detailed status update

### 1200 — bridge verdict completed

Result:
- The bridge verdict explicitly says the range is not release-ready.
- Direct Deposit is repaired, but Browser-Shop and storefront cleanup
  still require code work and proof.

### 1201 — HUB public cleanup completed

Result:
- Public HUB now has exactly two action cards.
- Operator/payment diagnostics no longer render in the public HUB.
- HUB technical references are visible only in admin diagnostics.
- A guard locks the public HUB boundary.

### Next detailed steps

1202 should start Browser-Shop layout separation or, if a browser proof
is available, verify the repaired Direct Deposit and HUB surfaces first.
If no browser runtime is available, continue with source-level cleanup
of Browser-Shop public UI blockers.

## v168_21 remap after cycles 1202-1203

Cycles 1202-1203 are complete for their specific findings:
Browser-Shop now has a route-based dedicated `ShopLayout`, and the
storefront top zone shows avatar, EFHC balance and Profile link.  The
main Q/A register now contains all 100 visual answers.

Remaining immediate blockers:

- clean storefront product cards;
- hide SKU/code/item_type/status and technical IDs;
- remove public wallet/memo/copy blocks;
- move Browser-Shop payment diagnostics to admin diagnostics;
- connect Pay to wallet-open without rendering raw `tonconnect_tx`.

## v168_22 detailed status

1204-1205 repaired Browser-Shop public content after the layout split.
The storefront no longer exposes the old diagnostic blocks or manual
payment fields.  The public card surface is now intentionally minimal.

Next detailed work:

- 1206: add Pay-button wallet-open integration using backend payment
  payload without rendering raw transaction data;
- 1207: add guard for no raw transaction payload in public UI;
- 1208: strengthen admin diagnostics for payment lifecycle review;
- 1209: smoke/guard proof for HUB -> Storefront -> Profile path;
- 1210: SSOT/NORM/report synchronization after storefront repair wave.


## v168_24 detailed status after 1207

1207 is complete for its focused finding:
Browser-Shop payment status is now polled after wallet handoff.

Next detailed direction:

- 1208: strengthen active-payment card and duplicate-payment feedback;
- 1209: add compact button feedback for disabled/tokenless actions;
- 1210: update diagnostics and frontend route/call matrix;
- 1211 onward: start compressing first-level UI surfaces into
  expandable cards and drawers while keeping all functions.

Dragon-style visual functions are planned separately for 1231-1350.

## v168_25 detailed status after 1208

1208 is complete for its focused FAQ finding:

- FAQ UI labels now use selected-language locale keys;
- FAQ remounts when `ctx.lang` changes;
- FAQ uses a compact bot-width shell;
- no canonical bottom menu buttons were changed.

Next focus:

- 1209: visible user-function inventory by page;
- 1210: classify each function as keep, move to admin, or question;
- 1211: begin Wallet subsection visual planning if approved.

---

## Источник: `WORK_CYCLES_1200-1300.md`


## v168_50 cycle 1266 note

Cycle 1266 restores FAQ access and repairs route/button tails after
the public UI rollback.  FAQ remains a page at `/faq` and is now visible
from the global header and from the `/web-profile` FAQ tab.  The six
canonical bottom buttons are unchanged.  `/admin/logs` is added because
admin surfaces already linked to it.  Shared `Button` now has a safe
`href` mode so navigation buttons no longer need unsafe Link-wrapped
Button nesting.  Docker SSL/runtime fixes from v168_48 and the public
UI rollback from v168_49 remain preserved.


## v168_49 cycle 1265 note

Cycle 1265 is a repair rollback of public UI mistakes while keeping
Docker fixes from v168_48.  HUB no longer renders technical runtime
text.  Energy no longer has unsanctioned HUB or Wallet/Profile action
cards and returns to the canon: energy, kWh, progress, panels, base
rate, generation speed, EFHC balance and available kWh.  Header balance
is visible again.  Public Profile no longer shows browser/PWA/internal
shell labels.  A local smoke test script was added for PC runtime
checks.

## v168_45 cycle 1261 note

The user pasted a Docker build log where backend completed and the
frontend image stopped at `RUN npm ci`.  The fragment has no final npm
error line, so the failure is classified as a frontend dependency
installation blocker/hang or low-visibility Docker install step.

Cycle 1261 hardens `ops/docker/Dockerfile.frontend`: npm registry is
explicit, audit/fund/progress noise is disabled, fetch retries are set,
and a static guard protects these Docker build flags.  Docker runtime
proof remains pending because Docker is not available in the assistant
environment.

## v168_44 cycles 1251-1260 note

Fresh log `logs_69555566503.zip` is green: all gate exit files are
zero, pytest reports 538 passed, npm build is green in GitHub CI and
backend security/static checks passed.  The pass therefore worked on
remaining visual and audit tails instead of log failures.

Closed cycle notes:

- 1251: Panels page uses compact list containment and GameDetails for
  activation context and per-panel technical details.
- 1252: Exchange page keeps the amount selector visible and moves
  advanced proof/withdraw detail into GameDetails drawers.
- 1253: Tasks page keeps active earning cards visible and moves the
  long help text into a compact GameDetails drawer.
- 1254: Referrals page keeps invite/share primary and moves system and
  level detail into compact drawers.
- 1255: Ranks page keeps the user card and podium visible, with the
  full table and extended leaderboard in drawers.
- 1256: Existing clean empty states are preserved and protected as the
  public fallback for inactive modules.
- 1257: Public loading/error states remain non-technical and use safe
  labels instead of raw exception text.
- 1258: All canonical route entry points remain intact.
- 1259: Added a static guard for GameDetails usage, route preservation
  and dependency warning tail closure.
- 1260: Documented compact proof and remaining proof boundary.

## v168_43 cycles 1246-1250 note

Cycles 1246-1250 are closed as a log-driven repair and Energy first
screen polish block.  The fresh log `logs_69510727201.zip` had three
pytest failures.  The pass fixed WebProfile payment/outcome surface
markers, split internal helper routes out of public OpenAPI SSOT,
refreshed OpenAPI from SSOT and added compact Energy first-screen chips
and bridge actions.

Closed cycle notes:

- 1246: EFHC balance chip added to Energy first screen.
- 1247: HUB bridge action added as a clean public card.
- 1248: Profile/Wallet compact entry added.
- 1249: the six-button bottom menu remains canonical and unchanged.
- 1250: first-screen public action count guard added.

## v168_23 cycle 1206 note

Cycle 1206 continues the public visual repair program.

Closed findings:

- language selector now matches the user's one-button dropdown canon;
- store pay button now uses the backend TonConnect transaction payload
  internally and opens the wallet transaction flow through TonConnect.

New planning input:

- Dragon/Web3 reference sandboxes are accepted as visual references for
  future browser shell, buttons, progress bars and game-like surfaces.
  They are not accepted as code donors.

# WORK CYCLES 1200-1300

Status: new visual repair range container.
Created during v168_17 after imported visual audit v002.

This document replaces the older generic 1201-1300 direction for the
active visual repair program. It does not close any future cycle.

## Activation rule

- Cycle 1200 is a bridge verdict, not automatic range closeout.
- Cycles 1201-1230 continue the visual blocker repair program.
- Cycles 1231-1300 remain future stabilization, proof and release
  evidence work after the main visual road repairs.
- If code repair proves a different order is safer, the cycle plan may
  be remapped in a new report. The reason must be explicit.

## 1200 bridge

- 1200: corrected bridge verdict for 1176-1200. Do not claim release
  readiness if visual blockers from the imported audit are still open.

## v168_19 remap after 1198-1199

Cycles 1198-1199 repaired the Direct Deposit modal and backend
wallet-open contract ahead of the older 1201-1203 plan items. The
remaining 1201-1203 items are therefore not repeated as new code tasks;
they become verification, browser check and evidence tasks for Direct
Deposit. HUB and Browser-Shop cleanup remain open.

## 1201-1230 active visual repair program
- 1201: Verify Direct Deposit backend contract in browser/runtime
  context and confirm receiver settings are present in deployment.
- 1202: Verify Direct Deposit frontend wallet-open integration by
  browser or Telegram WebApp run; no raw wallet/memo/copy UI allowed.
- 1203: Extend Direct Deposit guard evidence if browser screenshots or
  runtime route export expose any remaining public leakage.
- 1204: Clean HUB public screen to two actions only. Preserve VIP URL
  and language rules.
- 1205: Move HUB diagnostic blocks to admin diagnostics or admin
  components with one operator entry.
- 1206: Add HUB guard proving exactly two public actions and no
  forbidden technical terms.
- 1207: Create ShopLayout or route-based layout exception for
  browser-shop. Remove Mini App bottom navigation and GlobalHeader from
  storefront.
- 1208: Create storefront top area with avatar, balance and Profile
  button, using public names only.
- 1209: Clean storefront product cards. Show title, EFHC quantity,
  price, description and Pay only.
- 1210: Remove SKU, code, item_type, status, endpoint, intent id, order
  id and internal category from public storefront cards.
- 1211: Remove public custom amount, search and filters for first-stage
  storefront unless backed by approved active product design.
- 1212: Wire product Pay button to create payment and open TON wallet
  immediately with amount and memo embedded.
- 1213: Add simple wallet-open failure UX: Ne udalos otkryt koshelek.
  Poprobuyte snova.
- 1214: Ensure opened-but-unpaid wallet flow does not show pressure or
  technical duplicate prompts.
- 1215: Clean public payment status language: waiting, checking,
  completed and error as human messages.
- 1216: Move Browser-Shop payment diagnostics to admin diagnostics and
  backend/operator logs.
- 1217: Expand admin/diagnostics with HUB, Shop, Deposit, endpoint
  health, status and payment chain diagnostics.
- 1218: Keep admin/shop card management intact and verify active public
  cards come from admin catalog.
- 1219: Add public UI forbidden-term guard across HUB, DepositModal and
  BrowserShopPage user strings.
- 1220: Add public card field guard proving no admin fields are rendered
  in storefront cards.
- 1221: Add layout guard proving browser-shop does not use Mini App
  Layout or bottom nav.
- 1222: Add wallet-flow guard proving tonconnect_tx is internal and not
  rendered as public text.
- 1223: Add route/contract guard proving Direct Deposit is not package
  purchase and storefront remains product purchase.
- 1224: Frontend/backend call matrix enforcement for visual roads after
  component cleanup.
- 1225: Contract tests repair for repaired visual roads and previously
  repaired economic roads.
- 1226: Smoke test HUB path: Home to HUB to storefront and VIP link
  without diagnostics.
- 1227: Smoke test Direct Deposit path: plus to clean modal to
  wallet-open attempt and simple failure handling.
- 1228: Smoke test storefront path: product card to Pay to wallet-open
  attempt and profile/history outcome contract.
- 1229: Update SSOT, API contracts, road matrix, Healer and reports
  after visual road repairs.
- 1230: Visual release evidence audit. Separate proven repairs,
  remaining blockers and not-release-ready claims.

## 1231-1240 visual hardening
- 1231: Run screenshot or browser-based audit for HUB, Deposit and
  Storefront.
- 1232: Check Telegram browser and normal browser storefront entry.
- 1233: Validate responsive layout against Telegram Mini App
  constraints.
- 1234: Check Russian user copy as meaning canon.
- 1235: Check non-Russian fallback without exposing technical terms.
- 1236: Check profile history naming and completed payment visibility.
- 1237: Check active payment card copy and duplicate prevention.
- 1238: Check admin diagnostics contains moved technical data.
- 1239: Check admin/shop retains card management with admin-only fields.
- 1240: Update visual blocker registry after browser checks.

## 1241-1260 contract and smoke proof
- 1241: contract, smoke or guard proof wave 1241.
- 1242: contract, smoke or guard proof wave 1242.
- 1243: contract, smoke or guard proof wave 1243.
- 1244: contract, smoke or guard proof wave 1244.
- 1245: contract, smoke or guard proof wave 1245.
- 1246: contract, smoke or guard proof wave 1246.
- 1247: contract, smoke or guard proof wave 1247.
- 1248: contract, smoke or guard proof wave 1248.
- 1249: contract, smoke or guard proof wave 1249.
- 1250: contract, smoke or guard proof wave 1250.
- 1251: contract, smoke or guard proof wave 1251.
- 1252: contract, smoke or guard proof wave 1252.
- 1253: contract, smoke or guard proof wave 1253.
- 1254: contract, smoke or guard proof wave 1254.
- 1255: contract, smoke or guard proof wave 1255.
- 1256: contract, smoke or guard proof wave 1256.
- 1257: contract, smoke or guard proof wave 1257.
- 1258: contract, smoke or guard proof wave 1258.
- 1259: contract, smoke or guard proof wave 1259.
- 1260: contract, smoke or guard proof wave 1260.

## 1261-1280 road registry and SSOT proof
- 1261: route, SSOT, NORM, Healer or report sync wave 1261.
- 1262: route, SSOT, NORM, Healer or report sync wave 1262.
- 1263: route, SSOT, NORM, Healer or report sync wave 1263.
- 1264: route, SSOT, NORM, Healer or report sync wave 1264.
- 1265: route, SSOT, NORM, Healer or report sync wave 1265.
- 1266: route, SSOT, NORM, Healer or report sync wave 1266.
- 1267: route, SSOT, NORM, Healer or report sync wave 1267.
- 1268: route, SSOT, NORM, Healer or report sync wave 1268.
- 1269: route, SSOT, NORM, Healer or report sync wave 1269.
- 1270: route, SSOT, NORM, Healer or report sync wave 1270.
- 1271: route, SSOT, NORM, Healer or report sync wave 1271.
- 1272: route, SSOT, NORM, Healer or report sync wave 1272.
- 1273: route, SSOT, NORM, Healer or report sync wave 1273.
- 1274: route, SSOT, NORM, Healer or report sync wave 1274.
- 1275: route, SSOT, NORM, Healer or report sync wave 1275.
- 1276: route, SSOT, NORM, Healer or report sync wave 1276.
- 1277: route, SSOT, NORM, Healer or report sync wave 1277.
- 1278: route, SSOT, NORM, Healer or report sync wave 1278.
- 1279: route, SSOT, NORM, Healer or report sync wave 1279.
- 1280: route, SSOT, NORM, Healer or report sync wave 1280.

## 1281-1300 release evidence closeout
- 1281: final blocker, archive, report or range evidence wave 1281.
- 1282: final blocker, archive, report or range evidence wave 1282.
- 1283: final blocker, archive, report or range evidence wave 1283.
- 1284: final blocker, archive, report or range evidence wave 1284.
- 1285: final blocker, archive, report or range evidence wave 1285.
- 1286: final blocker, archive, report or range evidence wave 1286.
- 1287: final blocker, archive, report or range evidence wave 1287.
- 1288: final blocker, archive, report or range evidence wave 1288.
- 1289: final blocker, archive, report or range evidence wave 1289.
- 1290: final blocker, archive, report or range evidence wave 1290.
- 1291: final blocker, archive, report or range evidence wave 1291.
- 1292: final blocker, archive, report or range evidence wave 1292.
- 1293: final blocker, archive, report or range evidence wave 1293.
- 1294: final blocker, archive, report or range evidence wave 1294.
- 1295: final blocker, archive, report or range evidence wave 1295.
- 1296: final blocker, archive, report or range evidence wave 1296.
- 1297: final blocker, archive, report or range evidence wave 1297.
- 1298: final blocker, archive, report or range evidence wave 1298.
- 1299: final blocker, archive, report or range evidence wave 1299.
- 1300: final blocker, archive, report or range evidence wave 1300.

## Non-claim rule

Planning text in this file is not release readiness. A cycle is only
complete after real change, focused check and report evidence.

## v168_20 remap after cycles 1200-1201

Cycle 1200 completed the bridge verdict without false release readiness.
Cycle 1201 was remapped from verification-only work to a real code fix:
public HUB cleanup.  This was safe because the visual audit identifies
HUB diagnostics leakage as a blocker, while Direct Deposit already had
source-level code and guard proof from cycles 1198-1199.

### Updated near-term order

- 1202: Browser-Shop layout separation: storefront must not use the
  common Mini App Layout, GlobalHeader or bottom navigation.
- 1203: Storefront top zone: avatar, balance and Profile button.
- 1204: Clean storefront product cards and hide admin fields.
- 1205: Remove public wallet/memo/copy and payment diagnostics from
  Browser-Shop.
- 1206: Add forbidden-term and layout guards for Browser-Shop.
- 1207: Wire Pay button to wallet-open without rendering raw
  `tonconnect_tx`.
- 1208: Expand admin diagnostics for moved Browser-Shop details.
- 1209: Add smoke/guard proof for HUB and storefront paths.
- 1210: Sync SSOT/NORM/reports after Browser-Shop repair wave.

Older numbers after 1210 remain valid as stabilization and proof waves,
but the immediate priority is Browser-Shop cleanup.

## v168_21 remap after cycles 1202-1203

Cycles 1202-1203 are complete for their specific findings:
Browser-Shop now has a route-based dedicated `ShopLayout`, and the
storefront top zone shows avatar, EFHC balance and Profile link.  The
main Q/A register now contains all 100 visual answers.

Remaining immediate blockers:

- clean storefront product cards;
- hide SKU/code/item_type/status and technical IDs;
- remove public wallet/memo/copy blocks;
- move Browser-Shop payment diagnostics to admin diagnostics;
- connect Pay to wallet-open without rendering raw `tonconnect_tx`.

## v168_22 storefront cleanup status

Cycle 1204 removed public storefront operator noise and technical card
fields.

Cycle 1205 removed manual wallet/memo/copy/payment diagnostics from the
public Browser-Shop page and moved the technical review surface to
admin diagnostics.

The next active work is not a release verdict.  It is Pay-button wallet
opening and proof that the wallet instruction remains internal.


## v168_24 update after cycle 1207

Cycle 1207 completed a focused payment-status and route-diagnosis pass.

- Browser-Shop now keeps `activeIntentId` after creating a payment.
- Pending/checking payments poll `/shopfront/intent-status`.
- Payment status maps to human states only: checking, completed or
  error.
- The generated status validator now keeps optional `flow_truth`.
- A static route inventory found no missing page routes for current
  frontend `href`, `router.push` and `window.location.assign` links.

This does not prove every button in a live browser.  It proves that the
current issue is not a global missing-page-route failure.  The remaining
problem is UX architecture: too many first-level actions, Telegram-only
runtime dependencies, disabled states without enough explanation and
async actions without immediate user feedback.

## Dragon-style extension plan

The Dragon-style visual and functional-compression program is recorded
in:

`docs/cycles/WORK_CYCLES_1231-1350_DRAGON_VISUAL_FUNCTIONS_PLAN.md`.

It is visual/UX work only.  It must not copy Dragon branding or assets,
and it must not remove EFHC functions.

## v168_25 update after cycle 1208

Cycle 1208 repaired the FAQ frontend layer.

The user clarified that the six bottom navigation buttons are canonical.
They must not be renamed, reordered, removed, or collapsed.

Future compression must happen inside canonical pages:

- remove artifact functions only after audit;
- move operator/admin functions to admin;
- keep game pages visually equal for normal users and admins;
- approve visible function fate through Q/A.

FAQ-specific result:

- localized quick labels;
- compact Mini App shell;
- bot-width overflow protection;
- architecture guard added.

## v168_26 update

Cycle 1209 added browser/PWA shell foundation and visible function
inventory.  The 1209-1230 detailed plan is corrected to keep all six
canonical buttons and to compress only subsections unless a later Q/A
approves deeper changes.

## v168_38 update after cycle 1226-1228 Energy repair

Cycle 1226-1228 now has a real Energy first-screen code repair.

Confirmed in chat:

- Profile remains a route page, not an overlay.
- Energy follows a Dragon-like first-screen structure, but with EFHC
  branding and EFHC routes.

Implemented:

- stronger Energy hero;
- live central kWh resource number;
- visible progress strip;
- active panels and generation-rate chips;
- first-screen action cards for Panels and Exchange;
- duplicate pre-page skin hero removed from Layout.

This is not a 99 percent frontend verdict.  The next planned step is the
shared EFHC Game UI Kit for all canonical pages.

## v168_39 update after cycles 1229-1230

Cycles 1229-1230 were updated and closed as a first shared visual pass.

Cycle 1229:

- added shared EFHC Game UI Kit component layer;
- moved Panels, Exchange, Tasks, Referrals and Ranks to the shared game
  page/hero/stat pattern;
- kept the six canonical bottom navigation labels unchanged.

Cycle 1230:

- localized Profile / Wallet / History tabs across all locale files;
- restored Admin entry for admin accounts;
- hid raw public technical errors from user-facing pages;
- added a dynamic TonConnect manifest endpoint for browser/Cloudflare
  mode;
- reduced flicker sources in splash and Telegram MainButton handling;
- polished the bottom navigation into a stronger dark/gold game bar.

This is still not a 99 percent frontend verdict.  The next visual wave
must continue from the shared kit into deeper card polish, Wallet flow,
Shop/HUB proof and live browser/Docker verification.

## v168_40 cycle update: 1231-1232

### 1231: live check and FAQ containment

- Previous Cloudflare tunnel was checked and returned `502 Bad Gateway`.
- No live visual success is claimed from that tunnel.
- FAQ overflow blocker was fixed by adding strict containment and
  wrapping rules to the FAQ shell.
- Long FAQ section names, answers, breadcrumbs and category pills must
  stay inside the application frame.

### 1232: Wallet / HUB / Browser-Shop Game UI Kit pass

- Wallet and History inside `/web-profile` now use shared Game UI Kit
  stat and notice primitives.
- HUB now uses Game UI Kit hero, action cards and notice blocks.
- Browser-Shop now uses Game UI Kit hero, notices, sections and product
  cards.
- Browser-Shop no longer displays raw public exception details in the
  storefront error state.

### Status after v168_40

- Cycles 1226-1228: base launch, independent shell and Energy first
  screen foundation.
- Cycles 1229-1230: first EFHC Game UI Kit wave and public blocker
  cleanup.
- Cycles 1231-1232: FAQ containment plus Wallet / HUB / Browser-Shop
  Game UI Kit extension.

Next focus: live deployment proof and then deeper Wallet state-map,
HUB handoff proof and Browser-Shop checkout proof.

## Cycles 1233-1235 — Wallet state-map + TonConnect proof UI

- 1233: done — WebProfile Wallet state-map added for six public states:
  connected, not connected, pending proof, wallet error, backend error,
  and bound.
- 1234: done — TonConnect manifest CORS and proof UI foundation kept
  aligned with WalletGate/TonConnect SSOT.
- 1235: done — `logs_69492808512.zip` failures triaged and repaired:
  TypeScript nullable URL, undefined `processing_ik`, route policy,
  OpenAPI/SSOT drift, stale guards, and artifact hygiene.

## v168_42 cycles 1236-1245 note

Closed in this pass:

- 1236: started EFHC status-chip polish for Wallet and Shop states.
- 1237: made Wallet state-map more visual through GameStatusPill.
- 1238: added Browser-Shop runtime state signal in the hero area.
- 1239: repaired fresh log pack `logs_69501935339.zip` findings.
- 1240: re-synced DB and route SSOT drift from current CSV truth.
- 1241: restored HUB pending/disabled public state coverage.
- 1242: restored VIP NFT external collection wording canon.
- 1243: restored Browser-Shop TON-only MVP guard boundary.
- 1244: restored pre-archive test rule in AI startup documents.
- 1245: passed local TypeScript no-emit proof after frontend changes.

Remaining for 1246-1250:

- live proof after a working tunnel;
- deeper Wallet / HUB / Browser-Shop visual polish;
- final screenshot-based browser verification.

## v168_46 cycle 1262: Docker known-good rollback

- User reported Docker stopped working and that v168_37 was
  the last working version.
- The provided Docker log showed backend build success and frontend stop
  at `RUN npm ci`.
- Root cause: the release branch moved away from the v168_37 frontend
  dependency baseline during npm-audit cleanup and Dockerfile npm-ci
  hardening.
- Repair: restore `frontend/package.json`, `frontend/package-lock.json`
  and `ops/docker/Dockerfile.frontend` from v168_37.
- Application code is not rolled back.
- Dependency security cleanup is postponed to a separate Docker-proven
  upgrade cycle.

## v168_47 cycle 1263: Docker history runtime fix

- User provided Docker history after v168_46.
- Earlier npm-ci-only diagnosis was incomplete.
- The history shows containers reaching runtime and backend health checks
  returning `200 OK`.
- The real runtime blocker is asyncpg receiving unsupported `sslmode`
  from the async `DATABASE_URL`.
- Repair: strip `sslmode` from asyncpg DSN and map SSL-required modes to
  asyncpg `ssl=True`.
- Local Docker async DB URLs no longer include `?sslmode=disable`.
- v168_37 frontend dependency baseline remains preserved from v168_46.


## v168_48 cycle 1264: Docker sync SSL mode fix

- User provided the next Docker output from v168_47.
- Backend and frontend images build, but `docker compose up` fails at
  backend startup.
- Confirmed runtime blocker: Alembic / psycopg2 requires SSL against
  local Docker Postgres.
- Root cause: `backend/migrations/env.py` auto-added
  `sslmode=require` for host `db` when the sync URL did not include
  an explicit sslmode.
- Repair: Docker `PSYCOPG_URL` now uses `sslmode=disable`.
- Repair: Alembic no longer forces SSL for local/dev/ci/test or
  Docker local hosts `db` and `postgres`.
- Async `DATABASE_URL` remains clean asyncpg without psycopg
  sslmode.


## v168_51 — FAQ / tunnel / routes / admin correction

- FAQ must be a vertical section/subsection/question tree, not a pill or
  quick-button interface.
- Profile must keep a visible FAQ entry.
- Cloudflare quick tunnel failure is diagnosed separately from EFHC
  runtime: local frontend and Docker-to-host frontend may work while
  `POST https://api.trycloudflare.com/tunnel` fails externally.
- Admin root must move toward clear app-button launcher cards, not a
  mixed technical proof page.
- Route targets must be checked with `ops/local/check_frontend_routes.py`.

---

## Источник: `WORK_CYCLES_1201-1300.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1201-1300

Status: planning container only.

This file exists so the next range has a prepared cycle container.
It is not evidence that any cycle from 1201 onward is complete.

## Control rule

- cycles must be executed in order;
- every completed cycle needs its own report or explicit range report;
- no future cycle is closed by planning text;
- no code deletion is allowed only because a route looks old;
- frontend and FAQ line72 work remains excluded unless the user gives a
  new direct instruction.

## Planned direction

The 1201-1300 range continues the proof program opened by the road
audit and cycles 1180-1200.

Primary themes:

1. runtime OpenAPI proof;
2. frontend/backend contract proof;
3. ORM versus `0001` proof;
4. economic-road outcome proof;
5. helper/internal route isolation;
6. contract tests for sensitive roads;
7. release-readiness matrix and final closeout.

## Planned cycle groups

### 1201-1210 — runtime route proof

- 1201 — generate runtime OpenAPI from the FastAPI app.
- 1202 — compare runtime OpenAPI with static route decorators.
- 1203 — classify hidden helper routes and public routes.
- 1204 — compare OpenAPI paths with frontend callers.
- 1205 — create missing route-to-caller notes.
- 1206 — route registry update.
- 1207 — route registry guard script update.
- 1208 — route compatibility report.
- 1209 — route proof recheck.
- 1210 — route proof closeout.

### 1211-1225 — schema proof

- 1211 — list ORM tables and fields.
- 1212 — inspect `0001` metadata strategy.
- 1213 — compare key economic models with migration support.
- 1214 — verify withdraw schema support.
- 1215 — verify deposit and payment schema support.
- 1216 — verify exchange and panels schema support.
- 1217 — verify shop/order schema support.
- 1218 — verify task and ads schema support.
- 1219 — record schema gaps without unsafe migration edits.
- 1220 — fix confirmed safe schema-doc gaps.
- 1221 — prepare code fixes only where verified.
- 1222 — run focused compile checks.
- 1223 — update schema proof docs.
- 1224 — Healer sync.
- 1225 — schema proof closeout.

### 1226-1245 — economic roads

- 1226 — withdraw create road proof.
- 1227 — withdraw admin review road proof.
- 1228 — withdraw final status road proof.
- 1229 — deposit intent road proof.
- 1230 — watcher result road proof.
- 1231 — payment truth road proof.
- 1232 — exchange request road proof.
- 1233 — exchange ledger road proof.
- 1234 — panel activation road proof.
- 1235 — panel history road proof.
- 1236 — shop order road proof.
- 1237 — shop payment road proof.
- 1238 — bank ledger road proof.
- 1239 — admin statistics road proof.
- 1240 — user-visible outcome proof.
- 1241 — operator-visible outcome proof.
- 1242 — focused tests map.
- 1243 — economic proof matrix update.
- 1244 — Healer sync.
- 1245 — economic roads closeout.

### 1246-1265 — helper/internal and false roads

- 1246 — helper route inventory.
- 1247 — RBAC marking pass.
- 1248 — `include_in_schema` review.
- 1249 — diagnostics route boundary.
- 1250 — sync route boundary.
- 1251 — shop helper boundary.
- 1252 — admin helper boundary.
- 1253 — false UI action scan.
- 1254 — false UI outcome classification.
- 1255 — safe hiding plan for unproven UI actions.
- 1256 — compatibility guard plan.
- 1257 — no-consumer proof rule.
- 1258 — route deprecation notes.
- 1259 — helper docs update.
- 1260 — Healer sync.
- 1261 — focused tests.
- 1262 — report sync.
- 1263 — matrix sync.
- 1264 — release note sync.
- 1265 — helper/internal closeout.

### 1266-1300 — release proof closeout

- 1266 — contract test gap map.
- 1267 — payload shape proof.
- 1268 — response shape proof.
- 1269 — error outcome proof.
- 1270 — idempotency proof.
- 1271 — tg_id-only proof.
- 1272 — admin operator proof.
- 1273 — user account center proof.
- 1274 — Browser-Shop proof.
- 1275 — Hub handoff proof.
- 1276 — Web-Profile proof.
- 1277 — ProfileModal boundary proof.
- 1278 — route registry final sync.
- 1279 — schema registry final sync.
- 1280 — economic registry final sync.
- 1281 — Healer final sync.
- 1282 — reports index sync.
- 1283 — AI docs sync.
- 1284 — SSOT/NORM sync.
- 1285 — local focused checks.
- 1286 — archive hygiene check.
- 1287 — no-deletion preservation check.
- 1288 — line72 changed-doc check.
- 1289 — release evidence pack draft.
- 1290 — release evidence pack review.
- 1291 — final gap inventory.
- 1292 — final blocker list.
- 1293 — final must-fix list.
- 1294 — final should-fix list.
- 1295 — final deferred list.
- 1296 — final operator checklist.
- 1297 — final user-facing risk check.
- 1298 — final archive report.
- 1299 — final range report.
- 1300 — range closeout.

## Bridge note after v168_06

The 1201-1300 file remains a future container. It must not be used to
claim work beyond 1200. The expected bridge after 1196-1200 is a
release-proof continuation based on the final road-integrity gate list.


## Bridge note after v168_07

The 1176-1200 range is closed.

The next active cycle is 1201. The 1201-1300 range must continue with
runtime OpenAPI proof, DB-backed schema proof, frontend/backend
contract tests and E2E economic-road evidence.

Planning text in this file does not close any cycle by itself.


## Activation guard after v168_08 correction

This range is not active until cycles 1182-1200 are completed or
honestly handed off with explicit blockers. The previous v168_07
closeout
was corrected: 1180-1200 were not real release-fix closure cycles.

## Superseded planning note after v168_17

This older 1201-1300 file is now superseded for the active visual
repair direction by docs/cycles/WORK_CYCLES_1200-1300.md and
docs/cycles/WORK_CYCLES_1195-1230_VISUAL_FIX_PLAN.md. Keep this file
as historical context; do not use it to claim cycle completion.


## 1211-1212 — Energy/Ranks boundary repair

Status: specific finding repaired.

- Removed the public Energy progress ladder from Ranks.
- Kept the six bottom menu buttons unchanged.
- Kept Energy as the canonical first screen.
- Recorded the game simulator WebApp model in glossary/docs.
- Added guard `test_energy_ranks_boundary_guard.py`.

---

## Источник: `WORK_CYCLES_1209-1230_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

## 1217-1218 update

Tasks must be a compact earning module. Keep the canon bottom button
Tasks. Do not remove ads-flow. Replace public frontend path tg_id calls
with current-user routes. Add clear human explanations for disabled
buttons.

## v168_27 correction

Cycle 1210 became targeted shell repair and visible-function triage.
Cycle 1211 now starts the Energy visual hierarchy audit.
See `WORK_CYCLES_1210-1230_DETAILED_PLAN.md`.

# WORK CYCLES 1209-1230 — corrected detailed plan

## Core correction after user answers

The project must not be collapsed into a new button system.
The six bottom buttons are canonical and remain unchanged:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

Energy remains canonical as the first screen.
It shows progress and generation, not a first-action button grid.

Dragon style is visual only.
Do not copy Dragon brand or assets.
Do not remove EFHC functions without an approved triage.

## Cycle 1209

Theme: visible function audit and Browser shell foundation.

Actions:

- generate visible frontend function inventory;
- document route/click diagnosis;
- add browser/PWA shell infrastructure;
- document Dragon reference limitation and method;
- update cycle plan and visual norm.

Evidence:

- `frontend_visible_functions_inventory_1209.json`;
- PWA manifest and service worker guard;
- visible function audit guard.

## Cycle 1210

Theme: Energy visual hierarchy audit.

Actions:

- inspect Energy page progress and generation blocks;
- verify rank-level names are not exposed where forbidden;
- map Dragon-like progress bars to EFHC energy progress;
- keep Energy route and name unchanged.

## Cycle 1211

Theme: Energy visual repair.

Actions:

- compact the Energy page without removing canon data;
- improve progress bar, generation and balance hierarchy;
- add guards for hidden rank-level internals.

## Cycle 1212

Theme: Panels visible controls audit.

Actions:

- inventory visible Panels buttons;
- classify controls as canonical, secondary, artifact or admin;
- do not remove without Q/A when uncertain.

## Cycle 1213

Theme: Panels visual compression.

Actions:

- keep Panels page as canonical;
- compress secondary controls inside cards/drawers;
- preserve panel activation canon.

## Cycle 1214

Theme: Exchange route and feedback audit.

Actions:

- verify Exchange buttons and API calls;
- identify inactive/disabled states with no explanation;
- keep Exchange page as canonical.

## Cycle 1215

Theme: Exchange visual repair.

Actions:

- add immediate feedback for async states;
- improve error and empty states;
- preserve economic canon 1 kWh = 1 EFHC.

## Cycle 1216

Theme: Tasks visual audit.

Actions:

- inventory all visible task actions;
- classify artifact/debug controls;
- map Dragon-style task cards to EFHC tasks.

## Cycle 1217

Theme: Tasks compact repair.

Actions:

- implement compact task cards;
- add clearer button feedback;
- keep route and business logic unchanged.

## Cycle 1218

Theme: Referrals visual audit.

Actions:

- inventory referral buttons and tabs;
- find runtime-state button failures;
- keep Referrals canonical.

## Cycle 1219

Theme: Referrals compact repair.

Actions:

- add Dragon-like compact referral cards;
- preserve referral links and active/inactive subroutes;
- improve copy/share feedback.

## Cycle 1220

Theme: Ranks semantic audit.

Actions:

- inspect rank page and Energy level progress;
- separate leaderboard from hidden internal level names;
- verify 12 Energy progress levels are not overexposed.

## Cycle 1221

Theme: Ranks visual repair.

Actions:

- implement progress-card style where safe;
- keep Ranks canonical page;
- keep leaderboard readable.

## Cycle 1222

Theme: Wallet/Profile design audit.

Actions:

- audit all wallet/profile visible functions;
- prepare detailed Q/A for the new Wallet subsection;
- do not redesign money roads without approval.

## Cycle 1223

Theme: Wallet/Profile first repair.

Actions:

- compress Wallet visual structure;
- preserve Deposit, history and wallet-connect roads;
- add clear disabled-state explanations.

## Cycle 1224

Theme: Browser-Shop Web3-style audit.

Actions:

- compare current Browser-Shop to Web3 reference structure;
- keep Browser-Shop reachable through HUB;
- verify public card fields stay clean.

## Cycle 1225

Theme: Browser-Shop visual polish.

Actions:

- add compact Web3-style shop visuals using EFHC brand;
- preserve TON wallet opening and status polling;
- no raw wallet/memo/copy blocks in public UI.

## Cycle 1226

Theme: browser shell click audit.

Actions:

- inspect Telegram-only functions in normal browser mode;
- document required browser fallbacks;
- avoid false live proof without browser execution.

## Cycle 1227

Theme: browser shell fallback repair.

Actions:

- add safe browser fallbacks where obvious;
- keep Telegram Mini App behavior intact;
- update PWA/browser docs.

## Cycle 1228

Theme: visible function triage report.

Actions:

- produce user-facing table: leave/delete/admin/question;
- list uncertain functions for approval;
- do not delete uncertain functions.

## Cycle 1229

Theme: approved visible function cleanup.

Actions:

- remove or move only approved artifact functions;
- add guards for public/admin separation;
- update reports and Q/A register.

## Cycle 1230

Theme: corrected visual range verdict.

Actions:

- collect evidence from 1195-1230;
- state what is fixed and what remains open;
- do not claim full release readiness without CI and browser proof.


## Update after cycles 1211-1212

User correction: chat is the place of approval.  Archive files may store
working memory, but the user approves details only through chat.

Cycle 1211 repaired Energy progress exposure.  The Energy screen remains
the canonical first page and shows progress/generation without exposing
internal 12-level names as public text.

Cycle 1212 repaired Ranks.  Ranks is a leaderboard, not a catalogue of
Energy progress thresholds.  The next cycles should continue visual
compression only inside canonical pages.

## v168_29 update after cycles 1213-1214

The browser/PWA goal is fixed as a dual-surface EFHC application:
Telegram Mini App plus normal browser/PWA shell.  Installation must use
the browser system install prompt, not a custom EFHC install button.

Ranks now has compact leader cards while staying a leaderboard.
Panels, Exchange and Tasks were audited without deleting functions.
The next safe focus is Panels compact visual repair.

## v168_30 correction

Cycles 1215-1216 followed the corrected v168_29 plan rather than older
payment-diagnostic notes.  Panels and Exchange were visually compressed
inside their canonical pages.  No bottom navigation labels or positions
were changed.

## Update after cycle 1219 emergency user report

User reported that the frontend looked empty in browser launch: no dark
surface, no first-page content and no visible progress bars.  The hard
product correction is: EFHC must render as a full app without Telegram
`tg_id`.

### 1219 — browser independence emergency repair

- Add safe browser fallback snapshot.
- Remove loading-only returns from Energy and core pages when `tg_id` is
  absent.
- Keep real economic actions protected; do not fake server success.

### 1220 — WebApp simulator canon sync

- Record WebApp/PWA model in glossary and AI/NORM docs.
- State that Telegram and browser open the same app.

### 1221 — visible elements table for chat agreement

- Create page-by-page visible elements table.
- Use it only as a working table; final agreement is in chat.

### 1222 — Energy first-screen proof

- Ensure Energy renders progress bar and game state from fallback state.
- No public internal 12-level ladder.

### 1223 — Tasks browser demo safety

- Tasks must not disappear in browser mode.
- Safe local demo timer allowed for visual/browser proof.

### 1224 — route/button diagnosis extension

- Continue checking buttons that appear inactive.
- Distinguish route breakage from missing identity or backend state.

### 1225 — evidence and next repair plan

- Summarize what is now visible to the user.
- Prepare Referrals/Profile/Wallet next visual agreement.

## 1225 follow-up: blank screen and visual agreement correction

New correction after user browser check:

- blank / white screen is a blocker;
- default app theme must be dark;
- Energy must render without Telegram tg_id;
- locale loading must not keep SplashScreen forever;
- progress bar must be visible even at zero percent;
- Referrals must not call user-only backend when tg_id is missing;
- all visible frontend elements must be agreed in chat.

Next priorities:

1. Referrals compact repair.
2. Profile / Wallet detailed agreement.
3. Energy visual center repair.
4. Browser/PWA live proof.
5. Full page-by-page visual audit in chat.

---

## Источник: `WORK_CYCLES_1210-1230_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Work cycles 1210-1230 — corrected visual plan

## Cycle 1210 — infrastructure and visible function triage

Apply the user's correction list:

- Docker backend docs copy;
- compose `/api/health` healthcheck;
- Telegram SDK in `_document`;
- shared Modal as bottom-sheet;
- focused modal/header/shell CSS additions;
- GlobalHeader visual adaptation without breaking actions;
- Layout Telegram/game-shell navigation without changing the six bottom
  menu buttons;
- visible functions table: leave/delete/admin/question.

## Cycle 1211 — Energy and progress hierarchy

Audit and repair the Energy screen as the canonical first screen:

- generation information;
- kWh progress;
- active panel signal;
- game-style progress bars;
- no public exposure of forbidden internal rank-level mechanics.

## Cycle 1212 — Ranks visual compression

Adapt Ranks to compact game-style cards while keeping canonical rank
logic and without renaming the bottom button.

## Cycle 1213 — Panels visual compression

Keep Panels as a canonical page. Compress only subsections and visible
states that are not core to panel activation.

## Cycle 1214 — Exchange visual compression

Keep Exchange as a canonical page. Improve clarity of preview, convert,
history and disabled states.

## Cycle 1215 — Tasks / Referrals visual grouping

Use Dragon-like card hierarchy only inside canonical pages. Do not move
Tasks or Referrals into a different first-level button.

## Cycle 1216 — Wallet/Profile detailed agreement

Prepare the Wallet/Profile model for approval. Separate balance,
wallet-connect, history, deposit and withdraw surfaces clearly.

## Cycle 1217 — Wallet/Profile implementation pass

Implement only the approved Wallet/Profile visual corrections.

## Cycle 1218 — Button feedback and disabled states

Audit buttons that look broken because they need wallet, Telegram
runtime, tg_id, backend data or async state. Add clear user feedback.

## Cycle 1219 — Browser shell hardening

Keep browser/PWA mode system-install only. Do not add a custom install
button unless later approved.

## Cycle 1220 — Browser fallback audit

List Telegram-only functions and define safe browser fallbacks without
breaking Telegram Mini App behavior.

## Cycle 1221 — Browser fallback repair

Repair only safe fallbacks found in cycle 1220.

## Cycle 1222 — Admin separation audit

Check that admin/debug/operator features are visible only through Admin.

## Cycle 1223 — Admin separation repair

Move only confirmed public leaks to Admin. Do not remove uncertain
features without approval.

## Cycle 1224 — Browser-Shop Web3 polish

Continue Web3-style visual polish through HUB while preserving payment
and status polling roads.

## Cycle 1225 — FAQ and help polish

Keep FAQ compact and language-aware. Do not rewrite FAQ content unless
a specific FAQ content cycle is approved.

## Cycle 1226 — Visual guard pack

Add static guards for public leaks, bottom menu canon, modal shell and
browser shell.

## Cycle 1227 — Route/click static audit

Regenerate route and button inventories. Separate real broken links from
state-gated actions.

## Cycle 1228 — User approval table

Produce the next leave/delete/admin/question table after the page-level
repairs.

## Cycle 1229 — Approved cleanup only

Delete or move only functions directly approved by the user.

## Cycle 1230 — range verdict

Collect evidence for 1195-1230 and state what is fixed, open or not
proven. Do not claim full release readiness without CI and browser
proof.


## Update after cycles 1211-1212

The visible-function approval table remains a working audit artifact.
It is not an approval mechanism.  Approval happens in chat.

Cycle 1211: Energy progress boundary repaired.
Cycle 1212: Ranks leaderboard boundary repaired.

Next recommended focus: page-level visual hierarchy for Energy and Ranks
using the Dragon-style principle of compact cards and progressive
disclosure, without renaming or moving canonical bottom menu sections.

## v168_29 correction

Cycle 1213 added Ranks compact cards and WebApp/PWA target fixation.
Cycle 1214 audited Panels, Exchange and Tasks.

The next repair must stay inside canonical pages and must not rename or
move the six bottom navigation buttons.

---

## Источник: `WORK_CYCLES_1213-1230_DETAILED_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

## 1217-1218 update

After Panels and Exchange compression, Tasks is repaired as a compact
earning module. The next page focus should be Referrals or Wallet after
chat approval. Questions to the user must be simple and human.

# Work cycles 1213-1230 — corrected visual/game-shell plan

## Cycle 1213

Theme: WebApp / PWA target fixation and Ranks visual cards.

Actions:

- define EFHC as Telegram WebApp plus browser/PWA application;
- keep browser install through the system browser prompt;
- do not add a custom install button;
- add compact Dragon-style leader cards to Ranks;
- preserve Ranks as leaderboard only.

## Cycle 1214

Theme: Panels / Exchange / Tasks visible-function audit.

Actions:

- audit visible functions without deleting them;
- classify leave / ask / move to Admin / delete;
- localize confirmed public hardcoded text;
- remove confirmed technical wording from public strings;
- keep canonical pages and bottom buttons unchanged.

## Cycle 1215

Theme: Panels compact visual repair.

Actions:

- compress duplicate visual surfaces in Panels;
- keep activation road and 100 EFHC activation canon;
- do not change panel economics;
- add disabled-state explanation where needed.

## Cycle 1216

Theme: Exchange compact visual repair.

Actions:

- keep kWh to EFHC exchange road;
- keep withdraw road until Wallet design is approved;
- reduce helper cards into compact cards or drawer hints;
- keep no public technical terms.

## Cycle 1217

Theme: Tasks compact earning module.

Actions:

- make task cards more game-like;
- keep task claim road;
- do not remove ads flow without chat approval;
- add clear feedback for disabled buttons.

## Cycle 1218

Theme: Wallet subsection questions.

Actions:

- ask detailed Wallet design questions in chat;
- do not move withdraw/deposit/history without approval;
- prepare visual target for Wallet.

## Cycle 1219

Theme: Wallet subsection first repair.

Actions:

- implement only approved Wallet visual structure;
- preserve money roads and history;
- keep admin/debug out of game pages.

## Cycle 1220

Theme: browser runtime audit.

Actions:

- inspect Telegram-only calls in browser mode;
- add safe browser fallbacks where confirmed;
- do not claim live browser proof without running it.

## Cycle 1221

Theme: browser fallback repair.

Actions:

- fix safe Telegram runtime assumptions;
- keep Telegram behavior intact;
- keep PWA manifest and service worker valid.

## Cycle 1222

Theme: Admin separation audit.

Actions:

- verify admin/debug functions are only through Admin;
- list public leaks if any;
- do not remove uncertain functions without chat approval.

## Cycle 1223

Theme: Admin separation repair.

Actions:

- move only confirmed public leaks to Admin;
- update guards and docs;
- keep game pages same for all users.

## Cycle 1224

Theme: Browser-Shop Web3 polish.

Actions:

- continue Web3-style shop visuals through HUB;
- preserve TON wallet opening and polling;
- keep no wallet/memo/copy public blocks.

## Cycle 1225

Theme: FAQ/help polish.

Actions:

- keep FAQ language-aware;
- keep compact bot width;
- do not rewrite FAQ content without approval.

## Cycle 1226

Theme: visual guard pack.

Actions:

- guard bottom menu canon;
- guard no Energy ladder in Ranks;
- guard browser/PWA files;
- guard public technical term absence.

## Cycle 1227

Theme: click and button audit.

Actions:

- inventory all visible buttons;
- separate route bugs from state-gated buttons;
- document disabled-state reasons.

## Cycle 1228

Theme: chat approval packet.

Actions:

- produce concise questions in chat;
- archive can store notes but not approve decisions;
- ask only high-value questions.

## Cycle 1229

Theme: approved cleanup only.

Actions:

- remove or move only chat-approved functions;
- no silent deletions;
- update guards.

## Cycle 1230

Theme: range verdict.

Actions:

- collect evidence for 1195-1230;
- state fixed/open/not proven;
- do not claim CI green without user CI log.

## v168_30 update after cycles 1215-1216

Cycle 1215 repaired Panels compact visuals and moved Panels list calls
to
self-user routes.  The activation road and 100 EFHC canon were not
changed.  Legacy `/panels/{tg_id}/active|archive` routes remain hidden
compatibility routes.

Cycle 1216 repaired Exchange compact visuals.  Exchange and Withdraw
remain on the canonical Exchange page until the Wallet subsection is
approved in chat.  Secondary helper text is moved into an expandable
compact details layer.

The next focus stays cycle 1217: Tasks compact earning module and clear
feedback for disabled or state-gated actions.

## 1219-1225 correction: app must not depend on tg_id

The user clarified that the app must be complete in every mode.  Missing
Telegram `tg_id` cannot blank pages.  The browser/PWA shell must render
Energy, progress bars, Panels, Exchange, Tasks, Ranks and other public
surfaces with safe zero-state data until real identity data is present.

## 1225 correction note

User confirmed that the current visual result is not acceptable.
The plan is corrected: do not continue cosmetic micro-fixes before the
basic game shell is stable in browser and Telegram.

Hard rule:

- the app must show the same game UI without tg_id;
- Telegram data may personalize, but must not control existence of UI;
- visible elements are approved only in chat.

---

## Источник: `WORK_CYCLES_1226-1350_FRONTEND_99_ROADMAP.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# WORK CYCLES 1226-1350 FRONTEND 99 ROADMAP

Status: planned route after v168_35 audit.

## Purpose

Move EFHC Bot frontend from visual survival state to 99 percent
user-facing WebApp/PWA readiness.

This roadmap does not remove canonical pages and does not change the
EFHC economy. It organizes the next visual work into proof gates.

## 1226-1230 recovery and agreement

- 1226: build/runtime audit for blank screen and dark shell.
- 1227: visible element agreement table in chat.
- 1228: EFHC visual tokens for cards, glow, chips and bars.
- 1229: reusable game component kit specification.
- 1230: corrected verdict for current frontend readiness.

## 1231-1240 reference and design foundation

- 1231: Dragon/Web3 visual principles into EFHC rules.
- 1232: no external brand assets check.
- 1233: first-screen information hierarchy.
- 1234: progressive disclosure rules.
- 1235: progress bar and resource chip mapping.
- 1236: game card and action card mapping.
- 1237: mobile Telegram shell constraints.
- 1238: desktop browser frame constraints.
- 1239: visual regression checklist.
- 1240: Healer risk update.

## 1241-1260 Energy and core canonical pages

- 1241: GameShell and GameHeader implementation.
- 1242: BottomGameNav final visual pass.
- 1243: ResourceChip component.
- 1244: EnergyProgress component.
- 1245: Energy first screen final layout.
- 1246: Panels machine-card migration.
- 1247: Panels details drawer.
- 1248: Exchange converter card.
- 1249: Exchange history/details drawer.
- 1250: Tasks earning/ad card migration.
- 1251: Tasks ad-flow state feedback.
- 1252: common empty states.
- 1253: common loading states.
- 1254: common error states.
- 1255: no route deletion guard.
- 1256: no admin/debug public leak guard.
- 1257: route smoke map update.
- 1258: TypeScript proof.
- 1259: targeted pytest proof.
- 1260: first core-page visual verdict.

## 1261-1280 Referrals, Ranks, Profile and Wallet

- 1261: Referrals invite card migration.
- 1262: Referrals growth progress migration.
- 1263: Referrals active/inactive compact lists.
- 1264: Ranks leaderboard final card layout.
- 1265: Ranks current-user and empty-state cleanup.
- 1266: Profile overview compression.
- 1267: Profile language/settings cleanup.
- 1268: Wallet subsection design agreement.
- 1269: Wallet primary balance card.
- 1270: Wallet history timeline.
- 1271: WebProfile technical language removal.
- 1272: WebProfile diagnostics moved to Admin.
- 1273: Profile/Wallet guard proof.
- 1274: desktop profile access check.
- 1275: browser no-tg_id profile state.
- 1276: TypeScript proof.
- 1277: targeted pytest proof.
- 1278: route smoke proof.
- 1279: visual checklist update.
- 1280: Profile/Wallet verdict.

## 1281-1300 HUB, Browser-Shop and interactions

- 1281: HUB final two-card bridge polish.
- 1282: Browser-Shop storefront hero polish.
- 1283: Browser-Shop product card polish.
- 1284: Browser-Shop payment state cleanup.
- 1285: wallet-open failure recovery.
- 1286: public button inventory.
- 1287: primary / secondary / hidden classification.
- 1288: dead-button feedback repair.
- 1289: disabled reason copy.
- 1290: compact toast system.
- 1291: async pending state guard.
- 1292: no payload / token / memo public leak guard.
- 1293: route button map.
- 1294: click-flow matrix.
- 1295: TypeScript proof.
- 1296: targeted pytest proof.
- 1297: route smoke proof.
- 1298: Browser/PWA shell proof if possible.
- 1299: reports and NORM update.
- 1300: interaction verdict.

## 1301-1325 visual polish wave

- 1301: spacing rhythm pass.
- 1302: typography rhythm pass.
- 1303: icon and coin visual rhythm.
- 1304: cards glow and border pass.
- 1305: progress bars consistency pass.
- 1306: mobile 360 px pass.
- 1307: desktop centered frame pass.
- 1308: FAQ final compact pass.
- 1309: Withdraw placement review.
- 1310: Ads route placement under Tasks review.
- 1311: all public strings technical-language audit.
- 1312: all public empty states audit.
- 1313: all public loading states audit.
- 1314: all public error states audit.
- 1315: all public buttons audit.
- 1316: bottom menu tap target audit.
- 1317: Telegram safe-area audit.
- 1318: browser safe-area audit.
- 1319: PWA icon and manifest audit.
- 1320: service worker API safety audit.
- 1321: no external Dragon asset audit.
- 1322: visual proof checklist.
- 1323: NORM update.
- 1324: Healer update.
- 1325: polish verdict.

## 1326-1350 release evidence and hardening

- 1326: frontend static guard pack.
- 1327: public visual blocker guard pack.
- 1328: TypeScript noEmit.
- 1329: npm build with real exit code.
- 1330: Docker frontend proof if environment allows.
- 1331: direct browser route proof if environment allows.
- 1332: Telegram WebApp route proof from user log or local evidence.
- 1333: PWA installability checklist.
- 1334: route registry update.
- 1335: frontend call matrix update.
- 1336: SSOT route table update if changed.
- 1337: tests catalog update.
- 1338: reports index update.
- 1339: Q/A register update.
- 1340: ZIP hygiene cleanup.
- 1341: FLAT ZIP proof.
- 1342: no economic route drift check.
- 1343: no migration drift check.
- 1344: no admin function public leak check.
- 1345: no bottom menu rename check.
- 1346: no hidden function deletion check.
- 1347: final visual evidence audit.
- 1348: final unresolved proof list.
- 1349: corrected release readiness verdict.
- 1350: frontend 99 percent verdict.

---

## Источник: `WORK_CYCLES_1231-1350_DRAGON_VISUAL_FUNCTIONS_PLAN.md`


## v168_49 correction note

The previous Dragon-style compression went too far on the public first
screen.  The approved boundary is now restored: visual polish may
improve surfaces, but it must not add new Energy action entries or hide
core balances without chat approval.  HUB and Wallet/Profile entries are
not first-screen Energy actions.

## v168_44 cycles 1251-1260 note

Fresh log `logs_69555566503.zip` is green: all gate exit files are
zero, pytest reports 538 passed, npm build is green in GitHub CI and
backend security/static checks passed.  The pass therefore worked on
remaining visual and audit tails instead of log failures.

Closed cycle notes:

- 1251: Panels page uses compact list containment and GameDetails for
  activation context and per-panel technical details.
- 1252: Exchange page keeps the amount selector visible and moves
  advanced proof/withdraw detail into GameDetails drawers.
- 1253: Tasks page keeps active earning cards visible and moves the
  long help text into a compact GameDetails drawer.
- 1254: Referrals page keeps invite/share primary and moves system and
  level detail into compact drawers.
- 1255: Ranks page keeps the user card and podium visible, with the
  full table and extended leaderboard in drawers.
- 1256: Existing clean empty states are preserved and protected as the
  public fallback for inactive modules.
- 1257: Public loading/error states remain non-technical and use safe
  labels instead of raw exception text.
- 1258: All canonical route entry points remain intact.
- 1259: Added a static guard for GameDetails usage, route preservation
  and dependency warning tail closure.
- 1260: Documented compact proof and remaining proof boundary.

## v168_43 implementation note — cycles 1246-1250

The 1246-1250 part of the Dragon-style plan is implemented in EFHC
branding, not by copying Dragon assets.  Energy now has compact resource
chips for EFHC and kWh, a HUB bridge card, a Wallet/Profile card and an
action-count guard.  The canonical bottom menu is preserved.

# WORK CYCLES 1231-1350 — Dragon-style visual functions plan
Status: planned after reference sandbox intake cycle 1206.
Scope: visual and UX restructuring only. All EFHC functions,
economy, balances, bank ledger and backend roads remain EFHC.

## Purpose

Implement a Dragon-like compact game shell for EFHC without
copying the external brand.  EFHC keeps its identity: energy,
panels, kWh, EFHC, ranks, green economy and wallet safety.

## 1231-1240 reference intake and design tokens

- 1231: Document final Dragon reference UI principles for EFHC.
- 1232: Create EFHC visual token map for cards, glow, badges and bars.
- 1233: Define compact first-screen information hierarchy.
- 1234: Define progressive disclosure rules for all large pages.
- 1235: Map Dragon-style progress bars to EFHC energy progress.
- 1236: Map Dragon-style resource chips to EFHC, kWh and panels.
- 1237: Define icon and asset replacement plan using EFHC branding.
- 1238: Define mobile and desktop browser frame constraints.
- 1239: Create visual regression checklist for Dragon-style migration.
- 1240: Update Healer with risks of copying reference brand too closely.

## 1241-1260 compact home and first buttons

- 1241: Build compact EFHC game home skeleton behind existing route.
- 1242: Compress first-screen actions to a small visible action set.
- 1243: Move secondary actions into expandable cards or drawers.
- 1244: Add energy progress bar with kWh and active panels summary.
- 1245: Add rank/progress card with compact next-level signal.
- 1246: Add EFHC balance chip without exposing technical payment data.
- 1247: Add HUB card as one clean bridge action.
- 1248: Add Profile/Wallet entry as a compact card or chip.
- 1249: Keep existing bottom menu while testing compressed home.
- 1250: Add guard for maximum first-level public action count.
- 1251: Compress Panels page into summary plus expandable details.
- 1252: Compress Exchange page into amount selector plus
  advanced drawer.
- 1253: Compress Tasks page into active tasks and expandable archive.
- 1254: Compress Referrals page into invite card plus expandable stats.
- 1255: Compress Ranks page into progress ladder and details drawer.
- 1256: Add consistent empty states for inactive modules.
- 1257: Add compact error and loading states across user pages.
- 1258: Check all compressed pages keep existing route entry points.
- 1259: Add static guard for no hidden feature deletion.
- 1260: Document compact home proof and remaining blockers.

## 1261-1280 desktop/browser game shell

- 1261: Define browser desktop entry strategy for EFHC game shell.
- 1262: Add desktop-safe shell without Telegram-only hard dependency.
- 1263: Add centered PC game frame and responsive max width.
- 1264: Separate Telegram Mini App chrome from browser chrome.
- 1265: Add safe fallback for missing Telegram init data.
- 1266: Add browser route for read-only or limited game launch mode.
- 1267: Add auth/token requirement notes for money actions in browser.
- 1268: Add disabled-state explanations for browser-only
  unavailable actions.
- 1269: Ensure Direct Deposit still requires safe wallet flow.
- 1270: Ensure Browser-Shop remains separate from core game shell.
- 1271: Add desktop shell smoke guard for key routes.
- 1272: Add route audit for Telegram-only buttons in browser mode.
- 1273: Add visual tokens for desktop background and game frame.
- 1274: Add desktop profile entry and language dropdown access.
- 1275: Add desktop state banner for Telegram connection status.
- 1276: Add operator diagnostics for browser-shell launch state.
- 1277: Add docs for PC launch limitations and allowed actions.
- 1278: Run TypeScript proof for desktop shell paths.
- 1279: Run route proof for shell entry pages.
- 1280: Document desktop shell status without claiming full release.

## 1281-1300 interaction compression and button repair

- 1281: Inventory all public buttons and their handlers.
- 1282: Classify buttons as primary, secondary, hidden or admin-only.
- 1283: Add visible feedback for async buttons before API completion.
- 1284: Add disabled-state reason copy for wallet/token/TG requirements.
- 1285: Replace silent no-op patterns with visible user feedback.
- 1286: Audit MainButton Telegram handlers versus visible buttons.
- 1287: Move duplicate profile shortcuts into one compact
  profile surface.
- 1288: Move duplicate payment shortcuts into Wallet/Profile or HUB.
- 1289: Guard against public admin/debug controls outside admin.
- 1290: Guard against route buttons pointing to missing pages.
- 1291: Add click-flow static map for main pages.
- 1292: Add frontend call matrix for compact pages.
- 1293: Fix confirmed non-reactive buttons by route or feedback.
- 1294: Document which actions are intentionally disabled by state.
- 1295: Add compact toasts for common button outcomes.
- 1296: Add mobile tap target and spacing consistency check.
- 1297: Add keyboard/browser accessibility for desktop shell controls.
- 1298: Update visual NORM with compressed interaction rules.
- 1299: Update Healer with remaining interaction blockers.
- 1300: Create verdict for compression wave 1281-1300.

## 1301-1325 EFHC visual polish wave

- 1301: Introduce EFHC energy-card style across main pages.
- 1302: Introduce consistent progress-bar component for energy/rank.
- 1303: Introduce resource-chip component for EFHC, kWh and panels.
- 1304: Introduce action-card component for first-level actions.
- 1305: Introduce drawer component for secondary details.
- 1306: Migrate HUB visuals to match compact action-card style.
- 1307: Migrate Direct Deposit visuals to compact safe-payment style.
- 1308: Migrate Browser-Shop cards to EFHC storefront style.
- 1309: Migrate Profile top zone to compact account style.
- 1310: Migrate Wallet section to compact security style.
- 1311: Migrate History section to compact operation timeline.
- 1312: Migrate Panels page to energy-machine style.
- 1313: Migrate Exchange page to simple converter style.
- 1314: Migrate Tasks page to reward-card style.
- 1315: Migrate Referrals page to invite-growth style.
- 1316: Migrate Ranks page to ladder/progress style.
- 1317: Add consistent skeleton loading UI.
- 1318: Add consistent empty states for no panels/tasks/referrals.
- 1319: Add error cards with one recovery action.
- 1320: Add language dropdown consistency in desktop and mobile shells.
- 1321: Add visual guard for no technical words in compact UI.
- 1322: Add screenshot checklist for compact home and storefront.
- 1323: Update docs with final component naming.
- 1324: Update reports with polish wave evidence.
- 1325: Create polish wave verdict without CI green claim.

## 1326-1350 release evidence and hardening

- 1326: Run static guard pack for public visual blockers.
- 1327: Run static guard pack for compact button routes.
- 1328: Run TypeScript proof for compact shell changes.
- 1329: Run focused tests for payment and profile language roads.
- 1330: Regenerate frontend call matrix for compact pages.
- 1331: Regenerate route registry evidence.
- 1332: Update ROAD_INTEGRITY_MATRIX for visual shell routes.
- 1333: Update API_CONTRACTS only where contracts changed.
- 1334: Update VISUAL_FRONTEND_PUBLIC_UI_NORM.
- 1335: Update TESTS_CATALOG with all Dragon-style guards.
- 1336: Update Q/A register with approved iteration answers.
- 1337: Update Healer with closed and open visual blockers.
- 1338: Update reports index and change reports.
- 1339: Check ZIP hygiene and junk exclusion.
- 1340: Check no external Dragon brand assets entered EFHC archive.
- 1341: Check no EFHC economic routes were changed by visual work.
- 1342: Check admin diagnostics still contains moved technical data.
- 1343: Check public UI has no endpoint/debug/truth-layer leaks.
- 1344: Check browser shell has fallback for missing Telegram runtime.
- 1345: Check desktop route opens without Telegram-only crash.
- 1346: Check Browser-Shop remains separate external storefront.
- 1347: Prepare final visual evidence audit.
- 1348: Prepare corrected range verdict for 1231-1350.
- 1349: List not-proven items requiring user browser/CI proof.
- 1350: Issue final Dragon-style visual integration verdict.

## Non-goals

- Do not copy Dragon brand, names or copyrighted assets.
- Do not remove EFHC functions during visual compression.
- Do not change bank ledger or EFHC economic canon.
- Do not claim GitHub CI green without user logs.

## v168_25 clarification

The Dragon-style program is visual only.

Canonical EFHC navigation remains:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

The first screen remains the Energy/progress/generation screen.
It is not a first-action button screen.

Future Dragon-style work must adapt:

- game cards;
- progress bars;
- compact subsections;
- desktop browser shell;
- Web3-like storefront path through HUB.

It must not rename or collapse canonical EFHC pages.

## v168_26 correction after user answers

The Dragon-style program must not replace EFHC navigation.
The six bottom buttons remain canonical.
Energy remains the first screen.

Dragon-style migration is now defined as:

- visual tokens;
- compact cards;
- progress bars;
- resource chips;
- browser/PWA shell;
- Web3-style Browser-Shop through HUB;
- no route/name/function removal without separate approval.

Full Dragon code was not fully readable in the current sandbox because
RAR text extraction needs an external backend.  The visible file
list and assets still support the browser-app conclusion.
It is a web bundle with Telegram integration plus install/PWA-style
resources.


## Correction from cycle 1211

Dragon-style implementation means visual compression, game feedback,
progressive disclosure and browser/PWA shell behavior.  It does not mean
renaming EFHC sections, merging canonical pages or exposing hidden
Energy progression levels in Ranks.

Future Dragon-style cycles must respect:

- Energy remains Energy;
- Panels remains Panels;
- Exchange remains Exchange;
- Tasks remains Tasks;
- Referrals remains Referrals;
- Ranks remains Ranks;
- approvals are made in chat first.

## v168_29 WebApp/PWA target

Long-range Dragon-style work must produce an EFHC web application that
opens both inside Telegram and directly in a normal browser.  Browser
installation is handled by the system browser install prompt through the
PWA manifest/service-worker layer.

Do not add a separate fake install button unless the user approves it in
chat.

## v168_40 implementation sync

Cycles 1231-1232 are now actual code cycles, not only plan text.

### Cycle 1231 result

- Attempted public tunnel live-check.
- Result: `502 Bad Gateway`; no live proof claimed.
- FAQ overflow blocker fixed with application-frame containment.

### Cycle 1232 result

- Wallet route page continued into EFHC Game UI Kit style.
- HUB rebuilt with Game UI Kit primitives.
- Browser-Shop rebuilt with Game UI Kit storefront primitives.
- Public raw storefront error text hidden.

### Remaining visual road

- 1233-1235: Wallet state-map and TonConnect proof UI.
- 1236-1238: Browser-Shop checkout state proof.
- 1239-1240: HUB handoff proof and Admin diagnostics split.
- 1241-1260: live browser/Docker proof waves.

## 1233-1235 Wallet/TonConnect runtime state layer

Status: done as v168_41 foundation.

- Wallet state-map is now visible in `/web-profile`.
- TonConnect proof UI has explicit public states.
- Browser-Shop and HUB remain on Game UI Kit path.
- Next step is live runtime proof and then deeper visual polish.

## v168_42 execution update

The 1236-1245 slice was executed as a combined log-repair and visual
polish pass.

- Resource/status chip direction was started with `GameStatusPill`.
- Wallet state-map now has compact visual state rows.
- Browser-Shop hero now exposes a clean runtime state pill.
- HUB keeps pending/disabled state coverage while staying a bridge.
- Browser-Shop TON-only MVP boundary was restored after guard drift.
- Route and DB SSOT documents were re-synced to current CSV truth.

Cycles 1246-1250 remain open for live visual proof and deeper polish.

---

## Источник: `WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md`

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / CYCLE EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.


# План циклов 1268-1320: восстановление и интеграция frontend

Статус: detailed implementation plan.
Дата: 2026-05-20.
Архивная версия: v168_67.

## 1. Понимание цели

Frontend EFHC Bot больше нельзя лечить как набор отдельных визуальных
правок. Это восстановление функционального канона приложения.

Цель: привести EFHC Bot к состоянию игрового WebApp/PWA, который:

- открывается в Telegram и браузере;
- в браузере показывает login/demo, а не белый экран;
- сохраняет каноническое нижнее меню из шести кнопок;
- не прячет важные функции;
- не выводит технический мусор в публичный UI;
- использует Dragon/Web3 направление только как визуальную логику;
- хранит спорные решения только после согласования в чате.

## 2. Остались ли вопросы

Для начала кодовых циклов критических вопросов нет. Достаточно данных,
чтобы начинать восстановление.

Остаются только отложенные вопросы, которые не блокируют первые циклы:

- как именно возвращать USDT в Browser-Shop: сразу или после аудита
  payment-road;
- нужен ли будущий отдельный bonus packages pass;
- какие точные assets использовать для больших Web3-картинок Shop,
  если текущих будет недостаточно.

Эти вопросы не мешают начинать с login, Energy, Panels, Exchange,
Tasks, Referrals, Ranks, Profile, Wallet, History, HUB и Admin.

## 3. Главный порядок работы

Не переписывать весь frontend сразу. Каждый цикл должен иметь:

- выбранный экран или слой;
- что сломано;
- что восстанавливаем;
- какие файлы трогаем;
- какие данные нельзя потерять;
- какой guard добавляем;
- какие проверки запускаем;
- что не заявляем без live-proof.

## 4. Циклы 1268-1270: контроль перед кодом

### 1268 — frontend source canon freeze

Цель: зафиксировать рабочий источник правды перед кодом.

Сделать:

- перечитать `FRONTEND_FUNCTION_RECOVERY_CANON.md`;
- перечитать `FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md`;
- перечитать древние page-source документы;
- проверить, что PDF-первоисточники не хранятся в архиве;
- создать generated JSON по обязательным элементам экранов.

Guard:

- тест на наличие `FRONTEND_FUNCTION_RECOVERY_CANON.md`;
- тест, что PDF-первоисточники отсутствуют;
- тест, что Q/A и transcript обновлены.

### 1269 — page element matrix

Цель: создать машинно-проверяемую матрицу экранов.

Сделать:

- Energy mandatory/forbidden matrix;
- Panels mandatory/forbidden matrix;
- Exchange mandatory/forbidden matrix;
- Tasks mandatory/forbidden matrix;
- Referrals mandatory/forbidden matrix;
- Ranks mandatory/forbidden matrix;
- Profile/Wallet/History matrix;
- HUB/Shop/Admin matrix.

Guard:

- проверка, что матрица содержит все публичные экраны;
- проверка, что Energy не содержит HUB/Profile/Wallet cards;
- проверка, что Exchange forbids transfers.

### 1270 — visual token and shell lock

Цель: закрепить визуальную основу перед правками страниц.

Сделать:

- проверить dark theme tokens;
- проверить button sizes;
- проверить card spacing;
- проверить mobile width;
- проверить no-horizontal-scroll rules;
- закрепить одинаковый размер HUB-кнопок.

Guard:

- CSS marker guard для shell, buttons, card, progress;
- forbidden text guard для public debug phrases.

## 5. Циклы 1271-1274: Browser/PWA login и no blank screen

### 1271 — browser login page

Цель: заменить белый экран на красивую страницу входа.

Сделать:

- создать browser login page;
- добавить кнопку входа через Telegram;
- добавить demo-preview Energy ниже;
- не показывать fake account;
- не блокировать Telegram WebApp.

Guard:

- без `tg_id` не должно быть white screen;
- login page имеет dark shell;
- demo-preview не показывает fake balances как реальные.

### 1272 — Telegram/browser parity gate

Цель: одинаковая структура приложения в Telegram и браузере.

Сделать:

- проверить entry flow Telegram;
- проверить entry flow browser;
- проверить PWA manifest;
- проверить service worker только как shell-layer.

Guard:

- route checker для Telegram/browser paths;
- no Telegram-only crash guard.

### 1273 — splash and loading repair

Цель: загрузка не должна зависать.

Сделать:

- splash только до готовности shell;
- fallback словаря;
- dark first paint;
- no raw i18n keys.

Guard:

- raw i18n key scan;
- dark first screen CSS marker.

### 1274 — PWA install policy

Цель: установка только системной кнопкой браузера.

Сделать:

- убрать собственные install buttons, если найдены;
- добавить только подсказку без кнопки, если нужна;
- документировать системный способ установки.

Guard:

- no custom install button marker.

## 6. Циклы 1275-1278: Energy

### 1275 — Energy canonical composition

Цель: Energy как главный экран генерации.

Сделать:

- оставить generated kWh как центр;
- показать available kWh;
- показать progress-bar;
- показать kWh per second всех активных панелей;
- показать VIP как статус;
- не показывать balances как центр;
- не показывать referrals/ranks/tasks/shop cards.

Guard:

- forbidden Energy cards guard;
- mandatory Energy labels guard.

### 1276 — Energy header balance boundary

Цель: баланс виден в верхней панели, но не ломает Energy.

Сделать:

- проверить header balance;
- убрать main/bonus/total из central Energy, если они там есть;
- оставить `available kWh` на Energy.

Guard:

- balance placement guard.

### 1277 — Energy VIP status and generation chips

Цель: закрепить только каноничные чипы Energy.

Сделать:

- active panels chip;
- generation rate chip;
- available kWh chip;
- VIP только как статусная надпись;
- не возвращать HUB, Wallet, Shop, Tasks, Ranks или Referrals;
- не превращать VIP в отдельный action/block на Energy.

Guard:

- Energy chip count guard;
- VIP status-only guard;
- forbidden Energy action guard.

### 1278 — Energy mobile proof pass

Цель: первый экран читается на смартфоне.

Сделать:

- 390px mobile audit;
- no horizontal scroll;
- progress visible;
- buttons aligned;
- no debug text.

Guard:

- screenshot QA checklist update.

## 7. Циклы 1279-1285: Panels

### 1279 — Panels active/archive layout

Цель: активные панели первыми, архивные через переключение.

Сделать:

- кнопки `Active` / `Archive` или RU по admin/player canon;
- частичный список на основной странице;
- возможность перейти к полному списку, если это безопасно;
- не делать хаос из вкладок.

Guard:

- active/archive controls exist;
- no tg_id public leak.

### 1280 — panel activation CTA

Цель: одна главная кнопка активации панели.

Сделать:

- `Активировать панель` / canonical label;
- списание bonus first, then main;
- не прятать цену 100 EFHC;
- не менять экономику.

Guard:

- panel price marker;
- bonus-first main-second guard.

### 1281 — panel countdown model audit

Цель: найти текущую модель даты активации/деактивации.

Сделать:

- проверить backend fields;
- проверить frontend card fields;
- найти, где потерян countdown;
- составить migration-safe plan, если полей нет.

Guard:

- audit only, без изменения БД без необходимости.

### 1282 — panel countdown backend/source repair

Цель: вернуть данные для обратного отсчёта.

Сделать:

- activation date;
- deactivation date;
- remaining seconds;
- server/source calculation;
- не использовать age вместо remaining time.

Guard:

- remaining seconds test;
- no days-active-only marker.

### 1283 — panel countdown UI

Цель: показать дни/часы/минуты и runtime countdown.

Сделать:

- карточка панели показывает дату активации;
- карточка показывает дату деактивации;
- карточка показывает `осталось`;
- runtime tick обновляет countdown;
- генерация kWh получает секунды.

Guard:

- UI source marker;
- TypeScript proof.

### 1284 — Panels generation summary

Цель: общая генерация всех панелей в hero.

Сделать:

- total active generation rate;
- active panels count;
- no VIP block;
- no daily generation per panel.

Guard:

- mandatory hero fields.

### 1285 — Panels proof pass

Цель: закрыть Panels как восстановленный слой.

Сделать:

- route proof;
- visual checklist;
- backend/frontend contract proof;
- report.

## 8. Циклы 1286-1290: Exchange

### 1286 — exchange transfer ban

Цель: жёстко запретить переводы EFHC между пользователями.

Сделать:

- найти UI/route traces transfer;
- удалить/скрыть только после проверки;
- закрепить запрет в guard.

Guard:

- no transfer button;
- no transfer route in public UI.

### 1287 — exchange kWh to EFHC only

Цель: только обмен kWh → EFHC.

Сделать:

- строка `1 kWh = 1 EFHC`;
- input доступных kWh;
- кнопка Convert;
- кнопка Max;
- no extra explanation overload.

Guard:

- rate marker;
- Max button marker.

### 1288 — exchange history link

Цель: история не мешает, но доступна.

Сделать:

- ненавязчивая кнопка перехода в History;
- не делать отдельную heavy history на Exchange.

Guard:

- link exists, no table overload.

### 1289 — exchange route and contract proof

Цель: не вернуть tg_id/path drift.

Сделать:

- current-user route proof;
- no user transfer proof;
- no path tg_id leaks.

Status v168_87 / cycle 1289: completed.

Result:

- Exchange route-contract proof markers added;
- generated current-user seams are locked;
- `tg_id`/`user_id` path drift is guarded;
- user-transfer roads are guarded as forbidden.

### 1290 — Exchange visual proof

Цель: компактный экран обмена.

Сделать:

- mobile proof;
- no debug;
- no VIP block;
- no overload.

## 9. Циклы 1291-1294: Tasks

### 1291 — Tasks list-card layout

Цель: список заданий как гармоничные карточки.

Сделать:

- задание;
- награда;
- кнопка действия;
- без лишней истории;
- без перегруза статусами.

Guard:

- no task history public block.

Status v168_89 / cycle 1291: completed.

Result:

- `/tasks` has compact earning-card markers;
- public technical/idempotency help block was removed;
- cards keep title, description, reward, compact status, human help and primary action;
- no task history/log surface was added.

### 1292 — Ads task action

Цель: кнопка `Смотреть рекламу` сразу открывает ads.

Сделать:

- проверить ads route/action;
- не добавлять лишнее предупреждение;
- дать feedback только если действие не сработало.

Guard:

- ads button action marker.

Status v168_90 / cycle 1292: completed.

Result:

- ad task cards keep the primary `watch-ad` action;
- the extra confirmation gate before ad opening was removed;
- `/ads/slot` is called without public `tg_id` or `user_id` query leak;
- the ad modal has a direct-open marker;
- user feedback is shown when the ad action fails, not as an extra warning before opening.

### 1293 — hidden task execution log boundary

Цель: история выполнений скрыта от пользователя.

Сделать:

- backend/log сохраняет double-claim protection;
- frontend не показывает историю заданий;
- admin/logs может видеть служебные следы.

Guard:

- hidden history guard.

Status v168_91 / cycle 1293: completed.

Result:

- `/tasks` remains clean player-facing earning UI;
- public task execution history/log/debug surfaces are not rendered;
- backend double-claim protection remains internal through locks, bonus logs, submissions and idempotency paths;
- admin/operator task traces remain available through admin task submissions and `/admin/logs/transfers?reason=task_bonus`;
- `test_tasks_hidden_execution_log.py` protects the boundary.

### 1294 — Tasks proof pass

Цель: Tasks не перегружен и работает.

Сделать:

- route proof;
- TypeScript;
- visual checklist.

Status v168_92 / cycle 1294: completed.

Result:

- `/tasks` has `data-tasks-proof-pass="1294"`;
- public Tasks stays a clean earning screen;
- no public task history, backend log or debug block is rendered;
- static route proof is protected by `test_tasks_proof_pass.py`.


## 10. Циклы 1295-1302: Referrals и Ranks

### 1295 — Referrals invite block

Цель: реферальная ссылка как главный элемент.

Сделать:

- link;
- copy;
- share;
- social sharing;
- не показывать tg_id.

Status v168_92 / cycle 1295: completed.

Result:

- the invite card has explicit link/copy/share proof markers;
- frontend stats call uses `/referrals/stats/me`;
- no public referral stats URL is built with `parent_tg_id`, `tg_id` or `user_id`;
- backend exposes `/referrals/stats/me` through `get_current_tg_id`;
- legacy stats route remains only for compatibility and sends a deprecation header.

Guard:

- no tg_id public marker;
- current-user stats route guard.


Guard:

- no tg_id public marker.

### 1296 — active/inactive referrals

Цель: пользователь видит, за кого начислен бонус.

Сделать:

- active list;
- inactive list;
- buttons to switch;
- username only;
- Active status persists after first panel purchase.

Status v168_92 / cycle 1296: completed.

Result:

- active/inactive list calls use `/referrals/active/me` and `/referrals/inactive/me`;
- frontend no longer builds list URLs with `parent_tg_id`;
- rows display username or neutral user fallback, not tg_id;
- list card has `data-referrals-active-inactive-boundary="1296"`;
- backend exposes current-user active/inactive routes and keeps legacy routes deprecated.

Guard:

- active status source marker;
- no tg_id marker;
- current-user list route guard.


Guard:

- active status source marker;
- no tg_id marker.

### 1297 — referral progress and levels

Цель: главный сектор реферальной системы.

Status v168_93 / cycle 1297: completed.

Result:

- referral progress moved into a visible main card;
- progress bar, level, achievements and next-level values are present;
- guard protects the progress/levels boundary.

Guard:

- progress exists;
- no hidden main referral progress.

### 1298 — referral bonus wording

Цель: простая формула `+0.1 EFHC`.

Status v168_93 / cycle 1298: completed.

Result:

- `+0.1 EFHC` is explained in the rules/progress block;
- every referral row remains clean and is not overloaded by repeated
  bonus text;
- bonus wording says active referrals only.

Guard:

- bonus copy marker.

### 1299 — Ranks card layout

Цель: вертикальные карточки игроков.

Status v168_93 / cycle 1299: completed.

Result:

- rank rows are vertical player cards;
- cards show position, username/neutral fallback, score and VIP;
- raw tg_id fallback was removed from the public UI.

Guard:

- no table-only fallback;
- no tg_id.

### 1300 — Ranks filters

Цель: только `kWh` и `Referrals`.

Status v168_93 / cycle 1300: completed.

Result:

- Ranks has exactly two public filters: `kWh` and `Referrals`;
- no week/all-time filter was added;
- kWh and referral rank modes use current-user backend routes.

Guard:

- filters exact marker.

### 1301 — show me in Ranks

Цель: показать пользователя и конкурентов рядом.

Status v168_93 / cycle 1301: completed.

Result:

- `Показать меня` remains as the public action;
- button scrolls to the user card;
- focused view keeps a nearby competitor window around the user.

Guard:

- source marker or test for action presence.

### 1302 — Ranks proof pass

Цель: Ranks соответствует канону.

Status v168_93 / cycle 1302: completed.

Result:

- Ranks has no 12 Energy levels catalog;
- Ranks uses vertical cards;
- filters are exactly kWh/referrals;
- no raw tg_id/user_id path or query is used by the frontend.

## 11. Циклы 1303-1310: Profile, Wallet, History, FAQ

### 1303 — Profile status model

Цель: Profile показывает VIP и Active как постоянные статусы.

Сделать:

- VIP indicator always visible;
- Active indicator always visible;
- inactive state grey;
- active state green/gold;
- no technical labels.

Guard:

- no `Browser ready`, `PWA`, `independent shell` public text.

### 1304 — Profile FAQ button

Цель: Profile содержит только кнопку на полный FAQ.

Сделать:

- remove embedded mini FAQ if present;
- add clean button to `/faq`;
- no design over function.

Guard:

- FAQ button marker.

### 1305 — Wallet as wallet list

Цель: Wallet — только подключённые кошельки.

Сделать:

- list connected wallets;
- add/manage/remove primary wallet actions;
- no general account history inside Wallet;
- no large status dashboard.

Guard:

- no History block in Wallet.

### 1306 — wallet error microcopy

Цель: только понятный минимум для ошибок подключения.

Сделать:

- short error notice if connect fails;
- no technical payload;
- no state-map dashboard.

Guard:

- no raw wallet error payload.

### 1307 — History account timeline

Цель: общая история аккаунта.

Сделать:

- filters: All, Purchases, Exchange, Withdraw, Bonuses, Panels;
- include purchases, exchanges, withdraws, bonuses, panels;
- not wallet-specific.

Guard:

- history filters marker.

### 1308 — History data contract audit

Цель: понять, какие backend endpoints уже есть.

Сделать:

- map history endpoints;
- no fake data;
- if endpoint missing, document blocker before UI claim.

### 1309 — FAQ full list compact tree

Цель: FAQ функционален и компактен.

Сделать:

- all sections visible as list;
- vertical expand;
- no pills/categories;
- no overflow;
- language follows current lang.

Guard:

- no FAQ pills marker;
- compact tree marker.

### 1310 — Profile/Wallet/FAQ proof pass

Цель: закрыть профильный контур.

Сделать:

- route proof;
- TypeScript;
- visual checklist.

## 12. Циклы 1311-1316: HUB, Browser-Shop, USDT

### 1311 — HUB two equal buttons

Цель: HUB строго две одинаковые кнопки.

Сделать:

- `Пополнить EFHC`;
- `EFHC VIP NFT`;
- equal width/height;
- equal descriptions;
- no third point without chat approval.

Guard:

- HUB button count exactly two;
- equal class marker.

### 1312 — VIP NFT link policy

Цель: VIP NFT — ссылка на сайт/GetGems.

Сделать:

- no heavy NFT panel;
- no separate NFT admin panel;
- text `EFHC VIP NFT`;
- link only.

Guard:

- no public NFT debug.

### 1313 — Browser-Shop Web3 cards

Цель: крупные Web3-карточки товаров.

Сделать:

- large image/card frame;
- product title;
- price;
- payment button;
- no wallet/memo/copy/raw.

Guard:

- no raw payment technical fields.

### 1314 — EFHC for TON payment

Цель: TON purchase остаётся рабочей.

Сделать:

- check current TON flow;
- status human text;
- no technical payload.

Guard:

- TON route proof.

### 1315 — USDT payment road audit

Цель: объяснить и согласовать возврат USDT.

Сделать:

- найти backend routes;
- найти watcher support;
- найти current shop product model;
- вывести пользователю простой вопрос перед UI.

Не делать:

- не показывать сломанную USDT кнопку как готовую.

### 1316 — Browser-Shop proof pass

Цель: Web3-shop без технического мусора.

Сделать:

- no bottom menu;
- no Mini App layout;
- cards proof;
- payment status proof.

## 13. Циклы 1317-1320: Admin

### 1317 — Admin home app grid

Цель: главная Admin как список разделов.

Сделать:

- Users;
- Bank;
- Withdrawals;
- Shop;
- Tasks;
- Reports;
- Diagnostics;
- System;
- no debug dump.

Guard:

- no raw debug on Admin home.

### 1318 — Admin functional page template

Цель: каждая функция Admin имеет структуру.

Сделать:

- график/статистика сверху;
- действия и таблицы ниже;
- отдельный route per function;
- Russian admin UI.

Guard:

- template component marker.

### 1319 — Admin routes map

Цель: понять все существующие backend/admin routes.

Сделать:

- route inventory;
- UI section mapping;
- no route deletion without approval;
- missing page list.

### 1320 — Admin proof and next plan

Цель: зафиксировать готовность к следующей фазе.

Сделать:

- visual audit;
- route proof;
- next cycles 1321-1350 if needed;
- no release-ready claim without live proof.

## 14. Проверки каждого code cycle

Минимум:

- `python3 ops/local/check_frontend_routes.py`;
- `python3 -m compileall -q ops/local tests/architecture`;
- targeted architecture tests;
- `tsc --noEmit`, если frontend менялся;
- locale JSON validation, если менялись тексты;
- ZIP `unzip -t`.

Дополнительно для live/UI:

- screenshot QA mobile;
- screenshot QA desktop;
- Docker runtime smoke;
- no white screen proof.

## 15. Запрещено

- не возвращать старые PDF как канон;
- не хранить PDF-первоисточники;
- не задавать вопросы, если ответ уже есть в Q/A;
- не писать `объяснение в файле` вместо объяснения в чате;
- не добавлять новые Energy cards;
- не показывать transfers в Exchange;
- не показывать tg_id пользователям;
- не выводить debug dump в публичный UI;
- не делать fake release-ready.


## v168_68 status update

Cycles 1268-1270 are completed as control-layer cycles. No frontend or
backend code was changed. The next implementation cycle is 1271:
browser login page and no white screen.

## v168_69 status update

Cycle 1271 is completed as the first practical frontend code pass after
control freeze. A browser login/demo panel was added for
browser/PWA mode
when Telegram user data is absent. The panel does not replace the app:
it sits above the normal demo Energy/content layer and prevents blank or
white-screen perception.

Next cycle: 1272 — no-white-screen first paint guard and dark browser
boot proof.

## v168_70 — cycle 1272 completed

Статус: выполнено.

Сделано:

- добавлен dark first paint guard на уровне `document.tsx`;
- добавлен `#__next` dark shell в global CSS;
- добавлен splash timeout escape в `app.tsx`;
- добавлен marker `data-efhc-shell` через React dataset;
- добавлен guard `test_first_paint_guard.py`.

Назначение: browser/PWA больше не должен показывать белый или пустой
первый экран, если Telegram-данные, словари или snapshot временно не
готовы.

Следующий цикл: 1273 — splash/loading repair и raw i18n key scan.


## Cycle status addendum — v168.71

Cycle 1273 is completed as splash/loading and raw i18n guard.
The startup shell now has named timeout constants and explicit
booting/ready CSS state. Missing i18n keys that look technical no
longer fall through as raw public strings. The next planned cycle is
1274: PWA install policy lock.

## v168_72 — cycle 1274 completed

Cycle 1274 is completed as the PWA install policy lock.

Result:

- browser/PWA installation remains controlled by browser/system UI;
- no custom EFHC install button is allowed without chat approval;
- no active custom install button was found in frontend source;
- a guard was added for future install-button drift;
- no runtime frontend/backend code was changed.

Next cycle: 1275 — Energy canonical composition.


## v168_73 — cycle 1275 completed

Статус: выполнено.

Сделано:

- Energy приведён к канонической композиции главного экрана;
- центр экрана оставлен за generated kWh;
- сохранены progress bar, available kWh и kWh per second;
- VIP показывается только как статусная надпись, если активен;
- main balance, bonus balance и EFHC balance убраны из центральной
  композиции Energy, потому что баланс относится к верхней панели;
- base rate и exchanged total убраны из Energy как перегруз;
- HUB, Wallet/Profile, Tasks, Shop, Ranks и Referrals не добавлялись;
- добавлен guard `test_energy_canonical_composition.py`.

Следующий цикл: 1276 — Energy header balance boundary.

## v168_74 — cycle 1276 completed

Статус: выполнено.

Сделано:

- закреплена граница баланса Energy/header;
- баланс аккаунта остаётся в верхней панели приложения;
- центр Energy остаётся за генерацией kWh и прогрессом;
- `GlobalHeader` получил явные boundary markers;
- Energy не получил main/bonus/total balance props;
- добавлен guard `test_energy_header_balance_boundary.py`.

Назначение: не дать будущим правкам снова превратить Energy в
балансовый дашборд. Energy показывает генерацию, а общий EFHC balance
живёт в глобальной верхней панели.

Следующий цикл: 1277 — Energy VIP status and generation chips.

Cycle 1276 proof phrase: balance in the global header, not in the
Energy center.


## v168_75 — cycle 1277

Статус: выполнено.

Сделано:

- Energy получил явные маркеры для трёх каноничных чипов;
- active panels, generation rate и available kWh защищены тестом;
- VIP зафиксирован как статусная надпись, а не action-card;
- центральная композиция Energy не получила HUB, Wallet, Shop,
  Tasks, Ranks или Referrals.

Следующий цикл: 1278 — Energy mobile proof pass.

## v168_76 — cycle 1278

Статус: выполнено.

Сделано:

- Energy получил mobile-proof markers для 390px viewport;
- добавлен 390px CSS-блок для читаемости первого экрана;
- закреплены max-width/min-width правила против horizontal scroll;
- кнопки Panels и Exchange сохранены как две ровные action cards;
- progress bar и три каноничных чипа остаются видимыми;
- добавлен guard `test_energy_mobile_proof.py`.

Следующий цикл: 1279 — Panels active/archive layout.

Cycle 1278 proof phrase: Energy is readable at 390px without
horizontal scroll and without extra action cards.

## v168_77 — cycle 1279

Статус: выполнено.

Сделано:

- Panels получил явный active/archive layout marker;
- active/archive переключатель закреплён как segmented layout;
- список панелей получил tab-aware marker;
- карточки панелей получили tab-aware marker;
- кнопки Active/Archive выровнены по высоте и ширине;
- список панелей защищён от overflow;
- public `tg_id` path leak на Panels не возвращался;
- добавлен guard `test_panels_active_archive_layout.py`.

Следующий цикл: 1280 — panel activation CTA.

Cycle 1279 proof phrase: Panels has a guarded active/archive segmented
layout without public `tg_id` paths.

## v168_78 — cycle 1280

Status: done.

Cycle 1280 completed the panel activation CTA lock.

Implemented:

- public Panels CTA has a guarded `100 EFHC` marker;
- activation note states bonus-first then main debit order;
- UI activation availability uses bonus plus main balance;
- locale keys were added for all active frontend locales;
- backend panel economy was not changed.

Added guard:

- `test_panel_activation_cta.py`.

Next cycle: 1281 — panel countdown model audit.

Cycle 1280 proof phrase: Panels activation is guarded as
100 EFHC with bonus-first/main-second debit order.


## v168_79 / cycle 1281 completion

Status: completed.

Result:

- backend date algorithm for panels was found;
- panel activation uses server `utcnow`;
- `expires_at` is server activation time plus 180 days;
- active/archive is based on `expires_at` vs server time;
- list response now exposes `public_id` and `activated_at`;
- no database or migration change was made.

Next cycle: 1282 — panel countdown backend/source repair.

## v168_80 / cycle 1282 completion

Status: completed.

Result:

- `remaining_seconds` is now part of the panel list contract;
- backend computes it from `expires_at` and `server_now_utc`;
- frontend stores `server_now_utc` from the panel list response;
- local time is only a display stopwatch after the server anchor;
- countdown display includes seconds;
- no database or migration change was made.

Next cycle: 1283 — panel card date display repair.
## v168_81 / cycle 1283 completion

Status: completed.

Result:

- panel cards now show the canonical panel ID field;
- activation date is visible on the card body;
- deactivation date is visible on the card body;
- generated kWh remains visible on the card body;
- live countdown remains visible on the card body;
- activation/deactivation dates are not hidden only in details;
- backend/database/migrations were not changed.

Next cycle: 1284 — panel countdown live display proof.

Cycle 1283 proof phrase: panel card date display keeps ID,
activation date, deactivation date, countdown, and generated kWh visible.


## v168_82 / cycle 1284 completion

Status: completed.

Result:

- panel countdown is guarded as a live display element;
- countdown field has an explicit live marker;
- countdown value updates through the one-second tick;
- `aria-live="polite"` is used for user-facing live changes;
- the server-now anchor remains the source of truth;
- local time is only a display stopwatch after the server anchor;
- backend/database/migrations were not changed.

Next cycle: 1285 — Panels activation/history boundary.

Cycle 1284 proof phrase: panel countdown is a live display, not a
static date or panel-age replacement.

## v168_83 / cycle 1285 completion

Status: completed.

Result:

- Panels now has an explicit account-history boundary;
- Panels keeps activation, active panels, archive panels and timers;
- Panels no longer opens Wallet from the panel context;
- History remains reachable as a small secondary action;
- History is recorded as account-level, not wallet-level;
- backend, database and migrations were not changed.

Next cycle: 1286 — Exchange kWh to EFHC only boundary.

Cycle 1285 proof phrase: Panels is not Wallet and not the account
History page; it only links to account History as a secondary action.

## v168_84 / cycle 1286 completion

Status: completed.

Result:

- Exchange now has an explicit kWh to EFHC only boundary;
- the visible surface keeps available kWh, input, Max, canonical rate,
  conversion action and a small account History link;
- Wallet/Withdraw blocks were removed from the Exchange page;
- percentage quick actions were removed as overload;
- transfer/user-recipient UI is not present on Exchange;
- backend, database and migrations were not changed.

Next cycle: 1287 — Exchange amount/preview polish.

Cycle 1286 proof phrase: Exchange is only kWh to EFHC at 1:1.


## v168_85 / cycle 1287 completion

Cycle: 1287 — Exchange amount/preview polish.

Status: completed.

Result:

- added visible amount label for Exchange;
- added sanitized decimal amount input;
- added 8-decimal precision limit;
- added one clear receive preview row;
- added human helper text for invalid and over-limit amounts;
- updated locale keys for all public locale JSON files;
- hidden Telegram Main Button on Exchange to avoid amount mismatch;
- copied `21.md` into `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/21.md`.

Boundary:

- no transfer;
- no withdraw;
- no wallet block;
- no VIP block;
- no percentage quick actions;
- no extra action-card overload.

Next cycle: 1288 — Exchange History link light boundary.

Cycle 1287 proof phrase: Exchange amount is simple, visible and 1:1.
## v168_86 / cycle 1288 — Exchange History link light boundary

Status: completed.

Result:

- the Exchange screen keeps access to common account History;
- the History entry is a light secondary navigation row;
- the link has explicit `data-exchange-history-link-light="1288"`;
- no heavy history table, filters or list were added to `/exchange`;
- all public locale files have `exchange.history_hint`;
- `exchange.open_history` was humanized outside English.

Boundary:

- Exchange remains kWh -> EFHC only;
- History remains account-level and external to the converter card;
- Exchange must not become a History/Wallet/Withdraw page.

Next cycle: 1290 — Exchange visual proof.

Cycle 1288 proof phrase: Exchange has History access without History
surface overload.


Exchange route and contract proof.

## v168_88 / cycle 1290 — AUDIT_TZ_v168_83 repair pass

Priority audit fixes were completed before moving to Tasks.
This cycle consumed the 1290 slot because the uploaded audit contained
critical/high visible defects in Profile, Panels, i18n, app shell and
backend route boundaries.

Original Exchange visual proof is not claimed as screenshot/runtime proof.
The Exchange boundary remains protected by cycles 1286-1289 guards.

## v168_94 implementation update — cycles 1303-1310

Completed in one pass:

- 1303 Profile status model;
- 1304 Profile FAQ button;
- 1305 Wallet as wallet list;
- 1306 wallet error microcopy;
- 1307 History account timeline;
- 1308 History data contract audit;
- 1309 FAQ full list compact tree;
- 1310 Profile/Wallet/FAQ proof pass.

The 1268-1320 frontend recovery range is closed. Next implementation cycle is 1321 — Users page statistics and actions audit.


## v168_95 cycles 1311-1320 result

Cycles completed in one pass:

- 1311 — HUB two equal buttons;
- 1312 — VIP NFT link policy;
- 1313 — Browser-Shop Web3 cards;
- 1314 — EFHC for TON payment;
- 1315 — USDT payment road audit;
- 1316 — Browser-Shop proof pass;
- 1317 — Admin home app grid;
- 1318 — Admin functional page template;
- 1319 — Admin routes map;
- 1320 — Admin proof and next plan.

Status: completed as a static/code-level pass.

Result:

- HUB public section is locked to exactly two equal actions: top up EFHC
  and EFHC VIP NFT;
- VIP NFT remains an external link policy and no heavy NFT/admin panel was
  introduced;
- Browser-Shop keeps large Web3 product cards and TON payment road proof;
- USDT road was audited, but no ready USDT button was exposed;
- Admin home starts with the canonical eight-section grid;
- a shared Admin functional page template was added;
- Admin route inventory was created without route deletion;
- the 1321-1350 Admin recovery extension plan was created.

Next cycle: 1321 — Users page statistics and actions audit.


## Historical work-pass markers restored for active architecture guards

v168_77 — work pass: Panels active/archive layout.
v168_80 / work pass: remaining_seconds panel countdown source.
v168_81 / work pass: panel card date display.
v168_82 / work pass: panel countdown live display.
v168_83 / work pass: Panels activation/history boundary with account history.
v168_84 / work pass: Exchange kWh to EFHC only boundary.
v168_85 / work pass: Exchange amount/preview polish.
v168_86 / work pass: Exchange History link light boundary, no heavy history.
v168_87 / work pass: Exchange route and contract proof.
v168_92 / work pass: Tasks proof pass, Referrals invite block, active/inactive referrals.
