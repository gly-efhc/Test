# Cycle 1508 — PACK-02 tails wallet canon cleanup

## Goal

Close two remaining PACK-02 tails:

1. Remove the active legacy admin wallet contour based on
   `efhc_core.crypto_wallets`.
2. Add an existing-database canonical backfill for old
   `wallet_bindings.wallet_address` values.

## Result

- `backend/app/services/admin/admin_wallets_service.py` was removed.
- `admin_facade.py` no longer imports or delegates to `AdminWalletsService`.
- `crypto_wallets` is marked as removed/deprecated/not active in the DB
  drift matrix.
- `0001_init.py` now contains `_backfill_wallet_bindings_canonical(conn)`.
- New guards protect both the legacy cleanup and canonical backfill.

## Safety

No EFHC economy, withdraw payout canon, admin payout canon, frontend
runtime, CI/workflow or dependency changes were made.
