# Рабочий цикл 1605 — Frontend GlobalId string system

Исходный HEAD: `EFHC_Bot_v172_01.zip`.
Целевой HEAD: `EFHC_Bot_v172_02.zip`.

## Цель

Создать канонический frontend-тип `GlobalId`, который сохраняет ведущие
нули и не может использоваться как JavaScript number либо как аргумент
арифметики. Одновременно оптимизировать roadmap по фактическим
архитектурным зависимостям.

## Реализация

- `GlobalId` — branded string;
- wire/display формат — ровно десять ASCII-цифр;
- `0000000000` запрещён;
- создание значения возможно только через `parseGlobalId` либо
  `globalIdFromApi`;
- `globalIdToApi` и `formatGlobalId` не меняют строку;
- стабильные коды ошибок находятся в пространстве
  `global_id.frontend.*`;
- guard запрещает `number`, `bigint`, numeric schema/conversion,
  arithmetic и unsafe casts.

## Граница цикла

Текущие Telegram-specific `tg_id: number` не заменяются механически.
API DTO и OpenAPI-wide migration относятся к циклу 1606. Session-first
frontend switch относится к циклу 1694.

## Оптимизация roadmap

Введены code line и data line, gates `PG-0…PG-4`, возможность безопасно
подготовить циклы 1606–1612 при недоступной БД и жёсткий запрет на
начало цикла 1613 без реального `PG-0 PASS`. Устранена логическая
инверсия между циклами 1679 и 1680 и повторный read switch в 1697.

## Следующий цикл

`1606 — API-контракт global_id`.

## Итог тестирования

- точная collection: `2881`;
- `PASSED`: `2709`;
- `SKIPPED`: `172`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Пропуски: 95 browser E2E, 72 real PostgreSQL integration,
4 Postgres-only CI и 1 проверка без `DATABASE_URL`.

Isolated TypeScript strict typecheck и runtime contract пройдены.
Полный Next.js typecheck/build не выполнен: локальный npm cache не
содержит архив `zod`, поэтому `npm ci --offline` завершился
`ENOTCACHED`. Release-assets проверены: 29 файлов. Performance budgets
не запускались без `.next/build-manifest.json`.

## PostgreSQL

Reconciliation gate повторно завершился кодом блокировки среды.
`historical_backfill`, `dual_write`, `read_switch` и
`financial_ownership_switch` остаются `false`.
