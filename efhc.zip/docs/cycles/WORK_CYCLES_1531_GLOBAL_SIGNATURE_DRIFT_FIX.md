# Cycle 1531 — Global Signature Drift Fix

Input HEAD: `v171.05`.
Output HEAD: `v171.06`.

## Purpose

Apply the global audit/TZ findings against `v171.05` and close the runtime
kwarg/signature mismatch class without changing EFHC economy, money-flow,
wallet binding, withdraw business logic or frontend runtime.

## Closed locally

- `P0-PANELS-PAGINATION-CURSOR-TYPEERROR`
- `P1-SCHEDULER-ARCHIVE-PANELS-DOUBLE-TYPEERROR`
- `P1-BOT-REFERRAL-STATS-TYPEERROR`
- `P1-BOT-RANKS-DOUBLE-BUG-SILENTLY-SWALLOWED`
- `P1-NFT-ROUTES-WALLET-HAS-NFT-TYPEERROR`
- `P2-ADMIN-FORMAT-DECIMAL-KWARG-MISMATCH`
- `P1-MYPY-SCOPE-TOO-NARROW` as staged scope expansion plus architecture
  guard

## Proof boundary

Targeted local tests passed. Full pytest was attempted but timed out in the
sandbox and is not claimed. `ruff`, `mypy` and `bandit` were unavailable
locally. Fresh GitHub CI for output `v171.06` is required.

## Release status

`NOT_RELEASE_READY`. Live Telegram and real TonConnect proof remain missing.
