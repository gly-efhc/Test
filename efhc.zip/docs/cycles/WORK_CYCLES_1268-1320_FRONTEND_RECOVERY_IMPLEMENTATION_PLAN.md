
# План циклов 1268-1320: восстановление и интеграция frontend

Статус: detailed implementation plan.
Дата: 2026-05-20.
Архивная версия: v168_67.

## 1. Понимание цели

Frontend EFHC Bot больше нельзя лечить как набор отдельных визуальных
правок. Это восстановление функционального канона приложения.

Цель: привести EFHC Bot к состоянию игрового WebApp/PWA, который:

- открывается в Telegram и браузере;
- в браузере показывает login/demo, а не белый экран;
- сохраняет каноническое нижнее меню из шести кнопок;
- не прячет важные функции;
- не выводит технический мусор в публичный UI;
- использует Dragon/Web3 направление только как визуальную логику;
- хранит спорные решения только после согласования в чате.

## 2. Остались ли вопросы

Для начала кодовых циклов критических вопросов нет. Достаточно данных,
чтобы начинать восстановление.

Остаются только отложенные вопросы, которые не блокируют первые циклы:

- как именно возвращать USDT в Browser-Shop: сразу или после аудита
  payment-road;
- нужен ли будущий отдельный bonus packages pass;
- какие точные assets использовать для больших Web3-картинок Shop,
  если текущих будет недостаточно.

Эти вопросы не мешают начинать с login, Energy, Panels, Exchange,
Tasks, Referrals, Ranks, Profile, Wallet, History, HUB и Admin.

## 3. Главный порядок работы

Не переписывать весь frontend сразу. Каждый цикл должен иметь:

- выбранный экран или слой;
- что сломано;
- что восстанавливаем;
- какие файлы трогаем;
- какие данные нельзя потерять;
- какой guard добавляем;
- какие проверки запускаем;
- что не заявляем без live-proof.

## 4. Циклы 1268-1270: контроль перед кодом

### 1268 — frontend source canon freeze

Цель: зафиксировать рабочий источник правды перед кодом.

Сделать:

- перечитать `FRONTEND_FUNCTION_RECOVERY_CANON.md`;
- перечитать `FRONTEND_RECOVERY_20_FOLLOWUP_ANSWERS.md`;
- перечитать древние page-source документы;
- проверить, что PDF-первоисточники не хранятся в архиве;
- создать generated JSON по обязательным элементам экранов.

Guard:

- тест на наличие `FRONTEND_FUNCTION_RECOVERY_CANON.md`;
- тест, что PDF-первоисточники отсутствуют;
- тест, что Q/A и transcript обновлены.

### 1269 — page element matrix

Цель: создать машинно-проверяемую матрицу экранов.

Сделать:

- Energy mandatory/forbidden matrix;
- Panels mandatory/forbidden matrix;
- Exchange mandatory/forbidden matrix;
- Tasks mandatory/forbidden matrix;
- Referrals mandatory/forbidden matrix;
- Ranks mandatory/forbidden matrix;
- Profile/Wallet/History matrix;
- HUB/Shop/Admin matrix.

Guard:

- проверка, что матрица содержит все публичные экраны;
- проверка, что Energy не содержит HUB/Profile/Wallet cards;
- проверка, что Exchange forbids transfers.

### 1270 — visual token and shell lock

Цель: закрепить визуальную основу перед правками страниц.

Сделать:

- проверить dark theme tokens;
- проверить button sizes;
- проверить card spacing;
- проверить mobile width;
- проверить no-horizontal-scroll rules;
- закрепить одинаковый размер HUB-кнопок.

Guard:

- CSS marker guard для shell, buttons, card, progress;
- forbidden text guard для public debug phrases.

## 5. Циклы 1271-1274: Browser/PWA login и no blank screen

### 1271 — browser login page

Цель: заменить белый экран на красивую страницу входа.

Сделать:

- создать browser login page;
- добавить кнопку входа через Telegram;
- добавить demo-preview Energy ниже;
- не показывать fake account;
- не блокировать Telegram WebApp.

Guard:

- без `global_id` не должно быть white screen;
- login page имеет dark shell;
- demo-preview не показывает fake balances как реальные.

### 1272 — Telegram/browser parity gate

Цель: одинаковая структура приложения в Telegram и браузере.

Сделать:

- проверить entry flow Telegram;
- проверить entry flow browser;
- проверить PWA manifest;
- проверить service worker только как shell-layer.

Guard:

- route checker для Telegram/browser paths;
- no Telegram-only crash guard.

### 1273 — splash and loading repair

Цель: загрузка не должна зависать.

Сделать:

- splash только до готовности shell;
- fallback словаря;
- dark first paint;
- no raw i18n keys.

Guard:

- raw i18n key scan;
- dark first screen CSS marker.

### 1274 — PWA install policy

Цель: установка только системной кнопкой браузера.

Сделать:

- убрать собственные install buttons, если найдены;
- добавить только подсказку без кнопки, если нужна;
- документировать системный способ установки.

Guard:

- no custom install button marker.

## 6. Циклы 1275-1278: Energy

### 1275 — Energy canonical composition

Цель: Energy как главный экран генерации.

Сделать:

- оставить generated kWh как центр;
- показать available kWh;
- показать progress-bar;
- показать kWh per second всех активных панелей;
- показать VIP как статус;
- не показывать balances как центр;
- не показывать referrals/ranks/tasks/shop cards.

Guard:

- forbidden Energy cards guard;
- mandatory Energy labels guard.

### 1276 — Energy header balance boundary

Цель: баланс виден в верхней панели, но не ломает Energy.

Сделать:

- проверить header balance;
- убрать main/bonus/total из central Energy, если они там есть;
- оставить `available kWh` на Energy.

Guard:

- balance placement guard.

### 1277 — Energy VIP status and generation chips

Цель: закрепить только каноничные чипы Energy.

Сделать:

- active panels chip;
- generation rate chip;
- available kWh chip;
- VIP только как статусная надпись;
- не возвращать HUB, Wallet, Shop, Tasks, Ranks или Referrals;
- не превращать VIP в отдельный action/block на Energy.

Guard:

- Energy chip count guard;
- VIP status-only guard;
- forbidden Energy action guard.

### 1278 — Energy mobile proof pass

Цель: первый экран читается на смартфоне.

Сделать:

- 390px mobile audit;
- no horizontal scroll;
- progress visible;
- buttons aligned;
- no debug text.

Guard:

- screenshot QA checklist update.

## 7. Циклы 1279-1285: Panels

### 1279 — Panels active/archive layout

Цель: активные панели первыми, архивные через переключение.

Сделать:

- кнопки `Active` / `Archive` или RU по admin/player canon;
- частичный список на основной странице;
- возможность перейти к полному списку, если это безопасно;
- не делать хаос из вкладок.

Guard:

- active/archive controls exist;
- no global_id public leak.

### 1280 — panel activation CTA

Цель: одна главная кнопка активации панели.

Сделать:

- `Активировать панель` / canonical label;
- списание bonus first, then main;
- не прятать цену 100 EFHC;
- не менять экономику.

Guard:

- panel price marker;
- bonus-first main-second guard.

### 1281 — panel countdown model audit

Цель: найти текущую модель даты активации/деактивации.

Сделать:

- проверить backend fields;
- проверить frontend card fields;
- найти, где потерян countdown;
- составить migration-safe plan, если полей нет.

Guard:

- audit only, без изменения БД без необходимости.

### 1282 — panel countdown backend/source repair

Цель: вернуть данные для обратного отсчёта.

Сделать:

- activation date;
- deactivation date;
- remaining seconds;
- server/source calculation;
- не использовать age вместо remaining time.

Guard:

- remaining seconds test;
- no days-active-only marker.

### 1283 — panel countdown UI

Цель: показать дни/часы/минуты и runtime countdown.

Сделать:

- карточка панели показывает дату активации;
- карточка показывает дату деактивации;
- карточка показывает `осталось`;
- runtime tick обновляет countdown;
- генерация kWh получает секунды.

Guard:

- UI source marker;
- TypeScript proof.

### 1284 — Panels generation summary

Цель: общая генерация всех панелей в hero.

Сделать:

- total active generation rate;
- active panels count;
- no VIP block;
- no daily generation per panel.

Guard:

- mandatory hero fields.

### 1285 — Panels proof pass

Цель: закрыть Panels как восстановленный слой.

Сделать:

- route proof;
- visual checklist;
- backend/frontend contract proof;
- report.

## 8. Циклы 1286-1290: Exchange

### 1286 — exchange transfer ban

Цель: жёстко запретить переводы EFHC между пользователями.

Сделать:

- найти UI/route traces transfer;
- удалить/скрыть только после проверки;
- закрепить запрет в guard.

Guard:

- no transfer button;
- no transfer route in public UI.

### 1287 — exchange kWh to EFHC only

Цель: только обмен kWh → EFHC.

Сделать:

- строка `1 kWh = 1 EFHC`;
- input доступных kWh;
- кнопка Convert;
- кнопка Max;
- no extra explanation overload.

Guard:

- rate marker;
- Max button marker.

### 1288 — exchange history link

Цель: история не мешает, но доступна.

Сделать:

- ненавязчивая кнопка перехода в History;
- не делать отдельную heavy history на Exchange.

Guard:

- link exists, no table overload.

### 1289 — exchange route and contract proof

Цель: не вернуть global_id/path drift.

Сделать:

- current-user route proof;
- no user transfer proof;
- no path global_id leaks.

Status v168_87 / cycle 1289: completed.

Result:

- Exchange route-contract proof markers added;
- generated current-user seams are locked;
- `global_id`/`user_id` path drift is guarded;
- user-transfer roads are guarded as forbidden.

### 1290 — Exchange visual proof

Цель: компактный экран обмена.

Сделать:

- mobile proof;
- no debug;
- no VIP block;
- no overload.

## 9. Циклы 1291-1294: Tasks

### 1291 — Tasks list-card layout

Цель: список заданий как гармоничные карточки.

Сделать:

- задание;
- награда;
- кнопка действия;
- без лишней истории;
- без перегруза статусами.

Guard:

- no task history public block.

Status v168_89 / cycle 1291: completed.

Result:

- `/tasks` has compact earning-card markers;
- public technical/idempotency help block was removed;
- cards keep title, description, reward, compact status, human help and primary action;
- no task history/log surface was added.

### 1292 — Ads task action

Цель: кнопка `Смотреть рекламу` сразу открывает ads.

Сделать:

- проверить ads route/action;
- не добавлять лишнее предупреждение;
- дать feedback только если действие не сработало.

Guard:

- ads button action marker.

Status v168_90 / cycle 1292: completed.

Result:

- ad task cards keep the primary `watch-ad` action;
- the extra confirmation gate before ad opening was removed;
- `/ads/slot` is called without public `global_id` or `user_id` query leak;
- the ad modal has a direct-open marker;
- user feedback is shown when the ad action fails, not as an extra warning before opening.

### 1293 — hidden task execution log boundary

Цель: история выполнений скрыта от пользователя.

Сделать:

- backend/log сохраняет double-claim protection;
- frontend не показывает историю заданий;
- admin/logs может видеть служебные следы.

Guard:

- hidden history guard.

Status v168_91 / cycle 1293: completed.

Result:

- `/tasks` remains clean player-facing earning UI;
- public task execution history/log/debug surfaces are not rendered;
- backend double-claim protection remains internal through locks, bonus logs, submissions and idempotency paths;
- admin/operator task traces remain available through admin task submissions and `/admin/logs/transfers?reason=task_bonus`;
- `test_tasks_hidden_execution_log.py` protects the boundary.

### 1294 — Tasks proof pass

Цель: Tasks не перегружен и работает.

Сделать:

- route proof;
- TypeScript;
- visual checklist.

Status v168_92 / cycle 1294: completed.

Result:

- `/tasks` has `data-tasks-proof-pass="1294"`;
- public Tasks stays a clean earning screen;
- no public task history, backend log or debug block is rendered;
- static route proof is protected by `test_tasks_proof_pass.py`.


## 10. Циклы 1295-1302: Referrals и Ranks

### 1295 — Referrals invite block

Цель: реферальная ссылка как главный элемент.

Сделать:

- link;
- copy;
- share;
- social sharing;
- не показывать global_id.

Status v168_92 / cycle 1295: completed.

Result:

- the invite card has explicit link/copy/share proof markers;
- frontend stats call uses `/referrals/stats/me`;
- no public referral stats URL is built with `parent_global_id`, `global_id` or `user_id`;
- backend exposes `/referrals/stats/me` through `get_current_global_id`;
- legacy stats route remains only for compatibility and sends a deprecation header.

Guard:

- no global_id public marker;
- current-user stats route guard.


Guard:

- no global_id public marker.

### 1296 — active/inactive referrals

Цель: пользователь видит, за кого начислен бонус.

Сделать:

- active list;
- inactive list;
- buttons to switch;
- username only;
- Active status persists after first panel purchase.

Status v168_92 / cycle 1296: completed.

Result:

- active/inactive list calls use `/referrals/active/me` and `/referrals/inactive/me`;
- frontend no longer builds list URLs with `parent_global_id`;
- rows display username or neutral user fallback, not global_id;
- list card has `data-referrals-active-inactive-boundary="1296"`;
- backend exposes current-user active/inactive routes and keeps legacy routes deprecated.

Guard:

- active status source marker;
- no global_id marker;
- current-user list route guard.


Guard:

- active status source marker;
- no global_id marker.

### 1297 — referral progress and levels

Цель: главный сектор реферальной системы.

Status v168_93 / cycle 1297: completed.

Result:

- referral progress moved into a visible main card;
- progress bar, level, achievements and next-level values are present;
- guard protects the progress/levels boundary.

Guard:

- progress exists;
- no hidden main referral progress.

### 1298 — referral bonus wording

Цель: простая формула `+0.1 EFHC`.

Status v168_93 / cycle 1298: completed.

Result:

- `+0.1 EFHC` is explained in the rules/progress block;
- every referral row remains clean and is not overloaded by repeated
  bonus text;
- bonus wording says active referrals only.

Guard:

- bonus copy marker.

### 1299 — Ranks card layout

Цель: вертикальные карточки игроков.

Status v168_93 / cycle 1299: completed.

Result:

- rank rows are vertical player cards;
- cards show position, username/neutral fallback, score and VIP;
- raw global_id fallback was removed from the public UI.

Guard:

- no table-only fallback;
- no global_id.

### 1300 — Ranks filters

Цель: только `kWh` и `Referrals`.

Status v168_93 / cycle 1300: completed.

Result:

- Ranks has exactly two public filters: `kWh` and `Referrals`;
- no week/all-time filter was added;
- kWh and referral rank modes use current-user backend routes.

Guard:

- filters exact marker.

### 1301 — show me in Ranks

Цель: показать пользователя и конкурентов рядом.

Status v168_93 / cycle 1301: completed.

Result:

- `Показать меня` remains as the public action;
- button scrolls to the user card;
- focused view keeps a nearby competitor window around the user.

Guard:

- source marker or test for action presence.

### 1302 — Ranks proof pass

Цель: Ranks соответствует канону.

Status v168_93 / cycle 1302: completed.

Result:

- Ranks has no 12 Energy levels catalog;
- Ranks uses vertical cards;
- filters are exactly kWh/referrals;
- no raw global_id/user_id path or query is used by the frontend.

## 11. Циклы 1303-1310: Profile, Wallet, History, FAQ

### 1303 — Profile status model

Цель: Profile показывает VIP и Active как постоянные статусы.

Сделать:

- VIP indicator always visible;
- Active indicator always visible;
- inactive state grey;
- active state green/gold;
- no technical labels.

Guard:

- no `Browser ready`, `PWA`, `independent shell` public text.

### 1304 — Profile FAQ button

Цель: Profile содержит только кнопку на полный FAQ.

Сделать:

- remove embedded mini FAQ if present;
- add clean button to `/faq`;
- no design over function.

Guard:

- FAQ button marker.

### 1305 — Wallet as wallet list

Цель: Wallet — только подключённые кошельки.

Сделать:

- list connected wallets;
- add/manage/remove primary wallet actions;
- no general account history inside Wallet;
- no large status dashboard.

Guard:

- no History block in Wallet.

### 1306 — wallet error microcopy

Цель: только понятный минимум для ошибок подключения.

Сделать:

- short error notice if connect fails;
- no technical payload;
- no state-map dashboard.

Guard:

- no raw wallet error payload.

### 1307 — History account timeline

Цель: общая история аккаунта.

Сделать:

- filters: All, Purchases, Exchange, Withdraw, Bonuses, Panels;
- include purchases, exchanges, withdraws, bonuses, panels;
- not wallet-specific.

Guard:

- history filters marker.

### 1308 — History data contract audit

Цель: понять, какие backend endpoints уже есть.

Сделать:

- map history endpoints;
- no fake data;
- if endpoint missing, document blocker before UI claim.

### 1309 — FAQ full list compact tree

Цель: FAQ функционален и компактен.

Сделать:

- all sections visible as list;
- vertical expand;
- no pills/categories;
- no overflow;
- language follows current lang.

Guard:

- no FAQ pills marker;
- compact tree marker.

### 1310 — Profile/Wallet/FAQ proof pass

Цель: закрыть профильный контур.

Сделать:

- route proof;
- TypeScript;
- visual checklist.

## 12. Циклы 1311-1316: HUB, Browser-Shop, USDT

### 1311 — HUB two equal buttons

Цель: HUB строго две одинаковые кнопки.

Сделать:

- `Пополнить EFHC`;
- `EFHC VIP NFT`;
- equal width/height;
- equal descriptions;
- no third point without chat approval.

Guard:

- HUB button count exactly two;
- equal class marker.

### 1312 — VIP NFT link policy

Цель: VIP NFT — ссылка на сайт/GetGems.

Сделать:

- no heavy NFT panel;
- no separate NFT admin panel;
- text `EFHC VIP NFT`;
- link only.

Guard:

- no public NFT debug.

### 1313 — Browser-Shop Web3 cards

Цель: крупные Web3-карточки товаров.

Сделать:

- large image/card frame;
- product title;
- price;
- payment button;
- no wallet/memo/copy/raw.

Guard:

- no raw payment technical fields.

### 1314 — EFHC for TON payment

Цель: TON purchase остаётся рабочей.

Сделать:

- check current TON flow;
- status human text;
- no technical payload.

Guard:

- TON route proof.

### 1315 — USDT payment road audit

Цель: объяснить и согласовать возврат USDT.

Сделать:

- найти backend routes;
- найти watcher support;
- найти current shop product model;
- вывести пользователю простой вопрос перед UI.

Не делать:

- не показывать сломанную USDT кнопку как готовую.

### 1316 — Browser-Shop proof pass

Цель: Web3-shop без технического мусора.

Сделать:

- no bottom menu;
- no Mini App layout;
- cards proof;
- payment status proof.

## 13. Циклы 1317-1320: Admin

### 1317 — Admin home app grid

Цель: главная Admin как список разделов.

Сделать:

- Users;
- Bank;
- Withdrawals;
- Shop;
- Tasks;
- Reports;
- Diagnostics;
- System;
- no debug dump.

Guard:

- no raw debug on Admin home.

### 1318 — Admin functional page template

Цель: каждая функция Admin имеет структуру.

Сделать:

- график/статистика сверху;
- действия и таблицы ниже;
- отдельный route per function;
- Russian admin UI.

Guard:

- template component marker.

### 1319 — Admin routes map

Цель: понять все существующие backend/admin routes.

Сделать:

- route inventory;
- UI section mapping;
- no route deletion without approval;
- missing page list.

### 1320 — Admin proof and next plan

Цель: зафиксировать готовность к следующей фазе.

Сделать:

- visual audit;
- route proof;
- next cycles 1321-1350 if needed;
- no release-ready claim without live proof.

## 14. Проверки каждого code cycle

Минимум:

- `python3 ops/local/check_frontend_routes.py`;
- `python3 -m compileall -q ops/local tests/architecture`;
- targeted architecture tests;
- `tsc --noEmit`, если frontend менялся;
- locale JSON validation, если менялись тексты;
- ZIP `unzip -t`.

Дополнительно для live/UI:

- screenshot QA mobile;
- screenshot QA desktop;
- Docker runtime smoke;
- no white screen proof.

## 15. Запрещено

- не возвращать старые PDF как канон;
- не хранить PDF-первоисточники;
- не задавать вопросы, если ответ уже есть в Q/A;
- не писать `объяснение в файле` вместо объяснения в чате;
- не добавлять новые Energy cards;
- не показывать transfers в Exchange;
- не показывать global_id пользователям;
- не выводить debug dump в публичный UI;
- не делать fake release-ready.


## v168_68 status update

Cycles 1268-1270 are completed as control-layer cycles. No frontend or
backend code was changed. The next implementation cycle is 1271:
browser login page and no white screen.

## v168_69 status update

Cycle 1271 is completed as the first practical frontend code pass after
control freeze. A browser login/demo panel was added for
browser/PWA mode
when Telegram user data is absent. The panel does not replace the app:
it sits above the normal demo Energy/content layer and prevents blank or
white-screen perception.

Next cycle: 1272 — no-white-screen first paint guard and dark browser
boot proof.

## v168_70 — cycle 1272 completed

Статус: выполнено.

Сделано:

- добавлен dark first paint guard на уровне `document.tsx`;
- добавлен `#__next` dark shell в global CSS;
- добавлен splash timeout escape в `app.tsx`;
- добавлен marker `data-efhc-shell` через React dataset;
- добавлен guard `test_first_paint_guard.py`.

Назначение: browser/PWA больше не должен показывать белый или пустой
первый экран, если Telegram-данные, словари или snapshot временно не
готовы.

Следующий цикл: 1273 — splash/loading repair и raw i18n key scan.


## Cycle status addendum — v168.71

Cycle 1273 is completed as splash/loading and raw i18n guard.
The startup shell now has named timeout constants and explicit
booting/ready CSS state. Missing i18n keys that look technical no
longer fall through as raw public strings. The next planned cycle is
1274: PWA install policy lock.

## v168_72 — cycle 1274 completed

Cycle 1274 is completed as the PWA install policy lock.

Result:

- browser/PWA installation remains controlled by browser/system UI;
- no custom EFHC install button is allowed without chat approval;
- no active custom install button was found in frontend source;
- a guard was added for future install-button drift;
- no runtime frontend/backend code was changed.

Next cycle: 1275 — Energy canonical composition.


## v168_73 — cycle 1275 completed

Статус: выполнено.

Сделано:

- Energy приведён к канонической композиции главного экрана;
- центр экрана оставлен за generated kWh;
- сохранены progress bar, available kWh и kWh per second;
- VIP показывается только как статусная надпись, если активен;
- main balance, bonus balance и EFHC balance убраны из центральной
  композиции Energy, потому что баланс относится к верхней панели;
- base rate и exchanged total убраны из Energy как перегруз;
- HUB, Wallet/Profile, Tasks, Shop, Ranks и Referrals не добавлялись;
- добавлен guard `test_energy_canonical_composition.py`.

Следующий цикл: 1276 — Energy header balance boundary.

## v168_74 — cycle 1276 completed

Статус: выполнено.

Сделано:

- закреплена граница баланса Energy/header;
- баланс аккаунта остаётся в верхней панели приложения;
- центр Energy остаётся за генерацией kWh и прогрессом;
- `GlobalHeader` получил явные boundary markers;
- Energy не получил main/bonus/total balance props;
- добавлен guard `test_energy_header_balance_boundary.py`.

Назначение: не дать будущим правкам снова превратить Energy в
балансовый дашборд. Energy показывает генерацию, а общий EFHC balance
живёт в глобальной верхней панели.

Следующий цикл: 1277 — Energy VIP status and generation chips.

Cycle 1276 proof phrase: balance in the global header, not in the
Energy center.


## v168_75 — cycle 1277

Статус: выполнено.

Сделано:

- Energy получил явные маркеры для трёх каноничных чипов;
- active panels, generation rate и available kWh защищены тестом;
- VIP зафиксирован как статусная надпись, а не action-card;
- центральная композиция Energy не получила HUB, Wallet, Shop,
  Tasks, Ranks или Referrals.

Следующий цикл: 1278 — Energy mobile proof pass.

## v168_76 — cycle 1278

Статус: выполнено.

Сделано:

- Energy получил mobile-proof markers для 390px viewport;
- добавлен 390px CSS-блок для читаемости первого экрана;
- закреплены max-width/min-width правила против horizontal scroll;
- кнопки Panels и Exchange сохранены как две ровные action cards;
- progress bar и три каноничных чипа остаются видимыми;
- добавлен guard `test_energy_mobile_proof.py`.

Следующий цикл: 1279 — Panels active/archive layout.

Cycle 1278 proof phrase: Energy is readable at 390px without
horizontal scroll and without extra action cards.

## v168_77 — cycle 1279

Статус: выполнено.

Сделано:

- Panels получил явный active/archive layout marker;
- active/archive переключатель закреплён как segmented layout;
- список панелей получил tab-aware marker;
- карточки панелей получили tab-aware marker;
- кнопки Active/Archive выровнены по высоте и ширине;
- список панелей защищён от overflow;
- public `global_id` path leak на Panels не возвращался;
- добавлен guard `test_panels_active_archive_layout.py`.

Следующий цикл: 1280 — panel activation CTA.

Cycle 1279 proof phrase: Panels has a guarded active/archive segmented
layout without public `global_id` paths.

## v168_78 — cycle 1280

Status: done.

Cycle 1280 completed the panel activation CTA lock.

Implemented:

- public Panels CTA has a guarded `100 EFHC` marker;
- activation note states bonus-first then main debit order;
- UI activation availability uses bonus plus main balance;
- locale keys were added for all active frontend locales;
- backend panel economy was not changed.

Added guard:

- `test_panel_activation_cta.py`.

Next cycle: 1281 — panel countdown model audit.

Cycle 1280 proof phrase: Panels activation is guarded as
100 EFHC with bonus-first/main-second debit order.


## v168_79 / cycle 1281 completion

Status: completed.

Result:

- backend date algorithm for panels was found;
- panel activation uses server `utcnow`;
- `expires_at` is server activation time plus 180 days;
- active/archive is based on `expires_at` vs server time;
- list response now exposes `public_id` and `activated_at`;
- no database or migration change was made.

Next cycle: 1282 — panel countdown backend/source repair.

## v168_80 / cycle 1282 completion

Status: completed.

Result:

- `remaining_seconds` is now part of the panel list contract;
- backend computes it from `expires_at` and `server_now_utc`;
- frontend stores `server_now_utc` from the panel list response;
- local time is only a display stopwatch after the server anchor;
- countdown display includes seconds;
- no database or migration change was made.

Next cycle: 1283 — panel card date display repair.
## v168_81 / cycle 1283 completion

Status: completed.

Result:

- panel cards now show the canonical panel ID field;
- activation date is visible on the card body;
- deactivation date is visible on the card body;
- generated kWh remains visible on the card body;
- live countdown remains visible on the card body;
- activation/deactivation dates are not hidden only in details;
- backend/database/migrations were not changed.

Next cycle: 1284 — panel countdown live display proof.

Cycle 1283 proof phrase: panel card date display keeps ID,
activation date, deactivation date, countdown, and generated kWh visible.


## v168_82 / cycle 1284 completion

Status: completed.

Result:

- panel countdown is guarded as a live display element;
- countdown field has an explicit live marker;
- countdown value updates through the one-second tick;
- `aria-live="polite"` is used for user-facing live changes;
- the server-now anchor remains the source of truth;
- local time is only a display stopwatch after the server anchor;
- backend/database/migrations were not changed.

Next cycle: 1285 — Panels activation/history boundary.

Cycle 1284 proof phrase: panel countdown is a live display, not a
static date or panel-age replacement.

## v168_83 / cycle 1285 completion

Status: completed.

Result:

- Panels now has an explicit account-history boundary;
- Panels keeps activation, active panels, archive panels and timers;
- Panels no longer opens Wallet from the panel context;
- History remains reachable as a small secondary action;
- History is recorded as account-level, not wallet-level;
- backend, database and migrations were not changed.

Next cycle: 1286 — Exchange kWh to EFHC only boundary.

Cycle 1285 proof phrase: Panels is not Wallet and not the account
History page; it only links to account History as a secondary action.

## v168_84 / cycle 1286 completion

Status: completed.

Result:

- Exchange now has an explicit kWh to EFHC only boundary;
- the visible surface keeps available kWh, input, Max, canonical rate,
  conversion action and a small account History link;
- Wallet/Withdraw blocks were removed from the Exchange page;
- percentage quick actions were removed as overload;
- transfer/user-recipient UI is not present on Exchange;
- backend, database and migrations were not changed.

Next cycle: 1287 — Exchange amount/preview polish.

Cycle 1286 proof phrase: Exchange is only kWh to EFHC at 1:1.


## v168_85 / cycle 1287 completion

Cycle: 1287 — Exchange amount/preview polish.

Status: completed.

Result:

- added visible amount label for Exchange;
- added sanitized decimal amount input;
- added 8-decimal precision limit;
- added one clear receive preview row;
- added human helper text for invalid and over-limit amounts;
- updated locale keys for all public locale JSON files;
- hidden Telegram Main Button on Exchange to avoid amount mismatch;
- copied `21.md` into `docs/NORM/CHATS/21.md`.

Boundary:

- no transfer;
- no withdraw;
- no wallet block;
- no VIP block;
- no percentage quick actions;
- no extra action-card overload.

Next cycle: 1288 — Exchange History link light boundary.

Cycle 1287 proof phrase: Exchange amount is simple, visible and 1:1.
## v168_86 / cycle 1288 — Exchange History link light boundary

Status: completed.

Result:

- the Exchange screen keeps access to common account History;
- the History entry is a light secondary navigation row;
- the link has explicit `data-exchange-history-link-light="1288"`;
- no heavy history table, filters or list were added to `/exchange`;
- all public locale files have `exchange.history_hint`;
- `exchange.open_history` was humanized outside English.

Boundary:

- Exchange remains kWh -> EFHC only;
- History remains account-level and external to the converter card;
- Exchange must not become a History/Wallet/Withdraw page.

Next cycle: 1290 — Exchange visual proof.

Cycle 1288 proof phrase: Exchange has History access without History
surface overload.


Exchange route and contract proof.

## v168_88 / cycle 1290 — AUDIT_TZ_v168_83 repair pass

Priority audit fixes were completed before moving to Tasks.
This cycle consumed the 1290 slot because the uploaded audit contained
critical/high visible defects in Profile, Panels, i18n, app shell and
backend route boundaries.

Original Exchange visual proof is not claimed as screenshot/runtime proof.
The Exchange boundary remains protected by cycles 1286-1289 guards.

## v168_94 implementation update — cycles 1303-1310

Completed in one pass:

- 1303 Profile status model;
- 1304 Profile FAQ button;
- 1305 Wallet as wallet list;
- 1306 wallet error microcopy;
- 1307 History account timeline;
- 1308 History data contract audit;
- 1309 FAQ full list compact tree;
- 1310 Profile/Wallet/FAQ proof pass.

The 1268-1320 frontend recovery range is closed. Next implementation cycle is 1321 — Users page statistics and actions audit.


## v168_95 cycles 1311-1320 result

Cycles completed in one pass:

- 1311 — HUB two equal buttons;
- 1312 — VIP NFT link policy;
- 1313 — Browser-Shop Web3 cards;
- 1314 — EFHC for TON payment;
- 1315 — USDT payment road audit;
- 1316 — Browser-Shop proof pass;
- 1317 — Admin home app grid;
- 1318 — Admin functional page template;
- 1319 — Admin routes map;
- 1320 — Admin proof and next plan.

Status: completed as a static/code-level pass.

Result:

- HUB public section is locked to exactly two equal actions: top up EFHC
  and EFHC VIP NFT;
- VIP NFT remains an external link policy and no heavy NFT/admin panel was
  introduced;
- Browser-Shop keeps large Web3 product cards and TON payment road proof;
- USDT road was audited, but no ready USDT button was exposed;
- Admin home starts with the canonical eight-section grid;
- a shared Admin functional page template was added;
- Admin route inventory was created without route deletion;
- the 1321-1350 Admin recovery extension plan was created.

Next cycle: 1321 — Users page statistics and actions audit.


## Historical work-pass markers restored for active architecture guards

v168_77 — work pass: Panels active/archive layout.
v168_80 / work pass: remaining_seconds panel countdown source.
v168_81 / work pass: panel card date display.
v168_82 / work pass: panel countdown live display.
v168_83 / work pass: Panels activation/history boundary with account history.
v168_84 / work pass: Exchange kWh to EFHC only boundary.
v168_85 / work pass: Exchange amount/preview polish.
v168_86 / work pass: Exchange History link light boundary, no heavy history.
v168_87 / work pass: Exchange route and contract proof.
v168_92 / work pass: Tasks proof pass, Referrals invite block, active/inactive referrals.
