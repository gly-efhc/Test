# Текущий контроль циклов — v172.66

Exact v172.65 CI показал, что слепой big-bang codemod повредил рабочую
реализацию. В v172.66 выполнена controlled rebase пересборка: canonical
`global_id` ownership циклов 1641–1646 сохранён, а временный alias-слой
переведён под machine-controlled baseline.

- 1641–1645: canonical business ownership сохранён;
- 1646: безопасно удалённые aliases не возвращены;
- 1646: compatibility baseline может только уменьшаться;
- новый слепой текстовый codemod запрещён;
- все 90 test-файлов, упавших в переданном CI, прошли точечно;
- production cutover не выполнялся;
- exact-head main CI обязателен.
- пользовательский ZIP CI-логов является источником истины; дублирующие полные локальные прогоны запрещены;

```text
CYCLES_1641_1646_RUNTIME_KERNEL_RESTORED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
TG_ID_COMPATIBILITY_BASELINE_FROZEN
MECHANICAL_BIG_BANG_CODEMOD_REJECTED
CYCLE_1646_EXACT_HEAD_CI_REQUIRED
CYCLE_1647_ALIAS_REDUCTION_AFTER_PASS
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.65

Цикл 1647 переведён на утверждённый big-bang метод первых identity-циклов:
сначала глобальный rewrite, затем отдельная тестовая коррекция, после PASS
— удаление alias-слоя.

- 158 runtime-файлов массово переведены на `global_id`;
- business runtime debt `global_id` вне allowlist: 0;
- alias-harness активен;
- функциональная квалификация ещё не начиналась;
- production cutover не выполнялся.

```text
CYCLE_1647_PHASE_A_BULK_REWRITE_IMPLEMENTED
GLOBAL_OWNER_BULK_REWRITE_READY_FOR_TEST_REPAIR
CYCLE_1647_PHASE_B_TEST_REPAIR_NOT_STARTED
CYCLE_1647_PHASE_C_ALIAS_REMOVAL_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.64

Fresh exact v172.63 CI подтвердил большую часть gates и локализовал одну
Mypy-ошибку и пять pytest failures. В v172.64 они исправлены, а цикл
1646 начат безопасным удалением алиасов без runtime-callers.

- 1641–1645: canonical `global_id` business ownership сохранён;
- 1646: выполнен alias audit;
- 1646: удалены четыре финансовых `*_by_global_id` wrappers;
- 1646: удалён мёртвый `STATUS_SENT`;
- provider-specific Telegram lookup сохранён;
- active route/ORM compatibility переносится в цикл 1647;
- production cutover не выполнялся;
- exact-head main CI обязателен.

```text
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1646_ALIAS_AUDIT_COMPLETE
CYCLE_1646_SAFE_ALIAS_REMOVAL_STARTED
CYCLE_1646_EXACT_HEAD_CI_REQUIRED
CYCLE_1647_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.63

Fresh exact v172.62 CI выявил schema-count drift, четыре Ruff imports,
четыре Bandit dynamic SQL boundary и compatibility regressions после
перевода callers на `global_id`.

В v172.63:

- фактические 39 FK закреплены в migration и architecture contracts;
- static/security причины из fresh CI устранены;
- compatibility seams сохранены до утверждённых циклов 1646–1647;
- current HTTP self-routes остаются canonical `global_id`;
- полный локальный pytest завершён без failure;
- production cutover не выполнялся;
- exact-head main CI обязателен.

```text
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLES_1641_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.62

Fresh exact v172.61 CI локализовал остатки циклов 1644 и caller/cutover
границы. В v172.62 исправлены все подтверждённые классы ошибок и локально
реализован цикл 1645.

- 1644: Tasks/Ranks/Wallet CI regressions исправлены без возврата `global_id`
  в business ownership;
- 1645: текущие routes, bot handlers, watcher и service callers используют
  canonical `global_id`;
- 1645: Achievements и referral codes подготовлены Alembic revision `0002`;
- 1645: добавлен изолированный операторский preflight/cutover/rollback;
- migration не переключает production flags автоматически;
- production cutover не выполнялся;
- exact-head main CI обязателен.

```text
CYCLE_1644_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1645_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1644_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.61

Fresh exact v172.60 CI локализовал остатки циклов 1643 и тестовой
identity-инфраструктуры. В v172.61 исправлены все подтверждённые классы
ошибок и реализован цикл 1644.

- 1643: Referral SQL и historical fixtures исправлены после CI;
- 1644: Tasks и ad rewards используют canonical `global_id` owner;
- 1644: ranks snapshot включает Telegram и TON-only accounts;
- 1644: wallet read-side использует canonical owner;
- Telegram proof/connect и channel join остаются provider-specific;
- production cutover не выполнялся;
- exact-head main CI обязателен.

```text
CYCLE_1643_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1644_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1643_1644_EXACT_HEAD_CI_REQUIRED
CYCLE_1645_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.60

Fresh exact v172.59 CI локализовал ошибки циклов 1641–1642. В v172.60
исправлены все подтверждённые классы ошибок и реализован цикл 1643.

- 1641: transactions/ledger owner сохранён на canonical `global_id`,
  восстановлены test singleton и post-lock idempotency read-through;
- 1642: Panels, Withdrawals и Payment Intents исправлены после CI;
- 1643: referral ownership и identifier-coupled keys нормализованы;
- legacy referral read-through разрешён только для shadow-null rows;
- production cutover не выполнялся;
- exact-head main CI обязателен.

```text
CYCLE_1641_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1642_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1643_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1643_EXACT_HEAD_CI_REQUIRED
CYCLE_1644_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий контроль циклов — v172.59

Локально реализованы циклы 1641–1642 без visual и Admin scope.

- 1641: transactions и ledger используют canonical `global_id`;
- 1642: Panels, Withdrawals и создание Payment Intents используют owner;
- `tg_id` остаётся только временным provider selector;
- production cutover не выполнялся;
- exact-head main CI обязателен.

```text
CYCLE_1641_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1642_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1642_EXACT_HEAD_CI_REQUIRED
CYCLE_1643_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Current cycle control — v172.58 / cycle 1640 visual corrective

> Текущий верхний раздел authoritative. История ниже — evidence.

Полностью утверждённый план:
`docs/cycles/WORK_CYCLES_1640_1665_APPROVED_PLAN.md`.

Немедленный corrective scope:

- восстановлен v172.50 public visual baseline;
- сохранены полезные functional changes;
- запрещён возврат отклонённого v172.51 decorative layer;
- identity и Admin UX не смешивались с visual patch.

Следующий порядок:

1. fresh exact-head main CI и screenshots v172.58;
2. закрыть qualification цикла 1640;
3. начать цикл 1641 transactions/ledger global_id;
4. visual route repair продолжать только в выделенных циклах 1651–1653;
5. Admin Support Center — только 1654–1660.

```text
CYCLE_1640_VISUAL_CORRECTIVE_LOCAL_COMPLETE
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
APPROVED_PLAN_1640_1665_LOCKED
NOT_PRODUCTION_RELEASE_READY
```

---

# Current cycle control — v172.57 / cycle 1640

> Текущий верхний раздел является authoritative. История ниже — evidence.

Авторитетный детальный план:
`docs/cycles/WORK_CYCLES_1640-1650_GLOBAL_ID_FULL_CUTOVER.md`.

Выполнено локально в цикле 1640:

- write-side owner resolver;
- canonical `global_id` normalization;
- row lock `FOR UPDATE`;
- TON-only support;
- shared migration-control loader;
- idempotency-key audit;
- targeted tests PASS.

Следующий цикл после exact-head qualification v172.57: `1641` — перевод
`transactions_service.py` и ledger ownership на `global_id`.

```text
CYCLE_1639_MAIN_CI_PASS
CYCLE_1639_VISUAL_EVIDENCE_DEFERRED_BY_USER
CYCLE_1640_LOCAL_SCOPE_COMPLETE
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Current cycle control — v172.56 / cycle 1639 corrective

Fresh CI `83583696254` exact `v172.55` подтвердил static/type/security,
PostgreSQL/Alembic и production frontend scope. Pytest дал `3219 passed`,
`28 skipped` и один failure только в cross-provider qualification fixture.

В `v172.56`:

- production registration callers и service не меняются;
- после назначения TON-first account нового `global_id` test fixture явно
  выполняет `flush()`;
- `ReferralCode` вставляется только после фактического UPDATE пользователя;
- строгий FK сохраняется;
- cycle `1640` не начат.

```text
CYCLE_1636_QUALIFIED
CYCLE_1637_QUALIFIED
CYCLE_1638_RUNTIME_QUALIFIED
CYCLE_1639_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
---
# Current cycle control — v172.50 / cycle 1635 corrective

- Fresh exact `v172.49` CI passed PostgreSQL, Alembic, static analysis and
  production frontend build.
- Pytest and route-backed visual gate failed; findings were localized.
- Public UI now follows the trusted admin design reference without changing
  routes, economics, backend, auth or database semantics.
- FAQ Markdown-like emphasis is rendered safely; read-only offline status no
  longer obstructs FAQ/HUB.
- Admin home contains release/business/operator data only; internal technical
  proof surfaces were removed from the home screen.
- Cycle 1635 is not closed until fresh exact-head PNG and user acceptance.
- Cycle 1636 is not started.
- `production_release_ready`: `false`.
- Next changed development archive after accepted proof: only by real change.

Last cycle: `1635 corrective / acceptance required`.
Range `1501–1600`: historical closed range retained below.
Historical entries below do not override this current section.

---

# Current cycle control — v171.85 / cycle 1588

- Cycle 1587 referral runtime/API TZ audit: `LOCAL_SCOPE_COMPLETE`.
- Cycle 1588 exact-HEAD evidence gate repair: `LOCAL_SCOPE_COMPLETE`.
- Stale v171.67 CI evidence is rejected for v171.85.
- Current status: `LOCAL_RELEASE_CANDIDATE /
  FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.
- Backend, frontend UI, database, migrations and economics are unchanged.
- `production_release_ready`: `false`.
- Next changed development archive: `v171.86`.

Historical entries below preserve prior states and do not override this
v171.85 section.

---

# Current cycle control — v171.73 / cycle 1578

- Supplied GitHub CI logs for both v171.72 archives were analyzed.
- Development failures repaired: Ruff 14, Mypy 2, Bandit 6 and pytest 11.
- Minimal release archive now carries a dedicated fail-closed CI profile and test dependency manifest.
- Financial seed truth is single-sourced in the idempotent production bootstrap; Alembic no longer mints bank balance.
- Frontend production build was green in the supplied development log and remains route/runtime unchanged.
- Local bounded regression groups are green; fresh exact-HEAD GitHub CI is still required.
- `production_release_ready`: `false`.
- Next changed development archive: `v171.74`.

Historical entries below preserve prior states and do not override the current v171.73 CI-repair section.

---

# Current cycle control — v171.70 / cycle 1578

- Cycles 1574–1578 locally executable scope: `COMPLETE`.
- Current artifact: clean-first-boot production release candidate.
- Empty PostgreSQL bootstrap, both schemas, exact 44-table validation and idempotent system seed are implemented.
- Mandatory backend routes and all eight scheduler tasks are strict production requirements.
- First and repeated deployment use the single command `./scripts/release/deploy.sh`.
- Provider portability, secret isolation, fail-closed migration/restore and bounded Docker logs are enforced.
- Local status: `LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED`.
- Docker/VPS, live Telegram/TON, real transactions and second-provider restore remain unverified.
- `production_release_ready`: `false`.
- Next changed development archive: `v171.71`.

Historical entries below preserve prior states and do not override the current v171.70 section.

---

# Current cycle control — v171.68 / cycle 1578

- Cycles 1574–1578: `LOCAL_SCOPE_COMPLETE`.
- Overall local status: `LOCAL_PRE_RELEASE_99_PERCENT_COMPLETE`.
- Technical deployment package: `READY_FOR_TECHNICAL_DEPLOYMENT`.
- Provider-independent runtime uses project domains, Docker Compose, standard PostgreSQL, FastAPI, Next.js and Caddy.
- Backup, encrypted recovery bundle, restore drill, off-site synchronization, domain change and Telegram webhook scripts are included.
- Fresh supplied v171.67 CI evidence is green; v171.68 deployment-only delta has targeted local guards.
- Live VPS, DNS/HTTPS, Telegram, TonProof, transaction settlement and cross-provider restore are deferred and unverified.
- Production/public release status remains false until those live gates pass.
- Next changed archive: `v171.69`.

Historical entries below preserve prior states and do not override the current v171.68 section.

---

# Current cycle control — v171.67

- Cycle 1573: `LOCAL_SCOPE_COMPLETE / EXTERNAL_POST_RELEASE_VERIFICATION_DEFERRED`.
- Cycle 1574: `ACTIVE / CI LOG ROOT-CAUSE REPAIR COMPLETED LOCALLY / FRESH CI REQUIRED`.
- All 58 pytest node IDs from `logs_81507543006.zip` now pass locally.
- The 170 line-length violations were repaired without weakening the 72-character guard.
- The two missing Profile settings SVG constants and all three exact Ruff defects were corrected.
- Production npm build and authoritative Ruff verdict require a fresh CI environment because package installation is unavailable in this sandbox.
- No CI/workflow file, economy, database schema, route or canonical navigation was changed.
- External live proof remains deferred and unverified.
- Next safe archive: `v171.68`.

Historical entries below preserve prior states and do not override the current v171.67 section.

---

# Current cycle control — v171.66

- Cycle 1573: `LOCAL_SCOPE_COMPLETE / EXTERNAL_POST_RELEASE_VERIFICATION_DEFERRED`.
- Cycle 1574: `ACTIVE / WALLET PROVIDER ADAPTER IMPLEMENTED / LOCAL RELEASE-CANDIDATE AUDIT CONTINUES`.
- Implemented an application-owned `WalletProvider` with three independent adapters: TonConnect, Wallet in Telegram and Native Gram Wallet.
- Migrated `_app`, Layout, direct EFHC deposit, Browser Shop checkout, profile wallet surfaces and admin payout away from direct TonConnect dependencies.
- TonConnect remains operational; unpublished Telegram/native transports are fail-closed and do not claim live functionality.
- Added exact Operator Kernel classification/route, SSOT/NORM and architecture regression guards.
- No economic formula, backend settlement rule, database schema, six-button navigation or rendered UI contract was changed.
- External live proof remains `DEFERRED_POST_RELEASE_BY_USER` and unverified.
- Next safe archive: `v171.67`.

Historical entries below preserve prior states and do not override the current v171.66 section.

---

# Current cycle control — v171.65

- Cycle 1573: `LOCAL_SCOPE_COMPLETE / EXTERNAL_POST_RELEASE_VERIFICATION_DEFERRED`.
- External disposition: `DEFERRED_POST_RELEASE_BY_USER`.
- Live Telegram, real TonConnect, real TonProof and real transaction remain unverified and are not claimed.
- Cycle 1574: `ACTIVE / LOCAL RELEASE-CANDIDATE AUDIT`.
- Impossible external checks must not be repeated in the same incapable environment without new evidence or capability.
- Next safe archive: `v171.66`.

Historical entries below preserve prior states and do not override the current v171.65 section.

---

# Current cycle control — v171.63

- Cycle 1573: `ACTIVE / BLOCKED_EXTERNAL_PROOF / NOT COMPLETE`.
- Kernel/control-document compaction and targeted TonConnect/TonProof validation completed locally.
- Real route-backed screenshots remain blocked by unavailable frontend dependencies.
- Live Telegram, real TonConnect, real TonProof and real transaction evidence are absent.
- Cycle 1574 must not start.
- Next safe archive: `v171.64`.

---

# Current cycle control — v171.61

- Cycle 1573: FROZEN / NOT COMPLETE.
- Source regression repair completed for header/profile and Profile-only settings gear.
- Honest route-backed audit harness prepared, but production runtime/screenshots remain blocked by unavailable frontend dependency installation in this environment.
- No synthetic or inherited PNG may close the visual gate.
- Cycle 1574 must not start.
- Next archive: v171.62.

---

# Current cycle control — v171.60

- Cycle 1573: FROZEN / NOT COMPLETE.
- v171.60: governance/navigation recovery only.
- Real route-backed visual proof and live Telegram/TonConnect/TonProof/transaction evidence remain open.
- Cycle 1574 must not start.
- Next archive: v171.61.

---

# Current cycle note — v171.59 / cycle 1573 corrective pass

Cycle 1573 remains active.

Completed in this bounded corrective pass:

- verified Chromium, Xvfb and Python Playwright before declaring blockers;
- corrected the v171.58 screenshot-process failure;
- retained the uniform header balance numeral repair;
- mounted the existing `ProfileModal` from `WebProfilePage`;
- added a visible Settings button without removing Profile/Wallet/History/FAQ;
- generated 13 fresh Chromium browser-captured component/page PNG;
- verified header at 360, 390, 430 and 768 px;
- ran targeted guards: `31 passed`;
- kept Native Wallet Adapter as planning-only:
  `WalletProvider → TonConnectAdapter / TelegramWalletAdapter / NativeGramWalletAdapter`.

Not completed:

- live Telegram proof;
- real TonConnect proof;
- real TonProof proof;
- real transaction contour proof.

Therefore cycle 1573 is not complete and cycle 1574 is not started.
---

# Cycle 1573 — v171.57 live contour gate and evidence blocker

Status: `ACTIVE_NOT_COMPLETE`.

This pass continues cycle 1573 without advancing to cycle 1574. Since no live Telegram client proof, real TonConnect proof, real TonProof proof or real transaction proof was available in the workspace, the live contour remains blocked by evidence, not by local code changes.

Implemented:

- `ops/release/cycle_1573_live_contour_gate.py` — fail-closed evidence intake gate;
- `tests/architecture/test_cycle_1573_live_contour_gate.py` — guard that prevents silent advancement or live-proof claims;
- `reports/generated/cycle_1573_live_contour_gate_v171_57.json` — machine evidence showing all four live contours are still false;
- inherited screenshot manifest for v171.57, because UI did not change.

Proof status:

- `LIVE_TELEGRAM_NOT_VERIFIED`;
- `REAL_TONCONNECT_NOT_VERIFIED`;
- `REAL_TONPROOF_NOT_VERIFIED`;
- `REAL_TRANSACTION_NOT_VERIFIED`.

Validation scope: targeted gate tests and protocol gate only. Full CI remains user-run.
---

# Cycle 1573 — compact header reference refresh / v171.56

Status: `ACTIVE / UI_REFINEMENT_COMPLETE / LIVE_PROOF_OPEN`.

Completed in this bounded continuation:

- refined `GlobalHeader` visual proportions to better match the supplied balance reference;
- compressed text-only Activ/VIP indicators and lengthened the balance pill;
- tightened mobile Profile topbar, hero spacing and status rhythm without changing business logic;
- preserved sticky Profile tabs and the bottom safe-area protection contract;
- re-verified French FAQ 2.3 replacement and 2.7 non-regression across mirrors;
- produced seven fresh browser-captured component/page proof PNG at 360/390/430/768 px;
- kept cycle 1573 active because live Telegram / real TonConnect / TonProof / transactions are still not factually verified.

Cycle boundary:

- cycle 1572 is complete by green user-run logs;
- cycle 1573 remains active;
- cycle 1574 is not started.
---

# Cycle 1572 — fresh GitHub log repair and header visual refinement / v171.52

Status: `LOCAL_REPAIR_COMPLETE / CYCLE_CONTINUES`.

Completed locally:

- parsed `logs_81110261160.zip` and isolated exactly two pytest failures;
- preserved the successful GitHub evidence for Ruff, frontend build, budgets, mypy, bandit, flake8, compileall, PostgreSQL and Alembic;
- removed current control-text collisions with the archive filename-hygiene guard without weakening the guard;
- replaced the whitespace-fragile EFHC header-label assertion with a semantic markup assertion;
- refined the GlobalHeader exact-balance card with integer/fraction hierarchy and no truncation;
- made active Activ and VIP use the same gold text glow; inactive states remain gray text only and all status containers remain absent;
- performed only targeted checks: `9 passed`;
- created three fresh changed-header screenshots at 360/390 px;
- surfaced actual mobile/tablet Profile baselines from the current screenshot evidence package;
- documented concrete frontend optimization options.

Not run by design:

- full pytest, full CI or GitHub-equivalent local workflow;
- npm dependency installation, typecheck or production build;
- broad browser matrix or live Telegram/TonConnect proof.

Cycle 1572 remains active until the user supplies the next GitHub rerun for `v171.52`. Next planned cycle after green CI: `1573`.

---

# Cycle 1572 — AI law anti-diversion and anti-sabotage hardening / v171.51

Status: `CONTROL_LAYER_REPAIRED / CYCLE_1572_CONTINUES`.

Completed:

- independently verified `EFHC_Bot_v171_50_Screenshots.zip`;
- confirmed `363` PNG and the three new `header_visual_1572` screenshots;
- added an explicit prohibition of project diversion and sabotage to the mandatory AI Archive Laws by direct user instruction;
- synchronized the lock hash, SSOT canon, enforcement NORM, mandatory integrity script, Kernel and handoff;
- did not change application runtime or UI;
- did not run full CI, npm install, typecheck or production build.

Cycle 1572 remains active. Next application step is the user's fresh GitHub rerun; next archive number is `v171.52`.

---

# Cycle 1572 — GitHub log and GlobalHeader visual repair / v171.50

Status: `LOCAL_REPAIR_COMPLETE / FRESH_GITHUB_RERUN_REQUIRED`.

Completed locally:

- parsed `logs_81093410130.zip` and isolated three Ruff plus five pytest
  failures without changing unrelated contours;
- normalized the three import blocks;
- made screenshot evidence lookup schema-aware and incremental;
- removed the terminology false positive without weakening the guards;
- corrected the clipped header balance and aligned the top row;
- changed GlobalHeader Activ/VIP to gray inactive text or glowing active text,
  without pills or highlights;
- added targeted guards, reconciled stale header guards and obtained `38 passed`, `1 skipped`;
- created three fresh Chromium component screenshots and a verified companion
  archive with `363` PNG (`3` fresh).

Open boundary:

- full-app E2E, local typecheck and post-change production build are
  `BLOCKED_EXTERNAL` by repeated registry `503`;
- fresh GitHub CI for `v171.50` is still required;
- cycle 1572 remains active until that rerun is reconciled.

Next planned cycle after green CI: `1573`.

---

# Cycle 1572 — workspace recovery and remaining-route synchronization / v171.49

Status: `PLANNING_SYNC_DONE / CYCLE_1572_CONTINUES`.

This iteration restored the canonical tree once into `/mnt/data/efhc_workspace`,
verified the factual stop point and synchronized the remaining release route.
No application code or protected runtime contour was changed.

Confirmed stop point:

- `v171.48` is a transfer/execution-boundary repair snapshot;
- the previous factual application implementation is `v171.47`;
- cycle 1572 is active and not complete;
- the last supplied CI evidence had `2416 passed`, `19 skipped`, `3 failed`;
- those three failures were local PNG evidence checks and were removed from blocking CI in `v171.48`;
- a fresh GitHub rerun for `v171.48` or later has not been supplied.

Remaining ordered route:

1. Finish cycle 1572 from fresh user-supplied GitHub logs: exact root-cause repair, bounded targeted checks, blocker reconciliation and bundle/runtime evidence only where directly actionable.
2. Cycle 1573: operator-controlled live Telegram, TonConnect/TonProof and real transaction-boundary proof. No secrets are stored in the archive.
3. Cycle 1574: fail-closed RC audit, residual P0/P1 closure, release-owner/rollback/sign-off evidence and truthful decision.

Next substantive archive after this planning snapshot: `v171.50`.

---

# Cycle 1572 — transfer and execution-boundary repair

Status: `TRANSFER_READY / CYCLE_CONTINUES`.

Completed:

- classified the three supplied CI failures as local PNG evidence checks;
- removed PNG and companion requirements from blocking CI;
- kept local screenshot verification under `visual_evidence`;
- added bounded execution, retry and packaging stop conditions;
- added a complete new-chat handoff prompt;
- prepared output `v171_48` for continued cycle 1572 work.

Not claimed: full cycle 1572 completion, fresh GitHub CI, full local
regression, new frontend build or new visual proof.

Next archive after substantive work: `v171_49`.

---

# Cycle 1570 — Public/Admin interaction, visual, load and recovery

Status: `DONE_LOCALLY_WITH_CONTROLLED_BROWSER_PROOF`.

Completed locally:

- 15/15 protected public routes and 13/13 languages;
- 17/17 Admin routes and 12/12 launcher DOM-click actions;
- controlled public financial, referral, wallet and Admin confirmation flows;
- numeric shell and dynamic PWA-cache progress;
- adaptive bounded cache with privacy-safe network-only financial data;
- FAQ locale splitting and lazy TonConnect, sound and skin modules;
- gzip/Brotli budgets for 36 routes;
- Web Vitals platform dimensions and low-end recovery states;
- supplied-log repair for 10 pytest and 3 ruff failures.

Not claimed: fresh GitHub CI, production Cache Storage, live Telegram, real
TonConnect or blockchain transfers, release-ready or production-ready.

Next cycle: `1571 — Full regression and GitHub workflow normalization`.

---

# Cycle 1563 — TonConnect wallet and transaction UX

Status: `DONE_LOCALLY_WITH_CONTROLLED_BROWSER_PROOF`.

Completed locally:

- runtime and fallback TonConnect manifest alignment;
- reactive wallet state and session restore;
- complete TonProof envelope in wallet binding;
- backend Ed25519, domain and payload verification proof;
- visible connection and transaction rejection states;
- transaction signing and watcher-confirmed UX;
- seven current browser screenshots;
- controlled Chromium wallet and transaction scenarios.

Not claimed: live HTTPS deployment, a real wallet signature, a real network
transaction, live Telegram verification or fresh GitHub CI.

Detailed document:
`docs/cycles/WORK_CYCLES_1563_TONCONNECT.md`.

Next cycle: `1564 — Admin Panel MVP`.

---

# Cycle 1561 — funding correction, Withdraw and Energy

Status: `DONE_LOCALLY_WITH_OPERATOR_VISUAL_OPEN`.

## Required correction

The `v171.35` Direct Deposit implementation was incorrect. It accepted
native TON, applied pricing and credited EFHCm. Its former verification
status is revoked.

The active canon is now:

- `Прямое пополнение`: direct EFHC jetton transfer to EFHCm;
- `Пополнение`: HUB opens Browser Shop purchase for TON/GRAM or USDT.

## Completed implementation

- direct EFHC jetton TEP-74 transaction builder;
- backend EFHC master, decimals and memo metadata;
- watcher rejects non-EFHC assets for direct deposit;
- exact EFHCj to EFHCm credit quantity;
- Browser Shop TON/GRAM and USDT methods;
- Withdraw React Query create, cancel, detail, status and history;
- Energy exact progress and eight-decimal generation rates;
- public browser interaction and responsive screenshots.

## Proof boundary

Public visual proof is established. Admin Withdraw code, routes and
operator actions are statically and unit protected, but a new admin
browser screenshot was not obtained on the managed Chromium host.

Fresh CI, live Telegram, real jetton transactions and payout are not
claimed.

---

# 1560 — HUB and Direct Deposit / v171.35 — DONE locally

- HUB now has exactly two equal primary actions.
- EFHC handoff uses a typed service and React Query mutation.
- VIP NFT opens the fixed GetGems URL.
- Direct Deposit accepts a positive TON amount.
- Canonical memo stays backend-generated as `EFHC:<global_id>`.
- Watcher credit is reconciled through balance history.
- Human checking and confirmed states are visible.
- Browser proof covers four viewports and five screenshots.
- Full regression: `2274 passed`, `129 skipped`, `0 failed`.
- Release evidence score: `24 / 100`.
- Next cycle: `1561 — Withdraw user and operator contour`.

---

# Cycle 1559 — Profile, Wallet, History and FAQ

Status: `DONE LOCALLY / OUTPUT v171.34`.

## Input

- Archive: `EFHC_Bot_v171_33.zip`.
- SHA-256:
  `9b959774b20a640d6992ee755e3dece5a85bee1bf02b7abc2ce8ea2cf222323d`.
- ZIP: `testzip=None`.
- Records: `4188` (`3962` files, `226` directories).
- Forbidden artifacts: `0`.

## Completed scenarios

- One routed Profile surface instead of three competing interfaces.
- Typed Wallet, balance-history and withdrawal-history query linkage.
- Full FAQ vertical tree and Profile launcher.
- Responsive proof at four viewport sizes.
- Profile and FAQ proof in all thirteen canonical languages.

## Evidence

- Exact full regression: `2399` nodes, `2271 passed`, `128 skipped`,
  `0 failed`.
- Browser language matrix: `26 / 26` passed.
- Responsive surface matrix: `5 / 5` passed.
- Release evidence score: `21 / 100`.

Fresh CI, live Telegram, real TonConnect, real PostgreSQL concurrency,
release-ready and production-ready are not established.

Detailed cycle document:
`docs/cycles/WORK_CYCLES_1559_PROFILE_WALLET_HISTORY_FAQ.md`.

---

# Cycle 1558 — Referrals, Ranks and navigation icon repair

Status: `DONE LOCALLY / OUTPUT v171.33`.

## Input

- Archive: `EFHC_Bot_v171_32.zip`.
- SHA-256:
  `87d794d1125485ebfca69e8d876e9364c920763837439a7253c46a2db9405d29`.
- ZIP: `testzip=None`.
- Records: `4172` (`3947` files, `225` directories).
- Forbidden artifacts: `0`.

## Completed scenarios

- Referrals: typed statistics/list queries, deep-link copy and share.
- `start_param`: retry-safe bind marker and existing backend protections.
- Ranks: personal rank, generated kWh and vertical TOP-100.
- Header: only `EFHC`, without the visual word `Total`.
- Logo: universal energy SVG instead of the dense legacy coin image.
- Bottom navigation: six consistent original SVG icons.

## Evidence

- Browser Referrals/Ranks interaction proof: passed at `390x844`.
- Exact full regression: `2394` nodes, `2267 passed`, `127 skipped`,
  `0 failed`.
- Release evidence score: `19 / 100`.

Fresh CI, live Telegram, real TonConnect, real PostgreSQL concurrency,
release-ready and production-ready are not established.

Detailed cycle document:
`docs/cycles/WORK_CYCLES_1558_REFERRALS_RANKS_NAVIGATION.md`.

---

# Cycle 1557 — Tasks, Ads alias and compact typography

Status: `DONE LOCALLY / OUTPUT v171.32`.

## Input

- Archive: `EFHC_Bot_v171_31.zip`.
- SHA-256:
  `c67d2763308bae654979207f48ec431c7394fe8b2a280db01f9a5e08ba5ce7fe`.
- ZIP: `testzip=None`.
- Records: `4155` (`3931` files, `224` directories).
- Forbidden artifacts: `0`.

## Completed scenario

`/tasks -> React Query -> validated service/DTO -> backend action ->
credit boundary -> invalidation -> visible claimed state`.

- Tasks now has one operational catalogue.
- `/ads` remains a compatibility alias to `/tasks`.
- Custom claims reject double credit through the paid replay guard.
- Advertising status joins `user_tasks_status` into `/tasks/my`.
- Claim and advertising completion refetch task state and snapshot.
- The shared modal is rendered above fixed bottom navigation.
- Global typography uses a compact Arial-like stack.
- Panels and Exchange economic values remain on one line at 390 px.

## Evidence

- Browser Tasks/Ads action proof: passed.
- Panels and Exchange typography proof: passed.
- Exact full regression: `2389` nodes, `2263 passed`, `126 skipped`,
  `0 failed`.
- Release evidence score: `15 / 100`.

Fresh CI, live Telegram, real TonConnect, real PostgreSQL concurrency,
release-ready and production-ready are not established.

Detailed cycle document:
`docs/cycles/WORK_CYCLES_1557_TASKS_ADS_TYPOGRAPHY.md`.

---

# Cycle 1556 — Panels, Exchange and release readiness

Status: `DONE LOCALLY / OUTPUT v171.31`.

## Input

- Archive: `EFHC_Bot_v171_30.zip`.
- SHA-256:
  `7ffd094d3bdcf8b1b71a8458ec642e60b917dd22751677941a5a47b0e174cd4e`.
- ZIP: `testzip=None`.
- Records: `4134` (`3911` files, `223` directories).
- Forbidden artifacts: `0`.

## Completed scenarios

- Panels: activation uses generated DTO validation, React Query state,
  idempotency and visible list/summary refetch.
- Exchange: preview and conversion use query hooks, normalized amount,
  idempotency and visible balance refetch.
- Browser evidence passed for both routes at `390x844`.
- Route-to-service transaction-boundary tests passed.
- Full regression: `2379` unique nodes, `2255 passed`, `124 skipped`,
  `0 failed`, with no omitted node.
- A twelve-domain, 100-point release-readiness plan now controls cycles
  1557–1574 and the 99-percent release-candidate gate.

## Evidence boundary

Two consecutive clean `npm run build` executions exited naturally with all
thirty-four Next routes verified. Real PostgreSQL atomicity, fresh CI, live
Telegram and real TonConnect are not established.

Detailed cycle document:
`docs/cycles/WORK_CYCLES_1556_PANELS_EXCHANGE_RELEASE_READINESS.md`.

---

# Cycle 1555 — shell, Energy runtime and public browser proof

Status: `DONE LOCALLY / OUTPUT v171.30`.

## Input

- Archive: `EFHC_Bot_v171_29.zip`.
- SHA-256:
  `2c3a5e0dfa2084e678943299239b04eb5b78d4dedf9d79603670ae68e320fb08`.
- ZIP: `testzip=None`.
- Records: `4097` (`3876` files, `221` directories).
- Forbidden artifacts: `0`.
- AI Archive Laws integrity: passed before changes.

## Scenario completed

`Browser/PWA entry -> shell -> Energy -> protected navigation -> public route`.

Implemented:

- compact browser notice instead of a duplicate Energy mock;
- canonical shell loading and focus behavior;
- localized accessible navigation names with protected English visual labels;
- document `lang` synchronized with the selected locale;
- Energy first paint initialized from the validated snapshot;
- exact zero progress without a synthetic two-percent minimum;
- deterministic one-worker Next production build by default;
- policy-compatible local browser proof through a controlled HTML proxy;
- twelve protected public routes verified at `390x844`;
- exact thirteen-language proof and locale-key parity.
- architecture collection: `2070 passed, 7 skipped`;
- full pytest collection: `2235 passed, 123 skipped`;
- two consecutive clean production builds, thirty-four routes each.

## Language-scope finding

`C1555-LANGUAGE-SCOPE-COMPRESSION` was caused by conflating:

1. the complete thirteen-language EFHC Bot runtime;
2. the `RU/UK/EN` minimum smoke-test sample;
3. three external Google Sites;
4. English visible labels in the protected bottom navigation.

The complete bot scope remains exactly thirteen languages. The exception for
English visual navigation labels does not affect localized accessibility or
page language.

## Proof boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for the public cycle-1555 matrix only.

Not established:

- admin visual matrix;
- GitHub CI for `v171.30`;
- live Telegram;
- real TonConnect transaction;
- MVP release audit;
- release-ready or production-ready status.

No economic, backend, auth, payment, wallet, withdraw, DB or migration canon
was changed.

---

# Cycle 1554 — MVP critical-path audit and Energy/frontend repair

Status: `DONE LOCALLY / OUTPUT v171.29`.

## Input

- Archive: `EFHC_Bot_v171_28.zip`.
- SHA-256:
  `a02f51dd918da4d30bc12c754dbd5a3e38ffda7f58230af4a7f181aaa6d9bff2`.
- ZIP: `testzip=None`.
- Records: `4086` (`3867` files, `219` directories).
- Forbidden artifacts: `0`.
- AI Archive Laws integrity: passed before changes.

## MVP scenario repaired

`Browser/Telegram shell -> snapshot load -> Energy -> contextual next step`.

Root causes:

1. Energy rendered three competing surfaces at once.
2. `useSnapshot` called the transport directly and manually duplicated the
   response shape.
3. Browser fallback hid initial loading and recoverable error states.
4. `Layout` did not use the active canonical shell primitives.
5. Next static-page collection oversubscribed the operator host and stalled.

Implemented:

- Zod snapshot DTO and `snapshot.service.ts`.
- React Query snapshot hook through service/query-key registry.
- explicit `loading / recoverable-error / content / browser-preview` state.
- one cohesive Energy surface with all MVP-required values.
- one contextual action: Panels when no panel is active, Exchange when kWh is
  available, otherwise Panels state.
- canonical shell primitives wired into `Layout`.
- stable `npm run build` path uses official Next webpack compilation;
  `prebuild` clears only `.next` and `tsconfig.tsbuildinfo`; page-data
  workers remain configurable through `EFHC_NEXT_BUILD_CPUS`, default 2.
- replacement mapping for inactive legacy Energy dashboard components.

## Evidence boundary

Passed locally: AI lock, TypeScript, repeatable production frontend build,
public-copy firewall, direct-public-API gate, Agent Skills gate, targeted
tests, full pytest (`2228 passed, 126 skipped`) and the frontend
architecture make target.

Browser screenshots are not claimed. The available system Chromium rejects
local URLs with `ERR_BLOCKED_BY_ADMINISTRATOR`; a separate Playwright browser
could not be downloaded in the sandbox network.

No economy, balances formula, panel price, referral amount, payment,
TonConnect, wallet, withdraw, auth, DB or Alembic canon changed.

Range `1501-1600`: `54 / 100` done, `46 / 100` remaining.
Next: `1555 — shell/navigation runtime completion and visual-proof repair`.

---

# Cycle 1553 — Fresh CI archive and skills log repair

Status: DONE locally.

Input: `EFHC_Bot_v171_27.zip` and `logs_75642227264.zip`.
Output: `EFHC_Bot_v171_28.zip`.

Closed: ruff unused-variable drift, fail-closed release-status anchor,
CI-created local log artifact guard, Agent Skills line72 drift and
legacy Ranks-forbidden terms.

Not claimed: GitHub CI green, full pytest green, frontend build green,
live Telegram proof, real TonConnect proof, release-ready or
production-ready.

---

# Latest cycle — 1552 / v171.27

- Current HEAD: `v171_27 / v171.27`.
- Last cycle: `1552 — Archive Purity / Naming Guard Repair`.
- Range `1501–1600`: `52 / 100` done, `48 / 100` remaining.
- Output archive: `EFHC_Bot_v171_27.zip`.
- Repaired incident: previous `v171_26` ZIP included `.local_artifacts/logs/app.log` and the final report incorrectly claimed `forbidden artifacts 0`.
- Closed: archive purity cleanup, compact filename canon, operator hygiene guard, release artifact hygiene guard and current-head archive numbering guard.
- Runtime business logic was not changed.
- Not claimed: GitHub CI green, full pytest green, frontend build green, visual runtime verified, live Telegram proof, real TonConnect proof, release-ready or production-ready.

Next safe cycle: `1553 — Fresh CI Rerun / Archive Purity Confirmation`.

---

# Latest cycle — 1551 / v171.26

- Current HEAD: `v171_26 / v171.26`.
- Last cycle: `1551 — Agent Skills Adapter Fix`.
- Range `1501–1600`: `51 / 100` done, `49 / 100` remaining.
- Input TZ: `tz_v171_26_agent_skills_adapter_fix.md` from user message.
- Closed: invalid TOML in ship commands, stale EFHC startup hook test anchor,
  broken persona links, missing TOML/link validation in adapter scanner,
  EventSource/WebSocket direct public API scanner coverage, hooks fallback path
  and plugin metadata drift.
- Foundation fix only: no runtime money/auth/TON/withdraw/wallet/DB/migration
  logic changed.
- Not claimed for output `v171.26`: GitHub CI green, full pytest green,
  frontend build green, visual runtime verified, live Telegram proof, real
  TonConnect proof, release-ready or production-ready.

Next safe cycle: `1552 — Fresh CI Rerun / Agent Skills Adapter Fix Follow-up`.

---

# Latest cycle — 1550 / v171.25

- Current HEAD: `v171_25 / v171.25`.
- Last cycle: `1550 — Agent Skills Adapter Foundation`.
- Range `1501–1600`: `50 / 100` done, `50 / 100` remaining.
- Uploaded TZ: `tz_v171_24_agent_skills_kernel_integration.md`.
- Upstream archive: `agent-skills-main.zip`.
- Closed: root AGENTS/CLAUDE entrypoints, EFHC adapter document, adapted
  skills/commands/personas, upstream index, scanner and architecture guard.
- Agent Skills are subordinate to AI Archive Laws, SSOT, NORM and user
  instruction.
- No runtime money/auth/TON/withdraw/wallet/DB/migration logic changed.
- Not claimed for output `v171.25`: GitHub CI green, full pytest green,
  frontend build green, visual runtime verified, live Telegram proof, real
  TonConnect proof, release-ready or production-ready.

Next safe cycle: `1551 — Fresh CI Rerun / Agent Skills Adapter Follow-up`.

---

# Latest cycle — 1549 / v171.24

- Current HEAD: `v171_24 / v171.24`.
- Last cycle: `1549 — Fresh CI Service API Gate Log Repair`.
- Range `1501–1600`: `49 / 100` done, `51 / 100` remaining.
- Uploaded log: `logs_74815399993.zip`.
- Failed gate in uploaded log: `pytest`.
- Passed gates in uploaded log: `ruff`, `mypy backend/app`, `bandit`,
  `compileall`, Alembic, `npm ci`, frontend build.
- Closed: stale service/API migration architecture guards, new query seam
  `global_id` alias drift, TonConnect/referral/profile/browser-shop service seam
  guard drift and numbered-label hygiene.
- Not claimed for output `v171.24`: GitHub CI green, full pytest green,
  frontend build green, visual runtime verified, live Telegram proof, real
  TonConnect proof, release-ready or production-ready.

Next safe cycle: `1550 — Fresh CI Rerun / Service API Gate Confirmation`.

---

# Latest cycle — 1548 / v171.23

- Current HEAD: `v171_23 / v171.23`.
- Last cycle: `1548 — API Service React Query Migration Gate`.
- Range `1501–1600`: `48 / 100` done, `52 / 100` remaining.
- Uploaded TZ: `tz_v171_20.md`.
- Closed: public UI direct API migration gate, expiring allowlist policy,
  scanner, pytest guard, service/query seams for P0 flows and frontend command
  linkage.
- P0 migrated flows: `browser-shop`, `withdraw`, `tasks`, `panels`, `exchange`.
- Public copy firewall and public API migration gate pass locally.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed for output `v171.23`.
- Next safe cycle: `1549 — Fresh CI Rerun / Service API Gate Follow-up`.

---

# Latest cycle — 1547 / v171.22

- Current HEAD: `v171_22 / v171.22`.
- Last cycle: `1547 — Fresh CI Public Copy Log Repair`.
- Range `1501–1600`: `47 / 100` done, `53 / 100` remaining.
- Uploaded log: `logs_74688208405.zip`.
- Failed gates in the log: `ruff`, `pytest`.
- Passed gates in the log: `flake8`, `mypy backend/app`, `bandit`,
  `compileall`, Alembic, `npm ci`, frontend build.
- Repaired public-copy scanner style, import ordering, FAQ SSOT/generated
  drift, non-English `portal.web_profile.no_data`, stale exact-copy guards and
  numbered-label hygiene.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed for output `v171.22`.
- Next safe cycle: `1548 — Fresh CI Rerun / Visual Proof Runtime Follow-up`.

---

# Latest cycle — 1546 / v171.21

- Current HEAD: `v171_21 / v171.21`.
- Last cycle: `1546 — Visual Proof Splash Settle Guard`.
- Range `1501–1600`: `46 / 100` done, `54 / 100` remaining.
- Uploaded audit/TZ/patch: `a_v171_18.md`, `tz_v171_18.md`,
  `visual_proof_splash_fix_v171_17_v2.patch`.
- Closed: visual proof splash capture race, DOM marker-only success,
  admin click wait race and missing explicit minimum `2500ms` settle timing.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, frontend build green, visual runtime
  verified, live Telegram proof, real TonConnect proof and release-ready are
  not claimed for output `v171.21`.
- Next safe cycle: `1547 — Fresh CI Rerun / Visual Proof Runtime Follow-up`.

---

# Latest cycle — 1545 / v171.20

- Current HEAD: `v171_20 / v171.20`.
- Last cycle: `1545 — Public Copy Firewall Guard`.
- Range `1501–1600`: `45 / 100` done, `55 / 100` remaining.
- Uploaded TZ: `tz_v171_17_copy_guard.md`.
- Closed: public technical copy firewall, scanner, pytest guard,
  Makefile/frontend command linkage, public copy cleanup and rough empty-state
  copy guard.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, frontend build green, DOM visual proof,
  live Telegram proof, real TonConnect proof and release-ready are not claimed
  for output `v171.20`.
- Next safe cycle: `1546 — Fresh CI Rerun / Public Copy Proof Follow-up`.

---

# Latest cycle — 1544 / v171.19

- Current HEAD: `v171_19 / v171.19`.
- Last cycle: `1544 — Fresh CI Memo Log Repair`.
- Range `1501–1600`: `44 / 100` done, `56 / 100` remaining.
- Input CI log: `logs_74672087378.zip`.
- Failed gates repaired: `ruff`, `mypy backend/app`, `pytest`.
- Closed: ruff style/import ordering, watcher memo adapter mypy return type,
  i18n locale-count drift to `1465`, and memo SSOT guard cast compatibility.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, frontend build green, live Telegram
  proof, real TonConnect proof and release-ready are not claimed for output
  `v171.19`.
- Next safe cycle: `1545 — Fresh CI Rerun Confirmation / Live Proof Follow-up`.

---

# Latest cycle — 1543 / v171.18

- Current HEAD: `v171_18 / v171.18`.
- Last cycle: `1543 — Memo Canon / Webhook / Raw Error Repair`.
- Range `1501–1600`: `43 / 100` done, `57 / 100` remaining.
- Uploaded audit/TZ: `a_v171_17.md`, `tz_v171_17.md`.
- Closed: P0 memo drift, panels activate UX, webhook defensive commit,
  middleware comment drift, admin raw error tails and raw-error guard gap.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed for output `v171.18`.
- Next safe cycle: `1544 — Fresh CI Rerun Confirmation / Live Proof Follow-up`.

---

# Latest cycle — 1542 / v171.17

- Current HEAD: `v171_17 / v171.17`.
- Last cycle: `1542 — Fresh CI Rerun Guard Repair`.
- Range `1501–1600`: `42 / 100` done, `58 / 100` remaining.
- Uploaded log: `logs_74653569841.zip`.
- Failed gates in the uploaded log: `pytest` only.
- Passed gates in the uploaded log: flake8, ruff, mypy backend/app, bandit,
  compileall, Alembic, npm ci and frontend build.
- Repaired locally: stale architecture guard expecting exact referral import
  whitespace; guard now checks semantic import symbols.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed for output `v171.17`.
- Next safe cycle: `1543 — Fresh CI Rerun Confirmation / Visual Proof Follow-up`.

---

# Latest cycle — 1541 / v171.16

- Current HEAD: `v171_16 / v171.16`.
- Last cycle: `1541 — Fresh CI Frontend Noise Log Repair`.
- Range `1501–1600`: `41 / 100` done, `59 / 100` remaining.
- Uploaded log: `logs_74645134614.zip`.
- Failed gates in the uploaded log: `ruff`, `pytest`.
- Passed gates in the uploaded log: flake8, mypy backend/app, bandit,
  compileall, Alembic, npm ci and frontend build.
- Repaired locally: import ordering, stale UX guards, ErrorBoundary safe-copy
  guard alignment, wave-3 i18n error-copy fallbacks, PWA offline shell
  compatibility, line-length drift and root-doc label hygiene.
- Runtime economy, rates, balances, referral bonus amount, wallet binding,
  TonConnect proof, idempotency, money-flow and withdraw business logic were
  not changed.
- GitHub CI green, full pytest green, live Telegram proof, real TonConnect
  proof and release-ready are not claimed for output `v171.16`.
- Next safe cycle: `1542 — Fresh CI Rerun Confirmation / Visual Proof Follow-up`.

---

# Latest cycle — 1540 / v171.15

- Current HEAD: `v171_15 / v171.15`.
- Last cycle: `1540 — Frontend Error Noise Cleanup`.
- Range `1501–1600`: `40 / 100` done, `60 / 100` remaining.
- New audit/TZ read: `docs/audits/a_v171_12.md`, `docs/audits/tz_v171_12.md`.
- Chat intake: `docs/NORM/CHATS/36.md` added and indexed.
- Closed locally: all ten `v171_12` frontend error-noise findings from P0 through P3.
- Runtime economy, rates, balances, referral bonus amount, wallet binding, TonConnect proof, idempotency, money-flow and withdraw business logic were not changed.
- GitHub CI green, full pytest green, live Telegram proof, real TonConnect proof and release-ready are not claimed for output `v171.15`.
- Next safe cycle: `1541 — Fresh CI Frontend Noise Cleanup Confirmation / Visual Proof Follow-up`.

---

# Latest cycle — 1539 / v171.14

- Current HEAD: `v171_14 / v171.14`.
- Last cycle: `1539 — Fresh CI / Live Referral Proof Gate`.
- Range `1501–1600`: `39 / 100` done, `61 / 100` remaining.
- Dashboard direction `1455–1496`: closed/frozen `42 / 42`.
- New external evidence: no new `logs_*.zip`, audit or TZ was provided.
- Closed locally: proof-gate status, release overclaim guard, Kernel/map/cycle
  documentation refresh and Operator Kernel task registration.
- Runtime economy, money-flow, wallet-flow, withdraw business logic,
  TonConnect, referral bonus amount and frontend money mutation were not
  changed.
- Output GitHub CI green, full pytest green, live Telegram proof, real WebApp
  referral proof, real TonConnect proof and release-ready are not claimed.
- Next safe cycle: `1540 — Fresh CI Evidence Intake / Live Proof Follow-up`.

---

# Latest cycle — 1538 / v171.13

- Current HEAD: `v171_13 / v171.13`.
- Last cycle: `1538 — Fresh CI Artifact Hygiene Log Repair`.
- Range `1501–1600`: `38 / 100` done, `62 / 100` remaining.
- Dashboard direction `1455–1496`: closed/frozen `42 / 42`.
- Uploaded log `logs_74600883162.zip` was red on ruff and pytest.
- Repaired locally: import ordering, forbidden frontend build artifact,
  stale route-count markers and bot middleware identity spelling.
- Output GitHub CI green and release-ready are not claimed.
- Next safe cycle: `1539 — Fresh CI Green Confirmation / Live Referral Proof Gate`.

---

# Latest cycle — 1537 / v171.12

Cycle 1537 closed referral persistence and Telegram webhook DB DI audit
findings locally. Range status: `37 / 100` done, `63 / 100` remaining.
Next safe cycle: `1538 — Fresh CI Rerun / Referral Persistence Confirmation`.

---

# Latest cycle — 1536 / v171.11

Cycle 1536 repaired fresh CI red-log drift after referral UX repair.

- Input HEAD: `v171.10`.
- Uploaded log: `logs_74569153381.zip`.
- Failed gates in log: ruff, mypy and pytest.
- Repaired locally: ruff import ordering, mypy no-any-return in start
  payload extraction, i18n manual coverage fallbacks, OpenAPI route snapshot
  drift, frontend route linkage drift and public locale-count guard drift.
- No runtime economy, money-flow, wallet-flow, withdraw business logic,
  TonConnect or frontend money mutation changes were made.
- Range status: `36 / 100` done, `64 / 100` remaining.
- Next safe cycle: `1537 — Fresh CI Rerun Confirmation / Referral Live Proof Gate`.

---

# Latest cycle — 1535 / v171.10

Cycle 1535 closed the referral binding / UX audit findings locally.

- P0 referral deep-link activation: closed locally.
- `/start ref_<code>` now has a production call-site to referral attach.
- WebApp `start_param` fallback posts to authenticated `/referrals/bind`.
- Withdraw raw toast and exchange mutation copy were corrected.
- First-run onboarding tour was added as UI-only state.
- Range status: `35 / 100` done, `65 / 100` remaining.
- Next safe cycle: `1536 — Fresh CI Rerun / Referral Live Proof Gate`.

---

# Current range status update — after cycle 1534

- Current HEAD: `v171.09`.
- Last cycle: `1534 — Fresh CI Rerun / Hygiene Log Repair`.
- Range `1501–1600`: `34 / 100` done, `66 / 100` remaining.
- Dashboard direction `1455–1496`: closed/frozen `42 / 42`.
- Next safe cycle: `1535 — Fresh CI Rerun Confirmation / Mypy Scope Follow-up`.

## 1534 — Fresh CI Rerun / Hygiene Log Repair / v171.09 — DONE locally

Uploaded log `logs_74538464541.zip` was red on ruff and pytest. Repaired
logged failures only: NFT route runtime test import ordering, numbered
work-pass filename in NORM report, and numbered work-pass text in root Kernel
and Healer indexes. No runtime, money-flow, wallet-flow, withdraw logic,
TonConnect, frontend runtime or EFHC economy changes were made.

No GitHub-CI-green, release-ready or production-ready claim is made for
output `v171.09`.

---

# Current range status update — after cycle 1533

- Current HEAD: `v171.08`.
- Last cycle: `1533 — Scheduler Notify Fix / Admin Facade Cleanup`.
- Range `1501–1600`: `33 / 100` done, `67 / 100` remaining.
- Dashboard direction `1455–1496`: closed/frozen `42 / 42`.
- Next safe cycle: `1534 — Fresh CI Rerun / Mypy Scheduler-Facade Confirmation`.

## 1533 — Scheduler Notify Fix / Admin Facade Cleanup / v171.08 — DONE locally

Closed audit/TZ findings:

- `P1-WITHDRAWALS-PROCESSOR-DOUBLE-BUG`.
- `P1-REPORTS-DAILY-NOTIFY-GENERIC`.
- `P2-DEAD-CODE-ADMIN-FACADE-APPROVE-WITHDRAW`.
- `P2-DEAD-CODE-ADMIN-FACADE-REJECT-WITHDRAW`.
- `P1-MYPY-SCOPE-STILL-REACTIVE` as staged expansion plus guard.

No release-ready or production-ready claim was made.

---

# Current range status update — after cycle 1532

- Current HEAD: `v171.07`.
- Last cycle: `1532 — Fresh CI Rerun / Mypy Scope Follow-up`.
- Done: `32 / 100`.
- Remaining: `68 / 100`.
- Uploaded CI log `logs_74475316189.zip` was red: ruff and pytest failed.
- Mypy full scope passed in the log: `Success: no issues found in 283 source files`.
- Ruff import-order failures and stale Kernel guard drift are repaired locally.
- Fresh GitHub CI for output `v171.07` is not claimed.
- Next safe cycle: `1533 — Fresh CI Rerun Confirmation / Live Proof Gate`.

---

## 1532 — Fresh CI Rerun / Mypy Scope Follow-up / v171.07 — DONE locally after red-log repair

- Input HEAD: `EFHC_Bot_v171_06_cycle_1531_global_signature_drift_fix.zip`.
- Uploaded log: `logs_74475316189.zip`.
- Log verdict: red.
- Failed gates: ruff and pytest.
- Passed gates included mypy full report, bandit, compileall, Alembic,
  npm ci and frontend build.
- Repaired ruff import ordering in three new cycle 1531 runtime tests.
- Repaired stale exact-version Kernel assertion in the cycle 1529 guard.
- Runtime, money-flow, wallet flow, withdraw logic, TonConnect behavior,
  frontend runtime and EFHC economy were not changed.
- Output GitHub CI green, full pytest green, full frontend build green,
  live Telegram proof, real TonConnect proof and release-ready are not claimed.
- Next safe planned cycle: `1533 — Fresh CI Rerun Confirmation / Live Proof Gate`.

Range status after 1532: `32 / 100` done, `68 / 100` remaining.

# Current range status update — after cycle 1531

- Current HEAD: `v171.06`.
- Last cycle: `1531 — Global Signature Drift Fix`.
- Done: `31 / 100`.
- Remaining: `69 / 100`.
- All global audit kwarg/signature mismatch findings are closed locally.
- Fresh GitHub CI for output `v171.06` is not claimed.
- Next safe cycle: `1532 — Fresh CI Rerun / Mypy Scope Follow-up`.

---

## 1530 — Fresh CI Rerun Confirmation / v171.05 — DONE locally with green input evidence

- Input HEAD: `EFHC_Bot_v171_04_cycle_1529_fresh_ci_log_repair_kernel_anchor_restore.zip`.
- Uploaded log: `logs_74465909794.zip`; verdict green for input HEAD `v171.04`.
- Passed in log: flake8 critical/full, ruff, mypy, bandit, compileall,
  PSQL pre-check, Alembic upgrade head, pytest, npm ci, frontend build and
  final gate summary.
- Pytest: `1962 passed, 8 skipped, 2 warnings in 50.74s`.
- Gate summary: `OK: all gate steps passed.`
- No code defect was found in the log; this cycle records the green CI
  evidence and updates release proof status, Kernel, map, reports and guard
  manifest.
- Runtime, money-flow, wallet flow, withdraw logic, TonConnect behavior,
  frontend runtime and EFHC economy were not changed.
- GitHub CI green is confirmed for `v171.04`, not for output archive
  `v171.05` until a fresh rerun is provided for `v171.05`.
- Live Telegram proof, real TonConnect proof, release-ready and
  production-ready are not claimed.
- Next safe planned cycle: `1531 — Live Telegram / Real TonConnect Evidence
  Intake`.

Range status after 1530: `30 / 100` done, `70 / 100` remaining.

## 1529 — Fresh CI Evidence Intake / Red-log Repair / v171.04 — DONE locally after red-log repair

- Input HEAD: `EFHC_Bot_v171_03_cycle_1528_kernel_map_compaction_test_consolidation.zip`.
- Uploaded log: `logs_74445426759.zip`; verdict red.
- CI log passed before pytest gate: ruff, mypy, bandit, compileall,
  Alembic upgrade head, npm ci and frontend build.
- Failed gate: pytest, `24 failed, 1933 passed, 8 skipped, 2 warnings`.
- Root cause: cycle 1528 compacted `KERNEL.md` while legacy architecture
  guards still expected exact historical navigation anchors in root Kernel.
- Repair: restored compact compatibility anchors in `KERNEL.md`, registered
  the current repair in `map_element.md` and added route compatibility anchors.
- Targeted logged-failure replay passed locally: `31 passed`.
- Runtime, money-flow, wallet flow, withdraw logic, TonConnect behavior,
  frontend runtime and EFHC economy were not changed.
- GitHub CI green for output archive, full pytest green, full frontend build
  green, live Telegram proof, real TonConnect proof and release-ready are not
  claimed.
- Next safe planned cycle: `1530 — Fresh CI Rerun Confirmation / Remaining
  Guard Drift Intake`.

Range status after 1529: `29 / 100` done, `71 / 100` remaining.

## 1528 — Kernel / map_element Compaction Pass / v171.03 — DONE locally fail-closed

- Output archive target: `EFHC_Bot_v171_03_cycle_1528_kernel_map_compaction_test_consolidation.zip`.
- No fresh `logs_*.zip` was provided; GitHub CI green is not claimed.
- `KERNEL.md` kept compact and current.
- `map_element.md` received a compact current section while historical anchors
  remain preserved for older guards.
- Low-risk chat-docs guards were consolidated into
  `tests/architecture/test_chat_docs_intake.py` with mapping.
- Runtime, money-flow, wallet flow, TonConnect behavior and EFHC economy were
  not changed.
- Next safe planned cycle: `1529 — Fresh CI Evidence Intake / Red-log Repair`.

Range status after 1528: `28 / 100` done, `72 / 100` remaining.

## 1527 — Fresh GitHub CI Evidence Intake / Chat Docs / Test Consolidation / v171.02 — DONE locally fail-closed

- HEAD input: `EFHC_Bot_v171_01_cycle_1526_fresh_ci_live_tonconnect_proof.zip`.
- Output archive target: `EFHC_Bot_v171_02_cycle_1527_ci_evidence_chat_docs_test_consolidation.zip`.
- No `logs_*.zip` was provided; GitHub CI green is not claimed.
- Added chat exports `34.md` and `35.md` to canonical `docs/NORM/CHATS/`.
- Updated `CHATS_INDEX.md`, `README.md`, reports index, Kernel and map.
- Added a proposal-only test guard consolidation candidate list.
- No tests were merged, deleted, skipped or xfailed.
- Runtime, money-flow, wallet flow, withdraw logic, TonConnect behavior,
  frontend runtime and EFHC economy were not changed.
- Current progress for `1501–1600`: done `27 / 100`, remaining `73 / 100`.
- Next safe planned cycle: `1528 — Kernel / map_element Compaction Pass`.

## 1526 — Fresh CI Rerun / Live Telegram / Real TonConnect Proof / v171.01 — DONE locally fail-closed

- Input HEAD: `EFHC_Bot_v171_00_cycle_1525_archive_numbering_rollover_repair.zip`.
- Output archive: `EFHC_Bot_v171_01_cycle_1526_fresh_ci_live_tonconnect_proof.zip`.
- No fresh `logs_*.zip` was provided, so no red log was parsed and GitHub CI
  green is not claimed.
- Refreshed release proof gate for input `v171.00` and output `v171.01`.
- Live Telegram proof remains `BLOCKED_MISSING_ENV`.
- Real TonConnect proof remains `BLOCKED_MISSING_ENV`.
- Fresh GitHub CI proof remains `NOT_PROVIDED_FOR_V171_00`.
- P0 withdrawals guard and withdrawals NULL fixture guard passed locally in
  targeted architecture checks.
- DB-backed withdrawals runtime tests were collected with `PYTHONPATH=backend`
  and skipped locally because no Postgres test DB is available.
- Runtime service code, money-flow, withdraw logic, wallet binding logic,
  TonConnect behavior, frontend runtime and EFHC economy were not changed.
- Current progress for `1501–1600`: done `26 / 100`, remaining `74 / 100`.
- Next safe planned work item: `1527 — Fresh GitHub CI Evidence Intake / Red-log Repair`.

## 1525 — Archive Numbering Rollover Repair / v171.00 — DONE locally

- Emergency repair accepted by user after numbering regression.
- Previous valid lineage anchor: `v170.99`.
- Correct canonical rollover version: `v171.00`.
- Problem: local archive version used a forbidden three-digit minor suffix
  after `_99`.
- Fix: reissued current HEAD under canonical rollover version and updated
  Kernel, map, reports, generated metadata, release status and cycle docs.
- Added guard: `tests/architecture/test_archive_numbering_rollover_guard.py`.
- Runtime code, money-flow, withdraw logic, TonConnect behavior and EFHC
  economy were not changed.
- Output GitHub CI green, live Telegram proof, real TonConnect proof and
  release-ready are not claimed.
- Current progress for `1501–1600`: done `25 / 100`, remaining `75 / 100`.
- Next safe planned cycle: `1526 — Fresh CI rerun / Live Telegram / Real
  TonConnect proof`.

## 1524 — Fresh CI Rerun / Withdrawals Runtime Test Isolation Repair / v171.00 — DONE locally

- HEAD input: `EFHC_Bot_v170_99_cycle_1523_p0_admin_withdrawals_list_regression_fix.zip`.
- Log source: `logs_74379950976.zip`.
- Input CI log was red only because pytest failed: `2 failed, 1938 passed, 8 skipped, 2 warnings`.
- Non-pytest CI gates in the uploaded log passed: ruff, mypy, bandit,
  compileall, Alembic, npm ci and npm build.
- Root cause: cycle 1523 withdrawals DB runtime tests inserted absent
  `users.ton_wallet` as empty string, violating `uq_users_ton_wallet`.
- Fix: withdrawals runtime test helpers now insert `NULL` for absent legacy wallet.
- Added guard `tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py`.
- Runtime service code, money-flow, withdraw business logic and EFHC economy were not changed.
- Output GitHub CI green, live Telegram proof, real TonConnect proof and release-ready are not claimed.
- Current progress for `1501–1600`: done `24 / 100`, remaining `76 / 100`.
- Next safe planned cycle: `1525 — Archive Numbering Rollover Repair`.

## 1523 — P0 Admin Withdrawals List Regression Fix / v170.99 — DONE locally

- HEAD input: `EFHC_Bot_v170_98_cycle_1522_fresh_ci_rerun_log_repair.zip`.
- Audit input: `CYCLE_1523_P0_WITHDRAWALS_LIST.md`.
- P0 fixed locally: `P0-ADMIN-WITHDRAWALS-LIST-ALWAYS-EMPTY`.
- `list_withdrawals()` now reads real `withdraw_requests` without checking
  legacy `bonus_awards`.
- Runtime service and route tests added; AST guard scope tests added.
- Release-ready and production-ready are not claimed.

## 1522 — Fresh CI rerun / external proof evidence intake log repair / v170.98 — DONE locally

- HEAD input: `EFHC_Bot_v170_97_cycle_1521_live_release_readiness_gate.zip`.
- Input log: `logs_74335271498.zip`; verdict red.
- CI log passed before pytest failure: flake8, ruff, mypy, bandit,
  compileall, Alembic, npm ci and npm build.
- Repaired pytest failures: `line72` in public visual proof script, stale
  panels route-evidence guard after generated seam migration and missing
  static route evidence in the panels page.
- Public panels page keeps generated seam constants; raw public money endpoint
  `apiRequest("/panels/activate"` remains forbidden.
- Added guard: `tests/architecture/test_fresh_ci_rerun_log_repair.py`.
- GitHub CI green for output archive, live Telegram proof, real TonConnect
  proof and release-ready are not claimed.
- Current progress for `1501–1600`: done `22 / 100`, remaining `78 / 100`.
- Next safe planned work item: `1523 — Fresh CI rerun / external proof evidence intake`.

## 1521 — Live Telegram / Real TonConnect / Release Readiness Proof Gate / v170.97 — DONE locally

- HEAD input: `EFHC_Bot_v170_96_cycle_1520_frontend_i18n_visual_closure.zip`.
- Added fail-closed release proof gate: `ops/release/release_readiness_proof_gate.py`.
- Generated report: `reports/generated/live_release_readiness_gate_v170_97.json`.
- Local visual/i18n proof reports from `v170.96` are recorded as passed.
- Live Telegram proof remains blocked without external live URL and bot env.
- Real TonConnect proof remains blocked without external wallet/live endpoint env.
- Fresh GitHub CI proof for output archive is not claimed.
- Release readiness is explicitly blocked: `NOT_RELEASE_READY`.
- Added guard: `tests/architecture/test_live_release_readiness_gate.py`.
- Current progress for `1501–1600`: done `21 / 100`, remaining `79 / 100`.
- Next safe planned work item: `1522 — Fresh CI rerun / external proof evidence intake`.

## 1519 — Fresh CI proof / red-log repair / v170.95 — DONE locally

- HEAD input: `EFHC_Bot_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.zip`.
- Input log: `logs_74249190312.zip`; verdict red.
- CI log green before pytest/frontend gate: flake8, ruff, mypy, bandit, compileall, Alembic and PSQL pre-check.
- Repaired pytest failures: KERNEL numbered work-pass labels, package-lock internal registry marker, line72 violations, stale ORM table count `43 → 44`, withdraw approve/list legacy `bonus_awards` guard, generation-rate literals outside SSOT.
- Repaired frontend gate failure: `form-data` resolved URL now points to public npm registry.
- Added guard: `tests/architecture/test_fresh_ci_log_repair.py`.
- GitHub CI green for output archive, full pytest green, full frontend build green and release-ready are not claimed.
- Current progress for `1501–1600`: done `19 / 100`, remaining `81 / 100`.
- Next safe planned work item: fresh CI rerun for `v170.95` or new audit intake.

## 1517 — Frontend Buttons / API / i18n Drift Audit / v170.93 — DONE locally

- HEAD input: `EFHC_Bot_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.zip`.
- Closed locally: `P2-ADMIN-FEATURES-BYPASS-ADMIN-SEAMS`.
- Admin feature/components now use `adminApiRequest`, generated admin seam constants and `adminPath` for admin routes.
- Closed locally: `P2-I18N-NODE-AUDIT-SCRIPTS-BROKEN-DIRNAME`.
- `ops/i18n/audit_locale_placeholders.js` and `ops/i18n/audit_identical_to_english.js` now run successfully.
- `npm audit --audit-level=high` is clean after lockfile update to `form-data@4.0.6`.
- Runtime economy changed: no. Backend money logic changed: no. TonConnect canon weakened: no.
- GitHub CI green, full pytest green, full frontend build green, browser proof, live Telegram proof, live TonConnect proof and release-ready are not claimed.
- Current progress for `1501–1600`: done `17 / 100`, remaining `83 / 100`.
- Next safe planned cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.

## Work item 1515 — Fresh CI Rerun Proof / Visual Proof Preparation — DONE v170.91

- Input HEAD: `v170.90`.
- Output HEAD: `v170.91`.
- No new `logs_*.zip` was provided; fresh GitHub CI green is not claimed.
- Prepared admin visual/button-click proof matrix.
- Rechecked 1514 repaired admin/runtime tails with targeted local tests.
- Local validation passed: targeted pytest pack (`68 passed, 4 skipped`), ruff, mypy, bandit backend/app, compileall, npm ci, npm audit, npm typecheck, and Next build with `CIRCLE_NODE_TOTAL=1`.
- Full pytest timed out without final verdict; full pytest green is not claimed. Browser screenshots, full button-click proof, live Telegram proof, real TonConnect proof and release-ready are not claimed.
- Range `1501–1600`: `15 / 100` done, `85 / 100` remaining.
- Next safe cycle: `1516 — Browser/Admin visual capture and button-click execution proof`.

## Work item 1514 — Admin UX QA / Visual Regression / Full Button Click Proof — DONE v170.90

- Input HEAD: `EFHC_Bot_v170_89_cycle_1513_fresh_ci_admin_seams_tail_closure.zip`.
- Input log: `logs_74028431848.zip` was red: pytest failed with `22 failed, 1843 passed, 8 skipped, 1 warning`.
- Repaired missing `efhc_admin.admin_notifications` ORM coverage, outcome delivery JSONB path binding, stale adminSeams guards and top-level `get_bot` import in `tasks_service.py`.
- Admin pages remain in strict seam mode with zero raw admin `apiRequest` calls.
- Visual/browser click proof remains `VISUAL_NOT_VERIFIED`; output GitHub CI green is not claimed without a fresh rerun.
- Range `1501–1600`: `14 / 100` done, `86 / 100` remaining.
- Next safe cycle: `1515`.

## Work item 1511 — GitHub CI log repair — DONE v170.87

- Input HEAD: `EFHC_Bot_v170_86_cycle_1510_wallet_model_replacement_trace.zip`.
- Input log: `logs_74007805923.zip`.
- Repaired exact log failures: ruff import order, mypy no-any-return and
  stale TON address regression expectation.
- Added `docs/NORM/GITHUB_CI_LOG_REPAIR.md`.
- Added `tests/architecture/test_github_ci_log_repair.py`.
- No economy, PACK-01, PACK-02, PACK-03, CI/workflow or lockfile changes.
- Range `1501–1600`: `11 / 100` done, `89 / 100` remaining.
- Next safe cycle: `1512`.

## Work item 1510 — Wallet Model Replacement Trace — DONE v170.86

- Input HEAD: `EFHC_Bot_v170_85_cycle_1509_pack_03_final_cleanup_consistency.zip`.
- Answered and guarded the audit question: the removed
  `backend/app/models/wallet_models.py` is replaced by
  `backend/app/models/wallets_models.py::WalletBinding`.
- Supporting runtime pieces: `wallets_service.py`,
  `tonconnect_proof_service.py`, `wallets_routes.py` and
  `ton_address.py::canonicalize_ton_address`.
- Added `docs/NORM/WALLET_MODEL_REPLACEMENT_TRACE.md`.
- Added `tests/architecture/test_wallet_model_replacement_trace.py`.
- No economy, withdraw canon, admin payout canon, CI/workflow or lockfile
  changes.

## Work item 1509 — PACK-03 Final Cleanup and Consistency — DONE v170.85

- Input HEAD: `EFHC_Bot_v170_84_cycle_1508_pack_02_tails_wallet_canon_cleanup.zip`.
- Closed wallet legacy naming cleanup: no runtime `UserWallet` alias and no
  active `app.models.wallet_models` import.
- Added direct EFHC payment intent canon and watcher incoming deposit
  accounting canon.
- Adjusted direct EFHC confirmation so a later different `tx_hash` for the
  same direct intent is not silently dropped.
- Created DB drift matrix, admin button coverage matrix, frontend/API/i18n
  consistency matrix and release proof status.
- Release proof status: `PARTIAL_PROOF`, `CI_NOT_VERIFIED`,
  `VISUAL_NOT_VERIFIED`, `NOT_RELEASE_READY`.
- No EFHC economy change. PACK-01 and PACK-02 canons preserved.
- Range `1501–1600`: `9 / 100` done, `91 / 100` remaining.
- Next safe cycle: `1510`.

## Work item 1508 — PACK-02 tails wallet canon cleanup — DONE v170.84

- Input HEAD: `EFHC_Bot_v170_83_cycle_1507_ton_wallet_canon_admin_payout.zip`.
- Closed tail 1: removed active legacy `admin_wallets_service.py` contour
  based on `efhc_core.crypto_wallets`.
- Closed tail 2: added existing-database canonical backfill for old
  `wallet_bindings.wallet_address` formats in `0001_init.py`.
- Added NORM docs, cycle doc, generated report, change report and
  architecture guards.
- No EFHC economy, withdraw PACK-01 canon, admin payout canon, frontend
  runtime, CI/workflow or dependency change.
- Range `1501–1600`: `8 / 100` done, `92 / 100` remaining.
- Next safe cycle: `1509`.

## Work item 1504 — DASH-03 Grafana Pattern Map Completion — DONE v170.80

- Input HEAD: `EFHC_Bot_v170_79_cycle_1503_admin_domain_report_endpoints_foundation.zip`.
- Closed audit/TZ finding `DASH-03`: completed Grafana pattern map sections for Grid layout, Drill-down and Empty/error states.
- Added active NORM, cycle note, generated report, change report and architecture guard.
- Audit/TZ repair block `1501–1504` is now closed locally: `4 / 4` done, `0 / 4` remaining.
- No runtime, CSS, backend, OpenAPI, migration, dependency, lock file, CI/workflow, economy or money-flow was changed.
- Песочница and Grafana remain reference-only layers; runtime code was not copied.
- Range `1501–1600`: `4 / 100` done, `96 / 100` remaining.
- Next safe cycle: `1505 — GitHub CI Rerun Proof`.

## Work item 1503 — DASH-02 Admin Domain Report Endpoints — DONE v170.79

- Input HEAD: `EFHC_Bot_v170_78_cycle_1502_dash_01_orphan_bank_dashboard_deletion.zip`.
- Closed audit/TZ finding `DASH-02`: added five read-only admin domain report endpoints.
- Added `GET /admin/reports/users`, `/bank`, `/panels`, `/withdrawals` and `/deposits`.
- Synced OpenAPI route-source snapshot and frontend generated admin seams.
- Added `33.md` to `docs/NORM/CHATS/` and updated chat guards.
- No Alembic migration, money-flow, economy, dependency, lock file or CI/workflow was changed.
- Range `1501–1600`: `3 / 100` done, `97 / 100` remaining.
- Next safe cycle: `1504 — DASH-03 Grafana Pattern Map Completion`.

## Work item 1502 — DASH-01 Orphan Bank Dashboard Deletion — DONE v170.78

- Input HEAD: `EFHC_Bot_v170_77_cycle_1501_dashboard_ui_kit_consolidation_qa.zip`.
- Closed audit/TZ finding `DASH-01`: deleted orphan `AdminInteractiveBankDashboard.tsx`.
- Added guard against reimport of `AdminInteractiveBankDashboard` and admin `buildSeries` reintroduction.
- Updated Sandbox inventory, Kernel, map, reports index and test guard manifest.
- No backend, OpenAPI, migration, money-flow, economy, dependency, lock file, CI/workflow or active bank runtime behavior changed.
- Песочница and Grafana remain reference-only layers; runtime code was not copied.
- Range `1501–1600`: `2 / 100` done, `98 / 100` remaining.
- Next safe cycle: `1503 — DASH-02 Admin Domain Report Endpoints Foundation`.

## Work item 1501 — Dashboard UI Kit Consolidation QA — DONE v170.77

- Input HEAD: `EFHC_Bot_v170_76_cycle_1500_final_range_closure.zip`.
- Closed audit/TZ finding `CYC-1459`: `DashboardPanelAction` now supports `onClick` and explicit `actionKind`.
- Contract version updated to `EFHC_DASHBOARD_CONTRACT_V2`.
- Added active NORM, cycle note, generated report, change report and architecture guard.
- Archived audit/TZ: `docs/audits/AUDIT_TZ_REPAIR_1501_1504.md`.
- Remaining audit/TZ findings are assigned to `1502–1504`: `DASH-01`, `DASH-02`, `DASH-03`.
- No backend, OpenAPI, migration, money-flow, economy, dependency, lock file, CI/workflow or existing runtime behavior changed.
- Песочница and Grafana remain reference-only layers; runtime code was not copied.
- Range `1501–1600`: `1 / 100` done, `99 / 100` remaining.
- Next safe cycle: `1502 — DASH-01 Orphan AdminInteractiveBankDashboard deletion`.

## Work item 1500 — Final Range Closure / Transition to 1501–1600 — DONE v170.76

- Overall range `1401–1500`: `100 / 100` done, `0 / 100` remaining.
- Closed overall range `1401–1500` with final closure artifacts and transition guard.
- Dashboard direction `1455–1496` remains closed/frozen: `42 / 42` done, `0 / 42` remaining.
- Confirmed future range plan: `docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`.
- Next safe cycle: `1501 — Dashboard UI Kit Consolidation QA`.
- Added final range closure NORM, cycle note, generated report, change report and active architecture guard.
- No backend write-flow, money-flow, economy, migration, OpenAPI route set, dependency, lock file or CI/workflow change was introduced.
- No GitHub CI green, full pytest green, full frontend build green, release-ready, browser screenshot proof, live Telegram proof or real TonConnect proof is claimed for `v170.76`.

## Work item 1499 — VIS-03 Withdraw History Semantic Repair / Final Range Cleanup — DONE v170.75

- Fixed green log proof from `logs_73559592200.zip`.
- Closed `VIS-03`: public withdraw history renders semantic localized balance labels instead of raw `main` / `bonus` enum values.
- Added guard markers to `/withdraw` history rows and active architecture guard `test_vis_03_withdraw_history_semantic_repair.py`.
- No backend write-flow, money-flow, economy, migration, OpenAPI route set, dependency, lock file or CI/workflow change was introduced.
- Overall range `1401–1500`: `99 / 100` done, `1 / 100` remaining.
- Dashboard direction remains closed: `42 / 42`.

## Work item 1498 — CI Log Repair / Public Dashboard i18n Hardening — DONE v170.74

- Repaired factual failures from `logs_73496341059.zip`.
- Fixed ruff SIM102 in dashboard handoff guard.
- Fixed mypy row mapping assignment in `admin_observability_routes.py`.
- Renamed audit follow-up doc/test files to satisfy filename hygiene.
- Hardened public dashboard i18n: no English-identical fallback values remain in guarded public dashboard locale keys.
- Admin dashboards remain Russian operator surfaces.
- Overall range `1401–1500`: `98 / 100` done, `2 / 100` remaining.
- Dashboard direction remains closed: `42 / 42`.

## Cycle 1497 — Dashboard Direction Audit Follow-up / Future Range Foundation — DONE v170.73

- Accepted audit verdict `DIRECTION_COMPLETE_WITH_KNOWN_GAPS`.
- Closed orphan `AdminInteractiveBankDashboard.tsx` synthetic-series risk by marking it `@deprecated ORPHAN DO NOT IMPORT` and removing `buildSeries`.
- Added missing reusable Sim/Admin UI Kit wrappers from dashboard plan §9/§10.
- Created `docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`.
- Froze `admin_domain_report_endpoints_backlog` into future range instead of implementing partial endpoints inside completed dashboard direction.
- Overall range `1401–1500`: `97 / 100` done, `3 / 100` remaining.
- Dashboard direction remains closed: `42 / 42`; cycle 1497 is audit follow-up, not a reopening of the direction.

## Cycle 1496 — Dashboard Direction Handoff / Backlog Freeze — DONE v170.72

- Dashboard direction `1455–1496` closed: `42 / 42` done, `0 / 42` remaining.
- Public user-facing dashboards are fixed as a 13-language UI surface.
- Admin dashboards remain Russian operator surface and are outside the public 13-language claim.
- Remaining dashboard work is frozen into backlog: post-VIS-03 regression QA, optional admin i18n, browser screenshot proof, GitHub CI rerun proof and release audit.
- Overall range `1401–1500`: `96 / 100` done, `4 / 100` remaining.

# v170.70 / cycle 1494 — Accessibility / Localization / Overflow QA

Status: DONE locally.

- Shared dashboard primitives now expose accessibility markers and status/progress semantics.
- Dashboard progress bars expose `role=progressbar` and aria values.
- Dashboard CSS has additional overflow/mobile hardening for long values and long translations.
- Exchange/Profile `raw snapshot` placeholder locale values were localized.
- Real time-series filter labels were localized for Russian admin UI.
- No backend, OpenAPI, migration, economy, write-flow, dependency, lock-file or CI/workflow change was introduced.
- Current progress: `1401–1500` = `94 / 100`, remaining `6 / 100`; Dashboard `1455–1496` = `40 / 42`, remaining `2 / 42`.
- Next: `1495 — Final Dashboard Visual Audit / Screenshot Proof`.

# v170.69 / cycle 1493 — Visual Performance / Bundle Safety

Status: DONE locally.

- `/admin` now lazy-loads `AdminObservabilityTimeseriesDashboardRuntime` via `next/dynamic` with `ssr: false`.
- Heavy chart libraries and Grafana runtime dependencies remain absent.
- Public/TMA pages do not import admin dashboard runtime components.
- No backend, OpenAPI, migration, economy, write-flow, dependency, lock-file or CI/workflow change was introduced.
- Current progress: `1401–1500` = `93 / 100`, remaining `7 / 100`; Dashboard `1455–1496` = `39 / 42`, remaining `3 / 42`.
- Next: `1494 — Accessibility / Localization / Overflow QA`.

## 1491 — Real Time-Series Backend Contracts / v170.67 — DONE locally

- HEAD input: `EFHC_Bot_v170_66_cycle_1490_admin_logs_events_dashboard.zip`.
- Green CI proof fixed from `logs_73205751012.zip`.
- Added active norm document: `docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS.md`.
- Added Grafana element analysis: `docs/NORM/REAL_TIME_SERIES_BACKEND_CONTRACTS_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added backend read-only route module: `backend/app/routes/admin_observability_routes.py`.
- Added read-only contracts: summary, timeseries, events and health.
- Rebuilt checked-in OpenAPI static route snapshot.
- Regenerated frontend admin seams for the new contracts.
- No economy, migration, dependency, lock file, CI workflow, write-flow or money-flow changed.
- Next safe cycle: `1492 — Synthetic Data Cleanup / Truth Hardening`.

## 1490 — Admin Logs / Events Dashboard / v170.66 — DONE locally

- HEAD input: `EFHC_Bot_v170_65_cycle_1489_admin_system_health_dashboard.zip`.
- Repaired actual CI log failure from `logs_73159210416.zip`.
- Added active norm document: `docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD.md`.
- Added Grafana element analysis: `docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime component: `frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx`.
- Integrated read-only dashboard into `/admin/logs`.
- Existing Docker command helper stays below dashboard.
- No backend, OpenAPI, economy, DB migration, dependency, lock file, CI workflow, write-flow or money-flow changed.
- Next safe cycle: `1491 — Real Time-Series Backend Contracts`.

## 1488 — Admin Tasks / Referrals Dashboard Upgrade / v170.64 — DONE locally

- HEAD input: `EFHC_Bot_v170_63_cycle_1487_admin_panels_dashboard_upgrade.zip`.
- Added active norm document: `docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis: `docs/NORM/ADMIN_TASKS_REFERRALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime component: `frontend/src/components/admin/AdminTasksReferralsDashboardRuntime.tsx`.
- Integrated read-only dashboard into `/admin/tasks` and `/admin/referrals`.
- Closed `VIS-04`: Admin Tasks visible active/inactive labels are now Russian operator labels.
- Added chat exports `31.md` and `32.md` to `docs/NORM/CHATS/`.
- Existing approve/reject, refresh statuses, manual bonus and referral reassignment controls remain guarded outside dashboard.
- No backend, OpenAPI, economy, DB migration, dependency, lock file, CI workflow, write-flow or money-flow change.
- Next safe cycle: `1489 — Admin System Health Dashboard`.

## 1485 — Admin Deposits Dashboard Upgrade / v170.61 — DONE locally

- HEAD input: `EFHC_Bot_v170_60_cycle_1484_admin_users_dashboard_upgrade.zip`.
- Added active norm document: `docs/NORM/ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis: `docs/NORM/ADMIN_DEPOSITS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime admin deposits dashboard component: `frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx`.
- Integrated the dashboard into live admin route: `frontend/src/pages/admin/efhc-deposits.tsx`.
- Added guard: `tests/architecture/test_admin_deposits_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot` from existing runtime summary.
- No fake time-series, synthetic analytics, raw payload, debug JSON or secrets.
- Replay, exception processing and force fulfill controls remain guarded.
- No backend, OpenAPI, economy, dependency, lock file, write-flow or money-flow change.
- Next safe cycle: `1486 — Admin Withdrawals Dashboard Upgrade`.

## 1484 — Admin Users Dashboard Upgrade / v170.60 — DONE locally

- HEAD input: `EFHC_Bot_v170_59_cycle_1483_admin_bank_dashboard_upgrade.zip`.
- Added active norm document: `docs/NORM/ADMIN_USERS_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis: `docs/NORM/ADMIN_USERS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime admin users dashboard component: `frontend/src/components/admin/AdminUsersDashboardRuntime.tsx`.
- Integrated the dashboard into live admin route: `frontend/src/pages/admin/users.tsx`.
- Added guard: `tests/architecture/test_admin_users_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot` from current users search/detail state.
- Removed old sandbox-style `AdminInteractiveOperatorPanel` from `/admin/users`.
- Existing VIP/active/wallet reset/admin transfer controls remain guarded.
- No backend, OpenAPI, economy, dependency, lock file, write-flow or money-flow change.
- Next safe cycle: `1485 — Admin Deposits Dashboard Upgrade`.

## 1483 — Admin Bank Dashboard Upgrade / v170.59 — DONE locally

- HEAD input: `EFHC_Bot_v170_58_cycle_1482_admin_reports_grafana_like_upgrade.zip`.
- Added active norm document:
  `docs/NORM/ADMIN_BANK_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis:
  `docs/NORM/ADMIN_BANK_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime admin bank dashboard component:
  `frontend/src/components/admin/AdminBankDashboardRuntime.tsx`.
- Integrated the dashboard into live admin route:
  `frontend/src/pages/admin/bank.tsx`.
- Added guard:
  `tests/architecture/test_admin_bank_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot` from existing bank/overview/log data.
- Synthetic admin analytics, secrets, raw payload and debug JSON: no.
- Mint/burn confirmation flow remains separate and guarded.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `83 / 100`, remaining `17 / 100`.
- Dashboard direction progress: done `29 / 42`, remaining `13 / 42`.
- Next safe planned cycle: `1484 — Admin Users Dashboard Upgrade`.

## 1481 — Admin Overview Dashboard Upgrade / v170.57 — DONE locally

- HEAD input: `EFHC_Bot_v170_56_cycle_1480_web_profile_account_center_dashboard_polish.zip`.
- Added active norm document:
  `docs/NORM/ADMIN_OVERVIEW_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis:
  `docs/NORM/ADMIN_OVERVIEW_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime admin overview dashboard component:
  `frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx`.
- Integrated the dashboard into live admin route:
  `frontend/src/pages/admin/index.tsx`.
- Added guard:
  `tests/architecture/test_admin_overview_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot` from existing admin overview data.
- Synthetic admin analytics, secrets, raw payload and debug JSON: no.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `81 / 100`, remaining `19 / 100`.
- Dashboard direction progress: done `27 / 42`, remaining `15 / 42`.
- Next safe planned cycle: `1482 — Admin Reports Grafana-like Upgrade`.

# Cycle 1479 update — Exchange Dashboard Support Widgets

- `1479 — Exchange Dashboard Support Widgets` completed locally in `v170.55`.
- Added runtime component `ExchangeDashboardRuntime.tsx`.
- Live `/exchange` now has read-only support widgets for available kWh,
  exchangeable kWh, EFHC result, one-way rule and preview readiness.
- `ExchangePanel` remains the protected write/action form.
- No reverse exchange, fake history, economy, backend, OpenAPI,
  dependency, lock-file or write-flow change.
- Next safe cycle: `1480 — Web Profile / Account Center Dashboard Polish`.
- Dashboard direction progress: `25 / 42` done, `17 / 42` remain.
- 1401–1500 progress: `79 / 100` done, `21 / 100` remain.

# Cycle 1478 update — Referrals Dashboard Upgrade

- `1478 — Referrals Dashboard Upgrade` completed locally in `v170.54`.
- Added runtime component `ReferralsDashboardRuntime.tsx`.
- Live `/referrals` now shows referral growth and bonus dashboard cards.
- No fake referral history, public raw `global_id`, economy or write-flow change.
- Next safe cycle: `1479 — Exchange Dashboard Support Widgets`.
- Dashboard direction progress: `24 / 42` done, `18 / 42` remain.
- 1401–1500 progress: `78 / 100` done, `22 / 100` remain.

# Cycle 1477 update — Tasks Dashboard Upgrade

- `1477 — Tasks Dashboard Upgrade` completed locally in `v170.53`.
- Added runtime component `TasksDashboardRuntime.tsx`.
- Live `/tasks` now shows progress dashboard cards using raw + derived
  task snapshots.
- No public execution history, backend logs, idempotency/debug data,
  fake runtime tasks, economy or write-flow change.
- Next safe cycle: `1478 — Referrals Dashboard Upgrade`.
- Dashboard direction progress: `23 / 42` done, `19 / 42` remain.
- 1401–1500 progress: `77 / 100` done, `23 / 100` remain.

# Cycle 1476 update — Leaderboard Visual System

- `1476 — Leaderboard Visual System` completed locally in `v170.52`.
- Added shared component `LeaderboardVisualSystem.tsx`.
- Ranks runtime now uses shared podium/list visual components.
- No fake runtime rows, public raw `global_id`, economy or write-flow change.
- Next safe cycle: `1477 — Tasks Dashboard Upgrade`.
- Dashboard direction progress: `22 / 42` done, `20 / 42` remain.
- 1401–1500 progress: `76 / 100` done, `24 / 100` remain.

# Cycle 1475 — Ranks Dashboard Runtime Port

Status: `DONE_LOCAL`

Archive: `v170.51`

Result: live `/ranks` now renders `RanksDashboardRuntime` with raw +
derived snapshot data from existing backend ranks endpoints. The old
visual fallback that could make unloaded data look like `#1` was
removed. No fake leaderboard rows, no public raw `global_id`, no internal
12 Energy-level catalogue and no economy/backend/write-flow changes.

Next: `1476 — Leaderboard Visual System`.

# Cycle 1474 — Ranks Dashboard Sandbox Prototype

Status: `DONE_LOCAL`

Archive: `v170.50`

Result: sandbox-only Ranks dashboard prototype added. It includes rank
hero, leaderboard scope filter, username-only cards, visible position
milestones, score composition and privacy/truth strip. Runtime `/ranks`
was not changed, raw `global_id` is not exposed and the internal 12 Energy
levels were not reintroduced into Ranks.

Next: `1475 — Ranks Dashboard Runtime Port`.

# Cycle 1473 — Panel Cards Deep Polish

Status: `DONE_LOCAL`

Archive: `v170.49`

Result: runtime panel cards now have micro-state polish,
accessibility labels, explicit units, formatted UTC dates and no
duplicate archived lifecycle progress. Sandbox preview rates are
formula-derived and internally consistent.

Next: `1474 — Ranks Dashboard Sandbox Prototype`.

# Cycle 1472 — Panels Portfolio Runtime Port

Status: `DONE_LOCAL`

Archive: `v170.48`

Result: live `/panels` now renders `PanelsPortfolioRuntime` with raw +
derived snapshot data only. No synthetic runtime data, no fake
real-time series and no write-flow changes.

Next: `1473 — Panel Cards Deep Polish`.

# 1468 — Dependency Audit Triage / v170.44 — DONE locally

- Input HEAD: `v170.43 / Energy Dashboard Sandbox Prototype`.
- Logs read first: `logs_72723974684.zip`.
- Repaired supplied CI-log failures:
  - restored Kernel legacy marker `v170.27 / CI log repair`;
  - removed forbidden transient artifact `frontend/tsconfig.tsbuildinfo`.
- Closed npm audit vulnerabilities through controlled frontend dependency update.
- `npm audit --json` result after repair: `0` vulnerabilities.
- Updated docs:
  - `docs/NORM/DEPENDENCY_AUDIT_TRIAGE.md`;
  - `docs/NORM/DEPENDENCY_AUDIT_GRAFANA_ELEMENT_ANALYSIS.md`;
  - `docs/cycles/WORK_CYCLES_1468_DEPENDENCY_AUDIT_TRIAGE.md`;
  - `reports/generated/dependency_audit_triage_v170_44.json`.
- Dashboard plan shifted: old `1468 — Energy Dashboard Runtime Port` → new `1469`; final handoff moves to `1496`.
- Range progress: `68 / 100` done, `32 / 100` remain.
- Dashboard direction progress: `14 / 42` done, `28 / 42` remain.
- Next safe cycle: `1469 — Energy Dashboard Runtime Port`.

# 1467 — Energy Dashboard Sandbox Prototype / v170.43 — DONE locally

- HEAD input: `EFHC_Bot_v170_42_cycle_1466_variables_filters_system.zip`.
- Added active document: `docs/NORM/ENERGY_DASHBOARD_SANDBOX_PROTOTYPE.md`.
- Added Grafana element analysis: `docs/NORM/ENERGY_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added EFHC-owned prototype component: `frontend/src/components/dashboard/EnergyDashboardSandboxPrototype.tsx`.
- Prototype includes hero energy card, KPI strip, period switch, mini area chart, mini bar chart, activity strip, compact sparkline, segmented progress and safe CTA links to `/panels` and `/exchange`.
- Truth model: `synthetic_preview`; live runtime Energy route is not changed.
- Added guard: `tests/architecture/test_energy_dashboard_sandbox_prototype.py`.
- Updated Grafana and Песочница maps as reference-only layers.
- Recorded dependency audit follow-up from cycle 1466: `npm ci` reported 5 vulnerabilities (3 moderate, 2 high); no dependency/lock-file repair without separate permission.
- Boundaries: no economy, backend contract, DB migration, OpenAPI, CI/workflow, dependency, lock file, Grafana runtime, sandbox runtime, write-flow or money-action changes.
- Next safe cycle: `1468 — Energy Dashboard Runtime Port`.

# 1466 — Variables / Filters System / v170.42 — DONE locally

- HEAD input: `EFHC_Bot_v170_41_cycle_1465_dashboard_toolbar_foundation.zip`.
- Added active document: `docs/NORM/VARIABLES_FILTERS_SYSTEM.md`.
- Added runtime shared filters:
  `frontend/src/components/dashboard/DashboardFilters.tsx`.
- Added admin wrappers: `AdminVariableBar`, `AdminFilterBar`,
  `AdminStatusFilter`, `AdminOperationTypeFilter`,
  `AdminDateRangeFilter`, `AdminRouteFilter`.
- Added simulation wrappers: `SimFilterBar`, `SimPeriodFilter`,
  `SimPanelStateFilter`, `SimLeaderboardScopeFilter`.
- Added CSS foundation in `frontend/src/styles/globals.css`.
- Added guard: `tests/architecture/test_variables_filters_system.py`.
- Updated Grafana variables/filter anchor map in `map_element.md` and
  `docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md`.
- URL query sync is display-only and rejects unsafe query keys.
- Boundaries: no economy, backend contract, DB migration, CI/workflow,
  lock file, Grafana runtime, sandbox runtime, write-flow or money-action
  changes.
- Next safe cycle: `1467 — Energy Dashboard Sandbox Prototype`.

# 1465 — Dashboard Toolbar Foundation / v170.41 — DONE locally

- HEAD input: `EFHC_Bot_v170_40_cycle_1464_mini_charts_foundation.zip`.
- Added active document: `docs/NORM/DASHBOARD_TOOLBAR_FOUNDATION.md`.
- Added runtime shared toolbar:
  `frontend/src/components/dashboard/DashboardToolbar.tsx`.
- Added admin wrappers: `AdminTimeRangePicker`, `AdminRefreshPicker`,
  `AdminFreshnessBadge`.
- Added simulation wrappers: `SimDashboardToolbar`, `SimPeriodSwitch`,
  `SimFreshnessBadge`.
- Added CSS foundation in `frontend/src/styles/globals.css`.
- Added guard: `tests/architecture/test_dashboard_toolbar_foundation.py`.
- Updated Grafana toolbar anchor map in `map_element.md` and
  `docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md`.
- Boundaries: no economy, backend contract, DB migration, CI/workflow,
  lock file, Grafana runtime, or sandbox runtime changes.
- Next safe cycle: `1466 — Variables / Filters System`.

# 1462 — Panel Chrome Foundation / v170.38 — DONE locally

- HEAD input: `EFHC_Bot_v170_37_cycle_1461_admin_dashboard_ui_kit_foundation.zip`.
- Added active document: `docs/NORM/PANEL_CHROME_FOUNDATION.md`.
- Added runtime shared shell:
  `frontend/src/components/dashboard/PanelChrome.tsx`.
- Updated admin wrapper: `AdminPanelChrome`.
- Added simulation wrapper: `SimPanelChrome`.
- Added shared CSS in `frontend/src/styles/globals.css`.
- Added guard: `tests/architecture/test_panel_chrome_foundation.py`.
- Added deeper Grafana PanelChrome anchor map to `map_element.md`.
- Boundaries: no economy, backend contract, DB migration, CI/workflow,
  lock file, Grafana runtime, or sandbox runtime changes.
- Next safe cycle: `1463 — Progress System Foundation`.

# 1461 — Admin Dashboard UI Kit Foundation / v170.37 — DONE locally

- HEAD input: `EFHC_Bot_v170_36_cycle_1460_simulation_dashboard_ui_kit_foundation.zip`.
- Added active document: `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`.
- Added Grafana usage map: `docs/NORM/GRAFANA_EFHC_ELEMENT_USAGE_MAP.md`.
- Extended runtime admin component:
  `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
- Added CSS foundation in `frontend/src/styles/globals.css`.
- Added guard:
  `tests/architecture/test_admin_dashboard_ui_kit_foundation.py`.
- Boundaries: no economy, backend contract, DB migration, CI/workflow,
  lock file, Grafana runtime, or sandbox runtime changes.
- Next safe cycle: `1462 — Panel Chrome / единая оболочка панели`.

# 1460 — Simulation Dashboard UI Kit Foundation / v170.36 — DONE locally

- HEAD input: `EFHC_Bot_v170_35_cycle_1459_dashboard_component_contract.zip`.
- Added active document:
  `docs/NORM/SIMULATION_DASHBOARD_UI_KIT_FOUNDATION.md`.
- Added runtime foundation component:
  `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`.
- Added CSS classes for simulation dashboard shell, section, grid, hero,
  cards, stat cards, progress and status pills.
- Added deletion check:
  `docs/audits/DASHBOARD_DELETION_CHECK_V170_36.md`.
- Answer to user: old dashboard files were not deleted. Prior diff showed
  ZIP directory entries only, not source file removal.
- Preserved old dashboard files:
  `AdminDashboardUiKit.tsx`, `AdminInteractiveBankDashboard.tsx`,
  `AdminReportsVisualDashboardPanel.tsx`, and Grafana dashboard JSONs.
- Runtime economy changed: no. Backend contracts changed: no. DB
  migrations changed: no. CI/workflows/lock files changed: no.
- Grafana and Песочница runtime code copied: no.
- Tests were not deleted, archived, skipped or xfailed.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `60 / 100`, remaining
  `40 / 100`.
- Dashboard direction progress: done `6 / 41`, remaining `35 / 41`.
- Next safe step: `1461 — Admin Dashboard UI Kit Foundation`.

# 1458 — Dashboard Design Tokens Foundation / v170.34 — DONE locally

- HEAD input: `EFHC_Bot_v170_33_cycle_1457_grafana_visual_pattern_map.zip`.
- Added active token document:
  `docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`.
- Added EFHC-owned dashboard CSS variables to
  `frontend/src/styles/globals.css`.
- Token families cover surface, border, text, accent, semantic states,
  radius, spacing, shadow and typography.
- Added primitive utility classes for future dashboard panels.
- Grafana remains visual-pattern reference only.
- Песочница remains reference/navigation/prototype layer only.
- Runtime code, dependencies, lock files, CI files, backend logic,
  wallet/payment logic and economics from Grafana or Песочница were not
  copied.
- Runtime economy changed: no. Backend contracts changed: no. DB
  migrations changed: no. CI/workflows/lock files changed: no.
- Tests were not deleted, archived, skipped or xfailed.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `58 / 100`, remaining
  `42 / 100`.
- Dashboard direction progress: done `4 / 41`, remaining `37 / 41`.
- Next safe planned step: `1459 — Dashboard Component Contract`.

# 1457 — Grafana Visual Pattern Map / v170.33 — DONE locally

- HEAD input: `EFHC_Bot_v170_32_cycle_1456_sandbox_dashboard_inventory.zip`.
- Created active map: `docs/NORM/GRAFANA_VISUAL_PATTERN_MAP.md`.
- Created report: `reports/generated/grafana_visual_pattern_map_v170_33.json`.
- Added guard: `tests/architecture/test_grafana_visual_pattern_map.py`.
- Mapped Grafana patterns to EFHC-owned implementation targets:
  PanelChrome, DashboardGrid, TimeRangePicker, RefreshPicker,
  VariableBar, InspectorDrawer, StatCard, MiniChart and tables.
- Grafana remains visual-pattern reference only.
- Песочница remains reference/navigation/prototype layer only.
- Runtime code, dependencies, lock files, CI files, backend logic,
  wallet/payment logic and economics from Grafana or Песочница were not
  copied.
- Runtime economy changed: no. Backend contracts changed: no. DB
  migrations changed: no. CI/workflows/lock files changed: no.
- Tests were not deleted, archived, skipped or xfailed.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `57 / 100`, remaining
  `43 / 100`.
- Next safe planned step: `1458 — Dashboard Design Tokens Foundation`.

# 1455 — Dashboard Visual Kernel / v170.31 — DONE locally

- HEAD input: `EFHC_Bot_v170_30_cycle_1454_screenshot_proof_preparation.zip`.
- Dashboard Visual Direction Plan is now actively started.
- Added operational kernel: `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
- Active direction remains `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Dashboard work range remains `1455-1495`, 41 cycles.
- Next step is `1456 — Sandbox Dashboard Inventory`.
- Grafana remains visual-pattern reference only.
- Песочница remains reference/navigation/prototype layer only.
- Runtime code, dependencies, lock files, CI files, backend logic,
  wallet/payment logic and economics from Grafana or Песочница were not
  copied.
- Runtime economy changed: no. Backend contracts changed: no. DB
  migrations changed: no. CI/workflows/lock files changed: no.
- Tests were not deleted, archived, skipped or xfailed.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `55 / 100`, remaining
  `45 / 100`.
- Next safe planned step: `1456 — Sandbox Dashboard Inventory`.

## 1454 — Screenshot proof preparation / v170.30 — DONE locally

- HEAD input:
  `EFHC_Bot_v170_29_cycle_1453_ci_log_repair_dashboard_prep.zip`.
- Logs input: `logs_72687610241.zip`.
- Supplied CI log run is green for the input archive:
  - ruff: passed;
  - mypy: passed;
  - bandit: passed;
  - backend compileall: passed;
  - Alembic upgrade: passed;
  - pytest: `1306 passed, 8 skipped, 1 warning`;
  - npm ci: passed;
  - frontend build: passed;
  - gate summary: `OK: all gate steps passed.`
- Added screenshot proof preparation for Dashboard Visual Direction Plan.
- Added manifest:
  `reports/generated/dashboard_screenshot_proof_manifest_v170_30.json`.
- Added guard:
  `tests/architecture/test_dashboard_screenshot_proof_preparation.py`.
- Screenshot status: `SCREENSHOT_PREPARATION_READY_NO_CAPTURE`.
- No browser screenshots, live Telegram proof, real wallet proof or
  release-ready are claimed.
- Grafana and Песочница remain reference only; no runtime code copied.
- Current progress for `1401-1500`: done `54 / 100`, remaining
  `46 / 100`.
- Next safe planned step: `1455 — Dashboard Visual Kernel`.

## 1453 — CI log repair + Grafana map prep / v170.29 — DONE locally

- HEAD input:
  `EFHC_Bot_v170_28_cycle_1452_dashboard_visual_direction_plan.zip`.
- Logs input: `logs_72685602190.zip`.
- Root cause: CI gate failed only on pytest with two stale guard
  anchors:
  - admin bank import anchor mismatch;
  - missing Kernel legacy marker `v170.27 / CI log repair`.
- Repaired exact causes without changing runtime economy, backend
  contracts, DB migrations, CI/workflows or lock files.
- Updated `map_element.md` with explicit Grafana reference anchors for
  dashboard visual work.
- Grafana remains reference only; runtime code was not copied.
- Песочница remains reference/navigation/prototype layer only.
- Local targeted validation passed; external CI green is not claimed.
- Current progress for `1401-1500`: done `53 / 100`, remaining
  `47 / 100`.
- Next safe planned step: `1454 — screenshot proof preparation` or
  factual log repair if new `logs_*.zip` is supplied.

## 1451 — CI log repair / v170.27 — DONE locally

- HEAD input:
  `EFHC_Bot_v170_26_cycle_1450_visual_p0_countdown_followup_repair.zip`.
- Logs input: `logs_72682359351.zip`.
- Repaired factual CI failures from logs:
  - ruff `I001` import-order drift in backend services and chat guard;
  - pytest stale chat/Kernel/profile/canon guard anchors;
  - frontend build TypeScript failure from missing generated
    `AdminWithdrawOutcomePreviewResponse`.
- Added guard:
  `tests/architecture/test_ci_log_repair_v170_27_guards.py`.
- Runtime economy changed: no. Backend contracts changed: no.
  DB migrations changed: no.
- CI/workflows/lock files changed: no. Tests were not deleted,
  archived, skipped or xfailed.
- Local validation: ruff passed; canon guard passed; AI laws guard
  passed; targeted pytest set passed; wider guard pack `60 passed`.
- Frontend build green is not claimed. Local retry passed TypeScript
  and production compilation phases, then sandbox page-data worker hit
  `EPIPE`.
- Not claimed: GitHub CI green, full pytest green, release-ready,
  screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `51 / 100`, remaining
  `49 / 100`.
- Next safe planned cycle: fresh CI rerun proof or factual log repair
  if new `logs_*.zip` is provided.

## 1447 — Chat docs intake / v170.23 — DONE locally

- HEAD input: `EFHC_Bot_v170_22_cycle_1446_ci_rerun_log_repair.zip`.
- Scope: load user-provided chat exports into canonical chat docs.
- Added canonical chat copies:
  - `docs/NORM/CHATS/26.md`;
  - `docs/NORM/CHATS/27.md`;
  - `docs/NORM/CHATS/28.md`;
  - `docs/NORM/CHATS/30.md`.
- Updated chat index and README in `docs/NORM/CHATS/`.
- Added guard: `tests/architecture/test_chat_docs_intake.py`.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Local validation:
  - chat docs guard: `3 passed`;
  - selected kernel/filename guard subset: passed;
  - `py_compile` / `compileall` for architecture tests: passed.
- Not claimed: GitHub CI green, full pytest green, frontend build green,
  live proof gates or release-ready.
- Current progress for `1401-1500`: done `47 / 100`, remaining `53 / 100`.
- Next safe planned step: fresh CI rerun proof / release-gate
  preparation, or next log repair if fresh logs fail.

## 1446 — CI rerun log repair / v170.22 — DONE locally

- HEAD input: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`.
- Input logs: `logs_72627437860.zip`.
- Scope: read fresh logs first, repair factual CI failures, update docs,
  and keep release-ready wording forbidden until new proof.
- Root cause repaired:
  - ruff `I001` import-order drift in admin bank and transactions service;
  - pytest historical-audit status note failure in `ROUTE_INVENTORY_FREEZE.md`.
- Added guard: `tests/architecture/test_ci_log_repair_guards.py`.
- Added report: `reports/generated/ci_log_repair_v170_22.json`.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Local validation:
  - log-repair guards: `5 passed`;
  - kernel/filename guard subset: `13 passed`;
  - `py_compile` touched backend Python files: passed.
- Not claimed: GitHub CI green, full pytest green, frontend build green,
  live proof gates or release-ready.
- Current progress for `1401-1500`: done `46 / 100`, remaining `54 / 100`.
- Next safe planned cycle: `1447 — fresh CI rerun proof / release-gate
  preparation`, or next log repair if fresh logs fail.

## 1444 — Linkage repeat audit + HEALER tail reconciliation / v170.20 — DONE locally

- HEAD input: `EFHC_Bot_v170_19_cycle_1443_full_linkage_architecture_tests.zip`.
- Scope: local repeat audit of linkage findings `F-001…F-008` and HEALER loader/schema tail reconciliation.
- Repeat audit report: `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json` → `status=ok`, `blockers=[]`.
- Added script: `ops/linkage/repeat_linkage_healer_audit.py`.
- Added guard: `tests/architecture/test_linkage_repeat_audit_healer_tail.py`.
- HEALER tooling repair: `ops/healer/loader.py` accepts historical compact cards/cases through safe defaults; `ops/healer/run_once.py` accepts compact `version` keys.
- Local validation:
  - new guard file: `4 passed`;
  - targeted linkage repeat suite: `54 passed`;
  - `py_compile` for new/changed tooling: passed.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- Not claimed: GitHub CI green, full pytest green, frontend build, live FastAPI proof, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `44 / 100`, remaining `56 / 100`.
- Next safe planned cycle: `1446 — CI rerun log reconciliation or next fresh log repair`.

# Active block — v170.19 cycle 1443 Full linkage architecture tests

- Current HEAD: `v170.19 / cycle 1443 Full linkage architecture tests`.
- Base archive: `EFHC_Bot_v170_18_cycle_1442_openapi_rebuild_strict_contract_gate.zip`.
- Scope: close `F-007` and `F-008` locally by adding full static architecture linkage tests and critical UI loading/error/empty-state guards.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- Added scanner: `ops/linkage/build_full_linkage_report.py`.
- Added report: `reports/generated/full_linkage_report_v170_19.json`.
- Added guard: `tests/architecture/test_full_linkage_architecture_and_ui_states.py`.
- Local report status: `ok`.
- Guarded critical UI surfaces: admin bank, admin reports, admin deposits, admin hub, admin users, admin shop, withdraw, tasks, referrals, exchange.
- Range progress: 43 of 100 cycles done; 57 cycles remain.
- Remaining release blocker: repeat audit, HEALER reconciliation and CI/log proof.
- Next safe step: cycle `1444` Linkage repeat audit + HEALER tail reconciliation.

See also:
- `docs/cycles/WORK_CYCLES_1443_FULL_LINKAGE_ARCHITECTURE_TESTS.md`;
- `reports/change_cycle_2026-06-05_v170_19_cycle_1443_full_linkage_architecture_tests.md`.

# Active block — v170.17 cycle 1441 Admin wallet reset semantic repair

- Current HEAD: `v170.17 / cycle 1441 Admin wallet reset semantic repair`.
- Base archive: `EFHC_Bot_v170_16_cycle_1440_admin_hub_route_prefix_repair.zip`.
- Scope: close `F-005` from the active migrations/routes/backend-frontend linkage audit.
- Runtime changed: admin wallet reset now clears legacy `users.ton_wallet` and deactivates canonical `efhc_core.wallet_bindings` in one admin transaction boundary.
- Canonical wallet state remains `efhc_core.wallet_bindings`; active connected wallet means active + verified binding.
- New service helper: `wallets_service.admin_reset_wallet_bindings()`.
- Admin audit log records `wallet_bindings_deactivated=...`.
- Frontend admin reset action is no longer blocked solely by stale legacy `selected.ton_wallet`.
- New guard: `tests/architecture/test_admin_wallet_reset_semantic_repair.py`.
- Local validation: new guard passed; related linkage/kernel guard pack passed; targeted `py_compile` passed.
- Range progress: 41 of 100 cycles done; 59 cycles remain.
- Remaining release blocker: `P0_RELEASE_BLOCKED` until `F-006+` are repaired and re-audited.
- Next safe step: cycle `1442` OpenAPI rebuild and strict contract gate.

See also:
- `docs/cycles/WORK_CYCLES_1441_ADMIN_WALLET_RESET_SEMANTIC_REPAIR.md`;
- `reports/change_cycle_2026-06-05_v170_17_cycle_1441_admin_wallet_reset_semantic_repair.md`.

# Active block — v170.16 cycle 1440 Admin Hub route prefix repair

- Current HEAD: `v170.16 / cycle 1440 Admin Hub route prefix repair`.
- Base archive: `EFHC_Bot_v170_15_cycle_1439_admin_reports_bank_table_repair.zip`.
- Scope: close `F-004` from the active migrations/routes/backend-frontend linkage audit.
- Runtime changed: Admin Hub links manager moved from nested `admin_shop_routes.py` router to dedicated `backend/app/routes/admin_hub_routes.py`.
- Canonical Admin Hub backend path: `/admin/hub/*`.
- Removed drift: Admin Hub is no longer nested under `/admin/shop/*`; accidental `/admin/shop/admin/hub/*` route shape is guarded against.
- Frontend AdminHubPage already calls `/admin/hub/links*`; runtime now matches this path.
- Existing OpenAPI canonical `/admin/hub/links*` paths now match runtime registration.
- New guard: `tests/architecture/test_admin_hub_route_prefix_repair.py`.
- Local validation: new guard passed; targeted `py_compile` passed.
- Range progress: 40 of 100 cycles done; 60 cycles remain.
- Remaining release blocker: `P0_RELEASE_BLOCKED` until `F-005+` are repaired and re-audited.
- Next safe step: cycle `1441` Admin wallet reset semantic repair.

See also:
- `docs/cycles/WORK_CYCLES_1440_ADMIN_HUB_ROUTE_PREFIX_REPAIR.md`;
- `reports/change_cycle_2026-06-05_v170_16_cycle_1440_admin_hub_route_prefix_repair.md`.

# Active block — v170.15 cycle 1439 Admin reports bank table repair

- Current HEAD: `v170.15 / cycle 1439 Admin reports bank table repair`.
- Base archive: `EFHC_Bot_v170_14_cycle_1438_p0_deposit_watcher_wallet_ssot_repair.zip`.
- Scope: close `F-003` from the active migrations/routes/backend-frontend linkage audit.
- Runtime changed: `GET /admin/reports/overview` now reads bank totals from canonical `efhc_core.bank_balance` with `key='EFHC_MAIN'`.
- Removed drift: the reports overview route no longer reads legacy `efhc_admin.bank_balances`, `balance_key='main'` or `efhc_balance`.
- Genesis bank seed remains allowed only in `backend/migrations/versions/0001_initial_release_schema.py`: `5000000.00000000 EFHC` into `efhc_core.bank_balance`.
- Future migrations are guarded from silently minting or rewriting bank balance; runtime mint/burn must use `AdminBankService` + `transactions_service`.
- New guard: `tests/architecture/test_admin_reports_bank_ssot_repair.py`.
- Local validation: new guard passed; targeted `py_compile` passed.
- Range progress: 39 of 100 cycles done; 61 cycles remain.
- Remaining release blocker: `P0_RELEASE_BLOCKED` until `F-004+` are repaired and re-audited.
- Next safe step: cycle `1440` Admin Hub route prefix repair.

See also:
- `docs/cycles/WORK_CYCLES_1439_ADMIN_REPORTS_BANK_TABLE_REPAIR.md`;
- `reports/change_cycle_2026-06-05_v170_15_cycle_1439_admin_reports_bank_table_repair.md`.

# Active block — v170.14 cycle 1438 P0 Deposit watcher wallet SSOT repair

- Current HEAD: `v170.14 / cycle 1438 P0 Deposit watcher wallet SSOT repair`.
- Base archive: `EFHC_Bot_v170_13_cycle_1437_p0_bank_ssot_repair.zip`.
- Scope: close `F-002` from the active migrations/routes/backend-frontend linkage audit.
- Runtime changed: watcher wallet lookup moved from legacy `user_wallets` to canonical `wallet_bindings`.
- Scheduler watcher and admin replay now share the same canonical wallet lookup through `process_incoming_tx()`.
- New guard: `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`.
- Local validation: `7 passed` for the new guard; targeted `py_compile` passed.
- Range progress: 38 of 100 cycles done; 62 cycles remain.
- Remaining release blocker: `P0_RELEASE_BLOCKED` until `F-003+` are repaired and re-audited.
- Next safe step: cycle `1439` Admin reports bank table repair.
- Bank start balance note: `5000000.00000000 EFHC` is seeded in `0001_init.py` into `efhc_core.bank_balance`; runtime fallback lives in `AdminBankService.BANK_INITIAL_TOTAL`.

See also:
- `docs/cycles/WORK_CYCLES_1438_P0_DEPOSIT_WATCHER_WALLET_SSOT_REPAIR.md`;
- `reports/change_cycle_2026-06-05_v170_14_cycle_1438_p0_deposit_watcher_wallet_ssot_repair.md`.

# Active block — v170.13 cycle 1437 P0 Bank SSOT repair

- Current HEAD: `v170.13 / cycle 1437 P0 Bank SSOT repair`.
- Base archive: `EFHC_Bot_v170_12_cycle_1436_user_decisions_doc_update.zip`.
- Scope: close `F-001` from the active migrations/routes/backend-frontend linkage audit.
- Runtime changed: admin bank mint/burn now use `transactions_service` helpers and existing official/canonical tables only.
- Canonical bank balance: `efhc_core.bank_balance`.
- Canonical idempotency/audit ledger for admin bank supply changes: `efhc_core.efhc_transfers_log`.
- No separate `efhc_mint_burn` ledger/table was created.
- No migration, CI/workflow, lock-file, frontend economic logic or EFHC economy change was made.
- Guards added: `tests/architecture/test_admin_bank_ssot_repair.py`.
- Local validation: 7 new guard tests passed; 35 related architecture/financial/kernel/filename tests passed; targeted `py_compile` passed.
- Active range: `1401-1500` — OPEN.
- Range progress: 37 of 100 cycles done; 63 cycles remain.
- Remaining release blocker: `P0_RELEASE_BLOCKED` until `F-002+` are repaired and repeat-audited.
- Next safe step: cycle `1438` P0 Deposit watcher wallet SSOT repair.
- Non-claims: no GitHub CI green, no full pytest green, no frontend build green, no release-ready, no screenshots, no live Telegram or real TonConnect proof.

See also:
- `docs/cycles/WORK_CYCLES_1437_P0_BANK_SSOT_REPAIR.md`;
- `reports/change_cycle_2026-06-05_v170_13_cycle_1437_p0_bank_ssot_repair.md`.

# Active block — v170.12 cycle 1436 user decisions doc update

- Current HEAD: `v170.12 / cycle 1436 user decisions doc update`.
- Base archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`.
- Mode: docs-only user decisions lock. Runtime, tests, migrations, frontend/backend logic, CI/workflows and lock files were not changed.
- User decisions locked:
  - `1437`: admin bank mint/burn must use existing official/canonical tables only; no separate `efhc_mint_burn` ledger/table.
  - `1441`: admin wallet reset fully unbinds canonical `wallet_bindings`.
  - `1440`: Admin Hub canonical path is `/admin/hub/*`.
- Iteration question format locked in `docs/NORM/ITERATION_QUESTIONS_FORMAT_STANDARD.md`.
- Active range: `1401-1500` — OPEN.
- Range progress remains 36 of 100 cycles done; this is a supplemental doc update to cycle 1436, not a runtime repair cycle.
- Next safe step: cycle `1437` P0 Bank SSOT repair using existing official/canonical tables.

# Active block — v170.11 cycle 1436 migrations/routes/backend-frontend linkage freeze

- Current HEAD: `v170.11 / cycle 1436 migrations routes linkage freeze`.
- Base archive: `EFHC_Bot_v170_10_cycle_1435_cold_start_ux_asset_optimization.zip`.
- User task: register P0 migrations/routes/backend-frontend linkage audit and
  prepare the next repair cycles.
- Audit registered: `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.
- Machine index: `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`.
- Verdict: `P0_RELEASE_BLOCKED`.
- Runtime/business/economy/security/money-flow changes: none.
- Tests deleted/archived/skipped/xfailed: 0.
- Active range: `1401-1500` — OPEN.
- Range progress: 36 of 100 cycles done; 64 cycles remain.
- Next safe step: cycle `1437` P0 Bank SSOT repair after answering Q1 about
  whether `efhc_mint_burn` is a required ledger or must be removed from runtime
  usage.

# Active block — v170.10 / cycle 1435 cold start UX asset optimization

- Current HEAD: `v170.10 / cycle 1435 cold start UX asset optimization`.
- Base archive: `EFHC_Bot_v170_09_cycle_1434_security_minor_repair.zip`.
- User task: record that Cloud Run / Neon cold start is not an EFHC Bot
  MVP blocker when cached shell and stale-while-revalidate UX are active,
  and compress the bot image.
- Canon fixed: first screen must not wait for DB; Alembic migrations must
  not run on user request; heavy assets must not block the interface;
  backend must not be the only initial visual state.
- Allowed: Cloud Run `min instances = 0`, Neon Free / scale-to-zero,
  Cloud Scheduler health ping when needed and stale-while-revalidate.
- Asset optimized: `frontend/public/skins/1.webp` is now the first-paint
  Energy skin image; it is 197,804 bytes versus 1,146,051 bytes for the
  compatibility PNG.
- Runtime/business/economy/security/money-flow changes: none.
- Tests deleted/archived/skipped/xfailed: 0.
- Active range: `1401-1500` — OPEN.
- Range progress: 35 of 100 cycles done; 65 cycles remain.
- Next safe step: fresh CI log, focused release audit, frontend build,
  browser capture or new user task.
- Non-claims: no GitHub CI green, no full pytest green, no frontend build
  green, no screenshots, no live Telegram or real TonConnect proof.

See also:
- `docs/NORM/COLD_START_MVP_UX_CANON.md`;
- `docs/cycles/WORK_CYCLES_1435_COLD_START_UX_ASSET_OPTIMIZATION.md`;
- `reports/change_cycle_2026-06-05_v170_10_cycle_1435_cold_start_ux_asset_optimization.md`.

# Active block — v170.09 / cycle 1434 security minor repair

- Current HEAD: `v170.09 / cycle 1434 security minor repair`.
- Base archive: `EFHC_Bot_v170_08_cycle_1433_operator_kernel_first_standard_hardening.zip`.
- Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_08.md`.
- Scope: close remaining v170.08 security minor findings.
- Runtime/config changed: `ADS_TEST_MODE` prod/stage fail-fast, monetary
  middleware default prefixes include `/deposit` and `/payment-intents`, and
  `env.prod.example` uses placeholders for TON operational addresses.
- Guards added/updated: `test_security_audit_v170_08_minor_repair.py` and
  `test_monetary_rate_limit_enabled.py`.
- Tests deleted/archived/skipped/xfailed: 0.
- Sandbox use: reference/navigation only; no sandbox runtime code, wallet/payment
  logic, CI files, lock files, configs, secrets, economics or translations were
  imported.
- Active range: `1401-1500` — OPEN.
- Range progress: 34 of 100 cycles done; 66 cycles remain.
- Next safe step: fresh CI log, focused release audit, or new user task.
- Non-claims: no GitHub CI green, no full pytest green, no frontend build green,
  no release-ready, no screenshots, no live Telegram or real TonConnect proof.

See also:
- `docs/cycles/WORK_CYCLES_1434_SECURITY_MINOR_REPAIR.md`;
- `docs/security/P0_SECURITY_REPAIR_CANON.md`;
- `reports/change_cycle_2026-06-05_v170_09_cycle_1434_security_minor_repair.md`.

# Active block — v170.06 / cycle 1431 security regression hardening

- Current HEAD: `v170.06 / cycle 1431 security regression hardening`.
- Base archive: `EFHC_Bot_v170_05_cycle_1430_security_p2_replay_opsec_repair.zip`.
- Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_01.md`.
- Scope: regression hardening and repeat-audit preparation after cycles 1429-1430.
- Runtime changed: Telegram webhook now verifies provider secret before dedupe registration.
- Guards added: admin backend auth coverage, owner-scoped money route checks, prod docs/CORS safety and webhook secret-before-dedupe order.
- Tests deleted/archived/skipped/xfailed: 0.
- Sandbox use: reference/navigation only; no runtime code, wallet/payment logic, CI files, lock files, configs, secrets, economics or translations imported.
- Active range: `1401-1500` — OPEN.
- Range progress: 31 of 100 cycles done; 69 cycles remain.
- Next safe step: repeat security audit, fresh CI log or direct user task.
- Non-claims: no GitHub CI green, no full pytest green, no frontend build green, no release-ready, no screenshots, no live Telegram or real TonConnect proof.

See also:
- `docs/cycles/WORK_CYCLES_1431_SECURITY_REGRESSION_HARDENING.md`;
- `docs/security/P0_SECURITY_REPAIR_CANON.md`;
- `reports/change_cycle_2026-06-04_v170_06_cycle_1431_security_regression_hardening.md`.

## 1421 — CI log repair after FSM split / v169.96 — DONE

- HEAD input: `EFHC_Bot_v169_95_cycles_1417_1420_fsm_states_split_range_closure.zip`.
- Log input: `logs_72253479436.zip`; logs were read first.
- Log facts: flake8, ruff, mypy, bandit, compileall, Alembic and frontend build were green; pytest failed with `3 failed, 1173 passed, 8 skipped, 1 warning`.
- Fixed exact root causes from logs:
  - raw `asyncio.create_task()` in `backend/app/bot/fsm/manager.py` replaced by `create_logged_task()`;
  - numbered work-pass labels removed from non-exception docs/source comments;
  - stale HEAL-0055 Atlas confirmation basis updated after completed DB-backed long-retention repair.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build rerun, screenshots, live Telegram proof, real wallet proof or release-ready.
- Next action: fresh CI/log confirmation or a new audit/task.

# Active block — v169_93 / cycles 1413-1414

- Current HEAD: `v169_93 / cycles 1413-1414 HEAL-0055 deposit retention policy + P0 cross-guard consolidation`.
- Base archive: `EFHC_Bot_v169_92_cycle_1412_heal0055_deposit_cache_kernel_start_core.zip`.
- User task: continue cycles 1413-1414, read documents, use sandbox/map navigation, update documents, and report remaining cycles.
- Cycle 1413 runtime repair: deposit idempotency retention is explicitly non-expiring via `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"` and `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`.
- Cycle 1413 safety repair: same deposit idempotency key replayed with different watcher payload raises `idempotency_fingerprint_mismatch`.
- Cycle 1414 guard repair: added additive P0 cross-guard over HEAL-0045/0040/0044/0023/0018/0024/0055 invariants without deleting, archiving, skipping or xfail-ing any existing test.
- Sandbox/map: used only as reference/navigation layer. No sandbox runtime, CI, lock files, wallet/payment logic or translations were imported.
- Remaining active plan cycles after 1414: 6 (`1415-1420`). General 1401-1500 remaining: 86 cycles.

# Active block — v169_91 / cycles 1410-1411

- Current HEAD: `v169_91 / cycles 1410-1411 HEAL-0024 withdraw atomicity repair + Operator Kernel refresh/version check`.
- Base archive: `EFHC_Bot_v169_90_cycles_1409_1410_heal0018_transaction_boundary_repair.zip`.
- User task: continue cycles 1410-1411, read documents, use sandbox/map navigation, update documents, report remaining cycles, and evaluate Operator Kernel optimization.
- Cycle 1410 status: confirmed/read as prior HEAL-0018 transaction-boundary repair from v169.90.
- Cycle 1411 runtime repair: `request_withdraw()` now commits withdraw request row, balance hold, transfer-log audit meta and `hold_done=TRUE` in one service-owned transaction boundary.
- Cycle 1411 transaction helper: `transactions_service.debit_user_to_bank_nocommit()` added for higher-level atomic state machines; caller owns commit/rollback.
- Legacy autofix path: `ensure_consistency()` hold catch-up now uses the same no-commit hold helper inside one `_tx_context`.
- Operator Kernel optimization: `ops/operator_kernel/refresh.sh` added; `routes.yaml` now has `version: 1`; `config_loader` validates route config version at load time.
- New files: only `ops/operator_kernel/refresh.sh`, because it was explicitly requested. Guards were updated in existing test files.
- Sandbox/map: used only as reference/navigation layer. No sandbox runtime, CI, lock files, wallet/payment logic or translations were imported.
- Remaining active plan cycles after 1411: 9 (`1412-1420`). General 1401-1500 remaining: 89 cycles.

# Active block — v169_89 / cycles 1408-1409

- Current HEAD: `v169_89 / cycles 1408-1409 HEAL-0023 idempotency hardening + HEAL-0018 transaction-boundary map`.
- Base archive: `EFHC_Bot_v169_88_cycles_1406_1407_heal0040_payment_contract_heal0044_schema_proof.zip`.
- User task: continue cycles 1408-1409, read documents, use sandbox/map navigation, update documents, optimize report, show remaining cycles.
- Mode: targeted P0 runtime hardening for `HEAL-0023` + audit/map for `HEAL-0018`.
- Cycle 1408 root cause: explicit `IDEMPOTENCY_CONFLICT:<key>` marker existed but the shared detector only recognized generic unique/idempotency DB messages.
- Cycle 1408 repair: `_is_idempotency_conflict()` now directly recognizes explicit `idempotency_conflict:` markers and all local `IDEMPOTENCY_CONFLICT` branches use the shared helper.
- Cycle 1409 scope: transaction-boundary mapping only. No runtime transaction-boundary rewrite was performed in 1409.
- Cycle 1409 result: `docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_MAP.md` defines service-owned / route-owned / savepoint-only / mixed classifications before cycle 1410 repair.
- New guard: `tests/architecture/test_heal0023_0018_idempotency_transaction_boundary.py`.
- Tests deleted/archived/skipped/xfailed: 0.
- Active plan cycles remaining after 1409: 11 (`1410-1420`).
- 1401-1500 range remaining after 1409: 91 cycles.
- Sandbox: Песочница used only as reference/navigation layer via `map_element.md`; no runtime code, CI, lock files, wallet/payment logic or translations imported.

# Active block — v169_88 / cycles 1406-1407

- Current HEAD: `v169_88 / cycles 1406-1407 HEAL-0040 payment contract + HEAL-0044 schema proof`.
- Base archive: `EFHC_Bot_v169_87_cycle_1405_heal0045_global_id_identity_repair.zip`.
- User task: continue cycles 1406-1407, read documents, use sandbox/map navigation, update documents.
- Mode: targeted P0 runtime/schema repair + docs/guard update.
- Cycle 1406 root cause: `PaymentIntent.package_id` was `nullable=False` while custom/package-less intent SQL inserted `NULL`.
- Cycle 1406 repair: ORM package_id is nullable; package-based path still uses `:pid`; custom and package-less paths use `NULL`; no fake `0` package sentinel remains.
- Cycle 1407 root cause: existing DBs could still have `efhc_transfers_log.direction varchar(8)` even though the ORM model uses `String(24)`.
- Cycle 1407 repair: Alembic 0001 now widens existing direction columns below 24 and fails sanity if package_id is not nullable or direction is shorter than varchar(24).
- New guard: `tests/architecture/test_heal0040_0044_payment_schema_contract.py`.
- Tests deleted/archived/skipped/xfailed: 0.
- Sandbox: Песочница used only as reference/navigation layer via `map_element.md`; no runtime, CI, lock file, wallet/payment logic or translation imported.
- Active range: `1401-1500` — OPEN.
- Range progress: 7 of 100 cycles done; 93 cycles remain.
- Next planned cycle: `1408 — HEAL-0023 idempotency read-through conflict hardening`, unless fresh logs are supplied first.
- Non-claims: no GitHub CI green, no full local pytest green, no frontend build green, no release-ready, no screenshots, no live Telegram or real TonConnect proof.


# Active block — v169_87 / cycle 1405

- Current HEAD: `v169_87 / cycle 1405 HEAL-0045 global_id identity canon repair`.
- Base archive: `EFHC_Bot_v169_86_cycle_1404_p0_heal_alignment_deposit_cache_plan.zip`.
- User task: continue cycles, read documents, use sandbox/map navigation, update documents, and perform cycle 1405.
- Mode: targeted P0 runtime repair + docs/guard update.
- Root cause: `backend/app/crud/referrals_crud.py::admin_top_inviters()` joined Telegram ID fields (`ReferralLink.inviter_tg_id`, `active_subq.c.tg_id`, `bonus_subq.c.tg_id`) to internal `User.id`.
- Repair: all joins now use `User.global_id`; admin aggregate identity is `User.global_id.label("inviter_global_id")`.
- New guard: `tests/architecture/test_heal0045_global_id_identity_canon.py`.
- Tests deleted/archived/skipped/xfailed: 0.
- Sandbox: Песочница used only as reference/navigation layer via `map_element.md`; no runtime, CI, lock file, wallet/payment logic or translation imported.
- Active range: `1401-1500` — OPEN.
- Range progress: 5 of 100 cycles done; 95 cycles remain.
- Next planned cycle: `1406 — HEAL-0040 payment_intents contract repair`, unless fresh logs are supplied first.
- Non-claims: no GitHub CI green, no full local pytest green, no frontend build green, no release-ready, no screenshots, no live Telegram or real TonConnect proof.


# Active block — v169_86 / cycle 1404

- Current HEAD: `v169_86 / cycle 1404 P0 HEAL alignment and deposit-cache plan`.
- Base archive: `EFHC_Bot_v169_85_cycle_1403_p0_backend_and_fsm_repair_plan.zip`.
- User task: add deposit-cache cycles, record answers to cycle-1403 iteration questions, check Q&A/Atlas for stale regression, and update plans.
- Mode: planning/docs/guard only; no runtime backend repair in this cycle.
- User decisions recorded: `HEAL-0040` nullable package_id for custom intents; transaction-boundary repair allowed for `HEAL-0024`/`HEAL-0018`; FSM split uses compatibility facade.
- New risk lane: `HEAL-0055` deposit-cache/idempotency proof and long-retention records through `efhc_admin.idempotency_key`.
- Current code check: no active runtime `_ttl_seen` found in `backend/app/core/system_locks.py`; DB-backed `_acquire_idempotency_ttl_lock()` uses `IdempotencyKey`.
- Atlas/Q&A verdict: Atlas contains HEAL cards, but Q&A lacked cycle-1404 decisions; Q&A updated.
- Added active plan: `docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`.
- Previous plan `WORK_CYCLES_1403-1417...` is superseded, not deleted.
- Active range: `1401-1500` — OPEN.
- Range progress: 4 of 100 cycles done; 96 cycles remain.
- Next planned cycle: `1405 — HEAL-0045 global_id identity canon repair`, unless fresh logs are supplied first.
- Non-claims: no GitHub CI green, no full local pytest green, no frontend build green, no release-ready, no screenshots, no live Telegram or real TonConnect proof.


# Active block — v169_85 / cycle 1403

- Current HEAD: `v169_85 / cycle 1403 P0 backend and FSM repair plan`.
- Base archive: `EFHC_Bot_v169_84_cycle_1402_i18n_hardcoded_strings_repair.zip`.
- User task: check P0 / Red Zone issues HEAL-0023, HEAL-0024, HEAL-0018,
  HEAL-0045, HEAL-0040, HEAL-0044 and the `states.py` SRP warning.
- Mode: audit/TZ/plan only; no runtime code repair in this cycle.
- Confirmed active P0 defects: HEAL-0045 global_id/User.id drift and
  HEAL-0040 payment_intents package_id contract drift.
- Confirmed residual P0 risks: HEAL-0023 idempotency detector,
  HEAL-0024 withdraw atomicity, HEAL-0018 transaction-boundary drift,
  HEAL-0044 schema/migration proof.
- `states.py` check: confirmed SRP violation, 50816 bytes / 1092 lines;
  split TZ created for `fsm/dto.py`, `fsm/backend.py`, `fsm/manager.py`,
  `fsm/decorators.py` with compatibility facade.
- Added plan: `docs/cycles/WORK_CYCLES_1403-1417_P0_BACKEND_AND_FSM_REPAIR_PLAN.md`.
- Test suite changed: no tests added/deleted/archived/skipped/xfailed in this
  planning cycle.
- Runtime code changed: no.
- Active range: `1401-1500` — OPEN and expanded from post-i18n stabilization
  to P0 backend stabilization by direct user command.
- Range progress: 3 of 100 cycles done; 97 cycles remain.
- Next planned cycle: `1404 — HEAL-0045 global_id identity canon repair`, unless
  fresh logs are supplied first.
- Non-claims: no GitHub CI green, no full local pytest green, no frontend
  build green, no release-ready, no screenshots, no live Telegram or real
  TonConnect proof.

# Active block — v169_83 / cycle 1401

- Current HEAD: `v169_83 / cycle 1401 i18n reaudit low-signal repair`.
- Base archive: `EFHC_Bot_v169_82_cycle_1400_range_closure_ci_ruff_repair.zip`.
- New audit input: `I18N_REAUDIT_REPORT_v169_82_2026_06_03.md`.
- Audit fact: all four original i18n TЗ tasks were reported fixed.
- Audit fact: genuinely untranslated public keys are reported as 0.
- LOW signals repaired: `FAQ` allowlist, panels-service comment false positive,
  and wave-3 quality scripts not reading shared allowlist.
- Runtime code changed: no player/runtime behavior change; only audit/guard
  scripts and documentation.
- Test suite changed: one new active architecture guard added.
- Tests deleted/archived/skipped/xfailed: 0.
- Active range: `1401-1500` — OPEN by new audit.
- Range progress: 1 of 100 cycles done; 99 cycles remain.
- Next planned cycle: `1402`, only after a new audit/log/task or direct user
  command.
- Non-claims: no GitHub CI green for v169_83, no full local pytest green, no
  frontend build green, no release-ready, no screenshots, no live Telegram or
  real TonConnect proof.

See also:
- `docs/frontend/I18N_REAUDIT_LOW_SIGNAL_REPAIR.md`;
- `docs/audits/I18N_REAUDIT_LOW_SIGNAL_REPAIR_AUDIT_V169_83.md`;
- `reports/generated/i18n_reaudit_low_signal_repair_v169_83.json`;
- `reports/change_cycle_2026-06-03_v169_83_cycle_1401_i18n_reaudit_low_signal_repair.md`.

# Active block — v169_82 / cycle 1400

- Current HEAD: `v169_82 / cycle 1400 range closure and CI ruff repair`.
- Base archive: `EFHC_Bot_v169_81_cycle_1399_mapped_test_consolidation.zip`.
- Fresh CI log input: `logs_72210640420.zip`.
- CI fact: pytest passed with `1130 passed`, `8 skipped`, `1 warning`.
- CI fact: frontend `npm ci` and `next build` passed.
- CI fact: DB/Alembic gates passed.
- CI blocker: `ruff` found one import-order issue in the compatibility
  shim `ops/i18n/audit_forbidden_gaming_contour.py`.
- Repair: removed the extra blank line in that import block only.
- Runtime code changed: no.
- Test suite changed: no.
- Active range: `1390-1400` — CLOSED.
- Range progress: 11 of 11 cycles done; 0 cycles remain.
- Next work: wait for the new audit before opening a new active range.
- Non-claims: no GitHub CI green for v169_82 until CI reruns, no
  release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/audits/CI_LOG_RANGE_CLOSURE_AUDIT_V169_82.md`;
- `reports/generated/range_closure_v169_82.json`;
- `reports/change_cycle_2026-06-03_v169_82_cycle_1400_range_closure.md`.

# Active block — v169_81 / cycle 1399

- Current HEAD: `v169_81 / cycle 1399 mapped test consolidation`.
- Base archive: `EFHC_Bot_v169_80_cycle_1398_test_consolidation_audit_only_map.zip`.
- User decision: consolidate all four groups prepared in cycle 1398.
- Old active test files converted to support modules: 32.
- New active consolidated test files: 4.
- Original test functions preserved as active pytest cases: 154.
- Deleted without mapping: 0.
- Archived as `test_*.py`: 0.
- Active range: `1390-1400` — OPEN.
- Range progress: 10 of 11 cycles done; 1 cycle remains.
- Next planned cycle: `1400 — range closure and fresh CI handoff`.
- Non-claims: no new GitHub CI green, no full local pytest green, no
  release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/testing/TEST_CONSOLIDATION_MAPPING.md`;
- `docs/audits/MAPPED_TEST_CONSOLIDATION_AUDIT_V169_81.md`;
- `reports/generated/mapped_test_consolidation_v169_81.json`.

# Active block — v169_80 / cycle 1398

- Current HEAD: `v169_80 / cycle 1398 test consolidation audit-only map`.
- Base archive: `EFHC_Bot_v169_79_cycle_1397_ci_log_canon_guard_repair.zip`.
- Last completed pass: audit-only mapping for possible future test
  consolidation.
- User decision: prepare only the safety map; do not change tests.
- Tests changed: 0. Tests deleted: 0. Tests archived: 0.
- Candidate groups mapped: 4.
- Candidate test files mapped: 32.
- Candidate test functions mapped: 154.
- Sandbox input: available as reference-only; not needed for this
  audit-only mapping pass.
- Active range: `1390-1400` — OPEN.
- Range progress: 9 of 11 cycles done; 2 cycles remain.
- Next planned cycle: `1399 — optional actual consolidation only after
  direct user approval`, otherwise no-merge control pass.
- Non-claims: no new GitHub CI green, no full local pytest green, no
  release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/testing/TEST_CONSOLIDATION_AUDIT_ONLY_MAP.md`;
- `docs/audits/TEST_CONSOLIDATION_AUDIT_ONLY_MAPPING_AUDIT_V169_80.md`;
- `reports/generated/test_consolidation_audit_only_map_v169_80.json`.

# Active block — v169_79 / cycle 1397

- Current HEAD: `v169_79 / cycle 1397 CI log canon guard repair`.
- Base archive: `EFHC_Bot_v169_78_cycle_1396_ranks_hub_browser_shop_wording_guard.zip`.
- Fresh failing log input: `logs_72195040558.zip`.
- DB/Alembic result from logs: green; no DB repair was needed.
- Failing lanes from logs: ruff import order and pytest canon guard.
- Repair: renamed the active forbidden-contour guard to a neutral path and
  removed the banned English legacy token from active docs, tests and ops
  references.
- Sandbox input: available as reference-only; not needed for this log repair.
- Active range: `1390-1400` — OPEN.
- Range progress: 8 of 11 cycles done; 3 cycles remain.
- Next planned cycle: `1398 — audit-only consolidation mapping`.
- Non-claims: no new GitHub CI green, no full local pytest green, no
  release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/audits/CI_LOG_CANON_GUARD_REPAIR_AUDIT_V169_79.md`;
- `reports/generated/ci_log_canon_guard_repair_v169_79.json`;
- `ops/i18n/audit_forbidden_gambling_chance_contour.py`;
- `tests/architecture/test_game_word_boundary_and_wording.py`.

# Active block — v169_78 / cycle 1396

- Current HEAD: `v169_78 / cycle 1396 ranks, hub and browser-shop wording guard`.
- Base archive: `EFHC_Bot_v169_77_cycle_1395_admin_visible_functions_chat25.zip`.
- Last completed pass: Ranks/Hub/Browser-Shop wording matrix and game-vs-gambling correction.
- Fresh failing log input: none supplied for this cycle.
- User correction: the word `game` is allowed; the active ban is gambling, loto, betting and random financial meaning.
- Sandbox input: available as reference-only; no runtime, CI, lock, wallet/payment logic or translation source was imported.
- Active range: `1390-1400` — OPEN.
- Range progress: 7 of 11 cycles done; 4 cycles remain.
- Next planned cycle: `1397 — Alembic/Postgres smoke only if fresh CI reports DB blockers`, otherwise continue to 1398 audit-only consolidation prep.
- Non-claims: no new GitHub CI green, no full local pytest green, no release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/frontend/RANKS_HUB_BROWSER_SHOP_WORDING_GUARD_MATRIX.md`;
- `reports/generated/ranks_hub_browser_shop_wording_guard_v169_78.json`;
- `tests/architecture/test_game_word_boundary_and_wording.py`;
- `docs/SSOT/GAME_VS_GAMBLING_BOUNDARY_SSOT.md`.

# Active block — v169_77 / cycle 1395

- Current HEAD: `v169_77 / cycle 1395 admin visible functions guard matrix and chat 25 intake`.
- Base archive: `EFHC_Bot_v169_76_cycle_1394_public_triad_guard_matrix.zip`.
- Last completed pass: Admin route to visible function to guard matrix, plus `25.md` canonical chat intake.
- Fresh failing log input: none supplied for this cycle.
- User decision: continue strictly by plan 1394-1400; minimal active architecture guard is allowed when weak Admin evidence links are found.
- Sandbox input: `Песочница.xz` and five extra TMA template ZIP files checked as reference-only sources.
- Active range: `1390-1400` — OPEN.
- Next planned cycle: `1396 — rank wording / legacy words / browser-shop / hub wording`, unless a fresh log archive is supplied first.
- Non-claims: no new GitHub CI green, no full local pytest green, no release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/admin/ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX.md`;
- `reports/generated/admin_visible_functions_guard_matrix_v169_77.json`;
- `tests/architecture/test_admin_visible_functions_guard_matrix.py`;
- `docs/NORM/CHATS/25.md`.

# Active block — v169_76 / cycle 1394

- Current HEAD: `v169_76 / cycle 1394 public Energy/Panels/Exchange guard matrix`.
- Base archive: `EFHC_Bot_v169_75_cycle_1393_fresh_ci_log_shell_verification.zip`.
- Last completed pass: public triad route-component-backend-economy guard matrix.
- Fresh failing log input: none supplied for this cycle.
- User decision: continue strictly by plan 1394-1400; dependency-security warning remains separate.
- Active range: `1390-1400` — OPEN.
- Next planned cycle: `1395 — visible functions, admin route evidence and report-index repair`, unless a fresh log archive is supplied first.
- Non-claims: no new GitHub CI green, no full local pytest green, no release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/frontend/PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md`;
- `reports/generated/public_energy_panels_exchange_guard_matrix_v169_76.json`;
- `tests/architecture/test_public_energy_panels_exchange_guard_matrix.py`;
- `docs/cycles/WORK_CYCLES_1390-1400_CI_LOG_REPAIR_AND_TEST_HEALING_PLAN.md`.

# Active block — v169_74 / cycle 1392

- Current HEAD: `v169_74 / cycle 1392 CI log pytest failure repair`.
- Base archive: `EFHC_Bot_v169_71_cycle_1390_law0_line72_test_mapping_repair.zip`.
- Last completed pass: log-driven repair of `logs_72176795654.zip`.
- Fixed violation: `docs/testing/TEST_CONSOLIDATION_MAPPING_1390.md`
  was renamed to `docs/testing/TEST_CONSOLIDATION_MAPPING.md`.
- Policy strengthened: `docs/testing/` is not a cycle-label
  exception layer; cycle traceability belongs inside the document body.
- Filename limits are explicit: 120 UTF-8 bytes per path component,
  220 UTF-8 bytes per archive-relative path.
- Active range: `1390-1400` — OPEN.
- Next planned cycle: `1393 — frontend shell / document / PWA guard
  repair`, unless a fresh log archive is supplied first.
- User answers accepted: continue log/domain healing, prepare mapping for
  cycle-marker docs guards, and keep `routes.yaml` as a line-length
  file-format exception.
- Non-claims: no GitHub CI green, no full pytest green, no
  release-ready, no screenshots, no live Telegram/TonConnect proof.

See also:
- `docs/cycles/WORK_CYCLES_1390-1400_CI_LOG_REPAIR_AND_TEST_HEALING_PLAN.md`;
- `docs/testing/TEST_CONSOLIDATION_MAPPING.md`;
- `docs/NORM/ARCHIVE_FILENAME_HYGIENE_POLICY.md`;
- `docs/audits/FILENAME_HYGIENE_REPAIR_AUDIT_V169_72.md`.

# Active block — v169_69 / cycle 1389

- Current HEAD: `v169_69 / cycle 1389 AI archive laws kernel/canon lock`.
- Base archive: `EFHC_Bot_v169_68_critical_test_control_rollback_repair.zip`.
- Last completed cycle: `1389 — AI archive laws inserted into Kernel, AI and canon`.
- Next planned cycle: domain-by-domain test repair only after reading
  `docs/AI/AI_ARCHIVE_LAWS.md`.
- `v169_67` remains unsafe as a test-control regression incident.
- Non-claims: no GitHub CI green, no full pytest green, no release-ready,
  no screenshots, no live Telegram/TonConnect proof.

See also: `docs/cycles/WORK_CYCLES_1389_AI_ARCHIVE_LAWS_KERNEL_CANON_LOCK.md`.

# Active block — v169_64 / cycles 1376-1385

- Current HEAD: `v169_64 / cycle 1384 i18n browser text stress screenshot-readiness plan`.
- Base archive: `EFHC_Bot_v169_63_cycle_1383_i18n_manual_coverage_consolidation.zip`.
- Last completed cycle: `1384 — i18n browser text stress / screenshot-readiness planning only`.
- Next planned cycle: `1385 — i18n range closure and next visual/browser-evidence handoff`.
- Active range: `1376-1385` — OPEN.
- Completed in this range: 1376 audit intake/manual plan, off-queue i18n process correction, 1377 UK public pass, 1378 wave-3 public_engagement, 1379 portal/shop, 1380 profile/trust, 1381 panels/tasks/history, 1382 hub/energy/wallet/ranks/referrals tail, 1383 consolidation, 1384 browser text stress readiness plan.
- Translation rule: manual only; verified Russian meaning is the source; English and sandbox labels are not semantic sources.
- Browser evidence boundary: no screenshots were captured in 1384; this is a readiness matrix only.
- Non-claims: no GitHub CI green, no browser screenshots, no live Telegram client proof, no wallet transaction proof and no release-ready verdict.

See also: `docs/frontend/I18N_BROWSER_TEXT_STRESS_SCREENSHOT_READINESS_PLAN.md`.

# Active block — v169_62 / cycles 1376-1385

- Current HEAD: `v169_62 / cycle 1382 wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass`.
- Base archive: `EFHC_Bot_v169_61_cycle_1381_wave3_panels_tasks_history_manual_translation_pass.zip`.
- Last completed cycle: `1382 — wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass`.
- Next planned cycle: `1383 — i18n manual coverage consolidation and remaining-tail audit`.
- Active range: `1376-1385` — OPEN.
- Completed in this range: 1376 audit intake/manual plan, off-queue i18n process correction, 1377 UK public pass, 1378 wave-3 `public_engagement.*`, 1379 wave-3 portal/shop, 1380 wave-3 profile/trust, 1381 wave-3 panels/tasks/history, 1382 wave-3 hub/energy/wallet/ranks/referrals tail.
- Translation rule: manual only; verified Russian meaning is the source; English and sandbox labels are not semantic sources.
- Non-claims: no GitHub CI green, no browser screenshots, no live Telegram client proof, no wallet transaction proof and no release-ready verdict.

See also: `docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`.

# Active block — v169_61 / cycles 1376-1385

- Current HEAD: `v169_61 / cycle 1381 wave-3 panels/tasks/history manual translation pass`.
- Base archive: `EFHC_Bot_v169_60_cycle_1380_wave3_profile_trust_manual_translation_pass.zip`.
- Last completed cycle: `1381 — wave-3 panels/tasks/history manual translation pass`.
- Next planned cycle: `1382 — wave-3 hub/energy/wallet/ranks/referrals tail manual translation pass`.
- Active range: `1376-1385` — OPEN.
- Completed in this range: 1376 audit intake/manual plan, off-queue i18n process correction, 1377 UK public pass, 1378 wave-3 `public_engagement.*`, 1379 wave-3 portal/shop, 1380 wave-3 profile/trust, 1381 wave-3 panels/tasks/history.
- Translation rule: manual only; verified Russian meaning is the source; English and sandbox labels are not semantic sources.
- Non-claims: no GitHub CI green, no browser screenshots, no live Telegram client proof, no wallet transaction proof and no release-ready verdict.

See also: `docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`.

# Active block — v169_60 / cycles 1376-1385

- Current HEAD: `v169_60 / cycle 1380 wave-3 profile/public-profile-trust manual translation pass`.
- Base archive: `EFHC_Bot_v169_59_cycle_1379_wave3_portal_shop_manual_translation_pass.zip`.
- Last completed cycle: `1380 — wave-3 profile/public-profile-trust manual translation pass`.
- Next planned cycle: `1381 — wave-3 panels/tasks/history manual translation pass`.
- Active range: `1376-1385` — OPEN.
- Completed in this range: 1376 audit intake/manual plan, off-queue i18n process correction, 1377 UK public pass, 1378 wave-3 `public_engagement.*`, 1379 wave-3 portal/shop, 1380 wave-3 profile/trust.
- Translation rule: manual only; verified Russian meaning is the source; English and sandbox labels are not semantic sources.
- Non-claims: no GitHub CI green, no browser screenshots, no live Telegram client proof, no wallet transaction proof and no release-ready verdict.

See also: `docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`.

# Active block — v169_59 / cycles 1376-1385

- Current HEAD: `v169_59 / cycle 1379 wave-3 portal/shop manual translation pass`.
- Base archive: `EFHC_Bot_v169_58_cycle_1378_wave3_public_engagement_manual_translation_pass.zip`.
- Last completed cycle: `1379 — wave-3 portal/shop manual translation pass`.
- Next planned cycle: `1380 — wave-3 profile/public-profile-trust manual translation pass`.
- Active range: `1376-1385` — OPEN.
- Completed in this range: 1376 audit intake/manual plan, off-queue i18n process correction, 1377 UK public pass, 1378 wave-3 `public_engagement.*`, 1379 wave-3 portal/shop.
- Translation rule: manual only; verified Russian meaning is the source; English and sandbox labels are not semantic sources.
- Non-claims: no GitHub CI green, no browser screenshots, no live Telegram client proof, no wallet transaction proof and no release-ready verdict.

See also: `docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`.

# EFHC Work Cycles Index

## Active block — v169_58 / cycles 1376-1385

- Current HEAD: `v169_58 / cycle 1378 wave-3 public_engagement manual translation pass`.
- Base archive: `EFHC_Bot_v169_57_cycle_1377_uk_public_manual_translation_pass.zip`.
- New audit source: `docs/audits/I18N_REAUDIT_REPORT_V169_54_2026_06_03.md`.
- Last completed cycle: `1378 — wave-3 public_engagement manual translation pass`.
- Next planned cycle: `1379 — wave-3 portal/shop manual translation pass`.
- Active range: `1376-1385` — OPEN.
- Future range file added: `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md` (draft/reserved only, not active).
- Translation rule: manual only; verified Russian meaning is the source; English and sandbox labels are not semantic sources.
- Non-claims: no GitHub CI green, no browser screenshots, no live Telegram client proof, no wallet transaction proof and no release-ready verdict.

See also: `docs/cycles/WORK_CYCLES_1376-1385_I18N_REAUDIT_MANUAL_TRANSLATION_PLAN.md`.


## Closed active block — v169 / cycles 1351-1375

- Current HEAD: `v169_54 / TonConnect Wallet UX range closure`
- Last completed: `1375` TonConnect / Wallet UX proof and range closure
- Last active pass: `1375 — TonConnect / Wallet UX proof and range closure / next-audit handoff`
- Next: `1376+ — blocked until a new audit is supplied in chat`
- Active range: `1351-1375` — CLOSED
- Legacy ranges: historical only
- Current line: `Admin/Public range closed after TMA Shell Polish → TonConnect Wallet UX Proof → Next-Audit Handoff`
- Sync-pass rule: old ranges, including `1176-1230`, must remain archived history
  and must not be presented as the current active phase.

## Cycle label hygiene

Cycle labels remain useful in audit, report and cycle-index layers. Product,
AI, SSOT, NORM, GENERAL, backend, frontend, ops and admin filenames should stay
semantic without numeric work-pass suffixes. If a work-pass number is needed for
history, place the detailed trace in `docs/cycles/`, `docs/audits/` or
`reports/`.

## Current checkpoint result

- 1356: Admin regression proof pass. DONE in v169_35.
- 1357: Admin recovery checkpoint, dunder-integrity repair, cycle/index sync
  and sandbox element map refresh. DONE in v169_36.
- 1358: HIGH audit fixes implementation: admin bottom-nav boundary, base E2E smoke scaffold and Sale Packages mutations. DONE in v169_37.
- 1359: MEDIUM audit fixes implementation: idempotency, public error states, component-level AdminPage guard and PWA offline fallback. DONE in v169_37.
- 1360: LOW audit polish and checkpoint: DepositModal wallet open, TonConnect fallback note and no-prefix router documentation. DONE in v169_37.
- 1361: Public UI screenshot QA preparation. DONE in v169_39 as preparation scope; screenshot capture/browser verdict is not claimed.
- 1362: Public UI regression proof pass. DONE in v169_40 as static route/component/backend/SSOT/guard proof; browser screenshot verdict is not claimed.
- 1363: Next range extension checkpoint. DONE in v169_41.
- 1364: Public browser screenshot evidence harness and capture manifest. DONE in v169_42 as harness/manifest only; screenshot capture/browser verdict is not claimed.
- 1365: Public visual beauty pass for Energy, Panels and Exchange. DONE in v169_43 as static/source visual polish; screenshot capture/browser verdict is not claimed.
- 1366: Public visual beauty pass for Tasks, Referrals and Ranks. DONE in v169_44 as static/source visual polish; screenshot capture/browser verdict is not claimed.
- 1367: Profile / Wallet / History / FAQ visual trust pass. DONE in v169_45 as static/source visual trust polish; screenshot capture/browser verdict is not claimed.
- 1368: HUB / Browser Shop / Withdraw / Ads visual trust pass. DONE in v169_46 as static/source visual trust polish; screenshot capture/browser verdict is not claimed.
- 1369: i18n critical audit repair pass. DONE in v169_47; C1-C4 audit blockers repaired, full untranslated tail remains planned for 1370-1371.

- 1372-1373: Russian source language canon lock and RU regression audit. DONE in v169_52; AI/SSOT/NORM/Kernel now require translations from verified Russian meaning, and current RU locale English-source regressions were repaired.
- 1374: Telegram Mini App shell polish. DONE in v169_53 as source/static viewport/theme/BackButton/safe-area polish; no live Telegram client, screenshot or GitHub CI verdict is claimed.

- 1375: TonConnect / Wallet UX proof and range closure. DONE in v169_54 as static/source proof and next-audit handoff; no live wallet transaction, Telegram client, screenshot, GitHub CI or release-ready verdict is claimed.

## v169_54 range closure rule

The `1351-1375` range is closed. Cycles `1376+` must start only after the user supplies a new audit/task in chat. The next assistant must not invent a continuation from internal momentum.


## v169_47 update — i18n critical repair

Cycle 1369 was remapped by direct user instruction from Telegram Mini App shell
polish to i18n critical audit repair after the v169.45 localization audit.

Fixed in this pass:

- player-facing fallback chain now uses English, not Russian, for missing keys;
- Hindi `{count}` and `{id}` placeholders are restored;
- five empty public keys are filled in all 13 locale files;
- main-shell admin guard fallback text is English;
- `ShopLayout` no longer falls back to hardcoded Russian `Профиль`;
- `audit_bot_texts_parity.py` importlib typo is fixed;
- `TRANSLATION_STATUS.md` now separates structural parity from quality status.

Remaining language lane:

- 1370: public untranslated key remediation;
- 1371: FAQ wave-3 translation/status repair.

By user instruction, the previous 1358-1360 plan items were moved forward:
- old 1358 Public UI screenshot QA preparation -> 1361;
- old 1359 Public UI regression proof pass -> 1362;
- old 1360 Next range extension checkpoint -> 1363.


## v169_38 update — audit fixes recheck and Public UI QA start

This pass rechecked cycles 1358-1360 before moving deeper into Public UI QA.
Two minor tails were found and closed:

- Sale Packages no longer shows a stale `read-only` badge after mutation wiring;
- Admin EFHC deposits `forceFulfill` now uses a frontend `Idempotency-Key`.

Cycle 1361 is started as Public UI screenshot QA preparation. The active
preparation document is `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`.
No browser screenshot completion or GitHub CI green status is claimed by this
local pass.


## v169_39 update — Public UI QA preparation complete and residual audit fixes

Cycle 1361 now includes the residual audit corrections requested after the
v169_37/v169_38 review:

- all 13 public locale files now contain `common.session_expired` and
  `common.load_error`;
- E2E interaction smokes for Exchange, HUB and Withdraw now assert actual POST
  calls instead of only checking non-empty pages;
- public smoke scope now includes `/withdraw`, `/ads`, `/referrals/active` and
  `/referrals/inactive`;
- admin smoke scope now includes `/admin/sale-packages`, `/admin/efhc-deposits`,
  `/admin/hub`, `/admin/referrals`, `/admin/templates` and `/admin/ads`;
- `offline.html` now has a multilingual fallback line.

This closes preparation readiness for 1361. It does not claim that screenshots
were captured or that browser Playwright passed against a live localhost.



## v169_40 update — Public UI regression proof pass

Cycle 1362 connects each public surface to its frontend page, component family,
backend road, SSOT/NORM anchor and guard in:

- `docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md`;
- `docs/audits/PUBLIC_UI_REGRESSION_PROOF_AUDIT_V169_40.md`;
- `reports/generated/public_ui_regression_proof_v169_40.json`.

The proof covers 14 public routes: `/`, `/panels`, `/exchange`, `/tasks`,
`/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks`,
`/web-profile`, `/faq`, `/hub`, `/browser-shop`, `/withdraw` and `/ads`.

This pass does not claim real screenshots, live Playwright execution or GitHub
CI green. Next cycle is 1363 — Next range extension checkpoint.



## v169_43 update — Energy / Panels / Exchange visual polish

Cycle 1365 improved the first public visual lane after screenshot-harness setup:

- Energy interactive overview now has active surface classes and compact visual rail chips;
- Panels activation preview now has ready/locked state classes and visual rail chips;
- Exchange interactive preview now has ready/loading/focus state classes and visual rail chips;
- shared CSS adds stronger focus-visible states, mobile chip constraints and reduced-motion handling.

No backend roads, EFHC economics, admin pages, sandbox runtime or CI workflow were changed.
No browser screenshot verdict is claimed.



## v169_44 update — Tasks / Referrals / Ranks visual polish

Cycle 1366 improved the second public visual lane after screenshot-harness setup:

- the shared engagement preview now has a visual rail for Tasks, Referrals and Ranks;
- Tasks cards now expose ready/locked/ad/claim classes and status/reward chips;
- Referrals invite surface now has copy/share visual rail and touch-target polish;
- Ranks now has filter/me/podium markers and leader-card visual rows;
- shared CSS adds stronger focus-visible states, mobile chip constraints and reduced-motion handling.

No backend roads, EFHC economics, admin pages, sandbox runtime or CI workflow were changed.
No browser screenshot verdict is claimed.

## Historical control block — cycles 432-451

- Номера блока: 432-451
- Выполнено: cycles 432-451 historically closed.
- Осталось: 0 в историческом блоке.
- Последний выполненный цикл: 451/451.
- Следующий цикл: current frontend line continues in 1233-1235.
- `v*` обозначения — это архивные итерации ZIP.
- Cross-range markers: 430/500, 431/500.
- residual technical healing plan 02.

# v168_31 cycles 1217-1218

- 1217: Tasks compact earning module repair.
- 1218: Tasks current-user route repair and human questions rule.
- Result: Tasks uses compact cards and self-routes.
- Release readiness is not claimed.

## v168_27 update — cycle 1210

Historical range: 1176-1230.
Historical status after that pass: cycles 1176-1210 completed for
specific audit findings only.
Historical next cycle at that time: 1211.

Cycle 1210 applied targeted project corrections:

- backend Docker image now copies `docs` into `/app/docs`;
- Docker healthcheck now uses `/api/health`;
- Telegram WebApp SDK is bootstrapped from `document.tsx`;
- shared Modal is now a bottom-sheet without changing call sites;
- GlobalHeader and Layout have game-shell visual structure;
- bottom navigation canon is preserved;
- visible functions triage table was created for approval.

Release readiness is not claimed.

## v168_23 update — cycle 1206

Historical range: 1176-1230.
Historical status after that pass: cycles 1176-1206 completed for
specific audit findings only.
Historical next cycle at that time: 1207.

Cycle 1206 fixed two concrete findings:

- profile language selector is now one current-language dropdown button;
- browser shop `Оплатить` uses `tonconnect_tx` internally
  and calls the
  TonConnect wallet transaction flow.

Release readiness is not claimed.

# WORK CYCLES INDEX

## Historical range — cycles 1176-1230

Historical range: 1176-1230.
Historical status after that pass: cycles 1176-1203 completed
for their specific audit findings.
Historical next cycle at that time: 1204.

## Rule

Cycles are not the goal.  The goal is to repair audit findings.  A cycle
may include several related fixes when they belong to the same defect
class and can be closed safely in one pass.

## Road-audit correction

Cycles 1180-1181 are the compact audit intake and planning scaffold.
Cycles 1182-1200 are the real repair plan for the road audit and the
audit-of-audit findings.

## Visual audit remap after v168_17

The uploaded visual TZ v002 and visual QA 100 v002 create a new active
repair layer for cycles 1195-1230. The old 1195 contract-test item is
not deleted, but it is postponed behind confirmed public UI blockers:
Direct Deposit, HUB, Browser Shop layout and diagnostics leakage.


## v168_18 update

Cycles 1196-1197 were remapped by direct user instruction to the
profile language switcher blocker inside the visual frontend range.

- 1196 repaired runtime selected-language dictionary loading and
  settings hydration safety.
- 1197 replaced the profile language grid with a horizontal language
  bar and added a guard for language switching plus bottom-menu English
  canon.

Direct Deposit public modal and backend wallet-open road were repaired
in cycles 1198-1199. HUB and Browser-Shop visual blockers remain open
for 1200 onward.

## v168_19 update

Cycles 1198-1199 repaired the Direct Deposit road.

- 1198 rewrote public `DepositModal` as a clean direct-deposit modal.
- 1199 added `POST /deposit/direct-open` without `package_id` coupling.
- The profile language fix was rechecked and direct-deposit locale keys
  were added for all active languages.
- New guard: `test_direct_deposit_guard.py`.

Next focus: 1200 bridge verdict and then HUB/Browser-Shop public UI
cleanup.

## v168_20 update

Cycles 1200-1201 continued the visual repair range.

- 1200 recorded the corrected bridge verdict: 1176-1200 is not a full
  release-ready range because Browser-Shop and other visual blockers
  remain open.
- 1201 cleaned the public HUB to the approved two-action screen:
  Top up EFHC and EFHC VIP NFT.
- HUB diagnostic details were moved to `/admin/diagnostics`.
- New guard:
  `test_hub_public_cleanup_guard.py`.

Next focus: Browser-Shop layout separation and public storefront
cleanup.

## v168_21 update

Cycles 1202-1203 repaired the Browser-Shop shell boundary.

- 1202 added a route-based `/browser-shop` exception in `app.tsx`.
- 1203 added dedicated `ShopLayout` with avatar, EFHC balance and
  Profile link.
- The 100 visual Q/A answers were added to the main
  `QUESTIONS_AND_ANSWERS_REGISTER.md`.
- New guard:
  `test_browser_shop_layout_guard.py`.

Next focus: clean public storefront cards and payment diagnostics.

## v168_22 update

Cycles 1204-1205 cleaned the public Browser-Shop storefront.

- 1204 removed public storefront operator blocks, search/filter noise,
  custom amount and selected-item technical detail rows.
- 1205 removed public wallet/memo/copy/payment-chain diagnostics and
  moved Browser-Shop diagnostics to `/admin/diagnostics`.
- New guard:
  `test_browser_shop_public_cleanup_guard.py`.

Next focus: Pay button wallet-open integration and proof that raw
`tonconnect_tx` is never rendered to the user.


## v168_24 update

Cycle 1207 was completed as a focused Browser-Shop payment status and
frontend route diagnosis pass.

- Payment after wallet-open now polls `/shopfront/intent-status`.
- Status UI remains human-readable and does not expose raw intent data.
- Generated status validator keeps `flow_truth`.
- Static page-route inventory found no missing current page routes.
- The long-range Dragon-style visual plan was added for
  cycles 1231-1350.

Next focus: continue compact frontend compression and interaction repair
without removing existing EFHC functions.

## v168_25 cycle 1208 result

Cycle 1208 repaired the FAQ language and layout layer.

Changed scope:

- FAQ quick labels are no longer hardcoded in English;
- FAQ uses the selected runtime language through `ctx.lang`;
- FAQ remounts on language changes with `key={ctx.lang}`;
- FAQ got the compact `efhc-faq-shell` bot-width layout;
- the sticky search/category block got `efhc-faq-sticky`;
- all active locale files received the new FAQ UI keys.

Guard:

- `tests/architecture/test_faq_language_layout_guard.py`.

The six bottom navigation buttons remain canonical and untouched.
Full browser click-proof is not claimed.

## v168_26 cycle 1209 status

Cycle 1209 performed visible function inventory and added the first safe
browser/PWA shell infrastructure.

Fixed scope:

- Dragon reference browser-app mechanism documented;
- EFHC manifest and service worker added;
- visible frontend function inventory generated;
- canonical six bottom buttons preserved;
- detailed 1209-1230 plan corrected after user answers.

Release readiness is not claimed.


## v168_28 — cycles 1211-1212

- Cycle 1211: repaired Energy progress boundary.  Energy keeps the
  progress bar and generation information, but does not expose public
  level names as player-facing text.
- Cycle 1212: repaired Ranks boundary.  Ranks no longer renders the
  internal 12-level Energy ladder and remains a leaderboard page.
- Added game simulator WebApp glossary and chat-first approval canon.

## v168_29 — cycles 1213-1214

- Cycle 1213: fixed the WebApp/PWA target in documents and added
  compact Dragon-style leader cards to Ranks.
- Cycle 1214: audited Panels, Exchange and Tasks visible functions
  without deleting canonical features.
- Exchange public helper strings were localized.
- Public `truth-layer` wording was removed from the exchange locale.
- Approval remains chat-first; archive tables are working notes only.

## v168_30 — cycles 1215-1216

- Cycle 1215: Panels compact visual repair.
  Panels now uses one compact hero, segmented Active / Archive selector,
  compact panel tiles and expandable secondary details.
- Panels list frontend now calls self-user routes:
  `GET /panels/active` and `GET /panels/archive`.
- Legacy path routes remain as hidden compatibility routes and are not
  removed.
- Cycle 1216: Exchange compact visual repair.
  Exchange keeps kWh -> EFHC and withdraw roads, but secondary helper
  blocks are collapsed into compact details.
- Canonical bottom menu remains unchanged:
  Energy, Panels, Exchange, Tasks, Referrals, Ranks.

Next focus: Tasks compact earning module and disabled-state feedback.

## v168_32 cycles 1219-1225

Emergency correction after user browser launch report.  Core frontend
pages must render without Telegram `tg_id`.  Added browser fallback
snapshot, removed loading-only gates from Energy and core pages, added
Tasks browser demo fallback, recorded WebApp/PWA simulator canon and
created visible-elements chat-agreement table.

## v168_84 cycle 1286 result

Cycle 1286 repaired the Exchange boundary.

Changed scope:

- Exchange is now a single kWh -> EFHC conversion surface;
- `/exchange` no longer renders Wallet or Withdraw blocks;
- the page keeps available kWh, Max, 1:1 rate, input and convert action;
- account History remains as a small secondary link;
- backend, database, migrations and withdraw route logic were not changed.

Next focus: Exchange amount/preview polish.


## v168_85 cycle 1287 result

Cycle: 1287 — Exchange amount/preview polish.

Status: completed.

Result:

- Exchange remains only kWh -> EFHC;
- amount input now has a clear label and sanitized decimal input;
- comma input is normalized to dot input;
- fractional precision is limited to 8 decimals;
- Max remains the only quick action;
- preview row shows how much EFHC the user receives;
- invalid and over-available states are human-readable;
- confirmation text no longer says all available kWh are exchanged;
- Telegram Main Button is hidden on Exchange to avoid amount mismatch.

Next cycle: 1288 — Exchange History link light boundary.
## v168_86 cycle 1288 result

Cycle: 1288 — Exchange History link light boundary.

Status: completed.

Result:

- Exchange History access remains available;
- History access is now a light text navigation row, not a heavy card;
- a short account-history hint was added;
- no History table/list/filter surface was added to Exchange;
- no Wallet or Withdraw flow was reintroduced;
- locale keys were added or humanized for all public locales.

Next cycle: 1289 — Exchange route and contract proof.


## v168_87 cycle 1289 result

Cycle: 1289 — Exchange route and contract proof.

Status: completed.

Result:

- Exchange received current-user route proof markers;
- frontend Exchange cannot silently drift back to `global_id` roads;
- generated `/exchange/preview` and `/exchange/convert` seams remain
  the allowed Exchange frontend roads;
- no user-to-user transfer road is allowed on Exchange;
- uploaded `Песочница.xz` is documented as a visual donor, not HEAD.

Next cycle: 1290 — Exchange visual proof.

## v168_88 cycle 1290 result

Cycle: 1290 — AUDIT_TZ_v168_83 repair pass.

Status: completed.

Result:

- fixed hardcoded Russian transaction reason labels in WebProfile;
- fixed unconditional Active badge in WebProfile;
- filled missing locale keys across all 13 public locales;
- removed deprecated `panels.open_wallet` locale key;
- moved withdraw history frontend calls to `/withdraw/list/me`;
- added backend `/withdraw/list/me` alias for current-user access;
- fixed Panels error storage and activation reload flash;
- wrapped Panels list loading in `useCallback` with abort protection;
- moved live countdown clock update out of render calculation;
- added localized countdown short units;
- stabilized TonConnect manifest initialization;
- stabilized language setter passed to layout providers;
- documented legacy panels global_id routes as deprecated;
- added focus-visible and touch target CSS fixes.

Next cycle: 1291 — Tasks earning module boundary.

## v168_89 cycle 1291 result

Cycle: 1291 — Tasks earning module boundary.

Status: completed.

Result:

- Tasks remains the earning module for bonus EFHC actions;
- `/tasks` now has explicit compact list-card proof markers;
- public technical help/idempotency explanation was removed from the page;
- task cards keep title, description, reward, compact status, human help and primary action;
- no public task completion history, backend execution log or debug block was added;
- accessibility labels were added to primary task action buttons.

Next cycle: 1292 — Ads task action.



## v168_90 cycle 1292 result

Cycle: 1292 — Ads task action.

Status: completed.

Result:

- Tasks ad cards keep the primary `watch-ad` action;
- the extra confirmation gate before ad opening was removed;
- `/ads/slot` is called without `global_id`/`user_id` query leakage;
- the ad modal has a direct-open marker;
- user feedback remains available only for failure/blocked cases.

Next cycle: 1293 — hidden task execution log boundary.


## v168_91 cycle 1293 result

Cycle: 1293 — hidden task execution log boundary.

Status: completed.

Result:

- `/tasks` remains a public earning module, not a history/log/debug screen;
- task execution history is hidden from the player-facing Tasks page;
- backend double-claim protection remains internal through task locks, bonus logs, submissions and idempotency paths;
- admin/operator traces remain available through admin task submissions and `/admin/logs/transfers?reason=task_bonus`;
- guard `test_tasks_hidden_execution_log.py` protects the boundary.

Next cycle: 1294 — Tasks proof pass.


## v168_92 cycles 1294-1296 result

Cycles completed in one pass:

- 1294 — Tasks proof pass;
- 1295 — Referrals invite block;
- 1296 — active/inactive referrals.

Status: completed.

Result:

- Tasks received a final public proof marker for the completed Tasks block;
- Tasks remains a clean earning module without public history/log/debug text;
- Referrals invite block now has explicit link/copy/share proof markers;
- Referrals stats uses `/referrals/stats/me` for current-user frontend calls;
- active/inactive referrals use `/referrals/active/me` and `/referrals/inactive/me`;
- frontend no longer builds public referral URLs with `parent_global_id`, `global_id` or `user_id`;
- referral rows show username or neutral user fallback instead of global_id;
- backend keeps legacy `parent_global_id` routes with deprecated warning headers for compatibility.

Next cycle: 1297 — referral progress and levels.


## v168_93 cycles 1297-1302 result

Cycles completed in one pass:

- 1297 — referral progress and levels;
- 1298 — referral bonus wording;
- 1299 — Ranks card layout;
- 1300 — Ranks filters;
- 1301 — show me in Ranks;
- 1302 — Ranks proof pass.

Status: completed.

Result:

- Referrals progress is now visible as a main card, not hidden in a
  collapsed details-only area;
- referral level, progress bar, achievements marker and next-level value
  are protected by guard;
- referral bonus wording is fixed as `+0.1 EFHC` in the rules/progress
  block, without overloading each referral row;
- Ranks uses vertical player cards and username/neutral fallback only;
- Ranks public filters are exactly `kWh` and `Referrals`;
- Ranks frontend uses current-user backend routes instead of `global_id` or
  `exclude_global_id` query strings;
- current-user kWh routes and current-user referrals rank routes were
  added to backend;
- the Show me button focuses the user and a nearby competitor window.

Next cycle: 1303 — Profile status model.


## v168_94 cycles 1303-1310 result

Cycles completed in one pass:

- 1303 — Profile status model;
- 1304 — Profile FAQ button;
- 1305 — Wallet as wallet list;
- 1306 — wallet error microcopy;
- 1307 — History account timeline;
- 1308 — History data contract audit;
- 1309 — FAQ full list compact tree;
- 1310 — Profile/Wallet/FAQ proof pass.

Status: completed.

Result:

- Profile now keeps VIP and Active badges always visible, with inactive
  status rendered as a muted/grey state instead of disappearing;
- Profile no longer exposes Telegram numeric account id as the main public
  identity card;
- Profile FAQ entry is a clean button to `/faq`; the embedded mini FAQ was
  removed from Web-Profile;
- Wallet tab is reduced to connected wallet management and no longer
  contains general balances, withdraw status or a status-dashboard block;
- wallet errors use short human microcopy instead of raw error payloads;
- History now has account-level filters: All, Purchases, Exchange, Withdraw,
  Bonuses and Panels;
- History uses existing backend contracts `/wallets/balance-history` and
  `/withdraw/list/me`; no fake history data was added;
- FAQ uses a compact vertical tree and no `openAll` full expansion or
  horizontal quick-pill navigation on the main FAQ page;
- guard `test_profile_wallet_history_faq.py` protects the whole
  profile/wallet/history/FAQ contour.

Next cycle: 1321 — Users page statistics and actions audit.


## v168_95 cycles 1311-1320 result

Cycles completed in one pass:

- 1311 — HUB two equal buttons;
- 1312 — VIP NFT link policy;
- 1313 — Browser-Shop Web3 cards;
- 1314 — EFHC for TON payment;
- 1315 — USDT payment road audit;
- 1316 — Browser-Shop proof pass;
- 1317 — Admin home app grid;
- 1318 — Admin functional page template;
- 1319 — Admin routes map;
- 1320 — Admin proof and next plan.

Status: completed as a static/code-level pass.

Result:

- HUB public section is locked to exactly two equal actions: top up EFHC
  and EFHC VIP NFT;
- VIP NFT remains an external link policy and no heavy NFT/admin panel was
  introduced;
- Browser-Shop keeps large Web3 product cards and TON payment road proof;
- USDT road was audited, but no ready USDT button was exposed;
- Admin home starts with the canonical eight-section grid;
- a shared Admin functional page template was added;
- Admin route inventory was created without route deletion;
- the 1321-1350 Admin recovery extension plan was created.

Next cycle: 1321 — Users page statistics and actions audit.

## v168_99 cycle 1321 admin users audit

- Cycle 1321 repaired the Admin Users first-load search boundary.
- `/admin/users/search` now accepts empty `q` and returns latest users.
- Search supports username prefix and `global_id` prefix.
- Admin Users page now has statistics/actions proof markers.
- A wallet-bound users stat was added to the top stats strip.
- Balance correction is marked as `/admin/transfer` only.
- Guard: `tests/architecture/test_admin_users.py`.

## v169_00 cycle 1322 — Users table readability and safe operator actions

- Cycle 1322 turned Admin Users into a readable operator screen.
- Route diagnostics and endpoint badges were removed from the Users page.
- The user list is now a table with user, status, balances, wallet and
  action columns.
- Safe view/navigation actions are separated from sensitive operator actions.
- Balance correction requires operator confirmation before calling
  `/admin/transfer`.
- Correction direction values now match the backend contract:
  `credit` / `debit`.
- Guard: `tests/architecture/test_admin_users_variant_a.py`.

Next cycle: 1323 — Bank page statistics and ledger boundary.

## v169_01 cycle 1323 — Admin Bank statistics and ledger boundary

- Cycle 1323 rebuilt Admin Bank as a visual operator screen.
- Sandbox admin/dashboard references were inspected and recorded.
- Bank now has KPI statistics, interactive chart toggle, CSS chart bars,
  flow scheme, ledger table and safe operator actions.
- Route diagnostics were removed from the public Bank operator page.
- Guard: `tests/architecture/test_admin_bank.py`.

Next cycle: 1324 — Bank action confirmations and idempotency proof.


## v169_02 emergency archive numbering regression audit

- Emergency audit found that `v168_100` and `v168_101` were invalid archive
  aliases after valid `v168_99`.
- Canonical mapping: cycle 1322 = `v169_00`, cycle 1323 = `v169_01`.
- Current corrected archive continuation is `v169_02`.
- Root cause: hard numbering rule existed in AI startup docs, but no
  dedicated pre-release archive-numbering guard was run before publishing.
- Guard: `tests/architecture/test_archive_numbering_canon_v169_02.py`.

Next cycle: 1324 — Bank action confirmations and idempotency proof.

## v169_03 cycle 1324 — Admin Bank confirmations and idempotency proof

- Cycle 1324 strengthened Admin Bank sensitive action safety.
- Mint/Burn now require an explicit typed operator confirmation phrase.
- A pending idempotency key is prepared when the confirmation modal opens.
- The same prepared key is used for the mutation request.
- The visible Bank ledger copy no longer exposes an API route string to the
  operator.
- Guard: `tests/architecture/test_admin_bank_variant_a.py`.

Next cycle: 1325 — Users/Bank proof pass.

## v169_04 cycle 1325 — Admin interactive dashboard

- User clarified the Admin goal: an interactive analytics dashboard for the
  banking simulator, not a simple static control page.
- Admin home now includes a dynamic bank simulator dashboard with metric
  filters, game-day windows, zoom control, live pulse and auto-refresh.
- The dashboard recalculates visible KPI values client-side without page
  reload and uses current `/admin/reports/overview` facts/counters.
- Sandbox dashboard/chart patterns remain the visual donor; implementation is
  dependency-safe CSS/SVG because the project has no chart library dependency.
- Guard: `tests/architecture/test_admin_interactive_dashboard.py`.

Next cycle: 1326 — Withdrawals state-machine UI audit.

## v169_05-v169_35 Admin/Public extension summary — cycles 1326-1356

- 1326: Admin Dashboard UI Kit foundation and sandbox porting map.
- 1327: Admin interactive operator section for Bank / Users.
- 1328: Withdrawals mobile decision panel.
- 1329-1335: security/dependency/log repair and frontend standard migration to
  Next.js 16.2.6 / React 19.2.6 / Tailwind CSS 4.3.0.
- 1339: Admin Shop / Web3 separation panel.
- 1341-1342: Admin Tasks catalog UX and execution trace boundary.
- 1343-1345: Reports visual dashboard, export/download boundary and Diagnostics
  technical boundary.
- 1346-1351: Public UI sandbox audit and public interactivity/trust layers.
- 1352: ZIP encoding and wallets CRUD import hotfix.
- 1353: Admin UI Kit adoption proof pass.
- 1354: Admin screenshot QA preparation.
- 1355: Admin docs and SSOT route map update.
- 1356: Admin regression proof pass. DONE in v169_35.

Next cycle: 1357 — Admin recovery checkpoint report.

## v169_41 update — Next range extension checkpoint

Cycle 1363 closes the static public regression-proof lane and opens the next
public visual evidence lane. The new extension plan is:

- `docs/cycles/WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md`.

The next active step is 1364 — Public browser screenshot evidence harness and
capture manifest. This checkpoint does not claim real screenshots, live
Playwright execution, frontend build, backend full test suite or GitHub CI
green. Sandbox archives remain reference-only through `map_element.md`.



## v169_42 update — Public browser screenshot evidence harness

Cycle 1364 creates the public browser screenshot evidence harness and capture
manifest for 14 public routes. Added:

- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`;
- `tests/frontend/e2e/test_public_screenshot_capture_manifest.py`;
- `tests/architecture/test_public_browser_screenshot_evidence_harness.py`.

This pass does not include real PNG screenshots and does not claim live browser
Playwright execution, frontend build, backend full test suite or GitHub CI
green. Sandbox archives remain reference-only through `map_element.md`.


## v169_45 update — Profile / Wallet / History / FAQ visual trust pass

Cycle 1367 improved the account-trust public lane after the first two visual beauty passes:

- Profile trust rail and visual tab markers;
- wallet connect / primary / Ton Proof trust rail;
- history balance/filter/withdraw timeline rail;
- FAQ search/tree trust rail while preserving the vertical tree model.

This is static/source visual polish only. It does not claim browser screenshots,
live Playwright execution, GitHub CI green or final release readiness.

## 1371 semantic alignment completion note

Cycle 1371 now has two explicitly separated outcomes:

- v169_49: translation-quality repair for FAQ wave-3 English-identical tails;
- v169_50: semantic alignment repair against Q/A and RU/FAQ approval anchors.

Rule fixed by user: SSOT can also regress. If RU FAQ and EN FAQ differ, check
`docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` and FAQ approval records before
trusting either layer. After Q/A check, RU/FAQ meaning is the anchor and EN is a
translation layer.


## v169_53 update — Telegram Mini App shell polish

Cycle 1374 completed source/static TMA shell polish after the language canon lock was synchronized. The pass added Telegram/browser runtime shell markers, viewport-state handling, content/device safe-area CSS vars, public route BackButton behavior and TMA shell CSS. It did not change EFHC economics, backend roads, admin pages, TonConnect payment logic, sandbox runtime frameworks or CI workflows.

No real Telegram client run, screenshot/browser proof, frontend build/typecheck or GitHub CI green is claimed.

### Off-queue correction — v169.56 / i18n process correction

Status: DONE. This correction does not consume cycle 1377.

Completed after user instruction:
- no standalone report/json artifacts should be created for download; only the new archive is delivered;
- two i18n audit scripts were changed from hard `AssertionError` preconditions to default clean-checkout mode plus `--strict`;
- `test_i18n_fallback_is_english.py` was strengthened to protect the English fallback chain;
- `1 kWh = 1 EFHC` remains an allowlisted rate formula;
- `game task` public wording is not forbidden; its earlier neutral wording was a tone choice. The active ban is limited to gambling, loto, betting and random financial meaning.

Next planned regular cycle remains `1377 — UK public manual translation pass`.


### Cycle 1377 — UK public manual translation pass / v169.57

Status: DONE. The UK pass translated the remaining public-facing UK tails from verified Russian meaning without bulk-filling other languages. Updated domains: `public_engagement`, `profile`, `portal`, `energy`, plus small trust/wallet tails detected by the UK quality guard. Protected formulas/tokens (`1 kWh = 1 EFHC`, `TON`, `kWh`, `truth-path`) remain identical through the global allowlist, not as translation debt.

Changed guard: `ops/i18n/audit_uk_locale_value_quality.py` now reads `ops/i18n/identical_to_english_allowlist.json` so protected exact values are handled consistently.

No GitHub CI green, browser screenshots, live Telegram client proof, wallet transaction proof or release-ready verdict is claimed.

### Cycle 1383 — i18n manual coverage consolidation / v169.63

Status: DONE. Cycle 1383 consolidated the manual public-locale translation work
from cycles 1377-1382 and added the cross-locale guard
`ops/i18n/audit_i18n_manual_coverage_consolidation.py`. The guard reports 0
unexpected English-identical values and 0 wave-3 Cyrillic tails after shared
allowlist, admin-scope and key-specific UI abbreviation exclusions. Two Hindi
English-tail values were corrected manually: `browser_login.badge` and
`exchange.receive_label`.

This is static/source consolidation only. It does not claim human linguistic
certification, GitHub CI green, screenshots, live Telegram client proof,
TonConnect transaction proof or release readiness.

Next planned cycle: 1384 — browser text stress plan / screenshot-readiness plan.

## 1385 — CI logs repair / i18n range closure — DONE

- HEAD input: v169_64.
- Log input: logs_72099692636.zip.
- Fixed visible blockers: Alembic dunder/name drift, ruff findings, mypy logged attr drift, Next global CSS placement, flake8 critical-gate config, and PWA service-worker guard.
- i18n range 1376–1385 is closed at static/source level.
- No GitHub CI green, release-ready, screenshots, Telegram client proof or TonConnect transaction proof claimed.


## 1386 — CI logs 72103768470 repair / pytest skip-root fix — DONE

- HEAD input: v169_65.
- Log input: logs_72103768470.zip.
- Fixed critical pytest issue: `tests/frontend/e2e/conftest.py` no longer marks all collected tests as skipped when `EFHC_RUN_E2E` is unset; skip is scoped only to tests under `tests/frontend/e2e/`.
- Fixed Alembic metadata blocker: SQLAlchemy model `__table_args__` schema declarations restored from `_table_args_` drift.
- Fixed Next `/app` build blocker: `/app` is now a deep-link alias to `/`, while the custom shell remains in `_app.tsx`.
- No GitHub CI green, release-ready, screenshot, live Telegram client or TonConnect transaction proof claimed.

## 1388 — Critical test control rollback / v169.68

Status: REPAIR PASS. v169.67 is treated as unsafe because it archived active
architecture tests instead of repairing or mapping them. The repair base is
v169.66. All 271 pre-incident active architecture test files remain active;
no architecture tests were deleted, archived, skipped or xfailed in this pass.
A new integrity guard and manifest were added:

- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `scripts/ci/check_test_suite_integrity.py`;
- `tests/architecture/test_test_suite_integrity_repair.py`.

Log repair performed: the Next `/document` build blocker was fixed by moving
`frontend/src/pages/document.tsx` to `frontend/src/pages/_document.tsx`.
Shell-invariant architecture tests now check `_app.tsx`, while `/app` remains
only a deep-link alias route.

Collect-only control: 1198 tests collected locally with `PYTHONPATH=backend`.
This is not a full pytest green claim. Remaining active pytest failures from
`logs_72108233397.zip` must be repaired by domain in later cycles; hiding or
archiving failing tests is forbidden.


## Active control block

Current cycle line after v169_69: 1390 begins log-driven repair and test healing plan.
Historical numbering canon retained: v169_02 emergency archive; work pass = `v169_00`; work pass = `v169_01`.
## Active control block — cycles 1390-1400

- Номера блока: 432-451
- Выполнено: emergency law lock and first log-healing groups.
- Осталось: domain-by-domain pytest healing without disabling tests.
- Последний выполненный цикл: 1389 — AI archive laws kernel/canon lock.
- Следующий цикл: 1390 — CI log repair and test healing plan.
- `v*` обозначения — это архивные итерации ZIP, not test-control bypass.
- residual technical healing plan 02 remains historical.
- 430/500 and 431/500 markers retained for global numbering canon.

## 1390 — CI logs 72130548522 repair / test healing plan — PARTIAL

- HEAD input: v169_69.
- Log input: `logs_72130548522.zip`.
- Log facts: pytest reported `61 failed, 1063 passed, 8 skipped`; other logged gates were green.
- Fixed groups: dunder/name drift, admin route false positive, backend app init anchor, `_document.tsx` guard drift, PWA/service-worker guard compatibility, static retention anchors, cycle markers, Energy balance-chip boundary, rank wording and filename hygiene.
- Test consolidation status: audit only. No tests deleted, archived, skipped, xfailed or merged.
- Local collect-only: `1201 tests collected`.
- Targeted old failures excluding the line-length blocker: `59 passed`.
- Open blocker: `tests/architecture/test_max_line_length_72.py` still reports 174 line-length violations.
- Cycle 1390 closure: line-length 72 was repaired in v169.71 and filename
  hygiene was repaired in v169.72.
- Next planned cycle after 1390 closure: `1391 — pytest/domain failure
  healing from fresh logs or detected collection/domain blockers`.

See also: `docs/cycles/WORK_CYCLES_1390-1400_CI_LOG_REPAIR_AND_TEST_HEALING_PLAN.md`.


## 1391 — Pytest collection bootstrap diagnostics / v169.73 — DONE

- HEAD input: `EFHC_Bot_v169_72_cycle_1390_filename_hygiene_repair.zip`.
- Log input: no fresh `logs_*.zip` supplied.
- Local finding: full collect-only cannot be completed in the current sandbox
  because `alembic`, `freezegun`, `psycopg` and `sqlalchemy` are absent.
- Root cause fixed: the test-suite integrity script now reports the missing
  bootstrap dependency layer before pytest emits a long misleading collection
  tail.
- Guard added: the architecture test-suite integrity test now protects that
  dependency-diagnostics message.
- Not changed: no tests deleted, archived, skipped, xfailed or excluded; no CI
  workflow changed; no EFHC runtime/economics changed.
- Checked: AI archive laws guard passed; structural test-suite guard passed;
  targeted protection set passed with `31 passed`.
- Not claimed: full pytest green, GitHub CI green, npm build, screenshots,
  live Telegram client proof or release readiness.
- Next cycle: `1392 — historical docs/index retention anchor repair`, unless
  a fresh log archive is supplied first.


## 1392 — CI logs 72176795654 pytest failure repair / v169.74 — DONE

- HEAD input: `EFHC_Bot_v169_73_cycle_1391_pytest_collection_bootstrap_guard.zip`.
- Log input: `logs_72176795654.zip`.
- Log facts: CI gates except pytest passed; pytest reported `8 failed`,
  `1105 passed`, `8 skipped`.
- Root causes repaired from the log:
  - idempotency conflict marker in `transactions_service.py`;
  - brittle SQL-block boundary in `_enqueue_resync_energy`;
  - forbidden legacy gaming literals inside the active i18n guard itself;
  - bot-text parity loader importing Telegram runtime dependencies;
  - stale route-prefix guard locked to whitespace style;
  - split TonConnect generated-report path in operator route resolver;
  - Ukrainian exact-allowlist guard call formatting;
  - split USDT disabled-reason marker in shop catalog output.
- Test changes were limited to stale/broken guard anchors and preserved the
  same invariants. No test was deleted, archived, skipped, xfailed or hidden.
- Checked: 63 targeted architecture/policy tests passed; compileall passed;
  AI laws guard passed; structural test-suite guard passed; bot-text and UK
  i18n guards passed; gambling/loto guard reported zero forbidden findings.
- Local full collect-only still cannot be claimed because this sandbox lacks
  `alembic`, `freezegun`, `psycopg` and `sqlalchemy`.
- Not claimed: GitHub CI green, full pytest green, release-ready, browser
  screenshots, live Telegram proof or real TonConnect/wallet proof.
- Next cycle: `1393`, unless new logs are supplied first.

## 1393 — Fresh CI log green proof and shell verification / v169.75 — DONE

- HEAD input: `EFHC_Bot_v169_74_cycle_1392_ci_log_pytest_failure_repair.zip`.
- Log input: `logs_72181359058.zip`.
- Log facts: CI gate summary reported all gate steps passed.
- Pytest in the supplied log reported `1113 passed`, `8 skipped`,
  `1 warning` and no failures.
- Frontend build in the supplied log completed successfully on
  Next.js 16.2.6 and listed the expected public/admin pages.
- No log failure required code repair in this cycle. The cycle records
  evidence and keeps the shell/PWA/TonConnect guard lane active.
- Local targeted shell guard check passed with `48 passed`.
- Not changed: no tests deleted, archived, skipped, xfailed or hidden;
  no CI workflow, EFHC economics, wallet logic or sandbox runtime changed.
- Visible non-blocking log note: `npm ci` reported audit warnings
  (`5 vulnerabilities`). This was not a failing gate and requires a
  separate dependency-security audit before package changes.
- Not claimed beyond the supplied logs: release-ready, live Telegram
  client proof, browser screenshot proof or real TonConnect transaction
  proof.
- Next cycle: `1394 — Public Energy / Panels / Exchange guards`, unless
  a fresh log archive is supplied first.
## 1394 — Public Energy / Panels / Exchange guard matrix / v169.76 — DONE

- HEAD input: `EFHC_Bot_v169_75_cycle_1393_fresh_ci_log_shell_verification.zip`.
- Log input: no fresh failing logs supplied in this cycle.
- User decision: continue strictly by plan 1394-1400.
- Scope: public Energy, Panels and Exchange source-level guard matrix.
- Added guard: `tests/architecture/test_public_energy_panels_exchange_guard_matrix.py`.
- Added document: `docs/frontend/PUBLIC_ENERGY_PANELS_EXCHANGE_GUARD_MATRIX.md`.
- Added generated evidence: `reports/generated/public_energy_panels_exchange_guard_matrix_v169_76.json`.
- Protected chains:
  - `/` → `PublicEnergyInteractiveOverview` → public first-screen actions;
  - `/panels` → `PublicPanelsActivationPreview` → active/archive/activate roads;
  - `/exchange` → `PublicExchangeInteractivePreview` → preview/convert roads.
- Economic invariants preserved: `1 EFHC = 1 kWh`, Panels activation `100 EFHC`, Exchange only `kWh → EFHC`, no withdraw road mixing.
- Not changed: no CI workflow, no package lock, no wallet logic, no sandbox runtime, no EFHC economics.
- Test-control status: no test deleted, archived, skipped, xfailed, hidden or consolidated.
- Local targeted guard check passed for the public triad lane.
- Not claimed: full local pytest green, new GitHub CI green, screenshots, live Telegram proof, real TonConnect proof or release-ready.
- Next cycle: `1395`, unless fresh failing logs are supplied first.

## 1402 — I18N hardcoded strings repair / v169.84 — DONE

- HEAD input: `EFHC_Bot_v169_83_cycle_1401_i18n_reaudit_low_signal_repair.zip`.
- Audit/TZ input: `docs/audits/I18N_HARDCODED_AUDIT_AND_TZ_V169_83_2026_06_03.md`.
- Scope: public/shared hardcoded strings from the v169.83 i18n audit.
- Repaired required group-A findings in ErrorBoundary, AdminRouteGuardState,
  AdsBanner, EnergyGauge, TelegramProductCard, Modal and SurfaceFactsStrip.
- SurfaceFactsStrip use-cases were checked; all current call sites pass `title`,
  so the English default fallback was removed instead of adding an unused key.
- Optional low-risk accessibility/component cleanup was also applied for
  GlobalHeader `EFHC balance` aria text, ShopLayout avatar alt and
  TelegramProductCard secondary Details action.
- Added 18 flat i18n keys to all 13 locale bundles: 15 required keys and 3
  optional accessibility/component keys.
- Added active guard:
  `tests/architecture/test_i18n_hardcoded_strings_guard.py`.
- Not changed: no EFHC economics, wallet/TonConnect logic, CI workflow,
  package lock, sandbox runtime or admin/public route boundary.
- Test-control status: no test deleted, archived, skipped, xfailed, hidden or
  consolidated.
- Checked: locale parity, locale inventory, no-admin-leak, gambling/chance
  contour, all 12 locale value-quality scripts and the new targeted guard.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots,
  live Telegram client proof, real TonConnect/wallet proof or release-ready.
- Next cycle: `1403`, only after a new audit/log/task or direct user command.

## 1409-1410 — HEAL-0018 transaction-boundary repair / v169.90 — DONE

- HEAD input: `EFHC_Bot_v169_89_cycles_1408_1409_heal0023_idempotency_heal0018_boundary_map.zip`.
- Cycle 1409 map was re-read and used as the controlled repair base.
- Cycle 1410 repaired the first runtime boundary in core money services:
  - `backend/app/services/transactions_service.py` no longer uses hidden
    `begin_nested()` fallback in `_tx_context()`;
  - `_tx_context()` now owns a single commit/rollback boundary for the money
    service call;
  - `backend/app/services/exchange_service.py` closes read-only preflight
    autobegin before entering transactions_service.
- Added guard: `tests/architecture/test_heal0018_transaction_boundary_repair.py`.
- Added docs/audit/report for v169.90.
- Not changed: withdraw atomicity, EFHC economics, wallet/TonConnect logic,
  CI workflow, package locks, sandbox runtime or AI Archive Laws.
- Residual next cycle: `1411 — HEAL-0024 exchange/withdraw atomicity repair`.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots,
  live Telegram proof, real wallet proof or release-ready.


## 1411-1412 — HEAL-0055 deposit-cache DB idempotency and Kernel Start Core / v169.92 — DONE

- HEAD input: `EFHC_Bot_v169_91_cycles_1410_1411_heal0024_withdraw_atomicity_kernel_refresh.zip`.
- Cycle 1411 was re-read as the withdraw atomicity baseline.
- Cycle 1412 repaired deposit duplicate protection by adding DB-backed long-retention idempotency records in `efhc_admin.idempotency_key`.
- `backend/app/services/efhc_deposits_service.py` now uses `scope=deposit:efhc`, canonical tx-hash keys, `expires_at=NULL`, and response read-through via `response_payload_json`.
- `backend/app/services/transactions_service.py::credit_user_from_bank()` accepts optional meta so deposit tx metadata can be stored in transfer-log meta.
- Operator Kernel is now mandatory in Start Core: `READING_ENTRYPOINT`, `TOPIC_READING_ROUTES`, `ARCHIVE_SYNAPTIC_LINKS`, root `KERNEL.md`, and `file_map.py --refresh` were updated.
- Added guard: `tests/architecture/test_heal0055_deposit_idempotency_kernel_start_core.py`.
- Not changed: EFHC economics, wallet/TonConnect logic, CI workflow, package locks, sandbox runtime or AI Archive Laws.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots, live Telegram proof, real wallet proof or release-ready.
- Next cycle: `1413 — HEAL-0055 long-retention deposit idempotency policy`.


## 1415-1416 — CI log repair and P0 range closure audit / v169.94 — DONE

- HEAD input: `EFHC_Bot_v169_93_cycles_1413_1414_heal0055_retention_p0_cross_guard.zip`.
- Log input: `logs_72248746196.zip`; logs were read first.
- Log facts: ruff full report failed with one `SIM102`; pytest reported
  `8 failed, 1164 passed, 8 skipped, 1 warning`.
- Root causes repaired: stale guards after i18n/withdraw atomicity repairs,
  line-length drift, numbered-label hygiene drift, healer enum drift, and
  one canon wording violation.
- Targeted checks for logged failures passed locally with `7 passed`.
- Ruff full report passed locally after repair.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  screenshots, live Telegram proof, real wallet proof or release-ready.
- Remaining active plan cycles: `1417-1420`.

## 1417-1420 — FSM states split and range closure / v169.95 — DONE

- HEAD input: `EFHC_Bot_v169_94_cycles_1415_1416_ci_log_repair_range_closure.zip`.
- Kernel preload was performed before topic work.
- `backend/app/bot/states.py` was split by responsibility into `backend/app/bot/fsm/` modules while remaining a compatibility facade.
- New modules: `dto.py`, `backend.py`, `manager.py`, `decorators.py`, and package `__init__.py`.
- `backend/app/bot/__init__.py` now lazily loads the heavy aiogram runtime so FSM imports stay lightweight.
- Added guard: `tests/architecture/test_fsm_states_split_facade.py`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Active plan `1404-1420` is closed with 0 cycles remaining.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots, live Telegram proof, real wallet proof or release-ready.

## 1422 — P0 economic risk surgical repair / v169.97 — DONE

- HEAD input: `EFHC_Bot_v169_96_cycle_1421_ci_log_repair.zip`.
- Audit source: `P0_ECONOMIC_RISK_FOUND` for `transactions_service.py` and related money services.
- Scope repaired:
  - `FIND-002`: `spend_user_to_bank_bonus_then_main()` now read-throughs by both `:main` and `:bonus` derived idempotency keys.
  - `FIND-004`: `BankService.manual_bank_user_transfer()` no longer passes nonexistent kwargs to canonical debit functions.
- Added active guard: `tests/architecture/test_economic_risk_guards.py`.
- Added cycle doc: `docs/cycles/WORK_CYCLES_1422_ECONOMIC_RISK_REPAIR.md`.
- Added backend plan: `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`.
- Archived supplied audit in `docs/audits/`.
- Kernel cache refreshed after new files were added.
- Песочница использована только как reference/navigation layer. Runtime-код не переносился.
- Not changed: EFHC economics, wallet/TonConnect logic, frontend runtime, CI workflow, package locks or AI Archive Laws.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots, live Telegram proof, real wallet proof or release-ready.
- Remaining economic audit plan:
  - `1423`: `FIND-001` panel activation atomicity;
  - `1424`: `FIND-003` withdraw refund split + `FIND-005` exchange TOCTOU;
  - `1425`: `FIND-006..010` cleanup and reconciliation hardening.

## 1423 — P0 panel activation atomicity repair / v169.98 — DONE

- HEAD input: `EFHC_Bot_v169_97_cycle_1422_economic_risk_repair.zip`.
- User confirmed option `A` for `FIND-001`: add a nocommit spend helper and make `panels_service.py` own the single transaction boundary.
- Scope repaired:
  - `FIND-001`: panel activation no longer commits EFHC spend before panel row creation.
  - `spend_user_to_bank_bonus_then__main__nocommit()` was added for higher-level atomic flows.
  - `activate_panel()` now performs user lock, limit checks, spend, panel creation and activation payload merge in one transaction.
  - Replay payload lookup now reads both `:main` and `:bonus` spend logs, protecting all-bonus panel activation replay.
- Updated active guard: `tests/architecture/test_economic_risk_guards.py`.
- Added cycle doc: `docs/cycles/WORK_CYCLES_1423_PANEL_ATOMICITY_REPAIR.md`.
- Песочница использована только как reference/navigation layer. Runtime-код не переносился.
- Not changed: EFHC economics, wallet/TonConnect logic, frontend runtime, CI workflow, package locks or AI Archive Laws.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots, live Telegram proof, real wallet proof or release-ready.
- Remaining economic audit plan:
  - `1424`: `FIND-003` withdraw refund split + `FIND-005` exchange TOCTOU;
  - `1425`: `FIND-006..010` cleanup and reconciliation hardening.



## 1424 — Withdraw refund atomicity and exchange TOCTOU repair / v169.99 — DONE

- HEAD input: `EFHC_Bot_v169_98_cycle_1423_panel_atomicity_repair.zip`.
- User had already confirmed the architecture decisions for `FIND-003` and
  `FIND-005`.
- Scope repaired:
  - `FIND-003`: `cancel_withdraw()` and `admin_reject_withdraw()` no longer
    commit final status separately from refund;
  - `credit_user_from_bank_nocommit()` was added for higher-level atomic
    withdraw refund flows;
  - `FIND-005`: exchange helpers no longer perform idempotency read-through
    before the user row lock;
  - exchange helpers now close preflight/autobegin state at entry and check
    idempotency inside the lock/retry loop.
- Updated active guard: `tests/architecture/test_economic_risk_guards.py`.
- Added cycle doc: `docs/cycles/WORK_CYCLES_1424_WITHDRAW_EXCHANGE_ATOMICITY_REPAIR.md`.
- Песочница использована только как reference/navigation layer. Runtime-код не переносился.
- Not changed: EFHC economics, wallet/TonConnect logic, frontend runtime,
  CI workflow, package locks or AI Archive Laws.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots,
  live Telegram proof, real wallet proof or release-ready.
- Remaining economic audit plan:
  - `1425`: `FIND-006..010` cleanup and reconciliation hardening.


## 1425 — Economic cleanup and reconciliation hardening / v170.00 — DONE

- HEAD input: `EFHC_Bot_v169_99_cycle_1424_withdraw_exchange_atomicity_repair.zip`.
- Activation source: direct user task to continue cycle `1425`.
- Scope repaired:
  - `FIND-006`: rejected `exchange_all` with `available_kwh=0` no longer writes a false financial zero-log;
  - `FIND-007`: exchange direct-call preflight/autobegin safety is guarded;
  - `FIND-008`: `withdraw_service.py` no longer owns a duplicate `_tx_context`;
  - `FIND-009`: legacy strict kWh check now uses SSOT calculation from `total_generated_kwh - exchanged_kwh_total`;
  - `FIND-010`: bonus credit `meta` is passed into `_run_idempotent` and persisted to transfer log metadata.
- Reconciliation hardening documented: `INV-08` — `SUM(user.main_balance + user.bonus_balance) + bank.balance = const` for non-emission money movements.
- Updated active guard: `tests/architecture/test_economic_risk_guards.py`.
- Added cycle doc: `docs/cycles/WORK_CYCLES_1425_ECONOMIC_CLEANUP_RECONCILIATION.md`.
- Песочница использована только как reference/navigation layer. Runtime-код не переносился.
- Not changed: EFHC economics, wallet/TonConnect logic, frontend runtime, CI workflow, package locks or AI Archive Laws.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, screenshots, live Telegram proof, real wallet proof or release-ready.
- Economic audit repair plan `1422-1425` is complete locally; next safe step is a fresh CI log, release audit, or new user task.

## 1426 — Panel dead transaction-context cleanup / v170.01 — DONE

- HEAD input: `EFHC_Bot_v170_00_cycle_1425_economic_cleanup_reconciliation.zip`.
- Audit input: `P0_ECONOMIC_REAUDIT_V170_00_CYCLE_1425.md` with verdict
  `ECONOMY_SAFE_WITH_MINOR_FINDINGS`.
- Re-audit confirmed all previous economic findings closed and found one new
  P3: dead local `_tx_context` in `panels_service.py` using `db.begin_nested()`.
- Runtime repair: removed the unused local helper and kept panel activation on
  canonical `bank._tx_context(db)`.
- Guard added: `test_panels_service_no_local_tx_context` in
  `tests/architecture/test_economic_risk_guards.py`.
- Documents, Q&A, Healer, casebook, map_element and Operator Kernel cache were
  updated.
- Current progress for `1401-1500`: done `26 / 100`, remaining `74 / 100`.
- The economic re-audit cleanup condition is locally satisfied. Next safe step:
  release audit, fresh CI log, or new user task.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.

## 1427 — CI log repair after economic cleanup / v170.02 — DONE

- HEAD input: `EFHC_Bot_v170_01_cycle_1426_panel_dead_tx_context_cleanup.zip`.
- Log input: `logs_72342361356.zip`.
- Log verdict: gate failed because `ruff` and `pytest` failed.
- Root causes repaired:
  - `withdraw_service.py` import order failed ruff `I001`;
  - `panels_service.py` had 3 line72 violations;
  - new economic helper names contained degraded `_main_` tokens;
  - `atlas.json` had one incomplete Healer card and one invalid enum.
- Runtime changed:
  - `backend/app/services/withdraw_service.py`;
  - `backend/app/services/panels_service.py`;
  - `backend/app/services/transactions_service.py`.
- Test changed: `tests/architecture/test_economic_risk_guards.py`.
- Documents, Q&A, Healer, casebook, map_element and Operator Kernel cache were
  updated.
- Sandbox note: uploaded sandbox archives were used only as reference and
  navigation context. Runtime code, lock files, CI files, wallet logic,
  economics and translations were not imported.
- Current progress for `1401-1500`: done `27 / 100`, remaining `73 / 100`.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.

## 1428 — Security audit reconciliation and repair plan / v170.03 — DONE

- HEAD input: `EFHC_Bot_v170_02_cycle_1427_ci_log_repair.zip`.
- Audit input: `P0_SECURITY_AUDIT_V170_01.md`.
- Audit verdict accepted: `P0_RELEASE_BLOCKED`.
- Scope: planning/reconciliation only; no runtime security code was changed.
- Truth split resolved:
  - audit title names `v170.01`;
  - audit body says `v170.02` was actually inspected;
  - current line HEAD is `v170.02`;
  - therefore future security repair continues from `v170.02`.
- Audit questions answered:
  - wallet binding canon is TonConnect proof based;
  - both backend entrypoints must converge to the same security behavior;
  - final verdicts must be based on the actual latest HEAD.
- Archived audit source: `docs/audits/P0_SECURITY_AUDIT_V170_01.md`.
- New canon: `docs/security/P0_SECURITY_REPAIR_CANON.md`.
- New cycle plan:
  - `1429`: P0 wallet proof boundary plus cron secret control plane;
  - `1430`: P2 Telegram `auth_date`, redaction and legacy headers;
  - `1431`: regression hardening and repeat security audit prep.
- New guard: `tests/architecture/test_security_audit_reconciliation_plan.py`.
- Песочница used only as reference/navigation layer. Runtime code, CI files,
  lock files, wallet/payment logic, economics, configs, secrets and
  translations were not imported.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: P0 fixed, GitHub CI green, full pytest green, frontend build,
  screenshots, live Telegram proof, real wallet proof or release-ready.
- Current progress for `1401-1500`: done `28 / 100`, remaining `72 / 100`.

## 1429 — P0 security repair / v170.04 — DONE locally, re-audit pending

- HEAD input: `EFHC_Bot_v170_03_cycle_1428_security_audit_reconciliation_plan.zip`.
- Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_01.md`.
- Entering verdict: `P0_RELEASE_BLOCKED`.
- Runtime repair was applied for the two P0 blockers:
  - `/wallets/connect` now requires verified TonConnect proof before binding;
  - wallet-gated money routes require `proof_verified = true` active bindings;
  - TonConnect proof payload tokens are single-use/replay guarded;
  - `/cron/tick` no longer has a working repository-known default secret;
  - prod/stage fail fast on unsafe `CRON_SECRET`.
- New guard: `tests/architecture/test_security_p0_repair_guards.py`.
- Documents, Q&A, SSOT table inventory, Healer, casebook, map_element and
  Operator Kernel cache were updated.
- Песочница used only as reference/navigation layer. Runtime code, CI files,
  lock files, wallet/payment donor logic, economics, secrets, configs and
  translations were not imported.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: repeat security audit passed, release-ready, GitHub CI green,
  full pytest green, frontend build, screenshots, live Telegram proof or real
  wallet proof in Telegram client.
- Current progress for `1401-1500`: done `29 / 100`, remaining `71 / 100`.
- Next safe planned cycle: `1430 — P2 replay / OPSEC / legacy headers`.


## 1430 — Security P2 replay / OPSEC repair / v170.05 — DONE locally

- HEAD input: `EFHC_Bot_v170_04_cycle_1429_p0_security_repair.zip`.
- Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_01.md`.
- Closed locally:
  - strict Telegram `auth_date` fail-closed behavior;
  - production secret redaction aliases;
  - removal of legacy frontend/admin headers from runtime and CORS layers.
- New guard: `tests/architecture/test_security_p2_replay_opsec_headers.py`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: repeat security audit pass, release-ready, GitHub CI green,
  full pytest green, frontend build, screenshots, live Telegram proof or real
  wallet proof.
- Current progress for `1401-1500`: done `30 / 100`, remaining `70 / 100`.

## 1431 — Security regression hardening / v170.06 — DONE locally

- HEAD input: `EFHC_Bot_v170_05_cycle_1430_security_p2_replay_opsec_repair.zip`.
- Purpose: add regression guards and repeat-audit preparation after P0/P2
  security repairs.
- Runtime hardening:
  - Telegram webhook secret is verified before dedupe registration;
  - secret-protected callbacks can use `register_external_event_after_secret()`.
- New guard: `tests/architecture/test_security_regression_hardening.py`.
- Guard coverage:
  - every backend admin route has `Depends(require_admin)`;
  - owner-scoped money routes use authenticated identity / ownership service;
  - prod docs/OpenAPI/Redoc null handling and CORS wildcard rejection are locked;
  - Telegram webhook dedupe runs after secret validation.
- Песочница used only as reference/navigation layer.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: repeat security audit pass, release-ready, GitHub CI green,
  full pytest green, frontend build, screenshots, live Telegram proof or real
  wallet proof.
- Current progress for `1401-1500`: done `32 / 100`, remaining `68 / 100`.


## Cycle 1432 — CI log repair after security hardening

Status: DONE
Archive: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`
Source log: `logs_72432961872.zip`

Closed factual CI failures after cycles `1429–1431`: ruff UP037, Bandit
legacy digest naming, SSOT table-count drift (`43` ORM tables), stale panel/spend
guards, Healer enum drift and wallet proof replay ordering.

## 1433 — Operator Kernel First Standard hardening / v170.08 — DONE

- HEAD input: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`.
- Mode: `KERNEL HARDENING / DOCS-ONLY / NO RUNTIME LOGIC CHANGE`.
- Created: `docs/NORM/EFHC_OPERATOR_KERNEL_FIRST_STANDARD.md`.
- Strengthened root `KERNEL.md` as a short startup pointer, not an
  encyclopedia.
- Added Kernel-first references to reading entrypoint, Operator Kernel
  protocol, Permission/Patch/Validation standards, routes, guard manifest,
  Q&A register, report index and cycle register.
- Regenerated `ops/operator_kernel/cache/file_map.json` after documentation
  changes.
- Песочница used only as reference/navigation layer. No runtime, test, CI,
  lock, wallet/payment, economy, config, secret or translation code was
  imported.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, browser screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `33 / 100`, remaining `67 / 100`.


## 1434 — Security minor findings repair / v170.09 — DONE

- HEAD input: `EFHC_Bot_v170_08_cycle_1433_operator_kernel_first_standard_hardening.zip`.
- Audit input: `docs/audits/P0_SECURITY_AUDIT_V170_08.md`.
- Closed `FIND-02` P1: `ADS_TEST_MODE=true` is forbidden in prod/stage by
  settings fail-fast and `env.prod.example` records `ADS_TEST_MODE=false`.
- Closed `FIND-04` P1: monetary middleware default prefixes now cover
  `/deposit` and `/payment-intents`.
- Closed `FIND-05` P2: real-looking TON addresses in `env.prod.example` were
  replaced with placeholders.
- Added guard `tests/architecture/test_security_audit_v170_08_minor_repair.py`
  and updated `tests/architecture/test_monetary_rate_limit_enabled.py`.
- Песочница used only as reference/navigation layer.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, browser screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `34 / 100`, remaining `66 / 100`.

## 1442 — OpenAPI rebuild and strict contract gate / v170.18 — DONE locally

- HEAD input: `EFHC_Bot_v170_17_cycle_1441_admin_wallet_reset_semantic_repair.zip`.
- Scope: repair checked-in OpenAPI/contract drift from `F-006` in the active migrations/routes/backend-frontend linkage audit.
- Added dependency-light route-source rebuilder: `ops/routes/rebuild_openapi_contract_snapshot.py`.
- Rebuilt:
  - `backend/openapi/openapi.json`;
  - `backend/openapi/openapi_manifest.json`;
  - `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`;
  - `docs/SSOT/ssot_pack/SSOT_ROUTES_NUMBERED.csv`;
  - `docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv`.
- Added strict static gate: `ops/routes/check_openapi_strict_contract_gate.py`.
- Added guard: `tests/architecture/test_openapi_rebuild_strict_contract_gate.py`.
- Guard report: `reports/generated/openapi_strict_contract_gate_v170_18.json` → `status=ok`.
- Local validation:
  - new OpenAPI guard file: `9 passed`;
  - related linkage/OpenAPI guard pack: `47 passed`.
- Not claimed: live FastAPI `app.openapi()` proof, GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `42 / 100`, remaining `58 / 100`.
- Next safe planned cycle: `1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards`.

## 1445 — CI log repair + BNB/source skin cleanup / v170.21 — DONE locally

- HEAD input: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`.
- Logs input: `logs_72623328892.zip`.
- Fixed factual CI failures: ruff import-order/E402, mypy Decimal/Optional drift, admin bank road guard drift, admin hub route module guard drift, Kernel fallback marker, line72 tooling violations, route freeze markdown drift, Healer atlas compact schema drift, wallet hardening test state bleed.
- Removed old BNB/source skin: `frontend/public/skins/1.png`.
- Canonical skin asset is now WebP: `frontend/public/skins/1.webp`.
- Added report: `reports/generated/ci_log_repair_v170_21.json`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `45 / 100`, remaining `55 / 100`.
- Next safe planned cycle: `1446 — CI rerun log reconciliation or next fresh log repair`.

## 1448 — Linkage minor findings repair / v170.24 — DONE locally

- HEAD input: `EFHC_Bot_v170_23_cycle_1447_chat_docs_intake.zip`.
- Audit verdict: `LINKAGE_SAFE_WITH_MINOR_FINDINGS`.
- Closed locally:
  - `LNK-01`: full linkage report/test metadata moved from
    `1443 / v170.19` to `1448 / v170.24`;
  - `LNK-02`: Admin Hub frontend now uses generated admin seam
    constants/types for `/admin/hub/*` paths.
- New machine report: `reports/generated/full_linkage_report_v170_24.json`.
- Repair evidence: `reports/generated/linkage_minor_findings_repair_v170_24.json`.
- Runtime economy changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Local validation:
  - full linkage architecture guard: `9 passed`;
  - OpenAPI strict contract guard: `9 passed`;
  - line72 guard: `1 passed`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `48 / 100`, remaining `52 / 100`.
- Next safe planned cycle: fresh CI rerun proof / release-gate preparation
  or factual log repair if new `logs_*.zip` is provided.

## 1449 — Frontend visual / i18n / buttons / UX repair / v170.25 — DONE locally

- HEAD input: `EFHC_Bot_v170_24_cycle_1448_linkage_minor_findings_repair.zip`.
- Audit inputs:
  - `docs/audits/P0_FRONTEND_VISUAL_I18N_BUTTONS_UX_AUDIT_V170_24.md`;
  - `docs/audits/TZ_FRONTEND_VISUAL_I18N_BUTTONS_UX_REPAIR_V170_24.md`.
- Closed locally F-01 through F-09 from the visual/i18n/buttons UX audit.
- Added shared frontend human-label normalizer: `frontend/src/lib/humanLabels.ts`.
- Panels countdown now uses `86400 / 3600 / 60` second math.
- Tasks, Web Profile, Withdraw, Ranks, Admin Shop and Admin Withdrawals no longer use the confirmed raw runtime labels from the audit.
- Withdraw Money-Center return now targets `/web-profile?section=history`.
- Active Energy route docs now keep `/` as canonical and mark `/energy` inactive.
- F-10 screenshot proof is deferred to a runtime browser/TMA screenshot cycle.
- Runtime economy changed: no. Backend contracts changed: no. DB migrations changed: no.
- CI/workflows/lock files changed: no. Tests were not deleted, archived, skipped or xfailed.
- Local validation: targeted visual/i18n UX guard `9 passed`; targeted guard pack `55 passed`; line72 passed.
- Not claimed: GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `49 / 100`, remaining `51 / 100`.
- Next safe planned cycle: screenshot proof / visual regression or factual log repair if new `logs_*.zip` is provided.

## 1450 — Visual P0 countdown follow-up repair / v170.26 — DONE locally

- HEAD input: `EFHC_Bot_v170_25_cycle_1449_frontend_visual_i18n_ux_repair.zip`.
- Additional audit verdict: `P0_VISUAL_OR_BUTTON_RISK_FOUND`.
- Closed locally VIS-01 through VIS-07 from the additional visual audit.
- Panels countdown uses explicit `86400 / 3600 / 60` second constants and arithmetic guard tests.
- Admin Withdrawals mobile labels, Withdraw history balance type and Admin Tasks badges are human-readable.
- Locale JSON files no longer contain nested ghost `admin` / `common` objects; all active locale files keep equal flat key counts.
- HUB trust rail now renders only two canonical spans.
- Runtime economy changed: no. Backend contracts changed: no. DB migrations changed: no.
- CI/workflows/lock files changed: no. Tests were not deleted, archived, skipped or xfailed.
- Not claimed: GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `50 / 100`, remaining `50 / 100`.
- Next safe planned cycle: screenshot proof / visual regression or factual log repair if new `logs_*.zip` is provided.


## 1452 — Dashboard visual direction plan / v170.28 — DONE locally

- HEAD input: `EFHC_Bot_v170_27_cycle_1451_ci_log_repair.zip`.
- User supplied `DASHBOARD_VISUAL_PLAN.md` and `grafana-main.zip`.
- Added active direction document:
  `docs/NORM/DASHBOARD_VISUAL_PLAN.md`.
- Fixed dashboard work direction range as `1455–1495`, 41 cycles.
- Added cycle `1495` as dashboard direction handoff/backlog freeze.
- `grafana-main.zip` was inspected as reference only; runtime code,
  dependencies, lock files and CI were not copied.
- Runtime economy changed: no. Backend contracts changed: no. DB
  migrations changed: no. CI/workflows/lock files changed: no.
- Tests were not deleted, archived, skipped or xfailed.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `52 / 100`, remaining
  `48 / 100`.
- Next safe planned steps: `1453` fresh CI proof/log repair if logs
  exist, `1454` screenshot proof preparation, `1455` Dashboard Visual
  Kernel.


## 1459 — Dashboard Component Contract / v170.35 — DONE locally

- HEAD input:
  `EFHC_Bot_v170_34_cycle_1458_dashboard_design_tokens_foundation.zip`.
- Added active component contract:
  `docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`.
- Added runtime type contract:
  `frontend/src/lib/dashboard/componentContract.ts`.
- Added machine report:
  `reports/generated/dashboard_component_contract_v170_35.json`.
- Added guard:
  `tests/architecture/test_dashboard_component_contract.py`.
- Required states fixed as loading, empty, error, stale and success.
- Required data kinds fixed as raw, derived, synthetic preview and
  real time-series.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. CI/workflows/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `59 / 100`, remaining
  `41 / 100`.
- Dashboard direction progress: done `5 / 41`, remaining `36 / 41`.
- Next safe planned cycle: `1460 — Simulation Dashboard UI Kit
  Foundation`.


## 1463 — Progress System Foundation / v170.39 — DONE locally

- HEAD input: `EFHC_Bot_v170_38_cycle_1462_panel_chrome_foundation.zip`.
- Added active progress system document:
  `docs/NORM/PROGRESS_SYSTEM_FOUNDATION.md`.
- Added runtime progress system:
  `frontend/src/components/dashboard/ProgressSystem.tsx`.
- Added linear, segmented, circular, countdown and milestone progress
  primitives.
- Simulation and Admin UI Kits now expose safe progress wrappers.
- Grafana progress/gauge anchors were mapped as reference only.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. CI/workflows/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `63 / 100`, remaining
  `37 / 100`.
- Dashboard direction progress: done `9 / 41`, remaining `32 / 41`.
- Next safe planned cycle: `1464 — Mini Charts Foundation`.


## 1469 — Energy Dashboard Runtime Port / v170.45 — DONE locally

- HEAD input: `EFHC_Bot_v170_44_cycle_1468_dependency_audit_triage.zip`.
- Added active runtime document:
  `docs/NORM/ENERGY_DASHBOARD_RUNTIME_PORT.md`.
- Added Grafana element analysis:
  `docs/NORM/ENERGY_DASHBOARD_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime Energy dashboard component:
  `frontend/src/components/dashboard/EnergyDashboardRuntime.tsx`.
- Integrated runtime dashboard into live Energy route:
  `frontend/src/pages/index.tsx`.
- Added guard:
  `tests/architecture/test_energy_dashboard_runtime_port.py`.
- Truth model: raw + derived values from existing `SyncSnapshot`.
- Synthetic preview data in runtime: no. Real time-series claim: no.
- Runtime period control is snapshot-only until read-only time-series
  backend contracts exist.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `69 / 100`, remaining `31 / 100`.
- Dashboard direction progress: done `15 / 42`, remaining `27 / 42`.
- Next safe planned cycle: `1470 — Energy Dashboard Visual QA`.

## 1471 — Panels Portfolio Sandbox Prototype / v170.47 — DONE locally

- HEAD input: `EFHC_Bot_v170_46_cycle_1470_energy_dashboard_visual_qa.zip`.
- Added active prototype document:
  `docs/NORM/PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`.
- Added Grafana element analysis:
  `docs/NORM/PANELS_PORTFOLIO_SANDBOX_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added sandbox-only component:
  `frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx`.
- Added guard:
  `tests/architecture/test_panels_portfolio_sandbox_prototype.py`.
- Truth model: `synthetic_preview`; runtime `/panels` route changed: no.
- Visible prototype blocks: portfolio toolbar, KPI strip, active/archive filter,
  180-day lifecycle countdown, portfolio trend, distribution, activity strip and
  individual panel cards.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `71 / 100`, remaining `29 / 100`.
- Dashboard direction progress: done `17 / 42`, remaining `25 / 42`.
- Next safe planned cycle: `1472 — Panels Portfolio Runtime Port`.


## 1480 — Web Profile / Account Center Dashboard Polish / v170.56 — DONE locally

- HEAD input: `EFHC_Bot_v170_55_cycle_1479_exchange_dashboard_support_widgets.zip`.
- Added active norm document:
  `docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_DASHBOARD_POLISH.md`.
- Added Grafana element analysis:
  `docs/NORM/WEB_PROFILE_ACCOUNT_CENTER_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime account dashboard component:
  `frontend/src/components/dashboard/WebProfileAccountDashboard.tsx`.
- Integrated the dashboard into live Web-Profile feature page:
  `frontend/src/features/profile/WebProfilePage.tsx`.
- Added guard:
  `tests/architecture/test_web_profile_account_center_dashboard_polish.py`.
- Truth model: `raw + derived snapshot`; fake account history added: no.
- Public raw `tg_id`, raw payload, initData and debug JSON visible: no.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `80 / 100`, remaining `20 / 100`.
- Dashboard direction progress: done `26 / 42`, remaining `16 / 42`.
- Next safe planned cycle: `1481 — Admin Overview Dashboard Upgrade`.

## Cycle 1482 completion note

`1482 — Admin Reports Grafana-like Upgrade` was completed locally as
`v170.58`. `/admin/reports` now has a Grafana-like read-only dashboard
surface with toolbar, freshness, display-only filters, panel chrome,
derived snapshot charts and a safe inspector. The old fake trend
generator from a single snapshot was removed. Next safe cycle is
`1483 — Admin Bank Dashboard Upgrade`.
## 1486 — Admin Withdrawals Dashboard Upgrade / v170.62 — DONE locally

- HEAD input: `EFHC_Bot_v170_61_cycle_1485_admin_deposits_dashboard_upgrade.zip`.
- Added active norm document:
  `docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis:
  `docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime withdrawals dashboard component:
  `frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx`.
- Integrated the dashboard into live admin route:
  `frontend/src/pages/admin/withdrawals.tsx`.
- Added guard:
  `tests/architecture/test_admin_withdrawals_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot`; fake time-series and fake handling time added: no.
- Guarded actions pay/approve/reject/consistency repair remain outside dashboard.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `86 / 100`, remaining `14 / 100`.
- Dashboard direction progress: done `32 / 42`, remaining `10 / 42`.
- Next safe planned cycle: `1487 — Admin Panels Dashboard Upgrade`.



## 1487 — Admin Panels Dashboard Upgrade / v170.63 — DONE locally

- HEAD input: `EFHC_Bot_v170_62_cycle_1486_admin_withdrawals_dashboard_upgrade.zip`.
- Added active norm document:
  `docs/NORM/ADMIN_PANELS_DASHBOARD_UPGRADE.md`.
- Added Grafana element analysis:
  `docs/NORM/ADMIN_PANELS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`.
- Added runtime panels dashboard component:
  `frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx`.
- Integrated the dashboard into live admin route:
  `frontend/src/pages/admin/panels.tsx`.
- Added guard:
  `tests/architecture/test_admin_panels_dashboard_upgrade.py`.
- Truth model: `raw + derived snapshot`; fake activation trends and fake panel history added: no.
- Guarded activate/deactivate controls remain outside dashboard.
- 1485 deposits progress-bar coverage UX debt closed with a third Pending intents progress bar.
- Runtime economy changed: no. Backend contracts changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Grafana and Песочница used only as reference layers.
- Not claimed: GitHub CI green, full pytest green, full frontend build,
  release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `87 / 100`, remaining `13 / 100`.
- Dashboard direction progress: done `33 / 42`, remaining `9 / 42`.
- Next safe planned cycle: `1488 — Admin Tasks / Referrals Dashboard Upgrade`.


## v170.65 / cycle 1489 — Admin System Health Dashboard

Status: DONE locally. `/admin/system` now has a read-only system health dashboard using `/health`, `/health/db` and `/health/runtime`. Logs `logs_72992801401.zip` were repaired. Next planned cycle: `1490 — Admin Logs / Events Dashboard`.


## 1492 — Synthetic Data Cleanup / Truth Hardening / v170.68 — DONE locally

- `/admin` no longer renders old `AdminInteractiveBankDashboard` synthetic-looking series.
- Added `AdminObservabilityTimeseriesDashboardRuntime` backed by real `/admin/observability/timeseries`.
- Fixed 1491 review notes: precise referral route match and EFHC amount gross/credit/debit clarity.
- Runtime synthetic preview remains forbidden outside sandbox/prototype layers.
- Current progress: `1401–1500` = `92 / 100`, remaining `8 / 100`; Dashboard `1455–1496` = `38 / 42`, remaining `4 / 42`.
- Next: `1493 — Visual Performance / Bundle Safety`.


## Cycle 1495 — Final Dashboard Visual Audit / Screenshot Proof — DONE v170.71

- Attached log failures from `logs_73325744958.zip` repaired.
- Public dashboard locale key parity across 13 active locales confirmed.
- Dashboard localization placeholder prefixes are blocked by guard.
- Static screenshot matrix prepared; browser screenshot capture is not claimed.
- Overall progress: `1401–1500` = `95 / 100`, remaining `5 / 100`.
- Dashboard progress: `1455–1496` = `41 / 42`, remaining `1 / 42`.
- Next safe cycle: `1496 — Dashboard Direction Handoff / Backlog Freeze`.


## 1505 — GitHub CI Rerun Proof / v170.81 — DONE locally

- HEAD input: `EFHC_Bot_v170_80_cycle_1504_grafana_pattern_map_completion.zip`.
- Log source: `logs_73728142603.zip`.
- Log verdict: GitHub CI rerun was red, not green.
- Repaired root causes from logs: ruff I001 import ordering, stale
  admin route module canon, stale chat legacy anchor, forbidden
  `frontend/tsconfig.tsbuildinfo`, stale route-count marker, `_main_`
  dunder false positive and route inventory freeze markdown count.
- Added active norm document: `docs/NORM/GITHUB_CI_RERUN_PROOF.md`.
- Added guard: `tests/architecture/test_github_ci_rerun_proof.py`.
- Runtime economy changed: no. Backend business logic changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- GitHub CI green for output archive is not claimed until a fresh rerun
  proves it.
- Current progress for `1501–1600`: done `5 / 100`, remaining
  `95 / 100`.
- Next safe planned cycle: `1506 — Release Audit Preparation`.


## 1506 — PACK-01 Withdraw Canon Clarification / v170.82 — DONE locally

- HEAD input: `EFHC_Bot_v170_81_cycle_1505_github_ci_rerun_proof.zip`.
- Task source copied into archive:
  `docs/audits/EFHC_PACK_01_WITHDRAW_CANON_CORRECTED_TZ.md`.
- Added withdraw V1 payout canon docs and regression guard.
- `PENDING -> PAID` after approved admin/operator payout is documented.
- `wallet_send_confirmed=true` is documented as valid V1 payout signal.
- `payout_ref` is documented as operational reference, not blockchain
  proof.
- Mandatory backend watcher proof and mandatory settlement FSM are not
  required by V1 canon.
- Runtime economy changed: no. Backend business logic changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Current progress for `1501–1600`: done `6 / 100`, remaining
  `94 / 100`.
- Next safe planned cycle: `1507 — PACK-02 Payment Intent Canon`.

## 1507 — PACK-02 TON Wallet Canon / Admin Payout Canon / v170.83 — DONE locally

- HEAD input: `EFHC_Bot_v170_82_cycle_1506_pack_01_withdraw_canon_clarification.zip`.
- Task source copied into archive:
  `docs/audits/EFHC_PACK_02_TON_WALLET_CANON_ADMIN_PAYOUT_CANON_TZ.md`.
- Added canonical TON address helper and canonical storage docs.
- `wallets_service.connect_wallet()` now persists canonical address.
- Watcher and EFHC deposit wallet lookup canonicalize valid TON addresses.
- Legacy memo/bind-request `wallet_binding_service.py` runtime file removed.
- Added admin payout canon: operator payout does not grant treasury/private
  funds access.
- Runtime economy changed: no. Withdraw PACK-01 canon changed: no.
- DB migrations changed: no. OpenAPI changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Current progress for `1501–1600`: done `7 / 100`, remaining
  `93 / 100`.
- Next safe planned cycle: `1508 — Payment Intent Canon`.

## 1512 — Admin Runtime P1 Fix / Admin Seams Cleanup / v170.88 — DONE locally

- HEAD input: `EFHC_Bot_v170_87_cycle_1511_github_ci_log_repair.zip`.
- Log source: `logs_74012116642.zip`.
- Input log verdict: green CI for v170.87.
- Closed `P1-WITHDRAW-REPAIR-TYPEERROR` by removing unsupported kwargs
  from withdraw hold repair call.
- Closed `P1-ADMIN-BONUS-DEBIT-TYPEERROR` by adding `meta` support to
  `debit_user_bonus_to_bank`.
- Added runtime regression tests for withdraw repair and admin BONUS
  debit.
- Added AST guard for admin money call-site/signature drift.
- Admin seam constants now cover all OpenAPI `/admin` paths.
- Existing raw admin page `apiRequest` calls are tracked as temporary
  migration debt, not silent drift.
- `/admin/shop/items/set-price` and `/admin/tasks/{task_id}` are
  documented as legacy/internal routes.
- Runtime economy changed: no. Business logic formulas changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Current progress for `1501–1600`: done `12 / 100`, remaining
  `88 / 100`.
- Next safe planned cycle: `1513`.

## 1513 — Fresh CI Proof / Admin Seams Full Migration / Runtime Tail Closure / v170.89 — DONE locally

- HEAD input: `EFHC_Bot_v170_88_cycle_1512_admin_runtime_fix_seams_cleanup.zip`.
- Log source: `logs_74025005532.zip`.
- Input log verdict: red CI for v170.88; ruff and pytest failed.
- Repaired ruff E402/I001 in admin runtime tests.
- Repaired pytest collection path by lazy-loading `get_bot` in
  `outcome_service` and exporting `router` from the historical
  `admin__main__handlers` wrapper.
- Completed admin frontend seam migration: raw admin `apiRequest` in admin
  pages is now `0`.
- `adminSeams.ts` has `59 / 59` OpenAPI admin path coverage and now exports
  `adminApiRequest()` plus `adminPath()`.
- P3 orphan routes are finalized as documented legacy/internal.
- Fresh GitHub CI green for output archive is not claimed until a new rerun
  proves it.
- Runtime economy changed: no. EFHC formulas changed: no.
- CI/workflows/dependencies/lock files changed: no.
- Current progress for `1501–1600`: done `13 / 100`, remaining
  `87 / 100`.
- Next safe planned cycle: `1514 — Admin UX QA / Visual Regression / Full Button Click Proof`.

## 1516 — DB Drift Closure / VIP-NFT TonConnect Sync Repair / v170.92 — DONE locally

- HEAD input: `EFHC_Bot_v170_91_cycle_1515_fresh_ci_rerun_visual_prep.zip`.
- User clarified the DB drift closure task as current cycle `1516`.
- Closed locally: `P1-VIP-NFT-SYNC-BROKEN-FOR-TONCONNECT-USERS`.
- `NftCheckService` now resolves wallets through active `wallet_bindings` first and `users.ton_wallet` only as legacy fallback.
- `/v1/me` no longer blocks stale VIP refresh only because `users.ton_wallet` is empty.
- Batch NFT/VIP discovery includes TonConnect `wallet_bindings` users and legacy wallet users without duplicates.
- `bonus_awards` is documented as legacy/dead code and guarded/no-op or fail-closed.
- `withdraw_requests.amount` precision drift closed with `Numeric(30,8)` and existing-schema repair.
- Deprecated `withdrawals` constraint-name drift documented as legacy cosmetic drift.
- Runtime economy changed: no. VIP formula changed: no. TonConnect canon weakened: no.
- GitHub CI green, full pytest green, browser proof, live TonConnect proof and release-ready are not claimed.
- Current progress for `1501–1600`: done `16 / 100`, remaining `84 / 100`.
- Next safe planned cycle: `1517 — Frontend Buttons / API / i18n Drift Audit`.

## 1517 — Frontend Buttons / API / i18n Drift Audit / v170.93 — DONE locally

- HEAD input: `EFHC_Bot_v170_92_cycle_1516_db_drift_closure_vip_nft_sync_repair.zip`.
- Closed static frontend/API/i18n audit drift findings.
- Admin feature/components now route admin API calls through `adminSeams.ts` helpers.
- Node i18n audit scripts use valid `__dirname` and run locally.
- `npm audit --audit-level=high` is clean after lock repair.
- Browser proof, full button-click proof, GitHub CI green and release-ready were not claimed.
- Current progress for `1501–1600`: done `17 / 100`, remaining `83 / 100`.
- Next safe planned cycle: `1518 — Browser/Admin Visual Capture / Button-click Proof Execution`.

## 1518 — Browser/Admin Visual Capture / Button-click Proof Execution / v170.94 — DONE locally

- HEAD input: `EFHC_Bot_v170_93_cycle_1517_frontend_buttons_api_i18n_drift_audit.zip`.
- Produced local browser screenshot proof for 7 admin core routes using Playwright + system Chromium.
- Produced local admin hub navigation proof for 6 core links from `/admin`.
- Added `ops/frontend/admin_visual_button_click_proof.py` as reusable local proof harness.
- Added system Chromium fallback for local Playwright e2e fixtures.
- Added e2e-only TonConnect restore-disable switch for browser proof runs.
- Hardened admin observability timeseries and admin users page response normalization based on browser-proof findings.
- Added guard `tests/architecture/test_browser_admin_visual_button_click_proof.py`.
- Exhaustive all-admin click proof, GitHub CI green, full pytest green, full frontend build green, live Telegram proof, real TonConnect proof and release-ready are not claimed.
- Current progress for `1501–1600`: done `18 / 100`, remaining `82 / 100`.
- Next safe planned cycle: `1519 — Fresh CI proof / New Audit Intake Gate`.

## 1519 — Fresh CI proof / red-log repair / v170.95 — DONE locally

- HEAD input: `EFHC_Bot_v170_94_cycle_1518_browser_admin_visual_capture_button_click_proof.zip`.
- Log source: `logs_74249190312.zip`.
- Input CI log was red: pytest and frontend gate failed.
- Repaired stale ORM table counts, package-lock registry marker,
  line72 findings, KERNEL cycle-label hygiene, withdraw/bonus legacy
  guard drift and browser proof mock generation-rate literals.
- Output GitHub CI green is not claimed until a fresh rerun proves it.
- Current progress for `1501–1600`: done `19 / 100`, remaining
  `81 / 100`.
- Next safe planned cycle: `1520 — New Audit Intake Gate`.

## 1520 — Frontend i18n Closure / Public Visual Proof / v170.96 — DONE locally

- HEAD input: `EFHC_Bot_v170_95_cycle_1519_fresh_ci_log_repair.zip`.
- Closed `P2-I18N-PUBLIC-KEYS-MISSING` locally.
- Added 37 used i18n keys to all 13 locales.
- Locale parity is `1434 / 1434`, missing used keys are `0`,
  empty values are `0`.
- Closed the currently reproducible UK locale Russian-tail marker.
- Hardened TonConnect sandbox/e2e failure handling without disabling
  production TonConnect by default.
- Admin visual runtime guard passed locally for `7 / 7` core admin routes.
- Public browser proof passed locally for `11 / 11` core public routes.
- GitHub CI green, full pytest green, full frontend build green, live
  Telegram proof, real TonConnect proof and release-ready are not claimed.
- Current progress for `1501–1600`: done `20 / 100`, remaining
  `80 / 100`.
- Next safe planned cycle: `1521 — Live Telegram / Real TonConnect / Release Readiness Proof`.



## 1562 — Browser Shop checkout / compact WebApp / v171.37 — DONE locally

- Input HEAD: `EFHC_Bot_v171_36.zip`.
- HUB now contains one neutral `Пополнение` action.
- Browser Shop supports TON/GRAM and USDT checkout contours.
- Web and Telegram linking preserve token, SKU and method on return.
- Payment TTL comes from backend `expires_at`.
- Status polling uses React Query and stops on terminal state.
- Energy and six-cell navigation received compact visual repair.
- Controlled browser screenshots are preserved in the archive.
- Live payments, live Telegram and fresh GitHub CI are not claimed.
- Current progress for `1501–1600`: done `62 / 100`, remaining
  `38 / 100`.
- Next cycle: `1563 — TonConnect restore, TonProof and transaction UX`.


## 1562 repeat — guarded HUB/Energy restoration / v171.38 — DONE locally

- Input HEAD: `EFHC_Bot_v171_37.zip`.
- Browser Shop TON/GRAM and USDT linking/TTL/polling proof repeated.
- Restored the guarded EFHC VIP NFT HUB action.
- Restored current named Energy levels.
- Removed Wallet balances and Exchange actions from Energy.
- Rebuilt six bottom navigation cells as wide rounded rectangles.
- Added an audit of guards inverted without direct user permission.
- Current progress for `1501–1600`: done `62 / 100`, remaining
  `38 / 100`.
- Next cycle: `1563 — TonConnect restore, TonProof and transaction UX`.

## 1564 — Admin Panel MVP / v171.40 — DONE locally

- Input HEAD: `EFHC_Bot_v171_39.zip`.
- Completed the full protected Admin launcher and 17 route surfaces.
- Controlled Chromium proof: 17/17 routes and 12/12 required DOM clicks.
- Restored persistent VIP and Active header statuses.
- Added an active public-copy guard for all 13 locales.
- Replaced unrelated Admin launcher emoji with one SVG icon system.
- Real production DB mutations, live Telegram and fresh GitHub CI are not claimed.
- Current progress for `1501–1600`: done `64 / 100`, remaining `36 / 100`.
- Next cycle: `1565 — Full frontend/API/business/DB linkage matrix`.


## 1565 — Complete function linkage matrix / v171.41 — DONE locally

- Input HEAD: `EFHC_Bot_v171_40.zip`.
- Verified 81 active public and Admin actions end to end in source.
- Public actions: 38; Admin actions: 43; partial actions: 0.
- Removed all active direct UI transport bypasses.
- Added shared Admin React Query/service/DTO ownership.
- Added Shop launcher, skins, referrals and TonConnect boundaries.
- Rebalanced the Global Header and removed the VIP crown.
- Current Admin browser proof: 17 routes and 12 DOM clicks.
- Real PostgreSQL mutation and concurrency proof is not claimed.
- Current progress for `1501–1600`: done `65 / 100`, remaining
  `35 / 100`.
- Next cycle: `1566 — PostgreSQL atomicity, concurrency and restore`.

## 1566 — PostgreSQL atomicity, concurrency and restore / v171.42 — DONE locally

- Input HEAD: `EFHC_Bot_v171_41.zip`.
- Fresh real PostgreSQL 18.1 migration reached Alembic `0001`.
- Canonical schemas: `efhc_core`, `efhc_admin`; schema tables: `45`.
- Injected post-debit failure proved request, balance and ledger rollback.
- PostgreSQL focused suite: `37 passed`, `0 failed`.
- `pg_dump` custom backup restored into a separate database.
- Source and restore catalog/control-data fingerprints matched.
- Supplied CI-log ruff and missing `requests` failures were repaired.
- Fresh visual proof: 12 public routes, 17 Admin routes and 12 clicks.
- Production PostgreSQL, PITR, failover and fresh GitHub CI are not claimed.
- Current progress for `1501–1600`: done `66 / 100`, remaining
  `34 / 100`.
- Next cycle: `1568 — Observability, deployment and rollback readiness`.



## 1567 — Security, privacy, legal and abuse hardening / v171.43 — DONE locally

- Input HEAD: `EFHC_Bot_v171_42.zip`.
- Repaired all five exact pytest failures from `logs_80747596654.zip`.
- Updated Axios to exact `1.18.0`; local npm audit reports zero findings.
- Added API/browser security headers and configurable request-body limits.
- Removed raw DB exception disclosure and added recursive structured-log
  redaction.
- Fixed monetary rate-limit/idempotency matching for runtime `/api` paths.
- Added Privacy Policy and Terms in all 13 canonical languages.
- Added Profile and TonConnect manifest links to active legal surfaces.
- Fresh visual proof: 6 public cases, 7 selected Admin routes and one Admin
  Diagnostics DOM-click.
- Production security audit, fresh GitHub CI, live Telegram and real
  TonConnect are not claimed.
- Current progress for `1501–1600`: done `67 / 100`, remaining `33 / 100`.
- Next cycle: `1568 — Observability, deployment and rollback readiness`.

## 1568 — Observability, deployment and rollback / v171.44 — DONE locally

- Input HEAD: `EFHC_Bot_v171_43.zip`.
- Repaired supplied mypy, dependency-guard and line-length CI failures.
- Added request correlation, bounded metrics, safe deployment metadata and
  fail-closed readiness.
- Added immutable-digest Kubernetes contracts, probes, resource limits,
  TLS ingress and zero-unavailable rolling updates.
- Added environment-parity, provenance, rollback preflight and plan-only
  rollback drill tools plus operator runbooks.
- Implemented all 20 approved visual improvements.
- Fresh proof: 16 public cases, seven selected Admin routes, one Admin click
  and one redacted-log detail proof.
- Real staging, production rollout/rollback and fresh GitHub CI are not
  claimed.
- Current progress for `1501–1600`: done `68 / 100`, remaining `32 / 100`.
- Next cycle: `1569 — PWA, Telegram WebView, devices, WCAG and performance`.



## PWA, Telegram WebView, device, WCAG and performance QA

Completed locally for v171.45. Safe static/content caching, four-width visual proof, controlled Telegram/offline/focus/reduced-motion states and supplied-log repair are recorded. Production/live proof is not claimed.

## 1571 — Full regression and GitHub workflow normalization / v171.47 — DONE locally

- Input HEAD: `EFHC_Bot_v171_46.zip`.
- Supplied red pytest-log causes were repaired without deleting or skipping
  tests.
- Exact inventory: `2508` unique nodes, `2370 passed`, `138 skipped`, zero
  failed or omitted.
- Root and active GitHub workflows now use the same blocking gates and
  deterministic checkpoint/resume regression runner.
- All twelve requested optimization items were implemented.
- Production build generated 34 pages and passed 36/36 compressed budgets.
- Fresh visual proof: 15 public routes, 13 languages, 17 Admin routes,
  12 Admin clicks and 7 new cache/FAQ/offline/update cases.
- Fresh GitHub CI, production cache behavior, field metrics and live
  network boundaries are not claimed.
- Current progress for `1501–1600`: done `71 / 100`, remaining `29 / 100`.
- Next cycle: `1572 — Fresh GitHub rerun intake and release blocker triage`.


## 1573 — v171.53 transfer — INVALIDATED

- Input HEAD: `EFHC_Bot_v171_52.zip`.
- Useful UI/i18n/FAQ changes are preserved in `v171.54`.
- The `v171.53` transfer is invalid because control documents were stale and
  its PNG files were synthetic rather than browser captures.
- Cycle 1573 was not completed and must not advance to cycle 1574.
- Authoritative correction: the v171.54 section at the top of this document.
- Current range count remains `72 / 100` completed; cycle 1573 is active.

## 1580 — First-panel referral atomic wiring / v171.77 — DONE locally

- Input HEAD: `EFHC_Bot_v171_76.zip`.
- Both supplied v171.76 GitHub CI archives were green.
- Independent audit found the P0 missing caller for
  `on_user_first_panel_activation()`.
- First-panel debit, panel rows, referral activation and rewards now share one
  transaction and one rollback boundary.
- Added no-commit BONUS banking, source wiring, PostgreSQL full-flow,
  idempotency and failure rollback guards.
- Fresh exact-HEAD v171.77 GitHub CI remains required.

## 1583 — Referrals page Lvl and inline segments / v171.80 — DONE locally

- Input HEAD: `EFHC_Bot_v171_79.zip`.
- Preserved first-creation referral ownership and both monetary reward types.
- `/referrals` now contains next-Lvl progress, invite/share actions, inline
  Active/Inactive tabs and explicit Lvl 0–5 economics.
- Backend owns the complete level scale and cumulative reward calculation.
- Lvl 1 cumulative truth is `10 × 0.1 + 1 = 2 EFHC`.
- Fresh exact-HEAD GitHub CI and route-backed browser proof remain required.

## 1584 — Referral EFHCb full-cycle truth / v171.81 — DONE locally

- Input HEAD: `EFHC_Bot_v171_80.zip`.
- Corrected all referral monetary notation to bonus asset `EFHCb`.
- Exposed the previously hidden cumulative Lvl subtotal.
- Full cycle is fixed as `1 000 + 1 411 = 2 411 EFHCb`.
- Backend API, Referrals UI, 13 locales, FAQ SSOT and release acceptance share
  the same arithmetic.
- Fresh exact-HEAD GitHub CI and route-backed browser proof remain required.


## 1589 — Referral activation consolidation and runtime test depth / v171.86 — DONE locally

- Input HEAD: `EFHC_Bot_v171_85.zip`.
- Removed the second inline implementation of referral activation.
- One CRUD operation now owns row locking and the activation transition.
- Critical tests execute the actual onboarding → panel → reward flow.
- Real PostgreSQL Lvl 1 cumulative result is `2 EFHCb`.
- GitHub CI requires at least 24 integration tests and zero skips.
- Fresh exact-HEAD development/release CI remains required.
