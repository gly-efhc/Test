# Цикл 1619 — Telegram initData adapter и session issue

## Цель

Создать provider-neutral Telegram login flow, в котором Telegram
является способом подтверждения доступа, а не владельцем account data.

## Реализованный поток

1. `POST /api/auth/telegram/session` получает `X-Telegram-Init-Data`.
2. Канонический Telegram HMAC verifier проверяет подпись.
3. Adapter проверяет строгий raw boundary, TTL и future skew.
4. Результат преобразуется в `VerifiedIdentity(provider=telegram)`.
5. Transactional `IdentityResolver` разрешает существующую identity.
6. При отсутствии identity используется существующий legacy account по
   `tg_id` либо создаётся новый Telegram account и identity.
7. В той же транзакции выдаётся hashed server-side session.
8. Exact initData replay отклоняется через namespaced hash в
   `processed_external_events`.

## Инварианты

- один Telegram provider subject соответствует одному `global_id`;
- повторный вход открывает тот же account;
- `global_id` не становится domain owner;
- `global_id` не вычисляется из `global_id`;
- raw `initData` и raw session token не сохраняются;
- provider subject и `tg_id` отсутствуют в публичном response;
- auto-merge и финансовые mutations отсутствуют;
- legacy Telegram routes не переключаются;
- migration `0006` отсутствует.

## PostgreSQL evidence package

Подготовлено шесть tests: existing identity, legacy account adoption,
new account/session, repeat login, exact replay и concurrent first
login. Реальный PostgreSQL выполняет канонический GitHub CI.

## Exit

```text
Telegram provider не owner.
Повторный вход открывает тот же account.
Session выдаётся атомарно и хранится только как hash.
```

До fresh exact-HEAD CI статус цикла — `PACKAGE_PREPARED`.
