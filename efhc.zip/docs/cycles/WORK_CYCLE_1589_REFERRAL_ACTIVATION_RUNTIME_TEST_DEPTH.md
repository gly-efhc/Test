# WORK CYCLE 1589 — REFERRAL ACTIVATION CONSOLIDATION AND RUNTIME TEST DEPTH

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED.
Version: `v171.86`.
Input HEAD: `EFHC_Bot_v171_85.zip`.

## Objective

Execute `TZ_full_referral_consolidation_and_tests.md` against the exact v171.85
runtime, preserving stronger existing PostgreSQL infrastructure while removing
remaining paper-test and duplicate-implementation defects.

## Audit decisions

- The proposed per-TG cleanup fixture was rejected because the current isolated
  CI database plus Alembic and per-test `TRUNCATE ... CASCADE` is stronger; the
  proposed SQL also referenced a nonexistent
  `referral_bonus_ledger.inviter_global_id` column.
- Existing PostgreSQL tests were retained, but critical paths were strengthened
  where they bypassed production onboarding.
- The DB self-referral constraint and runtime test remain as defence in depth.
- A literal 10 000 sequential purchase load test was not added to the blocking
  10-minute workflow. Runtime proof covers real E2E Lvl 1, all level thresholds,
  the 9 999/10 000/10 001 boundary, concurrency, rollback and idempotency.

## Runtime repair

- `referrals_crud.activate_referral()` is now the single owner of
  `SELECT ... FOR UPDATE` and the `NULL -> activated_at` transition.
- The operation accepts deterministic `activation_dt` and returns
  `ReferralActivationResult(link, activated_now)`.
- `referral_service.on_user_first_panel_activation()` no longer contains a
  duplicate inline update and rewards only the transaction that owns the
  transition.
- The panel lock-order invariant is documented next to the runtime call.
- CRUD health-check naming now states honestly that it verifies symbol presence,
  not production wiring.

## Test/CI repair

- The first-panel reward/replay test now executes real inviter onboarding,
  referral-code creation, invitee onboarding, funding, panel purchase and DB
  assertions.
- Rollback and parallel first-panel tests also use the real attribution path.
- Added deterministic activation-transition proof.
- Added ten-referral E2E proof: `10 × 0.1 + 1 = 2 EFHCb` in real PostgreSQL.
- Removed the arithmetic-only `2 411` function from the integration module;
  full-cycle constants remain protected in dedicated economy/architecture tests.
- GitHub CI writes JUnit evidence and fails unless at least 24 integration tests
  are collected with zero failures, errors or skips.
- Missing DB URLs or SQLAlchemy dependencies fail in CI instead of silently
  skipping the integration suite.

## Unchanged canon

No change to `1 EFHC = 1 kWh`, referral thresholds, 2 411 EFHCb full-cycle
economics, 13 locales, UI, API routes, database schema, Alembic head, 44-table
contract, WalletProvider or production deployment architecture.
## Validation evidence

- deterministic regression inventory: `2667` unique nodes;
- result: `2522 passed`, `145 skipped`, `0 failed`, `0 omitted`;
- targeted final repair pack: `34 passed`;
- PostgreSQL integration inventory: `24` tests;
- local environment result without PostgreSQL: `24 skipped` and not accepted as
  runtime proof;
- simulated GitHub Actions without database variables: fail-closed error;
- Canon Guard, workflow parity and Python compilation: PASS;
- standalone release acceptance: `12 passed, 1 skipped`;
- fresh exact-HEAD GitHub Actions remains mandatory.

