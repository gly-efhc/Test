# EFHC — ЦИКЛЫ 1701–1800
Статус: канонический диапазонный документ. Промежуточные файлы циклов не создаются.

Active authority: `docs/PLANS/WORK_PLAN_1693-1709.md`.
В этом диапазоне утверждены циклы 1701–1709. Циклы 1708–1709 добавлены
прямым решением пользователя как post-migration очистка aliases. Циклы
1710–1800 не утверждены и не имеют scope.

---

# ACTIVE PLAN ENTRIES

## 1701 — Identity inventory burn-down

Построчно закрыть `OPEN_REVIEW`, `OPEN_CONFIRMED`, `REVIEW_REQUIRED`.
Не улучшать цифры переклассификацией реальных нарушений.  
**Критерий:** actionable queue сведена к нулю либо только к отдельно утверждённым
provider boundaries с доказанным основанием.

### Фактически выполнено — v173.20

- Operator Kernel: `ci_logs_repair_or_verification -> ci_log_exact_failure_repair`.
- GitHub CI `84794235500`, SHA `de6ba0deb59756a4ba0c119600cc5fea8d9a5102`: подтверждены Ruff UP017 и два pytest failures; все три причины исправлены.
- Identity inventory: `69 review/actionable -> 0`; финальный scanner: `2381 total / 2381 allowed-or-preserved / 0 actionable`.
- Реальные drifts исправлены в admin visual API mocks, visual bootstrap calls, Operator Kernel authority и Healer active wording.
- Создан exact review registry `ops/identity/tg_id_review_dispositions.json`: 58 reviewed entries, broad patterns запрещены, ключ `file + line + column + token + fragment SHA-256`.
- `OPEN_CONFIRMED=0`, `OPEN_REVIEW=0`, `REVIEW_REQUIRED=0`.
- Provider runtime baseline сохранён: `97 files / 943 occurrences`, `business_owner_tg_id=0`, semantic mix `0`.
- Full pytest/CI/frontend build локально не запускались; следующий exact-head GitHub CI обязателен.

## 1702 — Multi-provider resolution hardening

Telegram/TON и общий resolver: uniqueness, collision, linking, conflict fail-closed,
provider-independent session owner.  
**Критерий:** каждая `provider + subject` разрешается ровно в один `global_id`.

### Фактически выполнено — v173.21

- Operator Kernel: `ci_logs_repair_or_verification` + route `transactional_identity_resolver`; bounded context по Telegram/TON/general resolver.
- GitHub CI `84797264635`, SHA `02667638d2b423fbc733a8e32a88b44996a3ba6e`: единственный pytest failure исправлен переименованием трёх test-функций на русский без изменения test semantics.
- `AuthProvider` приведён к current canon: добавлен Discord; удалены неутверждённые `microsoft`, `email`, `phone`; `mock` сохранён только как test-only provider.
- Синхронизированы provider registry/auth context/OpenAPI contracts; неизвестные `microsoft/email/phone` теперь проверяются как fail-closed.
- Resolver contract усилен: identity key `(provider, provider_tenant, provider_subject)`, one-pair-one-global, разные providers с одинаковым subject не смешиваются, automatic merge запрещён, session owner только `global_id`.
- Provider-registry guard исправлен под действующий Alembic canon: единственный head/revision `0001`, без возврата `0002`.
- Добавлен fail-closed `check_multi_provider_resolution_hardening.py` и PostgreSQL tests для same-subject/different-provider, duplicate collision, TON→existing Telegram account linking и conflicting TON identity/binding ownership. PostgreSQL integration локально не запускался.
- Test provider registry уменьшен `450 -> 441`, business-selector violations `0`.
- Identity inventory: `2372 total / 0 actionable`; exact review dispositions `59`, broad allowlist отсутствует.
- Provider runtime boundary: `97 files / 943 occurrences`, `business_owner_tg_id=0`, semantic mix `0`.
- Full pytest/CI/frontend build/PostgreSQL integration локально не запускались; следующий exact-head GitHub CI обязателен.

### Корректирующее продолжение 1702 — v173.22

- По прямому решению пользователя исправлена несогласованная в v173.21 provider wire naming: production provider names теперь `telegram`, `ton`, `google`, `apple`, `facebook`, `discord`, `github`; `mock` остаётся test-only.
- Временная рабочая alias-map использована только для контролируемого перехода `ton_wallet -> ton`, `TON_WALLET -> TON`, `ton_wallet.login -> ton.login`; после перевода consumers runtime alias удалён и exact parser его отклоняет fail-closed.
- `users.ton_wallet`, Admin wallet field, TON wallet config и wallet adapter names не переименовывались: это не auth-provider identifiers.
- Синхронизированы backend enum/routes/schemas, provider contracts, TON login/proof contracts, OpenAPI generated schema, frontend TON auth seam, visual/provider tooling и tests.
- Сужены stale alias exemptions в architecture tests; добавлен guard canonical provider wire names без retired alias.
- Fresh GitHub CI `84803385157`, SHA `1eb8de01a8329e924deac679908c3a085c2be14c`: исправлены два Ruff I001 и один pytest failure exact review-disposition coordinates.
- Exact identity review registry после сдвигов строк пересогласован только по прежнему exact fragment SHA; добавлен один отрицательный guard disposition. Итог: `2374 total / 0 actionable`, exact dispositions `60`.
- Targeted provider/resolver batch: `93 passed`; полный pytest/CI/frontend build локально не запускались.
- В cycle 1705 добавлена только финальная проверка отсутствия retired provider/identity aliases; отдельный новый цикл не создавался.

## 1703 — Security and audit identity

Session/auth context, privileged actions, audit actor, privacy/minimization.
Provider subject не используется как внутренний audit owner.  
**Критерий:** privileged/audit ownership = `global_id` end-to-end.

## 1704 — Release, documents and immutable history guards

Cycles/chats/reports archive, numbered report cadence, Operator Kernel routes,
file_map и RELEASE exclusion.  
**Критерий:** numbered reports без gaps; artifacts не входят в active runtime/RELEASE.

## 1705 — Cross-layer consistency

Проверить `signature -> callers -> DTO -> ORM -> SQL -> routes -> frontend -> tests
-> guards`, а также Development/RELEASE parity.  
**Критерий:** отсутствие identity drift между слоями.

Дополнительная финальная проверка: отсутствие retired provider/identity aliases после безопасной частичной очистки 1702.

## 1706 — Exact-head CI burn-down

Исправить только фактические failures свежего GitHub exact-head CI, без возврата
legacy architecture и без повышения baseline.  
**Критерий:** новый exact-head run не содержит причинных identity failures.

## 1707 — Qualification milestone

Финальная доказательная матрица.  
**Критерий завершения identity migration:** одновременно
`business_owner_tg_id = 0`, actionable identity queue закрыта, PostgreSQL `0001`
доказан, active tests/docs/guards соответствуют канону и exact-head GitHub CI
зелёный. Без этого статус остаётся `EXACT_HEAD_CI_REQUIRED`.

---

## 1708 — Runtime alias cleanup

После основной migration/qualification провести точный inventory active runtime
aliases, перевести callers на canonical contracts и удалить безопасные alias
definitions только после доказанного отсутствия потребителей.
**Критерий:** retired provider/identity/owner aliases в active runtime = 0.

## 1709 — Alias cleanup qualification

Удалить остаточные alias-exemptions из tests/guards/tooling/generated contracts и
active documents; доказать отсутствие retired aliases end-to-end и подтвердить
результат новым exact-head GitHub CI.
**Критерий:** retired aliases = 0 во всех active layers; exact-head CI после
cleanup зелёный.

## 1710–1800 — НЕ ЗАПЛАНИРОВАНО

Циклы 1710–1800 не утверждены и не имеют scope, порядка или критериев
завершения. Новый план может появиться только по прямому решению пользователя.


### Corrective continuation 1702 — TON provider subject canon sync (v173.23)

По прямому утверждению пользователя окончательно закреплено:
`provider=ton`, `ton_wallet_id` = адрес TON-кошелька. Отдельного числового TON
provider ID нет. Первый подтверждённый вход по новому адресу создаёт новый
`global_id`; повторный вход использует существующую связь; collision завершается
fail closed. Active CANON/SSOT/Kernel/contracts/runtime/API/frontend/tests/guards
синхронизированы. `ton_address` удалено только как provider-subject alias;
технические address concepts (`app.lib.ton_address`, `dest_ton_address`,
`wallet_bindings.wallet_address`, legacy `users.ton_wallet`) сохранены по их
реальной семантике.

### Финальная синхронизация Operator Kernel после TON subject canon — v173.23

- После создания первого immutable отчёта v173.23 финальная проверка Kernel выявила stale active-authority wording: исторический блок периода 1598 назывался «текущей границей» и содержал superseded Alembic `0002`.
- Блок сохранён только как история, явно помечен `HISTORICAL / SUPERSEDED` и снабжён ссылками на текущие `GLOBAL_IDENTITY_SSOT`, runtime NORM и single-head `0001` canon.
- `EFHC_OPERATOR_KERNEL_ROUTE_MAP.md` и `EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md` актуализированы на `v173.23 / corrective cycle 1702`; удалены active ссылки на ранее удалённый `docs/history` и obsolete test-archive dependency.
- Operator Kernel file map и bounded context capsule пересобраны после финальной структуры; capsule теперь извлекает текущий TON lock, а не superseded migration wording.
- Immutable `reports_02219` не переписывался; финальная Kernel-коррекция зарегистрирована следующим numbered report.

### Корректирующее продолжение 1702 по fresh CI — v173.24

- Operator Kernel использовал exact CI repair route и active identity authority.
- GitHub CI `84824576549`, SHA `430a4f741d16bc3226f88dd61d079f6743280624`: подтверждены 3 Ruff и 3 pytest failures.
- Исправлены import ordering в `backend/app/identity/__init__.py`, два F841 в `tests/test_no_banned_identifiers.py`, русскоязычная policy-строка `CONTRIBUTING.md`, версия test `tg_id` registry и TON integration caller `proof.provider_subject -> proof.ton_wallet_id`.
- Утверждённый TON canon `provider=ton`, `ton_wallet_id=адрес кошелька` не откатывался.
- По прямому решению пользователя active plan расширен циклами 1708–1709: runtime alias cleanup и последующая qualification alias cleanup. Циклы 1710–1800 остаются незапланированными.
- Полный локальный pytest/CI/frontend build не запускались; исправления fresh CI требуют следующего exact-head GitHub CI.

### Фактически выполнено — цикл 1703 Security and audit identity, v173.24

- Проверен Admin Bank: `admin_bank_service.py`, `admin_routes.py` и `frontend/src/pages/admin/bank.tsx` не менялись между v173.21/v173.22/v173.23; financial request/operations используют `global_id`. Регресс `global_id -> tg_id` в financial owner не подтверждён.
- Найден и исправлен соседний security-tail: legacy `_is_bank_admin()` использовал JWT `tg_id` как privileged selector. Теперь privileged JWT требует роль ADMIN + canonical `global_id`; provider subject не является privileged owner.
- `require_admin()` больше не переносит `context.tg_id` в privileged dependency context; admin session содержит canonical `global_id` и server-side admin flag.
- `AdminActionLog.actor_global_id` и все проверенные `AdminLogger.write` используют canonical `global_id`; runtime `granted_by_tg_id` не используется за пределами legacy model/storage compatibility.
- Новые Hub/Web-Profile signed handoff tokens содержат только `global_id`; Telegram subject остаётся delivery/legacy-resolution boundary и не включается в новые owner claims.
- Raw provider subjects удалены из application logs; auth diagnostics redaction строит provider-specific sensitive names из единого canonical subject-field registry.
- Добавлены `ops/identity/check_security_audit_identity.py` и `tests/architecture/test_security_audit_identity.py`.
- Test `tg_id` registry: 442 зарегистрированных provider/test occurrences, business-selector violations 0.
- Identity inventory: 2353 occurrences, actionable/review 0, exact dispositions 60.
- Provider runtime boundary уменьшен `97 files / 943 max -> 95 files / 901 occurrences`; `business_owner_tg_id=0`, semantic mix 0. Baseline только уменьшен.
- Targeted batch после основных исправлений: 28 PASS / 1 language-policy failure; после исправления повторён только упавший тест — PASS. После refactor canonical redaction registry повторены только непосредственно затронутые tests — 5 PASS.
- PostgreSQL integration failure из fresh CI исправлен по коду, но PostgreSQL integration локально не запускался.
- Следующий цикл: 1704. Оставшийся утверждённый диапазон: 1704–1709 (6 циклов).

### Финальная Kernel/inventory синхронизация 1703 — v173.24

После финального `Operator Kernel refresh` file map вырос до 4380 файлов, а identity inventory — с 2353 до 2358 token occurrences из-за обновлённого active Kernel/evidence контекста. Одна строка canonical identity registry сохранила тот же exact fragment SHA, но сместила координату; disposition перепривязан только по exact fragment. Финальное состояние: `2358 total / 0 actionable`, dispositions `60`. Повторён только непосредственно затронутый fail-closed disposition test — PASS. Предыдущий immutable report не переписывался.


### Фактически выполнено — цикл 1705 Cross-layer consistency, v173.25

Статус порядка: цикл 1705 выполнен по прямому указанию пользователя **до**
незавершённого цикла 1704. Цикл 1704 не объявляется выполненным и остаётся
следующим обязательным pending scope. Scope циклов 1706–1709 не переносился.

Подтверждено/исправлено:

- fresh GitHub CI `84832679011`, SHA `abd2c623e66f90a0570a4dafbfb956163d524a8e`: F821 в provider registry, Ruff SIM300, stale AuthContext architecture expectation и stale test-guard cycle expectation;
- cross-layer chain `signature -> callers -> DTO -> ORM -> SQL -> routes -> frontend -> tests -> guards` синхронизирована по canonical identity;
- Admin privilege owner — `global_id`; provider subject не предоставляет admin rights;
- `require_admin` использует server-side session и RBAC resolve по `global_id`; whitelist без явной роли fail-closed;
- удалён автоматический fallback, искусственно назначавший SuperAdmin withdrawal-действиям;
- добавлен protected `GET /admin/access`; frontend показывает admin entry только после server-side ответа; public Telegram allowlist больше не является runtime authority;
- provider boundary уменьшен с `95 files / 901 occurrences` до `93 / 889`, `business_owner_tg_id = 0`, semantic mix = 0;
- identity inventory: `2353 total / 0 actionable-review`; test provider registry: `442 / 0 business-selector violations`;
- новый fail-closed `check_cross_layer_consistency.py`; retired provider aliases не возвращены.

Targeted verification: один связанный pytest batch — `26 passed / 2 skipped`; active-test-surface PASS; provider-boundary PASS; identity inventory actionable `0`. Полный локальный pytest/CI/frontend build не запускались.

### Фактически выполнено — цикл 1704 Release, documents and immutable history guards, v173.26

- Цикл 1704 закрыт после ранее выполненного вне очереди 1705; scope не переносился и не объявлялся завершённым задним числом.
- Корневой `АРТЕФАКТЫ` и `docs/history` отсутствуют в active HEAD и не должны воссоздаваться active tooling/guards.
- Canonical history остаётся в `docs/cycles`, `docs/chats`, `reports/numbered`; superseded bytes хранятся только во внешнем ARTIFACTS_HISTORY archive пользователя.
- Добавлен fail-closed `ops/reports/check_release_history_integrity.py`: проверяет 18 canonical cycle-range документов, cycle/chat/report manifests и SHA, непрерывность numbered reports, отсутствие positive active dependency на удалённый historical root, Kernel file-map и RELEASE exclusion.
- Active SSOT/NORM/Kernel/AI docs очищены от положительных ссылок на `docs/history`; provenance в immutable manifests не переписывается.
- RELEASE contract подтверждает отсутствие development-only `docs/`, `reports/`, `tests/`, `skills/`, `agents/`, `commands`, `hooks`, `references` и удалённого `АРТЕФАКТЫ` в production archive.
- Numbered report cadence продолжена; manifest cycle SHA обновляется только после законного изменения range-документа.
- Полный локальный pytest/CI не запускался; выполнены только связанные guards/tests.

### Корректирующее продолжение — цикл 1705 Cross-layer consistency, v173.26

- GitHub CI `84845837837`, SHA `02667638d2b423fbc733a8e32a88b44996a3ba6e`: подтверждены 2 Ruff и 6 pytest failures; исправлены только причинные расхождения.
- Frontend generated admin seam получил canonical `/admin/access`; admin client использует generated seam, а Chromium/session-first architecture expectations синхронизированы с server-side admin access.
- OpenAPI current contract содержит 128 paths / 133 operations; stale test expectation `127/132` исправлено без изменения API ради теста.
- Identity/test-layer guards читают фактический current cycle 1705, а не жёстко ожидают 1703.
- Telegram bot admin handlers больше не дают права по `ADMIN_TG_ID`: sender `tg_id` используется только как provider subject для resolution `telegram identity -> global_id`, после чего доступ проверяется через server-side RBAC.
- Web Admin остаётся provider-independent: session -> `global_id` -> `admin_whitelist.global_id` -> explicit RBAC role -> `/admin/access`.
- `ADMIN_TG_ID` не является источником admin privilege; legacy ENV/config surface остаётся кандидатом на утверждённую alias cleanup 1708–1709.
- Cross-layer chain и history/release guard синхронизированы; runtime ownership через `tg_id` не возвращался.
- Следующий цикл по утверждённому плану: 1706.

### Финальная provider-boundary/Kernel синхронизация 1705 — v173.26

После первичной фиксации корректирующего 1705 provider-boundary guard обнаружил, что промежуточный новый `admin_access.py` создавал новую Telegram surface, хотя девять старых handler surfaces уже были очищены. Новый allowlist entry не добавлялся: Telegram subject resolution перенесён в существующую canonical Telegram identity boundary, а `admin_access.py` оставлен без `tg_id` token и отвечает только за `global_id -> RBAC` orchestration. Девять stale handler baseline entries удалены. Финальный provider boundary: `84 files / 863 occurrences`, `business_owner_tg_id=0`, semantic mix `0`. После финального Operator Kernel refresh test registry = `442`, identity inventory = `2340 / actionable 0`. Предыдущий immutable report не переписывался; финальное состояние фиксируется отдельным numbered report.

### Фактически выполнено — цикл 1706 Exact-head CI burn-down, v173.27

- Operator Kernel использовал fresh exact-head CI evidence и active SSOT/CANON; полный локальный CI/pytest/frontend build не запускались.
- GitHub CI `84852823818`, SHA `1eaef85b1e36e0faa09b25380f0684561b850c5f`: все показанные gates, кроме Ruff и одного pytest, прошли. Ruff подтвердил 10 `I001` в Telegram admin handlers; pytest подтвердил один archive-filename hygiene defect в `README_RELEASE.md`.
- Все 10 import-order причин исправлены в указанных CI файлах; `README_RELEASE.md` очищен от запрещённой numbered-work-pass формулировки. Новое exact-head подтверждение требуется следующим GitHub CI.
- По дополнительному решению пользователя `global_id=1313131313` зарезервирован для SuperAdmin. Обычная registration allocation пропускает reserved ID; ORM/`0001` fail-closed запрещают обычную запись с этим ID без `meta.reserved_identity=superadmin`. Сам reserved ID не предоставляет admin rights: нужны active whitelist + explicit RBAC `superadmin`.
- Проверены admin/NFT boundaries: current RBAC использует `admin_whitelist.global_id` + `admin_role`; NFT/VIP (`is_vip`) не является admin credential. Публичного подтверждённого admin-management endpoint/CLI для назначения новых whitelist/role записей в current HEAD не найдено.
- Проверен custody boundary по active source/config examples: wallet mnemonic/private key/seed не найден; `SECRET_KEY` является application/JWT secret, а payout canon использует TonConnect и внешнюю подпись operator wallet. Этот вывод не утверждает содержимое внешней deployment environment.
- Центральный банк подтверждён как логический `BANK_EFHC` с единственным balance key `EFHC_MAIN` в `efhc_core.bank_balance`. Numeric `BANK_EFHC` ENV удалён. Банк идентифицируется только как `system_entity=BANK_EFHC` и не имеет user/provider/global_id alias.
- Identity inventory: `2341 total / 0 actionable`; test provider registry: `442 / 0 business-selector violations`; provider runtime baseline сохраняется `84 files / 863 occurrences`, `business_owner_tg_id=0`, semantic mix `0`.
- Targeted verification: один связанный batch дал `35 PASS / 1 stale current-state failure`; после актуализации current completed cycle повторён только этот упавший test — `1 PASS`. Изменённые Python-файлы: `27/27` syntax PASS. Ruff локально не запускался.
- Следующий цикл: 1707. После локального завершения 1706 остаются 1707–1709 (3 цикла).

### Corrective status recovery — цикл 1706, v173.28

- Recovery-аудит предыдущего оборванного чата не подтвердил отдельного code patch до handoff: подтверждены только анализ CI, admin/NFT boundary и custody findings; они уже присутствуют в v173.27.
- Технический patch set v173.27 сохраняется без отката.
- Исправлена статусная ошибка v173.27: локальная реализация patch set не равна закрытию цикла. Цикл 1706 остаётся **IN PROGRESS** до нового exact-head GitHub CI по patched HEAD.
- `1707` не начат. Pending по утверждённому плану, включая текущий: `1706–1709` = `4`.
- Immutable `reports_02229` не переписывается; его технические факты сохраняются как evidence, а ошибочная формулировка статуса исправляется новым numbered report.

### Exact-head CI follow-up + BANK/NFT evidence correction — цикл 1706, v173.29

- Operator Kernel: task type `ci_logs_repair_or_verification`, primary route `ci_log_exact_failure_repair`; bounded secondary read used for admin/NFT/bank evidence only.
- Fresh GitHub CI `84865747522`, SHA `6d5002fbce58579f2c09f28f60762a15184d4510`: pytest `1494 passed / 3 failed / 22 skipped`; flake8/Ruff/mypy/Bandit/compileall/Alembic/npm/frontend gates = exit `0`.
- Исправлены три подтверждённые причины: missing AI-laws reference в `TEST_GUARD_MANIFEST.md`, stale release marker в `frontend/scripts/budgets.mjs`, stale Admin release marker в `frontend/src/pages/admin/index.tsx`.
- Targeted rerun только трёх упавших tests: `3 passed`; полный локальный CI/pytest/frontend build не запускался.
- Проверена история admin NFT: ранний original-source действительно предусматривал `require_admin_or_nft_or_key`; поздний security-fix заменил `admin_nft_whitelist` на `efhc_admin.admin_whitelist`. Current runtime использует `global_id -> RBAC`; VIP NFT не является admin credential.
- Удалены 2 stale machine-index rows `admin_nft_whitelist` из `SSOT_RAW_SQL_USAGE.csv`, потому что соответствующего current runtime SQL в `backend/app/deps.py` нет.
- EFHC BANK runtime не менялся. Подтверждены `BANK_EFHC`, SSOT `efhc_core.bank_balance[key=EFHC_MAIN]`, paired mirror ledger semantics и отсутствие fixed numeric bank ID в archive. Strict double-entry redesign описан только как `NOT APPROVED / NOT IMPLEMENTED` proposal.
- Цикл 1706 остаётся `IN PROGRESS` до следующего exact-head GitHub CI; 1707 не начат; pending включая текущий: 1706–1709 = 4.


### Emergency stabilization override — цикл 1706, v173.30

По прямому решению пользователя обычный план сдвинут на **+5 циклов**. Циклы
`1706–1710` и создаваемые в них numbered reports предназначены только для аварийного
латания подтверждённых регрессов. Инициативные аудиты, полный локальный CI/full pytest,
полный frontend build и архитектурный cleanup в этом окне не являются задачей.

Новая очередь:

- `1706` — Emergency BANK repair.
- `1707` — Emergency Admin access repair.
- `1708` — Emergency economy repair.
- `1709` — Emergency regression reserve #4.
- `1710` — Emergency regression reserve #5.
- `1711` — перенесённый прежний `1706 Exact-head CI burn-down`.
- `1712` — перенесённый прежний `1707 Qualification milestone`.
- `1713` — перенесённый прежний `1708 Runtime alias cleanup`.
- `1714` — перенесённый прежний `1709 Alias cleanup qualification`.

#### BANK repair 1706

Утверждён banking identity:

```text
global_id     = NULL
system_entity = BANK_EFHC
tg_id         = NULL
```

`BANK_EFHC` больше не создаётся/не требуется как фиктивный user/provider owner. Единственная
истина баланса банка остаётся `efhc_core.bank_balance[key=EFHC_MAIN]`, стартовый seed
`5 000 000 EFHC`, отрицательный bank balance разрешён. Новые mirror rows используют
`system_entity=BANK_EFHC`; numeric bank aliases удалены из active runtime/config/0001.
External deposit получает settlement evidence в ledger metadata. Withdraw V1 не меняется:
после разрешённого payout action заявка считается `PAID` без mandatory backend blockchain
watcher proof. Mint/Burn сохранены только как аварийные admin reserve mechanisms.

Все 20 вопросов/ответов пользователя сохранены в
`docs/GENERAL/BANK_QUESTIONS_ANSWERS_REGISTRY.md`. Подробный current SSOT:
`docs/SSOT/BANK_CANON.md`.


#### Admin access repair + BANK cleanup 1707 — v173.31

Аварийный patch без CI/tests/build. Перед восстановлением Admin access дочищен BANK canon:
Numeric `BANK_EFHC` ENV, `LEGACY_BANK_TG_ID`, `bank_alias_tg_id`, numeric release preflight и legacy bank-read branches удалены из active code. Банковская ledger-сторона определяется только `system_entity=BANK_EFHC`; `global_id/tg_id` у неё NULL. Admin transfer API/UI получает explicit `system_entity`, а не угадывает банк по NULL owner.

Восстановлен исторический NFT-admin credential как provider-neutral `efhc_admin.admin_nft_whitelist.global_id`. Центральный `require_admin_or_nft_or_key` требует server-side session и после resolution `global_id` принимает обычный admin whitelist/RBAC либо active Admin-NFT whitelist. Старые header/SECRET_KEY bypass не возвращены. Цикл 1707 является emergency patch cycle; квалификация отложена.


#### Emergency economy repair 1708 — v173.32

Цикл выполнен как аварийное латание экономики без CI/tests/full build. Утверждённые коэффициенты не изменялись.

- `BANK_EFHC` остаётся обязательным контрагентом всех денежных начислений/списаний.
- Exchange: `kWh -> EFHCm` 1:1; Withdraw: только EFHCm, minimum 10.
- Referrals и Tasks/ADS: только EFHCb.
- Panels: 100 EFHC, списание EFHCb сначала, затем недостающая EFHCm; срок 180 дней; max 1000; BASE/VIP 0.00000692/0.00000741 kWh/s.
- Исправлен latent double-debit `orders_service._debit_user_bonus_first`: одна сумма теперь делится canonical bank helper, а не списывается полной суммой отдельно с bonus и main. Legacy shop write-block не снимался.
- User-facing functional denominations приведены к EFHCm/EFHCb; aggregate contexts сохраняют EFHC.
- Создан active `docs/SSOT/ECONOMY_CANON.md`.
- Следующий аварийный цикл: `1709 — Emergency regression reserve #4`.

#### Emergency tails + supplied CI repair 1709 — v173.33

Цикл 1709 использован по прямому решению пользователя для закрытия хвостов
1706–1708 и исправления только подтверждённых ошибок предоставленного GitHub CI
`84878523923` (checkout SHA
`ca8e5d490f1be8af7e77eeb9eba9bd38b95cba90`, пакет v173.32).

Подтверждённые самостоятельные причины CI и исправления:

- Alembic: stale identity guard ожидал `39` global-owner FK при фактических `41`
  в v173.32. После коррекции Admin NFT credential с `global_id` на
  `ton_wallet_id` один owner FK удалён, а `created_by_global_id` остаётся audit
  metadata; current expected count установлен `40`. Новое DB-подтверждение
  требуется следующим CI.
- Ruff: B904 в `backend/app/deps.py` исправлен явным exception chaining.
- Frontend TypeScript: локальный `AdminTaskTraceItem` синхронизирован с dashboard
  contract полем `system_entity`.
- Architecture tests: stale BANK mirror, idempotency quote-style и release seed
  expectations обновлены под фактический канон 1706–1708.
- Russian engineering language findings из CI исправлены в пяти указанных
  файлах; language checker повторно локально не запускался.
- `ECONOMY_CANON.md` очищен от терминов, запрещённых active canon guard.
- PostgreSQL `UndefinedTableError` в оставшихся integration tests не латался как
  отдельные дефекты: в этом run они возникли после abort `alembic upgrade head`.
  Их статус определит следующий GitHub CI.

Admin access corrected:

- обычный Admin list: active `efhc_admin.admin_whitelist.global_id` + explicit
  `admin_role`;
- резервный Admin NFT list: active
  `efhc_admin.admin_nft_whitelist.ton_wallet_id` + роль;
- central `require_admin_or_nft_or_key` получает canonical `global_id` только из
  server-side session; для Admin NFT находит active verified TON identity этого
  account и сопоставляет её `provider_subject` с `ton_wallet_id` NFT-list;
- `ton_wallet_id` остаётся provider credential и не становится business/admin
  owner; actor после успешного входа остаётся session `global_id`;
- Telegram/header/SECRET_KEY bypass и обычный VIP-флаг не дают admin access;
- отдельный формат/on-chain verifier «NFT key» не придумывался: такого контракта
  active sources не определяют.

Миграция `0001` для существующей pre-release schema добавляет `ton_wallet_id` в
старую Admin NFT table, backfill выполняется только из active verified TON
identity, unresolved active credential блокирует migration fail-closed, после
успешного backfill obsolete authorization-column `global_id` удаляется.

Полные локальные CI, pytest, frontend build и Alembic execution не запускались.
Квалификация v173.33 требует следующего GitHub CI. Следующий emergency cycle:
`1710` — резерв только под подтверждённую критическую дыру.

#### Emergency CI + Admin NFT key repair 1710 — v173.34

Operator Kernel выбрал маршрут `ci_log_exact_failure_repair`. Предоставленный
GitHub CI `84881845935` проверял checkout SHA
`0289cd1f14c11eeb72d1a907d9fd6be65561e876` на predecessor v173.33. Alembic,
Bandit, compileall, flake8, mypy и frontend build прошли; красными остались Ruff
и pytest (`9 failed, 1489 passed, 22 skipped, 1 warning`).

Исправлены только самостоятельные причины из лога:

- Ruff I001: import `resolve_canonical_ton_wallet_id` приведён к ожидаемому
  многострочному формату.
- Archive hygiene: `ARCHITECTURAL_LOCKS.md` зарегистрирован как root
  traceability-файл, потому что по назначению хранит numbered lock lineage.
- Russian engineering language: исправлены CI-указанные новые английские
  фрагменты `KERNEL.md` и комментарий `bank_balance_models.py`.
- Test `tg_id` registry пересоздан штатным генератором один раз: live и saved
  registered occurrences = `441`, business-selector violations = `0`.
- `TEST_GUARD_MANIFEST.json` синхронизируется с v173.34 / cycle 1710.
- Admin NFT больше не имеет `created_by_global_id` owner FK; `0001` и static
  PostgreSQL contract возвращены к ожидаемым `39` global-owner FK. Integration
  tests не ослаблялись.
- Три payment-intent mocks принимают новый `meta`, уже передаваемый production
  deposit reconciliation после BANK-канона.

По прямому уточнению пользователя interim Admin NFT-модель 1709 исправлена.
Источник резервного права — конкретный Admin NFT key из ENV внутри
`TON_NFT_COLLECTION`. `nft_check_service` использует тот же fetch активов, что и
VIP, вычисляет Admin NFT, материализует свежий derived state в
`efhc_admin.admin_nft_whitelist`; строка DB сама по себе права не выдаёт.
`require_admin_or_nft_or_key` требует server-side session, verified TON identity,
`source='env_nft'`, `nft_key`, active/non-revoked state, freshness TTL и
присутствие ключа в текущем ENV. Actor остаётся canonical session `global_id`.
Frontend уже показывает существующую Admin Panel кнопку по `GET /admin/access`;
отдельная UI-кнопка не создавалась. Создан `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.

Пять операционных параметров Admin NFT заданы пользователю отдельными вопросами
и ожидают подтверждения; v173.34 использует явно документированные переходные
параметры без выдачи SuperAdmin. Полные локальные CI/pytest/frontend build и
Alembic execution не запускались. Следующий источник квалификации — новый
exact-head GitHub CI.



#### Cycle 1710 continuation — user-confirmed Admin NFT IDs — v173.35

Пользователь окончательно закрыл пять pending-параметров Admin NFT. Канон
переведён с переходного key-контракта на exact NFT-item ID contract:

- единственное ENV-имя: `TON_ADMIN_NFT_IDS`;
- значение: точный TON NFT-item address;
- любой совпавший Admin NFT даёт полный обычный Admin access;
- достаточно Admin NFT на любом active verified TON wallet одного `global_id`;
- право следует за NFT: при обнаружении того же `nft_id` у нового wallet
  предыдущий active derived owner деактивируется, новый становится active;
- тот же штатный NFT/VIP refresh выполняет grant/revoke; отдельный live TON API
  запрос на каждый admin route не вводился; stale derived state ограничен TTL.

Runtime/config/tests/0001/active SSOT переведены на `TON_ADMIN_NFT_IDS` и
`nft_id`. Промежуточные ENV aliases удалены. Исторический report 02236 не
переписывался. Новый report 02237 фиксирует continuation. Локальные CI/pytest/
Ruff/Alembic/frontend build не запускались; qualification требует следующего
exact-head GitHub CI.

#### Cycle 1711 — Exact-head CI burn-down closed — v173.36

Предоставлен GitHub CI `84921131844`. Checkout SHA `ffdc369b3eaaf65eacbac48f31e7e7743458434e`. Проверенный `efhc.zip` имеет
размер `11846393` bytes и Git blob SHA-1 `9d729596849cd9c80eb6480acc92c04881fe7419`, полностью совпадающий с локальным
`EFHC_Bot_v173_35.zip`; exactness подтверждён byte-for-byte.

Все canonical gates завершились exit=0: Alembic, PostgreSQL preflight, flake8,
Ruff, Mypy, Bandit, compileall, pytest, npm ci и production frontend build.
Pytest: `1498 passed / 22 skipped / 1 warning`.

Подтверждённых ошибок для исправления не найдено. В цикле 1711 runtime, schema,
BANK, Admin/Admin NFT и Economy code не менялись. Цикл 1711 закрывает перенесённый
Exact-head CI burn-down. Следующий цикл — `1712 Qualification milestone`.

Пакет `v173.36` обновляет только текущие status/version/package документы и
служебные manifests после зелёного `v173.35`; отдельный exact-head claim для
байтов `v173.36` не делается до следующего GitHub CI.

### Global ID qualification milestone — цикл 1712

- GitHub CI `84923645231` проверил byte-exact `v173.36`, checkout `cb915ded036615efaec297689787a3a5053a36e0`, blob `7139f9e65515d4fd553fad0872710d72dc842336`.
- Все canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- `business_owner_tg_id=0`, actionable identity queue=0, semantic mix=0, PostgreSQL `0001` PASS.
- Ownership migration квалифицирована. Immutable report: `reports_02239`.

### Post-migration runtime alias cleanup — цикл 1713

- После qualification удалён переходный runtime слой: owner switches, hidden `tg_id` business routes, temporary migration-control/dual-write infrastructure, dead aliases/stubs/test façades/no-caller compatibility modules.
- Telegram/TON/stored-data compatibility сохранена только на доказуемых provider/external/history boundaries.
- Targeted static control changed files: parse PASS, deleted-module imports=0; удалено 5 retired routes.
- Patch package `v173.37` требует exact-head CI. Immutable report: `reports_02240`. Следующий цикл: `1714`.

### Cycle 1714 — supplied CI runtime repair + Admin preservation — v173.38

- GitHub CI `84937506938` проверил byte-exact `v173.37`: checkout `7bdda0368e67516759c26b97db50a5432f492537`, `efhc.zip` `11839937` bytes, Git blob SHA-1 `3f731d2951d17b06a996cba99488caca85645c6f`.
- Alembic/PostgreSQL/Bandit/compileall/frontend build PASS; red gates: flake8 critical, Ruff, Mypy, pytest collection.
- Исправлены подтверждённые production defects после 1713 cleanup: missing Telegram resolver in ADS, TonConnect proof builder, watcher confirmation result variables/type, payment reconciliation bank credit helper path, CI-reported unused imports/import blocks.
- Проверена сохранность Admin Panel: HTTP routes `63 -> 63`; после восстановления публичных Admin service symbols из exact-green v173.36 отсутствующих = `0`.
- Восстановлен ошибочно удалённый в 1713 protected Bonus Awards service/facade/contract block. Admin NFT/Admin list/BANK access contracts не переопределялись.
- По прямому указанию пользователя работа с test layer остановлена; test-файлы не изменены и локальные test/lint/type/build suites не запускались.
- Immutable report: `reports_02241__cycle_1714_ci_runtime_admin_function_recovery.md`.
- `v173.38` требует нового exact-head GitHub CI. Следующий цикл: `1715 — exact-head follow-up по новым подтверждённым runtime failures`; работа с test layer только по отдельному прямому разрешению пользователя.


### Cycle 1715 — exact-head CI Ruff + pytest collection repair — v173.39

- GitHub CI `84940689623` проверил exact `v173.38`: checkout `cd0bea87936db8f218290d25121e41d0ba784b3f`, archive size `11816383` bytes.
- Green gates: Alembic upgrade, PostgreSQL preflight, flake8 critical/full, Mypy, Bandit, compileall, npm ci, frontend production build.
- Failed gates: Ruff (`22` import-hygiene diagnostics) и pytest collection (`4` errors; test execution не началось).
- Ruff: в перечисленных CI production modules выполнен только import-order/import-placement patch; production business semantics не менялась.
- Pytest collection: изменены только четыре exact CI-failed test locations. Старые imports/expectations переведены на существующие canonical interfaces: `financial_owner.FinancialReadOwner`, `account_registration.normalize_referral_start_param`, `nonfinancial_owner.resolve_nonfinancial_read_owner(..., global_id=...)`, `idempotency_readthrough.choose_idempotency_key_with_history`.
- Transition-only `financial_read_switch`, `nonfinancial_read_switch`, `identity_migration_control` и test-only `idempotency_compat` production layer не восстанавливались, поскольку active post-migration CANON их запрещает. В integration referral test удалён только setup retired migration-control table, непосредственно связанный с упавшим stale transition contract.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guards не запускались. Новый HEAD не объявляется PASS.
- Immutable report: `reports_02242__cycle_1715_exact_head_ci_ruff_pytest_collection_repair.md`.
- Статус `v173.39`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий цикл: `1716 — exact-head CI follow-up`.


### Cycle 1716 — exact-head CI repair + function/Admin/routes/docs preservation audit — v173.40

- Input exact-head CI: `84942802763` on `v173.39`, checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`, archive size `12095859` bytes.
- GREEN supplied gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- FAILED: Ruff `3` I001; pytest `61 failed / 1307 passed / 22 skipped / 130 errors`.
- Confirmed mass setup cause: stale test fixtures referenced retired `efhc_core.identity_migration_control`; transition table/schema was not restored.
- Confirmed CI-failed test/source contracts were reconciled to current post-cutover global_id/idempotency/referral/NFT/watcher/withdraw/rank/security surfaces. No local verification run.
- Explicit additional user scope: historical comparison against `v171.89`; Admin function preservation audit; docs/page vs code audit; backend route/frontend linkage audit; Bonus Awards architecture audit; function catalog/control creation.
- Historical one-to-one backend symbol-name delta before recovery: `126`; Admin subset: `25`. Delta explicitly not equated to lost functionality.
- Restored only safe delegating compatibility entrypoints: startup, DB, decimal, ShopOrder, FSM, Admin bot main, scheduler context/errors/tick/maintenance, pure `RBAC.is_superadmin`. Legacy tg_id-owner Admin CRUD/migration compatibility was not rolled back.
- Bonus Awards: service/facade capability confirmed; dedicated Bonus Admin route/page not confirmed in either `v171.89` or current HEAD.
- Static no-frontend-caller Admin APIs are preserved, not deleted. Referral ranking frontend mode is recorded as recovery candidate because backend referral ranking routes remain present but current Ranks UI linkage was not found.
- Created active `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`, audit `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`, registry `contracts/application_function_surface_v1.json`, CI control `tests/architecture/test_application_function_surface_manifest.py` (created, **not run locally**).
- Immutable report: `reports_02243__cycle_1716_ci_function_preservation_audit.md`.
- Status `v173.40`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Next cycle: `1717`.

### Cycle 1717 — exact-head CI follow-up + extended function preservation audit — v173.41

- Input exact-head CI: `84948550953` on `v173.40`, checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`, archive size `12124946` bytes.
- GREEN supplied gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- FAILED: Ruff `1` I001; pytest `45 failed / 1456 passed / 22 skipped`.
- Исправлены только подтверждённые CI causes. Final-cutover referral/account/Telegram/TON expectations синхронизированы с active `global_id` CANON; retired migration-control/tg-owned runtime не возвращён.
- Восстановлен подтверждённо потерянный payment compatibility surface: `wallets_service.credit_user_from_bank`, `_confirm_payment_intent`, watcher/reconciliation injection seam и совместимые status constants. External-shop reason сокращён до размера DB-поля.
- По прямому дополнительному ТЗ продолжен static historical audit against `v171.89`: восстановлены безопасные `AdminService/AdminUsersService.credit_bonus_efhc` и `credit_regular_efhc`, а также NFT-maintenance facade `nft_requests_service` без возврата старого `tg_id` ownership.
- Frontend page paths: `38/38` совпадают с `v171.89`; исчезнувших page-файлов статически не найдено. OpenAPI: historical `125 paths / 130 ops`, current `127 paths / 132 ops`.
- Bonus Awards: отдельная historical/current Admin page/route не подтверждена; legacy docs описывают таблицу как неактивную. Compatibility service/facade surfaces сохранены.
- Method-aware audit зафиксировал `11` Admin HTTP operations без найденного прямого frontend caller; они маркированы `PRESERVE_NO_UI_CALLER`, а не удалены. Referral leaderboard UI и `/shopfront/profile` зафиксированы как integration/recovery candidates без самовольного восстановления.
- Fail-closed function registry расширен до `259` critical Python symbols / `44` modules / `14` required files; защищены полный public `AdminService`, Admin bot handlers, Admin NFT chain, payment/NFT compatibility markers. Расширенный control test локально не запускался.
- Номер immutable отчёта: `reports_02244`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guards не запускались.
- Статус `v173.41`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий цикл: `1718`.
