# Рабочий цикл 1602 — канонизация Global ID

Исходный HEAD: `EFHC_Bot_v171_98.zip`.
Целевой HEAD: `EFHC_Bot_v171_99.zip`.

## Цель

Закрепить `global_id` как единственный главный идентификатор аккаунта
EFHC, не создавая новую физическую колонку и не выполняя backfill,
read switch либо изменение финансового ownership.

## Реализовано

- введены `GlobalId`, `GlobalIdDisplay`, `ExternalGlobalId`,
  `PydanticGlobalId` и строгие helpers;
- `UserId` сохранён только как LEGACY type alias;
- введён `User.global_id = synonym("user_id")`;
- введены `User.legacy_pk = synonym("id")` и
  `User.telegram_id = synonym("tg_id")`;
- физические столбцы `users` не изменены;
- добавлены `GlobalIdRequest/GlobalIdResponse` и OpenAPI format
  `efhc-global-id`;
- активные SSOT/NORM/roadmap переведены на `global_id`;
- прежние identity-документы сохранены в history;
- audit matrix теперь направляет ownership в `global_id`;
- добавлен fail-closed guard против provider/local-PK mixing,
  отдельной колонки, новых неопределённых DTO `user_id`, новых FK на
  `users.id`, удаления aliases и преждевременного switch.

## Не выполнялось

- Alembic revision;
- изменение PostgreSQL DDL;
- historical backfill;
- dual-write, shadow read и runtime read switch;
- изменение балансов, панелей, кошельков, транзакций или экономики;
- создание `user_identities`, AuthContext или TON login;
- GitHub CI.

## PostgreSQL

Preflight заблокирован средой: нет URL, синхронного драйвера,
PostgreSQL Server, `psql`, Docker или Podman. Статус нельзя считать
успешной reconciliation.

## Exit gate

- `global_id` является активным логическим каноном;
- отдельной физической `users.global_id` нет;
- `users.id` остаётся PK;
- `users.user_id` остаётся nullable EXPAND-полем;
- Alembic head остаётся `0002`;
- backfill/read/financial switch равны `false`;
- причинные тесты и exact-HEAD guards проходят.

Следующий цикл: `1603 — Global ID PostgreSQL reconciliation baseline`.

## Проверка

- полный pytest: `2679 passed`, `175 skipped`, `0 failed`, `0 errors`;
- Global ID guards: пройдены;
- Operator Kernel guards: пройдены;
- Python compileall: пройден;
- PostgreSQL preflight: `БЛОКИРОВАНО_СРЕДОЙ`;
- GitHub CI: не запускался.
