# Work cycle 1428 — security audit reconciliation and repair plan

## Status

DONE as planning/reconciliation cycle.

## HEAD input

`EFHC_Bot_v170_02_cycle_1427_ci_log_repair.zip`

## Audit input

`docs/audits/P0_SECURITY_AUDIT_V170_01.md`

Verdict from audit: `P0_RELEASE_BLOCKED`.

The audit reports:

- P0: 2;
- P1: 0;
- P2: 3;
- P3: 0;
- inspected backend HTTP routes: 133;
- inspected `/admin/*` routes: 55;
- minimum repair cycles: 3.

## Scope of this cycle

This cycle does not repair runtime security code. It resolves the audit truth
split, records security decisions, archives the audit, updates documents, and
creates the next repair plan.

No wallet, cron, Telegram auth, frontend auth, CORS, CI workflow, lock file,
AI Archive Laws, or EFHC economic runtime change is made here.

## Truth reconciliation

The audit title references `v170.01`, while the audit body states that the
actually inspected archive was `v170.02`. The current working archive is also
`v170.02`.

Decision:

- v170.02 is the factual HEAD for this line;
- the security audit is accepted as applying to `v170.02`;
- `v170.01` in the title is treated as target-label drift;
- all follow-up security repair cycles continue from `v170.02`.

This resolves the truth split without pretending that release is safe.

## Resolved audit questions

### Q1 — canonical wallet binding contour

Answer: canonical production wallet binding is TonConnect proof through the
current wallet routes/service/proof service contour.

Production must not accept naked address-only binding as a wallet ownership
proof. Legacy/memo-style binding may remain only if it is deprecated or upgraded
to the same verified-proof invariant.

### Q2 — production entrypoint

Answer: both entrypoints must have the same security behavior.

The project must not use entrypoint uncertainty to leave weaker CORS/header or
startup behavior in one path. `backend/app/main.py` and
`backend/app/__init__.py:create_app` must converge.

### Q3 — archive version for final verdict

Answer: repair and later verdicts are based on the latest actual HEAD in this
line, starting from `v170.02`. The audit is archived as evidence and the label
mismatch is documented.

## Repair plan after this cycle

### Cycle 1429 — P0 security blockers

Goal: close both release blockers.

Work:

1. Wallet binding proof boundary:
   - reject `/wallets/connect` without verified TonConnect proof;
   - bind proof to current `tg_id`, domain, TTL, nonce/payload token and
     address;
   - reject proof replay;
   - wallet-gated money routes must accept only verified binding.

2. Cron secret control-plane boundary:
   - remove repository-known working default for `CRON_SECRET`;
   - production/stage fail fast on empty/default/placeholder/short secret;
   - `/cron/tick` rejects missing/wrong/default secret;
   - update `env.prod.example` with placeholder-only guidance.

Required tests:

- `/wallets/connect` rejects unverified address-only bind;
- verified proof is required for wallet binding;
- proof replay does not create verified binding;
- wallet-gated money routes reject naked address-only binding;
- `/cron/tick` rejects missing/wrong/default secret in production mode;
- production startup fails on unsafe `CRON_SECRET`.

### Cycle 1430 — P2 replay, OPSEC and legacy headers

Goal: close P2 findings.

Work:

1. Telegram `initData` freshness:
   - `auth_date` is required;
   - missing/non-numeric/expired `auth_date` fails closed.

2. Logging redaction:
   - cover `BOT_TOKEN`, `SECRET_KEY`, `ADMIN_API_KEY`,
     `TELEGRAM_WEBHOOK_SECRET`, `CRON_SECRET` and TON provider aliases.

3. Legacy frontend headers:
   - remove production emission of `X-Telegram-User-Id`;
   - remove production emission of `X-Admin-Id` and `X-Admin-Token`;
   - update user-facing/security docs so frontend guard remains UX-only.

Required tests:

- missing `auth_date` returns unauthorized;
- non-numeric `auth_date` returns unauthorized;
- redactor masks all production secret aliases;
- frontend runtime does not emit legacy auth/admin headers.

### Cycle 1431 — regression hardening and security re-audit prep

Goal: prove that the repair is guarded across the route surface.

Work:

- AST guard: every `/admin/*` route has `Depends(require_admin)`;
- ownership tests for wallet/order/withdraw/payment intent routes;
- production docs/openapi/redoc safety tests;
- production CORS safety tests;
- monetary/auth-sensitive rate-limit coverage tests;
- callback/webhook secret-before-dedupe tests;
- prepare repeat security audit on the new HEAD.

## Test/guard policy

No test may be deleted, skipped, xfailed, hidden, or weakened to make the
security lane pass. The repair must close the root cause, not the symptom.

## Sandbox use

Песочница used only as reference/navigation layer through `map_element.md`.
No sandbox runtime, CI files, lock files, wallet/payment logic, economics,
secrets, configs, or translations were imported.

## Non-claims

This cycle does not claim:

- P0 fixed;
- GitHub CI green;
- full pytest green;
- frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect/wallet proof.

