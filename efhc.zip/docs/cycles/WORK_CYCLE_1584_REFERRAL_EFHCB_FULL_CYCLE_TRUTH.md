# Cycle 1584 — Referral EFHCb full-cycle truth

Status: LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED
Input HEAD: `EFHC_Bot_v171_80.zip`
Output HEAD: `EFHC_Bot_v171_81.zip`

## Direct user correction

All monetary referral rewards belong to the bonus balance and therefore use the
asset notation `EFHCb`, not generic `EFHC`.

The complete cycle is:

```text
10 000 active direct referrals × 0.1 EFHCb = 1 000 EFHCb
Lvl rewards 1 + 10 + 100 + 300 + 1 000 = 1 411 EFHCb
1 000 + 1 411 = 2 411 EFHCb
```

## Root cause

The backend arithmetic already produced `2 411`, but the public Lvl card showed
only the current Lvl reward. At Lvl 5 the screen therefore exposed `1 000` for
direct referrals and `+1 000` for Lvl 5, then jumped to `2 411` without showing
the accumulated earlier Lvl rewards `1 + 10 + 100 + 300 = 411`. Generic `EFHC`
labels also hid that all of these amounts are credited to `bonus_balance`.

## Runtime repair

- Added the canonical asset field `bonus_asset = EFHCb` to referral stats.
- Added explicit full-cycle API fields:
  - `full_cycle_direct_bonus = 1000.00000000`;
  - `full_cycle_level_bonus = 1411.00000000`;
  - `full_cycle_total_bonus = 2411.00000000`.
- Kept backend-owned per-Lvl fields and exposed `cumulative_level_bonus` visibly.
- Referrals UI now shows direct subtotal, current Lvl reward, accumulated Lvl
  rewards and cumulative total, all in EFHCb.
- Added a separate full-cycle summary block.

## Documentation and causal links

Updated the active referral NORM, first-creation canon, runtime proof, FAQ SSOT,
all 13 locale bundles, frontend screen registry, Healer, error registry, Kernel,
START_HERE and new-chat handoff. Historical reports remain historical and do
not override this cycle.

## Guards

- `tests/architecture/test_referral_bonus_cycle_efhcb_v171_81.py`;
- `tests/architecture/test_referral_level_bonus_runtime.py`;
- `tests/architecture/test_referrals_page_canon_v171_80.py`;
- `tests/architecture/test_referrals_progress_bonus.py`;
- `tests/efhc_backend/referrals/test_referral_level_rewards_integration.py`;
- `ops/release/ci_profile/test_release_archive_contract.py`.

## Local validation completed

- Targeted economics/API/frontend/OpenAPI: `22 passed, 2 skipped, 0 failed`.
- Broad referral/FAQ/i18n/OpenAPI architecture set: `308 passed, 0 failed`.
- Kernel/file-map/startup/referral final guards: `86 passed, 0 failed`.
- Canon Guard: PASS.
- OpenAPI strict contract: 129 operations, no missing/dead seams.
- Python compile, JSON validation (772 files) and release shell `bash -n`: PASS.
- Real PostgreSQL, npm production build, Chromium route proof and fresh exact-HEAD GitHub CI remain external gates.

## Proof boundary

Local static, bounded runtime and archive checks do not replace fresh exact-HEAD
GitHub CI, real PostgreSQL integration execution or route-backed browser proof.
