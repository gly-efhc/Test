# Cycle 1440 — Admin Hub route prefix repair

Status: DONE locally in `v170.16`.

## Goal

Close `F-004` from `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.

## Root problem

Admin Hub frontend and OpenAPI expected canonical paths under:

```text
/admin/hub/*
```

But the backend Hub router lived inside `backend/app/routes/admin_shop_routes.py` and was included through the `/admin/shop` router. That created route-prefix drift risk and could expose the accidental runtime shape:

```text
/admin/shop/admin/hub/*
```

## User decision applied

Admin Hub is a separate admin section.

Canonical backend/frontend/OpenAPI path:

```text
/admin/hub/*
```

## Runtime repair

Changed runtime routing:

1. Added dedicated router module:

```text
backend/app/routes/admin_hub_routes.py
```

2. Registered it in:

```text
backend/app/routes/__init__.py
```

3. Removed Hub router nesting from:

```text
backend/app/routes/admin_shop_routes.py
```

4. Kept Shop routes under:

```text
/admin/shop/*
```

5. Kept Admin Hub links manager under:

```text
/admin/hub/links
/admin/hub/links/{link_id}
/admin/hub/links/{link_id}/toggle
/admin/hub/links/reorder
```

## Frontend / OpenAPI alignment

Confirmed frontend already calls canonical Admin Hub paths from:

```text
frontend/src/features/admin/AdminHubPage.tsx
frontend/src/pages/admin/hub.tsx
```

Confirmed existing OpenAPI contract already contains canonical Admin Hub paths:

```text
/admin/hub/links
/admin/hub/links/{link_id}
/admin/hub/links/{link_id}/toggle
/admin/hub/links/reorder
```

Cycle 1440 did not rebuild the full OpenAPI file because cycle 1442 is the dedicated OpenAPI rebuild and strict contract gate. This cycle aligned runtime routing with the existing canonical OpenAPI paths.

## Tests / guards

Added active guard file:

```text
tests/architecture/test_admin_hub_route_prefix_repair.py
```

Protected invariants:

- `test_admin_hub_routes_match_frontend_and_openapi`
- `test_admin_hub_links_list_route_registered`
- `test_admin_hub_links_create_update_archive_routes_registered`
- `test_admin_hub_reorder_route_registered`
- `test_frontend_admin_hub_calls_existing_backend_routes`
- `test_admin_hub_router_is_not_nested_under_admin_shop`
- `test_admin_hub_chain_uses_hub_links_model_and_service`

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_admin_hub_route_prefix_repair.py -q
# 7 passed
```

Targeted Python compile passed for changed backend route files.

## Scope boundaries

No EFHC economy change.
No money-flow change.
No migration change.
No CI/workflow/lock-file change.
No test deletion, archival, skip or xfail.
No direct runtime transfer from Песочница.

Песочница used only as reference/navigation layer.

## Remaining blockers

`P0_RELEASE_BLOCKED` remains until later linkage findings are repaired and repeat linkage audit is performed.

Next safe cycle:

```text
1441 — Admin wallet reset semantic repair
```
