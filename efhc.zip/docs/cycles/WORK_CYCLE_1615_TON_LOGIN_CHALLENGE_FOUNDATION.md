# Цикл 1615 — TON audit, challenge endpoint и canonical address resolver

Версия пакета: `v172.14`.

## Цель

Подготовить provider-neutral начало TON login без Telegram-зависимости и без
преждевременной реализации cryptographic TON Proof.

## Реализовано

1. Добавлен endpoint:

   ```text
   POST /api/auth/ton/challenge
   ```

2. Endpoint не принимает и не читает `tg_id`, Telegram initData либо текущую
   Telegram session.
3. Challenge создаётся через `AuthChallengeService` и таблицу
   `efhc_core.auth_challenges`:
   - provider: `ton_wallet`;
   - purpose: `ton_wallet.login`;
   - TTL: 600 секунд;
   - raw payload возвращается один раз;
   - PostgreSQL хранит только namespaced SHA-256.
4. Production domain берётся только из configured public URL. Fallback на
   request Host разрешён только в local/dev/ci.
5. Введён `CanonicalTonAddressResolver`. Все допустимые raw/friendly,
   bounceable/non-bounceable, mainnet/testnet, base64/base64url формы дают один
   provider subject:

   ```text
   <workchain>:<64 lowercase hex account_id>
   ```

6. Единый parser подключён к существующему `tonconnect_proof_service`; его
   прежние дублирующие raw/friendly parser functions удалены.
7. Friendly input проверяет tag, точную длину, strict base64 alphabet и
   CRC16-XMODEM. Неявные преобразования `bool/int/object → str` запрещены.

## Разделение существующих контуров

Старый endpoint wallet binding, который выдаёт TonConnect payload для
известного Telegram-пользователя, остаётся legacy compatibility flow. Он не
является новым TON login endpoint и не используется циклом `1615`.

## Не входит в цикл

- signature verification;
- network verification;
- state-init verification;
- replay/concurrent consumption proof;
- account или identity creation;
- session issue;
- TON-only registration;
- Telegram adapter;
- migration `0005`;
- financial changes.

Эти cryptographic checks выполняются в цикле `1616`.

## Exit gate

```text
TON_CHALLENGE_TELEGRAM_INDEPENDENT
TON_ADDRESS_CANONICALIZATION_UNAMBIGUOUS
EXACT_HEAD_CI_REQUIRED
```

## Локальное причинное подтверждение

- четыре конкретных architecture failure run `82897904509`: `4 PASS`;
- новый TON foundation и напрямую связанные regression tests: `39 PASS`;
- статический TON guard: `PASS`;
- Operator Kernel exact primary route: `PASS`, fallback отсутствует;
- `43` protected files и migrations `0001–0004`: без изменений;
- полный regression, PostgreSQL и frontend build оставлены GitHub CI.
