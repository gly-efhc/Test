# WORK CYCLES 1226-1350 FRONTEND 99 ROADMAP

Status: planned route after v168_35 audit.

## Purpose

Move EFHC Bot frontend from visual survival state to 99 percent
user-facing WebApp/PWA readiness.

This roadmap does not remove canonical pages and does not change the
EFHC economy. It organizes the next visual work into proof gates.

## 1226-1230 recovery and agreement

- 1226: build/runtime audit for blank screen and dark shell.
- 1227: visible element agreement table in chat.
- 1228: EFHC visual tokens for cards, glow, chips and bars.
- 1229: reusable game component kit specification.
- 1230: corrected verdict for current frontend readiness.

## 1231-1240 reference and design foundation

- 1231: Dragon/Web3 visual principles into EFHC rules.
- 1232: no external brand assets check.
- 1233: first-screen information hierarchy.
- 1234: progressive disclosure rules.
- 1235: progress bar and resource chip mapping.
- 1236: game card and action card mapping.
- 1237: mobile Telegram shell constraints.
- 1238: desktop browser frame constraints.
- 1239: visual regression checklist.
- 1240: Healer risk update.

## 1241-1260 Energy and core canonical pages

- 1241: GameShell and GameHeader implementation.
- 1242: BottomGameNav final visual pass.
- 1243: ResourceChip component.
- 1244: EnergyProgress component.
- 1245: Energy first screen final layout.
- 1246: Panels machine-card migration.
- 1247: Panels details drawer.
- 1248: Exchange converter card.
- 1249: Exchange history/details drawer.
- 1250: Tasks earning/ad card migration.
- 1251: Tasks ad-flow state feedback.
- 1252: common empty states.
- 1253: common loading states.
- 1254: common error states.
- 1255: no route deletion guard.
- 1256: no admin/debug public leak guard.
- 1257: route smoke map update.
- 1258: TypeScript proof.
- 1259: targeted pytest proof.
- 1260: first core-page visual verdict.

## 1261-1280 Referrals, Ranks, Profile and Wallet

- 1261: Referrals invite card migration.
- 1262: Referrals growth progress migration.
- 1263: Referrals active/inactive compact lists.
- 1264: Ranks leaderboard final card layout.
- 1265: Ranks current-user and empty-state cleanup.
- 1266: Profile overview compression.
- 1267: Profile language/settings cleanup.
- 1268: Wallet subsection design agreement.
- 1269: Wallet primary balance card.
- 1270: Wallet history timeline.
- 1271: WebProfile technical language removal.
- 1272: WebProfile diagnostics moved to Admin.
- 1273: Profile/Wallet guard proof.
- 1274: desktop profile access check.
- 1275: browser no-global_id profile state.
- 1276: TypeScript proof.
- 1277: targeted pytest proof.
- 1278: route smoke proof.
- 1279: visual checklist update.
- 1280: Profile/Wallet verdict.

## 1281-1300 HUB, Browser-Shop and interactions

- 1281: HUB final two-card bridge polish.
- 1282: Browser-Shop storefront hero polish.
- 1283: Browser-Shop product card polish.
- 1284: Browser-Shop payment state cleanup.
- 1285: wallet-open failure recovery.
- 1286: public button inventory.
- 1287: primary / secondary / hidden classification.
- 1288: dead-button feedback repair.
- 1289: disabled reason copy.
- 1290: compact toast system.
- 1291: async pending state guard.
- 1292: no payload / token / memo public leak guard.
- 1293: route button map.
- 1294: click-flow matrix.
- 1295: TypeScript proof.
- 1296: targeted pytest proof.
- 1297: route smoke proof.
- 1298: Browser/PWA shell proof if possible.
- 1299: reports and NORM update.
- 1300: interaction verdict.

## 1301-1325 visual polish wave

- 1301: spacing rhythm pass.
- 1302: typography rhythm pass.
- 1303: icon and coin visual rhythm.
- 1304: cards glow and border pass.
- 1305: progress bars consistency pass.
- 1306: mobile 360 px pass.
- 1307: desktop centered frame pass.
- 1308: FAQ final compact pass.
- 1309: Withdraw placement review.
- 1310: Ads route placement under Tasks review.
- 1311: all public strings technical-language audit.
- 1312: all public empty states audit.
- 1313: all public loading states audit.
- 1314: all public error states audit.
- 1315: all public buttons audit.
- 1316: bottom menu tap target audit.
- 1317: Telegram safe-area audit.
- 1318: browser safe-area audit.
- 1319: PWA icon and manifest audit.
- 1320: service worker API safety audit.
- 1321: no external Dragon asset audit.
- 1322: visual proof checklist.
- 1323: NORM update.
- 1324: Healer update.
- 1325: polish verdict.

## 1326-1350 release evidence and hardening

- 1326: frontend static guard pack.
- 1327: public visual blocker guard pack.
- 1328: TypeScript noEmit.
- 1329: npm build with real exit code.
- 1330: Docker frontend proof if environment allows.
- 1331: direct browser route proof if environment allows.
- 1332: Telegram WebApp route proof from user log or local evidence.
- 1333: PWA installability checklist.
- 1334: route registry update.
- 1335: frontend call matrix update.
- 1336: SSOT route table update if changed.
- 1337: tests catalog update.
- 1338: reports index update.
- 1339: Q/A register update.
- 1340: ZIP hygiene cleanup.
- 1341: FLAT ZIP proof.
- 1342: no economic route drift check.
- 1343: no migration drift check.
- 1344: no admin function public leak check.
- 1345: no bottom menu rename check.
- 1346: no hidden function deletion check.
- 1347: final visual evidence audit.
- 1348: final unresolved proof list.
- 1349: corrected release readiness verdict.
- 1350: frontend 99 percent verdict.
