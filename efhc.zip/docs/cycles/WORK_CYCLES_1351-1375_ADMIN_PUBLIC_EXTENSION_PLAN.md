# WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN

Purpose: extend work after the original 1321-1350 recovery range.

## Completed

- 1351: Public Profile / Wallet / History trust layer. DONE in v169_30.
- 1352: ZIP encoding and wallets CRUD import hotfix. DONE in v169_31.
- 1353: Admin UI Kit adoption proof pass. DONE in v169_32.
- 1354: Admin screenshot QA preparation. DONE in v169_33.
- 1355: Admin docs and SSOT route map update. DONE in v169_34.
- 1356: Admin regression proof pass. DONE in v169_35.
- 1357: Admin recovery checkpoint report and sandbox map refresh. DONE in v169_36.
- 1358: HIGH audit fixes implementation: admin bottom nav boundary, E2E scaffold, Sale Packages mutations. DONE in v169_37.
- 1359: MEDIUM audit fixes implementation: EFHC deposits idempotency, public error states, AdminPage guard, PWA offline fallback. DONE in v169_37.
- 1360: LOW audit polish: DepositModal wallet open, TonConnect fallback note, no-prefix router docs. DONE in v169_37.

## Active / Next

- 1361: Public UI screenshot QA preparation and residual audit closure. DONE in v169_39.
- 1362: Public UI regression proof pass. DONE in v169_40.
- 1363: Next range extension checkpoint. DONE in v169_41.
- 1364: Public browser screenshot evidence harness and capture manifest. DONE in v169_42 as harness/manifest only; screenshots are not claimed.
- 1365: Public visual beauty pass — Energy, Panels, Exchange. DONE in v169_43 as static/source polish; screenshots are not claimed.
- 1366: Public visual beauty pass — Tasks, Referrals, Ranks. DONE in v169_44 as static/source polish; screenshots are not claimed.
- 1367: Profile / Wallet / History / FAQ visual trust pass. DONE in v169_45 as static/source polish; screenshots are not claimed.
- 1368: HUB / Browser Shop / Withdraw / Ads visual trust pass. DONE in v169_46 as static/source polish; screenshots are not claimed.
- 1369: i18n critical audit repair pass. DONE in v169_47.
- 1370: Public i18n untranslated keys remediation. NEXT.
- 1371: FAQ wave-3 translation and status repair.
- 1372: Telegram Mini App shell polish: viewport, theme, BackButton, safe-area.

## Cycle remap note

By direct user instruction, the original public UI sequence was moved from
1358-1360 to 1361-1363. Cycles 1358-1360 were reassigned to the uploaded
`TZ_FIXES_AUDIT_v169_35.md` correction package.

## Cycle 1353 note

Admin UI Kit proof pass is a frontend/admin proof cycle. It adds a visible
Admin-home proof panel and documents the adoption chain from cycles 1326 to
1345. It does not change CI, backend routes, public UI or EFHC economics.

## Cycle 1354 note

Admin screenshot QA preparation adds a visible Admin-home QA matrix. It
prepares manual screenshots for mobile, Telegram-like, desktop and state
proof without claiming browser screenshot completion. CI files were not
changed.

## Cycle 1355 note

Admin docs and route-map update created
`docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`, refreshed the legacy
Admin routes map and kept CI files unchanged.


## Cycle 1356 note

Admin regression proof pass created
`docs/admin/ADMIN_REGRESSION_PROOF_PASS.md`, audit, generated JSON proof
and architecture guard. It also synchronized `WORK_CYCLES.md` and
`AI_DOCS_INDEX.md` to the active `v169_* / 1350+` phase and moved old
`1176-1230` wording into historical-only context.

## Cycle 1357 note

Admin recovery checkpoint closes the transition after Admin route-map and
regression-proof work. It synchronizes the active cycle/index layer, refreshes
`map_element.md` as the navigation map for sandbox references and records that
sandbox archives remain donor references rather than EFHC runtime code.

It also repairs Python dunder-token damage caused by the previous filename
cleanup and adds a guard so `__future__`, `__file__`, `__name__`, `__all__`,
`__init__` and related Python protocol names cannot silently degrade again.

## Cycle 1358 note

HIGH audit fixes implemented the admin/public boundary and sale-package wiring:

- `/admin/*` routes no longer render public bottom navigation;
- `tests/frontend/e2e/` now contains baseline Playwright smoke files;
- `AdminSalePackagesPage.tsx` wires create/edit/toggle calls with
  `Idempotency-Key` and modal confirmation.

## Cycle 1359 note

MEDIUM audit fixes implemented safety and fallback repairs:

- Admin EFHC deposit process/reprocess sends frontend idempotency keys;
- public API 401/403 handling is normalized through `publicApiErrorMessage`;
- `AdminPage.tsx` has component-level `LayoutContext.isAdmin` guard;
- service worker now caches and serves `frontend/public/offline.html`.

## Cycle 1360 note

LOW audit polish implemented final documented fixes:

- `DepositModal.tsx` opens wallet links through Telegram `openLink` or
  `window.open(..., "_blank", "noopener,noreferrer")` instead of replacing
  browser/TMA history;
- static `tonconnect-manifest.json` is marked fallback-only and SSOT says the
  canonical runtime manifest is `/api/tonconnect-manifest`;
- no-prefix `me_routes.py` and `system_routes.py` exceptions are documented in
  code and `docs/NORM/API_CONTRACTS.md`.


## Recheck note before 1361

Before starting public screenshot QA, the audit-fixes implementation was
rechecked. The recheck confirmed FIX-01 through FIX-10 and closed two small
tails: Sale Packages stale `read-only` wording and missing frontend idempotency
on the EFHC deposits force-fulfillment POST.

The active public QA preparation document is:

- `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md`.

## Cycle 1361 note

Public UI screenshot QA preparation is complete as a preparation layer in v169_39.
The scope now includes 14 public routes and the related E2E smoke matrix:

- `/`, `/panels`, `/exchange`, `/tasks`, `/referrals`, `/referrals/active`,
  `/referrals/inactive`, `/ranks`, `/web-profile`, `/faq`, `/hub`,
  `/browser-shop`, `/withdraw`, `/ads`;
- 17 admin smoke routes remain covered for boundary regression control.

Residual audit corrections from the v169_37 review were also closed: localized
common error keys, interaction-level POST E2E smokes and multilingual offline
fallback. Actual screenshot capture and public route proof are intentionally left
for 1362.



## Cycle 1362 note

Public UI regression proof pass is complete as a static proof in v169_40.

The proof document is:

- `docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md`.

It maps 14 public surfaces to frontend pages, component families, backend roads,
SSOT/NORM anchors and guards. The pass does not claim actual screenshot capture,
live browser Playwright execution, frontend build or GitHub CI green.

## Cycle 1363 note

Next range extension checkpoint is complete in v169_41. It adds the public
visual extension plan:

- `docs/cycles/WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md`.

The next active work after this checkpoint was 1364 — Public browser screenshot
evidence harness and capture manifest. The checkpoint is documentary and routing
work only: it does not claim browser screenshots, live Playwright execution,
frontend build or GitHub CI green.

## Cycle 1364 note

Public browser screenshot evidence harness is complete in v169_42. It adds:

- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`;
- `reports/generated/public_browser_screenshot_capture_manifest_v169_42.json`;
- `tests/frontend/e2e/test_public_screenshot_capture_manifest.py`;
- `tests/architecture/test_public_browser_screenshot_evidence_harness.py`.

The next active work after 1364 was 1365 — Public visual beauty pass: Energy, Panels,
Exchange. No real screenshot evidence, live browser verdict, frontend build or
GitHub CI green is claimed by 1364.


## Cycle 1365 note

Public visual beauty pass for Energy, Panels and Exchange is complete in v169_43.
It adds static/source visual polish and guard coverage for the first public
visual lane. No real screenshot evidence, live browser verdict, frontend build
or GitHub CI green is claimed by 1365.

## Cycle 1366 note

Public visual beauty pass for Tasks, Referrals and Ranks is complete in v169_44.
It adds:

- `docs/frontend/PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md`;
- `reports/generated/public_visual_beauty_pass_v169_44.json`;
- `tests/architecture/test_public_visual_beauty_pass_tasks_referrals_ranks.py`.

The next active work after 1366 was 1367 — Profile / Wallet / History / FAQ visual trust pass. No real screenshot evidence, live browser verdict, frontend build or GitHub CI green is claimed by 1366.

## Cycle 1367 note

Profile / Wallet / History / FAQ visual trust pass is complete in v169_45. It adds static/source visual trust polish for account, wallet, history and FAQ surfaces. No real screenshot evidence, live browser verdict, frontend build or GitHub CI green is claimed by 1367.

## Cycle 1368 note

HUB / Browser Shop / Withdraw / Ads visual trust pass is complete in v169_46. It adds:

- `docs/frontend/PUBLIC_VISUAL_TRUST_PASS_HUB_BROWSER_SHOP_WITHDRAW_ADS.md`;
- `reports/generated/public_visual_trust_pass_v169_46.json`;
- `tests/architecture/test_public_visual_trust_pass_hub_browser_shop_withdraw_ads.py`.

The next active work was remapped by user instruction to localization repair. Cycle 1369 is i18n critical audit repair; cycle 1370 is public i18n untranslated keys remediation. No real screenshot evidence, live browser verdict, frontend build or GitHub CI green is claimed by 1368.


## v169_47 / cycle 1369 i18n critical repair

User instruction remapped the next pass from Telegram Mini App shell polish to
localization repair based on the v169.45 i18n audit.

Cycle 1369 repairs:

- C1 English-first player fallback in `frontend/src/lib/i18n.ts`;
- C2/C3 Hindi placeholder drift;
- C4 five empty locale keys across all 13 languages;
- main-shell Russian fallback issues from the audit;
- broken `audit_bot_texts_parity.py`;
- inaccurate flat `complete` labels in `TRANSLATION_STATUS.md`.

The next language work is 1370 public untranslated key remediation and 1371 FAQ
wave-3 translation/status repair. TMA shell polish is moved to 1372 unless a new
user instruction changes the priority.


## Historical next-marker compatibility

1354: Admin screenshot QA preparation. DONE in v169_33.
1355: Admin docs and SSOT route map update. DONE in v169_34.
1356: Admin regression proof pass. NEXT.
