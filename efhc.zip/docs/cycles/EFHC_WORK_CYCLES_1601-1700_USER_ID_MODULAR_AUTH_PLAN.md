# Статус перехода к диапазону 1601–1700

Циклы `1593–1600` локально закрыты в `EFHC_Bot_v171_97.zip`.
Сформированы аудит, guards, типы `UserId`/`TelegramId`, внешний
API-контракт, nullable EXPAND `users.user_id`, LEGACY alias,
backfill harness и PostgreSQL reconciliation gate.

Реальная PostgreSQL-сверка не выполнена. Historical backfill и
runtime read switch запрещены. Следующий цикл — `1601`; следующая
изменённая версия — `v171.98`.
