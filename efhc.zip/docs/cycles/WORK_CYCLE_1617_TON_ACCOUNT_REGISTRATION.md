# Цикл 1617 — TON account registration

## Цель

После verified TON Proof детерминированно открыть существующий global
account либо создать новый TON-only account без фиктивного Telegram ID.

## Реализация

1. `PostgreSQLIdentityResolver` удерживает advisory lock по TON identity.
2. Existing active verified identity возвращает тот же `global_id`.
3. Existing active verified legacy wallet binding создаёт identity для того
   же account.
4. Новый wallet создаёт `users`, `user_identities` и `wallet_bindings` одной
   транзакцией.
5. `users.global_id` и `wallet_bindings.global_id` nullable с migration `0005`.
6. Conflict, inactive/unverified binding и legacy drift завершаются fail
   closed. Auto-merge отсутствует.
7. Proof endpoint возвращает `global_id` и account outcome, но не session.

## PostgreSQL evidence package

Подготовлены сценарии existing identity, legacy binding, new TON-only
registration, concurrent registration и unverified binding. Реальная БД
проверяется только каноническим GitHub CI.

## Exit gate

```text
ONE_WALLET_ONE_GLOBAL_ACCOUNT
FAKE_TG_ID_ABSENT
EXACT_HEAD_CI_PASS_REQUIRED
```
