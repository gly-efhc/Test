# Cycle 1426 — Panel dead transaction-context cleanup

Status: DONE.
Archive: `EFHC_Bot_v170_01_cycle_1426_panel_dead_tx_context_cleanup.zip`.
Input HEAD: `EFHC_Bot_v170_00_cycle_1425_economic_cleanup_reconciliation.zip`.
Audit source: `docs/audits/P0_ECONOMIC_REAUDIT_V170_00_CYCLE_1425.md`.
Verdict source: `ECONOMY_SAFE_WITH_MINOR_FINDINGS`.

## Goal

Close `NEW-001` from the v170.00 economic re-audit: remove the dead local
`_tx_context` helper in `backend/app/services/panels_service.py` that still used
`db.begin_nested()` and could tempt a future developer to reintroduce the
forbidden HEAL-0018 savepoint fallback pattern.

## Repair

- Removed the unused local `def _tx_context(db: AsyncSession)` from
  `panels_service.py`.
- Preserved the canonical transaction owner for panel activation:
  `bank._tx_context(db)` from `transactions_service.py`.
- Updated the panels service header comment to state the current atomicity
  model: EFHC spend and panel row creation are committed or rolled back
  together.
- Added `test_panels_service_no_local_tx_context` to
  `tests/architecture/test_economic_risk_guards.py`.

## Guard meaning

The guard forbids:

- local `_tx_context` in `panels_service.py`;
- `db.begin_nested()` in `panels_service.py`;
- future panel-service transaction-boundary drift away from
  `bank._tx_context(db)`.

## Sandbox / map_element

`map_element.md` and the uploaded sandbox archives were used only as a
reference/navigation layer. No Vue/Solid/Nuxt/Vanilla runtime, CI file, lock
file, wallet/payment logic, foreign economy or translation was imported.

## Checks

Targeted local checks:

- `tests/architecture/test_economic_risk_guards.py`
- targeted architecture pack including filename hygiene and P0 economic guards
- `scripts/ci/check_ai_archive_laws_integrity.py`
- ZIP `testzip`

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, frontend build,
release-ready status, screenshots, live Telegram client proof or real
TonConnect/wallet proof.

## Result

`NEW-001` is closed. The economic re-audit condition for removing dead
`panels_service._tx_context` is satisfied locally, but a general release-ready
claim still requires a separate release audit and full external CI/build proof.
