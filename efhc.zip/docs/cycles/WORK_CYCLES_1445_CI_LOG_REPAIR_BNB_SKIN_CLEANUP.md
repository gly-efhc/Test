# Cycle 1445 — CI/log proof and residual audit-tail closure

Status: DONE locally

HEAD input: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`

Input logs: `logs_72623328892.zip`

Output archive: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`

## Цель

Разобрать fresh CI logs, исправить фактические ошибки, удалить старый BNB/source skin and update docs/guards.

## Root cause from logs

CI failed on ruff, mypy and pytest. Main causes:

- import-order/E402 drift after previous route/OpenAPI tooling work;
- type drift in bank balance helper and bank transfer log mapping;
- legacy admin bank road guard still expected old mint/burn marker;
- admin route module guard did not include `admin_hub_routes.py`;
- Kernel lacked exact fallback refresh command marker;
- line72 violations existed in new ops tooling scripts;
- banned legacy substring was triggered by English `startup pointer` predecessor wording;
- route freeze markdown count was stale;
- Healer atlas cards had compact schema tails;
- wallet hardening test reused shared Postgres wallet tables;
- old PNG BNB/source skin still existed after WebP first-paint migration.

## Runtime / code changes

- `transactions_service.get_bank_main_balance()` renamed to `get_bank_balance()` to avoid degraded `_main_` token shape.
- `get_bank_balance()` now returns `cast(Decimal, d8(...))` for mypy.
- Admin bank transfer log IDs now use explicit `int | None` typing.
- Import ordering fixed in touched Python modules.
- `ops/openapi/refresh_openapi_from_ssot.py` now uses lazy import inside `main()` to avoid E402.
- Wallet test helper now truncates wallet hardening tables for Postgres test isolation.
- Skin catalog and frontend skin URL now use `.webp`; old `frontend/public/skins/1.png` was removed.

## Guard / docs changes

- Admin bank road guard now protects the new canonical rule: no runtime dependency on `efhc_mint_burn`; mint/burn must go through canonical transaction service.
- Admin route module guard includes `admin_hub_routes.py` with `/admin/hub` and `admin:hub`.
- Kernel docs include exact fallback command: `python ops/operator_kernel/file_map.py --refresh`.
- Route inventory markdown regenerated from current freeze CSV.
- Healer atlas compact tails normalized.
- Cold-start skin guard now requires WebP and absence of old PNG source skin.

## Local validation

See `reports/generated/ci_log_repair_v170_21.json`.

## Not claimed

No GitHub CI green, full pytest green, frontend build green, release-ready, browser screenshots, live Telegram proof or real TonConnect proof is claimed.

## Next safe step

`1446 — CI rerun log reconciliation or next fresh log repair` if new CI logs are supplied.
