# 1528 — Kernel / map_element compaction / test consolidation

Status: DONE locally, fail-closed.

## Input HEAD

`EFHC_Bot_v171_02_cycle_1527_ci_evidence_chat_docs_test_consolidation.zip`

## Output HEAD

`EFHC_Bot_v171_03_cycle_1528_kernel_map_compaction_test_consolidation.zip`

## Scope

- Keep `KERNEL.md` compact and current.
- Add the current compact navigation section to `map_element.md`.
- Preserve historical `map_element.md` anchors for guard compatibility.
- Execute the safest consolidation candidate: chat docs intake guards.
- Update docs, reports, manifest and guards.

## Logs

No `logs_*.zip` was provided for cycle 1528. No log repair is claimed.

## Test consolidation

Executed only group 1 from the candidate list:

- removed `tests/architecture/test_chat_24_archive_intake.py`;
- removed `tests/architecture/test_chat_25_archive_intake.py`;
- preserved their checks inside `tests/architecture/test_chat_docs_intake.py`.

## Runtime boundary

Runtime service code, money-flow, withdraw logic, wallet binding logic,
TonConnect behavior, frontend runtime and EFHC economy were not changed.

## Claims not made

- no GitHub CI green;
- no full pytest green;
- no full frontend build green;
- no live Telegram proof;
- no real TonConnect proof;
- no release-ready claim.

## Next safe cycle

`1529 — Fresh CI Evidence Intake / Red-log Repair`
