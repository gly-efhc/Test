# Cycle 1438 — P0 Deposit watcher wallet SSOT repair

Status: DONE locally in `v170.14`.
Base HEAD: `EFHC_Bot_v170_13_cycle_1437_p0_bank_ssot_repair.zip`.

## Goal

Close linkage finding `F-002`: deposit watcher and admin replay must use the canonical wallet SSOT `efhc_core.wallet_bindings`, not legacy `efhc_core.user_wallets` or `users.ton_wallet`.

## Runtime repair

Changed:

- `backend/app/services/watcher_service.py`

Result:

- `_find_user_by_wallet()` now reads `efhc_core.wallet_bindings`;
- watcher lookup requires `wallet_address = :wa`;
- only active bindings are accepted: `is_active = TRUE`;
- only verified bindings are accepted: `proof_verified = TRUE`;
- revoked/deactivated/unverified wallet bindings are not used for auto-credit;
- scheduler path and admin replay path stay unified because both call `process_incoming_tx()`;
- no migration was added;
- no new wallet table was created;
- no EFHC economics were changed.

## Admin replay chain

`/admin/efhc-deposits/reprocess/{tx_hash}` continues to call `reprocess_single_tx()`, and `reprocess_single_tx()` reconstructs the logged incoming transaction and sends it back through `process_incoming_tx()`. Therefore admin replay uses the same canonical `wallet_bindings` lookup as the scheduler watcher path.

## Guards / tests

Added:

- `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`

Protected checks:

- `test_deposit_watcher_uses_wallet_bindings_ssot`
- `test_deposit_reprocess_uses_wallet_bindings_ssot`
- `test_wallet_bound_deposit_is_matched_to_user`
- `test_revoked_wallet_binding_is_not_used_for_deposit_credit`
- `test_deposit_payment_intent_chain_complete`
- `test_admin_efhc_deposit_reprocess_has_admin_guard`
- `test_wallet_bindings_model_is_canonical_for_tonconnect`

## Bank start balance answer

The canonical start balance `5000000.00000000 EFHC` lives in two places with different roles:

1. **Physical DB seed / migration truth:** `backend/migrations/versions/0001_initial_release_schema.py` inserts/upserts `efhc_core.bank_balance` with `key='EFHC_MAIN'` and `balance=Decimal('5000000.00000000')`.
2. **Runtime fallback / service initialization:** `backend/app/services/admin/admin_bank_service.py` defines `BANK_INITIAL_TOTAL` with fallback `5000000` and passes it into `transactions_service.ensure_bank_initialized()` / `get_bank_balance()` when the bank row must be initialized by service code.

The active bank balance itself is stored in `efhc_core.bank_balance`, not in `users`, not in `efhc_admin.bank_balances`, and not in a separate mint/burn ledger.

## Local validation performed

Executed locally:

```text
python -m pytest tests/architecture/test_deposit_watcher_wallet_ssot_repair.py -q
# 7 passed

python -m py_compile backend/app/services/watcher_service.py backend/app/routes/admin_routes.py backend/app/services/wallets_service.py backend/app/services/admin/admin_bank_service.py
# passed
```

Additional local checks:

```text
python -m pytest tests/architecture/test_deposit_watcher_wallet_ssot_repair.py tests/architecture/test_admin_bank_ssot_repair.py tests/architecture/test_archive_filename_hygiene.py tests/architecture/test_operator_kernel_routes.py tests/architecture/test_operator_kernel_config_loading.py -q
# 27 passed

grep -RIn "user_wallets" backend/app/services/watcher_service.py
# no runtime hits
```

Not claimed:

- no GitHub CI green;
- no full pytest green;
- no frontend build green;
- no release-ready;
- no browser screenshots;
- no live Telegram/TonConnect proof.

## Remaining blockers

The archive is still not release-ready because the active linkage audit still has open blockers after `F-001` and `F-002`:

- `F-003` / cycle 1439: admin reports must use `efhc_core.bank_balance`;
- `F-004` / cycle 1440: Admin Hub canonical route `/admin/hub/*`;
- `F-005` / cycle 1441: admin wallet reset must unbind canonical `wallet_bindings`;
- `F-006` / cycle 1442: OpenAPI rebuild and strict contract gate;
- `F-007/F-008` / cycle 1443+: UI state guards and full linkage architecture tests.

Next safe cycle: `1439 — Admin reports bank table repair`.

Песочница использована только как reference/navigation layer. Runtime-код не переносился.
