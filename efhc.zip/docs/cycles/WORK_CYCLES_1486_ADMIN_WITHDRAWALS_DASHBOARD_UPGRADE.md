# WORK_CYCLES_1486_ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE

**Cycle:** 1486 — Admin Withdrawals Dashboard Upgrade  
**Archive:** v170.62  
**Status:** DONE LOCALLY

## Goal

Upgrade `/admin/withdrawals` into a Grafana-like read-only dashboard for
withdrawal queue control, without changing the guarded decision flow.

## Result

Added:

```text
frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/withdrawals.tsx
```

The dashboard shows pending queue, final statuses, operator attention,
VIP share, pending age buckets, average handling only from real timestamps,
recent queue snapshot and the canonical operator order.

## Boundaries

No backend, DB, OpenAPI, dependency, lock-file, CI/workflow, economy,
wallet or money/write-flow change.

Approve, reject, TonConnect payment and consistency repair stay in the
existing guarded controls.

## Checks

Local targeted checks passed. GitHub CI green, full pytest green, full
frontend build green, release-ready, browser screenshots, live Telegram
proof and real wallet proof are not claimed.

## Next

Next safe cycle:

```text
1487 — Admin Panels Dashboard Upgrade
```
