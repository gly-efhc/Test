# 1522 — Fresh CI rerun / external proof evidence intake log repair

Status: DONE locally as red-log repair.
Archive target: `v170.98`.

## Input

- Input HEAD: `v170.97`.
- Input log: `logs_74335271498.zip`.
- Input verdict: red because `pytest` failed.
- Non-pytest CI gates in the uploaded log passed: flake8, ruff, mypy,
  bandit, compileall, Alembic, npm ci and npm build.

## Repairs

- Fixed `line72` violations in `ops/frontend/public_visual_runtime_proof.py`.
- Restored local static evidence for canonical public panel routes without
  returning to raw public money endpoint strings.
- Updated the stale public panels route-evidence guard to generated seam
  canon: `PANELS_ACTIVATE_PATH` is expected, direct
  `apiRequest("/panels/activate"` remains forbidden.

## Proof boundary

- Targeted replay of logged pytest failures passed locally.
- Full local `pytest -q` did not receive a final verdict in sandbox because of
  timeout.
- Fresh GitHub CI green for `v170.98` is not claimed.
- Release readiness is not claimed.

## Next safe work item

`1523 — Fresh CI rerun for v170.98 / external proof evidence intake`.
