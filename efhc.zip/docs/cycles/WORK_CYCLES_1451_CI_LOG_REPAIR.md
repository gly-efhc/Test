# Cycle 1451 — CI log repair / v170.27

Status: DONE locally.
Date: 2026-06-06.

## Input

- HEAD input:
  `EFHC_Bot_v170_26_cycle_1450_visual_p0_countdown_followup_repair.zip`.
- Logs input: `logs_72682359351.zip`.

## Root causes from logs

1. `ruff I001` import-order drift:
   - `backend/app/services/admin/admin_bank_service.py`;
   - `backend/app/services/transactions_service.py`;
   - `tests/architecture/test_chat_docs_intake.py`.
2. Pytest stale guards:
   - old chat index anchor strings for branches 24 and 25;
   - old Kernel marker `# Operator Kernel` missing;
   - profile history i18n anchor moved behind shared normalizer;
   - canon guard found prohibited terms inside imported chat export `26.md`.
3. Frontend build TypeScript failure:
   - generated `adminSeams.ts` had no exported
     `AdminWithdrawOutcomePreviewResponse` type.

## Repaired

- Restored ruff import ordering.
- Added compatibility chat index anchors without creating branch
  duplicates.
- Restored exact Kernel compatibility marker.
- Added profile history i18n anchors while keeping shared normalizer.
- Reworded imported chat export terms that violated canon guard.
- Added generated admin withdraw preview response types to
  `adminSeams.ts` and its generator.
- Added active regression guard:
  `tests/architecture/test_ci_log_repair_v170_27_guards.py`.

## Safety

- Runtime economy changed: no.
- Backend monetary logic changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- No test was deleted, archived, skipped, xfailed or hidden.

## Local validation

- `ruff check backend api ops tests`: passed.
- `ops/canon_guard.py`: passed.
- `scripts/ci/check_ai_archive_laws_integrity.py`: passed.
- Log failure targeted pytest set: passed.
- Added v170.27 CI log repair guard: passed.
- Wider targeted guard pack: 60 passed.
- `compileall` for `ops`, `scripts`, `tests/architecture`: passed.
- Frontend build retry passed TypeScript and production compilation
  phases, but full build green is not claimed because sandbox page-data
  worker ended with `EPIPE`.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Full frontend build green.
- Release-ready.
- Browser screenshots.
- Live Telegram proof.
- Real TonConnect / wallet proof.

## Next safe step

Fresh CI rerun proof or factual log repair if new `logs_*.zip` exists.
