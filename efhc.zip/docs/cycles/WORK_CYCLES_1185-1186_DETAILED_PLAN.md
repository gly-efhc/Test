# WORK CYCLES 1185-1186 DETAILED PLAN

## Purpose

This pass repairs concrete road-audit findings.  The goal is not to
increase cycle count.  The goal is to remove route ambiguity after a
consumer check and to keep only canonical self-user roads.

## Cycle 1185: profile route alias repair

Audit finding:
- `/user/me` and `/user/{global_id}/me` created duplicate self-profile
  roads.

Required work:
1. Check backend route decorators.
2. Check frontend source for direct legacy consumers.
3. Check active API contract docs.
4. Check architecture tests and guards.
5. Remove the legacy alias if no real consumer requires it.
6. Keep `/user/me` as the only active self-profile route.
7. Update active docs, guards, tests and generated evidence.

Done condition:
- no active backend route for `/user/{global_id}/me`;
- no frontend consumer for `/user/{global_id}/me`;
- no active API contract section for `/user/{global_id}/me`;
- guard returns `all_required_present: true`.

## Cycle 1186: panels-summary orphan repair

Audit finding:
- `/user/{global_id}/panels-summary` looked like a tg-id scoped road, while
  the real self-user road should use authenticated current user context.

Required work:
1. Check backend route decorators.
2. Check frontend source for direct legacy consumers.
3. Check active API contract docs.
4. Replace the tg-id route with `/user/me/panels-summary`.
5. Use the canonical auth dependency as the source of current global_id.
6. Update SSOT route inventory entries and active docs.
7. Add guard and architecture test.

Done condition:
- `/user/me/panels-summary` exists in active backend code;
- `/user/{global_id}/panels-summary` is absent from active backend code;
- no frontend consumer requires the removed tg-id path;
- guard returns `all_required_present: true`.
