# Cycle 1557 — Tasks, Ads alias and compact typography

Status: `DONE LOCALLY / OUTPUT v171.32`.

## Completed user scenario

`/tasks -> React Query catalogue/state -> action or claim -> validated service
DTO -> backend route -> protected credit boundary -> query invalidation ->
visible claimed state`.

The routed page now exposes one operational catalogue. Historical dashboard
and engagement-preview components remain only as inactive legacy references.
The `/ads` route remains a compatibility alias to `/tasks`.

## Double-credit protection

Custom-task claim locks the submission, returns an idempotent response when
`paid=true`, and does not issue a second credit. The broken post-claim balance
reader was replaced with the existing `get_user_balances_snapshot` service.
Advertising completion remains protected by `task_complete_lock` and the
reward log. `/tasks/my` now merges moderated submissions with automatic
`user_tasks_status`, so refetch shows the credited advertising task.

## Browser interaction evidence

At `390x844`, one custom-task POST and one advertising callback POST were
observed. Each action refetched `/tasks/my`; both cards became `claimed`, no
horizontal overflow appeared, and screenshots were created.

## Typography and modal repair

The public runtime uses `Arial, Helvetica Neue, Helvetica, sans-serif` with a
compact mobile scale. Panels and Exchange statistic values are kept on one
line. Chromium measured `1 kWh = 1 EFHC` at `12.16px`, `nowrap`, and one line.
The shared Modal now renders through a body portal above fixed navigation, so
its confirmation button is not intercepted by the bottom bar.

## Exact evidence boundary

Established: code repair, targeted tests, production build and local Chromium
evidence for Tasks/Ads and the Panels/Exchange typography checks.

Not established: fresh GitHub CI, live Telegram, real TonConnect, real
PostgreSQL concurrency proof, release-ready or production-ready status.

## Final verification

- `npm ci`: passed, `0` vulnerabilities.
- TypeScript: passed.
- Frontend architecture: passed.
- Production build: two consecutive passes, 34 pages each.
- Browser E2E: `2 passed`.
- Exact full regression: `2389` nodes, `2263 passed`, `126 skipped`,
  `0 failed`.
- Release master gate: passed at `15 / 100` verified points.

The skipped nodes are established environment-gated tests. The new browser
tests were executed separately and passed. No explicit `skip` or `xfail`
marker was added by this work scope.
