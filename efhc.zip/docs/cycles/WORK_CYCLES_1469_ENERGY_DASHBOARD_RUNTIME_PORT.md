# WORK CYCLE 1469 — ENERGY DASHBOARD RUNTIME PORT

Status: `DONE_LOCAL`

Archive: `EFHC_Bot_v170_45_cycle_1469_energy_dashboard_runtime_port.zip`

## Goal

Port the Energy Dashboard sandbox prototype into the live Energy route
using runtime snapshot data and without changing EFHC economy or
write-flow.

## Result

Added runtime Energy Dashboard layer:

- `frontend/src/components/dashboard/EnergyDashboardRuntime.tsx`
- route integration in `frontend/src/pages/index.tsx`
- user-facing locale keys in `frontend/public/locale/ru.json`
- user-facing locale keys in `frontend/public/locale/en.json`

The existing live Energy hero and existing public interactive overview
were preserved.

## Truth model

- Runtime data kind: `raw` and `derived`.
- Synthetic preview data in runtime: no.
- Real time-series claim: no.
- Backend write-flow: no.
- Money action added: no.

## Grafana / Песочница

Grafana used only as visual-pattern/reference layer.
Runtime code was not copied.

Песочница used only as reference/navigation/prototype layer.
Runtime code was not copied.

## Boundaries

Changed:

- frontend runtime UI component;
- Energy page integration;
- docs/reports/tests/navigation;
- RU/EN locale keys;
- one UI-kit cleanup: duplicated unit span in `SimHeroEnergyCard`.

Not changed:

- EFHC economy;
- backend routes;
- database migrations;
- OpenAPI;
- CI/workflows;
- package dependencies;
- lock files;
- write/money flows.

## Validation

Local validation must not be overstated as GitHub CI proof.

Validated locally:

- targeted architecture guard for cycle 1469;
- selected dashboard guard pack;
- AI Archive Laws integrity;
- test-suite integrity guard;
- frontend `npm ci`;
- `npm audit --json` with zero vulnerabilities;
- frontend typecheck.

Not claimed:

- GitHub CI green;
- full pytest green;
- full production build green;
- browser screenshots;
- live Telegram proof;
- real TonConnect/wallet proof;
- release-ready.

## Next cycle

`1470 — Energy Dashboard Visual QA`
