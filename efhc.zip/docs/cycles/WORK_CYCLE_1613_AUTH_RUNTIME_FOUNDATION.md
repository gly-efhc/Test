# Рабочий цикл 1613 — auth runtime foundation

Версия: `v172.12`.

Статус:

```text
CYCLE_1612_FUNCTIONAL_POSTGRESQL_STATIC_GATES_PASS
CYCLE_1612_HANDOFF_MARKER_FIX_INCLUDED
CYCLE_1613_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## 1. Основание

GitHub CI run `82865834601` подтвердил functional/static/PostgreSQL объём
цикла `1612`: resolver tests, PostgreSQL preflight, Alembic, Ruff, Mypy,
Bandit и frontend прошли. Общий run упал только на одном handoff marker,
который исправлен в `v172.12`.

## 2. Цель

Создать provider-neutral auth-core storage и services без подключения
provider login flows:

```text
auth_challenges
auth_sessions
user_roles
FastAPI auth dependencies
```

## 3. Storage и migration 0004

Migration `0004` является чистой `EXPAND` migration. Она создаёт три пустые
таблицы и составной FK session → `(identity_id, global_id)`, не создаёт
accounts/identities/sessions с данными и не меняет domain/financial ownership.
Downgrade разрешён только при пустых auth-таблицах.

## 4. Security contracts

- challenge token: high entropy, namespaced SHA-256 в storage, atomic consume;
- session token: high entropy, namespaced SHA-256 в storage, revoke support;
- raw tokens выдаются только один раз и redacted в `repr`;
- session требует active verified identity с тем же `global_id`;
- session issue статически проверяет точное значение `AuthProvider` и
  блокирует identity row до завершения транзакции;
- corrupted provider/global identity завершается fail closed;
- malformed bearer token всегда `401`, а не internal error;
- roles принадлежат только `global_id` и не содержат `global_id`;
- concurrent role grant использует PostgreSQL upsert.

## 5. Test package

Локально выполняются только короткие причинные tests и collection. Реальный
PostgreSQL package содержит `9` tests: schema/constraints, one-time challenge,
concurrent consumption, hashed session, identity/global mismatch, logout,
role revoke и concurrent role grant.

## 6. Release qualification boundary

Release archive проверяется статически без импорта приложения: metadata,
manifest, purity, modes и development/release parity. Импорт FastAPI при
отсутствующем `TON_WALLET_ADDRESS` не выполняется и имеет статус
`BLOCKED_BY_REQUIRED_CONFIGURATION`; фиктивные значения не используются.

## 7. Запреты

В цикле отсутствуют public endpoints, TON Proof, Telegram adapter switch,
account/identity creation, auto-merge, backfill, dual-write, read switch и
financial changes. Цикл `1614` не начинается до fresh exact-HEAD CI.

## 8. Exit gate

```text
One-time challenge.
Hashed session.
Roles по global_id.
Fresh exact-HEAD CI PASS.
```
