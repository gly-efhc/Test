# WORK CYCLE 1472 — PANELS PORTFOLIO RUNTIME PORT

Human title: Panels Portfolio Runtime Port

Status: `DONE_LOCAL`

Archive: `v170.48`

Input HEAD: `v170.47 / Panels Portfolio Sandbox Prototype`

## Goal

Port the Panels Portfolio Dashboard idea from sandbox into the live
`/panels` runtime page without changing EFHC economics, backend state,
activation flow or write/money flows.

## Added

- `frontend/src/components/dashboard/PanelsPortfolioRuntime.tsx`;
- `docs/NORM/PANELS_PORTFOLIO_RUNTIME_PORT.md`;
- `docs/NORM/PANELS_PORTFOLIO_RUNTIME_GRAFANA_ELEMENT_ANALYSIS.md`;
- `reports/generated/panels_portfolio_runtime_port_v170_48.json`;
- `reports/change_cycle_2026-06-07_v170_48_cycle_1472_panels_portfolio_runtime_port.md`;
- `tests/architecture/test_panels_portfolio_runtime_port.py`.

## Runtime structure

- portfolio toolbar;
- active/archive filter connected to existing tab state;
- raw KPI strip;
- derived loaded-list metrics;
- summary panel;
- mini bar chart from loaded panel snapshots;
- activity strip from loaded active/archive statuses;
- runtime panel cards with countdown and lifecycle progress.

## Truth boundary

Runtime data kind: `raw + derived snapshot`.

No synthetic preview data is used in runtime.

No real time-series is claimed.

Loaded archive count is marked as loaded-list derived data, not total
archive truth.

## Boundaries

Changed: frontend runtime display, docs, tests, CSS, locales and
navigation indexes.

Not changed:

- EFHC economics;
- backend routes;
- DB migrations;
- OpenAPI;
- dependencies;
- lock files;
- CI workflows;
- panel activation price;
- debit order;
- idempotency;
- money/write flows.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## Local validation

Targeted validation is recorded in the final chat report and generated
machine report.

Not claimed:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshots;
- live Telegram proof;
- real TonConnect / wallet proof.

## Next safe cycle

`1473 — Panel Cards Deep Polish`
