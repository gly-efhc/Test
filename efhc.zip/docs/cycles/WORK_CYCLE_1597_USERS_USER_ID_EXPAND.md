# Work cycle 1597 — users.user_id EXPAND

## Input

- Development HEAD: `EFHC_Bot_v171_93.zip`.
- Target HEAD: `EFHC_Bot_v171_94.zip`.
- Exact route: `user_id_expand_migration`.

## Implemented scope

- linear Alembic revision `0002` after `0001`;
- nullable `efhc_core.users.user_id BIGINT`;
- independent sequence `users_user_id_seq`;
- range and unique constraints;
- default allocation for newly created rows;
- PostgreSQL offline fresh/install and existing-schema DDL dry-run;
- exact patch boundary protecting domain ownership and finance.

## Explicit non-scope

- no historical-row backfill;
- no `global_id` nullability change;
- no primary-key switch;
- no AuthContext/routes/services/frontend read switch;
- no TON login activation;
- no financial data mutation.

## TON account decision

A valid future TON Proof may open an existing `user_id` or create a new
`user_id`. Connection without proof is not authentication. A conflict
never triggers automatic merge.

## Exit gate

- migration chain `0001 -> 0002` is valid;
- offline PostgreSQL DDL renders and passes static safety checks;
- model and migration contracts match;
- regression and archive gates are green;
- online PostgreSQL execution remains separately reported if unavailable.

## Final local evidence

- full collection: `2795`;
- full regression: `2623 passed`, `172 skipped`, `0 failed`, `0 errors`;
- PostgreSQL business integration: `25 skipped`, DB unavailable;
- Alembic PostgreSQL offline render: exit `0`;
- online PostgreSQL execution: `NOT_RUN_DB_UNAVAILABLE`;
- semantic domain dependency rows: `2054`;
- ORM `global_id` fields: `32`; service signatures: `336`;
- patch-boundary protected files: `476`; violations: `0`.
