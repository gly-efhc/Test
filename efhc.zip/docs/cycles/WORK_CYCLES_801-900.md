# Рабочие циклы 801-900

Диапазон создан: 2026-04-10
Назначение: следующий диапазон для новых утверждённых циклов после закрытия 701-800.

## Правило диапазона
- этот файл создан заранее как следующий диапазон контроля;
- запись циклов 801-900 начинается только после прямого утверждения пользователем;
- до начала реального исполнения диапазон служит резервной рабочей линией;
- перескок из незакрытого утверждённого диапазона в 801+ запрещён.

## Текущий статус
- диапазон 801-900 создан и синхронизирован с индексом циклов;
- на момент создания файла исполнение остаётся в диапазоне 701-800;
- первые записи в этот файл вносятся только после отдельного старта 801+.

## Approved future block 801-810 (recorded only, not executed yet)
- 801-810 — SSOT-guided hardening block for shop external payment flow and reconcile architecture.
- Основание: пользователь утвердил новый SSOT-документ `SSOT-SHOP-PAYMENTS-001`, но из-за правила строгой последовательности исполнение 801+ начинается только после закрытия 701-800.

## Cycles 801-805 — shop payments external flow SSOT baseline wave 2026-04-10
- 801 — performed a full compliance audit of the current external shop payment contour against `SSOT-SHOP-PAYMENTS-001` and fixed the confirmed gap list.
- 802 — rewrote and normalized `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md` to the approved canonical wording provided by the user.
- 803 — published a detailed execution plan for cycles 801-810 with acceptance criteria and residual gaps.
- 804 — fixed a critical reconcile defect: watcher now requires exact amount equality for external shop payment confirmation instead of allowing overpayment via a soft `< expected` guard.
- 805 — added a behavioral test for non-exact amount rejection and a reproducible SSOT audit guard for the new block.

## Cycle 806 — direct PENDING alignment wave 2026-04-10
- 806 — aligned payment intent creation and owner-status examples to strict `PENDING` under the new SSOT, removed the local optimistic `SENT` transition from the deposit modal and kept `STATUS_SENT` only as a legacy alias for safe transition.


## Cycle 807 — tx-hash locks core contour wave 2026-04-10
- 807 — added a separate core-side `efhc_core.tx_hash_locks` contour with unique key on `tx_hash`, created the helper service to acquire the lock in the same transaction block before confirm update and wired fail-stop conflict handling into watcher confirmation for `deposit_efhc` and `shop_external`.


## Cycle 808 — shared payment reconciliation service wave 2026-04-10
- 808 — removed the stray `0002` migration as non-canonical, introduced `payment_reconciliation_service.py` as the shared confirmation line for `deposit_efhc` and `shop_external`, and kept watcher as orchestration over the unified service.


## Approved future block 811-820 — external payment flow continuation
- 811-820 — continuation of the same SSOT-guided shop external payment and reconciliation hardening line after full closure of 801-810.
- Основание: пользователь прямо утвердил продолжение диапазона по тому же направлению.
- Запуск 811+ допускается только после фактического закрытия 809-810.


## Cycle 809 — jetton parsing helper/service wave 2026-04-10
- 809 — added a dedicated `jetton_parsing_service.py` with strict USDT master-address allowlist semantics and delegated watcher transport parsing to that helper/service layer before the confirm path.

## Cycle 810 — compliance audit and tables/routes sync wave 2026-04-10
- 810 — synchronized SSOT table and route documents for `tx_hash_locks`, explicitly included `AdminTonReconcile` in the compliance surface and added a reproducible compliance audit guard for the external payment flow.


## Cycle 811 — ton-http-api donor audit wave 2026-04-10
- 811 — audited the newly provided `ton-http-api-master.zip` as a donor source for TON/Jetton API surface understanding and recorded that it is useful for transport shape awareness but not for direct EFHC reconcile logic adoption.

## Cycle 812 — intent payload parsing service extraction wave 2026-04-10
- 812 — extracted the nested `EFHC:` payment-intent payload parser from watcher into `intent_payload_parsing_service.py`, kept watcher aligned to the new shared parser boundary and added focused parser tests.


## Cycle 813 — strict jetton payload envelope parser wave 2026-04-10
- 813 — added a strict jetton payload envelope parser with hard USDT master-address allowlist, fail-closed invalid envelope handling and explicit transfer/transfer_notification recognition before nested EFHC payload extraction.

## Cycle 814 — jetton fraud test wave 2026-04-10
- 814 — added focused fraud tests covering fake-USDT master address, `EXCESSES` misuse and invalid envelope shape to harden the new parser before any further guard refactoring.


## Cycle 815 — reconcile diagnostics service wave 2026-04-10
- 815 — added `reconcile_diagnostics_service.py` and exposed structured diagnostics in `AdminTonReconcile` response so operator review is not limited to raw logs.

## Cycle 816 — transport precision edge fraud test wave 2026-04-10
- 816 — added focused precision-edge tests for USDT d6 and EFHC d8 transport conversion boundaries to harden the financial contour against rounding drift.


## Cycle 817 — shared confirm-path guard layer wave 2026-04-10
- 817 — added `confirm__path__guards_service.py` and moved exact asset/destination/amount guard rules into a shared service layer used by payment reconciliation.

## Cycle 818 — nanoton and commercial-policy fraud tests wave 2026-04-10
- 818 — added focused fraud tests for exact-d8 commercial policy, including rejection of extra-sign amounts and nanoton-scale overflow beyond 8 fractional digits.


## Cycle 819 — end-to-end compliance audit wave 2026-04-10
- 819 — completed a full end-to-end compliance audit for the external payment flow chain 801-819 and fixed the signal-loss gap by preserving confirm-layer reasons into `ton_inbox_logs.note`.

## Cycle 820 — extended guaranteed/fail-closed/remaining report wave 2026-04-10
- 820 — published an extended technical audit report that separates what is guaranteed, what remains fail-closed and what stays as future work for the next continuation block.


## Approved block 821-840 — blitz launch / withdrawals / monitoring / go-live
- 821-825 — Blitz-Launch (замыкание контура продаж)
- 826-830 — Withdraw + onboarding
- 831-835 — Minimal monitoring + UX
- 836-840 — Go-live + pre-release cleanup
- Основание: пользователь утвердил подробный план 821-840 в чате.


## Cycle 821 — payment_error_log field wave 2026-04-10
- 821 — added `payment_error_log` to the `shop_orders` model surface and exposed it in the admin order list as the first simple human-readable payment rejection trail.

## Cycle 822 — Force Fulfill admin rescue wave 2026-04-10
- 822 — added backend/admin Force Fulfill flow for shop orders and exposed operator rescue actions in admin shop orders and `/admin/efhc-deposits`.


## Cycle 823 — minimal ops-runner wave 2026-04-10
- 823 — added `ops/shop_payments/run_shop_payments_blitz_once.py` as a minimal Blitz-Launch runner over the existing backend scheduler core and notification scan, without creating a separate watcher microservice.

## Cycle 824 — simple bot order notifications wave 2026-04-10
- 824 — added `shop_order_notifications_service.py`, unified auto-success and manual `Force Fulfill` notification flow and started writing order-level payment rejection reasons into `payment_error_log` for simple user-facing error notices.


## Cycle 825 — RC1 mainnet test SOP template wave 2026-04-10
- 825 — added `docs/RELEASE_CANDIDATE_1.md` as a strict operator template and step-by-step SOP for the first manual mainnet test without claiming that the mainnet run has already happened.

## Cycle 826 — withdraw blitz compatibility audit wave 2026-04-10
- 826 — audited the current `/withdraw/request` contour against the Blitz manual-withdraw plan and confirmed PENDING + hold semantics without direct blockchain send logic in the request path.


## Cycle 827 — withdraw admin TonConnect contour wave 2026-04-10
- 827 — restored the operator-facing withdraw contour as ready cards with backend payout metadata, added a TonConnect wallet action path in admin withdrawals and fixed the missing SSOT by publishing `WITHDRAW_ADMIN_TONCONNECT_SSOT.md`.

## Cycle 828 — browser-shop success screen completion wave 2026-04-10
- 828 — replaced the dry confirmed-state copy in Browser-Shop with a closed success message that explicitly tells the user the balance is already credited and no further action is required.


## Cycle 829 — global USDT master-address hardcode wave 2026-04-10
- 829 — synchronized the approved USDT jetton master address across backend config and frontend TON helper layers so user/admin transport metadata do not rely on an empty or drifting value.

## Cycle 830 — short Admin SOP wave 2026-04-10
- 830 — created a short routing `ADMIN_SOP.md`, linked it to `RELEASE_CANDIDATE_1.md` and `WITHDRAW_ADMIN_TONCONNECT_SSOT.md`, and extended the withdraw SSOT with the full outbound Blitz flow provided by the user.


## Cycle 831 — watcher alert fan-out wave 2026-04-10
- 831 — upgraded admin Telegram alerts from a single watcher recipient to a fan-out list/dedicated chat contour and wired `check_ton_inbox` timeout/error paths to emit `WATCHER_ALERT` notifications.

## Cycle 832 — watcher heartbeat health strip wave 2026-04-10
- 832 — added `/health/runtime` with `watcher_last_heartbeat`/age status from `scheduler_task_log` and surfaced backend/db/watcher liveness in `AdminRouteHealthStrip`.


## Cycle 833 — synchronized 2-decimal UI rounding wave 2026-04-10
- 833 — added `formatD8ToHuman()` and applied synchronized 2-decimal rendering across key user-facing financial pages and admin payout/balance cards while keeping internal transport/request values at strict d8.

## Cycle 834 — legacy shop write isolation wave 2026-04-10
- 834 — isolated `orders_service.py` legacy write paths behind explicit read-only runtime guards, kept legacy read routes available and added a reproducible audit script proving that only read-only legacy access remains.

## Recorded future chat-audit block 846-850
- 846-850 — UX backlog recorded from explicit user requests in chat.
- Stored in `docs/audits/CHAT_AUDIT_PLAN_846_850_2026_04_10.md`.
- Execution is forbidden before the active ordered line reaches that range.


## Cycle 835 — OpenAPI freeze wave 2026-04-10
- 835 — regenerated the SSOT-derived OpenAPI snapshot and frontend seam types, then recorded the current API surface as frozen for Blitz V1 work until an explicit V2 change.

## Cycle 836 — blitz pending-intent limit wave 2026-04-10
- 836 — added a hard limit of 5 active `PENDING` payment intents per global_id/purpose for the blitz create-intent flow and recorded it as the first anti-spam guard for storefront intent creation.


## Recorded future gap-fill block 841-845
- 841-845 — UX gap-fill block added by direct user clarification after a numbering misunderstanding.
- These cycles fill the accidental gap 841-845 and do not replace any existing later backlog.
- Stored in `docs/audits/UX_GAPS_PLAN_841_845_2026_04_10.md`.
- Execution remains forbidden before the active ordered line reaches that range.


## Cycle 837 — blitz bundle cleanup sweep 2026-04-10
- 837 — audited the frontend bundle for clearly dead player-facing legacy game/event components and confirmed that only allowed admin-helper legacy surfaces remain.

## Cycle 838 — production ENV template + rule wave 2026-04-10
- 838 — rebuilt `env.prod.example`, added `docs/ENV_PROD_CHECKLIST.md` and fixed the rule that safe + medium-risk ENV data must be inserted immediately into templates/checklists while secrets stay as placeholders.


## Cycle 839 — final release gate wave 2026-04-10
- 839 — assembled a single Blitz V1 release gate script over all confirmed audit scripts, explicitly including `audit_blitz_bundle_cleanup.py`, and fixed the confirmed CI defects blocking canon checks.

## Cycle 840 — V1 release notes with first-24-hours operator section 2026-04-10
- 840 — added `docs/V1_RELEASE_NOTES.md` as the Blitz V1 release-candidate act with an explicit first-24-hours operator playbook and without claiming that production rollout has already happened.


## Cycle 841 — Blitz/V1 context actualization for gap-fill block 2026-04-10
- 841 — actualized the cycle and audit docs so the 841-845 UX gap-fill block is explicitly tied to the current Blitz/V1 release-gate context before any new UI changes are started.


## Cycle 843 — ranks jump-anchor bridge wave 2026-04-10
- 843 — added a find-me jump-anchor flow inside `/ranks`, merged the self row into the visible board and prepared smooth scroll to the player position without introducing a new full ranks route.

## Cycle 844 — neutral tasks empty/error state wave 2026-04-10
- 844 — removed raw server-error text leakage from `tasks.tsx` and switched both load-failure and no-tasks states to one neutral localized empty-state surface.


## Cycle 845 — terminal post-success bridge and local logo PNG assets 2026-04-10
- 845 — added 1.5-second terminal redirect only for withdraw terminal actions, prepared local EFHC logo PNG assets in `public/images/`, and recorded the Blitz/V1 splash-screen direction without claiming live runtime proof.


## Approved block 846-850 — splash screen + CI/doc-sync hardening
- 846-849 — canonical Splash Screen wave
- 850 — hard-fix remaining backend/doc-sync defects from fresh GitHub CI
- Основание: пользователь утвердил новый порядок после закрытия 845.

## Cycle 846 — splash screen component layer 2026-04-10
- 846 — added `SplashScreen.tsx` as a full-screen fixed overlay with the canonical EFHC SVG on a deep dark background.

## Cycle 847 — splash breathe animation 2026-04-10
- 847 — added a smooth breathe/pulse animation for the EFHC splash logo in the global stylesheet.

## Cycle 848 — splash initialization lifecycle 2026-04-10
- 848 — wired the splash screen to app initialization in `app.tsx` with fade-out and delayed unmount.

## Cycle 849 — splash Blitz/V1 integration note 2026-04-10
- 849 — fixed the splash direction as a Blitz/V1 latency-masking + branding layer and documented that it is not live-mainnet proof.


## Cycle 850 — backend/doc-sync hard-fix wave 2026-04-10
- 850 — started the hard-fix wave from the fresh GitHub CI log, corrected the safe deterministic subset of backend/doc-sync defects, updated stale NORM/SSOT count docs and restored watcher compatibility markers; full GitHub CI closure is not claimed in this pass.

## Cycle 850 — residual log-fix continuation 2026-04-11
- 850 — continued the same active tail from fresh GitHub CI logs: fixed swapped reconciliation guard reasons, removed the Bandit pass-through branch, repaired watcher/wallet typing bridge, fixed admin referral seam alias generation and reduced duplicate model-import pressure in Alembic 0001; full GitHub CI closure is still not claimed in this pass.

## Cycle 850 — compatibility/doc-sync continuation 2026-04-11
- 850 — continued the same active tail from fresh GitHub CI logs: restored watcher compatibility markers and legacy substring fallback for USDT memo parsing, added legacy shop-order extra-snapshot fallback, synced migration docs/plan to 36 tables, regenerated route inventory freeze to 95 routes, and removed the remaining banned rank substrings from active docs; full GitHub CI closure is still not claimed.

## Cycle 850 — logo canon and residual-fix continuation 2026-04-11
- 850 — continued the same active verification tail from fresh GitHub CI logs: fixed the remaining admin bank response drift, corrected reconciliation amount-guard reason, regenerated route inventory freeze with required status metadata, and refreshed the local EFHC PNG runtime assets directly from the new canonical SVG; full GitHub CI closure is still not claimed.

## Cycle 850 — 36-table canon and line72 priority continuation 2026-04-11
- 850 — after the explicit user answers, fixed the stale hard-coded 35-table lock to the approved 36-table canon, recorded that line72 remains priority №1 inside the same cycle, verified that no repo files had been silently removed in the previous pass, and continued reducing the line72 tail.

## Cycle 850 — watcher/shop compat, line72 and terms audit continuation 2026-04-11
- 850 — fixed the `amount_guard` regression, restored watcher compatibility with older `_confirm_payment_intent` shims, fixed the admin shop idempotency signature drift, removed an extra JSX closer in admin withdrawals, confirmed that frontend is only partially excluded from line72, and reduced the active line72 residual count from 115 to 102 while preparing a glossary-gap candidate set for approval.

## Cycle 850 — glossary approval and log-fix continuation 2026-04-11
- 850 — added only user-approved glossary terms with English+Russian paired naming, restored watcher transport env fallback through runtime settings, fixed the admin shop category-pills prop contract, and continued line72 reduction without claiming GitHub CI closure.

## Cycle 850 — line72 front-slice continuation 2026-04-11
- 850 — reduced the active line72 residual wave from 92 to 66, fully cleaned `audit_final_release_gate.py`, `AdminHubPage.tsx` and `BrowserShopPage.tsx` under the current scope, removed the unsupported `Button` size prop from `/admin/shop`, and recorded the exact glossary definitions for Cycle / Pass plus nearby missing candidate terms.

## Cycle 850 — terms correction, watcher USDT fallback and line72 continuation 2026-04-11
- 850 — corrected the glossary meanings for Cycle / Pass / Active range / tail / sync drift to the exact user wording, added a watcher-side USDT transport fallback for runtime settings compatibility, and cleared the active line72 overflow from `admin/withdrawals` and `AdminSalePackagesPage`; full GitHub CI closure is still not claimed.

## Cycle 850 — line72 blitz + exchange type fix continuation 2026-04-11
- 850 — restored the missing `formatD8ToHuman` import in `exchange.tsx`, then removed the active line72 overflow from the remaining backend/ops/exchange files surfaced by the fresh GitHub CI log; full GitHub CI closure is still not claimed.

## Cycle 850 — AI test-rule hardening + index type fix continuation 2026-04-11
- 850 — restored the missing `formatD8ToHuman` import in `index.tsx` and added a strict AI-layer rule: tests may be changed only after a separate user iteration with 5 clarifying questions for each test.

## Cycle 850 — test setup cast + AI rule refine continuation 2026-04-11
- 850 — refined the AI rule so that 5-question iteration is required only for changing test essence/logic, and fixed the `:extra::jsonb` test setup tail by switching to `CAST(:extra AS JSONB)` without changing the business goal of the test.

## Cycle 850 — tasks catalog type fix continuation 2026-04-11
- 850 — fixed the fresh `tasks.tsx` typing drift by adding `id` to `TaskCatalogItem`, aligning the page type with backend `TaskOut`.

## Cycle 850 — tasks next_available_at typing fix continuation 2026-04-11
- 850 — fixed the fresh `tasks.tsx` typing tail by declaring optional `next_available_at` on `MyTaskItem`, matching the page's optional access pattern.

## Cycle 850 — ruff import-tail continuation 2026-04-11
- 850 — cleaned the fresh backend/ops/tests import-order tail from GitHub CI, normalized watcher imports, removed the unused `_RE_INTENT_SUBSTR` import and moved the blitz runner app imports into the function body to avoid `E402`.

## Cycle 850 — ruff tail regression repair continuation 2026-04-11
- 850 — repaired the watcher import-hygiene regression from the previous pass by restoring the `_RE_INTENT` compatibility alias and `_CREDIT_ORIG`, then ran focused import-order normalization across the exact backend/ops/tests files surfaced by the fresh GitHub CI log; full GitHub CI closure is still not claimed.

## Cycle 850 — `_RE_INTENT` marker fix continuation 2026-04-11
- 850 — restored the literal `_RE_INTENT` compatibility marker in `watcher_service.py` after the previous lint pass collapsed the alias import, while keeping `_CREDIT_ORIG` and the watcher import block lint-clean; full GitHub CI closure is still not claimed.

## Cycle 850 — healer consolidation continuation 2026-04-11
- 850 — consolidated the confirmed system-error families from the full log and cycle history into Healer, Casebook and the registry so that the active disease memory is no longer fragmented across many tiny continuation notes.

## Cycle 850 — sterile closure 2026-04-11
- 850 — the fresh GitHub CI log `logs_64193330672.zip` passed fully (`alembic`, `bandit`, `compileall`, `flake8`, `mypy`, `npm build`, `pytest`, `ruff` all with `exit=0`), so cycle 850 is now fixed as sterily closed without opening a new range in the same pass.

## Planned block 851-870 — audit-driven release-hardening program 2026-04-11
- 851 — Withdraw audit reinterpretation: compare the release audit with the current withdraw code and reframe `payout-proof` around user-approved wallet-send confirmation semantics instead of a simplistic `tx_hash required on approve` rule.
- 852 — Withdraw status model hardening: split `request accepted`, `wallet send initiated`, `wallet send confirmed`, `on-chain pending`, `paid proven` and `repair needed` into a truthful status chain.
- 853 — Withdraw admin action-chain hardening: make the approve flow explicitly capture operator wallet-send initiation rather than silently jumping to a final-looking state.
- 854 — Withdraw wallet-provider proof bridge: design and implement the confirmation contour for Tonkeeper / MyTonWallet / compatible wallets where the decisive proof is pressing Send to bot-embedded requisites.
- 855 — Withdraw evidence trail: persist immutable wallet-send evidence, timestamps, provider kind and operator trail without pretending that blockchain arrival was already proven at approve time.
- 856 — Unified money-center architecture: define the single user-facing account / wallet / deposit / withdraw information architecture demanded by the audit.
- 857 — Wallet/deposit journey unification: rebuild the fragmented wallet/deposit/profile route graph into one clear money path with explicit prerequisites and status meaning.
- 858 — Hub→browser-shop contract hardening: audit and strengthen the signed handoff contract, token TTL, wallet-sync prerequisites and storefront bootstrap truth states.
- 859 — Browser-shop guest/auth truth layer: remove guest-mode overconfidence, expose auth/wallet-sync gating honestly and align completion states with real proof.
- 860 — Storefront payment completion proof: tighten the visible status model from intent creation to paid/fulfilled completion and surface what is guaranteed vs still pending.
- 861 — Money-path state machine hardening: define the full backend/storefront payment state chain from initiated to credited/failed/manual_review and always show the next honest user step.
- 862 — Web-profile canonical account center: establish Web-Profile as the heavy SSOT user cockpit while Telegram ProfileModal stays a light operational layer with shortcuts and current statuses.
- 863 — Thin orchestration layer for deposit entry: only after 861-862, add a slim DepositModal that reuses the canonical state machine and Web-Profile truth without duplicating business logic.
- 864 — Admin helper/draft truth-marking layer: visually and semantically separate helper / overview / draft modules from combat modules.
- 865 — Admin navigation cleanup: reorganize admin navigation so that tasks / diagnostics / ads / sale-packages cannot masquerade as equally mature release surfaces.
- 866 — Admin tasks operator restoration: turn admin tasks into a real combat operator module for creating, editing, listing and reviewing tasks instead of leaving the frontend on a helper-only shell.
- 867 — Sale-packages / ads / diagnostics release-truth pass: keep them read-only/helper where needed and align copy, badges and access paths with their real maturity.
- 868 — Release-hardening QA matrix: create the new cross-contour acceptance matrix for withdraw, wallet/deposit, hub/browser-shop, helper/draft separation and money-path truth states.
- 869 — SSOT / NORM / glossary / Healer sync for 851-868: record the new semantics, state machine, labels and risk language in project memory/docs.
- 870 — Final re-audit checkpoint: compare the post-implementation state against this new audit and decide whether the product truly moved from release-near to release-ready.

### 2026-04-11 — execution note for 851-870
- Блок 851-870 утверждён как фиксированный список циклов.
- Разрешена частичная реализация и внутренняя перегруппировка внутри
  блока, если список самих циклов не меняется.
- Стартовый фокус после audit iteration: withdraw proof semantics,
  one money-center UX, hub/browser-shop truth layer.

### 2026-04-11 — clarification on admin tasks strength
- Backend already has a strong base for admin tasks: create, list, get,
  update, delete and submission-list routes exist.
- The weak point is not the existence of the domain; the weak point is
  that the current admin page still exposes only a helper shell with
  refresh-statuses and navigation links instead of a full operator UI.
- Therefore the correct next move is not to demote the domain itself,
  but to restore the frontend/operator surface to the strength already
  implied by backend routes.

## Cycles 854-855 — withdraw send-proof bridge wave 2026-04-11
- 854-855 — started the new implementation block on the withdraw action-chain: admin approve payload now accepts wallet-send proof metadata (`payout_ref`, `wallet_send_confirmed`, `wallet_provider`, `sender_wallet_address`), the TonConnect wallet path sends this proof after `sendTransaction()`, and `tx_hash` remains optional secondary evidence.

## Cycle 856 — money-center web-profile wave 2026-04-11
- 856 — started the unified Money-Center UX direction in `WebProfilePage`: the external profile now presents an explicit 3-step financial journey (wallet sync → browser shop top-up → Telegram return for history/withdraw) instead of a generic quick-links block.


## 2026-04-11 — v166_65
- Cycle 857 advanced: `ProfileModal` now contains a unified Money-Center card linking wallet state, balance view, latest withdraw status and history without dead ends.
- Cycle 866 advanced in implementation direction: `/admin/tasks` was rebuilt from helper-only shell into a real submissions moderation surface with task selection, submissions queue and idempotent approve/reject actions.


## 2026-04-11 — v166_66
- Cycle 857 continued: `/withdraw` now carries a Money-Center context card plus recent EFHC operations, so profile -> withdraw -> history no longer breaks into blind screens.
- Cycle 866 continued: task moderation now shows an expanded proof card with timing, moderator context and proof preview/open action.


## 2026-04-11 — v166_67
- Cycle 857 continued: `/withdraw` now returns the user back into the profile Money-Center context after successful create/cancel actions, instead of dropping them on a dead-end route.


## 2026-04-11 — v166_68
- Cycle 867 advanced: added `efhc_core.system_templates`, seeded fallback keys and exposed admin CRUD routes for templates.
- Cycle 868 advanced: `/admin/templates` surface added; task moderation gained stored moderator notes, template fallback and Telegram-facing note delivery.


## 2026-04-16 — v166_69_70
- Cycle 858 advanced: strengthened the signed Hub → browser-shop contract with a dedicated truth-layer endpoint and explicit handoff/wallet/intent state.
- Cycle 859-860 advanced: browser-shop now exposes honest guest/auth/wallet gating plus active-intent resume semantics, and the visible payment path distinguishes resume/create states instead of inviting duplicate operations.

- Cycle 861 advanced: payment intents now expose a full flow-truth state model with lifecycle stage, terminal flag, next step, watcher evidence and order-level error context.
- Cycle 861 continued: browser-shop reads the backend flow truth on reload and shows honest payment guidance instead of a raw status-only badge.
- Cycle 862 started: web-profile now surfaces the active payment state as the beginning of the heavy canonical account center.


## 2026-04-16 — v166_73_74
- Cycle 862 advanced: `WebProfilePage` now acts more like the heavy canonical account center by surfacing recent intent history, order history, current payment state and withdraw-oriented shortcuts back into Telegram.
- Cycle 863 advanced: `DepositModal` was reduced to a thin launcher that reads `/hub/shop-truth`, opens the signed Browser-Shop flow and no longer maintains its own local polling/state-machine.


## 2026-04-16 — v166_75_76
- Cycle 864 advanced: helper/draft/internal admin surfaces now use soft truth-badges and top info-blocks instead of heavy warning-style headers.
- Cycle 865 advanced: admin home navigation is regrouped by combat domains, and helper / draft / internal routes are isolated into a separate cluster.
- CI repair wave: fixed undefined `settings` in `hub_routes.py`, synchronized generated payment-intent seam with `flow_truth`, refreshed 37-table migration docs and removed banned legacy rank substrings from active memory docs.


## 2026-04-16 — v166_77_78
- Cycle 867 advanced: `sale-packages`, `ads` and `diagnostics` now carry explicit release-truth classification via soft badges and top info blocks; helper/internal surfaces remain visible but secondary.
- CI repair wave: fixed stale admin-route canon for `admin_templates_routes.py`, corrected the 32-table `efhc_core` header in `SSOT_DB_SCHEMAS_TABLES.md`, restored validator declaration order for `PaymentIntentFlowTruthSchema`, and removed the fresh line72 regressions in Hub/WebProfile/payment-intent/task-notify code.


## 2026-04-16 — v166_79_80
- Cycle 868 advanced: added a release-hardening QA matrix plus a
  manual operator checklist for withdraw, wallet/deposit,
  hub/browser-shop, helper/draft separation and money-path truth.
- Cycle 869 advanced: synced glossary and AI docs to record the
  canonical meanings of helper, internal, draft, read-only,
  not release contour, Web-Profile as canonical account center,
  ProfileModal as cockpit and DepositModal as thin launcher.
- CI repair wave: fixed the `RowMapping`→`Mapping` mypy tail in
  `payment_intents_service.py` and restored the missing
  `activeIntentLabel` in `BrowserShopPage.tsx`.


## 2026-04-16 — v166_81_82
- Cycle 870 advanced as the final gate/verdict pass: the release gate now explicitly includes the active release contour plus AI-layer sync, glossary consistency and helper/internal/draft marking consistency.
- CI repair wave: fixed the remaining `RowMapping`→`Mapping` tail for `_build_intent_flow_truth(...)`, normalized the active-intent label in browser-shop to a strict string subtitle, and removed the accidental banned legacy substring from `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md` without weakening guards.
- Forbidden-word iteration recorded: broad exceptions are not allowed; only narrow, explicitly user-approved exceptions may be documented later if they are ever truly needed.

## Approved block 871-890 — post-gate release-readiness hardening, operator-proof, RC-prep 2026-04-16
- 871 — Release-Near Verdict Document: a strict status act of what is truly ready, what is only release-near and what limits still remain after cycle 870.
- 872 — Money-Path Branch Audit: verify all branches (`initiated`, `network_seen`, `manual_review`, `credited`, `failed`, `expired`, `canceled`) together with `next_step` and `user_message`.
- 873 — Manual Review Governance: define truthful entry, exit, operator actions and user messaging for `manual_review`.
- 874 — Web-Profile Hardening: strengthen the canonical account center with active payment, intent history, order history, withdraw shortcuts and clear block hierarchy.
- 875 — ProfileModal Cockpit Polish: compact summary-cockpit with balances, quick shortcuts and one lightweight active-payment block that deep-links to Web-Profile for details. [done 2026-04-16]
- 876 — Shared i18n/constants layer: create the shared copy-key and replacement-map layer before broad UI-copy migration. [done 2026-04-16]
- 877 — Deposit Entry Consistency: align Hub, Browser-Shop and profile shortcuts so every top-up entry leads into the same launcher and truth path. [done 2026-04-16 after approved reorder]
- 878 — i18n key naming/style rules: fix the naming canon for shared copy keys before rollout so future UI-string migration starts from a stable key model. [done 2026-04-16 after approved reorder]
- 879 — Helper/Internal Governance Rules: define stable criteria for assigning/removing `helper`, `internal`, `draft`, `read-only`, `not release contour`. [done 2026-04-16]
- 880 — Release-Truth UI Consistency: unify badge language, info-block tone and UI truth-marking with glossary semantics. [done 2026-04-16]
- 881 — AI Docs runtime refresh: refresh AI docs for the 870+ phase, priority stack, active model and anti-drift rules.
- 882 — SSOT / NORM / Reports Sync: synchronize cycles, reports, Q&A, glossary and AI docs after the wide 851-880 block.
- 883 — Sandbox UI Proof Pass: gather sandbox-backed evidence for the key user-facing flows.
- 884 — Hub / Browser-Shop Continuity Pass: verify refresh / return / resume behavior across `expired`, `canceled`, `manual_review` and related continuity states.
- 885 — User-Facing Copy Pass: align statuses, instructions, errors and next-step language into one truthful user copy layer.
- 886 — High-Risk Gap List: isolate only the real high-risk tails without noise.
- 887 — High-Risk Closure Pass: close only the critical tails surfaced by cycle 886.
- 888 — Outcome Domain Foundation: add `withdraw_outcome_events` and `outcome_fallback_promos` so withdraw result becomes a managed domain object.
- 889 — Locale-Aware Comment Resolver: build backend comment resolution from profile language, system templates, fallback chain and manual override flags.
- 890 — Promo Resolver + Fallback Promo EFHC: success gets promo zone through backend fallback promo; reject gets no promo zone.
- 891 — Outcome Bundle Builder API: add one runtime endpoint that returns outcome kind, locale, comment block, promo block/null and metadata.
- 892 — Withdraw Lifecycle Integration: generate and persist resolved outcome events directly from approve/reject flow.


## Cycle 871 — release-near verdict document and forbidden words SSOT wave 2026-04-16
- 871 — published a strict release-near verdict layer for the post-870 state, fixed the frontend validator declaration-order tail from fresh CI logs and formalized forbidden words / narrow exceptions policy as a dedicated SSOT anchor for future anti-drift passes.


## Cycle 872 — money-path branch audit and UI replacement audit pass 2026-04-16
- 872 — fixed fresh CI tails in generated validators and tg_id runtime alias guard scope, published the canonical money-path truth table (`status -> lifecycle_stage -> next_step -> user_message`) with terminal/non-terminal policy, and added a controlled hardcoded UI strings replacement list for future i18n migration without mass copy refactor in this cycle.


## Cycle 873 — manual review governance 2026-04-16
- 873 — fixed the active admin tab type tail and the remaining generated validator line72 tail, then published a strict governance table for `manual_review` with entry rules, owner, allowed operator actions, exit conditions and user wording.
- 873 — added a high-risk UI strings priority map (`wallet`, `deposit`, `withdraw`, `browser-shop`, `profile`) for future migration without mass copy refactor in this cycle.


## Cycle 874 — web-profile hardening 2026-04-16
- 874 — fixed the fresh frontend CI blocker in `admin/withdrawals` and strengthened `WebProfilePage` around the canonical account-center journey `Current state -> History -> Actions`, keeping shortcuts moderate and avoiding a dense operator cockpit.


## 2026-04-16 — v166_87_88
- Cycle 875 advanced: `ProfileModal` now stays a compact summary-cockpit but shows one light active-payment block with quick status and a deep-link into Web-Profile for details.
- Cycle 876 advanced: shared copy-layer groundwork was added through `uiKeys` and `uiConstants`, without starting mass UI-string migration.

## 2026-04-16 — v166_89_90
- Cycle 877 advanced: Hub, ProfileModal, Web-Profile and shop-entry now converge into one launcher behavior through the same canonical shop launcher and backend/storefront truth path.
- Cycle 878 advanced: i18n key naming/style rules were fixed before rollout, so future UI-string migration can start from a shared canon instead of fragmented ad-hoc keys.


## 2026-04-16 — v166_91_92
- Cycle 879 advanced: published a strict decision-table for `helper`, `internal`, `draft`, `read-only`, `not release contour` and `manual`, with assignment/removal criteria, prohibitions and typical page examples.
- Cycle 880 advanced: aligned release-truth UI language around consistent badges and `Release-truth classification` info-block wording, and removed the `non-release` synonym in favor of the glossary canon `not release contour`.


## 2026-04-16 — v166_93_94
- Cycle 881 advanced: refreshed AI docs so the active prompt-layer now reflects the confirmed post-gate contour 871-880 and includes a short preface about the prepared but not yet started block 893-900.
- Cycle 882 advanced: completed the broad sync pass across cycles, reports, Q&A, glossary, AI docs and the strategic Telegram-first / one-profile / external-sector SSOT/TZ layer, so that this strategic frame no longer lives as an isolated appendix.

## 2026-04-16 — v166_95_96
- Cycle 883 advanced: published a sandbox-backed UI proof pass centered on the user-facing contour (`Hub`, `Browser-Shop`, `Web-Profile`, `ProfileModal`, launcher flow) and included only a light admin evidence block for release-truth marking.
- Cycle 884 advanced: published the continuity pass across `expired`, `canceled`, `manual_review` and mandatory `credited` re-entry anti-confusion behavior, keeping one continuity truth across Hub/storefront/profile surfaces.

## Executed block 893-900 — outcome rollout and trust hardening 2026-04-16
- 893 — Product Canon Alignment Pass: align Telegram-first, one-profile, external sector and outcome-service canon across active docs.
- 894 — Admin Outcome Controls: preview comment template, manual override input, locale preview and promo preview for operators.
- 895 — Templates Admin Expansion: add domain/locale filters, preview mode, success tone variants and strict-neutral reject templates.
- 896 — Fallback Promo Management: manage fallback promo EFHC texts, CTA, images, locales and contexts.
- 897 — Outcome UI Integration in Web-Profile: render success promo + comment block and reject comment-only layout in the canonical account center.
- 898 — Telegram Delivery Alignment: deliver the same resolved outcome bundle into Telegram without a second independent text path.
- 899 — Auto-Translation Controlled Layer: store source text, translated result and provenance without replacing canonical templates.
- 900 — Outcome Trust Re-Audit: independently verify tone, locale correctness, promo correctness and one-profile consistency.


## 2026-04-16 — v167_00_01
- 888-892 — started and advanced together as one outcome-service wave: withdraw result now has a backend-managed outcome domain, locale-aware comment resolver, fallback promo EFHC, runtime outcome API and lifecycle persistence from admin approve/reject.


## Cycle 893 — product canon alignment pass 2026-04-16
- 893 — aligned active product wording and docs around outcome-service, one-profile, Telegram-first and external economic sector.

## Cycle 894 — admin outcome controls in /admin/withdrawals 2026-04-16
- 894 — added case-level outcome preview directly inside `/admin/withdrawals`; `/admin/templates` remains a governance surface.

## Cycle 895 — preview and override contract expansion 2026-04-16
- 895 — expanded preview-safe contracts for comment override and auto-translation flags in the admin withdraw contour.

## Cycle 896 — migration canon healing for outcome-service 2026-04-16
- 896 — outcome schema was integrated into `0001_init.py`; separate `0002+` migration remains forbidden before release.

## Cycle 897 — Web-Profile outcome screen 2026-04-16
- 897 — integrated the latest withdraw outcome into Web-Profile with success promo zone and reject comment-only layout.


## Cycle 898 — Telegram delivery alignment 2026-04-16
- 898 — added a short Telegram outcome delivery path that sends only a compact notification plus a signed Web-Profile link, keeping Web-Profile as the canonical full outcome surface.

## Cycle 899 — controlled auto-translation boundary 2026-04-16
- 899 — kept auto-translation strictly limited to manual override comments; promo copy remains locale-prepared and is not machine-translated in this phase.

## Cycle 900 — outcome trust re-audit 2026-04-16
- 900 — completed an independent re-audit of admin preview, stored outcome bundle, Web-Profile rendering and Telegram delivery to confirm one-profile continuity and success/reject separation.
