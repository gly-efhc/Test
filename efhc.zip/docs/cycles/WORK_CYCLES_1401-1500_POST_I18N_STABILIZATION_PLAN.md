## 1446 — CI rerun log repair / v170.22 — DONE locally

- HEAD input: `EFHC_Bot_v170_21_cycle_1445_ci_log_repair_bnb_skin_cleanup.zip`.
- Input logs: `logs_72627437860.zip`.
- Scope: read fresh logs first, repair factual CI failures, update docs,
  and keep release-ready wording forbidden until new proof.
- Root cause repaired:
  - ruff `I001` import-order drift in admin bank and transactions service;
  - pytest historical-audit status note failure in `ROUTE_INVENTORY_FREEZE.md`.
- Added guard: `tests/architecture/test_ci_log_repair_guards.py`.
- Added report: `reports/generated/ci_log_repair_v170_22.json`.
- Runtime business logic changed: no.
- EFHC economy changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Local validation:
  - log-repair guards: `5 passed`;
  - kernel/filename guard subset: `13 passed`;
  - `py_compile` touched backend Python files: passed.
- Not claimed: GitHub CI green, full pytest green, frontend build green,
  live proof gates or release-ready.
- Current progress for `1401-1500`: done `46 / 100`, remaining `54 / 100`.
- Next safe planned cycle: `1447 — fresh CI rerun proof / release-gate
  preparation`, or next log repair if fresh logs fail.

## Cycle 1444 — Linkage repeat audit + HEALER tail reconciliation

Status: DONE locally in `v170.20`.

- Local repeat audit for `F-001…F-008` produced `status=ok`, `blockers=[]`.
- Report: `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`.
- Guard: `tests/architecture/test_linkage_repeat_audit_healer_tail.py`.
- HEALER loader/schema tail reconciled in `ops/healer/loader.py` and `ops/healer/run_once.py`.
- `F-006` remains live FastAPI/CI proof pending; no release-ready claim.
- Next: `1446 — CI rerun log reconciliation or next fresh log repair`.

## Cycle 1441 — Admin wallet reset semantic repair

Status: DONE locally in `v170.17`.

- Repaired `F-005`: admin wallet reset now fully unbinds canonical `efhc_core.wallet_bindings`.
- Legacy `users.ton_wallet` cleanup remains only compatibility cleanup.
- New service helper: `wallets_service.admin_reset_wallet_bindings()`.
- Frontend reset action is not blocked solely by stale legacy `selected.ton_wallet`.
- Guard file: `tests/architecture/test_admin_wallet_reset_semantic_repair.py`.
- Remaining next step: `1442 — OpenAPI rebuild and strict contract gate`.

## Audit/HEALER tail routing after cycle 1441

- `1442`: OpenAPI rebuild and strict contract gate (`F-006`).
- `1443`: Full linkage architecture tests and critical UI state guards (`F-007`, `F-008`).
- `1444`: Repeat linkage audit + HEALER tail reconciliation.
- `1445`: CI/log proof and residual audit-tail closure if fresh logs are supplied.

## Cycle 1440 — Admin Hub route prefix repair

Status: DONE locally in `v170.16`.

- Repaired `F-004`: Admin Hub route prefix drift.
- Runtime Admin Hub routes now live in `backend/app/routes/admin_hub_routes.py`.
- Canonical path `/admin/hub/*` is enforced; Hub router is not nested under `/admin/shop/*`.
- Guard file: `tests/architecture/test_admin_hub_route_prefix_repair.py`.
- Remaining next step: `1441 — Admin wallet reset semantic repair`.

## Cycle 1439 — Admin reports bank table repair

Status: DONE locally in `v170.15`.

- `F-003` repaired: `/admin/reports/overview` now reads canonical `efhc_core.bank_balance` / `EFHC_MAIN`.
- Legacy `efhc_admin.bank_balances` is no longer used by the reports overview route.
- New guard: `tests/architecture/test_admin_reports_bank_ssot_repair.py`.
- Future bank mint/rewrite via migrations is guarded: only genesis seed in `0001_init.py` is allowed.
- Remaining next step: `1440 — Admin Hub route prefix repair`.

## Cycle 1438 — P0 Deposit watcher wallet SSOT repair

Status: DONE locally in `v170.14`.

- `F-002` repaired: deposit watcher wallet lookup now uses canonical `efhc_core.wallet_bindings`.
- Admin replay uses the same `process_incoming_tx()` canonical path as scheduler watcher.
- New guard: `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`.
- Remaining next step: `1439 — Admin reports bank table repair`.

## Cycle 1437 — P0 Bank SSOT repair

Status: DONE locally in `v170.13`.

- `F-001` repaired: admin bank mint/burn now use existing official/canonical tables only.
- No separate mint/burn ledger/table was created.
- New guard: `tests/architecture/test_admin_bank_ssot_repair.py`.
- Remaining next step: `1439 — Admin reports bank table repair`.

## Cycle 1436 — migrations/routes/backend-frontend linkage freeze

Status: DONE. Archive: `EFHC_Bot_v170_11_cycle_1436_migrations_routes_linkage_freeze.zip`.

The P0 linkage audit for v170.10 is now an active release blocker. Next planned
repair lane:

- 1437: P0 Bank SSOT repair.
- 1438: P0 Deposit watcher wallet SSOT repair — DONE locally in v170.14.
- 1439: Admin reports bank table repair — DONE locally in v170.15.
- 1440: Admin Hub route prefix repair — DONE locally in v170.16.
- 1441: Admin wallet reset semantic repair — DONE locally in v170.17.
- 1442: OpenAPI rebuild and strict contract gate.
- 1443: Full linkage architecture tests.
- 1444: Linkage repeat audit + HEALER tail reconciliation.
- 1445: CI/log proof and residual audit-tail closure if fresh logs are supplied.

No runtime, test, CI, workflow or lock-file changes were made in cycle 1436.

# Work cycles 1401-1500 — post-i18n stabilization

Status: ACTIVE / OPEN after the repeat i18n audit supplied on 2026-06-03.
Activation source: `docs/audits/I18N_REAUDIT_REPORT_V169_82_2026_06_03.md`.

## Activation rule satisfied

The previous range `1390-1400` was closed in v169.82. The user supplied a new
repeat i18n audit for v169.82. Therefore cycle 1401 is allowed to open as an
audit-driven repair cycle.

## Cycle 1401 — DONE

Goal: repair LOW false-positive i18n signals from the repeat audit.

Done in v169.83:

- added `FAQ` to the exact-value allowlist;
- added compact time-unit labels `h`, `d`, `m` to the exact-value allowlist;
- preserved existing `s` allowlist entry;
- added shared helper `ops/i18n/locale_quality_allowlist.py`;
- wired 10 wave-3 locale value-quality scripts to the shared allowlist;
- added exact false-positive phrase `Цена панели фиксирована` to the
  gambling/chance contour;
- archived the repeat audit source inside `docs/audits/`;
- added active regression guard
  `tests/architecture/test_i18n_reaudit_low_signal_repair.py`.

## Current progress

- Range: `1401-1500`.
- Done: `41 / 100`.
- Remaining: `59 / 100`.
- Next: `1442 — OpenAPI rebuild and strict contract gate`.

## Non-claims

This plan does not claim GitHub CI green, full pytest green, frontend build,
screenshots, Telegram client proof, real wallet proof or release readiness.

## Cycle 1402 — DONE

Goal: repair public/shared hardcoded i18n strings found by the v169.83 audit/TZ.

Done in v169.84:

- replaced audited hardcoded copy in `ErrorBoundary.tsx` with i18n keys via an
  optional translator prop for the class component;
- localized public admin-route guard copy in `_app.tsx` through `admin_guard.*`;
- localized AdsBanner, EnergyGauge, Modal close aria and TelegramProductCard
  image placeholder;
- removed the `SurfaceFactsStrip` English default after confirming all call
  sites pass `title`;
- localized optional low-risk accessibility/component strings in GlobalHeader,
  ShopLayout and TelegramProductCard;
- added `tests/architecture/test_i18n_hardcoded_strings_guard.py`.

## Current progress after cycle 1402

- Range: `1401-1500`.
- Done: `41 / 100`.
- Remaining: `59 / 100`.
- Next: `1442 — OpenAPI rebuild and strict contract gate`.

## Cycle 1403 — DONE

Goal: audit and plan P0 / Red Zone backend repairs and the `states.py` split.

Done in v169.85:

- read active AI/NORM/SSOT/testing/cycle documents and `map_element.md`;
- checked P0 issues HEAL-0023, HEAL-0024, HEAL-0018, HEAL-0045, HEAL-0040 and HEAL-0044;
- confirmed active defects in HEAL-0045 and HEAL-0040;
- confirmed residual risk lanes for HEAL-0023, HEAL-0024, HEAL-0018 and HEAL-0044;
- checked `backend/app/bot/states.py` and confirmed SRP violation;
- added P0 backend repair plan and FSM split TZ;
- did not change runtime code.

## Current progress after cycle 1403

- Range: `1401-1500`.
- Done: `3 / 100`.
- Remaining: `97 / 100`.
- Next: `1404 — HEAL-0045 global_id identity canon repair`, unless fresh logs are supplied first.

## Range lane update after cycle 1403

The range is no longer only post-i18n stabilization. By direct user command, it now includes P0 backend financial/identity stabilization and the planned FSM split lane. The original i18n stabilization work remains preserved and closed for cycles 1401-1402.


## v169_86 / cycle 1404 update

Cycle 1404 recorded user decisions for HEAL-0040, HEAL-0024/0018 and FSM split, and added the HEAL-0055 deposit-cache lane. Active repair planning moved to `docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`. Next planned cycle is 1405 — HEAL-0045 global_id identity canon repair.



## v169.87 / cycle 1405 update

Cycle 1405 completed `HEAL-0045` global_id identity canon repair. The confirmed
`referrals_crud.admin_top_inviters()` drift from Telegram ID to internal
`users.id` was repaired and locked by
`tests/architecture/test_heal0045_global_id_identity_canon.py`.

Next planned P0 cycle: `1408 — HEAL-0023 idempotency read-through conflict hardening`. Cycles 1406-1407 closed in v169.88 for HEAL-0040 and HEAL-0044.


## v169_89 / cycles 1408-1409 P0 idempotency and transaction-boundary map update

- `HEAL-0023`: explicit `IDEMPOTENCY_CONFLICT` marker is handled by shared read-through conflict detection.
- `HEAL-0018`: transaction-boundary map is recorded; runtime transaction-boundary rewrite remains scheduled for cycle 1410.
- Active plan remaining: 11 cycles (`1410-1420`).
- No sandbox runtime, CI, lock file, wallet/payment donor logic or translations were imported.

## v169_90 / cycles 1409-1410 P0 transaction-boundary repair update

- Cycle 1409 transaction-boundary map remains the repair base.
- Cycle 1410 applied the first HEAL-0018 runtime repair:
  `transactions_service._tx_context()` no longer uses hidden `begin_nested()`
  fallback, and `exchange_service` closes read-only preflight autobegin before
  money-service entry.
- Active plan remaining: 10 cycles (`1411-1420`).
- Next planned P0 cycle: `1411 — HEAL-0024 exchange/withdraw atomicity repair`.

## v169.91 cycles 1410-1411 update

- HEAL-0024 primary withdraw atomicity repaired: request row, hold transfer, audit meta and `hold_done=TRUE` are now in one service-owned transaction boundary.
- Operator Kernel refresh optimization added: `ops/operator_kernel/refresh.sh`; `routes.yaml` versioned as `version: 1` and validated during load.
- Next planned P0 cycle: `1412 — HEAL-0055 deposit-cache DB idempotency proof`.

## v169.92 / cycle 1412 status

Cycle 1412 is complete. HEAL-0055 deposit duplicate protection now uses long-retention `efhc_admin.idempotency_key` records and Operator Kernel Start Core preload is mandatory. Remaining active plan cycles: `1413-1420`.


## v169_95 cycles 1417-1420 update

The active P0 backend/FSM subrange `1404-1420` is closed. FSM implementation
was split into `backend/app/bot/fsm/` modules with `backend/app/bot/states.py`
kept as a compatibility facade. Remaining work in the broader `1401-1500`
range should start from a new audit/log/task rather than continuing the closed
subrange automatically.


## v169.96 / cycle 1421 CI log repair

- Source logs: `logs_72253479436.zip`.
- Fixed pytest failures after FSM split and HEAL-0055 metadata update.
- The `1404-1420` subplan remains closed.
- Broader `1401-1500` range remains active only by direct user task, fresh logs or new audit.

## v169.97 / cycle 1422 economic risk repair

- Activation source: user supplied P0 economic audit with verdict `P0_ECONOMIC_RISK_FOUND`.
- Cycle 1422 closed the first surgical repair pair:
  - `FIND-002` all-bonus spend idempotency retry/read-through;
  - `FIND-004` admin manual debit TypeError from nonexistent kwargs.
- Active guard added: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `22 / 100`, remaining `78 / 100`.
- Next safe planned cycle: `1423 — FIND-001 panel activation atomicity`, after architecture decision confirmation.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.

## v169.98 / cycle 1423 panel activation atomicity repair

- Activation source: direct user task plus confirmed architecture answer `A` for `FIND-001`.
- Cycle 1423 closed the P0 panel activation atomicity risk:
  - `transactions_service.py` now has `spend_user_to_bank_bonus_then__main__nocommit`;
  - `panels_service.py` owns the single transaction for spend plus panel creation;
  - panel activation replay reads both `:main` and `:bonus` transfer logs.
- Active guard updated: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `23 / 100`, remaining `77 / 100`.
- Next safe planned cycle: `1424 — FIND-003 withdraw refund split + FIND-005 exchange TOCTOU`.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.


## v169.99 / cycle 1424 withdraw/exchange atomicity repair

- Activation source: direct user task plus previously confirmed architecture
  answers for `FIND-003` and `FIND-005`.
- Cycle 1424 closed the remaining P1 economic risks:
  - withdraw cancel/reject final status and refund now share one transaction;
  - exchange idempotency proof moved inside the lock/retry loop;
  - exchange helpers close direct-call preflight/autobegin state at entry.
- Active guard updated: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `24 / 100`, remaining `76 / 100`.
- Next safe planned cycle: `1425 — FIND-006..010 cleanup and reconciliation hardening`.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.


## v170.00 / cycle 1425 economic cleanup and reconciliation hardening

- Activation source: direct user task to continue cycle `1425`.
- Cycle 1425 closed remaining P2/P3 findings from the P0 economic audit:
  - `FIND-006` false zero-amount rejected exchange transfer log;
  - `FIND-007` direct exchange transaction-boundary safety guard;
  - `FIND-008` duplicate withdraw `_tx_context`;
  - `FIND-009` strict kWh check SSOT calculation;
  - `FIND-010` bonus credit audit meta persistence.
- Reconciliation hardening documented for `INV-08`.
- Active guard updated: `tests/architecture/test_economic_risk_guards.py`.
- Current progress for `1401-1500`: done `25 / 100`, remaining `75 / 100`.
- The `1422-1425` economic audit repair lane is locally complete. Next safe step: fresh CI log, release audit, or new user task.

Non-claims remain: no GitHub CI green, full pytest green, frontend build,
screenshot proof, live Telegram proof, real wallet proof or release-ready claim.

## v170.01 / cycle 1426 economic re-audit cleanup note

Cycle 1426 was opened by direct user task after the v170.00 economic re-audit
verdict `ECONOMY_SAFE_WITH_MINOR_FINDINGS`. It closed the only new P3 finding:
removed the unused local `panels_service._tx_context` helper that still used
`db.begin_nested()` and added an active guard against reintroduction.

Current broader range progress: done `26 / 100`, remaining `74 / 100`.
Next safe step: release audit, fresh CI log, or new user task.

No GitHub CI green, full pytest green, frontend build, browser screenshot, live
Telegram proof, wallet proof or release-ready status is claimed by this note.

## v170.02 / cycle 1427 CI log repair note

Cycle 1427 was opened by direct user task with `logs_72342361356.zip`.
The log canon was followed: logs were read first, exact failures were mapped,
then root causes were repaired.

Closed log failures:

- ruff `I001` import ordering in `withdraw_service.py`;
- line72 violations in `panels_service.py`;
- degraded `_main_` tokens in new helper/test names;
- Healer atlas schema drift in `atlas.json`.

Current broader range progress: done `27 / 100`, remaining `73 / 100`.
No GitHub CI green, full pytest green, frontend build, browser screenshot,
live Telegram proof, wallet proof or release-ready status is claimed.

## v170.03 / cycle 1428 security audit reconciliation

- Activation source: supplied P0 security audit with verdict
  `P0_RELEASE_BLOCKED`.
- This was a planning/reconciliation cycle, not runtime repair.
- Truth split resolved: the audit title points to `v170.01`, but the audit body
  and current archive line use `v170.02`; follow-up security repair starts from
  the actual latest HEAD.
- Questions answered: TonConnect proof is the production wallet binding canon;
  both backend entrypoints must converge; final verdicts use actual HEAD.
- Next safe planned cycles: `1429-1431`.
- Current progress for `1401-1500`: done `28 / 100`, remaining `72 / 100`.

Non-claims remain: no P0 fixed claim, no GitHub CI green, no full pytest green,
no frontend build, no screenshot proof, no live Telegram proof, no real wallet
proof and no release-ready claim.

## v170.04 / cycle 1429 P0 security repair

Cycle 1429 was opened by direct user task after the security reconciliation
cycle 1428. It repaired the two P0 release blockers locally:

- wallet binding now requires verified TonConnect proof and only verified active
  bindings satisfy wallet gates;
- `/cron/tick` requires a real ENV secret in prod/stage and no longer has a
  working repository-known default secret.

Current broader range progress: done `29 / 100`, remaining `71 / 100`.
Next safe step: cycle `1430` for P2 replay / OPSEC / legacy headers, unless a
fresh CI log, repeat audit or direct user task changes the order.

No repeat security audit pass, GitHub CI green, full pytest green, frontend
build, browser screenshot, live Telegram proof, real wallet proof or
release-ready status is claimed by this note.


## Cycle 1430 update — security P2 replay / OPSEC repair

Cycle 1430 is DONE locally. It closes the P2 layer from the active security
audit: strict Telegram `auth_date`, expanded production secret redaction aliases
and removal of legacy frontend/admin identity headers from runtime/CORS
compatibility layers. Next planned security step is cycle 1431 regression
hardening and repeat-audit preparation.


## Cycle 1431 update — security regression hardening

Cycle 1431 is DONE locally. It adds the repeat-audit preparation guard layer
after security cycles 1429-1430 and repairs Telegram webhook order so the
webhook secret is checked before dedupe registration. Current broader range
progress: done `32 / 100`, remaining `68 / 100`.

No repeat security audit pass, GitHub CI green, full pytest green, frontend
build, browser screenshot, live Telegram proof, real wallet proof or
release-ready status is claimed by this note.


## Cycle 1432 — CI log repair after security hardening

Status: DONE
Archive: `EFHC_Bot_v170_07_cycle_1432_ci_log_repair.zip`
Source log: `logs_72432961872.zip`

Closed factual CI failures after cycles `1429–1431`: ruff UP037, Bandit
legacy digest naming, SSOT table-count drift (`43` ORM tables), stale panel/spend
guards, Healer enum drift and wallet proof replay ordering.

## Cycle 1433 update — Operator Kernel First Standard hardening

Cycle 1433 is DONE as docs-only Kernel hardening. It adds
`docs/NORM/EFHC_OPERATOR_KERNEL_FIRST_STANDARD.md` and aligns Kernel entry,
reading entrypoint, protocol, permission/patch/validation standards, routes,
file_map, Q&A, reports and guard manifest. Current broader range progress:
done `33 / 100`, remaining `67 / 100`.

No runtime, security/auth, money-flow, test, CI/workflow or lock-file change is
claimed by this note.


## Cycle 1434 update — security minor findings repair

Cycle 1434 is DONE locally. It closes the remaining v170.08 security audit
minor findings: `ADS_TEST_MODE` prod/stage fail-fast, monetary rate-limit
coverage for `/deposit` and `/payment-intents`, and OPSEC placeholder cleanup in
`env.prod.example`. Current broader range progress: done `34 / 100`, remaining
`66 / 100`.

No GitHub CI green, full pytest green, frontend build, browser screenshot, live
Telegram proof, real wallet proof or release-ready status is claimed by this
note.


## Cycle 1435 update — cold start MVP UX asset optimization

Cycle 1435 is DONE locally. Cold start is not treated as an MVP blocker
when cached shell first, loading/effect and stale-while-revalidate are
preserved. The Energy first-paint bot image now uses
`frontend/public/skins/1.webp` at 197,804 bytes. Current broader range
progress: done `35 / 100`, remaining `65 / 100`.

## v170.18 / cycle 1442 update

Cycle 1442 completed the checked-in OpenAPI rebuild and strict static contract gate.

- `F-006` is repaired locally for the checked-in OpenAPI/route snapshot.
- OpenAPI snapshot now has `116` paths and `121` operations from backend route source.
- New guard: `tests/architecture/test_openapi_rebuild_strict_contract_gate.py`.
- Guard report: `reports/generated/openapi_strict_contract_gate_v170_18.json` with `status=ok`.
- Live FastAPI `app.openapi()` proof is not claimed in the local tool environment because runtime dependency `sqlalchemy` is missing.
- Current progress: `42 / 100` done, `58 / 100` remaining.
- Next planned cycle: `1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards`.

## Cycle 1443 — completed locally

- `F-007` and `F-008` local guard layer added.
- New scanner: `ops/linkage/build_full_linkage_report.py`.
- New report: `reports/generated/full_linkage_report_v170_19.json`.
- New guard: `tests/architecture/test_full_linkage_architecture_and_ui_states.py`.
- Next: `1444 — Linkage repeat audit + HEALER tail reconciliation`.


## 1445 — CI log repair + BNB/source skin cleanup / v170.21 — DONE locally

- HEAD input: `EFHC_Bot_v170_20_cycle_1444_linkage_repeat_audit_healer_tail_reconciliation.zip`.
- Logs input: `logs_72623328892.zip`.
- Fixed factual CI failures: ruff import-order/E402, mypy Decimal/Optional drift, admin bank road guard drift, admin hub route module guard drift, Kernel fallback marker, line72 tooling violations, route freeze markdown drift, Healer atlas compact schema drift, wallet hardening test state bleed.
- Removed old BNB/source skin: `frontend/public/skins/1.png`.
- Canonical skin asset is now WebP: `frontend/public/skins/1.webp`.
- Added report: `reports/generated/ci_log_repair_v170_21.json`.
- No test was deleted, archived, skipped, xfailed or hidden.
- Not claimed: GitHub CI green, full pytest green, frontend build, release-ready, screenshots, live Telegram proof or real wallet proof.
- Current progress for `1401-1500`: done `45 / 100`, remaining `55 / 100`.
- Next safe planned cycle: `1446 — CI rerun log reconciliation or next fresh log repair`.

## v170.24 / cycle 1448 update

Cycle 1448 closed two P2 linkage housekeeping findings from the v170.23
full linkage audit. The full linkage report/test now targets
`1448 / v170.24`, and Admin Hub frontend routes use generated
`adminSeams.ts` constants/types instead of raw `/admin/hub/*` API path
literals.

No economy, migration, CI/workflow or lock-file change was made.
