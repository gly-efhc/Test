# WORK CYCLE 1421 — CI log repair after FSM split

Status: DONE.
Date: 2026-06-04.
Archive output: `v169_96`.

## Input

- HEAD: `EFHC_Bot_v169_95_cycles_1417_1420_fsm_states_split_range_closure.zip`.
- Logs: `logs_72253479436.zip`.

## Log facts

CI logs were read first. Gate summary showed only pytest failed; flake8, ruff, mypy, bandit, compileall, Alembic and frontend build were green in the supplied logs.

Pytest reported:

- `3 failed, 1173 passed, 8 skipped, 1 warning`.

Failing tests:

1. `test_archive_filename_hygiene.py::test_no_numbered_work_pass_labels_in_non_exception_docs_and_indexes`.
2. `test_no_raw_create_task.py::test_no_raw_asyncio_create_task_outside_helper`.
3. `test_p0_heal_alignment_deposit_cache_docs.py::test_healer_0055_elevated_and_planned`.

## Root causes

- FSM split introduced a raw `asyncio.create_task()` in `backend/app/bot/fsm/manager.py`.
- Some non-exception docs and the `states.py` compatibility facade contained numbered work-pass wording.
- `atlas.json` still contained stale HEAL-0055 wording from before the long-retention repair.

## Repairs

- Replaced raw background task spawning in `backend/app/bot/fsm/manager.py` with `create_logged_task()`.
- Reworded non-exception docs and facade comments to avoid numbered work-pass labels while preserving traceability in allowed cycle/audit/report layers.
- Updated `atlas.json` HEAL-0055 confirmation basis to state that DB-backed deposit idempotency and long-retention policy are already repaired.

## Checks

- Exact failing pytest tests pass locally.
- Ruff and focused architecture checks were run locally after repair.
- No tests were deleted, archived, skipped, xfailed or hidden.

## Status

DONE. The next action is fresh CI/log confirmation or a new audit/task.
