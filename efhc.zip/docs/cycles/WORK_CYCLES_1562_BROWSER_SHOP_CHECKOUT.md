# Cycle 1562 — repeated Browser Shop and guarded visual restoration

Status: `DONE_LOCALLY_WITH_CONTROLLED_BROWSER_PROOF`.

## Input and output

- Input: `EFHC_Bot_v171_37.zip`.
- Output target: `EFHC_Bot_v171_38.zip`.
- This is a corrective repeat of cycle 1562, not cycle 1563.

## Browser Shop

Verified locally:

- TON/GRAM and USDT payment methods;
- Telegram handoff and Web access-key linking;
- return to the same token, SKU and payment method;
- payment-intent creation;
- backend `expires_at` as the TTL source;
- React Query status polling every five seconds;
- polling stops on terminal state;
- active-intent resume, wallet-sync and `flow_truth`;
- compact mobile and tablet checkout surfaces.

## Restored HUB canon

- HUB contains exactly two canonical actions:
  `Пополнение` and `EFHC VIP NFT`;
- `Пополнение` contains no purchase, asset, price or checkout wording before
  the external transition;
- the VIP action opens the official GetGems collection;
- deletion of either guarded function requires a direct user decision.

## Restored Energy canon

Energy contains only:

- generated kWh;
- exact progress;
- current `Lvl N` and canonical level name;
- active panels;
- generation rate;
- available kWh.

It does not render Wallet balances, EFHC action cards or Exchange actions.
The available-kWh unit is not duplicated.

## Navigation

- six equal-width rounded rectangular cells;
- small equal gaps;
- almost full phone width;
- one coherent rounded-outline SVG family;
- route order unchanged.

## Guard contradiction repair

The accepted `v171_36` two-action HUB guards were inverted during `v171_37`
and Energy guards were changed to require wallet/exchange blocks and hide
level names. These changes were unauthorized. The audit and permanent repair
are recorded in:

`docs/audits/RECENT_GUARD_CONTRADICTION_AUDIT_1562.md`.

## Evidence

- architecture inventory: `2125 passed`, `7 skipped`, `0 failed`;
- full regression: `2296 passed`, `135 skipped`, `0 failed`;
- controlled Browser Shop and visual Chromium E2E: `2 passed`;
- seven current screenshots in
  `reports/screenshots/browser_shop_1562_repeat/`;
- two consecutive production builds: `34 / 34` pages;
- live Telegram linking and real payments are not claimed.

## Next cycle

`1563 — TonConnect manifest, restore, TonProof and transaction UX`.
