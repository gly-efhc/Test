# Work cycles 1210-1230 — corrected visual plan

## Cycle 1210 — infrastructure and visible function triage

Apply the user's correction list:

- Docker backend docs copy;
- compose `/api/health` healthcheck;
- Telegram SDK in `_document`;
- shared Modal as bottom-sheet;
- focused modal/header/shell CSS additions;
- GlobalHeader visual adaptation without breaking actions;
- Layout Telegram/game-shell navigation without changing the six bottom
  menu buttons;
- visible functions table: leave/delete/admin/question.

## Cycle 1211 — Energy and progress hierarchy

Audit and repair the Energy screen as the canonical first screen:

- generation information;
- kWh progress;
- active panel signal;
- game-style progress bars;
- no public exposure of forbidden internal rank-level mechanics.

## Cycle 1212 — Ranks visual compression

Adapt Ranks to compact game-style cards while keeping canonical rank
logic and without renaming the bottom button.

## Cycle 1213 — Panels visual compression

Keep Panels as a canonical page. Compress only subsections and visible
states that are not core to panel activation.

## Cycle 1214 — Exchange visual compression

Keep Exchange as a canonical page. Improve clarity of preview, convert,
history and disabled states.

## Cycle 1215 — Tasks / Referrals visual grouping

Use Dragon-like card hierarchy only inside canonical pages. Do not move
Tasks or Referrals into a different first-level button.

## Cycle 1216 — Wallet/Profile detailed agreement

Prepare the Wallet/Profile model for approval. Separate balance,
wallet-connect, history, deposit and withdraw surfaces clearly.

## Cycle 1217 — Wallet/Profile implementation pass

Implement only the approved Wallet/Profile visual corrections.

## Cycle 1218 — Button feedback and disabled states

Audit buttons that look broken because they need wallet, Telegram
runtime, global_id, backend data or async state. Add clear user feedback.

## Cycle 1219 — Browser shell hardening

Keep browser/PWA mode system-install only. Do not add a custom install
button unless later approved.

## Cycle 1220 — Browser fallback audit

List Telegram-only functions and define safe browser fallbacks without
breaking Telegram Mini App behavior.

## Cycle 1221 — Browser fallback repair

Repair only safe fallbacks found in cycle 1220.

## Cycle 1222 — Admin separation audit

Check that admin/debug/operator features are visible only through Admin.

## Cycle 1223 — Admin separation repair

Move only confirmed public leaks to Admin. Do not remove uncertain
features without approval.

## Cycle 1224 — Browser-Shop Web3 polish

Continue Web3-style visual polish through HUB while preserving payment
and status polling roads.

## Cycle 1225 — FAQ and help polish

Keep FAQ compact and language-aware. Do not rewrite FAQ content unless
a specific FAQ content cycle is approved.

## Cycle 1226 — Visual guard pack

Add static guards for public leaks, bottom menu canon, modal shell and
browser shell.

## Cycle 1227 — Route/click static audit

Regenerate route and button inventories. Separate real broken links from
state-gated actions.

## Cycle 1228 — User approval table

Produce the next leave/delete/admin/question table after the page-level
repairs.

## Cycle 1229 — Approved cleanup only

Delete or move only functions directly approved by the user.

## Cycle 1230 — range verdict

Collect evidence for 1195-1230 and state what is fixed, open or not
proven. Do not claim full release readiness without CI and browser
proof.


## Update after cycles 1211-1212

The visible-function approval table remains a working audit artifact.
It is not an approval mechanism.  Approval happens in chat.

Cycle 1211: Energy progress boundary repaired.
Cycle 1212: Ranks leaderboard boundary repaired.

Next recommended focus: page-level visual hierarchy for Energy and Ranks
using the Dragon-style principle of compact cards and progressive
disclosure, without renaming or moving canonical bottom menu sections.

## v168_29 correction

Cycle 1213 added Ranks compact cards and WebApp/PWA target fixation.
Cycle 1214 audited Panels, Exchange and Tasks.

The next repair must stay inside canonical pages and must not rename or
move the six bottom navigation buttons.
