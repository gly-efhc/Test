# Циклы 1640–1650 — полный cutover бизнес-владения на global_id

Статус: `ACTIVE_PLAN`  
База: `v172.56`, основной exact-head CI PASS.  
Директива пользователя: visual screenshots не блокируют дальнейшую
разработку; visual evidence остаётся отдельной незакрытой задачей и не
подменяет backend/PostgreSQL qualification.

Источник требований:
`docs/NORM/TZ/TZ_global_id_full_cutover.md`.

## Неподвижный результат программы

- `global_id` — единственный business owner и idempotency owner.
- `tg_id` сохраняется только как Telegram provider attribute.
- TON/browser/APK account может выполнять бизнес-операции без Telegram.
- Один релиз готовится заранее; production cutover выполняется одной
  контролируемой транзакцией.
- После cutover удаляются legacy aliases и compatibility tails.

## Цикл 1640 — write-side foundation и idempotency audit

Scope:

1. Добавить `identity/financial_write_switch.py`.
2. Разрешать ровно один selector: `global_id` или `global_id`.
3. Всегда возвращать canonical `global_id`.
4. Блокировать `users` через `FOR UPDATE`.
5. Требовать `dual_write_enabled`.
6. Разрешить TON-only owner (`legacy_global_id=None`).
7. Провести построчный audit idempotency-key construction.
8. Зафиксировать список identifier-coupled keys до изменения ledger path.

Exit:

- write-side resolver покрыт unit/architecture tests;
- read/write используют один singleton control loader;
- idempotency risk register создан;
- application services ещё не переключены массово.

## Цикл 1641 — transactions/ledger canonical owner

Scope:

- перевести core helpers и публичные money functions на owner selector;
- balances lock/update выполнять по `global_id`;
- `efhc_transfers_log.global_id` сделать обязательным canonical owner для
  user-side записей;
- `tg_id` заполнять только при наличии provider attribute;
- нормализовать identifier-coupled idempotency keys с совместимым
  read-through старых ключей;
- доказать одинаковый результат вызова по `global_id` и `global_id`.

## Цикл 1642 — panels, withdrawals, payment intents

Scope:

- panels service;
- withdraw service;
- payment intents service;
- соответствующие routes;
- убрать `owner.require_legacy_global_id()` из этих business paths;
- сохранить финансовые инварианты, rollback и Decimal(30,8).

## Цикл 1643 — referrals, tasks, ranks, wallets

Scope:

- referral ownership/count/reward paths;
- task completion/ad reward/listing;
- ranks user/top reads;
- wallets ownership and bank credit bridge;
- заменить referral idempotency keys, зависящие от `global_id`.

## Цикл 1644 — callers и achievements

Scope:

- все оставшиеся routes;
- Telegram bot handlers;
- admin services/routes;
- scheduler jobs;
- `achievements.global_id` в ORM и canonical `0001`;
- provider-only использование `global_id` отделить от business ownership.

## Цикл 1645 — one-release cutover и rollback

Scope:

- изменить canonical `0001`, чтобы `legacy_authoritative` мог стать FALSE;
- реализовать транзакционный cutover в требуемом порядке;
- реализовать транзакционный rollback;
- подключить и проверять `*_rollback_ready`;
- при необходимости расширить owner consistency triggers;
- добавить pre-cutover readiness gate.

Exit:

- вся business logic заранее работает через `global_id`;
- cutover и rollback выполняются одним действием;
- production switch ещё не считается выполненным без exact qualification.

## Цикл 1646 — удаление legacy aliases

Удалить после завершения 1640–1645:

- service aliases `*_by_tg_id`, если они больше не provider adapters;
- `require_legacy_global_id()` из business routes;
- reverse owner alias `User.user_id`;
- runtime owner aliases `legacy_pk`/`legacy_runtime_id`, если полный audit не
  выявит допустимого system-only использования;
- устаревшие owner DTO/parameters и дублирующие SQL entrypoints.

`tg_id` как Telegram provider attribute не удаляется.

## Цикл 1647 — удаление compatibility tails и защита от возврата

Scope:

- удалить legacy business SQL (`WHERE global_id` в owner operations);
- очистить temporary AI memory и устаревшие current-state docs;
- перенести history/evidence в history;
- добавить static guards, запрещающие возврат global_id ownership;
- проверить отсутствие двусмысленных aliases в OpenAPI, frontend и bot.

## Цикл 1648 — focused qualification

- selector equivalence по каждой мигрированной функции;
- TON-only account без `global_id`;
- idempotency equivalence;
- concurrency/row locking;
- rollback/fail-closed;
- неизменённый `test_referral_runtime.py`.

## Цикл 1649 — full exact-head qualification

- PostgreSQL 16;
- canonical Alembic `0001`;
- полный pytest;
- Flake8/Ruff/Mypy/Bandit/compileall;
- frontend production build;
- migration/control telemetry;
- monetary discrepancy `0.00000000`.

## Цикл 1650 — финальный audit и release package

- полный поиск legacy aliases/tails;
- schema/ORM/routes/services/bot/admin/scheduler consistency;
- archive CRC/SHA and release purity;
- MATRIX_TECHNICAL evidence;
- final status и production cutover runbook.

## Текущий статус

```text
CYCLE_1639_MAIN_CI_PASS
CYCLE_1639_VISUAL_EVIDENCE_DEFERRED_BY_USER
CYCLE_1640_IN_PROGRESS
CYCLE_1641_NOT_STARTED
CYCLE_1642_NOT_STARTED
CYCLE_1643_NOT_STARTED
CYCLE_1644_NOT_STARTED
CYCLE_1645_NOT_STARTED
CYCLE_1646_NOT_STARTED
CYCLE_1647_NOT_STARTED
CYCLE_1648_NOT_STARTED
CYCLE_1649_NOT_STARTED
CYCLE_1650_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
