# Work Cycle 1590 — fresh CI referral PostgreSQL repair

Status: `LOCAL_SCOPE_COMPLETE`.
Archive target: `v171.87`.
Route: `ci_log_exact_failure_repair`.
Fallback: `false`.

## Input evidence

- GitHub run `82060386826`: release archive, green.
- GitHub run `82058627460`: development archive, red.
- Development failures: Ruff and PostgreSQL integration.

## Root causes

1. Four exact Ruff import and unused-name findings existed in the new
   integration modules.
2. Integration seed SQL passed untyped values into expressions where
   asyncpg could not infer `timestamptz`, `bigint` or `boolean`.
3. The production referral cursor query passed `None` for the first-page
   cursor without explicit PostgreSQL bind types.
4. One test expected 90 EFHC after a panel purchase although the canonical
   panel price is 100 EFHC and the seeded balance was 100 EFHC.
5. The same-user monetary lock used `FOR UPDATE SKIP LOCKED`, converting a
   valid parallel request into a false missing-user failure.

## Runtime repair

- Added explicit PostgreSQL casts to referral cursor binds.
- Replaced same-user `SKIP LOCKED` with blocking `FOR UPDATE`.
- Preserved idempotency checks inside the serialized transaction.
- Corrected integration seed SQL with explicit bind casts.
- Corrected the balance assertion to `0.00000000`.
- Applied the exact Ruff import and unused-name repairs.

## Regression protection

- Development structural guards require all cursor casts.
- Development guards require blocking monetary row locking.
- Integration tests retain replay, rollback and concurrency coverage.
- Packaged release acceptance protects the same production invariants.

## Proof boundary

Local regression is complete. The supplied release CI is green only for
v171.86. Fresh exact-HEAD GitHub CI is required for v171.87.
