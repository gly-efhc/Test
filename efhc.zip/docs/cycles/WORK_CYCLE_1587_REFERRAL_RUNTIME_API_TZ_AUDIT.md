# WORK CYCLE 1587 — REFERRAL RUNTIME/API TZ AUDIT

Status: LOCAL_SCOPE_COMPLETE / EXTERNAL_VERIFICATION_DEFERRED.
Version: `v171.84`.

## Objective

Audit two referral/release specifications against the exact v171.83 runtime,
repair every confirmed defect, adapt conflicting template requirements to the
active canon, and add real PostgreSQL/API proof.

## Confirmed repairs

- TG-ID-only referral and panel relationships;
- permanent Active status after any first panel, including archived panels;
- PostgreSQL filtering and stable cursor pagination;
- legacy CRUD repair;
- self-only user API security;
- complete Admin referral totals;
- ETag mutation correctness;
- atomic/idempotent concurrent reward hardening;
- stale CRUD health registry removal;
- integration CI and release documentation cleanup.

## Canonical adaptations

- invalid supplied referral code creates no user;
- full development tests remain outside release, minimal acceptance guards stay;
- bank deficit mode remains valid;
- no unnecessary migration or idempotency-key namespace change.

## External boundary

Fresh v171.84 GitHub CI, real PostgreSQL execution, frontend build, Docker clean
deploy/update/rollback and VPS/live gates remain deferred and must not be
reported as completed.
