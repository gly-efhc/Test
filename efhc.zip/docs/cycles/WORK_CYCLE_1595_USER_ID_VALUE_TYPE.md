# WORK CYCLE 1595 — Backend UserId value type

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.
Source HEAD: `EFHC_Bot_v171_91.zip`.
Target HEAD: `EFHC_Bot_v171_92.zip`.
Exact route: `user_id_value_type_adoption`.
Historical target HEAD: `EFHC_Bot_v171_92.zip`.
Fallback: `false`.

## 1. Purpose

Cycle 1595 converts the cycle-1594 nominal aliases into immutable,
validated backend value objects and proves their unit-level contract.
It does not connect them to ORM ownership, FastAPI authentication,
domain services, DTOs or frontend state.

The approved boundary is:

```text
raw PostgreSQL integer
→ user_id_from_database()
→ UserId
→ format_user_id()
→ UserIdDisplay
```

The reverse external boundary is:

```text
strict ten-ASCII-digit string
→ parse_user_id()
→ UserId
→ user_id_to_database()
→ BIGINT-compatible integer
```

## 2. Implemented types

Authoritative module:

```text
backend/app/identity/types.py
```

Implemented:

- immutable `UserId` value object;
- immutable `TelegramId` value object;
- validated `UserIdDisplay` string subtype;
- strict `ExternalUserId` Pydantic-ready annotation;
- `validate_user_id()`;
- `validate_global_id()`;
- `validate_user_id_display()`;
- `format_user_id()`;
- `parse_user_id()`;
- `user_id_from_database()`;
- `user_id_to_database()`;
- `is_user_id()` and `is_global_id()` type guards.

`UserId` is deliberately not an `int` subclass. A raw integer,
`TelegramId`, provider subject or wallet address cannot silently pass
through formatting or database conversion functions.

## 3. Runtime boundary

Cycle 1595 keeps:

```text
users.id INTEGER primary key
users.global_id BIGINT unique not null
AuthContext.global_id
legacy domain reads by global_id
```

No identity type is imported by runtime code outside
`backend/app/identity/`.

No Alembic migration, ORM field, SQL ownership key, route dependency,
service signature, DTO or frontend owner was changed.

## 4. Active doctrine correction

Three active runtime comments incorrectly stated that `global_id` was the
permanent sole identifier. They now state that it is a `LEGACY runtime`
owner key until the assigned expand/backfill/read-switch cycles.

Only comments/docstrings changed. The protected Python AST remains
identical.

## 5. Negative and patch guards

Cycle guard:

```text
ops/identity/check_user_id_value_type_boundary.py
ops/identity/user_id_value_type_patch_boundary.json
```

The manifest protects `481` files:

- models;
- services;
- CRUD;
- routes;
- schemas;
- FastAPI dependencies;
- Alembic/migration files;
- frontend source.

Python files are protected by AST hashes with docstrings removed.
Non-Python files are protected by exact SHA-256. Therefore comments may
be corrected, while executable semantics cannot change unnoticed.

The guard also rejects:

- any runtime import of `app.identity` outside the identity package;
- any new protected runtime file;
- any protected semantic change;
- active runtime wording that calls `global_id` the permanent sole ID.

## 6. Financial and data invariants

Cycle 1595 performs no database write and no data migration.

It must not change:

- user count or ownership;
- main or bonus balance;
- kWh values;
- panels;
- transactions;
- deposits or withdrawals;
- referrals or rewards;
- wallet bindings;
- roles;
- idempotency and transaction locks.

Allowed financial drift remains `0.00000000`.

## 7. Rollback

Rollback is source-only:

1. restore exact `EFHC_Bot_v171_91.zip` and its release archive;
2. do not run Alembic downgrade;
3. do not restore PostgreSQL because no database change exists;
4. verify source archive SHA-256 and CRC.

## 8. Local verification

```text
2757 collected
2585 passed
172 skipped
0 failed
0 errors
54 targeted tests passed
25 PostgreSQL integration tests collected
```

The 25 PostgreSQL tests were skipped because no DB URL was available.
Ruff, Mypy and Bandit are unavailable locally. Offline `npm ci` failed
because the Zod tarball is absent from the cache, so frontend typecheck,
production build and real route-backed Chromium proof remain unverified.

## 9. Evidence paths

```text
reports/generated/cycle_1595_full_pytest_summary_v171_92.json
reports/generated/user_id_value_type_boundary_v171_92.json
reports/generated/global_id_domain_boundary_v171_92.json
reports/generated/user_identity_reconciliation_v171_92.json
reports/junit/cycle_1595_targeted_v171_92.xml
reports/runtime_logs/cycle_1595_*.txt
```

## 10. Next cycle

```text
1596 — External API/Pydantic UserId contract preparation
```

Cycle 1596 may prepare API schemas and OpenAPI contract tests but must
not switch current domain ownership before the expand/backfill gates.
