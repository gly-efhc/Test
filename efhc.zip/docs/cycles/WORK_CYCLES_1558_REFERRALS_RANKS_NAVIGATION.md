# Cycle 1558 — Referrals, Ranks and navigation icon repair

Status: `DONE LOCALLY / OUTPUT v171.33` after final verification.

## Completed user scenarios

Referral path:

`Telegram start_param -> typed bind service -> backend referral protection ->
React Query statistics -> copy/share -> active/inactive referral routes`.

Ranks path:

`/ranks -> typed service -> React Query -> personal generated kWh state ->
vertical TOP-100 leaderboard -> refresh and find-me actions`.

## Referral binding and repeat protection

The bind marker is scoped by both `global_id` and `start_param`. A pending marker
has a fifteen-second expiry, failed transport or backend error removes the
marker, and only terminal results become `done`. Existing backend checks for
invalid code, unknown code, self-referral and an already assigned parent remain
unchanged.

## Header, energy mark and navigation

The header balance label is now only `EFHC`; the visual word `Total` is not
rendered. The dense legacy coin image is replaced by a neutral energy circle
and lightning SVG. All six protected bottom-navigation entries use one original
stroke-icon system. Sandbox assets were reviewed only as visual references;
no foreign runtime, branding or asset file was copied.

## Browser interaction evidence

At `390x844`, one `start_param` bind POST was observed, the referral link was
copied and shared through the Telegram link API, and route navigation loaded
personal rank, generated kWh and TOP leaderboard data. Refresh caused a second
rank query. The header showed only `EFHC`, the universal energy mark was
present, exactly six navigation icons were rendered, and horizontal overflow
was absent.

## Exact evidence boundary

Established: code repair, typed service/query seams, backend repeat-binding
guards, targeted tests, production build and local Chromium evidence for the
cycle-1558 scope.

Not established: fresh GitHub CI, live Telegram client proof, real TonConnect,
real PostgreSQL concurrency proof, release-ready or production-ready status.

## Final verification

- `npm ci`: passed, `0` vulnerabilities.
- TypeScript: passed.
- Frontend architecture: passed.
- Production build: two consecutive passes, 34 pages each.
- Browser E2E after final build: `1 passed`.
- Exact full regression: `2394` nodes, `2267 passed`,
  `127 skipped`, `0 failed`.
- Release master gate: passed at `19 / 100` verified points.

The skipped nodes are established environment-gated tests. The new browser
test was executed separately and passed. No explicit `skip` or `xfail` marker
was added by this work scope.
