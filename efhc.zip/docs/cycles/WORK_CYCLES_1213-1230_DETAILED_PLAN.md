## 1217-1218 update

After Panels and Exchange compression, Tasks is repaired as a compact
earning module. The next page focus should be Referrals or Wallet after
chat approval. Questions to the user must be simple and human.

# Work cycles 1213-1230 — corrected visual/game-shell plan

## Cycle 1213

Theme: WebApp / PWA target fixation and Ranks visual cards.

Actions:

- define EFHC as Telegram WebApp plus browser/PWA application;
- keep browser install through the system browser prompt;
- do not add a custom install button;
- add compact Dragon-style leader cards to Ranks;
- preserve Ranks as leaderboard only.

## Cycle 1214

Theme: Panels / Exchange / Tasks visible-function audit.

Actions:

- audit visible functions without deleting them;
- classify leave / ask / move to Admin / delete;
- localize confirmed public hardcoded text;
- remove confirmed technical wording from public strings;
- keep canonical pages and bottom buttons unchanged.

## Cycle 1215

Theme: Panels compact visual repair.

Actions:

- compress duplicate visual surfaces in Panels;
- keep activation road and 100 EFHC activation canon;
- do not change panel economics;
- add disabled-state explanation where needed.

## Cycle 1216

Theme: Exchange compact visual repair.

Actions:

- keep kWh to EFHC exchange road;
- keep withdraw road until Wallet design is approved;
- reduce helper cards into compact cards or drawer hints;
- keep no public technical terms.

## Cycle 1217

Theme: Tasks compact earning module.

Actions:

- make task cards more game-like;
- keep task claim road;
- do not remove ads flow without chat approval;
- add clear feedback for disabled buttons.

## Cycle 1218

Theme: Wallet subsection questions.

Actions:

- ask detailed Wallet design questions in chat;
- do not move withdraw/deposit/history without approval;
- prepare visual target for Wallet.

## Cycle 1219

Theme: Wallet subsection first repair.

Actions:

- implement only approved Wallet visual structure;
- preserve money roads and history;
- keep admin/debug out of game pages.

## Cycle 1220

Theme: browser runtime audit.

Actions:

- inspect Telegram-only calls in browser mode;
- add safe browser fallbacks where confirmed;
- do not claim live browser proof without running it.

## Cycle 1221

Theme: browser fallback repair.

Actions:

- fix safe Telegram runtime assumptions;
- keep Telegram behavior intact;
- keep PWA manifest and service worker valid.

## Cycle 1222

Theme: Admin separation audit.

Actions:

- verify admin/debug functions are only through Admin;
- list public leaks if any;
- do not remove uncertain functions without chat approval.

## Cycle 1223

Theme: Admin separation repair.

Actions:

- move only confirmed public leaks to Admin;
- update guards and docs;
- keep game pages same for all users.

## Cycle 1224

Theme: Browser-Shop Web3 polish.

Actions:

- continue Web3-style shop visuals through HUB;
- preserve TON wallet opening and polling;
- keep no wallet/memo/copy public blocks.

## Cycle 1225

Theme: FAQ/help polish.

Actions:

- keep FAQ language-aware;
- keep compact bot width;
- do not rewrite FAQ content without approval.

## Cycle 1226

Theme: visual guard pack.

Actions:

- guard bottom menu canon;
- guard no Energy ladder in Ranks;
- guard browser/PWA files;
- guard public technical term absence.

## Cycle 1227

Theme: click and button audit.

Actions:

- inventory all visible buttons;
- separate route bugs from state-gated buttons;
- document disabled-state reasons.

## Cycle 1228

Theme: chat approval packet.

Actions:

- produce concise questions in chat;
- archive can store notes but not approve decisions;
- ask only high-value questions.

## Cycle 1229

Theme: approved cleanup only.

Actions:

- remove or move only chat-approved functions;
- no silent deletions;
- update guards.

## Cycle 1230

Theme: range verdict.

Actions:

- collect evidence for 1195-1230;
- state fixed/open/not proven;
- do not claim CI green without user CI log.

## v168_30 update after cycles 1215-1216

Cycle 1215 repaired Panels compact visuals and moved Panels list calls
to
self-user routes.  The activation road and 100 EFHC canon were not
changed.  Legacy `/panels/{global_id}/active|archive` routes remain hidden
compatibility routes.

Cycle 1216 repaired Exchange compact visuals.  Exchange and Withdraw
remain on the canonical Exchange page until the Wallet subsection is
approved in chat.  Secondary helper text is moved into an expandable
compact details layer.

The next focus stays cycle 1217: Tasks compact earning module and clear
feedback for disabled or state-gated actions.

## 1219-1225 correction: app must not depend on global_id

The user clarified that the app must be complete in every mode.  Missing
Telegram `tg_id` cannot blank pages.  The browser/PWA shell must render
Energy, progress bars, Panels, Exchange, Tasks, Ranks and other public
surfaces with safe zero-state data until real identity data is present.

## 1225 correction note

User confirmed that the current visual result is not acceptable.
The plan is corrected: do not continue cosmetic micro-fixes before the
basic game shell is stable in browser and Telegram.

Hard rule:

- the app must show the same game UI without global_id;
- Telegram data may personalize, but must not control existence of UI;
- visible elements are approved only in chat.
