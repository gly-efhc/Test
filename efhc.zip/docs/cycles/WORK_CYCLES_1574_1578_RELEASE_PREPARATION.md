# Work cycles 1574–1578 — pre-release completion route

Status: LOCAL SCOPE COMPLETE / LIVE VERIFICATION DEFERRED.
Input HEAD: `EFHC_Bot_v171_68.zip`.
Output HEAD: `EFHC_Bot_v171_69.zip`.

## Cycle 1574 — local release-candidate audit

Local work:

- reconcile the current green CI evidence;
- close the provider-independent deployment requirement;
- add a truthful local 99-percent gate;
- create a minimal production release package;
- keep external live claims fail-closed.

Status after this pass:
`LOCAL_SCOPE_COMPLETE`.

## Cycle 1575 — technical deployment preparation

Local work:

- production Dockerfiles;
- universal Docker Compose;
- Caddy HTTPS proxy;
- standard PostgreSQL;
- server installer, deployment and health verification;
- domain and webhook reconfiguration.

External remainder:
`LIVE_VPS_DEPLOYMENT`.

## Cycle 1576 — Telegram and wallet publication preparation

Local work:

- stable project-domain contract;
- Telegram webhook registration and verification script;
- WalletProvider boundary retained;
- live checklist for Telegram, TonConnect and TonProof.

External remainder:
`LIVE_TELEGRAM_AND_WALLET_PROOF`.

## Cycle 1577 — controlled transaction preparation

Local work:

- backup before financial testing;
- readiness verification;
- restore drill;
- operator checklist for deposit, Browser Shop and withdrawal settlement;
- transaction evidence and anti-double-credit requirements.

External remainder:
`REAL_ONCHAIN_TRANSACTION_AND_SETTLEMENT_PROOF`.

## Cycle 1578 — public release preparation

Local work:

- release archive and checksum;
- deployment and rollback runbooks;
- off-site recovery bundle process;
- cross-provider drill procedure;
- go/no-go checklist and launch observation boundary.

External remainder:

- real second-provider recovery drill;
- DNS switch;
- live Telegram and TON checks;
- controlled public launch observation.

## Current completion semantics

The user directly approved this boundary:

```text
all locally executable work complete
+ portable production archive ready
+ external gates explicitly listed
= LOCAL_PRE_RELEASE_99_PERCENT
```

This does not equal `PRODUCTION_RELEASE_READY`. The remaining one percent
is the real deployment and live verification layer.

## Completion record

- Cycle 1574: `LOCAL_SCOPE_COMPLETE`.
- Cycle 1575: `DEPLOYMENT_PACKAGE_COMPLETE_LIVE_DEPLOYMENT_DEFERRED`.
- Cycle 1576: `LOCAL_TELEGRAM_WALLET_PREPARATION_COMPLETE_LIVE_DEFERRED`.
- Cycle 1577: `LOCAL_TRANSACTION_GUARDS_COMPLETE_REAL_SETTLEMENT_DEFERRED`.
- Cycle 1578: `PUBLIC_RELEASE_PACKAGE_PREPARED_GO_LIVE_DEFERRED`.

Machine evidence: `reports/generated/local_pre_release_99_v171_68.json`.

## v171.69 audited release blocker closure

The first v171.68 release package was not accepted for VPS deployment
because an independent audit found blocking operational defects. v171.69
closes them without claiming live deployment:

- canonical SchedulerService is the only production scheduler;
- all eight jobs are registered strictly;
- scheduler shutdown is bounded and awaited;
- release scripts preserve executable mode 0755;
- database restore is fail-closed;
- PostgreSQL and Caddy do not receive the complete backend environment;
- Docker access setup supports a normal non-root operator;
- release documentation matches the real Compose path;
- Docker logs are bounded;
- updates are backup-first and sequential.

Docker build and real startup remain part of technical deployment.

## v171.70 clean first-boot closure

The second release audit found that the archive still could not prove a
first deployment to a completely empty PostgreSQL volume. v171.70 adds
the missing local production contract:

- migrations no longer depend on `docs/` or SSOT CSV;
- ORM metadata defines the exact 44-table contract;
- `migrate` creates schemas, applies Alembic head, validates the database
  and inserts only idempotent system data;
- `BANK_EFHC` is a reserved service-user ID and is never recreated or
  reset by repeated deployment;
- webhook and TON variables are canonical and preflight-validated;
- rankings match ORM/API structures and support an empty database;
- admin shop/hub routes are mandatory in production;
- TON reconciliation is periodic and persistent;
- Compose uses `db → migrate → backend + scheduler → frontend → proxy`;
- the only documented first-start command is `deploy.sh`.

External acceptance remains a real Docker no-cache build, empty-volume
first start, repeated deployment and live service verification.

## v171.71 production frontend build closure

The third release audit found that the v171.70 VPS build still depended
on development-only FAQ generation and an automatic budget report path.
v171.71 closes those blockers:

- FAQ, locale and PWA files are generated during release packaging;
- the minimal release contains a SHA-256 asset manifest;
- frontend prebuild performs Node-only verification of packaged files;
- Docker build does not require Python, `docs/` or SSOT sources;
- performance budgets are removed from npm `postbuild`;
- the Next.js timeout is configurable and VPS-safe;
- Compose builds the shared backend image consistently;
- preserved PostgreSQL data triggers the update backup path;
- scheduler environment settings are no longer ignored;
- all expected route modules are fail-closed in production.

Real Docker build and deployment acceptance remain external gates.
