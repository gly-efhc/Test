# Work cycle 1510 — Wallet model replacement trace

## Goal

Close the audit tail raised after removing
`backend/app/models/wallet_models.py` by documenting and guarding the exact
active replacement.

## Answer

`backend/app/models/wallet_models.py` is replaced by:

```text
backend/app/models/wallets_models.py::WalletBinding
```

The active wallet runtime uses:

```text
wallets_routes.py → tonconnect_proof_service.py → wallets_service.py
→ wallets_models.py::WalletBinding
→ ton_address.py::canonicalize_ton_address
```

## Changes

- Added `docs/NORM/WALLET_MODEL_REPLACEMENT_TRACE.md`.
- Added `tests/architecture/test_wallet_model_replacement_trace.py`.
- Updated Kernel, map, cycle docs, reports and test guard manifest.

## Boundaries

No EFHC economy changes.
No withdraw canon changes.
No admin payout canon changes.
No legacy wallet runtime restoration.
No CI/workflow/lock file changes.
