# Cycle 1439 — Admin reports bank table repair

Status: DONE locally in `v170.15`.

## Goal

Close `F-003` from `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.

## Root problem

`GET /admin/reports/overview` read bank totals from legacy `efhc_admin.bank_balances` using old columns `balance_key` and `efhc_balance`, while the current canonical bank SSOT is `efhc_core.bank_balance` with `key` and `balance`.

## Runtime repair

Changed `backend/app/routes/admin_routes.py`:

```sql
from efhc_core.bank_balance
where key = 'EFHC_MAIN'
```

The route no longer reads:

```text
efhc_admin.bank_balances
balance_key = 'main'
efhc_balance
```

## User question: future mint through migrations

Answer: yes, the archive can forbid future bank mint/rewrite via migration guard while still allowing the first genesis seed.

Applied rule:

- `0001_init.py` is allowed to seed `5000000.00000000 EFHC` into `efhc_core.bank_balance` as genesis/bootstrap state.
- Any future migration that references `efhc_core.bank_balance`, `bank_balance`, `EFHC_MAIN` or `BANK_INITIAL_TOTAL` is treated as a violation by architecture guard unless explicitly redesigned in a separate approved cycle.
- Runtime mint/burn must use `AdminBankService` and `transactions_service`, not Alembic migrations.

## Files changed

Runtime:

- `backend/app/routes/admin_routes.py`
- `backend/app/services/admin/admin_stats_service.py` comments/log wording only

Tests:

- `tests/architecture/test_admin_reports_bank_ssot_repair.py`

Docs/indexes:

- `KERNEL.md`
- `map_element.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/SSOT/EFHC_CANON.md`
- `docs/SSOT/ssot_pack/SSOT_RAW_SQL_USAGE.csv`
- `docs/SSOT/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`
- `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `reports/REPORTS_INDEX.md`

## Guards

Added:

- `test_admin_reports_overview_uses_bank_balance_ssot`
- `test_admin_reports_overview_response_shape_matches_frontend`
- `test_admin_bank_dashboard_uses_same_bank_total_as_bank_service`
- `test_openapi_admin_reports_overview_schema_matches_runtime`
- `test_future_bank_mint_via_migrations_is_forbidden_except_genesis_seed`

## Local validation

Executed locally:

```text
python -m pytest tests/architecture/test_admin_reports_bank_ssot_repair.py -q
```

Executed targeted compile:

```text
python -m py_compile backend/app/routes/admin_routes.py backend/app/services/admin/admin_stats_service.py
```

## Non-claims

This cycle does not claim GitHub CI green, full pytest green, frontend build green, browser screenshots, live Telegram proof, real TonConnect proof or release-ready status.

## Remaining blockers

- `F-004` Admin Hub route prefix drift.
- `F-005` Admin wallet reset semantic mismatch.
- `F-006` OpenAPI stale/dead routes.
- `F-007` UI loading/error/empty state gaps.
- `F-008` full frontend API call → backend route guard gap.

Next safe step: `1440 — Admin Hub route prefix repair`.
