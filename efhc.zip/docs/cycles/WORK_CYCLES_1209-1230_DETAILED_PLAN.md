## 1217-1218 update

Tasks must be a compact earning module. Keep the canon bottom button
Tasks. Do not remove ads-flow. Replace public frontend path global_id calls
with current-user routes. Add clear human explanations for disabled
buttons.

## v168_27 correction

Cycle 1210 became targeted shell repair and visible-function triage.
Cycle 1211 now starts the Energy visual hierarchy audit.
See `WORK_CYCLES_1210-1230_DETAILED_PLAN.md`.

# WORK CYCLES 1209-1230 — corrected detailed plan

## Core correction after user answers

The project must not be collapsed into a new button system.
The six bottom buttons are canonical and remain unchanged:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

Energy remains canonical as the first screen.
It shows progress and generation, not a first-action button grid.

Dragon style is visual only.
Do not copy Dragon brand or assets.
Do not remove EFHC functions without an approved triage.

## Cycle 1209

Theme: visible function audit and Browser shell foundation.

Actions:

- generate visible frontend function inventory;
- document route/click diagnosis;
- add browser/PWA shell infrastructure;
- document Dragon reference limitation and method;
- update cycle plan and visual norm.

Evidence:

- `frontend_visible_functions_inventory_1209.json`;
- PWA manifest and service worker guard;
- visible function audit guard.

## Cycle 1210

Theme: Energy visual hierarchy audit.

Actions:

- inspect Energy page progress and generation blocks;
- verify rank-level names are not exposed where forbidden;
- map Dragon-like progress bars to EFHC energy progress;
- keep Energy route and name unchanged.

## Cycle 1211

Theme: Energy visual repair.

Actions:

- compact the Energy page without removing canon data;
- improve progress bar, generation and balance hierarchy;
- add guards for hidden rank-level internals.

## Cycle 1212

Theme: Panels visible controls audit.

Actions:

- inventory visible Panels buttons;
- classify controls as canonical, secondary, artifact or admin;
- do not remove without Q/A when uncertain.

## Cycle 1213

Theme: Panels visual compression.

Actions:

- keep Panels page as canonical;
- compress secondary controls inside cards/drawers;
- preserve panel activation canon.

## Cycle 1214

Theme: Exchange route and feedback audit.

Actions:

- verify Exchange buttons and API calls;
- identify inactive/disabled states with no explanation;
- keep Exchange page as canonical.

## Cycle 1215

Theme: Exchange visual repair.

Actions:

- add immediate feedback for async states;
- improve error and empty states;
- preserve economic canon 1 kWh = 1 EFHC.

## Cycle 1216

Theme: Tasks visual audit.

Actions:

- inventory all visible task actions;
- classify artifact/debug controls;
- map Dragon-style task cards to EFHC tasks.

## Cycle 1217

Theme: Tasks compact repair.

Actions:

- implement compact task cards;
- add clearer button feedback;
- keep route and business logic unchanged.

## Cycle 1218

Theme: Referrals visual audit.

Actions:

- inventory referral buttons and tabs;
- find runtime-state button failures;
- keep Referrals canonical.

## Cycle 1219

Theme: Referrals compact repair.

Actions:

- add Dragon-like compact referral cards;
- preserve referral links and active/inactive subroutes;
- improve copy/share feedback.

## Cycle 1220

Theme: Ranks semantic audit.

Actions:

- inspect rank page and Energy level progress;
- separate leaderboard from hidden internal level names;
- verify 12 Energy progress levels are not overexposed.

## Cycle 1221

Theme: Ranks visual repair.

Actions:

- implement progress-card style where safe;
- keep Ranks canonical page;
- keep leaderboard readable.

## Cycle 1222

Theme: Wallet/Profile design audit.

Actions:

- audit all wallet/profile visible functions;
- prepare detailed Q/A for the new Wallet subsection;
- do not redesign money roads without approval.

## Cycle 1223

Theme: Wallet/Profile first repair.

Actions:

- compress Wallet visual structure;
- preserve Deposit, history and wallet-connect roads;
- add clear disabled-state explanations.

## Cycle 1224

Theme: Browser-Shop Web3-style audit.

Actions:

- compare current Browser-Shop to Web3 reference structure;
- keep Browser-Shop reachable through HUB;
- verify public card fields stay clean.

## Cycle 1225

Theme: Browser-Shop visual polish.

Actions:

- add compact Web3-style shop visuals using EFHC brand;
- preserve TON wallet opening and status polling;
- no raw wallet/memo/copy blocks in public UI.

## Cycle 1226

Theme: browser shell click audit.

Actions:

- inspect Telegram-only functions in normal browser mode;
- document required browser fallbacks;
- avoid false live proof without browser execution.

## Cycle 1227

Theme: browser shell fallback repair.

Actions:

- add safe browser fallbacks where obvious;
- keep Telegram Mini App behavior intact;
- update PWA/browser docs.

## Cycle 1228

Theme: visible function triage report.

Actions:

- produce user-facing table: leave/delete/admin/question;
- list uncertain functions for approval;
- do not delete uncertain functions.

## Cycle 1229

Theme: approved visible function cleanup.

Actions:

- remove or move only approved artifact functions;
- add guards for public/admin separation;
- update reports and Q/A register.

## Cycle 1230

Theme: corrected visual range verdict.

Actions:

- collect evidence from 1195-1230;
- state what is fixed and what remains open;
- do not claim full release readiness without CI and browser proof.


## Update after cycles 1211-1212

User correction: chat is the place of approval.  Archive files may store
working memory, but the user approves details only through chat.

Cycle 1211 repaired Energy progress exposure.  The Energy screen remains
the canonical first page and shows progress/generation without exposing
internal 12-level names as public text.

Cycle 1212 repaired Ranks.  Ranks is a leaderboard, not a catalogue of
Energy progress thresholds.  The next cycles should continue visual
compression only inside canonical pages.

## v168_29 update after cycles 1213-1214

The browser/PWA goal is fixed as a dual-surface EFHC application:
Telegram Mini App plus normal browser/PWA shell.  Installation must use
the browser system install prompt, not a custom EFHC install button.

Ranks now has compact leader cards while staying a leaderboard.
Panels, Exchange and Tasks were audited without deleting functions.
The next safe focus is Panels compact visual repair.

## v168_30 correction

Cycles 1215-1216 followed the corrected v168_29 plan rather than older
payment-diagnostic notes.  Panels and Exchange were visually compressed
inside their canonical pages.  No bottom navigation labels or positions
were changed.

## Update after cycle 1219 emergency user report

User reported that the frontend looked empty in browser launch: no dark
surface, no first-page content and no visible progress bars.  The hard
product correction is: EFHC must render as a full app without Telegram
`global_id`.

### 1219 — browser independence emergency repair

- Add safe browser fallback snapshot.
- Remove loading-only returns from Energy and core pages when `global_id` is
  absent.
- Keep real economic actions protected; do not fake server success.

### 1220 — WebApp simulator canon sync

- Record WebApp/PWA model in glossary and AI/NORM docs.
- State that Telegram and browser open the same app.

### 1221 — visible elements table for chat agreement

- Create page-by-page visible elements table.
- Use it only as a working table; final agreement is in chat.

### 1222 — Energy first-screen proof

- Ensure Energy renders progress bar and game state from fallback state.
- No public internal 12-level ladder.

### 1223 — Tasks browser demo safety

- Tasks must not disappear in browser mode.
- Safe local demo timer allowed for visual/browser proof.

### 1224 — route/button diagnosis extension

- Continue checking buttons that appear inactive.
- Distinguish route breakage from missing identity or backend state.

### 1225 — evidence and next repair plan

- Summarize what is now visible to the user.
- Prepare Referrals/Profile/Wallet next visual agreement.

## 1225 follow-up: blank screen and visual agreement correction

New correction after user browser check:

- blank / white screen is a blocker;
- default app theme must be dark;
- Energy must render without Telegram tg_id;
- locale loading must not keep SplashScreen forever;
- progress bar must be visible even at zero percent;
- Referrals must not call user-only backend when global_id is missing;
- all visible frontend elements must be agreed in chat.

Next priorities:

1. Referrals compact repair.
2. Profile / Wallet detailed agreement.
3. Energy visual center repair.
4. Browser/PWA live proof.
5. Full page-by-page visual audit in chat.
