# Cycle 1441 — Admin wallet reset semantic repair

Status: DONE locally in `v170.17`.

## Goal

Close `F-005` from `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`.

## Root problem

The admin action:

```text
POST /admin/users/{global_id}/wallet/reset
```

cleared only legacy `efhc_core.users.ton_wallet`, while the canonical TonConnect wallet state lives in:

```text
efhc_core.wallet_bindings
```

That meant the operator could see a "wallet reset" action, but an active verified canonical binding could remain usable by wallet-aware services.

## User decision applied

Admin wallet reset means full canonical unbind.

The route must not be legacy-only. It must also deactivate canonical wallet bindings.

## Runtime repair

Changed runtime behavior:

1. `backend/app/services/wallets_service.py`
   - Added `admin_reset_wallet_bindings(db, global_id=...)`.
   - It deactivates all canonical wallet bindings for the user:

```text
is_active = false
is_primary = false
```

   - It intentionally does not commit; the admin route owns the full transaction boundary.

2. `backend/app/routes/admin_users_routes.py`
   - Keeps legacy cleanup:

```text
users.ton_wallet = NULL
```

   - Calls canonical wallet service:

```text
wallets_service.admin_reset_wallet_bindings(...)
```

   - Writes admin audit log with `wallet_bindings_deactivated=...`.
   - Commits once after legacy cleanup, canonical reset and audit log are all staged.

3. `frontend/src/pages/admin/users.tsx`
   - The reset button no longer depends on legacy `selected.ton_wallet` only.
   - The operator can run reset even when a canonical binding exists but the legacy field is empty.
   - After reset the UI reloads both detail and list.

## Tests / guards

Added active guard file:

```text
tests/architecture/test_admin_wallet_reset_semantic_repair.py
```

Protected invariants:

- `test_admin_wallet_reset_resets_canonical_wallet_bindings`
- `test_admin_wallet_reset_writes_audit_log`
- `test_admin_wallet_reset_requires_admin_guard`
- `test_wallet_reset_reflected_in_profile_wallet_state`
- `test_revoked_wallet_not_used_by_deposit_watcher`
- `test_admin_wallet_reset_service_does_not_commit_inside_helper`
- `test_wallet_bindings_model_remains_canonical`

## Local validation

Passed locally:

```text
python -m pytest tests/architecture/test_admin_wallet_reset_semantic_repair.py -q
# 7 passed
```

Related linkage/kernel/filename/line72 guard pack passed locally:

```text
python -m pytest   tests/architecture/test_admin_wallet_reset_semantic_repair.py   tests/architecture/test_admin_hub_route_prefix_repair.py   tests/architecture/test_admin_reports_bank_ssot_repair.py   tests/architecture/test_deposit_watcher_wallet_ssot_repair.py   tests/architecture/test_admin_bank_ssot_repair.py   tests/architecture/test_archive_filename_hygiene.py   tests/architecture/test_operator_kernel_routes.py   tests/architecture/test_operator_kernel_config_loading.py -q
# 47 passed
```

Targeted Python compile passed for changed backend route/service files.

## Scope boundaries

No EFHC economy change.
No money-flow change.
No migration change.
No OpenAPI rebuild in this cycle.
No CI/workflow/lock-file change.
No test deletion, archival, skip or xfail.
No direct runtime transfer from Песочница.

Песочница used only as reference/navigation layer.

## Healer / audit tails routed forward

After checking prior audit/HEALER tails, the next bounded cycles are:

```text
1442 — OpenAPI rebuild and strict contract gate
1443 — Full linkage architecture tests + critical UI loading/error/empty-state guards
1444 — Linkage repeat audit + HEALER tail reconciliation
1445 — CI/log proof and residual audit-tail closure if fresh logs are supplied
```

Known tails that must not be hidden:

- `F-006`: OpenAPI incomplete/stale routes.
- `F-007`: UI loading/error/empty-state guard tail.
- `F-008`: frontend API call → backend route guard missing.
- HEALER notes: repeat audit / fresh CI proof remain pending; do not claim release-ready before those gates.

## Remaining blockers

`P0_RELEASE_BLOCKED` remains until `F-006+` are repaired and repeat linkage audit is performed.

Next safe cycle:

```text
1442 — OpenAPI rebuild and strict contract gate
```
