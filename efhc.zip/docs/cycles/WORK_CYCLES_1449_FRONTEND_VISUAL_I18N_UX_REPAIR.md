# Cycle 1449 — frontend visual / i18n / buttons / UX repair

Status: DONE locally.
Archive output: `EFHC_Bot_v170_25_cycle_1449_frontend_visual_i18n_ux_repair.zip`.
Input HEAD: `EFHC_Bot_v170_24_cycle_1448_linkage_minor_findings_repair.zip`.

## Inputs

- `docs/audits/P0_FRONTEND_VISUAL_I18N_BUTTONS_UX_AUDIT_V170_24.md`
- `docs/audits/TZ_FRONTEND_VISUAL_I18N_BUTTONS_UX_REPAIR_V170_24.md`

Audit verdict accepted as source for this cycle:
`VISUAL_SAFE_NO_P0_FOUND`, with `8` P1 findings and `2` P2
findings.

## Closed locally

- F-01: Panels countdown now uses real seconds math:
  `86400`, `3600`, `60`.
- F-02: Tasks no longer returns raw public task status values.
- F-03: Ranks no longer uses `browser-player` as runtime fallback.
- F-04: Web Profile balance history uses a shared reason normalizer.
- F-05: Withdraw history/outcome labels use human labels instead of
  raw `reason`, `balance_type` and `outcome_kind`.
- F-06: Withdraw Money-Center return now goes to
  `/web-profile?section=history`.
- F-07: Admin Shop operator labels were Russian-first normalized.
- F-08: Admin Withdrawals and its mobile decision panel use
  Russian operator labels for statuses/outcomes.
- F-09: active Energy route docs now keep `/` as the only active route.

## Deferred

- F-10 screenshot proof is not claimed in this cycle. The archive still
  needs real browser/screenshot runtime capture in a later cycle because
  this local environment did not provide a running browser/TMA proof.

## Safety

- Runtime economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- Tests deleted/archived/skipped/xfail: no.
- Песочница used only as reference/navigation layer.
