# Work cycle 1586 — CI Ruff import-order repair

Status: `LOCAL_SCOPE_COMPLETE / FRESH_EXACT_HEAD_CI_REQUIRED`.

## Input

- Development HEAD: `EFHC_Bot_v171_82.zip`.
- Development CI: `logs_81874732041.zip`.
- Release CI: `logs_81877007921.zip`.
- Exact Kernel route: `ci_log_exact_failure_repair`.
- Fallback: not used.

## Root cause

Both archives passed all functional gates. Development completed
`2556 passed, 20 skipped`; release completed `12 passed`. PostgreSQL,
Alembic, Mypy, Bandit, compilation and frontend production build were
green.

Delivery failed only because the same two shared runtime files violated
Ruff `I001` import ordering:

- `backend/app/services/admin/admin_facade.py`;
- `backend/app/services/referral_service.py`.

The SQLAlchemy imports were positioned before app-service imports while
the repository Ruff/isort configuration classifies the resulting block
in the opposite order.

## Repair

The two import blocks now match the exact ordering proposed by Ruff.
No executable statements, schemas, API contracts, database behavior,
frontend behavior or economic rules changed.

A targeted architecture guard protects the two known ordering anchors.
The mandatory Ruff jobs remain the authoritative delivery gate.

## Proof boundary

Local targeted and bounded regression checks must pass. Fresh exact-HEAD
GitHub CI for both `v171.83` archives remains mandatory before any
stronger release status.
