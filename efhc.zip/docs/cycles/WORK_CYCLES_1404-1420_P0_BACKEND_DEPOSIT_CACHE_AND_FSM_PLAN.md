# WORK_CYCLES_1404-1420 — P0 backend, deposit-cache and FSM repair plan

Status: CLOSED / CYCLES 1404-1420 DONE.  
Created in: `v169_86 / cycle 1404`.  
Base HEAD: `EFHC_Bot_v169_85_cycle_1403_p0_backend_and_fsm_repair_plan.zip`.

## Governing rule

P0 money, identity, payment and deposit-cache fixes must be done in small controlled cycles. If logs are supplied, logs are read first. No test may be deleted, archived, skipped, xfailed or hidden to make the suite green.

## User decisions now locked

1. `HEAL-0040`: custom/package-less deposit intents may use `package_id = NULL`.
2. `HEAL-0024` / `HEAL-0018`: transaction-boundary repair may adapt service/route ownership where required.
3. FSM split: `backend/app/bot/states.py` remains a compatibility facade.
4. Deposit cache: no process-local `_ttl_seen` as source of truth; use `efhc_admin.idempotency_key` with durable/long-retention records for deposit protection.

## Cycle map

| Cycle | Purpose | Status | Notes |
|---:|---|---:|---|
| 1404 | P0 decision/Q&A/Atlas alignment + deposit-cache plan | DONE in v169.86 | Documentation/guard cycle. No runtime repair. |
| 1405 | HEAL-0045 global_id identity canon repair | DONE in v169.87 | `admin_top_inviters()` now joins `*_global_id` fields to `User.global_id`, exposes `inviter_global_id`, and is locked by `test_heal0045_global_id_identity_canon.py`. |
| 1406 | HEAL-0040 payment_intents contract repair | DONE in v169.88 | Nullable `package_id` contract implemented for custom/package-less intents; package path keeps `:pid`; fake `0` sentinel removed from shop_external. |
| 1407 | HEAL-0044 schema proof for transfer direction width | DONE in v169.88 | Existing DB repair and sanity proof added for `efhc_transfers_log.direction varchar(24)`. |
| 1408 | HEAL-0023 idempotency read-through conflict hardening | DONE in v169.89 | Explicit `IDEMPOTENCY_CONFLICT` marker is now detected by the shared helper; local branches use `_is_idempotency_conflict(...)`. |
| 1409 | HEAL-0018 transaction boundary map | DONE in v169.89 | Transaction ownership map added. No runtime boundary rewrite in 1409. |
| 1410 | HEAL-0018 transaction boundary repair | DONE in v169.90 | Core `transactions_service` hidden `begin_nested()` fallback removed; `exchange_service` closes read-only preflight autobegin before money-service entry. |
| 1411 | HEAL-0024 exchange/withdraw atomicity repair | DONE in v169.91 | Primary withdraw request path now commits request row, hold transfer, audit meta and hold_done flag in one service-owned boundary; exchange lock path remains protected by existing row-lock guards. |
| 1412 | HEAL-0055 deposit-cache DB idempotency proof | DONE in v169.92 | Deposit processing now uses long-retention `efhc_admin.idempotency_key` records with `scope=deposit:efhc`, `expires_at=NULL` and response read-through; Kernel Start Core was also made mandatory. |
| 1413 | HEAL-0055 long-retention deposit idempotency policy | DONE in v169.93 | Deposit idempotency retention is explicitly `NON_EXPIRING`, `expires_at=None`, and same-key/different-payload replay raises `idempotency_fingerprint_mismatch`. |
| 1414 | P0 cross-guard consolidation without deleting tests | DONE in v169.93 | Added additive cross-guard over identity/payment/schema/idempotency/transaction/withdraw/deposit invariants. No existing guard was deleted or weakened. |
| 1415 | P0 backend targeted test and log repair | DONE in v169.94 | Read `logs_72248746196.zip` first and repaired the exact ruff/pytest failures. |
| 1416 | P0 range closure audit | DONE in v169.94 | Added log repair and range-closure audit with explicit non-claims. |
| 1417 | FSM states.py split import/dependency map | DONE in v169.95 | Kernel route and current imports were checked; facade strategy confirmed. |
| 1418 | FSM dto/backend extraction | DONE in v169.95 | `BotStates`, `ConversationState`, `StateBackend` and `MemoryStateBackend` moved under `backend/app/bot/fsm/`. |
| 1419 | FSM manager extraction | DONE in v169.95 | `StateManager` and `get_state_manager()` moved to `fsm/manager.py`; singleton semantics preserved. |
| 1420 | FSM decorators extraction and regression proof | DONE in v169.95 | Decorators moved to `fsm/decorators.py`; `states.py` remains a compatibility facade and guard was added. |

## Current remaining cycles

After cycle 1420, this active plan has 0 cycles remaining. Range `1404-1420` is closed.

## Non-claims

This plan does not claim GitHub CI green, full pytest green, npm build, screenshots, live Telegram proof, real wallet proof or release readiness.


## Cycle 1412 decision/status update

- `HEAL-0055` deposit-cache proof is now applied at service level.
- `process_efhc_deposit()` records canonical deposit idempotency keys in `efhc_admin.idempotency_key` with `scope=deposit:efhc` and `expires_at=NULL`.
- Completed deposit responses are stored in `response_payload_json` and replayed on duplicate tx-hash processing.
- Operator Kernel is now mandatory in Start Core navigation; `KERNEL.md` was added and `file_map.py --refresh` is available.
- Remaining plan cycles: `1413-1420`.


## Cycle 1413-1414 status update

- `HEAL-0055` deposit idempotency retention is now explicit in code:
  `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"` and
  `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`.
- A repeated deposit key with different watcher payload now raises
  `idempotency_fingerprint_mismatch` instead of silently reusing or crediting.
- Cycle 1414 added `tests/architecture/test_p0_cross_guard_consolidation.py`.
- Remaining plan cycles: `1415-1420`.


## Cycle 1415-1416 status update

- Log archive `logs_72248746196.zip` was read first.
- The failing ruff and pytest gates were repaired by root cause.
- No test was deleted, archived, skipped, xfailed or hidden.
- Remaining plan cycles: `1417-1420`.


## Cycle 1417-1420 status update

- `backend/app/bot/states.py` is now a compatibility facade below 2500 bytes.
- New implementation modules live in `backend/app/bot/fsm/`.
- `backend/app/bot/__init__.py` lazily loads heavy bot runtime exports so FSM imports do not require aiogram at import time.
- Added guard: `tests/architecture/test_fsm_states_split_facade.py`.
- Active plan `1404-1420` is now closed.
