# Рабочий цикл 1611 — user_identities и PostgreSQL test package

Версия: `v172.08`.

Статус:

```text
PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

## Цель

Подготовить schema EXPAND для provider-neutral identity storage и полный
PostgreSQL test package без установки PostgreSQL в среде чата и без
изменения канонических CI workflow.

## Реализовано

- Alembic revision `0003` после `0002`;
- ORM-модель `UserIdentity`;
- таблица `efhc_core.user_identities`;
- FK `global_id → users.user_id` с `RESTRICT`;
- unique `(provider, provider_tenant, provider_subject)`;
- range, provider, tenant, subject, status и verification constraints;
- partial unique index одной primary identity на account;
- fail-closed downgrade только пустой таблицы;
- read-only `PG-0` preflight;
- architecture, unit и negative tests;
- PostgreSQL integration test для upgrade `0002 → 0003`, constraints,
  financial parity, fail-closed downgrade и re-upgrade;
- offline PostgreSQL SQL render upgrade и downgrade;
- byte-for-byte guard неизменности `ci.yml` и `.github/workflows`;
- exact Operator Kernel route цикла 1611.

## Локальные доказательства

Fresh exact-HEAD collect содержит `3007` уникальных node ID без дублей.
Завершённый regression:

```text
2835 PASSED
172 SKIPPED
0 FAILED
0 ERROR
```

Все `172` skips относятся к PostgreSQL/browser environment gates.
PostgreSQL migration module дополнительно запущен отдельно и
зафиксирован как `1 SKIPPED` на уровне module, поскольку PostgreSQL и
`psycopg` по прямому указанию пользователя не устанавливались.

## Не выполнено

- PostgreSQL не устанавливался и не запускался;
- реальный `PG-0` не выполнен;
- migration не применялась online;
- PostgreSQL integration test не исполнялся;
- GitHub CI не запускался;
- CI workflow не создавались и не изменялись;
- backfill, resolver, account/session и ownership switch отсутствуют.

## Gate

Это не `PG-0 PASS`. Alembic code head равен `0003`, но applied
PostgreSQL head не подтверждён. Цикл 1612 заблокирован до выполнения
подготовленного test package существующим каноническим CI GitHub.

## Следующее действие

```text
Необходимо запустить канонический CI GitHub
```

## Локальная приёмка пакета

```text
2978 unique non-integration node ID
2832 PASSED
146 SKIPPED
0 FAILED
0 ERROR
PostgreSQL integration: NOT RUN
GitHub CI: NOT RUN
```

Offline SQL и static contracts проверены. Реальный PostgreSQL result
отсутствует и не подменён SQLite, mock driver либо offline renderer.
