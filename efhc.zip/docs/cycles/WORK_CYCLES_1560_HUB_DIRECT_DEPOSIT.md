# Work cycle 1560 — HUB and Direct Deposit

Status: `DONE LOCALLY / OUTPUT v171.35`.

## Input

- Archive: `EFHC_Bot_v171_34.zip`.
- SHA-256:
  `4b8e99e3db0902276cccbbbe480d1a79569497a80efe26116a6bf85e682990ea`.
- ZIP: `testzip=None`.
- Records: `4248` (`4020` files, `228` directories).
- Forbidden artifacts: `0`.

## Completed scenario

- HUB exposes exactly two equal primary actions.
- EFHC top-up uses a typed handoff service and React Query mutation.
- VIP NFT opens the fixed GetGems URL.
- Global Header `+` opens Direct Deposit without a wallet gate.
- The user enters a positive TON amount.
- The backend generates the canonical memo `EFHC:<global_id>`.
- The TON wallet URL contains the amount in nanoTON and the memo.
- The modal remains open while reconciliation is checked.
- Watcher credit is recognized through balance history.
- The user sees human checking, retry and confirmed states.
- Raw wallet, memo, intent IDs and payment diagnostics remain hidden.

## Browser evidence

Checked viewports:

- `360x800`;
- `390x844`;
- `430x932`;
- `768x1024`.

Evidence proves:

- two HUB actions;
- one EFHC handoff POST;
- one Direct Deposit open POST;
- `1.25 TON` converted to `1250000000` nanoTON;
- canonical memo included in the wallet URL;
- visible watcher checking and confirmed states;
- confirmed credit `25.00000000 EFHC`;
- no horizontal overflow.

Screenshots:

`reports/screenshots/hub_direct_deposit_1560/`.

Machine evidence:

- `reports/generated/hub_direct_deposit_v171_35.json`;
- `reports/generated/hub_direct_deposit_linkage_v171_35.json`.

## Regression

- Exact inventory: `2403` unique nodes.
- Passed: `2274`.
- Skipped: `129` existing environment-gated nodes.
- Failed: `0`.
- Omitted: `0`.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED` for HUB and Direct Deposit.

Not established:

- fresh GitHub CI;
- live Telegram client proof;
- a real signed TON transaction;
- final release audit;
- release-ready or production-ready status.
