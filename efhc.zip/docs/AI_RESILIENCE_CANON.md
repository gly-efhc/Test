# AI RESILIENCE AND SELF-HEALING CANON

Документ фиксирует принципы устойчивости EFHC Bot.

## Базовые механизмы

- guarded transitions
- idempotency для денежных POST
- audit trail
- soft-fallback вместо тихого молчания
- self-healing для фоновых задач и пересборок снапшотов

## Что это значит на практике

- система предпочитает безопасный отказ скрытому повреждению данных;
- фоновые задачи обязаны логировать исключения;
- критические переходы статусов имеют атомарные условия;
- повторный вызов не должен плодить деньги, панели и выводы;
- обзорные документы должны совпадать с SSOT.

## Связанные источники

- `docs/EFHC_CANON.md`
- `docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`
- `docs/BANK_CANON_SHORT.md`
- `ops/canon_guard.py`
