# RELEASE_CANDIDATE_1 — Mainnet Test SOP (Template)

Дата подготовки: 2026-04-10
Статус: шаблон и операторский сценарий, не подтверждение фактического mainnet-прогона
Цикл: 825

## Назначение
Это рабочая инструкция для первого ручного боевого прогона внешнего shop payment flow в Mainnet.
Документ не утверждает, что mainnet-тест уже выполнен.
Он описывает строгую SOP-последовательность для безопасного запуска.

## Предусловия
- Backend запущен с production-like конфигом.
- Доступен admin route для shop orders.
- Доступна таблица `efhc_core.shop_orders`.
- Доступна таблица `efhc_core.ton_inbox_logs`.
- Доступен admin rescue-action `Force Fulfill`.
- У оператора есть тестовый бюджет на 1 TON или 1 USDT в Mainnet.

## Сценарий A — 1 TON
1. Открыть Browser Shop.
2. Выбрать EFHC-пакет.
3. Нажать создание внешнего intent.
4. Убедиться, что на фронте показан payload/memo из сервера.
5. Отправить ровно указанную сумму.
6. Дождаться обработки watcher.
7. Проверить в БД:
   - `efhc_core.shop_orders.status`
   - `efhc_core.shop_orders.tx_hash`
   - `efhc_core.shop_orders.payment_error_log`
   - `efhc_core.ton_inbox_logs.status`
   - `efhc_core.ton_inbox_logs.note`
8. Убедиться, что пользователю пришло success-уведомление.

## Сценарий B — 1 USDT
1. Повторить шаги создания заказа.
2. Убедиться, что asset = USDT и используется разрешённый контракт.
3. Отправить ровно указанную сумму.
4. Проверить те же таблицы и поля, что и в сценарии A.

## Если автоматика не сработала
1. Открыть admin shop orders.
2. Найти заказ.
3. Проверить `payment_error_log` и `ton_inbox_logs.note`.
4. Если платёж валиден по факту, нажать `Force Fulfill`.
5. Убедиться, что:
   - заказ стал `PAID_AUTO`;
   - баланс зачислен;
   - пользователю пришло success-уведомление.

## Что фиксировать после теста
- дата и время прогона;
- какой asset тестировался;
- статус заказа;
- был ли нужен `Force Fulfill`;
- итог: success / manual rescue / fail-closed.
