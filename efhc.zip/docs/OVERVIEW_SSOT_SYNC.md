# OVERVIEW SSOT SYNC

Это короткий обзорный SSOT-срез проекта.

## Актуальные числа

- схемы БД: **2** (`efhc_core`, `efhc_admin`)
- ORM-таблицы: **38**
- HTTP-маршруты: **92**
- test files: **74**
- миграции Alembic: единая `0001_init.py`

## Источники истины

- таблицы: `docs/ssot_pack/SSOT_TABLES_ORM.csv`
- маршруты: `docs/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`
- тесты: реальный `tests/**/test_*.py`
- миграции: `backend/migrations/versions/0001_init.py`

## Что считается актуальным обзором

Обзорная документация обязана повторять ровно эту картину:

- только две схемы БД;
- обзорные числа берутся из `ssot_pack`, а не из памяти;
- каталог тестов синхронизируется с репозиторием;
- любые старые числа в обзорных документах считаются дефектом.

## Критические домены

- bank / withdraw / exchange
- panels / energy / ranks
- shop / lotteries / referrals
- wallets / TON inbox / admin audit

## Замечание

Исторические аудиты могут содержать старые числа как часть хроники.
Это не меняет текущий обзорный SSOT.
