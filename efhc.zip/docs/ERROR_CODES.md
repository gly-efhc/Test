# ERROR_CODES (EFHC) — SSOT кодов ошибок

Статус: NORM (нормативный документ). Якорь SSOT: docs/SSOT_INDEX.md

Цель: единый перечень кодов ошибок и единый формат ошибки для API,
WebApp и админки.

Любая ошибка в публичном API и в админ-API обязана быть сериализована в
структуре:

- error_code: str
- message: str
- details: object | null

Требования:
- error_code — машиночитаемый код (SSOT ниже), без свободного текста.
- message — короткое человекочитаемое описание.
- details — структурированный объект для контекста (не строка-роман).
- tg_id указывается в details, если это уместно и не нарушает
  приватность.

Примечание:
- Коды ниже используются как SSOT. Если кода нет — добавлять его нужно
сначала сюда (NORM), затем в код и тесты.

---

## 1. Общие ошибки

- E000_UNEXPECTED
  - Когда: непредвиденная ошибка, не классифицированная ниже.
  - details: {request_id?, correlation_id?, where?}

- E001_VALIDATION
  - Когда: невалидные входные данные (schema/тип/формат).
  - details: {field?, reason?, expected?}

- E002_NOT_FOUND
  - Когда: сущность не найдена.
  - details: {entity, key, value}

- E003_CONFLICT
  - Когда: конфликт состояния (уже создано, неверный статус).
  - details: {entity, state?, expected?, actual?}

- E004_FORBIDDEN
  - Когда: запрет по правам доступа.
  - details: {required_role?, required_scope?, actor_tg_id?}

- E005_UNAUTHORIZED
  - Когда: нет авторизации/токена.
  - details: {auth_scheme?}

- E006_RATE_LIMIT
  - Когда: превышение лимитов.
  - details: {limit, window_sec, retry_after_sec?}

---

## 2. Идентификатор пользователя (tg_id only)

- E100_TG_ID_REQUIRED
  - Когда: tg_id обязателен, но отсутствует.
  - details: {where}

- E101_TG_ID_INVALID
  - Когда: tg_id имеет неверный формат/диапазон.
  - details: {tg_id, reason}

- E102_TG_ID_MISMATCH
  - Когда: tg_id в URL не совпадает с tg_id из контекста авторизации.
  - details: {url_tg_id, auth_tg_id}

---

## 3. Идемпотентность

- E200_IDEMPOTENCY_KEY_REQUIRED
  - Когда: Idempotency-Key обязателен для операции.
  - details: {operation, header}

- E201_IDEMPOTENCY_KEY_INVALID
  - Когда: Idempotency-Key имеет неверный формат.
  - details: {key, reason}

- E202_IDEMPOTENCY_REPLAY
  - Когда: повторная обработка операции запрещена.
  - details: {key, first_seen_at?, operation}

---

## 4. EFHC баланс и банк

- E300_INSUFFICIENT_BALANCE
  - Когда: у пользователя недостаточно EFHC.
  - details: {tg_id, required, available}

- E301_NEGATIVE_BALANCE_FORBIDDEN
  - Когда: операция привела бы к отрицательному балансу пользователя.
  - details: {tg_id, delta, would_be}

- E302_BANK_OPERATION_FAILED
  - Когда: проводка банка не выполнена атомарно.
  - details: {reason, stage?, tx_id?}

- E303_DECIMAL_INVALID
  - Когда: число не приводится к Decimal по правилам проекта.
  - details: {value, reason}

---

## 5. Генерация энергии и панели

- E400_PANEL_NOT_FOUND
  - Когда: панель/тип панели не найден.
  - details: {panel_id?}

- E401_PANEL_ALREADY_OWNED
  - Когда: повторная покупка запрещена или недоступна.
  - details: {tg_id, panel_id?}

- E402_ENERGY_STATE_INVALID
  - Когда: состояние генерации неконсистентно.
  - details: {tg_id, reason}

---

## 6. Магазин

- E500_ITEM_NOT_FOUND
  - Когда: товар не найден.
  - details: {item_id}

- E501_ORDER_NOT_FOUND
  - Когда: заказ не найден.
  - details: {order_id}

- E502_PURCHASE_NOT_ALLOWED
  - Когда: покупка запрещена правилами.
  - details: {tg_id, rule}

- E503_PAYMENT_NOT_CONFIRMED
  - Когда: платёж не подтверждён.
  - details: {provider, payment_ref?}

---

## 7. Выводы

- E600_WITHDRAWAL_NOT_FOUND
  - Когда: заявка на вывод не найдена.
  - details: {withdrawal_id}

- E601_WITHDRAWAL_STATUS_INVALID
  - Когда: переход статуса запрещён.
  - details: {withdrawal_id, from, to}

- E602_WITHDRAWAL_LIMIT_EXCEEDED
  - Когда: превышен лимит вывода.
  - details: {tg_id, limit, window_sec}

---

## 8. TON интеграция

- E700_TON_MEMO_INVALID
  - Когда: memo не соответствует формату проекта.
  - details: {memo, reason}

- E701_TON_TX_ALREADY_PROCESSED
  - Когда: TON транзакция уже обработана.
  - details: {tx_hash, first_seen_at?}

- E702_TON_TX_NOT_FOUND
  - Когда: TON транзакция не найдена.
  - details: {tx_hash}

- E703_TON_PROVIDER_ERROR
  - Когда: TON провайдер недоступен/вернул ошибку.
  - details: {provider, status?, body?}

---

## 9. Админ-операции

- E800_ADMIN_ACTION_AUDIT_REQUIRED
  - Когда: операция требует аудита, но контекст отсутствует.
  - details: {action, admin_tg_id?}

- E801_ADMIN_ONLY
  - Когда: endpoint доступен только админам.
  - details: {actor_tg_id?}

- E802_ADMIN_SCOPE_FORBIDDEN
  - Когда: роль/область не позволяет действие.
  - details: {scope, required_scope}

