# Public error message canon

Status: active after `v171_10`.

Sensitive public money-flow screens must not show raw exception strings in
toasts. Use `publicApiErrorMessage(e, t)` for both local form error state and
toast text.

Closed in this pass:

- withdraw create error toast no longer uses raw `e?.message`;
- withdraw cancel error toast no longer uses raw `e?.message`;
- exchange mutation no longer uses preview-unavailable copy;
- `exchange.exchange_failed` exists in all active locales.


## Cycle 1537 update

`publicApiErrorMessage` accepts an operation fallback key while preserving
auth/session mapping to `common.session_expired`. Exchange mutation uses
`exchange.exchange_failed` for non-auth errors.
