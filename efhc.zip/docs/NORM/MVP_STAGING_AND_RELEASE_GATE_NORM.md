# MVP staging and release-gate norm

## Scope
This norm applies to the Browser Shop TON/GRAM and USDT payment contour after green CI proof.

## Controlled staging package
A controlled staging-ready package is considered complete when all of the following are true:
- CI gates are green on the current archive.
- Frontend source archive contains no forbidden registry markers.
- Frontend source archive contains no transient build artifacts.
- TON/GRAM native checkout path is active.
- USDT TEP-74 checkout path is active.
- VIP remains external verification only.
- both payment assets are protected by payment-intent and watcher gates.

## Final release-gate package
A final MVP release-gate package is considered complete when:
- the controlled staging package is complete;
- a final audit document records the green CI proof set;
- the work-cycle queue is updated to reflect that the MVP release layer is closed at archive level.

## Honest boundary
This norm closes archive-level release readiness. It does not pretend that an external deploy was executed from this environment.
