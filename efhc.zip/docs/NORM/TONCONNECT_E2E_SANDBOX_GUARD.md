# TonConnect e2e sandbox guard

Cycle: 1520. Archive target: v170.96.

Production TonConnect behavior is unchanged by default.

For local browser proof and e2e runs, the environment flag
`NEXT_PUBLIC_EFHC_E2E_DISABLE_TONCONNECT_RESTORE=1` prevents wallet-list
restore calls from breaking the visual proof with sandbox network
artifacts.

Runtime hardening was also added to the TonConnect compatibility layer:
failed `getWallets()` now degrades to an empty wallet list and emits a
controlled warning instead of causing a red runtime overlay.

Required distinction:

- disabled by explicit e2e/proof env flag: sandbox proof only;
- no env flag: production integration remains active;
- failed external wallet-list fetch: UI must continue rendering.
