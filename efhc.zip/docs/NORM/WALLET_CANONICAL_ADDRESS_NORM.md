# TON canonical address norm

## Internal format

EFHC Bot internal canonical TON address format is:

```text
<workchain>:<64 lowercase hex account_id>
```

The helper is:

```python
canonicalize_ton_address(address: str) -> str
```

All valid TON address input formats must be normalized before
persistence or ownership comparison.

Accepted input formats include:

- raw;
- friendly;
- bounceable;
- non-bounceable;
- base64;
- base64url.

## Required canonical uses

Canonical address is used for:

- wallet ownership;
- conflict check;
- watcher lookup;
- unique constraint;
- admin wallet tools;
- tests.

Friendly/display address may be stored or rendered separately for UI.
Display address never replaces canonical ownership identity.

## Current storage choice

EFHC Bot uses option A for V1:

```text
wallet_bindings.wallet_address = canonical TON address
```

That field remains unique and is the ownership/conflict/lookup key.

## Existing database backfill

Existing databases may contain historical friendly/raw display formats in
`wallet_bindings.wallet_address`. Cycle 1508 adds the compatibility
backfill `_backfill_wallet_bindings_canonical(conn)` to the active
`0001_init.py` migration layer.

The backfill normalizes valid old values to the same canonical format
used by fresh runtime writes. Canonical collisions stop the migration
with exact row ids instead of silently corrupting ownership.
