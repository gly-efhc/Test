# Migration invariants hardening

Status: NORM
SSOT anchor: `docs/SSOT/SSOT_INDEX.md`

Дата: 2026-03-26

## Подтверждённые инварианты active HEAD
- Схемы БД: только `efhc_core`, `efhc_admin`.
- Таблицы ORM-канона: 35.
- Расклад по схемам:
  - `efhc_core`: 27
  - `efhc_admin`: 5
- `backend/migrations/versions/0001_init.py` создаёт таблицы через
  `Base.metadata.create_all(..., checkfirst=True)`.
- Sanity сверяет `Base.metadata.tables` с
  `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.

## Что закреплено этим циклом
- В active migration docs и планах больше не допускаются устаревшие count/schema формулы.
- В active migration plan запрещены alias-термины для `tg_id`.
- `0001` трактуется как ORM-only производный артефакт, а не как
  источник для расширения таблиц raw SQL.

## Запреты
- Нельзя добавлять extra tables в `0001_init.py` через raw SQL.
- Нельзя расширять migration canon вне `Base.metadata`.
- Нельзя возвращать banned alias-термины для tg_id и `uid` в
  active migration docs/plan.
## Current HEAD audit note

- Этот документ должен читаться вместе с `backend/migrations/MIGRATION_RULES.md` и текущим MVP-каноном `0001 only`.
- Числа и схемные формулы в этом документе следует считать подтверждёнными только в пределах текущего HEAD и периодически перепроверять после каждой новой волны миграционных изменений.

## Overview summary absorbed note

- Short overview figures formerly duplicated in `OVERVIEW_SSOT_SYNC.md` are now considered absorbed by active NORM docs.
- Current headline invariants to read here and in `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md`: 2 DB schemas (`efhc_core`, `efhc_admin`), single-base migration `0001_init.py`, and confirmed migration hardening under the current HEAD.
