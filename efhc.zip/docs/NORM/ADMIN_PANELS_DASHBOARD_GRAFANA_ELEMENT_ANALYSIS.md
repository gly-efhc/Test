# ADMIN_PANELS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS

**Project:** EFHC Bot  
**Cycle:** 1487 — Admin Panels Dashboard Upgrade  
**Archive:** v170.63  
**Mode:** Grafana visual-pattern/reference analysis only

## 1. Boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

No Grafana source code, dependencies, backend logic, auth logic,
datasource logic, alerting logic or plugin logic is copied into EFHC Bot.

## 2. Useful Grafana patterns

| Grafana pattern | EFHC usage |
|---|---|
| DashboardControls | admin panels toolbar rhythm |
| RefreshPicker | manual panels snapshot refresh |
| Variables | display-only lifecycle scope filter |
| PanelChrome | lifecycle/status/age/table panels |
| PanelStatus | fresh/stale/error markers |
| BigValue | total/active/archive/attention KPIs |
| BarGauge | active/archive/expiring/missing-expiry distribution |
| StatusHistoryPanel | panel age bucket strip idea |
| StateTimelinePanel | future real panel lifecycle timeline |
| PanelInspector | safe future panel details without payload dumps |

## 3. EFHC adaptation

The runtime component uses EFHC-owned components:

```text
AdminDashboardToolbar
AdminFreshnessBadge
AdminRefreshPicker
AdminFilterBar
AdminKpiCard
AdminPanelChrome
AdminMiniBarChart
AdminProgressBar
AdminHeatStrip
AdminFlowMapCard
AdminActionTable
AdminStatusBadge
```

## 4. Explicit non-goals

The panels dashboard does not become Grafana.

It does not add real time-series until a read-only backend time-series
contract exists.

It does not show raw payload, debug JSON, secrets or wallet payload.

It does not execute panel activation/deactivation or change lifecycle
rules.
