# Public active-copy guard norm

## Purpose

Public pages must use human product language. Internal implementation terms may
exist in admin, diagnostics, source code and logs, but not in visible public
copy.

## Current enforcement boundary

This file is the current normative boundary for public product language. Removed historical scanner/policy artifacts are not current authority. Validation must use current source/locale review and any current bounded regression guard explicitly present in the physical HEAD; no absent machine guard may be claimed as PASS.

## Forbidden public concepts

Examples include raw payload, backend endpoint, service truth, access key,
watcher, polling, TonProof, proof envelope, diagnostic JSON and runtime
implementation details.

## Boundary

Admin pages and diagnostics may use technical operator language. Public error
messages must remain human, recoverable and action-oriented.
