# Public active-copy guard norm

## Purpose

Public pages must use human product language. Internal implementation terms may
exist in admin, diagnostics, source code and logs, but not in visible public
copy.

## Enforced source of truth

The guard reads actual `t("key")` usages from public frontend surfaces and then
checks the corresponding values in all 13 locale files. It also checks literal
visible JSX text and visible attributes.

The active phrase policy is stored in:

- `ops/policy/public_ui_active_copy.json`;
- `ops/ci_checks/check_public_ui_active_copy.py`.

The gate is part of `make frontend-architecture` through the
`public-active-copy` target.

## Forbidden public concepts

Examples include raw payload, backend endpoint, service truth, access key,
watcher, polling, TonProof, proof envelope, diagnostic JSON and runtime
implementation details.

## Boundary

Admin pages and diagnostics may use technical operator language. Public error
messages must remain human, recoverable and action-oriented.
