# ADMIN_OVERVIEW_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS

**Cycle:** 1481 — Admin Overview Dashboard Upgrade  
**Archive:** v170.57  
**Status:** ACTIVE / DONE LOCALLY

## 1. Boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

No Grafana source code, dependencies, lock files, backend logic,
auth logic, datasource logic, plugins or alerting logic are ported into
EFHC Bot.

## 2. Useful Grafana elements for EFHC Admin Overview

| Grafana element | EFHC use |
|---|---|
| `PanelChrome` | `AdminPanelChrome` wraps overview, facts and boundary panels. |
| `PanelHeader` | Each operator panel has clear title, source and status. |
| `PanelStatus` | Backend overview and Telegram session states are visible. |
| `DashboardGrid` | Overview cards and domain links use mobile-safe grid layout. |
| `DashboardControls` | Toolbar rhythm for overview refresh and freshness. |
| `RefreshPicker` | Read-only overview refresh action, not a write operation. |
| `BigValue` | Backend counters, modules and KPI snapshot values. |
| `Sparkline/TimeSeries` | Not used as real history until backend contracts exist. |
| `StatusHistoryPanel` | Used only as visual idea for domain state strip. |
| `StateTimelinePanel` | Used only as future operator events pattern. |

## 3. EFHC implementation

The EFHC-owned component is:

```text
frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx
```

It uses existing EFHC dashboard components and CSS. It does not import
or copy Grafana runtime code.

## 4. Future usage notes

The same pattern should guide future cycles:

- `1482 — Admin Reports Grafana-like Upgrade`;
- `1483 — Admin Bank Dashboard Upgrade`;
- `1484 — Admin Users Dashboard Upgrade`;
- `1485 — Admin Deposits Dashboard Upgrade`;
- `1486 — Admin Withdrawals Dashboard Upgrade`.

The admin overview should remain the navigation hub and high-level
operator status surface.
