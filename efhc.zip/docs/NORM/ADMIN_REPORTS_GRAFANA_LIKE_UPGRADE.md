# ADMIN_REPORTS_GRAFANA_LIKE_UPGRADE

**Project:** EFHC Bot  
**Cycle:** 1482 — Admin Reports Grafana-like Upgrade  
**Archive:** v170.58  
**Status:** ACTIVE / DONE LOCALLY  
**Layer:** Admin Dashboard Layer  
**Mode:** runtime UI-only / read-only reports / safe inspector

## 1. Purpose

Cycle 1482 upgrades `/admin/reports` into a Grafana-like reporting
surface without turning EFHC Bot into Grafana.

The page must help the operator read the current backend overview quickly:
KPI cards, filter bar, toolbar, panel chrome, charts, safe inspector and
truth boundary.

## 2. Runtime component

```text
frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx
```

The component is integrated into:

```text
frontend/src/pages/admin/reports.tsx
```

## 3. Data model

Truth model:

```text
raw + derived snapshot
```

Source:

```text
/admin/reports/overview
```

Charts are derived from the current overview snapshot. They are not real
time-series. The component must not generate fake history from one
snapshot.

## 4. What the dashboard shows

The upgraded reports dashboard shows:

- admin toolbar with freshness and manual refresh;
- display-only report scope filter;
- overview API status;
- current scope and primary metric;
- counters/facts coverage;
- derived area/bar chart display;
- safe panel inspector;
- metric rows;
- truth/safety boundary.

## 5. Safety boundaries

The reports dashboard is read-only. It must not:

- call write APIs;
- create idempotency keys;
- mutate money state;
- change backend routes;
- change OpenAPI;
- show secrets;
- show raw payload dumps;
- show debug JSON;
- claim real time-series until backend read-only time-series contracts
  exist.

## 6. Grafana / Песочница boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## 7. Acceptance result

- `/admin/reports` has a Grafana-like read-only dashboard surface.
- The old fake trend generator was removed.
- Visual charts are marked as derived snapshot display.
- Export/download boundary remains separate.
- Economy, backend, OpenAPI, dependencies, lock files and write flows are
  not changed.
