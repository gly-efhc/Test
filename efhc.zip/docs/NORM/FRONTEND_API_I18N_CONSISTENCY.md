<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Cycle 1517 addendum — Frontend Buttons / API / i18n Drift Audit

Status: `DONE_LOCALLY`, `VISUAL_NOT_VERIFIED`, `GITHUB_CI_NOT_VERIFIED`.

Cycle 1517 closed the static frontend/API/i18n audit tail:

- admin feature/components now use `adminApiRequest()` and generated admin
  seam constants for `/admin` routes;
- templated admin routes use `adminPath()`;
- direct raw `apiRequest('/admin...')` is forbidden across admin pages,
  admin features and admin dashboard components;
- health widgets remain the only allowed direct `apiRequest` use in admin
  component scope because they call public `/api/health*` routes, not `/admin`;
- Node i18n audit scripts now run with valid CommonJS `__dirname`;
- static internal `href` / `router.push` literals are guarded against missing
  Next pages or unapproved static assets.

Browser capture and click proof were not executed in this cycle.

# Frontend API i18n consistency

Visual browser capture was not executed in this cycle.
Status: `VISUAL_NOT_VERIFIED`.

## User-facing rules

- User-facing UI must not show raw `global_id` when display name exists.
- User-facing UI must not show debug/internal payload text.
- Backend raw errors must be normalized to human-readable messages.
- FAQ is vertical.
- HUB contains only allowed buttons.

| Page/component | Button/action | API client | Backend route | Loading state | Error state | Empty state | i18n key | User-facing text status | Status |
|---|---|---|---|---|---|---|---|---|---|
| Energy | claim/open | api client | energy routes | yes | yes | yes | energy.* | localized | COVERED |
| Panels | buy/view | api client | panels routes | yes | yes | yes | panels.* | localized | COVERED |
| Exchange | exchange | api client | exchange routes | yes | yes | yes | exchange.* | localized | COVERED |
| Tasks | submit/review | api client | tasks routes | yes | yes | yes | tasks.* | localized | COVERED |
| Referrals | copy/open | api client | referral routes | yes | yes | yes | referrals.* | localized | COVERED |
| Ranks | view | api client | ranks routes | yes | yes | yes | ranks.* | localized | COVERED |
| Profile | view | api client | profile routes | yes | yes | yes | profile.* | localized | COVERED |
| Wallet | connect | api client | wallet routes | yes | yes | yes | wallet.* | friendly address | COVERED |
| History | view | api client | history routes | yes | yes | yes | history.* | no raw enum | COVERED |
| FAQ | vertical FAQ | none | none | yes | N/A | yes | faq.* | vertical canon | COVERED |
| HUB | allowed buttons | api client | hub routes | yes | yes | yes | hub.* | allowed only | COVERED |
| Browser-Shop | buy/open | api client | shop routes | yes | yes | yes | shop.* | localized | COVERED |
| Admin Hub | admin nav | admin client | admin routes | yes | yes | yes | admin.* | operator ru | COVERED |
| Admin pages | admin actions | admin client | admin routes | yes | yes | yes | admin.* | operator ru | COVERED |

## Backend raw error mapping canon

Raw backend exceptions must not be rendered directly to users.
Frontend may log technical detail internally, but visible errors must be
human-readable and localized where public i18n applies.


Compatibility boundary: public UI must not show raw `tg_id`.
