
# Audit rules

Статус: active project audit norm.

## 0. Исполнимость без доступа к чату

Любое ТЗ должно быть понятно разработчику без доступа к переписке,
сообщениям чата, внутренним рассуждениям или внешним аудитам.

В ТЗ запрещено ссылаться на:

- «аудит этого чата»;
- «аудитор сказал»;
- «глубокое исследование показало»;
- выводы, которые не лежат в самом архиве проекта;
- недоступные специалисту сообщения чата.

Разрешено ссылаться только на:

1. файлы проекта;
2. конкретные пути файлов;
3. конкретные функции, классы и маршруты;
4. конкретные тесты;
5. новые документы, которые нужно создать внутри архива;
6. воспроизводимые проверки, которые специалист может выполнить локально.

Если причина задачи возникла из проверки, её нужно переписать как
самостоятельное техническое требование, без ссылки на недоступные
сообщения.

## Rule: audit must follow project canon

Аудит обязан проверять код относительно текущего канона проекта.

Запрещено классифицировать как P0/P1 отсутствие механизма, который не
является частью текущего канона. Такой механизм не является частью
текущего канона до отдельного SSOT/NORM изменения. Формула:
механизм не является частью текущего канона без отдельного SSOT/NORM.

Для EFHC Bot V1 отсутствие обязательного backend payout watcher proof в
withdraw-flow не является P0/P1, если заявка закрывается через
разрешённый admin/operator payout-flow.

## Future TZ structure

Каждое будущее ТЗ должно иметь структуру:

```md
# PACK-XX — Название

## 0. Исполнимость без доступа к чату

## 1. Цель

## 2. Канон проекта

## 3. Scope

## 4. Required changes

## 5. Required tests

## 6. Acceptance criteria

## 7. Forbidden changes

## 8. Definition of Done
```

Запрещённый формат будущих ТЗ:

```text
Как указано в аудите...
По результатам глубокого исследования...
Аудитор нашёл...
В этом чате мы решили...
```

Разрешённый формат:

```text
В `docs/NORM/...` закрепить правило...
В `backend/app/...` проверить/обновить функцию...
Добавить test `...`, который проверяет...
Acceptance criteria: ...
```

## Rule: wallet and payout audit must follow project canon

Audit must not treat admin payout UI as treasury/private funds access
when the project canon says payout is an operator wallet action.

Audit must not classify absence of a legacy wallet binding mechanism as
a defect when TonConnect proof and `wallet_bindings` are the active
project canon.

Audit must treat display/friendly TON address as UI format only.
Ownership, watcher lookup, conflict check and unique constraints must be
judged against canonical address storage.
