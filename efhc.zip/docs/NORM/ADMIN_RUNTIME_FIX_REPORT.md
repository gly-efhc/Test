# Cycle 1512 Admin Runtime Fix Report

## Fixed P1 findings

- `P1-WITHDRAW-REPAIR-TYPEERROR`: CLOSED.
- `P1-ADMIN-BONUS-DEBIT-TYPEERROR`: CLOSED.

## Runtime fixes

- Removed unsupported kwargs from withdraw hold repair call to
  `debit_user_to_bank`.
- Added `meta` to `debit_user_bonus_to_bank` and forwarded it to
  `_run_idempotent`.

## Test hardening

Added:

- `tests/efhc_backend/admin/test_admin_withdrawals_hold_repair_`
  `runtime.py`
- `tests/efhc_backend/admin/test_admin_bank_bonus_debit_runtime.py`
- `tests/architecture/test_admin_money_call_signatures.py`
- `tests/architecture/test_admin_frontend_uses_admin_seams.py`
- `tests/architecture/test_admin_orphan_routes_documented.py`

## P2/P3 status

- Admin seams constants now cover all current OpenAPI `/admin` paths.
- Existing raw admin page `apiRequest` calls are tracked as temporary
  migration debt.
- `/admin/shop/items/set-price` is documented as legacy/internal.
- `/admin/tasks/{task_id}` is documented as legacy/internal.

## Proof status

The input CI log for v170.87 was green. This report does not claim fresh
GitHub CI green for v170.88 until a new rerun proves it.
