# MODEL → TABLE → ROUTE → TEST MAP

Status: NORM
SSOT anchor: `docs/SSOT/SSOT_INDEX.md`


Критическая карта соответствия для быстрых аудитов.

- таблицы SSOT: **33**
- маршруты SSOT: **89**
- OpenAPI operations: **89**
- OpenAPI paths: **84**
- test files: **172**

## bank

- model file: `backend/app/models/bank_balance_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/admin/bank/balance`
  - `/admin/bank/mint`
  - `/admin/bank/burn`
- tests:
  - `tests/architecture/test_api_finance_canon.py`
  - `tests/architecture/test_financial_integrity.py`
  - `tests/test_economics_transactions.py`
  - `tests/architecture/test_bank_runtime_invariants.py`

## withdraw

- model file: `backend/app/models/withdraw_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/withdraw/request`
  - `/withdraw/{request_id}`
  - `/withdraw/{request_id}/cancel`
  - `/admin/withdrawals/{request_id}/approve`
  - `/admin/withdrawals/{request_id}/reject`
- tests:
  - `tests/test_withdraw_state_machine.py`
  - `tests/test_concurrency_withdraw_double.py`
  - `tests/test_concurrency_exchange_withdraw.py`
  - `tests/architecture/test_withdraw_runtime_invariants.py`

## exchange

- model file: `backend/app/models/transactions_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/exchange/preview/{tg_id}`
  - `/exchange/convert/{tg_id}`
  - `/exchange/history/{tg_id}`
- tests:
  - `tests/architecture/test_exchange_mirror_and_locks.py`
  - `tests/efhc_backend/unit/test_exchange.py`
  - `tests/test_concurrency_exchange_all.py`

## panels

- model file: `backend/app/models/panels_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/panels/{tg_id}/summary`
  - `/panels/{tg_id}/active`
  - `/panels/{tg_id}/archive`
  - `/panels/buy/{tg_id}`
  - `/panels/activate/{tg_id}`
- tests:
  - `tests/test_panels_180_days.py`
  - `tests/test_panels_ssot_backend.py`
  - `tests/test_panels_idempotent_create.py`

## referrals

- model file: `backend/app/models/referral_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/referrals/counters`
  - `/referrals/active`
  - `/referrals/inactive`
  - `/api/admin/referrals/summary`
- tests:
  - `tests/architecture/test_api_finance_canon.py`
  - `tests/efhc_backend/unit/test_finance_spend_rules.py`

## ranks

- model file: `backend/app/models/ranks_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/ranks/top`
  - `/ranks/my-plus-top`
- tests:
  - `tests/architecture/test_no_banned_rank_terms.py`
  - `tests/architecture/test_forbidden_identifiers_repo.py`

## wallets

- model file: `backend/app/models/wallets_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/wallets/me`
  - `/wallets/connect`
  - `/wallets/{wallet_id}/make-primary`
- tests:
  - `tests/test_wallets_connect_hardening.py`
  - `tests/test_wallets_tonconnect_semantics_guard.py`

## shop

- model file: `backend/app/models/shop_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/shop/catalog`
  - `/shop/purchase-efhc`
  - `/shop/order-external`
  - `/shop/orders`
- tests:
  - `tests/efhc_backend/unit/test_shop_items.py`
  - `tests/efhc_backend/unit/test_orders.py`
  - `tests/architecture/test_deposit_packages_contract.py`

## tasks

- model file: `backend/app/models/tasks_models.py`
- tables:
  - `efhc_core.bank_balance`
  - `efhc_core.efhc_transfers_log`
- routes:
  - `/tasks/catalog`
  - `/tasks/my/{tg_id}`
  - `/tasks/claim/{tg_id}`
  - `/api/admin/tasks`
- tests:
  - `tests/test_per_sec_constants_settings.py`
  - `tests/test_build_sanity.py`


## hub_links

- model file: `backend/app/models/hub_links_models.py`
- table: `efhc_core.hub_links`
- routes:
  - `/admin/hub/links`
  - `/admin/hub/links/{link_id}`
  - `/admin/hub/links/{link_id}/toggle`
  - `/admin/hub/links/reorder`
  - `/admin/shop/hub-links`
  - `/admin/shop/hub-links/{link_id}`
  - `/admin/shop/hub-links/{link_id}/toggle`
  - `/admin/shop/hub-links/reorder`
- tests:
  - `tests/architecture/test_hub_admin_routes_services_wave_lock.py`
  - `tests/architecture/test_hub_admin_ui_wave_lock.py`

## 2026-03-28 — cycle 74 hub_links

- model: `backend/app/models/hub_links_models.py`
- table: `efhc_core.hub_links`
- migration: `backend/migrations/versions/0001_init.py`
- test: `tests/architecture/test_hub_admin_migration_model_wave_lock.py`

- Panels activation canonical route: `POST /panels/activate/{tg_id}`.
- Compatibility route remains: `POST /panels/buy/{tg_id}`.
## Current HEAD audit note

- Этот документ является derived control-map и должен регулярно синхронизироваться с `backend/openapi/openapi.json`, `docs/NORM/MIGRATION_INVARIANTS_HARDENING.md` и route/test inventory after significant backend changes.
- Числа tables/routes/paths/operations/test files следует считать подтверждёнными только в пределах текущего HEAD и периодически перепроверять.

## Overview summary absorbed note

- Short overview figures formerly duplicated in `OVERVIEW_SSOT_SYNC.md` are now maintained through this control-map and related NORM migration docs instead of through a separate overview summary file.
- Current quick-audit figures in this document remain the active source for tables/routes/OpenAPI/tests counts for the current HEAD.

## Route/OpenAPI generation hardening

Current HEAD keeps deterministic regeneration of route inventory markdown from
`docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv` via
`ops/routes/regenerate_route_inventory_md.py`. This hardening replaces the
older standalone note from cycle 169.
