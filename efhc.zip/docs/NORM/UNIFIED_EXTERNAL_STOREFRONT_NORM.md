# Unified external storefront norm

## Canon

1. WebApp and browser flow are one frontend shell.
2. Telegram is a handoff and context layer only.
3. The storefront itself opens outside Telegram.
4. The external storefront may live in the same backend/admin repo.
5. Repo location does not redefine the storefront as an in-Telegram sale.
6. EFHC top-up flow and VIP verification flow must stay split.
7. TON/TonConnect runtime path must stay common for the shared shell.


## 2026-04-11 — audit iteration clarification

8. External browser-shop is not anonymous by default when entered through
   the approved handoff path.
9. The signed handoff token binds the storefront session to the player
   profile context.
10. Guest-mode or bootstrap screens must not visually overstate
    completion guarantees beyond what the signed handoff actually proves.

## Consolidated planning rules from AI temporary memory — 2026-04-24

The following browser-shop planning rules are now treated as NORM-level working
rules where they do not conflict with newer code or SSOT documents:

1. Browser-shop MVP uses one storefront and one checkout pattern.
2. One selected product or one custom EFHC amount creates one operation.
3. Cart complexity is outside the MVP model.
4. Telegram linking is required before final payment confirmation.
5. Handoff-key automatic linking is preferred when available.
6. Page-top controls for Telegram and wallet sync must exist when automatic
   binding is unavailable.
7. Package cards, custom EFHC purchase and VIP NFT cards share one checkout
   skeleton while keeping different post-payment semantics.
8. The status screen is required and must separate waiting, confirmed,
   credited/manual issue, expired and error outcomes.
9. Browser-shop may look visually separate from Telegram WebApp while still
   using the same account and backend truth-layer.
10. Sandbox and donor repositories are reference-only until manually adapted.
