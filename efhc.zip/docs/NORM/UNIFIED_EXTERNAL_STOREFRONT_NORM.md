# Unified external storefront norm

## Canon

1. WebApp and browser flow are one frontend shell.
2. Telegram is a handoff and context layer only.
3. The storefront itself opens outside Telegram.
4. The external storefront may live in the same backend/admin repo.
5. Repo location does not redefine the storefront as an in-Telegram sale.
6. EFHC top-up flow and VIP verification flow must stay split.
7. TON/TonConnect runtime path must stay common for the shared shell.
