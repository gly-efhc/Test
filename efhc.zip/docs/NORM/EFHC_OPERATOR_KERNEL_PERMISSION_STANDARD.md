# EFHC Operator Kernel Permission Standard — compatibility pointer

Status: DEPRECATED PATH / NOT AN ACTIVE RULE SOURCE.

The active consolidated rule is `docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md`. This `PERMISSION` path remains only so historical references do not break.
