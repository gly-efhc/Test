<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Cycle 1497 sync note

`1497 — Dashboard Direction Audit Follow-up / Future Range Foundation` is complete locally in `v170.73`. It accepts the audit verdict `DIRECTION_COMPLETE_WITH_KNOWN_GAPS`, closes the orphan synthetic `buildSeries` risk, consolidates missing UI Kit wrappers from plan §9/§10, and creates the next future range document `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md`. Dashboard direction `1455–1496` remains closed at `42 / 42`; 1497 is an audit-follow-up and backlog planning cycle.

# Cycle 1496 sync note

`1496 — Dashboard Direction Handoff / Backlog Freeze` is complete locally in `v170.72`. Dashboard direction `1455–1496` is closed at `42 / 42`. User-facing dashboards are fixed as a 13-language public UI surface across `en, ru, uk, de, fr, es, it, tr, pl, da, hi, id, sw`; admin dashboards remain a Russian operator surface and are not part of that public 13-language claim. Remaining work is frozen into backlog.

# Cycle 1494 sync note

`1494 — Accessibility / Localization / Overflow QA` is complete locally in `v170.70`. Dashboard truth remains unchanged; this cycle hardens readable/accessibility-safe presentation on narrow Telegram/browser surfaces. Next safe cycle: `1495 — Final Dashboard Visual Audit / Screenshot Proof`.

# Cycle 1493 sync note

`1493 — Visual Performance / Bundle Safety` is complete locally in `v170.69`. Admin-heavy real time-series panel loading is now guarded by a lazy boundary on `/admin`; Grafana and Песочница remain reference-only. Next safe cycle: `1494 — Accessibility / Localization / Overflow QA`.

# Cycle 1491 sync note

`1491 — Real Time-Series Backend Contracts` is complete locally in `v170.67`. Real time-series now means backend history from runtime truth tables only. Frontend synthetic history from one snapshot remains forbidden. Next safe cycle: `1492 — Synthetic Data Cleanup / Truth Hardening`.

# Cycle 1490 sync note

`1490 — Admin Logs / Events Dashboard` is complete locally in `v170.66`. Logs/events truth remains `raw + derived snapshot`; no fake time-series, raw payload, debug JSON, secrets or dashboard write actions are allowed. Next safe cycle: `1491 — Real Time-Series Backend Contracts`.

# Cycle 1488 sync note

`1488 — Admin Tasks / Referrals Dashboard Upgrade` is complete locally in `v170.64`. Dashboard truth remains `raw + derived snapshot`; no fake time-series, fake referral growth, raw payload, debug JSON, secrets or dashboard write actions are allowed. Next safe cycle: `1489 — Admin System Health Dashboard`.

# Cycle 1484 sync note

`1484 — Admin Users Dashboard Upgrade` is complete locally in `v170.60`. `/admin/users` now has a read-only admin dashboard layer. No fake retention, fake time-series, raw payload, debug JSON, secrets or dashboard write actions are allowed. Next safe cycle: `1485 — Admin Deposits Dashboard Upgrade`.

# Cycle 1478 sync note

`1478 — Referrals Dashboard Upgrade` is complete locally in v170.54.
Live `/referrals` now has a dashboard section using raw + derived
referral stats only. It does not change the active-only `+0.1 EFHCbb`
bonus rule, backend, economy, write-flow or money-flow. The next safe
cycle is `1479 — Exchange Dashboard Support Widgets`.

# Cycle 1477 sync note

`1477 — Tasks Dashboard Upgrade` is complete locally in v170.53.
Tasks now has a runtime dashboard component on `/tasks`; it does not
change rewards, claim flow, ads flow, backend, economy or write-flow.
The next safe cycle is `1478 — Referrals Dashboard Upgrade`.


# Cycle 1476 sync note

`1476 — Leaderboard Visual System` is complete locally in v170.52.
Ranks now has a shared EFHC-owned leaderboard visual system for podium
and list cards. The next safe cycle is `1477 — Tasks Dashboard Upgrade`.


> Cycle 1475 runtime note: Ranks runtime dashboard is live on `/ranks`
> as UI-only read-only port. It uses backend ranks snapshot truth, does
> not expose raw `global_id`, does not restore public 12 Energy levels and
> does not invent leaderboard rows.

# Cycle 1474 update — Ranks Dashboard Sandbox Prototype

- Ranks sandbox prototype is active in v170.50.
- Runtime `/ranks` is not changed in this cycle.
- Ranks remains leaderboard/motivation dashboard, not a public Energy
  level catalogue.
- Synthetic preview must stay clearly marked until runtime port.
- Next safe step: `1475 — Ranks Dashboard Runtime Port`.


> Cycle 1473 note: Panel Cards Deep Polish is active in
> `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/PANEL_CARDS_DEEP_POLISH.md`. Runtime panel cards now
> expose micro states and accessibility markers. Sandbox preview
> generation rates are formula-derived from generated kWh and seconds.
> Grafana and Песочница remain reference-only layers. Next safe cycle:
> `1474 — Ranks Dashboard Sandbox Prototype`.

> Cycle 1472 note: Panels Portfolio Runtime Port is active in
> `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/PANELS_PORTFOLIO_RUNTIME_PORT.md`. The live `/panels`
> route now renders EFHC-owned `PanelsPortfolioRuntime` with raw +
> derived snapshot data only. No synthetic runtime data and no real
> time-series are claimed. Next safe cycle: `1473 — Panel Cards Deep Polish`.

> Cycle 1471 note: Panels Portfolio Sandbox Prototype is active in
> `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/PANELS_PORTFOLIO_SANDBOX_PROTOTYPE.md`. The EFHC-owned
> prototype lives in `frontend/src/components/dashboard/PanelsPortfolioSandboxPrototype.tsx`
> and uses `synthetic_preview` markers only. Runtime `/panels` is not
> changed. Grafana and Песочница remain reference-only layers. Next safe
> cycle: `1472 — Panels Portfolio Runtime Port`.

> Cycle 1470 note: Energy Dashboard Visual QA is active in `v170.46`.
> Runtime Energy dashboard passed static visual QA and local HTTP proof.
> Browser screenshot capture was attempted but blocked by environment policy, so screenshot proof is not claimed.
> Safe UI fixes: RU raw/derived labels localized, mobile overflow hardening added, visual QA markers added.
> Next safe cycle: `1471 — Panels Portfolio Sandbox Prototype`.

> Cycle 1469 note: Energy Dashboard Runtime Port is active in `v170.45`.
> The live Energy route now contains an EFHC-owned runtime dashboard
> based on raw/derived `SyncSnapshot` values. Synthetic preview data is
> not used in runtime and real time-series are not claimed.
> Next safe cycle: `1470 — Energy Dashboard Visual QA`.

> Cycle 1468 note: Dependency Audit Triage is active in `v170.44`.
> The dashboard plan is shifted from `1455–1495 / 41 cycles` to
> `1455–1496 / 42 cycles`.
> `1469 — Energy Dashboard Runtime Port` is now the next safe dashboard runtime step.
> Dependency repair is a safety interlock before runtime port; it does not change EFHC economics or dashboard truth.

> Cycle 1467 note: Energy Dashboard Sandbox Prototype is active in
> `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/ENERGY_DASHBOARD_SANDBOX_PROTOTYPE.md`. The prototype is
> sandbox-only, uses `synthetic_preview`, and prepares cycle 1468 runtime
> mapping without changing live Energy truth.


> Cycle 1465 note: Dashboard Toolbar Foundation is active in
> `docs/NORM/DASHBOARD_TOOLBAR_FOUNDATION.md`. Shared runtime toolbar
> lives in `frontend/src/components/dashboard/DashboardToolbar.tsx`.
> Grafana and Песочница remain reference only.

> Cycle 1462 note: Panel Chrome Foundation is active in
> `docs/NORM/PANEL_CHROME_FOUNDATION.md`. Shared runtime shell lives in
> `frontend/src/components/dashboard/PanelChrome.tsx`; admin and
> simulation wrappers are `AdminPanelChrome` and `SimPanelChrome`.
> Grafana and Песочница remain reference only.

> Cycle 1461 note: Admin Dashboard UI Kit Foundation is active in
> `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`.
> Additional Grafana element usage map is active in
> `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
> Runtime foundation extends
> `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
> Grafana and Песочница remain reference only.

# DASHBOARD VISUAL KERNEL

Status: `ACTIVE_DASHBOARD_VISUAL_KERNEL`

Cycle: `1455`

Archive target: `v170.31`

## Purpose

This document is the short operational kernel for the Dashboard Visual
Direction Plan. It tells the next AI agent where the dashboard truth
lives, what may be designed, what must not be copied, and where the
next cycle starts.

## Active truth

Primary Dashboard Visual Direction Plan document:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Screenshot preparation document:

`docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`

Grafana reference map:

`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`

Machine manifests:

- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/generated/dashboard_visual_direction_plan_v170_28.json`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/generated/dashboard_screenshot_proof_manifest_v170_30.json`;
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/generated/dashboard_visual_kernel_v170_31.json`.

## Two dashboard layers

### Admin Dashboard Layer

Operator dashboards for overview, reports, bank, users, deposits,
withdrawals, panels, tasks, system health, logs and events.

### Simulation Dashboard Layer

User-facing visual simulation for Energy, Panels, Ranks, Tasks,
Referrals, Exchange and Web Profile.

## Non-negotiable boundaries

- EFHC Bot does not become Grafana.
- Grafana is visual-pattern reference only.
- Песочница is reference, navigation and prototype layer only.
- Runtime code from Grafana or Песочница must not be copied.
- Lock files, CI files, backend logic and wallet/payment logic from
  external references must not be copied.
- Synthetic preview data must be marked as preview.
- Beautiful charts must not replace backend truth.
- Dashboard work must not change EFHC economy.
- Dashboard work must not remove, hide, skip or xfail tests.

## Required dashboard pipeline

```text
Песочница prototype -> visual proof -> runtime port -> tests -> docs
-> screenshot proof
```

If a dashboard component changes screen structure, it should have a
sandbox/prototype proof before runtime port.

## Start route for cycle 1456

Cycle `1456` should create the Sandbox Dashboard Inventory:

1. read this file;
2. read `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`;
3. read `docs/frontend/DASHBOARD_SCREENSHOT_PROOF_PREPARATION.md`;
4. read `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md` Grafana and Песочница sections;
5. inspect Песочница and existing dashboard/admin UI components;
6. produce a reuse/porting map;
7. do not port runtime code yet.

## Allowed Grafana reference patterns

- PanelChrome;
- DashboardGrid;
- RefreshPicker;
- DateTimePickers;
- PanelHeader;
- DashboardPageProxy;
- panel menu and safe inspector patterns;
- toolbar, time range, variables and freshness markers.

The implementation must be own EFHC code, not copied Grafana runtime.

## Success criteria for this kernel

- dashboard direction is visible from `KERNEL.md`;
- dashboard plan is visible from `routes.yaml`;
- dashboard reference map is visible from `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/map_element.md`;
- dashboard tests guard the reference-only boundary;
- the next agent can start cycle `1456` without guessing.


## Cycle 1456 inventory update

Active inventory document:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Cycle 1456 classifies sources into:

- runtime-safe existing EFHC components;
- prototype-only reference sources;
- forbidden-to-port sources;
- truth-hardening-required components.

Cycle 1457 must build the Grafana Visual Pattern Map from this
inventory without copying Grafana runtime code.

## Cycle 1457 pattern map update

Active Grafana pattern map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Cycle 1457 maps Grafana-like patterns to EFHC-owned implementation
targets. It does not import Grafana runtime code, dependencies, lock
files, CI files or backend logic.

Cycle 1458 must create Dashboard Design Tokens Foundation using EFHC
CSS/Tailwind-first discipline.


## Cycle 1458 update

Design tokens are now active in
`docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md` and
`frontend/src/styles/globals.css`.

The token layer is EFHC-owned. It is inspired by the Grafana pattern
map but does not import Grafana runtime code, themes or dependencies.

Next cycle: `1459 — Dashboard Component Contract`.


## Cycle 1459 component contract update

Active contract document:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Runtime type contract:

`frontend/src/lib/dashboard/componentContract.ts`

Every future dashboard panel must support:

- loading;
- empty;
- error;
- stale;
- success.

Every panel must declare source and data kind.

Synthetic preview data must be clearly marked and must not be shown as
runtime truth.

Next safe step: `1460 — Simulation Dashboard UI Kit Foundation`.

## Cycle 1460 simulation UI kit anchor

Simulation Dashboard UI Kit Foundation:
`docs/NORM/SIMULATION_DASHBOARD_UI_KIT_FOUNDATION.md`

Runtime component:
`frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`

Old dashboard preservation check:
`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/audits/DASHBOARD_DELETION_CHECK_V170_36.md`

## Cycle 1479 kernel note

Exchange dashboard widgets are support-only. They may visualize raw and
derived exchange preview values, but they must not execute conversion,
change the 1:1 rule, add reverse exchange or create fake exchange
history.

Next safe cycle: `1480 — Web Profile / Account Center Dashboard Polish`.

## Cycle 1480 — Web Profile Account Center

Web-Profile now has a read-only Account Center dashboard summary. It is a
public account surface, not an admin inspector. It must not expose raw `global_id`,
initData, raw payload or debug JSON. Wallet/history write flows remain in their
existing guarded sections.
## Cycle 1481 — Admin Overview Dashboard Upgrade

Admin Overview is now a read-only operator dashboard layer for `/admin`.
It uses raw + derived snapshot data from the existing admin overview
endpoint and existing admin navigation modules. Synthetic admin analytics,
raw payload dumps, debug JSON and write-flow bypass are forbidden.

Next safe cycle: `1482 — Admin Reports Grafana-like Upgrade`.

## Cycle 1482 completion note

`1482 — Admin Reports Grafana-like Upgrade` was completed locally as
`v170.58`. `/admin/reports` now has a Grafana-like read-only dashboard
surface with toolbar, freshness, display-only filters, panel chrome,
derived snapshot charts and a safe inspector. The old fake trend
generator from a single snapshot was removed. Next safe cycle is
`1483 — Admin Bank Dashboard Upgrade`.

## Cycle 1483 active update — Admin Bank Dashboard Upgrade

- `/admin/bank` now has `AdminBankDashboardRuntime.tsx`.
- Truth model is `raw + derived snapshot`.
- Bank can go negative canon is visible in dashboard panels.
- Mint/burn remains outside dashboard widgets in guarded confirmation flow.
- Synthetic admin analytics and fake time-series remain forbidden.
- Next safe cycle: `1484 — Admin Users Dashboard Upgrade`.



## Runtime dashboard status — 1489

`1489 — Admin System Health Dashboard` is completed in v170.65. System health uses read-only health endpoints and keeps Diagnostics as the technical boundary.


## v170.68 / cycle 1492 truth hardening
- Runtime dashboard surfaces must not synthesize history from one snapshot.
- `/admin` uses `AdminObservabilityTimeseriesDashboardRuntime` and `/admin/observability/timeseries`.
- `synthetic_preview` is allowed only in sandbox/prototype components with explicit labels.


## Cycle 1495 — Final Dashboard Visual Audit / Screenshot Proof — DONE v170.71

- Attached log failures from `logs_73325744958.zip` repaired.
- Public dashboard locale key parity across 13 active locales confirmed.
- Dashboard localization placeholder prefixes are blocked by guard.
- Static screenshot matrix prepared; browser screenshot capture is not claimed.
- Overall progress: `1401–1500` = `95 / 100`, remaining `5 / 100`.
- Dashboard progress: `1455–1496` = `41 / 42`, remaining `1 / 42`.
- Next safe cycle: `1496 — Dashboard Direction Handoff / Backlog Freeze`.
