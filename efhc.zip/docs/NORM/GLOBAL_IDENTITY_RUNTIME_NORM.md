<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# GLOBAL IDENTITY RUNTIME NORM

Статус: **NORM / ACTIVE**  
Версия среза: **v173.29 / цикл 1706**

## 1. Обязательный контур

Любое identity-изменение проверяется целиком:

`signature → callers → DTO → ORM → SQL → routes → frontend → tests → guards`.

Нельзя менять только колонку или сигнатуру, оставляя provider subject
как owner в соседнем слое.

## 2. Runtime

После `provider + subject → global_id` все business services получают
и используют `global_id`. `tg_id` остаётся только в Telegram ingress,
delivery, mapping и точечном historical read-through.

## 3. Test-layer

Business tests обязаны создавать canonical string `global_id`,
использовать его в owner FK и ожидать его во внутренних API.

Каждое допустимое тестовое употребление `tg_id` регистрируется
построчно с provider-семантикой. Широкая directory allowlist и
фиктивное `tg_id = global_id` запрещены.

## 4. Document-layer

Только документы из active index могут задавать текущий закон.
Исторические аудиты и superseded bytes, признанные устаревшими, не возвращаются в active HEAD и хранятся только во внешнем history ZIP пользователя. Канонические `docs/cycles/`, `docs/chats/` и `reports/numbered/` остаются в проекте как структурированная immutable history и не определяют active runtime semantics.

Архивирование не переписывает историю; active tests/tooling не должны зависеть от удалённых historical bytes.

## 5. Migration и schema

- один Alembic head;
- только `0001_initial_release_schema.py`;
- fresh и pre-release upgrade приводят к одной schema;
- owner FK на `users.tg_id` запрещены;
- dual-write owner запрещён.

## 6. Метрики

Раздельно считаются `CODE`, `TESTS`, `ACTIVE DOCUMENTS`,
`ARTIFACT DOCUMENTS` и `GENERATED REPORTS`.

Главная кодовая метрика: `business-owner tg_id = 0`.


## TON provider subject naming

Для `provider=ton` единственное каноническое provider-specific имя —
`ton_wallet_id`; значение — адрес TON-кошелька. `ton_address` запрещено как
provider-subject alias. Generic storage `provider_subject` сохраняется как
универсальная колонка identity table и для TON содержит `ton_wallet_id`.

## 7. Security/audit identity

Privileged session owner и audit actor — только `global_id`. Provider subjects не логируются в raw-виде и не включаются в новые internal signed handoff claims. Для Telegram delivery `tg_id` может существовать только на provider boundary отдельно от business owner.


## 8. Cross-layer admin consistency

Для admin-доступа цепочка обязательна end-to-end:
`session global_id -> whitelist global_id -> explicit RBAC role -> protected route -> frontend access probe`.
Frontend/provider metadata не может заменять server-side RBAC. Любой compatibility
code, автоматически повышающий роль, запрещён.

## Post-migration cleanup norm — cycle 1713

After qualification, transition-only runtime code must not be reintroduced: dual-write/read-switch control tables, owner selector aliases, hidden business `/{tg_id}` routes, no-caller compatibility wrappers, test-only production façades and temporary migration stubs are forbidden. External/stored-data compatibility may remain only with an explicit real boundary and must not become business ownership.


## Active-account runtime gate

После разрешения `global_id` существование account недостаточно: для выдачи и
использования server-side session, financial/nonfinancial read-owner и
privileged Admin resolution требуется `efhc_core.users.is_active IS TRUE`.
Admin-деактивация отзывает active `auth_sessions` того же `global_id` до
единственного commit. Stateless signed handoff при каждом разрешении owner
повторно проверяет active core account; ранее подписанный token не обходит
account kill-switch.
