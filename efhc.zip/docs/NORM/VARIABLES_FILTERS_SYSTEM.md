<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# VARIABLES / FILTERS SYSTEM

Status: `ACTIVE_VARIABLES_FILTERS_SYSTEM`

Cycle: `1466`

Archive target: `v170.42`

## Purpose

Cycle 1466 creates the reusable dashboard variables / filters system for
EFHC Bot Dashboard Visual Direction.

The system gives Admin Dashboard Layer and Simulation Dashboard Layer one
safe visual language for status filters, route filters, operation type
filters, period filters, panel state filters, leaderboard scopes, task
status filters and referral scopes.

## Active sources

Primary direction:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Dashboard kernel:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Component contract:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Toolbar foundation:

`docs/NORM/DASHBOARD_TOOLBAR_FOUNDATION.md`

Grafana usage map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Runtime component:

`frontend/src/components/dashboard/DashboardFilters.tsx`

Admin wrapper:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

Simulation wrapper:

`frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`

## Runtime components

Shared exports:

- `DashboardFilterBar`;
- `DashboardVariableBar`;
- `DashboardFilterChip`;
- `DashboardFilterResetButton`;
- `DashboardFilterGroup`;
- `isSafeDashboardFilterQueryKey`.

Admin wrappers:

- `AdminVariableBar`;
- `AdminFilterBar`;
- `AdminStatusFilter`;
- `AdminOperationTypeFilter`;
- `AdminDateRangeFilter`;
- `AdminRouteFilter`.

Simulation wrappers:

- `SimFilterBar`;
- `SimPeriodFilter`;
- `SimPanelStateFilter`;
- `SimLeaderboardScopeFilter`.

## Allowed filter domains

Admin filter kinds:

- `status`;
- `route`;
- `operation_type`;
- `user_segment`;
- `date_range`;
- `source`;
- `severity`.

Simulation filter kinds:

- `panel_state`;
- `period`;
- `leaderboard_scope`;
- `task_status`;
- `referral_scope`.

## URL query boundary

URL query sync is allowed only as `safe_display_only` and only for safe
query keys.

The foundation explicitly rejects unsafe query key fragments such as
secret, token, payload, initData, password, private key material, seed,
mnemonic and raw `global_id`.

URL query sync must never become a source of business truth. It may only
restore a visual filter selection for read-only dashboard display.

## Safety boundary

Filters are display controls only.

They do not change EFHC economy, backend state, database schema, payment
logic, wallet logic, user balances, admin decisions, idempotency, money
path, OpenAPI contracts, CI or lock files.

They do not create write actions. They expose only selection/reset UI
callbacks and must not call backend write routes directly.

Admin filters must not render secrets, raw payloads, raw initData, debug
JSON or private data.

Simulation filters must not render raw `global_id`, fake leaderboard scopes
or synthetic achievements as real data.

## Grafana reference

Grafana variables and controls are used as conceptual references only:

- `Variables`;
- `DashboardControls.tsx`;
- `TimeRangePicker.tsx`;
- `RelativeTimeRangePicker/`;
- `RefreshPicker.tsx`;
- `PageToolbar.tsx`.

No Grafana source code is copied.
No Grafana dependency is added.
No Grafana runtime schema is imported.

## Acceptance checks

A valid dashboard filter implementation must prove:

- shared components exist;
- Admin wrappers exist;
- Simulation wrappers exist;
- filter controls are read-only display controls;
- URL query sync is marked safe-only and rejects dangerous keys;
- no raw `global_id`, secrets, payloads or debug JSON are exposed in filter UI;
- Grafana is reference only;
- `docs/history/legacy_artifacts/map_element.md`, Kernel routes and generated report are updated.

## Next cycle

`1467 — Energy Dashboard Sandbox Prototype`.
