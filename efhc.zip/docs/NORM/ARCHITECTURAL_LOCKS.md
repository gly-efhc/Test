# Architectural Locks

Статус: NORM (нормативный документ разработки). Якорь SSOT:
docs/SSOT/SSOT_INDEX.md

Назначение:
- Этот документ фиксирует архитектурные запреты и ограничения
  разработки.
- Продуктовые нормы (термины, экономика, банк, выводы, TON) живут в
docs/SSOT/EFHC_CANON.md и docs/SSOT/TERMS_GLOSSARY.md.

Приоритет и конфликты:
- Источник приоритета документов: docs/SSOT/SSOT_INDEX.md.
- Если DERIVED-документ (architecture/specification и т.п.) конфликтует
  с
NORM, он подлежит обновлению.
- Если код конфликтует с NORM, это дефект: требуется правка кода или
  NORM
через осмысленное изменение и тесты.

Инструменты контроля:
- ops/canon_rules.yaml и ops/canon_guard.py реализуют проверки канона,
но не заменяют SSOT_INDEX и NORM-документы.

---

## LOCK: runtime logs location

Правило:
- Все runtime-логи проекта пишутся только в `reports/`.
- Запрещено создавать log/session/strict файлы и каталоги
  вне `reports/`.


## LOCK: tg_id only in public runtime surfaces

Правило:
- В runtime-коде, API, логах, событиях и схемах допускается только
  tg_id.
- Запрещены любые алиасы внешнего идентификатора пользователя.

Разрешено:
- Внутренний PK БД может называться user_pk/row_id, но он не должен
утекать наружу и не должен подменять tg_id.

Админ-контур:
- allowlist/авторизация админа: только по tg_id (Settings/ENV).
- public row_id запрещён везде, включая admin.

---

## LOCK: UI navbar fixed (6 tabs, order)

Запрещено менять состав и порядок нижней навигации.

Канон (ровно 6 вкладок, фиксированный порядок): 1) Energy 2) Panels 3)
Exchange 4) Tasks 5) Referrals 6) Ranks

Любые изменения допускаются только через обновление NORM/SSOT и guard.

---

## LOCK: UI labels always English

Запрещено локализовать кнопки/лейблы/названия вкладок/уровней.

Канон:
- UI labels (tabs/buttons/field labels) — всегда EN.
- Levels / ranks names — всегда EN.
- Выбор языка влияет только на descriptions/описания.

---

## LOCK: Profile entrypoint + SSOT settings list

Канон входа: Profile открывается по нажатию на аватар в левом
верхнем углу.

SSOT список настроек (утверждён): 1) Telegram display name (RO) 2)
Username (RO) 3) VIP badge (RO) 4) Avatar (Telegram default + custom +
reset) 5) Descriptions language (13 langs, EN first) 6) UI sounds
(on/off) 7) Sound volume 8) Sound pack 9) Haptics (on/off) 10) Hide
balances 11) Show decimal detail (still 8 decimals) 12) Reduce motion
13) Confirm before purchase 14) Confirm before withdraw request 15)
Confirm before convert kWh→EFHC 16) Confirm before watch ad 17) In-app
toasts 18) Important alerts only 19) FAQ 20) Support chat 21) Terms 22)
Privacy 23) Reset settings

---



## LOCK: GlobalHeader status badges + profile entrypoint

Канон:
- В `GlobalHeader` должны существовать badge `VIP` и `Activ`, если
  соответствующие статусы есть у пользователя.
- User-facing вход обозначается как `Профиль / Профіль / Profile`.
- Архивные панели не должны просачиваться в Energy summary.
- На странице Energy допускаются только активные панели и их текущая
  суммарная генерация.

## LOCK: Admin entry via Profile (tg_id allowlist)

Канон:
- Пункт Admin Panel виден только если tg_id входит в allowlist.
- Элемент отображается только внутри Profile.



## Economy SSOT Locks: Generation & Exchange

SSOT: механика обмена и вывода — см.
docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

SSOT: механика панелей — см. docs/SSOT/PANELS_SSOT.md


- **Lock: total_generated_kwh is append-only** (never decreases).
- **Lock: exchanged_kwh_total is append-only** (never decreases).
- **Mirror formula (source of truth):**
  `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`
- **EXCHANGE_ALL** MUST:
  - increase `exchanged_kwh_total` by `available_kwh_before`
  - credit EFHC **MAIN** 1:1
  - never mutate `total_generated_kwh`
  - `available_kwh` существует только как вычисляемое зеркало
  по формуле mirror result.


## Общие логи (reports/)

Подробные логи изменений ведутся только в `reports/`.
`reports/REPORTS_INDEX.md` — каноничный нумерованный реестр
`append-only`: каждая новая запись добавляется строго по порядку
и получает следующий номер без пропусков.


## Overview docs sync (MUST)

- Обзорные документы обязаны совпадать с `docs/SSOT/ssot_pack/*`.
- `docs/NORM/TESTS_CATALOG.md` обязан совпадать с реальным `tests/**`.
- Для быстрого аудита использовать `docs/OVERVIEW_SSOT_SYNC.md` и
  `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md`.


## LOCK: Healer + registry + reports triple write

Канон текущего цикла разработки:
- Каждая подтверждённая проблема и её лечение фиксируются во все три
  места одновременно:
  - Healer
  - `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
  - `reports/`
- `reports/` — обязательная постоянная запись каждого цикла.
- Healer — медицинская память проекта и не отменяет текущую
  обязательность `reports/` и реестра ошибок.

## LOCK: Continuation prompt for new chat

Для старта нового чата использовать документ:
- `docs/AI/CONTINUE_NEW_CHAT_V162_02_PROMPT.md`

Текущая документная фаза опирается на `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv`,
`docs/GENERAL/MASTER_DOCUMENT_INDEX.md` и `docs/GENERAL/ARCHIVE_NAV_INDEX.md`.

## Historical trace lock

как audit/report/migration history. Они не могут возвращаться в
active architecture, runtime imports, API routes или SSOT tables.


## LOCK: document phase package exclusions

В обычные пакеты документной ревизии не входят:
- `docs/audits/`;
- `reports/`;
- log-документы;
- `artifacts/`, если пользователь не дал отдельное решение.

## LOCK: inventory answer format

Для файлов документной ревизии описание даётся связными абзацами, а
в конце обязательно формулируется отдельное предложение по файлу.
