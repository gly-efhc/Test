<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Блокировка цикла 1611 — PostgreSQL gate

До реального `PG-0 PASS` разрешены только подготовленные ORM, migration,
static guards и PostgreSQL tests. Запрещены runtime `IdentityResolver`,
account/session creation, backfill, ownership/read switch и переход к
циклу 1612. PostgreSQL в среде чата не устанавливается; существующие
GitHub CI workflows не изменяются.

# Блокировка цикла 1609

`AuthProvider` и `VerifiedIdentity` являются provider-neutral
контрактами. Provider registry работает fail closed, Telegram не
является root provider, а `global_id` остаётся единственным account
owner. До последующих циклов запрещены DDL, account resolution,
sessions, backfill, read switch и financial ownership switch.

## Cycle 1598 LEGACY alias lock

The active compatibility alias is
`User.legacy_runtime_id -> User.id`; it is restricted to migration,
reconciliation and compatibility tests. The future alias from
`User.id` to `User.user_id` remains inactive until the separately
approved read switch. Backfill execution is forbidden in cycle 1598.

## Cycle 1595 — immutable identity value-type lock

The only allowed backend adoption in this cycle is the isolated `backend/app/identity` value-type package. `UserId` and `TelegramId` must remain distinct nominal objects. Models, migrations, services, CRUD, routes, schemas, dependencies and frontend ownership are protected by a 481-file semantic/exact manifest. Comments may be corrected, but executable semantics must remain unchanged.

## LOCK: Single startup and active Operator Kernel architecture — v171.64

- `START_HERE.md` is the only active startup order.
- `KERNEL.md` is the active full detailed dispatch layer: keywords, task types, exact routes, canonical anchors, patch/validation/proof/archive boundaries.
- Kernel must not duplicate full CANON/SSOT/NORM or accumulate historical Current HEAD blocks, but it must never be demoted to navigation-only.
- `routes.yaml` is primary runtime route truth; hardcoded routes are fallback only.
- `file_map.summary.json` is the startup map; full `file_map.json` and full Healer history are route-only.
- CANON, SSOT, NORM, AI Archive Laws and active AI docs remain independent critical regression-control layers.
- The sandbox is ephemeral; each new session starts from the latest canonical archive.
- CI is allowed with bounded timeout; the canonical GitHub Actions `canon` job timeout is 10 minutes and may not exceed the user-approved 5–10 minute range without direct instruction. PNG screenshots are local-only evidence, not required GitHub CI artifacts.
- Real application screenshot proof must use the running app and `page.goto()`; `page.set_content` cannot be accepted as application proof.
- Duplicate active truth sources are forbidden. Compatibility files must point to the canonical source.


## LOCK: AI operational brain and bounded history reading

- `docs/AI/` is the AI operational working brain, not a historical archive.
- `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` contains only unresolved or immediately actionable items.
- Every user-approved decision is transferred to the appropriate CANON / SSOT / NORM and removed from active temporary memory.
- Reports, audits and cycles remain stored in the development archive, but without an explicit request ordinary reading is limited to the latest two relevant entries per layer.
- Older history is route-only: explicit user request, forensic regression, Healer pointer or cycle reconciliation.

## LOCK: AI Archive Laws

- `docs/AI/AI_ARCHIVE_LAWS.md` is an active archive-work lock.
- Tests, CI, logs and reports must not be weakened to hide a problem.
- Active tests must not be archived, skipped, xfailed or excluded without
  replacement mapping and direct user permission where required.
- If an error cannot be safely repaired, the assistant must ask mandatory
  iteration questions in Russian.

# Architectural Locks

Статус: NORM (нормативный документ разработки). Якорь SSOT:
docs/SSOT/SSOT_INDEX.md

Назначение:
- Этот документ фиксирует архитектурные запреты и ограничения
  разработки.
- Продуктовые нормы (термины, экономика, банк, выводы, TON) живут в
docs/SSOT/EFHC_CANON.md и docs/SSOT/PROJECT_GLOSSARY.md.

Приоритет и конфликты:
- Источник приоритета документов: docs/SSOT/SSOT_INDEX.md.
- Если DERIVED-документ (architecture/specification и т.п.) конфликтует
  с
NORM, он подлежит обновлению.
- Если код конфликтует с NORM, это дефект: требуется правка кода или
  NORM
через осмысленное изменение и тесты.

Инструменты контроля:
- ops/canon_rules.yaml и ops/canon_guard.py реализуют проверки канона,
но не заменяют SSOT_INDEX и NORM-документы.

---

## LOCK: runtime logs location

Правило:
- Текущие runtime/evidence outputs пишутся только в `reports/current/` или `reports/generated/`; immutable отчёты — в `reports/numbered/`.
- Запрещено создавать log/session/strict файлы и каталоги
  вне канонических `reports/current/`, `reports/generated/` и `reports/numbered/`.


## LOCK: provider-independent global identity

Active source: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

- главный system/domain owner — `GlobalId` / `global_id`;
- физическая owner-колонка — `users.global_id`;
- `users.user_id` отсутствует; `User.global_id` обращается к физической колонке напрямую;
- локальный `id` не является identity аккаунта;
- `TelegramId` / `tg_id` — только provider identifier;
- `global_id = tg_id` и косвенные преобразования запрещены;
- wallet, email и provider subjects не становятся `global_id`;
- внешний `global_id` — десять ASCII-цифр, ноль запрещён;
- historical backfill/read-switch stages завершены; новые owner-переходы допускаются только с PostgreSQL reconciliation;
- legacy aliases не могут становиться новым контрактом и удаляются по матрице cleanup.

Admin roles целево принадлежат `global_id + user_roles`. Telegram
whitelist остаётся только временным bootstrap/audit source.

## LOCK: UI navbar fixed (6 tabs, order)

Запрещено менять состав и порядок нижней навигации.

Канон (ровно 6 вкладок, фиксированный порядок): 1) Energy 2) Panels 3)
Exchange 4) Tasks 5) Referrals 6) Ranks

Любые изменения допускаются только через обновление NORM/SSOT и guard.

---

## LOCK: language split by surface

Запрещено смешивать языковой канон player-facing и admin/operator
слоёв.

Канон:
- Player-facing surfaces — English-first.
- Admin/operator surfaces — Russian-first.
- Trust-sensitive player comments/outcomes — quality-first; fallback =
  English.
- Levels / ranks names — всегда EN.
- Плохой или сырой перевод не может подменять English fallback для
  игрока.

---

## LOCK: Profile entrypoint + SSOT settings list

Канон входа: Profile открывается по нажатию на аватар в левом
верхнем углу.

SSOT список настроек (утверждён): 1) Telegram display name (RO) 2)
Username (RO) 3) VIP badge (RO) 4) Avatar (Telegram default + custom +
reset) 5) Descriptions language (13 langs, EN first) 6) UI sounds
(on/off) 7) Sound volume 8) Sound pack 9) Haptics (on/off) 10) Hide
balances 11) Show decimal detail (still 8 decimals) 12) Reduce motion
13) Confirm before purchase 14) Confirm before withdraw request 15)
Confirm before convert kWh→EFHC 16) Confirm before watch ad 17) In-app
toasts 18) Important alerts only 19) FAQ 20) Support chat 21) Terms 22)
Privacy 23) Reset settings

---



## LOCK: GlobalHeader status badges + profile entrypoint

Канон:
- В `GlobalHeader` должны существовать badge `VIP` и `Activ`, если
  соответствующие статусы есть у пользователя.
- User-facing вход обозначается как `Профиль / Профіль / Profile`.
- Архивные панели не должны просачиваться в Energy summary.
- На странице Energy допускаются только активные панели и их текущая
  суммарная генерация.

## LOCK: Admin entry via Profile

Current compatibility:
- Admin Panel remains inside Profile.
- The Telegram allowlist continues to work during migration.
- Target authorization is `global_id + user_roles`.
- Provider identity is context, not the final RBAC owner.



## Economy SSOT Locks: Generation & Exchange

SSOT: механика обмена и вывода — см.
docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

SSOT: механика панелей — см. docs/SSOT/PANELS_SSOT.md


- **Lock: total_generated_kwh is append-only** (never decreases).
- **Lock: exchanged_kwh_total is append-only** (never decreases).
- **Mirror formula (source of truth):**
  `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`
- **EXCHANGE_ALL** MUST:
  - increase `exchanged_kwh_total` by `available_kwh_before`
  - credit EFHC **MAIN** 1:1
  - never mutate `total_generated_kwh`
  - `available_kwh` существует только как вычисляемое зеркало
  по формуле mirror result.


## Общие логи и отчёты

Immutable отчёты изменений ведутся в `reports/numbered/`.
`reports/manifests/REPORTS_NUMBERING_MANIFEST.csv` — каноничный нумерованный реестр
`append-only`: каждая новая запись добавляется строго по порядку
и получает следующий номер без пропусков.


## Overview docs sync (MUST)

- Обзорные документы обязаны совпадать с `docs/SSOT/ssot_pack/*`.
- `docs/NORM/TESTS_CATALOG.md` описывает реальный active `tests/**`.
- Для быстрого аудита использовать `docs/OVERVIEW_SSOT_SYNC.md` и
  `docs/NORM/DATABASE_MIGRATION_INVARIANTS_NORM.md`.


## LOCK: Conditional incident and report synchronization

- Every changed pass receives one concise change report.
- Healer and the errors registry are updated only for a confirmed incident/root cause with an independent preventive guard.
- A CSS/runtime/document edit does not automatically create a new Healer case or product norm.
- Reports record work and evidence; they cannot create CANON/SSOT/NORM truth.

## LOCK: New-chat continuation source

A new chat starts from the latest canonical ZIP, then `START_HERE.md` and `KERNEL.md`. Obsolete continuation prompts are externalized in the artifacts history ZIP and are not active startup instructions.

## Historical trace lock

как audit/report/migration history. Они не могут возвращаться в
active architecture, runtime imports, API routes или SSOT tables.


## LOCK: document phase package exclusions

В обычные пакеты документной ревизии не входят:
- внешний `ARTIFACTS_HISTORY` ZIP;
- historical log/evidence, уже вынесенные из active HEAD;
- временные generated outputs вне `reports/current/` и `reports/generated/`.
Удалённые `docs/history/` и `АРТЕФАКТЫ/` не создаются повторно.

## LOCK: inventory answer format

Для файлов документной ревизии описание даётся связными абзацами, а
в конце обязательно формулируется отдельное предложение по файлу.


## v168_91 / work pass lock: Tasks execution log boundary

The `/tasks` player-facing screen is an earning module, not a task
history, execution-log, backend-log or idempotency/debug screen.

Allowed:
- backend tables/services may keep `task_complete_lock`,
  `task_bonus_log`, `task_submissions` and transfer logs for
  double-claim protection, auditability and admin operations;
- admin/operator contours may inspect task traces through admin routes
  such as `/admin/tasks/...` and `/admin/logs/transfers?reason=task_bonus`.

Forbidden:
- rendering task execution history on `/tasks`;
- rendering backend execution logs or idempotency/protection internals on
  the public Tasks page;
- adding public `/tasks/history` or `/tasks/logs` routes without a later
  explicit canon change.

## HUB two-action public-copy lock — current

- `/hub` renders exactly two visible actions: `Пополнение` and `EFHC VIP NFT`.
- The `Пополнение` action contains no explanatory commerce copy before external navigation.
- Purchase, buy, shop, package, checkout, TON, GRAM, USDT and price are forbidden in the active HUB copy.
- The separate `EFHC VIP NFT` action and official GetGems link are mandatory and may not be removed without direct user approval.
- Commerce details are allowed only after signed handoff on `/browser-shop`.
- GlobalHeader `+` remains Direct Deposit and accepts EFHC jetton only.
- If a current guard conflicts with an interpretation, the guarded function must not be deleted silently; stop and request a user decision unless the user has already supplied an explicit replacement canon.
