# OWNER LOCK — v174.47 / цикл 1793 CI qualification repair

- Direct owner scope: продолжить цикл `1793` по exact HEAD/active SSOT/CANON и исправить все подтверждённые ошибки GitHub CI `87288059313`.
- Единственный RED является qualification-only: stale historical-count baseline в Russian engineering language guard; runtime ради него не менять.
- `CONTINUE_IN_NEW_CHAT.md` хранит immutable historical snapshots: их не переводить и не переписывать ради GREEN; baseline допускает ровно текущие `53` historical violations и fail-closed запрещает новые.
- Existing 52-table CRUD operational; frozen `0001` сохраняется; `0002+` не создавать. FAQ и approved FRONTEND_v146 не менять.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не выполнять. `v174.47` требует fresh exact-head GitHub CI.
- Handoff только `EFHC_Bot_v174_47.zip`, без descriptive suffixes/sidecars.

# OWNER LOCK — v174.46 / цикл 1793 CI qualification repair

- Direct owner scope: продолжить цикл `1793` по exact HEAD/active SSOT/CANON и исправить все подтверждённые ошибки GitHub CI `87285361835`.
- Canonical financial SSOT не откатывать: `SpendBreakdown` и `split_bonus_then_main` принадлежат `app.standards.finance_rules`; stale module facade не восстанавливать ради тестов.
- Shop SQLAlchemy-safe `CAST(:extra AS jsonb)` сохраняется; старый `:extra::jsonb` не возвращать.
- Tests проверяют invariant, а не форматирование import или исторический небезопасный SQL literal.
- Existing 52-table CRUD operational; frozen `0001` сохраняется; `0002+` не создавать. FAQ и approved FRONTEND_v146 не менять.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не выполнять. `v174.46` требует fresh exact-head GitHub CI.
- Handoff только `EFHC_Bot_v174_46.zip`, без descriptive suffixes/sidecars.

# OWNER LOCK — v174.45 / цикл 1793 CI qualification repair

- Direct owner scope: продолжить цикл `1793` по exact HEAD/active SSOT/CANON и исправить все подтверждённые ошибки GitHub CI `87278222904`.
- Не откатывать deep backend remediation `v174.44` ради stale tests: canonical `db_session()`, единый security middleware installer, async export cleanup, FSM/lifecycle и financial SSOT остаются authority.
- Реальные source defects этого CI исправляются минимально: missing `get_session_factory` и SQLAlchemy/asyncpg JSONB bind-cast.
- Stale tests адаптируются к current contract, но security/financial/transaction guards не ослабляются.
- Existing 52-table CRUD operational; frozen `0001` сохраняется; `0002+` не создавать. FAQ и approved FRONTEND_v146 не менять.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не выполнять. `v174.45` требует fresh exact-head GitHub CI.
- Handoff только `EFHC_Bot_v174_45.zip`, без descriptive suffixes/sidecars.

# OWNER LOCK — v174.44 / цикл 1792 deep backend remediation

- Прямое решение владельца: исправить все подтверждённые ошибки Deep Backend Remediation Specification для exact `v174.43` и дополнительно проверить аудит.
- Root transaction принадлежит только application use-case owner; composable service/CRUD не имеет права неожиданно `commit/rollback` чужую transaction. Expected conflicts используют savepoint.
- `asyncio.CancelledError` — lifecycle signal: scheduler/worker не превращает cancellation в normal result; owner выполняет rollback и re-raise.
- DB contract: FastAPI `Depends(get_db)` является adapter поверх canonical `db_session()`; runtime/scheduler использует только `async with db_session()`; engine закрывается canonical lifespan.
- FSM current single-process atomicity обеспечивается per-key lock и copy isolation; distributed CAS является обязательным отдельным условием перед multi-replica scale-out, но не вводится скрыто без schema/infra scope.
- Финансовый spend rule имеет одну runtime-реализацию в `app.standards.finance_rules`; FAQ не является runtime financial SSOT.
- Не ослаблять watcher P0 `trusted time → 180-day barrier → replay/idempotency → mutation → ledger` и Telegram atomic dedupe/root transaction.
- Existing 52-table CRUD operational; frozen `0001` сохраняется; `0002+` не создавать. FAQ/FRONTEND_v146 не менять данным backend repair.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не выполнять. `v174.44` требует fresh exact-head GitHub CI.
- Handoff только `EFHC_Bot_v174_44.zip`, без descriptive suffixes/sidecars.

# OWNER LOCK — v174.43 / цикл 1792 CI qualification repair

- Direct owner scope: продолжить cycle `1792` и исправить все подтверждённые ошибки supplied CI `87220054352`.
- Exact input authority: `v174.42` SHA-256 `2ef41df8ec14235d584ccc2a2994cca780c58d0e993de2aacdba3957c56384c8` / checkout `fe6d0d4f32a75d8419f0d165afffc18fef76cc02`.
- Не ослаблять repaired contracts v174.42: Telegram root transaction/dedupe fail-closed, watcher P0 `trusted time -> 180-day barrier -> replay -> mutation -> ledger`, configured TonConnect domain, idempotency bounds, scheduler positive operational values.
- Qualification tests не имеют права требовать обход P0 trusted-time barrier; stale harness адаптируется к current runtime.
- FAQ/locale/PWA остаются standalone checked-in release assets; FRONTEND_v146 visual/UX/text не менять.
- Existing 52-table CRUD operational; frozen `0001` сохраняется; `0002+` не создавать.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не выполнять. `v174.43` требует fresh exact-head GitHub CI.
- Handoff только `EFHC_Bot_v174_43.zip`, без descriptive suffixes/sidecars.

# OWNER LOCK — v174.42 / цикл 1791 corrective re-audit repair

- Прямое owner scope: исправить **все подтверждённые defects** из `EFHC_v174_41_REAUDIT_TECHNICAL_SPEC.md` и повторно проверить аудит.
- Telegram webhook invariant: source authentication → JSON validation → uncommitted dedupe INSERT → business processing на той же DB session → один root commit. Любая DB dedupe failure, exception или cancellation завершает contour fail-closed; manual compensating DELETE запрещён.
- `/start` onboarding внутри webhook не владеет root transaction; unexpected exceptions не маскируются normal success.
- Broad internal exceptions не возвращаются в HTTP 5xx detail. TonConnect production proof domain берётся из configured canonical domain; request Host не является authority. `TrustedHostMiddleware` применяется при configured allowlist.
- Raw idempotency key проверяется до hash: максимум 128 символов, control chars запрещены. Operational scheduler zero-values запрещены, кроме `JITTER_SEC=0`.
- FAQ runtime/SSOT content и frozen migration `0001` **не изменять** данным backend/security repair; `0002+` не создавать. Existing 52-table CRUD остаётся рабочим; schema-change governance lock сохраняется.
- FRONTEND_v146 visual/UX/text не откатывать; PWA listener cleanup является non-visual lifecycle repair.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не выполнять. `v174.42` требует fresh exact-head GitHub CI.
- Handoff только `EFHC_Bot_v174_42.zip`, без descriptive suffixes/sidecars.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

# OWNER LOCK — v174.41 / цикл 1791 exact-head GREEN anchor + full audit repair

- Exact-head `v174.40` is GREEN by GitHub CI `87088984879`: SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`, all recorded gates exit `0`, pytest `1670 passed / 22 skipped / 1 warning`, frontend/PostgreSQL/Alembic PASS. GREEN does not inherit to `v174.41`.
- Financial P0 remains hard: trusted time -> 180-day barrier -> replay/idempotency -> mutation -> ledger. Watcher audit repair enforces this order before final/replay decision and settlement.
- Schema-change governance lock remains active: existing 52 tables/CRUD are operational; frozen `0001` remains the only release migration; `0002+` or DDL requires direct owner scope.
- Production recovery is fail-closed: encrypted artifact ciphertext SHA-256 evidence is mandatory before decrypt/restore; DR docs must match current encrypted recovery contract.
- Production release/update canonical filename is `EFHC_Bot_vNNN_NN.zip`; descriptive `_RELEASE`/`fixed`/`cycle` suffixes are forbidden in active archive contract.
- FAQ/locale/PWA are standalone checked-in release assets; packaging verifies application bytes and cannot regenerate them. Approved FRONTEND_v146 remains visual/UX/text authority.
- Assistant does not run local project tests/guards/lint/type/build/Alembic/PostgreSQL/CI. `v174.41` requires fresh exact-head GitHub CI.

> **Historical boundary:** lower owner-lock snapshots are historical.

# OWNER LOCK — v174.40 / цикл 1790 CI qualification hygiene

- Exact CI `87074955772` tested `v174.39` SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872` / checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`; all recorded gates GREEN except pytest `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Confirmed repair: only two English docstrings in development-only FAQ duplicate-control verifier; runtime/frontend/backend/schema behavior is unchanged.
- FAQ remains standalone checked-in release authority; FAQ SSOT is duplicate control only and MUST NOT write runtime. Release packaging remains application-byte read-only.
- **Schema-lock meaning:** this is a governance lock on unapproved DDL/schema/migration changes, not a runtime PostgreSQL table lock and not a CRUD restriction. Existing tables remain operational.
- Frozen `0001_initial_release_schema.py` remains the only release migration; `0002+` or schema expansion requires direct owner scope. A direct owner decision may supersede this freeze for an explicitly approved schema change.
- Assistant does not run local project tests/guards/lint/type/build/Alembic/CI; next qualification is exact-head GitHub CI.
- Canonical handoff filename: `EFHC_Bot_v174_40.zip`; no descriptive archive suffixes or owner-facing sidecars.

> **Historical boundary:** lower owner-lock snapshots are historical.

# OWNER LOCK — v174.39 / цикл 1790 release-asset independence

- Exact CI `87062684580` tested `v174.38` SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75` / checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`; all non-pytest gates GREEN, pytest only `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Owner decision: production FAQ authority = checked-in frontend runtime assets. FAQ SSOT is duplicate-control evidence only and MUST NOT generate/overwrite runtime FAQ.
- Release packaging MUST be application-byte read-only: FAQ/locale/PWA assets are prepared before packaging and fail-closed verified by hashes. FAQ/PWA generators are development-only and forbidden in release packaging.
- Approved FRONTEND_v146 remains visual/UX/text authority. Stale qualification tests do not restore superseded behavior.
- Database migration lock remains active: frozen `0001_initial_release_schema.py`; `0002+` or schema expansion requires a separate direct owner scope.
- Assistant does not run local project tests/build/Alembic/CI; next qualification is exact-head GitHub CI.
- Canonical handoff filename: `EFHC_Bot_v174_39.zip`; no descriptive archive suffixes or owner-facing sidecars.

> **Historical boundary:** lower owner-lock snapshots are historical.

# OWNER LOCK — v174.38 / цикл 1789 continuation

- Exact CI `86992003426` tested `v174.37` SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d` / checkout `7384e8284dbde416086a13bd23de7136be585681`; only pytest qualification had 3 failures, all repaired without frontend/runtime rollback.
- Approved FRONTEND_v146 remains owner authority over visual/UX/text behavior; stale tests cannot restore superseded UI.
- Database migration lock remains active: only frozen `0001_initial_release_schema.py`; `0002+` or schema expansion requires direct owner scope. Current CI PostgreSQL/Alembic GREEN.
- FAQ runtime/prebuild remains detached from Python/docs/SSOT; release packaging still SSOT-generating under current lock. Standalone verify-only packaging is recommendation only until owner approval.
- Assistant does not run local project tests/build/Alembic/CI; next qualification is exact-head GitHub CI.
- Canonical handoff filename: `EFHC_Bot_v174_38.zip`; no descriptive suffixes or owner-facing sidecars.

> **Historical boundary:** lower owner-lock snapshots are historical.

## OWNER LOCK v174.37 / cycle 1789 — stale guard qualification

- Approved FRONTEND_v146 remains authority over stale frontend literal tests.
- Cycle 1789 changes only qualification guards and current metadata; controlled frontend runtime bytes remain unchanged.
- FAQ runtime/prebuild has no Python/docs/SSOT dependency. Release packaging remains separately SSOT-generated under current approved architecture; do not conflate the two boundaries.
- Handoff: only `EFHC_Bot_v174_37.zip`; next exact-head CI required.

## OWNER LOCK v174.36 / cycle 1788 — CI/test authority

- Approved FRONTEND_v146 integrated source имеет owner priority над stale frontend implementation-detail tests.
- Тесты служат для обнаружения и проверки изменений; корректно утверждённое изменение не откатывается ради старого expectation.
- Stale test разрешено обновить или удалить; test реального backend/security/financial invariant сохраняется и переносится на current authority.
- Current source authority: `INTEGRATED_FRONTEND_SOURCE_v174.36_FRONTEND_v146` / `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`.
- Handoff archive: только `EFHC_Bot_v174_36.zip`, без descriptive suffix.

## OWNER LOCK v174.35 / cycle 1788 — FRONTEND_v146 integrated source

- Direct owner order открыл цикл `1788`: supplied FRONTEND_v146 runtime-only patch является новым visual/UX/text authority для exact `v174.35`.
- Patch интегрируется только в normal `frontend/` source; после установки внешний patch удаляется и не может быть runtime overlay.
- Current backend/CANON остаётся authority для API, security, identity, economy и financial semantics; frontend patch не разрешает менять frozen `0001` или финансовые invariants.
- Source authority lock: `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146` / `3a87f68020b1dbb38087a2a384c28081cca45b01740c03c0cc9f8d4a85d5cea5`.
- Local full tests/build/CI не выполняются; следующий qualification — exact-head GitHub CI по новому архиву.
- Новые CI-log repairs выполняются только по фактически предоставленным логам; в текущем handoff CI-log artifact отсутствует.

## OWNER LOCK v174.34 — полный historical Q/A recovery

- Единый active owner Q/A authority: `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; реестр append-only.
- При owner-команде восстановить вопросы/ответы либо при обнаружении coverage gap оператор обязан пройти все доступные numbered transcripts `docs/chats/<N>.md`, а не только текущий чат.
- В реестр допускаются только пары, подтверждённые transcript evidence. Вопрос без доказанного ответа получает `UNRESOLVED`; generic ответ без восстанавливаемого вопроса получает `CONTEXT_INCOMPLETE`; inference запрещён.
- Recovery audit обязан хранить source chat, line/context marker, SHA-256 источника и disposition.
- Более позднее direct owner decision / active SSOT / CANON имеет приоритет над recovered history; историческая запись не переписывается, а supersede фиксируется новой записью.

## OWNER LOCK v174.21 — verification integrity / final artifact read-back

- Перед каждым owner-facing ответом все существенные утверждения повторно проверяются по exact final source.
- Перед handoff любого файла обязателен post-write read-back exact final path, затем structure/marker verification, SHA-256 и size.
- Memory/intention/intermediate state не являются доказательством. Неперепроверенный факт маркируется `UNVERIFIED`.
- CI claims требуют exact run/log + Gate Summary; ZIP claims требуют финальной integrity/content/mode qualification.
- Инцидент двукратной передачи старого `ci_github.yml` как якобы проверенного нового файла зафиксирован в `docs/chats/CURRENT_CHAT_VERIFICATION_RULES.md` и AI Archive Laws amendment v174.21.
- Повторение считается verification-integrity regression.

## Цикл 1756 — current frontend/source lock

- Offline Demo/Simulation запрещён в main application по прямому решению владельца.
- Ads current session/provider contour сохраняется как до frontend patch.
- Frontend visual/text authority — approved integrated source hashes; active patch artifact после merge отсутствует.
- Любое удаление public/compatibility/runtime функции по-прежнему требует понятного объяснения и явного owner approval.

## Cycle 1755 lock — v173.93 owner-approved FRONTEND_v113 source integration

- Frontend visual/text/language authority после принятия живёт только в normal source; внешний patch удаляется из рабочего HEAD и не является active authority/runtime overlay.
- Текущий backend/security/economy `v173.92` имеет приоритет в function-union. Нельзя откатывать Ads `/ads/session*`, Browser Shop handoff security, health security или financial/global_id CANON ради более старого frontend implementation.
- Current Ads runtime locale keys, реально используемые сохранённым Tasks flow, обязаны оставаться доступными во всех 13 locales даже если supplied visual bundle внутренне их опускает.
- Direct Deposit response metadata canonical: `memo_binding=global_id`; provider-neutral memo `EFHC:GID:<global_id>`.
- HTTP/DB floor остаётся `156/162/168`, hidden `8`, mounted `170`, ORM `56`, Alembic only `0001`. Новые tables/columns/FK/migrations требуют отдельного owner explanation/approval.
- Удаление runtime/public compatibility surface требует понятного объяснения и явного owner approval. Два retired Energy Dashboard visual component-файла разрешены только как часть прямо одобренного supplied visual patch.
- Offline Demo production-domain enablement через query остаётся отдельным owner decision; наличие code path не является автоматическим production approval.
- Candidate `v173.93` не квалифицирован до следующего exact-head GitHub CI.

## Cycle 1745 lock — exact-head CI continuation после Audit 3/10

- `v173.73` квалифицирован supplied CI `85671783650` по checkout и точному archive size `12388486` bytes.
- Stale tests/guards не могут вернуть committing Shop money boundary, writable legacy sale-packages или обязательный legacy `tg_id` read-through.
- Canonical Shop EFHC boundary: caller-owned nocommit + order + один root commit. Canonical sale-package mutation status: `409 SALE_PACKAGES_NOT_RELEASE_SSOT`. Business owner: `global_id`.
- Frontend PATCH_002 visual/text остаётся неизменным; generated Admin seam для существующего rollback route является разрешённой невизуальной интеграцией.
- Protected floor: `355/66/81`, OpenAPI `156/162`, ORM `55`, schemas `168`, pages `39`.
- Локальные tests/CI/guards не запускать; новый candidate требует exact-head GitHub CI.

## Текущая рабочая блокировка — кандидат v173.73 / цикл 1744 — Audit 3/10: Shop/PaymentIntent/Bank financial consistency

- Входной HEAD: `EFHC_Bot_v173_72.zip`, SHA-256 `0af948145f1f3f1745b09bbab5024c28a3bee3dd341f8beded64dba1150ecb9c`, 4573 ZIP entries; archive integrity clean, все entries `ZIP_DEFLATED`.
- Scope: шесть findings Audit 3/10 пользователя, непосредственно связанный Bank rollback surface и следующий подтверждённый response defect внутри `/shop/order-external` execution path. Все пользовательские findings подтверждены по exact source, DB boundaries и active SSOT/CANON.
- Shop EFHC purchase переведён на caller-owned `spend_user_to_bank_bonus_then__main__nocommit()` и один root commit вместе с `shop_orders`; ошибка любой части откатывает money/order единым rollback.
- `shop_orders` получает pre-release canonical `UNIQUE(global_id, idempotency_key)` в ORM и единственном `0001`; read-through проверяет immutable owner-scoped fingerprint, а EFHC purchase дополнительно сверяет derived ledger keys/payload.
- `ShopPurchaseByEFHCOut` теперь строится из фактического committed order/ledger result; внешний `ShopOrderExternalIn.quantity` сохраняется compatibility field, но канонически допускает только `1`.
- PaymentIntent creation idempotency сравнивает полный immutable fingerprint; mismatch → `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact replay формируется только из persisted DB-row и не продлевает сохранённый expiry.
- `/admin/sale-packages` GET сохранён как compatibility/read surface; mutating create/update/toggle fail-closed отвечают `409 SALE_PACKAGES_NOT_RELEASE_SSOT`, пока release sale authority остаётся `efhc_core.shop_items`.
- Existing Admin Bank rollback выведен в API только после hardening: source `transfer_log_id` блокируется `FOR UPDATE`, допускается только исходная user-side Admin manual ledger operation, amount/direction/`balance_type` выводятся из source row, а deterministic compensation identity `admin_bank_rollback:<transfer_log_id>` не допускает второй reversal с иным HTTP key.
- `/shop/order-external` больше не пытается делать item-assignment в `ShopOrderExternalOut` после commit; финальный response строится новым `ShopOrderExternalOut(order=..., pay=...)`, исключая подтверждённый post-commit Pydantic `TypeError` path.
- Protected floor после добавления canonical rollback API/facade symbol: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted HTTP operations **170**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02276`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.72 / цикл 1743 — exact-head CI burn-down v173.71 после аудита 2/10

- Входной HEAD: `EFHC_Bot_v173_71.zip`, SHA-256 `e658dab6a2c05cbf9f4eb15c9b67b2153b8b05077f72c65223ba9b446ca82ab6`, размер `12456075` bytes.
- Exact-head GitHub CI `85571802073`, checkout `d3f3eb541a09954a2bc16266d45abf2c417931f0`; CI `efhc.zip` имеет тот же размер `12456075` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates по предоставленным логам: Alembic, Bandit, compileall, Flake8 full, npm ci, frontend build и PostgreSQL preflight.
- Ошибочные gates: Flake8 critical — `4` F821; Ruff — `5` diagnostics (`4` F821 + `1` I001); Mypy — `4` name-defined errors; pytest — `1 failed / 1548 passed / 22 skipped / 1 warning`.
- Подтверждённые причины исправлены минимально: восстановлен импорт `require_idempotency_key_header_only` для трёх Admin money routes; из emergency deposit rejection-audit удалён stale `request_ik`, потому что recovery authority остаётся immutable `tx_hash`; исправлен import-order в CI-указанном Admin RBAC guard; stale Bank runtime fixture использует `NULL` для отсутствующего legacy `users.ton_wallet` вместо конфликтующего `''` под `UNIQUE(ton_wallet)`.
- Семантика аудита 2/10 не ослаблена: write RBAC, strict financial Idempotency-Key, materialized-only emergency recovery, global `tx_hash` settlement claim, atomic money + required Admin audit и canonical `users.global_id` actor сохранены.
- Protected floor без изменений: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report (неизменяемый отчёт): `reports_02275`.
- Audit 3/10 не начат: текущий continuation сначала требует exact-head GitHub CI нового `v173.72`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.70 / цикл 1743 — security audit 2/10

- Входной HEAD: `EFHC_Bot_v173_69.zip`, SHA-256 `d8bd8ffe570e4d7af47cce21a243e54aa7c6ff8dd2763d02ba2ee8ce899ce87f`, размер `12429259` bytes.
- Scope: семь подтверждённых findings аудита 2/10; произвольный cleanup/refactor не выполняется.
- Admin authorization разделён: `require_admin` = authentication/read gate; любой state-changing `POST/PUT/PATCH/DELETE` требует `require_admin_write` (минимум Moderator), поэтому `Analyst/auditor → 403`.
- Emergency EFHC deposit принимает только `tx_hash`; amount/MEMO/address/raw facts берутся исключительно из materialized `ton_inbox_logs` под `FOR UPDATE`; отсутствие watcher-записи fail-closed. Money + обязательный actor audit фиксируются одним commit.
- Admin bank money operations используют caller-owned nocommit boundaries: ledger + обязательный `admin_action_log` + notification outbox атомарны; Telegram delivery выполняется после commit.
- Повторный `Idempotency-Key` с другим owner/operation/direction/balance/amount возвращает `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact payload остаётся read-through.
- Admin NFT principal после центрального gate не проходит whitelist-only повторную авторизацию.
- Panels service синхронизирован с `archived_at`; facade использует `toggle_panel`; HTTP activate/deactivate идут через единый service-layer. Rollback balance type выводится только из исходной ledger-строки.
- Protected floor: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02273`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.69 / цикл 1742 — exact-head CI burn-down

- Входной HEAD: `EFHC_Bot_v173_68.zip`, SHA-256 `89f6601c1eb21958cf49e4013b006675c02e108bd675abf315211d0234cdb0e7`, размер `12423369` bytes.
- Exact-head GitHub CI `85494080104`, checkout `c26d756731522adbf009d792f1885e79313e2835`; CI `efhc.zip` имеет тот же размер `12423369` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build и PostgreSQL preflight.
- Failing gates: Ruff — `1` I001 import-order; pytest — `7 failed / 1533 passed / 22 skipped / 1 warning`.
- Подтверждённые исправления continuation 1742: Ruff import-order; traceability exception для immutable audit evidence 1741; timeless комментарий `0001`; financial-identity guard приведён к canonical `owner_db`; Russian Engineering NORM в `ton_memo`; lifecycle tests больше не требуют несуществующий `wallets_service.STATUS_PENDING_MANUAL`; watcher accounting SSOT/tests синхронизированы с fail-closed `CONFIRMED + different tx_hash` semantics.
- Финансовые исправления аудита 1/10 не откатываются: legacy BUY/SKU MEMO остаётся `pending_manual`, PaymentIntent требует live `PENDING`, global `tx_hash` settlement lock остаётся единственным settlement claim.
- Protected floor не изменяется: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.68 / цикл 1742

- Входной HEAD: `EFHC_Bot_v173_67.zip`, SHA-256 `d594424e7ff88eb4b3366019de7d6efd62064debd91f411784dfe69fa456c4aa`, размер `12398809` bytes.
- Scope цикла 1742 ограничен тремя подтверждёнными дефектами финансового аудита 1/10 по входящим платежам; произвольный cleanup/refactor не выполняется.
- CRITICAL legacy `BUY:EFHC` / `SKU:EFHC` MEMO больше не является settlement/reward authority: `qty` из пользовательского MEMO не может определять размер начисления. Без canonical PaymentIntent подтверждения такой входящий платёж переводится только в `pending_manual`; `credit_user_from_bank` и `PAID_AUTO` из legacy SKU-ветки запрещены.
- PaymentIntent после `FOR UPDATE` принимает новый settlement только при `status=PENDING` и `expires_at > now`; уже `CONFIRMED` допускается только как идемпотентный read-through того же самого `tx_hash`. Другой `tx_hash`, expired/canceled/unknown status fail-closed.
- `efhc_core.tx_hash_locks` расширен до единственного глобального immutable on-chain settlement claim для PaymentIntent, watcher direct/nomemo и Admin recovery. `intent_id` nullable только потому, что direct/admin settlement не обязан иметь PaymentIntent; unique `tx_hash` остаётся глобальным.
- Business idempotency keys сохраняются как второй слой, но не могут позволить повторно начислить одну blockchain-транзакцию через другой processing namespace.
- Active financial CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`, `docs/SSOT/PAYMENT_INTENT_SSOT.md`, `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md`, `docs/SSOT/TON_MEMO_SPEC.md`.
- Registered protected floor после добавления общего settlement service: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; HTTP surface не изменяется. ORM tables остаются **55**; single Alembic head остаётся `0001_initial_release_schema.py`.
- Добавлены/актуализированы CI-only regression guards для трёх findings; локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Последний green CI `85400569189` относится к `v173.66`, не к этому кандидату.

# ACTIVE CYCLE 1741 — GREEN CI + FULL FUNCTION/ROUTE/TABLE AUDIT LOCK — кандидат v173.67

1. Exact-head CI `85400569189` на входном `v173.66` имеет `exit=0` по всем canonical gates; это green evidence только для входного HEAD.
2. Аудит не разрешает cleanup: `no caller != delete proof`; полный inventory private helpers не является whitelist для удаления.
3. Public HTTP surface остаётся `155 paths / 161 OpenAPI operations`; дополнительно **8 mounted hidden operations** обязаны учитываться отдельно в `SSOT_INTERNAL_ROUTES.csv`. Hidden route нельзя удалить из-за отсутствия в OpenAPI.
4. Четыре `/hub/browser-shop-*` hidden routes являются compatibility aliases к canonical `/shopfront/*` и сохраняются до прямого owner decision либо production-level external-use delete-proof. Отсутствие caller'ов внутри репозитория само по себе не разрешает удаление публично достижимого compatibility URL.
5. `/meta/metrics`, `/meta/deployment`, `/cron/tick`, `/tg/webhook` — internal/operator boundaries; их отсутствие в OpenAPI является намеренным, а не delete-proof.
6. ORM business inventory: **55 tables = 48 efhc_core + 7 efhc_admin**. Single Alembic head остаётся `0001`; создание `0002+` запрещено без отдельного решения владельца.
7. Protected function floor: `339 symbols / 62 modules / 77 files`; frontend floor: `39 pages`; PATCH_002 visual/text authority и ADS mediation CANON не изменяются.
8. Новый кандидат после audit/docs/guard patch требует отдельного exact-head GitHub CI; локальная application qualification запрещена.

## Текущая рабочая блокировка — кандидат v173.66 / цикл 1740

- Входной HEAD: `EFHC_Bot_v173_65.zip`, SHA-256 `33a9e31d5c098091889e8bd782c79b026ef4e28fd91d1bd2735e0833e5f3f4c5`, размер `12348905` bytes.
- GitHub CI пользователя `85386896242`, checkout `d01a440b86a8ac2f062f7b88cbf2e252b8fbb615`; CI `efhc.zip` имеет тот же размер `12348905` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied canonical gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `1 failed / 1533 passed / 22 skipped / 1 warning`. Единственный подтверждённый failure — Russian Engineering Language NORM: английское имя одной test-function в `tests/architecture/test_browser_shop_mvp_cut_lock.py`.
- Исправление 1740: изменено только имя этой test-function на русскоязычное; test semantics, production runtime/backend/frontend, ADS mediation, schema, routes, PATCH_002 visual/text CANON и business `global_id` semantics не изменялись.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# ACTIVE EXACT-HEAD CI REPAIR LOCK — v173.65 / цикл 1739

1. Evidence source цикла — GitHub CI `85380431378` на входном `v173.64`; CI archive size `12351381` bytes совпадает с локальным входным HEAD, SHA-256 payload в CI-логах отсутствует.
2. Единственный failing gate входного CI — pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`; остальные canonical gates `exit=0`.
3. Исправлять разрешено только четыре подтверждённых stale expectations: два PostgreSQL FK-count tests, exact-fragment identity disposition и Russian Engineering NORM.
4. Production runtime/backend/frontend, ADS mediation, single-head `0001`, PATCH_002 visual/text CANON и business `global_id` semantics не изменяются.
5. CI/guards не получают новых broad exemptions; provider wire aliases остаются только на уже зарегистрированных boundaries.
6. Локальные tests/guards/lint/type/build/Alembic/CI запрещены; следующий verifier — exact-head GitHub CI кандидата `v173.65`.
7. Function-preservation floor остаётся `339/62/77`, OpenAPI `155/161`, frontend pages `39`, schemas `168`.

# ACTIVE ADS / FRONTEND MERGE LOCK — v173.63 / циклы 1735–1737

1. `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` остаётся абсолютным visual + user-facing text CANON для затронутых frontend surfaces. ADS ТЗ не даёт права возвращать старый Bot UI.
2. Прямое owner-approved исключение ADS scope: разрешены новые элементы Admin ADS/Admin Tasks и runtime ADS-состояния существующей Tasks-страницы; остальные visual/text изменения требуют отдельного согласования владельца.
3. `AdManager` — единственная новая production mediation architecture. Tasks не содержит provider-specific SDK/verification logic; provider adapters не начисляют EFHCb.
4. Reward authority: `Task.bonus_efhc` → immutable session reward snapshot → existing `tasks_service` / canonical bonus path. Callback/provider amount никогда не определяет EFHCb.
5. ADS business owner — `global_id`. `tg_id` допустим только на Telegram/provider boundary, когда этого реально требует provider/Bot API.
6. `Admin DB override → ENV fallback`; secret credential хранится encrypted, frontend получает только public runtime config. Secret plaintext/log/OpenAPI example/analytics запрещены.
7. `builtin_timer` — DEV/CI/diagnostics only и не входит в production monetization fallback. Exhausted real-provider chain → `NO_FILL` без reward.
8. TADS/MyBid reward adapters остаются fail-closed `NOT_SUPPORTED`, пока нет точного официального publisher-cabinet SDK/callback contract. Запрещено придумывать verification contract ради «полноты».
9. Server session, UTC daily limit, provider event dedup, one reward/session, impossible-transition rejection и idempotent reward — обязательные security invariants.
10. Старые `/ads/slot`, `/ads/callback/{provider}`, `showTelegramAd()` и historical `efhc_core.ads` сохраняются как compatibility/historical surfaces; их существование не создаёт вторую production reward architecture.
11. Revenue Optimizer использует фактическую EFHC telemetry (requests/fills/completions/revenue/fallback), не hardcoded рейтинг рекламных сетей.
12. Любое удаление compatibility/provider surface требует отдельного delete-proof; `no caller != delete proof`.
13. Локальные tests/guards/lint/type/build/Alembic/CI не запускать без отдельного разрешения владельца. Новый `v173.63` требует exact-head GitHub CI пользователя.

---

## Cycle 1734 — FRONTEND PATCH AUTHORITY corrective merge lock — кандидат v173.60

- Утверждённый владельцем `PATCH_002` имеет абсолютный приоритет для visual/UX/user-facing text. Старый Bot frontend **не является visual donor**.
- GitHub CI/architecture tests не могут разрешить visual/text rollback. Guard, требующий старую presentation при конфликте с PATCH_002, является stale и мигрируется под patch.
- Функции обеих веток сохраняются: `frontend ∪ main/backend`. Отсутствие функции в patch UI не разрешает удалить её и не разрешает вернуть старый UI; до согласования она остаётся `OWNER_REVIEW` donor либо встраивается без visual/text change.
- Автоматически допустимы только route/API/data/global_id/security/typing/i18n-coverage/generated-metadata изменения без visual/text эффекта. Любое visual/text/layout/CSS/icon/visible-action изменение требует отдельного решения владельца.
- Fail-closed proof: `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; только `EXACT_PATCH`, зарегистрированный `NON_VISUAL_INTEGRATION`, `FUNCTION_UNION_NON_VISUAL` или `OWNER_APPROVED_CHANGE`.
- Историческая формулировка цикла 1733 о восстановлении старых Hub/Profile/Header/Admin visual surfaces **SUPERSEDED_BY_OWNER_DECISION_1734** и не является active instruction.
- Локальные application tests/build/CI не запускались; новый exact-head GitHub CI обязателен.

## Cycle 1733 — exact-head CI regression repair lock — кандидат v173.59

- Единственный источник дефектов цикла — GitHub CI `85239758056` на входном `v173.58`; широкие refactor/cleanup/search-for-next-failure запрещены.
- Разрешены только минимальные patches подтверждённых Ruff/Mypy/frontend-build/pytest failures и обязательная синхронизация current-state/release metadata/history.
- Защищённые Hub/Profile/Header/Admin/provider/compatibility surfaces восстанавливаются поверх frontend patch без удаления новых утверждённых bridge/Withdraw/Sale Packages contracts цикла 1732.
- `global_id`, BANK, Payment/Reconciliation, ShopOrder, Admin NFT, Reward Ads, Economy и Alembic CANON не изменяются.
- Новый `v173.59` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

## Текущая рабочая блокировка — кандидат v173.58 / цикл 1732

- Входной Development HEAD: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`.
- Внедрён адресный production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip`, SHA-256 `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`, рассчитанный именно на `v173.57`. Проверено: `131/131` modify source SHA совпали с HEAD, `45/45` add отсутствовали в HEAD; исходные target SHA overlay совпали `176/176`.
- Overlay: `162` frontend-файла и `14` backend bridge/OpenAPI-файлов; standalone/demo/simulation runtime в overlay отсутствует. Frontend contract patch содержит `128` production HTTP contracts: `126` уже существовали, добавлены `GET /auth/profile-photos` и `GET /tasks/earnings/me`.
- Supplied OpenAPI artifact после patch: `138 paths / 143 operations / 168 schemas`. В inventory также появился уже существовавший в source `GET /meta/health_db`; новый runtime route для него в 1732 не создавался. Frontend page floor: `39`. Protected Python/file floor остаётся `312 symbols / 58 modules / 68 files`.
- Новый selected-wallet seam адаптирован к Wallet/global_id CANON: внешний owner остаётся string `global_id`, BIGINT создаётся только через canonical DB-boundary helper. Новый Tasks bridge не добавляет лишний numeric coercion поверх уже разрешённого `NonFinancialReadOwner`.
- Новый Admin diagnostics helper сохранён как техническая диагностика, но его launcher/title приведены к человеческому русскому языку. Новые инженерные docstring/comments/error messages patch приведены к `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; технические идентификаторы не переводились.
- Frontend release metadata синхронизированы по фактическим patched bytes без запуска build/generator scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `pwa-build.json` и `release-assets-manifest.json`.
- Последний предоставленный exact-head CI остаётся `85157912581` на `v173.56`. Exact-head CI для входного `v173.57` в цикле 1732 не предоставлялся; новый `v173.58` требует отдельного GitHub CI пользователя.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий feature-cycle автоматически не назначается.

## Текущая рабочая блокировка — кандидат v173.57 / цикл 1731

- Exact-head GitHub CI `85157912581` проверил `v173.56`: CI `efhc.zip` размером `11975213` bytes совпадает с загруженным `EFHC_Bot_v173_56.zip`; checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`. SHA-256 загруженного входного HEAD: `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`; CI-лог не публикует SHA-256 самого `efhc.zip`.
- Все canonical gates в предоставленном gate summary имеют `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci, frontend build и pytest. Pytest: `1502 passed / 22 skipped / 1 warning`.
- Цикл 1731 выполнен как статический backend/frontend + SSOT/CANON audit и handoff без запуска локальных tests/guards/lint/type/build/Alembic/CI.
- Подтверждённый protected floor: `312 symbols / 58 modules / 68 files / 135 OpenAPI paths / 140 operations / 38 frontend pages`; отсутствующих зарегистрированных элементов не найдено.
- Runtime/backend/frontend production code в цикле 1731 не изменяется: подтверждённые системные долги вынесены в handoff backlog, destructive cleanup запрещён.
- Синхронизируются только active audit/current-state/function-surface/OpenAPI metadata и обязательная cycle/report документация.
- Статус кандидата v173.57: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий номер feature/audit-цикла не назначается самовольно; сначала требуется exact-head CI нового кандидата, затем работа продолжается по зафиксированному handoff backlog по решению пользователя.

## Cycle 1730 continuation — exact-head CI manifest integrity lock — кандидат v173.56

- Evidence: GitHub CI `85153784574`, checkout `f5371d8f896486a2cbffe10584d76e65ebb7d959`, CI archive size `12053999` bytes; exact local input HEAD `EFHC_Bot_v173_55.zip` имеет SHA-256 `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`.
- Единственный подтверждённый failing gate — pytest; единственный failure: stale SHA для `docs/cycles/WORK_CYCLES_1701-1800.md` в `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv`.
- Разрешён только минимальный repair release-history manifest после фактической записи цикла и обязательная синхронизация current-state/report numbering.
- Backend/frontend runtime, routes, compatibility, aliases, Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics не менять.
- Цикл 1731 не начинается до следующего exact-head GitHub CI кандидата `v173.56`.

## Cycle 1730 — exact-head CI qualification lock — кандидат v173.55

- Evidence: GitHub CI `85145865998`, checkout `3dd76713f4dea04ebb8d728385eab80f1726e41d`, CI archive size `12046473` bytes; SHA-256 CI archive в логах отсутствует.
- Подтверждённые failing gates: Mypy (`4` `no-any-return` на явной `global_id -> BIGINT` DB-boundary) и pytest (`3` architecture/current-state failures).
- Разрешены только минимальные исправления этих подтверждённых причин и обязательная синхронизация current-state/reporting документов.
- Запрещены новый alias cleanup, перенос функций, изменение Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics и удаление compatibility surfaces.
- Новый `v173.55` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Блокировка цикла 1611 — PostgreSQL gate

До реального `PG-0 PASS` разрешены только подготовленные ORM, migration,
static guards и PostgreSQL tests. Запрещены runtime `IdentityResolver`,
account/session creation, backfill, ownership/read switch и переход к
циклу 1612. PostgreSQL в среде чата не устанавливается; существующие
GitHub CI workflows не изменяются.

# Блокировка цикла 1609

`AuthProvider` и `VerifiedIdentity` являются provider-neutral
контрактами. Provider registry работает fail closed, Telegram не
является root provider, а `global_id` остаётся единственным account
owner. До последующих циклов запрещены DDL, account resolution,
sessions, backfill, read switch и financial ownership switch.

## Cycle 1598 LEGACY alias lock

The active compatibility alias is
`User.legacy_runtime_id -> User.id`; it is restricted to migration,
reconciliation and compatibility tests. The future alias from
`User.id` to `User.user_id` remains inactive until the separately
approved read switch. Backfill execution is forbidden in cycle 1598.

## Cycle 1595 — immutable identity value-type lock

The only allowed backend adoption in this cycle is the isolated `backend/app/identity` value-type package. `UserId` and `TelegramId` must remain distinct nominal objects. Models, migrations, services, CRUD, routes, schemas, dependencies and frontend ownership are protected by a 481-file semantic/exact manifest. Comments may be corrected, but executable semantics must remain unchanged.

## LOCK: Single startup and active Operator Kernel architecture — v171.64

- `START_HERE.md` is the only active startup order.
- `KERNEL.md` is the active full detailed dispatch layer: keywords, task types, exact routes, canonical anchors, patch/validation/proof/archive boundaries.
- Kernel must not duplicate full CANON/SSOT/NORM or accumulate historical Current HEAD blocks, but it must never be demoted to navigation-only.
- `routes.yaml` is primary runtime route truth; hardcoded routes are fallback only.
- `file_map.summary.json` is the startup map; full `file_map.json` and full Healer history are route-only.
- CANON, SSOT, NORM, AI Archive Laws and active AI docs remain independent critical regression-control layers.
- The sandbox is ephemeral; each new session starts from the latest canonical archive.
- CI is allowed with bounded timeout; the canonical GitHub Actions `canon` job timeout is 10 minutes and may not exceed the user-approved 5–10 minute range without direct instruction. PNG screenshots are local-only evidence, not required GitHub CI artifacts.
- Real application screenshot proof must use the running app and `page.goto()`; `page.set_content` cannot be accepted as application proof.
- Duplicate active truth sources are forbidden. Compatibility files must point to the canonical source.


## LOCK: AI operational brain and bounded history reading

- `docs/AI/` is the AI operational working brain, not a historical archive.
- `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` contains only unresolved or immediately actionable items.
- Every user-approved decision is transferred to the appropriate CANON / SSOT / NORM and removed from active temporary memory.
- Reports, audits and cycles remain stored in the development archive, but without an explicit request ordinary reading is limited to the latest two relevant entries per layer.
- Older history is route-only: explicit user request, forensic regression, Healer pointer or cycle reconciliation.

## LOCK: AI Archive Laws

- `docs/AI/AI_ARCHIVE_LAWS.md` is an active archive-work lock.
- Tests, CI, logs and reports must not be weakened to hide a problem.
- Active tests must not be archived, skipped, xfailed or excluded without
  replacement mapping and direct user permission where required.
- If an error cannot be safely repaired, the assistant must ask mandatory
  iteration questions in Russian.

# Architectural Locks

Статус: NORM (нормативный документ разработки). Якорь SSOT:
docs/SSOT/SSOT_INDEX.md

Назначение:
- Этот документ фиксирует архитектурные запреты и ограничения
  разработки.
- Продуктовые нормы (термины, экономика, банк, выводы, TON) живут в
docs/SSOT/EFHC_CANON.md и docs/SSOT/PROJECT_GLOSSARY.md.

Приоритет и конфликты:
- Источник приоритета документов: docs/SSOT/SSOT_INDEX.md.
- Если DERIVED-документ (architecture/specification и т.п.) конфликтует
  с
NORM, он подлежит обновлению.
- Если код конфликтует с NORM, это дефект: требуется правка кода или
  NORM
через осмысленное изменение и тесты.

Инструменты контроля:
- ops/canon_rules.yaml и ops/canon_guard.py реализуют проверки канона,
но не заменяют SSOT_INDEX и NORM-документы.

---

## LOCK: runtime logs location

Правило:
- Текущие runtime/evidence outputs пишутся только в `reports/current/` или `reports/generated/`; immutable отчёты — в `reports/numbered/`.
- Запрещено создавать log/session/strict файлы и каталоги
  вне канонических `reports/current/`, `reports/generated/` и `reports/numbered/`.


## LOCK: provider-independent global identity

Active source: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

- главный system/domain owner — `GlobalId` / `global_id`;
- физическая owner-колонка — `users.global_id`;
- `users.user_id` отсутствует; `User.global_id` обращается к физической колонке напрямую;
- локальный `id` не является identity аккаунта;
- `TelegramId` / `tg_id` — только provider identifier;
- `global_id = tg_id` и косвенные преобразования запрещены;
- wallet, email и provider subjects не становятся `global_id`;
- внешний `global_id` — десять ASCII-цифр, ноль запрещён;
- historical backfill/read-switch stages завершены; новые owner-переходы допускаются только с PostgreSQL reconciliation;
- legacy aliases не могут становиться новым контрактом и удаляются по матрице cleanup.

Admin roles целево принадлежат `global_id + user_roles`. Telegram
whitelist остаётся только временным bootstrap/audit source.

## LOCK: UI navbar fixed (6 tabs, order)

Запрещено менять состав и порядок нижней навигации.

Канон (ровно 6 вкладок, фиксированный порядок): 1) Energy 2) Panels 3)
Exchange 4) Tasks 5) Referrals 6) Ranks

Любые изменения допускаются только через обновление NORM/SSOT и guard.

---

## LOCK: language split by surface

Запрещено смешивать языковой канон player-facing и admin/operator
слоёв.

Канон:
- Player-facing surfaces — English-first.
- Admin/operator surfaces — Russian-first.
- Trust-sensitive player comments/outcomes — quality-first; fallback =
  English.
- Levels / ranks names — всегда EN.
- Плохой или сырой перевод не может подменять English fallback для
  игрока.

---

## LOCK: Profile entrypoint + SSOT settings list

Канон входа: Profile открывается по нажатию на аватар в левом
верхнем углу.

SSOT список настроек (утверждён): 1) Telegram display name (RO) 2)
Username (RO) 3) VIP badge (RO) 4) Avatar (Telegram default + custom +
reset) 5) Descriptions language (13 langs, EN first) 6) UI sounds
(on/off) 7) Sound volume 8) Sound pack 9) Haptics (on/off) 10) Hide
balances 11) Show decimal detail (still 8 decimals) 12) Reduce motion
13) Confirm before purchase 14) Confirm before withdraw request 15)
Confirm before convert kWh→EFHC 16) Confirm before watch ad 17) In-app
toasts 18) Important alerts only 19) FAQ 20) Support chat 21) Terms 22)
Privacy 23) Reset settings

---



## LOCK: GlobalHeader status badges + profile entrypoint

Канон:
- В `GlobalHeader` должны существовать badge `VIP` и `Activ`, если
  соответствующие статусы есть у пользователя.
- User-facing вход обозначается как `Профиль / Профіль / Profile`.
- Архивные панели не должны просачиваться в Energy summary.
- На странице Energy допускаются только активные панели и их текущая
  суммарная генерация.

## LOCK: Admin entry via Profile

Current compatibility:
- Admin Panel remains inside Profile.
- The Telegram allowlist continues to work during migration.
- Target authorization is `global_id + user_roles`.
- Provider identity is context, not the final RBAC owner.



## Economy SSOT Locks: Generation & Exchange

SSOT: механика обмена и вывода — см.
docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

SSOT: механика панелей — см. docs/SSOT/PANELS_SSOT.md


- **Lock: total_generated_kwh is append-only** (never decreases).
- **Lock: exchanged_kwh_total is append-only** (never decreases).
- **Mirror formula (source of truth):**
  `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`
- **EXCHANGE_ALL** MUST:
  - increase `exchanged_kwh_total` by `available_kwh_before`
  - credit EFHC **MAIN** 1:1
  - never mutate `total_generated_kwh`
  - `available_kwh` существует только как вычисляемое зеркало
  по формуле mirror result.


## Tasks monetary atomicity

- Любая Task operation, которая перемещает EFHCb и одновременно меняет submission/completion state, использует caller-owned `*_nocommit` banking primitive.
- Money ledger, final/paid state, `Task.total_limit` reservation и canonical transfer reference фиксируются одной root DB transaction.
- Admin moderation дополнительно включает `AdminLogger.write(required=True)` и notification outbox до того же commit.
- Внешняя Telegram/network delivery выполняется только после successful commit.
- `TxResult.created_log_id` — canonical transfer-log reference; несуществующие aliases `log_id` / `transfer_id` запрещены без явного DTO contract.

## ADS provider financial claim

- Reward-authoritative provider event глобально single-claim по `(provider, provider_event_id)` до EFHCb payout.
- Event telemetry deduplication не заменяет financial replay guard; cross-session/cross-owner reuse fail-closed.


## Общие логи и отчёты

Immutable отчёты изменений ведутся в `reports/numbered/`.
`reports/manifests/REPORTS_NUMBERING_MANIFEST.csv` — каноничный нумерованный реестр
`append-only`: каждая новая запись добавляется строго по порядку
и получает следующий номер без пропусков.


## Overview docs sync (MUST)

- Обзорные документы обязаны совпадать с `docs/SSOT/ssot_pack/*`.
- `docs/NORM/TESTS_CATALOG.md` описывает реальный active `tests/**`.
- Для быстрого аудита использовать `docs/OVERVIEW_SSOT_SYNC.md` и
  `docs/NORM/DATABASE_MIGRATION_INVARIANTS_NORM.md`.


## LOCK: Conditional incident and report synchronization

- Every changed pass receives one concise change report.
- Healer and the errors registry are updated only for a confirmed incident/root cause with an independent preventive guard.
- A CSS/runtime/document edit does not automatically create a new Healer case or product norm.
- Reports record work and evidence; they cannot create CANON/SSOT/NORM truth.

## LOCK: New-chat continuation source

A new chat starts from the latest canonical ZIP, then `START_HERE.md` and `KERNEL.md`. Obsolete continuation prompts are externalized in the artifacts history ZIP and are not active startup instructions.

## Historical trace lock

как audit/report/migration history. Они не могут возвращаться в
active architecture, runtime imports, API routes или SSOT tables.


## LOCK: document phase package exclusions

В обычные пакеты документной ревизии не входят:
- внешний `ARTIFACTS_HISTORY` ZIP;
- historical log/evidence, уже вынесенные из active HEAD;
- временные generated outputs вне `reports/current/` и `reports/generated/`.
Удалённые `docs/history/` и `АРТЕФАКТЫ/` не создаются повторно.

## LOCK: inventory answer format

Для файлов документной ревизии описание даётся связными абзацами, а
в конце обязательно формулируется отдельное предложение по файлу.


## v168_91 / work pass lock: Tasks execution log boundary

The `/tasks` player-facing screen is an earning module, not a task
history, execution-log, backend-log or idempotency/debug screen.

Allowed:
- backend tables/services may keep `task_complete_lock`,
  `task_bonus_log`, `task_submissions` and transfer logs for
  double-claim protection, auditability and admin operations;
- admin/operator contours may inspect task traces through admin routes
  such as `/admin/tasks/...` and `/admin/logs/transfers?reason=task_bonus`.

Forbidden:
- rendering task execution history on `/tasks`;
- rendering backend execution logs or idempotency/protection internals on
  the public Tasks page;
- adding public `/tasks/history` or `/tasks/logs` routes without a later
  explicit canon change.

## HUB two-action public-copy lock — current

- `/hub` renders exactly two visible actions: `Пополнение` and `EFHC VIP NFT`.
- The `Пополнение` action contains no explanatory commerce copy before external navigation.
- Purchase, buy, shop, package, checkout, TON, GRAM, USDT and price are forbidden in the active HUB copy.
- The separate `EFHC VIP NFT` action and official GetGems link are mandatory and may not be removed without direct user approval.
- Commerce details are allowed only after signed handoff on `/browser-shop`.
- GlobalHeader `+` remains Direct Deposit and accepts EFHC jetton only.
- If a current guard conflicts with an interpretation, the guarded function must not be deleted silently; stop and request a user decision unless the user has already supplied an explicit replacement canon.

## Цикл 1728 — Runtime Compatibility lock

- `no caller != delete proof`: отсутствие current caller не является основанием удаления compatibility surface.
- `create_app`, `app.database.get_engine/get_session_factory`, `app.core.decimal_utils.d8` и `order_models.ShopOrder` сохраняются бессрочно как тонкие import/startup/ORM facades и не получают второй runtime.
- `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, `TickContext`, `SchedulerError`, `JobTimeout`, `scheduler_core.tick`, `tasks_maintenance.run_once` — бессрочные compatibility-only surfaces; новый код использует canonical implementation.
- `RBAC.is_superadmin` не является auth-path и может применяться только к уже разрешённому `AdminUser`.
- Подробные комментарии рядом с compatibility-кодом являются частью архитектурного решения и должны читаться до будущего cleanup-аудита.
- Удаление возможно только после отдельного решения пользователя, полного delete-proof и последующего exact-head GitHub CI.
- Active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
## Cycle 1729 — consolidation + alias retirement lock

- Решения 1719–1728 сведены в `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`; новый cleanup из консолидации не выводится автоматически.
- `sql_aliases_core` больше не является transitional resolver: private aliases `core/efhc/efhc-core/admin/efhc-admin/vip_log/vip_status` удалены после delete-proof.
- ENV/provider/wire/history aliases не приравниваются к obsolete runtime aliases и сохраняются без отдельного delete-proof внешних потребителей.
- Бессрочные compatibility surfaces циклов 1726–1728 не являются кандидатами удаления в 1729.
- Следующий цикл 1730 — только exact-head CI qualification/error burn-down; новые функциональные решения запрещены без нового ТЗ.


## Autonomous DevOps safety

- Existing Docker Compose deployment/backup/rollback contour remains authority; autonomous DevOps may extend it but must not create a parallel deployment/backup system.
- Каждый production backup generation имеет один canonical encrypted recovery artifact; artifact сохраняется локально, а владелец скачивает выбранную копию на ПК/смартфон по SSH/SFTP.
- Локальный retention production VPS жёстко ограничен 10 newest backup generations; generation 11+ локально не сохраняется.
- Database-changing update требует successful создания и проверки собственного pre-update encrypted recovery artifact до продолжения update; Telegram delivery не входит в backup contract.
- Backup encryption key создаётся только при явной первичной initialization. Отсутствующий key в initialized installation является fail-closed состоянием и никогда не запускает автоматическую регенерацию.
- Auto-healing allowlist is limited to bounded restart of ordinary application services; PostgreSQL restore/restart, volume deletion, SSH/firewall mutation and destructive rollback are not autonomous actions.
- Diagnostic bundle must exclude `.env`, authentication/secrets/private keys/passphrase, request bodies and private user data.
- EFHC V1 использует одну production VPS; обязательный второй monitoring/backup host запрещён, а полная потеря VPS относится к Disaster Recovery на заменяющем VPS.

## Referral monetary namespace separation

- Direct numbered unit reward uses `REF_ACT_UNIT:G{inviter_global_id}:N{reward_no:05d}`, slots `1..10000` only.
- Lvl reward uses independent `REF_LVL:G{inviter_global_id}:L{level}` namespace; Lvl `1..5` each may pay once regardless of direct slot allocation.
- Referral/ranking display is nonfinancial and must not create reward transactions.
