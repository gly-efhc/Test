# ACTIVE EXACT-HEAD CI REPAIR LOCK — v173.65 / цикл 1739

1. Evidence source цикла — GitHub CI `85380431378` на входном `v173.64`; CI archive size `12351381` bytes совпадает с локальным входным HEAD, SHA-256 payload в CI-логах отсутствует.
2. Единственный failing gate входного CI — pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`; остальные canonical gates `exit=0`.
3. Исправлять разрешено только четыре подтверждённых stale expectations: два PostgreSQL FK-count tests, exact-fragment identity disposition и Russian Engineering NORM.
4. Production runtime/backend/frontend, ADS mediation, single-head `0001`, PATCH_002 visual/text CANON и business `global_id` semantics не изменяются.
5. CI/guards не получают новых broad exemptions; provider wire aliases остаются только на уже зарегистрированных boundaries.
6. Локальные tests/guards/lint/type/build/Alembic/CI запрещены; следующий verifier — exact-head GitHub CI кандидата `v173.65`.
7. Function-preservation floor остаётся `339/62/77`, OpenAPI `155/161`, frontend pages `39`, schemas `168`.

# ACTIVE ADS / FRONTEND MERGE LOCK — v173.63 / циклы 1735–1737

1. `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` остаётся абсолютным visual + user-facing text CANON для затронутых frontend surfaces. ADS ТЗ не даёт права возвращать старый Bot UI.
2. Прямое owner-approved исключение ADS scope: разрешены новые элементы Admin ADS/Admin Tasks и runtime ADS-состояния существующей Tasks-страницы; остальные visual/text изменения требуют отдельного согласования владельца.
3. `AdManager` — единственная новая production mediation architecture. Tasks не содержит provider-specific SDK/verification logic; provider adapters не начисляют EFHCb.
4. Reward authority: `Task.bonus_efhc` → immutable session reward snapshot → existing `tasks_service` / canonical bonus path. Callback/provider amount никогда не определяет EFHCb.
5. ADS business owner — `global_id`. `tg_id` допустим только на Telegram/provider boundary, когда этого реально требует provider/Bot API.
6. `Admin DB override → ENV fallback`; secret credential хранится encrypted, frontend получает только public runtime config. Secret plaintext/log/OpenAPI example/analytics запрещены.
7. `builtin_timer` — DEV/CI/diagnostics only и не входит в production monetization fallback. Exhausted real-provider chain → `NO_FILL` без reward.
8. TADS/MyBid reward adapters остаются fail-closed `NOT_SUPPORTED`, пока нет точного официального publisher-cabinet SDK/callback contract. Запрещено придумывать verification contract ради «полноты».
9. Server session, UTC daily limit, provider event dedup, one reward/session, impossible-transition rejection и idempotent reward — обязательные security invariants.
10. Старые `/ads/slot`, `/ads/callback/{provider}`, `showTelegramAd()` и historical `efhc_core.ads` сохраняются как compatibility/historical surfaces; их существование не создаёт вторую production reward architecture.
11. Revenue Optimizer использует фактическую EFHC telemetry (requests/fills/completions/revenue/fallback), не hardcoded рейтинг рекламных сетей.
12. Любое удаление compatibility/provider surface требует отдельного delete-proof; `no caller != delete proof`.
13. Локальные tests/guards/lint/type/build/Alembic/CI не запускать без отдельного разрешения владельца. Новый `v173.63` требует exact-head GitHub CI пользователя.

---

## Cycle 1734 — FRONTEND PATCH AUTHORITY corrective merge lock — кандидат v173.60

- Утверждённый владельцем `PATCH_002` имеет абсолютный приоритет для visual/UX/user-facing text. Старый Bot frontend **не является visual donor**.
- GitHub CI/architecture tests не могут разрешить visual/text rollback. Guard, требующий старую presentation при конфликте с PATCH_002, является stale и мигрируется под patch.
- Функции обеих веток сохраняются: `frontend ∪ main/backend`. Отсутствие функции в patch UI не разрешает удалить её и не разрешает вернуть старый UI; до согласования она остаётся `OWNER_REVIEW` donor либо встраивается без visual/text change.
- Автоматически допустимы только route/API/data/global_id/security/typing/i18n-coverage/generated-metadata изменения без visual/text эффекта. Любое visual/text/layout/CSS/icon/visible-action изменение требует отдельного решения владельца.
- Fail-closed proof: `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; только `EXACT_PATCH`, зарегистрированный `NON_VISUAL_INTEGRATION`, `FUNCTION_UNION_NON_VISUAL` или `OWNER_APPROVED_CHANGE`.
- Историческая формулировка цикла 1733 о восстановлении старых Hub/Profile/Header/Admin visual surfaces **SUPERSEDED_BY_OWNER_DECISION_1734** и не является active instruction.
- Локальные application tests/build/CI не запускались; новый exact-head GitHub CI обязателен.

## Cycle 1733 — exact-head CI regression repair lock — кандидат v173.59

- Единственный источник дефектов цикла — GitHub CI `85239758056` на входном `v173.58`; широкие refactor/cleanup/search-for-next-failure запрещены.
- Разрешены только минимальные patches подтверждённых Ruff/Mypy/frontend-build/pytest failures и обязательная синхронизация current-state/release metadata/history.
- Защищённые Hub/Profile/Header/Admin/provider/compatibility surfaces восстанавливаются поверх frontend patch без удаления новых утверждённых bridge/Withdraw/Sale Packages contracts цикла 1732.
- `global_id`, BANK, Payment/Reconciliation, ShopOrder, Admin NFT, Reward Ads, Economy и Alembic CANON не изменяются.
- Новый `v173.59` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

## Текущая рабочая блокировка — кандидат v173.58 / цикл 1732

- Входной Development HEAD: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`.
- Внедрён адресный production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip`, SHA-256 `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`, рассчитанный именно на `v173.57`. Проверено: `131/131` modify source SHA совпали с HEAD, `45/45` add отсутствовали в HEAD; исходные target SHA overlay совпали `176/176`.
- Overlay: `162` frontend-файла и `14` backend bridge/OpenAPI-файлов; standalone/demo/simulation runtime в overlay отсутствует. Frontend contract patch содержит `128` production HTTP contracts: `126` уже существовали, добавлены `GET /auth/profile-photos` и `GET /tasks/earnings/me`.
- Supplied OpenAPI artifact после patch: `138 paths / 143 operations / 168 schemas`. В inventory также появился уже существовавший в source `GET /meta/health_db`; новый runtime route для него в 1732 не создавался. Frontend page floor: `39`. Protected Python/file floor остаётся `312 symbols / 58 modules / 68 files`.
- Новый selected-wallet seam адаптирован к Wallet/global_id CANON: внешний owner остаётся string `global_id`, BIGINT создаётся только через canonical DB-boundary helper. Новый Tasks bridge не добавляет лишний numeric coercion поверх уже разрешённого `NonFinancialReadOwner`.
- Новый Admin diagnostics helper сохранён как техническая диагностика, но его launcher/title приведены к человеческому русскому языку. Новые инженерные docstring/comments/error messages patch приведены к `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; технические идентификаторы не переводились.
- Frontend release metadata синхронизированы по фактическим patched bytes без запуска build/generator scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `pwa-build.json` и `release-assets-manifest.json`.
- Последний предоставленный exact-head CI остаётся `85157912581` на `v173.56`. Exact-head CI для входного `v173.57` в цикле 1732 не предоставлялся; новый `v173.58` требует отдельного GitHub CI пользователя.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий feature-cycle автоматически не назначается.

## Текущая рабочая блокировка — кандидат v173.57 / цикл 1731

- Exact-head GitHub CI `85157912581` проверил `v173.56`: CI `efhc.zip` размером `11975213` bytes совпадает с загруженным `EFHC_Bot_v173_56.zip`; checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`. SHA-256 загруженного входного HEAD: `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`; CI-лог не публикует SHA-256 самого `efhc.zip`.
- Все canonical gates в предоставленном gate summary имеют `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci, frontend build и pytest. Pytest: `1502 passed / 22 skipped / 1 warning`.
- Цикл 1731 выполнен как статический backend/frontend + SSOT/CANON audit и handoff без запуска локальных tests/guards/lint/type/build/Alembic/CI.
- Подтверждённый protected floor: `312 symbols / 58 modules / 68 files / 135 OpenAPI paths / 140 operations / 38 frontend pages`; отсутствующих зарегистрированных элементов не найдено.
- Runtime/backend/frontend production code в цикле 1731 не изменяется: подтверждённые системные долги вынесены в handoff backlog, destructive cleanup запрещён.
- Синхронизируются только active audit/current-state/function-surface/OpenAPI metadata и обязательная cycle/report документация.
- Статус кандидата v173.57: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий номер feature/audit-цикла не назначается самовольно; сначала требуется exact-head CI нового кандидата, затем работа продолжается по зафиксированному handoff backlog по решению пользователя.

## Cycle 1730 continuation — exact-head CI manifest integrity lock — кандидат v173.56

- Evidence: GitHub CI `85153784574`, checkout `f5371d8f896486a2cbffe10584d76e65ebb7d959`, CI archive size `12053999` bytes; exact local input HEAD `EFHC_Bot_v173_55.zip` имеет SHA-256 `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`.
- Единственный подтверждённый failing gate — pytest; единственный failure: stale SHA для `docs/cycles/WORK_CYCLES_1701-1800.md` в `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv`.
- Разрешён только минимальный repair release-history manifest после фактической записи цикла и обязательная синхронизация current-state/report numbering.
- Backend/frontend runtime, routes, compatibility, aliases, Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics не менять.
- Цикл 1731 не начинается до следующего exact-head GitHub CI кандидата `v173.56`.

## Cycle 1730 — exact-head CI qualification lock — кандидат v173.55

- Evidence: GitHub CI `85145865998`, checkout `3dd76713f4dea04ebb8d728385eab80f1726e41d`, CI archive size `12046473` bytes; SHA-256 CI archive в логах отсутствует.
- Подтверждённые failing gates: Mypy (`4` `no-any-return` на явной `global_id -> BIGINT` DB-boundary) и pytest (`3` architecture/current-state failures).
- Разрешены только минимальные исправления этих подтверждённых причин и обязательная синхронизация current-state/reporting документов.
- Запрещены новый alias cleanup, перенос функций, изменение Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics и удаление compatibility surfaces.
- Новый `v173.55` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Блокировка цикла 1611 — PostgreSQL gate

До реального `PG-0 PASS` разрешены только подготовленные ORM, migration,
static guards и PostgreSQL tests. Запрещены runtime `IdentityResolver`,
account/session creation, backfill, ownership/read switch и переход к
циклу 1612. PostgreSQL в среде чата не устанавливается; существующие
GitHub CI workflows не изменяются.

# Блокировка цикла 1609

`AuthProvider` и `VerifiedIdentity` являются provider-neutral
контрактами. Provider registry работает fail closed, Telegram не
является root provider, а `global_id` остаётся единственным account
owner. До последующих циклов запрещены DDL, account resolution,
sessions, backfill, read switch и financial ownership switch.

## Cycle 1598 LEGACY alias lock

The active compatibility alias is
`User.legacy_runtime_id -> User.id`; it is restricted to migration,
reconciliation and compatibility tests. The future alias from
`User.id` to `User.user_id` remains inactive until the separately
approved read switch. Backfill execution is forbidden in cycle 1598.

## Cycle 1595 — immutable identity value-type lock

The only allowed backend adoption in this cycle is the isolated `backend/app/identity` value-type package. `UserId` and `TelegramId` must remain distinct nominal objects. Models, migrations, services, CRUD, routes, schemas, dependencies and frontend ownership are protected by a 481-file semantic/exact manifest. Comments may be corrected, but executable semantics must remain unchanged.

## LOCK: Single startup and active Operator Kernel architecture — v171.64

- `START_HERE.md` is the only active startup order.
- `KERNEL.md` is the active full detailed dispatch layer: keywords, task types, exact routes, canonical anchors, patch/validation/proof/archive boundaries.
- Kernel must not duplicate full CANON/SSOT/NORM or accumulate historical Current HEAD blocks, but it must never be demoted to navigation-only.
- `routes.yaml` is primary runtime route truth; hardcoded routes are fallback only.
- `file_map.summary.json` is the startup map; full `file_map.json` and full Healer history are route-only.
- CANON, SSOT, NORM, AI Archive Laws and active AI docs remain independent critical regression-control layers.
- The sandbox is ephemeral; each new session starts from the latest canonical archive.
- CI is allowed with bounded timeout; the canonical GitHub Actions `canon` job timeout is 10 minutes and may not exceed the user-approved 5–10 minute range without direct instruction. PNG screenshots are local-only evidence, not required GitHub CI artifacts.
- Real application screenshot proof must use the running app and `page.goto()`; `page.set_content` cannot be accepted as application proof.
- Duplicate active truth sources are forbidden. Compatibility files must point to the canonical source.


## LOCK: AI operational brain and bounded history reading

- `docs/AI/` is the AI operational working brain, not a historical archive.
- `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` contains only unresolved or immediately actionable items.
- Every user-approved decision is transferred to the appropriate CANON / SSOT / NORM and removed from active temporary memory.
- Reports, audits and cycles remain stored in the development archive, but without an explicit request ordinary reading is limited to the latest two relevant entries per layer.
- Older history is route-only: explicit user request, forensic regression, Healer pointer or cycle reconciliation.

## LOCK: AI Archive Laws

- `docs/AI/AI_ARCHIVE_LAWS.md` is an active archive-work lock.
- Tests, CI, logs and reports must not be weakened to hide a problem.
- Active tests must not be archived, skipped, xfailed or excluded without
  replacement mapping and direct user permission where required.
- If an error cannot be safely repaired, the assistant must ask mandatory
  iteration questions in Russian.

# Architectural Locks

Статус: NORM (нормативный документ разработки). Якорь SSOT:
docs/SSOT/SSOT_INDEX.md

Назначение:
- Этот документ фиксирует архитектурные запреты и ограничения
  разработки.
- Продуктовые нормы (термины, экономика, банк, выводы, TON) живут в
docs/SSOT/EFHC_CANON.md и docs/SSOT/PROJECT_GLOSSARY.md.

Приоритет и конфликты:
- Источник приоритета документов: docs/SSOT/SSOT_INDEX.md.
- Если DERIVED-документ (architecture/specification и т.п.) конфликтует
  с
NORM, он подлежит обновлению.
- Если код конфликтует с NORM, это дефект: требуется правка кода или
  NORM
через осмысленное изменение и тесты.

Инструменты контроля:
- ops/canon_rules.yaml и ops/canon_guard.py реализуют проверки канона,
но не заменяют SSOT_INDEX и NORM-документы.

---

## LOCK: runtime logs location

Правило:
- Текущие runtime/evidence outputs пишутся только в `reports/current/` или `reports/generated/`; immutable отчёты — в `reports/numbered/`.
- Запрещено создавать log/session/strict файлы и каталоги
  вне канонических `reports/current/`, `reports/generated/` и `reports/numbered/`.


## LOCK: provider-independent global identity

Active source: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

- главный system/domain owner — `GlobalId` / `global_id`;
- физическая owner-колонка — `users.global_id`;
- `users.user_id` отсутствует; `User.global_id` обращается к физической колонке напрямую;
- локальный `id` не является identity аккаунта;
- `TelegramId` / `tg_id` — только provider identifier;
- `global_id = tg_id` и косвенные преобразования запрещены;
- wallet, email и provider subjects не становятся `global_id`;
- внешний `global_id` — десять ASCII-цифр, ноль запрещён;
- historical backfill/read-switch stages завершены; новые owner-переходы допускаются только с PostgreSQL reconciliation;
- legacy aliases не могут становиться новым контрактом и удаляются по матрице cleanup.

Admin roles целево принадлежат `global_id + user_roles`. Telegram
whitelist остаётся только временным bootstrap/audit source.

## LOCK: UI navbar fixed (6 tabs, order)

Запрещено менять состав и порядок нижней навигации.

Канон (ровно 6 вкладок, фиксированный порядок): 1) Energy 2) Panels 3)
Exchange 4) Tasks 5) Referrals 6) Ranks

Любые изменения допускаются только через обновление NORM/SSOT и guard.

---

## LOCK: language split by surface

Запрещено смешивать языковой канон player-facing и admin/operator
слоёв.

Канон:
- Player-facing surfaces — English-first.
- Admin/operator surfaces — Russian-first.
- Trust-sensitive player comments/outcomes — quality-first; fallback =
  English.
- Levels / ranks names — всегда EN.
- Плохой или сырой перевод не может подменять English fallback для
  игрока.

---

## LOCK: Profile entrypoint + SSOT settings list

Канон входа: Profile открывается по нажатию на аватар в левом
верхнем углу.

SSOT список настроек (утверждён): 1) Telegram display name (RO) 2)
Username (RO) 3) VIP badge (RO) 4) Avatar (Telegram default + custom +
reset) 5) Descriptions language (13 langs, EN first) 6) UI sounds
(on/off) 7) Sound volume 8) Sound pack 9) Haptics (on/off) 10) Hide
balances 11) Show decimal detail (still 8 decimals) 12) Reduce motion
13) Confirm before purchase 14) Confirm before withdraw request 15)
Confirm before convert kWh→EFHC 16) Confirm before watch ad 17) In-app
toasts 18) Important alerts only 19) FAQ 20) Support chat 21) Terms 22)
Privacy 23) Reset settings

---



## LOCK: GlobalHeader status badges + profile entrypoint

Канон:
- В `GlobalHeader` должны существовать badge `VIP` и `Activ`, если
  соответствующие статусы есть у пользователя.
- User-facing вход обозначается как `Профиль / Профіль / Profile`.
- Архивные панели не должны просачиваться в Energy summary.
- На странице Energy допускаются только активные панели и их текущая
  суммарная генерация.

## LOCK: Admin entry via Profile

Current compatibility:
- Admin Panel remains inside Profile.
- The Telegram allowlist continues to work during migration.
- Target authorization is `global_id + user_roles`.
- Provider identity is context, not the final RBAC owner.



## Economy SSOT Locks: Generation & Exchange

SSOT: механика обмена и вывода — см.
docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

SSOT: механика панелей — см. docs/SSOT/PANELS_SSOT.md


- **Lock: total_generated_kwh is append-only** (never decreases).
- **Lock: exchanged_kwh_total is append-only** (never decreases).
- **Mirror formula (source of truth):**
  `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`
- **EXCHANGE_ALL** MUST:
  - increase `exchanged_kwh_total` by `available_kwh_before`
  - credit EFHC **MAIN** 1:1
  - never mutate `total_generated_kwh`
  - `available_kwh` существует только как вычисляемое зеркало
  по формуле mirror result.


## Общие логи и отчёты

Immutable отчёты изменений ведутся в `reports/numbered/`.
`reports/manifests/REPORTS_NUMBERING_MANIFEST.csv` — каноничный нумерованный реестр
`append-only`: каждая новая запись добавляется строго по порядку
и получает следующий номер без пропусков.


## Overview docs sync (MUST)

- Обзорные документы обязаны совпадать с `docs/SSOT/ssot_pack/*`.
- `docs/NORM/TESTS_CATALOG.md` описывает реальный active `tests/**`.
- Для быстрого аудита использовать `docs/OVERVIEW_SSOT_SYNC.md` и
  `docs/NORM/DATABASE_MIGRATION_INVARIANTS_NORM.md`.


## LOCK: Conditional incident and report synchronization

- Every changed pass receives one concise change report.
- Healer and the errors registry are updated only for a confirmed incident/root cause with an independent preventive guard.
- A CSS/runtime/document edit does not automatically create a new Healer case or product norm.
- Reports record work and evidence; they cannot create CANON/SSOT/NORM truth.

## LOCK: New-chat continuation source

A new chat starts from the latest canonical ZIP, then `START_HERE.md` and `KERNEL.md`. Obsolete continuation prompts are externalized in the artifacts history ZIP and are not active startup instructions.

## Historical trace lock

как audit/report/migration history. Они не могут возвращаться в
active architecture, runtime imports, API routes или SSOT tables.


## LOCK: document phase package exclusions

В обычные пакеты документной ревизии не входят:
- внешний `ARTIFACTS_HISTORY` ZIP;
- historical log/evidence, уже вынесенные из active HEAD;
- временные generated outputs вне `reports/current/` и `reports/generated/`.
Удалённые `docs/history/` и `АРТЕФАКТЫ/` не создаются повторно.

## LOCK: inventory answer format

Для файлов документной ревизии описание даётся связными абзацами, а
в конце обязательно формулируется отдельное предложение по файлу.


## v168_91 / work pass lock: Tasks execution log boundary

The `/tasks` player-facing screen is an earning module, not a task
history, execution-log, backend-log or idempotency/debug screen.

Allowed:
- backend tables/services may keep `task_complete_lock`,
  `task_bonus_log`, `task_submissions` and transfer logs for
  double-claim protection, auditability and admin operations;
- admin/operator contours may inspect task traces through admin routes
  such as `/admin/tasks/...` and `/admin/logs/transfers?reason=task_bonus`.

Forbidden:
- rendering task execution history on `/tasks`;
- rendering backend execution logs or idempotency/protection internals on
  the public Tasks page;
- adding public `/tasks/history` or `/tasks/logs` routes without a later
  explicit canon change.

## HUB two-action public-copy lock — current

- `/hub` renders exactly two visible actions: `Пополнение` and `EFHC VIP NFT`.
- The `Пополнение` action contains no explanatory commerce copy before external navigation.
- Purchase, buy, shop, package, checkout, TON, GRAM, USDT and price are forbidden in the active HUB copy.
- The separate `EFHC VIP NFT` action and official GetGems link are mandatory and may not be removed without direct user approval.
- Commerce details are allowed only after signed handoff on `/browser-shop`.
- GlobalHeader `+` remains Direct Deposit and accepts EFHC jetton only.
- If a current guard conflicts with an interpretation, the guarded function must not be deleted silently; stop and request a user decision unless the user has already supplied an explicit replacement canon.

## Цикл 1728 — Runtime Compatibility lock

- `no caller != delete proof`: отсутствие current caller не является основанием удаления compatibility surface.
- `create_app`, `app.database.get_engine/get_session_factory`, `app.core.decimal_utils.d8` и `order_models.ShopOrder` сохраняются бессрочно как тонкие import/startup/ORM facades и не получают второй runtime.
- `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, `TickContext`, `SchedulerError`, `JobTimeout`, `scheduler_core.tick`, `tasks_maintenance.run_once` — бессрочные compatibility-only surfaces; новый код использует canonical implementation.
- `RBAC.is_superadmin` не является auth-path и может применяться только к уже разрешённому `AdminUser`.
- Подробные комментарии рядом с compatibility-кодом являются частью архитектурного решения и должны читаться до будущего cleanup-аудита.
- Удаление возможно только после отдельного решения пользователя, полного delete-proof и последующего exact-head GitHub CI.
- Active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
## Cycle 1729 — consolidation + alias retirement lock

- Решения 1719–1728 сведены в `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`; новый cleanup из консолидации не выводится автоматически.
- `sql_aliases_core` больше не является transitional resolver: private aliases `core/efhc/efhc-core/admin/efhc-admin/vip_log/vip_status` удалены после delete-proof.
- ENV/provider/wire/history aliases не приравниваются к obsolete runtime aliases и сохраняются без отдельного delete-proof внешних потребителей.
- Бессрочные compatibility surfaces циклов 1726–1728 не являются кандидатами удаления в 1729.
- Следующий цикл 1730 — только exact-head CI qualification/error burn-down; новые функциональные решения запрещены без нового ТЗ.

