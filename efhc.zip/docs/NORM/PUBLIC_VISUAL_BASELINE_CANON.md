# PUBLIC VISUAL BASELINE CANON

Статус: **CANON / ACTIVE**

- Public UI сохраняет утверждённые layout, responsive boundaries и
  accessibility constraints.
- Baseline не повышается и не заменяется только ради прохождения CI.
- Historical visual snapshots не являются текущим каноном и при необходимости хранятся только во внешнем `ARTIFACTS_HISTORY` ZIP.
- Изменение baseline допускается только после подтверждённого изменения UI.
