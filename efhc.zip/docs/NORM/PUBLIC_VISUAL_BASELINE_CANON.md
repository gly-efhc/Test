# PUBLIC VISUAL BASELINE CANON

Статус: **CANON / ACTIVE**

- Public UI сохраняет утверждённые layout, responsive boundaries и
  accessibility constraints.
- Baseline не повышается и не заменяется только ради прохождения CI.
- Historical visual snapshots не являются текущим каноном и при необходимости хранятся только во внешнем `ARTIFACTS_HISTORY` ZIP.
- Изменение baseline допускается только после подтверждённого изменения UI.
## Bottom Navigation fixed-text boundary
The six labels/order are fixed: `Energy`, `Panels`, `Exchange`, `Tasks`, `Referrals`, `Ranks`. Fit workarounds must not relabel/localize/abbreviate/reorder/remove/reroute items, use `scaleX`, split/wrap the fixed-English words, enlarge cells just to permit further text growth, or convert the six-item row to 3×2. Any future Bottom Nav visual mutation requires direct OWNER instruction.

### Universal USER scroll-content boundary
OWNER correction from Cycle0376, implemented by Cycle0377: on every USER page/subpage that has Bottom Nav, the **visible scroll viewport itself** terminates at the top edge of the fixed Bottom Nav. Page content must never become visible behind/under Bottom Nav during scrolling. Production measures the actual fixed nav height with `ResizeObserver` and applies it as the USER main scroll-container bottom reserve; standalone mirrors the same measured reserve on `.unified-pages`. `--efhc-user-bottom-nav-viewport-reserve` is only the safe-area-aware first-paint fallback until measurement. `padding-bottom` and `scroll-padding-bottom` are supplemental final-content clearance, not viewport geometry. Short pages keep that normal final gap. Bottom Nav remains fixed and its labels/order/geometry are frozen. Admin remains outside this USER-only contract.

### Floating Settings gear boundary
Across all USER themes/routes the customization dock is shell-owned and safe-area-aware. Its lower edge remains anchored by `--efhc-user-floating-control-bottom = calc(4.72rem + var(--efhc-safe-bottom))`, immediately above the fixed Bottom Nav. Because Cycle0377 now ends the scroll viewport at the Bottom Nav top edge, `--efhc-user-bottom-nav-boundary = 2.78rem` reserves only the unchanged 2.25rem floating-control height plus 0.53rem clearance **inside** that scroll viewport; the old 7.5rem nav+gear compound padding is obsolete. Production ownership remains `frontend/src/components/Layout.tsx` + `frontend/src/styles/globals.css`; standalone mirrors the same geometry. Route-local/theme-local vertical offsets are forbidden. Gear size/icon/runtime are unchanged. Admin remains outside this USER-only Bottom Nav boundary contract.

## Header balance display
- The balance icon follows the active theme-owned hue.
- The complete numeric Header balance value is always neutral `#f8fafc` in USER themes and Admin; the numeric value must not inherit accent colour or accent glow.
- Header balance display changes must not alter balance arithmetic, D2/D8/D9/D6 precision, wallet/payment semantics or Header geometry/navigation unless separately opened by OWNER.

## Public action hit-area target
- Canonical interactive secondary/non-destructive controls target at least `44×44 CSS px` where the project control family owns the hit area.
- Increasing hit area must not require enlarging the glyph itself or changing already-compliant production geometry.
- Compact repeated controls must preserve 320px no-overflow/no-overlap boundaries.

