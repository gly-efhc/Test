# TASKS_STANDARD

Статус: NORM (технический стандарт фоновых задач).
Якорь SSOT: `docs/SSOT/SSOT_INDEX.md`

Единый стандарт для `asyncio.create_task()` и фоновых циклов.

## MUST

- каждая задача получает понятное имя;
- каждая задача логирует исключение через done-callback;
- `CancelledError` считается нормальным завершением;
- follow-up после фоновой ошибки должен быть виден в логах;
- запрещена тихая смерть фоновой задачи.

## Технический канон

Использовать `app.core.async_tasks.create_logged_task()`.

## Контуры применения

- `backend/run.py`
- `backend/app/bot/states.py`
- scheduler / sync / background rebuild paths

## Граница стандарта

Этот документ описывает именно technical standard для запуска и
сопровождения background tasks. Он не заменяет доменные SSOT по
экономике, выводам или scheduler-политике, но задаёт единый способ
создания и завершения фоновых задач.

## Observability follow-up

For future hardening of background processes, the project prioritizes:

- count of background errors by task name;
- duration of critical background cycles;
- enqueue / retry / soft-fallback counts;
- rebuild snapshot / resync / backfill counts;
- admin critical action counts.

Priority contours: scheduler, sync, TON inbox watcher, ranks snapshot rebuild.


## Scheduler policy absorption

Current scheduler/runtime follow-up also absorbs the former standalone
`SCHEDULER_PLAYBOOK` rules:

- tick every 10 minutes (600 sec) unless a stricter service policy is
  explicitly documented elsewhere;
- time works as a trigger, not as a filter for already unfinished work;
- all unfinished jobs must be considered on each scheduler pass;
- scheduler/background critical loops must use advisory locking where the
  runtime path supports it;
- network integrations require retries and visible follow-up in logs.
