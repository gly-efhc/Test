<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# BROWSER_SHOP_PAYMENT_FLOW_NORM

Статус: NORM
Якорь: browser-shop payment flow / checkout / intent / memo / confirm / antifraud

## Назначение

Единый нормативный документ browser-shop payment flow. Объединяет checkout/status режим, intent/memo contract и watcher/confirm/antifraud правила в один active NORM документ.

## Part 1 — checkout and status



Документ фиксирует нормативный режим внешнего browser-shop checkout и status
screen.

## 2. Общий паттерн

Для browser-shop действует единый checkout pattern:
- package card
- custom EFHC card
- VIP NFT card

Все три класса товаров идут по одному checkout-скелету, а различаются только
товарной и post-payment логикой.

## 3. Корзина запрещена

В MVP browser-shop корзина не используется.

Канон операции:
- один выбранный товар = одна операция
- одна операция = один checkout
- один checkout = один payment intent

## 4. Обязательные данные checkout

Checkout обязан показывать пользователю:
- товар / summary
- выбранный актив (TON / USDT)
- сумму оплаты
- memo
- TTL
- текущий статус

Этих данных должно быть достаточно для backend-проверки и последующей проводки.

## 5. Status screen

Status screen является обязательным отдельным экраном/состоянием.

Минимальные состояния:
- checkout создан
- ждём оплату
- транзакция найдена
- начисление выполнено
- истёк TTL / требуется пересоздание
- ошибка

## 6. Различие текстов по товару

Status screen должен уметь показывать разные тексты:
- EFHC package / custom EFHC: кредитование баланса EFHC
- VIP NFT: создана заявка на ручную выдачу

## 7. Связь с linking

Финальное подтверждение checkout требует Telegram linking.

Если handoff key даёт авто-связку, это предпочтительный путь.
Если авто-связки нет, страница должна иметь видимые controls для синхронизации
Telegram и кошелька.

## Current implemented payment assets

- Browser Shop supports native TON/GRAM and USDT jetton on TON/GRAM.
- USDT uses a real TEP-74 transfer body assembled from server-issued intent metadata.
- The selected asset is fixed in the payment intent and cannot be silently changed after creation.
- Watcher confirmation requires exact receiver, asset, amount, payload, TTL and idempotency match.
- This local implementation status does not claim a real signed TON or USDT network transaction.



## Part 2 — intent and memo contract



Документ фиксирует режим draft checkout, payment intent и memo-based
reconciliation для внешнего browser-shop.

## 2. Модель операции

Канон:
- один товар или одна custom amount = одна операция
- одна операция = один payment intent
- один payment intent = один memo

## 3. Draft checkout

Draft checkout может существовать до Telegram linking.

Он нужен для:
- сохранения выбранной карточки или custom amount
- сохранения выбранного актива
- возврата пользователя в тот же checkout state после linking

Draft checkout не является payment intent и не должен запускать payment flow.

## 4. Payment intent

Payment intent создаётся только после подтверждённого Telegram linking.

Payment intent обязан фиксировать:
- `global_id`
- item code / item type
- mode (`package` / `custom` / `vip_nft`)
- asset (`TON` / `USDT`)
- amount asset
- amount EFHC (где применимо)
- memo
- receiving address context
- pricing snapshot / oracle context
- TTL
- status

## 5. Memo

Memo обязан быть уникальным для каждой операции.

Memo является основным механизмом сопоставления входящего платежа с intent.
Дополнительный контекст сопоставления:
- адрес приёма
- тип актива

## 6. Freeze rule

Pricing snapshot и TON-эквивалент должны фиксироваться внутри intent на время
его TTL.

При истечении TTL intent не должен silently переиспользоваться; требуется
пересоздание/переподтверждение checkout с новым расчётом.


## 7. Неизменяемость memo

Пользователь не должен иметь возможности редактировать, заменять или вручную
вводить memo покупки.

Канон:
- memo формируется сервером;
- memo сохраняется как неизменяемый идентификатор операции;
- UI может только показать memo пользователю для копирования/оплаты;
- клиентский payload не должен содержать редактируемое поле memo.

## Current implemented payment assets

- Browser Shop supports native TON/GRAM and USDT jetton on TON/GRAM.
- USDT uses a real TEP-74 transfer body assembled from server-issued intent metadata.
- The selected asset is fixed in the payment intent and cannot be silently changed after creation.
- Watcher confirmation requires exact receiver, asset, amount, payload, TTL and idempotency match.
- This local implementation status does not claim a real signed TON or USDT network transaction.



## Part 3 — watcher confirm antifraud



Документ фиксирует anti-fraud режим watcher / confirm / business logic для
внешнего browser-shop.

## 2. Базовый принцип

Memo само по себе не даёт права на зачисление.

Кредитование возможно только при полном совпадении с заранее созданной и
разрешённой сервером операцией.

## 3. Разрешённая операция

Разрешённой считается только операция, для которой до on-chain платежа уже
существует серверный purchase signal:
- payment intent
- связанный checkout context
- frozen payment snapshot

## 4. Обязательное условие crediting

Watcher имеет право выполнять crediting только если одновременно выполнены все
условия:
- существует pending/allowed intent
- intent не истёк и не закрыт
- совпадает receiving address
- совпадает asset type
- совпадает memo
- совпадает ожидаемая сумма по intent
- операция ещё не была обработана ранее

## 5. Запрет на credit по свободному приходу

Свободный входящий платёж с мемо, отправленный без site-created intent,
кредитовать запрещено.

Примеры запрета:
- пользователь отправил сумму меньше ожидаемой, но вставил корректное memo
- пользователь скопировал memo чужой операции
- пользователь отправил произвольный платёж после истечения TTL
- хакер пытается подставить memo для ложного credit

Во всех таких случаях watcher должен игнорировать автоматическое зачисление.

## 6. Подтверждение сайтом

Внешний сайт обязан создавать серверный purchase signal до оплаты.

On-chain перевод без такого предсозданного сигнала не является основанием для
crediting даже при наличии memo.

## 7. Business logic after confirmed match

После полного подтверждённого совпадения:
- package/custom EFHC -> кредитование основного баланса
- VIP NFT -> создание manual issue request

## 8. User-facing история

Игнорируемые или мошеннические свободные приходы не должны порождать user-facing
кредит в истории профиля.
