<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# BROWSER_SHOP_PAYMENT_FLOW_NORM

Статус: NORM
Якорь: browser-shop payment flow / checkout / intent / memo / confirm / antifraud

## CURRENT IMPLEMENTATION OVERLAY — cycle 1820 / reconciliation + atomic VIP reservation

- Условие OWNER «selected VIP number checkout только после atomic reservation» выполнено backend implementation: selected number блокируется row-level lock, reservation связывается с `global_id + idempotency_key + ShopOrder + PaymentIntent + expires_at`, а paid claim фиксируется в той же financial flow.
- Browser Shop external TON/USDT creation связывает `PENDING ShopOrder + PaymentIntent + immutable payer/delivery snapshot + reservation` одной root transaction на application boundary.
- Reconciliation остаётся authority: exact native atomic payment, trusted blockchain operation time, reservation/order/intent/idempotency match и затем PAID transition. Поздняя обработка watcher не инвалидирует транзакцию, совершённую до TTL.
- `PaymentIntent != ShopOrder`; `My orders` остаётся paid ShopOrder-only.

## CURRENT OWNER OVERLAY — cycle 1818 / Custom, VIP, Orders and fail-closed rollout

Owner-Decision-Refs: `QA-2026-08-27-FRONTEND248-01..10`.

- `EFHC_PACKAGE_CUSTOM / Обмен EFHCm` is active. Quantity is integer `>=1 EFHCm` and is carried in `custom_efhc_amount_d8`.
- For Custom, `price_ton` / `price_usdt` are D2 rates per `1 EFHCm`; authoritative total is recomputed server-side as `rate × quantity`. For fixed packages the fields remain full-package prices.
- Automatic production prices/defaults are forbidden. Missing Admin price makes the method unavailable; no silent fallback or formula such as `0.30 USDT × quantity` may populate production prices.
- Fixed EFHCm catalog is exactly 15 denominations plus Custom.
- VIP is one operational customer-facing product with TON/USDT/EFHC methods; legacy payment-specific SKU are history/read compatibility only.
- Selected VIP number may be listed/selected for preview, but checkout/payment is fail-closed until server-side atomic reservation guarantees the selected number.
- `My orders` contains paid `ShopOrder` records only. `PaymentIntent` states before confirmed payment belong to a separate history/surface. `PaymentIntent != ShopOrder`.
- Production external TON/USDT payment action remains fail-closed until the complete canonical reconciliation chain is integrated and proven. UI/presentation may be integrated earlier; standalone simulation does not qualify production settlement.

## Назначение

Owner-Decision-Ref: `QA-2026-08-20-FIN3-14`. Shop является внешней отдельной HTML-страницей для покупок, связанной с backend и Admin Panel. Отдельного внутреннего магазина в EFHC application не существует и не проектируется.

Единый нормативный документ browser-shop payment flow. Объединяет checkout/status режим, intent/memo contract и watcher/confirm/antifraud правила в один active NORM документ.

## Part 1 — checkout and status



Документ фиксирует нормативный режим внешнего browser-shop checkout и status
screen.

## 2. Общий паттерн

Для browser-shop действует единый checkout pattern:
- package card
- custom EFHC card
- VIP NFT card

Все три класса товаров идут по одному checkout-скелету, а различаются только
товарной и post-payment логикой.

## 3. Корзина запрещена

В MVP browser-shop корзина не используется.

Канон операции:
- один выбранный товар = одна операция
- одна операция = один checkout
- один checkout = один payment intent

## 4. Обязательные данные checkout

Checkout обязан показывать пользователю:
- товар / summary
- выбранный актив (TON / USDT)
- сумму оплаты
- memo
- TTL
- текущий статус

Этих данных должно быть достаточно для backend-проверки и последующей проводки.

## 5. Status screen

Status screen является обязательным отдельным экраном/состоянием.

Минимальные состояния:
- checkout создан
- ждём оплату
- транзакция найдена
- начисление выполнено
- истёк TTL / требуется пересоздание
- ошибка

## 6. Различие текстов по товару

Status screen должен уметь показывать разные тексты:
- EFHC package / custom EFHC: кредитование баланса EFHC
- VIP NFT: создана заявка на ручную выдачу

## 7. Связь с linking

Финальное подтверждение checkout требует Telegram linking.

Если handoff key даёт авто-связку, это предпочтительный путь.
Если авто-связки нет, страница должна иметь видимые controls для синхронизации
Telegram и кошелька.

## Текущие реализованные payment assets

- Browser Shop поддерживает native TON/GRAM и USDT jetton в сети TON/GRAM.
- Для USDT используется реальный TEP-74 transfer body, собранный из server-issued intent metadata.
- Выбранный asset фиксируется в PaymentIntent и не может незаметно изменяться после создания.
- Watcher confirmation требует точного совпадения receiver, asset, amount, payload, TTL и idempotency.
- Этот локальный implementation status не утверждает наличие реальной подписанной TON/USDT network transaction.



## Part 2 — intent and memo contract



Документ фиксирует режим draft checkout, payment intent и memo-based
reconciliation для внешнего browser-shop.

## 2. Модель операции

Канон:
- один товар = одна операция
- одна операция = один payment intent
- один payment intent = один memo

## 3. Draft checkout

Draft checkout может существовать до Telegram linking.

Он нужен для:
- сохранения выбранной карточки
- сохранения выбранного актива
- возврата пользователя в тот же checkout state после linking

Draft checkout не является payment intent и не должен запускать payment flow.

## 4. Payment intent

Payment intent создаётся только после подтверждённого Telegram linking.

Payment intent обязан фиксировать:
- `global_id`
- item code / item type
- mode (`package` / `custom` / `vip_nft`)
- asset (`TON` / `USDT`)
- amount asset
- amount EFHC (где применимо)
- memo
- receiving address context
- snapshot ручной цены товара на момент создания intent
- TTL
- status

## 5. Memo

Memo обязан быть уникальным для каждой операции.

Memo является основным механизмом сопоставления входящего платежа с intent.
Дополнительный контекст сопоставления:
- адрес приёма
- тип актива

## 6. Ручная цена и freeze rule

Shop не использует ценовой оракул, внешний FX-курс или автоматический пересчёт
TON/USDT. Для каждой товарной карточки администратор независимо задаёт
`price_ton` и/или `price_usdt`. Эта ручная цена является runtime authority для
соответствующего способа оплаты.

При создании intent выбранная ручная цена товара фиксируется на весь TTL intent.
Последующее изменение цены карточки влияет только на новые intent и не
пересчитывает уже созданный intent. Если `price_ton` или `price_usdt` не задана,
соответствующий способ оплаты для этой карточки недоступен.

При истечении TTL intent не должен silently переиспользоваться; требуется
создание нового intent по текущей ручной цене карточки.


### D2 boundary ручной внешней цены Shop

Owner-Decision-Refs: `QA-2026-08-19-FIN3-13`, `QA-2026-08-20-FIN3-14`, `QA-2026-08-20-FIN3-15`.

- Admin manual `price_ton` / `price_usdt` имеют максимум D2.
- `1.23 TON` и `4.56 USDT` валидны; `1.234 TON` / `4.567 USDT` отклоняются.
- Backend rejects precision >D2; silent rounding запрещён.
- Frontend editor/create flow блокирует >D2 как UX guard; direct HTTP bypass всё равно отклоняется backend.
- PaymentIntent не округляет Shop price до D2: он получает уже валидированную D2 price и фиксирует её native atomic representation.
- D2 Shop не меняет native execution precision TON 9 / USDT 6 и не превращает TON/USDT в EFHC accounting.
- `price = 0.00`: товар остаётся доступным/видимым, но кнопка/действие покупки деактивировано; backend не создаёт бесплатный order/intent. Negative price запрещён.

## 7. Неизменяемость memo

Пользователь не должен иметь возможности редактировать, заменять или вручную
вводить memo покупки.

Канон:
- memo формируется сервером;
- memo сохраняется как неизменяемый идентификатор операции;
- UI может только показать memo пользователю для копирования/оплаты;
- клиентский payload не должен содержать редактируемое поле memo.

## Текущие реализованные payment assets

- Browser Shop поддерживает native TON/GRAM и USDT jetton в сети TON/GRAM.
- Для USDT используется реальный TEP-74 transfer body, собранный из server-issued intent metadata.
- Выбранный asset фиксируется в PaymentIntent и не может незаметно изменяться после создания.
- Watcher confirmation требует точного совпадения receiver, asset, amount, payload, TTL и idempotency.
- Этот локальный implementation status не утверждает наличие реальной подписанной TON/USDT network transaction.



## Часть 3 — watcher confirm anti-fraud



Документ фиксирует anti-fraud режим watcher / confirm / business logic для
внешнего browser-shop.

## 2. Базовый принцип

Memo само по себе не даёт права на зачисление.

Кредитование возможно только при полном совпадении с заранее созданной и
разрешённой сервером операцией.

## 3. Разрешённая операция

Разрешённой считается только операция, для которой до on-chain платежа уже
существует серверный purchase signal:
- payment intent
- связанный checkout context
- замороженный payment snapshot

## 4. Обязательное условие crediting

Watcher имеет право выполнять crediting только если одновременно выполнены все
условия:
- существует pending/allowed intent
- intent не истёк и не закрыт
- совпадает receiving address
- совпадает asset type
- совпадает memo
- совпадает ожидаемая сумма по intent
- операция ещё не была обработана ранее

## 5. Запрет на credit по свободному приходу

Свободный входящий платёж с мемо, отправленный без site-created intent,
кредитовать запрещено.

Примеры запрета:
- пользователь отправил сумму меньше ожидаемой, но вставил корректное memo
- пользователь скопировал memo чужой операции
- пользователь отправил произвольный платёж после истечения TTL
- хакер пытается подставить memo для ложного credit

Во всех таких случаях watcher должен игнорировать автоматическое зачисление.

## 6. Подтверждение сайтом

Внешний сайт обязан создавать серверный purchase signal до оплаты.

On-chain перевод без такого предсозданного сигнала не является основанием для
crediting даже при наличии memo.

## 7. Business logic после подтверждённого match

После полного подтверждённого совпадения:
- package/custom EFHC → кредитование основного баланса
- VIP NFT → создание manual issue request

## 8. User-facing история

Игнорируемые или мошеннические свободные приходы не должны порождать user-facing
кредит в истории профиля.

## Cycle 1794 — atomic settlement и zero-price fail-closed

OWNER decision refs: `QA-2026-08-19-FIN3-09`, `FIN3-11`, `FIN3-12`.

- TON/USDT external amount не является EFHC D8.
- TON payment сравнивается в nanotons; USDT — в integer token units `10^6`.
- Client получает server-issued `external_amount_atomic`/`external_decimals` и не может подменить manual catalog price.
- `price <= 0` = method unavailable; backend является финальной authority запрета, frontend disable — обязательный UX guard.
- `price_ton`/`price_usdt` остаются независимыми ручными Admin ценами карточки.
- Oracle/FX/CUSTOM_EFHC fixed-rate pricing запрещены и не восстанавливаются.
