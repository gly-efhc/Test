# ADMIN_SYSTEM_HEALTH_DASHBOARD.md

**Цикл:** 1489 — Admin System Health Dashboard

`/admin/system` получил read-only System Health Dashboard для API, DB, schema guard и watcher heartbeat. Источники: `GET /health`, `GET /health/db`, `GET /health/runtime`. Запрещены write methods, idempotency key creation, env/secrets/raw payload/debug JSON, fake time-series, frontend workaround hiding backend defect. Песочница/Grafana reference only.
