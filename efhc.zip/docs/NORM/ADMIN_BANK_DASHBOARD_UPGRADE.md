# ADMIN_BANK_DASHBOARD_UPGRADE

**Project:** EFHC Bot  
**Cycle:** 1483 — Admin Bank Dashboard Upgrade  
**Archive:** v170.59  
**Status:** ACTIVE / DONE LOCALLY  
**Layer:** Admin Dashboard Layer  
**Mode:** runtime UI-only / read-only bank dashboard

## 1. Purpose

Cycle 1483 upgrades `/admin/bank` into an operator dashboard for the EFHC
banking contour.

The page must help the operator see bank balance, user balances, bank/users
reconciliation, panel flow, recent ledger rows and action safety boundaries
without changing the money logic.

## 2. Runtime component

```text
frontend/src/components/admin/AdminBankDashboardRuntime.tsx
```

The component is integrated into:

```text
frontend/src/pages/admin/bank.tsx
```

## 3. Data model

Truth model:

```text
raw + derived snapshot
```

Sources:

```text
GET /admin/bank/balance
GET /admin/reports/overview
GET /admin/logs/transfers?limit=12
```

The dashboard does not claim real time-series and does not generate fake
history from one snapshot.

## 4. What the dashboard shows

The upgraded Bank dashboard shows:

- bank actor and `EFHC_MAIN` balance;
- user total EFHC balance;
- bank/users reconciliation result;
- derived bank/users/panels/diff chart display;
- canonical flow map;
- operation safety status;
- recent ledger timeline;
- bank safety boundary.

## 5. BANK_CANON boundary

The dashboard repeats the bank canon:

- bank key: `EFHC_MAIN`;
- bank can go negative;
- user balances cannot go negative;
- `user credit ⇒ bank debit`;
- `user debit ⇒ bank credit`;
- no manual SQL money update;
- no dashboard write bypass.

## 6. Safety boundaries

The Bank dashboard is read-only. It must not:

- call write APIs;
- create idempotency keys;
- mutate bank balance;
- change mint/burn/reset logic;
- change ledger logic;
- change backend routes;
- change OpenAPI;
- show secrets;
- show raw payload dumps;
- show debug JSON;
- claim real time-series.

The existing mint/burn actions remain in their guarded confirmation area.
They are not moved into the dashboard component.

## 7. Grafana / Песочница boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## 8. Acceptance result

- `/admin/bank` has a read-only dashboard surface.
- The dashboard uses raw + derived snapshot only.
- Bank negative balance canon is visible.
- Ledger and action boundaries are visible.
- Mint/burn confirmation flow remains separate.
- Economy, backend, OpenAPI, dependencies, lock files and write flows are
  not changed.


Runtime code is not copied.
