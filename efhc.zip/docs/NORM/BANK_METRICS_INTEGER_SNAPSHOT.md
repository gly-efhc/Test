# Admin → Банк: полный канон формул и integer snapshot

**Статус:** ACTIVE CANON / NORM / OWNER-APPROVED  
**Формульная authority:** `docs/NORM/BANK_METRICS_INTEGER_SNAPSHOT.md`  
**Связанный финансовый SSOT:** `docs/SSOT/BANK_CANON.md`, `docs/SSOT/ECONOMY_CANON.md`  
**Frontend authority:** `docs/frontend/EFHC_FRONTEND_OWNER_QA_v182.md`  
**Текущая реализация:** `backend/app/services/bank_metrics_snapshot_service.py`, `frontend/src/pages/admin/bank.tsx`  
**Canonical table:** `efhc_core.bank_metrics_snapshot`, singleton `id = 1`

## 1. Назначение документа

Этот документ является полным формульным каноном страницы **Admin → Банк**. Он фиксирует:

- исходные canonical данные, из которых backend строит Bank snapshot;
- все 11 строк `Балансовой карты`;
- блок `Целостность системы`;
- `expected_supply`, `integrity_delta` и служебные derived metrics;
- базы процентов для каждой строки;
- D8 representation, нормализацию, округление и zero-denominator semantics;
- правила protective-voided Panels;
- границу ответственности DB/backend/frontend;
- fail-closed поведение при отсутствии snapshot.

При конфликте с историческими описаниями формул приоритет имеет более позднее прямое OWNER DECISION, затем этот active CANON/NORM и связанные active SSOT.

## 2. Главный архитектурный принцип

Финансовая математика страницы Admin → Банк выполняется **только server-side**.

```text
canonical DB sources
        ↓
backend source aggregation
        ↓
integer D8 calculation
        ↓
efhc_core.bank_metrics_snapshot (id = 1)
        ↓
/admin/reports/overview → facts.bank_metrics_*
        ↓
frontend: только отображение и UI-formatting
```

Frontend не имеет права:

- пересчитывать Bank formulas из raw ledger rows;
- реконструировать показатели из capped списков;
- использовать JS `Number` как authority для EFHC/EFHCm/EFHCb/kWh;
- строить browser fallback finance при отсутствии snapshot;
- заменять server-side процент собственной финансовой формулой.

`efhc_core.bank_metrics_snapshot` является единственной read authority готовых показателей Admin Bank, но **не заменяет** первичные BANK/user/Panel/ledger tables как источник финансовых фактов.

## 3. Что именно решила специальная таблица `bank_metrics_snapshot`

Таблица была введена по прямому OWNER DECISION для устранения класса проблем, при котором frontend мог расходиться с backend из-за повторного вычисления формул, ограниченных выборок или floating-point arithmetic.

Она решает это следующим образом:

1. Все Bank amounts, energy metrics и проценты рассчитываются backend.
2. Готовые результаты материализуются в одной singleton row `id = 1`.
3. Frontend читает уже рассчитанные значения.
4. При отсутствии/ошибке refresh frontend fail closed.
5. Формулы и denominator semantics централизованы в одном backend calculation contour.

Важно: таблица **не меняет математическое определение показателей сама по себе**. Она хранит результат действующих формул. Поэтому текущие semantics отрицательных derived values и zero denominator определяются backend-калькулятором и отражаются в snapshot без browser-side исправлений.

## 4. Числовая модель

### 4.1. D8 amounts и energy

Все materialized monetary и kWh значения snapshot хранятся как signed `BIGINT × 10^8`.

```text
D8_SCALE = 100_000_000
1.00000000 EFHC = 100_000_000
1.00000000 kWh  = 100_000_000
```

### 4.2. D8 percentages

Процент хранится как signed percentage `BIGINT × 10^8`.

```text
PCT_SCALE = 100_000_000
1%   = 100_000_000
5%   = 500_000_000
100% = 10_000_000_000
```

### 4.3. Фиксированные константы

```text
INITIAL_SUPPLY = 5 000 000.00000000 EFHC
PANEL_PRICE    =       100.00000000 EFHC
```

### 4.4. Размерностное правило kWh → EFHCm

Действующий economy canon фиксирует:

```text
1 kWh = 1 EFHCm
```

Поэтому Panel-generated kWh в формулах обязательств используется как численно эквивалентная EFHCm-величина D8. Это не FX/oracle conversion и не меняет единицу исходного energy counter; это фиксированный внутренний economic rate.

## 5. Нормализация canonical source values в D8

Source SQL агрегирует canonical `NUMERIC` значения, после чего переводит их в integer D8:

```text
D8(x) = trunc(x × 100_000_000)
```

В calculation contour не используется `float`.

Для отдельных входов дополнительно действует non-negative normalization:

```text
panel_spent = max(0, source_panel_spent)
generated   = max(0, source_generated)
converted   = max(0, source_converted)
fixed_population = max(0, source_fixed_population)
```

`reserve`, `users_main`, `users_bonus`, `fixed_generated`, `minted`, `burned` остаются signed согласно полученному canonical source value.

## 6. Canonical source variables

Ниже `Σ` означает server-side aggregate по canonical DB sources.

### 6.1. `reserve`

Источник:

```text
efhc_core.bank_balance
key = 'EFHC_MAIN'
```

Фактическая source aggregation:

```text
reserve = max(balance where key = 'EFHC_MAIN')
```

Поскольку `key` является primary key, canonical row одна. Баланс Банка может быть отрицательным согласно `BANK_CANON`.

### 6.2. `users_main`

```text
users_main = Σ efhc_core.users.main_balance
```

Это суммарный пользовательский `EFHCm`.

### 6.3. `users_bonus`

```text
users_bonus = Σ efhc_core.users.bonus_balance
```

Это суммарный пользовательский `EFHCb`.

### 6.4. `converted`

```text
converted = Σ efhc_core.users.exchanged_kwh_total
```

Это lifetime/current canonical aggregate уже обменянной энергии после действующих корректировок protective lifecycle. На Bank page он отображается как `Обмен kWh → EFHCm`; при фиксированном курсе `1 kWh = 1 EFHCm` числовое значение D8 совпадает с полученным EFHCm.

### 6.5. `generated`

Источник — `efhc_core.panels.generated_kwh`.

В aggregate входят только Панели, для которых:

```text
coalesce(meta ->> 'protectively_voided', 'false') <> 'true'
```

Формула:

```text
generated = Σ generated_kwh всех не protectively_voided Panels
```

Protectively voided Panel полностью исключается из текущего Panel-derived generated aggregate.

### 6.6. `fixed_generated`

Из того же множества не protectively-voided Panels:

```text
fixed_generated = Σ generated_kwh
                  where (not is_active OR is_archived)
```

### 6.7. `fixed_population`

```text
fixed_population = COUNT(Panels)
                   where (not is_active OR is_archived)
                   and protectively_voided != true
```

### 6.8. `activation_spent`

Источник — `efhc_core.efhc_transfers_log`.

В сумму включаются `amount` пользовательских debit операций с reason:

```text
panel_purchase
panel_activation
panel_reactivation
```

и условием:

```text
direction = 'debit'
```

Формула:

```text
activation_spent = Σ amount таких debit операций
```

### 6.9. `voided_spent`

Для каждого canonical Panel protective event:

```text
event.op = 'protective_deactivate'
```

берётся historical payment split:

```text
original_payment_bonus
original_payment_main
```

Формула:

```text
voided_spent = Σ(original_payment_bonus + original_payment_main)
```

### 6.10. `panel_spent`

Source-level:

```text
source_panel_spent = activation_spent - voided_spent
```

Calculation-level:

```text
panel_spent = max(0, source_panel_spent)
```

Это означает, что каждый protective-deactivate event полностью сторнирует historical Panel spend соответствующего lifecycle на исходный payment split `B + M = 100 EFHC`.

Фактический NET refund `100 - R`, проведённый через BANK ledger, не подменяет эту Panel analytical metric. Ledger history остаётся неизменяемой; current Panel analytics и financial ledger history не смешиваются.

### 6.11. `minted`

```text
minted = Σ efhc_core.efhc_transfers_log.amount
         where system_entity = 'BANK_EFHC'
         and reason = 'admin_bank_mint'
```

### 6.12. `burned`

```text
burned = Σ efhc_core.efhc_transfers_log.amount
         where system_entity = 'BANK_EFHC'
         and reason = 'admin_bank_burn'
```

Mint/Burn — emergency mechanisms и не являются обычным пользовательским money flow.

## 7. Базовые derived values

### 7.1. `circulation`

```text
circulation = users_main + users_bonus
```

UI label:

```text
Весь оборот
```

### 7.2. `actual_mass`

```text
actual_mass = reserve + circulation
```

То есть:

```text
actual_mass = reserve + users_main + users_bonus
```

UI label:

```text
Общая масса
```

### 7.3. `expected_supply`

```text
expected_supply = INITIAL_SUPPLY + minted - burned
```

или:

```text
expected_supply = 5 000 000 EFHC + admin_bank_mint - admin_bank_burn
```

Это canonical denominator блока целостности. Запрещено автоматически заменять его на `reserve + circulation`, потому что такая нормализация скрыла бы supply mismatch.

### 7.4. `integrity_delta`

```text
integrity_delta = actual_mass - expected_supply
```

Эквивалентно:

```text
integrity_delta = reserve + circulation - expected_supply
```

Canonical integrity condition:

```text
integrity_ok ⇔ integrity_delta == 0
```

Проверка выполняется по exact integer D8, а не по округлённому UI-проценту.

## 8. Полный канон 11 строк Балансовой карты

### Строка 1. `Резерв Банка`

Amount:

```text
reserve
```

Процент:

```text
reserve_pct = reserve / expected_supply × 100
```

Canonical snapshot fields:

```text
reserve_efhc_d8
reserve_pct_d8
```

UI unit: `EFHC`.

### Строка 2. `Весь оборот`

Amount:

```text
circulation = users_main + users_bonus
```

Процент:

```text
circulation_pct = circulation / expected_supply × 100
```

Canonical snapshot fields:

```text
circulation_efhc_d8
circulation_pct_d8
```

UI unit: `EFHC`.

### Строка 3. `Новые обязательства`

Amount:

```text
new_obligations = generated - panel_spent
```

Panel spend всегда подаётся в формулу как положительная величина расхода.

OWNER-проверка знака:

```text
generated = 150
panel_spent = 100
new_obligations = 150 - 100 = 50
```

Запрещён double-negative результат `250`.

Процент:

```text
new_obligations_pct = new_obligations / actual_mass × 100
```

Так как:

```text
actual_mass = reserve + circulation
```

это соответствует owner formula:

```text
Новые обязательства / (Резерв Банка + Весь оборот) × 100
```

Процент показывает только excess/new-obligations share. Если новые обязательства составляют 5% базы, отображается `5%`, не `105%`.

Canonical snapshot fields:

```text
new_obligations_efhcm_d8
new_obligations_pct_d8
```

UI unit: `EFHCm`.

### Строка 4. `EFHCm пользователей`

Amount:

```text
users_main
```

Процент:

```text
users_main_pct = users_main / expected_supply × 100
```

Canonical snapshot fields:

```text
users_main_efhc_d8
users_main_pct_d8
```

UI unit: `EFHCm`.

### Строка 5. `EFHCb пользователей`

Amount:

```text
users_bonus
```

Процент:

```text
users_bonus_pct = users_bonus / expected_supply × 100
```

Canonical snapshot fields:

```text
users_bonus_efhc_d8
users_bonus_pct_d8
```

UI unit: `EFHCb`.

### Строка 6. `Общая масса`

Amount:

```text
actual_mass = reserve + circulation
```

Процент:

```text
actual_mass_pct = actual_mass / expected_supply × 100
```

Canonical snapshot fields:

```text
actual_mass_efhc_d8
actual_mass_pct_d8
```

UI unit: `EFHC`.

При исправной supply integrity этот процент exact равен `100%`.

### Строка 7. `Зафиксированные обязательства`

Amount:

```text
fixed_obligations = fixed_generated - fixed_population × PANEL_PRICE
```

то есть:

```text
fixed_obligations = Σ generated_kwh деактивированных/архивных
                    не protectively-voided Panels
                    - 100 EFHC × количество таких Panels
```

При фиксированном курсе `1 kWh = 1 EFHCm` результат трактуется как EFHCm obligation metric.

Процент:

```text
fixed_obligations_pct = fixed_obligations / expected_supply × 100
```

Canonical snapshot fields:

```text
fixed_obligations_efhcm_d8
fixed_obligations_pct_d8
```

UI unit: `EFHCm`.

#### Signed semantics

Текущая canonical implementation **не применяет** `max(0, fixed_obligations)`.

Следовательно, если:

```text
fixed_generated < fixed_population × 100
```

то `fixed_obligations` является отрицательным signed D8 значением и таким же signed значением материализуется в snapshot. В таблице отсутствует non-negative constraint для `fixed_obligations_efhcm_d8`.

Специальная snapshot-таблица устраняет browser-side расхождение формул, но не преобразует отрицательный результат в ноль.

Protectively voided Panels в `fixed_generated` и `fixed_population` не входят, поэтому protective void не создаёт искусственное `−100` в этой метрике.

### Строка 8. `Потрачено EFHCm + EFHCb на все панели`

Amount:

```text
panel_spent = max(0, activation_spent - voided_spent)
```

Процент:

```text
panel_spent_pct = panel_spent / users_main × 100
```

То есть denominator по прямому OWNER decision — **только `EFHCm пользователей`**, а не весь circulation и не expected supply.

Canonical snapshot fields:

```text
panel_spent_efhc_d8
panel_spent_pct_d8
```

UI unit: `EFHC`.

### Строка 9. `Сгенерировано kWh`

Amount:

```text
generated = Σ generated_kwh всех не protectively-voided Panels
```

Процент:

```text
generated_pct = generated / actual_mass × 100
```

`actual_mass = reserve + circulation` является текущей pre-emission денежной базой для этого показателя по FRONTEND_v182.

Canonical snapshot fields:

```text
generated_kwh_d8
generated_pct_d8
```

UI unit: `kWh`.

### Строка 10. `Обмен kWh → EFHCm`

Amount:

```text
converted = Σ users.exchanged_kwh_total
```

При rate `1 kWh = 1 EFHCm` frontend показывает числовой результат в `EFHCm`.

Процент:

```text
converted_pct = converted / generated × 100
```

Canonical snapshot fields:

```text
converted_kwh_d8
converted_pct_d8
```

UI unit: `EFHCm`.

### Строка 11. `В ожидании kWh → EFHCm`

Amount:

```text
pending = generated - converted
```

Процент:

```text
pending_pct = pending / generated × 100
```

Canonical snapshot fields:

```text
pending_kwh_d8
pending_pct_d8
```

UI unit: `kWh`.

`pending` остаётся signed derived value. Если canonical source state когда-либо даст `converted > generated`, snapshot не скрывает это через `max(0)`; отрицательное значение является observable inconsistency signal.

## 9. Блок `Целостность системы`

Блок не является самостоятельной второй математикой. Он отображает значения того же snapshot.

### 9.1. Левая часть

```text
Резерв Банка = reserve
reserve_pct = reserve / expected_supply × 100
```

### 9.2. Правая часть

```text
В обороте = circulation
circulation_pct = circulation / expected_supply × 100
```

### 9.3. Итого

```text
integrity_pct = actual_mass / expected_supply × 100
```

где:

```text
actual_mass = reserve + circulation
```

### 9.4. Exact integrity status

```text
integrity_ok = 1, если integrity_delta == 0
integrity_ok = 0, если integrity_delta != 0
```

При `integrity_ok = 1` frontend показывает `✓ 100%`.

При отклонении frontend показывает реальный server-side `integrity_pct` и detail:

```text
Отклонение = integrity_delta EFHC
```

Delta не является отдельной строкой Балансовой карты.

## 10. Полный реестр процентных denominators

| Показатель | Numerator | Denominator |
|---|---|---|
| Резерв Банка | `reserve` | `expected_supply` |
| Весь оборот | `circulation` | `expected_supply` |
| Новые обязательства | `new_obligations` | `actual_mass = reserve + circulation` |
| EFHCm пользователей | `users_main` | `expected_supply` |
| EFHCb пользователей | `users_bonus` | `expected_supply` |
| Общая масса | `actual_mass` | `expected_supply` |
| Зафиксированные обязательства | `fixed_obligations` | `expected_supply` |
| Потрачено на все панели | `panel_spent` | `users_main` |
| Сгенерировано kWh | `generated` | `actual_mass = reserve + circulation` |
| Обмен kWh → EFHCm | `converted` | `generated` |
| В ожидании kWh → EFHCm | `pending` | `generated` |
| Целостность системы | `actual_mass` | `expected_supply` |

## 11. Canonical percentage algorithm

Backend использует только integer arithmetic.

Для `denominator != 0`:

```text
negative = sign(numerator) XOR sign(denominator)
n = abs(numerator)
d = abs(denominator)

pct_d8 = floor((n × 100 × PCT_SCALE + floor(d / 2)) / d)
```

После этого возвращается отрицательный знак, если `negative = true`.

Это соответствует **half-up rounding** абсолютной величины до percentage D8.

### 11.1. Zero denominator

Текущая canonical implementation:

```text
if denominator == 0:
    percentage = 0.00000000%
```

То есть отсутствие denominator не приводит к browser-side делению, `NaN`, `Infinity` или fallback formula. Backend материализует `0%`.

Специальная snapshot-таблица централизует это правило, но сама по себе не создаёт состояние `N/A`. В текущем production contour canonical result при denominator `0` — `0.00000000%`.

## 12. Табличные constraints и signed values

`efhc_core.bank_metrics_snapshot` имеет обязательные non-negative constraints только для:

```text
panel_spent_efhc_d8 >= 0
generated_kwh_d8   >= 0
converted_kwh_d8   >= 0
```

Также действует singleton constraint:

```text
id = 1
```

Следующие derived fields intentionally способны хранить signed результат и не имеют non-negative DB constraint:

```text
reserve_efhc_d8
new_obligations_efhcm_d8
fixed_obligations_efhcm_d8
pending_kwh_d8
expected_supply_efhc_d8
integrity_delta_efhc_d8
все percentage *_pct_d8
```

Это важно для observability: snapshot не обязан скрывать математическое отклонение принудительным clamp, если такой clamp не установлен OWNER CANON.

## 13. Protective Panel semantics в Bank formulas

Protective Admin deactivation не является обычным Panel lifecycle.

Для Bank snapshot действуют два разных механизма.

### 13.1. Panel-row aggregates

Panel с:

```text
meta.protectively_voided = true
```

не участвует в:

```text
generated
fixed_generated
fixed_population
```

Следовательно, она не участвует в текущих `generated`, `fixed_obligations` и связанных процентах.

### 13.2. `panel_spent`

Historical activation/reactivation debit не удаляется из immutable BANK ledger.

В Panel analytics он компенсируется отдельно:

```text
panel_spent = activation_spent - Σ original historical B/M split protective events
```

После non-negative normalization:

```text
panel_spent = max(0, ...)
```

Таким образом dead lifecycle даёт `0` Panel spend aggregate, но реальные BANK transfer operations, включая фактический NET refund, остаются исторической финансовой evidence.

## 14. Snapshot persistence

После calculation backend выполняет UPSERT singleton row:

```text
INSERT ... id = 1
ON CONFLICT (id) DO UPDATE
```

В той же записи материализуются:

- 13 amount/energy/derived fields;
- 12 percentage fields;
- `updated_at`.

`updated_at` устанавливается server-side UTC.

`refresh_bank_metrics_snapshot(db)` transaction-neutral: helper не делает скрытый `commit()` или `rollback()`.

Root transaction принадлежит route/application boundary. Текущий `/admin/reports/overview` после успешного refresh делает commit, а при исключении — rollback.

## 15. Snapshot → API facts

Backend отдаёт frontend готовые decimal strings без float.

Основные mappings:

```text
reserve_efhc_d8              → bank_metrics_reserve_efhc
circulation_efhc_d8          → bank_metrics_circulation_efhc
users_main_efhc_d8           → bank_metrics_users_main_efhc
users_bonus_efhc_d8          → bank_metrics_users_bonus_efhc
actual_mass_efhc_d8          → bank_metrics_actual_mass_efhc
panel_spent_efhc_d8          → bank_metrics_panel_spent_efhc
generated_kwh_d8             → bank_metrics_generated_kwh
new_obligations_efhcm_d8     → bank_metrics_new_obligations_efhcm
fixed_obligations_efhcm_d8   → bank_metrics_fixed_obligations_efhcm
converted_kwh_d8             → bank_metrics_converted_kwh
pending_kwh_d8               → bank_metrics_pending_kwh
expected_supply_efhc_d8      → bank_metrics_expected_supply_efhc
integrity_delta_efhc_d8      → bank_metrics_integrity_delta_efhc
```

Percent fields аналогично отдаются как `bank_metrics_*_pct` decimal strings.

Дополнительно:

```text
bank_metrics_ready = "1"
bank_metrics_integrity_ok = "1" iff integrity_delta == 0
bank_metrics_updated_at = snapshot.updated_at UTC ISO
```

## 16. Fail-closed contract

Если snapshot отсутствует или refresh не может быть выполнен корректно:

```text
bank_metrics_ready != "1"
```

Admin Bank frontend не строит альтернативную формулу и не показывает reconstructed production finance. Страница переходит в error state.

Это обязательный OWNER contract.

## 17. Frontend formatting: что является формулой, а что нет

FRONTEND_v182 не выполняет финансовую математику Bank.

### 17.1. Amount display

Server присылает exact D8 decimal string. Для human-facing Bank rows текущий UI вызывает `formatD8ToHuman(..., 2)`, то есть визуально показывает 2 decimal digits через decimal-string truncation/down-formatting.

Это **только presentation formatting**. Snapshot и API остаются D8.

### 17.2. Percent text в строках карты

Snapshot percentage приходит в D8. UI переводит его в видимый процент с 2 decimal digits и half-up display rounding.

Пример:

```text
12.34567890% → 12.35%
```

Это не пересчёт denominator и не новая финансовая формула.

### 17.3. Integrity total

Для `Целостность системы` frontend использует server-side `integrity_pct`, отображает до 8 decimals и удаляет незначащие trailing zeros.

Exact green/error status определяется не строкой процента, а `bank_metrics_integrity_ok`, который backend строит из exact `integrity_delta == 0`.

### 17.4. Bar width

Визуальная длина индикатора:

```text
width = min(abs(server_percentage), 100%)
```

Это только UI geometry. Знак и реальное значение остаются в текстовом percentage. Bar clamp не меняет snapshot metric.

## 18. Примеры canonical calculation

### 18.1. Нормальная целостность и новые обязательства

Пусть:

```text
reserve        = 400 EFHC
users_main     = 500 EFHCm
users_bonus    = 100 EFHCb
panel_spent    = 100 EFHC
generated      = 150 kWh
converted      = 60 kWh
fixed_generated = 250 kWh
fixed_population = 2
expected_supply = 1 000 EFHC
```

Тогда:

```text
circulation = 500 + 100 = 600 EFHC
actual_mass = 400 + 600 = 1 000 EFHC
new_obligations = 150 - 100 = 50 EFHCm
fixed_obligations = 250 - 2×100 = 50 EFHCm
pending = 150 - 60 = 90 kWh
integrity_delta = 1 000 - 1 000 = 0 EFHC
```

Проценты:

```text
reserve             = 40%
circulation         = 60%
new_obligations     = 5%
users_main          = 50%
users_bonus         = 10%
actual_mass         = 100%
fixed_obligations   = 5%
panel_spent         = 100 / 500 = 20%
generated           = 150 / 1000 = 15%
converted           = 60 / 150 = 40%
pending             = 90 / 150 = 60%
integrity           = 100%
```

### 18.2. Отрицательные `Зафиксированные обязательства`

Пусть:

```text
fixed_generated = 150 kWh
fixed_population = 2
```

Тогда:

```text
fixed_obligations = 150 - 2×100 = -50 EFHCm
```

Текущий canonical backend не clamp-ит результат к нулю. Snapshot способен хранить `-50.00000000`.

### 18.3. Zero denominator

Пусть:

```text
generated = 0
converted = 0
pending = 0
```

Для:

```text
converted_pct = converted / generated
pending_pct = pending / generated
```

backend применяет canonical zero-denominator rule:

```text
converted_pct = 0.00000000%
pending_pct = 0.00000000%
```

Browser не выполняет division самостоятельно.

### 18.4. Supply mismatch

Пусть:

```text
expected_supply = 1 000 EFHC
reserve = 401 EFHC
circulation = 600 EFHC
actual_mass = 1 001 EFHC
```

Тогда:

```text
integrity_delta = +1 EFHC
integrity_pct = 100.1%
integrity_ok = 0
```

Frontend должен показать alarm, а не перенормировать denominator на `1 001` и не скрыть ошибку как `100%`.

## 19. Полный canonical snapshot surface

### Amount / energy / derived BIGINT D8

```text
reserve_efhc_d8
circulation_efhc_d8
users_main_efhc_d8
users_bonus_efhc_d8
actual_mass_efhc_d8
panel_spent_efhc_d8
generated_kwh_d8
new_obligations_efhcm_d8
fixed_obligations_efhcm_d8
converted_kwh_d8
pending_kwh_d8
expected_supply_efhc_d8
integrity_delta_efhc_d8
```

### Percentage BIGINT D8

```text
reserve_pct_d8
circulation_pct_d8
new_obligations_pct_d8
users_main_pct_d8
users_bonus_pct_d8
actual_mass_pct_d8
fixed_obligations_pct_d8
panel_spent_pct_d8
generated_pct_d8
converted_pct_d8
pending_pct_d8
integrity_pct_d8
```

### Technical fields

```text
id = 1
updated_at
```

## 20. Канонические запреты

Запрещено:

1. Считать эти формулы повторно в frontend.
2. Использовать browser raw lists как замену snapshot.
3. Использовать floating-point authority для D8 financial/energy values.
4. Нормализовать integrity denominator на `reserve + circulation`.
5. Превращать `new_obligations_pct` в `100% + excess`.
6. Выполнять double-negative `generated - (-panel_spent)`.
7. Возвращать protectively voided Panel в generated/fixed aggregates.
8. Считать фактический protective NET refund заменой analytical `panel_spent` reversal.
9. Самовольно clamp-ить signed derived metrics, для которых OWNER CANON не установил clamp.
10. Самовольно заменять zero-denominator `0%` на `N/A`, `Infinity`, ошибку или browser fallback без нового OWNER DECISION.
11. Создавать вторую Bank formula authority параллельно `bank_metrics_snapshot`.

## 21. Authority и изменение формул

Любое изменение:

- amount formula;
- percentage numerator;
- percentage denominator;
- clamp semantics;
- zero-denominator semantics;
- Panel inclusion/exclusion rule;
- `INITIAL_SUPPLY`;
- `PANEL_PRICE`;
- exchange dimensional rule `1 kWh = 1 EFHCm`;
- rounding rule;

является изменением финансового CANON и требует прямого OWNER DECISION.

После изменения CANON в той же итерации должны быть синхронизированы backend calculation, snapshot fields/DB contract при необходимости, frontend rendering contract и stale tests/guards. Правильный production invariant не меняется ради старого implementation-shape test.

## 22. Проверенная реализация physical HEAD v174.63

На physical HEAD `v174.63` статически подтверждено:

- singleton ORM model `BankMetricsSnapshot` существует;
- frozen `0001_initial_release_schema.py` содержит `efhc_core.bank_metrics_snapshot`;
- owner-supplied `URGENT_BANK_METRICS_SNAPSHOT.sql` создаёт тот же singleton surface для existing DB;
- backend source aggregation и все формулы находятся в `bank_metrics_snapshot_service.py`;
- `/admin/reports/overview` refresh-ит snapshot и отдаёт `bank_metrics_*` facts;
- frontend `/admin/bank` требует `bank_metrics_ready == "1"` и fail closed при отсутствии snapshot;
- frontend отображает 11 canonical строк в owner-approved порядке;
- frontend не пересчитывает financial denominators и использует server-side percentage facts.

Этот раздел фиксирует проверенное состояние текущего HEAD, а не обещание о будущих версиях.
