# Политика трёх рабочих архивов EFHC

Статус: активная норма с цикла `1608`.

## 1. Development Current HEAD

Содержит code, frontend/backend, migrations, tests, SSOT/NORM,
канонические Markdown-отчёты, machine summaries, receipts и SHA-256
manifests. Не содержит исторические подробные XLSX, JUnit/XML и
многомегабайтные raw-матрицы, уже вынесенные в matrix/technical archive.

## 2. Release archive

Содержит только production-необходимые файлы. Логи, JUnit, development
evidence, матрицы, test data, secrets и nested archives запрещены.

## 3. Matrix/technical archive

Содержит:

- все уникальные подробные XLSX identity matrices;
- текущие raw CSV/JSON matrices;
- JUnit/XML и полные test logs текущего цикла;
- retention и movement manifests;
- подробный XLSX-индекс файлов, размеров, SHA-256 и категорий;
- registry/guard evidence и archive verification.

## 4. Воспроизводимость

Перед удалением или переносом фиксируются путь, размер, SHA-256,
категория, причина и архив назначения. Код, tests, SSOT/NORM, migrations,
финансовые reconciliation reports и active mandatory documents удалять
запрещено.
