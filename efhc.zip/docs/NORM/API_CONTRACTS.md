<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
# API contracts

## Global identity

Текущий машинный контракт находится в `contracts/identity/global_id_api_contract_v1.json`. Removed historical exporter/checker scripts are not current authority.

Действующие правила:

- внешнее поле называется только `global_id`;
- wire type — строка `^[0-9]{10}$`;
- `0000000000` запрещён;
- JSON number, JavaScript `number`, `Number()`, `parseInt()` и unary `+`
  для внешнего `global_id` запрещены;
- `tg_id` является только Telegram provider subject;
- после identity resolution business API использует `global_id`;
- активные compatibility aliases отсутствуют;
- единственная release migration —
  `backend/migrations/versions/0001_initial_release_schema.py`.


## Каноническая поверхность текущего аккаунта

- `GET /api/v1/me` возвращает текущий аккаунт только по проверенной server-side session.
- Внутренний owner ответа — строковый `global_id`; Telegram subject в business response не требуется.

## no-prefix router exceptions

Маршрутизаторы без общего префикса допускаются только при явном фиксированном публичном пути, зарегистрированном в route inventory. Они не могут принимать произвольный `tg_id` как owner и обязаны разрешать authenticated identity до `global_id`.

- `GET /user/me` — текущая self-profile поверхность nonfinancial account API.
- Self-profile route с произвольным идентификатором в пути запрещён: текущий аккаунт определяется только из authenticated session.

Явные no-prefix router exceptions: `backend/app/routes/me_routes.py` и `backend/app/routes/system_routes.py`. Оба файла содержат фиксированные пути и собственный канонический комментарий.

## Current OpenAPI artifact

`backend/openapi/openapi.json` — полный dependency-backed export `app.main:app.openapi()` при canonical default Settings и `API_PREFIX=/api`, а не static route scan. Его paths — фактические mounted URLs; frontend seam constants остаются router-local, существующий API client добавляет `/api`. `/meta/health_db` остаётся отдельным unprefixed URL. Hidden cron/webhook/compatibility handlers не публикуются в OpenAPI. Existing full runtime/snapshot contract test проверяет операции, schemas и metadata; отдельный route CSV или governance layer не создаётся.
