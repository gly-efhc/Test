<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
# API contracts

## Global identity

Текущий машинный контракт находится в
`contracts/identity/global_id_api_contract_v1.json` и воспроизводится
через `ops/identity/export_global_id_api_contract.py`.

Действующие правила:

- внешнее поле называется только `global_id`;
- wire type — строка `^[0-9]{10}$`;
- `0000000000` запрещён;
- JSON number, JavaScript `number`, `Number()`, `parseInt()` и unary `+`
  для внешнего `global_id` запрещены;
- `tg_id` является только Telegram provider subject;
- после identity resolution business API использует `global_id`;
- активные compatibility aliases отсутствуют;
- единственная release migration —
  `backend/migrations/versions/0001_initial_release_schema.py`.

Guard:
`ops/identity/check_global_id_api_contract.py`.
