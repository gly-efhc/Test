<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Цикл 1606 — канонический API-контракт global_id

Изолированный контракт находится в
`contracts/identity/global_id_api_contract_v1.json` и воспроизводится
через `ops/identity/export_global_id_api_contract.py`.

Backend, OpenAPI fixture и frontend обязаны иметь parity:

- поле: `global_id`;
- type: `string`;
- format: `efhc-global-id`;
- pattern: `^[0-9]{10}$`;
- min/max length: 10;
- `0000000000` запрещён runtime-валидацией;
- ведущие нули не удаляются.

Контракт пока не подключён к действующим routes. LEGACY envelopes
сохраняются до отдельного switch-cycle.

## Current physical and API state

- Физический owner: `users.global_id`.
- `users.user_id` отсутствует.
- Alembic имеет один head: `0001_initial_release_schema.py`.
- Внешний `global_id` подключён как строка ровно из 10 ASCII-цифр.
- `0000000000`, numeric coercion и integer schema запрещены.
- `tg_id` допускается только в Telegram/provider ingress и source metadata.
- Старые cycle 1596–1597 preparation-формулировки являются историческими и
  не описывают current runtime.

# API_CONTRACTS (EFHC) — Контракты routes ↔ services

Статус: NORM (исполняемые контрактные требования).
Якорь SSOT: docs/SSOT/SSOT_INDEX.md

Цель:
- Зафиксировать контракт между HTTP-роутами и сервисами.
- Убрать зависимость от чатов: вход/выход/ошибки/идемпотентность/права.

Правила контракта (общие):
- Target system account: `global_id` / `GlobalId`. `user_id` / `UserId` запрещены для новых контрактов и допустимы только в явно историческом или изолированном compatibility-коде.
- Current runtime resolves account ownership by canonical `global_id`; provider selectors are isolated at ingress boundaries.
- Пагинация списков: next_cursor + limit.
  - encode_cursor/decode_cursor — кодирование/декодирование
    курсора без раскрытия внутренних ключей.
  - CursorPage: items + next_cursor (или null).
- Формат ошибок: единый объект (см. docs/SSOT/EFHC_CANON.md).
- Денежные/энергетические величины: Decimal, округление вниз.
- Идемпотентность обязательна для операций, меняющих баланс.

Нотация:
- Auth: USER / ADMIN.
- Idem: REQUIRED / OPTIONAL / FORBIDDEN.
- Headers: обязательные заголовки.

---

## 1) System

### GET /system/health
Auth: USER (безопасно и публично) | Idem: FORBIDDEN
Вход: нет
Выход: {"status": "ok"}
Ошибки: 500

---

## 2) Me / User

### GET /api/v1/me
Auth: USER | Idem: FORBIDDEN
Вход:
- Telegram auth context (`initData` / middleware / deps)
Выход (минимум):
- global_id
- username
- vip
Особенности:
- safe-витрина для Telegram WebApp
- при наличии `ton_wallet` может мягко обновить VIP-кэш
Ошибки:
- 401 UNAUTHORIZED

### GET /user/me
Auth: USER | Idem: FORBIDDEN
Вход:
- Telegram auth context
- canonical auth dependency
Выход (минимум):
- global_id
- username
- is_vip
- main_balance
- bonus_balance
- available_kwh
- total_generated_kwh
- gen_per_sec_base_kwh
- gen_per_sec_vip_kwh
Ошибки:
- 401 UNAUTHORIZED
- 404 USER_NOT_FOUND

### POST /sync/user/{global_id}
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key: <random-idempotency-key>
Вход:
- Path: global_id (int)
- Body: профильные поля синхронизации (SSOT в schemas)
Выход:
- актуальное состояние пользователя
Ошибки:
- 409 IDEMPOTENCY_CONFLICT
- 422 VALIDATION_ERROR

## 3) Energy / Panels


### GET /user/me/panels-summary
Auth: USER | Idem: FORBIDDEN
Вход:
- Telegram auth context через канонический auth dependency
Выход:
- active_count
- total_generated_by_panels
- nearest_expire_at
Особенности:
- единственный canonical panels-summary self route
- старый `GET /user/{global_id}/panels-summary` удалён
- старый `GET /panels/{global_id}/summary` также удалён
Ошибки:
- 401 UNAUTHORIZED
- 500 TEMPORARY_ERROR

### POST /panels/activate
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- текущий global_id берётся только из auth context
- Body: активация панели по current schemas/SSOT
Выход:
- результат активации панели
- обновлённые балансы/состояние по current contract
Особенности:
- path global_id больше не используется
- compatibility buy route удалён из active backend code
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 409 IDEMPOTENCY_CONFLICT

### GET /energy/{global_id}/state
Auth: USER | Idem: FORBIDDEN
Вход: Path global_id
Выход:
- gen_per_sec
- total_generated
- updated_at
Ошибки:
- 404 USER_NOT_FOUND

---

## 4) Hub + Shop backend commerce

### POST /hub/efhc-handoff
Auth: USER | Idem: FORBIDDEN
Вход: нет
Выход:
- redirect_url
- expires_at
- transport = external_url
- mode = signed_token
Ошибки:
- 503 HUB_EFHC_BUY_FLOW_NOT_CONNECTED

### GET /shop/catalog
Auth: USER | Idem: FORBIDDEN
Вход: нет
Выход:
- items[]
  - sku
  - title
  - description
  - price_ton / price_usdt / price_efhc (если применимо)
  - availability
Ошибки: 500

### POST /shop/order-external
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Body: внешний order payload для TON/USDT покупки
Выход:
- payment_intent
- tx
- order
Ошибки:
- 400 VALIDATION_ERROR
- 403 WALLET_REQUIRED
- 409 IDEMPOTENCY_CONFLICT

### POST /shop/purchase-efhc
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Body: внутренний payload покупки за EFHC
Выход:
- order_id
- status
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 409 IDEMPOTENCY_CONFLICT

### GET /shop/orders
Auth: USER | Idem: FORBIDDEN
Вход: курсор / limit
Выход:
- orders[]
- next_cursor
Ошибки: 404 USER_NOT_FOUND

### GET /admin/hub/links
Auth: ADMIN | Idem: FORBIDDEN
Вход:
- Query: active_only
Выход:
- items[] HubLinkAdminOut

### POST /admin/hub/links
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminCreateIn
Выход: HubLinkAdminOut

### PUT /admin/hub/links/{link_id}
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminUpdateIn
Выход: HubLinkAdminOut

### POST /admin/hub/links/{link_id}/toggle
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminToggleIn
Выход: HubLinkAdminOut

### POST /admin/hub/links/reorder
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminReorderIn
Выход:
- items[] HubLinkAdminOut

## 5) Withdrawals

### POST /withdraw/request
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Input:
- body.amount as decimal string
Output:
- id
- global_id
- amount
- status
- idempotency_key
- hold_done
- refund_done
- payout_ref
- created_at
- updated_at
Rules:
- current user is resolved from auth;
- user global_id is not accepted from path;
- request service creates PENDING request and holds EFHC to bank;
- only one active PENDING request per user is allowed.

### GET /withdraw/list
Auth: USER | Idem: FORBIDDEN
Input:
- optional legacy query global_id for self-check only
- limit
- cursor
- status_filter
Output:
- items[]
- next_cursor
Rules:
- current user is resolved from auth;
- if legacy global_id is provided it must match current user;
- list reads only current user's requests.

### GET /withdraw/{request_id}
Auth: USER | Idem: FORBIDDEN
Input:
- path request_id
Output:
- withdraw detail
Rules:
- request global_id must match current user.

### POST /withdraw/{request_id}/cancel
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Input:
- path request_id
Output:
- withdraw detail
Rules:
- only PENDING request can be canceled by user;
- refund credits EFHC from bank when hold_done is true;
- repeated partial recovery must not create duplicate refund.

### POST /admin/withdrawals/{request_id}/approve
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Rules:
- PENDING becomes PAID;
- same idempotency key for already PAID returns idempotent replay;
- outcome event is saved;
- database commit is explicit before success response.

### POST /admin/withdrawals/{request_id}/reject
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Rules:
- PENDING becomes REJECTED;
- refund is done when hold_done is true;
- outcome event is saved;
- database commit is explicit before success response.

---

### GET /admin/stats
Auth: ADMIN | Idem: FORBIDDEN
Вход: нет
Выход:
- users_count
- bank_balance
- withdrawals_pending
- last_events[]
Ошибки:
- 403 FORBIDDEN

### POST /admin/withdrawals/{withdraw_id}/set_status
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: withdraw_id
- Body: {"status": "PAID|REJECTED|CANCELED", "comment": str}
Выход:
- withdraw_id
- new_status
- audit_log_id
Ошибки:
- 404 WITHDRAW_NOT_FOUND
- 409 IDEMPOTENCY_CONFLICT

### POST /admin/transfer
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Input:
- LEGACY runtime input: body.tg_id identifies the current Telegram-backed account
- target contract: body.user_id is the ten-digit system identifier after the assigned API read switch
- body.direction is credit or debit
- body.balance is main or bonus
- body.amount is a Decimal EFHC amount
Output:
- global_id
- direction
- balance
- amount
- bank_balance_after
- user__main__after
- user_bonus_after
Rules:
- all mutations go through transactions_service helpers
- raw internal users.id is never accepted as an external identifier
- cycle 1594 does not change this endpoint or its owner read
- idempotency is header-only and required
Errors:
- 400 VALIDATION_ERROR
- 409 IDEMPOTENCY_CONFLICT

### POST /admin/bank/mint
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Input:
- body.amount as Decimal EFHC amount
- body.reason optional
Output:
- bank_balance_after
- idempotency_key
- reused
Rules:
- route resolves admin by global_id through RBAC
- service writes canonical `efhc_transfers_log` entry and admin log
- route commits before the success response

### POST /admin/bank/burn
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Input:
- body.amount as Decimal EFHC amount
- body.reason optional
Output:
- bank_balance_after
- idempotency_key
- reused
Rules:
- route resolves admin by global_id through RBAC
- service writes canonical `efhc_transfers_log` entry and admin log
- route commits before the success response

---

## 8) Ошибки и идемпотентность

### Идемпотентность
- Любой endpoint с Idem: REQUIRED обязан:
  - принимать Idempotency-Key
  - возвращать тот же результат при повторе
  - возвращать 409 при конфликте разных тел под один ключ

### Ошибка
Единый формат ошибки определяется в docs/SSOT/EFHC_CANON.md.


## Appendix A) Reference notes absorbed from API_REFERENCE.md

### Idempotency
Все POST/PUT, меняющие баланс или создающие оплату, заказ, заявку или
другую чувствительную сущность, требуют `Idempotency-Key`.

Повторный запрос с тем же ключом возвращает ранее созданный результат
через read-through policy.

### Cursor pagination
Списки используют `next_cursor` и `limit`.

Ответ возвращает:
- `items` — элементы текущей страницы;
- `next_cursor` — строковый курсор следующей страницы или `null`.

Курсор кодируется и не должен раскрывать внутренние ключи.

### Example reference: GET /wallets/balance-history
Возвращает историю изменений main/bonus балансов пользователя из
`efhc_core.efhc_transfers_log` в порядке от новых к старым.

## Route/OpenAPI regeneration note

For route docs hygiene the project uses deterministic regeneration of
`АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/audits/ROUTE_INVENTORY_FREEZE.md` from
`docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv`. Historical manual
drift notes are absorbed into current contract/control docs and no
longer stay
as standalone active files.


## Browser-shop intent contract (planning anchor)

### Draft checkout state
- Exists before Telegram linking if the user entered through browser
  flow.
- Is not a payment intent.
- Stores chosen product/custom amount and selected asset preference.

### Runtime payment-intent status route

- `GET /payment-intents/{intent_id}` is owner-only.
- It resolves the owner from auth, not from query input.
- It must return 404 when the service returns `ok = false`.
- Internal service key `ok` is not part of the API response model.
- The response carries `flow_truth` for deposit/watcher UX.

### Payment intent
- Created only after Telegram linking is confirmed.
- One product or one custom amount = one payment intent.
- Payment intent must freeze:
  - `global_id`
  - item code / item type
  - mode (`package` / `custom` / `vip_nft`)
  - selected asset (`TON` / `USDT`)
  - EFHC amount (where applicable)
  - asset amount to pay
  - memo
  - receiving address context
  - pricing snapshot / oracle-derived rate context
  - TTL
  - status

### Reconciliation anchor
- Primary matching mechanism: unique memo per operation.
- Matching context also includes receiving address and asset type.
- Business logic after match depends on item type and is defined
  separately in
  watcher/business-flow planning.

- Client must not be allowed to submit or mutate memo.


## Browser-shop confirm anti-fraud anchor

- Memo alone is insufficient for credit.
- Credit requires a pre-existing authorized intent/purchase signal.
- Watcher must verify the full frozen payment profile before business
  logic is
  triggered.
- Arbitrary incoming payments with copied memo or wrong amount must be
  ignored
  for automatic user credit.


### Exchange convert contract

- `POST /exchange/convert` принимает `amount_kwh`.
- Если `amount_kwh` отсутствует, допускается `EXCHANGE_ALL`.
- Если `amount_kwh` передан, сервис обязан выполнить частичный обмен
  ровно на запрошенную сумму.
- Контракт route и фактический `actual_amount_kwh` MUST match.


## 2A) Payment / shop_external confirm

### Internal confirm contract
Auth: INTERNAL / WATCHER | Idem: REQUIRED

Канон:
- `shop_external` не считается успешно подтверждённым без order-side
  effect.
- Сначала order переводится `PENDING -> PAID_AUTO` с `RETURNING`,
  затем подтверждается `payment_intent`.
- При отсутствии order update должен возвращаться manual/pending path,
  а не тихий success.

## Internal helper routes

`GET /cron/tick` and `POST /tg/webhook` are runtime helper/internal
routes.  They are not part of public OpenAPI and must not be treated as
user-facing roads.  Cron requires `X-Cron-Secret` when configured.
Telegram webhook requires `X-Telegram-Bot-Api-Secret-Token` when
configured.

---

## v168_19 Direct Deposit contract

### POST /deposit/direct-open
Auth: USER | Idem: FORBIDDEN
Input:
- authenticated Telegram user from current user context.
Output:
- `purpose = direct_deposit`;
- `wallet_open_url` for frontend internal wallet handoff;
- `memo` bound to authenticated `global_id`;
- `receiver_address` for frontend internal wallet handoff;
- `memo_binding = global_id`.
Rules:
- This route is not a shop package purchase.
- It must not accept `package_id`.
- It must not call package-purchase intent creation.
- Public UI must not render receiver address, memo or copy buttons.
- User chooses the amount inside the wallet.
Errors:
- 500 `DIRECT_DEPOSIT_RECEIVER_NOT_SET` if receiver wallet is absent.
Proof:
- Guard `test_direct_deposit_guard.py`.

## v168_30 Panels self-list routes

Canonical self-user Panels list routes for the public frontend:

- `GET /panels/active`
- `GET /panels/archive`

Legacy compatibility routes remain hidden from public schema:

- `GET /panels/{global_id}/active`
- `GET /panels/{global_id}/archive`

The public frontend must prefer the self-user routes.  Panel activation
remains `POST /panels/activate`.
---

## no-prefix router exceptions

These backend route modules intentionally declare `APIRouter()` without a
module-level `prefix=` and must not be changed silently:

- `backend/app/routes/me_routes.py` — `/v1/me` and related Me/User profile
  routes are mounted by the include layer; the module itself remains
  no-prefix by canon.
- `backend/app/routes/system_routes.py` — `/health`, `/health/db`,
  `/health/runtime` and close system endpoints remain no-prefix by project
  convention.

Do not add a module-level prefix to these files without an explicit
architecture decision, because it would change public/API health paths and
Me route contracts.



## v169_88 Payment Intent package_id contract

`payment_intents.package_id` contract after `HEAL-0040`:

- package-based deposit intents must store a real `package_id`;
- custom/package-less intents must store `NULL`;
- fake sentinel `0` is forbidden;
- service SQL, ORM, migration and tests must keep this contract aligned.

`efhc_core.efhc_transfers_log.direction` after `HEAL-0044`:

- ORM and live DB must support `varchar(24)`;
- existing DB repair belongs to Alembic 0001 until a post-release migration phase exists.

## Cycle 1442 — OpenAPI rebuild strict contract gate

Current checked-in OpenAPI snapshot is rebuilt from backend route source by:

```text
ops/routes/rebuild_openapi_contract_snapshot.py
```

Current strict gate:

```text
ops/routes/check_openapi_strict_contract_gate.py
```

Canonical generated artifacts:

```text
backend/openapi/openapi.json
backend/openapi/openapi_manifest.json
docs/SSOT/ssot_pack/SSOT_ROUTES.csv
docs/SSOT/ssot_pack/SSOT_ROUTES_NUMBERED.csv
docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv
АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/generated/openapi_contract_snapshot_v170_18.json
АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/generated/openapi_strict_contract_gate_v170_18.json
```

Rule: checked-in OpenAPI must have no dead routes and no missing visible backend routes against backend route source. Generated frontend seam constants and direct frontend `apiRequest(...)` calls must resolve to backend/OpenAPI routes after API client normalization.

Boundary: this is a dependency-light static contract gate. Live FastAPI `app.openapi()` export remains a separate CI/full-runtime proof and must not be claimed from local static validation.
