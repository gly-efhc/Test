# API_CONTRACTS (EFHC) — Контракты routes ↔ services

Статус: NORM (исполняемые контрактные требования).
Якорь SSOT: docs/SSOT/SSOT_INDEX.md

Цель:
- Зафиксировать контракт между HTTP-роутами и сервисами.
- Убрать зависимость от чатов: вход/выход/ошибки/идемпотентность/права.

Правила контракта (общие):
- Канон пользователя: только tg_id.
- Пагинация списков: next_cursor + limit.
  - encode_cursor/decode_cursor — кодирование/декодирование
    курсора без раскрытия внутренних ключей.
  - CursorPage: items + next_cursor (или null).
- Формат ошибок: единый объект (см. docs/SSOT/EFHC_CANON.md).
- Денежные/энергетические величины: Decimal, округление вниз.
- Идемпотентность обязательна для операций, меняющих баланс.

Нотация:
- Auth: USER / ADMIN.
- Idem: REQUIRED / OPTIONAL / FORBIDDEN.
- Headers: обязательные заголовки.

---

## 1) System

### GET /system/health
Auth: USER (безопасно и публично) | Idem: FORBIDDEN
Вход: нет
Выход: {"status": "ok"}
Ошибки: 500

---

## 2) Me / User

### GET /api/v1/me
Auth: USER | Idem: FORBIDDEN
Вход:
- Telegram auth context (`initData` / middleware / deps)
Выход (минимум):
- tg_id
- username
- vip
Особенности:
- safe-витрина для Telegram WebApp
- при наличии `ton_wallet` может мягко обновить VIP-кэш
Ошибки:
- 401 UNAUTHORIZED

### GET /user/me
Auth: USER | Idem: FORBIDDEN
Вход:
- Telegram auth context (`req.state.tg_id` или канонический auth dependency)
Выход (минимум):
- tg_id
- username
- is_vip
- main_balance
- bonus_balance
- available_kwh
- total_generated_kwh
- gen_per_sec_base_kwh
- gen_per_sec_vip_kwh
Ошибки:
- 401 UNAUTHORIZED
- 404 USER_NOT_FOUND

### GET /user/{tg_id}/me
Auth: USER | Idem: FORBIDDEN
Вход:
- Path: tg_id (int)
Выход:
- тот же контракт, что и у `GET /user/me`
Особенности:
- self-guarded alias для совместимости
- доступ разрешён только при `tg_id == current_tg_id`
Ошибки:
- 401 UNAUTHORIZED
- 403 FORBIDDEN
- 404 USER_NOT_FOUND

### POST /sync/user/{tg_id}
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key: <random-idempotency-key>
Вход:
- Path: tg_id (int)
- Body: профильные поля синхронизации (SSOT в schemas)
Выход:
- актуальное состояние пользователя
Ошибки:
- 409 IDEMPOTENCY_CONFLICT
- 422 VALIDATION_ERROR

## 3) Energy / Panels

### POST /panels/activate/{tg_id}
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: tg_id
- Body: активация панели по current schemas/SSOT
Выход:
- результат активации панели
- обновлённые балансы/состояние по current contract
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 409 IDEMPOTENCY_CONFLICT

### POST /panels/buy/{tg_id}
Auth: USER | Idem: REQUIRED
Статус: compat path
Особенности:
- historical compatibility path
- не должен объявляться как новый основной канон поверх
  `/panels/activate/{tg_id}`

### GET /energy/{tg_id}/state
Auth: USER | Idem: FORBIDDEN
Вход: Path tg_id
Выход:
- gen_per_sec
- total_generated
- updated_at
Ошибки:
- 404 USER_NOT_FOUND

---

## 4) Hub + Shop backend commerce

### POST /hub/efhc-handoff
Auth: USER | Idem: FORBIDDEN
Вход: нет
Выход:
- redirect_url
- expires_at
- transport = external_url
- mode = signed_token
Ошибки:
- 503 HUB_EFHC_BUY_FLOW_NOT_CONNECTED

### GET /shop/catalog
Auth: USER | Idem: FORBIDDEN
Вход: нет
Выход:
- items[]
  - sku
  - title
  - description
  - price_ton / price_usdt / price_efhc (если применимо)
  - availability
Ошибки: 500

### POST /shop/order-external
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Body: внешний order payload для TON/USDT покупки
Выход:
- payment_intent
- tx
- order
Ошибки:
- 400 VALIDATION_ERROR
- 403 WALLET_REQUIRED
- 409 IDEMPOTENCY_CONFLICT

### POST /shop/purchase-efhc
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Body: внутренний payload покупки за EFHC
Выход:
- order_id
- status
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 409 IDEMPOTENCY_CONFLICT

### GET /shop/orders
Auth: USER | Idem: FORBIDDEN
Вход: курсор / limit
Выход:
- orders[]
- next_cursor
Ошибки: 404 USER_NOT_FOUND

### GET /admin/hub/links
Auth: ADMIN | Idem: FORBIDDEN
Вход:
- Query: active_only
Выход:
- items[] HubLinkAdminOut

### POST /admin/hub/links
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminCreateIn
Выход: HubLinkAdminOut

### PUT /admin/hub/links/{link_id}
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminUpdateIn
Выход: HubLinkAdminOut

### POST /admin/hub/links/{link_id}/toggle
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminToggleIn
Выход: HubLinkAdminOut

### POST /admin/hub/links/reorder
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход: HubLinkAdminReorderIn
Выход:
- items[] HubLinkAdminOut

## 5) Withdrawals

### POST /withdraw/{tg_id}/request
Auth: USER | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: tg_id
- Body:
  - amount (Decimal)
  - payout_wallet (str)
Выход:
- withdraw_id
- status (PENDING)
Ошибки:
- 400 INSUFFICIENT_FUNDS
- 422 VALIDATION_ERROR
- 409 IDEMPOTENCY_CONFLICT

### GET /withdraw/{tg_id}/history
Auth: USER | Idem: FORBIDDEN
Вход: Path tg_id
Выход:
- withdrawals[]
Ошибки: 404 USER_NOT_FOUND

---

### GET /admin/stats
Auth: ADMIN | Idem: FORBIDDEN
Вход: нет
Выход:
- users_count
- bank_balance
- withdrawals_pending
- last_events[]
Ошибки:
- 403 FORBIDDEN

### POST /admin/withdrawals/{withdraw_id}/set_status
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Path: withdraw_id
- Body: {"status": "PAID|REJECTED|CANCELED", "comment": str}
Выход:
- withdraw_id
- new_status
- audit_log_id
Ошибки:
- 404 WITHDRAW_NOT_FOUND
- 409 IDEMPOTENCY_CONFLICT

### POST /admin/bank/adjust
Auth: ADMIN | Idem: REQUIRED
Headers:
- Idempotency-Key
Вход:
- Body:
  - amount (Decimal)
  - reason (enum)
  - details (object)
Выход:
- operation_id
- bank_balance
Ошибки:
- 422 VALIDATION_ERROR
- 409 IDEMPOTENCY_CONFLICT

---

## 8) Ошибки и идемпотентность

### Идемпотентность
- Любой endpoint с Idem: REQUIRED обязан:
  - принимать Idempotency-Key
  - возвращать тот же результат при повторе
  - возвращать 409 при конфликте разных тел под один ключ

### Ошибка
Единый формат ошибки определяется в docs/SSOT/EFHC_CANON.md.


## Appendix A) Reference notes absorbed from API_REFERENCE.md

### Idempotency
Все POST/PUT, меняющие баланс или создающие оплату, заказ, заявку или
другую чувствительную сущность, требуют `Idempotency-Key`.

Повторный запрос с тем же ключом возвращает ранее созданный результат
через read-through policy.

### Cursor pagination
Списки используют `next_cursor` и `limit`.

Ответ возвращает:
- `items` — элементы текущей страницы;
- `next_cursor` — строковый курсор следующей страницы или `null`.

Курсор кодируется и не должен раскрывать внутренние ключи.

### Example reference: GET /wallets/balance-history
Возвращает историю изменений main/bonus балансов пользователя из
`efhc_core.efhc_transfers_log` в порядке от новых к старым.

## Route/OpenAPI regeneration note

For route docs hygiene the project uses deterministic regeneration of
`docs/audits/ROUTE_INVENTORY_FREEZE.md` from
`docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv`. Historical manual
drift notes are absorbed into current contract/control docs and no longer stay
as standalone active files.


## Browser-shop intent contract (planning anchor)

### Draft checkout state
- Exists before Telegram linking if the user entered through browser flow.
- Is not a payment intent.
- Stores chosen product/custom amount and selected asset preference.

### Payment intent
- Created only after Telegram linking is confirmed.
- One product or one custom amount = one payment intent.
- Payment intent must freeze:
  - `tg_id`
  - item code / item type
  - mode (`package` / `custom` / `vip_nft`)
  - selected asset (`TON` / `USDT`)
  - EFHC amount (where applicable)
  - asset amount to pay
  - memo
  - receiving address context
  - pricing snapshot / oracle-derived rate context
  - TTL
  - status

### Reconciliation anchor
- Primary matching mechanism: unique memo per operation.
- Matching context also includes receiving address and asset type.
- Business logic after match depends on item type and is defined separately in
  watcher/business-flow planning.

- Client must not be allowed to submit or mutate memo.


## Browser-shop confirm anti-fraud anchor

- Memo alone is insufficient for credit.
- Credit requires a pre-existing authorized intent/purchase signal.
- Watcher must verify the full frozen payment profile before business logic is
  triggered.
- Arbitrary incoming payments with copied memo or wrong amount must be ignored
  for automatic user credit.


### Exchange convert contract

- `POST /exchange/convert/{tg_id}` принимает `amount_kwh`.
- Если `amount_kwh` отсутствует, допускается `EXCHANGE_ALL`.
- Если `amount_kwh` передан, сервис обязан выполнить частичный обмен
  ровно на запрошенную сумму.
- Контракт route и фактический `actual_amount_kwh` MUST match.


## 2A) Payment / shop_external confirm

### Internal confirm contract
Auth: INTERNAL / WATCHER | Idem: REQUIRED

Канон:
- `shop_external` не считается успешно подтверждённым без order-side effect.
- Сначала order переводится `PENDING -> PAID_AUTO` с `RETURNING`,
  затем подтверждается `payment_intent`.
- При отсутствии order update должен возвращаться manual/pending path,
  а не тихий success.
