# ARCHIVE NUMBERING CANON

## Current compact filename rule

EFHC Bot release archives now use the compact canonical pattern:

`EFHC_Bot_v<major>_<minor_two_digits>.zip`

The cycle number, repair title, reason and evidence belong inside archive
documents, reports and Kernel records, not in the ZIP filename. Therefore,
cycle and title belong inside archive documents, not in the filename. This keeps
release filenames short while preserving full traceability in the archive.

Allowed example:

- `EFHC_Bot_v171_27.zip`

Long descriptive filenames are deprecated for current HEAD archives. Historical
archives with `_cycle_XXXX_<slug>` remain evidence only and must not be used as
new naming guidance.

## Legacy descriptive pattern

Older EFHC Bot release archives used the pattern:

`EFHC_Bot_v<major>_<minor_two_digits>_<description>.zip`

This legacy form remains readable as historical evidence, but the active naming
canon is the compact form above.

## Mandatory version rollover rule

The minor suffix is exactly two digits: `00` through `99`.
After `vN_99`, the next valid archive is `v(N+1)_00`.

Therefore:

- after `v168_99` comes `v169_00`;
- after `v169_99` comes `v170_00`.

## Forbidden forms

The following forms are invalid:

- `v168_100`;
- `v168_101`;
- any `vN_100+` version;
- parallel manual archive branches without explicit emergency mapping.

## Emergency alias map — 2026-05-26

The following issued names were invalid and are historical aliases only:

- `v168_100` -> canonical `v169_00`;
- `v168_101` -> canonical `v169_01`.

Current corrected continuation: `v169_03`.


## Экстренная коррекция alias — 2026-08-29 / цикл 1841

В цикле `1840` был ошибочно выпущен архив `EFHC_Bot_v174_100.zip`.
Имя нарушает действующий двухзначный minor-канон и не может быть current HEAD.
Содержимое этого физического выпуска сохраняется только как историческое входное
evidence для коррекции, без отката утверждённых изменений цикла 1840.

Каноническое соответствие:

- invalid historical alias `v174_100` -> canonical rollover `v175_00`.

Текущая продолженная линия после исправления: `v175_00`. Следующий изменённый
release после него обязан быть `v175_01`; возврат к `v174_100+` запрещён.

Причина инцидента: production release parsers принимали `\d+` для minor вместо
ровно двух цифр. В цикле `1841` builder, safe extractor и updater переведены на
fail-closed `00..99`, добавлен независимый regression guard.

## Current-branch guard requirement

Current work archives must never use a three-digit minor suffix.
The only valid continuation after any `_99` archive is the next major
with `_00`. This applies to every major version, not only to the
historical aliases listed below.

Architecture guards must scan active files, generated reports and
indexes for numeric archive tokens with a three-digit minor suffix.
Historical invalid aliases may remain only as explicitly documented
legacy evidence, never as current HEAD or next-cycle guidance.
