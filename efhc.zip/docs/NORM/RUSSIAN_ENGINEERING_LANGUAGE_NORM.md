# Document language boundary — действующий NORM

Статус: ACTIVE / OWNER-CORRECTED / cycle `1813`.
Маркер: `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`.

## 1. Обязательный human-readable scope

Для `documents`, `reports`, `cycles` и owner-facing `chat` используется русский
описательный текст. При этом `technical terms`, `concepts`, `identifiers`,
`protocol names`, `API names`, `framework names`, `status tokens`, `file paths`
и другие canonical technical names сохраняются на English и не переводятся
ради стилистической однородности.

Короткая формула:

**Формула: Russian descriptive prose + English technical terms/concepts.**

## 2. Граница source code

`Document language policy` не является `source code style policy` и не может
задавать язык программного кода. Нельзя менять `source code` только ради
соответствия этой policy, включая:

- `identifiers`, function/class/variable names и `test names`;
- `comments` и `docstrings`;
- `types`, `properties`, `enum/status tokens` и `machine literals`;
- `API`, `SQL`, `protocol`, `schema`, `route` и `command` names;
- Python/TypeScript/JavaScript и любой другой executable/source artifact.

Если `document language guard` начинает квалифицировать `source code`, defect
находится в `guard scope`, а не в коде приложения. Исправляется `guard scope`;
runtime/test source запрещено переименовывать только ради document language.

## 3. UI и localization

User-facing `UI text` и `localization` регулируются отдельными `UX/i18n`
contracts. Русский `UI text` не считается нарушением English technical naming,
потому что это пользовательский content, а не programmatic identifier.

## 4. Regression protection

`ops/quality/check_russian_engineering_language.py` сохраняет legacy filename
только для compatibility. Его controlled scope ограничен human-readable
Markdown/text documents и current reports.

Постоянный regression guard:
`tests/architecture/test_document_language_scope_canon.py`.

Guard обязан доказывать:

1. English `source code`, `test names`, `comments` и `docstrings` не попадают в
      не попадают в document language qualification;
2. Russian descriptive prose с English technical terms проходит;
3. полностью English descriptive prose в новом human-readable document
   блокируется;
4. active AI/CANON/NORM documents содержат marker
   `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`.

## 5. Historical evidence

Historical документы и прежние CI evidence сохраняют старые формулировки как
traceability. Они не являются active authority и не могут снова расширить
`document language policy` на `source code`.
