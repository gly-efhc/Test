# Referral first-creation attribution canon

Status: ACTIVE from `v171.78`; monetary level rewards restored in `v171.79`.

## Primary path

```text
/start ref_<code>
→ validate referral code
→ create the new users row
→ create referral_links in the same transaction
→ one commit
```

## Zero user path

```text
/start without referral payload
→ create the new users row
→ do not create referral_links
→ user is permanently a direct system / 0 user
```

A 0 user has no inviter and therefore produces no referral activation bonus.
The bank neither gives nor receives a referral bonus for that user.

## Permanent rules

- Referral attribution exists only for a user who did not exist before the
  current transaction.
- An existing user can never be attached, reattached or reassigned.
- A user created without an inviter remains a 0 user permanently.
- Every user may invite any number of genuinely new users.
- Rewards and referral counts concern direct invitees only.
- A direct inviter receives one `0.1 EFHCb` bonus when a direct invitee
  activates the first panel.
- Referral levels are based on active direct invitees and create automatic
  one-time milestone rewards:
  `10 → 1 EFHCb`, `100 → 10 EFHCb`, `1000 → 100 EFHCb`,
  `3000 → 300 EFHCb`, `10000 → 1000 EFHCb`.
- Level rewards are canonical monetary motivation, not manual Admin awards.
- Invalid or unknown supplied referral payload fails closed before the users
  row is inserted.
- User creation and referral link creation are one atomic PostgreSQL unit.
- Failure to insert the referral relation rolls back the new user row.
- Manual public routes `/referrals/bind` and `/referrals/attach` do not exist.
- Admin referral reassignment and manual referral bonus routes do not exist.
- Profile and money services cannot create missing player rows implicitly.
- Frontend code never sends a referral code to a late-binding endpoint.
- Cycles are impossible by construction: an already existing ancestor or
  descendant cannot become a new invitee later.

## Bonus boundary

No bonus is paid during registration. When the invitee activates the first
panel, the direct inviter receives the one-time `0.1 EFHCb` reward and every
newly reached level milestone reward. Unit and level rewards are idempotent and
remain inside the same first-panel transaction; any failure rolls back the
panel, debit, activation and all referral rewards.
