# Backend signature drift guard

Current guard:

- `tests/architecture/test_backend_signature_drift.py`

Cycle 1533 extensions:

- catches `notify_generic(title=...)` and `notify_generic(level=...)`;
- catches `notify_generic` calls without positional DB session;
- catches `notify_generic` calls without `event=`;
- catches lowercase `WithdrawalRequest.status == "pending"` in the
  withdrawals scheduler;
- catches stale admin facade calls using `request_id=` for current
  withdraw service methods;
- checks mypy scope includes scheduler notify files and admin facade.

The guard is an architecture tripwire. Runtime tests still remain
mandatory for live paths.
