# Visual Performance / Bundle Safety

**Project:** EFHC Bot  
**Cycle:** 1493 — Visual Performance / Bundle Safety  
**Archive version:** v170.69  
**Status:** DONE locally  
**Mode:** performance hardening / bundle safety / dashboard lazy boundary / docs / tests

## 1. Purpose

Cycle 1493 protects the dashboard direction from turning the Telegram Mini App
and public shell into a heavy BI application. EFHC Bot keeps Grafana-grade
visual discipline, but it must not copy Grafana runtime code, must not add heavy
chart libraries, and must not eagerly load admin-heavy panels into surfaces that
do not need them.

## 2. What changed

The admin-only real time-series dashboard introduced after the backend
observability contracts is now behind a lazy boundary on `/admin`.

```text
frontend/src/pages/admin/index.tsx
  -> dynamic import of AdminObservabilityTimeseriesDashboardRuntime
  -> ssr: false
  -> explicit lightweight loading placeholder
```

This does not change backend contracts, data truth, money-flow, write-flow or
EFHC economics. It only moves a heavy admin dashboard panel out of the initial
admin page module graph.

## 3. Bundle safety rules

The active dashboard direction now has the following guardrails:

1. No Grafana runtime package may be added to `frontend/package.json`.
2. No heavy chart library may be added without a separate bundle/build audit
   cycle.
3. Admin-only heavy dashboard panels should use lazy boundaries when they are
   not needed for first paint.
4. Public/TMA surfaces must not import `frontend/src/components/admin/*`.
5. Mini charts remain EFHC-owned SVG/CSS components.
6. Runtime dashboards must not use `synthetic_preview` as real analytics.
7. Performance fixes must not hide backend defects or weaken tests.

## 4. Forbidden dependencies without separate approval

The current cycle explicitly guards against adding:

- `@grafana/*`
- `grafana-*`
- `recharts`
- `chart.js`
- `react-chartjs-2`
- `echarts`
- `d3`
- `nivo`
- `victory`
- `plotly.js`
- `highcharts`
- `ag-grid-community`

This is not a permanent ban on all visualization libraries. It is a release
safety gate: adding any of them requires a separate dependency, license, bundle
and build audit cycle.

## 5. Lazy boundary added

`AdminObservabilityTimeseriesDashboardRuntime` is admin-only and calls
`/admin/observability/*`. It is useful, but not required for the first visual
paint of the admin home page.

The page now uses:

```text
dynamic(() => import("../../components/admin/AdminObservabilityTimeseriesDashboardRuntime"), { ssr: false })
```

The placeholder is marked with:

```text
data-admin-observability-lazy-placeholder="1493"
data-admin-heavy-panel-lazy-loaded="true"
data-admin-heavy-panel-ssr="false"
```

## 6. What did not change

- backend: no business/backend write-flow changes;
- OpenAPI: no new route contracts;
- migrations: no changes;
- EFHC economy: no changes;
- dependencies and lock files: no changes;
- CI/workflows: no changes;
- admin guarded actions: no changes.

## 7. Grafana / Песочница boundary

Grafana использована только как visual-pattern/reference layer. Runtime-код не
переносился.

Песочница использована только как reference/navigation/prototype layer.
Runtime-код не переносился.

## 8. Acceptance criteria

Cycle 1493 is accepted when:

1. The admin real time-series panel is lazy-loaded on `/admin`.
2. No heavy chart dependency is present in `frontend/package.json`.
3. No Grafana package/runtime import exists in frontend runtime code.
4. Public/TMA pages do not import admin dashboard runtime components.
5. `npm ci`, `npm audit`, `npm run typecheck` pass locally.
6. Architecture guard protects the lazy boundary and dependency blacklist.
