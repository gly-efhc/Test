# Exchange Dashboard Support Widgets

**Project:** EFHC Bot  
**Cycle:** 1479  
**Version:** v170.55  
**Status:** ACTIVE NORM  

## Purpose

Cycle 1479 adds a lightweight dashboard support layer to the public
Exchange route. The layer helps the user understand available kWh,
exchangeable kWh, expected EFHC result and the one-way conversion rule.

The dashboard is visual support only. It does not execute exchange and it
does not change the protected conversion form.

## Runtime target

- Route: `frontend/src/pages/exchange.tsx`.
- Component: `frontend/src/components/dashboard/ExchangeDashboardRuntime.tsx`.
- Existing protected action component remains `ExchangePanel`.
- Existing preview endpoint remains `EXCHANGE_PREVIEW_PATH`.
- Existing convert endpoint remains `EXCHANGE_CONVERT_PATH`.

## Truth model

```text
raw + derived snapshot
```

Raw values come from current sync snapshot and exchange preview.
Derived values are visual display values calculated from those raw values.

No synthetic runtime exchange history is allowed.
No fake time-series is allowed.
No reverse exchange is allowed.

## Economic boundaries

The cycle preserves the canonical exchange rule:

```text
kWh -> EFHC only, 1:1
```

Forbidden changes:

- EFHC -> kWh reverse exchange.
- Any change to the exchange rate.
- Any new write action in dashboard widgets.
- Any bypass of confirm / idempotency / existing guarded form.
- Any fake exchange history.
- Any backend or OpenAPI change.

## Visual widgets

The dashboard includes:

- Exchange overview toolbar.
- Available kWh card.
- Exchangeable kWh card.
- Expected EFHC card.
- Main balance card.
- kWh -> EFHC flow panel.
- 1:1 and one-way rule chips.
- Preview readiness panel.
- History boundary panel linking to account history.

## Runtime safety markers

`ExchangeDashboardRuntime.tsx` must keep:

```text
data-exchange-dashboard-runtime="1479"
data-exchange-dashboard-rate="1-kwh-1-efhc"
data-exchange-dashboard-one-way="kwh-to-efhc-only"
data-exchange-dashboard-no-reverse="true"
data-exchange-dashboard-no-write-bypass="true"
data-exchange-dashboard-no-fake-history="true"
data-exchange-dashboard-truth="raw-derived"
```

## Grafana and sandbox boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.
