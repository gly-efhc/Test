<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN_RBAC (EFHC) — Роли и права админ-панели

Статус: NORM (нормативный документ прав доступа).
Якорь SSOT: docs/SSOT/SSOT_INDEX.md

Цель: единая матрица ролей и разрешений для backend/admin API и UI.
Любые отличия кода/доков от этого документа считаются дефектом.

---

## 1. Термины

- RBAC — Role-Based Access Control (доступ по ролям).
- AdminRole — модель/перечисление роли администратора.
- require_role — проверка минимальной роли для админ-операции.
- role — роль (набор прав).
- permission — разрешение на операцию.
- admin_action — действие админа, которое обязано попасть в audit.
- audit_log — журнал аудита админ-действий.
- sensitive_operation — операция с повышенным риском.
- idempotency_key — ключ идемпотентности для операций,
  изменяющих состояние и баланс.

---

## 2. Общие правила доступа

1) Разделение доступа
- user API — доступен только пользователю по global_id.
- admin API — доступен только админам по global_id.

2) Канон идентификатора
- Во всех админ-действиях и аудите используется только global_id.

3) Аудит и идемпотентность
- Все sensitive_operation обязаны:
  - иметь audit_log запись,
  - требовать Idempotency-Key,
  - логировать global_id исполнителя и цель операции.

4) Принцип наименьших привилегий
- Роль получает только те права, которые нужны для задач.

---

## 3. Роли (каноничный набор)

Минимальный канон ролей:
- viewer — только просмотр (read-only).
- operator — операционные действия без изменения банка.
- finance — финансы (банк, корректировки, подтверждения).
- auditor — аудит и отчёты (read-only + экспорт).
- admin — полный доступ.
- owner — владелец/суперадмин, включая критичные настройки.

Примечание:
- Если в текущем runtime нет полной ролевой модели, документ
  используется как целевое SSOT.

---

## 4. Матрица прав (операции)

Легенда:
- R — read (просмотр)
- W — write (изменение)
- A — audit required
- I — idempotency required

### 4.1 Пользователи

- Просмотр профиля пользователя
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Корректировка баланса пользователя (EFHC)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Изменение статусов (VIP / NFT / ранг) вручную
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.2 EFHC Bank

- Просмотр баланса банка и журнала операций
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Ручная корректировка банка (bank_operation)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Массовые операции банка
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I
  Требование: отдельное подтверждение и отдельный audit.

### 4.3 Withdrawals

- Просмотр очереди заявок
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Изменение статуса заявки (approve / reject / paid / error)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Назначение приоритета (VIP priority)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.4 Hub / Commerce

- Просмотр commerce-сущностей текущего HEAD
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Подтверждение покупки / операции после внешней оплаты
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Возврат / отмена там, где это предусмотрено
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.5 Tasks / Ads / Referrals

- CRUD задач и модерация выполнений
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Управление Ads provider layer и ручная диагностика
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Ручные бонусные действия в referrals contour
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.6 Логи, события и отчёты

- Просмотр audit_log / events
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Экспорт отчётов
  - viewer: -
  - operator: -
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

---

## 5. Требования к реализации

1) Любой admin endpoint обязан иметь:
- required_role или эквивалентный guard,
- audit_log для W A операций,
- Idempotency-Key для W I операций.

2) Любая операция, влияющая на баланс:
- должна иметь reason + details,
- должна быть атомарной.

3) Ошибки доступа
- Использовать единый формат ошибок:
  - error_code,
  - message,
  - details.
  См. `docs/NORM/ERROR_CODES.md`.

## 6. Current access bootstrap и Admin NFT boundary

- `global_id=1313131313` зарезервирован для владельца SuperAdmin и не выдаётся
  обычной регистрацией. Само значение ID прав не даёт.
- Обычный Admin list: active `efhc_admin.admin_whitelist.global_id` + явная
  запись `admin_role`.
- Резервный Admin NFT не является ручным whitelist TON-кошельков. Источник
  права — точный NFT-item address из TON_ADMIN_NFT_IDS внутри `TON_NFT_COLLECTION`, обнаруженный
  тем же штатным NFT-checker, который обновляет VIP.
- `efhc_admin.admin_nft_whitelist` хранит только материализованный результат
  последней NFT-проверки: `ton_wallet_id`, `nft_id`, `source='env_nft'`, роль,
  active/revoked и timestamps. Строка БД без подтверждённого ENV NFT права не
  выдаёт.
- Обычный VIP (`users.is_vip`) сам по себе не является admin credential.
- Центральный `require_admin_or_nft_or_key` сначала использует canonical
  `global_id` проверенной server-side session. Затем допускается обычный RBAC
  либо verified TON identity + свежий derived Admin NFT state.
- `ton_wallet_id` остаётся provider subject; actor любой admin-операции —
  canonical session `global_id`.
- Admin NFT state fail-closed: ключ обязан всё ещё входить в текущий ENV, row
  должен быть active/non-revoked и не старше `NFT_CACHE_TTL_SECONDS`.
- Telegram/provider headers и SECRET_KEY bypass не разрешены.
- Подробный канон: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.

