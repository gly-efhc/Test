<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN_RBAC (EFHC) — Роли и права админ-панели

Статус: NORM (нормативный документ прав доступа).
Якорь SSOT: docs/SSOT/SSOT_INDEX.md

Цель: единая матрица ролей и разрешений для backend/admin API и UI.
Любые отличия кода/доков от этого документа считаются дефектом.

---

## 1. Термины

- RBAC — Role-Based Access Control (доступ по ролям).
- AdminRole — модель/перечисление роли администратора.
- require_role — проверка минимальной роли для админ-операции.
- role — роль (набор прав).
- permission — разрешение на операцию.
- admin_action — действие админа, которое обязано попасть в audit.
- audit_log — журнал аудита админ-действий.
- sensitive_operation — операция с повышенным риском.
- idempotency_key — ключ идемпотентности для операций,
  изменяющих состояние и баланс.

---

## 2. Общие правила доступа

1) Разделение доступа
- user API — доступен только пользователю по global_id.
- admin API — доступен только админам по global_id.

2) Канон идентификатора
- Во всех админ-действиях и аудите используется только global_id.

3) Аудит и идемпотентность
- Все sensitive_operation обязаны:
  - иметь audit_log запись,
  - требовать Idempotency-Key,
  - логировать global_id исполнителя и цель операции.

4) Принцип наименьших привилегий
- Роль получает только те права, которые нужны для задач.

---

## 3. Роли (каноничный набор)

Минимальный канон ролей:
- viewer — только просмотр (read-only).
- operator — операционные действия без изменения банка.
- finance — финансы (банк, корректировки, подтверждения).
- auditor — аудит и отчёты (read-only + экспорт).
- admin — полный доступ.
- owner — владелец/суперадмин, включая критичные настройки.

Примечание:
- Если в текущем runtime нет полной ролевой модели, документ
  используется как целевое SSOT.

---

## 4. Матрица прав (операции)

Легенда:
- R — read (просмотр)
- W — write (изменение)
- A — audit required
- I — idempotency required

### 4.1 Пользователи

- Просмотр профиля пользователя
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Корректировка баланса пользователя (EFHC)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Изменение статусов (VIP / NFT / ранг) вручную
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.2 EFHC Bank

- Просмотр баланса банка и журнала операций
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Ручная корректировка банка (bank_operation)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Массовые операции банка
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I
  Требование: отдельное подтверждение и отдельный audit.

### 4.3 Withdrawals

- Просмотр очереди заявок
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Изменение статуса заявки (approve / reject / paid / error)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Назначение приоритета (VIP priority)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.4 Hub / Commerce

- Просмотр commerce-сущностей текущего HEAD
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Подтверждение покупки / операции после внешней оплаты
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Возврат / отмена там, где это предусмотрено
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.5 Tasks / Ads / Referrals

- CRUD задач и модерация выполнений
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Управление Ads provider layer и ручная диагностика
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Ручные бонусные действия в referrals contour
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.6 Логи, события и отчёты

- Просмотр audit_log / events
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Экспорт отчётов
  - viewer: -
  - operator: -
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

---

## 5. Требования к реализации

1) Любой admin endpoint обязан иметь:
- required_role или эквивалентный guard,
- audit_log для W A операций,
- Idempotency-Key для W I операций.

2) Любая операция, влияющая на баланс:
- должна иметь reason + details,
- должна быть атомарной.

3) Ошибки доступа
- Использовать единый формат ошибок:
  - error_code,
  - message,
  - details.
  См. `docs/NORM/ERROR_CODES.md`.

## 6. Current access bootstrap и NFT boundary

- `global_id=1313131313` зарезервирован для владельца SuperAdmin и не выдаётся
  обычной регистрацией.
- Само наличие этого `global_id` не даёт прав: требуется active
  `admin_whitelist.global_id` и явная запись `admin_role=superadmin`.
- Дополнительные администраторы назначаются только по canonical `global_id` +
  server-side role. Provider subjects не являются источником прав.
- В текущем HEAD нет подтверждённого публичного admin-management endpoint/CLI,
  который создаёт новые whitelist/role записи; это отдельный operational gap.
- Обычный VIP-флаг (`users.is_vip`, `/nft/has_vip`) сам по себе не выдаёт admin-доступ.
- Существуют два независимых источника доступа к Admin Panel:
  1. обычный Admin list — active `efhc_admin.admin_whitelist.global_id` +
     явная запись `admin_role`;
  2. резервный Admin NFT list — active
     `efhc_admin.admin_nft_whitelist.ton_wallet_id` + `revoked_at IS NULL`.
- Admin NFT list намеренно не хранит account-owner `global_id` как credential.
  После проверенной server-side TON-сессии текущий `global_id` должен иметь
  active verified `user_identities(provider='ton')`; её `provider_subject`
  (`ton_wallet_id`) сопоставляется с Admin NFT list. Поэтому потеря Telegram-
  аккаунта не уничтожает резервный TON-based путь доступа.
- `ton_wallet_id` остаётся provider subject и не становится business/admin
  owner. Actor после успешного входа по-прежнему фиксируется canonical
  `global_id` текущей server-side session.
- Центральный gate `require_admin_or_nft_or_key` принимает либо обычный
  Admin list + RBAC, либо резервный Admin NFT list. Все admin routes используют
  alias `require_admin`, указывающий на этот единый gate.
- Telegram/provider headers и SECRET_KEY bypass не восстановлены. Обычный
  VIP-флаг (`users.is_vip`, `/nft/has_vip`) также не является admin credential.
- Поле `role` в `admin_nft_whitelist` совместимо с текущим RBAC. Значение по
  умолчанию `admin`; `superadmin` должен быть указан явно.
- Отдельный формат или on-chain verifier «NFT key» в активных источниках не
  определён; цикл 1709 не придумывает такой контракт. Текущий подтверждённый
  резервный credential — canonical `ton_wallet_id` из verified TON identity.
