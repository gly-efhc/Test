<!-- EFHC_GLOBAL_IDENTITY_CANON_V2 -->
> **Действующий identity-канон EFHC.** `global_id` — главный
> персональный идентификатор и единственный внутренний account/business
> owner. `tg_id` — только Telegram provider subject. Обязательная
> цепочка: `provider + subject → global_id → business runtime`.
> Внешний `global_id` — string ровно из 10 ASCII-цифр;
> `0000000000` запрещён; numeric coercion запрещён.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# ADMIN_RBAC (EFHC) — Роли и права админ-панели

Статус: NORM (нормативный документ прав доступа).
Якорь SSOT: docs/SSOT/SSOT_INDEX.md

Цель: единая матрица ролей и разрешений для backend/admin API и UI.
Любые отличия кода/доков от этого документа считаются дефектом.

---

## 1. Термины

- RBAC — Role-Based Access Control (доступ по ролям).
- AdminRole — модель/перечисление роли администратора.
- require_role — проверка минимальной роли для админ-операции.
- role — роль (набор прав).
- permission — разрешение на операцию.
- admin_action — действие админа, которое обязано попасть в audit.
- audit_log — журнал аудита админ-действий.
- sensitive_operation — операция с повышенным риском.
- idempotency_key — ключ идемпотентности для операций,
  изменяющих состояние и баланс.

---

## 2. Общие правила доступа

1) Разделение доступа
- user API — доступен только пользователю по global_id.
- admin API — доступен только админам по global_id.

2) Канон идентификатора
- Во всех админ-действиях и аудите используется только global_id.

3) Аудит и идемпотентность
- Все sensitive_operation обязаны:
  - иметь audit_log запись,
  - требовать Idempotency-Key,
  - логировать global_id исполнителя и цель операции.

4) Принцип наименьших привилегий
- Роль получает только те права, которые нужны для задач.

---

## 3. Роли (каноничный набор)

Минимальный канон ролей:
- viewer — только просмотр (read-only).
- operator — операционные действия без изменения банка.
- finance — финансы (банк, корректировки, подтверждения).
- auditor — аудит и отчёты (read-only + экспорт).
- admin — полный доступ.
- owner — владелец/суперадмин, включая критичные настройки.

Примечание:
- Если в текущем runtime нет полной ролевой модели, документ
  используется как целевое SSOT.

---

## 4. Матрица прав (операции)

Легенда:
- R — read (просмотр)
- W — write (изменение)
- A — audit required
- I — idempotency required

### 4.1 Пользователи

- Просмотр профиля пользователя
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Корректировка баланса пользователя (EFHC)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Изменение статусов (VIP / NFT / ранг) вручную
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.2 EFHC Bank

- Просмотр баланса банка и журнала операций
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Ручная корректировка банка (bank_operation)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Массовые операции банка
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I
  Требование: отдельное подтверждение и отдельный audit.

### 4.3 Withdrawals

- Просмотр очереди заявок
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Изменение статуса заявки (approve / reject / paid / error)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Назначение приоритета (VIP priority)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.4 Hub / Commerce

- Просмотр commerce-сущностей текущего HEAD
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Подтверждение покупки / операции после внешней оплаты
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Возврат / отмена там, где это предусмотрено
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.5 Tasks / Ads / Referrals

- CRUD задач и модерация выполнений
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Управление Ads provider layer и ручная диагностика
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Ручные бонусные действия в referrals contour
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.6 Логи, события и отчёты

- Просмотр audit_log / events
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Экспорт отчётов
  - viewer: -
  - operator: -
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

---

## 5. Требования к реализации

1) Любой admin endpoint обязан иметь:
- required_role или эквивалентный guard,
- audit_log для W A операций,
- Idempotency-Key для W I операций.

2) Любая операция, влияющая на баланс:
- должна иметь reason + details,
- должна быть атомарной.

3) Ошибки доступа
- Использовать единый формат ошибок:
  - error_code,
  - message,
  - details.
  См. `docs/NORM/ERROR_CODES.md`.
