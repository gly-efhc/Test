# Admin Runtime Fix and Seams Cleanup

Cycle: 1512  
Archive line: v170.87 -> v170.88

## Scope

This cycle fixes two runtime P1 defects in admin money paths and adds
regression guards so call-site/function-signature drift cannot pass
silently again.

## P1: withdraw hold repair

`WithdrawalsService.approve_withdrawal` no longer passes non-existing
`spend_bonus_first` or `forbid_user_negative` keyword arguments to
`debit_user_to_bank`.

This is safe because `debit_user_to_bank` already spends only MAIN and
already rejects negative user MAIN balance.

## P1: admin BONUS debit

`debit_user_bonus_to_bank` now accepts `meta` and forwards it into
`_run_idempotent`.

This preserves admin money audit context from
`BankService.manual_bank_user_transfer`, including:

- `admin_id`;
- `admin_role`;
- `admin_reason`;
- `source=admin_manual_bank_transfer`.

## Signature guard

`tests/architecture/test_admin_money_call_signatures.py` parses admin
money call sites and transaction-service signatures. The guard fails if
an admin call site passes a keyword that the target function does not
accept.

## Admin seams status

`adminSeams.ts` now exports constants for every current OpenAPI
`/admin` path. Existing raw `apiRequest('/admin/...')` usage in admin
pages is tracked in `ADMIN_SEAMS_CLEANUP_TRACKING.md` as temporary
migration debt, not silent drift.

## Orphan admin route status

Two routes are explicitly documented as legacy/internal until connected
to UI or removed in a later explicit cycle:

- `/admin/shop/items/set-price`;
- `/admin/tasks/{task_id}`.

## Release status

The input CI log was green for v170.87. This cycle still does not claim
GitHub CI green for v170.88 until a fresh rerun proves it.
