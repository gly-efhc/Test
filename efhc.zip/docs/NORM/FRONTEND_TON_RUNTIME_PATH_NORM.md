# FRONTEND TON RUNTIME PATH NORM

## Назначение
Этот документ фиксирует обязательный production-path для TON / TonConnect /
USDT во фронтенде EFHC Bot.

## Норма production-path
Во frontend production/runtime path разрешены только:
- опубликованные TON пакеты;
- опубликованный TonConnect SDK path;
- EFHC-owned код в `frontend/src/lib/*`;
- локальный compat-layer только как тонкий переходный UI-шов.

## Разрешённый runtime-набор
### TON runtime
- `@ton/core`
- `@ton/ton`
- `buffer`
- `@ton/crypto` только если реально нужен коду

### TonConnect
- целевой путь: `@tonconnect/ui-react` / `@tonconnect/ui`
  или контролируемый Tonkeeper-compatible alias
- текущий переходный допуск: локальный compat-layer для
  `@tonconnect/ui-react`, без возврата raw donor-source для SDK/runtime

## Запрещено
Запрещено делать частью активного frontend runtime path:
- `../песочница/*/src`
- `../песочница/sdk-main/packages/sdk/src/*`
- любые `tsconfig paths`, которые возвращают `@ton/core`, `@ton/ton`,
  `@ton/crypto`, `@tonconnect/sdk`, `@tonconnect/protocol`,
  `@tonconnect/isomorphic-fetch`, `@tonconnect/isomorphic-eventsource`
  в raw donor-source

Песочница допускается только как reference-only слой.

## USDT / jetton норма
USDT frontend path должен оставаться минимальным и контролируемым:
- вычисление jetton wallet через `@ton/ton`
- сборка TEP-74 payload через `@ton/core`
- отправка через TonConnect transport
- финальная валидация платежа — только на backend watcher слое

## Guard policy
Репозиторий должен содержать тест/guard, который не допускает возврат raw
 donor-source в активный frontend runtime path.

## Donor/reference consolidation — 2026-04-24

Sandbox archives and external repositories may be used for study, comparison
and manual adaptation only. They must not be imported as raw runtime source into
active frontend paths.

Allowed use:
- inspect reference implementations;
- extract architecture patterns manually;
- write EFHC-owned code based on the project canon;
- document compatibility decisions.

Forbidden use:
- embedding sandbox ZIPs in the release archive;
- pointing TypeScript aliases at raw donor source;
- treating donor code as already verified EFHC runtime code.

## Reactive restore and proof rule

The local UI compatibility layer must remain a thin reactive adapter over the
published TonConnect SDK. It must subscribe to connector wallet status and must
not expose a stale `connector.wallet` snapshot as React state.

The full TonProof envelope is sent to the authoritative wallet-binding route.
Splitting proof verification from an incomplete binding request is forbidden.
User rejection code `300` must have a separate public state for both connection
and transaction requests.
