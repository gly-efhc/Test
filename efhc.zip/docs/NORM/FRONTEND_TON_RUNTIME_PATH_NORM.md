# FRONTEND TON RUNTIME PATH NORM

## Назначение
Этот документ фиксирует обязательный production-path для TON / TonConnect /
USDT во фронтенде EFHC Bot.

## Норма production-path
Во frontend production/runtime path разрешены только:
- опубликованные TON пакеты;
- опубликованный TonConnect SDK path;
- EFHC-owned код в `frontend/src/lib/*`;
- локальный compat-layer только как тонкий переходный UI-шов.

## Разрешённый runtime-набор
### TON runtime
- `@ton/core`
- `@ton/ton`
- `buffer`
- `@ton/crypto` только если реально нужен коду

### TonConnect
- целевой путь: `@tonconnect/ui-react` / `@tonconnect/ui`
  или контролируемый Tonkeeper-compatible alias
- текущий переходный допуск: локальный compat-layer для
  `@tonconnect/ui-react`, без возврата raw donor-source для SDK/runtime

## Запрещено
Запрещено делать частью активного frontend runtime path:
- `../песочница/*/src`
- `../песочница/sdk-main/packages/sdk/src/*`
- любые `tsconfig paths`, которые возвращают `@ton/core`, `@ton/ton`,
  `@ton/crypto`, `@tonconnect/sdk`, `@tonconnect/protocol`,
  `@tonconnect/isomorphic-fetch`, `@tonconnect/isomorphic-eventsource`
  в raw donor-source

Песочница допускается только как reference-only слой.

## USDT / jetton норма
USDT frontend path должен оставаться минимальным и контролируемым:
- вычисление jetton wallet через `@ton/ton`
- сборка TEP-74 payload через `@ton/core`
- отправка через TonConnect transport
- финальная валидация платежа — только на backend watcher слое

## Guard policy
Репозиторий должен содержать тест/guard, который не допускает возврат raw
 donor-source в активный frontend runtime path.
