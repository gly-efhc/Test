# FRONTEND REPORT STANDARD — ACTIVE

## Актуальное решение OWNER — 25 октября 2026 года

**OWNER, последующее уточнение 25.10.2026:** каждый законченный материальный блок обязательно получает новый последовательный numbered report. Ранее разрешённое отсутствие отчёта было строго разовым и не создаёт постоянной политики. Обязательное сохранение после материального блока осуществляется полным ZIP-SAVEPOINT и двумя HTML даже при `PARTIAL`, без выдуманного CI PASS. Исторические numbered отчёты не менять без новой адресной OWNER-команды. См. `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`.


Статус: **ACTIVE / CURRENT / OWNER-APPROVED**.

Authority: `docs/NORM/EFHC_REPORTING_RULES_TZ.md`. При конфликте это ТЗ выше старых active reporting rules. Исторические reports/evidence immutable.

## OWNER-facing closure

Обычный completed-cycle closure отвечает по смыслу только на два пункта: фактический результат текущего цикла и следующий последовательный цикл. Сами вопросы как заголовки/boilerplate не печатаются.

Форма:
`FRONTEND_ADMIN_CYCLE_0XXX — завершён.`
`Сделано: <краткий человеческий фактический результат>.`
`Создан physical release FRONTEND_vNNN.` — только когда release обязателен.
`Следующий цикл: FRONTEND_ADMIN_CYCLE_0YYY — <название/цель только если уже утверждены>.`

Если план следующего цикла отсутствует, указывается только следующий последовательный номер; scope/название не придумываются. Следующий цикл автоматически не запускается. Реальный blocker упоминается кратко только если он существует.

В обычный чат запрещено выводить SHA/CRC, test counters, EAM counters, commit/run/deployment IDs, команды, логи, exit codes, tool/schema diagnostics, manifests, matrices, длинные file lists, internal paths, numbered-report replay или ссылку на numbered report. Подробный отчёт означает больше человеческого объяснения, а не technical dump.

В чат выдаются только конечные release artifacts: `FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`. Service/evidence files остаются внутри проекта.

## Новое решение OWNER — 24 октября 2026 года

Прямой приказ OWNER: исправить номерные отчёты по действующему русскому
стандарту **без языковых и форматных исключений**, включая ранее закреплённые
группы `00687–00692` и `00697–00721`. Этот приказ однократно разрешает
переработку этих документов в новом физическом выпуске, несмотря на прежний
запрет изменения завершённой истории. Исходный ZIP `FRONTEND_v818.zip`
остаётся неизменённым контрольным образцом. Предыдущие и исправленные SHA-256
помещаются в новый последовательный отчёт о миграции; факты, технические
идентификаторы и результаты испытаний нельзя придумывать или повышать до PASS.

С `00687` действуют строгие проверки русского авторского текста для каждого
отчёта; исключений `00687–00692` по языку больше нет. Для отчётов начиная
с `00481` действуют обязательные структурные секции; прежние исключения
`00697–00721` и `historical_migrated` для структуры больше не применяются.
Документы до соответствующих дат принятия контрактов сохраняют исходную
допустимую структуру; это не явное исключение по действующему контракту.

Предыдущие решения об исключениях, цитируемые ниже, сохраняются только как
история процесса и **не действуют** после настоящего прямого решения OWNER.
Ни один последующий агент не вправе произвольно переписывать уже
исправленные документы без новой прямой команды OWNER.

## Numbered report

Один report = итог законченного рабочего блока/цикла или действительно самостоятельной завершённой итерации. Report пишется после завершения всего набора связанных работ, а не после каждого маленького fix. В один report можно и нужно включать несколько выполненных задач: 5–10 связанных задач одного цикла фиксируются одним итоговым report. Мелкие изменения, commits, проверки, паузы и истечение timebox внутри одного цикла не создают отдельные reports и не означают завершение самостоятельной итерации.

Отдельный report нужен только для реально завершённого самостоятельного блока/цикла/итерации. Один MAIN-cycle может иметь несколько таких reports; каждый следующий report получает новый последовательный report number и отдельный `iteration_NN`. После завершения блока и финализации report его содержимое становится immutable и больше не дописывается.

Canonical filename для новых reports: `NNNNN__reports_<CYCLE_ID>_iteration_NN_<описание>.md`. Номер всегда стоит первым. Report ledger независим от MAIN-cycle numbering и physical release numbering.

Вверху report — human-readable итог блока, все выполненные задачи, способ, status и следующий шаг. Ниже — materially relevant решения, hashes, test/CI evidence, blockers и provenance, необходимые для проверки общего результата. `reports` — итоговый доказательный слой, а не журнал каждой мелкой операции; пошаговый technical dump и запись каждой команды не требуются. Новые отдельные log/evidence sidecars для рутинного логирования не создаются; существующий `reports/evidence/` считается historical/contract-required compatibility layer и не является параллельным журналом.

Обязательный файловый блок: `Изменены`, `Созданы`, `Удалены`; пустая категория = `нет`.

По умолчанию завершённые отчёты неизменны; OWNER отдельно разрешил однократное исправление содержания исторических отчётов 24.10.2026 с anti-loss доказательствами. Прочие изменения истории запрещены. Exact byte-identical duplicates сводятся к одной canonical copy; при необходимости объединения разных исторических payloads оно документируется отдельным migration report без потери исходного содержания.

Если пропущена запись reports, все пропущенные выполненные задачи собираются в один сводный recovery report с фактическими циклами/блоками и provenance из Git history. Нельзя размножать reports задним числом на каждый fix/commit или выдумывать самостоятельные итерации. Recovery получает следующий фактический report number; существующие immutable reports и строгая sequence/hash/path integrity сохраняются.

Единственный authoritative machine manifest: `reports/FRONTEND_REPORT_MANIFEST.json`. `reports/FRONTEND_NUMBERING_MANIFEST.csv` не используется и не допускается как параллельный authority. Human-readable правила и current pointers находятся в `reports/README.md`.

Canonical structure: `reports/numbered/`, `reports/cycles/`, `reports/rules/`; `reports/evidence/` допускается только как frozen historical/contract-required compatibility layer. Для report/cycle/rules identities имя начинается с номера. Cycle0432 historical migration завершена; `PENDING_0432` и параллельный numbering CSV запрещено восстанавливать.

Все новые `reports` Frontend пишутся на русском языке. Английский сохраняется только в технических идентификаторах, именах файлов/путей, API/коде и иных неизменяемых терминах.

Physical release не обязан иметь связь 1:1 с report или cycle. При этом обязательный material release checkpoint всё равно должен быть физически создан согласно archive/release law до объявления соответствующего material state завершённым.

## Dynamic navigation during active work

Report sequence has two modes. **WORK MODE:** physical numbered corpus is the navigation baseline; stale README/current pointer/manifest metadata is `REPORT_NAVIGATION_DRIFT`, is corrected dynamically inside the current authorized iteration and does not by itself block engineering work. An in-progress report is mutable until its iteration is closed. **CLOSURE MODE:** the completed report becomes immutable and the physical corpus, JSON manifest, README/index and `next=N+1` must be strict and coherent before closure/physical release.

`ops/reports/check_numbered_reports.py` is therefore a strict closure/release gate, not a startup permission gate. Hard stop is reserved for ambiguous/colliding physical report identities, historical data-loss/corruption risk or an authority conflict that cannot be repaired safely. Full law: `reports/rules/00002__rules_dynamic_reports_navigation_nonblocking_work.md`.

## Предыдущая политика после Cycle0491 (историческая, изменена 24.10.2026)

В `FRONTEND_v770` физические numbered reports `00001–00721` имели строгую
непрерывную нумерацию и верные пути/хеши в manifest. 51 нарушение legacy
формата относилось к 23 завершённым отчётам `00697–00721`; потери или
пропуска физических номеров не обнаружено.

Подлинные завершённые документы сохраняются побайтово. Их несовпадение с
позднейшим шаблоном не является разрешением переписывать историю. Для
ограниченного списка исторических исключений применяется **жёсткая
привязка SHA-256 к исходному содержимому**; при изменении хотя бы байта
проверка завершается ошибкой. Строгий контроль последовательности,
манифеста, путей и хешей обязателен для **всего** numbered-корпуса.

Все вновь создаваемые записи, начиная с текущего отчёта 00722, обязаны
соответствовать полному действующему русскому формату, иметь явно указанную
идентичность цикла и блоки `Результат`, `Полный список файлов итерации`,
`Проверки`, `Следующий цикл`. Пропущенные самостоятельные блоки при наличии
доказательств объединяются в один новый последовательный recovery report;
без доказательства фактической утраты отчёты задним числом не создаются.

## Hygiene / preflight

Temporary files: `DELETE_DIRECT` удаляются до release; `REQUIRED_EVIDENCE` сохраняются только внутри authority; `REVIEW` не удаляются и не становятся authority без решения OWNER.

Перед chat closure выполняется один bounded preflight: сформировать → один раз проверить по ТЗ → при нарушении один раз исправить. Recursive report validators/retry loops запрещены.

## Numbering integrity

Источник report numbering — `reports/FRONTEND_REPORT_MANIFEST.json` + физический numbered corpus текущего release. Последовательность номеров `00001…NNNNN` строгая; следующий report = `N+1`. Planned/reserved identity номер не расходует. Во время OWNER-authorized historical migration допускается временный mixed filename format только при однозначном извлечении номера и anti-loss mapping; после migration все canonical filenames должны начинаться с номера.

## Историческое решение OWNER от 21.10.2026 (заменено решением 24.10.2026)

Исходные numbered reports `00687`–`00692` являются завершёнными историческими документами. Сохранить исходные байты, номера, пути и хеши из авторитетного манифеста; не переписывать задним числом и не удалять следы первоначальной редакции. OWNER-разрешённая переработка их англоязычного авторского текста под действующий русский канон выполняется в **новом последовательном сводном numbered report**, со ссылками на сохранённые исходные записи и указанием их содержания. Вновь созданный сводный report полностью подчинён правилу русского авторского текста.

Начиная с номера `00693`, автоматическая проверка русского авторского текста обязательна для каждого нового numbered report. Для замороженных `00687`–`00692` проверяется **строгое совпадение каждого исходного SHA-256** с закреплённым списком и манифестом; это исключение по содержанию языка не является исключением по целостности. Общая проверка последовательности/хешей действует для всех отчётов `00001..N`. Предыдущие завершённые записи не пересоздаются ради нового канона.

Постоянные тесты, противоречащие новым действующим стандартам безопасности, срочно переписываются по новому разделу `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`: защищённый invariant не ослаблять, безопасное исправление не откатывать.
