# Tests Catalog

Status: active catalog + merge-review ledger
Last audited HEAD: `EFHC_Bot_v164_39_cycle_docs_canon_and_refresh_wave.zip`
Latest log reviewed: `logs_63368478117.zip`

Confirmed current Python test files: **155**

Active grouped counts:
- `tests/architecture/`: 100
- `tests/core/`: 4
- `tests/efhc_backend/unit/`: 10
- `tests/healer/`: 4
- root `tests/test_*.py`: 35

Current state:
- Latest reviewed CI log is green: `pytest = 329 passed`, `ruff` passed, `flake8 critical = 0`, `mypy` success, `npm build` success.
- Cycle 236 manually cleaned stale historical lock tests that were tied to pre-reorg doc paths.
- Cycle 237 reviewed root test clusters without forced deletions because the latest CI was already green.
- Cycle 239 applied a controlled helper-level consolidation to the payment-intents pack through `tests/payment_intents_testkit.py` while keeping explicit scenario tests separate.
- Cycle 245 applied a controlled helper-level consolidation to the concurrency pack through `tests/concurrency_testkit.py` while keeping explicit scenario tests separate.
- Cycle 246 applied a controlled helper-level consolidation to the panels pack through `tests/panels_testkit.py` while keeping explicit scenario tests separate.
- Cycle 247 applied a controlled helper-level consolidation to the wallet/TON pack through `tests/wallets_ton_testkit.py` while keeping explicit static SSOT/route guards separate.

## Merge-review candidates for next waves
- Concurrency trio: helper-level consolidation partially applied in cycle 245 via `tests/concurrency_testkit.py`; scenario tests remain explicit and separate.
- Payment intents pack: helper-level consolidation partially applied in cycle 239 via `tests/payment_intents_testkit.py`; scenario tests remain explicit and separate.
- Wallet / TON cluster: helper-level consolidation partially applied in cycle 247 via `tests/wallets_ton_testkit.py`; static SSOT/route guards remain explicit and separate.
- Panels pack: helper-level consolidation partially applied in cycle 246 via `tests/panels_testkit.py`; scenario tests remain explicit and separate.

- Cycle 249 cleanup review concluded that the root merge phase is sufficiently cleaned after the payment-intents, concurrency, panels and wallet/TON helper waves.

## Retired / historical ledger
- Cycle 236 already retired the stale historical lock wave that still targeted pre-reorg docs and removed files; the detailed retired set is fixed in `reports/change_cycle_2026-04-02_v163_03_cycle_236_manual_stale_tests_cleanup.md`.

## Active inventory

### Architecture tests
- `tests/architecture/test_active_frontend_wording_sync_lock.py`
- `tests/architecture/test_admin_panel_limit_counts_only_active.py`
- `tests/architecture/test_admin_reports_overview_metrics.py`
- `tests/architecture/test_admin_route_modules_canon.py`
- `tests/architecture/test_admin_routes_guarded.py`
- `tests/architecture/test_api_finance_canon.py`
- `tests/architecture/test_backend_admin_referral_wording_sync_lock.py`
- `tests/architecture/test_bank_runtime_invariants.py`
- `tests/architecture/test_bot_webapp_entrypoint_stabilization_lock.py`
- `tests/architecture/test_cycle_102_alias_sunset_and_0001_squash_lock.py`
- `tests/architecture/test_db_diagnostics_docs_sync.py`
- `tests/architecture/test_deposit_packages_contract.py`
- `tests/architecture/test_efhc_notation_frontend.py`
- `tests/architecture/test_exchange_faq_approved_rewrite_wave1_lock.py`
- `tests/architecture/test_exchange_mirror_and_locks.py`
- `tests/architecture/test_faq_approval_governance_restore_lock.py`
- `tests/architecture/test_faq_banned_terms_absent.py`
- `tests/architecture/test_faq_catalogs_generated_from_ssot.py`
- `tests/architecture/test_faq_code_generation_hardening_lock.py`
- `tests/architecture/test_faq_ru_synced_with_ssot.py`
- `tests/architecture/test_faq_ru_wave2_refinement_sync.py`
- `tests/architecture/test_faq_translations_wave1_sync.py`
- `tests/architecture/test_faq_translations_wave2_sync.py`
- `tests/architecture/test_faq_translations_wave3_sync.py`
- `tests/architecture/test_financial_integrity.py`
- `tests/architecture/test_forbidden_identifiers_repo.py`
- `tests/architecture/test_forbidden_wording_ru_rewrite_wave1_lock.py`
- `tests/architecture/test_frontend_haptics_policy.py`
- `tests/architecture/test_frontend_no_hardcoded_ui_strings.py`
- `tests/architecture/test_frontend_page_shell_coverage.py`
- `tests/architecture/test_frontend_release_artifact_hygiene.py`
- `tests/architecture/test_frontend_screen_states_coverage.py`
- `tests/architecture/test_frontend_tabs_canon.py`
- `tests/architecture/test_frontend_translation_coverage.py`
- `tests/architecture/test_generation_rate_canon_only.py`
- `tests/architecture/test_great_canon_guard.py`
- `tests/architecture/test_hub_admin_migration_model_wave_lock.py`
- `tests/architecture/test_hub_faq_approved_rewrite_wave1_lock.py`
- `tests/architecture/test_hub_ui_naming_wave1_lock.py`
- `tests/architecture/test_hub_user_facing_catalog_removal_lock.py`
- `tests/architecture/test_hub_vip_getgems_alignment_wave1_lock.py`
- `tests/architecture/test_lang_code_uk_only.py`
- `tests/architecture/test_max_line_length_72.py`
- `tests/architecture/test_me_user_route_overlap_canon.py`
- `tests/architecture/test_migration_0001_orm_ssot_sync.py`
- `tests/architecture/test_migration_invariants_hardening.py`
- `tests/architecture/test_migrations_numbering_canon.py`
- `tests/architecture/test_monetary_rate_limit_enabled.py`
- `tests/architecture/test_no_available_kwh_direct_debit.py`
- `tests/architecture/test_no_backend_app_imports_repo.py`
- `tests/architecture/test_no_banned_rank_terms.py`
- `tests/architecture/test_no_daily_generation_tokens.py`
- `tests/architecture/test_no_raw_create_task.py`
- `tests/architecture/test_no_tg_id_aliases_repo.py`
- `tests/architecture/test_no_total_generated_kwh_decrement.py`
- `tests/architecture/test_openapi_startup_consistency.py`
- `tests/architecture/test_panels_activate_route_freeze_lock.py`
- `tests/architecture/test_panels_bot_ui_approved_rewrite_wave1_lock.py`
- `tests/architecture/test_panels_no_local_numeric_casts.py`
- `tests/architecture/test_plan_docs_collapse_wave1_lock.py`
- `tests/architecture/test_referral_level_bonus_runtime.py`
- `tests/architecture/test_release_artifact_hygiene_wave2.py`
- `tests/architecture/test_route_error_response_canon.py`
- `tests/architecture/test_route_idempotency_policy.py`
- `tests/architecture/test_route_inventory_freeze_sync.py`
- `tests/architecture/test_route_prefixes_no_embedded_api.py`
- `tests/architecture/test_schema_count_two.py`
- `tests/architecture/test_services_no_http_exception.py`
- `tests/architecture/test_shop_admin_contract_freeze_lock.py`
- `tests/architecture/test_shop_spending_order_canon.py`
- `tests/architecture/test_skin_switcher_concept_closure_lock.py`
- `tests/architecture/test_skin_switcher_implementation_wave1_lock.py`
- `tests/architecture/test_skins_canon_refactor_wave1_lock.py`
- `tests/architecture/test_tg_id_access_contracts.py`
- `tests/architecture/test_tonconnect_frontend_wallet_binding.py`
- `tests/architecture/test_tonconnect_tma_integration.py`
- `tests/architecture/test_topbar_faq_approved_rewrite_wave1_lock.py`
- `tests/architecture/test_user_withdraw_requests_visible.py`
- `tests/architecture/test_vip_faq_approved_rewrite_wave1_lock.py`
- `tests/architecture/test_wallet_faq_approved_rewrite_wave1_lock.py`
- `tests/architecture/test_withdraw_admin_contract.py`
- `tests/architecture/test_withdraw_runtime_invariants.py`

### Core tests
- `tests/core/test_async_tasks.py`
- `tests/core/test_core_math_econ.py`
- `tests/core/test_monetary_idempotency_middleware.py`
- `tests/core/test_monetary_rate_limit_middleware.py`

### EFHC backend unit tests
- `tests/efhc_backend/unit/test_cursor_codec_ssot.py`
- `tests/efhc_backend/unit/test_exchange.py`
- `tests/efhc_backend/unit/test_finance_spend_rules.py`
- `tests/efhc_backend/unit/test_no_legacy_words.py`
- `tests/efhc_backend/unit/test_orders.py`
- `tests/efhc_backend/unit/test_shop_items.py`
- `tests/efhc_backend/unit/test_ssot_idempotency.py`
- `tests/efhc_backend/unit/test_ssot_tg_only.py`
- `tests/efhc_backend/unit/test_telegram_init_data.py`
- `tests/efhc_backend/unit/test_transactions.py`

### Healer tests
- `tests/healer/test_healer_atlas_rules.py`
- `tests/healer/test_healer_atlas_sync.py`
- `tests/healer/test_healer_casebook_sync.py`
- `tests/healer/test_healer_unknown_draft.py`

### Root tests
- `tests/test_alembic_healthcheck_soft.py`
- `tests/test_build_sanity.py`
- `tests/test_canon_guard_negative.py`
- `tests/test_concurrency_exchange_all.py`
- `tests/test_concurrency_exchange_withdraw.py`
- `tests/test_concurrency_withdraw_double.py`
- `tests/test_economics_transactions.py`
- `tests/test_exchange_audit_fields_complete.py`
- `tests/test_frontend_telegram_api_guard.py`
- `tests/test_gen_rate_vip_switch.py`
- `tests/test_migrations_upgrade_head.py`
- `tests/test_no_banned_identifiers.py`
- `tests/test_no_placeholders.py`
- `tests/test_panels_180_days.py`
- `tests/test_panels_active_archive.py`
- `tests/test_panels_global_id.py`
- `tests/test_panels_idempotent_create.py`
- `tests/test_panels_ssot_backend.py`
- `tests/test_panels_uses_canon_formatter.py`
- `tests/test_payment_intent_status_owner_only.py`
- `tests/test_payment_intents_ab_ssot.py`
- `tests/test_payment_intents_lifecycle_double_payments.py`
- `tests/test_payment_intents_payload_unique.py`
- `tests/test_payment_intents_usdt_tx_and_confirm.py`
- `tests/test_per_sec_constants_settings.py`
- `tests/test_per_sec_literals_guard.py`
- `tests/test_tonconnect_wallets_ssot.py`
- `tests/test_total_generated_kwh_append_only.py`
- `tests/test_ui_ssot_no_float_number.py`
- `tests/test_unmatched_incoming_recording.py`
- `tests/test_utcnow_ssot.py`
- `tests/test_wallets_connect_hardening.py`
- `tests/test_wallets_tonconnect_semantics_guard.py`
- `tests/test_withdraw_state_machine.py`

- `tests/architecture/test_frontend_ton_runtime_path_guard.py` — guard against returning raw donor-source to active frontend TON/TonConnect runtime path; also locks published deps and early polyfill import.

- `tests/architecture/test_hub_external_handoff_neutrality.py` — locks the external EFHC handoff to neutral balance-top-up wording and forbids product wording before leaving Telegram.

- `tests/architecture/test_frontend_ton_runtime_path_guard.py`
- `tests/architecture/test_hub_external_handoff_neutrality.py`
- `tests/architecture/test_vip_external_verification_guard.py`

## Latest Telegram-side storefront guards
- Added runtime-path guard for published TON/TonConnect path.
- Added neutral EFHC external handoff guard.
- Added VIP external verification guard: Telegram-side VIP card must stay external-collection wording and must not drift into in-app sale / activation wording.

- `tests/architecture/test_common_shell_handoff_and_tonconnect_contract.py`
- `tests/architecture/test_unified_external_storefront_norm_sync.py`

## Latest common-shell guards
- Added common-shell TonConnect/provider/handoff contract guard.
- Added unified external storefront norm-sync guard.
- Local proof pack on latest pass: 12 passed.
