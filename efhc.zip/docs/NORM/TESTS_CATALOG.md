<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
# Каталог активных тестов EFHC

## Назначение

Каталог описывает только постоянный активный test-layer. Исторические, cycle-specific и version-specific проверки вынесены во внешний artifacts history ZIP и отсутствуют в active HEAD; pytest их не собирает.

## Канон идентичности

- `global_id` — единственный account/business owner.
- внешний `global_id` — строка ровно из десяти ASCII-цифр;
- `tg_id` допускается только на Telegram/provider boundary;
- business-service calls через `tg_id` запрещены;
- migration остаётся единственной `0001_initial_release_schema.py`.

## Тематические группы

1. Identity и provider boundaries.
2. Business и экономические инварианты.
3. PostgreSQL ORM/0001/raw SQL consistency.
4. API/OpenAPI/frontend contracts.
5. Security, release и archive hygiene.
6. Telegram/TON delivery and authentication.

## Guards

- `ops/identity/check_active_test_surface.py`;
- `ops/identity/force_test_global_id_cutover.py`;
- `scripts/ci/check_test_suite_integrity.py`;
- `tests/architecture/test_active_test_surface.py`.

Active HEAD не зависит от архивного test manifest. Архивные bytes сохраняются только во внешнем history ZIP.
