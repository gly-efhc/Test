# AI Execution Bounds and Handoff Standard

Status: ACTIVE NORM.
Archive: `v171.60`.

## 1. Purpose

Prevent two failures at once:

- replacing real repair with endless CI/browser/dependency loops;
- using anti-hang rules as an excuse not to run necessary verification.

## 2. CI is allowed

The user has not prohibited CI, pytest, build, typecheck, lint, browser tests or regression.

The AI may run the verification required by the task or release stage. It must not claim that local execution is GitHub CI. Fresh GitHub CI status requires a real GitHub log for the exact HEAD.

## 3. Bounded execution

For every broad command:

- use an explicit timeout;
- preserve stdout/stderr and checkpoints;
- do not automatically repeat the same full command after a hang;
- treat confirmed root cause before rerunning;
- continue independent work and packaging when possible.

A hanging optional check must not silence the assistant for hours or block a valid development snapshot.

## 4. Validation order

```text
read exact evidence
→ identify root cause
→ bounded repair
→ targeted tests/guards
→ necessary build/regression once
→ package development archive
→ report honest remaining boundary
```

## 5. Screenshot boundary

PNG screenshots are local visual evidence and are not required GitHub CI artifacts.

GitHub CI may verify route scripts, DOM markers, HTTP status, JSON browser reports, overflow and error counts. It must not require PNG files, PNG hashes or a screenshots ZIP.

Application screenshots must be captured from the real running app with `page.goto()`. `page.set_content` or manual HTML is prototype/reference only and cannot be called application proof.

## 6. Stop conditions

- External download outage: one bounded retry after confirmation, then record `BLOCKED_EXTERNAL`.
- Browser hang: terminate, preserve evidence, isolate changed route once if useful, do not repeat a full matrix automatically.
- Full regression hang: stop the hanging batch, preserve checkpoint and report exact boundary.

## 7. Archive handoff

After requested changes and targeted guards, create a development archive even if release-only proof is open. Label it honestly. A release archive remains separate.

## 8. Honest vocabulary

Allowed: `CODE_FIXED`, `TARGETED_CHECKS_PASSED`, `LOCAL_BUILD_PASSED`, `LOCAL_VISUAL_EVIDENCE_CREATED`, `BLOCKED_EXTERNAL`, `BLOCKED_RUNTIME`, `GITHUB_CI_NOT_RUN`, `UNKNOWN`.
