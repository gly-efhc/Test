# WebApp Referral Bind Retry Semantics

WebApp referral bind is best-effort and UI-safe. The session marker is now:

- `pending` while the background request is in flight;
- `done` only after successful backend response;
- removed after failure so the same session can retry.

No error toast is shown for background referral bind failure. Backend
idempotency remains the canonical protection against duplicates.
