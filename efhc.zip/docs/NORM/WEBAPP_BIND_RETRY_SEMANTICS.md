# WebApp referral start-param transport retry semantics

Status: ACTIVE NORM. This document describes pre-auth referral transport only. It does **not** authorize a late referral-binding mutation.

## Current transport

On the first WebApp entry, the frontend may receive a referral start parameter from Telegram `initDataUnsafe.start_param` or one of the supported launch-query aliases. The frontend:

- normalizes only a valid referral code;
- stores only the normalized code (or an internal invalid marker) in `sessionStorage` under the current referral transport key;
- removes referral-bearing query parameters from the visible URL as a privacy best-effort step;
- never writes the raw launch value to persistent storage;
- never calls `/referrals/bind` or `/referrals/attach`.

The stored referral code is sent only while authentication may still create the account:

- Telegram session issuance: `POST /auth/telegram/session`;
- TON proof login: `POST /auth/ton/proof`.

The field name is `referral_start_param`. Existing-account attribution remains backend-fail-closed and cannot become a late bind.

## Retry / clear semantics

- Successful Telegram or TON authentication clears the session transport value.
- A malformed locally captured value is a final local error and is cleared.
- Backend `400` or `422`, or a recognized final invalid-referral reason, clears the value.
- Transient/network/server failures do not clear the value; the same browser session may retry authentication with the same normalized referral code.
- No background referral mutation and no referral-bind error toast are part of this flow.

Backend first-creation attribution and atomicity remain defined by `REFERRAL_DEEPLINK_BINDING_CANON.md`.
