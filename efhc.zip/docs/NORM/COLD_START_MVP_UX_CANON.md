# Cold Start MVP UX Canon

Status: active NORM.
Scope: EFHC Bot MVP, Telegram Mini App, browser and PWA shell.

## Purpose

Cold start latency is not a blocker for EFHC Bot MVP when the user sees
an immediate cached shell and a smooth loading/update effect. The first
visual state must not depend on a live database response.

## Canon decision

Cold start is acceptable for the MVP because EFHC Bot uses cached UX:

1. Show the local or previous interface first.
2. Show a visual loading/effect state while data refreshes.
3. Update data smoothly from backend and Neon after first paint.
4. Use stale-while-revalidate semantics for non-critical visual data.

## Forbidden

- Do not block the first screen waiting for the database.
- Do not run Alembic migrations on a user request.
- Do not load heavy assets before showing the interface.
- Do not make backend the only source of the initial visual state.
- Do not treat Cloud Run or Neon cold start as an MVP blocker by itself.

## Allowed

- Cloud Run `min instances = 0`.
- Neon Free / scale-to-zero.
- Cloud Scheduler health ping when operationally needed.
- Stale-while-revalidate data model.
- Cached shell first, backend refresh second.
- Optimized first-paint assets, including WebP for large hero images.

## First screen rule

The first screen must be a visible EFHC shell, not a blank page. It may
show cached balances, previous state, skeletons, visual progress or a
loading effect while backend data is refreshing.

## Asset rule

Heavy first-paint images must have an optimized runtime variant. The
source/canonical asset may stay available for compatibility, but CSS and
first paint should use the smallest visually safe runtime asset.

Current optimized bot/skin hero asset:

- source compatibility asset: `frontend/public/skins/1.webp`;
- runtime first-paint asset: `frontend/public/skins/1.webp`;
- target: keep the runtime first-paint image below 220 KB unless a
  design task explicitly approves a larger asset.

## Deployment implication

Cloud Run scale-to-zero and Neon scale-to-zero are allowed for the MVP.
They become a product risk only if the user sees a blank screen, broken
navigation or blocked core shell while backend wakes up.

## Verification language

Do not write that cold start is solved, measured or production-proven
without real measurements. Use these statuses:

- VERIFIED: measured with logs or browser/network proof.
- FOUND_NOT_VERIFIED: canon/documentation exists, but no measurement ran.
- UNKNOWN: no proof is available.
- BLOCKED: measurement cannot run because dependency/context is absent.
