<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# PACK-02 TON Wallet Canon / Admin Payout Canon

## Status

Cycle: `1507`.

Archive version: `v170.83`.

Mode: code cleanup + docs canon + architecture tests.

Economy changed: no.

Withdraw PACK-01 canon changed: no.


## Mandatory PACK-02 clarification

PACK-02 is closed as an implementation task, not as an exploratory
audit. The active wallet binding mechanism is fixed and singular:

```text
TonConnect proof
-> signature verification
-> wallet ownership proof
-> global_id binding
-> wallet_bindings
-> replay protection
-> idempotency
```

The legacy `wallet_binding_service.py` memo/bind-request runtime path is
removed from active runtime. Any future reintroduction must be rejected
unless the project canon is explicitly changed by a separate approved
cycle.

Admin payout remains an operator wallet-flow action and must not be
modelled as treasury/private funds access.

## Canon summary

EFHC Bot accepts valid TON address formats at the input boundary.
Inside the project, wallet ownership uses one canonical internal address:

```text
<workchain>:<64 lowercase hex account_id>
```

UI may display friendly, short or masked address, but DB ownership,
watcher lookup, conflict checks and unique constraints use canonical
address.

## Admin payout canon

Admin payout is an operator wallet action.

Admin does not receive technical access to project treasury/private
funds.

Withdraw payout is performed through TonConnect and an approved operator
wallet.

## Single wallet binding canon

The active wallet binding mechanism is:

```text
TonConnect proof
-> signature verification
-> wallet ownership proof
-> global_id binding
-> wallet_bindings
-> replay protection
-> idempotency
```

The legacy memo/bind-request runtime service was removed from active
runtime in PACK-02.

## Implementation notes

- `backend/app/lib/ton_address.py` provides canonical address helper.
- `wallets_service.normalize_wallet_address()` returns canonical address.
- `watcher_service._norm_addr()` canonicalizes valid TON addresses before
  lookup.
- `efhc_deposits_service._resolve_user_by_wallet()` canonicalizes valid
  sender address before wallet lookup.
- `wallet_bindings.wallet_address` remains the unique canonical key.
