<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# PROGRESS SYSTEM FOUNDATION

Status: `ACTIVE_PROGRESS_SYSTEM_FOUNDATION`

Cycle: `1463`

Archive target: `v170.39`

## Purpose

This document fixes the reusable progress language for EFHC Bot
Dashboard Visual Direction.

Progress bars must make Energy, Panels, Ranks, Tasks and Referrals
feel alive without changing EFHC economics or inventing fake truth.

## Active sources

Primary direction:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Component contract:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Panel chrome foundation:

`docs/NORM/PANEL_CHROME_FOUNDATION.md`

Grafana usage map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Runtime progress component:

`frontend/src/components/dashboard/ProgressSystem.tsx`

## Boundary

Grafana is visual-pattern reference only.

Песочница is reference, navigation and prototype layer only.

This cycle does not change EFHC economy, backend contracts, database
schema, CI, locks, money flow or user balances.

## Runtime components

The active progress system exports EFHC-owned components:

- `DashboardProgressBar`;
- `DashboardSegmentedProgress`;
- `DashboardCircularProgress`;
- `DashboardCountdownProgress`;
- `DashboardMilestoneProgress`.

Simulation wrappers:

- `SimProgressBar`;
- `SimSegmentedProgress`;
- `SimCircularProgress`;
- `SimCountdownProgress`;
- `SimMilestoneProgress`.

Admin wrapper:

- `AdminProgressBar`.

## Supported progress kinds

Allowed progress kinds:

- `linear`;
- `segmented`;
- `circular`;
- `countdown`;
- `milestone`.

Each kind is display-only. It must not create, approve, mint, burn,
withdraw, exchange or mutate money state.

## Truth model

Progress data must declare or imply one of the dashboard contract data
kinds:

- `raw`;
- `derived`;
- `synthetic_preview`;
- `real_timeseries`.

Derived progress is allowed only when the source is clear. Synthetic
preview progress must be marked and must not be presented as real
analytics.

## Canonical progress use cases

| Surface | Progress meaning | Data kind |
|---|---|---|
| Energy | next goal / rank progress | derived |
| Panels | lifetime countdown / expiry progress | derived |
| Ranks | current tier to next tier | derived |
| Tasks | completion progress | raw or derived |
| Referrals | active referral growth | raw or derived |
| Exchange | lightweight conversion readiness | raw or derived |
| Admin | status / queue / health completion | raw or derived |

## Countdown safety

Countdown progress must use real seconds math.

Constants:

- `SECONDS_PER_DAY = 86400`;
- `SECONDS_PER_HOUR = 3600`;
- `SECONDS_PER_MINUTE = 60`.

The old visual bug class `/ 86` or `/ 3` is forbidden for duration
formatting.

## Grafana alignment

Cycle 1463 maps Grafana progress-like elements to EFHC-owned
implementation targets:

| Grafana anchor | EFHC target |
|---|---|
| `BarGauge` | `DashboardProgressBar` / segmented progress |
| `RadialGauge` | `DashboardCircularProgress` |
| `BigValue/PercentChange` | progress value label / delta text |
| `StatusHistoryPanel` | future activity/status progress strip |
| `StateTimelinePanel` | future milestone/time progress timeline |
| `ProgressBar` | simple linear progress only |

The mapping is conceptual. No Grafana runtime source is copied.

## Safety rules

Progress components must not:

- change EFHC balance, kWh, panel lifetime or rank economics;
- invent fake leaderboard or task completion data;
- hide source/freshness requirements;
- show raw `global_id` in public progress widgets;
- show secrets, env values, initData or debug payload;
- import `@grafana/*` packages;
- add heavy chart dependencies.

## Acceptance criteria

- `ProgressSystem.tsx` exists in `frontend/src/components/dashboard/`.
- Linear, segmented, circular, countdown and milestone components exist.
- Simulation UI Kit exposes progress wrappers.
- Admin UI Kit exposes a safe progress wrapper.
- CSS uses dashboard tokens from cycle 1458.
- Grafana progress/gauge elements are mapped as reference only.
- Runtime code from Grafana or Песочница is not copied.
- No economy, backend, DB, CI or lock files are changed.

## Next step

Cycle `1464 — Mini Charts Foundation` should build dependency-safe
mini charts on top of the same truth model.


## Cycle 1464 continuation

Mini Charts Foundation extends the visual system with lightweight
SVG/CSS chart primitives. Progress components remain for percentage and
milestone states; mini charts are for compact trends and activity strips.

