# FRONTEND CYCLE TIMEBOX CANON

Status: `ACTIVE / OWNER PROCESS LAW`

- Канонический engineering timebox: **15–20 минут на bounded итерацию**.
- Один OWNER-authorized MAIN-cycle может содержать несколько последовательных итераций.
- Report пишется после завершения всего рабочего блока/цикла и объединяет несколько связанных задач (в том числе 5–10 задач). Отдельный immutable report нужен только для реально самостоятельной завершённой итерации; мелкие fixes, commits и истечение timebox не создают reports.
- Номер report, номер MAIN-cycle и physical release version независимы.
- Physical checkpoint создаётся по release law при material state change и по возможности фиксируется после соответствующей итерации; один cycle может иметь несколько physical releases.
- Старое правило `один cycle = один physical release` superseded и не применяется. Historical records не переписываются.
- Если scope не помещается в один timebox, работа продолжается следующим bounded отрезком того же OWNER-authorized cycle. Это не создаёт самостоятельную report iteration; итоговый report оформляется после завершения набора работ. Новый MAIN-cycle автоматически не открывается.
- Длинный/зависший процесс диагностируется bounded; промежуточные результаты накапливаются для общего итога. Пауза/диагностика не требуют отдельного report. Пропущенные задачи восстанавливаются одним сводным recovery report по фактической истории.
- Material state, для которого release law требует physical checkpoint, не считается физически закреплённым до coherent release.
- Следующий MAIN-cycle автоматически не запускается.

## Обязательная запись цикла

Одна запись цикла = один Cycle ID: ровно один четырёхзначный номер `NNNN`. Каждая current/planned cycle entry содержит обязательный минимум:

| Поле | Содержание |
|---|---|
| Cycle ID | Один номер `NNNN`, без диапазона, суффикса `+` или второго номера. |
| Status | Фактическое состояние конкретного цикла; DONE только после qualification. |
| Objective | Измеримый результат, который должен быть достигнут. |
| Scope | Работы, разрешённые OWNER в этом цикле. |
| Protected / Out of scope | Семантика и области, которые нельзя менять в данном scope. |
| Required work | Основные задачи для достижения Objective. |
| Qualification / DONE | Измеримые критерии завершения и существующие релевантные проверки. |
| Closure | Обновление затронутых current-state/roadmap файлов, один итоговый report завершённого блока, commit/sync в разрешённой ветке; release только по прямой authority/release law. |

Диапазоны допустимы только в обычном тексте как ссылка на группу циклов, но не как Cycle ID или общая status-запись. Каждый уже назначенный/зарезервированный номер имеет отдельную запись. Numbering gaps помечаются отдельно для каждого существующего номера; это не создаёт исполнявшуюся работу или retroactive report.

Будущее направление `0452+` — Global Themes lane, не Cycle ID. Оно размещается отдельно от cycle entries. Новые номера и scope внутри lane задаёт только OWNER. Для OWNER RESERVED entries Objective/Scope/Required work не выдумываются: явно фиксируется отсутствие назначения и запрет старта.

Действующие записи находятся в существующем canonical roadmap и cycle documents; guardian state — только derived projection. Исторические завершённые reports не переписываются, отдельный governance/check layer не создаётся.
