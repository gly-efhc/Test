# Admin Safe Error Summary Canon

Admin UI is an operator surface, not a backend log viewer. The main visible
admin text must be a safe summary. Raw backend payloads, exception messages,
HTTP dumps and stack-like text are not allowed as the primary UI copy.

Canonical admin behaviour:
- use `adminUiErrorMessage(...)` / `adminSafeLoadError(...)` for visible text;
- preserve technical payload only in telemetry, dev-only details or explicitly
  hidden diagnostic surfaces;
- do not display `e?.message || String(e)` or `error.message` as the main
  page state;
- do not use frontend workaround language to hide security/funds blockers from
  the team.
