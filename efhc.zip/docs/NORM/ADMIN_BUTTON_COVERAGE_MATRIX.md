# Cycle 1517 addendum — admin feature/component seam closure

Status: `DONE_LOCALLY`.

The admin button/API audit now covers not only `frontend/src/pages/admin`, but
also `frontend/src/features/admin` and `frontend/src/components/admin`.
Direct raw `apiRequest('/admin...')` is forbidden in those scopes. Admin route
calls must use `frontend/src/lib/api/generated/adminSeams.ts` via
`adminApiRequest()`, generated constants and `adminPath()` for templated paths.

Allowed exception: admin health widgets may use public `/api/health*` routes
through the base API client because those routes are not `/admin` routes.

# Admin Button Coverage Matrix

Admin payout is operator wallet action and not treasury access.

| Admin section | Button/action | Page/component | Handler/API client | Backend route | Service/CRUD | DB table | Guard | Audit log | Confirmation | Test | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Admin Overview | open dashboard | frontend/src/pages/admin/index.tsx | admin api seams | GET /admin/observability/* | observability services | observability tables | admin guard | read-only log N/A | N/A | tests | READ_ONLY |
| Admin Users | view/block/edit user | users.tsx | admin client | /admin/users/* | admin_users_service | users | require_admin | admin_action_log | required for mutations | tests | COVERED |
| Admin Bank | view/manual bank action | bank.tsx | admin client | /admin/bank/* | admin_bank_service | bank_balance, efhc_transfers_log | require_admin | admin_action_log | required for mutations | tests | COVERED |
| Admin Deposits | review deposits | efhc-deposits.tsx | admin client | /admin/reports/deposits | admin_reports_routes | payment_intents, ton_inbox_logs | require_admin | read-only log N/A | N/A | tests | READ_ONLY |
| Admin Withdrawals | operator payout | withdrawals.tsx | admin client | /admin/withdrawals/* | admin_withdrawals_service | withdraw_requests | require_admin | admin_action_log | required | tests | COVERED |
| Admin Shop | manage shop | shop.tsx | admin client | /admin/shop/* | shop_service | shop_items, shop_orders | require_admin | admin_action_log | required | tests | COVERED |
| Admin Sale Packages | manage packages | sale-packages.tsx | admin client | /admin/sale-packages/* | admin service | efhc_sale_packages | require_admin | admin_action_log | required | tests | COVERED |
| Admin Tasks | moderate tasks | tasks.tsx | admin client | /admin/tasks/* | admin tasks service | tasks, task_submissions | require_admin | admin_action_log | required | tests | COVERED |
| Admin Referrals | view referrals | referrals.tsx | admin client | /admin/referrals/* | referral services | referral_links | require_admin | read-only log N/A | N/A | tests | READ_ONLY |
| Admin Panels | manage panels | panels.tsx | admin client | /admin/panels/* | admin_panels_service | panels | require_admin | admin_action_log | required | tests | COVERED |
| Admin Ads | manage ads | ads.tsx | admin client | /admin/ads/* | ads routes/service | ads | require_admin | admin_action_log | required | tests | COVERED |
| Admin Logs / Events | view logs | logs.tsx | admin client | /admin/logs/* | logs routes | efhc_transfers_log | require_admin | read-only log N/A | N/A | tests | READ_ONLY |
| Admin Observability | view observability | index.tsx | admin seams | /admin/observability/* | admin_observability_routes | multiple read-only | require_admin | read-only log N/A | N/A | tests | READ_ONLY |
| Admin Reports | view reports | reports.tsx | admin seams | /admin/reports/* | admin_reports_routes | multiple read-only | require_admin | read-only log N/A | N/A | tests | READ_ONLY |
| Admin Templates | manage templates | templates.tsx | admin client | /admin/templates/* | templates service | system_templates | require_admin | admin_action_log | required | tests | COVERED |
| Admin System / Hub | system hub | system.tsx, hub.tsx | admin client | /admin/system/* | system routes | scheduler_task_log | require_admin | admin_action_log | required for mutations | tests | COVERED |

## Allowed statuses

`COVERED`, `READ_ONLY`, `API_ONLY`, `UI_ONLY_BUG`,
`ROUTE_ONLY_BUG`, `MISSING_GUARD`, `MISSING_AUDIT_LOG`,
`MISSING_TEST`, `SECTION_MISSING_JUSTIFIED`, `NOT_APPLICABLE`.
