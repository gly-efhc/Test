# WALLET PROVIDER ADAPTER NORM

Status: ACTIVE.
Applies from: `v171.66`.

## 1. Mandatory dependency direction

```text
feature/page/component
        ↓
WalletProvider / WalletAdapter contract
        ↓
provider-specific adapter
        ↓
external wallet API or SDK
```

Direct imports of `@tonconnect/ui-react`, TonConnect transaction helpers or a
future Telegram/native wallet API from application features are forbidden.
Provider-specific imports are allowed only inside the provider/adapter layer or
an explicitly preserved compatibility helper consumed by an adapter.

## 2. Required adapters

The provider registry must preserve three independent adapter identities:

- `tonconnect`;
- `telegram_wallet`;
- `native_gram_wallet`.

Removing, merging or silently aliasing these adapters requires direct user
instruction and synchronized SSOT/NORM changes.

## 3. Fail-closed unpublished API rule

If an official Telegram Wallet or native GRAM API is unavailable, unknown or
not injected:

- adapter `available=false`;
- session is `null`;
- connect/proof/transaction calls throw `WalletAdapterUnavailableError`;
- no mock address, signature, BOC or success status is created;
- TonConnect may remain the fallback adapter.

Do not infer method names, event names, request schemas or security properties
of an unpublished API.

## 4. Ownership proof

Every adapter that can bind a wallet must route an ownership proof to the
backend verification boundary. A connected frontend address alone is
insufficient.

An adapter may translate provider-specific proof data, but it may not weaken:

- server-generated one-time challenge;
- nonce expiry and one-use enforcement;
- domain binding;
- address/public-key/signature consistency;
- replay protection;
- audit trail.

If a provider cannot satisfy the approved proof boundary, wallet binding fails
closed until a new explicit security design is approved.

## 5. Transaction dispatch

Application features pass only a canonical `TonWalletTransaction` to
`WalletProvider.sendTransaction()`.

Adapters may translate this request into their external API. They must preserve:

- destination address;
- nanotone amount;
- payload/state-init when present;
- validity deadline;
- message order;
- explicit user rejection versus technical failure.

A successful adapter call means only that the provider returned a signed/send
result. It does not authorize frontend credit or mark backend settlement.

## 6. Runtime selection and replacement

A deployment may choose an available adapter through
`NEXT_PUBLIC_EFHC_WALLET_PROVIDER`. Changing the preferred wallet transport must
not require changes to deposit, Browser Shop, profile, Layout or admin payout
components.

When an official Telegram API is published, implementation work is:

1. map it inside `TelegramWalletAdapter` or `NativeGramWalletAdapter`;
2. add provider-specific proof and transaction tests;
3. preserve the public `WalletAdapter` contract;
4. perform live external verification separately.

## 7. UI and product boundary

This adapter refactor must not by itself:

- redesign the wallet UI;
- alter canonical routes or six-button navigation;
- change EFHC economics, balances or settlement rules;
- expose unavailable adapters as working;
- add provider-specific public wording without 13-language routing.

When rendered UI output is unchanged, new screenshots are not required. Any
future adapter selector or provider-specific state shown to users is a visual
and i18n change and requires route-backed proof.

## 8. Tests

Every wallet-provider change requires at minimum:

- adapter registry/contract guard;
- no-direct-provider-import guard for application features;
- TonConnect regression tests;
- TonProof cryptographic-boundary tests;
- user-rejection and transaction-dispatch tests;
- Operator Kernel exact-route test;
- TypeScript/build checks when dependencies are available;
- explicit documentation of any unavailable external proof.
