<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# VIP / NFT TonConnect Sync Canon — Cycle 1516

Status: `ACTIVE_CANON`

## Purpose

Close audit finding `P1-VIP-NFT-SYNC-BROKEN-FOR-TONCONNECT-USERS` without changing EFHC economics, VIP rules, bonus formulas, limits, rates or balances.

## Canonical wallet source order

1. Primary source: active `efhc_core.wallet_bindings` row for `global_id`.
2. Legacy fallback: `efhc_core.users.ton_wallet` only when no active wallet binding exists.
3. No wallet source: return `None` and perform safe no-op / false sync according to the existing VIP checker semantics.

`users.ton_wallet` is not restored as the main source of truth. It remains a legacy compatibility field.

## Runtime rules

- `NftCheckService.get_wallet_for_user()` must resolve `wallet_bindings` first.
- `check_user_vip_once()` remains the single safe one-user refresh entrypoint.
- `/v1/me` must not gate stale refresh by `users.ton_wallet`; it may call `check_user_vip_once()` when stale and let the resolver decide no-op vs refresh.
- Batch NFT/VIP discovery must include active `wallet_bindings` users.
- Batch NFT/VIP discovery must include legacy `users.ton_wallet` users only when no binding exists.
- A `global_id` must appear once in a batch candidate set.
- When both sources exist, `wallet_bindings` wins.

## Non-goals

- No economy changes.
- No VIP formula changes.
- No NFT collection rule changes.
- No balance mutation inside wallet resolution.
- No creation of wallet binding from the NFT checker.
- No change to TonConnect ownership proof canon.

## Guards

- `tests/efhc_backend/nft/test_vip_nft_tonconnect_wallet_binding_sync.py`
- `tests/architecture/test_db_drift_matrix.py`
